from __future__ import annotations

import importlib
from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from starlette.requests import Request

from spaps_server_quickstart.auth import (
    AuthenticationError,
    SpapsAuthMiddleware,
    SpapsAuthService,
    build_spaps_auth_service,
)
from spaps_server_quickstart.settings import BaseServiceSettings


class AuthSettings(BaseServiceSettings):
    spaps_api_key: str | None = "api-key"
    spaps_application_id: str | None = "app-id"


def test_build_spaps_auth_service_requires_keys() -> None:
    settings = BaseServiceSettings()
    with pytest.raises(ValueError):
        build_spaps_auth_service(settings)

    auth_settings = AuthSettings()
    service = build_spaps_auth_service(auth_settings)
    assert service  # instantiated without hitting network


class DummyAuthService:
    def __init__(self) -> None:
        self.calls: list[str] = []

    async def authenticate(self, token: str) -> dict[str, str]:
        if token == "denied":
            raise AuthenticationError("Authentication failed", status_code=401)
        if token == "service-down":
            raise AuthenticationError("Authentication service unavailable", status_code=503)
        self.calls.append(token)
        return {"user_id": "user"}

    async def aclose(self) -> None:  # pragma: no cover - not invoked in test
        return None


def test_spaps_auth_middleware_enforces_headers() -> None:
    app = FastAPI()
    auth_service = DummyAuthService()

    app.add_middleware(SpapsAuthMiddleware, auth_service=auth_service, exempt_paths={"/open"})

    @app.get("/open")
    async def open_endpoint() -> dict[str, str]:  # pragma: no cover - executed via client
        return {"status": "ok"}

    @app.get("/secure")
    async def secure_endpoint(request: Request) -> dict[str, Any]:  # pragma: no cover - executed via client
        return {"user": getattr(request.state, "authenticated_user", None)}

    client = TestClient(app)

    assert client.get("/open").status_code == 200
    assert client.get("/secure").status_code == 401
    assert client.get("/secure", headers={"Authorization": "Basic foo"}).status_code == 401

    response = client.get("/secure", headers={"Authorization": "Bearer token"})
    assert response.status_code == 200
    assert auth_service.calls == ["token"]

    denied = client.get("/secure", headers={"Authorization": "Bearer denied"})
    assert denied.status_code == 401
    assert denied.json()["detail"] == "Authentication failed"

    service_down = client.get("/secure", headers={"Authorization": "Bearer service-down"})
    assert service_down.status_code == 503
    assert service_down.json()["detail"] == "Authentication service unavailable"


def test_spaps_auth_middleware_supports_glob_patterns() -> None:
    """Test that exempt_paths supports fnmatch-style glob patterns like /v1/chatroom/*/ws."""
    app = FastAPI()
    auth_service = DummyAuthService()

    # Test glob pattern with wildcard in the middle (not just at the end)
    app.add_middleware(
        SpapsAuthMiddleware,
        auth_service=auth_service,
        exempt_paths={"/v1/chatroom/*/ws", "/api/*/public/*"},
    )

    @app.get("/v1/chatroom/{room_id}/ws")
    async def chatroom_ws(room_id: str) -> dict[str, str]:  # pragma: no cover - executed via client
        return {"room": room_id}

    @app.get("/api/{version}/public/{resource}")
    async def public_api(version: str, resource: str) -> dict[str, str]:  # pragma: no cover - executed via client
        return {"version": version, "resource": resource}

    @app.get("/v1/chatroom/{room_id}/messages")
    async def chatroom_messages(room_id: str) -> dict[str, str]:  # pragma: no cover - executed via client
        return {"room": room_id}

    @app.get("/secure")
    async def secure() -> dict[str, str]:  # pragma: no cover - executed via client
        return {"status": "ok"}

    client = TestClient(app)

    # Glob pattern /v1/chatroom/*/ws should match any room_id
    assert client.get("/v1/chatroom/abc-123/ws").status_code == 200
    assert client.get("/v1/chatroom/some-uuid-here/ws").status_code == 200

    # Glob pattern /api/*/public/* should match nested paths
    assert client.get("/api/v1/public/docs").status_code == 200
    assert client.get("/api/v2/public/health").status_code == 200

    # Non-matching paths should require auth
    assert client.get("/v1/chatroom/abc-123/messages").status_code == 401
    assert client.get("/secure").status_code == 401

    # Verify no auth calls were made for exempt paths
    assert auth_service.calls == []


def test_import_spaps_client_falls_back_to_monorepo(monkeypatch) -> None:
    import spaps_server_quickstart.auth as auth

    real_import = importlib.import_module
    state = {"raised": False, "calls": []}

    def fake_import(name: str, package: str | None = None):
        state["calls"].append(name)
        if name == "spaps_client" and not state["raised"]:
            state["raised"] = True
            raise ImportError("missing dependency")
        return real_import(name, package)

    monkeypatch.setattr(auth.importlib, "import_module", fake_import)

    client_cls, error_cls = auth._import_spaps_client()

    assert state["raised"] is True
    assert state["calls"].count("spaps_client") >= 2
    assert client_cls is auth.AsyncSessionsClient
    assert error_cls is auth.SessionError


@pytest.mark.asyncio()
async def test_spaps_auth_service_authenticate_assigns_roles(monkeypatch) -> None:
    import spaps_server_quickstart.auth as auth

    class StubAsyncSessionsClient:
        def __init__(self, *, access_token: str, **_: Any) -> None:
            self._token = access_token
            self._session_id = "session-1"

        async def validate_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            return SimpleNamespace(valid=True, session_id=self._session_id, renewed=False)

        async def get_current_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            token = access_token_override or self._token
            tier = "Practitioner Premium" if token != "no-tier" else None
            return SimpleNamespace(
                user_id="user-1",
                session_id="session-1",
                application_id="app-id",
                tier=tier,
                expires_at=datetime(2025, 1, 1, tzinfo=UTC),
            )

    monkeypatch.setattr(auth, "AsyncSessionsClient", StubAsyncSessionsClient)

    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
        role_hints=("practitioner", "patient"),
    )

    user = await service.authenticate("token")
    assert user.user_id == "user-1"
    assert user.roles == {"practitioner"}
    assert user.subscription_active is True

    user_without_tier = await service.authenticate("no-tier")
    assert user_without_tier.roles == {"patient"}
    assert user_without_tier.subscription_active is False

    await service.aclose()
    assert service._client.is_closed  # type: ignore[attr-defined]


@pytest.mark.asyncio()
async def test_spaps_auth_service_rejects_application_mismatch(monkeypatch) -> None:
    import spaps_server_quickstart.auth as auth

    class MismatchClient:
        def __init__(self, *, access_token: str, **_: Any) -> None:
            self._token = access_token

        async def validate_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            return SimpleNamespace(valid=True, session_id="session-2", renewed=False)

        async def get_current_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            return SimpleNamespace(
                user_id="user-2",
                session_id="session-2",
                application_id="other-app",
                tier=None,
                expires_at=datetime(2025, 1, 1, tzinfo=UTC),
            )

    monkeypatch.setattr(auth, "AsyncSessionsClient", MismatchClient)

    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
    )

    with pytest.raises(AuthenticationError):
        await service.authenticate("token")


@pytest.mark.asyncio()
async def test_spaps_auth_service_wraps_session_error(monkeypatch) -> None:
    import spaps_server_quickstart.auth as auth

    class ErrorClient:
        def __init__(self, **_: Any) -> None:
            pass

        async def validate_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            return SimpleNamespace(valid=True, session_id="session-1", renewed=False)

        async def get_current_session(
            self, *, access_token_override: str | None = None
        ) -> None:
            raise auth.SessionError(
                "remote failure",
                status_code=401,
                error_code="denied",
                request_id="req-123",
            )

    monkeypatch.setattr(auth, "AsyncSessionsClient", ErrorClient)

    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
    )

    with pytest.raises(AuthenticationError) as exc:
        await service.authenticate("token")

    error = exc.value
    assert "remote failure" in str(error)
    assert error.status_code == 401
    assert error.error_code == "denied"


@pytest.mark.asyncio()
async def test_spaps_auth_service_handles_validate_session_errors(monkeypatch) -> None:
    import spaps_server_quickstart.auth as auth

    class ErrorClient:
        def __init__(self, **_: Any) -> None:
            pass

        async def validate_session(
            self, *, access_token_override: str | None = None
        ) -> None:
            raise auth.SessionError(
                "upstream exploded",
                status_code=502,
                error_code="GATEWAY_TIMEOUT",
                request_id="req-502",
            )

    monkeypatch.setattr(auth, "AsyncSessionsClient", ErrorClient)

    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
    )

    with pytest.raises(AuthenticationError) as exc:
        await service.authenticate("token")

    error = exc.value
    assert str(error) == "Authentication service unavailable"
    assert error.status_code == 503
    assert error.error_code == "GATEWAY_TIMEOUT"


@pytest.mark.asyncio()
async def test_spaps_auth_service_rejects_invalid_session(monkeypatch) -> None:
    import spaps_server_quickstart.auth as auth

    class InvalidSessionClient:
        def __init__(self, *, access_token: str, **_: Any) -> None:
            self._token = access_token

        async def validate_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            return SimpleNamespace(valid=False, session_id="sess-invalid", renewed=False)

        async def get_current_session(
            self, *, access_token_override: str | None = None
        ) -> None:  # pragma: no cover - should not be reached
            raise AssertionError("get_current_session should not run when session invalid")

    monkeypatch.setattr(auth, "AsyncSessionsClient", InvalidSessionClient)

    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
    )

    with pytest.raises(AuthenticationError) as exc:
        await service.authenticate("token")

    error = exc.value
    assert str(error) == "Authentication required"
    assert error.status_code == 401
    assert error.error_code == "SESSION_INVALID"


@pytest.mark.asyncio()
async def test_spaps_auth_service_detects_renewed_session(monkeypatch) -> None:
    import spaps_server_quickstart.auth as auth

    class RenewedSessionClient:
        def __init__(self, *, access_token: str, **_: Any) -> None:
            self._token = access_token

        async def validate_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            return SimpleNamespace(valid=False, session_id="sess-renew", renewed=True)

        async def get_current_session(
            self, *, access_token_override: str | None = None
        ) -> None:  # pragma: no cover - should not be reached
            raise AssertionError("get_current_session should not run when session renewed")

    monkeypatch.setattr(auth, "AsyncSessionsClient", RenewedSessionClient)

    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
    )

    with pytest.raises(AuthenticationError) as exc:
        await service.authenticate("token")

    error = exc.value
    assert str(error) == "Authentication required"
    assert error.status_code == 401
    assert error.error_code == "SESSION_INVALID"


@pytest.mark.asyncio()
async def test_spaps_auth_service_reuses_sessions_client_on_invalid_cache_miss(monkeypatch) -> None:
    import spaps_server_quickstart.auth as auth

    init_tokens: list[str] = []
    validate_overrides: list[str | None] = []
    get_current_calls = 0

    class InvalidSessionClient:
        def __init__(self, *, access_token: str, **_: Any) -> None:
            init_tokens.append(access_token)

        async def validate_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            validate_overrides.append(access_token_override)
            return SimpleNamespace(valid=False, session_id="sess-invalid", renewed=False)

        async def get_current_session(self, *, access_token_override: str | None = None) -> None:
            nonlocal get_current_calls
            get_current_calls += 1
            raise AssertionError("get_current_session should not run when session invalid")

    monkeypatch.setattr(auth, "AsyncSessionsClient", InvalidSessionClient)
    auth._SESSION_CACHE.clear()

    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
    )

    with pytest.raises(AuthenticationError):
        await service.authenticate("token-one")
    with pytest.raises(AuthenticationError):
        await service.authenticate("token-two")

    assert init_tokens == [""]
    assert validate_overrides == ["token-one", "token-two"]
    assert get_current_calls == 0


@pytest.mark.asyncio()
async def test_spaps_auth_service_maps_session_fetch_503(monkeypatch) -> None:
    import spaps_server_quickstart.auth as auth

    class FetchErrorClient:
        def __init__(self, *, access_token: str, **_: Any) -> None:
            self._token = access_token

        async def validate_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            return SimpleNamespace(valid=True, session_id="sess-123", renewed=False)

        async def get_current_session(
            self, *, access_token_override: str | None = None
        ) -> None:
            raise auth.SessionError(
                "backend down",
                status_code=500,
                error_code="SERVER_ERROR",
                request_id="req-500",
            )

    monkeypatch.setattr(auth, "AsyncSessionsClient", FetchErrorClient)

    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
    )

    with pytest.raises(AuthenticationError) as exc:
        await service.authenticate("token")

    error = exc.value
    assert str(error) == "Authentication service unavailable"
    assert error.status_code == 503
    assert error.error_code == "SERVER_ERROR"


@pytest.mark.asyncio()
async def test_spaps_auth_service_uses_cache(monkeypatch) -> None:
    """Test session caching to improve performance."""
    import spaps_server_quickstart.auth as auth
    from datetime import timedelta

    call_log = {"count": 0}

    class CountingClient:
        def __init__(self, *, access_token: str, **_: Any) -> None:
            self._token = access_token

        async def validate_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            call_log["count"] += 1
            return SimpleNamespace(valid=True, session_id="session-1", renewed=False)

        async def get_current_session(
            self, *, access_token_override: str | None = None
        ) -> SimpleNamespace:
            # Use future date so cache entry stays valid
            future_expires = datetime.now(tz=UTC) + timedelta(hours=24)
            return SimpleNamespace(
                user_id="user-1",
                session_id="session-1",
                application_id="app-id",
                tier="basic",
                expires_at=future_expires,
            )

    monkeypatch.setattr(auth, "AsyncSessionsClient", CountingClient)
    # Clear cache
    auth._SESSION_CACHE.clear()

    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
    )

    # First call should hit the API
    user1 = await service.authenticate("cached-token")
    assert user1.user_id == "user-1"
    assert call_log["count"] == 1

    # Second call with same token should use cache
    user2 = await service.authenticate("cached-token")
    assert user2.user_id == "user-1"
    assert call_log["count"] == 1  # No additional call

    # Clear cache and verify it hits API again
    auth._SESSION_CACHE.clear()
    user3 = await service.authenticate("cached-token")
    assert user3.user_id == "user-1"
    assert call_log["count"] == 2


def test_spaps_auth_middleware_skips_pre_authenticated(monkeypatch) -> None:
    """Test middleware skips auth when request is already authenticated by another middleware."""
    app = FastAPI()
    auth_service = DummyAuthService()

    app.add_middleware(SpapsAuthMiddleware, auth_service=auth_service, exempt_paths=set())

    @app.get("/secure")
    async def secure_endpoint(request: Request) -> dict[str, Any]:  # pragma: no cover - executed via client
        user = getattr(request.state, "authenticated_user", None)
        return {"user_id": user.user_id if user else None}

    client = TestClient(app)

    # Manually set authenticated_user before middleware runs
    # This simulates another middleware (like TrustedServiceMiddleware) already authenticating
    from spaps_server_quickstart.auth import AuthenticatedUser

    def add_auth_middleware(app):
        original_middleware = app.middleware_stack

        async def pre_auth_middleware(scope, receive, send):
            if scope["type"] == "http":
                # Create a minimal state object
                scope.setdefault("state", {})
                scope["state"]["authenticated_user"] = AuthenticatedUser(
                    user_id="pre-auth-user",
                    session_id="pre-auth-session",
                    application_id="app-id",
                )
            await original_middleware(scope, receive, send)

        app.middleware_stack = pre_auth_middleware

    # Note: TestClient rebuilds the app, so we need to test via direct middleware
    # For this test, we'll verify the middleware code path via unit test style
    from starlette.responses import Response

    async def mock_call_next(request: Request) -> Response:
        return Response("OK")

    middleware_instance = SpapsAuthMiddleware(
        app=app,
        auth_service=auth_service,
        exempt_paths=set(),
    )

    # Create request with pre-existing authenticated_user
    request = Request({"type": "http", "method": "GET", "path": "/secure", "headers": []})
    request.state.authenticated_user = AuthenticatedUser(
        user_id="pre-auth-user",
        session_id="pre-auth-session",
        application_id="app-id",
    )

    import asyncio
    response = asyncio.run(middleware_instance.dispatch(request, mock_call_next))
    assert response.body == b"OK"
    # Verify auth service was never called
    assert auth_service.calls == []


def test_spaps_auth_middleware_normalizes_paths() -> None:
    """Test path normalization for exempt paths."""
    from spaps_server_quickstart.auth import SpapsAuthMiddleware

    # Test various path formats
    assert SpapsAuthMiddleware._normalize_path("/api/v1") == "/api/v1"
    assert SpapsAuthMiddleware._normalize_path("/api/v1/") == "/api/v1"
    assert SpapsAuthMiddleware._normalize_path("api/v1") == "/api/v1"
    assert SpapsAuthMiddleware._normalize_path("/") == "/"
    assert SpapsAuthMiddleware._normalize_path("") == "/"
    # Multiple slashes get stripped to empty, which normalizes to "/"
    result = SpapsAuthMiddleware._normalize_path("///")
    assert result in ("", "/")  # Implementation may vary


def test_spaps_auth_middleware_wildcard_stripping() -> None:
    """Test wildcard suffix removal."""
    from spaps_server_quickstart.auth import SpapsAuthMiddleware

    assert SpapsAuthMiddleware._strip_wildcard("/api/*") == "/api"
    assert SpapsAuthMiddleware._strip_wildcard("/v1/auth/*") == "/v1/auth"
    assert SpapsAuthMiddleware._strip_wildcard("/*") == "/"


def test_spaps_auth_middleware_prefix_matching() -> None:
    """Test prefix matching logic."""
    from spaps_server_quickstart.auth import SpapsAuthMiddleware

    # Root prefix matches everything
    assert SpapsAuthMiddleware._matches_prefix("/anything", "/")
    assert SpapsAuthMiddleware._matches_prefix("/api/v1", "/")

    # Exact match
    assert SpapsAuthMiddleware._matches_prefix("/api", "/api")

    # Prefix match
    assert SpapsAuthMiddleware._matches_prefix("/api/v1", "/api")
    assert SpapsAuthMiddleware._matches_prefix("/api/v1/users", "/api")

    # Non-match
    assert not SpapsAuthMiddleware._matches_prefix("/other", "/api")


def test_hash_token() -> None:
    """Test token hashing for cache keys."""
    from spaps_server_quickstart.auth import _hash_token

    hash1 = _hash_token("token123")
    hash2 = _hash_token("token123")
    hash3 = _hash_token("different")

    assert hash1 == hash2
    assert hash1 != hash3
    assert len(hash1) == 32  # First 32 chars of SHA256 hex


def test_cleanup_expired_session_cache() -> None:
    """Test expired cache entry cleanup."""
    from datetime import timedelta
    from spaps_server_quickstart.auth import (
        _SESSION_CACHE,
        _cache_session,
        _cleanup_expired_session_cache,
        AuthenticatedUser,
        _hash_token,
    )

    _SESSION_CACHE.clear()

    now = datetime.now(tz=UTC)

    # Add expired entry - manually add to cache with past expiry
    expired_user = AuthenticatedUser(
        user_id="user-expired",
        session_id="session-expired",
        application_id="app-id",
        session_expires_at=now + timedelta(seconds=5),
    )

    # Manually add to cache to bypass _cache_session's expiry check
    _SESSION_CACHE[_hash_token("expired-token")] = (
        expired_user,
        now - timedelta(seconds=10),  # Already expired cache entry
    )

    # Add valid entry
    valid_user = AuthenticatedUser(
        user_id="user-valid",
        session_id="session-valid",
        application_id="app-id",
        session_expires_at=now + timedelta(hours=1),
    )
    _cache_session("valid-token", valid_user)

    initial_size = len(_SESSION_CACHE)
    assert initial_size == 2

    _cleanup_expired_session_cache()

    # Expired entry should be removed
    assert len(_SESSION_CACHE) < initial_size
    _SESSION_CACHE.clear()


def test_get_cached_session_returns_none_for_missing() -> None:
    """Test cache miss returns None."""
    from spaps_server_quickstart.auth import _SESSION_CACHE, _get_cached_session

    _SESSION_CACHE.clear()
    result = _get_cached_session("nonexistent-token")
    assert result is None


def test_cache_session_respects_max_size() -> None:
    """Test cache size limits and cleanup."""
    from spaps_server_quickstart.auth import (
        _SESSION_CACHE,
        _SESSION_CACHE_MAX_SIZE,
        _cache_session,
        AuthenticatedUser,
    )
    from datetime import timedelta

    _SESSION_CACHE.clear()

    # Fill cache beyond max size
    for i in range(_SESSION_CACHE_MAX_SIZE + 100):
        user = AuthenticatedUser(
            user_id=f"user-{i}",
            session_id=f"session-{i}",
            application_id="app-id",
            session_expires_at=datetime.now(tz=UTC) + timedelta(hours=1),
        )
        _cache_session(f"token-{i}", user)

    # Should trigger cleanup and maintain max size
    assert len(_SESSION_CACHE) <= _SESSION_CACHE_MAX_SIZE
    _SESSION_CACHE.clear()


@pytest.mark.asyncio()
async def test_spaps_auth_service_rejects_empty_token() -> None:
    """Test that empty access token is rejected."""
    service = SpapsAuthService(
        base_url="https://api",
        api_key="key",
        application_id="app-id",
    )

    with pytest.raises(AuthenticationError) as exc:
        await service.authenticate("")

    assert exc.value.status_code == 401
    assert "Access token missing" in str(exc.value)
