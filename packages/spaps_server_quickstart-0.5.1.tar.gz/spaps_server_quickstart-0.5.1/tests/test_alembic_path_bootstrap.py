from __future__ import annotations

import importlib.util
from pathlib import Path


def _load_bootstrap_module():
    repo_root = Path(__file__).resolve().parents[3]
    module_path = repo_root / "alembic" / "path_bootstrap.py"
    spec = importlib.util.spec_from_file_location("alembic_path_bootstrap", module_path)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


path_bootstrap = _load_bootstrap_module()


def test_resolve_quickstart_src_path_prefers_existing_sys_path_mount(tmp_path: Path) -> None:
    app_src = tmp_path / "app" / "src"
    (app_src / "spaps_server_quickstart").mkdir(parents=True)

    packaged_src = tmp_path / "app" / "packages" / "python-server-quickstart" / "src"
    (packaged_src / "spaps_server_quickstart").mkdir(parents=True)

    alembic_env_path = tmp_path / "app" / "alembic" / "env.py"
    alembic_env_path.parent.mkdir(parents=True)
    alembic_env_path.touch()

    resolved = path_bootstrap.resolve_quickstart_src_path(
        alembic_env_path,
        [str(app_src), str(packaged_src)],
    )

    assert resolved == str(app_src.resolve())


def test_resolve_quickstart_src_path_falls_back_to_repo_package_src(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    packaged_src = repo_root / "packages" / "python-server-quickstart" / "src"
    (packaged_src / "spaps_server_quickstart").mkdir(parents=True)

    alembic_env_path = repo_root / "alembic" / "env.py"
    alembic_env_path.parent.mkdir(parents=True)
    alembic_env_path.touch()

    resolved = path_bootstrap.resolve_quickstart_src_path(alembic_env_path, [])

    assert resolved == str(packaged_src.resolve())


def test_ensure_quickstart_src_path_moves_resolved_entry_to_front(tmp_path: Path) -> None:
    app_src = tmp_path / "app" / "src"
    (app_src / "spaps_server_quickstart").mkdir(parents=True)

    sys_path = ["/usr/local/lib/python3.12/site-packages", str(app_src)]

    resolved = path_bootstrap.ensure_quickstart_src_path(
        tmp_path / "app" / "alembic" / "env.py",
        sys_path,
    )

    assert resolved == str(app_src.resolve())
    assert sys_path[0] == str(app_src.resolve())
