"""Contract tests for the golden app pack blueprint."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.applications.blueprints import (
    compile_application_blueprint,
)
from spaps_server_quickstart.domains.applications.service import DEFAULT_APP_SETTINGS
from spaps_server_quickstart.domains.policies.evaluator import UserContext, evaluate_condition


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[4]


def _compile_golden_pack():
    return compile_application_blueprint(
        default_settings=DEFAULT_APP_SETTINGS,
        blueprint_key="golden_path",
    )


class TestGoldenAppPackContract:
    def test_compiles_machine_readable_reference_contract(self):
        compiled = _compile_golden_pack()

        assert compiled.key == "golden_path"
        assert compiled.publishable_scopes == [
            "auth",
            "sessions",
            "stripe_consumer",
            "entitlements_read",
            "docs",
        ]
        assert compiled.docs == [
            "docs/guides/application-blueprints.md",
            "docs/guides/self-service-api.md",
            "docs/downstream_apps/golden-path-reference/README.md",
        ]
        assert compiled.settings["application_blueprint"]["journeys"] == [
            {
                "key": "browser_auth_session",
                "name": "Browser auth and session bootstrap",
                "description": "Sign in from a browser with a publishable key and establish a reusable session.",
                "publishable_scopes": ["auth", "sessions"],
            },
            {
                "key": "checkout_projects_paid_access",
                "name": "Checkout projects paid access",
                "description": "A Stripe checkout or subscription event projects the paid_access entitlement for the application user.",
                "publishable_scopes": ["stripe_consumer", "entitlements_read"],
                "entitlement_key": "paid_access",
                "policy_name": "access-paid-features",
            },
            {
                "key": "developer_handoff",
                "name": "Developer docs and operator handoff",
                "description": "Operators can trace the contract from the blueprint metadata to the runbook and docs bundle.",
                "publishable_scopes": ["docs"],
            },
        ]

        [paid_policy] = compiled.default_policies
        assert paid_policy.name == "access-paid-features"
        assert paid_policy.effect == "allow"
        assert paid_policy.conditions == {
            "any": [
                {"has_role": {"role": "admin"}},
                {"has_entitlement": {"key": "paid_access"}},
            ]
        }
        assert paid_policy.metadata == {
            "source": "application-blueprint",
            "blueprint_key": "golden_path",
            "journey": "checkout_projects_paid_access",
        }

    def test_docs_bundle_files_exist(self):
        compiled = _compile_golden_pack()
        repo_root = _repo_root()

        for rel_path in compiled.docs:
            assert (repo_root / rel_path).exists(), f"Missing docs bundle file: {rel_path}"

    @pytest.mark.asyncio
    async def test_paid_access_policy_matches_policy_engine(self):
        compiled = _compile_golden_pack()
        [paid_policy] = compiled.default_policies
        ctx = UserContext(
            AsyncMock(),
            user_id=uuid4(),
            application_id=uuid4(),
        )
        ctx._roles = ["user"]
        ctx._entitlements = {
            "entitlements": [{"entitlement_key": "paid_access", "revoked_at": None}],
            "count": 1,
        }

        result = await evaluate_condition(ctx, paid_policy.conditions)

        assert result.matched is True
        assert "has entitlement 'paid_access'" in result.reasons

    @pytest.mark.asyncio
    async def test_paid_access_policy_denies_unpaid_non_admin_users(self):
        compiled = _compile_golden_pack()
        [paid_policy] = compiled.default_policies
        ctx = UserContext(
            AsyncMock(),
            user_id=uuid4(),
            application_id=uuid4(),
        )
        ctx._roles = ["user"]
        ctx._entitlements = {"entitlements": [], "count": 0}

        result = await evaluate_condition(ctx, paid_policy.conditions)

        assert result.matched is False
        assert "missing entitlement 'paid_access'" in result.reasons
