from __future__ import annotations

from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from spaps_server_quickstart.spaps_app import (
    _validate_tm014_email_override_startup_invariant,
)


class _SessionContext:
    def __init__(self, session: Any) -> None:
        self._session = session

    async def __aenter__(self) -> Any:
        return self._session

    async def __aexit__(self, *_: Any) -> None:
        return None


def _make_db_resources(session: Any) -> Any:
    return SimpleNamespace(
        get_session_factory=lambda: (lambda: _SessionContext(session))
    )


def _make_result(rows: list[dict[str, str]]) -> MagicMock:
    result = MagicMock()
    result.mappings.return_value.all.return_value = rows
    return result


@pytest.mark.asyncio
async def test_email_override_invariant_skips_non_production() -> None:
    session = AsyncMock()

    await _validate_tm014_email_override_startup_invariant(
        SimpleNamespace(env="dev"),
        _make_db_resources(session),
    )

    session.execute.assert_not_awaited()


@pytest.mark.asyncio
async def test_email_override_invariant_passes_without_overrides() -> None:
    session = AsyncMock()
    session.execute.return_value = _make_result([])

    await _validate_tm014_email_override_startup_invariant(
        SimpleNamespace(env="production"),
        _make_db_resources(session),
    )

    session.execute.assert_awaited_once()


@pytest.mark.asyncio
async def test_email_override_invariant_rejects_production_overrides() -> None:
    session = AsyncMock()
    session.execute.return_value = _make_result(
        [
            {"slug": "cfo", "override_key": "override_to"},
            {"slug": "sandbox-app", "override_key": "dev_override_to"},
        ]
    )

    with pytest.raises(
        RuntimeError,
        match=r"cfo\.override_to, sandbox-app\.dev_override_to",
    ):
        await _validate_tm014_email_override_startup_invariant(
            SimpleNamespace(env="prod"),
            _make_db_resources(session),
        )
