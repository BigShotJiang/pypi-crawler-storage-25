"""Tests for domains/sessions/blacklist_service.py"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import pytest
import spaps_server_quickstart.domains.sessions.blacklist_service as blacklist_service_module

from spaps_server_quickstart.domains.sessions.blacklist_service import (
    blacklist_all_user_tokens,
    _clear_cache,
    _cache,
    blacklist_token,
    cleanup_expired,
    is_blacklisted,
)


@pytest.mark.asyncio()
async def test_blacklist_token_adds_to_cache_and_db():
    """Test token blacklist writes to both memory and database."""
    session = AsyncMock()
    session.add = MagicMock()
    session.flush = AsyncMock()

    _clear_cache()

    jti = "test-jti-123"
    user_id = "user-1"
    expires_at = datetime.now(tz=UTC) + timedelta(hours=1)

    await blacklist_token(
        session=session,
        jti=jti,
        user_id=user_id,
        reason="logout",
        expires_at=expires_at,
        ip_address="127.0.0.1",
        user_agent="TestAgent/1.0",
    )

    # Verify in-memory cache
    assert jti in _cache
    assert _cache[jti].user_id == user_id
    assert _cache[jti].reason == "logout"

    # Verify database write
    session.add.assert_called_once()
    session.flush.assert_awaited_once()

    _clear_cache()


@pytest.mark.asyncio()
async def test_is_blacklisted_checks_memory_first():
    """Test that is_blacklisted checks memory cache before database."""
    session = AsyncMock()
    session.add = MagicMock()  # session.add() is synchronous in SQLAlchemy
    _clear_cache()

    jti = "cached-jti"
    user_id = "user-1"
    expires_at = datetime.now(tz=UTC) + timedelta(hours=1)

    # Add to memory cache
    await blacklist_token(
        session=session,
        jti=jti,
        user_id=user_id,
        reason="logout",
        expires_at=expires_at,
    )

    # Check blacklist - should hit memory cache, not database
    session.execute = AsyncMock()  # Reset
    result = await is_blacklisted(session, jti)

    assert result is True
    session.execute.assert_not_awaited()  # DB should not be queried

    _clear_cache()


@pytest.mark.asyncio()
async def test_is_blacklisted_falls_back_to_db():
    """Test that a DB hit is cached for subsequent checks."""
    session = AsyncMock()
    session.add = MagicMock()  # session.add() is synchronous in SQLAlchemy
    _clear_cache()

    jti = "db-only-jti"

    # Mock database response (found)
    mock_row = MagicMock()
    mock_row.expires_at = datetime.now(tz=UTC) + timedelta(hours=1)
    mock_result = MagicMock()
    mock_result.one_or_none.return_value = mock_row
    session.execute.return_value = mock_result

    first_result = await is_blacklisted(session, jti)
    second_result = await is_blacklisted(session, jti)

    assert first_result is True
    assert second_result is True
    session.execute.assert_awaited_once()

    # Verify it was cached for next lookup
    assert jti in _cache

    _clear_cache()


@pytest.mark.asyncio()
async def test_is_blacklisted_returns_false_when_not_found():
    """Test that is_blacklisted returns False when token not blacklisted."""
    session = AsyncMock()
    _clear_cache()

    jti = "clean-jti"

    # Mock database response (not found)
    mock_result = MagicMock()
    mock_result.one_or_none.return_value = None
    session.execute.return_value = mock_result

    result = await is_blacklisted(session, jti)

    assert result is False

    _clear_cache()


@pytest.mark.asyncio()
async def test_is_blacklisted_fails_secure_on_db_error():
    """Test that is_blacklisted returns True (fail secure) on database errors."""
    session = AsyncMock()
    _clear_cache()

    jti = "error-jti"

    # Mock database exception
    session.execute.side_effect = Exception("Database connection failed")

    result = await is_blacklisted(session, jti)

    # Should fail secure (treat as blacklisted)
    assert result is True

    _clear_cache()


@pytest.mark.asyncio()
async def test_blacklist_all_user_tokens():
    """Test mass revocation of user tokens."""
    session = AsyncMock()
    session.add = MagicMock()  # session.add() is synchronous in SQLAlchemy
    _clear_cache()

    user_id = "user-1"
    expires_at = datetime.now(tz=UTC) + timedelta(hours=1)

    # Add some tokens for this user to cache
    await blacklist_token(session, "jti-1", user_id, "logout", expires_at)
    await blacklist_token(session, "jti-2", user_id, "logout", expires_at)
    await blacklist_token(session, "jti-3", "other-user", "logout", expires_at)

    session.add = MagicMock()
    session.flush = AsyncMock()

    await blacklist_all_user_tokens(session, user_id, "security")

    # All user tokens should remain in cache (they're already blacklisted)
    assert "jti-1" in _cache
    assert "jti-2" in _cache

    _clear_cache()


@pytest.mark.asyncio()
async def test_cleanup_expired_removes_from_memory_and_db():
    """Test cleanup removes expired entries from both layers."""
    session = AsyncMock()
    session.add = MagicMock()  # session.add() is synchronous in SQLAlchemy
    _clear_cache()

    now = datetime.now(tz=UTC)
    past = now - timedelta(hours=1)
    future = now + timedelta(hours=1)

    # Add expired entry
    await blacklist_token(session, "expired-jti", "user-1", "logout", past)

    # Add valid entry
    await blacklist_token(session, "valid-jti", "user-2", "logout", future)

    # Mock database delete
    mock_result = MagicMock()
    mock_result.rowcount = 5  # Simulates 5 rows deleted from DB
    session.execute.return_value = mock_result

    cleaned = await cleanup_expired(session)

    # Should report memory + DB deletions
    assert cleaned > 0

    # Expired should be gone from memory
    assert "expired-jti" not in _cache
    # Valid should remain
    assert "valid-jti" in _cache

    session.execute.assert_awaited_once()

    _clear_cache()


@pytest.mark.asyncio()
async def test_lazy_cleanup_triggers_on_interval():
    """Test that lazy cleanup triggers after threshold checks."""
    from spaps_server_quickstart.domains.sessions.blacklist_service import (
        _CLEANUP_CHECK_INTERVAL,
    )

    session = AsyncMock()
    session.add = MagicMock()  # session.add() is synchronous in SQLAlchemy
    _clear_cache()

    # Add expired entries
    now = datetime.now(tz=UTC)
    past = now - timedelta(hours=1)

    for i in range(10):
        await blacklist_token(session, f"expired-{i}", "user-1", "logout", past)

    initial_count = len(_cache)

    # Trigger cleanup by calling is_blacklisted repeatedly
    mock_result = MagicMock()
    mock_result.one_or_none.return_value = None
    session.execute.return_value = mock_result

    # Call enough times to trigger cleanup
    for i in range(_CLEANUP_CHECK_INTERVAL + 1):
        await is_blacklisted(session, f"check-{i}")

    # Expired entries should be cleaned up
    assert len(_cache) < initial_count

    _clear_cache()


@pytest.mark.asyncio()
async def test_size_threshold_cleanup_does_not_rescan_on_every_lookup(monkeypatch):
    """Oversize cleanup should run once per write burst, not every check."""
    session = AsyncMock()
    session.add = MagicMock()  # session.add() is synchronous in SQLAlchemy
    session.flush = AsyncMock()
    _clear_cache()

    monkeypatch.setattr(blacklist_service_module, "_CLEANUP_SIZE_THRESHOLD", 2)
    monkeypatch.setattr(blacklist_service_module, "_CLEANUP_CHECK_INTERVAL", 1000)

    cleanup_calls = 0
    original_cleanup = blacklist_service_module._cleanup_expired_cache_entries

    def counting_cleanup(*, now=None):
        nonlocal cleanup_calls
        cleanup_calls += 1
        return original_cleanup(now=now)

    monkeypatch.setattr(
        blacklist_service_module,
        "_cleanup_expired_cache_entries",
        counting_cleanup,
    )

    future = datetime.now(tz=UTC) + timedelta(hours=1)
    for i in range(3):
        await blacklist_token(session, f"oversized-{i}", "user-1", "logout", future)

    mock_result = MagicMock()
    mock_result.one_or_none.return_value = None
    session.execute.return_value = mock_result

    for i in range(3):
        assert await is_blacklisted(session, f"clean-{i}") is False

    assert cleanup_calls == 1

    _clear_cache()


@pytest.mark.asyncio()
async def test_cleanup_expired_clears_pending_size_cleanup_flag(monkeypatch):
    """Explicit cleanup should stop the next lookup from rescanning the cache."""
    session = AsyncMock()
    session.add = MagicMock()  # session.add() is synchronous in SQLAlchemy
    session.flush = AsyncMock()
    _clear_cache()

    monkeypatch.setattr(blacklist_service_module, "_CLEANUP_SIZE_THRESHOLD", 2)
    monkeypatch.setattr(blacklist_service_module, "_CLEANUP_CHECK_INTERVAL", 1000)

    expired_at = datetime.now(tz=UTC) - timedelta(hours=1)
    for i in range(3):
        await blacklist_token(session, f"expired-{i}", "user-1", "logout", expired_at)

    delete_result = MagicMock()
    delete_result.rowcount = 3
    session.execute.return_value = delete_result

    await cleanup_expired(session)

    cleanup_calls = 0
    original_cleanup = blacklist_service_module._cleanup_expired_cache_entries

    def counting_cleanup(*, now=None):
        nonlocal cleanup_calls
        cleanup_calls += 1
        return original_cleanup(now=now)

    monkeypatch.setattr(
        blacklist_service_module,
        "_cleanup_expired_cache_entries",
        counting_cleanup,
    )

    lookup_result = MagicMock()
    lookup_result.one_or_none.return_value = None
    session.execute.return_value = lookup_result

    assert await is_blacklisted(session, "clean-check") is False
    assert cleanup_calls == 0

    _clear_cache()


def test_clear_cache_helper():
    """Test the testing helper _clear_cache."""
    _cache["test"] = MagicMock()
    _clear_cache()

    assert len(_cache) == 0
