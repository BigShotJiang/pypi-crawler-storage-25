"""
SPAPS health endpoints.

Provides three health check endpoints matching the Node.js SPAPS contract:
- GET /health — basic status
- GET /health/ready — deep check with DB + Redis
- GET /health/local-mode — local development mode status
"""

from __future__ import annotations

import os
from datetime import UTC, datetime
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Request
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

router = APIRouter(tags=["health"])

_STARTED_AT = datetime.now(tz=UTC)
_STARTED_AT_EST = _STARTED_AT.astimezone(ZoneInfo("America/New_York"))


async def _has_pii_enabled_app(request: Request) -> bool:
    """Return True when at least one application has ``settings.pii_enabled=true``."""
    db_resources = getattr(request.app.state, "db_resources", None)
    if db_resources is None:
        return False

    session_factory = db_resources.get_session_factory()
    async with session_factory() as session:
        result = await session.execute(
            text(
                """
                SELECT EXISTS (
                  SELECT 1
                  FROM applications
                  WHERE COALESCE((settings->>'pii_enabled')::boolean, false) = true
                )
                """
            )
        )
        return bool(result.scalar())


@router.get("/health")
async def health() -> dict:
    """Basic health check — always returns ok if the process is running."""
    return {
        "status": "ok",
        "version": os.environ.get("GIT_COMMIT_SHA", "1.0.0"),
        "started_at": _STARTED_AT.isoformat(),
        "started_at_est": _STARTED_AT_EST.strftime("%Y-%m-%d %I:%M:%S %p %Z"),
    }


@router.get("/health/ready")
async def health_ready(request: Request) -> dict:
    """
    Deep readiness check. Verifies database and Redis connectivity.

    Returns envelope-wrapped response with check details.
    """
    checks: dict[str, dict] = {}

    # Database check — get session from app state
    db_resources = getattr(request.app.state, "db_resources", None)
    if db_resources is not None:
        try:
            session_factory = db_resources.get_session_factory()
            async with session_factory() as session:
                await session.execute(text("SELECT 1"))
            checks["database"] = {"status": "connected"}
        except SQLAlchemyError as e:
            checks["database"] = {"status": "disconnected", "error": str(e)}
    else:
        checks["database"] = {"status": "not_configured"}

    # Redis check
    try:
        import redis as redis_lib

        settings = getattr(request.app.state, "settings", None)
        redis_url = getattr(settings, "redis_url", None) or os.environ.get(
            "REDIS_URL", "redis://localhost:6379/0"
        )
        r = redis_lib.from_url(redis_url, socket_connect_timeout=2, socket_timeout=2)
        r.ping()
        checks["redis"] = {"status": "connected"}
        r.close()
    except Exception as e:
        checks["redis"] = {"status": "disconnected", "error": type(e).__name__}

    # TM-013: Fail readiness when PII-enabled apps exist but master key is missing.
    # This keeps traffic out of a fail-open PHI/PII posture.
    settings = getattr(request.app.state, "settings", None)
    master_key = getattr(settings, "spaps_pii_master_key", "")
    if checks.get("database", {}).get("status") == "connected":
        try:
            has_pii_apps = await _has_pii_enabled_app(request)
            if has_pii_apps and not master_key:
                checks["pii_encryption"] = {
                    "status": "disconnected",
                    "error": "SPAPS_PII_MASTER_KEY missing while pii_enabled applications exist",
                }
            else:
                checks["pii_encryption"] = {"status": "connected"}
        except SQLAlchemyError as e:
            checks["pii_encryption"] = {"status": "disconnected", "error": str(e)}

    all_healthy = all(c.get("status") == "connected" for c in checks.values())

    return {
        "success": True,
        "data": {
            "status": "ready" if all_healthy else "not_ready",
            "checks": checks,
        },
        "metadata": {
            "timestamp": datetime.now(UTC).isoformat(),
        },
    }


@router.get("/health/local-mode")
async def health_local_mode(request: Request) -> dict:
    """Show whether local development mode is active and its configuration."""
    settings = request.app.state.settings
    is_local = settings.is_spaps_local_mode

    data: dict = {
        "local_mode_active": is_local,
        "environment": settings.env,
        "spaps_local_mode_env": settings.spaps_local_mode,
    }

    if is_local:
        data["test_users"] = ["user", "admin", "premium"]
        data["test_application"] = {
            "id": "00000000-0000-0000-0000-000000000100",
            "slug": "local-dev",
            "api_key": "spaps_local_development_key",
        }
        data["hints"] = {
            "select_user": "Use ?_user=admin or X-Test-User: admin header",
            "bypass_api_key": "Missing API keys fall back to local-dev; explicit real API keys still resolve their application",
            "rate_limiting": "Disabled in local mode",
        }

    return {
        "success": True,
        "data": data,
        "metadata": {
            "timestamp": datetime.now(UTC).isoformat(),
        },
    }
