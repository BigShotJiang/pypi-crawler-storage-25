"""Business logic for the affiliate_referrals domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from . import repository as repo
from ..webhooks import service as webhook_service
from ..errors import ForbiddenError
from .errors import (
    AffiliateAlreadyExistsError,
    AffiliateNotFoundError,
    AlreadyAttributedError,
    ClickExpiredError,
    ClickNotFoundError,
    ClickRateLimitedError,
    InsufficientBalanceError,
    NotApplicationOwnerError,
    PayoutNotApprovedError,
    PayoutNotFoundError,
    PayoutNotPendingError,
    PayoutWalletNotSetError,
    SelfReferralError,
    SlugAlreadyExistsError,
)

logger = logging.getLogger(__name__)

# SPAPS defaults (used when no app config exists)
DEFAULT_L1_RATE_BPS = 1000
DEFAULT_L2_RATE_BPS = 500
DEFAULT_L3_RATE_BPS = 200
DEFAULT_ATTRIBUTION_WINDOW_DAYS = 30
DEFAULT_MIN_PAYOUT_CENTS = 2500


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _hash_ip(ip_address: str) -> str:
    """SHA-256 hash for privacy-safe click deduplication."""
    return hashlib.sha256(ip_address.encode()).hexdigest()


def _affiliate_to_dict(affiliate: Any) -> dict[str, Any]:
    """Convert an Affiliate model instance to a serialisable dict."""
    return {
        "id": str(affiliate.id),
        "affiliate_type": affiliate.affiliate_type,
        "user_id": str(affiliate.user_id) if affiliate.user_id else None,
        "agent_id": str(affiliate.agent_id) if affiliate.agent_id else None,
        "slug": affiliate.slug,
        "referral_url_pattern": f"?ref={affiliate.slug}",
        "referred_by": None,
        "referral_depth": affiliate.referral_depth,
        "is_active": affiliate.is_active,
        "credit_balance_cents": affiliate.credit_balance_cents,
        "lifetime_earned_cents": affiliate.lifetime_earned_cents,
        "lifetime_paid_out_cents": affiliate.lifetime_paid_out_cents,
        "payout_wallet_address": affiliate.payout_wallet_address,
        "payout_chain": affiliate.payout_chain,
        "created_at": affiliate.created_at.isoformat() if hasattr(affiliate.created_at, "isoformat") else str(affiliate.created_at),
        "updated_at": affiliate.updated_at.isoformat() if hasattr(affiliate.updated_at, "isoformat") else str(affiliate.updated_at),
    }


async def _enrich_referred_by(
    db: AsyncSession,
    affiliate: Any,
    result: dict[str, Any],
) -> None:
    """Add referred_by info if affiliate has a referrer."""
    if affiliate.referred_by_affiliate_id:
        referrer = await repo.get_affiliate_by_id(db, affiliate.referred_by_affiliate_id)
        if referrer:
            result["referred_by"] = {
                "affiliate_id": str(referrer.id),
                "slug": referrer.slug,
            }


def _payout_to_dict(payout: Any) -> dict[str, Any]:
    return {
        "id": str(payout.id),
        "amount_cents": payout.amount_cents,
        "payout_method": payout.payout_method,
        "wallet_address": payout.wallet_address,
        "chain": payout.chain,
        "tx_hash": payout.tx_hash,
        "status": payout.status,
        "requested_at": payout.requested_at.isoformat() if hasattr(payout.requested_at, "isoformat") else str(payout.requested_at),
        "approved_at": payout.approved_at.isoformat() if payout.approved_at and hasattr(payout.approved_at, "isoformat") else None,
        "completed_at": payout.completed_at.isoformat() if payout.completed_at and hasattr(payout.completed_at, "isoformat") else None,
    }


async def _get_app_rates(
    db: AsyncSession,
    application_id: UUID,
) -> dict[str, Any]:
    """Get commission rates for an application, falling back to SPAPS defaults."""
    config = await repo.get_app_config(db, application_id)
    if config:
        return {
            "enabled": config.enabled,
            "l1_rate_bps": config.l1_rate_bps,
            "l2_rate_bps": config.l2_rate_bps,
            "l3_rate_bps": config.l3_rate_bps,
            "attribution_window_days": config.attribution_window_days,
            "min_payout_cents": config.min_payout_cents,
        }
    return {
        "enabled": True,
        "l1_rate_bps": DEFAULT_L1_RATE_BPS,
        "l2_rate_bps": DEFAULT_L2_RATE_BPS,
        "l3_rate_bps": DEFAULT_L3_RATE_BPS,
        "attribution_window_days": DEFAULT_ATTRIBUTION_WINDOW_DAYS,
        "min_payout_cents": DEFAULT_MIN_PAYOUT_CENTS,
    }


def _resolve_affiliate_owner_user_id(affiliate: Any) -> UUID | None:
    """Get the user_id that owns this affiliate for self-referral checks."""
    if affiliate.affiliate_type == "user":
        return affiliate.user_id
    return None


def _build_affiliate_update_fields(
    *,
    slug: str | None,
    payout_wallet_address: str | None,
    payout_chain: str | None,
    is_active: bool | None,
) -> dict[str, Any]:
    """Collect mutable affiliate fields from optional update inputs."""
    fields: dict[str, Any] = {}
    if slug is not None:
        fields["slug"] = slug
    if payout_wallet_address is not None:
        fields["payout_wallet_address"] = payout_wallet_address
    if payout_chain is not None:
        fields["payout_chain"] = payout_chain
    if is_active is not None:
        fields["is_active"] = is_active
    return fields


async def _trigger_affiliate_event(
    db: AsyncSession,
    *,
    event_type: str,
    application_id: UUID,
    data: dict[str, Any],
) -> None:
    """Best-effort webhook trigger for affiliate lifecycle events."""
    try:
        await webhook_service.trigger_event(
            db,
            event_type=event_type,
            application_id=application_id,
            data=data,
        )
    except Exception:
        logger.exception(
            "Failed to dispatch affiliate webhook event",
            extra={"event_type": event_type, "application_id": str(application_id)},
        )


# ---------------------------------------------------------------------------
# Affiliate registration & profile
# ---------------------------------------------------------------------------


async def register_affiliate(
    db: AsyncSession,
    *,
    user_id: UUID,
    affiliate_type: str,
    agent_id: UUID | None = None,
    slug: str,
    payout_wallet_address: str | None = None,
    payout_chain: str | None = None,
) -> dict[str, Any]:
    """Register as an affiliate."""
    # Check slug uniqueness
    existing_slug = await repo.get_affiliate_by_slug(db, slug)
    if existing_slug is not None:
        raise SlugAlreadyExistsError()

    # Determine the entity FK
    if affiliate_type == "agent":
        if agent_id is None:
            from ..errors import ValidationError
            raise ValidationError("agent_id is required for agent affiliates")

        # Check agent exists and is owned by user
        agent = await repo.get_agent_by_id(db, agent_id)
        if agent is None:
            from ..agent_approvals.errors import AgentNotFoundError
            raise AgentNotFoundError()
        if agent.owner_user_id != user_id:
            from ..agent_approvals.errors import NotAgentOwnerError
            raise NotAgentOwnerError()

        # Check agent doesn't already have an affiliate
        existing = await repo.get_affiliate_by_agent_id(db, agent_id)
        if existing is not None:
            raise AffiliateAlreadyExistsError()

        fk_user_id = None
        fk_agent_id = agent_id
    else:
        # User affiliate
        existing = await repo.get_affiliate_by_user_id(db, user_id)
        if existing is not None:
            raise AffiliateAlreadyExistsError()

        fk_user_id = user_id
        fk_agent_id = None

    # Check for referral chain linking
    referred_by_affiliate_id = None
    referral_depth = 0

    # Check if this entity was referred
    entity_type = affiliate_type
    entity_id = fk_agent_id if affiliate_type == "agent" else fk_user_id
    if entity_id:
        attribution = await repo.get_attribution_by_entity(db, entity_type, entity_id)
        if attribution:
            referrer = await repo.get_affiliate_by_id(db, attribution.affiliate_id)
            if referrer:
                referred_by_affiliate_id = referrer.id
                referral_depth = referrer.referral_depth + 1

    affiliate = await repo.create_affiliate(
        db,
        affiliate_type=affiliate_type,
        user_id=fk_user_id,
        agent_id=fk_agent_id,
        slug=slug,
        referred_by_affiliate_id=referred_by_affiliate_id,
        referral_depth=referral_depth,
        payout_wallet_address=payout_wallet_address,
        payout_chain=payout_chain,
    )

    result = _affiliate_to_dict(affiliate)
    await _enrich_referred_by(db, affiliate, result)
    return result


async def get_my_affiliate(
    db: AsyncSession,
    *,
    user_id: UUID,
    agent_id: UUID | None = None,
) -> dict[str, Any]:
    """Get the affiliate profile for the authenticated user or their agent."""
    affiliate = await _resolve_affiliate(db, user_id, agent_id)
    result = _affiliate_to_dict(affiliate)
    await _enrich_referred_by(db, affiliate, result)
    return result


async def update_my_affiliate(
    db: AsyncSession,
    *,
    user_id: UUID,
    agent_id: UUID | None = None,
    slug: str | None = None,
    payout_wallet_address: str | None = None,
    payout_chain: str | None = None,
    is_active: bool | None = None,
) -> dict[str, Any]:
    """Update affiliate profile."""
    affiliate = await _resolve_affiliate(db, user_id, agent_id)

    # Check slug uniqueness if changing
    if slug is not None and slug != affiliate.slug:
        existing = await repo.get_affiliate_by_slug(db, slug)
        if existing is not None:
            raise SlugAlreadyExistsError()

    fields = _build_affiliate_update_fields(
        slug=slug,
        payout_wallet_address=payout_wallet_address,
        payout_chain=payout_chain,
        is_active=is_active,
    )

    updated = await repo.update_affiliate(db, affiliate, **fields)

    result = _affiliate_to_dict(updated)
    await _enrich_referred_by(db, updated, result)
    return result


# ---------------------------------------------------------------------------
# Referral click tracking
# ---------------------------------------------------------------------------


async def record_click(
    db: AsyncSession,
    *,
    slug: str,
    application_id: UUID,
    ip_address: str,
    user_agent: str | None = None,
) -> dict[str, Any]:
    """Record a referral link click."""
    # Resolve affiliate from slug
    affiliate = await repo.get_affiliate_by_slug(db, slug)
    if affiliate is None or not affiliate.is_active:
        raise AffiliateNotFoundError()

    # IP-based dedup
    ip_hash = _hash_ip(ip_address)
    existing = await repo.get_recent_click(db, affiliate.id, ip_hash)
    if existing is not None:
        raise ClickRateLimitedError()

    # Get attribution window from app config
    rates = await _get_app_rates(db, application_id)
    window_days = rates["attribution_window_days"]

    now = datetime.now(UTC)
    expires_at = now + timedelta(days=window_days)

    click = await repo.create_click(
        db,
        affiliate_id=affiliate.id,
        application_id=application_id,
        ip_hash=ip_hash,
        user_agent=user_agent,
        expires_at=expires_at,
    )

    return {
        "click_id": str(click.id),
        "affiliate_slug": affiliate.slug,
        "expires_at": expires_at.isoformat(),
    }


# ---------------------------------------------------------------------------
# Referral attribution
# ---------------------------------------------------------------------------


async def attribute_referral(
    db: AsyncSession,
    *,
    referred_entity_type: str,
    referred_entity_id: UUID,
    caller_user_id: UUID | None = None,
    click_id: UUID | None = None,
    slug: str | None = None,
    application_id: UUID,
) -> dict[str, Any]:
    """Attribute a signup to a referral affiliate."""
    if caller_user_id is not None:
        await _check_caller_controls_referred_entity(
            db,
            caller_user_id=caller_user_id,
            entity_type=referred_entity_type,
            entity_id=referred_entity_id,
        )

    # Check entity not already attributed
    existing = await repo.get_attribution_by_entity(
        db, referred_entity_type, referred_entity_id
    )
    if existing is not None:
        raise AlreadyAttributedError()

    # Resolve affiliate
    affiliate: Any = None
    click = None

    if click_id:
        click = await repo.get_click_by_id(
            db,
            click_id,
            application_id=application_id,
        )
        if click is None:
            raise ClickNotFoundError()

        # Check expiration
        now = datetime.now(UTC)
        if click.expires_at <= now:
            raise ClickExpiredError()

        affiliate = await repo.get_affiliate_by_id(db, click.affiliate_id)
    elif slug:
        affiliate = await repo.get_affiliate_by_slug(db, slug)

    if affiliate is None:
        raise AffiliateNotFoundError()

    # Self-referral prevention
    await _check_self_referral(db, affiliate, referred_entity_type, referred_entity_id)

    # Create attribution
    attribution = await repo.create_attribution(
        db,
        referred_entity_type=referred_entity_type,
        referred_entity_id=referred_entity_id,
        affiliate_id=affiliate.id,
        referral_click_id=click.id if click else None,
        application_id=application_id,
    )

    # Update click conversion if applicable
    if click:
        await repo.update_click_conversion(
            db,
            click,
            converted_entity_type=referred_entity_type,
            converted_entity_id=referred_entity_id,
        )

    await _trigger_affiliate_event(
        db,
        event_type="REFERRAL_ATTRIBUTED",
        application_id=application_id,
        data={
            "affiliate_id": str(affiliate.id),
            "affiliate_slug": affiliate.slug,
            "referred_entity_type": referred_entity_type,
            "referred_entity_id": str(referred_entity_id),
            "application_id": str(application_id),
        },
    )

    return {
        "attribution_id": str(attribution.id),
        "referred_entity_type": referred_entity_type,
        "referred_entity_id": str(referred_entity_id),
        "affiliate_id": str(affiliate.id),
        "affiliate_slug": affiliate.slug,
        "attributed_at": attribution.attributed_at.isoformat()
        if hasattr(attribution.attributed_at, "isoformat")
        else str(attribution.attributed_at),
    }


async def _check_caller_controls_referred_entity(
    db: AsyncSession,
    *,
    caller_user_id: UUID,
    entity_type: str,
    entity_id: UUID,
) -> None:
    """Allow authenticated attribution only for the caller's own user/agent."""
    if entity_type == "user":
        if caller_user_id != entity_id:
            raise ForbiddenError("Caller must be the referred user")
        return

    if entity_type == "agent":
        agent = await repo.get_agent_by_id(db, entity_id)
        if agent is None or agent.owner_user_id != caller_user_id:
            raise ForbiddenError("Caller must own the referred agent")


async def _check_self_referral(
    db: AsyncSession,
    affiliate: Any,
    entity_type: str,
    entity_id: UUID,
) -> None:
    """Block self-referral at both direct and owner levels."""
    # Direct match: entity IS the affiliate
    if affiliate.affiliate_type == entity_type:
        if entity_type == "user" and affiliate.user_id == entity_id:
            raise SelfReferralError()
        if entity_type == "agent" and affiliate.agent_id == entity_id:
            raise SelfReferralError()

    # Cross-type: user owns the agent that's the affiliate (or vice versa)
    if affiliate.affiliate_type == "agent" and entity_type == "user":
        agent = await repo.get_agent_by_id(db, affiliate.agent_id)
        if agent and agent.owner_user_id == entity_id:
            raise SelfReferralError()

    if affiliate.affiliate_type == "user" and entity_type == "agent":
        agent = await repo.get_agent_by_id(db, entity_id)
        if agent and agent.owner_user_id == affiliate.user_id:
            raise SelfReferralError()


# ---------------------------------------------------------------------------
# Commission processing (internal)
# ---------------------------------------------------------------------------


async def process_commissions(
    db: AsyncSession,
    *,
    payer_entity_type: str,
    payer_entity_id: UUID,
    payment_amount_cents: int,
    payment_event_type: str,
    payment_reference: str,
    application_id: UUID,
) -> dict[str, Any]:
    """Process payment event for affiliate commissions.

    Walks the referral chain up to 3 levels and credits affiliates.
    Idempotent on payment_reference.
    """
    # Look up attribution for payer
    attribution = await repo.get_attribution_by_entity(
        db, payer_entity_type, payer_entity_id
    )
    if attribution is None:
        return {"commissions": []}

    # Get L1 affiliate (direct referrer)
    l1_affiliate = await repo.get_affiliate_by_id(db, attribution.affiliate_id)
    if l1_affiliate is None:
        return {"commissions": []}

    # Load app config
    rates = await _get_app_rates(db, application_id)
    if not rates["enabled"]:
        return {"commissions": []}

    # Walk chain
    level_rates = {
        1: rates["l1_rate_bps"],
        2: rates["l2_rate_bps"],
        3: rates["l3_rate_bps"],
    }

    commissions = []
    current_affiliate: Any = l1_affiliate

    for level in range(1, 4):
        if current_affiliate is None:
            break

        rate_bps = level_rates[level]
        commission_cents = (payment_amount_cents * rate_bps) // 10000

        # Skip zero-cent commissions
        if commission_cents <= 0:
            # Still walk the chain
            if current_affiliate.referred_by_affiliate_id:
                current_affiliate = await repo.get_affiliate_by_id(
                    db, current_affiliate.referred_by_affiliate_id
                )
            else:
                current_affiliate = None
            continue

        # Skip inactive affiliates but continue walking
        if not current_affiliate.is_active:
            if current_affiliate.referred_by_affiliate_id:
                current_affiliate = await repo.get_affiliate_by_id(
                    db, current_affiliate.referred_by_affiliate_id
                )
            else:
                current_affiliate = None
            continue

        # Idempotency check
        existing = await repo.get_commission_by_reference(
            db, payment_reference, current_affiliate.id, level
        )
        if existing is not None:
            commissions.append({
                "affiliate_id": str(current_affiliate.id),
                "level": level,
                "amount_cents": existing.commission_amount_cents,
                "rate_bps": existing.commission_rate_bps,
            })
        else:
            # Create commission record
            await repo.create_commission(
                db,
                affiliate_id=current_affiliate.id,
                source_entity_type=payer_entity_type,
                source_entity_id=payer_entity_id,
                payment_event_type=payment_event_type,
                payment_amount_cents=payment_amount_cents,
                commission_level=level,
                commission_rate_bps=rate_bps,
                commission_amount_cents=commission_cents,
                application_id=application_id,
                payment_reference=payment_reference,
            )

            # Credit balance
            await repo.credit_affiliate_balance(
                db, current_affiliate, commission_cents
            )

            await _trigger_affiliate_event(
                db,
                event_type="AFFILIATE_COMMISSION_EARNED",
                application_id=application_id,
                data={
                    "affiliate_id": str(current_affiliate.id),
                    "affiliate_slug": current_affiliate.slug,
                    "commission_level": level,
                    "commission_amount_cents": commission_cents,
                    "payment_event_type": payment_event_type,
                    "new_balance_cents": current_affiliate.credit_balance_cents,
                    "application_id": str(application_id),
                },
            )

            commissions.append({
                "affiliate_id": str(current_affiliate.id),
                "level": level,
                "amount_cents": commission_cents,
                "rate_bps": rate_bps,
            })

        # Walk to next level
        if current_affiliate.referred_by_affiliate_id:
            current_affiliate = await repo.get_affiliate_by_id(
                db, current_affiliate.referred_by_affiliate_id
            )
        else:
            current_affiliate = None

    return {"commissions": commissions}


# ---------------------------------------------------------------------------
# Commission / referral queries
# ---------------------------------------------------------------------------


async def get_commissions(
    db: AsyncSession,
    *,
    user_id: UUID,
    agent_id: UUID | None = None,
    level: int | None = None,
    since: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> dict[str, Any]:
    """Get commission history for an affiliate."""
    affiliate = await _resolve_affiliate(db, user_id, agent_id)

    commissions = await repo.list_commissions(
        db, affiliate.id, level=level, since=since, limit=limit, offset=offset
    )
    total = await repo.count_commissions(
        db, affiliate.id, level=level, since=since
    )
    by_level = await repo.sum_commissions_by_level(db, affiliate.id)

    # Batch-resolve source slugs and application names for enrichment
    source_slug_cache: dict[str, str | None] = {}
    app_name_cache: dict[str, str | None] = {}

    commission_list = []
    for c in commissions:
        # Resolve source_slug (affiliate slug of the payer entity)
        source_key = f"{c.source_entity_type}:{c.source_entity_id}"
        if source_key not in source_slug_cache:
            if c.source_entity_type == "agent":
                source_aff = await repo.get_affiliate_by_agent_id(db, c.source_entity_id)
            else:
                source_aff = await repo.get_affiliate_by_user_id(db, c.source_entity_id)
            source_slug_cache[source_key] = source_aff.slug if source_aff else None

        # Resolve application_name
        app_key = str(c.application_id)
        if app_key not in app_name_cache:
            app = await repo.get_application_by_id(db, c.application_id)
            app_name_cache[app_key] = app.name if app and hasattr(app, "name") else None

        commission_list.append({
            "id": str(c.id),
            "source_entity_type": c.source_entity_type,
            "source_slug": source_slug_cache[source_key],
            "payment_event_type": c.payment_event_type,
            "payment_amount_cents": c.payment_amount_cents,
            "commission_level": c.commission_level,
            "commission_rate_bps": c.commission_rate_bps,
            "commission_amount_cents": c.commission_amount_cents,
            "application_name": app_name_cache[app_key],
            "credited_at": c.credited_at.isoformat() if hasattr(c.credited_at, "isoformat") else str(c.credited_at),
        })

    return {
        "commissions": commission_list,
        "total": total,
        "summary": {
            "total_earned_cents": affiliate.lifetime_earned_cents,
            "by_level": {str(k): v for k, v in by_level.items()},
        },
    }


async def get_my_referrals(
    db: AsyncSession,
    *,
    user_id: UUID,
    agent_id: UUID | None = None,
    limit: int = 20,
    offset: int = 0,
) -> dict[str, Any]:
    """Get direct referrals for an affiliate."""
    affiliate = await _resolve_affiliate(db, user_id, agent_id)

    referrals = await repo.list_direct_referrals(
        db, affiliate.id, limit=limit, offset=offset
    )
    total = await repo.count_direct_referrals(db, affiliate.id)

    referral_list = []
    for r in referrals:
        referral_list.append({
            "affiliate_id": str(r.id),
            "affiliate_type": r.affiliate_type,
            "slug": r.slug,
            "attributed_at": r.created_at.isoformat() if hasattr(r.created_at, "isoformat") else str(r.created_at),
            "lifetime_revenue_cents": r.lifetime_earned_cents,
            "commission_earned_cents": r.lifetime_earned_cents,
        })

    return {"referrals": referral_list, "total": total}


async def get_referral_tree(
    db: AsyncSession,
    *,
    user_id: UUID,
    agent_id: UUID | None = None,
) -> dict[str, Any]:
    """Get referral tree summary (3-level counts + earnings)."""
    affiliate = await _resolve_affiliate(db, user_id, agent_id)

    levels = await repo.get_referral_tree_stats(db, affiliate.id)

    total_count = sum(lvl["referral_count"] for lvl in levels)
    total_earned = sum(lvl["total_earned_cents"] for lvl in levels)

    return {
        "levels": levels,
        "totals": {
            "referral_count": total_count,
            "total_earned_cents": total_earned,
        },
    }


# ---------------------------------------------------------------------------
# Payouts
# ---------------------------------------------------------------------------


async def request_payout(
    db: AsyncSession,
    *,
    user_id: UUID,
    agent_id: UUID | None = None,
    amount_cents: int,
    application_id: UUID,
) -> dict[str, Any]:
    """Request a USDC payout."""
    affiliate = await _resolve_affiliate(db, user_id, agent_id)

    # Validate wallet is set
    if not affiliate.payout_wallet_address or not affiliate.payout_chain:
        raise PayoutWalletNotSetError()

    # Validate minimum and balance
    rates = await _get_app_rates(db, application_id)
    min_payout = rates["min_payout_cents"]

    if amount_cents < min_payout:
        raise InsufficientBalanceError(
            f"Minimum payout is {min_payout} cents"
        )

    if amount_cents > affiliate.credit_balance_cents:
        raise InsufficientBalanceError("Amount exceeds available balance")

    # Check no active payout
    active = await repo.get_active_payout(db, affiliate.id)
    if active is not None:
        raise InsufficientBalanceError(
            "A payout is already in progress"
        )

    # Reserve balance
    affiliate.credit_balance_cents -= amount_cents
    affiliate.lifetime_paid_out_cents += amount_cents
    await db.flush()

    payout = await repo.create_payout(
        db,
        affiliate_id=affiliate.id,
        amount_cents=amount_cents,
        wallet_address=affiliate.payout_wallet_address,
        chain=affiliate.payout_chain,
    )

    return _payout_to_dict(payout)


async def get_my_payouts(
    db: AsyncSession,
    *,
    user_id: UUID,
    agent_id: UUID | None = None,
    status: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> dict[str, Any]:
    """Get payout history for an affiliate."""
    affiliate = await _resolve_affiliate(db, user_id, agent_id)

    payouts = await repo.list_payouts(
        db, affiliate_id=affiliate.id, status=status, limit=limit, offset=offset
    )
    total = await repo.count_payouts(
        db, affiliate_id=affiliate.id, status=status
    )

    return {
        "payouts": [_payout_to_dict(p) for p in payouts],
        "total": total,
    }


# ---------------------------------------------------------------------------
# Admin payout management
# ---------------------------------------------------------------------------


async def list_admin_payouts(
    db: AsyncSession,
    *,
    status: str | None = "requested",
    limit: int = 20,
    offset: int = 0,
) -> dict[str, Any]:
    """List payout queue (admin only)."""
    payouts = await repo.list_payouts(
        db, status=status, limit=limit, offset=offset
    )
    total = await repo.count_payouts(db, status=status)

    payout_list = []
    for p in payouts:
        affiliate = await repo.get_affiliate_by_id(db, p.affiliate_id)
        payout_list.append({
            **_payout_to_dict(p),
            "affiliate_id": str(p.affiliate_id),
            "affiliate_slug": affiliate.slug if affiliate else None,
            "affiliate_type": affiliate.affiliate_type if affiliate else None,
        })

    return {"payouts": payout_list, "total": total}


async def approve_payout(
    db: AsyncSession,
    *,
    payout_id: UUID,
    admin_user_id: UUID,
) -> dict[str, Any]:
    """Approve a payout request (admin only)."""
    payout = await repo.get_payout_by_id(db, payout_id)
    if payout is None:
        raise PayoutNotFoundError()

    if payout.status != "requested":
        raise PayoutNotPendingError()

    now = datetime.now(UTC)
    await repo.update_payout(
        db,
        payout,
        status="approved",
        approved_at=now,
        approved_by_user_id=admin_user_id,
    )

    return {
        "id": str(payout_id),
        "status": "approved",
        "approved_at": now.isoformat(),
        "message": "Payout approved. Send USDC manually, then mark completed with tx_hash.",
    }


async def complete_payout(
    db: AsyncSession,
    *,
    payout_id: UUID,
    tx_hash: str,
    application_id: UUID,
) -> dict[str, Any]:
    """Mark a payout as completed with tx_hash (admin only)."""
    payout = await repo.get_payout_by_id(db, payout_id)
    if payout is None:
        raise PayoutNotFoundError()

    if payout.status != "approved":
        raise PayoutNotApprovedError()

    now = datetime.now(UTC)
    await repo.update_payout(
        db,
        payout,
        status="completed",
        tx_hash=tx_hash,
        completed_at=now,
    )

    affiliate = await repo.get_affiliate_by_id(db, payout.affiliate_id)
    if affiliate:
        await _trigger_affiliate_event(
            db,
            event_type="AFFILIATE_PAYOUT_COMPLETED",
            application_id=application_id,
            data={
                "affiliate_id": str(affiliate.id),
                "affiliate_slug": affiliate.slug,
                "amount_cents": payout.amount_cents,
                "tx_hash": tx_hash,
                "chain": payout.chain,
                "new_balance_cents": affiliate.credit_balance_cents,
            },
        )

    return {
        "id": str(payout_id),
        "status": "completed",
        "tx_hash": tx_hash,
        "completed_at": now.isoformat(),
        "message": "Payout marked as completed.",
    }


async def deny_payout(
    db: AsyncSession,
    *,
    payout_id: UUID,
    reason: str | None = None,
) -> dict[str, Any]:
    """Deny a payout and refund balance (admin only)."""
    payout = await repo.get_payout_by_id(db, payout_id)
    if payout is None:
        raise PayoutNotFoundError()

    if payout.status != "requested":
        raise PayoutNotPendingError()

    await repo.update_payout(
        db,
        payout,
        status="denied",
        denial_reason=reason,
    )

    # Refund balance
    await repo.refund_payout_to_balance(db, payout)

    return {
        "id": str(payout_id),
        "status": "denied",
        "message": "Payout denied. Credits returned to affiliate balance.",
    }


async def fail_payout(
    db: AsyncSession,
    *,
    payout_id: UUID,
    reason: str | None = None,
) -> dict[str, Any]:
    """Mark a payout as failed and refund balance (admin only)."""
    payout = await repo.get_payout_by_id(db, payout_id)
    if payout is None:
        raise PayoutNotFoundError()

    if payout.status != "approved":
        raise PayoutNotApprovedError()

    await repo.update_payout(
        db,
        payout,
        status="failed",
        failure_reason=reason,
    )

    # Refund balance
    await repo.refund_payout_to_balance(db, payout)

    return {
        "id": str(payout_id),
        "status": "failed",
        "message": "Payout marked as failed. Credits returned to affiliate balance.",
    }


# ---------------------------------------------------------------------------
# App affiliate config
# ---------------------------------------------------------------------------


async def get_affiliate_config(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> dict[str, Any]:
    """Get affiliate config for an application (returns defaults if none)."""
    rates = await _get_app_rates(db, application_id)
    return {
        "application_id": str(application_id),
        **rates,
    }


async def update_affiliate_config(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    is_admin: bool = False,
    enabled: bool,
    l1_rate_bps: int,
    l2_rate_bps: int,
    l3_rate_bps: int,
    attribution_window_days: int,
    min_payout_cents: int,
) -> dict[str, Any]:
    """Update affiliate config (application owner or admin)."""
    # Check ownership
    if not is_admin:
        owner_id = await repo.get_application_owner_id(db, application_id)
        if owner_id != user_id:
            raise NotApplicationOwnerError()

    config = await repo.upsert_app_config(
        db,
        application_id,
        enabled=enabled,
        l1_rate_bps=l1_rate_bps,
        l2_rate_bps=l2_rate_bps,
        l3_rate_bps=l3_rate_bps,
        attribution_window_days=attribution_window_days,
        min_payout_cents=min_payout_cents,
    )

    return {
        "application_id": str(application_id),
        "enabled": config.enabled,
        "l1_rate_bps": config.l1_rate_bps,
        "l2_rate_bps": config.l2_rate_bps,
        "l3_rate_bps": config.l3_rate_bps,
        "attribution_window_days": config.attribution_window_days,
        "min_payout_cents": config.min_payout_cents,
        "updated_at": config.updated_at.isoformat() if hasattr(config.updated_at, "isoformat") else str(config.updated_at),
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


async def _resolve_affiliate(
    db: AsyncSession,
    user_id: UUID,
    agent_id: UUID | None = None,
) -> Any:
    """Resolve affiliate from user_id/agent_id, raising AffiliateNotFoundError if not found."""
    if agent_id:
        agent = await repo.get_agent_by_id(db, agent_id)
        if agent is None or agent.owner_user_id != user_id:
            raise AffiliateNotFoundError()
        affiliate = await repo.get_affiliate_by_agent_id(db, agent_id)
    else:
        affiliate = await repo.get_affiliate_by_user_id(db, user_id)

    if affiliate is None:
        raise AffiliateNotFoundError()

    return affiliate
