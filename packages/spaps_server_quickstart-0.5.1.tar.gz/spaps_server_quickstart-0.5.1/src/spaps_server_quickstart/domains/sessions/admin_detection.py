"""Admin role and permission detection for SPAPS.

Ported from the TypeScript ``src/utils/adminDetection.ts`` and
``src/types/admin.ts``.  Provides static configuration of admin
identities (emails, wallet addresses, super-admin IDs) and a full
role-to-permission mapping.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Static admin identity lists
# ---------------------------------------------------------------------------

ADMIN_EMAILS: list[str] = [
    "buildooor@gmail.com",
    "hailey@healingwithhailey.ca",
    "rob@campbellcoaccounting.com",
    "rob+super-admin@campbellcoaccounting.com",
    "rob+accountant@campbellcoaccounting.com",
]

SUPER_ADMIN_IDS: list[str] = [
    "5bdb0db2-5ab1-4e2c-999b-1153cc329477",
]

ADMIN_WALLETS: dict[str, list[str]] = {
    "ethereum": [
        "0xa72bb7CeF1e4B2Cc144373d8dE0Add7CCc8DF4Ba",
    ],
    "solana": [
        "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy",
    ],
    "bitcoin": [],
    "base": [],
}

# ---------------------------------------------------------------------------
# Role -> permission mapping
# ---------------------------------------------------------------------------

ROLE_PERMISSIONS: dict[str, list[str]] = {
    "admin": [
        "view_products",
        "create_products",
        "edit_products",
        "manage_products",
        "view_users",
        "view_orders",
        "create_orders",
        "edit_orders",
        "access_admin",
        "view_analytics",
        "view_subscriptions",
        "manage_subscriptions",
    ],
    "super_admin": [
        "view_products",
        "create_products",
        "edit_products",
        "delete_products",
        "manage_products",
        "view_users",
        "create_users",
        "edit_users",
        "delete_users",
        "manage_users",
        "view_orders",
        "create_orders",
        "edit_orders",
        "cancel_orders",
        "manage_orders",
        "access_admin",
        "access_super_admin",
        "system_settings",
        "view_analytics",
        "view_reports",
        "export_data",
        "view_subscriptions",
        "manage_subscriptions",
        "cancel_subscriptions",
        "access_audit_logs",
        "view_security_alerts",
        "manage_security",
        "view_compliance_reports",
    ],
    "security_admin": [
        "view_users",
        "view_orders",
        "access_admin",
        "view_analytics",
        "view_reports",
        "access_audit_logs",
        "view_security_alerts",
        "manage_security",
        "view_compliance_reports",
    ],
    "billing_admin": [
        "view_products",
        "view_users",
        "view_orders",
        "access_admin",
        "view_analytics",
        "view_subscriptions",
        "manage_subscriptions",
    ],
    "user": [
        "view_products",
    ],
}


# ---------------------------------------------------------------------------
# Detection helpers
# ---------------------------------------------------------------------------

def _flatten_admin_wallets() -> set[str]:
    """Return all admin wallet addresses lower-cased for O(1) lookup."""
    return {
        addr.lower()
        for addresses in ADMIN_WALLETS.values()
        for addr in addresses
    }


_ADMIN_WALLET_SET: set[str] = _flatten_admin_wallets()
_ADMIN_EMAIL_SET: set[str] = {e.lower() for e in ADMIN_EMAILS}


def is_admin_user(
    email: str | None = None,
    user_id: str | None = None,
    wallet_addresses: list[str] | None = None,
) -> bool:
    """Return ``True`` if the user has any admin privilege.

    Checks (in order):
        1. Super-admin user ID
        2. Admin email
        3. Admin wallet address (any chain)
    """

    if user_id and user_id in SUPER_ADMIN_IDS:
        logger.info("Admin detected via super-admin ID", extra={"user_id": user_id})
        return True

    if email and email.lower() in _ADMIN_EMAIL_SET:
        logger.info(
            "Admin detected via email",
            extra={"user_id": user_id, "email": email},
        )
        return True

    if wallet_addresses:
        for addr in wallet_addresses:
            if addr.lower() in _ADMIN_WALLET_SET:
                logger.info(
                    "Admin detected via wallet",
                    extra={"user_id": user_id, "wallet_address": addr},
                )
                return True

    return False


def is_super_admin(
    email: str | None = None,
    user_id: str | None = None,
) -> bool:
    """Return ``True`` if the user is a super-admin.

    Super-admins are identified only by explicit ``SUPER_ADMIN_IDS``.
    Admin email matches grant ``admin`` role, but not ``super_admin``.
    """

    if user_id and user_id in SUPER_ADMIN_IDS:
        logger.info("Super-admin detected via user ID", extra={"user_id": user_id})
        return True

    return False


def get_user_roles(
    email: str | None = None,
    user_id: str | None = None,
    wallet_addresses: list[str] | None = None,
) -> list[str]:
    """Determine the role list for a user.

    Returns:
        ``['admin', 'super_admin']`` for super-admins,
        ``['admin']`` for regular admins,
        ``['user']`` for everyone else.
    """

    if is_super_admin(email=email, user_id=user_id):
        return ["admin", "super_admin"]

    if is_admin_user(email=email, user_id=user_id, wallet_addresses=wallet_addresses):
        return ["admin"]

    return ["user"]


def get_admin_permissions(roles: list[str]) -> list[str]:
    """Collect the de-duplicated union of permissions for the given *roles*.

    Unknown roles are silently ignored.  If no matching roles are found the
    result is the default ``['view_products']`` permission set.
    """

    permissions: set[str] = set()
    for role in roles:
        role_perms = ROLE_PERMISSIONS.get(role)
        if role_perms is not None:
            permissions.update(role_perms)

    if not permissions:
        return list(ROLE_PERMISSIONS.get("user", ["view_products"]))

    return sorted(permissions)
