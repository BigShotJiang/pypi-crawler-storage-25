"""Resolve Stripe billing context from trusted application state."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Protocol
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from spaps_server_quickstart.domains.errors import InvalidStateError, NotFoundError
from spaps_server_quickstart.spaps_settings import SpapsSettings, get_spaps_settings

from ..applications import repository as applications_repo
from ..secure_messages.encryption import PiiEncryptionService
from . import repository as billing_accounts_repo


class TrustedApplication(Protocol):
    """Trusted application shape carried by auth dependencies."""

    id: UUID | str
    billing_account_id: UUID | str | None


@dataclass(frozen=True, slots=True)
class _ResolvedApplicationRef:
    """Normalized trusted application reference for resolver internals."""

    id: UUID
    billing_account_id: UUID | None


@dataclass(frozen=True, slots=True)
class StripeBillingContext:
    """Resolved Stripe billing credentials for an application."""

    application_id: UUID
    source: Literal["billing_account", "legacy_env_default"]
    stripe_secret_key: str
    billing_account_id: UUID | None = None
    stripe_account_id: str | None = None
    stripe_publishable_key: str | None = None
    stripe_webhook_secret: str | None = None
    credential_source: str | None = None
    ownership_mode: str | None = None
    livemode: bool = False


async def resolve_stripe_billing_context(
    db: AsyncSession,
    *,
    application: TrustedApplication | None = None,
    application_id: UUID | str | None = None,
    settings: SpapsSettings | None = None,
) -> StripeBillingContext:
    """Resolve Stripe credentials for a trusted application context.

    Accepts either a trusted application model from auth dependencies or an
    explicit ``application_id`` that is looked up server-side. Raw request
    metadata is intentionally out of scope for this resolver.
    """

    resolved_application = await _resolve_application(
        db,
        application=application,
        application_id=application_id,
    )
    resolved_application_id = resolved_application.id
    resolved_billing_account_id = resolved_application.billing_account_id

    if resolved_billing_account_id is None:
        return _build_legacy_env_context(
            application_id=resolved_application_id,
            settings=settings or get_spaps_settings(),
        )

    return await _resolve_bound_billing_account_context(
        db,
        billing_account_id=resolved_billing_account_id,
        application_id=resolved_application_id,
        settings=settings or get_spaps_settings(),
    )


async def resolve_stripe_billing_context_for_billing_account(
    db: AsyncSession,
    *,
    billing_account_id: UUID | str,
    settings: SpapsSettings | None = None,
) -> StripeBillingContext:
    """Resolve Stripe credentials directly from a billing-account id."""
    return await _resolve_bound_billing_account_context(
        db,
        billing_account_id=billing_account_id,
        application_id=None,
        settings=settings or get_spaps_settings(),
    )


async def _resolve_bound_billing_account_context(
    db: AsyncSession,
    *,
    billing_account_id: UUID | str,
    application_id: UUID | None,
    settings: SpapsSettings,
) -> StripeBillingContext:
    bound_billing_account_id = _coerce_uuid(billing_account_id)
    billing_account = await billing_accounts_repo.get_billing_account_by_id(
        db,
        str(bound_billing_account_id),
    )
    if billing_account is None:
        raise InvalidStateError(
            "Application billing account binding is invalid",
            status_code=500,
        )

    if billing_account.provider != "stripe":
        raise InvalidStateError(
            "Application billing account is not configured for Stripe",
            status_code=500,
        )

    if not billing_account.encrypted_secret_key:
        raise InvalidStateError(
            "Stripe billing account secret key is not configured",
            status_code=500,
        )

    stripe_secret_key = _resolve_billing_secret(
        billing_account.encrypted_secret_key,
        billing_account_id=bound_billing_account_id,
        application_id=application_id,
        settings=settings,
        field_name="secret key",
        expected_prefixes=("sk_", "rk_"),
    )
    if stripe_secret_key is None:
        raise InvalidStateError(
            "Stripe billing account secret key is not configured",
            status_code=500,
        )

    return StripeBillingContext(
        application_id=application_id or bound_billing_account_id,
        source="billing_account",
        stripe_secret_key=stripe_secret_key,
        billing_account_id=bound_billing_account_id,
        stripe_account_id=billing_account.stripe_account_id,
        stripe_publishable_key=billing_account.stripe_publishable_key,
        stripe_webhook_secret=_resolve_billing_secret(
            billing_account.encrypted_webhook_secret,
            billing_account_id=bound_billing_account_id,
            application_id=application_id,
            settings=settings,
            field_name="webhook secret",
            expected_prefixes=("whsec_",),
        ),
        credential_source=billing_account.credential_source,
        ownership_mode=billing_account.ownership_mode,
        livemode=bool(billing_account.livemode),
    )


async def _resolve_application(
    db: AsyncSession,
    *,
    application: TrustedApplication | None,
    application_id: UUID | str | None,
) -> _ResolvedApplicationRef:
    if (application is None) == (application_id is None):
        raise ValueError("Provide exactly one of application or application_id")

    if application is not None:
        return _ResolvedApplicationRef(
            id=_coerce_uuid(application.id),
            billing_account_id=_coerce_optional_uuid(application.billing_account_id),
        )

    resolved_application_id = _coerce_uuid(application_id)
    application_model = await applications_repo.get_application_by_id(
        db,
        str(resolved_application_id),
    )
    if application_model is None:
        raise NotFoundError("Application not found")
    return _ResolvedApplicationRef(
        id=_coerce_uuid(application_model.id),
        billing_account_id=_coerce_optional_uuid(
            application_model.billing_account_id,
        ),
    )


def _build_legacy_env_context(
    *,
    application_id: UUID,
    settings: SpapsSettings,
) -> StripeBillingContext:
    stripe_secret_key = settings.stripe_secret_key
    return StripeBillingContext(
        application_id=application_id,
        source="legacy_env_default",
        stripe_secret_key=stripe_secret_key,
        stripe_webhook_secret=settings.stripe_webhook_secret or None,
        credential_source="env_ref",
        ownership_mode="platform_managed",
        livemode=stripe_secret_key.startswith("sk_live_"),
    )


def _resolve_billing_secret(
    encrypted_value: str | None,
    *,
    billing_account_id: UUID,
    application_id: UUID | None,
    settings: SpapsSettings,
    field_name: str,
    expected_prefixes: tuple[str, ...],
) -> str | None:
    if encrypted_value is None:
        return None
    if encrypted_value.startswith(expected_prefixes):
        return encrypted_value

    master_key = getattr(settings, "spaps_pii_master_key", "")
    if not master_key:
        return encrypted_value

    decryptor = PiiEncryptionService(master_key=master_key)
    candidate_ids = [str(billing_account_id)]
    if application_id is not None:
        candidate_ids.append(str(application_id))

    last_error: Exception | None = None
    for candidate_id in candidate_ids:
        try:
            decrypted = decryptor.decrypt_field(
                application_id=candidate_id,
                encoded=encrypted_value,
            )
        except Exception as exc:
            last_error = exc
            continue

        if isinstance(decrypted, str) and decrypted.startswith(expected_prefixes):
            return decrypted
        if decrypted == encrypted_value:
            continue

    if last_error is not None:
        raise InvalidStateError(
            f"Stripe billing account {field_name} could not be decrypted",
            status_code=500,
        ) from last_error

    return encrypted_value


def _coerce_uuid(value: UUID | str | None) -> UUID:
    if isinstance(value, UUID):
        return value
    if value is None:
        raise ValueError("Expected UUID value")
    return UUID(str(value))


def _coerce_optional_uuid(value: UUID | str | None) -> UUID | None:
    if value is None:
        return None
    return _coerce_uuid(value)
