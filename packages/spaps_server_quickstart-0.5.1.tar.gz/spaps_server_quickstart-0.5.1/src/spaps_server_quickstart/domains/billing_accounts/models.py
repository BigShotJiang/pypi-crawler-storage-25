"""SQLAlchemy models for billing account ownership and credential metadata."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import Boolean, DateTime, Text, func, text
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, EncryptedText, PGUUID


class BillingAccount(Base):
    """A first-class billing account bound to one or more applications."""

    __tablename__ = "billing_accounts"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    provider: Mapped[str] = mapped_column(Text, nullable=False)
    ownership_mode: Mapped[str] = mapped_column(Text, nullable=False)
    credential_source: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(
        Text, nullable=False, server_default=text("'active'"), default="active"
    )
    livemode: Mapped[bool] = mapped_column(
        Boolean, nullable=False, server_default="false", default=False
    )
    stripe_account_id: Mapped[str | None] = mapped_column(
        Text, unique=True, nullable=True
    )
    stripe_publishable_key: Mapped[str | None] = mapped_column(Text, nullable=True)
    encrypted_secret_key: Mapped[str | None] = mapped_column(
        EncryptedText, nullable=True
    )
    encrypted_webhook_secret: Mapped[str | None] = mapped_column(
        EncryptedText, nullable=True
    )
    stripe_webhook_endpoint_id: Mapped[str | None] = mapped_column(
        Text, unique=True, nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return (
            f"<BillingAccount id={self.id!r} provider={self.provider!r} "
            f"ownership_mode={self.ownership_mode!r}>"
        )
