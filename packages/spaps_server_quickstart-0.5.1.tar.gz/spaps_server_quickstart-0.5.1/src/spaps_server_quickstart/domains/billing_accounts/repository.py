"""Database operations for the billing_accounts domain."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import BillingAccount


async def get_billing_account_by_id(
    db: AsyncSession,
    billing_account_id: str,
) -> BillingAccount | None:
    """Fetch a billing account by primary key."""
    result = await db.execute(
        select(BillingAccount).where(BillingAccount.id == billing_account_id)
    )
    return result.scalar_one_or_none()


async def get_billing_account_by_stripe_account_id(
    db: AsyncSession,
    stripe_account_id: str,
) -> BillingAccount | None:
    """Fetch a billing account by its Stripe account id."""
    result = await db.execute(
        select(BillingAccount).where(
            BillingAccount.stripe_account_id == stripe_account_id
        )
    )
    return result.scalar_one_or_none()


async def create_billing_account(
    db: AsyncSession,
    *,
    provider: str,
    ownership_mode: str,
    credential_source: str,
    status: str = "active",
    livemode: bool = False,
    stripe_account_id: str | None = None,
    stripe_publishable_key: str | None = None,
    encrypted_secret_key: str | None = None,
    encrypted_webhook_secret: str | None = None,
    stripe_webhook_endpoint_id: str | None = None,
) -> BillingAccount:
    """Insert a new billing account and return the persisted instance."""
    billing_account = BillingAccount(
        provider=provider,
        ownership_mode=ownership_mode,
        credential_source=credential_source,
        status=status,
        livemode=livemode,
        stripe_account_id=stripe_account_id,
        stripe_publishable_key=stripe_publishable_key,
        encrypted_secret_key=encrypted_secret_key,
        encrypted_webhook_secret=encrypted_webhook_secret,
        stripe_webhook_endpoint_id=stripe_webhook_endpoint_id,
    )

    db.add(billing_account)
    await db.flush()
    await db.refresh(billing_account)
    return billing_account


async def update_billing_account(
    db: AsyncSession,
    billing_account_id: str,
    **kwargs: Any,
) -> BillingAccount | None:
    """Update arbitrary columns on a billing account row."""
    billing_account = await get_billing_account_by_id(db, billing_account_id)
    if billing_account is None:
        return None

    for key, value in kwargs.items():
        if hasattr(billing_account, key):
            setattr(billing_account, key, value)

    billing_account.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(billing_account)
    return billing_account


async def list_billing_accounts(
    db: AsyncSession,
    *,
    provider: str | None = None,
    ownership_mode: str | None = None,
    active_only: bool = False,
) -> list[BillingAccount]:
    """List billing accounts, optionally filtered by provider or status."""
    stmt = select(BillingAccount).order_by(BillingAccount.created_at.desc())

    if provider is not None:
        stmt = stmt.where(BillingAccount.provider == provider)
    if ownership_mode is not None:
        stmt = stmt.where(BillingAccount.ownership_mode == ownership_mode)
    if active_only:
        stmt = stmt.where(BillingAccount.status == "active")

    result = await db.execute(stmt)
    return list(result.scalars().all())
