"""Pydantic request/response schemas for webhook endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Webhook event types (hardcoded list from spec)
# ---------------------------------------------------------------------------

WEBHOOK_EVENT_TYPES: list[dict[str, str]] = [
    # Authentication
    {"key": "user.registered", "value": "user.registered", "description": "User registered a new account"},
    {"key": "user.login", "value": "user.login", "description": "User logged in"},
    {"key": "user.logout", "value": "user.logout", "description": "User logged out"},
    {"key": "user.password_reset", "value": "user.password_reset", "description": "User requested password reset"},
    {"key": "user.password_changed", "value": "user.password_changed", "description": "User changed their password"},
    # Sessions
    {"key": "session.created", "value": "session.created", "description": "New session created"},
    {"key": "session.refreshed", "value": "session.refreshed", "description": "Session token refreshed"},
    {"key": "session.revoked", "value": "session.revoked", "description": "Session revoked"},
    {"key": "session.expired", "value": "session.expired", "description": "Session expired"},
    # Wallets
    {"key": "wallet.connected", "value": "wallet.connected", "description": "Wallet connected to account"},
    {"key": "wallet.disconnected", "value": "wallet.disconnected", "description": "Wallet disconnected from account"},
    {"key": "wallet.verified", "value": "wallet.verified", "description": "Wallet ownership verified"},
    # Security
    {"key": "security.suspicious_activity", "value": "security.suspicious_activity", "description": "Suspicious activity detected"},
    {"key": "security.failed_login_attempts", "value": "security.failed_login_attempts", "description": "Multiple failed login attempts"},
    {"key": "security.token_blacklisted", "value": "security.token_blacklisted", "description": "Token was blacklisted"},
    # Entitlements
    {"key": "entitlement.granted", "value": "entitlement.granted", "description": "Entitlement granted to user"},
    {"key": "entitlement.renewed", "value": "entitlement.renewed", "description": "Entitlement renewed"},
    {"key": "entitlement.updated", "value": "entitlement.updated", "description": "Entitlement updated"},
    {"key": "entitlement.expired", "value": "entitlement.expired", "description": "Entitlement expired"},
    {"key": "entitlement.revoked", "value": "entitlement.revoked", "description": "Entitlement revoked"},
    {"key": "entitlement.claimed", "value": "entitlement.claimed", "description": "Entitlement claimed by user"},
    # Bookings (checkin_call_booking)
    {"key": "booking.created", "value": "booking.created", "description": "Booking created (free or paid-confirmed)"},
    {"key": "booking.cancelled", "value": "booking.cancelled", "description": "Booking cancelled (patient or admin)"},
    {"key": "booking.rescheduled", "value": "booking.rescheduled", "description": "Booking rescheduled (old cancelled + new created)"},
    # Affiliate referrals
    {"key": "AFFILIATE_COMMISSION_EARNED", "value": "AFFILIATE_COMMISSION_EARNED", "description": "Affiliate earned a commission from a referred payment"},
    {"key": "AFFILIATE_PAYOUT_COMPLETED", "value": "AFFILIATE_PAYOUT_COMPLETED", "description": "Affiliate payout marked as completed"},
    {"key": "REFERRAL_ATTRIBUTED", "value": "REFERRAL_ATTRIBUTED", "description": "A user or agent signup was attributed to an affiliate"},
]

VALID_EVENT_TYPE_KEYS: set[str] = {e["key"] for e in WEBHOOK_EVENT_TYPES}


# ---------------------------------------------------------------------------
# Canonical representations
# ---------------------------------------------------------------------------


class WebhookOut(BaseModel):
    """Canonical representation of a webhook."""

    id: str
    application_id: str
    url: str
    events: list[str]
    is_active: bool
    headers: dict[str, Any] | None = None
    retry_config: dict[str, Any] | None = None
    created_at: str
    updated_at: str


class WebhookDeliveryOut(BaseModel):
    """Canonical representation of a webhook delivery."""

    id: str
    webhook_id: str
    event_type: str
    payload: dict[str, Any]
    response_status: int | None = None
    response_body: str | None = None
    delivered_at: str | None = None
    retry_count: int
    attempt: int
    error_message: str | None = None


class WebhookEventTypeOut(BaseModel):
    """Canonical representation of a webhook event type."""

    key: str
    value: str
    description: str


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class CreateWebhookRequest(BaseModel):
    """POST /webhooks body."""

    url: str
    events: list[str]
    headers: dict[str, Any] | None = None


class UpdateWebhookRequest(BaseModel):
    """PUT /webhooks/{id} body."""

    url: str | None = None
    events: list[str] | None = None
    is_active: bool | None = None
    headers: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class ListWebhooksResponse(BaseModel):
    """GET /webhooks -- success payload."""

    webhooks: list[WebhookOut]
    total: int


class CreateWebhookResponse(BaseModel):
    """POST /webhooks -- success payload."""

    webhook: WebhookOut
    signing_secret: str
    message: str


class UpdateWebhookResponse(BaseModel):
    """PUT /webhooks/{id} -- success payload."""

    webhook: WebhookOut


class DeleteWebhookResponse(BaseModel):
    """DELETE /webhooks/{id} -- success payload."""

    message: str
    webhook_id: str


class ListDeliveriesResponse(BaseModel):
    """GET /webhooks/{id}/deliveries -- success payload."""

    deliveries: list[WebhookDeliveryOut]
    total: int


class ListEventTypesResponse(BaseModel):
    """GET /webhooks/events -- success payload."""

    events: list[WebhookEventTypeOut]
    total: int


class MailgunEventResponse(BaseModel):
    """POST /webhooks/mailgun/events -- success payload."""

    message: str
    event: str
    status: str
