"""HMAC-SHA256 signing and verification for webhook payloads.

Signature format: ``X-SPAPS-Signature: t=<timestamp>,v1=<hmac_sha256_hex>``

HMAC is computed on ``<timestamp>.<json_body>`` using the webhook secret.

Zero FastAPI imports -- pure crypto utility.
"""

from __future__ import annotations

import hashlib
import hmac
import re
import time


# Signature header regex: t=<unix_timestamp>,v1=<64_hex_chars>
_SIGNATURE_PATTERN = re.compile(r"^t=(\d+),v1=([a-f0-9]{64})$")

# Maximum allowed age of a signature timestamp (in seconds)
MAX_TIMESTAMP_AGE_SECONDS = 300
_mailgun_seen_tokens: dict[str, int] = {}


def compute_signature(*, timestamp: int, body: str, secret: str) -> str:
    """Compute HMAC-SHA256 signature for a webhook payload.

    Args:
        timestamp: Unix timestamp (seconds).
        body: JSON-encoded payload body.
        secret: Webhook secret key.

    Returns:
        Hex-encoded HMAC-SHA256 signature.
    """
    message = f"{timestamp}.{body}"
    return hmac.new(
        secret.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def build_signature_header(*, timestamp: int, body: str, secret: str) -> str:
    """Build the full ``X-SPAPS-Signature`` header value.

    Args:
        timestamp: Unix timestamp (seconds).
        body: JSON-encoded payload body.
        secret: Webhook secret key.

    Returns:
        Header value in format ``t=<timestamp>,v1=<hmac_hex>``.
    """
    sig = compute_signature(timestamp=timestamp, body=body, secret=secret)
    return f"t={timestamp},v1={sig}"


def verify_signature(
    *,
    header: str,
    body: str,
    secret: str,
    current_time: int | None = None,
) -> bool:
    """Verify an ``X-SPAPS-Signature`` header.

    Parses the ``t=`` timestamp and ``v1=`` HMAC from the header,
    checks the timestamp is within ``MAX_TIMESTAMP_AGE_SECONDS`` of
    current time, then performs a timing-safe comparison of the HMAC.

    Args:
        header: The ``X-SPAPS-Signature`` header value.
        body: The raw request body (JSON string).
        secret: The webhook secret key.
        current_time: Override for current unix timestamp (for testing).

    Returns:
        True if the signature is valid and not expired.
    """
    match = _SIGNATURE_PATTERN.match(header)
    if not match:
        return False

    timestamp = int(match.group(1))
    provided_sig = match.group(2)

    # Check timestamp freshness
    now = current_time if current_time is not None else int(time.time())
    if abs(now - timestamp) > MAX_TIMESTAMP_AGE_SECONDS:
        return False

    # Compute expected signature
    expected_sig = compute_signature(
        timestamp=timestamp, body=body, secret=secret
    )

    # Timing-safe comparison
    return hmac.compare_digest(provided_sig, expected_sig)


def verify_mailgun_signature(
    *,
    signing_key: str,
    timestamp: str,
    token: str,
    signature: str,
) -> bool:
    """Verify a Mailgun webhook signature.

    Mailgun signs webhooks with HMAC-SHA256 of ``timestamp + token``
    using the Mailgun signing key.

    Args:
        signing_key: Mailgun webhook signing key.
        timestamp: The ``timestamp`` field from the Mailgun event.
        token: The ``token`` field from the Mailgun event.
        signature: The ``signature`` field from the Mailgun event.

    Returns:
        True if the signature is valid.
    """
    message = f"{timestamp}{token}"
    expected = hmac.new(
        signing_key.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(expected, signature)


def is_mailgun_timestamp_fresh(
    *,
    timestamp: str,
    current_time: int | None = None,
) -> bool:
    """Return True when a Mailgun timestamp is within the replay window."""
    try:
        timestamp_int = int(timestamp)
    except (TypeError, ValueError):
        return False

    now = current_time if current_time is not None else int(time.time())
    return abs(now - timestamp_int) <= MAX_TIMESTAMP_AGE_SECONDS


def register_mailgun_delivery(
    *,
    timestamp: str,
    token: str,
    current_time: int | None = None,
) -> bool:
    """Track a Mailgun token within the replay window.

    Returns ``False`` when the same ``timestamp`` + ``token`` combination
    has already been seen inside the replay window.
    """
    now = current_time if current_time is not None else int(time.time())
    cutoff = now - MAX_TIMESTAMP_AGE_SECONDS

    stale_keys = [
        key for key, seen_at in _mailgun_seen_tokens.items() if seen_at < cutoff
    ]
    for key in stale_keys:
        _mailgun_seen_tokens.pop(key, None)

    key = f"{timestamp}:{token}"
    if key in _mailgun_seen_tokens:
        return False

    _mailgun_seen_tokens[key] = now
    return True


def reset_mailgun_replay_protection() -> None:
    """Clear process-local Mailgun replay tracking state."""
    _mailgun_seen_tokens.clear()
