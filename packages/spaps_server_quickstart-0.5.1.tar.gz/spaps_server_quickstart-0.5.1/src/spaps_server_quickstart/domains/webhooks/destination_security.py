"""Shared destination security helpers for webhook URL validation and delivery."""

from __future__ import annotations

import asyncio
import ipaddress
import socket
from urllib.parse import ParseResult, urlparse

IPAddress = ipaddress.IPv4Address | ipaddress.IPv6Address

NON_PRODUCTION_ENVIRONMENTS = frozenset(("development", "dev", "test"))


def is_non_production_environment(environment: str) -> bool:
    """Return True when the environment is a local/dev/test variant."""
    return environment.lower() in NON_PRODUCTION_ENVIRONMENTS


def parse_destination_url(url: str) -> ParseResult:
    """Parse a destination URL into a structured ParseResult."""
    return urlparse(url)


def resolve_destination_ips(hostname: str, port: int) -> list[IPAddress]:
    """Resolve all IPs for a hostname/port pair."""
    addr_infos = socket.getaddrinfo(hostname, port, proto=socket.IPPROTO_TCP)
    return [ipaddress.ip_address(sockaddr[0]) for *_prefix, sockaddr in addr_infos]


async def resolve_destination_ips_async(hostname: str, port: int) -> list[IPAddress]:
    """Resolve all IPs without blocking the event loop."""
    return await asyncio.to_thread(resolve_destination_ips, hostname, port)


def find_forbidden_ip(ips: list[IPAddress]) -> IPAddress | None:
    """Return the first private/loopback/link-local/reserved IP, if any."""
    for ip in ips:
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return ip
    return None
