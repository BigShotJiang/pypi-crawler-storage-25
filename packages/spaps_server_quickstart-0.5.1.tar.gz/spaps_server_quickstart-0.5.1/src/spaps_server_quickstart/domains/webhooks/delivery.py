"""Async webhook delivery with exponential backoff retry.

Delivery is in-process async (no Celery). Uses asyncio.create_task
for fire-and-forget delivery after event creation.

Zero FastAPI imports -- pure async delivery logic.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import UTC, datetime
from typing import Any

import httpx

from .destination_security import (
    find_forbidden_ip,
    is_non_production_environment,
    parse_destination_url,
    resolve_destination_ips_async,
)
from .signing import build_signature_header

logger = logging.getLogger(__name__)


# Default retry configuration (matches Node.js webhookService.ts)
DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_INITIAL_DELAY_MS = 1000
DEFAULT_MAX_DELAY_MS = 10000
_RESERVED_DELIVERY_HEADER_NAMES = frozenset({
    "content-type",
    "x-webhook-id",
    "x-spaps-signature",
    "x-webhook-timestamp",
})


def _blocked_attempt(error_message: str, *, attempt: int = 1) -> dict[str, Any]:
    return {
        "attempt": attempt,
        "response_status": None,
        "response_body": None,
        "error_message": error_message,
        "delivered_at": None,
    }


async def _preflight_delivery_error(webhook_url: str) -> str | None:
    """Return an error string when the destination is blocked, else None."""
    parsed_url = parse_destination_url(webhook_url)
    if parsed_url.scheme != "https":
        return "Blocked: webhook URL must use https:// in production"

    hostname = parsed_url.hostname
    if not hostname:
        return "Blocked: webhook URL must have a valid hostname"

    try:
        ips = await resolve_destination_ips_async(hostname, parsed_url.port or 443)
    except OSError:
        return f"Cannot resolve hostname: {hostname}"

    if not ips:
        return f"Cannot resolve hostname: {hostname}"

    blocked_ip = find_forbidden_ip(ips)
    if blocked_ip is not None:
        logger.error(
            "SSRF blocked: webhook URL %s resolves to private IP %s",
            webhook_url, blocked_ip,
        )
        return f"Blocked: resolves to private IP {blocked_ip}"

    return None


def _build_delivery_envelope(
    *,
    event_id: str,
    event_type: str,
    schema_version: int,
    application_id: str,
    created_at: str,
    data: dict[str, Any],
) -> dict[str, Any]:
    """Build the webhook delivery envelope.

    Format:
        { id, type, schema_version, application_id, created_at, data }
    """
    return {
        "id": event_id,
        "type": event_type,
        "schema_version": schema_version,
        "application_id": application_id,
        "created_at": created_at,
        "data": data,
    }


def _build_delivery_headers(
    *,
    event_id: str,
    signature_header: str,
    timestamp_iso: str,
    custom_headers: dict[str, Any] | None = None,
) -> dict[str, str]:
    """Build the headers for a webhook delivery.

    Standard headers:
        - Content-Type: application/json
        - X-Webhook-Id: <event_id>
        - X-SPAPS-Signature: t=...,v1=..
        - X-Webhook-Timestamp: <ISO>

    Plus any custom headers from the webhook configuration, except
    reserved SPAPS delivery headers.
    """
    headers: dict[str, str] = {
        "Content-Type": "application/json",
        "X-Webhook-Id": event_id,
        "X-SPAPS-Signature": signature_header,
        "X-Webhook-Timestamp": timestamp_iso,
    }

    if custom_headers:
        for name, value in custom_headers.items():
            header_name = str(name).strip()
            if (
                not header_name
                or header_name.lower() in _RESERVED_DELIVERY_HEADER_NAMES
            ):
                continue
            headers[header_name] = str(value)

    return headers


def _calculate_delay_ms(
    attempt: int,
    initial_delay_ms: int = DEFAULT_INITIAL_DELAY_MS,
    max_delay_ms: int = DEFAULT_MAX_DELAY_MS,
) -> int:
    """Calculate exponential backoff delay for a retry attempt.

    Attempt 1 (first retry): initial_delay_ms
    Attempt 2 (second retry): initial_delay_ms * 2
    Capped at max_delay_ms.
    """
    delay = initial_delay_ms * (2 ** (attempt - 1))
    return min(delay, max_delay_ms)


def _should_retry(status_code: int | None) -> bool:
    """Determine if a delivery should be retried based on response status.

    Only 5xx responses and network errors (status_code=None) are retried.
    4xx responses are NOT retried.
    """
    if status_code is None:
        # Network error
        return True
    return status_code >= 500


async def deliver_webhook(
    *,
    webhook_url: str,
    webhook_secret: str,
    event_id: str,
    event_type: str,
    schema_version: int,
    application_id: str,
    created_at: str,
    data: dict[str, Any],
    custom_headers: dict[str, Any] | None = None,
    max_attempts: int = DEFAULT_MAX_ATTEMPTS,
    initial_delay_ms: int = DEFAULT_INITIAL_DELAY_MS,
    max_delay_ms: int = DEFAULT_MAX_DELAY_MS,
    environment: str = "production",
) -> list[dict[str, Any]]:
    """Deliver a webhook event to a registered URL with retry logic.

    Builds the delivery envelope, signs it with HMAC-SHA256, and sends
    it via HTTP POST. Retries on 5xx and network errors with exponential
    backoff. Does NOT retry on 4xx responses.

    In non-production environments, delivery is skipped and a synthetic
    success result is returned.

    Args:
        webhook_url: The destination URL.
        webhook_secret: The HMAC secret for signing.
        event_id: The webhook event ID.
        event_type: The event type string.
        schema_version: The schema version number.
        application_id: The application ID.
        created_at: ISO timestamp of event creation.
        data: The event payload data.
        custom_headers: Optional custom headers from webhook config.
        max_attempts: Maximum delivery attempts (default 3).
        initial_delay_ms: Initial retry delay in ms (default 1000).
        max_delay_ms: Maximum retry delay in ms (default 10000).
        environment: Runtime environment (default "production").

    Returns:
        List of delivery attempt results, each containing:
        - attempt: int
        - response_status: int | None
        - response_body: str | None
        - error_message: str | None
        - delivered_at: str | None
    """
    if is_non_production_environment(environment):
        logger.info(
            "webhook_delivery_skipped env=%s url=%s", environment, webhook_url,
        )
        return [{
            "attempt": 1,
            "response_status": 202,
            "response_body": "skipped in non-production",
            "error_message": None,
            "delivered_at": datetime.now(UTC).isoformat(),
            "skipped": True,
        }]

    envelope = _build_delivery_envelope(
        event_id=event_id,
        event_type=event_type,
        schema_version=schema_version,
        application_id=application_id,
        created_at=created_at,
        data=data,
    )

    body_json = json.dumps(envelope)
    attempts: list[dict[str, Any]] = []

    for attempt_num in range(1, max_attempts + 1):
        timestamp = int(time.time())
        timestamp_iso = datetime.now(UTC).isoformat()

        signature_header = build_signature_header(
            timestamp=timestamp,
            body=body_json,
            secret=webhook_secret,
        )

        headers = _build_delivery_headers(
            event_id=event_id,
            signature_header=signature_header,
            timestamp_iso=timestamp_iso,
            custom_headers=custom_headers,
        )

        attempt_result: dict[str, Any] = {
            "attempt": attempt_num,
            "response_status": None,
            "response_body": None,
            "error_message": None,
            "delivered_at": None,
        }

        # TM-007: DNS may change after registration or a prior retry. Re-check
        # immediately before every outbound POST and fail closed.
        preflight_error = await _preflight_delivery_error(webhook_url)
        if preflight_error is not None:
            attempts.append(_blocked_attempt(preflight_error, attempt=attempt_num))
            return attempts

        try:
            async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
                response = await client.post(
                    webhook_url,
                    content=body_json,
                    headers=headers,
                )

                attempt_result["response_status"] = response.status_code
                attempt_result["response_body"] = response.text[:2000]
                attempt_result["delivered_at"] = timestamp_iso

                if response.status_code < 400:
                    # Success
                    logger.info(
                        "Webhook delivered successfully",
                        extra={
                            "url": webhook_url,
                            "event_type": event_type,
                            "attempt": attempt_num,
                            "status": response.status_code,
                        },
                    )
                    attempts.append(attempt_result)
                    return attempts

                if not _should_retry(response.status_code):
                    # 4xx -- do not retry
                    attempt_result["error_message"] = (
                        f"Client error: {response.status_code}"
                    )
                    logger.warning(
                        "Webhook delivery got client error (not retrying)",
                        extra={
                            "url": webhook_url,
                            "event_type": event_type,
                            "status": response.status_code,
                        },
                    )
                    attempts.append(attempt_result)
                    return attempts

                # 5xx -- will retry
                attempt_result["error_message"] = (
                    f"Server error: {response.status_code}"
                )

        except Exception as exc:
            attempt_result["error_message"] = f"Network error: {exc!s}"
            logger.warning(
                "Webhook delivery network error",
                extra={
                    "url": webhook_url,
                    "event_type": event_type,
                    "attempt": attempt_num,
                    "error": str(exc),
                },
            )

        attempts.append(attempt_result)

        # Wait before retry (if not last attempt)
        if attempt_num < max_attempts:
            delay_ms = _calculate_delay_ms(
                attempt_num,
                initial_delay_ms=initial_delay_ms,
                max_delay_ms=max_delay_ms,
            )
            await asyncio.sleep(delay_ms / 1000.0)

    logger.error(
        "Webhook delivery permanently failed after %d attempts",
        max_attempts,
        extra={
            "url": webhook_url,
            "event_type": event_type,
        },
    )

    return attempts
