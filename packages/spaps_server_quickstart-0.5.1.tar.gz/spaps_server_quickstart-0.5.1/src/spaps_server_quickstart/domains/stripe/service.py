"""Business logic for the Stripe domain.

Coordinates between the Stripe API (mocked in tests), the local
repository, and returns domain-friendly dicts.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any, Callable
from uuid import UUID

import stripe
from sqlalchemy.ext.asyncio import AsyncSession

from ..billing_accounts.resolver import resolve_stripe_billing_context
from . import repository as repo
from .errors import (
    CheckoutSessionError,
    PaymentNotFoundError,
    PortalSessionError,
    PriceNotFoundError,
    ProductNotFoundError,
    SessionNotFoundError,
    StripeApiError,
    SubscriptionError,
    SubscriptionNotFoundError,
)

logger = logging.getLogger(__name__)


def _build_stripe_client(secret_key: str) -> stripe.StripeClient:
    """Build an isolated Stripe client for a single billing context."""
    return stripe.StripeClient(secret_key)


async def _resolve_checkout_billing_context(
    db: AsyncSession,
    *,
    application_id: UUID,
):
    """Resolve billing context while tolerating mock DB handles in isolated tests."""
    if isinstance(db, AsyncSession):
        return await resolve_stripe_billing_context(
            db,
            application_id=application_id,
        )

    return await resolve_stripe_billing_context(
        db,
        application=SimpleNamespace(
            id=application_id,
            billing_account_id=None,
        ),
    )


async def _run_stripe_call(func, /, *args: Any, **kwargs: Any) -> Any:
    """Run Stripe's synchronous SDK calls off the event loop."""
    return await asyncio.to_thread(func, *args, **kwargs)


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------


async def list_products(
    db: AsyncSession,
    *,
    application_id: UUID,
    category: str | None = None,
    active_only: bool = False,
    limit: int = 100,
) -> dict[str, Any]:
    products = await repo.list_products(
        db,
        application_id,
        category=category,
        active_only=active_only,
        limit=limit,
    )
    return {
        "products": [_product_to_dict(p) for p in products],
        "total": len(products),
    }


async def get_product(
    db: AsyncSession,
    *,
    stripe_product_id: str,
    application_id: UUID | None = None,
) -> dict[str, Any]:
    product = await repo.get_product(db, stripe_product_id)
    if product is None:
        raise ProductNotFoundError()
    # TM-005: Verify ownership
    if application_id is not None and product.application_id != application_id:
        raise ProductNotFoundError()
    prices = await repo.list_prices_for_product(db, stripe_product_id)
    d = _product_to_dict(product)
    d["prices"] = [_price_to_dict(p) for p in prices]
    return d


async def create_product(
    db: AsyncSession,
    *,
    application_id: UUID,
    application_slug: str,
    name: str,
    description: str | None = None,
    category: str = "general",
    images: list[str] | None = None,
    metadata: dict[str, str] | None = None,
    active: bool = True,
) -> dict[str, Any]:
    """Create product via Stripe API then persist locally."""
    try:
        stripe_product = await _run_stripe_call(
            stripe.Product.create,
            name=name,
            description=description or "",
            active=active,
            images=images or [],
            metadata={
                **(metadata or {}),
                "app_id": str(application_id),
                "app_slug": application_slug,
                "category": category,
            },
        )
    except stripe.StripeError as e:
        raise StripeApiError(str(e), stripe_code=getattr(e, "code", None))

    product = await repo.create_product(
        db,
        stripe_product_id=stripe_product.id,
        application_id=application_id,
        name=name,
        description=description,
        active=active,
        images=images,
        metadata={
            **(metadata or {}),
            "app_id": str(application_id),
            "app_slug": application_slug,
            "category": category,
        },
    )
    return _product_to_dict(product)


async def update_product(
    db: AsyncSession,
    *,
    stripe_product_id: str,
    application_id: UUID | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    # TM-005: Verify ownership before update
    if application_id is not None:
        product = await repo.get_product(db, stripe_product_id)
        if product is not None and product.application_id != application_id:
            raise ProductNotFoundError()

    try:
        update_params: dict[str, Any] = {}
        for k in ("name", "description", "active", "images", "metadata"):
            if k in kwargs and kwargs[k] is not None:
                update_params[k] = kwargs[k]
        if update_params:
            await _run_stripe_call(
                stripe.Product.modify,
                stripe_product_id,
                **update_params,
            )
    except stripe.StripeError as e:
        raise StripeApiError(str(e), stripe_code=getattr(e, "code", None))

    product = await repo.update_product(db, stripe_product_id, **kwargs)
    if product is None:
        raise ProductNotFoundError()
    return _product_to_dict(product)


async def archive_product(
    db: AsyncSession,
    *,
    stripe_product_id: str,
    application_id: UUID | None = None,
) -> dict[str, Any]:
    # TM-005: Verify ownership before archive
    if application_id is not None:
        product = await repo.get_product(db, stripe_product_id)
        if product is not None and product.application_id != application_id:
            raise ProductNotFoundError()

    try:
        await _run_stripe_call(
            stripe.Product.modify,
            stripe_product_id,
            active=False,
        )
    except stripe.StripeError as e:
        raise StripeApiError(str(e), stripe_code=getattr(e, "code", None))

    product = await repo.archive_product(db, stripe_product_id)
    if product is None:
        raise ProductNotFoundError()
    return {"id": product.stripe_product_id, "archived": True, "active": False}


async def sync_products(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> dict[str, Any]:
    """Pull products from Stripe and upsert locally."""
    try:
        stripe_products = await _run_stripe_call(stripe.Product.list, limit=100)
    except stripe.StripeError as e:
        raise StripeApiError(str(e), stripe_code=getattr(e, "code", None))

    synced = 0
    for sp in stripe_products.get("data", []):
        existing = await repo.get_product(db, sp["id"])
        if existing:
            await repo.update_product(
                db,
                sp["id"],
                name=sp.get("name", ""),
                description=sp.get("description"),
                active=sp.get("active", True),
            )
        else:
            await repo.create_product(
                db,
                stripe_product_id=sp["id"],
                application_id=application_id,
                name=sp.get("name", ""),
                description=sp.get("description"),
                active=sp.get("active", True),
                metadata=sp.get("metadata"),
            )
        synced += 1

    return {"synced_count": synced, "message": f"Successfully synced {synced} products from Stripe"}


async def create_product_with_price(
    db: AsyncSession,
    *,
    application_id: UUID,
    application_slug: str,
    product_data: dict[str, Any],
    price_data: dict[str, Any],
) -> dict[str, Any]:
    product = await create_product(
        db,
        application_id=application_id,
        application_slug=application_slug,
        name=product_data["name"],
        description=product_data.get("description"),
        category=product_data.get("category", "general"),
        images=product_data.get("images"),
        metadata=product_data.get("metadata"),
        active=product_data.get("active", True),
    )

    price = await create_price(
        db,
        stripe_product_id=product["id"],
        unit_amount=price_data["amount"],
        currency=price_data["currency"],
        interval=price_data.get("interval"),
        interval_count=price_data.get("interval_count"),
        recurring=price_data.get("type") == "subscription",
        nickname=price_data.get("nickname"),
        metadata=price_data.get("metadata"),
    )

    return {"product": product, "price": price}


# ---------------------------------------------------------------------------
# Prices
# ---------------------------------------------------------------------------


async def create_price(
    db: AsyncSession,
    *,
    stripe_product_id: str,
    unit_amount: int,
    currency: str,
    interval: str | None = None,
    interval_count: int | None = None,
    recurring: bool = False,
    nickname: str | None = None,
    metadata: dict[str, Any] | None = None,
    active: bool = True,
) -> dict[str, Any]:
    try:
        params: dict[str, Any] = {
            "product": stripe_product_id,
            "unit_amount": unit_amount,
            "currency": currency,
        }
        if recurring and interval:
            params["recurring"] = {
                "interval": interval,
                "interval_count": interval_count or 1,
            }
        if nickname:
            params["nickname"] = nickname
        if metadata:
            params["metadata"] = metadata

        stripe_price = await _run_stripe_call(stripe.Price.create, **params)
    except stripe.StripeError as e:
        raise StripeApiError(str(e), stripe_code=getattr(e, "code", None))

    recurring_data = None
    if recurring and interval:
        recurring_data = {"interval": interval, "interval_count": interval_count or 1}

    price = await repo.create_price(
        db,
        stripe_price_id=stripe_price.id,
        stripe_product_id=stripe_product_id,
        currency=currency,
        unit_amount=unit_amount,
        type_="recurring" if recurring else "one_time",
        nickname=nickname,
        recurring=recurring_data,
        active=active,
        metadata=metadata,
    )
    return _price_to_dict(price)


async def deactivate_price(
    db: AsyncSession,
    *,
    stripe_price_id: str,
    application_id: UUID | None = None,
) -> dict[str, Any]:
    # TM-005: Verify price belongs to a product owned by this application
    if application_id is not None:
        price = await repo.get_price(db, stripe_price_id)
        if price is not None:
            product = await repo.get_product(db, price.stripe_product_id)
            if product is not None and product.application_id != application_id:
                raise PriceNotFoundError()

    try:
        await _run_stripe_call(
            stripe.Price.modify,
            stripe_price_id,
            active=False,
        )
    except stripe.StripeError as e:
        raise StripeApiError(str(e), stripe_code=getattr(e, "code", None))

    price = await repo.deactivate_price(db, stripe_price_id)
    if price is None:
        raise PriceNotFoundError()
    return {"id": price.stripe_price_id, "archived": True, "active": False}


async def set_default_price(
    db: AsyncSession,
    *,
    stripe_product_id: str,
    stripe_price_id: str,
) -> dict[str, Any]:
    try:
        await _run_stripe_call(
            stripe.Product.modify,
            stripe_product_id,
            default_price=stripe_price_id,
        )
    except stripe.StripeError as e:
        raise StripeApiError(str(e), stripe_code=getattr(e, "code", None))

    product = await repo.get_product(db, stripe_product_id)
    if product is None:
        raise ProductNotFoundError()
    return _product_to_dict(product)


async def create_price_and_set_default(
    db: AsyncSession,
    *,
    stripe_product_id: str,
    unit_amount: int,
    currency: str,
    interval: str | None = None,
    interval_count: int | None = None,
    recurring: bool = False,
    nickname: str | None = None,
    metadata: dict[str, Any] | None = None,
    deactivate_previous: bool = False,
) -> dict[str, Any]:
    price = await create_price(
        db,
        stripe_product_id=stripe_product_id,
        unit_amount=unit_amount,
        currency=currency,
        interval=interval,
        interval_count=interval_count,
        recurring=recurring,
        nickname=nickname,
        metadata=metadata,
    )

    await set_default_price(
        db,
        stripe_product_id=stripe_product_id,
        stripe_price_id=price["id"],
    )

    return {"price": price, "product_id": stripe_product_id}


# ---------------------------------------------------------------------------
# Checkout Sessions
# ---------------------------------------------------------------------------


async def _build_checkout_line_items(
    db: AsyncSession,
    *,
    application_id: UUID,
    line_items: list[dict[str, Any]],
    error_factory: Callable[[str], Exception] = CheckoutSessionError,
) -> list[dict[str, Any]]:
    """Return Stripe line items after enforcing app-owned server prices."""
    stripe_line_items: list[dict[str, Any]] = []
    for item in line_items:
        if item.get("price_data") is not None:
            raise error_factory(
                "inline price_data is not allowed; use a server-managed price_id"
            )

        price_id = item.get("price_id")
        if not price_id:
            raise error_factory("price_id is required")

        price = await repo.get_price(db, price_id)
        if price is None or not getattr(price, "active", True):
            raise PriceNotFoundError()

        product = await repo.get_product(db, price.stripe_product_id)
        if (
            product is None
            or product.application_id != application_id
            or not getattr(product, "active", True)
        ):
            raise PriceNotFoundError()

        stripe_line_items.append(
            {
                "price": price_id,
                "quantity": item.get("quantity", 1),
            }
        )

    return stripe_line_items


async def create_checkout_session(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    mode: str = "payment",
    line_items: list[dict[str, Any]],
    success_url: str,
    cancel_url: str,
    metadata: dict[str, str] | None = None,
    customer_email: str | None = None,
) -> dict[str, Any]:
    stripe_line_items = await _build_checkout_line_items(
        db,
        application_id=application_id,
        line_items=line_items,
    )
    billing_context = await _resolve_checkout_billing_context(
        db,
        application_id=application_id,
    )
    stripe_client = _build_stripe_client(billing_context.stripe_secret_key)
    try:
        stripe_session = await _run_stripe_call(
            stripe_client.checkout.sessions.create,
            {
                "mode": mode,
                "line_items": stripe_line_items,
                "success_url": success_url,
                "cancel_url": cancel_url,
                "metadata": {
                    **(metadata or {}),
                    "app_id": str(application_id),
                    "user_id": str(user_id),
                },
                **(
                    {"customer_email": customer_email}
                    if customer_email
                    else {}
                ),
            },
        )
    except stripe.StripeError as e:
        raise CheckoutSessionError(str(e))

    session = await repo.create_checkout_session(
        db,
        session_id=stripe_session.id,
        application_id=application_id,
        user_id=user_id,
        customer_id=stripe_session.get("customer"),
        status=stripe_session.get("status", "open"),
        mode=mode,
        success_url=success_url,
        cancel_url=cancel_url,
        amount_total=stripe_session.get("amount_total"),
        currency=stripe_session.get("currency"),
        payment_intent_id=stripe_session.get("payment_intent"),
        subscription_id=stripe_session.get("subscription"),
        metadata={
            **(metadata or {}),
            "app_id": str(application_id),
            "user_id": str(user_id),
        },
        customer_email=customer_email,
    )

    return {
        "id": session.session_id,
        "status": session.status,
        "url": stripe_session.get("url"),
        "payment_status": session.payment_status,
        "amount_total": session.amount_total,
        "currency": session.currency,
        "payment_intent": stripe_session.get("payment_intent"),
        "subscription": stripe_session.get("subscription"),
        "client_reference_id": stripe_session.get("client_reference_id"),
        "metadata": session.metadata_,
    }


async def get_checkout_session(
    db: AsyncSession,
    *,
    session_id: str,
    application_id: UUID | None = None,
    user_id: UUID | None = None,
) -> dict[str, Any]:
    session = await repo.get_checkout_session(db, session_id)
    if session is None:
        raise SessionNotFoundError()
    # TM-003: Verify caller owns the session
    if application_id is not None and session.application_id != application_id:
        raise SessionNotFoundError()
    if user_id is not None and session.user_id is not None and session.user_id != user_id:
        raise SessionNotFoundError()
    return _session_to_dict(session)


async def list_checkout_sessions(
    db: AsyncSession,
    *,
    user_id: UUID,
    application_id: UUID,
    limit: int = 10,
) -> dict[str, Any]:
    sessions = await repo.list_checkout_sessions(
        db, user_id=user_id, application_id=application_id, limit=limit
    )
    return {
        "sessions": [_session_to_dict(s) for s in sessions],
        "has_more": len(sessions) >= limit,
    }


async def expire_checkout_session(
    db: AsyncSession,
    *,
    session_id: str,
    application_id: UUID | None = None,
    user_id: UUID | None = None,
) -> dict[str, Any]:
    # TM-003: Verify ownership before expiring
    session = await repo.get_checkout_session(db, session_id)
    if session is None:
        raise SessionNotFoundError()
    if application_id is not None and session.application_id != application_id:
        raise SessionNotFoundError()
    if user_id is not None and session.user_id is not None and session.user_id != user_id:
        raise SessionNotFoundError()

    try:
        await _run_stripe_call(
            stripe.checkout.Session.expire,
            session_id,
        )
    except stripe.StripeError as e:
        raise CheckoutSessionError(str(e))

    session = await repo.update_checkout_session_status(
        db, session_id, "expired", expired_at=datetime.now(UTC)
    )
    if session is None:
        raise SessionNotFoundError()
    return {"id": session.session_id, "status": "expired", "expired": True}


# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------


async def create_subscription(
    db: AsyncSession,
    *,
    user_id: UUID,
    customer_id: str,
    price_id: str,
    application_id: UUID | None = None,
    metadata: dict[str, str] | None = None,
    trial_period_days: int | None = None,
) -> dict[str, Any]:
    # TM-002: Store application_id in subscriptions table for full multi-tenant isolation.
    try:
        params: dict[str, Any] = {
            "customer": customer_id,
            "items": [{"price": price_id}],
            "payment_behavior": "default_incomplete",
            "expand": ["latest_invoice.payment_intent"],
        }
        if metadata:
            params["metadata"] = metadata
        if trial_period_days:
            params["trial_period_days"] = trial_period_days

        stripe_sub = await _run_stripe_call(stripe.Subscription.create, **params)
    except stripe.StripeError as e:
        raise SubscriptionError(str(e))

    sub = await repo.create_subscription(
        db,
        user_id=user_id,
        application_id=application_id,
        stripe_customer_id=customer_id,
        stripe_subscription_id=stripe_sub.id,
        price_id=price_id,
        status=stripe_sub.get("status", "active"),
        metadata=metadata,
    )
    return _subscription_to_dict(sub, stripe_sub)


async def get_subscription(
    db: AsyncSession,
    *,
    subscription_id: str,
    user_id: UUID | None = None,
    application_id: UUID | None = None,
) -> dict[str, Any]:
    # TM-002: REQUIRE local DB record scoped by application_id before querying Stripe.
    # This prevents cross-user/cross-tenant billing data exposure.
    if application_id is not None:
        local_sub = await repo.get_subscription_by_stripe_id_and_app(
            db,
            stripe_subscription_id=subscription_id,
            application_id=application_id,
        )
    else:
        local_sub = await repo.get_subscription_by_stripe_id(db, subscription_id)

    if local_sub is None:
        raise SubscriptionNotFoundError("Subscription not found in local database")

    # TM-002: Verify user ownership if user_id is provided
    if user_id is not None and local_sub.user_id != user_id:
        raise SubscriptionNotFoundError("Subscription not found")

    try:
        stripe_sub = await _run_stripe_call(
            stripe.Subscription.retrieve,
            subscription_id,
            expand=["customer", "default_payment_method", "latest_invoice"],
        )
    except stripe.StripeError as e:
        raise SubscriptionNotFoundError(str(e))

    return {
        "id": stripe_sub.id,
        "status": stripe_sub.get("status"),
        "current_period_start": stripe_sub.get("current_period_start"),
        "current_period_end": stripe_sub.get("current_period_end"),
        "cancel_at_period_end": stripe_sub.get("cancel_at_period_end", False),
        "canceled_at": stripe_sub.get("canceled_at"),
        "items": _format_sub_items(stripe_sub),
    }


async def list_subscriptions(
    db: AsyncSession,
    *,
    user_id: UUID,
    application_id: UUID | None = None,
    status: str | None = None,
    limit: int = 10,
) -> list[dict[str, Any]]:
    # TM-002: list_subscriptions queries local DB only with application_id filtering.
    # This prevents exposure of other users' subscriptions and cross-app data leakage.
    subs = await repo.list_subscriptions(
        db,
        user_id=user_id,
        application_id=application_id,
        status=status,
        limit=limit,
    )
    return [
        {
            "id": s.stripe_subscription_id or str(s.id),
            "status": s.status,
            "price_id": s.price_id,
            "current_period_start": s.current_period_start.isoformat() if s.current_period_start else None,
            "current_period_end": s.current_period_end.isoformat() if s.current_period_end else None,
            "cancel_at_period_end": s.cancel_at is not None,
            "canceled_at": s.canceled_at.isoformat() if s.canceled_at else None,
        }
        for s in subs
    ]


async def cancel_subscription(
    db: AsyncSession,
    *,
    subscription_id: str,
    immediately: bool = False,
    user_id: UUID | None = None,
    application_id: UUID | None = None,
) -> dict[str, Any]:
    # TM-002: REQUIRE local DB record scoped by application_id before canceling via Stripe.
    # This prevents unauthorized cancellation of other users' subscriptions.
    if application_id is not None:
        local_sub = await repo.get_subscription_by_stripe_id_and_app(
            db,
            stripe_subscription_id=subscription_id,
            application_id=application_id,
        )
    else:
        local_sub = await repo.get_subscription_by_stripe_id(db, subscription_id)

    if local_sub is None:
        raise SubscriptionNotFoundError("Subscription not found in local database")

    # TM-002: Verify user ownership if user_id is provided
    if user_id is not None and local_sub.user_id != user_id:
        raise SubscriptionNotFoundError("Subscription not found")

    try:
        if immediately:
            stripe_sub = await _run_stripe_call(
                stripe.Subscription.cancel,
                subscription_id,
            )
        else:
            stripe_sub = await _run_stripe_call(
                stripe.Subscription.modify,
                subscription_id, cancel_at_period_end=True
            )
    except stripe.StripeError as e:
        raise SubscriptionNotFoundError(str(e))

    await repo.update_subscription(
        db,
        subscription_id,
        status=stripe_sub.get("status", "canceled" if immediately else "active"),
        canceled_at=datetime.now(UTC) if immediately else None,
    )

    return {
        "id": stripe_sub.id,
        "status": stripe_sub.get("status"),
        "cancel_at_period_end": stripe_sub.get("cancel_at_period_end", False),
        "canceled_at": stripe_sub.get("canceled_at"),
    }


async def update_subscription_plan(
    db: AsyncSession,
    *,
    subscription_id: str,
    price_id: str,
    user_id: UUID | None = None,
    application_id: UUID | None = None,
) -> dict[str, Any]:
    # TM-002: REQUIRE local DB record scoped by application_id before updating via Stripe.
    # This prevents unauthorized modification of other users' subscriptions.
    if application_id is not None:
        local_sub = await repo.get_subscription_by_stripe_id_and_app(
            db,
            stripe_subscription_id=subscription_id,
            application_id=application_id,
        )
    else:
        local_sub = await repo.get_subscription_by_stripe_id(db, subscription_id)

    if local_sub is None:
        raise SubscriptionNotFoundError("Subscription not found in local database")

    # TM-002: Verify user ownership if user_id is provided
    if user_id is not None and local_sub.user_id != user_id:
        raise SubscriptionNotFoundError("Subscription not found")

    try:
        current = await _run_stripe_call(
            stripe.Subscription.retrieve,
            subscription_id,
        )
        items = current.get("items", {}).get("data", [])
        item_id = items[0]["id"] if items else None

        if item_id:
            stripe_sub = await _run_stripe_call(
                stripe.Subscription.modify,
                subscription_id,
                items=[{"id": item_id, "price": price_id}],
            )
        else:
            stripe_sub = await _run_stripe_call(
                stripe.Subscription.modify,
                subscription_id,
                items=[{"price": price_id}],
            )
    except stripe.StripeError as e:
        raise SubscriptionError(str(e))

    await repo.update_subscription(
        db, subscription_id, price_id=price_id
    )

    return {
        "id": stripe_sub.id,
        "status": stripe_sub.get("status"),
        "items": _format_sub_items(stripe_sub),
    }


# ---------------------------------------------------------------------------
# Payment History
# ---------------------------------------------------------------------------


async def list_payment_history(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    limit: int = 10,
    status: str | None = None,
) -> dict[str, Any]:
    records = await repo.list_payment_history(
        db,
        application_id=application_id,
        user_id=user_id,
        limit=limit,
        status=status,
    )
    return {
        "payments": [_payment_record_to_dict(r) for r in records],
        "has_more": len(records) >= limit,
        "total_count": len(records),
    }


async def get_payment_detail(
    db: AsyncSession,
    *,
    payment_id: UUID,
    application_id: UUID,
    user_id: UUID,
) -> dict[str, Any]:
    record = await repo.get_payment_record(
        db,
        payment_id,
        application_id=application_id,
        user_id=user_id,
    )
    if record is None:
        raise PaymentNotFoundError()
    return {"payment": _payment_record_to_dict(record)}


# ---------------------------------------------------------------------------
# Portal
# ---------------------------------------------------------------------------


async def create_portal_session(
    db: AsyncSession,
    *,
    user_id: UUID,
    application_id: UUID,
    return_url: str,
) -> dict[str, Any]:
    # Resolve the actual Stripe customer id (cus_...) scoped to this application
    customer_id = await repo.get_latest_checkout_customer_id(
        db,
        user_id=user_id,
        application_id=application_id,
    )
    if not customer_id:
        raise SessionNotFoundError("No Stripe customer found for this user")

    billing_context = await resolve_stripe_billing_context(
        db,
        application_id=application_id,
    )
    stripe_client = _build_stripe_client(billing_context.stripe_secret_key)

    try:
        session = await _run_stripe_call(
            stripe_client.billing_portal.sessions.create,
            {
                "customer": customer_id,
                "return_url": return_url,
            },
        )
    except stripe.StripeError as e:
        raise PortalSessionError(str(e))

    expires_at_str: str | None = None
    expires_at_raw = session.get("expires_at") if hasattr(session, "get") else None
    if expires_at_raw is not None:
        expires_at_str = datetime.fromtimestamp(int(expires_at_raw), tz=UTC).isoformat()

    return {
        "url": session.url,
        "session_id": session.id,
        "expires_at": expires_at_str,
    }


# ---------------------------------------------------------------------------
# Super Admin helpers
# ---------------------------------------------------------------------------


async def list_all_products(
    db: AsyncSession,
    *,
    limit: int = 100,
) -> dict[str, Any]:
    products = await repo.list_all_products(db, limit=limit)
    return {
        "products": [_product_to_dict(p) for p in products],
        "total": len(products),
    }


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def _product_to_dict(product) -> dict[str, Any]:
    return {
        "id": product.stripe_product_id,
        "name": product.name,
        "description": product.description,
        "images": product.images,
        "active": product.active,
        "metadata": product.metadata_,
        "created_at": int(product.created_at.timestamp()) if product.created_at else None,
        "application_id": str(product.application_id) if product.application_id else None,
    }


def _price_to_dict(price) -> dict[str, Any]:
    return {
        "id": price.stripe_price_id,
        "product_id": price.stripe_product_id,
        "unit_amount": price.unit_amount,
        "currency": price.currency,
        "type": price.type,
        "recurring": price.recurring,
        "nickname": price.nickname,
        "active": price.active,
    }


def _session_to_dict(session) -> dict[str, Any]:
    return {
        "id": session.session_id,
        "status": session.status,
        "payment_status": session.payment_status,
        "customer_email": session.customer_email,
        "amount_total": session.amount_total,
        "currency": session.currency,
        "success_url": session.success_url,
        "cancel_url": session.cancel_url,
        "payment_intent": getattr(session, "payment_intent", None),
        "subscription": getattr(session, "subscription", None),
        "client_reference_id": getattr(session, "client_reference_id", None),
        "metadata": session.metadata_,
        "is_guest": session.is_guest,
        "expires_at": session.expires_at.isoformat() if session.expires_at else None,
        "created_at": session.created_at.isoformat() if session.created_at else None,
        "application_id": str(session.application_id) if session.application_id else None,
    }


def _subscription_to_dict(sub, stripe_sub=None) -> dict[str, Any]:
    d: dict[str, Any] = {
        "id": sub.stripe_subscription_id or str(sub.id),
        "status": sub.status,
        "price_id": sub.price_id,
    }
    if stripe_sub:
        d["items"] = _format_sub_items(stripe_sub)
    return d


def _format_sub_items(stripe_sub) -> list[dict[str, Any]]:
    items = stripe_sub.get("items", {})
    data = items.get("data", []) if isinstance(items, dict) else []
    return [
        {
            "id": item.get("id"),
            "price": {
                "id": item.get("price", {}).get("id"),
                "product": item.get("price", {}).get("product"),
                "unit_amount": item.get("price", {}).get("unit_amount", 0),
                "currency": item.get("price", {}).get("currency"),
            },
        }
        for item in data
    ]


def _payment_record_to_dict(record) -> dict[str, Any]:
    return {
        "id": str(record.id),
        "amount": record.amount,
        "currency": record.currency,
        "status": record.status,
        "description": record.description,
        "stripe_payment_intent_id": record.stripe_payment_intent_id,
        "created_at": record.created_at.isoformat() if record.created_at else None,
        "metadata": record.metadata_,
    }
