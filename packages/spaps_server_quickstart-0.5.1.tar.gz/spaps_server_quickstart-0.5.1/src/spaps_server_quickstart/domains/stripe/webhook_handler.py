"""Stripe webhook event handler.

Verifies signatures, stores events, and dispatches to type-specific
handlers. Entitlement-granting events use STUB functions that log
"TODO: wire to entitlements domain".
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

import stripe
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from . import repository as repo
from ..dayrate import service as dayrate_service
from ..entitlements import service as entitlement_service
from ..security import service as security_service
from .errors import WebhookProcessingError, WebhookSignatureError

logger = logging.getLogger(__name__)


def _trusted_uuid(value: Any) -> UUID | None:
    return value if isinstance(value, UUID) else None


def _trusted_str(value: Any) -> str | None:
    return value if isinstance(value, str) else None


def _timestamp_to_datetime(value: Any) -> datetime | None:
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=UTC)
    return None


def _metadata_with_trusted_context(
    metadata: dict[str, Any] | None,
    *,
    application_id: UUID | None,
    user_id: UUID | None = None,
) -> dict[str, Any]:
    trusted_metadata = dict(metadata or {})
    if application_id is not None:
        trusted_metadata["app_id"] = str(application_id)
    if user_id is not None:
        trusted_metadata["user_id"] = str(user_id)
    return trusted_metadata


def _checkout_payload_with_trusted_context(
    data: dict[str, Any],
    *,
    application_id: UUID | None,
    user_id: UUID | None,
    customer_email: str | None,
) -> dict[str, Any]:
    trusted_data = dict(data)
    trusted_data["metadata"] = _metadata_with_trusted_context(
        data.get("metadata"),
        application_id=application_id,
        user_id=user_id,
    )
    if customer_email and not trusted_data.get("customer_email"):
        trusted_data["customer_email"] = customer_email
    return trusted_data


def _subscription_payload_with_trusted_context(
    data: dict[str, Any],
    *,
    application_id: UUID | None,
    user_id: UUID | None,
) -> dict[str, Any]:
    trusted_data = dict(data)
    trusted_data["metadata"] = _metadata_with_trusted_context(
        data.get("metadata"),
        application_id=application_id,
        user_id=user_id,
    )
    return trusted_data


async def _process_affiliate_commissions(
    db: AsyncSession,
    *,
    payer_entity_type: str,
    payer_entity_id: str | None,
    payment_amount_cents: int | None,
    payment_event_type: str,
    payment_reference: str | None,
    application_id: str | None,
) -> None:
    """Best-effort affiliate commission processing for Stripe payments."""
    if (
        not payer_entity_id
        or not application_id
        or not payment_reference
        or not payment_amount_cents
        or payment_amount_cents <= 0
    ):
        return

    try:
        from ..affiliate_referrals import service as affiliate_referral_service

        await affiliate_referral_service.process_commissions(
            db,
            payer_entity_type=payer_entity_type,
            payer_entity_id=UUID(payer_entity_id),
            payment_amount_cents=payment_amount_cents,
            payment_event_type=payment_event_type,
            payment_reference=payment_reference,
            application_id=UUID(application_id),
        )
    except Exception:
        logger.exception(
            "Affiliate commission processing failed",
            extra={
                "payment_event_type": payment_event_type,
                "payment_reference": payment_reference,
                "application_id": application_id,
            },
        )


def verify_webhook_signature(
    payload: bytes,
    signature: str,
    webhook_secret: str,
) -> dict[str, Any]:
    """Verify a Stripe webhook signature and return the parsed event."""
    try:
        event = stripe.Webhook.construct_event(payload, signature, webhook_secret)
        return dict(event)
    except stripe.SignatureVerificationError:
        raise WebhookSignatureError()
    except Exception as exc:
        raise WebhookSignatureError(f"Webhook verification failed: {exc}")


async def handle_webhook_event(
    db: AsyncSession,
    *,
    event: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch a webhook event to the appropriate handler.

    Stores the event, processes by type, and marks it processed on success.
    Returns ``{"received": True}`` on success.
    """
    event_id = event.get("id", "unknown")
    event_type = event.get("type", "unknown")

    logger.info("Processing webhook event %s: %s", event_id, event_type)

    existing_event = await repo.get_webhook_event(db, event_id)
    if existing_event is not None:
        logger.info("Duplicate webhook event ignored: %s", event_id)
        return {"received": True, "duplicate": True}

    stored_event = None
    try:
        stored_event = await repo.store_webhook_event(
            db,
            event_id=event_id,
            event_type=event_type,
            data=event.get("data", {}),
        )
    except IntegrityError:
        await db.rollback()
        logger.info("Duplicate webhook event ignored after insert race: %s", event_id)
        return {"received": True, "duplicate": True}
    except Exception as exc:
        logger.error("Failed to store webhook event %s: %s", event_id, exc)
        raise WebhookProcessingError("Failed to persist webhook event") from exc

    # Dispatch
    data_object = event.get("data", {}).get("object", {})

    handlers = {
        "checkout.session.completed": _handle_checkout_completed,
        "checkout.session.expired": _handle_checkout_expired,
        "payment_intent.succeeded": _handle_payment_intent_succeeded,
        "payment_intent.payment_failed": _handle_payment_intent_failed,
        "customer.subscription.created": _handle_subscription_created,
        "customer.subscription.updated": _handle_subscription_updated,
        "customer.subscription.deleted": _handle_subscription_deleted,
        "invoice.payment_succeeded": _handle_invoice_payment_succeeded,
        "invoice.payment_failed": _handle_invoice_payment_failed,
        "product.created": _handle_product_upsert,
        "product.updated": _handle_product_upsert,
        "price.created": _handle_price_upsert,
        "price.updated": _handle_price_upsert,
    }

    handler = handlers.get(event_type)
    if handler:
        try:
            await handler(db, data_object)
            if stored_event is not None:
                stored_event.processed_at = datetime.now(UTC)
                await db.flush()
        except Exception as exc:
            logger.error("Error processing webhook %s (%s): %s", event_id, event_type, exc)
            raise WebhookProcessingError(f"Failed to process {event_type}") from exc
    else:
        logger.info("Unhandled webhook event type: %s", event_type)
        if stored_event is not None:
            stored_event.processed_at = datetime.now(UTC)
            await db.flush()

    return {"received": True}


# ---------------------------------------------------------------------------
# Event handlers
# ---------------------------------------------------------------------------


async def _handle_checkout_completed(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    session_id = data.get("id")
    payment_intent_id = data.get("payment_intent")
    metadata = data.get("metadata", {}) or {}
    is_dayrate_checkout = str(metadata.get("dayrate_booking", "")).lower() == "true"
    trusted_checkout = None
    trusted_application_id: UUID | None = None
    trusted_application_id_str: str | None = None
    trusted_user_id: UUID | None = None
    trusted_customer_email: str | None = None

    if session_id:
        trusted_checkout = await repo.update_checkout_session_status(
            db,
            session_id,
            "complete",
            completed_at=datetime.now(UTC),
            payment_intent_id=payment_intent_id,
            subscription_id=data.get("subscription"),
            customer_id=data.get("customer"),
            payment_status=data.get("payment_status"),
        )
        if trusted_checkout is None:
            trusted_checkout = await repo.get_checkout_session(db, session_id)

        trusted_application_id = _trusted_uuid(
            getattr(trusted_checkout, "application_id", None)
        )
        trusted_application_id_str = (
            str(trusted_application_id) if trusted_application_id else None
        )
        trusted_user_id = _trusted_uuid(getattr(trusted_checkout, "user_id", None))
        trusted_customer_email = _trusted_str(
            getattr(trusted_checkout, "customer_email", None)
        )

        if is_dayrate_checkout:
            dayrate_result = await dayrate_service.confirm_paid_bookings_for_checkout_session(
                db,
                stripe_session_id=session_id,
                stripe_payment_intent_id=payment_intent_id,
            )

            if dayrate_result["matched"] == 0:
                await security_service.create_alert(
                    db,
                    alert_type="dayrate_checkout_reconciliation_failure",
                    severity="high",
                    application_id=trusted_application_id,
                    elevated_by="stripe_webhook",
                    details={
                        "stripe_session_id": session_id,
                        "stripe_payment_intent_id": payment_intent_id,
                        "application_id": trusted_application_id_str
                        or metadata.get("application_id"),
                        "metadata_application_id": metadata.get("application_id"),
                        "booking_group_id": metadata.get("booking_group_id"),
                        "client_email": metadata.get("client_email"),
                        "slot": metadata.get("slot"),
                        "date": metadata.get("date"),
                    },
                )

    trusted_data = _checkout_payload_with_trusted_context(
        data,
        application_id=trusted_application_id,
        user_id=trusted_user_id,
        customer_email=trusted_customer_email,
    )

    if trusted_application_id is not None:
        line_items = data.get("line_items", {}).get("data") if data.get("line_items") else None
        await entitlement_service.process_stripe_checkout(
            db,
            session=trusted_data,
            line_items=line_items,
            app_id=trusted_application_id,
            trusted_user_id=trusted_user_id,
            trusted_customer_email=trusted_customer_email,
        )

    await _process_affiliate_commissions(
        db,
        payer_entity_type="user",
        payer_entity_id=str(trusted_user_id) if trusted_user_id else None,
        payment_amount_cents=data.get("amount_total"),
        payment_event_type="stripe_onetime",
        payment_reference=data.get("payment_intent") or session_id,
        application_id=str(trusted_application_id) if trusted_application_id else None,
    )


async def _handle_checkout_expired(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    session_id = data.get("id")
    metadata = data.get("metadata", {}) or {}
    is_dayrate_checkout = str(metadata.get("dayrate_booking", "")).lower() == "true"
    if session_id:
        await repo.update_checkout_session_status(
            db, session_id, "expired", expired_at=datetime.now(UTC)
        )
        if is_dayrate_checkout:
            await dayrate_service.expire_pending_bookings_for_checkout_session(
                db,
                stripe_session_id=session_id,
            )
    logger.info("Checkout session expired: %s", session_id)


async def _handle_payment_intent_succeeded(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    pi_id = data.get("id")
    trusted_checkout = (
        await repo.get_checkout_session_by_payment_intent(db, pi_id)
        if pi_id
        else None
    )
    trusted_application_id = _trusted_uuid(getattr(trusted_checkout, "application_id", None))
    trusted_user_id = _trusted_uuid(getattr(trusted_checkout, "user_id", None))
    trusted_metadata = _metadata_with_trusted_context(
        data.get("metadata"),
        application_id=trusted_application_id,
        user_id=trusted_user_id,
    )

    await repo.upsert_payment(
        db,
        payment_intent_id=pi_id or "unknown",
        application_id=trusted_application_id,
        customer_id=data.get("customer"),
        amount=data.get("amount", 0),
        currency=data.get("currency", "usd"),
        status="succeeded",
        metadata=trusted_metadata,
    )
    await _process_affiliate_commissions(
        db,
        payer_entity_type="user",
        payer_entity_id=str(trusted_user_id) if trusted_user_id else None,
        payment_amount_cents=data.get("amount"),
        payment_event_type="stripe_onetime",
        payment_reference=pi_id,
        application_id=str(trusted_application_id) if trusted_application_id else None,
    )
    logger.info("Payment intent succeeded: %s", pi_id)


async def _handle_payment_intent_failed(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    pi_id = data.get("id")
    logger.warning("Payment intent failed: %s", pi_id)


async def _handle_subscription_created(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    sub_id = data.get("id")
    trusted_subscription = (
        await repo.get_subscription_by_stripe_id(db, sub_id)
        if sub_id
        else None
    )
    trusted_application_id = _trusted_uuid(getattr(trusted_subscription, "application_id", None))
    trusted_user_id = _trusted_uuid(getattr(trusted_subscription, "user_id", None))
    if trusted_application_id is not None:
        trusted_data = _subscription_payload_with_trusted_context(
            data,
            application_id=trusted_application_id,
            user_id=trusted_user_id,
        )
        await entitlement_service.process_stripe_subscription(
            db,
            subscription=trusted_data,
            event_type="created",
            app_id=trusted_application_id,
            trusted_user_id=trusted_user_id,
        )


async def _handle_subscription_updated(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    sub_id = data.get("id")
    trusted_subscription = None
    if sub_id:
        update_kwargs: dict[str, Any] = {"status": data.get("status", "active")}
        for key in ("current_period_start", "current_period_end", "cancel_at", "canceled_at"):
            if key in data and data.get(key) is not None:
                update_kwargs[key] = _timestamp_to_datetime(data.get(key))
        trusted_subscription = await repo.update_subscription(
            db,
            sub_id,
            **update_kwargs,
        )
        if trusted_subscription is None:
            trusted_subscription = await repo.get_subscription_by_stripe_id(db, sub_id)
    trusted_application_id = _trusted_uuid(getattr(trusted_subscription, "application_id", None))
    trusted_user_id = _trusted_uuid(getattr(trusted_subscription, "user_id", None))
    if trusted_application_id is not None:
        trusted_data = _subscription_payload_with_trusted_context(
            data,
            application_id=trusted_application_id,
            user_id=trusted_user_id,
        )
        await entitlement_service.process_stripe_subscription(
            db,
            subscription=trusted_data,
            event_type="updated",
            app_id=trusted_application_id,
            trusted_user_id=trusted_user_id,
        )


async def _handle_subscription_deleted(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    sub_id = data.get("id")
    trusted_subscription = None
    if sub_id:
        trusted_subscription = await repo.update_subscription(
            db,
            sub_id,
            status="canceled",
            canceled_at=_timestamp_to_datetime(data.get("canceled_at")) or datetime.now(UTC),
            current_period_end=_timestamp_to_datetime(data.get("current_period_end")),
            cancel_at=_timestamp_to_datetime(data.get("cancel_at")),
        )
        if trusted_subscription is None:
            trusted_subscription = await repo.get_subscription_by_stripe_id(db, sub_id)
    trusted_application_id = _trusted_uuid(getattr(trusted_subscription, "application_id", None))
    trusted_user_id = _trusted_uuid(getattr(trusted_subscription, "user_id", None))
    if trusted_application_id is not None:
        trusted_data = _subscription_payload_with_trusted_context(
            data,
            application_id=trusted_application_id,
            user_id=trusted_user_id,
        )
        await entitlement_service.process_stripe_subscription(
            db,
            subscription=trusted_data,
            event_type="deleted",
            app_id=trusted_application_id,
            trusted_user_id=trusted_user_id,
        )


async def _handle_invoice_payment_succeeded(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    invoice_id = data.get("id")
    subscription_id = data.get("subscription")
    trusted_subscription = (
        await repo.get_subscription_by_stripe_id(db, subscription_id)
        if isinstance(subscription_id, str)
        else None
    )
    trusted_application_id = _trusted_uuid(getattr(trusted_subscription, "application_id", None))
    trusted_user_id = _trusted_uuid(getattr(trusted_subscription, "user_id", None))
    trusted_metadata = _metadata_with_trusted_context(
        data.get("metadata"),
        application_id=trusted_application_id,
        user_id=trusted_user_id,
    )
    await repo.upsert_invoice(
        db,
        invoice_id=invoice_id or "unknown",
        subscription_id=subscription_id,
        customer_id=data.get("customer"),
        amount_paid=data.get("amount_paid"),
        amount_due=data.get("amount_due"),
        currency=data.get("currency", "usd"),
        status="paid",
        metadata=trusted_metadata,
    )
    if trusted_application_id is not None:
        await entitlement_service.process_stripe_invoice(
            db,
            invoice=data,
            app_id=trusted_application_id,
        )

    await _process_affiliate_commissions(
        db,
        payer_entity_type="user",
        payer_entity_id=str(trusted_user_id) if trusted_user_id else None,
        payment_amount_cents=data.get("amount_paid"),
        payment_event_type="stripe_subscription",
        payment_reference=invoice_id,
        application_id=str(trusted_application_id) if trusted_application_id else None,
    )


async def _handle_invoice_payment_failed(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    invoice_id = data.get("id")
    logger.warning("Invoice payment failed: %s", invoice_id)


async def _handle_product_upsert(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    product_id = data.get("id")
    if not product_id:
        return
    existing = await repo.get_product(db, product_id)
    if existing:
        await repo.update_product(
            db,
            product_id,
            name=data.get("name", ""),
            description=data.get("description"),
            active=data.get("active", True),
        )
    else:
        logger.info("Product upsert from webhook skipped (no local record): %s", product_id)


async def _handle_price_upsert(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    price_id = data.get("id")
    if not price_id:
        return
    existing = await repo.get_price(db, price_id)
    if existing:
        existing.active = data.get("active", True)
        existing.unit_amount = data.get("unit_amount")
        await db.flush()
    else:
        logger.info("Price upsert from webhook skipped (no local record): %s", price_id)
