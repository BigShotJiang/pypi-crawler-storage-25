"""Database operations for the Stripe domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import (
    CheckoutSession,
    GuestCheckoutConversion,
    PaymentHistory,
    StripeCustomer,
    StripeInvoice,
    StripePayment,
    StripePrice,
    StripeProduct,
    StripeWebhookEvent,
    Subscription,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------


async def get_product(
    db: AsyncSession, stripe_product_id: str
) -> StripeProduct | None:
    stmt = select(StripeProduct).where(StripeProduct.stripe_product_id == stripe_product_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_products(
    db: AsyncSession,
    application_id: UUID,
    *,
    category: str | None = None,
    active_only: bool = False,
    limit: int = 100,
) -> list[StripeProduct]:
    stmt = (
        select(StripeProduct)
        .where(StripeProduct.application_id == application_id)
        .order_by(StripeProduct.created_at.desc())
        .limit(limit)
    )
    if active_only:
        stmt = stmt.where(StripeProduct.active.is_(True))
    if category:
        stmt = stmt.where(
            StripeProduct.metadata_.op("->>")(  # type: ignore[union-attr]
                "category"
            )
            == category
        )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def list_all_products(
    db: AsyncSession,
    *,
    limit: int = 100,
) -> list[StripeProduct]:
    stmt = select(StripeProduct).order_by(StripeProduct.created_at.desc()).limit(limit)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def create_product(
    db: AsyncSession,
    *,
    stripe_product_id: str,
    application_id: UUID,
    name: str,
    description: str | None = None,
    active: bool = True,
    images: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> StripeProduct:
    product = StripeProduct(
        stripe_product_id=stripe_product_id,
        application_id=application_id,
        name=name,
        description=description,
        active=active,
        images=images,
        metadata_=metadata or {},
    )
    db.add(product)
    await db.flush()
    await db.refresh(product)
    return product


async def update_product(
    db: AsyncSession,
    stripe_product_id: str,
    **kwargs: Any,
) -> StripeProduct | None:
    product = await get_product(db, stripe_product_id)
    if product is None:
        return None
    for key, value in kwargs.items():
        if key == "metadata":
            product.metadata_ = value
        elif hasattr(product, key):
            setattr(product, key, value)
    product.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(product)
    return product


async def archive_product(
    db: AsyncSession, stripe_product_id: str
) -> StripeProduct | None:
    product = await get_product(db, stripe_product_id)
    if product is None:
        return None
    product.active = False
    product.archived_at = datetime.now(UTC)
    product.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(product)
    return product


# ---------------------------------------------------------------------------
# Prices
# ---------------------------------------------------------------------------


async def get_price(db: AsyncSession, stripe_price_id: str) -> StripePrice | None:
    stmt = select(StripePrice).where(StripePrice.stripe_price_id == stripe_price_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_prices_for_product(
    db: AsyncSession, stripe_product_id: str
) -> list[StripePrice]:
    stmt = (
        select(StripePrice)
        .where(StripePrice.stripe_product_id == stripe_product_id)
        .order_by(StripePrice.created_at.desc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def create_price(
    db: AsyncSession,
    *,
    stripe_price_id: str,
    stripe_product_id: str,
    currency: str,
    unit_amount: int | None = None,
    type_: str = "one_time",
    nickname: str | None = None,
    recurring: dict[str, Any] | None = None,
    active: bool = True,
    metadata: dict[str, Any] | None = None,
) -> StripePrice:
    price = StripePrice(
        stripe_price_id=stripe_price_id,
        stripe_product_id=stripe_product_id,
        currency=currency,
        unit_amount=unit_amount,
        type=type_,
        nickname=nickname,
        recurring=recurring,
        active=active,
        metadata_=metadata or {},
    )
    db.add(price)
    await db.flush()
    await db.refresh(price)
    return price


async def deactivate_price(
    db: AsyncSession, stripe_price_id: str
) -> StripePrice | None:
    price = await get_price(db, stripe_price_id)
    if price is None:
        return None
    price.active = False
    price.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(price)
    return price


# ---------------------------------------------------------------------------
# Checkout Sessions
# ---------------------------------------------------------------------------


async def create_checkout_session(
    db: AsyncSession,
    *,
    session_id: str,
    application_id: UUID,
    user_id: UUID | None = None,
    customer_id: str | None = None,
    status: str = "open",
    mode: str = "payment",
    success_url: str | None = None,
    cancel_url: str | None = None,
    amount_total: int | None = None,
    currency: str | None = None,
    payment_intent_id: str | None = None,
    subscription_id: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_guest: bool = False,
    customer_email: str | None = None,
    expires_at: datetime | None = None,
    url: str | None = None,
) -> CheckoutSession:
    session = CheckoutSession(
        session_id=session_id,
        application_id=application_id,
        user_id=user_id,
        customer_id=customer_id,
        status=status,
        mode=mode,
        success_url=success_url,
        cancel_url=cancel_url,
        amount_total=amount_total,
        currency=currency,
        payment_intent_id=payment_intent_id,
        subscription_id=subscription_id,
        metadata_=metadata or {},
        is_guest=is_guest,
        customer_email=customer_email,
        expires_at=expires_at,
    )
    db.add(session)
    await db.flush()
    await db.refresh(session)
    return session


async def get_checkout_session(
    db: AsyncSession, session_id: str
) -> CheckoutSession | None:
    stmt = select(CheckoutSession).where(CheckoutSession.session_id == session_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_checkout_session_by_payment_intent(
    db: AsyncSession, payment_intent_id: str
) -> CheckoutSession | None:
    stmt = select(CheckoutSession).where(
        CheckoutSession.payment_intent_id == payment_intent_id
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_checkout_sessions(
    db: AsyncSession,
    *,
    user_id: UUID | None = None,
    application_id: UUID | None = None,
    limit: int = 10,
) -> list[CheckoutSession]:
    stmt = select(CheckoutSession).order_by(CheckoutSession.created_at.desc()).limit(limit)
    if user_id:
        stmt = stmt.where(CheckoutSession.user_id == user_id)
    if application_id:
        stmt = stmt.where(CheckoutSession.application_id == application_id)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def update_checkout_session_status(
    db: AsyncSession,
    session_id: str,
    status: str,
    **extra: Any,
) -> CheckoutSession | None:
    session = await get_checkout_session(db, session_id)
    if session is None:
        return None
    session.status = status
    for key, value in extra.items():
        if hasattr(session, key):
            setattr(session, key, value)
    session.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(session)
    return session


# ---------------------------------------------------------------------------
# Payments
# ---------------------------------------------------------------------------


async def upsert_payment(
    db: AsyncSession,
    *,
    payment_intent_id: str,
    application_id: UUID | None = None,
    customer_id: str | None = None,
    amount: int,
    currency: str,
    status: str,
    metadata: dict[str, Any] | None = None,
) -> StripePayment:
    existing = await db.get(StripePayment, payment_intent_id)
    if existing:
        existing.status = status
        existing.updated_at = datetime.now(UTC)
        if metadata:
            existing.metadata_ = metadata
        await db.flush()
        await db.refresh(existing)
        return existing
    payment = StripePayment(
        payment_intent_id=payment_intent_id,
        application_id=application_id,
        customer_id=customer_id,
        amount=amount,
        currency=currency,
        status=status,
        metadata_=metadata or {},
    )
    db.add(payment)
    await db.flush()
    await db.refresh(payment)
    return payment


# ---------------------------------------------------------------------------
# Webhook Events
# ---------------------------------------------------------------------------


async def store_webhook_event(
    db: AsyncSession,
    *,
    event_id: str,
    event_type: str,
    data: dict[str, Any],
) -> StripeWebhookEvent:
    event = StripeWebhookEvent(
        event_id=event_id,
        type=event_type,
        data=data,
    )
    db.add(event)
    await db.flush()
    await db.refresh(event)
    return event


async def get_webhook_event(
    db: AsyncSession, event_id: str
) -> StripeWebhookEvent | None:
    return await db.get(StripeWebhookEvent, event_id)


async def mark_webhook_event_processed(
    db: AsyncSession, event_id: str
) -> StripeWebhookEvent | None:
    event = await get_webhook_event(db, event_id)
    if event is None:
        return None

    event.processed_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(event)
    return event


# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------


async def create_subscription(
    db: AsyncSession,
    *,
    user_id: UUID,
    application_id: UUID | None = None,
    stripe_customer_id: str | None = None,
    stripe_subscription_id: str | None = None,
    price_id: str | None = None,
    status: str = "active",
    current_period_start: datetime | None = None,
    current_period_end: datetime | None = None,
    metadata: dict[str, Any] | None = None,
) -> Subscription:
    sub = Subscription(
        user_id=user_id,
        application_id=application_id,
        stripe_customer_id=stripe_customer_id,
        stripe_subscription_id=stripe_subscription_id,
        price_id=price_id,
        status=status,
        current_period_start=current_period_start,
        current_period_end=current_period_end,
        metadata_=metadata or {},
    )
    db.add(sub)
    await db.flush()
    await db.refresh(sub)
    return sub


async def get_subscription_by_stripe_id(
    db: AsyncSession, stripe_subscription_id: str
) -> Subscription | None:
    stmt = select(Subscription).where(
        Subscription.stripe_subscription_id == stripe_subscription_id
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_subscription_by_stripe_id_and_app(
    db: AsyncSession,
    *,
    stripe_subscription_id: str,
    application_id: UUID,
) -> Subscription | None:
    """Get subscription by Stripe ID scoped to application_id.

    TM-002: Required for multi-tenant subscription isolation.
    """
    stmt = select(Subscription).where(
        Subscription.stripe_subscription_id == stripe_subscription_id,
        Subscription.application_id == application_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_subscription(db: AsyncSession, sub_id: UUID) -> Subscription | None:
    return await db.get(Subscription, sub_id)


async def list_subscriptions(
    db: AsyncSession,
    *,
    user_id: UUID | None = None,
    application_id: UUID | None = None,
    status: str | None = None,
    limit: int = 10,
) -> list[Subscription]:
    stmt = select(Subscription).order_by(Subscription.created_at.desc()).limit(limit)
    if user_id:
        stmt = stmt.where(Subscription.user_id == user_id)
    if application_id:
        stmt = stmt.where(Subscription.application_id == application_id)
    if status:
        stmt = stmt.where(Subscription.status == status)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def update_subscription(
    db: AsyncSession,
    stripe_subscription_id: str,
    **kwargs: Any,
) -> Subscription | None:
    sub = await get_subscription_by_stripe_id(db, stripe_subscription_id)
    if sub is None:
        return None
    for key, value in kwargs.items():
        if key == "metadata":
            sub.metadata_ = value
        elif hasattr(sub, key):
            setattr(sub, key, value)
    sub.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(sub)
    return sub


# ---------------------------------------------------------------------------
# Invoices
# ---------------------------------------------------------------------------


async def upsert_invoice(
    db: AsyncSession,
    *,
    invoice_id: str,
    subscription_id: str | None = None,
    customer_id: str | None = None,
    amount_paid: int | None = None,
    amount_due: int | None = None,
    currency: str,
    status: str,
    metadata: dict[str, Any] | None = None,
) -> StripeInvoice:
    existing = await db.get(StripeInvoice, invoice_id)
    if existing:
        existing.status = status
        existing.updated_at = datetime.now(UTC)
        if amount_paid is not None:
            existing.amount_paid = amount_paid
        await db.flush()
        await db.refresh(existing)
        return existing
    invoice = StripeInvoice(
        invoice_id=invoice_id,
        subscription_id=subscription_id,
        customer_id=customer_id,
        amount_paid=amount_paid,
        amount_due=amount_due,
        currency=currency,
        status=status,
        metadata_=metadata or {},
    )
    db.add(invoice)
    await db.flush()
    await db.refresh(invoice)
    return invoice


# ---------------------------------------------------------------------------
# Payment History
# ---------------------------------------------------------------------------


async def list_payment_history(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    limit: int = 10,
    status: str | None = None,
) -> list[PaymentHistory]:
    stmt = (
        select(PaymentHistory)
        .where(
            PaymentHistory.application_id == application_id,
            PaymentHistory.user_id == user_id,
        )
        .order_by(PaymentHistory.created_at.desc())
        .limit(limit)
    )
    if status:
        stmt = stmt.where(PaymentHistory.status == status)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_payment_record(
    db: AsyncSession,
    payment_id: UUID,
    *,
    application_id: UUID,
    user_id: UUID,
) -> PaymentHistory | None:
    stmt = select(PaymentHistory).where(
        PaymentHistory.id == payment_id,
        PaymentHistory.application_id == application_id,
        PaymentHistory.user_id == user_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------


async def get_customer_by_user_id(
    db: AsyncSession, user_id: UUID
) -> StripeCustomer | None:
    stmt = select(StripeCustomer).where(StripeCustomer.user_id == user_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_latest_checkout_customer_id(
    db: AsyncSession,
    *,
    user_id: UUID,
    application_id: UUID | None = None,
) -> str | None:
    """Return the most recent Stripe customer id (``cus_*``) for a user.

    Data is sourced from checkout sessions because ``stripe_customers.id`` is
    an internal UUID primary key, not the Stripe customer identifier.
    """
    stmt = (
        select(CheckoutSession.customer_id)
        .where(
            CheckoutSession.user_id == user_id,
            CheckoutSession.customer_id.is_not(None),
        )
        .order_by(CheckoutSession.created_at.desc())
        .limit(1)
    )
    if application_id is not None:
        stmt = stmt.where(CheckoutSession.application_id == application_id)

    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_customer(
    db: AsyncSession,
    *,
    user_id: UUID,
    application_id: UUID | None = None,
    email: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> StripeCustomer:
    customer = StripeCustomer(
        user_id=user_id,
        application_id=application_id,
        email=email,
        metadata_=metadata or {},
    )
    db.add(customer)
    await db.flush()
    await db.refresh(customer)
    return customer


# ---------------------------------------------------------------------------
# Guest Checkout Conversions
# ---------------------------------------------------------------------------


async def create_guest_conversion(
    db: AsyncSession,
    *,
    session_id: str,
    guest_email: str,
    converted_user_id: UUID,
    converted_at: datetime,
) -> GuestCheckoutConversion:
    conversion = GuestCheckoutConversion(
        session_id=session_id,
        guest_email=guest_email,
        converted_user_id=converted_user_id,
        converted_at=converted_at,
    )
    db.add(conversion)
    await db.flush()
    await db.refresh(conversion)
    return conversion
