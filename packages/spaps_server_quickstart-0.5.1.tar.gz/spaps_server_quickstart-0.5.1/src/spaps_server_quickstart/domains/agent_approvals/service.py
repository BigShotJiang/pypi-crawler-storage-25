"""Business logic for the agent_approvals domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
import secrets
import string
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

import bcrypt
import jwt
from sqlalchemy.ext.asyncio import AsyncSession

from . import repository as repo
from .errors import (
    AgentAlreadyInactiveError,
    AgentInactiveError,
    AgentNameExistsError,
    AgentNotFoundError,
    ApprovalAlreadyResolvedError,
    ApprovalExpiredError,
    ApprovalNotFoundError,
    ApprovalTokenConfigurationError,
    ApproverAlreadyExistsError,
    ApproverNotFoundError,
    InvalidAgentCredentialsError,
    MaxApproversExceededError,
    NotAgentOwnerError,
    NotAuthorizedApproverError,
    ScopeViolationError,
)

logger = logging.getLogger(__name__)

DEFAULT_VERIFICATION_URL_BASE = "https://openclawth.com"
MAX_APPROVERS_PER_AGENT = 20


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _generate_agent_secret() -> str:
    """Generate a cryptographically secure agent secret."""
    random_part = secrets.token_urlsafe(32)
    return f"spaps_agent_{random_part}"


def _generate_verification_code() -> str:
    """Generate a verification code in XXXX-YYYY format."""
    chars = string.ascii_uppercase
    part1 = "".join(secrets.choice(chars) for _ in range(4))
    part2 = "".join(secrets.choice(chars) for _ in range(4))
    return f"{part1}-{part2}"


def _hash_secret(raw_secret: str) -> str:
    """Hash a secret using bcrypt."""
    return bcrypt.hashpw(raw_secret.encode(), bcrypt.gensalt()).decode()


def _verify_secret(raw_secret: str, hashed: str) -> bool:
    """Verify a raw secret against a bcrypt hash."""
    return bcrypt.checkpw(raw_secret.encode(), hashed.encode())


def _check_scope_match(scopes: list[str] | None, action: str) -> bool:
    """Check whether an action matches at least one scope (prefix match).

    Empty or None scopes = unrestricted (any action allowed).
    """
    if not scopes:
        return True
    return any(action.startswith(scope) for scope in scopes)


def _resolve_approval_jwt_secret(settings: Any) -> str:
    """Return a configured JWT secret for approval-token signing."""
    jwt_secret = getattr(settings, "jwt_secret", None)
    if not isinstance(jwt_secret, str) or not jwt_secret.strip():
        raise ApprovalTokenConfigurationError()
    return jwt_secret


def _agent_to_dict(agent: Any, *, include_secret: bool = False) -> dict[str, Any]:
    """Convert an Agent model instance to a serialisable dict."""
    result = {
        "id": str(agent.id),
        "name": agent.name,
        "description": agent.description,
        "application_id": str(agent.application_id),
        "owner_user_id": str(agent.owner_user_id),
        "scopes": agent.scopes or [],
        "is_active": agent.is_active,
        "metadata": agent.metadata_ if hasattr(agent, "metadata_") else {},
        "created_at": agent.created_at.isoformat() if hasattr(agent.created_at, "isoformat") else str(agent.created_at),
        "updated_at": agent.updated_at.isoformat() if hasattr(agent.updated_at, "isoformat") else str(agent.updated_at),
    }
    return result


async def _attribute_agent_referral(
    db: AsyncSession,
    *,
    agent_id: UUID,
    application_id: UUID,
    referral_click_id: str | None = None,
    referral_slug: str | None = None,
) -> None:
    """Best-effort referral attribution for newly registered agents."""
    if not referral_click_id and not referral_slug:
        return

    click_uuid: UUID | None = None
    if referral_click_id:
        try:
            click_uuid = UUID(referral_click_id)
        except ValueError:
            logger.warning(
                "Skipping agent referral attribution due to invalid click UUID",
                extra={"referral_click_id": referral_click_id},
            )
            return

    from ..affiliate_referrals import service as affiliate_referral_service
    from ..affiliate_referrals.errors import (
        AffiliateNotFoundError,
        AlreadyAttributedError,
        ClickExpiredError,
        ClickNotFoundError,
        SelfReferralError,
    )

    try:
        await affiliate_referral_service.attribute_referral(
            db,
            referred_entity_type="agent",
            referred_entity_id=agent_id,
            click_id=click_uuid,
            slug=referral_slug,
            application_id=application_id,
        )
    except (
        AffiliateNotFoundError,
        AlreadyAttributedError,
        ClickExpiredError,
        ClickNotFoundError,
        SelfReferralError,
    ):
        logger.info(
            "Agent referral attribution skipped",
            extra={
                "agent_id": str(agent_id),
                "application_id": str(application_id),
                "has_click_id": bool(click_uuid),
                "has_slug": bool(referral_slug),
            },
        )
    except Exception:
        logger.exception(
            "Unexpected error during agent referral attribution",
            extra={"agent_id": str(agent_id), "application_id": str(application_id)},
        )


def _approval_to_detail_dict(
    approval: Any,
    agent_name: str | None = None,
    *,
    include_sensitive_fields: bool = True,
) -> dict[str, Any]:
    """Convert an AgentApproval to the detail response dict."""
    now = datetime.now(UTC)

    # Lazy expiration: if pending and past expires_at, treat as expired
    status = approval.status
    if status == "pending" and approval.expires_at <= now:
        status = "expired"

    result: dict[str, Any] = {
        "id": str(approval.id),
        "status": status,
    }

    if status == "expired":
        result["expired_at"] = (
            approval.expires_at.isoformat()
            if hasattr(approval.expires_at, "isoformat")
            else str(approval.expires_at)
        )
        return result

    # Common fields for non-expired statuses
    result.update({
        "agent_id": str(approval.agent_id),
        "agent_name": agent_name,
        "action": approval.action,
        "resource_type": approval.resource_type,
        "resource_id": approval.resource_id,
        "reason": approval.reason,
        "code": approval.code,
        "created_at": approval.created_at.isoformat() if hasattr(approval.created_at, "isoformat") else str(approval.created_at),
        "expires_at": approval.expires_at.isoformat() if hasattr(approval.expires_at, "isoformat") else str(approval.expires_at),
    })

    if status == "approved":
        result["approved_at"] = (
            approval.responded_at.isoformat()
            if approval.responded_at and hasattr(approval.responded_at, "isoformat")
            else None
        )
        result["approved_by"] = (
            str(approval.responded_by_user_id)
            if approval.responded_by_user_id
            else str(approval.responded_by_agent_id) if approval.responded_by_agent_id else None
        )
        result["note"] = approval.note
        if include_sensitive_fields:
            result["approval_token"] = approval.approval_token
            result["token_expires_at"] = (
                approval.token_expires_at.isoformat()
                if approval.token_expires_at and hasattr(approval.token_expires_at, "isoformat")
                else None
            )

    elif status == "denied":
        result["denied_at"] = (
            approval.responded_at.isoformat()
            if approval.responded_at and hasattr(approval.responded_at, "isoformat")
            else None
        )
        result["denied_by"] = (
            str(approval.responded_by_user_id)
            if approval.responded_by_user_id
            else str(approval.responded_by_agent_id) if approval.responded_by_agent_id else None
        )
        result["note"] = approval.note

    # Add transaction signing fields if present (tx_signing)
    if include_sensitive_fields:
        if approval.transaction_intent is not None:
            result["transaction_intent"] = approval.transaction_intent
        if approval.signed_transaction is not None:
            result["signed_transaction"] = approval.signed_transaction
        if approval.signer_address is not None:
            result["signer_address"] = approval.signer_address
        if approval.edited_intent is not None:
            result["edited_intent"] = approval.edited_intent

    return result


def _generate_approval_token(
    approval: Any,
    agent: Any,
    jwt_secret: str,
) -> tuple[str, datetime]:
    """Generate a scoped JWT approval token.

    Token TTL = min(remaining TTL of approval, 3600s). Minimum 60s.
    """
    now = datetime.now(UTC)
    remaining = (approval.expires_at - now).total_seconds()
    ttl_seconds = max(60, min(remaining, 3600))
    expires_at = now + timedelta(seconds=ttl_seconds)

    claims = {
        "type": "approval",
        "approval_id": str(approval.id),
        "agent_id": str(agent.id),
        "agent_name": agent.name,
        "owner_user_id": str(agent.owner_user_id),
        "action": approval.action,
        "resource_type": approval.resource_type,
        "resource_id": approval.resource_id,
        "application_id": str(approval.application_id),
        "iat": int(now.timestamp()),
        "exp": int(expires_at.timestamp()),
    }

    token = jwt.encode(claims, jwt_secret, algorithm="HS256")
    return token, expires_at


# ---------------------------------------------------------------------------
# Agent CRUD
# ---------------------------------------------------------------------------


async def register_agent(
    db: AsyncSession,
    *,
    application_id: UUID,
    owner_user_id: UUID,
    name: str,
    description: str | None = None,
    scopes: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
    referral_click_id: str | None = None,
    referral_slug: str | None = None,
) -> dict[str, Any]:
    """Register a new agent under an application.

    Returns the agent data including the raw secret (shown once).
    """
    # Check name uniqueness within application
    existing = await repo.get_agent_by_name(db, application_id, name)
    if existing is not None:
        raise AgentNameExistsError()

    # Generate secret
    raw_secret = _generate_agent_secret()
    secret_hash = _hash_secret(raw_secret)
    secret_prefix = raw_secret[:8]

    agent = await repo.create_agent(
        db,
        application_id=application_id,
        owner_user_id=owner_user_id,
        name=name,
        description=description,
        agent_secret_hash=secret_hash,
        agent_secret_prefix=secret_prefix,
        scopes=scopes,
        metadata=metadata,
    )

    await _attribute_agent_referral(
        db,
        agent_id=agent.id,
        application_id=application_id,
        referral_click_id=referral_click_id,
        referral_slug=referral_slug,
    )

    result = _agent_to_dict(agent)
    result["agent_secret"] = raw_secret
    return result


async def get_agent(
    db: AsyncSession,
    *,
    agent_id: UUID,
    application_id: UUID,
    user_id: UUID,
    is_admin: bool = False,
) -> dict[str, Any]:
    """Get agent details. Owner or admin only."""
    agent = await repo.get_agent_by_id(db, agent_id, application_id=application_id)
    if agent is None:
        raise AgentNotFoundError()

    if not is_admin and agent.owner_user_id != user_id:
        raise NotAgentOwnerError()

    return _agent_to_dict(agent)


async def list_agents(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    is_admin: bool = False,
    is_active: bool | None = True,
    limit: int = 20,
    offset: int = 0,
) -> dict[str, Any]:
    """List agents. Owner sees own agents, admin sees all."""
    owner_filter = None if is_admin else user_id

    agents = await repo.list_agents(
        db,
        application_id,
        owner_user_id=owner_filter,
        is_active=is_active,
        limit=limit,
        offset=offset,
    )
    total = await repo.count_agents(
        db,
        application_id,
        owner_user_id=owner_filter,
        is_active=is_active,
    )

    # Enrich with pending approval counts
    agent_ids = [a.id for a in agents]
    pending_counts = await repo.count_pending_approvals_for_agents(db, agent_ids)

    agent_list = []
    for a in agents:
        agent_list.append({
            "id": str(a.id),
            "name": a.name,
            "description": a.description,
            "scopes": a.scopes or [],
            "is_active": a.is_active,
            "created_at": a.created_at.isoformat() if hasattr(a.created_at, "isoformat") else str(a.created_at),
            "pending_approvals_count": pending_counts.get(a.id, 0),
        })

    return {"agents": agent_list, "total": total}


async def update_agent(
    db: AsyncSession,
    *,
    agent_id: UUID,
    application_id: UUID,
    user_id: UUID,
    is_admin: bool = False,
    name: str | None = None,
    description: str | None = None,
    scopes: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
    is_active: bool | None = None,
) -> dict[str, Any]:
    """Update agent fields. Owner or admin only."""
    agent = await repo.get_agent_by_id(db, agent_id, application_id=application_id)
    if agent is None:
        raise AgentNotFoundError()

    if not is_admin and agent.owner_user_id != user_id:
        raise NotAgentOwnerError()

    # Check name uniqueness if name is changing
    if name is not None and name != agent.name:
        existing = await repo.get_agent_by_name(db, application_id, name)
        if existing is not None:
            raise AgentNameExistsError()

    fields: dict[str, Any] = {}
    if name is not None:
        fields["name"] = name
    if description is not None:
        fields["description"] = description
    if scopes is not None:
        fields["scopes"] = scopes
    if metadata is not None:
        fields["metadata"] = metadata
    if is_active is not None:
        fields["is_active"] = is_active

    updated = await repo.update_agent(db, agent, **fields)
    return _agent_to_dict(updated)


async def deactivate_agent(
    db: AsyncSession,
    *,
    agent_id: UUID,
    application_id: UUID,
    user_id: UUID,
    is_admin: bool = False,
) -> dict[str, Any]:
    """Deactivate an agent (soft delete). Expires all pending approvals."""
    agent = await repo.get_agent_by_id(db, agent_id, application_id=application_id)
    if agent is None:
        raise AgentNotFoundError()

    if not is_admin and agent.owner_user_id != user_id:
        raise NotAgentOwnerError()

    if not agent.is_active:
        raise AgentAlreadyInactiveError()

    await repo.deactivate_agent(db, agent)
    expired_count = await repo.expire_pending_approvals_for_agent(db, agent_id)

    logger.info(
        "Agent %s deactivated, %d pending approvals expired",
        agent_id,
        expired_count,
    )

    return {
        "id": str(agent_id),
        "is_active": False,
        "message": "Agent deactivated",
    }


async def rotate_agent_secret(
    db: AsyncSession,
    *,
    agent_id: UUID,
    application_id: UUID,
    user_id: UUID,
) -> dict[str, Any]:
    """Rotate agent secret. Owner only."""
    agent = await repo.get_agent_by_id(db, agent_id, application_id=application_id)
    if agent is None:
        raise AgentNotFoundError()

    if agent.owner_user_id != user_id:
        raise NotAgentOwnerError()

    raw_secret = _generate_agent_secret()
    secret_hash = _hash_secret(raw_secret)
    secret_prefix = raw_secret[:8]

    await repo.update_agent_secret(
        db,
        agent,
        agent_secret_hash=secret_hash,
        agent_secret_prefix=secret_prefix,
    )

    return {
        "agent_secret": raw_secret,
        "message": "Secret rotated. Previous secret is now invalid.",
    }


# ---------------------------------------------------------------------------
# Approver management
# ---------------------------------------------------------------------------


async def add_approver(
    db: AsyncSession,
    *,
    agent_id: UUID,
    application_id: UUID,
    user_id: UUID,
    approver_type: str,
    approver_user_id: UUID | None = None,
    approver_agent_id: UUID | None = None,
) -> dict[str, Any]:
    """Add an approver to an agent. Owner only."""
    agent = await repo.get_agent_by_id(db, agent_id, application_id=application_id)
    if agent is None:
        raise AgentNotFoundError()

    if agent.owner_user_id != user_id:
        raise NotAgentOwnerError()

    # Check max approvers
    count = await repo.count_approvers(db, agent_id)
    if count >= MAX_APPROVERS_PER_AGENT:
        raise MaxApproversExceededError()

    # Check for duplicate
    if approver_type == "user" and approver_user_id:
        existing = await repo.get_approver(db, agent_id, approver_user_id=approver_user_id)
        if existing is not None:
            raise ApproverAlreadyExistsError()

        # Validate user exists in app
        exists = await repo.user_exists_in_app(db, approver_user_id, application_id)
        if not exists:
            raise ApproverNotFoundError()

    elif approver_type == "agent" and approver_agent_id:
        existing = await repo.get_approver(db, agent_id, approver_agent_id=approver_agent_id)
        if existing is not None:
            raise ApproverAlreadyExistsError()

        # Validate agent exists in app
        supervisor = await repo.get_agent_by_id(db, approver_agent_id, application_id=application_id)
        if supervisor is None:
            raise ApproverNotFoundError()

    approver = await repo.create_approver(
        db,
        agent_id=agent_id,
        approver_type=approver_type,
        approver_user_id=approver_user_id,
        approver_agent_id=approver_agent_id,
    )

    return {
        "id": str(approver.id),
        "agent_id": str(approver.agent_id),
        "approver_type": approver.approver_type,
        "approver_user_id": str(approver.approver_user_id) if approver.approver_user_id else None,
        "approver_agent_id": str(approver.approver_agent_id) if approver.approver_agent_id else None,
        "created_at": approver.created_at.isoformat() if hasattr(approver.created_at, "isoformat") else str(approver.created_at),
    }


async def list_approvers(
    db: AsyncSession,
    *,
    agent_id: UUID,
    application_id: UUID,
    user_id: UUID,
    is_admin: bool = False,
) -> dict[str, Any]:
    """List approvers for an agent. Owner or admin."""
    agent = await repo.get_agent_by_id(db, agent_id, application_id=application_id)
    if agent is None:
        raise AgentNotFoundError()

    if not is_admin and agent.owner_user_id != user_id:
        raise NotAgentOwnerError()

    approvers = await repo.list_approvers(db, agent_id)

    # Collect IDs for enrichment
    user_ids = [a.approver_user_id for a in approvers if a.approver_user_id]
    user_ids.append(agent.owner_user_id)  # owner email too
    agent_ids = [a.approver_agent_id for a in approvers if a.approver_agent_id]

    email_map = await repo.get_user_emails_by_ids(db, user_ids)
    agent_map = await repo.get_agents_by_ids(db, agent_ids) if agent_ids else {}

    approver_list = []
    for a in approvers:
        entry: dict[str, Any] = {
            "id": str(a.id),
            "approver_type": a.approver_type,
            "approver_user_id": str(a.approver_user_id) if a.approver_user_id else None,
            "approver_agent_id": str(a.approver_agent_id) if a.approver_agent_id else None,
            "created_at": a.created_at.isoformat() if hasattr(a.created_at, "isoformat") else str(a.created_at),
        }
        if a.approver_user_id:
            entry["approver_email"] = email_map.get(a.approver_user_id)
        if a.approver_agent_id:
            sup = agent_map.get(a.approver_agent_id)
            entry["approver_agent_name"] = sup.name if sup else None
        approver_list.append(entry)

    return {
        "approvers": approver_list,
        "owner": {
            "user_id": str(agent.owner_user_id),
            "email": email_map.get(agent.owner_user_id),
            "implicit": True,
        },
        "total": len(approver_list) + 1,  # +1 for implicit owner
    }


async def remove_approver(
    db: AsyncSession,
    *,
    agent_id: UUID,
    approver_id: UUID,
    application_id: UUID,
    user_id: UUID,
) -> dict[str, Any]:
    """Remove an approver from an agent. Owner only."""
    agent = await repo.get_agent_by_id(db, agent_id, application_id=application_id)
    if agent is None:
        raise AgentNotFoundError()

    if agent.owner_user_id != user_id:
        raise NotAgentOwnerError()

    approver = await repo.get_approver_by_id(db, approver_id, agent_id=agent_id)
    if approver is None:
        raise ApproverNotFoundError()

    await repo.delete_approver(db, approver)

    return {"message": "Approver removed"}


# ---------------------------------------------------------------------------
# Approval flow
# ---------------------------------------------------------------------------


async def authenticate_agent(
    db: AsyncSession,
    *,
    agent_id: UUID,
    agent_secret: str,
    application_id: UUID,
    reveal_not_found: bool = False,
) -> Any:
    """Authenticate agent via agent_id + agent_secret.

    Returns the agent model on success.
    Raises InvalidAgentCredentialsError on failure.
    """
    agent = await repo.get_agent_by_id(db, agent_id, application_id=application_id)
    if agent is None:
        if reveal_not_found:
            raise AgentNotFoundError()
        raise InvalidAgentCredentialsError()

    if not _verify_secret(agent_secret, agent.agent_secret_hash):
        raise InvalidAgentCredentialsError()

    if not agent.is_active:
        raise AgentInactiveError()

    return agent


async def create_approval(
    db: AsyncSession,
    *,
    agent_id: UUID,
    application_id: UUID,
    action: str,
    resource_type: str | None = None,
    resource_id: str | None = None,
    reason: str | None = None,
    metadata: dict[str, Any] | None = None,
    expires_in: int = 900,
    callback_url: str | None = None,
    transaction_intent: dict[str, Any] | None = None,
    settings: object | None = None,
) -> dict[str, Any]:
    """Create an approval request from an agent."""
    # Validate agent
    agent = await repo.get_agent_by_id(db, agent_id, application_id=application_id)
    if agent is None:
        raise AgentNotFoundError()

    if not agent.is_active:
        raise AgentInactiveError()

    # Scope enforcement
    if not _check_scope_match(agent.scopes, action):
        raise ScopeViolationError()

    # Generate verification code
    code = _generate_verification_code()

    # Calculate expiration
    now = datetime.now(UTC)
    expires_at = now + timedelta(seconds=expires_in)

    # Get verification URL base from application settings
    app_model = await repo.get_application(db, application_id)

    if callback_url and settings and app_model:
        from .schemas import validate_callback_url_origin

        validate_callback_url_origin(callback_url, settings=settings, application=app_model)

    verification_url_base = DEFAULT_VERIFICATION_URL_BASE
    if app_model and hasattr(app_model, "settings") and app_model.settings:
        verification_url_base = app_model.settings.get(
            "verification_url_base", DEFAULT_VERIFICATION_URL_BASE
        )

    verification_url = f"{verification_url_base}/approve?code={code}"

    approval = await repo.create_approval(
        db,
        application_id=application_id,
        agent_id=agent_id,
        code=code,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        reason=reason,
        metadata=metadata,
        callback_url=callback_url,
        expires_at=expires_at,
        transaction_intent=transaction_intent,
    )

    return {
        "id": str(approval.id),
        "status": "pending",
        "verification_url": verification_url,
        "code": approval.code,
        "expires_at": expires_at.isoformat(),
        "expires_in": expires_in,
    }


async def get_approval(
    db: AsyncSession,
    *,
    approval_id: UUID,
    application_id: UUID,
) -> dict[str, Any]:
    """Get poll-safe approval details for app-key callers."""
    approval = await repo.get_approval_by_id(
        db, approval_id, application_id=application_id
    )
    if approval is None:
        raise ApprovalNotFoundError()

    # Get agent name for enrichment
    agent = await repo.get_agent_by_id(db, approval.agent_id)
    agent_name = agent.name if agent else None

    return _approval_to_detail_dict(
        approval,
        agent_name=agent_name,
        include_sensitive_fields=False,
    )


async def get_approval_by_code(
    db: AsyncSession,
    *,
    code: str,
    application_id: UUID,
    user_id: UUID,
) -> dict[str, Any]:
    """Get approval by verification code. Authorized approvers only."""
    approval = await repo.get_approval_by_code(
        db, code, application_id=application_id
    )
    if approval is None:
        raise ApprovalNotFoundError()

    agent = await repo.get_agent_by_id(db, approval.agent_id)
    if agent is None:
        raise ApprovalNotFoundError()

    # Check authorization
    is_approver = await repo.is_authorized_approver(
        db, approval.agent_id, agent.owner_user_id, user_id=user_id
    )
    if not is_approver:
        raise NotAuthorizedApproverError()

    return _approval_to_detail_dict(approval, agent_name=agent.name)


async def respond_to_approval(
    db: AsyncSession,
    *,
    approval_id: UUID,
    application_id: UUID,
    action: str,  # "approve" or "deny"
    responder_type: str,  # "user" or "agent"
    responder_user_id: UUID | None = None,
    responder_agent_id: UUID | None = None,
    note: str | None = None,
    signed_transaction: str | None = None,
    signer_address: str | None = None,
    edited_intent: dict[str, Any] | None = None,
    settings: Any = None,
) -> dict[str, Any]:
    """Respond to an approval request (approve or deny)."""
    approval = await repo.get_approval_by_id_for_update(
        db, approval_id, application_id=application_id
    )
    if approval is None:
        raise ApprovalNotFoundError()

    agent = await repo.get_agent_by_id(db, approval.agent_id)
    if agent is None:
        raise ApprovalNotFoundError()

    # Check if already resolved
    if approval.status != "pending":
        raise ApprovalAlreadyResolvedError()

    # Check expiration
    now = datetime.now(UTC)
    if approval.expires_at <= now:
        raise ApprovalExpiredError()

    # Check authorization
    is_approver = await repo.is_authorized_approver(
        db,
        approval.agent_id,
        agent.owner_user_id,
        user_id=responder_user_id,
        approver_agent_id=responder_agent_id,
    )
    if not is_approver:
        raise NotAuthorizedApproverError()

    if action == "approve":
        new_status = "approved"

        # Generate approval token
        jwt_secret = _resolve_approval_jwt_secret(settings)
        token, token_expires_at = _generate_approval_token(
            approval, agent, jwt_secret
        )

        await repo.update_approval_status(
            db,
            approval,
            status=new_status,
            note=note,
            responded_by_user_id=responder_user_id,
            responded_by_agent_id=responder_agent_id,
            responder_type=responder_type,
            responded_at=now,
            approval_token=token,
            token_expires_at=token_expires_at,
            signed_transaction=signed_transaction,
            signer_address=signer_address,
            edited_intent=edited_intent,
        )

        return {
            "id": str(approval_id),
            "status": "approved",
            "approved_at": now.isoformat(),
            "message": "Approval granted",
        }

    else:  # deny
        new_status = "denied"

        await repo.update_approval_status(
            db,
            approval,
            status=new_status,
            note=note,
            responded_by_user_id=responder_user_id,
            responded_by_agent_id=responder_agent_id,
            responder_type=responder_type,
            responded_at=now,
            signed_transaction=signed_transaction,
            signer_address=signer_address,
            edited_intent=edited_intent,
        )

        return {
            "id": str(approval_id),
            "status": "denied",
            "denied_at": now.isoformat(),
            "message": "Approval denied",
        }


async def list_approvals(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    is_admin: bool = False,
    agent_id: UUID | None = None,
    status: str | None = None,
    since: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> dict[str, Any]:
    """List approval history. Owner sees own agents' approvals, admin sees all."""
    owner_filter = None if is_admin else user_id

    approvals = await repo.list_approvals(
        db,
        application_id,
        owner_user_id=owner_filter,
        agent_id=agent_id,
        status=status,
        since=since,
        limit=limit,
        offset=offset,
    )
    total = await repo.count_approvals(
        db,
        application_id,
        owner_user_id=owner_filter,
        agent_id=agent_id,
        status=status,
        since=since,
    )

    # Enrich with agent names
    agent_ids = list({a.agent_id for a in approvals})
    agents_map = await repo.get_agents_by_ids(db, agent_ids)

    approval_list = []
    for a in approvals:
        agent = agents_map.get(a.agent_id)
        item: dict[str, Any] = {
            "id": str(a.id),
            "agent_id": str(a.agent_id),
            "agent_name": agent.name if agent else None,
            "action": a.action,
            "resource_type": a.resource_type,
            "resource_id": a.resource_id,
            "status": a.status,
            "created_at": a.created_at.isoformat() if hasattr(a.created_at, "isoformat") else str(a.created_at),
            "resolved_at": a.responded_at.isoformat() if a.responded_at and hasattr(a.responded_at, "isoformat") else None,
            "note": a.note,
            "reason": a.reason,
            "metadata": a.metadata_ if hasattr(a, "metadata_") else None,
            # Transaction signing fields (tx_signing)
            "transaction_intent": a.transaction_intent,
            "signed_transaction": a.signed_transaction,
        }
        approval_list.append(item)

    return {"approvals": approval_list, "total": total}
