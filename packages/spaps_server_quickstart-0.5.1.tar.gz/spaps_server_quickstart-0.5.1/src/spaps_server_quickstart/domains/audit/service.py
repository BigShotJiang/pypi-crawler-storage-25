"""Business logic for the audit domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from ..errors import ForbiddenError
from . import repository as repo
from .models import AuditLog

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _audit_log_to_dict(log: AuditLog) -> dict[str, Any]:
    """Convert an AuditLog model instance to a serialisable dict."""
    return {
        "id": str(log.id),
        "admin_user_id": str(log.admin_user_id) if log.admin_user_id else None,
        "admin_email": log.admin_email,
        "action": log.action,
        "resource_type": log.resource_type,
        "resource_id": log.resource_id,
        "resource_data": log.resource_data,
        "error_details": log.error_details,
        "ip_address": log.ip_address,
        "user_agent": log.user_agent,
        "application_id": str(log.application_id) if log.application_id else None,
        "severity": log.severity,
        "timestamp": log.timestamp.isoformat() if log.timestamp else None,
    }


# ---------------------------------------------------------------------------
# Audit logging -- public API (called by other domains)
# ---------------------------------------------------------------------------


async def log_action(
    db: AsyncSession,
    *,
    admin_user_id: UUID | None = None,
    admin_email: str | None = None,
    action: str,
    resource_type: str | None = None,
    resource_id: str | None = None,
    resource_data: dict[str, Any] | None = None,
    ip_address: str | None = None,
    user_agent: str | None = None,
    application_id: UUID | None = None,
    severity: str = "info",
) -> dict[str, Any]:
    """Create an audit log entry for a successful admin action.

    This is the primary entry point used by other domains to record
    admin actions in the immutable audit trail.
    """
    log_entry = await repo.create_audit_log(
        db,
        admin_user_id=admin_user_id,
        admin_email=admin_email,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        resource_data=resource_data,
        ip_address=ip_address,
        user_agent=user_agent,
        application_id=application_id,
        severity=severity,
    )

    logger.info(
        "Audit log created",
        extra={
            "action": action,
            "admin_email": admin_email,
            "resource_type": resource_type,
            "resource_id": resource_id,
        },
    )

    return _audit_log_to_dict(log_entry)


async def log_failed_action(
    db: AsyncSession,
    *,
    admin_user_id: UUID | None = None,
    admin_email: str | None = None,
    action: str,
    resource_type: str | None = None,
    resource_id: str | None = None,
    error_details: dict[str, Any] | None = None,
    ip_address: str | None = None,
    user_agent: str | None = None,
    application_id: UUID | None = None,
    severity: str = "warning",
) -> dict[str, Any]:
    """Create an audit log entry for a failed admin action.

    Records the error details alongside the action metadata.
    """
    log_entry = await repo.create_audit_log(
        db,
        admin_user_id=admin_user_id,
        admin_email=admin_email,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        error_details=error_details,
        ip_address=ip_address,
        user_agent=user_agent,
        application_id=application_id,
        severity=severity,
    )

    logger.warning(
        "Audit log created for failed action",
        extra={
            "action": action,
            "admin_email": admin_email,
            "error_details": error_details,
        },
    )

    return _audit_log_to_dict(log_entry)


# ---------------------------------------------------------------------------
# Audit log queries -- admin endpoints
# ---------------------------------------------------------------------------


async def get_admin_logs(
    db: AsyncSession,
    *,
    current_admin_user_id: UUID,
    requested_admin_user_id: UUID | None = None,
    action: str | None = None,
    resource_type: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> dict[str, Any]:
    """Get audit logs for a specific admin user.

    Used by the GET /audit/logs endpoint (admin access).

    Normal admins are always scoped to their own audit trail. Cross-admin
    queries must use the super-admin surface.
    """
    if (
        requested_admin_user_id is not None
        and requested_admin_user_id != current_admin_user_id
    ):
        raise ForbiddenError("Admins may only read their own audit logs")

    logs, total = await repo.list_logs_by_admin(
        db,
        current_admin_user_id,
        action=action,
        resource_type=resource_type,
        limit=limit,
        offset=offset,
    )

    return {
        "logs": [_audit_log_to_dict(log) for log in logs],
        "total": total,
    }


async def get_all_logs(
    db: AsyncSession,
    *,
    admin_user_id: UUID | None = None,
    action: str | None = None,
    resource_type: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> dict[str, Any]:
    """Get all audit logs across all admins (super admin only).

    Used by the GET /audit/all-logs endpoint (super admin access).
    """
    logs, total = await repo.list_all_logs(
        db,
        admin_user_id=admin_user_id,
        action=action,
        resource_type=resource_type,
        limit=limit,
        offset=offset,
    )

    return {
        "logs": [_audit_log_to_dict(log) for log in logs],
        "total": total,
    }


# ---------------------------------------------------------------------------
# Retention cleanup
# ---------------------------------------------------------------------------


async def retention_cleanup(
    db: AsyncSession,
    *,
    retention_days: int = 90,
    archive_retention_days: int = 365,
) -> dict[str, int]:
    """Run retention cleanup: archive old logs, purge old archives.

    - Logs older than ``retention_days`` are moved to audit_logs_archive.
    - Archives older than ``archive_retention_days`` are permanently deleted.

    Returns counts of archived and purged rows.
    """
    from datetime import timedelta

    now = datetime.now(UTC)

    archive_cutoff = now - timedelta(days=retention_days)
    purge_cutoff = now - timedelta(days=archive_retention_days)

    archived = await repo.archive_old_logs(db, archive_cutoff)
    purged = await repo.purge_old_archives(db, purge_cutoff)

    if archived > 0 or purged > 0:
        logger.info(
            "Audit retention cleanup completed",
            extra={
                "archived": archived,
                "purged": purged,
                "retention_days": retention_days,
                "archive_retention_days": archive_retention_days,
            },
        )

    return {"archived": archived, "purged": purged}
