"""Business logic for the dayrate domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import datetime as dt
import logging
import zoneinfo
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from ..entitlements import repository as ent_repo
from ..errors import ValidationError
from ..webhooks import service as webhook_service
from . import repository as repo
from .errors import (
    AllotmentExhaustedError,
    BookingAlreadyCancelledError,
    BookingNotFoundError,
    ConfigNotFoundError,
    NotBookingOwnerError,
    NoticePeriodViolationError,
    PolicyAlreadyExistsError,
    PolicyNotFoundError,
    SlotUnavailableError,
)
from .models import BookingPolicy, DayRateBooking, DayRateConfig
from .pricing import calculate_price_with_breakdown

logger = logging.getLogger(__name__)

# Default slot definitions (matches Node's DEFAULT_SLOT_DEFINITIONS)
DEFAULT_SLOT_TYPES = ["AM", "PM"]
DEFAULT_SLOT_DEFINITIONS: dict[str, dict[str, Any]] = {
    "AM": {"startHour": 9, "endHour": 13, "label": "Morning"},
    "PM": {"startHour": 14, "endHour": 18, "label": "Afternoon"},
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _config_to_dict(config: DayRateConfig) -> dict[str, Any]:
    """Convert a DayRateConfig model instance to a serialisable dict."""
    return {
        "id": str(config.id),
        "application_id": str(config.application_id),
        "base_rate": config.base_rate,
        "available_days": config.available_days,
        "slots": config.slots,
        "fill_tiers": config.fill_tiers,
        "time_tiers": config.time_tiers,
        "horizon_weeks": config.horizon_weeks,
        "meeting_link": config.meeting_link,
        "min_notice_hours": config.min_notice_hours,
        "hold_duration_minutes": config.hold_duration_minutes,
        "timezone": config.timezone,
        "slot_definitions": config.slot_definitions,
        "currency": config.currency,
        "product_name": config.product_name,
        "created_at": config.created_at.isoformat() if config.created_at else None,
        "updated_at": config.updated_at.isoformat() if config.updated_at else None,
    }


def _booking_to_dict(booking: DayRateBooking) -> dict[str, Any]:
    """Convert a DayRateBooking model instance to a serialisable dict."""
    result: dict[str, Any] = {
        "id": str(booking.id),
        "application_id": str(booking.application_id),
        "user_id": str(booking.user_id) if booking.user_id else None,
        "date": booking.date.isoformat() if booking.date else None,
        "slot_type": booking.slot_type,
        "client_email": booking.client_email,
        "client_name": booking.client_name,
        "price_paid": booking.price_paid,
        "stripe_session_id": booking.stripe_session_id,
        "stripe_payment_intent_id": booking.stripe_payment_intent_id,
        "status": booking.status,
        "metadata": booking.metadata_,
        "booking_group_id": booking.booking_group_id,
        "expires_at": booking.expires_at.isoformat() if booking.expires_at else None,
        "created_at": booking.created_at.isoformat() if booking.created_at else None,
        "updated_at": booking.updated_at.isoformat() if booking.updated_at else None,
    }
    # checkin_call_booking additions (always include for forward compat)
    result["enrollment_id"] = getattr(booking, "enrollment_id", None)
    result["replaces_booking_id"] = (
        str(booking.replaces_booking_id)
        if getattr(booking, "replaces_booking_id", None)
        else None
    )
    result["policy_key"] = getattr(booking, "policy_key", None)
    result["is_free"] = getattr(booking, "is_free", False)
    return result


def _checkout_status_booking_to_dict(booking: DayRateBooking) -> dict[str, Any]:
    """Return a guest-safe booking summary for checkout polling."""
    return {
        "bookingId": str(booking.id),
        "date": booking.date.isoformat() if booking.date else None,
        "slot": booking.slot_type,
        "status": booking.status,
        "price": booking.price_paid,
        "bookingGroupId": booking.booking_group_id,
    }


def _policy_to_dict(policy: BookingPolicy) -> dict[str, Any]:
    """Convert a BookingPolicy model instance to a serialisable dict."""
    return {
        "id": str(policy.id),
        "applicationId": str(policy.application_id),
        "policyKey": policy.policy_key,
        "entitlementKey": policy.entitlement_key,
        "freeBookingsPerPeriod": policy.free_bookings_per_period,
        "periodDays": policy.period_days,
        "overageRate": policy.overage_rate,
        "overageCurrency": policy.overage_currency,
        "overageProductName": policy.overage_product_name,
        "rescheduleIsFree": policy.reschedule_is_free,
        "isActive": policy.is_active,
        "metadata": policy.metadata_,
    }


def _verify_ownership(
    booking: DayRateBooking,
    *,
    user_id: UUID | None = None,
    email: str | None = None,
) -> None:
    """Verify caller owns the booking. Raises NotBookingOwnerError on mismatch.

    Ownership resolution (backend.md Rule 4):
    1. If booking has user_id -> caller user_id must match
    2. If booking has no user_id -> fallback to client_email matching
    """
    if booking.user_id is not None:
        # Primary check: user_id match
        if user_id is None or booking.user_id != user_id:
            raise NotBookingOwnerError()
    else:
        # Fallback: client_email match (legacy bookings without user_id)
        if email is None or booking.client_email.lower() != email.lower():
            raise NotBookingOwnerError()


def _slot_types_from_slot_definitions(slot_definitions: Any) -> list[str]:
    """Extract slot types from canonical slot_definitions shape."""
    if isinstance(slot_definitions, dict) and slot_definitions:
        return list(slot_definitions.keys())
    return []


def _slot_types_from_legacy_slots(slots: Any) -> list[str]:
    """Extract slot types from legacy slots values."""
    if isinstance(slots, list):
        return [str(slot) for slot in slots if isinstance(slot, str) and slot]
    if isinstance(slots, dict):
        return [str(slot) for slot in slots.keys()]
    return []


def _get_slot_types(config: DayRateConfig) -> list[str]:
    """Get slot types from config, with safe fallback order.

    Precedence:
    1. ``slot_definitions`` keys (new/canonical shape)
    2. ``slots`` array (legacy/prod TEXT[] shape)
    3. built-in AM/PM defaults
    """
    slot_types = _slot_types_from_slot_definitions(config.slot_definitions)
    if slot_types:
        return slot_types

    slot_types = _slot_types_from_legacy_slots(config.slots)
    if slot_types:
        return slot_types

    return DEFAULT_SLOT_TYPES


def _get_slot_definition(
    slot_type: str, slot_definitions: dict[str, Any] | None
) -> dict[str, Any]:
    """Get slot definition, falling back to defaults. Matches Node."""
    if slot_definitions and slot_type in slot_definitions:
        return slot_definitions[slot_type]
    return DEFAULT_SLOT_DEFINITIONS.get(
        slot_type, {"startHour": 9, "endHour": 17, "label": slot_type}
    )


def _format_slot_time_range(slot_def: dict[str, Any]) -> str:
    """Format slot time range for display (e.g. '9am-1pm'). Matches Node."""
    def _fmt(h: int) -> str:
        hour12 = h % 12 or 12
        suffix = "am" if h < 12 else "pm"
        return f"{hour12}{suffix}"

    return f"{_fmt(slot_def['startHour'])}-{_fmt(slot_def['endHour'])}"


def _build_product_name(
    product_name: str,
    booking_date: dt.date,
    slot: str,
    slot_definitions: dict[str, Any] | None,
) -> str:
    """Build rich Stripe product name matching Node pattern.

    Example: 'Half Day Session - Wednesday Afternoon (2pm-5pm)'
    """
    day_of_week = booking_date.strftime("%A")
    slot_def = _get_slot_definition(slot, slot_definitions)
    slot_label = f"{slot_def['label']} ({_format_slot_time_range(slot_def)})"
    return f"{product_name} - {day_of_week} {slot_label}"


def _get_available_days(config: DayRateConfig) -> list[str]:
    """Get the list of available day names from config."""
    if config.available_days:
        return [d.lower() for d in config.available_days]
    # Default: Monday through Friday
    return ["monday", "tuesday", "wednesday", "thursday", "friday"]


def _is_day_available(date: dt.date, available_days: list[str]) -> bool:
    """Check if a date falls on an available day of the week."""
    day_name = date.strftime("%A").lower()
    return day_name in available_days


def _check_notice_period(
    booking_date: dt.date,
    slot_type: str,
    min_notice_hours: int | None,
    timezone: str | None,
    now: dt.datetime | None = None,
) -> bool:
    """Check whether a booking violates the minimum notice period.

    Returns True if the booking is valid (enough notice), False if violated.
    """
    if now is None:
        now = dt.datetime.now(dt.UTC)

    # Defend against legacy/null config rows in dev snapshots.
    notice_hours = min_notice_hours if isinstance(min_notice_hours, int) else 24

    # Use the configured timezone for the booking date so that the notice
    # period is calculated relative to the application's local time.
    try:
        tz = zoneinfo.ZoneInfo(timezone) if timezone else dt.UTC
    except (zoneinfo.ZoneInfoNotFoundError, ValueError):
        logger.warning("Invalid dayrate timezone %r; defaulting to UTC", timezone)
        tz = dt.UTC
    booking_dt = dt.datetime.combine(booking_date, dt.time.min, tzinfo=tz)

    # Convert both to UTC for comparison
    now_utc = now.astimezone(dt.UTC)
    booking_utc = booking_dt.astimezone(dt.UTC)
    hours_until = (booking_utc - now_utc).total_seconds() / 3600

    return hours_until >= notice_hours


def _count_total_slots(
    start_date: dt.date,
    end_date: dt.date,
    available_days: list[str],
    slots_per_day: int,
) -> int:
    """Count total bookable slots across a date range.

    Matches the Node ``countTotalSlots`` function: iterate each day in
    [start_date, end_date], count days that fall on an available weekday,
    multiply by slots_per_day.
    """
    count = 0
    current = start_date
    while current <= end_date:
        if _is_day_available(current, available_days):
            count += slots_per_day
        current += dt.timedelta(days=1)
    return count


# ---------------------------------------------------------------------------
# Availability
# ---------------------------------------------------------------------------


async def get_availability(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> dict[str, Any]:
    """Get available slots within the booking horizon.

    Returns slots with calculated prices and availability status.
    """
    config = await repo.get_config(db, application_id)
    if config is None:
        raise ConfigNotFoundError()

    slot_types = _get_slot_types(config)
    available_days = _get_available_days(config)
    horizon_weeks = config.horizon_weeks or 4
    now = dt.datetime.now(dt.UTC)
    today = now.date()

    start_date = today
    end_date = today + dt.timedelta(weeks=horizon_weeks)

    # Get all active bookings in range
    existing_bookings = await repo.get_bookings_in_range(
        db, application_id, start_date, end_date
    )

    # Build a set of booked (date, slot) pairs for quick lookup
    booked_slots: set[tuple[str, str]] = set()
    bookings_per_day: dict[str, int] = {}
    for booking in existing_bookings:
        date_str = booking.date.isoformat()
        booked_slots.add((date_str, booking.slot_type))
        bookings_per_day[date_str] = bookings_per_day.get(date_str, 0) + 1

    slots: list[dict[str, Any]] = []

    # Horizon-wide fill calculation (matches Node engine)
    total_horizon_slots = _count_total_slots(
        start_date, end_date, available_days, len(slot_types)
    )
    total_booked = len(existing_bookings)
    horizon_fill_percent = (
        (total_booked / total_horizon_slots * 100)
        if total_horizon_slots > 0
        else 0
    )

    current = start_date
    while current <= end_date:
        if not _is_day_available(current, available_days):
            current += dt.timedelta(days=1)
            continue

        date_str = current.isoformat()
        days_until = (current - today).days

        breakdown = calculate_price_with_breakdown(
            base_rate=config.base_rate,
            fill_percent=horizon_fill_percent,
            days_until=days_until,
            fill_tiers=config.fill_tiers,
            time_tiers=config.time_tiers,
        )

        for slot in slot_types:
            is_booked = (date_str, slot) in booked_slots
            notice_ok = _check_notice_period(
                current, slot, config.min_notice_hours, config.timezone, now
            )
            available = not is_booked and notice_ok

            slot_info = {
                "date": date_str,
                "dayOfWeek": current.strftime("%A").lower(),
                "slot": slot,
                "price": breakdown["finalPrice"],
                "available": available,
                "breakdown": breakdown,
            }
            slots.append(slot_info)

        current += dt.timedelta(days=1)

    return {
        "currentFillRate": round(horizon_fill_percent, 2),
        "totalSlots": total_horizon_slots,
        "bookedSlots": total_booked,
        "baseRate": config.base_rate,
        "meetingLink": config.meeting_link,
        "slots": slots,
    }


# ---------------------------------------------------------------------------
# Booking
# ---------------------------------------------------------------------------


async def book_slot(
    db: AsyncSession,
    *,
    application_id: UUID,
    date_str: str,
    slot: str,
    client_email: str,
    client_name: str,
    success_url: str,
    cancel_url: str,
    stripe_create_checkout: Any = None,
    # --- checkin_call_booking additions (all optional) ---
    policy_key: str | None = None,
    enrollment_id: str | None = None,
    replaces_booking_id: UUID | None = None,
    user_id: UUID | None = None,
    branding_display_name: str | None = None,
    allow_free_booking: bool = True,
    free_booking_user_id: UUID | None = None,
    free_booking_email: str | None = None,
    session_factory: Any = None,
) -> dict[str, Any]:
    """Book a single slot. Enhanced with free/reschedule/allotment paths.

    Branching logic:
    1. If replacesBookingId -> reschedule flow (cancel old + create new atomically)
    2. If policyKey -> check entitlement + allotment:
       a. Entitled + remaining -> free auto-confirm
       b. Entitled + exhausted + overage_rate -> Stripe at overage rate
       c. Entitled + exhausted + no overage -> 403
       d. No entitlement -> Stripe at dynamic price
    3. No policyKey -> existing paid flow (buildooor)

    Args:
        stripe_create_checkout: Callable for Stripe checkout session creation.
        policy_key: Booking policy key (enables free/allotment path).
        enrollment_id: Cross-system enrollment reference (HTMA).
        replaces_booking_id: ID of booking to reschedule.
        user_id: Authenticated user ID for ownership.
        allow_free_booking: Whether the caller is allowed to redeem the free path.
        free_booking_user_id: Trusted user ID for free-path entitlement checks.
        free_booking_email: Trusted email for free-path entitlement checks.
        session_factory: Session factory for webhook delivery persistence.
    """
    config = await repo.get_config(db, application_id)
    if config is None:
        raise ConfigNotFoundError()

    # Parse date
    try:
        booking_date = dt.date.fromisoformat(date_str)
    except ValueError as exc:
        raise ValidationError(f"Invalid date format: {date_str}") from exc

    # Validate slot type (dynamic against config, not hardcoded AM/PM)
    slot_types = _get_slot_types(config)
    if slot not in slot_types:
        raise ValidationError(f"Invalid slot type: {slot}. Valid types: {slot_types}")

    # Check notice period
    now = dt.datetime.now(dt.UTC)
    if not _check_notice_period(
        booking_date, slot, config.min_notice_hours, config.timezone, now
    ):
        raise NoticePeriodViolationError()

    # -----------------------------------------------------------------------
    # Reschedule path (Rule 3)
    # -----------------------------------------------------------------------
    if replaces_booking_id is not None:
        return await _reschedule_booking(
            db,
            config=config,
            application_id=application_id,
            replaces_booking_id=replaces_booking_id,
            new_date=booking_date,
            new_date_str=date_str,
            new_slot=slot,
            client_email=client_email,
            client_name=client_name,
            user_id=user_id,
            email=client_email,
            enrollment_id=enrollment_id,
            session_factory=session_factory,
        )

    # -----------------------------------------------------------------------
    # Policy-aware booking path (Rule 2)
    # -----------------------------------------------------------------------
    if policy_key is not None:
        policy = await repo.get_booking_policy_by_key(db, application_id, policy_key)
        if policy is None:
            raise PolicyNotFoundError(f"No active policy '{policy_key}'")

        effective_free_booking_user_id = (
            free_booking_user_id if free_booking_user_id is not None else user_id
        )
        effective_free_booking_email = (
            free_booking_email if free_booking_email is not None else client_email
        )

        if not allow_free_booking:
            return await _create_paid_booking(
                db,
                config=config,
                application_id=application_id,
                booking_date=booking_date,
                date_str=date_str,
                slot=slot,
                client_email=client_email,
                client_name=client_name,
                user_id=user_id,
                success_url=success_url,
                cancel_url=cancel_url,
                stripe_create_checkout=stripe_create_checkout,
                branding_display_name=branding_display_name,
                policy_key=policy_key,
                enrollment_id=enrollment_id,
            )

        # Lock policy row for allotment serialization (Rule 5)
        await repo.lock_policy_for_allotment(db, application_id, policy_key)

        # Check entitlement
        entitlements = await ent_repo.list_entitlements(
            db,
            application_id,
            user_id=effective_free_booking_user_id,
            email=effective_free_booking_email,
            entitlement_key=policy.entitlement_key,
        )

        has_entitlement = len(entitlements) > 0

        if has_entitlement:
            # Count allotment
            period_start = now - dt.timedelta(days=policy.period_days)
            used = await repo.count_allotment_bookings(
                db,
                application_id,
                period_start,
                user_id=effective_free_booking_user_id,
                email=effective_free_booking_email,
            )
            remaining = max(0, policy.free_bookings_per_period - used)

            if remaining > 0:
                # FREE PATH: auto-confirm, skip Stripe
                return await _create_free_booking(
                    db,
                    config=config,
                    application_id=application_id,
                    booking_date=booking_date,
                    date_str=date_str,
                    slot=slot,
                    client_email=effective_free_booking_email,
                    client_name=client_name,
                    user_id=effective_free_booking_user_id,
                    policy_key=policy_key,
                    enrollment_id=enrollment_id,
                    allotment_total=policy.free_bookings_per_period,
                    allotment_used=used + 1,  # this booking counts
                    session_factory=session_factory,
                )

            # Allotment exhausted
            if policy.overage_rate is not None:
                # OVERAGE PATH: Stripe at overage rate
                return await _create_paid_booking(
                    db,
                    config=config,
                    application_id=application_id,
                    booking_date=booking_date,
                    date_str=date_str,
                    slot=slot,
                    client_email=client_email,
                    client_name=client_name,
                    user_id=user_id,
                    success_url=success_url,
                    cancel_url=cancel_url,
                    stripe_create_checkout=stripe_create_checkout,
                    override_price=policy.overage_rate,
                    override_currency=policy.overage_currency,
                    override_product_name=policy.overage_product_name,
                    branding_display_name=branding_display_name,
                    policy_key=policy_key,
                    enrollment_id=enrollment_id,
                )
            else:
                raise AllotmentExhaustedError()

        # No entitlement -> fall through to standard paid flow

    # -----------------------------------------------------------------------
    # Standard paid flow (existing buildooor path)
    # -----------------------------------------------------------------------
    return await _create_paid_booking(
        db,
        config=config,
        application_id=application_id,
        booking_date=booking_date,
        date_str=date_str,
        slot=slot,
        client_email=client_email,
        client_name=client_name,
        user_id=user_id,
        success_url=success_url,
        cancel_url=cancel_url,
        stripe_create_checkout=stripe_create_checkout,
        branding_display_name=branding_display_name,
        policy_key=policy_key,
        enrollment_id=enrollment_id,
    )


async def _create_free_booking(
    db: AsyncSession,
    *,
    config: DayRateConfig,
    application_id: UUID,
    booking_date: dt.date,
    date_str: str,
    slot: str,
    client_email: str,
    client_name: str,
    user_id: UUID | None,
    policy_key: str | None,
    enrollment_id: str | None,
    allotment_total: int,
    allotment_used: int,
    session_factory: Any = None,
) -> dict[str, Any]:
    """Create a free auto-confirmed booking (allotment path)."""
    # Check slot availability
    existing = await repo.get_bookings_for_date(db, application_id, booking_date)
    for b in existing:
        if b.slot_type == slot:
            raise SlotUnavailableError()

    await repo.expire_stale_pendings(db, application_id, booking_date, slot)

    try:
        booking = await repo.create_booking(
            db,
            application_id=application_id,
            date=booking_date,
            slot_type=slot,
            client_email=client_email,
            client_name=client_name,
            price_paid=0,
            status="confirmed",
            is_free=True,
            policy_key=policy_key,
            enrollment_id=enrollment_id,
            user_id=user_id,
        )
    except IntegrityError:
        await db.rollback()
        raise SlotUnavailableError(
            f"Slot {slot} on {date_str} was just booked by another user"
        )

    logger.info(
        "Free day-rate booking created",
        extra={
            "booking_id": str(booking.id),
            "date": date_str,
            "slot": slot,
            "policy_key": policy_key,
        },
    )

    # Dispatch BOOKING_CREATED webhook
    await _dispatch_booking_webhook(
        db,
        event_type="booking.created",
        application_id=application_id,
        booking=booking,
        session_factory=session_factory,
    )

    return {
        "bookingId": str(booking.id),
        "status": "confirmed",
        "isFree": True,
        "allotment": {
            "total": allotment_total,
            "used": allotment_used,
            "remaining": allotment_total - allotment_used,
        },
    }


async def _create_paid_booking(
    db: AsyncSession,
    *,
    config: DayRateConfig,
    application_id: UUID,
    booking_date: dt.date,
    date_str: str,
    slot: str,
    client_email: str,
    client_name: str,
    user_id: UUID | None = None,
    success_url: str,
    cancel_url: str,
    stripe_create_checkout: Any = None,
    override_price: int | None = None,
    override_currency: str | None = None,
    override_product_name: str | None = None,
    branding_display_name: str | None = None,
    policy_key: str | None = None,
    enrollment_id: str | None = None,
) -> dict[str, Any]:
    """Create a paid booking via Stripe checkout (existing flow + optional overrides)."""
    # Check slot availability
    existing = await repo.get_bookings_for_date(db, application_id, booking_date)
    for b in existing:
        if b.slot_type == slot:
            raise SlotUnavailableError()

    slot_types = _get_slot_types(config)
    now = dt.datetime.now(dt.UTC)

    if override_price is not None:
        price = override_price
        breakdown = {
            "baseRate": override_price,
            "fillMultiplier": 1.0,
            "timeMultiplier": 1.0,
            "finalPrice": override_price,
        }
    else:
        # Calculate price using horizon-wide fill rate
        horizon_weeks = config.horizon_weeks or 4
        today = now.date()
        start_date = today
        end_date = today + dt.timedelta(weeks=horizon_weeks)
        available_days = _get_available_days(config)

        total_horizon_slots = _count_total_slots(
            start_date, end_date, available_days, len(slot_types)
        )
        all_bookings = await repo.get_bookings_in_range(
            db, application_id, start_date, end_date
        )
        total_booked = len(all_bookings)
        fill_percent = (
            (total_booked / total_horizon_slots * 100)
            if total_horizon_slots > 0
            else 0
        )
        days_until = (booking_date - now.date()).days

        breakdown = calculate_price_with_breakdown(
            base_rate=config.base_rate,
            fill_percent=fill_percent,
            days_until=days_until,
            fill_tiers=config.fill_tiers,
            time_tiers=config.time_tiers,
        )
        price = int(breakdown["finalPrice"])

    currency = override_currency or config.currency
    product_name = override_product_name or config.product_name or "Day Rate"

    checkout_metadata = {
        "dayrate_booking": "true",
        "application_id": str(application_id),
        "date": date_str,
        "slot": slot,
        "client_email": client_email,
        "client_name": client_name,
    }

    rich_name = _build_product_name(
        product_name, booking_date, slot, config.slot_definitions
    )

    checkout_result: dict[str, Any] = {}
    if stripe_create_checkout is not None:
        checkout_result = await stripe_create_checkout(
            price=price,
            currency=currency,
            product_name=rich_name,
            description=f"Booking for {date_str}",
            success_url=success_url,
            cancel_url=cancel_url,
            client_email=client_email,
            metadata=checkout_metadata,
            branding_display_name=branding_display_name,
        )
    else:
        checkout_result = {
            "id": f"cs_pending_{uuid4().hex[:12]}",
            "url": success_url,
        }

    session_id = checkout_result.get("id", "")
    checkout_url = checkout_result.get("url", "")

    hold_minutes = config.hold_duration_minutes or 30
    expires_at = now + dt.timedelta(minutes=hold_minutes)

    await repo.expire_stale_pendings(db, application_id, booking_date, slot)

    try:
        booking = await repo.create_booking(
            db,
            application_id=application_id,
            date=booking_date,
            slot_type=slot,
            client_email=client_email,
            client_name=client_name,
            price_paid=price,
            stripe_session_id=session_id,
            status="pending",
            metadata_=checkout_metadata,
            expires_at=expires_at,
            is_free=False,
            policy_key=policy_key,
            enrollment_id=enrollment_id,
            user_id=user_id,
        )
    except IntegrityError:
        await db.rollback()
        raise SlotUnavailableError(
            f"Slot {slot} on {date_str} was just booked by another user"
        )

    logger.info(
        "Day-rate booking created (paid)",
        extra={"booking_id": str(booking.id), "date": date_str, "slot": slot, "price": price},
    )

    return {
        "bookingId": str(booking.id),
        "checkoutUrl": checkout_url,
        "price": price,
        "breakdown": breakdown,
        "expiresAt": expires_at.isoformat(),
        "expiresIn": hold_minutes * 60,
    }


async def get_checkout_status(
    db: AsyncSession,
    *,
    application_id: UUID,
    stripe_session_id: str,
) -> dict[str, Any]:
    """Summarize checkout confirmation state for a single Stripe session."""
    bookings = [
        booking
        for booking in await repo.get_bookings_by_stripe_session_id(db, stripe_session_id)
        if booking.application_id == application_id
    ]
    bookings.sort(key=lambda booking: (booking.date, booking.slot_type))

    matched = len(bookings)
    confirmed_count = sum(1 for booking in bookings if booking.status == "confirmed")
    pending_count = sum(1 for booking in bookings if booking.status == "pending")
    other_count = matched - confirmed_count - pending_count

    if matched == 0:
        status = "not_found"
    elif confirmed_count == matched:
        status = "confirmed"
    elif pending_count > 0 and other_count == 0:
        status = "pending"
    else:
        status = "attention_required"

    return {
        "sessionId": stripe_session_id,
        "status": status,
        "matched": matched,
        "confirmedCount": confirmed_count,
        "pendingCount": pending_count,
        "otherCount": other_count,
        "bookings": [_checkout_status_booking_to_dict(booking) for booking in bookings],
    }


async def confirm_paid_bookings_for_checkout_session(
    db: AsyncSession,
    *,
    stripe_session_id: str,
    stripe_payment_intent_id: str | None = None,
    session_factory: Any = None,
) -> dict[str, Any]:
    """Confirm pending paid bookings associated with a Stripe checkout session."""
    bookings = await repo.get_bookings_by_stripe_session_id(db, stripe_session_id)
    confirmed_count = 0

    for booking in bookings:
        if booking.status == "pending":
            booking = await repo.update_booking(
                db,
                booking.id,
                status="confirmed",
                stripe_payment_intent_id=stripe_payment_intent_id,
                expires_at=None,
            ) or booking
            confirmed_count += 1
            await _dispatch_booking_webhook(
                db,
                event_type="booking.created",
                application_id=booking.application_id,
                booking=booking,
                session_factory=session_factory,
            )
            continue

        if (
            booking.status == "confirmed"
            and stripe_payment_intent_id
            and not booking.stripe_payment_intent_id
        ):
            await repo.update_booking(
                db,
                booking.id,
                stripe_payment_intent_id=stripe_payment_intent_id,
            )

    return {
        "matched": len(bookings),
        "confirmed": confirmed_count,
        "bookings": [_booking_to_dict(booking) for booking in bookings],
    }


async def expire_pending_bookings_for_checkout_session(
    db: AsyncSession,
    *,
    stripe_session_id: str,
) -> dict[str, Any]:
    """Expire pending paid bookings associated with a Stripe checkout session."""
    bookings = await repo.get_bookings_by_stripe_session_id(db, stripe_session_id)
    expired_count = 0

    for booking in bookings:
        if booking.status != "pending":
            continue

        await repo.update_booking(
            db,
            booking.id,
            status="expired",
            expires_at=None,
        )
        expired_count += 1

    return {
        "matched": len(bookings),
        "expired": expired_count,
        "bookings": [_booking_to_dict(booking) for booking in bookings],
    }


async def _reschedule_booking(
    db: AsyncSession,
    *,
    config: DayRateConfig,
    application_id: UUID,
    replaces_booking_id: UUID,
    new_date: dt.date,
    new_date_str: str,
    new_slot: str,
    client_email: str,
    client_name: str,
    user_id: UUID | None,
    email: str | None,
    enrollment_id: str | None,
    session_factory: Any = None,
) -> dict[str, Any]:
    """Atomic reschedule: cancel old + create new in one transaction.

    Rule 3: If any step fails, the entire operation rolls back.
    """
    # Lock old booking (FOR UPDATE)
    old_booking = await repo.get_booking_by_id_for_update(db, replaces_booking_id)
    if old_booking is None:
        raise BookingNotFoundError()

    # Verify ownership (Rule 4)
    _verify_ownership(old_booking, user_id=user_id, email=email)

    # Verify not already cancelled
    if old_booking.status == "cancelled":
        raise BookingAlreadyCancelledError()

    # Check new slot availability
    existing = await repo.get_bookings_for_date(db, application_id, new_date)
    for b in existing:
        if b.slot_type == new_slot:
            raise SlotUnavailableError()

    # Cancel old booking
    await repo.update_booking(db, old_booking.id, status="cancelled")

    # Inherit is_free and policy_key from old booking
    inherited_is_free = getattr(old_booking, "is_free", False)
    inherited_policy_key = getattr(old_booking, "policy_key", None)
    inherited_enrollment_id = enrollment_id or getattr(old_booking, "enrollment_id", None)

    # Expire stale pendings for the new slot
    await repo.expire_stale_pendings(db, application_id, new_date, new_slot)

    try:
        new_booking = await repo.create_booking(
            db,
            application_id=application_id,
            date=new_date,
            slot_type=new_slot,
            client_email=client_email,
            client_name=client_name,
            price_paid=0 if inherited_is_free else old_booking.price_paid,
            status="confirmed",
            is_free=inherited_is_free,
            policy_key=inherited_policy_key,
            enrollment_id=inherited_enrollment_id,
            replaces_booking_id=replaces_booking_id,
            user_id=user_id,
        )
    except IntegrityError:
        await db.rollback()
        raise SlotUnavailableError(
            f"Slot {new_slot} on {new_date_str} was just booked by another user"
        )

    logger.info(
        "Booking rescheduled",
        extra={
            "old_booking_id": str(old_booking.id),
            "new_booking_id": str(new_booking.id),
        },
    )

    # Dispatch BOOKING_RESCHEDULED webhook
    await _dispatch_reschedule_webhook(
        db,
        application_id=application_id,
        old_booking=old_booking,
        new_booking=new_booking,
        session_factory=session_factory,
    )

    return {
        "bookingId": str(new_booking.id),
        "status": "confirmed",
        "isFree": inherited_is_free,
    }


async def book_multi(
    db: AsyncSession,
    *,
    application_id: UUID,
    slots: list[dict[str, str]],
    client_email: str,
    client_name: str,
    success_url: str,
    cancel_url: str,
    stripe_create_checkout: Any = None,
    branding_display_name: str | None = None,
) -> dict[str, Any]:
    """Book multiple slots in a single Stripe checkout session.

    Creates a pending booking for each slot with a shared booking_group_id.
    """
    config = await repo.get_config(db, application_id)
    if config is None:
        raise ConfigNotFoundError()

    if not slots:
        raise ValidationError("At least one slot is required")

    slot_types = _get_slot_types(config)
    now = dt.datetime.now(dt.UTC)
    booking_group_id = str(uuid4())
    total_price = 0
    booking_entries: list[dict[str, Any]] = []

    # Pre-compute horizon-wide fill data (matches Node engine)
    available_days = _get_available_days(config)
    horizon_weeks = config.horizon_weeks or 4
    today = now.date()
    start_date = today
    end_date = today + dt.timedelta(weeks=horizon_weeks)

    total_horizon_slots = _count_total_slots(
        start_date, end_date, available_days, len(slot_types)
    )
    all_bookings = await repo.get_bookings_in_range(
        db, application_id, start_date, end_date
    )
    running_booked_count = len(all_bookings)
    requested_dates: list[dt.date] = []
    parsed_slots: list[tuple[dt.date, str, str]] = []

    # Validate all slots first
    for slot_item in slots:
        date_str = slot_item.get("date", "")
        slot = slot_item.get("slot", "")

        # Parse date
        try:
            booking_date = dt.date.fromisoformat(date_str)
        except ValueError as exc:
            raise ValidationError(f"Invalid date format: {date_str}") from exc

        # Validate slot type
        if slot not in slot_types:
            raise ValidationError(
                f"Invalid slot type: {slot}. Valid types: {slot_types}"
            )

        # Check notice period
        if not _check_notice_period(
            booking_date, slot, config.min_notice_hours, config.timezone, now
        ):
            raise NoticePeriodViolationError(
                f"Booking on {date_str} {slot} violates minimum notice period"
            )

        requested_dates.append(booking_date)
        parsed_slots.append((booking_date, slot, date_str))

    existing_by_slot = {
        (booking.date, booking.slot_type)
        for booking in await repo.get_bookings_for_dates(
            db, application_id, requested_dates
        )
    }

    for booking_date, slot, date_str in parsed_slots:
        if (booking_date, slot) in existing_by_slot:
            raise SlotUnavailableError(
                f"Slot {slot} on {date_str} is already booked"
            )

        # Calculate price with running fill count (matches Node's runningBookedCount)
        fill_percent = (
            (running_booked_count / total_horizon_slots * 100)
            if total_horizon_slots > 0
            else 0
        )
        days_until = (booking_date - today).days

        breakdown = calculate_price_with_breakdown(
            base_rate=config.base_rate,
            fill_percent=fill_percent,
            days_until=days_until,
            fill_tiers=config.fill_tiers,
            time_tiers=config.time_tiers,
        )
        price = breakdown["finalPrice"]
        total_price += price
        running_booked_count += 1  # Next slot sees higher fill

        booking_entries.append({
            "date": booking_date,
            "date_str": date_str,
            "slot": slot,
            "price": price,
            "breakdown": breakdown,
        })

    # Create Stripe checkout session for total
    checkout_metadata = {
        "dayrate_booking": "true",
        "dayrate_multi": "true",
        "application_id": str(application_id),
        "booking_group_id": booking_group_id,
        "slot_count": str(len(booking_entries)),
        "client_email": client_email,
        "client_name": client_name,
    }

    # Build per-slot line items (matches Node's multi-checkout pattern)
    line_items = []
    base_product_name = config.product_name or "Day Rate"
    for entry in booking_entries:
        rich_name = _build_product_name(
            base_product_name,
            entry["date"],
            entry["slot"],
            config.slot_definitions,
        )
        line_items.append({
            "price": entry["price"],
            "product_name": rich_name,
            "description": f"Booking for {entry['date_str']}",
        })

    checkout_result: dict[str, Any] = {}
    if stripe_create_checkout is not None:
        checkout_result = await stripe_create_checkout(
            line_items=line_items,
            currency=config.currency,
            success_url=success_url,
            cancel_url=cancel_url,
            client_email=client_email,
            metadata=checkout_metadata,
            branding_display_name=branding_display_name,
        )
    else:
        checkout_result = {
            "id": f"cs_pending_{uuid4().hex[:12]}",
            "url": success_url,
        }

    session_id = checkout_result.get("id", "")
    checkout_url = checkout_result.get("url", "")

    # Create pending bookings
    hold_minutes = config.hold_duration_minutes or 30
    expires_at = now + dt.timedelta(minutes=hold_minutes)
    slot_pairs = [(entry["date"], entry["slot"]) for entry in booking_entries]
    booking_payloads = [
        {
            "application_id": application_id,
            "date": entry["date"],
            "slot_type": entry["slot"],
            "client_email": client_email,
            "client_name": client_name,
            "price_paid": entry["price"],
            "stripe_session_id": session_id,
            "status": "pending",
            "booking_group_id": booking_group_id,
            "metadata_": checkout_metadata,
            "expires_at": expires_at,
        }
        for entry in booking_entries
    ]

    await repo.expire_stale_pendings_for_slots(db, application_id, slot_pairs)

    try:
        bookings = await repo.create_bookings(db, booking_payloads)
    except IntegrityError:
        await db.rollback()
        raise SlotUnavailableError(
            "One or more requested slots were just booked by another user"
        )

    logger.info(
        "Multi-slot day-rate booking created",
        extra={
            "booking_group_id": booking_group_id,
            "slot_count": len(booking_entries),
            "total_price": total_price,
        },
    )

    return {
        "bookingGroupId": booking_group_id,
        "bookingIds": [str(booking.id) for booking in bookings],
        "checkoutUrl": checkout_url,
        "totalPrice": total_price,
        "priceBreakdowns": [e["breakdown"] for e in booking_entries],
        "expiresAt": expires_at.isoformat(),
        "expiresIn": hold_minutes * 60,
    }


# ---------------------------------------------------------------------------
# Admin — Config
# ---------------------------------------------------------------------------


async def get_config(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> dict[str, Any]:
    """Get the dayrate config for an application."""
    config = await repo.get_config(db, application_id)
    if config is None:
        raise ConfigNotFoundError()
    return {"config": _config_to_dict(config)}


async def update_config(
    db: AsyncSession,
    *,
    application_id: UUID,
    base_rate: int | None = None,
    available_days: list[str] | None = None,
    slots: dict | None = None,
    fill_tiers: list[dict] | None = None,
    time_tiers: list[dict] | None = None,
    horizon_weeks: int | None = None,
    meeting_link: str | None = None,
    min_notice_hours: int | None = None,
    hold_duration_minutes: int | None = None,
    timezone: str | None = None,
    slot_definitions: dict | None = None,
    currency: str | None = None,
    product_name: str | None = None,
) -> dict[str, Any]:
    """Update (upsert) the dayrate config for an application."""
    kwargs: dict[str, Any] = {}
    if base_rate is not None:
        kwargs["base_rate"] = base_rate
    if available_days is not None:
        kwargs["available_days"] = available_days
    if slots is not None:
        kwargs["slots"] = slots
    if fill_tiers is not None:
        kwargs["fill_tiers"] = fill_tiers
    if time_tiers is not None:
        kwargs["time_tiers"] = time_tiers
    if horizon_weeks is not None:
        kwargs["horizon_weeks"] = horizon_weeks
    if meeting_link is not None:
        kwargs["meeting_link"] = meeting_link
    if min_notice_hours is not None:
        kwargs["min_notice_hours"] = min_notice_hours
    if hold_duration_minutes is not None:
        kwargs["hold_duration_minutes"] = hold_duration_minutes
    if timezone is not None:
        kwargs["timezone"] = timezone
    if slot_definitions is not None:
        kwargs["slot_definitions"] = slot_definitions
    if currency is not None:
        kwargs["currency"] = currency
    if product_name is not None:
        kwargs["product_name"] = product_name

    config = await repo.upsert_config(db, application_id, **kwargs)

    logger.info(
        "DayRate config updated",
        extra={"application_id": str(application_id)},
    )

    return {
        "config": _config_to_dict(config),
        "message": "Configuration updated successfully",
    }


# ---------------------------------------------------------------------------
# Admin — Bookings
# ---------------------------------------------------------------------------


async def list_bookings(
    db: AsyncSession,
    *,
    application_id: UUID,
    status: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    client_email: str | None = None,
    enrollment_id: str | None = None,
    user_id_filter: str | None = None,
    is_free: bool | None = None,
    limit: int = 100,
    offset: int = 0,
) -> dict[str, Any]:
    """List bookings for admin view with optional filters.

    Enhanced with new filter params for checkin_call_booking.
    """
    parsed_start = None
    parsed_end = None
    parsed_user_id = None

    if start_date:
        try:
            parsed_start = dt.date.fromisoformat(start_date)
        except ValueError as exc:
            raise ValidationError(f"Invalid startDate format: {start_date}") from exc

    if end_date:
        try:
            parsed_end = dt.date.fromisoformat(end_date)
        except ValueError as exc:
            raise ValidationError(f"Invalid endDate format: {end_date}") from exc

    if user_id_filter:
        try:
            parsed_user_id = UUID(user_id_filter)
        except ValueError as exc:
            raise ValidationError(f"Invalid userId format: {user_id_filter}") from exc

    bookings, total = await repo.list_bookings(
        db,
        application_id,
        status=status,
        start_date=parsed_start,
        end_date=parsed_end,
        client_email=client_email,
        enrollment_id=enrollment_id,
        user_id=parsed_user_id,
        is_free=is_free,
        limit=limit,
        offset=offset,
    )

    return {
        "bookings": [_booking_to_dict(b) for b in bookings],
        "total": total,
    }


# ---------------------------------------------------------------------------
# Patient Cancel (US-4)
# ---------------------------------------------------------------------------


async def cancel_booking_by_owner(
    db: AsyncSession,
    *,
    application_id: UUID,
    booking_id: UUID,
    user_id: UUID | None = None,
    email: str | None = None,
    session_factory: Any = None,
) -> dict[str, Any]:
    """Cancel a booking by its owner.

    Ownership resolution (Rule 4): user_id match first, email fallback.
    """
    booking = await repo.get_booking_by_id(db, booking_id)
    if booking is None:
        raise BookingNotFoundError()

    # Verify application scope
    if booking.application_id != application_id:
        raise BookingNotFoundError()

    if booking.status == "cancelled":
        raise BookingAlreadyCancelledError()

    _verify_ownership(booking, user_id=user_id, email=email)

    await repo.update_booking(db, booking_id, status="cancelled")

    logger.info(
        "Booking cancelled by owner",
        extra={"booking_id": str(booking_id)},
    )

    # Dispatch BOOKING_CANCELLED webhook
    await _dispatch_booking_webhook(
        db,
        event_type="booking.cancelled",
        application_id=application_id,
        booking=booking,
        extra_data={"cancelledBy": "patient"},
        session_factory=session_factory,
    )

    # Build allotment info if policy exists
    allotment_info = None
    policy_key = getattr(booking, "policy_key", None)
    if policy_key:
        try:
            allotment_result = await check_allotment(
                db,
                application_id=application_id,
                policy_key=policy_key,
                user_id=user_id,
                email=email,
            )
            if allotment_result.get("allotment"):
                allotment_info = allotment_result["allotment"]
        except Exception:
            pass  # Best-effort allotment info

    result: dict[str, Any] = {
        "bookingId": str(booking_id),
        "status": "cancelled",
    }
    if allotment_info:
        result["allotment"] = allotment_info

    return result


# ---------------------------------------------------------------------------
# Allotment Checking (US-5)
# ---------------------------------------------------------------------------


async def check_allotment(
    db: AsyncSession,
    *,
    application_id: UUID,
    policy_key: str,
    user_id: UUID | None = None,
    email: str | None = None,
) -> dict[str, Any]:
    """Check a patient's booking allotment status.

    Algorithm from backend.md:
    1. Look up policy
    2. Check entitlement
    3. Count bookings in rolling window
    4. Return allotment status
    """
    policy = await repo.get_booking_policy_by_key(db, application_id, policy_key)
    if policy is None:
        # No policy -> buildooor case (policyKey: null discriminator)
        return {
            "policyKey": None,
            "entitled": False,
            "allotment": None,
            "overageRate": None,
            "overageCurrency": None,
        }

    # Lock policy row for serialized allotment check (Rule 5)
    await repo.lock_policy_for_allotment(db, application_id, policy_key)

    # Check entitlement
    entitlements = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        email=email,
        entitlement_key=policy.entitlement_key,
    )

    if not entitlements:
        return {
            "policyKey": policy.policy_key,
            "entitled": False,
            "allotment": None,
            "overageRate": None,
            "overageCurrency": None,
        }

    # Count bookings in rolling window
    now = dt.datetime.now(dt.UTC)
    period_start = now - dt.timedelta(days=policy.period_days)
    used = await repo.count_allotment_bookings(
        db,
        application_id,
        period_start,
        user_id=user_id,
        email=email,
    )
    remaining = max(0, policy.free_bookings_per_period - used)

    return {
        "policyKey": policy.policy_key,
        "entitled": True,
        "allotment": {
            "total": policy.free_bookings_per_period,
            "used": used,
            "remaining": remaining,
            "periodDays": policy.period_days,
            "periodStart": period_start.isoformat(),
            "periodEnd": now.isoformat(),
        },
        "overageRate": policy.overage_rate,
        "overageCurrency": policy.overage_currency,
    }


# ---------------------------------------------------------------------------
# Booking Policy CRUD (US-7)
# ---------------------------------------------------------------------------


async def create_booking_policy(
    db: AsyncSession,
    *,
    application_id: UUID,
    policy_key: str,
    entitlement_key: str,
    free_bookings_per_period: int = 0,
    period_days: int = 28,
    overage_rate: int | None = None,
    overage_currency: str = "usd",
    overage_product_name: str | None = None,
    reschedule_is_free: bool = True,
    metadata: dict | None = None,
) -> dict[str, Any]:
    """Create a booking policy. Returns the policy dict."""
    # Check for duplicate
    existing = await repo.get_booking_policy_by_key(db, application_id, policy_key)
    if existing is not None:
        raise PolicyAlreadyExistsError(
            f"Policy '{policy_key}' already exists for this application"
        )

    policy = await repo.create_booking_policy(
        db,
        application_id=application_id,
        policy_key=policy_key,
        entitlement_key=entitlement_key,
        free_bookings_per_period=free_bookings_per_period,
        period_days=period_days,
        overage_rate=overage_rate,
        overage_currency=overage_currency,
        overage_product_name=overage_product_name,
        reschedule_is_free=reschedule_is_free,
        metadata_=metadata or {},
    )

    logger.info(
        "Booking policy created",
        extra={"policy_key": policy_key, "application_id": str(application_id)},
    )

    return _policy_to_dict(policy)


async def list_booking_policies(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> list[dict[str, Any]]:
    """List active booking policies for an application."""
    policies = await repo.list_booking_policies(db, application_id)
    return [_policy_to_dict(p) for p in policies]


async def update_booking_policy(
    db: AsyncSession,
    *,
    policy_id: UUID,
    application_id: UUID,
    **kwargs: Any,
) -> dict[str, Any]:
    """Update a booking policy. Returns the updated policy dict."""
    # Map camelCase field names to snake_case
    update_kwargs: dict[str, Any] = {}
    field_map = {
        "entitlement_key": "entitlement_key",
        "free_bookings_per_period": "free_bookings_per_period",
        "period_days": "period_days",
        "overage_rate": "overage_rate",
        "overage_currency": "overage_currency",
        "overage_product_name": "overage_product_name",
        "reschedule_is_free": "reschedule_is_free",
        "is_active": "is_active",
        "metadata": "metadata",
    }

    for key, value in kwargs.items():
        if key in field_map and value is not None:
            update_kwargs[field_map[key]] = value

    policy = await repo.update_booking_policy(
        db, policy_id, application_id, **update_kwargs
    )
    if policy is None:
        raise PolicyNotFoundError()

    logger.info("Booking policy updated", extra={"policy_id": str(policy_id)})

    return _policy_to_dict(policy)


async def delete_booking_policy(
    db: AsyncSession,
    *,
    policy_id: UUID,
    application_id: UUID,
) -> dict[str, Any]:
    """Delete a booking policy."""
    deleted = await repo.delete_booking_policy(db, policy_id, application_id)
    if not deleted:
        raise PolicyNotFoundError()

    logger.info("Booking policy deleted", extra={"policy_id": str(policy_id)})

    return {"success": True}


# ---------------------------------------------------------------------------
# Webhook Dispatch Helpers (Rule 6)
# ---------------------------------------------------------------------------


async def _dispatch_booking_webhook(
    db: AsyncSession,
    *,
    event_type: str,
    application_id: UUID,
    booking: DayRateBooking,
    extra_data: dict[str, Any] | None = None,
    session_factory: Any = None,
) -> None:
    """Dispatch a booking webhook event (best-effort)."""
    try:
        data: dict[str, Any] = {
            "bookingId": str(booking.id),
            "applicationId": str(booking.application_id),
            "userId": str(booking.user_id) if booking.user_id else None,
            "clientEmail": booking.client_email,
            "clientName": booking.client_name,
            "date": booking.date.isoformat() if booking.date else None,
            "slot": booking.slot_type,
            "status": booking.status,
            "isFree": getattr(booking, "is_free", False),
            "policyKey": getattr(booking, "policy_key", None),
            "enrollmentId": getattr(booking, "enrollment_id", None),
            "replacesBookingId": (
                str(booking.replaces_booking_id)
                if getattr(booking, "replaces_booking_id", None)
                else None
            ),
        }
        if extra_data:
            data.update(extra_data)

        await webhook_service.trigger_event(
            db,
            event_type=event_type,
            application_id=application_id,
            data=data,
            user_id=booking.user_id,
            session_factory=session_factory,
        )
    except Exception:
        logger.exception(
            "Failed to dispatch booking webhook",
            extra={"event_type": event_type, "booking_id": str(booking.id)},
        )


async def _dispatch_reschedule_webhook(
    db: AsyncSession,
    *,
    application_id: UUID,
    old_booking: DayRateBooking,
    new_booking: DayRateBooking,
    session_factory: Any = None,
) -> None:
    """Dispatch a BOOKING_RESCHEDULED webhook event."""
    try:
        data = {
            "oldBookingId": str(old_booking.id),
            "newBookingId": str(new_booking.id),
            "applicationId": str(application_id),
            "userId": str(new_booking.user_id) if new_booking.user_id else None,
            "clientEmail": new_booking.client_email,
            "oldDate": old_booking.date.isoformat() if old_booking.date else None,
            "oldSlot": old_booking.slot_type,
            "newDate": new_booking.date.isoformat() if new_booking.date else None,
            "newSlot": new_booking.slot_type,
            "isFree": getattr(new_booking, "is_free", False),
            "policyKey": getattr(new_booking, "policy_key", None),
            "enrollmentId": getattr(new_booking, "enrollment_id", None),
        }

        await webhook_service.trigger_event(
            db,
            event_type="booking.rescheduled",
            application_id=application_id,
            data=data,
            user_id=new_booking.user_id,
            session_factory=session_factory,
        )
    except Exception:
        logger.exception(
            "Failed to dispatch reschedule webhook",
            extra={
                "old_booking_id": str(old_booking.id),
                "new_booking_id": str(new_booking.id),
            },
        )


# ---------------------------------------------------------------------------
# Upcoming bookings for user batch (US-8, Rule 7)
# ---------------------------------------------------------------------------


async def get_upcoming_bookings_for_users(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_ids: list[str],
    emails: dict[str, str],
) -> dict[str, list[dict[str, Any]]]:
    """Get upcoming bookings (next 28 days) for a batch of users.

    Two bounded queries: one by user_id, one by email for legacy bookings.
    Returns {user_id: [booking_info, ...]}.

    Args:
        emails: Mapping of {user_id: email} for email fallback lookups.
    """
    now = dt.datetime.now(dt.UTC)
    today = now.date()
    end_date = today + dt.timedelta(days=28)

    user_uuids = []
    for uid in user_ids:
        try:
            user_uuids.append(UUID(uid))
        except ValueError:
            continue

    # Query 1: bookings by user_id
    bookings_by_user_id = await repo.get_upcoming_bookings_by_user_ids(
        db, application_id, user_uuids, today, end_date
    )

    # Query 2: bookings by email (for legacy bookings without user_id)
    email_list = list(emails.values())
    bookings_by_email = await repo.get_upcoming_bookings_by_emails(
        db, application_id, email_list, today, end_date
    )

    # Build reverse map: email -> user_id
    email_to_user_id: dict[str, str] = {v: k for k, v in emails.items()}

    # Merge results
    result: dict[str, list[dict[str, Any]]] = {uid: [] for uid in user_ids}

    for booking in bookings_by_user_id:
        uid = str(booking.user_id)
        if uid in result:
            result[uid].append({
                "bookingId": str(booking.id),
                "date": booking.date.isoformat(),
                "slot": booking.slot_type,
                "status": booking.status,
                "isFree": getattr(booking, "is_free", False),
                "enrollmentId": getattr(booking, "enrollment_id", None),
            })

    for booking in bookings_by_email:
        email = booking.client_email
        if not email:
            continue
        matched_user_id = email_to_user_id.get(email)
        if matched_user_id and matched_user_id in result:
            # Avoid duplicates (booking may already be matched by user_id)
            existing_ids = {b["bookingId"] for b in result[matched_user_id]}
            booking_id = str(booking.id)
            if booking_id not in existing_ids:
                result[matched_user_id].append({
                    "bookingId": booking_id,
                    "date": booking.date.isoformat(),
                    "slot": booking.slot_type,
                    "status": booking.status,
                    "isFree": getattr(booking, "is_free", False),
                    "enrollmentId": getattr(booking, "enrollment_id", None),
                })

    # Sort each user's bookings by date
    for uid in result:
        result[uid].sort(key=lambda b: b["date"])

    return result
