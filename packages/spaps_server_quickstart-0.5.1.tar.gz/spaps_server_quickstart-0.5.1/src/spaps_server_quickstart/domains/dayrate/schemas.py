"""Pydantic request/response schemas for dayrate endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, ValidationInfo, field_validator

from ..redirects import validate_redirect_url_format


# ---------------------------------------------------------------------------
# Shared types
# ---------------------------------------------------------------------------


class PriceBreakdownOut(BaseModel):
    """Price breakdown matching SDK ``PriceBreakdown`` type."""

    baseRate: int
    fillMultiplier: float
    timeMultiplier: float
    finalPrice: int


class SlotInfo(BaseModel):
    """A single availability slot with its calculated price."""

    date: str
    dayOfWeek: str
    slot: str
    price: int
    available: bool
    breakdown: PriceBreakdownOut


class DayRateConfigOut(BaseModel):
    """Canonical representation of a dayrate config."""

    id: str
    application_id: str
    base_rate: int
    available_days: list[str] | None = None
    slots: dict[str, Any] | None = None
    fill_tiers: list[dict[str, Any]] | None = None
    time_tiers: list[dict[str, Any]] | None = None
    horizon_weeks: int
    meeting_link: str | None = None
    min_notice_hours: int
    hold_duration_minutes: int
    timezone: str
    slot_definitions: dict[str, Any] | None = None
    currency: str
    product_name: str | None = None
    created_at: str
    updated_at: str


class DayRateBookingOut(BaseModel):
    """Canonical representation of a dayrate booking.

    Enhanced with checkin_call_booking fields.
    """

    id: str
    application_id: str
    user_id: str | None = None
    date: str
    slot_type: str
    client_email: str
    client_name: str
    price_paid: int
    stripe_session_id: str | None = None
    stripe_payment_intent_id: str | None = None
    status: str
    metadata: dict[str, Any] | None = None
    booking_group_id: str | None = None
    expires_at: str | None = None
    # checkin_call_booking additions
    enrollment_id: str | None = None
    replaces_booking_id: str | None = None
    policy_key: str | None = None
    is_free: bool = False
    created_at: str
    updated_at: str


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class BookRequest(BaseModel):
    """POST /dayrate/book body.

    Enhanced with policy support for checkin_call_booking.
    All new fields are optional for backward compatibility.
    """

    date: str = Field(..., description="Booking date in YYYY-MM-DD format")
    slot: str = Field(..., description="Slot type (e.g. AM, PM, 10:00)")
    clientEmail: str = Field(..., description="Client email address")
    clientName: str = Field(..., description="Client name")
    successUrl: str = Field(..., description="Stripe success redirect URL")
    cancelUrl: str = Field(..., description="Stripe cancel redirect URL")
    brandingDisplayName: str | None = Field(
        default=None,
        description="Optional Checkout display name shown on Stripe hosted page",
    )
    # --- checkin_call_booking additions (all optional, backward-compatible) ---
    policyKey: str | None = Field(default=None, description="Booking policy key")
    enrollmentId: str | None = Field(default=None, description="Enrollment ID (cross-system ref)")
    replacesBookingId: str | None = Field(default=None, description="Booking ID to reschedule")
    userId: str | None = Field(
        default=None,
        description=(
            "User ID for ownership. Publishable-key free bookings ignore caller-"
            "supplied ownership and bind eligibility to the authenticated user."
        ),
    )

    @field_validator("successUrl", "cancelUrl")
    @classmethod
    def validate_redirect_urls(cls, value: str, info: ValidationInfo) -> str:
        return validate_redirect_url_format(
            value,
            field_name=info.field_name or "redirect_url",
        )


class BookMultiSlotItem(BaseModel):
    """A single slot within a book-multi request."""

    date: str
    slot: str


class BookMultiRequest(BaseModel):
    """POST /dayrate/book-multi body."""

    slots: list[BookMultiSlotItem] = Field(
        ..., min_length=1, description="List of slots to book"
    )
    clientEmail: str = Field(..., description="Client email address")
    clientName: str = Field(..., description="Client name")
    successUrl: str = Field(..., description="Stripe success redirect URL")
    cancelUrl: str = Field(..., description="Stripe cancel redirect URL")
    brandingDisplayName: str | None = Field(
        default=None,
        description="Optional Checkout display name shown on Stripe hosted page",
    )

    @field_validator("successUrl", "cancelUrl")
    @classmethod
    def validate_redirect_urls(cls, value: str, info: ValidationInfo) -> str:
        return validate_redirect_url_format(
            value,
            field_name=info.field_name or "redirect_url",
        )


class UpdateConfigRequest(BaseModel):
    """PUT /dayrate/admin/config body."""

    base_rate: int | None = None
    available_days: list[str] | None = None
    slots: dict[str, Any] | None = None
    fill_tiers: list[dict[str, Any]] | None = None
    time_tiers: list[dict[str, Any]] | None = None
    horizon_weeks: int | None = None
    meeting_link: str | None = None
    min_notice_hours: int | None = None
    hold_duration_minutes: int | None = None
    timezone: str | None = None
    slot_definitions: dict[str, Any] | None = None
    currency: str | None = None
    product_name: str | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class AvailabilityResponse(BaseModel):
    """GET /dayrate/availability -- success payload."""

    currentFillRate: float
    totalSlots: int
    bookedSlots: int
    baseRate: int
    meetingLink: str | None
    slots: list[SlotInfo]


class BookResponse(BaseModel):
    """POST /dayrate/book -- success payload (paid path)."""

    bookingId: str
    checkoutUrl: str
    price: int
    breakdown: PriceBreakdownOut
    expiresAt: str
    expiresIn: int


class AllotmentInfo(BaseModel):
    """Allotment status within a booking response."""

    total: int
    used: int
    remaining: int


class FreeBookResponse(BaseModel):
    """POST /dayrate/book -- success payload (free path)."""

    bookingId: str
    status: str
    isFree: bool
    allotment: AllotmentInfo


class BookMultiResponse(BaseModel):
    """POST /dayrate/book-multi -- success payload."""

    bookingGroupId: str
    bookingIds: list[str]
    checkoutUrl: str
    totalPrice: int
    priceBreakdowns: list[PriceBreakdownOut]
    expiresAt: str
    expiresIn: int


class CheckoutStatusBookingOut(BaseModel):
    """Minimal booking summary for a guest checkout status poll."""

    bookingId: str
    date: str
    slot: str
    status: str
    price: int
    bookingGroupId: str | None = None


class CheckoutStatusResponse(BaseModel):
    """GET /dayrate/checkout-status -- success payload."""

    sessionId: str
    status: str
    matched: int
    confirmedCount: int
    pendingCount: int
    otherCount: int
    bookings: list[CheckoutStatusBookingOut]


class GetConfigResponse(BaseModel):
    """GET /dayrate/admin/config -- success payload."""

    config: DayRateConfigOut


class UpdateConfigResponse(BaseModel):
    """PUT /dayrate/admin/config -- success payload."""

    config: DayRateConfigOut
    message: str


class ListBookingsResponse(BaseModel):
    """GET /dayrate/admin/bookings -- success payload."""

    bookings: list[DayRateBookingOut]
    total: int


# ---------------------------------------------------------------------------
# Cancel endpoint
# ---------------------------------------------------------------------------


class CancelRequest(BaseModel):
    """POST /dayrate/cancel body."""

    bookingId: str = Field(..., description="Booking ID to cancel")
    userId: str | None = Field(default=None, description="Caller user ID")
    email: str | None = Field(default=None, description="Caller email (fallback)")


class CancelAllotmentInfo(BaseModel):
    """Allotment status after cancel (optional)."""

    total: int
    used: int
    remaining: int


class CancelResponse(BaseModel):
    """POST /dayrate/cancel -- success payload."""

    bookingId: str
    status: str
    allotment: CancelAllotmentInfo | None = None


# ---------------------------------------------------------------------------
# Allotment endpoint
# ---------------------------------------------------------------------------


class AllotmentDetailInfo(BaseModel):
    """Full allotment details for the allotment endpoint."""

    total: int
    used: int
    remaining: int
    periodDays: int
    periodStart: str
    periodEnd: str


class AllotmentResponse(BaseModel):
    """GET /dayrate/allotment -- success payload."""

    policyKey: str | None
    entitled: bool
    allotment: AllotmentDetailInfo | None = None
    overageRate: int | None = None
    overageCurrency: str | None = None


# ---------------------------------------------------------------------------
# Booking Policy CRUD
# ---------------------------------------------------------------------------


class BookingPolicyOut(BaseModel):
    """Canonical representation of a booking policy."""

    id: str
    applicationId: str
    policyKey: str
    entitlementKey: str
    freeBookingsPerPeriod: int
    periodDays: int
    overageRate: int | None = None
    overageCurrency: str
    overageProductName: str | None = None
    rescheduleIsFree: bool
    isActive: bool
    metadata: dict[str, Any] | None = None


class CreatePolicyRequest(BaseModel):
    """POST /dayrate/admin/policies body."""

    policyKey: str = Field(..., description="Unique policy key per app")
    entitlementKey: str = Field(..., description="Entitlement key for free access")
    freeBookingsPerPeriod: int = Field(default=0, ge=0)
    periodDays: int = Field(default=28, ge=1)
    overageRate: int | None = Field(default=None, ge=0, description="Cents, NULL = extras blocked")
    overageCurrency: str = Field(default="usd")
    overageProductName: str | None = None
    rescheduleIsFree: bool = Field(default=True)
    metadata: dict[str, Any] | None = None


class UpdatePolicyRequest(BaseModel):
    """PUT /dayrate/admin/policies/:id body (partial update)."""

    entitlementKey: str | None = None
    freeBookingsPerPeriod: int | None = Field(default=None, ge=0)
    periodDays: int | None = Field(default=None, ge=1)
    overageRate: int | None = None
    overageCurrency: str | None = None
    overageProductName: str | None = None
    rescheduleIsFree: bool | None = None
    isActive: bool | None = None
    metadata: dict[str, Any] | None = None


class ListPoliciesResponse(BaseModel):
    """GET /dayrate/admin/policies -- success payload."""

    policies: list[BookingPolicyOut]


class PolicyResponse(BaseModel):
    """Single policy response (create/update)."""

    policy: BookingPolicyOut


class DeletePolicyResponse(BaseModel):
    """DELETE /dayrate/admin/policies/:id -- success payload."""

    success: bool


# ---------------------------------------------------------------------------
# Upcoming bookings for user batch
# ---------------------------------------------------------------------------


class UpcomingBookingOut(BaseModel):
    """A single upcoming booking in the batch response."""

    bookingId: str
    date: str
    slot: str
    status: str
    isFree: bool
    enrollmentId: str | None = None
