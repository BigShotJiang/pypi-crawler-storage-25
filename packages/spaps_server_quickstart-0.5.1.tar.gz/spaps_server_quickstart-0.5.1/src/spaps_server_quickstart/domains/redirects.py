"""Shared validation for externally controlled redirect URLs."""

from __future__ import annotations

from urllib.parse import SplitResult, urlsplit

from ..middleware.origin_validation import validate_origin
from .errors import ValidationError


_PRODUCTION_ENVS = {"production", "prod"}
_LOCAL_REDIRECT_HOSTS = {"localhost", "127.0.0.1", "::1", "0.0.0.0"}
_GLOBAL_WILDCARD_ORIGINS = {"*", "http://*", "https://*"}


def validate_redirect_url_format(value: str, *, field_name: str = "redirect_url") -> str:
    """Validate that a redirect URL is absolute HTTP(S) without userinfo."""
    normalized = str(value).strip()
    _parse_redirect_url(normalized, field_name=field_name)
    return normalized


def validate_payment_redirect_urls(
    *,
    success_url: str,
    cancel_url: str,
    settings: object,
    application: object,
    success_field: str = "success_url",
    cancel_field: str = "cancel_url",
) -> tuple[str, str]:
    """Validate the success/cancel redirect pair used by payment checkout flows."""
    return (
        validate_payment_redirect_url(
            success_url,
            field_name=success_field,
            settings=settings,
            application=application,
        ),
        validate_payment_redirect_url(
            cancel_url,
            field_name=cancel_field,
            settings=settings,
            application=application,
        ),
    )


def validate_payment_redirect_url(
    value: str,
    *,
    field_name: str,
    settings: object,
    application: object,
) -> str:
    """Validate a payment redirect URL against environment and app-origin policy."""
    normalized = validate_redirect_url_format(value, field_name=field_name)
    parsed = _parse_redirect_url(normalized, field_name=field_name)
    is_production = _is_production(settings)

    if parsed.scheme.lower() != "https":
        if is_production:
            raise ValidationError(f"{field_name} must use https:// in production")
        if not _is_local_redirect_host(parsed.hostname):
            raise ValidationError(
                f"{field_name} must use https:// unless it targets localhost in non-production"
            )

    allowed_origins = _application_allowed_origins(application)
    if _has_global_wildcard_origin(allowed_origins):
        if is_production:
            raise ValidationError(
                f"{field_name} cannot be validated against wildcard application "
                "allowed_origins in production"
            )
        return normalized

    origin = _origin_from_url(parsed)
    if not validate_origin(origin, allowed_origins):
        raise ValidationError(
            f"{field_name} origin is not allowed for this application"
        )

    return normalized


def _parse_redirect_url(value: str, *, field_name: str) -> SplitResult:
    if not value:
        raise ValidationError(f"{field_name} is required")

    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError as exc:
        raise ValidationError(f"{field_name} must be a valid absolute URL") from exc

    if parsed.scheme.lower() not in {"http", "https"}:
        raise ValidationError(f"{field_name} must use http:// or https://")
    if not parsed.netloc or not parsed.hostname:
        raise ValidationError(f"{field_name} must be an absolute URL")
    if parsed.username or parsed.password:
        raise ValidationError(f"{field_name} must not include credentials")
    if port is not None and not (0 < port <= 65535):
        raise ValidationError(f"{field_name} has an invalid port")

    return parsed


def _is_production(settings: object) -> bool:
    env = getattr(settings, "env", "")
    return isinstance(env, str) and env.strip().lower() in _PRODUCTION_ENVS


def _is_local_redirect_host(hostname: str | None) -> bool:
    return (hostname or "").strip("[]").lower() in _LOCAL_REDIRECT_HOSTS


def _application_allowed_origins(application: object) -> list[str]:
    raw_origins = getattr(application, "allowed_origins", None)
    if not isinstance(raw_origins, (list, tuple, set, frozenset)):
        return []

    origins: list[str] = []
    for raw_origin in raw_origins:
        if not isinstance(raw_origin, str):
            continue
        origin = raw_origin.strip().rstrip("/")
        if origin:
            origins.append(origin)
    return origins


def _has_global_wildcard_origin(origins: list[str]) -> bool:
    return any(origin.lower() in _GLOBAL_WILDCARD_ORIGINS for origin in origins)


def _origin_from_url(parsed: SplitResult) -> str:
    host = (parsed.hostname or "").lower()
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"

    origin = f"{parsed.scheme.lower()}://{host}"
    if parsed.port is not None:
        origin = f"{origin}:{parsed.port}"
    return origin
