"""Business logic for the CFO / QuickBooks domain.

Coordinates repository calls, QuickBooks API interactions, token
encryption, and auth code management. This module is pure domain
logic -- no FastAPI imports.
"""

from __future__ import annotations

import base64
import logging
import secrets
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import urlencode
from uuid import UUID, uuid4

from sqlalchemy.ext.asyncio import AsyncSession

from ..errors import ValidationError
from . import quickbooks as qb
from . import repository as repo
from .errors import (
    CfoConnectionAlreadyRevokedError,
    CfoConnectionNotFoundError,
    CfoInvalidCodeError,
    CfoOAuthError,
)
from .models import CfoConnection

logger = logging.getLogger(__name__)

# Default expiry settings
DEFAULT_MAGIC_LINK_EXPIRY_HOURS = 24
DEFAULT_AUTH_CODE_EXPIRY_MINUTES = 5
RUNTIME_EXPORTABLE_STATUSES = {"active", "connected"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _require_oauth_config(*, client_id: str, redirect_uri: str) -> None:
    """Ensure required OAuth settings are present before building auth URLs."""
    if not client_id or not client_id.strip():
        raise ValidationError(
            "QuickBooks OAuth is not configured (missing QUICKBOOKS_CLIENT_ID)"
        )
    if not redirect_uri or not redirect_uri.strip():
        raise ValidationError(
            "QuickBooks OAuth is not configured (missing redirect URI)"
        )


def _connection_to_dict(conn: CfoConnection) -> dict[str, Any]:
    """Convert a CfoConnection to a serialisable dict."""
    return {
        "id": str(conn.id),
        "user_id": str(conn.user_id) if conn.user_id else None,
        "client_name": conn.client_name,
        "company_name": conn.company_name,
        "realm_id": conn.realm_id,
        "status": conn.status,
        "accounting_method": conn.accounting_method,
        "risk_tier": conn.risk_tier,
        "connected_at": conn.connected_at.isoformat() if conn.connected_at else None,
        "token_expires_at": (
            conn.token_expires_at.isoformat() if conn.token_expires_at else None
        ),
        "created_at": conn.created_at.isoformat() if conn.created_at else None,
    }


def _connection_to_user_dict(
    conn: CfoConnection,
    connected_by: str | None = None,
) -> dict[str, Any]:
    """Convert a CfoConnection to a user-facing dict (camelCase keys)."""
    result: dict[str, Any] = {
        "id": str(conn.id),
        "status": conn.status,
        "companyName": conn.company_name,
        "realmId": conn.realm_id,
        "connectedAt": conn.connected_at.isoformat() if conn.connected_at else None,
        "tokenExpiresAt": (
            conn.token_expires_at.isoformat() if conn.token_expires_at else None
        ),
    }
    if connected_by is not None:
        result["connectedBy"] = connected_by
    return result


def encrypt_refresh_token(token: str, public_key_pem: str) -> str:
    """Encrypt a refresh token using RSA public key.

    Uses OAEP padding with SHA-256. Returns base64-encoded ciphertext.
    """
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding

        public_key = serialization.load_pem_public_key(
            public_key_pem.encode("utf-8")
        )
        ciphertext = public_key.encrypt(  # type: ignore[union-attr]
            token.encode("utf-8"),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )
        return base64.b64encode(ciphertext).decode("utf-8")
    except (ValueError, TypeError, AttributeError) as exc:
        logger.exception("Failed to encrypt refresh token")
        raise CfoOAuthError("Failed to encrypt refresh token") from exc


def generate_auth_code() -> str:
    """Generate a 64-character hex auth code."""
    return secrets.token_hex(32)


def _oauth_error_redirect(frontend_url: str, message: str) -> dict[str, Any]:
    """Build a standardized OAuth error redirect payload."""
    return {
        "redirect": f"{frontend_url}/cfo/expired?error={message}",
        "error": True,
    }


def _credential_scrub_update(*, status: str) -> dict[str, Any]:
    """Return the update payload that disables runtime credential export."""
    return {
        "status": status,
        "encrypted_refresh_token": None,
        "token_expires_at": None,
    }


# ---------------------------------------------------------------------------
# Magic link flow (admin-generated)
# ---------------------------------------------------------------------------


async def generate_magic_link(
    db: AsyncSession,
    *,
    client_name: str,
    frontend_url: str,
    magic_link_expiry_hours: int = DEFAULT_MAGIC_LINK_EXPIRY_HOURS,
) -> dict[str, Any]:
    """Generate a magic link for a client to connect QuickBooks.

    Creates a CfoConnection (pending) and a CfoMagicLink, returns
    the URL, token, expiry, and connection ID.
    """
    # Create pending connection
    connection = await repo.create_connection(
        db,
        client_name=client_name,
        status="pending",
    )

    # Create magic link
    token = secrets.token_urlsafe(32)
    expires_at = datetime.now(UTC) + timedelta(hours=magic_link_expiry_hours)

    await repo.create_magic_link(
        db,
        token=token,
        client_name=client_name,
        connection_id=connection.id,
        expires_at=expires_at,
    )

    url = f"{frontend_url}/cfo/connect?token={token}"

    return {
        "url": url,
        "token": token,
        "expiresAt": expires_at.isoformat(),
        "connectionId": str(connection.id),
    }


async def validate_magic_link_token(
    db: AsyncSession,
    *,
    token: str,
    client_id: str,
    redirect_uri: str,
) -> dict[str, Any]:
    """Validate a magic link token and return the auth URL.

    Returns { valid, clientName?, authUrl?, expiresAt? }.
    """
    link = await repo.get_magic_link_by_token(db, token)

    if link is None:
        return {"valid": False}

    now = datetime.now(UTC)

    if link.used_at is not None:
        return {"valid": False}

    if link.expires_at < now:
        return {"valid": False}

    _require_oauth_config(client_id=client_id, redirect_uri=redirect_uri)

    # Build Intuit auth URL with token as state
    state = token
    auth_url = qb.build_authorization_url(
        client_id=client_id,
        redirect_uri=redirect_uri,
        state=state,
    )

    return {
        "valid": True,
        "clientName": link.client_name,
        "authUrl": auth_url,
        "expiresAt": link.expires_at.isoformat(),
    }


# ---------------------------------------------------------------------------
# OAuth callback processing
# ---------------------------------------------------------------------------


async def process_oauth_callback(
    db: AsyncSession,
    *,
    code: str,
    state: str,
    realm_id: str,
    client_id: str,
    client_secret: str,
    redirect_uri: str,
    cfo_public_key: str,
    frontend_url: str,
    auth_code_expiry_minutes: int = DEFAULT_AUTH_CODE_EXPIRY_MINUTES,
) -> dict[str, Any]:
    """Process the Intuit OAuth callback.

    Handles both magic-link flow (state=token) and direct/user flow.
    Returns a dict with redirect info.
    """
    # Exchange authorization code for tokens
    try:
        token_data = await qb.exchange_code_for_tokens(
            code=code,
            redirect_uri=redirect_uri,
            client_id=client_id,
            client_secret=client_secret,
        )
    except qb.QuickBooksAPIError as exc:
        logger.error("OAuth code exchange failed", extra={"error": str(exc)})
        return {
            "redirect": f"{frontend_url}/cfo/expired?error=OAuth+exchange+failed",
            "error": True,
        }

    access_token = token_data.get("access_token", "")
    refresh_token = token_data.get("refresh_token", "")
    expires_in = token_data.get("expires_in", 3600)

    if not refresh_token:
        logger.error("OAuth callback missing refresh token")
        return _oauth_error_redirect(frontend_url, "OAuth+exchange+failed")

    public_key = cfo_public_key.strip() if isinstance(cfo_public_key, str) else ""
    if not public_key:
        logger.error("OAuth callback rejected: CFO public key missing for refresh-token encryption")
        return _oauth_error_redirect(frontend_url, "Token+encryption+not+configured")

    # Fetch company and user info
    company_info = await qb.fetch_company_info(
        access_token=access_token,
        realm_id=realm_id,
    )
    user_info = await qb.fetch_user_info(access_token=access_token)

    company_name = (
        company_info.get("CompanyName")
        or company_info.get("companyName")
        or company_info.get("LegalName")
        or ""
    )

    # Encrypt refresh token (fail closed if encryption fails)
    try:
        encrypted_token = encrypt_refresh_token(refresh_token, public_key)
    except CfoOAuthError:
        logger.error("OAuth callback rejected: failed to encrypt refresh token")
        return _oauth_error_redirect(frontend_url, "Token+encryption+failed")

    token_expires_at = datetime.now(UTC) + timedelta(seconds=expires_in)

    # Check if state is a magic link token
    magic_link = await repo.get_magic_link_by_token(db, state)

    if magic_link and magic_link.used_at is None and magic_link.expires_at > datetime.now(UTC):
        # Magic link flow -- complete the existing connection
        await repo.mark_magic_link_used(db, magic_link.id)

        if magic_link.connection_id:
            await repo.update_connection(
                db,
                magic_link.connection_id,
                realm_id=realm_id,
                company_name=company_name,
                encrypted_refresh_token=encrypted_token,
                token_expires_at=token_expires_at,
                accounting_method=company_info.get("FiscalYearStartMonth"),
                status="connected",
                connected_at=datetime.now(UTC),
            )

        # Build redirect URL with connection_id and optional company_id
        redirect_params: dict[str, str] = {"company": company_name}
        if magic_link.connection_id:
            redirect_params["connection_id"] = str(magic_link.connection_id)
            # Read the connection to check for company_id
            conn = await repo.get_connection_by_id(db, magic_link.connection_id)
            if conn and conn.company_id:
                redirect_params["company_id"] = str(conn.company_id)

        return {
            "redirect": f"{frontend_url}/cfo/success?{urlencode(redirect_params)}",
            "error": False,
            "connection_id": str(magic_link.connection_id) if magic_link.connection_id else None,
        }

    # Check if state is a user-initiated connection UUID
    try:
        connection_id = UUID(state)
        existing_conn = await repo.get_connection_by_id(db, connection_id)
        if existing_conn and existing_conn.status == "pending":
            # User-initiated flow
            await repo.update_connection(
                db,
                connection_id,
                realm_id=realm_id,
                company_name=company_name,
                encrypted_refresh_token=encrypted_token,
                token_expires_at=token_expires_at,
                status="connected",
                connected_at=datetime.now(UTC),
            )

            # Build redirect URL with connection_id and optional company_id
            redirect_params = {
                "connection_id": str(connection_id),
                "company": company_name,
            }
            if existing_conn.company_id:
                redirect_params["company_id"] = str(existing_conn.company_id)

            return {
                "redirect": f"{frontend_url}/cfo/success?{urlencode(redirect_params)}",
                "error": False,
                "connection_id": str(connection_id),
            }
    except (ValueError, AttributeError):
        # State is not a valid UUID — reject (only UUID-formatted states are legitimate)
        logger.warning(
            "OAuth callback with unrecognized state",
            extra={"state_prefix": state[:8] if state else ""},
        )
        return {
            "redirect": f"{frontend_url}/cfo/expired?error=Invalid+OAuth+state",
            "error": True,
        }

    # Direct flow -- create connection, user, and auth code
    email = user_info.get("email", "")

    connection = await repo.create_connection(
        db,
        realm_id=realm_id,
        company_name=company_name,
        encrypted_refresh_token=encrypted_token,
        token_expires_at=token_expires_at,
        status="connected",
        connected_at=datetime.now(UTC),
    )

    # Generate one-time auth code
    hex_code = generate_auth_code()
    auth_code_expires = datetime.now(UTC) + timedelta(
        minutes=auth_code_expiry_minutes
    )

    # Encrypt auth data (tokens + user info)
    encrypted_auth_data = None
    if public_key:
        import json

        auth_data = json.dumps({
            "access_token": access_token,
            "refresh_token": refresh_token,
            "email": email,
            "user_info": user_info,
        })
        try:
            encrypted_auth_data = encrypt_refresh_token(auth_data, public_key)
        except CfoOAuthError:
            logger.error("OAuth callback rejected: failed to encrypt auth code payload")
            return _oauth_error_redirect(frontend_url, "Token+encryption+failed")

    await repo.create_auth_code(
        db,
        code=hex_code,
        user_id=None,
        company_name=company_name,
        realm_id=realm_id,
        encrypted_auth_data=encrypted_auth_data,
        expires_at=auth_code_expires,
    )

    return {
        "redirect": f"{frontend_url}/cfo/success?code={hex_code}",
        "error": False,
        "connection_id": str(connection.id),
        "auth_code": hex_code,
    }


# ---------------------------------------------------------------------------
# Exchange auth code
# ---------------------------------------------------------------------------


async def exchange_auth_code(
    db: AsyncSession,
    *,
    code: str,
) -> dict[str, Any]:
    """Exchange a one-time 64-char hex auth code for tokens + user info.

    The code is single-use. Returns INVALID_CODE if invalid/expired/used.
    """
    auth_code = await repo.get_auth_code_by_code(db, code)

    if auth_code is None:
        raise CfoInvalidCodeError()

    now = datetime.now(UTC)

    if auth_code.used_at is not None:
        raise CfoInvalidCodeError("Code has already been used")

    if auth_code.expires_at < now:
        raise CfoInvalidCodeError("Code has expired")

    # Mark as used
    await repo.mark_auth_code_used(db, auth_code.id)

    return {
        "company_name": auth_code.company_name,
        "realm_id": auth_code.realm_id,
        "user_id": str(auth_code.user_id) if auth_code.user_id else None,
        "encrypted_auth_data": auth_code.encrypted_auth_data,
    }


async def get_runtime_connection_token(
    db: AsyncSession,
    *,
    connection_id: UUID | None = None,
    realm_id: str | None = None,
    client_id: str,
    client_secret: str,
    cfo_public_key: str,
) -> dict[str, Any]:
    """Return the encrypted refresh token payload for a hosted connection.

    This is an admin-only runtime bridge for trusted CFO MCP tooling. The raw
    refresh token remains encrypted with the CFO public key at rest and in
    transit through this endpoint.
    """
    if connection_id is None and not realm_id:
        raise ValidationError("connection_id or realm_id is required")

    connection: CfoConnection | None = None
    if connection_id is not None:
        connection = await repo.get_connection_by_id(db, connection_id)
    elif realm_id is not None:
        connection = await repo.find_connection_by_realm_id(db, realm_id)

    if connection is None:
        raise CfoConnectionNotFoundError()

    if connection.status not in RUNTIME_EXPORTABLE_STATUSES:
        raise CfoConnectionNotFoundError(
            "Connection is not active for runtime token export"
        )

    if not connection.encrypted_refresh_token:
        raise CfoConnectionNotFoundError("No stored refresh token for this connection")

    normalized_client_id = client_id.strip()
    normalized_client_secret = client_secret.strip()
    normalized_public_key = cfo_public_key.strip()

    if not normalized_client_id:
        raise ValidationError("QuickBooks client ID is required")
    if not normalized_client_secret:
        raise ValidationError("QuickBooks client secret is required")
    if not normalized_public_key:
        raise ValidationError("CFO public key is required")

    encrypted_client_secret = encrypt_refresh_token(
        normalized_client_secret,
        normalized_public_key,
    )

    return {
        "connection_id": str(connection.id),
        "realm_id": connection.realm_id,
        "company_name": connection.company_name,
        "status": connection.status,
        "client_id": normalized_client_id,
        "environment": "production",
        "encrypted_refresh_token": connection.encrypted_refresh_token,
        "encrypted_client_secret": encrypted_client_secret,
    }


# ---------------------------------------------------------------------------
# Connect start (direct flow)
# ---------------------------------------------------------------------------


async def get_connect_start_url(
    *,
    client_id: str,
    redirect_uri: str,
    token: str | None = None,
) -> dict[str, Any]:
    """Generate the Intuit OAuth URL for direct connect.

    If a magic link token is provided, uses it as state.
    Otherwise generates a random UUID state.
    """
    _require_oauth_config(client_id=client_id, redirect_uri=redirect_uri)

    state = token or str(uuid4())
    auth_url = qb.build_authorization_url(
        client_id=client_id,
        redirect_uri=redirect_uri,
        state=state,
    )
    return {"authUrl": auth_url, "state": state}


# ---------------------------------------------------------------------------
# Connect with email
# ---------------------------------------------------------------------------


async def connect_with_email(
    db: AsyncSession,
    *,
    email: str,
    client_id: str,
    redirect_uri: str,
) -> dict[str, Any]:
    """Start OAuth flow for a given email (creates/finds user).

    Creates a pending connection and returns the Intuit auth URL.
    """
    if not email or not email.strip():
        raise ValidationError("Email is required")

    _require_oauth_config(client_id=client_id, redirect_uri=redirect_uri)

    connection = await repo.create_connection(
        db,
        status="pending",
    )

    state = str(connection.id)
    auth_url = qb.build_authorization_url(
        client_id=client_id,
        redirect_uri=redirect_uri,
        state=state,
    )

    return {
        "authUrl": auth_url,
        "connectionId": str(connection.id),
    }


# ---------------------------------------------------------------------------
# Admin operations
# ---------------------------------------------------------------------------


async def get_connection_status(
    db: AsyncSession,
    *,
    connection_id: UUID,
) -> dict[str, Any]:
    """Get detailed status of a connection (admin)."""
    connection = await repo.get_connection_by_id(db, connection_id)
    if connection is None:
        raise CfoConnectionNotFoundError()

    return _connection_to_dict(connection)


async def revoke_connection(
    db: AsyncSession,
    *,
    connection_id: UUID,
) -> dict[str, Any]:
    """Revoke a connection (admin).

    Hard revoke semantics:
    - status => revoked
    - encrypted refresh token removed
    - token expiry cleared
    """
    connection = await repo.get_connection_by_id(db, connection_id)
    if connection is None:
        raise CfoConnectionNotFoundError()

    if connection.status == "revoked":
        raise CfoConnectionAlreadyRevokedError()

    await repo.update_connection(
        db,
        connection_id,
        **_credential_scrub_update(status="revoked"),
    )

    logger.info(
        "CFO connection revoked",
        extra={"connection_id": str(connection_id)},
    )

    return {"revoked": True, "message": "Connection revoked successfully"}


async def list_connections(
    db: AsyncSession,
    *,
    user_id: UUID | None = None,
) -> dict[str, Any]:
    """List connections, optionally filtered by user_id (admin)."""
    connections = await repo.list_connections(db, user_id=user_id)
    return {
        "connections": [_connection_to_dict(c) for c in connections],
    }


# ---------------------------------------------------------------------------
# User operations (JWT-authenticated)
# ---------------------------------------------------------------------------


async def user_connect(
    db: AsyncSession,
    *,
    user_id: UUID,
    client_id: str,
    redirect_uri: str,
) -> dict[str, Any]:
    """User-initiated QuickBooks connection.

    Creates a pending connection linked to the user, returns the auth URL.
    """
    _require_oauth_config(client_id=client_id, redirect_uri=redirect_uri)

    connection = await repo.create_connection(
        db,
        user_id=user_id,
        status="pending",
    )

    state = str(connection.id)
    auth_url = qb.build_authorization_url(
        client_id=client_id,
        redirect_uri=redirect_uri,
        state=state,
    )

    return {
        "authUrl": auth_url,
        "connectionId": str(connection.id),
    }


async def user_status(
    db: AsyncSession,
    *,
    user_id: UUID,
) -> dict[str, Any]:
    """Get the user's primary QuickBooks connection status."""
    primary = await repo.find_user_primary_connection(db, user_id)
    total = await repo.count_user_connections(db, user_id)

    if primary is None:
        return {"connection": None, "totalConnections": total}

    return {
        "connection": _connection_to_user_dict(primary),
        "totalConnections": total,
    }


async def user_disconnect(
    db: AsyncSession,
    *,
    user_id: UUID,
) -> dict[str, Any]:
    """Disconnect the user's primary QuickBooks connection (deprecated)."""
    primary = await repo.find_user_primary_connection(db, user_id)
    if primary is None:
        raise CfoConnectionNotFoundError("No active connection found")

    await repo.update_connection(
        db,
        primary.id,
        **_credential_scrub_update(status="disconnected"),
    )

    return {"success": True, "message": "QuickBooks disconnected"}


async def user_connections(
    db: AsyncSession,
    *,
    user_id: UUID,
    include_all: bool = False,
    is_admin: bool = False,
) -> dict[str, Any]:
    """Get the user's connections, or all connections if admin + ?all=true."""
    if include_all and is_admin:
        connections = await repo.list_all_connections(db)
        return {
            "connections": [
                _connection_to_user_dict(c, connected_by=str(c.user_id) if c.user_id else None)
                for c in connections
            ],
        }

    connections = await repo.list_connections(db, user_id=user_id)
    return {
        "connections": [_connection_to_user_dict(c) for c in connections],
    }


async def user_add_connection(
    db: AsyncSession,
    *,
    user_id: UUID,
    client_id: str,
    redirect_uri: str,
    company_id: str | None = None,
) -> dict[str, Any]:
    """Add another QuickBooks company connection for the user.

    If ``company_id`` is provided (UUID string), it is stored on the
    connection row as a soft reference to the CFO company.  The
    success-page frontend uses it to auto-link the connection after
    OAuth completes.
    """
    _require_oauth_config(client_id=client_id, redirect_uri=redirect_uri)

    existing_count = await repo.count_user_connections(db, user_id)

    create_kwargs: dict[str, Any] = {
        "user_id": user_id,
        "status": "pending",
    }
    if company_id is not None:
        try:
            create_kwargs["company_id"] = UUID(company_id)
        except ValueError as exc:
            raise ValidationError("company_id must be a valid UUID") from exc

    connection = await repo.create_connection(db, **create_kwargs)

    state = str(connection.id)
    auth_url = qb.build_authorization_url(
        client_id=client_id,
        redirect_uri=redirect_uri,
        state=state,
    )

    return {
        "authUrl": auth_url,
        "connectionId": str(connection.id),
        "existingConnections": existing_count,
    }


async def user_delete_connection(
    db: AsyncSession,
    *,
    user_id: UUID,
    connection_id: UUID,
) -> dict[str, Any]:
    """Disconnect a specific QuickBooks connection for the user.

    Only the owning user can disconnect their own connections.
    """
    connection = await repo.get_connection_by_id(db, connection_id)
    if connection is None:
        raise CfoConnectionNotFoundError()

    if connection.user_id != user_id:
        raise CfoConnectionNotFoundError("Connection not found for this user")

    await repo.update_connection(
        db,
        connection_id,
        **_credential_scrub_update(status="disconnected"),
    )

    return {"success": True, "message": "Connection disconnected"}
