"""HTTP routes for the admin / applications domain.

All endpoints live under the ``/admin`` prefix and require API-key
authentication only (no JWT).

The response envelope ``{ success, data, error, metadata }`` is
applied automatically by ``ResponseEnvelopeMiddleware`` -- handlers
return the raw *data* portion only.
"""

from __future__ import annotations

import logging
import re

from fastapi import APIRouter

from ...middleware.spaps_deps import Application, DbSession, SuperAdminUser
from ..errors import ValidationError
from . import service
from .schemas import (
    ApplicationInfo,
    CreateAppApplicationOut,
    CreateAppRequest,
    CreateAppResponse,
    ListAppsResponse,
    RotateApiKeyResponse,
)

logger = logging.getLogger(__name__)

_SLUG_RE = re.compile(r"^[a-z0-9-]+$")

router = APIRouter(prefix="/admin", tags=["admin"])


# ---------------------------------------------------------------------------
# POST /admin/create-app
# ---------------------------------------------------------------------------


@router.post("/create-app", status_code=201)
async def create_app(
    body: CreateAppRequest,
    db: DbSession,
    application: Application,
    super_admin: SuperAdminUser,  # TM-008: Require super-admin JWT
) -> CreateAppResponse:
    """Create a new client application with generated API keys.

    Returns the application details and the raw secret key (shown once).
    """
    # Validate slug format before calling service
    if not _SLUG_RE.match(body.slug):
        raise ValidationError("slug must match [a-z0-9-]+")

    result = await service.create_application_with_keys(
        db,
        name=body.name,
        slug=body.slug,
        description=body.description,
        webhook_url=body.webhook_url,
        allowed_origins=body.allowed_origins,
        settings=body.settings,
        blueprint_key=body.blueprint_key,
        blueprint=body.blueprint,
    )

    app_model = result["application"]

    return CreateAppResponse(
        application=CreateAppApplicationOut(
            id=str(app_model.id),
            name=app_model.name,
            slug=app_model.slug,
            description=app_model.description,
            webhook_url=app_model.webhook_url,
            allowed_origins=app_model.allowed_origins,
            settings=app_model.settings,
            created_at=app_model.created_at,
        ),
        api_key=result["api_key"],
        warning=result["warning"],
    )


# ---------------------------------------------------------------------------
# POST /admin/rotate-api-key/{app_id}
# ---------------------------------------------------------------------------


@router.post("/rotate-api-key/{id}")
async def rotate_api_key(
    id: str,
    db: DbSession,
    application: Application,
    super_admin: SuperAdminUser,  # TM-008: Require super-admin JWT
) -> RotateApiKeyResponse:
    """Rotate the legacy API key for the given application.

    Returns the new raw key (shown once).
    """
    if not id:
        raise ValidationError("Application ID is required")

    result = await service.rotate_api_key(db, id)
    return RotateApiKeyResponse(**result)


# ---------------------------------------------------------------------------
# GET /admin/apps
# ---------------------------------------------------------------------------


@router.get("/apps")
async def list_apps(
    application: Application,  # API-key auth
) -> ListAppsResponse:
    """Return the requesting application's details.

    Full multi-app management requires super-admin access (future).
    """
    return ListAppsResponse(
        application=ApplicationInfo(
            id=str(application.id),
            name=application.name,
            slug=application.slug,
            description=getattr(application, "description", None),
            webhook_url=getattr(application, "webhook_url", None),
            allowed_origins=getattr(application, "allowed_origins", None),
            settings=getattr(application, "settings", None),
            whitelist_enabled=getattr(application, "whitelist_enabled", False),
        ),
        note=(
            "This endpoint shows only your application. "
            "Full app management requires super admin access."
        ),
    )
