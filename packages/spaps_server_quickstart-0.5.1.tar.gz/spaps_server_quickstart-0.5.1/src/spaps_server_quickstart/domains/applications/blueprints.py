"""Application blueprint registry and compilation helpers.

Blueprints let downstream applications declare a reusable contract for:
- default application settings
- publishable-key route scope
- default authorization policies
- related documentation bundles

The compiled blueprint is stored inside ``application.settings`` so the
runtime can enforce app-specific key scope without adding new schema columns.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..errors import ValidationError


@dataclass(frozen=True, slots=True)
class BlueprintPolicySeed:
    """Canonical policy seed for blueprint-driven application bootstrap."""

    name: str
    description: str | None = None
    effect: str = "allow"
    conditions: dict[str, Any] = field(default_factory=dict)
    priority: int = 0
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class BlueprintJourney:
    """Machine-readable reference journey carried with a blueprint."""

    key: str
    name: str
    description: str
    publishable_scopes: tuple[str, ...] = ()
    entitlement_key: str | None = None
    policy_name: str | None = None


@dataclass(frozen=True, slots=True)
class ApplicationBlueprint:
    """Built-in application blueprint definition."""

    key: str
    name: str
    description: str
    publishable_scopes: tuple[str, ...] = ()
    settings: dict[str, Any] = field(default_factory=dict)
    default_policies: tuple[BlueprintPolicySeed, ...] = ()
    docs: tuple[str, ...] = ()
    journeys: tuple[BlueprintJourney, ...] = ()


@dataclass(frozen=True, slots=True)
class CompiledApplicationBlueprint:
    """Materialized blueprint payload ready for persistence."""

    key: str
    name: str
    description: str
    publishable_scopes: list[str]
    publishable_patterns: list[str]
    settings: dict[str, Any]
    default_policies: list[BlueprintPolicySeed]
    docs: list[str]
    journeys: list[dict[str, Any]]


PUBLISHABLE_SCOPE_PATTERNS: dict[str, tuple[str, ...]] = {
    "auth": (
        "/api/auth/login",
        "/api/auth/register",
        "/api/auth/refresh",
        "/api/auth/logout",
        "/api/auth/nonce",
        "/api/auth/wallet-sign-in",
        "/api/auth/magic-link",
        "/api/auth/verify-magic-link",
        "/api/auth/password-reset",
        "/api/auth/reset-password-confirm",
        "/api/auth/set-password",
        "/api/auth/user",
        "/api/auth/solana/",
        "/api/auth/ethereum/",
    ),
    "sessions": (
        "/api/sessions",
    ),
    "stripe_consumer": (
        "/api/stripe/checkout-sessions",
        "/api/stripe/products",
        "/api/stripe/subscriptions",
        "/api/stripe/subscription",
        "/api/stripe/history",
        "/api/stripe/payment",
        "/api/stripe/portal-session",
    ),
    "usage": (
        "/api/usage/",
    ),
    "entitlements_read": (
        "/api/entitlements",
    ),
    "issue_reporting": (
        "/api/v1/issue-reports",
    ),
    "dayrate_public": (
        "/api/dayrate/availability",
        "/api/dayrate/book",
        "/api/dayrate/book-multi",
    ),
    "health": (
        "/health",
    ),
    "docs": (
        "/docs",
        "/api-docs",
        "/api/docs/",
    ),
    "device_flow": (
        "/api/cli/device/",
    ),
}


def _route(
    path: str,
    methods: tuple[str, ...],
    match: str = "exact",
) -> dict[str, Any]:
    return {
        "path": path,
        "methods": list(methods),
        "match": match,
    }


PUBLISHABLE_ROUTE_RULES_BY_PATTERN: dict[str, tuple[dict[str, Any], ...]] = {
    "/api/auth/login": (_route("/api/auth/login", ("POST",)),),
    "/api/auth/register": (_route("/api/auth/register", ("POST",)),),
    "/api/auth/refresh": (_route("/api/auth/refresh", ("POST",)),),
    "/api/auth/logout": (_route("/api/auth/logout", ("POST",)),),
    "/api/auth/nonce": (_route("/api/auth/nonce", ("POST",)),),
    "/api/auth/wallet-sign-in": (_route("/api/auth/wallet-sign-in", ("POST",)),),
    "/api/auth/magic-link": (_route("/api/auth/magic-link", ("POST",)),),
    "/api/auth/verify-magic-link": (_route("/api/auth/verify-magic-link", ("POST",)),),
    "/api/auth/password-reset": (_route("/api/auth/password-reset", ("POST",)),),
    "/api/auth/reset-password-confirm": (_route("/api/auth/reset-password-confirm", ("POST",)),),
    "/api/auth/set-password": (_route("/api/auth/set-password", ("POST",)),),
    "/api/auth/user": (_route("/api/auth/user", ("GET",)),),
    "/api/auth/solana/": (_route("/api/auth/solana/", ("GET", "POST"), "prefix"),),
    "/api/auth/ethereum/": (_route("/api/auth/ethereum/", ("GET", "POST"), "prefix"),),
    "/api/sessions": (
        _route("/api/sessions", ("GET",)),
        _route("/api/sessions/current", ("GET",)),
        _route("/api/sessions/validate", ("POST",)),
        _route("/api/sessions/touch", ("POST",)),
        _route("/api/sessions/all", ("DELETE",)),
        _route("/api/sessions/{session_id}", ("DELETE",), "template"),
    ),
    "/api/stripe/checkout-sessions": (
        _route("/api/stripe/checkout-sessions", ("GET", "POST")),
        _route("/api/stripe/checkout-sessions/{session_id}", ("GET",), "template"),
    ),
    "/api/stripe/products": (
        _route("/api/stripe/products", ("GET",)),
        _route("/api/stripe/products/{product_id}", ("GET",), "template"),
    ),
    "/api/stripe/subscriptions": (_route("/api/stripe/subscriptions", ("GET", "POST")),),
    "/api/stripe/subscription": (
        _route("/api/stripe/subscription/{id}", ("GET",), "template"),
        _route("/api/stripe/subscription/{id}/cancel", ("POST",), "template"),
        _route("/api/stripe/subscription/{id}/update", ("POST",), "template"),
    ),
    "/api/stripe/history": (_route("/api/stripe/history", ("GET",)),),
    "/api/stripe/payment": (_route("/api/stripe/payment/{payment_id}", ("GET",), "template"),),
    "/api/stripe/portal-session": (_route("/api/stripe/portal-session", ("POST",)),),
    "/api/usage/": (_route("/api/usage/", ("GET", "POST"), "prefix"),),
    "/api/entitlements": (
        _route("/api/entitlements", ("GET",)),
        _route("/api/entitlements/check", ("GET",)),
        _route("/api/entitlements/changes", ("GET",)),
        _route("/api/entitlements/history", ("GET",)),
        _route("/api/entitlements/claim", ("POST",)),
    ),
    "/api/v1/issue-reports": (
        _route("/api/v1/issue-reports", ("GET", "POST")),
        _route("/api/v1/issue-reports/voice-token", ("POST",)),
        _route("/api/v1/issue-reports/status", ("GET",)),
        _route("/api/v1/issue-reports/{issue_report_id}", ("GET", "PATCH"), "template"),
        _route(
            "/api/v1/issue-reports/{issue_report_id}/replies",
            ("POST",),
            "template",
        ),
    ),
    "/api/dayrate/availability": (_route("/api/dayrate/availability", ("GET",)),),
    "/api/dayrate/book": (_route("/api/dayrate/book", ("POST",)),),
    "/api/dayrate/book-multi": (_route("/api/dayrate/book-multi", ("POST",)),),
    "/health": (_route("/health", ("GET",)),),
    "/docs": (_route("/docs", ("GET",)),),
    "/api-docs": (_route("/api-docs", ("GET",)),),
    "/api/docs/": (_route("/api/docs/", ("GET", "POST"), "prefix"),),
    "/api/cli/device/": (_route("/api/cli/device/", ("POST",), "prefix"),),
}


def _legacy_route_for_pattern(pattern: str) -> dict[str, Any]:
    match = "prefix" if pattern.endswith("/") else "exact"
    return _route(pattern, ("GET",), match)


def _copy_route(route: dict[str, Any]) -> dict[str, Any]:
    return {
        "path": str(route["path"]),
        "methods": [str(method).upper() for method in route["methods"]],
        "match": str(route.get("match") or "exact"),
    }


def resolve_publishable_routes_for_patterns(patterns: list[str]) -> list[dict[str, Any]]:
    """Expand route patterns into method-aware publishable route rules."""
    routes: list[dict[str, Any]] = []
    seen: set[tuple[str, str, tuple[str, ...]]] = set()
    for pattern in patterns:
        rules = PUBLISHABLE_ROUTE_RULES_BY_PATTERN.get(
            pattern,
            (_legacy_route_for_pattern(pattern),),
        )
        for rule in rules:
            copied = _copy_route(rule)
            key = (
                copied["path"],
                copied["match"],
                tuple(copied["methods"]),
            )
            if key in seen:
                continue
            seen.add(key)
            routes.append(copied)

    return routes


def resolve_publishable_routes(scopes: list[str]) -> list[dict[str, Any]]:
    """Expand publishable scope keys into method-aware route rules."""
    patterns = resolve_publishable_patterns(scopes)
    return resolve_publishable_routes_for_patterns(patterns)


BUILTIN_BLUEPRINTS: dict[str, ApplicationBlueprint] = {
    "default": ApplicationBlueprint(
        key="default",
        name="Default Platform App",
        description="Backwards-compatible SPAPS application defaults.",
        publishable_scopes=(
            "auth",
            "sessions",
            "stripe_consumer",
            "usage",
            "entitlements_read",
            "issue_reporting",
            "dayrate_public",
            "health",
            "docs",
            "device_flow",
        ),
        docs=(
            "docs/guides/API_INTEGRATION_GUIDE.md",
            "docs/guides/publishable-keys.md",
        ),
    ),
    "browser_auth": ApplicationBlueprint(
        key="browser_auth",
        name="Browser Auth App",
        description="Browser-first auth and developer-doc surface.",
        publishable_scopes=("auth", "sessions", "docs"),
        docs=(
            "docs/guides/publishable-keys.md",
            "docs/guides/API_INTEGRATION_GUIDE.md",
        ),
    ),
    "dayrate": ApplicationBlueprint(
        key="dayrate",
        name="Dayrate Booking App",
        description="Browser auth plus booking and checkout flows.",
        publishable_scopes=(
            "auth",
            "sessions",
            "stripe_consumer",
            "entitlements_read",
            "dayrate_public",
            "docs",
        ),
        settings={"stripe_enabled": True},
        docs=(
            "docs/guides/self-service-api.md",
            "docs/guides/publishable-keys.md",
        ),
    ),
    "golden_path": ApplicationBlueprint(
        key="golden_path",
        name="Golden Path Reference App",
        description="Canonical SPAPS control-plane contract for auth, checkout, entitlement projection, and paid access.",
        publishable_scopes=(
            "auth",
            "sessions",
            "stripe_consumer",
            "entitlements_read",
            "docs",
        ),
        settings={
            "stripe_enabled": True,
            "feature_flags": {
                "golden_path_reference": True,
            },
        },
        default_policies=(
            BlueprintPolicySeed(
                name="access-paid-features",
                description="Allow admins and users with the paid_access entitlement into paid-only surfaces.",
                effect="allow",
                conditions={
                    "any": [
                        {"has_role": {"role": "admin"}},
                        {"has_entitlement": {"key": "paid_access"}},
                    ]
                },
                priority=100,
                metadata={
                    "source": "application-blueprint",
                    "blueprint_key": "golden_path",
                    "journey": "checkout_projects_paid_access",
                },
            ),
        ),
        docs=(
            "docs/guides/application-blueprints.md",
            "docs/guides/self-service-api.md",
            "docs/downstream_apps/golden-path-reference/README.md",
        ),
        journeys=(
            BlueprintJourney(
                key="browser_auth_session",
                name="Browser auth and session bootstrap",
                description="Sign in from a browser with a publishable key and establish a reusable session.",
                publishable_scopes=("auth", "sessions"),
            ),
            BlueprintJourney(
                key="checkout_projects_paid_access",
                name="Checkout projects paid access",
                description="A Stripe checkout or subscription event projects the paid_access entitlement for the application user.",
                publishable_scopes=("stripe_consumer", "entitlements_read"),
                entitlement_key="paid_access",
                policy_name="access-paid-features",
            ),
            BlueprintJourney(
                key="developer_handoff",
                name="Developer docs and operator handoff",
                description="Operators can trace the contract from the blueprint metadata to the runbook and docs bundle.",
                publishable_scopes=("docs",),
            ),
        ),
    ),
}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge mapping values while preserving non-dict overrides."""
    merged: dict[str, Any] = dict(base)
    for key, value in override.items():
        existing = merged.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            merged[key] = _deep_merge(existing, value)
        else:
            merged[key] = value
    return merged


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered


def get_application_blueprint(key: str) -> ApplicationBlueprint:
    """Return a built-in blueprint by key or raise validation error."""
    blueprint = BUILTIN_BLUEPRINTS.get(key)
    if blueprint is None:
        raise ValidationError(f"Unknown application blueprint '{key}'")
    return blueprint


def resolve_publishable_patterns(scopes: list[str]) -> list[str]:
    """Expand publishable scope keys into ordered route patterns."""
    patterns: list[str] = []
    unknown: list[str] = []
    for scope in scopes:
        resolved = PUBLISHABLE_SCOPE_PATTERNS.get(scope)
        if resolved is None:
            unknown.append(scope)
            continue
        patterns.extend(resolved)

    if unknown:
        unknown_list = ", ".join(sorted(unknown))
        raise ValidationError(f"Unknown publishable scopes: {unknown_list}")

    return _dedupe(patterns)


def _normalize_policy_seed(raw_policy: dict[str, Any]) -> BlueprintPolicySeed:
    if not isinstance(raw_policy, dict):
        raise ValidationError("Blueprint policies must be JSON objects")

    name = str(raw_policy.get("name", "")).strip()
    if not name:
        raise ValidationError("Blueprint policy name is required")

    conditions = raw_policy.get("conditions")
    if not isinstance(conditions, dict) or not conditions:
        raise ValidationError(
            f"Blueprint policy '{name}' must define non-empty conditions"
        )

    effect = str(raw_policy.get("effect", "allow")).strip().lower()
    if effect not in {"allow", "deny"}:
        raise ValidationError(
            f"Blueprint policy '{name}' effect must be 'allow' or 'deny'"
        )

    priority = raw_policy.get("priority", 0)
    if not isinstance(priority, int):
        raise ValidationError(
            f"Blueprint policy '{name}' priority must be an integer"
        )

    metadata = raw_policy.get("metadata")
    if metadata is not None and not isinstance(metadata, dict):
        raise ValidationError(
            f"Blueprint policy '{name}' metadata must be a JSON object"
        )

    description = raw_policy.get("description")
    if description is not None:
        description = str(description)

    return BlueprintPolicySeed(
        name=name,
        description=description,
        effect=effect,
        conditions=conditions,
        priority=priority,
        metadata=metadata,
    )


def _journey_to_dict(journey: BlueprintJourney) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "key": journey.key,
        "name": journey.name,
        "description": journey.description,
        "publishable_scopes": list(journey.publishable_scopes),
    }
    if journey.entitlement_key is not None:
        payload["entitlement_key"] = journey.entitlement_key
    if journey.policy_name is not None:
        payload["policy_name"] = journey.policy_name
    return payload


def _normalize_inline_blueprint(
    blueprint: dict[str, Any] | None,
) -> dict[str, Any]:
    if blueprint is None:
        return {}
    if not isinstance(blueprint, dict):
        raise ValidationError("Blueprint overrides must be a JSON object")
    return blueprint


def compile_application_blueprint(
    *,
    default_settings: dict[str, Any],
    blueprint_key: str | None = None,
    blueprint: dict[str, Any] | None = None,
    settings: dict[str, Any] | None = None,
) -> CompiledApplicationBlueprint:
    """Compile built-in and inline blueprint inputs into persisted settings."""
    builtin_key = blueprint_key or "default"
    builtin = get_application_blueprint(builtin_key)
    inline = _normalize_inline_blueprint(blueprint)

    inline_settings = inline.get("settings") or {}
    if inline_settings and not isinstance(inline_settings, dict):
        raise ValidationError("Blueprint settings must be a JSON object")

    docs_override = inline.get("docs")
    if docs_override is not None and not isinstance(docs_override, list):
        raise ValidationError("Blueprint docs must be a list of paths")

    scopes_override = inline.get("publishable_scopes")
    if scopes_override is None:
        publishable_scopes = list(builtin.publishable_scopes)
    else:
        if not isinstance(scopes_override, list) or not all(
            isinstance(scope, str) for scope in scopes_override
        ):
            raise ValidationError("Blueprint publishable_scopes must be a list of strings")
        publishable_scopes = [scope.strip() for scope in scopes_override if scope.strip()]

    publishable_patterns = resolve_publishable_patterns(publishable_scopes)
    publishable_routes = resolve_publishable_routes_for_patterns(publishable_patterns)
    journeys = [_journey_to_dict(journey) for journey in builtin.journeys]

    compiled_settings = _deep_merge(default_settings, builtin.settings)
    compiled_settings = _deep_merge(compiled_settings, inline_settings)
    compiled_settings = _deep_merge(compiled_settings, settings or {})
    compiled_settings["application_blueprint"] = {
        "key": builtin.key,
        "name": str(inline.get("name") or builtin.name),
        "description": str(inline.get("description") or builtin.description),
        "publishable_scopes": publishable_scopes,
        "docs": _dedupe(
            [*builtin.docs, *[str(doc) for doc in (docs_override or [])]]
        ),
        "journeys": journeys,
    }
    compiled_settings["publishable_key_access"] = {
        "allowed_patterns": publishable_patterns,
        "allowed_routes": publishable_routes,
    }

    inline_default_policies = inline.get("default_policies") or []
    if inline_default_policies and not isinstance(inline_default_policies, list):
        raise ValidationError("Blueprint default_policies must be a list")

    default_policies = [
        *builtin.default_policies,
        *[_normalize_policy_seed(policy) for policy in inline_default_policies],
    ]

    return CompiledApplicationBlueprint(
        key=builtin.key,
        name=str(inline.get("name") or builtin.name),
        description=str(inline.get("description") or builtin.description),
        publishable_scopes=publishable_scopes,
        publishable_patterns=publishable_patterns,
        settings=compiled_settings,
        default_policies=default_policies,
        docs=compiled_settings["application_blueprint"]["docs"],
        journeys=journeys,
    )
