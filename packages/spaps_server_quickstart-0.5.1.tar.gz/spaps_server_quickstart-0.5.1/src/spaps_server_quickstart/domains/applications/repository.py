"""Database operations for the applications domain.

Pure SQLAlchemy async repository — no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import Application

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lookups
# ---------------------------------------------------------------------------


async def get_application_by_id(
    db: AsyncSession,
    app_id: str,
) -> Application | None:
    """Fetch an application by primary key."""
    result = await db.execute(select(Application).where(Application.id == app_id))
    return result.scalar_one_or_none()


async def get_application_by_api_key(
    db: AsyncSession,
    api_key: str,
) -> Application | None:
    """Fetch an application by its legacy ``api_key`` column."""
    result = await db.execute(
        select(Application).where(Application.api_key == api_key)
    )
    return result.scalar_one_or_none()


async def get_application_by_publishable_key_hash(
    db: AsyncSession,
    key_hash: str,
) -> Application | None:
    """Fetch an application by its publishable key hash."""
    result = await db.execute(
        select(Application).where(Application.publishable_key_hash == key_hash)
    )
    return result.scalar_one_or_none()


async def get_application_by_secret_key_hash(
    db: AsyncSession,
    key_hash: str,
) -> Application | None:
    """Fetch an application by its secret key hash."""
    result = await db.execute(
        select(Application).where(Application.secret_key_hash == key_hash)
    )
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Mutations
# ---------------------------------------------------------------------------


async def create_application(
    db: AsyncSession,
    name: str,
    api_key: str,
    owner_id: str | None = None,
    **kwargs: Any,
) -> Application:
    """Insert a new application and return the persisted instance.

    Extra keyword arguments are applied as column values when they
    match a model attribute (e.g. ``slug``, ``description``,
    ``webhook_url``, ``billing_account_id``, ``publishable_key_hash``,
    ``secret_key_hash``).
    """
    app = Application(name=name, api_key=api_key)

    # Apply optional columns
    for key, value in kwargs.items():
        if hasattr(app, key):
            setattr(app, key, value)

    db.add(app)
    await db.flush()
    await db.refresh(app)
    return app


async def update_application(
    db: AsyncSession,
    app_id: str,
    **kwargs: Any,
) -> Application | None:
    """Update arbitrary columns on an application row.

    Returns ``None`` if the application does not exist.
    """
    app = await get_application_by_id(db, app_id)
    if app is None:
        return None

    for key, value in kwargs.items():
        if hasattr(app, key):
            setattr(app, key, value)

    app.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(app)
    return app


async def increment_request_count(db: AsyncSession, app_id: str) -> None:
    """Atomically increment the per-application request counter.

    The counter is stored inside the ``settings`` JSON column under
    the ``request_count`` key so that no schema migration is required.
    Uses a single UPDATE with a Postgres ``jsonb_set`` expression for
    atomicity.
    """
    from sqlalchemy import text

    stmt = text(
        """
        UPDATE applications
        SET settings = jsonb_set(
            COALESCE(settings, '{}')::jsonb,
            '{request_count}',
            (COALESCE((settings->>'request_count')::int, 0) + 1)::text::jsonb
        ),
        updated_at = now()
        WHERE id = :app_id
        """
    )
    await db.execute(stmt, {"app_id": app_id})
    await db.flush()


# ---------------------------------------------------------------------------
# Listing
# ---------------------------------------------------------------------------


async def list_applications(
    db: AsyncSession,
    owner_id: str | None = None,
) -> list[Application]:
    """List all applications, optionally filtered by owner.

    Note: The ``Application`` model does not currently have an
    ``owner_id`` column.  When one is added, filtering will take
    effect; until then the parameter is accepted but ignored.
    """
    stmt = select(Application).order_by(Application.created_at.desc())

    if owner_id is not None and hasattr(Application, "owner_id"):
        stmt = stmt.where(Application.owner_id == owner_id)  # type: ignore[attr-defined]

    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Additional lookups (admin / duplicate checking)
# ---------------------------------------------------------------------------


async def get_application_by_name(
    db: AsyncSession,
    name: str,
) -> Application | None:
    """Fetch an application by its unique name (case-sensitive)."""
    result = await db.execute(select(Application).where(Application.name == name))
    return result.scalar_one_or_none()


async def get_application_by_slug(
    db: AsyncSession,
    slug: str,
) -> Application | None:
    """Fetch an application by its unique slug."""
    result = await db.execute(select(Application).where(Application.slug == slug))
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Deletion
# ---------------------------------------------------------------------------


async def delete_application(
    db: AsyncSession,
    app_id: str,
) -> bool:
    """Hard-delete an application by primary key.

    Returns ``True`` if a row was deleted, ``False`` if it did not exist.
    """
    app = await get_application_by_id(db, app_id)
    if app is None:
        return False

    await db.delete(app)
    await db.flush()
    return True
