"""Database operations for the whitelist domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import EmailWhitelist

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lookups
# ---------------------------------------------------------------------------


async def get_by_email(
    db: AsyncSession,
    application_id: UUID,
    email: str,
) -> EmailWhitelist | None:
    """Fetch a whitelist entry by application and email."""
    stmt = select(EmailWhitelist).where(
        EmailWhitelist.application_id == application_id,
        EmailWhitelist.email == email.lower(),
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def count(
    db: AsyncSession,
    application_id: UUID,
    *,
    tier: str | None = None,
) -> int:
    """Count whitelist entries for an application, optionally filtered by tier."""
    stmt = select(func.count()).select_from(EmailWhitelist).where(
        EmailWhitelist.application_id == application_id,
    )
    if tier is not None:
        stmt = stmt.where(EmailWhitelist.tier == tier)
    result = await db.execute(stmt)
    return result.scalar_one()


# ---------------------------------------------------------------------------
# Mutations
# ---------------------------------------------------------------------------


async def create(
    db: AsyncSession,
    *,
    application_id: UUID,
    email: str,
    tier: str = "premium",
    bypass_payment: bool = False,
    metadata: dict[str, Any] | None = None,
    created_by: UUID | None = None,
) -> EmailWhitelist:
    """Insert a new whitelist entry and return the persisted instance."""
    entry = EmailWhitelist(
        application_id=application_id,
        email=email.lower(),
        tier=tier,
        bypass_payment=bypass_payment,
        metadata_=metadata or {},
        created_by=created_by,
    )
    db.add(entry)
    await db.flush()
    await db.refresh(entry)
    return entry


async def bulk_create(
    db: AsyncSession,
    *,
    application_id: UUID,
    entries: list[dict[str, Any]],
    created_by: UUID | None = None,
) -> tuple[list[EmailWhitelist], list[dict[str, str]]]:
    """Insert multiple whitelist entries.

    Returns a tuple of (successful entries, failed entries).
    Each failed entry is a dict with ``email`` and ``error`` keys.
    Entries are processed individually so a single failure does not
    abort the entire batch.
    """
    successful: list[EmailWhitelist] = []
    failed: list[dict[str, str]] = []

    for entry_data in entries:
        email = entry_data["email"].lower()
        tier = entry_data.get("tier", "premium")
        metadata = entry_data.get("metadata") or {}

        # Check for existing entry
        existing = await get_by_email(db, application_id, email)
        if existing is not None:
            failed.append({"email": email, "error": "Email already whitelisted"})
            continue

        try:
            entry = EmailWhitelist(
                application_id=application_id,
                email=email,
                tier=tier,
                bypass_payment=False,
                metadata_=metadata,
                created_by=created_by,
            )
            db.add(entry)
            await db.flush()
            await db.refresh(entry)
            successful.append(entry)
        except Exception as exc:
            logger.warning("Failed to add %s to whitelist: %s", email, exc)
            failed.append({"email": email, "error": str(exc)})

    return successful, failed


# ---------------------------------------------------------------------------
# Listing
# ---------------------------------------------------------------------------


async def list_entries(
    db: AsyncSession,
    application_id: UUID,
    *,
    limit: int = 10,
    offset: int = 0,
    tier: str | None = None,
) -> list[EmailWhitelist]:
    """List whitelist entries for an application with pagination."""
    stmt = (
        select(EmailWhitelist)
        .where(EmailWhitelist.application_id == application_id)
        .order_by(EmailWhitelist.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    if tier is not None:
        stmt = stmt.where(EmailWhitelist.tier == tier)
    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Updates
# ---------------------------------------------------------------------------


async def update_entry(
    db: AsyncSession,
    application_id: UUID,
    email: str,
    **kwargs: Any,
) -> EmailWhitelist | None:
    """Update arbitrary columns on a whitelist entry.

    Returns ``None`` if the entry does not exist.
    """
    entry = await get_by_email(db, application_id, email.lower())
    if entry is None:
        return None

    for key, value in kwargs.items():
        if key == "metadata":
            entry.metadata_ = value
        elif hasattr(entry, key):
            setattr(entry, key, value)

    entry.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(entry)
    return entry


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------


async def get_stats(
    db: AsyncSession,
    application_id: UUID,
    *,
    whitelist_enabled: bool = False,
) -> dict[str, Any]:
    """Aggregate whitelist statistics for an application.

    Returns a dict with ``enabled``, ``total``, and ``tier_breakdown``.
    """
    total = await count(db, application_id)

    # Tier breakdown
    stmt = (
        select(EmailWhitelist.tier, func.count().label("count"))
        .where(EmailWhitelist.application_id == application_id)
        .group_by(EmailWhitelist.tier)
    )
    result = await db.execute(stmt)
    tier_breakdown = [{"tier": row.tier, "count": row.count} for row in result.all()]

    return {
        "enabled": whitelist_enabled,
        "total": total,
        "tier_breakdown": tier_breakdown,
    }


# ---------------------------------------------------------------------------
# Deletions
# ---------------------------------------------------------------------------


async def clear_all(
    db: AsyncSession,
    application_id: UUID,
) -> int:
    """Delete all whitelist entries for an application.

    Returns the number of rows deleted.
    """
    stmt = delete(EmailWhitelist).where(
        EmailWhitelist.application_id == application_id
    )
    result = await db.execute(stmt)
    deleted = result.rowcount  # type: ignore[attr-defined]
    await db.flush()
    logger.info("Cleared %d whitelist entries for app %s", deleted, application_id)
    return deleted


async def delete_by_email(
    db: AsyncSession,
    application_id: UUID,
    email: str,
) -> bool:
    """Delete a single whitelist entry by email.

    Returns ``True`` if a row was deleted, ``False`` otherwise.
    """
    stmt = delete(EmailWhitelist).where(
        EmailWhitelist.application_id == application_id,
        EmailWhitelist.email == email.lower(),
    )
    result = await db.execute(stmt)
    deleted = result.rowcount > 0  # type: ignore[attr-defined]
    if deleted:
        await db.flush()
        logger.info("Removed %s from whitelist for app %s", email, application_id)
    return deleted
