"""HTTP routes for the email domain.

Provides the ``email_router`` for email endpoints under ``/email``.

Endpoint auth levels:
- POST /email/send: API Key
- GET /email/templates: API Key + JWT + Admin
- GET /email/templates/:key: API Key + JWT
- GET /email/templates/:key/preview: API Key + JWT
- POST /email/templates/:key/preview: API Key + JWT
- POST /email/templates: API Key + JWT + Admin
- PUT /email/templates/:key: API Key + JWT + Admin
- GET /email/templates/:key/override: API Key + JWT
- PUT /email/templates/:key/override: API Key + JWT + Admin
- DELETE /email/templates/:key/override: API Key + JWT + Admin
- GET /email/logs: API Key + JWT
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse

from ...middleware.spaps_deps import AdminUser, Application, CurrentUser, DbSession
from . import service
from .schemas import (
    CreateTemplateRequest,
    CreateTemplateResponse,
    DeleteTemplateOverrideResponse,
    ListLogsResponse,
    ListTemplatesResponse,
    PreviewTemplateRequest,
    SendEmailRequest,
    SendEmailResponse,
    TemplateOverrideRequest,
    TemplateOverrideResponse,
    UpdateTemplateRequest,
    UpdateTemplateResponse,
)

logger = logging.getLogger(__name__)

email_router = APIRouter(prefix="/email", tags=["email"])


def _is_admin_user(user: Any) -> bool:
    roles = getattr(user, "roles", []) or []
    return bool(
        getattr(user, "is_admin", False)
        or getattr(user, "is_super_admin", False)
        or "admin" in roles
        or "super_admin" in roles
    )


# ===========================================================================
# POST /email/send
# ===========================================================================


@email_router.post("/send", response_model=SendEmailResponse)
async def send_email(
    request: Request,
    body: SendEmailRequest,
    db: DbSession,
    app: Application,
) -> SendEmailResponse:
    """Send an email via template.

    Requires API key authentication.
    TM-ENV-001: Environment safety gates apply — emails only sent in production.
    """
    settings = request.app.state.settings
    result = await service.send_email(
        db,
        application_id=app.id,
        app_settings=app.settings,
        template_key=body.template_key,
        to=body.to,
        settings_env=settings.env,
        settings_local_mode=settings.is_spaps_local_mode,
        context=body.context,
        user_id=UUID(body.user_id) if body.user_id else None,
        owner_id=UUID(body.owner_id) if body.owner_id else None,
        subject_override=body.subject_override,
        body_override=body.body_override,
    )
    return SendEmailResponse(**result)


# ===========================================================================
# GET /email/templates
# ===========================================================================


@email_router.get("/templates", response_model=ListTemplatesResponse)
async def list_templates(
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> ListTemplatesResponse:
    """List all email templates.

    Requires API key + JWT (admin).
    """
    result = await service.list_templates(db, application_id=app.id)
    return ListTemplatesResponse(**result)


# ===========================================================================
# POST /email/templates (create) -- before /:key routes to avoid conflicts
# ===========================================================================


@email_router.post(
    "/templates", response_model=CreateTemplateResponse, status_code=201
)
async def create_template(
    body: CreateTemplateRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> CreateTemplateResponse:
    """Create a new email template.

    Requires API key + JWT (admin).
    """
    result = await service.create_template(
        db,
        application_id=app.id,
        template_key=body.template_key,
        name=body.name,
        subject=body.subject,
        html_body=body.html_body,
        description=body.description,
        text_body=body.text_body,
        from_email=body.from_email,
        from_name=body.from_name,
        reply_to=body.reply_to,
        variables=body.variables,
        sample_context=body.sample_context,
        is_active=body.is_active if body.is_active is not None else True,
        category=body.category,
    )
    return CreateTemplateResponse(**result)


# ===========================================================================
# GET /email/templates/:key
# ===========================================================================


@email_router.get("/templates/{template_key}")
async def get_template(
    template_key: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> JSONResponse:
    """Get a template by key.

    Requires API key + JWT authentication.
    """
    result = await service.get_template(
        db, application_id=app.id, template_key=template_key
    )
    return JSONResponse(content=result)


# ===========================================================================
# GET /email/templates/:key/preview
# ===========================================================================


@email_router.get("/templates/{template_key}/preview")
async def preview_template_get(
    template_key: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> HTMLResponse:
    """Preview a template with sample context.

    Requires API key + JWT authentication.
    """
    html = await service.preview_template(
        db, application_id=app.id, template_key=template_key
    )
    return HTMLResponse(content=html)


# ===========================================================================
# POST /email/templates/:key/preview
# ===========================================================================


@email_router.post("/templates/{template_key}/preview")
async def preview_template_post(
    template_key: str,
    body: PreviewTemplateRequest,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> HTMLResponse:
    """Preview a template with custom context.

    Requires API key + JWT authentication.
    """
    html = await service.preview_template(
        db,
        application_id=app.id,
        template_key=template_key,
        context=body.context,
    )
    return HTMLResponse(content=html)


# ===========================================================================
# PUT /email/templates/:key
# ===========================================================================


@email_router.put("/templates/{template_key}", response_model=UpdateTemplateResponse)
async def update_template(
    template_key: str,
    body: UpdateTemplateRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> UpdateTemplateResponse:
    """Update an existing email template.

    Requires API key + JWT (admin).
    """
    result = await service.update_template(
        db,
        application_id=app.id,
        template_key=template_key,
        name=body.name,
        description=body.description,
        subject=body.subject,
        html_body=body.html_body,
        text_body=body.text_body,
        from_email=body.from_email,
        from_name=body.from_name,
        reply_to=body.reply_to,
        variables=body.variables,
        sample_context=body.sample_context,
        is_active=body.is_active,
        category=body.category,
    )
    return UpdateTemplateResponse(**result)


# ===========================================================================
# Template overrides
# ===========================================================================


@email_router.get(
    "/templates/{template_key}/override",
    response_model=TemplateOverrideResponse,
)
async def get_template_override(
    template_key: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> TemplateOverrideResponse:
    """Get template override.

    Requires API key + JWT authentication.
    """
    result = await service.get_template_override(
        db,
        application_id=app.id,
        template_key=template_key,
    )
    return TemplateOverrideResponse(**result)


@email_router.put(
    "/templates/{template_key}/override",
    response_model=TemplateOverrideResponse,
)
async def put_template_override(
    template_key: str,
    body: TemplateOverrideRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> TemplateOverrideResponse:
    """Create or update template override.

    Requires API key + JWT (admin).
    """
    result = await service.create_or_update_template_override(
        db,
        application_id=app.id,
        template_key=template_key,
        subject_override=body.subject_override,
        body_override=body.body_override,
    )
    return TemplateOverrideResponse(**result)


@email_router.delete(
    "/templates/{template_key}/override",
    response_model=DeleteTemplateOverrideResponse,
)
async def delete_template_override(
    template_key: str,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> DeleteTemplateOverrideResponse:
    """Delete template override.

    Requires API key + JWT (admin).
    """
    result = await service.delete_template_override(
        db,
        application_id=app.id,
        template_key=template_key,
    )
    return DeleteTemplateOverrideResponse(**result)


# ===========================================================================
# GET /email/logs
# ===========================================================================


@email_router.get("/logs", response_model=ListLogsResponse)
async def list_logs(
    db: DbSession,
    app: Application,
    user: CurrentUser,
    owner_id: UUID | None = Query(default=None),
    user_id: UUID | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
) -> ListLogsResponse:
    """Get email logs.

    Requires API key + JWT authentication.
    """
    result = await service.get_logs(
        db,
        application_id=UUID(str(app.id)),
        current_user_id=UUID(str(user.id)),
        is_admin=_is_admin_user(user),
        owner_id=owner_id,
        user_id=user_id,
        limit=limit,
        offset=offset,
    )
    return ListLogsResponse(**result)
