"""Domain errors for the issue_reporting_platform domain."""

from __future__ import annotations

from ..errors import DomainError


class NotAuthenticatedError(DomainError):
    """Raised when an authenticated end-user session is required."""

    def __init__(self, message: str = "Authentication required") -> None:
        super().__init__("NOT_AUTHENTICATED", message, status_code=401)


class NotAuthorizedError(DomainError):
    """Raised when issue reporting is disabled for the caller context."""

    def __init__(self, message: str = "Caller is not authorized for issue reporting") -> None:
        super().__init__("NOT_AUTHORIZED", message, status_code=403)


class ValidationFailedError(DomainError):
    """Raised when an issue-report request fails validation."""

    def __init__(self, message: str = "Request validation failed") -> None:
        super().__init__("VALIDATION_FAILED", message, status_code=400)


class IssueReportNotFoundError(DomainError):
    """Raised when a caller-owned issue report cannot be found."""

    def __init__(self, message: str = "Issue report not found") -> None:
        super().__init__("ISSUE_REPORT_NOT_FOUND", message, status_code=404)


class IssueReportCannotEditClosedError(DomainError):
    """Raised when a closed issue report is edited."""

    def __init__(self, message: str = "Closed issue reports cannot be edited") -> None:
        super().__init__("ISSUE_REPORT_CANNOT_EDIT_CLOSED", message, status_code=400)


class IssueReportCannotReplyOpenError(DomainError):
    """Raised when a reply is attempted before the linked case is closed."""

    def __init__(self, message: str = "Open issue reports cannot be replied to") -> None:
        super().__init__("ISSUE_REPORT_CANNOT_REPLY_OPEN", message, status_code=400)


class IssueReportCaseLinkBrokenError(DomainError):
    """Raised when an issue report points at a missing support case."""

    def __init__(self, message: str = "Issue report support-case linkage is broken") -> None:
        super().__init__("ISSUE_REPORT_CASE_LINK_BROKEN", message, status_code=409)


class IssueReportVoiceUnavailableError(DomainError):
    """Raised when voice token minting is unavailable."""

    def __init__(self, message: str = "Voice input is temporarily unavailable") -> None:
        super().__init__("ISSUE_REPORT_VOICE_UNAVAILABLE", message, status_code=503)
