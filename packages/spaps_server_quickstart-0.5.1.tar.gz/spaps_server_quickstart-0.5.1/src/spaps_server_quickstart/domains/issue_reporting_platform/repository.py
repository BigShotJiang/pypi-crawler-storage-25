"""Repository operations for the issue_reporting_platform domain."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..support_telemetry_platform.models import SupportCase
from .models import IssueReport


async def create_issue_report(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    reporter_role_hint: str | None,
    component_key: str,
    component_label: str,
    page_url: str,
    surface_ref: str | None,
    target_metadata: dict[str, object],
    note: str,
    parent_issue_report_id: UUID | None,
    support_case_id: UUID,
    source_app: str | None = None,
    source_record_id: str | None = None,
    created_at: datetime | None = None,
    updated_at: datetime | None = None,
) -> IssueReport:
    issue_report = IssueReport(
        application_id=application_id,
        reporter_user_id=reporter_user_id,
        reporter_role_hint=reporter_role_hint,
        component_key=component_key,
        component_label=component_label,
        page_url=page_url,
        surface_ref=surface_ref,
        target_metadata=target_metadata,
        note=note,
        parent_issue_report_id=parent_issue_report_id,
        support_case_id=support_case_id,
        source_app=source_app,
        source_record_id=source_record_id,
    )
    if created_at is not None:
        issue_report.created_at = created_at
    if updated_at is not None:
        issue_report.updated_at = updated_at
    db.add(issue_report)
    await db.flush()
    await db.refresh(issue_report)
    return issue_report


async def get_issue_report_by_source_record(
    db: AsyncSession,
    *,
    application_id: UUID,
    source_app: str,
    source_record_id: str,
) -> IssueReport | None:
    stmt = select(IssueReport).where(
        IssueReport.application_id == application_id,
        IssueReport.source_app == source_app,
        IssueReport.source_record_id == source_record_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_issue_report_row(
    db: AsyncSession,
    *,
    issue_report_id: UUID,
    application_id: UUID,
    reporter_user_id: UUID,
) -> tuple[IssueReport, SupportCase | None] | None:
    stmt = (
        select(IssueReport, SupportCase)
        .outerjoin(SupportCase, SupportCase.id == IssueReport.support_case_id)
        .where(
            IssueReport.id == issue_report_id,
            IssueReport.application_id == application_id,
            IssueReport.reporter_user_id == reporter_user_id,
        )
    )
    result = await db.execute(stmt)
    row = result.first()
    if row is None:
        return None
    return row[0], row[1]


async def list_issue_report_rows(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    status: str | None,
    limit: int,
    offset: int,
) -> tuple[list[tuple[IssueReport, SupportCase | None]], int]:
    data_stmt = (
        select(IssueReport, SupportCase)
        .outerjoin(SupportCase, SupportCase.id == IssueReport.support_case_id)
        .where(
            IssueReport.application_id == application_id,
            IssueReport.reporter_user_id == reporter_user_id,
        )
    )
    count_stmt = (
        select(func.count())
        .select_from(IssueReport)
        .outerjoin(SupportCase, SupportCase.id == IssueReport.support_case_id)
        .where(
            IssueReport.application_id == application_id,
            IssueReport.reporter_user_id == reporter_user_id,
        )
    )
    if status is not None:
        data_stmt = data_stmt.where(SupportCase.status == status)
        count_stmt = count_stmt.where(SupportCase.status == status)

    data_stmt = data_stmt.order_by(IssueReport.created_at.desc()).limit(limit).offset(offset)

    data_result = await db.execute(data_stmt)
    count_result = await db.execute(count_stmt)
    rows = [(row[0], row[1]) for row in data_result.all()]
    return rows, int(count_result.scalar() or 0)


async def update_issue_report_note(
    db: AsyncSession,
    *,
    issue_report: IssueReport,
    note: str,
) -> IssueReport:
    issue_report.note = note
    issue_report.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(issue_report)
    return issue_report


async def count_open_issue_reports(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
) -> int:
    stmt = (
        select(func.count())
        .select_from(IssueReport)
        .join(SupportCase, SupportCase.id == IssueReport.support_case_id)
        .where(
            IssueReport.application_id == application_id,
            IssueReport.reporter_user_id == reporter_user_id,
            SupportCase.status.in_(("open", "in_progress")),
        )
    )
    result = await db.execute(stmt)
    return int(result.scalar() or 0)


async def count_recent_resolved_issue_reports(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    resolved_since: datetime,
) -> int:
    stmt = (
        select(func.count())
        .select_from(IssueReport)
        .join(SupportCase, SupportCase.id == IssueReport.support_case_id)
        .where(
            IssueReport.application_id == application_id,
            IssueReport.reporter_user_id == reporter_user_id,
            SupportCase.status == "resolved",
            SupportCase.resolved_at.is_not(None),
            SupportCase.resolved_at >= resolved_since,
        )
    )
    result = await db.execute(stmt)
    return int(result.scalar() or 0)
