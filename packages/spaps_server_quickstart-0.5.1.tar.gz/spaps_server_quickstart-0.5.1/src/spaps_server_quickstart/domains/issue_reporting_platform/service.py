"""Business logic for the issue_reporting_platform domain."""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID, uuid4

import httpx
from sqlalchemy.ext.asyncio import AsyncSession

from ...spaps_settings import get_spaps_settings
from ..support_telemetry_platform import repository as support_repo
from ..support_telemetry_platform.models import SupportCase
from . import repository as repo
from .errors import (
    IssueReportCannotEditClosedError,
    IssueReportCannotReplyOpenError,
    IssueReportCaseLinkBrokenError,
    IssueReportNotFoundError,
    IssueReportVoiceUnavailableError,
    ValidationFailedError,
)
from .models import IssueReport

RECENT_RESOLVED_WINDOW_DAYS = 7
NOTE_MIN_LENGTH = 10
HTMA_IMPORT_SOURCE = "htma"
HTMA_IMPORT_EXTERNAL_REF_PREFIX = "htma:issue-log:"
_COMPONENT_KEY_SLUG_RE = re.compile(r"[^a-z0-9]+")
_MIN_UTC_DATETIME = datetime.min.replace(tzinfo=UTC)
ELEVENLABS_SCRIBE_TOKEN_URL = "https://api.elevenlabs.io/v1/single-use-token/realtime_scribe"
VOICE_TOKEN_PROVIDER = "elevenlabs_scribe_realtime"
VOICE_TOKEN_MODEL = "scribe_v2_realtime"
VOICE_TOKEN_TTL_SECONDS = 900
VOICE_TOKEN_RETAIN_AUDIO_DEFAULT = False
VOICE_TOKEN_ATTACH_TRANSCRIPT_DEFAULT = True


@dataclass(frozen=True, slots=True)
class HTMALegacyIssueLogRecord:
    """Normalized legacy HTMA issue-log row used during cutover import."""

    legacy_issue_id: UUID | str
    reporter_user_id: UUID
    reporter_role_hint: str
    component_label: str
    page_url: str
    note: str
    created_at: datetime
    updated_at: datetime
    is_fixed: bool
    fixed_at: datetime | None = None
    parent_legacy_issue_id: UUID | str | None = None
    component_key: str | None = None
    surface_ref: str | None = None
    target_metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class _PreparedHTMALegacyIssueLogRecord:
    record: HTMALegacyIssueLogRecord
    source_record_id: str
    parent_source_id: str | None
    status_timestamp: datetime
    desired_status: str
    desired_resolved_at: datetime | None
    sort_key: tuple[datetime, str]


@dataclass(frozen=True, slots=True)
class _HTMAImportGraph:
    pending_record_ids: set[str]
    children_by_parent: dict[str, list[str]]
    ready_record_ids: list[str]


def _iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    return dt.isoformat()


def _normalize_note(note: str) -> str:
    normalized = note.strip()
    if len(normalized) < NOTE_MIN_LENGTH:
        raise ValidationFailedError("note must be at least 10 characters")
    return normalized


def _normalize_target(target: dict[str, Any]) -> dict[str, Any]:
    component_key = str(target.get("component_key") or "").strip()
    component_label = str(target.get("component_label") or "").strip()
    page_url = str(target.get("page_url") or "").strip()
    surface_ref = target.get("surface_ref")
    metadata = target.get("metadata") or {}

    if not component_key or not component_label or not page_url:
        raise ValidationFailedError("target snapshot is required")
    if not isinstance(metadata, dict):
        raise ValidationFailedError("target metadata must be an object")

    return {
        "component_key": component_key,
        "component_label": component_label,
        "page_url": page_url,
        "surface_ref": str(surface_ref).strip() if surface_ref else None,
        "metadata": metadata,
    }


def _derive_component_key(*, component_key: str | None, component_label: str) -> str:
    if component_key and component_key.strip():
        return component_key.strip()
    normalized = _COMPONENT_KEY_SLUG_RE.sub("_", component_label.strip().lower()).strip("_")
    return normalized or "legacy_issue_surface"


def _normalize_source_record_id(value: UUID | str | None) -> str | None:
    if value is None:
        return None
    return str(value).strip() or None


def _legacy_status_timestamp(record: HTMALegacyIssueLogRecord) -> datetime:
    if record.fixed_at is not None:
        return record.fixed_at
    return record.updated_at


def _desired_case_state(record: HTMALegacyIssueLogRecord) -> tuple[str, datetime | None]:
    if record.is_fixed:
        return "resolved", record.fixed_at or record.updated_at
    return "open", None


def _htma_external_case_ref(source_record_id: str) -> str:
    return f"{HTMA_IMPORT_EXTERNAL_REF_PREFIX}{source_record_id}"


def _prepare_legacy_issue_log_records(
    legacy_issue_logs: Sequence[HTMALegacyIssueLogRecord],
) -> dict[str, _PreparedHTMALegacyIssueLogRecord]:
    prepared_records: dict[str, _PreparedHTMALegacyIssueLogRecord] = {}
    for legacy_record in legacy_issue_logs:
        source_record_id = _normalize_source_record_id(legacy_record.legacy_issue_id)
        if source_record_id is None:
            raise ValidationFailedError("legacy issue id is required")
        if source_record_id in prepared_records:
            raise ValidationFailedError("legacy issue ids must be unique per import batch")

        parent_source_id = _normalize_source_record_id(legacy_record.parent_legacy_issue_id)
        desired_status, desired_resolved_at = _desired_case_state(legacy_record)
        status_timestamp = _legacy_status_timestamp(legacy_record)
        prepared_records[source_record_id] = _PreparedHTMALegacyIssueLogRecord(
            record=legacy_record,
            source_record_id=source_record_id,
            parent_source_id=parent_source_id,
            status_timestamp=status_timestamp,
            desired_status=desired_status,
            desired_resolved_at=desired_resolved_at,
            sort_key=(status_timestamp, source_record_id),
        )

    return prepared_records


def _build_htma_import_graph(
    prepared_records: dict[str, _PreparedHTMALegacyIssueLogRecord],
) -> _HTMAImportGraph:
    pending_record_ids = set(prepared_records)
    children_by_parent: dict[str, list[str]] = {}
    ready_record_ids: list[str] = []

    for source_record_id, prepared_record in prepared_records.items():
        parent_source_id = prepared_record.parent_source_id
        if parent_source_id is None or parent_source_id not in prepared_records:
            ready_record_ids.append(source_record_id)
            continue
        children_by_parent.setdefault(parent_source_id, []).append(source_record_id)

    return _HTMAImportGraph(
        pending_record_ids=pending_record_ids,
        children_by_parent=children_by_parent,
        ready_record_ids=ready_record_ids,
    )


def _select_htma_import_batch(
    *,
    ready_record_ids: list[str],
    pending_record_ids: set[str],
    prepared_records: dict[str, _PreparedHTMALegacyIssueLogRecord],
) -> list[str]:
    candidate_ids = (
        (source_record_id for source_record_id in ready_record_ids if source_record_id in pending_record_ids)
        if ready_record_ids
        else pending_record_ids
    )
    return sorted(
        candidate_ids,
        key=lambda source_record_id: prepared_records[source_record_id].sort_key,
    )


def _count_lineages_with_status(status_by_root: dict[str, str], desired_status: str) -> int:
    return sum(1 for status in status_by_root.values() if status == desired_status)


def _derive_reporter_role_hint(*, reporter_role_hint: str | None, user_roles: list[str] | set[str] | None) -> str:
    if reporter_role_hint and reporter_role_hint.strip():
        return reporter_role_hint.strip()

    roles = [str(role).strip() for role in (user_roles or []) if str(role).strip()]
    for preferred in ("practitioner", "patient", "user"):
        if preferred in roles:
            return preferred
    if roles:
        return roles[0]
    return "user"


def _actor_type_for_support_event(role_hint: str) -> str:
    if role_hint == "practitioner":
        return "practitioner"
    return "user"


def _linked_case_to_dict(case: SupportCase) -> dict[str, Any]:
    return {
        "case_id": str(case.id),
        "status": case.status,
        "priority": case.priority,
        "resolved_at": _iso(case.resolved_at),
    }


def _issue_report_to_dict(issue_report: IssueReport, case: SupportCase) -> dict[str, Any]:
    return {
        "id": str(issue_report.id),
        "application_id": str(issue_report.application_id),
        "reporter_user_id": str(issue_report.reporter_user_id),
        "reporter_role_hint": issue_report.reporter_role_hint,
        "target": {
            "component_key": issue_report.component_key,
            "component_label": issue_report.component_label,
            "page_url": issue_report.page_url,
            "surface_ref": issue_report.surface_ref,
            "metadata": issue_report.target_metadata or {},
        },
        "note": issue_report.note,
        "status": case.status,
        "parent_issue_report_id": (
            str(issue_report.parent_issue_report_id) if issue_report.parent_issue_report_id else None
        ),
        "linked_case": _linked_case_to_dict(case),
        "created_at": _iso(issue_report.created_at),
        "updated_at": _iso(issue_report.updated_at),
    }


def _resolve_elevenlabs_api_key(*, settings: Any | None = None) -> str:
    active_settings = settings if settings is not None else get_spaps_settings()
    api_key = str(getattr(active_settings, "elevenlabs_api_key", "") or "").strip()
    if not api_key:
        raise IssueReportVoiceUnavailableError()
    return api_key


async def create_voice_token(*, settings: Any | None = None) -> dict[str, Any]:
    """Mint an ElevenLabs realtime-scribe single-use token."""
    api_key = _resolve_elevenlabs_api_key(settings=settings)

    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(10.0, connect=3.0)) as client:
            response = await client.post(
                ELEVENLABS_SCRIBE_TOKEN_URL,
                headers={"xi-api-key": api_key},
            )
    except httpx.HTTPError as exc:
        raise IssueReportVoiceUnavailableError() from exc

    if response.status_code < 200 or response.status_code >= 300:
        raise IssueReportVoiceUnavailableError()

    try:
        payload = response.json()
    except ValueError as exc:
        raise IssueReportVoiceUnavailableError() from exc

    token = str(payload.get("token") if isinstance(payload, dict) else "").strip()
    if not token:
        raise IssueReportVoiceUnavailableError()

    return {
        "provider": VOICE_TOKEN_PROVIDER,
        "model_id": VOICE_TOKEN_MODEL,
        "token": token,
        "expires_in_seconds": VOICE_TOKEN_TTL_SECONDS,
        "retain_audio": VOICE_TOKEN_RETAIN_AUDIO_DEFAULT,
        "attach_transcript": VOICE_TOKEN_ATTACH_TRANSCRIPT_DEFAULT,
    }


def _ensure_linked_case(row: tuple[IssueReport, SupportCase | None] | None) -> tuple[IssueReport, SupportCase]:
    if row is None:
        raise IssueReportNotFoundError()
    issue_report, case = row
    if case is None:
        raise IssueReportCaseLinkBrokenError()
    return issue_report, case


async def create_issue_report(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    reporter_role_hint: str | None,
    user_roles: list[str] | set[str] | None,
    target: dict[str, Any],
    note: str,
) -> dict[str, Any]:
    """Create one canonical issue report and linked support case."""
    normalized_target = _normalize_target(target)
    normalized_note = _normalize_note(note)
    effective_role_hint = _derive_reporter_role_hint(
        reporter_role_hint=reporter_role_hint,
        user_roles=user_roles,
    )
    now = datetime.now(UTC)

    case = await support_repo.create_case(
        db,
        application_id=application_id,
        external_case_ref=None,
        title=normalized_target["component_label"],
        status="open",
        priority="normal",
        highest_severity="warning",
        first_event_at=now,
        last_event_at=now,
    )

    issue_report = await repo.create_issue_report(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
        reporter_role_hint=effective_role_hint,
        component_key=normalized_target["component_key"],
        component_label=normalized_target["component_label"],
        page_url=normalized_target["page_url"],
        surface_ref=normalized_target["surface_ref"],
        target_metadata=normalized_target["metadata"],
        note=normalized_note,
        parent_issue_report_id=None,
        support_case_id=case.id,
    )

    event = await support_repo.create_event(
        db,
        case_id=case.id,
        application_id=application_id,
        event_key=f"issue_report_created_{uuid4().hex}"[:128],
        source_channel="frontend",
        event_type="issue_reported",
        severity="warning",
        actor_type=_actor_type_for_support_event(effective_role_hint),
        actor_external_id=str(reporter_user_id),
        correlation_id=None,
        payload={
            "issue_report_id": str(issue_report.id),
            "reporter_role_hint": effective_role_hint,
            "target": normalized_target,
            "note": normalized_note,
        },
        redacted_keys=[],
        occurred_at=now,
        ingested_by_user_id=reporter_user_id,
    )
    case = await support_repo.update_case_summary(
        db,
        case=case,
        occurred_at=event.occurred_at,
        severity="warning",
        title=normalized_target["component_label"],
    )
    return _issue_report_to_dict(issue_report, case)


async def _apply_case_state(
    db: AsyncSession,
    *,
    case: SupportCase,
    desired_status: str,
    desired_resolved_at: datetime | None,
) -> SupportCase:
    if case.status == desired_status and case.resolved_at == desired_resolved_at:
        return case
    return await support_repo.update_case(
        db,
        case=case,
        status=desired_status,
        resolved_at=desired_resolved_at,
        set_resolved_at=True,
    )


async def _import_htma_issue_log_record(
    db: AsyncSession,
    *,
    application_id: UUID,
    prepared_record: _PreparedHTMALegacyIssueLogRecord,
    parent_issue_report: IssueReport | None,
    orphaned_reply: bool,
) -> tuple[IssueReport, SupportCase, bool, bool]:
    legacy_record = prepared_record.record
    source_record_id = prepared_record.source_record_id

    existing_issue_report = await repo.get_issue_report_by_source_record(
        db,
        application_id=application_id,
        source_app=HTMA_IMPORT_SOURCE,
        source_record_id=source_record_id,
    )
    if existing_issue_report is not None:
        case = await support_repo.get_case_by_id(
            db,
            case_id=existing_issue_report.support_case_id,
            application_id=application_id,
        )
        if case is None:
            raise IssueReportCaseLinkBrokenError()
        return existing_issue_report, case, False, False

    created_case = False

    if parent_issue_report is None:
        case = await support_repo.get_case_by_external_ref(
            db,
            application_id=application_id,
            external_case_ref=_htma_external_case_ref(source_record_id),
        )
        if case is None:
            created_case = True
            case = await support_repo.create_case(
                db,
                application_id=application_id,
                external_case_ref=_htma_external_case_ref(source_record_id),
                title=legacy_record.component_label,
                status=prepared_record.desired_status,
                priority="normal",
                highest_severity="warning",
                first_event_at=legacy_record.created_at,
                last_event_at=prepared_record.status_timestamp,
            )
    else:
        case = await support_repo.get_case_by_id(
            db,
            case_id=parent_issue_report.support_case_id,
            application_id=application_id,
        )
        if case is None:
            raise IssueReportCaseLinkBrokenError()

    case = await _apply_case_state(
        db,
        case=case,
        desired_status=prepared_record.desired_status,
        desired_resolved_at=prepared_record.desired_resolved_at,
    )
    issue_report = await repo.create_issue_report(
        db,
        application_id=application_id,
        reporter_user_id=legacy_record.reporter_user_id,
        reporter_role_hint=_derive_reporter_role_hint(
            reporter_role_hint=legacy_record.reporter_role_hint,
            user_roles=None,
        ),
        component_key=_derive_component_key(
            component_key=legacy_record.component_key,
            component_label=legacy_record.component_label,
        ),
        component_label=legacy_record.component_label.strip(),
        page_url=legacy_record.page_url.strip(),
        surface_ref=legacy_record.surface_ref.strip() if legacy_record.surface_ref else None,
        target_metadata=legacy_record.target_metadata,
        note=_normalize_note(legacy_record.note),
        parent_issue_report_id=parent_issue_report.id if parent_issue_report else None,
        support_case_id=case.id,
        source_app=HTMA_IMPORT_SOURCE,
        source_record_id=source_record_id,
        created_at=legacy_record.created_at,
        updated_at=legacy_record.updated_at,
    )
    event = await support_repo.create_event(
        db,
        case_id=case.id,
        application_id=application_id,
        event_key=f"htma_issue_log_import_{source_record_id}"[:128],
        source_channel="issue_log",
        event_type="issue_report_reply_imported" if parent_issue_report else "issue_report_imported",
        severity="warning",
        actor_type=_actor_type_for_support_event(legacy_record.reporter_role_hint),
        actor_external_id=str(legacy_record.reporter_user_id),
        correlation_id=None,
        payload={
            "issue_report_id": str(issue_report.id),
            "legacy_issue_id": source_record_id,
            "source_app": HTMA_IMPORT_SOURCE,
            "parent_legacy_issue_id": prepared_record.parent_source_id,
            "orphaned_reply_promoted": orphaned_reply,
            "status_after_import": prepared_record.desired_status,
        },
        redacted_keys=[],
        occurred_at=legacy_record.created_at,
        ingested_by_user_id=None,
    )
    case = await support_repo.update_case_summary(
        db,
        case=case,
        occurred_at=max(event.occurred_at, prepared_record.status_timestamp),
        severity="warning",
        title=legacy_record.component_label,
    )
    return issue_report, case, True, created_case


async def import_htma_issue_logs(
    db: AsyncSession,
    *,
    application_id: UUID,
    legacy_issue_logs: Sequence[HTMALegacyIssueLogRecord],
) -> dict[str, Any]:
    """Import legacy HTMA issue-log rows into canonical issue reports."""
    if not legacy_issue_logs:
        return {
            "total_legacy_records": 0,
            "created_issue_reports": 0,
            "reused_issue_reports": 0,
            "created_support_cases": 0,
            "reused_support_cases": 0,
            "root_count": 0,
            "reply_count": 0,
            "orphaned_reply_count": 0,
            "parity": {
                "expected_open_lineages": 0,
                "expected_resolved_lineages": 0,
                "imported_open_lineages": 0,
                "imported_resolved_lineages": 0,
                "record_count_match": True,
                "lineage_count_match": True,
                "lineage_status_match": True,
                "ok": True,
            },
        }

    prepared_records = _prepare_legacy_issue_log_records(legacy_issue_logs)
    import_graph = _build_htma_import_graph(prepared_records)
    pending_record_ids = import_graph.pending_record_ids
    children_by_parent = import_graph.children_by_parent
    ready_record_ids = import_graph.ready_record_ids

    imported_by_source_id: dict[str, IssueReport] = {}
    root_source_by_record_id: dict[str, str] = {}
    legacy_lineage_status_by_root: dict[str, str] = {}
    legacy_lineage_timestamp_by_root: dict[str, datetime] = {}
    imported_case_status_by_root: dict[str, str] = {}
    created_issue_report_ids: set[UUID] = set()
    reused_issue_report_ids: set[UUID] = set()
    created_support_case_ids: set[UUID] = set()
    reused_support_case_ids: set[UUID] = set()
    root_count = 0
    reply_count = 0
    orphaned_reply_count = 0

    while pending_record_ids:
        current_batch_ids = _select_htma_import_batch(
            ready_record_ids=ready_record_ids,
            pending_record_ids=pending_record_ids,
            prepared_records=prepared_records,
        )
        ready_record_ids = []
        next_ready_record_ids: set[str] = set()

        for source_record_id in current_batch_ids:
            if source_record_id not in pending_record_ids:
                continue

            pending_record_ids.remove(source_record_id)
            prepared_record = prepared_records[source_record_id]
            parent_source_id = prepared_record.parent_source_id
            parent_issue_report = imported_by_source_id.get(parent_source_id) if parent_source_id else None
            orphaned_reply = parent_source_id is not None and parent_issue_report is None
            if parent_issue_report is None:
                root_count += 1
                root_source_id = source_record_id
            else:
                assert parent_source_id is not None
                reply_count += 1
                root_source_id = root_source_by_record_id[parent_source_id]
            if orphaned_reply:
                orphaned_reply_count += 1

            issue_report, case, created_issue_report, created_support_case = await _import_htma_issue_log_record(
                db,
                application_id=application_id,
                prepared_record=prepared_record,
                parent_issue_report=parent_issue_report,
                orphaned_reply=orphaned_reply,
            )
            imported_by_source_id[source_record_id] = issue_report
            root_source_by_record_id[source_record_id] = root_source_id

            if created_issue_report:
                created_issue_report_ids.add(issue_report.id)
            else:
                reused_issue_report_ids.add(issue_report.id)

            if created_support_case:
                created_support_case_ids.add(case.id)
                reused_support_case_ids.discard(case.id)
            elif case.id not in created_support_case_ids:
                reused_support_case_ids.add(case.id)

            status_timestamp = prepared_record.status_timestamp
            if status_timestamp >= legacy_lineage_timestamp_by_root.get(root_source_id, _MIN_UTC_DATETIME):
                legacy_lineage_timestamp_by_root[root_source_id] = status_timestamp
                legacy_lineage_status_by_root[root_source_id] = prepared_record.desired_status
            imported_case_status_by_root[root_source_id] = case.status

            for child_source_id in children_by_parent.get(source_record_id, ()):
                if child_source_id in pending_record_ids:
                    next_ready_record_ids.add(child_source_id)

        ready_record_ids = list(next_ready_record_ids)

    expected_open_lineages = _count_lineages_with_status(legacy_lineage_status_by_root, "open")
    expected_resolved_lineages = _count_lineages_with_status(legacy_lineage_status_by_root, "resolved")
    imported_open_lineages = _count_lineages_with_status(imported_case_status_by_root, "open")
    imported_resolved_lineages = _count_lineages_with_status(imported_case_status_by_root, "resolved")
    parity = {
        "expected_open_lineages": expected_open_lineages,
        "expected_resolved_lineages": expected_resolved_lineages,
        "imported_open_lineages": imported_open_lineages,
        "imported_resolved_lineages": imported_resolved_lineages,
        "record_count_match": len(imported_by_source_id) == len(legacy_issue_logs),
        "lineage_count_match": len(imported_case_status_by_root) == root_count,
        "lineage_status_match": (
            expected_open_lineages == imported_open_lineages
            and expected_resolved_lineages == imported_resolved_lineages
        ),
    }
    parity["ok"] = all(
        bool(parity[key])
        for key in ("record_count_match", "lineage_count_match", "lineage_status_match")
    )
    return {
        "total_legacy_records": len(legacy_issue_logs),
        "created_issue_reports": len(created_issue_report_ids),
        "reused_issue_reports": len(reused_issue_report_ids),
        "created_support_cases": len(created_support_case_ids),
        "reused_support_cases": len(reused_support_case_ids),
        "root_count": root_count,
        "reply_count": reply_count,
        "orphaned_reply_count": orphaned_reply_count,
        "parity": parity,
    }


async def list_issue_reports(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    status: str | None,
    limit: int,
    offset: int,
) -> dict[str, Any]:
    """List one reporter's issue reports inside the active app scope."""
    rows, total = await repo.list_issue_report_rows(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
        status=status,
        limit=limit,
        offset=offset,
    )
    items = []
    for row in rows:
        issue_report, case = _ensure_linked_case(row)
        items.append(_issue_report_to_dict(issue_report, case))
    return {"items": items, "total": total}


async def get_issue_report_detail(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    issue_report_id: UUID,
) -> dict[str, Any]:
    """Return one caller-owned issue report."""
    row = await repo.get_issue_report_row(
        db,
        issue_report_id=issue_report_id,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
    )
    issue_report, case = _ensure_linked_case(row)
    return _issue_report_to_dict(issue_report, case)


async def update_issue_report_note(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    issue_report_id: UUID,
    note: str,
    reporter_role_hint: str | None,
    user_roles: list[str] | set[str] | None,
) -> dict[str, Any]:
    """Edit the note of an unresolved issue report."""
    normalized_note = _normalize_note(note)
    row = await repo.get_issue_report_row(
        db,
        issue_report_id=issue_report_id,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
    )
    issue_report, case = _ensure_linked_case(row)
    if case.status in {"resolved", "ignored"}:
        raise IssueReportCannotEditClosedError()

    previous_note = issue_report.note
    updated_issue_report = await repo.update_issue_report_note(
        db,
        issue_report=issue_report,
        note=normalized_note,
    )
    now = datetime.now(UTC)
    effective_role_hint = _derive_reporter_role_hint(
        reporter_role_hint=reporter_role_hint,
        user_roles=user_roles,
    )
    event = await support_repo.create_event(
        db,
        case_id=case.id,
        application_id=application_id,
        event_key=f"issue_report_edit_{uuid4().hex}"[:128],
        source_channel="frontend",
        event_type="issue_report_note_edited",
        severity="info",
        actor_type=_actor_type_for_support_event(effective_role_hint),
        actor_external_id=str(reporter_user_id),
        correlation_id=None,
        payload={
            "issue_report_id": str(updated_issue_report.id),
            "previous_note": previous_note,
            "note": normalized_note,
        },
        redacted_keys=[],
        occurred_at=now,
        ingested_by_user_id=reporter_user_id,
    )
    case = await support_repo.update_case_summary(
        db,
        case=case,
        occurred_at=event.occurred_at,
        severity="info",
        title=case.title,
    )
    return _issue_report_to_dict(updated_issue_report, case)


async def reply_to_issue_report(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    issue_report_id: UUID,
    note: str,
    reporter_role_hint: str | None,
    user_roles: list[str] | set[str] | None,
) -> dict[str, Any]:
    """Create a child issue report and reopen the linked case."""
    normalized_note = _normalize_note(note)
    row = await repo.get_issue_report_row(
        db,
        issue_report_id=issue_report_id,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
    )
    parent_issue_report, case = _ensure_linked_case(row)
    if case.status not in {"resolved", "ignored"}:
        raise IssueReportCannotReplyOpenError()

    effective_role_hint = _derive_reporter_role_hint(
        reporter_role_hint=reporter_role_hint,
        user_roles=user_roles,
    )
    previous_case_status = case.status
    child_issue_report = await repo.create_issue_report(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
        reporter_role_hint=effective_role_hint,
        component_key=parent_issue_report.component_key,
        component_label=parent_issue_report.component_label,
        page_url=parent_issue_report.page_url,
        surface_ref=parent_issue_report.surface_ref,
        target_metadata=parent_issue_report.target_metadata or {},
        note=normalized_note,
        parent_issue_report_id=parent_issue_report.id,
        support_case_id=case.id,
    )

    reopened_case = await support_repo.update_case(
        db,
        case=case,
        status="open",
        resolved_at=None,
        set_resolved_at=True,
    )
    now = datetime.now(UTC)
    event = await support_repo.create_event(
        db,
        case_id=reopened_case.id,
        application_id=application_id,
        event_key=f"issue_report_reply_{uuid4().hex}"[:128],
        source_channel="frontend",
        event_type="issue_report_replied",
        severity="warning",
        actor_type=_actor_type_for_support_event(effective_role_hint),
        actor_external_id=str(reporter_user_id),
        correlation_id=None,
        payload={
            "issue_report_id": str(child_issue_report.id),
            "parent_issue_report_id": str(parent_issue_report.id),
            "previous_case_status": previous_case_status,
            "note": normalized_note,
        },
        redacted_keys=[],
        occurred_at=now,
        ingested_by_user_id=reporter_user_id,
    )
    reopened_case = await support_repo.update_case_summary(
        db,
        case=reopened_case,
        occurred_at=event.occurred_at,
        severity="warning",
        title=reopened_case.title,
    )
    return _issue_report_to_dict(child_issue_report, reopened_case)


async def get_issue_report_status(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
) -> dict[str, Any]:
    """Return aggregate reporter status used by the floating entrypoint."""
    open_count = await repo.count_open_issue_reports(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
    )
    recent_resolved_count = await repo.count_recent_resolved_issue_reports(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
        resolved_since=datetime.now(UTC) - timedelta(days=RECENT_RESOLVED_WINDOW_DAYS),
    )
    return {
        "has_open": open_count > 0,
        "has_recent_resolved": recent_resolved_count > 0,
        "open_count": open_count,
        "recent_resolved_count": recent_resolved_count,
    }
