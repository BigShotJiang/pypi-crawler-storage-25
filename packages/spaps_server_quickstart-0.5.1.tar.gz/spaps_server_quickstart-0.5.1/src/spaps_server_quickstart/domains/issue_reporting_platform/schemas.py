"""Pydantic schemas for issue reporting platform endpoints."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

SupportCaseStatus = Literal["open", "in_progress", "resolved", "ignored"]
SupportCasePriority = Literal["low", "normal", "high", "urgent"]
IssueReportingVoiceProvider = Literal["elevenlabs_scribe_realtime"]
IssueReportingVoiceModel = Literal["scribe_v2_realtime"]
IssueReportScope = Literal["mine"]


class IssueReportTargetIn(BaseModel):
    """Immutable target snapshot captured at create time."""

    component_key: str = Field(..., min_length=1, max_length=255)
    component_label: str = Field(..., min_length=1, max_length=255)
    page_url: str = Field(..., min_length=1, max_length=500)
    surface_ref: str | None = Field(default=None, max_length=255)
    metadata: dict[str, Any] = Field(default_factory=dict)


class CreateIssueReportRequest(BaseModel):
    """POST /v1/issue-reports request body."""

    target: IssueReportTargetIn
    note: str = Field(..., min_length=10, max_length=2000)
    reporter_role_hint: str | None = Field(default=None, max_length=64)


class UpdateIssueReportRequest(BaseModel):
    """PATCH /v1/issue-reports/{issue_report_id} request body."""

    note: str = Field(..., min_length=10, max_length=2000)


class ReplyIssueReportRequest(BaseModel):
    """POST /v1/issue-reports/{issue_report_id}/replies request body."""

    note: str = Field(..., min_length=10, max_length=2000)
    reporter_role_hint: str | None = Field(default=None, max_length=64)


class IssueReportTargetOut(BaseModel):
    """Immutable target snapshot returned to consumers."""

    component_key: str
    component_label: str
    page_url: str
    surface_ref: str | None = None
    metadata: dict[str, Any]


class LinkedCaseSummary(BaseModel):
    """Linked support-case summary projected into the issue-report surface."""

    case_id: str
    status: SupportCaseStatus
    priority: SupportCasePriority
    resolved_at: str | None = None


class IssueReportOut(BaseModel):
    """Canonical issue-report payload."""

    id: str
    application_id: str
    reporter_user_id: str
    reporter_role_hint: str | None = None
    target: IssueReportTargetOut
    note: str
    status: SupportCaseStatus
    parent_issue_report_id: str | None = None
    linked_case: LinkedCaseSummary
    created_at: str
    updated_at: str


class ListIssueReportsResponse(BaseModel):
    """GET /v1/issue-reports response."""

    items: list[IssueReportOut]
    total: int


class IssueReportStatusResponse(BaseModel):
    """GET /v1/issue-reports/status response."""

    has_open: bool
    has_recent_resolved: bool
    open_count: int
    recent_resolved_count: int


class IssueReportVoiceTokenResponse(BaseModel):
    """POST /v1/issue-reports/voice-token response."""

    provider: IssueReportingVoiceProvider
    model_id: IssueReportingVoiceModel
    token: str = Field(..., min_length=1, max_length=4096)
    expires_in_seconds: int = Field(..., ge=1)
    retain_audio: bool
    attach_transcript: bool
