"""HTTP routes for the issue_reporting_platform domain."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from fastapi import APIRouter, Query

from ...middleware.spaps_deps import Application, DbSession, OptionalUser
from ..users import repository as user_repo
from . import service
from .errors import NotAuthenticatedError, NotAuthorizedError, ValidationFailedError
from .schemas import (
    CreateIssueReportRequest,
    IssueReportOut,
    IssueReportScope,
    IssueReportStatusResponse,
    IssueReportVoiceTokenResponse,
    ListIssueReportsResponse,
    ReplyIssueReportRequest,
    SupportCaseStatus,
    UpdateIssueReportRequest,
)

router = APIRouter(prefix="/v1/issue-reports", tags=["issue-reports"])
DEFAULT_ISSUE_REPORTING_CAPABILITY = "issue_reporting"
_CAPABILITY_COLLECTION_KEYS = ("capabilities", "permissions", "scopes")
DEFAULT_ISSUE_REPORTING_INPUT_MODES = ("text",)
VOICE_INPUT_MODE = "voice"


def _as_uuid(value: str, field_name: str) -> UUID:
    try:
        return UUID(str(value))
    except (TypeError, ValueError) as exc:
        raise ValidationFailedError(f"{field_name} must be a valid UUID") from exc


def _ensure_authenticated_user(optional_user: Any | None) -> Any:
    if optional_user is None:
        raise NotAuthenticatedError()
    return optional_user


def _coerce_bool(value: object, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
    return bool(value)


def _normalize_capability_names(value: object) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        items = value.split(",")
    elif isinstance(value, (list, tuple, set)):
        items = list(value)
    else:
        return ()

    normalized: list[str] = []
    seen: set[str] = set()
    for item in items:
        candidate = str(item).strip()
        if candidate and candidate not in seen:
            normalized.append(candidate)
            seen.add(candidate)
    return tuple(normalized)


def _get_setting_value(app: Any, name: str) -> object | None:
    settings = getattr(app, "settings", None) or {}
    if isinstance(settings, dict):
        return settings.get(name)
    return getattr(settings, name, None)


def _required_issue_reporting_capabilities(app: Any) -> tuple[str, ...]:
    configured = _normalize_capability_names(_get_setting_value(app, "issue_reporting_required_capabilities"))
    if configured:
        return configured

    configured_single = _normalize_capability_names(_get_setting_value(app, "issue_reporting_required_capability"))
    if configured_single:
        return configured_single

    return (DEFAULT_ISSUE_REPORTING_CAPABILITY,)


def _normalize_issue_reporting_input_modes(value: object) -> tuple[str, ...]:
    raw_values = _normalize_capability_names(value)
    if not raw_values:
        return ()

    normalized: list[str] = []
    seen: set[str] = set()
    for item in raw_values:
        normalized_item = item.strip().lower()
        if normalized_item and normalized_item not in seen:
            normalized.append(normalized_item)
            seen.add(normalized_item)
    return tuple(normalized)


def _issue_reporting_input_modes(app: Any) -> tuple[str, ...]:
    flat_modes = _normalize_issue_reporting_input_modes(
        _get_setting_value(app, "issue_reporting_input_modes")
    )
    if flat_modes:
        return flat_modes

    issue_reporting_settings = _get_setting_value(app, "issue_reporting")
    nested_modes_value: object | None = None
    if isinstance(issue_reporting_settings, dict):
        nested_modes_value = issue_reporting_settings.get("input_modes")
    elif issue_reporting_settings is not None:
        nested_modes_value = getattr(issue_reporting_settings, "input_modes", None)

    nested_modes = _normalize_issue_reporting_input_modes(nested_modes_value)
    if nested_modes:
        return nested_modes

    return DEFAULT_ISSUE_REPORTING_INPUT_MODES


def _capability_granted(permission_blob: object, required_capabilities: tuple[str, ...]) -> bool:
    if not required_capabilities:
        return True

    required = set(required_capabilities)

    if isinstance(permission_blob, dict):
        for capability in required_capabilities:
            if capability in permission_blob and _coerce_bool(permission_blob.get(capability), default=False):
                return True
        for key in _CAPABILITY_COLLECTION_KEYS:
            if _capability_granted(permission_blob.get(key), required_capabilities):
                return True
        return False

    if isinstance(permission_blob, (list, tuple, set)):
        return bool(required.intersection({str(item).strip() for item in permission_blob if str(item).strip()}))

    if isinstance(permission_blob, str):
        return permission_blob.strip() in required

    return False


def _application_scope_matches(user: Any, app: Any) -> bool:
    user_application_id = getattr(user, "application_id", None)
    if user_application_id is None:
        return True
    try:
        return UUID(str(user_application_id)) == UUID(str(app.id))
    except (TypeError, ValueError):
        return str(user_application_id) == str(app.id)


def _enforce_issue_reporting_enabled(app: Any) -> None:
    enabled = _coerce_bool(_get_setting_value(app, "issue_reporting_enabled"), default=True)
    if not enabled:
        raise NotAuthorizedError("Issue reporting is disabled for this application")


def _enforce_voice_issue_reporting_enabled(app: Any) -> None:
    if VOICE_INPUT_MODE not in _issue_reporting_input_modes(app):
        raise NotAuthorizedError("Voice input is not enabled for this application")


async def _enforce_issue_reporting_access(db: Any, app: Any, user: Any) -> None:
    _enforce_issue_reporting_enabled(app)

    if not _application_scope_matches(user, app):
        raise NotAuthorizedError("Caller application scope does not match the active application")

    required_capabilities = _required_issue_reporting_capabilities(app)
    if _capability_granted(getattr(user, "permissions", None), required_capabilities):
        return

    user_application = await user_repo.get_user_application(db, str(user.id), str(app.id))
    if user_application is None:
        raise NotAuthorizedError("Caller is not eligible for issue reporting in this application")

    if not _capability_granted(getattr(user_application, "permissions", None), required_capabilities):
        raise NotAuthorizedError("Caller is not eligible for issue reporting in this application")


@router.post("", response_model=IssueReportOut, status_code=201)
async def create_issue_report(
    body: CreateIssueReportRequest,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
) -> IssueReportOut:
    """Create one canonical issue report for the authenticated app user."""
    user = _ensure_authenticated_user(optional_user)
    await _enforce_issue_reporting_access(db, app, user)
    result = await service.create_issue_report(
        db,
        application_id=_as_uuid(str(app.id), "application.id"),
        reporter_user_id=_as_uuid(str(user.id), "user.id"),
        reporter_role_hint=body.reporter_role_hint,
        user_roles=getattr(user, "roles", []),
        target=body.target.model_dump(),
        note=body.note,
    )
    return IssueReportOut(**result)


@router.post("/voice-token", response_model=IssueReportVoiceTokenResponse)
async def create_voice_token(
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
) -> IssueReportVoiceTokenResponse:
    """Mint a browser-safe voice token for eligible authenticated app users."""
    user = _ensure_authenticated_user(optional_user)
    await _enforce_issue_reporting_access(db, app, user)
    _enforce_voice_issue_reporting_enabled(app)
    result = await service.create_voice_token()
    return IssueReportVoiceTokenResponse(**result)


@router.get("", response_model=ListIssueReportsResponse)
async def list_issue_reports(
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
    status: SupportCaseStatus | None = Query(default=None),
    scope: IssueReportScope = Query(default="mine"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> ListIssueReportsResponse:
    """List caller-owned issue reports inside the active application scope."""
    user = _ensure_authenticated_user(optional_user)
    await _enforce_issue_reporting_access(db, app, user)
    result = await service.list_issue_reports(
        db,
        application_id=_as_uuid(str(app.id), "application.id"),
        reporter_user_id=_as_uuid(str(user.id), "user.id"),
        status=status,
        limit=limit,
        offset=offset,
    )
    return ListIssueReportsResponse(**result)


@router.get("/status", response_model=IssueReportStatusResponse)
async def get_issue_report_status(
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
    scope: IssueReportScope = Query(default="mine"),
) -> IssueReportStatusResponse:
    """Return aggregate issue-report status for the floating entrypoint."""
    user = _ensure_authenticated_user(optional_user)
    await _enforce_issue_reporting_access(db, app, user)
    result = await service.get_issue_report_status(
        db,
        application_id=_as_uuid(str(app.id), "application.id"),
        reporter_user_id=_as_uuid(str(user.id), "user.id"),
    )
    return IssueReportStatusResponse(**result)


@router.get("/{issue_report_id}", response_model=IssueReportOut)
async def get_issue_report_detail(
    issue_report_id: str,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
) -> IssueReportOut:
    """Return one caller-owned issue report."""
    user = _ensure_authenticated_user(optional_user)
    await _enforce_issue_reporting_access(db, app, user)
    result = await service.get_issue_report_detail(
        db,
        application_id=_as_uuid(str(app.id), "application.id"),
        reporter_user_id=_as_uuid(str(user.id), "user.id"),
        issue_report_id=_as_uuid(issue_report_id, "issue_report_id"),
    )
    return IssueReportOut(**result)


@router.patch("/{issue_report_id}", response_model=IssueReportOut)
async def update_issue_report(
    issue_report_id: str,
    body: UpdateIssueReportRequest,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
) -> IssueReportOut:
    """Edit the note for an unresolved caller-owned issue report."""
    user = _ensure_authenticated_user(optional_user)
    await _enforce_issue_reporting_access(db, app, user)
    result = await service.update_issue_report_note(
        db,
        application_id=_as_uuid(str(app.id), "application.id"),
        reporter_user_id=_as_uuid(str(user.id), "user.id"),
        issue_report_id=_as_uuid(issue_report_id, "issue_report_id"),
        note=body.note,
        reporter_role_hint=None,
        user_roles=getattr(user, "roles", []),
    )
    return IssueReportOut(**result)


@router.post("/{issue_report_id}/replies", response_model=IssueReportOut, status_code=201)
async def reply_to_issue_report(
    issue_report_id: str,
    body: ReplyIssueReportRequest,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
) -> IssueReportOut:
    """Create a child issue report and reopen the linked case."""
    user = _ensure_authenticated_user(optional_user)
    await _enforce_issue_reporting_access(db, app, user)
    result = await service.reply_to_issue_report(
        db,
        application_id=_as_uuid(str(app.id), "application.id"),
        reporter_user_id=_as_uuid(str(user.id), "user.id"),
        issue_report_id=_as_uuid(issue_report_id, "issue_report_id"),
        note=body.note,
        reporter_role_hint=body.reporter_role_hint,
        user_roles=getattr(user, "roles", []),
    )
    return IssueReportOut(**result)
