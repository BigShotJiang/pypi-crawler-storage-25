"""Register all SQLAlchemy model modules for runtime metadata resolution."""

from __future__ import annotations

from importlib import import_module

_MODEL_MODULES = (
    "spaps_server_quickstart.domains.affiliate_referrals.models",
    "spaps_server_quickstart.domains.agent_approvals.models",
    "spaps_server_quickstart.domains.billing_accounts.models",
    "spaps_server_quickstart.domains.applications.models",
    "spaps_server_quickstart.domains.approval_authz_prod_hardening.models",
    "spaps_server_quickstart.domains.audit.models",
    "spaps_server_quickstart.domains.cfo.models",
    "spaps_server_quickstart.domains.crypto.models",
    "spaps_server_quickstart.domains.dayrate.models",
    "spaps_server_quickstart.domains.docs.models",
    "spaps_server_quickstart.domains.email.models",
    "spaps_server_quickstart.domains.entitlements.models",
    "spaps_server_quickstart.domains.issue_reporting_platform.models",
    "spaps_server_quickstart.domains.policies.models",
    "spaps_server_quickstart.domains.secure_messages.models",
    "spaps_server_quickstart.domains.security.models",
    "spaps_server_quickstart.domains.sessions.models",
    "spaps_server_quickstart.domains.stripe.models",
    "spaps_server_quickstart.domains.support_telemetry_platform.models",
    "spaps_server_quickstart.domains.users.models",
    "spaps_server_quickstart.domains.wallets.models",
    "spaps_server_quickstart.domains.webhooks.models",
    "spaps_server_quickstart.domains.whitelist.models",
)


def import_all_models() -> None:
    """Import every domain model module so Base.metadata contains all tables."""
    for module_path in _MODEL_MODULES:
        import_module(module_path)
