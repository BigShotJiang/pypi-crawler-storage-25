"""Business logic for support telemetry platform domain."""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import UTC, datetime, timedelta
from typing import Any, cast
from uuid import UUID, uuid4

from sqlalchemy.ext.asyncio import AsyncSession

from ...spaps_settings import get_spaps_settings
from . import repository as repo
from .errors import (
    SupportTelemetryBackpressureError,
    SupportTelemetryCaseNotFoundError,
    SupportTelemetryEventTooOldError,
    SupportTelemetryInvalidTransitionError,
    SupportTelemetryPayloadTooLargeError,
    ValidationFailedError,
)
from .models import SupportCase, SupportCaseEvent

MAX_PAYLOAD_BYTES = 64 * 1024
MAX_EVENT_AGE_DAYS = 90

UNSET = object()
logger = logging.getLogger(__name__)

_SUPPORT_TELEMETRY_INGEST_INFLIGHT = 0
_SUPPORT_TELEMETRY_INGEST_LOCK = asyncio.Lock()

_ALLOWED_TRANSITIONS: dict[str, set[str]] = {
    "open": {"in_progress", "resolved", "ignored"},
    "in_progress": {"open", "resolved", "ignored"},
    "resolved": {"open"},
    "ignored": {"open"},
}

_SECRET_KEY_MARKERS = (
    "password",
    "secret",
    "token",
    "api_key",
    "authorization",
    "private_key",
    "refresh_token",
    "access_token",
)


def _ingest_backpressure_limit(settings: Any | None = None) -> int:
    active_settings = settings if settings is not None else get_spaps_settings()
    configured = getattr(active_settings, "support_telemetry_max_inflight_ingest", 0) or 0
    try:
        parsed = int(configured)
    except (TypeError, ValueError):
        return 0
    return max(parsed, 0)


async def _reserve_ingest_slot(settings: Any | None = None) -> bool:
    global _SUPPORT_TELEMETRY_INGEST_INFLIGHT

    limit = _ingest_backpressure_limit(settings)
    if limit <= 0:
        return False

    async with _SUPPORT_TELEMETRY_INGEST_LOCK:
        if _SUPPORT_TELEMETRY_INGEST_INFLIGHT >= limit:
            logger.warning(
                "support_telemetry_backpressure_triggered limit=%s inflight=%s",
                limit,
                _SUPPORT_TELEMETRY_INGEST_INFLIGHT,
            )
            raise SupportTelemetryBackpressureError()
        _SUPPORT_TELEMETRY_INGEST_INFLIGHT += 1
        return True


async def _release_ingest_slot(slot_reserved: bool) -> None:
    global _SUPPORT_TELEMETRY_INGEST_INFLIGHT

    if not slot_reserved:
        return

    async with _SUPPORT_TELEMETRY_INGEST_LOCK:
        _SUPPORT_TELEMETRY_INGEST_INFLIGHT = max(_SUPPORT_TELEMETRY_INGEST_INFLIGHT - 1, 0)


def _iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    return dt.isoformat()


def _case_summary_to_dict(case: SupportCase) -> dict[str, Any]:
    return {
        "id": str(case.id),
        "application_id": str(case.application_id),
        "external_case_ref": case.external_case_ref,
        "title": case.title,
        "status": case.status,
        "priority": case.priority,
        "highest_severity": case.highest_severity,
        "assigned_to_user_id": str(case.assigned_to_user_id) if case.assigned_to_user_id else None,
        "first_event_at": _iso(case.first_event_at),
        "last_event_at": _iso(case.last_event_at),
        "resolved_at": _iso(case.resolved_at),
        "created_at": _iso(case.created_at),
        "updated_at": _iso(case.updated_at),
    }


def _case_patch_to_dict(case: SupportCase) -> dict[str, Any]:
    return {
        "id": str(case.id),
        "status": case.status,
        "priority": case.priority,
        "assigned_to_user_id": str(case.assigned_to_user_id) if case.assigned_to_user_id else None,
        "resolved_at": _iso(case.resolved_at),
        "updated_at": _iso(case.updated_at),
    }


def _case_by_external_to_dict(case: SupportCase) -> dict[str, Any]:
    return {
        "id": str(case.id),
        "application_id": str(case.application_id),
        "external_case_ref": case.external_case_ref,
        "status": case.status,
        "priority": case.priority,
        "assigned_to_user_id": str(case.assigned_to_user_id) if case.assigned_to_user_id else None,
        "resolved_at": _iso(case.resolved_at),
        "updated_at": _iso(case.updated_at),
    }


def _event_to_dict(event: SupportCaseEvent) -> dict[str, Any]:
    return {
        "id": str(event.id),
        "case_id": str(event.case_id),
        "event_key": event.event_key,
        "source_channel": event.source_channel,
        "event_type": event.event_type,
        "severity": event.severity,
        "actor": {
            "type": event.actor_type,
            "id": event.actor_external_id,
        },
        "correlation_id": event.correlation_id,
        "occurred_at": _iso(event.occurred_at),
        "received_at": _iso(event.received_at),
        "payload": event.payload or {},
    }


def _validate_payload_size(payload: dict[str, Any]) -> None:
    try:
        size = len(json.dumps(payload).encode("utf-8"))
    except (TypeError, ValueError) as exc:
        raise ValidationFailedError("payload must be JSON serializable") from exc

    if size > MAX_PAYLOAD_BYTES:
        raise SupportTelemetryPayloadTooLargeError()


def _validate_event_age(occurred_at: datetime) -> None:
    now = datetime.now(UTC)
    if occurred_at.tzinfo is None:
        occurred_at = occurred_at.replace(tzinfo=UTC)
    if occurred_at < now - timedelta(days=MAX_EVENT_AGE_DAYS):
        raise SupportTelemetryEventTooOldError()


def _redact_payload(payload: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    redacted_keys: list[str] = []

    def _walk(value: Any) -> Any:
        if isinstance(value, dict):
            result: dict[str, Any] = {}
            for key, nested in value.items():
                key_lower = str(key).lower()
                if any(marker in key_lower for marker in _SECRET_KEY_MARKERS):
                    redacted_keys.append(str(key))
                    result[key] = "[REDACTED]"
                else:
                    result[key] = _walk(nested)
            return result
        if isinstance(value, list):
            return [_walk(item) for item in value]
        return value

    redacted_payload = _walk(payload)

    deduped: list[str] = []
    seen: set[str] = set()
    for key in redacted_keys:
        if key not in seen:
            deduped.append(key)
            seen.add(key)

    return redacted_payload, deduped


async def ingest_event(
    db: AsyncSession,
    *,
    application_id: UUID,
    event_key: str,
    occurred_at: datetime,
    source_channel: str,
    event_type: str,
    severity: str,
    actor_type: str,
    actor_id: str | None,
    correlation_id: str | None,
    external_case_ref: str | None,
    title: str | None,
    payload: dict[str, Any],
    ingested_by_user_id: UUID | None,
    settings: Any | None = None,
) -> dict[str, Any]:
    """Ingest one telemetry event with idempotent semantics."""
    slot_reserved = await _reserve_ingest_slot(settings)
    try:
        _validate_payload_size(payload)
        _validate_event_age(occurred_at)

        existing_event = await repo.get_event_by_key(
            db,
            application_id=application_id,
            event_key=event_key,
        )
        if existing_event is not None:
            existing_case = await repo.get_case_by_id(
                db,
                case_id=existing_event.case_id,
                application_id=application_id,
            )
            return {
                "event_id": str(existing_event.id),
                "case_id": str(existing_event.case_id),
                "created_case": False,
                "deduplicated": True,
                "case_status": existing_case.status if existing_case else "open",
            }

        case: SupportCase | None = None
        created_case = False
        correlation_match_count = 0

        if external_case_ref:
            case = await repo.get_case_by_external_ref(
                db,
                application_id=application_id,
                external_case_ref=external_case_ref,
            )

        if case is None and correlation_id:
            case = await repo.find_open_case_by_correlation_id(
                db,
                application_id=application_id,
                correlation_id=correlation_id,
            )
            if case is not None:
                correlation_match_count = await repo.count_open_cases_by_correlation_id(
                    db,
                    application_id=application_id,
                    correlation_id=correlation_id,
                )

        if case is None:
            created_case = True
            case = await repo.create_case(
                db,
                application_id=application_id,
                external_case_ref=external_case_ref,
                title=title,
                status="open",
                priority="normal",
                highest_severity=severity,
                first_event_at=occurred_at,
                last_event_at=occurred_at,
            )

        redacted_payload, redacted_keys = _redact_payload(payload)

        event = await repo.create_event(
            db,
            case_id=case.id,
            application_id=application_id,
            event_key=event_key,
            source_channel=source_channel,
            event_type=event_type,
            severity=severity,
            actor_type=actor_type,
            actor_external_id=actor_id,
            correlation_id=correlation_id,
            payload=redacted_payload,
            redacted_keys=redacted_keys,
            occurred_at=occurred_at,
            ingested_by_user_id=ingested_by_user_id,
        )

        case = await repo.update_case_summary(
            db,
            case=case,
            occurred_at=occurred_at,
            severity=severity,
            title=title,
        )

        if correlation_id and correlation_match_count > 1:
            await repo.create_event(
                db,
                case_id=case.id,
                application_id=application_id,
                event_key=f"correlation_ambiguous_{uuid4().hex}"[:128],
                source_channel="api",
                event_type="correlation_match_ambiguous",
                severity="info",
                actor_type="service",
                actor_external_id=None,
                correlation_id=correlation_id,
                payload={
                    "input_correlation_id": correlation_id,
                    "selected_case_id": str(case.id),
                    "matched_open_case_count": correlation_match_count,
                    "ingest_event_id": str(event.id),
                },
                redacted_keys=[],
                occurred_at=occurred_at,
                ingested_by_user_id=ingested_by_user_id,
            )
            logger.info(
                "support_telemetry_correlation_ambiguity application_id=%s correlation_id=%s selected_case_id=%s matched_open_case_count=%s",
                application_id,
                correlation_id,
                case.id,
                correlation_match_count,
            )

        return {
            "event_id": str(event.id),
            "case_id": str(case.id),
            "created_case": created_case,
            "deduplicated": False,
            "case_status": case.status,
        }
    finally:
        await _release_ingest_slot(slot_reserved)


async def list_cases(
    db: AsyncSession,
    *,
    application_id: UUID | None,
    status: str | None,
    priority: str | None,
    severity_gte: str | None,
    assigned_to_user_id: UUID | None,
    limit: int,
    offset: int,
) -> dict[str, Any]:
    cases, total = await repo.list_cases(
        db,
        application_id=application_id,
        status=status,
        priority=priority,
        severity_gte=severity_gte,
        assigned_to_user_id=assigned_to_user_id,
        limit=limit,
        offset=offset,
    )
    return {
        "items": [_case_summary_to_dict(case) for case in cases],
        "total": total,
    }


async def get_case_detail(
    db: AsyncSession,
    *,
    case_id: UUID,
    application_id: UUID | None,
    event_limit: int,
    event_offset: int,
) -> dict[str, Any]:
    case = await repo.get_case_by_id(db, case_id=case_id, application_id=application_id)
    if case is None:
        raise SupportTelemetryCaseNotFoundError()

    events = await repo.list_case_events(
        db,
        case_id=case.id,
        limit=event_limit,
        offset=event_offset,
    )
    event_total = await repo.count_case_events(db, case_id=case.id)

    return {
        "case": _case_summary_to_dict(case),
        "events": [_event_to_dict(event) for event in events],
        "event_total": event_total,
    }


async def get_case_by_external_ref(
    db: AsyncSession,
    *,
    application_id: UUID,
    external_case_ref: str,
) -> dict[str, Any]:
    case = await repo.get_case_by_external_ref(
        db,
        application_id=application_id,
        external_case_ref=external_case_ref,
    )
    if case is None:
        raise SupportTelemetryCaseNotFoundError()
    return {"case": _case_by_external_to_dict(case)}


async def update_case_lifecycle(
    db: AsyncSession,
    *,
    case_id: UUID,
    application_id: UUID | None,
    status: str | object = UNSET,
    priority: str | object = UNSET,
    assigned_to_user_id: UUID | None | object = UNSET,
    resolution_note: str | None | object = UNSET,
    actor_user_id: UUID,
) -> dict[str, Any]:
    """Apply lifecycle/assignment updates with transition validation."""
    case = await repo.get_case_by_id(db, case_id=case_id, application_id=application_id)
    if case is None:
        raise SupportTelemetryCaseNotFoundError()

    if (
        status is UNSET
        and priority is UNSET
        and assigned_to_user_id is UNSET
        and resolution_note is UNSET
    ):
        raise ValidationFailedError("No patchable fields were provided")

    resolved_at_field: datetime | None | object = UNSET
    status_value: str | None = None
    if status is not UNSET:
        if status is None:
            raise ValidationFailedError("status must not be null when provided")
        status_value = str(status)
        if status_value != case.status:
            allowed = _ALLOWED_TRANSITIONS.get(case.status, set())
            if status_value not in allowed:
                raise SupportTelemetryInvalidTransitionError()

            if status_value in {"resolved", "ignored"}:
                if resolution_note is UNSET or not isinstance(resolution_note, str) or not resolution_note.strip():
                    raise ValidationFailedError(
                        "resolution_note is required for resolved or ignored status"
                    )
                resolved_at_field = datetime.now(UTC)
            elif case.status in {"resolved", "ignored"} and status_value == "open":
                resolved_at_field = None

    priority_value: str | None = None
    if priority is not UNSET:
        if priority is None:
            raise ValidationFailedError("priority must not be null when provided")
        priority_value = str(priority)

    previous_status = case.status
    set_assigned_to_user_id = assigned_to_user_id is not UNSET
    assigned_value = cast(UUID | None, assigned_to_user_id) if set_assigned_to_user_id else None
    set_resolved_at = resolved_at_field is not UNSET
    resolved_value = cast(datetime | None, resolved_at_field) if set_resolved_at else None

    updated_case = await repo.update_case(
        db,
        case=case,
        status=status_value,
        priority=priority_value,
        assigned_to_user_id=assigned_value,
        set_assigned_to_user_id=set_assigned_to_user_id,
        resolved_at=resolved_value,
        set_resolved_at=set_resolved_at,
    )

    note = resolution_note if isinstance(resolution_note, str) else None
    audit_payload = {
        "previous_status": previous_status,
        "new_status": updated_case.status,
        "priority": updated_case.priority,
        "assigned_to_user_id": str(updated_case.assigned_to_user_id) if updated_case.assigned_to_user_id else None,
        "resolution_note": note,
    }

    lifecycle_event_key = f"case_update_{case_id}_{uuid4().hex}"
    lifecycle_time = datetime.now(UTC)
    event = await repo.create_event(
        db,
        case_id=updated_case.id,
        application_id=updated_case.application_id,
        event_key=lifecycle_event_key[:128],
        source_channel="api",
        event_type="case_lifecycle_updated",
        severity="info",
        actor_type="support_operator",
        actor_external_id=str(actor_user_id),
        correlation_id=None,
        payload=audit_payload,
        redacted_keys=[],
        occurred_at=lifecycle_time,
        ingested_by_user_id=actor_user_id,
    )
    await repo.update_case_summary(
        db,
        case=updated_case,
        occurred_at=event.occurred_at,
        severity="info",
        title=updated_case.title,
    )

    return {"case": _case_patch_to_dict(updated_case)}
