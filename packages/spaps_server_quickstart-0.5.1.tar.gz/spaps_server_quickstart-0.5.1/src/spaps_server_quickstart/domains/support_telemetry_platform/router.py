"""HTTP routes for support telemetry platform domain."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from fastapi import APIRouter, Query, Request, Response

from ...middleware.api_key import KeyType
from ...middleware.spaps_deps import (
    Application,
    OptionalUser,
    SuperAdminUser,
    DbSession,
)
from . import service
from .errors import NotAuthorizedError, ValidationFailedError
from .schemas import (
    IngestEventRequest,
    IngestEventResponse,
    ListSupportCasesResponse,
    PatchSupportCaseRequest,
    PatchSupportCaseResponse,
    SupportCaseByExternalResponse,
    SupportCaseDetailResponse,
    SupportCasePriority,
    SupportCaseStatus,
    SupportEventSeverity,
)

router = APIRouter(prefix="/v1/support-telemetry", tags=["support-telemetry"])


def _as_uuid(value: str | None, field_name: str, *, required: bool = False) -> UUID | None:
    if value is None and required:
        raise ValidationFailedError(f"{field_name} is required")
    if value is None:
        return None
    try:
        return UUID(str(value))
    except (TypeError, ValueError) as exc:
        raise ValidationFailedError(f"{field_name} must be a valid UUID") from exc


def _as_required_uuid(value: str | None, field_name: str) -> UUID:
    parsed = _as_uuid(value, field_name, required=True)
    assert parsed is not None
    return parsed


def _is_super_admin(user: Any | None) -> bool:
    if user is None:
        return False
    if getattr(user, "is_super_admin", False):
        return True
    roles = getattr(user, "roles", []) or []
    return "super_admin" in roles


def _enforce_secret_key(request: Request) -> None:
    if getattr(request.state, "key_type", None) == KeyType.PUBLISHABLE:
        raise NotAuthorizedError("Publishable keys are not allowed for support telemetry endpoints")


def _resolve_scoped_application_id(
    *,
    app: Any,
    optional_user: Any | None,
    requested_application_id: UUID | None,
    require_super_admin_application_filter: bool = False,
) -> tuple[UUID | None, bool]:
    app_id = UUID(str(app.id))
    is_super_admin = _is_super_admin(optional_user)

    if optional_user is None:
        if requested_application_id and requested_application_id != app_id:
            raise NotAuthorizedError("Trusted service callers may only access their own application scope")
        return app_id, False

    if not is_super_admin:
        raise NotAuthorizedError("Only trusted services or super admins may access support telemetry")

    if require_super_admin_application_filter and requested_application_id is None:
        raise ValidationFailedError("application_id is required for operator external-ref lookups")

    return requested_application_id, True


@router.post("/events", response_model=IngestEventResponse)
async def ingest_support_event(
    body: IngestEventRequest,
    request: Request,
    response: Response,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
) -> IngestEventResponse:
    """Ingest a support telemetry event from trusted service or super admin."""
    _enforce_secret_key(request)

    requested_app_id = _as_uuid(body.application_id, "application_id")
    scoped_app_id, is_super_admin = _resolve_scoped_application_id(
        app=app,
        optional_user=optional_user,
        requested_application_id=requested_app_id,
    )
    ingest_app_id = scoped_app_id or UUID(str(app.id))

    ingested_by_user_id = _as_uuid(str(optional_user.id), "optional_user.id") if is_super_admin else None

    result = await service.ingest_event(
        db,
        application_id=ingest_app_id,
        event_key=body.event_key,
        occurred_at=body.occurred_at,
        source_channel=body.source_channel,
        event_type=body.event_type,
        severity=body.severity,
        actor_type=body.actor.type,
        actor_id=body.actor.id,
        correlation_id=body.correlation_id,
        external_case_ref=body.external_case_ref,
        title=body.title,
        payload=body.payload,
        ingested_by_user_id=ingested_by_user_id,
        settings=request.app.state.settings,
    )
    response.status_code = 200 if result["deduplicated"] else 201
    return IngestEventResponse(**result)


@router.get("/cases", response_model=ListSupportCasesResponse)
async def list_support_cases(
    request: Request,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
    application_id: str | None = Query(default=None),
    status: SupportCaseStatus | None = Query(default=None),
    priority: SupportCasePriority | None = Query(default=None),
    severity_gte: SupportEventSeverity | None = Query(default=None),
    assigned_to_user_id: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> ListSupportCasesResponse:
    """List support cases with trusted-service app scoping and operator override."""
    _enforce_secret_key(request)

    requested_app_id = _as_uuid(application_id, "application_id")
    scoped_app_id, _is_operator = _resolve_scoped_application_id(
        app=app,
        optional_user=optional_user,
        requested_application_id=requested_app_id,
    )

    result = await service.list_cases(
        db,
        application_id=scoped_app_id,
        status=status,
        priority=priority,
        severity_gte=severity_gte,
        assigned_to_user_id=_as_uuid(assigned_to_user_id, "assigned_to_user_id"),
        limit=limit,
        offset=offset,
    )
    return ListSupportCasesResponse(**result)


@router.get("/cases/{case_id}", response_model=SupportCaseDetailResponse)
async def get_support_case_detail(
    case_id: str,
    request: Request,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
    event_limit: int = Query(default=100, ge=1, le=500),
    event_offset: int = Query(default=0, ge=0),
) -> SupportCaseDetailResponse:
    """Get case detail + timeline within principal scope."""
    _enforce_secret_key(request)

    scoped_app_id, is_operator = _resolve_scoped_application_id(
        app=app,
        optional_user=optional_user,
        requested_application_id=None,
    )
    effective_app_scope = None if is_operator else scoped_app_id

    result = await service.get_case_detail(
        db,
        case_id=_as_required_uuid(case_id, "case_id"),
        application_id=effective_app_scope,
        event_limit=event_limit,
        event_offset=event_offset,
    )
    return SupportCaseDetailResponse(**result)


@router.patch("/cases/{case_id}", response_model=PatchSupportCaseResponse)
async def patch_support_case(
    case_id: str,
    body: PatchSupportCaseRequest,
    request: Request,
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> PatchSupportCaseResponse:
    """Update support case lifecycle/assignment (super admin only)."""
    _enforce_secret_key(request)

    fields_set = body.model_fields_set
    assigned_field: UUID | None | object = service.UNSET
    if "assigned_to_user_id" in fields_set:
        assigned_field = _as_uuid(body.assigned_to_user_id, "assigned_to_user_id")

    status_field: str | object = body.status if "status" in fields_set else service.UNSET
    priority_field: str | object = body.priority if "priority" in fields_set else service.UNSET
    note_field: str | None | object = body.resolution_note if "resolution_note" in fields_set else service.UNSET

    result = await service.update_case_lifecycle(
        db,
        case_id=_as_required_uuid(case_id, "case_id"),
        application_id=None,
        status=status_field,
        priority=priority_field,
        assigned_to_user_id=assigned_field,
        resolution_note=note_field,
        actor_user_id=_as_required_uuid(str(super_admin.id), "super_admin.id"),
    )
    return PatchSupportCaseResponse(**result)


@router.get(
    "/cases/by-external/{external_case_ref}",
    response_model=SupportCaseByExternalResponse,
)
async def get_support_case_by_external_ref(
    external_case_ref: str,
    request: Request,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
    application_id: str | None = Query(default=None),
) -> SupportCaseByExternalResponse:
    """Resolve canonical support case by downstream external reference."""
    _enforce_secret_key(request)

    requested_app_id = _as_uuid(application_id, "application_id")
    scoped_app_id, _is_operator = _resolve_scoped_application_id(
        app=app,
        optional_user=optional_user,
        requested_application_id=requested_app_id,
        require_super_admin_application_filter=True,
    )
    effective_app_id = scoped_app_id or UUID(str(app.id))

    result = await service.get_case_by_external_ref(
        db,
        application_id=effective_app_id,
        external_case_ref=external_case_ref,
    )
    return SupportCaseByExternalResponse(**result)
