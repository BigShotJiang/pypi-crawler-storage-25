"""Database operations for the entitlements domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import Entitlement, EntitlementEvent, EntitlementMapping
from ..stripe.models import Subscription

logger = logging.getLogger(__name__)

TERMINAL_SUBSCRIPTION_STATUSES = ("canceled", "unpaid", "incomplete_expired")


# ---------------------------------------------------------------------------
# Entitlement lookups
# ---------------------------------------------------------------------------


async def get_entitlement_by_id(
    db: AsyncSession,
    entitlement_id: UUID,
) -> Entitlement | None:
    """Fetch a single entitlement by ID."""
    stmt = select(Entitlement).where(Entitlement.id == entitlement_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def find_existing_entitlement(
    db: AsyncSession,
    *,
    application_id: UUID,
    entitlement_key: str,
    source: str,
    beneficiary_user_id: UUID | None = None,
    beneficiary_email: str | None = None,
    stripe_session_id: str | None = None,
    stripe_subscription_id: str | None = None,
    crypto_invoice_id: UUID | None = None,
    manual_grant_id: str | None = None,
) -> Entitlement | None:
    """Check for an existing entitlement for idempotency."""
    stmt = (
        select(Entitlement)
        .where(
            Entitlement.application_id == application_id,
            Entitlement.entitlement_key == entitlement_key,
            Entitlement.source == source,
        )
    )

    # Add beneficiary filter
    if beneficiary_user_id is not None:
        stmt = stmt.where(Entitlement.beneficiary_user_id == beneficiary_user_id)
    elif beneficiary_email is not None:
        stmt = stmt.where(
            Entitlement.beneficiary_email == beneficiary_email.lower()
        )

    # Add source-specific reference filter
    if source == "stripe_checkout" and stripe_session_id:
        stmt = stmt.where(Entitlement.stripe_session_id == stripe_session_id)
    elif source == "stripe_subscription" and stripe_subscription_id:
        stmt = stmt.where(
            Entitlement.stripe_subscription_id == stripe_subscription_id
        )
    elif source == "crypto" and crypto_invoice_id:
        stmt = stmt.where(Entitlement.crypto_invoice_id == crypto_invoice_id)
    elif source == "manual" and manual_grant_id:
        stmt = stmt.where(Entitlement.manual_grant_id == manual_grant_id)

    result = await db.execute(stmt)
    return result.scalars().first()


# ---------------------------------------------------------------------------
# Entitlement listing
# ---------------------------------------------------------------------------


async def list_entitlements(
    db: AsyncSession,
    application_id: UUID,
    *,
    user_id: UUID | None = None,
    email: str | None = None,
    entitlement_key: str | None = None,
    resource_type: str | None = None,
    resource_id: UUID | None = None,
    include_expired: bool = False,
    include_revoked: bool = False,
    limit: int | None = None,
    offset: int | None = None,
) -> list[Entitlement]:
    """List entitlements with optional filters."""
    stmt = (
        select(Entitlement)
        .where(Entitlement.application_id == application_id)
    )

    if user_id is not None:
        stmt = stmt.where(Entitlement.beneficiary_user_id == user_id)
    elif email is not None:
        stmt = stmt.where(Entitlement.beneficiary_email == email.lower())

    if entitlement_key is not None:
        stmt = stmt.where(Entitlement.entitlement_key == entitlement_key)

    if resource_type is not None:
        stmt = stmt.where(Entitlement.resource_type == resource_type)

    if resource_id is not None:
        stmt = stmt.where(Entitlement.resource_id == resource_id)

    if not include_revoked:
        stmt = stmt.where(Entitlement.revoked_at.is_(None))

    if not include_expired:
        now = datetime.now(UTC)
        stmt = stmt.where(
            (Entitlement.ends_at.is_(None)) | (Entitlement.ends_at > now)
        )

    stmt = stmt.order_by(Entitlement.created_at.desc())

    if offset is not None and offset > 0:
        stmt = stmt.offset(offset)

    if limit is not None:
        stmt = stmt.limit(limit)

    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Entitlement mutations
# ---------------------------------------------------------------------------


async def create_entitlement(
    db: AsyncSession,
    **kwargs: Any,
) -> Entitlement:
    """Insert a new entitlement and return the persisted instance."""
    entitlement = Entitlement(**kwargs)
    db.add(entitlement)
    await db.flush()
    await db.refresh(entitlement)
    return entitlement


async def update_entitlement(
    db: AsyncSession,
    entitlement_id: UUID,
    **kwargs: Any,
) -> Entitlement | None:
    """Update an entitlement by ID."""
    entitlement = await get_entitlement_by_id(db, entitlement_id)
    if entitlement is None:
        return None

    for key, value in kwargs.items():
        if key == "metadata":
            entitlement.metadata_ = value
        elif hasattr(entitlement, key):
            setattr(entitlement, key, value)

    entitlement.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(entitlement)
    return entitlement


async def claim_entitlements_by_email(
    db: AsyncSession,
    application_id: UUID,
    email: str,
    user_id: UUID,
) -> list[Entitlement]:
    """Find pending entitlements for an email and claim them (set user_id).

    Returns the list of claimed entitlements.
    """
    email_lower = email.lower()

    # Find pending entitlements
    stmt = (
        select(Entitlement)
        .where(
            Entitlement.application_id == application_id,
            Entitlement.beneficiary_email == email_lower,
            Entitlement.beneficiary_user_id.is_(None),
            Entitlement.revoked_at.is_(None),
        )
    )
    result = await db.execute(stmt)
    pending = list(result.scalars().all())

    if not pending:
        return []

    claimed: list[Entitlement] = []
    now = datetime.now(UTC)

    for entitlement in pending:
        entitlement.beneficiary_user_id = user_id
        entitlement.updated_at = now
        await db.flush()
        await db.refresh(entitlement)
        claimed.append(entitlement)

    return claimed


async def find_entitlements_by_subscription(
    db: AsyncSession,
    subscription_id: str,
    *,
    require_renewable_subscription: bool = False,
) -> list[Entitlement]:
    """Find all active entitlements for a Stripe subscription."""
    stmt = (
        select(Entitlement)
        .where(
            Entitlement.stripe_subscription_id == subscription_id,
            Entitlement.revoked_at.is_(None),
        )
    )
    if require_renewable_subscription:
        stmt = stmt.join(
            Subscription,
            Subscription.stripe_subscription_id == Entitlement.stripe_subscription_id,
        ).where(
            Subscription.status.notin_(TERMINAL_SUBSCRIPTION_STATUSES),
            Subscription.cancel_at.is_(None),
            Subscription.canceled_at.is_(None),
        )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_subscription_for_renewal(
    db: AsyncSession,
    subscription_id: str,
) -> Subscription | None:
    """Fetch the local subscription row used to gate invoice renewals."""
    stmt = select(Subscription).where(
        Subscription.stripe_subscription_id == subscription_id
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Entitlement events
# ---------------------------------------------------------------------------


async def create_event(
    db: AsyncSession,
    **kwargs: Any,
) -> EntitlementEvent:
    """Insert an entitlement event."""
    event = EntitlementEvent(**kwargs)
    db.add(event)
    await db.flush()
    await db.refresh(event)
    return event


async def list_events(
    db: AsyncSession,
    application_id: UUID,
    *,
    since: str | None = None,
    limit: int = 100,
) -> list[EntitlementEvent]:
    """List entitlement events for an application with optional since filter.

    Fetches limit+1 rows to detect has_more.
    """
    stmt = (
        select(EntitlementEvent)
        .where(EntitlementEvent.application_id == application_id)
    )

    if since is not None:
        stmt = stmt.where(EntitlementEvent.created_at > since)

    stmt = (
        stmt.order_by(EntitlementEvent.created_at.asc())
        .limit(limit + 1)
    )

    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Entitlement mappings
# ---------------------------------------------------------------------------


async def get_mapping_by_id(
    db: AsyncSession,
    mapping_id: UUID,
    application_id: UUID,
) -> EntitlementMapping | None:
    """Fetch a mapping by ID scoped to an application."""
    stmt = select(EntitlementMapping).where(
        EntitlementMapping.id == mapping_id,
        EntitlementMapping.application_id == application_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_mappings(
    db: AsyncSession,
    application_id: UUID,
    *,
    active_only: bool = False,
) -> list[EntitlementMapping]:
    """List entitlement mappings for an application."""
    stmt = (
        select(EntitlementMapping)
        .where(EntitlementMapping.application_id == application_id)
        .order_by(EntitlementMapping.created_at.desc())
    )

    if active_only:
        stmt = stmt.where(EntitlementMapping.is_active.is_(True))

    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_mappings_for_price(
    db: AsyncSession,
    application_id: UUID,
    price_id: str,
) -> list[EntitlementMapping]:
    """Get active mappings for a Stripe price ID."""
    stmt = (
        select(EntitlementMapping)
        .where(
            EntitlementMapping.application_id == application_id,
            EntitlementMapping.stripe_price_id == price_id,
            EntitlementMapping.is_active.is_(True),
        )
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def create_mapping(
    db: AsyncSession,
    **kwargs: Any,
) -> EntitlementMapping:
    """Insert a new entitlement mapping."""
    mapping = EntitlementMapping(**kwargs)
    db.add(mapping)
    await db.flush()
    await db.refresh(mapping)
    return mapping


async def update_mapping(
    db: AsyncSession,
    mapping_id: UUID,
    application_id: UUID,
    **kwargs: Any,
) -> EntitlementMapping | None:
    """Update a mapping by ID scoped to an application."""
    mapping = await get_mapping_by_id(db, mapping_id, application_id)
    if mapping is None:
        return None

    for key, value in kwargs.items():
        if key == "metadata":
            mapping.metadata_ = value
        elif hasattr(mapping, key):
            setattr(mapping, key, value)

    mapping.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(mapping)
    return mapping


async def deactivate_mapping(
    db: AsyncSession,
    mapping_id: UUID,
    application_id: UUID,
) -> EntitlementMapping | None:
    """Soft-delete (deactivate) a mapping."""
    mapping = await get_mapping_by_id(db, mapping_id, application_id)
    if mapping is None:
        return None

    mapping.is_active = False
    mapping.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(mapping)
    return mapping
