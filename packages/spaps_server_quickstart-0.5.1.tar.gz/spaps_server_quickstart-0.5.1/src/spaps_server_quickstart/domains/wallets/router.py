"""API routers for the wallets domain (Solana + Ethereum).

Two sub-routers are exported:

* ``solana_router`` -- mounted under ``/solana``
* ``ethereum_router`` -- mounted under ``/ethereum``

The main application mounts them separately so that chain-specific
prefixes are visible in the OpenAPI spec.
"""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Path, Query

from . import service
from .schemas import (
    # Solana requests
    SolanaSignInRequest,
    SolanaLinkWalletRequest,
    SolanaVerifySignatureRequest,
    SolanaVerifyOwnershipRequest,
    # Solana responses
    WalletSignInResponse,
    LinkWalletResponse,
    VerifySignatureResponse,
    GenerateMessageResponse,
    WalletsListResponse,
    VerifyOwnershipResponse,
    # Ethereum requests
    EthereumSignInRequest,
    EthereumLinkWalletRequest,
    EthereumVerifySignatureRequest,
    EthereumVerifyOwnershipRequest,
    EthereumVerifyTypedDataRequest,
    # Ethereum responses
    EthereumVerifySignatureResponse,
    EthereumVerifyTypedDataResponse,
    EthereumGenerateMessageResponse,
    EthereumBalanceResponse,
    EthereumContractCheckResponse,
    # Shared
    NetworkInfoResponse,
)
from ...middleware.spaps_deps import (
    Application,
    CurrentUser,
    DbSession,
    get_settings,
)

logger = logging.getLogger(__name__)

# Convenience type alias for the SPAPS settings dependency
Settings = Annotated[Any, Depends(get_settings)]


# ===========================================================================
# Solana router
# ===========================================================================

solana_router = APIRouter(prefix="/auth/solana", tags=["solana"])


@solana_router.post(
    "/sign-in",
    response_model=WalletSignInResponse,
    deprecated=True,
)
async def solana_sign_in(
    body: SolanaSignInRequest,
    _application: Application,
) -> WalletSignInResponse:
    """DEPRECATED: Use /api/auth/wallet-sign-in instead.

    This legacy route accepted application_id from the request body, which
    allowed cross-tenant JWT minting. It is retained as a stub that returns
    410 Gone so any remaining caller fails loudly.
    """
    raise HTTPException(
        status_code=410,
        detail={
            "error": "route_deprecated",
            "message": "This route is deprecated. Use /api/auth/wallet-sign-in.",
            "replacement": "/api/auth/wallet-sign-in",
        },
    )


@solana_router.post("/link-wallet", response_model=LinkWalletResponse)
async def solana_link_wallet(
    body: SolanaLinkWalletRequest,
    session: DbSession,
    current_user: CurrentUser,
) -> LinkWalletResponse:
    """Link a Solana wallet to the authenticated user."""

    result = await service.link_wallet_to_user(
        session,
        user_id=current_user.id,
        wallet_address=body.wallet_address,
        signature=body.signature,
        message=body.message,
        chain_type="solana",
    )
    return LinkWalletResponse(**result)


@solana_router.post(
    "/verify-signature",
    response_model=VerifySignatureResponse,
)
async def solana_verify_signature(
    body: SolanaVerifySignatureRequest,
    _application: Application,
) -> VerifySignatureResponse:
    """Verify a Solana Ed25519 signature (public, no JWT required)."""

    result = service.verify_signature(
        wallet_address=body.wallet_address,
        signature=body.signature,
        message=body.message,
        chain_type="solana",
    )
    return VerifySignatureResponse(**result)


@solana_router.post(
    "/verify-ownership",
    response_model=VerifyOwnershipResponse,
)
async def solana_verify_ownership(
    body: SolanaVerifyOwnershipRequest,
    session: DbSession,
    current_user: CurrentUser,
) -> VerifyOwnershipResponse:
    """Verify Solana wallet ownership for the authenticated user.

    Combines cryptographic verification with a database ownership check.
    """

    result = await service.verify_wallet_ownership(
        session,
        user_id=current_user.id,
        wallet_address=body.wallet_address,
        signature=body.signature,
        message=body.message,
        chain_type="solana",
    )
    return VerifyOwnershipResponse(**result)


@solana_router.get(
    "/generate-message/{wallet_address}",
    response_model=GenerateMessageResponse,
)
async def solana_generate_message(
    session: DbSession,
    _application: Application,
    wallet_address: str = Path(..., min_length=32, max_length=44),
    nonce: str = Query(...),
) -> GenerateMessageResponse:
    """Generate a signing message with nonce for Solana wallet authentication."""

    result = await service.generate_auth_message_for_wallet(
        session,
        wallet_address=wallet_address,
        chain_type="solana",
        nonce=nonce,
    )
    return GenerateMessageResponse(**result)


@solana_router.get("/wallets", response_model=WalletsListResponse)
async def solana_list_wallets(
    session: DbSession,
    current_user: CurrentUser,
) -> WalletsListResponse:
    """List all Solana wallets for the authenticated user."""

    result = await service.get_user_wallets(
        session,
        user_id=current_user.id,
        chain_type="solana",
    )
    return WalletsListResponse(**result)


@solana_router.get("/network-info", response_model=NetworkInfoResponse)
async def solana_network_info(
    _application: Application,
    settings: Settings,
) -> NetworkInfoResponse:
    """Get Solana network information (public)."""

    return NetworkInfoResponse(
        chain="solana",
        network=getattr(settings, "solana_network", "mainnet-beta"),
        rpc_url=getattr(settings, "solana_rpc_url", None),
    )


# ===========================================================================
# Ethereum router
# ===========================================================================

ethereum_router = APIRouter(prefix="/auth/ethereum", tags=["ethereum"])


@ethereum_router.post(
    "/sign-in",
    response_model=WalletSignInResponse,
    deprecated=True,
)
async def ethereum_sign_in(
    body: EthereumSignInRequest,
    _application: Application,
) -> WalletSignInResponse:
    """DEPRECATED: Use /api/auth/wallet-sign-in instead.

    This legacy route accepted application_id from the request body, which
    allowed cross-tenant JWT minting. It is retained as a stub that returns
    410 Gone so any remaining caller fails loudly.
    """
    raise HTTPException(
        status_code=410,
        detail={
            "error": "route_deprecated",
            "message": "This route is deprecated. Use /api/auth/wallet-sign-in.",
            "replacement": "/api/auth/wallet-sign-in",
        },
    )


@ethereum_router.post("/link-wallet", response_model=LinkWalletResponse)
async def ethereum_link_wallet(
    body: EthereumLinkWalletRequest,
    session: DbSession,
    current_user: CurrentUser,
) -> LinkWalletResponse:
    """Link an Ethereum wallet to the authenticated user."""

    result = await service.link_wallet_to_user(
        session,
        user_id=current_user.id,
        wallet_address=body.wallet_address,
        signature=body.signature,
        message=body.message,
        chain_type="ethereum",
    )
    return LinkWalletResponse(**result)


@ethereum_router.post(
    "/verify-signature",
    response_model=EthereumVerifySignatureResponse,
)
async def ethereum_verify_signature(
    body: EthereumVerifySignatureRequest,
    _application: Application,
) -> EthereumVerifySignatureResponse:
    """Verify an Ethereum EIP-191 ``personal_sign`` signature (public)."""

    result = service.verify_signature(
        wallet_address=body.wallet_address,
        signature=body.signature,
        message=body.message,
        chain_type="ethereum",
    )
    # Augment with Ethereum-specific signature type
    result["signature_type"] = "EIP-191"
    return EthereumVerifySignatureResponse(**result)


@ethereum_router.post(
    "/verify-typed-data",
    response_model=EthereumVerifyTypedDataResponse,
)
async def ethereum_verify_typed_data(
    body: EthereumVerifyTypedDataRequest,
    _application: Application,
) -> EthereumVerifyTypedDataResponse:
    """Verify an Ethereum EIP-712 typed-data signature (public)."""

    result = service.verify_typed_data(
        wallet_address=body.wallet_address,
        signature=body.signature,
        domain=body.domain,
        types=body.types,
        value=body.value,
    )
    return EthereumVerifyTypedDataResponse(**result)


@ethereum_router.get(
    "/generate-message/{wallet_address}",
    response_model=EthereumGenerateMessageResponse,
)
async def ethereum_generate_message(
    session: DbSession,
    _application: Application,
    wallet_address: str = Path(...),
    nonce: str = Query(...),
) -> EthereumGenerateMessageResponse:
    """Generate an EIP-191 signing message for Ethereum wallet authentication."""

    result = await service.generate_auth_message_for_wallet(
        session,
        wallet_address=wallet_address,
        chain_type="ethereum",
        nonce=nonce,
    )
    result["signature_type"] = "EIP-191"
    return EthereumGenerateMessageResponse(**result)


@ethereum_router.get("/generate-typed-data/{wallet_address}")
async def ethereum_generate_typed_data(
    session: DbSession,
    _application: Application,
    wallet_address: str = Path(...),
) -> dict[str, Any]:
    """Generate EIP-712 typed data for Ethereum wallet authentication.

    Returns the full typed-data structure (domain, types, primaryType,
    message) alongside wallet metadata.
    """

    return await service.generate_typed_data_message(
        session,
        wallet_address=wallet_address,
    )


@ethereum_router.get("/balance/{wallet_address}", response_model=EthereumBalanceResponse)
async def ethereum_balance(
    _application: Application,
    settings: Settings,
    wallet_address: str = Path(...),
) -> EthereumBalanceResponse:
    """Check ETH balance for a wallet address (public)."""

    result = await service.get_ethereum_balance(
        wallet_address=wallet_address,
        rpc_url=settings.ethereum_rpc_url,
    )
    return EthereumBalanceResponse(**result)


@ethereum_router.get(
    "/contract-check/{wallet_address}/{contract_address}",
    response_model=EthereumContractCheckResponse,
)
async def ethereum_contract_check(
    _application: Application,
    settings: Settings,
    wallet_address: str = Path(...),
    contract_address: str = Path(...),
) -> EthereumContractCheckResponse:
    """Check if a wallet can interact with a smart contract (public)."""

    result = await service.check_contract_interaction(
        wallet_address=wallet_address,
        contract_address=contract_address,
        rpc_url=settings.ethereum_rpc_url,
    )
    return EthereumContractCheckResponse(**result)


@ethereum_router.post(
    "/verify-ownership",
    response_model=VerifyOwnershipResponse,
)
async def ethereum_verify_ownership(
    body: EthereumVerifyOwnershipRequest,
    session: DbSession,
    current_user: CurrentUser,
) -> VerifyOwnershipResponse:
    """Verify Ethereum wallet ownership for the authenticated user.

    Combines cryptographic verification with a database ownership check.
    """

    result = await service.verify_wallet_ownership(
        session,
        user_id=current_user.id,
        wallet_address=body.wallet_address,
        signature=body.signature,
        message=body.message,
        chain_type="ethereum",
    )
    return VerifyOwnershipResponse(**result)


@ethereum_router.get("/wallets", response_model=WalletsListResponse)
async def ethereum_list_wallets(
    session: DbSession,
    current_user: CurrentUser,
) -> WalletsListResponse:
    """List all Ethereum wallets for the authenticated user."""

    result = await service.get_user_wallets(
        session,
        user_id=current_user.id,
        chain_type="ethereum",
    )
    return WalletsListResponse(**result)


@ethereum_router.get("/network-info", response_model=NetworkInfoResponse)
async def ethereum_network_info(
    _application: Application,
    settings: Settings,
) -> NetworkInfoResponse:
    """Get Ethereum network information (public)."""

    return NetworkInfoResponse(
        chain="ethereum",
        network=getattr(settings, "ethereum_network", "mainnet"),
        rpc_url=getattr(settings, "ethereum_rpc_url", None),
        chain_id=getattr(settings, "ethereum_chain_id", 1),
    )
