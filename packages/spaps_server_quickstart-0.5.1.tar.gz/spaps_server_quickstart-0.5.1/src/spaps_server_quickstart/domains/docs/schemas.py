"""Pydantic request/response schemas for documentation endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Shared types
# ---------------------------------------------------------------------------

SearchContextType = Literal[
    "getting-started", "guides", "api-reference", "troubleshooting", "examples"
]

LanguageType = Literal["typescript", "javascript", "python", "curl"]


# ---------------------------------------------------------------------------
# Canonical representations
# ---------------------------------------------------------------------------


class DocumentOut(BaseModel):
    """A single documentation search result."""

    id: str
    slug: str
    title: str
    content: str
    category: str | None = None
    tags: list[str] | None = None
    score: float | None = None
    examples: list[CodeExampleOut] | None = None


class CodeExampleOut(BaseModel):
    """A code example."""

    id: str
    title: str
    description: str | None = None
    language: str
    code: str
    dependencies: dict[str, Any] | None = None
    output: str | None = None


class ErrorDocOut(BaseModel):
    """Error code documentation."""

    id: str
    code: str
    http_status: int
    message: str
    description: str | None = None
    possible_causes: list[str] | None = None
    solutions: list[str] | None = None
    related_errors: list[str] | None = None
    examples: list[CodeExampleOut] | None = None


class EndpointDocOut(BaseModel):
    """Endpoint documentation."""

    id: str
    method: str
    path: str
    description: str | None = None
    authentication: dict[str, Any] | None = None
    request_body: dict[str, Any] | None = None
    response_body: dict[str, Any] | None = None
    error_codes: dict[str, Any] | None = None
    rate_limit: str | None = None
    deprecated: bool = False


class CategoryOut(BaseModel):
    """Documentation category."""

    id: str
    name: str
    slug: str
    description: str | None = None
    order_index: int


class BlueprintJourneyOut(BaseModel):
    """A machine-readable blueprint journey."""

    key: str
    name: str
    description: str
    publishable_scopes: list[str]
    entitlement_key: str | None = None
    policy_name: str | None = None


class BlueprintCatalogEntryOut(BaseModel):
    """A public application blueprint catalog entry."""

    key: str
    name: str
    description: str
    publishable_scopes: list[str]
    publishable_patterns: list[str]
    publishable_routes: list[dict[str, Any]]
    docs: list[str]
    journeys: list[BlueprintJourneyOut]


class ServiceDiscoveryServiceOut(BaseModel):
    """Core public service metadata for discovery."""

    title: str
    version: str
    docs_url: str
    redoc_url: str
    openapi_url: str
    openapi_yaml_url: str


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class SearchRequest(BaseModel):
    """POST /api/docs/search body."""

    query: str = Field(..., min_length=3, max_length=500)
    context: SearchContextType | None = None
    limit: int = Field(default=10, ge=1, le=20)
    includeExamples: bool = False
    language: LanguageType | None = None


class FeedbackRequest(BaseModel):
    """POST /api/docs/feedback body."""

    documentId: str
    helpful: bool
    suggestion: str | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class SearchResponse(BaseModel):
    """POST /api/docs/search -- success payload."""

    query: str
    results: list[DocumentOut]
    total: int
    searchId: str


class EndpointDocResponse(BaseModel):
    """GET /api/docs/endpoints/:method/:path -- success payload."""

    endpoint: EndpointDocOut


class ErrorDocResponse(BaseModel):
    """GET /api/docs/errors/:code -- success payload."""

    error: ErrorDocOut


class ExamplesResponse(BaseModel):
    """GET /api/docs/examples/:feature -- success payload."""

    feature: str
    examples: list[CodeExampleOut]
    languages: list[str]


class CategoriesResponse(BaseModel):
    """GET /api/docs/categories -- success payload."""

    categories: list[CategoryOut]


class FeedbackResponse(BaseModel):
    """POST /api/docs/feedback -- success payload."""

    message: str


class ServiceDiscoveryResponse(BaseModel):
    """GET /.well-known/spaps.json -- public service discovery payload."""

    service: ServiceDiscoveryServiceOut
    recommended_blueprint: str
    blueprints: list[BlueprintCatalogEntryOut]


# Fix forward reference for DocumentOut.examples
DocumentOut.model_rebuild()
