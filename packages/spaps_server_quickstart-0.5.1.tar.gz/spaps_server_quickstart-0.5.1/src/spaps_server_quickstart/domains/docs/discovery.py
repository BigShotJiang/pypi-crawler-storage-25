"""Helpers for the public SPAPS discovery document."""

from __future__ import annotations

from typing import Any

from ..applications.blueprints import (
    BUILTIN_BLUEPRINTS,
    ApplicationBlueprint,
    BlueprintJourney,
    resolve_publishable_patterns,
    resolve_publishable_routes,
)


def _journey_to_dict(journey: BlueprintJourney) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "key": journey.key,
        "name": journey.name,
        "description": journey.description,
        "publishable_scopes": list(journey.publishable_scopes),
    }
    if journey.entitlement_key is not None:
        payload["entitlement_key"] = journey.entitlement_key
    if journey.policy_name is not None:
        payload["policy_name"] = journey.policy_name
    return payload


def serialize_application_blueprint(blueprint: ApplicationBlueprint) -> dict[str, Any]:
    """Serialize a built-in blueprint for public discovery and tooling."""
    publishable_scopes = list(blueprint.publishable_scopes)
    return {
        "key": blueprint.key,
        "name": blueprint.name,
        "description": blueprint.description,
        "publishable_scopes": publishable_scopes,
        "publishable_patterns": resolve_publishable_patterns(publishable_scopes),
        "publishable_routes": resolve_publishable_routes(publishable_scopes),
        "docs": list(blueprint.docs),
        "journeys": [_journey_to_dict(journey) for journey in blueprint.journeys],
    }


def list_application_blueprints() -> list[dict[str, Any]]:
    """Return the ordered built-in blueprint catalog as serializable dicts."""
    return [
        serialize_application_blueprint(blueprint)
        for blueprint in BUILTIN_BLUEPRINTS.values()
    ]
