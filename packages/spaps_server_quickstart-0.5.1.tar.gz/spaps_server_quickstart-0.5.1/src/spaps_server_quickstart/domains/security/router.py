"""HTTP routes for the security domain.

Provides the ``security_router`` for admin-only security alert queries.

Security alert creation is done via the service layer (called by other
domains), not through HTTP endpoints. These routes are read-only query
endpoints.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Query

from ...middleware.spaps_deps import AdminUser, Application, DbSession
from . import service
from .schemas import (
    ListAlertsResponse,
    SummaryResponse,
)

logger = logging.getLogger(__name__)

security_router = APIRouter(prefix="/security", tags=["security"])


@security_router.get("/alerts", response_model=ListAlertsResponse)
async def get_alerts(
    db: DbSession,
    app: Application,
    admin: AdminUser,
    alert_type: str | None = Query(default=None),
    severity: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=1000),
) -> ListAlertsResponse:
    """Get security alerts with optional filters.

    Requires API Key + JWT + Admin.
    """
    result = await service.get_alerts(
        db,
        application_id=app.id,
        alert_type=alert_type,
        severity=severity,
        limit=limit,
    )
    return ListAlertsResponse(**result)


@security_router.get("/summary", response_model=SummaryResponse)
async def get_summary(
    db: DbSession,
    app: Application,
    admin: AdminUser,
    hours: int = Query(default=24, ge=1, le=720),
) -> SummaryResponse:
    """Get alert summary counts by type and severity.

    Requires API Key + JWT + Admin.
    """
    result = await service.get_summary(
        db,
        application_id=app.id,
        hours=hours,
    )
    return SummaryResponse(**result)
