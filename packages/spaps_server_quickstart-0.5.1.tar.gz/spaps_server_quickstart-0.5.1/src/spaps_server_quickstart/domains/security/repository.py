"""Database operations for the security domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import SecurityAlert

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Alert creation
# ---------------------------------------------------------------------------


async def create_alert(
    db: AsyncSession,
    **kwargs: Any,
) -> SecurityAlert:
    """Insert a new security alert and return the persisted instance."""
    alert = SecurityAlert(**kwargs)
    db.add(alert)
    await db.flush()
    await db.refresh(alert)
    return alert


# ---------------------------------------------------------------------------
# Alert queries
# ---------------------------------------------------------------------------


async def list_alerts(
    db: AsyncSession,
    *,
    application_id: UUID,
    alert_type: str | None = None,
    severity: str | None = None,
    limit: int = 50,
) -> tuple[list[SecurityAlert], int]:
    """List security alerts with optional filters.

    Returns (alerts, total_count).
    """
    base = select(SecurityAlert).where(
        SecurityAlert.application_id == application_id
    )

    if alert_type is not None:
        base = base.where(SecurityAlert.alert_type == alert_type)
    if severity is not None:
        base = base.where(SecurityAlert.severity == severity)

    # Total count
    count_stmt = select(func.count()).select_from(base.subquery())
    total = (await db.execute(count_stmt)).scalar_one()

    # Results (most recent first)
    stmt = base.order_by(SecurityAlert.timestamp.desc()).limit(limit)
    result = await db.execute(stmt)

    return list(result.scalars().all()), total


async def get_summary(
    db: AsyncSession,
    *,
    application_id: UUID,
    since: datetime,
) -> dict[str, Any]:
    """Get alert summary (counts by type and severity) since a given time.

    Returns dict with total, by_type, and by_severity.
    """
    base = select(SecurityAlert).where(
        SecurityAlert.application_id == application_id,
        SecurityAlert.timestamp >= since,
    )

    # Total count
    count_stmt = select(func.count()).select_from(base.subquery())
    total = (await db.execute(count_stmt)).scalar_one()

    # Count by type
    type_stmt = (
        select(SecurityAlert.alert_type, func.count().label("count"))
        .where(
            SecurityAlert.application_id == application_id,
            SecurityAlert.timestamp >= since,
        )
        .group_by(SecurityAlert.alert_type)
        .order_by(func.count().desc())
    )
    type_result = await db.execute(type_stmt)
    by_type = [
        {"alert_type": row.alert_type, "count": row.count}
        for row in type_result
    ]

    # Count by severity
    severity_stmt = (
        select(SecurityAlert.severity, func.count().label("count"))
        .where(
            SecurityAlert.application_id == application_id,
            SecurityAlert.timestamp >= since,
        )
        .group_by(SecurityAlert.severity)
        .order_by(func.count().desc())
    )
    severity_result = await db.execute(severity_stmt)
    by_severity = [
        {"severity": row.severity, "count": row.count}
        for row in severity_result
    ]

    return {
        "total": total,
        "by_type": by_type,
        "by_severity": by_severity,
    }
