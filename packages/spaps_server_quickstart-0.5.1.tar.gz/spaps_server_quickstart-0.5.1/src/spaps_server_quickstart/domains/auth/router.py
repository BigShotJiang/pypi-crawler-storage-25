"""HTTP routes for the auth domain.

All endpoints live under the ``/auth`` prefix and implement the
complete SPAPS authentication contract: login, register, wallet
sign-in, token refresh, magic link, password reset, and profile.

The response envelope ``{ success, data, error, metadata }`` is
applied automatically by ``ResponseEnvelopeMiddleware`` -- handlers
return the raw *data* portion only.

Rate limiting tiers (applied via ``rate_limiting`` middleware):
    STRICT  (5/min) : login, register, password-reset, magic-link
    TIGHT  (10/min) : wallet/sign-in, nonce, refresh
    MODERATE (15/min): me, set-password, logout
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Request, Response

from ...auth.cookies import clear_refresh_cookie, set_refresh_cookie
from ...middleware.client_ip import resolve_client_ip
from ..errors import InvalidRefreshTokenError

from ...middleware.spaps_deps import Application, CurrentUser, DbSession
from . import service
from .schemas import (
    GetUserResponse,
    LoginRequest,
    LoginResponse,
    LogoutResponse,
    MagicLinkRequest,
    MagicLinkResponse,
    NonceRequest,
    NonceResponse,
    PasswordResetRequest,
    PasswordResetResponse,
    RefreshRequest,
    RefreshResponse,
    RegisterRequest,
    RegisterResponse,
    ResetPasswordConfirmRequest,
    ResetPasswordConfirmResponse,
    SetPasswordRequest,
    SetPasswordResponse,
    VerifyMagicLinkRequest,
    VerifyMagicLinkResponse,
    WalletSignInRequest,
    WalletSignInResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["auth"])
COOKIE_MODE_HEADER = "X-SPAPS-Use-Refresh-Cookie"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _client_ip(request: Request) -> str | None:
    """Best-effort client IP extraction using trusted proxy settings."""
    settings = getattr(getattr(getattr(request, "app", None), "state", None), "settings", None)
    trusted_proxy_cidrs = getattr(settings, "trusted_proxy_cidrs", None)
    if not isinstance(trusted_proxy_cidrs, (list, tuple)):
        trusted_proxy_cidrs = None
    return resolve_client_ip(request, trusted_proxy_cidrs=trusted_proxy_cidrs)


def _device_info(request: Request) -> str | None:
    """Extract device info from User-Agent header."""
    return request.headers.get("User-Agent")


def _use_refresh_cookie_mode(request: Request) -> bool:
    """Return True when the caller explicitly opts into refresh-cookie mode."""
    value = request.headers.get(COOKIE_MODE_HEADER, "")
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _strip_refresh_token(result: dict[str, Any]) -> dict[str, Any]:
    """Remove refresh_token from a response payload before returning it to JS."""
    payload = dict(result)
    payload.pop("refresh_token", None)
    return payload


def _strip_nested_refresh_token(
    result: dict[str, Any],
    *,
    tokens_key: str = "tokens",
) -> dict[str, Any]:
    """Remove nested refresh_token values from token sub-objects."""
    payload = dict(result)
    tokens = payload.get(tokens_key)
    if isinstance(tokens, dict):
        cleaned_tokens = dict(tokens)
        cleaned_tokens.pop("refresh_token", None)
        payload[tokens_key] = cleaned_tokens
    return payload


# ---------------------------------------------------------------------------
# Public endpoints (API-key authentication only)
# ---------------------------------------------------------------------------


@router.post("/login", response_model=LoginResponse, response_model_exclude_none=True)
async def login(
    body: LoginRequest,
    request: Request,
    response: Response,
    db: DbSession,
    _app: Application,
) -> LoginResponse:
    """Authenticate with email and password.

    Returns an access/refresh token pair and the user profile.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.login(
        db, settings,
        email=body.email,
        password=body.password,
        application_id=app_id,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
    )
    if _use_refresh_cookie_mode(request):
        set_refresh_cookie(
            response=response,
            settings=settings,
            refresh_token=result.get("refresh_token"),
            expires_in=result.get("expires_in"),
        )
        return LoginResponse(**_strip_refresh_token(result))
    return LoginResponse(**result)


@router.post("/register", response_model=RegisterResponse, status_code=201)
async def register(
    body: RegisterRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> RegisterResponse:
    """Create a new user account.

    Returns the user profile and optionally tokens when email
    confirmation is not required (development environments).
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.register(
        db, settings,
        email=body.email,
        password=body.password,
        username=body.username,
        phone_number=body.phone_number,
        application_id=app_id,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
        referral_click_id=body.referral_click_id,
        referral_slug=body.ref,
    )
    return RegisterResponse(**result)


@router.post("/refresh", response_model=RefreshResponse, response_model_exclude_none=True)
async def refresh(
    body: RefreshRequest,
    request: Request,
    response: Response,
    db: DbSession,
    _app: Application,
) -> RefreshResponse:
    """Rotate a refresh token and receive a new token pair.

    The old refresh token is revoked on success.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)
    use_cookie_mode = _use_refresh_cookie_mode(request)
    refresh_token = body.refresh_token
    if use_cookie_mode and not refresh_token:
        refresh_token = request.cookies.get(settings.spaps_refresh_cookie_name)
    if not refresh_token:
        raise InvalidRefreshTokenError("Refresh token required")

    result = await service.refresh_tokens(
        db, settings,
        refresh_token_str=refresh_token,
        application_id=app_id,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
        client_ip=_client_ip(request),  # TM-011: Pass IP for anomaly tracking
        user_agent=_device_info(request),  # TM-011: Pass UA for anomaly tracking
    )
    if use_cookie_mode:
        set_refresh_cookie(
            response=response,
            settings=settings,
            refresh_token=result.get("refresh_token"),
            expires_in=result.get("expires_in"),
        )
        return RefreshResponse(**_strip_refresh_token(result))
    return RefreshResponse(**result)


@router.post("/nonce", response_model=NonceResponse)
async def request_nonce(
    body: NonceRequest,
    db: DbSession,
    _app: Application,
) -> NonceResponse:
    """Request a cryptographic nonce for wallet-based authentication.

    The client signs the returned message with their wallet and submits
    the signature to ``/auth/wallet/sign-in``.
    """
    result = await service.request_nonce(
        db,
        wallet_address=body.wallet_address,
    )
    return NonceResponse(**result)


@router.post("/wallet-sign-in", response_model=WalletSignInResponse, response_model_exclude_none=True)
async def wallet_sign_in(
    body: WalletSignInRequest,
    request: Request,
    response: Response,
    db: DbSession,
    _app: Application,
) -> WalletSignInResponse:
    """Sign in with a wallet signature.

    Supports Solana, Ethereum, and Base wallets.  The chain type
    is auto-detected from the address format if not provided.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.wallet_sign_in(
        db, settings,
        wallet_address=body.wallet_address,
        signature=body.signature,
        message=body.message,
        chain_type=body.chain_type,
        username=body.username,
        application_id=app_id,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
    )
    if _use_refresh_cookie_mode(request):
        set_refresh_cookie(
            response=response,
            settings=settings,
            refresh_token=result.get("refresh_token"),
            expires_in=result.get("expires_in"),
        )
        return WalletSignInResponse(**_strip_refresh_token(result))
    return WalletSignInResponse(**result)


@router.post("/magic-link", response_model=MagicLinkResponse)
async def request_magic_link(
    body: MagicLinkRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> MagicLinkResponse:
    """Request a magic-link email for passwordless sign-in.

    The magic link contains a one-time token that the client submits
    to ``/auth/magic-link/verify``.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.request_magic_link(
        db, settings,
        email=body.email,
        application_id=app_id,
        redirect_url=body.redirect_url,
        state=body.state,
        generate_state=body.generate_state or False,
    )
    return MagicLinkResponse(**result)


@router.post("/verify-magic-link", response_model=VerifyMagicLinkResponse, response_model_exclude_none=True)
async def verify_magic_link(
    body: VerifyMagicLinkRequest,
    request: Request,
    response: Response,
    db: DbSession,
    _app: Application,
) -> VerifyMagicLinkResponse:
    """Verify a magic-link token and sign in.

    The token is consumed on first use and cannot be replayed.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.verify_magic_link(
        db, settings,
        token=body.token,
        token_type=body.type,
        application_id=app_id,
        state=body.state,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
    )
    if _use_refresh_cookie_mode(request):
        tokens = result.get("tokens")
        refresh_token = tokens.get("refresh_token") if isinstance(tokens, dict) else None
        expires_in = tokens.get("expires_in") if isinstance(tokens, dict) else None
        set_refresh_cookie(
            response=response,
            settings=settings,
            refresh_token=refresh_token,
            expires_in=expires_in,
        )
        return VerifyMagicLinkResponse(**_strip_nested_refresh_token(result))
    return VerifyMagicLinkResponse(**result)


@router.post("/password-reset", response_model=PasswordResetResponse)
async def request_password_reset(
    body: PasswordResetRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> PasswordResetResponse:
    """Request a password reset email.

    Always returns success to prevent email enumeration.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.request_password_reset(
        db, settings,
        email=body.email,
        application_id=app_id,
        redirect_url=body.redirect_url,
    )
    return PasswordResetResponse(**result)


@router.post(
    "/reset-password-confirm",
    response_model=ResetPasswordConfirmResponse,
)
async def confirm_password_reset(
    body: ResetPasswordConfirmRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> ResetPasswordConfirmResponse:
    """Confirm a password reset with the token from the email.

    All existing sessions for the user are revoked.
    """
    settings = request.app.state.settings

    result = await service.confirm_password_reset(
        db, settings,
        token=body.token,
        new_password=body.new_password,
    )
    return ResetPasswordConfirmResponse(**result)


# ---------------------------------------------------------------------------
# Authenticated endpoints (JWT required)
# ---------------------------------------------------------------------------


@router.post("/set-password", response_model=SetPasswordResponse)
async def set_password(
    body: SetPasswordRequest,
    request: Request,
    db: DbSession,
    _app: Application,
    user: CurrentUser,
) -> SetPasswordResponse:
    """Set or change the current user's password.

    Wallet-only users setting a password for the first time may omit
    ``current_password``.  Users with an existing password must provide
    it for verification.
    """
    settings = request.app.state.settings

    result = await service.set_password(
        db, settings,
        user_id=user.id,
        current_password=body.current_password,
        new_password=body.new_password,
    )
    return SetPasswordResponse(**result)


@router.get("/user", response_model=GetUserResponse)
async def get_me(
    db: DbSession,
    _app: Application,
    user: CurrentUser,
) -> GetUserResponse:
    """Get the current authenticated user's profile.

    Includes linked wallets, roles, permissions, and tier information.
    """
    result = await service.get_me(db, user_id=user.id)
    return GetUserResponse(**result)


@router.post("/logout", response_model=LogoutResponse)
async def logout(
    request: Request,
    response: Response,
    db: DbSession,
    _app: Application,
    user: CurrentUser,
) -> LogoutResponse:
    """Log out the current user.

    Blacklists the access token and optionally revokes the refresh
    token.  The client should discard both tokens after this call.
    """
    # Extract refresh token from body if provided
    refresh_token: str | None = None
    try:
        body = await request.json()
        refresh_token = body.get("refresh_token") if isinstance(body, dict) else None
    except (ValueError, TypeError, KeyError):
        # Body is empty, not JSON, or malformed — proceed without refresh token
        pass

    # Get JTI and expiry from the JWT payload set by the auth middleware
    jwt_payload = getattr(request.state, "jwt_payload", {})
    jti = jwt_payload.get("jti") or getattr(user, "jti", None) or ""
    exp = jwt_payload.get("exp", 0)

    result = await service.logout(
        db,
        user_id=user.id,
        access_token_jti=jti,
        access_token_exp=exp,
        refresh_token=refresh_token,
    )
    if _use_refresh_cookie_mode(request):
        clear_refresh_cookie(response=response, settings=request.app.state.settings)
    return LogoutResponse(**result)
