"""Database operations for the auth domain.

Thin repository layer providing auth-specific cross-table queries.
Most DB work is delegated to other domain repositories; the functions
here handle queries that span users, wallets, and session tables in a
single logical operation.

All functions accept an ``AsyncSession`` as the first positional
argument so the caller controls the transaction boundary.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import hashlib
import logging
import secrets
from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..sessions.models import AuthMagicLinkState, AuthToken, RefreshToken
from ..users.models import User
from ..wallets.models import UserWallet

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# User lookup helpers
# ---------------------------------------------------------------------------


async def find_user_for_login(
    db: AsyncSession,
    email: str,
) -> User | None:
    """Get a user by email for the login flow.

    Returns the ``User`` row if found, ``None`` otherwise.
    The caller is responsible for password verification.
    """
    stmt = select(User).where(User.email == email)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def find_user_with_wallets(
    db: AsyncSession,
    user_id: str,
) -> tuple[User | None, list[UserWallet]]:
    """Get a user and all their wallet associations.

    Used by the ``/auth/me`` endpoint to build a complete profile.

    Returns
    -------
    tuple[User | None, list[UserWallet]]
        ``(user, wallets)`` where *wallets* is empty when the user
        has no linked wallets or when the user does not exist.
    """
    user_stmt = select(User).where(User.id == user_id)
    user_result = await db.execute(user_stmt)
    user = user_result.scalar_one_or_none()

    if user is None:
        return None, []

    wallet_stmt = select(UserWallet).where(UserWallet.user_id == user_id)
    wallet_result = await db.execute(wallet_stmt)
    wallets = list(wallet_result.scalars().all())

    return user, wallets


async def find_user_by_wallet(
    db: AsyncSession,
    wallet_address: str,
    chain_type: str,
) -> tuple[User | None, UserWallet | None]:
    """Find the user who owns a wallet address on a given chain.

    Returns ``(user, wallet)`` if found, ``(None, None)`` otherwise.
    """
    wallet_stmt = select(UserWallet).where(
        UserWallet.wallet_address == wallet_address,
        UserWallet.chain_type == chain_type,
    )
    wallet_result = await db.execute(wallet_stmt)
    wallet = wallet_result.scalar_one_or_none()

    if wallet is None:
        return None, None

    user_stmt = select(User).where(User.id == wallet.user_id)
    user_result = await db.execute(user_stmt)
    user = user_result.scalar_one_or_none()

    return user, wallet


async def create_user_with_wallet(
    db: AsyncSession,
    wallet_address: str,
    chain_type: str,
    username: str | None = None,
) -> tuple[User, UserWallet]:
    """Atomically create a new user and link a wallet address.

    Both records are flushed in a single operation so they succeed or
    fail together within the caller's transaction boundary.
    """
    user = User(
        id=uuid4(),
        username=username,
    )
    db.add(user)
    await db.flush()

    wallet = UserWallet(
        id=uuid4(),
        user_id=user.id,
        wallet_address=wallet_address,
        chain_type=chain_type,
        is_primary=True,
        verified_at=datetime.now(UTC),
    )
    db.add(wallet)
    await db.flush()

    logger.info(
        "Created user with wallet user_id=%s chain=%s",
        user.id,
        chain_type,
    )
    return user, wallet


# ---------------------------------------------------------------------------
# Refresh token persistence
# ---------------------------------------------------------------------------


def _hash_refresh_token(token: str) -> str:
    """SHA-256 hash a refresh token for safe storage.

    TM-011: Consistent with auth token storage pattern.
    """
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


async def store_refresh_token(
    db: AsyncSession,
    user_id: str,
    application_id: str | None,
    token: str,
    expires_at: datetime,
    issued_ip: str | None = None,
    issued_user_agent: str | None = None,
) -> RefreshToken:
    """Persist a new refresh token record.

    TM-011: Stores SHA-256 hash of the token, not plaintext.
    Also stores network context (IP, user agent) for anomaly detection.

    Parameters
    ----------
    db:
        Active SQLAlchemy async session.
    user_id:
        The user this token belongs to.
    application_id:
        The application context (may be ``None``).
    token:
        The signed JWT string (plaintext — only hash is stored).
    expires_at:
        Absolute expiration timestamp.
    issued_ip:
        IP address from which this token was issued (TM-011).
    issued_user_agent:
        User agent from which this token was issued (TM-011).
    """
    row = RefreshToken(
        id=uuid4(),
        user_id=user_id,
        application_id=application_id,
        token=_hash_refresh_token(token),
        expires_at=expires_at,
        issued_ip=issued_ip,
        issued_user_agent=issued_user_agent,
        last_seen_ip=issued_ip,
        last_seen_user_agent=issued_user_agent,
    )
    db.add(row)
    await db.flush()
    return row


async def find_refresh_token(
    db: AsyncSession,
    token: str,
) -> RefreshToken | None:
    """Look up a refresh token by its JWT string.

    TM-011: Hashes the input before lookup.

    Returns ``None`` if the token does not exist or has already been
    consumed (``used_at IS NOT NULL``).
    """
    token_hash = _hash_refresh_token(token)
    stmt = (
        select(RefreshToken)
        .where(
            RefreshToken.token == token_hash,
            RefreshToken.used_at.is_(None),
        )
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def find_refresh_token_for_update(
    db: AsyncSession,
    token: str,
) -> RefreshToken | None:
    """Look up a refresh token with a row-level lock.

    TM-011: Uses SELECT ... FOR UPDATE to prevent concurrent token
    consumption.  The lock is held until the enclosing transaction
    commits or rolls back.
    """
    token_hash = _hash_refresh_token(token)
    stmt = (
        select(RefreshToken)
        .where(RefreshToken.token == token_hash, RefreshToken.used_at.is_(None))
        .with_for_update()
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def revoke_refresh_token(
    db: AsyncSession,
    token: str,
) -> bool:
    """Mark a refresh token as consumed.

    TM-011: Hashes the input before matching.

    Returns ``True`` if a token was found and revoked.
    """
    token_hash = _hash_refresh_token(token)
    now = datetime.now(UTC)
    stmt = (
        update(RefreshToken)
        .where(RefreshToken.token == token_hash, RefreshToken.used_at.is_(None))
        .values(used_at=now)
    )
    result = await db.execute(stmt)
    return result.rowcount > 0  # type: ignore[attr-defined]


async def revoke_all_user_refresh_tokens(
    db: AsyncSession,
    user_id: str,
) -> int:
    """Revoke every active refresh token for a user.

    Used during password reset to invalidate all existing sessions.
    Returns the number of tokens revoked.
    """
    now = datetime.now(UTC)
    stmt = (
        update(RefreshToken)
        .where(
            RefreshToken.user_id == user_id,
            RefreshToken.used_at.is_(None),
        )
        .values(used_at=now)
    )
    result = await db.execute(stmt)
    revoked = result.rowcount  # type: ignore[attr-defined]
    if revoked:
        logger.info("Revoked %d refresh tokens for user_id=%s", revoked, user_id)
    return revoked


# ---------------------------------------------------------------------------
# Auth token (password reset, magic link) persistence
# ---------------------------------------------------------------------------


def _hash_token(token: str) -> str:
    """SHA-256 hash a plaintext token for safe storage."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


async def create_auth_token(
    db: AsyncSession,
    *,
    user_id: str | None,
    email: str | None,
    token_type: str,
    application_id: str | None = None,
    expires_in: int = 3600,
) -> str:
    """Generate and persist a one-time auth token.

    Returns the **plaintext** token for inclusion in a URL or email.
    Only the SHA-256 hash is stored in the database.

    Parameters
    ----------
    token_type:
        E.g. ``'password_reset'``, ``'magic_link'``, ``'email_verification'``.
    expires_in:
        TTL in seconds (default 3600 = 1 hour).
    """
    plaintext = secrets.token_urlsafe(32)
    token_hash = _hash_token(plaintext)

    row = AuthToken(
        id=uuid4(),
        user_id=user_id,
        token_hash=token_hash,
        type=token_type,
        email=email,
        application_id=application_id,
        expires_at=datetime.now(UTC) + timedelta(seconds=expires_in),
    )
    db.add(row)
    await db.flush()

    logger.debug("Auth token created type=%s email=%s", token_type, email)
    return plaintext


def _is_hex_hash(value: str) -> bool:
    """Return True if *value* looks like a 64-char lowercase hex SHA-256 hash."""
    return len(value) == 64 and all(c in "0123456789abcdef" for c in value)


async def validate_and_consume_auth_token(
    db: AsyncSession,
    token: str,
    token_type: str,
    application_id: UUID | None = None,
) -> AuthToken | None:
    """Validate and consume a one-time auth token.

    Looks up the token by its hash, checks that it is unused and not
    expired, then marks it as consumed.

    Accepts either a raw plaintext token (which is hashed before lookup)
    or a pre-hashed ``token_hash`` (64-char lowercase hex).

    Returns the ``AuthToken`` row on success, ``None`` on failure.
    """
    # If the caller already provides a hex hash, use it directly
    token_hash = token if _is_hex_hash(token) else _hash_token(token)
    now = datetime.now(UTC)

    stmt = select(AuthToken).where(
        AuthToken.token_hash == token_hash,
        AuthToken.type == token_type,
        AuthToken.used_at.is_(None),
        AuthToken.expires_at >= now,
    )
    if application_id is not None:
        stmt = stmt.where(AuthToken.application_id == application_id)
    result = await db.execute(stmt)
    row = result.scalar_one_or_none()

    if row is None:
        return None

    row.used_at = now
    await db.flush()

    logger.debug("Auth token consumed type=%s", token_type)
    return row


# ---------------------------------------------------------------------------
# Magic-link state
# ---------------------------------------------------------------------------


async def store_magic_link_state(
    db: AsyncSession,
    *,
    state: str,
    email: str,
    application_id: str | None = None,
    expires_in: int = 3600,
) -> AuthMagicLinkState:
    """Persist magic-link state for later verification."""
    row = AuthMagicLinkState(
        id=uuid4(),
        state=state,
        email=email,
        application_id=application_id,
        expires_at=datetime.now(UTC) + timedelta(seconds=expires_in),
    )
    db.add(row)
    await db.flush()
    return row


async def find_magic_link_state(
    db: AsyncSession,
    state: str,
    application_id: UUID | None = None,
) -> AuthMagicLinkState | None:
    """Look up a magic-link state entry by its state string."""
    stmt = select(AuthMagicLinkState).where(
        AuthMagicLinkState.state == state,
        AuthMagicLinkState.expires_at >= datetime.now(UTC),
    )
    if application_id is not None:
        stmt = stmt.where(AuthMagicLinkState.application_id == application_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()
