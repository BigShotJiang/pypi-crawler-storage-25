"""Authorization policy engine domain."""
