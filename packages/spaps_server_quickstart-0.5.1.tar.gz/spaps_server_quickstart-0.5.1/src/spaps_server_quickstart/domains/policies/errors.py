"""Domain errors for the policy engine."""

from __future__ import annotations

from ..errors import DomainError


class PolicyNotFoundError(DomainError):
    def __init__(self, message: str = "Policy not found") -> None:
        super().__init__("POLICY_NOT_FOUND", message, status_code=404)


class PolicyAlreadyExistsError(DomainError):
    def __init__(self, message: str = "Policy with this name already exists for this application") -> None:
        super().__init__("POLICY_ALREADY_EXISTS", message, status_code=409)


class InvalidConditionError(DomainError):
    def __init__(self, message: str = "Invalid policy condition") -> None:
        super().__init__("INVALID_CONDITION", message, status_code=400)


class EvaluationError(DomainError):
    def __init__(self, message: str = "Policy evaluation failed") -> None:
        super().__init__("EVALUATION_ERROR", message, status_code=500)
