"""Database operations for the policy engine domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import Policy, PolicyEvaluationLog

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Policy CRUD
# ---------------------------------------------------------------------------


async def get_policy_by_id(
    db: AsyncSession,
    policy_id: UUID,
) -> Policy | None:
    stmt = select(Policy).where(Policy.id == policy_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_policy_by_name(
    db: AsyncSession,
    *,
    application_id: UUID,
    name: str,
) -> Policy | None:
    stmt = select(Policy).where(
        Policy.application_id == application_id,
        Policy.name == name,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_policies(
    db: AsyncSession,
    *,
    application_id: UUID,
    is_active: bool | None = None,
    limit: int = 100,
) -> list[Policy]:
    stmt = (
        select(Policy)
        .where(Policy.application_id == application_id)
        .order_by(Policy.priority.desc(), Policy.created_at.desc())
        .limit(limit)
    )
    if is_active is not None:
        stmt = stmt.where(Policy.is_active == is_active)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def create_policy(db: AsyncSession, **kwargs: Any) -> Policy:
    policy = Policy(**kwargs)
    db.add(policy)
    await db.flush()
    await db.refresh(policy)
    return policy


async def update_policy(
    db: AsyncSession,
    policy_id: UUID,
    **kwargs: Any,
) -> Policy | None:
    policy = await get_policy_by_id(db, policy_id)
    if policy is None:
        return None
    for key, value in kwargs.items():
        if key == "metadata":
            policy.metadata_ = value
        elif hasattr(policy, key):
            setattr(policy, key, value)
    policy.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(policy)
    return policy


async def delete_policy(db: AsyncSession, policy_id: UUID) -> bool:
    policy = await get_policy_by_id(db, policy_id)
    if policy is None:
        return False
    await db.delete(policy)
    await db.flush()
    return True


# ---------------------------------------------------------------------------
# Evaluation log
# ---------------------------------------------------------------------------


async def create_evaluation_log(
    db: AsyncSession,
    **kwargs: Any,
) -> PolicyEvaluationLog:
    log = PolicyEvaluationLog(**kwargs)
    db.add(log)
    await db.flush()
    return log


async def list_evaluation_logs(
    db: AsyncSession,
    *,
    application_id: UUID,
    policy_name: str | None = None,
    user_id: UUID | None = None,
    limit: int = 50,
) -> list[PolicyEvaluationLog]:
    stmt = (
        select(PolicyEvaluationLog)
        .where(PolicyEvaluationLog.application_id == application_id)
        .order_by(PolicyEvaluationLog.created_at.desc())
        .limit(limit)
    )
    if policy_name is not None:
        stmt = stmt.where(PolicyEvaluationLog.policy_name == policy_name)
    if user_id is not None:
        stmt = stmt.where(PolicyEvaluationLog.user_id == user_id)
    result = await db.execute(stmt)
    return list(result.scalars().all())
