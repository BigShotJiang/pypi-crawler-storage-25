"""Composable policy condition evaluator.

This module is the heart of the policy engine. It evaluates a condition tree
against a user's state by resolving individual conditions through existing
SPAPS services (wallets, subscriptions, entitlements, users).

Condition tree structure:

    # Leaf conditions -- each maps to a resolver
    {"has_entitlement": {"key": "premium_access"}}
    {"subscription_status": {"eq": "active"}}
    {"account_age_days": {"gte": 30}}
    {"has_wallet": {"chain": "solana"}}
    {"has_role": {"role": "admin"}}
    {"user_tier": {"eq": "pro"}}
    {"context_value": {"key": "ip_country", "eq": "US"}}

    # Combinators
    {"all": [<condition>, ...]}    # AND
    {"any": [<condition>, ...]}    # OR
    {"not": <condition>}           # NOT

Pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
import time
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Evaluation result
# ---------------------------------------------------------------------------


class EvalResult:
    """Result of evaluating a single condition or condition tree."""

    __slots__ = ("matched", "reasons")

    def __init__(self, matched: bool, reasons: list[str] | None = None) -> None:
        self.matched = matched
        self.reasons = reasons or []

    def __bool__(self) -> bool:
        return self.matched


# ---------------------------------------------------------------------------
# User context -- gathered once, reused across condition evaluations
# ---------------------------------------------------------------------------


class UserContext:
    """Lazily-populated snapshot of user state for policy evaluation.

    Each field is loaded on first access via the corresponding resolver,
    then cached for the duration of the evaluation.
    """

    def __init__(
        self,
        db: AsyncSession,
        *,
        user_id: UUID | None = None,
        application_id: UUID,
        email: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        self.db = db
        self.user_id = user_id
        self.application_id = application_id
        self.email = email
        self.extra = extra or {}

        # Cached resolver results (populated lazily)
        self._user_profile: dict[str, Any] | None = None
        self._wallets: list[dict[str, Any]] | None = None
        self._entitlements: dict[str, Any] | None = None
        self._subscriptions: list[dict[str, Any]] | None = None
        self._roles: list[str] | None = None

    async def get_user_profile(self) -> dict[str, Any]:
        if self._user_profile is None:
            if self.user_id is None:
                self._user_profile = {}
            else:
                try:
                    from ..users import service as users_svc

                    user = await users_svc.get_user_profile(
                        self.db, str(self.user_id)
                    )
                    self._user_profile = {
                        "id": str(user.id),
                        "email": user.email,
                        "tier": getattr(user, "tier", "basic"),
                        "created_at": user.created_at,
                    }
                except Exception:
                    logger.debug("Could not load user profile for policy eval", exc_info=True)
                    self._user_profile = {}
        return self._user_profile

    async def get_wallets(self) -> list[dict[str, Any]]:
        if self._wallets is None:
            if self.user_id is None:
                self._wallets = []
            else:
                try:
                    from ..wallets import service as wallets_svc

                    result = await wallets_svc.get_user_wallets(
                        self.db, str(self.user_id)
                    )
                    self._wallets = result.get("wallets", [])
                except Exception:
                    logger.debug("Could not load wallets for policy eval", exc_info=True)
                    self._wallets = []
        return self._wallets

    async def get_entitlements(self) -> dict[str, Any]:
        if self._entitlements is None:
            if self.user_id is None:
                self._entitlements = {"entitlements": [], "count": 0}
            else:
                try:
                    from ..entitlements import service as ent_svc

                    self._entitlements = await ent_svc.get_entitlements(
                        self.db,
                        application_id=self.application_id,
                        user_id=self.user_id,
                    )
                except Exception:
                    logger.debug("Could not load entitlements for policy eval", exc_info=True)
                    self._entitlements = {"entitlements": [], "count": 0}
        return self._entitlements

    async def get_subscriptions(self) -> list[dict[str, Any]]:
        if self._subscriptions is None:
            if self.user_id is None:
                self._subscriptions = []
            else:
                try:
                    from ..stripe import service as stripe_svc

                    result = await stripe_svc.list_subscriptions(
                        self.db,
                        user_id=self.user_id,
                        application_id=self.application_id,
                    )
                    if isinstance(result, list):
                        self._subscriptions = result
                    elif isinstance(result, dict):
                        self._subscriptions = result.get("subscriptions", [])
                    else:
                        self._subscriptions = []
                except Exception:
                    logger.debug("Could not load subscriptions for policy eval", exc_info=True)
                    self._subscriptions = []
        return self._subscriptions

    async def get_roles(self) -> list[str]:
        if self._roles is None:
            try:
                from ..sessions.admin_detection import get_user_roles

                profile = await self.get_user_profile()
                wallets = await self.get_wallets()
                wallet_addresses = [w.get("wallet_address", "") for w in wallets]
                self._roles = get_user_roles(
                    email=profile.get("email") or self.email,
                    user_id=str(self.user_id) if self.user_id else None,
                    wallet_addresses=wallet_addresses or None,
                )
            except Exception:
                logger.debug("Could not load roles for policy eval", exc_info=True)
                self._roles = ["user"]
        return self._roles


# ---------------------------------------------------------------------------
# Condition resolvers
# ---------------------------------------------------------------------------


async def _resolve_has_entitlement(
    ctx: UserContext, params: dict[str, Any]
) -> EvalResult:
    """Check if user has a specific entitlement key."""
    key = params.get("key", "")
    entitlements = await ctx.get_entitlements()
    for ent in entitlements.get("entitlements", []):
        if ent.get("entitlement_key") == key and ent.get("revoked_at") is None:
            return EvalResult(True, [f"has entitlement '{key}'"])
    return EvalResult(False, [f"missing entitlement '{key}'"])


async def _resolve_subscription_status(
    ctx: UserContext, params: dict[str, Any]
) -> EvalResult:
    """Check if user has a subscription with the given status."""
    target = params.get("eq", "active")
    subscriptions = await ctx.get_subscriptions()
    for sub in subscriptions:
        if sub.get("status") == target:
            return EvalResult(True, [f"has subscription with status '{target}'"])
    return EvalResult(False, [f"no subscription with status '{target}'"])


async def _resolve_account_age_days(
    ctx: UserContext, params: dict[str, Any]
) -> EvalResult:
    """Check if user account is at least N days old."""
    min_days = params.get("gte", 0)
    profile = await ctx.get_user_profile()
    created_at = profile.get("created_at")
    if created_at is None:
        return EvalResult(False, ["unknown account age"])
    if isinstance(created_at, str):
        created_at = datetime.fromisoformat(created_at)
    age_days = (datetime.now(UTC) - created_at).days
    if age_days >= min_days:
        return EvalResult(True, [f"account age {age_days}d >= {min_days}d"])
    return EvalResult(False, [f"account age {age_days}d < {min_days}d"])


async def _resolve_has_wallet(
    ctx: UserContext, params: dict[str, Any]
) -> EvalResult:
    """Check if user has a verified wallet, optionally on a specific chain."""
    chain = params.get("chain")
    wallets = await ctx.get_wallets()
    if chain:
        matching = [w for w in wallets if w.get("chain_type") == chain]
        if matching:
            return EvalResult(True, [f"has {chain} wallet"])
        return EvalResult(False, [f"no {chain} wallet"])
    if wallets:
        return EvalResult(True, ["has at least one wallet"])
    return EvalResult(False, ["no wallets"])


async def _resolve_has_role(
    ctx: UserContext, params: dict[str, Any]
) -> EvalResult:
    """Check if user has a specific role (admin, super_admin, user)."""
    target = params.get("role", "user")
    roles = await ctx.get_roles()
    if target in roles:
        return EvalResult(True, [f"has role '{target}'"])
    return EvalResult(False, [f"missing role '{target}'"])


async def _resolve_user_tier(
    ctx: UserContext, params: dict[str, Any]
) -> EvalResult:
    """Check user's tier against an expected value."""
    target = params.get("eq", "basic")
    profile = await ctx.get_user_profile()
    tier = profile.get("tier", "basic")
    if tier == target:
        return EvalResult(True, [f"user tier is '{target}'"])
    return EvalResult(False, [f"user tier '{tier}' != '{target}'"])


async def _resolve_context_value(
    ctx: UserContext, params: dict[str, Any]
) -> EvalResult:
    """Check a value from the caller-supplied context dict.

    Supports ``eq``, ``neq``, ``in``, ``contains`` comparisons.
    """
    key = params.get("key", "")
    value = ctx.extra.get(key)

    if "eq" in params:
        if value == params["eq"]:
            return EvalResult(True, [f"context '{key}' == {params['eq']!r}"])
        return EvalResult(False, [f"context '{key}' ({value!r}) != {params['eq']!r}"])

    if "neq" in params:
        if value != params["neq"]:
            return EvalResult(True, [f"context '{key}' != {params['neq']!r}"])
        return EvalResult(False, [f"context '{key}' == {params['neq']!r}"])

    if "in" in params:
        if value in params["in"]:
            return EvalResult(True, [f"context '{key}' in allowed list"])
        return EvalResult(False, [f"context '{key}' not in allowed list"])

    if "contains" in params:
        if isinstance(value, (list, str)) and params["contains"] in value:
            return EvalResult(True, [f"context '{key}' contains {params['contains']!r}"])
        return EvalResult(False, [f"context '{key}' does not contain {params['contains']!r}"])

    return EvalResult(value is not None, [f"context '{key}' {'present' if value is not None else 'absent'}"])


# Resolver registry
CONDITION_RESOLVERS: dict[str, Any] = {
    "has_entitlement": _resolve_has_entitlement,
    "subscription_status": _resolve_subscription_status,
    "account_age_days": _resolve_account_age_days,
    "has_wallet": _resolve_has_wallet,
    "has_role": _resolve_has_role,
    "user_tier": _resolve_user_tier,
    "context_value": _resolve_context_value,
}


# ---------------------------------------------------------------------------
# Tree evaluator
# ---------------------------------------------------------------------------


async def evaluate_condition(
    ctx: UserContext,
    condition: dict[str, Any],
) -> EvalResult:
    """Recursively evaluate a condition tree against the user context.

    Supports combinators (``all``, ``any``, ``not``) and leaf conditions
    that map to registered resolvers.
    """
    # --- Combinators ---

    if "all" in condition:
        children = condition["all"]
        if not isinstance(children, list):
            return EvalResult(False, ["'all' value must be a list"])
        reasons: list[str] = []
        for child in children:
            result = await evaluate_condition(ctx, child)
            reasons.extend(result.reasons)
            if not result:
                return EvalResult(False, reasons)
        return EvalResult(True, reasons)

    if "any" in condition:
        children = condition["any"]
        if not isinstance(children, list):
            return EvalResult(False, ["'any' value must be a list"])
        reasons = []
        for child in children:
            result = await evaluate_condition(ctx, child)
            reasons.extend(result.reasons)
            if result:
                return EvalResult(True, reasons)
        return EvalResult(False, reasons)

    if "not" in condition:
        inner = condition["not"]
        result = await evaluate_condition(ctx, inner)
        if result:
            return EvalResult(False, [f"NOT({', '.join(result.reasons)})"])
        return EvalResult(True, [f"NOT({', '.join(result.reasons)})"])

    # --- Leaf condition ---
    for key, params in condition.items():
        resolver = CONDITION_RESOLVERS.get(key)
        if resolver is None:
            return EvalResult(False, [f"unknown condition type '{key}'"])
        if not isinstance(params, dict):
            params = {"value": params}
        return await resolver(ctx, params)

    return EvalResult(False, ["empty condition"])


async def evaluate_policy(
    db: AsyncSession,
    *,
    conditions: dict[str, Any],
    effect: str,
    user_id: UUID | None,
    application_id: UUID,
    email: str | None = None,
    extra_context: dict[str, Any] | None = None,
) -> tuple[bool, list[str], int]:
    """Evaluate a full policy and return (allowed, reasons, elapsed_ms).

    The ``effect`` determines the semantics:
    - ``allow``: conditions must match for access to be granted
    - ``deny``: conditions must match for access to be blocked
    """
    start = time.monotonic()
    ctx = UserContext(
        db,
        user_id=user_id,
        application_id=application_id,
        email=email,
        extra=extra_context,
    )

    result = await evaluate_condition(ctx, conditions)
    elapsed_ms = int((time.monotonic() - start) * 1000)

    if effect == "deny":
        # Deny policy: if conditions match, access is denied
        allowed = not result.matched
    else:
        # Allow policy: if conditions match, access is allowed
        allowed = result.matched

    return allowed, result.reasons, elapsed_ms
