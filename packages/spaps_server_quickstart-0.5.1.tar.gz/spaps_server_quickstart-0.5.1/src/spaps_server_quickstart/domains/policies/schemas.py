"""Pydantic request/response schemas for the policy engine.

These schemas define the *data* portion of each API response.
The standard response envelope is applied by middleware.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Canonical representations
# ---------------------------------------------------------------------------


class PolicyOut(BaseModel):
    """Canonical representation of an authorization policy."""

    id: str
    application_id: str
    name: str
    description: str | None = None
    effect: Literal["allow", "deny"]
    conditions: dict[str, Any]
    priority: int = 0
    is_active: bool = True
    metadata: dict[str, Any] | None = None
    created_at: str
    updated_at: str


class EvaluationLogOut(BaseModel):
    """Canonical representation of a policy evaluation log entry."""

    id: str
    policy_id: str | None = None
    application_id: str
    user_id: str | None = None
    policy_name: str
    decision: str
    reasons: list[str]
    evaluation_ms: int
    created_at: str


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class CreatePolicyRequest(BaseModel):
    """POST /policies body."""

    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    effect: Literal["allow", "deny"] = "allow"
    conditions: dict[str, Any]
    priority: int = Field(default=0, ge=-1000, le=1000)
    metadata: dict[str, Any] | None = None


class UpdatePolicyRequest(BaseModel):
    """PUT /policies/{id} body."""

    name: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = None
    effect: Literal["allow", "deny"] | None = None
    conditions: dict[str, Any] | None = None
    priority: int | None = Field(default=None, ge=-1000, le=1000)
    is_active: bool | None = None
    metadata: dict[str, Any] | None = None


class AuthorizeRequest(BaseModel):
    """POST /policies/authorize body.

    Evaluates a named policy against a user. The caller provides the
    policy name and optionally a user_id.  If the request comes from
    an authenticated session the user_id can be inferred from the JWT.
    """

    policy_name: str
    user_id: str | None = None
    context: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class ListPoliciesResponse(BaseModel):
    """GET /policies -- success payload."""

    policies: list[PolicyOut]
    count: int


class PolicyResponse(BaseModel):
    """Single-policy success payload."""

    policy: PolicyOut


class AuthorizeResponse(BaseModel):
    """POST /policies/authorize -- success payload."""

    allowed: bool
    decision: Literal["allow", "deny"]
    policy_name: str
    reasons: list[str]
    evaluation_ms: int


class EvaluationLogsResponse(BaseModel):
    """GET /policies/evaluations -- success payload."""

    evaluations: list[EvaluationLogOut]
    count: int
