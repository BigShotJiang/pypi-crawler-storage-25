"""Business logic for the authorization policy engine.

Orchestrates CRUD operations, policy evaluation, and audit logging.
Pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from . import repository as repo
from .errors import (
    InvalidConditionError,
    PolicyAlreadyExistsError,
    PolicyNotFoundError,
)
from .evaluator import CONDITION_RESOLVERS, evaluate_policy
from .models import Policy, PolicyEvaluationLog

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _policy_to_dict(policy: Policy) -> dict[str, Any]:
    return {
        "id": str(policy.id),
        "application_id": str(policy.application_id),
        "name": policy.name,
        "description": policy.description,
        "effect": policy.effect,
        "conditions": policy.conditions,
        "priority": policy.priority,
        "is_active": policy.is_active,
        "metadata": policy.metadata_,
        "created_at": policy.created_at.isoformat() if policy.created_at else None,
        "updated_at": policy.updated_at.isoformat() if policy.updated_at else None,
    }


def _eval_log_to_dict(log: PolicyEvaluationLog) -> dict[str, Any]:
    return {
        "id": str(log.id),
        "policy_id": str(log.policy_id) if log.policy_id else None,
        "application_id": str(log.application_id),
        "user_id": str(log.user_id) if log.user_id else None,
        "policy_name": log.policy_name,
        "decision": log.decision,
        "reasons": log.reasons or [],
        "evaluation_ms": log.evaluation_ms,
        "created_at": log.created_at.isoformat() if log.created_at else None,
    }


def _validate_conditions(conditions: dict[str, Any]) -> None:
    """Validate that a condition tree uses only known condition types."""
    if not isinstance(conditions, dict):
        raise InvalidConditionError("Conditions must be a JSON object")
    if not conditions:
        raise InvalidConditionError("Conditions cannot be empty")

    for key, value in conditions.items():
        if key in ("all", "any"):
            if not isinstance(value, list):
                raise InvalidConditionError(f"'{key}' must contain a list of conditions")
            for child in value:
                _validate_conditions(child)
        elif key == "not":
            if not isinstance(value, dict):
                raise InvalidConditionError("'not' must contain a condition object")
            _validate_conditions(value)
        elif key not in CONDITION_RESOLVERS:
            raise InvalidConditionError(
                f"Unknown condition type '{key}'. "
                f"Valid types: {', '.join(sorted(CONDITION_RESOLVERS))}"
            )


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


async def create_policy(
    db: AsyncSession,
    *,
    application_id: UUID,
    name: str,
    description: str | None = None,
    effect: str = "allow",
    conditions: dict[str, Any],
    priority: int = 0,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a new authorization policy."""
    _validate_conditions(conditions)

    existing = await repo.get_policy_by_name(
        db, application_id=application_id, name=name
    )
    if existing is not None:
        raise PolicyAlreadyExistsError()

    policy = await repo.create_policy(
        db,
        application_id=application_id,
        name=name,
        description=description,
        effect=effect,
        conditions=conditions,
        priority=priority,
        metadata_=metadata,
    )
    logger.info(
        "Policy created",
        extra={"policy_id": str(policy.id), "policy_name": name},
    )
    return {"policy": _policy_to_dict(policy)}


async def get_policy(
    db: AsyncSession,
    *,
    policy_id: UUID,
    application_id: UUID,
) -> dict[str, Any]:
    """Get a single policy by ID."""
    policy = await repo.get_policy_by_id(db, policy_id)
    if policy is None or policy.application_id != application_id:
        raise PolicyNotFoundError()
    return {"policy": _policy_to_dict(policy)}


async def list_policies(
    db: AsyncSession,
    *,
    application_id: UUID,
    is_active: bool | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    """List all policies for an application."""
    policies = await repo.list_policies(
        db, application_id=application_id, is_active=is_active, limit=limit
    )
    return {
        "policies": [_policy_to_dict(p) for p in policies],
        "count": len(policies),
    }


async def update_policy(
    db: AsyncSession,
    *,
    policy_id: UUID,
    application_id: UUID,
    name: str | None = None,
    description: str | None = None,
    effect: str | None = None,
    conditions: dict[str, Any] | None = None,
    priority: int | None = None,
    is_active: bool | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Update an existing policy."""
    policy = await repo.get_policy_by_id(db, policy_id)
    if policy is None or policy.application_id != application_id:
        raise PolicyNotFoundError()

    if conditions is not None:
        _validate_conditions(conditions)

    # Check name uniqueness if changing name
    if name is not None and name != policy.name:
        existing = await repo.get_policy_by_name(
            db, application_id=application_id, name=name
        )
        if existing is not None:
            raise PolicyAlreadyExistsError()

    kwargs: dict[str, Any] = {}
    if name is not None:
        kwargs["name"] = name
    if description is not None:
        kwargs["description"] = description
    if effect is not None:
        kwargs["effect"] = effect
    if conditions is not None:
        kwargs["conditions"] = conditions
    if priority is not None:
        kwargs["priority"] = priority
    if is_active is not None:
        kwargs["is_active"] = is_active
    if metadata is not None:
        kwargs["metadata"] = metadata

    updated = await repo.update_policy(db, policy_id, **kwargs)
    if updated is None:
        raise PolicyNotFoundError()

    logger.info("Policy updated", extra={"policy_id": str(policy_id)})
    return {"policy": _policy_to_dict(updated)}


async def delete_policy(
    db: AsyncSession,
    *,
    policy_id: UUID,
    application_id: UUID,
) -> dict[str, Any]:
    """Delete a policy."""
    policy = await repo.get_policy_by_id(db, policy_id)
    if policy is None or policy.application_id != application_id:
        raise PolicyNotFoundError()

    await repo.delete_policy(db, policy_id)
    logger.info("Policy deleted", extra={"policy_id": str(policy_id)})
    return {"message": "Policy deleted", "id": str(policy_id)}


# ---------------------------------------------------------------------------
# Authorization evaluation
# ---------------------------------------------------------------------------


async def authorize(
    db: AsyncSession,
    *,
    application_id: UUID,
    policy_name: str,
    user_id: UUID | None = None,
    email: str | None = None,
    extra_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Evaluate a named policy against a user.

    Returns the authorization decision with reasons and timing.
    """
    policy = await repo.get_policy_by_name(
        db, application_id=application_id, name=policy_name
    )
    if policy is None:
        raise PolicyNotFoundError(f"No policy named '{policy_name}'")
    if not policy.is_active:
        raise PolicyNotFoundError(f"Policy '{policy_name}' is disabled")

    allowed, reasons, elapsed_ms = await evaluate_policy(
        db,
        conditions=policy.conditions,
        effect=policy.effect,
        user_id=user_id,
        application_id=application_id,
        email=email,
        extra_context=extra_context,
    )

    decision = "allow" if allowed else "deny"

    # Log the evaluation (best-effort, don't fail the request)
    try:
        await repo.create_evaluation_log(
            db,
            policy_id=policy.id,
            application_id=application_id,
            user_id=user_id,
            policy_name=policy_name,
            decision=decision,
            reasons=reasons,
            evaluation_ms=elapsed_ms,
        )
    except Exception:
        logger.warning("Failed to log policy evaluation", exc_info=True)

    logger.info(
        "Policy evaluated",
        extra={
            "policy_name": policy_name,
            "decision": decision,
            "user_id": str(user_id) if user_id else None,
            "elapsed_ms": elapsed_ms,
        },
    )

    return {
        "allowed": allowed,
        "decision": decision,
        "policy_name": policy_name,
        "reasons": reasons,
        "evaluation_ms": elapsed_ms,
    }


# ---------------------------------------------------------------------------
# Evaluation logs
# ---------------------------------------------------------------------------


async def get_evaluation_logs(
    db: AsyncSession,
    *,
    application_id: UUID,
    policy_name: str | None = None,
    user_id: UUID | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    """List recent policy evaluation logs."""
    logs = await repo.list_evaluation_logs(
        db,
        application_id=application_id,
        policy_name=policy_name,
        user_id=user_id,
        limit=limit,
    )
    return {
        "evaluations": [_eval_log_to_dict(log) for log in logs],
        "count": len(logs),
    }
