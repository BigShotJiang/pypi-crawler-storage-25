"""SQLAlchemy models for the authorization policy engine."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class Policy(Base):
    """A composable authorization policy.

    Policies define access rules as a tree of conditions that evaluate
    against user state (wallets, subscriptions, entitlements, account age,
    etc.).  Client applications create policies via API and evaluate them
    at request time through ``POST /api/policies/authorize``.
    """

    __tablename__ = "policies"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    effect: Mapped[str] = mapped_column(
        String(10), nullable=False, server_default="allow", default="allow"
    )
    conditions: Mapped[dict[str, Any]] = mapped_column(
        JSON, nullable=False, default=dict
    )
    priority: Mapped[int] = mapped_column(
        Integer, nullable=False, server_default="0", default=0
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, server_default="true", default=True
    )
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True, default=dict
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<Policy name={self.name!r} effect={self.effect!r}>"


class PolicyEvaluationLog(Base):
    """Audit log of policy evaluations.

    Records every authorize call with the decision, matched policy,
    and evaluation timing for observability and debugging.
    """

    __tablename__ = "policy_evaluation_logs"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    policy_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("policies.id", ondelete="SET NULL"),
        nullable=True,
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), nullable=False
    )
    user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True), nullable=True
    )
    policy_name: Mapped[str] = mapped_column(String(255), nullable=False)
    decision: Mapped[str] = mapped_column(
        String(10), nullable=False
    )
    reasons: Mapped[list[str]] = mapped_column(
        JSON, nullable=False, default=list
    )
    evaluation_ms: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    context_snapshot: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return (
            f"<PolicyEvaluationLog policy={self.policy_name!r} "
            f"decision={self.decision!r}>"
        )
