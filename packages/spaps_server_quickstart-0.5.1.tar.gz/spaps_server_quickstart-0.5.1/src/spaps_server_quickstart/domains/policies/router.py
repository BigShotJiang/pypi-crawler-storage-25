"""FastAPI router for the authorization policy engine.

Provides CRUD for policies and the core ``POST /policies/authorize``
evaluation endpoint.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Path, Query, Request

from ..errors import ValidationError
from ...middleware.spaps_deps import AdminUser, Application, DbSession, OptionalUser
from . import service
from .schemas import (
    AuthorizeRequest,
    AuthorizeResponse,
    CreatePolicyRequest,
    EvaluationLogsResponse,
    ListPoliciesResponse,
    PolicyResponse,
    UpdatePolicyRequest,
)

policies_router = APIRouter(prefix="/policies", tags=["policies"])


def _parse_uuid(value: str, field_name: str) -> UUID:
    try:
        return UUID(str(value))
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"{field_name} must be a valid UUID") from exc


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


@policies_router.get("", response_model=ListPoliciesResponse)
async def list_policies(
    request: Request,
    db: DbSession,
    app: Application,
    _admin: AdminUser,
    is_active: bool | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=1000),
) -> ListPoliciesResponse:
    """List all policies for the current application."""
    result = await service.list_policies(
        db,
        application_id=UUID(str(app.id)),
        is_active=is_active,
        limit=limit,
    )
    return ListPoliciesResponse(**result)


@policies_router.post("", response_model=PolicyResponse, status_code=201)
async def create_policy(
    request: Request,
    body: CreatePolicyRequest,
    db: DbSession,
    app: Application,
    _admin: AdminUser,
) -> PolicyResponse:
    """Create a new authorization policy."""
    result = await service.create_policy(
        db,
        application_id=UUID(str(app.id)),
        name=body.name,
        description=body.description,
        effect=body.effect,
        conditions=body.conditions,
        priority=body.priority,
        metadata=body.metadata,
    )
    return PolicyResponse(**result)


@policies_router.post("/authorize", response_model=AuthorizeResponse)
async def authorize(
    request: Request,
    body: AuthorizeRequest,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
) -> AuthorizeResponse:
    """Evaluate a named policy against a user.

    The user_id can be provided in the request body or inferred from
    the authenticated session (JWT).  The ``context`` field allows
    callers to pass arbitrary key-value pairs for ``context_value``
    conditions.
    """
    # Resolve user_id: explicit > JWT > None
    user_id = None
    email = None
    if body.user_id:
        user_id = _parse_uuid(body.user_id, "user_id")
    elif optional_user is not None:
        user_id = UUID(str(optional_user.id)) if hasattr(optional_user, "id") else None
        email = getattr(optional_user, "email", None)

    result = await service.authorize(
        db,
        application_id=UUID(str(app.id)),
        policy_name=body.policy_name,
        user_id=user_id,
        email=email,
        extra_context=body.context,
    )
    return AuthorizeResponse(**result)


# ---------------------------------------------------------------------------
# Evaluation logs
# ---------------------------------------------------------------------------


@policies_router.get("/evaluations", response_model=EvaluationLogsResponse)
async def list_evaluations(
    request: Request,
    db: DbSession,
    app: Application,
    _admin: AdminUser,
    policy_name: str | None = Query(default=None),
    user_id: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=500),
) -> EvaluationLogsResponse:
    """List recent policy evaluation logs."""
    result = await service.get_evaluation_logs(
        db,
        application_id=UUID(str(app.id)),
        policy_name=policy_name,
        user_id=_parse_uuid(user_id, "user_id") if user_id else None,
        limit=limit,
    )
    return EvaluationLogsResponse(**result)


@policies_router.get("/{policy_id}", response_model=PolicyResponse)
async def get_policy(
    request: Request,
    db: DbSession,
    app: Application,
    _admin: AdminUser,
    policy_id: UUID = Path(...),
) -> PolicyResponse:
    """Get a single policy by ID."""
    result = await service.get_policy(
        db,
        policy_id=policy_id,
        application_id=UUID(str(app.id)),
    )
    return PolicyResponse(**result)


@policies_router.put("/{policy_id}", response_model=PolicyResponse)
async def update_policy(
    request: Request,
    body: UpdatePolicyRequest,
    db: DbSession,
    app: Application,
    _admin: AdminUser,
    policy_id: UUID = Path(...),
) -> PolicyResponse:
    """Update an existing policy."""
    result = await service.update_policy(
        db,
        policy_id=policy_id,
        application_id=UUID(str(app.id)),
        name=body.name,
        description=body.description,
        effect=body.effect,
        conditions=body.conditions,
        priority=body.priority,
        is_active=body.is_active,
        metadata=body.metadata,
    )
    return PolicyResponse(**result)


@policies_router.delete("/{policy_id}")
async def delete_policy(
    request: Request,
    db: DbSession,
    app: Application,
    _admin: AdminUser,
    policy_id: UUID = Path(...),
) -> dict:
    """Delete a policy."""
    return await service.delete_policy(
        db,
        policy_id=policy_id,
        application_id=UUID(str(app.id)),
    )
