"""
API key validation middleware for SPAPS.

Validates the X-API-Key header against the applications table.
Supports three key types:
- Publishable keys (prefix: spaps_pub_) → checked against publishable_key_hash
- Secret keys (prefix: spaps_sec_ or spaps_) → checked against secret_key_hash
- Legacy keys → checked against api_key column (plaintext or hashed; TM-009: deprecated)

Sets request.state.application, request.state.api_key, request.state.key_type.

TM-009 Mitigation:
- Legacy API key authentication is deprecated
- Controlled via LEGACY_API_KEY_AUTH_ENABLED setting (default: True)
- Emits structured deprecation warnings when legacy keys are used
- Can be disabled to enforce migration to hashed keys
"""

from __future__ import annotations

import hashlib
import hmac
import logging
from typing import TYPE_CHECKING, Any

from fastapi import Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

if TYPE_CHECKING:
    from ..domains.applications.models import Application

logger = logging.getLogger(__name__)


class KeyType:
    PUBLISHABLE = "publishable"
    SECRET = "secret"
    LEGACY = "legacy"


def _hash_key(key: str) -> str:
    """SHA-256 hash of an API key for comparison."""
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def _log_legacy_key_used(app: Any, api_key: str) -> None:
    """Emit the structured TM-009 warning for any legacy-key authentication."""
    key_prefix = api_key[:8] if len(api_key) >= 8 else api_key
    logger.warning(
        "Legacy API key authentication used (TM-009 deprecation)",
        extra={
            "event": "legacy_api_key_used",
            "application_id": str(app.id),
            "key_prefix": key_prefix,
            "threat_model_item": "TM-009",
        },
    )


async def _lookup_legacy_application(
    session: AsyncSession,
    application_model: Any,
    api_key: str,
) -> Any | None:
    """Look up a legacy API key stored either plaintext or SHA-256 hashed."""
    stmt = select(application_model).where(application_model.api_key == api_key)
    result = await session.execute(stmt)
    app = result.scalar_one_or_none()
    if app is not None:
        return app

    key_hash = _hash_key(api_key)
    stmt = select(application_model).where(application_model.api_key == key_hash)
    result = await session.execute(stmt)
    app = result.scalar_one_or_none()
    if app and (
        app.api_key is None or not hmac.compare_digest(app.api_key, key_hash)
    ):
        return None
    return app


async def validate_api_key(
    session: AsyncSession,
    api_key: str,
    legacy_api_key_auth_enabled: bool = True,
) -> tuple["Application", str]:
    """
    Validate an API key and return (application, key_type).

    Args:
        session: Database session
        api_key: The API key to validate
        legacy_api_key_auth_enabled: If False, reject legacy keys (TM-009)

    Raises InvalidApplicationError (via caller) if the key is invalid.
    Returns None if not found.

    TM-009: Legacy API keys are deprecated. When legacy_api_key_auth_enabled
    is False, this function refuses to authenticate using the legacy api_key column.
    """
    from ..domains.applications.models import Application

    key_type: str

    if api_key.startswith("spaps_pub_"):
        # Publishable key — check publishable_key_hash with timing-safe comparison
        key_hash = _hash_key(api_key)
        stmt = select(Application).where(Application.publishable_key_hash == key_hash)
        result = await session.execute(stmt)
        app = result.scalar_one_or_none()
        # Verify with timing-safe comparison to prevent timing attacks
        if app and (app.publishable_key_hash is None or not hmac.compare_digest(app.publishable_key_hash, key_hash)):
            app = None
        key_type = KeyType.PUBLISHABLE
    elif api_key.startswith("spaps_sec_") or api_key.startswith("spaps_"):
        # Secret key — check secret_key_hash with timing-safe comparison
        key_hash = _hash_key(api_key)
        stmt = select(Application).where(Application.secret_key_hash == key_hash)
        result = await session.execute(stmt)
        app = result.scalar_one_or_none()
        # Verify with timing-safe comparison to prevent timing attacks
        if app and (app.secret_key_hash is None or not hmac.compare_digest(app.secret_key_hash, key_hash)):
            app = None
        if app is None:
            # TM-009: Fall back to legacy api_key column (deprecated path)
            if not legacy_api_key_auth_enabled:
                # Legacy auth disabled — treat as not found
                key_type = KeyType.SECRET
            else:
                app = await _lookup_legacy_application(session, Application, api_key)
                if app:
                    # TM-009: Legacy key used — log structured deprecation warning
                    _log_legacy_key_used(app, api_key)
                key_type = KeyType.LEGACY if app else KeyType.SECRET
        else:
            key_type = KeyType.SECRET
    else:
        # TM-009: Legacy key — direct match on api_key column (deprecated path)
        if not legacy_api_key_auth_enabled:
            # Legacy auth disabled — reject immediately
            logger.info(
                "Legacy API key authentication rejected (disabled)",
                extra={
                    "event": "legacy_api_key_rejected",
                    "key_prefix": api_key[:8] if len(api_key) >= 8 else api_key,
                    "threat_model_item": "TM-009",
                },
            )
            return None, KeyType.LEGACY  # type: ignore[return-value]

        app = await _lookup_legacy_application(session, Application, api_key)
        if app:
            # TM-009: Legacy key used — log structured deprecation warning
            _log_legacy_key_used(app, api_key)
        key_type = KeyType.LEGACY

    if app is None:
        return None, key_type  # type: ignore[return-value]

    return app, key_type


def extract_api_key(request: Request) -> str | None:
    """Extract API key from X-API-Key header or Authorization: Bearer."""
    api_key = request.headers.get("X-API-Key") or request.headers.get("x-api-key")
    if api_key:
        return api_key

    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer ") and not _looks_like_jwt(auth_header[7:]):
        return auth_header[7:]

    return None


def _looks_like_jwt(token: str) -> bool:
    """Quick heuristic: JWTs have 3 dot-separated parts."""
    return token.count(".") == 2
