"""
Response envelope middleware.

Wraps ALL JSON responses in the standard SPAPS envelope:

    {
        "success": true/false,
        "data": { ... },
        "error": { "code": "...", "message": "...", "details": { ... } } | null,
        "metadata": { "timestamp": "ISO8601", "request_id": "uuid" }
    }

Responses that are already enveloped (contain a top-level "success" key) are
passed through unchanged. Non-JSON responses (HTML, plain text, binary) are
also passed through unchanged.
"""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime

from starlette.types import ASGIApp, Message, Receive, Scope, Send

try:  # pragma: no cover - exercised by repo-level docs tooling without package deps
    import orjson
except ModuleNotFoundError:  # pragma: no cover
    orjson = None  # type: ignore[assignment]


def _json_loads(body: bytes) -> object:
    if orjson is not None:
        return orjson.loads(body)
    return json.loads(body)


def _json_dumps(body: object) -> bytes:
    if orjson is not None:
        return orjson.dumps(body, default=str)
    return json.dumps(body, default=str, separators=(",", ":")).encode("utf-8")


class ResponseEnvelopeMiddleware:
    """Wrap JSON responses in the standard SPAPS response envelope."""

    PASSTHROUGH_PREFIXES = (
        "/.well-known",
        "/docs",
        "/redoc",
        "/openapi.json",
        "/api-docs",
        "/api/metrics",
    )

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request_id = self._get_request_id(scope) or str(uuid.uuid4())
        scope.setdefault("state", {})["request_id"] = request_id

        path = scope.get("path", "")
        skip_path = self._is_passthrough_path(path)
        response_start: Message | None = None
        buffered_body = bytearray()

        async def send_wrapper(message: Message) -> None:
            nonlocal response_start

            if message["type"] == "http.response.start":
                self._track_metrics(message["status"])
                if skip_path or not self._is_json_headers(message.get("headers", [])):
                    await send(message)
                    return
                response_start = message
                return

            if message["type"] != "http.response.body" or response_start is None:
                await send(message)
                return

            body_chunk = message.get("body", b"")
            if body_chunk:
                buffered_body.extend(body_chunk)

            if message.get("more_body", False):
                return

            body_bytes = bytes(buffered_body)
            if not body_bytes:
                await send(response_start)
                await send(message)
                return

            try:
                body = _json_loads(body_bytes)
            except (ValueError, UnicodeDecodeError):
                await send(response_start)
                await send({"type": "http.response.body", "body": body_bytes, "more_body": False})
                return

            if isinstance(body, dict) and "success" in body:
                await send(response_start)
                await send({"type": "http.response.body", "body": body_bytes, "more_body": False})
                return

            is_success = 200 <= response_start["status"] < 400
            envelope: dict[str, object] = {"success": is_success}
            if is_success:
                envelope["data"] = body
            else:
                envelope["error"] = body
            envelope["metadata"] = {
                "timestamp": datetime.now(UTC).isoformat(),
                "request_id": request_id,
            }

            envelope_bytes = _json_dumps(envelope)
            await send(self._with_content_length(response_start, len(envelope_bytes)))
            await send(
                {
                    "type": "http.response.body",
                    "body": envelope_bytes,
                    "more_body": False,
                }
            )

        await self.app(scope, receive, send_wrapper)

    @classmethod
    def _is_passthrough_path(cls, path: str) -> bool:
        return any(path.startswith(prefix) for prefix in cls.PASSTHROUGH_PREFIXES)

    @staticmethod
    def _get_request_id(scope: Scope) -> str | None:
        for name, value in scope.get("headers", []):
            if name == b"x-request-id":
                return value.decode("latin-1")
        return None

    @staticmethod
    def _is_json_headers(headers: list[tuple[bytes, bytes]]) -> bool:
        for name, value in headers:
            if name == b"content-type":
                return b"application/json" in value.lower()
        return False

    @staticmethod
    def _with_content_length(message: Message, content_length: int) -> Message:
        headers = [
            (name, value)
            for name, value in message.get("headers", [])
            if name.lower() != b"content-length"
        ]
        headers.append((b"content-length", str(content_length).encode("latin-1")))
        return {**message, "headers": headers}

    @staticmethod
    def _track_metrics(status_code: int) -> None:
        from ..api.domains.metrics_router import increment_error_count, increment_request_count

        increment_request_count()
        if status_code >= 400:
            increment_error_count()
