"""Trusted-proxy-aware client IP resolution helpers."""

from __future__ import annotations

import ipaddress

from fastapi import Request

IpAddress = ipaddress.IPv4Address | ipaddress.IPv6Address
IpNetwork = ipaddress.IPv4Network | ipaddress.IPv6Network


def _parse_ip(value: str | None) -> IpAddress | None:
    if not value:
        return None
    try:
        return ipaddress.ip_address(value)
    except ValueError:
        return None


def _parse_trusted_networks(
    trusted_proxy_cidrs: list[str] | tuple[str, ...] | None,
) -> list[IpNetwork]:
    networks: list[IpNetwork] = []
    for entry in trusted_proxy_cidrs or []:
        normalized = str(entry).strip()
        if not normalized:
            continue
        try:
            networks.append(ipaddress.ip_network(normalized, strict=False))
        except ValueError:
            continue
    return networks


def _is_trusted_proxy(ip: IpAddress, trusted_networks: list[IpNetwork]) -> bool:
    return any(ip in network for network in trusted_networks)


def resolve_client_ip(
    request: Request,
    trusted_proxy_cidrs: list[str] | tuple[str, ...] | None = None,
) -> str | None:
    """Resolve the effective client IP from a request.

    Rules:
    - If the immediate peer is absent or invalid, return ``None``.
    - If no trusted proxy networks are configured, ignore ``X-Forwarded-For`` and
      return the immediate peer IP.
    - If the immediate peer is not trusted, ignore ``X-Forwarded-For`` and return
      the immediate peer IP.
    - If the immediate peer is trusted, walk the combined forwarded chain from the
      right-hand side and return the first hop that is not a trusted proxy.
    - If the forwarded chain is malformed or resolves only to trusted hops, return
      ``None``.
    """

    peer_host = getattr(getattr(request, "client", None), "host", None)
    peer_ip = _parse_ip(peer_host)
    if peer_ip is None:
        return None

    trusted_networks = _parse_trusted_networks(trusted_proxy_cidrs)
    if not trusted_networks or not _is_trusted_proxy(peer_ip, trusted_networks):
        return str(peer_ip)

    headers = getattr(request, "headers", None)
    forwarded_for = None
    if headers is not None:
        forwarded_for = headers.get("x-forwarded-for") or headers.get("X-Forwarded-For")

    chain: list[IpAddress] = []
    if forwarded_for:
        raw_hops = [hop.strip() for hop in forwarded_for.split(",")]
        if not raw_hops or any(not hop for hop in raw_hops):
            return None
        for hop in raw_hops:
            parsed_hop = _parse_ip(hop)
            if parsed_hop is None:
                return None
            chain.append(parsed_hop)

    chain.append(peer_ip)

    for hop in reversed(chain):
        if _is_trusted_proxy(hop, trusted_networks):
            continue
        return str(hop)

    return None
