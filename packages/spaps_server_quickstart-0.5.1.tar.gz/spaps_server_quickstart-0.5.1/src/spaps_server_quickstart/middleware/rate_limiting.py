"""
Rate limiting for SPAPS endpoints.

Uses slowapi with in-memory storage (matches Node.js express-rate-limit MemoryStore).
Counters reset on restart — acceptable per plan.

Tiers:
  STRICT:   5 req / 1 min
  TIGHT:    10 req / 1 min
  MODERATE: 15 req / 1 min
  STANDARD: 300 req / 15 min
  RELAXED:  500 req / 15 min
  GENEROUS: 1000 req / 1 hr
"""

from __future__ import annotations

import inspect
import logging
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Awaitable, Protocol

from redis import asyncio as redis_asyncio

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse, Response

from .client_ip import resolve_client_ip

logger = logging.getLogger(__name__)

# First-party app IDs exempt from rate limiting
EXEMPT_APP_IDS = {
    "8e1414cf-a876-4d6f-b907-faee17e1bc1a",  # HTMA Labs
    "6e9f0b0a-e9ba-4f04-894c-f12b4adf1788",  # Campbell Company Accounting
}

# Loopback addresses exempt from rate limiting
EXEMPT_IP_PREFIXES = ("127.0.0.1", "::1")


@dataclass(frozen=True)
class RateLimitTier:
    name: str
    max_requests: int
    window_seconds: int


class RateLimitStore(Protocol):
    def is_allowed(
        self,
        key: str,
        tier: RateLimitTier,
    ) -> tuple[bool, int] | Awaitable[tuple[bool, int]]:
        """Return whether the request is allowed and remaining quota."""


# Named tiers
STRICT = RateLimitTier("STRICT", 5, 60)
TIGHT = RateLimitTier("TIGHT", 10, 60)
MODERATE = RateLimitTier("MODERATE", 15, 60)
STANDARD = RateLimitTier("STANDARD", 300, 900)
RELAXED = RateLimitTier("RELAXED", 500, 900)
GENEROUS = RateLimitTier("GENEROUS", 1000, 3600)
AGENT_REGISTER = RateLimitTier("AGENT_REGISTER", 10, 60)
APPROVAL_CREATE = RateLimitTier("APPROVAL_CREATE", 30, 60)
APPROVAL_POLL = RateLimitTier("APPROVAL_POLL", 60, 60)

# Development mode tiers (much higher)
DEV_STRICT = RateLimitTier("DEV_STRICT", 100, 60)
DEV_TIGHT = RateLimitTier("DEV_TIGHT", 100, 60)
DEV_MODERATE = RateLimitTier("DEV_MODERATE", 200, 60)
DEV_STANDARD = RateLimitTier("DEV_STANDARD", 1000, 900)

# Endpoint -> tier mapping (production)
ENDPOINT_TIERS: dict[str, RateLimitTier] = {
    # Auth
    "/api/auth/login": TIGHT,
    "/api/auth/refresh": TIGHT,
    "/api/auth/nonce": TIGHT,
    "/api/auth/wallet-sign-in": TIGHT,
    "/api/auth/register": MODERATE,
    "/api/auth/magic-link": STRICT,
    "/api/auth/password-reset": STRICT,
    # Solana
    "/api/auth/solana/sign-in": TIGHT,
    "/api/auth/solana/link-wallet": TIGHT,
    "/api/auth/solana/verify-signature": TIGHT,
    # Ethereum
    "/api/auth/ethereum/sign-in": TIGHT,
    "/api/auth/ethereum/link-wallet": TIGHT,
    "/api/auth/ethereum/verify-signature": TIGHT,
    # Stripe
    "/api/stripe/guest-checkout-sessions": STRICT,
    "/api/stripe/checkout-sessions": TIGHT,
    "/api/stripe/portal-session": TIGHT,
    "/api/stripe/products": RELAXED,
    "/api/stripe/webhooks": GENEROUS,
    # Admin
    "/api/admin": STANDARD,
    "/api/admin/reports": TIGHT,
    # Health
    "/health": GENEROUS,
    # Docs
    "/api/docs": RELAXED,
    # Self-service
    "/api/self-service": TIGHT,
    # DayRate
    "/api/dayrate/book": TIGHT,
    # CFO
    "/api/cfo/exchange-code": STRICT,
    "/api/cfo/generate-link": TIGHT,
    "/api/cfo/validate-token": TIGHT,
    "/api/cfo/me": RELAXED,        # Identity endpoint, called frequently by portal hooks
    "/api/cfo/admin": STANDARD,    # Admin routes, normal limit
}

# Default tier for endpoints not in the map
DEFAULT_TIER = STANDARD


def _get_trusted_proxy_cidrs(
    request: Request,
) -> list[str] | tuple[str, ...] | None:
    settings = getattr(getattr(getattr(request, "app", None), "state", None), "settings", None)
    trusted_proxy_cidrs = getattr(settings, "trusted_proxy_cidrs", None)
    if isinstance(trusted_proxy_cidrs, (list, tuple)):
        return trusted_proxy_cidrs
    return None


def _get_real_client_ip(request: Request) -> str:
    """Extract the effective client IP using the trusted proxy policy."""
    client_ip = resolve_client_ip(
        request,
        trusted_proxy_cidrs=_get_trusted_proxy_cidrs(request),
    )
    return client_ip or "unknown"


def _get_path(request: Request) -> str:
    """Return request path as a string for test-friendly mocking."""
    return str(getattr(getattr(request, "url", None), "path", "") or "")


def _get_method(request: Request) -> str:
    """Return request method uppercased for test-friendly mocking."""
    return str(getattr(request, "method", "") or "").upper()


def _get_header_case_insensitive(request: Request, name: str) -> str | None:
    """Get header value in a case-insensitive way for real and mocked requests."""
    headers = getattr(request, "headers", None)
    if headers is None:
        return None
    value = headers.get(name)
    if value:
        return value
    return headers.get(name.lower())


def _is_approval_poll_path(path: str) -> bool:
    """True for GET /api/approvals/{approval_id} only."""
    segments = [s for s in path.split("/") if s]
    return len(segments) == 3 and segments[0] == "api" and segments[1] == "approvals"


def get_rate_limit_key(request: Request) -> str:
    """
    Rate limit key for the request.

    Agent approvals have tighter per-resource keys:
    - POST /api/approvals -> per agent_id
    - GET /api/approvals/:id -> per approval_id

    Everything else uses application_id when available, else client IP.
    """
    path = _get_path(request)
    method = _get_method(request)

    if method == "POST" and path == "/api/approvals":
        agent_id = _get_header_case_insensitive(request, "X-Agent-Id")
        if agent_id:
            return f"agent:{agent_id}"

    if method == "GET" and _is_approval_poll_path(path):
        approval_id = path.rsplit("/", 1)[-1]
        if approval_id:
            return f"approval:{approval_id}"

    if method == "POST" and path in {"/api/auth/login", "/api/auth/refresh"}:
        ip = _get_real_client_ip(request)
        return f"ip:{ip}"

    app_id = getattr(request.state, "application_id", None)
    if app_id:
        return f"app:{app_id}"

    # Fall back to real client IP (X-Forwarded-For aware)
    ip = _get_real_client_ip(request)
    return f"ip:{ip}"


async def _populate_rate_limit_context(request: Request) -> None:
    """Populate request.state fields needed by rate-limit exemptions/keying.

    Middleware runs before dependency injection, so this performs a lightweight
    API-key lookup when possible.
    """
    # Respect pre-populated state from upstream middleware/tests.
    if getattr(request.state, "application_id", None) is not None and getattr(
        request.state, "is_local_mode", None
    ) is not None:
        return

    app = getattr(request, "app", None)
    app_state = getattr(app, "state", None)
    settings = getattr(app_state, "settings", None)

    if getattr(settings, "is_spaps_local_mode", False) is True:
        request.state.is_local_mode = True
        return

    if not hasattr(request.state, "is_local_mode"):
        request.state.is_local_mode = False

    # Already known; no DB work needed.
    if getattr(request.state, "application_id", None) is not None:
        return

    db_resources = getattr(app_state, "db_resources", None)
    if db_resources is None:
        return

    try:
        from .api_key import extract_api_key, validate_api_key
    except Exception:
        return

    api_key = extract_api_key(request)
    if not api_key:
        return

    try:
        session_factory = db_resources.get_session_factory()
        async with session_factory() as session:
            # TM-009: Respect legacy_api_key_auth_enabled setting
            legacy_enabled = getattr(settings, "legacy_api_key_auth_enabled", True)
            application, _key_type = await validate_api_key(session, api_key, legacy_api_key_auth_enabled=legacy_enabled)
            if application is not None:
                request.state.application_id = str(application.id)
    except Exception:
        logger.debug("rate_limit_context_api_key_lookup_failed", exc_info=True)


def is_rate_limit_exempt(request: Request) -> bool:
    """Check if request is exempt from rate limiting."""
    # Local mode disables rate limiting
    if getattr(request.state, "is_local_mode", False):
        return True

    # Middleware runs before dependencies; check app settings directly too.
    settings = getattr(getattr(getattr(request, "app", None), "state", None), "settings", None)
    if getattr(settings, "is_spaps_local_mode", False) is True:
        return True

    # First-party apps exempt
    app_id = getattr(request.state, "application_id", None)
    if app_id in EXEMPT_APP_IDS:
        return True

    # Loopback only exempt
    ip = _get_real_client_ip(request)
    for prefix in EXEMPT_IP_PREFIXES:
        if ip.startswith(prefix):
            return True

    return False


def get_tier_for_path(path: str) -> RateLimitTier:
    """Get the rate limit tier for a request path."""
    # Exact match first
    if path in ENDPOINT_TIERS:
        return ENDPOINT_TIERS[path]

    # Prefix match — longest (most specific) endpoint wins so e.g.
    # /api/admin/reports/foo gets TIGHT instead of being shadowed by
    # /api/admin (STANDARD). Require a "/" boundary so /api/admin does
    # not accidentally match /api/administrator.
    for endpoint in _SORTED_ENDPOINT_PREFIXES:
        if path.startswith(f"{endpoint.rstrip('/')}/"):
            return ENDPOINT_TIERS[endpoint]

    return DEFAULT_TIER


_SORTED_ENDPOINT_PREFIXES: tuple[str, ...] = tuple(
    sorted(ENDPOINT_TIERS.keys(), key=len, reverse=True)
)


def get_tier_for_request(request: Request) -> RateLimitTier:
    """Get rate-limit tier for request method+path."""
    path = _get_path(request)
    method = _get_method(request)

    if method == "POST" and path == "/api/agents":
        return AGENT_REGISTER

    if method == "POST" and path == "/api/approvals":
        return APPROVAL_CREATE

    if method == "GET" and _is_approval_poll_path(path):
        return APPROVAL_POLL

    return get_tier_for_path(path)


def format_slowapi_limit(tier: RateLimitTier) -> str:
    """Format tier as slowapi limit string: '{max}/{window}second'."""
    return f"{tier.max_requests}/{tier.window_seconds}second"


# ---------------------------------------------------------------------------
# In-memory sliding-window rate limiter
# ---------------------------------------------------------------------------


class _SlidingWindowStore:
    """Thread-safe in-memory sliding window counter.

    Stores a list of request timestamps per key.  On each check, expired
    timestamps outside the window are pruned.  Counters reset on restart,
    matching the Node.js ``express-rate-limit`` MemoryStore behaviour.
    """

    def __init__(self) -> None:
        self._buckets: dict[str, deque[float]] = defaultdict(deque)

    def is_allowed(self, key: str, tier: RateLimitTier) -> tuple[bool, int]:
        """Check if *key* is within the rate limit for *tier*.

        Returns ``(allowed, remaining)`` where *remaining* is the number
        of requests left in the current window.
        """
        now = time.monotonic()
        cutoff = now - tier.window_seconds

        # Prune expired timestamps from the head — O(k) where k is the
        # number of newly-expired entries, not the full bucket length.
        timestamps = self._buckets[key]
        while timestamps and timestamps[0] <= cutoff:
            timestamps.popleft()

        if len(timestamps) >= tier.max_requests:
            return False, 0

        timestamps.append(now)
        return True, tier.max_requests - len(timestamps)

    def clear(self) -> None:
        """Reset all counters (useful for testing)."""
        self._buckets.clear()


class RedisSlidingWindowStore:
    """Distributed sliding-window limiter backed by Redis sorted sets."""

    _SCRIPT = """
local key = KEYS[1]
local cutoff = tonumber(ARGV[1])
local now = tonumber(ARGV[2])
local member = ARGV[3]
local limit = tonumber(ARGV[4])
local ttl = tonumber(ARGV[5])

redis.call('ZREMRANGEBYSCORE', key, 0, cutoff)

local current = redis.call('ZCARD', key)
if current >= limit then
  return {0, 0}
end

redis.call('ZADD', key, now, member)
redis.call('EXPIRE', key, ttl)
return {1, limit - current - 1}
"""

    def __init__(self, redis_url: str) -> None:
        self._redis = redis_asyncio.from_url(redis_url)

    async def is_allowed(self, key: str, tier: RateLimitTier) -> tuple[bool, int]:
        now_ms = int(time.time() * 1000)
        cutoff_ms = now_ms - (tier.window_seconds * 1000)
        member = f"{now_ms}:{time.time_ns()}"
        allowed, remaining = await self._redis.eval(
            self._SCRIPT,
            1,
            key,
            cutoff_ms,
            now_ms,
            member,
            tier.max_requests,
            tier.window_seconds + 1,
        )
        return bool(int(allowed)), int(remaining)


# Module-level singleton — survives across requests, resets on restart.
_store = _SlidingWindowStore()


def build_rate_limit_store(settings: object | None) -> RateLimitStore:
    """Return the configured rate-limit store for the current deployment."""
    backend = str(getattr(settings, "rate_limit_backend", "memory") or "memory").lower()
    if backend == "redis":
        redis_url = str(
            getattr(settings, "redis_url", "redis://localhost:6379/0")
            or "redis://localhost:6379/0"
        )
        return RedisSlidingWindowStore(redis_url)
    return _store


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Enforce per-path rate limiting using the SPAPS tier map.

    Exempt requests (local mode, first-party app, internal networks) are
    passed through without counting.  All others are checked against the
    sliding window store.
    """

    def __init__(self, app, *, settings: object | None = None) -> None:  # type: ignore[override]
        super().__init__(app)
        self._store: RateLimitStore = build_rate_limit_store(settings)

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint,
    ) -> Response:
        await _populate_rate_limit_context(request)

        # Skip exempt requests
        if is_rate_limit_exempt(request):
            return await call_next(request)

        tier = get_tier_for_request(request)
        key = get_rate_limit_key(request)
        bucket_key = f"{key}:{tier.name}"

        store_result = self._store.is_allowed(bucket_key, tier)
        if inspect.isawaitable(store_result):
            allowed, remaining = await store_result
        else:
            allowed, remaining = store_result

        if not allowed:
            logger.warning(
                "Rate limit exceeded key=%s tier=%s path=%s",
                key, tier.name, request.url.path,
            )
            return JSONResponse(
                status_code=429,
                content={
                    "success": False,
                    "data": None,
                    "error": {
                        "code": "RATE_LIMIT_EXCEEDED",
                        "message": "Too many requests",
                        "details": {
                            "tier": tier.name,
                            "limit": tier.max_requests,
                            "window_seconds": tier.window_seconds,
                        },
                    },
                    "metadata": {},
                },
                headers={
                    "Retry-After": str(tier.window_seconds),
                    "X-RateLimit-Limit": str(tier.max_requests),
                    "X-RateLimit-Remaining": "0",
                },
            )

        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(tier.max_requests)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        return response
