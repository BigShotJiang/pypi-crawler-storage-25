"""
Key scope enforcement middleware for SPAPS.

Publishable keys (spaps_pub_) have limited endpoint access.
Secret keys (spaps_sec_, spaps_, legacy) can access everything.
"""

from __future__ import annotations

import logging
import posixpath
from typing import Any
from urllib.parse import unquote

from ..domains.applications.blueprints import (
    BUILTIN_BLUEPRINTS,
    resolve_publishable_patterns,
    resolve_publishable_routes,
    resolve_publishable_routes_for_patterns,
)

logger = logging.getLogger(__name__)

DEFAULT_PUBLISHABLE_ENDPOINTS: tuple[str, ...] = tuple(
    resolve_publishable_patterns(
        list(BUILTIN_BLUEPRINTS["default"].publishable_scopes)
    )
)
DEFAULT_PUBLISHABLE_ROUTES: tuple[dict[str, Any], ...] = tuple(
    resolve_publishable_routes(list(BUILTIN_BLUEPRINTS["default"].publishable_scopes))
)


def _allowed_patterns(settings: dict[str, Any] | None) -> list[str]:
    if not isinstance(settings, dict):
        return list(DEFAULT_PUBLISHABLE_ENDPOINTS)

    access = settings.get("publishable_key_access")
    if not isinstance(access, dict):
        return list(DEFAULT_PUBLISHABLE_ENDPOINTS)

    patterns = access.get("allowed_patterns")
    if not isinstance(patterns, list) or not all(isinstance(p, str) for p in patterns):
        return list(DEFAULT_PUBLISHABLE_ENDPOINTS)

    return patterns


def _normalise_route(raw: dict[str, Any]) -> dict[str, Any] | None:
    path = raw.get("path")
    if not isinstance(path, str) or not path.startswith("/"):
        return None

    methods = raw.get("methods")
    if not isinstance(methods, list) or not methods:
        return None

    normalised_methods = [
        method.strip().upper() for method in methods if isinstance(method, str) and method.strip()
    ]
    if not normalised_methods:
        return None

    match = raw.get("match") or "exact"
    if not isinstance(match, str) or match not in {"exact", "prefix", "template"}:
        return None

    return {
        "path": path,
        "methods": normalised_methods,
        "match": match,
    }


def _allowed_routes(settings: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not isinstance(settings, dict):
        return [dict(route) for route in DEFAULT_PUBLISHABLE_ROUTES]

    access = settings.get("publishable_key_access")
    if not isinstance(access, dict):
        return [dict(route) for route in DEFAULT_PUBLISHABLE_ROUTES]

    routes = access.get("allowed_routes")
    if isinstance(routes, list):
        normalised = [
            route
            for raw in routes
            if isinstance(raw, dict)
            for route in [_normalise_route(raw)]
            if route is not None
        ]
        if normalised or not routes:
            return normalised

    return resolve_publishable_routes_for_patterns(_allowed_patterns(settings))


def _path_parts(path: str) -> list[str]:
    return [part for part in path.strip("/").split("/") if part]


def _normalize_request_path(raw_path: str) -> str | None:
    decoded = unquote(raw_path)
    # Defense in depth: reject obviously suspicious surface before normalization
    # collapses repeated separators or coerces backslashes into a single segment.
    if "//" in decoded or "\\" in decoded:
        return None
    normalized = posixpath.normpath(decoded)
    if not normalized.startswith("/"):
        normalized = "/" + normalized
    if _path_parts(raw_path) != _path_parts(normalized):
        return None
    return normalized


def _template_matches(template: str, path: str) -> bool:
    template_parts = _path_parts(template)
    path_parts = _path_parts(path)
    if len(template_parts) != len(path_parts):
        return False

    for template_part, path_part in zip(template_parts, path_parts):
        if template_part.startswith("{") and template_part.endswith("}"):
            if not path_part:
                return False
            continue
        if template_part != path_part:
            return False

    return True


def _path_matches(rule_path: str, path: str, match: str) -> bool:
    if match == "template":
        return _template_matches(rule_path, path)

    if match == "prefix":
        prefix = rule_path if rule_path.endswith("/") else f"{rule_path}/"
        return path == rule_path.rstrip("/") or path.startswith(prefix)

    if path == rule_path:
        return True

    return path.rstrip("/") == rule_path.rstrip("/") and rule_path != "/"


def is_endpoint_allowed_for_publishable(
    path: str,
    settings: dict[str, Any] | None = None,
    *,
    method: str = "GET",
) -> bool:
    """
    Check if a publishable key can access this endpoint.
    Secret and legacy keys have unrestricted access.
    """
    normalized = _normalize_request_path(path)
    if normalized is None:
        return False

    request_method = method.strip().upper()
    for route in _allowed_routes(settings):
        methods = route["methods"]
        if "*" not in methods and request_method not in methods:
            continue
        if _path_matches(route["path"], normalized, route["match"]):
            return True

    return False
