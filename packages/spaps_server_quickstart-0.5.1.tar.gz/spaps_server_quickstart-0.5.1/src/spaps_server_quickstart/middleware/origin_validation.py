"""
Origin validation middleware for SPAPS.

For publishable keys: validates Origin header against application.allowed_origins.
Secret and legacy keys skip origin validation.

Supports:
- Exact match: "https://example.com"
- Wildcard subdomain: "*.example.com"
- Deep wildcard: "**.example.com"
- Wildcard port: "localhost:*" or "http://localhost:*"
"""

from __future__ import annotations

import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

_GLOBAL_WILDCARD_PATTERNS = {"*", "http://*", "https://*"}


def validate_origin(origin: str | None, allowed_origins: list[str] | None) -> bool:
    """
    Check if the origin is allowed.

    TM-009: Empty allowed_origins now DENIES all origins for publishable keys.
    Applications must explicitly configure allowed_origins.
    """
    if not allowed_origins:
        return False

    if not origin:
        # No origin header — reject for publishable keys
        return False

    for pattern in allowed_origins:
        if _origin_matches(origin, pattern):
            return True

    return False


def _origin_parts(value: str) -> tuple[str, str, str | None] | None:
    """Return normalized (origin, host, scheme) for a browser Origin value."""
    candidate = value.strip().rstrip("/")
    if not candidate:
        return None

    try:
        parsed = urlparse(candidate)
        port = parsed.port
    except ValueError:
        return None

    if not parsed.scheme or not parsed.hostname:
        return None

    scheme = parsed.scheme.lower()
    host = parsed.hostname.lower()
    if ":" in host and not host.startswith("["):
        rendered_host = f"[{host}]"
    else:
        rendered_host = host

    normalized = f"{scheme}://{rendered_host}"
    if port is not None:
        normalized = f"{normalized}:{port}"
    return normalized, host, scheme


def _wildcard_port_parts(pattern: str) -> tuple[str, str | None] | None:
    """Return (host, optional scheme) for localhost:* style patterns."""
    if not pattern.endswith(":*"):
        return None

    base = pattern[:-2].strip().rstrip("/")
    if not base:
        return None

    parsed = urlparse(base)
    if parsed.scheme:
        if not parsed.hostname:
            return None
        return parsed.hostname.lower(), parsed.scheme.lower()

    return base.strip("[]").lower(), None


def _origin_matches(origin: str, pattern: str) -> bool:
    """Check if an origin matches an allowed_origin pattern."""
    normalized_pattern = pattern.strip().rstrip("/")
    if not normalized_pattern:
        return False

    if normalized_pattern.lower() in _GLOBAL_WILDCARD_PATTERNS:
        return False

    origin_parts = _origin_parts(origin)
    if origin_parts is None:
        return False

    normalized_origin, origin_host, origin_scheme = origin_parts

    # Exact match (case-insensitive, normalized for trailing slashes/host case)
    pattern_parts = _origin_parts(normalized_pattern)
    if pattern_parts is not None and normalized_origin == pattern_parts[0]:
        return True

    # Wildcard port: "localhost:*" matches "http://localhost:3000"
    wildcard_port = _wildcard_port_parts(normalized_pattern)
    if wildcard_port is not None:
        pattern_host, pattern_scheme = wildcard_port
        if origin_host == pattern_host and (
            pattern_scheme is None or origin_scheme == pattern_scheme
        ):
            return True

    # Deep wildcard: "**.example.com" matches any depth of subdomain
    if normalized_pattern.startswith("**."):
        domain = normalized_pattern[3:].lower()
        if origin_host == domain or origin_host.endswith("." + domain):
            return True

    # Wildcard subdomain: "*.example.com" matches one level of subdomain
    if normalized_pattern.startswith("*."):
        domain = normalized_pattern[2:].lower()
        if origin_host.endswith("." + domain):
            # Ensure only one subdomain level
            prefix = origin_host[: -len(domain)]
            if prefix and "." not in prefix.rstrip("."):
                return True

    return False
