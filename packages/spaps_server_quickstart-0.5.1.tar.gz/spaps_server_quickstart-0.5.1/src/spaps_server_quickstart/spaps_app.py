"""
SPAPS application entry point.

Creates the FastAPI application for the Sweet Potato Auth & Payment Service.
This is the "v1.0" app factory that includes domain routers alongside the
existing quickstart scaffolding.

Usage:
    uvicorn spaps_server_quickstart.spaps_app:app --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.responses import ORJSONResponse
from sqlalchemy import text

from .domains._db.model_registry import import_all_models

from .api.domains.health_router import router as health_router
from .api.domains.metrics_router import router as metrics_router
from .api.router import build_base_router
from .domains.applications.router import router as admin_router
from .domains.auth.router import router as auth_router
from .domains.self_service.router import router as self_service_router
from .domains.sessions.router import router as sessions_router
from .domains.users.router import router as users_router
from .domains.wallets import ethereum_router, solana_router
from .domains.whitelist.router import router as whitelist_router
from .domains.entitlements.router import entitlements_router, mappings_router
from .domains.stripe.router import (
    products_router as stripe_products_router,
    checkout_router as stripe_checkout_router,
    guest_checkout_router as stripe_guest_checkout_router,
    subscriptions_router as stripe_subscriptions_router,
    history_router as stripe_history_router,
    portal_router as stripe_portal_router,
    webhooks_router as stripe_webhooks_router,
    admin_webhooks_router as stripe_admin_webhooks_router,
)
# Phase 5: email + webhooks
from .domains.email.router import email_router
from .domains.webhooks.router import webhooks_router, mailgun_router
# Phase 6: CFO/QuickBooks
from .domains.cfo.router import cfo_router
# Phase 6b: CFO RBAC (role management, feature toggles, /me)
from .domains.cfo_roles.router import cfo_admin_router
from .domains.cfo_roles.me_router import cfo_me_router
# Phase 7: remaining domains
from .domains.dayrate.router import dayrate_router, dayrate_admin_router
from .domains.audit.router import audit_router
from .domains.security.router import security_router
from .domains.docs.router import docs_router, openapi_router
from .domains.crypto.router import crypto_router, payments_stub_router, usage_stub_router
from .domains.device_flow.router import device_flow_router
from .domains.secure_messages.router import secure_messages_router
# Phase 8: agent approvals (consent gateway)
from .domains.agent_approvals.router import agents_router, approvals_router
# Phase 10: approval authz prod hardening (governance health)
from .domains.approval_authz_prod_hardening.router import governance_health_router
# Phase 9: affiliate referrals
from .domains.affiliate_referrals.router import (
    affiliates_router,
    referrals_router,
    affiliate_admin_router,
    affiliate_config_router,
    internal_commissions_router,
)
# Phase 11: support telemetry platform
from .domains.support_telemetry_platform.router import router as support_telemetry_router
# Phase 12: shared issue reporting
from .domains.issue_reporting_platform.router import router as issue_reporting_router
# Phase 13: authorization policy engine
from .domains.policies.router import policies_router
from .db.session import DatabaseResources
from .logging import configure_logging
from starlette.middleware.cors import CORSMiddleware

from .middleware.envelope import ResponseEnvelopeMiddleware
from .middleware.error_handler import install_error_handlers
from .middleware.rate_limiting import RateLimitMiddleware
from .middleware.security_headers import SecurityHeadersMiddleware
from .spaps_settings import SpapsSettings, get_spaps_settings
from .startup import startup_checks

logger = logging.getLogger(__name__)


async def _validate_tm013_pii_startup_invariant(
    settings: SpapsSettings,
    db_resources: DatabaseResources,
) -> None:
    """TM-013: Fail startup in production when pii-enabled apps exist without a master key."""
    if settings.env not in ("production", "prod"):
        return
    if settings.spaps_pii_master_key:
        return

    session_factory = db_resources.get_session_factory()
    async with session_factory() as session:
        result = await session.execute(
            text(
                """
                SELECT EXISTS (
                  SELECT 1
                  FROM applications
                  WHERE COALESCE((settings->>'pii_enabled')::boolean, false) = true
                )
                """
            )
        )
        pii_enabled_exists = bool(result.scalar())

    if pii_enabled_exists:
        raise RuntimeError(
            "TM-013 invariant failed: SPAPS_PII_MASTER_KEY is required in production "
            "when pii_enabled applications exist"
        )


async def _validate_tm014_email_override_startup_invariant(
    settings: SpapsSettings,
    db_resources: DatabaseResources,
) -> None:
    """TM-014: Fail startup in production when app-level email overrides exist."""
    if settings.env not in ("production", "prod"):
        return

    session_factory = db_resources.get_session_factory()
    async with session_factory() as session:
        result = await session.execute(
            text(
                """
                SELECT slug,
                       CASE
                         WHEN COALESCE(settings->'email'->>'override_to', '') <> ''
                           THEN 'override_to'
                         ELSE 'dev_override_to'
                       END AS override_key
                  FROM applications
                 WHERE COALESCE(settings->'email'->>'override_to', '') <> ''
                    OR COALESCE(settings->'email'->>'dev_override_to', '') <> ''
                 ORDER BY slug
                """
            )
        )
        violations = [
            f"{row['slug']}.{row['override_key']}" for row in result.mappings().all()
        ]

    if violations:
        raise RuntimeError(
            "TM-014 invariant failed: application email recipient overrides are "
            "not allowed in production ("
            + ", ".join(violations)
            + ")"
        )


async def _ensure_local_application_row(
    settings: SpapsSettings,
    db_resources: DatabaseResources,
) -> None:
    """Persist the advertised local-mode application so FK-backed writes succeed."""
    if not settings.is_spaps_local_mode:
        return

    from .domains.applications.models import Application
    from .middleware.local_mode import LOCAL_APPLICATION

    session_factory = db_resources.get_session_factory()
    async with session_factory() as session:
        await session.merge(
            Application(
                id=LOCAL_APPLICATION.id,
                name=LOCAL_APPLICATION.name,
                slug=LOCAL_APPLICATION.slug,
                api_key=LOCAL_APPLICATION.api_key,
                allowed_origins=list(LOCAL_APPLICATION.allowed_origins),
                webhook_url=LOCAL_APPLICATION.webhook_url,
                settings=dict(LOCAL_APPLICATION.settings or {}),
                whitelist_enabled=LOCAL_APPLICATION.whitelist_enabled,
                whitelist_count=LOCAL_APPLICATION.whitelist_count,
            )
        )
        await session.commit()

    logger.info("Ensured local-mode application row exists", extra={"app_id": str(LOCAL_APPLICATION.id)})


def create_spaps_app(
    *,
    settings: SpapsSettings | None = None,
) -> FastAPI:
    """
    Build the fully configured SPAPS FastAPI application.

    Mirrors consumer_server's create_app() pattern: explicit router
    composition, lifespan management, middleware stack.
    """
    settings = settings or get_spaps_settings()
    configure_logging(settings)
    import_all_models()

    # Database resources (lazy — engine created on first use)
    db_resources = DatabaseResources(settings)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        # Startup: validate configuration and safety invariants
        startup_checks(settings)
        await _ensure_local_application_row(settings, db_resources)
        await _validate_tm013_pii_startup_invariant(settings, db_resources)
        await _validate_tm014_email_override_startup_invariant(settings, db_resources)

        # Verify all model tables are registered before runtime writes.
        import_all_models()

        yield

        # Shutdown: dispose database connections
        await db_resources.dispose()

    # --- Compose routers ---
    # Phase 0: health + metrics only. Domain routers added in later phases.
    api_router = build_base_router(
        (health_router, {"prefix": "", "tags": ["health"]}),
        (metrics_router, {"prefix": "", "tags": ["metrics"]}),
        # Phase 1: domain routers
        (auth_router, {"prefix": "/api", "tags": ["auth"]}),
        (sessions_router, {"prefix": "/api", "tags": ["sessions"]}),
        (users_router, {"prefix": "/api", "tags": ["users"]}),
        (solana_router, {"prefix": "/api", "tags": ["solana"]}),
        (ethereum_router, {"prefix": "/api", "tags": ["ethereum"]}),
        # Phase 2: admin, whitelist, self-service
        (admin_router, {"prefix": "/api", "tags": ["admin"]}),
        (whitelist_router, {"prefix": "/api", "tags": ["whitelist"]}),
        (self_service_router, {"prefix": "/api", "tags": ["self-service"]}),
        # Phase 3: entitlements
        (entitlements_router, {"prefix": "/api", "tags": ["entitlements"]}),
        (mappings_router, {"prefix": "/api", "tags": ["entitlement-mappings"]}),
        # Phase 4: stripe
        (stripe_products_router, {"prefix": "/api", "tags": ["stripe-products"]}),
        (stripe_checkout_router, {"prefix": "/api", "tags": ["stripe-checkout"]}),
        (stripe_guest_checkout_router, {"prefix": "/api", "tags": ["stripe-guest-checkout"]}),
        (stripe_subscriptions_router, {"prefix": "/api", "tags": ["stripe-subscriptions"]}),
        (stripe_history_router, {"prefix": "/api", "tags": ["stripe-history"]}),
        (stripe_portal_router, {"prefix": "/api", "tags": ["stripe-portal"]}),
        (stripe_webhooks_router, {"prefix": "/api", "tags": ["stripe-webhooks"]}),
        (stripe_admin_webhooks_router, {"prefix": "/api", "tags": ["admin-stripe"]}),
        # Phase 5: email + webhooks
        (email_router, {"prefix": "/api", "tags": ["email"]}),
        (webhooks_router, {"prefix": "/api", "tags": ["webhooks"]}),
        (mailgun_router, {"prefix": "/api", "tags": ["webhooks"]}),
        # Phase 6: CFO/QuickBooks
        (cfo_router, {"prefix": "/api", "tags": ["cfo"]}),
        # Phase 6b: CFO RBAC
        (cfo_admin_router, {"prefix": "/api", "tags": ["cfo-admin"]}),
        (cfo_me_router, {"prefix": "/api", "tags": ["cfo-me"]}),
        # Phase 7: remaining domains
        (dayrate_router, {"prefix": "/api", "tags": ["dayrate"]}),
        (dayrate_admin_router, {"prefix": "/api", "tags": ["dayrate-admin"]}),
        (audit_router, {"prefix": "/api", "tags": ["audit"]}),
        (security_router, {"prefix": "/api", "tags": ["security"]}),
        (docs_router, {"prefix": "/api", "tags": ["docs"]}),
        (openapi_router, {"prefix": "", "tags": ["openapi"]}),
        (crypto_router, {"prefix": "/api", "tags": ["crypto"]}),
        (payments_stub_router, {"prefix": "/api", "tags": ["payments-stubs"]}),
        (usage_stub_router, {"prefix": "/api", "tags": ["usage-stubs"]}),
        (device_flow_router, {"prefix": "/api", "tags": ["device-flow"]}),
        (secure_messages_router, {"prefix": "/api", "tags": ["secure-messages"]}),
        # Phase 8: agent approvals
        (agents_router, {"prefix": "/api", "tags": ["agents"]}),
        (approvals_router, {"prefix": "/api", "tags": ["approvals"]}),
        # Phase 9: affiliate referrals
        (affiliates_router, {"prefix": "/api", "tags": ["affiliates"]}),
        (referrals_router, {"prefix": "/api", "tags": ["referrals"]}),
        (affiliate_admin_router, {"prefix": "/api", "tags": ["admin-payouts"]}),
        (affiliate_config_router, {"prefix": "/api", "tags": ["affiliate-config"]}),
        (internal_commissions_router, {"prefix": "/api", "tags": ["internal-commissions"]}),
        # Phase 10: approval authz prod hardening
        (governance_health_router, {"prefix": "/api", "tags": ["claw-governance"]}),
        # Phase 11: support telemetry platform
        (support_telemetry_router, {"prefix": "/api", "tags": ["support-telemetry"]}),
        # Phase 12: shared issue reporting
        (issue_reporting_router, {"prefix": "/api", "tags": ["issue-reporting"]}),
        # Phase 13: authorization policy engine
        (policies_router, {"prefix": "/api", "tags": ["policies"]}),
    )

    app = FastAPI(
        title="SPAPS - Sweet Potato Auth & Payment Service",
        version=settings.version,
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
        debug=settings.debug,
        default_response_class=ORJSONResponse,
    )

    # Install error handlers (DomainError → response envelope)
    install_error_handlers(app)

    # Middleware stack (outermost first — order matters)
    # 1. Response envelope wraps all JSON responses
    app.add_middleware(ResponseEnvelopeMiddleware)

    # 2. Rate limiting (before business logic, after CORS preflight)
    app.add_middleware(RateLimitMiddleware, settings=settings)

    # 3. Security headers on every response (after CORS, before rate limiting)
    app.add_middleware(SecurityHeadersMiddleware)

    # 4. CORS (outermost — must handle OPTIONS preflight before other middleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_allow_origins),
        allow_methods=list(settings.cors_allow_methods),
        allow_headers=list(settings.cors_allow_headers),
        expose_headers=list(settings.cors_expose_headers),
        allow_credentials=settings.cors_allow_credentials,
        max_age=settings.cors_max_age,
    )

    # Include routers
    app.include_router(api_router)

    # Store references on app.state for health checks and dependency injection
    app.state.db_resources = db_resources
    app.state.settings = settings

    return app


# Module-level app instance for uvicorn
app = create_spaps_app()
