"""
SPAPS authentication helpers shared across services.
"""

from __future__ import annotations

import fnmatch
import hashlib
import importlib
import sys
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, cast

import httpx
import structlog
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.types import ASGIApp

from ..settings import BaseServiceSettings


# Session validation cache - keyed by token hash
# Format: {token_hash: (AuthenticatedUser, expires_at)}
_SESSION_CACHE: dict[str, tuple[AuthenticatedUser, datetime]] = {}
_SESSION_CACHE_TTL_SECONDS = 60  # 1 minute default TTL
_SESSION_CACHE_MAX_SIZE = 1000  # Prevent unbounded growth


def _hash_token(token: str) -> str:
    """Create a secure hash of the token for cache key."""
    return hashlib.sha256(token.encode()).hexdigest()[:32]


def _cleanup_expired_session_cache() -> None:
    """Remove expired entries from the session cache."""
    now = datetime.now(tz=UTC)
    expired_keys = [
        token_hash
        for token_hash, (_, expires_at) in _SESSION_CACHE.items()
        if expires_at <= now
    ]
    for token_hash in expired_keys:
        del _SESSION_CACHE[token_hash]


def _get_cached_session(token: str) -> AuthenticatedUser | None:
    """Get a cached session if valid, otherwise return None."""
    token_hash = _hash_token(token)
    now = datetime.now(tz=UTC)

    if token_hash in _SESSION_CACHE:
        user, expires_at = _SESSION_CACHE[token_hash]
        if expires_at > now:
            return user
        # Entry expired
        del _SESSION_CACHE[token_hash]

    return None


def _cache_session(token: str, user: AuthenticatedUser) -> None:
    """Cache an authenticated session."""
    # Determine expiry: use session expiry if available and sooner, otherwise use TTL
    now = datetime.now(tz=UTC)
    ttl_expiry = now + timedelta(seconds=_SESSION_CACHE_TTL_SECONDS)

    if user.session_expires_at and user.session_expires_at < ttl_expiry:
        expires_at = user.session_expires_at
    else:
        expires_at = ttl_expiry

    # Don't cache if already expired
    if expires_at <= now:
        return

    token_hash = _hash_token(token)
    _SESSION_CACHE[token_hash] = (user, expires_at)

    # Cleanup if cache is too large
    if len(_SESSION_CACHE) > _SESSION_CACHE_MAX_SIZE:
        _cleanup_expired_session_cache()
        # If still too large, remove oldest entries
        while len(_SESSION_CACHE) > _SESSION_CACHE_MAX_SIZE:
            oldest_key = next(iter(_SESSION_CACHE))
            del _SESSION_CACHE[oldest_key]


def _locate_python_client_src() -> Path | None:
    """
    Walk up the filesystem to find the monorepo python-client source directory.
    """

    current = Path(__file__).resolve()
    for parent in current.parents:
        candidate = parent / "packages" / "python-client" / "src"
        if candidate.exists():
            return candidate
    return None


def _import_spaps_client() -> tuple[type[Any], type[Exception]]:
    """
    Import the SPAPS client, falling back to the monorepo source tree when running locally.
    """

    try:
        module = importlib.import_module("spaps_client")
    except ImportError:  # pragma: no cover - exercised via fallback test
        fallback = _locate_python_client_src()
        if fallback is None:
            raise
        if str(fallback) not in sys.path:
            sys.path.append(str(fallback))
        module = importlib.import_module("spaps_client")
    return module.AsyncSessionsClient, module.SessionError  # type: ignore[attr-defined]


AsyncSessionsClient, SessionError = _import_spaps_client()


class AuthenticationError(Exception):
    """Raised when a request cannot be authenticated via SPAPS."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        error_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


@dataclass(slots=True)
class AuthenticatedUser:
    """Represents the authenticated subject and subscription context."""

    user_id: str
    session_id: str
    application_id: str
    roles: set[str] = field(default_factory=set)
    subscription_active: bool = False
    subscription_plan: str | None = None
    tier: str | None = None
    session_expires_at: datetime | None = None


class SpapsAuthService:
    """Facilitates authentication by delegating to the Sweet Potato Sessions API."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        application_id: str,
        request_timeout: float = 10.0,
        http_client: httpx.AsyncClient | None = None,
        role_hints: Sequence[str] | None = None,
        logger_namespace: str = "service.auth",
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._application_id = application_id
        self._request_timeout = request_timeout
        if http_client is None:
            self._client = httpx.AsyncClient(base_url=self._base_url, timeout=request_timeout)
            self._owns_client = True
        else:
            self._client = http_client
            self._owns_client = False
        self._sessions_client = AsyncSessionsClient(
            base_url=self._base_url,
            api_key=self._api_key,
            access_token="",
            client=self._client,
            request_timeout=self._request_timeout,
        )
        self._role_hints = {hint.lower() for hint in role_hints or ("practitioner", "patient")}
        self._logger = structlog.get_logger(logger_namespace)

    async def authenticate(self, access_token: str) -> AuthenticatedUser:
        if not access_token:
            raise AuthenticationError("Access token missing", status_code=401)

        # Check cache first
        cached_user = _get_cached_session(access_token)
        if cached_user is not None:
            self._logger.debug(
                "spaps.session_cache_hit",
                user_id=cached_user.user_id,
                session_id=cached_user.session_id,
            )
            return cached_user

        try:
            validation = await self._sessions_client.validate_session(
                access_token_override=access_token
            )
        except SessionError as exc:  # pragma: no cover - exercised via middleware tests
            raise self._handle_session_error(
                exc,
                event="spaps.validation_failed",
                default_detail="Authentication failed",
            )
        except httpx.HTTPError as exc:  # pragma: no cover - network failures
            self._logger.error("spaps.http_error", error=str(exc))
            raise AuthenticationError("Authentication service unavailable", status_code=503) from exc

        if not validation.valid:
            self._logger.warning(
                "spaps.session_invalid",
                session_id=validation.session_id,
                renewed=validation.renewed,
            )
            raise AuthenticationError(
                "Authentication required",
                status_code=401,
                error_code="SESSION_INVALID",
            )

        try:
            session = await self._sessions_client.get_current_session(
                access_token_override=access_token
            )
        except SessionError as exc:  # pragma: no cover - exercised via middleware tests
            raise self._handle_session_error(
                exc,
                event="spaps.session_lookup_failed",
                default_detail="Authentication failed",
            )
        except httpx.HTTPError as exc:  # pragma: no cover - network failures
            self._logger.error("spaps.http_error", error=str(exc))
            raise AuthenticationError("Authentication service unavailable", status_code=503) from exc

        if session.application_id != self._application_id:
            self._logger.warning(
                "spaps.application_mismatch",
                expected=self._application_id,
                received=session.application_id,
            )
            raise AuthenticationError(
                "Token not issued for this application",
                status_code=401,
                error_code="APPLICATION_MISMATCH",
            )

        roles = self._derive_roles(session.tier)
        subscription_active = bool(session.tier)
        authenticated = AuthenticatedUser(
            user_id=session.user_id,
            session_id=session.session_id,
            application_id=session.application_id,
            roles=roles,
            subscription_active=subscription_active,
            subscription_plan=session.tier,
            tier=session.tier,
            session_expires_at=session.expires_at,
        )

        # Cache the successful authentication
        _cache_session(access_token, authenticated)
        self._logger.debug(
            "spaps.session_cached",
            user_id=authenticated.user_id,
            session_id=authenticated.session_id,
        )

        return authenticated

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    def _derive_roles(self, tier: str | None) -> set[str]:
        if tier:
            tier_lower = tier.lower()
            roles = {hint for hint in self._role_hints if hint in tier_lower}
            if roles:
                return roles
        return {"patient"}

    def _handle_session_error(
        self,
        exc: Exception,
        *,
        event: str,
        default_detail: str,
    ) -> AuthenticationError:
        detail = exc.args[0] if exc.args else default_detail
        status_code_attr = cast(int | None, getattr(exc, "status_code", None))
        error_code = cast(str | None, getattr(exc, "error_code", None))
        request_id = cast(str | None, getattr(exc, "request_id", None))

        status_code = status_code_attr or 401
        if status_code >= 500:
            status_code = 503
            detail = "Authentication service unavailable"

        self._logger.warning(
            event,
            status_code=status_code_attr,
            error_code=error_code,
            request_id=request_id,
        )
        return AuthenticationError(
            detail,
            status_code=status_code,
            error_code=error_code,
        )


class SpapsAuthMiddleware(BaseHTTPMiddleware):
    """Starlette middleware that authenticates requests using SPAPS."""

    def __init__(
        self,
        app: ASGIApp,
        *,
        auth_service: SpapsAuthService,
        exempt_paths: Iterable[str] | None = None,
    ) -> None:
        super().__init__(app)
        self.auth_service = auth_service
        normalized_paths = {
            self._normalize_path(path) for path in (exempt_paths or {"/health", "/docs", "/redoc"})
        }
        self.exempt_paths = normalized_paths
        # Paths without wildcards - exact match
        self._exempt_exact = {path for path in normalized_paths if "*" not in path}
        # Simple suffix wildcards like /v1/auth/* - can use fast prefix match
        # Only if * appears exactly once at the very end
        self._exempt_prefixes = tuple(
            self._strip_wildcard(path)
            for path in normalized_paths
            if path.endswith("/*") and path.count("*") == 1
        )
        # Complex glob patterns with * in the middle or multiple * - use fnmatch
        # (e.g., /v1/chatroom/*/ws, /api/*/public/*)
        self._exempt_globs = tuple(
            path for path in normalized_paths
            if "*" in path and not (path.endswith("/*") and path.count("*") == 1)
        )

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # If already authenticated by another middleware (e.g., TrustedServiceMiddleware),
        # skip authentication and pass through
        if hasattr(request.state, "authenticated_user") and request.state.authenticated_user:
            return await call_next(request)

        if self._is_exempt(request):
            return await call_next(request)

        auth_header = request.headers.get("Authorization")
        if not auth_header:
            return self._unauthorized("Authorization header missing")

        scheme, _, token = auth_header.partition(" ")
        if scheme.lower() != "bearer" or not token:
            return self._unauthorized("Invalid authorization scheme")

        try:
            user = await self.auth_service.authenticate(token)
        except AuthenticationError as exc:
            return self._handle_authentication_error(exc)

        request.state.authenticated_user = user
        return await call_next(request)

    def _is_exempt(self, request: Request) -> bool:
        normalized = self._normalize_path(request.url.path)
        if normalized in self._exempt_exact:
            return True
        if any(self._matches_prefix(normalized, prefix) for prefix in self._exempt_prefixes):
            return True
        # Check fnmatch-style glob patterns (e.g., /v1/chatroom/*/ws)
        return any(fnmatch.fnmatch(normalized, pattern) for pattern in self._exempt_globs)

    @staticmethod
    def _normalize_path(path: str) -> str:
        if not path:
            return "/"
        normalized = path if path.startswith("/") else f"/{path}"
        if len(normalized) > 1 and normalized.endswith("/"):
            normalized = normalized.rstrip("/")
        return normalized

    @staticmethod
    def _strip_wildcard(path: str) -> str:
        base = path[:-1]
        base = base.rstrip("/")
        return base or "/"

    @staticmethod
    def _matches_prefix(path: str, prefix: str) -> bool:
        if prefix in {"/", ""}:
            return True
        return path == prefix or path.startswith(f"{prefix}/")

    @staticmethod
    def _unauthorized(message: str) -> JSONResponse:
        return JSONResponse(
            {"detail": message},
            status_code=401,
            headers={"WWW-Authenticate": "Bearer"},
        )

    def _handle_authentication_error(self, exc: AuthenticationError) -> JSONResponse:
        status_code = getattr(exc, "status_code", None) or 401
        if status_code == 401:
            return self._unauthorized(str(exc))
        return JSONResponse({"detail": str(exc)}, status_code=status_code)


def build_spaps_auth_service(
    settings: BaseServiceSettings,
    *,
    http_client: httpx.AsyncClient | None = None,
    role_hints: Sequence[str] | None = None,
    logger_namespace: str | None = None,
    **extra: Any,
) -> SpapsAuthService:
    """
    Build an auth service instance using the shared settings.
    """

    if not settings.spaps_api_key:
        raise ValueError("SPAPS_API_KEY is not configured")
    if not settings.spaps_application_id:
        raise ValueError("SPAPS_APPLICATION_ID is not configured")
    namespace = logger_namespace or f"{settings.logger_namespace}.auth"
    return SpapsAuthService(
        base_url=settings.spaps_api_url,
        api_key=settings.spaps_api_key,
        application_id=settings.spaps_application_id,
        request_timeout=settings.spaps_request_timeout,
        http_client=http_client,
        role_hints=role_hints,
        logger_namespace=namespace,
        **extra,
    )


__all__ = [
    "AuthenticatedUser",
    "AuthenticationError",
    "SpapsAuthMiddleware",
    "SpapsAuthService",
    "build_spaps_auth_service",
]
