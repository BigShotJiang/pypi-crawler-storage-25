"""
Startup validation for Sweet Potato services.

Provides fail-fast configuration validation and startup logging with masked secrets.
Call startup_checks() in your app's lifespan context manager before yielding.

For SPAPS-specific safety invariants (production credential detection in non-production
environments), see validate_environment().
"""

from __future__ import annotations

import ipaddress
import os
import re
from typing import TYPE_CHECKING
from urllib.parse import urlparse

import structlog

if TYPE_CHECKING:
    from .settings import BaseServiceSettings

logger = structlog.get_logger(__name__)


class EnvironmentSafetyError(RuntimeError):
    """Raised when production credentials are detected in a non-production environment.

    This is the last line of defense. The dev data pipeline loads real production
    data — real emails, real Stripe customer IDs, real webhook URLs, real encrypted
    PII, real OAuth tokens. Without these guardrails, a misconfigured dev environment
    can email real users, charge real cards, or leak PII.
    """


def _is_valid_ip_or_cidr(value: str) -> bool:
    """Return True when *value* is a valid IP address or CIDR."""
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        pass

    try:
        ipaddress.ip_network(value, strict=False)
        return True
    except ValueError:
        return False


def _is_https_url(value: str) -> bool:
    """Return True when *value* is an absolute HTTPS URL."""
    parsed = urlparse(value)
    return parsed.scheme.lower() == "https" and bool(parsed.netloc)


def startup_checks(settings: "BaseServiceSettings") -> None:
    """
    Run all startup validation and logging.

    Call this in your lifespan context manager before yielding.
    Raises RuntimeError if configuration is invalid.
    Raises EnvironmentSafetyError if production credentials detected in non-production.

    Example:
        @asynccontextmanager
        async def lifespan(app: FastAPI):
            startup_checks(settings)
            yield
    """
    logger.info("startup_validation_begin")
    validate_settings(settings)
    validate_environment(settings)
    log_startup_config(settings)
    logger.info("startup_validation_complete")


def validate_settings(settings: "BaseServiceSettings") -> None:
    """
    Validate settings and fail fast if invalid.

    Collects all errors and raises a single RuntimeError with all issues.
    This catches configuration problems early before they cause confusing
    failures later in the application lifecycle.

    Raises:
        RuntimeError: If configuration is invalid.
    """
    errors: list[str] = []

    # Required: DATABASE_URL must be set and valid PostgreSQL
    if not settings.database_url:
        errors.append("DATABASE_URL is required")
    elif not settings.database_url.startswith("postgresql"):
        errors.append(
            f"DATABASE_URL must start with 'postgresql', got: {settings.database_url[:30]}..."
        )

    # SPAPS auth/token signing safety: if these fields exist on the settings
    # object (SpapsSettings), they must not be empty.
    jwt_secret = getattr(settings, "jwt_secret", None)
    if jwt_secret is not None and not str(jwt_secret).strip():
        errors.append("JWT_SECRET is required")

    refresh_secret = getattr(settings, "refresh_token_secret", None)
    if refresh_secret is not None and not str(refresh_secret).strip():
        errors.append("REFRESH_TOKEN_SECRET is required")

    # Conditional: if SPAPS auth is enabled, require related vars
    if settings.spaps_auth_enabled:
        if not settings.spaps_api_key:
            errors.append("SPAPS_API_KEY is required when SPAPS_AUTH_ENABLED=true")
        if not settings.spaps_application_id:
            errors.append("SPAPS_APPLICATION_ID is required when SPAPS_AUTH_ENABLED=true")
        if not settings.spaps_api_url:
            errors.append("SPAPS_API_URL is required when SPAPS_AUTH_ENABLED=true")

    if errors:
        error_msg = "Configuration validation failed:\n  - " + "\n  - ".join(errors)
        logger.error("startup_validation_failed", errors=errors)
        raise RuntimeError(error_msg)


def validate_environment(settings: "BaseServiceSettings") -> None:
    """
    Refuse to start if production credentials are detected in non-production mode.

    This is NOT optional. It is the last line of defense when everything else is
    misconfigured. Uses duck-typing so it works for both BaseServiceSettings
    (no-op for non-SPAPS services) and SpapsSettings (full safety checks).

    Raises:
        EnvironmentSafetyError: If safety violations are detected.
    """
    env = getattr(settings, "env", "development")
    if env in ("production", "prod"):
        _validate_production_environment(settings)
        return

    _validate_non_production_environment(settings, env)


def _validate_production_environment(settings: "BaseServiceSettings") -> None:
    production_violations: list[str] = []

    # Production can use production keys (obviously).
    # But fail if local mode is somehow enabled.
    if getattr(settings, "spaps_local_mode", False):
        logger.error(
            "environment_safety_violation",
            detail="SPAPS_LOCAL_MODE=true in production — this should never happen",
        )
        raise EnvironmentSafetyError(
            "Refusing to start: SPAPS_LOCAL_MODE cannot be enabled in production"
        )

    _append_production_url_violations(settings, production_violations)
    _append_quickbooks_oauth_violations(settings, production_violations)
    _append_legacy_api_key_violations(settings, production_violations)
    _append_cors_policy_violations(settings, production_violations)
    _append_webhook_policy_violations(settings, production_violations)
    _append_self_service_violations(settings, production_violations)

    if production_violations:
        raise EnvironmentSafetyError(
            f"Refusing to start: {len(production_violations)} safety violation(s) in production:\n"
            + "\n".join(f"  - {v}" for v in production_violations)
        )


def _append_production_url_violations(
    settings: "BaseServiceSettings",
    violations: list[str],
) -> None:
    if hasattr(settings, "spaps_api_url"):
        spaps_api_url = str(getattr(settings, "spaps_api_url", "")).strip()
        if spaps_api_url and not _is_https_url(spaps_api_url):
            violations.append("SPAPS_API_URL must use https:// in production")

    if hasattr(settings, "cfo_api_url"):
        cfo_api_url = str(getattr(settings, "cfo_api_url", "")).strip()
        if cfo_api_url and not _is_https_url(cfo_api_url):
            violations.append("CFO_API_URL must use https:// in production")


def _append_quickbooks_oauth_violations(
    settings: "BaseServiceSettings",
    violations: list[str],
) -> None:
    quickbooks_client_id = str(getattr(settings, "quickbooks_client_id", "")).strip()
    quickbooks_client_secret = str(getattr(settings, "quickbooks_client_secret", "")).strip()
    if not (quickbooks_client_id and quickbooks_client_secret):
        return

    cfo_public_key = str(getattr(settings, "cfo_public_key", "")).strip()
    if not cfo_public_key:
        violations.append(
            "CFO_PUBLIC_KEY is required in production when QuickBooks OAuth is configured"
        )


def _append_legacy_api_key_violations(
    settings: "BaseServiceSettings",
    violations: list[str],
) -> None:
    if hasattr(settings, "legacy_api_key_auth_enabled") and getattr(
        settings, "legacy_api_key_auth_enabled", False
    ):
        violations.append(
            "LEGACY_API_KEY_AUTH_ENABLED must be false in production — "
            "disable legacy plaintext API-key authentication"
        )


def _append_cors_policy_violations(
    settings: "BaseServiceSettings",
    violations: list[str],
) -> None:
    allow_credentials = bool(getattr(settings, "cors_allow_credentials", False))
    if not allow_credentials:
        return

    origins_raw = getattr(settings, "cors_allow_origins", ()) or ()
    origins = [str(origin).strip() for origin in origins_raw if str(origin).strip()]
    if "*" in origins:
        violations.append(
            "CORS wildcard origins cannot be used with credentials in production"
        )


def _append_webhook_policy_violations(
    settings: "BaseServiceSettings",
    violations: list[str],
) -> None:
    if not hasattr(settings, "webhook_destination_policy_mode"):
        return

    policy_mode = str(
        getattr(settings, "webhook_destination_policy_mode", "off")
    ).strip().lower()
    if policy_mode != "allowlist":
        violations.append(
            "WEBHOOK_DESTINATION_POLICY_MODE must be 'allowlist' in production"
        )
        return

    allowed_domains_raw = getattr(settings, "webhook_allowed_domains", [])
    allowed_domains = [
        str(domain).strip() for domain in allowed_domains_raw if str(domain).strip()
    ]
    if not allowed_domains:
        violations.append(
            "WEBHOOK_ALLOWED_DOMAINS must contain at least one domain in production "
            "when WEBHOOK_DESTINATION_POLICY_MODE=allowlist"
        )


def _append_self_service_violations(
    settings: "BaseServiceSettings",
    violations: list[str],
) -> None:
    if hasattr(settings, "self_service_allowed_ips"):
        allowed_ips_raw = getattr(settings, "self_service_allowed_ips", []) or []
        allowed_ips = [str(entry).strip() for entry in allowed_ips_raw if str(entry).strip()]
        if not allowed_ips:
            violations.append(
                "SELF_SERVICE_ALLOWED_IPS must contain at least one trusted IP/CIDR in production"
            )
        else:
            invalid_entries = [entry for entry in allowed_ips if not _is_valid_ip_or_cidr(entry)]
            if invalid_entries:
                violations.append(
                    "SELF_SERVICE_ALLOWED_IPS contains invalid IP/CIDR entries in production: "
                    + ", ".join(invalid_entries)
                )

    if hasattr(settings, "trusted_proxy_cidrs"):
        trusted_proxy_cidrs_raw = getattr(settings, "trusted_proxy_cidrs", []) or []
        trusted_proxy_cidrs = [
            str(entry).strip() for entry in trusted_proxy_cidrs_raw if str(entry).strip()
        ]
        invalid_entries = [
            entry for entry in trusted_proxy_cidrs if not _is_valid_ip_or_cidr(entry)
        ]
        if invalid_entries:
            violations.append(
                "TRUSTED_PROXY_CIDRS contains invalid IP/CIDR entries in production: "
                + ", ".join(invalid_entries)
            )

    if hasattr(settings, "self_service_password") and str(
        getattr(settings, "self_service_password", "")
    ).strip():
        violations.append(
            "SELF_SERVICE_PASSWORD must be unset in production — "
            "shared-password self-service auth is not allowed"
        )


def _validate_non_production_environment(
    settings: "BaseServiceSettings", env: str
) -> None:
    violations: list[str] = []

    # 1. No real emails in dev — EVER (unless explicitly opted-in)
    # If MAILGUN_API_KEY is set in non-production, refuse to start
    # UNLESS SPAPS_FORCE_EMAIL_DELIVERY=true (for use with DEV_EMAIL_OVERRIDE_TO).
    mailgun_key = getattr(settings, "mailgun_api_key", "")
    force_delivery = os.environ.get("SPAPS_FORCE_EMAIL_DELIVERY", "").lower() == "true"
    if mailgun_key and not force_delivery:
        violations.append(
            "MAILGUN_API_KEY is set in non-production — "
            "remove it to prevent sending real emails"
        )
    elif mailgun_key and force_delivery:
        logger.warning(
            "mailgun_api_key_allowed_by_force_flag",
            detail=(
                "MAILGUN_API_KEY is set in non-production but "
                "SPAPS_FORCE_EMAIL_DELIVERY=true — real emails will be sent. "
                "Ensure DEV_EMAIL_OVERRIDE_TO is configured in consuming services."
            ),
        )

    # 2. No real Stripe charges in dev
    # Only sk_test_* keys allowed in non-production.
    stripe_key = getattr(settings, "stripe_secret_key", "")
    if stripe_key and stripe_key.startswith("sk_live_"):
        violations.append(
            "STRIPE_SECRET_KEY is a live key (sk_live_*) in non-production — "
            "use a test key (sk_test_*)"
        )

    # 3. No real webhook deliveries — checked at delivery time, not startup.
    # (Webhook URL scrubbing is handled by the transform script.)

    # 4. No real QuickBooks/CFO API calls in dev (unless explicitly allowed)
    quickbooks_id = getattr(settings, "quickbooks_client_id", "")
    quickbooks_secret = getattr(settings, "quickbooks_client_secret", "")
    allow_quickbooks_nonprod = (
        os.environ.get("SPAPS_ALLOW_QUICKBOOKS_IN_NON_PRODUCTION", "").lower() == "true"
    )
    if quickbooks_id and quickbooks_secret:
        if allow_quickbooks_nonprod:
            logger.warning(
                "quickbooks_credentials_allowed_by_force_flag",
                detail=(
                    "QUICKBOOKS_CLIENT_ID/SECRET are set in non-production and "
                    "SPAPS_ALLOW_QUICKBOOKS_IN_NON_PRODUCTION=true. Use sandbox "
                    "credentials only."
                ),
            )
        else:
            # If both are set, this looks like a real QB integration attempt in dev.
            # Production uses specific client IDs; dev should use sandbox or nothing.
            violations.append(
                "QUICKBOOKS_CLIENT_ID and QUICKBOOKS_CLIENT_SECRET are both set in "
                "non-production — use a QuickBooks sandbox app or leave unset"
            )

    # 5. No real blockchain interactions in dev
    solana_url = getattr(settings, "solana_rpc_url", "")
    if solana_url and "mainnet" in solana_url.lower():
        violations.append(
            "SOLANA_RPC_URL points at mainnet in non-production — "
            "use devnet (https://api.devnet.solana.com)"
        )

    ethereum_url = getattr(settings, "ethereum_rpc_url", "")
    if ethereum_url and "mainnet" in ethereum_url.lower():
        violations.append(
            "ETHEREUM_RPC_URL points at mainnet in non-production — "
            "use a testnet RPC"
        )

    lightning_host = getattr(settings, "lightning_grpc_host", "")
    if lightning_host and lightning_host not in ("", "localhost", "127.0.0.1"):
        # Non-empty, non-localhost Lightning host in dev is suspicious
        violations.append(
            "LIGHTNING_GRPC_HOST is set to a non-localhost value in non-production — "
            "ensure this is not the production Lightning node"
        )

    # Shared: resolve host binding for warnings 6 and 7
    host = getattr(settings, "host", "127.0.0.1")

    # 6. PII data in dev — warn if same master key might be used
    # Using the same SPAPS_PII_MASTER_KEY in dev means production encrypted data
    # can be decrypted. This is acceptable for compat testing but risky if dev
    # is network-accessible. Warn rather than refuse — Phase 7 may tighten this.
    pii_key = getattr(settings, "spaps_pii_master_key", "")
    if pii_key and host == "0.0.0.0":
        logger.warning(
            "pii_key_network_exposure_risk",
            detail=(
                "SPAPS_PII_MASTER_KEY is set and server binds to 0.0.0.0 in "
                "non-production. If this key matches production, encrypted PII "
                "can be decrypted. Ensure this server is not network-accessible."
            ),
        )

    # 7. JWT secret isolation — warn (not fatal) if binding to 0.0.0.0
    # This is a warning because dev legitimately uses the same JWT_SECRET for
    # compat testing, but the server must not be network-accessible.
    jwt_secret = getattr(settings, "jwt_secret", "")
    if jwt_secret and host == "0.0.0.0":
        logger.warning(
            "jwt_secret_network_exposure_risk",
            detail=(
                "JWT_SECRET is set and server binds to 0.0.0.0 in non-production. "
                "Dev-issued tokens are valid in production. Ensure this server is "
                "not network-accessible."
            ),
        )

    if violations:
        raise EnvironmentSafetyError(
            f"Refusing to start: {len(violations)} safety violation(s) in "
            f"non-production environment ({env}):\n"
            + "\n".join(f"  - {v}" for v in violations)
        )


def log_startup_config(settings: "BaseServiceSettings") -> None:
    """
    Log configuration summary at startup with masked secrets.

    Provides visibility into what configuration the service is running with,
    while ensuring sensitive values (like passwords) are not exposed in logs.
    """
    db_display = _mask_database_url(settings.database_url)
    version = os.environ.get("GIT_COMMIT_SHA", settings.version)

    logger.info(
        "startup_config",
        app_name=settings.app_name,
        version=version,
        environment=settings.env,
        auth_enabled=settings.spaps_auth_enabled,
        database=db_display,
        cors_origins_count=len(settings.cors_allow_origins),
        debug=settings.debug,
        log_level=settings.log_level,
    )


def _mask_database_url(url: str | None) -> str:
    """
    Mask password in database URL for safe logging.

    Handles standard PostgreSQL connection strings:
        postgresql+asyncpg://user:password@host:port/dbname
        postgresql+psycopg://user:password@host:port/dbname

    Args:
        url: Database connection URL or None.

    Returns:
        Masked URL safe for logging, or placeholder if not set.
    """
    if not url:
        return "<not set>"

    # Match PostgreSQL URLs with password
    # postgresql+driver://user:password@host:port/dbname
    match = re.match(
        r"(postgresql(?:\+\w+)?://)([^:]+):([^@]+)@(.+)",
        url,
    )
    if match:
        prefix, user, _password, rest = match.groups()
        return f"{prefix}{user}:****@{rest}"

    # Fallback: truncate unrecognized formats
    if len(url) > 30:
        return url[:30] + "..."
    return url
