# Feature Plan Index

This index is the canonical entrypoint for Python server feature-slice planning in this repo.

Only slice folders under this directory should be treated as tracked feature plans during audits.

## Active Feature Slices

| Status | Slice | Scope | Notes |
| --- | --- | --- | --- |
| PLANNED | [trust-invariants-kernel](./trust-invariants-kernel/README.md) | Request principal, scope rules, secret redaction, and truthful JSON contract enforcement in the active FastAPI runtime | Narrow follow-on slice that supersedes the "already compliant" trust-boundary assumptions in `security-audit-remediation-2026q1`. |
| DONE | [security-audit-remediation-2026q1](./security-audit-remediation-2026q1/README.md) | `TM-002`, `TM-007`, `TM-008`, `TM-009`, `TM-010`, `TM-011`, `TM-013` | Audit-validated in `AUDIT_REPORT.md`; implemented in the active Python/FastAPI runtime. |

## Notes

These documents are useful context, but they are not tracked feature slices and should not be prioritized as active backlog without an explicit promotion into this directory.

| Type | Document | Notes |
| --- | --- | --- |
| Concept note | [messaging-broker-plan](../messaging-broker-plan.md) | Reference-only note; not active backlog. |

## Archived / Out-of-Scope Plans

Archived plan documents are kept under [`./_archived/`](./_archived/) when they should remain in the repo for reference but must not be treated as active feature work.
