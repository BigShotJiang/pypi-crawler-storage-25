# Flows: `trust_invariants_kernel`

## Flow 1: Authenticated Request Through The Kernel

1. Request enters the FastAPI app.
2. Kernel resolves effective client IP using trusted proxy rules.
3. Kernel resolves API key/application context and stores the principal on `request.state`.
4. JWT-aware dependency enriches the same principal with user identity and roles.
5. Rate limiting, scope checks, and business logic all read from the same principal.
6. Response leaves through the declared JSON contract path:
   - enveloped JSON, or
   - explicit passthrough

## Flow 2: Self-Scoped Audit Read

1. Admin calls `GET /api/audit/logs`.
2. Principal resolves authenticated admin and application scope.
3. Self-scope invariant ignores caller attempts to widen scope with `admin_user_id`.
4. Repository query filters to the authenticated admin only.
5. Response returns envelope-wrapped audit data for that admin.

## Flow 3: Operator-Scoped Audit Read

1. Super-admin calls `GET /api/audit/all-logs`.
2. Principal resolves admin identity and roles.
3. Operator-scope invariant allows optional `admin_user_id` filter.
4. Repository query applies requested admin filter if present.
5. Response returns envelope-wrapped data under operator rules.

## Flow 4: Webhook Create With Bootstrap Secret

1. Caller posts webhook registration request.
2. Service validates URL and event types.
3. Service generates a signing secret and persists it.
4. Response returns:
   - redacted webhook object
   - one-time `bootstrap_secret`
5. Future list/read/update calls return only the redacted webhook object.

## Flow 5: Application Key Rotation

1. Super-admin calls `POST /api/admin/rotate-api-key/{id}`.
2. Service determines which credential type is supported by the active runtime policy.
3. Service persists hashes on the matching validation path.
4. Response returns a credential that can authenticate immediately, or a deterministic error if that route is no longer valid.

## Flow 6: Security Alert Read By Application Scope

1. Security-relevant event is created with `application_id`.
2. Admin calls `GET /api/security/alerts` or `/api/security/summary`.
3. Principal resolves active application scope.
4. Query filters by `application_id`.
5. Response excludes alerts from other applications.

## Flow 7: Trustworthy JSON Contract

1. Route declares whether it is `enveloped_json` or `passthrough_json`.
2. Middleware/runtime follows that declaration.
3. OpenAPI and manifest generation use the same declaration.
4. Client tests verify the documented JSON shape matches live behavior.
