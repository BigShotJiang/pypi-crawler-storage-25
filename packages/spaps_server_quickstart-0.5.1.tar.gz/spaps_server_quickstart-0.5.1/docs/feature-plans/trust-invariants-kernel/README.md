# Trust Invariants Kernel Plan

This folder contains a domain-planner style slice for consolidating trust-boundary rules in the active SPAPS Python runtime.

## Scope

- Active stack only: `packages/python-server-quickstart/` (FastAPI/Python)
- Explicitly out of scope: deprecated Node/Express runtime under `src/`
- Focus: one request principal, one set of scope rules, one secret-exposure policy, and one truthful JSON contract model

## Why This Slice Exists

The previous security remediation slice marked several trust-model items as complete, but the live code still allows drift between:

- API key rotation and API key validation
- route-level scope intent and repository filtering
- secret-bearing models and normal read responses
- runtime JSON envelopes and generated OpenAPI/client contracts
- trusted proxy IP resolution and rate-limit identity

This slice addresses that drift by introducing an executable kernel instead of more one-off fixes.

## Plan Artifacts

- `plan.md`: strategy, landscape, user stories, and tradeoffs
- `shared.md`: locked contract deltas and runtime trust contract
- `backend.md`: backend rules, migrations, and TDD matrix
- `frontend.md`: API-only downstream consumer impact
- `flows.md`: critical request, rotation, and redaction flows
- `schema.mmd`: conceptual ERD for trust-boundary entities

## Suggested Execution Order

1. Principal and proxy-trust kernel
2. Scope-rule consolidation for audit and security surfaces
3. Secret write-only policy for webhook and credential surfaces
4. Truthful envelope/OpenAPI/manifest contract alignment
5. Describe packets for each implementation wave
