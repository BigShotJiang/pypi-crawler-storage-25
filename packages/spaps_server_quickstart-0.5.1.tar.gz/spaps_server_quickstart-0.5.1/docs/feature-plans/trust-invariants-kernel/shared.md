# Shared Contract: `trust_invariants_kernel`

## Contract Status

`DRAFT` (planning baseline, 2026-04-03)

This slice narrows and corrects trust-boundary behavior in existing endpoints. It does not add broad new product APIs.

## Global JSON Contract

### Envelope Rule

All JSON endpoints are in exactly one of these categories:

1. `enveloped_json`
   - Runtime response body is:

```json
{
  "success": true,
  "data": {},
  "error": null,
  "metadata": {
    "timestamp": "ISO8601",
    "request_id": "uuid"
  }
}
```

2. `passthrough_json`
   - The route is explicitly registered as passthrough and documented that way.

No JSON endpoint may silently return one shape while OpenAPI documents another.

## Shared Runtime Trust Contract

Every authenticated request resolves one principal with these fields before business logic:

- `application_id`
- `key_type`
- `user_id` when JWT-authenticated
- `roles`
- `client_ip`
- `request_id`
- `scope_class`

The principal is the source of truth for:

- rate-limit identity
- app/user binding checks
- self-scope versus operator-scope decisions
- audit and security event context

## Endpoint Behavior Deltas

### 1) Admin Credential Rotation

| Endpoint | Contract |
| --- | --- |
| `POST /api/admin/rotate-api-key/{id}` | Returns `{ api_key, key_type, warning }`, where `api_key` can authenticate immediately under the active runtime policy and `key_type` declares the credential class that was issued. The route must not issue a dead-on-arrival key. |

Notes:

- If the runtime still supports legacy credentials, the returned credential may be legacy.
- If the runtime no longer supports legacy credentials, the route must issue a supported secret credential or fail with an explicit error instead of returning an unusable value.

### 2) Webhook Secret Exposure

| Endpoint | Contract |
| --- | --- |
| `GET /api/webhooks` | Returns redacted webhook objects only; no raw signing secret |
| `POST /api/webhooks` | Returns `{ webhook, bootstrap_secret, message }`, where `webhook` is redacted and `bootstrap_secret` is one-time initialization data |
| `PUT /api/webhooks/{webhook_id}` | Returns redacted webhook object only |

Notes:

- Stored webhook signing secrets remain internal delivery-only data.
- A future explicit rotate-secret endpoint may return a new bootstrap secret once, but normal reads never do.

### 3) Audit Scope Rules

| Endpoint | Scope Contract |
| --- | --- |
| `GET /api/audit/logs` | Self-scoped to the authenticated admin. Caller-controlled widening is not allowed. |
| `GET /api/audit/all-logs` | Operator-scoped surface for super admins; optional `admin_user_id` filter allowed. |

### 4) Security Alert Scope Rules

| Endpoint | Scope Contract |
| --- | --- |
| `GET /api/security/alerts` | Returns only alerts for the active application scope. |
| `GET /api/security/summary` | Returns only summary data for the active application scope. |

Notes:

- This slice treats `Application` as a real tenant boundary for security alerts.
- Cross-application security operations are out of scope unless an explicit operator-only surface is added later.

### 5) Trusted Proxy Contract

| Surface | Contract |
| --- | --- |
| rate-limit identity | Uses the same trusted-proxy-aware client IP resolver as self-service and other guarded surfaces |
| startup validation | Rejects or warns on invalid trusted proxy configuration before production traffic |

## Error Contract

New or clarified error codes:

- `LEGACY_KEY_ROTATION_UNAVAILABLE` if legacy rotation is no longer supported and no compatible credential can be issued on that route
- existing auth and validation errors remain in the standard envelope

## Compatibility Rules

- Target state is correctness over implicit backward compatibility.
- Contract-affecting changes require synchronized updates to:
  - `docs/manifest.json`
  - `docs/api-reference*`
  - `packages/python-client` shared endpoint tests and docs
- Admin and webhook clients must treat secret bootstrap values as write-once data, not stable read-model fields.
