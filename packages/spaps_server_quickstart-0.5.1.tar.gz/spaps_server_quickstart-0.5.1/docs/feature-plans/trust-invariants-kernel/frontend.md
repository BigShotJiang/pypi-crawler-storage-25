# Frontend Spec: `trust_invariants_kernel`

## Frontend Surface

SPAPS remains API-only for this slice. There is no first-party UI deliverable.

## Downstream Consumer Impact

The slice changes what downstream consumers must trust about shared endpoints and generated clients:

- webhook management responses no longer expose raw signing secrets on read paths
- admin credential rotation returns a supported credential type or fails explicitly
- audit and security readers are more tightly scoped
- OpenAPI and SDKs must describe envelope-wrapped JSON truthfully

## Consumer-Facing Requirements

- `packages/python-client` must reflect the real envelope-wrapped JSON contract for touched endpoints
- docs under `docs/api*` and `docs/manifest.json` must match runtime behavior
- release notes should call out:
  - webhook secrets are now bootstrap-only
  - audit/security reads are more restrictive
  - credential rotation semantics are corrected

## Non-Goals

- No admin console changes
- No dashboard, portal, or widget work
- No new feature flag UI

## Validation

- shared client tests for touched endpoints pass
- generated docs and manifest reflect the same wire contract as the live runtime
