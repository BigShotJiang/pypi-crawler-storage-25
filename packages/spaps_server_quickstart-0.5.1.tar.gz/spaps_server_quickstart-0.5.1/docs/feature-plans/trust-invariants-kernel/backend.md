# Backend Spec: `trust_invariants_kernel`

## Implementation Principles

- Python/FastAPI only (`packages/python-server-quickstart/`)
- TDD first using repo-standard commands
- Keep trust rules centralized and explicit; avoid ad hoc per-route logic when the rule is reusable
- Mock external dependencies and avoid network calls in tests
- Canonical validation commands:
  - `make pytest`
  - `make lint`
  - `make typecheck`
  - `make test`

## Domains In Scope

- `middleware/api_key.py`
- `middleware/spaps_deps.py`
- `middleware/rate_limiting.py`
- `middleware/client_ip.py`
- `middleware/envelope.py`
- `domains/applications/`
- `domains/webhooks/`
- `domains/audit/`
- `domains/security/`
- `docs/manifest.json`
- `packages/python-client/` only where shared endpoint contract changes require parity

## Workstream A: Request Principal Kernel

### Rules

- Resolve one principal object per request before business logic.
- Principal resolution owns effective `client_ip`, `application_id`, `key_type`, optional `user_id`, and request-scoped metadata.
- Middleware and DI must reuse principal state instead of independently repeating database lookups or header parsing.

### Backend Tasks

- Introduce a shared principal resolver module or equivalent kernel surface.
- Move trusted client-IP resolution to the kernel and consume it from rate limiting.
- Reuse application/key metadata from the kernel in `get_application()` where possible to avoid duplicate DB fetches.

### TDD Matrix

- Middleware tests:
  - untrusted peer ignores forged `X-Forwarded-For`
  - trusted proxy chain resolves correct client IP
  - application context is reused instead of queried twice for the same key path
- Dependency tests:
  - local mode still populates compatible request state
  - JWT app-binding still enforces app match against the resolved principal

## Workstream B: Explicit Scope Rules

### Rules

- Self-scoped endpoints cannot be widened by caller-supplied identifiers.
- Operator-scoped surfaces must be explicit and role-gated.
- `Application` is treated as the tenant boundary for security alert reads.

### Backend Tasks

- Introduce an invariant declaration for self-scoped versus operator-scoped endpoint families.
- Apply self-scope enforcement to audit log reads.
- Add application scoping to security alert persistence and query paths.
- Update admin/security services to consume scope decisions from shared helpers rather than route-local conditionals.

### TDD Matrix

- Router tests:
  - non-super-admin cannot read another admin's audit logs
  - super-admin can still filter `/api/audit/all-logs`
  - security alerts are filtered by active application
- Repository/service tests:
  - security alert creation persists `application_id`
  - security summaries aggregate only within application scope

## Workstream C: Secret Write-Only Policy

### Rules

- Secret-bearing fields are redacted on normal read paths by default.
- Bootstrap secret values may be returned only on explicit create/rotate actions that mint them.
- Credential rotation routes must return immediately usable credentials or fail clearly.

### Backend Tasks

- Split webhook output schemas into redacted read models and bootstrap-secret write models.
- Centralize secret-field redaction helpers for serializer use.
- Repair application key rotation semantics so issued keys match a live validation path.

### TDD Matrix

- Webhook router/service tests:
  - list/create/update responses never expose persisted `secret`
  - create response returns one-time `bootstrap_secret`
- Application tests:
  - rotated credential authenticates on the intended path
  - rotation response includes `key_type` that matches the supported validation path
  - supported secret keys continue to work unchanged

## Workstream D: Truthful JSON Contract

### Rules

- Runtime JSON and declared JSON must match.
- Envelope behavior is either explicit in response schemas or explicitly bypassed.
- Manifest and client parity tests fail on shape drift.

### Backend Tasks

- Add a contract strategy for envelope-wrapped endpoints that OpenAPI can describe truthfully.
- Maintain a single registry for passthrough JSON paths.
- Update representative routes, docs, and client expectations.

### TDD Matrix

- Middleware tests:
  - enveloped JSON responses keep metadata and request IDs
  - passthrough JSON routes remain passthrough only when explicitly declared
- Contract tests:
  - representative route response shape matches documented envelope
  - manifest and client fixtures reflect the envelope

## Migration Plan (Conceptual)

1. Add `application_id` support to `security_alerts`.
2. Backfill existing security alerts where the application can be inferred safely; otherwise mark as operator-review-only legacy rows.
3. Land request-principal kernel and consume it in rate limiting and DI.
4. Land secret redaction and credential rotation repairs.
5. Update docs, manifest, and shared client tests after runtime behavior is truthful.

## Verification And Release Gates

- `make pytest`
- `make lint`
- `make typecheck`
- `make test`
- contract parity updates in:
  - `docs/manifest.json`
  - `docs/api-reference*`
  - `packages/python-client/`
- no remaining trust-boundary contradictions between this slice and live code on the representative surfaces:
  - audit
  - security alerts
  - webhook secrets
  - credential rotation
  - rate-limit client IP
  - envelope/OpenAPI truthfulness
