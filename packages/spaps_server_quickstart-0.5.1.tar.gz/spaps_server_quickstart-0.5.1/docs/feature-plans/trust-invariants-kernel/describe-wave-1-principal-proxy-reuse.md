# Describe: Principal Kernel Reuses Trusted Proxy Resolution And Auth Context

## Context

- **Type:** bug-fix
- **Affected:** `packages/python-server-quickstart/src/spaps_server_quickstart/middleware/rate_limiting.py:123`, `packages/python-server-quickstart/src/spaps_server_quickstart/middleware/client_ip.py:41`, `packages/python-server-quickstart/src/spaps_server_quickstart/middleware/spaps_deps.py:42`, `packages/python-server-quickstart/tests/middleware/test_rate_limiting.py:510`, `packages/python-server-quickstart/tests/middleware/test_client_ip.py:25`
- **Current behavior:** rate limiting uses its own raw `X-Forwarded-For` parser and can key login/refresh traffic by a spoofable header path; middleware also performs an API-key lookup before dependency injection, then `get_application()` validates the same key again instead of reusing request state.
- **Desired behavior:** rate limiting and dependency injection share one trusted-proxy-aware client IP and one pre-resolved application/auth context; spoofed forwarded headers from untrusted peers are ignored, and a request with pre-resolved application state does not perform a second key validation lookup.
- **Root cause:** `rate_limiting.py` duplicates trust-boundary logic in `_get_real_client_ip()` and only stores partial request state (`application_id`), while `get_application()` always runs its own validation path instead of reusing a previously resolved application object.

## Test Cases

### TC-1: Untrusted peer cannot spoof login rate-limit IP
- **Given:** a `POST /api/auth/login` request with `request.client.host = "198.51.100.99"`, header `x-forwarded-for: "203.0.113.42, 10.0.0.5"`, `trusted_proxy_cidrs = ["10.0.0.0/8"]`, and no `request.state.application_id`
- **When:** the rate-limit key is resolved for the request
- **Then:** the key is `ip:198.51.100.99`, not `ip:203.0.113.42`, and the request is not treated as loopback-exempt
- **Type:** error

### TC-2: Trusted proxy chain resolves the correct client hop
- **Given:** a `POST /api/auth/refresh` request with `request.client.host = "10.0.0.5"`, header `x-forwarded-for: "203.0.113.42, 10.0.0.6"`, and `trusted_proxy_cidrs = ["10.0.0.0/8"]`
- **When:** the effective client IP and rate-limit key are resolved
- **Then:** the effective client IP is `203.0.113.42` and the rate-limit key is `ip:203.0.113.42`
- **Type:** happy

### TC-3: Pre-resolved application is reused by `get_application()`
- **Given:** a request whose state already contains `application.id = "11111111-1111-4111-8111-111111111111"`, `application_id = "11111111-1111-4111-8111-111111111111"`, and `key_type = "secret"`
- **When:** `get_application()` runs later in the same request lifecycle
- **Then:** it returns the pre-resolved application object and does not call `validate_api_key()` again
- **Type:** happy

### TC-4: Local mode remains compatible with the shared principal path
- **Given:** `settings.is_spaps_local_mode = True` for a request to `/api/auth/magic-link`
- **When:** rate-limit context population and `get_application()` both run
- **Then:** the request is exempt from rate limiting, `request.state.is_local_mode` is `True`, and `get_application()` returns `LOCAL_APPLICATION` without database validation
- **Type:** regression

### TC-5: Missing client address falls back to the shared unknown bucket
- **Given:** a `POST /api/auth/refresh` request with no `request.client`, no `X-Forwarded-For`, and no `request.state.application_id`
- **When:** the rate-limit key is resolved
- **Then:** the key is `ip:unknown` and the request is not treated as loopback-exempt
- **Type:** edge

## Validation Commands

- `make pytest`
- `make lint`
- `make typecheck`

## Open Decisions

- None

## Coverage

- Happy paths: 2
- Error cases: 1
- Regression guards: 1
- Edge cases: 1
- Total: 5

## Underlying Ask

- Fix the trusted-proxy and duplicate-auth-resolution drift in the first kernel wave, because every later scope or secret rule assumes the request already has trustworthy principal state.

## Spec Review

- Holds: the packet is narrow, targets the critical-path trust bug, and names concrete state that later waves can reuse.
- Missing or risky cases: none that block wave 1; webhook secrets, audit scope, and envelope/OpenAPI truth remain intentionally deferred to later describe packets.

## Decisions Needed

- None

## Non-Goals

- Webhook secret redaction
- Audit or security endpoint scoping
- Admin key rotation semantics
- Envelope/OpenAPI contract alignment
