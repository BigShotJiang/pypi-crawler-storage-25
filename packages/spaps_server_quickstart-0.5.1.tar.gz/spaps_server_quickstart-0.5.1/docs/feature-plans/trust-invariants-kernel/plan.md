# Slice: `trust_invariants_kernel`

## Business Value

Replace scattered trust-boundary conventions with one executable kernel so SPAPS resolves caller identity, scope, secret exposure, and JSON response shape consistently across domains.

## Scope

- Codebase: `packages/python-server-quickstart/` only
- Runtime surfaces:
  - `middleware/api_key.py`
  - `middleware/spaps_deps.py`
  - `middleware/rate_limiting.py`
  - `middleware/client_ip.py`
  - `middleware/envelope.py`
  - `domains/applications/`
  - `domains/webhooks/`
  - `domains/audit/`
  - `domains/security/`
- Contract surfaces:
  - `docs/manifest.json`
  - `docs/api-reference*`
  - `packages/python-client/` for shared endpoint parity

## Out Of Scope

- New product features unrelated to trust boundaries
- Replacing router -> service -> repository layering
- Full RBAC redesign or new operator UI
- A brand-new API credential store beyond the current application credential columns
- Deprecated Node/Express runtime under `/src`

## Phase 0 Landscape

**Domain cluster:** `[security] [auth] [api-contract]`

**Sibling slice:** `security-audit-remediation-2026q1`

**Existing entities nearby:**

- `Application`
- `Webhook`
- `AuditLog`
- `SecurityAlert`
- `SecureMessage`
- response envelope middleware

**Existing patterns to reuse:**

- `issue_reporting_platform` already enforces application-bound caller scope
- `support_telemetry_platform` already redacts payload fields before persistence
- `self_service` already uses `resolve_client_ip()` instead of parsing raw headers directly

**Potential conflicts:**

- `security-audit-remediation-2026q1/AUDIT_REPORT.md` claims compliance for items the live code still violates
- existing response models document raw payloads even though middleware wraps them in an envelope
- admin and security readers do not consistently encode self-scope versus operator-scope rules

## Core Value Gate

- Primary actor: SPAPS operator maintaining a shared multi-tenant auth and payments service
- User-visible outcome: a caller cannot gain broader access, receive a leaked secret, or observe a different JSON shape than the runtime contract allows
- Minimum winning slice: one resolved request principal plus one invariant layer reused by auth, rate limiting, scope checks, secret-bearing serializers, and contract generation
- Explicit non-goals:
  - policy-engine generalization for every domain
  - broad admin UX improvements
  - tenant-configurable rule builders
  - full credential-store redesign
  - historical backfill for unrelated domains
- Debt avoided by deferring them:
  - avoids turning a trust-correctness slice into a full authorization platform rewrite
  - avoids schema churn for credentials unrelated to the current failures
  - avoids frontend/admin coordination before the backend contract is truthful

## Phase 1 Discovery

### User Story 1

As a SPAPS operator, I need one resolved request principal so middleware, dependencies, and services all use the same application, user, key type, and client IP facts.

Acceptance criteria:

- Every authenticated request resolves a single principal object before business logic.
- Rate limiting, dependency injection, and scope guards reuse that principal instead of re-querying or re-parsing independently.
- Trusted proxy configuration is the only source of truth for effective client IP.

Test scenarios:

- Happy path: secret-key request behind a trusted proxy yields one principal with the correct `application_id`, `key_type`, `user_id`, and client IP.
- Error path: untrusted peer with forged `X-Forwarded-For` is keyed and logged by peer IP, not spoofed header IP.
- Regression: local-development mode still bypasses SPAPS auth without breaking test helpers.

### User Story 2

As an admin, I need self-scoped admin read paths to stay self-scoped unless a route is explicitly marked as operator scope.

Acceptance criteria:

- `/api/audit/logs` cannot widen access via `admin_user_id` for a normal admin.
- `/api/audit/all-logs` remains the only route that can query another admin's audit trail.
- security alert readers are scoped to the active application unless a future operator-only surface says otherwise.

Test scenarios:

- Happy path: an admin reads only their own audit logs.
- Error path: the same admin cannot read another admin's logs by supplying `admin_user_id`.
- Regression: super-admin queries on `/api/audit/all-logs` still support `admin_user_id` filters.
- Edge: security alerts created for application A do not appear when an admin from application B queries `/api/security/alerts`.

### User Story 3

As an application integrator, I need secret-bearing resources to be write-only by default so routine list and update calls never leak reusable credentials.

Acceptance criteria:

- Webhook list, read, create, and update responses do not include persisted signing secrets.
- Create flows can return a bootstrap secret once when that is the only way to initialize the integration.
- Credential rotation routes return a credential that can authenticate immediately under the active runtime policy, plus an explicit `key_type` describing what was issued.

Test scenarios:

- Happy path: `POST /api/webhooks` returns `bootstrap_secret` once and a redacted webhook object.
- Error path: `GET /api/webhooks` never includes webhook secrets.
- Regression: existing webhook delivery signing still uses the stored secret internally.
- Regression: rotated application keys authenticate on the same request path they were issued for, and the response `key_type` matches the live validation path.

### User Story 4

As an SDK consumer, I need OpenAPI and generated clients to describe the JSON I actually receive so integrations are built against the real wire contract.

Acceptance criteria:

- Envelope-wrapped JSON endpoints are documented as envelope-wrapped in OpenAPI and manifest artifacts.
- Endpoints that intentionally bypass the envelope are explicitly marked and excluded.
- Shared docs and client tests fail if runtime JSON and declared schemas diverge.

Test scenarios:

- Happy path: a representative JSON endpoint documents `{success,data,error,metadata}` and returns that shape at runtime.
- Error path: a non-enveloped route is explicitly registered as passthrough instead of silently drifting.
- Regression: HTML, docs, metrics, and other passthrough surfaces remain unchanged.

### User Story 5

As a security reviewer, I need the trust boundary to be auditable from code and tests, not only from prose claims, so "compliant" slices cannot drift silently.

Acceptance criteria:

- The kernel declares which endpoints are self-scoped, operator-scoped, or secret-writing.
- The test suite includes contract tests for at least one route in each invariant category.
- The feature-plan index and remediation notes clearly state that this slice supersedes prior blanket compliance claims for these surfaces.

Test scenarios:

- Happy path: invariant metadata exists for audit, security, webhook, and admin key-rotation surfaces.
- Regression: adding a new scoped route without invariant metadata fails a contract test or review gate.

## Phase 5 Strategy

### Tradeoffs

| Decision | Chosen | Alternative(s) | Why Not |
| --- | --- | --- | --- |
| Request identity model | Resolve one principal object early and reuse it | Keep independent resolution in middleware and DI | Current drift already caused inconsistent auth, rate limiting, and scope behavior |
| Scope expression | Explicit self-scope and operator-scope invariants per endpoint family | Infer scope from query params or repository calls | Inference is how `/audit/logs` drifted into cross-admin reads |
| Secret exposure policy | Write-only by default, bootstrap-only returns when necessary | Let each serializer decide ad hoc | Ad hoc serialization already leaked webhook secrets |
| JSON contract truth | Make OpenAPI/manifest describe the envelope actually returned | Keep raw response models and rely on docs prose | Generated clients and consumers need machine-readable truth |
| Credential repair scope | Fix current rotation semantics without a full credential-store rewrite | Build a new multi-key registry immediately | Useful eventually, but it would slow down the minimum winning slice materially |

### Rejected Approaches

- Patch only the seven currently known issues with no shared invariant layer.
  - Rejected because the existing code already demonstrates that point fixes drift back apart.
- Treat this as only a documentation problem.
  - Rejected because the live runtime and the docs disagree in security-critical ways.
- Fold the work back into `security-audit-remediation-2026q1`.
  - Rejected because that slice is already marked `DONE`; a separate slice makes the contradiction explicit and reviewable.

### Out-of-Scope Follow-Ons

- Dedicated API credential inventory table and key IDs
- Wider policy-engine adoption across all domains
- Operator-facing trust-rule admin surface
- Full retrospective audit of every existing domain beyond the representative invariant families in this slice

## Global Definition Of Done

- One request-principal path is used by API key auth, JWT binding, rate limiting, and scope guards.
- Audit and security readers enforce the intended tenant/admin boundaries.
- Secret-bearing webhook and credential surfaces no longer leak reusable secrets on normal reads.
- OpenAPI, `docs/manifest.json`, and shared client tests match the real envelope-wrapped JSON contract.
- The slice replaces prior blanket compliance claims for these surfaces with executable tests and updated documentation.

## Handoff

- First implementation wave should be driven by `describe` packets:
  - principal + trusted proxy reuse
  - audit/security scope rules
  - webhook/credential secret policy
  - truthful envelope/OpenAPI parity
- After implementation, rerun security review against this slice rather than inheriting the previous audit verdict.
