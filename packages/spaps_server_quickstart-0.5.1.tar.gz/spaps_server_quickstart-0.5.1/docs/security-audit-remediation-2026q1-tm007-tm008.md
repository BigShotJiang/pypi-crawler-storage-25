# Security Audit Remediation: TM-007 & TM-008 Implementation

**Date:** 2026-02-13
**Status:** Implemented
**Scope:** TM-007 (Webhook Destination Governance), TM-008 (Self-Service Network Boundary)

## Summary

Implemented security enhancements for TM-007 and TM-008, plus added ALL feature flags for the entire security remediation plan to `spaps_settings.py`.

## Changes

### 1. Feature Flags Added to `spaps_settings.py`

Added **ALL** security audit remediation feature flags:

```python
# TM-013: Secure messages JWT requirement
secure_messages_require_jwt: bool = True

# TM-011: Refresh token anomaly enforcement
refresh_anomaly_enforcement_enabled: bool = False

# TM-007: Webhook destination governance policy mode
webhook_destination_policy_mode: str = "off"

# TM-007: Webhook allowed domains (for allowlist mode)
webhook_allowed_domains: list[str] = []

# TM-010: Rate limit backend
rate_limit_backend: str = "memory"

# TM-008: Self-service allowed IPs
self_service_allowed_ips: list[str] = []
```

### 2. TM-008: Self-Service Network Boundary

**New Error Code:**
- `SELF_SERVICE_NETWORK_RESTRICTED` (403)

**Implementation:**
- Added `domains/self_service/errors.py` with `SelfServiceNetworkRestrictedError`
- Added network boundary check in `domains/self_service/router.py`
- Network boundary enforced BEFORE authentication on all endpoints
- Backward compatible: empty allowlist = no restriction

**Behavior:**
- When `self_service_allowed_ips` is empty (default): no restriction, all IPs allowed
- When `self_service_allowed_ips` is configured: only listed IPs can access
- Ignores `X-Forwarded-For` unless the immediate peer is in `TRUSTED_PROXY_CIDRS`
- When the peer is trusted, resolves the client IP by walking the forwarded chain from the right
- Emits structured security events on denied access

**Tests Added:**
- `TestNetworkBoundary::test_empty_allowlist_allows_all_ips`
- `TestNetworkBoundary::test_allowlisted_ip_can_access`
- `TestNetworkBoundary::test_non_allowlisted_ip_denied`
- `TestNetworkBoundary::test_spoofed_forwarded_for_denied_without_trusted_proxy`
- `TestNetworkBoundary::test_trusted_proxy_can_forward_allowlisted_client_ip`
- `TestNetworkBoundary::test_network_boundary_applies_to_all_endpoints`

### 3. TM-007: Webhook Destination Governance

**New Error Code:**
- `WEBHOOK_DESTINATION_UNVERIFIED` (403) - for future verify mode

**Implementation:**
- Wired settings integration in `domains/webhooks/router.py`
- Router now reads `webhook_destination_policy_mode` and `webhook_allowed_domains` from settings
- Service layer already had governance logic, just needed settings wiring
- Applies to both `create_webhook` and `update_webhook`

**Modes:**
- `off` (default): No governance, all domains allowed
- `allowlist`: Only domains in `webhook_allowed_domains` permitted
  - Exact domain matches
  - Subdomain matching (e.g., api.example.com matches example.com)
  - Empty allowlist = deny all

**Tests Added:**
- `TestWebhookDestinationGovernance::test_policy_off_allows_any_domain`
- `TestWebhookDestinationGovernance::test_allowlist_mode_allows_exact_domain`
- `TestWebhookDestinationGovernance::test_allowlist_mode_allows_subdomain`
- `TestWebhookDestinationGovernance::test_allowlist_mode_denies_non_allowed_domain`
- `TestWebhookDestinationGovernance::test_allowlist_mode_with_empty_allowlist_denies_all`
- `TestWebhookDestinationGovernance::test_update_webhook_enforces_governance`
- `TestWebhookDestinationGovernance::test_update_webhook_skips_governance_when_url_not_changed`

## Test Results

All tests passing:
- Self-service domain: 46 tests passed
- Webhooks domain: 175 tests passed (all domains/webhooks tests)

## Deployment Configuration

### Development/Staging

```bash
# .env
SELF_SERVICE_ALLOWED_IPS=[]  # Empty = no restriction
TRUSTED_PROXY_CIDRS=[]       # Empty = ignore X-Forwarded-For
WEBHOOK_DESTINATION_POLICY_MODE=off
```

### Production

```bash
# .env
SELF_SERVICE_ALLOWED_IPS=["YOUR_ADMIN_IP_1", "YOUR_ADMIN_IP_2"]
TRUSTED_PROXY_CIDRS=["10.0.0.0/8"]  # Only if self-service sits behind trusted proxies
WEBHOOK_DESTINATION_POLICY_MODE=allowlist
WEBHOOK_ALLOWED_DOMAINS=["example.com", "partner-api.com"]
```

## Security Event Logging

Both features emit structured security events on denied access:

**TM-008 Event:**
```python
{
    "event": "self_service_network_denied",
    "threat_id": "TM-008",
    "client_ip": "...",
    "allowed_ips": [...],
    "path": "..."
}
```

**TM-007 Event:**
```python
{
    "event": "webhook_destination_denied",
    "threat_id": "TM-007",
    "destination": "...",
    "policy_mode": "allowlist",
    "allowed_domains": [...],
    "reason": "not_in_allowlist"
}
```

## Files Modified

- `src/spaps_server_quickstart/spaps_settings.py` - Added ALL feature flags
- `src/spaps_server_quickstart/domains/self_service/errors.py` - NEW: TM-008 error
- `src/spaps_server_quickstart/domains/self_service/router.py` - Network boundary enforcement
- `src/spaps_server_quickstart/domains/webhooks/errors.py` - TM-007 error codes
- `src/spaps_server_quickstart/domains/webhooks/router.py` - Settings integration
- `tests/domains/self_service/test_router.py` - TM-008 tests
- `tests/domains/webhooks/test_service.py` - TM-007 tests

## Next Steps

Other workstreams (TM-002, TM-009, TM-010, TM-011, TM-013) can now reference the feature flags in `spaps_settings.py`.
