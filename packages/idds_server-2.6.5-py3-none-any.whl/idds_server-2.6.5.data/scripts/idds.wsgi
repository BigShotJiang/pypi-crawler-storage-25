#!python
#
# Licensed under the Apache License, Version 2.0 (the "License");
# You may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0OA
#
# Authors:
# - Wen Guan, <wen.guan@cern.ch>, 2019

"""----------------------
   Web service startup
----------------------"""

import os
import sys

# If IDDS_CONFIG is not already set, default to <prefix>/etc/idds/idds.cfg
if "IDDS_CONFIG" not in os.environ:
    os.environ["IDDS_CONFIG"] = os.path.join(sys.prefix, "etc", "idds", "idds.cfg")

from idds.rest.v1.app import create_app  # noqa: E402


application = create_app()
