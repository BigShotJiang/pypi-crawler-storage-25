import logging

from kubepf.cli.main import app

logging.basicConfig()

if __name__ == "__main__":
    app()
