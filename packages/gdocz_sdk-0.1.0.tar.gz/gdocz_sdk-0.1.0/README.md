# Gdocz SDK

Python SDK for OCR processing.

## Install

pip install gdocz-sdk

## Usage

```python
from gdocz_sdk import GdoczaiClient

client = GdoczaiClient(api_key="your_api_key")

result = client.convert("file.pdf")

print(result["markdown"])