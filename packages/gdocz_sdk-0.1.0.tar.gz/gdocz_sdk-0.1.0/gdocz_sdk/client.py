import requests
import os


class GdoczaiClient:

    def __init__(self, api_key, base_url=None):
        if not api_key:
            raise ValueError("API key required")

        self.api_key = api_key
        self.base_url = base_url or os.getenv("GDOCZ_API_URL")

    def convert(self, file_path, mode="chandra", page_range=None):

        if not os.path.exists(file_path):
            raise FileNotFoundError("File not found")

        with open(file_path, "rb") as f:

            files = {
                "file": (os.path.basename(file_path), f)
            }

            data = {
                "model": mode
            }

            if page_range:
                data["page_range"] = page_range

            headers = {
                "X-API-Key": self.api_key
            }

            response = requests.post(
                f"{self.base_url}/ocr/markdown-only",
                files=files,
                data=data,
                headers=headers
            )

        if response.status_code != 200:
            raise Exception(f"API Error: {response.text}")

        return response.json()