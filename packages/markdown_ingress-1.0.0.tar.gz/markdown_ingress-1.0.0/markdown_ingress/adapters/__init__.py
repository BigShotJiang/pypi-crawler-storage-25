"""Infrastructure adapters for MarkDownIngress."""
