"""Normalizing adapters."""
