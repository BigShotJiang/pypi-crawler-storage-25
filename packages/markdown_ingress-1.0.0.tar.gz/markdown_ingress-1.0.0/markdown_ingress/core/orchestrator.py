"""Ingestion orchestration entrypoint for the MarkDownIngress pipeline."""

import time
from typing import Any

from markdown_ingress.config_models import DomainPolicy, IngestConfig
from markdown_ingress.core.document_builder import process_fetched_content
from markdown_ingress.core.hashing import Hasher
from markdown_ingress.core.inflight import (
    InFlightRegistry,
    acquire_inflight,
    await_inflight,
    clone_cached_document,
    inflight_active_count,
    make_request_key,
    release_inflight,
)
from markdown_ingress.core.ingest_stats import (
    record_stage_timing,
    snapshot_ingest_stats,
)
from markdown_ingress.core.ingest_stats import (
    reset_ingest_stats as _reset_ingest_stats,
)
from markdown_ingress.core.interfaces import (
    IExtractor,
    IMarkdownConverter,
    INormalizer,
    ITokenEstimator,
)
from markdown_ingress.core.link_analyzer import LinkAnalyzer
from markdown_ingress.core.metadata_extractor import MetadataExtractor
from markdown_ingress.core.scoring import Scorer
from markdown_ingress.models import FetchResult, SafeDocument


def get_ingest_stats() -> dict[str, Any]:
    """Return aggregate in-process ingestion stats for observability."""
    stats = snapshot_ingest_stats()
    stats["inflight_active"] = inflight_active_count()
    return stats


def reset_ingest_stats() -> None:
    """Reset aggregate in-process ingestion stats."""
    _reset_ingest_stats()


class IngestOrchestrator:
    """
    Orchestrates the web → markdown ingestion pipeline.

    Coordinates fetching, extraction, conversion, and security analysis
    using dependency injection pattern for better testability and maintainability.
    """

    # Dependency-injection constructor keeps pipeline ports explicit for tests.
    def __init__(  # noqa: PLR0913
        self,
        extractor: IExtractor | None = None,
        normalizer: INormalizer | None = None,
        md_converter: IMarkdownConverter | None = None,
        hasher: Hasher | None = None,
        token_estimator: ITokenEstimator | None = None,
        scorer: Scorer | None = None,
        metadata_extractor: MetadataExtractor | None = None,
        link_analyzer: LinkAnalyzer | None = None,
        inflight_registry: InFlightRegistry | None = None,
    ):
        """
        Initialize orchestrator with optional dependency injection.

        Args:
            extractor: HTML content extractor (implements IExtractor)
            normalizer: HTML normalizer (implements INormalizer)
            md_converter: Markdown converter
            hasher: Content hasher
            token_estimator: Token estimator
            scorer: Security scorer
            metadata_extractor: Metadata extractor
            link_analyzer: Link analyzer
        """
        self.extractor = extractor
        self.normalizer = normalizer
        self.md_converter: IMarkdownConverter | None = md_converter
        self.hasher = hasher
        self.token_estimator: ITokenEstimator | None = token_estimator
        self.scorer = scorer
        self.metadata_extractor = metadata_extractor
        self.link_analyzer = link_analyzer
        self._inflight_registry_was_injected = inflight_registry is not None
        self.inflight_registry = inflight_registry or InFlightRegistry()
        if not self._inflight_registry_was_injected:
            self.inflight_registry.start_periodic_cleanup()
        self._default_inflight_registry = (
            self.inflight_registry if not self._inflight_registry_was_injected else None
        )

    @staticmethod
    def make_request_key(
        url: str,
        config: IngestConfig,
        matched_domain_policy: DomainPolicy | None = None,
    ) -> str:
        return make_request_key(url, config, matched_domain_policy)

    def acquire_inflight(self, request_key: str):
        return acquire_inflight(request_key, registry=self.inflight_registry)

    def await_inflight(self, entry, request_key: str):
        return await_inflight(entry, request_key, registry=self.inflight_registry)

    def release_inflight(self, request_key: str, *, document=None, error=None) -> int:
        return release_inflight(
            request_key,
            document=document,
            error=error,
            registry=self.inflight_registry,
        )

    clone_cached_document = staticmethod(clone_cached_document)

    def timed_stage(self, stage: str, fn):
        """Execute a stage and record aggregate timing."""
        started = time.perf_counter()
        try:
            return fn()
        finally:
            duration_ms = (time.perf_counter() - started) * 1000.0
            record_stage_timing(stage, duration_ms)

    def process_fetched_content(
        self,
        fetch_result: FetchResult,
        config: IngestConfig,
        matched_domain_policy: DomainPolicy | None = None,
        operational_flags: list[str] | None = None,
    ) -> SafeDocument:
        """Transform already-fetched HTML into the final SafeDocument."""
        return process_fetched_content(
            self,
            fetch_result,
            config,
            matched_domain_policy=matched_domain_policy,
            operational_flags=operational_flags,
        )
