"""
Tests for plugin system
"""

import sys
import tempfile
from pathlib import Path

import pytest

from markdown_ingress.core.plugin import Plugin, PluginInfo, PluginLoader


class TestPlugin(Plugin):
    """Test plugin implementation"""

    __test__ = False

    def __init__(self):
        super().__init__()
        self.info = PluginInfo(
            name="TestPlugin", version="1.0.0", description="Test plugin for unit tests"
        )

    def get_patterns(self):
        return [r"test pattern 1", r"test pattern 2"]


class AnotherPlugin(Plugin):
    """Another test plugin"""

    def get_patterns(self):
        return [r"another pattern"]


class TestPluginSystem:
    """Test plugin loading and management"""

    def test_load_plugin_instance(self):
        """Load plugin instance directly"""
        loader = PluginLoader()
        plugin = TestPlugin()

        loader.load_plugin(plugin)

        assert "TestPlugin" in loader.plugins
        assert loader.get_plugin("TestPlugin") is plugin

    def test_get_all_patterns(self):
        """Get patterns from multiple plugins"""
        loader = PluginLoader()
        loader.load_plugin(TestPlugin())
        loader.load_plugin(AnotherPlugin())

        patterns = loader.get_all_patterns()

        assert len(patterns) == 3
        pattern_strings = [p for p, _ in patterns]
        assert "test pattern 1" in pattern_strings
        assert "test pattern 2" in pattern_strings
        assert "another pattern" in pattern_strings

    def test_unload_plugin(self):
        """Unload plugin by name"""
        loader = PluginLoader()
        loader.load_plugin(TestPlugin())

        assert "TestPlugin" in loader.plugins

        loader.unload_plugin("TestPlugin")

        assert "TestPlugin" not in loader.plugins

    def test_list_plugins(self):
        """List all loaded plugins"""
        loader = PluginLoader()
        loader.load_plugin(TestPlugin())

        plugins = loader.list_plugins()

        assert len(plugins) == 1
        assert plugins[0].name == "TestPlugin"
        assert plugins[0].version == "1.0.0"

    def test_load_from_directory(self):
        """Load plugins from directory"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a plugin file
            plugin_file = Path(tmpdir) / "my_plugin.py"
            plugin_file.write_text("""
from markdown_ingress.core.plugin import Plugin

class MyCustomPlugin(Plugin):
    def get_patterns(self):
        return ['custom pattern']
""")

            loader = PluginLoader()
            count = loader.load_from_directory(tmpdir)

            assert count == 1
            assert len(loader.plugins) == 1

            patterns = loader.get_all_patterns()
            assert "custom pattern" in [p for p, _ in patterns]

    def test_load_from_directory_is_deterministic_by_filename(self):
        """Load plugins from directory in filename order."""
        with tempfile.TemporaryDirectory() as tmpdir:
            first = Path(tmpdir) / "b_plugin.py"
            second = Path(tmpdir) / "a_plugin.py"
            first.write_text("""
from markdown_ingress.core.plugin import Plugin


class BPlugin(Plugin):
    def get_patterns(self):
        return ['pattern-b']
""".strip())
            second.write_text("""
from markdown_ingress.core.plugin import Plugin


class APlugin(Plugin):
    def get_patterns(self):
        return ['pattern-a']
""".strip())

            loader = PluginLoader()
            count = loader.load_from_directory(tmpdir)

            assert count == 2
            assert [p for p, _ in loader.get_all_patterns()] == ["pattern-a", "pattern-b"]

    def test_load_from_directory_ignores_imported_plugin_subclasses(self, monkeypatch):
        with tempfile.TemporaryDirectory() as tmpdir:
            helper = Path(tmpdir) / "helper_plugin.py"
            main = Path(tmpdir) / "main_plugin.py"
            helper.write_text("""
from markdown_ingress.core.plugin import Plugin, PluginInfo


class ImportedPlugin(Plugin):
    def __init__(self):
        super().__init__()
        self.info = PluginInfo(name="ImportedPlugin", version="1.0.0", description="imported")

    def get_patterns(self):
        return ["imported-pattern"]
""".strip())
            main.write_text("""
from helper_plugin import ImportedPlugin
from markdown_ingress.core.plugin import Plugin, PluginInfo


class RealPlugin(Plugin):
    def __init__(self):
        super().__init__()
        self.info = PluginInfo(name="RealPlugin", version="1.0.0", description="real")

    def get_patterns(self):
        return ["real-pattern"]
""".strip())

            monkeypatch.syspath_prepend(tmpdir)
            sys.modules.pop("helper_plugin", None)

            loader = PluginLoader()
            count = loader.load_from_directory(tmpdir)

            assert count == 2
            assert sorted(loader.plugins) == ["ImportedPlugin", "RealPlugin"]
            assert [p for p, _ in loader.get_all_patterns()] == ["imported-pattern", "real-pattern"]

    def test_load_from_directory_rolls_back_partial_file_load(self, tmp_path):
        plugin_file = tmp_path / "partial_plugin.py"
        rollback_marker = tmp_path / "rolled-back.txt"
        plugin_file.write_text(f"""
from pathlib import Path

from markdown_ingress.core.plugin import Plugin


class AGoodPlugin(Plugin):
    def on_unload(self):
        Path({str(rollback_marker)!r}).write_text("rolled back")

    def get_patterns(self):
        return ["good-pattern"]


class ZBrokenPlugin(Plugin):
    def on_load(self):
        raise RuntimeError("broken plugin")

    def get_patterns(self):
        return ["broken-pattern"]
""".strip())

        loader = PluginLoader()
        count = loader.load_from_directory(str(tmp_path))

        assert count == 0
        assert loader.plugins == {}
        assert rollback_marker.read_text() == "rolled back"

    def test_plugin_already_loaded_error(self):
        """Loading same plugin twice raises error"""
        loader = PluginLoader()
        plugin = TestPlugin()

        loader.load_plugin(plugin)

        with pytest.raises(ValueError, match="already loaded"):
            loader.load_plugin(TestPlugin())  # Same name
