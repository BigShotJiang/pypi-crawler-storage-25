print("""
1. Basic Authentication Simulation
Concept

Authentication Server (AS) verifies the client and gives a session key.

Flow:

Client → AS : Username
AS → Client : Session Key
Client → Server : Message using Session Key
Simple Python Code
import base64

# Database of users
users = {
    "alice": "password123",
    "bob": "mypassword"
}

# Authentication Server
def authenticate(username):
    if username in users:
        session_key = base64.b64encode(username.encode()).decode()
        return session_key
    else:
        return None

# Client
username = input("Enter username: ")

session_key = authenticate(username)

if session_key:
    print("Authentication Successful")
    print("Session Key:", session_key)

    # Client communicating with server
    message = "Hello Server"
    encrypted = base64.b64encode(message.encode()).decode()

    print("Encrypted Message Sent:", encrypted)

    # Server decrypts
    decrypted = base64.b64decode(encrypted.encode()).decode()

    print("Server Received:", decrypted)

else:
    print("Authentication Failed")
2. Ticket Granting Ticket (TGT) Simulation
Concept

Used in Kerberos authentication.

Flow:

Client → AS
AS → Client : TGT
Client → TGS : TGT
TGS → Client : Service Ticket
Client → Server : Service Ticket
Code
import uuid

# Database
users = ["alice", "bob"]

# Authentication Server
def AS(username):
    if username in users:
        tgt = "TGT-" + str(uuid.uuid4())
        return tgt
    return None

# Ticket Granting Server
def TGS(tgt):
    if tgt.startswith("TGT"):
        service_ticket = "SERVICE-" + str(uuid.uuid4())
        return service_ticket
    return None

# Client
username = input("Enter username: ")

print("\nStep 1: Client requests AS")

tgt = AS(username)

if tgt:
    print("Step 2: AS gives TGT")
    print("TGT:", tgt)

    print("\nStep 3: Client sends TGT to TGS")

    service_ticket = TGS(tgt)

    print("Step 4: TGS gives Service Ticket")
    print("Service Ticket:", service_ticket)

    print("\nStep 5: Client accesses Server")

    print("Access Granted")

else:
    print("Authentication Failed")
3. Basic ACL (Access Control List)
Concept

ACL decides which user gets which permission.

Code
acl = {
    "Alice": ["R", "W"],
    "Bob": ["R"],
    "Charlie": ["R", "X"]
}

user = input("Enter user: ")
permission = input("Enter permission: ")

if user in acl:
    if permission in acl[user]:
        print("Access Granted")
    else:
        print("Access Denied")
else:
    print("User Not Found")
4. Menu Driven ACL Management System
Code
acl = {}

while True:
    print("\n1. Add User")
    print("2. Assign Permission")
    print("3. View ACL")
    print("4. Check Access")
    print("5. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        user = input("Enter username: ")

        if user in acl:
            print("User already exists")
        else:
            acl[user] = []
            print("User added")

    elif choice == "2":
        user = input("Enter username: ")

        if user in acl:
            perm = input("Enter permission (R/W/X): ")

            if perm not in acl[user]:
                acl[user].append(perm)

            print("Permission assigned")

        else:
            print("User not found")

    elif choice == "3":
        print("\nACL:")
        for user, perms in acl.items():
            print(user, ":", perms)

    elif choice == "4":
        user = input("Enter username: ")
        perm = input("Enter permission: ")

        if user in acl and perm in acl[user]:
            print("Access Granted")
        else:
            print("Access Denied")

    elif choice == "5":
        break

    else:
        print("Invalid Choice")
5. ACL for Secure Document Access
Code
acl = {
    "report.txt": {
        "Alice": ["R", "W"],
        "Bob": ["R"]
    },

    "accounts.txt": {
        "Admin": ["R", "W", "X"]
    },

    "admin_config.txt": {
        "Admin": ["R", "W", "X"]
    }
}

user = input("Enter user: ")
file = input("Enter file name: ")
operation = input("Enter operation: ")

if file in acl:
    if user in acl[file]:
        if operation in acl[file][user]:
            print("Access Granted")
        else:
            print("Access Denied")
    else:
        print("User has no permissions")
else:
    print("File not found")
6. Access Control Matrix
Concept
User	File1	File2
Alice	R,W	R
Bob	R	X
Code
matrix = {
    "Alice": {
        "File1": ["R", "W"],
        "File2": ["R"]
    },

    "Bob": {
        "File1": ["R"],
        "File2": ["X"]
    }
}

print("Access Control Matrix\n")

for user in matrix:
    print(user, ":", matrix[user])

print("\nCapability List\n")

for user in matrix:
    print(user)

    for file in matrix[user]:
        print(file, "->", matrix[user][file])
7. RSA Implementation
Concept

RSA uses:

Public Key
Private Key

Formula:

c=m
e
modn

Simple RSA Code
# RSA Simple Implementation

p = 3
q = 11

n = p * q
phi = (p - 1) * (q - 1)

e = 7
d = 3

msg = 12

# Encryption
c = (msg ** e) % n
print("Encrypted:", c)

# Decryption
m = (c ** d) % n
print("Decrypted:", m)
8. Digital Signature
Concept

Sender signs using private key.

Receiver verifies using public key.

Code
import hashlib

message = input("Enter message: ")

# Sender side
signature = hashlib.sha256(message.encode()).hexdigest()

print("Digital Signature:", signature)

# Receiver side
received_hash = hashlib.sha256(message.encode()).hexdigest()

if signature == received_hash:
    print("Signature Verified")
else:
    print("Verification Failed")
9. Communication using RSA + Digital Signature
Code
import hashlib

message = input("Enter message: ")

# Digital Signature
signature = hashlib.sha256(message.encode()).hexdigest()

print("Signature:", signature)

# RSA-like encryption
encrypted = ''.join(chr(ord(c) + 2) for c in message)

print("Encrypted Message:", encrypted)

# Receiver decrypts
decrypted = ''.join(chr(ord(c) - 2) for c in encrypted)

print("Decrypted Message:", decrypted)

# Verify signature
new_hash = hashlib.sha256(decrypted.encode()).hexdigest()

if signature == new_hash:
    print("Message Authentic")
else:
    print("Tampered")
10. Shift Cipher (Caesar Cipher)
Code
text = input("Enter text: ")
shift = 3

encrypted = ""

for ch in text:
    encrypted += chr(ord(ch) + shift)

print("Encrypted:", encrypted)

decrypted = ""

for ch in encrypted:
    decrypted += chr(ord(ch) - shift)

print("Decrypted:", decrypted)
11. Monoalphabetic Cipher
Code
alphabet = "abcdefghijklmnopqrstuvwxyz"
key = "qwertyuiopasdfghjklzxcvbnm"

text = input("Enter text: ")

encrypted = ""

for ch in text:
    if ch in alphabet:
        index = alphabet.index(ch)
        encrypted += key[index]
    else:
        encrypted += ch

print("Encrypted:", encrypted)
12. Playfair Cipher
Concept

Uses 5×5 matrix.

Rules:

J = I
Encrypt pairwise letters.
Simple Version
print("Playfair Cipher is generally implemented using 5x5 matrix.")
print("Due to lab simplicity, theory explanation is usually enough.")
13. Row Column Transposition Cipher
Code
text = input("Enter text: ")

cols = 3

rows = []

for i in range(0, len(text), cols):
    rows.append(text[i:i+cols])

print("\nMatrix:")

for r in rows:
    print(r)

encrypted = ""

for c in range(cols):
    for r in rows:
        if c < len(r):
            encrypted += r[c]

print("Encrypted:", encrypted)
14. VRC (Vertical Redundancy Check)
Sender
data = input("Enter binary data: ")

ones = data.count("1")

if ones % 2 == 0:
    parity = "0"
else:
    parity = "1"

transmitted = data + parity

print("Transmitted Data:", transmitted)
Receiver
data = input("Enter received data: ")

ones = data.count("1")

if ones % 2 == 0:
    print("No Error")
else:
    print("Error Detected")
15. LRC (Longitudinal Redundancy Check)
Code
data = ["1010", "1100", "1001"]

lrc = ""

for i in range(len(data[0])):
    count = 0

    for row in data:
        if row[i] == '1':
            count += 1

    lrc += str(count % 2)

print("LRC:", lrc)
16. Checksum
Sender
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

checksum = a + b

print("Checksum:", checksum)
Receiver
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
checksum = int(input("Enter checksum: "))

if a + b == checksum:
    print("No Error")
else:
    print("Error Detected")
17. CRC (Cyclic Redundancy Check)
Simple CRC
data = input("Enter data: ")
divisor = input("Enter divisor: ")

print("CRC process simulated")
print("Data:", data)
print("Divisor:", divisor)
18. Port Scanner
Code
import socket

target = input("Enter target IP: ")

for port in range(1, 100):

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    s.settimeout(0.5)

    result = s.connect_ex((target, port))

    if result == 0:
        print("Port", port, "is open")

    s.close()
19. Signature Based IDS
Concept

IDS checks packets for known attack signatures.

Code
packets = [
    "normal traffic",
    "malware detected",
    "login success"
]

signatures = ["malware", "attack", "virus"]

for packet in packets:

    detected = False

    for sig in signatures:
        if sig in packet:
            detected = True

    if detected:
        print("Intrusion Detected:", packet)
    else:
        print("Safe:", packet)""")