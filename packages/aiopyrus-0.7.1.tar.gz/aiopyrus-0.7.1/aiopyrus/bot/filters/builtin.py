from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from aiopyrus.utils.context import _read_field

from .base import Filter

if TYPE_CHECKING:
    from aiopyrus.bot.bot import PyrusBot
    from aiopyrus.types.webhook import WebhookPayload

log = logging.getLogger("aiopyrus.filters")


class FormFilter(Filter):
    """Match tasks belonging to specific form(s).

    Фильтр по форме задачи. Принимает ``id`` (int), название формы (str)
    или их смесь. Имена резолвятся в id через ``bot.get_forms()`` один
    раз при старте диспетчера (polling/webhook). Совпадение по имени —
    точное; если не найдено — case-insensitive fallback.

    **Note:** ``form_id`` is ``None`` in responses from ``GET /inbox`` and
    ``GET /forms/{id}/register``.  In polling mode, ``start_polling()``
    automatically backfills ``form_id``, so this filter works correctly.
    For inbox polling, set ``enrich=True`` or this filter will never match.

    Usage::

        # By id
        @router.task_received(FormFilter(321))
        async def handle(ctx): ...

        # By form name (resolved at startup)
        @router.task_received(FormFilter("Заявки на доступ"))
        async def handle(ctx): ...

        # Mix and match
        @router.task_received(FormFilter([321, "Согласование договора"]))
        async def handle(ctx): ...
    """

    def __init__(self, form: int | str | list[int | str]) -> None:
        items = [form] if isinstance(form, (int, str)) else list(form)
        self._ids: set[int] = {x for x in items if isinstance(x, int)}
        self._names: set[str] = {x for x in items if isinstance(x, str)}

    async def resolve(self, bot: PyrusBot) -> None:
        if not self._names:
            return
        forms = await bot.get_forms()
        by_name: dict[str, int] = {f.name: f.id for f in forms}
        by_name_ci: dict[str, int] = {f.name.casefold(): f.id for f in forms}
        unresolved: list[str] = []
        for name in self._names:
            if name in by_name:
                self._ids.add(by_name[name])
            elif name.casefold() in by_name_ci:
                self._ids.add(by_name_ci[name.casefold()])
            else:
                unresolved.append(name)
        if unresolved:
            raise ValueError(
                f"FormFilter: form name(s) not found in workspace: {unresolved}. "
                f"Available forms: {sorted(by_name)}"
            )
        self._names.clear()

    async def __call__(self, payload: WebhookPayload) -> bool:
        if self._names:
            log.warning(
                "FormFilter has unresolved name(s) %s — call await dp.resolve_filters(bot) "
                "or use Dispatcher.start_polling/start_webhook which resolves automatically.",
                sorted(self._names),
            )
            return False
        return payload.task.form_id in self._ids


class StepFilter(Filter):
    """Match tasks currently at a specific workflow step.

    Фильтр по текущему шагу (этапу) задачи.

    **Note:** ``current_step`` is ``None`` in responses from ``GET /inbox``.
    In polling mode this works because ``GET /register`` does return the step.
    For inbox polling, set ``enrich=True`` or this filter will never match.

    Usage::

        @router.task_received(StepFilter(2))
        async def on_step_2(payload, bot): ...
    """

    def __init__(self, step: int | list[int]) -> None:
        self._steps: set[int] = {step} if isinstance(step, int) else set(step)

    async def __call__(self, payload: WebhookPayload) -> bool:
        return payload.task.current_step in self._steps


class ResponsibleFilter(Filter):
    """Match tasks where the responsible person is one of the given IDs.

    Usage::

        @router.task_received(ResponsibleFilter(12345))
        async def handle(payload, bot): ...
    """

    def __init__(self, person_id: int | list[int]) -> None:
        self._ids: set[int] = {person_id} if isinstance(person_id, int) else set(person_id)

    async def __call__(self, payload: WebhookPayload) -> bool:
        r = payload.task.responsible
        return r is not None and r.id in self._ids


class ApprovalPendingFilter(Filter):
    """Match tasks where a specific person/role is waiting for approval on the current step.

    Checks that the given ID appears in ``task.approvals[current_step - 1]``
    with ``approval_choice`` equal to ``waiting`` or ``None``.

    Usage::

        # Tasks pending approval by role 5555
        @router.task_received(ApprovalPendingFilter(5555))
        async def on_my_approval(ctx): ...

        # Tasks pending approval by any of several roles
        @router.task_received(ApprovalPendingFilter([5555, 6666]))
        async def on_multi(ctx): ...

        # Combine with form filter
        @router.task_received(FormFilter(321) & ApprovalPendingFilter(5555))
        async def on_form_approval(ctx): ...
    """

    def __init__(self, person_id: int | list[int]) -> None:
        self._ids: set[int] = {person_id} if isinstance(person_id, int) else set(person_id)

    async def __call__(self, payload: WebhookPayload) -> bool:
        task = payload.task
        if not task.approvals or not task.current_step:
            return False
        step_idx = task.current_step - 1
        if step_idx >= len(task.approvals):
            return False
        return any(
            entry.person.id in self._ids and entry.is_waiting for entry in task.approvals[step_idx]
        )


class TextFilter(Filter):
    """Match tasks/comments whose text contains a substring (case-insensitive by default).

    Usage::

        @router.task_received(TextFilter("оплата"))
        async def handle(payload, bot): ...
    """

    def __init__(self, substring: str, *, case_sensitive: bool = False) -> None:
        self._sub = substring if case_sensitive else substring.lower()
        self._case_sensitive = case_sensitive

    async def __call__(self, payload: WebhookPayload) -> bool:
        text = payload.task.text or ""
        if not self._case_sensitive:
            text = text.lower()
        return self._sub in text


class EventFilter(Filter):
    """Match specific webhook event types.

    Usage::

        @router.task_received(EventFilter("task_created"))
        async def on_create(payload, bot): ...
    """

    def __init__(self, *events: str) -> None:
        self._events = set(events)

    async def __call__(self, payload: WebhookPayload) -> bool:
        return payload.event in self._events


class FieldValueFilter(Filter):
    """Match tasks where a specific field has a given value.

    Uses human-readable values — the same strings you see in the Pyrus UI
    (no raw IDs, choice_ids, or dict payloads).

    Pass ``value=None`` to match tasks where the field is **empty**.

    Usage::

        # Exact value match (catalog, multiple_choice, text, person, …)
        FieldValueFilter(field_name="Request category *", value="Something is broken")
        FieldValueFilter(field_name="Problem type *", value="Report export")

        # Check that a field is empty
        FieldValueFilter(field_name="Case number *", value=None)

        # Combine with other filters
        @router.task_received(
            StepFilter(6)
            & FieldValueFilter(field_name="Request category *", value="Something is broken")
            & FieldValueFilter(field_name="Case number *", value=None)
        )
        async def handle(payload, bot): ...
    """

    def __init__(
        self,
        *,
        field_id: int | None = None,
        field_name: str | None = None,
        value: Any,
    ) -> None:
        self._field_id = field_id
        self._field_name = field_name
        self._value = value

    async def __call__(self, payload: WebhookPayload) -> bool:
        task = payload.task
        key: int | str | None = self._field_id or self._field_name
        if key is None:
            return False
        field = task.get_field(key)
        if field is None:
            return False
        human = _read_field(field)
        # value=None means "field must be empty"
        if self._value is None:
            return human is None
        # Case-insensitive string comparison (mirrors what the UI shows)
        return str(human).lower() == str(self._value).lower()


def _ensure_aware(dt: datetime) -> datetime:
    """Add UTC tzinfo to naive datetimes so comparisons always work."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


class ModifiedAfterFilter(Filter):
    """Match tasks whose ``last_modified_date`` is after a given moment.

    If ``since`` is omitted it defaults to **now** — i.e., the moment the
    filter object is created (typically at import / bot startup).  This gives
    per-handler "skip old tasks" behaviour.

    Usage::

        # Only tasks modified after the bot starts
        @router.task_received(ModifiedAfterFilter())
        async def handle(payload, bot): ...

        # Only tasks modified after a specific point in time
        from datetime import datetime
        @router.task_received(ModifiedAfterFilter(since=datetime(2025, 6, 1)))
        async def handle(payload, bot): ...

        # Combine with other filters
        @router.task_received(
            StepFilter(6) & ModifiedAfterFilter()
        )
        async def on_step6_fresh(payload, bot): ...
    """

    def __init__(self, since: datetime | None = None) -> None:
        self._since = _ensure_aware(since or datetime.now(timezone.utc))

    async def __call__(self, payload: WebhookPayload) -> bool:
        ts = payload.task.last_modified_date
        if ts is None:
            return False
        return _ensure_aware(ts) > self._since


class CreatedAfterFilter(Filter):
    """Match tasks whose ``create_date`` is after a given moment.

    Defaults to **now** when ``since`` is omitted (same as :class:`ModifiedAfterFilter`).

    Usage::

        # Ignore tasks created before the bot started
        @router.task_received(CreatedAfterFilter())
        async def handle(payload, bot): ...
    """

    def __init__(self, since: datetime | None = None) -> None:
        self._since = _ensure_aware(since or datetime.now(timezone.utc))

    async def __call__(self, payload: WebhookPayload) -> bool:
        ts = payload.task.create_date
        if ts is None:
            return False
        return _ensure_aware(ts) > self._since
