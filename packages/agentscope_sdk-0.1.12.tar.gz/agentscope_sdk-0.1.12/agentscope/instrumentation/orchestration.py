from __future__ import annotations

from typing import Any

from ..run import _current_run_state, observe_run

_STARLETTE_PATCHED = False


def instrument_orchestration(
    *,
    workflow_name: str = "orchestration_auto_trace",
    agent_name: str = "orchestrator",
) -> None:
    _instrument_starlette(
        workflow_name=workflow_name,
        agent_name=agent_name,
    )


def _instrument_starlette(*, workflow_name: str, agent_name: str) -> None:
    global _STARLETTE_PATCHED
    if _STARLETTE_PATCHED:
        return

    try:
        from starlette.applications import Starlette
    except Exception:
        return

    current = Starlette.__call__
    if getattr(current, "__agentscope_wrapped__", False):
        _STARLETTE_PATCHED = True
        return

    async def wrapped_call(self: Any, scope: dict[str, Any], receive: Any, send: Any) -> Any:
        scope_type = str(scope.get("type", "")).lower()
        if scope_type != "http":
            return await current(self, scope, receive, send)

        if _current_run_state() is not None:
            return await current(self, scope, receive, send)

        metadata = _build_request_metadata(scope)
        with observe_run(
            workflow_name,
            agent_name=agent_name,
            metadata=metadata,
            session_id=metadata.get("request_id"),
        ):
            return await current(self, scope, receive, send)

    wrapped_call.__agentscope_wrapped__ = True  # type: ignore[attr-defined]
    Starlette.__call__ = wrapped_call  # type: ignore[assignment]
    _STARLETTE_PATCHED = True


def _build_request_metadata(scope: dict[str, Any]) -> dict[str, Any]:
    headers: dict[str, str] = {}
    for raw_key, raw_value in scope.get("headers") or []:
        try:
            key = raw_key.decode("latin-1").lower()
            value = raw_value.decode("latin-1")
        except Exception:
            continue
        headers[key] = value

    client = scope.get("client") or ()
    client_host = None
    if isinstance(client, tuple) and len(client) > 0:
        client_host = client[0]

    request_id = (
        headers.get("x-request-id")
        or headers.get("x-correlation-id")
        or headers.get("traceparent")
    )

    return {
        "auto_orchestration": True,
        "framework": "starlette",
        "method": scope.get("method"),
        "path": scope.get("path"),
        "query_string": _decode_query_string(scope.get("query_string")),
        "client_ip": client_host,
        "request_id": request_id,
    }


def _decode_query_string(raw: Any) -> str | None:
    if raw is None:
        return None
    if isinstance(raw, bytes):
        try:
            return raw.decode("utf-8")
        except Exception:
            return None
    if isinstance(raw, str):
        return raw
    return None
