"""Template variable handlers package."""
