---
name: architecture-documentation
description: Document technical architecture
languages: [all]
subagents: [all]
tools_needed: [read, write]
---

## Architecture Documentation

### Overview
Document technical architecture.

### Core Concepts
- Concept 1: [Explanation]
- Concept 2: [Explanation]
- Concept 3: [Explanation]

### Key Steps
1. [Step 1 description]
2. [Step 2 description]
3. [Step 3 description]

### Best Practices
- Practice 1
- Practice 2
- Practice 3
