"""``mgf.fastapi.webhooks`` — Svix-shape HMAC webhook verification.

Closes FEEDBACK PAPER-26 (v0.26.0). Replaces the per-consumer
HMAC verification dance every web app reinvents:

  * Read ``<id>``, ``<ts>``, ``<sig>`` headers (case-insensitive).
  * Validate timestamp against a replay window (default 5 minutes).
  * Compute ``HMAC-SHA256(<id>.<ts>.<body>)``, base64-encode.
  * Constant-time-compare against the signature header (multi-version
    space-separated for key rotation).

The core verifier (:class:`HmacWebhookVerifier`) is transport-
agnostic — takes a header mapping and a body bytes object. The
FastAPI request adapter (:func:`verify_request`) lifts a
``Request`` into that shape; it lives separately so the core stays
importable without ``fastapi``.

Pairs with :class:`mgf.common.exceptions.HmacVerificationError`
(inherits from :class:`HttpUnauthorized` so PAPER-24's
``http_status`` resolution maps it to 401 without an explicit
``status_map`` entry).

v0.26.0 ships :data:`SVIX_SCHEMA` as the only built-in preset.
Stripe / GitHub / Slack use related-but-distinct shapes (combined
headers, hex encoding, alternate prefixes) and are deferred until
a second consumer surfaces friction — file via :file:`FEEDBACK.md`.
"""

from __future__ import annotations

from mgf.fastapi.webhooks._request import verify_request
from mgf.fastapi.webhooks._verifier import (
    SVIX_SCHEMA,
    HmacWebhookVerifier,
    WebhookHeaderSchema,
)

__all__ = [
    "SVIX_SCHEMA",
    "HmacWebhookVerifier",
    "WebhookHeaderSchema",
    "verify_request",
]
