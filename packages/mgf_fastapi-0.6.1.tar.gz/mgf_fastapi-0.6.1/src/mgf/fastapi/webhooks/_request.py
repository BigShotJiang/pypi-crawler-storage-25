"""FastAPI ``Request``-adapter for :class:`HmacWebhookVerifier`.

The verifier itself is transport-agnostic. This module provides the
thin lift from a FastAPI ``Request`` into the verifier's
``Mapping[str, str]`` + ``bytes`` shape. Lives in its own file so the
core verifier stays importable without ``fastapi`` installed (matches
the closed-box invariant for ``mgf.fastapi``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from mgf.fastapi.exceptions import HmacVerificationError

if TYPE_CHECKING:
    from fastapi import Request
    from mgf.fastapi.webhooks._verifier import HmacWebhookVerifier

__all__ = ["verify_request"]


async def verify_request(
    request: Request,
    verifier: HmacWebhookVerifier,
) -> tuple[str, int]:
    """Read body + headers from a FastAPI ``Request`` and verify.

    :param request: A FastAPI ``Request``. Caller must NOT have
        consumed the body yet — this function reads it via
        ``await request.body()``.
    :param verifier: The configured :class:`HmacWebhookVerifier`.
    :returns: ``(event_id, timestamp)`` per :meth:`HmacWebhookVerifier.verify`.
    :raises HmacVerificationError: on any verification failure.

    Typical usage in a FastAPI route::

        from mgf.fastapi.webhooks import (
            HmacWebhookVerifier,
            verify_request,
        )

        verifier = HmacWebhookVerifier(secret=settings.webhook_secret)

        @app.post("/webhooks/clerk")
        async def clerk_webhook(request: Request) -> dict:
            event_id, ts = await verify_request(request, verifier)
            payload = await request.json()
            ...
            return {"ok": True}

    Pair with :class:`mgf.fastapi.ExceptionTranslationMiddleware`
    to get the 401 response shape automatically — :class:`HmacVerificationError`
    inherits from :class:`HttpUnauthorized` so PAPER-24's ``http_status``
    resolution maps it without an explicit ``status_map`` entry.

    Body-already-consumed detection (RA-04)
    ---------------------------------------

    ``request.body()`` is idempotent under Starlette's caching, but
    an upstream middleware that consumed the stream a different way
    (``await request.stream()``, ``await request.json()``) leaves
    subsequent ``request.body()`` returning ``b""``. The HMAC over an
    empty body then mismatches and the caller sees a generic
    ``signature mismatch`` — the real failure (upstream consumed
    the body) is invisible.

    Defence: when ``request.body()`` returns empty AND
    ``Content-Length`` says the request had non-zero bytes, raise an
    actionable :class:`HmacVerificationError` whose message names the
    likely cause. Install :func:`verify_request` BEFORE any other
    middleware / dependency that consumes the body.
    """
    body = await request.body()
    # RA-04: detect the body-already-consumed footgun. Content-Length
    # is the most reliable signal — Starlette preserves it from the
    # ASGI scope. If the client sent bytes and we got an empty body
    # back, an upstream middleware ate the stream.
    if len(body) == 0:
        content_length = request.headers.get("content-length")
        if content_length and content_length.strip() not in ("0", ""):
            raise HmacVerificationError(
                f"request body was empty but Content-Length is "
                f"{content_length!r} — an upstream middleware likely "
                f"consumed the body before verify_request ran. Install "
                f"verify_request EARLIER in the middleware chain, or "
                f"avoid `await request.stream()` / `await request.json()` "
                f"in upstream middleware. (RA-04.)"
            )
    return verifier.verify(request.headers, body)
