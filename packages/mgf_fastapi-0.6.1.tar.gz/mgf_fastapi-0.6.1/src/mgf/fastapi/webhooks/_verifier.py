"""Transport-agnostic Svix-shape HMAC webhook verifier.

The verifier core takes a ``Mapping[str, str]`` of headers and a
``bytes`` body — no FastAPI / Starlette / framework dependency.
The framework adapter (``verify_request``) lives separately so the
core is testable in isolation and reusable from non-FastAPI code
paths (CLI, batch jobs, alternative HTTP frameworks).

The signing scheme is Svix's: ``HMAC-SHA256(<id>.<ts>.<body>)`` keyed
on the shared secret, base64-encoded, prefixed ``v1,`` per signature
version, multiple versions space-separated for key rotation. Clerk
ships Svix verbatim; Stripe / GitHub / Slack use related-but-distinct
shapes (combined headers, hex encoding, alternate prefixes) and are
NOT covered at v0.26 — see PAPER-26 retrospective.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

from mgf.fastapi.exceptions import HmacVerificationError

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

__all__ = [
    "SVIX_SCHEMA",
    "HmacWebhookVerifier",
    "WebhookHeaderSchema",
]


@dataclass(frozen=True, slots=True)
class WebhookHeaderSchema:
    """Names of the three Svix-style headers a provider uses.

    Header names are matched case-insensitively against the input
    mapping; the values stored here are the canonical lowercase form.
    """

    id_header: str
    timestamp_header: str
    signature_header: str

    def __post_init__(self) -> None:
        # Force-lowercase the canonical names so matching is uniform —
        # consumers can pass any case and the verifier still finds them.
        object.__setattr__(self, "id_header", self.id_header.lower())
        object.__setattr__(self, "timestamp_header", self.timestamp_header.lower())
        object.__setattr__(self, "signature_header", self.signature_header.lower())


SVIX_SCHEMA = WebhookHeaderSchema(
    id_header="svix-id",
    timestamp_header="svix-timestamp",
    signature_header="svix-signature",
)
"""Svix-flavoured header names. Used directly by Clerk webhooks.

Stripe / GitHub / Slack are deliberately not shipped at v0.26 — their
signing-header conventions differ enough (combined headers, hex
encoding, alternate prefixes) that a single :class:`WebhookHeaderSchema`
doesn't fit them. Adding them is tracked for follow-up papers.
"""


class HmacWebhookVerifier:
    """Verify a Svix-shape HMAC-signed webhook.

    The verifier is constructed once per webhook secret and reused
    across requests. It is stateless and thread-safe; concurrent
    callers MAY share a single instance.

    :param secret: The shared secret. ``bytes`` is preferred; ``str``
        is encoded as UTF-8 for convenience. For Svix/Clerk, the
        ``whsec_…`` prefix is part of the secret and SHOULD be passed
        through verbatim (do not strip).
    :param schema: Header-name schema. Defaults to :data:`SVIX_SCHEMA`.
    :param replay_window_seconds: Maximum age (in seconds) of a webhook
        timestamp to accept. Default 300 (5 minutes), matching Svix's
        published recommendation.
    :param signature_prefix: The version prefix. Svix uses ``"v1,"``
        (the comma is part of the prefix; the base64 sig follows).
        Multi-version sigs are space-separated; the verifier accepts
        any one matching this prefix.
    :param now: Override the timestamp source. Tests pass a fixed
        ``lambda: 1614265330``; production uses the default
        :func:`time.time`. Returns float seconds-since-epoch.
    """

    __slots__ = (
        "_now",
        "_replay_window_seconds",
        "_schema",
        "_secret",
        "_signature_prefix",
    )

    def __init__(
        self,
        *,
        secret: bytes | str,
        schema: WebhookHeaderSchema = SVIX_SCHEMA,
        replay_window_seconds: int = 300,
        signature_prefix: str = "v1,",
        now: Callable[[], float] | None = None,
    ) -> None:
        # SH-02: a too-short `signature_prefix` makes the version
        # namespace ambiguous with the signature bytes themselves —
        # e.g., `signature_prefix="v"` matches every candidate that
        # starts with "v", defeating the version-namespace + key-
        # rotation shape. Require at least 2 chars (the default
        # `"v1,"` is 3). The minimum is conservative; the Svix
        # convention always has at least a version + delimiter.
        if not signature_prefix or len(signature_prefix) < 2:
            raise ValueError(
                f"signature_prefix must be at least 2 characters to "
                f"avoid ambiguity with signature bytes "
                f"(got {signature_prefix!r}). The Svix convention is "
                f"a version label + comma, e.g. 'v1,'. (SH-02.)"
            )
        self._secret = secret.encode("utf-8") if isinstance(secret, str) else secret
        self._schema = schema
        self._replay_window_seconds = replay_window_seconds
        self._signature_prefix = signature_prefix
        self._now = now if now is not None else time.time

    def verify(
        self,
        headers: Mapping[str, str],
        body: bytes,
    ) -> tuple[str, int]:
        """Verify the signature on ``body`` against the headers.

        :returns: ``(event_id, timestamp)`` on success — the verified
            header values, useful for callers that want to log the
            event id or de-dupe.
        :raises HmacVerificationError: on missing header, unparseable
            timestamp, replay-window miss, or signature mismatch.
            The message gives the proximate cause (no secret material).
        """
        # Case-insensitive header lookup. Build a single dict once;
        # cheap relative to HMAC compute.
        h = {k.lower(): v for k, v in headers.items()}

        event_id = h.get(self._schema.id_header)
        if event_id is None:
            raise HmacVerificationError(
                f"missing header {self._schema.id_header!r}"
            )

        ts_raw = h.get(self._schema.timestamp_header)
        if ts_raw is None:
            raise HmacVerificationError(
                f"missing header {self._schema.timestamp_header!r}"
            )
        try:
            ts = int(ts_raw)
        except ValueError as exc:
            raise HmacVerificationError(
                f"header {self._schema.timestamp_header!r} is not an integer"
            ) from exc

        sig_header = h.get(self._schema.signature_header)
        if sig_header is None:
            raise HmacVerificationError(
                f"missing header {self._schema.signature_header!r}"
            )

        # Replay window: reject timestamps too far in the past or future.
        # Future skew is bounded too — a clock that's drifted way ahead
        # is as suspicious as a stale one.
        delta = abs(self._now() - ts)
        if delta > self._replay_window_seconds:
            raise HmacVerificationError(
                f"timestamp outside replay window "
                f"({self._replay_window_seconds}s)"
            )

        # Compute expected signature: HMAC-SHA256(<id>.<ts>.<body>)
        # base64-encoded.
        signed_payload = f"{event_id}.{ts}.".encode() + body
        digest = hmac.new(self._secret, signed_payload, hashlib.sha256).digest()
        expected = base64.b64encode(digest).decode("ascii")

        # Multi-version signatures: Svix sends ``v1,sigA v1,sigB`` for
        # key rotation. Accept any one matching the configured prefix.
        # RA-02: split on ANY whitespace (not just `" "`) so observed-
        # in-the-wild deviations parse correctly — proxies that
        # re-encode HTTP headers can replace single spaces with tabs,
        # multiple spaces, or stray leading/trailing whitespace.
        # `str.split()` with no arg also drops empty strings, so a
        # `"v1,sigA  v1,sigB "` payload doesn't yield empty
        # candidates that fail every prefix check silently.
        candidates = sig_header.split()
        for candidate in candidates:
            if not candidate.startswith(self._signature_prefix):
                continue
            received = candidate[len(self._signature_prefix) :]
            # Constant-time comparison to prevent timing-oracle leak.
            if hmac.compare_digest(received, expected):
                return event_id, ts

        raise HmacVerificationError("signature mismatch")
