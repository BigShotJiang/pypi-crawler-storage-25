"""``mgf.fastapi`` — FastAPI integration adapters for ``mgf-common``.

Sibling of :mod:`mgf.common` under the ``mgf.*`` namespace. Houses
every FastAPI-specific adapter that previously lived under
``mgf.common.fastapi.*`` — extracted at mgf-common v0.28 /
mgf-fastapi v0.1 per the federation split plan.

A consumer building a FastAPI service shouldn't reinvent the wiring
for these every time:

  - :func:`bootstrap` ↔ FastAPI lifespan (start/stop wiring).
  - Per-request ``X-Request-Id`` generation + propagation to logs.
  - Typed-exception → JSON response mapping
    (``ConfigError`` → 400, ``ResourceNotFoundError`` → 404,
    HTTP-01 leaves resolved via ``http_status``, etc.).
  - ``Depends()`` helpers for request-scoped data (settings,
    request_id, ``AppContext``).

The submodules:

  - :mod:`mgf.fastapi.webhooks` — Svix-shape HMAC webhook
    verification (``HmacWebhookVerifier``, ``verify_request``).
  - :mod:`mgf.fastapi.security` — request-side security
    primitives (``IpAllowlist``).
  - :mod:`mgf.fastapi.testing` — async context-manager test
    server (``run_test_app``).
  - :mod:`mgf.fastapi.exceptions` — sibling-domain concrete
    exception leaves (``HmacVerificationError``).

Install: ``pip install mgf-fastapi`` (or
``pip install 'mgf-fastapi[testing]'`` for ``run_test_app``).

The integration is **adapter-shaped, not framework-shaped**. Nothing
here re-exports FastAPI primitives or hides them. The consumer's app
is still a regular FastAPI app — these helpers just plug into the
seams FastAPI provides (lifespan, middleware, dependencies).

Closed-box invariant: ``mgf-fastapi`` depends on ``mgf-common`` +
``fastapi`` only. Consumers using only ``mgf-common`` never see
the import.
"""

from __future__ import annotations

from mgf.fastapi._dependencies import (
    get_app_context,
    get_request_id,
    get_settings,
)
from mgf.fastapi._exceptions import (
    DEFAULT_STATUS_MAP,
    ExceptionTranslationMiddleware,
)
from mgf.fastapi._lifespan import setup_lifespan
from mgf.fastapi._rate_limit import RateLimitMiddleware, TokenBucket
from mgf.fastapi._request_id import (
    REQUEST_ID_HEADER,
    RequestIdMiddleware,
    current_request_id,
)
from mgf.fastapi.exceptions import HmacVerificationError

__all__ = [
    "DEFAULT_STATUS_MAP",
    "REQUEST_ID_HEADER",
    "ExceptionTranslationMiddleware",
    "HmacVerificationError",
    "RateLimitMiddleware",
    "RequestIdMiddleware",
    "TokenBucket",
    "current_request_id",
    "get_app_context",
    "get_request_id",
    "get_settings",
    "setup_lifespan",
]
