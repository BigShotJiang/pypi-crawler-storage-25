# USERS — who depends on mgf-fastapi

> **Purpose:** mgf-fastapi's user roll. Lists every consumer project and
> federation sibling that imports `mgf.fastapi.*`.
> **Maintained by:** the mgf-common owner (Bassam — mgf-common owns the
> federation per the one-big-library mindset).
> **Per standard DOC-16** (v2.9): every `mgf-*` library MUST maintain a
> `USERS.md` at repo root.

Last verified: 2026-05-18 (post-mgf-fastapi v0.6.0 release with
RateLimitMiddleware).

---

## §1 Consumer projects (external users)

| Project           | Location                                      | Import sites | Status                                         | Surfaces used                                                  |
|-------------------|-----------------------------------------------|-------------:|------------------------------------------------|----------------------------------------------------------------|
| **PlasmaMapper**  | `/home/bassam/PycharmProjects/PlasmaMapper`   | 8            | Active — multi-tenant FastAPI SaaS, heaviest adopter | `mgf.fastapi` core / `webhooks` / `security` / `db` / `testing` |

**Single-consumer reality.** PlasmaMapper drives the mgf-fastapi roadmap.
Every shipped surface (10 in `mgf.fastapi`, 4 in `webhooks`, 4 in
`security`, 2 in `db`, 1 in `testing`) was extracted from PlasmaMapper's
in-tree code. Adoption will broaden once a second FastAPI consumer arrives.

---

## §2 Federation siblings (`mgf-*` libraries)

| Sibling             | Import sites | Surfaces used                                |
|---------------------|-------------:|----------------------------------------------|
| **mgf-sqlalchemy**  | 1 *(via the `[sqlalchemy]` extra)* | `mgf.sqlalchemy.AuditTrailMixin` integration  |

mgf-fastapi declares `mgf-sqlalchemy>=0.4,<0.5` under the `[sqlalchemy]`
extra so consumers opting into the audit-trail integration get the
right pin automatically (see `pyproject.toml [project.optional-dependencies]`).

---

## §3 What a "user" change MUST trigger

See [`../mgf_common/USERS.md`](../mgf_common/USERS.md) §3.

The single-consumer status today means breaking changes need only check
PlasmaMapper — but mgf-fastapi is the most-likely-to-grow library in the
federation (SaaS use cases stack up fast). Treat every PUBLIC_API change
with "would a second FastAPI consumer be surprised?" review.

---

## §4 How this list is maintained

```sh
for proj in VManager inthewords PlasmaMapper iosRecovery; do
  grep -rE "(from|import) +mgf\.fastapi" "/home/bassam/PycharmProjects/$proj" \
    --include='*.py' | wc -l
done
```

Re-run before each MINOR release. The second non-zero count is the signal
to formalise more of the experimental surface as stable.
