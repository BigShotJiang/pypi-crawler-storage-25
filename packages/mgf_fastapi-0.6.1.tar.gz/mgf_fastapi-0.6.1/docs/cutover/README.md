# `docs/cutover/` — per-release breaking-change guides

**Per `DOC-05`** in `mgf-common`'s [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md):
one guide per release that breaks a documented surface
(MAJOR — or MINOR within `0.x` per **AP-03**). The guide is
the **consumer's migration runway** between two pinned versions.

## What goes here

One file per breaking release, named `v<X.Y.Z>.md` after the
version that *contains* the breakage. Each guide MUST include
the four mandatory sections from **DOC-05**:

1. **What was removed / renamed / reshaped** — table of literal
   old name → literal new name + codemod yes/no.
2. **Quickest path — codemod recipe** — with `--dry-run`
   preview (if a codemod ships).
3. **Manual: each non-codemoddable change** — copy-pasteable
   before/after blocks.
4. **Closes FEEDBACK `<ID>`** — back-link to the design record
   (where applicable).

## What does NOT go here

- **CHANGELOG entries** → root `CHANGELOG.md` per **DOC-04**.
  The cutover guide is the *migration recipe*; the CHANGELOG is
  the *audit trail*. Both cross-reference each other.
- **Non-breaking changes** — those live only in `CHANGELOG.md`.
- **Roadmaps / proposals** — those live in `docs/inprogress/`
  (if the sibling has one).

## Index
