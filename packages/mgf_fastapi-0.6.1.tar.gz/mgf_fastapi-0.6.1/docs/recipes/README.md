# `docs/recipes/` — task-shaped how-tos

**Per `DOC-02`** in `mgf-common`'s [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md):
task-shaped how-tos ("I want to do X — here's the recipe").
Verb-shaped, consumer-facing. Sister bucket to
`docs/reference/` (if it exists) which is noun-shaped
("the Y component").

## What goes here

One file per common task. Recipes follow the shape:

```markdown
# How to <verb-shaped task>

> **You want to:** <one-sentence statement>.
> **You have:** <prerequisites>.
> **You'll end up with:** <concrete outcome>.

## Steps
1. ...
2. ...

## Verify
<one-command verification>

## Common pitfalls
<the things every reader gets wrong on first attempt>

## Cross-references
- [`mgf-common/...`](...) — relevant standards / recipes.
```

## What does NOT go here

- **Per-component user guides** — those go in `docs/reference/`
  if and when this project grows one.
- **Architecture / design papers** — those go in `docs/design/`
  if and when justified.
- **Cross-project rules** — those live in
  `mgf-common/docs/standards/`; this folder is for task-shaped
  guidance specific to consuming this sibling.

## Index
