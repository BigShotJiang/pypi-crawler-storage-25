# mgf-fastapi — Claude Reference

Dense lookup document. No prose. Facts only.

> **See also:** [`mgf-common/docs/claude/CLAUDE.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/claude/CLAUDE.md)
> — cornerstone reference shared across the federation. The
> cross-cutting patterns (atomic-write, never-raises observers,
> redaction layering) documented there apply to this sibling
> too. THIS file is the mgf-fastapi-specific addenda.

---

## Project shape

- **Federation sibling** of `mgf-common` (per
  [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) §2.0).
- **Conformance target:** L2 — inherited via
  `mgf-common>=0.33,<0.34`.
- **PyPI:** `mgf-fastapi`; first published at v0.1.0
  (2026-05-09); current v0.4.0 (this release adds the v2.6/v2.7
  compliance shape).
- **Codeberg:** `magogi-admin/mgf-fastapi`; default branch `main`.

## File map (where things live)

| Path | Purpose |
|---|---|
| `src/mgf/fastapi/__init__.py` | Re-exports the load-bearing public names from the submodules. PEP 420 namespace package. |
| `src/mgf/fastapi/_lifespan.py` | `setup_lifespan()` — builds a FastAPI lifespan that runs `mgf.common.bootstrap()` at app startup; stashes the `AppContext` on `app.state.mgf_context`. |
| `src/mgf/fastapi/_request_id.py` | `RequestIdMiddleware` + `current_request_id()` + `REQUEST_ID_HEADER`. ASGI middleware that injects/forwards `X-Request-Id`; shares the contextvar with `mgf.django.MgfRequestIdMiddleware` for cross-framework correlation. |
| `src/mgf/fastapi/_dependencies.py` | `get_app_context()`, `get_settings()`, `get_request_id()` FastAPI dependencies. |
| `src/mgf/fastapi/_exceptions.py` | `ExceptionTranslationMiddleware` + `DEFAULT_STATUS_MAP` — maps `AppError` to JSON 4xx/5xx via `status_map` AND PAPER-24's `http_status` fallback for HTTP-01 leaves. |
| `src/mgf/fastapi/exceptions.py` | Sibling-domain concretes: `HmacVerificationError` (inherits `HttpUnauthorized` → 401). |
| `src/mgf/fastapi/security.py` | `IpAllowlist` dep (PAPER-27, proxy-trust footgun documented) + `bearer_session` resolver + `AuthVerifier` Protocol (PAPER-29). |
| `src/mgf/fastapi/webhooks/_verifier.py` | `HmacWebhookVerifier` — constant-time HMAC compare + replay-window timestamp validation. PAPER-26. |
| `src/mgf/fastapi/webhooks/_request.py` | `WebhookRequest` wrapper for the verifier. |
| `src/mgf/fastapi/db.py` | Async-SQLAlchemy lifespan + dependency helpers (under `[sqlalchemy]` extra). |
| `src/mgf/fastapi/testing.py` | `run_test_app()` — async context manager that stands up a real FastAPI app on a free port for end-to-end tests. PAPER-28. |
| `PUBLIC_API.md` | Contract list — every public name with stability tier (per **AP-10**). |
| `CHANGELOG.md` | Per-release record (Keep a Changelog format). |
| `SECURITY.md` | Vulnerability-reporting policy (per **SC-12**). |
| `docs/standards/README.md` | Pointer-only stub — points at `mgf-common/docs/standards/`. NOT a duplicate. |
| `docs/cutover/v*.md` | Per-release breaking-change migration guides. |
| `docs/recipes/*.md` | Task-shaped how-tos (HMAC webhook, IP allowlist, bearer-session, test API server). |

## Cross-cutting patterns

1. **Bootstrap exactly once via lifespan.** `setup_lifespan()`
   wraps `mgf.common.bootstrap()` in a FastAPI lifespan; the
   `AppContext` lives on `app.state.mgf_context` for the
   process lifetime. LIFO unwind on shutdown ensures OTel
   flushes, log handlers detach, crash hooks reset.

2. **Request-id contextvar sharing.** `RequestIdMiddleware`
   reads/sets the SAME `mgf.common._request_id` contextvar
   that `mgf.django.MgfRequestIdMiddleware` uses. A FastAPI
   service called from a Django app (or the reverse) preserves
   the `X-Request-Id` end-to-end.

3. **PAPER-24 exception translation.** The middleware maps
   `AppError` subclasses to JSON responses by checking:
   (a) explicit `status_map` entry; (b) `exc.http_status`
   class attribute (HTTP-01 leaves like `HttpUnauthorized`,
   `HttpNotFound` inherit this); (c) default 500 for unknown
   `AppError` subclasses. The fallback chain means new
   domain-specific exceptions inheriting `HttpUnauthorized`
   "just work" without `status_map` extension.

4. **HMAC verifier — replay window.** `HmacWebhookVerifier`
   defaults to a 5-minute timestamp window. Tune per upstream's
   recommended window (Svix: 5min; Stripe: 5min default but
   configurable; GitHub: no built-in timestamp — use the
   `X-GitHub-Delivery` UUID for at-most-once instead).

5. **IP allowlist — proxy trust.** `IpAllowlist(trust_proxy=True)`
   reads the FIRST entry in `X-Forwarded-For`. Use ONLY when a
   trusted reverse proxy (Envoy, nginx, CloudFront) sits in
   front; otherwise `X-Forwarded-For` is attacker-controlled.
   Documented PAPER-27 footgun.

6. **Bearer-session — IdP outage handling.** The `AuthVerifier`
   Protocol's `verify()` raises `HttpUnauthorized` on every
   failure mode (missing token, expired, invalid signature, IdP
   500). Consumers MUST NOT differentiate — surfacing "your
   token is invalid" vs "we couldn't reach the IdP" to the
   user is an info-leak. PAPER-29.

7. **Test API server — port allocation.** `run_test_app()`
   uses `0` for the port (OS-assigned). Tests SHOULD read the
   actual port from the yielded `host:port` rather than
   hardcoding.

## Build and release

The canonical sequence per
[`mgf-common/docs/standards/RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md):

1. Bump `version` in `pyproject.toml`.
2. Add the `[X.Y.Z] — YYYY-MM-DD` entry in `CHANGELOG.md` in
   the same commit.
3. Update `PUBLIC_API.md` if the public surface changed
   (validated by `tests/unit/test_public_api_doc.py`).
4. Run the full test suite locally (`pytest`).
5. Run `mypy --strict src/mgf/fastapi/`.
6. Build: `uv build`.
7. `twine check dist/*` — both wheel and sdist MUST pass.
8. Commit (`chore: cut vX.Y.Z`).
9. Tag annotated: `git tag -a vX.Y.Z -m '...'`.
10. Push: `git push origin main && git push origin vX.Y.Z`.
11. Upload: `twine upload dist/*`.
12. Post-publish smoke: `pip install --upgrade mgf-fastapi==X.Y.Z`
    in a clean venv; import every public name.

## Common pitfalls

- **Forgetting `setup_lifespan()` on the FastAPI app.** Without
  it `app.state.mgf_context` is unset; `get_app_context()`
  raises `AppConfigError`. Symptom: every endpoint that
  depends on `get_settings()` fails at 500.
- **Middleware install order matters.** `RequestIdMiddleware`
  MUST precede `ExceptionTranslationMiddleware` so the error
  body can include `request_id`.
- **Forgetting to set `MGF_FASTAPI_TEST_BASE_URL` in tests.**
  `run_test_app()` yields the URL — read it from the yielded
  value; hardcoding `http://127.0.0.1:8000` flakes when the
  OS assigns a different port.
- **HMAC verifier vs. signature header name.** Different
  webhook sources use different header names (Svix:
  `svix-signature`; Stripe: `Stripe-Signature`; GitHub:
  `X-Hub-Signature-256`). The verifier's `header_name=`
  kwarg is required; no sensible default.
- **`bearer_session` with `AuthVerifier` that raises non-
  HttpUnauthorized.** The verifier MUST translate every
  failure mode to `HttpUnauthorized` at the seam. Letting a
  raw `httpx.ConnectError` propagate breaks PAPER-29's
  contract.

## Recently-touched areas

(Rolling list, last N changes. Update on every commit that
changes a load-bearing fact.)

- **v0.4.0 prep (2026-05-15)** — added v2.6/v2.7 compliance
  files (this CLAUDE.md + SECURITY.md + docs/standards/README.md
  pointer); no code changes.
- **v0.3.1 (2026-05-11)** — walked mgf-common pin to >=0.33,<0.34.
- **v0.3.0 (2026-05-10)** — PAPER-29: `bearer_session` +
  `AuthVerifier` Protocol shipped. Replaced ~30 LOC of
  duplicate code across PlasmaMapper's auth surface.
- **v0.2.0 (2026-05-10)** — PAPER-26 (HmacWebhookVerifier) +
  PAPER-27 (IpAllowlist) + PAPER-28 (run_test_app) moved
  from mgf-common into mgf-fastapi.

---

*Last updated: 2026-05-15.*
