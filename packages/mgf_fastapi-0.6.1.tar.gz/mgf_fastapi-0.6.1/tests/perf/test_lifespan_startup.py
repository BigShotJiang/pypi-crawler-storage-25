"""PC-04: ``setup_lifespan`` enter+exit wall-clock pin.

`setup_lifespan` returns an async context manager that runs
`mgf.common.bootstrap` at FastAPI startup. For long-lived workers
the cost amortises to zero; for test fixtures that build fresh
apps repeatedly (PAPER-28's `run_test_app`), the lifespan cost
compounds: 1000 tests x 100 ms = 100 s of bootstrap time per
suite.

Strategy: build a fresh FastAPI app and enter+exit the lifespan
in async context. Repeat 5x; assert the **max** stays under
budget so the test catches a regression in either the first
invocation (which pays the bootstrap-state setup) or a
subsequent invocation (where in-process state caches the work).

Local baseline (Linux 6.17, Python 3.11, v0.4.0):
  - first run:           ~24 ms
  - subsequent runs:     ~1 ms (bootstrap state cached in-process)

Budget: 150 ms (mgf-common's PC-01 100 ms cold-import baseline +
~50 ms sibling-side headroom). A breach signals either an
mgf.fastapi regression OR an upstream mgf-common bootstrap
regression — cross-reference mgf-common PC-01 for the cornerstone.

Marker: ``perf`` (registered in pyproject.toml). Excluded from
the default suite; run via ``pytest -m perf`` for the nightly
sweep.
"""

from __future__ import annotations

import asyncio
import time

import pytest
from fastapi import FastAPI

from mgf.fastapi import setup_lifespan

# Lifespan enter+exit budget. The measurement includes a fresh
# FastAPI() construction, the lifespan context manager's __aenter__
# (which runs mgf.common.bootstrap), and __aexit__ (which LIFO-
# unwinds the bootstrap stack). 150 ms is the tracker's spec:
# mgf-common's ~100 ms cold-import cornerstone + ~50 ms sibling
# headroom.
_LIFESPAN_BUDGET_MS = 150.0


@pytest.mark.perf
class TestLifespanStartup:
    """Pin the lifespan enter+exit wall-clock."""

    def test_max_of_5_under_budget(self) -> None:
        """Max wall-clock across 5 fresh-app enter+exit cycles."""

        async def _drive() -> list[float]:
            runs: list[float] = []
            for _ in range(5):
                app = FastAPI()
                lifespan = setup_lifespan(
                    app_name="perf-test",
                    app_version="0.0.1",
                )
                cm = lifespan(app)

                start = time.perf_counter()
                await cm.__aenter__()
                await cm.__aexit__(None, None, None)
                runs.append((time.perf_counter() - start) * 1000.0)

            return runs

        runs_ms = asyncio.run(_drive())
        max_ms = max(runs_ms)

        assert max_ms < _LIFESPAN_BUDGET_MS, (
            f"PC-04: setup_lifespan enter+exit budget breach: "
            f"max {max_ms:.1f} ms over 5 runs "
            f"(budget {_LIFESPAN_BUDGET_MS:.0f} ms). "
            f"All runs: {[f'{r:.1f}' for r in runs_ms]} ms. "
            f"Investigate src/mgf/fastapi/_lifespan.py::setup_lifespan + "
            f"cross-check mgf-common PC-01 (cold-import) for upstream "
            f"bootstrap regression."
        )
