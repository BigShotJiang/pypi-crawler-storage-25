"""PC-06: ``ExceptionTranslationMiddleware._lookup_status`` MRO walk cost.

The middleware only runs on exception (the happy path costs nothing).
But when an exception fires, ``_lookup_status`` walks ``exc_type.__mro__``
checking ``self._status_map``. Per call: O(MRO depth x map size).

For a deeply-derived exception (e.g., a 6-level inheritance chain
from AppError) against a 20-entry status_map, that's 120 dict lookups
worst case. Sub-µs per dict op in CPython; the worst case is still
microseconds — but PROD apps can have 100s of req/s on the exception
path during an incident.

Pin: lookup against a 5-level deep AppError subclass on a 20-entry
map stays under 20 µs per call. Local: ~1-2 µs.

Marker: ``perf``. Run via ``pytest -m perf``.
"""

from __future__ import annotations

import time

import pytest
from mgf.common.exceptions import AppError

from mgf.fastapi._exceptions import ExceptionTranslationMiddleware

pytestmark = pytest.mark.perf

_ITERATIONS = 10_000
_PER_LOOKUP_BUDGET_US = 20.0


def test_lookup_status_under_budget() -> None:
    # Build a deep AppError subclass hierarchy.
    class L1Error(AppError):
        pass

    class L2Error(L1Error):
        pass

    class L3Error(L2Error):
        pass

    class L4Error(L3Error):
        pass

    class L5Error(L4Error):
        pass

    # 20-entry status_map (none matching L5Error directly — forces a
    # full MRO walk down to AppError).
    status_map: dict[type[AppError], int] = {
        type(f"Unrelated{i}Error", (AppError,), {}): 400 + i
        for i in range(19)
    }
    status_map[AppError] = 500

    # Construct middleware (the app arg is unused for _lookup_status).
    middleware = ExceptionTranslationMiddleware(
        app=None,  # type: ignore[arg-type]
        status_map=status_map,
    )

    # Warm up.
    middleware._lookup_status(L5Error)

    start = time.perf_counter()
    for _ in range(_ITERATIONS):
        middleware._lookup_status(L5Error)
    elapsed_s = time.perf_counter() - start
    per_call_us = (elapsed_s / _ITERATIONS) * 1e6

    assert per_call_us < _PER_LOOKUP_BUDGET_US, (
        f"PC-06: _lookup_status MRO walk costs {per_call_us:.2f} µs "
        f"per call (budget {_PER_LOOKUP_BUDGET_US:.0f} µs). For a 5-level "
        f"AppError subclass on a 20-entry map. Regressions usually mean "
        f"the lookup acquired a per-call expense (logging, allocation, "
        f"isinstance chain instead of dict lookup). Investigate "
        f"src/mgf/fastapi/_exceptions.py."
    )
