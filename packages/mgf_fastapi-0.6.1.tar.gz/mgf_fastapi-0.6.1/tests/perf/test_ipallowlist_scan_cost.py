"""PC-05: ``IpAllowlist.__call__`` CIDR scan cost.

The dependency iterates ``self._networks`` checking ``client_ip in
network``. For a small allowlist (loopback only — 2 entries) the
per-request cost is sub-µs. For a "trust all our prod ranges"
allowlist (100+ CIDRs), the per-request scan compounds.

Pin: 100-CIDR allowlist evaluation stays under 50 µs per request.
Local: ~3-5 µs.

Marker: ``perf``. Run via ``pytest -m perf``.
"""

from __future__ import annotations

import time
from unittest.mock import Mock

import pytest

from mgf.fastapi.security import IpAllowlist

pytestmark = pytest.mark.perf

_ITERATIONS = 1000
_PER_CALL_BUDGET_US = 50.0


def _make_request(client_host: str) -> Mock:
    request = Mock()
    request.client = Mock()
    request.client.host = client_host
    request.headers = {}
    return request


def test_ipallowlist_100_cidr_under_budget() -> None:
    # 100 CIDRs — realistic upper bound for "all our prod /16s".
    cidrs = [f"10.{i}.0.0/16" for i in range(100)]
    allowlist = IpAllowlist(cidrs=cidrs)

    # Hit the LAST CIDR so we exercise the worst-case scan
    # (no short-circuit on early match).
    request = _make_request("10.99.0.1")

    # Warm up.
    allowlist(request)

    start = time.perf_counter()
    for _ in range(_ITERATIONS):
        allowlist(request)
    elapsed_s = time.perf_counter() - start
    per_call_us = (elapsed_s / _ITERATIONS) * 1e6

    assert per_call_us < _PER_CALL_BUDGET_US, (
        f"PC-05: IpAllowlist with 100 CIDRs costs {per_call_us:.2f} µs "
        f"per request (budget {_PER_CALL_BUDGET_US:.0f} µs). At 1000 "
        f"req/s, this is {per_call_us * 1000:.0f} µs/s of allowlist "
        f"scanning. A regression here would compound on every request. "
        f"Investigate src/mgf/fastapi/security.py::IpAllowlist."
    )
