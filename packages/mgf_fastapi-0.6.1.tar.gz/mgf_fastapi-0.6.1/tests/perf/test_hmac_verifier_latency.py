"""PC-02: ``HmacWebhookVerifier.verify`` latency budget.

`HmacWebhookVerifier.verify` runs:

  1. Build a case-insensitive header dict.
  2. Three header reads + UUID-ish event_id capture.
  3. `int(ts_raw)` parse + replay-window check.
  4. SHA-256 over `<id>.<ts>.<body>` — payload-size dominated.
  5. base64-encode the digest.
  6. Iterate signature candidates + `hmac.compare_digest`.

SHA-256 is CPython C-coded; its per-call cost is linear in body
size at roughly 200 MB/s, so the wall-clock is dominated by the
body. The Python overhead (dict comp, int parse, base64 encode)
is fixed at ~5-10 µs.

Pinned per body size to catch non-linear regressions. Anything
that pushed scaling from O(n) to O(n^2) — a redundant pass over
the body, a re-encode, a regex over the payload — would breach
the larger sizes first.

Local baseline (Linux 6.17, Python 3.11, v0.4.0):
  -   1 KB:  ~1.7 µs/verify
  -  16 KB:  ~5.3 µs/verify
  -  64 KB:  ~16 µs/verify
  - 256 KB:  ~59 µs/verify

Budgets give 5-12x cushion at each size. The biggest is sized
for the SHA-256-throughput floor; the smallest tolerates Python
overhead variance.

Marker: ``perf`` (registered in pyproject.toml). Excluded from
the default suite; run via ``pytest -m perf`` for the nightly
sweep.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import time

import pytest

from mgf.fastapi.webhooks._verifier import HmacWebhookVerifier

# Per-size budgets. Catch non-linear regressions (a redundant
# pass, a regex over the body) without false-positive on CI noise.
# Order matches the test's iteration order — see the test docstring.
_PER_SIZE_BUDGETS_US: tuple[tuple[int, float], ...] = (
    (1 * 1024, 50.0),       # 1 KB:    measured ~1.7 µs → 30x cushion
    (16 * 1024, 100.0),     # 16 KB:   measured ~5.3 µs → 19x cushion
    (64 * 1024, 200.0),     # 64 KB:   measured ~16 µs  → 12x cushion
    (256 * 1024, 500.0),    # 256 KB:  measured ~59 µs  →  8x cushion
)

# Use a wide replay window so synthetic test payloads with fixed
# timestamps don't fail the freshness check.
_REPLAY_WINDOW = 10**9
_SECRET = b"whsec_perf_test_secret"
_EVENT_ID = "evt_perf_test"
_TIMESTAMP = 1_700_000_000


def _make_signed_payload(body_size: int) -> tuple[dict[str, str], bytes]:
    """Build (headers, body) for a Svix-shape signed webhook."""
    body = b"x" * body_size
    signed = f"{_EVENT_ID}.{_TIMESTAMP}.".encode() + body
    digest = hmac.new(_SECRET, signed, hashlib.sha256).digest()
    sig = "v1," + base64.b64encode(digest).decode("ascii")
    headers = {
        "svix-id": _EVENT_ID,
        "svix-timestamp": str(_TIMESTAMP),
        "svix-signature": sig,
    }
    return headers, body


@pytest.mark.perf
class TestHmacVerifierLatency:
    """Pin per-body-size verify() latency."""

    def test_verify_under_per_size_budget(self) -> None:
        verifier = HmacWebhookVerifier(
            secret=_SECRET,
            replay_window_seconds=_REPLAY_WINDOW,
        )

        breaches: list[str] = []
        for body_size, budget_us in _PER_SIZE_BUDGETS_US:
            headers, body = _make_signed_payload(body_size)

            # Warm-up — pay first-call hash-state allocation costs
            # before the measurement window.
            for _ in range(50):
                verifier.verify(headers, body)

            n = 1000
            start = time.perf_counter()
            for _ in range(n):
                verifier.verify(headers, body)
            elapsed = time.perf_counter() - start
            per_call_us = (elapsed / n) * 1_000_000

            if per_call_us >= budget_us:
                breaches.append(
                    f"{body_size:>7} bytes: {per_call_us:.2f} µs "
                    f"(budget {budget_us:.0f} µs)"
                )

        assert not breaches, (
            "PC-02: HmacWebhookVerifier.verify budget breach:\n  "
            + "\n  ".join(breaches)
            + "\nInvestigate src/mgf/fastapi/webhooks/_verifier.py::"
            "HmacWebhookVerifier.verify — a non-linear regression "
            "(redundant body pass, regex, re-encode) breaches the "
            "larger sizes first."
        )
