"""PC-03: ``bearer_session`` dependency wrapper overhead.

The dependency returned by ``bearer_session()`` runs per protected
endpoint:

  1. `_extract_bearer_token(request, cookie_name)` — header read +
     scheme parse, optional cookie fallback. ~2-5 µs.
  2. `getattr(request.app.state, verifier_attr, None)` — ~1 µs.
  3. `await verifier.verify_session(token)` — THE COST. The
     verifier itself dominates (in-memory ~10 µs, JWT ~50 µs, IdP
     50-500 ms) — but the verifier's cost is **consumer-side** and
     NOT what this pin measures.

This test isolates the **wrapper overhead** by mocking
`verify_session` as a no-op coroutine returning a fixed principal.
What's left is exactly what mgf-fastapi owns: token extraction +
verifier lookup + the dependency-shape glue around the call.

Local baseline (Linux 6.17, Python 3.11, v0.4.0):
  - ~0.6 µs/call (no-op verifier).

Budget: 20 µs/call — ~35x cushion. Catches order-of-magnitude
regressions (an inadvertent O(N) header iteration, a new
synchronous I/O call, etc.) without false-positive on CI noise.

Marker: ``perf`` (registered in pyproject.toml). Excluded from
the default suite; run via ``pytest -m perf`` for the nightly
sweep.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import pytest
from fastapi import FastAPI
from starlette.requests import Request

from mgf.fastapi.security import bearer_session

# Per-call wrapper budget. EXCLUDES verifier cost (mocked away).
# Catches regressions in token extraction, verifier lookup, and
# the dependency-shape glue around the call.
_PER_CALL_BUDGET_US = 20.0


class _NoOpVerifier:
    """Fast no-op verifier — returns immediately with a fixed principal.

    The principal value is irrelevant; the test only measures the
    wrapper cost on the happy path.
    """

    async def verify_session(self, token: str) -> dict[str, Any]:
        return {"user": "perf-test"}


def _make_request_with_bearer(app: FastAPI) -> Request:
    """Build a synthetic Request with a valid Bearer header.

    Minimal scope so `_extract_bearer_token` runs the real header
    parse path; reuses the same Request across iterations (the
    dependency is stateless against the request).
    """
    scope: dict[str, Any] = {
        "type": "http",
        "app": app,
        "headers": [(b"authorization", b"Bearer perf-test-token-abcdef")],
    }
    return Request(scope)


@pytest.mark.perf
class TestBearerSessionWrapper:
    """Pin the per-call overhead of the bearer_session dependency."""

    def test_wrapper_under_budget(self) -> None:
        app = FastAPI()
        app.state.auth_provider = _NoOpVerifier()
        dep = bearer_session()
        request = _make_request_with_bearer(app)

        async def _drive() -> float:
            # Warm-up — first call pays cache costs.
            for _ in range(200):
                await dep(request)

            n = 10_000
            start = time.perf_counter()
            for _ in range(n):
                await dep(request)
            elapsed = time.perf_counter() - start
            return (elapsed / n) * 1_000_000

        per_call_us = asyncio.run(_drive())

        assert per_call_us < _PER_CALL_BUDGET_US, (
            f"PC-03: bearer_session wrapper budget breach: "
            f"{per_call_us:.2f} µs/call (budget "
            f"{_PER_CALL_BUDGET_US:.0f} µs). Investigate token "
            f"extraction + verifier lookup in "
            f"src/mgf/fastapi/security.py::bearer_session._dep."
        )
