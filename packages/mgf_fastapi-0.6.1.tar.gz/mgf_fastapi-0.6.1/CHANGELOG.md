# Changelog

All notable changes to `mgf-fastapi` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
the project follows [SemVer](https://semver.org/spec/v2.0.0.html). Per
the 0.x window ([SemVer 0.x](https://semver.org/#spec-item-4) and rule
**AP-03** from `mgf-common/docs/standards/API_DESIGN.md`), MINOR
releases MAY break the public API. Pin tightly:

```toml
mgf-fastapi = ">=0.X.0,<0.Y"   # one minor at a time
```

The release-engineering discipline that produces this changelog is in
[`mgf-common/docs/standards/RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md).

---

## [Unreleased]

Nothing yet.

---

## [0.6.1] — 2026-05-18

**Federation sync v2.10** — docs + tooling refresh; no library surface changes.

### Added
- `STARTHERE.md` + `CONTRIBUTING.md` (DOC-01 sibling MUSTs).
- `docs/CLAUDE.md` + `.claude/settings.json` (managed by `mgf-common catch-up`).

### Changed
- `mgf-common` pin: `>=0.36,<0.37` → `>=0.37,<0.38`.

### Federation
- Aligned with mgf-common v0.38.0 contract (DOC-13/14/15/16/17). Catch-up clean.

---

## [0.6.0] — 2026-05-18

PyPI: <https://pypi.org/project/mgf-fastapi/0.6.0/> · Tag: `v0.6.0`

> **Wave 2 sibling release — F-1 rate-limit middleware ships
> as a stdlib-only token-bucket primitive + Starlette/FastAPI
> middleware.** Skips v0.5.0 to align MINOR cadence with the
> mgf-common 0.36 / mgf-sqlalchemy 0.4 batch.

### Added — `RateLimitMiddleware` + `TokenBucket` (F-1)

Closes the F-1 federation row. PlasmaMapper is the immediate
adopter (the inthewords equivalent ships in mgf-django 0.4.0
as `D-1`).

Two public names (both `experimental` tier per AP-11):

- **`TokenBucket(*, capacity, refill_per_second)`** — pure-
  Python in-process token-bucket. Thread-safe; one bucket per
  key. `.try_consume(key) -> (allowed: bool, retry_after: float)`
  is the primitive. Multi-replica deployments wire a Redis-
  backed impl with the same shape externally.
- **`RateLimitMiddleware`** — Starlette/FastAPI middleware
  wrapping a `TokenBucket`. Accepts a `key(request) -> str | None`
  callable. Returns 429 with `Retry-After` (RFC 7231 integer-
  seconds) + JSON body `{"error": "rate-limit-exceeded",
  "retry_after": N}`. Returning `None` from the key function
  disables limiting per-request.

15 new unit tests cover algorithmic correctness (burst,
refill timing, per-key isolation, cap-at-capacity, reset
ergonomics) + middleware integration (passes-through,
429-when-exhausted, Retry-After header shape, None-key
bypass, multi-key isolation).

### Changed — pin bumps

- **`mgf-common>=0.33,<0.34` → `mgf-common>=0.36,<0.37`**
  (Wave 1 catch-up).
- **`mgf-sqlalchemy>=0.1,<0.2` → `mgf-sqlalchemy>=0.4,<0.5`**
  in the `[sqlalchemy]` extra (catches the new audit-trail +
  UUID v7 work).

### Verification

- pytest (excluding slow `lifespan_startup`): 152 passed
  (137 + 15 new).
- ruff: clean.
- mypy --strict: clean.

---

## [0.4.0] — 2026-05-15

PyPI: <https://pypi.org/project/mgf-fastapi/0.4.0/> · Tag: `v0.4.0`

> **v2.6 + v2.7 standards-compliance release.** The
> `mgf-common` documentation standard bumped to v2.6
> (project-shape taxonomy + LICENSE in the universal four)
> and v2.7 (DEPLOYMENT.md cloud-deployment standard). This
> release brings `mgf-fastapi` to the federation-sibling
> compliant shape: SECURITY.md + docs/claude/CLAUDE.md +
> docs/standards/README.md pointer-only stub. No code
> changes; documentation-only.

### Added — standards-compliance shape (v2.6 + v2.7)

- **`SECURITY.md`** at repo root — vulnerability-reporting
  policy per **SC-12** + the v2.6 universal-four root docs.
  Supported-versions table (`0.4.x` is the supported MINOR),
  private disclosure path (email or Codeberg security tab),
  90-day embargo default, scope (HMAC verifier + bearer
  session + IP allowlist + exception translation middleware
  + test API server). Out-of-scope notes for `fastapi` /
  `starlette` / `pydantic` (upstream).
- **`docs/claude/CLAUDE.md`** — AI-agent dense-lookup entry
  point per **DOC-07**. File map of every public name + the
  PAPER-24..29 paper provenance; cross-cutting patterns
  (request-id contextvar sharing with mgf-django, HMAC
  replay window, IP-allowlist proxy-trust, IdP-outage
  handling); build + release recipe; common pitfalls.
- **`docs/standards/README.md`** — pointer-only stub per
  **DOC-02** §2.0.4 Shape A. Cross-project standards live in
  `mgf-common/docs/standards/`; mgf-fastapi is a federation
  sibling and inherits them. Conformance target: L2.

### Engineering

- No code changes. This release is documentation-only; the
  `src/mgf/fastapi/` tree is byte-identical to v0.3.1.
- `mgf-common>=0.33,<0.34` runtime dependency unchanged from
  v0.3.1.

---

## [0.3.1] — 2026-05-11

PyPI: <https://pypi.org/project/mgf-fastapi/0.3.1/> · Tag: `v0.3.1`

> **Pin-walk patch release — no source change.** Walks the
> `mgf-common` pin forward to `>=0.33,<0.34`, the AP-12
> deprecation-removal release. `mgf-fastapi` source is clean of the
> three removed names (`mgf.common.configure`,
> `mgf.common.config.make_settings_config`,
> `mgf.common.exceptions.EnvironmentError`), so no code change is
> needed — only the dependency declaration moves.

### Changed

- **Dependency pin** — `mgf-common>=0.31,<0.32` → `mgf-common>=0.33,<0.34`.
  Lets consumers install `mgf-fastapi` alongside the current
  `mgf-common` line.

---

## [0.3.0] — 2026-05-10

PyPI: <https://pypi.org/project/mgf-fastapi/0.3.0/> · Tag: `v0.3.0`

> **Closes FEEDBACK PAPER-29** — `bearer_session` + `AuthVerifier`
> Protocol for "Authorization: Bearer → typed session principal" routes.
> Filed by PlasmaMapper after re-implementing the same ~30 LOC dependency
> on its own. Cutover guide: [`docs/cutover/v0.3.0.md`](docs/cutover/v0.3.0.md).

### Added

- **`mgf.fastapi.security.bearer_session(verifier_attr, *, cookie_name=None)`** —
  factory that returns a FastAPI dependency resolving
  `Authorization: Bearer <token>` (and, optionally, a session cookie for
  browser clients) to a typed principal. Reads an `AuthVerifier` from
  `app.state.<verifier_attr>` (`auth_provider` by default), calls
  `await verifier.verify_session(token)`, returns the principal.
- **`mgf.fastapi.security.AuthVerifier[P]`** — Protocol consumers
  implement to define the bearer-token → principal contract. Covariant
  in the principal type; consumers pick `P` (a dataclass, pydantic
  model, tenant-membership tuple, whatever).
- Case-insensitive Bearer scheme matching (RFC 7235).
- Optional `cookie_name` fallback for browser clients that store the
  token in an `HttpOnly` cookie. Header takes precedence.

### Behaviour guarantees

- Missing header, missing/empty token, wrong scheme: `HttpUnauthorized`
  ("missing bearer token").
- Verifier not wired on `app.state`: `HttpUnauthorized` to the caller +
  a noisy `LOG.error` to ops (deployment misconfig must not leak).
- Verifier raises `HttpUnauthorized` directly: pass-through (the
  verifier's message reaches the client).
- Verifier raises anything else (provider 500, expired JWT, network
  blip): translated to `HttpUnauthorized("invalid or expired session")`
  with the original exception chained via `__cause__`. The exception
  type name lands in a `LOG.info` line for debugging.
- `ExceptionTranslationMiddleware` resolves all `HttpUnauthorized`
  cases to a 401 JSON response via the HTTP-01 `http_status` fallback
  (no `status_map` extension required).

### Dependency bump

- **`mgf-common>=0.31,<0.32`** (was `>=0.30,<0.31`). Bumped in lock-step
  with mgf-common v0.31's release. The AP-03 0.x window pin discipline
  applies; consumers running mgf-common 0.30 keep their existing
  mgf-fastapi 0.2.x installs.

### Federation note

mgf-common is in its v0.32+ stabilization window (no new public surface
in mgf-common itself). Siblings retain autonomy to add public surface
in their own minors — this release exercises that autonomy.

---

## [0.2.0] — 2026-05-10

PyPI: <https://pypi.org/project/mgf-fastapi/0.2.0/> · Tag: `v0.2.0`

> **Paired with mgf-common v0.30.0** — picks up the FastAPI-shaped DB
> helpers extracted out of `mgf.common.db` at the v0.30 federation
> paired-extraction. The companion siblings (mgf-sqlalchemy v0.1.0,
> mgf-alembic v0.1.0) ship simultaneously. Cutover guide:
> [`docs/cutover/v0.2.0.md`](docs/cutover/v0.2.0.md).

### Added

- **`mgf.fastapi.db`** — submodule with `get_session` and `setup_db`,
  the FastAPI-shaped DB helpers that previously lived under
  `mgf.common.db.*` (mgf-common ≤ v0.29). They moved here at v0.30
  because the roadmap specified mgf-sqlalchemy as
  *framework-agnostic* — pulling Starlette into a "pure-SQLAlchemy"
  sibling would break that promise. mgf.fastapi.db imports from
  `mgf.sqlalchemy` (the new sibling).
- **`mgf.fastapi.db.get_session`** — FastAPI-Depends-compatible async
  generator. Yields one `AsyncSession` per request from
  `request.app.state.mgf_db_sessionmaker`. Closes via the context
  manager when the handler returns. Raises `AppConfigError` if
  the lifespan didn't run.
- **`mgf.fastapi.db.setup_db`** — async context manager for FastAPI
  lifespans. Creates the engine + sessionmaker via
  `mgf.sqlalchemy.create_engine` / `create_sessionmaker`, stashes
  them on `app.state.mgf_db_engine` / `app.state.mgf_db_sessionmaker`,
  and disposes the engine cleanly at lifespan exit.
- **`[sqlalchemy]` optional extra** — pulls `mgf-sqlalchemy>=0.1,<0.2`.
  Without it, `import mgf.fastapi.db` raises `ImportError` at load
  time with a message pointing at the missing extra.

### Changed

- **Runtime dep `mgf-common>=0.30,<0.31`** (was `>=0.28,<0.29`).
  AP-03 0.x window discipline — pin one minor at a time. mgf-common
  v0.30 strips out `mgf.common.db` and `mgf.common.alembic` (their
  surface lives in mgf-sqlalchemy and mgf-alembic now).

### Engineering

- 6 new tests (`tests/unit/test_db.py`) parity-preserved from
  `mgf-common/tests/unit/db/test_session.py` (FastAPI-Depends
  portions) and `tests/unit/db/test_db_lifespan.py`. The non-FastAPI
  portions of those files moved to `mgf-sqlalchemy/tests/unit/`.
- Total test count: 89 (was 83 in v0.1.0).
- mypy --strict still clean. Ruff still clean (in the new file).

---

## [0.1.0] — 2026-05-09

PyPI: <https://pypi.org/project/mgf-fastapi/0.1.0/> · Tag: `v0.1.0`

> **Maiden voyage** — extracted from `mgf-common` v0.28.0 per the
> federation split plan ([mgf-common/docs/release/federation_roadmap.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/release/federation_roadmap.md)).
> Cutover guide: [`docs/cutover/v0.1.0.md`](docs/cutover/v0.1.0.md).

### Added

- **`mgf.fastapi`** — top-level FastAPI integration. `bootstrap` ↔
  FastAPI lifespan (`setup_lifespan`); `RequestIdMiddleware` +
  `current_request_id()`; `ExceptionTranslationMiddleware` +
  `DEFAULT_STATUS_MAP`; `Depends()` helpers (`get_app_context`,
  `get_settings`, `get_request_id`); `REQUEST_ID_HEADER` constant.
- **`mgf.fastapi.webhooks`** — Svix-shape HMAC webhook verification.
  `WebhookHeaderSchema` (frozen dataclass; case-folds header names);
  `SVIX_SCHEMA` (Svix preset; used verbatim by Clerk);
  `HmacWebhookVerifier` (transport-agnostic core; thread-safe;
  `verify(headers, body) -> (event_id, ts)`); `verify_request`
  (async FastAPI request adapter).
- **`mgf.fastapi.security`** — `IpAllowlist` FastAPI dependency.
  CIDR allowlist with IPv4 + IPv6 dual-stack; cross-version matches
  deliberately rejected. `trust_proxy=False` default concentrates
  the proxy-trust footgun. Default `cidrs=LOOPBACK_CIDRS` so tests
  work out-of-the-box.
- **`mgf.fastapi.testing`** — `run_test_app` async context manager.
  Starts uvicorn for a FastAPI app on a free port; yields the base
  URL; tears down cleanly on context exit. Surfaces server-startup
  exceptions immediately instead of timing out silently. Optional
  `[testing]` extra pulls in `uvicorn>=0.30` + `httpx>=0.27`.
- **`mgf.fastapi.exceptions`** — `HmacVerificationError(HttpUnauthorized)`.
  Inherits the HTTP-01 status leaf from `mgf.common.exceptions` so
  PAPER-24's `http_status` resolution maps to 401 in
  `ExceptionTranslationMiddleware` without an explicit `status_map`
  entry. (Other concrete leaves can be added here in subsequent
  minors per the federation rule "siblings own their domain
  concretes; mgf-common owns hierarchy roots + status leaves.")

### Engineering

- 83 tests carried over from `mgf-common/tests/unit/fastapi/` —
  every pre-extraction failure mode and integration path stays
  green at parity. Coverage threshold ≥80% (matches mgf-common's
  standard).
- Imports from `mgf.common.fastapi.*` rewrite to `mgf.fastapi.*`.
  `HmacVerificationError` re-exported from `mgf.fastapi.exceptions`
  rather than `mgf.common.exceptions` (the latter no longer ships
  it as of mgf-common v0.28).
- `mgf-common>=0.28,<0.29` runtime dependency. AP-03 0.x window
  pin discipline applies — bump in lock-step with mgf-common's
  next minor.
- PEP 420 namespace package (no top-level `mgf/__init__.py`); the
  wheel ships `src/mgf/` as-is so `mgf.fastapi` and `mgf.common`
  coexist as siblings.
