# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Unit tests for sigv4_helper module."""

import httpx
import logging
import pytest
from httpx import __version__ as httpx_version
from mcp.types import Implementation
from mcp_proxy_for_aws import __version__
from mcp_proxy_for_aws.sigv4_helper import (
    SENSITIVE_HEADERS,
    SessionHolder,
    SigV4HTTPXAuth,
    _sanitize_headers,
    create_aws_session,
    create_sigv4_client,
)
from unittest.mock import Mock, patch


class TestSigV4HTTPXAuth:
    """Test cases for the SigV4HTTPXAuth class."""

    @pytest.mark.asyncio
    async def test_auth_flow_signs_request(self):
        """Test that auth_flow properly signs requests."""
        # Create mock credentials
        mock_credentials = Mock()
        mock_credentials.access_key = 'test_access_key'
        mock_credentials.secret_key = 'test_secret_key'
        mock_credentials.token = 'test_token'

        # Create a test request
        request = httpx.Request('GET', 'https://example.com/test', headers={'Host': 'example.com'})

        # Create auth instance
        auth = SigV4HTTPXAuth(mock_credentials, 'test-service', 'us-west-2')

        # Get signed request from auth flow
        auth_flow = auth.auth_flow(request)
        signed_request = next(auth_flow)

        # Verify request was signed (check for required SigV4 headers)
        assert 'Authorization' in signed_request.headers
        assert 'X-Amz-Date' in signed_request.headers


class TestCreateAwsSession:
    """Test cases for the create_aws_session function."""

    @patch('boto3.Session')
    def test_create_aws_session_default(self, mock_session_class):
        """Test creating AWS session with default profile."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session

        result = create_aws_session()

        mock_session_class.assert_called_once_with()
        assert result == mock_session

    @patch('boto3.Session')
    def test_create_aws_session_with_profile(self, mock_session_class):
        """Test creating AWS session with specific profile."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session

        result = create_aws_session(profile='test-profile')

        mock_session_class.assert_called_once_with(profile_name='test-profile')
        assert result == mock_session

    @patch('boto3.Session')
    def test_create_aws_session_no_credentials_returns_session(self, mock_session_class):
        """Test that session is returned even when no credentials are immediately available."""
        mock_session = Mock()
        mock_session.get_credentials.return_value = None
        mock_session_class.return_value = mock_session

        result = create_aws_session()

        assert result == mock_session

    @patch('boto3.Session')
    def test_create_aws_session_creation_failure(self, mock_session_class):
        """Test error handling when session creation fails."""
        # Mock session creation failure
        mock_session_class.side_effect = Exception('Session creation failed')

        # Test that ValueError is raised
        with pytest.raises(ValueError) as exc_info:
            create_aws_session(profile='invalid-profile')

        assert 'Failed to create AWS session' in str(exc_info.value)
        assert 'invalid-profile' in str(exc_info.value)


class TestCreateSigv4Client:
    """Test cases for the create_sigv4_client function."""

    @patch('mcp_proxy_for_aws.sigv4_helper.get_client_info', return_value=None)
    @patch('httpx.AsyncClient')
    def test_create_sigv4_client_default(self, mock_client_class, mock_get_client_info):
        """Test creating SigV4 client with default parameters."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        mock_session = Mock()
        session_holder = SessionHolder(mock_session)

        # Test client creation
        result = create_sigv4_client(
            service='test-service', region='test-region', session_holder=session_holder
        )

        # Check that AsyncClient was called with correct parameters
        call_args = mock_client_class.call_args
        assert 'auth' not in call_args[1], 'Auth should not be used, signing via hooks'
        assert 'event_hooks' in call_args[1]
        assert 'response' in call_args[1]['event_hooks']
        assert 'request' in call_args[1]['event_hooks']
        assert len(call_args[1]['event_hooks']['response']) == 1
        assert len(call_args[1]['event_hooks']['request']) == 2  # metadata + sign hooks
        assert call_args[1]['headers']['Accept'] == 'application/json, text/event-stream'
        expected_user_agent = f'python-httpx/{httpx_version} mcp-proxy-for-aws/{__version__}'
        assert call_args[1]['headers']['User-Agent'] == expected_user_agent
        assert result == mock_client

    @patch('mcp_proxy_for_aws.sigv4_helper.get_client_info', return_value=None)
    @patch('httpx.AsyncClient')
    def test_create_sigv4_client_with_custom_headers(
        self, mock_client_class, mock_get_client_info
    ):
        """Test creating SigV4 client with custom headers."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        session_holder = SessionHolder(Mock())

        # Test client creation with custom headers
        custom_headers = {'Custom-Header': 'custom-value'}
        result = create_sigv4_client(
            service='test-service',
            region='test-region',
            session_holder=session_holder,
            headers=custom_headers,
        )

        # Verify client was created with merged headers
        call_args = mock_client_class.call_args
        expected_headers = {
            'Accept': 'application/json, text/event-stream',
            'User-Agent': f'python-httpx/{httpx_version} mcp-proxy-for-aws/{__version__}',
            'Custom-Header': 'custom-value',
        }
        assert call_args[1]['headers'] == expected_headers
        assert result == mock_client

    @patch('httpx.AsyncClient')
    def test_create_sigv4_client_with_custom_service_and_region(self, mock_client_class):
        """Test creating SigV4 client with custom service and region."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client

        mock_session = Mock()
        mock_session.get_credentials.return_value = Mock(access_key='test-key')
        session_holder = SessionHolder(mock_session, profile='test-profile')

        # Test client creation with custom parameters
        result = create_sigv4_client(
            service='custom-service', session_holder=session_holder, region='us-east-1'
        )

        # Verify client was created
        assert result == mock_client

    @patch('httpx.AsyncClient')
    def test_create_sigv4_client_with_kwargs(self, mock_client_class):
        """Test creating SigV4 client with additional kwargs."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        session_holder = SessionHolder(Mock())

        # Test client creation with additional kwargs
        result = create_sigv4_client(
            service='test-service',
            region='test-region',
            session_holder=session_holder,
            verify=False,
            proxies={'http': 'http://proxy:8080'},
        )

        # Verify client was created with additional kwargs
        call_args = mock_client_class.call_args
        assert call_args[1]['verify'] is False
        assert call_args[1]['proxies'] == {'http': 'http://proxy:8080'}
        assert result == mock_client

    @patch('mcp_proxy_for_aws.sigv4_helper.get_client_info', return_value=None)
    @patch('httpx.AsyncClient')
    def test_create_sigv4_client_with_prompt_context(
        self, mock_client_class, mock_get_client_info
    ):
        """Test creating SigV4 client when prompts exist in the system context."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        session_holder = SessionHolder(Mock())

        prompt_context_headers = {
            'X-MCP-Prompt-Context': 'enabled',
            'Content-Type': 'application/json',
        }

        result = create_sigv4_client(
            service='test-service',
            session_holder=session_holder,
            headers=prompt_context_headers,
            region='us-west-2',
        )

        # Check that AsyncClient was called with correct parameters including prompt headers
        call_args = mock_client_class.call_args

        # Verify headers include both default and prompt-context headers
        expected_headers = {
            'Accept': 'application/json, text/event-stream',
            'User-Agent': f'python-httpx/{httpx_version} mcp-proxy-for-aws/{__version__}',
            'X-MCP-Prompt-Context': 'enabled',
            'Content-Type': 'application/json',
        }
        assert call_args[1]['headers'] == expected_headers

        # Verify error handling hook is present for prompt-related error responses
        assert 'event_hooks' in call_args[1]
        assert 'response' in call_args[1]['event_hooks']
        assert len(call_args[1]['event_hooks']['response']) == 1

        assert result == mock_client

    @patch('mcp_proxy_for_aws.sigv4_helper.get_client_info')
    @patch('httpx.AsyncClient')
    def test_create_sigv4_client_user_agent_excludes_client_info_when_telemetry_disabled(
        self, mock_client_class, mock_get_client_info
    ):
        """Test that User-Agent omits client info when disable_telemetry is True."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        session_holder = SessionHolder(Mock())
        mock_get_client_info.return_value = Implementation(name='My Client', version='2.0')

        result = create_sigv4_client(
            service='test-service',
            region='test-region',
            session_holder=session_holder,
            disable_telemetry=True,
        )

        call_args = mock_client_class.call_args
        user_agent = call_args[1]['headers']['User-Agent']
        assert 'python-httpx' in user_agent
        assert 'mcp-proxy-for-aws' in user_agent
        assert 'my-client' not in user_agent
        assert result == mock_client

    @patch('mcp_proxy_for_aws.sigv4_helper.get_client_info')
    @patch('httpx.AsyncClient')
    def test_create_sigv4_client_user_agent_includes_client_info_when_telemetry_enabled(
        self, mock_client_class, mock_get_client_info
    ):
        """Test that User-Agent includes client info when disable_telemetry is False."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        session_holder = SessionHolder(Mock())
        mock_get_client_info.return_value = Implementation(name='My Client', version='2.0')

        result = create_sigv4_client(
            service='test-service',
            region='test-region',
            session_holder=session_holder,
            disable_telemetry=False,
        )

        call_args = mock_client_class.call_args
        user_agent = call_args[1]['headers']['User-Agent']
        assert 'python-httpx' in user_agent
        assert 'mcp-proxy-for-aws' in user_agent
        assert 'my-client/2.0' in user_agent
        assert result == mock_client


class TestSessionHolder:
    """Test cases for the SessionHolder class."""

    def test_refresh_if_needed_noop_when_not_marked(self):
        """refresh_if_needed does nothing when not marked."""
        mock_session = Mock()
        holder = SessionHolder(mock_session)

        holder.refresh_if_needed()

        assert holder.session is mock_session

    @patch('mcp_proxy_for_aws.sigv4_helper.create_aws_session')
    def test_refresh_if_needed_creates_new_session_when_marked(self, mock_create):
        """refresh_if_needed replaces the session after mark_needs_refresh."""
        old_session = Mock()
        new_session = Mock()
        mock_create.return_value = new_session
        holder = SessionHolder(old_session, profile='my-profile')

        holder.mark_needs_refresh()
        holder.refresh_if_needed()

        mock_create.assert_called_once_with('my-profile')
        assert holder.session is new_session

    @patch('mcp_proxy_for_aws.sigv4_helper.create_aws_session')
    def test_refresh_clears_flag_on_success(self, mock_create):
        """After a successful refresh the flag is cleared — second call is a no-op."""
        mock_create.return_value = Mock()
        holder = SessionHolder(Mock())

        holder.mark_needs_refresh()
        holder.refresh_if_needed()
        mock_create.reset_mock()

        holder.refresh_if_needed()
        mock_create.assert_not_called()

    @patch('mcp_proxy_for_aws.sigv4_helper.create_aws_session')
    def test_refresh_keeps_flag_on_failure(self, mock_create):
        """If refresh fails the flag stays set so the next call retries."""
        old_session = Mock()
        mock_create.side_effect = ValueError('no creds')
        holder = SessionHolder(old_session)

        holder.mark_needs_refresh()
        holder.refresh_if_needed()

        # Session unchanged
        assert holder.session is old_session
        # Flag still set — next call retries
        mock_create.side_effect = None
        mock_create.return_value = Mock()
        holder.refresh_if_needed()
        assert mock_create.call_count == 2

    @patch('mcp_proxy_for_aws.sigv4_helper.create_aws_session')
    def test_refresh_logs_original_error_on_failure(self, mock_create, caplog):
        """Failed refresh logs the original ValueError."""
        mock_create.side_effect = ValueError('session creation boom')
        holder = SessionHolder(Mock())

        holder.mark_needs_refresh()
        with caplog.at_level(logging.WARNING):
            holder.refresh_if_needed()

        assert 'Failed to create fresh AWS session' in caplog.text
        assert 'session creation boom' in caplog.text


class TestSanitizeHeaders:
    """Test cases for the _sanitize_headers function."""

    def test_sanitize_headers_redacts_authorization(self):
        """Test that Authorization header is redacted."""
        headers = {
            'Authorization': 'AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/...',
            'Content-Type': 'application/json',
        }
        result = _sanitize_headers(headers)

        assert result['Authorization'] == '[REDACTED]'
        assert result['Content-Type'] == 'application/json'

    def test_sanitize_headers_redacts_security_token(self):
        """Test that x-amz-security-token header is redacted."""
        headers = {
            'x-amz-security-token': 'FwoGZXIvYXdzEBYaDK...',
            'Host': 'example.com',
        }
        result = _sanitize_headers(headers)

        assert result['x-amz-security-token'] == '[REDACTED]'
        assert result['Host'] == 'example.com'

    def test_sanitize_headers_redacts_amz_date(self):
        """Test that x-amz-date header is redacted."""
        headers = {
            'X-Amz-Date': '20260206T120000Z',
            'Accept': 'application/json',
        }
        result = _sanitize_headers(headers)

        assert result['X-Amz-Date'] == '[REDACTED]'
        assert result['Accept'] == 'application/json'

    def test_sanitize_headers_case_insensitive(self):
        """Test that header matching is case-insensitive."""
        headers = {
            'AUTHORIZATION': 'secret',
            'X-AMZ-SECURITY-TOKEN': 'secret',
            'x-amz-date': 'secret',
        }
        result = _sanitize_headers(headers)

        assert result['AUTHORIZATION'] == '[REDACTED]'
        assert result['X-AMZ-SECURITY-TOKEN'] == '[REDACTED]'
        assert result['x-amz-date'] == '[REDACTED]'

    def test_sanitize_headers_preserves_non_sensitive(self):
        """Test that non-sensitive headers are preserved."""
        headers = {
            'Content-Type': 'application/json',
            'Content-Length': '123',
            'Host': 'example.amazonaws.com',
            'User-Agent': 'test-client/1.0',
        }
        result = _sanitize_headers(headers)

        assert result == headers

    def test_sanitize_headers_empty_dict(self):
        """Test handling of empty headers dictionary."""
        result = _sanitize_headers({})
        assert result == {}

    def test_sensitive_headers_constant_is_frozen(self):
        """Test that SENSITIVE_HEADERS is immutable."""
        assert isinstance(SENSITIVE_HEADERS, frozenset)
        assert 'authorization' in SENSITIVE_HEADERS
        assert 'x-amz-security-token' in SENSITIVE_HEADERS
        assert 'x-amz-date' in SENSITIVE_HEADERS
