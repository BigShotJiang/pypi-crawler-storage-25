"""Pytest fixtures shared across the Fred test suite.

The web_search and web_fetch test files used to duplicate
``client_in_context`` and ``fresh_stats`` verbatim. Now both consume
the fixtures defined here. Each fixture drains the stats stash on
both web tools so a test that crosses tool boundaries (or a mis-
ordered fixture import) starts from a clean slate either way.
"""
from __future__ import annotations

import pytest

from fred.client import DSClient
from fred.tools._web_client import reset_active_client, set_active_client
from fred.tools.web_fetch import consume_last_stats as _drain_fetch
from fred.tools.web_search import consume_last_stats as _drain_search


def _drain_all_web_stats() -> None:
    _drain_search()
    _drain_fetch()


@pytest.fixture
def client_in_context():
    """Build a DSClient pointed at the proxy and install it as the active client.

    Used by both web_search and web_fetch tests; the base_url matches
    the PROXY_URL constants in those files.
    """
    c = DSClient(api_key="fred_live_test", base_url="https://api.fredcode.net/v1")
    token = set_active_client(c)
    yield c
    reset_active_client(token)
    _drain_all_web_stats()  # drain stash so other tests start clean


@pytest.fixture
def fresh_stats():
    """Drain web-tool stats stashes before and after the test."""
    _drain_all_web_stats()
    yield
    _drain_all_web_stats()
