"""web_search tool: Tavily /search via the FredWeb proxy.

Authoritative billing happens server-side in the Cloudflare Worker; the
CLI just POSTs to `/v1/web/search` with a Tavily-shape body and reads
the cost back from the `x-fred-web-cost-microcents` response header.

Stats are stashed in a ContextVar following the bash precedent so
session.py can drain them and emit a `web_search` tracer event.
"""
from __future__ import annotations

import time
import urllib.parse
from typing import Literal

from pydantic import BaseModel, Field

from fred._constants import WEB_HARD_BYTE_CAP
from fred.tools._web_client import (
    WebStatsCollector,
    format_web_error,
    get_active_client,
    parse_header_int,
)
from fred.tools.base import Tool, truncate

_stats = WebStatsCollector("fred_web_search_last_stats")


def consume_last_stats() -> dict | None:
    return _stats.consume()


class WebSearchArgs(BaseModel):
    query: str = Field(..., min_length=1, max_length=400)
    max_results: int = Field(5, ge=1, le=20)
    search_depth: Literal["basic", "advanced"] = "basic"
    topic: Literal["general", "news", "finance"] = "general"
    include_answer: bool = True
    include_domains: list[str] | None = None
    exclude_domains: list[str] | None = None
    days: int | None = Field(None, ge=1, le=365)
    time_range: Literal["day", "week", "month", "year"] | None = None


def _top_domain(results: list[dict]) -> str | None:
    if not results:
        return None
    try:
        return urllib.parse.urlparse(results[0].get("url", "")).hostname
    except Exception:
        return None


def run(args: WebSearchArgs) -> str:
    client = get_active_client()
    if client is None:
        return (
            "Error: web_search has no active client. This is a Fred bug — "
            "tool dispatch ran outside `run_session`."
        )

    body = args.model_dump(exclude_none=True)
    t0 = time.perf_counter()
    base_stats = {
        "query_chars": len(args.query),
        "search_depth": args.search_depth,
        "topic": args.topic,
        "max_results": args.max_results,
    }

    try:
        data, headers = client.web_call("search", body)
    except Exception as e:
        wire, err_class, http_status = format_web_error(e, "web_search")
        _stats.set({
            "ok": False,
            "http_status": http_status,
            "error_class": err_class,
            "result_count": 0,
            "top_domain": None,
            "tavily_response_time": None,
            "include_answer_used": False,
            "truncated": False,
            "bytes_returned": len(wire.encode("utf-8")),
            "duration_ms": int((time.perf_counter() - t0) * 1000),
            "cost_billed_microcents": None,
            "credits_consumed": None,
            "balance_after_microcents": None,
            **base_stats,
        })
        return wire

    results = data.get("results") or []
    answer = data.get("answer") if args.include_answer else None

    parts = [f"{len(results)} result(s) for: {args.query}"]
    if answer:
        parts.append(f"\nTavily summary: {answer}\n")
    for i, r in enumerate(results, 1):
        parts.append(f"- [{i}] {r.get('title', '(no title)')}")
        parts.append(f"  url: {r.get('url', '')}")
        try:
            parts.append(f"  score: {float(r.get('score', 0)):.2f}")
        except (TypeError, ValueError):
            pass
        if r.get("content"):
            parts.append(f"  excerpt: {r['content'][:500]}")

    raw = "\n".join(parts)
    raw_bytes = len(raw.encode("utf-8"))
    truncated_flag = raw_bytes > WEB_HARD_BYTE_CAP
    out = truncate(raw, limit=WEB_HARD_BYTE_CAP)

    _stats.set({
        "ok": True,
        "http_status": 200,
        "error_class": None,
        "result_count": len(results),
        "top_domain": _top_domain(results),
        "tavily_response_time": data.get("response_time"),
        "include_answer_used": bool(answer),
        "truncated": truncated_flag,
        "bytes_returned": len(out.encode("utf-8")),
        "duration_ms": int((time.perf_counter() - t0) * 1000),
        "cost_billed_microcents": parse_header_int(headers, "x-fred-web-cost-microcents"),
        "credits_consumed": parse_header_int(headers, "x-fred-web-credits"),
        "balance_after_microcents": parse_header_int(headers, "x-fred-balance-microcents"),
        **base_stats,
    })
    return out


tool = Tool(
    name="web_search",
    description=(
        "Search the live web via Tavily. Returns ranked results with title, "
        "url, relevance score, and short excerpt. Use this when the question "
        "depends on facts newer than your training data, on URLs the user "
        "mentioned, or on third-party documentation. After searching, call "
        "`web_fetch` to read the most promising result(s) in full. "
        "Costs ~$0.020 per basic search, ~$0.040 per advanced search."
    ),
    args_model=WebSearchArgs,
    handler=run,
    requires_permission=True,
)
