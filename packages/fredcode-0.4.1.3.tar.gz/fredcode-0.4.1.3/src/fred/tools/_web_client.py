"""Session-scoped accessor for the active DSClient + shared web-tool helpers.

Web research tools (`web_search`, `web_fetch`) need to call the proxy at
`/v1/web/{search,extract}` but the existing tool-handler signature is
``(args: BaseModel) -> str`` — the handler doesn't receive the client.
We expose the running session's client via a ContextVar that ``run_session``
sets at entry and clears on exit.

Tests can override this directly with ``set_active_client(stub)``.

This module also hosts helpers shared between ``web_search`` and
``web_fetch``: a stats-stash (``WebStatsCollector``) and the exception →
wire-message + stats-payload mapping (``format_web_error``). Both tools
were near-twins before the refactor; the helpers keep wire output
byte-identical to the bespoke logic that came before.
"""
from __future__ import annotations

import contextvars
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from fred.client import DSClient

_ACTIVE_CLIENT: contextvars.ContextVar["DSClient | None"] = contextvars.ContextVar(
    "fred_active_client", default=None,
)


def set_active_client(client: "DSClient | None") -> contextvars.Token:
    return _ACTIVE_CLIENT.set(client)


def reset_active_client(token: contextvars.Token) -> None:
    _ACTIVE_CLIENT.reset(token)


def get_active_client() -> "DSClient | None":
    return _ACTIVE_CLIENT.get()


def parse_header_int(headers: dict, name: str) -> int | None:
    """Extract an integer-valued header (case-insensitive lookup).

    The Cloudflare Worker emits ``x-fred-web-cost-microcents`` and
    friends as bare integers. Returns ``None`` if the header is absent
    or the value isn't parseable — callers treat both as "no info"
    rather than failing.
    """
    v = headers.get(name) or headers.get(name.lower())
    if v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


class WebStatsCollector:
    """Per-tool ContextVar wrapper for the last-call stats stash.

    Each web tool instantiates one collector with its own ContextVar
    name. ``set(stats)`` stores a payload; ``consume()`` returns it
    once and clears the slot. This matches the bash precedent:
    session.py drains stats after each tool call to emit a tracer event.
    """

    def __init__(self, name: str) -> None:
        self._var: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
            name, default=None,
        )

    def set(self, stats: dict) -> None:
        self._var.set(stats)

    def consume(self) -> dict | None:
        s = self._var.get()
        if s is not None:
            self._var.set(None)
        return s


def format_web_error(exc: BaseException, tool_name: str) -> tuple[str, str, int | None]:
    """Map a web-call exception to (wire_message, error_class, http_status).

    ``tool_name`` is ``"web_search"`` or ``"web_fetch"`` and is only
    threaded into the wire string for ``HTTPStatusError`` and the
    generic-Exception fallback (the disabled / out-of-credits messages
    don't mention the tool by name today, and we keep them byte-identical).

    The caller is responsible for assembling the full stats payload
    around the returned error class + http status — only those two
    fields differ between the two tools' error paths.
    """
    from fred.auth import InsufficientCreditsError, WebResearchDisabledError

    if isinstance(exc, WebResearchDisabledError):
        err_class = "web_research_disabled"
        wire = (
            f"Error: web research is disabled. "
            f"Enable it at {exc.settings_url}"
        )
    elif isinstance(exc, InsufficientCreditsError):
        err_class = "insufficient_credits"
        wire = f"Error: out of credits. Top up at {exc.topup_url}"
    elif isinstance(exc, httpx.HTTPStatusError):
        err_class = "HTTPStatusError"
        wire = (
            f"Error: {tool_name} HTTP {exc.response.status_code}: "
            f"{exc.response.text[:300]}"
        )
    else:
        err_class = type(exc).__name__
        wire = f"Error: {tool_name} failed: {err_class}: {exc}"

    http_status = getattr(getattr(exc, "response", None), "status_code", None)
    return wire, err_class, http_status
