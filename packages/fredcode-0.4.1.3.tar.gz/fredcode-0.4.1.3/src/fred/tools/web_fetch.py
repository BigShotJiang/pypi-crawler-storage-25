"""web_fetch tool: Tavily /extract via the FredWeb proxy.

Fetches up to 20 URLs at once and returns concatenated cleaned content.
Server-side billed; CLI-side capped at 100KB total to prevent context blowup.
"""
from __future__ import annotations

import time
from typing import Literal

from pydantic import BaseModel, Field

from fred._constants import WEB_HARD_BYTE_CAP
from fred.tools._web_client import (
    WebStatsCollector,
    format_web_error,
    get_active_client,
    parse_header_int,
)
from fred.tools.base import Tool, truncate

_stats = WebStatsCollector("fred_web_fetch_last_stats")


def consume_last_stats() -> dict | None:
    return _stats.consume()


class WebFetchArgs(BaseModel):
    urls: list[str] = Field(..., min_length=1, max_length=20)
    extract_depth: Literal["basic", "advanced"] = "basic"
    format: Literal["markdown", "text"] = "markdown"
    include_images: bool = False


def run(args: WebFetchArgs) -> str:
    client = get_active_client()
    if client is None:
        return (
            "Error: web_fetch has no active client. This is a Fred bug — "
            "tool dispatch ran outside `run_session`."
        )

    body = args.model_dump(exclude_none=True)
    t0 = time.perf_counter()
    base_stats = {
        "urls_requested": len(args.urls),
        "extract_depth": args.extract_depth,
        "format": args.format,
        "include_images": args.include_images,
    }

    try:
        data, headers = client.web_call("extract", body)
    except Exception as e:
        wire, err_class, http_status = format_web_error(e, "web_fetch")
        _stats.set({
            "ok": False,
            "http_status": http_status,
            "error_class": err_class,
            "success_count": 0,
            "failed_count": 0,
            "per_url_bytes": [],
            "total_bytes": 0,
            "truncated": False,
            "truncated_at_url": None,
            "bytes_returned": len(wire.encode("utf-8")),
            "tavily_response_time": None,
            "duration_ms": int((time.perf_counter() - t0) * 1000),
            "cost_billed_microcents": None,
            "credits_consumed": None,
            "balance_after_microcents": None,
            **base_stats,
        })
        return wire

    ok_results = data.get("results") or []
    failed = data.get("failed_results") or []

    parts = [f"[ok {len(ok_results)}/{len(args.urls)} URLs]"]
    per_url_bytes: list[int] = []
    running = sum(len(p.encode("utf-8")) for p in parts)
    truncated_at_url: int | None = None
    for i, r in enumerate(ok_results, 1):
        url = r.get("url", "")
        content = r.get("raw_content") or ""
        per_url_bytes.append(len(content.encode("utf-8")))
        block = f"\n--- [{i}] {url} ---\n{content}"
        if running + len(block.encode("utf-8")) > WEB_HARD_BYTE_CAP:
            truncated_at_url = i
            parts.append(
                f"\n[truncated at URL {i} — page byte cap "
                f"{WEB_HARD_BYTE_CAP} reached]"
            )
            break
        parts.append(block)
        running += len(block.encode("utf-8"))
    for f in failed:
        parts.append(f"\n[failed] {f.get('url', '?')}: {f.get('error', 'unknown')}")

    out = truncate("\n".join(parts), limit=WEB_HARD_BYTE_CAP)

    _stats.set({
        "ok": True,
        "http_status": 200,
        "error_class": None,
        "success_count": len(ok_results),
        "failed_count": len(failed),
        "per_url_bytes": per_url_bytes,
        "total_bytes": sum(per_url_bytes),
        "truncated": truncated_at_url is not None,
        "truncated_at_url": truncated_at_url,
        "bytes_returned": len(out.encode("utf-8")),
        "tavily_response_time": data.get("response_time"),
        "duration_ms": int((time.perf_counter() - t0) * 1000),
        "cost_billed_microcents": parse_header_int(headers, "x-fred-web-cost-microcents"),
        "credits_consumed": parse_header_int(headers, "x-fred-web-credits"),
        "balance_after_microcents": parse_header_int(headers, "x-fred-balance-microcents"),
        **base_stats,
    })
    return out


tool = Tool(
    name="web_fetch",
    description=(
        "Fetch and clean the full content of up to 20 URLs via Tavily extract. "
        "Use after `web_search` (or when the user gives you a URL) to read pages "
        "in full. Returns concatenated content with `--- [N] <url> ---` separators "
        "and a byte cap (~100KB total). Costs ~$0.020 per 5 URLs basic, "
        "~$0.040 per 5 URLs advanced."
    ),
    args_model=WebFetchArgs,
    handler=run,
    requires_permission=True,
)
