"""Module-level numeric constants. Imported by callers; never mutated.

Adding a constant here is preferable to inlining a literal when the value
is referenced from more than one module, OR when its semantic meaning
isn't obvious from the literal at the call site.
"""
from __future__ import annotations

WEB_HARD_BYTE_CAP: int = 100_000
"""Upper bound on web_search / web_fetch response body bytes returned
to the model after truncation. Both tools enforce this independently."""

TRUNCATE_HEAD_DEFAULT: int = 25_000
"""Default head byte count for truncate_head_tail in tools/_text_utils."""

TRUNCATE_TAIL_DEFAULT: int = 25_000
"""Default tail byte count for truncate_head_tail in tools/_text_utils."""

BASH_PROGRESS_SAMPLE: int = 10
"""Heartbeat interval (in stream lines) for showing background-bash progress."""

MENU_RESERVED_LINES: int = 8
"""Lines of terminal height the slash-completion menu reserves below
the prompt cursor."""
