"""Tests for CLI commands using haiv.test framework."""

import os

from haiv_mail import commands
from haiv import test


def test_routes_to_inbox():
    match = test.routes_to("inbox", commands)
    assert match is not None


def test_routes_to_send():
    match = test.routes_to("send", commands)
    assert match is not None


def test_routes_to_read_with_id():
    match = test.routes_to("read abc123", commands)
    assert match is not None


def test_routes_to_reply_with_id():
    match = test.routes_to("reply abc123", commands)
    assert match is not None


def test_routes_to_delete_with_id():
    match = test.routes_to("delete abc123", commands)
    assert match is not None


def test_routes_to_thread_with_id():
    match = test.routes_to("thread abc123", commands)
    assert match is not None


def test_routes_to_sent():
    match = test.routes_to("sent", commands)
    assert match is not None


def test_routes_to_wait():
    match = test.routes_to("wait", commands)
    assert match is not None


def test_routes_to_who():
    match = test.routes_to("who", commands)
    assert match is not None


def test_routes_to_contacts():
    match = test.routes_to("contacts", commands)
    assert match is not None


def test_parse_send_flags():
    ctx = test.parse("send --to luna@haiv --subject hello --body hi", commands)
    assert ctx.args.get_one("to") == "luna@haiv"
    assert ctx.args.get_one("subject") == "hello"
    assert ctx.args.get_one("body") == "hi"


def test_parse_wait_flags():
    ctx = test.parse("wait --from 仁@haiv-mail --timeout 30", commands)
    assert ctx.args.get_one("from") == "仁@haiv-mail"
    assert ctx.args.get_one("timeout") == "30"


def test_parse_read_captures_id():
    ctx = test.parse("read abc123", commands)
    assert ctx.args.get_one("id") == "abc123"


def test_parse_reply_captures_id():
    ctx = test.parse("reply abc123 --body response", commands)
    assert ctx.args.get_one("id") == "abc123"
    assert ctx.args.get_one("body") == "response"


def test_execute_inbox_empty(capsys):
    os.environ["HV_MIND"] = "testmind"
    try:
        test.execute("inbox", commands)
        captured = capsys.readouterr()
        assert "No messages" in captured.out
    finally:
        del os.environ["HV_MIND"]
