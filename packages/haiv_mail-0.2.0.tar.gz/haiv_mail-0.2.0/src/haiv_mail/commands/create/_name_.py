from haiv import cmd

from haiv_mail.commands._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="Create a mailing list",
        flags=[
            cmd.Flag("description", min_args=0),
        ],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    name = ctx.args.get_one("name")
    desc = ctx.args.get_one("description", default_value="")

    try:
        mb.create_list(name, me, description=desc)
    except ValueError as e:
        ctx.print(str(e))
        return

    ctx.print(f"Created list '{name}'")
    if desc:
        ctx.print(f"  {desc}")
