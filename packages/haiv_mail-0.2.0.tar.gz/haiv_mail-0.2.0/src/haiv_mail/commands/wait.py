from haiv import cmd
from haiv_mail import Address

from haiv_mail.commands._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="Wait for new mail (blocks until a message arrives)",
        flags=[
            cmd.Flag("from", min_args=0),
            cmd.Flag("timeout", min_args=0),
        ],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)

    from_raw = ctx.args.get_one("from", default_value=None)
    from_addr = Address.parse(from_raw) if from_raw else None
    timeout_raw = ctx.args.get_one("timeout", default_value=None)
    timeout = float(timeout_raw) if timeout_raw else None

    # Check for mutual wait deadlock before blocking
    if from_addr and mb._check_mutual_wait(me, from_addr):
        ctx.print(f"Warning: {from_addr} is already waiting for you. You would both be blocking.")
        ctx.print(f"Consider sending them a message first.")
        ctx.print(f"")

    if from_addr:
        ctx.print(f"Waiting for mail from {from_addr}...")
    else:
        ctx.print("Waiting for mail...")

    msg = mb.wait(me, from_addr=from_addr, timeout=timeout)

    if msg is None:
        ctx.print("Timed out — no new messages.")
        ctx.print("Run hv mail wait again with a longer --timeout if you're not busy.")
    else:
        ctx.print(f"")
        ctx.print(f"New message from {msg.sender}: \"{msg.subject}\"")
        ctx.print(f"Run: hv mail read {msg.id}")
        ctx.print(f"Run hv mail wait again if you're expecting more.")
