from haiv import cmd

from haiv_mail.commands._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="View a conversation thread",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    message_id = ctx.args.get_one("id")

    # Try DM thread first, then list thread
    thread = mb.thread(me, message_id)
    if not thread:
        thread = mb.list_thread(message_id)
    if not thread:
        ctx.print(f"No thread found for {message_id}")
        return

    for i, msg in enumerate(thread):
        ts = msg.timestamp.strftime("%Y-%m-%d %H:%M UTC")
        ctx.print(f"--- {msg.sender} ({ts}) ---")
        ctx.print(f"Subject: {msg.subject}")
        ctx.print(f"")
        ctx.print(msg.body)
        if i < len(thread) - 1:
            ctx.print(f"")
