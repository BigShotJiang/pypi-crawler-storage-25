from haiv import cmd

from haiv_mail.commands._resolve import mailbox


def define() -> cmd.Def:
    return cmd.Def(
        description="Show minds currently waiting for mail",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    waiting = mb.list_waiting()

    if not waiting:
        ctx.print("Nobody is waiting.")
        return

    for w in waiting:
        elapsed = _elapsed(w.started_at)
        if w.waiting_for:
            ctx.print(f"  {w.address}  waiting for {w.waiting_for}  ({elapsed})")
        else:
            ctx.print(f"  {w.address}  waiting for anyone  ({elapsed})")


def _elapsed(started_at) -> str:
    from datetime import datetime, timezone

    delta = datetime.now(timezone.utc) - started_at
    minutes = int(delta.total_seconds() / 60)
    if minutes < 1:
        return "just now"
    if minutes == 1:
        return "1 min"
    return f"{minutes} min"
