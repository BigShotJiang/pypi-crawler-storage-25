from haiv import cmd

from haiv_mail.commands._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="Read a specific message",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    message_id = ctx.args.get_one("id")

    # Try DM first, then list post
    msg = mb.read_message(me, message_id)
    if msg is None:
        msg = mb.read_list_post(message_id)
    if msg is None:
        ctx.print(f"No message with id {message_id}")
        return

    ts = msg.timestamp.strftime("%Y-%m-%d %H:%M UTC")
    recipients = ", ".join(str(r) for r in msg.recipients)
    ctx.print(f"From:    {msg.sender}")
    ctx.print(f"To:      {recipients}")
    ctx.print(f"Date:    {ts}")
    ctx.print(f"Subject: {msg.subject}")
    ctx.print(f"")
    ctx.print(msg.body)
