from haiv import cmd

from haiv_mail.commands._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="Delete a message from your inbox",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)
    message_id = ctx.args.get_one("id")

    if mb.delete_message(me, message_id):
        ctx.print(f"Deleted {message_id}")
    else:
        ctx.print(f"No message with id {message_id}")
