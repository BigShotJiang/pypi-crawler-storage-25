from haiv import cmd

from haiv_mail.commands._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="List minds you have communicated with",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)

    addrs = mb.contacts(me)
    if not addrs:
        ctx.print("No contacts yet.")
        return

    for addr in addrs:
        ctx.print(f"  {addr}")
