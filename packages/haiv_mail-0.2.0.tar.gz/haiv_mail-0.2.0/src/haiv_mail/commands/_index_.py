"""hv mail - Show what's new across DMs and mailing lists."""

from haiv import cmd

from haiv_mail.commands._resolve import mailbox, sender


def define() -> cmd.Def:
    return cmd.Def(
        description="What's new — DMs and mailing list activity",
        flags=[],
    )


def execute(ctx: cmd.Ctx) -> None:
    mb = mailbox()
    me = sender(ctx)

    # DMs
    unread = mb.unread_ids(me)
    messages = mb.list_messages(me)
    unread_msgs = [m for m in messages if m.id in unread]

    # List activity
    list_activity = mb.list_unread_activity(me)

    if not unread_msgs and not list_activity:
        ctx.print("Nothing new.")
        ctx.print("")
        ctx.print("  hv mail send <addr> --subject <s> --body <b>")
        ctx.print("  hv mail lists")
        ctx.print("  hv mail wait")
        return

    if unread_msgs:
        ctx.print("DMs:")
        for msg in unread_msgs:
            ts = msg.timestamp.strftime("%Y-%m-%d %H:%M")
            ctx.print(f"  * {msg.id}  {ts}  {msg.sender}  {msg.subject}")
        ctx.print("")

    if list_activity:
        ctx.print("Lists:")
        for item in list_activity:
            ctx.print(f"  * {item['list']}  {item['count']} new")
        ctx.print("")

    ctx.print("  hv mail read <id>          read a message")
    ctx.print("  hv mail browse <list>      see list threads")
