from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional
from typing import Any
from typing import Dict
from typing import List


class ApplyPaymentMethodResult(BaseModel):
    updated_subscription_pub_ids: Optional[List[str]] = None
    already_set_subscription_pub_ids: Optional[List[str]] = None
    update_failed_subscription_pub_ids: Optional['Dict[str, Any]'] = None


ApplyPaymentMethodResult.model_rebuild()
