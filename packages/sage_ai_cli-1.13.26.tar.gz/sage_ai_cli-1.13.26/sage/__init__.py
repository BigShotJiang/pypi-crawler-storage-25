"""Sage — a local-first AI coding CLI."""

__version__ = "1.13.26"
