"""Sage CLI — local-first AI coding assistant.

Usage:
  sage run                              Interactive coding agent (Claude Code-like)
  sage chat                             Interactive chat session
  sage ask "explain quicksort"          One-shot prompt
  sage ask -f script.py "explain"       Ask about a file
  cat file.py | sage ask "explain"      Pipe input
  sage models                           List available models
  sage config show                      Show current config
  sage config set <key> <value>         Set a config value

Module Structure Migration (P1-17):
    This file contains legacy class definitions that have modern equivalents
    in sage/core/. To reduce duplication, classes should migrate to use
    sage/core/ imports:

    - Checkpoint, CheckpointManager -> sage.core.checkpoint
    - SecurityFinding, SecurityAuditor -> sage.core.security
    - FileNode, DependencyGraph -> sage.core.dependencies
    - TaskType, SwarmTask, SwarmOrchestrator -> sage.core.swarm
    - ContextCompactor -> sage.core.context_management
    - ExecutionPhase, PlanTask, ExecutionPlan -> sage.core.procedural_workflow

    Until full migration, the local definitions remain for backward compatibility.
"""

from __future__ import annotations

import json as _json
import logging
import re
import shlex
import signal
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

import typer
from typing_extensions import Annotated

# Set up logger for SAGE
logger = logging.getLogger("sage")

from sage import __version__
from sage.config import (
    SageConfig,
    load_config,
    save_config,
    set_config_value,
    get_config_value,
)
from sage.core import renderer
from sage.core.engine import ConversationEngine
from sage.core.router import ProviderRouter
from sage.providers.base import ProviderBase, ModelInfo, Message
from sage.providers.gemini import GeminiProvider
from sage.providers.llama_cpp import LlamaCppProvider
from sage.providers.openai_compat import (
    build_openai_compat_providers,
    OllamaProvider,
)
from sage.models.catalog import (
    MODEL_CATALOG,
    CATALOG_BY_NAME,
    search_catalog,
    get_recommended_models,
    OLLAMA_CATALOG,
    OLLAMA_BY_NAME,
    search_ollama_catalog,
    get_recommended_ollama_models,
    get_ollama_models_by_category,
)
from sage.models.downloader import (
    download_model,
    register_model,
    is_downloaded,
    model_path,
    list_downloaded,
    delete_model,
)

# ══════════════════════════════════════════════════════════════════════════════
# ENHANCED AI CAPABILITIES - Advanced reasoning, code generation, and execution
# ══════════════════════════════════════════════════════════════════════════════

from sage.reasoning import (
    ChainOfThoughtReasoner,
    SelfReflectionEngine,
    MultiPerspectiveAnalyzer,
    ErrorDiagnosis,
    ReasoningContext,
    ReasoningPhase,
)
from sage.execution import (
    AdaptiveExecutionEngine,
    TaskScheduler,
    ParallelExecutor,
    SmartRetryHandler,
    ExecutionTask,
    TaskPriority,
    TaskStatus,
    RetryConfig,
    RetryStrategy,
)
from sage.core.ai_orchestration import (
    AIOrchestrator,
    AIDecompositionEngine,
    AIComplexityAssessor,
    AIPlanGenerator,
    AIChainOfThoughtReasoner,
)
from sage.core.procedural_workflow import (
    ProceduralWorkflowOrchestrator,
    WorkflowResult,
    WorkflowStep,
)
from sage.core.phd_agent import (
    PhDAgent,
    PhDAgentUI,
    StrategicResult,
    ExecutionLoopResult,
    AgentResult,
)
from sage.codegen import (
    CodeAnalyzer,
    CodeGenerator,
    CodeValidator,
    StyleEnforcer,
    CodeContext,
)
from sage.core.discovery import (
    FileDiscovery,
    DiscoveryResult,
    ProjectInfo,
    discover_files,
    discover_modules,
)
from sage.core.task_priority import (
    TaskPrioritizer,
    TaskCategory,
    CheckClass,
    PrioritizedTask,
)
from sage.core.prompts import (
    CHAIN_OF_THOUGHT_INSTRUCTIONS,
    AGENT_SYSTEM_PROMPT_TEMPLATE,
    LOCAL_AGENT_SYSTEM_PROMPT_TEMPLATE,
    build_agent_system_prompt,
)
from sage.core.validation import (
    validate_python_syntax as _validate_python_syntax,
    validate_json_syntax as _validate_json_syntax,
    pre_validate_content as _pre_validate_content,
    extract_imports_from_python as _extract_imports_from_python,
    pending_modules_for_files as _pending_modules_for_files,
    module_exists_in_codebase as _module_exists_in_codebase,
    validate_imports_in_content as _validate_imports_in_content,
    is_likely_hallucinated_code as _is_likely_hallucinated_code,
    is_garbage_content as _is_garbage_content,
    validate_file_path_against_codebase as _validate_file_path_against_codebase,
    STDLIB_MODULES,
    COMMON_PACKAGES,
)
from sage.core.shell import (
    extract_scoped_prefix as _extract_scoped_prefix,
    resolve_scoped_directory as _resolve_scoped_directory,
    run_shell as _run_shell,
    shell_quote as _shell_quote,
    extract_bash_blocks as _extract_bash_blocks,
    sanitize_shell_block as _sanitize_shell_block,
    strip_search_comment as _strip_search_comment,
    read_file_context as _read_file_context,
)
from sage.core.commands import (
    execute_command as _execute_command,
    execute_argv as _execute_argv,
)
from sage.core.project import (
    detect_test_files as _detect_test_files,
    detect_runnable_files as _detect_runnable_files,
    discover_workspace_project_roots as _discover_workspace_project_roots,
    project_root_score as _project_root_score,
    default_project_root as _default_project_root,
    discover_npm_script as _discover_npm_script,
    discover_python_test_command as _discover_python_test_command,
    discover_project_test_command as _discover_project_test_command,
    discover_project_full_test_command as _discover_project_full_test_command,
    discover_project_root_for_file as _discover_project_root_for_file,
    command_from_project_root as _command_from_project_root,
    validation_command_for_written_files as _validation_command_for_written_files,
)
from sage.core.request_classifier import (
    RequestType as _RequestType,
    ClassifiedRequest as _ClassifiedRequest,
    RequestClassifier as _RequestClassifier,
    validate_response as _validate_classified_response,
    EvidenceTracker as _EvidenceTracker,
    SynthesisGate as _SynthesisGate,
)
from sage.core.list_generator import (
    dedupe_numbered_list_items as _dedupe_numbered_list_items,
    extract_list_item_count as _extract_list_item_count,
    extract_list_items_detailed as _extract_list_items_detailed,
)

# ══════════════════════════════════════════════════════════════════════════════
# REQUEST CLASSIFICATION STATE - Enforces correct behavior per request type
# ══════════════════════════════════════════════════════════════════════════════

# Global request classifier instance (thread-local in production)
_request_classifier = _RequestClassifier()

# Current request classification - ENFORCED during file writing
_current_classification: _ClassifiedRequest | None = None


def _classify_and_store_request(user_input: str) -> _ClassifiedRequest:
    """Classify user request and store for enforcement during response processing.

    Also resets the evidence tracker for the new request.
    """
    global _current_classification
    _current_classification = _request_classifier.classify(user_input)
    # Reset evidence tracker for the new request
    _reset_evidence_tracker()
    return _current_classification


def _get_current_classification() -> _ClassifiedRequest | None:
    """Get the current request classification for enforcement."""
    return _current_classification


def _clear_classification() -> None:
    """Clear the current classification after request is complete."""
    global _current_classification
    _current_classification = None


# ══════════════════════════════════════════════════════════════════════════════
# EVIDENCE TRACKING STATE - Tracks verified file reads and searches for grounding
# ══════════════════════════════════════════════════════════════════════════════

# Global evidence tracker instance - tracks file reads and searches per request
_evidence_tracker: _EvidenceTracker | None = None

# Global synthesis gate instance - blocks synthesis without sufficient evidence
_synthesis_gate = _SynthesisGate(require_any_evidence=True)


def _reset_evidence_tracker() -> _EvidenceTracker:
    """Reset and return a fresh evidence tracker for a new request."""
    global _evidence_tracker
    _evidence_tracker = _EvidenceTracker()
    return _evidence_tracker


def _get_evidence_tracker() -> _EvidenceTracker | None:
    """Get the current evidence tracker."""
    return _evidence_tracker


def _record_file_read(filepath: str, success: bool = True) -> None:
    """Record a file read attempt on the current evidence tracker."""
    if _evidence_tracker is not None:
        _evidence_tracker.record_file_read(filepath, success)


def _record_search(pattern: str, results: list[str]) -> None:
    """Record a search and its results on the current evidence tracker."""
    if _evidence_tracker is not None:
        _evidence_tracker.record_search(pattern, results)


def _check_synthesis_gate() -> tuple[bool, str]:
    """Check if synthesis should be allowed based on collected evidence."""
    if _evidence_tracker is None:
        return False, "No evidence tracker initialized"
    return _synthesis_gate.check(_evidence_tracker)


# ══════════════════════════════════════════════════════════════════════════════
# TIME TRAVEL DEBUGGER - Git checkpoint + memory rollback system
# ══════════════════════════════════════════════════════════════════════════════

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Checkpoint:
    """Snapshot of SAGE state for time travel."""

    id: str
    timestamp: str
    git_sha: str | None  # Git commit SHA at checkpoint time
    git_stash: str | None  # Stash reference if uncommitted changes existed
    files_written: list[str]  # Files written since last checkpoint
    message_count: int  # Number of messages in conversation
    description: str  # Human-readable description


class CheckpointManager:
    """Manages time travel checkpoints for safe experimentation."""

    def __init__(self, cwd: Path):
        self.cwd = cwd
        self.checkpoints: list[Checkpoint] = []
        self._checkpoint_dir = cwd / ".sage" / "checkpoints"
        self._checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self._load_checkpoints()

    def _load_checkpoints(self) -> None:
        """Load checkpoints from disk."""
        checkpoint_file = self._checkpoint_dir / "history.json"
        if checkpoint_file.exists():
            try:
                data = _json.loads(checkpoint_file.read_text())
                self.checkpoints = [
                    Checkpoint(**cp) for cp in data.get("checkpoints", [])
                ]
            except Exception:
                self.checkpoints = []

    def _save_checkpoints(self) -> None:
        """Persist checkpoints to disk."""
        checkpoint_file = self._checkpoint_dir / "history.json"
        data = {
            "checkpoints": [
                {
                    "id": cp.id,
                    "timestamp": cp.timestamp,
                    "git_sha": cp.git_sha,
                    "git_stash": cp.git_stash,
                    "files_written": cp.files_written,
                    "message_count": cp.message_count,
                    "description": cp.description,
                }
                for cp in self.checkpoints[-20:]  # Keep last 20 checkpoints
            ]
        }
        checkpoint_file.write_text(_json.dumps(data, indent=2))

    def _get_git_sha(self) -> str | None:
        """Get current git HEAD SHA."""
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self.cwd,
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()[:12]
        except Exception:
            pass
        return None

    def _has_uncommitted_changes(self) -> bool:
        """Check if there are uncommitted changes."""
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=self.cwd,
                capture_output=True,
                text=True,
                timeout=5,
            )
            return bool(result.stdout.strip())
        except Exception:
            return False

    def _create_stash(self, message: str) -> str | None:
        """Create a git stash and return the stash reference."""
        try:
            # Check if there are changes to stash
            if not self._has_uncommitted_changes():
                return None
            result = subprocess.run(
                ["git", "stash", "push", "-m", f"SAGE checkpoint: {message}"],
                cwd=self.cwd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0 and "No local changes" not in result.stdout:
                # Get the stash reference
                list_result = subprocess.run(
                    ["git", "stash", "list", "-1"],
                    cwd=self.cwd,
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if list_result.returncode == 0 and list_result.stdout.strip():
                    return list_result.stdout.split(":")[0]  # e.g., "stash@{0}"
        except Exception:
            pass
        return None

    def create_checkpoint(
        self,
        files_written: list[str],
        message_count: int,
        description: str,
        auto_stash: bool = True,
    ) -> Checkpoint:
        """Create a new checkpoint before a major operation."""
        checkpoint_id = f"cp_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        git_stash = None
        if auto_stash and self._has_uncommitted_changes():
            git_stash = self._create_stash(description)

        checkpoint = Checkpoint(
            id=checkpoint_id,
            timestamp=datetime.now().isoformat(),
            git_sha=self._get_git_sha(),
            git_stash=git_stash,
            files_written=list(files_written),
            message_count=message_count,
            description=description,
        )
        self.checkpoints.append(checkpoint)
        self._save_checkpoints()
        return checkpoint

    def restore_checkpoint(self, checkpoint: Checkpoint) -> tuple[bool, str]:
        """Restore to a checkpoint.

        Returns (success, message).
        """
        errors = []

        # 1. Delete files written since checkpoint
        for fp in checkpoint.files_written:
            target = self.cwd / fp
            if target.exists():
                try:
                    target.unlink()
                except Exception as e:
                    errors.append(f"Failed to delete {fp}: {e}")

        # 2. Restore git state
        if checkpoint.git_stash:
            try:
                # Apply the stash (keep it in case we need it again)
                result = subprocess.run(
                    ["git", "stash", "pop", "--index"],
                    cwd=self.cwd,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode != 0:
                    errors.append(f"Git stash pop failed: {result.stderr}")
            except Exception as e:
                errors.append(f"Git restore failed: {e}")
        elif checkpoint.git_sha:
            try:
                # Hard reset to the checkpoint SHA (dangerous but effective)
                result = subprocess.run(
                    ["git", "checkout", checkpoint.git_sha, "--", "."],
                    cwd=self.cwd,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode != 0:
                    errors.append(f"Git checkout failed: {result.stderr}")
            except Exception as e:
                errors.append(f"Git reset failed: {e}")

        if errors:
            return False, "; ".join(errors)
        return True, f"Restored to checkpoint '{checkpoint.description}'"

    def get_last_checkpoint(self) -> Checkpoint | None:
        """Get the most recent checkpoint."""
        return self.checkpoints[-1] if self.checkpoints else None

    def list_checkpoints(self, limit: int = 5) -> list[Checkpoint]:
        """List recent checkpoints."""
        return self.checkpoints[-limit:][::-1]  # Most recent first


# ══════════════════════════════════════════════════════════════════════════════
# SECURITY AUDITOR - Ambient security scanning for every code change
# ══════════════════════════════════════════════════════════════════════════════


@dataclass
class SecurityFinding:
    """A security vulnerability finding."""

    severity: str  # CRITICAL, HIGH, MEDIUM, LOW, INFO
    file: str
    line: int
    rule: str
    message: str
    cwe: str | None = None


class SecurityAuditor:
    """Ambient security scanning for SAGE-written code."""

    # Common vulnerability patterns (fallback if no tools installed)
    PATTERNS = {
        "hardcoded_secret": (
            r'(?:password|secret|api_key|apikey|token|auth)\s*=\s*["\'][^"\']{8,}["\']',
            "HIGH",
            "CWE-798",
            "Hardcoded credential detected",
        ),
        "sql_injection": (
            r'(?:execute|cursor\.execute|raw)\s*\(\s*["\'].*%s.*["\']',
            "CRITICAL",
            "CWE-89",
            "Potential SQL injection (use parameterized queries)",
        ),
        "command_injection": (
            r"(?:os\.system|subprocess\.call|subprocess\.run|eval|exec)\s*\([^)]*\+",
            "CRITICAL",
            "CWE-78",
            "Potential command injection",
        ),
        "xss_vuln": (
            r"innerHTML\s*=|document\.write\s*\(|\.html\s*\([^)]*\+",
            "HIGH",
            "CWE-79",
            "Potential XSS vulnerability",
        ),
        "path_traversal": (
            r"open\s*\([^)]*\.\.\/",
            "HIGH",
            "CWE-22",
            "Potential path traversal",
        ),
        "weak_crypto": (
            r"(?:md5|sha1)\s*\(",
            "MEDIUM",
            "CWE-327",
            "Weak cryptographic algorithm",
        ),
        "debug_enabled": (
            r"(?:DEBUG\s*=\s*True|debug\s*=\s*true)",
            "LOW",
            "CWE-489",
            "Debug mode enabled",
        ),
        "private_key": (
            r"-----BEGIN (?:RSA |DSA |EC )?PRIVATE KEY-----",
            "CRITICAL",
            "CWE-321",
            "Private key in source code",
        ),
    }

    def __init__(self, cwd: Path):
        self.cwd = cwd
        self._has_bandit = self._check_tool("bandit")
        self._has_semgrep = self._check_tool("semgrep")

    def _check_tool(self, tool: str) -> bool:
        """Check if a security tool is installed."""
        try:
            result = subprocess.run([tool, "--version"], capture_output=True, timeout=5)
            return result.returncode == 0
        except Exception:
            return False

    def scan_file(self, filepath: str) -> list[SecurityFinding]:
        """Scan a single file for security issues."""
        findings: list[SecurityFinding] = []
        full_path = self.cwd / filepath

        if not full_path.exists():
            return findings

        # Determine file type
        suffix = full_path.suffix.lower()

        # Run bandit for Python files
        if suffix == ".py" and self._has_bandit:
            findings.extend(self._run_bandit(filepath))
        # Run semgrep for supported files
        elif self._has_semgrep and suffix in {
            ".py",
            ".js",
            ".ts",
            ".jsx",
            ".tsx",
            ".go",
            ".java",
        }:
            findings.extend(self._run_semgrep(filepath))

        # Always run pattern-based detection as fallback/supplement
        findings.extend(self._pattern_scan(filepath))

        return findings

    def _run_bandit(self, filepath: str) -> list[SecurityFinding]:
        """Run bandit on a Python file."""
        findings = []
        try:
            result = subprocess.run(
                ["bandit", "-f", "json", "-q", str(self.cwd / filepath)],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self.cwd,
            )
            if result.stdout:
                data = _json.loads(result.stdout)
                for issue in data.get("results", []):
                    sev = issue.get("issue_severity", "MEDIUM").upper()
                    findings.append(
                        SecurityFinding(
                            severity=sev,
                            file=filepath,
                            line=issue.get("line_number", 0),
                            rule=issue.get("test_id", ""),
                            message=issue.get("issue_text", ""),
                            cwe=issue.get("issue_cwe", {}).get("id"),
                        )
                    )
        except Exception:
            pass
        return findings

    def _run_semgrep(self, filepath: str) -> list[SecurityFinding]:
        """Run semgrep on a file."""
        findings = []
        try:
            result = subprocess.run(
                ["semgrep", "--json", "--config", "auto", str(self.cwd / filepath)],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=self.cwd,
            )
            if result.stdout:
                data = _json.loads(result.stdout)
                for issue in data.get("results", []):
                    sev = issue.get("extra", {}).get("severity", "WARNING").upper()
                    if sev == "WARNING":
                        sev = "MEDIUM"
                    elif sev == "ERROR":
                        sev = "HIGH"
                    findings.append(
                        SecurityFinding(
                            severity=sev,
                            file=filepath,
                            line=issue.get("start", {}).get("line", 0),
                            rule=issue.get("check_id", ""),
                            message=issue.get("extra", {}).get("message", ""),
                            cwe=issue.get("extra", {}).get("metadata", {}).get("cwe"),
                        )
                    )
        except Exception:
            pass
        return findings

    def _pattern_scan(self, filepath: str) -> list[SecurityFinding]:
        """Fallback pattern-based scanning."""
        findings = []
        full_path = self.cwd / filepath

        try:
            content = full_path.read_text(errors="ignore")
            lines = content.split("\n")

            for name, (pattern, severity, cwe, message) in self.PATTERNS.items():
                for i, line in enumerate(lines, 1):
                    if re.search(pattern, line, re.IGNORECASE):
                        findings.append(
                            SecurityFinding(
                                severity=severity,
                                file=filepath,
                                line=i,
                                rule=f"sage/{name}",
                                message=message,
                                cwe=cwe,
                            )
                        )
        except Exception:
            pass

        return findings

    def scan_files(self, filepaths: list[str]) -> list[SecurityFinding]:
        """Scan multiple files and return all findings."""
        all_findings = []
        for fp in filepaths:
            all_findings.extend(self.scan_file(fp))
        # Deduplicate by (file, line, rule)
        seen = set()
        unique = []
        for f in all_findings:
            key = (f.file, f.line, f.rule)
            if key not in seen:
                seen.add(key)
                unique.append(f)
        return sorted(
            unique,
            key=lambda x: {
                "CRITICAL": 0,
                "HIGH": 1,
                "MEDIUM": 2,
                "LOW": 3,
                "INFO": 4,
            }.get(x.severity, 5),
        )

    def format_findings(self, findings: list[SecurityFinding]) -> str:
        """Format findings for display."""
        if not findings:
            return "✅ No security issues found."

        severity_colors = {
            "CRITICAL": "🔴",
            "HIGH": "🟠",
            "MEDIUM": "🟡",
            "LOW": "🔵",
            "INFO": "⚪",
        }

        lines = ["🔒 Security Scan Results:"]
        for f in findings:
            icon = severity_colors.get(f.severity, "⚪")
            cwe_str = f" ({f.cwe})" if f.cwe else ""
            lines.append(
                f"  {icon} [{f.severity}] {f.file}:{f.line} — {f.message}{cwe_str}"
            )
        return "\n".join(lines)

    def has_critical_findings(self, findings: list[SecurityFinding]) -> bool:
        """Check if there are any critical or high severity findings."""
        return any(f.severity in {"CRITICAL", "HIGH"} for f in findings)


# ══════════════════════════════════════════════════════════════════════════════
# DEPENDENCY GRAPH - AST-based codebase indexing for intelligent context
# ══════════════════════════════════════════════════════════════════════════════

import ast


@dataclass
class FileNode:
    """A node in the dependency graph."""

    path: str
    imports: set[str] = field(default_factory=set)  # Modules this file imports
    imported_by: set[str] = field(default_factory=set)  # Files that import this
    functions: list[str] = field(default_factory=list)  # Function definitions
    classes: list[str] = field(default_factory=list)  # Class definitions


class DependencyGraph:
    """AST-based dependency graph for whole-repo awareness."""

    def __init__(self, cwd: Path):
        self.cwd = cwd
        self.nodes: dict[str, FileNode] = {}
        self._index_cache_file = cwd / ".sage" / "dep_graph.json"
        self._last_indexed: dict[str, float] = {}  # filepath -> mtime
        self._load_cache()

    def _load_cache(self) -> None:
        """Load cached graph from disk."""
        if self._index_cache_file.exists():
            try:
                data = _json.loads(self._index_cache_file.read_text())
                self._last_indexed = data.get("mtime", {})
                for path, node_data in data.get("nodes", {}).items():
                    self.nodes[path] = FileNode(
                        path=path,
                        imports=set(node_data.get("imports", [])),
                        imported_by=set(node_data.get("imported_by", [])),
                        functions=node_data.get("functions", []),
                        classes=node_data.get("classes", []),
                    )
            except Exception:
                pass

    def _save_cache(self) -> None:
        """Save graph to disk."""
        self._index_cache_file.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "mtime": self._last_indexed,
            "nodes": {
                path: {
                    "imports": list(node.imports),
                    "imported_by": list(node.imported_by),
                    "functions": node.functions,
                    "classes": node.classes,
                }
                for path, node in self.nodes.items()
            },
        }
        self._index_cache_file.write_text(_json.dumps(data))

    def _parse_python_file(self, filepath: str) -> FileNode | None:
        """Parse a Python file using AST."""
        full_path = self.cwd / filepath
        if not full_path.exists() or not filepath.endswith(".py"):
            return None

        try:
            source = full_path.read_text(errors="ignore")
            tree = ast.parse(source)
        except (SyntaxError, Exception):
            return None

        node = FileNode(path=filepath)

        for item in ast.walk(tree):
            if isinstance(item, ast.Import):
                for alias in item.names:
                    node.imports.add(alias.name.split(".")[0])
            elif isinstance(item, ast.ImportFrom):
                if item.module:
                    node.imports.add(item.module.split(".")[0])
            elif isinstance(item, ast.FunctionDef):
                node.functions.append(item.name)
            elif isinstance(item, ast.AsyncFunctionDef):
                node.functions.append(item.name)
            elif isinstance(item, ast.ClassDef):
                node.classes.append(item.name)

        return node

    def _module_to_filepath(self, module: str) -> str | None:
        """Convert a module name to a filepath."""
        # Try common patterns
        candidates = [
            f"{module}.py",
            f"{module}/__init__.py",
            f"src/{module}.py",
            f"src/{module}/__init__.py",
            f"lib/{module}.py",
        ]
        for candidate in candidates:
            if (self.cwd / candidate).exists():
                return candidate
        # Check if it's a submodule path
        parts = module.replace(".", "/")
        for candidate in [f"{parts}.py", f"{parts}/__init__.py"]:
            if (self.cwd / candidate).exists():
                return candidate
        return None

    def index_file(self, filepath: str) -> None:
        """Index a single file."""
        full_path = self.cwd / filepath
        if not full_path.exists():
            return

        try:
            mtime = full_path.stat().st_mtime
        except Exception:
            return

        # Skip if already indexed and unchanged
        if filepath in self._last_indexed and self._last_indexed[filepath] >= mtime:
            return

        node = self._parse_python_file(filepath)
        if node:
            self.nodes[filepath] = node
            self._last_indexed[filepath] = mtime

            # Update reverse dependencies
            for imp in node.imports:
                imp_path = self._module_to_filepath(imp)
                if imp_path and imp_path in self.nodes:
                    self.nodes[imp_path].imported_by.add(filepath)

    def index_project(self, limit: int = 500) -> int:
        """Index all Python files in the project."""
        indexed = 0
        for pattern in ["**/*.py"]:
            for path in self.cwd.glob(pattern):
                if indexed >= limit:
                    break
                rel_path = str(path.relative_to(self.cwd))
                # Skip hidden dirs, __pycache__, node_modules, venv
                if any(
                    part.startswith(".")
                    or part in {"__pycache__", "node_modules", "venv", ".venv"}
                    for part in rel_path.split("/")
                ):
                    continue
                self.index_file(rel_path)
                indexed += 1

        # Build reverse dependencies
        for filepath, node in self.nodes.items():
            for imp in node.imports:
                imp_path = self._module_to_filepath(imp)
                if imp_path and imp_path in self.nodes and imp_path != filepath:
                    self.nodes[imp_path].imported_by.add(filepath)

        self._save_cache()
        return indexed

    def get_affected_files(self, changed_files: list[str]) -> list[str]:
        """Get all files that would be affected by changes to the given files.

        This performs a BFS traversal of reverse dependencies.
        """
        affected = set(changed_files)
        queue = list(changed_files)

        while queue:
            current = queue.pop(0)
            if current not in self.nodes:
                continue
            for dependant in self.nodes[current].imported_by:
                if dependant not in affected:
                    affected.add(dependant)
                    queue.append(dependant)

        return sorted(affected)

    def get_file_context(self, filepath: str) -> str:
        """Get context about a file for the AI."""
        if filepath not in self.nodes:
            self.index_file(filepath)

        node = self.nodes.get(filepath)
        if not node:
            return ""

        lines = [f"📊 Dependency context for {filepath}:"]

        if node.imports:
            lines.append(f"  Imports: {', '.join(sorted(node.imports)[:10])}")

        if node.imported_by:
            lines.append(f"  Used by: {', '.join(sorted(node.imported_by)[:10])}")

        if node.functions:
            lines.append(f"  Functions: {', '.join(node.functions[:15])}")

        if node.classes:
            lines.append(f"  Classes: {', '.join(node.classes[:10])}")

        return "\n".join(lines)

    def get_impact_summary(self, changed_files: list[str]) -> str:
        """Get a summary of the impact of changes."""
        affected = self.get_affected_files(changed_files)
        if len(affected) <= len(changed_files):
            return ""

        other_affected = [f for f in affected if f not in changed_files]
        if not other_affected:
            return ""

        return (
            f"⚠️ Impact Analysis: Changes to {len(changed_files)} file(s) may affect "
            f"{len(other_affected)} other file(s):\n  "
            + "\n  ".join(other_affected[:10])
            + (
                f"\n  ... and {len(other_affected) - 10} more"
                if len(other_affected) > 10
                else ""
            )
        )


# ══════════════════════════════════════════════════════════════════════════════
# MULTI-AGENT SWARM - Orchestrator-Worker pattern with model routing
# ══════════════════════════════════════════════════════════════════════════════

from enum import Enum
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading


# ══════════════════════════════════════════════════════════════════════════════
# THREAD SAFETY HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _is_main_thread() -> bool:
    """Check if the current thread is the main thread.

    Returns:
        True if running on the main thread, False otherwise
    """
    return threading.current_thread() == threading.main_thread()


class TaskType(Enum):
    """Types of tasks for model routing."""

    ARCHITECTURE = "architecture"  # High-level planning, API design
    IMPLEMENTATION = "implementation"  # Writing core logic
    TESTING = "testing"  # Writing tests
    SECURITY = "security"  # Security auditing
    DOCUMENTATION = "documentation"  # Docs, README, comments
    REFACTORING = "refactoring"  # Code cleanup, DRY
    DEBUGGING = "debugging"  # Fixing bugs, analyzing errors
    REVIEW = "review"  # Code review, quality checks


@dataclass
class SwarmTask:
    """A task for the swarm to execute."""

    id: str
    type: TaskType
    description: str
    context: str  # Relevant file contents, errors, etc.
    dependencies: list[str] = field(default_factory=list)  # Task IDs this depends on
    result: str | None = None
    status: str = "pending"  # pending, running, completed, failed


@dataclass
class ModelProfile:
    """Profile for model routing decisions."""

    model_id: str
    strengths: list[TaskType]
    cost_tier: str  # "cheap", "medium", "expensive"
    context_size: int
    speed: str  # "fast", "medium", "slow"


class SwarmOrchestrator:
    """Orchestrates multi-agent task decomposition and execution."""

    # Model routing profiles - maps task types to preferred model characteristics
    TASK_MODEL_PREFERENCES = {
        TaskType.ARCHITECTURE: {
            "cost_tier": "expensive",
            "strengths": ["reasoning", "planning"],
        },
        TaskType.IMPLEMENTATION: {"cost_tier": "medium", "strengths": ["coding"]},
        TaskType.TESTING: {"cost_tier": "cheap", "strengths": ["testing"]},
        TaskType.SECURITY: {"cost_tier": "medium", "strengths": ["security"]},
        TaskType.DOCUMENTATION: {"cost_tier": "cheap", "strengths": ["writing"]},
        TaskType.REFACTORING: {"cost_tier": "medium", "strengths": ["coding"]},
        TaskType.DEBUGGING: {"cost_tier": "medium", "strengths": ["debugging"]},
        TaskType.REVIEW: {"cost_tier": "cheap", "strengths": ["review"]},
    }

    def __init__(self, router: "ProviderRouter", default_model: str):
        self.router = router
        self.default_model = default_model
        self.tasks: dict[str, SwarmTask] = {}
        self.model_profiles: dict[str, ModelProfile] = {}
        self._lock = threading.Lock()
        self._build_model_profiles()

    def _build_model_profiles(self) -> None:
        """Build profiles for available models."""
        # Get all available models and profile them
        for model_info in self.router.list_all_models():
            model_id = model_info.id
            name_lower = model_id.lower()

            # Determine cost tier
            if any(x in name_lower for x in ["opus", "gpt-4", "claude-3.5"]):
                cost_tier = "expensive"
            elif any(x in name_lower for x in ["sonnet", "gpt-3.5", "mixtral"]):
                cost_tier = "medium"
            else:
                cost_tier = "cheap"

            # Determine strengths
            strengths = []
            if any(x in name_lower for x in ["coder", "code", "deepseek", "starcoder"]):
                strengths.extend([TaskType.IMPLEMENTATION, TaskType.DEBUGGING])
            if any(x in name_lower for x in ["opus", "o1", "reasoning"]):
                strengths.extend([TaskType.ARCHITECTURE, TaskType.REVIEW])
            if not strengths:
                strengths = [TaskType.IMPLEMENTATION]

            self.model_profiles[model_id] = ModelProfile(
                model_id=model_id,
                strengths=strengths,
                cost_tier=cost_tier,
                context_size=getattr(model_info, "context_length", 8192),
                speed="fast" if cost_tier == "cheap" else "medium",
            )

    def select_model_for_task(self, task_type: TaskType) -> str:
        """Select the best model for a given task type."""
        prefs = self.TASK_MODEL_PREFERENCES.get(task_type, {})
        preferred_cost = prefs.get("cost_tier", "medium")

        # Find models matching the preferred cost tier and task type
        candidates = []
        for model_id, profile in self.model_profiles.items():
            if profile.cost_tier == preferred_cost and task_type in profile.strengths:
                candidates.append(model_id)

        # Fallback to any model with matching task type
        if not candidates:
            for model_id, profile in self.model_profiles.items():
                if task_type in profile.strengths:
                    candidates.append(model_id)

        # Final fallback to default model
        if not candidates:
            return self.default_model

        return candidates[0]

    def decompose_task(self, prompt: str, context: str = "") -> list[SwarmTask]:
        """Decompose a complex task into sub-tasks.

        Uses the orchestrator model to plan the work.
        """
        tasks = []

        # Use pattern matching to identify task types needed
        prompt_lower = prompt.lower()

        # Architecture planning for new features
        if any(
            x in prompt_lower for x in ["create", "implement", "build", "add feature"]
        ):
            tasks.append(
                SwarmTask(
                    id="plan",
                    type=TaskType.ARCHITECTURE,
                    description="Create implementation plan",
                    context=f"Task: {prompt}\n\nContext:\n{context[:2000]}",
                )
            )

        # Testing task (always first in TDD)
        if any(
            x in prompt_lower for x in ["test", "tdd", "create", "implement", "build"]
        ):
            tasks.append(
                SwarmTask(
                    id="tests",
                    type=TaskType.TESTING,
                    description="Write tests first (TDD)",
                    context=f"Task: {prompt}\n\nWrite tests that verify the expected behavior.",
                    dependencies=["plan"] if "plan" in [t.id for t in tasks] else [],
                )
            )

        # Implementation task
        if any(
            x in prompt_lower for x in ["implement", "build", "create", "fix", "update"]
        ):
            tasks.append(
                SwarmTask(
                    id="implement",
                    type=TaskType.IMPLEMENTATION,
                    description="Write implementation code",
                    context=f"Task: {prompt}\n\nImplement the solution.",
                    dependencies=["tests"] if "tests" in [t.id for t in tasks] else [],
                )
            )

        # Security audit for new code
        if tasks:
            tasks.append(
                SwarmTask(
                    id="security",
                    type=TaskType.SECURITY,
                    description="Security audit",
                    context="Review written code for security vulnerabilities.",
                    dependencies=(
                        ["implement"] if "implement" in [t.id for t in tasks] else []
                    ),
                )
            )

        # Documentation for new features
        if any(x in prompt_lower for x in ["create", "implement", "build", "add"]):
            tasks.append(
                SwarmTask(
                    id="docs",
                    type=TaskType.DOCUMENTATION,
                    description="Update documentation",
                    context="Add or update documentation for the changes.",
                    dependencies=(
                        ["implement"] if "implement" in [t.id for t in tasks] else []
                    ),
                )
            )

        # If no tasks identified, create a generic implementation task
        if not tasks:
            tasks.append(
                SwarmTask(
                    id="main",
                    type=TaskType.IMPLEMENTATION,
                    description=prompt[:100],
                    context=f"Task: {prompt}\n\nContext:\n{context[:2000]}",
                )
            )

        # Store tasks
        for task in tasks:
            self.tasks[task.id] = task

        return tasks

    def execute_task(
        self,
        task: SwarmTask,
        send_fn: Callable[[str, str], str | None],
    ) -> str | None:
        """Execute a single task using the appropriate model."""
        with self._lock:
            task.status = "running"

        # Select model for this task type
        model_id = self.select_model_for_task(task.type)

        # Build the task prompt
        task_prompt = (
            f"## Task: {task.description}\n\n"
            f"## Context:\n{task.context}\n\n"
            f"## Instructions:\n"
            f"Focus ONLY on this specific task. Output FILE: blocks for any code changes."
        )

        try:
            result = send_fn(task_prompt, model_id)
            with self._lock:
                task.result = result
                task.status = "completed"
            return result
        except Exception as e:
            with self._lock:
                task.status = "failed"
                task.result = str(e)
            return None

    def execute_swarm(
        self,
        tasks: list[SwarmTask],
        send_fn: Callable[[str, str], str | None],
        parallel: bool = True,
        max_workers: int = 3,
    ) -> dict[str, str | None]:
        """Execute all tasks, respecting dependencies.

        Returns dict of task_id -> result.
        """
        results: dict[str, str | None] = {}
        completed = set()

        # Group tasks by dependency level
        while len(completed) < len(tasks):
            # Find tasks that can run (all dependencies satisfied)
            ready = [
                t
                for t in tasks
                if t.id not in completed
                and all(dep in completed for dep in t.dependencies)
            ]

            if not ready:
                break  # No progress possible, dependency cycle or missing deps

            if parallel and len(ready) > 1:
                # Execute ready tasks in parallel
                with ThreadPoolExecutor(
                    max_workers=min(max_workers, len(ready))
                ) as executor:
                    futures = {
                        executor.submit(self.execute_task, task, send_fn): task
                        for task in ready
                    }
                    for future in as_completed(futures):
                        task = futures[future]
                        try:
                            results[task.id] = future.result()
                        except Exception:
                            results[task.id] = None
                        completed.add(task.id)
            else:
                # Sequential execution
                for task in ready:
                    results[task.id] = self.execute_task(task, send_fn)
                    completed.add(task.id)

        return results

    def get_swarm_summary(self) -> str:
        """Get a summary of swarm execution."""
        if not self.tasks:
            return "No swarm tasks."

        lines = ["🐝 Swarm Execution Summary:"]
        for task_id, task in self.tasks.items():
            status_icon = {
                "pending": "⏳",
                "running": "🔄",
                "completed": "✅",
                "failed": "❌",
            }.get(task.status, "?")
            lines.append(f"  {status_icon} [{task.type.value}] {task.description[:50]}")

        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# DOCKER SANDBOX - Isolated execution environment for verified TDD
# ══════════════════════════════════════════════════════════════════════════════

import shutil
import uuid
import atexit


@dataclass
class SandboxResult:
    """Result from sandbox execution."""

    exit_code: int
    stdout: str
    stderr: str
    duration: float
    command: str
    timed_out: bool = False


class DockerSandbox:
    """Ephemeral Docker container sandbox for isolated code execution.

    Key features:
    - Ephemeral containers destroyed after each session
    - Project mounted with configurable write access
    - Network isolation option
    - Resource limits (CPU, memory)
    - stdout/stderr capture for SAGE context
    """

    # Default Docker image for Python/Node projects
    DEFAULT_IMAGE = "python:3.12-slim"

    # Alternative images for different project types
    PROJECT_IMAGES = {
        "python": "python:3.12-slim",
        "node": "node:20-slim",
        "rust": "rust:1.75-slim",
        "go": "golang:1.22-alpine",
        "java": "openjdk:21-slim",
        "ruby": "ruby:3.3-slim",
    }

    def __init__(
        self,
        cwd: Path,
        image: str | None = None,
        network_enabled: bool = False,
        memory_limit: str = "512m",
        cpu_limit: float = 1.0,
    ):
        self.cwd = cwd
        self.image = image or self._detect_project_image()
        self.network_enabled = network_enabled
        self.memory_limit = memory_limit
        self.cpu_limit = cpu_limit
        self.container_id: str | None = None
        self.session_id = str(uuid.uuid4())[:8]
        self._docker_available = self._check_docker()

        # Register cleanup on exit
        atexit.register(self.cleanup)

    def _check_docker(self) -> bool:
        """Check if Docker is available."""
        try:
            result = subprocess.run(["docker", "info"], capture_output=True, timeout=5)
            return result.returncode == 0
        except Exception:
            return False

    def _detect_project_image(self) -> str:
        """Detect the best Docker image based on project files."""
        if (self.cwd / "Cargo.toml").exists():
            return self.PROJECT_IMAGES["rust"]
        if (self.cwd / "go.mod").exists():
            return self.PROJECT_IMAGES["go"]
        if (self.cwd / "package.json").exists():
            return self.PROJECT_IMAGES["node"]
        if (self.cwd / "Gemfile").exists():
            return self.PROJECT_IMAGES["ruby"]
        if (self.cwd / "pom.xml").exists() or (self.cwd / "build.gradle").exists():
            return self.PROJECT_IMAGES["java"]
        # Default to Python
        return self.PROJECT_IMAGES["python"]

    def is_available(self) -> bool:
        """Check if sandbox is available."""
        return self._docker_available

    def start(self) -> bool:
        """Start the sandbox container."""
        if not self._docker_available:
            return False

        if self.container_id:
            return True  # Already running

        container_name = f"sage-sandbox-{self.session_id}"

        # Build docker run command
        cmd = [
            "docker",
            "run",
            "-d",  # Detached
            "--name",
            container_name,
            "-w",
            "/workspace",
            "-v",
            f"{self.cwd}:/workspace",
            "--memory",
            self.memory_limit,
            f"--cpus={self.cpu_limit}",
        ]

        # Network isolation
        if not self.network_enabled:
            cmd.extend(["--network", "none"])

        # Security options
        cmd.extend(
            [
                "--security-opt",
                "no-new-privileges",
                "--cap-drop",
                "ALL",
                "--read-only",  # Read-only root filesystem
                "--tmpfs",
                "/tmp:rw,noexec,nosuid,size=100m",  # Writable /tmp
            ]
        )

        # Image and keep-alive command
        cmd.extend([self.image, "tail", "-f", "/dev/null"])

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            if result.returncode == 0:
                self.container_id = result.stdout.strip()[:12]
                return True
            else:
                # Container might already exist, try to start it
                subprocess.run(
                    ["docker", "start", container_name], capture_output=True, timeout=30
                )
                id_result = subprocess.run(
                    ["docker", "ps", "-q", "-f", f"name={container_name}"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if id_result.stdout.strip():
                    self.container_id = id_result.stdout.strip()[:12]
                    return True
        except Exception:
            pass

        return False

    def execute(
        self,
        command: str,
        timeout: int = 120,
        env: dict[str, str] | None = None,
    ) -> SandboxResult:
        """Execute a command in the sandbox.

        Returns structured result with exit code, stdout, stderr.
        """
        start_time = time.time()

        if not self.container_id:
            if not self.start():
                return SandboxResult(
                    exit_code=-1,
                    stdout="",
                    stderr="Sandbox not available. Docker may not be installed.",
                    duration=0,
                    command=command,
                )

        # Build exec command
        cmd = ["docker", "exec"]

        # Add environment variables
        if env:
            for key, value in env.items():
                cmd.extend(["-e", f"{key}={value}"])

        cmd.extend([self.container_id, "sh", "-c", command])

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            duration = time.time() - start_time

            return SandboxResult(
                exit_code=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
                duration=duration,
                command=command,
            )
        except subprocess.TimeoutExpired:
            duration = time.time() - start_time
            return SandboxResult(
                exit_code=-1,
                stdout="",
                stderr=f"Command timed out after {timeout}s",
                duration=duration,
                command=command,
                timed_out=True,
            )
        except Exception as e:
            duration = time.time() - start_time
            return SandboxResult(
                exit_code=-1,
                stdout="",
                stderr=str(e),
                duration=duration,
                command=command,
            )

    def run_tests(self, test_cmd: str = "pytest -v") -> SandboxResult:
        """Run tests in the sandbox with enhanced output capture."""
        # Install dependencies first if needed
        if "pytest" in test_cmd:
            self.execute("pip install -q pytest 2>/dev/null || true", timeout=60)
        elif "npm test" in test_cmd:
            self.execute("npm install --silent 2>/dev/null || true", timeout=120)

        return self.execute(test_cmd, timeout=300)

    def verify_test_failure(
        self, test_cmd: str, expected_failure: str | None = None
    ) -> tuple[bool, str]:
        """TDD Gate: Verify that tests actually fail before implementation.

        Returns (is_failing, message).
        """
        result = self.run_tests(test_cmd)

        # Check if tests failed
        is_failing = result.exit_code != 0

        if not is_failing:
            return False, (
                "❌ TDD VIOLATION: Tests are already passing!\n"
                "You must write a FAILING test first that proves the feature is missing.\n"
                f"Output:\n{result.stdout[:1000]}"
            )

        # Check for expected failure pattern if specified
        if expected_failure:
            output = result.stdout + result.stderr
            if expected_failure.lower() not in output.lower():
                return False, (
                    f"⚠️ Tests failed but not with expected error.\n"
                    f"Expected: {expected_failure}\n"
                    f"Got:\n{output[:1000]}"
                )

        return True, (
            f"✅ TDD Gate PASSED: Tests failing as expected.\n"
            f"Failures:\n{result.stderr[:500] or result.stdout[:500]}"
        )

    def verify_test_success(self, test_cmd: str) -> tuple[bool, str]:
        """TDD Gate: Verify that tests pass after implementation.

        Returns (is_passing, message).
        """
        result = self.run_tests(test_cmd)

        if result.exit_code == 0:
            return True, f"✅ GREEN: All tests passing!\n{result.stdout[:500]}"

        return False, (
            f"❌ Tests still failing. Implementation incomplete.\n"
            f"Errors:\n{result.stderr[:1000] or result.stdout[:1000]}"
        )

    def get_status(self) -> dict:
        """Get sandbox status."""
        return {
            "available": self._docker_available,
            "running": self.container_id is not None,
            "container_id": self.container_id,
            "image": self.image,
            "network": "enabled" if self.network_enabled else "isolated",
            "memory": self.memory_limit,
        }

    def cleanup(self) -> None:
        """Stop and remove the sandbox container."""
        if self.container_id:
            try:
                subprocess.run(
                    ["docker", "rm", "-f", self.container_id],
                    capture_output=True,
                    timeout=30,
                )
                self.container_id = None
            except Exception:
                pass

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()


class TDDGate:
    """Enforced TDD Gate - Code cannot proceed without verified test failure.

    The "Contract of Truth" between SAGE and the developer.
    """

    def __init__(self, sandbox: DockerSandbox):
        self.sandbox = sandbox
        self.red_verified = False
        self.green_verified = False
        self.test_cmd = "pytest -v"
        self.last_failure_output: str | None = None

    def set_test_command(self, cmd: str) -> None:
        """Set the test command to use."""
        self.test_cmd = cmd

    def verify_red(self, expected_failure: str | None = None) -> tuple[bool, str]:
        """RED Phase: Verify tests fail before implementation.

        SAGE cannot write implementation code until this passes.
        """
        if not self.sandbox.is_available():
            # Fallback to local execution if Docker not available
            return self._local_verify_red(expected_failure)

        is_red, message = self.sandbox.verify_test_failure(
            self.test_cmd, expected_failure
        )
        if is_red:
            self.red_verified = True
            self.last_failure_output = message
        return is_red, message

    def verify_green(self) -> tuple[bool, str]:
        """GREEN Phase: Verify tests pass after implementation.

        SAGE cannot proceed to refactor until this passes.
        """
        if not self.red_verified:
            return (
                False,
                "❌ Cannot verify GREEN: RED phase not completed. Write failing tests first.",
            )

        if not self.sandbox.is_available():
            return self._local_verify_green()

        is_green, message = self.sandbox.verify_test_success(self.test_cmd)
        if is_green:
            self.green_verified = True
        return is_green, message

    def reset(self) -> None:
        """Reset the TDD gate for a new cycle."""
        self.red_verified = False
        self.green_verified = False
        self.last_failure_output = None

    def _local_verify_red(
        self, expected_failure: str | None = None
    ) -> tuple[bool, str]:
        """Fallback: verify test failure locally."""
        try:
            result = subprocess.run(
                self.test_cmd.split(),
                capture_output=True,
                text=True,
                timeout=120,
                cwd=self.sandbox.cwd,
            )
            if result.returncode != 0:
                self.red_verified = True
                self.last_failure_output = result.stderr or result.stdout
                return (
                    True,
                    f"✅ TDD Gate (local): Tests failing.\n{result.stderr[:500]}",
                )
            return False, "❌ TDD VIOLATION: Tests already passing!"
        except Exception as e:
            return False, f"❌ Could not run tests: {e}"

    def _local_verify_green(self) -> tuple[bool, str]:
        """Fallback: verify test success locally."""
        try:
            result = subprocess.run(
                self.test_cmd.split(),
                capture_output=True,
                text=True,
                timeout=120,
                cwd=self.sandbox.cwd,
            )
            if result.returncode == 0:
                self.green_verified = True
                return True, f"✅ GREEN: All tests passing!"
            return False, f"❌ Tests still failing.\n{result.stderr[:500]}"
        except Exception as e:
            return False, f"❌ Could not run tests: {e}"

    def get_status(self) -> str:
        """Get TDD gate status."""
        if not self.red_verified:
            return "🔴 RED: Write failing tests first"
        elif not self.green_verified:
            return "🟡 IMPLEMENTATION: Make tests pass"
        else:
            return "🟢 GREEN: Ready to refactor"


class ControllerModel:
    """Gatekeeper model that validates sandbox operations.

    Uses a fast, cheap model to verify:
    - Command safety before execution
    - Code quality before writing
    - TDD compliance before proceeding
    """

    # Commands that should never be executed
    BLOCKED_PATTERNS = [
        r"rm\s+-rf\s+/",
        r"rm\s+-rf\s+~",
        r"rm\s+-rf\s+\*",
        r":(){ :|:& };:",  # Fork bomb
        r"mkfs\.",
        r"dd\s+if=.*/dev/",
        r"chmod\s+-R\s+777\s+/",
        r"curl.*\|\s*sh",
        r"wget.*\|\s*sh",
        r">\s*/dev/sd",
    ]

    # Commands that require explicit approval
    DANGEROUS_PATTERNS = [
        r"rm\s+-rf",
        r"git\s+push.*--force",
        r"git\s+reset\s+--hard",
        r"drop\s+database",
        r"drop\s+table",
        r"truncate\s+table",
        r"delete\s+from.*where\s+1\s*=\s*1",
    ]

    def __init__(self, router: "ProviderRouter", model_id: str | None = None):
        self.router = router
        # Use a fast, cheap model for gatekeeper operations
        self.model_id = model_id or self._select_fast_model()

    def _select_fast_model(self) -> str:
        """Select a fast model for controller operations."""
        models = self.router.list_all_models()
        # Prefer small/fast models
        for model in models:
            name = model.id.lower()
            if any(x in name for x in ["phi", "gemma", "llama-3.2-1b", "qwen2.5-1.5b"]):
                return model.id
        # Fallback to first available
        return models[0].id if models else "ollama:phi3"

    def validate_command(self, command: str) -> tuple[bool, str]:
        """Validate a command before sandbox execution.

        Returns (is_safe, reason).
        """
        command_lower = command.lower()

        # Check for blocked patterns
        for pattern in self.BLOCKED_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return (
                    False,
                    f"🚫 BLOCKED: Command matches dangerous pattern: {pattern}",
                )

        # Check for dangerous patterns (require approval)
        for pattern in self.DANGEROUS_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return (
                    False,
                    f"⚠️ DANGEROUS: Command requires approval: {command[:50]}...",
                )

        return True, "✅ Command validated"

    def validate_code(self, code: str, filepath: str) -> tuple[bool, str]:
        """Validate code before writing.

        Returns (is_safe, reason).
        """
        # Quick pattern-based checks
        dangerous_patterns = [
            (r"os\.system\([^)]*\$", "Shell injection risk"),
            (r"eval\([^)]*input", "Code injection risk"),
            (r"exec\([^)]*request", "Remote code execution risk"),
            (r"pickle\.loads?\([^)]*request", "Pickle deserialization risk"),
            (r"__import__\([^)]*request", "Dynamic import risk"),
        ]

        for pattern, reason in dangerous_patterns:
            if re.search(pattern, code, re.IGNORECASE):
                return False, f"🚫 BLOCKED: {reason} in {filepath}"

        return True, "✅ Code validated"

    def verify_tdd_compliance(
        self,
        response: str,
        has_test_files: bool,
        has_impl_files: bool,
        red_verified: bool,
    ) -> tuple[bool, str]:
        """Verify TDD compliance in the response.

        Returns (is_compliant, message).
        """
        if has_impl_files and not has_test_files and not red_verified:
            return False, (
                "❌ TDD VIOLATION: Implementation code without tests.\n"
                "You MUST write failing tests first."
            )

        if has_impl_files and not red_verified:
            return False, (
                "❌ TDD VIOLATION: Cannot write implementation until RED phase verified.\n"
                "Run tests to confirm they fail first."
            )

        return True, "✅ TDD compliant"


# ══════════════════════════════════════════════════════════════════════════════
# SAGE.md PROJECT MEMORY - Persistent project rules across sessions
# ══════════════════════════════════════════════════════════════════════════════


class ProjectMemory:
    """Persistent project memory via SAGE.md file.

    Like CLAUDE.md, stores:
    - Coding style preferences
    - Architectural decisions
    - Project-specific rules
    - Forbidden patterns
    """

    DEFAULT_TEMPLATE = """\
# SAGE Project Memory

## Project Overview
<!-- Describe your project here -->

## Coding Style
- Use type hints for all functions
- Prefer composition over inheritance
- Write tests before implementation (TDD)

## Architecture Rules
<!-- Add project-specific architecture rules -->

## Forbidden Patterns
<!-- Patterns SAGE should never use -->
- No `print()` for logging (use proper logger)
- No hardcoded secrets

## Custom Commands
<!-- Define shortcuts for common tasks -->
# test: pytest -v
# lint: ruff check .
# format: ruff format .
"""

    def __init__(self, cwd: Path):
        self.cwd = cwd
        self.memory_file = cwd / "SAGE.md"
        self._cache: dict[str, Any] | None = None

    def exists(self) -> bool:
        """Check if SAGE.md exists."""
        return self.memory_file.exists()

    def create(self) -> None:
        """Create a default SAGE.md file."""
        self.memory_file.write_text(self.DEFAULT_TEMPLATE)

    def load(self) -> str:
        """Load the project memory content."""
        if self.exists():
            return self.memory_file.read_text()
        return ""

    def get_rules(self) -> list[str]:
        """Extract rules from the memory file."""
        content = self.load()
        rules = []

        # Extract rules from ## sections
        in_rules_section = False
        for line in content.split("\n"):
            if line.startswith("## "):
                in_rules_section = (
                    "Rules" in line or "Style" in line or "Forbidden" in line
                )
            elif in_rules_section and line.strip().startswith("-"):
                rules.append(line.strip()[1:].strip())

        return rules

    def get_custom_commands(self) -> dict[str, str]:
        """Extract custom command shortcuts."""
        content = self.load()
        commands = {}

        in_commands = False
        for line in content.split("\n"):
            if "## Custom Commands" in line:
                in_commands = True
            elif line.startswith("## "):
                in_commands = False
            elif in_commands and line.strip().startswith("# "):
                parts = line.strip()[2:].split(":", 1)
                if len(parts) == 2:
                    commands[parts[0].strip()] = parts[1].strip()

        return commands

    def get_context_injection(self) -> str:
        """Get context to inject into system prompt."""
        if not self.exists():
            return ""

        rules = self.get_rules()
        if not rules:
            return ""

        return "\n\n## Project-Specific Rules (from SAGE.md)\n" + "\n".join(
            f"- {r}" for r in rules[:20]
        )


# ══════════════════════════════════════════════════════════════════════════════
# CONTEXT COMPACTION - Automatic summarization at 90% capacity
# ══════════════════════════════════════════════════════════════════════════════


def _get_msg_content(msg) -> str:
    """Get content from a message, whether it's a dict or Message dataclass."""
    if hasattr(msg, "content"):
        return msg.content
    elif isinstance(msg, dict):
        return msg.get("content", "")
    return ""


def _get_msg_role(msg) -> str:
    """Get role from a message, whether it's a dict or Message dataclass."""
    if hasattr(msg, "role"):
        return msg.role
    elif isinstance(msg, dict):
        return msg.get("role", "")
    return ""


def _msg_to_dict(msg) -> dict:
    """Convert a Message dataclass or dict to a dict."""
    if hasattr(msg, "role") and hasattr(msg, "content"):
        return {"role": msg.role, "content": msg.content}
    elif isinstance(msg, dict):
        return msg
    return {"role": "", "content": ""}


class ContextCompactor:
    """Automatic context compaction when approaching token limits.

    When context hits 90% of window, summarizes conversation history
    while preserving architectural decisions and key context.
    """

    def __init__(
        self,
        max_tokens: int = 128000,
        threshold: float = 0.9,
    ):
        self.max_tokens = max_tokens
        self.threshold = threshold
        self.compaction_count = 0

    def estimate_tokens(self, messages: list) -> int:
        """Rough token estimation (4 chars ≈ 1 token)."""
        total_chars = sum(len(_get_msg_content(m)) for m in messages)
        return total_chars // 4

    def needs_compaction(self, messages: list) -> bool:
        """Check if context needs compaction."""
        tokens = self.estimate_tokens(messages)
        return tokens >= (self.max_tokens * self.threshold)

    def compact(
        self,
        messages: list,
        router: "ProviderRouter",
        model_id: str,
    ) -> list:
        """Compact messages by summarizing older conversation.

        Preserves:
        - System prompt
        - Most recent 4 turns
        - Architectural decisions
        - File contents mentioned
        """
        if len(messages) <= 6:
            return messages

        # Keep system prompt and recent messages
        system_msgs = [m for m in messages if _get_msg_role(m) == "system"]
        recent = messages[-8:]  # Keep last 4 turns (8 messages)
        to_summarize = messages[len(system_msgs) : -8]

        if not to_summarize:
            return messages

        # Extract key information to preserve
        files_mentioned = set()
        architectural_decisions = []

        for msg in to_summarize:
            content = _get_msg_content(msg)
            # Extract file paths
            for match in re.finditer(r"FILE:\s*(\S+)", content):
                files_mentioned.add(match.group(1))
            # Extract architectural patterns
            if any(
                x in content.lower()
                for x in ["architecture", "design", "pattern", "structure"]
            ):
                # Keep first 200 chars of architectural discussions
                architectural_decisions.append(content[:200])

        # Build summary prompt
        summary_content = "\n---\n".join(
            _get_msg_content(m)[:500] for m in to_summarize[:10]
        )

        summary_prompt = (
            "Summarize this conversation history in 3-5 bullet points. "
            "Focus on: decisions made, files changed, problems solved.\n\n"
            f"{summary_content[:3000]}"
        )

        # Generate summary using a fast model
        try:
            from sage.providers.base import Message as MsgType
            summary = router.generate(
                [MsgType(role="user", content=summary_prompt)],
                model_id,
                temperature=0.3,
                max_tokens=500,
            )
        except Exception:
            summary = "Previous conversation involved code changes and debugging."

        # Build compacted context - use Message object for consistency
        from sage.providers.base import Message as MsgClass

        compacted_history = MsgClass(
            role="assistant",
            content=(
                f"[Context Compacted - Summary of {len(to_summarize)} messages]\n\n"
                f"{summary}\n\n"
                f"Files touched: {', '.join(list(files_mentioned)[:10]) or 'various'}\n"
            ),
        )

        self.compaction_count += 1

        return system_msgs + [compacted_history] + recent

    def get_status(self, messages: list) -> str:
        """Get context status."""
        tokens = self.estimate_tokens(messages)
        pct = (tokens / self.max_tokens) * 100
        return f"Context: {tokens:,}/{self.max_tokens:,} tokens ({pct:.1f}%) | Compactions: {self.compaction_count}"


# ══════════════════════════════════════════════════════════════════════════════
# LSP INTEGRATION - Language Server Protocol for real-time diagnostics
# ══════════════════════════════════════════════════════════════════════════════


@dataclass
class LSPDiagnostic:
    """A diagnostic from the language server."""

    file: str
    line: int
    column: int
    severity: str  # error, warning, info, hint
    message: str
    source: str  # pyright, typescript, rust-analyzer, etc.


class LSPClient:
    """Language Server Protocol client for real-time error detection.

    Detects "red squiggles" before running tests:
    - Type errors
    - Syntax errors
    - Import errors
    - Unused variables
    """

    # Language server commands for different languages
    LSP_SERVERS = {
        ".py": {
            "cmd": ["pyright", "--outputjson"],
            "name": "pyright",
        },
        ".ts": {
            "cmd": ["npx", "typescript", "--noEmit"],
            "name": "typescript",
        },
        ".tsx": {
            "cmd": ["npx", "typescript", "--noEmit"],
            "name": "typescript",
        },
        ".rs": {
            "cmd": ["cargo", "check", "--message-format=json"],
            "name": "rust-analyzer",
        },
        ".go": {
            "cmd": ["go", "vet", "./..."],
            "name": "go-vet",
        },
    }

    def __init__(self, cwd: Path):
        self.cwd = cwd
        self._available_servers: dict[str, bool] = {}
        self._check_servers()

    def _check_servers(self) -> None:
        """Check which language servers are available."""
        for ext, config in self.LSP_SERVERS.items():
            cmd = config["cmd"][0]
            try:
                result = subprocess.run(
                    ["which", cmd] if cmd != "npx" else ["which", "npx"],
                    capture_output=True,
                    timeout=5,
                )
                self._available_servers[ext] = result.returncode == 0
            except Exception:
                self._available_servers[ext] = False

    def check_file(self, filepath: str) -> list[LSPDiagnostic]:
        """Check a file for diagnostics."""
        full_path = self.cwd / filepath
        if not full_path.exists():
            return []

        ext = full_path.suffix.lower()
        if ext not in self.LSP_SERVERS or not self._available_servers.get(ext, False):
            return []

        config = self.LSP_SERVERS[ext]

        if ext == ".py":
            return self._check_python(filepath)
        elif ext in {".ts", ".tsx"}:
            return self._check_typescript(filepath)
        elif ext == ".rs":
            return self._check_rust(filepath)
        elif ext == ".go":
            return self._check_go(filepath)

        return []

    def _check_python(self, filepath: str) -> list[LSPDiagnostic]:
        """Check Python file with pyright."""
        diagnostics = []
        try:
            result = subprocess.run(
                ["pyright", "--outputjson", filepath],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self.cwd,
            )
            if result.stdout:
                data = _json.loads(result.stdout)
                for diag in data.get("generalDiagnostics", []):
                    severity = diag.get("severity", "error")
                    if severity == 1:
                        severity = "error"
                    elif severity == 2:
                        severity = "warning"
                    else:
                        severity = "info"

                    diagnostics.append(
                        LSPDiagnostic(
                            file=filepath,
                            line=diag.get("range", {}).get("start", {}).get("line", 0)
                            + 1,
                            column=diag.get("range", {})
                            .get("start", {})
                            .get("character", 0),
                            severity=severity,
                            message=diag.get("message", ""),
                            source="pyright",
                        )
                    )
        except Exception:
            pass
        return diagnostics

    def _check_typescript(self, filepath: str) -> list[LSPDiagnostic]:
        """Check TypeScript file."""
        diagnostics = []
        try:
            result = subprocess.run(
                ["npx", "tsc", "--noEmit", filepath],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self.cwd,
            )
            # Parse tsc output
            for line in result.stdout.split("\n"):
                match = re.match(
                    r"(.+)\((\d+),(\d+)\): (error|warning) TS\d+: (.+)", line
                )
                if match:
                    diagnostics.append(
                        LSPDiagnostic(
                            file=match.group(1),
                            line=int(match.group(2)),
                            column=int(match.group(3)),
                            severity=match.group(4),
                            message=match.group(5),
                            source="typescript",
                        )
                    )
        except Exception:
            pass
        return diagnostics

    def _check_rust(self, filepath: str) -> list[LSPDiagnostic]:
        """Check Rust file with cargo check."""
        diagnostics = []
        try:
            result = subprocess.run(
                ["cargo", "check", "--message-format=json"],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=self.cwd,
            )
            for line in result.stdout.split("\n"):
                if not line.strip():
                    continue
                try:
                    msg = _json.loads(line)
                    if msg.get("reason") == "compiler-message":
                        diag = msg.get("message", {})
                        spans = diag.get("spans", [])
                        if spans:
                            span = spans[0]
                            diagnostics.append(
                                LSPDiagnostic(
                                    file=span.get("file_name", filepath),
                                    line=span.get("line_start", 0),
                                    column=span.get("column_start", 0),
                                    severity=diag.get("level", "error"),
                                    message=diag.get("message", ""),
                                    source="rust-analyzer",
                                )
                            )
                except Exception:
                    pass
        except Exception:
            pass
        return diagnostics

    def _check_go(self, filepath: str) -> list[LSPDiagnostic]:
        """Check Go file with go vet."""
        diagnostics = []
        try:
            result = subprocess.run(
                ["go", "vet", filepath],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self.cwd,
            )
            for line in result.stderr.split("\n"):
                match = re.match(r"(.+):(\d+):(\d+): (.+)", line)
                if match:
                    diagnostics.append(
                        LSPDiagnostic(
                            file=match.group(1),
                            line=int(match.group(2)),
                            column=int(match.group(3)),
                            severity="error",
                            message=match.group(4),
                            source="go-vet",
                        )
                    )
        except Exception:
            pass
        return diagnostics

    def check_files(self, filepaths: list[str]) -> list[LSPDiagnostic]:
        """Check multiple files."""
        all_diags = []
        for fp in filepaths:
            all_diags.extend(self.check_file(fp))
        return all_diags

    def format_diagnostics(self, diagnostics: list[LSPDiagnostic]) -> str:
        """Format diagnostics for display."""
        if not diagnostics:
            return "✅ No LSP diagnostics"

        icons = {
            "error": "🔴",
            "warning": "🟡",
            "info": "🔵",
            "hint": "⚪",
        }

        lines = ["🔍 LSP Diagnostics:"]
        for d in diagnostics[:20]:
            icon = icons.get(d.severity, "⚪")
            lines.append(f"  {icon} {d.file}:{d.line}:{d.column} — {d.message}")

        return "\n".join(lines)

    def has_errors(self, diagnostics: list[LSPDiagnostic]) -> bool:
        """Check if there are any errors."""
        return any(d.severity == "error" for d in diagnostics)


# ══════════════════════════════════════════════════════════════════════════════
# INTELLIGENT EXECUTION ENGINE - The brain of SAGE autopilot
# ══════════════════════════════════════════════════════════════════════════════

from enum import Enum, auto
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
import hashlib
import traceback


class ExecutionPhase(Enum):
    """Phases of the intelligent execution cycle."""

    DISCOVERY = auto()  # Understand the codebase
    PLANNING = auto()  # Create execution plan
    VALIDATION = auto()  # Pre-execution validation
    EXECUTION = auto()  # Execute the plan
    VERIFICATION = auto()  # Verify results
    RECOVERY = auto()  # Handle failures
    LEARNING = auto()  # Learn from outcome


class TaskPriority(Enum):
    """Task priority levels."""

    CRITICAL = 1  # Must complete first (blockers, security)
    HIGH = 2  # Important (failing tests, errors)
    MEDIUM = 3  # Normal work (features, improvements)
    LOW = 4  # Nice to have (cleanup, docs)


@dataclass
class PlanTask:
    """A single task in the execution plan (for planning purposes)."""

    id: str
    description: str
    priority: TaskPriority
    dependencies: list[str] = field(default_factory=list)
    estimated_complexity: int = 1  # 1-5 scale
    files_involved: list[str] = field(default_factory=list)
    status: str = "pending"  # pending, running, completed, failed, skipped
    result: str = ""
    error: str = ""
    retries: int = 0
    max_retries: int = 3


@dataclass
class ExecutionPlan:
    """A complete execution plan."""

    id: str
    goal: str
    tasks: list[PlanTask] = field(default_factory=list)
    created_at: str = ""
    completed_at: str = ""
    status: str = "pending"
    total_retries: int = 0


@dataclass
class LearningEntry:
    """An entry in the learning database."""

    error_signature: str
    solution_pattern: str
    success_count: int = 0
    failure_count: int = 0
    last_used: str = ""


class IntelligentExecutionEngine:
    """
    The brain of SAGE autopilot - orchestrates intelligent code execution.

    Key capabilities:
    1. Smart task decomposition - breaks complex tasks into atomic units
    2. Dependency-aware execution - respects task dependencies
    3. Parallel execution - runs independent tasks concurrently
    4. Self-healing - learns from failures and auto-recovers
    5. Quality gates - ensures code quality at every step
    6. Incremental validation - validates as it goes
    7. Learning loop - improves over time
    """

    def __init__(self, cwd: Path, renderer, max_workers: int = 4):
        self.cwd = cwd
        self.renderer = renderer
        self.max_workers = max_workers
        self.current_plan: ExecutionPlan | None = None
        self.learning_db: dict[str, LearningEntry] = {}
        self.execution_history: list[dict] = []
        self.lock = Lock()
        self._load_learning_db()

    def _sage_dir(self) -> Path:
        """Get the .sage directory."""
        sage_dir = self.cwd / ".sage"
        sage_dir.mkdir(exist_ok=True)
        return sage_dir

    def _load_learning_db(self) -> None:
        """Load learning database from disk."""
        db_path = self._sage_dir() / "learning.json"
        if db_path.exists():
            try:
                data = _json.loads(db_path.read_text())
                for sig, entry in data.items():
                    self.learning_db[sig] = LearningEntry(**entry)
            except (OSError, _json.JSONDecodeError, TypeError, KeyError) as e:
                # Log but don't fail - learning DB is not critical
                import logging
                logging.getLogger("sage").debug("Failed to load learning DB: %s", e)

    def _save_learning_db(self) -> None:
        """Save learning database to disk."""
        db_path = self._sage_dir() / "learning.json"
        try:
            data = {
                sig: {
                    "error_signature": e.error_signature,
                    "solution_pattern": e.solution_pattern,
                    "success_count": e.success_count,
                    "failure_count": e.failure_count,
                    "last_used": e.last_used,
                }
                for sig, e in self.learning_db.items()
            }
            db_path.write_text(_json.dumps(data, indent=2))
        except (OSError, TypeError) as e:
            # Log but don't fail - learning DB is not critical
            import logging
            logging.getLogger("sage").debug("Failed to save learning DB: %s", e)

    def _compute_error_signature(self, error: str) -> str:
        """Compute a signature for an error to match similar errors."""
        # Normalize the error by removing line numbers, file paths, etc.
        normalized = re.sub(r"line \d+", "line N", error)
        normalized = re.sub(r":\d+:", ":N:", normalized)
        normalized = re.sub(r"/[^/]+\.py", "/FILE.py", normalized)
        normalized = re.sub(r"'[^']+\.py'", "'FILE.py'", normalized)
        return hashlib.md5(normalized.encode()).hexdigest()[:12]

    def learn_from_success(self, error: str, solution: str) -> None:
        """Record a successful solution for an error pattern."""
        sig = self._compute_error_signature(error)
        if sig in self.learning_db:
            entry = self.learning_db[sig]
            entry.success_count += 1
            entry.last_used = datetime.now().isoformat()
        else:
            self.learning_db[sig] = LearningEntry(
                error_signature=sig,
                solution_pattern=solution,
                success_count=1,
                last_used=datetime.now().isoformat(),
            )
        self._save_learning_db()

    def learn_from_failure(self, error: str) -> None:
        """Record a failed attempt at solving an error."""
        sig = self._compute_error_signature(error)
        if sig in self.learning_db:
            self.learning_db[sig].failure_count += 1
            self._save_learning_db()

    def get_learned_solution(self, error: str) -> str | None:
        """Get a previously learned solution for an error."""
        sig = self._compute_error_signature(error)
        if sig in self.learning_db:
            entry = self.learning_db[sig]
            # Only return if success rate is decent
            if entry.success_count > entry.failure_count:
                return entry.solution_pattern
        return None

    def _validate_learning_entry(self, entry: dict) -> bool:
        """Validate learning entry against schema (MEDIUM-14).

        Args:
            entry: Learning entry dict

        Returns:
            True if valid, False otherwise
        """
        required_fields = ["pattern", "solution", "success_rate", "timestamp"]

        # Check required fields
        for field in required_fields:
            if field not in entry:
                return False

        # Validate data types
        if not isinstance(entry.get("pattern"), str):
            return False
        if not isinstance(entry.get("solution"), str):
            return False
        if not isinstance(entry.get("success_rate"), (int, float)):
            return False
        if not isinstance(entry.get("timestamp"), str):
            return False

        # Validate value ranges
        if not (0 <= entry["success_rate"] <= 1.0):
            return False

        return True

    def _check_learning_db_corruption(self, db_path: str) -> bool:
        """Check if learning database is corrupted (MEDIUM-14).

        Args:
            db_path: Path to learning database file

        Returns:
            True if corrupted, False if valid
        """
        try:
            with open(db_path, 'r') as f:
                data = _json.load(f)

            # Basic structure validation
            if not isinstance(data, dict):
                return True

            # Validate entries
            for key, value in data.items():
                if not isinstance(value, dict):
                    return True

            return False

        except (_json.JSONDecodeError, OSError, Exception):
            return True

    def determine_execution_order(self, tasks: list) -> list:
        """Determine execution order based on task priorities (MEDIUM-16).

        Args:
            tasks: List of ExecutionTask objects

        Returns:
            List of tasks sorted by priority
        """
        # Sort by priority (lower number = higher priority)
        return sorted(tasks, key=lambda t: t.priority.value)

    def create_execution_batches(self, tasks: list) -> list[list]:
        """Create execution batches grouping tasks by priority (MEDIUM-16).

        Args:
            tasks: List of ExecutionTask objects

        Returns:
            List of batches, each batch containing tasks of same priority
        """
        from itertools import groupby

        # Sort by priority first
        sorted_tasks = self.determine_execution_order(tasks)

        # Group by priority
        batches = []
        for _, group in groupby(sorted_tasks, key=lambda t: t.priority):
            batches.append(list(group))

        return batches

    def analyze_codebase(self) -> dict:
        """Analyze the codebase to understand its structure."""
        analysis = {
            "languages": Counter(),
            "test_files": [],
            "source_files": [],
            "config_files": [],
            "entry_points": [],
            "total_files": 0,
            "total_lines": 0,
            "has_tests": False,
            "test_framework": None,
            "package_manager": None,
        }

        # Detect package manager and test framework
        if (self.cwd / "pyproject.toml").exists():
            analysis["package_manager"] = "poetry/pip"
            content = (self.cwd / "pyproject.toml").read_text()
            if "pytest" in content:
                analysis["test_framework"] = "pytest"
        elif (self.cwd / "package.json").exists():
            analysis["package_manager"] = "npm"
            content = (self.cwd / "package.json").read_text()
            if "jest" in content:
                analysis["test_framework"] = "jest"
            elif "vitest" in content:
                analysis["test_framework"] = "vitest"
        elif (self.cwd / "Cargo.toml").exists():
            analysis["package_manager"] = "cargo"
            analysis["test_framework"] = "cargo test"
        elif (self.cwd / "go.mod").exists():
            analysis["package_manager"] = "go"
            analysis["test_framework"] = "go test"

        # Scan files
        for fp in self.cwd.rglob("*"):
            if fp.is_file() and not any(
                p.startswith(".") for p in fp.parts[len(self.cwd.parts) :]
            ):
                if "__pycache__" in str(fp) or "node_modules" in str(fp):
                    continue

                ext = fp.suffix.lower()
                analysis["total_files"] += 1

                if ext in {".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java"}:
                    analysis["languages"][ext] += 1

                    # Count lines
                    try:
                        analysis["total_lines"] += len(fp.read_text().splitlines())
                    except Exception:
                        pass

                    # Categorize
                    name = fp.name.lower()
                    rel_path = str(fp.relative_to(self.cwd))

                    if "test" in name or rel_path.startswith("tests/"):
                        analysis["test_files"].append(rel_path)
                        analysis["has_tests"] = True
                    elif name in {
                        "main.py",
                        "app.py",
                        "index.js",
                        "index.ts",
                        "main.go",
                        "main.rs",
                    }:
                        analysis["entry_points"].append(rel_path)
                        analysis["source_files"].append(rel_path)
                    else:
                        analysis["source_files"].append(rel_path)

                elif ext in {".json", ".toml", ".yaml", ".yml"}:
                    analysis["config_files"].append(str(fp.relative_to(self.cwd)))

        return analysis

    def decompose_task(
        self, task_description: str, codebase_analysis: dict
    ) -> list[PlanTask]:
        """
        Intelligently decompose a complex task into atomic subtasks.

        This is the key to intelligent execution - breaking down work into
        manageable, verifiable units.
        """
        tasks = []
        task_id = 0

        def make_task(
            desc: str,
            priority: TaskPriority,
            deps: list[str] = None,
            complexity: int = 1,
            files: list[str] = None,
        ) -> PlanTask:
            nonlocal task_id
            task_id += 1
            return PlanTask(
                id=f"task_{task_id}",
                description=desc,
                priority=priority,
                dependencies=deps or [],
                estimated_complexity=complexity,
                files_involved=files or [],
            )

        # Analyze the task description
        lower_task = task_description.lower()

        # Pattern: Fix/Debug tasks
        if any(kw in lower_task for kw in ["fix", "debug", "error", "bug", "failing"]):
            tasks.append(
                make_task(
                    "Run tests to identify failing tests and errors",
                    TaskPriority.CRITICAL,
                    complexity=1,
                )
            )
            tasks.append(
                make_task(
                    "Analyze error messages and tracebacks",
                    TaskPriority.CRITICAL,
                    deps=["task_1"],
                    complexity=2,
                )
            )
            tasks.append(
                make_task(
                    "Identify root cause of failures",
                    TaskPriority.HIGH,
                    deps=["task_2"],
                    complexity=3,
                )
            )
            tasks.append(
                make_task(
                    "Implement fix for root cause",
                    TaskPriority.HIGH,
                    deps=["task_3"],
                    complexity=3,
                )
            )
            tasks.append(
                make_task(
                    "Verify fix resolves the issue",
                    TaskPriority.HIGH,
                    deps=["task_4"],
                    complexity=1,
                )
            )

        # Pattern: Add feature tasks
        elif any(kw in lower_task for kw in ["add", "implement", "create", "build"]):
            tasks.append(
                make_task(
                    "Analyze existing codebase architecture",
                    TaskPriority.HIGH,
                    complexity=2,
                )
            )
            tasks.append(
                make_task(
                    "Identify files to modify or create",
                    TaskPriority.HIGH,
                    deps=["task_1"],
                    complexity=2,
                )
            )
            if codebase_analysis.get("has_tests"):
                tasks.append(
                    make_task(
                        "Write failing tests for new feature (TDD RED phase)",
                        TaskPriority.HIGH,
                        deps=["task_2"],
                        complexity=3,
                    )
                )
                tasks.append(
                    make_task(
                        "Implement feature to make tests pass (TDD GREEN phase)",
                        TaskPriority.HIGH,
                        deps=["task_3"],
                        complexity=4,
                    )
                )
            else:
                tasks.append(
                    make_task(
                        "Implement the feature",
                        TaskPriority.HIGH,
                        deps=["task_2"],
                        complexity=4,
                    )
                )
            tasks.append(
                make_task(
                    "Run full test suite and fix any regressions",
                    TaskPriority.HIGH,
                    deps=[f"task_{len(tasks)}"],
                    complexity=2,
                )
            )

        # Pattern: Refactor tasks
        elif any(
            kw in lower_task for kw in ["refactor", "improve", "optimize", "clean"]
        ):
            tasks.append(
                make_task(
                    "Run existing tests to establish baseline",
                    TaskPriority.CRITICAL,
                    complexity=1,
                )
            )
            tasks.append(
                make_task(
                    "Identify code to refactor",
                    TaskPriority.HIGH,
                    deps=["task_1"],
                    complexity=2,
                )
            )
            tasks.append(
                make_task(
                    "Apply refactoring changes",
                    TaskPriority.HIGH,
                    deps=["task_2"],
                    complexity=3,
                )
            )
            tasks.append(
                make_task(
                    "Verify tests still pass after refactoring",
                    TaskPriority.CRITICAL,
                    deps=["task_3"],
                    complexity=1,
                )
            )

        # Pattern: Test tasks
        elif any(kw in lower_task for kw in ["test", "coverage"]):
            tasks.append(
                make_task(
                    "Analyze existing test coverage",
                    TaskPriority.HIGH,
                    complexity=2,
                )
            )
            tasks.append(
                make_task(
                    "Identify untested code paths",
                    TaskPriority.HIGH,
                    deps=["task_1"],
                    complexity=2,
                )
            )
            tasks.append(
                make_task(
                    "Write tests for uncovered code",
                    TaskPriority.HIGH,
                    deps=["task_2"],
                    complexity=4,
                )
            )
            tasks.append(
                make_task(
                    "Run full test suite",
                    TaskPriority.HIGH,
                    deps=["task_3"],
                    complexity=1,
                )
            )

        # Default: Generic improvement
        else:
            tasks.append(
                make_task(
                    "Understand current state of codebase",
                    TaskPriority.HIGH,
                    complexity=2,
                )
            )
            tasks.append(
                make_task(
                    "Run validation to establish baseline",
                    TaskPriority.HIGH,
                    deps=["task_1"],
                    complexity=1,
                )
            )
            tasks.append(
                make_task(
                    f"Execute: {task_description}",
                    TaskPriority.MEDIUM,
                    deps=["task_2"],
                    complexity=3,
                )
            )
            tasks.append(
                make_task(
                    "Verify changes work correctly",
                    TaskPriority.HIGH,
                    deps=["task_3"],
                    complexity=1,
                )
            )

        return tasks

    def create_plan(self, goal: str) -> ExecutionPlan:
        """Create an execution plan for a goal."""
        analysis = self.analyze_codebase()
        tasks = self.decompose_task(goal, analysis)

        plan = ExecutionPlan(
            id=f"plan_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            goal=goal,
            tasks=tasks,
            created_at=datetime.now().isoformat(),
        )

        self.current_plan = plan
        return plan

    def get_ready_tasks(self, plan: ExecutionPlan) -> list[PlanTask]:
        """Get tasks that are ready to execute (dependencies met)."""
        completed_ids = {t.id for t in plan.tasks if t.status == "completed"}
        ready = []

        for task in plan.tasks:
            if task.status != "pending":
                continue

            # Check if all dependencies are completed
            deps_met = all(dep_id in completed_ids for dep_id in task.dependencies)
            if deps_met:
                ready.append(task)

        return ready

    def estimate_total_complexity(self, plan: ExecutionPlan) -> int:
        """Estimate total complexity of a plan."""
        return sum(t.estimated_complexity for t in plan.tasks)

    def get_completion_percentage(self, plan: ExecutionPlan) -> float:
        """Get completion percentage of a plan."""
        if not plan.tasks:
            return 100.0

        completed = sum(1 for t in plan.tasks if t.status == "completed")
        return (completed / len(plan.tasks)) * 100


class QualityGate:
    """
    Quality gates that code must pass before being accepted.

    Gates:
    1. Syntax validation - code must parse
    2. Import validation - imports must resolve
    3. Test file validation - tests should contain real assertions
    4. Static diagnostics - surface LSP/type errors when local tools exist
    5. Security scan - block obvious risky patterns in written code
    """

    def __init__(self, cwd: Path, renderer):
        self.cwd = cwd
        self.renderer = renderer
        self.gates_passed: dict[str, bool] = {}
        self.lsp_client = LSPClient(cwd)
        self.security_auditor = SecurityAuditor(cwd)

    def check_syntax(self, filepath: str, content: str) -> tuple[bool, str]:
        """Check if code has valid syntax."""
        if filepath.endswith(".py"):
            try:
                compile(content, filepath, "exec")
                return True, "Syntax OK"
            except SyntaxError as e:
                return False, f"Syntax error at line {e.lineno}: {e.msg}"

        # For other languages, assume OK (LSP will catch later)
        return True, "Syntax check skipped"

    def check_imports(self, filepath: str, content: str) -> tuple[bool, list[str]]:
        """Check if all imports can be resolved."""
        if not filepath.endswith(".py"):
            return True, []

        imports = _extract_imports_from_python(content)
        missing = []

        for module in imports:
            if not _module_exists_in_codebase(module, self.cwd):
                missing.append(module)

        return len(missing) == 0, missing

    def check_test_file(self, filepath: str, content: str) -> tuple[bool, str]:
        """Validate test file quality."""
        if not ("test_" in filepath or filepath.startswith("tests/")):
            return True, "Not a test file"

        # Check for assertions
        has_assertions = bool(
            re.search(
                r"\b(assert|assertEqual|assertTrue|assertFalse|assertRaises|"
                r"assertIn|assertIsNone|expect\(|should\.|pytest\.raises)",
                content,
            )
        )

        if not has_assertions:
            return False, "Test file has no assertions"

        # Check for empty test functions
        empty_tests = len(re.findall(r"def test_\w+\([^)]*\):\s*\n\s*pass", content))
        if empty_tests > 0:
            return False, f"Test file has {empty_tests} empty test functions"

        return True, "Test file OK"

    def check_boilerplate(self, filepath: str, content: str) -> tuple[bool, list[str]]:
        """Check for boilerplate/placeholder code patterns.

        Returns (is_valid, list_of_issues).
        """
        issues = []

        # Check for placeholder patterns
        placeholder_patterns = [
            (r"# TODO[:\s]", "TODO comment found"),
            (r"# FIXME[:\s]", "FIXME comment found"),
            (r"# implement\s+this", "placeholder 'implement this' comment"),
            (r"raise\s+NotImplementedError", "NotImplementedError raised - incomplete implementation"),
            (r"pass\s*#\s*placeholder", "placeholder pass statement"),
            (r"\.\.\.\s*#\s*rest", "ellipsis placeholder"),
        ]

        for pattern, message in placeholder_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                issues.append(message)

        # Check for empty functions (just 'pass')
        empty_funcs = re.findall(r"def\s+(\w+)\([^)]*\):\s*\n\s*(?:#[^\n]*)?\s*pass\s*(?:\n|$)", content)
        if len(empty_funcs) >= 2:
            issues.append(f"Multiple empty functions: {', '.join(empty_funcs[:5])}")

        # Check for repetitive method signatures (copy-paste generation)
        func_names = re.findall(r"def\s+(\w+)\s*\(", content)
        if len(func_names) > 10:
            base_names = [re.sub(r"_\d+$", "", name) for name in func_names]
            from collections import Counter
            name_counts = Counter(base_names)
            most_common = name_counts.most_common(1)
            if most_common and most_common[0][1] >= 5:
                issues.append(f"Repetitive function names - {most_common[0][1]} functions starting with '{most_common[0][0]}'")

        return len(issues) == 0, issues

    def check_implementation_completeness(self, filepath: str, content: str) -> tuple[bool, list[str]]:
        """Check if implementation is complete and not just stubs.

        Returns (is_valid, list_of_issues).
        """
        issues = []

        # Skip test files
        if "test_" in filepath or filepath.startswith("tests/"):
            return True, []

        # Count functions
        func_pattern = r"def\s+\w+\([^)]*\):"
        functions = re.findall(func_pattern, content)

        if not functions:
            return True, []  # No functions to check

        # Check each function for actual implementation
        # A function with only docstring and pass/return None is incomplete
        incomplete_pattern = r"def\s+(\w+)\([^)]*\):\s*\n\s*(?:\"\"\"[^\"]*\"\"\"\s*)?\s*(?:pass|return\s+None)\s*(?:\n|$)"
        incomplete = re.findall(incomplete_pattern, content)

        if len(incomplete) > len(functions) // 2:
            issues.append(f"More than half of functions are incomplete stubs: {', '.join(incomplete[:5])}")

        return len(issues) == 0, issues

    def check_static_diagnostics(self, filepath: str) -> tuple[bool, list[str]]:
        """Check for static diagnostics when language tooling is available."""
        diagnostics = self.lsp_client.check_file(filepath)
        errors = [
            f"{diag.source} {diag.file}:{diag.line}:{diag.column} {diag.message}"
            for diag in diagnostics
            if diag.severity == "error"
        ]
        return len(errors) == 0, errors

    def check_security(self, filepath: str) -> tuple[bool, list[str]]:
        """Check a file for blocking security findings."""
        findings = self.security_auditor.scan_files([filepath])
        blocking = [
            f"[{finding.severity}] {finding.file}:{finding.line} {finding.message}"
            for finding in findings
            if finding.severity in {"CRITICAL", "HIGH"}
        ]
        return len(blocking) == 0, blocking

    def run_all_gates(self, filepath: str, content: str) -> tuple[bool, list[str]]:
        """Run all quality gates on a file."""
        issues = []

        # Gate 1: Syntax
        ok, msg = self.check_syntax(filepath, content)
        if not ok:
            issues.append(f"Syntax: {msg}")

        # Gate 2: Imports
        ok, missing = self.check_imports(filepath, content)
        if not ok:
            issues.append(f"Imports: Missing modules: {', '.join(missing)}")

        # Gate 3: Test quality
        ok, msg = self.check_test_file(filepath, content)
        if not ok:
            issues.append(f"Test quality: {msg}")

        # Gate 4: Static diagnostics
        ok, diagnostics = self.check_static_diagnostics(filepath)
        if not ok:
            issues.append(f"Diagnostics: {'; '.join(diagnostics[:5])}")

        # Gate 5: Security findings
        ok, findings = self.check_security(filepath)
        if not ok:
            issues.append(f"Security: {'; '.join(findings[:5])}")

        # Gate 6: Boilerplate/placeholder detection
        ok, boilerplate_issues = self.check_boilerplate(filepath, content)
        if not ok:
            issues.append(f"Boilerplate: {'; '.join(boilerplate_issues[:3])}")

        # Gate 7: Implementation completeness
        ok, completeness_issues = self.check_implementation_completeness(filepath, content)
        if not ok:
            issues.append(f"Incomplete: {'; '.join(completeness_issues[:3])}")

        all_passed = len(issues) == 0
        self.gates_passed[filepath] = all_passed

        return all_passed, issues


class IncrementalValidator:
    """
    Validates code incrementally as it's written.

    Instead of waiting until the end, we validate:
    1. After each file is written
    2. After each logical unit is complete
    3. Before proceeding to next task
    """

    def __init__(self, cwd: Path, renderer, test_cmd: str = ""):
        self.cwd = cwd
        self.renderer = renderer
        # Parse scoped prefix from test command
        self.test_cmd, self.test_cmd_cwd = self._parse_scoped_cmd(
            test_cmd or "python -m pytest -v --tb=short"
        )
        self.validation_cache: dict[str, tuple[bool, str]] = {}
        self.last_validation_time: float = 0
        self.min_validation_interval: float = 2.0  # seconds

    def _parse_scoped_cmd(self, cmd: str) -> tuple[str, Path]:
        """Parse [cwd=...] prefix from command and return (clean_cmd, effective_cwd)."""
        match = re.match(r"^\s*\[(?:cwd|dir)=(.+?)\]\s*(.*)$", cmd, re.DOTALL)
        if match:
            rel_path = match.group(1).strip()
            clean_cmd = match.group(2).strip()
            effective_cwd = self.cwd / rel_path
            return clean_cmd, effective_cwd
        return cmd.strip(), self.cwd

    def validate_file(self, filepath: str) -> tuple[bool, str]:
        """Validate a single file immediately after it's written."""
        full_path = self.cwd / filepath

        if not full_path.exists():
            return False, f"File not found: {filepath}"

        # Quick syntax check for Python
        if filepath.endswith(".py"):
            try:
                content = full_path.read_text()
                compile(content, filepath, "exec")
            except SyntaxError as e:
                return False, f"Syntax error at line {e.lineno}: {e.msg}"

        return True, "File OK"

    def validate_unit(self, files: list[str]) -> tuple[bool, str]:
        """Validate a logical unit (e.g., a test file + its implementation)."""
        # First validate individual files
        for fp in files:
            ok, msg = self.validate_file(fp)
            if not ok:
                return False, f"{fp}: {msg}"

        # Then run related tests
        test_files = [f for f in files if "test_" in f or f.startswith("tests/")]
        if test_files:
            return self._run_tests(test_files)

        return True, "Unit validated"

    def _run_tests(self, test_files: list[str]) -> tuple[bool, str]:
        """Run specific test files.

        P0-10-15: Uses safe command execution instead of shell=True.
        """
        # Rate limit test runs
        now = time.time()
        if now - self.last_validation_time < self.min_validation_interval:
            time.sleep(self.min_validation_interval - (now - self.last_validation_time))

        self.last_validation_time = time.time()

        # Run pytest on specific files using safe execution
        cmd = f"{self.test_cmd} {' '.join(test_files)}"
        result = _execute_command(
            cmd,
            cwd=self.test_cmd_cwd,
            timeout=60,
            allow_shell=True,  # Test commands may have shell constructs
            validate=False,  # Already validated test command
        )

        if result.success:
            return True, "Tests passed"
        elif result.timed_out:
            return False, "Test timeout"
        elif result.error:
            return False, f"Test error: {result.error}"
        else:
            # Extract failure summary
            summary = self._extract_failure_summary(result.output)
            return False, summary

    def _extract_failure_summary(self, output: str) -> str:
        """Extract a concise failure summary from test output."""
        lines = output.split("\n")
        summary_lines = []

        in_summary = False
        for line in lines:
            if "FAILED" in line or "ERROR" in line:
                summary_lines.append(line.strip())
            elif "short test summary" in line.lower():
                in_summary = True
            elif in_summary and line.strip():
                summary_lines.append(line.strip())
                if len(summary_lines) > 10:
                    break

        return "\n".join(summary_lines[:10]) if summary_lines else output[-500:]

    def _quick_test_check(self) -> tuple[bool, str]:
        """Quick check if test command will work at all (10 second limit).

        P0-10-15: Uses safe command execution instead of shell=True.
        """
        # Try to collect tests without running them
        # Note: This uses shell operators (|, 2>/dev/null) so needs allow_shell=True
        collect_cmd = f"{self.test_cmd} --collect-only -q 2>/dev/null | head -20"
        result = _execute_command(
            collect_cmd,
            cwd=self.test_cmd_cwd,
            timeout=10,
            allow_shell=True,  # Has shell operators
            validate=False,
        )

        if result.timed_out:
            return (
                False,
                "Test collection timed out - test suite may have import errors",
            )
        elif result.error:
            return False, f"Quick check failed: {result.error}"
        elif result.success:
            return True, result.stdout[:500]
        else:
            # If collect fails, the test suite has issues
            return False, result.stderr[:500] if result.stderr else result.stdout[:500]

    def full_validation(self, timeout: int = 120) -> tuple[bool, str]:
        """Run full project validation with smart timeout handling.

        P0-10-15: Uses safe command execution instead of shell=True.
        """
        # Handle empty or invalid test command
        if not self.test_cmd or not self.test_cmd.strip():
            return True, "No test command configured - skipping validation"

        # First do a quick check to see if tests will even collect
        quick_ok, quick_msg = self._quick_test_check()
        if not quick_ok:
            # If quick check fails, report it but don't block
            if "import" in quick_msg.lower() or "module" in quick_msg.lower():
                return (
                    False,
                    f"Test collection failed (likely import errors): {quick_msg[:200]}",
                )

        # Use a reasonable timeout (default 120s, not 300s)
        result = _execute_command(
            self.test_cmd,
            cwd=self.test_cmd_cwd,
            timeout=timeout,
            allow_shell=True,  # Test commands may have shell constructs
            validate=False,  # Already validated
        )

        if result.success:
            return True, "All tests passed"
        elif result.timed_out:
            return (
                False,
                f"Test suite timed out after {timeout}s - suite may be too large or stuck",
            )
        elif result.error and "not found" in result.error.lower():
            return True, f"Test directory not found: {self.test_cmd_cwd} - skipping"
        elif result.error:
            return False, f"Validation error: {result.error}"
        else:
            return False, self._extract_failure_summary(result.output)


class FreeModelRouter:
    """
    Intelligent routing to free model providers.

    Optimizes for:
    1. Model capability for the task
    2. Rate limits and availability
    3. Response quality
    4. Speed
    """

    # Free providers in order of capability
    FREE_PROVIDERS = [
        {"name": "pollinations", "model": "openai", "capability": 5, "rate_limit": 100},
        {
            "name": "ollama",
            "model": "qwen2.5-coder:7b",
            "capability": 4,
            "rate_limit": float("inf"),
        },
        {
            "name": "ollama",
            "model": "deepseek-coder:6.7b",
            "capability": 4,
            "rate_limit": float("inf"),
        },
        {
            "name": "ollama",
            "model": "codellama:7b",
            "capability": 3,
            "rate_limit": float("inf"),
        },
        {
            "name": "gemini",
            "model": "gemini-1.5-flash",
            "capability": 5,
            "rate_limit": 15,
        },
    ]

    def __init__(self, renderer):
        self.renderer = renderer
        self.usage_counts: dict[str, int] = {}
        self.last_reset: float = time.time()
        self.failure_counts: dict[str, int] = {}

    def _reset_if_needed(self) -> None:
        """Reset usage counts every hour."""
        if time.time() - self.last_reset > 3600:
            self.usage_counts = {}
            self.last_reset = time.time()

    def get_best_provider(self, task_complexity: int = 3) -> dict | None:
        """Get the best available provider for a task."""
        self._reset_if_needed()

        # Filter by capability and availability
        candidates = []
        for provider in self.FREE_PROVIDERS:
            key = f"{provider['name']}:{provider['model']}"
            current_usage = self.usage_counts.get(key, 0)
            failures = self.failure_counts.get(key, 0)

            # Skip if rate limited or too many failures
            if current_usage >= provider["rate_limit"]:
                continue
            if failures > 5:
                continue

            # Check if capability matches task
            if provider["capability"] >= task_complexity:
                candidates.append((provider, current_usage, failures))

        if not candidates:
            return None

        # Sort by: capability (desc), failures (asc), usage (asc)
        candidates.sort(key=lambda x: (-x[0]["capability"], x[2], x[1]))

        return candidates[0][0]

    def record_usage(self, provider_name: str, model: str) -> None:
        """Record a usage of a provider."""
        key = f"{provider_name}:{model}"
        self.usage_counts[key] = self.usage_counts.get(key, 0) + 1

    def record_failure(self, provider_name: str, model: str) -> None:
        """Record a failure from a provider."""
        key = f"{provider_name}:{model}"
        self.failure_counts[key] = self.failure_counts.get(key, 0) + 1

    def record_success(self, provider_name: str, model: str) -> None:
        """Record a success, reducing failure count."""
        key = f"{provider_name}:{model}"
        if key in self.failure_counts and self.failure_counts[key] > 0:
            self.failure_counts[key] -= 1


class SelfHealingSystem:
    """
    Self-healing system that automatically recovers from errors.

    Capabilities:
    1. Auto-retry with exponential backoff
    2. Error pattern matching
    3. Automatic rollback
    4. Alternative approach selection
    """

    COMMON_FIXES = {
        "ModuleNotFoundError": "Delete test files importing non-existent modules",
        "ImportError": "Check import paths and module existence",
        "SyntaxError": "Fix syntax error at indicated line",
        "IndentationError": "Fix indentation at indicated line",
        "NameError": "Define the missing variable or import",
        "TypeError": "Check argument types and function signatures",
        "AttributeError": "Verify object has the attribute or method",
        "AssertionError": "Test assertion failed - check test logic",
    }

    def __init__(
        self, cwd: Path, renderer, learning_engine: IntelligentExecutionEngine
    ):
        self.cwd = cwd
        self.renderer = renderer
        self.learning = learning_engine
        self.recovery_attempts: dict[str, int] = {}
        self.max_recovery_attempts = 3

    def can_recover(self, error: str) -> bool:
        """Check if we can attempt recovery for this error."""
        sig = self.learning._compute_error_signature(error)
        attempts = self.recovery_attempts.get(sig, 0)
        return attempts < self.max_recovery_attempts

    def analyze_error(self, error: str) -> dict:
        """Analyze an error and determine recovery strategy."""
        analysis = {
            "error_type": None,
            "suggested_fix": None,
            "learned_solution": None,
            "files_involved": [],
            "recoverable": True,
        }

        # Detect error type
        for error_type in self.COMMON_FIXES:
            if error_type in error:
                analysis["error_type"] = error_type
                analysis["suggested_fix"] = self.COMMON_FIXES[error_type]
                break

        # Check for learned solution
        learned = self.learning.get_learned_solution(error)
        if learned:
            analysis["learned_solution"] = learned

        # Extract file paths from error
        file_matches = re.findall(r"([a-zA-Z0-9_/]+\.py)", error)
        analysis["files_involved"] = list(set(file_matches))

        return analysis

    def attempt_recovery(
        self, error: str, written_files: list[str]
    ) -> tuple[bool, str]:
        """Attempt to automatically recover from an error."""
        sig = self.learning._compute_error_signature(error)
        self.recovery_attempts[sig] = self.recovery_attempts.get(sig, 0) + 1

        analysis = self.analyze_error(error)

        # Strategy 1: Delete broken test files for import errors
        if analysis["error_type"] in ("ModuleNotFoundError", "ImportError"):
            broken = _detect_broken_test_files(error, self.cwd)
            if broken:
                deleted = _cleanup_broken_tests(broken, self.renderer)
                if deleted:
                    return True, f"Deleted {len(deleted)} broken test file(s)"

        # Strategy 2: Use learned solution
        if analysis["learned_solution"]:
            return False, f"Try learned solution: {analysis['learned_solution']}"

        # Strategy 3: Suggest fix based on error type
        if analysis["suggested_fix"]:
            return False, f"Suggested fix: {analysis['suggested_fix']}"

        return False, "Unable to auto-recover, manual intervention needed"

    def reset_recovery_state(self) -> None:
        """Reset recovery attempt counts."""
        self.recovery_attempts = {}


app = typer.Typer(
    name="sage",
    help="Sage — local-first AI coding assistant",
    no_args_is_help=True,
    add_completion=False,
)

config_app = typer.Typer(help="Manage configuration")
app.add_typer(config_app, name="config")


# ── Shared setup ────────────────────────────────────────────


def _resolve_model_prefix(model_id: str, cfg: SageConfig) -> str:
    """Add a provider prefix to a bare model name if possible.

    'gemma4'           → 'ollama:gemma4'   (if in Ollama catalog)
    'deepseek-coder'   → 'ollama:deepseek-coder'
    'Qwen2.5-Coder-1.5B-Instruct-Q4_K_M' → 'llama_cpp:Qwen2.5-Coder-1.5B-Instruct-Q4_K_M'
    Already-prefixed IDs are returned unchanged.
    """
    # Known provider prefixes — if the model starts with one, it's already resolved
    _PROVIDER_PREFIXES = {
        "llama_cpp",
        "ollama",
        "cloud",
        "gemini",
        "openai",
        "groq",
        "together",
        "pollinations",
    }
    if ":" in model_id:
        prefix = model_id.split(":")[0]
        if prefix in _PROVIDER_PREFIXES:
            return model_id
        # Otherwise it might be an Ollama tag like "gemma3:latest"

    # Check if it's a registered local GGUF model
    if cfg.get_local_model(model_id) is not None:
        return f"llama_cpp:{model_id}"

    # Check if it's in the GGUF catalog
    if model_id in CATALOG_BY_NAME and CATALOG_BY_NAME[model_id].backend == "gguf":
        return f"llama_cpp:{model_id}"

    # Check if it's in the Ollama catalog or matches an Ollama model name
    if model_id in OLLAMA_BY_NAME:
        return f"ollama:{model_id}"
    # Also check without 'ollama:' prefix in catalog keys
    for key in OLLAMA_BY_NAME:
        bare = key.removeprefix("ollama:")
        if bare == model_id:
            return f"ollama:{model_id}"

    # Check if Ollama is running and has this model
    try:
        import httpx as _hx

        resp = _hx.get("http://localhost:11434/api/tags", timeout=3)
        if resp.status_code == 200:
            pulled = {m["name"].split(":")[0] for m in resp.json().get("models", [])}
            if model_id in pulled or model_id.split(":")[0] in pulled:
                return f"ollama:{model_id}"
    except Exception:
        pass

    # Default: assume Ollama if it looks like an Ollama model name (lowercase, no path separators)
    if "/" not in model_id and not model_id.endswith(".gguf"):
        return f"ollama:{model_id}"

    return model_id


def _ensure_model_available(cfg: SageConfig, model_id: str) -> SageConfig:
    """Auto-download a local model if it's not installed yet.

    For llama_cpp models: downloads the GGUF from catalog and registers it.
    For ollama models: checks if Ollama is running, auto-pulls if needed.
    For bare names: resolves the provider prefix first.
    Returns the (possibly updated) config.
    """
    # Resolve bare model names to prefixed ones
    resolved = _resolve_model_prefix(model_id, cfg)

    if resolved.startswith("llama_cpp:"):
        model_name = resolved.removeprefix("llama_cpp:")
        # Already registered and file exists?
        entry = cfg.get_local_model(model_name)
        if entry and Path(entry.path).exists():
            return cfg

        # Look up in catalog
        cat_model = CATALOG_BY_NAME.get(model_name)
        if cat_model and cat_model.backend == "gguf":
            if is_downloaded(cat_model):
                # Downloaded but not registered
                register_model(cat_model)
                return load_config()

            renderer.info(f"Model '{model_name}' not found locally — downloading...")
            try:

                def _progress(done: int, total: int) -> None:
                    pct = done / total * 100 if total else 0
                    mb = done / 1024 / 1024
                    total_mb = total / 1024 / 1024 if total else 0
                    print(
                        f"\r  Downloading: {mb:.0f}/{total_mb:.0f} MB ({pct:.0f}%)",
                        end="",
                        flush=True,
                        file=sys.stderr,
                    )

                download_model(cat_model, progress_callback=_progress)
                print(file=sys.stderr)  # newline after progress
                register_model(cat_model)
                renderer.step_done(f"Downloaded and registered '{model_name}'")
                return load_config()
            except Exception as exc:
                renderer.warning(f"Auto-download failed: {exc}")
                renderer.info("Falling back to cloud model.")

    elif resolved.startswith("ollama:"):
        ollama_name = resolved.removeprefix("ollama:")
        # Check if Ollama is running
        try:
            import httpx as _hx

            resp = _hx.get("http://localhost:11434/api/tags", timeout=3)
            if resp.status_code != 200:
                raise ConnectionError()
            # Ollama is running — auto-pull will happen in OllamaProvider._ensure_pulled()
        except Exception:
            renderer.warning(
                f"Ollama is not running. Model '{ollama_name}' needs Ollama."
            )
            renderer.info("Start Ollama with: ollama serve")
            renderer.info("Falling back to cloud model.")

    return cfg


def _build_router(cfg: SageConfig) -> ProviderRouter:
    """Instantiate all providers and return a configured router."""
    providers: list[ProviderBase] = [
        GeminiProvider(cfg),
        LlamaCppProvider(cfg),
        OllamaProvider(cfg),
        *build_openai_compat_providers(cfg),
    ]
    return ProviderRouter(providers, default_model=cfg.default_model)


def _model_capability_score(model: ModelInfo) -> int:
    text = f"{model.provider}:{model.id} {model.name}".lower()
    score = 0
    if any(k in text for k in ("reason", "reasoning", "r1")):
        score += 40
    if any(k in text for k in ("405b", "235b", "180b", "120b", "70b", "67b", "72b")):
        score += 45
    elif any(k in text for k in ("34b", "32b", "27b", "24b", "22b", "14b")):
        score += 25
    elif any(k in text for k in ("8b", "7b")):
        score += 8
    if any(k in text for k in ("3b", "2b", "1.5b", "1b")):
        score -= 18
    if model.provider in {"deepseek", "groq", "openrouter", "cerebras", "deepinfra"}:
        score += 12
    if model.provider == "pollinations":
        score -= 12
    if model.local:
        score -= 3
    return score


def _auto_upgrade_model_if_possible(
    router: ProviderRouter,
    cfg: SageConfig,
    chosen_model: str,
    explicit_model: str | None,
    last_used_model: str | None,
) -> str:
    if explicit_model:
        return chosen_model
    if cfg.default_model != SageConfig.default_model:
        return chosen_model
    if last_used_model and last_used_model != cfg.default_model:
        return chosen_model
    models = list(router.list_all_models())
    if not models:
        return chosen_model

    baseline_provider, baseline_id = (
        chosen_model.split(":", 1) if ":" in chosen_model else ("", chosen_model)
    )
    baseline = ModelInfo(
        id=baseline_id,
        provider=baseline_provider or "unknown",
        name=chosen_model,
        local=baseline_provider == "llama_cpp",
    )
    baseline_score = _model_capability_score(baseline)
    best = max(models, key=_model_capability_score)
    if _model_capability_score(best) < baseline_score + 12:
        return chosen_model
    return f"{best.provider}:{best.id}"


def _read_stdin() -> str | None:
    """Read piped input if stdin is not a terminal."""
    if sys.stdin.isatty():
        return None
    return sys.stdin.read()


# ── Prompt History ─────────────────────────────────────────


def _sage_dir(cwd: Path) -> Path:
    """Return .sage/ directory in the project root, creating if needed."""
    d = cwd / ".sage"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _prompt_history_path(cwd: Path) -> Path:
    return _sage_dir(cwd) / "prompt_history.json"


def _session_state_path(cwd: Path) -> Path:
    return _sage_dir(cwd) / "session_state.json"


def _autopolit_stop_path(cwd: Path) -> Path:
    return _sage_dir(cwd) / "autopolit.stop"


def _load_session_state(cwd: Path) -> dict:
    path = _session_state_path(cwd)
    if not path.exists():
        return {}
    try:
        return _json.loads(path.read_text("utf-8"))
    except (ValueError, OSError):
        return {}


def _save_session_state(cwd: Path, state: dict) -> None:
    path = _session_state_path(cwd)
    path.write_text(_json.dumps(state, indent=2) + "\n", "utf-8")


def _get_last_used_model(cwd: Path) -> str | None:
    state = _load_session_state(cwd)
    value = state.get("last_model")
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _set_last_used_model(cwd: Path, model_id: str) -> None:
    if not model_id.strip():
        return
    state = _load_session_state(cwd)
    state["last_model"] = model_id
    state["updated_at"] = datetime.now().isoformat(timespec="seconds")
    _save_session_state(cwd, state)


def _load_prompt_history(cwd: Path) -> list[dict]:
    """Load prompt history from .sage/prompt_history.json."""
    path = _prompt_history_path(cwd)
    if not path.exists():
        return []
    try:
        return _json.loads(path.read_text("utf-8"))
    except (ValueError, OSError):
        return []


def _save_prompt_history(cwd: Path, history: list[dict]) -> None:
    """Save prompt history, keeping the last 100 entries."""
    path = _prompt_history_path(cwd)
    history = history[-100:]  # Keep last 100
    path.write_text(_json.dumps(history, indent=2) + "\n", "utf-8")


def _add_to_prompt_history(cwd: Path, prompt: str) -> None:
    """Add a user prompt to the history file."""
    if not prompt.strip() or prompt.startswith("/") or prompt.startswith("!"):
        return
    history = _load_prompt_history(cwd)
    entry = {
        "prompt": prompt,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }
    # Deduplicate: remove previous identical prompt
    history = [h for h in history if h.get("prompt") != prompt]
    history.append(entry)
    _save_prompt_history(cwd, history)


def _build_prompt_reader(cwd: Path) -> Callable[[str], str]:
    """Build an input reader with arrow-key history when available.

    Uses prompt_toolkit in interactive terminals. Falls back to Rich input in
    non-interactive/test environments.
    """
    if sys.stdin.isatty() and sys.stdout.isatty():
        try:
            from prompt_toolkit import PromptSession
            from prompt_toolkit.history import InMemoryHistory

            history = InMemoryHistory()
            for item in _load_prompt_history(cwd):
                text = (item.get("prompt") or "").strip()
                if text:
                    history.append_string(text)
            session = PromptSession(history=history)
            return lambda prompt_text: session.prompt(prompt_text)
        except Exception:
            pass
    return lambda prompt_text: renderer.console.input(prompt_text)


def _scan_project_context(
    cwd: Path,
    max_tree: int = 40,
    max_config_chars: int = 400,
    max_source_files: int = 10,
    max_source_lines: int = 60,
) -> str:
    """Scan the project directory and return a compact context string.

    Reads the file tree, detects languages, git status, config files,
    and the first N lines of key source files for deep codebase context.
    """
    skip_dirs = {
        ".git",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        "dist",
        "build",
        ".next",
        ".cache",
        "target",
        ".tox",
        "egg-info",
        ".eggs",
        ".mypy_cache",
        ".pytest_cache",
    }
    source_exts = {
        ".py",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".rs",
        ".go",
        ".java",
        ".c",
        ".cpp",
        ".rb",
        ".sh",
    }
    ext_map = {
        ".py": "Python",
        ".js": "JavaScript",
        ".ts": "TypeScript",
        ".tsx": "TypeScript/React",
        ".jsx": "React",
        ".rs": "Rust",
        ".go": "Go",
        ".java": "Java",
        ".c": "C",
        ".cpp": "C++",
        ".rb": "Ruby",
        ".sh": "Shell",
        ".html": "HTML",
        ".css": "CSS",
        ".json": "JSON",
        ".yaml": "YAML",
        ".yml": "YAML",
        ".toml": "TOML",
        ".md": "Markdown",
    }

    all_files: list[str] = []
    source_files: list[Path] = []
    lang_counts: dict[str, int] = {}
    for p in sorted(cwd.rglob("*")):
        rel = p.relative_to(cwd)
        if any(
            part.startswith(".") or any(s in part for s in skip_dirs)
            for part in rel.parts
        ):
            continue
        if p.is_file():
            all_files.append(str(rel))
            ext = p.suffix.lower()
            if ext in ext_map:
                lang = ext_map[ext]
                lang_counts[lang] = lang_counts.get(lang, 0) + 1
            if ext in source_exts:
                source_files.append(p)

    sorted_langs = sorted(lang_counts.items(), key=lambda x: -x[1])
    primary_lang = sorted_langs[0][0] if sorted_langs else "Unknown"

    # Git context
    git_info = ""
    try:
        branch = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            text=True,
            cwd=str(cwd),
            timeout=5,
        ).strip()
        status = subprocess.check_output(
            ["git", "status", "--short"],
            text=True,
            cwd=str(cwd),
            timeout=5,
        ).strip()
        git_info = f"Branch: {branch}"
        if status:
            git_info += f"\nChanged:\n{status}"
    except Exception:
        git_info = "(not a git repo)"

    # Config files
    config_names = [
        "pyproject.toml",
        "package.json",
        "Cargo.toml",
        "go.mod",
        "requirements.txt",
        "Makefile",
        "Dockerfile",
    ]
    configs = []
    for cf in config_names:
        cf_path = cwd / cf
        if cf_path.exists():
            try:
                configs.append(
                    f"--- {cf} ---\n{cf_path.read_text('utf-8')[:max_config_chars]}"
                )
            except Exception:
                pass

    # Read key source files for deep codebase understanding
    source_previews: list[str] = []
    # Prioritize entry points, main files, and smaller files
    priority_names = {"main", "app", "index", "cli", "__init__", "server", "config"}

    def _sort_key(p: Path) -> tuple:
        stem = p.stem.lower()
        is_priority = 0 if stem in priority_names else 1
        return (is_priority, p.stat().st_size)

    try:
        source_files.sort(key=_sort_key)
    except OSError:
        pass

    for sf in source_files[:max_source_files]:
        try:
            rel = sf.relative_to(cwd)
            lines = sf.read_text("utf-8", errors="replace").splitlines()[
                :max_source_lines
            ]
            if lines:
                numbered = "\n".join(f"{i+1:>4}| {l}" for i, l in enumerate(lines))
                source_previews.append(
                    f"--- {rel} (first {len(lines)} lines) ---\n{numbered}"
                )
        except Exception:
            pass

    parts = [
        f"CWD: {cwd}",
        f"Lang: {primary_lang} | {', '.join(f'{l}({n})' for l, n in sorted_langs[:5])}",
        f"Git: {git_info}",
        f"Files ({len(all_files)}):",
    ]
    for f in all_files[:max_tree]:
        parts.append(f"  {f}")
    if len(all_files) > max_tree:
        parts.append(f"  ... +{len(all_files) - max_tree} more")
    if configs:
        parts.append("Config:")
        parts.extend(configs)
    if source_previews:
        parts.append("\nKey source files:")
        parts.extend(source_previews)
    return "\n".join(parts)


# NOTE: Shell utilities (_extract_scoped_prefix, _resolve_scoped_directory,
# _run_shell, _read_file_context, _extract_bash_blocks) moved to sage/core/shell.py


def _extract_tool_commands(text: str) -> list[tuple[str, str]]:
    """Extract READ:, SEARCH:, and RUN: tool commands from model output.

    Returns list of (tool_type, argument) tuples.
    """
    commands: list[tuple[str, str]] = []
    for m in re.finditer(
        r"^\s*(?:[-*]\s*)?(READ|SEARCH|RUN):\s*(.+)$", text, re.MULTILINE
    ):
        tool_type = m.group(1).upper()
        arg = m.group(2).strip()
        if arg:
            commands.append((tool_type, arg))
    return commands


# NOTE: _sanitize_shell_block and _strip_search_comment moved to sage/core/shell.py


def _discover_project_paths(
    cwd: Path,
    pattern: str,
    max_results: int = 40,
) -> list[str]:
    """Return file-path matches for glob-style SEARCH patterns."""
    matches: list[str] = []
    skip_dirs = {
        ".git",
        ".venv",
        "venv",
        "__pycache__",
        "node_modules",
        "dist",
        "build",
        ".pytest_cache",
        ".mypy_cache",
        ".sage",
    }

    try:
        candidates = sorted(cwd.rglob(pattern))
    except (OSError, ValueError, re.error):
        return matches

    for candidate in candidates:
        if not candidate.is_file():
            continue
        rel = candidate.relative_to(cwd)
        if any(part in skip_dirs or part.startswith(".") for part in rel.parts):
            continue
        matches.append(rel.as_posix())
        if len(matches) >= max_results:
            break
    return matches


def _split_search_patterns(pattern: str) -> list[str]:
    """Split a SEARCH expression into one or more concrete patterns."""
    cleaned = pattern.strip()
    if not cleaned:
        return []
    if any(ch in cleaned for ch in "*?[]"):
        return [cleaned]

    raw_parts = [cleaned]
    if re.search(r"\s+(?:OR|or)\s+", cleaned):
        raw_parts = re.split(r"\s+(?:OR|or)\s+", cleaned)
    elif "|" in cleaned and not any(ch in cleaned for ch in "(){}[]"):
        raw_parts = cleaned.split("|")

    parts: list[str] = []
    seen: set[str] = set()
    for part in raw_parts:
        normalized = part.strip().strip('"').strip("'").strip()
        if normalized and normalized not in seen:
            parts.append(normalized)
            seen.add(normalized)
    return parts or [cleaned]


def _tool_context_needs_more_investigation(tool_context: str) -> bool:
    """Return True when tool output is too weak to support grounded analysis."""
    sections = [section.strip() for section in tool_context.split("\n\n") if section.strip()]
    if not sections:
        return True

    negative_markers = (
        "file not found or empty",
        "no matches found",
        "no path matches found",
        "error:",
        "outside workspace",
        "scoped directory not found",
        "empty command",
        "no results found",
    )
    positive_markers = (
        "File: ",
        "Directory: ",
        "Search results for ",
        "Path matches for ",
        "Output:\n",
    )

    has_positive_signal = any(
        any(marker in section for marker in positive_markers) for section in sections
    )
    all_negative = all(
        any(marker in section.lower() for marker in negative_markers) for section in sections
    )
    return all_negative or not has_positive_signal


def _build_readonly_response_retry_prompt(
    response: str,
    classification: _ClassifiedRequest | None,
    *,
    verified_files: set[str] | None = None,
    cumulative_item_count: int | None = None,
) -> str | None:
    """Build a continuation prompt when a read-only response is incomplete or weak."""
    if not classification or not classification.read_only:
        return None

    # P0-1: Use cumulative count if provided, otherwise extract from current response
    if cumulative_item_count is not None:
        numbered_items = cumulative_item_count
    else:
        # Use unified extraction for consistent counting
        numbered_items = _extract_list_item_count(response)

    if (
        classification.request_type == _RequestType.LIST_GENERATION
        and classification.quantity_required
        and numbered_items < classification.quantity_required
    ):
        remaining = classification.quantity_required - numbered_items
        next_item = numbered_items + 1
        return (
            f"CONTINUE immediately from item {next_item}. You have {numbered_items} items, need {classification.quantity_required} total ({remaining} more).\n\n"
            f"CRITICAL: Output ONLY numbered list items starting with '{next_item}. ' — no explanations, no meta-commentary.\n"
            f"Do NOT explain why you can't continue. Do NOT ask for more context. Just generate items.\n\n"
            f"Start your response with:\n{next_item}. "
        )

    validation = _validate_classified_response(
        response,
        classification,
        verified_files=verified_files or set(),
    )
    if not validation.should_retry:
        return None

    retry_prompt = validation.retry_prompt or "Regenerate your response with the required corrections."
    grounding_rules = (
        "\nGROUNDING RULES:\n"
        "- Reference only files or code locations supported by verified READ:/SEARCH: results.\n"
        "- If you do not have enough evidence for a claim, say so explicitly instead of inventing facts.\n"
        "- Keep the response read-only: no FILE: blocks, tests, or implementation steps.\n"
    )
    return retry_prompt + grounding_rules


def _build_readonly_exploration_nudge(
    phase_name: str,
    classification: _ClassifiedRequest | None,
    *,
    has_verified_files: bool,
) -> str | None:
    """Ask the model to issue concrete investigation commands before analysis claims."""
    if not classification or not classification.read_only:
        return None
    if phase_name not in {"planning", "analysis"}:
        return None
    if has_verified_files:
        return None

    return (
        "This is read-only analysis and you have not gathered grounded evidence yet.\n"
        "Issue concrete investigation commands now before making substantive claims.\n"
        "Rules:\n"
        "1. Use READ: on real files (not directories unless you need a listing).\n"
        "2. Use SEARCH: with one pattern per line (no OR combinations on one line).\n"
        "3. Use RUN: only for safe read-only commands.\n"
        "4. After commands run, base findings only on verified results."
    )


def _execute_tool_commands(commands: list[tuple[str, str]], cwd: Path) -> list[str]:
    """Execute tool commands and return results as context strings.

    Also records evidence via the global evidence tracker for synthesis gating.
    """
    results: list[str] = []
    for tool_type, arg in commands:
        if tool_type == "READ":
            content = _read_file_context(arg, cwd, max_lines=200)
            if content:
                renderer.phase("reading", f"📄 {arg}")
                results.append(content)
                # Record successful file read as evidence
                _record_file_read(arg.strip().lstrip("./"), success=True)
            else:
                results.append(f"[READ {arg}: file not found or empty]")
                # Record failed file read
                _record_file_read(arg.strip().lstrip("./"), success=False)
        elif tool_type == "SEARCH":
            scope, pattern = _extract_scoped_prefix(arg)
            pattern = _strip_search_comment(pattern)
            search_cwd = cwd
            if scope:
                search_cwd, error = _resolve_scoped_directory(scope, cwd)
                if error:
                    results.append(error)
                    continue
            if any(ch in pattern for ch in "*?[]"):
                renderer.phase(
                    "searching",
                    f"🔍 {pattern}" if not scope else f"🔍 {scope}: {pattern}",
                )
                matches = _discover_project_paths(search_cwd, pattern)
                if matches:
                    results.append(
                        f"Path matches for '{pattern}'"
                        + (f" in {scope}" if scope else "")
                        + ":\n"
                        + "\n".join(matches)
                    )
                    # Record successful glob search as evidence
                    _record_search(pattern, matches)
                else:
                    results.append(
                        f"[SEARCH '{pattern}'"
                        + (f" in {scope}" if scope else "")
                        + ": no path matches found]"
                    )
                    # Record empty search
                    _record_search(pattern, [])
                continue
            search_patterns = _split_search_patterns(pattern)
            if len(search_patterns) > 1:
                renderer.phase(
                    "searching",
                    (
                        f"🔍 any of: {', '.join(search_patterns[:3])}"
                        if not scope
                        else f"🔍 {scope}: any of {', '.join(search_patterns[:3])}"
                    ),
                )
                combined: list[str] = []
                for term in search_patterns:
                    lines_result = _run_shell(
                        f"grep -rn --include='*.py' --include='*.js' --include='*.ts' "
                        f"--include='*.jsx' --include='*.tsx' --include='*.go' --include='*.rs' "
                        f"--include='*.java' --include='*.yaml' --include='*.yml' "
                        f"--include='*.json' --include='*.toml' --include='*.md' "
                        f"--include='Dockerfile' --include='requirements*.txt' "
                        f"{_shell_quote(term)} . 2>/dev/null | head -20",
                        search_cwd,
                        timeout=10,
                    ).strip()
                    if lines_result:
                        combined.append(f"[term: {term}]\n{lines_result}")
                if combined:
                    results.append(
                        f"Search results for any of {search_patterns}"
                        + (f" in {scope}" if scope else "")
                        + ":\n"
                        + "\n".join(combined)
                    )
                    # Record successful multi-pattern search as evidence
                    # Extract file paths from grep results
                    found_files = []
                    for line in "\n".join(combined).splitlines():
                        if ":" in line and not line.startswith("[term:"):
                            file_part = line.split(":")[0].lstrip("./")
                            if file_part and file_part not in found_files:
                                found_files.append(file_part)
                    _record_search(f"any of {search_patterns}", found_files)
                else:
                    results.append(
                        f"[SEARCH any of {search_patterns}"
                        + (f" in {scope}" if scope else "")
                        + ": no matches found]"
                    )
                    # Record empty search
                    _record_search(f"any of {search_patterns}", [])
                continue
            renderer.phase(
                "searching",
                f"🔍 {pattern}" if not scope else f"🔍 {scope}: {pattern}",
            )
            search_result = _run_shell(
                f"grep -rn --include='*.py' --include='*.js' --include='*.ts' "
                f"--include='*.jsx' --include='*.tsx' --include='*.go' --include='*.rs' "
                f"--include='*.java' --include='*.yaml' --include='*.yml' "
                f"--include='*.json' --include='*.toml' --include='*.md' "
                f"-l {_shell_quote(pattern)} . 2>/dev/null | head -20",
                search_cwd,
                timeout=10,
            )
            if search_result.strip():
                # Also grab matching lines for context
                lines_result = _run_shell(
                    f"grep -rn --include='*.py' --include='*.js' --include='*.ts' "
                    f"--include='*.jsx' --include='*.tsx' --include='*.go' --include='*.rs' "
                    f"--include='*.java' --include='*.yaml' --include='*.yml' "
                    f"--include='*.json' --include='*.toml' --include='*.md' "
                    f"{_shell_quote(pattern)} . 2>/dev/null | head -40",
                    search_cwd,
                    timeout=10,
                )
                results.append(
                    f"Search results for '{pattern}'"
                    + (f" in {scope}" if scope else "")
                    + f":\n{lines_result}"
                )
                # Record successful search as evidence
                found_files = [
                    f.strip().lstrip("./") for f in search_result.strip().splitlines() if f.strip()
                ]
                _record_search(pattern, found_files)
            else:
                results.append(
                    f"[SEARCH '{pattern}'"
                    + (f" in {scope}" if scope else "")
                    + ": no matches found]"
                )
                # Record empty search
                _record_search(pattern, [])
        elif tool_type == "RUN":
            scope, command = _extract_scoped_prefix(arg)
            label = command[:60] if command else arg[:60]
            renderer.phase(
                "running",
                f"⚡ {label}" if not scope else f"⚡ {scope}: {label}",
            )
            with renderer.status_spinner(
                (
                    f"Running: {label[:60]}..."
                    if not scope
                    else f"Running in {scope}: {label[:60]}..."
                ),
                "executing",
            ):
                output = _run_shell(arg, cwd, timeout=60)
            renderer.print_shell_output(output)
            results.append(f"[RUN: {arg}]\nOutput:\n{output}")
    return results


# NOTE: _shell_quote moved to sage/core/shell.py


# Names that are language tags, not real filenames — reject these
_INVALID_FILENAMES = {
    "bash",
    "sh",
    "shell",
    "python",
    "javascript",
    "typescript",
    "java",
    "ruby",
    "go",
    "rust",
    "c",
    "cpp",
    "html",
    "css",
    "sql",
    "json",
    "yaml",
    "yml",
    "toml",
    "xml",
    "text",
    "txt",
    "markdown",
    "md",
    "jsx",
    "tsx",
    "php",
    "perl",
    "swift",
    "kotlin",
    "scala",
    "r",
    "dockerfile",
    "makefile",
}


def _write_file(
    filepath_str: str,
    content: str,
    cwd: Path,
    protected_files: set[str] | None = None,
) -> str | None:
    """Safely write a file under *cwd*. Returns the relative path or None.

    Rejects:
    - Language tag names without extensions (e.g., 'bash', 'python')
    - Files without any extension or directory component
    - Path traversal attacks
    - Files in the protected set (existing project files)
    - Files with syntax errors (Python, JSON)
    - Files that appear truncated or incomplete
    """
    cwd_str = str(cwd)
    if filepath_str.startswith(cwd_str):
        filepath_str = filepath_str[len(cwd_str) :].lstrip("/")
    filepath_str = filepath_str.lstrip("/")

    # Reject bare language tags (model wrote "FILE: bash")
    if filepath_str.lower() in _INVALID_FILENAMES:
        renderer.warning(f"Rejected invalid filename: {filepath_str}")
        return None

    # Reject files with no extension and no directory (likely a mistake)
    if "/" not in filepath_str and "." not in filepath_str:
        renderer.warning(f"Rejected filename without extension: {filepath_str}")
        return None

    # Block overwriting protected files (existing project files)
    if protected_files and filepath_str in protected_files:
        renderer.warning(f"Blocked overwrite of existing file: {filepath_str}")
        return None

    # PRE-VALIDATION: Check content before writing
    is_valid, error = _pre_validate_content(filepath_str, content)
    if not is_valid:
        renderer.warning(f"Rejected {filepath_str}: {error}")
        return None

    try:
        target = (cwd / filepath_str).resolve()
        if not str(target).startswith(str(cwd.resolve())):
            renderer.warning(f"Path traversal blocked: {filepath_str}")
            return None
    except (ValueError, OSError):
        return None
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return filepath_str
    except OSError as exc:
        renderer.warning(f"Could not write {filepath_str}: {exc}")
        return None


def _extract_and_write_files(
    output: str,
    cwd: Path,
    protected_files: set[str] | None = None,
    files_read: set[str] | None = None,
) -> list[str]:
    """Parse model output for file blocks and write them to disk.

    Recognizes:
      1. FILE: path/to/file.ext\\n```\\ncontent\\n```
      2. ```path/to/file.ext\\ncontent\\n```

    protected_files: set of relative paths that should not be overwritten.
    files_read: set of paths that have been READ (enforces READ-before-write for existing files).
    Rejects garbage code (empty functions, no assertions in tests, placeholders).

    ENFORCEMENT: If the current request is classified as read-only (ANALYSIS, LIST_GENERATION,
    QUESTION, SEARCH), ALL FILE: blocks are rejected to prevent accidental code generation.
    """
    written: list[str] = []
    seen: set[str] = set()
    files_read = files_read or set()

    # ══════════════════════════════════════════════════════════════════════════
    # CRITICAL ENFORCEMENT: Block file writes for read-only request types
    # BUT still extract and display list/analysis content from the response
    # ══════════════════════════════════════════════════════════════════════════
    classification = _get_current_classification()
    if classification and classification.read_only:
        if classification.request_type == _RequestType.LIST_GENERATION:
            output = _dedupe_numbered_list_items(output)
        # Check if there are any FILE: blocks in the output
        if "FILE:" in output:
            file_count = output.count("FILE:")
            renderer.warning(
                f"🚫 BLOCKED: {file_count} FILE: block(s) rejected — "
                f"request type is {classification.request_type.name} (read-only analysis). "
                "The user asked for analysis/listing, not code changes."
            )

        # CRITICAL FIX: For LIST_GENERATION, extract and display the list content
        # even though we're not writing any files
        if classification.request_type == _RequestType.LIST_GENERATION:
            # Use unified extraction for consistent counting across SAGE
            item_count = _extract_list_item_count(output)
            detailed_items = _extract_list_items_detailed(output)

            if item_count > 0 and renderer.is_verbose():
                renderer.info(f"📋 Extracted {item_count} list items from response")
                if item_count > 10 and detailed_items:
                    first_items = [d["content"][:40] for d in detailed_items[:5]]
                    last_items = [d["content"][:40] for d in detailed_items[-3:]]
                    renderer.info(f"   First items: {', '.join(first_items)}...")
                    renderer.info(f"   Last items: ...{', '.join(last_items)}")

        return []  # Return empty - no files written for read-only requests

    # ══════════════════════════════════════════════════════════════════════════
    # ROBUST FILE BLOCK EXTRACTION - Handles multiple formats from various models
    # ══════════════════════════════════════════════════════════════════════════

    # Patterns to match FILE: blocks in order of specificity
    file_block_patterns = [
        # Pattern 1: FILE: path\n```lang\ncontent\n``` (most common)
        r"FILE:\s*(\S+)\s*\n```[^\n]*\n(.*?)```",
        # Pattern 2: FILE: path (with optional colon after path)\n```content```
        r"FILE:\s*([^\n:]+?)(?::\s*)?\n```[^\n]*\n(.*?)```",
        # Pattern 3: **FILE:** path\n```content``` (markdown bold)
        r"\*\*FILE:\*\*\s*(\S+)\s*\n```[^\n]*\n(.*?)```",
        # Pattern 4: `FILE: path`\n```content``` (inline code)
        r"`FILE:\s*(\S+)`\s*\n```[^\n]*\n(.*?)```",
        # Pattern 5: ### FILE: path\n```content``` (header style)
        r"#+\s*FILE:\s*(\S+)\s*\n```[^\n]*\n(.*?)```",
    ]

    pending_filepaths: list[str] = []
    for pattern in file_block_patterns:
        for m in re.finditer(pattern, output, re.DOTALL):
            pending_filepaths.append(m.group(1).strip().rstrip(":"))
    pending_modules = _pending_modules_for_files(pending_filepaths)

    for pattern in file_block_patterns:
        for m in re.finditer(pattern, output, re.DOTALL):
            fp = m.group(1).strip().rstrip(":")  # Remove trailing colon if present
            content = m.group(2)
            if fp in seen:
                continue
            seen.add(fp)

            # ══════════════════════════════════════════════════════════════════════════
            # VALIDATE FILE PATH AGAINST ACTUAL CODEBASE STRUCTURE
            # ══════════════════════════════════════════════════════════════════════════
            is_valid_path, path_error = _validate_file_path_against_codebase(fp, cwd)
            if not is_valid_path:
                renderer.warning(
                    f"🚫 REJECTED FILE PATH '{fp}': {path_error}"
                )
                continue

            # Enforce READ-before-write for existing files
            normalized_fp = fp.lstrip("./")
            target_path = cwd / normalized_fp
            if target_path.exists() and normalized_fp not in files_read:
                # File exists but wasn't READ first - reject to prevent blind overwrites
                renderer.warning(
                    f"Rejected write to {fp}: existing file must be READ first. "
                    "Use READ: {fp} before modifying."
                )
                continue

            # Check for garbage content before writing
            is_garbage, reason = _is_garbage_content(fp, content)
            if is_garbage:
                renderer.warning(f"Rejected garbage file {fp}: {reason}")
                continue

            # Validate imports for ALL Python files (not just tests)
            if fp.endswith(".py"):
                # First check for hallucinated code patterns
                is_hallucinated, hallucination_reason = _is_likely_hallucinated_code(
                    content,
                    cwd,
                    pending_modules=pending_modules,
                )
                if is_hallucinated:
                    renderer.warning(
                        f"🚫 REJECTED {fp}: {hallucination_reason}. "
                        "Check AVAILABLE MODULES list before importing!"
                    )
                    continue

                # Then validate all imports
                is_valid, missing = _validate_imports_in_content(
                    content,
                    cwd,
                    pending_modules=pending_modules,
                )
                if not is_valid:
                    # More specific error message based on file type
                    if "test_" in fp or fp.startswith("tests/"):
                        renderer.warning(
                            f"🚫 REJECTED test file {fp}: imports non-existent modules: {', '.join(missing)}. "
                            "Use SEARCH: to find actual modules in this codebase first."
                        )
                    else:
                        renderer.warning(
                            f"🚫 REJECTED {fp}: imports non-existent modules: {', '.join(missing)}. "
                            "Either the modules don't exist or you need to create them first."
                        )
                    continue

            result = _write_file(fp, content, cwd, protected_files=protected_files)
            if result:
                written.append(result)

    if written:
        return written

    # Pattern 2 (fallback): ```filename.ext\ncontent\n```
    lang_tags = {
        "python",
        "javascript",
        "typescript",
        "bash",
        "sh",
        "json",
        "yaml",
        "yml",
        "toml",
        "html",
        "css",
        "sql",
        "go",
        "rust",
        "java",
        "c",
        "cpp",
        "ruby",
        "php",
        "jsx",
        "tsx",
    }
    for m in re.finditer(r"```(\S+)\s*\n(.*?)```", output, re.DOTALL):
        tag = m.group(1).strip()
        content = m.group(2)
        if tag.lower() in lang_tags:
            continue
        if "." not in tag and "/" not in tag:
            continue
        if tag in seen:
            continue
        seen.add(tag)

        # Enforce READ-before-write for existing files
        normalized_tag = tag.lstrip("./")
        target_path = cwd / normalized_tag
        if target_path.exists() and normalized_tag not in files_read:
            renderer.warning(
                f"Rejected write to {tag}: existing file must be READ first."
            )
            continue

        # Check for garbage content before writing
        is_garbage, reason = _is_garbage_content(tag, content)
        if is_garbage:
            renderer.warning(f"Rejected garbage file {tag}: {reason}")
            continue

        # Validate imports for Python test files before writing
        if tag.endswith(".py") and ("test_" in tag or tag.startswith("tests/")):
            is_valid, missing = _validate_imports_in_content(
                content,
                cwd,
                pending_modules=pending_modules,
            )
            if not is_valid:
                renderer.warning(
                    f"Rejected test file {tag}: imports non-existent modules: {', '.join(missing)}. "
                    "Use SEARCH: to find actual modules in this codebase first."
                )
                continue

        result = _write_file(tag, content, cwd, protected_files=protected_files)
        if result:
            written.append(result)

    return written


# NOTE: Prompt templates moved to sage/core/prompts.py (P3-71)


def _run_validation_command(cmd: str, cwd: Path, timeout: int = 120) -> tuple[str, str]:
    """Run a validation command, falling back from `python -m pytest` to `pytest`."""
    output = _run_shell(cmd, cwd, timeout=timeout)
    if "No module named pytest" in output and "python -m pytest" in cmd:
        cmd = cmd.replace("python -m pytest", "pytest", 1)
        output = _run_shell(cmd, cwd, timeout=timeout)
    return cmd, output


def _syntax_precheck(written: list[str], cwd: Path) -> tuple[bool, str]:
    """Pre-check syntax of written files before running tests.

    Returns (all_ok, error_details).
    This catches errors early before slower test runs.
    """
    errors = []
    for filepath in written:
        full_path = cwd / filepath
        if not full_path.exists():
            continue

        # Python syntax check
        if filepath.endswith(".py"):
            result = _run_shell(
                f'python -m py_compile "{filepath}"',
                cwd,
                timeout=10,
            )
            # Filter out pytest-cov/coverage warnings that aren't actual syntax errors
            is_real_error = (
                result.strip()
                and ("SyntaxError" in result or "exit code: 1" in result)
                and "pytest-cov" not in result
                and "COV_CORE" not in result
            )
            if is_real_error:
                # Get more detailed error with line number
                detail_result = _run_shell(
                    f"python -c \"import ast; ast.parse(open({shlex.quote(filepath)}).read())\"",
                    cwd,
                    timeout=10,
                )
                # Only record if ast.parse also fails (confirms real syntax error)
                if "SyntaxError" in detail_result or "Error" in detail_result:
                    errors.append(f"SYNTAX ERROR in {filepath}:\n{detail_result}")

        # JavaScript/TypeScript basic check
        elif filepath.endswith((".js", ".ts", ".jsx", ".tsx")):
            # Check for obvious syntax errors using node --check if available
            result = _run_shell(
                f'node --check "{filepath}" 2>&1 || echo "exit code: $?"',
                cwd,
                timeout=10,
            )
            if "SyntaxError" in result or "Unexpected" in result:
                errors.append(f"SYNTAX ERROR in {filepath}:\n{result}")

        # JSON validation
        elif filepath.endswith(".json"):
            result = _run_shell(
                f"python -c \"import json; json.load(open({shlex.quote(filepath)}))\"",
                cwd,
                timeout=5,
            )
            if "Error" in result or "exit code" in result:
                errors.append(f"INVALID JSON in {filepath}:\n{result}")

        # YAML validation
        elif filepath.endswith((".yml", ".yaml")):
            result = _run_shell(
                f"python -c \"import yaml; yaml.safe_load(open({shlex.quote(filepath)}))\"",
                cwd,
                timeout=5,
            )
            if "Error" in result or "exit code" in result:
                errors.append(f"INVALID YAML in {filepath}:\n{result}")

    if errors:
        return False, "\n\n".join(errors)
    return True, ""


def _auto_validate(written: list[str], cwd: Path) -> str | None:
    """Run automatic validation on written files. Returns (cmd, output) or None.

    Validation order:
    1. Syntax pre-check (fast, catches obvious errors)
    2. Project-specific validation (pytest, npm test, etc.)
    3. Fallback syntax-only check if no test framework found
    """
    # Step 1: Fast syntax pre-check
    syntax_ok, syntax_errors = _syntax_precheck(written, cwd)
    if not syntax_ok:
        return "syntax pre-check", syntax_errors

    # Step 2: Project-specific validation
    validation_cmd = _validation_command_for_written_files(written, cwd)
    if validation_cmd:
        return _run_validation_command(validation_cmd, cwd, timeout=120)

    # Step 3: Fallback - at least check Python files compile
    runnable = _detect_runnable_files(written)
    if runnable:
        checks = []
        for f in runnable:
            result = _run_shell(
                f"python -c \"import ast; ast.parse(open({shlex.quote(f)}).read())\"",
                cwd,
                timeout=10,
            )
            if "exit code" in result or "Error" in result:
                checks.append(f"{f}: {result}")
        if checks:
            return "python syntax check", "\n".join(checks)

    return None


# ══════════════════════════════════════════════════════════════════════════════
# IMPLEMENTATION INTEGRITY - Phantom Implementation Detection
# ══════════════════════════════════════════════════════════════════════════════

def _detect_phantom_implementation(
    response_text: str,
    files_written: list[str],
    is_implementation_request: bool
) -> tuple[bool, str]:
    """Detect if response claims implementation but didn't actually write files.

    Args:
        response_text: The model's response
        files_written: List of files actually written
        is_implementation_request: Whether this was an implementation request

    Returns:
        Tuple of (is_phantom, reason)
    """
    if not is_implementation_request:
        return False, ""

    # Check for implementation claims
    impl_claims = [
        "implementation complete",
        "implemented",
        "i've implemented",
        "i have implemented",
        "code is now ready",
        "tests pass",
        "all tests pass",
    ]

    response_lower = response_text.lower()
    has_claim = any(claim in response_lower for claim in impl_claims)

    # Check for code snippets
    has_code_snippets = "```python" in response_text or "```javascript" in response_text or "```typescript" in response_text

    # If claims implementation or shows code but wrote no files, it's phantom
    if (has_claim or has_code_snippets) and len(files_written) == 0:
        return True, "claimed implementation but no files written"

    return False, ""


def _validate_implementation_response(
    response_text: str,
    files_written: list[str],
    is_implementation_request: bool
) -> tuple[bool, str]:
    """Validate that implementation responses contain FILE: blocks or RUN: commands.

    Args:
        response_text: The model's response
        files_written: List of files actually written
        is_implementation_request: Whether this was an implementation request

    Returns:
        Tuple of (is_valid, reason)
    """
    if not is_implementation_request:
        return True, ""

    has_file_blocks = "FILE:" in response_text
    has_run_commands = "RUN:" in response_text
    has_read_commands = "READ:" in response_text

    # Implementation must have FILE: blocks or RUN: commands (not just READ:)
    if not has_file_blocks and not has_run_commands:
        # Check if it's just planning/analysis
        if has_read_commands:
            return True, ""  # Just reading/researching is okay

        return False, "Implementation response must contain FILE: blocks or RUN: commands with actual code"

    return True, ""


def _validate_tdd_compliance(
    response_text: str,
    files_written: list[str],
    is_implementation_request: bool
) -> tuple[bool, str]:
    """Validate that TDD claims are backed by actual file writes.

    Args:
        response_text: The model's response
        files_written: List of files actually written
        is_implementation_request: Whether this was an implementation request

    Returns:
        Tuple of (is_compliant, reason)
    """
    if not is_implementation_request:
        return True, ""

    # Check for TDD claims
    tdd_claims = [
        "tdd",
        "test-driven",
        "tests first",
        "write tests",
        "created test",
    ]

    response_lower = response_text.lower()
    claims_tdd = any(claim in response_lower for claim in tdd_claims)

    if claims_tdd and len(files_written) == 0:
        return False, "Response claimed TDD process but no files were written (no FILE: blocks executed)"

    # If claims TDD, should have test files
    if claims_tdd and len(files_written) > 0:
        has_test_files = any("test" in f.lower() for f in files_written)
        if not has_test_files:
            return False, "Claimed TDD but no test files were written"

    return True, ""


def _default_test_command(cwd: Path) -> str:
    """Pick a sensible default pytest command for the current project."""
    project_root = _default_project_root(cwd)
    inner = _discover_project_test_command(project_root)
    if inner:
        return _command_from_project_root(project_root, inner, cwd)
    return "python -m pytest -v --tb=short"


def _full_project_test_command(cwd: Path) -> str:
    """Pick a full-project validation command for the current project."""
    project_root = _default_project_root(cwd)
    inner = _discover_project_full_test_command(project_root)
    if inner:
        return _command_from_project_root(project_root, inner, cwd)
    return "python -m pytest -v --tb=short"


def _collect_autopolit_priority_hints(cwd: Path, max_items: int = 6) -> list[str]:
    """Collect whole-codebase risk signals to guide autopolit task choice."""
    findings: list[tuple[int, str]] = []

    def _read_text(path: Path) -> str:
        try:
            return path.read_text("utf-8", errors="replace")
        except OSError:
            return ""

    project_root = _default_project_root(cwd)
    deploy_yml = project_root / ".github" / "workflows" / "deploy.yml"
    backend_app = project_root / "backend" / "app.py"
    pyproject = project_root / "pyproject.toml"
    sage_main = project_root / "sage" / "main.py"
    sage_tests = project_root / "sage" / "tests"

    deploy_text = _read_text(deploy_yml)
    if "--allow-unauthenticated" in deploy_text:
        findings.append(
            (10, "Deployment risk: production deploy is configured as unauthenticated.")
        )

    backend_text = _read_text(backend_app)
    if 'allow_origins=["*"]' in backend_text or 'allow_origins=["*",' in backend_text:
        findings.append(
            (20, "API exposure risk: backend CORS currently allows any origin.")
        )

    pyproject_text = _read_text(pyproject)
    if sage_tests.exists() and "sage/tests" not in pyproject_text:
        findings.append(
            (
                15,
                "Validation gap: default pytest discovery does not include sage/tests.",
            )
        )

    main_text = _read_text(sage_main)
    if main_text:
        line_count = len(main_text.splitlines())
        if line_count >= 8000:
            findings.append(
                (
                    40,
                    f"Maintainability hotspot: sage/main.py is {line_count} lines long.",
                )
            )

        broad_excepts = len(re.findall(r"except Exception", main_text))
        if broad_excepts >= 25:
            findings.append(
                (
                    35,
                    f"Reliability hotspot: sage/main.py has {broad_excepts} broad exception handlers.",
                )
            )

        shell_true_uses = len(re.findall(r"shell=True", main_text))
        if shell_true_uses:
            findings.append(
                (
                    30,
                    f"Command execution risk: sage/main.py uses shell=True {shell_true_uses} times.",
                )
            )

    source_exts = {".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java"}
    large_files: list[tuple[int, str]] = []
    for path in project_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in source_exts:
            continue
        rel = path.relative_to(project_root)
        if any(
            part.startswith(".") or part in {"node_modules", "__pycache__", ".sage"}
            for part in rel.parts
        ):
            continue
        try:
            large_files.append(
                (
                    len(path.read_text("utf-8", errors="replace").splitlines()),
                    rel.as_posix(),
                )
            )
        except OSError:
            continue
    for lines, rel in sorted(large_files, reverse=True)[:3]:
        if lines >= 500:
            findings.append((50, f"Large-file hotspot: {rel} is {lines} lines."))

    findings.sort(key=lambda item: (item[0], item[1]))
    return [message for _, message in findings[:max_items]]


def _response_describes_code_without_file_blocks(response: str) -> bool:
    """Detect code-change narratives that never emit executable FILE blocks."""
    if "FILE:" in response:
        return False

    path_listing = re.search(
        r"(?m)^\s*(?:#+\s*)?(?:[\w.-]+/)+[\w.-]+\.(?:py|js|ts|tsx|jsx|json|toml|ya?ml|sh|md|sql|go|rs|java|css|html)\s*$",
        response,
    )
    has_change_sections = any(
        marker in response
        for marker in ("Code Changes", "Tests Written", "Final Status")
    )
    has_fenced_code = response.count("```") >= 2
    return bool(path_listing and (has_change_sections or has_fenced_code))


def _summarize_test_output(output: str, max_chars: int = 6000) -> str:
    """Condense long test output into failure-focused context for fix prompts."""
    text = output.strip()
    if len(text) <= max_chars:
        return text

    lines = text.splitlines()
    keep: list[str] = []
    for i, line in enumerate(lines):
        low = line.lower()
        if (
            "error collecting" in low
            or "short test summary info" in low
            or "traceback" in low
            or line.startswith("E   ")
            or " failed " in low
            or line.startswith("FAILED ")
            or line.startswith("ERROR ")
        ):
            start = max(0, i - 2)
            end = min(len(lines), i + 6)
            keep.extend(lines[start:end])

    if not keep:
        return text[-max_chars:]

    deduped = []
    seen = set()
    for ln in keep:
        if ln not in seen:
            deduped.append(ln)
            seen.add(ln)
    summary = "\n".join(deduped)
    return summary[:max_chars]


def _detect_broken_test_files(output: str, cwd: Path) -> list[Path]:
    """Detect test files with import errors from test output.

    Returns list of test file paths that should be deleted.

    Enhanced detection handles:
    - ModuleNotFoundError: No module named 'xyz'
    - ImportError: cannot import name 'xyz' from 'module'
    - AttributeError from bad imports
    - SyntaxError in test files
    - Various pytest error collection patterns
    """
    broken_files: list[Path] = []
    seen_files: set[str] = set()

    lines = output.splitlines()
    current_file: Path | None = None

    # ══════════════════════════════════════════════════════════════════════════
    # PATTERN 1: Standard pytest file:line error format
    # ══════════════════════════════════════════════════════════════════════════
    for i, line in enumerate(lines):
        # Detect file path from pytest error collection
        # Patterns:
        #   tests/test_foo.py:1: in <module>
        #   sage/tests/test_bar.py:5: in <module>
        #   ./tests/test_baz.py:10: in test_func
        file_patterns = [
            r"^(tests?/[^\s:]+\.py):\d+:",
            r"^(\./tests?/[^\s:]+\.py):\d+:",
            r"^([^\s:]+/tests?/[^\s:]+\.py):\d+:",
            r"^([^\s:]+test_[^\s:]+\.py):\d+:",
        ]

        for pattern in file_patterns:
            file_match = re.search(pattern, line)
            if file_match:
                filepath = file_match.group(1).lstrip("./")
                current_file = cwd / filepath
                break

        # Detect import errors
        import_error_patterns = [
            r"ModuleNotFoundError:\s*No module named\s*['\"]([^'\"]+)['\"]",
            r"ImportError:\s*cannot import name\s*['\"]([^'\"]+)['\"].*from\s*['\"]([^'\"]+)['\"]",
            r"ImportError:\s*No module named\s*['\"]([^'\"]+)['\"]",
        ]

        for error_pattern in import_error_patterns:
            error_match = re.search(error_pattern, line)
            if error_match and current_file:
                module_name = error_match.group(1).split(".")[0]
                # Check if this is a non-existent local module
                if not _module_exists_in_codebase(module_name, cwd):
                    file_key = str(current_file)
                    if current_file.exists() and file_key not in seen_files:
                        broken_files.append(current_file)
                        seen_files.add(file_key)
                        current_file = None  # Reset after adding
                break

        # Detect syntax errors in test files
        if "SyntaxError" in line or "IndentationError" in line:
            if current_file and current_file.exists():
                file_key = str(current_file)
                if file_key not in seen_files:
                    broken_files.append(current_file)
                    seen_files.add(file_key)
                    current_file = None

    # ══════════════════════════════════════════════════════════════════════════
    # PATTERN 2: "ERROR collecting" pattern
    # ══════════════════════════════════════════════════════════════════════════
    error_collect_patterns = [
        r"error collecting\s+([^\s]+\.py)",
        r"ERROR collecting\s+([^\s]+\.py)",
        r"ERROR\s+([^\s]+test_[^\s]+\.py)",
    ]

    for i, line in enumerate(lines):
        for pattern in error_collect_patterns:
            error_collect_match = re.search(pattern, line, re.IGNORECASE)
            if error_collect_match:
                filepath = error_collect_match.group(1).lstrip("./")
                file_path = cwd / filepath
                file_key = str(file_path)

                if file_path.exists() and file_key not in seen_files:
                    # Check next few lines for import/syntax error
                    for j in range(i, min(i + 15, len(lines))):
                        check_line = lines[j]
                        # Check for module not found
                        module_match = re.search(
                            r"No module named\s*['\"]([^'\"]+)['\"]", check_line
                        )
                        if module_match:
                            module_name = module_match.group(1).split(".")[0]
                            if not _module_exists_in_codebase(module_name, cwd):
                                broken_files.append(file_path)
                                seen_files.add(file_key)
                                break
                        # Check for syntax errors
                        if (
                            "SyntaxError" in check_line
                            or "IndentationError" in check_line
                        ):
                            broken_files.append(file_path)
                            seen_files.add(file_key)
                            break

    # ══════════════════════════════════════════════════════════════════════════
    # PATTERN 3: Scan test files for known bad imports
    # ══════════════════════════════════════════════════════════════════════════
    # If tests directory exists, check for files with obvious import issues
    for tests_dir in ["tests", "test"]:
        tests_path = cwd / tests_dir
        if tests_path.is_dir():
            for test_file in tests_path.glob("test_*.py"):
                file_key = str(test_file)
                if file_key in seen_files:
                    continue

                try:
                    content = test_file.read_text(errors="ignore")
                    # Check if file imports from non-existent modules
                    is_valid, missing = _validate_imports_in_content(content, cwd)
                    if not is_valid and missing:
                        # Check if any missing module appears in the error output
                        for module in missing:
                            if module in output:
                                broken_files.append(test_file)
                                seen_files.add(file_key)
                                break
                except Exception:
                    pass

    return broken_files


def _cleanup_broken_tests(broken_files: list[Path], renderer) -> list[str]:
    """Delete broken test files that import non-existent modules.

    Returns list of deleted file paths.
    """
    deleted: list[str] = []
    for file_path in broken_files:
        try:
            rel_path = str(
                file_path.relative_to(file_path.parent.parent.parent)
                if len(file_path.parts) > 3
                else file_path.name
            )
            file_path.unlink()
            deleted.append(str(file_path))
            renderer.warning(
                f"🗑️  Deleted broken test file: {rel_path} (imports non-existent modules)"
            )
        except OSError as e:
            renderer.warning(f"Could not delete {file_path}: {e}")
    return deleted


def _has_errors(output: str) -> bool:
    """Check if command output indicates failure.

    Comprehensive error detection for multiple languages and frameworks.
    """
    # Python errors
    python_errors = [
        "SyntaxError",
        "IndentationError",
        "TabError",
        "NameError",
        "TypeError",
        "ValueError",
        "KeyError",
        "IndexError",
        "AttributeError",
        "ImportError",
        "ModuleNotFoundError",
        "FileNotFoundError",
        "RuntimeError",
        "ZeroDivisionError",
        "AssertionError",
        "Exception:",
        "Traceback (most recent call last)",
    ]

    # Test framework errors
    test_errors = [
        "FAILED",
        "ERROR",
        "FAILURES",
        "error collecting",
        "E   ",  # pytest assertion error marker
        "✗",  # Jest/Vitest failure
        "✕",  # Another failure marker
        "FAIL ",  # Go test
        "--- FAIL:",  # Go test
        "FAILED TEST",
        "tests? failed",
    ]

    # Build/lint errors
    build_errors = [
        "error:",
        "Error:",
        "error[",  # Rust errors
        "error TS",  # TypeScript errors
        "✖",  # ESLint errors
        "npm ERR!",
        "yarn error",
        "cargo error",
        "build failed",
        "compilation failed",
        "exit code:",
        "exit status 1",
        "returned non-zero",
    ]

    # CI/CD errors
    ci_errors = [
        "check failure",
        "workflow failed",
        "job failed",
        "Action required",
    ]

    all_signals = python_errors + test_errors + build_errors + ci_errors

    # Case-sensitive check for most signals
    for sig in all_signals:
        if sig in output:
            return True

    # Case-insensitive check for generic error patterns
    lower_output = output.lower()
    generic_errors = ["fatal:", "panic:", "segmentation fault", "core dumped"]
    for sig in generic_errors:
        if sig in lower_output:
            return True

    # Check for pytest/jest summary patterns
    if re.search(r"\d+ failed", lower_output):
        return True
    if re.search(r"tests?: \d+ failed", lower_output):
        return True

    return False


def _discover_project_modules(cwd: Path, max_depth: int = 3) -> list[str]:
    """Scan project directory and return available Python module paths.

    This helps the model know what imports are valid instead of hallucinating.
    """
    modules: list[str] = []
    for py_file in cwd.rglob("*.py"):
        try:
            rel = py_file.relative_to(cwd)
        except ValueError:
            continue
        # Skip hidden dirs, __pycache__, node_modules, etc.
        parts = rel.parts
        if any(
            p.startswith(".") or p == "__pycache__" or p == "node_modules"
            for p in parts
        ):
            continue
        if len(parts) > max_depth + 1:
            continue
        # Convert path to module: sage/core/engine.py -> sage.core.engine
        if py_file.name == "__init__.py":
            mod = ".".join(parts[:-1])
        else:
            mod = ".".join(parts)[:-3]  # strip .py
        if mod:
            modules.append(mod)
    return sorted(set(modules))[:50]  # Cap at 50 to avoid overflow


def _build_smart_error_context(output: str, written: list[str], cwd: Path) -> str:
    """Build context-aware error feedback with module discovery.

    Claude Code-like smart diagnostics that provide:
    - Available modules when ImportError occurs
    - Project structure when FileNotFoundError occurs
    - Line context when specific line numbers are referenced
    - Suggested fixes based on error patterns
    """
    extra = []

    # Module not found — show what modules actually exist
    if "ModuleNotFoundError" in output or "ImportError" in output:
        modules = _discover_project_modules(cwd)
        if modules:
            extra.append(
                "AVAILABLE PROJECT MODULES (use these for imports):\n"
                + "\n".join(f"  - {m}" for m in modules[:30])
                + "\n\nDo NOT import modules that are not in this list. "
                "Use the correct module paths shown above."
            )

        # Extract the module name that failed to import
        import_match = re.search(r"No module named ['\"]([^'\"]+)['\"]", output)
        if import_match:
            bad_module = import_match.group(1)
            extra.append(
                f"FAILED IMPORT: '{bad_module}'\n"
                "COMMON FIXES:\n"
                "- Check spelling of module name\n"
                "- Ensure __init__.py exists in package directories\n"
                "- Use relative imports if within same package\n"
                "- Verify the module file exists before importing"
            )

    # File not found — show project tree
    if "FileNotFoundError" in output or "No such file" in output:
        tree_result = _run_shell(
            "find . -name '*.py' -not -path './__pycache__/*' -not -path './.git/*' | head -30",
            cwd,
            timeout=5,
        )
        if tree_result.strip():
            extra.append(f"PROJECT FILES:\n{tree_result}")

    # Syntax error — extract line info and suggest fix
    if "SyntaxError" in output:
        line_match = re.search(r"line (\d+)", output)
        if line_match:
            line_num = line_match.group(1)
            extra.append(
                f"SYNTAX ERROR at line {line_num}\n"
                "COMMON CAUSES:\n"
                "- Missing colon after if/for/def/class\n"
                "- Unclosed parentheses, brackets, or quotes\n"
                "- Incorrect indentation\n"
                "- Missing comma in list/dict/function args"
            )

    # IndentationError — specific guidance
    if "IndentationError" in output or "TabError" in output:
        extra.append(
            "INDENTATION ERROR\n"
            "FIXES:\n"
            "- Use consistent 4-space indentation (no tabs)\n"
            "- Check that all lines in a block have same indent\n"
            "- Ensure no mixed tabs and spaces"
        )

    # NameError — variable not defined
    if "NameError" in output:
        name_match = re.search(r"name ['\"]([^'\"]+)['\"] is not defined", output)
        if name_match:
            bad_name = name_match.group(1)
            extra.append(
                f"UNDEFINED NAME: '{bad_name}'\n"
                "COMMON FIXES:\n"
                "- Check spelling of variable/function name\n"
                "- Ensure it's defined before use\n"
                "- Add missing import if it's from another module\n"
                "- Check variable scope (local vs global)"
            )

    # TypeError — wrong argument count or type
    if "TypeError" in output:
        arg_match = re.search(r"takes (\d+) .*arguments? but (\d+)", output)
        if arg_match:
            expected, got = arg_match.group(1), arg_match.group(2)
            extra.append(
                f"ARGUMENT COUNT MISMATCH: expected {expected}, got {got}\n"
                "FIX: Check the function signature and match the argument count"
            )

    # AssertionError — test failure
    if "AssertionError" in output:
        extra.append(
            "TEST ASSERTION FAILED\n"
            "DEBUG STEPS:\n"
            "1. Check expected vs actual values in the assertion\n"
            "2. Verify the implementation logic\n"
            "3. Add print/debug statements if needed\n"
            "4. Ensure test data matches expected format"
        )

    # AttributeError — object doesn't have attribute
    if "AttributeError" in output:
        attr_match = re.search(
            r"['\"]([^'\"]+)['\"] object has no attribute ['\"]([^'\"]+)['\"]", output
        )
        if attr_match:
            obj_type, attr_name = attr_match.group(1), attr_match.group(2)
            extra.append(
                f"ATTRIBUTE ERROR: '{obj_type}' has no attribute '{attr_name}'\n"
                "COMMON FIXES:\n"
                "- Check spelling of attribute name\n"
                "- Verify the object type is what you expect\n"
                "- Check if you're accessing a None value\n"
                "- Ensure the attribute exists on this type"
            )

    if extra:
        return "\n\n".join(extra)
    return ""


def _detect_repetition(responses: list[str], current: str) -> bool:
    """Detect if the model is stuck in a loop producing identical responses."""
    if not responses:
        return False
    # Check if current response matches any of the last 2 responses
    current_stripped = current.strip()[:500]  # Compare first 500 chars
    for prev in responses[-2:]:
        if prev.strip()[:500] == current_stripped:
            return True
    return False


# ══════════════════════════════════════════════════════════════════════════════
# ADDITIONAL INTEGRITY FIXES - HIGH-6 through MEDIUM-18
# ══════════════════════════════════════════════════════════════════════════════

def _detect_code_repetition(previous_responses: list[str], current_response: str) -> bool:
    """Detect if autopilot is generating identical code repeatedly.

    Args:
        previous_responses: List of previous response texts
        current_response: Current response text

    Returns:
        True if current response is identical to a recent previous response
    """
    if not previous_responses:
        return False

    # Extract FILE: blocks from current response
    current_files = _extract_file_blocks(current_response)
    if not current_files:
        return False

    # Check last 2 responses for identical file blocks
    for prev_response in previous_responses[-2:]:
        prev_files = _extract_file_blocks(prev_response)
        if prev_files == current_files:
            return True

    return False


def _extract_file_blocks(response: str) -> dict[str, str]:
    """Extract FILE: blocks from response.

    Returns:
        Dict mapping filename to file content
    """
    import re
    files = {}

    # Match FILE: filename followed by content
    pattern = r'FILE:\s*(\S+)\s*\n(.*?)(?=\nFILE:|$)'
    matches = re.findall(pattern, response, re.DOTALL)

    for filename, content in matches:
        files[filename] = content.strip()

    return files


def _compute_response_hash(response: str) -> str:
    """Compute normalized hash of response for repetition detection.

    Normalizes whitespace to detect subtle repetition.
    """
    import hashlib

    # Normalize whitespace
    normalized = " ".join(response.split())

    # Compute hash
    return hashlib.sha256(normalized.encode()).hexdigest()


def _should_stop_autopolit_cycle(cycle_history: list[dict]) -> tuple[bool, str]:
    """Determine if autopilot should stop based on cycle history.

    Args:
        cycle_history: List of dicts with 'response' and 'success' keys

    Returns:
        Tuple of (should_stop, reason)
    """
    if len(cycle_history) < 3:
        return False, ""

    # Check for identical responses in last 3 cycles
    recent_responses = [cycle["response"] for cycle in cycle_history[-3:]]
    recent_hashes = [_compute_response_hash(r) for r in recent_responses]

    if len(set(recent_hashes)) == 1:
        return True, "Autopilot is repeating identical responses"

    # Check for repeated failures
    recent_failures = sum(1 for cycle in cycle_history[-3:] if not cycle.get("success", False))
    if recent_failures >= 3:
        return True, "Too many consecutive failures"

    return False, ""


def _validate_implementation_claim(response: str) -> tuple[bool, str]:
    """Validate that implementation claims have FILE: blocks.

    Args:
        response: The LLM response text

    Returns:
        Tuple of (is_valid, reason)
    """
    # Check for implementation claims
    impl_claims = [
        "i've implemented",
        "i have implemented",
        "implementation complete",
        "implemented the",
        "created the implementation",
        "built the feature",
    ]

    response_lower = response.lower()
    has_impl_claim = any(claim in response_lower for claim in impl_claims)

    if not has_impl_claim:
        return True, ""  # No claim made

    # Check for FILE: blocks
    has_file_blocks = "FILE:" in response or "file:" in response

    if not has_file_blocks:
        return False, "Response claims implementation but has no FILE: blocks"

    return True, ""


def _validate_completion_claim(response: str) -> bool:
    """Check if completion claim has evidence (code or execution results).

    Args:
        response: The LLM response text

    Returns:
        True if completion claim has evidence, False otherwise
    """
    completion_claims = ["done!", "complete!", "all done", "finished", "completed"]

    response_lower = response.lower()
    has_completion_claim = any(claim in response_lower for claim in completion_claims)

    if not has_completion_claim:
        return True  # No claim made

    # Check for evidence
    has_file_blocks = "FILE:" in response
    has_run_commands = "RUN:" in response
    has_results = "RESULT:" in response

    return has_file_blocks or has_run_commands or has_results


def _validate_test_claim(response: str, test_output: str) -> bool:
    """Validate that test passing claims match actual test output.

    Args:
        response: The LLM response text
        test_output: Actual test execution output

    Returns:
        True if claims are accurate, False if misleading
    """
    # Check for "tests passing" claims
    passing_claims = [
        "tests are passing",
        "all tests pass",
        "tests pass",
        "tests passing",
        "green",
        "✓",
    ]

    response_lower = response.lower()
    claims_passing = any(claim in response_lower for claim in passing_claims)

    if not claims_passing:
        return True  # No claim made

    # Parse actual test results
    result = _parse_test_output(test_output)

    # Claim is accurate only if tests actually passed
    return result["is_success"]


def _parse_test_result_accurately(test_output: str) -> dict:
    """Parse test output accurately, handling edge cases.

    Args:
        test_output: Raw test execution output

    Returns:
        Dict with passed, failed, and overall_success keys
    """
    import re

    # Look for pytest-style summary
    # "===== 5 failed, 10 passed ====="
    # "===== 0 passed ====="

    passed = 0
    failed = 0

    # Match "N passed"
    passed_match = re.search(r'(\d+)\s+passed', test_output)
    if passed_match:
        passed = int(passed_match.group(1))

    # Match "N failed"
    failed_match = re.search(r'(\d+)\s+failed', test_output)
    if failed_match:
        failed = int(failed_match.group(1))

    return {
        "passed": passed,
        "failed": failed,
        "overall_success": failed == 0 and passed > 0
    }


def _parse_test_output(test_output: str) -> dict:
    """Parse test output to extract results.

    Returns:
        Dict with total_passed, total_failed, is_success
    """
    result = _parse_test_result_accurately(test_output)

    return {
        "total_passed": result["passed"],
        "total_failed": result["failed"],
        "is_success": result["overall_success"]
    }


def _validate_file_path_in_workspace(file_path: Path, workspace: Path) -> tuple[bool, str]:
    """Validate that file path is within workspace (no traversal).

    Args:
        file_path: The file path to validate
        workspace: The workspace root directory

    Returns:
        Tuple of (is_valid, reason)
    """
    try:
        # Resolve both paths to absolute
        file_abs = file_path.resolve() if not file_path.is_absolute() else file_path
        workspace_abs = workspace.resolve()

        # For relative paths, make them relative to workspace
        if not file_path.is_absolute():
            file_abs = (workspace_abs / file_path).resolve()

        # Check if file is within workspace
        try:
            file_abs.relative_to(workspace_abs)
            return True, ""
        except ValueError:
            return False, f"Path {file_path} is outside workspace {workspace}"

    except Exception as e:
        return False, f"Invalid path: {e}"


def _normalize_file_path(file_path: Path, workspace: Path) -> Path:
    """Normalize file path to be relative to workspace.

    Args:
        file_path: File path (absolute or relative)
        workspace: Workspace root directory

    Returns:
        Relative path from workspace
    """
    try:
        file_abs = file_path.resolve() if not file_path.is_absolute() else file_path
        workspace_abs = workspace.resolve()

        # If file is absolute and within workspace, make it relative
        if file_path.is_absolute():
            try:
                return file_abs.relative_to(workspace_abs)
            except ValueError:
                # Not within workspace, return as-is
                return file_path

        # Already relative
        return file_path

    except Exception:
        return file_path


def _validate_retry_has_evidence(original_response: str, retry_response: str) -> bool:
    """Check if retry response has new tool usage (evidence of investigation).

    Args:
        original_response: The original response text
        retry_response: The retry response text

    Returns:
        True if retry has new tool commands, False otherwise
    """
    # Extract tool commands from both responses
    original_tools = _extract_tool_command_names(original_response)
    retry_tools = _extract_tool_command_names(retry_response)

    # Retry should have new tool commands
    new_tools = set(retry_tools) - set(original_tools)

    return len(new_tools) > 0 or len(retry_tools) > len(original_tools)


def _extract_tool_command_names(response: str) -> list[str]:
    """Extract tool command names from response.

    Returns:
        List of tool command names like ["READ", "SEARCH"]
    """
    import re

    tool_pattern = r'^\s*(?:-|\*|•)?\s*(READ|SEARCH|RUN|FILE):\s*'
    matches = re.findall(tool_pattern, response, re.MULTILINE | re.IGNORECASE)

    return [m.upper() for m in matches]


def _response_has_tool_results(response: str) -> bool:
    """Check if response contains tool execution results.

    Args:
        response: The response text

    Returns:
        True if response has RESULT: blocks
    """
    return "RESULT:" in response or "result:" in response.lower()


def _extract_tool_commands_robust(response: str) -> list[dict]:
    """Extract tool commands from response, handling indentation and bullets.

    Args:
        response: The response text

    Returns:
        List of dicts with 'command' and 'args' keys
    """
    import re

    commands = []

    # Pattern matches: optional indent/bullet + command + colon + args
    # Examples:
    #   READ: file.py
    #   - READ: file.py
    #   •  SEARCH: pattern
    #       READ: file.py
    pattern = r'^\s*(?:-|\*|•|\d+\.|\d+\))?\s*(READ|SEARCH|RUN|FILE):\s*(.+)$'

    for line in response.split('\n'):
        match = re.match(pattern, line, re.IGNORECASE)
        if match:
            command = match.group(1).upper()
            args = match.group(2).strip()
            commands.append({
                "command": command,
                "args": args
            })

    return commands


def _validate_list_generation_result(
    response: str,
    extracted_list: list,
    expected_min_items: int = 1
) -> tuple[bool, str]:
    """Validate that list generation produced non-empty results.

    Args:
        response: The LLM response text
        extracted_list: The extracted list items
        expected_min_items: Minimum expected items

    Returns:
        Tuple of (is_valid, reason)
    """
    # Check for completion claims
    completion_claims = [
        "found all",
        "complete",
        "done",
        "finished the analysis",
        "that's all",
    ]

    response_lower = response.lower()
    claims_complete = any(claim in response_lower for claim in completion_claims)

    if claims_complete and len(extracted_list) < expected_min_items:
        return False, f"Response claims completion but list is empty (expected {expected_min_items}+ items)"

    return True, ""


def _validate_list_items_exist(
    listed_files: list[str],
    workspace: Path
) -> tuple[list[str], list[str]]:
    """Validate that listed files actually exist.

    Args:
        listed_files: List of file paths mentioned
        workspace: Workspace root directory

    Returns:
        Tuple of (valid_files, invalid_files)
    """
    valid_files = []
    invalid_files = []

    for file_path in listed_files:
        full_path = workspace / file_path
        if full_path.exists():
            valid_files.append(file_path)
        else:
            invalid_files.append(file_path)

    return valid_files, invalid_files


def _handle_context_overflow(
    context: str,
    max_tokens: int,
    preserve_file_writes: bool = True,
    preserve_tool_results: bool = True
) -> str:
    """Handle context overflow by smart truncation preserving important content.

    Args:
        context: The full context string
        max_tokens: Maximum tokens allowed
        preserve_file_writes: Whether to preserve FILE: blocks
        preserve_tool_results: Whether to preserve RESULT: blocks

    Returns:
        Truncated context that fits within max_tokens
    """
    import re

    # Extract important blocks to preserve
    preserved_blocks = []

    if preserve_file_writes:
        # Extract FILE: blocks
        file_blocks = re.findall(r'FILE:.*?(?=\n(?:FILE:|SEARCH:|READ:|RUN:|$))', context, re.DOTALL)
        preserved_blocks.extend(file_blocks)

    if preserve_tool_results:
        # Extract RESULT: blocks
        result_blocks = re.findall(r'RESULT:.*?(?=\n(?:FILE:|SEARCH:|READ:|RUN:|$))', context, re.DOTALL)
        preserved_blocks.extend(result_blocks)

    # Build truncated context
    # Keep last portion of context + preserved blocks
    preserved_text = "\n\n".join(preserved_blocks)

    # Rough token estimation (4 chars = 1 token)
    preserved_size = len(preserved_text) // 4
    remaining_tokens = max_tokens - preserved_size

    if remaining_tokens > 0:
        # Keep last portion of context
        context_size = remaining_tokens * 4
        truncated_context = context[-context_size:]

        return truncated_context + "\n\n" + preserved_text
    else:
        # Just return preserved blocks
        return preserved_text


def _truncate_context_smartly(messages: list[dict], max_tokens: int) -> list[dict]:
    """Smart truncation of message context preserving recent and important messages.

    Args:
        messages: List of message dicts with role and content
        max_tokens: Maximum tokens allowed

    Returns:
        Truncated list of messages
    """
    # Rough token estimation (4 chars = 1 token)
    def estimate_tokens(msg: dict) -> int:
        return len(str(msg.get("content", ""))) // 4

    # Always keep system message and last 2 messages
    if len(messages) <= 3:
        return messages

    system_msg = messages[0] if messages[0].get("role") == "system" else None
    recent_msgs = messages[-2:]
    middle_msgs = messages[1:-2] if system_msg else messages[:-2]

    # Calculate tokens
    system_tokens = estimate_tokens(system_msg) if system_msg else 0
    recent_tokens = sum(estimate_tokens(m) for m in recent_msgs)
    remaining_tokens = max_tokens - system_tokens - recent_tokens

    # Add middle messages that fit, prioritizing those with FILE: blocks
    kept_middle = []
    for msg in reversed(middle_msgs):
        msg_tokens = estimate_tokens(msg)
        if msg_tokens <= remaining_tokens:
            # Prioritize messages with FILE: blocks
            if "FILE:" in str(msg.get("content", "")):
                kept_middle.insert(0, msg)
                remaining_tokens -= msg_tokens

    # Build final message list
    result = []
    if system_msg:
        result.append(system_msg)
    result.extend(kept_middle)
    result.extend(recent_msgs)

    return result


def _handle_model_fallback(requested_model: str, fallback_model: str, reason: str) -> None:
    """Handle model fallback by warning user.

    Args:
        requested_model: The model that was requested
        fallback_model: The fallback model being used
        reason: Reason for fallback
    """
    # Use the global renderer instance
    renderer.warning(
        f"⚠️  Model fallback: {requested_model} → {fallback_model}\n"
        f"   Reason: {reason}\n"
        f"   Note: Response quality may be affected"
    )

    _log_model_fallback(requested_model, fallback_model, reason)


def _log_model_fallback(requested: str, actual: str, reason: str) -> None:
    """Log model fallback event.

    Args:
        requested: Requested model ID
        actual: Actual model ID used
        reason: Reason for fallback
    """
    logger.warning(
        f"Model fallback: requested={requested}, actual={actual}, reason={reason}"
    )


def _get_fallback_statistics() -> dict:
    """Get statistics on model fallback frequency.

    Returns:
        Dict with total_fallbacks and fallback_rate
    """
    # This would track fallbacks in memory or persistent storage
    # For now, return empty stats
    return {
        "total_fallbacks": 0,
        "fallback_rate": 0.0
    }


def _is_broken_test_file(filepath: str, error_output: str) -> bool:
    """Determine if a test file should be deleted due to persistent errors.

    A test file is considered broken if:
    1. It's a test file (in tests/ directory or starts with test_)
    2. The error output mentions import errors for this file
    3. The file imports modules that don't exist
    """
    # Must be a test file
    if not (filepath.startswith("tests/") or "test_" in filepath):
        return False

    # Must be mentioned in import errors
    filename = Path(filepath).name
    filepath_in_error = filepath in error_output or filename in error_output

    # Check for import-related errors mentioning this file
    import_errors = [
        "ImportError",
        "ModuleNotFoundError",
        "cannot import name",
        "No module named",
        "attempted relative import",
    ]
    has_import_error = any(err in error_output for err in import_errors)

    return filepath_in_error and has_import_error


def _cleanup_broken_test_files(cwd: Path, error_output: str) -> list[str]:
    """Flag broken test files with persistent import errors without deleting them.

    Returns a list of candidate file paths that need human or model review.
    """
    flagged = []

    # Find test files mentioned in errors
    test_dirs = [cwd / "tests", cwd / "tests" / "sage"]
    for test_dir in test_dirs:
        if not test_dir.exists():
            continue
        for test_file in test_dir.glob("test_*.py"):
            rel_path = str(test_file.relative_to(cwd))
            if _is_broken_test_file(rel_path, error_output):
                flagged.append(rel_path)

    return flagged


def _is_complex_task(task: str) -> bool:
    """Heuristic: does this task benefit from multi-step decomposition?

    Complex tasks have multiple sub-objectives, mention multiple files,
    or use words suggesting multi-part work. Simple tasks (explain X,
    fix typo, rename Y) don't need decomposition overhead.
    """
    lower = task.lower()
    # Multi-part indicators
    multi_indicators = [
        " and ",
        " then ",
        " also ",
        " with tests",
        "add a .* and",
        "create .* including",
        "implement",
        "build",
        "refactor",
        "migrate",
    ]
    score = sum(1 for pat in multi_indicators if re.search(pat, lower))
    # Long prompts are usually complex
    if len(task.split()) > 25:
        score += 1
    # Mentions multiple files
    file_mentions = re.findall(r"[\w/]+\.(?:py|js|ts|go|rs|java)\b", task)
    if len(file_mentions) >= 2:
        score += 1
    return score >= 2


def _should_use_multistep_pipeline(
    task: str,
    *,
    classification: _ClassifiedRequest | None = None,
    is_local_model: bool = False,
) -> bool:
    """Route complex local tasks into a model-driven multistep pipeline."""
    if not is_local_model:
        return False

    effective_classification = classification or _get_current_classification()
    if effective_classification and effective_classification.read_only:
        if effective_classification.request_type == _RequestType.LIST_GENERATION:
            return True
        if len(task.split()) > 20:
            return True

    return _is_complex_task(task)


def _get_project_file_listing(cwd: Path, max_files: int = 50) -> str:
    """Get a compact listing of actual project files for discovery.

    This helps the model know what files exist before trying to read them,
    preventing it from guessing filenames based on conventions.
    """
    skip_dirs = {
        ".git", "node_modules", "__pycache__", ".venv", "venv",
        "dist", "build", ".next", ".cache", "target", ".tox",
        "egg-info", ".eggs", ".mypy_cache", ".pytest_cache", "htmlcov"
    }
    source_exts = {".py", ".js", ".ts", ".tsx", ".jsx", ".rs", ".go", ".java", ".c", ".cpp", ".rb", ".sh"}
    config_files = {"pyproject.toml", "package.json", "Cargo.toml", "go.mod", "requirements.txt", "setup.py"}

    files: list[str] = []
    for p in sorted(cwd.rglob("*")):
        if not p.is_file():
            continue
        try:
            rel = p.relative_to(cwd)
            if any(part.startswith(".") or part in skip_dirs for part in rel.parts):
                continue
            # Include source files and config files
            if p.suffix.lower() in source_exts or p.name in config_files:
                files.append(str(rel))
                if len(files) >= max_files:
                    break
        except (ValueError, OSError):
            continue

    if not files:
        return ""

    listing = "\n".join(f"  - {f}" for f in files[:max_files])
    more = f"\n  ... and {len(files) - max_files} more files" if len(files) >= max_files else ""
    return f"\n\nACTUAL PROJECT FILES (use READ: with these exact paths):\n{listing}{more}"


def _build_multistep_phase_prompts(
    task_prompt: str,
    classification: _ClassifiedRequest | None = None,
    cwd: Path | None = None,
) -> list[tuple[str, str]]:
    """Build phase prompts so the model owns planning and task reasoning."""
    effective_classification = classification or _get_current_classification()

    # Get actual file listing for discovery (prevents model from guessing filenames)
    file_listing = ""
    if cwd:
        file_listing = _get_project_file_listing(cwd)

    if effective_classification and effective_classification.read_only:
        quantity_instruction = ""
        if effective_classification.quantity_required:
            quantity_instruction = (
                f" Target at least {effective_classification.quantity_required} distinct items"
                " if the user asked for a long ranked list."
            )

        return [
            (
                "planning",
                (
                    f"TASK: {task_prompt}\n\n"
                    "Break this read-only analysis into 2-4 concrete investigation steps. "
                    "For each step, say which file(s), subsystem(s), or commands to inspect. "
                    "Use READ: and SEARCH: now where helpful. READ files, not directories. "
                    "Use one SEARCH pattern per line instead of combining terms with OR on a single line. "
                    "IMPORTANT: Only read files that actually exist in the project (listed below). "
                    "Do NOT guess filenames based on conventions - use the actual file paths provided. "
                    "Do NOT write code, tests, or "
                    "writable file blocks."
                    f"{file_listing}"
                ),
            ),
            (
                "analysis",
                (
                    f"TASK: {task_prompt}\n\n"
                    "Continue the read-only investigation. Use READ:, SEARCH:, and safe RUN: "
                    "commands if needed to gather evidence. READ files, not directories. "
                    "Use one SEARCH pattern per line instead of combining terms with OR on a single line. "
                    "Focus on root causes, risks, and "
                    "priority." + quantity_instruction + " Do NOT write code or tests."
                ),
            ),
            (
                "synthesis",
                (
                    f"TASK: {task_prompt}\n\n"
                    "Now synthesize the final analysis. Produce a grounded, prioritized response "
                    "based on the evidence you gathered. "
                    "Reference only files or code locations that were explicitly verified during your investigation. "
                    "If the user asked for a long list, number every item clearly and do not stop early. "
                    "If evidence is insufficient for some claims, say so plainly instead of guessing. "
                    "Do NOT write code, tests, or writable file blocks."
                ),
            ),
        ]

    return [
        (
            "planning",
            (
                f"TASK: {task_prompt}\n\n"
                "Break this into 2-4 concrete implementation steps. "
                "For each step, say what file(s) to create/modify. "
                "Use READ: commands to examine any existing files you need to understand first.\n"
                "Format:\n"
                "STEP 1: <description> — <file(s)>\n"
                "STEP 2: <description> — <file(s)>\n"
                "...\n\n"
                "Also use READ: and SEARCH: to explore the codebase now."
            ),
        ),
        (
            "testing",
            (
                "Now write the TEST files for this task. Based on your plan above, "
                "create test files that verify the expected behavior.\n\n"
                "RULES:\n"
                "- Output ONLY test files using FILE: blocks\n"
                "- Import from modules that ACTUALLY EXIST in this project\n"
                "- Each test should be runnable independently\n"
                "- Do NOT write implementation files yet — only tests\n"
            ),
        ),
        (
            "implementation",
            (
                "Now write the IMPLEMENTATION files to make the tests pass. "
                "Based on your plan and the tests you wrote, create/modify the source files.\n\n"
                "RULES:\n"
                "- Output implementation files using FILE: blocks with COMPLETE contents\n"
                "- Make sure imports match what exists in the project\n"
                "- Do NOT rewrite the test files — only implementation files\n"
                "- Use RUN: to run the tests after writing the files\n"
            ),
        ),
    ]


def _build_tool_followup_prompt(
    tool_context: str,
    classification: _ClassifiedRequest | None = None,
) -> str:
    """Build a mode-aware follow-up prompt after READ/SEARCH/RUN commands."""
    effective_classification = classification or _get_current_classification()

    if effective_classification and effective_classification.read_only:
        if _tool_context_needs_more_investigation(tool_context):
            return (
                f"Here are the results of your tool commands:\n\n{tool_context}\n\n"
                "Your previous investigation commands did not produce enough grounded evidence yet. "
                "Issue corrected READ:/SEARCH:/RUN: commands before making substantive claims.\n"
                "Rules:\n"
                "1. READ files, not directories.\n"
                "2. Use one SEARCH pattern per line; do not combine terms with OR on a single line.\n"
                "3. If a tool failed or returned no matches, acknowledge that and correct the command.\n"
                "4. Do not claim facts unless they are explicitly supported by the tool results above.\n"
                "5. If evidence remains insufficient after another pass, say so plainly instead of guessing."
            )

        quantity_instruction = ""
        if effective_classification.quantity_required:
            quantity_instruction = (
                f" Provide at least {effective_classification.quantity_required} distinct items"
                " if the request asked for a long ranked list."
            )

        return (
            f"Here are the results of your tool commands:\n\n{tool_context}\n\n"
            "Now continue with your analysis. Synthesize concrete, evidence-based findings from "
            "these results."
            f"{quantity_instruction} "
            "Only claim facts explicitly supported by the tool results above. "
            "If evidence is incomplete, say so and issue more specific READ:/SEARCH: commands instead of guessing. "
            "Do NOT write writable file blocks, code, tests, or implementation steps unless the user "
            "explicitly asked for code changes."
        )

    return (
        f"Here are the results of your tool commands:\n\n{tool_context}\n\n"
        "Now continue with your task. Write FILE: blocks for any files "
        "that need to be created or modified."
    )


def _wants_code_changes(lower: str) -> bool:
    """Heuristic: user wants implementation, patches, or explicit fixes (not review-only)."""
    if re.search(
        r"\b(no code|don't write code|analysis only|read[- ]only|do not implement)\b",
        lower,
    ):
        return False
    if re.search(
        r"\b(and|then)\s+(fix|implement|refactor|patch|change|update)\b",
        lower,
    ):
        return True
    if re.search(r"\bfix\s+(this|that|the|it|bugs?|dockerfile)\b", lower):
        return True
    if re.search(r"\b(implement|refactor|patch)\b", lower):
        return True
    if re.search(
        r"\b(write|add|create|change|update)\s+(a\s+|the\s+|this\s+|those\s+)?(feature|function|class|file|tests?)\b",
        lower,
    ):
        return True
    return False


def _is_readonly_analysis_request(user_input: str) -> bool:
    """True for audit / review / prioritized findings without edits or execution."""
    lower = user_input.lower().strip()
    if _wants_code_changes(lower):
        return False
    analysis_markers = (
        "analyze",
        "review",
        "audit",
        "assess",
        "what needs",
        "what's wrong",
        "what is wrong",
        "priorit",
        "list ",
        "recommendations",
        "suggestions",
        "code review",
        "strengths",
        "weaknesses",
        "gaps",
        "areas for improvement",
    )
    return any(m in lower for m in analysis_markers)


def _expand_prompt(user_input: str) -> str:
    """Expand user prompts with detailed instructions for the model.

    Detects the type of request and adds specific guidance so that smaller
    models can produce high-quality results comparable to larger models.
    """
    lower = user_input.lower().strip()

    # ── Multi-item fix / "fix all" requests → task-list workflow ─────────────
    # Checked BEFORE read-only analysis so "address all items in the list" is
    # not mistakenly classified as analysis due to the word "list".
    multi_fix_triggers = [
        "fix all",
        "fix each",
        "fix every",
        "fix these",
        "fix those",
        "address all",
        "address each",
        "address these",
        "resolve all",
        "resolve each",
        "resolve these",
        "implement all",
        "implement each",
        "implement these",
        "apply all",
        "all of these",
        "every item",
        "every point",
        "all the points",
        "all the items",
        "all points",
        "all items",
    ]
    for trigger in multi_fix_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS — TASK-LIST WORKFLOW (MANDATORY):\n"
                "You have multiple items to fix. You MUST follow this workflow:\n\n"
                "## STEP 1: Build a numbered task list\n"
                "List every distinct task derived from the request, numbered 1..N.\n"
                "For each, state: one-line description, file(s) involved, status [PENDING].\n"
                "Print the full task list before starting any work.\n\n"
                "## STEP 2: Execute tasks ONE AT A TIME, in order\n"
                "For each task:\n"
                "  a) Print: '--- Task K/N: <description> [IN PROGRESS] ---'\n"
                "  b) READ: every file you plan to modify (MANDATORY — never guess file contents)\n"
                "  c) Write the fix/implementation using FILE: blocks with COMPLETE contents\n"
                "  d) Write or update tests (FILE: tests/...) if the change involves code logic\n"
                "  e) RUN: the relevant test/validation command\n"
                "  f) If the test fails, debug and retry before moving to the next task\n"
                "  g) Print: '--- Task K/N: <description> [DONE] ---'\n\n"
                "## STEP 3: Final summary\n"
                "After all tasks, print the full task list with updated statuses:\n"
                "  [DONE], [FAILED], or [SKIPPED] for each.\n"
                "Report how many passed, failed, or were skipped.\n\n"
                "## HARD RULES\n"
                "- Do NOT skip tasks or stop early. Complete EVERY item.\n"
                "- READ: files BEFORE modifying them — never hallucinate file contents.\n"
                "- If a task fails after 3 retries, mark it [FAILED] and move to the next.\n"
                "- Do NOT run destructive commands (docker build, training, deploy) unless the task specifically requires it.\n"
            )

    # ── Read-only analysis / review (no unsolicited code, tests, or builds) ──
    # Use the current classification for better enforcement
    classification = _get_current_classification()

    if classification and classification.read_only:
        # Build enforcement instructions based on classification
        quantity_instruction = ""
        if classification.quantity_required:
            qty = classification.quantity_required
            quantity_instruction = (
                f"\n## QUANTITY REQUIREMENT (MANDATORY)\n"
                f"You MUST provide AT LEAST {qty} distinct items in your response.\n"
                f"If you cannot find {qty} items, provide as many as you can with clear justification.\n"
                f"DO NOT stop at 3-5 items when the user asked for {qty}+.\n"
                f"Number each item clearly: 1., 2., 3., ... up to {qty}+.\n"
            )

        return (
            f"{user_input}\n\n"
            "## CRITICAL: READ-ONLY ANALYSIS MODE\n"
            "This request is classified as READ-ONLY ANALYSIS. You MUST:\n"
            "1. NEVER write FILE: blocks — they will be REJECTED by the system.\n"
            "2. NEVER create tests, patches, or implementation code.\n"
            "3. NEVER run destructive commands (docker build, training, deploys).\n"
            "4. Use READ:/SEARCH: to explore the codebase BEFORE making claims.\n"
            "5. Reference ONLY files that you have verified exist via SEARCH: or READ:.\n"
            "6. Include concrete file paths and line numbers in your analysis.\n"
            f"{quantity_instruction}\n"
            "## OUTPUT FORMAT\n"
            "Provide a prioritized list with:\n"
            "- Severity (P0/P1/P2/P3)\n"
            "- File path and line number\n"
            "- Specific issue description\n"
            "- Concrete recommendation\n"
            "- Estimated effort (low/medium/high)\n\n"
            "At the end, ask if the user wants you to implement any of the items.\n"
            "DO NOT start implementing unprompted."
        )

    # Fallback to old logic if no classification
    if _is_readonly_analysis_request(user_input):
        return (
            f"{user_input}\n\n"
            "INSTRUCTIONS (read-only analysis mode):\n"
            "1. Answer from the project context already provided. Do NOT write or modify code.\n"
            "2. Do NOT create tests, patches, or FILE: blocks unless the user explicitly asked you to implement or fix something.\n"
            "3. Do NOT run docker, training, builds, deploys, or other destructive/slow commands.\n"
            "4. Use READ:/SEARCH: only if you must verify a specific claim against the repo; prefer the supplied context.\n"
            "5. Deliver a prioritized list: severity, blast radius, concrete recommendation, and file paths to inspect.\n"
            "6. If something requires reading files you do not have, say what you would read — do not invent file contents.\n"
            "7. End by asking whether the user wants implementation help next — do not start implementing unprompted."
        )

    # ── Vague improvement / fix requests (implementation-oriented) ─────────────
    vague_impl_triggers = [
        "improve this",
        "improve the code",
        "make it better",
        "refactor this",
        "refactor the code",
        "fix this",
        "fix the code",
        "fix bugs",
        "what can be improved",
        "look at this",
        "check this",
    ]
    for trigger in vague_impl_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: You have the full codebase. Follow these steps:\n"
                "1. Identify the most impactful issues first: blockers, security risks, failing tests, CI/release gaps, then reliability/code quality\n"
                "2. Prioritize by severity and blast radius, not convenience or cosmetics\n"
                "3. READ: every file you plan to modify BEFORE writing changes (MANDATORY)\n"
                "4. For each fix, write or update tests that expose the issue (FILE: tests/test_improvement_N.py)\n"
                "5. Write the fix (FILE: path/to/fixed_file.py)\n"
                "6. Include ```bash blocks to run the relevant validation\n"
                "Reference specific files and line numbers from the project context."
            )

    # ── Deployment requests ────────────────────────────────
    deploy_triggers = [
        "deploy",
        "deployment",
        "ship it",
        "push to prod",
        "production",
        "hosting",
        "publish",
        "release",
    ]
    for trigger in deploy_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Create a complete deployment setup:\n"
                "1. Detect the tech stack from the project files\n"
                "2. Write a Dockerfile if the project doesn't have one\n"
                "3. Write a deployment config (docker-compose.yml, or platform-specific: fly.toml, vercel.json, railway.json, etc.)\n"
                "4. Add pre-deploy validation and health checks\n"
                "5. Write a deploy script (scripts/deploy.sh) that automates the process\n"
                "6. Create .env.example with all required environment variables (never hardcode secrets)\n"
                "7. Update .gitignore to exclude .env and other sensitive files\n"
                "8. Document a rollback path and staging/production separation\n"
                "9. Include ```bash blocks to test the deployment locally\n"
                "Use FILE: blocks for every file."
            )

    # ── CI/CD requests ─────────────────────────────────────
    ci_triggers = [
        "ci/cd",
        "ci cd",
        "pipeline",
        "github action",
        "gitlab ci",
        "continuous",
    ]
    for trigger in ci_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Create a CI/CD pipeline:\n"
                "1. Detect the tech stack and test framework\n"
                "2. Write .github/workflows/ci.yml (or equivalent) with fail-fast lint, test, and build stages\n"
                "3. Cache dependencies when the platform supports it\n"
                "4. Block merges when validation fails\n"
                "5. Add a deployment stage only after validation passes if requested\n"
                "6. Create any missing test scripts\n"
                "Use FILE: blocks for every file."
            )

    # ── Secret/env management ──────────────────────────────
    secret_triggers = [
        "secret",
        "env var",
        "environment variable",
        "api key",
        "credential",
        ".env",
    ]
    for trigger in secret_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Set up secure configuration:\n"
                "1. Create .env.example with all variables (placeholder values only)\n"
                "2. Write a config loader that reads from env vars with sensible defaults\n"
                "3. Add .env to .gitignore\n"
                "4. Write tests for the config loader\n"
                "NEVER put real secrets in code. Use FILE: blocks for every file."
            )

    # ── Docker requests ────────────────────────────────────
    docker_triggers = ["docker", "container", "containerize"]
    for trigger in docker_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Create Docker setup:\n"
                "1. Write a Dockerfile optimized for the project's tech stack\n"
                "2. Write docker-compose.yml if the app has services (db, cache, etc.)\n"
                "3. Write .dockerignore\n"
                "4. Include ```bash blocks to build and test the image\n"
                "Use FILE: blocks for every file."
            )

    # ── Database requests ──────────────────────────────────
    db_triggers = ["database", "migration", "schema", "sql", "orm", "model"]
    for trigger in db_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS:\n"
                "1. Check what database/ORM the project uses\n"
                "2. Write migration files if needed\n"
                "3. Write model/schema code\n"
                "4. Write tests with a test database\n"
                "5. Include ```bash blocks to run migrations and tests\n"
                "Use FILE: blocks for every file."
            )

    # ── Testing requests ───────────────────────────────────
    test_triggers = [
        "write test",
        "add test",
        "test coverage",
        "unit test",
        "integration test",
    ]
    for trigger in test_triggers:
        if trigger in lower:
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS:\n"
                "1. Identify what needs testing from the project files\n"
                "2. Write comprehensive tests covering: happy path, edge cases, error cases\n"
                "3. Include ```bash blocks to run the tests\n"
                "Use FILE: blocks for every test file."
            )

    # ── Build/create from scratch ──────────────────────────
    build_triggers = [
        "create",
        "build",
        "make",
        "add",
        "implement",
        "write",
        "set up",
        "setup",
    ]
    for trigger in build_triggers:
        if (
            trigger in lower and len(lower) > len(trigger) + 5
        ):  # Only if there's substance
            return (
                f"{user_input}\n\n"
                "INSTRUCTIONS: Think step by step:\n"
                "1. What exactly needs to be built? List the components.\n"
                "2. What existing code can you build on? Check the project files.\n"
                "3. Write tests first for the core functionality\n"
                "4. Write the implementation\n"
                "5. Include ```bash blocks to verify everything works\n"
                "Use FILE: blocks for every file."
            )

    return user_input


def _enhance_task_prompt(user_input: str) -> str:
    """Always enhance task prompts before model execution."""
    expanded = _expand_prompt(user_input)
    if expanded != user_input:
        return expanded

    # Check if this is a list generation request
    user_lower = user_input.lower()
    is_list_request = bool(re.search(r"\b(list|enumerate|identify|find)\s+\d+\b", user_lower))

    if is_list_request:
        return (
            f"{user_input}\n\n"
            "INSTRUCTIONS:\n"
            "1. Gather evidence FIRST using READ:/SEARCH: commands on actual project files.\n"
            "2. Every item MUST include specific file paths and line numbers (e.g., file.py:123).\n"
            "3. Base ALL findings on verified evidence from file reads and searches.\n"
            "4. No generic advice - only cite specific code locations you've examined.\n"
            "5. Reference ONLY files verified via READ:/SEARCH: - no invented paths.\n"
            "6. This is read-only analysis: no FILE: blocks, tests, or code changes.\n"
        )

    if _is_readonly_analysis_request(user_input):
        return (
            f"{user_input}\n\n"
            "INSTRUCTIONS:\n"
            "1. Restate the task goal in one sentence.\n"
            "2. This is read-only analysis: no FILE:, no tests, no implementation unless the user explicitly asked.\n"
            "3. Use READ:/SEARCH: to examine files and verify claims with specific file:line references.\n"
            "4. Base findings on evidence from actual file contents, not assumptions.\n"
        )
    return (
        f"{user_input}\n\n"
        "INSTRUCTIONS:\n"
        "1. Restate the task goal in one sentence.\n"
        "2. Identify constraints and assumptions.\n"
        "3. Use READ:/SEARCH: before edits and prefer minimal, verifiable changes.\n"
        "4. Validate with tests or runnable commands.\n"
        "5. If writing code, emit complete FILE: blocks.\n"
    )


def _build_enhanced_reasoning_prompt(
    user_input: str, context: dict[str, Any] | None = None
) -> str:
    """Build an enhanced prompt with chain-of-thought reasoning structure.

    This encourages the model to think through problems systematically.
    """
    reasoning_template = f"""## Task Analysis

**User Request:** {user_input}

Before implementing, think through this systematically:

### 1. UNDERSTAND
- What is the core objective?
- What are the explicit requirements?
- What are the implicit requirements?
- What would success look like?

### 2. ANALYZE
- What constraints exist?
- What assumptions am I making?
- What could go wrong?
- What edge cases exist?

### 3. PLAN
- What files need to be read first?
- What is the sequence of changes?
- What tests should be written first (TDD)?
- How will I verify success?

### 4. EXECUTE
Follow the plan with:
- READ: commands to understand existing code
- FILE: blocks for all changes (complete files only)
- RUN: commands to validate

### 5. VALIDATE
- Run tests after every change
- Fix any failures immediately
- Verify the solution meets all requirements

---

If the user asked only for analysis, review, or prioritized recommendations (no implementation), answer in prose with READ:/SEARCH: only if needed — skip FILE:, TDD, and RUN:.

Otherwise execute this task: start with READ: commands to understand the codebase, then proceed with TDD.
"""
    return reasoning_template


def _analyze_task_complexity(user_input: str) -> tuple[str, bool]:
    """Analyze task complexity to determine if enhanced reasoning is needed.

    Returns (complexity_level, needs_reasoning).
    """
    input_lower = user_input.lower()

    # Keywords indicating complex tasks
    complex_keywords = [
        "implement",
        "create",
        "build",
        "design",
        "architect",
        "refactor",
        "optimize",
        "integrate",
        "migrate",
        "add feature",
        "full",
        "complete",
        "comprehensive",
        "system",
        "framework",
    ]

    # Keywords indicating simple tasks
    simple_keywords = [
        "fix typo",
        "rename",
        "format",
        "lint",
        "simple",
        "quick",
        "small",
        "minor",
        "update comment",
        "add comment",
    ]

    # Check for simple tasks first
    if any(kw in input_lower for kw in simple_keywords):
        return "simple", False

    # Check for complex tasks
    if any(kw in input_lower for kw in complex_keywords):
        return "complex", True

    # Check word count - longer requests are often more complex
    word_count = len(user_input.split())
    if word_count > 50:
        return "complex", True

    return "medium", True


def _extract_and_validate_code(
    response: str,
    cwd: Path,
    code_validator: "CodeValidator",
) -> tuple[list[str], list[str]]:
    """Extract code from response and validate it.

    Returns (valid_files, errors).
    """
    files: list[str] = []
    errors: list[str] = []

    # Extract FILE: blocks
    file_pattern = r"FILE:\s*(\S+)\s*\n```[^\n]*\n(.*?)```"
    for match in re.finditer(file_pattern, response, re.DOTALL):
        filepath = match.group(1).strip()
        content = match.group(2)

        # Determine language from extension
        ext = Path(filepath).suffix.lower()
        language_map = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".go": "go",
        }
        language = language_map.get(ext, "unknown")

        # Validate the code
        validation = code_validator.validate(content, language, filepath)

        if validation.valid:
            files.append(filepath)
        else:
            errors.extend(validation.errors)
            for warning in validation.warnings:
                errors.append(f"Warning in {filepath}: {warning}")

    return files, errors


# ── Commands ────────────────────────────────────────────────


@app.command()
def run(
    model: Annotated[
        Optional[str], typer.Option("--model", "-m", help="Model ID")
    ] = None,
    temperature: Annotated[Optional[float], typer.Option("--temperature", "-t")] = None,
    max_tokens: Annotated[Optional[int], typer.Option("--max-tokens")] = None,
    auto_run: Annotated[
        bool,
        typer.Option(
            "--auto-run/--no-auto-run",
            help="Auto-execute bash blocks without prompting",
        ),
    ] = True,
    max_retries: Annotated[
        int, typer.Option("--max-retries", help="Max auto-fix retries on test failure")
    ] = 10,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose", "-v",
            help="Show all output including thinking blocks and detailed progress",
        ),
    ] = False,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Terminal verbosity: clean (default), normal (phases, no raw thinking), or verbose",
        ),
    ] = "clean",
    no_color: Annotated[
        bool,
        typer.Option(
            "--no-color",
            help="Disable ANSI colors (also respects NO_COLOR in the environment)",
        ),
    ] = False,
) -> None:
    """Interactive coding agent — Claude Code–style READ/SEARCH/edit/run using your models."""
    import os

    if no_color or os.environ.get("NO_COLOR"):
        renderer.set_no_color(True)

    om = (output or "clean").strip().lower()
    if om not in ("clean", "normal", "verbose"):
        renderer.err_console.print(
            f"[red]Invalid --output {output!r}; use clean, normal, or verbose.[/red]"
        )
        raise typer.Exit(code=2)

    # -v wins over --output
    if verbose:
        renderer.set_output_mode("verbose")
    else:
        renderer.set_output_mode(om)

    cwd = Path.cwd()
    cfg = load_config()
    router = _build_router(cfg)
    prompt_reader = _build_prompt_reader(cwd)

    last_used_model = _get_last_used_model(cwd)
    model_id = model or last_used_model or cfg.default_model
    model_id = _resolve_model_prefix(model_id, cfg)
    model_id = _auto_upgrade_model_if_possible(
        router, cfg, model_id, explicit_model=model, last_used_model=last_used_model
    )

    # Auto-download local models if not installed
    cfg = _ensure_model_available(cfg, model_id)
    # Rebuild router with updated config (may have new registered models)
    router = _build_router(cfg)

    _set_last_used_model(cwd, model_id)
    temp = temperature if temperature is not None else 0.1
    tokens = max_tokens if max_tokens is not None else cfg.max_tokens
    default_test_cmd = _default_test_command(cwd)
    full_project_test_cmd = _full_project_test_command(cwd)
    autopolit_priority_hints = _collect_autopolit_priority_hints(cwd)

    # Use lighter scan for local models to reduce prompt processing time
    is_local = (
        model_id.startswith("llama_cpp:")
        or model_id.startswith("ollama:")
        or cfg.get_local_model(model_id) is not None
    )
    with renderer.status_spinner("Scanning project...", "reading"):
        if is_local:
            context = _scan_project_context(
                cwd, max_tree=8, max_source_files=1, max_source_lines=8
            )
        else:
            context = _scan_project_context(cwd)
    renderer.step_done("Project scanned")

    # Set token limits: local models balance speed vs output, API models get full room
    # Increased limits to ensure enough memory for completing all procedural steps
    if is_local and tokens == cfg.max_tokens:
        tokens = 8192  # Increased from 4096 for more complete procedural output
    elif not is_local and tokens == cfg.max_tokens:
        tokens = max(tokens, 65536)  # Increased from 32768 for comprehensive task execution

    # Build initial conversation with project context
    system_prompt = build_agent_system_prompt(cwd, is_local=is_local)
    engine = ConversationEngine(
        system_prompt=system_prompt,
        max_history=100,  # Increased from 50 for more procedural context
    )

    bootstrap_user = (
        (
            "Project scan complete. Keep context compact and use READ:/SEARCH: for deep inspection.\n\n"
            f"{context}"
        )
        if is_local
        else (
            "Here is the full project codebase you are working on. "
            "You have already scanned it and have access to all the files listed below. "
            "When the user asks you to analyze, improve, or work on 'this code' or 'the code', "
            "they mean the project files below. Do NOT ask them to provide code — you already have it.\n\n"
            f"{context}"
        )
    )
    messages_init = [
        {"role": "user", "content": bootstrap_user},
        {
            "role": "assistant",
            "content": (
                "I've scanned the project and have full context of the codebase. "
                "I can see all files, the language, dependencies, and code structure. "
                "What would you like me to do?"
            ),
        },
    ]
    for m in messages_init:
        if m["role"] == "user":
            engine.add_user(m["content"])
        else:
            engine.add_assistant(m["content"])

    renderer.print_agent_welcome(model_id, str(cwd), is_local=is_local)

    last_written: list[str] = []
    all_written: list[str] = []
    files_read: set[str] = (
        set()
    )  # Track files that have been READ for write enforcement
    multiline_buffer: list[str] | None = None

    # ── Time Travel Debugger ────────────────────────────────────
    checkpoint_mgr = CheckpointManager(cwd)
    # Create initial checkpoint at session start
    checkpoint_mgr.create_checkpoint(
        files_written=[],
        message_count=engine.turn_count,
        description="Session start",
        auto_stash=False,  # Don't stash at session start
    )

    # ── Security Auditor ────────────────────────────────────────
    security_auditor = SecurityAuditor(cwd)

    # ── Output Verbosity Control ──────────────────────────────
    # When True, shows only essential info: steps, commands, todos, code changes, test results
    minimal_output = True  # Default to minimal for cleaner UX

    # ── Dependency Graph for whole-repo awareness ──────────────
    dep_graph = DependencyGraph(cwd)
    # Index project in background (async-friendly)
    indexed_count = dep_graph.index_project(limit=300)
    if indexed_count > 0 and not minimal_output:
        renderer.info(f"📊 Indexed {indexed_count} files for dependency analysis")

    # ── Multi-Agent Swarm Orchestrator ─────────────────────────
    swarm = SwarmOrchestrator(router, model_id)
    swarm_mode = False  # Toggle for swarm execution mode

    # ── Docker Sandbox & TDD Gate ──────────────────────────────
    sandbox = DockerSandbox(cwd, network_enabled=False)
    tdd_gate = TDDGate(sandbox)
    controller = ControllerModel(router)

    if not minimal_output:
        if sandbox.is_available():
            renderer.info("🐳 Docker sandbox available for isolated execution")
        else:
            renderer.info("⚠️  Docker not available - using local execution")

    # ── Project Memory (SAGE.md) ───────────────────────────────
    project_memory = ProjectMemory(cwd)
    if project_memory.exists() and not minimal_output:
        renderer.info("📝 SAGE.md loaded - project rules active")
        # Inject project rules into system prompt
        rules_context = project_memory.get_context_injection()
        if rules_context:
            engine.system_prompt += rules_context

    # ── Context Compactor ──────────────────────────────────────
    # Increased max_tokens to 200000 and lowered threshold to 0.85
    # to ensure enough memory for completing all procedural steps
    compactor = ContextCompactor(max_tokens=200000, threshold=0.85)

    # ── LSP Client for real-time diagnostics ───────────────────
    lsp_client = LSPClient(cwd)

    # ══════════════════════════════════════════════════════════════════════════
    # ENHANCED AI CAPABILITIES
    # ══════════════════════════════════════════════════════════════════════════

    # ── Chain-of-Thought Reasoning Engine ─────────────────────
    # Advanced reasoning with structured problem decomposition
    # NOTE: reasoning_engine and reflection_engine are instantiated AFTER
    # _send_to_model is defined (see below) so they can use the send function
    error_diagnosis = ErrorDiagnosis()

    # ── Enhanced Code Analysis ────────────────────────────────
    code_analyzer = CodeAnalyzer(cwd)
    code_validator = CodeValidator(cwd)
    style_enforcer = StyleEnforcer()

    # ── Adaptive Execution Engine ─────────────────────────────
    # Intelligent task execution with smart retry and learning
    adaptive_executor = AdaptiveExecutionEngine(cwd, max_workers=4)
    smart_retry = SmartRetryHandler()

    # Track reasoning context for the session
    current_reasoning_context: ReasoningContext | None = None
    enhanced_mode = True  # Enable enhanced AI capabilities

    if not minimal_output:
        renderer.info(
            "🧠 Enhanced AI capabilities enabled (reasoning, validation, learning)"
        )

    # Scan existing files to protect them from accidental overwrites
    _protected: set[str] = set()
    for p in cwd.rglob("*"):
        if p.is_file():
            try:
                rel = str(p.relative_to(cwd))
                parts = rel.split("/")
                if not any(
                    part.startswith(".")
                    or part == "__pycache__"
                    or part == "node_modules"
                    for part in parts
                ):
                    _protected.add(rel)
            except ValueError:
                pass

    def _send_to_model(user_msg: str, show_thinking: bool = True) -> str | None:
        """Send a message to the model and stream the response. Returns response text.

        Ctrl+C during generation cancels and returns partial output.
        In minimal mode, thinking blocks are collapsed to a brief indicator.
        """
        nonlocal tokens, minimal_output
        engine.add_user(user_msg)

        # Context compaction check - show only in verbose mode
        if compactor.needs_compaction(engine._messages):
            if not minimal_output:
                renderer.phase("compacting", "📦 Compacting context...")
            engine._messages = compactor.compact(engine._messages, router, model_id)
            if not minimal_output:
                renderer.info(
                    f"Context compacted to preserve memory. {compactor.get_status(engine._messages)}"
                )

        messages = engine.build_messages()
        try:
            # Always use phase streaming - it filters <thinking> blocks based on output mode
            # stream_tokens_with_phase checks suppress_thinking() internally
            response = renderer.stream_tokens_with_phase(
                router.stream(messages, model_id, temp, tokens),
                model_id=model_id if not minimal_output else "",  # Hide model in minimal mode
            )
            if response:
                engine.add_assistant(response)
            else:
                engine._messages.pop()  # Remove user message if no response
            return response or None
        except KeyboardInterrupt:
            renderer.console.print("\n  [dim yellow]─ Cancelled (Ctrl+C)[/dim yellow]")
            engine._messages.pop()  # Remove the failed user message
            return None
        except Exception as exc:
            err_msg = str(exc)
            err_lower = err_msg.lower()
            is_provider_failure = "all providers failed" in err_lower
            is_context_error = (
                "exceed context" in err_lower
                or "too many tokens" in err_lower
                or "context window" in err_lower
                or (
                    is_provider_failure
                    and ("requested tokens" in err_lower or "llama_cpp" in err_lower)
                )
            )
            is_transient_gateway = (
                "502 bad gateway" in err_lower
                or "503 service unavailable" in err_lower
                or "504 gateway timeout" in err_lower
                or (is_provider_failure and ("404 not found" in err_lower))
            )
            if is_context_error or is_transient_gateway:
                renderer.warning(
                    "Context window full — trimming old messages and retrying..."
                )
                engine._messages.pop()  # Remove the user message we just added
                if is_local:
                    engine._messages[:] = []
                elif len(engine._messages) > 6:
                    engine._messages[:] = engine._messages[:2] + engine._messages[-4:]

                for retry_idx in range(2):
                    old_tokens = tokens
                    match = re.search(
                        r"requested tokens \((\d+)\) exceed context window of (\d+)",
                        err_lower,
                    )
                    if match:
                        requested = int(match.group(1))
                        window = int(match.group(2))
                        overflow = max(1, requested - window)
                        tokens = max(256, min(tokens - overflow - 256, window - 768))
                    elif is_transient_gateway:
                        tokens = max(256, int(tokens * 0.8))
                    else:
                        tokens = max(256, int(tokens * 0.7))
                    if is_local:
                        tokens = min(tokens, 2048)
                    if tokens != old_tokens:
                        renderer.warning(
                            f"Adjusted context (max_tokens {old_tokens} -> {tokens}) and retrying..."
                        )
                    engine.add_user(user_msg)
                    try:
                        messages = engine.build_messages()
                        # Always use phase streaming - filters thinking blocks based on output mode
                        response = renderer.stream_tokens_with_phase(
                            router.stream(messages, model_id, temp, tokens),
                            model_id=model_id if not minimal_output else "",
                        )
                        if response:
                            engine.add_assistant(response)
                        else:
                            engine._messages.pop()
                        return response or None
                    except Exception as retry_exc:
                        engine._messages.pop()
                        err_msg = str(retry_exc)
                        err_lower = err_msg.lower()
                        if retry_idx == 1:
                            renderer.error(err_msg)
                            return None
                        if is_local:
                            engine._messages[:] = []
                        elif len(engine._messages) > 4:
                            engine._messages[:] = engine._messages[-4:]
                        continue
            engine._messages.pop()  # Remove the failed user message
            renderer.error(err_msg)
            return None

    def _send_to_model_autopolit(user_msg: str) -> str | None:
        """Send a message in autopolit mode (non-streaming, interruptible)."""
        nonlocal tokens
        engine.add_user(user_msg)
        messages = engine.build_messages()
        try:
            renderer.phase("thinking", "Autopolit running...")
            response = router.generate(messages, model_id, temp, tokens)
            renderer.console.print("[bold green]sage>[/bold green] ")
            renderer.render_markdown(response)
            if response:
                engine.add_assistant(response)
            else:
                engine._messages.pop()
            return response or None
        except KeyboardInterrupt:
            engine._messages.pop()
            raise
        except Exception as exc:
            err_msg = str(exc)
            err_lower = err_msg.lower()
            engine._messages.pop()
            is_provider_failure = "all providers failed" in err_lower
            is_context_error = (
                "exceed context" in err_lower
                or "too many tokens" in err_lower
                or "context window" in err_lower
                or (
                    is_provider_failure
                    and ("requested tokens" in err_lower or "llama_cpp" in err_lower)
                )
            )
            is_bad_request = "400 bad request" in err_lower
            is_transient_gateway = (
                "502 bad gateway" in err_lower
                or "503 service unavailable" in err_lower
                or "504 gateway timeout" in err_lower
                or (is_provider_failure and ("404 not found" in err_lower))
            )
            if is_context_error or is_bad_request or is_transient_gateway:
                # Keep bootstrap context + most recent turns only.
                if is_local:
                    engine._messages[:] = []
                elif len(engine._messages) > 6:
                    engine._messages[:] = engine._messages[:2] + engine._messages[-4:]
                old_tokens = tokens
                match = re.search(
                    r"requested tokens \((\d+)\) exceed context window of (\d+)",
                    err_lower,
                )
                if match:
                    requested = int(match.group(1))
                    window = int(match.group(2))
                    overflow = max(1, requested - window)
                    tokens = max(256, min(tokens - overflow - 128, window - 512))
                elif is_bad_request:
                    tokens = max(256, int(tokens * 0.75))
                elif is_transient_gateway:
                    tokens = max(256, int(tokens * 0.8))
                else:
                    tokens = max(256, int(tokens * 0.85))
                if is_local:
                    tokens = min(tokens, 2048)
                if tokens != old_tokens:
                    renderer.warning(
                        f"Autopolit adjusted context (max_tokens {old_tokens} -> {tokens}) and retrying..."
                    )
                else:
                    renderer.warning("Autopolit compacted context and retrying...")
                engine.add_user(user_msg)
                retry_messages = engine.build_messages()
                try:
                    renderer.phase("thinking", "Autopolit retry...")
                    retry_response = router.generate(
                        retry_messages, model_id, temp, tokens
                    )
                    renderer.console.print("[bold green]sage>[/bold green] ")
                    renderer.render_markdown(retry_response)
                    if retry_response:
                        engine.add_assistant(retry_response)
                    else:
                        engine._messages.pop()
                    return retry_response or None
                except KeyboardInterrupt:
                    engine._messages.pop()
                    raise
                except Exception as retry_exc:
                    engine._messages.pop()
                    renderer.error(str(retry_exc))
                    return None
            renderer.error(err_msg)
            return None

    # ══════════════════════════════════════════════════════════════════════════
    # CRITICAL FIX: Instantiate reasoning and reflection engines with send functions
    # These were previously set to None and never used - this connects them to the model
    # ══════════════════════════════════════════════════════════════════════════

    def _send_for_reasoning(prompt: str) -> str | None:
        """Send function for reasoning engine - doesn't add to conversation history."""
        nonlocal tokens
        messages = engine.build_messages()
        messages.append(Message(role="user", content=prompt))
        try:
            response = router.generate(messages, model_id, temp, min(tokens, 2048))
            return response
        except Exception:
            return None

    # Now instantiate the reasoning and reflection engines with actual send functions
    reasoning_engine = ChainOfThoughtReasoner(_send_for_reasoning, cwd)
    reflection_engine = SelfReflectionEngine(_send_for_reasoning)
    execution_engine = AdaptiveExecutionEngine(cwd, max_workers=4)

    # ══════════════════════════════════════════════════════════════════════════
    # CRITICAL: AI Model-Driven Orchestrator
    # Replaces all hardcoded orchestration with AI-driven decision making
    # ══════════════════════════════════════════════════════════════════════════
    def _ai_model_send(prompt: str) -> dict:
        """Wrapper to send prompts to AI model and parse JSON response."""
        try:
            response = _send_for_reasoning(prompt)
            if response:
                # Try to extract JSON from the response
                import json
                # Look for JSON in the response
                json_match = re.search(r'\{[\s\S]*\}', response)
                if json_match:
                    return json.loads(json_match.group())
            return {"result": response}
        except Exception:
            return {"result": "error", "error": "Failed to parse response"}

    ai_orchestrator = AIOrchestrator(
        _ai_model_send,
        enable_plugins=True,
        repo_path=cwd,
    )

    if not minimal_output:
        renderer.info("🧠 Reasoning, reflection, execution, and AI orchestration engines connected to model")
        capabilities_count = len(ai_orchestrator.list_plugin_capabilities())
        if capabilities_count:
            renderer.info(f"🔌 Plugin capabilities loaded: {capabilities_count}")

    def _process_response(response: str, tool_depth: int = 0) -> list[str]:
        """Process model response: write files, execute tool commands, run bash blocks.

        Handles the full agent loop:
        1. Execute READ:/SEARCH:/RUN: tool commands → feed results back to model
        2. Extract and write FILE: blocks
        3. Execute ```bash blocks
        Returns list of written files.
        """
        nonlocal last_written, all_written, files_read

        # ── Step 1: Execute tool commands (READ, SEARCH, RUN) ──
        if tool_depth >= 6:
            renderer.warning(
                "Tool loop depth limit reached. Requesting direct FILE: output next step."
            )
            return []

        if _response_describes_code_without_file_blocks(response):
            renderer.warning(
                "Response described code changes without FILE blocks. Ignoring shell execution until the model emits writable files."
            )
            return []

        tool_commands = _extract_tool_commands(response)
        if tool_commands:
            # Track files that are READ for write enforcement
            for tool_type, arg in tool_commands:
                if tool_type == "READ":
                    # Normalize path and add to files_read
                    normalized_path = arg.strip().lstrip("./")
                    files_read.add(normalized_path)
            tool_results = _execute_tool_commands(tool_commands, cwd)
            if tool_results:
                per_result_limit = 1200 if is_local else 5000
                total_limit = 4000 if is_local else 20000
                compact_results: list[str] = []
                used = 0
                for item in tool_results:
                    trimmed = (
                        item
                        if len(item) <= per_result_limit
                        else item[:per_result_limit]
                    )
                    if used + len(trimmed) > total_limit:
                        break
                    compact_results.append(trimmed)
                    used += len(trimmed)
                # Feed tool results back to model for a follow-up
                tool_context = (
                    "\n\n".join(compact_results)
                    if compact_results
                    else "(no tool output)"
                )
                followup_prompt = _build_tool_followup_prompt(
                    tool_context,
                    _get_current_classification(),
                )
                followup = _send_to_model(followup_prompt, show_thinking=False)
                if followup:
                    # Recursively process the follow-up (it may have more tools or files)
                    return _process_response(followup, tool_depth + 1)

        # ── Step 2: Write FILE: blocks ─────────────────────────
        written = _extract_and_write_files(
            response, cwd, protected_files=_protected, files_read=files_read
        )
        if written:
            # Auto-checkpoint before major file changes (Time Travel safety)
            if len(written) >= 2 or any(not (cwd / fp).exists() for fp in written):
                checkpoint_mgr.create_checkpoint(
                    files_written=list(all_written),
                    message_count=len(engine._messages),
                    description=f"Before writing {len(written)} file(s)",
                    auto_stash=False,  # Don't stash on every write
                )
            last_written = written
            all_written.extend(written)
            renderer.print_files_written(written)

            # ── Security audit on written files ────────────────────
            security_findings = security_auditor.scan_files(written)
            if security_findings:
                renderer.warning(security_auditor.format_findings(security_findings))
                if security_auditor.has_critical_findings(security_findings):
                    renderer.error(
                        "⚠️  CRITICAL security issues detected. "
                        "Review and fix before committing."
                    )

            # ── Dependency impact analysis ─────────────────────────
            impact_summary = dep_graph.get_impact_summary(written)
            if impact_summary:
                renderer.warning(impact_summary)
                # Re-index the changed files
                for fp in written:
                    dep_graph.index_file(fp)

            # ── LSP diagnostics (real-time error detection) ────────
            lsp_diags = lsp_client.check_files(written)
            if lsp_diags and lsp_client.has_errors(lsp_diags):
                renderer.warning(lsp_client.format_diagnostics(lsp_diags))
                # Auto-feed LSP errors back to model for fixing
                lsp_error_context = lsp_client.format_diagnostics(lsp_diags)
                fix_prompt = (
                    f"LSP detected errors in the code you just wrote:\n\n{lsp_error_context}\n\n"
                    "Fix these errors now. Output corrected FILE: blocks."
                )
                fix_response = _send_to_model(fix_prompt, show_thinking=False)
                if fix_response:
                    _process_response(fix_response, tool_depth + 1)

            # ── AUTOMATIC TDD CYCLE ────────────────────────────────
            # This is the "Gather-Act-Verify" loop from Claude Code
            test_files = [f for f in written if "test_" in f or f.startswith("tests/")]
            impl_files = [
                f for f in written if f not in test_files and f.endswith(".py")
            ]

            if test_files and not impl_files:
                # RED PHASE: Tests written - automatically verify they fail
                renderer.phase(
                    "tdd", "🔴 AUTO-TDD: Verifying tests fail (RED phase)..."
                )
                is_red, message = tdd_gate.verify_red()
                if is_red:
                    renderer.success(message)
                    # Now prompt model to write implementation
                    impl_prompt = (
                        "Tests are failing as expected (RED phase complete). "
                        "Now write the IMPLEMENTATION code to make them pass. "
                        "Output FILE: blocks with the implementation."
                    )
                    impl_response = _send_to_model(impl_prompt, show_thinking=False)
                    if impl_response:
                        _process_response(impl_response, tool_depth + 1)
                else:
                    renderer.warning(message)
                    # Tests already pass or couldn't run - inform model
                    fix_prompt = (
                        f"TDD Issue: {message}\n\n"
                        "The tests should FAIL first to prove the feature is missing. "
                        "Rewrite the tests to properly verify the expected behavior."
                    )
                    fix_response = _send_to_model(fix_prompt, show_thinking=False)
                    if fix_response:
                        _process_response(fix_response, tool_depth + 1)

            elif impl_files:
                # GREEN PHASE: Implementation written - automatically verify tests pass
                if tdd_gate.red_verified:
                    renderer.phase(
                        "tdd", "🟢 AUTO-TDD: Verifying tests pass (GREEN phase)..."
                    )
                    is_green, message = tdd_gate.verify_green()
                    if is_green:
                        renderer.success(message)
                        tdd_gate.reset()  # Ready for next TDD cycle
                    else:
                        renderer.warning(message)
                        # Tests still fail - feed error back to model
                        fix_prompt = (
                            f"Tests are still failing:\n\n{message}\n\n"
                            "Fix the implementation to make tests pass. "
                            "Output corrected FILE: blocks."
                        )
                        fix_response = _send_to_model(fix_prompt, show_thinking=False)
                        if fix_response:
                            _process_response(fix_response, tool_depth + 1)
                else:
                    # Implementation without RED - auto-run tests anyway
                    renderer.phase("tdd", "⚠️ Running tests on implementation...")
                    result = (
                        sandbox.run_tests(default_test_cmd)
                        if sandbox.is_available()
                        else None
                    )
                    if result and result.exit_code != 0:
                        # Tests fail - good opportunity to establish TDD
                        renderer.warning(
                            f"Tests failing:\n{result.stderr[:500] or result.stdout[:500]}\n"
                            "Feeding errors back to model for fixing..."
                        )
                        fix_prompt = (
                            f"Tests failed after your implementation:\n\n"
                            f"```\n{result.stderr[:1000] or result.stdout[:1000]}\n```\n\n"
                            "Fix the code to make tests pass. Output corrected FILE: blocks."
                        )
                        fix_response = _send_to_model(fix_prompt, show_thinking=False)
                        if fix_response:
                            _process_response(fix_response, tool_depth + 1)
                    elif result and result.exit_code == 0:
                        renderer.success("✅ Tests passing!")

        # ── Step 3: Execute bash blocks ────────────────────────
        bash_blocks = _extract_bash_blocks(response)
        for cmd in bash_blocks:
            cmd = _sanitize_shell_block(cmd)
            if not cmd:
                continue

            # Controller validation before execution
            is_safe, reason = controller.validate_command(cmd)
            if not is_safe:
                renderer.error(f"🛡️ Controller blocked: {reason}")
                continue

            should_run = auto_run
            if not should_run:
                try:
                    answer = renderer.console.input(
                        f"  [yellow]▷ Run:[/yellow] [dim]{cmd[:80]}{'...' if len(cmd) > 80 else ''}[/dim] [yellow](y/n)?[/yellow] "
                    )
                    should_run = answer.strip().lower() in {"y", "yes", ""}
                except (EOFError, KeyboardInterrupt):
                    break
            if should_run:
                renderer.print_shell_start(cmd)
                try:
                    with renderer.status_spinner(
                        f"Running: {cmd[:60]}...", "executing"
                    ):
                        output = _run_shell(cmd, cwd, timeout=60)
                    renderer.print_shell_output(output)
                    engine.add_user(f"[Ran: {cmd}]")
                    engine.add_assistant(f"Command output:\n```\n{output}\n```")
                except KeyboardInterrupt:
                    renderer.console.print(
                        "\n  [dim yellow]─ Command cancelled (Ctrl+C)[/dim yellow]"
                    )

        return written

    def _quality_check(response: str, original_prompt: str = "") -> str | None:
        """Check if response is low quality and return a retry prompt if so.

        Quality checks (in order of priority):
        1. Empty/too short responses
        2. Repetitive/stuck responses
        3. Cut-off responses (unclosed code blocks)
        4. Code described in prose without FILE: blocks (skipped for analysis)
        5. Missing TDD pattern (implementation without tests)
        6. Placeholder/TODO code
        7. Invalid commit messages
        """
        if not response:
            return None
        stripped = response.strip()

        is_analysis = _is_readonly_analysis_request(original_prompt) if original_prompt else False

        # Too short to be useful (less than 50 chars and no FILE: blocks)
        # Skip for analysis — a short analysis answer can be valid
        if len(stripped) < 50 and "FILE:" not in response and not is_analysis:
            return (
                "Your response was too short. Provide a complete implementation "
                "with FILE: blocks containing full file contents and RUN: commands to verify."
            )

        # Repetitive/stuck (same phrase repeated many times)
        words = stripped.split()
        if len(words) > 20:
            unique_ratio = len(set(words)) / len(words)
            if unique_ratio < 0.15:
                return (
                    "Your response was repetitive. Take a fresh approach: "
                    "READ: the relevant files, then write a clear implementation with FILE: blocks."
                )

        # Response cut off mid-sentence (no closing ``` for last code block)
        open_blocks = response.count("```")
        if open_blocks % 2 != 0:
            return (
                "Your response was cut off mid-code-block. "
                "Continue from where you left off and complete the FILE: blocks."
            )

        if not is_analysis and _response_describes_code_without_file_blocks(response):
            return (
                "You described code changes, tests, or file contents without using FILE: blocks. "
                "Reissue the response with explicit FILE: path/to/file.ext blocks containing complete file contents, "
                "and use READ:/SEARCH:/RUN: commands for exploration and validation."
            )

        # Check for TDD violation: implementation files without corresponding tests
        # Skip for analysis and when response includes READ: (model is gathering context first)
        if not is_analysis:
            file_blocks = re.findall(r"FILE:\s*(\S+)", response)
            impl_files = [
                f for f in file_blocks if not f.startswith("tests/") and "test_" not in f
            ]
            test_files = [f for f in file_blocks if f.startswith("tests/") or "test_" in f]
            has_read_commands = "READ:" in response

            if impl_files and not test_files and "RUN:" not in response and not has_read_commands:
                return (
                    "TDD VIOLATION: You wrote implementation code without tests.\n"
                    "You MUST follow TDD:\n"
                    "1. Write a failing test FIRST (FILE: tests/test_*.py)\n"
                    "2. Run the test to see it fail (RUN: pytest tests/test_*.py -v)\n"
                    "3. Then write implementation to make it pass\n"
                    "4. Run tests again to verify (RUN: pytest -v)\n\n"
                    "Rewrite your response with tests FIRST."
                )

        # Check for placeholder/TODO code in FILE blocks
        placeholder_patterns = [
            r"# TODO[:\s]",
            r"# FIXME[:\s]",
            r"# implement\s+this",
            r"pass\s*#\s*placeholder",
            r"\.\.\.\s*#\s*rest",
            r"raise\s+NotImplementedError",
            r"# Placeholder",
            r"# placeholder",
            r"if needed",  # "# Placeholder test if needed"
        ]
        for pattern in placeholder_patterns:
            if re.search(pattern, response, re.IGNORECASE):
                return (
                    "Your code contains placeholder/TODO comments or incomplete implementations.\n"
                    "You MUST provide COMPLETE, WORKING code. No placeholders, no TODOs, no '...'.\n"
                    "Rewrite with fully functional code that passes all tests."
                )

        # CRITICAL: Detect empty/useless functions (just 'pass' statements)
        # Count functions that only contain 'pass'
        empty_func_pattern = (
            r"def\s+\w+\([^)]*\):\s*\n\s*(?:#[^\n]*)?\s*pass\s*(?:\n|$)"
        )
        empty_functions = re.findall(empty_func_pattern, response)
        if len(empty_functions) >= 3:
            return (
                "GARBAGE CODE DETECTED: You wrote multiple empty functions with just 'pass'.\n"
                "This is UNACCEPTABLE. Empty functions do NOTHING.\n\n"
                "RULES:\n"
                "1. Every function MUST have actual implementation logic\n"
                "2. Test functions MUST have assertions (assert, assertEqual, etc.)\n"
                "3. If you don't know what to implement, READ: the source files first\n"
                "4. NEVER write placeholder functions\n\n"
                "START OVER: Read the existing code, understand what's needed, then write REAL implementations."
            )

        # Detect test files without assertions
        if "test_" in response and "FILE:" in response:
            # Check if there are test functions but no assertions
            has_test_funcs = bool(re.search(r"def test_\w+", response))
            has_assertions = bool(
                re.search(
                    r"\b(assert|assertEqual|assertTrue|assertFalse|assertRaises|assertIn|expect\(|should\.|to_equal|toBe)",
                    response,
                )
            )

            if has_test_funcs and not has_assertions:
                return (
                    "USELESS TESTS DETECTED: You wrote test functions without any assertions.\n"
                    "Tests without assertions prove NOTHING.\n\n"
                    "EVERY test function MUST have assertions:\n"
                    "- Python: assert result == expected, self.assertEqual(a, b)\n"
                    "- Jest: expect(result).toBe(expected)\n\n"
                    "Rewrite with REAL test logic that verifies behavior."
                )

        # Detect excessive repetition of similar function signatures (copy-paste garbage)
        func_signatures = re.findall(r"def\s+(\w+)\s*\(", response)
        if len(func_signatures) > 10:
            # Check if many functions have similar names (pattern-generated garbage)
            base_names = [re.sub(r"_\w+$", "", name) for name in func_signatures]
            from collections import Counter

            name_counts = Counter(base_names)
            most_common = name_counts.most_common(1)
            if most_common and most_common[0][1] >= 5:
                return (
                    "COPY-PASTE GARBAGE DETECTED: You generated many similar functions.\n"
                    f"Found {most_common[0][1]} functions starting with '{most_common[0][0]}_'.\n\n"
                    "This looks like you're generating repetitive placeholder code.\n"
                    "STOP. Read the ACTUAL requirements and write ONLY what's needed.\n\n"
                    "Write focused, minimal code that solves the specific problem."
                )

        # Detect mock classes without actual usage
        mock_pattern = r"class Mock\w+:\s*\n\s*def __init__"
        mocks = re.findall(mock_pattern, response)
        if len(mocks) >= 2 and "pytest" not in response.lower():
            return (
                "UNNECESSARY MOCKS DETECTED: You created mock classes that aren't used.\n"
                "Don't create infrastructure that isn't needed.\n\n"
                "RULES:\n"
                "1. Only mock what's actually required for tests\n"
                "2. Use pytest fixtures or unittest.mock instead of custom mock classes\n"
                "3. Import and test the REAL code, not mocks\n\n"
                "Rewrite: Import the actual module and test its real behavior."
            )

        # Check for bad commit messages
        bad_commit_patterns = [
            r'git commit -m ["\']?(fixed|changed|updated|modified|WIP|changes|stuff)["\']?\s*$',
            r'git commit -m ["\']?[^"\']{1,10}["\']?\s*$',  # Too short (< 10 chars)
        ]
        for pattern in bad_commit_patterns:
            if re.search(pattern, response, re.IGNORECASE):
                return (
                    "BAD COMMIT MESSAGE DETECTED.\n"
                    "Use Conventional Commits format: type(scope): description\n"
                    "Examples:\n"
                    "- feat(auth): add JWT token validation\n"
                    "- fix(api): prevent null pointer in user lookup\n"
                    "- refactor(utils): extract date formatting to helper\n\n"
                    "Rewrite your git commit command with a descriptive message."
                )

        # NEW: Detect overly verbose/repetitive code patterns (boilerplate generation)
        # Pattern: Many methods with similar docstrings indicating copy-paste
        docstring_pattern = r'"""[^"]+"""'
        docstrings = re.findall(docstring_pattern, response)
        if len(docstrings) > 10:
            # Check for repetitive docstrings
            from collections import Counter
            # Normalize by removing specific details
            normalized = [re.sub(r'\d+', 'N', d)[:50] for d in docstrings]
            counts = Counter(normalized)
            most_common = counts.most_common(1)
            if most_common and most_common[0][1] >= 5:
                return (
                    "BOILERPLATE CODE DETECTED: You generated many similar docstrings/methods.\n"
                    f"Found {most_common[0][1]} nearly identical docstrings.\n\n"
                    "This is a sign of copy-paste boilerplate generation.\n"
                    "STOP. Focus on the SPECIFIC task at hand.\n\n"
                    "Write ONLY the code needed for this task. No boilerplate. No templates.\n"
                    "If asked to implement ONE feature, implement ONE feature."
                )

        # NEW: Detect test files that import non-existent modules (hallucination)
        if "FILE:" in response and "import " in response:
            file_blocks = re.findall(r"FILE:\s*(\S+)\s*\n```[a-z]*\n(.*?)```", response, re.DOTALL)
            for filepath, content in file_blocks:
                if "test_" in filepath or filepath.startswith("tests/"):
                    # Look for imports of modules being tested
                    imports = re.findall(r"from\s+(\w+(?:\.\w+)*)\s+import", content)
                    for imp in imports:
                        # Check if the module being imported is also defined in FILE blocks
                        module_file = imp.replace(".", "/") + ".py"
                        impl_patterns = [module_file, imp.split(".")[-1] + ".py"]
                        has_impl = any(
                            any(p in fb[0] for p in impl_patterns)
                            for fb in file_blocks
                            if "test_" not in fb[0]
                        )
                        # If importing from a module that doesn't exist and isn't being created
                        if not has_impl and imp not in ["pytest", "unittest", "mock", "typing", "os", "sys", "json", "re", "pathlib"]:
                            # This might be importing a module that should be created
                            pass  # Allow this - implementation might exist already

        # NEW: Detect when model writes tests AFTER implementation (TDD violation)
        file_blocks_ordered = re.findall(r"FILE:\s*(\S+)", response)
        impl_indices = [i for i, f in enumerate(file_blocks_ordered) if "test_" not in f and not f.startswith("tests/")]
        test_indices = [i for i, f in enumerate(file_blocks_ordered) if "test_" in f or f.startswith("tests/")]

        if impl_indices and test_indices:
            # Tests should come BEFORE implementation in TDD
            first_impl = min(impl_indices)
            first_test = min(test_indices)
            if first_impl < first_test:
                return (
                    "TDD VIOLATION: You wrote implementation BEFORE tests.\n\n"
                    "In TDD, the order is:\n"
                    "1. Write failing tests FIRST (FILE: tests/test_*.py)\n"
                    "2. Write implementation to make tests pass (FILE: src/*.py)\n"
                    "3. Run tests to verify\n\n"
                    "You wrote implementation files before test files.\n"
                    "REORDER your response: Tests FIRST, then implementation."
                )

        return None

    def _auto_validate_and_retry(
        written: list[str], retries_left: int, attempt: int = 1
    ) -> None:
        """Auto-validate written files and retry on failure.

        Key improvements over naive retry:
        - Detects when model is stuck repeating the same fix → breaks loop
        - Provides module discovery when ImportError occurs
        - Trims context aggressively to avoid overflow on retries
        - Deletes broken files written by the model if they can't be fixed
        """
        if not written or retries_left <= 0:
            return

        validation = _auto_validate(written, cwd)
        if validation is None:
            return

        cmd_name, output = validation
        renderer.print_validation_start(cmd_name)

        with renderer.status_spinner("Running validation...", "testing"):
            pass  # validation already ran in _auto_validate

        has_errors = _has_errors(output)
        renderer.print_test_results(output, passed=not has_errors)

        if not has_errors:
            return

        # Track previous fix responses to detect repetition
        previous_fixes: list[str] = []

        current_written = written
        for retry_num in range(1, retries_left + 1):
            renderer.print_retry(retry_num, max_retries)

            # Trim context before retry to prevent overflow
            if len(engine._messages) > 10:
                engine._messages[:] = engine._messages[:2] + engine._messages[-6:]

            # Build smart error context with module discovery
            smart_context = _build_smart_error_context(output, current_written, cwd)

            # Include file contents in error feedback
            file_contents = []
            for fp in current_written[:3]:
                content = _read_file_context(fp, cwd, max_lines=80)
                if content:
                    file_contents.append(content)
            file_context = "\n\n".join(file_contents) if file_contents else ""

            fix_prompt = (
                f"VALIDATION FAILED (attempt {retry_num}/{max_retries}).\n"
                f"Command: `{cmd_name}`\n"
                f"Error:\n```\n{_summarize_test_output(output, max_chars=3000)}\n```\n"
            )
            if file_context:
                fix_prompt += f"\nCurrent file contents:\n\n{file_context}\n\n"
            if smart_context:
                fix_prompt += smart_context + "\n\n"
            fix_prompt += (
                "RULES FOR THIS FIX:\n"
                "1. Read the ACTUAL error message above — do not guess.\n"
                "2. Fix ONLY the specific error — do not rewrite unrelated code.\n"
                "3. If a module doesn't exist, check AVAILABLE PROJECT MODULES above.\n"
                "4. If a test imports a non-existent module, fix the implementation or import path; do NOT delete tests unless explicitly asked.\n"
                "5. Output corrected FILE: blocks with COMPLETE file contents.\n"
                "6. Try a DIFFERENT approach if your previous fix didn't work."
            )

            fix_response = _send_to_model(fix_prompt)
            if not fix_response:
                break

            # Check for repetition — model stuck producing same output
            if _detect_repetition(previous_fixes, fix_response):
                renderer.warning(
                    "Model is repeating the same fix — stopping retry loop. "
                    "Flagging broken files for follow-up."
                )
                # Flag suspicious test files instead of deleting repo content automatically.
                for fp in current_written:
                    target = cwd / fp
                    if target.exists() and _is_broken_test_file(fp, output):
                        renderer.info(f"  Flagged broken test file for review: {fp}")
                break

            previous_fixes.append(fix_response)

            new_written = _process_response(fix_response)
            if not new_written:
                break

            current_written = new_written

            # Re-validate
            validation = _auto_validate(current_written, cwd)
            if validation is None:
                break

            cmd_name, output = validation
            has_errors = _has_errors(output)
            renderer.print_test_results(output, passed=not has_errors)

            if not has_errors:
                renderer.success(f"Fixed on attempt {retry_num}!")
                break

    def _execute_multistep(
        task_prompt: str,
        send: Callable[[str], str | None],
        classification: _ClassifiedRequest | None = None,
    ) -> list[str]:
        """Execute a task via focused multi-step pipeline.

        Instead of one monolithic prompt, break work into model-driven phases.
        The phase set depends on the request type:
        - Read-only analysis: planning -> analysis -> synthesis
        - Implementation: planning -> testing -> implementation

        Each step is a separate model call with a focused prompt,
        keeping each call within the capability range of small models.
        """
        all_step_written: list[str] = []

        phase_messages = {
            "planning": "Breaking task into steps...",
            "analysis": "Investigating with the model...",
            "synthesis": "Synthesizing final analysis...",
            "testing": "Writing tests first (TDD)...",
            "implementation": "Writing implementation...",
        }

        for phase_name, prompt in _build_multistep_phase_prompts(task_prompt, classification, cwd):
            renderer.phase(
                "planning" if phase_name == "planning" else "thinking",
                phase_messages.get(phase_name, "Working..."),
            )
            phase_response = send(prompt)
            if not phase_response:
                if phase_name == "planning":
                    return []
                continue

            if classification and classification.read_only and phase_name in {"planning", "analysis"}:
                for retry_num in range(1, 3):
                    if files_read or _extract_tool_commands(phase_response):
                        break
                    nudge = _build_readonly_exploration_nudge(
                        phase_name,
                        classification,
                        has_verified_files=bool(files_read),
                    )
                    if not nudge:
                        break
                    renderer.phase(
                        "fixing",
                        f"Read-only investigation missing tool commands (attempt {retry_num}/2) — requesting evidence gathering..."
                    )
                    retry_response = send(nudge)
                    if not retry_response:
                        break
                    phase_response = retry_response

            defer_synthesis_processing = bool(
                classification
                and classification.read_only
                and phase_name == "synthesis"
            )
            if not defer_synthesis_processing:
                phase_written = _process_response(phase_response)
                all_step_written.extend(phase_written)

            grounding_final_fail = False
            if classification and classification.read_only and phase_name == "synthesis":
                # P0: Gate before showing synthesis; never emit ungrounded "final" analysis
                can_synthesize, gate_reason = _check_synthesis_gate()
                if not can_synthesize:
                    renderer.info(
                        f"Synthesis waiting on evidence: {gate_reason} — gathering more context..."
                    )
                    evidence_prompt = (
                        f"SYNTHESIS BLOCKED: {gate_reason}\n\n"
                        "You must gather concrete evidence before synthesizing findings.\n"
                        "Issue READ: and SEARCH: commands to verify your claims:\n"
                        "1. READ: specific files to understand their contents\n"
                        "2. SEARCH: for patterns to find relevant code\n"
                        "3. Only then synthesize findings based on VERIFIED evidence\n\n"
                        "Start with evidence gathering commands NOW."
                    )
                    evidence_response = send(evidence_prompt)
                    if evidence_response:
                        _process_response(evidence_response)
                    can_synthesize, gate_reason = _check_synthesis_gate()
                    if not can_synthesize:
                        grounding_final_fail = True
                        phase_response = (
                            "## Could not complete grounded analysis\n\n"
                            f"Insufficient verified evidence ({gate_reason}).\n\n"
                            "Use READ: and SEARCH: on real files in this project, then ask again, "
                            "or narrow your question."
                        )

                phase_written = _process_response(phase_response)
                all_step_written.extend(phase_written)

                if grounding_final_fail:
                    continue

                # For LIST_GENERATION, allow more retries since items come in batches
                max_list_retries = 10 if classification.request_type == _RequestType.LIST_GENERATION else 2

                # P0-1: Track cumulative items across all retries
                cumulative_responses: list[str] = [phase_response]
                cumulative_item_numbers: set[int] = set()
                previous_response: str | None = None

                # Extract initial items
                for line in phase_response.splitlines():
                    match = re.match(r"^\s*(\d+)[\.\)]\s+", line)
                    if match:
                        cumulative_item_numbers.add(int(match.group(1)))

                for retry_num in range(1, max_list_retries + 1):
                    # P0-1: Pass cumulative count for accurate continuation prompts
                    retry_prompt = _build_readonly_response_retry_prompt(
                        phase_response,
                        classification,
                        verified_files=files_read,
                        cumulative_item_count=len(cumulative_item_numbers),
                    )
                    if not retry_prompt:
                        break

                    if renderer.is_verbose():
                        renderer.phase(
                            "fixing",
                            f"Analysis response incomplete (attempt {retry_num}/{max_list_retries}) — requesting continuation..."
                        )
                    retry_response = send(retry_prompt)
                    if not retry_response:
                        break

                    # P0-2: Detect repetition and break early
                    if previous_response:
                        curr_nums = set()
                        prev_nums = set()
                        for line in retry_response.splitlines():
                            match = re.match(r"^\s*(\d+)[\.\)]\s+", line)
                            if match:
                                curr_nums.add(int(match.group(1)))
                        for line in previous_response.splitlines():
                            match = re.match(r"^\s*(\d+)[\.\)]\s+", line)
                            if match:
                                prev_nums.add(int(match.group(1)))
                        # If >50% overlap in item numbers, it's repeating
                        if curr_nums and prev_nums:
                            overlap = curr_nums & prev_nums
                            if len(overlap) / len(curr_nums) > 0.5:
                                if renderer.is_verbose():
                                    renderer.phase("fixing", "Detected repeated output, stopping continuation")
                                break

                    # Update cumulative tracking
                    for line in retry_response.splitlines():
                        match = re.match(r"^\s*(\d+)[\.\)]\s+", line)
                        if match:
                            cumulative_item_numbers.add(int(match.group(1)))
                    cumulative_responses.append(retry_response)

                    previous_response = retry_response
                    phase_response = retry_response
                    phase_written = _process_response(phase_response)
                    all_step_written.extend(phase_written)

        return all_step_written

    def _execute_task_prompt(
        task_prompt: str,
        save_history: bool = True,
        sender: Callable[[str], str | None] | None = None,
        ensure_green: bool = False,
        final_validation_cmd: str | None = None,
        role_trace: bool = False,
    ) -> tuple[list[str], bool]:
        """Run one full agent task cycle and return (written_files, task_ok)."""
        send = sender or _send_to_model
        validation_cmd = ""
        validation_status = "not-run"
        validation_retries = 0

        # ══════════════════════════════════════════════════════════════════════════
        # CRITICAL: Classify request FIRST to enable enforcement during processing
        # ══════════════════════════════════════════════════════════════════════════
        classification = _classify_and_store_request(task_prompt)
        if classification.read_only:
            renderer.phase(
                "analysis",
                f"📊 Request type: {classification.request_type.name} (read-only analysis)"
            )
            if classification.quantity_required:
                renderer.info(
                    f"   Quantity required: {classification.quantity_required}+ items"
                )
        else:
            renderer.phase(
                "planning",
                f"🔧 Request type: {classification.request_type.name} (implementation allowed)"
            )

        if role_trace:
            renderer.phase(
                "planning", "[Planner] Analyze requirements and produce plan"
            )
        if save_history:
            _add_to_prompt_history(cwd, task_prompt)

        # ══════════════════════════════════════════════════════════════════════════
        # CRITICAL: AI Model-Driven Orchestration
        # Uses AI model for ALL decisions instead of hardcoded keyword matching
        # ══════════════════════════════════════════════════════════════════════════
        ai_complexity = None
        ai_decomposition = None
        ai_plan = None
        ai_plugin_context = ""

        if enhanced_mode and ai_orchestrator is not None:
            try:
                # Step 1: Assess task complexity via AI (not hardcoded rules)
                ai_complexity = ai_orchestrator.complexity_assessor.assess(task_prompt)
                if ai_complexity.level == "high":
                    renderer.phase("analysis", f"🎯 AI assessed complexity: {ai_complexity.level} (score: {ai_complexity.score})")
                    if ai_complexity.factors:
                        renderer.info(f"   Factors: {', '.join(ai_complexity.factors[:3])}")

                # Step 2: Decompose task via AI (not keyword-based splitting)
                ai_decomposition = ai_orchestrator.decomposition_engine.decompose(task_prompt)
                if len(ai_decomposition.subtasks) > 1:
                    renderer.info(f"   AI decomposed into {len(ai_decomposition.subtasks)} subtasks")

                # Step 3: Generate execution plan via AI (not template-based)
                if ai_complexity.level in {"medium", "high"}:
                    ai_plan = ai_orchestrator.plan_generator.generate(task_prompt)
                    if ai_plan.steps:
                        renderer.info(f"   AI generated {len(ai_plan.steps)}-step execution plan")

                plugin_cycle = ai_orchestrator.run_plugin_cycle(
                    task_prompt,
                    allow_mutating=not classification.read_only,
                )
                planned_actions = plugin_cycle.get("planned_actions", [])
                plugin_results = plugin_cycle.get("results", [])
                ai_plugin_context = str(plugin_cycle.get("summary", "")).strip()

                if planned_actions:
                    renderer.info(
                        f"   AI planned {len(planned_actions)} plugin action(s)"
                    )
                for plugin_result in plugin_results:
                    if not plugin_result.get("success", False):
                        capability = plugin_result.get("capability_key", "unknown")
                        error_type = plugin_result.get("error_type", "internal")
                        error_message = plugin_result.get("error_message", "")
                        renderer.warning(
                            f"Plugin action failed [{capability}]: {error_type}: {error_message}"
                        )

                # P0 item 35: Track orchestration failures in results
                # Check for any failures in orchestration components
                orchestration_failures = []
                if ai_complexity and ai_complexity.failure:
                    orchestration_failures.append(ai_complexity.failure)
                if ai_decomposition and ai_decomposition.failure:
                    orchestration_failures.append(ai_decomposition.failure)
                if ai_plan and ai_plan.failure:
                    orchestration_failures.append(ai_plan.failure)

                if orchestration_failures:
                    # Surface failures but continue with degraded behavior
                    for failure in orchestration_failures:
                        renderer.warning(
                            f"Orchestration degraded [{failure.phase}]: {failure.error}"
                            + (" (using fallback)" if failure.fallback_used else "")
                        )
            except Exception as e:
                # P0 item 3: Replace generic warning with structured failure details
                import traceback
                error_type = type(e).__name__
                error_msg = str(e)
                # Log structured error for debugging
                renderer.warning(
                    f"AI orchestration skipped: {error_type}: {error_msg}"
                )
                if renderer.is_verbose():
                    renderer.info(f"   Traceback: {traceback.format_exc()[:500]}")

        # ══════════════════════════════════════════════════════════════════════════
        # CRITICAL FIX: Use reasoning engine for complex tasks
        # This enables structured thinking BEFORE sending to the model
        # ══════════════════════════════════════════════════════════════════════════
        nonlocal current_reasoning_context

        # Determine if task needs reasoning - use AI complexity if available
        needs_reasoning_ai = ai_complexity and ai_complexity.level in {"medium", "high"}
        needs_reasoning = (
            (needs_reasoning_ai or (
                not classification.read_only
                and classification.request_type.name in {"IMPLEMENTATION", "MULTI_STEP", "DEBUGGING"}
            ))
            and not _is_readonly_analysis_request(task_prompt)
            and enhanced_mode
        )

        reasoning_summary = ""
        if needs_reasoning and reasoning_engine is not None:
            renderer.phase("reasoning", "🧠 Analyzing task with chain-of-thought reasoning...")
            try:
                # Use quick reasoning for simple tasks, full for complex
                word_count = len(task_prompt.split())
                depth = "full" if word_count > 15 or "and" in task_prompt.lower() else "quick"
                current_reasoning_context = reasoning_engine.reason(task_prompt, depth=depth)

                # Get reasoning summary to enhance the prompt
                reasoning_summary = reasoning_engine.get_reasoning_summary()
                if current_reasoning_context.subtasks:
                    renderer.info(f"   Identified {len(current_reasoning_context.subtasks)} subtask(s)")
                if current_reasoning_context.selected_approach:
                    renderer.info(f"   Selected approach: {current_reasoning_context.selected_approach.approach[:60]}...")
            except Exception as e:
                renderer.warning(f"Reasoning phase skipped: {e}")
                current_reasoning_context = None

        if ai_plugin_context:
            if reasoning_summary:
                reasoning_summary = (
                    f"{reasoning_summary}\n\n"
                    f"## Plugin Execution Context\n{ai_plugin_context}"
                )
            else:
                reasoning_summary = f"## Plugin Execution Context\n{ai_plugin_context}"

        # ══════════════════════════════════════════════════════════════════════════
        # CRITICAL: Use AdaptiveExecutionEngine for multi-subtask execution
        # This enables parallel execution, smart retries, and learning from outcomes
        # ══════════════════════════════════════════════════════════════════════════
        execution_used = False
        if (
            current_reasoning_context
            and current_reasoning_context.subtasks
            and len(current_reasoning_context.subtasks) >= 2
            and execution_engine is not None
            and enhanced_mode
        ):
            renderer.phase("executing", f"🔄 Executing {len(current_reasoning_context.subtasks)} subtasks with adaptive engine...")

            # Convert subtasks to ExecutionTask objects
            execution_tasks: list[ExecutionTask] = []
            for i, subtask in enumerate(current_reasoning_context.subtasks):
                # P0 FIX: SubTask is a dataclass, extract description for string operations
                # Bug was: 'SubTask' object is not subscriptable - treating SubTask as str
                subtask_desc = subtask.description if hasattr(subtask, 'description') else str(subtask)

                # Create a closure that captures the subtask description and uses send()
                def create_task_command(st: str) -> Callable[[], Any]:
                    def task_command() -> dict[str, Any]:
                        """Execute a subtask via the AI model."""
                        subtask_prompt = _enhance_task_prompt(st)
                        if reasoning_summary:
                            subtask_prompt = (
                                f"{subtask_prompt}\n\n"
                                f"Context from overall task analysis:\n{reasoning_summary[:500]}"
                            )
                        result = send(subtask_prompt)
                        if result:
                            written_files = _process_response(result)
                            return {"success": True, "response": result, "files": written_files}
                        return {"success": False, "response": None, "files": []}
                    return task_command

                task = ExecutionTask(
                    id=f"subtask_{i}_{uuid.uuid4().hex[:8]}",
                    description=subtask_desc,  # P0 FIX: Use extracted description string
                    command=create_task_command(subtask_desc),  # P0 FIX: Pass description string
                    priority=TaskPriority.HIGH if i == 0 else TaskPriority.MEDIUM,
                    dependencies=[execution_tasks[-1].id] if execution_tasks else [],
                    timeout=180.0,
                    retry_config=RetryConfig(
                        max_attempts=2,
                        strategy=RetryStrategy.EXPONENTIAL,
                        initial_delay=1.0,
                    ),
                )
                execution_tasks.append(task)

            # Define progress callback
            def on_progress(task_id: str, status: TaskStatus, message: str) -> None:
                status_emoji = {
                    TaskStatus.PENDING: "⏳",
                    TaskStatus.RUNNING: "🔄",
                    TaskStatus.COMPLETED: "✅",
                    TaskStatus.FAILED: "❌",
                    TaskStatus.SKIPPED: "⏭️",
                }.get(status, "•")
                renderer.info(f"   {status_emoji} {message[:60]}...")

            # Define error callback - returns True to retry with AI fix
            def on_error(task_id: str, error: str) -> bool:
                renderer.warning(f"   Subtask error: {error[:80]}...")
                # Use error diagnosis to decide if retry is worthwhile
                if error_diagnosis:
                    diagnosis = error_diagnosis.diagnose(error)
                    if diagnosis.get("suggested_fixes"):
                        renderer.info(f"   Attempting AI-powered fix...")
                        return True
                return False

            try:
                # Execute the task chain
                results = execution_engine.execute_task_chain(
                    execution_tasks,
                    on_progress=on_progress,
                    on_error=on_error,
                )

                # Collect all written files from successful tasks
                exec_written: list[str] = []
                success_count = 0
                for task_id, result in results.items():
                    if result.success and result.output:
                        if isinstance(result.output, dict) and result.output.get("files"):
                            exec_written.extend(result.output["files"])
                        success_count += 1

                renderer.info(f"   Completed {success_count}/{len(execution_tasks)} subtasks")

                if exec_written:
                    written = list(set(exec_written))  # Deduplicate
                    execution_used = True
                    # Validate and retry if needed
                    _auto_validate_and_retry(written, max_retries)
            except Exception as e:
                renderer.warning(f"Execution engine failed: {e}. Falling back to standard pipeline.")
                execution_used = False

        # For complex tasks on local models, use multi-step decomposition
        # Small models benefit enormously from focused, single-objective prompts
        if execution_used:
            # Already handled by AdaptiveExecutionEngine - skip to validation
            pass
        elif _should_use_multistep_pipeline(
            task_prompt,
            classification=classification,
            is_local_model=is_local,
        ):
            renderer.phase(
                "planning", "Complex task detected — using multi-step pipeline"
            )
            if role_trace:
                renderer.phase(
                    "thinking",
                    "[Coder] Execute model-driven phases and use tools/files as needed",
                )
            written = _execute_multistep(task_prompt, send, classification=classification)
            if written:
                _auto_validate_and_retry(written, max_retries)
            # Fall through to ensure_green below
        else:
            # Standard single-shot path for simple tasks or API models
            expanded = _enhance_task_prompt(task_prompt)

            # Enhance prompt with reasoning/plugin context if available
            if reasoning_summary:
                expanded = (
                    f"{expanded}\n\n"
                    f"## AI Orchestration Context (use this to guide your implementation)\n"
                    f"{reasoning_summary}\n\n"
                    f"Follow the context above. Implement step by step."
                )

            if role_trace:
                renderer.phase(
                    "thinking", "[Coder] Implement changes and propose tool actions"
                )
            response = send(expanded)
            if not response:
                return [], False

            # ══════════════════════════════════════════════════════════════════════════
            # CRITICAL FIX: Enhanced retry loop with multiple attempts and better feedback
            # ══════════════════════════════════════════════════════════════════════════
            max_quality_retries = 3
            quality_attempt = 0

            while quality_attempt < max_quality_retries:
                retry_prompt = _quality_check(response, original_prompt=task_prompt)
                if not retry_prompt:
                    break  # Quality check passed

                quality_attempt += 1
                renderer.phase(
                    "fixing",
                    f"Quality check failed (attempt {quality_attempt}/{max_quality_retries}) — retrying..."
                )

                # Use error diagnosis if we have specific errors
                if error_diagnosis and "error" in retry_prompt.lower():
                    diagnosis = error_diagnosis.diagnose(retry_prompt)
                    if diagnosis.get("suggested_fixes"):
                        fixes = diagnosis["suggested_fixes"][:2]
                        retry_prompt += f"\n\nSuggested fixes:\n" + "\n".join(f"- {f}" for f in fixes)

                # Add context from reasoning if available
                if current_reasoning_context and current_reasoning_context.selected_approach:
                    retry_prompt += (
                        f"\n\nRemember to follow the approach: "
                        f"{current_reasoning_context.selected_approach.approach[:100]}"
                    )

                retry_response = send(retry_prompt)
                if retry_response:
                    response = retry_response
                else:
                    break  # No response, stop retrying

            if quality_attempt == max_quality_retries:
                renderer.warning(
                    f"Quality checks failed after {max_quality_retries} attempts. Proceeding with best response."
                )

            if role_trace:
                renderer.phase(
                    "fixing", "[Reviewer] Validate response quality and edit intent"
                )
            written = _process_response(response)

            has_tools = bool(_extract_tool_commands(response))
            if not written and not has_tools and "FILE:" not in response:
                if _is_readonly_analysis_request(task_prompt):
                    pass
                else:
                    renderer.phase(
                        "fixing", "No code produced — requesting implementation..."
                    )
                    nudge = (
                        "You responded with only text. You MUST write code or use tools. "
                        "Use READ: to examine existing files, then write tests FIRST using "
                        "FILE: blocks (FILE: tests/test_*.py), then write the implementation "
                        "using FILE: blocks, then use RUN: to run the tests. Do it now."
                    )
                    followup = send(nudge)
                    if followup:
                        written = _process_response(followup)

            if written:
                _auto_validate_and_retry(written, max_retries)

        task_ok = True
        if ensure_green:
            if role_trace:
                renderer.phase(
                    "testing",
                    "[Tester/DevOps] Run project validation and iterate until green",
                )
            test_cmd = (
                _validation_command_for_written_files(written or all_written, cwd)
                or final_validation_cmd
                or default_test_cmd
            )
            validation_cmd = test_cmd
            renderer.phase("testing", test_cmd)
            test_cmd, output = _run_validation_command(test_cmd, cwd, timeout=120)
            has_errors = _has_errors(output)

            # CRITICAL: Detect and cleanup broken test files with import errors
            # This prevents the autopilot from getting stuck trying to fix non-existent modules
            if has_errors and (
                "ModuleNotFoundError" in output or "ImportError" in output
            ):
                broken_tests = _detect_broken_test_files(output, cwd)
                if broken_tests:
                    deleted = _cleanup_broken_tests(broken_tests, renderer)
                    if deleted:
                        renderer.info(
                            f"🧹 Cleaned up {len(deleted)} broken test file(s) with invalid imports. "
                            "Re-running validation..."
                        )
                        # Re-run validation after cleanup
                        test_cmd, output = _run_validation_command(
                            test_cmd, cwd, timeout=120
                        )
                        has_errors = _has_errors(output)

            renderer.print_test_results(output, passed=not has_errors)
            validation_status = "passed" if not has_errors else "failed"
            attempts = 0
            while has_errors and attempts < max_retries:
                attempts += 1
                validation_retries = attempts
                fix_prompt = (
                    f"Project validation is failing for `{test_cmd}`. Use the REAL failure output below to fix the code.\n\n"
                    f"```text\n{_summarize_test_output(output)}\n```\n\n"
                    "Rules:\n"
                    "1. Do not invent files, functions, or line numbers.\n"
                    "2. Read real files first using READ: and SEARCH:.\n"
                    "3. Write tests first when adding behavior.\n"
                    "4. Output FILE: blocks with complete file contents.\n"
                    "5. Include RUN: commands for the same validation command.\n"
                )
                fix_response = send(fix_prompt)
                if not fix_response:
                    break
                if role_trace:
                    renderer.phase(
                        "fixing",
                        "[Incident Response] Diagnose failure and apply root-cause fix",
                    )
                fix_written = _process_response(fix_response)
                if fix_written:
                    _auto_validate_and_retry(fix_written, max_retries)
                test_cmd, output = _run_validation_command(test_cmd, cwd, timeout=120)
                has_errors = _has_errors(output)

                # Cleanup broken tests in retry loop too
                if has_errors and (
                    "ModuleNotFoundError" in output or "ImportError" in output
                ):
                    broken_tests = _detect_broken_test_files(output, cwd)
                    if broken_tests:
                        deleted = _cleanup_broken_tests(broken_tests, renderer)
                        if deleted:
                            test_cmd, output = _run_validation_command(
                                test_cmd, cwd, timeout=120
                            )
                            has_errors = _has_errors(output)

                renderer.print_test_results(output, passed=not has_errors)
                validation_status = "passed" if not has_errors else "failed"
            if has_errors:
                renderer.warning(
                    "Autopolit could not get the full test suite green in this cycle."
                )
                task_ok = False
        if role_trace:
            changed = ", ".join(written[:3]) if written else "none"
            renderer.info(
                "[Cycle Summary] "
                f"changed={changed} | validation={validation_status} | "
                f"cmd={validation_cmd or 'n/a'} | retries={validation_retries}"
            )

        # ══════════════════════════════════════════════════════════════════════════
        # CRITICAL FIX: Self-reflection after task completion to learn and improve
        # ══════════════════════════════════════════════════════════════════════════
        if written and reflection_engine is not None and enhanced_mode:
            try:
                renderer.phase("reflecting", "🔍 Self-reflection on completed work...")
                test_files = [f for f in written if "test" in f.lower()]
                code_files = [f for f in written if "test" not in f.lower()]
                errors_seen = []

                # Add any errors from validation
                if not task_ok:
                    errors_seen.append(f"Validation failed: {validation_status}")

                reflection_result = reflection_engine.reflect(
                    task=task_prompt,
                    code_files=code_files,
                    test_files=test_files,
                    errors=errors_seen,
                )

                if reflection_engine.needs_improvement(reflection_result):
                    issues = reflection_result.get('issues', [])
                    fixes = reflection_result.get('fixes_needed', [])
                    if issues:
                        renderer.warning(f"   Self-reflection found {len(issues)} potential issue(s)")
                    if fixes:
                        renderer.info(f"   Suggested fixes: {', '.join(fixes[:2])}")

                    # Track learning in context
                    if current_reasoning_context:
                        current_reasoning_context.learnings.extend(issues)
                else:
                    renderer.success("   Self-reflection: Code quality looks good")
            except Exception as e:
                renderer.warning(f"Reflection phase skipped: {e}")

        return written, task_ok

    def _build_autopolit_prompt(
        cycle: int,
        last_summary: str,
        no_change_streak: int = 0,
        previous_changed_files: list[str] | None = None,
        repeat_task_streak: int = 0,
    ) -> str:
        priority_block = ""
        if autopolit_priority_hints:
            priority_block = (
                "## WHOLE-CODEBASE PRIORITY SIGNALS\n"
                + "\n".join(f"- {hint}" for hint in autopolit_priority_hints)
                + "\n\n"
            )
        # Collect existing modules for the prompt using FileDiscovery (P0-4, P0-5)
        try:
            file_discovery = FileDiscovery(cwd)
            all_modules = file_discovery.discover_modules()
            discovered_modules = sorted(all_modules)[:30]  # Limit for prompt size
        except Exception:
            discovered_modules = []

        modules_block = ""
        if discovered_modules:
            modules_block = (
                "## DISCOVERED MODULES (Auto-scanned - these ACTUALLY exist)\n"
                f"{', '.join(discovered_modules)}\n\n"
                "ONLY import from the modules listed above. Any import from a module NOT in this list will be REJECTED.\n\n"
            )

        prompt = (
            f"Autopolit cycle {cycle}. Run an autonomous quality pass on the CURRENT codebase.\n\n"
            "You are auditing the WHOLE codebase, not just a single file.\n"
            "Pick the highest-severity real issue first. Do NOT spend cycles on cosmetic cleanup while higher-impact work exists.\n\n"
            f"{priority_block}"
            f"{modules_block}"
            "## PRE-FLIGHT CHECK (MANDATORY BEFORE ANY CODE)\n"
            f"Run the validation command to see current test status:\n"
            "```\n"
            f"RUN: {full_project_test_cmd}\n"
            "```\n"
            "Only write code for modules that ACTUALLY EXIST in the DISCOVERED MODULES list above.\n\n"
            "## MODULE VERIFICATION (ZERO TOLERANCE)\n"
            "Before importing ANY module in your code:\n"
            "1. Check if it's in the DISCOVERED MODULES list above\n"
            "2. If NOT in the list, that module DOES NOT EXIST - do NOT import it\n"
            "3. NEVER import from modules not in the discovered list\n"
            "4. NEVER create tests that import from non-existent modules\n"
            "5. If you write code that imports a non-existent module, it WILL BE REJECTED\n\n"
            "## IMPORT ERROR HANDLING (CRITICAL)\n"
            "When you see ImportError or ModuleNotFoundError in test output:\n"
            "1. READ the failing test and verify whether the imported module is in the discovered list\n"
            "2. Fix the root cause first (missing file, bad import, bad package path, broken test generation)\n"
            "3. Only delete a test if it is clearly junk or orphaned and you can justify that from repo evidence\n\n"
            "## SMART EXECUTION WORKFLOW\n"
            f"1. Pre-flight: RUN: {full_project_test_cmd}\n"
            "2. Analyze REAL error messages from actual test output\n"
            "3. READ: files mentioned in errors and the highest-risk supporting files\n"
            "4. Choose work by severity: failing validation, deployment/security risk, CI gaps, core-agent reliability, then maintainability\n"
            "5. Only write tests for modules in the DISCOVERED MODULES list above\n"
            "6. Re-run the full validation command to verify fixes work\n\n"
            "## PRIORITY ORDER\n"
            "- P0: Restore red validation, test collection, build, or deploy blockers\n"
            "- P1: Fix security, CI, or release-safety issues on real code paths\n"
            "- P2: Fix highest-blast-radius reliability issues in the core agent\n"
            "- P3: Add tests for real gaps once the suite is green\n"
            "- P4: Refactors and cosmetic improvements only when higher tiers are clear\n\n"
            "## HARD RULES\n"
            "- ONLY import from modules in the DISCOVERED MODULES list\n"
            "- READ: any file before editing it\n"
            "- Explain to yourself why the chosen task outranks the alternatives\n"
            "- Do not choose docs-only, naming-only, or cosmetic changes while any P0-P2 issue exists\n"
            "- Never invent files, functions, or module names\n"
            "- Use FILE: blocks for all code changes\n"
            "- Never claim success while tests are failing\n"
            "- NEVER write placeholder code (pass, TODO, stub functions)\n"
            "- NEVER write tests without real assertions\n"
            "- ALWAYS use RUN: commands to investigate errors before fixing\n\n"
            "## CLI INVESTIGATION (MANDATORY)\n"
            "Before writing ANY fix, you MUST investigate using CLI commands:\n"
            "```\n"
            "RUN: pytest tests/failing_test.py -v --tb=long  # Get full error details\n"
            "RUN: python -c \"from module import x\"  # Test imports\n"
            "RUN: grep -r \"function_name\" sage/  # Find function definitions\n"
            "```\n"
            "NEVER guess what the problem is - ALWAYS investigate first!\n\n"
            "## PRODUCTION-READY CODE ONLY\n"
            "Every line of code you write MUST be:\n"
            "- Functional and complete (no stubs)\n"
            "- Tested with real assertions\n"
            "- Verified by running tests\n"
            "Placeholder code will be AUTOMATICALLY REJECTED.\n\n"
            "## FILE BLOCK FORMAT (EXACT FORMAT REQUIRED)\n"
            "Write files using EXACTLY this format:\n\n"
            "FILE: path/to/file.py\n"
            "```python\n"
            "# Complete code here - NO placeholders, NO ellipsis\n"
            "def real_function():\n"
            "    return 'actual implementation'\n"
            "```\n\n"
            "EXAMPLE TEST FILE:\n"
            "FILE: tests/test_example.py\n"
            "```python\n"
            "import pytest\n"
            "from sage.config import load_config  # Import from EXISTING module\n\n"
            "def test_load_config_returns_dict():\n"
            "    result = load_config()\n"
            "    assert isinstance(result, dict)  # MUST have assertions\n"
            "```\n"
        )
        if no_change_streak >= 1:
            prompt += (
                "\nAdditional directive:\n"
                "- Last cycle made no code changes. Pick a NEW high-impact, concrete improvement task.\n"
                "- You MUST produce at least one real FILE: change and re-validate tests.\n"
            )
        if previous_changed_files:
            preview = ", ".join(previous_changed_files[:5])
            prompt += (
                "\nAnti-repetition directive:\n"
                f"- Previous cycle touched files: {preview}\n"
                "- For this cycle, choose a different subsystem/file set unless those files are currently failing tests.\n"
            )
        if repeat_task_streak >= 1:
            prompt += "- You repeated a similar task recently. Hard-pivot to a different module, class, or workflow.\n"
        if last_summary:
            prompt += f"\nPrevious cycle summary:\n{last_summary}\n"
        return prompt

    # ══════════════════════════════════════════════════════════════════════════
    # INTELLIGENT AUTOPILOT v2.0 - Self-improving autonomous coding agent
    # ══════════════════════════════════════════════════════════════════════════

    # Initialize the intelligent systems
    exec_engine = IntelligentExecutionEngine(cwd, renderer)
    quality_gate = QualityGate(cwd, renderer)
    incremental_validator = IncrementalValidator(cwd, renderer, full_project_test_cmd)
    model_router = FreeModelRouter(renderer)
    self_healer = SelfHealingSystem(cwd, renderer, exec_engine)
    task_prioritizer = TaskPrioritizer()  # P0-6/P0-7: Task prioritization
    file_discovery = FileDiscovery(cwd)  # P0-4: File discovery tool

    def _intelligent_pre_flight() -> dict:
        """Run intelligent pre-flight checks before starting autopilot."""
        renderer.phase("discovery", "🔍 Running intelligent pre-flight checks...")

        analysis = exec_engine.analyze_codebase()
        priority_hints = _collect_autopolit_priority_hints(cwd)

        # Display analysis
        renderer.info(f"📊 Codebase Analysis:")
        renderer.info(
            f"   Files: {analysis['total_files']} ({analysis['total_lines']} lines)"
        )
        renderer.info(f"   Languages: {dict(analysis['languages'])}")
        renderer.info(
            f"   Test framework: {analysis['test_framework'] or 'Not detected'}"
        )
        renderer.info(f"   Has tests: {'Yes' if analysis['has_tests'] else 'No'}")
        for hint in priority_hints:
            renderer.info(f"   Priority: {hint}")

        # Run initial validation
        renderer.phase(
            "validation", f"🧪 Running baseline validation: {full_project_test_cmd}"
        )
        ok, result = incremental_validator.full_validation()
        if ok:
            renderer.success("✅ Baseline: All tests passing")
        else:
            renderer.warning(f"⚠️ Baseline: Tests failing\n{result[:200]}")

        return {
            "analysis": analysis,
            "priority_hints": priority_hints,
            "baseline_ok": ok,
            "baseline_result": result,
        }

    def _intelligent_cycle(
        cycle: int,
        pre_flight: dict,
        last_result: dict,
        send_fn: Callable,
    ) -> dict:
        """Run one intelligent autopilot cycle."""

        result = {
            "written": [],
            "success": False,
            "errors": [],
            "learned": False,
            "recovery_attempted": False,
        }

        # Phase 1: Planning
        renderer.phase("planning", f"📋 Cycle {cycle}: Creating intelligent plan...")

        # Determine what to work on based on current state using TaskPrioritizer (P0-6/P0-7)
        baseline_ok = last_result.get("baseline_ok", True)
        baseline_result = last_result.get("baseline_result", "")

        if not baseline_ok and baseline_result:
            # Tests are failing - use TaskPrioritizer to determine priority
            prioritized_tasks = task_prioritizer.prioritize_tasks(
                [baseline_result],
                baseline_green=False,
            )
            if prioritized_tasks:
                top_task = prioritized_tasks[0]
                goal = f"Fix {top_task.category.name}: {top_task.description[:80]}"
                task_prioritizer.record_failure(baseline_result)
            else:
                goal = "Fix failing tests and get the test suite passing"
        elif last_result.get("errors"):
            # We had errors last cycle - try to fix them
            goal = f"Fix previous errors: {last_result['errors'][0][:100]}"
        else:
            # All green - check if improvements are allowed (P0-7: block cleanup while red)
            priority_hints = pre_flight.get("priority_hints") or []
            if priority_hints:
                goal = (
                    f"Address the highest-priority codebase issue: {priority_hints[0]}"
                )
            else:
                goal = "Address the highest-impact reliability, security, or CI issue in the codebase"

        plan = exec_engine.create_plan(goal)
        renderer.info(
            f"   Plan: {len(plan.tasks)} tasks, complexity: {exec_engine.estimate_total_complexity(plan)}"
        )

        # Phase 2: Execute each task
        for task in plan.tasks:
            if task.status == "completed":
                continue

            renderer.phase("executing", f"⚡ Task: {task.description[:50]}...")
            task.status = "running"

            # Build focused prompt for this task
            task_prompt = _build_task_prompt(task, pre_flight["analysis"])

            # Execute
            response = send_fn(task_prompt)
            if not response:
                task.status = "failed"
                task.error = "No response from model"
                result["errors"].append(task.error)
                continue

            # Process response
            written = _process_response(response)
            result["written"].extend(written)

            # Validate incrementally
            if written:
                for fp in written:
                    # Run quality gate
                    content = (cwd / fp).read_text() if (cwd / fp).exists() else ""
                    passed, issues = quality_gate.run_all_gates(fp, content)
                    if not passed:
                        task.status = "failed"
                        task.error = f"Quality gate failed: {'; '.join(issues)}"
                        result["errors"].append(task.error)

                        # Attempt self-healing
                        if self_healer.can_recover(task.error):
                            result["recovery_attempted"] = True
                            recovered, fix = self_healer.attempt_recovery(
                                task.error, written
                            )
                            if recovered:
                                renderer.success(f"🔧 Auto-recovery: {fix}")
                                task.status = "completed"
                                exec_engine.learn_from_success(task.error, fix)
                                result["learned"] = True
                            else:
                                renderer.warning(f"💡 Recovery hint: {fix}")
                        continue

                # Incremental validation
                ok, msg = incremental_validator.validate_unit(written)
                if ok:
                    task.status = "completed"
                    renderer.success(f"✅ Validated: {', '.join(written[:3])}")
                else:
                    task.status = "failed"
                    task.error = msg
                    result["errors"].append(msg)

                    # Learn from failure
                    exec_engine.learn_from_failure(msg)
            else:
                # No files written - might be analysis or explanation
                task.status = "completed"

        # Phase 3: Final validation
        renderer.phase("verification", "🔍 Final verification...")
        ok, msg = incremental_validator.full_validation()
        result["success"] = ok

        if ok:
            renderer.success("✅ All validations passed!")
            # Learn from success
            if result["errors"]:
                for error in result["errors"]:
                    exec_engine.learn_from_success(
                        error, "Auto-recovered during execution"
                    )
        else:
            renderer.warning(f"⚠️ Validation failed: {msg[:200]}")
            result["errors"].append(msg)

        # Calculate completion
        completion = exec_engine.get_completion_percentage(plan)
        renderer.info(f"📊 Cycle complete: {completion:.0f}% of tasks completed")

        return result

    def _build_task_prompt(task: PlanTask, analysis: dict) -> str:
        """Build a focused prompt for a specific task.

        Enhanced with:
        - Explicit FILE block format with working examples
        - Pre-write verification checklist
        - Import validation requirements
        - Anti-hallucination safeguards
        """
        # Get existing modules for context
        # Get existing modules using FileDiscovery (P0-4, P0-5)
        try:
            file_discovery = FileDiscovery(cwd)
            all_modules = file_discovery.discover_modules()
            existing_modules = sorted(
                [m for m in all_modules if not m.startswith("test_")]
            )[:15]
        except Exception:
            existing_modules = []

        # Build module list for prompt
        modules_str = (
            ", ".join(existing_modules)
            if existing_modules
            else "Unknown - check before importing"
        )

        prompt = f"""Execute this specific task: {task.description}

## Context
- Task ID: {task.id}
- Priority: {task.priority.name}
- Estimated complexity: {task.estimated_complexity}/5

## Codebase Info
- Languages: {dict(analysis.get('languages', {}))}
- Test framework: {analysis.get('test_framework', 'pytest')}
- Has existing tests: {analysis.get('has_tests', False)}

## AVAILABLE MODULES (Auto-discovered - ONLY import from these)
{modules_str}

## PRE-EXECUTION CHECKLIST (MANDATORY)
Before writing ANY code:
1. ✅ CHECK the AVAILABLE MODULES list above
2. ✅ READ: any file you plan to modify
3. ✅ ONLY import from modules in the AVAILABLE MODULES list
4. ✅ Never invent/hallucinate module names

## FILE BLOCK FORMAT (CRITICAL)
You MUST write files using EXACTLY this format:

```
FILE: path/to/file.py
```python
# Your complete code here
def real_function():
    return "actual implementation"
```
```

EXAMPLE - Writing a test file:
```
FILE: tests/test_example.py
```python
import pytest
from existing_module import actual_function  # Must exist!

def test_actual_function():
    result = actual_function()
    assert result is not None  # MUST have assertions
    assert isinstance(result, str)
```
```

EXAMPLE - Writing an implementation:
```
FILE: utils/helpers.py
```python
def helper_function(data: list) -> int:
    \"\"\"Process data and return count.\"\"\"
    if not data:
        return 0
    return len([x for x in data if x])
```
```

## CRITICAL RULES
1. FILE: must be on its own line, immediately followed by path
2. Path must be on the SAME LINE as FILE:
3. Code block must start on the NEXT line with triple backticks
4. NO ellipsis (...), NO "# rest of code", NO placeholders
5. Write COMPLETE, WORKING code that passes syntax check
6. Tests MUST have assert statements

## FORBIDDEN PATTERNS (Will be IMMEDIATELY REJECTED)
These patterns are auto-detected and your code WILL NOT be written:

HALLUCINATED IMPORTS (these modules DO NOT EXIST):
- `from sage.api import ...` - REJECTED
- `from utils.api import ...` - REJECTED
- `from services import ...` - REJECTED
- `from models import ...` - REJECTED
- `from schemas import ...` - REJECTED
- `from app.* import ...` - REJECTED unless verified
- `from backend.* import ...` - REJECTED unless verified
- `from ai_platform import ...` - REJECTED unless verified

OTHER FORBIDDEN PATTERNS:
- `def test_foo(): pass` (no assertions) - REJECTED
- `# TODO: implement` - REJECTED
- `# Placeholder` - REJECTED
- `...` (truncated code) - REJECTED
- Code that imports ANY module not in the AVAILABLE MODULES list - REJECTED

## WHAT TO DO INSTEAD
1. CHECK the AVAILABLE MODULES list above for what exists
2. Only import from modules in that list
3. If you need a utility function, write it yourself - don't import from fake modules
4. Test files should import from the ACTUAL sage package or standard library

## OUTPUT FORMAT
1. CHECK the AVAILABLE MODULES list (already provided above)
2. Run READ: on files you'll modify
3. Write FILE: blocks with complete code that imports ONLY from available modules
4. Run RUN: {analysis.get('test_framework', 'pytest')} to validate

IMPORTANT: If you import from modules not in the AVAILABLE MODULES list,
your code WILL BE REJECTED and you will waste a cycle.

Now execute this task. CHECK AVAILABLE MODULES before importing."""
        return prompt

    # ══════════════════════════════════════════════════════════════════════════════
    # STREAMLINED PROCEDURAL WORKFLOW - 15-step AI coding workflow with minimal noise
    # ══════════════════════════════════════════════════════════════════════════════

    def _run_procedural_workflow(
        task: str,
        verbose: bool = False,
        show_plan: bool = True,
        show_code_changes: bool = True,
    ) -> WorkflowResult | None:
        """
        Run the 15-step procedural workflow for a coding task.

        This is a streamlined, less noisy alternative to the full autopolit mode.
        It shows the AI's plan and code changes without excessive output.

        Steps:
        1. Input Normalization
        2. Intent Decomposition
        3. Brainstorming
        4. Planning
        5. Spec-to-Test (TDD)
        6. Code Generation
        7. Execution Loop
        8. Self-Review
        9. Refactor Loop
        10. Integration Validation
        11. Git Workflow
        12. CI/CD Pipeline
        13. Post-Evaluation
        14. Memory Update
        15. Human-in-the-Loop

        Args:
            task: The coding task to execute
            verbose: Show detailed output (default: minimal noise)
            show_plan: Display AI's execution plan
            show_code_changes: Display code changes as they happen

        Returns:
            WorkflowResult with all step results, or None on failure
        """
        # Create a workflow-specific send function
        def workflow_send(prompt: str) -> dict:
            """Send function for the procedural workflow."""
            messages = engine.build_messages()
            messages.append(Message(role="user", content=prompt))
            try:
                response = router.generate(messages, model_id, temp, min(tokens, 2048))
                # Try to parse as JSON
                try:
                    import json
                    return json.loads(response)
                except (json.JSONDecodeError, TypeError):
                    return {"raw": response}
            except Exception as e:
                return {"error": str(e)}

        # Initialize the workflow orchestrator
        workflow = ProceduralWorkflowOrchestrator(send=workflow_send)

        # Progress callback for minimal noise output
        def on_progress(step: int, status: str):
            step_name = workflow.STEP_NAMES.get(step, f"Step {step}")
            if status == "started":
                if verbose:
                    renderer.phase("workflow", f"▶ {step_name}")
                else:
                    # Minimal output - just show step number
                    renderer.console.print(f"[dim]  Step {step}/15: {step_name}[/dim]")
            elif status == "completed" and verbose:
                renderer.success(f"  ✓ {step_name} completed")

        # Show header
        renderer.console.print()
        renderer.console.print("[bold cyan]═══ SAGE Procedural Workflow ═══[/bold cyan]")
        renderer.console.print(f"[dim]Task: {task[:80]}{'...' if len(task) > 80 else ''}[/dim]")
        renderer.console.print()

        # Determine verbosity level
        verbosity = "verbose" if verbose else ("plan" if show_plan else "minimal")

        try:
            result = workflow.execute(
                task=task,
                on_progress=on_progress,
                verbosity=verbosity,
                show_code_changes=show_code_changes,
            )

            # Show plan if requested
            if show_plan and result.plan:
                renderer.console.print()
                renderer.console.print("[bold]📋 Execution Plan:[/bold]")
                for step in result.plan.steps:
                    file_info = f" ({step.file})" if step.file else ""
                    renderer.console.print(f"   {step.step_number}. {step.action}{file_info}")
                renderer.console.print()

            # Show code changes if requested
            if show_code_changes and result.code and result.code.code_changes:
                renderer.console.print("[bold]📝 Code Changes:[/bold]")
                for change in result.code.code_changes:
                    action_icon = {"create": "➕", "modify": "✏️", "delete": "🗑️"}.get(
                        change.action, "📄"
                    )
                    renderer.console.print(f"   {action_icon} {change.file}")
                    if verbose and change.content:
                        # Show first few lines
                        lines = change.content.split("\n")[:5]
                        for line in lines:
                            renderer.console.print(f"      [dim]{line}[/dim]")
                        if len(change.content.split("\n")) > 5:
                            renderer.console.print(f"      [dim]... ({len(change.content.split(chr(10)))} total lines)[/dim]")
                renderer.console.print()

            # Show summary
            renderer.console.print()
            if result.completed:
                renderer.console.print("[bold green]✓ Workflow completed successfully[/bold green]")
            else:
                renderer.console.print(
                    f"[bold yellow]⚠ Workflow stopped at step {result.current_step}[/bold yellow]"
                )

            if result.evaluation:
                if result.evaluation.task_completed:
                    renderer.console.print(
                        f"[green]  Task completion confidence: {result.evaluation.confidence:.0%}[/green]"
                    )
                if result.evaluation.follow_up_tasks:
                    renderer.console.print("[dim]  Suggested follow-ups:[/dim]")
                    for task in result.evaluation.follow_up_tasks[:3]:
                        renderer.console.print(f"[dim]    • {task}[/dim]")

            if result.human_review and result.human_review.requires_approval:
                renderer.console.print()
                renderer.console.print("[bold yellow]⚠ Human review recommended:[/bold yellow]")
                for point in result.human_review.approval_points[:3]:
                    renderer.console.print(f"   • {point}")

            renderer.console.print()
            return result

        except KeyboardInterrupt:
            renderer.warning("Workflow interrupted by user")
            return None
        except Exception as e:
            renderer.error(f"Workflow error: {e}")
            return None

    # ══════════════════════════════════════════════════════════════════════════════
    # PHD-LEVEL AI AGENT - Multi-loop architecture with minimal noise output
    # ══════════════════════════════════════════════════════════════════════════════

    def _run_phd_agent(task: str, minimal_noise: bool = True) -> AgentResult | None:
        """
        Run the PhD-level AI agent with multi-loop architecture.

        Features:
        - Strategic Loop: Spec reconstruction, problem modeling, solution exploration, meta-planning
        - Execution Loop: Test generation, incremental coding, adaptive debugging, validation
        - Learning Loop: Pattern storage, heuristic updates, continuous improvement

        Args:
            task: The coding task to execute
            minimal_noise: Show minimal output (default: True)

        Returns:
            AgentResult with completion status and generated code, or None on failure
        """
        # Create agent-specific send function
        def agent_send(prompt: str) -> dict:
            """Send function for the PhD agent."""
            messages = engine.build_messages()
            messages.append(Message(role="user", content=prompt))
            try:
                response = router.generate(messages, model_id, temp, min(tokens, 2048))
                try:
                    import json
                    return json.loads(response)
                except (json.JSONDecodeError, TypeError):
                    return {"raw": response}
            except Exception as e:
                return {"error": str(e)}

        # Initialize PhD agent
        agent = PhDAgent(send=agent_send)
        ui = PhDAgentUI(minimal_noise=minimal_noise)

        # Show header
        renderer.console.print()
        renderer.console.print("[bold magenta]═══ PhD-Level AI Agent ═══[/bold magenta]")
        renderer.console.print(f"[dim]Task: {task[:80]}{'...' if len(task) > 80 else ''}[/dim]")
        renderer.console.print()

        try:
            # Strategic Loop
            renderer.console.print("[bold]Strategic Loop[/bold]")
            todos = [
                {"name": "Spec Reconstruction", "status": "in_progress"},
                {"name": "Problem Modeling", "status": "pending"},
                {"name": "Solution Exploration", "status": "pending"},
                {"name": "Meta-Planning", "status": "pending"},
            ]
            if not minimal_noise:
                renderer.console.print(ui.format_todos(todos))

            strategic = agent.strategic_loop(task)

            # Update todos
            todos[0]["status"] = "completed"
            todos[1]["status"] = "completed"
            todos[2]["status"] = "completed"
            todos[3]["status"] = "completed"

            if not minimal_noise:
                renderer.console.print(ui.format_todos(todos))
            else:
                renderer.console.print("[dim]  ✓ Strategic analysis complete[/dim]")

            # Show spec if reconstructed
            if strategic.spec and not minimal_noise:
                renderer.console.print()
                renderer.console.print("[bold]📋 Reconstructed Specification:[/bold]")
                renderer.console.print(f"   Goal: {strategic.spec.goal}")
                if strategic.spec.constraints:
                    renderer.console.print(f"   Constraints: {', '.join(strategic.spec.constraints[:3])}")
                if strategic.spec.uncertainty_score > 0.5:
                    renderer.console.print(f"   [yellow]⚠ Uncertainty: {strategic.spec.uncertainty_score:.0%}[/yellow]")

            # Show plan if available
            if strategic.plan and strategic.plan.primary:
                renderer.console.print()
                renderer.console.print("[bold]📋 Execution Plan:[/bold]")
                for step in strategic.plan.primary.steps[:5]:
                    checkpoint = " [checkpoint]" if step.is_verification_checkpoint else ""
                    renderer.console.print(f"   {step.order}. {step.action}{checkpoint}")
                if len(strategic.plan.primary.steps) > 5:
                    renderer.console.print(f"   ... and {len(strategic.plan.primary.steps) - 5} more steps")

            # Execution Loop
            renderer.console.print()
            renderer.console.print("[bold]Execution Loop[/bold]")
            execution_todos = [
                {"name": "Generate Tests", "status": "in_progress"},
                {"name": "Implement Code", "status": "pending"},
                {"name": "Run Validation", "status": "pending"},
            ]
            if not minimal_noise:
                renderer.console.print(ui.format_todos(execution_todos))

            execution = agent.execution_loop(task, strategic.plan)

            execution_todos[0]["status"] = "completed"
            execution_todos[1]["status"] = "completed"
            execution_todos[2]["status"] = "completed"

            if not minimal_noise:
                renderer.console.print(ui.format_todos(execution_todos))
            else:
                renderer.console.print("[dim]  ✓ Execution complete[/dim]")

            # Show generated code if any
            if execution.code and not minimal_noise:
                renderer.console.print()
                renderer.console.print("[bold]📝 Generated Code:[/bold]")
                lines = execution.code.split("\n")[:10]
                for line in lines:
                    renderer.console.print(f"   [dim]{line}[/dim]")
                if len(execution.code.split("\n")) > 10:
                    renderer.console.print(f"   [dim]... ({len(execution.code.split(chr(10)))} total lines)[/dim]")

            # Learning Loop
            renderer.console.print()
            renderer.console.print("[bold]Learning Loop[/bold]")
            if not minimal_noise:
                renderer.console.print(f"   Patterns learned: {agent.learning_loop.total_experiences}")
            else:
                renderer.console.print("[dim]  ✓ Learning recorded[/dim]")

            # Final result
            result = AgentResult(
                completed=True,
                success=execution.validated,
                code=execution.code,
                summary=f"Completed: {task}",
            )

            # Show summary
            renderer.console.print()
            if result.success:
                renderer.console.print("[bold green]✓ PhD Agent completed successfully[/bold green]")
            else:
                renderer.console.print("[bold yellow]⚠ PhD Agent completed with issues[/bold yellow]")

            renderer.console.print()
            return result

        except KeyboardInterrupt:
            renderer.warning("PhD Agent interrupted by user")
            return None
        except Exception as e:
            renderer.error(f"PhD Agent error: {e}")
            return None

    def _run_intelligent_autopolit(max_cycles: int | None = None) -> None:
        """
        Intelligent autopilot v2.0 - The brain of SAGE.

        Key improvements over v1:
        1. Intelligent pre-flight analysis
        2. Task decomposition and planning
        3. Incremental validation after each change
        4. Self-healing error recovery
        5. Learning from successes and failures
        6. Quality gates before accepting code
        """
        cancel_now = False
        cycle = 0
        # CRITICAL: Only install signal handlers on the main thread to avoid crashes
        original_sigint = None
        _on_main_thread = _is_main_thread()

        def _handle_sigint(signum, frame):
            nonlocal cancel_now
            cancel_now = True
            raise KeyboardInterrupt

        # Only install signal handler if we're on the main thread
        if _on_main_thread:
            original_sigint = signal.getsignal(signal.SIGINT)
            signal.signal(signal.SIGINT, _handle_sigint)
        stop_file = _autopolit_stop_path(cwd)
        if stop_file.exists():
            stop_file.unlink(missing_ok=True)

        renderer.info("🚀 Intelligent Autopilot v2.0 started")
        renderer.info(
            "   Press Ctrl+C to stop | touch .sage/autopolit.stop to stop remotely"
        )

        try:
            # Pre-flight checks
            pre_flight = _intelligent_pre_flight()

            last_result: dict = {
                "baseline_ok": pre_flight["baseline_ok"],
                "errors": (
                    [pre_flight["baseline_result"]]
                    if not pre_flight["baseline_ok"]
                    else []
                ),
            }

            consecutive_failures = 0
            total_files_written = 0
            total_errors_fixed = 0

            while True:
                if stop_file.exists():
                    renderer.warning("Stop file detected. Exiting.")
                    stop_file.unlink(missing_ok=True)
                    break
                if cancel_now:
                    renderer.warning("Cancelled by user.")
                    break
                if max_cycles and cycle >= max_cycles:
                    renderer.success(f"Completed {max_cycles} cycles.")
                    break

                cycle += 1
                renderer.info(f"\n{'='*60}")
                renderer.info(f"🔄 INTELLIGENT CYCLE {cycle}")
                renderer.info(f"{'='*60}")

                try:
                    result = _intelligent_cycle(
                        cycle, pre_flight, last_result, _send_to_model_autopolit
                    )

                    total_files_written += len(result["written"])

                    if result["success"]:
                        consecutive_failures = 0
                        if result["learned"]:
                            total_errors_fixed += 1
                            renderer.info(
                                f"🧠 Learned from error recovery (total: {total_errors_fixed})"
                            )
                    else:
                        consecutive_failures += 1

                    last_result = result

                    # Safety: Stop after too many consecutive failures
                    if consecutive_failures >= 5:
                        renderer.error(
                            f"⚠️ {consecutive_failures} consecutive failures. "
                            "Stopping to prevent infinite loop."
                        )
                        # Save learning state
                        exec_engine._save_learning_db()
                        break

                    # Safety: Stop if we're not making progress
                    if cycle > 3 and total_files_written == 0:
                        renderer.warning(
                            "No files written in multiple cycles. "
                            "Consider providing a specific task."
                        )
                        break

                except Exception as e:
                    renderer.error(f"Cycle error: {e}")
                    consecutive_failures += 1
                    if consecutive_failures >= 3:
                        break

                # Brief pause between cycles
                time.sleep(0.5)

        except KeyboardInterrupt:
            renderer.warning("Interrupted by user.")
        finally:
            # Restore the original signal handler (only if we installed one)
            if _on_main_thread and original_sigint is not None:
                signal.signal(signal.SIGINT, original_sigint)
            exec_engine._save_learning_db()

            # Summary
            renderer.info(f"\n{'='*60}")
            renderer.info("📊 AUTOPILOT SUMMARY")
            renderer.info(f"{'='*60}")
            renderer.info(f"   Cycles completed: {cycle}")
            renderer.info(f"   Files written: {total_files_written}")
            renderer.info(f"   Errors auto-fixed: {total_errors_fixed}")
            renderer.info(f"   Learning entries: {len(exec_engine.learning_db)}")

    def _run_autopolit(max_cycles: int | None = None) -> None:
        """Endless autonomous loop (stoppable with Ctrl+C)."""
        cancel_now = False
        sigint_count = 0
        cycle = 0
        consecutive_failures = 0
        no_change_streak = 0
        repeat_task_streak = 0
        previous_changed_files: list[str] = []
        last_summary = ""
        # CRITICAL: Only install signal handlers on the main thread to avoid crashes
        original_sigint = None
        _on_main_thread = _is_main_thread()

        def _reset_engine_context() -> None:
            engine.clear()
            for m in messages_init:
                if m["role"] == "user":
                    engine.add_user(m["content"])
                else:
                    engine.add_assistant(m["content"])

        def _handle_sigint(signum, frame):
            nonlocal cancel_now, sigint_count
            sigint_count += 1
            cancel_now = True
            raise KeyboardInterrupt

        # Only install signal handler if we're on the main thread
        if _on_main_thread:
            original_sigint = signal.getsignal(signal.SIGINT)
            signal.signal(signal.SIGINT, _handle_sigint)
        stop_file = _autopolit_stop_path(cwd)
        if stop_file.exists():
            stop_file.unlink(missing_ok=True)
        renderer.info(
            "Autopolit started. Ctrl+C = immediate cancel. "
            "You can also stop from another terminal: touch .sage/autopolit.stop"
        )

        try:
            while True:
                if stop_file.exists():
                    renderer.warning("Autopolit stop file detected. Exiting loop.")
                    stop_file.unlink(missing_ok=True)
                    break
                if cancel_now:
                    renderer.warning("Autopolit cancelled immediately.")
                    break
                if max_cycles is not None and cycle >= max_cycles:
                    renderer.success(f"Autopolit reached max cycles: {max_cycles}")
                    break

                next_cycle = cycle + 1
                auto_prompt = _build_autopolit_prompt(
                    next_cycle,
                    last_summary,
                    no_change_streak=no_change_streak,
                    previous_changed_files=previous_changed_files,
                    repeat_task_streak=repeat_task_streak,
                )
                renderer.phase("planning", f"Autopolit task #{next_cycle}")
                written, task_ok = _execute_task_prompt(
                    auto_prompt,
                    save_history=True,
                    sender=_send_to_model_autopolit,
                    ensure_green=True,
                    final_validation_cmd=full_project_test_cmd,
                    role_trace=True,
                )
                if not task_ok:
                    consecutive_failures += 1
                    if consecutive_failures >= 8:
                        renderer.error(
                            "Autopolit hit repeated provider failures and is stopping to prevent an error loop."
                        )
                        break
                    if consecutive_failures >= 4:
                        renderer.warning(
                            "Autopolit saw repeated failures. Resetting context and continuing..."
                        )
                        _reset_engine_context()
                    time.sleep(0.1)
                    continue
                consecutive_failures = 0
                cycle = next_cycle
                current_changed_files = sorted(set(written))
                if current_changed_files and previous_changed_files:
                    if set(current_changed_files) == set(previous_changed_files):
                        repeat_task_streak += 1
                    else:
                        repeat_task_streak = 0
                elif current_changed_files:
                    repeat_task_streak = 0
                if current_changed_files:
                    previous_changed_files = current_changed_files
                    no_change_streak = 0
                else:
                    no_change_streak += 1

                # ── Loop detection break-out ──────────────────────
                if repeat_task_streak >= 3:
                    renderer.warning(
                        f"Autopolit stuck: same files touched {repeat_task_streak} cycles in a row. "
                        "Breaking out to avoid infinite loop."
                    )
                    # Flag suspicious test files before stopping, but never delete them automatically.
                    flagged = _cleanup_broken_test_files(cwd, last_summary)
                    if flagged:
                        renderer.info(
                            f"Flagged broken tests for review: {', '.join(flagged)}"
                        )
                    break

                if no_change_streak >= 4:
                    renderer.warning(
                        f"Autopolit stuck: {no_change_streak} consecutive cycles with no file changes. "
                        "Breaking out - consider running with a specific task."
                    )
                    break

                changed = ", ".join(written[:5]) if written else "no files changed"
                last_summary = f"Task: {auto_prompt}\nResult: {changed}"
        except KeyboardInterrupt:
            renderer.warning("Autopolit cancelled immediately.")
        finally:
            # Restore the original signal handler (only if we installed one)
            if _on_main_thread and original_sigint is not None:
                signal.signal(signal.SIGINT, original_sigint)

    while True:
        try:
            prompt_text = "you> " if multiline_buffer is None else "...  "
            raw = prompt_reader(prompt_text)
        except (EOFError, KeyboardInterrupt):
            renderer.info("\nGoodbye.")
            break

        # Multi-line mode
        if multiline_buffer is not None:
            if raw.rstrip() == '"""':
                user_input = "\n".join(multiline_buffer)
                multiline_buffer = None
            else:
                multiline_buffer.append(raw)
                continue
        elif raw.lstrip().startswith('"""'):
            rest = raw.lstrip()[3:]
            multiline_buffer = [rest] if rest else []
            continue
        else:
            user_input = raw.strip()

        if not user_input:
            continue

        # ── Shell escape: !command ─────────────────────────
        if user_input.startswith("!"):
            shell_cmd = user_input[1:].strip()
            if shell_cmd:
                renderer.print_shell_start(shell_cmd)
                with renderer.status_spinner(
                    f"Running: {shell_cmd[:60]}...", "executing"
                ):
                    output = _run_shell(shell_cmd, cwd)
                renderer.print_shell_output(output)
                engine.add_user(f"[Shell command: {shell_cmd}]")
                engine.add_assistant(f"Command output:\n```\n{output}\n```")
            continue

        # ── Agent commands ──────────────────────────────────
        if user_input.startswith("/"):
            cmd_parts = user_input.split(None, 1)
            command = cmd_parts[0].lower()
            arg = cmd_parts[1] if len(cmd_parts) > 1 else ""

            if command in {"/exit", "/quit", "/q"}:
                renderer.info("Goodbye.")
                break
            elif command == "/help":
                renderer.print_agent_help()
                continue
            elif command == "/models":
                all_models = router.list_all_models()
                if all_models:
                    q = arg.strip().lower()
                    rows = [
                        {
                            "id": m.id,
                            "provider": m.provider,
                            "name": m.name,
                            "local": m.local,
                        }
                        for m in all_models
                    ]
                    if q:
                        rows = [
                            r
                            for r in rows
                            if q in r["id"].lower()
                            or q in r["name"].lower()
                            or q in r["provider"].lower()
                        ]
                        renderer.info(
                            f"Filtered models matching {arg.strip()!r} ({len(rows)} of {len(all_models)})"
                        )
                        if not rows:
                            renderer.warning("No models matched that keyword.")
                            continue
                    renderer.print_model_table(
                        rows,
                        filter_hint=arg.strip() if q else None,
                    )
                    downloaded = list_downloaded()
                    dl_names = {name for name, _ in downloaded}
                    not_downloaded = [
                        m for m in MODEL_CATALOG if m.name not in dl_names
                    ]
                    if not_downloaded:
                        renderer.info(
                            f"\n{len(not_downloaded)} more downloadable GGUF models: sage pull --list"
                        )
                    # Show Ollama catalog hint
                    ollama_available = any(m.provider == "ollama" for m in all_models)
                    if ollama_available:
                        ollama_pulled = {
                            m.id for m in all_models if m.provider == "ollama"
                        }
                        not_pulled = [
                            m for m in OLLAMA_CATALOG if m.name not in ollama_pulled
                        ]
                        if not_pulled:
                            renderer.info(
                                f"\n{len(not_pulled)} more Ollama models available: "
                                "sage models --ollama"
                            )
                    else:
                        renderer.info(
                            f"\n{len(OLLAMA_CATALOG)} Ollama models available — "
                            "install Ollama (ollama.com) then: sage models --ollama"
                        )
                else:
                    renderer.warning(
                        "No models available right now. "
                        "Install Ollama (ollama.com) or check: sage pull --list"
                    )
                continue
            elif command == "/clear":
                engine.clear()
                last_written.clear()
                all_written.clear()
                renderer.success("Conversation and file history cleared.")
                continue
            elif command == "/compact":
                # Trim context to free up space (like Claude Code's /compact)
                before = len(engine._messages)
                if before > 6:
                    engine._messages[:] = engine._messages[:2] + engine._messages[-4:]
                    renderer.success(
                        f"Compacted: {before} messages → {len(engine._messages)}"
                    )
                else:
                    renderer.info("Context already compact.")
                continue
            elif command == "/think":
                if not arg:
                    renderer.warning("Usage: /think <task description>")
                    continue
                # Force model into step-by-step planning mode
                think_prompt = (
                    f"Think step by step about this task: {arg}\n\n"
                    "1. What exactly needs to happen?\n"
                    "2. What existing files need to be read? (Use READ: commands)\n"
                    "3. What files need to be created or modified? List them.\n"
                    "4. What's the correct order of operations?\n"
                    "5. What could go wrong and how will you verify success?\n\n"
                    "After your analysis, start implementing: write tests first with FILE: blocks, "
                    "then implementation, then RUN: to verify."
                )
                response = _send_to_model(think_prompt)
                if response:
                    written = _process_response(response)
                    if written:
                        _auto_validate_and_retry(written, max_retries)
                continue
            elif command == "/files":
                if all_written:
                    unique = list(dict.fromkeys(all_written))
                    renderer.info(f"All written files ({len(unique)}):")
                    for f in unique:
                        exists = "  " if (cwd / f).exists() else "  [deleted]"
                        renderer.console.print(f"  {exists} {f}")
                else:
                    renderer.info("No files written yet.")
                continue
            elif command == "/undo":
                # Time Travel: restore to last checkpoint
                last_cp = checkpoint_mgr.get_last_checkpoint()
                if last_cp and last_cp.description != "Session start":
                    renderer.phase(
                        "time_travel", f"Restoring to: {last_cp.description}"
                    )
                    success, msg = checkpoint_mgr.restore_checkpoint(last_cp)
                    if success:
                        # Trim conversation back to checkpoint state
                        while len(engine._messages) > last_cp.message_count:
                            engine._messages.pop()
                        # Clear written file tracking
                        for fp in last_cp.files_written:
                            if fp in all_written:
                                all_written.remove(fp)
                        last_written.clear()
                        checkpoint_mgr.checkpoints.pop()  # Remove the restored checkpoint
                        renderer.success(f"⏪ {msg}")
                    else:
                        renderer.error(f"Undo failed: {msg}")
                elif last_written:
                    # Fallback: just delete last written files
                    for fp in last_written:
                        target = cwd / fp
                        if target.exists():
                            target.unlink()
                            renderer.info(f"  Deleted: {fp}")
                    last_written.clear()
                else:
                    renderer.info("Nothing to undo. Use /checkpoints to see history.")
                continue
            elif command == "/checkpoint":
                # Manual checkpoint creation
                desc = arg or f"Manual checkpoint at turn {engine.turn_count}"
                cp = checkpoint_mgr.create_checkpoint(
                    files_written=list(all_written),
                    message_count=len(engine._messages),
                    description=desc,
                )
                renderer.success(f"📍 Checkpoint created: {cp.id} — {desc}")
                continue
            elif command == "/checkpoints":
                # List recent checkpoints
                cps = checkpoint_mgr.list_checkpoints(limit=10)
                if cps:
                    renderer.info("Recent checkpoints:")
                    for cp in cps:
                        files_info = (
                            f"{len(cp.files_written)} files"
                            if cp.files_written
                            else "no files"
                        )
                        renderer.info(f"  {cp.id}: {cp.description} ({files_info})")
                else:
                    renderer.info("No checkpoints yet.")
                continue
            elif command == "/model":
                if arg:
                    new_model = _resolve_model_prefix(arg, cfg)
                    # Ensure the model is available (auto-pull for Ollama, auto-download for GGUF)
                    cfg = _ensure_model_available(cfg, new_model)
                    router = _build_router(cfg)
                    model_id = new_model
                    is_local = (
                        model_id.startswith("llama_cpp:")
                        or model_id.startswith("ollama:")
                        or cfg.get_local_model(model_id) is not None
                    )
                    _set_last_used_model(cwd, model_id)
                    renderer.success(f"Switched to: {model_id}")
                else:
                    renderer.info(f"Model: {model_id}")
                continue
            elif command == "/read":
                if not arg:
                    renderer.warning("Usage: /read <filepath>")
                    continue
                content = _read_file_context(arg, cwd)
                if content:
                    line_count = content.count("\n")
                    renderer.print_file_read(arg, line_count)
                    engine.add_user(f"[Reading file: {arg}]\n{content}")
                    engine.add_assistant(
                        "I've read the file. What would you like me to do with it?"
                    )
                else:
                    renderer.step_fail(f"Could not read: {arg}")
                continue
            elif command == "/test":
                # Run project tests
                test_cmd = arg or default_test_cmd
                renderer.phase("testing", test_cmd)
                with renderer.status_spinner("Running tests...", "testing"):
                    output = _run_shell(test_cmd, cwd, timeout=120)
                has_errors = _has_errors(output)
                renderer.print_test_results(output, passed=not has_errors)
                if has_errors:
                    renderer.print_shell_output(output)
                engine.add_user(f"[Test run: {test_cmd}]")
                engine.add_assistant(f"Test output:\n```\n{output}\n```")
                continue
            elif command == "/security":
                # Run security scan on all written files or specified path
                renderer.phase("security", "🔒 Running security audit...")
                if arg:
                    scan_files = [arg]
                elif all_written:
                    scan_files = list(set(all_written))
                else:
                    # Scan common source directories
                    scan_files = []
                    for pattern in ["**/*.py", "**/*.js", "**/*.ts"]:
                        scan_files.extend(
                            str(p.relative_to(cwd))
                            for p in cwd.glob(pattern)
                            if p.is_file()
                        )
                    scan_files = scan_files[:50]  # Limit to 50 files

                if scan_files:
                    findings = security_auditor.scan_files(scan_files)
                    renderer.console.print(security_auditor.format_findings(findings))
                    if security_auditor.has_critical_findings(findings):
                        renderer.error(
                            "⚠️  Critical security issues require immediate attention!"
                        )
                else:
                    renderer.info("No files to scan.")
                continue
            elif command == "/deps":
                # Show dependency graph for a file
                if arg:
                    dep_graph.index_file(arg)
                    context = dep_graph.get_file_context(arg)
                    if context:
                        renderer.console.print(context)
                    else:
                        renderer.info(f"No dependency info for {arg}")
                else:
                    # Show summary of indexed files
                    renderer.info(
                        f"📊 Dependency Graph: {len(dep_graph.nodes)} files indexed"
                    )
                    # Show files with most dependents
                    by_dependents = sorted(
                        dep_graph.nodes.items(),
                        key=lambda x: len(x[1].imported_by),
                        reverse=True,
                    )[:10]
                    if by_dependents:
                        renderer.info("Most-depended-on files:")
                        for path, node in by_dependents:
                            if node.imported_by:
                                renderer.info(
                                    f"  {path}: used by {len(node.imported_by)} files"
                                )
                continue
            elif command == "/swarm":
                # Toggle or execute swarm mode
                if arg:
                    # Execute a task using swarm orchestration
                    renderer.phase("swarm", "🐝 Decomposing task into sub-tasks...")

                    # Get project context for the swarm
                    project_context = _scan_project_context(cwd, max_chars=3000)

                    # Decompose the task
                    tasks = swarm.decompose_task(arg, project_context)
                    renderer.info(f"Created {len(tasks)} sub-tasks:")
                    for task in tasks:
                        deps = (
                            f" (depends on: {', '.join(task.dependencies)})"
                            if task.dependencies
                            else ""
                        )
                        renderer.info(f"  [{task.type.value}] {task.description}{deps}")

                    # Ask for confirmation
                    try:
                        confirm = (
                            renderer.console.input(
                                "\n[yellow]Execute swarm? (y/n):[/yellow] "
                            )
                            .strip()
                            .lower()
                        )
                    except (EOFError, KeyboardInterrupt):
                        renderer.info("Swarm cancelled.")
                        continue

                    if confirm in {"y", "yes", ""}:
                        renderer.phase("swarm", "🐝 Executing swarm tasks...")

                        def swarm_send(prompt: str, target_model: str) -> str | None:
                            """Send to a specific model for swarm."""
                            engine.add_user(prompt)
                            messages = engine.build_messages()
                            try:
                                resp = router.generate(
                                    messages, target_model, temp, tokens
                                )
                                if resp:
                                    engine.add_assistant(resp)
                                return resp
                            except Exception as e:
                                return f"Error: {e}"

                        # Execute the swarm
                        results = swarm.execute_swarm(
                            tasks, swarm_send, parallel=True, max_workers=2
                        )

                        # Process results
                        for task_id, result in results.items():
                            if result:
                                renderer.phase("swarm", f"Processing {task_id}...")
                                written = _process_response(result)
                                if written:
                                    all_written.extend(written)

                        renderer.console.print(swarm.get_swarm_summary())
                else:
                    # Toggle swarm mode
                    swarm_mode = not swarm_mode
                    status = "enabled" if swarm_mode else "disabled"
                    renderer.info(f"🐝 Swarm mode {status}")
                    if swarm_mode:
                        renderer.info(
                            "Complex tasks will be decomposed into parallel sub-tasks.\n"
                            "Use /swarm <task> to run a specific swarm task."
                        )
                continue
            elif command == "/sandbox":
                # Sandbox status and control
                if arg == "start":
                    renderer.phase("sandbox", "🐳 Starting Docker sandbox...")
                    if sandbox.start():
                        renderer.success(f"Sandbox started: {sandbox.container_id}")
                    else:
                        renderer.error("Failed to start sandbox. Is Docker running?")
                elif arg == "stop":
                    sandbox.cleanup()
                    renderer.info("🐳 Sandbox stopped")
                elif arg == "status":
                    status = sandbox.get_status()
                    renderer.info("🐳 Sandbox Status:")
                    for key, value in status.items():
                        renderer.info(f"  {key}: {value}")
                elif arg:
                    # Execute command in sandbox
                    is_safe, reason = controller.validate_command(arg)
                    if not is_safe:
                        renderer.error(reason)
                    else:
                        renderer.phase("sandbox", f"🐳 Executing: {arg[:50]}...")
                        result = sandbox.execute(arg, timeout=120)
                        if result.stdout:
                            renderer.console.print(
                                f"[green]stdout:[/green]\n{result.stdout}"
                            )
                        if result.stderr:
                            renderer.console.print(
                                f"[red]stderr:[/red]\n{result.stderr}"
                            )
                        renderer.info(
                            f"Exit code: {result.exit_code} ({result.duration:.2f}s)"
                        )
                else:
                    status = sandbox.get_status()
                    renderer.info(
                        f"🐳 Sandbox: {'running' if status['running'] else 'stopped'}"
                    )
                    renderer.info(f"   Image: {status['image']}")
                    renderer.info(f"   Network: {status['network']}")
                    renderer.info("Commands: /sandbox start|stop|status|<command>")
                continue
            elif command == "/tdd":
                # TDD gate control
                if arg == "red":
                    # Verify tests fail (RED phase)
                    renderer.phase("tdd", "🔴 Verifying RED phase (tests must fail)...")
                    is_red, message = tdd_gate.verify_red()
                    if is_red:
                        renderer.success(message)
                    else:
                        renderer.error(message)
                elif arg == "green":
                    # Verify tests pass (GREEN phase)
                    renderer.phase(
                        "tdd", "🟢 Verifying GREEN phase (tests must pass)..."
                    )
                    is_green, message = tdd_gate.verify_green()
                    if is_green:
                        renderer.success(message)
                    else:
                        renderer.error(message)
                elif arg == "reset":
                    tdd_gate.reset()
                    renderer.info("🔄 TDD gate reset")
                elif arg == "status":
                    renderer.info(tdd_gate.get_status())
                elif arg and arg.startswith("cmd "):
                    # Set test command
                    test_cmd = arg[4:].strip()
                    tdd_gate.set_test_command(test_cmd)
                    renderer.info(f"Test command set to: {test_cmd}")
                else:
                    renderer.info(tdd_gate.get_status())
                    renderer.info("\nCommands:")
                    renderer.info(
                        "  /tdd red      - Verify tests fail (write tests first)"
                    )
                    renderer.info(
                        "  /tdd green    - Verify tests pass (after implementation)"
                    )
                    renderer.info("  /tdd reset    - Reset TDD cycle")
                    renderer.info(
                        "  /tdd cmd <x>  - Set test command (e.g., 'pytest -v')"
                    )
                continue
            elif command == "/memory":
                # SAGE.md project memory management
                if arg == "init":
                    if not project_memory.exists():
                        project_memory.create()
                        renderer.success(
                            "📝 Created SAGE.md - edit to add project rules"
                        )
                    else:
                        renderer.info("SAGE.md already exists")
                elif arg == "show":
                    content = project_memory.load()
                    if content:
                        renderer.console.print(content)
                    else:
                        renderer.info(
                            "No SAGE.md found. Use /memory init to create one."
                        )
                elif arg == "rules":
                    rules = project_memory.get_rules()
                    if rules:
                        renderer.info("📋 Active project rules:")
                        for rule in rules:
                            renderer.info(f"  • {rule}")
                    else:
                        renderer.info("No rules defined in SAGE.md")
                elif arg == "commands":
                    cmds = project_memory.get_custom_commands()
                    if cmds:
                        renderer.info("⚡ Custom commands:")
                        for name, cmd in cmds.items():
                            renderer.info(f"  {name}: {cmd}")
                    else:
                        renderer.info("No custom commands in SAGE.md")
                else:
                    renderer.info("📝 SAGE.md Project Memory")
                    renderer.info(
                        f"   Status: {'active' if project_memory.exists() else 'not found'}"
                    )
                    renderer.info("\nCommands:")
                    renderer.info("  /memory init     - Create SAGE.md")
                    renderer.info("  /memory show     - View SAGE.md content")
                    renderer.info("  /memory rules    - List active rules")
                    renderer.info("  /memory commands - List custom commands")
                continue
            elif command == "/lsp":
                # LSP diagnostics
                if arg:
                    # Check specific file
                    diags = lsp_client.check_file(arg)
                    renderer.console.print(lsp_client.format_diagnostics(diags))
                elif all_written:
                    # Check recently written files
                    diags = lsp_client.check_files(list(set(all_written[-10:])))
                    renderer.console.print(lsp_client.format_diagnostics(diags))
                else:
                    renderer.info("🔍 LSP Client")
                    renderer.info(
                        "Usage: /lsp <file> - Check file for type/syntax errors"
                    )
                    renderer.info("       /lsp        - Check recently written files")
                continue
            elif command == "/context":
                # Context status
                status = compactor.get_status(engine._messages)
                renderer.info(f"📦 {status}")
                renderer.info(f"   Messages: {len(engine._messages)}")
                renderer.info(f"   Turns: {engine.turn_count}")
                if arg == "compact":
                    renderer.phase("compacting", "📦 Force compacting context...")
                    engine._messages = compactor.compact(
                        engine._messages, router, model_id
                    )
                    renderer.success("Context compacted")
                    renderer.info(compactor.get_status(engine._messages))
                continue
            elif command == "/history":
                renderer.info(f"Turns: {engine.turn_count}")
                history = _load_prompt_history(cwd)
                if history:
                    renderer.info(f"Saved prompts: {len(history)}")
                    for i, h in enumerate(history[-10:], 1):
                        ts = h.get("timestamp", "")[:16]
                        text = h["prompt"][:70] + (
                            "..." if len(h["prompt"]) > 70 else ""
                        )
                        renderer.console.print(
                            f"    [dim]{ts}[/dim]  [cyan]{i}[/cyan]. {text}"
                        )
                    renderer.info(
                        "  Use /prompts to select and reuse a previous prompt."
                    )
                continue
            elif command == "/prompts":
                history = _load_prompt_history(cwd)
                if not history:
                    renderer.info("No prompt history yet.")
                    continue
                recent = history[-20:]
                renderer.console.print(
                    "\n[bold]Prompt History[/bold] (most recent last):\n"
                )
                for i, h in enumerate(recent, 1):
                    ts = h.get("timestamp", "")[:16]
                    text = h["prompt"][:80] + ("..." if len(h["prompt"]) > 80 else "")
                    renderer.console.print(
                        f"  [cyan]{i:>2}[/cyan]. [dim]{ts}[/dim]  {text}"
                    )
                renderer.console.print()
                try:
                    choice = renderer.console.input(
                        "[yellow]Select prompt # (or Enter to cancel):[/yellow] "
                    ).strip()
                except (EOFError, KeyboardInterrupt):
                    continue
                if not choice:
                    continue
                try:
                    idx = int(choice) - 1
                    if 0 <= idx < len(recent):
                        user_input = recent[idx]["prompt"]
                        renderer.console.print(
                            f"  [dim]Reusing:[/dim] {user_input[:80]}..."
                        )
                    else:
                        renderer.warning(f"Invalid selection: {choice}")
                        continue
                except ValueError:
                    renderer.warning(f"Invalid number: {choice}")
                    continue
                # Fall through to prompt processing below
            elif command in {"/workflow", "/wf"}:
                # 15-step procedural workflow
                verbose = False
                show_plan = True
                show_code = True
                task_text: str | None = None

                if arg:
                    args = arg.split()
                    task_parts: list[str] = []
                    for a in args:
                        if a == "--verbose" or a == "-v":
                            verbose = True
                        elif a == "--no-plan":
                            show_plan = False
                        elif a == "--no-code":
                            show_code = False
                        elif a == "--help" or a == "-h":
                            renderer.console.print("\n[bold]📋 SAGE Procedural Workflow[/bold]")
                            renderer.console.print("\nUsage: /workflow [options] <task description>")
                            renderer.console.print("\nOptions:")
                            renderer.console.print("  --verbose, -v   Show detailed step output")
                            renderer.console.print("  --no-plan       Hide execution plan")
                            renderer.console.print("  --no-code       Hide code changes")
                            renderer.console.print("\nAlternative: /wf <task>")
                            renderer.console.print("\nExample: /workflow add user authentication")
                            renderer.console.print("         /wf --verbose fix the login bug\n")
                            continue
                        else:
                            task_parts.append(a)
                    task_text = " ".join(task_parts) if task_parts else None

                if not task_text:
                    # Prompt for task
                    try:
                        task_text = renderer.console.input(
                            "[cyan]Enter task:[/cyan] "
                        ).strip()
                    except (EOFError, KeyboardInterrupt):
                        continue
                    if not task_text:
                        renderer.warning("No task provided. Use: /workflow <task description>")
                        continue

                _run_procedural_workflow(
                    task=task_text,
                    verbose=verbose,
                    show_plan=show_plan,
                    show_code_changes=show_code,
                )
                continue
            elif command in {"/autopolit", "/autopilot"}:
                max_cycles: int | None = None
                use_intelligent = False
                if arg:
                    args = arg.split()
                    for a in args:
                        if a == "--classic":
                            use_intelligent = False
                        elif a == "--smart" or a == "--v2":
                            use_intelligent = True
                        else:
                            try:
                                max_cycles = int(a)
                                if max_cycles <= 0:
                                    raise ValueError
                            except ValueError:
                                renderer.warning(
                                    "Usage: /autopolit [max-cycles] [--classic|--smart]\n"
                                    "Example: /autopolit 5 --smart"
                                )
                                continue

                if use_intelligent:
                    renderer.info("🧠 Using Intelligent Autopilot v2.0")
                    _run_intelligent_autopolit(max_cycles=max_cycles)
                else:
                    renderer.info("Using Classic Autopilot")
                    _run_autopolit(max_cycles=max_cycles)
                continue
            elif command == "/autopolit-stop":
                _autopolit_stop_path(cwd).write_text("stop\n", "utf-8")
                renderer.info(
                    "Stop signal written to .sage/autopolit.stop. Any running autopolit loop will exit after current step."
                )
                continue
            elif command in {"/phd", "/expert"}:
                # PhD-level AI agent with multi-loop architecture
                minimal_noise = True
                task_text: str | None = None

                if arg:
                    args = arg.split()
                    task_parts: list[str] = []
                    for a in args:
                        if a == "--verbose" or a == "-v":
                            minimal_noise = False
                        elif a == "--help" or a == "-h":
                            renderer.console.print("\n[bold]🎓 PhD-Level AI Agent[/bold]")
                            renderer.console.print("\nAdvanced multi-loop architecture with:")
                            renderer.console.print("  • Strategic Loop (spec, modeling, planning)")
                            renderer.console.print("  • Execution Loop (code, test, validate)")
                            renderer.console.print("  • Learning Loop (patterns, heuristics)")
                            renderer.console.print("\nUsage: /phd [options] <task description>")
                            renderer.console.print("\nOptions:")
                            renderer.console.print("  --verbose, -v   Show detailed step output")
                            renderer.console.print("\nAlternative: /expert <task>")
                            renderer.console.print("\nExample: /phd implement user authentication\n")
                            continue
                        else:
                            task_parts.append(a)
                    task_text = " ".join(task_parts) if task_parts else None

                if not task_text:
                    try:
                        task_text = renderer.console.input(
                            "[cyan]Enter task:[/cyan] "
                        ).strip()
                    except (EOFError, KeyboardInterrupt):
                        continue
                    if not task_text:
                        renderer.warning("No task provided. Use: /phd <task description>")
                        continue

                # Run PhD agent
                _run_phd_agent(task=task_text, minimal_noise=minimal_noise)
                continue
            else:
                renderer.warning(f"Unknown command: {command}")
                continue

        _execute_task_prompt(user_input, save_history=True, sender=_send_to_model)


@app.command()
def chat(
    model: Annotated[
        Optional[str], typer.Option("--model", "-m", help="Model ID (provider:model)")
    ] = None,
    system: Annotated[
        Optional[str], typer.Option("--system", "-s", help="System prompt")
    ] = None,
    temperature: Annotated[Optional[float], typer.Option("--temperature", "-t")] = None,
    max_tokens: Annotated[Optional[int], typer.Option("--max-tokens")] = None,
    no_stream: Annotated[
        bool, typer.Option("--no-stream", help="Disable streaming")
    ] = False,
) -> None:
    """Interactive chat session (REPL)."""
    cfg = load_config()
    model_id = _resolve_model_prefix(model or cfg.default_model, cfg)

    # Auto-download local models if not installed
    cfg = _ensure_model_available(cfg, model_id)
    router = _build_router(cfg)

    temp = temperature if temperature is not None else cfg.temperature
    tokens = max_tokens if max_tokens is not None else cfg.max_tokens

    engine = ConversationEngine(
        system_prompt=system or cfg.system_prompt,
        max_history=50,
    )

    renderer.print_welcome(model_id)

    multiline_buffer: list[str] | None = None

    while True:
        try:
            prompt_text = (
                "[bold cyan]you>[/bold cyan] "
                if multiline_buffer is None
                else "[dim]...[/dim]  "
            )
            raw = renderer.console.input(prompt_text)
        except (EOFError, KeyboardInterrupt):
            renderer.info("\nGoodbye.")
            break

        # Multi-line mode
        if multiline_buffer is not None:
            if raw.rstrip() == '"""':
                user_input = "\n".join(multiline_buffer)
                multiline_buffer = None
            else:
                multiline_buffer.append(raw)
                continue
        elif raw.lstrip().startswith('"""'):
            # Start multi-line
            rest = raw.lstrip()[3:]
            multiline_buffer = [rest] if rest else []
            continue
        else:
            user_input = raw.strip()

        if not user_input:
            continue

        # ── REPL commands ───────────────────────────────────
        if user_input.startswith("/"):
            cmd = user_input.split(None, 1)
            command = cmd[0].lower()
            arg = cmd[1] if len(cmd) > 1 else ""

            if command in {"/exit", "/quit", "/q"}:
                renderer.info("Goodbye.")
                break
            elif command == "/help":
                renderer.print_help()
                continue
            elif command == "/clear":
                engine.clear()
                renderer.success("Conversation cleared.")
                continue
            elif command == "/model":
                if arg:
                    new_model = _resolve_model_prefix(arg, cfg)
                    cfg = _ensure_model_available(cfg, new_model)
                    router = _build_router(cfg)
                    model_id = new_model
                    renderer.success(f"Switched to model: {model_id}")
                else:
                    renderer.info(f"Current model: {model_id}")
                continue
            elif command == "/system":
                if arg:
                    engine.system_prompt = arg
                    renderer.success("System prompt updated.")
                else:
                    sp = engine.system_prompt or "(none)"
                    renderer.info(f"System prompt: {sp}")
                continue
            elif command == "/history":
                renderer.info(f"Turns: {engine.turn_count}")
                continue
            else:
                renderer.warning(f"Unknown command: {command}")
                continue

        # ── Send to model ───────────────────────────────────
        engine.add_user(user_input)
        messages = engine.build_messages()

        try:
            renderer.console.print("[bold green]sage>[/bold green] ", end="")
            if no_stream:
                response = router.generate(messages, model_id, temp, tokens)
                renderer.console.print()
                renderer.render_markdown(response)
            else:
                response = renderer.stream_tokens(
                    router.stream(messages, model_id, temp, tokens)
                )
            engine.add_assistant(response)
        except Exception as exc:
            engine._messages.pop()  # Remove the failed user message
            renderer.error(str(exc))


@app.command()
def ask(
    prompt: Annotated[Optional[str], typer.Argument(help="Prompt text")] = None,
    file: Annotated[
        Optional[Path],
        typer.Option("--file", "-f", help="Read file content as context"),
    ] = None,
    model: Annotated[Optional[str], typer.Option("--model", "-m")] = None,
    system: Annotated[Optional[str], typer.Option("--system", "-s")] = None,
    temperature: Annotated[Optional[float], typer.Option("--temperature", "-t")] = None,
    max_tokens: Annotated[Optional[int], typer.Option("--max-tokens")] = None,
    raw: Annotated[
        bool, typer.Option("--raw", help="Output raw text (no markdown rendering)")
    ] = False,
) -> None:
    """One-shot prompt — ask a question and get an answer."""
    cfg = load_config()
    model_id = _resolve_model_prefix(model or cfg.default_model, cfg)

    # Auto-download local models if not installed
    cfg = _ensure_model_available(cfg, model_id)
    router = _build_router(cfg)

    temp = temperature if temperature is not None else cfg.temperature
    tokens = max_tokens if max_tokens is not None else cfg.max_tokens

    # Build the prompt from arguments, file, and/or stdin
    parts: list[str] = []

    # Check for piped input
    piped = _read_stdin()
    if piped:
        parts.append(piped.strip())

    # Read file if provided
    if file:
        if not file.exists():
            renderer.error(f"File not found: {file}")
            raise typer.Exit(1)
        content = file.read_text("utf-8")
        parts.append(f"File: {file.name}\n```\n{content}\n```")

    if prompt:
        parts.append(prompt)

    if not parts:
        renderer.error("No prompt provided. Usage: sage ask 'your question'")
        raise typer.Exit(1)

    full_prompt = _enhance_task_prompt("\n\n".join(parts))

    engine = ConversationEngine(system_prompt=system or cfg.system_prompt)
    engine.add_user(full_prompt)
    messages = engine.build_messages()

    try:
        if raw or not sys.stdout.isatty():
            # Non-interactive: stream raw text
            response = renderer.stream_tokens(
                router.stream(messages, model_id, temp, tokens)
            )
        else:
            # Interactive terminal: render markdown
            response = router.generate(messages, model_id, temp, tokens)
            renderer.render_markdown(response)
    except Exception as exc:
        renderer.error(str(exc))
        raise typer.Exit(2)


def _show_ollama_catalog(
    category: str | None = None, search_query: str | None = None
) -> None:
    """Display Ollama model catalog with Rich formatting."""
    if search_query:
        results = search_ollama_catalog(search_query)
        if not results:
            renderer.warning(f"No Ollama models matching '{search_query}'")
            return
        label = f"Ollama models matching '{search_query}'"
    elif category:
        results = get_ollama_models_by_category(category)
        if not results:
            renderer.warning(
                f"No Ollama models in category '{category}'. "
                "Try: coding, reasoning, general, vision, small, embedding"
            )
            return
        label = f"Ollama models — {category}"
    else:
        results = OLLAMA_CATALOG
        label = "All Ollama models"

    renderer.console.print(f"\n[bold]{label}[/bold] ({len(results)} models)\n")

    # Group by category for full listing
    if not category and not search_query:
        categories = ["coding", "reasoning", "general", "vision", "small", "embedding"]
        for cat in categories:
            cat_models = [m for m in results if m.category == cat]
            if not cat_models:
                continue
            renderer.console.print(f"  [bold cyan]{cat.upper()}[/bold cyan]")
            for m in cat_models:
                params = m.params if m.params else "cloud"
                tags = " ".join(f"[dim]{t}[/dim]" for t in m.tags) if m.tags else ""
                renderer.console.print(
                    f"    [green]{m.name:<30}[/green] "
                    f"[dim]({params})[/dim]  "
                    f"{m.description[:55]}"
                    f"  {tags}"
                )
            renderer.console.print()
    else:
        for m in results:
            params = m.params if m.params else "cloud"
            tags = " ".join(f"[dim]{t}[/dim]" for t in m.tags) if m.tags else ""
            renderer.console.print(
                f"  [green]{m.name:<30}[/green] "
                f"[dim]({params})[/dim]  "
                f"{m.description[:55]}"
                f"  {tags}"
            )

    renderer.console.print(
        "\n[dim]To pull: sage pull <name>  (or: ollama pull <model>)[/dim]"
    )
    renderer.console.print("[dim]To use: sage run --model ollama:<model>[/dim]")
    rec = get_recommended_ollama_models()
    if rec:
        names = ", ".join(m.name for m in rec[:5])
        renderer.console.print(f"[dim]Recommended: {names}[/dim]\n")


@app.command()
def models(
    ollama: Annotated[
        bool, typer.Option("--ollama", help="Show all Ollama models available to pull")
    ] = False,
    category: Annotated[
        Optional[str],
        typer.Option(
            "--category",
            "-c",
            help="Filter Ollama models by category (coding, reasoning, general, vision, small, embedding)",
        ),
    ] = None,
    search: Annotated[
        Optional[str],
        typer.Option("--search", "-s", help="Search Ollama catalog by keyword"),
    ] = None,
) -> None:
    """List available models from all configured providers.

    Examples:
      sage models                        List active models
      sage models --ollama               List all Ollama models available to pull
      sage models --ollama -c coding     List coding-focused Ollama models
      sage models --ollama -s deepseek   Search Ollama catalog
    """
    if ollama or category or search:
        _show_ollama_catalog(category=category, search_query=search)
        return

    cfg = load_config()
    router = _build_router(cfg)
    all_models = router.list_all_models()

    if not all_models:
        renderer.warning(
            "No models available.\n"
            "  Install Ollama (ollama.com) for 90+ free models\n"
            "  Or configure a key: sage config set api_keys.gemini YOUR_KEY\n"
            "  Or add local model: sage config set models.mymodel.path /path/to/model.gguf"
        )
        raise typer.Exit(1)

    renderer.print_model_table(
        [
            {"id": m.id, "provider": m.provider, "name": m.name, "local": m.local}
            for m in all_models
        ]
    )
    renderer.info(f"\nDefault: {cfg.default_model}")
    renderer.info(
        f"\n{len(OLLAMA_CATALOG)} Ollama models available — run: sage models --ollama"
    )


@app.command()
def install() -> None:
    """Download the best AI models for local use — run this after installing Sage.

    Downloads:
    - 3 best GGUF models (qwen2.5-coder-7b, deepseek-r1-7b, llama3.2-3b) for offline use
    - 8 best Ollama models (qwen3.5, gemma4, devstral, nemotron-mini, etc.)

    Total: ~30 GB. All models run 100% locally — no internet needed after install.
    """
    from sage.models.catalog import get_default_models, DEFAULT_OLLAMA_MODELS

    renderer.header("Installing Sage AI — Best Models")
    renderer.info("")

    # Step 1: Download default GGUF models
    defaults = get_default_models()
    renderer.info(f"[1/2] Downloading {len(defaults)} best GGUF models...")
    for m in defaults:
        if is_downloaded(m):
            renderer.success(f"  {m.display_name} ({m.params}) — already downloaded")
            continue
        renderer.info(f"  Downloading {m.display_name} ({m.size_gb} GB)...")
        try:
            download_model(m, progress_callback=lambda dl, tot: None)
            register_model(m)
            renderer.success(f"  {m.display_name} — done!")
        except Exception as exc:
            renderer.error(f"  {m.display_name} — failed: {exc}")

    # Step 2: Pull default Ollama models
    renderer.info(f"\n[2/2] Pulling {len(DEFAULT_OLLAMA_MODELS)} best Ollama models...")
    renderer.info("  (Requires Ollama installed — get it from https://ollama.com)")
    for model_name in DEFAULT_OLLAMA_MODELS:
        renderer.info(f"  Pulling {model_name}...")
        try:
            result = subprocess.run(
                ["ollama", "pull", model_name],
                check=False,
                timeout=600,
            )
            if result.returncode == 0:
                renderer.success(f"  {model_name} — done!")
            else:
                renderer.error(f"  {model_name} — ollama pull failed")
        except FileNotFoundError:
            renderer.warning("  Ollama not installed — skipping Ollama models")
            renderer.info("  Install from https://ollama.com then re-run: sage install")
            break
        except subprocess.TimeoutExpired:
            renderer.error(f"  {model_name} — timed out")

    renderer.info("")
    renderer.header("Setup Complete!")
    renderer.info("  Default model: qwen2.5-coder-7b (best local coding model)")
    renderer.info("  Run: sage chat    — to start chatting")
    renderer.info("  Run: sage models  — to see all available models")
    renderer.info("  Run: sage pull    — to download more models")
    renderer.info("")
    renderer.info("  All inference runs locally on your machine — no API keys needed.")


@app.command()
def pull(
    model_name: Annotated[
        Optional[str],
        typer.Argument(help="Model to download (e.g. 'gemma3-4b', 'qwen2.5-coder-3b')"),
    ] = None,
    list_available: Annotated[
        bool, typer.Option("--list", "-l", help="List all downloadable models")
    ] = False,
    search: Annotated[
        Optional[str], typer.Option("--search", "-s", help="Search catalog by keyword")
    ] = None,
    recommended: Annotated[
        bool,
        typer.Option("--recommended", "-r", help="Show recommended starter models"),
    ] = False,
    all_models: Annotated[
        bool,
        typer.Option(
            "--all",
            help="Download ALL models (GGUF + Ollama). Requires lots of disk space.",
        ),
    ] = False,
    all_gguf: Annotated[
        bool,
        typer.Option("--all-gguf", help="Download all GGUF models from HuggingFace"),
    ] = False,
    all_ollama: Annotated[
        bool,
        typer.Option("--all-ollama", help="Pull all Ollama models"),
    ] = False,
) -> None:
    """Download a free AI model for local use — no API key needed.

    Examples:
      sage pull --list                  List all downloadable models
      sage pull gemma3-4b               Download Google Gemma 3 4B
      sage pull qwen2.5-coder-3b       Download Qwen 2.5 Coder 3B
      sage pull --search code           Search for code-focused models
      sage pull --recommended           Show recommended starter models
      sage pull --all-gguf              Download all GGUF models (~30 GB)
      sage pull --all-ollama            Pull all Ollama models (100+ GB)
      sage pull --all                   Download everything
    """
    from rich.progress import (
        Progress,
        BarColumn,
        DownloadColumn,
        TransferSpeedColumn,
        TimeRemainingColumn,
    )

    # ── Batch download modes ────────────────────────────────
    if all_models or all_gguf or all_ollama:
        gguf_models = [m for m in MODEL_CATALOG if m.backend == "gguf"]
        ollama_models = [m for m in MODEL_CATALOG if m.backend == "ollama"]

        if all_models or all_gguf:
            total_gb = sum(m.size_gb for m in gguf_models)
            renderer.info(
                f"Downloading {len(gguf_models)} GGUF models (~{total_gb:.0f} GB total)..."
            )
            for i, m in enumerate(gguf_models, 1):
                if is_downloaded(m):
                    renderer.info(
                        f"  [{i}/{len(gguf_models)}] {m.name} — already downloaded"
                    )
                    continue
                renderer.info(
                    f"  [{i}/{len(gguf_models)}] Downloading {m.name} ({m.size_gb:.1f} GB)..."
                )
                try:
                    with Progress(
                        "[progress.description]{task.description}",
                        BarColumn(),
                        DownloadColumn(),
                        TransferSpeedColumn(),
                        TimeRemainingColumn(),
                    ) as prog:
                        task_id = prog.add_task(m.display_name, total=None)

                        def _cb(downloaded: int, total: int | None) -> None:
                            if total:
                                prog.update(task_id, completed=downloaded, total=total)

                        download_model(m, progress_callback=_cb)
                    renderer.success(f"  {m.name} downloaded")
                except Exception as exc:
                    renderer.error(f"  {m.name} failed: {exc}")

        if all_models or all_ollama:
            renderer.info(f"\nPulling {len(ollama_models)} Ollama models...")
            for i, m in enumerate(ollama_models, 1):
                ollama_name = m.name.removeprefix("ollama:")
                renderer.info(f"  [{i}/{len(ollama_models)}] Pulling {ollama_name}...")
                try:
                    result = subprocess.run(
                        ["ollama", "pull", ollama_name],
                        check=False,
                        timeout=600,
                        capture_output=True,
                    )
                    if result.returncode == 0:
                        renderer.success(f"  {ollama_name} pulled")
                    else:
                        renderer.error(
                            f"  {ollama_name} failed (exit {result.returncode})"
                        )
                except FileNotFoundError:
                    renderer.error(
                        "Ollama is not installed. Install from https://ollama.com"
                    )
                    break
                except subprocess.TimeoutExpired:
                    renderer.error(f"  {ollama_name} timed out")

        renderer.success("\nBatch download complete!")
        return

    if list_available or (model_name is None and not search and not recommended):
        # Show full catalog
        entries = []
        for m in MODEL_CATALOG:
            if m.backend == "ollama":
                status = ""  # Ollama models checked at runtime
                size_str = m.params if m.params else "cloud"
            else:
                status = "[green]downloaded[/green]" if is_downloaded(m) else ""
                size_str = f"{m.size_gb:.1f} GB"
            entries.append(
                {
                    "name": m.name,
                    "size": size_str,
                    "params": m.params,
                    "family": m.family,
                    "description": m.description,
                    "status": status,
                }
            )
        renderer.print_catalog_table(entries)
        gguf_count = len([m for m in MODEL_CATALOG if m.backend == "gguf"])
        ollama_count = len([m for m in MODEL_CATALOG if m.backend == "ollama"])
        renderer.info(
            f"\n{len(MODEL_CATALOG)} models ({gguf_count} GGUF + {ollama_count} Ollama). "
            "Download with: sage pull <name>"
        )
        renderer.info(
            "Recommended: sage pull qwen2.5-coder-3b (GGUF) or sage pull qwen3 (Ollama)"
        )
        return

    if recommended:
        recs = get_recommended_models()
        entries = []
        for m in recs:
            status = "[green]downloaded[/green]" if is_downloaded(m) else ""
            entries.append(
                {
                    "name": m.name,
                    "size": f"{m.size_gb:.1f} GB",
                    "params": m.params,
                    "family": m.family,
                    "description": m.description,
                    "status": status,
                }
            )
        renderer.print_catalog_table(entries)
        return

    if search:
        results = search_catalog(search)
        if not results:
            renderer.warning(f"No models matching '{search}'")
            raise typer.Exit(1)
        entries = []
        for m in results:
            status = "[green]downloaded[/green]" if is_downloaded(m) else ""
            entries.append(
                {
                    "name": m.name,
                    "size": f"{m.size_gb:.1f} GB",
                    "params": m.params,
                    "family": m.family,
                    "description": m.description,
                    "status": status,
                }
            )
        renderer.print_catalog_table(entries)
        return

    # Download a specific model
    # Try exact match first, then with "ollama:" prefix
    cat_model = CATALOG_BY_NAME.get(model_name)
    if not cat_model and not model_name.startswith("ollama:"):
        cat_model = CATALOG_BY_NAME.get(f"ollama:{model_name}")
    if not cat_model:
        # Try fuzzy search
        results = search_catalog(model_name)
        if results:
            renderer.warning(f"Model '{model_name}' not found. Did you mean:")
            for m in results[:5]:
                if m.backend == "ollama":
                    renderer.info(f"  sage pull {m.name}  — {m.display_name} (Ollama)")
                else:
                    renderer.info(
                        f"  sage pull {m.name}  — {m.display_name} ({m.size_gb:.1f} GB)"
                    )
        else:
            renderer.error(
                f"Model '{model_name}' not found. Run 'sage pull --list' to see available models."
            )
        raise typer.Exit(1)

    # ── Ollama model: pull via `ollama pull` ───────────────
    if cat_model.backend == "ollama":
        ollama_name = cat_model.name.removeprefix("ollama:")
        renderer.info(f"Pulling {cat_model.display_name} via Ollama...")
        renderer.info(f"Running: ollama pull {ollama_name}")
        renderer.console.print()
        try:
            result = subprocess.run(
                ["ollama", "pull", ollama_name],
                check=False,
                timeout=600,
            )
            if result.returncode == 0:
                renderer.success(f"{cat_model.display_name} pulled successfully!")
                renderer.info(f"Run with: sage run --model ollama:{ollama_name}")
            else:
                renderer.error(
                    f"ollama pull failed (exit code {result.returncode}). "
                    "Make sure Ollama is installed: https://ollama.com"
                )
                raise typer.Exit(2)
        except FileNotFoundError:
            renderer.error(
                "Ollama is not installed. Install it from https://ollama.com\n"
                "  Then run: sage pull " + model_name
            )
            raise typer.Exit(2)
        except subprocess.TimeoutExpired:
            renderer.error("Download timed out after 10 minutes.")
            raise typer.Exit(2)
        return

    # ── GGUF model: download from HuggingFace ─────────────
    if is_downloaded(cat_model):
        renderer.success(f"{cat_model.display_name} is already downloaded.")
        renderer.info(f"Run with: sage run --model llama_cpp:{cat_model.name}")
        return

    renderer.info(
        f"Downloading {cat_model.display_name} ({cat_model.size_gb:.1f} GB)..."
    )
    renderer.info(f"From: {cat_model.url[:80]}...")
    renderer.console.print()

    with Progress(
        "[progress.description]{task.description}",
        BarColumn(bar_width=40),
        "[progress.percentage]{task.percentage:>3.0f}%",
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=renderer.console,
    ) as progress:
        task = progress.add_task(f"Downloading {cat_model.name}", total=None)

        def on_progress(downloaded: int, total: int) -> None:
            progress.update(task, total=total, completed=downloaded)

        try:
            path = download_model(cat_model, progress_callback=on_progress)
        except Exception as exc:
            renderer.error(f"Download failed: {exc}")
            raise typer.Exit(2)

    # Auto-register in config
    register_model(cat_model)
    renderer.print_download_complete(
        cat_model.display_name,
        str(path),
        cat_model.size_gb,
    )


@app.command("train-all")
def train_all(
    limit: Annotated[
        Optional[int],
        typer.Option(
            "--limit",
            "-n",
            help="Optional cap for number of models to prepare in one run",
        ),
    ] = None,
    force: Annotated[
        bool,
        typer.Option("--force", help="Re-download even if model is already present"),
    ] = False,
) -> None:
    """Prepare local model catalog for immediate CLI usage."""
    targets = MODEL_CATALOG if limit is None else MODEL_CATALOG[: max(0, limit)]
    if not targets:
        renderer.warning("No models selected.")
        return

    renderer.info(f"Preparing {len(targets)} model(s) for local usage...")
    ok = 0
    skipped = 0
    failed: list[str] = []

    for model in targets:
        if is_downloaded(model) and not force:
            skipped += 1
            renderer.info(f"Already prepared: {model.name}")
            continue
        try:
            path = download_model(model)
            register_model(model)
            ok += 1
            renderer.success(f"Prepared: {model.display_name} -> {path}")
        except Exception as exc:
            failed.append(f"{model.name}: {exc}")
            renderer.warning(f"Failed: {model.name} ({exc})")

    renderer.console.print()
    renderer.info(
        f"Done. prepared={ok} skipped={skipped} failed={len(failed)} total={len(targets)}"
    )
    if failed:
        for item in failed:
            renderer.warning(item)
        raise typer.Exit(2)


@app.command("rm")
def remove_model(
    model_name: Annotated[
        str, typer.Argument(help="Name of the downloaded model to remove")
    ],
) -> None:
    """Remove a downloaded model and free disk space."""
    if delete_model(model_name):
        renderer.success(f"Removed model: {model_name}")
    else:
        renderer.error(f"Model '{model_name}' not found in downloaded models.")
        raise typer.Exit(1)


# ── Config subcommands ──────────────────────────────────────


@config_app.command("show")
def config_show() -> None:
    """Show current configuration."""
    cfg = load_config()
    # Mask API keys for display
    display = cfg.to_dict()
    for key in display.get("api_keys", {}):
        val = display["api_keys"][key]
        if val and len(val) > 8:
            display["api_keys"][key] = val[:4] + "..." + val[-4:]
    renderer.print_config(display)


@config_app.command("set")
def config_set(
    key: Annotated[
        str, typer.Argument(help="Config key (e.g. api_keys.gemini, default_model)")
    ],
    value: Annotated[str, typer.Argument(help="Value to set")],
) -> None:
    """Set a configuration value."""
    try:
        set_config_value(key, value)
        renderer.success(f"Set {key}")
    except KeyError as exc:
        renderer.error(str(exc))
        raise typer.Exit(1)


@config_app.command("get")
def config_get(
    key: Annotated[str, typer.Argument(help="Config key to read")],
) -> None:
    """Get a configuration value."""
    try:
        val = get_config_value(key)
        renderer.console.print(val)
    except KeyError as exc:
        renderer.error(str(exc))
        raise typer.Exit(1)


@config_app.command("init")
def config_init() -> None:
    """Create default config file at ~/.sage/config.json."""
    cfg = SageConfig()
    save_config(cfg)
    renderer.success(f"Config created at ~/.sage/config.json")
    renderer.console.print()
    renderer.info("Quick start (no setup needed):")
    renderer.info(
        "  sage run                            # Start coding with pre-trained free models"
    )
    renderer.info(
        "  sage models                         # See all available providers/models"
    )
    renderer.console.print()
    renderer.info("Optional: add your own keys/providers:")
    renderer.info("  sage config set api_keys.gemini    YOUR_KEY  # Google AI Studio")
    renderer.info("  sage config set api_keys.groq      YOUR_KEY  # console.groq.com")
    renderer.info("  sage config set api_keys.cerebras  YOUR_KEY  # cloud.cerebras.ai")
    renderer.info("Optional local offline model: sage pull qwen2.5-coder-3b")


# ── DevOps Commands ─────────────────────────────────────────


devops_app = typer.Typer(help="DevOps, Git, GitHub, and CI/CD operations")
app.add_typer(devops_app, name="devops")


@devops_app.command("status")
def devops_status() -> None:
    """Show git status and latest CI/CD run status."""
    from sage.devops.git import GitOps
    from sage.devops.ci_cd import CICDMonitor

    git = GitOps()
    monitor = CICDMonitor()

    # Git status
    status = git.status()
    renderer.header("Git Status")
    renderer.info(f"  Branch: {status.branch}")
    if status.ahead:
        renderer.info(f"  Ahead: {status.ahead} commit(s)")
    if status.behind:
        renderer.info(f"  Behind: {status.behind} commit(s)")
    if status.staged:
        renderer.info(f"  Staged: {len(status.staged)} file(s)")
    if status.modified:
        renderer.info(f"  Modified: {len(status.modified)} file(s)")
    if status.untracked:
        renderer.info(f"  Untracked: {len(status.untracked)} file(s)")
    if status.is_clean:
        renderer.success("  Working tree clean")

    # Latest CI run
    renderer.console.print()
    renderer.header("Latest CI/CD Run")
    run = monitor.get_latest_run()
    if run:
        if run.conclusion == "success":
            status_text = "[green]SUCCESS[/green]"
        elif run.conclusion == "failure":
            status_text = "[red]FAILED[/red]"
        elif run.is_running:
            status_text = "[yellow]RUNNING[/yellow]"
        else:
            status_text = f"[dim]{run.status}[/dim]"
        renderer.info(f"  Workflow: {run.workflow_name}")
        renderer.info(f"  Status: {status_text}")
        renderer.info(f"  Branch: {run.head_branch}")
        renderer.info(f"  URL: {run.url}")
    else:
        renderer.info("  No recent runs found")


@devops_app.command("commit")
def devops_commit(
    message: Annotated[str, typer.Argument(help="Commit message")],
    push: Annotated[
        bool, typer.Option("--push", "-p", help="Push after commit")
    ] = False,
    all_changes: Annotated[
        bool, typer.Option("--all", "-a", help="Stage all changes")
    ] = True,
) -> None:
    """Stage changes and create a commit.

    Examples:
      sage devops commit "feat: add login"        Stage all and commit
      sage devops commit "fix: bug" --push        Commit and push
    """
    from sage.devops.git import GitOps

    git = GitOps()

    if all_changes:
        add_result = git.add_all()
        if not add_result.success:
            renderer.error(f"Failed to stage changes: {add_result.error}")
            raise typer.Exit(1)

    commit_result = git.commit(message)
    if not commit_result.success:
        renderer.error(f"Commit failed: {commit_result.error}")
        raise typer.Exit(1)

    renderer.success(f"Committed: {message}")

    if push:
        push_result = git.push()
        if push_result.success:
            renderer.success("Pushed to remote")
        else:
            renderer.error(f"Push failed: {push_result.error}")
            raise typer.Exit(1)


@devops_app.command("push")
def devops_push(
    set_upstream: Annotated[
        bool, typer.Option("--set-upstream", "-u", help="Set upstream tracking")
    ] = False,
    force_with_lease: Annotated[
        bool, typer.Option("--force-with-lease", help="Safe force push")
    ] = False,
) -> None:
    """Push commits to remote.

    Examples:
      sage devops push                   Push to tracked remote
      sage devops push -u                Push and set upstream
    """
    from sage.devops.git import GitOps

    git = GitOps()
    result = git.push(set_upstream=set_upstream, force_with_lease=force_with_lease)

    if result.success:
        renderer.success("Pushed to remote")
        if result.output:
            renderer.info(result.output)
    else:
        renderer.error(f"Push failed: {result.error}")
        raise typer.Exit(1)


@devops_app.command("pr")
def devops_pr(
    title: Annotated[Optional[str], typer.Argument(help="PR title")] = None,
    body: Annotated[str, typer.Option("--body", "-b", help="PR description")] = "",
    base: Annotated[str, typer.Option("--base", help="Base branch")] = "main",
    draft: Annotated[
        bool, typer.Option("--draft", "-d", help="Create as draft")
    ] = False,
    list_prs: Annotated[
        bool, typer.Option("--list", "-l", help="List open PRs")
    ] = False,
) -> None:
    """Create or list pull requests.

    Examples:
      sage devops pr "Add feature"           Create PR with title
      sage devops pr "Fix bug" --draft       Create draft PR
      sage devops pr --list                  List open PRs
    """
    from sage.devops.github import GitHubOps

    gh = GitHubOps()

    if list_prs:
        prs = gh.pr_list()
        if not prs:
            renderer.info("No open pull requests")
            return

        from rich.table import Table

        table = Table(title="Open Pull Requests")
        table.add_column("#", style="cyan")
        table.add_column("Title", style="white")
        table.add_column("Author", style="green")
        table.add_column("Branch", style="yellow")

        for pr in prs:
            table.add_row(str(pr.number), pr.title, pr.author, pr.head_branch)

        renderer.console.print(table)
        return

    if not title:
        renderer.error("Please provide a PR title or use --list")
        raise typer.Exit(1)

    result = gh.pr_create(title=title, body=body, base=base, draft=draft)
    if result.success:
        renderer.success(f"Created PR: {result.output}")
    else:
        renderer.error(f"Failed to create PR: {result.error}")
        raise typer.Exit(1)


@devops_app.command("watch")
def devops_watch(
    run_id: Annotated[
        Optional[int], typer.Argument(help="Workflow run ID (latest if omitted)")
    ] = None,
    workflow: Annotated[
        Optional[str], typer.Option("--workflow", "-w", help="Filter by workflow file")
    ] = None,
    branch: Annotated[
        Optional[str], typer.Option("--branch", "-b", help="Filter by branch")
    ] = None,
) -> None:
    """Watch a CI/CD deployment with live progress bar.

    Examples:
      sage devops watch                      Watch latest run
      sage devops watch 12345678             Watch specific run ID
      sage devops watch -w ci.yml            Watch latest CI workflow
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    if run_id is None:
        run = monitor.get_latest_run(branch=branch, workflow=workflow)
        if not run:
            renderer.error("No workflow runs found")
            raise typer.Exit(1)
        run_id = run.id
        renderer.info(f"Watching: {run.workflow_name} (run {run.id})")

    final_status = monitor.watch_with_progress(run_id)

    if final_status:
        if final_status.conclusion == "success":
            renderer.success("Deployment completed successfully!")
        elif final_status.conclusion == "failure":
            renderer.error(
                f"Deployment failed ({final_status.jobs_failed} job(s) failed)"
            )
            renderer.info(f"View logs: gh run view {run_id} --log-failed")
            raise typer.Exit(1)
        else:
            renderer.warning(f"Deployment ended: {final_status.conclusion}")


@devops_app.command("runs")
def devops_runs(
    limit: Annotated[int, typer.Option("--limit", "-n", help="Number of runs")] = 10,
    workflow: Annotated[
        Optional[str], typer.Option("--workflow", "-w", help="Filter by workflow")
    ] = None,
    branch: Annotated[
        Optional[str], typer.Option("--branch", "-b", help="Filter by branch")
    ] = None,
) -> None:
    """List recent workflow runs.

    Examples:
      sage devops runs                       List 10 most recent runs
      sage devops runs -n 20                 List 20 runs
      sage devops runs -w ci.yml             List runs for ci.yml workflow
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()
    runs = monitor.gh.run_list(workflow=workflow, branch=branch, limit=limit)

    if not runs:
        renderer.info("No workflow runs found")
        return

    from rich.table import Table

    table = Table(title="Workflow Runs")
    table.add_column("ID", style="dim")
    table.add_column("Workflow", style="cyan")
    table.add_column("Branch", style="yellow")
    table.add_column("Status", justify="center")
    table.add_column("Commit", style="dim")

    for run in runs:
        if run.conclusion == "success":
            status = "[green]SUCCESS[/green]"
        elif run.conclusion == "failure":
            status = "[red]FAILED[/red]"
        elif run.is_running:
            status = "[yellow]RUNNING[/yellow]"
        else:
            status = f"[dim]{run.status}[/dim]"

        table.add_row(
            str(run.id),
            run.workflow_name,
            run.head_branch,
            status,
            run.head_sha[:8],
        )

    renderer.console.print(table)


@devops_app.command("diagnose")
def devops_diagnose(
    run_id: Annotated[
        Optional[int], typer.Argument(help="Workflow run ID (latest failed if omitted)")
    ] = None,
) -> None:
    """Diagnose failures in a CI/CD run.

    Examples:
      sage devops diagnose                   Diagnose latest failed run
      sage devops diagnose 12345678          Diagnose specific run
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    if run_id is None:
        runs = monitor.gh.run_list(limit=10)
        failed_runs = [r for r in runs if r.conclusion == "failure"]
        if not failed_runs:
            renderer.info("No recent failed runs to diagnose")
            return
        run_id = failed_runs[0].id
        renderer.info(f"Diagnosing latest failed run: {run_id}")

    diagnoses = monitor.diagnose(run_id)

    if not diagnoses:
        renderer.info("No specific errors identified")
        renderer.info(f"View full logs: gh run view {run_id} --log-failed")
        return

    for diag in diagnoses:
        from rich.panel import Panel

        fix_text = ""
        if diag.can_auto_fix:
            fix_text = f"\n[green]Auto-fixable:[/green] {diag.suggested_fix}"
        elif diag.suggested_fix:
            fix_text = f"\n[yellow]Suggested fix:[/yellow] {diag.suggested_fix}"

        renderer.console.print(
            Panel(
                f"[bold]{diag.error_type}[/bold]\n"
                f"Job: {diag.job_name}\n"
                f"Step: {diag.step_name}\n"
                f"Error: {diag.error_message}"
                + (
                    f"\nFile: {diag.file_path}:{diag.line_number}"
                    if diag.file_path
                    else ""
                )
                + fix_text,
                title="Failure Diagnosis",
                border_style="red" if not diag.can_auto_fix else "yellow",
            )
        )


@devops_app.command("fix")
def devops_fix(
    run_id: Annotated[
        Optional[int], typer.Argument(help="Workflow run ID to fix")
    ] = None,
    commit: Annotated[
        bool, typer.Option("--commit", "-c", help="Commit the fix")
    ] = True,
    push: Annotated[
        bool, typer.Option("--push", "-p", help="Push after committing")
    ] = True,
) -> None:
    """Attempt to auto-fix failures in a CI/CD run.

    Examples:
      sage devops fix                        Fix latest failed run
      sage devops fix 12345678               Fix specific run
      sage devops fix --no-push              Fix but don't push
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    if run_id is None:
        runs = monitor.gh.run_list(limit=10)
        failed_runs = [r for r in runs if r.conclusion == "failure"]
        if not failed_runs:
            renderer.info("No recent failed runs to fix")
            return
        run_id = failed_runs[0].id

    diagnoses = monitor.diagnose(run_id)
    fixable = [d for d in diagnoses if d.can_auto_fix]

    if not fixable:
        renderer.warning("No auto-fixable issues found")
        renderer.info("Run 'sage devops diagnose' to see all issues")
        return

    renderer.info(f"Found {len(fixable)} fixable issue(s)")

    for diag in fixable:
        renderer.info(f"  Fixing: {diag.error_type} - {diag.suggested_fix}")
        if monitor.auto_fix(diag, commit=False, push=False):
            renderer.success(f"  Fixed!")
        else:
            renderer.error(f"  Failed to fix")

    if commit:
        from sage.devops.git import GitOps

        git = GitOps()
        git.add_all()
        git.commit("fix: auto-fix CI failures")
        renderer.success("Committed fixes")

        if push:
            result = git.push()
            if result.success:
                renderer.success("Pushed to remote")
                renderer.info(
                    "CI will re-run automatically. Watch with: sage devops watch"
                )
            else:
                renderer.error(f"Push failed: {result.error}")


@devops_app.command("deploy")
def devops_deploy(
    message: Annotated[
        Optional[str], typer.Argument(help="Commit message (if changes exist)")
    ] = None,
    auto_fix: Annotated[
        bool, typer.Option("--auto-fix", "-f", help="Auto-fix failures and retry")
    ] = False,
    max_retries: Annotated[
        int, typer.Option("--retries", "-r", help="Max auto-fix retries")
    ] = 3,
    workflow: Annotated[
        Optional[str], typer.Option("--workflow", "-w", help="Workflow to watch")
    ] = None,
) -> None:
    """Full deployment flow: commit, push, watch, and optionally auto-fix.

    Examples:
      sage devops deploy "feat: new feature"        Commit, push, and watch
      sage devops deploy --auto-fix                 Deploy with auto-fix on failure
      sage devops deploy -f -r 5                    Auto-fix with 5 retries
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    success, final_status = monitor.deploy_and_watch(
        commit_message=message,
        workflow=workflow,
        auto_fix=auto_fix,
        max_retries=max_retries,
    )

    if success:
        renderer.success("Deployment completed successfully!")
    else:
        if final_status:
            renderer.error(f"Deployment failed: {final_status.conclusion}")
            renderer.info("Run 'sage devops diagnose' for failure analysis")
        raise typer.Exit(1)


@devops_app.command("rerun")
def devops_rerun(
    run_id: Annotated[
        Optional[int], typer.Argument(help="Workflow run ID to rerun")
    ] = None,
    failed_only: Annotated[
        bool, typer.Option("--failed", "-f", help="Only rerun failed jobs")
    ] = True,
    watch: Annotated[
        bool, typer.Option("--watch", "-w", help="Watch the rerun")
    ] = True,
) -> None:
    """Rerun a workflow run.

    Examples:
      sage devops rerun                      Rerun latest run (failed jobs only)
      sage devops rerun 12345678             Rerun specific run
      sage devops rerun --no-failed          Rerun all jobs
    """
    from sage.devops.ci_cd import CICDMonitor

    monitor = CICDMonitor()

    if run_id is None:
        run = monitor.get_latest_run()
        if not run:
            renderer.error("No workflow runs found")
            raise typer.Exit(1)
        run_id = run.id

    result = monitor.gh.run_rerun(run_id, failed_only=failed_only)

    if result.success:
        renderer.success(f"Rerun triggered for run {run_id}")
        if watch:
            import time

            time.sleep(3)  # Wait for new run to appear
            new_run = monitor.get_latest_run()
            if new_run:
                renderer.info(f"Watching new run: {new_run.id}")
                monitor.watch_with_progress(new_run.id)
    else:
        renderer.error(f"Failed to rerun: {result.error}")
        raise typer.Exit(1)


# ── Version callback ────────────────────────────────────────


def _version_callback(value: bool) -> None:
    if value:
        renderer.console.print(f"sage {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option("--version", "-v", callback=_version_callback, is_eager=True),
    ] = None,
) -> None:
    """Sage — local-first AI coding assistant."""


def run() -> None:
    """Entry point for pyproject.toml console_scripts."""
    app()
