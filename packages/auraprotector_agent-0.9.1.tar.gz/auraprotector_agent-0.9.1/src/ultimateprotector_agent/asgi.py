from __future__ import annotations

import asyncio
import hashlib
import os
import threading
import time
from typing import Any, Awaitable, Callable, Dict, Iterable, List, Mapping, Optional, Tuple

from .client import GeoLookupCache, UltimateProtectorClient
from .obsidian import ObsidianInjector
from .utils import (
    cidr_match,
    compile_php_like_regex,
    detect_country,
    is_sensitive_request,
    is_static_request,
    normalize_ip,
    parse_cookie_header,
    should_protect_request,
)
import re as _re

ASGIApp = Callable[[Dict[str, Any], Callable[[], Awaitable[Dict[str, Any]]], Callable[[Dict[str, Any]], Awaitable[None]]], Awaitable[None]]

# --- Additive scoring thresholds (ported from OG engine) ---
_THRESHOLDS = {"ALLOW": 0, "SLOW": 40, "CHALLENGE": 60, "DECOY": 75, "BLOCK": 85}
_RL_RATE_PER_SEC = 8
_RL_BURST = 24
_RL_ROUTE_MULTIPLIERS = [
    (_re.compile(r"^/login", _re.IGNORECASE), 0.4),
    (_re.compile(r"^/auth", _re.IGNORECASE), 0.4),
    (_re.compile(r"^/api/", _re.IGNORECASE), 0.7),
    (_re.compile(r"^/assets/", _re.IGNORECASE), 2.0),
    (_re.compile(r"^/wp-login", _re.IGNORECASE), 0.4),
    (_re.compile(r"^/wp-admin", _re.IGNORECASE), 0.5),
]
_DECOY_HTML = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Scheduled Maintenance</title><style>body{background:#0a0a0a;color:#aaa;font-family:system-ui;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0}.box{text-align:center;max-width:480px}h1{font-size:1.5rem;color:#fff;margin:0 0 1rem}p{color:#666;font-size:.875rem}</style></head><body><div class="box"><h1>Scheduled Maintenance</h1><p>We are currently performing scheduled maintenance. Please try again later.</p><p style="color:#444;font-size:.75rem;margin-top:2rem">ETA: ~15 minutes</p></div></body></html>'

# Per-IP token-bucket state (module-level dict)
_rl_buckets: Dict[str, Dict[str, float]] = {}
_rl_last_evict: float = 0.0


def _route_multiplier(path: str) -> float:
    for rx, m in _RL_ROUTE_MULTIPLIERS:
        if rx.search(path):
            return m
    return 1.0


def _consume_token(ip: str, mult: float) -> bool:
    """Returns True if rate exceeded."""
    global _rl_last_evict
    now = time.monotonic()
    bucket = _rl_buckets.get(ip)
    if bucket is None:
        bucket = {"ts": now, "tokens": float(_RL_BURST)}
        _rl_buckets[ip] = bucket

    elapsed = now - bucket["ts"]
    added = elapsed * _RL_RATE_PER_SEC * mult
    bucket["tokens"] = min(_RL_BURST * mult, bucket["tokens"] + added)
    bucket["ts"] = now

    if bucket["tokens"] >= 1:
        bucket["tokens"] -= 1
        exceeded = False
    else:
        exceeded = True

    # Evict stale entries every 5 minutes
    if now - _rl_last_evict > 300:
        _rl_last_evict = now
        stale = [k for k, v in _rl_buckets.items() if now - v["ts"] > 120]
        for k in stale:
            del _rl_buckets[k]

    return exceeded


def _score_request(headers: Dict[str, str], ua: str, method: str, path: str, ip: str, rules: Optional[Dict[str, Any]] = None) -> tuple:
    """Returns (score: int, reasons: list[str])."""
    score = 0
    reasons: list = []

    # Token-bucket rate limit
    mult = _route_multiplier(path)
    if _consume_token(ip, mult):
        score += 35
        reasons.append("rate_burst")

    # UA quality signals
    if not ua:
        score += 50
        reasons.append("ua_empty")
    elif len(ua) < 10:
        score += 25
        reasons.append("ua_too_short")

    # Missing Accept-Language
    if not headers.get("accept-language"):
        score += 20
        reasons.append("no_accept_language")

    # Missing or generic Accept
    accept = headers.get("accept", "")
    if not accept or accept == "*/*":
        score += 15
        reasons.append("generic_accept")

    # Connection: close
    if headers.get("connection", "").lower() == "close":
        score += 10
        reasons.append("conn_close")

    # POST with no Referer
    if method == "POST" and not headers.get("referer"):
        score += 15
        reasons.append("post_no_referer")

    # Scanner keyword match in UA (soft signal via scoring, not hard block)
    if rules and isinstance(rules, dict):
        scanner_keywords = rules.get("scanner_keywords")
        if isinstance(scanner_keywords, list) and scanner_keywords and ua:
            ua_lower = ua.lower()
            for kw in scanner_keywords:
                if isinstance(kw, str) and kw and kw.lower() in ua_lower:
                    score += 40
                    reasons.append("scanner_keyword")
                    break

    return (max(0, min(100, score)), reasons)


def extract_tls_fingerprint(scope: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
    """Extract a TLS fingerprint from the ASGI scope (Uvicorn/Hypercorn extensions).

    Approximates JA3 by hashing: TLS version + cipher suite.
    Returns None if TLS info is not available (e.g. behind a reverse proxy).
    """
    try:
        extensions = scope.get("extensions") or {}
        tls_info = extensions.get("tls") or {}
        if not tls_info:
            return None

        protocol = str(tls_info.get("server_protocol") or tls_info.get("protocol") or "")
        cipher = str(tls_info.get("server_cipher") or tls_info.get("cipher") or "")
        version = str(tls_info.get("version") or protocol or "")

        if not cipher and not version:
            return None

        raw = f"{protocol}|{cipher}|{version}"
        fp_hash = hashlib.md5(raw.encode("utf-8")).hexdigest()

        # Flag if TLS version is below 1.2
        min_tls_ok = (not protocol) or protocol in ("TLSv1.3", "TLSv1.2")

        return {"hash": fp_hash, "version": protocol, "cipher": cipher, "min_tls_ok": min_tls_ok}
    except Exception:
        return None


class UltimateProtectorMiddleware:
    def __init__(
        self,
        app: ASGIApp,
        *,
        license_key: str,
        api_url: str,
        sync_interval_seconds: int = 60,
        allow_sample_rate: float = 0.01,
        only_paths: Optional[List[str]] = None,
        except_paths: Optional[List[str]] = None,
        only_regex: Optional[str] = None,
    ) -> None:
        self.app = app
        self.license_key = str(license_key)
        self.api_url = str(api_url).rstrip("/")
        self.sync_interval_seconds = max(10, int(sync_interval_seconds))
        self.allow_sample_rate = max(0.0, min(1.0, float(allow_sample_rate)))

        self.only_paths = [str(x) for x in only_paths] if only_paths else None
        self.except_paths = [str(x) for x in except_paths] if except_paths else None
        self.only_regex = str(only_regex) if only_regex else None

        self.client = UltimateProtectorClient(
            license_key=self.license_key,
            api_url=self.api_url,
            sync_interval_seconds=self.sync_interval_seconds,
            allow_sample_rate=self.allow_sample_rate,
        )

        self.obsidian = ObsidianInjector()

        self.geo_cache = GeoLookupCache(
            api_url=self.api_url,
            license_key=self.license_key,
        )

        self.passport_cookie_name = "aura_passport"
        self.passport_cookie_value = hashlib.sha256(("verified" + self.license_key).encode("utf-8")).hexdigest()

        # Heartbeat: background-threaded ping every 5 minutes (non-blocking)
        self._heartbeat_interval = 300  # 5 minutes
        self._heartbeat_last_at = 0.0
        self._heartbeat_lock = threading.Lock()

    def _send_heartbeat_sync(self, domain: str) -> None:
        """Background-threaded heartbeat POST. Runs outside the event loop.

        Uses a synchronous HTTP client with a 2-second timeout.
        All errors are silently swallowed — heartbeat is best-effort.
        """
        try:
            import httpx as _httpx
            with _httpx.Client(timeout=2.0) as client:
                client.post(self.api_url + "/agent/heartbeat", json={
                    "license_key": self.license_key,
                    "domain": domain,
                    "agent_version": UltimateProtectorClient.agent_version,
                    "timestamp": int(time.time()),
                })
        except Exception:
            pass

    def _maybe_heartbeat(self, domain: str) -> None:
        """Throttled heartbeat trigger. Spawns a daemon thread to avoid blocking."""
        now = time.monotonic()
        with self._heartbeat_lock:
            if (now - self._heartbeat_last_at) < self._heartbeat_interval:
                return
            self._heartbeat_last_at = now
        t = threading.Thread(target=self._send_heartbeat_sync, args=(domain,), daemon=True)
        t.start()

    async def __call__(self, scope: Dict[str, Any], receive: Callable[[], Awaitable[Dict[str, Any]]], send: Callable[[Dict[str, Any]], Awaitable[None]]):
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        path = str(scope.get("path") or "/")

        # Non-blocking heartbeat (threaded, throttled internally)
        _hb_headers = _headers_to_dict(scope.get("headers") or [])
        _hb_host = _hb_headers.get("host", "unknown").split(":")[0]
        self._maybe_heartbeat(_hb_host)

        if not should_protect_request(
            path=path,
            only_paths=self.only_paths,
            except_paths=self.except_paths,
            only_regex=self.only_regex,
        ):
            await self.app(scope, receive, send)
            return

        headers = _headers_to_dict(scope.get("headers") or [])
        method = str(scope.get("method") or "").upper()

        qs = scope.get("query_string") or b""
        query = _parse_query_string(qs)

        # up_token exchange (challenge success)
        up_token = query.get("up_token")
        if up_token:
            if not self.client.verify_up_token(up_token):
                await _send_text(send, 403, "Invalid Token")
                return

            secure = _is_secure(scope, headers)
            set_cookie = _build_cookie(
                name=self.passport_cookie_name,
                value=self.passport_cookie_value,
                max_age=604800,
                secure=secure,
            )

            await _send_redirect(send, 302, _absolute_url(scope, headers, path), extra_headers=[(b"set-cookie", set_cookie.encode("utf-8"))])
            return

        cookies = parse_cookie_header(headers.get("cookie", ""))
        if (
            cookies.get(self.passport_cookie_name) == self.passport_cookie_value
            or cookies.get("up_passport") == self.passport_cookie_value
        ):
            ip = normalize_ip(_client_ip_from_scope(scope))
            ua = headers.get("user-agent", "")
            await self.client.log_allow_verified_human(
                ip=ip,
                ua=ua,
                method=method,
                host=headers.get("host", ""),
                path=path,
                country=detect_country(headers),
            )
            await self.app(scope, receive, send)
            return

        host = headers.get("host", "")
        domain = host.split(":")[0] if host else "unknown"

        try:
            rules = await self.client.get_rules(domain=domain)
        except Exception:
            # fail-open
            await self.app(scope, receive, send)
            return

        if self.client.status == "expired":
            await _send_html(send, 503, self.client.expired_html())
            return

        if not isinstance(rules, dict):
            await self.app(scope, receive, send)
            return

        # Obsidian hooks (response transform)
        send_wrapped = send
        if rules.get("obsidian_active"):
            send_wrapped = self.obsidian.wrap_send(send, rules)

        # Context
        ua = (headers.get("user-agent") or "")[: self.client.max_ua_length]
        country = detect_country(headers)
        origin = headers.get("origin", "")
        ref = headers.get("referer", "")

        remote_ip = normalize_ip(_client_ip_from_scope(scope))
        ip = _detect_client_ip(headers, rules, remote_ip)

        ctx = {
            "ip": ip,
            "ua": ua,
            "method": method,
            "host": host,
            "path": path,
            "country": country,
        }

        # L1.6 TLS fingerprint enforcement
        tls_fp = extract_tls_fingerprint(scope)
        if tls_fp:
            ctx["tls_hash"] = tls_fp["hash"]
            ctx["tls_version"] = tls_fp["version"]

            # Block outdated TLS versions (below 1.2)
            if not tls_fp["min_tls_ok"]:
                await self.client.log_block("TLS Version Too Low", "tls_version", ctx)
                await _respond_block(send_wrapped, rules, ip, "TLS Version Too Low")
                return

            # Check against known-bad fingerprints from intelligence
            bad_fps = rules.get("bad_tls_fingerprints")
            if isinstance(bad_fps, list) and tls_fp["hash"] in bad_fps:
                await self.client.log_block("Bad TLS Fingerprint", "bad_tls_fp", ctx)
                await _respond_block(send_wrapped, rules, ip, "Bad TLS Fingerprint")
                return

        # L-1 whitelist
        wl = rules.get("whitelist_ips")
        if isinstance(wl, list) and ip in wl:
            await self.client.log_allow("Whitelisted IP", None, ctx)
            await self.app(scope, receive, send_wrapped)
            return

        # L-0.5 SEO safety
        if rules.get("seo_safety_enabled"):
            ok = await self.client.is_safe_seo_crawler(ua=ua, ip=ip)
            if ok:
                await self.client.log_allow("SEO Safety", None, ctx)
                await self.app(scope, receive, send_wrapped)
                return
        else:
            # SEO safety OFF: ALL bots are denied.
            # Verified real crawlers → soft block (no ban). Fakes → hard block (ban).
            _crawler_tokens = ["googlebot", "bingbot", "yandex", "baiduspider", "duckduckbot", "slurp", "applebot", "facebookexternalhit", "twitterbot", "linkedinbot", "pinterestbot"]
            _ua_lower = ua.lower()
            _matched_bot = next((t for t in _crawler_tokens if t in _ua_lower), None)
            if _matched_bot:
                _verified = await self.client.is_safe_seo_crawler(ua=ua, ip=ip)
                if _verified:
                    # Real crawler — soft block (no ban, just 403)
                    await self.client.log_block(f"SEO Disabled \u2014 Verified Crawler: {_matched_bot}", "seo_disabled_crawler", ctx)
                    await _respond_soft_block(send_wrapped, rules, ip, "SEO Disabled")
                    return
                # Fake crawler — hard block + ban
                await self.client.log_block(f"Fake Crawler: {_matched_bot}", "fake_crawler", ctx)
                await _respond_block(send_wrapped, rules, ip, "Fake Crawler Detected")
                return

        # L1 global blocklist
        if self.client.is_globally_blocked_ip(rules, ip):
            await self.client.log_block("Global Blocklist", "global_blocklist", ctx)
            await _respond_block(send_wrapped, rules, ip, "Global Blocklist")
            return

        # Geo fallback — always resolve country via API when CDN headers are absent
        if country == "XX":
            try:
                country = await self.geo_cache.lookup(ip)
                ctx["country"] = country
            except Exception:
                pass  # fail-open: keep XX

        # L2 geo firewall (soft-block: IP is NOT auto-banned)
        # Real humans can retry with VPN or request whitelist.
        block_geo = rules.get("block_geo")
        if isinstance(block_geo, list) and block_geo:
            is_whitelist = (rules.get("geo_mode") or "blacklist") == "whitelist"
            in_list = country in block_geo
            if (is_whitelist and not in_list) or ((not is_whitelist) and in_list):
                await self.client.log_block("Geo Firewall", "geo_soft", ctx)
                await _respond_soft_block(send_wrapped, rules, ip, "Geo Firewall")
                return

        # L2.5 CIDR infrastructure blocking
        blocked_cidrs = rules.get("blocked_cidrs")
        if isinstance(blocked_cidrs, list) and blocked_cidrs:
            for cidr_entry in blocked_cidrs:
                if isinstance(cidr_entry, str) and cidr_entry and cidr_match(ip, cidr_entry):
                    await self.client.log_block("Blocked CIDR", "blocked_cidr", ctx)
                    await _respond_block(send_wrapped, rules, ip, "Blocked CIDR")
                    return

        # L2.7 Honeypot header detection
        honeypot_headers = rules.get("honeypot_headers")
        if isinstance(honeypot_headers, list) and honeypot_headers:
            for hp_header in honeypot_headers:
                hp_key = str(hp_header).lower() if hp_header else ""
                if hp_key and headers.get(hp_key):
                    await self.client.log_block("Honeypot Header", "honeypot_header", ctx)
                    await _respond_block(send_wrapped, rules, ip, "Honeypot Header")
                    return

        # L3 scanner UAs
        scanner_uas = rules.get("scanner_uas")
        if isinstance(scanner_uas, list):
            ua_lower = ua.lower()
            for bad in scanner_uas:
                if isinstance(bad, str) and bad and bad.lower() in ua_lower:
                    await self.client.log_block("Bot Signature", "bot_signature", ctx)
                    await _respond_block(send_wrapped, rules, ip, "Bot Signature")
                    return

        # L3 bot regex
        bot_ua_regex = rules.get("bot_ua_regex")
        if isinstance(bot_ua_regex, str) and bot_ua_regex:
            re_obj = compile_php_like_regex(bot_ua_regex)
            if re_obj and re_obj.search(ua):
                await self.client.log_block("Bot Regex", "bot_regex", ctx)
                await _respond_block(send_wrapped, rules, ip, "Bot Regex")
                return

        # L4 VPN shield (heuristics)
        if rules.get("block_vpn"):
            uri = _absolute_url(scope, headers, path)
            do_rdns = (not is_static_request(uri)) and method != "HEAD" and is_sensitive_request(method, uri)
            hostname = None
            if do_rdns:
                hostname = await self.client.rdns_lookup(ip)

            if hostname and hostname != ip:
                proxy_domains = rules.get("proxy_domains")
                if isinstance(proxy_domains, list):
                    hn = hostname.lower()
                    for d in proxy_domains:
                        if isinstance(d, str) and d and d.lower() in hn:
                            await self.client.log_challenge("Challenge", "challenge", ctx)
                            await _respond_challenge(send_wrapped, scope, headers, self.license_key, self.api_url)
                            return

                banned_isps = rules.get("banned_isps")
                if isinstance(banned_isps, list):
                    hn = hostname.lower()
                    for s in banned_isps:
                        if isinstance(s, str) and s and s.lower() in hn:
                            await self.client.log_block("Banned ISP", "banned_isp", ctx)
                            await _respond_block(send_wrapped, rules, ip, "Banned ISP")
                            return

                banned_asns = rules.get("banned_asns")
                if isinstance(banned_asns, list):
                    hn = hostname.lower()
                    for s in banned_asns:
                        if isinstance(s, str) and s and s.lower() in hn:
                            await self.client.log_block("Banned ASN", "banned_asn", ctx)
                            await _respond_block(send_wrapped, rules, ip, "Banned ASN")
                            return

        # L5 referrer security
        banned_ref = rules.get("banned_referrers")
        if isinstance(banned_ref, list) and banned_ref:
            if method == "POST" and not ref and not origin:
                await self.client.log_challenge("Challenge", "challenge", ctx)
                await _respond_challenge(send_wrapped, scope, headers, self.license_key, self.api_url)
                return

            if ref:
                # protocol mismatch detection (https site with http referrer)
                try:
                    from urllib.parse import urlparse

                    ru = urlparse(ref)
                    ref_host = ru.netloc
                    ref_scheme = ru.scheme
                    is_https = _is_secure(scope, headers)
                    if ref_host == host and is_https and ref_scheme == "http":
                        await self.client.log_block("Header Spoofing", None, ctx)
                        await _respond_block(send_wrapped, rules, ip, "Header Spoofing")
                        return
                except Exception:
                    pass

                ref_lower = ref.lower()
                for bad in banned_ref:
                    if isinstance(bad, str) and bad and bad.lower() in ref_lower:
                        await self.client.log_block("Bad Referrer", "bad_referrer", ctx)
                        await _respond_block(send_wrapped, rules, ip, "Bad Referrer")
                        return

        # --- Deep Scan: Additive Scoring Engine ---
        risk_score, score_reasons = _score_request(headers, ua, method, path, ip, rules)
        ctx["risk_score"] = risk_score

        if risk_score >= _THRESHOLDS["BLOCK"]:
            await self.client.log_block(
                f"High Risk Score ({risk_score}): {', '.join(score_reasons)}", "high_risk_score", ctx
            )
            await _respond_block(send_wrapped, rules, ip, "Risk Assessment")
            return
        if risk_score >= _THRESHOLDS["DECOY"]:
            await self.client.log_block(
                f"Decoy Score ({risk_score}): {', '.join(score_reasons)}", "decoy", ctx
            )
            await _respond_decoy(send_wrapped, rules)
            return
        if risk_score >= _THRESHOLDS["CHALLENGE"]:
            await self.client.log_challenge(
                f"Challenge Score ({risk_score}): {', '.join(score_reasons)}", "challenge_score", ctx
            )
            await _respond_challenge(send_wrapped, scope, headers, self.license_key, self.api_url)
            return
        if risk_score >= _THRESHOLDS["SLOW"]:
            await self.client.log_challenge(
                f"Slow Score ({risk_score}): {', '.join(score_reasons)}", "slow", ctx
            )
            await asyncio.sleep(2.0)
            # continues to allow after delay

        await self.client.log_allow("Clean Traffic", None, ctx)
        await self.app(scope, receive, send_wrapped)


def _headers_to_dict(headers: Iterable[Tuple[bytes, bytes]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for k, v in headers:
        out[k.decode("latin-1").lower()] = v.decode("latin-1")
    return out


def _parse_query_string(qs: bytes) -> Dict[str, str]:
    if not qs:
        return {}
    from urllib.parse import parse_qs

    parsed = parse_qs(qs.decode("latin-1"), keep_blank_values=True)
    return {k: (v[0] if v else "") for k, v in parsed.items()}


def _client_ip_from_scope(scope: Mapping[str, Any]) -> str:
    client = scope.get("client")
    if isinstance(client, (list, tuple)) and client:
        return str(client[0])
    return ""


def _is_secure(scope: Mapping[str, Any], headers: Mapping[str, str]) -> bool:
    xf = headers.get("x-forwarded-proto", "")
    if "https" in xf:
        return True
    return str(scope.get("scheme") or "").lower() == "https"


def _absolute_url(scope: Mapping[str, Any], headers: Mapping[str, str], path: str) -> str:
    scheme = "https" if _is_secure(scope, headers) else "http"
    host = headers.get("host", "") or "localhost"
    return f"{scheme}://{host}{path}"


def _detect_client_ip(headers: Mapping[str, str], rules: Mapping[str, Any], remote_ip: str) -> str:
    ip = normalize_ip(remote_ip) or "0.0.0.0"

    cf_ranges = rules.get("cloudflare_cidrs")
    if isinstance(cf_ranges, list) and cf_ranges:
        for cidr in cf_ranges:
            if isinstance(cidr, str) and cidr and cidr_match(ip, cidr):
                cf_ip = normalize_ip(headers.get("cf-connecting-ip", ""))
                if cf_ip:
                    return cf_ip

                xff = headers.get("x-forwarded-for", "")
                if xff:
                    first = normalize_ip(xff.split(",")[0].strip())
                    if first:
                        return first
                break

    # fallback
    return ip


def _build_cookie(*, name: str, value: str, max_age: int, secure: bool) -> str:
    base = f"{name}={value}; Path=/; Max-Age={int(max_age)}; HttpOnly; SameSite=Lax"
    return base + ("; Secure" if secure else "")


async def _send_text(send: Callable[[Dict[str, Any]], Awaitable[None]], status: int, text: str):
    await send({
        "type": "http.response.start",
        "status": int(status),
        "headers": [(b"content-type", b"text/plain; charset=utf-8")],
    })
    await send({
        "type": "http.response.body",
        "body": text.encode("utf-8"),
        "more_body": False,
    })


async def _send_html(send: Callable[[Dict[str, Any]], Awaitable[None]], status: int, html: str):
    await send({
        "type": "http.response.start",
        "status": int(status),
        "headers": [(b"content-type", b"text/html; charset=utf-8")],
    })
    await send({
        "type": "http.response.body",
        "body": html.encode("utf-8"),
        "more_body": False,
    })


async def _send_redirect(send: Callable[[Dict[str, Any]], Awaitable[None]], status: int, location: str, *, extra_headers: Optional[List[Tuple[bytes, bytes]]] = None):
    headers: List[Tuple[bytes, bytes]] = [(b"location", location.encode("utf-8"))]
    if extra_headers:
        headers.extend(extra_headers)
    await send({
        "type": "http.response.start",
        "status": int(status),
        "headers": headers,
    })
    await send({
        "type": "http.response.body",
        "body": b"",
        "more_body": False,
    })


async def _respond_challenge(send: Callable[[Dict[str, Any]], Awaitable[None]], scope: Mapping[str, Any], headers: Mapping[str, str], license_key: str, api_url: str):
    base_url = api_url
    if base_url.lower().endswith("/api"):
        base_url = base_url[:-4]
    current_url = _absolute_url(scope, headers, str(scope.get("path") or "/"))
    from urllib.parse import urlencode

    # Preferred flow: opaque token (prevents license_key leak in URLs/logs)
    token = None
    try:
        import httpx

        async with httpx.AsyncClient(timeout=2.0) as client:
            r = await client.post(api_url.rstrip("/") + "/agent/challenge/init", json={
                "license_key": license_key,
                "return_url": current_url,
            })
            if r.status_code >= 200 and r.status_code < 300:
                data = r.json()
                if isinstance(data, dict):
                    t = data.get("token")
                    if isinstance(t, str) and len(t) > 20:
                        token = t
    except Exception:
        token = None

    if token:
        location = base_url + "/security-check?" + urlencode({"token": token})
        await _send_redirect(send, 302, location)
        return

    # Fallback: serve block page instead of leaking license_key in URL
    ip = "0.0.0.0"
    await _send_html(send, 403, _branded_block_html(ip, "Verification Required"))


async def _respond_decoy(send: Callable[[Dict[str, Any]], Awaitable[None]], rules: Mapping[str, Any]):
    html = rules.get("cloak_html") if isinstance(rules.get("cloak_html"), str) and rules.get("cloak_html") else _DECOY_HTML
    await _send_html(send, 200, html)


async def _respond_block(send: Callable[[Dict[str, Any]], Awaitable[None]], rules: Mapping[str, Any], ip: str, reason: str):
    cloak_html = rules.get("cloak_html")
    if isinstance(cloak_html, str) and cloak_html:
        await _send_html(send, 200, cloak_html)
        return

    await _send_html(send, 403, _branded_block_html(ip, reason))


async def _respond_soft_block(send: Callable[[Dict[str, Any]], Awaitable[None]], rules: Mapping[str, Any], ip: str, reason: str):
    """Same visual as _respond_block but the reason code ('geo_soft', 'seo_disabled_crawler') prevents auto-ban."""
    cloak_html = rules.get("cloak_html")
    if isinstance(cloak_html, str) and cloak_html:
        await _send_html(send, 200, cloak_html)
        return

    await _send_html(send, 403, _branded_block_html(ip, reason))


def _branded_block_html(ip: str, reason: str) -> str:
    import html
    from datetime import datetime, timezone

    rid = "RAY-" + os.urandom(6).hex()
    t = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    safe_ip = html.escape(ip)
    safe_reason = html.escape(reason)
    return (
        '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>Access Denied \u2014 AuraGuardian</title>'
        '<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#08080c;color:#d4d4d8;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden}.bg{position:fixed;inset:0;z-index:0}.bg::before{content:"";position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(ellipse at 30% 20%,rgba(99,102,241,.08) 0%,transparent 60%),radial-gradient(ellipse at 70% 80%,rgba(244,63,94,.06) 0%,transparent 60%);animation:drift 20s ease-in-out infinite alternate}@keyframes drift{0%{transform:translate(0,0) rotate(0deg)}100%{transform:translate(30px,-20px) rotate(2deg)}}.card{position:relative;z-index:1;max-width:520px;width:90%;background:rgba(15,15,20,.85);border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:48px 40px;text-align:center;backdrop-filter:blur(40px);-webkit-backdrop-filter:blur(40px);box-shadow:0 25px 50px -12px rgba(0,0,0,.6),inset 0 1px 0 rgba(255,255,255,.05)}.shield{width:64px;height:64px;margin:0 auto 24px;position:relative}.shield svg{width:100%;height:100%;filter:drop-shadow(0 0 20px rgba(99,102,241,.3))}.shield::after{content:"";position:absolute;inset:-4px;border-radius:50%;background:conic-gradient(from 0deg,transparent 0%,rgba(99,102,241,.4) 25%,transparent 50%,rgba(244,63,94,.4) 75%,transparent 100%);animation:spin 3s linear infinite;mask:radial-gradient(farthest-side,transparent calc(100% - 2px),#000 calc(100% - 2px));-webkit-mask:radial-gradient(farthest-side,transparent calc(100% - 2px),#000 calc(100% - 2px))}@keyframes spin{to{transform:rotate(360deg)}}h1{font-size:24px;font-weight:700;color:#fff;margin-bottom:8px;letter-spacing:-.02em}.subtitle{font-size:15px;color:#71717a;line-height:1.5;margin-bottom:32px}.meta{background:rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.06);border-radius:12px;padding:16px 20px;text-align:left;font-family:"SF Mono","Cascadia Code","Fira Code",monospace;font-size:12px;color:#52525b}.meta .row{display:flex;justify-content:space-between;padding:4px 0}.meta .row+.row{border-top:1px solid rgba(255,255,255,.04)}.meta .label{color:#71717a}.meta .value{color:#a1a1aa;text-align:right;max-width:60%;word-break:break-all}.footer{margin-top:32px;font-size:11px;color:#3f3f46}.footer a{color:#6366f1;text-decoration:none;font-weight:500}.footer a:hover{text-decoration:underline}@media(max-width:480px){.card{padding:32px 24px}h1{font-size:20px}}</style></head>'
        '<body><div class="bg"></div><div class="card"><div class="shield">'
        '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L3 7v5c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-9-5z" fill="url(#g)" opacity=".15"/><path d="M12 2L3 7v5c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-9-5z" stroke="url(#g)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><defs><linearGradient id="g" x1="3" y1="2" x2="21" y2="24" gradientUnits="userSpaceOnUse"><stop stop-color="#818cf8"/><stop offset="1" stop-color="#f43f5e"/></linearGradient></defs></svg>'
        '</div><h1>Access Denied</h1><p class="subtitle">This request has been blocked by the site&#39;s security system.</p>'
        '<div class="meta">'
        f'<div class="row"><span class="label">Ray ID</span><span class="value">{rid}</span></div>'
        f'<div class="row"><span class="label">Your IP</span><span class="value">{safe_ip}</span></div>'
        f'<div class="row"><span class="label">Reason</span><span class="value">{safe_reason}</span></div>'
        f'<div class="row"><span class="label">Time</span><span class="value">{t}</span></div>'
        '</div>'
        '<p class="footer">Protected by <a href="https://auraguardian.co" target="_blank" rel="noopener">AuraGuardian</a></p>'
        '</div></body></html>'
    )
