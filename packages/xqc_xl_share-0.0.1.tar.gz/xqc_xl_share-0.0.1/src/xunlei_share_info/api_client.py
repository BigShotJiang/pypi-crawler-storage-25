"""迅雷分享链接 API 客户端（异步版本）."""

from __future__ import annotations

import hashlib
import json
import re
import time
import uuid
from typing import Any

import anyio
import httpx

from xunlei_share_info.models import format_file_size
from xunlei_share_info.parser import ShareLinkInfo, extract_links_from_text

# 迅雷分享链接正则（用于快速过滤非迅雷链接）
_XUNLEI_LINK_RE = re.compile(r"pan\.xunlei\.com/s/[a-zA-Z0-9_-]+", re.IGNORECASE)

# API 配置
CAPTCHA_API_URL = "https://xluser-ssl.xunlei.com/v1/shield/captcha/init"
API_BASE_URL = "https://api-pan.xunlei.com"
API_SHARE_DETAIL = "/drive/v1/share"

# 迅雷桌面客户端配置（用于 captcha 签名）
TOKEN_CLIENT_ID = "Yd0uSVGrNJhCC2oE"
CLIENT_ID = "Yd0uSVGrNJhCC2oE"
CLIENT_VERSION = "2.9.0"
PACKAGE_NAME = "pan.xunlei.com"
ALG_VERSION = "1"

# captcha_token 缓存有效期（秒）- 通常 captcha_token 有 5-10 分钟有效期
_CAPTCHA_TOKEN_TTL = 300

# captcha_sign 生成算法的盐值列表
_ALGORITHMS = [
    "t24w3VjaHB++4RM",
    "pgA9zT3GQqQhXyWwL",
    "35Nt1aQOI67",
    "lKwoU/SK0AJ3y6vn+l3n",
    "h3OGLCTCzmbhJLmb6WTNq8ogHNuI8GnpVUJ",
    "v0Br3m00h2g5cXF1Zbpbt4DNh9/8tt8",
    "vOSCqn9uXdX02Nt4pQCoRmj0WiY7AvDh6",
    "oa2PBcypZ",
    "NeNF/rCYnaA1Yp",
    "yDCpWLF5b",
    "xK9k",
    "K0ACI+Yf",
    "XDWXowjmmnp1GF",
    "cX5DR4LoIKZy2hbC2xmVy",
    "VZVfriR9",
]


class XunleiShareAPI:
    """迅雷分享链接异步 API 客户端."""

    def __init__(
        self,
        *,
        max_concurrent: int = 5,
        timeout: float = 30.0,
        retries: int = 1,
        retry_delay: float = 2.0,
    ) -> None:
        """初始化异步 API 客户端.

        :param max_concurrent: 最大并发请求数（默认 5）
        :param timeout: 单个请求超时秒数（默认 30.0）
        :param retries: 请求失败重试次数（默认 1）
        :param retry_delay: 重试间隔秒数（默认 2.0）
        """
        self.device_id = uuid.uuid4().hex[:32]
        self.max_concurrent = max_concurrent
        self.timeout = timeout
        self.retries = retries
        self.retry_delay = retry_delay
        self._client: httpx.AsyncClient | None = None
        # captcha_token 缓存: (token, expire_time)
        self._captcha_token_cache: tuple[str, float] | None = None
        # 并发限制器（创建一次，复用）
        self._limiter = anyio.CapacityLimiter(max_concurrent)
        # captcha_token 获取锁（防止并发竞态）
        self._captcha_lock = anyio.Lock()

    async def _get_client(self) -> httpx.AsyncClient:
        """获取或创建异步 HTTP 客户端（所有请求共享，复用连接池）."""
        if self._client is None or self._client.is_closed:
            limits = httpx.Limits(
                max_connections=100,
                max_keepalive_connections=20,
                keepalive_expiry=30.0,
            )
            self._client = httpx.AsyncClient(
                base_url=API_BASE_URL,
                timeout=self.timeout,
                follow_redirects=True,
                limits=limits,
            )
        return self._client

    @staticmethod
    def _md5_hash(value: str) -> str:
        """计算字符串的 MD5 哈希值."""
        return hashlib.md5(value.encode("utf-8")).hexdigest()

    def _generate_captcha_sign(self, timestamp: str) -> str:
        """生成 captcha_sign 签名.

        :param timestamp: 时间戳（毫秒）
        :returns: 签名字符串，格式为 "1.xxxxxx"
        """
        captcha_sign = (
            f"{TOKEN_CLIENT_ID}"
            f"{CLIENT_VERSION}"
            f"{PACKAGE_NAME}"
            f"{self.device_id}"
            f"{timestamp}"
        )

        for salt in _ALGORITHMS:
            captcha_sign = self._md5_hash(f"{captcha_sign}{salt}")

        return f"{ALG_VERSION}.{captcha_sign}"

    def _is_captcha_token_valid(self) -> bool:
        """检查缓存的 captcha_token 是否仍然有效.

        :returns: 是否有效
        """
        if self._captcha_token_cache is None:
            return False
        _, expire_time = self._captcha_token_cache
        return time.monotonic() < expire_time

    async def _get_captcha_token(self, action: str = "GET:/drive/v1/share") -> str:
        """获取验证码令牌（带缓存复用和并发锁保护）.

        :param action: API 操作标识
        :returns: captcha_token 字符串
        :raises ValueError: 当获取失败时
        """
        # 快速路径：缓存有效时直接返回
        if self._is_captcha_token_valid():
            return self._captcha_token_cache[0]

        # 缓存失效时，使用锁防止并发竞态
        async with self._captcha_lock:
            # 双重检查：可能其他协程已经获取了 token
            if self._is_captcha_token_valid():
                return self._captcha_token_cache[0]

            timestamp = str(int(time.time() * 1000))
            captcha_sign = self._generate_captcha_sign(timestamp)

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
                "Content-Type": "text/plain;charset=UTF-8",
                "Origin": "https://pan.xunlei.com",
                "Referer": "https://pan.xunlei.com/",
                "X-Device-Id": self.device_id,
                "X-Client-Id": CLIENT_ID,
            }

            payload = json.dumps(
                {
                    "client_id": TOKEN_CLIENT_ID,
                    "action": action,
                    "device_id": self.device_id,
                    "captcha_token": "",
                    "meta": {
                        "username": "",
                        "phone_number": "",
                        "email": "",
                        "package_name": PACKAGE_NAME,
                        "client_version": CLIENT_VERSION,
                        "captcha_sign": captcha_sign,
                        "timestamp": timestamp,
                        "user_id": "",
                    },
                },
                ensure_ascii=False,
            )

            # 使用共享客户端，复用连接池
            client = await self._get_client()
            response = await client.post(
                CAPTCHA_API_URL, content=payload, headers=headers
            )

            if response.status_code != 200:
                raise ValueError(f"获取验证码令牌失败: {response.text[:200]}")

            data = response.json()
            captcha_token = data.get("captcha_token")
            if not captcha_token:
                raise ValueError("获取验证码令牌失败：响应中缺少 captcha_token 字段")

            # 缓存 token
            self._captcha_token_cache = (
                captcha_token,
                time.monotonic() + _CAPTCHA_TOKEN_TTL,
            )

            return captcha_token

    async def _fetch_share_detail(self, share_info: ShareLinkInfo) -> dict[str, Any]:
        """获取分享链接详情.

        :param share_info: 分享链接信息
        :returns: API 响应的原始数据
        """
        captcha_token = await self._get_captcha_token()
        client = await self._get_client()

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
            "Accept": "*/*",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Origin": "https://pan.xunlei.com",
            "Referer": "https://pan.xunlei.com/",
            "X-Device-Id": self.device_id,
            "X-Client-Id": CLIENT_ID,
            "X-Captcha-Token": captcha_token,
        }

        params: dict[str, str] = {
            "share_id": share_info.share_id,
            "limit": "100",
            "page_token": "",
            "thumbnail_size": "SIZE_SMALL",
        }

        if share_info.pass_code:
            params["pass_code"] = share_info.pass_code

        response = await client.get(API_SHARE_DETAIL, params=params, headers=headers)
        response.raise_for_status()
        return response.json()

    @staticmethod
    def _resolve_status(data: dict[str, Any]) -> str:
        """解析分享链接的状态.

        :param data: API 原始响应数据
        :returns: 状态字符串
        """
        status = data.get("share_status", "")

        if status == "OK":
            return "valid"
        elif status == "PASS_CODE_EMPTY":
            return "passcode_required"
        elif status == "PASS_CODE_ERROR":
            return "passcode_invalid"
        elif status == "DELETED":
            return "deleted"
        elif status == "EXPIRED":
            return "expired"
        else:
            return "unknown"

    @staticmethod
    def _format_share_detail(
        data: dict[str, Any], share_info: ShareLinkInfo, task: str = ""
    ) -> dict[str, Any]:
        """将 API 响应格式化为字典格式.

        :param data: API 响应数据
        :param share_info: 分享链接信息
        :param task: 原始任务输入
        :returns: 格式化后的字典
        """
        files_data = data.get("files", [])
        user_info = data.get("user_info", {})
        file_count = int(data.get("file_num", 0))

        # 根对象（分享通常只有一个文件或目录）
        root_file = files_data[0] if files_data else {}

        # 基础字段
        result: dict[str, Any] = {
            "task": task,
            "share_status": "",
            "is_valid": False,
            "file_count": 0,
            "title": "",
            "name": "",
            "type": "",
            "size": "",
            "extension": "",
            "folder_type": None,
            "child_count": None,
            "sha1": "",
            "created_at": "",
            "modified_at": "",
            "owner_nickname": "",
            "owner_user_id": "",
            "share_url": "",
            "message": "",
        }
        result.update(
            {
                "share_status": XunleiShareAPI._resolve_status(data),
                "file_count": file_count,
                "owner_nickname": user_info.get("nickname", ""),
                "owner_user_id": user_info.get("user_id", ""),
                "title": data.get("title", ""),
                "share_url": f"https://pan.xunlei.com/s/{share_info.share_id}{f'?pwd={share_info.pass_code}' if share_info.pass_code else ''}",
                "message": "查询成功",
            }
        )

        # 根据状态动态设置有效性和提示消息
        status = result["share_status"]
        if status == "valid":
            result["message"] = "查询成功"
            result["is_valid"] = True
        elif status == "passcode_required":
            result["message"] = "分享有效，需要提供提取码"
            result["is_valid"] = True
        elif status == "passcode_invalid":
            result["message"] = "提取码错误"
            result["is_valid"] = True
        elif status == "deleted":
            result["message"] = "抱歉，该分享已被作者删除"
            result["is_valid"] = False
        elif status == "expired":
            result["message"] = "抱歉，该分享已过期"
            result["is_valid"] = False
        else:
            result["message"] = "未知状态"
            result["is_valid"] = False

        # 填充文件/目录信息
        if root_file:
            is_folder = root_file.get("kind", "") == "drive#folder"
            if is_folder:
                folder_type = root_file.get("folder_type", "")
                result["type"] = "folder"
                result["folder_type"] = folder_type if folder_type else None
                result["child_count"] = int(
                    root_file.get("params", {}).get("file_property_count", file_count)
                )
            else:
                file_size = int(root_file.get("size", 0))
                result["size"] = format_file_size(file_size)
                result["type"] = root_file.get("mime_type", "")

            result["name"] = root_file.get("name", "")
            result["extension"] = root_file.get("file_extension", "")
            result["sha1"] = root_file.get("hash", "")
            result["created_at"] = root_file.get("created_time", "")
            result["modified_at"] = root_file.get("modified_time", "")

        return result

    def _build_error_result(
        self,
        task: str,
        status: str,
        message: str,
    ) -> dict[str, Any]:
        """构建错误结果字典.

        :param task: 原始任务输入
        :param status: 状态标识
        :param message: 错误消息
        :returns: 错误结果字典
        """
        return {
            "task": task[:200],
            "share_status": status,
            "is_valid": False,
            "file_count": 0,
            "title": "",
            "name": "",
            "type": "",
            "size": "",
            "extension": "",
            "folder_type": None,
            "child_count": None,
            "sha1": "",
            "created_at": "",
            "modified_at": "",
            "owner_nickname": "",
            "owner_user_id": "",
            "share_url": "",
            "message": message,
        }

    async def _process_single_link(self, link_text: str) -> dict[str, Any]:
        """处理单个链接（包含重试逻辑）.

        :param link_text: 单个链接或包含链接的文本
        :returns: 格式化后的结果字典
        """
        # 正则预过滤：快速判断是否包含迅雷链接
        if not _XUNLEI_LINK_RE.search(link_text):
            return self._build_error_result(
                link_text, "invalid_link", "非迅雷云盘分享链接"
            )

        try:
            share_infos = extract_links_from_text(link_text)
        except ValueError:
            return self._build_error_result(
                link_text, "invalid_link", "无法解析分享链接"
            )

        # 重试逻辑
        last_err: Exception | None = None
        for attempt in range(1 + self.retries):
            try:
                results = []
                for share_info in share_infos:
                    raw_data = await self._fetch_share_detail(share_info)
                    detail = self._format_share_detail(
                        raw_data, share_info, task=link_text[:200]
                    )
                    results.append(detail)
                # 如果只有一个分享，直接返回；多个则返回第一个（通常只有一个）
                return (
                    results[0]
                    if results
                    else self._build_error_result(
                        link_text, "error", "未获取到分享数据"
                    )
                )
            except ValueError:
                raise
            except Exception as e:
                last_err = e
                if attempt < self.retries:
                    await anyio.sleep(self.retry_delay)
                continue

        # 所有重试都失败了
        return self._build_error_result(
            link_text,
            "error",
            f"请求失败（已重试 {self.retries} 次）: {last_err}",
        )

    async def get_share_details(self, links: list[str]) -> list[dict[str, Any]]:
        """并发批量获取分享链接详情.

        :param links: 分享链接或文本列表（每个元素可以是纯链或包含链接的文本）
        :returns: 详情字典列表
        """
        # 使用有序结果列表，保持输入顺序
        results: list[dict[str, Any] | None] = [None] * len(links)

        async def _fetch_with_order(idx: int, link_text: str) -> None:
            """带序号的并发获取，确保结果顺序一致."""
            async with self._limiter:
                result = await self._process_single_link(link_text)
                results[idx] = result

        async with anyio.create_task_group() as tg:
            for idx, link_text in enumerate(links):
                tg.start_soon(_fetch_with_order, idx, link_text)

        # 过滤 None（理论上不会出现）
        return [r for r in results if r is not None]

    async def close(self) -> None:
        """关闭异步 HTTP 客户端."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def __aenter__(self) -> "XunleiShareAPI":
        """支持异步上下文管理器."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """退出异步上下文时关闭客户端."""
        await self.close()
