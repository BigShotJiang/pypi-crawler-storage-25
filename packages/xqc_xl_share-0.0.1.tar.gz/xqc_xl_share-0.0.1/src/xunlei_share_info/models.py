"""分享详情数据模型和解析器."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional


@dataclass
class FileInfo:
    """文件信息."""

    file_id: str
    name: str
    size: int
    mime_type: str
    file_extension: str
    created_time: Optional[datetime] = None
    modified_time: Optional[datetime] = None
    md5_checksum: str = ""
    sha1_hash: str = ""
    icon_link: str = ""
    thumbnail_link: str = ""
    web_content_link: str = ""
    parent_id: str = ""
    file_category: str = ""


@dataclass
class UserInfo:
    """分享者信息."""

    user_id: str
    nickname: str
    portrait_url: str = ""
    avatar: str = ""


@dataclass
class ShareDetail:
    """分享详情."""

    share_id: str = ""
    title: str = ""
    share_status: str = ""
    share_status_text: str = ""
    file_num: int = 0
    expiration_left: str = ""
    expiration_left_seconds: int = -1
    pass_code_token: str = ""
    files: list[FileInfo] = field(default_factory=list)
    user_info: Optional[UserInfo] = None
    icon_link: str = ""
    thumbnail_link: str = ""

    @property
    def is_valid(self) -> bool:
        """分享链接是否有效."""
        return self.share_status == "OK"

    @property
    def total_size(self) -> int:
        """所有文件的总大小（字节）."""
        return sum(f.size for f in self.files)

    @property
    def file_count(self) -> int:
        """文件数量."""
        return len(self.files)

    @property
    def is_single_file(self) -> bool:
        """是否为单文件分享."""
        return self.file_count == 1

    @property
    def is_folder(self) -> bool:
        """是否为目录（多文件）分享."""
        return self.file_count > 1


def parse_timestamp(timestamp_str: str) -> Optional[datetime]:
    """解析 ISO 8601 格式的时间戳.

    :param timestamp_str: ISO 8601 格式的时间字符串，例如 2026-04-10T19:20:13.621+08:00
    :returns: datetime 对象，如果解析失败则返回 None
    """
    if not timestamp_str:
        return None
    try:
        # 处理带有毫秒的 ISO 格式
        return datetime.fromisoformat(timestamp_str)
    except (ValueError, TypeError):
        return None


def format_file_size(size_bytes: int) -> str:
    """格式化文件大小.

    :param size_bytes: 文件大小（字节）
    :returns: 人类可读的文件大小字符串，例如 "1.5 MB"
    """
    if size_bytes < 0:
        return "未知大小"

    units = [("B", 1), ("KB", 1024), ("MB", 1024**2), ("GB", 1024**3), ("TB", 1024**4)]

    for unit_name, unit_value in reversed(units):
        if size_bytes >= unit_value:
            size = size_bytes / unit_value
            return f"{size:.2f} {unit_name}"

    return f"{size_bytes} B"


def parse_file_info(file_data: dict[str, Any]) -> FileInfo:
    """从 API 响应中解析文件信息.

    :param file_data: API 响应中的文件数据字典
    :returns: FileInfo 对象
    """
    return FileInfo(
        file_id=file_data.get("id", ""),
        name=file_data.get("name", ""),
        size=int(file_data.get("size", 0)),
        mime_type=file_data.get("mime_type", ""),
        file_extension=file_data.get("file_extension", ""),
        created_time=parse_timestamp(file_data.get("created_time", "")),
        modified_time=parse_timestamp(file_data.get("modified_time", "")),
        md5_checksum=file_data.get("md5_checksum", ""),
        sha1_hash=file_data.get("hash", ""),
        icon_link=file_data.get("icon_link", ""),
        thumbnail_link=file_data.get("thumbnail_link", ""),
        web_content_link=file_data.get("web_content_link", ""),
        parent_id=file_data.get("parent_id", ""),
        file_category=file_data.get("file_category", ""),
    )


def parse_user_info(user_data: dict[str, Any]) -> UserInfo:
    """从 API 响应中解析用户信息.

    :param user_data: API 响应中的用户数据字典
    :returns: UserInfo 对象
    """
    return UserInfo(
        user_id=user_data.get("user_id", ""),
        nickname=user_data.get("nickname", ""),
        portrait_url=user_data.get("portrait_url", ""),
        avatar=user_data.get("avatar", ""),
    )


def parse_share_detail(api_response: dict[str, Any], share_id: str) -> ShareDetail:
    """从 API 响应中解析完整的分享详情.

    :param api_response: API 返回的 JSON 数据
    :param share_id: 分享 ID
    :returns: ShareDetail 对象
    """
    files_data = api_response.get("files", [])
    files = [parse_file_info(f) for f in files_data]

    user_data = api_response.get("user_info")
    user_info = parse_user_info(user_data) if user_data else None

    return ShareDetail(
        share_id=share_id,
        title=api_response.get("title", ""),
        share_status=api_response.get("share_status", ""),
        share_status_text=api_response.get("share_status_text", ""),
        file_num=int(api_response.get("file_num", 0)),
        expiration_left=api_response.get("expiration_left", ""),
        expiration_left_seconds=int(api_response.get("expiration_left_seconds", -1)),
        pass_code_token=api_response.get("pass_code_token", ""),
        files=files,
        user_info=user_info,
        icon_link=api_response.get("icon_link", ""),
        thumbnail_link=api_response.get("thumbnail_link", ""),
    )


def format_share_detail(detail: ShareDetail) -> str:
    """格式化分享详情为人类可读的字符串.

    :param detail: ShareDetail 对象
    :returns: 格式化后的详情字符串
    """
    lines = []
    lines.append("=" * 60)
    lines.append("迅雷分享链接详情")
    lines.append("=" * 60)

    # 基本信息
    lines.append(f"标题: {detail.title}")
    lines.append(
        f"分享状态: {detail.share_status} {'(有效)' if detail.is_valid else '(失效)'}"
    )
    lines.append(f"文件数量: {detail.file_count}")
    lines.append(f"总大小: {format_file_size(detail.total_size)}")

    if detail.expiration_left_seconds > 0:
        lines.append(f"剩余有效期: {detail.expiration_left}")
    else:
        lines.append("剩余有效期: 永久有效")

    # 分享者信息
    if detail.user_info:
        lines.append("-" * 60)
        lines.append("分享者信息")
        lines.append("-" * 60)
        lines.append(f"用户ID: {detail.user_info.user_id}")
        lines.append(f"昵称: {detail.user_info.nickname}")

    # 文件列表
    if detail.files:
        lines.append("-" * 60)
        lines.append("文件列表")
        lines.append("-" * 60)
        for i, file_info in enumerate(detail.files, 1):
            lines.append(f"\n[{i}] {file_info.name}")
            lines.append(f"    大小: {format_file_size(file_info.size)}")
            lines.append(f"    类型: {file_info.mime_type}")
            lines.append(f"    扩展名: {file_info.file_extension}")
            if file_info.created_time:
                lines.append(
                    f"    创建时间: {file_info.created_time.strftime('%Y-%m-%d %H:%M:%S')}"
                )
            if file_info.modified_time:
                lines.append(
                    f"    修改时间: {file_info.modified_time.strftime('%Y-%m-%d %H:%M:%S')}"
                )
            if file_info.sha1_hash:
                lines.append(f"    SHA1: {file_info.sha1_hash}")

    lines.append("=" * 60)
    return "\n".join(lines)
