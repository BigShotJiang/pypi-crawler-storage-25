"""同步/异步运行器 - 提供智能的 sync/async 桥接."""

from __future__ import annotations

import asyncio
from functools import partial
from typing import Any, Coroutine

import anyio

from xunlei_share_info.api_client import XunleiShareAPI


def _normalize_links(links: str | list[str]) -> list[str]:
    """标准化输入链接为列表.

    :param links: 分享链接或包含链接的文本，可以是字符串或字符串列表
    :returns: 清理后的链接列表
    """
    if isinstance(links, str):
        links = links.strip()
        # 判断是否为多行（每行一个链接）
        lines = [line.strip() for line in links.split("\n") if line.strip()]
        return lines if len(lines) > 1 else [links]
    return [link.strip() for link in links if link.strip()]


async def _async_runner(
    links: list[str],
    *,
    max_concurrent: int = 5,
    retries: int = 1,
    retry_delay: float = 2.0,
    timeout: float = 30.0,
) -> list[dict[str, Any]]:
    """异步运行器 - 在 async 环境中直接调用.

    :param links: 清理后的链接列表
    :param max_concurrent: 最大并发请求数
    :param retries: 重试次数
    :param retry_delay: 重试间隔秒数
    :param timeout: 请求超时秒数
    :returns: 详情字典列表
    """
    async with XunleiShareAPI(
        max_concurrent=max_concurrent,
        timeout=timeout,
        retries=retries,
        retry_delay=retry_delay,
    ) as api:
        return await api.get_share_details(links)


def _sync_runner(
    links: list[str],
    *,
    max_concurrent: int = 5,
    retries: int = 1,
    retry_delay: float = 2.0,
    timeout: float = 30.0,
) -> list[dict[str, Any]]:
    """同步运行器 - 在 sync 环境中通过 anyio.run 启动异步事件循环.

    :param links: 清理后的链接列表
    :param max_concurrent: 最大并发请求数
    :param retries: 重试次数
    :param retry_delay: 重试间隔秒数
    :param timeout: 请求超时秒数
    :returns: 详情字典列表
    """
    return anyio.run(
        partial(
            _async_runner,
            links,
            max_concurrent=max_concurrent,
            retries=retries,
            retry_delay=retry_delay,
            timeout=timeout,
        )
    )


def get_share_info(
    links: str | list[str],
    *,
    max_concurrent: int = 5,
    retries: int = 1,
    retry_delay: float = 2.0,
    timeout: float = 30.0,
) -> list[dict[str, Any]] | Coroutine[Any, Any, list[dict[str, Any]]]:
    """智能获取分享链接详情 - 自动检测同步/异步调用环境.

    同步环境调用:
        >>> result = get_share_info("https://pan.xunlei.com/s/xxx?pwd=yyy")
        >>> result = get_share_info(["链接1", "链接2"], max_concurrent=5)

    异步环境调用:
        >>> result = await get_share_info("https://pan.xunlei.com/s/xxx?pwd=yyy")
        >>> result = await get_share_info(["链接1", "链接2"], max_concurrent=5)

    :param links: 分享链接或包含链接的文本，可以是字符串或字符串列表
    :param max_concurrent: 最大并发请求数（默认 5）
    :param retries: 请求失败重试次数（默认 1）
    :param retry_delay: 重试间隔秒数（默认 2.0）
    :param timeout: 单个请求超时秒数（默认 30.0）
    :returns: 同步环境返回详情字典列表，异步环境返回协程对象
    """
    normalized = _normalize_links(links)

    # 检测是否在异步环境中
    try:
        asyncio.get_running_loop()
        # 异步环境：返回协程，等待调用方 await
        return _async_runner(
            normalized,
            max_concurrent=max_concurrent,
            retries=retries,
            retry_delay=retry_delay,
            timeout=timeout,
        )
    except RuntimeError:
        # 同步环境：启动事件循环并执行
        return _sync_runner(
            normalized,
            max_concurrent=max_concurrent,
            retries=retries,
            retry_delay=retry_delay,
            timeout=timeout,
        )
