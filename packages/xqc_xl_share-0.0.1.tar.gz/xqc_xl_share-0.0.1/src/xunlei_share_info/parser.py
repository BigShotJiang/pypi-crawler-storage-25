"""迅雷分享链接解析器."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class ShareLinkInfo:
    """分享链接解析后的信息."""

    share_id: str
    pass_code: Optional[str] = None

    @property
    def has_pass_code(self) -> bool:
        """是否有提取码."""
        return self.pass_code is not None and len(self.pass_code) > 0


def extract_links_from_text(text: str) -> list[ShareLinkInfo]:
    """从文本中智能提取分享链接和提取码.

    支持格式:
    - 纯链接: https://pan.xunlei.com/s/xxx?pwd=yyy
    - 纯链接无提取码: https://pan.xunlei.com/s/xxx
    - 复杂文本: 链接：https://pan.xunlei.com/s/xxx# 提取码：yyy 复制这段...
    - 多行文本中包含多个链接

    :param text: 包含分享链接的文本
    :returns: ShareLinkInfo 列表
    """
    text = text.strip()
    results = []

    # 尝试匹配复杂格式: 链接：URL# 提取码：xxx 或 链接：URL 提取码：xxx
    pattern_complex = re.compile(
        r"链接[:：]\s*(https?://pan\.xunlei\.com/s/([a-zA-Z0-9_-]+))"
        r"[^#]*?"
        r"(?:#.*?提取码[:：]\s*([a-zA-Z0-9]+)|提取码[:：]\s*([a-zA-Z0-9]+))",
    )

    for match in pattern_complex.finditer(text):
        share_id = match.group(2)
        pass_code = match.group(3) or match.group(4)
        results.append(ShareLinkInfo(share_id=share_id, pass_code=pass_code))

    if results:
        return results

    # 尝试标准 URL 格式（带 pwd 参数）
    pattern_with_pwd = re.compile(
        r"https?://pan\.xunlei\.com/s/([a-zA-Z0-9_-]+)\?pwd=([a-zA-Z0-9]+)"
    )
    for match in pattern_with_pwd.finditer(text):
        results.append(ShareLinkInfo(share_id=match.group(1), pass_code=match.group(2)))

    if results:
        return results

    # 尝试标准 URL 格式（无 pwd 参数）
    pattern_no_pwd = re.compile(r"https?://pan\.xunlei\.com/s/([a-zA-Z0-9_-]+)")
    for match in pattern_no_pwd.finditer(text):
        results.append(ShareLinkInfo(share_id=match.group(1)))

    if results:
        return results

    raise ValueError(f"未找到有效的迅雷分享链接: {text[:100]}")


def parse_share_link(url: str) -> ShareLinkInfo:
    """解析迅雷分享链接，提取 share_id 和提取码.

    :param url: 迅雷分享链接或包含链接的文本
    :returns: 包含 share_id 和 pass_code 的 ShareLinkInfo 对象
    :raises ValueError: 当链接格式不正确时抛出异常
    """
    results = extract_links_from_text(url)
    return results[0]
