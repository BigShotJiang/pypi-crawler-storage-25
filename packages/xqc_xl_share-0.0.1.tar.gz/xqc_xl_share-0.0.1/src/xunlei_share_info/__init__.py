"""迅雷分享链接解析器.

使用示例:
    >>> from xunlei_share_info import get_share_info
    >>> # 同步调用（普通环境）- 直接调用
    >>> result = get_share_info("https://pan.xunlei.com/s/xxx?pwd=yyy")
    >>> result = get_share_info(["链接1", "链接2"])
    >>> result = get_share_info("链接：https://pan.xunlei.com/s/xxx# 提取码：yyy")
    >>>
    >>> # 异步调用（async 环境）- 加 await
    >>> result = await get_share_info("https://pan.xunlei.com/s/xxx?pwd=yyy")
    >>>
    >>> # 控制并发数
    >>> get_share_info([...], max_concurrent=10)
    >>> await get_share_info([...], max_concurrent=10)  # 异步环境
"""

from __future__ import annotations

from xunlei_share_info.api_client import XunleiShareAPI
from xunlei_share_info.models import (
    FileInfo,
    ShareDetail,
    UserInfo,
    format_file_size,
    format_share_detail,
    parse_share_detail,
)
from xunlei_share_info.parser import (
    ShareLinkInfo,
    extract_links_from_text,
    parse_share_link,
)
from xunlei_share_info._runner import get_share_info

__all__ = [
    "FileInfo",
    "ShareDetail",
    "ShareLinkInfo",
    "UserInfo",
    "XunleiShareAPI",
    "extract_links_from_text",
    "format_file_size",
    "format_share_detail",
    "get_share_info",
    "parse_share_detail",
    "parse_share_link",
]
