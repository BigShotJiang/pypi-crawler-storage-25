from enum import StrEnum

import numpy as np
import pytest
from astropy.io import fits

from dkist_processing_common.models.fits_access import FitsAccessBase
from dkist_processing_common.models.fits_access import MetadataKey
from dkist_processing_common.parsers.l0_fits_access import L0FitsAccess
from dkist_processing_common.parsers.l1_fits_access import L1FitsAccess


@pytest.fixture(params=["history", "comment", "continue"])
def header_with_special_keys(complete_common_header, request):
    """
    A header that includes variations on the special keys that make headers different from dicts.

    The base complete_common_header already has history and comment cards so this fixture adds extras.
    """
    add_special = request.param
    header = complete_common_header
    if add_special == "history":
        header.add_history("test history")
        return header, request.param
    if add_special == "comment":
        header.add_comment("test comment")
        return header, request.param
    if add_special == "continue":
        header["LONG_VAL"] = " " * 100
        return header, request.param


@pytest.fixture()
def incomplete_common_header(complete_common_header):
    """
    A header missing two of the expected common by-frame keywords
    """
    incomplete_header = complete_common_header.copy()
    incomplete_header.pop(MetadataKey.elevation)
    incomplete_header.pop(MetadataKey.azimuth)
    return incomplete_header


class MetadataKeyWithNaxisKeys(StrEnum):
    naxis = "NAXIS"
    naxis1 = "NAXIS1"
    naxis2 = "NAXIS2"


class FitsAccessWithNaxisKeys(FitsAccessBase):
    def __init__(self, *, header, name):
        super().__init__(header=header, name=name)
        self.naxis = self.header[MetadataKeyWithNaxisKeys.naxis]
        self.naxis1 = self.header[MetadataKeyWithNaxisKeys.naxis1]
        self.naxis2 = self.header[MetadataKeyWithNaxisKeys.naxis2]


class FitsAccessWithModstate(L0FitsAccess):
    def __init__(
        self,
        *,
        header: fits.Header,
        name: str | None = None,
        auto_squeeze: bool = True,
    ):
        super().__init__(header=header, name=name, auto_squeeze=auto_squeeze)
        self.modulator_state = 5


def test_metadata_keys_in_access_bases(complete_common_header):
    """
    Given: a set of metadata key names in the MetadataKey sting enumeration
    When: the FITS access classes define a set of attributes/properties
    Then: the sets are the same and the values of the attributes/properties are correct
    """
    all_metadata_key_names = {mk.name for mk in MetadataKey}
    fits_obj = L0FitsAccess(header=complete_common_header)
    fits_access_defined_attributes = {
        k
        for k, v in fits_obj.__dict__.items()
        if k not in ["header", "_data", "name", "auto_squeeze"]
    }
    l0_access_properties = {k for k, v in L0FitsAccess.__dict__.items() if isinstance(v, property)}
    l1_access_properties = {k for k, v in L1FitsAccess.__dict__.items() if isinstance(v, property)}
    fits_access_properties = l0_access_properties | l1_access_properties
    assert fits_access_defined_attributes | fits_access_properties == all_metadata_key_names
    for key in fits_access_defined_attributes:
        assert getattr(fits_obj, key) == fits_obj.header[MetadataKey[key]]


def test_l0_fits_access(complete_common_header):
    """
    Given: A header with expected, common by-frame keywords and a data array
    When: Instantiating a L0FitsAccess instance with the header and data
    Then: values for common keywords are exposed as properties on the fits_obj class and the data is correct
    """
    data = np.arange(9).reshape(3, 3)
    fits_obj = L0FitsAccess(header=complete_common_header, data=data)
    assert fits_obj.elevation == 6.28
    assert fits_obj.azimuth == 3.14
    assert fits_obj.table_angle == 1.23
    assert fits_obj.time_obs == "2020-01-02T00:00:00.000000"
    assert fits_obj.name is None
    np.testing.assert_equal(fits_obj.data, data)


def test_l1_only_fits_access(complete_l1_only_header):
    """
    Given: A header with 214 L1-only values
    When: Loading the header with the L1FitsAccess class
    Then: No errors are raised and values are exposed
    """
    data = np.arange(9).reshape(3, 3)
    fits_obj = L1FitsAccess(header=complete_l1_only_header, data=data)
    assert fits_obj.elevation == 6.28
    assert fits_obj.azimuth == 3.14
    assert fits_obj.table_angle == 1.23
    assert fits_obj.time_obs == "2020-01-02T00:00:00.000000"
    assert fits_obj.name is None
    np.testing.assert_equal(fits_obj.data, data)


@pytest.mark.parametrize(
    "auto_squeeze",
    [pytest.param(True, id="auto_squeeze"), pytest.param(False, id="no_auto_squeeze")],
)
def test_none_data(complete_common_header, auto_squeeze):
    """
    Given: A full header
    When: Creating a `L0FitsAccess` object with `None` data and then accessing the data
    Then: `None` is returned
    """
    fits_obj = L0FitsAccess(header=complete_common_header, data=None, auto_squeeze=auto_squeeze)
    assert fits_obj.data is None


def test_no_header_value(incomplete_common_header):
    """
    Given: A header with missing common by-frame keywords
    When: Processing the HDU with the L0FitsAccess class
    Then: A KeyError is raised
    """
    with pytest.raises(KeyError):
        _ = L0FitsAccess(header=incomplete_common_header)


def test_as_subclass(complete_common_header):
    """
    Given: An instrument-specific fits_obj class that subclasses L0FitsAccess
    When: Processing a header with instrument-specific keywords
    Then: Both the common and instrument specific keywords values are available as properties in the
    derived class
    """

    class InstFitsAccess(L0FitsAccess):
        def __init__(self, header, name):
            super().__init__(header=header, name=name)
            self.foo: str = self.header["VISP_012"]

    fits_obj = InstFitsAccess(complete_common_header, name="foo")
    assert fits_obj.foo == "bar"
    assert fits_obj.elevation == 6.28
    assert fits_obj.azimuth == 3.14
    assert fits_obj.table_angle == 1.23
    assert fits_obj.time_obs == "2020-01-02T00:00:00.000000"
    assert fits_obj.name == "foo"


def test_squeezing_array(complete_common_header):
    """
    Given: A 3D array, where one axis has length 1
    When: Loading the data with the L0FitsAccess class
    Then: The data element only contains two axes, the third axis being removed
    """
    data = np.ones(shape=(1, 3, 3))
    fits_obj = L0FitsAccess(header=complete_common_header, data=data)
    assert len(fits_obj.data.shape) == 2


def test_squeezing_array_with_intentional_unitary_axis(
    complete_common_header,
):
    """
    Given: A 2D array, where one axis has length 1
    When: Loading the data with the L0FitsAccess class
    Then: The data element only contains two axes, with the 'squeeze' not taking effect
    """
    data = np.ones(shape=(1, 3))
    fits_obj = L0FitsAccess(header=complete_common_header, data=data)
    assert len(fits_obj.data.shape) == 2


def test_false_auto_squeeze(complete_common_header):
    """
    Given: A 3D array where all axes have length 1
    When: Loading the data with a FitsAccess class with auto_squeeze set to False
    Then: The full, 3D shape of the data is preserved
    """
    data = np.ones(shape=(1, 1, 1))
    fits_obj = L0FitsAccess(header=complete_common_header, data=data, auto_squeeze=False)
    assert fits_obj.data.shape == (1, 1, 1)


def test_setting_data(complete_common_header):
    """
    Given: A L0FitsAccess object with data and a header
    When: Setting the object's data property with a new array
    Then: The object's data are correctly updated
    """
    fits_obj = L0FitsAccess(header=complete_common_header, data=np.ones((3, 3)))
    new_array = np.random.random((10, 4))
    fits_obj.data = new_array
    np.testing.assert_equal(fits_obj.data, new_array)


def test_header_dict(header_with_special_keys):
    """
    Given: A FitsAccess object with a header including special header keys
    When: Accessing the header_dict method
    Then: The object's header is successfully exported as a dict of the same length as the header when accounting for multiple HISTORY or COMMENT cards
    """
    header, added_header_key = header_with_special_keys
    fits_obj = FitsAccessBase(header=header)
    assert isinstance(fits_obj.header_dict, dict)
    if added_header_key == "continue":
        assert len(fits_obj.header_dict) == len(fits_obj.header)
    if added_header_key in ["history", "comment"]:
        # HISTORY and COMMENT keys get "squeezed"
        assert len(fits_obj.header_dict) == len(fits_obj.header) - 1


def test_l0fitsaccess_modulator_state(complete_common_header):
    """
    Given: Instances of both the base `L0FitsAccess` class and a subclass of the same that defines the `modulator_state` property
    When: Accessing the `modulator_state` property on both classes
    Then: The base `L0FitsAccess` instance raises the appropriate error and the subclass returns the correct value
    """
    l0_obj = L0FitsAccess(header=complete_common_header)
    with pytest.raises(
        NotImplementedError,
        match="This property needs to be defined manually in an instrument subclass",
    ):
        _ = l0_obj.modulator_state

    child_obj = FitsAccessWithModstate(header=complete_common_header)
    assert child_obj.modulator_state == 5
