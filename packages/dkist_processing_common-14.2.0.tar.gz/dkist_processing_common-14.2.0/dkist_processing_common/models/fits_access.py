"""Abstraction layer for accessing fits data via class attributes."""

from __future__ import annotations

from enum import StrEnum
from enum import unique
from pathlib import Path

import numpy as np
from astropy.io import fits

HEADER_KEY_NOT_FOUND = "HEADER_KEY_NOT_FOUND"


@unique
class MetadataKey(StrEnum):
    """Controlled list of names for FITS metadata header keys."""

    ip_task_type = "IPTASK"  # in L0FitsAccess
    ip_start_time = "DKIST011"  # in L0FitsAccess
    ip_end_time = "DKIST012"  # in L0FitsAccess
    elevation = "ELEV_ANG"
    azimuth = "TAZIMUTH"
    table_angle = "TTBLANGL"
    gos_level3_status = "LVL3STAT"
    gos_level3_lamp_status = "LAMPSTAT"
    gos_polarizer_status = "LVL2STAT"
    gos_polarizer_angle = "POLANGLE"
    gos_retarder_status = "LVL1STAT"
    gos_retarder_angle = "RETANGLE"
    gos_level0_status = "LVL0STAT"
    time_obs = "DATE-BEG"
    ip_id = "IP_ID"
    instrument = "INSTRUME"
    wavelength = "LINEWAV"
    proposal_id = "PROP_ID"
    experiment_id = "EXPER_ID"
    num_dsps_repeats = "DSPSREPS"
    current_dsps_repeat = "DSPSNUM"
    fpa_exposure_time_ms = "XPOSURE"
    sensor_readout_exposure_time_ms = "TEXPOSUR"
    num_raw_frames_per_fpa = "NSUMEXP"
    camera_id = "CAM_ID"
    camera_name = "CAMERA"
    camera_bit_depth = "BITDEPTH"
    hardware_binning_x = "HWBIN1"
    hardware_binning_y = "HWBIN2"
    software_binning_x = "SWBIN1"
    software_binning_y = "SWBIN2"
    observing_program_execution_id = "OBSPR_ID"
    telescope_tracking_mode = "TELTRACK"
    coude_table_tracking_mode = "TTBLTRCK"
    telescope_scanning_mode = "TELSCAN"
    light_level = "LIGHTLVL"
    hls_version = "HLSVERS"


class FitsAccessBase:
    """
    Abstraction layer for accessing fits data via class attributes.

    .. note::
      The preferred method to load a FITS file into this class or its children is to use one of the `fits access codecs <dkist_processing_common.codecs.fits>`
      in combination with `~dkist_processing_common.tasks.base.WorkflowTaskBase.read`. Direct instantiation should only
      be used in unit tests or when `header` and `data` have been recently generated and only live in memory.

    Parameters
    ----------
    header
        The header from which to parse higher-level properties

    data
        A data array to associate with the current instance

    name
        An optional name that can be associated with the object

    auto_squeeze
        A boolean indicating whether to 'squeeze' out dimensions of size 1
    """

    def __init__(
        self,
        *,
        header: fits.Header,
        data: np.ndarray | None = None,
        name: str | Path | None = None,
        auto_squeeze: bool = True,
    ):
        self.header = header
        self._data = data
        self.name = name
        self.auto_squeeze = auto_squeeze

    def __repr__(self):
        return f"{self.__class__.__name__}(header={self.header!r}, data={self._data!r}, name={self.name!r}, auto_squeeze={self.auto_squeeze})"

    @property
    def data(self) -> np.ndarray | None:
        """
        Return the data array, with axes of length 1 removed if the array has three dimensions and the unit axis is the zeroth one.

        This is intended solely to remove the dummy dimension that is in raw data from the summit.

        Setting `auto_squeeze = False` when initializing this object will never squeeze out any dimensions

        Returns
        -------
        data array
        """
        if not self.auto_squeeze or self._data is None:
            return self._data

        # This conditional is explicitly to catch summit data with a dummy first axis for WCS
        # purposes
        if len(self._data.shape) == 3 and self._data.shape[0] == 1:
            return np.squeeze(self._data)

        return self._data

    @data.setter
    def data(self, array: np.ndarray) -> None:
        """
        Set the data array using an input data array.

        Note that this method does not update any keys in this object's `.header` (NAXIS, BITPIX, etc.). If the data and
        header of this object are to be written to disk, make sure to use the `~astropy.io.fits` interface, which will
        correctly update the header on write.

        Parameters
        ----------
        array
            The input array

        Returns
        -------
        None
        """
        self._data = array

    @property
    def header_dict(self) -> dict:
        """Return the header as a dict for this fits object with the special card values (HISTORY, COMMENT) as strings."""
        result = {}
        for card, value in self.header.items():
            if not isinstance(value, (int, float, str, bool)):
                result[card] = str(value)
            else:
                result[card] = value
        return result
