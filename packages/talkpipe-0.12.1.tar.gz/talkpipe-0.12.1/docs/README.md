# TalkPipe Documentation

Welcome to the TalkPipe documentation! This directory contains guides, API references, and examples for using TalkPipe effectively.

## Quick Navigation

### 🚀 [Getting Started](quickstart.md)
New to TalkPipe? Start here for installation, basic concepts, and your first pipeline.

### 📖 [RAG Commands](guides/makevectordatabase-and-serverag.md)
Create vector databases and run RAG servers in two commands: `makevectordatabase` and `serverag`.

### ⚙️ [Model and source configuration](guides/model-and-source-configuration.md)
Set default LLM and embedding providers via segment parameters, `~/.talkpipe.toml`, or environment variables.

### 🐳 [Container images](guides/container-images.md)
Pull multi-platform release images from GitHub Container Registry (`ghcr.io`), tags, and Docker/Podman usage.

### 💡 [Tutorials](tutorials/)
Real-world usage examples and tutorials:
- [Tutorial Overview](tutorials/) 
- [Tutorial 1: Document Indexing](tutorials/Tutorial_1-Document_Indexing/) - Basic TalkPipe concepts
- [Tutorial 2: Search & RAG](tutorials/Tutorial_2-Search_by_Example_and_RAG/) - Advanced search techniques
- [Tutorial 3: Report Writing](tutorials/Tutorial_3_Report_Writing/) - Automated report generation

### 📚 [API Reference](api-reference/)
Complete documentation for all TalkPipe commands and components:
- [chatterlang_serve](api-reference/chatterlang-server.md) - Run a script as an API endpoint with a customizable web interface
- [ChatterLang Workbench](api-reference/chatterlang-workbench.md) - Interactive web interface for writing and testing scripts interactively
- [ChatterLang Script Runner](api-reference/chatterlang-script.md) - Run a script from the command line
- [Documentation Generator](api-reference/talkpipe-ref.md) - Generate reference documentation for Segments and Sources
- [Plugin Manager](api-reference/talkpipe-plugin-manager.md) - Manage and inspect TalkPipe plugins

### 🏗️ [Architecture](architecture/)
Deep technical documentation:
- [Pipe API](architecture/pipe-api.md) - Internal DSL and pipeline construction
- [ChatterLang](architecture/chatterlang.md) - External DSL language reference
- [Extending TalkPipe](architecture/extending-talkpipe.md) - Creating custom components and plugins
- [Configuration](architecture/configuration.md) - Configuring variables for scripts

### 🧩 [Contributing / developer handbook](contributing/developer-handbook.md)
Glossary, repository conventions, shared parameter semantics (`set_as`, `field`, `field_list`, …), and standard `~/.talkpipe.toml` keys—reference material for contributors and advanced users.


## Contributing to Documentation

Found a gap or error? Documentation improvements are welcome! Please:
1. Check existing issues for the topic
2. Submit a pull request with your improvements
3. Follow the existing documentation style and structure
4. See [Documentation Formatting](architecture/documentation-formatting.md) for code block and example guidelines

---

*For the main project overview and installation instructions, see the [main README](../README.md).*