"""JSON Schema to IR parser.

This package converts JSON Schema objects into strongly-typed Intermediate Representation (IR) nodes.
The IR is designed to be adapter-agnostic, capturing JSON Schema semantics in a way that adapters
(Pydantic, etc.) can render to target validation libraries.

Public API:
- parse: Main entry point - converts JSON Schema dict to SchemaNode
- ParseContext, create_context: Context for parsing with cycle detection
- parse_string, parse_number: Primitive parsers (exported for testing/internal use)
- parse_object, parse_array, parse_tuple, parse_legacy_tuple: Collection parsers
- parse_all_of, parse_any_of, parse_one_of, parse_not, parse_conditional: Composition parsers
- parse_literal, parse_enum: Value parsers

Internal structure:
- core: Main parse() function and recursive parsing logic
- primitives: String, number, boolean, null type parsing
- collections: Object, array, tuple type parsing
- composition: allOf, anyOf, oneOf, not, if/then/else parsing
- values: const, enum parsing
- context: Parse context for cycle detection and ref resolution
"""

from valbridge_core.parser.core import parse
from valbridge_core.parser.context import ParseContext, create_context
from valbridge_core.parser.enriched import parse_enriched
from valbridge_core.parser.primitives import parse_number, parse_string
from valbridge_core.parser.collections import (
    parse_array,
    parse_legacy_tuple,
    parse_object,
    parse_tuple,
)
from valbridge_core.parser.composition import (
    parse_all_of,
    parse_any_of,
    parse_conditional,
    parse_not,
    parse_one_of,
)
from valbridge_core.parser.values import parse_enum, parse_literal

__all__ = [
    "parse",
    "parse_enriched",
    # Context
    "ParseContext",
    "create_context",
    # Primitive parsers
    "parse_string",
    "parse_number",
    # Collection parsers
    "parse_object",
    "parse_array",
    "parse_tuple",
    "parse_legacy_tuple",
    # Composition parsers
    "parse_all_of",
    "parse_any_of",
    "parse_one_of",
    "parse_not",
    "parse_conditional",
    # Value parsers
    "parse_literal",
    "parse_enum",
]
