import os
import click
from .commands.connect import connect_command
from .commands.upload import upload_command

# ── User-facing standalone entry points ─────────────────────────

@click.command()
@click.option("--name", required=True, help="VM name (e.g. 'training', 'inference')")
def connect_gpu(name):
    """Bind to an already-running GPU session"""
    connect_command(vm_name=name)

@click.command()
@click.option("--name", required=True, help="VM name")
@click.argument("args", nargs=-1, required=True)
def upload_gpu(name, args):
    """Upload files to your GPU container.

    \b
    Usage (scp-like):
      upload-gpu --name training file.py                  → /workspace/file.py
      upload-gpu --name training file.py models/          → /workspace/models/file.py
      upload-gpu --name training *.py src/ models/        → /workspace/models/{files}
    """
    if len(args) >= 2 and not os.path.exists(args[-1]):
        sources, dest = args[:-1], args[-1]
    else:
        sources, dest = args, ""
    upload_command(sources, dest, vm_name=name)
