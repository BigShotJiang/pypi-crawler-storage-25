from django.urls import path, include

urlpatterns = [
    path('', include('pretix_gpwebpay.urls')),
]
