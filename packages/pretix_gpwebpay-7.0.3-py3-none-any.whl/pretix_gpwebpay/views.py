import logging

from django.contrib import messages
from django.http import HttpRequest, HttpResponse, HttpResponseBadRequest
from django.shortcuts import redirect, get_object_or_404
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from pretix.base.models import OrderPayment

from .payment import GPWebPay

logger = logging.getLogger(__name__)

# All response fields that may appear per spec section 5.2 (DIGEST/DIGEST1 excluded).
_RESPONSE_FIELDS = GPWebPay._RESPONSE_DIGEST_FIELDS


def _collect_response_params(request: HttpRequest) -> dict:
    """Return all recognized response fields actually present in the request."""
    result = {}
    for field in _RESPONSE_FIELDS:
        value = request.GET.get(field) or request.POST.get(field)
        if value:
            result[field] = value
    return result


@method_decorator(csrf_exempt, name='dispatch')
class ReturnView(View):
    """Handle user redirect back from GPWebPay gateway."""

    def get(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        return self._handle_response(request, order, payment, order_secret)

    def post(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        return self._handle_response(request, order, payment, order_secret)

    def _handle_response(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        order_obj = None
        try:
            payment_obj = get_object_or_404(
                OrderPayment,
                id=payment,
                order__code=order,
                order__secret=order_secret,
            )
            order_obj = payment_obj.order
            event = order_obj.event

            provider = event.get_payment_providers().get('gpwebpay')
            if not provider:
                logger.error('GPWebPay provider not found for event %s', event.slug)
                messages.error(request, _('Payment provider not configured.'))
                return redirect(order_obj.get_abandon_url())

            public_key_data = provider.settings.get('public_key', '')
            merchant_number = provider.settings.get('merchant_number', '')
            if not public_key_data or not merchant_number:
                logger.error('GPWebPay keys/merchant not configured for event %s', event.slug)
                messages.error(request, _('Payment provider not configured properly.'))
                return redirect(order_obj.get_abandon_url())

            digest1 = request.GET.get('DIGEST1') or request.POST.get('DIGEST1')
            if not digest1:
                logger.error('GPWebPay return response missing DIGEST1 for payment %s', payment)
                messages.error(request, _('Payment verification failed.'))
                return redirect(order_obj.get_abandon_url())

            # Build digest from only the fields actually received, in spec table order,
            # then append MERCHANTNUMBER at the end (DIGEST1 definition).
            received = _collect_response_params(request)
            response_digest = provider._build_response_digest(received, merchant_number)

            if not provider._verify_signature(response_digest, digest1, public_key_data):
                logger.error('GPWebPay DIGEST1 verification failed for payment %s', payment)
                messages.error(request, _('Payment verification failed.'))
                return redirect(order_obj.get_abandon_url())

            prcode = received.get('PRCODE', '')
            srcode = received.get('SRCODE', '')
            resulttext = received.get('RESULTTEXT', '')

            if prcode == '0' and srcode == '0':
                if payment_obj.state == OrderPayment.PAYMENT_STATE_PENDING:
                    payment_obj.confirm()
                    logger.info('GPWebPay payment %s confirmed for order %s', payment, order)
                    messages.success(request, _('Payment successful!'))
                return redirect(order_obj.get_absolute_url())
            else:
                error_msg = resulttext or str(_('Payment failed.'))
                if payment_obj.state == OrderPayment.PAYMENT_STATE_PENDING:
                    payment_obj.fail(info={'error': error_msg, 'prcode': prcode, 'srcode': srcode})
                    logger.warning(
                        'GPWebPay payment %s failed for order %s: PRCODE=%s SRCODE=%s %s',
                        payment, order, prcode, srcode, resulttext,
                    )
                messages.error(request, error_msg)
                return redirect(order_obj.get_abandon_url())

        except Exception as e:
            logger.error('Error processing GPWebPay return for payment %s: %s', payment, e, exc_info=True)
            messages.error(request, _('An error occurred while processing your payment.'))
            if order_obj is not None:
                return redirect(order_obj.get_abandon_url())
            return HttpResponseBadRequest('Error processing payment')


@method_decorator(csrf_exempt, name='dispatch')
class NotifyView(View):
    """Handle server-to-server (IPN) notification from GPWebPay."""

    def get(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        return self._handle_notification(request, order, payment, order_secret)

    def post(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        return self._handle_notification(request, order, payment, order_secret)

    def _handle_notification(self, request: HttpRequest, order: str, payment: int, order_secret: str):
        try:
            payment_obj = get_object_or_404(
                OrderPayment,
                id=payment,
                order__code=order,
                order__secret=order_secret,
            )
            order_obj = payment_obj.order
            event = order_obj.event

            provider = event.get_payment_providers().get('gpwebpay')
            if not provider:
                logger.error('GPWebPay provider not found for event %s', event.slug)
                return HttpResponseBadRequest('Provider not configured')

            public_key_data = provider.settings.get('public_key', '')
            merchant_number = provider.settings.get('merchant_number', '')
            if not public_key_data or not merchant_number:
                logger.error('GPWebPay keys/merchant not configured for event %s', event.slug)
                return HttpResponseBadRequest('Provider not configured')

            digest1 = request.GET.get('DIGEST1') or request.POST.get('DIGEST1')
            if not digest1:
                logger.error('GPWebPay notification missing DIGEST1 for payment %s', payment)
                return HttpResponseBadRequest('Missing signature')

            received = _collect_response_params(request)
            response_digest = provider._build_response_digest(received, merchant_number)

            if not provider._verify_signature(response_digest, digest1, public_key_data):
                logger.error('GPWebPay DIGEST1 verification failed for notification payment %s', payment)
                return HttpResponseBadRequest('Invalid signature')

            prcode = received.get('PRCODE', '')
            srcode = received.get('SRCODE', '')
            resulttext = received.get('RESULTTEXT', '')

            if prcode == '0' and srcode == '0':
                if payment_obj.state == OrderPayment.PAYMENT_STATE_PENDING:
                    payment_obj.confirm()
                    logger.info('GPWebPay payment %s confirmed via IPN for order %s', payment, order)
            else:
                if payment_obj.state == OrderPayment.PAYMENT_STATE_PENDING:
                    payment_obj.fail(info={
                        'error': resulttext or 'Payment failed',
                        'prcode': prcode,
                        'srcode': srcode,
                    })
                    logger.warning(
                        'GPWebPay payment %s failed via IPN for order %s: PRCODE=%s SRCODE=%s %s',
                        payment, order, prcode, srcode, resulttext,
                    )

            return HttpResponse('OK')

        except Exception as e:
            logger.error('Error processing GPWebPay notification for payment %s: %s', payment, e, exc_info=True)
            return HttpResponseBadRequest('Error processing notification')
