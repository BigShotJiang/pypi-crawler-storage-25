__version__ = '7.0.3'

from .apps import PluginApp

PretixPluginMeta = PluginApp.PretixPluginMeta

default_app_config = 'pretix_gpwebpay.apps.PluginApp'
