from django.urls import path
from . import views

urlpatterns = [
    path('return/<str:order>/<int:payment>/<str:order_secret>/', views.ReturnView.as_view(), name='return'),
    path('notify/<str:order>/<int:payment>/<str:order_secret>/', views.NotifyView.as_view(), name='notify'),
]

