import logging
import urllib.parse
import uuid
from collections import OrderedDict
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Optional

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from django import forms
from django.http import HttpRequest, HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
from pretix.base.models import OrderPayment, OrderRefund
from pretix.base.payment import BasePaymentProvider, PaymentException
from pretix.control.forms import ExtFileField

logger = logging.getLogger(__name__)


class GPWebPaySettingsForm(forms.Form):
    merchant_number = forms.CharField(
        label=_('Merchant Number'),
        help_text=_('Your GPWebPay merchant number'),
        required=True,
        max_length=10,
    )
    private_key = ExtFileField(
        label=_('Private Key File'),
        help_text=_('Upload your GPWebPay private key file (.key or .pem format)'),
        required=True,
        ext_whitelist=('.key', '.pem', '.txt'),
    )
    private_key_password = forms.CharField(
        label=_('Private Key Password'),
        help_text=_('Password for your private key file'),
        required=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}),
    )
    public_key = ExtFileField(
        label=_('GPWebPay Public Key File'),
        help_text=_('Upload the GPWebPay public key file for signature verification'),
        required=True,
        ext_whitelist=('.key', '.pem', '.txt'),
    )
    gateway_url = forms.URLField(
        label=_('Gateway URL'),
        help_text=_('GPWebPay gateway URL (e.g., https://3dsecure.gpwebpay.com/pgw/order.do)'),
        required=True,
        initial='https://3dsecure.gpwebpay.com/pgw/order.do',
    )
    deposit_flag = forms.ChoiceField(
        label=_('Deposit flag'),
        choices=[
            ('1', _('1 — Authorize and capture immediately (recommended)')),
            ('0', _('0 — Authorize only, capture manually later')),
        ],
        initial='1',
        help_text=_('Controls whether the payment is captured immediately (1) or only authorized (0).'),
    )
    provider_code = forms.CharField(
        label=_('Provider Code'),
        help_text=_('4-digit acquirer identifier required for refunds (e.g., 0100 for Česká spořitelna). See GPWebPay documentation Annex 5.'),
        required=False,
        max_length=4,
        min_length=4,
    )
    ws_url = forms.URLField(
        label=_('WS API URL'),
        help_text=_('GPWebPay WS API URL for refunds (leave blank for default production URL)'),
        required=False,
        initial='https://3dsecure.gpwebpay.com/pay-ws/v1/PaymentService',
    )
    test_mode = forms.BooleanField(
        label=_('Test mode'),
        help_text=_('Enable test mode for development'),
        required=False,
        initial=False,
    )


class GPWebPay(BasePaymentProvider):
    identifier = 'gpwebpay'
    verbose_name = _('GPWebPay')
    public_name = _('GPWebPay')
    abort_pending_allowed = True
    refunds_allowed = True

    # Currencies where 1 unit = 1 smallest unit (no cents/haléře)
    _ZERO_DECIMAL_CURRENCIES = {'HUF', 'JPY', 'ISK', 'KRW', 'TWD'}

    # Request digest field order per spec section 5.1 table (Annex 1).
    # Only fields actually sent (non-empty) are included.
    _REQUEST_DIGEST_FIELDS = [
        'MERCHANTNUMBER', 'OPERATION', 'ORDERNUMBER', 'AMOUNT', 'CURRENCY',
        'DEPOSITFLAG', 'MERORDERNUM', 'URL', 'DESCRIPTION', 'MD', 'USERPARAM1',
        'VRCODE', 'FASTPAYID', 'PAYMETHOD', 'PAYMETHODS', 'EMAIL',
        'REFERENCENUMBER', 'ADDINFO', 'PANPATTERN', 'TOKEN', 'FASTTOKEN',
    ]

    # Response fields in spec table order (section 5.2). DIGEST and DIGEST1 excluded.
    # MERCHANTNUMBER is appended at the end for DIGEST1 verification.
    _RESPONSE_DIGEST_FIELDS = [
        'OPERATION', 'ORDERNUMBER', 'MERORDERNUM', 'MD', 'PRCODE', 'SRCODE',
        'RESULTTEXT', 'ADDINFO', 'TOKEN', 'EXPIRY', 'ACSRES', 'ACCODE',
        'PANPATTERN', 'DAYTOCAPTURE', 'TOKENREGSTATUS', 'ACRC', 'RRN', 'PAR', 'TRACEID',
    ]

    @property
    def settings_form_fields(self):
        fields = OrderedDict(super().settings_form_fields)
        fields.update(GPWebPaySettingsForm.base_fields)
        return fields

    def settings_form_clean(self, cleaned_data):
        """
        Process file uploads and store them as strings.
        Pretix's ExtFileField returns a file object.
        """
        # Handle private key file upload
        if 'private_key' in cleaned_data and cleaned_data['private_key']:
            file = cleaned_data['private_key']
            if hasattr(file, 'read'):
                file.seek(0)
                try:
                    cleaned_data['private_key'] = file.read().decode('utf-8')
                except UnicodeDecodeError:
                    # Try with different encoding or base64
                    file.seek(0)
                    import base64
                    cleaned_data['private_key'] = base64.b64encode(file.read()).decode('utf-8')
                file.seek(0)

        # Handle public key file upload
        if 'public_key' in cleaned_data and cleaned_data['public_key']:
            file = cleaned_data['public_key']
            if hasattr(file, 'read'):
                file.seek(0)
                try:
                    cleaned_data['public_key'] = file.read().decode('utf-8')
                except UnicodeDecodeError:
                    # Try with different encoding or base64
                    file.seek(0)
                    import base64
                    cleaned_data['public_key'] = base64.b64encode(file.read()).decode('utf-8')
                file.seek(0)

        return cleaned_data

    def settings_content_render(self, request):
        return """
        <p>Configure your GPWebPay payment gateway settings.</p>
        <p>You need to:</p>
        <ul>
            <li>Obtain your merchant number from GPWebPay</li>
            <li>Upload your private key file (used for signing requests)</li>
            <li>Upload GPWebPay's public key file (used for verifying responses)</li>
            <li>Configure the gateway URL (use test URL for testing)</li>
        </ul>
        """

    def payment_form_render(self, request) -> str:
        return ""

    def checkout_confirm_render(self, request, order=None, info_data=None) -> str:
        return ""

    def payment_is_valid_session(self, request):
        return True

    def execute_payment(self, request: HttpRequest, payment: OrderPayment) -> Optional[HttpResponse]:
        order = payment.order

        settings_dict = self.settings
        merchant_number = settings_dict.get('merchant_number', '')
        gateway_url = settings_dict.get('gateway_url', 'https://3dsecure.gpwebpay.com/pgw/order.do')
        private_key_data = settings_dict.get('private_key', '')
        private_key_password = settings_dict.get('private_key_password', '')
        deposit_flag = settings_dict.get('deposit_flag', '1')

        if not merchant_number or not private_key_data:
            raise PaymentException(_('GPWebPay is not configured properly.'))

        params = {
            'MERCHANTNUMBER': merchant_number,
            'OPERATION': 'CREATE_ORDER',
            'ORDERNUMBER': str(payment.id),
            'AMOUNT': str(self._get_amount(payment)),
            'CURRENCY': self._get_currency_code(order.currency),
            'DEPOSITFLAG': deposit_flag,
            'URL': request.build_absolute_uri(
                reverse('plugins:pretix_gpwebpay:return', kwargs={
                    'order': order.code,
                    'payment': payment.id,
                    'order_secret': payment.order.secret,
                })
            ),
            'DESCRIPTION': 'Order %s' % order.code,
            'MD': str(payment.id),
        }

        try:
            digest = self._generate_digest(params)
            signature = self._sign_message(digest, private_key_data, private_key_password)
            params['DIGEST'] = signature
        except Exception as e:
            logger.error('GPWebPay signing error: %s', e, exc_info=True)
            raise PaymentException(_('Error preparing payment request.'))

        # Redirect to GPWebPay
        return HttpResponseRedirect(f"{gateway_url}?{urllib.parse.urlencode(params)}")

    def _get_currency_code(self, currency: str) -> str:
        currency_map = {
            'CZK': '203',
            'EUR': '978',
            'USD': '840',
            'GBP': '826',
            'PLN': '985',
            'HUF': '348',
        }
        return currency_map.get(currency.upper(), '978')

    def _get_amount(self, payment: OrderPayment) -> int:
        """Return amount in the smallest currency unit per GPWebPay spec."""
        currency = payment.order.currency.upper()
        multiplier = 1 if currency in self._ZERO_DECIMAL_CURRENCIES else 100
        return int(
            (payment.amount * multiplier).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
        )

    def _generate_digest(self, params: Dict[str, str]) -> str:
        """Build request digest string per spec section 5.1 table order.
        Only non-empty fields are included; optional fields absent from params are skipped.
        """
        return '|'.join(params[f] for f in self._REQUEST_DIGEST_FIELDS if params.get(f))

    def _build_response_digest(self, received: Dict[str, str], merchant_number: str) -> str:
        """Build DIGEST1 verification string per spec section 5.2.
        Takes only fields actually received (non-empty), in spec table order,
        then appends MERCHANTNUMBER at the end.
        """
        parts = [received[f] for f in self._RESPONSE_DIGEST_FIELDS if received.get(f)]
        parts.append(merchant_number)
        return '|'.join(parts)

    def _sign_message(self, message: str, private_key_data: str, password: Optional[str] = None) -> str:
        """Sign message with RSA-SHA256/PKCS1v15 per GPWebPay spec. Returns Base64 signature."""
        import base64

        try:
            if private_key_data.startswith('-----BEGIN'):
                key_bytes = private_key_data.encode('utf-8')
            else:
                try:
                    key_bytes = base64.b64decode(private_key_data)
                    if not key_bytes.startswith(b'-----BEGIN'):
                        raise ValueError('Decoded data is not PEM')
                except Exception:
                    key_bytes = private_key_data.encode('utf-8')

            password_bytes = password.encode('utf-8') if password else None
            private_key = serialization.load_pem_private_key(
                key_bytes,
                password=password_bytes,
                backend=default_backend(),
            )
            signature = private_key.sign(message.encode('utf-8'), padding.PKCS1v15(), hashes.SHA256())
            return base64.b64encode(signature).decode('utf-8')
        except Exception as e:
            logger.error('GPWebPay signing error: %s', e, exc_info=True)
            raise

    def _verify_signature(self, message: str, signature: str, public_key_data: str) -> bool:
        """Verify RSA-SHA256/PKCS1v15 signature per GPWebPay spec. Returns False on any failure."""
        import base64

        try:
            if public_key_data.startswith('-----BEGIN'):
                key_bytes = public_key_data.encode('utf-8')
            else:
                try:
                    key_bytes = base64.b64decode(public_key_data)
                    if not key_bytes.startswith(b'-----BEGIN'):
                        raise ValueError('Decoded data is not PEM')
                except Exception:
                    key_bytes = public_key_data.encode('utf-8')

            public_key = serialization.load_pem_public_key(key_bytes, backend=default_backend())
            public_key.verify(
                base64.b64decode(signature),
                message.encode('utf-8'),
                padding.PKCS1v15(),
                hashes.SHA256(),
            )
            return True
        except Exception as e:
            logger.error('GPWebPay signature verification error: %s', e, exc_info=True)
            return False

    def execute_refund(self, refund: OrderRefund):
        """Execute refund via GPWebPay WS API processRefund operation."""
        payment = refund.payment
        merchant_number = self.settings.get('merchant_number', '')
        provider_code = self.settings.get('provider_code', '')
        private_key_data = self.settings.get('private_key', '')
        private_key_password = self.settings.get('private_key_password', '')
        public_key_data = self.settings.get('public_key', '')
        ws_url = self.settings.get(
            'ws_url',
            'https://3dsecure.gpwebpay.com/pay-ws/v1/PaymentService',
        )

        if not merchant_number or not provider_code or not private_key_data:
            raise PaymentException(_('GPWebPay refunds require provider code to be configured.'))

        message_id = uuid.uuid4().hex
        payment_number = str(payment.id)
        currency = payment.order.currency.upper()
        multiplier = 1 if currency in self._ZERO_DECIMAL_CURRENCIES else 100
        amount = str(int(
            (refund.amount * multiplier).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
        ))

        digest = '|'.join([message_id, provider_code, merchant_number, payment_number, amount])
        try:
            signature = self._sign_message(digest, private_key_data, private_key_password)
        except Exception as e:
            logger.error('GPWebPay refund signing error for payment %s: %s', payment.id, e)
            raise PaymentException(_('Error preparing refund request.'))

        soap_xml = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<soapenv:Envelope'
            ' xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
            ' xmlns:v1="http://gpe.cz/pay/pay-ws/proc/v1"'
            ' xmlns:type="http://gpe.cz/pay/pay-ws/core/type">'
            '<soapenv:Header/>'
            '<soapenv:Body>'
            '<v1:processRefund>'
            '<v1:refundRequest>'
            f'<type:messageId>{message_id}</type:messageId>'
            f'<type:provider>{provider_code}</type:provider>'
            f'<type:merchantNumber>{merchant_number}</type:merchantNumber>'
            f'<type:paymentNumber>{payment_number}</type:paymentNumber>'
            f'<type:amount>{amount}</type:amount>'
            f'<type:signature>{signature}</type:signature>'
            '</v1:refundRequest>'
            '</v1:processRefund>'
            '</soapenv:Body>'
            '</soapenv:Envelope>'
        )

        try:
            import requests as req_lib
            http_resp = req_lib.post(
                ws_url,
                data=soap_xml.encode('utf-8'),
                headers={
                    'Content-Type': 'text/xml; charset=utf-8',
                    'SOAPAction': '""',
                },
                timeout=30,
            )
            http_resp.raise_for_status()
        except Exception as e:
            logger.error('GPWebPay WS API error for payment %s refund: %s', payment.id, e)
            raise PaymentException(_('Error communicating with payment gateway.'))

        try:
            import xml.etree.ElementTree as ET
            root = ET.fromstring(http_resp.text)

            fault = root.find('.//{http://schemas.xmlsoap.org/soap/envelope/}Fault')
            if fault is not None:
                fault_string = fault.findtext('faultstring') or 'Unknown error'
                logger.error('GPWebPay WS SOAP fault for payment %s refund: %s', payment.id, fault_string)
                raise PaymentException(_('Refund was rejected by the payment gateway.'))

            resp_el = None
            for elem in root.iter():
                if elem.tag.endswith('}refundRequestResponse') or elem.tag == 'refundRequestResponse':
                    resp_el = elem
                    break

            if resp_el is None:
                logger.error('GPWebPay WS missing refundRequestResponse for payment %s', payment.id)
                raise PaymentException(_('Invalid refund response from payment gateway.'))

            def _find_text(parent, tag):
                for child in parent:
                    if child.tag.endswith('}' + tag) or child.tag == tag:
                        return child.text or ''
                return ''

            resp_msg_id = _find_text(resp_el, 'messageId')
            resp_state = _find_text(resp_el, 'state')
            resp_status = _find_text(resp_el, 'status')
            resp_substatus = _find_text(resp_el, 'subStatus')
            resp_signature = _find_text(resp_el, 'signature')

            if resp_signature and public_key_data:
                parts = [resp_msg_id, resp_state]
                if resp_status:
                    parts.append(resp_status)
                if resp_substatus:
                    parts.append(resp_substatus)
                if not self._verify_signature('|'.join(parts), resp_signature, public_key_data):
                    logger.error('GPWebPay WS response signature invalid for payment %s refund', payment.id)
                    raise PaymentException(_('Refund response verification failed.'))

            logger.info(
                'GPWebPay refund accepted for payment %s: state=%s status=%s subStatus=%s',
                payment.id, resp_state, resp_status, resp_substatus,
            )
            refund.done()
        except PaymentException:
            raise
        except Exception as e:
            logger.error('GPWebPay WS response parse error for payment %s refund: %s', payment.id, e)
            raise PaymentException(_('Error processing refund response.'))

    def payment_pending_render(self, request, payment: OrderPayment):
        return f"""
        <p>{_('Your payment is being processed.')}</p>
        <p>{_('Please wait...')}</p>
        """

    def payment_control_render(self, request, payment: OrderPayment):
        return f"""
        <dl class="dl-horizontal">
            <dt>{_('Payment ID')}</dt>
            <dd>{payment.id}</dd>
            <dt>{_('Status')}</dt>
            <dd>{payment.state}</dd>
        </dl>
        """

