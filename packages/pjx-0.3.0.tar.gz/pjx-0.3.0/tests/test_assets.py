from __future__ import annotations

from jinja2 import DictLoader
from pjx_ui.assets import UIBrowserAssetProvider

from pjx import PJXEnvironment
from pjx import assets as assets_module
from pjx.assets import AssetBuildStep, BrowserAsset, BrowserAssetFile
from pjx_tailwind.assets import TailwindBrowserAssetProvider


def test_document_injects_detected_assets_from_installed_providers():
    env = PJXEnvironment(
        loader=DictLoader(
            {
                "page.jinja": (
                    "<!DOCTYPE html>"
                    "<html><head><title>Demo</title></head>"
                    '<body><button hx-get="/users">Load</button>'
                    '<div data-controller="modal"></div></body></html>'
                )
            }
        ),
        asset_mode="cdn",
        asset_providers=["htmx", "stimulus"],
    )

    html = env.get_template("page.jinja").render()

    assert 'data-pjx-asset="htmx"' in html
    assert 'data-pjx-asset="stimulus"' in html
    assert "https://unpkg.com/htmx.org@2.0.4/dist/htmx.min.js" in html
    assert "https://unpkg.com/@hotwired/stimulus@3.2.2/dist/stimulus.umd.js" in html
    assert html.index('data-pjx-asset="htmx"') < html.index("</head>")
    assert html.index('data-pjx-asset="stimulus"') < html.index("</head>")


def test_fragments_do_not_get_browser_asset_tags():
    env = PJXEnvironment(
        loader=DictLoader({"fragment.jinja": '<button hx-get="/users">Load</button>'}),
        asset_mode="cdn",
        asset_providers=["htmx"],
    )

    html = env.get_template("fragment.jinja").render()

    assert 'data-pjx-asset="htmx"' not in html


def test_vendor_mode_uses_static_vendor_paths():
    env = PJXEnvironment(
        loader=DictLoader(
            {
                "page.jinja": (
                    "<!DOCTYPE html><html><head></head>"
                    '<body><button hx-post="/users">Save</button></body></html>'
                )
            }
        ),
        asset_mode="vendor",
        asset_base_url="/static/vendor/pjx",
        asset_providers=["htmx"],
    )

    html = env.get_template("page.jinja").render()

    assert 'src="/static/vendor/pjx/js/htmx.min.js"' in html


def test_existing_manual_asset_tag_is_not_duplicated():
    env = PJXEnvironment(
        loader=DictLoader(
            {
                "page.jinja": (
                    "<!DOCTYPE html><html><head>"
                    '<script src="https://unpkg.com/htmx.org@2.0.4/dist/htmx.min.js"></script>'
                    '</head><body><button hx-get="/users">Load</button></body></html>'
                )
            }
        ),
        asset_mode="cdn",
        asset_providers=["htmx"],
    )

    html = env.get_template("page.jinja").render()

    assert html.count("htmx.min.js") == 1


def test_generic_external_provider_can_inject_and_vendor(monkeypatch, tmp_path):
    class FakeProvider:
        name = "acme"

        def matches(self, html: str) -> bool:
            return "data-acme" in html

        def get_assets(self) -> tuple[BrowserAsset, ...]:
            return (
                BrowserAsset(
                    name="acme-runtime",
                    kind="script",
                    placement="head",
                    cdn_url="https://cdn.example.com/acme.js",
                    vendor_file=BrowserAssetFile(
                        relative_path="js/acme.js",
                        source_url="https://cdn.example.com/acme.js",
                    ),
                ),
            )

    fake_provider = FakeProvider()

    html = assets_module.inject_browser_assets(
        "<!DOCTYPE html><html><head></head><body><div data-acme></div></body></html>",
        mode="vendor",
        base_url="/static/vendor/pjx",
        providers=[fake_provider],
    )
    result = assets_module.build_vendor_assets(
        tmp_path,
        providers=[fake_provider],
        fetcher=lambda url: b"console.log('acme');",
    )

    assert 'src="/static/vendor/pjx/js/acme.js"' in html
    assert result.files_written == 1
    assert (tmp_path / "js" / "acme.js").read_text() == "console.log('acme');"


def test_tailwind_provider_detects_browser_style_usage():
    provider = TailwindBrowserAssetProvider()
    html = '<div class="bg-slate-900 text-white md:flex"></div>'

    assert provider.matches(html)


def test_ui_provider_injects_semantic_css_and_script():
    env = PJXEnvironment(
        loader=DictLoader(
            {
                "page.jinja": (
                    "<!DOCTYPE html><html><head></head>"
                    '<body><div class="ui-card">Hello</div></body></html>'
                )
            }
        ),
        asset_mode="vendor",
        asset_base_url="/static/vendor/pjx",
        asset_providers=["pjx-ui"],
    )

    html = env.get_template("page.jinja").render()

    assert 'href="/static/vendor/pjx/css/pjx-ui.css"' in html
    assert 'src="/static/vendor/pjx/js/pjx-ui.js"' in html


def test_ui_script_is_not_skipped_by_plain_text_mentions_in_page_body():
    env = PJXEnvironment(
        loader=DictLoader(
            {
                "page.jinja": (
                    "<!DOCTYPE html><html><head></head><body>"
                    '<div class="ui-card">The runtime lives in pjx-ui.js</div>'
                    "</body></html>"
                )
            }
        ),
        asset_mode="vendor",
        asset_base_url="/static/vendor/pjx",
        asset_providers=["pjx-ui", "stimulus"],
    )

    html = env.get_template("page.jinja").render()

    assert html.count('data-pjx-asset="pjx-ui"') == 1
    assert 'src="/static/vendor/pjx/js/pjx-ui.js"' in html


def test_bundled_assets_can_be_written_to_vendor_dir(tmp_path):
    result = assets_module.build_vendor_assets(tmp_path, providers=[UIBrowserAssetProvider()])

    assert result.files_written == 2
    assert (tmp_path / "css" / "pjx-ui.css").exists()
    assert (tmp_path / "js" / "pjx-ui.js").exists()


def test_ui_provider_exposes_css_build_step():
    provider = UIBrowserAssetProvider()

    steps = provider.get_build_steps()

    assert len(steps) == 1
    assert steps[0].name == "pjx-ui-css"
    assert steps[0].outputs[0].name == "pjx-ui.css"
    assert steps[0].command[0].endswith("tailwindcss")
    assert "-i" in steps[0].command


def test_build_vendor_assets_runs_provider_build_steps(monkeypatch, tmp_path):
    input_file = tmp_path / "tokens.css"
    output_file = tmp_path / "bundle.css"
    input_file.write_text(":root {}")

    class FakeProvider:
        name = "buildy"

        def matches(self, html: str) -> bool:
            return "buildy" in html

        def get_assets(self) -> tuple[BrowserAsset, ...]:
            return ()

        def get_build_steps(self) -> tuple[AssetBuildStep, ...]:
            return (
                AssetBuildStep(
                    name="buildy-css",
                    command=("fake-build",),
                    inputs=(input_file,),
                    outputs=(output_file,),
                    cwd=tmp_path,
                ),
            )

    seen: list[AssetBuildStep] = []

    def fake_run(step: AssetBuildStep) -> None:
        seen.append(step)
        output_file.write_text("compiled")

    monkeypatch.setattr(assets_module, "_run_build_step", fake_run)

    result = assets_module.build_vendor_assets(tmp_path, providers=[FakeProvider()])

    assert result.files_written == 0
    assert [step.name for step in seen] == ["buildy-css"]
    assert output_file.read_text() == "compiled"
