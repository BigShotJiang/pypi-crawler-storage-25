from __future__ import annotations

import pytest
from fastapi import Request
from httpx import ASGITransport, AsyncClient

from pjx.demo.app.deps import _user_service
from pjx.demo.app.main import app, server_error
from pjx.demo.app.models import User


@pytest.fixture(autouse=True)
def reset_user_service():
    _user_service._users = [
        User(id=1, name="Alice", email="alice@example.com", role="admin"),
        User(id=2, name="Bob", email="bob@example.com", role="user"),
    ]
    _user_service._next_id = 3


@pytest.fixture
def client():
    transport = ASGITransport(app=app)
    return AsyncClient(transport=transport, base_url="http://test")


@pytest.mark.anyio
async def test_demo_home_renders(client):
    response = await client.get("/")

    assert response.status_code == 200
    assert "PJX Demo" in response.text
    assert "Active records" in response.text
    assert "New user" in response.text
    assert 'data-pjx-asset="pjx-ui-css"' in response.text
    assert "/static/vendor/pjx/css/pjx-ui.css" in response.text
    assert "/static/vendor/pjx/js/pjx-ui.js" in response.text
    assert "tailwind.browser.js" not in response.text
    assert 'hx-get="/users/1/edit"' in response.text
    assert 'hx-delete="/users/1"' in response.text
    assert 'hx-swap="delete"' in response.text
    assert 'id="user-count-stat"' in response.text


@pytest.mark.anyio
async def test_demo_user_detail_renders(client):
    response = await client.get("/users/1")

    assert response.status_code == 200
    assert "Alice" in response.text
    assert "alice@example.com" in response.text
    assert 'hx-delete="/users/1"' in response.text
    assert 'hx-target="#detail-card"' in response.text


@pytest.mark.anyio
async def test_demo_create_user_returns_card_fragment(client):
    response = await client.post(
        "/users",
        content="name=Carol&email=carol@example.com&role=agent",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    assert response.status_code == 200
    assert "Carol" in response.text
    assert "carol@example.com" in response.text
    assert "user-3" in response.text
    assert 'hx-swap-oob="outerHTML"' in response.text
    assert 'id="user-form-shell"' in response.text


@pytest.mark.anyio
async def test_demo_edit_fragment_renders(client):
    response = await client.get("/users/1/edit")

    assert response.status_code == 200
    assert "Edit user" in response.text
    assert 'id="edit-modal"' in response.text
    assert 'data-ui-close="edit-modal"' in response.text
    assert 'class="ui-modal fixed inset-0 z-50 overflow-y-auto"' in response.text


@pytest.mark.anyio
async def test_demo_update_user_returns_card_fragment(client):
    response = await client.put(
        "/users/1",
        content="name=Alice+Updated&email=alice.updated%40example.com&role=admin",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    assert response.status_code == 200
    assert "Alice Updated" in response.text
    assert "alice.updated@example.com" in response.text


@pytest.mark.anyio
async def test_demo_not_found_uses_template(client):
    response = await client.get("/missing")

    assert response.status_code == 404
    assert "Page not found." in response.text


@pytest.mark.anyio
async def test_demo_server_error_template_renders():
    request = Request({"type": "http", "method": "GET", "path": "/boom", "headers": []})

    response = await server_error(request, Exception("boom"))

    assert response.status_code == 500
    assert "Something went wrong. Please try again." in response.body.decode()


@pytest.mark.anyio
async def test_demo_empty_state_renders_with_summary(client):
    _user_service._users = []

    response = await client.get("/")

    assert response.status_code == 200
    assert "No users have been added yet." in response.text
    assert "Use the form above to create the first record." in response.text
    assert 'id="user-count-stat"' in response.text


@pytest.mark.anyio
async def test_seo_page_renders(client):
    response = await client.get("/seo")

    assert response.status_code == 200
    assert "SEO Settings" in response.text
    assert "site_title" in response.text
    assert "sitemap.xml" in response.text
    assert "robots.txt" in response.text


@pytest.mark.anyio
async def test_seo_update(client):
    response = await client.put(
        "/seo",
        content="site_title=My+App&site_description=A+test+app&site_url=https://example.com&og_image=&robots_disallow=",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    assert response.status_code == 200
    assert "My App" in response.text
    assert "example.com" in response.text


@pytest.mark.anyio
async def test_sitemap_xml_endpoint(client):
    response = await client.get("/sitemap.xml")

    assert response.status_code == 200
    assert "<?xml" in response.text
    assert "<urlset" in response.text
    assert "<loc>" in response.text


@pytest.mark.anyio
async def test_robots_txt_endpoint(client):
    response = await client.get("/robots.txt")

    assert response.status_code == 200
    assert "User-agent:" in response.text
    assert "Sitemap:" in response.text
