from pjx.formatter import format_template


def test_reorders_sections():
    source = """---
interface Props {
  title: str
}

from ..layouts import Base

derived {
  greeting = "Hi " ~ title
}

state {
  color = "blue"
}
---

<h1>{{ greeting }}</h1>
"""
    result = format_template(source)
    lines = result.split("\n")
    # imports should come first, then interface Props, then state, then derived
    import_idx = next(i for i, ln in enumerate(lines) if "from" in ln)
    props_idx = next(i for i, ln in enumerate(lines) if "interface Props" in ln)
    state_idx = next(i for i, ln in enumerate(lines) if ln.strip() == "state {")
    derived_idx = next(i for i, ln in enumerate(lines) if ln.strip() == "derived {")
    assert import_idx < props_idx < state_idx < derived_idx


def test_no_frontmatter_passthrough():
    source = "<h1>Hello</h1>"
    assert format_template(source) == source


def test_already_formatted_new_syntax():
    source = """---
from ..layouts import Base

interface Props {
  title: str
}

state {
  color = "blue"
}

derived {
  greeting = "Hi " ~ title
}
---

<h1>{{ greeting }}</h1>
"""
    result = format_template(source)
    # Should remain stable (idempotent)
    assert format_template(result) == result


def test_slots_come_last():
    source = """---
slots {
  actions
}

interface Props {
  title: str
}

from ..layouts import Base
---

<h1>test</h1>
"""
    result = format_template(source)
    lines = result.split("\n")
    import_idx = next(i for i, ln in enumerate(lines) if "from" in ln)
    slot_idx = next(i for i, ln in enumerate(lines) if "slots {" in ln)
    assert import_idx < slot_idx


def test_multiline_derived_roundtrip():
    source = """---
derived {
  items = [
    "home",
    "base",
  ]
}
---

<div>test</div>
"""
    result = format_template(source)
    assert "derived {" in result
    assert "items = [" in result
    assert '    "home",' in result
    assert '    "base",' in result
    # Idempotent
    assert format_template(result) == result


def test_optional_props_preserved():
    source = """---
interface Props {
  title: str = "Test"
  active?: bool
}
---

<div>test</div>
"""
    result = format_template(source)
    assert "active?: bool" in result
    assert 'title: str = "Test"' in result
    assert format_template(result) == result
