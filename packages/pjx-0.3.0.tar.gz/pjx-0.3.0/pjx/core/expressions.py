from __future__ import annotations

import re

from pjx.core.types import ProcessorContext, ProcessorResult

# Match attr={expr} in attribute values, but NOT {{ expr }} (Jinja) or {% %} (Jinja tags)
ATTR_EXPR_RE = re.compile(
    r"""
    ([\w:.\-@]+)            # attribute name
    \s*=\s*                  # equals sign
    \{                       # opening brace
    (?!\{)                   # NOT followed by another { (would be Jinja {{ }})
    ([^}]+)                  # expression content
    \}                       # closing brace
    (?!\})                   # NOT followed by another } (would be Jinja {{ }})
    """,
    re.VERBOSE,
)

# Match {expr} in text content (outside of HTML tags)
# Must NOT match: {{ }}, {% %}, attr={expr}, {...spread}
TEXT_EXPR_RE = re.compile(
    r"""
    (?<![{\w=])             # NOT preceded by { (Jinja), word char, or = (attr)
    \{                       # opening brace
    (?!\{)                   # NOT Jinja {{
    (?!\%)                   # NOT Jinja {%
    (?!\.\.\.)               # NOT spread
    ([^}]+?)                 # expression content (non-greedy)
    \}                       # closing brace
    (?!\})                   # NOT Jinja }}
    """,
    re.VERBOSE,
)


_JINJA_BLOCK_RE = re.compile(r"\{[%{].*?[%}]\}", re.DOTALL)
_HTML_TAG_RE = re.compile(r"<[^>]+>", re.DOTALL)
_STYLE_SCRIPT_RE = re.compile(
    r"(<(?:style|script)\b[^>]*>)(.*?)(</(?:style|script)>)",
    re.DOTALL | re.IGNORECASE,
)


class ExpressionProcessor:
    def process(self, source: str, ctx: ProcessorContext) -> ProcessorResult:
        # Split source into Jinja blocks (preserved) and HTML segments (transformed)
        parts: list[str] = []
        last_end = 0
        for m in _JINJA_BLOCK_RE.finditer(source):
            segment = source[last_end : m.start()]
            parts.append(self._transform_segment(segment))
            parts.append(m.group(0))
            last_end = m.end()
        parts.append(self._transform_segment(source[last_end:]))
        return ProcessorResult(source="".join(parts))

    def _transform_segment(self, segment: str) -> str:
        """Transform both attr={expr} and text {expr} in a non-Jinja segment."""
        # First pass: transform attr={expr} inside HTML tags
        # Second pass: transform {expr} in text content (outside tags)
        result = ATTR_EXPR_RE.sub(self._replace_attr_expr, segment)
        result = self._transform_text_expressions(result)
        return result

    def _replace_attr_expr(self, match: re.Match) -> str:
        attr_name = match.group(1)
        expr = self._transform_slot_refs(match.group(2).strip())
        return f'{attr_name}="{{{{ {expr} }}}}"'

    def _transform_text_expressions(self, segment: str) -> str:
        """Transform {expr} in text content (outside HTML tags) to {{ expr }}.

        Skips <style> and <script> blocks entirely.
        """
        # First: protect style/script blocks from transformation
        protected: list[tuple[int, int, str]] = []
        for m in _STYLE_SCRIPT_RE.finditer(segment):
            protected.append((m.start(), m.end(), m.group(0)))

        # Split segment into HTML tags (preserved) and text (transformed)
        parts: list[str] = []
        last_end = 0
        for m in _HTML_TAG_RE.finditer(segment):
            text = segment[last_end : m.start()]
            if not self._in_protected(last_end, m.start(), protected):
                text = TEXT_EXPR_RE.sub(self._replace_text_expr, text)
            parts.append(text)
            parts.append(m.group(0))  # preserve HTML tag as-is
            last_end = m.end()
        text = segment[last_end:]
        if not self._in_protected(last_end, len(segment), protected):
            text = TEXT_EXPR_RE.sub(self._replace_text_expr, text)
        parts.append(text)
        return "".join(parts)

    def _in_protected(self, start: int, end: int, protected: list[tuple[int, int, str]]) -> bool:
        """Check if a text range falls inside a protected (style/script) block."""
        return any(start >= p_start and end <= p_end for p_start, p_end, _ in protected)

    def _replace_text_expr(self, match: re.Match) -> str:
        expr = self._transform_slot_refs(match.group(1).strip())
        if not expr:
            return match.group(0)
        return f"{{{{ {expr} }}}}"

    def _transform_slot_refs(self, expr: str) -> str:
        """Transform slot.name references to slot_name for Jinja2 compatibility."""
        return re.sub(r"\bslot\.(\w+)", r"slot_\1", expr)
