from __future__ import annotations

import re

from pjx.core.types import ProcessorContext, ProcessorResult
from pjx.errors import PJXError, SourceLocation
from pjx.models import (
    ComputedDecl,
    ImportDecl,
    PropDecl,
    SlotDecl,
    TemplateMetadata,
    VarDecl,
)

FRONTMATTER_DELIM = "---"
IMPORT_RE = re.compile(r"^from\s+(\S+)\s+import\s+(.+)$")

INTERFACE_OPEN_RE = re.compile(r"^interface\s+Props\s*\{$")
STATE_OPEN_RE = re.compile(r"^state\s*\{$")
DERIVED_OPEN_RE = re.compile(r"^derived\s*\{$")
SLOTS_OPEN_RE = re.compile(r"^slots\s*\{$")

PROP_RE = re.compile(r"^(\w+)(\??)\s*:\s*(.+?)(?:\s*=\s*(.+))?$")
STATE_ENTRY_RE = re.compile(r"^(\w+)\s*=\s*(.+)$")
DERIVED_ENTRY_RE = re.compile(r"^(\w+)\s*=\s*(.+)$")


def _brackets_balanced(text: str) -> bool:
    depth = 0
    in_single = False
    in_double = False
    in_backtick = False
    prev = ""
    for ch in text:
        if ch == "`" and not in_single and not in_double:
            in_backtick = not in_backtick
        elif ch == '"' and not in_single and not in_backtick and prev != "\\":
            in_double = not in_double
        elif ch == "'" and not in_double and not in_backtick and prev != "\\":
            in_single = not in_single
        elif not in_single and not in_double and not in_backtick:
            if ch in "[{":
                depth += 1
            elif ch in "]}":
                depth -= 1
        prev = ch
    return depth == 0


class FrontmatterProcessor:
    def process(self, source: str, ctx: ProcessorContext) -> ProcessorResult:
        if not source.startswith(FRONTMATTER_DELIM + "\n") and not source.startswith(
            FRONTMATTER_DELIM + "\r\n"
        ):
            return ProcessorResult(source=source)

        first_delim_end = source.index("\n") + 1
        second_delim_pos = source.find("\n" + FRONTMATTER_DELIM + "\n", first_delim_end)
        if second_delim_pos == -1:
            second_delim_pos = source.find("\n" + FRONTMATTER_DELIM + "\r\n", first_delim_end)
        if second_delim_pos == -1:
            if source.rstrip().endswith(FRONTMATTER_DELIM):
                second_delim_pos = source.rstrip().rfind(FRONTMATTER_DELIM) - 1
            else:
                raise PJXError(
                    "Unclosed frontmatter: missing second '---'",
                    SourceLocation(ctx.filename, 1, 1),
                    code="PJX001",
                )

        frontmatter_content = source[first_delim_end : second_delim_pos + 1]
        body_start = source.index("\n", second_delim_pos + 1) + 1
        body = source[body_start:]

        metadata = self._parse_frontmatter(frontmatter_content, ctx.filename)
        return ProcessorResult(source=body, metadata=metadata)

    def _parse_frontmatter(self, content: str, filename: str | None) -> TemplateMetadata:
        imports: list[ImportDecl] = []
        props: list[PropDecl] = []
        slots: list[SlotDecl] = []
        vars_: list[VarDecl] = []
        computed: list[ComputedDecl] = []

        lines = content.split("\n")
        i = 0

        while i < len(lines):
            line_num = i + 2
            line = lines[i].strip()

            if not line or line.startswith("#"):
                i += 1
                continue

            import_match = IMPORT_RE.match(line)
            if import_match:
                source_module = import_match.group(1)
                names = tuple(n.strip() for n in import_match.group(2).split(","))
                imports.append(ImportDecl(source=source_module, names=names))
                i += 1
                continue

            if INTERFACE_OPEN_RE.match(line):
                i, block_props = self._parse_interface_block(lines, i, filename)
                props.extend(block_props)
                continue

            if STATE_OPEN_RE.match(line):
                i, block_vars = self._parse_state_block(lines, i, filename)
                vars_.extend(block_vars)
                continue

            if DERIVED_OPEN_RE.match(line):
                i, block_computed = self._parse_derived_block(lines, i, filename)
                computed.extend(block_computed)
                continue

            if SLOTS_OPEN_RE.match(line):
                i, block_slots = self._parse_slots_block(lines, i, filename)
                slots.extend(block_slots)
                continue

            raise PJXError(
                f"Invalid frontmatter: '{line}'",
                SourceLocation(filename, line_num, 1),
                code="PJX002",
            )

        return TemplateMetadata(
            imports=imports,
            props=props,
            slots=slots,
            vars=vars_,
            computed=computed,
        )

    def _collect_block(
        self, lines: list[str], start: int, filename: str | None
    ) -> tuple[int, list[str]]:
        """Collect lines from the opening { to the matching }."""
        body: list[str] = []
        depth = 1
        i = start + 1
        while i < len(lines):
            line = lines[i].strip()
            if line == "}" and depth == 1:
                return i + 1, body
            for ch in line:
                if ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        before = line[: line.rindex("}")]
                        if before.strip():
                            body.append(before)
                        return i + 1, body
            body.append(lines[i])
            i += 1

        raise PJXError(
            "Unclosed block: missing '}'",
            SourceLocation(filename, start + 2, 1),
            code="PJX001",
        )

    def _parse_interface_block(
        self, lines: list[str], start: int, filename: str | None
    ) -> tuple[int, list[PropDecl]]:
        next_i, body = self._collect_block(lines, start, filename)
        props: list[PropDecl] = []
        for raw in body:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            m = PROP_RE.match(line)
            if m:
                name = m.group(1)
                optional = m.group(2) == "?"
                type_ann = m.group(3).strip()
                default = m.group(4)
                if default is not None:
                    default = default.strip()
                props.append(
                    PropDecl(
                        name=name, type_annotation=type_ann, default=default, optional=optional
                    )
                )
            else:
                raise PJXError(
                    f"Invalid prop declaration: '{line}'",
                    SourceLocation(filename, start + 2, 1),
                    code="PJX002",
                )
        return next_i, props

    def _parse_state_block(
        self, lines: list[str], start: int, filename: str | None
    ) -> tuple[int, list[VarDecl]]:
        next_i, body = self._collect_block(lines, start, filename)
        vars_: list[VarDecl] = []
        i = 0
        while i < len(body):
            line = body[i].strip()
            if not line or line.startswith("#"):
                i += 1
                continue
            m = STATE_ENTRY_RE.match(line)
            if m:
                name = m.group(1)
                value_str = m.group(2).strip()
                if not _brackets_balanced(value_str):
                    acc = [body[i]]
                    i += 1
                    found = False
                    while i < len(body):
                        acc.append(body[i])
                        joined = "\n".join(line.strip() for line in acc)
                        full = joined.split("=", 1)[1].strip() if "=" in joined else joined
                        if _brackets_balanced(full):
                            value_str = full
                            found = True
                            break
                        i += 1
                    if not found:
                        raise PJXError(
                            f"Unclosed brackets in state '{name}'",
                            SourceLocation(filename, start + 2, 1),
                            code="PJX003",
                        )
                vars_.append(VarDecl(name=name, value=value_str))
            else:
                raise PJXError(
                    f"Invalid state declaration: '{line}'",
                    SourceLocation(filename, start + 2, 1),
                    code="PJX002",
                )
            i += 1
        return next_i, vars_

    def _parse_derived_block(
        self, lines: list[str], start: int, filename: str | None
    ) -> tuple[int, list[ComputedDecl]]:
        next_i, body = self._collect_block(lines, start, filename)
        computed: list[ComputedDecl] = []
        i = 0
        while i < len(body):
            line = body[i].strip()
            if not line or line.startswith("#"):
                i += 1
                continue
            m = DERIVED_ENTRY_RE.match(line)
            if m:
                name = m.group(1)
                expr = m.group(2).strip()
                if not _brackets_balanced(expr):
                    acc = [body[i]]
                    i += 1
                    found = False
                    while i < len(body):
                        acc.append(body[i])
                        joined = "\n".join(line.strip() for line in acc)
                        full = joined.split("=", 1)[1].strip() if "=" in joined else joined
                        if _brackets_balanced(full):
                            expr = full
                            found = True
                            break
                        i += 1
                    if not found:
                        raise PJXError(
                            f"Unclosed brackets in derived '{name}'",
                            SourceLocation(filename, start + 2, 1),
                            code="PJX003",
                        )
                computed.append(ComputedDecl(name=name, expression=expr))
            else:
                raise PJXError(
                    f"Invalid derived declaration: '{line}'",
                    SourceLocation(filename, start + 2, 1),
                    code="PJX002",
                )
            i += 1
        return next_i, computed

    def _parse_slots_block(
        self, lines: list[str], start: int, filename: str | None
    ) -> tuple[int, list[SlotDecl]]:
        next_i, body = self._collect_block(lines, start, filename)
        slots: list[SlotDecl] = []
        for raw in body:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if re.match(r"^\w+$", line):
                slots.append(SlotDecl(name=line))
            else:
                raise PJXError(
                    f"Invalid slot declaration: '{line}'",
                    SourceLocation(filename, start + 2, 1),
                    code="PJX002",
                )
        return next_i, slots
