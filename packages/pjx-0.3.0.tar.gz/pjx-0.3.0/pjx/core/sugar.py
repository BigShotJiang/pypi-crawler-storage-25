from __future__ import annotations

import re

from pjx.core.types import ProcessorContext, ProcessorResult

_JINJA_BLOCK_RE = re.compile(r"\{[%{].*?[%}]\}", re.DOTALL)

# Match template literals: `text ${expr} more`
_TEMPLATE_LITERAL_RE = re.compile(r"`([^`]*)`")
_TEMPLATE_INTERP_RE = re.compile(r"\$\{([^}]+)\}")

# Match JS ternary: expr ? value : value
# Captures: (condition) ? (truthy) : (falsy)
# Handles nested parens/brackets but not nested ternaries
_TERNARY_RE = re.compile(
    r"""
    (?<![?])        # not preceded by ? (avoid ??)
    \?              # the ? operator
    (?![?.])        # not followed by ? or . (avoid ?. and ??)
    """,
    re.VERBOSE,
)

# Function-call sugar: len(x) → x | length, str(x) → x | string, etc.
_FUNCTION_SUGAR = {
    "len": "length",
    "str": "string",
    "int": "int",
    "float": "float",
}
_FUNC_CALL_RE = re.compile(r"\b(" + "|".join(_FUNCTION_SUGAR) + r")\s*\(([^)]+)\)")


def _transform_template_literal(match: re.Match) -> str:
    """Convert `text ${expr} more` to "text " ~ expr ~ " more"."""
    body = match.group(1)
    parts: list[str] = []
    last_end = 0
    for m in _TEMPLATE_INTERP_RE.finditer(body):
        text_before = body[last_end : m.start()]
        if text_before:
            parts.append(f'"{text_before}"')
        parts.append(m.group(1).strip())
        last_end = m.end()
    text_after = body[last_end:]
    if text_after:
        parts.append(f'"{text_after}"')
    if not parts:
        return '""'
    return " ~ ".join(parts)


def _transform_logical_ops(text: str) -> str:
    """Transform && → and, || → or, !expr → not expr (respecting != and strings)."""
    result: list[str] = []
    i = 0
    in_string: str | None = None

    while i < len(text):
        ch = text[i]

        # Track string boundaries
        if ch in ('"', "'") and (i == 0 or text[i - 1] != "\\"):
            if in_string is None:
                in_string = ch
            elif in_string == ch:
                in_string = None
            result.append(ch)
            i += 1
            continue

        if in_string is not None:
            result.append(ch)
            i += 1
            continue

        # && → and
        if ch == "&" and i + 1 < len(text) and text[i + 1] == "&":
            result.append("and")
            i += 2
            continue

        # || → or
        if ch == "|" and i + 1 < len(text) and text[i + 1] == "|":
            result.append("or")
            i += 2
            continue

        # ! → not (but not != or !!)
        if (
            ch == "!"
            and i + 1 < len(text)
            and text[i + 1] not in ("=", "!")
            and (i == 0 or text[i - 1] in (" ", "(", ",", "{", "["))
        ):
            result.append("not ")
            i += 1
            continue

        result.append(ch)
        i += 1

    return "".join(result)


def _transform_ternary(text: str) -> str:
    """Transform `cond ? truthy : falsy` to `truthy if cond else falsy`.

    Only handles simple (non-nested) ternaries. The condition is everything
    before `?`, truthy is between `?` and `:`, falsy is after `:`.
    Respects string boundaries and nested parens/brackets.
    """
    # Find the ? that acts as ternary operator
    q_pos = _find_ternary_question(text)
    if q_pos is None:
        return text

    # Find the matching : for this ternary
    colon_pos = _find_ternary_colon(text, q_pos + 1)
    if colon_pos is None:
        return text

    cond = text[:q_pos].strip()
    truthy = text[q_pos + 1 : colon_pos].strip()
    falsy = text[colon_pos + 1 :].strip()

    if not cond or not truthy or not falsy:
        return text

    return f"{truthy} if {cond} else {falsy}"


def _find_ternary_question(text: str) -> int | None:
    """Find the position of `?` acting as ternary operator."""
    depth = 0
    in_string: str | None = None

    for i, ch in enumerate(text):
        if ch in ('"', "'") and (i == 0 or text[i - 1] != "\\"):
            if in_string is None:
                in_string = ch
            elif in_string == ch:
                in_string = None
            continue
        if in_string is not None:
            continue
        if ch in ("(", "[", "{"):
            depth += 1
        elif ch in (")", "]", "}"):
            depth -= 1
        elif ch == "?" and depth == 0:
            # Not ?. or ?? or ?attr
            if i + 1 < len(text) and text[i + 1] in (".", "?"):
                continue
            # Not preceded by another ?
            if i > 0 and text[i - 1] == "?":
                continue
            return i
    return None


def _find_ternary_colon(text: str, start: int) -> int | None:
    """Find the position of `:` matching a ternary `?`, starting from `start`."""
    depth = 0
    in_string: str | None = None

    for i in range(start, len(text)):
        ch = text[i]
        if ch in ('"', "'") and (i == 0 or text[i - 1] != "\\"):
            if in_string is None:
                in_string = ch
            elif in_string == ch:
                in_string = None
            continue
        if in_string is not None:
            continue
        if ch in ("(", "[", "{"):
            depth += 1
        elif ch in (")", "]", "}"):
            depth -= 1
        elif ch == ":" and depth == 0:
            return i
    return None


def _transform_function_sugar(text: str) -> str:
    """Transform len(x) → x | length, str(x) → x | string, etc."""

    def _replace(match: re.Match) -> str:
        func = match.group(1)
        arg = match.group(2).strip()
        jinja_filter = _FUNCTION_SUGAR[func]
        return f"{arg} | {jinja_filter}"

    return _FUNC_CALL_RE.sub(_replace, text)


def transform_expression(text: str) -> str:
    """Apply all expression sugar transformations to a single expression."""
    result = _TEMPLATE_LITERAL_RE.sub(_transform_template_literal, text)
    result = _transform_function_sugar(result)
    result = _transform_logical_ops(result)
    result = _transform_ternary(result)
    return result


def _find_brace_expressions(text: str) -> list[tuple[int, int, str]]:
    """Find all {expr} blocks using bracket-balanced scanning.

    Returns list of (start, end, inner_expr) tuples.
    Skips {{ jinja }} and {... spread} patterns.
    """
    results: list[tuple[int, int, str]] = []
    i = 0
    while i < len(text):
        ch = text[i]

        # Skip {{ (Jinja expression)
        if ch == "{" and i + 1 < len(text) and text[i + 1] == "{":
            close = text.find("}}", i + 2)
            i = close + 2 if close != -1 else len(text)
            continue

        # Skip {% (Jinja tag)
        if ch == "{" and i + 1 < len(text) and text[i + 1] == "%":
            close = text.find("%}", i + 2)
            i = close + 2 if close != -1 else len(text)
            continue

        # Found a single { — potential expression
        if ch == "{":
            # Skip spread: {...obj}
            if i + 1 < len(text) and text[i + 1 : i + 4] == "...":
                # Find matching close brace
                depth = 1
                j = i + 1
                while j < len(text) and depth > 0:
                    if text[j] == "{":
                        depth += 1
                    elif text[j] == "}":
                        depth -= 1
                    j += 1
                i = j
                continue

            # Scan for matching } with bracket balancing
            depth = 1
            j = i + 1
            in_str: str | None = None
            in_backtick = False
            while j < len(text) and depth > 0:
                c = text[j]
                if c == "`" and not in_str:
                    in_backtick = not in_backtick
                elif c in ('"', "'") and not in_backtick and (j == 0 or text[j - 1] != "\\"):
                    if in_str is None:
                        in_str = c
                    elif in_str == c:
                        in_str = None
                elif not in_str and not in_backtick:
                    if c == "{":
                        depth += 1
                    elif c == "}":
                        depth -= 1
                j += 1

            if depth == 0:
                inner = text[i + 1 : j - 1]
                # Skip empty expressions
                if inner.strip():
                    results.append((i, j, inner))
                i = j
                continue

        i += 1
    return results


class ExpressionSugarProcessor:
    def process(self, source: str, ctx: ProcessorContext) -> ProcessorResult:
        # Split source preserving Jinja blocks
        parts: list[str] = []
        last_end = 0
        for m in _JINJA_BLOCK_RE.finditer(source):
            segment = source[last_end : m.start()]
            parts.append(self._transform_segment(segment))
            parts.append(m.group(0))
            last_end = m.end()
        parts.append(self._transform_segment(source[last_end:]))
        return ProcessorResult(source="".join(parts))

    def _transform_segment(self, segment: str) -> str:
        """Transform {expr} contents within a non-Jinja segment."""
        exprs = _find_brace_expressions(segment)
        if not exprs:
            return segment

        result: list[str] = []
        last = 0
        for start, end, inner in exprs:
            result.append(segment[last:start])
            transformed = transform_expression(inner)
            result.append("{" + transformed + "}")
            last = end
        result.append(segment[last:])
        return "".join(result)
