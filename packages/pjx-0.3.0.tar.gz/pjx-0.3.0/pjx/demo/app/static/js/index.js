function getErrorContainer(form) {
  if (!form) return document.getElementById("form-errors");
  return (
    form.querySelector("#edit-errors") ||
    form.querySelector("#form-errors") ||
    document.getElementById("form-errors")
  );
}

document.addEventListener("htmx:beforeRequest", function (event) {
  var form = event.detail && event.detail.elt && event.detail.elt.closest("form");
  var errors = getErrorContainer(form);
  if (errors) {
    errors.innerHTML = "";
  }
});

document.addEventListener("htmx:responseError", function (event) {
  if (!event.detail || !event.detail.xhr || event.detail.xhr.status !== 422) return;
  var form = event.detail.elt && event.detail.elt.closest("form");
  var errors = getErrorContainer(form);
  if (errors) {
    errors.innerHTML = event.detail.xhr.responseText;
  }
});

document.addEventListener("htmx:afterSwap", function (event) {
  var target = event.detail && event.detail.target;
  if (!target || target.id !== "modal-container") return;

  var autofocus = target.querySelector("input, select, textarea");
  if (autofocus && typeof autofocus.focus === "function") {
    autofocus.focus();
  }
});
