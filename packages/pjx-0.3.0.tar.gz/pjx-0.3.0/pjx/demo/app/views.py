"""View routes — HTML endpoints rendered with PJX templates."""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from jinja2 import FileSystemLoader

from pjx import PJXEnvironment
from pjx.router import FormData, PJXRouter
from pjx.seo import discover_pages, generate_robots, generate_sitemap

from .deps import get_seo_config, get_user_service, update_seo_config
from .models import (
    CreateUserForm,
    HomeProps,
    SeoConfig,
    SeoPageProps,
    UpdateUserForm,
    UserCardProps,
    UserDetailProps,
    UserMutationProps,
)
from .service import UserService

_HERE = Path(__file__).parent


def _template_search_paths() -> list[str]:
    paths = [str(_HERE / "templates")]
    try:
        from importlib.resources import files

        ui_templates = files("pjx_ui").joinpath("templates")
        if ui_templates.is_dir():
            paths.append(str(ui_templates))
    except (ImportError, TypeError):
        pass
    return paths


templates = Jinja2Templates(
    env=PJXEnvironment(
        loader=FileSystemLoader(_template_search_paths()),
        asset_mode=os.getenv("PJX_ASSET_MODE", "vendor"),
        asset_base_url=os.getenv("PJX_ASSET_BASE_URL", "/static/vendor/pjx"),
        asset_providers=["htmx", "stimulus", "pjx-ui"],
    )
)
ui = PJXRouter(templates)


@ui.page("/", "pages/home.jinja")
async def home(request: Request, svc: UserService = Depends(get_user_service)) -> HomeProps:
    return HomeProps(users=svc.list_all())


@ui.action(
    "/users",
    success_template="partials/create_user_response.jinja",
    error_template="partials/form_error.jinja",
)
async def create_user(
    request: Request,
    data: CreateUserForm = FormData(CreateUserForm),
    svc: UserService = Depends(get_user_service),
) -> UserMutationProps:
    user = svc.create(data)
    return UserMutationProps(
        id=user.id,
        name=user.name,
        email=user.email,
        role=user.role,
        total_count=len(svc.list_all()),
    )


@ui.fragment("/users/{user_id}/edit", "partials/edit_modal.jinja")
async def edit_user_form(
    request: Request, user_id: int, svc: UserService = Depends(get_user_service)
) -> UserCardProps:
    user = svc.get(user_id)
    return UserCardProps(id=user.id, name=user.name, email=user.email, role=user.role)


@ui.action(
    "/users/{user_id}",
    success_template="partials/update_user_response.jinja",
    error_template="partials/form_error.jinja",
    method="PUT",
)
async def update_user(
    request: Request,
    data: UpdateUserForm = FormData(UpdateUserForm),
    svc: UserService = Depends(get_user_service),
) -> UserMutationProps:
    user_id = int(request.path_params["user_id"])
    user = svc.update(user_id, data)
    return UserMutationProps(
        id=user.id,
        name=user.name,
        email=user.email,
        role=user.role,
        total_count=len(svc.list_all()),
    )


@ui.page("/users/{user_id}", "pages/users/[id].jinja")
async def user_detail(
    request: Request, user_id: int, svc: UserService = Depends(get_user_service)
) -> UserDetailProps:
    return UserDetailProps(user=svc.get(user_id))


def _build_seo_previews(config: SeoConfig) -> tuple[str, str]:
    entries = discover_pages(_HERE / "templates")
    sitemap = generate_sitemap(entries, config.site_url)
    disallow = [p.strip() for p in config.robots_disallow.split(",") if p.strip()] or None
    robots = generate_robots(config.site_url, disallow=disallow)
    return sitemap, robots


@ui.page("/seo", "pages/seo.jinja")
async def seo_page(request: Request) -> SeoPageProps:
    config = get_seo_config()
    sitemap, robots = _build_seo_previews(config)
    return SeoPageProps(config=config, sitemap_preview=sitemap, robots_preview=robots)


@ui.action(
    "/seo",
    success_template="partials/seo_preview.jinja",
    error_template="partials/form_error.jinja",
    method="PUT",
)
async def update_seo(request: Request, data: SeoConfig = FormData(SeoConfig)) -> SeoPageProps:
    update_seo_config(data)
    sitemap, robots = _build_seo_previews(data)
    return SeoPageProps(config=data, sitemap_preview=sitemap, robots_preview=robots)


@ui.delete("/users/{user_id}")
async def delete_user(
    request: Request,
    user_id: int,
    svc: UserService = Depends(get_user_service),
) -> HTMLResponse:
    user = svc.get(user_id)
    svc.delete(user_id)
    total_count = len(svc.list_all())
    context = {
        "request": request,
        "props": {
            "total_count": total_count,
            "name": user.name,
        },
        "params": dict(request.path_params),
    }
    target = request.headers.get("HX-Target", "")
    template = (
        "partials/delete_user_detail_response.jinja"
        if target == "detail-card"
        else "partials/delete_user_home_response.jinja"
    )
    return HTMLResponse(ui.render(template, context))
