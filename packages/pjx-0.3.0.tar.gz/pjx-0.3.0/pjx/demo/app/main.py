"""
PJX Demo — user CRUD with HTMX

Run with:
  fastapi dev demo/app/main.py
  uv run uvicorn demo.app.main:app --reload
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles

from pjx.seo import discover_pages, generate_robots, generate_sitemap

from .api import router as api_router
from .deps import get_seo_config
from .views import ui

_HERE = Path(__file__).parent

app = FastAPI(title="PJX Demo")
app.mount("/static", StaticFiles(directory=str(_HERE / "static")), name="static")
app.include_router(api_router)
app.include_router(ui)


@app.get("/sitemap.xml")
async def sitemap_endpoint() -> Response:
    config = get_seo_config()
    entries = discover_pages(_HERE / "templates")
    xml = generate_sitemap(entries, config.site_url)
    return Response(content=xml, media_type="application/xml")


@app.get("/robots.txt")
async def robots_endpoint() -> PlainTextResponse:
    config = get_seo_config()
    disallow = [p.strip() for p in config.robots_disallow.split(",") if p.strip()] or None
    robots = generate_robots(config.site_url, disallow=disallow)
    return PlainTextResponse(robots)


@app.exception_handler(404)
async def not_found(request: Request, exc: Exception) -> HTMLResponse:
    return HTMLResponse(ui.render("pages/404.jinja"), status_code=404)


@app.exception_handler(500)
async def server_error(request: Request, exc: Exception) -> HTMLResponse:
    return HTMLResponse(ui.render("pages/500.jinja"), status_code=500)
