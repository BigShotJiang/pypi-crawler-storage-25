from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, EmailStr, Field

Role = Literal["admin", "user", "agent"]


class User(BaseModel):
    id: int
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    role: Role = "user"


class CreateUserForm(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    role: Role = "user"


class UpdateUserForm(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    role: Role = "user"


class SeoConfig(BaseModel):
    site_title: str = "PJX Demo"
    site_description: str = "Small CRUD example built with PJX, HTMX, and pjx-ui components."
    site_url: str = "http://localhost:8000"
    og_image: str = ""
    robots_disallow: str = ""


class SeoPageProps(BaseModel):
    title: str = "SEO Settings"
    config: SeoConfig = SeoConfig()
    sitemap_preview: str = ""
    robots_preview: str = ""


class HomeProps(BaseModel):
    title: str = "PJX Demo"
    users: list[User] = []


class UserCardProps(BaseModel):
    id: int
    name: str
    email: str
    role: Role


class UserMutationProps(UserCardProps):
    total_count: int = 0


class UserDetailProps(BaseModel):
    user: User
