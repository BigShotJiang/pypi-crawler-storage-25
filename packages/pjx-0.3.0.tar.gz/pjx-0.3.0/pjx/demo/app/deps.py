from .models import SeoConfig
from .service import UserService

_user_service = UserService()
_seo_config = SeoConfig()


async def get_user_service() -> UserService:
    return _user_service


def get_seo_config() -> SeoConfig:
    return _seo_config


def update_seo_config(config: SeoConfig) -> None:
    global _seo_config
    _seo_config = config
