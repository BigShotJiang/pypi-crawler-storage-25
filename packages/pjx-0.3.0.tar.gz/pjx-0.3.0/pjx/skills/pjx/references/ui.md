# PJX UI — Component Library Reference

78 Tailwind + Stimulus components for PJX, organized in 7 categories.

## Install

```bash
pip install pjx-ui   # auto-registers via pjx.extensions entry point
```

## Import Pattern

```html
---
from pjx_ui.base import Button, Icon, Typography
from pjx_ui.layout import Flex, Grid, Container
from pjx_ui.nav import Navbar, Tabs, Breadcrumb
from pjx_ui.form import Input, Select, Field, Form
from pjx_ui.display import Card, Table, Badge, Tag
from pjx_ui.feedback import Modal, Drawer, Alert, Toast
from pjx_ui.sections import Hero, CTA, Feature
---
```

## Categories

### base (5)
Button, ButtonGroup, FloatButton, Icon, Typography

### layout (8)
Container, Divider, Flex, Grid, Layout, Sidebar, Space, Splitter

### nav (8)
Anchor, Breadcrumb, Dropdown, Menu, Navbar, Pagination, Steps, Tabs

### form (16)
AutoComplete, Checkbox, ColorPicker, DatePicker, Field, Form, Input,
InputGroup, InputNumber, Radio, Select, Slider, Switch, Textarea,
TimePicker, Upload

### display (21)
Avatar, Badge, Calendar, Card, Carousel, Collapse, Descriptions, Empty,
Image, Item, List, Popover, QRCode, Segmented, Statistic, Table, Tag,
Timeline, Tooltip, Transfer, Tree

### feedback (11)
Alert, Drawer, Message, Modal, Notification, Popconfirm, Progress, Result,
Skeleton, Spinner, Toast

### sections (9)
CTA, Feature, Footer, Gallery, Header, Hero, Pricing, Team, Testimonial

## Common Prop Patterns

All components accept `class` for custom Tailwind classes and `{...attrs}` for
extra HTML attributes.

```html
<Button variant="primary" size="lg" class="mt-4">Save</Button>
<Button variant="danger" disabled={true}>Delete</Button>
<Input type="email" placeholder="you@example.com" name="email" />
<Field label="Email" error={errors.email} required={true}>
  <Input type="email" name="email" id="email" />
</Field>
```

## Stimulus Controllers

Components auto-bind Stimulus controllers via `data-controller` attributes.
Key controllers and their features:

| Controller | Component | Features |
|------------|-----------|----------|
| ui-tabs | Tabs | Auto-bind click, ARIA roles, pills variant |
| ui-modal | Modal | Open/close, backdrop click, Escape key |
| ui-drawer | Drawer | Slide animation, Escape key, backdrop |
| ui-dropdown | Dropdown | Outside click, Escape key |
| ui-collapse | Collapse | Toggle body, icon rotation |
| ui-toast | Toast | Auto-dismiss with duration |
| ui-carousel | Carousel | Autoplay, prev/next navigation |
| ui-sidebar | Sidebar | Collapsible, localStorage persistence |
| ui-calendar | Calendar | Month/year navigation, day selection |
| ui-popconfirm | Popconfirm | Confirm/cancel, outside click, Escape |
| ui-field | Field | Inline validation on blur |
| ui-switch | Switch | Visual sync with checkbox state |
| ui-pagination | Pagination | Page navigation, active state |
| ui-tree | Tree | Expand/collapse nodes |
| ui-popover | Popover | Toggle panel, outside click |

## Layout Components

### Grid
```html
<Grid cols="3" gap="6" class="sm:grid-cols-2 xl:grid-cols-4">
  <Card>...</Card>
  <Card>...</Card>
</Grid>
```
Supported `cols`: 1-6, 12. Supported `gap`: 0-6, 8.

### Flex
```html
<Flex align="center" justify="between" gap="4" wrap={true}>
  <Button>Left</Button>
  <Button>Right</Button>
</Flex>
```
Props: `direction` (row/col/row-reverse/col-reverse), `align`, `justify`, `gap`, `wrap`.

## Form Pattern

```html
<Form action="/submit" method="POST">
  <Field label="Name" required={true} id="name">
    <Input name="name" id="name" placeholder="Your name" />
  </Field>
  <Field label="Role" id="role">
    <Select name="role" id="role">
      <option value="admin">Admin</option>
      <option value="user">User</option>
    </Select>
  </Field>
  <Button variant="primary" type="submit">Submit</Button>
</Form>
```

## Feedback Pattern

```html
<Button data-action="click->ui-modal#open">Open Modal</Button>
<Modal title="Confirm">
  <p>Are you sure?</p>
  <Flex gap="2" justify="end">
    <Button data-action="click->ui-modal#close">Cancel</Button>
    <Button variant="primary">Confirm</Button>
  </Flex>
</Modal>
```

Modal, Drawer, Dropdown, and Popconfirm all close with Escape key.
