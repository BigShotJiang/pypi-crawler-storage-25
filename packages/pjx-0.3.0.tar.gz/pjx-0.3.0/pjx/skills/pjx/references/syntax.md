# PJX Template Syntax

## Frontmatter

Every `.jinja` file can start with a `---` block declaring metadata:

```html
---
from ..layouts import BaseLayout
from ..components import UserCard

interface Props {
  title: str = "Dashboard"
  users: list = []
  active?: bool
}

state {
  card_class = "rounded shadow p-4"
  roles = {
    admin: "badge-red",
    user: "badge-gray",
  }
}

derived {
  has_users = len(users) > 0
  greeting = `Welcome to ${title}`
}

slots {
  children
  actions
}
---
```

**Section order** (enforced by `pjx format`):
imports -> interface Props -> state -> derived -> slots

## Control Flow

```html
<!-- Loop -->
<For each={items} as="item">
  <li>{item.name}</li>
</For>

<!-- Loop with index -->
<For each={items} as="item" index="i">
  <li>{i + 1}. {item.name}</li>
</For>

<!-- Loop with destructuring -->
<For each={config.items()} as="key, value">
  <dt>{key}</dt><dd>{value}</dd>
</For>

<!-- Conditional -->
<Show when={user.active}>
  <span>Active</span>
  <Else>
    <span>Inactive</span>
  </Else>
</Show>

<!-- ElseIf -->
<Show when={role == "admin"}>
  <AdminPanel />
  <ElseIf when={role == "editor"}>
    <EditorPanel />
  </ElseIf>
  <Else>
    <ViewerPanel />
  </Else>
</Show>

<!-- Switch -->
<Switch expr={user.role}>
  <Case value="admin"><span>Admin</span></Case>
  <Case when={level > 5}><span>Senior</span></Case>
  <Default><span>User</span></Default>
</Switch>

<!-- Fragment: render children without wrapper -->
<Fragment>
  <span>A</span>
  <span>B</span>
</Fragment>
```

## Expressions

`{expr}` works in both attributes and text content:

```html
<a href={"/users/" ~ user.id}>{user.name}</a>
<h1>{title}</h1>
<p>{len(items)} items found</p>
```

### Expression Sugar

JS-style operators are supported alongside Python/Jinja2 equivalents:

| Sugar | Compiles to | Example |
|-------|------------|---------|
| `&&` | `and` | `active && visible` |
| `\|\|` | `or` | `a \|\| b` |
| `!` | `not` | `!disabled` |
| `a ? b : c` | `b if a else c` | `admin ? "red" : "gray"` |
| `len(x)` | `x \| length` | `len(items) > 0` |
| `str(x)` | `x \| string` | `str(count)` |
| `` `text ${expr}` `` | `"text " ~ expr` | `` `/users/${id}` `` |

## Conditional Attributes

`?attr={expr}` — includes the attribute only when truthy:

```html
<div ?hidden={!visible}>content</div>
<option value="admin" ?selected={role == "admin"}>Admin</option>
<input ?required={is_required} ?disabled={is_disabled} />
```

## Spread Attributes

`{...dict}` — expands a dict as HTML attributes:

```html
<div class="base" {...extra_attrs}>content</div>
```

## Components

Uppercase tags imported via frontmatter. Compiled to `{% include %}`:

```html
---
from ..components import UserCard
---

<!-- Self-closing -->
<UserCard id={user.id} name={user.name} />

<!-- With children (template receives {children}) -->
<BaseLayout title={title}>
  <h1>Page content</h1>
</BaseLayout>
```

## Named Slots

Components can define named slots for structured content passing:

```html
<!-- Parent: pass named slots -->
<Card title="Users">
  Default content goes to {children}

  <slot:actions>
    <Button>Add User</Button>
  </slot:actions>

  <slot:footer>
    <Pagination total={count} />
  </slot:footer>
</Card>

<!-- Card.jinja: render named slots -->
---
slots {
  children
  actions
  footer
}
---

<div class="card-body">{children}</div>
<Show when={slot.actions}>
  <div class="card-actions">{slot.actions}</div>
</Show>
<Show when={slot.footer}>
  <div class="card-footer">{slot.footer}</div>
</Show>
```

## Template Variables

### state — static values

```html
---
state {
  color = "blue"
  count = 42
  tags = ["alpha", "beta"]
  sizes = {
    sm: "h-8 px-3",
    md: "h-10 px-4",
  }
}
---
<div class={sizes[size]}>...</div>
```

### derived — computed values

```html
---
interface Props {
  first: str
  last: str
}

derived {
  full_name = first ~ " " ~ last
  is_long = len(full_name) > 20
}
---
<h1>{full_name}</h1>
```

### Multiline derived (bracket-balanced)

```html
---
derived {
  items = [
    { key: "home", label: "Overview", url: "/" },
    { key: "base", label: "Base", url: "/base" },
  ]
}
---
<For each={items} as="item">
  <a href={item.url}>{item.label}</a>
</For>
```

## HTMX Aliases (requires pjx[htmx])

```html
<button htmx:post="/users" htmx:target="#list" htmx:swap="innerHTML">
  Save
</button>

<div sse:connect="/events" sse:swap="message"></div>
```

## Stimulus Aliases (requires pjx[stimulus])

```html
<div stimulus:controller="dropdown">
  <button stimulus:action="click->dropdown#toggle">Menu</button>
  <div stimulus:target="menu">Content</div>
</div>
```

## cn() (requires pjx[tailwind])

Class-name merging — filters falsy, deduplicates:

```html
---
derived {
  cls = cn("btn", is_primary && "btn-primary", disabled && "opacity-50")
}
---
<button class={cls}>Click</button>
```

## Compilation Table

| PJX | Compiles to |
| --- | --- |
| `<For each={items} as="item">` | `{% for item in items %}` |
| `<For each={items} as="item" index="i">` | `{% for item in items %}{% set i = loop.index0 %}` |
| `<Show when={cond}>` | `{% if cond %}` |
| `<ElseIf when={cond}>` | `{% elif cond %}` |
| `<Else>` | `{% else %}` |
| `<Switch>/<Case>/<Default>` | `{% if %}/{% elif %}/{% else %}` |
| `<Fragment>` | (removed) |
| `<Card name={x} />` | `{% with name=x %}{% include %}{% endwith %}` |
| `href={url}` | `href="{{ url }}"` |
| `{expr}` (in text) | `{{ expr }}` |
| `?hidden={expr}` | `{% if expr %}hidden="{{ expr }}"{% endif %}` |
| `{...attrs}` | `{{ attrs \| xmlattr }}` |
| `<slot:name>...</slot:name>` | `{% set slot_name %}...{% endset %}` |
| `{slot.name}` | `{{ slot_name }}` |
| `&&` / `\|\|` / `!` | `and` / `or` / `not` |
| `a ? b : c` | `b if a else c` |
| `len(x)` | `x \| length` |
| `` `text ${x}` `` | `"text " ~ x` |
| `interface Props { }` | `{% set name = name \| default(...) %}` |
| `state { x = val }` | `{% set x = val %}` |
| `derived { x = expr }` | `{% set x = expr %}` |
