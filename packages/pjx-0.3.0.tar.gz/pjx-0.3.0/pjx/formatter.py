from __future__ import annotations

from pathlib import Path

from pjx.core.frontmatter import FrontmatterProcessor
from pjx.core.types import ProcessorContext
from pjx.errors import PJXError

FRONTMATTER_DELIM = "---"


def format_template(source: str) -> str:
    if not source.startswith(FRONTMATTER_DELIM + "\n") and not source.startswith(
        FRONTMATTER_DELIM + "\r\n"
    ):
        return source

    processor = FrontmatterProcessor()
    try:
        result = processor.process(source, ProcessorContext())
    except PJXError:
        return source

    if result.metadata is None:
        return source

    frontmatter = _format_metadata(result.metadata)
    return FRONTMATTER_DELIM + "\n" + frontmatter + FRONTMATTER_DELIM + "\n" + result.source


def _format_metadata(metadata: object) -> str:
    from pjx.models import TemplateMetadata

    assert isinstance(metadata, TemplateMetadata)
    parts: list[str] = []

    if metadata.imports:
        parts.extend(f"from {imp.source} import {', '.join(imp.names)}" for imp in metadata.imports)

    if metadata.props:
        prop_lines: list[str] = []
        for prop in metadata.props:
            opt = "?" if prop.optional else ""
            line = f"  {prop.name}{opt}: {prop.type_annotation}"
            if prop.default is not None:
                line += f" = {prop.default}"
            prop_lines.append(line)
        _append_block(parts, "interface Props", prop_lines)

    if metadata.vars:
        var_lines: list[str] = []
        for var in metadata.vars:
            var_lines.append(f"  {var.name} = {var.value}")
        _append_block(parts, "state", var_lines)

    if metadata.computed:
        computed_lines: list[str] = []
        for comp in metadata.computed:
            if "\n" in comp.expression:
                expr_lines = comp.expression.split("\n")
                computed_lines.append(f"  {comp.name} = {expr_lines[0]}")
                computed_lines.extend(f"    {line}" for line in expr_lines[1:])
            else:
                computed_lines.append(f"  {comp.name} = {comp.expression}")
        _append_block(parts, "derived", computed_lines)

    if metadata.slots:
        slot_lines = [f"  {slot.name}" for slot in metadata.slots]
        _append_block(parts, "slots", slot_lines)

    if parts:
        parts.append("")

    return "\n".join(parts)


def _append_block(parts: list[str], header: str, lines: list[str]) -> None:
    if not lines:
        return
    if parts:
        parts.append("")
    parts.append(f"{header} {{")
    parts.extend(lines)
    parts.append("}")


def format_file(path: Path) -> bool:
    source = path.read_text()
    formatted = format_template(source)
    if formatted != source:
        path.write_text(formatted)
        return True
    return False


def check_format(path: Path) -> bool:
    source = path.read_text()
    formatted = format_template(source)
    return formatted == source
