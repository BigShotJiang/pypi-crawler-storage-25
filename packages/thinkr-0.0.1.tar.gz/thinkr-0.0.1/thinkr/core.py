def hill_climbing():
    return """
Hill Climbing Algorithm:

A local search algorithm that continuously moves towards better states.

Steps:
1. Start with initial solution
2. Generate neighbors
3. Move to better neighbor
4. Stop at local optimum
"""
