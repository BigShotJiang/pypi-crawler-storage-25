# Thinkr

AI theory as Python functions.

## Usage

```python
from thinkr import hill_climbing

print(hill_climbing())