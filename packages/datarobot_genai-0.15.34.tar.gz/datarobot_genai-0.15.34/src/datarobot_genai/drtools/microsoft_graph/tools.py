# Copyright 2026 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Microsoft Graph MCP tools for searching SharePoint and OneDrive content."""

import logging
from typing import Annotated
from typing import Any
from typing import Literal

from datarobot_genai.drtools.core import tool_metadata
from datarobot_genai.drtools.core.clients.microsoft_graph import MicrosoftGraphClient
from datarobot_genai.drtools.core.clients.microsoft_graph import get_microsoft_graph_access_token
from datarobot_genai.drtools.core.clients.microsoft_graph import validate_site_url
from datarobot_genai.drtools.core.exceptions import ToolError
from datarobot_genai.drtools.core.exceptions import ToolErrorKind

logger = logging.getLogger(__name__)

_MS_SEARCH_QUERY = "https://learn.microsoft.com/en-us/graph/api/search-query"
_MS_SEARCH_FILES = "https://learn.microsoft.com/en-us/graph/search-concept-files"
_MS_KQL = (
    "https://learn.microsoft.com/en-us/sharepoint/dev/general-development/"
    "keyword-query-language-kql-syntax-reference"
)
_MS_DRIVEITEM = "https://learn.microsoft.com/en-us/graph/api/resources/driveitem"
_MS_DRIVEITEM_INVITE = "https://learn.microsoft.com/en-us/graph/api/driveitem-invite"
_MS_DRIVEITEM_PATCH = "https://learn.microsoft.com/en-us/graph/api/driveitem-update"


@tool_metadata(
    tags={
        "microsoft_graph",
        "microsoft",
        "sharepoint",
        "onedrive",
        "search",
        "files",
    },
    description=(
        "[M365—search files] Use when the user needs SharePoint or OneDrive files and list items "
        "by keywords plus optional KQL filters, paginated. Scope with site_url or site_id when "
        "they named a site. Not Google Drive (gdrive_find_contents), not Jira issues, not "
        "Confluence pages, not downloading file contents.\n\n"
        "Scope: with site_url/site_id -> that site; without -> tenant-wide accessible content. "
        "Entity types include driveItem, listItem, site, list, drive. "
        "Filters: KQL list e.g. ['fileType:docx', 'size>1000']. "
        "Pagination: size max 250; page 1 from_offset=0, page 2 from_offset=250, etc.\n\n"
        f"References: {_MS_SEARCH_QUERY} {_MS_SEARCH_FILES} {_MS_KQL}"
    ),
)
async def microsoft_graph_search_content(
    *,
    search_query: Annotated[str, "The search string to find files, folders, or list items."],
    site_url: Annotated[
        str | None,
        "Optional SharePoint site URL to scope the search "
        "(e.g., https://tenant.sharepoint.com/sites/sitename). "
        "If not provided, searches across all accessible sites.",
    ] = None,
    site_id: Annotated[
        str | None,
        "Optional ID of the site to scope the search. If provided, takes precedence over site_url.",
    ] = None,
    from_offset: Annotated[
        int,
        "The zero-based index of the first result to return. Use this for pagination. "
        "Default: 0 (start from the beginning). To get the next page, increment by the size "
        "value (e.g., first page: from=0 size=250, second page: from=250 size=250, "
        "third page: from=500 size=250).",
    ] = 0,
    size: Annotated[
        int,
        "Maximum number of results to return in this request. Default is 250, max is 250. "
        "The LLM should control pagination by making multiple calls with different 'from' values.",
    ] = 250,
    entity_types: Annotated[
        list[str] | None,
        "Optional. Each list entry must be exactly one of these strings: 'driveItem', "
        "'listItem', 'site', 'list', 'drive'. Omit to default to ['driveItem', 'listItem'].",
    ] = None,
    filters: Annotated[
        list[str] | None,
        "Optional list of KQL filter expressions to refine search results "
        "(e.g., ['fileType:docx', 'size>1000']).",
    ] = None,
    include_hidden_content: Annotated[
        bool,
        "Whether to include hidden content in search results. Only works with delegated "
        "permissions, not application permissions. Default: False.",
    ] = False,
    region: Annotated[
        str | None,
        "Optional region code for application permissions (e.g., 'NAM', 'EUR', 'APC'). "
        "Required when using application permissions to search SharePoint content in "
        "specific regions.",
    ] = None,
) -> dict[str, Any]:
    if not search_query:
        raise ToolError(
            "Argument validation error: 'search_query' cannot be empty.",
            kind=ToolErrorKind.VALIDATION,
        )

    # Validate site_url if provided
    if site_url:
        validation_error = validate_site_url(site_url)
        if validation_error:
            raise ToolError(validation_error, kind=ToolErrorKind.VALIDATION)

    access_token = await get_microsoft_graph_access_token()
    if isinstance(access_token, ToolError):
        raise access_token

    async with MicrosoftGraphClient(access_token=access_token, site_url=site_url) as client:
        items = await client.search_content(
            search_query=search_query,
            site_id=site_id,
            from_offset=from_offset,
            size=size,
            entity_types=entity_types,
            filters=filters,
            include_hidden_content=include_hidden_content,
            region=region,
        )

    results = []
    for item in items:
        result_dict = {
            "id": item.id,  # Unique ID of the file, folder, or list item
            "name": item.name,
            "webUrl": item.web_url,
            "size": item.size,
            "createdDateTime": item.created_datetime,
            "lastModifiedDateTime": item.last_modified_datetime,
            "isFolder": item.is_folder,
            "mimeType": item.mime_type,
            # Document library/drive ID (driveId in Microsoft Graph API)
            "documentLibraryId": item.drive_id,
            "parentFolderId": item.parent_folder_id,  # Parent folder ID
        }
        results.append(result_dict)

    return {
        "query": search_query,
        "siteUrl": site_url,
        "siteId": site_id,
        "from": from_offset,
        "size": size,
        "results": results,
        "count": len(results),
    }


@tool_metadata(
    tags={"microsoft_graph", "sharepoint", "onedrive", "share"},
    enabled=False,
    description=(
        "[M365—share item] Use when inviting people to an existing SharePoint/OneDrive file or "
        "folder by file id and document library id. Not search (microsoft_graph_search_content), "
        "not create file.\n\n"
        "Internal or existing guest users only; does not create new guests via /invitations. "
        "Graph treats OneDrive and SharePoint items as driveItem.\n\n"
        f"References: {_MS_DRIVEITEM} {_MS_DRIVEITEM_INVITE}"
    ),
)
async def microsoft_graph_share_item(
    *,
    file_id: Annotated[str, "The ID of the file or folder to share."],
    document_library_id: Annotated[str, "The ID of the document library containing the item."],
    recipient_emails: Annotated[list[str], "A list of email addresses to invite."],
    role: Annotated[
        Literal["read", "write"],
        "Pass exactly one of these strings: 'read', 'write'. Omit to default to 'read'.",
    ] = "read",
    send_invitation: Annotated[
        bool, "Flag determining if recipients should be notified. Default False"
    ] = False,
) -> dict[str, Any]:
    if not file_id or not file_id.strip():
        raise ToolError(
            "Argument validation error: 'file_id' cannot be empty.", kind=ToolErrorKind.VALIDATION
        )

    if not document_library_id or not document_library_id.strip():
        raise ToolError(
            "Argument validation error: 'document_library_id' cannot be empty.",
            kind=ToolErrorKind.VALIDATION,
        )

    if not recipient_emails:
        raise ToolError(
            "Argument validation error: you must provide at least one 'recipient'.",
            kind=ToolErrorKind.VALIDATION,
        )

    access_token = await get_microsoft_graph_access_token()
    if isinstance(access_token, ToolError):
        raise access_token

    async with MicrosoftGraphClient(access_token=access_token) as client:
        await client.share_item(
            file_id=file_id,
            document_library_id=document_library_id,
            recipient_emails=recipient_emails,
            role=role,
            send_invitation=send_invitation,
        )

    return {
        "fileId": file_id,
        "documentLibraryId": document_library_id,
        "recipientEmails": recipient_emails,
        "n": len(recipient_emails),
        "role": role,
    }


@tool_metadata(
    tags={"microsoft_graph", "sharepoint", "onedrive", "create", "file", "write"},
    enabled=False,
    description=(
        "[M365—create text file] Use when the user wants a new plain-text file in personal "
        "OneDrive or a SharePoint library (library id from search). Not metadata updates "
        "(microsoft_update_metadata), not sharing (microsoft_graph_share_item).\n\n"
        "Personal OneDrive: file_name + content_text only (saves to root). SharePoint: set "
        "document_library_id from microsoft_graph_search_content (documentLibraryId). "
        "Duplicate names are auto-renamed (e.g. report (1).txt).\n\n"
        f"References: {_MS_DRIVEITEM} {_MS_DRIVEITEM_PATCH}"
    ),
)
async def microsoft_create_file(
    *,
    file_name: Annotated[str, "The name of the file to create (e.g., 'report.txt')."],
    content_text: Annotated[str, "The raw text content to be stored in the file."],
    document_library_id: Annotated[
        str | None,
        "The ID of the document library (Drive). If not provided, saves to personal OneDrive.",
    ] = None,
    parent_folder_id: Annotated[
        str | None,
        "ID of the parent folder. Defaults to 'root' (root of the drive).",
    ] = "root",
) -> dict[str, Any]:
    if not file_name or not file_name.strip():
        raise ToolError("Error: file_name is required.", kind=ToolErrorKind.VALIDATION)
    if not content_text:
        raise ToolError("Error: content_text is required.", kind=ToolErrorKind.VALIDATION)

    access_token = await get_microsoft_graph_access_token()
    if isinstance(access_token, ToolError):
        raise access_token

    folder_id = parent_folder_id if parent_folder_id else "root"

    async with MicrosoftGraphClient(access_token=access_token) as client:
        # Auto-fetch personal OneDrive if no library specified
        if document_library_id is None:
            drive_id = await client.get_personal_drive_id()
            is_personal_onedrive = True
        else:
            drive_id = document_library_id
            is_personal_onedrive = False

        created_file = await client.create_file(
            drive_id=drive_id,
            file_name=file_name.strip(),
            content=content_text,
            parent_folder_id=folder_id,
            conflict_behavior="rename",
        )

    return {
        "file_name": created_file.name,
        "destination": "onedrive" if is_personal_onedrive else "sharepoint",
        "driveId": drive_id,
        "id": created_file.id,
        "webUrl": created_file.web_url,
        "parentFolderId": created_file.parent_folder_id,
    }


@tool_metadata(
    tags={"microsoft_graph", "sharepoint", "onedrive", "metadata", "update"},
    enabled=False,
    description=(
        "[M365—update metadata] Use when renaming or updating list/drive item fields: either "
        "SharePoint list context (site_id + list_id) or a drive item (document_library_id). "
        "Not file body edits, not search, not sharing.\n\n"
        "List items: both site_id and list_id; custom columns in fields_to_update. "
        "Drive items: document_library_id; only name and/or description in fields_to_update. "
        "Do not mix list and drive contexts.\n\n"
        f"References: {_MS_DRIVEITEM} {_MS_DRIVEITEM_PATCH}"
    ),
)
async def microsoft_update_metadata(
    *,
    item_id: Annotated[str, "The ID of the file or list item to update."],
    fields_to_update: Annotated[
        dict[str, Any],
        "Key-value pairs of metadata fields to modify. "
        "For SharePoint list items: any custom column values. "
        "For drive items: 'name' and/or 'description'.",
    ],
    site_id: Annotated[
        str | None,
        "The site ID (required for SharePoint list items, along with list_id).",
    ] = None,
    list_id: Annotated[
        str | None,
        "The list ID (required for SharePoint list items, along with site_id).",
    ] = None,
    document_library_id: Annotated[
        str | None,
        "The drive ID (required for OneDrive/drive item updates). "
        "Cannot be used together with site_id and list_id.",
    ] = None,
) -> dict[str, Any]:
    if not item_id or not item_id.strip():
        raise ToolError("Error: item_id is required.", kind=ToolErrorKind.VALIDATION)
    if not fields_to_update:
        raise ToolError(
            "Error: fields_to_update is required and cannot be empty.",
            kind=ToolErrorKind.VALIDATION,
        )

    # Validate context parameters
    has_sharepoint_context = site_id is not None and list_id is not None
    has_partial_sharepoint_context = (site_id is not None) != (list_id is not None)
    has_drive_context = document_library_id is not None

    if has_partial_sharepoint_context:
        raise ToolError(
            "Error: For SharePoint list items, both site_id and list_id must be provided.",
            kind=ToolErrorKind.VALIDATION,
        )

    if has_sharepoint_context and has_drive_context:
        raise ToolError(
            "Error: Cannot specify both SharePoint (site_id + list_id) and OneDrive "
            "(document_library_id) context. Choose one.",
            kind=ToolErrorKind.VALIDATION,
        )

    if not has_sharepoint_context and not has_drive_context:
        raise ToolError(
            "Error: Must specify either SharePoint context (site_id + list_id) or "
            "OneDrive context (document_library_id).",
            kind=ToolErrorKind.VALIDATION,
        )

    access_token = await get_microsoft_graph_access_token()
    if isinstance(access_token, ToolError):
        raise access_token

    async with MicrosoftGraphClient(access_token=access_token) as client:
        result = await client.update_item_metadata(
            item_id=item_id.strip(),
            fields_to_update=fields_to_update,
            site_id=site_id,
            list_id=list_id,
            drive_id=document_library_id,
        )

    context_type = "sharepoint_list_item" if has_sharepoint_context else "drive_item"
    structured: dict[str, Any] = {
        "item_id": item_id,
        "context_type": context_type,
        "fields_updated": list(fields_to_update.keys()),
    }

    # Add context-specific IDs for traceability
    if has_sharepoint_context:
        structured["site_id"] = site_id
        structured["list_id"] = list_id
    else:
        structured["document_library_id"] = document_library_id

    # Include relevant response data
    if isinstance(result, dict):
        # For drive items, include key properties if present
        if has_drive_context:
            if "id" in result:
                structured["id"] = result["id"]
            if "name" in result:
                structured["name"] = result["name"]
            if "webUrl" in result:
                structured["webUrl"] = result["webUrl"]
            if "description" in result:
                structured["description"] = result.get("description")
        # For list items, the response is the fields object itself
        else:
            structured["updated_fields"] = result

    return structured
