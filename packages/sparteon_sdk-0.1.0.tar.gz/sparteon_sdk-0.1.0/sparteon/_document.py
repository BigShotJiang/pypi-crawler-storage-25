from __future__ import annotations

import io

import httpx

async def fetch_document_text(url: str) -> str:
    """
    Download a document from a signed URL and return its text content.

    Supports PDF (via pdfminer.six) and plain text. The caller receives
    extracted text only — never raw bytes or the original URL.

    Args:
        url: Signed URL to download the document from.

    Returns:
        Extracted plain text.
    """
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, follow_redirects=True)
        resp.raise_for_status()
        content = resp.content
        content_type = resp.headers.get("content-type", "")

    if "pdf" in content_type or url.lower().split("?")[0].endswith(".pdf"):
        return _extract_pdf(content)
    else:
        return content.decode("utf-8", errors="replace")


def _extract_pdf(data: bytes) -> str:
    from pdfminer.high_level import extract_text  # lazy import

    return extract_text(io.BytesIO(data))
