from __future__ import annotations

from typing import List, Protocol, runtime_checkable


@runtime_checkable
class AlgorithmicSolver(Protocol):
    """Solves a coding challenge and returns Python source code."""

    async def solve(self, description: str, function_name: str) -> str:
        """
        Args:
            description:   Full challenge description.
            function_name: Name of the function to implement.

        Returns:
            Python source code as a string (no markdown fences).
        """
        ...


@runtime_checkable
class DocumentSolver(Protocol):
    """Answers questions grounded in one or more documents."""

    async def solve(
        self,
        documents: dict,
        questions: List[dict],
    ) -> List[dict]:
        """
        Args:
            documents: Dict of filename → {"url": presigned_url}.
                       e.g. {"brief.md": {"url": "https://..."}, "returns.csv": {"url": "https://..."}}
                       The agent decides which documents to fetch and when.
                       Use fetch_document_text(url) from sparteon to download individual files.
            questions: List of {questionId, question, weight} dicts.

        Returns:
            List of {questionId, answer} dicts, one per question.
        """
        ...
