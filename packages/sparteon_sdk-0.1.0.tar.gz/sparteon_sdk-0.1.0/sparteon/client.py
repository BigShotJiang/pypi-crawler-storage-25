from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import Any, Callable, Coroutine, List, Optional

import httpx

TERMINAL = {"JUDGED", "FAILED"}
POLL_START = 2       # seconds
POLL_MAX   = 60      # seconds


@dataclass
class JudgeResult:
    submission_id: str
    status: str          # JUDGED or FAILED
    verdict: Optional[str]
    score: Optional[float]


def _safe_body(content: bytes) -> str:
    try:
        return json.dumps(json.loads(content), indent=2)
    except Exception:
        return content.decode("utf-8", errors="replace")[:2000]


class ArenaClient:
    def __init__(self, base_url: str, api_key: str, log: Optional[Callable] = None):
        self._base = base_url.rstrip("/")
        self._headers = {"X-Agent-API-Key": api_key, "Content-Type": "application/json"}
        self._log = log or (lambda _: None)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def submit(
        self,
        challenge_id: str,
        nonce: str,
        *,
        code: Optional[str] = None,
        answers: Optional[List[dict]] = None,
        followup_handler: Optional[Callable[[List[dict]], Coroutine]] = None,
        on_result: Optional[Callable[[JudgeResult], None]] = None,
    ) -> JudgeResult:
        """
        Submit to a challenge. Returns when status reaches JUDGED (or FAILED).

        followup_handler: async callable that receives followup_questions and
                          returns a list of {questionId, answer} dicts.
                          Required for DOCUMENT_GROUNDED challenges.
        on_result:        optional callback fired with the final JudgeResult.
        """
        payload: dict[str, Any] = {"nonce": nonce}
        if code is not None:
            payload["code"] = code
        if answers is not None:
            payload["answers"] = answers

        async with httpx.AsyncClient(
            headers=self._headers,
            event_hooks={"request": [self._log_request], "response": [self._log_response]},
        ) as client:
            resp = await client.post(
                f"{self._base}/challenges/{challenge_id}/submit",
                json=payload,
            )
            resp.raise_for_status()
            submission_id: str = resp.json()["submissionId"]

            result = await self._poll(
                client, challenge_id, submission_id, followup_handler
            )

        if on_result:
            on_result(result)
        return result

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _log_request(self, request: httpx.Request) -> None:
        body = _safe_body(request.content) if request.content else "(no body)"
        self._log(f"[http] --> {request.method} {request.url}")
        self._log(f"[http]     body: {body}")

    async def _log_response(self, response: httpx.Response) -> None:
        await response.aread()
        body = _safe_body(response.content) if response.content else "(no body)"
        self._log(f"[http] <-- {response.status_code} {response.url}")
        self._log(f"[http]     body: {body}")

    async def _poll(
        self,
        client: httpx.AsyncClient,
        challenge_id: str,
        submission_id: str,
        followup_handler: Optional[Callable],
    ) -> JudgeResult:
        delay = POLL_START

        while True:
            await asyncio.sleep(delay)
            delay = min(delay * 2, POLL_MAX)

            resp = await client.get(f"{self._base}/submission/{submission_id}")
            resp.raise_for_status()
            data = resp.json()
            status = data["status"]

            if status == "PENDING_FOLLOWUP":
                if followup_handler is None:
                    raise RuntimeError(
                        "Received PENDING_FOLLOWUP but no followup_handler provided"
                    )
                followup_answers = await followup_handler(data["followupQuestions"])
                await self._submit_followup(
                    client, challenge_id, submission_id, followup_answers
                )
                delay = POLL_START  # reset backoff after re-submission

            elif status in TERMINAL:
                return JudgeResult(
                    submission_id=submission_id,
                    status=status,
                    verdict=data.get("verdict"),
                    score=data.get("score"),
                )

    async def _submit_followup(
        self,
        client: httpx.AsyncClient,
        challenge_id: str,
        submission_id: str,
        followup_answers: List[dict],
    ) -> None:
        resp = await client.post(
            f"{self._base}/challenges/{challenge_id}/followup",
            json={"submissionId": submission_id, "followupAnswers": followup_answers},
        )
        resp.raise_for_status()
