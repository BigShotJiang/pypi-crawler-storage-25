"""Unit tests for ArenaClient."""
from __future__ import annotations

import pytest
import respx
import httpx

from sparteon import ArenaClient, JudgeResult


@pytest.fixture(autouse=True)
def no_sleep(monkeypatch):
    """Skip all asyncio.sleep delays so polls run instantly."""
    async def _noop(_delay):
        pass
    monkeypatch.setattr("asyncio.sleep", _noop)


# ── submit: algorithmic (JUDGED on first poll) ─────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_submit_returns_judged():
    respx.post("http://arena/challenges/c1/submit").mock(
        return_value=httpx.Response(202, json={"submissionId": "s1"})
    )
    respx.get("http://arena/submission/s1").mock(
        return_value=httpx.Response(200, json={
            "status": "JUDGED", "verdict": "PASS", "score": 1.0
        })
    )

    client = ArenaClient("http://arena", "key")
    result = await client.submit("c1", "nonce", code="def foo(): pass")

    assert isinstance(result, JudgeResult)
    assert result.submission_id == "s1"
    assert result.status == "JUDGED"
    assert result.verdict == "PASS"
    assert result.score == 1.0


# ── submit: polls through JUDGING before resolving ────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_submit_polls_through_judging():
    respx.post("http://arena/challenges/c1/submit").mock(
        return_value=httpx.Response(202, json={"submissionId": "s1"})
    )

    responses = [
        httpx.Response(200, json={"status": "JUDGING"}),
        httpx.Response(200, json={"status": "JUDGING"}),
        httpx.Response(200, json={"status": "JUDGED", "verdict": "FAIL", "score": 0.0}),
    ]
    respx.get("http://arena/submission/s1").mock(side_effect=responses)

    client = ArenaClient("http://arena", "key")
    result = await client.submit("c1", "nonce", code="def foo(): pass")

    assert result.status == "JUDGED"
    assert result.verdict == "FAIL"
    assert respx.calls.call_count == 4  # 1 POST + 3 GETs


# ── submit: FAILED is a terminal state ────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_submit_failed_is_terminal():
    respx.post("http://arena/challenges/c1/submit").mock(
        return_value=httpx.Response(202, json={"submissionId": "s1"})
    )
    respx.get("http://arena/submission/s1").mock(
        return_value=httpx.Response(200, json={
            "status": "FAILED", "verdict": None, "score": None
        })
    )

    client = ArenaClient("http://arena", "key")
    result = await client.submit("c1", "nonce", code="def foo(): pass")

    assert result.status == "FAILED"
    assert result.verdict is None
    assert result.score is None


# ── submit: followup handler called ───────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_followup_handler_invoked():
    respx.post("http://arena/challenges/c1/submit").mock(
        return_value=httpx.Response(202, json={"submissionId": "s1"})
    )
    poll_responses = [
        httpx.Response(200, json={
            "status": "PENDING_FOLLOWUP",
            "followupQuestions": [{"questionId": "q1", "question": "What is X?"}],
        }),
        httpx.Response(200, json={"status": "JUDGED", "verdict": "PASS", "score": 0.9}),
    ]
    respx.get("http://arena/submission/s1").mock(side_effect=poll_responses)
    respx.post("http://arena/challenges/c1/followup").mock(
        return_value=httpx.Response(202, json={})
    )

    captured: list = []

    async def followup_handler(questions):
        captured.extend(questions)
        return [{"questionId": "q1", "answer": "42"}]

    client = ArenaClient("http://arena", "key")
    result = await client.submit("c1", "nonce", answers=[], followup_handler=followup_handler)

    assert result.status == "JUDGED"
    assert len(captured) == 1
    assert captured[0]["questionId"] == "q1"


# ── submit: no followup_handler → RuntimeError ────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_pending_followup_without_handler_raises():
    respx.post("http://arena/challenges/c1/submit").mock(
        return_value=httpx.Response(202, json={"submissionId": "s1"})
    )
    respx.get("http://arena/submission/s1").mock(
        return_value=httpx.Response(200, json={
            "status": "PENDING_FOLLOWUP",
            "followupQuestions": [],
        })
    )

    client = ArenaClient("http://arena", "key")
    with pytest.raises(RuntimeError, match="no followup_handler"):
        await client.submit("c1", "nonce", answers=[])


# ── on_result callback ─────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_on_result_callback_fires():
    respx.post("http://arena/challenges/c1/submit").mock(
        return_value=httpx.Response(202, json={"submissionId": "s1"})
    )
    respx.get("http://arena/submission/s1").mock(
        return_value=httpx.Response(200, json={
            "status": "JUDGED", "verdict": "PASS", "score": 1.0
        })
    )

    received: list[JudgeResult] = []

    client = ArenaClient("http://arena", "key")
    result = await client.submit("c1", "nonce", code="x", on_result=received.append)

    assert len(received) == 1
    assert received[0] is result
