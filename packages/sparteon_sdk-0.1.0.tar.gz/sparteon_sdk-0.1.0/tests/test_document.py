"""Unit tests for fetch_document_text."""
from __future__ import annotations

import io

import pytest
import respx
import httpx

from sparteon import fetch_document_text


_PLAIN_TEXT = "Hello, this is a plain text document.\n" * 10


# ── plain text ─────────────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_fetch_plain_text():
    respx.get("http://files/doc.txt").mock(
        return_value=httpx.Response(
            200,
            content=_PLAIN_TEXT.encode(),
            headers={"content-type": "text/plain"},
        )
    )

    text = await fetch_document_text("http://files/doc.txt")
    assert "Hello, this is a plain text document." in text


@respx.mock
@pytest.mark.asyncio
async def test_fetch_truncates_to_max_chars():
    long_content = "x" * 50_000
    respx.get("http://files/big.txt").mock(
        return_value=httpx.Response(
            200,
            content=long_content.encode(),
            headers={"content-type": "text/plain"},
        )
    )

    text = await fetch_document_text("http://files/big.txt", max_chars=100)
    assert len(text) == 100


# ── PDF detection by content-type ─────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_fetch_pdf_by_content_type(monkeypatch):
    fake_pdf = b"%PDF-fake"

    def mock_extract(stream):
        return "Extracted from PDF."

    monkeypatch.setattr(
        "sparteon._document._extract_pdf",
        lambda data: "Extracted from PDF.",
    )

    respx.get("http://files/report").mock(
        return_value=httpx.Response(
            200,
            content=fake_pdf,
            headers={"content-type": "application/pdf"},
        )
    )

    text = await fetch_document_text("http://files/report")
    assert text == "Extracted from PDF."


# ── PDF detection by URL extension ────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_fetch_pdf_by_url_extension(monkeypatch):
    monkeypatch.setattr(
        "sparteon._document._extract_pdf",
        lambda data: "PDF via URL extension.",
    )

    respx.get("http://files/report.pdf").mock(
        return_value=httpx.Response(
            200,
            content=b"%PDF-fake",
            headers={"content-type": "application/octet-stream"},
        )
    )

    text = await fetch_document_text("http://files/report.pdf")
    assert text == "PDF via URL extension."


# ── signed URL with query params — extension check ignores query string ────────

@respx.mock
@pytest.mark.asyncio
async def test_fetch_pdf_signed_url(monkeypatch):
    monkeypatch.setattr(
        "sparteon._document._extract_pdf",
        lambda data: "Signed PDF.",
    )

    url = "http://files/doc.pdf?X-Amz-Signature=abc123&X-Amz-Expires=3600"
    respx.get(url).mock(
        return_value=httpx.Response(
            200,
            content=b"%PDF-fake",
            headers={"content-type": "application/octet-stream"},
        )
    )

    text = await fetch_document_text(url)
    assert text == "Signed PDF."


# ── HTTP error propagates ──────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_fetch_raises_on_http_error():
    respx.get("http://files/missing.txt").mock(
        return_value=httpx.Response(404)
    )

    with pytest.raises(httpx.HTTPStatusError):
        await fetch_document_text("http://files/missing.txt")
