#!/usr/bin/env python

import argparse
import json
import os

from mdo_agent_base import copy_solver_files
from mdo_agent_base import convert_vsp3_to_cst
from mdo_agent_base import export_optimization_boundary_vtks
from mdo_agent_base import resolve_section_cst_coeffs
from mdo_agent_aircraft import AircraftGenerateCFDMesh
from mdo_agent_aircraft import AircraftRunAeroOptimization
from mdo_agent_aircraft import AircraftRunCFDSimulation


def main():
    parser = argparse.ArgumentParser(
        description="Workflow helper commands for aircraft skill analyze phases."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    copy_parser = subparsers.add_parser("copy-solver-files")
    copy_parser.add_argument("--solver-name", required=True)

    prep_parser = subparsers.add_parser("prepare-aircraft-case")
    prep_parser.add_argument("--airfoil-profiles", nargs="+", required=True)
    prep_parser.add_argument("--n-cst-coeffs", required=True, type=int)
    prep_parser.add_argument("--solver-name", required=True)
    prep_parser.add_argument("--case-dir", default=".")
    prep_parser.add_argument("--cst-coeffs", nargs="+", type=float, default=None)

    geometry_parser = subparsers.add_parser("write-geometry-analysis")
    geometry_parser.add_argument("--analysis-file", required=True)
    geometry_parser.add_argument("--geometry-file", default="aircraft.stl")
    geometry_parser.add_argument("--vsp3-file", default="aircraft.vsp3")
    geometry_parser.add_argument("--airfoil-profiles", nargs="+", required=True)
    geometry_parser.add_argument("--sweeps", type=float, nargs="+", required=True)
    geometry_parser.add_argument("--twists", type=float, nargs="+", required=True)
    geometry_parser.add_argument("--chords", type=float, nargs="+", required=True)
    geometry_parser.add_argument("--spans", type=float, nargs="+", required=True)
    geometry_parser.add_argument("--dihedrals", type=float, nargs="+", required=True)
    geometry_parser.add_argument("--tail-twist", type=float, required=True)

    mesh_parser = subparsers.add_parser("write-mesh-analysis")
    mesh_parser.add_argument("--log-file", required=True)
    mesh_parser.add_argument("--metrics-file", required=True)
    mesh_parser.add_argument("--analysis-file", required=True)

    cfd_parser = subparsers.add_parser("write-cfd-analysis")
    cfd_parser.add_argument("--log-file", required=True)
    cfd_parser.add_argument("--output-file", required=True)

    opt_parser = subparsers.add_parser("write-optimization-analysis")
    opt_parser.add_argument("--log-file", required=True)
    opt_parser.add_argument("--output-file", required=True)

    export_opt_vtk_parser = subparsers.add_parser("export-optimization-boundary-vtks")
    export_opt_vtk_parser.add_argument("--case-dir", default=".")

    args = parser.parse_args()

    if args.command == "copy-solver-files":
        copy_solver_files(".", args.solver_name)
        return
    if args.command == "prepare-aircraft-case":
        cst_coeffs = args.cst_coeffs
        if cst_coeffs is None:
            cst_coeffs = resolve_section_cst_coeffs(
                args.airfoil_profiles,
                int(args.n_cst_coeffs),
                args.case_dir,
            )
        convert_vsp3_to_cst(
            args.case_dir,
            int(args.n_cst_coeffs),
            "aircraft.vsp3",
            "Wing",
            xsec_indices=range(len(args.airfoil_profiles)),
        )
        copy_solver_files(args.case_dir, args.solver_name)
        with open("cst_coeffs.prepare.json", "w", encoding="utf-8") as handle:
            json.dump(
                {"cst_coeffs": [float(value) for value in cst_coeffs]},
                handle,
                indent=2,
                sort_keys=True,
            )
        return
    if args.command == "export-optimization-boundary-vtks":
        # Use aircraft/sym patches matching the aircraft boundary naming convention.
        export_optimization_boundary_vtks(
            case_dir=args.case_dir,
            patches="(aircraft sym)",
            fields="(U p T rho nut)",
        )
        return

    if args.command == "write-geometry-analysis":
        analysis = {
            "outputs": [],
            "plots": [],
            "airfoil_profiles": args.airfoil_profiles,
            "sweeps": [args.sweeps],
            "twists": [args.twists],
            "chords": [args.chords],
            "spans": [args.spans],
            "dihedrals": [args.dihedrals],
            "tail_twist": args.tail_twist,
        }
        for filename in [args.geometry_file, args.vsp3_file]:
            if os.path.exists(filename):
                analysis["outputs"].append(filename)
        if os.path.isdir("plots"):
            case_name = os.path.basename(os.getcwd())
            for plot_name in sorted(os.listdir("plots")):
                if plot_name.lower().endswith(".png"):
                    analysis["plots"].append(os.path.join(case_name, "plots", plot_name))
        with open(args.analysis_file, "w", encoding="utf-8", errors="ignore") as handle:
            json.dump(analysis, handle, indent=2, sort_keys=True)
        return

    if args.command == "write-mesh-analysis":
        skill = AircraftGenerateCFDMesh()
        metrics = skill.parse_mesh_log(args.log_file)
        with open(args.metrics_file, "w", encoding="utf-8", errors="ignore") as handle:
            json.dump(metrics, handle, indent=2, sort_keys=True)

        analysis = {
            "outputs": [],
            "plots": [],
        }
        for filename in ["aircraft.stl", "aircraft.vsp3", "constant/polyMesh", "VTK/boundary.vtp"]:
            if os.path.exists(filename):
                analysis["outputs"].append(filename)
        if os.path.isdir("plots"):
            case_name = os.path.basename(os.getcwd())
            for plot_name in sorted(os.listdir("plots")):
                if plot_name.lower().endswith(".png"):
                    analysis["plots"].append(os.path.join(case_name, "plots", plot_name))
        with open(args.analysis_file, "w", encoding="utf-8", errors="ignore") as handle:
            json.dump(analysis, handle, indent=2, sort_keys=True)
        return

    if args.command == "write-cfd-analysis":
        skill = AircraftRunCFDSimulation()
        metrics = skill.build_convergence_metrics(skill.parse_simulation_log(args.log_file))
        with open(args.output_file, "w", encoding="utf-8", errors="ignore") as handle:
            json.dump(metrics, handle, indent=2, sort_keys=True)
        return

    if args.command == "write-optimization-analysis":
        skill = AircraftRunAeroOptimization()
        metrics = skill.parse_optimization_log(args.log_file)
        with open(args.output_file, "w", encoding="utf-8", errors="ignore") as handle:
            json.dump(metrics, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
