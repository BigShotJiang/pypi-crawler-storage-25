#!/usr/bin/env python

import argparse

from mdo_agent_aircraft import generate_aircraft_geometry_outputs


parser = argparse.ArgumentParser(description="Modify a packaged aircraft VSP3 and export aircraft.stl.")
parser.add_argument("-airfoil_profiles", type=str, nargs="+", default=["rae2822", "rae2822", "rae2822"])
parser.add_argument("-sweeps", type=float, nargs="+", default=[35.0, 30.0])
parser.add_argument("-twists", type=float, nargs="+", default=[0.0, 0.0])
parser.add_argument("-chords", type=float, nargs="+", default=[8.0, 4.5])
parser.add_argument("-spans", type=float, nargs="+", default=[5.0, 14.0])
parser.add_argument("-dihedrals", type=float, nargs="+", default=[0.0, 0.0])
parser.add_argument("-tail_twist", type=float, default=0.0)
args = parser.parse_args()

result = generate_aircraft_geometry_outputs(
    template_vsp3="aircraft.vsp3",
    output_vsp3="aircraft.vsp3",
    output_stl="aircraft.stl",
    airfoil_profiles=args.airfoil_profiles,
    sweeps=args.sweeps,
    twists=args.twists,
    chords=args.chords,
    spans=args.spans,
    dihedrals=args.dihedrals,
    tail_twist=args.tail_twist,
)

print(f"[geometry] updated wing airfoil profiles to {result['airfoil_profiles']}")
print(f"[geometry] updated wing sweeps to {result['sweeps']}")
print(f"[geometry] updated wing twists to {result['twists']}")
print(f"[geometry] updated wing chords to {result['chords']}")
print(f"[geometry] updated wing panel semi-spans to {result['spans']}")
print(f"[geometry] updated wing dihedrals to {result['dihedrals']}")
print(f"[geometry] updated tail twist to {result['tail_twist']}")
print(f"[geometry] wrote {result['output_vsp3']}")
print(f"[geometry] wrote {result['output_stl']}")
