#!/usr/bin/env python

import argparse

from mdo_agent_plot import aircraft_plot_mesh
from mdo_agent_plot import aircraft_plot_geometry
from mdo_agent_plot import aircraft_plot_flow_field
from mdo_agent_plot import aircraft_plot_pressure_profile
from mdo_agent_plot import general_plot_function
from mdo_agent_plot import general_plot_residual
from mdo_agent_plot import general_trame_view


def parse_args():
    parser = argparse.ArgumentParser(description="Thin mdo_agent_plot wrapper for case-local aircraft plotting.")
    parser.add_argument("-mode", type=str, required=True)
    parser.add_argument("-input_files", type=str, nargs="+", default=None)
    parser.add_argument("-port", type=int, default=8002)
    parser.add_argument("-case_dir", type=str, default=".")
    parser.add_argument("-log_file", type=str, default="log_simulation.txt")
    parser.add_argument("-geometry_file", type=str, default="aircraft.stl")
    parser.add_argument("-mesh_file", type=str, default="VTK/boundary.vtp")
    parser.add_argument("-camera_scale", type=float, default=1.0)
    parser.add_argument("-image_width", type=int, default=1920)
    parser.add_argument("-image_height", type=int, default=1150)
    parser.add_argument("-flow_field", type=str, default="p")
    parser.add_argument("-time_step", type=int, default=-1)
    parser.add_argument("-spanwise_y", type=float, nargs="+", default=[0.3, 1.5, 2.7])
    parser.add_argument("-spanwise_chords", type=float, nargs="+", default=[1.0, 1.0, 1.0])
    parser.add_argument("-spanwise_x", type=float, nargs="+", default=[0.0, 0.0, 0.0])
    parser.add_argument("-spanwise_fractions", type=float, nargs="+", default=None)
    parser.add_argument("-reference_pressure", type=float, default=None)
    parser.add_argument("-pressure_coefficient_scale", type=float, default=None)
    return parser.parse_args()

def main():
    args = parse_args()

    if args.mode == "aircraft_plot_geometry":
        return aircraft_plot_geometry(
            case_dir=args.case_dir,
            geometry_file=args.geometry_file,
            camera_scale=args.camera_scale,
            image_width=args.image_width,
            image_height=args.image_height,
        )
    if args.mode == "aircraft_plot_mesh":
        return aircraft_plot_mesh(
            case_dir=args.case_dir,
            mesh_file=args.mesh_file,
            camera_scale=args.camera_scale,
            image_width=args.image_width,
            image_height=args.image_height,
        )
    if args.mode == "general_plot_residual":
        return general_plot_residual(
            case_dir=args.case_dir,
            log_file=args.log_file,
        )
    if args.mode == "general_plot_function":
        return general_plot_function(
            case_dir=args.case_dir,
            log_file=args.log_file,
        )
    if args.mode == "aircraft_plot_flow_field":
        return aircraft_plot_flow_field(
            case_dir=args.case_dir,
            flow_field=args.flow_field,
            time_step=args.time_step,
            camera_scale=args.camera_scale,
            image_width=args.image_width,
            image_height=args.image_height,
        )
    if args.mode == "aircraft_plot_pressure_profile":
        return aircraft_plot_pressure_profile(
            case_dir=args.case_dir,
            time_step=args.time_step,
            mesh_file=args.mesh_file,
            reference_pressure=args.reference_pressure,
            pressure_coefficient_scale=args.pressure_coefficient_scale,
            spanwise_y=args.spanwise_y,
            spanwise_chords=args.spanwise_chords,
            spanwise_x=args.spanwise_x,
            spanwise_fractions=args.spanwise_fractions,
        )
    if args.mode == "trame_view":
        return general_trame_view(
            input_files=args.input_files,
            port=args.port,
        )

    raise ValueError(
        "Unsupported mode. Expected one of: aircraft_plot_geometry, aircraft_plot_mesh, "
        "general_plot_residual, general_plot_function, aircraft_plot_flow_field, "
        "aircraft_plot_pressure_profile, trame_view."
    )


if __name__ == "__main__":
    main()
