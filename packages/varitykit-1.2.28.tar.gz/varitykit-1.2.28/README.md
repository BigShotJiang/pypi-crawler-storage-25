# varitykit

> Deploy any app — websites, APIs, AI agents — for less than what AWS, Vercel, Railway, and Render charge. One command. No infrastructure setup.

[![PyPI version](https://img.shields.io/pypi/v/varitykit)](https://pypi.org/project/varitykit/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://github.com/varity-labs/varity-sdk/blob/main/LICENSE)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)

`varitykit` is the command-line tool for [Varity](https://varity.app). You point it at any project — website, API, AI agent — and one command takes it live with a real cost number. Static sites are a flat $5/month; dynamic apps and AI agents are usage-priced and run a fraction of what the same workload costs on Vercel, Render, or AWS.

## Why people switch

- **Static sites: flat $5/month**, traffic and storage included — no Pro-plan gating, no surprise overage bills.
- **Dynamic apps and AI agents**: usage-priced. Pay only for the compute time your container actually runs. No idle-hour fees, no per-request fees, no plan tiers.
- **No infrastructure to wire up**: no Dockerfile, no Kubernetes, no DNS, no region selection. `varitykit app deploy` and you're live.

Run `varitykit app deploy --dry-run` to see the estimated monthly cost before you ship anything.

## 60-second quickstart

```bash
pip install varitykit                     # 1. install
varitykit login                           # 2. paste your deploy key
varitykit init my-app                     # 3. scaffold a new Next.js app
cd my-app && varitykit app deploy         # 4. live at https://varity.app/my-app/
```

Already have an app? Skip step 3. `cd` into it and run `varitykit app deploy`.

## What kinds of apps work

Validated end-to-end on this release:

| Pattern | Status | Notes |
|---|---|---|
| Plain HTML | ✅ | Works as-is |
| Vite SPA (Vue / React) | ✅ | Build first, then deploy |
| Next.js with `output: "export"` | ✅ | Build first, then deploy |
| Express / Node API | ✅ | Single container; works end-to-end |
| Next.js with API routes / SSR | ✅ | Deploys; multi-service polish underway |
| FastAPI / Flask / Django | ⚠ | Single-container apps work; apps that need Postgres or an LLM hit a startup-ordering issue we're fixing |
| AI agent with a local LLM | ⚠ | Same as above |

Go, Rust, Ruby, Elixir, Java, PHP, and .NET are on the roadmap.

## Commands

```
varitykit doctor              check Node 20+, Python 3.11+, git, npm, network
varitykit login [--key ...]   save your deploy key (or use VARITY_DEPLOY_KEY env var)
varitykit init <name>         scaffold a new Next.js app
varitykit app deploy          deploy from the current directory
varitykit app list            list your deployments
varitykit app info <id>       details for a specific deployment
varitykit app delete <name>   stop a deployment and end its billing
varitykit agent list          list available AI agent templates
varitykit agent info <name>   full details for one agent (env vars, ports, cost)
varitykit migrate --url <gh>  convert a Vercel project to Varity
varitykit completions         install shell tab completion (bash / zsh / fish)
```

`--debug`, `--json`, `--version`, and `--help` are available globally.

### `varitykit init`

Wraps `npx create-next-app@latest` with sensible defaults (TypeScript, App Router, no preset Tailwind / ESLint) and writes a small `varity.config.json` next to the scaffold. The previous bundled SaaS template is deprecated; `--template` is accepted for backward compatibility but routes to the same flow.

### `varitykit app deploy`

```bash
varitykit app deploy                        # auto — figures out everything
varitykit app deploy --hosting static       # force static hosting
varitykit app deploy --hosting dynamic      # force dynamic hosting
varitykit app deploy --dry-run              # show what would deploy without shipping
varitykit app deploy --name staging         # custom URL slug → varity.app/staging/
```

For dynamic apps (anything with a server), your code currently needs to be in a public GitHub repo so the host can fetch it at startup. Eliminating that requirement is the next thing we're shipping. (See [KNOWN_ISSUES.md](./KNOWN_ISSUES.md).)

### `varitykit app deploy --agent <name>` — deploy a ready-made AI agent

Skip the code entirely. Pick one of 5 curated AI agent templates and Varity will deploy a working instance for you, exposing it at `https://varity.app/<name>/`.

| Agent | What it is | Est. cost |
|---|---|---|
| `hermes` | Self-hosted Telegram chatbot powered by an LLM | ~$16 / mo |
| `openclaw` | Claude-compatible web chat UI with persistent history | ~$38 / mo |
| `agent-zero` | General-purpose AI agent framework — zero required env vars | ~$14 / mo |
| `autoresearch` | GPU-backed CUDA workstation (SSH access) | ~$280 / mo |
| `eliza-venice` | ElizaOS agent for Twitter/X automation | ~$168 / mo |

```bash
varitykit agent list                                         # see all 5
varitykit agent info hermes                                  # full setup (env vars, ports)
varitykit app deploy --agent hermes --name my-telegram-bot   # deploy it
```

Each agent prompts you for the small set of required environment variables (a bot token, an API key, etc.). When you're done with it: `varitykit app delete my-telegram-bot`.

### `varitykit migrate`

Converts a Vercel-deployed app to Varity: clones the repo, removes Vercel-specific packages and config (`vercel.json`, `@vercel/blob`, `@vercel/kv`, edge-runtime markers, Next image-optimizer settings), suggests portable replacements (S3-compatible storage for `@vercel/blob`, `ioredis` for `@vercel/kv`), applies them, and deploys.

```bash
varitykit migrate --url https://github.com/me/my-vercel-app --dry-run   # preview
varitykit migrate --url https://github.com/me/my-vercel-app             # do it
```

Verified on real-world Vercel projects: the Next.js framework itself, `leerob/leerob.io`, `shadcn-ui/taxonomy`.

## Use Varity from your AI editor

Varity ships an MCP server so Cursor, Claude Code, VS Code Copilot, Windsurf, and other AI tools can deploy without typing.

```bash
claude mcp add varity -- npx @varity-labs/mcp     # Claude Code
# Then: "deploy this app to Varity"
```

See [@varity-labs/mcp](https://www.npmjs.com/package/@varity-labs/mcp) for setup in other clients.

## Honest current state

Static deploys (websites, exported Next.js, Vite SPAs) and single-container APIs are production-ready. Multi-service apps — an API with a database, or an AI agent with an LLM — are configured correctly by the CLI, but the order in which the services start up needs polish before launch. See [KNOWN_ISSUES.md](./KNOWN_ISSUES.md) for the full audit.

## Support

- **Issues**: [github.com/varity-labs/varity-sdk/issues](https://github.com/varity-labs/varity-sdk/issues)
- **Discord**: [discord.gg/7vWsdwa2Bg](https://discord.gg/7vWsdwa2Bg)

## License

MIT — see [LICENSE](../LICENSE).
