"""
`varitykit agent` command group — discover and inspect curated AI agent
templates that deploy via `varitykit app deploy --agent <name>`.

Templates and metadata are vendored under
`cli/varitykit/templates/agents/` from the awesome-akash repo at the
pinned commit `cfba51744479a149d16f83f80db4120f7bfc313c`.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


_AGENTS_DIR = Path(__file__).resolve().parent.parent / "templates" / "agents"
_AGENTS_JSON = _AGENTS_DIR / "agents.json"


class AgentNotFoundError(click.ClickException):
    def __init__(self, name: str, available: List[str]):
        msg = (
            f"Unknown agent: {name!r}.\n"
            f"  Available agents: {', '.join(sorted(available))}\n"
            f"  Run `varitykit agent list` for descriptions."
        )
        super().__init__(msg)


def _load_agents_registry() -> Dict[str, Any]:
    """Load the curated agent metadata. Strips the `_meta` block."""
    if not _AGENTS_JSON.exists():
        raise click.ClickException(
            f"Agent registry missing: {_AGENTS_JSON}. This is a packaging bug."
        )
    raw = json.loads(_AGENTS_JSON.read_text(encoding="utf-8"))
    return {k: v for k, v in raw.items() if not k.startswith("_")}


def get_agent_metadata(name: str) -> Dict[str, Any]:
    """Public helper: return one agent's metadata or raise AgentNotFoundError."""
    registry = _load_agents_registry()
    if name not in registry:
        raise AgentNotFoundError(name, list(registry.keys()))
    return registry[name]


def load_agent_sdl(name: str) -> Tuple[str, Dict[str, Any]]:
    """Public helper: return (raw_sdl_yaml_text, metadata) for an agent."""
    meta = get_agent_metadata(name)
    sdl_path = _AGENTS_DIR / meta["sdl_path"]
    if not sdl_path.exists():
        raise click.ClickException(
            f"SDL template missing for agent {name!r}: {sdl_path}"
        )
    return sdl_path.read_text(encoding="utf-8"), meta


def list_agents() -> List[Tuple[str, Dict[str, Any]]]:
    """Sorted list of (name, metadata) for use by other commands."""
    registry = _load_agents_registry()
    return sorted(registry.items(), key=lambda kv: kv[0])


# ----------------------------------------------------------------------
# `varitykit agent` command group
# ----------------------------------------------------------------------


@click.group()
def agent() -> None:
    """Discover and inspect curated AI agent deploy templates.

    Deploy any of these with:
      varitykit app deploy --agent <name>
    """


@agent.command("list")
def cmd_list() -> None:
    """List available AI agent templates."""
    table = Table(title="Available AI agent templates", show_lines=False)
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Description")
    table.add_column("Est. cost/mo", justify="right", style="green")
    table.add_column("Access")

    for name, meta in list_agents():
        cost = f"~${meta.get('estimated_cost_per_month_usd', 0):.0f}/mo"
        desc = meta.get("description", "(no description)")
        # Shorten very long descriptions for table display
        if len(desc) > 90:
            desc = desc[:87] + "…"
        access = meta.get("access", "—")
        if len(access) > 35:
            access = access[:32] + "…"
        table.add_row(name, desc, cost, access)

    console.print(table)
    console.print(
        "\n  Run [bold cyan]varitykit agent info <name>[/bold cyan] for full details (env vars, ports, resources).\n"
        "  Deploy any of these with: [bold cyan]varitykit app deploy --agent <name>[/bold cyan]\n"
    )


@agent.command("info")
@click.argument("name")
def cmd_info(name: str) -> None:
    """Show full details for an agent template (env vars, ports, resources)."""
    meta = get_agent_metadata(name)

    body_lines = [
        f"[bold cyan]{meta['name']}[/bold cyan]",
        "",
        meta.get("description", ""),
        "",
        f"[bold]Image:[/bold]            {meta.get('primary_image', '(unknown)')}",
        f"[bold]Access:[/bold]           {meta.get('access', '(unknown)')}",
        f"[bold]Exposed ports:[/bold]    {', '.join(str(p) for p in meta.get('exposed_ports', []))}",
        f"[bold]Resources:[/bold]        {_format_resources(meta.get('resources', {}))}",
        f"[bold]Est. cost / month:[/bold] [green]~${meta.get('estimated_cost_per_month_usd', 0):.0f} USD[/green]",
    ]

    required = meta.get("required_env", [])
    optional = meta.get("optional_env", [])
    if required:
        body_lines.append("")
        body_lines.append(f"[bold red]Required env vars[/bold red] (you'll be prompted unless provided via --env):")
        for k in required:
            body_lines.append(f"  • {k}")
    if optional:
        body_lines.append("")
        body_lines.append(f"[bold yellow]Optional env vars[/bold yellow] (defaults shipped in the template):")
        for k in optional[:12]:
            body_lines.append(f"  • {k}")
        if len(optional) > 12:
            body_lines.append(f"  • … +{len(optional) - 12} more (see the template SDL)")

    if meta.get("notes"):
        body_lines.append("")
        body_lines.append(f"[dim]Note:[/dim] {meta['notes']}")

    body_lines.append("")
    body_lines.append(f"[bold]Deploy:[/bold]")
    body_lines.append(f"  varitykit app deploy --agent {name} --name my-{name}-instance")

    console.print(Panel.fit("\n".join(body_lines), border_style="cyan"))


def _format_resources(r: Dict[str, Any]) -> str:
    cpu = r.get("cpu", "?")
    mem = r.get("memory", "?")
    storage = r.get("storage", "?")
    return f"cpu={cpu} memory={mem} storage={storage}"
