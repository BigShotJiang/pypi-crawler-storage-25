"""
Deployment Orchestrator - Coordinates complete deployment workflow

This orchestrator coordinates all deployment steps:
1. Project detection (Agent 1)
2. Build execution (Agent 1)
3. IPFS upload (Agent 2)
4. Deployment metadata storage
5. Result reporting

Phase 1 MVP: IPFS deployment only
Phase 2: Adds Akash deployment + App Store submission
"""

import json
import os
import re
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from .types import (
    BuildArtifacts,
    BuildError,
    DeploymentError,
    DeploymentResult,
    IPFSUploadError,
    ProjectDetectionError,
    ProjectInfo,
)


class DeploymentOrchestrator:
    """
    Orchestrates complete deployment workflow.

    Coordinates project detection, building, IPFS upload, and metadata storage.

    Usage:
        orchestrator = DeploymentOrchestrator(verbose=True)
        result = orchestrator.deploy(
            project_path=".",
            network="varity",
            submit_to_store=False
        )
        print(f"Deployed to: {result.frontend_url}")
    """

    def __init__(self, verbose: bool = True):
        """
        Initialize deployment orchestrator.

        Args:
            verbose: Whether to print progress messages
        """
        self.verbose = verbose

        # These will be initialized when Agent 1 and Agent 2 are ready
        # For now, we import them lazily to allow testing with mocks
        self._detector = None
        self._builder = None
        self._ipfs = None
        self._akash = None  # Phase 2: Akash deployment (Agent 5)
        self._app_store = None  # Phase 2: App Store client (Agent 6)
        self._history = None  # Phase 2: Deployment history manager (Agent 7)

    @property
    def detector(self):
        """Lazy load ProjectDetector (Agent 1)"""
        if self._detector is None:
            try:
                from .project_detector import ProjectDetector

                self._detector = ProjectDetector()
            except ImportError:
                raise ImportError(
                    "ProjectDetector not yet implemented. " "Waiting for Agent 1 to complete."
                )
        return self._detector

    @property
    def builder(self):
        """Lazy load BuildManager (Agent 1)"""
        if self._builder is None:
            try:
                from .build_manager import BuildManager

                self._builder = BuildManager()
            except ImportError:
                raise ImportError(
                    "BuildManager not yet implemented. " "Waiting for Agent 1 to complete."
                )
        return self._builder

    @property
    def ipfs(self):
        """Lazy load IPFSUploader (Agent 2)"""
        if self._ipfs is None:
            try:
                from .ipfs_uploader import IPFSUploader

                self._ipfs = IPFSUploader()
            except ImportError:
                raise ImportError(
                    "IPFSUploader not yet implemented. " "Waiting for Agent 2 to complete."
                )
        return self._ipfs

    @property
    def akash(self):
        """Lazy load AkashConsoleDeployer (uses Console API - no CLI required)"""
        if self._akash is None:
            try:
                from .akash.console_deployer import AkashConsoleDeployer

                self._akash = AkashConsoleDeployer(on_progress=self._log)
            except ImportError:
                raise ImportError(
                    "AkashConsoleDeployer not available. "
                    "Ensure AKASH_CONSOLE_API_KEY is set."
                )
        return self._akash

    @property
    def app_store(self):
        """Lazy load AppStoreClient (Agent 6 - Phase 2)"""
        if self._app_store is None:
            try:
                from .app_store.client import AppStoreClient

                self._app_store = AppStoreClient()
            except ImportError:
                raise ImportError(
                    "AppStoreClient not yet implemented. " "Waiting for Agent 6 to complete."
                )
        return self._app_store

    @property
    def history(self):
        """Lazy load DeploymentHistory (Agent 7 - Phase 2)"""
        if self._history is None:
            from .deployment_history import DeploymentHistory

            self._history = DeploymentHistory()
        return self._history

    def deploy(
        self,
        project_path: str = ".",
        network: str = "varity",
        hosting: str = "ipfs",
        submit_to_store: bool = False,
        tier: str = "free",
        custom_name: Optional[str] = None,
        skip_build: bool = False,
        repo_url: Optional[str] = None,
    ) -> DeploymentResult:
        """
        Deploy application to decentralized infrastructure.

        Args:
            project_path: Path to project directory (default: current directory)
            network: Target network (default: "varity")
            hosting: Hosting type - "ipfs" for static sites, "akash" for dynamic apps
            submit_to_store: Auto-submit to App Store

        Returns:
            DeploymentResult with URLs, CID, and manifest

        Raises:
            ProjectDetectionError: If project type cannot be detected
            BuildError: If build fails
            IPFSUploadError: If IPFS upload fails
            DeploymentError: For other deployment failures
        """
        from varitykit.services.gateway_client import (
            register_domain, sanitize_subdomain,
            check_availability, get_deploy_key, GatewayError,
        )
        import varitykit as _vk
        _run_id = str(uuid.uuid4())
        _t_start = time.monotonic()
        _telem: Dict = {
            "run_id": _run_id,
            "ts": datetime.now().isoformat(),
            "hosting_requested": hosting,
            "cli_version": getattr(_vk, "__version__", "unknown"),
        }

        try:
            self._log("🚀 Starting deployment...")

            # Step 1: Detect project
            self._log("📦 Detecting project type...")
            project_info = self._detect_project(project_path)
            self._log(f"   Detected: {project_info.project_type}")
            _telem["project_type"] = project_info.project_type

            # Capture size signals and anonymized user_id for all deploy paths
            _size_bytes, _file_count = self._compute_project_size(project_path)
            _telem.update({"repo_size_bytes": _size_bytes, "file_count": _file_count})
            try:
                import hashlib as _hl
                _dk = get_deploy_key()
                _telem["user_id"] = _hl.sha256(_dk.encode()).hexdigest()[:16] if _dk else None
            except Exception:
                pass

            # Step 2: Build project
            # For Akash hosting, Docker handles the build inside the container,
            # so we skip the local npm/build step and create a placeholder.
            #
            # For static (IPFS) hosting, compute the expected subdomain early so
            # NEXT_PUBLIC_BASE_PATH can be injected into the build environment.
            # This lets next.config.js set basePath at build time, which is required
            # for correct internal navigation on sub-path deployments (varity.app/{name}/).
            _extra_build_env: dict = {}
            if hosting != "akash" and not skip_build:
                # Forward user-supplied env vars to the build environment.
                # Static (IPFS) builds bake NEXT_PUBLIC_* / VITE_* etc. at
                # build time — there is no runtime container to inject them
                # into. Akash deploys go through a separate path that
                # injects env vars into the SDL service block. This call
                # uses the same reserved-keys + platform-leak filters as
                # the Akash path, so users can't accidentally inject
                # NODE_ENV / DATABASE_URL etc. that would override
                # Varity-managed wiring.
                _extra_build_env.update(self._load_env_vars(project_path))
                try:
                    _pre_subdomain = sanitize_subdomain(custom_name or project_info.name)
                    # NEXT_PUBLIC_BASE_PATH is route-determined, not user-
                    # controlled — set it after the merge so it wins on
                    # conflict if the user accidentally added one.
                    _extra_build_env["NEXT_PUBLIC_BASE_PATH"] = f"/{_pre_subdomain}"
                except Exception:
                    pass

            if hosting == "akash":
                self._log("📦 Preparing for compute deployment...")
                build_artifacts = BuildArtifacts(
                    success=True,
                    output_dir=project_path,
                    files=[],
                    entrypoint="",
                    total_size_mb=0.0,
                    build_time_seconds=0.0,
                )
            elif skip_build:
                self._log("⚡ Using existing build output...")
                build_artifacts = self.builder._collect_artifacts(
                    Path(project_path), project_info.output_dir, 0.0,
                )
            else:
                self._log(f"🔨 Building project ({project_info.build_command})...")
                build_artifacts = self._build_project(project_path, project_info, extra_env=_extra_build_env if _extra_build_env else None)

                if not build_artifacts.success:
                    raise BuildError("Build failed")

                self._log(
                    f"   Built {len(build_artifacts.files)} files ({build_artifacts.total_size_mb:.2f} MB)"
                )

            # Step 2.5: Rewrite paths for static hosting (IPFS compatibility)
            if hosting != "akash":
                from .path_rewriter import rewrite_paths_for_static_hosting
                self._log("   Optimizing for static hosting...")
                modified = rewrite_paths_for_static_hosting(build_artifacts.output_dir)
                self._log(f"   Rewrote {modified} files for portable paths")

            # Step 2.7: Check domain availability BEFORE uploading (fail fast)
            subdomain = None
            owner_id = None
            if hosting != "akash":
                try:
                    subdomain = sanitize_subdomain(custom_name or project_info.name)
                    owner_id = get_deploy_key()

                    availability = check_availability(subdomain, owner_id=owner_id)
                    if not availability.get("available") and not availability.get("ownedByYou"):
                        reason = availability.get("reason", "taken")
                        if reason == "reserved":
                            raise GatewayError(
                                f'"{subdomain}" is reserved. Use --name to pick a different name.'
                            )
                        raise GatewayError(
                            f'"{subdomain}" is taken by another developer. '
                            f"Use --name to pick a different name."
                        )
                    self._log(f"   Name '{subdomain}' is available ✓")
                except GatewayError as e:
                    self._log(f"   ⚠️ Domain check skipped: {e}")
                    # Continue — domain registration will be attempted after upload
                except Exception:
                    pass  # Gateway unreachable — proceed, registration will fail later if needed

            # Base tag injection disabled — Next.js static export generates correct
            # relative paths with trailingSlash:true. Gateway handles subdirectory routing.

            # Step 3: Deploy based on hosting type
            frontend_url = ""
            thirdweb_url = ""
            cid = ""
            akash_deploy_result = None
            ipfs_result = None

            if hosting == "akash":
                # Deploy to Akash Network via Console API (git clone at runtime)
                self._log("☁️  Deploying to compute platform...")

                # Resolve GitHub repo URL — use provided repo_url first, fall back to .git/config
                try:
                    github_url = repo_url if repo_url else self._resolve_github_url(project_path)
                except DeploymentError:
                    _telem["failure_stage"] = "repo_access"
                    raise

                # Capture Akash-specific telemetry signals (idempotent file reads)
                _telem_svc = self._detect_services(project_path)
                _telem_env = self._load_env_vars(project_path)
                from varitykit.services.akash_deploy_service import (
                    detect_app_port as _dap, app_resources as _app_res, size_to_mb as _sz,
                )
                _telem_port = _dap(project_path, project_info.project_type)
                _node_types = {"nextjs", "react", "vue", "nodejs"}
                # Hardware = the same app_resources() the SDL generator uses, so
                # telemetry mirrors exactly what gets provisioned.
                _res = _app_res(project_info.project_type)
                _telem.update({
                    "repo_url": github_url,
                    "sidecars_added": _telem_svc,
                    "env_var_count": len(_telem_env),
                    "port": _telem_port,
                    "image": "node:20-bookworm-slim" if project_info.project_type in _node_types else "python:3.11-slim",
                    "cpu": float(_res["cpu"]),
                    "memory_mb": _sz(_res["memory"]),
                    "storage_mb": _sz(_res["storage"]),
                    "dependency_signals": {
                        "has_pg": "postgres" in _telem_svc,
                        "has_redis": "redis" in _telem_svc,
                        "has_mongodb": "mongodb" in _telem_svc,
                        "has_ollama": "ollama" in _telem_svc,
                        "has_mysql": "mysql" in _telem_svc,
                        "has_prisma": self._has_prisma(project_path),
                    },
                })

                _akash_t0 = time.monotonic()
                akash_deploy_result = self._deploy_to_akash_service(
                    project_path, project_info, custom_name,
                    github_repo_url=github_url,
                )
                _telem["container_first_response_seconds"] = round(time.monotonic() - _akash_t0, 1)
                # Record provider bids + provisioned hardware with the deploy
                # telemetry. Set before the success check so FAILED deploys are
                # captured too (the RL action space + cost counterfactual).
                _telem["provider_bids"] = akash_deploy_result.provider_bids
                _telem["selected_provider"] = akash_deploy_result.provider
                _telem["selected_price"] = akash_deploy_result.selected_price
                _telem["bid_count"] = akash_deploy_result.bid_count
                if akash_deploy_result.cpu:
                    _telem["cpu"] = akash_deploy_result.cpu
                if akash_deploy_result.memory_mb:
                    _telem["memory_mb"] = akash_deploy_result.memory_mb
                if akash_deploy_result.storage_mb:
                    _telem["storage_mb"] = akash_deploy_result.storage_mb

                if not akash_deploy_result.success:
                    # Pinpoint which deploy stage failed (sdl_submission /
                    # bid_collection / lease_acceptance / container_health) so
                    # failures feed the agents building varitykit toward
                    # "deploy anything" — not just "it failed".
                    _telem["failure_stage"] = akash_deploy_result.failure_stage or "container_health"
                    # If Akash accepted the SDL (dseq assigned) but warmup timed
                    # out, save a ghost record so the deployment is discoverable
                    # and cancellable even though the health check failed.
                    if akash_deploy_result.dseq:
                        self._save_ghost_deployment(
                            akash_deploy_result, project_info, project_path, network
                        )
                    raise DeploymentError(
                        akash_deploy_result.error_message or "Compute deployment failed"
                    )

                frontend_url = akash_deploy_result.url
                cid = f"akash:{akash_deploy_result.dseq}"
                self._log(f"   App running at: {frontend_url}")
                self._log(f"   Monthly cost: ~${akash_deploy_result.estimated_monthly_cost:.0f}")
            else:
                # Default: Upload to IPFS
                self._log("☁️  Deploying your app...")
                ipfs_result = self._upload_to_ipfs(build_artifacts)

                if not ipfs_result.success:
                    raise IPFSUploadError("IPFS upload failed")

                cid = ipfs_result.cid
                frontend_url = ipfs_result.gateway_url
                thirdweb_url = ipfs_result.thirdweb_url
                self._log(f"   URL: {frontend_url}")

                # Capture service/env signals for IPFS deploys
                _ipfs_svc = self._detect_services(project_path)
                _ipfs_env = self._load_env_vars(project_path)
                _telem.update({
                    "sidecars_added": [],
                    "env_var_count": len(_ipfs_env),
                    "port": None,
                    "image": None,
                    # Static → IPFS/CDN: no container, so no reserved hardware.
                    "cpu": 0,
                    "memory_mb": 0,
                    "storage_mb": 0,
                    "dependency_signals": {
                        "has_pg": "postgres" in _ipfs_svc,
                        "has_redis": "redis" in _ipfs_svc,
                        "has_mongodb": "mongodb" in _ipfs_svc,
                        "has_ollama": "ollama" in _ipfs_svc,
                        "has_mysql": "mysql" in _ipfs_svc,
                        "has_prisma": self._has_prisma(project_path),
                    },
                })

            # Step 3.5: Register custom domain
            custom_domain_url = None

            # For Akash deployments, register with deployment URL
            if hosting == "akash" and akash_deploy_result and akash_deploy_result.success:
                try:
                    from varitykit.services.gateway_client import (
                        register_akash_domain, sanitize_subdomain,
                        get_deploy_key,
                    )
                    # Prefer directory name over package.json `name` when no --name flag was given.
                    # package.json names are npm artifact names (e.g. "dx-express-v2") that don't
                    # reflect the developer's intended URL slug — the directory does.
                    subdomain = sanitize_subdomain(custom_name or Path(project_path).name)
                    owner_id = get_deploy_key()

                    self._log("   Setting up your app's web address…")
                    register_akash_domain(
                        subdomain=subdomain,
                        deployment_url=akash_deploy_result.url,
                        deployment_id=akash_deploy_result.dseq,
                        app_name=project_info.display_name or project_info.name,
                        tagline=project_info.description,
                        owner_id=owner_id,
                        provider=akash_deploy_result.provider,
                    )
                    custom_domain_url = f"https://{subdomain}.varity.app/"
                    frontend_url = custom_domain_url
                    self._log(f"   🌐 {custom_domain_url}")

                    if not owner_id:
                        self._log("   💡 Tip: Run 'varitykit login' to protect your apps.")
                except Exception:
                    self._log("   ⚠️ Your app's web address is being finalized — ready shortly.")
                    # Don't fail the deploy — the app is still coming up.

            # For IPFS deployments, register with CID
            elif cid and subdomain and hosting != "akash":
                try:
                    register_domain(
                        subdomain, cid,
                        app_name=project_info.display_name or project_info.name,
                        tagline=project_info.description,
                        owner_id=owner_id,
                    )
                    custom_domain_url = f"https://varity.app/{subdomain}/"
                    frontend_url = custom_domain_url
                    self._log(f"   🌐 {custom_domain_url}")

                    if not owner_id:
                        self._log("   💡 Tip: Run 'varitykit login' to protect your domains.")
                except GatewayError as e:
                    self._log(f"   ⚠️ Custom domain unavailable: {e}")
                    self._log(f"   App is still accessible via IPFS URL above.")
                except Exception as e:
                    self._log(f"   ⚠️ Custom domain unavailable: {e}")
                    self._log(f"   App is still accessible via IPFS URL above.")

            # Step 4: Create deployment manifest
            manifest = self._create_manifest(
                project_info, build_artifacts, ipfs_result, network, hosting,
                akash_result=akash_deploy_result,
                project_path=project_path,
            )

            # Store custom domain info in manifest
            if custom_domain_url and subdomain:
                manifest["custom_domain"] = {
                    "subdomain": subdomain,
                    "url": custom_domain_url,
                    "owner_id": owner_id,
                }

            # Step 5: Save deployment metadata
            deployment_id = self._save_deployment(manifest)

            # Step 6: Submit to App Store
            app_store_url = None
            if submit_to_store:
                self._log("📝 Submitting to App Store...")
                try:
                    app_store_result = self._submit_to_app_store(
                        project_info,
                        {"frontend_url": frontend_url},
                        project_path,
                        network,
                        tier=tier,
                    )

                    if app_store_result and app_store_result.success:
                        app_store_url = app_store_result.url
                        manifest["app_store"] = {
                            "submitted": True,
                            "app_id": app_store_result.app_id,
                            "tx_hash": app_store_result.tx_hash,
                            "url": app_store_result.url,
                            "status": "pending_approval",
                        }
                        self._log(f"   ✅ App ID: {app_store_result.app_id}")
                        self._log(f"   📱 View at: {app_store_result.url}")
                    else:
                        error_msg = (
                            app_store_result.error_message if app_store_result else "Unknown error"
                        )
                        self._log(f"   ⚠️  App Store submission failed: {error_msg}")
                        self._log("   Manual submission: https://store.varity.so/submit")
                        manifest["app_store"] = {"submitted": False, "error": error_msg}
                except Exception as e:
                    self._log(f"   ⚠️  App Store submission error: {e}")
                    self._log("   Manual submission: https://store.varity.so/submit")
                    manifest["app_store"] = {"submitted": False, "error": str(e)}

            # Step 6.5: Wait for the URL to actually serve traffic before
            # declaring success. The Akash lease (or IPFS pin) being accepted
            # does NOT mean the container is reachable — the gateway needs
            # ~30s to propagate routing for new dynamic deploys, multi-service
            # containers need their sidecars to start, and IPFS needs DNS
            # propagation. Polling here avoids the F4-8a class of bug where
            # the user clicks the URL immediately, sees 502, and assumes the
            # deploy failed.
            readiness_url = custom_domain_url or frontend_url
            has_sidecars = bool(_telem.get("sidecars_added"))
            is_static = (hosting != "akash")
            readiness_status, readiness_elapsed = self._wait_for_url_ready(
                readiness_url, has_sidecars=has_sidecars, is_static=is_static,
            ) if readiness_url else ("skipped", 0.0)

            # Step 7: Return result
            result = DeploymentResult(
                deployment_id=deployment_id,
                frontend_url=frontend_url,
                thirdweb_url=thirdweb_url,
                cid=cid,
                app_store_url=app_store_url,
                manifest=manifest,
                custom_domain=custom_domain_url,
                hosting_type="akash" if hosting == "akash" else "static",
                provider_url=akash_deploy_result.url if akash_deploy_result else None,
                estimated_monthly_cost=akash_deploy_result.estimated_monthly_cost if akash_deploy_result else 0.0,
                free_credits_remaining=0.0,
                docker_image=None,  # No Docker — apps deploy via git clone on Akash
                readiness_status=readiness_status,
                readiness_elapsed_seconds=readiness_elapsed,
            )

            # Print a status line that reflects whether the URL actually
            # responded. Callers (app_deploy.py) render the panel based on
            # `result.readiness_status` and can show appropriate guidance.
            if readiness_status == "ready":
                self._log(f"✅ Live at {result.frontend_url}  ({readiness_elapsed:.0f}s)")
            elif readiness_status == "timeout":
                self._log(
                    f"🟢 Deployed. Your app is starting up — this can take a few minutes."
                )
                self._log(f"   It'll be live at {result.frontend_url} shortly — open it in a few minutes.")
                self._log("   Re-check anytime:  varitykit app status")
            elif readiness_status == "failed":
                self._log("🔴 Deployed, but your app isn't responding yet.")
                self._log(f"   Try again in a few minutes:  {result.frontend_url}")
                self._log("   If it stays down, redeploy with:  varitykit app deploy")
            else:  # 'skipped'
                self._log(f"✅ Deployed. Your app: {result.frontend_url}\n")

            _telem.update({
                "success": True,
                "duration_seconds": round(time.monotonic() - _t_start, 1),
                "deploy_id": result.deployment_id,
                "frontend_url": result.frontend_url,
            })
            self._emit_telemetry(_telem)
            self._write_wm_entities(_telem)
            self._run_learned_recommender(_telem)
            return result

        except ProjectDetectionError as e:
            self._log(f"❌ Could not detect project type: {e}")
            self._log("   Supported: Next.js, React, Vue")
            self._log("   Ensure package.json exists")
            _telem.update({"success": False, "error_class": "detection_error", "error_message": str(e), "error_type": type(e).__name__, "failure_stage": "framework_detection", "duration_seconds": round(time.monotonic() - _t_start, 1)})
            self._emit_telemetry(_telem)
            self._write_wm_entities(_telem)
            raise

        except BuildError as e:
            self._log(f"❌ Build failed: {e}")
            self._log("   Try running build manually first")
            _telem.update({"success": False, "error_class": "build_error", "error_message": str(e), "error_type": type(e).__name__, "failure_stage": "build_execution", "duration_seconds": round(time.monotonic() - _t_start, 1)})
            self._emit_telemetry(_telem)
            self._write_wm_entities(_telem)
            raise

        except IPFSUploadError as e:
            self._log(f"❌ Deployment failed: {e}")
            self._log("   Please try again or contact support: https://discord.gg/7vWsdwa2Bg")
            _telem.update({"success": False, "error_class": "upload_error", "error_message": str(e), "error_type": type(e).__name__, "failure_stage": "ipfs_upload", "duration_seconds": round(time.monotonic() - _t_start, 1)})
            self._emit_telemetry(_telem)
            self._write_wm_entities(_telem)
            raise

        except Exception as e:
            self._log(f"❌ Deployment failed: {e}")
            _telem.update({"success": False, "error_class": "runtime_error", "error_message": str(e), "error_type": type(e).__name__, "duration_seconds": round(time.monotonic() - _t_start, 1)})
            # Preserve a stage set earlier (repo_access / sdl_submission /
            # bid_collection / lease_acceptance / container_health); only fall
            # back to a generic stage when nothing more specific was recorded.
            _telem.setdefault("failure_stage", "orchestration")
            self._emit_telemetry(_telem)
            self._write_wm_entities(_telem)
            raise DeploymentError(f"Deployment failed: {e}")

    def deploy_agent(
        self,
        agent_template: str,
        cli_env_overrides: Optional[Dict[str, str]] = None,
        custom_name: Optional[str] = None,
        non_interactive: bool = False,
        dry_run: bool = False,
        network: str = "varity",
    ) -> DeploymentResult:
        """
        Deploy a curated AI agent template through the standard orchestration pipeline.

        Agents skip the project-detection and build steps (image is pre-built,
        SDL is vendored) but otherwise go through the SAME post-deploy pipeline
        as every other Akash app: subdomain availability check, deploy with $5
        deposit, register_akash_domain, manifest creation, local history save,
        wait for URL ready, telemetry. This means everything that works for
        a regular `varitykit app deploy` (app list, info, status, dashboard,
        billing-meter) also works for `varitykit app deploy --agent <name>`.

        Adding a new agent in the future is just: drop a YAML in
        templates/agents/<slug>.yaml + add a JSON entry in agents.json. No code
        changes required.
        """
        from varitykit.commands.agent import get_agent_metadata, load_agent_sdl
        from varitykit.services.agent_deployer import (
            collect_env_values, render_sdl_with_env,
        )
        from varitykit.services.akash_deploy_service import _resolve_api_key
        from varitykit.core.akash.console_deployer import AkashConsoleDeployer
        from varitykit.core.akash.types import AkashError
        from varitykit.services.gateway_client import (
            register_akash_domain, sanitize_subdomain,
            check_availability, get_deploy_key, GatewayError,
        )
        import varitykit as _vk

        cli_env_overrides = cli_env_overrides or {}
        _run_id = str(uuid.uuid4())
        _t_start = time.monotonic()
        _telem: Dict = {
            "run_id": _run_id,
            "ts": datetime.now().isoformat(),
            "hosting_requested": "akash",
            "cli_version": getattr(_vk, "__version__", "unknown"),
            "agent_template": agent_template,
            "project_type": "agent",
        }

        try:
            self._log("🚀 Starting agent deployment...")

            # ── Phase 1: load template + synthesize ProjectInfo ──
            sdl_yaml, metadata = load_agent_sdl(agent_template)
            agent_display_name = metadata.get("name", agent_template)
            agent_description = metadata.get("description", "")
            estimated_cost = float(metadata.get("estimated_cost_per_month_usd", 0))

            self._log(f"📦 Agent template: {agent_display_name}")
            self._log(f"   Image: {metadata.get('primary_image', '?')}")
            self._log(f"   Est. cost: ~${estimated_cost:.0f}/month")

            # Synthetic ProjectInfo so the existing manifest + history paths
            # work without modification. project_type="agent" is the marker
            # that downstream telemetry / dashboard code can use to render the
            # right icon / category.
            project_info = ProjectInfo(
                name=agent_template,
                project_type="agent",
                framework_version=None,
                build_command="",
                output_dir="",
                package_manager="",
                display_name=agent_display_name,
                description=agent_description,
                has_backend=True,
            )

            # User identity for telemetry + ownerId on the domain record.
            owner_id = None
            try:
                import hashlib as _hl
                owner_id = get_deploy_key()
                _telem["user_id"] = _hl.sha256(owner_id.encode()).hexdigest()[:16] if owner_id else None
            except Exception:
                pass

            # ── Phase 2.7: subdomain availability check (matches regular deploy) ──
            subdomain = sanitize_subdomain(custom_name or agent_template)
            try:
                availability = check_availability(subdomain)
                if availability and not availability.get("available", True):
                    raise DeploymentError(
                        f"Subdomain '{subdomain}' is already taken. "
                        f"Pick a different name with --name <yourname>."
                    )
            except GatewayError as e:
                # Non-fatal: the gateway may be unreachable; the deploy will
                # still try register at Step 3.5 and surface conflicts then.
                self._log("   ⚠️ Skipping name-availability check — continuing.")

            # ── Phase 3a: collect env values + render SDL ──
            self._log("🔧 Configuring agent...")
            required_count = len(metadata.get("required_env", []))
            if required_count:
                self._log(
                    f"   This agent needs {required_count} required value(s). "
                    f"You'll be prompted for any not already set."
                )
            env_values = collect_env_values(
                agent_template, sdl_yaml, metadata, cli_env_overrides,
                non_interactive=non_interactive,
            )
            # Many apps reject API/WebSocket calls unless their public origin
            # is allowlisted (Agent Zero: "Origin None not allowed"; Next.js:
            # NEXTAUTH_URL; Django: ALLOWED_HOSTS; etc.). A template declares
            # which env keys must carry its public URL via `public_url_env`;
            # inject https://<subdomain>.varity.app into each (unless the user
            # already supplied a value via --env, which still wins).
            public_url = f"https://{subdomain}.varity.app"
            for env_key in metadata.get("public_url_env", []):
                if env_key not in env_values:
                    env_values[env_key] = public_url
            primary_service = metadata.get("primary_service") or "app"
            final_sdl = render_sdl_with_env(sdl_yaml, env_values, primary_service)
            _telem["env_var_count"] = len(env_values)

            # Parity with the framework path: recover the orchestration decision
            # surface (hardware + sidecars + image + port) from the vendored SDL
            # so agent telemetry is never thinner than a regular deploy.
            _spec = self._extract_sdl_spec(final_sdl, primary_service)
            _agent_sidecars = _spec["sidecars_added"]
            _telem.update({
                "sidecars_added": _agent_sidecars,
                "image": _spec["image"] or metadata.get("primary_image"),
                "port": _spec["port"],
                "cpu": _spec["cpu"],
                "memory_mb": _spec["memory_mb"],
                "storage_mb": _spec["storage_mb"],
                "dependency_signals": {
                    "has_pg": any("postgres" in s or "pgvector" in s for s in _agent_sidecars),
                    "has_redis": any("redis" in s for s in _agent_sidecars),
                    "has_mongodb": any("mongo" in s for s in _agent_sidecars),
                    "has_ollama": any("ollama" in s for s in _agent_sidecars),
                    "has_mysql": any("mysql" in s or "mariadb" in s for s in _agent_sidecars),
                    "has_prisma": False,
                },
            })

            if dry_run:
                self._log("🟡 DRY RUN — SDL rendered, deploy not submitted.")
                self._log(final_sdl)
                # Return a stub so callers don't crash.
                return DeploymentResult(
                    deployment_id="dry-run",
                    frontend_url=f"https://{subdomain}.varity.app/",
                    thirdweb_url="",
                    cid=f"akash:dry-run",
                    app_store_url=None,
                    manifest={"dry_run": True, "agent_template": agent_template},
                    custom_domain=f"https://{subdomain}.varity.app/",
                    hosting_type="akash",
                    provider_url=None,
                    estimated_monthly_cost=estimated_cost,
                )

            # ── Phase 3b: submit the pre-built SDL to Akash ──
            self._log("☁️  Deploying to compute platform...")
            api_key = _resolve_api_key()
            deployer = AkashConsoleDeployer(api_key=api_key, on_progress=self._log)
            _akash_t0 = time.monotonic()
            # deposit=5 matches akash_deploy_service.py:534 (regular dynamic
            # deploys). The Managed Wallet API takes deposit in whole USDC.
            try:
                deploy_response = deployer.deploy(
                    sdl=final_sdl, deposit=5,
                    primary_service=metadata.get("primary_service"),
                )
            except AkashError as e:
                # Pinpoint the failing stage from the console deployer
                # (sdl_submission / bid_collection / lease_acceptance).
                _telem["failure_stage"] = getattr(e, "failure_stage", None) or "sdl_submission"
                raise
            _telem["container_first_response_seconds"] = round(time.monotonic() - _akash_t0, 1)

            # Provider bid set + winner — parity with the framework path (the RL
            # action space + cost counterfactual).
            _telem["provider_bids"] = deploy_response.get("provider_bids", [])
            _telem["selected_provider"] = deploy_response.get("provider", "")
            _telem["selected_price"] = deploy_response.get("selected_price", 0.0)
            _telem["bid_count"] = deploy_response.get("bid_count", 0)

            dseq = deploy_response.get("dseq", "")
            provider = deploy_response.get("provider", "")
            provider_url = deploy_response.get("url", "")

            if not dseq:
                _telem["failure_stage"] = "lease_acceptance"
                raise DeploymentError("Akash accepted the SDL but returned no deployment ID.")

            # Synthesize an AkashDeploymentResult-shape so the existing
            # _create_manifest / register flow works as-is.
            class _AgentAkashResult:
                success = True
                def __init__(self, dseq, url, provider, cost):
                    self.dseq = dseq
                    self.url = url
                    self.provider = provider
                    self.estimated_monthly_cost = cost
                    self.error_message = ""
            akash_result = _AgentAkashResult(dseq, provider_url, provider, estimated_cost)

            frontend_url = provider_url
            cid = f"akash:{dseq}"
            self._log("   Setting up your app…")

            # ── Phase 3.5: register domain with the gateway (the missing step!) ──
            custom_domain_url = None
            try:
                self._log("   Setting up your app's web address…")
                register_akash_domain(
                    subdomain=subdomain,
                    deployment_url=provider_url,
                    deployment_id=dseq,
                    app_name=agent_display_name,
                    tagline=agent_description,
                    owner_id=owner_id,
                    provider=provider,
                )
                custom_domain_url = f"https://{subdomain}.varity.app/"
                frontend_url = custom_domain_url
                self._log(f"   🌐 {custom_domain_url}")
            except Exception as e:
                # Don't fail the deploy — the app's web address just needs a
                # moment. Never surface the raw error/provider detail.
                self._log("   ⚠️ Your app's web address is being finalized — ready shortly.")

            # ── Phase 4: synthesize BuildArtifacts + manifest ──
            # _create_manifest expects a BuildArtifacts. Agents don't build
            # anything locally, so we pass a stub.
            build_artifacts = BuildArtifacts(
                success=True,
                output_dir="",
                files=[],
                entrypoint="",
                total_size_mb=0.0,
                build_time_seconds=0.0,
            )
            manifest = self._create_manifest(
                project_info, build_artifacts, ipfs_result=None,
                network=network, hosting="akash",
                akash_result=akash_result, project_path=None,
            )
            # Agents-specific manifest enrichment.
            manifest["agent"] = {
                "template": agent_template,
                "image": metadata.get("primary_image"),
                "required_env": metadata.get("required_env", []),
                "exposed_ports": metadata.get("exposed_ports", []),
            }
            if custom_domain_url:
                manifest["custom_domain"] = {
                    "subdomain": subdomain,
                    "url": custom_domain_url,
                    "owner_id": owner_id,
                }

            # ── Phase 5: save to local deployment history ──
            deployment_id = self._save_deployment(manifest)

            # ── Phase 6.5: wait for the URL to actually serve traffic ──
            http_health = metadata.get("http_health", True)
            exposed_ports = metadata.get("exposed_ports", []) or []
            ssh_only = (http_health is False) or (exposed_ports == [22])
            if ssh_only:
                # SSH workstations (e.g. autoresearch, port 22) have no HTTP
                # endpoint to probe — skip readiness rather than report a
                # false failure.
                readiness_status, readiness_elapsed = "ssh_only", 0.0
            else:
                # readiness_url is the varity.app subdomain — the gateway
                # already routes it to the template's primary service/port,
                # so multi-port templates (e.g. eliza-venice 3000/5173/5174)
                # are handled gateway-side, no special-casing here.
                readiness_url = custom_domain_url or frontend_url
                readiness_status, readiness_elapsed = self._wait_for_url_ready(
                    readiness_url, has_sidecars=False, is_static=False,
                    warmup_override=metadata.get("warmup_seconds"),
                ) if readiness_url else ("skipped", 0.0)

            # ── Phase 7: return + telemetry ──
            result = DeploymentResult(
                deployment_id=deployment_id,
                frontend_url=frontend_url,
                thirdweb_url="",
                cid=cid,
                app_store_url=None,
                manifest=manifest,
                custom_domain=custom_domain_url,
                hosting_type="akash",
                provider_url=provider_url,
                estimated_monthly_cost=estimated_cost,
                free_credits_remaining=0.0,
                docker_image=metadata.get("primary_image"),
                readiness_status=readiness_status,
                readiness_elapsed_seconds=readiness_elapsed,
            )

            if readiness_status == "ready":
                self._log(f"✅ Live at {result.frontend_url}  ({readiness_elapsed:.0f}s)")
            elif readiness_status == "timeout":
                self._log(
                    f"🟢 Deployed. {agent_display_name} is starting up — heavy agents "
                    f"take a few minutes to come online the first time."
                )
                self._log(f"   It'll be live at {result.frontend_url} shortly — open it in a few minutes.")
                self._log("   Re-check anytime:  varitykit app status")
            elif readiness_status == "failed":
                self._log(f"🔴 Deployed, but {agent_display_name} isn't responding yet.")
                self._log(f"   Try again in a few minutes:  {result.frontend_url}")
                self._log(f"   If it stays down, redeploy:  varitykit app deploy --agent {agent_template}")
            elif readiness_status == "ssh_only":
                self._log(f"✅ Deployed. {agent_display_name} is an SSH workstation (not a web app).")
                self._log("   Connect using the SSH key you provided.")
            else:
                self._log(f"✅ Deployed. Your app: {result.frontend_url}\n")

            if readiness_status == "failed":
                # Lease landed but the app served 4xx/5xx for the whole window —
                # record an honest container_health failure (parity with the
                # framework path, which gates success on health). "timeout"
                # (still warming) is NOT a failure.
                _telem.update({
                    "success": False,
                    "error_class": "container_health",
                    "error_type": "ContainerUnhealthy",
                    "error_message": f"{agent_display_name} did not respond after deploy (readiness failed).",
                    "failure_stage": "container_health",
                    "duration_seconds": round(time.monotonic() - _t_start, 1),
                    "deploy_id": result.deployment_id,
                    "frontend_url": result.frontend_url,
                })
            else:
                _telem.update({
                    "success": True,
                    "duration_seconds": round(time.monotonic() - _t_start, 1),
                    "deploy_id": result.deployment_id,
                    "frontend_url": result.frontend_url,
                })
            self._emit_telemetry(_telem)
            self._write_wm_entities(_telem)
            return result

        except DeploymentError as e:
            _telem.update({"success": False, "error_class": "deployment_error",
                          "error_message": str(e), "error_type": type(e).__name__,
                          "duration_seconds": round(time.monotonic() - _t_start, 1)})
            _telem.setdefault("failure_stage", "orchestration")
            self._emit_telemetry(_telem)
            self._write_wm_entities(_telem)
            raise
        except Exception as e:
            self._log(f"❌ Agent deployment failed: {e}")
            _telem.update({"success": False, "error_class": "runtime_error",
                          "error_message": str(e), "error_type": type(e).__name__,
                          "duration_seconds": round(time.monotonic() - _t_start, 1)})
            _telem.setdefault("failure_stage", "orchestration")
            self._emit_telemetry(_telem)
            self._write_wm_entities(_telem)
            raise DeploymentError(f"Agent deployment failed: {e}")

    def _detect_project(self, project_path: str) -> ProjectInfo:
        """
        Detect project type using ProjectDetector (Agent 1).

        Args:
            project_path: Path to project directory

        Returns:
            ProjectInfo with detected project details
        """
        return self.detector.detect(project_path)

    def _build_project(self, project_path: str, project_info: ProjectInfo, extra_env: Optional[Dict[str, str]] = None) -> BuildArtifacts:
        """
        Build project using BuildManager (Agent 1).

        Args:
            project_path: Path to project directory
            project_info: Detected project information
            extra_env: Extra env vars to inject (e.g. NEXT_PUBLIC_BASE_PATH for sub-path deploys)

        Returns:
            BuildArtifacts with build results
        """
        return self.builder.build(
            project_path=project_path,
            build_command=project_info.build_command,
            output_dir=project_info.output_dir,
            extra_env=extra_env,
        )

    def _upload_to_ipfs(self, build_artifacts: BuildArtifacts):
        """
        Upload build artifacts to IPFS using IPFSUploader (Agent 2).

        Args:
            build_artifacts: Build output to upload

        Returns:
            IPFSUploadResult with CID, URLs, and metadata
        """
        return self.ipfs.upload(build_artifacts.output_dir)

    def _create_manifest(
        self,
        project_info: ProjectInfo,
        build_artifacts: BuildArtifacts,
        ipfs_result=None,
        network: str = "varity",
        hosting: str = "ipfs",
        akash_result=None,
        project_path: Optional[str] = None,
    ) -> dict:
        """
        Create deployment manifest.

        Args:
            project_info: Detected project information
            build_artifacts: Build output
            ipfs_result: IPFS upload result (None if using Akash)
            network: Target network
            hosting: Hosting type ("ipfs" or "akash")
            akash_result: Akash deployment result (None if using IPFS)
            project_path: Absolute path to the project directory

        Returns:
            Deployment manifest dictionary
        """
        # Use timestamp with microseconds to ensure uniqueness
        now = datetime.now()
        timestamp_microseconds = int(now.timestamp() * 1_000_000)
        deployment_id = f"deploy-{timestamp_microseconds}"

        manifest = {
            "version": "1.0",
            "deployment_id": deployment_id,
            "timestamp": datetime.now().isoformat(),
            "network": network,
            "hosting": hosting,
            # app_name / project_name are the slug used by varity_deploy_status to construct
            # the clean varity.app/<app_name>/ URL instead of falling back to deployment-ID URLs.
            "app_name": project_info.name,
            "project_name": project_info.display_name or project_info.name,
            "cwd": str(project_path) if project_path else None,
            "project": {
                "name": project_info.name,
                "display_name": project_info.display_name or project_info.name,
                "type": project_info.project_type,
                "framework_version": project_info.framework_version,
                "build_command": project_info.build_command,
                "package_manager": project_info.package_manager,
            },
            "build": {
                "success": build_artifacts.success,
                "files": len(build_artifacts.files),
                "size_mb": build_artifacts.total_size_mb,
                "time_seconds": build_artifacts.build_time_seconds,
                "output_dir": build_artifacts.output_dir,
            },
        }

        # Add hosting-specific metadata
        if hosting == "akash" and akash_result:
            manifest["akash"] = {
                "dseq": akash_result.dseq,
                "url": akash_result.url,
                "provider": akash_result.provider,
                "estimated_monthly_cost": akash_result.estimated_monthly_cost,
            }
        elif ipfs_result:
            manifest["ipfs"] = {
                "cid": ipfs_result.cid,
                "gateway_url": ipfs_result.gateway_url,
                "thirdweb_url": ipfs_result.thirdweb_url,
                "total_size": ipfs_result.total_size,
                "file_count": ipfs_result.file_count,
            }

        return manifest

    def _save_deployment(self, manifest: dict) -> str:
        """
        Save deployment metadata locally.

        Args:
            manifest: Deployment manifest dictionary

        Returns:
            Deployment ID
        """
        # Create deployments directory
        deployments_dir = Path.home() / ".varitykit" / "deployments"
        deployments_dir.mkdir(parents=True, exist_ok=True)

        deployment_id = manifest["deployment_id"]
        filepath = deployments_dir / f"{deployment_id}.json"

        # Save manifest to file
        with open(filepath, "w") as f:
            json.dump(manifest, f, indent=2)

        self._log(f"   Saved deployment metadata to: {filepath}")

        return deployment_id

    def _save_ghost_deployment(self, akash_result, project_info: "ProjectInfo", project_path: str, network: str) -> str:
        """Save a minimal record for a deployment whose container warmup timed out.

        The Akash network accepted the SDL (dseq assigned) but the container
        never passed the health check. Without this record the user cannot
        discover or cancel the running ghost deploy, and credits keep draining.
        """
        deployments_dir = Path.home() / ".varitykit" / "deployments"
        deployments_dir.mkdir(parents=True, exist_ok=True)

        now = datetime.now()
        deployment_id = f"deploy-{int(now.timestamp() * 1_000_000)}"
        filepath = deployments_dir / f"{deployment_id}.json"

        manifest = {
            "version": "1.0",
            "deployment_id": deployment_id,
            "timestamp": now.isoformat(),
            "network": network,
            "hosting": "akash",
            "status": "warmup_timeout",
            "app_name": project_info.name,
            "project_name": project_info.display_name or project_info.name,
            "cwd": str(project_path),
            "akash": {
                "dseq": akash_result.dseq,
                "url": akash_result.url,
                "provider": akash_result.provider,
            },
        }

        with open(filepath, "w") as f:
            json.dump(manifest, f, indent=2)

        self._log("   Saved. Check status anytime with: varitykit app status")
        return deployment_id

    def get_deployment(self, deployment_id: str) -> Optional[dict]:
        """
        Retrieve deployment manifest by ID.

        Args:
            deployment_id: Deployment ID to retrieve

        Returns:
            Deployment manifest dictionary or None if not found
        """
        deployments_dir = Path.home() / ".varitykit" / "deployments"
        filepath = deployments_dir / f"{deployment_id}.json"

        if not filepath.exists():
            return None

        with open(filepath, "r") as f:
            return json.load(f)

    def list_deployments(self, network: Optional[str] = None) -> list:
        """
        List all deployments.

        Args:
            network: Filter by network (optional)

        Returns:
            List of deployment manifest dictionaries
        """
        deployments_dir = Path.home() / ".varitykit" / "deployments"

        if not deployments_dir.exists():
            return []

        deployments = []
        for filepath in deployments_dir.glob("deploy-*.json"):
            with open(filepath, "r") as f:
                manifest = json.load(f)

                # Filter by network if specified
                if network is None or manifest.get("network") == network:
                    deployments.append(manifest)

        # Sort by timestamp (newest first)
        deployments.sort(key=lambda x: x["timestamp"], reverse=True)

        return deployments

    def _submit_to_app_store(
        self, project_info: ProjectInfo, deployment_result: dict, project_path: str, network: str, tier: str = "free"
    ):
        """
        Submit app to Varity App Store (Phase 2 - Agent 6).

        Args:
            project_info: Detected project information
            deployment_result: Deployment result with frontend_url
            project_path: Path to project directory
            network: Target network

        Returns:
            SubmissionResult or None if submission fails
        """
        try:
            from .app_store.metadata_builder import MetadataBuilder

            # Determine chain ID from network
            chain_id_map = {
                "varity": 33529,
                "arbitrum": 42161,
                "arbitrum-sepolia": 421614,
                "base": 8453,
                "base-sepolia": 84532,
            }
            chain_id = chain_id_map.get(network, 33529)

            # Build package.json path
            import os

            package_json_path = os.path.join(project_path, "package.json")

            if not os.path.exists(package_json_path):
                self._log(f"   ⚠️  package.json not found at {package_json_path}")
                return None

            # Build metadata from deployment
            builder = MetadataBuilder()
            metadata = builder.build_from_deployment(
                project_info=project_info,
                deployment_result=deployment_result,
                package_json_path=package_json_path,
                chain_id=chain_id,
                tier=tier,
            )

            # Submit to App Store contract
            result = self.app_store.submit_app(metadata)

            return result

        except Exception as e:
            self._log(f"   ⚠️  App Store submission error: {e}")
            return None

    def _log(self, message: str):
        """Log message if verbose mode is enabled (jargon-redacted backstop)."""
        if self.verbose:
            from varitykit.core.output_sanitizer import redact_jargon
            print(redact_jargon(message))

    def _wait_for_url_ready(
        self,
        url: str,
        has_sidecars: bool,
        is_static: bool,
        url_checker=None,
        warmup_override=None,
    ):
        """
        Poll the user-facing URL until it responds with HTTP 200, or until the
        warmup window elapses. Returns a tuple ``(status, elapsed_seconds)``
        where status is one of:

          - ``'ready'``   — URL returned a 2xx response. Deploy is live.
          - ``'timeout'`` — Warmup window elapsed without the URL ever
                            returning 2xx. The deploy is registered and the
                            container may still be starting; caller should
                            print a "still warming up" message rather than
                            success.
          - ``'failed'``  — URL returned 4xx/5xx for every poll throughout the
                            window. Likely a real failure (bad container, port
                            mismatch, app crash). Caller should suggest logs.
          - ``'skipped'`` — No URL supplied (caller should not call this).

        Timeouts are tuned to the shape of the deployment so non-technical
        users see honest progress rather than a misleading "✅ Deployed" the
        moment the lease lands (F4-8a):

          - Static (IPFS): 30s total (DNS + gateway propagation; no container)
          - Single-container Akash: 60s (image pull + container start)
          - Multi-service Akash: 150s (sidecars must boot too; e.g. ollama
            pre-pulls a model)

        Polling shape: 5s initial wait → poll every 3s. Progress messages
        change to keep the user oriented during longer waits.

        ``url_checker`` is an optional injected function for testing — it
        receives ``url`` and returns ``(status_code, body_bytes)``. Default
        uses ``urllib.request`` with a 5s timeout. Always passes a
        Varity-Deploy-Poll User-Agent so the gateway can filter probe traffic
        out of telemetry.
        """
        import time as _time
        import urllib.request
        import urllib.error

        if not url:
            return "skipped", 0.0

        if is_static:
            total_timeout = 30
        elif has_sidecars:
            total_timeout = 150
        else:
            total_timeout = 60

        # Per-template override (heavy agent images cold-boot in minutes).
        if warmup_override and warmup_override > 0:
            total_timeout = warmup_override
        is_heavy = bool(warmup_override and warmup_override >= 240)

        # A gateway 502/503 means the ingress is up but the upstream container
        # is still booting — that is "still warming", NEVER a failure. Only
        # genuine 4xx/5xx from a live-but-broken app counts toward 'failed'.
        _INGRESS_NOT_READY = {502, 503}

        def default_check(target):
            req = urllib.request.Request(
                target,
                headers={"User-Agent": "Varity-Deploy-Poll/1.0"},
            )
            try:
                with urllib.request.urlopen(req, timeout=5) as resp:
                    return resp.status, b""
            except urllib.error.HTTPError as e:
                return e.code, b""
            except Exception:
                return 0, b""

        check = url_checker or default_check

        deploy_kind = "static deploy" if is_static else (
            "multi-service deploy" if has_sidecars else "single-container deploy"
        )
        self._log(f"   ⏳ Provisioning your {deploy_kind}...")

        # Initial settle delay — let gateway propagate before our first probe.
        _time.sleep(5)

        start = _time.monotonic()
        last_progress_at = start
        last_code = None
        non_2xx_count = 0
        total_polls = 0

        while True:
            elapsed = _time.monotonic() - start
            if elapsed >= total_timeout:
                break

            code, _ = check(url)
            total_polls += 1
            last_code = code

            if 200 <= code < 300:
                return "ready", round(_time.monotonic() - start, 1)

            # 502/503 = ingress up, container still warming → not a failure.
            if code >= 400 and code not in _INGRESS_NOT_READY:
                non_2xx_count += 1

            # Progress messages — shown periodically so the user knows it
            # isn't stuck. Choice of message depends on elapsed time.
            now = _time.monotonic()
            if now - last_progress_at >= 12:
                if is_heavy:
                    self._log(
                        "   …heavy agent image — first boot can take a few minutes"
                    )
                elif has_sidecars:
                    self._log(
                        "   …still warming up — multi-service deploys can take up to 2 minutes"
                    )
                elif is_static:
                    self._log("   …gateway is propagating the new route")
                else:
                    self._log("   …container is starting up")
                last_progress_at = now

            _time.sleep(3)

        # Timeout reached without a 2xx response.
        elapsed = round(_time.monotonic() - start, 1)
        # If every single poll returned an error code, that's a stronger
        # signal than "still warming". Only call it 'failed' when we have at
        # least 5 polls all in the 4xx/5xx range.
        if total_polls >= 5 and non_2xx_count == total_polls and last_code and last_code >= 400:
            return "failed", elapsed
        return "timeout", elapsed

    @staticmethod
    def _resolve_github_url(project_path: str) -> str:
        """
        Resolve GitHub repo URL from the project directory.

        Checks (in order):
        1. varity.config.json → github_repo field
        2. .git/config → remote origin URL
        3. Raises error if neither found
        """
        from pathlib import Path
        import json
        import subprocess

        path = Path(project_path)

        # 1. Check varity.config.json
        config_path = path / "varity.config.json"
        if config_path.exists():
            try:
                config = json.loads(config_path.read_text())
                repo = config.get("github_repo") or config.get("repo") or config.get("repository")
                if repo:
                    return repo
            except (json.JSONDecodeError, IOError):
                pass

        # 2. Check git remote
        try:
            result = subprocess.run(
                ["git", "remote", "get-url", "origin"],
                cwd=project_path,
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                url = result.stdout.strip()
                # Convert SSH to HTTPS if needed
                if url.startswith("git@github.com:"):
                    url = url.replace("git@github.com:", "https://github.com/")
                if url.endswith(".git"):
                    url = url[:-4]
                return url + ".git"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        raise DeploymentError(
            "No GitHub repository found. Dynamic hosting requires a public GitHub repo.\n"
            "Push your code to GitHub first, or add 'github_repo' to varity.config.json."
        )

    # ------------------------------------------------------------------
    # Service detection — which backend services does this app need?
    # Today: postgres, redis, ollama, mongodb. Future: vector DBs, kafka,
    # crypto-project modules (IPFS node, Graph node, Ceramic, etc.).
    # The orchestrator is intentionally small — adding a service means
    # extending the signal maps + the SDL template, not rewiring control flow.
    # ------------------------------------------------------------------

    _JS_DEPENDENCY_SIGNALS = {
        "postgres": {
            "pg", "postgres", "@neondatabase/serverless", "pg-promise",
            "sequelize", "typeorm", "drizzle-orm",
            "kysely", "knex", "@supabase/supabase-js", "mikro-orm",
            "slonik",
        },
        "mysql": {"mysql2", "mysql", "@planetscale/database"},
        "mongodb": {"mongoose", "mongodb", "mongosh"},
        "redis": {
            "ioredis", "redis", "bullmq", "bull", "connect-redis",
            "@upstash/redis",
        },
        "ollama": {
            "@langchain/ollama", "ollama", "ollama-ai-provider",
        },
    }

    _PY_DEPENDENCY_SIGNALS = {
        "postgres": {
            "psycopg", "psycopg2", "psycopg2-binary", "asyncpg",
            "sqlalchemy", "databases", "tortoise-orm", "peewee",
            "django",
        },
        "mysql": {
            "mysqlclient", "mysql-connector-python", "aiomysql",
            "asyncmy", "PyMySQL",
        },
        "mongodb": {"pymongo", "motor", "beanie", "mongoengine", "odmantic"},
        "redis": {"redis", "aioredis", "hiredis", "rq", "celery", "dramatiq", "huey"},
        "ollama": {"ollama", "langchain-ollama"},
    }

    _SERVICE_ORDER = ("postgres", "mysql", "redis", "ollama", "mongodb")

    @classmethod
    def _detect_services(cls, project_path: str) -> List[str]:
        """Detect backend services this app needs.

        Returns service names in canonical order: postgres, redis, ollama,
        mongodb. The caller passes this list to akash_deploy_service.deploy()
        which renders the matching sidecars into the SDL.

        Signals checked (all additive — any match triggers the service):
          1. package.json dependencies (JS projects)
          2. Prisma schema datasource provider (determines postgres vs mongodb)
          3. requirements.txt / pyproject.toml (Python projects)
          4. varity.config.json database.collections (legacy Varity DB signal)
        """
        path = Path(project_path)
        detected: set[str] = set()

        # 1. JS dependencies
        pkg_path = path / "package.json"
        if pkg_path.exists():
            try:
                pkg = json.loads(pkg_path.read_text())
                js_deps = set(pkg.get("dependencies", {}).keys()) | set(
                    pkg.get("devDependencies", {}).keys()
                )
                for service, signals in cls._JS_DEPENDENCY_SIGNALS.items():
                    if signals & js_deps:
                        detected.add(service)

                # 2. Prisma is provider-agnostic — inspect schema to choose
                # postgres vs mongodb. Without a schema, default to postgres
                # (the overwhelmingly common case).
                if "@prisma/client" in js_deps or "prisma" in js_deps:
                    provider = cls._prisma_provider(path)
                    if provider in ("postgresql", "postgres"):
                        detected.add("postgres")
                    elif provider == "mongodb":
                        detected.add("mongodb")
                    elif provider in ("mysql", "mariadb"):
                        detected.add("mysql")
                    elif provider is None:
                        detected.add("postgres")
            except (json.JSONDecodeError, IOError):
                pass

        # 3. Python dependencies
        for dep_file in ("requirements.txt", "pyproject.toml"):
            dep_path = path / dep_file
            if dep_path.exists():
                try:
                    text = dep_path.read_text()
                    for service, signals in cls._PY_DEPENDENCY_SIGNALS.items():
                        for sig in signals:
                            # Match at line start or after a quote/whitespace,
                            # followed by extras ([srv]), version spec, quote,
                            # whitespace, or EOL.  Prevents substring false
                            # positives (e.g. "mongodb-stubs" not matching
                            # "mongodb") while allowing extras like pymongo[srv].
                            pattern = (
                                rf'(?:^|["\'\s]){re.escape(sig)}'
                                rf'(?:\[[\w,]+\])?'
                                rf'(?:\s*[<>=!~]|["\'\s,]|$)'
                            )
                            if re.search(pattern, text, re.MULTILINE):
                                detected.add(service)
                                break
                except IOError:
                    pass

        # 4. Legacy Varity DB collections → postgres
        config_path = path / "varity.config.json"
        if config_path.exists():
            try:
                config = json.loads(config_path.read_text())
                if config.get("database", {}).get("collections"):
                    detected.add("postgres")
            except (json.JSONDecodeError, IOError):
                pass

        return [s for s in cls._SERVICE_ORDER if s in detected]

    @staticmethod
    def _prisma_provider(project_root: Path) -> Optional[str]:
        """Read prisma/schema.prisma and return the DATASOURCE provider
        (e.g. 'postgresql', 'mongodb', 'mysql').

        IMPORTANT: schema.prisma has TWO `provider = "..."` fields — one
        in the `generator` block (e.g. `prisma-client-js`) and one in the
        `datasource` block (the DB driver). We MUST pick the datasource
        one, not the first match in the file. Getting this wrong means
        Prisma apps never get the postgres sidecar auto-added.
        """
        schema = project_root / "prisma" / "schema.prisma"
        if not schema.exists():
            return None
        try:
            content = schema.read_text()
            # Match: datasource <name> { ... provider = "..." ... }
            # The datasource block is where the real DB provider lives.
            ds_match = re.search(
                r'datasource\s+\w+\s*\{[^}]*?provider\s*=\s*"([^"]+)"',
                content,
                re.DOTALL,
            )
            if ds_match:
                return ds_match.group(1).lower()
        except IOError:
            pass
        return None

    # ------------------------------------------------------------------
    # Env var loading — reads the user's local .env file and forwards
    # non-reserved / non-platform-leakage keys into the Akash SDL.
    # Filepath precedence: .env.varity → .env.local → .env
    # (first match wins; the rest are ignored to avoid merging surprises).
    # ------------------------------------------------------------------

    # Keys Varity generates/controls — if the user has them in .env we
    # silently skip, so we never let a stale local DATABASE_URL override
    # the one we wire to the postgres sidecar.
    _VARITY_RESERVED_ENV_KEYS = frozenset({
        "NODE_ENV", "PORT", "NODE_OPTIONS",
        "PYTHONUNBUFFERED",
        "DATABASE_URL", "REDIS_URL", "OLLAMA_URL", "MONGODB_URI",
        "MYSQL_URL",
        "POSTGRES_USER", "POSTGRES_PASSWORD", "POSTGRES_DB", "PGDATA",
        "MONGO_INITDB_ROOT_USERNAME", "MONGO_INITDB_ROOT_PASSWORD",
        "MONGO_INITDB_DATABASE",
        "MYSQL_ROOT_PASSWORD", "MYSQL_DATABASE", "MYSQL_USER", "MYSQL_PASSWORD",
        "APP_NAME",
    })

    # Prefixes that indicate a platform-injected var from another host.
    # A Vercel user migrating to Varity shouldn't carry over VERCEL_URL,
    # VERCEL_ENV, etc. — they're meaningless on Akash and often misleading.
    _PLATFORM_LEAK_PREFIXES = (
        "VERCEL_",
        "NEXT_RUNTIME",
        "AWS_",
        "RAILWAY_",
        "RENDER_",
        "NETLIFY_",
        "FLY_",
    )

    _ENV_FILE_PRECEDENCE = (".env.varity", ".env.local", ".env")

    @classmethod
    def _load_env_vars(cls, project_path: str) -> Dict[str, str]:
        """Load user-defined env vars from the project's .env file.

        Precedence: .env.varity > .env.local > .env. First match wins.
        Reserved Varity keys and platform-leaked prefixes are filtered so
        they don't override Varity-managed wiring or pollute the deployment.

        Returns {} if no recognized env file exists.
        """
        path = Path(project_path)
        for filename in cls._ENV_FILE_PRECEDENCE:
            env_file = path / filename
            if env_file.exists():
                raw = cls._parse_env_file(env_file)
                return {
                    k: v for k, v in raw.items()
                    if cls._is_user_env_key(k)
                }
        return {}

    @staticmethod
    def _parse_env_file(env_file: Path) -> Dict[str, str]:
        """Parse a .env file.

        Supports:
          - KEY=value
          - KEY="value with spaces"
          - KEY='value with spaces'
          - Lines starting with # (comments)
          - Blank lines
          - `export KEY=value` (shell-style prefix is stripped)

        Does not support multiline values or shell expansion — those aren't
        portable across .env parsers anyway.
        """
        out: Dict[str, str] = {}
        try:
            text = env_file.read_text(encoding="utf-8")
        except IOError:
            return out

        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # Allow `export KEY=value`
            if line.startswith("export "):
                line = line[len("export "):].lstrip()
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()
            # Strip matching surrounding quotes
            if len(value) >= 2 and (
                (value[0] == value[-1] == '"') or (value[0] == value[-1] == "'")
            ):
                value = value[1:-1]
            # Trim inline comments only on UNQUOTED values (after the strip
            # above, we've lost the quote context — so only strip ` #...` if
            # the original value wasn't quoted. To keep things simple, we
            # only strip inline comments when value has no spaces + a # later).
            if key:
                out[key] = value
        return out

    @classmethod
    def _is_user_env_key(cls, key: str) -> bool:
        """True if this key should be forwarded to the deployment."""
        if not key or not key[0].isalpha() and key[0] != "_":
            # Invalid env var name — skip silently
            return False
        if key in cls._VARITY_RESERVED_ENV_KEYS:
            return False
        if any(key.startswith(p) for p in cls._PLATFORM_LEAK_PREFIXES):
            return False
        return True

    @staticmethod
    def _has_prisma(project_path: str) -> bool:
        return (Path(project_path) / "prisma" / "schema.prisma").exists()

    _SKIP_SIZE_DIRS = frozenset({
        "node_modules", ".git", ".next", "__pycache__", ".mypy_cache",
        "dist", "build", ".venv", "venv", ".pytest_cache", ".turbo",
        ".cache", "coverage", ".nyc_output",
    })

    @classmethod
    def _compute_project_size(cls, project_path: str):
        """Walk the project tree (skipping build/cache dirs) and return (size_bytes, file_count)."""
        total_bytes = 0
        total_files = 0
        try:
            for root, dirs, files in os.walk(project_path):
                dirs[:] = [d for d in dirs if d not in cls._SKIP_SIZE_DIRS]
                for f in files:
                    try:
                        total_bytes += os.path.getsize(os.path.join(root, f))
                        total_files += 1
                    except OSError:
                        pass
        except Exception:
            pass
        return total_bytes, total_files

    @staticmethod
    def _extract_sdl_spec(sdl_yaml: str, primary_service: Optional[str] = None) -> Dict:
        """Recover the orchestration decision surface from a rendered Akash SDL.

        Agent deploys ship a vendored SDL instead of generating one from a
        detected framework, so the hardware/sidecar/image/port decisions live
        in the SDL rather than in code. Parsing them here brings agent
        telemetry to parity with the framework path. Returns sensible zero
        defaults on any parse failure (telemetry must never break a deploy).
        """
        from varitykit.services.akash_deploy_service import size_to_mb as _sz
        spec: Dict = {
            "image": None, "port": None, "cpu": 0.0,
            "memory_mb": 0, "storage_mb": 0, "sidecars_added": [],
        }
        try:
            import yaml as _yaml
            sdl = _yaml.safe_load(sdl_yaml) or {}
        except Exception:
            return spec

        services = sdl.get("services", {}) or {}
        primary = primary_service if primary_service in services else next(iter(services), None)
        if primary is None:
            return spec

        # Sidecars = every declared service other than the user-facing app.
        spec["sidecars_added"] = sorted(n for n in services if n != primary)

        psvc = services.get(primary, {}) or {}
        spec["image"] = psvc.get("image")
        expose = psvc.get("expose", []) or []
        if expose and isinstance(expose[0], dict):
            spec["port"] = expose[0].get("port")

        # Hardware: follow deployment[primary] → profile name → compute profile.
        profiles = (sdl.get("profiles", {}) or {}).get("compute", {}) or {}
        dep = (sdl.get("deployment", {}) or {}).get(primary, {}) or {}
        profile_name = None
        for grp in dep.values():
            if isinstance(grp, dict) and grp.get("profile"):
                profile_name = grp["profile"]
                break
        prof = profiles.get(profile_name or primary, {}) or {}
        res = prof.get("resources", prof) or {}

        cpu_raw = res.get("cpu")
        cpu_val = cpu_raw.get("units") if isinstance(cpu_raw, dict) else cpu_raw
        try:
            spec["cpu"] = float(cpu_val) if cpu_val is not None else 0.0
        except (TypeError, ValueError):
            spec["cpu"] = 0.0

        mem_raw = res.get("memory")
        mem_val = mem_raw.get("size") if isinstance(mem_raw, dict) else mem_raw
        spec["memory_mb"] = _sz(mem_val) if mem_val else 0

        sto_raw = res.get("storage")
        if isinstance(sto_raw, list) and sto_raw:
            sto_raw = sto_raw[0]
        sto_val = sto_raw.get("size") if isinstance(sto_raw, dict) else sto_raw
        spec["storage_mb"] = _sz(sto_val) if sto_val else 0

        return spec

    @staticmethod
    def _write_wm_entities(telem: Dict) -> None:
        """Write OrchestrationRun + DeployOutcome to the World Model DB.

        Fire-and-forget daemon thread. Only runs when WORLD_MODEL_DB_HOST is set
        (Varity infra). Silently no-ops on developer machines without WM access.
        """
        import os as _os
        wm_host = _os.environ.get("WORLD_MODEL_DB_HOST") or _os.environ.get("GRAPHITI_DB_HOST")
        if not wm_host:
            return

        def _write() -> None:
            try:
                import psycopg2
                import json as _json
            except ImportError:
                return
            try:
                wm_port = int(
                    _os.environ.get("WORLD_MODEL_DB_PORT")
                    or _os.environ.get("GRAPHITI_DB_PORT", "30096")
                )
                wm_user = (
                    _os.environ.get("WORLD_MODEL_DB_USER")
                    or _os.environ.get("GRAPHITI_DB_USER", "varity_wm")
                )
                wm_name = (
                    _os.environ.get("WORLD_MODEL_DB_NAME")
                    or _os.environ.get("GRAPHITI_DB_NAME", "varity_world_model")
                )
                wm_pass = (
                    _os.environ.get("WORLD_MODEL_DB_PASSWORD")
                    or _os.environ.get("GRAPHITI_DB_PASSWORD", "")
                )
                run_id = telem.get("run_id", "unknown")
                outcome_id = f"outcome-{run_id}"
                _outcome_keys = {
                    "success", "duration_seconds", "error_class", "error_message",
                    "error_type", "failure_stage", "container_first_response_seconds",
                }
                orch_props = {k: v for k, v in telem.items() if k not in _outcome_keys}
                orch_props["asserted_by"] = "varitykit"
                outcome_props = {k: telem[k] for k in _outcome_keys if k in telem}
                outcome_props["run_id"] = run_id
                outcome_props["asserted_by"] = "varitykit"

                conn = psycopg2.connect(
                    host=wm_host, port=wm_port, user=wm_user,
                    dbname=wm_name, password=wm_pass, connect_timeout=5,
                )
                try:
                    with conn:
                        with conn.cursor() as cur:
                            for etype, eid, props in [
                                ("OrchestrationRun", run_id, orch_props),
                                ("DeployOutcome", outcome_id, outcome_props),
                            ]:
                                cur.execute(
                                    "UPDATE world_model_entities SET valid_to = NOW() "
                                    "WHERE type = %s AND entity_id = %s AND valid_to IS NULL",
                                    (etype, eid),
                                )
                                cur.execute(
                                    "INSERT INTO world_model_entities "
                                    "(type, entity_id, props, valid_from) "
                                    "VALUES (%s, %s, %s::jsonb, NOW())",
                                    (etype, eid, _json.dumps(props)),
                                )
                            cur.execute(
                                "INSERT INTO world_model_relationships "
                                "(from_type, from_id, relation, to_type, to_id, asserted_by, valid_from) "
                                "VALUES (%s, %s, %s, %s, %s, %s, NOW()) "
                                "ON CONFLICT (from_type, from_id, relation, to_type, to_id) "
                                "WHERE valid_to IS NULL DO NOTHING",
                                (
                                    "DeployOutcome", outcome_id, "PRODUCED_BY",
                                    "OrchestrationRun", run_id, "varitykit",
                                ),
                            )
                finally:
                    conn.close()
            except Exception:
                pass  # Never fail the deploy over WM write errors

        threading.Thread(target=_write, daemon=True).start()

    @staticmethod
    def _emit_telemetry(telem: Dict) -> None:
        """POST deploy telemetry to the gateway. Never raises.

        Routes to the SAME gateway base varitykit registers domains with
        (VARITY_GATEWAY_URL). When the gateway shells varitykit this is
        http://localhost:8080 — an in-container loopback that actually works.
        POSTing to the public https://varity.app from inside the gateway's own
        Akash container hairpins and silently fails, which dropped 100% of
        portal-deploy telemetry. Standalone CLI/MCP have no override → public URL.
        """
        import json as _json
        import os as _os
        import urllib.request as _req

        _base = (_os.getenv("VARITY_GATEWAY_URL", "https://varity.app") or "https://varity.app").rstrip("/")
        _url = f"{_base}/api/telemetry/deploy"

        def _post() -> None:
            try:
                # source attribution for the ML pipeline. The gateway shells
                # varitykit for portal deploys and sets VARITY_DEPLOY_SOURCE=portal;
                # CLI + MCP leave it unset → "cli".
                _source = telem.get("source") or _os.getenv("VARITY_DEPLOY_SOURCE", "cli")
                _outcome_keys = {
                    "success", "duration_seconds", "deploy_id", "frontend_url",
                    "error_class", "error_message", "error_type", "failure_stage",
                }
                payload = {
                    "run_id": telem.get("run_id"),
                    "source": _source,
                    "orchestration_run": {k: v for k, v in telem.items() if k not in _outcome_keys and k != "source"},
                    "deploy_outcome": {k: telem[k] for k in _outcome_keys if k in telem},
                }
                data = _json.dumps(payload).encode()
                request = _req.Request(
                    _url,
                    data=data,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                _req.urlopen(request, timeout=5)
            except Exception:
                pass  # Telemetry is best-effort — never fail the deploy

        # Bounded join: telemetry is the LAST step and on failure the process
        # exits immediately after — a pure daemon thread would be killed
        # mid-POST and the row would never persist. Wait up to 6s (the POST is
        # sub-second to the loopback), then move on regardless so telemetry can
        # never delay or break a deploy.
        _t = threading.Thread(target=_post, daemon=True)
        _t.start()
        _t.join(timeout=6)

    @staticmethod
    def _run_learned_recommender(telem: Dict) -> None:
        """Run the learned recommender in a background thread (silent A/B).

        Produces a RecommenderProposal entity in the World Model for
        offline comparison against the rules-engine decision. Never
        affects the actual deployment path.
        """
        def _recommend() -> None:
            try:
                from .learned_recommender import LearnedRecommender
                rec = LearnedRecommender()
                result = rec.recommend(telem)
                rec.write_proposal(telem, result)
            except Exception:
                pass  # Never fail the deploy over recommender errors

        threading.Thread(target=_recommend, daemon=True).start()

    def _deploy_to_akash_service(
        self,
        project_path: str,
        project_info: ProjectInfo,
        custom_name: Optional[str] = None,
        github_repo_url: Optional[str] = None,
    ):
        """
        Deploy to Akash via Console API using git clone pattern.

        No Docker required. Generates SDL that clones the GitHub repo
        at runtime on the Akash provider.

        Args:
            project_path: Path to project directory
            project_info: Detected project information
            custom_name: Custom app name override
            github_repo_url: GitHub repo URL for the app code

        Returns:
            AkashDeploymentResult with deployment URL

        Raises:
            DeploymentError: If deployment fails
        """
        from varitykit.services.akash_deploy_service import (
            deploy,
            detect_app_port,
            detect_python_start_command,
        )

        try:
            app_name = custom_name or project_info.name
            port = detect_app_port(project_path, project_info.project_type)

            # Detect what services the app needs (postgres/redis/ollama/mongodb)
            services = self._detect_services(project_path)

            # GitHub URL is required for Akash deployment
            if not github_repo_url:
                raise DeploymentError(
                    "A GitHub repository is required for dynamic hosting. "
                    "Push your code to GitHub first."
                )

            # For Python projects, detect the right start command (Procfile,
            # Django manage.py, FastAPI/Flask conventions). None = caller uses
            # its uvicorn default.
            python_start = detect_python_start_command(project_path)

            # Load user env vars from .env.varity / .env.local / .env.
            # Reserved + platform-leakage keys (VERCEL_*, AWS_*, DATABASE_URL,
            # etc.) are filtered so they don't collide with Varity-managed
            # wiring or carry Vercel-isms into the Akash deployment.
            user_env = self._load_env_vars(project_path)

            # deploy() never raises — it returns an AkashDeploymentResult with
            # success=False (and a failure_stage) on failure. Return it as-is so
            # the orchestrator can record the bid set + failing stage in
            # telemetry before raising. (Previously this raised on failure,
            # which discarded the provider bids + failure_stage on failed
            # dynamic deploys — the #1 RL signal.)
            return deploy(
                github_repo_url=github_repo_url,
                app_name=app_name,
                project_type=project_info.project_type,
                services=services,
                port=port,
                python_start_command=python_start,
                env_vars=user_env,
                package_manager=project_info.package_manager or "npm",
            )

        except DeploymentError:
            raise
        except Exception as e:
            raise DeploymentError(f"Deployment failed: {e}")

    # Legacy _deploy_to_akash() removed — all Akash deployments use
    # _deploy_to_akash_service() which calls the Console API directly.
