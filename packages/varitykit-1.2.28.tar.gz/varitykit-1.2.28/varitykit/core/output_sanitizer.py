"""
Defensive blockchain/DePIN jargon redaction.

Varity has a zero-tolerance rule (CLAUDE.md Beta-Period Rule #1): non-technical
users must never see Akash addresses, `dseq`, provider ingress hostnames,
AKT/uakt/uact denominations, etc.

Every user-facing string is point-fixed at its source. This module is the
*backstop*: it is wired into the two user-output chokepoints so that if a
future change re-introduces a leak, the offending token is redacted to `…`
instead of reaching the user. It must NEVER fire in normal operation.

It only redacts (replaces the token with `…`) — it never rewrites surrounding
text, so it cannot corrupt an otherwise-correct line. HTTP status codes are
intentionally NOT matched here (too collision-prone — handled by point-fixes).
"""

import re

# Akash addresses, dseq (+ optional =/: value), provider ingress hostnames,
# *.provider.akash.network, and AKT/uakt/uact denominations.
_JARGON = re.compile(
    r"akash1[0-9a-z]{6,}"
    r"|\bdseq\b(?:\s*[=:]\s*\d+)?"
    r"|[A-Za-z0-9-]+\.ingress\.[A-Za-z0-9.-]+"
    r"|[A-Za-z0-9-]+\.provider\.akash\.network"
    r"|\b\d[\d.,]*\s*u(?:akt|act)\b"
    r"|\bu(?:akt|act)\b"
    r"|\bAKT\b",
    re.IGNORECASE,
)


def redact_jargon(text: str) -> str:
    """Replace any residual blockchain/DePIN token with `…`. No-op if clean."""
    if not text:
        return text
    return _JARGON.sub("…", text)
