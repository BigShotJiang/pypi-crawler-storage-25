"""
Akash Console API Client

Deploys applications to Akash Network using the Console Managed Wallet API.
No local CLI, wallet, or AKT tokens required.

API: https://console-api.akash.network/v1
Auth: x-api-key header
"""

from __future__ import annotations

import json
import os
import time
import urllib.request
import urllib.error
from typing import Any, Dict, Optional

from .types import AkashError


BASE_URL = "https://console-api.akash.network/v1"
BID_POLL_INTERVAL = 3  # seconds (per official docs)
BID_MAX_ATTEMPTS = 10


class AkashConsoleDeployer:
    """Akash Console Managed Wallet API client."""

    def __init__(self, api_key: Optional[str] = None, on_progress=None):
        if api_key:
            self.api_key = api_key
        else:
            try:
                from varitykit.services.credential_fetcher import fetch_akash_credentials
                self.api_key = fetch_akash_credentials()
            except ImportError:
                self.api_key = os.getenv("AKASH_CONSOLE_API_KEY")

        if not self.api_key:
            raise AkashError(
                "Dynamic hosting credentials not found. "
                "Run 'varitykit login' to authenticate."
            )
        # Optional user-facing progress sink. Default = silent (NOT print) so
        # this low-level client never leaks raw infra detail on its own.
        self._on_progress = on_progress

    def _emit(self, message: str) -> None:
        """Emit a user-facing progress line (jargon-redacted) if a sink is set."""
        if self._on_progress:
            from varitykit.core.output_sanitizer import redact_jargon
            self._on_progress(redact_jargon(message))

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def deploy(self, sdl: str, deposit: int = 5, primary_service: Optional[str] = None) -> Dict[str, Any]:
        """
        Create deployment, wait for bids, select cheapest, create lease.

        `primary_service` (when known, e.g. from agent template metadata) makes
        URL extraction deterministic for multi-service / multi-port templates
        by selecting that service's ingress instead of "first service found".

        Returns dict with keys: dseq, provider, url
        """
        # 1. Create deployment (submit the SDL)
        try:
            resp = self._post("/deployments", {"data": {"sdl": sdl, "deposit": deposit}})
        except AkashError as e:
            e.failure_stage = e.failure_stage or "sdl_submission"
            raise
        data = resp.get("data", resp)
        dseq = data.get("dseq")
        manifest = data.get("manifest")
        if not dseq:
            raise AkashError(f"No deployment ID returned: {resp}", failure_stage="sdl_submission")

        # 2. Wait for bids (collects ≥3 bids or ≥12s, not just the first
        #    poll cycle — fixes Bug 2 where europlots always won because it
        #    was the fastest bidder).
        bids = self.wait_for_bids(dseq)
        if not bids:
            raise AkashError("No provider bids received", failure_stage="bid_collection")

        # 3. Select cheapest bid across all collected providers
        best = min(bids, key=lambda b: float(b["bid"]["price"].get("amount", "0")))

        # Include the provider bids in the deploy result for telemetry.
        bid_summary = [
            {"provider": b["bid"]["id"]["provider"], "price": float(b["bid"]["price"].get("amount", "0"))}
            for b in bids
        ]

        self._emit("   Selecting the best infrastructure for your app…")

        # 4. Create lease (accept the winning bid)
        try:
            lease_resp = self.create_lease(dseq, manifest, best)
        except AkashError as e:
            e.failure_stage = e.failure_stage or "lease_acceptance"
            raise

        # 5. Wait for URL (provider needs time to start the container)
        url = self._extract_url(lease_resp, primary_service)
        if not url:
            for _ in range(10):
                time.sleep(3)
                status_resp = self.get_status(str(dseq))
                url = self._extract_url(status_resp, primary_service)
                if url:
                    break

        return {
            "dseq": str(dseq),
            "provider": best["bid"]["id"]["provider"],
            "url": url or "",
            "provider_bids": bid_summary,
            "selected_price": float(best["bid"]["price"].get("amount", "0")),
            "bid_count": len(bids),
        }

    def wait_for_bids(self, dseq: str) -> list:
        """
        Poll GET /v1/bids?dseq=X collecting bids across multiple cycles, not
        just the first non-empty batch.

        The old behavior was: poll → if any bids exist → return them
        immediately. That meant the caller's "pick cheapest" only ever saw
        bids from the first poll cycle, biasing toward whichever provider's
        bid landed fastest (empirically: europlots in Europe). Real bid
        markets have providers responding over 6-15 seconds; cutting off at
        3 seconds throws away most of the price-discovery window.

        New behavior:
          - Keep polling until any of: ≥3 distinct bids collected,
            ≥12 seconds total elapsed, or BID_MAX_ATTEMPTS reached.
          - Deduplicate by provider (a provider that posts twice in
            different poll cycles counts once).
          - Return the full collected set so the caller can select cheapest
            across the whole window.

        Returns list of raw bid objects from the API.
        """
        BID_COLLECT_TARGET = 3
        BID_COLLECT_MIN_SECONDS = 12

        collected_by_provider: dict = {}
        start = time.monotonic()
        attempts = 0

        while attempts < BID_MAX_ATTEMPTS:
            attempts += 1
            try:
                resp = self._get("/bids", params={"dseq": dseq})
                bids = resp.get("data", []) or []
            except Exception:
                bids = []

            for bid_entry in bids:
                provider = (
                    bid_entry.get("bid", {}).get("id", {}).get("provider")
                )
                if provider and provider not in collected_by_provider:
                    collected_by_provider[provider] = bid_entry

            elapsed = time.monotonic() - start
            have_enough = len(collected_by_provider) >= BID_COLLECT_TARGET
            window_elapsed = elapsed >= BID_COLLECT_MIN_SECONDS

            if collected_by_provider and (have_enough or window_elapsed):
                break

            time.sleep(BID_POLL_INTERVAL)

        return list(collected_by_provider.values())

    def create_lease(self, dseq: str, manifest: str, provider_bid: dict) -> Dict[str, Any]:
        """
        Accept a bid and create a lease.

        Args:
            dseq: Deployment sequence number
            manifest: Manifest string from deployment creation
            provider_bid: Raw bid object from wait_for_bids
        """
        bid_id = provider_bid.get("bid", {}).get("id", {})
        return self._post("/leases", {
            "manifest": manifest,
            "leases": [{
                "dseq": dseq,
                "gseq": bid_id.get("gseq", 1),
                "oseq": bid_id.get("oseq", 1),
                "provider": bid_id.get("provider", ""),
            }],
        })

    def get_status(self, dseq: str) -> Dict[str, Any]:
        """GET /v1/deployments/{dseq}"""
        return self._get(f"/deployments/{dseq}")

    def close(self, dseq: str) -> None:
        """DELETE /v1/deployments/{dseq}"""
        self._request("DELETE", f"/deployments/{dseq}")

    # ------------------------------------------------------------------
    # HTTP helpers (stdlib only)
    # ------------------------------------------------------------------

    def _get(self, path: str, params: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        if params:
            qs = "&".join(f"{k}={v}" for k, v in params.items())
            path = f"{path}?{qs}"
        return self._request("GET", path)

    def _post(self, path: str, body: dict) -> Dict[str, Any]:
        return self._request("POST", path, body)

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> Dict[str, Any]:
        url = f"{BASE_URL}{path}"
        data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(
            url,
            data=data,
            method=method,
            headers={
                "Content-Type": "application/json",
                "x-api-key": self.api_key or "",
                "User-Agent": "Varity/1.0",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                raw = resp.read().decode()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = json.loads(e.read().decode()).get("message", str(e))
            except Exception:
                detail = str(e)
            raise AkashError(f"API error ({e.code}): {detail}")
        except urllib.error.URLError as e:
            raise AkashError(f"Request failed: {e.reason}")

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_url(response: Dict[str, Any], primary_service: Optional[str] = None) -> Optional[str]:
        """
        Extract the public ingress URL from a lease/status response.

        When `primary_service` is given, that service's ingress is preferred
        (deterministic for multi-service / multi-port templates). Otherwise
        falls back to the first service that has a URI.
        """
        def _pick(services: Dict[str, Any]) -> Optional[str]:
            if not isinstance(services, dict):
                return None
            # Prefer the declared primary service's ingress.
            if primary_service:
                svc = services.get(primary_service)
                if isinstance(svc, dict):
                    uris = svc.get("uris", []) or []
                    if uris:
                        return uris[0]
            # Fallback: first service that exposes a URI.
            for svc in services.values():
                if isinstance(svc, dict):
                    uris = svc.get("uris", []) or []
                    if uris:
                        return uris[0]
            return None

        data = response.get("data", response)

        leases = data.get("leases", [])
        if leases:
            url = _pick(leases[0].get("status", {}).get("services", {}))
            if url:
                return url

        return _pick(data.get("services", {}))
