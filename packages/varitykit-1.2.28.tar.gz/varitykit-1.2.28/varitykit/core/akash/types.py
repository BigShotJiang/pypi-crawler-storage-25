"""Akash deployment types."""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


class AkashError(Exception):
    """Akash deployment error.

    Carries an optional ``failure_stage`` so the orchestrator can record which
    deploy stage broke (sdl_submission / bid_collection / lease_acceptance)
    without string-matching the message.
    """

    def __init__(self, message: str = "", failure_stage: Optional[str] = None):
        super().__init__(message)
        self.failure_stage = failure_stage


@dataclass
class AkashDeploymentResult:
    """Result from an Akash deployment."""
    success: bool
    dseq: str = ""
    url: str = ""
    provider: str = ""
    estimated_monthly_cost: float = 0.0
    error_message: str = ""
    # Provider bids recorded with the deploy result for telemetry.
    provider_bids: List[Dict[str, Any]] = field(default_factory=list)
    selected_price: float = 0.0
    bid_count: int = 0
    # Hardware actually reserved for the app service (the orchestration
    # decision) — captured so telemetry mirrors what was provisioned.
    cpu: float = 0.0
    memory_mb: int = 0
    storage_mb: int = 0
    # Which deploy stage failed (only set when success is False):
    # sdl_submission / bid_collection / lease_acceptance / container_health.
    failure_stage: str = ""
