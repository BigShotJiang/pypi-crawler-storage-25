"""
Agent template helpers: env-value collection + SDL rendering.

These functions are used by `DeploymentOrchestrator.deploy_agent()` to take a
vendored awesome-akash-derived SDL template + the user's env-var responses
and produce the final SDL ready to submit to the Akash Console API.

The `deploy_agent()` entry point that used to live in this module was removed
in 1.2.21 — agent deploys now route through the standard
`DeploymentOrchestrator.deploy_agent()` so they get the same pipeline (subdomain
check, register_akash_domain, history save, wait-for-URL-ready, telemetry) as
every other Varity deploy.
"""

from __future__ import annotations

import os
import re
from typing import Any, Dict, List

import click
import yaml


def _looks_like_placeholder(value: str) -> bool:
    """Heuristic: detect env values that are clearly meant to be replaced.

    The vendored awesome-akash SDLs use placeholders like `xxxxxxxxxxx`
    or `CHANGE_ME_TO_STRONG_PASSWORD` for fields the operator must set.
    We treat any value that matches one of these patterns as "must be
    overridden by the user" — distinct from a missing required key.
    """
    if not value:
        return True
    if re.fullmatch(r"x{4,}", value, re.IGNORECASE):
        return True
    if value.upper().startswith("CHANGE_ME"):
        return True
    return False


def collect_env_values(
    agent_name: str,
    sdl_yaml: str,
    metadata: Dict[str, Any],
    cli_env_overrides: Dict[str, str],
    non_interactive: bool = False,
) -> Dict[str, str]:
    """Determine the final env value for every key in the agent's SDL.

    Resolution order, highest priority first:
      1. CLI --env KEY=VALUE flags
      2. The process environment (so CI / MCP can pre-set values)
      3. Interactive prompt (only when stdin is a TTY and non_interactive=False)
      4. The default from the vendored SDL (kept as-is)

    Returns a mapping of {KEY: VALUE} that the caller should substitute
    back into the SDL's env block. Raises click.ClickException if a
    required key is missing under non-interactive mode.
    """
    sdl = yaml.safe_load(sdl_yaml)
    services = sdl.get("services", {})
    primary_name = metadata.get("primary_service") or next(iter(services))
    primary_svc = services.get(primary_name, {})
    env_list: List[str] = primary_svc.get("env", []) or []

    result: Dict[str, str] = {}
    required_set = set(metadata.get("required_env", []))

    for entry in env_list:
        if not isinstance(entry, str) or "=" not in entry:
            continue
        key, _, default = entry.partition("=")
        key = key.strip()
        # 1. CLI override
        if key in cli_env_overrides:
            result[key] = cli_env_overrides[key]
            continue
        # 2. Process env
        env_value = os.environ.get(key)
        if env_value is not None:
            result[key] = env_value
            continue
        # 3. Required + interactive prompt
        is_required = key in required_set or _looks_like_placeholder(default)
        if is_required:
            if non_interactive:
                raise click.ClickException(
                    f"Required env var {key!r} for agent {agent_name!r} not provided. "
                    f"Pass it via --env {key}=<value> or set ${key} in the environment."
                )
            try:
                response = click.prompt(
                    f"  {key}",
                    default="" if not default else None,
                    hide_input=key.upper().endswith(("KEY", "PASSWORD", "SECRET", "TOKEN", "PUBKEY")),
                    show_default=False,
                )
            except click.Abort:
                raise click.ClickException("Aborted by user.")
            if not response and default and not _looks_like_placeholder(default):
                result[key] = default
            else:
                result[key] = response
            continue
        # 4. Keep default
        result[key] = default

    return result


def render_sdl_with_env(sdl_yaml: str, env_overrides: Dict[str, str], primary_service: str) -> str:
    """Substitute user-supplied env values back into the SDL.

    Preserves the rest of the SDL byte-for-byte (resources, placement,
    pricing, ports, deployment block). Only the env list on the primary
    service is rewritten.
    """
    sdl = yaml.safe_load(sdl_yaml)
    svc = sdl["services"][primary_service]
    new_env: List[str] = []
    seen: set = set()
    for entry in svc.get("env", []) or []:
        if isinstance(entry, str) and "=" in entry:
            key = entry.split("=", 1)[0].strip()
            if key in env_overrides:
                new_env.append(f"{key}={env_overrides[key]}")
                seen.add(key)
                continue
        new_env.append(entry)
    # Any overrides that weren't already in the SDL (unlikely but
    # defensive): append them so they still reach the container.
    for key, value in env_overrides.items():
        if key not in seen:
            new_env.append(f"{key}={value}")
    svc["env"] = new_env
    return yaml.safe_dump(sdl, default_flow_style=False, sort_keys=False)
