# ROS2 rclpy native node — sensor subscriptions, camera auto-detection, cmd_vel
import os
import time
import threading

from .config import log, _ros2_cache, _ros2_lock
from .sensors_config import get_sensor_config
import ai_teammate_ros2_bridge.config as _cfg

# Track ROS2 spin thread state for restart
_ros2_thread: threading.Thread | None = None
_ros2_restart_lock = threading.Lock()


def _ros2_spin_thread():
    """Background thread: spin rclpy node for subscriptions."""
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import Twist
    from sensor_msgs.msg import Imu, LaserScan, CameraInfo, Image as RosImage
    from nav_msgs.msg import Odometry
    import cv2
    import numpy as np

    rclpy.init()
    node = Node("ai_teammate_bridge")
    _cfg._ros2_node = node

    sc = get_sensor_config()

    # ── Discover topics once for auto-resolve ──
    time.sleep(2)
    try:
        discovered = node.get_topic_names_and_types()
        by_type: dict[str, list[str]] = {}
        for name, types in discovered:
            for t in types:
                by_type.setdefault(t, []).append(name)
        sc.set_detected_topics(by_type)
    except Exception as e:
        log.warning(f"Topic discovery failed: {e}")

    # Publisher
    cmd_vel_topic = sc.topic("cmd_vel") or "/cmd_vel"
    _cfg._cmd_vel_pub = node.create_publisher(Twist, cmd_vel_topic, 10)
    log.info(f"cmd_vel publisher created: {cmd_vel_topic}")

    # Subscribers
    def on_imu(msg):
        with _ros2_lock:
            import math
            q = msg.orientation
            siny = 2.0 * (q.w * q.z + q.x * q.y)
            cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
            yaw = math.atan2(siny, cosy)
            sinr = 2.0 * (q.w * q.x + q.y * q.z)
            cosr = 1.0 - 2.0 * (q.x * q.x + q.y * q.y)
            roll = math.atan2(sinr, cosr)
            sinp = 2.0 * (q.w * q.y - q.z * q.x)
            pitch = math.asin(max(-1.0, min(1.0, sinp)))
            _ros2_cache["imu_ts"] = time.time()
            _ros2_cache["imu"] = {
                "roll": roll,
                "pitch": pitch,
                "yaw": yaw,
                "accel_x": msg.linear_acceleration.x,
                "accel_y": msg.linear_acceleration.y,
                "accel_z": msg.linear_acceleration.z,
            }

    def on_odom(msg):
        with _ros2_lock:
            _ros2_cache["odom_ts"] = time.time()
            import math
            q = msg.pose.pose.orientation
            siny = 2.0 * (q.w * q.z + q.x * q.y)
            cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
            yaw = math.atan2(siny, cosy)
            _ros2_cache["odometry"] = {
                "x": msg.pose.pose.position.x,
                "y": msg.pose.pose.position.y,
                "theta": yaw,
                "linear_vel": msg.twist.twist.linear.x,
                "angular_vel": msg.twist.twist.angular.z,
            }

    def on_scan(msg):
        import math as _math
        with _ros2_lock:
            _ros2_cache["scan_ts"] = time.time()
            ranges = list(msg.ranges)
            valid = [r for r in ranges if msg.range_min < r < msg.range_max]
            n = len(ranges)
            if n > 0:
                angle_inc = (msg.angle_max - msg.angle_min) / n
                front_indices = [i for i in range(n) if abs(msg.angle_min + i * angle_inc) < 0.52]
                front_ranges = [ranges[i] for i in front_indices if msg.range_min < ranges[i] < msg.range_max]
                front_min = round(min(front_ranges), 3) if front_ranges else None
            else:
                front_min = None
                angle_inc = 0

            # Downsample scan to ~60 points for WS relay (every 10th ray)
            scan_points = []
            step = max(1, n // 60)
            for i in range(0, n, step):
                r = ranges[i]
                if msg.range_min < r < msg.range_max:
                    angle = msg.angle_min + i * angle_inc
                    scan_points.append([
                        round(r * _math.cos(angle), 3),
                        round(r * _math.sin(angle), 3),
                    ])

            _ros2_cache["scan"] = {
                "range_min": msg.range_min,
                "range_max": msg.range_max,
                "angle_min": msg.angle_min,
                "angle_max": msg.angle_max,
                "num_ranges": n,
                "min_distance": round(min(valid), 3) if valid else None,
                "mean_distance": round(sum(valid) / len(valid), 3) if valid else None,
                "front_min_distance": front_min,
            }
            _ros2_cache["scan_points"] = scan_points

    def on_camera_info(msg):
        with _ros2_lock:
            _ros2_cache["camera"] = {
                "width": msg.width,
                "height": msg.height,
                "distortion_model": msg.distortion_model,
                "frame_id": msg.header.frame_id,
                "available": True,
            }

    def on_image(msg):
        """Cache latest camera frame as compressed JPEG bytes."""
        try:
            if msg.encoding == 'rgb8':
                img = np.frombuffer(msg.data, dtype=np.uint8).reshape(msg.height, msg.width, 3)
                img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            elif msg.encoding == 'bgr8':
                img = np.frombuffer(msg.data, dtype=np.uint8).reshape(msg.height, msg.width, 3)
            elif msg.encoding in ('16UC1', '32FC1'):
                return
            else:
                img = np.frombuffer(msg.data, dtype=np.uint8).reshape(msg.height, msg.width, -1)

            _, jpeg = cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, 60])
            with _ros2_lock:
                _ros2_cache["camera_frame"] = jpeg.tobytes()
                _ros2_cache["camera_frame_ts"] = time.time()
        except Exception as e:
            log.debug(f"Image conversion error: {e}")

    # ── Camera auto-detection ──
    CAMERA_INFO_TOPIC = os.environ.get("CAMERA_INFO_TOPIC", "")
    CAMERA_IMAGE_TOPIC = os.environ.get("CAMERA_IMAGE_TOPIC", "")

    if not CAMERA_IMAGE_TOPIC:
        log.info("Auto-detecting camera topics...")
        try:
            time.sleep(2)
            topic_list = node.get_topic_names_and_types()
            image_topics = [
                name for name, types in topic_list
                if any("sensor_msgs/msg/Image" in t for t in types)
            ]
            info_topics = [
                name for name, types in topic_list
                if any("sensor_msgs/msg/CameraInfo" in t for t in types)
            ]
            if image_topics:
                CAMERA_IMAGE_TOPIC = next(
                    (t for t in image_topics if "color" in t and "depth" not in t),
                    image_topics[0]
                )
                CAMERA_INFO_TOPIC = next(
                    (t for t in info_topics if "color" in t),
                    info_topics[0] if info_topics else ""
                )
                log.info(f"Camera auto-detected: image={CAMERA_IMAGE_TOPIC}, info={CAMERA_INFO_TOPIC}")
                log.info(f"All image topics: {image_topics}")
            else:
                log.info("No camera topics found — camera disabled")
        except Exception as e:
            log.warning(f"Camera auto-detection failed: {e}")

    if not CAMERA_IMAGE_TOPIC:
        CAMERA_IMAGE_TOPIC = "/camera/camera/color/image_raw"
        CAMERA_INFO_TOPIC = "/camera/camera/color/camera_info"
        log.info(f"Using default camera topics: {CAMERA_IMAGE_TOPIC}")

    imu_topic = sc.topic("imu") or "/imu/data"
    odom_topic = sc.topic("odom") or "/odom"
    scan_topic = sc.topic("scan") or "/scan"
    cam_info_topic = sc.topic("camera_info") or CAMERA_INFO_TOPIC
    cam_image_topic = sc.topic("camera_image") or CAMERA_IMAGE_TOPIC

    if sc.enabled("imu"):
        node.create_subscription(Imu, imu_topic, on_imu, sc.qos("imu"))
    if sc.enabled("odom"):
        node.create_subscription(Odometry, odom_topic, on_odom, sc.qos("odom"))
    if sc.enabled("scan"):
        node.create_subscription(LaserScan, scan_topic, on_scan, sc.qos("scan"))
    if sc.enabled("camera_info") and cam_info_topic:
        node.create_subscription(CameraInfo, cam_info_topic, on_camera_info, sc.qos("camera_info"))
    if sc.enabled("camera_image") and cam_image_topic:
        node.create_subscription(RosImage, cam_image_topic, on_image, sc.qos("camera_image"))

    # Robot feedback (Former robot: battery voltage, temperature, estop button)
    FEEDBACK_TOPIC = os.environ.get("FEEDBACK_TOPIC", "/former_io_controller/robot_feedback")
    try:
        from former_interfaces.msg import RobotFeedback

        def on_robot_feedback(msg):
            with _ros2_lock:
                _ros2_cache["robot_feedback"] = {
                    "system_voltage": msg.system_voltage,
                    "charging_voltage": msg.charging_voltage,
                    "current_temperature": msg.current_temperature,
                    "estop_button": msg.estop_button,
                    "motor_enabled": msg.motor_enabled,
                    "fault_flag": msg.fault_flag,
                }

        node.create_subscription(RobotFeedback, FEEDBACK_TOPIC, on_robot_feedback, 10)
        log.info(f"Robot feedback subscribed: {FEEDBACK_TOPIC}")
    except ImportError:
        log.info("former_interfaces not available — robot feedback disabled")

    # ── SLAM map subscription (OccupancyGrid) ──
    MAP_TOPIC = os.environ.get("MAP_TOPIC", "/map")
    try:
        from nav_msgs.msg import OccupancyGrid as OccGrid

        _map_throttle_ts = [0.0]  # last update timestamp

        _MAP_MAX_CELLS = int(os.environ.get("MAP_MAX_CELLS", "10000"))  # ~100x100

        def on_map(msg):
            now = time.time()
            if now - _map_throttle_ts[0] < 2.0:
                return  # throttle: max once per 2 seconds
            _map_throttle_ts[0] = now

            w, h = msg.info.width, msg.info.height
            res = msg.info.resolution
            ox = msg.info.origin.position.x
            oy = msg.info.origin.position.y

            # Downsample if exceeds max cells
            total = w * h
            if total > _MAP_MAX_CELLS:
                step = max(2, int((total / _MAP_MAX_CELLS) ** 0.5))
                dw = w // step
                dh = h // step
                raw = msg.data
                ddata = []
                for dy in range(dh):
                    row = dy * step * w
                    for dx in range(dw):
                        ddata.append(raw[row + dx * step])
                map_data = ddata
                map_w, map_h, map_res = dw, dh, res * step
            else:
                map_data = list(msg.data)
                map_w, map_h, map_res = w, h, res

            with _ros2_lock:
                _ros2_cache["slam_map"] = {
                    "width": map_w,
                    "height": map_h,
                    "resolution": map_res,
                    "origin": {"x": ox, "y": oy, "theta": 0.0},
                    "data": map_data,
                }
                _ros2_cache["slam_map_ts"] = now

        from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
        map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        node.create_subscription(OccGrid, MAP_TOPIC, on_map, map_qos)
        log.info(f"SLAM map subscribed: {MAP_TOPIC} (TRANSIENT_LOCAL)")
    except Exception as e:
        log.info(f"SLAM map subscription skipped: {e}")

    # ── TF listener for map-frame pose ──
    try:
        from tf2_ros import Buffer, TransformListener
        import math as _math
        _tf_buffer = Buffer()
        _tf_listener = TransformListener(_tf_buffer, node)

        def _update_map_pose():
            """Lookup map→base_footprint and cache as slam_pose."""
            try:
                t = _tf_buffer.lookup_transform("map", "base_footprint", rclpy.time.Time())
                p = t.transform.translation
                r = t.transform.rotation
                siny = 2.0 * (r.w * r.z + r.x * r.y)
                cosy = 1.0 - 2.0 * (r.y * r.y + r.z * r.z)
                yaw = _math.atan2(siny, cosy)
                with _ros2_lock:
                    _ros2_cache["slam_pose"] = {"x": p.x, "y": p.y, "theta": yaw}
                    _ros2_cache["slam_pose_ts"] = time.time()
            except Exception as tf_err:
                # Log once per 30s to avoid spam
                if not hasattr(_update_map_pose, '_last_err') or time.time() - _update_map_pose._last_err > 30:
                    log.debug(f"TF lookup map→base_footprint failed: {tf_err}")
                    _update_map_pose._last_err = time.time()

        # Timer: update map pose at 5 Hz
        node.create_timer(0.2, _update_map_pose)
        log.info("TF listener started for map→base_footprint pose")
    except Exception as e:
        log.info(f"TF listener skipped: {e}")

    log.info(f"Subscribed to {imu_topic}, {odom_topic}, {scan_topic}, {cam_info_topic}, {cam_image_topic}")

    try:
        rclpy.spin(node)
    except Exception as e:
        log.error(f"rclpy spin error: {e}")
    finally:
        try:
            node.destroy_node()
        except Exception:
            pass
        try:
            rclpy.shutdown()
        except Exception:
            pass
        log.warning("ROS2 node shut down")
        _cfg._ros2_node = None
        _cfg._cmd_vel_pub = None


def is_ros2_healthy() -> bool:
    """Check if rclpy context + node are alive.

    토픽 데이터 수신 여부는 건강 지표가 아님 — 센서 침묵(IMU 미장착 등)이 있어도
    노드는 정상. rclpy.ok() 와 노드 핸들 존재만으로 판단.
    """
    if _cfg._ros2_node is None or _cfg._cmd_vel_pub is None:
        return False
    try:
        import rclpy
        return rclpy.ok()
    except Exception:
        return False


_last_restart_ts: float = 0.0
_RESTART_COOLDOWN_SEC = 60.0  # 같은 기동 내 재시작 최소 간격


def restart_ros2_node():
    """Restart the ROS2 spin thread. Called when context becomes invalid."""
    global _ros2_thread, _last_restart_ts
    with _ros2_restart_lock:
        now = time.time()
        if now - _last_restart_ts < _RESTART_COOLDOWN_SEC:
            log.info(
                f"ROS2 restart skipped — cooldown ({int(now - _last_restart_ts)}s < {int(_RESTART_COOLDOWN_SEC)}s)"
            )
            return
        _last_restart_ts = now
        log.warning("Restarting ROS2 node...")

        # Shutdown existing
        if _cfg._ros2_node:
            try:
                _cfg._ros2_node.destroy_node()
            except Exception:
                pass
        try:
            import rclpy
            rclpy.shutdown()
        except Exception:
            pass

        _cfg._ros2_node = None
        _cfg._cmd_vel_pub = None
        with _ros2_lock:
            _ros2_cache.clear()

        # Start new thread
        _ros2_thread = threading.Thread(target=_ros2_spin_thread, daemon=True)
        _ros2_thread.start()
        log.info("ROS2 node restart initiated")
