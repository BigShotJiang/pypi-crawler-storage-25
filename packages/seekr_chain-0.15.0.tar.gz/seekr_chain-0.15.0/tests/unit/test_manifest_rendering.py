"""Tests for Jinja2 template rendering of Argo/JobSet manifests."""

import yaml

from seekr_chain.backends.argo import render
from seekr_chain.backends.argo.job_info import get_job_info
from seekr_chain.backends.argo.jobset import build_jobset_context
from seekr_chain.config import WorkflowConfig

DATASTORE_ROOT = "s3://test-bucket/seekr-chain/"


def _minimal_config(**kwargs) -> WorkflowConfig:
    defaults = {
        "name": "test-job",
        "steps": [
            {
                "name": "train",
                "image": "pytorch:2.0",
                "script": "echo hello",
                "resources": {
                    "cpus_per_node": "4",
                    "mem_per_node": "8Gi",
                    "ephemeral_storage_per_node": "10Gi",
                },
            }
        ],
    }
    defaults.update(kwargs)
    return WorkflowConfig(**defaults)


def _fake_job_info():
    return get_job_info("ab1234", datastore_root=DATASTORE_ROOT)


class TestJobsetTemplateRendering:
    def test_renders_valid_yaml(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        js_name, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        assert manifest is not None
        assert manifest["apiVersion"] == "jobset.x-k8s.io/v1alpha2"
        assert manifest["kind"] == "JobSet"

    def test_jobset_name(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        js_name, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        assert js_name == "ab1234-train-js"
        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)
        assert manifest["metadata"]["name"] == "ab1234-train-js"

    def test_single_replicated_job(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        jobs = manifest["spec"]["replicatedJobs"]
        assert len(jobs) == 1
        assert jobs[0]["replicas"] == 1

    def test_init_containers_present(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        pod_spec = manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]
        init_names = [c["name"] for c in pod_spec["initContainers"]]
        assert init_names == ["download-assets", "unpack-assets", "inject-shell"]

    def test_main_and_sidecar_containers(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        pod_spec = manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]
        container_names = [c["name"] for c in pod_spec["containers"]]
        assert "main" in container_names
        assert "log-sidecar" in container_names

    def test_env_vars_present(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[
                {"name": "MY_SECRET", "valueFrom": {"secretKeyRef": {"name": "ab1234", "key": "MY_SECRET"}}}
            ],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        pod_spec = manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]
        main_container = next(c for c in pod_spec["containers"] if c["name"] == "main")
        env_names = [e["name"] for e in main_container["env"]]

        assert "NODE_RANK" in env_names
        assert "NNODES" in env_names
        assert "MASTER_ADDR" in env_names
        assert "MY_SECRET" in env_names

    def test_cluster_secret_ref_points_at_cluster_secret(self, tmp_path):
        """SecretRefSource entries must reference the original secret, not the workflow secret."""
        config = _minimal_config()
        job_info = _fake_job_info()

        # Simulate what _create_workflow_secrets produces for a SecretRefSource entry
        cluster_secret_ref = {
            "name": "API_TOKEN",
            "valueFrom": {"secretKeyRef": {"name": "my-cluster-secret", "key": "token"}},
        }

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[cluster_secret_ref],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        pod_spec = manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]
        main_container = next(c for c in pod_spec["containers"] if c["name"] == "main")

        api_token_env = next(e for e in main_container["env"] if e["name"] == "API_TOKEN")
        secret_ref = api_token_env["valueFrom"]["secretKeyRef"]

        # Must point at the cluster secret, not the per-workflow secret
        assert secret_ref["name"] == "my-cluster-secret"
        assert secret_ref["key"] == "token"

    def test_no_success_policy_by_default(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        assert "successPolicy" not in manifest["spec"]

    def test_network_config(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        network = manifest["spec"]["network"]
        assert network["enableDNSHostnames"] is True
        assert network["subdomain"] == "ab1234-train-js"

    def test_shm_size_present(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        pod_spec = manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]
        shm_vol = next(v for v in pod_spec["volumes"] if v["name"] == "shm")
        # Default shm_size is not UNLIMITED, so sizeLimit should be present
        assert "sizeLimit" in shm_vol["emptyDir"]

    def test_interactive_uses_sleep_command(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=True,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        pod_spec = manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]
        main_container = next(c for c in pod_spec["containers"] if c["name"] == "main")
        assert "sleep" in main_container["args"][0]

    def test_host_network_defaults_false(self, tmp_path):
        """host_network defaults to false — no port conflicts on shared nodes."""
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        pod_spec = manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]
        assert pod_spec["hostNetwork"] is False
        assert pod_spec["dnsPolicy"] == "ClusterFirst"

    def test_host_network_true_sets_dns_policy(self, tmp_path):
        """host_network: true must also switch dnsPolicy to ClusterFirstWithHostNet."""
        config = _minimal_config(
            steps=[
                {
                    "name": "train",
                    "image": "pytorch:2.0",
                    "script": "echo hello",
                    "resources": {
                        "cpus_per_node": "4",
                        "mem_per_node": "8Gi",
                        "ephemeral_storage_per_node": "10Gi",
                        "host_network": True,
                    },
                }
            ]
        )
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        pod_spec = manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]
        assert pod_spec["hostNetwork"] is True
        assert pod_spec["dnsPolicy"] == "ClusterFirstWithHostNet"

    def test_no_scheduling_labels_by_default(self, tmp_path):
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        labels = manifest["metadata"]["labels"]
        assert "kueue.x-k8s.io/queue-name" not in labels
        assert "kueue.x-k8s.io/priority-class" not in labels

    def test_scheduling_queue_label(self, tmp_path):
        config = _minimal_config(scheduling={"queue": "gpu-queue"})
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        labels = manifest["metadata"]["labels"]
        assert labels["kueue.x-k8s.io/queue-name"] == "gpu-queue"
        assert "kueue.x-k8s.io/priority-class" not in labels

    def test_scheduling_priority_label(self, tmp_path):
        config = _minimal_config(scheduling={"queue": "gpu-queue", "priority": "high"})
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        labels = manifest["metadata"]["labels"]
        assert labels["kueue.x-k8s.io/queue-name"] == "gpu-queue"
        assert labels["kueue.x-k8s.io/priority-class"] == "high"

    def test_privileged_bool_is_yaml_boolean(self, tmp_path):
        """Kubernetes rejects Python True/False — template must emit true/false."""
        config = _minimal_config()
        job_info = _fake_job_info()

        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )

        rendered = render.render("jobset.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        pod_spec = manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]
        main_container = next(c for c in pod_spec["containers"] if c["name"] == "main")
        privileged = main_container["securityContext"]["privileged"]
        # Must be a native Python bool (parsed from YAML true/false), not a string
        assert isinstance(privileged, bool)


class TestWorkflowTemplateRendering:
    def _build_workflow_context(self, jobset_yaml: str = "apiVersion: jobset.x-k8s.io/v1alpha2\nkind: JobSet\n"):
        return {
            "workflow_name": "ab1234",
            "job_id": "ab1234",
            "job_name": "test-job",
            "user": "testuser",
            "datastore_root": "s3://test-bucket/seekr-chain/",
            "ttl_seconds": 604800,
            "dag_tasks": [{"name": "train"}],
            "steps": [
                {
                    "name": "train",
                    "jobset_name": "ab1234-train-js",
                    "jobset_yaml": jobset_yaml,
                    "labels": {},
                }
            ],
        }

    def test_renders_valid_yaml(self):
        context = self._build_workflow_context()
        rendered = render.render("workflow.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        assert manifest is not None
        assert manifest["apiVersion"] == "argoproj.io/v1alpha1"
        assert manifest["kind"] == "Workflow"

    def test_workflow_name(self):
        context = self._build_workflow_context()
        rendered = render.render("workflow.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        assert manifest["metadata"]["name"] == "ab1234"

    def test_ttl_strategy(self):
        context = self._build_workflow_context()
        rendered = render.render("workflow.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        assert manifest["spec"]["ttlStrategy"]["secondsAfterCompletion"] == 604800

    def test_entrypoint(self):
        context = self._build_workflow_context()
        rendered = render.render("workflow.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        assert manifest["spec"]["entrypoint"] == "seekr-chain-main"

    def test_dag_tasks(self):
        context = self._build_workflow_context()
        rendered = render.render("workflow.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        templates = manifest["spec"]["templates"]
        main_template = next(t for t in templates if t["name"] == "seekr-chain-main")
        tasks = main_template["dag"]["tasks"]
        assert len(tasks) == 1
        assert tasks[0]["name"] == "train"

    def test_step_template_present(self):
        context = self._build_workflow_context()
        rendered = render.render("workflow.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        templates = manifest["spec"]["templates"]
        step_template = next(t for t in templates if t["name"] == "train")
        assert step_template["resource"]["action"] == "create"
        assert step_template["resource"]["successCondition"] == "status.terminalState == Completed"

    def test_jobset_yaml_embedded(self):
        """JobSet YAML must be parseable from within the manifest field."""
        context = self._build_workflow_context(
            jobset_yaml="apiVersion: jobset.x-k8s.io/v1alpha2\nkind: JobSet\nmetadata:\n  name: test\n"
        )
        rendered = render.render("workflow.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        templates = manifest["spec"]["templates"]
        step_template = next(t for t in templates if t["name"] == "train")
        embedded_yaml = step_template["resource"]["manifest"]

        # The embedded string must itself be parseable YAML
        embedded = yaml.safe_load(embedded_yaml)
        assert embedded["kind"] == "JobSet"

    def test_dag_task_with_dependencies(self):
        context = self._build_workflow_context()
        context["dag_tasks"] = [
            {"name": "step-a"},
            {"name": "step-b", "dependencies": ["step-a"]},
        ]
        context["steps"].append(
            {
                "name": "step-b",
                "jobset_name": "ab1234-step-b-js",
                "jobset_yaml": "apiVersion: jobset.x-k8s.io/v1alpha2\nkind: JobSet\n",
            }
        )
        rendered = render.render("workflow.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        templates = manifest["spec"]["templates"]
        main_template = next(t for t in templates if t["name"] == "seekr-chain-main")
        tasks = {t["name"]: t for t in main_template["dag"]["tasks"]}

        assert "dependencies" not in tasks["step-a"] or tasks["step-a"].get("dependencies") is None
        assert tasks["step-b"]["dependencies"] == ["step-a"]

    def test_labels_present(self):
        context = self._build_workflow_context()
        rendered = render.render("workflow.yaml.j2", context)
        manifest = yaml.safe_load(rendered)

        labels = manifest["metadata"]["labels"]
        assert labels["seekr-chain/job-id"] == "ab1234"
        assert labels["seekr-chain/job-name"] == "test-job"
        assert labels["seekr-chain/user"] == "testuser"


class TestAffinityRendering:
    def _render(self, affinity_rules: list, tmp_path):
        config = _minimal_config(affinity=affinity_rules)
        job_info = _fake_job_info()
        _, context = build_jobset_context(
            workflow_config=config,
            step_index=0,
            job_info=job_info,
            workflow_name="ab1234",
            workflow_secrets=[],
            interactive=False,
            assets_path=tmp_path / "assets",
        )
        rendered = render.render("jobset.yaml.j2", context)
        return yaml.safe_load(rendered)

    def _pod_template(self, manifest):
        return manifest["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]

    def _affinity(self, manifest):
        return self._pod_template(manifest)["spec"]["affinity"]

    # ── Node affinity ──────────────────────────────────────────────────────────

    def test_node_attract_renders_in_operator(self, tmp_path):
        manifest = self._render([{"type": "NODE", "direction": "ATTRACT", "hostnames": ["gpu-node-01"]}], tmp_path)
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {
                            "matchExpressions": [
                                {"key": "kubernetes.io/hostname", "operator": "In", "values": ["gpu-node-01"]}
                            ]
                        }
                    ]
                }
            }
        }

    def test_node_repel_hostnames_renders_not_in(self, tmp_path):
        manifest = self._render(
            [{"type": "NODE", "direction": "REPEL", "hostnames": ["bad-node", "flaky-node"]}], tmp_path
        )
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {
                            "matchExpressions": [
                                {"key": "kubernetes.io/hostname", "operator": "NotIn", "values": ["bad-node"]},
                                {"key": "kubernetes.io/hostname", "operator": "NotIn", "values": ["flaky-node"]},
                            ]
                        }
                    ]
                }
            }
        }

    def test_node_attract_labels_renders_in(self, tmp_path):
        manifest = self._render([{"type": "NODE", "direction": "ATTRACT", "labels": {"gpu-type": ["a100"]}}], tmp_path)
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {"matchExpressions": [{"key": "gpu-type", "operator": "In", "values": ["a100"]}]}
                    ]
                }
            }
        }

    def test_node_attract_labels_multiple_values(self, tmp_path):
        manifest = self._render(
            [{"type": "NODE", "direction": "ATTRACT", "labels": {"gpu-type": ["a100", "h100"]}}], tmp_path
        )
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {"matchExpressions": [{"key": "gpu-type", "operator": "In", "values": ["a100", "h100"]}]}
                    ]
                }
            }
        }

    def test_node_repel_labels_multiple_values(self, tmp_path):
        manifest = self._render(
            [{"type": "NODE", "direction": "REPEL", "labels": {"gpu-type": ["a100", "h100"]}}], tmp_path
        )
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {"matchExpressions": [{"key": "gpu-type", "operator": "NotIn", "values": ["a100", "h100"]}]}
                    ]
                }
            }
        }

    def test_node_repel_labels_renders_not_in(self, tmp_path):
        manifest = self._render([{"type": "NODE", "direction": "REPEL", "labels": {"reserved": ["true"]}}], tmp_path)
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {"matchExpressions": [{"key": "reserved", "operator": "NotIn", "values": ["true"]}]}
                    ]
                }
            }
        }

    def test_node_required_uses_required_block(self, tmp_path):
        manifest = self._render(
            [{"type": "NODE", "direction": "ATTRACT", "hostnames": ["n1"], "required": True}], tmp_path
        )
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {"matchExpressions": [{"key": "kubernetes.io/hostname", "operator": "In", "values": ["n1"]}]}
                    ]
                }
            }
        }

    def test_node_soft_uses_preferred_block(self, tmp_path):
        manifest = self._render(
            [{"type": "NODE", "direction": "ATTRACT", "hostnames": ["n1"], "required": False}], tmp_path
        )
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "preferredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "weight": 1,
                        "preference": {
                            "matchExpressions": [{"key": "kubernetes.io/hostname", "operator": "In", "values": ["n1"]}]
                        },
                    }
                ]
            }
        }

    def test_node_hostnames_and_labels_combined(self, tmp_path):
        manifest = self._render(
            [{"type": "NODE", "direction": "ATTRACT", "hostnames": ["n1"], "labels": {"zone": ["us-east-1a"]}}],
            tmp_path,
        )
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {
                            "matchExpressions": [
                                {"key": "kubernetes.io/hostname", "operator": "In", "values": ["n1"]},
                                {"key": "zone", "operator": "In", "values": ["us-east-1a"]},
                            ]
                        }
                    ]
                }
            }
        }

    # ── Pod affinity ───────────────────────────────────────────────────────────

    def test_pod_attract_soft_preferred(self, tmp_path):
        manifest = self._render([{"type": "POD", "direction": "ATTRACT", "group": "exp", "required": False}], tmp_path)
        assert self._affinity(manifest) == {
            "podAffinity": {
                "preferredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "weight": 100,
                        "podAffinityTerm": {
                            "labelSelector": {"matchLabels": {"seekr-chain/pg.exp": "true"}},
                            "topologyKey": "kubernetes.io/hostname",
                        },
                    }
                ]
            }
        }

    def test_pod_attract_hard_required(self, tmp_path):
        import warnings

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            manifest = self._render(
                [{"type": "POD", "direction": "ATTRACT", "group": "exp", "required": True}], tmp_path
            )
        assert self._affinity(manifest) == {
            "podAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "labelSelector": {"matchLabels": {"seekr-chain/pg.exp": "true"}},
                        "topologyKey": "kubernetes.io/hostname",
                    }
                ]
            }
        }

    def test_pod_repel_soft_preferred(self, tmp_path):
        manifest = self._render([{"type": "POD", "direction": "REPEL", "group": "exp", "required": False}], tmp_path)
        assert self._affinity(manifest) == {
            "podAntiAffinity": {
                "preferredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "weight": 100,
                        "podAffinityTerm": {
                            "labelSelector": {"matchLabels": {"seekr-chain/pg.exp": "true"}},
                            "topologyKey": "kubernetes.io/hostname",
                        },
                    }
                ]
            }
        }

    def test_pod_repel_hard_required(self, tmp_path):
        manifest = self._render([{"type": "POD", "direction": "REPEL", "group": "exp", "required": True}], tmp_path)
        assert self._affinity(manifest) == {
            "podAntiAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "labelSelector": {"matchLabels": {"seekr-chain/pg.exp": "true"}},
                        "topologyKey": "kubernetes.io/hostname",
                    }
                ]
            }
        }

    def test_pod_attract_emits_pg_label(self, tmp_path):
        manifest = self._render([{"type": "POD", "direction": "ATTRACT", "group": "my-exp"}], tmp_path)
        labels = self._pod_template(manifest)["metadata"]["labels"]
        assert labels["seekr-chain/pg.my-exp"] == "true"

    def test_pod_repel_emits_no_label(self, tmp_path):
        manifest = self._render([{"type": "POD", "direction": "REPEL", "group": "other"}], tmp_path)
        labels = self._pod_template(manifest)["metadata"]["labels"]
        assert not any(k.startswith("seekr-chain/pg.") for k in labels)

    def test_multiple_attract_groups_emit_multiple_labels(self, tmp_path):
        manifest = self._render(
            [
                {"type": "POD", "direction": "ATTRACT", "group": "group-a"},
                {"type": "POD", "direction": "ATTRACT", "group": "group-b"},
            ],
            tmp_path,
        )
        labels = self._pod_template(manifest)["metadata"]["labels"]
        assert labels["seekr-chain/pg.group-a"] == "true"
        assert labels["seekr-chain/pg.group-b"] == "true"

    def test_pod_affinity_selector_uses_pg_label_key(self, tmp_path):
        manifest = self._render([{"type": "POD", "direction": "ATTRACT", "group": "my-exp"}], tmp_path)
        assert self._affinity(manifest) == {
            "podAffinity": {
                "preferredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "weight": 100,
                        "podAffinityTerm": {
                            "labelSelector": {"matchLabels": {"seekr-chain/pg.my-exp": "true"}},
                            "topologyKey": "kubernetes.io/hostname",
                        },
                    }
                ]
            }
        }

    def test_attract_required_warns(self, tmp_path):
        import warnings

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            self._render([{"type": "POD", "direction": "ATTRACT", "group": "exp", "required": True}], tmp_path)
        assert any(issubclass(w.category, UserWarning) for w in caught)

    # ── Mixed / structural ─────────────────────────────────────────────────────

    def test_node_and_pod_rules_coexist(self, tmp_path):
        manifest = self._render(
            [
                {"type": "NODE", "direction": "ATTRACT", "hostnames": ["gpu-node-01"]},
                {"type": "POD", "direction": "ATTRACT", "group": "exp"},
            ],
            tmp_path,
        )
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {
                            "matchExpressions": [
                                {"key": "kubernetes.io/hostname", "operator": "In", "values": ["gpu-node-01"]}
                            ]
                        }
                    ]
                }
            },
            "podAffinity": {
                "preferredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "weight": 100,
                        "podAffinityTerm": {
                            "labelSelector": {"matchLabels": {"seekr-chain/pg.exp": "true"}},
                            "topologyKey": "kubernetes.io/hostname",
                        },
                    }
                ]
            },
        }

    def test_no_affinity_no_block(self, tmp_path):
        manifest = self._render([], tmp_path)
        pod_spec = self._pod_template(manifest)["spec"]
        assert "affinity" not in pod_spec

    def test_backward_compat_old_dict_coercion(self, tmp_path):
        # Old dict format should produce the same rendered YAML as the new list format
        old_format = self._render(
            {"nodes": {"include_hostnames": ["gpu-node-01"]}},  # type: ignore[arg-type]
            tmp_path,
        )
        new_format = self._render([{"type": "NODE", "direction": "ATTRACT", "hostnames": ["gpu-node-01"]}], tmp_path)
        old_aff = old_format["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]["affinity"]
        new_aff = new_format["spec"]["replicatedJobs"][0]["template"]["spec"]["template"]["spec"]["affinity"]
        assert old_aff == new_aff

    def test_all_rules_together_valid_yaml(self, tmp_path):
        import warnings

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            manifest = self._render(
                [
                    {"type": "NODE", "direction": "ATTRACT", "labels": {"gpu-type": ["a100"]}, "required": True},
                    {"type": "NODE", "direction": "REPEL", "hostnames": ["flaky-node"], "required": False},
                    {"type": "POD", "direction": "ATTRACT", "group": "exp-42", "required": False},
                    {"type": "POD", "direction": "REPEL", "group": "inference-prod", "required": True},
                ],
                tmp_path,
            )
        assert manifest["apiVersion"] == "jobset.x-k8s.io/v1alpha2"
        assert self._affinity(manifest) == {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {"matchExpressions": [{"key": "gpu-type", "operator": "In", "values": ["a100"]}]}
                    ]
                },
                "preferredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "weight": 1,
                        "preference": {
                            "matchExpressions": [
                                {"key": "kubernetes.io/hostname", "operator": "NotIn", "values": ["flaky-node"]}
                            ]
                        },
                    }
                ],
            },
            "podAffinity": {
                "preferredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "weight": 100,
                        "podAffinityTerm": {
                            "labelSelector": {"matchLabels": {"seekr-chain/pg.exp-42": "true"}},
                            "topologyKey": "kubernetes.io/hostname",
                        },
                    }
                ]
            },
            "podAntiAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": [
                    {
                        "labelSelector": {"matchLabels": {"seekr-chain/pg.inference-prod": "true"}},
                        "topologyKey": "kubernetes.io/hostname",
                    }
                ]
            },
        }
