"""Cryonirsp additions to the common dataset extra header model."""

from dkist_processing_common.models.extras import DatasetExtraHeaderData


class CryonirspDatasetExtraHeaderData(DatasetExtraHeaderData):
    """Data needed to build Cryonirsp dataset extra headers."""

    filter: str
    beam: int = 1
