"""Use the Cryonirsp science task to process polarization calibration frames as if they were science observe frames."""

from dkist_processing_common.models.task_name import TaskName
from dkist_service_configuration.logging import logger

from dkist_processing_cryonirsp.models.constants import CryonirspConstants
from dkist_processing_cryonirsp.models.exposure_conditions import ExposureConditions
from dkist_processing_cryonirsp.models.tags import CryonirspTag
from dkist_processing_cryonirsp.tasks.ci_science import CIScienceCalibration
from dkist_processing_cryonirsp.tasks.science_base import ScienceCalibrationBase
from dkist_processing_cryonirsp.tasks.sp_science import SPScienceCalibration

__all__ = ["CIPolcalAsScienceCalibration", "SPPolcalAsScienceCalibration"]


class CryonirspPolcalAsScienceConstants(CryonirspConstants):
    """Temporarily override constants so that loops in the science task can be used for polcal-as-science."""

    @property
    def num_map_scans(self) -> int:
        """Use the map_scans as a proxy for the number of CS steps."""
        return self.num_cs_steps

    @property
    def num_meas(self) -> int:
        """Set the number of measurements to 1."""
        return 1

    @property
    def num_scan_steps(self) -> int:
        """Set the number of scan steps to 1."""
        return 1

    @property
    def observe_exposure_conditions_list(self) -> list[ExposureConditions]:
        """Use the observe exposure conditions as a proxy for polcal exposure conditions."""
        return self.polcal_exposure_conditions_list


class PolcalAsScienceCalibrationBase(ScienceCalibrationBase):
    """
    Base task class for Cryonirsp science-like calibration of polcal input frames.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs
    """

    record_provenance = False

    @property
    def constants_model_class(self):
        """Get temporary Cryonirsp polcal-as-science pipeline constants."""
        return CryonirspPolcalAsScienceConstants

    def run(self):
        """Only run the task if the instrument is running in polarization mode."""
        if self.constants.correct_for_polarization:
            with self.telemetry_span("Loading calibration objects for PCAS"):
                calibrations = self.collect_calibration_objects()

            with self.telemetry_span(
                f"Processing PCAS frames for {self.constants.num_map_scans} CS steps"
            ):
                self.calibrate_and_write_frames(calibrations=calibrations)
        else:
            logger.info(
                "Instrument running in intensity mode - no polcal as science calibration to perform."
            )

    def build_observe_file_tags(
        self,
        map_scan: int,
        scan_step: int,
        meas_num: int,
        modstate: int,
        exposure_conditions: ExposureConditions,
    ) -> list[str]:
        """
        Return list of tags to mark a polcal frame as an observe frame.

        ScienceCalibration loops over map_scan, which we co-opt for CS step.
        CS step is zero indexed.
        """
        tags = [
            CryonirspTag.task_polcal(),
            CryonirspTag.modstate(modstate),
            CryonirspTag.cs_step(map_scan - 1),
            CryonirspTag.linearized_frame(exposure_conditions=exposure_conditions),
        ]
        return tags

    def build_calibrated_file_tags(
        self, stokes: str, meas_num: int, scan_step: int, map_scan: int
    ) -> list[str]:
        """
        Output tags to prepare polcal-as-science output for later use in the dataset extras.

        [Arm]ScienceCalibration loops over map_scan, which we co-opt for CS step.
        CS step is zero indexed. We use a different set of tags for the final outputs
        to prevent collisions with observe outputs.
        """
        tags = [
            CryonirspTag.intermediate(),
            CryonirspTag.frame(),
            CryonirspTag.task(TaskName.polcal_as_science),
            CryonirspTag.stokes(stokes),
            CryonirspTag.cs_step(map_scan - 1),
        ]
        return tags

    def rollback(self):
        """Warn that rolling back this task may conflict with ScienceCalibration, as both share tags and typically execute in parallel."""
        super().rollback()
        logger.warning(
            "Rolling back [Arm]PolCalAsScienceCalibration requires also rolling back [Arm]ScienceCalibration."
        )


class CIPolcalAsScienceCalibration(PolcalAsScienceCalibrationBase, CIScienceCalibration):
    """
    Task class for Cryonirsp CI science-like calibration of polcal input frames.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs
    """

    def run(self):
        """Use the run method from polcal-as-science calibration base class."""
        PolcalAsScienceCalibrationBase.run(self)


class SPPolcalAsScienceCalibration(PolcalAsScienceCalibrationBase, SPScienceCalibration):
    """
    Task class for Cryonirsp SP science-like calibration of polcal input frames.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs
    """

    def run(self):
        """Use the run method from polcal-as-science calibration base class."""
        PolcalAsScienceCalibrationBase.run(self)
