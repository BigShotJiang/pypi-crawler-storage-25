"""Convert intermediate data written in other pipeline tasks into dataset extras for delivery alongside L1 science data."""

from functools import cached_property

import numpy as np
from astropy.io import fits
from dkist_processing_common.codecs.fits import fits_array_decoder
from dkist_processing_common.codecs.json import json_decoder
from dkist_processing_common.models.extras import DatasetExtraHeaderSection
from dkist_processing_common.models.extras import DatasetExtraType
from dkist_processing_common.models.tags import EXP_TIME_ROUND_DIGITS
from dkist_processing_common.models.task_name import TaskName
from dkist_processing_common.tasks.write_extra import WriteL1DatasetExtras

from dkist_processing_cryonirsp.models.constants import CryonirspConstants
from dkist_processing_cryonirsp.models.dataset_extras import CryonirspDatasetExtraHeaderData
from dkist_processing_cryonirsp.models.parameters import CryonirspParameters
from dkist_processing_cryonirsp.models.tags import CryonirspTag

__all__ = ["CryonirspWriteL1DatasetExtras"]


class CryonirspWriteL1DatasetExtras(WriteL1DatasetExtras):
    """Task to write the dataset extra files."""

    @property
    def constants_model_class(self):
        """Get the task constants."""
        return CryonirspConstants

    def __init__(self, recipe_run_id, workflow_name, workflow_version):
        super().__init__(
            recipe_run_id=recipe_run_id,
            workflow_name=workflow_name,
            workflow_version=workflow_version,
        )
        self.parameters = CryonirspParameters(
            scratch=self.scratch,
            obs_ip_start_time=self.constants.obs_ip_start_time,
            wavelength=self.constants.wavelength,
            arm_id=self.constants.arm_id,
        )

    def run(self):
        """Write the dataset extras."""
        self.write_bad_pixel_map_dataset_extra()
        self.write_dark_dataset_extras()
        self.write_solar_gain_dataset_extras()
        if self.constants.correct_for_polarization:
            self.write_demodulation_matrices_dataset_extras()
            self.write_polcal_as_science_dataset_extras()
        if self.constants.arm_id == "SP":
            self.write_wavelength_calibration_input_spectrum_dataset_extra()
            self.write_wavelength_calibration_reference_spectrum_dataset_extra()
            self.write_reference_wavelength_vector_dataset_extra()
            self.write_characteristic_spectra_dataset_extras()
            self.write_beam_offsets_dataset_extras()
            self.write_beam_angles_dataset_extras()
            self.write_spectral_curvature_shifts_dataset_extras()

    @cached_property
    def wavecal_solution(self) -> dict:
        """Return the wavelength calibration solution."""
        solution = next(
            self.read(
                tags=[CryonirspTag.task_spectral_fit(), CryonirspTag.intermediate()],
                decoder=json_decoder,
            )
        )
        return solution

    def format_extra_filename(
        self, extra_name: DatasetExtraType | str, detail: str | None = None
    ) -> str:
        """Override the method from WriteL1DatasetExtras to include the arm name."""
        base_filename = f"{self.constants.instrument}_{self.constants.arm_id}_{self.constants.dataset_id}_{extra_name.replace(' ', '-')}"
        if detail:
            base_filename += "_" + detail
        filename_counter = str(self.filename_counter.increment(base_filename))
        return f"{base_filename}_{filename_counter}.fits"

    def assemble_and_write_dataset_extra(
        self,
        data: np.ndarray | list[np.ndarray],
        header: fits.Header | list[fits.Header],
        filename: str,
        detail: str | None = None,
    ):
        """Override the method from WriteL1DatasetExtras to include telemetry span with filename detail."""
        name = header["EXTNAME"]
        with self.telemetry_span(name=f"Write {name} {detail if detail else ""} dataset extra"):
            super().assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def dataset_extra_headers(self, header_data: CryonirspDatasetExtraHeaderData) -> dict:
        """Override the method from WriteL1DatasetExtras to include additional header sections."""
        headers = super().dataset_extra_headers(header_data=header_data)
        # Cryonirsp section:
        headers.update(
            {
                DatasetExtraHeaderSection.cryonirsp: {
                    "CNARMID": self.constants.arm_id,
                    "CNMODNST": self.constants.num_modstates,
                    "CNBEAM": header_data.beam,
                    "CNFILTNP": header_data.filter,
                },
            }
        )
        if self.constants.arm_id == "SP":
            headers[DatasetExtraHeaderSection.cryonirsp].update(
                {
                    "CNGRTPOS": self.constants.grating_position_deg,
                    "CNGRTLAT": self.constants.grating_littrow_angle_deg,
                    "CNGRTCON": self.constants.grating_constant.value,
                    "CNSLITW": self.constants.slit_width,
                }
            )
        # Wavecal and atlas sections:
        if self.constants.arm_id == "SP":
            headers.update(
                {
                    DatasetExtraHeaderSection.wavecal: {
                        "CTYPE1": self.wavecal_solution.get("CTYPE1")
                        or self.wavecal_solution.get("CTYPE2"),
                        "CUNIT1": self.wavecal_solution.get("CUNIT1")
                        or self.wavecal_solution.get("CUNIT2"),
                        "CRPIX1": self.wavecal_solution.get("CRPIX1")
                        or self.wavecal_solution.get("CRPIX2"),
                        "CDELT1": self.wavecal_solution.get("CDELT1")
                        or self.wavecal_solution.get("CDELT2"),
                        "PV1_0": self.wavecal_solution.get("PV1_0")
                        or self.wavecal_solution.get("PV2_0"),
                        "PV1_1": self.wavecal_solution.get("PV1_1")
                        or self.wavecal_solution.get("PV2_1"),
                        "PV1_2": self.wavecal_solution.get("PV1_2")
                        or self.wavecal_solution.get("PV2_2"),
                    },
                    DatasetExtraHeaderSection.atlas: {
                        "ATLASURL": self.parameters.wavecal_atlas_download_config.base_url,
                    },
                },
            )
        return headers

    @property
    def default_header_sections(self) -> list[DatasetExtraHeaderSection]:
        """Return the default header sections."""
        return [
            DatasetExtraHeaderSection.common,
            DatasetExtraHeaderSection.iptask,
            DatasetExtraHeaderSection.gos,
            DatasetExtraHeaderSection.aggregate,
            DatasetExtraHeaderSection.cryonirsp,
        ]

    @property
    def solar_gain_task_type_dataset_extra_fields(self) -> dict:
        """Return data common to any dataset extra with IP type SOLAR_GAIN."""
        header_data_base = {
            "task_type": TaskName.solar_gain,
            "readout_exposure": self.constants.solar_gain_readout_exp_times[0],
            "total_exposure": self.constants.solar_gain_exposure_conditions_list[0].exposure_time,
            "filter": self.constants.solar_gain_exposure_conditions_list[0].filter_name,
            "end_time": self.constants.solar_gain_date_end,
        }
        return header_data_base

    @property
    def polcal_task_type_dataset_extra_fields(self) -> dict:
        """Return data common to any dataset extra with IP type POLCAL."""
        header_data_base = {
            "task_type": TaskName.polcal,
            "readout_exposure": self.constants.polcal_readout_exp_times[0],
            "total_exposure": self.constants.polcal_exposure_conditions_list[0].exposure_time,
            "filter": self.constants.polcal_exposure_conditions_list[0].filter_name,
            "end_time": self.constants.polcal_date_end,
        }
        return header_data_base

    def write_bad_pixel_map_dataset_extra(self):
        """Create the bad pixel map dataset extra."""
        extra_name = DatasetExtraType.bad_pixel_map
        filename = self.format_extra_filename(extra_name=extra_name)
        data = next(
            self.read(
                tags=[
                    CryonirspTag.intermediate_frame(),
                    CryonirspTag.task_bad_pixel_map(),
                ],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=self.default_header_sections,
            header_data=CryonirspDatasetExtraHeaderData(
                filename=filename,
                extra_name=extra_name,
                **self.solar_gain_task_type_dataset_extra_fields,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_dark_dataset_extras(self):
        """Create the dark dataset extras."""
        extra_name = DatasetExtraType.dark
        if self.constants.arm_id == "CI":
            dark_intermediate_exposure_conditions = (
                self.constants.ci_non_dark_and_non_polcal_and_non_lamp_gain_task_exposure_conditions_list
            )
        else:
            dark_intermediate_exposure_conditions = (
                self.constants.sp_non_dark_and_non_polcal_task_exposure_conditions_list
            )
        for exposure_conditions in dark_intermediate_exposure_conditions:
            for beam in range(1, self.constants.num_beams + 1):
                exposure_time = exposure_conditions.exposure_time
                readout_time = self.constants.dark_fpa_exp_time_to_readout_exp_time_lookup[
                    round(exposure_time, EXP_TIME_ROUND_DIGITS)
                ][0]
                detail = "_".join(
                    [CryonirspTag.beam(beam), CryonirspTag.exposure_time(exposure_time)]
                )
                filename = self.format_extra_filename(extra_name=extra_name, detail=detail)
                data = next(
                    self.read(
                        tags=[
                            CryonirspTag.intermediate_frame(
                                beam=beam, exposure_conditions=exposure_conditions
                            ),
                            CryonirspTag.task_dark(),
                        ],
                        decoder=fits_array_decoder,
                    )
                )
                header = self.build_dataset_extra_header(
                    sections=self.default_header_sections,
                    header_data=CryonirspDatasetExtraHeaderData(
                        task_type=TaskName.dark,
                        filename=filename,
                        extra_name=extra_name,
                        beam=beam,
                        total_exposure=exposure_time,
                        readout_exposure=readout_time,
                        filter=exposure_conditions.filter_name,
                        end_time=self.constants.dark_date_end,
                    ),
                )
                self.assemble_and_write_dataset_extra(
                    data=data, header=header, filename=filename, detail=detail
                )

    def write_solar_gain_dataset_extras(self):
        """Create the solar gain dataset extras."""
        extra_name = DatasetExtraType.solar_gain
        for beam in range(1, self.constants.num_beams + 1):
            detail = CryonirspTag.beam(beam)
            filename = self.format_extra_filename(extra_name=extra_name, detail=detail)
            data = next(
                self.read(
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_solar_gain(),
                    ],
                    decoder=fits_array_decoder,
                )
            )
            header = self.build_dataset_extra_header(
                sections=self.default_header_sections,
                header_data=CryonirspDatasetExtraHeaderData(
                    filename=filename,
                    extra_name=extra_name,
                    beam=beam,
                    **self.solar_gain_task_type_dataset_extra_fields,
                ),
            )
            self.assemble_and_write_dataset_extra(
                data=data, header=header, filename=filename, detail=detail
            )

    def write_characteristic_spectra_dataset_extras(self):
        """Create the characteristic spectra dataset extras."""
        extra_name = DatasetExtraType.characteristic_spectra
        for beam in range(1, self.constants.num_beams + 1):
            detail = CryonirspTag.beam(beam)
            filename = self.format_extra_filename(extra_name=extra_name, detail=detail)
            data = next(
                self.read(
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_characteristic_spectra(),
                    ],
                    decoder=fits_array_decoder,
                )
            )
            header = self.build_dataset_extra_header(
                sections=self.default_header_sections,
                header_data=CryonirspDatasetExtraHeaderData(
                    filename=filename,
                    extra_name=extra_name,
                    beam=beam,
                    **self.solar_gain_task_type_dataset_extra_fields,
                ),
            )
            self.assemble_and_write_dataset_extra(
                data=data, header=header, filename=filename, detail=detail
            )

    def write_beam_offsets_dataset_extras(self):
        """Create the beam offsets dataset extras."""
        extra_name = DatasetExtraType.beam_offsets
        for beam in range(1, self.constants.num_beams + 1):
            detail = CryonirspTag.beam(beam)
            filename = self.format_extra_filename(extra_name=extra_name, detail=detail)
            data = next(
                self.read(
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_geometric_offset(),
                    ],
                    decoder=fits_array_decoder,
                )
            )
            header = self.build_dataset_extra_header(
                sections=self.default_header_sections,
                header_data=CryonirspDatasetExtraHeaderData(
                    filename=filename,
                    extra_name=extra_name,
                    beam=beam,
                    **self.solar_gain_task_type_dataset_extra_fields,
                ),
            )
            self.assemble_and_write_dataset_extra(
                data=data, header=header, filename=filename, detail=detail
            )

    def write_beam_angles_dataset_extras(self):
        """Create the beam angles dataset extras."""
        extra_name = DatasetExtraType.beam_angles
        for beam in range(1, self.constants.num_beams + 1):
            detail = CryonirspTag.beam(beam)
            filename = self.format_extra_filename(extra_name=extra_name, detail=detail)
            data = next(
                self.read(
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_geometric_angle(),
                    ],
                    decoder=fits_array_decoder,
                )
            )
            header = self.build_dataset_extra_header(
                sections=self.default_header_sections,
                header_data=CryonirspDatasetExtraHeaderData(
                    filename=filename,
                    extra_name=extra_name,
                    beam=beam,
                    **self.solar_gain_task_type_dataset_extra_fields,
                ),
            )
            self.assemble_and_write_dataset_extra(
                data=data, header=header, filename=filename, detail=detail
            )

    def write_spectral_curvature_shifts_dataset_extras(self):
        """Create the spectral curvature shifts dataset extras."""
        extra_name = DatasetExtraType.spectral_curvature_shifts
        for beam in range(1, self.constants.num_beams + 1):
            detail = CryonirspTag.beam(beam)
            filename = self.format_extra_filename(extra_name=extra_name, detail=detail)
            data = next(
                self.read(
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_geometric_spectral_shifts(),
                    ],
                    decoder=fits_array_decoder,
                )
            )
            header = self.build_dataset_extra_header(
                sections=self.default_header_sections,
                header_data=CryonirspDatasetExtraHeaderData(
                    filename=filename,
                    extra_name=extra_name,
                    beam=beam,
                    **self.solar_gain_task_type_dataset_extra_fields,
                ),
            )
            self.assemble_and_write_dataset_extra(
                data=data, header=header, filename=filename, detail=detail
            )

    def write_wavelength_calibration_input_spectrum_dataset_extra(self):
        """Create the wavelength calibration input spectrum dataset extras."""
        extra_name = DatasetExtraType.wavelength_calibration_input_spectrum
        filename = self.format_extra_filename(extra_name=extra_name)
        data = next(
            self.read(
                tags=[
                    CryonirspTag.intermediate(),
                    CryonirspTag.task_wavelength_calibration_input_spectrum(),
                ],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=self.default_header_sections,
            header_data=CryonirspDatasetExtraHeaderData(
                filename=filename,
                extra_name=extra_name,
                **self.solar_gain_task_type_dataset_extra_fields,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_wavelength_calibration_reference_spectrum_dataset_extra(self):
        """Create the wavelength calibration reference spectrum dataset extras."""
        extra_name = DatasetExtraType.wavelength_calibration_reference_spectrum
        filename = self.format_extra_filename(extra_name=extra_name)
        data = next(
            self.read(
                tags=[
                    CryonirspTag.intermediate(),
                    CryonirspTag.task_wavelength_calibration_reference_spectrum(),
                ],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.atlas,
                DatasetExtraHeaderSection.cryonirsp,
            ],
            header_data=CryonirspDatasetExtraHeaderData(
                filename=filename,
                extra_name=extra_name,
                **self.solar_gain_task_type_dataset_extra_fields,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_reference_wavelength_vector_dataset_extra(self):
        """Create the reference wavelength vector dataset extras."""
        extra_name = DatasetExtraType.reference_wavelength_vector
        filename = self.format_extra_filename(extra_name=extra_name)
        data = next(
            self.read(
                tags=[
                    CryonirspTag.intermediate(),
                    CryonirspTag.task_wavelength_calibration_reference_wavelength_vector(),
                ],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.wavecal,
                DatasetExtraHeaderSection.cryonirsp,
            ],
            header_data=CryonirspDatasetExtraHeaderData(
                filename=filename,
                extra_name=extra_name,
                **self.solar_gain_task_type_dataset_extra_fields,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_demodulation_matrices_dataset_extras(self):
        """Create the demodulation matrices dataset extras."""
        extra_name = DatasetExtraType.demodulation_matrices
        for beam in range(1, self.constants.num_beams + 1):
            detail = CryonirspTag.beam(beam)
            filename = self.format_extra_filename(extra_name=extra_name, detail=detail)
            data = next(
                self.read(
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_demodulation_matrices(),
                    ],
                    decoder=fits_array_decoder,
                )
            )
            header = self.build_dataset_extra_header(
                sections=[
                    DatasetExtraHeaderSection.common,
                    DatasetExtraHeaderSection.iptask,
                    DatasetExtraHeaderSection.aggregate,
                    DatasetExtraHeaderSection.cryonirsp,
                ],
                header_data=CryonirspDatasetExtraHeaderData(
                    filename=filename,
                    extra_name=extra_name,
                    beam=beam,
                    **self.polcal_task_type_dataset_extra_fields,
                ),
            )
            self.assemble_and_write_dataset_extra(
                data=data, header=header, filename=filename, detail=detail
            )

    def write_polcal_as_science_dataset_extras(self):
        """Create the polcal-as-science dataset extras."""
        extra_name = DatasetExtraType.polcal_as_science
        for cs_step in range(self.constants.num_cs_steps):
            for stokes in self.constants.stokes_params:
                detail = "_".join([CryonirspTag.cs_step(cs_step), CryonirspTag.stokes(stokes)])
                filename = self.format_extra_filename(extra_name=extra_name, detail=detail)
                data = next(
                    self.read(
                        tags=[
                            CryonirspTag.task(TaskName.polcal_as_science),
                            CryonirspTag.cs_step(cs_step),
                            CryonirspTag.stokes(stokes),
                        ],
                        decoder=fits_array_decoder,
                    )
                )
                header = self.build_dataset_extra_header(
                    sections=[
                        DatasetExtraHeaderSection.common,
                        DatasetExtraHeaderSection.iptask,
                        DatasetExtraHeaderSection.gos,
                        DatasetExtraHeaderSection.pcas,
                        DatasetExtraHeaderSection.cryonirsp,
                    ],
                    header_data=CryonirspDatasetExtraHeaderData(
                        filename=filename,
                        extra_name=extra_name,
                        **self.polcal_task_type_dataset_extra_fields,
                        num_cs_steps=self.constants.num_cs_steps,
                        frame_in_cs_step=1,
                        num_frames_per_cs_step=1,
                        cs_step=cs_step,
                        stokes=stokes,
                    ),
                )
                self.assemble_and_write_dataset_extra(
                    data=data, header=header, filename=filename, detail=detail
                )
