from datetime import datetime

import numpy as np
import pytest
from astropy.io import fits
from dkist_header_validator import spec122_validator
from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.codecs.fits import fits_array_encoder
from dkist_processing_common.codecs.fits import fits_hdulist_encoder
from dkist_processing_common.models.task_name import TaskName

from dkist_processing_cryonirsp.models.exposure_conditions import AllowableOpticalDensityFilterNames
from dkist_processing_cryonirsp.models.exposure_conditions import ExposureConditions
from dkist_processing_cryonirsp.models.tags import CryonirspTag
from dkist_processing_cryonirsp.tasks.polcal_as_science import CIPolcalAsScienceCalibration
from dkist_processing_cryonirsp.tasks.polcal_as_science import SPPolcalAsScienceCalibration
from dkist_processing_cryonirsp.tests.conftest import CryonirspConstantsDb
from dkist_processing_cryonirsp.tests.conftest import cryonirsp_testing_parameters_factory
from dkist_processing_cryonirsp.tests.conftest import generate_fits_frame
from dkist_processing_cryonirsp.tests.header_models import CryonirspHeadersValidPolcalFrames


@pytest.fixture(params=["CI", "SP"])
def arm_id(request):
    return request.param


@pytest.fixture(params=["Full Stokes", "Stokes-I"])
def pol_mode(request):
    return request.param


def create_polcal_arrays(
    task,
    dataset_shape,
    array_shape,
    exposure_conditions,
    start_time,
    num_modstates,
    num_cs_steps,
):
    for modstate in range(1, num_modstates + 1):
        # Create polcal input frames for this modstate
        ds = CryonirspHeadersValidPolcalFrames(
            dataset_shape=dataset_shape,
            array_shape=array_shape,
            time_delta=10,
            num_modstates=num_modstates,
            modstate=modstate,
            start_time=start_time,
        )
        header_generator = (
            spec122_validator.validate_and_translate_to_214_l0(
                d.header(), return_type=fits.HDUList
            )[0].header
            for d in ds
        )
        # cs_step does not map to a single keyword, so not needed in the fake headers
        # We start at 2 because dark and gain are 0 and 1
        for cs_step in range(num_cs_steps):
            hdul = generate_fits_frame(header_generator=header_generator, shape=array_shape)
            task.write(
                data=hdul,
                tags=[
                    CryonirspTag.task_polcal(),
                    CryonirspTag.modstate(modstate),
                    CryonirspTag.cs_step(cs_step),
                    CryonirspTag.linearized_frame(exposure_conditions=exposure_conditions),
                ],
                encoder=fits_hdulist_encoder,
            )


@pytest.fixture
def polcal_as_science_calibration_task(
    arm_id,
    pol_mode,
    tmp_path,
    recipe_run_id,
    assign_input_dataset_doc_to_task,
    init_cryonirsp_constants_db,
):
    num_modstates = 2 if pol_mode == "Full Stokes" else 1
    modulator_spin_mode = "Continuous" if pol_mode == "Full Stokes" else "Off"
    num_beams = 2 if arm_id == "SP" else 1
    num_cs_steps = 2
    exposure_time = 0.01  # From CryoHeadersValidPolcalFrames fixture (Check this value)
    exposure_conditions = ExposureConditions(
        exposure_time, AllowableOpticalDensityFilterNames.OPEN.value
    )
    array_shape = (1, 20, 10)
    intermediate_shape = array_shape[1:]
    dataset_shape = (num_cs_steps,) + array_shape[1:]

    constants_db = CryonirspConstantsDb(
        ARM_ID=arm_id,
        NUM_MODSTATES=num_modstates,
        NUM_BEAMS=num_beams,
        NUM_CS_STEPS=num_cs_steps,
        POLCAL_EXPOSURE_CONDITIONS_LIST=(exposure_conditions,),
        OBSERVE_EXPOSURE_CONDITIONS_LIST=(exposure_conditions,),
        MODULATOR_SPIN_MODE=modulator_spin_mode,
    )
    init_cryonirsp_constants_db(recipe_run_id, constants_db)

    task_class = SPPolcalAsScienceCalibration if arm_id == "SP" else CIPolcalAsScienceCalibration
    with task_class(
        recipe_run_id=recipe_run_id,
        workflow_name="polcal_as_science_calibration",
        workflow_version="VX.Y",
    ) as task:
        try:  # This try... block is here to make sure the dbs get cleaned up if there's a failure in the fixture
            task.scratch = WorkflowFileSystem(
                scratch_base_path=tmp_path, recipe_run_id=recipe_run_id
            )
            param_class = cryonirsp_testing_parameters_factory(task)
            assign_input_dataset_doc_to_task(task, param_class())

            # Create beam boundary file
            for beam in range(1, num_beams + 1):
                task.write(
                    data=np.array([0, intermediate_shape[0], 0, intermediate_shape[1]]),
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_beam_boundaries(),
                    ],
                    encoder=fits_array_encoder,
                )
            # Create fake bad pixel map
            task.write(
                data=np.zeros(array_shape[1:]),
                tags=[CryonirspTag.intermediate_frame(), CryonirspTag.task_bad_pixel_map()],
                encoder=fits_array_encoder,
            )
            # Create fake demodulation matrices
            demod_matrices = np.zeros((1, 1, 4, num_modstates))
            for modstate in range(num_modstates):
                demod_matrices[0, 0, :, modstate] = [1, 2, 3, 4]
            for beam in range(1, num_beams + 1):
                demod_hdul = fits.HDUList([fits.PrimaryHDU(data=demod_matrices)])
                task.write(
                    data=demod_hdul,
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_demodulation_matrices(),
                    ],
                    encoder=fits_hdulist_encoder,
                )
            # Create fake dark intermediate arrays
            for beam in range(1, num_beams + 1):
                task.write(
                    data=np.zeros(intermediate_shape),
                    tags=[
                        CryonirspTag.intermediate_frame(
                            beam=beam, exposure_conditions=exposure_conditions
                        ),
                        CryonirspTag.task_dark(),
                    ],
                    encoder=fits_array_encoder,
                )
            # Create fake lamp and solar gain intermediate arrays
            for beam in range(1, num_beams + 1):
                for modstate in range(1, num_modstates + 1):
                    gain_hdul = fits.HDUList([fits.PrimaryHDU(data=np.ones(intermediate_shape))])
                    task.write(
                        data=gain_hdul,
                        tags=[
                            CryonirspTag.intermediate_frame(beam=beam),
                            CryonirspTag.task_lamp_gain(),
                            CryonirspTag.modstate(modstate),
                        ],
                        encoder=fits_hdulist_encoder,
                    )
                    task.write(
                        data=gain_hdul,
                        tags=[
                            CryonirspTag.intermediate_frame(beam=beam),
                            CryonirspTag.task_solar_gain(),
                            CryonirspTag.modstate(modstate),
                        ],
                        encoder=fits_hdulist_encoder,
                    )
            # Create fake geometric objects
            angle = np.array([0.0])
            offset = np.array([-10.2, 5.1])
            spec_shift = np.zeros(intermediate_shape[0])
            for beam in range(1, num_beams + 1):
                task.write(
                    data=angle,
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_geometric_angle(),
                    ],
                    encoder=fits_array_encoder,
                )
                task.write(
                    data=spec_shift,
                    tags=[
                        CryonirspTag.intermediate_frame(beam=beam),
                        CryonirspTag.task_geometric_spectral_shifts(),
                    ],
                    encoder=fits_array_encoder,
                )
                for modstate in range(1, num_modstates + 1):
                    task.write(
                        data=offset
                        * (beam - 1),  # Because we need the fiducial array to have (0, 0) offset
                        tags=[
                            CryonirspTag.intermediate_frame(beam=beam),
                            CryonirspTag.task_geometric_offset(),
                            CryonirspTag.modstate(modstate),
                        ],
                        encoder=fits_array_encoder,
                    )

            # Create polcal frames to be used as observe frames
            start_time = datetime.now()
            # polcal frames for all modstates
            create_polcal_arrays(
                task,
                dataset_shape,
                array_shape,
                exposure_conditions,
                start_time,
                num_modstates,
                num_cs_steps,
            )
            yield task, arm_id, pol_mode
        finally:
            task._purge()


def test_polcal_as_science_calibration_task(
    polcal_as_science_calibration_task, mocker, fake_gql_client
):
    """
    Given: A PolcalAsScienceCalibration task (either CI or SP)
    When: Calling the task instance
    Then: The expected number of polcal-as-science frames exist with the correct tags
    """
    mocker.patch(
        "dkist_processing_common.tasks.mixin.metadata_store.GraphQLClient", new=fake_gql_client
    )
    task, arm_id, pol_mode = polcal_as_science_calibration_task
    task()
    output_files = list(task.read(tags=[CryonirspTag.task(TaskName.polcal_as_science)]))
    if pol_mode == "Stokes-I":
        assert len(output_files) == 0
    else:
        num_stokes = len(task.constants.stokes_params)
        num_cs_steps = task.constants.num_cs_steps
        assert len(output_files) == num_cs_steps * num_stokes
        for cs_step in range(num_cs_steps):
            for stokes_param in task.constants.stokes_params:
                tags = [
                    CryonirspTag.task(TaskName.polcal_as_science),
                    CryonirspTag.stokes(stokes_param),
                    CryonirspTag.cs_step(cs_step),
                ]
                assert len(list(task.read(tags=tags))) == 1
