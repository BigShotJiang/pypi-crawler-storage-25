from pathlib import Path
from unittest.mock import MagicMock

import pytest
from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.tasks import AssembleQualityData

from dkist_processing_cryonirsp.tasks.l1_output_data import CIAssembleQualityData
from dkist_processing_cryonirsp.tasks.l1_output_data import SPAssembleQualityData
from dkist_processing_cryonirsp.tests.conftest import CryonirspConstantsDb


@pytest.fixture(scope="function", params=["CI", "SP"])
def cryo_assemble_quality_data_task(
    tmp_path, recipe_run_id, init_cryonirsp_constants_db, request
) -> AssembleQualityData:
    arm_id = request.param
    init_cryonirsp_constants_db(
        recipe_run_id=recipe_run_id, constants_obj=CryonirspConstantsDb(ARM_ID=arm_id)
    )
    if arm_id == "CI":
        with CIAssembleQualityData(
            recipe_run_id=recipe_run_id,
            workflow_name="cryonirsp_submit_quality",
            workflow_version="VX.Y",
        ) as task:
            yield task, arm_id
            task._purge()
    elif arm_id == "SP":
        with SPAssembleQualityData(
            recipe_run_id=recipe_run_id,
            workflow_name="cryonirsp_submit_quality",
            workflow_version="VX.Y",
        ) as task:
            yield task, arm_id
            task._purge()
    else:
        raise RuntimeError(f"Invalid cryo-nirsp arm_id: {arm_id!r}")


@pytest.fixture
def dummy_quality_data() -> list[dict]:
    return [{"dummy_key": "dummy_value"}]


@pytest.fixture
def quality_assemble_data_mock(mocker, dummy_quality_data) -> MagicMock:
    yield mocker.patch(
        "dkist_processing_common.tasks.mixin.quality.QualityMixin.quality_assemble_data",
        return_value=dummy_quality_data,
        autospec=True,
    )


@pytest.fixture
def assemble_quality_data_task(
    tmp_path: Path, recipe_run_id: int, init_cryonirsp_constants_db
) -> CIAssembleQualityData:
    constants_db = CryonirspConstantsDb(NUM_MODSTATES=2)
    init_cryonirsp_constants_db(recipe_run_id, constants_db)
    with CIAssembleQualityData(
        recipe_run_id=recipe_run_id,
        workflow_name="ci_assemble_quality",
        workflow_version="ci_assemble_quality_version",
    ) as task:
        task.scratch = WorkflowFileSystem(
            recipe_run_id=recipe_run_id,
            scratch_base_path=tmp_path,
        )
        yield task
        task._purge()


def test_correct_polcal_label_list(cryo_assemble_quality_data_task, quality_assemble_data_mock):
    """
    Given: A CIAssembleQualityData task
    When: Calling the task
    Then: The correct polcal_label_list property is passed to .quality_assemble_data
    """
    task, arm_id = cryo_assemble_quality_data_task

    task()

    if arm_id == "SP":
        quality_assemble_data_mock.assert_called_once_with(
            task, polcal_label_list=["SP Beam 1", "SP Beam 2"]
        )
    elif arm_id == "CI":
        quality_assemble_data_mock.assert_called_once_with(task, polcal_label_list=["CI Beam 1"])
    else:
        raise RuntimeError(f"Invalid cryo-nirsp arm_id: {arm_id!r}")
