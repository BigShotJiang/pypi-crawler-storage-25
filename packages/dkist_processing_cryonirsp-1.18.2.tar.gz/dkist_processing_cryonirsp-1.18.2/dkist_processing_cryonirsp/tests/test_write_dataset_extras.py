import numpy as np
import pytest
from astropy.io import fits
from dkist_header_validator.spec_validators import spec_extras_validator
from dkist_processing_common.codecs.fits import fits_array_encoder
from dkist_processing_common.codecs.json import json_encoder
from dkist_processing_common.models.extras import DatasetExtraType
from dkist_processing_common.models.task_name import TaskName

from dkist_processing_cryonirsp.models.dataset_extras import CryonirspDatasetExtraHeaderData
from dkist_processing_cryonirsp.models.exposure_conditions import AllowableOpticalDensityFilterNames
from dkist_processing_cryonirsp.models.exposure_conditions import ExposureConditions
from dkist_processing_cryonirsp.models.tags import CryonirspTag
from dkist_processing_cryonirsp.tasks.write_dataset_extras import CryonirspWriteL1DatasetExtras
from dkist_processing_cryonirsp.tests.conftest import CryonirspConstantsDb
from dkist_processing_cryonirsp.tests.conftest import cryonirsp_testing_parameters_factory


@pytest.fixture(scope="function")
def write_dataset_extras_task(
    recipe_run_id,
    init_cryonirsp_constants_db,
    num_stokes_params,
    arm_id,
    assign_input_dataset_doc_to_task,
):
    if num_stokes_params == 1:
        num_modstates = 1
    else:
        num_modstates = 2

    constants_db = CryonirspConstantsDb(
        # Needed so self.correct_for_polarization is set to the right value
        NUM_MODSTATES=num_modstates,
        ARM_ID=arm_id,
        POLCAL_EXPOSURE_CONDITIONS_LIST=(
            ExposureConditions(0.01, AllowableOpticalDensityFilterNames.OPEN.value),
        ),
        DARK_FRAME_EXPOSURE_CONDITIONS_LIST=(
            ExposureConditions(100.0, AllowableOpticalDensityFilterNames.NONE.value),
            ExposureConditions(1.0, AllowableOpticalDensityFilterNames.NONE.value),
            ExposureConditions(0.01, AllowableOpticalDensityFilterNames.NONE.value),
        ),
    )

    init_cryonirsp_constants_db(recipe_run_id, constants_db)
    with CryonirspWriteL1DatasetExtras(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        param_class = cryonirsp_testing_parameters_factory(task)
        assign_input_dataset_doc_to_task(task, param_class())
        try:  # This try... block is here to make sure the dbs get cleaned up if there's a failure in the fixture
            if arm_id == "SP":
                write_dummy_sp_dispersion_intermediate(task)
            yield task
        finally:
            task._purge()


def write_dummy_sp_dispersion_intermediate(task: CryonirspWriteL1DatasetExtras) -> None:
    dummy_fit_solution = {
        "CTYPE1": "AWAV-GRA",
        "CUNIT1": "nm",
        "CRPIX1": 5,
        "CRVAL1": 9999.0,
        "CDELT1": 4.56,
        "PV1_0": 78.9,
        "PV1_1": 51,
        "PV1_2": 11121,
    }
    dummy_fit_solution = dummy_fit_solution | {f"{k}A": v for k, v in dummy_fit_solution.items()}
    task.write(
        data=dummy_fit_solution,
        tags=[CryonirspTag.intermediate(), CryonirspTag.task_spectral_fit()],
        encoder=json_encoder,
    )


def dark_intermediate_exposure_conditions(
    task: CryonirspWriteL1DatasetExtras,
) -> list[ExposureConditions]:
    """Return the list of dark exposure conditions written as intermediate frames."""
    if task.constants.arm_id == "CI":
        return (
            task.constants.ci_non_dark_and_non_polcal_and_non_lamp_gain_task_exposure_conditions_list
        )
    if task.constants.arm_id == "SP":
        return task.constants.sp_non_dark_and_non_polcal_task_exposure_conditions_list


def write_intermediate_files_to_task(task: CryonirspWriteL1DatasetExtras):
    for beam in range(1, task.constants.num_beams + 1):
        task.write(
            data=np.zeros((10, 10)),
            tags=[CryonirspTag.intermediate_frame(beam=beam), CryonirspTag.task_solar_gain()],
            encoder=fits_array_encoder,
        )
        task.write(
            data=np.zeros((10, 10)),
            tags=[
                CryonirspTag.intermediate_frame(beam=beam),
                CryonirspTag.task_characteristic_spectra(),
            ],
            encoder=fits_array_encoder,
        )
        task.write(
            data=np.zeros((10, 10)),
            tags=[
                CryonirspTag.intermediate_frame(beam=beam),
                CryonirspTag.task_geometric_offset(),
            ],
            encoder=fits_array_encoder,
        )
        task.write(
            data=np.zeros((10, 10)),
            tags=[
                CryonirspTag.intermediate_frame(beam=beam),
                CryonirspTag.task_geometric_angle(),
            ],
            encoder=fits_array_encoder,
        )
        task.write(
            data=np.zeros((10, 10)),
            tags=[
                CryonirspTag.intermediate_frame(beam=beam),
                CryonirspTag.task_geometric_spectral_shifts(),
            ],
            encoder=fits_array_encoder,
        )
        task.write(
            data=np.zeros((10, 10)),
            tags=[
                CryonirspTag.intermediate_frame(beam=beam),
                CryonirspTag.task_demodulation_matrices(),
            ],
            encoder=fits_array_encoder,
        )
        for exposure_conditions in dark_intermediate_exposure_conditions(task):
            task.write(
                data=np.zeros((10, 10)),
                tags=[
                    CryonirspTag.intermediate_frame(
                        beam=beam, exposure_conditions=exposure_conditions
                    ),
                    CryonirspTag.task_dark(),
                ],
                encoder=fits_array_encoder,
            )
    task.write(
        data=np.zeros((10, 10)),
        tags=[CryonirspTag.intermediate_frame(), CryonirspTag.task_bad_pixel_map()],
        encoder=fits_array_encoder,
    )
    task.write(
        data=np.zeros((10, 10)),
        tags=[
            CryonirspTag.intermediate(),
            CryonirspTag.task_wavelength_calibration_input_spectrum(),
        ],
        encoder=fits_array_encoder,
    )
    task.write(
        data=np.zeros((10, 10)),
        tags=[
            CryonirspTag.intermediate(),
            CryonirspTag.task_wavelength_calibration_reference_spectrum(),
        ],
        encoder=fits_array_encoder,
    )
    task.write(
        data=np.zeros((10, 10)),
        tags=[
            CryonirspTag.intermediate(),
            CryonirspTag.task_wavelength_calibration_reference_wavelength_vector(),
        ],
        encoder=fits_array_encoder,
    )
    for stokes in task.constants.stokes_params:
        for cs_step in range(task.constants.num_cs_steps):
            task.write(
                data=np.zeros((10, 10)),
                tags=[
                    CryonirspTag.task(TaskName.polcal_as_science),
                    CryonirspTag.stokes(stokes),
                    CryonirspTag.cs_step(cs_step),
                ],
                encoder=fits_array_encoder,
            )


@pytest.mark.parametrize(
    "num_stokes_params",
    [pytest.param(1, id="Stokes_I"), pytest.param(4, id="Stokes_IQUV")],
)
@pytest.mark.parametrize(
    "arm_id",
    [pytest.param("CI", id="CI"), pytest.param("SP", id="SP")],
)
def test_write_dataset_extras(
    write_dataset_extras_task,
    mocker,
    fake_gql_client,
    arm_id,
    num_stokes_params,
):
    """
    :Given: a write dataset extras task
    :When: running the task
    :Then: the correct number of files are written with the correct headers
    """
    mocker.patch(
        "dkist_processing_common.tasks.mixin.metadata_store.GraphQLClient", new=fake_gql_client
    )
    task = write_dataset_extras_task
    write_intermediate_files_to_task(task)
    task()

    files = list(task.read(tags=[CryonirspTag.extra()]))
    num_beams = task.constants.num_beams
    num_cs_steps = task.constants.num_cs_steps
    num_dark_exp_times = len(dark_intermediate_exposure_conditions(task))
    expected_num_common_extras = {
        "bad_pixel_maps": 1,
        "dark": num_beams * num_dark_exp_times,
        "solar_gain": num_beams,
    }
    expected_num_SP_extras = {
        "characteristic_spectra": num_beams,
        "beam_offsets": num_beams,
        "beam_angles": num_beams,
        "spectral_curvature_shifts": num_beams,
        "wavecal_input": 1,
        "wavecal_best_fit": 1,
        "wavecal_wavelength": 1,
    }
    expected_num_polarization_extras = {
        "demod_matrices": num_beams,
        "pcas": num_stokes_params * num_cs_steps,
    }

    expected_num_files = sum(expected_num_common_extras.values())
    if arm_id == "SP":
        expected_num_files += sum(expected_num_SP_extras.values())
    if num_stokes_params == 4:
        expected_num_files += sum(expected_num_polarization_extras.values())
    assert len(files) == expected_num_files
    for file in files:
        assert file.exists
        assert spec_extras_validator.validate(file, extra=False)
        hdu_list = fits.open(file)
        header = hdu_list[1].header
        assert len(hdu_list) == 2  # Primary, CompImage
        assert isinstance(hdu_list[0], fits.PrimaryHDU)
        assert isinstance(hdu_list[1], fits.CompImageHDU)
        assert header["PROCTYPE"] == "L1_EXTRA"
        assert header["EXTNAME"] in DatasetExtraType
        if arm_id == "CI":
            assert "CNGRTPOS" not in header
            assert "CNGRTLAT" not in header
            assert "CNGRTCON" not in header
            assert "CNSLITW" not in header
