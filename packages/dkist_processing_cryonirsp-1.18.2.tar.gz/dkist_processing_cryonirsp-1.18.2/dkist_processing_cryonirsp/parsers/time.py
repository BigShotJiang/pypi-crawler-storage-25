"""Buds to parse exposure time."""

from datetime import datetime
from datetime import timezone
from typing import Callable
from typing import Type

from dkist_processing_common.models.fits_access import MetadataKey
from dkist_processing_common.models.flower_pot import SetStem
from dkist_processing_common.models.flower_pot import SpilledDirt
from dkist_processing_common.parsers.lookup_bud import TaskTimeLookupBud
from dkist_processing_common.parsers.task import passthrough_header_ip_task
from dkist_processing_common.parsers.time import TaskDatetimeBudBase

from dkist_processing_cryonirsp.models.constants import CryonirspBudName
from dkist_processing_cryonirsp.models.exposure_conditions import CRYO_EXP_TIME_ROUND_DIGITS
from dkist_processing_cryonirsp.parsers.cryonirsp_l0_fits_access import CryonirspRampFitsAccess


class CryonirspTimeObsBud(SetStem):
    """
    Produce a tuple of all time_obs values present in the dataset.

    The time_obs is a unique identifier for all raw frames in a single ramp. Hence, this list identifies all
    the ramps that must be processed in a data set.
    """

    def __init__(self):
        super().__init__(stem_name=CryonirspBudName.time_obs_list.value)

    def setter(self, fits_obj: CryonirspRampFitsAccess) -> str:
        """
        Set the time_obs for this fits object.

        Parameters
        ----------
        fits_obj
            The input fits object
        Returns
        -------
        The time_obs value associated with this fits object
        """
        return fits_obj.time_obs

    def getter(self) -> tuple:
        """
        Get the sorted tuple of time_obs values.

        Returns
        -------
        A tuple of exposure times
        """
        time_obs_tup = tuple(sorted(self.value_set))
        return time_obs_tup


class TaskDateEndBud(TaskDatetimeBudBase):
    """Class for the date end task Bud."""

    def __init__(
        self,
        constant_name: str,
        ip_task_types: str | list[str],
        task_type_parsing_function: Callable = passthrough_header_ip_task,
    ):
        super().__init__(
            stem_name=constant_name,
            metadata_key=MetadataKey.time_obs,
            ip_task_types=ip_task_types,
            task_type_parsing_function=task_type_parsing_function,
        )

    def setter(self, fits_obj: CryonirspRampFitsAccess) -> float | Type[SpilledDirt]:
        """
        Calculate the date end and store it as unix seconds if the task type is in the desired types.

        Parameters
        ----------
        fits_obj
            The input fits object
        Returns
        -------
        The datetime in seconds
        """
        # super().setter() returns date-begin in unix seconds
        date_beg = super().setter(fits_obj)
        if date_beg == SpilledDirt:
            return SpilledDirt
        exp_time = fits_obj.fpa_exposure_time_ms / 1000.0
        date_end = date_beg + exp_time
        return date_end

    def getter(self) -> str:
        """
        Return the latest date end for the ip task type converted from unix seconds to datetime string.

        Returns
        -------
        Return the maximum date end as a datetime string
        """
        # super().getter() returns a sorted list
        max_time = super().getter()[-1]
        max_time_dt = datetime.fromtimestamp(max_time, tz=timezone.utc)
        return max_time_dt.strftime("%Y-%m-%dT%H:%M:%S.%f")


class CryonirspTaskTimeLookupBud(TaskTimeLookupBud):
    """
    Subclass of `TaskTimeLookupBud` that rounds the key values with the Cryonirsp rounding.

    Parameters
    ----------
    constant_name
        The name for the constant to be defined

    key_metadata_key
        The time metadata key for the resulting dictionary key

    value_metadata_key
        The metadata key for the resulting dictionary value

    ip_task_types
        Only consider objects whose parsed header IP task type matches a string in this list

    task_type_parsing_function
        The function used to convert a header into an IP task type
    """

    def getter(self):
        """
        Get the dictionary mapping created by the setter with Cryonirsp rounding applied to keys.

        Returns
        -------
        The mapping dictionary with values converted to JSON-able lists
        """
        mapping_lists = {
            round(k, CRYO_EXP_TIME_ROUND_DIGITS): l for k, l in super().getter().items()
        }
        return mapping_lists
