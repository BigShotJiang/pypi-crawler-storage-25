Dataset Extras
==============

In addition to the L1 science frames, each Cryo-NIRSP dataset includes a collection of "dataset extras", which are
described in detail on this page.

**NOTE:** The primary purpose of dataset extras is to provide a common context between the user and the DKIST Data Center
when discussing issues seen in the L1 data. Any user who uses dataset extras for analysis or inferring properties of the L1
data does so *at their own risk*. **Support for the dataset extras as useful end-user data is not guaranteed.**

Location and Naming
-------------------

All dataset extras are included with a full download of the main dataset and live in a subdirectory called "extra". The
general naming scheme is

`CRYO-NIRSP_{ARM_ID}_{DATASET_ID}_{NAME}_{DETAIL}_{COUNTER}.fits`

with

ARM_ID
    The arm of the current dataset, either CI for the context imager or SP for the spectropolarimeter.

DATASET_ID
    The dataset ID of the current dataset. Matches the same value in the names of L1 files.

NAME
    The identifier of the current extra. See the list below.

DETAIL
    Most Dataset Extras use extra details in their filenames that correspond to properties that change within extras of
    the same NAME. The full list of potential DETAILS is below; see each extra's description for which details are
    included in its filename.

    BEAM_{VALUE}
        The Cryo-NIRSP beam. The CI arm has one beam and the SP arm has two beams.

    EXP_TIME_{VALUE}
        The sensor exposure time.

    CS_STEP_{VALUE}
        For Polcal-As-Science extras, the current Calibration Sequence step.

    STOKES_{VALUE}
        For Polcal-As-Science extras, the current Stokes parameter.

COUNTER
    A counter that starts from 1. Allows for multiple extras of the same type, although this is very rare.

Headers
-------

All dataset extra files have headers that conform to the `Dataset Extras FITS Specification <https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#>`_.
Please see that page for a complete list of header keys and their meanings. Note that, apart from the
`Cryo-NIRSP <https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#cryo-nirsp-keywords>`_ table,
not all extras will have all header keys; the specific tables that apply to each extra are listed below.

List of Dataset Extras
----------------------

The values of this list correspond to the "NAME" field mentioned above.

BAD-PIXEL-MAP
    The map of the bad pixels, result of the `~dkist_processing_cryonirsp.tasks.bad_pixel_map` task.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

DARK
    The average dark frame used to correct all other frames.  The dark is a result of the `~dkist_processing_cryonirsp.tasks.dark`
    task.  There is one file per beam.  This extra also includes a `EXP_TIME_{VALUE}` part of the filename that corresponds
    to the sensor time of the given dark.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM, EXP_TIME

SOLAR-GAIN
    The average solar gain/flat array used to correct science data, with solar spectrum removed.  The solar gain
    is the result of the `~dkist_processing_cryonirsp.tasks.gain` task (or `~dkist_processing_cryonirsp.tasks.sp_solar_gain`
    for the SP arm). There is one file per beam.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

CHARACTERISTIC-SPECTRA
    The measured characteristic solar spectrum that is removed from raw solar gain frames to produce the SOLAR-GAIN frames,
    provided only for observations with the SP arm.
    There is one file per beam, each with a data shape determined by the beam boundary, less than or equal to `(2048,)`.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

BEAM-OFFSETS
    The (x, y) pixel offset needed to align each beam with the fiducial beam, provided only for observations with the SP arm.
    There is one file per beam, each with a data shape `(2,)`.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

BEAM-ANGLE
    The rotation angle that, when applied to each beam, aligns the spatial axis with a pixel axis, provided only for
    observations with the SP arm. There is one file per beam, each with a single float value.
    See :doc:`here </beam_angle_calculation>` for more information.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

SPECTRAL-CURVATURE-SHIFTS
    The pixel shift in the dispersion direction to apply to each spatial pixel to align all spectra to the same
    relative wavelength grid, provided only for observations with the SP arm. There is one file per beam, each with a
    single value per spatial pixel.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

WAVELENGTH-CALIBRATION-INPUT-SPECTRUM
    Representative solar spectrum (derived from the solar gain images) used to compute the absolute wavelength solution,
    provided only for observations with the SP arm. See :doc:`here </wavelength_calibration>` for more information.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

WAVELENGTH-CALIBRATION-REFERENCE-SPECTRUM
    The best-fit combination of Solar and telluric atlases, provided only for observations with the SP arm.
    See :doc:`here </wavelength_calibration>` for more information.

    **Header tables**: `Common`_, `Atlas`_

REFERENCE-WAVELENGTH-VECTOR
    Wavelength abscissa for both the input and best-fit atlas spectra, provided only for observations with the SP arm.
    Units are nanometers.

    **Header tables**: `Common`_, `Wavecal`_

DEMODULATION-MATRICES
    Arrays used to demodulate science data, provided only for observations in polarimetric mode. There is one file per
    beam.  The data shape is `(4, 8)`, which correspond to Stokes dimension and modulation state, respectively.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_

    **DETAIL fields**: BEAM

POLCAL-AS-SCIENCE
    The INPUT POLCAL task-type frames processed as if they were science frames, provided only for observations in
    polarimetric mode. These extras include the `CS_STEP_{VALUE}` detail, which indicates the
    `Calibration Sequence <https://docs.dkist.nso.edu/projects/pac/en/stable/background.html#the-rol-of-polcal-data>`_
    step. The POLCAL frames are processed exactly the same as science frames; see detail on the
    :doc:`CI arm calibration</ci_science_calibration>` and the :doc:`SP arm calibration </sp_science_calibration>`
    for more information.

    **Header tables**: `Common`_, `IPTASK`_, `GOS`_, `PCAS`_

    **DETAIL fields**: CS_STEP, STOKES

.. _Common: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#common-keywords
.. _Aggregate: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#aggregate-keywords
.. _IPTASK: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#iptask-keywords
.. _GOS: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#gos-configuration-keywords
.. _Wavecal: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#wavelength-calibration-keywords
.. _Atlas: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#atlas-keywords
.. _PCAS: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#pcas-keywords
