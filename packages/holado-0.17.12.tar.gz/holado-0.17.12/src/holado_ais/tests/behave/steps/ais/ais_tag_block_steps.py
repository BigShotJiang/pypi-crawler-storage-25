# -*- coding: utf-8 -*-

#################################################
# HolAdo (Holistic Automation do)
#
# (C) Copyright 2021-2025 by Eric Klumpp
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

# The Software is provided “as is”, without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose and noninfringement. In no event shall the authors or copyright holders be liable for any claim, damages or other liability, whether in an action of contract, tort or otherwise, arising from, out of or in connection with the software or the use or other dealings in the Software.
#################################################


from holado_test.scenario.step_tools import StepTools
from holado.common.context.session_context import SessionContext
import logging
from holado_test.behave.scenario.behave_step_tools import BehaveStepTools
from holado_ais.ais.ais_messages import AISMessages
# pyais imports must be done after AISMessages import so that pyais patches are applied
from pyais import TagBlock
from holado_test.behave.behave import *  # @UnusedWildImport
from holado_value.common.tables.converters.value_table_converter import ValueTableConverter

logger = logging.getLogger(__name__)


def __get_scenario_context():
    return SessionContext.instance().get_scenario_context()

def __get_text_interpreter():
    return __get_scenario_context().get_text_interpreter()

def __get_variable_manager():
    return __get_scenario_context().get_variable_manager()



if AISMessages.is_available():
    @Step(r"add fields to AIS tag blocks")
    def step_impl(context):
        table = BehaveStepTools.get_step_table(context)
        fields = ValueTableConverter.convert_table_with_header_to_dict_list(table)

        for field in fields:
            TagBlock.add_field(field_name=field['Name'], field_code=field['Code'])


    @Step(r"(?P<var_name>{Variable}) = create AIS tag block string")
    def step_impl(context, var_name):
        var_name = StepTools.evaluate_variable_name(var_name)
        table = BehaveStepTools.get_step_table(context)
        kwargs = ValueTableConverter.convert_name_value_table_2_dict(table)

        res = TagBlock.create_str(**kwargs)

        __get_variable_manager().register_variable(var_name, res)


    @Step(r"(?P<var_name>{Variable}) = create AIS tag block object")
    def step_impl(context, var_name):
        var_name = StepTools.evaluate_variable_name(var_name)
        table = BehaveStepTools.get_step_table(context)
        fields = ValueTableConverter.convert_name_value_table_2_dict(table)

        res = TagBlock(None)
        res.init()
        for field_name, value in fields.items():
            res.set_field_value(field_name, value)

        __get_variable_manager().register_variable(var_name, res)


    @Step(r"(?P<var_name>{Variable}) = convert AIS tag block (?P<tag_block>{Variable}) to dict")
    def step_impl(context, var_name, tag_block):
        var_name = StepTools.evaluate_variable_name(var_name)
        tag_block = StepTools.evaluate_variable_value(tag_block)

        res = tag_block.asdict()

        __get_variable_manager().register_variable(var_name, res)


    


