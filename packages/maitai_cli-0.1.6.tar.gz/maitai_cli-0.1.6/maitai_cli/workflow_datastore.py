import json
import os
from pathlib import Path
from typing import Optional

import typer
import yaml
from maitai_cli.utils import console, get_client, handle_api_errors
from rich.progress import Progress, SpinnerColumn, TextColumn

workflow_app = typer.Typer(name="workflow", help="Manage workflows and datastores.")
datastore_app = typer.Typer(name="datastore", help="Manage workflow datastores.")
workflow_app.add_typer(datastore_app)


@datastore_app.command("schema")
@handle_api_errors
def update_schema(
    workflow_id: int = typer.Argument(..., help="Workflow ID"),
    name: str = typer.Argument(..., help="Datastore name"),
    schema_file: str = typer.Argument(..., help="Path to schema YAML/JSON file"),
):
    """Create or update a workflow datastore schema."""
    with open(schema_file, "r") as f:
        if schema_file.endswith(".json"):
            schema = json.load(f)
        else:
            schema = yaml.safe_load(f)

    client = get_client()
    response = client.post(
        f"/workflow/{workflow_id}/datastore/{name}", json={"schema": schema}
    )

    console.print(f"[green]Successfully updated schema for datastore '{name}'.[/green]")


@datastore_app.command("upload")
@handle_api_errors
def upload_data(
    workflow_id: int = typer.Argument(..., help="Workflow ID"),
    name: str = typer.Argument(..., help="Datastore name"),
    data_dir: Optional[str] = typer.Option(
        None, "--data-dir", help="Directory containing JSON records"
    ),
    s3_uri: Optional[str] = typer.Option(
        None, "--s3-uri", help="S3 URI containing JSON records (e.g. s3://bucket/path/)"
    ),
):
    """Upload records or link an S3 directory for a workflow datastore."""
    client = get_client()

    if s3_uri:
        console.print(f"Linking datastore '{name}' to S3 URI '{s3_uri}'...")
        response = client.post(
            f"/workflow/{workflow_id}/datastore/{name}/upload", json={"s3_uri": s3_uri}
        )
        console.print(f"[green]Successfully linked S3 URI to datastore.[/green]")
        console.print("To build the index, run the build_datastore_index.py script.")
        return

    if not data_dir:
        console.print("[red]Either --data-dir or --s3-uri must be provided[/red]")
        raise typer.Exit(1)

    data_path = Path(data_dir)
    json_files = list(data_path.glob("*.json"))

    if not json_files:
        console.print(f"[red]No JSON files found in {data_dir}[/red]")
        raise typer.Exit(1)

    console.print(f"Uploading {len(json_files)} files to datastore '{name}'...")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task(f"Uploading...", total=len(json_files))

        # Batch uploads would be better, but for MVP we upload them one by one or in small multipart batches
        batch_size = 10
        for i in range(0, len(json_files), batch_size):
            batch = json_files[i : i + batch_size]
            files = []
            for f in batch:
                files.append(("file", (f.name, open(f, "rb"), "application/json")))

            response = client.post(
                f"/workflow/{workflow_id}/datastore/{name}/upload", files=files
            )

            for _, f_tuple in files:
                f_tuple[1].close()

            if response.status_code != 200:
                console.print(
                    f"[red]Error uploading batch starting at {batch[0].name}:[/red] {response.text}"
                )
                raise typer.Exit(1)

            progress.update(task, advance=len(batch))

    console.print(f"[green]Successfully uploaded {len(json_files)} files.[/green]")

    # Normally we would trigger the build here
    console.print("To build the index, run the build_datastore_index.py script.")
