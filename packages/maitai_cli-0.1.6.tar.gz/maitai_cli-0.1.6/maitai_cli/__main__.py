"""Allow running as python -m maitai_cli."""

from maitai_cli.main import main

if __name__ == "__main__":
    main()
