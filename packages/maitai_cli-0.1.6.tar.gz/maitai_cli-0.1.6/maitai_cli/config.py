"""Configuration and authentication for the Maitai CLI."""

import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".maitai"
CONFIG_FILE = CONFIG_DIR / "config"
API_KEY_ENV = "MAITAI_API_KEY"
BASE_URL_ENV = "MAITAI_BASE_URL"
DEFAULT_BASE_URL = "https://api.trymaitai.ai/api/v1"


def get_config_dir() -> Path:
    """Return the config directory, creating it if needed."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


def get_api_key() -> str | None:
    """Get API key from environment or config file."""
    key = os.environ.get(API_KEY_ENV)
    if key:
        return key.strip()
    if CONFIG_FILE.exists():
        try:
            content = CONFIG_FILE.read_text().strip()
            for line in content.splitlines():
                line = line.strip()
                if line.startswith("api_key="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
                if line.startswith("MAITAI_API_KEY="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
        except OSError:
            pass
    return None


def get_base_url() -> str:
    """Get base URL from environment or config file."""
    url = os.environ.get(BASE_URL_ENV)
    if url:
        return url.strip().rstrip("/")
    if CONFIG_FILE.exists():
        try:
            content = CONFIG_FILE.read_text().strip()
            for line in content.splitlines():
                line = line.strip()
                if line.startswith("base_url="):
                    return (
                        line.split("=", 1)[1].strip().strip('"').strip("'").rstrip("/")
                    )
                if line.startswith("MAITAI_BASE_URL="):
                    return (
                        line.split("=", 1)[1].strip().strip('"').strip("'").rstrip("/")
                    )
        except OSError:
            pass
    return DEFAULT_BASE_URL


def save_config(api_key: str, base_url: str | None = None) -> None:
    """Save API key and optional base URL to config file."""
    get_config_dir()
    url = base_url or get_base_url()
    content = f"api_key={api_key}\nbase_url={url}\n"
    CONFIG_FILE.write_text(content)
    # Restrict permissions
    os.chmod(CONFIG_FILE, 0o600)


def clear_config() -> None:
    """Remove stored credentials."""
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
