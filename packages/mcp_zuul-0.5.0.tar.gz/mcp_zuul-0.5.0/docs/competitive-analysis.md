# MCP Servers Competitive Analysis - CI/CD/DevOps Landscape

**Date**: 2026-03-24
**Scope**: 50+ MCP servers across CI/CD, SCM, DevOps infrastructure, and monitoring
**Purpose**: Identify best practices and feature gaps for mcp-zuul

---

## Executive Summary

Researched 50+ MCP servers across the CI/CD/DevOps ecosystem. mcp-zuul is well-positioned - it's the **only Zuul CI MCP server**, has strong security hardening, and competitive tool count (36). However, several patterns from top servers represent clear opportunities for improvement.

**Top 5 gaps to close** (ranked by impact):
1. **Progress notifications** for long-running operations (GitHub, Buildkite pattern)
2. **Cursor-based pagination** for list operations (MCP spec best practice)
3. **Health check tool** for deployment monitoring (universal pattern)
4. **Verbosity levels** on output (Buildkite Parquet, Bitbucket TOON format)
5. **More prompts** - workflow templates for common scenarios (Jenkins jankins has 6)

---

## Competitive Landscape

### CI/CD Platforms (Direct Competitors)

| Server | Tools | Stars | Lang | Transport | Official | Unique Feature |
|--------|-------|-------|------|-----------|----------|----------------|
| **GitHub MCP** | 48 | 28,185 | Go | stdio/HTTP | Yes | Dynamic toolsets, OAuth remote, i18n |
| **Azure DevOps** | 86 | 1,458 | TS | stdio/HTTP | Yes | 9 domain filtering, remote preview |
| **GitLab** | 87 | N/A | Py/Native | HTTP | Yes (18.6+) | Native integration, safe mode + dry run |
| **mcp-zuul** | **36** | **~15** | **Py** | **stdio/SSE/HTTP** | **N/A** | **Failure analysis, Kerberos, LogJuicer** |
| **Jenkins (kud)** | 25 | 102 | TS | stdio | No | Multi-instance, multi-auth |
| **Jenkins (jankins)** | 25 | ~20 | TS | stdio | No | Token optimization, 6 prompts |
| **CircleCI** | 15 | 80 | TS | stdio/Docker | Yes | AI prompt tools, cost optimization |
| **Buildkite** | 27 | 49 | Go | stdio/HTTP | Yes | Parquet log conversion, OAuth |
| **Harness** | 80+ | 30 | Go | stdio | Yes | 21 toolsets, chaos engineering |
| **ArgoCD** | 12 | 357 | TS | stdio/HTTP | Yes (Labs) | GitOps natural language |
| **Drone CI** | 2 | ~5 | TS | stdio | No | Minimal read-only |
| **Spinnaker** | 3 | 1 | TS | stdio | No | Auto-refresh context |

### SCM / Code Review

| Server | Tools | Stars | Unique Feature |
|--------|-------|-------|----------------|
| **GitHub MCP** | 48 | 28,185 | Copilot integration, scope filtering |
| **GitLab (zereight)** | 114 | ~500 | 11 toolsets, regex filtering |
| **GitLab (structured-world)** | 44 | ~50 | CQRS architecture, 18 entity types |
| **Bitbucket (aashari)** | 30+ | ~100 | TOON format (30-60% token reduction) |
| **Gerrit** | 3 | ~10 | Focused code review |
| **Phabricator** | 11 | ~5 | Smart review analysis |
| **Perforce** | 7 cats | ~5 | P4 code review |

### DevOps Infrastructure

| Server | Stars | Focus | Key Feature |
|--------|-------|-------|-------------|
| **Grafana MCP** | 2,600 | Observability | Dashboard search, Prometheus/Loki queries |
| **Sentry MCP** | 600 | Error tracking | AI root cause (Seer), OAuth |
| **Prometheus MCP** | 380 | Metrics | 18 read-only tools, multi-tenant |
| **kubectl-mcp** | ~300 | K8s | Natural language cluster ops |
| **k8m** | ~200 | K8s multi-cluster | 50+ tools, multi-cluster |
| **Datadog MCP** | ~150 | Full observability | Metrics + logs + traces unified |
| **Terraform MCP** | ~100 | IaC | Plan/apply with approval gates |
| **Dynatrace MCP** | ~50 | APM | AI-powered performance insights |

---

## Pattern Analysis

### 1. Tool Organization & Filtering

**What leaders do:**
- **GitHub**: Dynamic toolsets loaded on-demand (96% token reduction). `--toolsets builds,pipelines` loads only subsets. `--dynamic-toolsets` lets LLM request tools as needed.
- **Azure DevOps**: 9 domain categories (`-d pipelines,repos`). Only loads relevant tools.
- **Harness**: 21 toolsets from CI/CD to chaos engineering to cost management.
- **GitLab (zereight)**: 11 toolsets with regex-based filtering.

**mcp-zuul status**: Has `ZUUL_ENABLED_TOOLS` / `ZUUL_DISABLED_TOOLS` env vars. This is functional but not as ergonomic as named toolsets.

**Gap**: Named toolset groups (e.g., `builds`, `logs`, `status`, `config`, `write`) would improve UX and documentation.

---

### 2. Token Optimization

**What leaders do:**
- **Buildkite**: Converts logs to **Parquet format** for LLM consumption. Caches transformed logs.
- **Bitbucket (aashari)**: **TOON format** - Token-Optimized Output Notation reduces tokens 30-60%.
- **Jenkins (jankins)**: Default summaries with `detail=full` option. Byte-offset pagination for logs. Token estimates in responses.
- **CircleCI**: `MAX_MCP_OUTPUT_LENGTH` env var for output limiting.
- **All top servers**: Strip None values, smart truncation, limit defaults.

**mcp-zuul status**: Has `clean()`, `smart_truncate()`, limit defaults (200 for list ops), streaming caps (10MB/20MB). Good foundation.

**Gap**: No verbosity levels (summary vs full). No token estimates in responses. No output size env var override.

---

### 3. Log Processing

**What leaders do:**
- **Buildkite**: Parquet conversion for AI consumption. Logs Search & Query Library.
- **Jenkins (enterprise)**: Vector search with Qdrant. 10GB logs searchable in 30s. Sub-build hierarchy.
- **Jenkins (karadHub)**: YAML-configurable error patterns (externalized classifier).
- **kubectl-mcp**: Streams pod logs with follow mode.

**mcp-zuul status**: Has `grep_log_context()`, `stream_log()` with caps, `_parse_playbooks()` for job-output.json. LogJuicer for ML anomaly detection. This is actually **industry-leading**.

**Gap**: Error patterns in `classifier.py` are hardcoded. Could externalize to YAML/JSON config for user customization. Consider progressive log retrieval (byte-offset pagination) instead of full loads.

---

### 4. Authentication Patterns

**What leaders do:**
- **GitHub**: OAuth 2.0 remote MCP via `api.githubcopilot.com/mcp/`. Auto-refreshing tokens.
- **Azure DevOps**: Browser-based OAuth with Entra policies. Remote server at `mcp.dev.azure.com`.
- **Buildkite**: OAuth flow with 12-hour tokens, 7-day refresh.
- **Jenkins (kud)**: Multi-auth (Bearer/Basic/OAuth) with multi-instance support + tool prefixes.
- **GitLab**: PAT + OAuth, native integration in 18.6+.

**mcp-zuul status**: Kerberos/SPNEGO (enterprise SSO), `_BearerAuth` with cross-origin protection, `asyncio.Lock` for concurrent auth. This is **strong and unique**.

**Gap**: No OAuth 2.0 flow for remote MCP deployment. As remote MCP becomes standard, this may matter.

---

### 5. Safety & Read-Only Modes

**What leaders do:**
- **GitHub**: `--read-only` flag + lockdown mode (restrict public repos to collaborators).
- **GitLab**: `SAFE_MODE=true` + `DRY_RUN=true` + project allowlist + rate limiting (60 req/min).
- **ArgoCD**: `MCP_READ_ONLY=true`.
- **All major servers**: Tool annotations (`readOnlyHint`, `destructiveHint`, `idempotentHint`).

**mcp-zuul status**: `ZUUL_READ_ONLY=true` (default), tool annotations on all tools. **On par with leaders**.

**Gap**: No dry-run mode. No project/tenant allowlist. No rate limiting.

---

### 6. Prompts & Resources

**What leaders do:**
- **Jenkins (jankins)**: 6 prompts - debug build, pipeline status, test analysis, deployment review, security audit, performance review.
- **CircleCI**: AI prompt template creation/testing tools (meta-prompts).
- **GitLab (poly-mcp)**: ADR (Architecture Decision Record) generation.
- **GitHub**: 48 tools across 18 toolsets with comprehensive coverage.

**mcp-zuul status**: 3 prompts (`debug_build`, `compare_builds`, `check_change`), 3 resources (`zuul://` URI scheme). Functional but limited.

**Gap**: Could add prompts for: pipeline status overview, flaky job analysis, node pool health, tenant health check, job configuration review. Resources could expose tenant lists, pipeline summaries.

---

### 7. Progress & Streaming

**What leaders do:**
- **MCP spec**: `progressToken` for long-running operations. `notifications/progress` messages.
- **Buildkite**: `wait_for_build` tool with polling.
- **Spinnaker**: Auto-refresh context every 30 seconds.
- **GitHub/Azure DevOps**: Streamable HTTP transport (2026-03-26 spec).

**mcp-zuul status**: Supports streamable-http transport. No progress notifications.

**Gap**: `list_buildsets` (concurrent fetches with semaphore), `diagnose_build` (multi-step analysis), and `find_flaky_jobs` (history scan) would benefit from progress notifications.

---

### 8. Pagination

**What leaders do:**
- **MCP spec**: Cursor-based pagination (opaque cursors, `nextCursor: null` = done).
- **Supported on**: `resources/list`, `resources/read`, `resources/templates/list`.
- **GitHub**: Pagination on all list operations.
- **Azure DevOps**: Standard pagination across 86 tools.

**mcp-zuul status**: Uses `limit` parameter on list operations but no cursor-based pagination. Results are truncated, not paginated.

**Gap**: `list_builds`, `list_buildsets`, `list_jobs`, `list_projects` should support cursor-based pagination for large result sets.

---

### 9. Monitoring & Observability

**What leaders do:**
- **Best practice**: Health check endpoints, structured stderr logging, OpenTelemetry integration.
- **Buildkite**: Container-first with health checks.
- **Prometheus MCP**: 18 read-only tools wrapping Prometheus HTTP API.
- **Grafana MCP**: Dashboard search, datasource queries, incident investigation.
- **Industry concern**: MCP servers create observability blind spots - no `/metrics`, no structured logs, no tracing.

**mcp-zuul status**: No health check tool. No structured logging. No metrics export.

**Gap**: Add a `health_check` tool (verify API connectivity, auth, tenant availability). Add structured stderr logging with correlation IDs.

---

### 10. Deployment & Distribution

**What leaders do:**
- **GitHub**: One-click VS Code install buttons. Remote OAuth MCP server.
- **Azure DevOps**: Remote server at `mcp.dev.azure.com`. VS 2026 built-in.
- **CircleCI**: NPX + Docker + self-managed options.
- **Buildkite**: Hosted remote (recommended) + local. chainguard minimal image.
- **Harness V2**: `npx harness-mcp-v2` (zero install).

**mcp-zuul status**: PyPI (`mcp-zuul`), Docker (`ghcr.io/imatza-rh/mcp-zuul`), stdio/SSE/streamable-http. **Good coverage**.

**Gap**: No one-click IDE install buttons. No hosted remote option.

---

### 11. Testing Patterns

**What leaders do:**
- **FastMCP pattern**: `Client(server)` for in-process testing.
- **respx**: HTTP mocking at transport level (not tool level).
- **Chaos engineering**: Test failure scenarios (API timeouts, network partitions, auth failures).
- **Load testing**: >1000 req/s throughput targets.

**mcp-zuul status**: pytest-asyncio + respx, factory functions, 89% coverage. **Strong**.

**Gap**: No chaos engineering tests. No load tests.

---

### 12. Innovative Features We Don't Have

| Feature | Server | Description | Relevance to Zuul |
|---------|--------|-------------|-------------------|
| **Cost optimization** | CircleCI | `find_underused_resource_classes`, usage analysis | Node utilization analysis |
| **AI prompt engineering** | CircleCI | Template creation/testing tools | Meta-prompts for Zuul workflows |
| **Chaos engineering** | Harness | Chaos tools integrated with CI | N/A (out of scope) |
| **ADR generation** | GitLab | Architecture Decision Records from code | Config change documentation |
| **Copilot integration** | GitHub | `assign_copilot_to_issue`, `request_copilot_review` | N/A (platform-specific) |
| **Vector search** | Jenkins (enterprise) | Qdrant-based semantic log search | Similar failure detection |
| **Multi-instance routing** | Jenkins (kud) | Single server, multiple instances with prefixes | Multi-Zuul deployment support |
| **Configurable diagnostics** | Jenkins (karadHub) | YAML-driven error patterns | Externalize classifier.py |
| **Batch operations** | Jenkins (AshwiniGhuge) | batch_enqueue, batch operations | batch_enqueue, batch_autohold |
| **Diff analysis** | CircleCI | `analyze_diff` against rules | Config diff analysis |
| **Smart file truncation** | Bitbucket | First 60% + last 40% for large files | Apply to log viewing |
| **Connection pooling** | GitLab (zereight) | Dynamic API URL with connection reuse | Already using httpx clients |
| **Dry run mode** | GitLab | Simulate operations without executing | Dry run for write tools |

---

## Recommendations

### Tier 1: Quick Wins (High Impact, Low Effort)

1. **Health check tool** - New tool that verifies API connectivity, auth status, default tenant availability. Universal pattern across all major servers.

2. **More prompts** - Add 3-4 workflow prompts:
   - `review_pipeline` - Pipeline status overview with recommendations
   - `analyze_flaky_job` - Deep flaky job investigation template
   - `review_job_config` - Job configuration review and optimization
   - `tenant_health` - Overall tenant health assessment

3. **Named toolset documentation** - Document logical tool groups in README for users configuring `ZUUL_ENABLED_TOOLS`:
   - `builds`: list_builds, get_build, get_build_failures, diagnose_build, get_buildset, get_build_log
   - `status`: list_tenants, get_status, get_change_status, find_flaky_jobs
   - `config`: list_jobs, get_job, get_project, list_pipelines, list_nodes, get_freeze_jobs
   - `write`: enqueue, dequeue, autohold_create, autohold_delete

4. **Output size control** - `ZUUL_MAX_OUTPUT_LENGTH` env var (like CircleCI's `MAX_MCP_OUTPUT_LENGTH`).

### Tier 2: Medium Effort, High Value

5. **Progress notifications** - Add `progressToken` support for `list_buildsets`, `diagnose_build`, `find_flaky_jobs`. Shows real-time progress during multi-step operations.

6. **Verbosity levels** - `verbosity` parameter on key tools (`summary` default, `full` for complete data). Could reduce token usage 40-60% for routine queries.

7. **Externalize error patterns** - Move `classifier.py` patterns to a YAML/JSON config file. Users can add custom patterns without code changes.

8. **Cursor-based pagination** - Implement on `list_builds`, `list_buildsets`, `list_jobs`, `list_projects`. MCP spec native feature.

9. **Dry run mode** - `ZUUL_DRY_RUN=true` for write tools. Simulates enqueue/dequeue without executing.

### Tier 3: Strategic (Longer Term)

10. **Structured logging** - JSON stderr logging with correlation IDs. Essential for production deployments and debugging.

11. **More resources** - Dynamic resources for:
    - `zuul://{tenant}/status` - Live pipeline status
    - `zuul://{tenant}/tenants` - Available tenants list
    - `zuul://{tenant}/pipeline/{pipeline}` - Pipeline details

12. **Multi-instance support** - Single mcp-zuul server connecting to multiple Zuul deployments with tool prefixes (like Jenkins kud pattern).

13. **OAuth 2.0 flow** - For remote MCP deployment scenarios (following GitHub/Azure DevOps pattern).

14. **One-click IDE install** - VS Code extension marketplace entry or install button in README.

15. **Progressive log retrieval** - Byte-offset pagination for large logs instead of streaming full content. Request specific ranges.

---

## What mcp-zuul Already Does Better Than Most

1. **Structured failure analysis** - `_parse_playbooks()` with job-output.json parsing. No other CI MCP does this.
2. **ML anomaly detection** - LogJuicer integration. Unique in the ecosystem.
3. **Kerberos/SPNEGO auth** - Enterprise SSO. Only Gerrit MCPs come close.
4. **Dual client architecture** - Separate `client` (API) and `log_client` (logs) with token safety.
5. **Config errors tool** - Proactive Zuul config validation. No CI MCP equivalent.
6. **URL-based input** - 7 tools accept web URLs via `parse_zuul_url()`. GitHub MCP doesn't even do this.
7. **Failure classifier** - `INFRA_FLAKE` / `REAL_FAILURE` / `CONFIG_ERROR` / `UNKNOWN`. No peer has this.
8. **Security hardening** - `_BearerAuth` cross-origin protection, `asyncio.Lock` for auth, `defusedxml`, streaming caps, `safepath()`. Above industry average.
9. **Smart log grep** - `grep_log_context()` with configurable context windows. Better than raw log dumps.
10. **Multi-transport** - stdio/SSE/streamable-http. Matches GitHub and Buildkite.

---

## Sources

### CI/CD Platforms
- [GitHub MCP Server](https://github.com/github/github-mcp-server) (28,185 stars)
- [Azure DevOps MCP](https://github.com/microsoft/azure-devops-mcp) (1,458 stars)
- [CircleCI MCP](https://github.com/CircleCI-Public/mcp-server-circleci) (80 stars)
- [Buildkite MCP](https://github.com/buildkite/buildkite-mcp-server) (49 stars)
- [ArgoCD MCP](https://github.com/argoproj-labs/mcp-for-argocd) (357 stars)
- [Harness MCP](https://github.com/harness/mcp-server) (30 stars)
- [Jenkins MCP (kud)](https://github.com/kud/mcp-jenkins) (102 stars)
- [Drone CI MCP](https://github.com/madappa-sharath/drone-ci-mcp)
- [Spinnaker MCP](https://github.com/dion-hagan/mcp-server-spinnaker)
- [GitLab MCP Docs](https://docs.gitlab.com/user/gitlab_duo/model_context_protocol/mcp_server/)

### SCM / Code Review
- [GitLab MCP (zereight)](https://github.com/zereight/gitlab-mcp-server) (~500 stars)
- [Bitbucket MCP (aashari)](https://github.com/aashari/mcp-server-atlassian-bitbucket)
- [Phabricator MCP](https://github.com/search?q=mcp+phabricator)
- [Gerrit MCP](https://github.com/nicholasgasior/mcp-gerrit)

### DevOps Infrastructure
- [Grafana MCP](https://github.com/grafana/mcp-grafana) (2,600 stars)
- [Sentry MCP](https://github.com/getsentry/sentry-mcp) (600 stars)
- [Prometheus MCP](https://github.com/pab1it0/prometheus-mcp-server) (380 stars)
- [kubectl MCP](https://github.com/rohitg00/kubectl-mcp-server) (~300 stars)
- [Datadog MCP](https://github.com/search?q=datadog+mcp+server)
- [Terraform MCP](https://github.com/nwiizo/tfmcp)

### Best Practices & Registries
- [MCP Architecture Overview](https://modelcontextprotocol.io/docs/learn/architecture)
- [MCP Best Practices](https://modelcontextprotocol.info/docs/best-practices/)
- [Production-Ready MCP Guide](https://webmcpguide.com/articles/production-ready-mcp-servers-guide)
- [Tool Annotations as Risk Vocabulary](https://blog.modelcontextprotocol.io/posts/2026-03-16-tool-annotations/)
- [Token Optimization Strategies](https://tetrate.io/learn/ai/mcp/token-optimization-strategies)
- [Dynamic Tool Discovery](https://www.speakeasy.com/mcp/tool-design/dynamic-tool-discovery)
- [MCP Server Observability](https://zeo.org/resources/blog/mcp-server-observability-monitoring-testing-performance-metrics)
- [10 Best MCP for Platform Engineers](https://stackgen.com/blog/the-10-best-mcp-servers-for-platform-engineers-in-2026)
- [Awesome DevOps MCP Servers](https://github.com/rohitg00/awesome-devops-mcp-servers)
- [Best-of MCP Servers (ranked weekly)](https://github.com/tolkonepiu/best-of-mcp-servers)
- [MCP Registry](https://registry.modelcontextprotocol.io/)
- [Glama MCP Directory](https://glama.ai/mcp/servers)
- [Smithery](https://smithery.ai/)
- [PulseMCP](https://www.pulsemcp.com/servers)
- [Azure DevOps Remote MCP Preview](https://devblogs.microsoft.com/devops/azure-devops-remote-mcp-server-public-preview/)
- [MCP DevOps Guide 2026](https://www.cloudshipai.com/blog/mcp-servers-devops-complete-guide-2026)
- [K8s MCP Observability Gap](https://dev.to/stacklok/the-next-big-observability-gap-for-kubernetes-is-mcp-servers-421d)
