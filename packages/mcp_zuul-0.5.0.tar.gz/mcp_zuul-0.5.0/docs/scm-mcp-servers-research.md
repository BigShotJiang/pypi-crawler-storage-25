# Source Code Management & Code Review MCP Servers - Comprehensive Research

**Research Date:** 2026-03-24
**Scope:** All MCP servers for SCM platforms (GitLab, GitHub, Gerrit, Bitbucket, Azure DevOps, Perforce, Git, SVN, Mercurial)

---

## Executive Summary

This research identified **15+ distinct MCP server implementations** across 9 source control and code review platforms. The landscape is dominated by GitHub (28k stars) and GitLab (1.2k stars for community version), with emerging official servers from Microsoft (Azure DevOps), GitHub, GitLab, and Perforce.

**Key Findings:**
- **Tool Count Range:** 3-114 tools per server (GitLab zereight leads with 114)
- **Authentication:** OAuth 2.0/2.1, PAT tokens, Kerberos/SPNEGO, API keys
- **Architecture Patterns:** CQRS, toolset-based filtering, read-only modes, connection pooling
- **Transport Support:** stdio, SSE, HTTP/Streamable HTTP
- **Best Practices:** Rate limiting, pagination caps, safety modes, intelligent truncation

---

## 1. GitLab MCP Servers

### 1.1 Official GitLab MCP Server
**Repository:** https://docs.gitlab.com/user/gitlab_duo/model_context_protocol/
**Status:** Beta (changed from experiment in GitLab 18.6)
**Tool Count:** 15 tools

**Tools:**
1. get_mcp_server_version
2. create_issue
3. get_issue
4. create_merge_request
5. get_merge_request
6. get_merge_request_commits
7. get_merge_request_diffs
8. get_merge_request_pipelines
9. get_pipeline_jobs
10. manage_pipeline
11. create_workitem_note
12. get_workitem_notes
13. search
14. search_labels
15. semantic_code_search

**Architecture:**
- **Authentication:** OAuth 2.0 Dynamic Client Registration
- **Transport:** HTTP (recommended), stdio with mcp-remote
- **Endpoint:** `https://<gitlab.example.com>/api/v4/mcp`
- **MCP Protocol:** Supports 2025-03-26 and 2025-06-18 specifications

**Key Features:**
- Native GitLab integration (works with GitLab.com and self-managed)
- Direct API access without CLI dependencies
- Semantic code search capabilities
- Pipeline management and CI/CD inspection

---

### 1.2 zereight/gitlab-mcp
**Repository:** https://github.com/zereight/gitlab-mcp
**Stars:** 1,238
**Language:** TypeScript (75.2%), JavaScript (23.6%)
**Tool Count:** 114 tools across 11 toolsets

**Toolsets:**
- **merge_requests** (31 tools) - MR operations, notes, discussions, draft notes, threads
- **issues** (14 tools) - Issue CRUD, notes, links, discussions
- **repositories** (7 tools) - Search, create, file contents, push, fork, tree
- **branches** (4 tools) - Creation, commits, diffs
- **projects** (8 tools) - Project/namespace info, group projects, iterations
- **labels** (5 tools) - CRUD operations
- **pipelines** (19 tools) - Pipeline and job operations
- **milestones** (9 tools) - CRUD, issues, MRs, burndown
- **wiki** (5 tools) - Page CRUD
- **releases** (7 tools) - CRUD, evidence, asset downloads
- **users** (5 tools) - Info, events, markdown upload, attachments
- **execute_graphql** (requires explicit opt-in)

**Architecture:**
- **Authentication:** Personal Access Token, OAuth2 (browser-based with auto-refresh), Remote Authorization (per-session HTTP headers)
- **Transport:** stdio, SSE, Streamable HTTP
- **Connection Pooling:** Dynamic API URL support with connection pooling via `gitlab-client-pool.ts`
- **Error Handling:** Structured error responses
- **Pagination:** Configurable via `GITLAB_COMMIT_FILES_PER_PAGE`

**Key Features:**
- Most comprehensive GitLab MCP server (114 tools)
- Read-only mode support
- Project allowlisting (single or multiple)
- Tool filtering via regex patterns
- Toolset customization (enable specific sets or "all")
- File encoding options (text or base64)
- Session timeouts for remote authorization (1-86400 seconds)
- Security-first GraphQL exposure (kept outside default toolsets)
- Backward compatibility with legacy flags

**Best Practices:**
- GraphQL kept separate to prevent bypassing permission boundaries
- Composite tool selection: "(toolset tools) ∪ (GITLAB_TOOLS) ∪ (legacy overrides)"
- Dependency injection for testability

---

### 1.3 yoda-digital/mcp-gitlab-server
**Repository:** https://github.com/yoda-digital/mcp-gitlab-server
**Stars:** 42
**Language:** TypeScript
**Tool Count:** 86 tools

**Tool Categories:**
- Repository Operations (search, create, fork, archive)
- File Management (read, create, update, delete with branch support)
- Issue Tracking (create, list, filter, close with advanced search)
- Merge Requests (full lifecycle: create, review, approve, merge)
- CI/CD (pipeline listing, triggering, retrying, cancellation, job logs)
- Wiki Management (project and group wiki creation/updates with attachments)
- Member Administration (project and group member management)
- Labels & Milestones (complete CRUD)
- Protected Branches (full configuration support)
- Releases (creation and management)
- Activity Tracking (event monitoring, commit history, project activity)

**Architecture:**
- **Authentication:** GitLab Personal Access Token (PAT) via `GITLAB_PERSONAL_ACCESS_TOKEN`
- **Instance URL:** Configurable via `GITLAB_URL` (defaults to https://gitlab.com)
- **Transport:** stdio and Server-Sent Events (SSE)
- **Safety:** Read-only mode via `GITLAB_READ_ONLY` environment variable
- **Tech Stack:** TypeScript, npm-based, Vitest testing

**Unique Features:**
- Comprehensive protected branch CRUD operations
- Full release lifecycle management
- SSE transport alongside stdio
- Built-in read-only safety mode

**Roadmap:**
- Planned enterprise features: SAML/OAuth3 authentication, audit logging, compliance tools, Jira integration (target: March 2026)

---

### 1.4 poly-mcp/GitLab-MCP-Server
**Repository:** https://github.com/poly-mcp/GitLab-MCP-Server
**Stars:** 1
**Language:** Python
**Tool Count:** 18+ tools

**Tool Categories:**
1. **Merge Request Management** (6 tools): list_merge_requests, get_merge_request_details, create_merge_request, approve_merge_request, merge_merge_request, rebase_merge_request
2. **Pipeline & CI/CD** (7 tools): list_pipeline_jobs, get_job_log, analyze_failed_jobs, trigger_pipeline, retry_pipeline, cancel_pipeline, retry_failed_job
3. **Code & Search** (1 tool): search_code
4. **Architecture Documentation** (2 tools): create_adr_document, commit_adr_to_gitlab
5. **Cloud Deployment** (1 tool): deploy_to_cloud (AWS, Azure, GCP)

**Architecture:**
- **Authentication:** GitLab token via environment variables
- **Safety:** Safe Mode (blocks write operations by default), Dry Run capability, Project allowlist filtering
- **Rate Limiting:** 60 requests/minute
- **Error Handling:** Retry logic with configurable MAX_RETRIES
- **Dependencies:** FastAPI ≥0.104.0, Uvicorn ≥0.24.0, Aiohttp ≥3.9.0, PyYAML ≥6.0, Pydantic ≥2.0.0, PolyMCP 1.2.4

**Unique Features:**
- ADR (Architecture Decision Record) generation in Markdown
- Pipeline intelligence with fix suggestions for failed jobs
- Multi-client support (Cursor, ChatGPT, PolyMCP)
- Dual modes: stdio and HTTP server

**Best Practices:**
- Start with `SAFE_MODE=true` to explore safely
- Create tokens with minimal permissions (read_api, read_repository only)

---

## 2. GitHub MCP Servers

### 2.1 github/github-mcp-server (Official)
**Repository:** https://github.com/github/github-mcp-server
**Stars:** 28,185
**Language:** Go
**Tool Count:** 51 tools

**Complete Tool List:**
1. add_issue_comment
2. add_pull_request_review_comment_to_pending_review
3. assign_copilot_to_issue
4. create_and_submit_pull_request_review
5. create_branch
6. create_issue
7. create_or_update_file
8. create_pending_pull_request_review
9. create_pull_request
10. create_repository
11. delete_file
12. delete_pending_pull_request_review
13. dismiss_notification
14. fork_repository
15. get_code_scanning_alert
16. get_commit
17. get_file_contents
18. get_issue
19. get_issue_comments
20. get_me
21. get_notification_details
22. get_pull_request
23. get_pull_request_comments
24. get_pull_request_diff
25. get_pull_request_files
26. get_pull_request_reviews
27. get_pull_request_status
28. get_secret_scanning_alert
29. get_tag
30. list_branches
31. list_code_scanning_alerts
32. list_commits
33. list_issues
34. list_notifications
35. list_pull_requests
36. list_secret_scanning_alerts
37. list_tags
38. manage_notification_subscription
39. manage_repository_notification_subscription
40. mark_all_notifications_read
41. merge_pull_request
42. push_files
43. request_copilot_review
44. search_code
45. search_issues
46. search_repositories
47. search_users
48. submit_pending_pull_request_review
49. update_issue
50. update_pull_request
51. update_pull_request_branch

**Deployment Options:**
- **Remote Server:** Hosted at `https://api.githubcopilot.com/mcp/` (OAuth + PAT auth)
- **Local Server:** Docker image `ghcr.io/github/github-mcp-server` for GitHub Enterprise

**Architecture:**
- **Authentication:** OAuth (remote server), Personal Access Tokens, environment variables (`GITHUB_PERSONAL_ACCESS_TOKEN`)
- **Toolsets:** Logical groups (repos, issues, pull_requests, actions, code_security, discussions, teams, notifications)
- **Tool Selection:** `--toolsets` flag or `GITHUB_TOOLSETS` env var, fine-grained via `--tools` parameter
- **Security:** Token management via env vars, minimum permission scoping, separate tokens per environment

**Key Features:**
- Repository management and code analysis
- Issue and PR automation
- CI/CD workflow monitoring
- Security findings review (code scanning, secret scanning)
- Team collaboration features
- Copilot integration (assign_copilot_to_issue, request_copilot_review)

**Enterprise Support:**
- GitHub Enterprise Cloud (ghe.com) via remote server
- GitHub Enterprise Server via local deployment with `GITHUB_HOST` env var

**CLI Utilities:**
- `tool-search` command with TTY color support
- Insiders mode for early feature access

**Best Practices:**
- Binary builds via `go build` in `cmd/github-mcp-server`
- Workspace-level `.vscode/mcp.json` configuration sharing
- Token logout recovery guidance for Docker usage

---

### 2.2 @modelcontextprotocol/server-github (Deprecated)
**Repository:** Part of https://github.com/modelcontextprotocol/servers (81,902 stars)
**Status:** No longer supported, moved to github/github-mcp-server
**npm Package:** @modelcontextprotocol/server-github

**Features (Historical):**
- File operations
- Repository management
- Search functionality (code, issues/PRs, users)
- Automatic branch creation
- Batch operations (single-file and multi-file)
- PR branch updates (equivalent to GitHub's "Update branch" button)

---

## 3. Gerrit MCP Servers

### 3.1 cayirtepeomer/gerrit-code-review-mcp
**Repository:** https://github.com/cayirtepeomer/gerrit-code-review-mcp
**Stars:** 37
**Language:** Python
**Tool Count:** 3 tools

**Tools:**
1. **fetch_gerrit_change** - Retrieves complete change information including files, patch sets, diffs, review history
2. **fetch_patchset_diff** - Compares differences between two patchsets with optional file-specific filtering
3. **submit_gerrit_review** - Posts feedback, votes, inline/file-level comments to changes

**Architecture:**
- **Authentication:** HTTP digest authentication using Gerrit HTTP credentials via environment variables (`GERRIT_HOST`, `GERRIT_USER`, `GERRIT_HTTP_PASSWORD`)
- **TLS:** Supports certificate verification disabling and custom CA bundles via `GERRIT_SSL_VERIFY` and `GERRIT_CA_BUNDLE`
- **Error Handling:** Basic credential validation, curl testing recommended
- **Dependencies:** Python 3.10+ (3.11 recommended), MCP SDK (`mcp[cli]`), testcontainers-python, Docker (for integration tests)

**Key Features:**
- Complete change retrieval (project/branch info, author/reviewer details, comments, file modifications with diff content)
- Patchset comparison across review iterations
- Review submission with vote labels, custom notifications (NONE, OWNER, OWNER_REVIEWERS, ALL), structured comments
- File exclusion via regex patterns to prevent large files from infinite loops

**Unique Capabilities:**
- Smithery integration (one-command installation for Claude Desktop)
- Docker testing with containerized Gerrit instances
- Self-signed certificate support with custom CA bundles
- Flexible comment payloads (dictionaries with path, message, optional Gerrit fields)

**Best Practices:**
- Generate HTTP passwords from Gerrit Settings > HTTP Credentials
- Use hostname-only configuration (exclude https://)
- Implement file exclusion patterns for performance
- Validate authentication before troubleshooting other issues

---

### 3.2 Google's gerrit-mcp-server
**Repository:** https://gerrit.googlesource.com/gerrit-mcp-server/
**Status:** Not an officially supported Google product

**Features:**
- Query changes
- Retrieve details
- Manage reviews via curl commands against Gerrit REST API
- Python 3.10+ required
- Gerrit HTTP access credentials needed

---

### 3.3 @hicho-lge/gerrit-mcp-server (npm)
**Package:** @hicho-lge/gerrit-mcp-server v1.1.4
**Status:** Package removed from npm registry
**Description:** MCP Server for Gerrit Code Review System with GitHub Copilot Integration

---

## 4. Bitbucket MCP Servers

### 4.1 MatanYemini/bitbucket-mcp
**Repository:** https://github.com/MatanYemini/bitbucket-mcp
**Stars:** 109
**Language:** TypeScript/JavaScript
**Tool Count:** 30+ tools

**Tool Categories:**

1. **Repository Operations** (2 tools):
   - listRepositories (with optional name filtering)
   - getRepository

2. **Pull Request Operations** (13 tools):
   - getPullRequests, getPullRequest
   - createPullRequest, createDraftPullRequest
   - updatePullRequest
   - approvePullRequest, unapprovePullRequest
   - requestChanges, removeChangeRequest
   - declinePullRequest, mergePullRequest
   - publishDraftPullRequest, convertTodraft
   - getPullRequestActivity

3. **Pull Request Comments** (1+ tools):
   - getPullRequestComments

**Architecture:**
- **Authentication:** Dual credential modes - BITBUCKET_TOKEN or both BITBUCKET_USERNAME and BITBUCKET_PASSWORD; API Key support for Atlassian authentication
- **Pagination:** Flexible with safety caps - optional `pagelen` (items per page, capped at 100), optional `page` parameter (1-based), `all` flag auto-follows pagination until 1,000 entry safety limit
- **Error Handling:** Troubleshooting guides for 401 authentication errors
- **Configuration:** 8 environment variables (BITBUCKET_URL, WORKSPACE, USERNAME, PASSWORD, TOKEN, BITBUCKET_ENABLE_DANGEROUS, logging controls)

**Key Features:**
- Draft PR support (create and publish)
- Comprehensive review actions (approve, decline, request changes)
- Activity tracking for PR audit trails
- Flexible merge strategies (merge-commit, squash, fast-forward)
- Reviewer management (assign multiple reviewers during PR creation)

**Security & Quality:**
- Read-only by default (no DELETE functionality)
- CodeQL analysis on all PRs
- MIT License
- Docker support

**Unique Capabilities:**
- Automatic workspace extraction from URLs (legacy-compatible configuration)
- 109 stars, 65 forks indicating community adoption

---

### 4.2 aashari/mcp-server-atlassian-bitbucket
**Repository:** https://github.com/aashari/mcp-server-atlassian-bitbucket
**Stars:** 132
**Language:** Node.js/TypeScript
**Tool Count:** 6 tools

**Tools:**
1. **bb_get** - Retrieve data from Bitbucket API endpoints
2. **bb_post** - Create resources via POST requests
3. **bb_put** - Replace resources via PUT requests
4. **bb_patch** - Perform partial updates
5. **bb_delete** - Remove resources
6. **bb_clone** - Clone repositories locally

**Architecture:**
- **Authentication:** Scoped API Tokens (recommended, future-proof), Legacy App Passwords (deprecated by June 2026)
- **Output Formats:** TOON (Token-Oriented Object Notation, reduces tokens 30-60% vs JSON), JSON format available
- **Filtering:** JMESPath filtering for response transformation, query parameter support for server-side filtering, sparse fieldsets via `fields` parameter
- **Pagination:** Built-in via query parameters
- **Caching:** Dashboard indexeddb caching mentioned

**API Coverage:**
- Bitbucket Cloud REST API 2.0 (not Server/Data Center)
- Workspaces and repositories
- Pull request management
- Branch operations
- Commit history
- File content access
- Issues and downloads

**Dependencies:**
- Node.js 18.0.0 or higher

**Unique Capabilities:**
- TOON format for token efficiency
- Repository cloning directly from AI context
- JMESPath filtering for minimizing token usage
- Multi-client support (Claude Desktop, Cursor, Continue.dev, Cline)
- Configuration file support

---

### 4.3 garc33/bitbucket-server-mcp-server
**Repository:** https://github.com/garc33/bitbucket-server-mcp-server
**Stars:** 57
**Language:** Node.js/TypeScript
**Tool Count:** 24 tools

**Tools:**

**Project & Repository Management:**
- list_projects, list_repositories

**Pull Request Operations:**
- create_pull_request, get_pull_request, merge_pull_request, decline_pull_request
- list_pull_requests, approve_pull_request, unapprove_pull_request

**Code Review & Comments:**
- add_comment, get_comments, get_reviews, get_activities, get_diff

**Branch Management:**
- list_branches, delete_branch, list_commits

**File & Code Operations:**
- get_file_content, browse_repository, search

**Architecture:**
- **Authentication:** API-based with custom header support via `BITBUCKET_CUSTOM_HEADERS` (useful for Zero Trust tokens or proxies)
- **Pagination:** All list operations support `limit` and `start` parameters (defaults typically 25 items, max 1000)
- **Error Handling:** Safety checks (prevents deletion of default branches)
- **Filtering:** Supports state filtering (OPEN/MERGED/DECLINED), author filtering, direction filtering (INCOMING/OUTGOING)

**Key Features:**
- Custom HTTP headers for Zero Trust environments
- Advanced search (project/repository filtering, query optimization, searches both file contents and filenames)
- Large file handling via intelligent pagination (first 60% from beginning, last 40% from end for truncated files)
- Flexible configuration (default project optional, specify per-command or via `BITBUCKET_DEFAULT_PROJECT`)

**Unique Capabilities:**
- Diff context control (configurable context lines and per-file truncation limits)
- Activity timeline distinction (separate tools for comprehensive activities vs comment-only)
- Search optimization ("file" type wraps queries in quotes for exact filename matching)
- Merge strategy options (merge-commit, squash, fast-forward)

**Dependencies:**
- Node.js >= 16
- Bitbucket Server API access (specifically for Bitbucket Server, not Cloud)

---

## 5. Azure DevOps MCP Server

### 5.1 microsoft/azure-devops-mcp (Official)
**Repository:** https://github.com/microsoft/azure-devops-mcp
**Stars:** 1,458
**Language:** TypeScript
**Tool Count:** Multiple tools across 9 domains

**Domains:**
- core
- work
- work-items
- search
- test-plans
- repositories
- wiki
- pipelines
- advanced-security

**Example Capabilities:**
- List projects, builds, repos, test plans, teams, iterations, work items
- Wiki CRUD operations
- CI/CD pipeline management
- Advanced security features

**Architecture:**
- **Authentication:** Browser-based OAuth flow (Microsoft accounts, credentials must match Azure DevOps organization)
- **API Design:** Thin abstraction layer over REST APIs for simplicity and focused tool design
- **Domain Filtering:** `-d` argument loads only needed tool groups, respecting client tool limits
- **Pagination & Caching:** Dashboard indexedDB caching, standard REST API pagination

**Key Features:**
- Multi-tool integration (VS Code, Claude Code, Cursor, Opencode, Kilocode, Visual Studio 2022)
- Agent Mode (GitHub Copilot Agent Mode support for intelligent tool selection)
- Wiki operations (create, update, retrieve wiki pages with path-based organization)
- Remote alternative (public preview remote server available, local version being phased out)

**Dependencies:**
- Node.js 20+
- VS Code or VS Code Insiders
- npm/npx for installation via `@azure-devops/mcp`
- Nightly builds via `@azure-devops/mcp@next`

**Unique Capabilities:**
- Deliberate simplicity ("concise, simple, focused, easy to use" tools)
- Dynamic domain loading (customize toolset per project to manage cognitive load)
- Copilot Instructions Integration (`.github/copilot-instructions.md` guidance)
- Migration path to remote server for future-proofing

**Best Practices:**
- Enable `core` domain always for project-level information
- Create `.github/copilot-instructions.md` noting Azure DevOps MCP availability
- Migrate to Remote MCP Server for continued feature investment
- Use browser-based authentication workflow on first execution

**License:** MIT
**Commits:** 458

---

## 6. Perforce P4 MCP Server

### 6.1 perforce/p4mcp-server (Community Supported)
**Repository:** https://github.com/perforce/p4mcp-server
**Status:** Community supported (not officially supported by Perforce)
**Language:** Python (FastMCP)
**Tool Count:** 6 primary tool categories with multiple actions each

**Tool Categories:**
1. **query_server** - Server diagnostics (server_info, current_user)
2. **query_workspaces** - Workspace management (list, get, type, status)
3. **query_changelists** - Changelist access (get, list)
4. **query_files** - File operations (content, history, info, metadata, diff, annotations)
5. **query_shelves** - Shelved changes (list, diff, files)
6. **query_jobs** - Job tracking (list_jobs, get_job)
7. **query_reviews** - Code reviews (list, dashboard, get, transitions)

**Architecture:**
- **Authentication:** P4 tickets (persistent), password-based, P4CONFIG file support
- **Environment Variables:** P4PORT (server address with SSL support), P4USER (username), P4CLIENT (workspace name), P4PASSWD (optional password)
- **Arguments:** `--readonly` (controls write operations), `--allow-usage` (enables usage statistics), `--toolsets` (specifies enabled tool categories)
- **Access Control:** Property-based restrictions with strict order of precedence (user-level overrides group-level, sequence numbering)

**Key Features:**
- Safety-first design (read-only mode by default, ownership checks, explicit confirmation for destructive deletes)
- Flexible configuration (selective toolset enablement)
- Cross-platform support (Windows 10+, macOS 12+, Ubuntu 20.04+)
- Optional telemetry (consent-gated, disabled by default)
- P4 Code Review support (version 2025.2+)

**Code Review Capabilities:**
- Discovery, voting, state transitions, commenting, participant management
- Recommend reviewers (based on file ownership, recent changes, file history)

**Deployment Options:**
1. Pre-built binaries (macOS, Windows)
2. Build from source (Python 3.11+)
3. Docker containers (Linux/macOS) with volume mounting for client roots

**Notable Capabilities:**
- File annotations with blame information
- Diff operations (depot-to-depot and mixed comparisons)
- Review state transitions and participant management
- Admin configuration via `p4 property` commands
- Workspace host restrictions management
- Pagination support via `max_results` parameters
- Global master switch via `mcp.enabled` property for administrators

**Dependencies:**
- Python 3.11+ (build only; pre-built binaries are standalone)
- P4 Server 2025.2+ (earlier versions untested)
- Docker (optional, for containerized deployment)

---

## 7. Phabricator MCP Server

### 7.1 YushengAuggie/phabricator-mcp-server
**Repository:** https://github.com/YushengAuggie/phabricator-mcp-server
**Language:** Python
**Tool Count:** 11 tools

**Tool Categories:**

**Task Management (3 tools):**
- get-task (retrieve comprehensive task details with comments)
- add-task-comment
- subscribe-to-task

**Code Review (8 tools):**
- get-differential (basic revision details)
- get-differential-detailed (comprehensive review with code changes)
- get-review-feedback (intelligent review analysis with code context)
- add-differential-comment (general review comments)
- add-inline-comment (targeted feedback to specific code lines)
- accept-differential (approve/accept revisions)
- request-changes-differential (request changes with optional feedback)
- subscribe-to-differential

**Architecture:**
- **Authentication:** Hybrid authentication with three-tier priority - (1) Personal API tokens via tool parameters, (2) Environment variables (PHABRICATOR_TOKEN, PHABRICATOR_URL), (3) Fallback .env file configuration
- **Transport:** HTTP/SSE (recommended) on port 8932, stdio for legacy support
- **Error Handling:** Graceful failure modes for API errors, argument validation
- **Testing:** Mock Phabricator implementation, pytest, coverage analysis

**Advanced Features:**

**Intelligent Code Analysis (`get-review-feedback`):**
- Comment-Code Correlation (links review feedback to specific code locations)
- Contextual code display with surrounding lines
- Action item categorization (Issues → Suggestions → Nits → Other)
- Priority classification
- Structured data: file references, target line numbers, hunk information, surrounding code context with line numbers

**Dependencies:**
- Python 3.8+
- Phabricator instance with API access
- FastMCP library
- Development tools: pytest, black/ruff, mypy

**Unique Capabilities:**
- Smart review analysis (correlates inline comments with surrounding code context automatically)
- Flexible authentication (supports both personal and shared tokens simultaneously)
- Comprehensive testing (tool completeness validation, integration testing, mock data support)
- Production-ready architecture (HTTP/SSE transport with automatic dependency management)

**Best Practices:**
- Follows "Standard MCP Integration" patterns
- MCP ecosystem best practices for authentication
- User attribution (comments appear under individual names, not shared service account)

---

## 8. Local Git MCP Servers

### 8.1 cyanheads/git-mcp-server
**Repository:** https://github.com/cyanheads/git-mcp-server
**Stars:** 199
**Language:** TypeScript
**Tool Count:** 28 git operations across 7 categories

**Tool Categories:**

1. **Repository Management** (4): git_init, git_clone, git_status, git_clean
2. **Staging & Commits** (3): git_add, git_commit, git_diff
3. **History & Inspection** (4): git_log, git_show, git_blame, git_reflog
4. **Analysis** (1): git_changelog_analyze
5. **Branching & Merging** (5): git_branch, git_checkout, git_merge, git_rebase, git_cherry_pick
6. **Remote Operations** (4): git_remote, git_fetch, git_pull, git_push
7. **Advanced Workflows** (7): git_tag, git_stash, git_reset, git_worktree, git_set_working_dir, git_clear_working_dir, git_wrapup_instructions

**Architecture:**
- **Authentication:** Supports none, JWT, and OAuth for deployments requiring access control
- **Error Handling:** Unified `McpError` system for consistent, structured error responses
- **Dependency Injection:** Built with tsyringe for testable, decoupled architecture
- **Response Formatting:** JSON (optimized for LLM) and markdown (for humans), configurable verbosity (minimal, standard, full)
- **Provider Architecture:** Pluggable provider system; currently CLI-based with planned isomorphic-git support for edge environments

**Key Features:**
- Cross-runtime support (auto-detects Bun or Node.js)
- Working directory management (session-specific repository context for multi-repo workflows)
- Commit signing (optional GPG/SSH signing across commits, merges, rebases, cherry-picks, tags)
- Safety mechanisms (destructive operations require explicit confirmation flags)
- Path sanitization (all file paths validated to prevent directory traversal)
- Configurable git identity (environment variable overrides with fallback to global config)

**Storage & Observability:**
- **Storage backends:** In-memory, filesystem, Supabase, Cloudflare KV/R2
- **Logging:** Structured via Pino with optional OpenTelemetry instrumentation for traces and metrics

**Technology Stack:**
- Runtime: TypeScript with Bun (v1.2.21+) or Node.js (v20+)
- MCP Spec: 2025-11-25 compliant
- License: Apache 2.0

**Unique Capabilities:**
- Session-scoped working directory via `git://working-directory` resource
- "Git Wrap-up" prompt for completing sessions (review, documentation, commit, tag workflows)
- Base directory restriction for multi-tenant sandboxing

---

### 8.2 @modelcontextprotocol/git (Reference)
**Repository:** Part of https://github.com/modelcontextprotocol/servers (81,902 stars)
**Status:** Early development, functionality subject to change
**npm Package:** @modelcontextprotocol/git

**Features:**
- Read, search, and manipulate Git repositories
- Commit filtering (start_timestamp/end_timestamp with ISO 8601, relative dates, absolute dates)
- Branch listing (local, remote, all) with commit SHA filtering
- Returns commit entries with hash, author, date, message

**Installation:**
- uvx to directly run mcp-server-git
- pip install mcp-server-git

---

## 9. SVN/Subversion MCP Server

### 9.1 gcorroto/mcp-svn
**Repository:** https://github.com/gcorroto/mcp-svn
**Stars:** 11
**Language:** TypeScript
**Tool Count:** 10+ core tools

**Tools:**

**Basic Operations:**
- svn_health_check (verify SVN system status)
- svn_info
- svn_status
- svn_log
- svn_diff

**Repository Operations:**
- svn_checkout (with depth/revision control)
- svn_update (with conflict resolution options)

**File Management:**
- svn_add
- svn_commit
- svn_delete
- svn_revert

**Maintenance:**
- svn_cleanup (recovery from interrupted operations)

**In Development:**
- Branch management
- Advanced operations (merge, switch, properties)
- Blame/conflict detection
- Batch operations

**Architecture:**
- **Authentication:** Environment variables (SVN_USERNAME, SVN_PASSWORD), optional inline credentials
- **Configuration:** SVN_PATH (executable location), SVN_WORKING_DIRECTORY (default context), SVN_TIMEOUT (30-second default)
- **Error Handling:** Conflict resolution strategies (postpone, base, mine-conflict, theirs-conflict, mine-full, theirs-full) during updates

**Dependencies:**
- Node.js ≥18.0.0
- Subversion (system-installed, CLI-based)
- TypeScript (development)

**Unique Capabilities:**
- Health check diagnostics for system validation
- Flexible revision targeting ("HEAD", "BASE", "COMMITTED", "PREV")
- Depth-controlled checkouts (empty, files, immediates, infinity)
- Multi-path batch operations for add/delete
- MCP protocol integration for AI agent compatibility

---

## 10. Mercurial (Hg) MCP Server

### 10.1 cwt/hg-mcp
**Repository:** https://github.com/cwt/hg-mcp
**Stars:** 0 (very new)
**Language:** Python
**Tool Count:** 40+ tools

**Tool Categories:**

**Core Commands (6):** hg_status, hg_log, hg_diff, hg_commit, hg_add, hg_remove

**Branch & Navigation (6):** hg_update, hg_branch, hg_bookmarks, hg_topic, hg_topics, hg_topic_current

**Remote Sync (3):** hg_push, hg_pull, hg_paths

**History Rewriting (5):** hg_rebase, hg_strip, hg_histedit, hg_evolve, hg_transplant

**Merge & Conflict (3):** hg_merge, hg_resolve, hg_revert

**Large Files (1):** hg_largefiles

**Configuration & Help (7):** hg_config, hg_extensions, hg_git, hg_help, hg_paths, hg_tags, hg_tag

**Repository Inspection (5):** hg_annotate, hg_files, hg_summary, hg_verify, hg_identify

**Patch & Remote Operations (5):** hg_export, hg_import, hg_heads, hg_incoming, hg_outgoing

**History Operations (1):** hg_backout

**Architecture:**
- **Authentication:** None (operates via local filesystem access to Mercurial repositories)
- **Error Handling:** "Smart error handling" with helpful messages and hints for missing extensions; automatic repository detection in subdirectories
- **Pagination:** Configurable history limits for viewing commit history; JSON output parsing for relevant commands
- **Caching:** Dashboard IndexedDB caching features

**Dependencies:**
- Python 3.10+
- Mercurial (system-level installation)
- AsyncIO framework
- Optional performance: uvloop (Unix/macOS), winloop (Windows)
- Poetry or pip/venv for package management

**Key Capabilities:**
- Extension detection (automatically identifies enabled Mercurial extensions, gracefully handles optional features)
- Async I/O (asynchronous command execution for responsive operations)
- JSON output (automatic JSON formatting for 20+ operations)
- Multi-client support (Claude Desktop, Qwen-Coder, Gemini-CLI, OpenCode)
- Repository validation (verifies Mercurial repository status and configuration integrity)

**Best Practices:**
- Isolated test fixtures with controlled extension configurations
- Comprehensive pytest test suite
- Code quality tools (linting, type checking, formatting scripts)
- Clear virtual environment setup documentation
- Configuration examples for multiple AI assistant platforms

---

## Architecture Pattern Comparison

### Authentication Methods

| Platform | Auth Methods | Notes |
|----------|-------------|-------|
| **GitLab** | PAT, OAuth2, OAuth 2.1, Remote Auth (HTTP headers) | OAuth with auto-refresh, session timeouts |
| **GitHub** | OAuth, PAT, env vars | Remote + local deployment options |
| **Gerrit** | HTTP Digest, Kerberos/SPNEGO | Custom CA bundle support |
| **Bitbucket** | API Tokens, App Passwords, API Keys | App Passwords deprecated June 2026 |
| **Azure DevOps** | Browser-based OAuth (Microsoft accounts) | Must match organization |
| **Perforce** | P4 tickets, password-based, P4CONFIG | SSL support |
| **Phabricator** | Personal API tokens, env vars, .env fallback | Hybrid three-tier priority |
| **Git (local)** | None, JWT, OAuth | For deployments requiring access control |
| **SVN** | Username/password via env vars | Optional inline credentials |
| **Mercurial** | None (local filesystem) | Repository-based access |

### Error Handling Patterns

| Server | Pattern | Details |
|--------|---------|---------|
| **zereight/gitlab-mcp** | Structured error responses | Standard API error handling |
| **github-mcp-server** | Clear error messages | Common issue troubleshooting |
| **gerrit-code-review-mcp** | Basic credential validation | curl testing recommended |
| **bitbucket-mcp** | Troubleshooting guides | 401 authentication errors |
| **git-mcp-server** | Unified McpError system | Consistent, structured errors |
| **poly-mcp/GitLab** | Retry logic | Configurable MAX_RETRIES |
| **mcp-svn** | Conflict resolution strategies | 6 resolution options |
| **hg-mcp** | Smart error handling | Helpful messages, extension hints |

### Pagination & Rate Limiting

| Server | Approach | Limits |
|--------|----------|--------|
| **bitbucket-mcp** | `pagelen`, `page`, `all` flag | 1,000 entry safety limit |
| **bitbucket-server-mcp** | `limit`, `start` | Default 25, max 1,000 |
| **poly-mcp/GitLab** | Rate limiting | 60 requests/minute |
| **p4mcp-server** | `max_results` parameter | Configurable per query |
| **git-mcp-server** | Timestamp filtering | ISO 8601, relative dates |
| **zereight/gitlab-mcp** | `GITLAB_COMMIT_FILES_PER_PAGE` | Configurable per instance |

### Transport Support

| Server | Transports | Notes |
|--------|-----------|-------|
| **zereight/gitlab-mcp** | stdio, SSE, Streamable HTTP | Connection pooling |
| **yoda-digital/mcp-gitlab** | stdio, SSE | Dual transport |
| **poly-mcp/GitLab** | stdio, HTTP | Dual modes |
| **github-mcp-server** | Remote (HTTPS), local (Docker) | Remote hosted by GitHub |
| **git-mcp-server** | stdio, HTTP | JWT/OAuth optional |
| **phabricator-mcp** | HTTP/SSE (port 8932), stdio | HTTP recommended |
| **azure-devops-mcp** | Multiple (VS Code, Claude, Cursor, etc.) | Multi-tool integration |

### Safety Features

| Server | Features |
|--------|----------|
| **yoda-digital/mcp-gitlab** | Read-only mode via `GITLAB_READ_ONLY` |
| **poly-mcp/GitLab** | Safe Mode (blocks writes by default), Dry Run, Project allowlist |
| **bitbucket-mcp** | Read-safe design (no DELETE), `BITBUCKET_ENABLE_DANGEROUS` flag |
| **p4mcp-server** | Read-only mode by default, ownership checks, explicit confirmation for destructive ops |
| **git-mcp-server** | Destructive operations require explicit confirmation flags, path sanitization |
| **bitbucket-server-mcp** | Prevents deletion of default branches |

### Unique Architecture Patterns

**CQRS Architecture (structured-world/gitlab-mcp):**
- 44 tools across 18 entity types
- Command Query Responsibility Segregation

**Toolset-Based Filtering (zereight/gitlab-mcp):**
- 11 toolsets with selective enablement
- Regex-based tool filtering
- Composite tool selection algorithm

**Connection Pooling (zereight/gitlab-mcp):**
- Dynamic API URL support
- `gitlab-client-pool.ts` for multi-instance management

**Provider Architecture (git-mcp-server):**
- Pluggable provider system
- CLI-based with planned isomorphic-git support

**Token-Oriented Notation (aashari/bitbucket-mcp):**
- TOON format reduces tokens 30-60% vs JSON
- JMESPath filtering for token minimization

**Dependency Injection (git-mcp-server):**
- tsyringe for testable, decoupled architecture

**Session-Scoped Resources (git-mcp-server):**
- `git://working-directory` resource for multi-repo workflows

**Property-Based Access Control (p4mcp-server):**
- Strict precedence order (user > group > sequence)
- Global master switch via `mcp.enabled`

---

## Best Practices Observed

### Authentication & Security

1. **Minimum Permission Scoping** (poly-mcp/GitLab)
   - Create tokens with minimal permissions (read_api, read_repository only)
   - Start with SAFE_MODE=true to explore safely

2. **Token Management** (github-mcp-server)
   - Use environment variables for token storage
   - Separate tokens per environment
   - File permission restrictions (chmod 600)

3. **Certificate Handling** (gerrit-code-review-mcp)
   - Support custom CA bundles
   - Keep verification enabled while trusting private CAs

4. **Multi-Tier Auth Fallback** (phabricator-mcp)
   - Personal API tokens → env vars → .env file
   - Enables user attribution vs shared service accounts

### Tool Design

1. **Deliberate Simplicity** (azure-devops-mcp)
   - Tools that are concise, simple, focused, easy to use
   - Avoid complex multi-purpose solutions

2. **Security-First GraphQL** (zereight/gitlab-mcp)
   - Keep GraphQL outside default toolsets
   - Prevent bypassing permission boundaries

3. **Intelligent Truncation** (bitbucket-server-mcp)
   - Large files: first 60% from beginning, last 40% from end
   - Prevents unbounded responses

4. **Smart Error Handling** (hg-mcp)
   - Helpful messages with extension hints
   - Automatic repository detection in subdirectories

### Token Efficiency

1. **TOON Format** (aashari/bitbucket-mcp)
   - Token-Oriented Object Notation reduces tokens 30-60%
   - JMESPath filtering for response transformation

2. **Sparse Fieldsets** (aashari/bitbucket-mcp)
   - `fields` parameter for selective data retrieval

3. **Configurable Verbosity** (git-mcp-server)
   - minimal, standard, full modes
   - JSON optimized for LLM, markdown for humans

### Safety & Validation

1. **Read-Only Defaults** (multiple servers)
   - yoda-digital/mcp-gitlab: `GITLAB_READ_ONLY`
   - poly-mcp/GitLab: `SAFE_MODE=true`
   - p4mcp-server: `--readonly` flag

2. **Explicit Confirmation** (git-mcp-server)
   - Destructive operations require confirmation flags
   - Path sanitization prevents directory traversal

3. **Safety Limits** (bitbucket-mcp)
   - Pagination auto-follows until 1,000 entry safety limit
   - Prevents unbounded memory usage

### Testing & Quality

1. **Comprehensive Testing** (phabricator-mcp)
   - Tool completeness validation
   - Integration testing
   - Mock data support

2. **Isolated Test Fixtures** (hg-mcp)
   - Controlled extension configurations
   - Comprehensive pytest test suite

3. **Docker Testing** (gerrit-code-review-mcp)
   - Containerized Gerrit instances for integration tests
   - testcontainers-python usage

### Developer Experience

1. **Health Check Diagnostics** (mcp-svn)
   - System validation before operations

2. **CLI Utilities** (github-mcp-server)
   - `tool-search` command with TTY color support

3. **Insiders Mode** (github-mcp-server, azure-devops-mcp)
   - Early feature access via URL path or header configuration

4. **Migration Paths** (azure-devops-mcp)
   - Explicit transition strategy toward remote server
   - Nightly builds for testing: `@azure-devops/mcp@next`

---

## Innovation Highlights

### Advanced Features

**Intelligent Review Analysis (phabricator-mcp):**
- Comment-Code Correlation linking feedback to specific locations
- Contextual code display with surrounding lines
- Action item categorization (Issues → Suggestions → Nits → Other)

**ADR Generation (poly-mcp/GitLab):**
- Automated Architecture Decision Record creation in Markdown
- Commit ADR directly to GitLab

**Pipeline Intelligence (poly-mcp/GitLab):**
- Suggests fixes for failed jobs with contextual analysis

**Copilot Integration (github-mcp-server):**
- assign_copilot_to_issue
- request_copilot_review
- Agent Mode for intelligent tool selection

**Git Wrap-up Prompt (git-mcp-server):**
- Session completion workflow
- Review, documentation, commit, tag automation

### Architectural Innovation

**Pluggable Provider System (git-mcp-server):**
- CLI-based with planned isomorphic-git for edge environments

**Multi-Transport with Connection Pooling (zereight/gitlab-mcp):**
- Dynamic API URL support
- Connection pooling via `gitlab-client-pool.ts`

**CQRS with 18 Entity Types (structured-world/gitlab-mcp):**
- Command Query Responsibility Segregation
- 44 tools across comprehensive entity model

**Storage Backends (git-mcp-server):**
- In-memory, filesystem, Supabase, Cloudflare KV/R2

**Observability (git-mcp-server):**
- Structured logging via Pino
- OpenTelemetry instrumentation for traces and metrics

---

## Comparison to mcp-zuul

**mcp-zuul Context:**
- 36 tools (31 read-only + 4 write + 1 LogJuicer)
- Zuul CI focus (builds, logs, pipelines, jobs, infrastructure)
- Published on PyPI, MCP Registry, Docker, Glama
- Competitive: only Zuul CI MCP server

**Relative Positioning:**

| Metric | mcp-zuul | SCM MCP Landscape |
|--------|----------|------------------|
| **Tool Count** | 36 | Range: 3-114 (median ~20-30) |
| **Stars** | N/A (new) | Range: 0-28,185 (GitHub official leads) |
| **Architecture** | FastMCP, Python, dual httpx clients, auth lock | Diverse: TypeScript/Python/Go, various patterns |
| **Transport** | stdio, SSE, streamable-http | stdio, SSE, HTTP most common |
| **Auth** | Kerberos/SPNEGO, bearer tokens, cross-origin safety | OAuth2, PAT tokens, digest auth dominate |
| **Safety** | Read-only mode, `@handle_errors`, streaming caps | Read-only modes common, explicit confirmation patterns |
| **Unique Features** | job-output.json parsing, grep fallback, LogJuicer ML | ADR generation, Copilot integration, TOON format, CQRS |

**Patterns mcp-zuul Could Adopt:**

1. **Toolset-Based Filtering** (from zereight/gitlab-mcp)
   - Group 36 tools into logical categories (builds, logs, status, config, write, tests, logjuicer)
   - Allow selective enablement via `ZUUL_TOOLSETS` (similar to existing `ZUUL_ENABLED_TOOLS`)

2. **Intelligent Truncation** (from bitbucket-server-mcp)
   - Already has `smart_truncate()` for logs
   - Could apply to large `job-output.json` responses (first 60% + last 40%)

3. **Verbosity Levels** (from git-mcp-server)
   - minimal (key fields only), standard (current), full (all data)
   - Reduce token usage for simple queries

4. **Health Check Tool** (from mcp-svn)
   - `check_zuul_health` to verify API connectivity, auth status, tenant availability

5. **CLI Utilities** (from github-mcp-server)
   - Tool search/discovery helper
   - Tenant discovery command

6. **Structured Error Categories** (from git-mcp-server)
   - Already has classifier.py (INFRA_FLAKE, REAL_FAILURE, CONFIG_ERROR, UNKNOWN)
   - Could expose as dedicated error type hierarchy

**Patterns mcp-zuul Already Uses Well:**

1. **Dual Client Safety** (unique to mcp-zuul)
   - Separate `client` (API + auth) and `log_client` (external hosts, no auth)
   - `_BearerAuth` strips tokens on cross-origin redirects
   - More sophisticated than most SCM servers

2. **Streaming with Caps** (similar to git-mcp-server storage backends)
   - `fetch_log_url()` streams up to 20 MB
   - `stream_log()` returns `(bytes, truncated_bool)` for caller warnings

3. **URL-Based Input** (ahead of most SCM servers)
   - 7 tools accept `url` param via `_resolve()` + `parse_zuul_url()`
   - Supports multi-tenant and single-tenant URL formats

4. **Read-Only Mode** (common pattern, well-implemented)
   - `ZUUL_READ_ONLY=true` default removes write tools at startup
   - Similar to poly-mcp/GitLab `SAFE_MODE`, p4mcp-server `--readonly`

5. **Tool Filtering** (similar to zereight/gitlab-mcp, github-mcp-server)
   - `ZUUL_ENABLED_TOOLS` / `ZUUL_DISABLED_TOOLS` (mutually exclusive)
   - Removes tools via `ToolManager.remove_tool()` at startup

**Unique mcp-zuul Strengths:**

1. **ML-Based Anomaly Detection** (LogJuicer integration)
   - No SCM server has equivalent intelligent log analysis
   - `log_client` isolation prevents token leakage

2. **Structured Failure Analysis** (job-output.json parsing)
   - `_parse_playbooks()` extracts playbook summaries + failed tasks
   - Smart fallback to text grep if JSON unavailable

3. **Security Hardening** (v0.3.2)
   - `asyncio.Lock` serializes Kerberos re-auth (prevents concurrent session corruption)
   - More sophisticated than most SCM servers

4. **CI-Specific Metadata** (infra failure tracking)
   - `find_flaky_jobs` tracks NODE_FAILURE, RETRY_LIMIT, TIMED_OUT, DISK_FULL separately
   - Unique to CI/CD domain

---

## Recommendations for mcp-zuul

### Short-Term (High Value, Low Effort)

1. **Add Toolset Grouping**
   - Categories: builds, logs, status, config, write, tests, logjuicer
   - Env var: `ZUUL_TOOLSETS=builds,logs,status` (default: all read-only)
   - Reduces cognitive load for LLMs with limited tool capacity

2. **Add Health Check Tool**
   - `check_zuul_health` - verify API connectivity, auth status, default tenant
   - Similar to mcp-svn `svn_health_check`

3. **Document Best Practices in README**
   - Start with `ZUUL_READ_ONLY=true`
   - Use `ZUUL_TOOLSETS` or `ZUUL_ENABLED_TOOLS` for focused workflows
   - Token scoping guidance (minimum permissions)

### Medium-Term (Moderate Effort)

1. **Verbosity Levels**
   - Add `ZUUL_VERBOSITY=minimal|standard|full` env var
   - minimal: key fields only (uuid, result, job_name, duration)
   - standard: current behavior
   - full: all data including raw job-output.json

2. **Intelligent Truncation for job-output.json**
   - Apply bitbucket-server-mcp pattern (first 60% + last 40%)
   - Warn users when truncated
   - Already have `smart_truncate()` for logs

3. **Response Format Options**
   - Add `ZUUL_FORMAT=json|markdown` (default: json)
   - Markdown for human readability (similar to git-mcp-server)

### Long-Term (Research/Exploration)

1. **Storage Backend for Build Cache**
   - Similar to git-mcp-server (in-memory, filesystem, Supabase, Cloudflare KV/R2)
   - Cache recent build metadata to reduce API calls
   - Configurable TTL

2. **OpenTelemetry Instrumentation**
   - Following git-mcp-server pattern
   - Traces and metrics for observability
   - Optional, disabled by default

3. **Multi-Zuul Support**
   - Connection pooling similar to zereight/gitlab-mcp `gitlab-client-pool.ts`
   - Support multiple Zuul instances in one server
   - `ZUUL_INSTANCES` JSON config

---

## Summary Tables

### Server Popularity (by Stars)

| Rank | Server | Stars | Platform |
|------|--------|-------|----------|
| 1 | github/github-mcp-server | 28,185 | GitHub |
| 2 | modelcontextprotocol/servers | 81,902 | Reference (multi-platform) |
| 3 | microsoft/azure-devops-mcp | 1,458 | Azure DevOps |
| 4 | zereight/gitlab-mcp | 1,238 | GitLab |
| 5 | cyanheads/git-mcp-server | 199 | Git (local) |
| 6 | aashari/mcp-server-atlassian-bitbucket | 132 | Bitbucket |
| 7 | MatanYemini/bitbucket-mcp | 109 | Bitbucket |
| 8 | garc33/bitbucket-server-mcp-server | 57 | Bitbucket Server |
| 9 | yoda-digital/mcp-gitlab-server | 42 | GitLab |
| 10 | cayirtepeomer/gerrit-code-review-mcp | 37 | Gerrit |
| 11 | gcorroto/mcp-svn | 11 | SVN |
| 12 | poly-mcp/GitLab-MCP-Server | 1 | GitLab |
| 13 | cwt/hg-mcp | 0 | Mercurial |

### Tool Count Comparison

| Server | Tool Count | Platform |
|--------|-----------|----------|
| zereight/gitlab-mcp | 114 | GitLab |
| yoda-digital/mcp-gitlab-server | 86 | GitLab |
| github-mcp-server | 51 | GitHub |
| hg-mcp | 40+ | Mercurial |
| MatanYemini/bitbucket-mcp | 30+ | Bitbucket |
| git-mcp-server | 28 | Git (local) |
| bitbucket-server-mcp-server | 24 | Bitbucket Server |
| poly-mcp/GitLab-MCP-Server | 18+ | GitLab |
| Official GitLab MCP | 15 | GitLab |
| phabricator-mcp-server | 11 | Phabricator |
| mcp-svn | 10+ | SVN |
| azure-devops-mcp | 9 domains | Azure DevOps |
| p4mcp-server | 7 categories | Perforce |
| aashari/mcp-bitbucket | 6 | Bitbucket |
| gerrit-code-review-mcp | 3 | Gerrit |

### Primary Language

| Language | Servers |
|----------|---------|
| **TypeScript/JavaScript** | zereight/gitlab-mcp, yoda-digital/mcp-gitlab-server, MatanYemini/bitbucket-mcp, aashari/mcp-bitbucket, bitbucket-server-mcp-server, git-mcp-server, mcp-svn, azure-devops-mcp |
| **Python** | poly-mcp/GitLab-MCP-Server, gerrit-code-review-mcp, phabricator-mcp-server, p4mcp-server, hg-mcp |
| **Go** | github-mcp-server |

### Authentication Complexity

| Complexity | Servers | Methods |
|------------|---------|---------|
| **High** | zereight/gitlab-mcp, github-mcp-server | OAuth2 + PAT + Remote Auth + Session Management |
| **Medium** | azure-devops-mcp, phabricator-mcp, gerrit-mcp | Browser OAuth, Three-tier fallback, HTTP Digest |
| **Low** | git-mcp-server, hg-mcp, mcp-svn | Optional (none/JWT/OAuth), Local filesystem, Username/password |

---

## Sources

### GitLab
- [GitLab MCP server | GitLab Docs](https://docs.gitlab.com/user/gitlab_duo/model_context_protocol/mcp_server/)
- [GitLab MCP server tools | GitLab Docs](https://docs.gitlab.com/user/gitlab_duo/model_context_protocol/mcp_server_tools/)
- [GitHub - zereight/gitlab-mcp](https://github.com/zereight/gitlab-mcp)
- [GitHub - yoda-digital/mcp-gitlab-server](https://github.com/yoda-digital/mcp-gitlab-server)
- [GitHub - poly-mcp/GitLab-MCP-Server](https://github.com/poly-mcp/GitLab-MCP-Server)

### GitHub
- [GitHub - github/github-mcp-server](https://github.com/github/github-mcp-server)
- [Using the GitHub MCP Server - GitHub Docs](https://docs.github.com/en/copilot/how-tos/provide-context/use-mcp/use-the-github-mcp-server)
- [List of all 51 MCP tools - GitHub Gist](https://gist.github.com/didier-durand/2970be82fec6c84d522f7953ac7881b4)
- [@modelcontextprotocol/server-github - npm](https://www.npmjs.com/package/@modelcontextprotocol/server-github)

### Gerrit
- [GitHub - cayirtepeomer/gerrit-code-review-mcp](https://github.com/cayirtepeomer/gerrit-code-review-mcp)
- [Gerrit Code Review MCP Server | PulseMCP](https://www.pulsemcp.com/servers/cayirtepeomer-gerrit-code-review)
- [gerrit-mcp-server - Git at Google](https://gerrit.googlesource.com/gerrit-mcp-server/)

### Bitbucket
- [GitHub - MatanYemini/bitbucket-mcp](https://github.com/MatanYemini/bitbucket-mcp)
- [GitHub - aashari/mcp-server-atlassian-bitbucket](https://github.com/aashari/mcp-server-atlassian-bitbucket)
- [GitHub - garc33/bitbucket-server-mcp-server](https://github.com/garc33/bitbucket-server-mcp-server)

### Azure DevOps
- [GitHub - microsoft/azure-devops-mcp](https://github.com/microsoft/azure-devops-mcp)
- [Enable AI assistance with the Azure DevOps MCP Server - Azure Boards](https://learn.microsoft.com/en-us/azure/devops/mcp-server/mcp-server-overview?view=azure-devops)

### Perforce
- [GitHub - perforce/p4mcp-server](https://github.com/perforce/p4mcp-server)
- [AI‑Driven Workflows with P4 MCP | Perforce Software](https://www.perforce.com/products/p4/p4-mcp)

### Phabricator
- [GitHub - YushengAuggie/phabricator-mcp-server](https://github.com/YushengAuggie/phabricator-mcp-server)

### Git (Local)
- [GitHub - cyanheads/git-mcp-server](https://github.com/cyanheads/git-mcp-server)
- [Git | Awesome MCP Servers](https://mcpservers.org/servers/modelcontextprotocol/git)

### SVN
- [GitHub - gcorroto/mcp-svn](https://github.com/gcorroto/mcp-svn)

### Mercurial
- [GitHub - cwt/hg-mcp](https://github.com/cwt/hg-mcp)

### General MCP Resources
- [GitHub - modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers)
- [The MCP Registry - Model Context Protocol](https://modelcontextprotocol.io/registry/about)
- [GitHub - punkpeye/awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers)
- [Awesome MCP Servers - mcp-awesome.com](https://mcp-awesome.com/)
