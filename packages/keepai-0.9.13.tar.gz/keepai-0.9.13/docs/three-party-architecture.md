# keep 三方系统架构图

`keep` 当前的核心三方是：

1. `Human`：定义 group 目标，做最终决策。
2. `Supervisor`：人的代理，负责拆任务、审输出、继续推进。
3. `Worker`：执行具体实现。

`Daemon`、`CLI`、`State`、`Terminal Backend` 是基础设施，不属于三方主体。`Reviewer` 是可选的外审通道，用于 task / group 关键节点的独立状态审查。

另外，`keep` 现在支持两种执行模式：

1. `workers_enabled=true`：Supervisor 协调真实 Worker，会使用 `supervisor send/read/wake`。
2. `workers_enabled=false`：Supervisor 不创建 Worker，改用 Agent tool 派 subagent 完成实现。

## 总览图

```mermaid
flowchart LR
    human["Human"]

    subgraph control["Control Plane"]
        cli["keep CLI<br/>group / task / supervisor / worker / reviewer"]
        daemon["keep Daemon<br/>poll + relay + review routing"]
        state["~/.keep State<br/>global.json / groups/*.json / tasks / messages / transcript / runtime"]
        signals["Signal Files<br/>stop-[session_id]<br/>group-sync / group-stop"]
    end

    subgraph runtime["Per-Group Runtime"]
        terminal["Terminal Container<br/>cmux / iTerm2 / tmux / kitty / Terminal.app"]
        sup["Supervisor Session"]
        worker["Worker Session(s)"]
        reviewer["Reviewer Session(s)<br/>(optional)"]
        hook["Stop Hook"]
    end

    human -->|"set group / decide final direction"| cli
    sup -->|"run keep commands"| cli
    cli <-->|"load / mutate group state"| state
    cli -->|"spawn session + inject bootstrap/contract"| terminal

    terminal --> sup
    terminal --> worker
    terminal --> reviewer

    sup -->|"supervisor send / read / wake"| worker
    sup -->|"ask for input only when needed"| human

    worker -->|"turn finished"| hook
    reviewer -->|"turn finished"| hook
    hook -->|"write stop payload"| signals

    daemon -->|"poll + consume"| signals
    daemon <-->|"persist runtime / transcript / messages"| state
    daemon -->|"stop / silent / idle event"| sup
    daemon -->|"review request / group sync"| reviewer
    daemon -->|"parse reviewer stop + settle review_result"| sup
```

## 主循环时序

```mermaid
sequenceDiagram
    autonumber
    participant H as Human
    participant C as keep CLI
    participant S as Supervisor
    participant W as Worker
    participant D as Daemon
    participant R as Reviewer
    participant ST as ~/.keep State

    H->>C: group create / task create
    C->>ST: persist group + task
    H->>C: supervisor create / worker create
    C->>S: bootstrap prompt + supervisor contract
    C->>W: bootstrap prompt + worker contract

    S->>C: supervisor send task file
    C->>W: deliver task message
    W-->>W: code / test / analyze
    W->>D: Stop hook produces stop signal
    D->>ST: append transcript + save worker output
    D->>S: keep event stop / silent / idle

    S->>C: read / send / wake / task update
    C->>ST: mutate task / group state

    opt reviewers enabled
        D->>R: review_request (task / group stop)
        R->>C: task update / group stop
        C->>ST: persist reviewer resource state
        D->>ST: aggregate resource states and settle workflow
    end

    S->>H: request new direction only when needed
```

## 设计边界

- 三方主链路是 `Human -> Supervisor -> Worker`。`keep` 的目标不是替代 Human，而是把 Human 从每一次实现细节里解放出来。
- `Daemon` 只做事件接力，不做业务决策。它负责 stop/silent/idle 检测、review 事件路由、group 同步。
- `Supervisor` 和 `Worker` 是同构 agent session，只是角色 contract 不同。
- `Supervisor` contract 现在按 `workers_enabled` 分叉：有 worker 模式走 worker 协调链路；无 worker 模式走 subagent 执行链路。
- `Reviewer` 不在主执行链路里；它只在关键 gate 上介入，提供独立外审，避免 Supervisor 自审自过。
- 每个 group 绑定一个 terminal container；同 group 下的 supervisor / reviewer / workers 共处同一个容器，只是 pane/tab 布局不同。

## 对应实现

- CLI / participant dispatch：`keep/cli.py`、`keep/_cli/dispatch_supervisor.py`、`keep/_cli/dispatch_worker.py`、`keep/_cli/dispatch_reviewer.py`
- Daemon facade / loop：`keep/daemon.py`、`keep/_daemon/loop.py`
- Stop / silent / notify / review routing：`keep/_daemon/worker_check.py`、`keep/_daemon/notify.py`、`keep/_daemon/review.py`
- State persistence：`keep/state.py`、`keep/_state/`
- 角色说明与运行语义：`README.md`
