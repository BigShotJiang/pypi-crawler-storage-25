from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from keep._state.participants import (
    ReviewerParticipant,
    SupervisorParticipant,
    WorkerParticipant,
    participant_jsonl_path,
    participant_last_message,
    participant_model,
    participant_ready,
    participant_target_id,
    participant_thread_id,
)


def test_participant_model_resolves_role_subclass() -> None:
    assert isinstance(participant_model({"session": "s1", "role": "supervisor"}), SupervisorParticipant)
    assert isinstance(participant_model({"session": "w1", "role": "worker"}), WorkerParticipant)
    assert isinstance(participant_model({"session": "r1", "role": "reviewer"}), ReviewerParticipant)


def test_participant_accessors_read_cache_fields() -> None:
    participant = {
        "session": "r1",
        "role": "reviewer",
        "cache": {
            "target_id": "surface-1",
            "jsonl_path": "/tmp/demo.jsonl",
            "thread_id": "thread-1",
        },
    }

    assert participant_target_id(participant) == "surface-1"
    assert participant_jsonl_path(participant) == Path("/tmp/demo.jsonl")
    assert participant_thread_id(participant) == "thread-1"
    assert participant_ready(participant) is True


def test_participant_last_message_uses_codex_agent(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, str | None, Path | None]] = []

    class FakeCodexAgent:
        def last_message(self, session: str, *, session_id: str | None = None, jsonl_path: Path | None = None):
            calls.append((session, session_id, jsonl_path))
            return SimpleNamespace(text="codex says hi")

    monkeypatch.setattr("keep.agents.codex.CodexAgent", FakeCodexAgent)

    message = participant_last_message(
        {
            "session": "r1",
            "role": "reviewer",
            "agent_type": "codex",
            "cache": {"thread_id": "thread-1", "jsonl_path": "/tmp/demo.jsonl"},
        }
    )

    assert message is not None
    assert message.text == "codex says hi"
    assert calls == [("r1", "thread-1", Path("/tmp/demo.jsonl"))]


def test_participant_last_message_uses_cc_agent(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, Path | None]] = []

    class FakeCCAgent:
        def last_message(self, session: str, *, jsonl_path: Path | None = None):
            calls.append((session, jsonl_path))
            return SimpleNamespace(text="cc says hi")

    monkeypatch.setattr("keep.agents.cc.CCAgent", FakeCCAgent)

    message = participant_last_message(
        {
            "session": "w1",
            "role": "worker",
            "agent_type": "claude-code",
            "cache": {"jsonl_path": "/tmp/worker.jsonl"},
        }
    )

    assert message is not None
    assert message.text == "cc says hi"
    assert calls == [("w1", Path("/tmp/worker.jsonl"))]


def test_participant_model_rejects_unknown_role() -> None:
    with pytest.raises(ValueError, match="Unknown participant role"):
        participant_model({"session": "x1", "role": "unknown"})
