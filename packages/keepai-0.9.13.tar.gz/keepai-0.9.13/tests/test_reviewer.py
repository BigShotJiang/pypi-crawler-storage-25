import json
from pathlib import Path

import pytest

from keep import state
from keep._daemon import runtime_state
from keep._daemon.constants import stop_file
from keep._daemon.notify import notify_all_reviewers
from keep._daemon.verdict_handlers import _handle_task_submitted_review, _handle_task_proposed_review
from keep._daemon.review import (
    aggregate_reviewer_verdict,
    check_reviewer_stop_signals,
)


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    (state_dir / "missions").mkdir(parents=True)
    monkeypatch.setenv("KEEP_HOME", str(state_dir))
    return state_dir


@pytest.fixture
def group_id(isolated_state: Path) -> str:
    name = "test-group"
    state.create_group(name)
    return name


# ── Task default status ───────────────────────────────────────


def test_task_default_status_is_proposed(isolated_state: Path) -> None:
    task = state.create_task("m1", subject="do something")
    assert task["status"] == "proposed"


# ── Reviewer CRUD ─────────────────────────────────────────────
#
# Reviewer participant ids are their session ids. Tests should use whatever
# `add_participant(..., role="reviewer")` returns.


def _is_uuid_like(value: str) -> bool:
    # UUID4 canonical form: 8-4-4-4-12 hex.
    import re
    return bool(re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", value))


def test_add_reviewer_returns_reviewer_id(group_id: str) -> None:
    reviewer_id = state.add_participant(group_id, "sess-abc", role="reviewer")["session"]
    assert isinstance(reviewer_id, str)
    assert reviewer_id == "sess-abc"


def test_add_reviewer_stores_data(group_id: str) -> None:
    reviewer_id = state.add_participant(group_id, "sess-abc", role="reviewer")["session"]
    reviewer = state.get_participant(group_id, reviewer_id, role="reviewer")
    assert reviewer["session"] == "sess-abc"
    assert reviewer["role"] == "reviewer"
    assert reviewer["session"] == reviewer_id


def test_get_reviewer_existing(group_id: str) -> None:
    reviewer_id = state.add_participant(group_id, "sess-1", role="reviewer")["session"]
    reviewer = state.get_participant(group_id, reviewer_id, role="reviewer")
    assert reviewer["session"] == reviewer_id


def test_get_reviewer_nonexistent_raises(group_id: str) -> None:
    with pytest.raises(ValueError, match="r99"):
        state.get_participant(group_id, "r99", role="reviewer")


def test_remove_reviewer_then_get_raises(group_id: str) -> None:
    reviewer_id = state.add_participant(group_id, "sess-1", role="reviewer")["session"]
    state.remove_participant(group_id, reviewer_id, role="reviewer")
    with pytest.raises(ValueError, match=reviewer_id):
        state.get_participant(group_id, reviewer_id, role="reviewer")


def test_remove_reviewer_nonexistent_raises(group_id: str) -> None:
    removed = state.remove_participant(group_id, "r99", role="reviewer")
    assert removed is False


def test_update_reviewer_updates_field(group_id: str) -> None:
    reviewer_id = state.add_participant(group_id, "sess-1", role="reviewer")["session"]
    updated = state.update_participant(group_id, reviewer_id, role="reviewer", status="active")
    assert updated["status"] == "active"
    # Persisted
    reloaded = state.get_participant(group_id, reviewer_id, role="reviewer")
    assert reloaded["status"] == "active"


def test_update_reviewer_nonexistent_raises(group_id: str) -> None:
    with pytest.raises(ValueError, match="r99"):
        state.update_participant(group_id, "r99", role="reviewer", status="active")


def test_iter_reviewers_returns_all(group_id: str) -> None:
    id1 = state.add_participant(group_id, "sess-1", role="reviewer")["session"]
    id2 = state.add_participant(group_id, "sess-2", role="reviewer")["session"]
    reviewers = list(state.iter_reviewers(group_id))
    assert len(reviewers) == 2
    ids = {r["session"] for r in reviewers}
    assert ids == {id1, id2}


def test_iter_reviewers_empty(group_id: str) -> None:
    reviewers = list(state.iter_reviewers(group_id))
    assert reviewers == []


def test_notify_all_reviewers_uses_group_embedded_reviewers(monkeypatch: pytest.MonkeyPatch) -> None:
    group = {
        "name": "m1",
        "terminal_type": "tmux",
        "participants": [
            {"session": "r1", "role": "reviewer", "status": "active", "cache": {"target_id": "surface-1"}},
            {"session": "r2", "role": "reviewer", "status": "active", "cache": {"target_id": "surface-2"}},
        ],
    }
    sent: list[str] = []
    monkeypatch.setattr("keep._daemon.notify.notify_reviewer", lambda group, reviewer, message: sent.append(reviewer["id"]))

    notify_all_reviewers(group, "hello")

    assert sent == ["r1", "r2"]


def test_load_group_migrates_legacy_reviewers_into_participants(isolated_state: Path) -> None:
    group_file = isolated_state / "missions" / "legacy.json"
    group_file.write_text(
        """{
  "schema_version": 2,
  "name": "legacy",
  "status": "stopped",
  "participants": [],
  "group_prompt": null,
  "created_at": 0,
  "review_events": [
    {
      "id": "re1",
      "type": "task_submitted_review",
      "participant_verdicts": {"legacy-reviewer-id": "pass"},
      "participant_rationales": {"legacy-reviewer-id": "/tmp/rationale.md"}
    }
  ],
  "terminal_type": "tmux",
  "terminal_container": null,
  "reviewers": [
    {
      "id": "legacy-reviewer-id",
      "session": "reviewer-session-1",
      "name": "planet",
      "status": "active",
      "agent_type": "codex"
    }
  ]
}""",
        encoding="utf-8",
    )

    group = state.load_group("legacy")

    assert group is not None
    reviewers = list(state.iter_reviewers("legacy"))
    assert len(reviewers) == 1
    assert reviewers[0]["session"] == "reviewer-session-1"
    assert reviewers[0]["id"] == "reviewer-session-1"
    assert group.get("reviewers") in (None, [])
    assert group["review_events"][0]["participant_verdicts"] == {"reviewer-session-1": "pass"}
    assert group["review_events"][0]["participant_rationales"] == {"reviewer-session-1": "/tmp/rationale.md"}


def test_aggregate_reviewer_verdict_uses_group_embedded_reviewers() -> None:
    group = {
        "name": "m1",
        "reviewers": [
            {"id": "r1", "triggers": ["task_submitted_review"]},
            {"id": "r2", "triggers": ["group_stop"]},
        ],
    }
    event = {
        "type": "task_submitted_review",
        "participant_verdicts": {"r1": "pass"},
    }

    verdict = aggregate_reviewer_verdict(group, event)

    assert verdict == "approved"


# ── Review Event CRUD ─────────────────────────────────────────


def test_add_review_event_returns_event_id(group_id: str) -> None:
    event_id = state.add_review_event(group_id, {"type": "lgtm", "reviewer": "r1"})
    assert event_id == "re1"


def test_add_review_event_stores_data(group_id: str) -> None:
    state.add_review_event(group_id, {"type": "lgtm", "reviewer": "r1"})
    event = state.get_review_event(group_id, "re1")
    assert event["type"] == "lgtm"
    assert event["reviewer"] == "r1"
    assert event["id"] == "re1"
    assert event["round"] == 1


def test_get_review_event_existing(group_id: str) -> None:
    state.add_review_event(group_id, {"type": "request_changes"})
    event = state.get_review_event(group_id, "re1")
    assert event["id"] == "re1"


def test_get_review_event_nonexistent_raises(group_id: str) -> None:
    with pytest.raises(ValueError, match="re99"):
        state.get_review_event(group_id, "re99")


def test_update_review_event_updates_field(group_id: str) -> None:
    state.add_review_event(group_id, {"type": "lgtm"})
    updated = state.update_review_event(group_id, "re1", resolved=True)
    assert updated["resolved"] is True
    # Persisted
    reloaded = state.get_review_event(group_id, "re1")
    assert reloaded["resolved"] is True


def test_update_review_event_nonexistent_raises(group_id: str) -> None:
    with pytest.raises(ValueError, match="re99"):
        state.update_review_event(group_id, "re99", resolved=True)


def test_add_multiple_review_events_sequential_ids(group_id: str) -> None:
    id1 = state.add_review_event(group_id, {"type": "lgtm"})
    id2 = state.add_review_event(group_id, {"type": "request_changes"})
    assert id1 == "re1"
    assert id2 == "re2"


def test_task_proposed_review_rejection_notifies_supervisor_with_review_result(
    group_id: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_task(group_id, subject="Task 1")
    state.create_task(group_id, subject="Task 2")
    group = state.load_group(group_id)
    assert group is not None

    sent: list[str] = []
    monkeypatch.setattr("keep._daemon.verdict_handlers.notify_supervisor", lambda group, message: sent.append(message))

    _handle_task_proposed_review(
        group_id,
        group,
        "re1",
        {
            "type": "task_proposed_review",
            "task_ids": ["1", "2"],
            "participant_resource_states": {"rv1": {"1": "proposed", "2": "proposed"}},
            "participant_rationales": {"rv1": "/tmp/review-reject.md"},
        },
        "rejected",
    )

    assert state.get_task(group_id, "1")["status"] == "proposed"
    assert state.get_task(group_id, "2")["status"] == "proposed"
    assert len(sent) == 1
    assert 'event="review_result"' in sent[0]
    assert 'type="task_proposed_review"' in sent[0]
    assert "proposed: #1, #2" in sent[0]
    assert "reviewers:" in sent[0]
    assert "[rv1 -&gt; #1=proposed, #2=proposed]" in sent[0]


def test_task_submitted_review_rejection_notifies_supervisor_with_review_result(
    group_id: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_task(group_id, subject="Task 1")
    state.create_task(group_id, subject="Task 2")
    state.update_task(group_id, "1", {"status": "in_progress"})
    state.update_task(group_id, "2", {"status": "in_progress"})
    group = state.load_group(group_id)
    assert group is not None

    sent: list[str] = []
    monkeypatch.setattr("keep._daemon.verdict_handlers.notify_supervisor", lambda group, message: sent.append(message))

    _handle_task_submitted_review(
        group_id,
        group,
        "re2",
        {
            "type": "task_submitted_review",
            "task_ids": ["1", "2"],
            "participant_resource_states": {"rv1": {"1": "in_progress", "2": "in_progress"}},
            "participant_rationales": {"rv1": "/tmp/claimed-reject.md"},
        },
        "rejected",
    )

    assert state.get_task(group_id, "1")["status"] == "in_progress"
    assert state.get_task(group_id, "2")["status"] == "in_progress"
    assert len(sent) == 1
    assert 'event="review_result"' in sent[0]
    assert 'type="task_submitted_review"' in sent[0]
    assert "in_progress: #1, #2" in sent[0]
    assert "reviewers:" in sent[0]
    assert "[rv1 -&gt; #1=in_progress, #2=in_progress]" in sent[0]


def test_check_reviewer_stop_signals_records_task_result_from_stop_file(
    group_id: str,
) -> None:
    reviewer_id = state.add_participant(group_id, "sess-review", role="reviewer")["session"]
    state.add_review_event(
        group_id,
        {
            "type": "task_submitted_review",
            "task_ids": ["1", "2"],
            "participant_resource_states": {},
        },
    )
    result_file = state.messages_dir(group_id) / "review-result.json"
    result_file.write_text(
        json.dumps(
            {
                "tasks": {"1": "completed", "2": "in_progress"},
                "rationale": "2 缺回归证明",
            }
        ),
        encoding="utf-8",
    )
    stop_file(reviewer_id).write_text(
        json.dumps({"last_assistant_message": str(result_file)}),
        encoding="utf-8",
    )
    runtime_state.first_stop_suppressed.add(reviewer_id)

    group = state.load_group(group_id)
    assert group is not None
    check_reviewer_stop_signals(group_id, group)

    event = state.get_review_event(group_id, "re1")
    assert event["participant_resource_states"] == {
        reviewer_id: {"1": "completed", "2": "in_progress"}
    }
    rationale_path = event["participant_rationales"][reviewer_id]
    assert "2 缺回归证明" in Path(rationale_path).read_text(encoding="utf-8")


def test_check_reviewer_stop_signals_matches_open_group_stop(
    group_id: str,
) -> None:
    reviewer_id = state.add_participant(group_id, "sess-review", role="reviewer")["session"]
    state.add_review_event(
        group_id,
        {
            "type": "group_stop",
            "participant_resource_states": {},
        },
    )
    result_file = state.messages_dir(group_id) / "group-stop-result.json"
    result_file.write_text(
        json.dumps({"group": "active", "rationale": "exit criteria 未满足"}),
        encoding="utf-8",
    )
    stop_file(reviewer_id).write_text(
        json.dumps({"last_assistant_message": str(result_file)}),
        encoding="utf-8",
    )
    runtime_state.first_stop_suppressed.add(reviewer_id)

    group = state.load_group(group_id)
    assert group is not None
    check_reviewer_stop_signals(group_id, group)

    event = state.get_review_event(group_id, "re1")
    assert event["participant_resource_states"] == {reviewer_id: {"group": "active"}}
    rationale_path = event["participant_rationales"][reviewer_id]
    assert "exit criteria 未满足" in Path(rationale_path).read_text(encoding="utf-8")


def test_check_reviewer_stop_signals_ignores_ambiguous_open_batches(
    group_id: str,
) -> None:
    reviewer_id = state.add_participant(group_id, "sess-review", role="reviewer")["session"]
    state.add_review_event(
        group_id,
        {
            "type": "task_proposed_review",
            "task_ids": ["1"],
            "participant_resource_states": {},
        },
    )
    state.add_review_event(
        group_id,
        {
            "type": "task_proposed_review",
            "task_ids": ["1"],
            "participant_resource_states": {},
        },
    )
    result_file = state.messages_dir(group_id) / "ambiguous-result.json"
    result_file.write_text(
        json.dumps({"tasks": {"1": "pending"}, "rationale": "ok"}),
        encoding="utf-8",
    )
    stop_file(reviewer_id).write_text(
        json.dumps({"last_assistant_message": str(result_file)}),
        encoding="utf-8",
    )
    runtime_state.first_stop_suppressed.add(reviewer_id)

    group = state.load_group(group_id)
    assert group is not None
    check_reviewer_stop_signals(group_id, group)

    assert state.get_review_event(group_id, "re1")["participant_resource_states"] == {}
    assert state.get_review_event(group_id, "re2")["participant_resource_states"] == {}


def test_check_reviewer_stop_signals_preserves_multiple_reviewer_results_in_same_tick(
    group_id: str,
) -> None:
    state.add_participant(group_id, "rev-a", role="reviewer", triggers=["task_proposed_review"], bootstrapped=True)
    state.add_participant(group_id, "rev-b", role="reviewer", triggers=["task_proposed_review"], bootstrapped=True)
    state.add_review_event(
        group_id,
        {
            "type": "task_proposed_review",
            "task_ids": ["1", "2"],
            "participant_resource_states": {},
        },
    )
    msg_dir = state.messages_dir(group_id)
    (msg_dir / "rev-a.json").write_text(
        json.dumps({"tasks": {"1": "pending", "2": "pending"}, "rationale": "a"}),
        encoding="utf-8",
    )
    (msg_dir / "rev-b.json").write_text(
        json.dumps({"tasks": {"1": "pending", "2": "pending"}, "rationale": "b"}),
        encoding="utf-8",
    )
    stop_file("rev-a").write_text(
        json.dumps({"last_assistant_message": str(msg_dir / "rev-a.json")}),
        encoding="utf-8",
    )
    stop_file("rev-b").write_text(
        json.dumps({"last_assistant_message": str(msg_dir / "rev-b.json")}),
        encoding="utf-8",
    )
    runtime_state.first_stop_suppressed.update({"rev-a", "rev-b"})

    group = state.load_group(group_id)
    assert group is not None
    check_reviewer_stop_signals(group_id, group)

    event = state.get_review_event(group_id, "re1")
    assert event["participant_resource_states"] == {
        "rev-a": {"1": "pending", "2": "pending"},
        "rev-b": {"1": "pending", "2": "pending"},
    }
