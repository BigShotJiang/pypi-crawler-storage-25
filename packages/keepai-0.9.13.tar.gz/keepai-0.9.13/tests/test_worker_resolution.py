from __future__ import annotations

import subprocess

from keep import worker


def test_find_claude_pid_prefers_process_with_cmux_surface(monkeypatch):
    ps_lines = "\n".join([
        "71683 bash /Users/apple/.cac/bin/claude --name runtime-smoke-worker-2",
        "71722 /Users/apple/.cac/versions/2.1.96/claude --name runtime-smoke-worker-2",
    ])

    def fake_run(args, capture_output=True, text=True, timeout=5):
        if args == ["ps", "-eo", "pid,args"]:
            return subprocess.CompletedProcess(args, 0, stdout=ps_lines, stderr="")
        if args == ["ps", "eww", "-p", "71683"]:
            return subprocess.CompletedProcess(args, 0, stdout="PID TT STAT TIME COMMAND\n71683 ...", stderr="")
        if args == ["ps", "eww", "-p", "71722"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout=(
                    "PID TT STAT TIME COMMAND\n"
                    "71722 ... CMUX_WORKSPACE_ID=ws-1 CMUX_SURFACE_ID=surface-1"
                ),
                stderr="",
            )
        raise AssertionError(f"unexpected args: {args}")

    monkeypatch.setattr(subprocess, "run", fake_run)

    assert worker._find_claude_pid("runtime-smoke-worker-2") == 71722


def test_find_claude_pid_supports_session_id_flag(monkeypatch):
    ps_lines = "\n".join([
        "71683 bash /Users/apple/.cac/bin/claude --session-id 11111111-1111-4111-8111-111111111111",
        "71722 /Users/apple/.cac/versions/2.1.96/claude --session-id 11111111-1111-4111-8111-111111111111",
    ])

    def fake_run(args, capture_output=True, text=True, timeout=5):
        if args == ["ps", "-eo", "pid,args"]:
            return subprocess.CompletedProcess(args, 0, stdout=ps_lines, stderr="")
        raise AssertionError(f"unexpected args: {args}")

    monkeypatch.setattr(subprocess, "run", fake_run)

    assert worker._find_claude_pid("11111111-1111-4111-8111-111111111111") == 71722


def test_find_claude_pid_prefers_keep_participant_session_env(monkeypatch):
    monkeypatch.setattr(
        worker,
        "_list_processes_with_env",
        lambda: [
            (
                71722,
                "claude --dangerously-skip-permissions prompt KEEP_PARTICIPANT_SESSION=11111111-1111-4111-8111-111111111111",
            ),
        ],
    )

    assert worker._find_claude_pid("11111111-1111-4111-8111-111111111111") == 71722


def test_find_codex_pid_matches_keep_session_even_when_thread_id_is_present(monkeypatch):
    monkeypatch.setattr(worker, "_find_pid_by_surface_id", lambda **kwargs: None)
    monkeypatch.setattr(
        worker,
        "_list_processes",
        lambda: [
            (
                71722,
                "codex --dangerously-bypass-approvals-and-sandbox --no-alt-screen "
                "Group: 'm'。session id: 11111111-1111-4111-8111-111111111111。你是 worker",
            ),
        ],
    )

    assert worker._find_codex_pid(
        "11111111-1111-4111-8111-111111111111",
        None,
        {"thread_id": "codex-thread-1"},
    ) == 71722
