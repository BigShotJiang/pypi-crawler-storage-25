"""Regression tests for concurrent group-state mutators.

Participant CRUD (`add_supervisor` / `add_worker` / `remove_*`) used to take a
`group: dict` argument and mutate it in-memory; callers then did their own
`load_group` + `save_group`. That pattern races with any other process
holding a file lock via `mutate_group(group_id)` (reviewers, daemon):

    T1 (participant add): load → mutate in-mem                         → save
    T2 (reviewer add):                          lock → load → mutate → save
                                                                          ^
                                                           T1's save now overwrites

These tests stress the fix: every mutator takes `group_id` and serialises
through `mutate_group`. A barrier releases N threads simultaneously so
they really contend on the lock; the final state must show *every* add.
"""

from __future__ import annotations

import threading
import uuid
from pathlib import Path

import pytest

from keep import state
from keep._cli.helpers import refresh_worker_cache
from keep.worker import WorkerInfo


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    (state_dir / "missions").mkdir(parents=True)
    monkeypatch.setenv("KEEP_HOME", str(state_dir))
    state.save_global(state.new_global())
    return state_dir


def _run_concurrently(fns: list) -> list[BaseException | None]:
    """Release all `fns` together through a barrier; collect any exception."""
    barrier = threading.Barrier(len(fns))
    errors: list[BaseException | None] = [None] * len(fns)

    def wrapped(idx: int, fn):
        try:
            barrier.wait(timeout=5)
            fn()
        except BaseException as exc:  # noqa: BLE001 — capture for assertion
            errors[idx] = exc

    threads = [threading.Thread(target=wrapped, args=(i, fn)) for i, fn in enumerate(fns)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=10)
        assert not t.is_alive(), "race test deadlocked — mutators not releasing lock"
    return errors


def test_concurrent_add_supervisor_and_reviewer_both_visible(isolated_state: Path) -> None:
    """Supervisor add (participants.py) and reviewer add (reviewers.py) must not clobber each other.

    Historical bug: `add_supervisor(group, ...)` mutated `group` in memory
    and the caller called `save_group`, bypassing `mutate_group`'s lock
    while `add_reviewer(group_id, ...)` held it and produced a stale-read
    write on unlock.
    """
    for i in range(10):
        group_id = f"group-r{i}"
        state.create_group(group_id)

        sup_session = str(uuid.uuid4())
        reviewer_payload = {
            "name": "rev-a",
            "path": "/tmp/rev",
            "status": "active",
            "session": str(uuid.uuid4()),
        }

        errors = _run_concurrently([
            lambda mid=group_id, s=sup_session: state.add_supervisor(mid, s),
            lambda mid=group_id, d=reviewer_payload: state.add_participant(mid, d["session"], role="reviewer", name=d["name"], path=d["path"], status=d["status"]),
        ])
        assert all(e is None for e in errors), f"concurrent ops errored: {errors!r}"

        group = state.load_group(group_id)
        assert group is not None
        sup = state.find_supervisor(group)
        assert sup is not None and sup["session"] == sup_session, (
            f"iter={i}: supervisor lost; participants={group.get('participants')}"
        )
        reviewers = list(state.iter_reviewers(group_id))
        assert len(reviewers) == 1, (
            f"iter={i}: reviewer lost; reviewers={reviewers!r}"
        )


def test_concurrent_add_workers_all_visible(isolated_state: Path) -> None:
    """N parallel add_worker calls on the same group must all land."""
    for i in range(10):
        group_id = f"group-w{i}"
        state.create_group(group_id)

        sessions = [str(uuid.uuid4()) for _ in range(5)]
        errors = _run_concurrently([
            lambda mid=group_id, s=sess: state.add_worker(mid, s, cache={"target_id": f"t-{s[:4]}"})
            for sess in sessions
        ])
        assert all(e is None for e in errors), f"iter={i} errors: {errors!r}"

        group = state.load_group(group_id)
        assert group is not None
        workers = state.iter_workers(group)
        got = {w["session"] for w in workers}
        assert got == set(sessions), (
            f"iter={i}: workers lost; got={got!r}, want={set(sessions)!r}"
        )


def test_concurrent_mixed_participants_and_reviewers(isolated_state: Path) -> None:
    """Mix supervisor + workers + reviewers all contending on one group's lock.

    This is the full shape of the race hit in production: supervisor create,
    worker create, reviewer create all kicked off roughly together.
    """
    for i in range(5):
        group_id = f"group-mix{i}"
        state.create_group(group_id)

        sup_session = str(uuid.uuid4())
        worker_sessions = [str(uuid.uuid4()) for _ in range(3)]
        reviewer_payloads = [
            {"name": f"rev-{j}", "path": "/tmp/r", "status": "active", "session": str(uuid.uuid4())}
            for j in range(2)
        ]

        fns = (
            [lambda mid=group_id, s=sup_session: state.add_supervisor(mid, s)]
            + [lambda mid=group_id, s=sess: state.add_worker(mid, s) for sess in worker_sessions]
            + [lambda mid=group_id, d=pl: state.add_participant(mid, d["session"], role="reviewer", name=d["name"], path=d["path"], status=d["status"]) for pl in reviewer_payloads]
        )
        errors = _run_concurrently(fns)
        assert all(e is None for e in errors), f"iter={i} errors: {errors!r}"

        group = state.load_group(group_id)
        assert group is not None
        sup = state.find_supervisor(group)
        assert sup is not None and sup["session"] == sup_session, f"iter={i}: sup lost"
        got_workers = {w["session"] for w in state.iter_workers(group)}
        assert got_workers == set(worker_sessions), (
            f"iter={i}: workers lost; got={got_workers!r}, want={set(worker_sessions)!r}"
        )
        got_reviewers = list(state.iter_reviewers(group_id))
        assert len(got_reviewers) == len(reviewer_payloads), (
            f"iter={i}: reviewers lost; got={got_reviewers!r}"
        )


def _unlocked_add_supervisor(group_id: str, session: str) -> None:
    """The pre-fix pattern, open-coded: load → mutate in-memory → save, **no lock**.

    Used by `test_race_actually_happens_without_lock` to confirm our concurrent
    harness really contends (otherwise the fix-validated tests would be vacuous
    — they'd pass even if the lock did nothing, because threads happened not
    to interleave).
    """
    group = state.load_group(group_id)
    if group is None:
        raise ValueError(f"Group {group_id!r} 不存在")
    group.setdefault("participants", []).append(
        {"session": session, "role": "supervisor", "name": "", "path": "", "contract": None, "cache": None}
    )
    # Simulate realistic think/spawn delay between load and save so the race window
    # is wide. Without this the threads serialise accidentally on fast filesystems.
    import time
    time.sleep(0.01)
    state.save_group(group_id, group)


def _unlocked_add_reviewer(group_id: str, payload: dict) -> None:
    """Lock-free variant of add_reviewer mirroring what the supervisor path used to do."""
    group = state.load_group(group_id)
    if group is None:
        raise ValueError(f"Group {group_id!r} 不存在")
    group.setdefault("reviewers", []).append({**payload, "id": str(uuid.uuid4())})
    import time
    time.sleep(0.01)
    state.save_group(group_id, group)


def test_race_actually_happens_without_lock(isolated_state: Path) -> None:
    """Proof that the harness + sleep window actually exposes the race.

    Runs the **unlocked** variants concurrently on the same group across
    many iterations; expects at least one iteration to lose data. If this
    test ever flakes to "all iterations consistent", the race window has
    closed and the other tests in this file may be vacuously green — revisit
    the sleep / iteration count.
    """
    lost_iterations = 0
    iterations = 20
    for i in range(iterations):
        group_id = f"group-proof{i}"
        state.create_group(group_id)

        sup_session = str(uuid.uuid4())
        reviewer_payload = {
            "name": "rev", "path": "/tmp/rev", "status": "active",
            "session": str(uuid.uuid4()),
        }

        errors = _run_concurrently([
            lambda mid=group_id, s=sup_session: _unlocked_add_supervisor(mid, s),
            lambda mid=group_id, d=reviewer_payload: _unlocked_add_reviewer(mid, d),
        ])
        if any(e is not None for e in errors):
            # Exception from `atomic_write_text`'s tmp-file collision also
            # counts as a failure mode the lock prevents.
            lost_iterations += 1
            continue
        group = state.load_group(group_id)
        if group is None:
            lost_iterations += 1
            continue
        has_sup = state.find_supervisor(group) is not None
        has_reviewer = len(list(state.iter_reviewers(group_id))) == 1
        if not (has_sup and has_reviewer):
            lost_iterations += 1
    assert lost_iterations > 0, (
        f"race was supposed to be exposable but {iterations} iterations all landed both writes — "
        "sleep window may need widening"
    )


def test_concurrent_add_then_remove_worker_leaves_consistent_state(isolated_state: Path) -> None:
    """add_worker and remove_worker contending must not leave duplicate or stale entries."""
    for i in range(10):
        group_id = f"group-ar{i}"
        state.create_group(group_id)

        sess_keep = str(uuid.uuid4())
        sess_churn = str(uuid.uuid4())
        # Pre-seed the churn worker so remove_worker has something to remove.
        state.add_worker(group_id, sess_churn, cache={"target_id": "churn"})

        errors = _run_concurrently([
            lambda mid=group_id, s=sess_keep: state.add_worker(mid, s, cache={"target_id": "keep"}),
            lambda mid=group_id, s=sess_churn: state.remove_worker(mid, s),
        ])
        assert all(e is None for e in errors), f"iter={i} errors: {errors!r}"

        group = state.load_group(group_id)
        got = {w["session"] for w in state.iter_workers(group)}
        assert got == {sess_keep}, (
            f"iter={i}: unexpected workers after concurrent add+remove: {got!r}"
        )


def test_refresh_worker_cache_does_not_clobber_newer_worker_additions(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    group_id = "group-refresh"
    state.create_group(group_id)
    state.add_worker(group_id, "worker-1", cache={"target_id": "surface-old"})

    stale_group = state.load_group(group_id)
    assert stale_group is not None
    stale_worker = state.find_worker(stale_group, "worker-1")
    assert stale_worker is not None

    state.add_worker(group_id, "worker-2", cache={"target_id": "surface-2"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None, agent_type=None, cache_hint=None: WorkerInfo(
            session=session,
            agent_type=agent_type or "claude-code",
            pid=123,
            terminal_type=terminal_type,
            target_id="surface-new",
            jsonl_path=None,
            running=True,
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id},
    )

    info = refresh_worker_cache(stale_worker, group_id, stale_group)

    assert info.running is True
    fresh = state.load_group(group_id)
    assert fresh is not None
    assert state.find_worker(fresh, "worker-1") is not None
    assert state.find_worker(fresh, "worker-2") is not None
    assert state.find_worker(fresh, "worker-1")["cache"] == {"pid": 123, "target_id": "surface-new"}
