from __future__ import annotations

from pathlib import Path

from keep._daemon.xml_format import _read_rationale
from keep._cli.dispatch_task import _reviewer_rationale_text as task_rationale_text
from keep.cli import _reviewer_rationale_text as group_rationale_text


def test_daemon_review_summary_blocks_rationale_outside_keep_home(tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path / "state"))
    outside = tmp_path / "outside.txt"
    outside.write_text("secret", encoding="utf-8")

    text = _read_rationale(str(outside))

    assert "outside KEEP_HOME" in text
    assert "secret" not in text


def test_cli_reviewer_rationale_blocks_paths_outside_keep_home(tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path / "state"))
    outside = tmp_path / "outside.txt"
    outside.write_text("secret", encoding="utf-8")
    event = {
        "participant_verdicts": {"rv1": "reject"},
        "participant_rationales": {"rv1": str(outside)},
    }

    group_text = group_rationale_text(event)
    task_text = task_rationale_text(event)

    assert "outside KEEP_HOME" in group_text
    assert "outside KEEP_HOME" in task_text
    assert "secret" not in group_text
    assert "secret" not in task_text


def test_cli_reviewer_rationale_reads_keep_home_files(tmp_path, monkeypatch):
    state_dir = tmp_path / "state"
    messages_dir = state_dir / "missions" / "m1" / "messages"
    messages_dir.mkdir(parents=True)
    rationale = messages_dir / "rationale.txt"
    rationale.write_text("allowed", encoding="utf-8")
    monkeypatch.setenv("KEEP_HOME", str(state_dir))
    event = {
        "participant_verdicts": {"rv1": "reject"},
        "participant_rationales": {"rv1": str(rationale)},
    }

    group_text = group_rationale_text(event)
    task_text = task_rationale_text(event)

    assert "allowed" in group_text
    assert "allowed" in task_text
