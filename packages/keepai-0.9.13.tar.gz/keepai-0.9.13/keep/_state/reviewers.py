"""Review event CRUD.

Reviewer participant CRUD now lives in ``_state.participants``.
This module only owns review-event storage.
"""

from __future__ import annotations
from typing import Any

from keep._state.groups import load_group, mutate_group


def _next_seq_id(group: dict, key: str, prefix: str) -> str:
    """生成下一个序列 ID。使用最大值 + 1，避免删除后 ID 碰撞。"""
    max_n = 0
    for item in group.get(key, []):
        raw = str(item.get("id", "")).removeprefix(prefix)
        try:
            max_n = max(max_n, int(raw))
        except ValueError:
            pass
    return f"{prefix}{max_n + 1}"

# ── Review Events ─────────────────────────────────────────────


def _next_review_event_id(group: dict[str, Any]) -> str:
    return _next_seq_id(group, "review_events", "re")


def add_review_event(group_id: str, event_data: dict) -> str:
    """Add a review event to a group. Returns the generated event_id."""
    with mutate_group(group_id) as group:
        group.setdefault("review_events", [])
        event_id = _next_review_event_id(group)
        event = dict(event_data)
        event["id"] = event_id
        event.setdefault("round", 1)
        group["review_events"].append(event)
    return event_id


def get_review_event(group_id: str, event_id: str) -> dict:
    """Get a single review event by id. Raises ValueError if not found."""
    group = load_group(group_id)
    if group is None:
        raise ValueError(f"Group '{group_id}' 不存在")
    for e in group.get("review_events", []):
        if e.get("id") == event_id:
            return e
    raise ValueError(f"Review event '{event_id}' 不存在")


def update_review_event(group_id: str, event_id: str, **kwargs) -> dict:
    """Update fields on a review event. Raises ValueError if not found."""
    with mutate_group(group_id) as group:
        for e in group.get("review_events", []):
            if e.get("id") == event_id:
                e.update(kwargs)
                return e
        raise ValueError(f"Review event '{event_id}' 不存在")
