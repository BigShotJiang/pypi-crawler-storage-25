"""Participant helpers.

Participant = {session, role, agent_type?, cache?, name?, path?, contract?}
  role:  "worker" | "supervisor" | "reviewer"
  agent_type: "claude-code" | "codex"（缺省视为 claude-code）
  cache: 运行时信息（pid/target_id/jsonl_path/thread_id），可选

terminal_type 不存在 participant 上：group 是唯一来源。

Mutator pattern (并发安全)：
  add_*/remove_* 接 group_id，内部通过 `mutate_group` 取 per-group
  file lock，load → mutate → save 原子化。caller **不要** 自己
  `load_group + save_group` —— 那样绕开了锁，会和 daemon / 其他 CLI
  进程 race 写（后写覆盖前写，state 丢失）。
"""

from __future__ import annotations

from typing import Any
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict

from keep.agent import AgentMessage
from keep.agent_types import normalize_agent_type
from keep._state.groups import VALID_PARTICIPANT_ROLES, list_groups, load_group, mutate_group


class Participant(BaseModel):
    model_config = ConfigDict(extra="allow")

    session: str = ""
    role: Literal["worker", "supervisor", "reviewer"]
    name: str = ""
    path: str = ""
    contract: dict | None = None
    agent_type: str | None = None
    cache: dict | None = None

    def normalized_agent_type(self) -> str:
        return normalize_agent_type(self.agent_type)

    def target_id(self) -> str | None:
        return str((self.cache or {}).get("target_id") or "") or None

    def jsonl_path(self) -> Path | None:
        raw = (self.cache or {}).get("jsonl_path")
        if not raw:
            return None
        return Path(str(raw))

    def thread_id(self) -> str | None:
        raw = (self.cache or {}).get("thread_id")
        return str(raw) if raw else None

    def is_ready(self) -> bool:
        return bool(self.target_id())

    def last_message(self) -> AgentMessage | None:
        if self.normalized_agent_type() == "codex":
            from keep.agents.codex import CodexAgent

            return CodexAgent().last_message(
                self.session,
                session_id=self.thread_id(),
                jsonl_path=self.jsonl_path(),
            )

        from keep.agents.cc import CCAgent

        return CCAgent().last_message(
            self.session,
            jsonl_path=self.jsonl_path(),
        )


class SupervisorParticipant(Participant):
    role: Literal["supervisor"] = "supervisor"


class WorkerParticipant(Participant):
    role: Literal["worker"] = "worker"


class ReviewerParticipant(Participant):
    role: Literal["reviewer"] = "reviewer"


def participant_model(participant: dict[str, Any]) -> Participant:
    role = str(participant.get("role") or "")
    if role == "supervisor":
        return SupervisorParticipant.model_validate(participant)
    if role == "worker":
        return WorkerParticipant.model_validate(participant)
    if role == "reviewer":
        return ReviewerParticipant.model_validate(participant)
    raise ValueError(
        f"Unknown participant role: {role!r}; valid: {sorted(VALID_PARTICIPANT_ROLES)}"
    )


def _participants_by_role(group: dict[str, Any], role: str) -> list[dict[str, Any]]:
    return [p for p in group.get("participants", []) if p.get("role") == role]


def iter_participants(group: dict[str, Any], *, role: str | None = None) -> list[dict[str, Any]]:
    if role is None:
        return list(group.get("participants", []))
    return _participants_by_role(group, role)


def participant_agent_type(participant: dict[str, Any]) -> str:
    return participant_model(participant).normalized_agent_type()


def participant_last_message(participant: dict[str, Any]) -> AgentMessage | None:
    return participant_model(participant).last_message()


def participant_ready(participant: dict[str, Any]) -> bool:
    return participant_model(participant).is_ready()


def participant_target_id(participant: dict[str, Any]) -> str | None:
    return participant_model(participant).target_id()


def participant_jsonl_path(participant: dict[str, Any]) -> Path | None:
    return participant_model(participant).jsonl_path()


def participant_thread_id(participant: dict[str, Any]) -> str | None:
    return participant_model(participant).thread_id()


def worker_session_id(worker: dict[str, Any]) -> str | None:
    """Return keep's stable participant session id for routing stop files."""
    session = worker.get("session")
    if session:
        return str(session)
    thread_id = participant_thread_id(worker)
    if thread_id:
        return str(thread_id)
    return None


def iter_workers(group: dict[str, Any]) -> list[dict[str, Any]]:
    """返回 group 里所有 role=worker 的 participant。"""
    return iter_participants(group, role="worker")


def iter_reviewer_participants(group: dict[str, Any]) -> list[dict[str, Any]]:
    return iter_participants(group, role="reviewer")


def iter_reviewers(group_id: str) -> list[dict[str, Any]]:
    group = load_group(group_id)
    if group is None:
        raise ValueError(f"Group '{group_id}' 不存在")
    return [
        {**reviewer, "id": reviewer.get("session")}
        for reviewer in iter_reviewer_participants(group)
    ]


def find_worker(group: dict[str, Any], session: str) -> dict[str, Any] | None:
    return find_participant(group, session, role="worker")


def find_participant(
    group: dict[str, Any],
    session: str,
    *,
    role: str | None = None,
) -> dict[str, Any] | None:
    participants = iter_participants(group, role=role)
    return next(
        (p for p in participants if p.get("session") == session),
        None,
    )


def get_participant(
    group_id: str,
    session: str,
    *,
    role: str | None = None,
) -> dict[str, Any]:
    group = load_group(group_id)
    if group is None:
        raise ValueError(f"Group '{group_id}' 不存在")
    participant = find_participant(group, session, role=role)
    if participant is None:
        label = role or "participant"
        raise ValueError(f"{label.title()} '{session}' 不存在")
    return participant


def find_worker_globally(session: str) -> str | None:
    """检查 session 是否已作为 worker 在任何 group 中，返回 group name 或 None。"""
    return find_participant_globally(session, role="worker")


def find_participant_globally(session: str, *, role: str | None = None) -> str | None:
    """检查 session 是否已作为 participant 在任何 group 中，返回 group name 或 None。"""
    for name in list_groups():
        m = load_group(name)
        if m and find_participant(m, session, role=role):
            return name
    return None


def find_supervisor(group: dict[str, Any]) -> dict[str, Any] | None:
    """返回 group 的 supervisor participant（若有）。"""
    return next(iter(iter_participants(group, role="supervisor")), None)


def add_participant(
    group_id: str,
    session: str,
    *,
    role: str,
    cache: dict | None = None,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
    bootstrapped: bool | None = None,
    **extra_fields: Any,
) -> dict[str, Any]:
    existing = find_participant_globally(session, role=role)
    if existing and existing != group_id:
        raise ValueError(
            f"Participant '{session}' 已在 group '{existing}' 中，"
            f"先从该 group 中移除"
        )
    participant: dict[str, Any] = {
        "session": session,
        "role": role,
        "name": name or "",
        "path": path or "",
        "contract": contract,
        "agent_type": normalize_agent_type(agent_type),
        "cache": cache,
    }
    if bootstrapped is not None:
        participant["bootstrapped"] = bootstrapped
    participant.update(extra_fields)
    with mutate_group(group_id) as group:
        group.setdefault("participants", [])
        if role == "supervisor":
            existing_supervisor = find_supervisor(group)
            if existing_supervisor is not None:
                old_id = existing_supervisor.get("name") or existing_supervisor.get("session", "")
                raise ValueError(
                    f"Group already has a supervisor ({old_id}). "
                    "Remove it first: keep supervisor remove"
                )
        if find_participant(group, session, role=role):
            raise ValueError(f"{role.title()} '{session}' 已在此 group 中")
        group["participants"].append(participant)
    return participant


def update_participant(
    group_id: str,
    session: str,
    *,
    role: str | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    with mutate_group(group_id) as group:
        participant = find_participant(group, session, role=role)
        if participant is None:
            label = role or "participant"
            raise ValueError(f"{label.title()} '{session}' 不存在")
        participant.update(kwargs)
        participant["session"] = session
        if role is not None:
            participant["role"] = role
        return participant


def remove_participant(
    group_id: str,
    session: str,
    *,
    role: str | None = None,
) -> bool:
    with mutate_group(group_id) as group:
        participants = group.get("participants", [])
        new_participants = [
            p for p in participants
            if not (
                p.get("session") == session
                and (role is None or p.get("role") == role)
            )
        ]
        if len(new_participants) == len(participants):
            return False
        group["participants"] = new_participants
    return True


def add_worker(
    group_id: str,
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
    bootstrapped: bool = False,
) -> dict[str, Any]:
    return add_participant(
        group_id,
        session,
        role="worker",
        cache=cache,
        name=name,
        path=path,
        contract=contract,
        agent_type=agent_type,
        bootstrapped=bootstrapped,
    )


def remove_worker(group_id: str, session: str) -> bool:
    return remove_participant(group_id, session, role="worker")


def add_supervisor(
    group_id: str,
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
) -> dict[str, Any]:
    return add_participant(
        group_id,
        session,
        role="supervisor",
        cache=cache,
        name=name,
        path=path,
        contract=contract,
        agent_type=agent_type,
    )


def remove_supervisor(group_id: str) -> bool:
    group = load_group(group_id)
    if group is None:
        return False
    supervisor = find_supervisor(group)
    if supervisor is None:
        return False
    return remove_participant(group_id, str(supervisor["session"]), role="supervisor")
