"""Group CRUD, schema versioning, migration, per-group lock."""

from __future__ import annotations

import json
import re
import shutil
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from filelock import FileLock

from keep.agent_types import normalize_agent_type
from keep._state import paths as _paths
from keep._state.globals_ import new_global, save_global
from keep._state.paths import (
    DEFAULT_TERMINAL,
    VALID_TERMINALS,
    atomic_write_text,
    _ensure_dirs,
    _validate_group_name,
)

_LEGACY_PROMPT_KEY = "mis" "sion_prompt"

# Schema version. Bump when introducing migration-requiring changes.
# Current shape:
#   - participants: no "terminal_type" or "reach" fields
#   - group: no "relationships" / "plans" / "next_plan_id"
#   - tasks: no "rationale_review_event_id"
SCHEMA_VERSION = 6

VALID_GROUP_STATUSES = frozenset({"active", "stopped", "paused"})
VALID_PARTICIPANT_ROLES = frozenset({"worker", "supervisor", "reviewer"})


def group_terminal_type(group: dict[str, Any]) -> str:
    """Group's terminal_type. Falls back to DEFAULT_TERMINAL only for pre-feature groups."""
    return group.get("terminal_type") or DEFAULT_TERMINAL


def validate_group(group: dict[str, Any]) -> None:
    """Raise ValueError if group violates schema invariants.

    Required fields enforced here let display/logic paths use direct dict
    access (group["status"], group["name"]) instead of .get with masking
    fallbacks. Bugs in serializers surface here, not at use sites.
    """
    name = group.get("name")
    if not name:
        raise ValueError(f"Group missing required field 'name': {group!r}")

    status = group.get("status")
    if status not in VALID_GROUP_STATUSES:
        raise ValueError(
            f"Group {name!r}: invalid status {status!r}; "
            f"valid: {sorted(VALID_GROUP_STATUSES)}"
        )

    tt = group.get("terminal_type")
    if tt is not None and tt not in VALID_TERMINALS:
        raise ValueError(
            f"Group {name!r}: invalid terminal_type {tt!r}; "
            f"valid: {sorted(VALID_TERMINALS)}"
        )

    default_agent = group.get("default_agent")
    if default_agent is not None:
        try:
            normalize_agent_type(default_agent)
        except ValueError as exc:
            raise ValueError(f"Group {name!r}: {exc}") from exc

    tc = group.get("terminal_container")
    if tc is not None and not isinstance(tc, str):
        raise ValueError(
            f"Group {name!r}: terminal_container must be str or None, got {type(tc).__name__}"
        )

    for p in group.get("participants", []):
        role = p.get("role")
        if role not in VALID_PARTICIPANT_ROLES:
            raise ValueError(
                f"Group {name!r}: participant has invalid role {role!r}; "
                f"valid: {sorted(VALID_PARTICIPANT_ROLES)}"
            )
        if not p.get("session"):
            raise ValueError(f"Group {name!r}: participant missing 'session' field")


def _group_file(name: str) -> Path:
    return _paths.GROUPS_DIR / f"{name}.json"


def _group_lock_file(name: str) -> Path:
    return _paths.GROUPS_DIR / f"{name}.json.lock"


def _group_resource_dir(group_name: str) -> Path:
    return _paths.GROUPS_DIR / group_name


def new_group(
    name: str,
    terminal_type: str = DEFAULT_TERMINAL,
    *,
    default_agent: str | None = None,
    workers_enabled: bool | None = None,
) -> dict[str, Any]:
    group: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "name": name,
        "status": "stopped",
        "participants": [],
        "group_prompt": None,
        "created_at": time.time(),
        "review_events": [],
        "terminal_type": terminal_type,
        "terminal_container": None,
    }
    if default_agent is not None:
        group["default_agent"] = normalize_agent_type(default_agent)
    if workers_enabled is not None:
        group["workers_enabled"] = workers_enabled
    return group


def _migrate_group_shape(group: dict[str, Any]) -> bool:
    """Run all migrations needed to bring `group` up to SCHEMA_VERSION.

    Skipped on already-current groups. Returns True if anything was changed.
    """
    if group.get("schema_version") == SCHEMA_VERSION and _LEGACY_PROMPT_KEY not in group:
        return False

    version = group.get("schema_version", 0)

    # v0.3 → v0.4: workers → participants[role=worker]
    if "participants" not in group:
        old = group.get("workers", [])
        group["participants"] = [
            {"session": w["session"], "role": "worker", "cache": w.get("cache")}
            for w in old
        ]
        group.pop("workers", None)
    else:
        for p in group["participants"]:
            # Removed dead participant fields (group is the source of truth)
            for dead_key in ("reach", "terminal_type"):
                p.pop(dead_key, None)

    # Dead top-level fields removed in later versions
    for dead_key in ("relationships", "plans", "next_plan_id"):
        group.pop(dead_key, None)

    # v1 → v2: add terminal_container (no readers yet; upcoming refactor)
    if version < 2:
        group.setdefault("terminal_container", None)

    # v2 → v3: reviewers move into participants[role=reviewer]
    if version < 3:
        participants = group.setdefault("participants", [])
        reviewer_migration_map: dict[str, str] = {}
        for reviewer in group.pop("reviewers", []) or []:
            legacy_id = reviewer.get("id")
            session = str(reviewer.get("session") or legacy_id or "")
            if not session:
                continue
            reviewer_participant = {k: v for k, v in reviewer.items() if k not in {"id", "role"}}
            reviewer_participant["session"] = session
            reviewer_participant["role"] = "reviewer"
            reviewer_participant["agent_type"] = normalize_agent_type(reviewer_participant.get("agent_type"))
            if not any(
                p.get("role") == "reviewer" and p.get("session") == session
                for p in participants
            ):
                participants.append(reviewer_participant)
            if legacy_id:
                reviewer_migration_map[str(legacy_id)] = session

        if reviewer_migration_map:
            for event in group.get("review_events", []) or []:
                verdicts = dict(event.get("reviewer_verdicts") or {})
                if verdicts:
                    event["reviewer_verdicts"] = {
                        reviewer_migration_map.get(str(reviewer_id), str(reviewer_id)): verdict
                        for reviewer_id, verdict in verdicts.items()
                    }
                rationales = dict(event.get("reviewer_rationales") or {})
                if rationales:
                    event["reviewer_rationales"] = {
                        reviewer_migration_map.get(str(reviewer_id), str(reviewer_id)): rationale
                        for reviewer_id, rationale in rationales.items()
                    }
                participant_verdicts = dict(event.get("participant_verdicts") or {})
                if participant_verdicts:
                    event["participant_verdicts"] = {
                        reviewer_migration_map.get(str(participant_id), str(participant_id)): verdict
                        for participant_id, verdict in participant_verdicts.items()
                    }
                participant_rationales = dict(event.get("participant_rationales") or {})
                if participant_rationales:
                    event["participant_rationales"] = {
                        reviewer_migration_map.get(str(participant_id), str(participant_id)): rationale
                        for participant_id, rationale in participant_rationales.items()
                    }

    # v3 → v4: reviewer_* review-event fields become participant_*
    if version < 4:
        for event in group.get("review_events", []) or []:
            if "participant_verdicts" not in event and "reviewer_verdicts" in event:
                event["participant_verdicts"] = dict(event.pop("reviewer_verdicts") or {})
            if "participant_rationales" not in event and "reviewer_rationales" in event:
                event["participant_rationales"] = dict(event.pop("reviewer_rationales") or {})

    # v4 → v5: legacy prompt key becomes group_prompt; rekey in-flight
    # participant_resource_states["mission"] → ["group"].
    if version < 5:
        if "group_prompt" not in group:
            group["group_prompt"] = group.pop(_LEGACY_PROMPT_KEY, None)
        else:
            group.pop(_LEGACY_PROMPT_KEY, None)
        for event in group.get("review_events", []) or []:
            resource_states = event.get("participant_resource_states")
            if not isinstance(resource_states, dict):
                continue
            for reviewer_states in resource_states.values():
                if not isinstance(reviewer_states, dict):
                    continue
                if "mission" in reviewer_states and "group" not in reviewer_states:
                    reviewer_states["group"] = reviewer_states.pop("mission")

    # v5 → v6: split reviewer participant `path` (was prompt-file path) into
    # `prompt` (reviewer markdown) + `path` (cwd, aligned with supervisor).
    if version < 6:
        for p in group.get("participants", []) or []:
            if p.get("role") != "reviewer":
                continue
            if "prompt" in p:
                continue
            legacy_path = p.get("path")
            if isinstance(legacy_path, str) and legacy_path.endswith(".md"):
                p["prompt"] = legacy_path
                p["path"] = None

    group["schema_version"] = SCHEMA_VERSION
    return True  # always re-save to persist schema_version


def load_group(name: str) -> dict[str, Any] | None:
    _ensure_dirs()
    f = _group_file(name)
    if not f.exists():
        return None
    group = json.loads(f.read_text())
    if _migrate_group_shape(group):
        save_group(name, group)
    validate_group(group)
    return group


def save_group(name: str, group: dict[str, Any]) -> None:
    _ensure_dirs()
    atomic_write_text(_group_file(name), json.dumps(group, ensure_ascii=False, indent=2))


def delete_group(name: str) -> bool:
    f = _group_file(name)
    if not f.exists():
        return False
    f.unlink()
    # 清理 per-group 资源目录，但保留 messages/ 以便事后分析。
    # 若清理后外层目录为空（没有 messages/ 需要保留），一并 rmdir 掉，
    # 避免留下空壳目录。
    resource_dir = _group_resource_dir(name)
    if resource_dir.exists():
        for child in resource_dir.iterdir():
            if child.name == "messages":
                continue
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
            else:
                child.unlink(missing_ok=True)
        # next() 拿第一项；空迭代器说明目录已清空，可安全 rmdir
        if next(resource_dir.iterdir(), None) is None:
            resource_dir.rmdir()
    return True


def list_groups() -> list[str]:
    """返回所有 group 名（按文件名排序）。"""
    _ensure_dirs()
    if not _paths.GROUPS_DIR.exists():
        return []
    return sorted(f.stem for f in _paths.GROUPS_DIR.glob("*.json"))


def create_group(
    name: str,
    terminal_type: str = DEFAULT_TERMINAL,
    *,
    default_agent: str | None = None,
    workers_enabled: bool | None = None,
) -> dict[str, Any]:
    """创建新 group，如已存在则报错。"""
    _validate_group_name(name)
    if _group_file(name).exists():
        raise ValueError(f"Group '{name}' 已存在")
    group = new_group(
        name,
        terminal_type=terminal_type,
        default_agent=default_agent,
        workers_enabled=workers_enabled,
    )
    validate_group(group)
    save_group(name, group)
    return group


def delete_all() -> None:
    """清除所有状态（global + groups + signal files）。"""
    from keep._state.globals_ import delete_global
    delete_global()
    if _paths.GROUPS_DIR.exists():
        for f in _paths.GROUPS_DIR.glob("*.json"):
            f.unlink()
            # 对称于 delete_group：同步清掉 per-group 资源目录
            # （transcript.jsonl 等）。ignore_errors 保证清理失败不反向破坏
            # 主流程。
            shutil.rmtree(_group_resource_dir(f.stem), ignore_errors=True)
    if _paths.LEGACY_MISSIONS_DIR.exists():
        shutil.rmtree(_paths.LEGACY_MISSIONS_DIR, ignore_errors=True)
    for f in _paths.STATE_DIR.glob("stop-*"):
        f.unlink()
    # v0.4: submit-* 遗留文件清理（不再使用 UserPromptSubmit hook 确认投递）
    for f in _paths.STATE_DIR.glob("submit-*"):
        f.unlink()


@contextmanager
def mutate_group(name: str) -> Iterator[dict[str, Any]]:
    """Acquire per-group lock, load, yield group for mutation, save on exit.

    Use this for any read-modify-write on group state to prevent
    daemon and CLI from clobbering each other's writes.
    """
    _ensure_dirs()
    lock_path = _group_lock_file(name)
    with FileLock(str(lock_path)):
        group = load_group(name)
        if group is None:
            raise ValueError(f"Group {name!r} 不存在")
        yield group
        save_group(name, group)


def set_group_container(name: str, ref: str) -> None:
    with mutate_group(name) as group:
        group["terminal_container"] = ref


# ── v0.2 migration ────────────────────────────────────────────

_v2_check_done = False


def _migrate_v2() -> None:
    """检测 v0.2 active.json 并迁移为 v0.3 格式。Process-cached: only stat once per run."""
    global _v2_check_done
    if _v2_check_done:
        return
    _v2_check_done = True
    old_file = _paths.STATE_DIR / "active.json"
    if not old_file.exists():
        return
    if _paths.GLOBAL_FILE.exists():
        # 已经迁移过，清理旧文件
        old_file.unlink()
        return

    old = json.loads(old_file.read_text())
    _ensure_dirs()

    # 提取全局信息（v0.4 起不再存 supervisor_surface）
    global_state = new_global()
    global_state["daemon_pid"] = old.get("daemon_pid")

    # 提取 group（用 worker_session 或 "default" 作为名字）
    group_name = old.get("worker_session") or "default"
    # 清理名字中不合法字符
    group_name = re.sub(r"[^a-zA-Z0-9_-]", "-", group_name).strip("-") or "default"

    group = new_group(group_name)
    group["group_prompt"] = old.get(_LEGACY_PROMPT_KEY)

    # 迁移 worker 为 participant(role=worker)
    worker_session = old.get("worker_session")
    if worker_session:
        group["participants"] = [{
            "session": worker_session,
            "role": "worker",
            "cache": old.get("worker_cache"),
        }]

    save_global(global_state)
    save_group(group_name, group)
    old_file.unlink()
