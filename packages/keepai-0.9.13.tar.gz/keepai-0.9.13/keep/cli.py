"""Group CLI — command model v2 (public facade).

Wires the `typer` app tree:

    keep self <show|start|stop|reset|config>
    keep group <create|update|remove|list|show|start|stop|pause|resume>
    keep <group_id> <task|worker|supervisor|reviewer> <verb> ...

Command bodies delegate to `keep._cli.*` sub-modules organised by
responsibility. See `keep/_cli/__init__.py` for the split rationale. Any
test that used to patch `keep.cli.<helper>` should now patch
`keep._cli.<module>.<helper>` (the symbol actually used at call time).
"""

from __future__ import annotations

import logging
import os
import signal
import sys
from importlib.metadata import version as _pkg_version
from pathlib import Path

import click
import typer
from typer.core import TyperGroup

_log = logging.getLogger("keep.cli")

from keep.agent_types import normalize_agent_type
from keep._cli.authority import authorize_group_stop, authorize_operation
from keep._cli.constants import (
    CREATE_HELP,
    GROUP_HELP,
    GROUP_SCOPED_HELP,
    OLD_ROOT_COMMANDS,
    _HELP,
)
from keep._cli.dispatch import dispatch_group_scoped
from keep._cli.helpers import (
    ensure_file_in_messages_dir,
    format_timestamp,
    generate_group_id,
    is_daemon_running,
    load_keep_config,
    require_global,
    require_group_by_name,
    persist_participant_last_message,
    reviewer_covers_event,
    save_keep_config,
)
from keep._daemon.constants import (
    EV_GROUP_STOP,
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
    group_stop_signal_file,
)
from keep._daemon.review import cancel_pending_group_stop
from keep._cli import spawn as _spawn_mod
from keep._cli.spawn import (
    check_stop_hook_or_fail,
    launch_daemon,
)
from keep._state.config import (
    default_agent_global,
    default_terminal_global,
    is_workers_enabled_for_group,
    group_default_agent,
    workers_enabled_global,
)
from keep.state import (
    VALID_TERMINALS,
    create_group,
    delete_all,
    delete_group,
    find_supervisor,
    get_participant,
    get_review_event,
    iter_reviewers,
    iter_workers,
    list_groups,
    list_tasks,
    load_global,
    load_group,
    messages_dir,
    group_terminal_type,
    mutate_group,
    new_global,
    resolve_content,
    save_global,
    save_group,
    task_store_dir,
    update_review_event,
)
from keep._state.content import read_keep_home_text
from keep._state.participants import participant_agent_type
from keep.workflow_policy import ActorRole, OperationName


_REQUIRED_REVIEW_EVENTS = (
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
    EV_GROUP_STOP,
)
_REVIEW_EVENT_LABELS = {
    EV_TASK_PROPOSED_REVIEW: "task_proposed_review",
    EV_TASK_SUBMITTED_REVIEW: "task_submitted_review",
    EV_GROUP_STOP: "group_stop",
}


# ── typer app wiring ──────────────────────────────────────────


class RootGroup(TyperGroup):
    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and args[0].startswith("-"):
            return super().parse_args(ctx, args)
        if args and args[0] not in self.commands and args[0] not in {"-h", "--help"}:
            ctx.meta["group_scoped_args"] = list(args)
            return []
        return super().parse_args(ctx, args)


class GroupCommandGroup(TyperGroup):
    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and args[0] in GROUP_SCOPED_HELP and args[0] not in self.commands:
            ctx.meta["group_help_args"] = list(args)
            return []
        return super().parse_args(ctx, args)


# Non-interactive: disable Rich panels (errors fall back to Click plain text)
_rich_markup_mode = None if not sys.stdout.isatty() else "rich"

app = typer.Typer(
    cls=RootGroup,
    help=_HELP,
    context_settings={"help_option_names": ["-h", "--help"]},
    invoke_without_command=True,
    no_args_is_help=True,
    rich_markup_mode=_rich_markup_mode,
)
self_app = typer.Typer(help="keep 系统管理", rich_markup_mode=_rich_markup_mode)
group_app = typer.Typer(
    cls=GroupCommandGroup,
    help=GROUP_HELP,
    invoke_without_command=True,
    rich_markup_mode=_rich_markup_mode,
)
app.add_typer(self_app, name="self")
app.add_typer(group_app, name="group")


def _version_callback(value: bool) -> None:
    if value:
        for _dist in ("keepai", "keep"):
            try:
                typer.echo(_pkg_version(_dist))
                break
            except Exception:
                pass
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-V", "-v",
        callback=_version_callback, is_eager=True, help="显示版本",
    ),
) -> None:
    if ctx.invoked_subcommand is not None:
        return

    scoped_args = ctx.meta.get("group_scoped_args")
    if not scoped_args:
        return

    group_id = scoped_args[0]
    rest = scoped_args[1:]

    allow_discovery_help = group_id in GROUP_SCOPED_HELP and (
        not rest
        or rest in (["--help"], ["-h"])
        or (len(rest) == 2 and rest[0] == "create" and rest[1] in {"--help", "-h"})
    )
    if group_id in OLD_ROOT_COMMANDS and not allow_discovery_help:
        typer.echo(f"No such command '{group_id}'", err=True)
        raise typer.Exit(2)

    # Discoverability: allow group-scoped help without a concrete group_id,
    # e.g. `keep task --help`, while root subjects remain only self/group.
    if group_id in GROUP_SCOPED_HELP:
        if not rest or rest == ["--help"] or rest == ["-h"]:
            typer.echo(GROUP_SCOPED_HELP[group_id])
            raise typer.Exit()
        if len(rest) == 2 and rest[0] == "create" and rest[1] in {"--help", "-h"} and group_id in CREATE_HELP:
            typer.echo(CREATE_HELP[group_id])
            raise typer.Exit()

    if not rest:
        typer.echo(f"Group '{group_id}' requires a scoped command", err=True)
        raise typer.Exit(2)

    subject = rest[0]
    if len(rest) == 2 and rest[1] in {"--help", "-h"} and subject in GROUP_SCOPED_HELP:
        typer.echo(GROUP_SCOPED_HELP[subject])
        raise typer.Exit()
    if len(rest) == 3 and rest[2] in {"--help", "-h"} and subject in CREATE_HELP and rest[1] == "create":
        typer.echo(CREATE_HELP[subject])
        raise typer.Exit()

    dispatch_group_scoped(group_id, rest)


@group_app.callback()
def group_main(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is not None:
        return

    help_args = ctx.meta.get("group_help_args")
    if not help_args:
        return

    subject = help_args[0]
    if len(help_args) == 2 and help_args[1] in {"--help", "-h"} and subject in GROUP_SCOPED_HELP:
        typer.echo(GROUP_SCOPED_HELP[subject])
        raise typer.Exit()
    if len(help_args) == 3 and help_args[2] in {"--help", "-h"} and subject in CREATE_HELP and help_args[1] == "create":
        typer.echo(CREATE_HELP[subject])
        raise typer.Exit()
    typer.echo(f"No such command '{subject}'", err=True)
    raise typer.Exit(2)


# ── self ──────────────────────────────────────────────────────


@self_app.command("start")
def self_start(
    foreground: bool = typer.Option(False, "-f", "--foreground", help="前台运行 daemon"),
) -> None:
    authorize_operation(OperationName.SELF_START)
    global_state = load_global()
    if global_state is None:
        global_state = new_global()
        save_global(global_state)
    if is_daemon_running(global_state):
        typer.echo("Daemon 已在运行", err=True)
        raise typer.Exit(1)
    launch_daemon(global_state, foreground)


@self_app.command("stop")
def self_stop() -> None:
    authorize_operation(OperationName.SELF_STOP)
    global_state = require_global()
    daemon_pid = global_state.get("daemon_pid")
    if daemon_pid:
        try:
            os.kill(daemon_pid, signal.SIGTERM)
        except (ProcessLookupError, TypeError):
            pass
    global_state["daemon_pid"] = None
    global_state["stopped"] = True
    save_global(global_state)
    typer.echo("Keep 已停止。")


@self_app.command("show")
def self_show() -> None:
    global_state = load_global()
    if global_state is None:
        typer.echo("Keep 未启动。")
        return

    daemon_running = is_daemon_running(global_state)
    if global_state.get("stopped"):
        state_label = "已锁定 (stopped)"
    elif daemon_running:
        state_label = "运行中"
    else:
        state_label = "异常 (daemon 未运行)"

    lines = [f"状态: {state_label}"]
    pid = global_state.get("daemon_pid")
    if pid:
        lines.append(f"Daemon PID: {pid}" + (" (运行中)" if daemon_running else " (已退出)"))

    missions = []
    for name in list_groups():
        group = load_group(name)
        if group is None:
            continue
        missions.append((name, group))

    if not missions:
        lines.append("")
        lines.append("没有 group。用 keep group create 创建（ID 自动生成）。")
    else:
        lines.append("")
        for name, group in missions:
            workers = [worker["session"] for worker in iter_workers(group)]
            supervisor = find_supervisor(group)
            tasks = list_tasks(name)
            done = sum(1 for task in tasks if task["status"] == "completed")
            running = sum(1 for task in tasks if task["status"] == "in_progress")
            pending = sum(1 for task in tasks if task["status"] == "pending")
            workers_text = ", ".join(workers) if workers else "无"
            supervisor_text = supervisor["session"] if supervisor else "(unclaimed)"
            lines.append(
                f"  {name} — supervisor: {supervisor_text} | workers: {workers_text} | tasks: {done} done, {running} running, {pending} pending ({len(tasks)} total)"
            )

    typer.echo("\n".join(lines))


@self_app.command("reset")
def self_reset() -> None:
    authorize_operation(OperationName.SELF_RESET)
    global_state = require_global()

    # Step 1: best-effort close every participant's terminal surface while the
    # daemon is still alive. Mirrors `group_remove`'s teardown path; we delegate
    # to `kill_and_close_worker` rather than re-implementing close logic.
    for group_id in list_groups():
        try:
            group = load_group(group_id)
        except Exception as exc:
            _log.warning("self reset: failed to load group %r, skipping surface close: %s", group_id, exc)
            continue
        if group is None:
            continue
        supervisor = find_supervisor(group)
        if supervisor:
            _spawn_mod.kill_and_close_worker(supervisor, group)
        for worker in iter_workers(group):
            _spawn_mod.kill_and_close_worker(worker, group)
        try:
            reviewers = list(iter_reviewers(group_id))
        except ValueError as exc:
            _log.warning("self reset: failed to iter reviewers for %r: %s", group_id, exc)
            reviewers = []
        for reviewer in reviewers:
            _spawn_mod.kill_and_close_worker(reviewer, group)

    # Step 2: terminate daemon so it can't race us while we clear state below.
    daemon_pid = global_state.get("daemon_pid")
    if daemon_pid:
        try:
            os.kill(daemon_pid, signal.SIGTERM)
        except (ProcessLookupError, TypeError):
            pass

    # Step 3: wipe group + global state.
    delete_all()

    # Step 4: `delete_all()` doesn't touch daemon runtime state — remove it here
    # so a fresh daemon starts with an empty in-memory model.
    from keep._daemon.constants import RUNTIME_STATE_FILE
    RUNTIME_STATE_FILE.unlink(missing_ok=True)

    typer.echo("Keep 已重置，所有状态已清除。")


@self_app.command("config")
def self_config(
    terminal: str = typer.Option("", "--terminal", help="Default terminal: cmux, tmux, terminal, kitty, iterm2"),
    agent: str = typer.Option("", "--agent", help="Default agent: claude-code or codex"),
    workers_enabled: str = typer.Option("", "--workers-enabled", help="Default workers mode: true or false"),
) -> None:
    """Show or update keep-level default configuration."""
    if terminal or agent or workers_enabled:
        authorize_operation(OperationName.SELF_CONFIG)
    config = load_keep_config()
    updates = 0

    if terminal:
        if terminal not in VALID_TERMINALS:
            typer.echo(f"Invalid terminal '{terminal}'. Choose from: {', '.join(sorted(VALID_TERMINALS))}", err=True)
            raise typer.Exit(1)
        config["default_terminal"] = terminal
        config.pop("terminal", None)
        updates += 1

    if agent:
        try:
            resolved_agent = normalize_agent_type(agent)
        except ValueError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(1)
        config["default_agent"] = resolved_agent
        updates += 1

    workers_enabled_value = _parse_workers_enabled_override_or_fail(
        workers_enabled=workers_enabled,
        no_workers=False,
        allow_none=True,
        context_label="workers-enabled",
    )
    if workers_enabled_value is not None:
        config["workers_enabled"] = workers_enabled_value
        updates += 1

    if updates:
        save_keep_config(config)
        typer.echo("Keep defaults updated.")

    typer.echo("\n".join(_self_config_lines()))
    prereqs = {
        "cmux": "CMUX: Settings → Socket Control → set to 'Automation Mode'",
        "tmux": "TMUX: no prerequisites",
        "terminal": "Terminal.app: System Settings → Privacy → Accessibility (grant permission to your shell/terminal)",
        "kitty": "Kitty: add 'allow_remote_control yes' and 'listen_on unix:/tmp/kitty.sock' to ~/.config/kitty/kitty.conf",
        "iterm2": "iTerm2: System Settings → Privacy → Automation (grant permission to your shell/terminal to control iTerm)",
    }
    if terminal:
        typer.echo(f"Prerequisites: {prereqs[terminal]}")


# ── group ─────────────────────────────────────────────────────


@group_app.command("create")
def group_create(
    terminal: str = typer.Option("", "--terminal", help="Terminal type: cmux|tmux|terminal|kitty|iterm2"),
    agent: str = typer.Option("", "--agent", help="Default agent: claude-code|codex"),
    workers_enabled: str = typer.Option("", "--workers-enabled", help="Workers mode: true|false"),
    no_workers: bool = typer.Option(False, "--no-workers", help="Disable workers for this group (workers_enabled=false)"),
) -> None:
    authorize_operation(OperationName.GROUP_CREATE)
    require_global()
    # Resolve terminal: explicit flag > keep default > internal fallback
    if terminal:
        if terminal not in VALID_TERMINALS:
            typer.echo(f"Invalid terminal '{terminal}'. Choose from: {', '.join(sorted(VALID_TERMINALS))}", err=True)
            raise typer.Exit(1)
        resolved_terminal = terminal
    else:
        resolved_terminal = default_terminal_global()
    if agent:
        try:
            resolved_agent = normalize_agent_type(agent)
        except ValueError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(1)
    else:
        resolved_agent = default_agent_global()
    workers_enabled_flag = _parse_workers_enabled_override_or_fail(
        workers_enabled=workers_enabled,
        no_workers=no_workers,
        allow_none=True,
        context_label="workers-enabled",
    )
    resolved_workers_enabled = (
        workers_enabled_flag
        if workers_enabled_flag is not None
        else workers_enabled_global()
    )
    group_id = generate_group_id()
    try:
        create_group(
            group_id,
            terminal_type=resolved_terminal,
            default_agent=resolved_agent,
            workers_enabled=resolved_workers_enabled,
        )
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(
        f"Group '{group_id}' 已创建。"
        f"(terminal: {resolved_terminal}, agent: {resolved_agent}, "
        f"workers_enabled={str(resolved_workers_enabled).lower()})"
    )


@group_app.command("update")
def group_update(
    group_id: str = typer.Argument(...),
    prompt: str = typer.Argument(""),
    terminal: str = typer.Option("", "--terminal", help="Change terminal type: cmux|tmux|terminal|kitty|iterm2"),
    agent: str = typer.Option("", "--agent", help="Change default agent: claude-code|codex"),
    workers_enabled: str = typer.Option("", "--workers-enabled", help="Change workers mode: true|false"),
    no_workers: bool = typer.Option(False, "--no-workers", help="Alias for --workers-enabled false"),
) -> None:
    authorize_operation(OperationName.GROUP_UPDATE, group_id=group_id)
    require_global()
    require_group_by_name(group_id)
    workers_enabled_value = _parse_workers_enabled_override_or_fail(
        workers_enabled=workers_enabled,
        no_workers=no_workers,
        allow_none=True,
        context_label="workers-enabled",
    )
    if not prompt and not terminal and not agent and workers_enabled_value is None:
        typer.echo("Nothing to update. Provide a prompt or one of --terminal/--agent/--workers-enabled.", err=True)
        raise typer.Exit(1)
    if terminal and terminal not in VALID_TERMINALS:
        typer.echo(f"Invalid terminal '{terminal}'. Choose from: {', '.join(sorted(VALID_TERMINALS))}", err=True)
        raise typer.Exit(1)
    resolved_agent: str | None = None
    if agent:
        try:
            resolved_agent = normalize_agent_type(agent)
        except ValueError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(1)
    with mutate_group(group_id) as group:
        if prompt:
            group["group_prompt"] = prompt
        if terminal:
            group["terminal_type"] = terminal
        if resolved_agent is not None:
            group["default_agent"] = resolved_agent
        if workers_enabled_value is not None:
            group["workers_enabled"] = workers_enabled_value
    typer.echo(f"Group '{group_id}' 已更新。")
    # Signal daemon to sync updated group to reviewers
    from keep.daemon import group_sync_signal_file
    group_sync_signal_file(group_id).write_text("")


@group_app.command("remove")
def group_remove(group_id: str = typer.Argument(...)) -> None:
    authorize_operation(OperationName.GROUP_REMOVE, group_id=group_id)
    require_global()
    group = load_group(group_id)
    worker_sessions: list[str] = []
    if group is not None:
        supervisor = find_supervisor(group)
        if supervisor:
            worker_sessions.append(supervisor["session"])
            _spawn_mod.kill_and_close_worker(supervisor, group)
            typer.echo(f"  Supervisor {supervisor['session'][:8]} closed")
        workers = list(iter_workers(group))
        if workers:
            worker_sessions.extend(w["session"] for w in workers)
            for w in workers:
                _spawn_mod.kill_and_close_worker(w, group)
            typer.echo(f"  {len(workers)} worker{'s' if len(workers) > 1 else ''} closed")
        reviewers = list(iter_reviewers(group_id))
        if reviewers:
            for r in reviewers:
                if r.get("session"):
                    worker_sessions.append(r["session"])
                _spawn_mod.kill_and_close_worker(r, group)
                typer.echo(f"  Reviewer {r.get('name', r['id'])} ({r['id'][:8]}) closed")
        ref = group.get("terminal_container")
        if ref:
            try:
                from keep.terminal import get_terminal
                get_terminal(group_terminal_type(group)).close_group_container(ref)
            except Exception as exc:
                _log.warning("close_group_container %r: %s", ref, exc)
    if not delete_group(group_id):
        typer.echo(f"Group '{group_id}' 不存在", err=True)
        raise typer.Exit(1)
    from keep._daemon import runtime_state as _rt
    _rt.purge_group(group_id, worker_sessions)
    typer.echo(f"  Group {group_id} deleted")


@group_app.command("list")
@group_app.command("ls")
def group_list() -> None:
    require_global()
    names = list_groups()
    if not names:
        typer.echo("没有 group。")
        return
    lines = ["Groups:"]
    for name in names:
        group = load_group(name)
        if group is None:
            continue
        task_count = len(list_tasks(name))
        lines.append(f"  {name} — {len(iter_workers(group))} workers, {task_count} tasks")
    typer.echo("\n".join(lines))


@group_app.command("show")
def group_show(group_id: str = typer.Argument(...)) -> None:
    require_global()
    group = require_group_by_name(group_id)
    lines = [f"Group '{group_id}':"]
    lines.append(f"  状态: {group['status']}")
    lines.append(f"  Terminal: {group_terminal_type(group)}")
    lines.append(f"  Default Agent: {group_default_agent(group)}")
    lines.append(
        f"  Workers Enabled: {str(is_workers_enabled_for_group(group)).lower()}"
    )
    lines.append(f"  创建时间: {format_timestamp(group.get('created_at'))}")
    prompt = group.get("group_prompt")
    lines.append(f"  Prompt: {resolve_content(prompt) if prompt else '(未设置)'}")
    lines.append(f"  Tasks dir: {task_store_dir(group_id)}")
    typer.echo("\n".join(lines))


@group_app.command("start")
def group_start(group_id: str = typer.Argument(...)) -> None:
    authorize_operation(OperationName.GROUP_START, group_id=group_id)
    require_global()
    group = require_group_by_name(group_id)

    # Pre-flight: verify stop hook is wired up
    # Pre-flight checks: require supervisor AND at least one reviewer
    supervisor = find_supervisor(group)
    try:
        reviewers = list(iter_reviewers(group_id))
    except ValueError:
        reviewers = []

    missing: list[str] = []
    if not supervisor:
        missing.append(
            f"  注册 Supervisor: keep {group_id} supervisor create --name <session>"
        )
    if not reviewers:
        missing.append(
            f"  添加 Reviewer:   keep {group_id} reviewer create --name <name>"
        )
    else:
        missing_review_events = _missing_review_events(reviewers)
        for event_type in missing_review_events:
            label = _REVIEW_EVENT_LABELS[event_type]
            missing.append(
                f"  Reviewer 覆盖缺失: {label} 需要至少一个 reviewer 处理"
            )
    if missing:
        typer.echo(
            f"Group '{group_id}' 无法启动：需要 Supervisor，且 3 个 review 事件都至少有一个 reviewer 覆盖。\n"
            + "\n".join(missing),
            err=True,
        )
        raise typer.Exit(1)

    agent_types = {
        participant_agent_type(supervisor),
        *(normalize_agent_type(r.get("agent_type")) for r in reviewers),
    }
    check_stop_hook_or_fail(agent_types)

    group["status"] = "active"
    save_group(group_id, group)
    cancel_pending_group_stop(group_id)
    typer.echo(f"Group '{group_id}' 已启动。\n")

    issues: list[str] = []

    sup_label = supervisor.get("name") or supervisor.get("session", "?")
    typer.secho(f"  ✓ Supervisor: {sup_label}", fg=typer.colors.GREEN)

    if reviewers:
        reviewer_labels = ", ".join(r.get("name") or r.get("id", "?") for r in reviewers)
        typer.secho(f"  ✓ Reviewers ({len(reviewers)}): {reviewer_labels}", fg=typer.colors.GREEN)
        coverage = _review_event_coverage(reviewers)
        coverage_summary = "; ".join(
            f"{_REVIEW_EVENT_LABELS[event_type]}="
            + ",".join(coverage[event_type])
            for event_type in _REQUIRED_REVIEW_EVENTS
        )
        typer.secho(f"  ✓ Review Coverage: {coverage_summary}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Reviewers: 无", fg=typer.colors.YELLOW)
        issues.append(f"无 Reviewer——task 送审后无人判决。添加：keep {group_id} reviewer create --name <name>")

    workers = iter_workers(group)
    workers_enabled = is_workers_enabled_for_group(group)
    if not workers_enabled:
        typer.secho("  ✓ Workers: disabled by config (workers_enabled=false)", fg=typer.colors.GREEN)
    elif workers:
        labels = ", ".join(w.get("name") or w.get("session", "?") for w in workers)
        typer.secho(f"  ✓ Workers ({len(workers)}): {labels}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Workers: 无", fg=typer.colors.YELLOW)
        issues.append("无 Worker——无法执行任务")

    tasks = list_tasks(group_id)
    pending = [t for t in tasks if t.get("status") not in {"completed", "deleted"}]
    if tasks:
        typer.secho(f"  ✓ Tasks: {len(pending)} pending / {len(tasks)} total", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Tasks: 无", fg=typer.colors.YELLOW)
        issues.append("Task 队列为空——Supervisor 收到 start 后无任务可推进")

    if issues:
        typer.echo("")
        for issue in issues:
            typer.secho(f"  ⚠  {issue}", fg=typer.colors.YELLOW)


@group_app.command("stop")
def group_stop(
    group_id: str = typer.Argument(...),
    rationale: str | None = typer.Option(None, "--rationale", help="停止原因文件路径（说明 group 为何完成）"),
    status: str | None = typer.Option(None, "--status", help="reviewer 决策状态：stopped 或 active"),
    force: bool = typer.Option(False, "--force", help="跳过 reviewer 审批，直接强制停止"),
) -> None:
    require_global()
    group = require_group_by_name(group_id)

    decision = authorize_group_stop(
        group_id,
        group,
        force=force,
    )
    actor = decision.actor
    desired_status = status or "stopped"

    if force and desired_status != "stopped":
        typer.echo("--force 只允许与 stopped 一起使用。", err=True)
        raise typer.Exit(2)

    if force:
        group["status"] = "stopped"
        save_group(group_id, group)
        cancel_pending_group_stop(group_id)
        typer.echo(f"Group '{group_id}' 已强制停止。")
        return

    if actor.role == ActorRole.REVIEWER:
        if desired_status not in {"stopped", "active"}:
            typer.echo("--status 只允许 stopped 或 active。", err=True)
            raise typer.Exit(2)
        reviewer = get_participant(group_id, str(actor.participant_session or ""), role="reviewer")
        rationale_path = None
        if rationale is not None:
            rationale_path = str(
                ensure_file_in_messages_dir(
                    group,
                    rationale,
                    label="rationale file",
                    record_index=True,
                )
            )
        else:
            rationale_path = persist_participant_last_message(
                group_id,
                reviewer,
                event_type="reviewer_last_message",
            )
        event_id = _record_reviewer_group_stop_decision(
            group_id,
            group,
            reviewer_id=str(actor.participant_session or ""),
            group_status=desired_status,
            rationale_path=str(rationale_path or ""),
        )
        typer.echo(f"审批已记录：group -> {desired_status}（batch {event_id}）。等待结算。")
        return

    if desired_status != "stopped":
        typer.echo("supervisor 发起 group stop 时 --status 只能是 stopped。", err=True)
        raise typer.Exit(2)

    # When reviewers are configured, delegate stop decision to daemon/reviewers.
    try:
        reviewers = list(iter_reviewers(group_id))
    except ValueError:
        reviewers = []

    if reviewers and group.get("status") != "stopped":
        rationale_path: str | None = None
        if rationale is not None:
            rationale_path = str(
                ensure_file_in_messages_dir(
                    group,
                    rationale,
                    label="rationale file",
                    record_index=True,
                )
            )
        _request_group_stop_review(group_id, group, rationale_path)
        return

    # No reviewers or already stopped — stop immediately.
    group["status"] = "stopped"
    save_group(group_id, group)
    typer.echo(f"Group '{group_id}' 已停止。")


def _has_open_group_stop_request(group: dict) -> bool:
    return any(
        event.get("type") == EV_GROUP_STOP and not event.get("final_verdict")
        for event in group.get("review_events", [])
    )


def _open_group_stop_event(group_id: str, group: dict) -> tuple[str, dict]:
    matches = [
        event
        for event in group.get("review_events", [])
        if event.get("type") == EV_GROUP_STOP and not event.get("final_verdict")
    ]
    if len(matches) != 1:
        typer.echo(
            f"Group '{group_id}' 当前没有唯一的待审批 group stop，reviewer 不能直接行权。",
            err=True,
        )
        raise typer.Exit(1)
    event = matches[0]
    return str(event["id"]), get_review_event(group_id, str(event["id"]))


def _record_reviewer_group_stop_decision(
    group_id: str,
    group: dict,
    *,
    reviewer_id: str,
    group_status: str,
    rationale_path: str,
) -> str:
    event_id, event = _open_group_stop_event(group_id, group)
    reviewer = get_participant(group_id, reviewer_id, role="reviewer")
    if not reviewer_covers_event(reviewer, EV_GROUP_STOP):
        typer.echo(
            f"reviewer '{reviewer_id[:8]}' 未覆盖 group_stop，不能审批该事项。",
            err=True,
        )
        raise typer.Exit(1)
    resource_states = dict(event.get("participant_resource_states") or {})
    resource_states[reviewer_id] = {"group": group_status}
    rationales = dict(event.get("participant_rationales") or {})
    rationales[reviewer_id] = rationale_path
    update_review_event(
        group_id,
        event_id,
        participant_resource_states=resource_states,
        participant_rationales=rationales,
    )
    return event_id


def _request_group_stop_review(group_id: str, group: dict, rationale: str | None) -> None:
    """Request a group_stop review and return immediately."""
    signal_path = group_stop_signal_file(group_id)
    if signal_path.exists() or _has_open_group_stop_request(group):
        typer.echo(
            f"Group '{group_id}' 已有未结算的 group stop 审批；等待 review_result 后再决定下一轮。",
            err=True,
        )
        raise typer.Exit(1)
    signal_path.write_text(rationale or "", encoding="utf-8")
    typer.echo(
        f"你无权直接停止 group '{group_id}'；系统已上报给有权限的 reviewer 审批。等待后续 review_result。"
    )


@group_app.command("pause")
def group_pause(group_id: str = typer.Argument(...)) -> None:
    """暂停 group：daemon 停止事件检测，supervisor send 仍可用。"""
    authorize_operation(OperationName.GROUP_PAUSE, group_id=group_id)
    require_global()
    group = require_group_by_name(group_id)
    if group.get("status") == "paused":
        typer.echo(f"Group '{group_id}' 已经是暂停状态。")
        return
    if group.get("status") == "stopped":
        typer.echo(f"Group '{group_id}' 已停止，无法暂停。", err=True)
        raise typer.Exit(1)
    group["status"] = "paused"
    save_group(group_id, group)
    typer.echo(f"Group '{group_id}' 已暂停。daemon 事件检测已停止，supervisor send 仍可用。")


@group_app.command("resume")
def group_resume(group_id: str = typer.Argument(...)) -> None:
    """恢复 group：从 paused 状态回到 active。"""
    authorize_operation(OperationName.GROUP_RESUME, group_id=group_id)
    require_global()
    group = require_group_by_name(group_id)
    if group.get("status") != "paused":
        typer.echo(f"Group '{group_id}' 不在暂停状态（当前：{group.get('status')}）。", err=True)
        raise typer.Exit(1)
    group["status"] = "active"
    save_group(group_id, group)
    typer.echo(f"Group '{group_id}' 已恢复。")


def _reviewer_rationale_text(event: dict) -> str:
    parts: list[str] = []
    resource_states = dict(event.get("participant_resource_states") or {})
    verdicts = dict(event.get("participant_verdicts") or {})
    for reviewer_id, rationale_path in dict(event.get("participant_rationales") or {}).items():
        reviewer_state = resource_states.get(reviewer_id)
        returned = isinstance(reviewer_state, dict) and reviewer_state.get("group") == "active"
        if not returned and verdicts.get(reviewer_id) != "reject":
            continue
        rationale_text = read_keep_home_text(
            rationale_path,
            missing_message="(rationale file not found: {path})",
            outside_message="(blocked: outside KEEP_HOME: {path})",
        )
        parts.append(f"\n[{reviewer_id}] {rationale_text}")
    if parts:
        return "".join(parts)

    rationale_path = event.get("rationale", "")
    if not rationale_path:
        return ""
    return "\n" + read_keep_home_text(
        rationale_path,
        missing_message="(rationale file not found: {path})",
        outside_message="(blocked: outside KEEP_HOME: {path})",
    )


def _reviewer_covers_event(reviewer: dict, event_type: str) -> bool:
    triggers = reviewer.get("triggers")
    if triggers is None:
        return True
    return event_type in triggers


def _review_event_coverage(reviewers: list[dict]) -> dict[str, list[str]]:
    coverage: dict[str, list[str]] = {event_type: [] for event_type in _REQUIRED_REVIEW_EVENTS}
    for reviewer in reviewers:
        label = reviewer.get("name") or reviewer.get("id", "?")
        for event_type in _REQUIRED_REVIEW_EVENTS:
            if _reviewer_covers_event(reviewer, event_type):
                coverage[event_type].append(label)
    return coverage


def _missing_review_events(reviewers: list[dict]) -> list[str]:
    coverage = _review_event_coverage(reviewers)
    return [event_type for event_type in _REQUIRED_REVIEW_EVENTS if not coverage[event_type]]


# Keep `messages_dir` re-export for any historical importer. Otherwise unused.
__all__ = ["app", "messages_dir"]


def _parse_workers_enabled_override_or_fail(
    *,
    workers_enabled: str,
    no_workers: bool,
    allow_none: bool,
    context_label: str,
) -> bool | None:
    if no_workers and workers_enabled:
        typer.echo(f"Cannot combine --no-workers with --{context_label}.", err=True)
        raise typer.Exit(1)
    if no_workers:
        return False
    if not workers_enabled:
        if allow_none:
            return None
        typer.echo(f"--{context_label} is required", err=True)
        raise typer.Exit(1)
    lower = workers_enabled.lower()
    if lower not in {"true", "false", "1", "0", "yes", "no"}:
        typer.echo(
            f"Invalid value '{workers_enabled}' for {context_label}. Use: true or false",
            err=True,
        )
        raise typer.Exit(1)
    return lower in {"true", "1", "yes"}


def _self_config_lines() -> list[str]:
    return [
        "Keep Defaults:",
        f"  Default Terminal: {default_terminal_global()}",
        f"  Default Agent: {default_agent_global()}",
        f"  Workers Enabled: {str(workers_enabled_global()).lower()}",
    ]


if __name__ == "__main__":
    app()
