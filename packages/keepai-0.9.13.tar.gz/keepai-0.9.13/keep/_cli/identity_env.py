"""Minimal keep participant environment helpers.

Environment identity only answers one question: how does a process locate its
own keep participant record? The stable answer is:

    KEEP_GROUP_ID + KEEP_PARTICIPANT_SESSION
"""

from __future__ import annotations

import os
import shlex
from dataclasses import dataclass
from pathlib import Path

import typer

ENV_KEEP_GROUP_ID = "KEEP_GROUP_ID"
ENV_KEEP_PARTICIPANT_SESSION = "KEEP_PARTICIPANT_SESSION"
ENV_KEEP_OPERATOR_ROLE = "KEEP_OPERATOR_ROLE"


@dataclass(frozen=True)
class KeepProcessIdentity:
    group_id: str | None = None
    participant_session: str | None = None
    operator_role: str | None = None

    def has_keep_env(self) -> bool:
        return bool(self.group_id or self.participant_session or self.operator_role)


def current_keep_identity() -> KeepProcessIdentity:
    return KeepProcessIdentity(
        group_id=os.environ.get(ENV_KEEP_GROUP_ID) or None,
        participant_session=os.environ.get(ENV_KEEP_PARTICIPANT_SESSION) or None,
        operator_role=os.environ.get(ENV_KEEP_OPERATOR_ROLE) or None,
    )


def build_participant_env(
    *,
    group_id: str,
    participant_session: str,
) -> dict[str, str]:
    env = {
        ENV_KEEP_GROUP_ID: group_id,
        ENV_KEEP_PARTICIPANT_SESSION: participant_session,
    }
    for passthrough in ("KEEP_HOME", "HOME"):
        value = os.environ.get(passthrough)
        if value:
            env[passthrough] = value
    pythonpath = os.environ.get("PYTHONPATH")
    if pythonpath:
        entries: list[str] = []
        cwd = Path.cwd()
        for entry in pythonpath.split(os.pathsep):
            if not entry:
                continue
            path = Path(entry)
            if not path.is_absolute():
                path = (cwd / path).resolve()
            entries.append(str(path))
        if entries:
            env["PYTHONPATH"] = os.pathsep.join(entries)
    return env


def shell_env_prefix(env: dict[str, str] | None) -> str:
    if not env:
        return ""
    exports = "; ".join(
        f"export {key}={shlex.quote(value)}"
        for key, value in env.items()
    )
    return exports + "; "


def resolve_current_participant_session(group_id: str) -> str | None:
    ident = current_keep_identity()
    if not ident.has_keep_env():
        return None
    if ident.group_id != group_id:
        typer.echo(
            f"当前 keep participant 属于 group '{ident.group_id or 'unknown'}'，"
            f"不是 '{group_id}'。",
            err=True,
        )
        raise typer.Exit(1)
    if not ident.participant_session:
        typer.echo(
            f"当前 participant 缺少 {ENV_KEEP_PARTICIPANT_SESSION}，"
            "请获取正确环境变量后重启该 participant。",
            err=True,
        )
        raise typer.Exit(1)
    return ident.participant_session
