"""Central collaborative authority / invariant validation layer.

This layer resolves the current actor from keep env, applies typed command
policies, and validates workflow invariants around task / group transitions.
"""

from __future__ import annotations

import typer
from pydantic import BaseModel, ConfigDict

from keep._cli.helpers import (
    require_group_active,
    require_group_event_processing_active,
    require_reviewer_event_coverage,
)
from keep._cli.identity_env import current_keep_identity, resolve_current_participant_session
from keep.state import get_participant
from keep._state.participants import participant_model
from keep.workflow_policy import (
    ActorIdentity,
    ActorRole,
    CollaborativeOperationPolicy,
    COLLABORATIVE_OPERATION_POLICIES,
    GROUP_STOP_POLICY,
    GroupReviewTransition,
    OperationName,
    TaskReviewTransition,
    TaskStatus,
    get_task_review_transition,
    get_task_status_command_policy,
    task_status_mutation_allowed,
)


class AuthorizationDecision(BaseModel):
    model_config = ConfigDict(frozen=True)

    actor: ActorIdentity
    task_review_transition: TaskReviewTransition | None = None
    group_review_transition: GroupReviewTransition | None = None


def resolve_actor_identity(group_id: str) -> ActorIdentity:
    ident = current_keep_identity()
    participant_session = resolve_current_participant_session(group_id)
    if participant_session is None:
        if ident.operator_role == ActorRole.OPERATOR.value:
            return ActorIdentity(
                role=ActorRole.OPERATOR,
                source="human_cli",
            )
        return ActorIdentity(
            role=ActorRole.HUMAN,
            source="human_cli",
        )
    participant = get_participant(group_id, participant_session)
    participant_view = participant_model(participant)
    return ActorIdentity(
        role=ActorRole(participant_view.role),
        group_id=group_id,
        participant_session=participant_session,
        source="participant_env",
    )


def resolve_global_actor_identity() -> ActorIdentity:
    ident = current_keep_identity()
    if not ident.has_keep_env():
        return ActorIdentity(
            role=ActorRole.HUMAN,
            source="human_cli",
        )
    if ident.operator_role == ActorRole.OPERATOR.value:
        return ActorIdentity(
            role=ActorRole.OPERATOR,
            source="human_cli",
        )
    if not ident.group_id or not ident.participant_session:
        typer.echo("当前 keep env 不完整，无法识别操作者。", err=True)
        raise typer.Exit(1)
    participant = get_participant(ident.group_id, ident.participant_session)
    participant_view = participant_model(participant)
    return ActorIdentity(
        role=ActorRole(participant_view.role),
        group_id=ident.group_id,
        participant_session=ident.participant_session,
        source="participant_env",
    )


def _deny(intent: OperationName, actor: ActorIdentity) -> None:
    if actor.role == ActorRole.HUMAN:
        who = "当前 shell"
    else:
        who = f"{actor.role.value} {actor.participant_session}"
    typer.echo(
        f"{who} 无权执行 {intent.value}。",
        err=True,
    )
    raise typer.Exit(1)


def _require_policy(intent: OperationName, actor: ActorIdentity) -> CollaborativeOperationPolicy:
    policy = COLLABORATIVE_OPERATION_POLICIES[intent]
    if actor.role not in policy.allowed_roles:
        _deny(intent, actor)
    return policy


def authorize_operation(
    operation: OperationName,
    *,
    group_id: str | None = None,
) -> ActorIdentity:
    actor = resolve_actor_identity(group_id) if group_id is not None else resolve_global_actor_identity()
    _require_policy(operation, actor)
    return actor


def authorize_task_operation(
    group_id: str,
    group: dict,
    *,
    operation: OperationName,
    target_status: str | None = None,
    needs_review: bool = False,
    tasks: list[dict] | None = None,
    patch_keys: set[str] | None = None,
) -> AuthorizationDecision:
    actor = resolve_actor_identity(group_id)
    _require_policy(operation, actor)

    if operation in {
        OperationName.TASK_CREATE,
        OperationName.TASK_UPDATE,
    }:
        require_group_active(group_id, group)

    if actor.role == ActorRole.REVIEWER:
        extra_keys = set(patch_keys or set()) - {"status"}
        if extra_keys:
            typer.echo(
                "reviewer 只能用 task update --status ... 对已有审批事项行权，"
                f"不能更新字段: {', '.join(sorted(extra_keys))}",
                err=True,
            )
            raise typer.Exit(1)
        if target_status is None:
            typer.echo("reviewer 的 task update 必须带 --status。", err=True)
            raise typer.Exit(1)
        return AuthorizationDecision(actor=actor)

    review_transition = get_task_review_transition(target_status) if needs_review else None
    command_policy = get_task_status_command_policy(target_status) if needs_review else None
    if review_transition is not None and command_policy is not None:
        require_group_event_processing_active(
            group_id,
            group,
            command=f"task update --status {target_status}",
        )
        if tasks is not None:
            invalid = [
                f"#{task['id']}[{task.get('status')}]"
                for task in tasks
                if task.get("status") != command_policy.required_source_status.value
            ]
            if invalid:
                typer.echo(
                    f"task update --status {review_transition.target_status.value} requires tasks currently in "
                    f"{command_policy.required_source_status.value}: " + ", ".join(invalid),
                    err=True,
                )
                raise typer.Exit(1)
        if actor.role not in command_policy.command_roles:
            _deny(operation, actor)
        require_reviewer_event_coverage(
            group_id,
            command_policy.review_event_type.value,
        )
    elif target_status is not None and tasks is not None:
        invalid = [
            f"#{task['id']}[{task.get('status')}]"
            for task in tasks
            if not task_status_mutation_allowed(
                actor_role=actor.role,
                source_status=task.get("status"),
                target_status=target_status,
            )
        ]
        if invalid:
            typer.echo(
                f"{actor.role.value} 无权将 task 状态改为 {target_status}: " + ", ".join(invalid),
                err=True,
            )
            raise typer.Exit(1)

    return AuthorizationDecision(
        actor=actor,
        task_review_transition=review_transition,
    )


def authorize_group_stop(
    group_id: str,
    group: dict,
    *,
    force: bool,
) -> AuthorizationDecision:
    actor = resolve_actor_identity(group_id)
    intent = OperationName.GROUP_STOP_FORCE if force else OperationName.GROUP_STOP
    _require_policy(intent, actor)
    if force:
        return AuthorizationDecision(
            actor=actor,
            group_review_transition=GroupReviewTransition(),
        )

    if actor.role == ActorRole.REVIEWER:
        require_group_event_processing_active(
            group_id,
            group,
            command="group stop",
        )
        return AuthorizationDecision(
            actor=actor,
            group_review_transition=GroupReviewTransition(),
        )

    require_group_event_processing_active(
        group_id,
        group,
        command="group stop",
    )
    if actor.role not in GROUP_STOP_POLICY.command_roles:
        _deny(intent, actor)
    require_reviewer_event_coverage(
        group_id,
        GroupReviewTransition().review_event_type.value,
    )
    return AuthorizationDecision(
        actor=actor,
        group_review_transition=GroupReviewTransition(),
    )
