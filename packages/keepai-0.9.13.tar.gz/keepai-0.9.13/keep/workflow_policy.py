"""Typed workflow policy models shared by CLI and daemon.

This module is the single source of truth for:

- actor roles in the collaborative workflow
- reviewable task / group transitions
- high-level operation policies for collaborative commands
"""

from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict


class ActorRole(str, Enum):
    HUMAN = "human"
    OPERATOR = "operator"
    SUPERVISOR = "supervisor"
    REVIEWER = "reviewer"
    WORKER = "worker"


class ReviewEventType(str, Enum):
    TASK_PROPOSED_REVIEW = "task_proposed_review"
    TASK_SUBMITTED_REVIEW = "task_submitted_review"
    GROUP_STOP = "group_stop"


class TaskStatus(str, Enum):
    PROPOSED = "proposed"
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    DELETED = "deleted"


class OperationName(str, Enum):
    SELF_START = "self.start"
    SELF_STOP = "self.stop"
    SELF_RESET = "self.reset"
    SELF_CONFIG = "self.config"
    GROUP_CREATE = "group.create"
    GROUP_UPDATE = "group.update"
    GROUP_REMOVE = "group.remove"
    GROUP_START = "group.start"
    TASK_CREATE = "task.create"
    TASK_UPDATE = "task.update"
    TASK_REMOVE = "task.remove"
    GROUP_PAUSE = "group.pause"
    GROUP_RESUME = "group.resume"
    GROUP_STOP = "group.stop"
    GROUP_STOP_FORCE = "group.stop.force"
    SUPERVISOR_CREATE = "supervisor.create"
    SUPERVISOR_UPDATE = "supervisor.update"
    SUPERVISOR_REMOVE = "supervisor.remove"
    SUPERVISOR_SEND = "supervisor.send"
    SUPERVISOR_READ = "supervisor.read"
    SUPERVISOR_WAKE = "supervisor.wake"
    WORKER_CREATE = "worker.create"
    WORKER_UPDATE = "worker.update"
    WORKER_REMOVE = "worker.remove"
    REVIEWER_CREATE = "reviewer.create"
    REVIEWER_UPDATE = "reviewer.update"
    REVIEWER_REMOVE = "reviewer.remove"


class ActorIdentity(BaseModel):
    model_config = ConfigDict(frozen=True)

    role: ActorRole
    group_id: str | None = None
    participant_session: str | None = None
    source: Literal["human_cli", "participant_env"]


class TaskReviewTransition(BaseModel):
    model_config = ConfigDict(frozen=True)

    review_event_type: ReviewEventType
    source_status: TaskStatus
    target_status: TaskStatus
    return_status: TaskStatus


class GroupReviewTransition(BaseModel):
    model_config = ConfigDict(frozen=True)

    review_event_type: ReviewEventType = ReviewEventType.GROUP_STOP
    source_status: Literal["active"] = "active"
    target_status: Literal["stopped"] = "stopped"
    return_status: Literal["active"] = "active"


class CollaborativeOperationPolicy(BaseModel):
    model_config = ConfigDict(frozen=True)

    operation: OperationName
    allowed_roles: tuple[ActorRole, ...]


class TaskStatusCommandPolicy(BaseModel):
    model_config = ConfigDict(frozen=True)

    target_status: TaskStatus
    required_source_status: TaskStatus
    command_roles: tuple[ActorRole, ...]
    decision_roles: tuple[ActorRole, ...]
    return_status: TaskStatus
    review_event_type: ReviewEventType


class GroupStopPolicy(BaseModel):
    model_config = ConfigDict(frozen=True)

    command_roles: tuple[ActorRole, ...]
    decision_roles: tuple[ActorRole, ...]
    source_status: Literal["active"] = "active"
    target_status: Literal["stopped"] = "stopped"
    return_status: Literal["active"] = "active"


class TaskStatusMutationPolicy(BaseModel):
    model_config = ConfigDict(frozen=True)

    actor_role: ActorRole
    source_status: TaskStatus
    target_status: TaskStatus


class GroupStatusMutationPolicy(BaseModel):
    model_config = ConfigDict(frozen=True)

    actor_role: ActorRole
    source_status: Literal["active"]
    target_status: Literal["stopped", "active"]


TASK_REVIEW_TRANSITIONS_BY_TARGET: dict[TaskStatus, TaskReviewTransition] = {
    TaskStatus.PENDING: TaskReviewTransition(
        review_event_type=ReviewEventType.TASK_PROPOSED_REVIEW,
        source_status=TaskStatus.PROPOSED,
        target_status=TaskStatus.PENDING,
        return_status=TaskStatus.PROPOSED,
    ),
    TaskStatus.COMPLETED: TaskReviewTransition(
        review_event_type=ReviewEventType.TASK_SUBMITTED_REVIEW,
        source_status=TaskStatus.IN_PROGRESS,
        target_status=TaskStatus.COMPLETED,
        return_status=TaskStatus.IN_PROGRESS,
    ),
}

TASK_STATUS_COMMAND_POLICIES_BY_TARGET: dict[TaskStatus, TaskStatusCommandPolicy] = {
    TaskStatus.PENDING: TaskStatusCommandPolicy(
        target_status=TaskStatus.PENDING,
        required_source_status=TaskStatus.PROPOSED,
        command_roles=(ActorRole.SUPERVISOR,),
        decision_roles=(ActorRole.REVIEWER,),
        return_status=TaskStatus.PROPOSED,
        review_event_type=ReviewEventType.TASK_PROPOSED_REVIEW,
    ),
    TaskStatus.COMPLETED: TaskStatusCommandPolicy(
        target_status=TaskStatus.COMPLETED,
        required_source_status=TaskStatus.IN_PROGRESS,
        command_roles=(ActorRole.SUPERVISOR,),
        decision_roles=(ActorRole.REVIEWER,),
        return_status=TaskStatus.IN_PROGRESS,
        review_event_type=ReviewEventType.TASK_SUBMITTED_REVIEW,
    ),
}

GROUP_STOP_POLICY = GroupStopPolicy(
    command_roles=(ActorRole.SUPERVISOR,),
    decision_roles=(ActorRole.REVIEWER,),
)

REVIEW_TRANSITIONS_BY_EVENT: dict[ReviewEventType, TaskReviewTransition | GroupReviewTransition] = {
    ReviewEventType.TASK_PROPOSED_REVIEW: TASK_REVIEW_TRANSITIONS_BY_TARGET[TaskStatus.PENDING],
    ReviewEventType.TASK_SUBMITTED_REVIEW: TASK_REVIEW_TRANSITIONS_BY_TARGET[TaskStatus.COMPLETED],
    ReviewEventType.GROUP_STOP: GroupReviewTransition(),
}

TASK_STATUS_MUTATION_POLICIES: tuple[TaskStatusMutationPolicy, ...] = (
    TaskStatusMutationPolicy(
        actor_role=ActorRole.SUPERVISOR,
        source_status=TaskStatus.PROPOSED,
        target_status=TaskStatus.IN_PROGRESS,
    ),
    TaskStatusMutationPolicy(
        actor_role=ActorRole.SUPERVISOR,
        source_status=TaskStatus.PENDING,
        target_status=TaskStatus.IN_PROGRESS,
    ),
    TaskStatusMutationPolicy(
        actor_role=ActorRole.SUPERVISOR,
        source_status=TaskStatus.PROPOSED,
        target_status=TaskStatus.DELETED,
    ),
    TaskStatusMutationPolicy(
        actor_role=ActorRole.SUPERVISOR,
        source_status=TaskStatus.PENDING,
        target_status=TaskStatus.DELETED,
    ),
    TaskStatusMutationPolicy(
        actor_role=ActorRole.SUPERVISOR,
        source_status=TaskStatus.IN_PROGRESS,
        target_status=TaskStatus.DELETED,
    ),
    TaskStatusMutationPolicy(
        actor_role=ActorRole.SUPERVISOR,
        source_status=TaskStatus.COMPLETED,
        target_status=TaskStatus.DELETED,
    ),
    TaskStatusMutationPolicy(
        actor_role=ActorRole.REVIEWER,
        source_status=TaskStatus.PROPOSED,
        target_status=TaskStatus.PENDING,
    ),
    TaskStatusMutationPolicy(
        actor_role=ActorRole.REVIEWER,
        source_status=TaskStatus.PROPOSED,
        target_status=TaskStatus.PROPOSED,
    ),
    TaskStatusMutationPolicy(
        actor_role=ActorRole.REVIEWER,
        source_status=TaskStatus.IN_PROGRESS,
        target_status=TaskStatus.COMPLETED,
    ),
    TaskStatusMutationPolicy(
        actor_role=ActorRole.REVIEWER,
        source_status=TaskStatus.IN_PROGRESS,
        target_status=TaskStatus.IN_PROGRESS,
    ),
)

GROUP_STATUS_MUTATION_POLICIES: tuple[GroupStatusMutationPolicy, ...] = (
    GroupStatusMutationPolicy(
        actor_role=ActorRole.REVIEWER,
        source_status="active",
        target_status="stopped",
    ),
    GroupStatusMutationPolicy(
        actor_role=ActorRole.REVIEWER,
        source_status="active",
        target_status="active",
    ),
    GroupStatusMutationPolicy(
        actor_role=ActorRole.HUMAN,
        source_status="active",
        target_status="stopped",
    ),
    GroupStatusMutationPolicy(
        actor_role=ActorRole.OPERATOR,
        source_status="active",
        target_status="stopped",
    ),
)

COLLABORATIVE_OPERATION_POLICIES: dict[OperationName, CollaborativeOperationPolicy] = {
    OperationName.SELF_START: CollaborativeOperationPolicy(
        operation=OperationName.SELF_START,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR, ActorRole.SUPERVISOR),
    ),
    OperationName.SELF_STOP: CollaborativeOperationPolicy(
        operation=OperationName.SELF_STOP,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.SELF_RESET: CollaborativeOperationPolicy(
        operation=OperationName.SELF_RESET,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.SELF_CONFIG: CollaborativeOperationPolicy(
        operation=OperationName.SELF_CONFIG,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.GROUP_CREATE: CollaborativeOperationPolicy(
        operation=OperationName.GROUP_CREATE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.GROUP_UPDATE: CollaborativeOperationPolicy(
        operation=OperationName.GROUP_UPDATE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR, ActorRole.SUPERVISOR),
    ),
    OperationName.GROUP_REMOVE: CollaborativeOperationPolicy(
        operation=OperationName.GROUP_REMOVE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.GROUP_START: CollaborativeOperationPolicy(
        operation=OperationName.GROUP_START,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR, ActorRole.SUPERVISOR),
    ),
    OperationName.TASK_CREATE: CollaborativeOperationPolicy(
        operation=OperationName.TASK_CREATE,
        allowed_roles=(ActorRole.SUPERVISOR,),
    ),
    OperationName.TASK_UPDATE: CollaborativeOperationPolicy(
        operation=OperationName.TASK_UPDATE,
        allowed_roles=(ActorRole.SUPERVISOR, ActorRole.REVIEWER),
    ),
    OperationName.TASK_REMOVE: CollaborativeOperationPolicy(
        operation=OperationName.TASK_REMOVE,
        allowed_roles=(ActorRole.SUPERVISOR, ActorRole.REVIEWER),
    ),
    OperationName.GROUP_PAUSE: CollaborativeOperationPolicy(
        operation=OperationName.GROUP_PAUSE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR, ActorRole.SUPERVISOR),
    ),
    OperationName.GROUP_RESUME: CollaborativeOperationPolicy(
        operation=OperationName.GROUP_RESUME,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR, ActorRole.SUPERVISOR),
    ),
    OperationName.GROUP_STOP: CollaborativeOperationPolicy(
        operation=OperationName.GROUP_STOP,
        allowed_roles=(ActorRole.SUPERVISOR, ActorRole.REVIEWER),
    ),
    OperationName.GROUP_STOP_FORCE: CollaborativeOperationPolicy(
        operation=OperationName.GROUP_STOP_FORCE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.SUPERVISOR_CREATE: CollaborativeOperationPolicy(
        operation=OperationName.SUPERVISOR_CREATE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.SUPERVISOR_UPDATE: CollaborativeOperationPolicy(
        operation=OperationName.SUPERVISOR_UPDATE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.SUPERVISOR_REMOVE: CollaborativeOperationPolicy(
        operation=OperationName.SUPERVISOR_REMOVE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.SUPERVISOR_SEND: CollaborativeOperationPolicy(
        operation=OperationName.SUPERVISOR_SEND,
        allowed_roles=(ActorRole.SUPERVISOR,),
    ),
    OperationName.SUPERVISOR_READ: CollaborativeOperationPolicy(
        operation=OperationName.SUPERVISOR_READ,
        allowed_roles=(ActorRole.SUPERVISOR,),
    ),
    OperationName.SUPERVISOR_WAKE: CollaborativeOperationPolicy(
        operation=OperationName.SUPERVISOR_WAKE,
        allowed_roles=(ActorRole.SUPERVISOR,),
    ),
    OperationName.WORKER_CREATE: CollaborativeOperationPolicy(
        operation=OperationName.WORKER_CREATE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.WORKER_UPDATE: CollaborativeOperationPolicy(
        operation=OperationName.WORKER_UPDATE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.WORKER_REMOVE: CollaborativeOperationPolicy(
        operation=OperationName.WORKER_REMOVE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.REVIEWER_CREATE: CollaborativeOperationPolicy(
        operation=OperationName.REVIEWER_CREATE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.REVIEWER_UPDATE: CollaborativeOperationPolicy(
        operation=OperationName.REVIEWER_UPDATE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
    OperationName.REVIEWER_REMOVE: CollaborativeOperationPolicy(
        operation=OperationName.REVIEWER_REMOVE,
        allowed_roles=(ActorRole.HUMAN, ActorRole.OPERATOR),
    ),
}


def get_task_review_transition(
    target_status: str | TaskStatus | None,
) -> TaskReviewTransition | None:
    if target_status is None:
        return None
    try:
        resolved_status = target_status if isinstance(target_status, TaskStatus) else TaskStatus(str(target_status))
    except ValueError:
        return None
    return TASK_REVIEW_TRANSITIONS_BY_TARGET.get(resolved_status)


def get_task_status_command_policy(
    target_status: str | TaskStatus | None,
) -> TaskStatusCommandPolicy | None:
    if target_status is None:
        return None
    try:
        resolved_status = target_status if isinstance(target_status, TaskStatus) else TaskStatus(str(target_status))
    except ValueError:
        return None
    return TASK_STATUS_COMMAND_POLICIES_BY_TARGET.get(resolved_status)


def get_review_transition_by_event(
    event_type: str | ReviewEventType,
) -> TaskReviewTransition | GroupReviewTransition | None:
    try:
        resolved_event_type = event_type if isinstance(event_type, ReviewEventType) else ReviewEventType(str(event_type))
    except ValueError:
        return None
    return REVIEW_TRANSITIONS_BY_EVENT.get(resolved_event_type)


def task_status_mutation_allowed(
    *,
    actor_role: ActorRole,
    source_status: str | TaskStatus,
    target_status: str | TaskStatus,
) -> bool:
    try:
        resolved_source = source_status if isinstance(source_status, TaskStatus) else TaskStatus(str(source_status))
        resolved_target = target_status if isinstance(target_status, TaskStatus) else TaskStatus(str(target_status))
    except ValueError:
        return False
    return any(
        policy.actor_role == actor_role
        and policy.source_status == resolved_source
        and policy.target_status == resolved_target
        for policy in TASK_STATUS_MUTATION_POLICIES
    )


def group_status_mutation_allowed(
    *,
    actor_role: ActorRole,
    source_status: str,
    target_status: str,
) -> bool:
    return any(
        policy.actor_role == actor_role
        and policy.source_status == source_status
        and policy.target_status == target_status
        for policy in GROUP_STATUS_MUTATION_POLICIES
    )
