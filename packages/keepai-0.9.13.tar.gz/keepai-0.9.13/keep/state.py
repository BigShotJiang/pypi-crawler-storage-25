"""Keep 状态持久化（public facade）.

v0.4: Participants 模型
  $KEEP_HOME/global.json          — daemon_pid, stopped
  $KEEP_HOME/groups/<name>.json   — 每个 group 独立状态
    participants: [{session, role, cache}]  role ∈ {"worker", "supervisor", "reviewer"}

多 group 场景下所有命令必须显式指定 group id；不再有 current_group 全局默认。

Implementation is split across `keep._state.*` sub-modules by responsibility
(groups, participants, tasks, reviewers, transcript, messages, …). This
module re-exports the public API unchanged; external callers should keep
importing from `keep.state`.

Path constants (STATE_DIR, GROUPS_DIR, GLOBAL_FILE) resolve dynamically from
the ``KEEP_HOME`` env var (default ``~/.keep``) on every access. Tests isolate
by setting the env var (e.g. ``monkeypatch.setenv("KEEP_HOME", str(tmp))``);
the change propagates to every path derivation — including subprocesses.
"""

from __future__ import annotations

from keep._state import paths as _paths
from keep._state.content import resolve_content
from keep._state.globals_ import (
    delete_global,
    load_global,
    new_global,
    save_global,
)
from keep._state.messages import (
    append_message_index,
    messages_dir,
    write_and_index_message,
)
from keep._state.groups import (
    SCHEMA_VERSION,
    VALID_GROUP_STATUSES,
    VALID_PARTICIPANT_ROLES,
    create_group,
    delete_all,
    delete_group,
    list_groups,
    load_group,
    group_terminal_type,
    mutate_group,
    new_group,
    save_group,
    set_group_container,
    validate_group,
)
from keep._state.participants import (
    add_participant,
    add_supervisor,
    add_worker,
    find_participant,
    find_participant_globally,
    find_supervisor,
    find_worker,
    get_participant,
    find_worker_globally,
    iter_participants,
    iter_reviewers,
    iter_workers,
    remove_participant,
    remove_supervisor,
    remove_worker,
    update_participant,
    worker_session_id,
)
from keep._state.paths import (
    DEFAULT_TERMINAL,
    VALID_TERMINALS,
    atomic_write_text,
)
from keep._state.reviewers import (
    add_review_event,
    get_review_event,
    update_review_event,
)
from keep._state.tasks import (
    create_task,
    get_task,
    highwatermark_file,
    list_tasks,
    lock_file,
    next_task_id,
    remove_task,
    task_file,
    task_store_dir,
    update_task,
    update_tasks,
)
from keep._state.transcript import (
    Direction,
    Kind,
    TranscriptEntry,
    append_transcript,
    read_transcript,
)


# ── Dynamic path re-exports ───────────────────────────────────
#
# STATE_DIR / GROUPS_DIR / GLOBAL_FILE resolve from `KEEP_HOME` on every
# access. Re-export via module-level __getattr__ so `from keep.state import
# STATE_DIR` captures the current value at the time of import, and
# `keep.state.STATE_DIR` attribute access always re-reads.

_PROXIED_PATH_NAMES = frozenset({"STATE_DIR", "GROUPS_DIR", "GLOBAL_FILE"})


def __getattr__(name: str):
    if name in _PROXIED_PATH_NAMES:
        return getattr(_paths, name)
    raise AttributeError(f"module 'keep.state' has no attribute {name!r}")


__all__ = [
    # paths
    "STATE_DIR",
    "GLOBAL_FILE",
    "GROUPS_DIR",
    "DEFAULT_TERMINAL",
    "VALID_TERMINALS",
    "atomic_write_text",
    # global
    "load_global",
    "save_global",
    "delete_global",
    "new_global",
    # group
    "SCHEMA_VERSION",
    "VALID_GROUP_STATUSES",
    "VALID_PARTICIPANT_ROLES",
    "group_terminal_type",
    "validate_group",
    "new_group",
    "load_group",
    "save_group",
    "delete_group",
    "list_groups",
    "create_group",
    "delete_all",
    "mutate_group",
    "set_group_container",
    # participants
    "worker_session_id",
    "iter_participants",
    "iter_workers",
    "iter_reviewers",
    "find_participant",
    "get_participant",
    "find_worker",
    "find_participant_globally",
    "find_worker_globally",
    "find_supervisor",
    "add_participant",
    "add_worker",
    "update_participant",
    "remove_participant",
    "remove_worker",
    "add_supervisor",
    "remove_supervisor",
    # tasks
    "task_store_dir",
    "task_file",
    "highwatermark_file",
    "lock_file",
    "next_task_id",
    "create_task",
    "get_task",
    "list_tasks",
    "update_task",
    "update_tasks",
    "remove_task",
    # review events
    "add_review_event",
    "get_review_event",
    "update_review_event",
    # content
    "resolve_content",
    # transcript
    "Direction",
    "Kind",
    "TranscriptEntry",
    "append_transcript",
    "read_transcript",
    # messages
    "messages_dir",
    "append_message_index",
    "write_and_index_message",
]
