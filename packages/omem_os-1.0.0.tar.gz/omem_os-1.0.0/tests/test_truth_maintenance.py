import pytest
import time
import numpy as np
from omem import OMem, MemoryType, MemoryTier, MemoryPriority, MemoryStatus
from omem.core.brain.tms import extract_triplet, ConflictResolver

def test_truth_maintenance_dob_correction():
    """Test that OMem identifies and flags conflicting facts (e.g., DOB)."""
    m = OMem()
    
    # 1. Add conflicting memories
    # The TMS should detect these in real-time during add()
    m.add("My date of birth is 15 March 1999", importance=0.8)
    m.add("Actually, my DOB is 05 Oct 1999", importance=0.9)
    
    # 2. Check statuses
    all_mems = m.all()
    conflicts = [mem for mem in all_mems if mem.status == MemoryStatus.CONFLICTED]
    
    # We expect both the old and new to be marked as conflicted
    # until a resolution (e.g. via dream/consolidate) occurs.
    assert len(conflicts) >= 2
    
def test_conflict_detection_logic():
    """Test the v0.8.0 triplet extraction and conflict hash logic."""
    from omem.core.brain.tms import extract_triplet, compute_logical_hash
    from omem.types import Memory
    
    # "My DOB is 15 March" -> (user, fact, 15 march)
    t1 = extract_triplet("My DOB is 15 March")
    assert t1 is not None
    assert t1[0] == "dob"
    assert t1[2] == "15 march"
    
    # "My DOB is 05 Oct" -> (user, fact, 05 oct)
    t2 = extract_triplet("My DOB is 05 Oct")
    assert t2 is not None
    assert t1[0] == t2[0] # Same entity
    assert t1[1] == t2[1] # Same attribute
    
    # They should produce the same logical hash
    h1 = compute_logical_hash(t1[0], t1[1])
    h2 = compute_logical_hash(t2[0], t2[1])
    assert h1 == h2

if __name__ == "__main__":
    pytest.main([__file__])
