# Changelog

All notable changes to acp-mcp will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2026-05-14

### Changed

- **Breaking**: Templates are no longer bundled with the wheel. `acp init` and `acp version update` now fetch templates from `agent-context-protocol` (GitHub) at runtime via `git clone --depth=1`. Templates evolve independently of acp-mcp releases.
- **Breaking**: `acp version update` now refreshes the project's ACP artifacts from agent-context-protocol mainline (matching bash semantics). Previously it ran `uv tool upgrade acp-mcp`. To upgrade the tool itself, use `uv tool upgrade acp-mcp` directly.
- **Breaking**: `acp version check` now compares the project's ACP version (from `AGENT.md`) against agent-context-protocol mainline. Previously it checked PyPI for a new acp-mcp release.
- `acp init` now performs a shallow git clone instead of copying bundled resources. Requires `git` on PATH.

### Added

- `acp.core.fetch.fetch_acp_templates()` — runtime git-clone primitive (context manager; yields clone root, cleans up on exit).
- `acp version show` — print the project's ACP version from `AGENT.md` (separate from `acp --version` which shows the tool version).
- `acp_version` MCP tool: `show` (project ACP version), `check` (compare project vs upstream), `update` (refresh project artifacts).
- `acp_enumerate` MCP tool: discover ACP artifacts (commands, patterns, designs, specs) in `./agent/` and `~/.acp/agent/`. Extracts `@scry.entry` marker metadata via `scry-parse` when installed; falls back to plain file listing.
- `acp_package` MCP tool: full implementation — `list`, `install`, `update`, `remove`, `info` backed by `acp.core.package_manager`. `search` returns `status: "not_available"` pending registry launch.
- `acp package install/list/update/remove/info` CLI commands backed by `acp.core.package_manager`.
- `acp.core.package_manager` module: package management logic (install from git URL, list, info, remove, update — reads/writes `agent/manifest.yaml`).
- `scry-parse>=1.0.2` as a runtime dependency.
- 62+ tests covering fetch, init, version, MCP server, and package manager flows. All tests mock the network; one integration test (real clone, opt-in via `pytest -m integration`) is included.

### Removed

- Bundled template tree under `src/acp/templates/` (73 markdown files). Templates now come from `git clone` at runtime.
- `uv tool upgrade acp-mcp` wrapper in `acp version update`. Users should run `uv tool upgrade acp-mcp` directly.
- PyPI version-check logic from `acp version check`. Project ACP version is now the thing being checked.

### Requirements

- `git` must be installed and on PATH for `acp init` and `acp version update`.

## [0.2.0] - 2026-05-14

### Added

- `acp init .` — bootstrap a new ACP project in any directory.
  - Copies 64+ bundled template files (commands, design templates, patterns, schemas, AGENT.md) into the target directory.
  - Generates `agent/progress.yaml` with project metadata (name, version, started date).
  - `--force` flag to overwrite an existing `agent/` directory.
  - Rich colored output with next-step suggestions.
- Bundled ACP template library under `src/acp/templates/` (72 files total):
  - 48+ command files from `agent/commands/`
  - Design, pattern, milestone, task, spec, artifact, clarification templates
  - Schema files (`package.schema.yaml`, `progress.schema.yaml`, etc.)
  - `AGENT.md` methodology documentation
- Templates are accessible at runtime via `importlib.resources.files("acp.templates")`.

## [0.1.0] - 2026-05-14

### Added

- Project bootstrap.
