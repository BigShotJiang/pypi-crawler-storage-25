"""acp version — manage a project's ACP methodology version.

Commands:
  show    — print the project's installed ACP version (from AGENT.md)
  check   — compare project to agent-context-protocol mainline; report update status
  update  — fetch latest templates and refresh project's agent/ artifacts

Note: to upgrade the acp-mcp tool itself, run `uv tool upgrade acp-mcp` directly.
"""
from __future__ import annotations

import re
from pathlib import Path

import typer
from rich.console import Console

from acp.core.fetch import fetch_acp_templates

console = Console()

app = typer.Typer(
    help="Manage the project's ACP methodology version.",
    no_args_is_help=True,
)

_VERSION_RE = re.compile(r"\*\*Version\*\*\s*:\s*(.+)")


def _find_project_root(start: Path) -> Path | None:
    """Walk up from start looking for a directory containing agent/AGENT.md or agent/."""
    current = start.resolve()
    for candidate in [current, *current.parents]:
        if (candidate / "AGENT.md").exists():
            return candidate
        if (candidate / "agent").is_dir():
            return candidate
    return None


def _read_agent_md_version(agent_md: Path) -> str | None:
    """Extract **Version**: from AGENT.md. Returns None if not found or file absent."""
    if not agent_md.exists():
        return None
    text = agent_md.read_text(encoding="utf-8", errors="replace")
    match = _VERSION_RE.search(text)
    return match.group(1).strip() if match else None


def _copy_templates_to_project(src_root: Path, project_root: Path) -> int:
    """Copy ACP template files from a clone root into an existing project.

    Uses the same filter logic as `acp init`: only template files are copied,
    preserving user-authored project-specific content.

    Returns the count of files written.
    """
    from acp.cli.init import _copy_templates
    return _copy_templates(src_root, project_root)


@app.command()
def show(
    project: Path = typer.Option(
        Path("."),
        "--project",
        help="Project directory (default: current directory).",
    ),
) -> None:
    """Print the project's installed ACP version (from AGENT.md)."""
    root = _find_project_root(project)
    if root is None:
        console.print("[red]Not an ACP project:[/red] could not find project root.")
        raise typer.Exit(code=1)

    agent_md = root / "AGENT.md"
    version = _read_agent_md_version(agent_md)

    if version is None:
        console.print(
            f"[yellow]ACP version unknown.[/yellow] "
            f"AGENT.md not found or missing **Version** field at {root}"
        )
        raise typer.Exit(code=1)

    console.print(version)


@app.command()
def check(
    project: Path = typer.Option(
        Path("."),
        "--project",
        help="Project directory (default: current directory).",
    ),
    branch: str = typer.Option("mainline", "--branch", help="Upstream branch to compare against."),
) -> None:
    """Compare the project's ACP version against agent-context-protocol mainline."""
    root = _find_project_root(project)
    if root is None:
        console.print("[red]Not an ACP project:[/red] could not find project root.")
        raise typer.Exit(code=1)

    agent_md = root / "AGENT.md"
    local_version = _read_agent_md_version(agent_md)

    if local_version is None:
        console.print(
            "[yellow]ACP version unknown.[/yellow] "
            f"AGENT.md missing or no **Version** field at {root}."
        )
        raise typer.Exit(code=1)

    console.print(f"Project ACP version: [bold]{local_version}[/bold]")
    console.print(f"Fetching upstream version from agent-context-protocol ({branch})…")

    try:
        with fetch_acp_templates(branch=branch) as src_root:
            upstream_version = _read_agent_md_version(src_root / "AGENT.md")
    except RuntimeError as exc:
        console.print(f"[red]Could not fetch upstream:[/red] {exc}")
        raise typer.Exit(code=1)

    if upstream_version is None:
        console.print("[yellow]Upstream AGENT.md missing **Version** field.[/yellow]")
        raise typer.Exit(code=1)

    console.print(f"Upstream ACP version: [bold]{upstream_version}[/bold]")

    if local_version == upstream_version:
        console.print("[green]Up to date.[/green]")
    else:
        console.print(
            f"[yellow]Update available:[/yellow] {local_version} → {upstream_version}"
        )
        console.print("  Run [cyan]acp version update[/cyan] to refresh.")


@app.command()
def update(
    project: Path = typer.Option(
        Path("."),
        "--project",
        help="Project directory (default: current directory).",
    ),
    branch: str = typer.Option("mainline", "--branch", help="Upstream branch to fetch from."),
    force: bool = typer.Option(False, "--force", help="Apply updates even if versions match."),
) -> None:
    """Refresh the project's ACP artifacts from agent-context-protocol mainline.

    Only template files are updated. Project-specific content (your design docs,
    task instances, etc.) is not touched.

    Requires git on PATH.
    """
    root = _find_project_root(project)
    if root is None:
        console.print("[red]Not an ACP project:[/red] could not find project root.")
        raise typer.Exit(code=1)

    # Read current local version for user-facing output (best-effort)
    agent_md = root / "AGENT.md"
    local_version = _read_agent_md_version(agent_md)
    if local_version:
        console.print(f"Current ACP version: [bold]{local_version}[/bold]")

    console.print(f"Fetching latest templates from agent-context-protocol ({branch})…")

    try:
        with fetch_acp_templates(branch=branch) as src_root:
            upstream_version = _read_agent_md_version(src_root / "AGENT.md")

            if not force and local_version and upstream_version == local_version:
                console.print(f"[green]Already up to date.[/green] ({local_version})")
                return

            file_count = _copy_templates_to_project(src_root, root)
    except RuntimeError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    console.print(f"  [green]✓[/green] Updated {file_count} template files")

    if upstream_version:
        console.print(f"  ACP version: [bold]{upstream_version}[/bold]")

    console.print("[bold green]Done![/bold green] ACP templates refreshed.")
    console.print(
        "  Note: your project-specific docs (designs, tasks, milestones) are unchanged."
    )
