"""acp package — package management subcommands."""
from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from acp.core.package_manager import (
    info_package,
    install_package,
    list_packages,
    remove_package,
    update_package,
)

console = Console()

app = typer.Typer(
    help="Package management: install, list, update, remove, info.",
    no_args_is_help=True,
)


def _project_dir() -> Path:
    return Path.cwd()


@app.command()
def install(
    repo: str = typer.Argument(..., help="Git repository URL of the ACP package."),
    global_install: bool = typer.Option(
        False, "--global", help="Install to ~/.acp/agent/ instead of ./agent/."
    ),
    experimental: bool = typer.Option(
        False, "--experimental", help="Include experimental package contents."
    ),
    force: bool = typer.Option(False, "--force", help="Reinstall even if already installed."),
) -> None:
    """Install an ACP package from a git repository."""
    console.print(f"Installing [cyan]{repo}[/cyan]…")
    try:
        result = install_package(repo, _project_dir(), global_install, experimental, force)
    except RuntimeError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    pkg_name = result["name"]
    pkg_version = result["version"]
    installed = result["installed_files"]
    warnings = result["warnings"]

    console.print(
        f"[green]Installed[/green] [bold]{pkg_name}[/bold] v{pkg_version}"
    )

    # Summary by kind
    for kind, files in installed.items():
        if files:
            console.print(f"  {kind}: {len(files)} file(s)")

    for w in warnings:
        console.print(f"  [yellow]warn:[/yellow] {w}")


@app.command(name="list")
def list_packages_cmd(
    global_install: bool = typer.Option(
        False, "--global", help="List packages from ~/.acp/agent/manifest.yaml."
    ),
) -> None:
    """List installed ACP packages."""
    try:
        packages = list_packages(_project_dir(), global_install)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    if not packages:
        scope = "global (~/.acp/agent/)" if global_install else "project (./agent/)"
        console.print(f"No ACP packages installed in {scope}.")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Files")
    table.add_column("Updated")

    for pkg in packages:
        file_summary = ", ".join(
            f"{count} {kind}" for kind, count in pkg["file_counts"].items()
        )
        updated = (pkg.get("updated_at") or "")[:10]  # date portion
        table.add_row(pkg["name"], pkg["version"], file_summary, updated)

    console.print(table)


@app.command()
def update(
    name: str = typer.Argument(..., help="Package name to update."),
    global_install: bool = typer.Option(
        False, "--global", help="Update in global context."
    ),
) -> None:
    """Update an installed ACP package to the latest version from its source."""
    console.print(f"Updating [cyan]{name}[/cyan]…")
    try:
        result = update_package(name, _project_dir(), global_install)
    except RuntimeError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    console.print(
        f"[green]Updated[/green] [bold]{result['name']}[/bold] to v{result['version']}"
    )
    for w in result.get("warnings", []):
        console.print(f"  [yellow]warn:[/yellow] {w}")


@app.command()
def remove(
    name: str = typer.Argument(..., help="Package name to remove."),
    global_install: bool = typer.Option(
        False, "--global", help="Remove from global context."
    ),
) -> None:
    """Remove an installed ACP package."""
    try:
        result = remove_package(name, _project_dir(), global_install)
    except RuntimeError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    removed = result["removed"]
    missing = result["missing"]
    console.print(f"[green]Removed[/green] [bold]{name}[/bold] ({len(removed)} file(s) deleted)")
    for m in missing:
        console.print(f"  [yellow]warn:[/yellow] file not found: {m}")


@app.command()
def info(
    name: str = typer.Argument(..., help="Package name to inspect."),
    global_install: bool = typer.Option(
        False, "--global", help="Look up in global context."
    ),
) -> None:
    """Show details for an installed ACP package."""
    try:
        pkg = info_package(name, _project_dir(), global_install)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    if pkg is None:
        console.print(f"[red]Package '{name}' is not installed.[/red]")
        raise typer.Exit(code=1)

    console.print(f"[bold]{pkg['name']}[/bold] v{pkg['version']}")
    console.print(f"  Source:       {pkg['source']}")
    console.print(f"  Installed:    {(pkg.get('installed_at') or '')[:19]}")
    console.print(f"  Updated:      {(pkg.get('updated_at') or '')[:19]}")
    console.print("  Files:")
    for kind, files in pkg.get("files", {}).items():
        console.print(f"    {kind}: {len(files)}")
        for f in files:
            console.print(f"      - {f.get('name', '?')}")


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query (package name or keyword)."),
) -> None:
    """Search for ACP packages. (Registry not yet implemented.)"""
    console.print(
        "[yellow]acp package search[/yellow] requires a package registry that is not yet live.\n"
        "To install a package directly, use:\n"
        "  [cyan]acp package install <git-url>[/cyan]"
    )
    raise typer.Exit(code=0)
