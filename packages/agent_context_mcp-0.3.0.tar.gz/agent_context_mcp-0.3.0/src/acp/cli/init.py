"""acp init — bootstrap a new ACP project.

Fetches templates from agent-context-protocol (GitHub) at runtime via a
shallow git clone. Templates are not bundled with the wheel; this means
templates can evolve independently of acp-mcp release cadence.

Requires: git on PATH.
"""
from __future__ import annotations

import re
import shutil
from datetime import date
from pathlib import Path

import typer
import yaml
from rich.console import Console
from rich.text import Text

from acp.core.fetch import fetch_acp_templates

console = Console()

app = typer.Typer(
    help="Bootstrap a new ACP project.",
    no_args_is_help=False,
)

# Directories inside agent/ to skip entirely when copying from a clone.
_SKIP_AGENT_SUBDIRS = frozenset({
    "reports",
    "clarifications",
    "feedback",
    "drafts",
    "projects",
    "scripts",
})

# Directories inside agent/ where we copy ONLY *.template.* files
# (not project-specific instances the source repo might have).
_TEMPLATE_ONLY_SUBDIRS = frozenset({
    "design",
    "milestones",
    "tasks",
    "patterns",
    "specs",
    "artifacts",
    "sessions",
})


def _should_copy(rel: Path) -> bool:
    """Return True if this path from the clone root should be copied to the target.

    rel is relative to the clone root (e.g. "agent/commands/acp.proceed.md").
    """
    parts = rel.parts

    # Skip .git, .github, and other hidden top-level dirs
    if parts[0].startswith("."):
        return False

    # At top level: only AGENT.md and .gitignore are meaningful for new projects
    if len(parts) == 1:
        return parts[0] in ("AGENT.md", ".gitignore")

    # Inside agent/: apply subdirectory rules
    if parts[0] == "agent":
        if len(parts) < 2:
            return False  # bare "agent" dir entry — not a file

        subdir = parts[1]

        # Flat files directly under agent/ — templates like progress.template.yaml
        if len(parts) == 2:
            name = parts[1]
            # Only copy *.template.* files; skip live files like progress.yaml
            return ".template." in name

        # Skip excluded subdirs entirely
        if subdir in _SKIP_AGENT_SUBDIRS:
            return False

        # Template-only subdirs: only *.template.* files
        if subdir in _TEMPLATE_ONLY_SUBDIRS:
            name = parts[-1]
            return ".template." in name

        # Other subdirs (commands, schemas, index): copy everything
        return True

    # Anything else at top level that isn't AGENT.md — skip
    return False


def _copy_templates(src_root: Path, target: Path) -> int:
    """Copy filtered template files from src_root into target. Returns file count."""
    file_count = 0
    for src_file in sorted(src_root.rglob("*")):
        if not src_file.is_file():
            continue
        try:
            rel = src_file.relative_to(src_root)
        except ValueError:
            continue
        if not _should_copy(rel):
            continue
        dest = target / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_file, dest)
        file_count += 1
    return file_count


def _generate_progress_yaml(project_name: str) -> str:
    """Generate a minimal, valid progress.yaml for a fresh project."""
    today = date.today().isoformat()
    data = {
        "project": {
            "name": project_name,
            "version": "0.1.0",
            "started": today,
            "status": "in_progress",
            "current_milestone": None,
            "description": f"ACP project: {project_name}",
        },
        "milestones": [],
        "tasks": {},
        "documentation": {
            "design_documents": 0,
            "milestone_documents": 0,
            "pattern_documents": 0,
            "task_documents": 0,
            "last_updated": today,
        },
        "progress": {
            "planning": 0,
            "implementation": 0,
            "testing": 0,
            "documentation": 0,
            "overall": 0,
        },
        "recent_work": [],
        "next_steps": [
            "Define requirements in agent/design/requirements.md",
            "Create first milestone in agent/milestones/",
            "Run `acp package list` to see installed packages",
        ],
        "notes": [],
        "current_blockers": [],
    }
    return yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False)


def read_acp_version_from_agent_md(agent_md_path: Path) -> str | None:
    """Extract **Version**: field from AGENT.md. Returns None if not found."""
    if not agent_md_path.exists():
        return None
    text = agent_md_path.read_text(encoding="utf-8", errors="replace")
    match = re.search(r"\*\*Version\*\*\s*:\s*(.+)", text)
    return match.group(1).strip() if match else None


@app.callback(invoke_without_command=True)
def init(
    path: Path = typer.Argument(Path("."), help="Directory to initialize. Use '.' for current."),
    force: bool = typer.Option(False, "--force", help="Overwrite existing agent/ directory."),
    branch: str = typer.Option("mainline", "--branch", help="agent-context-protocol branch to fetch."),
) -> None:
    """Bootstrap a new ACP project at PATH (default: current directory).

    Fetches templates from agent-context-protocol (GitHub) at runtime.
    Requires git on PATH.
    """
    target = path.resolve()
    agent_dir = target / "agent"

    # Guard: already initialized
    if agent_dir.exists() and not force:
        console.print(
            Text(
                f"[error] ACP project already initialized at {target}\n"
                "        Use --force to overwrite.",
                style="bold red",
            )
        )
        raise typer.Exit(code=1)

    # Create target directory if it doesn't exist
    target.mkdir(parents=True, exist_ok=True)

    console.print(f"[bold]Bootstrapping ACP project at[/bold] {target}")
    console.print("  Fetching templates from agent-context-protocol…")

    try:
        with fetch_acp_templates(branch=branch) as src_root:
            file_count = _copy_templates(src_root, target)
    except RuntimeError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    console.print(f"  [green]✓[/green] Copied {file_count} template files")

    # Generate agent/progress.yaml (project-specific; not a template)
    progress_path = agent_dir / "progress.yaml"
    progress_path.parent.mkdir(parents=True, exist_ok=True)
    progress_path.write_text(
        _generate_progress_yaml(project_name=target.name),
        encoding="utf-8",
    )
    console.print("  [green]✓[/green] Created agent/progress.yaml")

    console.print()
    console.print("[bold green]Done![/bold green] ACP project initialized.")
    console.print()
    console.print("[bold]Next steps:[/bold]")
    if str(path) != ".":
        console.print(f"  cd {path}")
    console.print("  Define requirements in [cyan]agent/design/requirements.md[/cyan]")
    console.print("  Run [cyan]acp package list[/cyan] to see installed packages")
    console.print("  Start drafting milestones and tasks in [cyan]agent/milestones/[/cyan]")
