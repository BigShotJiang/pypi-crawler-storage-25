"""acp CLI entry point.

Routes top-level subcommands (package, version, init) to their respective
modules. Workflow commands (proceed, status, etc.) are intentionally NOT
exposed here — those remain as markdown directives invoked via @acp.* syntax.
"""
from __future__ import annotations

import typer

from acp.cli import init as init_cmd
from acp.cli import package as package_cmd
from acp.cli import version as version_cmd

app = typer.Typer(
    help="ACP package manager and MCP integration.",
    no_args_is_help=True,
    add_completion=False,
)
app.add_typer(package_cmd.app, name="package")
app.add_typer(version_cmd.app, name="version")
app.add_typer(init_cmd.app, name="init")


if __name__ == "__main__":
    app()
