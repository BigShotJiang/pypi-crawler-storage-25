"""Core package management logic for ACP packages.

ACP packages are git repositories containing:
  - package.yaml        — package manifest (name, version, contents)
  - agent/commands/     — command markdown files
  - agent/patterns/     — pattern markdown files
  - agent/design/       — design markdown files
  - agent/scripts/      — shell scripts (being phased out)
  - agent/files/        — template/source files

Installation copies declared content into the project's agent/ directory
and records the installed package in agent/manifest.yaml.
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import yaml


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_manifest(manifest_path: Path) -> dict:
    if manifest_path.exists():
        return yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
    return {"packages": {}, "manifest_version": "1.0.0", "last_updated": None}


def _save_manifest(manifest_path: Path, manifest: dict) -> None:
    manifest["last_updated"] = _now_iso()
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        yaml.dump(manifest, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )


def _manifest_path(project_dir: Path, global_install: bool) -> Path:
    if global_install:
        return Path.home() / ".acp" / "agent" / "manifest.yaml"
    return project_dir / "agent" / "manifest.yaml"


def _agent_root(project_dir: Path, global_install: bool) -> Path:
    if global_install:
        return Path.home() / ".acp" / "agent"
    return project_dir / "agent"


# kind → (source subdir within package's agent/, destination subdir within project's agent/)
_KIND_MAP: list[tuple[str, str, str]] = [
    ("commands", "commands", "commands"),
    ("patterns", "patterns", "patterns"),
    ("designs", "design", "design"),
    ("scripts", "scripts", "scripts"),
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def install_package(
    repo_url: str,
    project_dir: Path,
    global_install: bool = False,
    experimental: bool = False,
    force: bool = False,
) -> dict:
    """Install an ACP package from a git repository.

    Clones the repo, reads package.yaml, copies declared files into the project's
    agent/ directory, and updates agent/manifest.yaml.

    Returns:
        {"name": str, "version": str, "installed_files": dict, "warnings": list[str]}

    Raises:
        RuntimeError on clone failure, missing package.yaml, validation error, or
        already-installed conflict (unless force=True).
    """
    with tempfile.TemporaryDirectory() as tmp:
        pkg_root = Path(tmp) / "pkg"

        # Clone
        result = subprocess.run(
            ["git", "clone", "--depth=1", repo_url, str(pkg_root)],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(f"git clone failed:\n{result.stderr.strip()}")

        # Load and validate package.yaml
        pkg_yaml_path = pkg_root / "package.yaml"
        if not pkg_yaml_path.exists():
            raise RuntimeError(f"No package.yaml found at root of {repo_url}")

        pkg_data: dict = yaml.safe_load(pkg_yaml_path.read_text(encoding="utf-8")) or {}

        for field in ("name", "version", "description", "author", "license", "repository"):
            if field not in pkg_data:
                raise RuntimeError(f"package.yaml missing required field: '{field}'")

        pkg_name: str = pkg_data["name"]
        pkg_version: str = pkg_data["version"]

        # Check manifest for existing install
        manifest_file = _manifest_path(project_dir, global_install)
        manifest = _load_manifest(manifest_file)
        packages: dict = manifest.setdefault("packages", {})

        if pkg_name in packages and not force:
            existing_ver = packages[pkg_name].get("package_version", "?")
            raise RuntimeError(
                f"Package '{pkg_name}' is already installed at v{existing_ver}. "
                "Use --force to reinstall or `acp package update` to upgrade."
            )

        # Copy files
        agent_dir = _agent_root(project_dir, global_install)
        contents: dict = pkg_data.get("contents", {})
        installed_files: dict[str, list[dict]] = {}
        warnings: list[str] = []

        # Standard kinds: commands, patterns, designs, scripts
        for kind, src_sub, dst_sub in _KIND_MAP:
            items = contents.get(kind, [])
            if not items:
                continue
            src_dir = pkg_root / "agent" / src_sub
            dst_dir = agent_dir / dst_sub
            dst_dir.mkdir(parents=True, exist_ok=True)
            installed_files[kind] = []

            for item in items:
                item_name = item.get("name", "")
                if not item_name:
                    continue
                if item.get("experimental", False) and not experimental:
                    warnings.append(
                        f"Skipping experimental {kind}: {item_name} "
                        "(pass --experimental to include)"
                    )
                    continue
                src_file = src_dir / item_name
                if not src_file.exists():
                    warnings.append(f"File not found in package: {src_sub}/{item_name}")
                    continue
                shutil.copy2(str(src_file), str(dst_dir / item_name))
                installed_files[kind].append({"name": item_name})

        # Template files (agent/files/)
        file_items = contents.get("files", [])
        if file_items:
            files_dir = agent_dir / "files"
            files_dir.mkdir(parents=True, exist_ok=True)
            installed_files["files"] = []
            for item in file_items:
                item_name = item.get("name", "")
                if not item_name:
                    continue
                if item.get("experimental", False) and not experimental:
                    warnings.append(
                        f"Skipping experimental file: {item_name} "
                        "(pass --experimental to include)"
                    )
                    continue
                src_file = pkg_root / "agent" / "files" / item_name
                if not src_file.exists():
                    warnings.append(f"File not found in package: files/{item_name}")
                    continue
                dst_file = files_dir / item_name
                dst_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(src_file), str(dst_file))
                installed_files["files"].append({"name": item_name})

        # Update manifest
        now = _now_iso()
        packages[pkg_name] = {
            "source": repo_url,
            "package_version": pkg_version,
            "installed_at": packages.get(pkg_name, {}).get("installed_at", now),
            "updated_at": now,
            "files": installed_files,
        }
        _save_manifest(manifest_file, manifest)

        return {
            "name": pkg_name,
            "version": pkg_version,
            "installed_files": installed_files,
            "warnings": warnings,
        }


def list_packages(project_dir: Path, global_install: bool = False) -> list[dict]:
    """List all installed ACP packages.

    Returns a list of dicts: {name, version, source, installed_at, updated_at, file_counts}.
    """
    manifest_file = _manifest_path(project_dir, global_install)
    manifest = _load_manifest(manifest_file)
    packages = manifest.get("packages", {})

    result = []
    for name, info in packages.items():
        file_counts = {k: len(v) for k, v in info.get("files", {}).items()}
        result.append({
            "name": name,
            "version": info.get("package_version", "?"),
            "source": info.get("source", "?"),
            "installed_at": info.get("installed_at"),
            "updated_at": info.get("updated_at"),
            "file_counts": file_counts,
        })
    return result


def info_package(name: str, project_dir: Path, global_install: bool = False) -> dict | None:
    """Get info for a specific installed ACP package.

    Returns None if the package is not installed.
    """
    manifest_file = _manifest_path(project_dir, global_install)
    manifest = _load_manifest(manifest_file)
    packages = manifest.get("packages", {})

    if name not in packages:
        return None

    pkg = packages[name]
    return {
        "name": name,
        "version": pkg.get("package_version", "?"),
        "source": pkg.get("source", "?"),
        "installed_at": pkg.get("installed_at"),
        "updated_at": pkg.get("updated_at"),
        "files": pkg.get("files", {}),
    }


def remove_package(name: str, project_dir: Path, global_install: bool = False) -> dict:
    """Remove an installed ACP package.

    Deletes the installed files and removes the package from manifest.yaml.

    Returns:
        {"removed": list[str], "missing": list[str]}

    Raises:
        RuntimeError if the package is not installed.
    """
    manifest_file = _manifest_path(project_dir, global_install)
    manifest = _load_manifest(manifest_file)
    packages = manifest.get("packages", {})

    if name not in packages:
        raise RuntimeError(f"Package '{name}' is not installed.")

    pkg = packages[name]
    agent_dir = _agent_root(project_dir, global_install)

    removed: list[str] = []
    missing: list[str] = []

    kind_to_dir = {
        "commands": "commands",
        "patterns": "patterns",
        "designs": "design",
        "scripts": "scripts",
        "files": "files",
    }

    for kind, dst_sub in kind_to_dir.items():
        for item in pkg.get("files", {}).get(kind, []):
            item_name = item.get("name", "")
            if not item_name:
                continue
            f = agent_dir / dst_sub / item_name
            if f.exists():
                f.unlink()
                removed.append(f"{dst_sub}/{item_name}")
            else:
                missing.append(f"{dst_sub}/{item_name}")

    del packages[name]
    _save_manifest(manifest_file, manifest)

    return {"removed": removed, "missing": missing}


def update_package(name: str, project_dir: Path, global_install: bool = False) -> dict:
    """Update an installed ACP package to the latest version from its recorded source.

    Removes the current installation and reinstalls from the same git URL.

    Returns the install_package result dict.

    Raises:
        RuntimeError if the package is not installed or has no source URL.
    """
    manifest_file = _manifest_path(project_dir, global_install)
    manifest = _load_manifest(manifest_file)
    packages = manifest.get("packages", {})

    if name not in packages:
        raise RuntimeError(f"Package '{name}' is not installed.")

    source = packages[name].get("source")
    if not source:
        raise RuntimeError(f"Package '{name}' has no recorded source URL; cannot update.")

    # Preserve installed_at across the remove→reinstall cycle
    installed_at = packages[name].get("installed_at")
    remove_package(name, project_dir, global_install)
    result = install_package(source, project_dir, global_install, force=True)

    # Restore original installed_at
    manifest2 = _load_manifest(manifest_file)
    if name in manifest2.get("packages", {}):
        manifest2["packages"][name]["installed_at"] = installed_at
        _save_manifest(manifest_file, manifest2)

    return result
