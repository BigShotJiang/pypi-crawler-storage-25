"""acp.core.fetch — runtime fetch of agent-context-protocol templates.

Provides a context manager that shallow-clones agent-context-protocol from
GitHub into a temp directory, yields the path, and cleans up on exit.

Templates are NOT bundled with acp-mcp. They live in agent-context-protocol's
GitHub repo and are fetched at runtime so they can evolve independently of
acp-mcp releases.
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

ACP_REPO_URL = "https://github.com/prmichaelsen/agent-context-protocol.git"
ACP_BRANCH = "mainline"


def _check_git() -> None:
    """Raise RuntimeError if git is not on PATH."""
    try:
        subprocess.run(
            ["git", "--version"],
            check=True,
            capture_output=True,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "git is not installed or not on PATH. "
            "Install git to use `acp init` and `acp version update`."
        )


def _git_clone(url: str, branch: str, dest: Path) -> None:
    """Shallow-clone url@branch into dest. Raises RuntimeError on failure."""
    try:
        subprocess.run(
            ["git", "clone", "--depth=1", "--branch", branch, url, str(dest)],
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.decode(errors="replace") if exc.stderr else ""
        raise RuntimeError(
            f"Failed to clone {url!r} (branch={branch!r}): {stderr.strip()}"
        ) from exc


@contextmanager
def fetch_acp_templates(
    branch: str = ACP_BRANCH,
    repo_url: str = ACP_REPO_URL,
) -> Generator[Path, None, None]:
    """Context manager: shallow-clone agent-context-protocol and yield the clone root.

    The temp directory is always deleted on exit, even if an exception occurs.

    Args:
        branch:   Branch to clone. Defaults to "mainline".
        repo_url: Repository URL. Defaults to the canonical agent-context-protocol URL.

    Yields:
        Path to the root of the cloned repository.

    Raises:
        RuntimeError: If git is not installed, or the clone fails.
    """
    _check_git()
    tmpdir = Path(tempfile.mkdtemp(prefix="acp-mcp-fetch-"))
    try:
        _git_clone(repo_url, branch, tmpdir)
        yield tmpdir
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
