"""Core library — pure functions, no CLI/MCP surface."""
