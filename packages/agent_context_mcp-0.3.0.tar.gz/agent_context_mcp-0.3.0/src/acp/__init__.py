"""acp — Python package manager and MCP server for Agent Context Protocol projects."""

__version__ = "0.3.0"
