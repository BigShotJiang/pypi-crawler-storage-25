"""acp-mcp — MCP server entry point.

Exposes substrate-level tools for ACP projects:
  - acp_package: search/list/install/update/remove/info
  - acp_version: show/check/update (project ACP methodology version)
  - acp_enumerate: discover commands/patterns/designs/specs across global and project contexts

Workflow tools (proceed, status, task-create, etc.) are intentionally NOT
exposed here — those remain markdown directives invoked via @acp.* syntax.
"""
from __future__ import annotations

from pathlib import Path
from typing import Literal

from fastmcp import FastMCP
from acp.core.fetch import fetch_acp_templates
from acp.cli.version import (
    _find_project_root,
    _read_agent_md_version,
    _copy_templates_to_project,
)

mcp: FastMCP = FastMCP(
    name="acp-mcp",
    instructions=(
        "Substrate tools for ACP (Agent Context Protocol) projects. "
        "Use acp_package for package discovery and install/update/remove. "
        "Use acp_version to show, check, or update the project's ACP methodology version. "
        "Use acp_enumerate to discover available commands, patterns, designs, and specs "
        "in both global (~/.acp/agent/) and project (./agent/) contexts."
    ),
)


# ---------------------------------------------------------------------------
# acp_version
# ---------------------------------------------------------------------------

@mcp.tool()
def acp_version(
    action: Literal["show", "check", "update"] = "show",
    project: str = ".",
    branch: str = "mainline",
    force: bool = False,
) -> dict:
    """Manage the project's ACP methodology version.

    Actions:
      - show:   return the project's installed ACP version (from AGENT.md)
      - check:  compare the project's version against agent-context-protocol mainline
      - update: fetch latest templates from agent-context-protocol and refresh project artifacts

    Note: to upgrade the acp-mcp tool itself, run `uv tool upgrade acp-mcp` directly.

    Args:
        action:  One of "show", "check", or "update".
        project: Path to the project root (default: current directory).
        branch:  agent-context-protocol branch to compare/fetch from (default: "mainline").
        force:   For action="update" — apply updates even if versions already match.
    """
    project_path = Path(project)
    root = _find_project_root(project_path)
    if root is None:
        return {"error": "Not an ACP project: could not find project root."}

    agent_md = root / "AGENT.md"

    if action == "show":
        version = _read_agent_md_version(agent_md)
        if version is None:
            return {
                "error": "ACP version unknown: AGENT.md not found or missing **Version** field.",
                "project_root": str(root),
            }
        return {"acp_version": version, "project_root": str(root)}

    if action == "check":
        local_version = _read_agent_md_version(agent_md)
        if local_version is None:
            return {
                "error": "ACP version unknown: AGENT.md missing or no **Version** field.",
                "project_root": str(root),
            }
        try:
            with fetch_acp_templates(branch=branch) as src_root:
                upstream_version = _read_agent_md_version(src_root / "AGENT.md")
        except RuntimeError as exc:
            return {"error": f"Could not fetch upstream: {exc}"}

        if upstream_version is None:
            return {"error": "Upstream AGENT.md missing **Version** field."}

        up_to_date = local_version == upstream_version
        return {
            "local_version": local_version,
            "upstream_version": upstream_version,
            "up_to_date": up_to_date,
            "message": (
                f"Up to date ({local_version})"
                if up_to_date
                else f"Update available: {local_version} → {upstream_version}. "
                     "Call acp_version(action='update') to refresh."
            ),
        }

    if action == "update":
        local_version = _read_agent_md_version(agent_md)
        try:
            with fetch_acp_templates(branch=branch) as src_root:
                upstream_version = _read_agent_md_version(src_root / "AGENT.md")

                if not force and local_version and upstream_version == local_version:
                    return {
                        "status": "already_up_to_date",
                        "acp_version": local_version,
                        "message": f"Already up to date ({local_version}).",
                    }

                file_count = _copy_templates_to_project(src_root, root)
        except RuntimeError as exc:
            return {"error": str(exc)}

        return {
            "status": "updated",
            "files_written": file_count,
            "acp_version": upstream_version,
            "message": (
                f"Refreshed {file_count} template files. "
                f"ACP version: {upstream_version}. "
                "Project-specific docs (designs, tasks, milestones) are unchanged."
            ),
        }

    return {"error": f"Unknown action: {action!r}. Use 'show', 'check', or 'update'."}


# ---------------------------------------------------------------------------
# acp_enumerate
# ---------------------------------------------------------------------------

def _scan_directory(
    root: Path,
    kind_filter: str | None,
    base: Path | None = None,
) -> list[dict]:
    """Walk root for markdown files carrying @scry.entry markers.

    Falls back to listing all .md files with just name/path metadata
    if scry-parse is not installed.

    Args:
        root: Directory to scan recursively.
        kind_filter: Optional marker kind to filter results.
        base: Base directory for relative path computation. Defaults to root.parent.
    """
    results = []
    if not root.exists():
        return results

    rel_base = base if base is not None else root.parent

    try:
        from scry_parse import parse_markers  # type: ignore[import]
        _have_scry = True
    except ImportError:
        _have_scry = False

    for md_path in sorted(root.rglob("*.md")):
        try:
            rel = str(md_path.relative_to(rel_base))
        except ValueError:
            rel = str(md_path)  # fallback: absolute path if base doesn't contain md_path
        if _have_scry:
            content = md_path.read_text(encoding="utf-8", errors="replace")
            parsed = parse_markers(content)
            if parsed.entries:
                for entry in parsed.entries:
                    # EntryMarker is a dataclass — use attribute access, not dict .get()
                    if kind_filter and getattr(entry, "kind", None) != kind_filter:
                        continue
                    results.append({
                        "path": rel,
                        "id": getattr(entry, "id", None),
                        "kind": getattr(entry, "kind", None),
                        "summary": getattr(entry, "summary", None),
                        "status": getattr(entry, "status", None),
                        "weight": getattr(entry, "weight", None),
                        "tags": getattr(entry, "tags", None) or [],
                    })
            elif kind_filter is None:
                # No markers — include as a plain file
                results.append({
                    "path": rel,
                    "id": None,
                    "kind": None,
                    "summary": None,
                    "status": None,
                    "weight": None,
                    "tags": [],
                })
        else:
            # No scry-parse: basic listing
            if kind_filter is None:
                results.append({
                    "path": rel,
                    "id": None,
                    "kind": None,
                    "summary": None,
                    "status": None,
                    "weight": None,
                    "tags": [],
                    "note": "Install scry-parse for rich marker metadata.",
                })

    return results


@mcp.tool()
def acp_enumerate(
    scope: Literal["project", "global", "both"] = "both",
    kind: str | None = None,
    subdir: str | None = None,
) -> dict:
    """Discover ACP artifacts (commands, patterns, designs, specs, etc.).

    Searches the `agent/` directory tree for markdown files and extracts
    @scry.entry marker metadata where present.

    Args:
        scope: Where to look.
          - "project" — ./agent/ relative to cwd
          - "global"  — ~/.acp/agent/
          - "both"    — both (default)
        kind: Optional filter on marker kind (e.g. "design", "pattern", "task", "spec").
              Files without markers are included when kind is None.
        subdir: Optional sub-directory within agent/ to restrict the scan
                (e.g. "commands", "design", "patterns").

    Returns a dict with:
      - "project": list of matching files/markers from ./agent/ (when scope includes "project")
      - "global": list of matching files/markers from ~/.acp/agent/ (when scope includes "global")
      - "scry_parse_available": bool — whether rich marker metadata is available
    """
    try:
        import scry_parse  # noqa: F401
        scry_available = True
    except ImportError:
        scry_available = False

    project_results: list[dict] = []
    global_results: list[dict] = []

    project_agent = Path.cwd() / "agent"
    global_agent = Path.home() / ".acp" / "agent"

    if subdir:
        project_root = project_agent / subdir
        global_root = global_agent / subdir
    else:
        project_root = project_agent
        global_root = global_agent

    if scope in ("project", "both"):
        project_results = _scan_directory(project_root, kind_filter=kind, base=Path.cwd())

    if scope in ("global", "both"):
        global_results = _scan_directory(global_root, kind_filter=kind, base=global_agent.parent)

    return {
        "project": project_results,
        "global": global_results,
        "scry_parse_available": scry_available,
        "total": len(project_results) + len(global_results),
    }


# ---------------------------------------------------------------------------
# acp_package
# ---------------------------------------------------------------------------

@mcp.tool()
def acp_package(
    action: Literal["list", "search", "install", "update", "remove", "info"],
    name: str | None = None,
    repo: str | None = None,
    global_install: bool = False,
    experimental: bool = False,
    force: bool = False,
) -> dict:
    """ACP package management.

    Actions:
      - list:    list installed packages (global_install=True for ~/.acp/agent/)
      - search:  search the registry (not yet live — registry coming soon)
      - install: install a package from a git URL (requires repo=<url>)
      - update:  update an installed package to the latest from its source (requires name=<pkg>)
      - remove:  remove an installed package (requires name=<pkg>)
      - info:    show details for an installed package (requires name=<pkg>)

    Args:
        action:         One of the actions above.
        name:           Package name (required for update/remove/info).
        repo:           Git repository URL (required for install).
        global_install: Operate on ~/.acp/agent/ instead of ./agent/.
        experimental:   Include experimental package contents (install only).
        force:          Reinstall even if already installed (install only).
    """
    from acp.core.package_manager import (
        install_package as _install,
        list_packages as _list,
        info_package as _info,
        remove_package as _remove,
        update_package as _update,
    )

    project_dir = Path(".")

    if action == "list":
        pkgs = _list(project_dir, global_install)
        return {"packages": pkgs, "count": len(pkgs)}

    if action == "search":
        return {
            "action": "search",
            "status": "not_available",
            "message": (
                "acp package search requires a package registry that is not yet live. "
                "To install a package directly, use acp_package(action='install', repo='<git-url>')."
            ),
        }

    if action == "install":
        if not repo:
            return {"error": "action='install' requires repo=<git-url>"}
        try:
            result = _install(
                repo_url=repo, project_dir=project_dir,
                global_install=global_install, experimental=experimental, force=force,
            )
            return {"status": "installed", **result}
        except RuntimeError as exc:
            return {"error": str(exc)}

    if action == "update":
        if not name:
            return {"error": "action='update' requires name=<package-name>"}
        try:
            result = _update(name, project_dir, global_install)
            return {"status": "updated", **result}
        except RuntimeError as exc:
            return {"error": str(exc)}

    if action == "remove":
        if not name:
            return {"error": "action='remove' requires name=<package-name>"}
        try:
            result = _remove(name, project_dir, global_install)
            return {"status": "removed", "name": name, **result}
        except RuntimeError as exc:
            return {"error": str(exc)}

    if action == "info":
        if not name:
            return {"error": "action='info' requires name=<package-name>"}
        pkg = _info(name, project_dir, global_install)
        if pkg is None:
            return {"error": f"Package '{name}' is not installed."}
        return pkg

    return {"error": f"Unknown action: {action}"}


def main() -> None:
    """Run the acp-mcp MCP server over stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
