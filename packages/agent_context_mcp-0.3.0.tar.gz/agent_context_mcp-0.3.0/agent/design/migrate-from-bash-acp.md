<!-- @scry.entry
id: design.migrate-from-bash-acp~e9c4f1a2
kind: design
summary: >
  Architectural separation between agent-context-protocol (canonical ACP
  methodology repo) and acp-mcp (Python tooling that consumes it). Eliminates
  template duplication via runtime git clone, not wheel bundling. Bash version
  remains as a legacy install path; acp-mcp becomes the preferred tool surface.
status: active
weight: 0.95
tags: ["scope:acp-mcp", "topic:architecture", "topic:templates", "topic:fetch"]
rationale: >
  Two repos, clear separation of concerns. agent-context-protocol owns the
  methodology (templates, commands, patterns, AGENT.md); acp-mcp consumes it
  via runtime git clone. Templates evolve at agent-context-protocol's cadence,
  decoupled from acp-mcp release cycles. Mirrors the scry-spec / scry-parse
  pattern: spec in one repo, implementations consume it.
applies: implementing acp init, implementing acp version check/update, deciding where templates live, naming version commands, planning agent-context-protocol's continued role
seeded_questions:
  - "Why fetch from github instead of bundling templates with the wheel?"
  - "What happens to agent-context-protocol the GitHub repo?"
  - "How do acp init and acp version update differ?"
  - "What does the bash version do that acp-mcp doesn't?"
  - "Does this break existing ACP packages (acp-firebase, etc.)?"
@scry.entry.end -->

# Architecture: acp-mcp consumes agent-context-protocol via runtime fetch

**Concept**: agent-context-protocol stays alive as the canonical source of truth for ACP methodology. acp-mcp is a preferred Python tooling layer that fetches templates from agent-context-protocol at runtime via git clone.
**Created**: 2026-05-14
**Status**: Design Specification

---

## Overview

`agent-context-protocol` (ACP) is a project that ships the **ACP methodology**:
- `AGENT.md` (methodology documentation)
- 48+ command markdown files (`agent/commands/acp.*.md`)
- Pattern, design, milestone, task, spec, and clarification templates
- Schemas (`package.yaml`, `progress.yaml`, etc.)
- Key file index conventions
- Bash scripts for install, version-check, and update (legacy install path)

`acp-mcp` is a Python package that provides:
- A CLI for ACP operations (`acp init`, `acp package`, `acp version`)
- An MCP server exposing substrate tools to agents (`acp_package`, `acp_version`, `acp_enumerate`)
- A core library for project detection, marker parsing (via scry-parse), and package management

**The relationship**: acp-mcp is a **preferred consumer tool**, not a fork. It fetches templates and commands from agent-context-protocol at runtime; both projects evolve independently.

---

## Problem Statement

The earlier draft of this design proposed bundling templates inside acp-mcp's wheel as Python package data. That approach has a critical downside: **templates can only evolve at acp-mcp's release cadence**. A typo in `acp.proceed.md` would require a new acp-mcp release, even though no Python code changed.

The bash version solves this differently: `acp.install.sh` and `acp.version-update.sh` both **curl from agent-context-protocol's github** at runtime. Templates evolve in agent-context-protocol on their own cadence; the bash scripts just orchestrate the fetch.

acp-mcp should preserve this property. Otherwise, every template fix requires a Python release.

---

## Solution

### Two repos, clean separation

```
agent-context-protocol  →  Source of truth for ACP methodology
                           (templates, commands, patterns, AGENT.md, schemas)
                           ├─ bash install path (legacy, still works)
                           └─ git/github (canonical content host)

acp-mcp                 →  Preferred Python tooling
                           ├─ CLI: acp init, acp version, acp package
                           ├─ MCP surface: acp_package, acp_version, acp_enumerate
                           └─ Fetches templates from agent-context-protocol via git clone
```

This mirrors the scry ecosystem:
- `scry-spec` (markdown contract) — source of truth
- `scry-parse-py` / `scry-parse-ts` (implementations) — consume the spec
- `scry-mcp` (server) — consumes scry-parse

Same pattern. agent-context-protocol is the spec/content; acp-mcp is one consumer.

### Runtime template fetching via git clone

`acp init` and `acp version update` clone agent-context-protocol's `mainline` branch to a temporary directory, copy files into the target project, then clean up.

**Why git clone instead of per-file fetch or tarball**:
- Single command, well-understood semantics
- Works with private repos via SSH if ever needed
- Shallow clone (`--depth=1`) is fast (~1 second for agent-context-protocol)
- No need to know individual file paths or maintain a manifest
- Idempotent — clone, copy what's needed, clean up

**Why /tmp instead of persistent cache**:
- Simpler model: every fetch gets a fresh clone
- No staleness concerns (cache invalidation is a hard problem)
- Disk churn is negligible (one shallow clone per operation)
- A future optimization could add `~/.cache/acp-mcp/` if measurements show /tmp churn is a real cost

### Command surface (clarified)

| Command | What it does |
|---|---|
| `acp init [PATH]` | Clone agent-context-protocol/mainline to /tmp, copy AGENT.md + agent/ templates into PATH, generate progress.yaml, clean up. |
| `acp version show` | Print the project's ACP version (read from progress.yaml or similar). |
| `acp version check` | Compare the project's ACP version against agent-context-protocol's mainline HEAD. |
| `acp version update` | Clone agent-context-protocol/mainline to /tmp, refresh template files in `agent/`, preserve user content (milestones, designs, etc.), clean up. |
| `acp --version` | Print acp-mcp tool version (typer adds this automatically). |
| `uv tool upgrade acp-mcp` | Upgrade the acp-mcp tool itself (not our command — defer to uv). |

**Key distinction**: `acp version *` operates on the **project's ACP methodology version**, not the **acp-mcp tool version**. The tool version is uv's concern; the project version is ours.

This matches bash semantics — `@acp.version-update` historically refreshed project files, not the bash scripts.

---

## Implementation

### Phase 1: Build the fetch primitive

Add `src/acp/core/fetch.py`:

```python
import subprocess
import tempfile
from pathlib import Path
from contextlib import contextmanager

ACP_REPO_URL = "https://github.com/prmichaelsen/agent-context-protocol.git"
ACP_BRANCH = "mainline"


@contextmanager
def fetch_acp_templates(branch: str = ACP_BRANCH):
    """Shallow-clone agent-context-protocol to a temp dir and yield the path.
    Cleans up on exit.
    """
    tmpdir = Path(tempfile.mkdtemp(prefix="acp-mcp-fetch-"))
    try:
        subprocess.run(
            ["git", "clone", "--depth=1", "--branch", branch, ACP_REPO_URL, str(tmpdir)],
            check=True, capture_output=True,
        )
        yield tmpdir
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
```

### Phase 2: Rework `acp init`

Replace the bundle-reading logic with a fetch-and-copy:

```python
def init(path: Path = ".", force: bool = False):
    target = path.resolve()
    agent_dir = target / "agent"
    if agent_dir.exists() and not force:
        # error
        ...

    with fetch_acp_templates() as src_root:
        # Copy AGENT.md and agent/ from src_root into target
        # Skip bash scripts (agent/scripts/), reports, clarifications, drafts
        ...

    # Generate fresh progress.yaml
    ...
```

### Phase 3: Implement `acp version check` and `acp version update`

```python
def check():
    """Compare project's ACP version to agent-context-protocol/mainline HEAD."""
    project_version = read_acp_version_from_project()  # from progress.yaml or similar
    with fetch_acp_templates() as src_root:
        upstream_version = read_acp_version_from_repo(src_root)  # from AGENT.md or VERSION file
    # report whether project is up to date
    ...


def update():
    """Refresh project's ACP template files from agent-context-protocol/mainline."""
    project_root = find_project_root()
    with fetch_acp_templates() as src_root:
        for tpl in template_files(src_root):
            dest = project_root / tpl.relative_to(src_root)
            shutil.copy(tpl, dest)
    # Preserve user content (don't overwrite milestone/task/design instances)
    ...
```

### Phase 4: Drop the bundled templates

Remove the bundled `src/acp/templates/` tree. The package no longer carries 73 markdown files. Wheel shrinks.

Remove the `[tool.hatch.build.targets.wheel.shared-data]` config (or simplify the comment block) so hatchling doesn't include the templates directory.

### Phase 5: agent-context-protocol stays alive

- **bash scripts get deprecated**: `acp.install.sh`, `acp.version-update.sh`, `acp.version-check.sh` are no longer the recommended install path. They keep working for users who still want bash.
- **Templates and methodology live on**: AGENT.md, agent/commands/, agent/*.template.md, agent/schemas/ — all stay in agent-context-protocol's repo. This is the canonical content.
- **README updates**: agent-context-protocol's README points users to `uv tool install acp-mcp` as the preferred install path, with bash as the fallback.
- **Repo lives in its own release cadence**: template/command/pattern changes happen on agent-context-protocol's release schedule. acp-mcp just consumes the latest.

---

## Benefits

- **Templates evolve independently of tool releases** — typo fix in `acp.proceed.md` doesn't require an acp-mcp release.
- **Single source of truth** — agent-context-protocol is the canonical methodology repo. acp-mcp is one consumer (others can exist).
- **bash version stays functional** — legacy install path still works for users who want it; no forced migration.
- **Simpler model** — both `acp init` and `acp version update` do the same thing (clone, copy); only the destination's prior state differs.
- **Consistent semantics with bash** — `acp version update` refreshes project files, matching what bash users already expect.
- **Smaller wheel** — no bundled markdown payload (~500 KB saved). Minor but nice.
- **No staleness surprises** — users always get whatever's on mainline at the moment they ran the command.

---

## Trade-offs

### Network required at `acp init` time

**Impact**: First-time bootstrap requires network access (git clone).

**Mitigation**: Same as bash version's `acp.install.sh` (which curls from github). Standard expectation for install operations in 2026. Airgapped environments use the bash version's offline-friendly path (template files copied manually).

### Git dependency

**Impact**: `git` must be installed and on PATH.

**Mitigation**: Same as bash version's requirements. Virtually all dev environments have git. Document the requirement in README.

### No reproducibility from acp-mcp version alone

**Impact**: `acp init` today and tomorrow can produce different output if agent-context-protocol's mainline moved.

**Mitigation**: This is by design — users want fresh templates. If reproducibility is needed for a specific deployment, pin via `--branch` or `--ref` (future flag) to a specific commit or tag.

### Slower than bundled

**Impact**: Shallow clone takes ~1 second vs file-copy taking ~10ms.

**Mitigation**: `acp init` is a one-time operation per project; the latency is invisible against the user's first-run mental model. `acp version update` is periodic; same.

---

## Migration for already-bundled v0.2.0

The acp-worker shipped v0.2.0 with bundled templates and a fully functional `acp init` reading from `importlib.resources`. That work isn't wasted — the structure and tests carry forward — but the template source changes.

Migration tasks (to be queued to acp-worker):

1. Add `src/acp/core/fetch.py` with the git-clone primitive.
2. Rework `src/acp/cli/init.py` to fetch + copy instead of reading bundled resources.
3. Remove `src/acp/templates/` directory (bundle no longer needed).
4. Update `pyproject.toml` to drop the bundled data config.
5. Rework `src/acp/cli/version.py`:
   - `acp version show` — show project's ACP version (from progress.yaml)
   - `acp version check` — compare project vs agent-context-protocol mainline
   - `acp version update` — fetch and refresh project artifacts (NOT `uv tool upgrade`)
6. Rework `src/acp/mcp/server.py`'s `acp_version` MCP tool to mirror the new CLI semantics.
7. Update README to describe the runtime-fetch model.
8. Add tests for the fetch primitive (mock subprocess) and the new init/version flows.
9. Bump to v0.3.0.

---

## Dependencies

- `git` must be installed and on PATH (runtime requirement, not a Python dependency).
- No new Python dependencies (subprocess + tempfile + pathlib are stdlib).
- `scry-parse` is still required for `acp_enumerate` (marker extraction) — that path is unchanged.

---

## Testing Strategy

### Fetch tests
- Unit test: mock subprocess.run, verify the right `git clone` command is issued
- Integration test: actually clone agent-context-protocol from github, verify expected files appear (gated behind a marker, skipped in CI by default to avoid network requirements)

### `acp init` tests
- Verify clone happens, files are copied, progress.yaml is generated
- Verify --force overwrites
- Verify tempdir is cleaned up on success and on failure

### `acp version update` tests
- Verify template files get updated
- Verify user content (specific milestones, designs, etc.) is preserved
- Verify dry-run mode shows diff without applying

### Reliability tests
- Network failure during clone: clean error, no partial state
- Tempdir cleanup happens even on exception
- Git not installed: clear error message

---

## Key Design Decisions

| Decision | Choice | Rationale |
|---|---|---|
| Template source | agent-context-protocol github | Stays canonical; templates evolve independently |
| Fetch mechanism | `git clone --depth=1` to /tmp | Simple, fast, well-understood |
| Cache strategy | None — fresh fetch every time | Avoids cache invalidation; cheap enough |
| Bundle templates in wheel | No | Defeats the purpose of independent evolution |
| `acp version update` semantics | Project artifact refresh | Matches bash semantics; tool upgrade is uv's job |
| Tool self-upgrade command | No (defer to `uv tool upgrade acp-mcp`) | Don't reinvent uv |
| Bash version status | Deprecated but functional | Backward compat for legacy users |
| agent-context-protocol status | Active, canonical methodology repo | Same model as scry-spec / scry-parse |
| Project ACP version source | progress.yaml or VERSION file | TBD during implementation; one place to read it |

---

## Future Considerations

- **Cached fetches**: if `/tmp` clones become a measurable cost, add `~/.cache/acp-mcp/templates/` with TTL-based invalidation.
- **Pinning**: `--branch`, `--ref`, or `--tag` flag on `acp init` for reproducible deployments.
- **Multi-source templates**: support custom template sources beyond agent-context-protocol (e.g., for orgs with their own ACP fork).
- **Diff/preview mode**: `acp version update --dry-run` shows what would change without applying.
- **Offline mode**: detect network failure and prompt to install via bash, or use a manually-supplied template directory.

---

**Status**: Active design specification.
**Recommendation**: Queue the migration tasks to acp-worker. Drop bundled templates. Implement fetch primitive. Rework version commands. Bump to v0.3.0.
**Related documents**:
- `acp-mcp/CHANGELOG.md` — track releases that implement each phase
- `scry-spec v1.0` — markers used in fetched templates (when `@scry.entry` markers are added to agent-context-protocol's templates)
