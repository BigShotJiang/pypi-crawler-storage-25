"""Tests for `acp init` — bootstrap a new ACP project.

Tests mock fetch_acp_templates so no network access is required. The one
integration test (test_init_integration_real_clone) is marked and skipped
by default; run it with pytest -m integration to exercise the real GitHub clone.
"""
from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path

import pytest
import yaml
from typer.testing import CliRunner
from unittest.mock import patch

from acp.cli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_fake_clone(base: Path) -> Path:
    """Build a minimal agent-context-protocol-shaped directory for tests."""
    root = base / "_fake_clone"
    root.mkdir(parents=True, exist_ok=True)

    # AGENT.md at repo root
    (root / "AGENT.md").write_text("**Version**: 1.0.0\nSome ACP docs.\n")

    # .gitignore at repo root
    (root / ".gitignore").write_text("*.pyc\n.venv/\n")

    # agent/commands — all files copied
    cmds = root / "agent" / "commands"
    cmds.mkdir(parents=True)
    for name in (
        "acp.proceed.md",
        "acp.plan.md",
        "acp.task-create.md",
        "acp.design-create.md",
        "acp.status.md",
        "acp.init.md",
        "command.template.md",
    ):
        (cmds / name).write_text(f"# {name}\n")

    # agent/design — only *.template.md copied; project file skipped
    design = root / "agent" / "design"
    design.mkdir(parents=True)
    (design / "design.template.md").write_text("# Design template\n")
    (design / "my-project-design.md").write_text("# Real project doc\n")  # should NOT be copied

    # agent/schemas — all yaml copied
    schemas = root / "agent" / "schemas"
    schemas.mkdir(parents=True)
    (schemas / "progress.schema.yaml").write_text("type: object\n")

    # agent/ flat template file
    (root / "agent" / "progress.template.yaml").write_text("project: ~\n")

    # agent/reports — should be excluded
    reports = root / "agent" / "reports"
    reports.mkdir(parents=True)
    (reports / "old-report.md").write_text("# Report\n")

    return root


def make_fake_fetch(clone_root: Path):
    """Return a mock for fetch_acp_templates that yields clone_root."""
    @contextmanager
    def _fake_fetch(branch="mainline", repo_url=None):
        yield clone_root
    return _fake_fetch


# ---------------------------------------------------------------------------
# Unit tests (mocked network)
# ---------------------------------------------------------------------------

def test_init_creates_agent_directory(tmp_path: Path) -> None:
    """Init creates agent/ with expected subdirectories."""
    fake_clone = _make_fake_clone(tmp_path)
    target = tmp_path / "project"

    with patch("acp.cli.init.fetch_acp_templates", make_fake_fetch(fake_clone)):
        result = runner.invoke(app, ["init", str(target)])

    assert result.exit_code == 0, result.output
    assert (target / "agent").is_dir()
    assert (target / "agent" / "commands").is_dir()
    assert (target / "agent" / "schemas").is_dir()


def test_init_copies_agent_md(tmp_path: Path) -> None:
    """AGENT.md is copied to the project root."""
    fake_clone = _make_fake_clone(tmp_path)
    target = tmp_path / "project"

    with patch("acp.cli.init.fetch_acp_templates", make_fake_fetch(fake_clone)):
        result = runner.invoke(app, ["init", str(target)])

    assert result.exit_code == 0, result.output
    agent_md = target / "AGENT.md"
    assert agent_md.exists(), "AGENT.md not found"
    assert agent_md.stat().st_size > 0, "AGENT.md is empty"


def test_init_copies_commands(tmp_path: Path) -> None:
    """Core command files are present and non-empty after init."""
    fake_clone = _make_fake_clone(tmp_path)
    target = tmp_path / "project"

    with patch("acp.cli.init.fetch_acp_templates", make_fake_fetch(fake_clone)):
        result = runner.invoke(app, ["init", str(target)])

    assert result.exit_code == 0, result.output
    expected_commands = [
        "acp.proceed.md",
        "acp.plan.md",
        "acp.task-create.md",
        "acp.design-create.md",
        "acp.status.md",
        "acp.init.md",
        "command.template.md",
    ]
    for cmd in expected_commands:
        p = target / "agent" / "commands" / cmd
        assert p.exists(), f"Missing command file: {cmd}"
        assert p.stat().st_size > 0, f"Empty command file: {cmd}"


def test_init_copies_only_template_files_from_design(tmp_path: Path) -> None:
    """Only *.template.md files are copied from agent/design/; project files are skipped."""
    fake_clone = _make_fake_clone(tmp_path)
    target = tmp_path / "project"

    with patch("acp.cli.init.fetch_acp_templates", make_fake_fetch(fake_clone)):
        result = runner.invoke(app, ["init", str(target)])

    assert result.exit_code == 0, result.output
    # Template file should be copied
    assert (target / "agent" / "design" / "design.template.md").exists()
    # Project-specific file should NOT be copied
    assert not (target / "agent" / "design" / "my-project-design.md").exists()


def test_init_excludes_reports_directory(tmp_path: Path) -> None:
    """agent/reports/ is excluded from the copy."""
    fake_clone = _make_fake_clone(tmp_path)
    target = tmp_path / "project"

    with patch("acp.cli.init.fetch_acp_templates", make_fake_fetch(fake_clone)):
        result = runner.invoke(app, ["init", str(target)])

    assert result.exit_code == 0, result.output
    assert not (target / "agent" / "reports").exists()


def test_init_creates_progress_yaml(tmp_path: Path) -> None:
    """agent/progress.yaml is generated with correct top-level keys."""
    fake_clone = _make_fake_clone(tmp_path)
    target = tmp_path / "project"

    with patch("acp.cli.init.fetch_acp_templates", make_fake_fetch(fake_clone)):
        result = runner.invoke(app, ["init", str(target)])

    assert result.exit_code == 0, result.output
    progress_path = target / "agent" / "progress.yaml"
    assert progress_path.exists()

    with open(progress_path) as f:
        data = yaml.safe_load(f)

    assert "project" in data
    assert data["project"]["name"] == target.name
    assert data["project"]["version"] == "0.1.0"
    assert data["project"]["status"] == "in_progress"
    assert "milestones" in data
    assert "tasks" in data
    assert "progress" in data


def test_init_errors_if_already_initialized(tmp_path: Path) -> None:
    """Running init twice without --force errors on the second run."""
    fake_clone = _make_fake_clone(tmp_path)
    target = tmp_path / "project"

    with patch("acp.cli.init.fetch_acp_templates", make_fake_fetch(fake_clone)):
        first = runner.invoke(app, ["init", str(target)])
        assert first.exit_code == 0, first.output

        second = runner.invoke(app, ["init", str(target)])
        assert second.exit_code != 0, "Expected non-zero exit on second init without --force"


def test_init_force_overwrites(tmp_path: Path) -> None:
    """Running init twice with --force succeeds on the second run."""
    fake_clone = _make_fake_clone(tmp_path)
    target = tmp_path / "project"

    with patch("acp.cli.init.fetch_acp_templates", make_fake_fetch(fake_clone)):
        first = runner.invoke(app, ["init", str(target)])
        assert first.exit_code == 0, first.output

        second = runner.invoke(app, ["init", "--force", str(target)])
        assert second.exit_code == 0, second.output

    assert (target / "agent" / "commands" / "acp.proceed.md").exists()


def test_init_errors_when_fetch_fails(tmp_path: Path) -> None:
    """A fetch failure (e.g. no network) exits non-zero with an error message."""
    target = tmp_path / "project"

    @contextmanager
    def _failing_fetch(branch="mainline", repo_url=None):
        raise RuntimeError("git is not installed")
        yield  # makes it a generator (never reached)

    with patch("acp.cli.init.fetch_acp_templates", _failing_fetch):
        result = runner.invoke(app, ["init", str(target)])

    assert result.exit_code != 0
    assert "git is not installed" in result.output or "Error" in result.output


def test_init_copies_flat_agent_templates(tmp_path: Path) -> None:
    """Flat *.template.* files under agent/ (like progress.template.yaml) are copied."""
    fake_clone = _make_fake_clone(tmp_path)
    target = tmp_path / "project"

    with patch("acp.cli.init.fetch_acp_templates", make_fake_fetch(fake_clone)):
        result = runner.invoke(app, ["init", str(target)])

    assert result.exit_code == 0, result.output
    assert (target / "agent" / "progress.template.yaml").exists()


# ---------------------------------------------------------------------------
# Integration test (real GitHub clone — skipped by default)
# ---------------------------------------------------------------------------

@pytest.mark.integration
def test_init_integration_real_clone(tmp_path: Path) -> None:  # pragma: no cover
    """Integration: acp init performs a real git clone from agent-context-protocol.

    Requires network access and git on PATH.
    Run with: pytest -m integration
    """
    target = tmp_path / "real-project"
    result = runner.invoke(app, ["init", str(target)])
    assert result.exit_code == 0, result.output
    assert (target / "AGENT.md").exists()
    assert (target / "agent" / "commands").is_dir()
    assert (target / "agent" / "progress.yaml").exists()
