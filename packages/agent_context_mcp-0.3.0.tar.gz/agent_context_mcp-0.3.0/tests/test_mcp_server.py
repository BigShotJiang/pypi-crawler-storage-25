"""Tests for acp-mcp MCP server tools: acp_version, acp_enumerate, acp_package."""
from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from acp.mcp.server import acp_enumerate, acp_package, acp_version


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_fake_fetch_with_version(version: str):
    """Mock fetch_acp_templates that yields a temp dir with the given AGENT.md version."""
    @contextmanager
    def _fake(branch="mainline", repo_url=None):
        import tempfile, shutil
        tmpdir = Path(tempfile.mkdtemp())
        try:
            (tmpdir / "AGENT.md").write_text(f"**Version**: {version}\n")
            yield tmpdir
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
    return _fake


def _make_fake_fetch_with_files(version: str, files: dict[str, str]):
    @contextmanager
    def _fake(branch="mainline", repo_url=None):
        import tempfile, shutil
        tmpdir = Path(tempfile.mkdtemp())
        try:
            (tmpdir / "AGENT.md").write_text(f"**Version**: {version}\n")
            for rel, content in files.items():
                dest = tmpdir / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_text(content)
            yield tmpdir
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
    return _fake


# ---------------------------------------------------------------------------
# acp_version — show
# ---------------------------------------------------------------------------

def test_acp_version_show_returns_project_version(tmp_path: Path) -> None:
    """show returns the project's ACP version from AGENT.md."""
    (tmp_path / "AGENT.md").write_text("**Version**: 2.5.0\n")
    result = acp_version(action="show", project=str(tmp_path))
    assert result.get("acp_version") == "2.5.0"
    assert "project_root" in result


def test_acp_version_show_no_agent_md(tmp_path: Path) -> None:
    """show returns an error when AGENT.md is absent or has no **Version** field."""
    (tmp_path / "agent").mkdir()  # make it a recognized project root
    result = acp_version(action="show", project=str(tmp_path))
    assert "error" in result


# ---------------------------------------------------------------------------
# acp_version — check
# ---------------------------------------------------------------------------

def test_acp_version_check_up_to_date(tmp_path: Path) -> None:
    """check reports up-to-date when project and upstream versions match."""
    (tmp_path / "AGENT.md").write_text("**Version**: 2.0.0\n")

    with patch("acp.mcp.server.fetch_acp_templates", _make_fake_fetch_with_version("2.0.0")):
        result = acp_version(action="check", project=str(tmp_path))

    assert result.get("up_to_date") is True
    assert "Up to date" in result.get("message", "")


def test_acp_version_check_update_available(tmp_path: Path) -> None:
    """check reports update available when upstream is newer."""
    (tmp_path / "AGENT.md").write_text("**Version**: 1.0.0\n")

    with patch("acp.mcp.server.fetch_acp_templates", _make_fake_fetch_with_version("3.0.0")):
        result = acp_version(action="check", project=str(tmp_path))

    assert result.get("up_to_date") is False
    assert result.get("upstream_version") == "3.0.0"
    assert "Update available" in result.get("message", "")


def test_acp_version_check_network_error(tmp_path: Path) -> None:
    """check returns an error dict when fetch fails."""
    (tmp_path / "AGENT.md").write_text("**Version**: 1.0.0\n")

    @contextmanager
    def _failing_fetch(branch="mainline", repo_url=None):
        raise RuntimeError("network error")
        yield

    with patch("acp.mcp.server.fetch_acp_templates", _failing_fetch):
        result = acp_version(action="check", project=str(tmp_path))

    assert "error" in result


# ---------------------------------------------------------------------------
# acp_version — update
# ---------------------------------------------------------------------------

def test_acp_version_update_copies_files(tmp_path: Path) -> None:
    """update copies template files and reports success."""
    (tmp_path / "AGENT.md").write_text("**Version**: 1.0.0\n")
    (tmp_path / "agent").mkdir()

    fake_fetch = _make_fake_fetch_with_files("2.0.0", {
        "agent/commands/acp.proceed.md": "# proceed\n",
    })

    with patch("acp.mcp.server.fetch_acp_templates", fake_fetch):
        result = acp_version(action="update", project=str(tmp_path))

    assert result.get("status") == "updated"
    assert result.get("files_written", 0) >= 1
    assert (tmp_path / "agent" / "commands" / "acp.proceed.md").exists()


def test_acp_version_update_already_up_to_date(tmp_path: Path) -> None:
    """update returns already_up_to_date when versions match."""
    (tmp_path / "AGENT.md").write_text("**Version**: 2.0.0\n")
    (tmp_path / "agent").mkdir()

    with patch("acp.mcp.server.fetch_acp_templates", _make_fake_fetch_with_version("2.0.0")):
        result = acp_version(action="update", project=str(tmp_path))

    assert result.get("status") == "already_up_to_date"


def test_acp_version_update_force_applies(tmp_path: Path) -> None:
    """update with force=True applies even when already up to date."""
    (tmp_path / "AGENT.md").write_text("**Version**: 2.0.0\n")
    (tmp_path / "agent").mkdir()

    fake_fetch = _make_fake_fetch_with_files("2.0.0", {
        "agent/commands/acp.proceed.md": "# proceed\n",
    })

    with patch("acp.mcp.server.fetch_acp_templates", fake_fetch):
        result = acp_version(action="update", project=str(tmp_path), force=True)

    assert result.get("status") == "updated"


# ---------------------------------------------------------------------------
# acp_version — unknown action
# ---------------------------------------------------------------------------

def test_acp_version_unknown_action(tmp_path: Path) -> None:
    """Unknown action returns an error dict."""
    (tmp_path / "AGENT.md").write_text("**Version**: 1.0\n")
    result = acp_version(action="unknown", project=str(tmp_path))  # type: ignore[arg-type]
    assert "error" in result


# ---------------------------------------------------------------------------
# acp_enumerate
# ---------------------------------------------------------------------------

def test_acp_enumerate_empty_project(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """enumerate on a dir with no agent/ returns empty project list."""
    monkeypatch.chdir(tmp_path)
    result = acp_enumerate(scope="project")
    assert result["project"] == []
    assert "total" in result
    assert "scry_parse_available" in result


def test_acp_enumerate_finds_markdown_files(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """enumerate finds .md files under agent/ when scry-parse is unavailable."""
    agent_dir = tmp_path / "agent" / "design"
    agent_dir.mkdir(parents=True)
    (agent_dir / "my-design.md").write_text("# My Design\n")
    (agent_dir / "other.md").write_text("# Other\n")

    monkeypatch.chdir(tmp_path)

    # Force scry-parse unavailable path by patching import
    with patch("builtins.__import__", side_effect=_selective_import_error("scry_parse")):
        result = acp_enumerate(scope="project")

    # At least 2 files found
    assert len(result["project"]) >= 2
    assert result["scry_parse_available"] is False
    paths = [r["path"] for r in result["project"]]
    assert any("my-design.md" in p for p in paths)


def test_acp_enumerate_subdir_filter(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """subdir restricts scan to the named subdirectory."""
    commands_dir = tmp_path / "agent" / "commands"
    design_dir = tmp_path / "agent" / "design"
    commands_dir.mkdir(parents=True)
    design_dir.mkdir(parents=True)

    (commands_dir / "cmd.md").write_text("# Command\n")
    (design_dir / "des.md").write_text("# Design\n")

    monkeypatch.chdir(tmp_path)

    result = acp_enumerate(scope="project", subdir="commands")
    paths = [r["path"] for r in result["project"]]
    assert all("commands" in p for p in paths)
    assert not any("design" in p for p in paths)


def test_acp_enumerate_with_scry_markers(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """enumerate extracts scry marker metadata when scry-parse is available."""
    agent_dir = tmp_path / "agent" / "design"
    agent_dir.mkdir(parents=True)

    marker_content = """\
<!-- @scry.entry
id: design.test~abc12345
kind: design
summary: Test design doc
status: active
weight: 0.9
tags: ["topic:test"]
@scry.entry.end -->

# Test Design
Some content.
"""
    (agent_dir / "test-design.md").write_text(marker_content)

    monkeypatch.chdir(tmp_path)

    result = acp_enumerate(scope="project")

    if not result["scry_parse_available"]:
        pytest.skip("scry-parse not installed; marker extraction not testable")

    assert len(result["project"]) >= 1
    entry = next((r for r in result["project"] if r["id"] == "design.test~abc12345"), None)
    assert entry is not None, f"Marker not found in results: {result['project']}"
    assert entry["kind"] == "design"
    assert entry["summary"] == "Test design doc"


def test_acp_enumerate_both_scope(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """scope='both' returns project + global keys."""
    monkeypatch.chdir(tmp_path)
    result = acp_enumerate(scope="both")
    assert "project" in result
    assert "global" in result
    assert "total" in result


# ---------------------------------------------------------------------------
# acp_package
# ---------------------------------------------------------------------------

def test_acp_package_list_empty(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """list action with no manifest returns empty packages list."""
    monkeypatch.chdir(tmp_path)
    result = acp_package(action="list")
    assert "packages" in result
    assert "count" in result
    assert result["count"] == 0
    assert isinstance(result["packages"], list)


def test_acp_package_search_not_available() -> None:
    """search action returns not_available (registry not yet live)."""
    result = acp_package(action="search")
    assert result.get("status") == "not_available"
    assert "registry" in result.get("message", "").lower()


def test_acp_package_install_requires_repo() -> None:
    """install action without repo returns an error dict."""
    result = acp_package(action="install")
    assert "error" in result
    assert "repo" in result["error"]


def test_acp_package_update_requires_name() -> None:
    """update action without name returns an error dict."""
    result = acp_package(action="update")
    assert "error" in result
    assert "name" in result["error"]


def test_acp_package_remove_requires_name() -> None:
    """remove action without name returns an error dict."""
    result = acp_package(action="remove")
    assert "error" in result
    assert "name" in result["error"]


def test_acp_package_info_requires_name() -> None:
    """info action without name returns an error dict."""
    result = acp_package(action="info")
    assert "error" in result
    assert "name" in result["error"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _selective_import_error(blocked_module: str):
    """Return a side-effect function that raises ImportError only for blocked_module."""
    _real_import = __builtins__.__import__ if hasattr(__builtins__, "__import__") else __import__

    def _import(name, *args, **kwargs):
        if name == blocked_module or name.startswith(blocked_module + "."):
            raise ImportError(f"Mocked ImportError for {name}")
        return _real_import(name, *args, **kwargs)

    return _import
