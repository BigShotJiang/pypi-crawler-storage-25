"""Unit tests for acp.core.fetch — fetch_acp_templates context manager."""
from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import pytest

from acp.core.fetch import fetch_acp_templates, _check_git, _git_clone, ACP_REPO_URL, ACP_BRANCH


# ---------------------------------------------------------------------------
# _check_git
# ---------------------------------------------------------------------------

def test_check_git_success() -> None:
    """_check_git does not raise when git is available."""
    mock_result = MagicMock()
    with patch("subprocess.run", return_value=mock_result) as mock_run:
        _check_git()
    mock_run.assert_called_once_with(
        ["git", "--version"], check=True, capture_output=True
    )


def test_check_git_missing_raises() -> None:
    """_check_git raises RuntimeError when git is not on PATH."""
    with patch("subprocess.run", side_effect=FileNotFoundError()):
        with pytest.raises(RuntimeError, match="git is not installed"):
            _check_git()


# ---------------------------------------------------------------------------
# _git_clone
# ---------------------------------------------------------------------------

def test_git_clone_calls_correct_command(tmp_path: Path) -> None:
    """_git_clone invokes the right git command."""
    with patch("subprocess.run") as mock_run:
        _git_clone("https://example.com/repo.git", "main", tmp_path)

    mock_run.assert_called_once_with(
        ["git", "clone", "--depth=1", "--branch", "main",
         "https://example.com/repo.git", str(tmp_path)],
        check=True,
        capture_output=True,
    )


def test_git_clone_raises_on_failure(tmp_path: Path) -> None:
    """_git_clone raises RuntimeError with context when clone fails."""
    exc = subprocess.CalledProcessError(128, ["git"], stderr=b"repository not found")
    with patch("subprocess.run", side_effect=exc):
        with pytest.raises(RuntimeError, match="Failed to clone"):
            _git_clone("https://example.com/repo.git", "main", tmp_path)


# ---------------------------------------------------------------------------
# fetch_acp_templates
# ---------------------------------------------------------------------------

def test_fetch_acp_templates_yields_path(tmp_path: Path) -> None:
    """fetch_acp_templates yields the temp directory path."""
    fake_path = tmp_path / "fake-clone"
    fake_path.mkdir()

    with (
        patch("acp.core.fetch._check_git"),
        patch("acp.core.fetch._git_clone"),
        patch("tempfile.mkdtemp", return_value=str(fake_path)),
        patch("shutil.rmtree"),
    ):
        with fetch_acp_templates() as path:
            assert path == fake_path


def test_fetch_acp_templates_uses_defaults(tmp_path: Path) -> None:
    """fetch_acp_templates passes the default URL and branch to _git_clone."""
    fake_path = tmp_path / "fake-clone"
    fake_path.mkdir()

    with (
        patch("acp.core.fetch._check_git"),
        patch("acp.core.fetch._git_clone") as mock_clone,
        patch("tempfile.mkdtemp", return_value=str(fake_path)),
        patch("shutil.rmtree"),
    ):
        with fetch_acp_templates():
            pass

    mock_clone.assert_called_once_with(ACP_REPO_URL, ACP_BRANCH, fake_path)


def test_fetch_acp_templates_cleanup_on_success(tmp_path: Path) -> None:
    """The temp directory is removed after the context exits normally."""
    fake_path = tmp_path / "fake-clone"
    fake_path.mkdir()

    with (
        patch("acp.core.fetch._check_git"),
        patch("acp.core.fetch._git_clone"),
        patch("tempfile.mkdtemp", return_value=str(fake_path)),
        patch("shutil.rmtree") as mock_rmtree,
    ):
        with fetch_acp_templates():
            pass

    mock_rmtree.assert_called_once_with(fake_path, ignore_errors=True)


def test_fetch_acp_templates_cleanup_on_exception(tmp_path: Path) -> None:
    """The temp directory is removed even when the body raises."""
    fake_path = tmp_path / "fake-clone"
    fake_path.mkdir()

    with (
        patch("acp.core.fetch._check_git"),
        patch("acp.core.fetch._git_clone"),
        patch("tempfile.mkdtemp", return_value=str(fake_path)),
        patch("shutil.rmtree") as mock_rmtree,
    ):
        with pytest.raises(ValueError, match="test exception"):
            with fetch_acp_templates():
                raise ValueError("test exception")

    mock_rmtree.assert_called_once_with(fake_path, ignore_errors=True)


def test_fetch_acp_templates_raises_when_git_missing(tmp_path: Path) -> None:
    """fetch_acp_templates propagates RuntimeError from _check_git."""
    with patch(
        "acp.core.fetch._check_git",
        side_effect=RuntimeError("git is not installed"),
    ):
        with pytest.raises(RuntimeError, match="git is not installed"):
            with fetch_acp_templates():
                pass


def test_fetch_acp_templates_raises_on_clone_failure(tmp_path: Path) -> None:
    """fetch_acp_templates propagates RuntimeError from a failed clone."""
    fake_path = tmp_path / "fake-clone"
    fake_path.mkdir()

    with (
        patch("acp.core.fetch._check_git"),
        patch(
            "acp.core.fetch._git_clone",
            side_effect=RuntimeError("Failed to clone: repo not found"),
        ),
        patch("tempfile.mkdtemp", return_value=str(fake_path)),
        patch("shutil.rmtree"),
    ):
        with pytest.raises(RuntimeError, match="Failed to clone"):
            with fetch_acp_templates():
                pass


def test_fetch_acp_templates_custom_branch_and_url(tmp_path: Path) -> None:
    """fetch_acp_templates passes custom branch and repo_url to _git_clone."""
    fake_path = tmp_path / "fake-clone"
    fake_path.mkdir()

    with (
        patch("acp.core.fetch._check_git"),
        patch("acp.core.fetch._git_clone") as mock_clone,
        patch("tempfile.mkdtemp", return_value=str(fake_path)),
        patch("shutil.rmtree"),
    ):
        with fetch_acp_templates(branch="dev", repo_url="https://example.com/fork.git"):
            pass

    mock_clone.assert_called_once_with(
        "https://example.com/fork.git", "dev", fake_path
    )
