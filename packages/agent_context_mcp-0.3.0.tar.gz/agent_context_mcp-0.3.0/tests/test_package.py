"""Tests for acp.core.package_manager."""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest
import yaml

from acp.core.package_manager import (
    info_package,
    install_package,
    list_packages,
    remove_package,
    update_package,
)


# ---------------------------------------------------------------------------
# Helpers to build a minimal fake ACP package repo
# ---------------------------------------------------------------------------

def make_fake_package(
    tmp_path: Path,
    name: str = "test-pkg",
    version: str = "1.0.0",
    commands: list[str] | None = None,
    patterns: list[str] | None = None,
    experimental_commands: list[str] | None = None,
) -> Path:
    """Create a minimal fake ACP package as a bare git repo."""
    pkg_dir = tmp_path / "pkg-source"
    pkg_dir.mkdir()

    commands = commands or ["hello.md"]
    patterns = patterns or []
    experimental_commands = experimental_commands or []

    # agent/commands/
    cmds_dir = pkg_dir / "agent" / "commands"
    cmds_dir.mkdir(parents=True)
    for cmd in commands + experimental_commands:
        (cmds_dir / cmd).write_text(f"# {cmd}\nContent of {cmd}\n")

    # agent/patterns/
    pats_dir = pkg_dir / "agent" / "patterns"
    pats_dir.mkdir(parents=True)
    for pat in patterns:
        (pats_dir / pat).write_text(f"# {pat}\nContent of {pat}\n")

    # package.yaml
    contents: dict = {}
    if commands:
        contents["commands"] = [{"name": c, "description": f"Command {c}"} for c in commands]
    if experimental_commands:
        existing = contents.setdefault("commands", [])
        existing += [
            {"name": c, "description": f"Experimental {c}", "experimental": True}
            for c in experimental_commands
        ]
    if patterns:
        contents["patterns"] = [{"name": p, "description": f"Pattern {p}"} for p in patterns]

    pkg_yaml = {
        "name": name,
        "version": version,
        "description": f"Test package {name}",
        "author": "Tester",
        "license": "MIT",
        "repository": f"https://github.com/test/{name}.git",
        "contents": contents,
    }
    (pkg_dir / "package.yaml").write_text(yaml.dump(pkg_yaml))

    # Init as git repo so git clone works
    subprocess.run(["git", "init"], cwd=str(pkg_dir), capture_output=True)
    subprocess.run(["git", "add", "-A"], cwd=str(pkg_dir), capture_output=True)
    subprocess.run(
        ["git", "-c", "user.email=test@test.com", "-c", "user.name=Test",
         "commit", "-m", "init"],
        cwd=str(pkg_dir), capture_output=True,
    )

    return pkg_dir


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_install_creates_agent_commands(tmp_path):
    """install_package copies commands into agent/commands/."""
    pkg_dir = make_fake_package(tmp_path, commands=["hello.md", "world.md"])
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    result = install_package(str(pkg_dir), project_dir)

    assert result["name"] == "test-pkg"
    assert result["version"] == "1.0.0"
    assert (project_dir / "agent" / "commands" / "hello.md").exists()
    assert (project_dir / "agent" / "commands" / "world.md").exists()


def test_install_updates_manifest(tmp_path):
    """install_package writes agent/manifest.yaml with correct metadata."""
    pkg_dir = make_fake_package(tmp_path, name="my-pkg", version="2.0.0")
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    install_package(str(pkg_dir), project_dir)

    manifest_path = project_dir / "agent" / "manifest.yaml"
    assert manifest_path.exists()
    manifest = yaml.safe_load(manifest_path.read_text())

    assert "my-pkg" in manifest["packages"]
    pkg = manifest["packages"]["my-pkg"]
    assert pkg["package_version"] == "2.0.0"
    assert "installed_at" in pkg
    assert "updated_at" in pkg
    assert pkg["files"]["commands"] == [{"name": "hello.md"}]


def test_install_errors_if_already_installed(tmp_path):
    """Second install without --force raises RuntimeError."""
    pkg_dir = make_fake_package(tmp_path)
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    install_package(str(pkg_dir), project_dir)
    with pytest.raises(RuntimeError, match="already installed"):
        install_package(str(pkg_dir), project_dir)


def test_install_force_overwrites(tmp_path):
    """install_package with force=True succeeds even if already installed."""
    pkg_dir = make_fake_package(tmp_path)
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    install_package(str(pkg_dir), project_dir)
    result = install_package(str(pkg_dir), project_dir, force=True)

    assert result["name"] == "test-pkg"


def test_install_skips_experimental_by_default(tmp_path):
    """Experimental commands are not installed unless experimental=True."""
    pkg_dir = make_fake_package(tmp_path, commands=["stable.md"], experimental_commands=["exp.md"])
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    result = install_package(str(pkg_dir), project_dir)

    assert (project_dir / "agent" / "commands" / "stable.md").exists()
    assert not (project_dir / "agent" / "commands" / "exp.md").exists()
    assert any("experimental" in w for w in result["warnings"])


def test_install_includes_experimental_when_flagged(tmp_path):
    """Experimental commands are installed when experimental=True."""
    pkg_dir = make_fake_package(tmp_path, experimental_commands=["exp.md"])
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    result = install_package(str(pkg_dir), project_dir, experimental=True)

    assert (project_dir / "agent" / "commands" / "exp.md").exists()
    assert not result["warnings"]


def test_list_packages_empty(tmp_path):
    """list_packages returns empty list when no manifest exists."""
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    assert list_packages(project_dir) == []


def test_list_packages_after_install(tmp_path):
    """list_packages returns installed packages."""
    pkg_dir = make_fake_package(tmp_path, name="alpha", version="1.2.3")
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    install_package(str(pkg_dir), project_dir)
    pkgs = list_packages(project_dir)

    assert len(pkgs) == 1
    assert pkgs[0]["name"] == "alpha"
    assert pkgs[0]["version"] == "1.2.3"
    assert pkgs[0]["file_counts"]["commands"] == 1


def test_info_package_not_installed(tmp_path):
    """info_package returns None for an uninstalled package."""
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    assert info_package("nonexistent", project_dir) is None


def test_info_package_after_install(tmp_path):
    """info_package returns correct metadata after install."""
    pkg_dir = make_fake_package(tmp_path, name="beta")
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    install_package(str(pkg_dir), project_dir)
    info = info_package("beta", project_dir)

    assert info is not None
    assert info["name"] == "beta"
    assert "files" in info
    assert len(info["files"]["commands"]) == 1


def test_remove_package(tmp_path):
    """remove_package deletes files and removes from manifest."""
    pkg_dir = make_fake_package(tmp_path, commands=["hello.md"])
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    install_package(str(pkg_dir), project_dir)
    cmd_file = project_dir / "agent" / "commands" / "hello.md"
    assert cmd_file.exists()

    result = remove_package("test-pkg", project_dir)

    assert not cmd_file.exists()
    assert "commands/hello.md" in result["removed"]

    # Package no longer in manifest
    assert info_package("test-pkg", project_dir) is None


def test_remove_package_not_installed(tmp_path):
    """remove_package raises RuntimeError if package is not installed."""
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    with pytest.raises(RuntimeError, match="not installed"):
        remove_package("ghost", project_dir)


def test_update_package(tmp_path):
    """update_package reinstalls from the original source."""
    pkg_dir = make_fake_package(tmp_path, version="1.0.0")
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    install_package(str(pkg_dir), project_dir)

    # Bump version in source
    pkg_yaml_path = pkg_dir / "package.yaml"
    data = yaml.safe_load(pkg_yaml_path.read_text())
    data["version"] = "1.1.0"
    pkg_yaml_path.write_text(yaml.dump(data))
    subprocess.run(["git", "add", "-A"], cwd=str(pkg_dir), capture_output=True)
    subprocess.run(
        ["git", "-c", "user.email=test@test.com", "-c", "user.name=Test",
         "commit", "-m", "bump version"],
        cwd=str(pkg_dir), capture_output=True,
    )

    result = update_package("test-pkg", project_dir)
    assert result["version"] == "1.1.0"

    # Manifest updated
    info = info_package("test-pkg", project_dir)
    assert info["version"] == "1.1.0"
