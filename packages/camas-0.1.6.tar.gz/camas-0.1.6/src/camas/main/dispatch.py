# SPDX-License-Identifier: MIT
# SPDX-FileCopyrightText: 2026 JP Hutchins

from __future__ import annotations

import ast
import asyncio
import sys
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Final, NamedTuple

from ..core.effect import Effect
from ..core.execution import run
from ..core.matrix import matrix_axes, override_matrix
from ..core.render import color_on
from ..core.task import TaskNode
from .argv import apply_passthrough, parse_axis_values, parse_matrix_kv, split_passthrough
from .effects import parse_effects
from .expression import parse_expression
from .format import (
	format_reference,
	format_try_hint,
	print_available_effects,
	print_task_help,
	print_task_summary_listing,
	print_task_trees,
	print_tree,
)
from .parser import RESERVED_FLAGS, build_parser
from .tasks import load_tasks, load_tasks_from_py, name_scope_bindings, name_scope_effects


def dispatch_arg(arg: str, tasks: Mapping[str, TaskNode]) -> TaskNode:
	"""Interpret a CLI arg: task name (possibly hyphenated) ⇒ lookup, else inline expression."""
	if arg in tasks:
		return tasks[arg]
	try:
		parsed = ast.parse(arg, mode="eval")
	except SyntaxError:
		return parse_expression(arg, tasks=tasks)
	if isinstance(parsed.body, ast.Name):
		name = parsed.body.id
		known = ", ".join(sorted(tasks)) or "none"
		print(f"error: no task named {name!r} (known: {known})", file=sys.stderr)
		sys.exit(2)
	return parse_expression(arg, tasks=tasks)


def run_cli(scope: Mapping[str, object]) -> None:
	"""Collect Task/Sequential/Parallel values from ``scope`` and dispatch CLI args.

	Names starting with ``_`` and non-task values are skipped. Public bindings
	are named by their binding identifier, and nested references inherit those
	names (consistent with ``[tool.camas.tasks]`` in pyproject.toml). Public
	Effect classes in ``scope`` are also picked up so users can
	pass them to ``--effects`` and see them under ``camas --effects``.
	"""
	dispatch(name_scope_bindings(scope), scope_effects=name_scope_effects(scope))


def dispatch(
	tasks: Mapping[str, TaskNode],
	argv: list[str] | None = None,
	source: Path | None = None,
	scope_effects: Mapping[str, type[Effect[Any]]] = {},
) -> None:
	"""Parse ``argv`` (defaulting to sys.argv) against ``tasks`` and run the dispatched task.

	When invoked with no expression and tasks are defined, prints a compact listing
	of available tasks and exits 0 — the ``camas`` (no-args) ergonomic default,
	mirroring ``just`` and ``task``.
	"""
	split: Final = split_passthrough(sys.argv[1:] if argv is None else argv)

	if (
		len(split.head) >= 2
		and split.head[0] in tasks
		and any(a in ("-h", "--help") for a in split.head[1:])
	):
		print_task_help(split.head[0], tasks[split.head[0]])
		sys.exit(0)

	parser: Final = build_parser(tasks, source, scope_effects)
	args, _leftover = parser.parse_known_args(split.head)

	augmented_axes: dict[str, tuple[str, ...]] = {}
	if isinstance(args.expression, str) and args.expression in tasks:
		for name, values in matrix_axes(tasks[args.expression]).items():
			if name.lower() in RESERVED_FLAGS:
				continue
			parser.add_argument(
				f"--{name}",
				dest=name,
				action="store",
				default=None,
				metavar="VAL[,VAL...]",
				help=f"override matrix axis {name!r} (current: {', '.join(values)})",
			)
			augmented_axes[name] = values
	args = parser.parse_args(split.head)

	if args.list:
		print_task_summary_listing(tasks, source)
		sys.exit(0)

	if args.tree:
		print_task_trees(tasks, source)
		sys.exit(0)

	if args.effects == "":
		print_available_effects(scope_effects)
		sys.exit(0)

	if args.expression is None:
		if tasks:
			print(parser.format_usage().rstrip())
			print()
			print_task_summary_listing(tasks, source)
			print()
			print(format_try_hint(color_on()))
			print()
			print(format_reference(color_on()))
			print()
			sys.stdout.flush()
			print(f"{parser.prog}: error: task or expression is required", file=sys.stderr)
			sys.exit(2)
		parser.error("task or expression is required (no tasks defined)")

	try:
		effects: Final = parse_effects(args.effects, scope_effects)
	except ValueError as e:
		print(f"error: --effects: {e}", file=sys.stderr)
		sys.exit(2)

	overrides: dict[str, tuple[str, ...]] = {}
	for raw in args.matrix:
		try:
			k, v = parse_matrix_kv(raw)
		except ValueError as e:
			print(f"error: {e}", file=sys.stderr)
			sys.exit(2)
		overrides[k] = v
	for axis_name in augmented_axes:
		val = getattr(args, axis_name, None)
		if val is not None:
			values = parse_axis_values(val)
			if not values:
				print(f"error: --{axis_name}: at least one value required", file=sys.stderr)
				sys.exit(2)
			overrides[axis_name] = values

	resolved = dispatch_arg(args.expression, tasks)
	if overrides:
		try:
			resolved = override_matrix(resolved, overrides)
		except ValueError as e:
			print(f"error: {e}", file=sys.stderr)
			sys.exit(2)
	try:
		task: Final = (
			apply_passthrough(resolved, split.passthrough) if split.passthrough else resolved
		)
	except ValueError as e:
		print(f"error: {e}", file=sys.stderr)
		sys.exit(2)
	if args.dry_run:
		print_tree(task, show_cmd=True)
		sys.exit(0)
	sys.exit(asyncio.run(run(task, effects=effects)).returncode)


def looks_like_py_file(arg: str) -> bool:
	"""A CLI arg refers to a tasks file when it ends in ``.py`` — expressions always end in ``)``.

	>>> looks_like_py_file("tasks.py")
	True
	>>> looks_like_py_file("./sub/my_tasks.py")
	True
	>>> looks_like_py_file('Task("pytest x.py")')
	False
	>>> looks_like_py_file("lint")
	False
	"""
	return arg.endswith(".py")


class TasksSource(NamedTuple):
	"""Result of locating a tasks source on disk."""

	tasks: dict[str, TaskNode]
	"""Tasks parsed from ``source``; empty when no tasks file was found."""
	argv: list[str]
	"""Remaining argv after consuming an explicit ``foo.py`` first arg, if any."""
	source: Path | None
	"""File the tasks were loaded from, or ``None`` when none was found."""
	scope_effects: dict[str, type[Effect[Any]]]
	"""User-defined Effects from a ``tasks.py`` scope; empty for pyproject."""


def resolve_tasks_source(argv: list[str]) -> TasksSource:
	"""Locate the tasks source and return a :class:`TasksSource`.

	If ``argv[0]`` ends in ``.py`` it is consumed as an explicit file path.
	Otherwise walks upward from cwd and returns tasks from the nearest directory
	that defines any; ``tasks.py`` wins over ``pyproject.toml`` at the same level.
	A ``pyproject.toml`` without ``[tool.camas.tasks]`` is not a match — the walk
	continues upward.
	"""
	if argv and looks_like_py_file(argv[0]):
		path = Path(argv[0])
		if not path.is_file():
			print(f"error: {path}: no such file", file=sys.stderr)
			sys.exit(2)
		try:
			tasks_py_loaded, scope_effects = load_tasks_from_py(path)
			return TasksSource(tasks_py_loaded, argv[1:], path, scope_effects)
		except Exception as e:
			print(f"error: {path}: {e}", file=sys.stderr)
			sys.exit(2)

	start: Final = Path.cwd()
	for candidate in (start, *start.parents):
		tasks_py = candidate / "tasks.py"
		if tasks_py.is_file():
			try:
				tasks_py_loaded, scope_effects = load_tasks_from_py(tasks_py)
				return TasksSource(tasks_py_loaded, argv, tasks_py, scope_effects)
			except Exception as e:
				print(f"error: {tasks_py}: {e}", file=sys.stderr)
				sys.exit(2)
		pyproject = candidate / "pyproject.toml"
		if pyproject.is_file():
			try:
				tasks, _ = load_tasks(pyproject)
			except ValueError as e:
				print(f"error: {pyproject}: {e}", file=sys.stderr)
				sys.exit(2)
			if tasks:
				return TasksSource(tasks, argv, pyproject, {})

	return TasksSource({}, argv, None, {})
