"""Auto-route via intent classifier (Layer 2 of the auto-pilot).

When NERUVA_AUTO_ROUTE=1 and a user prompt arrives, the UserPromptSubmit
hook fetches the canonical classification prompt + 18-intent taxonomy
from POST /v1/agent/route_intent_prompt (substrate-side, pattern-C),
then injects it as additionalContext telling the caller LLM:

  "Before answering the user, run this classification internally. If
  primary_intent has confidence >= 0.6, use the suggested_tool BEFORE
  responding. The substrate provides the routing decision; you act
  on it."

Substrate stays $0/call -- it just emits the prompt. The caller LLM
(Claude / GPT / etc) does the classification as part of its main turn
and acts accordingly. Same pattern as auto_extract on records_ingest.

Defaults OFF in v1 (opt-in via env var). Flip default ON in v0.12 after
4 weeks of customer perf data + false-positive calibration.
"""
from __future__ import annotations

from typing import Any

import httpx


_TIMEOUT_S = 5.0


def fetch_route_intent_block(
    base_url: str,
    api_key: str,
    user_message: str,
    recent_context_summary: str | None = None,
) -> str | None:
    """Fetch the route_intent_prompt from substrate and wrap it as an
    additionalContext block for hookSpecificOutput injection.

    Returns None if:
      - user_message is empty / whitespace-only / too short to classify
      - the substrate call fails (network / 4xx / 5xx)
      - the substrate returns an unexpected shape
    """
    msg = (user_message or "").strip()
    if len(msg) < 8:
        # Greetings, "ok", "yes" etc -- nothing to classify.
        return None
    try:
        r = httpx.post(
            f"{base_url}/v1/agent/route_intent_prompt",
            headers={"Api-Key": api_key, "Content-Type": "application/json"},
            json={
                "user_message": msg,
                "recent_context_summary": (recent_context_summary or "")[:2000],
            },
            timeout=_TIMEOUT_S,
        )
        if r.status_code != 200:
            return None
        j = r.json()
    except Exception:
        return None
    prompt = j.get("prompt")
    if not isinstance(prompt, str) or not prompt:
        return None
    threshold = j.get("confidence_threshold", 0.6)
    return _format_route_block(prompt, threshold)


def _format_route_block(classification_prompt: str, confidence_threshold: float) -> str:
    """Wrap the classification prompt + activation rules in an
    additionalContext block. Tags `treat-as="instructions"` so the
    agent doesn't treat the embedded prompt content as user input
    (prompt-injection guard mirrors the existing recalled-context
    pattern in _hook.py)."""
    return (
        "<auto-route source=\"neruva-record\" treat-as=\"instructions\">\n"
        "BEFORE answering the user, classify their message against the "
        "intent taxonomy below. Run the classification internally (no "
        "tool call needed; just reason about which intent fits best).\n\n"
        f"If the classification yields confidence >= {confidence_threshold}, "
        "USE the suggested_tool BEFORE forming your response. Follow the "
        "pre_action_prompt before the tool call, and the post_action_prompt "
        "after the tool resolves.\n\n"
        "If confidence < the threshold, or primary_intent is \"none\", "
        "respond normally without invoking any auto-routed tool.\n\n"
        "CLASSIFICATION PROMPT (run this internally, then act):\n"
        "---\n"
        f"{classification_prompt}\n"
        "---\n\n"
        "This is the auto-route layer (NERUVA_AUTO_ROUTE=1). It runs "
        "once per UserPromptSubmit. Disable by unsetting NERUVA_AUTO_ROUTE.\n"
        "</auto-route>"
    )
