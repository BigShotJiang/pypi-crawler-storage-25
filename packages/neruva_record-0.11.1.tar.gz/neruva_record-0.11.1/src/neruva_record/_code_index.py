"""neruva-record code-index -- Python codebase -> Neruva KG.

Walks a directory of .py files, extracts (subject, relation, object)
triples via Python's stdlib ast, and batch-pushes them to the substrate
KG endpoint POST /v1/hd/kg/{name}/facts.

Same triple format as neruva_hd.code_graph (the substrate-side adapter
validated by probe 101 + probe 102 -- 99.3% macro recall@1 at codebase
scale). This client-side version is intentionally self-contained: no
dependency on neruva_hd, only stdlib + httpx (already a neruva-record dep).
"""
from __future__ import annotations

import argparse
import ast
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Iterable

import httpx


# Resolve the bundled @neruva/js-extractor script if installed alongside.
# Production install path candidates, in priority order. The first
# existing path wins; if none found, JS/TS files are skipped with a
# soft warning.
def _find_js_extractor() -> Path | None:
    env = os.environ.get("NERUVA_JS_EXTRACTOR")
    if env:
        p = Path(env)
        return p if p.exists() else None
    candidates = [
        Path("C:/Neruva_HD/packages/js-extractor/index.js"),
        Path(__file__).parent / "_vendor" / "js-extractor" / "index.js",
        Path.home() / ".neruva" / "js-extractor" / "index.js",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


JS_EXTENSIONS = {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}
JS_EXTRACTOR_PATH = _find_js_extractor()

# Tree-sitter multilang extensions: dispatched to _code_index_treesitter
# when the optional `neruva-record[multilang]` dep is installed.
TS_EXTENSIONS = {
    ".go", ".rs", ".java", ".rb",
    ".cpp", ".cxx", ".cc", ".hpp", ".hxx", ".hh", ".h", ".c",
}


def _ts_available() -> bool:
    """True if tree-sitter + at least one language parser is importable.
    Cached implicitly by Python's import system."""
    try:
        import tree_sitter  # noqa: F401
    except ImportError:
        return False
    return True


TS_AVAILABLE = _ts_available()


DEFAULT_API_URL = "https://api.neruva.io"
DEFAULT_BATCH = 1000
DEFAULT_EXCLUDE = (
    "__pycache__", "_archive", "_attic", ".git",
    "node_modules", "build", "dist", ".venv", "venv",
)


def qualified_name(module: str, cls: str | None, fn: str) -> str:
    if cls:
        return f"{module}::{cls}.{fn}"
    return f"{module}::{fn}"


def _module_path(file_path: Path, root: Path) -> str:
    rel = file_path.resolve().relative_to(root.resolve())
    parts = list(rel.with_suffix("").parts)
    if parts and parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def _expr_simple_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Call):
        return _expr_simple_name(node.func)
    return None


def _parse_file_triples(
    file_path: Path, root: Path
) -> tuple[list[tuple[str, str, str]], dict]:
    src = file_path.read_text(encoding="utf-8", errors="replace")
    try:
        tree = ast.parse(src, filename=str(file_path))
    except SyntaxError:
        return [], {"n_functions": 0, "n_classes": 0, "n_calls": 0,
                    "n_params": 0, "module": "", "error": "syntax"}

    module = _module_path(file_path, root)
    triples: list[tuple[str, str, str]] = []
    counters = {"n_functions": 0, "n_methods": 0, "n_classes": 0,
                "n_calls": 0, "n_params": 0}

    def _emit(s: str, r: str, o: str) -> None:
        triples.append((s, r, o))

    def _walk_function(node: ast.AST, cls: str | None) -> None:
        counters["n_functions"] += 1
        if cls is not None:
            counters["n_methods"] += 1
        qname = qualified_name(module, cls, node.name)
        _emit(qname, "defined_in_module", module)
        if cls is not None:
            _emit(qname, "defined_in_class", cls)
        args = node.args
        param_nodes = list(args.posonlyargs) + list(args.args)
        if args.vararg is not None:
            param_nodes.append(args.vararg)
        param_nodes.extend(args.kwonlyargs)
        if args.kwarg is not None:
            param_nodes.append(args.kwarg)
        for arg in param_nodes:
            if arg.arg in ("self", "cls"):
                continue
            _emit(qname, "param_of", arg.arg)
            counters["n_params"] += 1
        for deco in node.decorator_list:
            name = _expr_simple_name(deco)
            if name:
                _emit(qname, "decorated_by", name)
        ret_kind = "none"
        for sub in ast.walk(node):
            if isinstance(sub, ast.Call):
                callee = _expr_simple_name(sub.func)
                if callee:
                    _emit(qname, "calls", callee)
                    _emit(callee, "called_by", qname)
                    counters["n_calls"] += 1
            if isinstance(sub, ast.Return) and sub.value is not None:
                if isinstance(sub.value, ast.Tuple):
                    ret_kind = "tuple"
                elif ret_kind == "none":
                    ret_kind = "expr"
            if isinstance(sub, (ast.Yield, ast.YieldFrom)):
                ret_kind = "yield"
        _emit(qname, "returns_kind", ret_kind)

    def _walk(node: ast.AST, cls: str | None = None) -> None:
        if isinstance(node, ast.ClassDef):
            counters["n_classes"] += 1
            full_cls = f"{cls}.{node.name}" if cls else node.name
            qclass = qualified_name(module, None, full_cls)
            _emit(qclass, "defined_in_module", module)
            for base in node.bases:
                base_name = _expr_simple_name(base)
                if base_name:
                    _emit(qclass, "inherits", base_name)
            for stmt in node.body:
                _walk(stmt, cls=full_cls)
            return
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            _walk_function(node, cls)
            return
        if isinstance(node, ast.ImportFrom) and node.module:
            _emit(module, "imports_from", node.module)
            return
        if isinstance(node, ast.Import):
            for alias in node.names:
                _emit(module, "imports_from", alias.name.split(".")[0])
            return
        for child in ast.iter_child_nodes(node):
            _walk(child, cls=cls)

    for top in tree.body:
        _walk(top)

    info = {"module": module}
    info.update(counters)
    return triples, info


def _extract_js_ts(path: Path, root: Path) -> tuple[
    list[tuple[str, str, str]], dict
]:
    """Invoke @neruva/js-extractor as a subprocess. Returns same
    (triples, info) shape as `_parse_file_triples`. If extractor is
    unavailable, returns an empty result with `error="no-extractor"`.
    """
    if JS_EXTRACTOR_PATH is None or shutil.which("node") is None:
        return [], {"n_functions": 0, "n_classes": 0, "n_methods": 0,
                    "n_calls": 0, "n_params": 0, "module": "",
                    "error": "no-extractor"}
    try:
        proc = subprocess.run(
            ["node", str(JS_EXTRACTOR_PATH), str(path),
             "--root", str(root)],
            capture_output=True, text=True, timeout=60,
            encoding="utf-8",
        )
    except subprocess.TimeoutExpired:
        return [], {"n_functions": 0, "n_classes": 0, "n_methods": 0,
                    "n_calls": 0, "n_params": 0, "module": "",
                    "error": "timeout"}
    if proc.returncode != 0:
        return [], {"n_functions": 0, "n_classes": 0, "n_methods": 0,
                    "n_calls": 0, "n_params": 0, "module": "",
                    "error": f"exit:{proc.returncode}",
                    "stderr": proc.stderr[:300]}
    try:
        out = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return [], {"n_functions": 0, "n_classes": 0, "n_methods": 0,
                    "n_calls": 0, "n_params": 0, "module": "",
                    "error": "json-decode"}
    triples = [tuple(t) for t in out.get("triples", [])]
    info = out.get("info", {})
    info.setdefault("n_methods", 0)
    return triples, info


def walk_tree(
    root: Path, exclude: Iterable[str] = DEFAULT_EXCLUDE
) -> tuple[list[tuple[str, str, str]], dict]:
    excluded = set(exclude)
    all_triples: list[tuple[str, str, str]] = []
    agg = {"files": 0, "py_files": 0, "js_files": 0, "ts_files": 0,
           "n_functions": 0, "n_classes": 0,
           "n_methods": 0, "n_calls": 0, "n_params": 0,
           "errors": 0, "js_skipped": 0, "ts_skipped": 0}
    js_available = JS_EXTRACTOR_PATH is not None and \
        shutil.which("node") is not None
    ts_extract = None
    if TS_AVAILABLE:
        try:
            from neruva_record._code_index_treesitter import extract as ts_extract
        except ImportError:
            ts_extract = None
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in excluded]
        for fn in filenames:
            p = Path(dirpath) / fn
            suffix = p.suffix.lower()
            if suffix == ".py":
                try:
                    triples, info = _parse_file_triples(p, root)
                    all_triples.extend(triples)
                    agg["files"] += 1
                    agg["py_files"] += 1
                    for k in ("n_functions", "n_methods", "n_classes",
                              "n_calls", "n_params"):
                        agg[k] += int(info.get(k, 0))
                except Exception:
                    agg["errors"] += 1
            elif suffix in JS_EXTENSIONS:
                if not js_available:
                    agg["js_skipped"] += 1
                    continue
                try:
                    triples, info = _extract_js_ts(p, root)
                    if info.get("error"):
                        agg["errors"] += 1
                        continue
                    all_triples.extend(triples)
                    agg["files"] += 1
                    agg["js_files"] += 1
                    for k in ("n_functions", "n_classes", "n_methods",
                              "n_calls", "n_params"):
                        agg[k] += int(info.get(k, 0))
                except Exception:
                    agg["errors"] += 1
            elif suffix in TS_EXTENSIONS:
                if ts_extract is None:
                    agg["ts_skipped"] += 1
                    continue
                try:
                    triples, info = ts_extract(p, root)
                    if info.get("error"):
                        # Per-parser missing (e.g. no tree-sitter-rust) is
                        # a soft skip, not an error.
                        if str(info["error"]).startswith("no-parser"):
                            agg["ts_skipped"] += 1
                        else:
                            agg["errors"] += 1
                        continue
                    all_triples.extend(triples)
                    agg["files"] += 1
                    agg["ts_files"] += 1
                    for k in ("n_functions", "n_classes", "n_methods",
                              "n_calls", "n_params"):
                        agg[k] += int(info.get(k, 0))
                except Exception:
                    agg["errors"] += 1
    return all_triples, agg


def push_facts(
    base_url: str, api_key: str, kg_name: str,
    facts: list[tuple[str, str, str]],
    engine: str = "hadamard", batch_size: int = DEFAULT_BATCH,
) -> dict:
    url = f"{base_url}/v1/hd/kg/{kg_name}/facts"
    headers = {"Api-Key": api_key, "Content-Type": "application/json"}
    added_total = 0
    batches = 0
    last_total = 0
    last_relations = 0
    with httpx.Client(timeout=60.0) as client:
        for i in range(0, len(facts), batch_size):
            chunk = facts[i:i + batch_size]
            body = {
                "facts": [
                    {"subject": s, "relation": r, "object": o}
                    for s, r, o in chunk
                ],
                "engine": engine,
            }
            r = client.post(url, headers=headers, json=body)
            r.raise_for_status()
            data = r.json()
            added_total += int(data.get("added", 0))
            last_total = int(data.get("total_facts", 0))
            last_relations = int(data.get("relations", 0))
            batches += 1
    return {"added": added_total, "batches": batches,
            "last_total": last_total, "last_relations": last_relations}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="neruva-record-code-index",
        description=(
            "Walk a Python codebase, extract (s, r, o) triples via "
            "stdlib ast, push to Neruva substrate KG."
        ),
    )
    parser.add_argument("path", type=str,
                        help="Path to directory or .py file to index")
    parser.add_argument("--kg-name", type=str, default=None,
                        help="KG name on substrate (default: code-<basename>)")
    parser.add_argument("--engine", type=str, default="hadamard",
                        choices=("hadamard", "opb", "multishard",
                                 "quorum", "feature_bundle"))
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH)
    parser.add_argument("--api-url", type=str,
                        default=os.environ.get("NERUVA_API_URL",
                                               DEFAULT_API_URL))
    parser.add_argument("--api-key", type=str,
                        default=os.environ.get("NERUVA_API_KEY"))
    parser.add_argument("--dry-run", action="store_true",
                        help="Parse only; print counts; do not push")
    args = parser.parse_args(argv)

    if not args.api_key and not args.dry_run:
        print("error: --api-key not set and NERUVA_API_KEY not in env",
              file=sys.stderr)
        return 2

    target = Path(args.path).resolve()
    if not target.exists():
        print(f"error: path not found: {target}", file=sys.stderr)
        return 2

    if target.is_file():
        root = target.parent
        suffix = target.suffix.lower()
        if suffix == ".py":
            triples, info = _parse_file_triples(target, root)
        elif suffix in JS_EXTENSIONS:
            triples, info = _extract_js_ts(target, root)
        elif suffix in TS_EXTENSIONS and TS_AVAILABLE:
            from neruva_record._code_index_treesitter import extract as ts_extract
            triples, info = ts_extract(target, root)
        else:
            triples, info = [], {"error": f"unsupported extension: {suffix}"}
        agg = {"files": 1,
               "n_functions": info.get("n_functions", 0),
               "n_classes": info.get("n_classes", 0),
               "n_methods": info.get("n_methods", 0),
               "n_calls": info.get("n_calls", 0),
               "n_params": info.get("n_params", 0),
               "errors": 1 if info.get("error") else 0,
               "py_files": 1 if suffix == ".py" else 0,
               "js_files": 1 if suffix in JS_EXTENSIONS else 0,
               "ts_files": 1 if suffix in TS_EXTENSIONS else 0,
               "js_skipped": 0, "ts_skipped": 0}
    else:
        root = target
        triples, agg = walk_tree(root)

    kg_name = args.kg_name or f"code-{target.name}"
    print(f"path     : {target}")
    print(f"root     : {root}")
    print(f"kg-name  : {kg_name}  (engine={args.engine})")
    print(f"files    : {agg['files']}  "
          f"(py={agg.get('py_files', 0)}, "
          f"js={agg.get('js_files', 0)}, "
          f"ts={agg.get('ts_files', 0)})")
    print(f"funcs    : {agg['n_functions']}")
    print(f"classes  : {agg['n_classes']}")
    print(f"methods  : {agg.get('n_methods', 0)}")
    print(f"call edg : {agg['n_calls']}")
    print(f"params   : {agg['n_params']}")
    print(f"errors   : {agg['errors']}")
    if agg.get("js_skipped"):
        print(f"js skip  : {agg['js_skipped']} "
              f"(install @neruva/js-extractor or set "
              f"NERUVA_JS_EXTRACTOR=<path>)")
    if agg.get("ts_skipped"):
        print(f"ts skip  : {agg['ts_skipped']} "
              f"(install: pip install 'neruva-record[multilang]')")
    print(f"triples  : {len(triples)}")

    if args.dry_run:
        print("[dry-run] skipping push")
        return 0

    print(f"\npushing to {args.api_url}/v1/hd/kg/{kg_name}/facts ...")
    try:
        result = push_facts(
            args.api_url, args.api_key, kg_name, triples,
            engine=args.engine, batch_size=args.batch_size,
        )
    except httpx.HTTPStatusError as e:
        print(f"error: HTTP {e.response.status_code}: "
              f"{e.response.text[:300]}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"error: push failed: {e!r}", file=sys.stderr)
        return 1

    print(f"added    : {result['added']}")
    print(f"batches  : {result['batches']}")
    print(f"kg.total : {result['last_total']}")
    print(f"kg.rels  : {result['last_relations']}")
    print("ok")
    return 0


if __name__ == "__main__":
    sys.exit(main())
