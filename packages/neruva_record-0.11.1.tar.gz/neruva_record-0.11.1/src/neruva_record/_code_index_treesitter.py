"""neruva-record code-index multilang extractor (tree-sitter).

Adds Go / Rust / Java / Ruby / C++ to the code-index pipeline. The
existing dispatch in `_code_index.walk_tree`:

    .py                 -> stdlib ast (validated, zero deps)
    .js/.ts/.jsx/.tsx   -> @neruva/js-extractor (Node subprocess, Babel)
    .go/.rs/.java/.rb   -> THIS MODULE (tree-sitter, in-process)
    .cpp/.hpp/.cc/.cxx
    .c/.h               -> THIS MODULE (treated as C++)

All extractors emit the same triple schema as the Python/JS paths:

    defined_in_module, defined_in_class, param_of, returns_kind,
    imports_from, inherits, implements, calls, called_by, decorated_by

Shipped behind the optional dependency ``neruva-record[multilang]``.
If tree-sitter or any per-language parser is missing, the file is
counted in ``ts_skipped`` (not ``errors``) and the run continues.
"""
from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any


# Cache of loaded (Language, Parser) tuples per language tag.
_PARSER_CACHE: dict[str, tuple[Any, Any] | None] = {}

# (suffix tuple, language tag). Match in order; first hit wins.
_SUFFIX_LANG: tuple[tuple[tuple[str, ...], str], ...] = (
    ((".go",), "go"),
    ((".rs",), "rust"),
    ((".java",), "java"),
    ((".rb",), "ruby"),
    ((".cpp", ".cxx", ".cc", ".hpp", ".hxx", ".hh", ".h", ".c"), "cpp"),
)


def suffix_to_lang(suffix: str) -> str | None:
    s = suffix.lower()
    for suffixes, lang in _SUFFIX_LANG:
        if s in suffixes:
            return lang
    return None


def _get_parser(lang: str):
    """Return (Language, Parser) for ``lang`` or None if unavailable.
    Cached. Soft-import: callers should treat None as 'skip this file'.
    """
    if lang in _PARSER_CACHE:
        return _PARSER_CACHE[lang]
    try:
        from tree_sitter import Language, Parser
    except ImportError:
        _PARSER_CACHE[lang] = None
        return None
    try:
        mod = importlib.import_module(f"tree_sitter_{lang}")
    except ImportError:
        _PARSER_CACHE[lang] = None
        return None
    try:
        language = Language(mod.language())
        parser = Parser(language)
        _PARSER_CACHE[lang] = (language, parser)
        return _PARSER_CACHE[lang]
    except Exception:
        _PARSER_CACHE[lang] = None
        return None


def _module_path(file_path: Path, root: Path) -> str:
    """Same convention as Python/JS extractors: dotted path from root."""
    try:
        rel = file_path.resolve().relative_to(root.resolve())
    except ValueError:
        rel = Path(file_path.name)
    parts = list(rel.with_suffix("").parts)
    return ".".join(parts) if parts else file_path.stem


def _qualified(module: str, cls: str | None, fn: str) -> str:
    return f"{module}::{cls}.{fn}" if cls else f"{module}::{fn}"


def _text(node) -> str:
    return node.text.decode("utf-8", errors="replace") if node is not None else ""


def _empty_info(module: str, **extras) -> dict:
    info = {"module": module, "n_functions": 0, "n_methods": 0,
            "n_classes": 0, "n_calls": 0, "n_params": 0}
    info.update(extras)
    return info


# ----------------------------- Go -------------------------------------------

def _extract_go(parser, src: str, module: str) -> tuple[list[tuple[str, str, str]], dict]:
    tree = parser.parse(src.encode("utf-8"))
    triples: list[tuple[str, str, str]] = []
    info = _empty_info(module)

    def emit(s, r, o): triples.append((s, r, o))

    def walk_calls(node, qname):
        if node.type == "call_expression":
            fn = node.child_by_field_name("function")
            name = None
            if fn is not None:
                if fn.type == "identifier":
                    name = _text(fn)
                elif fn.type == "selector_expression":
                    field = fn.child_by_field_name("field")
                    name = _text(field) if field else None
            if name:
                emit(qname, "calls", name)
                emit(name, "called_by", qname)
                info["n_calls"] += 1
        for c in node.children:
            walk_calls(c, qname)

    def walk_function(node, cls):
        name_node = node.child_by_field_name("name")
        if name_node is None:
            # method_declaration uses a `name` field in newer grammars but
            # some emit a bare field_identifier child.
            for c in node.children:
                if c.type == "field_identifier":
                    name_node = c
                    break
        if name_node is None:
            return
        fn_name = _text(name_node)
        info["n_functions"] += 1
        if cls is not None:
            info["n_methods"] += 1
        qname = _qualified(module, cls, fn_name)
        emit(qname, "defined_in_module", module)
        if cls is not None:
            emit(qname, "defined_in_class", cls)
        params = node.child_by_field_name("parameters")
        if params is not None:
            for p in params.children:
                if p.type == "parameter_declaration":
                    for c in p.children:
                        if c.type == "identifier":
                            pn = _text(c)
                            emit(qname, "param_of", pn)
                            info["n_params"] += 1
        result = node.child_by_field_name("result")
        emit(qname, "returns_kind", "expr" if result is not None else "none")
        body = node.child_by_field_name("body")
        if body is not None:
            walk_calls(body, qname)

    def walk(node):
        if node.type == "package_clause":
            for c in node.children:
                if c.type == "package_identifier":
                    pass  # package name is the module-level scope; ignored here
            return
        if node.type == "import_declaration":
            # Two shapes:
            #   import "fmt"                 -> import_spec child
            #   import ( "fmt" "strings" )   -> import_spec_list -> import_spec*
            def _walk_import(n):
                if n.type == "import_spec":
                    for c in n.children:
                        if c.type == "interpreted_string_literal":
                            s = _text(c).strip('"')
                            if s:
                                emit(module, "imports_from", s.split("/")[-1])
                            return
                for c in n.children:
                    _walk_import(c)
            _walk_import(node)
            return
        if node.type == "type_declaration":
            for spec in node.children:
                if spec.type == "type_spec":
                    name_node = None
                    type_node = None
                    for c in spec.children:
                        if c.type == "type_identifier" and name_node is None:
                            name_node = c
                        elif c.type in ("struct_type", "interface_type"):
                            type_node = c
                    if name_node is not None and type_node is not None:
                        info["n_classes"] += 1
                        qcls = _qualified(module, None, _text(name_node))
                        emit(qcls, "defined_in_module", module)
            return
        if node.type == "method_declaration":
            # Receiver tells us the class
            recv = node.child_by_field_name("receiver")
            cls = None
            if recv is not None:
                # parameter_declaration -> identifier + (pointer_type)? type_identifier
                for c in recv.children:
                    if c.type == "parameter_declaration":
                        for cc in c.children:
                            if cc.type == "type_identifier":
                                cls = _text(cc)
                            elif cc.type == "pointer_type":
                                for ccc in cc.children:
                                    if ccc.type == "type_identifier":
                                        cls = _text(ccc)
            walk_function(node, cls)
            return
        if node.type == "function_declaration":
            walk_function(node, None)
            return
        for c in node.children:
            walk(c)

    walk(tree.root_node)
    return triples, info


# ----------------------------- Rust -----------------------------------------

def _extract_rust(parser, src: str, module: str) -> tuple[list, dict]:
    tree = parser.parse(src.encode("utf-8"))
    triples: list[tuple[str, str, str]] = []
    info = _empty_info(module)

    def emit(s, r, o): triples.append((s, r, o))

    def walk_calls(node, qname):
        if node.type == "call_expression":
            fn = node.child_by_field_name("function")
            name = None
            if fn is not None:
                if fn.type == "identifier":
                    name = _text(fn)
                elif fn.type == "field_expression":
                    field = fn.child_by_field_name("field")
                    name = _text(field) if field else None
                elif fn.type == "scoped_identifier":
                    name = _text(fn.child_by_field_name("name") or fn).rsplit("::", 1)[-1]
            if name:
                emit(qname, "calls", name)
                emit(name, "called_by", qname)
                info["n_calls"] += 1
        elif node.type == "macro_invocation":
            # Rust macros like `format!`, `println!`, `vec!` are common
            # callsite shapes; count them so the call graph isn't blind
            # to them.
            macro = node.child_by_field_name("macro")
            if macro is not None:
                name = _text(macro).rsplit("::", 1)[-1]
                if name:
                    emit(qname, "calls", name)
                    emit(name, "called_by", qname)
                    info["n_calls"] += 1
        for c in node.children:
            walk_calls(c, qname)

    def walk_function(node, cls):
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        fn_name = _text(name_node)
        info["n_functions"] += 1
        if cls is not None:
            info["n_methods"] += 1
        qname = _qualified(module, cls, fn_name)
        emit(qname, "defined_in_module", module)
        if cls is not None:
            emit(qname, "defined_in_class", cls)
        params = node.child_by_field_name("parameters")
        if params is not None:
            for p in params.children:
                if p.type == "parameter":
                    pat = p.child_by_field_name("pattern")
                    if pat is not None and pat.type == "identifier":
                        pn = _text(pat)
                        if pn not in ("self", "&self", "&mut self"):
                            emit(qname, "param_of", pn)
                            info["n_params"] += 1
                elif p.type == "self_parameter":
                    continue
        ret = node.child_by_field_name("return_type")
        emit(qname, "returns_kind", "expr" if ret is not None else "none")
        body = node.child_by_field_name("body")
        if body is not None:
            walk_calls(body, qname)

    def walk(node, cls=None):
        if node.type == "use_declaration":
            for c in node.children:
                if c.type in ("scoped_identifier", "identifier", "scoped_use_list"):
                    top = _text(c).split("::")[0]
                    if top:
                        emit(module, "imports_from", top)
            return
        if node.type == "struct_item" or node.type == "enum_item" or node.type == "trait_item":
            name_node = node.child_by_field_name("name")
            if name_node is not None:
                info["n_classes"] += 1
                qcls = _qualified(module, None, _text(name_node))
                emit(qcls, "defined_in_module", module)
                if node.type == "trait_item":
                    pass  # trait body might have function_signature; skip
            return
        if node.type == "impl_item":
            type_node = node.child_by_field_name("type")
            trait_node = node.child_by_field_name("trait")
            cls_name = _text(type_node) if type_node is not None else None
            if trait_node is not None and cls_name is not None:
                # `impl Trait for Type` -> Type implements Trait
                emit(_qualified(module, None, cls_name), "implements", _text(trait_node))
            body = node.child_by_field_name("body")
            if body is not None:
                for c in body.children:
                    if c.type == "function_item":
                        walk_function(c, cls_name)
            return
        if node.type == "function_item":
            walk_function(node, cls)
            return
        if node.type == "mod_item":
            # Inline modules: walk body with prefixed module context skipped
            body = node.child_by_field_name("body")
            if body is not None:
                for c in body.children:
                    walk(c, cls)
            return
        for c in node.children:
            walk(c, cls)

    walk(tree.root_node)
    return triples, info


# ----------------------------- Java -----------------------------------------

def _extract_java(parser, src: str, module: str) -> tuple[list, dict]:
    tree = parser.parse(src.encode("utf-8"))
    triples: list[tuple[str, str, str]] = []
    info = _empty_info(module)

    def emit(s, r, o): triples.append((s, r, o))

    def walk_calls(node, qname):
        if node.type == "method_invocation":
            name_node = node.child_by_field_name("name")
            if name_node is not None:
                name = _text(name_node)
                emit(qname, "calls", name)
                emit(name, "called_by", qname)
                info["n_calls"] += 1
        elif node.type == "object_creation_expression":
            type_node = node.child_by_field_name("type")
            if type_node is not None:
                # `new ArrayList<>()` -> type_node is `generic_type` wrapping
                # a `type_identifier`. Descend to the bare name.
                name = None
                if type_node.type == "type_identifier":
                    name = _text(type_node)
                elif type_node.type == "generic_type":
                    for c in type_node.children:
                        if c.type == "type_identifier":
                            name = _text(c)
                            break
                else:
                    name = _text(type_node)
                if name:
                    emit(qname, "calls", name)
                    emit(name, "called_by", qname)
                    info["n_calls"] += 1
        for c in node.children:
            walk_calls(c, qname)

    def walk_method(node, cls):
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        fn_name = _text(name_node)
        info["n_functions"] += 1
        if cls is not None:
            info["n_methods"] += 1
        qname = _qualified(module, cls, fn_name)
        emit(qname, "defined_in_module", module)
        if cls is not None:
            emit(qname, "defined_in_class", cls)
        # Annotations as decorators
        modifiers = None
        for c in node.children:
            if c.type == "modifiers":
                modifiers = c
                break
        if modifiers is not None:
            for c in modifiers.children:
                if c.type in ("annotation", "marker_annotation"):
                    for cc in c.children:
                        if cc.type == "identifier":
                            emit(qname, "decorated_by", _text(cc))
                            break
        params = node.child_by_field_name("parameters")
        if params is not None:
            for p in params.children:
                if p.type == "formal_parameter":
                    nm = p.child_by_field_name("name")
                    if nm is not None:
                        emit(qname, "param_of", _text(nm))
                        info["n_params"] += 1
        ret = node.child_by_field_name("type")
        # constructor_declaration has no return type field
        is_void = ret is not None and _text(ret) == "void"
        kind = "none" if is_void else "expr"
        emit(qname, "returns_kind", kind)
        body = node.child_by_field_name("body")
        if body is not None:
            walk_calls(body, qname)

    def walk_class(node, outer_cls=None):
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        cls_name = _text(name_node)
        full_cls = f"{outer_cls}.{cls_name}" if outer_cls else cls_name
        info["n_classes"] += 1
        qcls = _qualified(module, None, full_cls)
        emit(qcls, "defined_in_module", module)
        # extends
        superclass = node.child_by_field_name("superclass")
        if superclass is not None:
            for c in superclass.children:
                if c.type in ("type_identifier", "identifier"):
                    emit(qcls, "inherits", _text(c))
                    break
        # implements
        interfaces = node.child_by_field_name("interfaces")
        if interfaces is not None:
            for c in interfaces.children:
                # type_list -> type_identifier...
                if c.type == "type_list":
                    for cc in c.children:
                        if cc.type == "type_identifier":
                            emit(qcls, "implements", _text(cc))
        body = node.child_by_field_name("body")
        if body is not None:
            for c in body.children:
                if c.type in ("method_declaration", "constructor_declaration"):
                    walk_method(c, full_cls)
                elif c.type in ("class_declaration", "interface_declaration"):
                    walk_class(c, full_cls)

    def walk(node):
        if node.type == "package_declaration":
            return
        if node.type == "import_declaration":
            for c in node.children:
                if c.type in ("scoped_identifier", "identifier"):
                    top = _text(c).split(".")[0]
                    if top:
                        emit(module, "imports_from", top)
            return
        if node.type in ("class_declaration", "interface_declaration"):
            walk_class(node)
            return
        for c in node.children:
            walk(c)

    walk(tree.root_node)
    return triples, info


# ----------------------------- Ruby -----------------------------------------

def _extract_ruby(parser, src: str, module: str) -> tuple[list, dict]:
    tree = parser.parse(src.encode("utf-8"))
    triples: list[tuple[str, str, str]] = []
    info = _empty_info(module)

    def emit(s, r, o): triples.append((s, r, o))

    def walk_calls(node, qname):
        if node.type == "call":
            method = node.child_by_field_name("method")
            name = _text(method) if method is not None else None
            if name:
                emit(qname, "calls", name)
                emit(name, "called_by", qname)
                info["n_calls"] += 1
        for c in node.children:
            walk_calls(c, qname)

    def walk_method(node, cls):
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        fn_name = _text(name_node)
        info["n_functions"] += 1
        if cls is not None:
            info["n_methods"] += 1
        qname = _qualified(module, cls, fn_name)
        emit(qname, "defined_in_module", module)
        if cls is not None:
            emit(qname, "defined_in_class", cls)
        params = node.child_by_field_name("parameters")
        if params is not None:
            for p in params.children:
                if p.type == "identifier":
                    emit(qname, "param_of", _text(p))
                    info["n_params"] += 1
                elif p.type in ("optional_parameter", "keyword_parameter",
                                "splat_parameter", "hash_splat_parameter"):
                    nm = p.child_by_field_name("name")
                    if nm is None:
                        for c in p.children:
                            if c.type == "identifier":
                                nm = c
                                break
                    if nm is not None:
                        emit(qname, "param_of", _text(nm))
                        info["n_params"] += 1
        emit(qname, "returns_kind", "expr")  # Ruby methods always return something
        body = node.child_by_field_name("body")
        if body is not None:
            walk_calls(body, qname)

    def walk_class(node, outer_cls=None):
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        cls_name = _text(name_node)
        full_cls = f"{outer_cls}.{cls_name}" if outer_cls else cls_name
        info["n_classes"] += 1
        qcls = _qualified(module, None, full_cls)
        emit(qcls, "defined_in_module", module)
        superclass = node.child_by_field_name("superclass")
        if superclass is not None:
            for c in superclass.children:
                if c.type == "constant":
                    emit(qcls, "inherits", _text(c))
                    break
        body = node.child_by_field_name("body")
        if body is not None:
            for c in body.children:
                if c.type == "method":
                    walk_method(c, full_cls)
                elif c.type == "singleton_method":
                    walk_method(c, full_cls)
                elif c.type == "class":
                    walk_class(c, full_cls)

    def walk(node):
        if node.type == "call":
            # Top-level `require` is the closest thing to an import.
            method = node.child_by_field_name("method")
            if method is not None and _text(method) in ("require", "require_relative", "load"):
                args = node.child_by_field_name("arguments")
                if args is not None:
                    for c in args.children:
                        if c.type == "string":
                            for cc in c.children:
                                if cc.type == "string_content":
                                    emit(module, "imports_from", _text(cc))
                                    break
            # No return: a top-level `require` IS a call too. Fall through.
        if node.type == "class":
            walk_class(node)
            return
        if node.type == "module":
            # Open the module body as a namespace; treat like class for body traversal
            body = node.child_by_field_name("body")
            if body is not None:
                for c in body.children:
                    walk(c)
            return
        if node.type == "method":
            walk_method(node, None)
            return
        for c in node.children:
            walk(c)

    walk(tree.root_node)
    return triples, info


# ----------------------------- C++ ------------------------------------------

def _extract_cpp(parser, src: str, module: str) -> tuple[list, dict]:
    """C++ extractor: classes/structs + top-level functions + method
    definitions defined inside class bodies. Out-of-class
    definitions like `int Foo::bar() {...}` are captured as top-level
    function (qname loses the class scope; documented limitation).
    """
    tree = parser.parse(src.encode("utf-8"))
    triples: list[tuple[str, str, str]] = []
    info = _empty_info(module)

    def emit(s, r, o): triples.append((s, r, o))

    def fn_name_from_declarator(decl):
        """Walk into nested function_declarator -> identifier."""
        if decl is None:
            return None
        if decl.type == "identifier":
            return _text(decl)
        if decl.type == "field_identifier":
            return _text(decl)
        # function_declarator has a `declarator` field child
        inner = decl.child_by_field_name("declarator")
        if inner is not None:
            return fn_name_from_declarator(inner)
        return None

    def walk_calls(node, qname):
        if node.type == "call_expression":
            fn = node.child_by_field_name("function")
            name = None
            if fn is not None:
                if fn.type == "identifier":
                    name = _text(fn)
                elif fn.type == "field_expression":
                    field = fn.child_by_field_name("field")
                    name = _text(field) if field else None
                elif fn.type == "qualified_identifier":
                    # ns::func -> grab last component
                    name = _text(fn).split("::")[-1]
            if name:
                emit(qname, "calls", name)
                emit(name, "called_by", qname)
                info["n_calls"] += 1
        for c in node.children:
            walk_calls(c, qname)

    def walk_function_def(node, cls):
        decl = node.child_by_field_name("declarator")
        fn_name = fn_name_from_declarator(decl)
        if not fn_name:
            return
        info["n_functions"] += 1
        if cls is not None:
            info["n_methods"] += 1
        qname = _qualified(module, cls, fn_name)
        emit(qname, "defined_in_module", module)
        if cls is not None:
            emit(qname, "defined_in_class", cls)
        # params: function_declarator's `parameters` field
        if decl is not None:
            params = decl.child_by_field_name("parameters")
            if params is not None:
                for p in params.children:
                    if p.type == "parameter_declaration":
                        pdecl = p.child_by_field_name("declarator")
                        pname = fn_name_from_declarator(pdecl)
                        if pname:
                            emit(qname, "param_of", pname)
                            info["n_params"] += 1
        ret = node.child_by_field_name("type")
        is_void = ret is not None and _text(ret).strip() == "void"
        emit(qname, "returns_kind", "none" if is_void else "expr")
        body = node.child_by_field_name("body")
        if body is not None:
            walk_calls(body, qname)

    def walk_class(node, outer_cls=None):
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        cls_name = _text(name_node)
        full_cls = f"{outer_cls}.{cls_name}" if outer_cls else cls_name
        info["n_classes"] += 1
        qcls = _qualified(module, None, full_cls)
        emit(qcls, "defined_in_module", module)
        # base classes
        for c in node.children:
            if c.type == "base_class_clause":
                for cc in c.children:
                    if cc.type == "type_identifier":
                        emit(qcls, "inherits", _text(cc))
        body = node.child_by_field_name("body")
        if body is not None:
            for c in body.children:
                if c.type == "function_definition":
                    walk_function_def(c, full_cls)
                elif c.type in ("class_specifier", "struct_specifier"):
                    walk_class(c, full_cls)

    def walk(node):
        if node.type == "preproc_include":
            for c in node.children:
                if c.type in ("system_lib_string", "string_literal"):
                    s = _text(c).strip('<>"')
                    if s:
                        emit(module, "imports_from", s.split("/")[-1].split(".")[0])
            return
        if node.type in ("class_specifier", "struct_specifier"):
            walk_class(node)
            return
        if node.type == "function_definition":
            walk_function_def(node, None)
            return
        if node.type == "namespace_definition":
            body = node.child_by_field_name("body")
            if body is not None:
                for c in body.children:
                    walk(c)
            return
        for c in node.children:
            walk(c)

    walk(tree.root_node)
    return triples, info


# ----------------------------- Public surface -------------------------------

_EXTRACTORS = {
    "go": _extract_go,
    "rust": _extract_rust,
    "java": _extract_java,
    "ruby": _extract_ruby,
    "cpp": _extract_cpp,
}


def extract(path: Path, root: Path) -> tuple[list[tuple[str, str, str]], dict]:
    """Public dispatch. Returns (triples, info). Info contains:
      - module, n_functions, n_methods, n_classes, n_calls, n_params
      - error: one of {None, "no-parser", "no-tree-sitter", "parse"}
    Callers should check info.get("error") and route to the soft-skip
    aggregator if non-None (same pattern as the Babel path).
    """
    lang = suffix_to_lang(path.suffix)
    if lang is None:
        return [], _empty_info(_module_path(path, root), error="unsupported")
    parser_tuple = _get_parser(lang)
    if parser_tuple is None:
        return [], _empty_info(
            _module_path(path, root),
            error=f"no-parser:{lang}",
        )
    _, parser = parser_tuple
    try:
        src = path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return [], _empty_info(_module_path(path, root), error=f"read:{e!r}")
    module = _module_path(path, root)
    fn = _EXTRACTORS[lang]
    try:
        return fn(parser, src, module)
    except Exception as e:
        return [], _empty_info(module, error=f"parse:{e!r}")


def extract_source(src: str, lang: str, module: str = "mod") -> tuple[list, dict]:
    """Convenience entry point for tests: parse a source string directly."""
    parser_tuple = _get_parser(lang)
    if parser_tuple is None:
        return [], _empty_info(module, error=f"no-parser:{lang}")
    _, parser = parser_tuple
    fn = _EXTRACTORS.get(lang)
    if fn is None:
        return [], _empty_info(module, error=f"unknown-lang:{lang}")
    return fn(parser, src, module)


def available_languages() -> set[str]:
    """Set of languages with a working parser in the current env."""
    out = set()
    for lang in _EXTRACTORS:
        if _get_parser(lang) is not None:
            out.add(lang)
    return out
