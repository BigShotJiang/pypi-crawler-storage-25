"""One-command upgrade for the full Neruva client stack.

Fixes the three things that historically went wrong on `pip upgrade`:

  1. Stale __version__ from a prior PyPI release where the maintainer
     forgot to bump the source string. (Now fixed at source via
     importlib.metadata; this CLI just runs the upgrade.)

  2. Two co-existing installs of `neruva-record` -- one in user-site
     (AppData\\Roaming\\Python on Windows, ~/.local on POSIX), one in
     system-site -- whose dist-info disagrees from the actual
     __init__.py loaded by the hook EXE shim. The CLI detects this and
     prints the install paths.

  3. Stale npx cache pinning `npx -y @neruva/mcp@latest` to an ancient
     binary even after PyPI/npm publish. The CLI clears the npm cache
     so the next MCP host restart re-resolves.

Usage:

    neruva-record-upgrade                  # detect + upgrade + clear cache
    neruva-record-upgrade --dry-run        # detect only, no changes
    neruva-record-upgrade --pip-only       # skip the npm cache clean
    neruva-record-upgrade --npm-only       # skip the pip upgrade

After running, fully quit + relaunch your MCP host (Claude Code,
Cursor, Goose, etc) so it picks up the new binary.
"""
from __future__ import annotations

import argparse
import importlib.metadata as im
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional


# Packages we know about. The CLI upgrades neruva-record by default;
# the others are surfaced in the install report so you can see what's
# co-installed.
NERUVA_PYPI_PACKAGES = (
    "neruva-record",
    "neruva-langchain",
    "neruva-langgraph",
    "neruva-crewai",
    "neruva-goose",
    "neruva-mcp",
    "neruva-control",
)


def _detect_duplicate_installs(pkg: str) -> list[tuple[str, Path]]:
    """Return list of (version, dist-info-path) for every install of
    `pkg` discoverable on this Python's sys.path.

    Filters out pip-uninstall tombstone directories (any dist-info dir
    whose name starts with '~' -- pip's marker for an interrupted
    uninstall). These are dead but importlib.metadata still finds them.
    """
    found: list[tuple[str, Path]] = []
    for dist in im.distributions():
        # metadata['Name'] is the canonical PEP 503 name
        name = (dist.metadata.get("Name") or "").lower()
        if name != pkg.lower():
            continue
        path = Path(getattr(dist, "_path", "?"))
        # Skip pip-uninstall tombstones (dist-info dirs starting with '~')
        if path.name.startswith("~"):
            continue
        found.append((dist.version, path))
    return found


def _detect_neruva_inventory() -> dict[str, list[tuple[str, Path]]]:
    """Snapshot every Neruva PyPI package currently visible."""
    out: dict[str, list[tuple[str, Path]]] = {}
    for pkg in NERUVA_PYPI_PACKAGES:
        installs = _detect_duplicate_installs(pkg)
        if installs:
            out[pkg] = installs
    return out


def _print_inventory(inv: dict[str, list[tuple[str, Path]]]) -> int:
    """Print the install report. Returns count of packages with > 1 install."""
    if not inv:
        print("  no Neruva packages detected on this Python.")
        return 0
    duplicates = 0
    print(f"  Python: {sys.executable}")
    print()
    for pkg, installs in sorted(inv.items()):
        if len(installs) == 1:
            ver, path = installs[0]
            print(f"  {pkg}  {ver}")
            print(f"      {path}")
        else:
            duplicates += 1
            print(f"  {pkg}  *** {len(installs)} INSTALLS ***")
            for ver, path in installs:
                print(f"      {ver}  at  {path}")
    if duplicates:
        print()
        print(f"  WARNING: {duplicates} package(s) have duplicate installs.")
        print("  The hook EXE shim resolves whichever copy sys.path finds first;")
        print("  the OTHER copy is shadowed but can still trip diagnostic tools.")
        print("  After upgrade, the stale dist-info(s) should be cleaned up:")
        print("      pip uninstall <pkg>   # answer y to each prompt")
        print("      pip install <pkg>     # reinstall the canonical copy")
    return duplicates


def _pip_upgrade(pkg: str, *, force: bool = True) -> bool:
    """Run pip upgrade for one package against the current interpreter.
    Returns True on success."""
    cmd = [
        sys.executable, "-m", "pip", "install",
        "--no-cache-dir",
        "--upgrade",
    ]
    if force:
        cmd.append("--force-reinstall")
    cmd.append(pkg)
    print(f"  $ {' '.join(cmd)}")
    try:
        r = subprocess.run(cmd, text=True)
    except Exception as e:
        print(f"  ERROR: pip invocation failed: {e}", file=sys.stderr)
        return False
    return r.returncode == 0


def _npm_cache_clean() -> bool:
    """Clear the npm cache so `npx -y @neruva/mcp@latest` re-resolves."""
    npm = shutil.which("npm")
    if not npm:
        print("  npm not on PATH -- skipping npm cache clean.")
        print("  Install Node.js (which ships npm) if you use @neruva/mcp via npx.")
        return False
    cmd = [npm, "cache", "clean", "--force"]
    print(f"  $ {' '.join(cmd)}")
    try:
        r = subprocess.run(cmd, text=True, capture_output=True)
    except Exception as e:
        print(f"  ERROR: npm cache clean failed: {e}", file=sys.stderr)
        return False
    if r.returncode != 0:
        print(f"  npm cache clean returned {r.returncode}: {r.stderr.strip()}",
              file=sys.stderr)
        return False
    return True


def upgrade(
    *,
    dry_run: bool = False,
    pip: bool = True,
    npm: bool = True,
    extra_packages: Optional[list[str]] = None,
) -> int:
    print("Neruva client upgrade")
    print()
    print("Pre-upgrade inventory:")
    inv = _detect_neruva_inventory()
    dups = _print_inventory(inv)
    print()

    if dry_run:
        print("  dry-run: no changes made.")
        return 0 if dups == 0 else 2

    failures = 0

    if pip:
        print("Step 1: pip upgrade")
        # Upgrade every Neruva PyPI package currently installed so the
        # whole stack moves together. Skip ones not present (we don't
        # want to install neruva-control on a user who never had it).
        targets = list(inv.keys())
        for extra in (extra_packages or []):
            if extra not in targets:
                targets.append(extra)
        if not targets:
            targets = ["neruva-record"]
        for pkg in targets:
            ok = _pip_upgrade(pkg)
            if not ok:
                failures += 1
                print(f"  FAIL: {pkg}", file=sys.stderr)
        print()

    if npm:
        print("Step 2: clear npm cache (so @neruva/mcp@latest re-resolves)")
        ok = _npm_cache_clean()
        if not ok:
            failures += 1
        print()

    print("Post-upgrade inventory:")
    _print_inventory(_detect_neruva_inventory())
    print()

    print("Next steps:")
    print("  1. Fully quit + relaunch your MCP host (Claude Code, Cursor, Goose).")
    print("     The host re-resolves npx @latest on launch.")
    print("  2. Confirm the new version in your host's /mcp panel (or equivalent).")
    print("  3. If a duplicate-install warning showed above, run:")
    print("        pip uninstall <pkg>  &&  pip install <pkg>")
    print("     to clean up the shadowed copy.")
    return 0 if failures == 0 else 1


def main() -> int:
    p = argparse.ArgumentParser(
        prog="neruva-record-upgrade",
        description=(
            "Upgrade the Neruva client stack: pip-upgrades every Neruva "
            "PyPI package currently installed against this Python, then "
            "clears the npm cache so @neruva/mcp@latest re-resolves on "
            "next MCP host restart."
        ),
    )
    p.add_argument("--dry-run", action="store_true",
                   help="detect installs only; make no changes")
    p.add_argument("--pip-only", action="store_true",
                   help="skip the npm cache clean")
    p.add_argument("--npm-only", action="store_true",
                   help="skip the pip upgrade")
    p.add_argument("--also", action="append", default=[],
                   metavar="PKG",
                   help="extra Neruva PyPI package to upgrade even if "
                        "not currently installed (repeatable)")
    args = p.parse_args()

    if args.pip_only and args.npm_only:
        print("--pip-only and --npm-only are mutually exclusive.",
              file=sys.stderr)
        return 2

    return upgrade(
        dry_run=args.dry_run,
        pip=not args.npm_only,
        npm=not args.pip_only,
        extra_packages=args.also,
    )


if __name__ == "__main__":
    raise SystemExit(main())
