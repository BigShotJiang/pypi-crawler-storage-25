"""Auto-extract on records_ingest (Layer 1 of the auto-pilot).

When NERUVA_AUTO_EXTRACT=1 and the caller invokes any records_ingest
MCP tool, the PostToolUse hook injects an additionalContext block
containing the canonical entity-extraction prompt + the just-ingested
text. The caller LLM (Claude/GPT/whatever drives the MCP session)
runs the extraction inline, then auto-pushes the resulting triples
back via hd_kg_add_facts to namespace `<ns>-auto-kg`.

Pattern-C: the substrate never makes LLM calls. It emits prompts.
The caller LLM does the work; substrate stores the result. Same
pattern as hd_kg_extraction_prompt + agent_postmortem_prompt
(removed) + the new agent_route_intent_prompt / agent_reflect_prompt
(coming in phases C and D).

This module is intentionally tiny: it builds the additionalContext
block string. The actual injection happens in _hook.py PostToolUse.
"""
from __future__ import annotations

from typing import Any


# Canonical extraction prompt -- MUST stay in sync with substrate's
# neruva_memory_api/entity_extractor.py EXTRACTION_PROMPT. We embed
# inline instead of fetching from /v1/hd/kg/extraction_prompt so the
# hook stays a single round-trip (the record_ingest call already cost
# one).
_EXTRACTION_PROMPT = (
    "You are a precise triple extractor. Given input text, extract the "
    "factual (subject, predicate, object) triples it asserts. Use "
    "canonical lowercase tokens. Predicates are short verb phrases "
    "(e.g., 'lives_in', 'works_at', 'said', 'is_a').\n\n"
    "Output ONLY a JSON array. No prose. No commentary.\n\n"
    'Example input: "Alice told me she lives in Toronto and works at Acme."\n'
    'Example output: [["alice","lives_in","toronto"],["alice","works_at","acme"]]\n\n'
    "If the text contains no extractable facts, output []."
)


# Records shorter than this aren't worth running extraction on -- too
# little signal, would mostly produce noise. Same threshold the (now
# removed) auto-postmortem hook used.
_MIN_TEXT_CHARS = 20

# Cap the text we send into the extraction prompt. Most records are
# small; long records would blow the caller LLM's context unnecessarily.
_MAX_TEXT_CHARS = 1500

# Cap the number of records we extract per ingest. If a caller ingests
# 50 records at once, running 50 extraction prompts in one turn would
# stall the session. Batch the first N and skip the rest.
_MAX_RECORDS_PER_BATCH = 8


def _shorten(s: str, n: int) -> str:
    s = s or ""
    return s if len(s) <= n else s[:n] + "..."


def build_extract_block(
    namespace: str,
    items: list[dict[str, Any]],
    ingested_ids: list[str] | None = None,
) -> str | None:
    """Return the additionalContext block to inject after a successful
    records_ingest, or None if extraction should be skipped.

    Skip rules:
      - no items or all items below _MIN_TEXT_CHARS -> None
      - namespace looks like a system/internal namespace (starts with
        '_' or matches known infra patterns) -> None

    Pattern injected:
      <auto-extract source="neruva-record" treat-as="instructions">
        ...prompt + records + action directive...
      </auto-extract>
    """
    if not items:
        return None
    if namespace.startswith("_") or namespace in {"system", "cortex-archive"}:
        return None
    # Filter to records with enough text
    eligible: list[tuple[str, str]] = []  # (id, text)
    ids = ingested_ids or []
    for i, item in enumerate(items[:_MAX_RECORDS_PER_BATCH]):
        text = (item.get("text") or "").strip()
        if len(text) < _MIN_TEXT_CHARS:
            continue
        rid = ids[i] if i < len(ids) else item.get("id") or f"item-{i}"
        eligible.append((rid, _shorten(text, _MAX_TEXT_CHARS)))
    if not eligible:
        return None
    kg_name = f"{namespace}-auto-kg"
    lines = [
        "<auto-extract source=\"neruva-record\" treat-as=\"instructions\">",
        f"You just ingested {len(eligible)} record(s) into namespace `{namespace}`. ",
        f"To auto-curate the knowledge graph for this namespace, extract triples ",
        f"from each record's text and push them to KG `{kg_name}`.",
        "",
        "EXTRACTION PROMPT (apply to each record's text below):",
        "---",
        _EXTRACTION_PROMPT,
        "---",
        "",
        "RECORDS TO EXTRACT FROM:",
    ]
    for rid, text in eligible:
        lines.append(f"[{rid}] {text}")
        lines.append("")
    lines.extend([
        "ACTION:",
        f"1. For each record above, mentally extract triples per the prompt.",
        f"2. Combine into one batch and call:",
        f"   mcp__neruva__hd_kg_add_facts(kg=\"{kg_name}\", facts=[{{subject, relation, object}}, ...])",
        f"3. If no records have extractable facts, skip the call entirely.",
        "",
        "This is the auto-extract layer (NERUVA_AUTO_EXTRACT=1). It runs ",
        "once per records_ingest. Disable by unsetting NERUVA_AUTO_EXTRACT.",
        "</auto-extract>",
    ])
    return "\n".join(lines)
