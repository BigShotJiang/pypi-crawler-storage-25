"""Auto-reflective writes (Layer 3 of the auto-pilot).

When NERUVA_AUTO_REFLECT is set, the Stop hook (end of an assistant turn)
fetches the canonical reflection prompt from substrate, builds an
additionalContext block, and injects it. The caller LLM sees the
block on the NEXT UserPromptSubmit and is instructed to:

  1. Reflect over the last N turns
  2. Extract durable items (decisions, facts, mistakes, open questions)
  3. Persist via records_ingest + hd_kg_add_facts
  4. Then respond to the new user message normally

Pattern-C: substrate emits the prompt; caller LLM does the reflection.
Substrate stays $0/call.

Cadence v1: simplest possible -- fire on every Stop when the env var
is set to a positive integer. The "every N turns" cadence is deferred
to v0.12 once we have real customer data on perf / noise. Users can
already gate by setting the env var only during sessions where they
want reflection (e.g., long planning sessions, end-of-week wraps).
"""
from __future__ import annotations

from typing import Any

import httpx


_TIMEOUT_S = 5.0
_RECENT_TURNS_LIMIT = 10


def fetch_reflect_block(
    base_url: str,
    api_key: str,
    namespace: str,
) -> str | None:
    """Pull last ~10 turns from substrate, fetch reflect_prompt with them
    substituted, and wrap as additionalContext.

    Returns None on any failure or if there aren't enough recent turns
    (skip if < 3 turns -- no signal worth reflecting on).
    """
    try:
        turns = _fetch_recent_turns(base_url, api_key, namespace, _RECENT_TURNS_LIMIT)
    except Exception:
        return None
    if len(turns) < 3:
        return None
    try:
        r = httpx.post(
            f"{base_url}/v1/agent/reflect_prompt",
            headers={"Api-Key": api_key, "Content-Type": "application/json"},
            json={
                "recent_turns": turns,
                "window_chars": 8000,
            },
            timeout=_TIMEOUT_S,
        )
        if r.status_code != 200:
            return None
        j = r.json()
    except Exception:
        return None
    prompt = j.get("prompt")
    if not isinstance(prompt, str) or not prompt:
        return None
    return _format_reflect_block(prompt, namespace)


def _fetch_recent_turns(
    base_url: str, api_key: str, namespace: str, limit: int,
) -> list[dict[str, Any]]:
    """Pull recent user_prompt + assistant_turn records and shape into
    the {role, text} format the reflect_prompt expects."""
    try:
        r = httpx.post(
            f"{base_url}/v1/records/{namespace}/query",
            headers={"Api-Key": api_key, "Content-Type": "application/json"},
            json={
                "kind": ["user_prompt", "assistant_turn"],
                "topK": limit,
            },
            timeout=_TIMEOUT_S,
        )
        if r.status_code != 200:
            return []
        j = r.json()
    except Exception:
        return []
    records = j.get("records") or []
    # Records come back newest-first; reverse to oldest-first for the prompt.
    out: list[dict[str, Any]] = []
    for rec in reversed(records):
        kind = rec.get("kind") or ""
        text = (rec.get("text") or "").strip()
        if not text:
            continue
        role = "user" if kind == "user_prompt" else "assistant"
        out.append({"role": role, "text": text})
    return out


def _format_reflect_block(reflect_prompt: str, namespace: str) -> str:
    """Wrap the reflection prompt + activation rules in an
    additionalContext block. The agent reads this on its NEXT user turn
    and is instructed to reflect first, then respond.
    """
    auto_kg = f"{namespace}-auto-kg"
    return (
        "<auto-reflect source=\"neruva-record\" treat-as=\"instructions\">\n"
        "BEFORE responding to the user's next message, run a reflection "
        "pass over the recent turns. This is the auto-curator layer -- "
        "you are pinning durable items to substrate so next session "
        "boots with curated context, not raw transcript.\n\n"
        "REFLECTION PROMPT (run internally, then act on the output):\n"
        "---\n"
        f"{reflect_prompt}\n"
        "---\n\n"
        "AFTER reflecting, write the extracted items:\n"
        f"  - decisions -> mcp__neruva__records_ingest(namespace=\"{namespace}\", "
        "items=[{kind:'decision', text, tags:['auto-reflected', ...]}])\n"
        f"  - mistakes  -> mcp__neruva__records_ingest(namespace=\"{namespace}\", "
        "items=[{kind:'mistake', text, tags:['auto-reflected', ...]}])\n"
        f"  - open_qs   -> mcp__neruva__records_ingest(namespace=\"{namespace}\", "
        "items=[{kind:'open_question', text, tags:['auto-reflected', ...]}])\n"
        f"  - facts     -> mcp__neruva__hd_kg_add_facts(kg=\"{auto_kg}\", "
        "facts=[{subject, relation, object}, ...])\n\n"
        "If all four categories are empty, SKIP all writes -- only persist "
        "when something durable actually happened.\n\n"
        "THEN respond to the user's message normally.\n\n"
        "This is the auto-reflect layer (NERUVA_AUTO_REFLECT). It runs "
        "after each assistant turn end. Disable by unsetting NERUVA_AUTO_REFLECT.\n"
        "</auto-reflect>"
    )
