from __future__ import print_function

import os

from vswmc.client import VswmcClient
from vswmc.core import auth


def create_client(args):
    # Bypass auth for local development
    if args.dev:
        return VswmcClient("http://localhost:3000")

    token = resolve_token(args)
    if not token:
        raise Exception(
            "Missing access token. Provide --token, --token-file, or VSWMC_ACCESS_TOKEN."
        )

    credentials = auth.TokenCredentials(token=token)
    return VswmcClient(args.url, credentials=credentials)


def resolve_token(args):
    if args.token:
        return args.token.strip()

    if args.token_file:
        with open(os.path.expanduser(args.token_file), "r") as f:
            return f.read().strip()

    token = os.environ.get("VSWMC_ACCESS_TOKEN")
    return token.strip() if token else None


def print_table(rows, header=False):
    widths = list(map(len, rows[0]))
    for row in rows:
        for idx, col in enumerate(row):
            widths[idx] = max(len(str(col)), widths[idx])

    separator = "  "

    total_width = 0
    for width in widths:
        total_width += width
    total_width += len(separator) * (len(widths) - 1)

    data = rows[1:] if header else rows
    if header and data:
        cols = separator.join(
            [str.ljust(str(col), width) for col, width in zip(rows[0], widths)]
        )
        print(cols)
    if data:
        for row in data:
            cols = separator.join(
                [str.ljust(str(col), width) for col, width in zip(row, widths)]
            )
            print(cols)
