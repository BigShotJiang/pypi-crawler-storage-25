from __future__ import print_function

import os

from vswmc.cli import utils


def do_save(args):
    client = utils.create_client(args)
    content = client.download_results(args.run)

    target_file = args.run + ".zip"
    print("Saving {}".format(target_file))
    with open(target_file, "wb") as f:
        f.write(content)


def do_save_new(args):
    client = utils.create_client(args)
    outputs = client.list_run_outputs(args.run)
    if not outputs:
        print("No outputs available for run {}".format(args.run))
        return
    os.path.makedirs(args.run, exist_ok=True)
    for output in outputs:
        content = client.get_run_output_presign_content(args.run, output["path"])
        target_file = os.path.join(args.run, output["path"])
        print("Saving {}".format(target_file))
        with open(target_file, "wb") as f:
            f.write(content)


def configure_parser(parser):
    parser.set_defaults(func=do_save_new)
    parser.add_argument("run", metavar="RUN", help="The run to save")
