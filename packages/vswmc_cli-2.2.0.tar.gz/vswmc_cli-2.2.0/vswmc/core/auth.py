class TokenCredentials(object):
    def __init__(self, token=None):
        self.token = token
