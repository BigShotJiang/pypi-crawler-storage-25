from cnpjaberto.client import Client, CnpjAbertoError, NotFoundError, RateLimitError, AuthError

__all__ = [
    "Client",
    "CnpjAbertoError",
    "NotFoundError",
    "RateLimitError",
    "AuthError",
]

__version__ = "0.1.1"
