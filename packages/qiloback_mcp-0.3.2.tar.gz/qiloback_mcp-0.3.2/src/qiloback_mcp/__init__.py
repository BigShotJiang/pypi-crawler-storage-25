"""QiloBack MCP Server — AI tool integration for backend manufacturing."""

__version__ = "0.1.0"
