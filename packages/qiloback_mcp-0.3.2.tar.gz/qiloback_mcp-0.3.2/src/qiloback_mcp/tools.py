"""QiloBack MCP — Tool definitions.

Each tool calls the Platform API (http://localhost:8001) via HTTP.
"""

from __future__ import annotations

import json
import os

import httpx
import yaml

PLATFORM_API_URL = os.environ.get("QILOBACK_API_URL", "http://localhost:8001")
API_TOKEN = os.environ.get("QILOBACK_API_TOKEN", "")

_TEMPLATES = [
    "saas-starter",
    "ecommerce",
    "cms",
    "crm",
    "marketplace",
    "social-network",
    "project-management",
    "booking-system",
    "learning-platform",
    "inventory",
]


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if API_TOKEN:
        headers["Authorization"] = f"Bearer {API_TOKEN}"
    return headers


async def _api_get(path: str) -> httpx.Response:
    async with httpx.AsyncClient(base_url=PLATFORM_API_URL, timeout=30) as client:
        return await client.get(path, headers=_headers())


async def _api_post(path: str, data: dict | None = None) -> httpx.Response:
    async with httpx.AsyncClient(base_url=PLATFORM_API_URL, timeout=60) as client:
        return await client.post(path, json=data or {}, headers=_headers())


async def _api_put(path: str, data: dict | None = None) -> httpx.Response:
    async with httpx.AsyncClient(base_url=PLATFORM_API_URL, timeout=30) as client:
        return await client.put(path, json=data or {}, headers=_headers())


async def create_project(name: str, template: str = "") -> str:
    """Create a new QiloBack project.

    Templates: saas-starter, ecommerce, cms, crm, marketplace, social-network,
    project-management, booking-system, learning-platform, inventory.
    Leave template empty for a blank project.
    """
    payload = {"name": name}
    if template:
        payload["template"] = template
    resp = await _api_post("/api/v1/projects", payload)
    if resp.status_code >= 400:
        return f"Error creating project: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def add_entity(project_id: str, name: str, fields: list[dict]) -> str:
    """Add an entity to a project.

    Fields format: [{"name": "title", "type": "string", "required": true, "unique": false}]
    Supported types: string, text, integer, float, decimal, boolean, date, datetime,
    email, url, uuid, json, enum, file, encrypted, slug.
    """
    payload = {"name": name, "fields": fields}
    resp = await _api_post(f"/api/v1/projects/{project_id}/entities", payload)
    if resp.status_code >= 400:
        return f"Error adding entity: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def generate_backend(project_id: str) -> str:
    """Generate the backend from the project's DSL.

    This compiles the YAML DSL into a full FastAPI backend with models,
    schemas, repositories, services, routers, tests, and RLS policies.
    """
    resp = await _api_post(f"/api/v1/projects/{project_id}/generate")
    if resp.status_code >= 400:
        return f"Error generating backend: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def list_projects() -> str:
    """List all QiloBack projects."""
    resp = await _api_get("/api/v1/projects")
    if resp.status_code >= 400:
        return f"Error listing projects: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def get_project_dsl(project_id: str) -> str:
    """Get the DSL YAML of a project.

    Returns the full YAML definition including entities, modules, and configuration.
    """
    resp = await _api_get(f"/api/v1/projects/{project_id}/dsl")
    if resp.status_code >= 400:
        return f"Error fetching DSL: {resp.status_code} — {resp.text}"
    data = resp.json()
    # Return as YAML for readability
    if isinstance(data, dict) and "dsl" in data:
        return data["dsl"]
    return json.dumps(data, indent=2)


async def update_dsl(project_id: str, dsl_yaml: str) -> str:
    """Update a project's DSL with new YAML content.

    The YAML must be valid QiloBack DSL. It will be validated before saving.
    """
    # Validate YAML syntax first
    try:
        yaml.safe_load(dsl_yaml)
    except yaml.YAMLError as e:
        return f"Invalid YAML syntax: {e}"

    resp = await _api_put(f"/api/v1/projects/{project_id}/dsl", {"dsl": dsl_yaml})
    if resp.status_code >= 400:
        return f"Error updating DSL: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def scan_frontend(code: str, language: str = "typescript") -> str:
    """Scan frontend code and generate a backend DSL.

    Analyzes the code to detect API calls, data models, and auth patterns,
    then produces a QiloBack DSL YAML that implements the required backend.
    Supported languages: typescript, javascript, python, dart.
    """
    payload = {"code": code, "language": language}
    resp = await _api_post("/api/v1/scan/frontend", payload)
    if resp.status_code >= 400:
        return f"Error scanning frontend: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def generate_sdk(project_id: str, language: str = "ts") -> str:
    """Generate a client SDK for a project.

    Languages: ts (TypeScript), py (Python), go (Go), dart (Dart).
    Returns the generated SDK code or download information.
    """
    resp = await _api_post(f"/api/v1/projects/{project_id}/sdk", {"language": language})
    if resp.status_code >= 400:
        return f"Error generating SDK: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def list_templates() -> str:
    """List available project templates.

    Templates provide pre-configured DSL definitions for common application types.
    """
    # Try API first, fall back to local list
    try:
        resp = await _api_get("/api/v1/templates")
        if resp.status_code < 400:
            return json.dumps(resp.json(), indent=2)
    except httpx.ConnectError:
        pass

    # Fallback: return known templates
    templates = [
        {"name": t, "description": f"Pre-configured DSL for {t.replace('-', ' ')} applications"} for t in _TEMPLATES
    ]
    return json.dumps({"templates": templates}, indent=2)


async def ai_generate_dsl(description: str) -> str:
    """Generate a backend DSL from a natural language description.

    Describe what your backend needs (entities, auth, billing, etc.)
    and QiloBack will produce a valid DSL YAML.

    Example: "E-commerce with products, orders, customers, payments, and inventory tracking"
    """
    payload = {"description": description}
    resp = await _api_post("/api/v1/ai/generate-dsl", payload)
    if resp.status_code >= 400:
        return f"Error generating DSL: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


# ── Project group ───────────────────────────────────────────────────


async def get_project(project_id: str) -> str:
    """Fetch a single project's metadata (name, slug, status, timestamps)."""
    resp = await _api_get(f"/api/v1/projects/{project_id}")
    if resp.status_code >= 400:
        return f"Error fetching project: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def delete_project(project_id: str) -> str:
    """Soft-delete a project by id. Generated artefacts are kept; the
    project row is marked deleted_at and disappears from list_projects.
    """
    async with httpx.AsyncClient(base_url=PLATFORM_API_URL, timeout=30) as client:
        resp = await client.delete(f"/api/v1/projects/{project_id}", headers=_headers())
    if resp.status_code >= 400:
        return f"Error deleting project: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def eject_project(project_id: str, output_path: str = "") -> str:
    """Download the project's portable backend bundle.

    Calls POST /api/v1/projects/{id}/eject and either saves the zip to
    ``output_path`` (when provided) or returns a base64-encoded preview
    of the first 4 KiB so the AI agent can reason about the bundle
    without holding the whole binary in context.

    The bundle contains the FastAPI source, a Dockerfile, a docker-
    compose stack, a deploy README and an Apache-2.0 license — runs on
    any container host with no QiloBack runtime dependency.
    """
    import base64
    from pathlib import Path

    async with httpx.AsyncClient(base_url=PLATFORM_API_URL, timeout=120) as client:
        resp = await client.post(f"/api/v1/projects/{project_id}/eject", headers=_headers())
    if resp.status_code >= 400:
        return f"Error ejecting project: {resp.status_code} — {resp.text}"

    payload = resp.content
    size = len(payload)
    suggested = resp.headers.get("content-disposition", "")

    if output_path:
        target = Path(output_path).expanduser()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        return json.dumps(
            {
                "saved_to": str(target),
                "bytes": size,
                "suggested_filename": suggested,
            },
            indent=2,
        )

    return json.dumps(
        {
            "bytes": size,
            "suggested_filename": suggested,
            "preview_base64": base64.b64encode(payload[:4096]).decode("ascii"),
            "hint": "Pass output_path to save the full zip to disk.",
        },
        indent=2,
    )


# ── DSL group ───────────────────────────────────────────────────────


async def validate_dsl(project_id: str) -> str:
    """Validate the project's persisted DSL.

    Returns the validator's verdict — ``valid`` plus arrays of errors
    and warnings. Same surface the panel uses before save.
    """
    resp = await _api_post(f"/api/v1/projects/{project_id}/validate")
    if resp.status_code >= 400:
        return f"Error validating DSL: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def diff_dsl(project_id: str, proposed_yaml: str) -> str:
    """Compare a proposed DSL against the persisted one without saving.

    Returns the unified diff plus a structured per-entity summary of
    additions, removals and field-level changes, alongside the
    validator's verdict on the proposal.
    """
    try:
        yaml.safe_load(proposed_yaml)
    except yaml.YAMLError as e:
        return f"Invalid YAML syntax: {e}"

    resp = await _api_post(
        f"/api/v1/projects/{project_id}/dsl/diff",
        {"content": proposed_yaml},
    )
    if resp.status_code >= 400:
        return f"Error computing diff: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


# ── Codegen group ───────────────────────────────────────────────────


async def list_generations(project_id: str) -> str:
    """List the generation history for a project (most recent first).

    Each entry has the DSL hash that was generated, the status, the
    duration, who triggered it and the timestamp.
    """
    resp = await _api_get(f"/api/v1/projects/{project_id}/generations")
    if resp.status_code >= 400:
        return f"Error listing generations: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def get_generation(generation_id: str) -> str:
    """Fetch a single generation log row by id (includes the artefact
    list, DSL hash, error message if any)."""
    resp = await _api_get(f"/api/v1/generations/{generation_id}")
    if resp.status_code >= 400:
        return f"Error fetching generation: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


# ── Migration group ─────────────────────────────────────────────────


async def migration_status(project_id: str) -> str:
    """Return the project's Alembic head and the diff of pending
    migrations against the live DB. Maps to GET /projects/{id}/migrations/status.
    """
    resp = await _api_get(f"/api/v1/projects/{project_id}/migrations/status")
    if resp.status_code >= 400:
        return f"Error fetching migration status: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


# ── Operations group ────────────────────────────────────────────────


async def get_audit_events(
    project_id: str = "",
    event_type: str = "",
    limit: int = 50,
) -> str:
    """Tail the platform audit log.

    Filter by ``project_id`` and/or ``event_type`` (e.g.
    ``ingest.applied``, ``project.created``). The audit log is event-
    sourced with HMAC-chained row signatures; tampering shows up at
    verification time.
    """
    params: list[str] = [f"limit={int(limit)}"]
    if project_id:
        params.append(f"project_id={project_id}")
    if event_type:
        params.append(f"event_type={event_type}")
    qs = "&".join(params)
    resp = await _api_get(f"/api/v1/audit/events?{qs}")
    if resp.status_code >= 400:
        return f"Error fetching audit events: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def health_check() -> str:
    """Hit the platform-api ``/health`` endpoint and return the live
    status payload (database, redis, version)."""
    resp = await _api_get("/health")
    if resp.status_code >= 400:
        return f"Health check failed: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def get_metrics(metric: str = "", range_minutes: int = 60) -> str:
    """Fetch a Prometheus-shaped metrics summary for the platform.

    ``metric`` filters by metric name prefix (empty = all). ``range_minutes``
    is the lookback window (default 60).
    """
    qs = f"range_minutes={int(range_minutes)}"
    if metric:
        qs += f"&metric={metric}"
    resp = await _api_get(f"/api/v1/operations/metrics?{qs}")
    if resp.status_code >= 400:
        return f"Error fetching metrics: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


# ── AI group (review + suggestions) ─────────────────────────────────


async def review_dsl(project_id: str) -> str:
    """Run the AI review pass over the project's DSL.

    The reviewer flags anti-patterns (missing tenant_id on a multi-
    tenant entity, suspect index choices, fields without max_length,
    relations without on-delete behaviour) and returns a structured
    list of findings with suggested edits.
    """
    resp = await _api_post(f"/api/v1/projects/{project_id}/ai/review")
    if resp.status_code >= 400:
        return f"Error running AI review: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


async def suggest_indexes(project_id: str) -> str:
    """Ask the platform for index recommendations on the project's DSL.

    Reads the model graph + recent query patterns and proposes
    composite / partial indexes worth adding.
    """
    resp = await _api_post(f"/api/v1/projects/{project_id}/ai/suggest-indexes")
    if resp.status_code >= 400:
        return f"Error suggesting indexes: {resp.status_code} — {resp.text}"
    return json.dumps(resp.json(), indent=2)


# ── Marketplace (component manifest registry) ──────────────────────


async def list_components() -> str:
    """List the components advertised by the platform's marketplace.

    Returns the same structured payload the panel renders, each entry
    carries name, version, description, tags, the table count and the
    endpoint count. Use this before calling :func:`get_component`
    when an agent wants to browse before installing.
    """
    resp = await _api_get("/api/v1/components")
    if resp.status_code >= 400:
        # Fall back to the bundled manifest set so the tool is useful
        # even when the platform-api is offline / has not implemented
        # the listing endpoint yet.
        return json.dumps(_local_component_summaries(), indent=2)
    return json.dumps(resp.json(), indent=2)


async def get_component(name: str) -> str:
    """Return the full manifest for the named component.

    Same shape the marketplace UI uses to render the install dialog:
    declared tables, endpoints, config knobs, lifecycle hooks and the
    list of files the component will emit into the host project on
    install.
    """
    resp = await _api_get(f"/api/v1/components/{name}")
    if resp.status_code >= 400:
        # Local fallback as in :func:`list_components` — read straight
        # from the bundled registry so the tool keeps working offline.
        local = _local_component_manifest(name)
        if local is None:
            return f"Component not found: {name}"
        return json.dumps(local, indent=2)
    return json.dumps(resp.json(), indent=2)


def _component_registry_dir() -> str | None:
    """Locate the bundled ``packages/components/`` registry.

    Walks up from this file looking for the registry so the lookup
    works in source checkouts, editable installs, and inside the
    PyInstaller bundle once the binary build lands.
    """
    from pathlib import Path

    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "packages" / "components"
        if candidate.is_dir():
            return str(candidate)
    return None  # pragma: no cover — fallback when the bundled registry is absent (wheel-only install)


def _local_component_summaries() -> list[dict[str, object]]:
    """Read every manifest in the bundled registry and project a summary.

    Returns the same lightweight shape the platform-api endpoint
    advertises so callers can switch between the two without
    branching. Empty list when the registry is missing.
    """
    from pathlib import Path

    root = _component_registry_dir()
    if root is None:
        return []
    summaries: list[dict[str, object]] = []
    for entry in sorted(Path(root).iterdir()):
        manifest_path = entry / "component.yaml"
        if not entry.is_dir() or not manifest_path.is_file():
            continue
        try:
            raw = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        component = raw.get("component", {})
        if not component.get("name"):
            continue
        summaries.append(
            {
                "name": component.get("name"),
                "version": component.get("version", "?"),
                "description": component.get("description", ""),
                "tags": component.get("tags", []),
                "table_count": len(raw.get("tables", []) or []),
                "endpoint_count": len(raw.get("endpoints", []) or []),
            }
        )
    return summaries


def _local_component_manifest(name: str) -> dict[str, object] | None:
    """Return the parsed manifest for a single component or None."""
    from pathlib import Path

    root = _component_registry_dir()
    if root is None:
        return None
    manifest_path = Path(root) / name / "component.yaml"
    if not manifest_path.is_file():
        return None
    try:
        raw = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError:
        return None
    return raw if isinstance(raw, dict) else None
