"""QiloBack MCP Server — exposes QiloBack platform as AI tools.

Connects to the Platform API (default: http://localhost:8001) and provides
tools for creating projects, managing entities, generating backends, and more.

Usage:
    # Run directly
    qiloback-mcp

    # Add to Claude Code
    claude mcp add qiloback -- uvx qiloback-mcp

    # Environment variables:
    #   QILOBACK_API_URL   — Platform API URL (default: http://localhost:8001)
    #   QILOBACK_API_TOKEN — Bearer token for API auth (optional)
"""

from __future__ import annotations

from fastmcp import FastMCP

from qiloback_mcp.tools import (
    add_entity,
    ai_generate_dsl,
    create_project,
    delete_project,
    diff_dsl,
    eject_project,
    generate_backend,
    generate_sdk,
    get_audit_events,
    get_component,
    get_generation,
    get_metrics,
    get_project,
    get_project_dsl,
    health_check,
    list_components,
    list_generations,
    list_projects,
    list_templates,
    migration_status,
    review_dsl,
    scan_frontend,
    suggest_indexes,
    update_dsl,
    validate_dsl,
)

mcp = FastMCP(
    "QiloBack",
    instructions=(
        "Backend manufacturing platform. Create, configure, and generate "
        "production-grade FastAPI backends from YAML DSL definitions. "
        "Bundle and download the result with the eject tool — no "
        "QiloBack runtime dependency on the deployed backend."
    ),
)

# Project group
mcp.tool()(create_project)
mcp.tool()(get_project)
mcp.tool()(list_projects)
mcp.tool()(delete_project)
mcp.tool()(eject_project)

# DSL group
mcp.tool()(get_project_dsl)
mcp.tool()(update_dsl)
mcp.tool()(validate_dsl)
mcp.tool()(diff_dsl)
mcp.tool()(add_entity)
mcp.tool()(list_templates)

# Codegen group
mcp.tool()(generate_backend)
mcp.tool()(list_generations)
mcp.tool()(get_generation)
mcp.tool()(generate_sdk)
mcp.tool()(scan_frontend)

# Migration group
mcp.tool()(migration_status)

# Operations group
mcp.tool()(health_check)
mcp.tool()(get_audit_events)
mcp.tool()(get_metrics)

# AI group
mcp.tool()(ai_generate_dsl)
mcp.tool()(review_dsl)
mcp.tool()(suggest_indexes)

# Marketplace group
mcp.tool()(list_components)
mcp.tool()(get_component)


def main() -> None:
    """Entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":  # pragma: no cover — script-mode entry shim
    main()
