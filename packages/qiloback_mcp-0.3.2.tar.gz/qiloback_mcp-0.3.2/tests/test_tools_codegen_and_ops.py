"""Codegen, migration, operations and AI tools.

Covers: generate_backend, list_generations, get_generation, generate_sdk,
scan_frontend, migration_status, get_audit_events, health_check,
get_metrics, ai_generate_dsl, review_dsl, suggest_indexes.
"""

from __future__ import annotations

import json

import pytest
from _fixtures import FakeResponse

# ── Codegen ────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_generate_backend_happy(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/generate",
        FakeResponse(200, json_body={"job_id": "j1", "status": "running"}),
    )
    from qiloback_mcp.tools import generate_backend

    out = await generate_backend("p1")
    assert json.loads(out)["job_id"] == "j1"


@pytest.mark.asyncio
async def test_generate_backend_error(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/generate",
        FakeResponse(500, text="generator down"),
    )
    from qiloback_mcp.tools import generate_backend

    out = await generate_backend("p1")
    assert "Error generating backend: 500" in out


@pytest.mark.asyncio
async def test_list_generations(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects/p1/generations",
        FakeResponse(200, json_body=[{"id": "g1"}, {"id": "g2"}]),
    )
    from qiloback_mcp.tools import list_generations

    out = await list_generations("p1")
    assert len(json.loads(out)) == 2


@pytest.mark.asyncio
async def test_list_generations_error(fake_client):
    fake_client.expect("GET", "/api/v1/projects/p1/generations", FakeResponse(404, text="x"))
    from qiloback_mcp.tools import list_generations

    out = await list_generations("p1")
    assert "Error listing generations: 404" in out


@pytest.mark.asyncio
async def test_get_generation(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/generations/g1",
        FakeResponse(200, json_body={"id": "g1", "status": "success"}),
    )
    from qiloback_mcp.tools import get_generation

    out = await get_generation("g1")
    assert json.loads(out)["status"] == "success"


@pytest.mark.asyncio
async def test_get_generation_error(fake_client):
    fake_client.expect("GET", "/api/v1/generations/missing", FakeResponse(404, text="x"))
    from qiloback_mcp.tools import get_generation

    out = await get_generation("missing")
    assert "Error fetching generation: 404" in out


@pytest.mark.asyncio
async def test_generate_sdk_default_lang(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/sdk",
        FakeResponse(200, json_body={"download": "url"}),
    )
    from qiloback_mcp.tools import generate_sdk

    await generate_sdk("p1")
    assert fake_client.calls[-1].json_body == {"language": "ts"}


@pytest.mark.asyncio
async def test_generate_sdk_explicit_lang(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/sdk",
        FakeResponse(200, json_body={}),
    )
    from qiloback_mcp.tools import generate_sdk

    await generate_sdk("p1", language="dart")
    assert fake_client.calls[-1].json_body == {"language": "dart"}


@pytest.mark.asyncio
async def test_generate_sdk_error(fake_client):
    fake_client.expect("POST", "/api/v1/projects/p1/sdk", FakeResponse(503, text="x"))
    from qiloback_mcp.tools import generate_sdk

    out = await generate_sdk("p1")
    assert "Error generating SDK: 503" in out


@pytest.mark.asyncio
async def test_scan_frontend_default_language(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/scan/frontend",
        FakeResponse(200, json_body={"detected": ["Lead"]}),
    )
    from qiloback_mcp.tools import scan_frontend

    out = await scan_frontend("export const X = 1;")
    assert json.loads(out)["detected"] == ["Lead"]
    assert fake_client.calls[-1].json_body == {
        "code": "export const X = 1;",
        "language": "typescript",
    }


@pytest.mark.asyncio
async def test_scan_frontend_explicit_language(fake_client):
    fake_client.expect("POST", "/api/v1/scan/frontend", FakeResponse(200, json_body={}))
    from qiloback_mcp.tools import scan_frontend

    await scan_frontend("foo = 1", language="python")
    assert fake_client.calls[-1].json_body["language"] == "python"


@pytest.mark.asyncio
async def test_scan_frontend_error(fake_client):
    fake_client.expect("POST", "/api/v1/scan/frontend", FakeResponse(500, text="x"))
    from qiloback_mcp.tools import scan_frontend

    out = await scan_frontend("x = 1")
    assert "Error scanning frontend: 500" in out


# ── Migration ──────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_migration_status_happy(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects/p1/migrations/status",
        FakeResponse(200, json_body={"head": "abc123", "pending": []}),
    )
    from qiloback_mcp.tools import migration_status

    out = await migration_status("p1")
    assert json.loads(out)["head"] == "abc123"


@pytest.mark.asyncio
async def test_migration_status_error(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects/p1/migrations/status",
        FakeResponse(500, text="x"),
    )
    from qiloback_mcp.tools import migration_status

    out = await migration_status("p1")
    assert "Error fetching migration status: 500" in out


# ── Operations ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_health_check_happy(fake_client):
    fake_client.expect("GET", "/health", FakeResponse(200, json_body={"status": "ok"}))
    from qiloback_mcp.tools import health_check

    out = await health_check()
    assert json.loads(out)["status"] == "ok"


@pytest.mark.asyncio
async def test_health_check_error(fake_client):
    fake_client.expect("GET", "/health", FakeResponse(500, text="db down"))
    from qiloback_mcp.tools import health_check

    out = await health_check()
    assert "Health check failed: 500" in out


@pytest.mark.asyncio
async def test_get_metrics_no_filter(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/operations/metrics?range_minutes=60",
        FakeResponse(200, json_body={"metrics": []}),
    )
    from qiloback_mcp.tools import get_metrics

    out = await get_metrics()
    assert json.loads(out) == {"metrics": []}


@pytest.mark.asyncio
async def test_get_metrics_with_filter(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/operations/metrics?range_minutes=15&metric=cpu",
        FakeResponse(200, json_body={}),
    )
    from qiloback_mcp.tools import get_metrics

    await get_metrics(metric="cpu", range_minutes=15)
    assert fake_client.calls[-1].path == "/api/v1/operations/metrics?range_minutes=15&metric=cpu"


@pytest.mark.asyncio
async def test_get_metrics_error(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/operations/metrics?range_minutes=60",
        FakeResponse(500, text="x"),
    )
    from qiloback_mcp.tools import get_metrics

    out = await get_metrics()
    assert "Error fetching metrics: 500" in out


@pytest.mark.asyncio
async def test_get_audit_events_no_filters(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/audit/events?limit=50",
        FakeResponse(200, json_body=[]),
    )
    from qiloback_mcp.tools import get_audit_events

    out = await get_audit_events()
    assert json.loads(out) == []


@pytest.mark.asyncio
async def test_get_audit_events_full_filters(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/audit/events?limit=10&project_id=p1&event_type=ingest.applied",
        FakeResponse(200, json_body=[{"id": "e1"}]),
    )
    from qiloback_mcp.tools import get_audit_events

    out = await get_audit_events(project_id="p1", event_type="ingest.applied", limit=10)
    assert len(json.loads(out)) == 1


@pytest.mark.asyncio
async def test_get_audit_events_error(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/audit/events?limit=50",
        FakeResponse(500, text="x"),
    )
    from qiloback_mcp.tools import get_audit_events

    out = await get_audit_events()
    assert "Error fetching audit events: 500" in out


# ── AI tools ───────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_ai_generate_dsl_happy(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/ai/generate-dsl",
        FakeResponse(200, json_body={"dsl": "..."}),
    )
    from qiloback_mcp.tools import ai_generate_dsl

    out = await ai_generate_dsl("a CRM with companies and contacts")
    assert json.loads(out)["dsl"] == "..."


@pytest.mark.asyncio
async def test_ai_generate_dsl_error(fake_client):
    fake_client.expect("POST", "/api/v1/ai/generate-dsl", FakeResponse(429, text="rate"))
    from qiloback_mcp.tools import ai_generate_dsl

    out = await ai_generate_dsl("...")
    assert "Error generating DSL: 429" in out


@pytest.mark.asyncio
async def test_review_dsl_happy(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/ai/review",
        FakeResponse(200, json_body={"findings": []}),
    )
    from qiloback_mcp.tools import review_dsl

    out = await review_dsl("p1")
    assert json.loads(out)["findings"] == []


@pytest.mark.asyncio
async def test_review_dsl_error(fake_client):
    fake_client.expect("POST", "/api/v1/projects/p1/ai/review", FakeResponse(503, text="x"))
    from qiloback_mcp.tools import review_dsl

    out = await review_dsl("p1")
    assert "Error running AI review: 503" in out


@pytest.mark.asyncio
async def test_suggest_indexes_happy(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/ai/suggest-indexes",
        FakeResponse(200, json_body={"suggested": []}),
    )
    from qiloback_mcp.tools import suggest_indexes

    out = await suggest_indexes("p1")
    assert json.loads(out)["suggested"] == []


@pytest.mark.asyncio
async def test_suggest_indexes_error(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/ai/suggest-indexes",
        FakeResponse(500, text="x"),
    )
    from qiloback_mcp.tools import suggest_indexes

    out = await suggest_indexes("p1")
    assert "Error suggesting indexes: 500" in out
