"""pytest fixtures for the MCP server tests.

Wires the ``fake_client`` fixture; value classes (``FakeResponse``,
``FakeAsyncClient``, ``RecordedCall``) live in ``_fixtures.py`` so test
modules import them by package-relative path and the workspace
collector at the repo root never has to traverse this conftest.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Make the package's tests directory importable regardless of which
# rootdir the pytest collector picks. Critical when the workspace
# at the repo root runs `pytest packages/mcp-server/tests/...`.
_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

# Make ``src/`` importable too — without this, importing
# ``qiloback_mcp`` from a test fails when pytest is invoked from
# anywhere other than ``packages/mcp-server/``.
_SRC = _HERE.parent / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

import pytest
from _fixtures import FakeAsyncClient, FakeResponse  # noqa: F401  (re-exported for tests)
from qiloback_mcp import tools as tools_module


@pytest.fixture
def fake_client(monkeypatch: pytest.MonkeyPatch) -> FakeAsyncClient:
    """Patch ``httpx.AsyncClient`` to a single shared fake.

    The same instance is yielded into the test so it can both
    pre-register expected responses and assert the captured calls.
    """
    instance = FakeAsyncClient()

    def factory(*args, **kwargs) -> FakeAsyncClient:
        instance.base_url = kwargs.get("base_url", "")
        instance.timeout = kwargs.get("timeout", 30.0)
        return instance

    monkeypatch.setattr(tools_module.httpx, "AsyncClient", factory)
    return instance
