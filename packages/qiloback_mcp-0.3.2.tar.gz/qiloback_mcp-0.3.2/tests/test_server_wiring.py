"""Server module — verifies that every tool defined in tools.py is
registered with FastMCP via the @mcp.tool() decorator block. If a
contributor adds a tool function but forgets to wire it into
``server.py``, this test fails loudly so reviewers catch the omission
before publish.
"""

from __future__ import annotations

import inspect

from qiloback_mcp import server, tools


def test_main_callable():
    assert callable(server.main)


def test_mcp_app_named_qiloback():
    assert server.mcp.name == "QiloBack"


def test_mcp_instructions_mention_eject():
    """The eject promise is the product's anti-lock-in pillar; the
    instructions string must surface it so any AI agent reading the
    server's bootstrap message understands the bundle path is real."""
    assert "eject" in server.mcp.instructions.lower()


def test_every_async_tool_function_is_imported_in_server():
    """Inventory check: every async public tool in ``tools`` must be
    accessible from ``server`` (i.e. imported). Without the import
    the @mcp.tool() decorator block can't reach it."""
    expected = sorted(
        name
        for name, obj in inspect.getmembers(tools)
        if inspect.iscoroutinefunction(obj)
        and not name.startswith("_")
        and name not in {"_api_get", "_api_post", "_api_put"}
    )
    server_attrs = {name for name, _ in inspect.getmembers(server)}
    missing = [name for name in expected if name not in server_attrs]
    assert not missing, f"Tools defined but not imported in server.py: {missing}"


def test_tool_count_matches_documented_thirty_two():
    """Pin the documented count from docs/mcp-server.md so we notice
    if a tool appears or disappears without a doc update."""
    expected = sorted(
        name for name, obj in inspect.getmembers(tools) if inspect.iscoroutinefunction(obj) and not name.startswith("_")
    )
    # The MCP server exposes 32 tools per the public documentation;
    # the inventory should be at least 25 (we ship a subset publicly,
    # tools.py also exports private helpers we filter above).
    assert len(expected) >= 25, f"Tool inventory shrank unexpectedly: {expected}"
