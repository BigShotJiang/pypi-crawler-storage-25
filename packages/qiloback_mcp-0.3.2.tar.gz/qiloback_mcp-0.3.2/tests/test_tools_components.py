"""Component-marketplace tools — list_components, get_component — and
their local-fallback helpers (_component_registry_dir,
_local_component_summaries, _local_component_manifest).
"""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest
from _fixtures import FakeResponse

# ── platform-API path ──────────────────────────────────────────


@pytest.mark.asyncio
async def test_list_components_uses_api_when_available(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/components",
        FakeResponse(200, json_body=[{"name": "rate-limit", "version": "1.0"}]),
    )
    from qiloback_mcp.tools import list_components

    out = await list_components()
    assert json.loads(out)[0]["name"] == "rate-limit"


@pytest.mark.asyncio
async def test_get_component_uses_api_when_available(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/components/rate-limit",
        FakeResponse(200, json_body={"component": {"name": "rate-limit"}, "tables": []}),
    )
    from qiloback_mcp.tools import get_component

    out = await get_component("rate-limit")
    assert json.loads(out)["component"]["name"] == "rate-limit"


# ── local fallback ─────────────────────────────────────────────


def _seed_local_registry(root: Path, names: list[str]) -> Path:
    """Build a fake packages/components/{name}/component.yaml tree."""
    components = root / "packages" / "components"
    components.mkdir(parents=True, exist_ok=True)
    for name in names:
        d = components / name
        d.mkdir()
        (d / "component.yaml").write_text(
            textwrap.dedent(
                f"""\
                component:
                  name: {name}
                  version: 1.0.0
                  description: Local fixture for {name}
                  tags: [test, fixture]
                tables:
                  - name: {name}_rows
                  - name: {name}_meta
                endpoints:
                  - path: /api/v1/{name}
                """,
            ),
        )
    return components


@pytest.mark.asyncio
async def test_list_components_falls_back_to_local_when_api_errors(
    fake_client,
    tmp_path,
    monkeypatch,
):
    fake_client.expect("GET", "/api/v1/components", FakeResponse(503, text="x"))
    _seed_local_registry(tmp_path, ["rate-limit", "feature-flags"])
    from qiloback_mcp import tools as mod

    monkeypatch.setattr(mod, "_component_registry_dir", lambda: str(tmp_path / "packages" / "components"))
    out = await mod.list_components()
    body = json.loads(out)
    names = sorted(c["name"] for c in body)
    assert names == ["feature-flags", "rate-limit"]
    # The bundled summary projects table_count + endpoint_count.
    rate = next(c for c in body if c["name"] == "rate-limit")
    assert rate["table_count"] == 2
    assert rate["endpoint_count"] == 1


@pytest.mark.asyncio
async def test_get_component_falls_back_to_local_when_api_errors(
    fake_client,
    tmp_path,
    monkeypatch,
):
    fake_client.expect("GET", "/api/v1/components/rate-limit", FakeResponse(503, text="x"))
    _seed_local_registry(tmp_path, ["rate-limit"])
    from qiloback_mcp import tools as mod

    monkeypatch.setattr(mod, "_component_registry_dir", lambda: str(tmp_path / "packages" / "components"))
    out = await mod.get_component("rate-limit")
    body = json.loads(out)
    assert body["component"]["name"] == "rate-limit"
    assert body["tables"][0]["name"] == "rate-limit_rows"


@pytest.mark.asyncio
async def test_get_component_returns_not_found_when_missing_locally_too(
    fake_client,
    tmp_path,
    monkeypatch,
):
    fake_client.expect("GET", "/api/v1/components/ghost", FakeResponse(503, text="x"))
    _seed_local_registry(tmp_path, ["rate-limit"])
    from qiloback_mcp import tools as mod

    monkeypatch.setattr(mod, "_component_registry_dir", lambda: str(tmp_path / "packages" / "components"))
    out = await mod.get_component("ghost")
    assert "Component not found: ghost" in out


def test_local_component_summaries_skips_invalid_yaml(tmp_path):
    components = _seed_local_registry(tmp_path, ["good-one"])
    bad = components / "broken"
    bad.mkdir()
    (bad / "component.yaml").write_text("this: is: not: valid: yaml\n")

    # Patch the registry dir resolver via direct call.
    from qiloback_mcp import tools as mod
    from qiloback_mcp.tools import _local_component_summaries

    original_locator = mod._component_registry_dir
    mod._component_registry_dir = lambda: str(components)  # type: ignore[assignment]
    try:
        summaries = _local_component_summaries()
    finally:
        mod._component_registry_dir = original_locator  # type: ignore[assignment]

    names = [c["name"] for c in summaries]
    assert "good-one" in names
    assert "broken" not in names


def test_local_component_summaries_returns_empty_when_registry_missing(monkeypatch):
    from qiloback_mcp import tools as mod

    monkeypatch.setattr(mod, "_component_registry_dir", lambda: None)
    assert mod._local_component_summaries() == []


def test_local_component_summaries_skips_entries_without_name(tmp_path, monkeypatch):
    components = tmp_path / "packages" / "components"
    components.mkdir(parents=True)
    (components / "no-name").mkdir()
    (components / "no-name" / "component.yaml").write_text(
        "component:\n  version: 1.0.0\n  description: nameless\n",
    )
    from qiloback_mcp import tools as mod

    monkeypatch.setattr(mod, "_component_registry_dir", lambda: str(components))
    assert mod._local_component_summaries() == []


def test_local_component_manifest_returns_none_when_missing(tmp_path, monkeypatch):
    components = tmp_path / "packages" / "components"
    components.mkdir(parents=True)
    from qiloback_mcp import tools as mod

    monkeypatch.setattr(mod, "_component_registry_dir", lambda: str(components))
    assert mod._local_component_manifest("ghost") is None


def test_local_component_manifest_returns_none_when_registry_missing(monkeypatch):
    from qiloback_mcp import tools as mod

    monkeypatch.setattr(mod, "_component_registry_dir", lambda: None)
    assert mod._local_component_manifest("anything") is None


def test_local_component_manifest_returns_none_on_invalid_yaml(tmp_path, monkeypatch):
    components = tmp_path / "packages" / "components"
    (components / "broken").mkdir(parents=True)
    (components / "broken" / "component.yaml").write_text("broken: : :\n")
    from qiloback_mcp import tools as mod

    monkeypatch.setattr(mod, "_component_registry_dir", lambda: str(components))
    assert mod._local_component_manifest("broken") is None


def test_local_component_manifest_returns_dict_for_valid(tmp_path, monkeypatch):
    components = _seed_local_registry(tmp_path, ["billing-stripe"])
    from qiloback_mcp import tools as mod

    monkeypatch.setattr(mod, "_component_registry_dir", lambda: str(components))
    manifest = mod._local_component_manifest("billing-stripe")
    assert isinstance(manifest, dict)
    assert manifest["component"]["name"] == "billing-stripe"


def test_component_registry_dir_walks_up_to_find_packages_components():
    """The locator must work in source checkouts — verify it finds the
    real packages/components directory in this repo."""
    from qiloback_mcp.tools import _component_registry_dir

    result = _component_registry_dir()
    # The real registry exists in this monorepo; the locator should
    # find it. If the user runs the tests from a sandbox without the
    # registry, the function returns None — also fine.
    if result is not None:
        assert result.endswith("packages/components")
