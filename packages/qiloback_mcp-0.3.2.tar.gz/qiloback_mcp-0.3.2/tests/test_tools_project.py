"""Project-group tools — create, get, list, delete, eject.

Each tool is exercised under both happy and error paths. The shared
fake httpx client (see ``conftest.py``) records every captured call so
the tests assert on URL, method and body shape — the contract with
the platform-api stays explicit.
"""

from __future__ import annotations

import base64
import json

import pytest
from _fixtures import FakeResponse


@pytest.mark.asyncio
async def test_create_project_no_template(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects",
        FakeResponse(200, json_body={"id": "p1", "name": "Acme"}),
    )
    from qiloback_mcp.tools import create_project

    out = await create_project("Acme")
    assert json.loads(out)["id"] == "p1"

    call = fake_client.calls[-1]
    assert call.method == "POST"
    assert call.path == "/api/v1/projects"
    assert call.json_body == {"name": "Acme"}


@pytest.mark.asyncio
async def test_create_project_with_template(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects",
        FakeResponse(200, json_body={"id": "p2"}),
    )
    from qiloback_mcp.tools import create_project

    await create_project("Shop", template="ecommerce")
    assert fake_client.calls[-1].json_body == {"name": "Shop", "template": "ecommerce"}


@pytest.mark.asyncio
async def test_create_project_error_surfaces_status_and_text(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects",
        FakeResponse(409, text="slug already exists"),
    )
    from qiloback_mcp.tools import create_project

    out = await create_project("Acme")
    assert "Error creating project: 409" in out
    assert "slug already exists" in out


@pytest.mark.asyncio
async def test_get_project_happy(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects/p1",
        FakeResponse(200, json_body={"id": "p1", "slug": "acme"}),
    )
    from qiloback_mcp.tools import get_project

    out = await get_project("p1")
    assert json.loads(out)["slug"] == "acme"


@pytest.mark.asyncio
async def test_get_project_not_found(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects/missing",
        FakeResponse(404, text="not found"),
    )
    from qiloback_mcp.tools import get_project

    out = await get_project("missing")
    assert "Error fetching project: 404" in out


@pytest.mark.asyncio
async def test_list_projects(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects",
        FakeResponse(200, json_body=[{"id": "p1"}, {"id": "p2"}]),
    )
    from qiloback_mcp.tools import list_projects

    out = await list_projects()
    payload = json.loads(out)
    assert len(payload) == 2


@pytest.mark.asyncio
async def test_list_projects_error(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects",
        FakeResponse(503, text="db unavailable"),
    )
    from qiloback_mcp.tools import list_projects

    out = await list_projects()
    assert "Error listing projects: 503" in out


@pytest.mark.asyncio
async def test_delete_project_uses_delete_method(fake_client):
    fake_client.expect(
        "DELETE",
        "/api/v1/projects/p1",
        FakeResponse(200, json_body={"ok": True}),
    )
    from qiloback_mcp.tools import delete_project

    out = await delete_project("p1")
    assert json.loads(out)["ok"] is True
    assert fake_client.calls[-1].method == "DELETE"


@pytest.mark.asyncio
async def test_delete_project_error(fake_client):
    fake_client.expect(
        "DELETE",
        "/api/v1/projects/p1",
        FakeResponse(403, text="forbidden"),
    )
    from qiloback_mcp.tools import delete_project

    out = await delete_project("p1")
    assert "Error deleting project: 403" in out


@pytest.mark.asyncio
async def test_eject_project_returns_preview_when_no_output_path(fake_client):
    payload = b"PK\x03\x04" + b"A" * 8192  # zip-like fixture
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/eject",
        FakeResponse(
            200,
            content=payload,
            headers={"content-disposition": "attachment; filename=acme.zip"},
        ),
    )
    from qiloback_mcp.tools import eject_project

    out = await eject_project("p1")
    body = json.loads(out)
    assert body["bytes"] == len(payload)
    assert body["suggested_filename"] == "attachment; filename=acme.zip"
    decoded = base64.b64decode(body["preview_base64"])
    assert decoded == payload[:4096]


@pytest.mark.asyncio
async def test_eject_project_writes_to_disk_when_output_path(fake_client, tmp_path):
    payload = b"zip-content-here"
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/eject",
        FakeResponse(200, content=payload, headers={"content-disposition": ""}),
    )
    from qiloback_mcp.tools import eject_project

    target = tmp_path / "subdir" / "out.zip"
    out = await eject_project("p1", output_path=str(target))
    body = json.loads(out)
    assert body["saved_to"] == str(target)
    assert body["bytes"] == len(payload)
    assert target.read_bytes() == payload


@pytest.mark.asyncio
async def test_eject_project_error(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/eject",
        FakeResponse(500, text="ouch"),
    )
    from qiloback_mcp.tools import eject_project

    out = await eject_project("p1")
    assert "Error ejecting project: 500" in out
