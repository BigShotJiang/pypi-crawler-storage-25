"""Coverage for the few internal branches the public-tool tests can't
naturally exercise: the ``_headers`` token branch, the
``httpx.ConnectError`` fallback in ``list_templates``, the
``_local_component_summaries`` skip-non-dir branch, and the empty-arg
``main()`` shim in server.py.
"""

from __future__ import annotations

import importlib

import httpx
import pytest


def test_headers_attaches_bearer_when_token_present(monkeypatch):
    """The token branch of ``_headers`` is exercised by reloading the
    module after patching the environment so the module-level constant
    picks up the new value."""
    import os

    os.environ["QILOBACK_API_TOKEN"] = "test-token-abc"
    try:
        from qiloback_mcp import tools

        importlib.reload(tools)
        h = tools._headers()
        assert h["Authorization"] == "Bearer test-token-abc"
        assert h["Content-Type"] == "application/json"
    finally:
        os.environ.pop("QILOBACK_API_TOKEN", None)
        # Restore the canonical empty-token state for downstream tests
        from qiloback_mcp import tools as t

        importlib.reload(t)


@pytest.mark.asyncio
async def test_list_templates_falls_back_on_connect_error(monkeypatch):
    """When the platform-api refuses TCP, list_templates returns the
    bundled set instead of bubbling the exception."""
    import json

    from qiloback_mcp import tools

    async def boom(_path):
        raise httpx.ConnectError("simulated connect failure")

    monkeypatch.setattr(tools, "_api_get", boom)
    out = await tools.list_templates()
    body = json.loads(out)
    assert "templates" in body
    assert any(t["name"] == "crm" for t in body["templates"])


def test_local_component_summaries_skips_non_directory_entries(tmp_path, monkeypatch):
    """A stray file at the registry root should be silently ignored."""
    components = tmp_path / "packages" / "components"
    components.mkdir(parents=True)
    (components / "stray.txt").write_text("not a component")
    # Add one valid entry alongside so the function returns something.
    valid = components / "valid"
    valid.mkdir()
    (valid / "component.yaml").write_text(
        "component:\n  name: valid\n  version: 1.0.0\n  description: x\n",
    )
    from qiloback_mcp import tools

    monkeypatch.setattr(tools, "_component_registry_dir", lambda: str(components))
    summaries = tools._local_component_summaries()
    assert [c["name"] for c in summaries] == ["valid"]


def test_main_invokes_mcp_run(monkeypatch):
    """``server.main()`` is the entry point declared in [project.scripts].
    Stub ``mcp.run`` so we exercise the body without spawning a server."""
    from qiloback_mcp import server

    called = {"n": 0}

    def fake_run():
        called["n"] += 1

    monkeypatch.setattr(server.mcp, "run", fake_run)
    server.main()
    assert called["n"] == 1
