"""Test helpers extracted from conftest.py so test modules can import
them by package-relative path. The conftest fixtures keep wiring
``fake_client``; this module owns the ``FakeResponse`` value class
that the test bodies construct directly.
"""

from __future__ import annotations

import json
import typing


class FakeResponse:
    """Drop-in for httpx.Response with the small subset our tools touch."""

    def __init__(
        self,
        status_code: int = 200,
        json_body: object = None,
        text: str = "",
        content: bytes = b"",
        headers: dict[str, str] | None = None,
    ) -> None:
        self.status_code = status_code
        self._json = json_body
        self.text = text or ("" if json_body is None else _safe_text(json_body))
        self.content = content
        self.headers = headers or {}

    def json(self) -> object:
        if self._json is None:
            raise ValueError("no JSON body configured for this fake response")
        return self._json


def _safe_text(payload: object) -> str:
    try:
        return json.dumps(payload)
    except TypeError:
        return str(payload)


class RecordedCall:
    """One captured HTTP call — method, path, body, headers."""

    __slots__ = ("headers", "json_body", "method", "params", "path")

    def __init__(
        self,
        method: str,
        path: str,
        json_body: object | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, object] | None = None,
    ) -> None:
        self.method = method
        self.path = path
        self.json_body = json_body
        self.headers = headers or {}
        self.params = params or {}


class FakeAsyncClient:
    """Async-context manager mimicking ``httpx.AsyncClient``."""

    def __init__(self, base_url: str = "", timeout: float = 30.0) -> None:
        self.base_url = base_url
        self.timeout = timeout
        self._calls: list[RecordedCall] = []
        self._responses: dict[tuple[str, str], FakeResponse] = {}

    async def __aenter__(self) -> FakeAsyncClient:
        return self

    async def __aexit__(self, *_a: object) -> None:  # pragma: no cover — no-op
        return None

    def expect(self, method: str, path: str, response: FakeResponse) -> None:
        self._responses[(method.upper(), path)] = response

    @property
    def calls(self) -> list[RecordedCall]:
        return self._calls

    async def get(self, path: str, headers: dict[str, str] | None = None) -> FakeResponse:
        return self._dispatch("GET", path, headers=headers)

    async def post(
        self,
        path: str,
        json: object | None = None,
        headers: dict[str, str] | None = None,
    ) -> FakeResponse:
        return self._dispatch("POST", path, json_body=json, headers=headers)

    async def put(
        self,
        path: str,
        json: object | None = None,
        headers: dict[str, str] | None = None,
    ) -> FakeResponse:
        return self._dispatch("PUT", path, json_body=json, headers=headers)

    async def delete(
        self,
        path: str,
        headers: dict[str, str] | None = None,
    ) -> FakeResponse:
        return self._dispatch("DELETE", path, headers=headers)

    def _dispatch(
        self,
        method: str,
        path: str,
        json_body: object | None = None,
        headers: dict[str, str] | None = None,
    ) -> FakeResponse:
        self._calls.append(RecordedCall(method, path, json_body, headers))
        key = (method, path)
        if key in self._responses:
            return self._responses[key]
        return FakeResponse(
            status_code=404,
            json_body={"detail": f"unregistered fake call: {method} {path}"},
            text=f"unregistered fake call: {method} {path}",
        )


# Public re-exports
__all__: typing.Final = ["FakeAsyncClient", "FakeResponse", "RecordedCall"]
