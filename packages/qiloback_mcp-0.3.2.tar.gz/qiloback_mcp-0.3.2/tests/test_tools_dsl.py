"""DSL-group tools — get_project_dsl, update_dsl, validate_dsl,
diff_dsl, add_entity, list_templates."""

from __future__ import annotations

import json

import pytest
from _fixtures import FakeResponse


@pytest.mark.asyncio
async def test_get_project_dsl_returns_yaml_when_present(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects/p1/dsl",
        FakeResponse(200, json_body={"dsl": "dsl_version: 1.0\nproject:\n  name: Acme\n"}),
    )
    from qiloback_mcp.tools import get_project_dsl

    out = await get_project_dsl("p1")
    assert out.startswith("dsl_version:")


@pytest.mark.asyncio
async def test_get_project_dsl_falls_through_when_dsl_field_missing(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects/p1/dsl",
        FakeResponse(200, json_body={"raw": "no dsl key"}),
    )
    from qiloback_mcp.tools import get_project_dsl

    out = await get_project_dsl("p1")
    assert json.loads(out) == {"raw": "no dsl key"}


@pytest.mark.asyncio
async def test_get_project_dsl_error(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/projects/p1/dsl",
        FakeResponse(404, text="no project"),
    )
    from qiloback_mcp.tools import get_project_dsl

    out = await get_project_dsl("p1")
    assert "Error fetching DSL: 404" in out


@pytest.mark.asyncio
async def test_update_dsl_rejects_invalid_yaml(fake_client):
    from qiloback_mcp.tools import update_dsl

    out = await update_dsl("p1", "key: value\n  bad: yaml: triple-colon")
    assert "Invalid YAML syntax" in out
    # Server must NOT have been called — invalid input rejected client-side.
    assert fake_client.calls == []


@pytest.mark.asyncio
async def test_update_dsl_happy(fake_client):
    fake_client.expect(
        "PUT",
        "/api/v1/projects/p1/dsl",
        FakeResponse(200, json_body={"ok": True, "version": 2}),
    )
    from qiloback_mcp.tools import update_dsl

    valid = "dsl_version: 1.0\nproject:\n  name: Acme\n"
    out = await update_dsl("p1", valid)
    assert json.loads(out)["version"] == 2
    assert fake_client.calls[-1].json_body == {"dsl": valid}


@pytest.mark.asyncio
async def test_update_dsl_server_error(fake_client):
    fake_client.expect(
        "PUT",
        "/api/v1/projects/p1/dsl",
        FakeResponse(500, text="boom"),
    )
    from qiloback_mcp.tools import update_dsl

    out = await update_dsl("p1", "valid: yaml\n")
    assert "Error updating DSL: 500" in out


@pytest.mark.asyncio
async def test_validate_dsl_happy(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/validate",
        FakeResponse(200, json_body={"valid": True, "errors": [], "warnings": []}),
    )
    from qiloback_mcp.tools import validate_dsl

    out = await validate_dsl("p1")
    assert json.loads(out)["valid"] is True


@pytest.mark.asyncio
async def test_validate_dsl_error(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/validate",
        FakeResponse(404, text="missing"),
    )
    from qiloback_mcp.tools import validate_dsl

    out = await validate_dsl("p1")
    assert "Error validating DSL: 404" in out


@pytest.mark.asyncio
async def test_diff_dsl_rejects_invalid_yaml(fake_client):
    from qiloback_mcp.tools import diff_dsl

    out = await diff_dsl("p1", "bad: yaml: trip:")
    assert "Invalid YAML syntax" in out
    assert fake_client.calls == []


@pytest.mark.asyncio
async def test_diff_dsl_happy(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/dsl/diff",
        FakeResponse(
            200,
            json_body={
                "diff": "+ entity Foo",
                "summary": {"entities_added": ["Foo"]},
                "valid": True,
            },
        ),
    )
    from qiloback_mcp.tools import diff_dsl

    out = await diff_dsl("p1", "dsl_version: 1.0\n")
    body = json.loads(out)
    assert body["summary"]["entities_added"] == ["Foo"]


@pytest.mark.asyncio
async def test_diff_dsl_error(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/dsl/diff",
        FakeResponse(400, text="bad request"),
    )
    from qiloback_mcp.tools import diff_dsl

    out = await diff_dsl("p1", "dsl_version: 1.0\n")
    assert "Error computing diff: 400" in out


@pytest.mark.asyncio
async def test_add_entity_happy(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/entities",
        FakeResponse(200, json_body={"name": "Lead", "id": "e1"}),
    )
    from qiloback_mcp.tools import add_entity

    out = await add_entity(
        "p1",
        "Lead",
        [{"name": "email", "type": "email", "required": True}],
    )
    assert json.loads(out)["id"] == "e1"
    assert fake_client.calls[-1].json_body == {
        "name": "Lead",
        "fields": [{"name": "email", "type": "email", "required": True}],
    }


@pytest.mark.asyncio
async def test_add_entity_error(fake_client):
    fake_client.expect(
        "POST",
        "/api/v1/projects/p1/entities",
        FakeResponse(409, text="duplicate"),
    )
    from qiloback_mcp.tools import add_entity

    out = await add_entity("p1", "Lead", [])
    assert "Error adding entity: 409" in out


@pytest.mark.asyncio
async def test_list_templates_uses_api_when_available(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/templates",
        FakeResponse(200, json_body={"templates": [{"name": "crm"}]}),
    )
    from qiloback_mcp.tools import list_templates

    out = await list_templates()
    assert json.loads(out)["templates"][0]["name"] == "crm"


@pytest.mark.asyncio
async def test_list_templates_falls_back_when_api_errors(fake_client):
    fake_client.expect(
        "GET",
        "/api/v1/templates",
        FakeResponse(500, text="boom"),
    )
    from qiloback_mcp.tools import list_templates

    out = await list_templates()
    body = json.loads(out)
    # 5xx ALSO falls back since the function returns the local list when
    # the API status is >= 400.
    assert "templates" in body
    names = [t["name"] for t in body["templates"]]
    assert "crm" in names
