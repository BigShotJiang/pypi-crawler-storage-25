# qiloback-mcp

MCP (Model Context Protocol) server for QiloBack. Lets AI agents
(Claude Code, Cursor, Windsurf, ChatGPT Desktop, …) drive a QiloBack
platform-api as a first-class tool.

## Install

```bash
pip install qiloback-mcp     # or: uvx qiloback-mcp
```

## Configure (Claude Code)

```bash
claude mcp add qiloback -- uvx qiloback-mcp
```

Set the platform endpoint and (optional) bearer token via environment:

```bash
export QILOBACK_API_URL=http://localhost:8001
export QILOBACK_API_TOKEN=…
```

## Tools

The server exposes tools across six groups:

- **Project** — `create_project`, `get_project`, `list_projects`,
  `delete_project`, `eject_project`
- **DSL** — `get_project_dsl`, `update_dsl`, `validate_dsl`,
  `diff_dsl`, `add_entity`, `list_templates`
- **Codegen** — `generate_backend`, `list_generations`,
  `get_generation`, `generate_sdk`, `scan_frontend`
- **Migration** — `migration_status`
- **Operations** — `health_check`, `get_audit_events`, `get_metrics`
- **AI** — `ai_generate_dsl`, `review_dsl`, `suggest_indexes`

The most opinionated tool is `eject_project`: it returns a portable
zip with the FastAPI source, a Dockerfile, a docker-compose stack and
a deploy README — runs anywhere with no QiloBack runtime dependency.
The artefacts inside the bundle are released under Apache 2.0; the
QiloBack license stays on the generator, not on its output.

## License

`qiloback-mcp` itself ships under FSL-1.1-ALv2 — source-available
during the FSL window, automatic conversion to Apache 2.0 two years
after each release. See the QiloBack
[LICENSE-FAQ.md](https://github.com/delixon-labs/delixon-qiloback/blob/main/LICENSE-FAQ.md)
for the full picture.
