import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from codexussdk import MgbSdk


class TestMgbSdk(unittest.TestCase):
    def test_sdk_creation(self):
        """Test SDK instance creation"""
        sdk = MgbSdk(x19_version="1.1.0")
        self.assertIsNotNone(sdk)
        sdk.close()
    
    def test_sdk_creation_default_version(self):
        """Test SDK with default version"""
        sdk = MgbSdk()
        self.assertIsNotNone(sdk)
        sdk.close()


if __name__ == '__main__':
    unittest.main()
