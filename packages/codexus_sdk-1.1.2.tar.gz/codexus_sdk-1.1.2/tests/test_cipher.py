import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from codexussdk import http_encrypt, http_decrypt, compute_dynamic_token, skip32_encrypt, skip32_decrypt


class TestCipher(unittest.TestCase):
    def test_http_encrypt_decrypt(self):
        """Test HTTP AES encryption and decryption"""
        data = b'Hello World'
        encrypted = http_encrypt(data)
        self.assertIsInstance(encrypted, bytes)
        self.assertGreater(len(encrypted), len(data))
        
        decrypted = http_decrypt(encrypted)
        self.assertEqual(decrypted, data)
    
    def test_http_encrypt_empty(self):
        """Test encrypting empty data"""
        data = b''
        encrypted = http_encrypt(data)
        decrypted = http_decrypt(encrypted)
        self.assertEqual(decrypted, data)
    
    def test_dynamic_token(self):
        """Test dynamic token generation"""
        token = compute_dynamic_token('/test', '{"a":1}', 'user123', 'token456')
        self.assertIsInstance(token, dict)
        self.assertIn('user-id', token)
        self.assertIn('user-token', token)
        self.assertEqual(token['user-id'], 'user123')
        self.assertGreaterEqual(len(token['user-token']), 16)
    
    def test_skip32_roundtrip(self):
        """Test Skip32 encryption roundtrip"""
        key = b'1234567890'
        value = 123456789
        encrypted = skip32_encrypt(value, key)
        decrypted = skip32_decrypt(encrypted, key)
        self.assertEqual(decrypted, value)
    
    def test_skip32_zero(self):
        """Test Skip32 with zero value"""
        key = b'1234567890'
        value = 0
        encrypted = skip32_encrypt(value, key)
        decrypted = skip32_decrypt(encrypted, key)
        self.assertEqual(decrypted, value)


if __name__ == '__main__':
    unittest.main()
