from setuptools import setup, find_packages

setup(
    name="codexus-sdk",
    version="1.1.2",
    description="Python SDK for Codexus OpenSDK - Third-party Minecraft launcher",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Codexus",
    python_requires=">=3.8",
    packages=find_packages(),
    install_requires=[
        "requests>=2.28.0",
        "cryptography>=37.0.0",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
    ],
)
