# Codexus Python SDK

C# Codexus.OpenSDK 的 Python 移植版本，用于网易 Minecraft (X19) 的第三方登录和启动。

## 功能特性

- ✅ 4399 账号密码登录
- ✅ X19 认证流程 (LoginOtp -> AuthenticationOtp)
- ✅ HTTP AES 加密/解密 (HttpCipher)
- ✅ 动态令牌计算 (DynamicToken)
- ✅ SKIP32 加密 (Skip32Cipher)
- ✅ 完整的类型注解和数据模型

## 安装

```bash
# 方式1: 直接安装
pip install codexus-sdk

# 方式2: 从源码安装
git clone https://github.com/your-repo/codexus-sdk.git
cd codexus-sdk
pip install -e .
```

依赖:
- requests >= 2.28.0
- cryptography >= 37.0.0

## 使用示例

```python
from codexussdk import MgbSdk

# 创建 SDK 实例
sdk = MgbSdk(x19_version="1.1.0")

# 登录
result = sdk.login("your_username", "your_password")
if result.success:
    print(f"登录成功: {result.username}")
    
    # 获取游戏令牌
    token = sdk.get_game_token()
    print(f"游戏令牌: {token}")
    
    # 构建启动参数
    params = sdk.build_launch_parameters(
        server_address="mc.example.com",
        server_port=25565,
        player_name="PlayerName",
        version="1.20.1"
    )
    print(f"启动参数: {params}")
else:
    print(f"登录失败: {result.message}")

# 释放资源
sdk.close()
```

## 模块说明

| 模块 | 说明 |
|------|------|
| `codexussdk.cipher` | 加密解密工具 (HttpCipher, DynamicToken, Skip32Cipher) |
| `codexussdk.http_client` | HTTP 客户端封装 |
| `codexussdk.entities` | 数据模型 (LoginResult, X19AuthDetail, MPayUser 等) |
| `codexussdk.c4399` | 4399 登录实现 |
| `codexussdk.x19` | X19 认证实现 |
| `codexussdk.mgb_sdk` | MGB SDK 主入口 |

## 文件结构

```
codexussdk/
├── __init__.py      # 包入口，导出所有公共 API
├── cipher.py        # 加密模块
├── http_client.py   # HTTP 客户端
├── entities.py      # 数据模型
├── c4399.py         # 4399 登录
├── x19.py           # X19 认证
├── mgb_sdk.py       # SDK 主类
├── example.py       # 使用示例
├── setup.py         # 安装配置
├── pyproject.toml   # 现代 Python 包配置
├── requirements.txt # 依赖列表
├── README.md        # 说明文档
└── tests/           # 单元测试
    ├── __init__.py
    ├── test_cipher.py
    └── test_sdk.py
```

## 注意事项

1. 本 SDK 为 C# 版本的 Python 移植，部分实现可能因语言差异而简化
2. X19 认证流程涉及加密通信，实际使用时需要确保网络环境正常
3. 4399 登录可能需要验证码，请根据返回结果处理

## 许可证

GPL 3.0 (与原始 C# SDK 保持一致)
