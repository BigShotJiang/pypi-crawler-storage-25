"""
Codexus Python SDK
==================

C# Codexus.OpenSDK 的 Python 移植版本

主要模块:
    - cipher: 加密解密工具 (HttpCipher, DynamicToken, Skip32Cipher)
    - http_client: HTTP 客户端封装
    - entities: 数据模型
    - c4399: 4399 登录
    - x19: X19 认证
    - mgb_sdk: MGB SDK 主入口

使用示例:
    >>> from CodexusPython import MgbSdk
    >>> sdk = MgbSdk()
    >>> result = sdk.login("username", "password")
    >>> if result.success:
    ...     print(f"登录成功: {result.username}")
    ...     token = sdk.get_game_token()
"""

__version__ = "1.0.0"

from .cipher import (
    compute_dynamic_token,
    http_decrypt,
    http_encrypt,
    skip32_decrypt,
    skip32_encrypt,
)
from .entities import (
    C4399LoginResult,
    LaunchParameters,
    MPayDevice,
    MPayExtInfo,
    MPayUser,
    MPayUserWrapper,
    RegisterResult,
    X19AuthenticationDetail,
    X19Entity,
    X19LoginOtp,
    X19Response,
)
from .http_client import HttpClient, HttpRequestOptions
from .mgb_sdk import MgbSdk

__all__ = [
    # 主类
    "MgbSdk",
    "HttpClient",
    "HttpRequestOptions",
    
    # 加密工具
    "http_encrypt",
    "http_decrypt",
    "compute_dynamic_token",
    "skip32_encrypt",
    "skip32_decrypt",
    
    # 数据模型
    "C4399LoginResult",
    "X19AuthenticationDetail",
    "X19Entity",
    "X19LoginOtp",
    "X19Response",
    "MPayUser",
    "MPayExtInfo",
    "MPayDevice",
    "MPayUserWrapper",
    "LaunchParameters",
    "RegisterResult",
]
