"""
4399 登录模块 - 对应 C# Codexus.OpenSDK.C4399
"""

import json
import re
import time
from typing import Dict, Optional

from .entities import C4399LoginResult
from .http_client import HttpClient, HttpRequestOptions


class C4399Login:
    """
    4399 登录实现
    
    对应 C# Codexus.OpenSDK.C4399 类
    """

    # 4399 登录相关 URL
    LOGIN_URL = "https://ptlogin.4399.com/ptlogin/login.do"
    CAPTCHA_URL = "https://ptlogin.4399.com/ptlogin/captcha.do"
    
    def __init__(self):
        self._http = HttpClient(
            configure_defaults=lambda opts: opts
                .add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .add_header("Referer", "https://ptlogin.4399.com/")
        )
    
    def login_with_password(
        self,
        username: str,
        password: str,
        captcha: Optional[str] = None
    ) -> C4399LoginResult:
        """
        使用密码登录 4399
        
        Args:
            username: 用户名
            password: 密码
            captcha: 验证码 (可选)
            
        Returns:
            登录结果
        """
        result = C4399LoginResult()
        
        try:
            # 构建登录表单
            form_data = {
                "loginFrom": "uframe",
                "postLoginHandler": "default",
                "layoutSelfAdapt": "true",
                "externalLogin": "qq",
                "displayMode": "popup",
                "layout": "vertical",
                "appId": "www_home",
                "gameId": "",
                "css": "",
                "redirectUrl": "",
                "sessionId": "",
                "mainDivId": "login_div",
                "includeFcmInfo": "false",
                "userNameLabel": "4399用户名",
                "userNameTip": "支持4399用户名/邮箱/手机号",
                "welcomeTip": "欢迎登录4399",
                "sec": "",
                "password": password,
                "username": username,
            }
            
            if captcha:
                form_data["captcha"] = captcha
            
            # 发送登录请求
            response = self._http.post_form(
                self.LOGIN_URL,
                form_data,
                configure=lambda opts: opts
                    .add_header("X-Requested-With", "XMLHttpRequest")
                    .add_header("Origin", "https://ptlogin.4399.com")
            )
            
            response_text = response.text
            
            # 解析响应
            if "登录成功" in response_text or '"code":0' in response_text:
                # 提取用户信息
                result.success = True
                result.username = username
                result.message = "登录成功"
                
                # 尝试提取 token
                token_match = re.search(r'"token":"([^"]+)"', response_text)
                if token_match:
                    result.token = token_match.group(1)
                
                # 生成 sAuth (简化实现)
                result.s_auth = self._generate_sauth(username, result.token)
                
            elif "验证码" in response_text or "captcha" in response_text.lower():
                result.message = "需要验证码"
                result.requires_captcha = True
                result.success = False
            else:
                # 提取错误信息
                error_match = re.search(r'"message":"([^"]+)"', response_text)
                if error_match:
                    result.message = error_match.group(1)
                else:
                    result.message = "登录失败"
                result.success = False
                
        except Exception as e:
            result.success = False
            result.message = f"登录异常: {str(e)}"
        
        return result
    
    def get_captcha_image(self) -> Optional[bytes]:
        """
        获取验证码图片
        
        Returns:
            图片字节数据，失败返回 None
        """
        try:
            timestamp = int(time.time() * 1000)
            
            # 尝试多个可能的验证码接口
            captcha_urls = [
                f"{self.CAPTCHA_URL}?t={timestamp}",
                f"https://ptlogin.4399.com/captcha/get?t={timestamp}",
                f"https://ptlogin.4399.com/verifycode?t={timestamp}",
            ]
            
            for url in captcha_urls:
                try:
                    response = self._http.get(
                        url,
                        configure=lambda opts: opts
                            .add_header("Accept", "image/webp,image/apng,image/*,*/*;q=0.8")
                            .add_header("Referer", "https://ptlogin.4399.com/ptlogin/login.do")
                    )
                    if response.status_code == 200 and len(response.content) > 100:
                        content_type = response.headers.get("Content-Type", "")
                        if "image" in content_type:
                            return response.content
                except Exception:
                    continue
        except Exception:
            pass
        return None
    
    def _generate_sauth(self, username: str, token: str) -> str:
        """
        生成 sAuth 字符串 (简化实现)
        
        实际实现需要参考 C# 源码中的加密逻辑
        """
        import hashlib
        data = f"{username}:{token}:{int(time.time())}"
        return hashlib.md5(data.encode()).hexdigest()
    
    def close(self):
        """关闭 HTTP 客户端"""
        self._http.close()
