"""
HTTP 客户端 - 对应 C# Codexus.OpenSDK.Http.HttpWrapper
封装 requests 库，提供统一的 HTTP 请求接口
"""

import json
import time
from typing import Any, Callable, Dict, Optional
from urllib.parse import urlencode

import requests
from requests import Response, Session
from requests.cookies import RequestsCookieJar


class HttpRequestOptions:
    """HTTP 请求配置选项"""
    
    def __init__(self):
        self.headers: Dict[str, str] = {}
        self.query_parameters: Dict[str, str] = {}
        self.timeout: Optional[float] = 30.0
    
    def add_header(self, key: str, value: str) -> 'HttpRequestOptions':
        self.headers[key] = value
        return self
    
    def add_headers(self, headers: Dict[str, str]) -> 'HttpRequestOptions':
        self.headers.update(headers)
        return self
    
    def add_query(self, key: str, value: str) -> 'HttpRequestOptions':
        self.query_parameters[key] = value
        return self
    
    def clone(self) -> 'HttpRequestOptions':
        opts = HttpRequestOptions()
        opts.headers = dict(self.headers)
        opts.query_parameters = dict(self.query_parameters)
        opts.timeout = self.timeout
        return opts


class HttpClient:
    """
    HTTP 客户端 - 对应 C# HttpWrapper
    
    支持:
    - GET/POST 请求
    - 自动 Cookie 管理
    - 查询参数构建
    - JSON 序列化/反序列化
    """
    
    def __init__(
        self,
        base_url: str = "",
        configure_defaults: Optional[Callable[[HttpRequestOptions], None]] = None,
        cookies: Optional[RequestsCookieJar] = None
    ):
        """
        初始化 HTTP 客户端
        
        Args:
            base_url: 基础 URL
            configure_defaults: 默认配置回调
            cookies: 初始 Cookie 容器
        """
        self._base_url = base_url.rstrip('/') if base_url else ""
        self._session = requests.Session()
        
        # 自动解压
        self._session.headers.update({
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept': '*/*',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Connection': 'keep-alive',
        })
        
        if cookies:
            self._session.cookies = cookies
        
        # 应用默认配置
        self._default_options = HttpRequestOptions()
        if configure_defaults:
            configure_defaults(self._default_options)
        
        # 应用默认 headers
        for key, value in self._default_options.headers.items():
            self._session.headers[key] = value
    
    @property
    def session(self) -> Session:
        """获取 Session 对象"""
        return self._session
    
    def _build_url(self, url: str, query_params: Dict[str, str]) -> str:
        """构建完整 URL"""
        if not self._base_url:
            full_url = url
        else:
            full_url = f"{self._base_url}/{url.lstrip('/')}"
        
        if query_params:
            query_str = urlencode(query_params)
            separator = '&' if '?' in full_url else '?'
            full_url = f"{full_url}{separator}{query_str}"
        
        return full_url
    
    def get_string(
        self,
        url: str,
        configure: Optional[Callable[[HttpRequestOptions], None]] = None,
        timeout: Optional[float] = None
    ) -> str:
        """
        GET 请求并返回文本
        
        Args:
            url: 请求 URL
            configure: 请求配置回调
            timeout: 超时时间
            
        Returns:
            响应文本
        """
        response = self.get(url, configure, timeout)
        response.raise_for_status()
        return response.text
    
    def get_json(
        self,
        url: str,
        configure: Optional[Callable[[HttpRequestOptions], None]] = None,
        timeout: Optional[float] = None
    ) -> Any:
        """
        GET 请求并返回 JSON
        
        Args:
            url: 请求 URL
            configure: 请求配置回调
            timeout: 超时时间
            
        Returns:
            解析后的 JSON 对象
        """
        text = self.get_string(url, configure, timeout)
        return json.loads(text)
    
    def get(
        self,
        url: str,
        configure: Optional[Callable[[HttpRequestOptions], None]] = None,
        timeout: Optional[float] = None
    ) -> Response:
        """
        GET 请求
        
        Args:
            url: 请求 URL
            configure: 请求配置回调
            timeout: 超时时间
            
        Returns:
            Response 对象
        """
        opts = self._default_options.clone()
        if configure:
            configure(opts)
        
        full_url = self._build_url(url, opts.query_parameters)
        
        response = self._session.get(
            full_url,
            headers=opts.headers,
            timeout=timeout or opts.timeout
        )
        return response
    
    def post_json(
        self,
        url: str,
        data: Any,
        configure: Optional[Callable[[HttpRequestOptions], None]] = None,
        timeout: Optional[float] = None
    ) -> Response:
        """
        POST JSON 请求
        
        Args:
            url: 请求 URL
            data: JSON 数据
            configure: 请求配置回调
            timeout: 超时时间
            
        Returns:
            Response 对象
        """
        opts = self._default_options.clone()
        if configure:
            configure(opts)
        
        full_url = self._build_url(url, opts.query_parameters)
        
        response = self._session.post(
            full_url,
            data=json.dumps(data),
            headers={**opts.headers, 'Content-Type': 'application/json'},
            timeout=timeout or opts.timeout
        )
        return response
    
    def post_json_with_response(
        self,
        url: str,
        data: Any,
        configure: Optional[Callable[[HttpRequestOptions], None]] = None,
        timeout: Optional[float] = None
    ) -> Any:
        """
        POST JSON 请求并返回解析后的 JSON
        
        Args:
            url: 请求 URL
            data: JSON 数据
            configure: 请求配置回调
            timeout: 超时时间
            
        Returns:
            解析后的 JSON 对象
        """
        response = self.post_json(url, data, configure, timeout)
        response.raise_for_status()
        return json.loads(response.text)
    
    def post_form(
        self,
        url: str,
        form_data: Dict[str, str],
        configure: Optional[Callable[[HttpRequestOptions], None]] = None,
        timeout: Optional[float] = None
    ) -> Response:
        """
        POST 表单请求
        
        Args:
            url: 请求 URL
            form_data: 表单数据
            configure: 请求配置回调
            timeout: 超时时间
            
        Returns:
            Response 对象
        """
        opts = self._default_options.clone()
        if configure:
            configure(opts)
        
        full_url = self._build_url(url, opts.query_parameters)
        
        response = self._session.post(
            full_url,
            data=form_data,
            headers=opts.headers,
            timeout=timeout or opts.timeout
        )
        return response
    
    def post(
        self,
        url: str,
        content: str,
        content_type: str = "application/json",
        configure: Optional[Callable[[HttpRequestOptions], None]] = None,
        timeout: Optional[float] = None
    ) -> Response:
        """
        POST 请求
        
        Args:
            url: 请求 URL
            content: 请求体内容
            content_type: Content-Type
            configure: 请求配置回调
            timeout: 超时时间
            
        Returns:
            Response 对象
        """
        opts = self._default_options.clone()
        if configure:
            configure(opts)
        
        full_url = self._build_url(url, opts.query_parameters)
        
        headers = {**opts.headers, 'Content-Type': content_type}
        
        response = self._session.post(
            full_url,
            data=content,
            headers=headers,
            timeout=timeout or opts.timeout
        )
        return response
    
    def post_bytes(
        self,
        url: str,
        content: bytes,
        content_type: str = "application/octet-stream",
        configure: Optional[Callable[[HttpRequestOptions], None]] = None,
        timeout: Optional[float] = None
    ) -> Response:
        """
        POST 字节数据请求
        
        Args:
            url: 请求 URL
            content: 字节内容
            content_type: Content-Type
            configure: 请求配置回调
            timeout: 超时时间
            
        Returns:
            Response 对象
        """
        opts = self._default_options.clone()
        if configure:
            configure(opts)
        
        full_url = self._build_url(url, opts.query_parameters)
        
        headers = {**opts.headers, 'Content-Type': content_type}
        
        response = self._session.post(
            full_url,
            data=content,
            headers=headers,
            timeout=timeout or opts.timeout
        )
        return response
    
    def close(self) -> None:
        """关闭会话"""
        self._session.close()
    
    def __enter__(self) -> 'HttpClient':
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()


def _user_agent() -> str:
    """获取 User-Agent"""
    return "WPFLauncher/0.0.0.0"
