"""
MGB SDK 主入口 - 对应 C# Codexus.OpenSDK.MgbSdk
整合 4399 登录和 X19 认证
"""

from typing import Optional

from .c4399 import C4399Login
from .entities import C4399LoginResult, LaunchParameters, X19AuthenticationDetail
from .x19 import X19Auth


class MgbSdk:
    """
    MGB SDK 主类
    
    对应 C# Codexus.OpenSDK.MgbSdk
    提供统一的登录和启动接口
    """

    def __init__(self, x19_version: str = "1.1.0"):
        """
        初始化 MGB SDK
        
        Args:
            x19_version: X19 版本号
        """
        self._c4399 = C4399Login()
        self._x19 = X19Auth(version=x19_version)
        self._auth_detail: Optional[X19AuthenticationDetail] = None
        self._login_result: Optional[C4399LoginResult] = None
    
    def login(self, username: str, password: str, captcha: Optional[str] = None) -> C4399LoginResult:
        """
        登录账号
        
        Args:
            username: 4399 用户名
            password: 密码
            captcha: 验证码 (可选)
            
        Returns:
            登录结果。如果 requires_captcha=True，需要调用 get_captcha_image() 获取验证码图片，
            然后再次调用 login() 并传入 captcha 参数
        """
        # 1. 4399 登录
        result = self._c4399.login_with_password(username, password, captcha)
        
        # 如果需要验证码，自动获取验证码图片
        if result.requires_captcha:
            result.captcha_image = self._c4399.get_captcha_image()
            return result
        
        if not result.success:
            return result
        
        self._login_result = result
        
        # 2. X19 认证
        try:
            auth_detail = self._x19.continue_auth(result.s_auth)
            self._auth_detail = auth_detail
            result.message = "登录成功 (含 X19 认证)"
        except Exception as e:
            result.message = f"4399 登录成功，但 X19 认证失败: {str(e)}"
            result.success = False
        
        return result
    
    def login_with_captcha(self, username: str, password: str) -> C4399LoginResult:
        """
        完整的验证码登录流程（交互式）
        
        自动处理验证码流程：
        1. 尝试登录
        2. 如果需要验证码，自动获取并保存图片到文件
        3. 返回结果供用户输入验证码后再次调用
        
        Args:
            username: 4399 用户名
            password: 密码
            
        Returns:
            登录结果。如果 requires_captcha=True，验证码图片已保存到 captcha.png
        """
        # 第一次尝试登录
        result = self.login(username, password)
        
        if result.requires_captcha and result.captcha_image:
            # 保存验证码图片到文件
            with open("captcha.png", "wb") as f:
                f.write(result.captcha_image)
            print("验证码已保存到 captcha.png，请查看并输入验证码")
        
        return result
    
    def get_game_token(self) -> Optional[str]:
        """
        获取游戏令牌
        
        Returns:
            Access Token，未登录返回 None
        """
        if self._auth_detail:
            return self._auth_detail.access_token
        return None
    
    def is_logged_in(self) -> bool:
        """
        检查是否已登录
        
        Returns:
            是否已登录
        """
        return self._auth_detail is not None and bool(self._auth_detail.access_token)
    
    def build_launch_parameters(
        self,
        server_address: str,
        server_port: int,
        player_name: str,
        version: str = "1.20.1",
        game_dir: str = ""
    ) -> LaunchParameters:
        """
        构建游戏启动参数
        
        Args:
            server_address: 服务器地址
            server_port: 服务器端口
            player_name: 玩家名称
            version: 游戏版本
            game_dir: 游戏目录
            
        Returns:
            启动参数
        """
        params = LaunchParameters()
        params.server_address = server_address
        params.server_port = server_port
        params.player_name = player_name
        params.version = version
        params.game_dir = game_dir
        
        if self._auth_detail:
            params.access_token = self._auth_detail.access_token
        
        return params
    
    def get_captcha_image(self) -> Optional[bytes]:
        """
        获取验证码图片
        
        Returns:
            图片字节数据
        """
        return self._c4399.get_captcha_image()
    
    def close(self):
        """释放资源"""
        self._c4399.close()
        self._x19.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
