"""
Codexus Python SDK 使用示例
"""

from CodexusPython import MgbSdk


def main():
    """主函数"""
    # 创建 SDK 实例
    sdk = MgbSdk(x19_version="1.1.0")
    
    try:
        # 登录
        print("正在登录...")
        result = sdk.login("your_username", "your_password")
        
        if result.success:
            print(f"✅ 登录成功!")
            print(f"   用户名: {result.username}")
            print(f"   Token: {result.token}")
            
            # 获取游戏令牌
            game_token = sdk.get_game_token()
            print(f"   游戏令牌: {game_token}")
            
            # 构建启动参数
            params = sdk.build_launch_parameters(
                server_address="mc.example.com",
                server_port=25565,
                player_name="PlayerName",
                version="1.20.1"
            )
            print(f"\n🎮 启动参数:")
            print(f"   服务器: {params.server_address}:{params.server_port}")
            print(f"   玩家名: {params.player_name}")
            print(f"   版本: {params.version}")
            print(f"   令牌: {params.access_token}")
            
        else:
            print(f"❌ 登录失败: {result.message}")
            
            # 如果需要验证码
            if "验证码" in result.message:
                print("\n需要验证码，正在获取...")
                captcha_image = sdk.get_captcha_image()
                if captcha_image:
                    # 保存验证码图片
                    with open("captcha.png", "wb") as f:
                        f.write(captcha_image)
                    print("验证码已保存到 captcha.png")
                    
                    # 手动输入验证码
                    captcha = input("请输入验证码: ")
                    result = sdk.login("your_username", "your_password", captcha)
                    
                    if result.success:
                        print(f"✅ 登录成功!")
                    else:
                        print(f"❌ 登录失败: {result.message}")
    
    finally:
        # 释放资源
        sdk.close()


if __name__ == "__main__":
    main()
