"""
加密解密模块 - 对应 C# Codexus.OpenSDK.Cipher
包含: HttpCipher, DynamicToken, Skip32Cipher
"""

import os
import hashlib
import struct
from typing import Dict, Optional

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend


# ============================================================================
# HttpCipher - X19 API HTTP 加密/解密
# ============================================================================

# AES 密钥池 (16个16字节密钥)
_HTTP_KEYS = [
    b"MK6mipwmOUedplb6",
    b"OtEylfId6dyhrfdn",
    b"VNbhn5mvUaQaeOo9",
    b"bIEoQGQYjKd02U0J",
    b"fuaJrPwaH2cfXXLP",
    b"LEkdyiroouKQ4XN1",
    b"jM1h27H4UROu427W",
    b"DhReQada7gZybTDk",
    b"ZGXfpSTYUvcdKqdY",
    b"AZwKf7MWZrJpGR5W",
    b"amuvbcHw38TcSyPU",
    b"SI4QotspbjhyFdT0",
    b"VP4dhjKnDGlSJtbB",
    b"UXDZx4KhZywQ2tcn",
    b"NIK73ZNvNqzva4kd",
    b"WeiW7qU766Q1YQZI",
]

_IV = b"szkgpbyimxavqjcn"


def http_encrypt(body: bytes) -> bytes:
    """
    HTTP 加密 - 对应 C# HttpCipher.HttpEncrypt()
    
    Args:
        body: 待加密的原始数据
        
    Returns:
        加密后的数据 (格式: IV + 密文 + keyIndex)
    """
    # PKCS7 填充到 16 字节倍数
    padding_len = 16 - (len(body) % 16)
    if padding_len == 0:
        padding_len = 16
    padded_body = body + bytes([padding_len] * padding_len)
    
    # 随机选择密钥索引 (0-15)
    key_index = os.urandom(1)[0] & 0xF
    
    # AES-128-CBC 加密
    key = _HTTP_KEYS[key_index]
    cipher = Cipher(algorithms.AES(key), modes.CBC(_IV), backend=default_backend())
    encryptor = cipher.encryptor()
    encrypted = encryptor.update(padded_body) + encryptor.finalize()
    
    # 组装结果: IV(16) + 密文 + keyIndex(1)
    result = _IV + encrypted + bytes([key_index])
    return result


def http_decrypt(body: bytes) -> Optional[bytes]:
    """
    HTTP 解密 - 对应 C# HttpCipher.HttpDecrypt()
    
    Args:
        body: 加密数据 (格式: IV + 密文 + keyIndex)
        
    Returns:
        解密后的原始数据，失败返回 None
    """
    if len(body) < 0x12:
        return None
    
    # 提取 IV、密文、keyIndex
    iv = body[:16]
    encrypted_data = body[16:-1]
    key_index = body[-1] & 0xF
    
    try:
        # AES-128-CBC 解密
        key = _HTTP_KEYS[key_index]
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        decrypted = decryptor.update(encrypted_data) + decryptor.finalize()
        
        # 去除 PKCS7 填充
        padding_len = decrypted[-1]
        if 1 <= padding_len <= 16:
            decrypted = decrypted[:-padding_len]
        
        return decrypted
    except Exception:
        return None


# ============================================================================
# DynamicToken - X19 API 动态令牌计算
# ============================================================================

_TOKEN_SALT = "0eGsBkhl"
_TOKEN_KEY = b"debbde3548928fab"
_TOKEN_IV = b"afd4c5c5a7c456a1"


def _md5_hex(data: bytes) -> str:
    """计算 MD5 哈希 (hex 小写)"""
    return hashlib.md5(data).hexdigest().lower()


def _hex_to_binary(hex_string: str) -> str:
    """十六进制转二进制字符串"""
    binary = ""
    for c in hex_string:
        binary += bin(int(c, 16))[2:].zfill(4)
    return binary


def _process_binary_block(secret_bin: str, http_token: bytearray) -> None:
    """处理二进制块 - 对应 C# ProcessBinaryBlock()"""
    block_count = len(secret_bin) // 8
    for i in range(block_count):
        block = secret_bin[i * 8:(i + 1) * 8]
        xor_buffer = 0
        for j, bit in enumerate(reversed(block)):
            if bit == '1':
                xor_buffer |= (1 << j)
        http_token[i] ^= xor_buffer


def compute_dynamic_token(request_path: str, send_body: str, user_id: str, user_token: str) -> Dict[str, str]:
    """
    计算 X19 API 动态令牌 - 对应 C# DynamicToken.Compute()
    
    Args:
        request_path: 请求路径 (如 "/authentication-otp")
        send_body: 请求体 JSON
        user_id: 用户 ID
        user_token: 用户令牌
        
    Returns:
        包含 "user-id" 和 "user-token" 的字典
    """
    # 确保路径以 "/" 开头
    if not request_path.startswith('/'):
        request_path = '/' + request_path
    
    # Token 的 MD5
    user_token_md5 = _md5_hex(user_token.encode('utf-8'))
    
    # 拼接数据流
    stream_data = (
        user_token_md5.encode('utf-8') +  # Token MD5
        send_body.encode('utf-8') +         # 请求体
        _TOKEN_SALT.encode('utf-8') +       # Salt
        request_path.encode('utf-8')        # 请求路径
    )
    
    # 计算 MD5
    secret_md5 = _md5_hex(stream_data)
    
    # 转换为二进制并位移
    secret_bin = _hex_to_binary(secret_md5)
    secret_bin = secret_bin[6:] + secret_bin[:6]
    
    # 处理 HTTP Token
    http_token = bytearray(secret_md5.encode('utf-8'))
    _process_binary_block(secret_bin, http_token)
    
    # 生成 Base64 并替换特殊字符
    dynamic_token = ""
    base64_part = ""
    for i, b in enumerate(http_token[:12]):
        base64_part += chr(b)
    base64_token = _base64_encode_str(base64_part) + "1"
    dynamic_token = base64_token.replace('+', 'm').replace('/', 'o')
    
    return {
        "user-id": user_id,
        "user-token": dynamic_token
    }


def _base64_encode_str(s: str) -> str:
    """Base64 编码字符串"""
    import base64
    return base64.b64encode(s.encode('latin1')).decode('ascii')


# ============================================================================
# Skip32Cipher - 32位 SKIP32 加密
# ============================================================================

_F_TABLE = [
    0xa3, 0xd7, 0x09, 0x83, 0xf8, 0x48, 0xf6, 0xf4, 0xb3, 0x21,
    0x15, 0x78, 0x99, 0xb1, 0xaf, 0xf9, 0xe7, 0x2d, 0x4d, 0x8a,
    0xce, 0x4c, 0xca, 0x2e, 0x52, 0x95, 0xd9, 0x1e, 0x4e, 0x38,
    0x44, 0x28, 0x0a, 0xdf, 0x02, 0xa0, 0x17, 0xf1, 0x60, 0x68,
    0x12, 0xb7, 0x7a, 0xc3, 0xe9, 0xfa, 0x3d, 0x53, 0x96, 0x84,
    0x6b, 0xba, 0xf2, 0x63, 0x9a, 0x19, 0x7c, 0xae, 0xe5, 0xf5,
    0xf7, 0x16, 0x6a, 0xa2, 0x39, 0xb6, 0x7b, 0x0f, 0xc1, 0x93,
    0x81, 0x1b, 0xee, 0xb4, 0x1a, 0xea, 0xd0, 0x91, 0x2f, 0xb8,
    0x55, 0xb9, 0xda, 0x85, 0x3f, 0x41, 0xbf, 0xe0, 0x5a, 0x58,
    0x80, 0x5f, 0x66, 0x0b, 0xd8, 0x90, 0x35, 0xd5, 0xc0, 0xa7,
    0x33, 0x06, 0x65, 0x69, 0x45, 0x00, 0x94, 0x56, 0x6d, 0x98,
    0x9b, 0x76, 0x97, 0xfc, 0xb2, 0xc2, 0xb0, 0xfe, 0xdb, 0x20,
    0xe1, 0xeb, 0xd6, 0xe4, 0xdd, 0x47, 0x4a, 0x1d, 0x42, 0xed,
    0x9e, 0x6e, 0x49, 0x3c, 0xcd, 0x43, 0x27, 0xd2, 0x07, 0xd4,
    0xde, 0xc7, 0x67, 0x18, 0x89, 0xcb, 0x30, 0x1f, 0x8d, 0xc6,
    0x8f, 0xaa, 0xc8, 0x74, 0xdc, 0xc9, 0x5d, 0x5c, 0x31, 0xa4,
    0x70, 0x88, 0x61, 0x2c, 0x9f, 0x0d, 0x2b, 0x87, 0x50, 0x82,
    0x54, 0x64, 0x26, 0x7d, 0x03, 0x40, 0x34, 0x4b, 0x1c, 0x73,
    0xd1, 0xc4, 0xfd, 0x3b, 0xcc, 0xfb, 0x7f, 0xab, 0xe6, 0x3e,
    0x5b, 0xa5, 0xad, 0x04, 0x23, 0x9c, 0x14, 0x51, 0x22, 0xf0,
    0x29, 0x79, 0x71, 0x7e, 0xff, 0x8c, 0x0e, 0xe2, 0x0c, 0xef,
    0xbc, 0x72, 0x75, 0x6f, 0x37, 0xa1, 0xec, 0xd3, 0x8e, 0x62,
    0x8b, 0x86, 0x10, 0xe8, 0x08, 0x77, 0x11, 0xbe, 0x92, 0x4f,
    0x24, 0xc5, 0x32, 0x36, 0x9d, 0xcf, 0xf3, 0xa6, 0xbb, 0xac,
    0x5e, 0x6c, 0xa9, 0x13, 0x57, 0x25, 0xb5, 0xe3, 0xbd, 0xa8,
    0x3a, 0x01, 0x05, 0x59, 0x2a, 0x46
]


def _g(key: bytes, k: int, w: int) -> int:
    """G 函数 - SKIP32 内部计算"""
    g1 = w >> 8
    g2 = w & 0xff
    g3 = _F_TABLE[g2 ^ (key[4 * k % 10] & 0xFF)] ^ g1
    g4 = _F_TABLE[g3 ^ (key[(4 * k + 1) % 10] & 0xFF)] ^ g2
    g5 = _F_TABLE[g4 ^ (key[(4 * k + 2) % 10] & 0xFF)] ^ g3
    g6 = _F_TABLE[g5 ^ (key[(4 * k + 3) % 10] & 0xFF)] ^ g4
    return (g5 << 8) + g6


def _skip32(key: bytes, buf: list, encrypt: bool) -> None:
    """SKIP32 加解密核心"""
    step = 1 if encrypt else -1
    k = 0 if encrypt else 23
    
    wl = (buf[0] << 8) + buf[1]
    wr = (buf[2] << 8) + buf[3]
    
    for _ in range(24 // 2):
        wr ^= _g(key, k, wl) ^ k
        k += step
        wl ^= _g(key, k, wr) ^ k
        k += step
    
    buf[0] = wr >> 8
    buf[1] = wr & 0xFF
    buf[2] = wl >> 8
    buf[3] = wl & 0xFF


def skip32_encrypt(value: int, key: bytes) -> int:
    """
    SKIP32 加密 - 对应 C# Skip32Cipher.Encrypt()
    
    Args:
        value: 待加密的 32 位整数
        key: 10 字节密钥
        
    Returns:
        加密后的 32 位整数
    """
    buf = [
        (value >> 24) & 0xff,
        (value >> 16) & 0xff,
        (value >> 8) & 0xff,
        value & 0xff
    ]
    _skip32(key, buf, True)
    return (buf[0] << 24) | (buf[1] << 16) | (buf[2] << 8) | buf[3]


def skip32_decrypt(value: int, key: bytes) -> int:
    """
    SKIP32 解密 - 对应 C# Skip32Cipher.Decrypt()
    
    Args:
        value: 加密的 32 位整数
        key: 10 字节密钥
        
    Returns:
        解密后的 32 位整数
    """
    buf = [
        (value >> 24) & 0xff,
        (value >> 16) & 0xff,
        (value >> 8) & 0xff,
        value & 0xff
    ]
    _skip32(key, buf, False)
    return (buf[0] << 24) | (buf[1] << 16) | (buf[2] << 8) | buf[3]
