"""
X19 认证模块 - 对应 C# Codexus.OpenSDK.X19
网易 Minecraft 认证流程
"""

import json
import time
from typing import Dict, Optional

from .cipher import compute_dynamic_token, http_decrypt, http_encrypt
from .entities import X19AuthenticationDetail, X19Entity, X19LoginOtp, X19Response
from .http_client import HttpClient


class X19Auth:
    """
    X19 认证实现
    
    对应 C# Codexus.OpenSDK.X19 类
    处理网易 Minecraft 的登录认证流程
    """

    # X19 API 基础 URL
    BASE_URL = "https://x19.xmcsrv.net"
    
    # API 端点
    LOGIN_OTP_ENDPOINT = "/login-otp"
    AUTHENTICATION_OTP_ENDPOINT = "/authentication-otp"
    INTERCONNECTION_ENDPOINT = "/interconnection"
    
    def __init__(self, version: str = "1.1.0"):
        """
        初始化 X19 认证
        
        Args:
            version: X19 版本号
        """
        self._version = version
        self._http = HttpClient(
            base_url=self.BASE_URL,
            configure_defaults=lambda opts: opts
                .add_header("User-Agent", f"X19Client/{version}")
                .add_header("Accept", "application/json")
                .add_header("X-Client-Version", version)
        )
        self._user_id: Optional[str] = None
        self._user_token: Optional[str] = None
    
    def continue_auth(self, s_auth: str) -> X19AuthenticationDetail:
        """
        继续 X19 认证流程
        
        对应 C# X19.ContinueAsync()
        
        Args:
            s_auth: 4399 登录成功后获取的 sAuth
            
        Returns:
            认证详情
        """
        # 1. 登录 OTP
        login_otp = self._login_otp(s_auth)
        if not login_otp:
            raise Exception("Login OTP failed")
        
        # 2. 认证 OTP
        auth_detail = self._authentication_otp(login_otp)
        if not auth_detail:
            raise Exception("Authentication OTP failed")
        
        # 3. 保存用户信息
        self._user_id = auth_detail.get("user_id", "")
        self._user_token = auth_detail.get("access_token", "")
        
        # 4. 构建返回对象
        detail = X19AuthenticationDetail()
        detail.access_token = auth_detail.get("access_token", "")
        detail.refresh_token = auth_detail.get("refresh_token", "")
        detail.expires_in = auth_detail.get("expires_in", 0)
        detail.scope = auth_detail.get("scope", "")
        detail.token_type = auth_detail.get("token_type", "")
        
        return detail
    
    def _login_otp(self, s_auth: str) -> Optional[Dict]:
        """
        登录 OTP
        
        对应 C# X19.LoginOtpAsync()
        """
        try:
            # 构建请求体
            request_body = {
                "sAuth": s_auth,
                "version": self._version,
                "timestamp": int(time.time())
            }
            
            # 加密请求体
            encrypted_body = http_encrypt(json.dumps(request_body).encode('utf-8'))
            
            # 发送请求
            response = self._http.post_bytes(
                self.LOGIN_OTP_ENDPOINT,
                encrypted_body,
                content_type="application/octet-stream",
                configure=lambda opts: opts
                    .add_header("X-Encrypted", "true")
            )
            
            if response.status_code != 200:
                return None
            
            # 解密响应
            decrypted = http_decrypt(response.content)
            if not decrypted:
                return None
            
            result = json.loads(decrypted.decode('utf-8'))
            
            if result.get("status") != 0:
                return None
            
            return result.get("data", {})
            
        except Exception as e:
            print(f"Login OTP error: {e}")
            return None
    
    def _authentication_otp(self, login_otp_data: Dict) -> Optional[Dict]:
        """
        认证 OTP
        
        对应 C# X19.AuthenticationOtpAsync()
        """
        try:
            # 构建请求体
            request_body = {
                "otp": login_otp_data.get("otp", ""),
                "device_id": login_otp_data.get("device_id", ""),
                "timestamp": int(time.time())
            }
            
            # 计算动态令牌
            token_headers = compute_dynamic_token(
                self.AUTHENTICATION_OTP_ENDPOINT,
                json.dumps(request_body),
                self._user_id or "",
                self._user_token or ""
            )
            
            # 加密请求体
            encrypted_body = http_encrypt(json.dumps(request_body).encode('utf-8'))
            
            # 发送请求
            response = self._http.post_bytes(
                self.AUTHENTICATION_OTP_ENDPOINT,
                encrypted_body,
                content_type="application/octet-stream",
                configure=lambda opts: opts
                    .add_header("X-Encrypted", "true")
                    .add_header("X-User-Id", token_headers.get("user-id", ""))
                    .add_header("X-User-Token", token_headers.get("user-token", ""))
            )
            
            if response.status_code != 200:
                return None
            
            # 解密响应
            decrypted = http_decrypt(response.content)
            if not decrypted:
                return None
            
            result = json.loads(decrypted.decode('utf-8'))
            
            if result.get("status") != 0:
                return None
            
            return result.get("data", {})
            
        except Exception as e:
            print(f"Authentication OTP error: {e}")
            return None
    
    def get_patch_versions(self) -> Dict[str, str]:
        """
        获取补丁版本列表
        
        对应 C# X19.GetPatchVersionsAsync()
        
        Returns:
            版本字典 {版本号: URL}
        """
        try:
            response = self._http.get_json("/patch-versions")
            if isinstance(response, dict) and response.get("status") == 0:
                return response.get("data", {})
        except Exception:
            pass
        return {}
    
    def close(self):
        """关闭 HTTP 客户端"""
        self._http.close()
