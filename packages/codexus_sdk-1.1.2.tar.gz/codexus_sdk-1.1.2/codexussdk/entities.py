"""
数据模型 - 对应 C# Codexus.OpenSDK.Entities
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ============================================================================
# X19 响应模型
# ============================================================================

@dataclass
class X19Response:
    """X19 API 基础响应"""
    status: int = 0
    message: str = ""


@dataclass
class X19Entity(X19Response):
    """X19 API 实体响应"""
    details: str = ""
    data: Any = None


@dataclass
class X19AuthenticationDetail:
    """X19 认证详情"""
    access_token: str = ""
    refresh_token: str = ""
    expires_in: int = 0
    scope: str = ""
    token_type: str = ""


@dataclass
class X19LoginOtp:
    """X19 登录 OTP 响应"""
    phone: str = ""
    otp_type: int = 0
    device_id: str = ""


# ============================================================================
# MPay 用户模型
# ============================================================================

@dataclass
class MPayExtInfo:
    """MPay 扩展信息"""
    ext_access_token: str = ""
    realname_verify_status: int = 0
    login_channel: str = ""
    realname_status: int = 0
    related_login_status: int = 0
    need_mask: bool = False
    mobile_bind_status: int = 0
    mask_related_mobile: str = ""
    display_username: str = ""
    token: str = ""
    client_username: str = ""
    avatar: str = ""
    need_aas: bool = False
    login_type: int = 0
    nickname: str = ""
    id: str = ""


@dataclass
class MPayUser:
    """MPay 用户信息"""
    ext_access_token: str = ""
    realname_verify_status: int = 0
    login_channel: str = ""
    realname_status: int = 0
    related_login_status: int = 0
    need_mask: bool = False
    mobile_bind_status: int = 0
    mask_related_mobile: str = ""
    display_username: str = ""
    token: str = ""
    client_username: str = ""
    avatar: str = ""
    need_aas: bool = False
    login_type: int = 0
    nickname: str = ""
    id: str = ""
    ext_info: MPayExtInfo = field(default_factory=MPayExtInfo)


@dataclass
class MPayDevice:
    """MPay 设备信息"""
    id: str = ""
    key: str = ""


@dataclass
class MPayUserWrapper:
    """MPay 用户包装器"""
    user: Optional[MPayUser] = None
    device: Optional[MPayDevice] = None


# ============================================================================
# 4399 登录模型
# ============================================================================

@dataclass
class C4399LoginResult:
    """4399 登录结果"""
    success: bool = False
    username: str = ""
    token: str = ""
    s_auth: str = ""
    message: str = ""
    user_id: str = ""
    display_name: str = ""
    requires_captcha: bool = False
    captcha_image: Optional[bytes] = None


# ============================================================================
# 启动参数模型
# ============================================================================

@dataclass
class LaunchParameters:
    """游戏启动参数"""
    server_address: str = ""
    server_port: int = 0
    player_name: str = ""
    access_token: str = ""
    version: str = ""
    game_dir: str = ""


# ============================================================================
# 注册结果模型
# ============================================================================

@dataclass
class RegisterResult:
    """注册结果"""
    success: bool = False
    username: str = ""
    password: str = ""
    message: str = ""
