"""High-level Sybilion API client: Bearer auth, forecast polling, pagination iterators."""

from __future__ import annotations

import time
from collections.abc import Iterator
from typing import Any

from sybilion._api import ApiClient, Configuration, DefaultApi
from sybilion._api.models.api_v1_forecasts_id_get200_response import (
    ApiV1ForecastsIdGet200Response,
)
from sybilion._api.models.api_v1_jobs_get200_response import ApiV1JobsGet200Response
from sybilion._api.models.api_v1_usage_get200_response import ApiV1UsageGet200Response
from sybilion.env import resolve_api_base_url


class Client:
    """Thin wrapper around the generated :class:`DefaultApi` with convenience methods.

    Parameters
    ----------
    token:
        Bearer token (an API key ``sk_ops_...`` or a dashboard session token).
    base_url:
        API origin override. When ``None``, falls through to ``SYBILION_API_BASE_URL``
        and then the SDK's compiled default (currently ``https://api.sybilion.dev``).
    """

    def __init__(self, *, token: str, base_url: str | None = None) -> None:
        host = resolve_api_base_url(base_url)
        self._cfg = Configuration(host=host, access_token=token)
        self._api = DefaultApi(ApiClient(self._cfg))

    @property
    def raw(self) -> DefaultApi:
        """Underlying OpenAPI-generated API for endpoints not wrapped by helpers."""
        return self._api

    def wait_forecast(
        self,
        job_id: str,
        *,
        poll_s: float = 2.0,
        timeout_s: float = 3600.0,
    ) -> ApiV1ForecastsIdGet200Response:
        """Poll ``GET /api/v1/forecasts/{id}`` until ``settled`` is true or timeout.

        Returns as soon as the job reports ``settled == True`` (works for completed,
        failed, and canceled). Raises :class:`TimeoutError` on deadline exceeded —
        the job continues running on the server and you may resume polling later.
        """
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            job = self._api.api_v1_forecasts_id_get(id=job_id)
            if job.settled is True:
                return job
            time.sleep(poll_s)
        raise TimeoutError(f"forecast {job_id} did not settle within {timeout_s}s")

    def iter_usage_pages(
        self,
        *,
        sort: str = "id",
        order: str = "desc",
        limit: int = 50,
    ) -> Iterator[ApiV1UsageGet200Response]:
        """Yield each page of ``GET /api/v1/usage`` (1-indexed page walk)."""
        page = 1
        while True:
            resp = self._api.api_v1_usage_get(page=page, limit=limit, sort=sort, order=order)
            yield resp
            pg = resp.pagination
            if page >= int(pg.total_pages):
                break
            page += 1

    def iter_jobs_pages(
        self,
        *,
        sort: str = "created_at",
        order: str = "desc",
        limit: int = 50,
        status: str | None = None,
        pipeline_type: str | None = None,
    ) -> Iterator[ApiV1JobsGet200Response]:
        """Yield each page of ``GET /api/v1/jobs`` (1-indexed page walk)."""
        page = 1
        while True:
            kwargs: dict[str, Any] = {"page": page, "limit": limit, "sort": sort, "order": order}
            if status is not None:
                kwargs["status"] = status
            if pipeline_type is not None:
                kwargs["pipeline_type"] = pipeline_type
            resp = self._api.api_v1_jobs_get(**kwargs)
            yield resp
            pg = resp.pagination
            if page >= int(pg.total_pages):
                break
            page += 1
