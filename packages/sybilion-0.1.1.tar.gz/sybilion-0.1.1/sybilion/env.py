"""Runtime base URL: explicit argument -> SYBILION_API_BASE_URL -> compiled default."""

from __future__ import annotations

import os

from sybilion.defaults_gen import DEFAULT_PUBLIC_API_BASE_URL

SYBILION_API_BASE_URL_ENV = "SYBILION_API_BASE_URL"
OPERATIONAL_API_BASE_URL_ENV = "OPERATIONAL_API_BASE_URL"


def resolve_api_base_url(explicit: str | None) -> str:
    """Strip trailing slashes. Empty explicit falls through to env then defaults_gen.

    The previous environment variable name (``OPERATIONAL_API_BASE_URL``) is still
    accepted as a silent fallback for one transition release.
    """
    if explicit is not None and str(explicit).strip():
        return str(explicit).rstrip("/")
    env_val = os.environ.get(SYBILION_API_BASE_URL_ENV, "").strip()
    if env_val:
        return env_val.rstrip("/")
    legacy = os.environ.get(OPERATIONAL_API_BASE_URL_ENV, "").strip()
    if legacy:
        return legacy.rstrip("/")
    return DEFAULT_PUBLIC_API_BASE_URL.rstrip("/")
