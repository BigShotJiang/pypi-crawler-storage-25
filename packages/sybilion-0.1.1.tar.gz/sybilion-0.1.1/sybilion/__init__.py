"""Sybilion API client.

The official Python SDK for the Sybilion API. Install with ``pip install sybilion``.

Quick use:

    from sybilion import Client

    c = Client(token="sk_ops_...")
    me = c.raw.api_v1_me_get()

The low-level OpenAPI-generated client lives at ``sybilion._api`` and is exposed
through ``Client.raw`` for endpoints not yet wrapped by the ergonomic helpers.
"""

from sybilion._api.exceptions import (
    ApiException,
    ApiTypeError,
    ApiValueError,
    BadRequestException,
    ConflictException,
    ForbiddenException,
    NotFoundException,
    OpenApiException,
    ServiceException,
    UnauthorizedException,
    UnprocessableEntityException,
)
from sybilion.client import Client
from sybilion.defaults_gen import DEFAULT_PUBLIC_API_BASE_URL
from sybilion.env import (
    OPERATIONAL_API_BASE_URL_ENV,
    SYBILION_API_BASE_URL_ENV,
    resolve_api_base_url,
)

__all__ = [
    "Client",
    "DEFAULT_PUBLIC_API_BASE_URL",
    "SYBILION_API_BASE_URL_ENV",
    "OPERATIONAL_API_BASE_URL_ENV",
    "resolve_api_base_url",
    # Exception types re-exported from the generated client for convenience.
    "ApiException",
    "ApiTypeError",
    "ApiValueError",
    "BadRequestException",
    "ConflictException",
    "ForbiddenException",
    "NotFoundException",
    "OpenApiException",
    "ServiceException",
    "UnauthorizedException",
    "UnprocessableEntityException",
]
