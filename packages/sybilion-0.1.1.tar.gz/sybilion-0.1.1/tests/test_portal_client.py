"""Tests for sybilion.Client (no real API — local httptest)."""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from sybilion import (
    DEFAULT_PUBLIC_API_BASE_URL,
    OPERATIONAL_API_BASE_URL_ENV,
    SYBILION_API_BASE_URL_ENV,
    Client,
    resolve_api_base_url,
)


class _Handler(BaseHTTPRequestHandler):
    calls = 0

    def log_message(self, _format: str, *_args: object) -> None:  # noqa: D102
        return

    def do_GET(self) -> None:  # noqa: N802
        if self.path.startswith("/api/v1/forecasts/"):
            _Handler.calls += 1
            settled = _Handler.calls >= 2
            body = {
                "job_id": "00000000-0000-0000-0000-000000000002",
                "status": "completed",
                "pipeline_type": "forecast",
                "created_at": "2026-01-01T00:00:00Z",
                "settled": settled,
                "settled_at": "2026-01-01T00:00:01Z" if settled else None,
                "eur_cents_final": 1 if settled else None,
            }
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(body).encode())
            return
        self.send_error(404)


@pytest.fixture()
def http_base() -> str:
    _Handler.calls = 0
    srv = HTTPServer(("127.0.0.1", 0), _Handler)
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    host, port = srv.server_address
    base = f"http://{host}:{port}"
    yield base
    srv.shutdown()


def test_resolve_api_base_url_explicit_over_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(SYBILION_API_BASE_URL_ENV, "https://env.example/")
    assert resolve_api_base_url("https://explicit.example/") == "https://explicit.example"


def test_resolve_api_base_url_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(SYBILION_API_BASE_URL_ENV, "https://custom.example/")
    assert resolve_api_base_url(None) == "https://custom.example"


def test_resolve_api_base_url_legacy_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(SYBILION_API_BASE_URL_ENV, raising=False)
    monkeypatch.setenv(OPERATIONAL_API_BASE_URL_ENV, "https://legacy.example/")
    assert resolve_api_base_url(None) == "https://legacy.example"


def test_resolve_api_base_url_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(SYBILION_API_BASE_URL_ENV, raising=False)
    monkeypatch.delenv(OPERATIONAL_API_BASE_URL_ENV, raising=False)
    assert resolve_api_base_url(None) == DEFAULT_PUBLIC_API_BASE_URL.rstrip("/")


def test_wait_forecast(http_base: str) -> None:
    c = Client(token="t", base_url=http_base)
    job = c.wait_forecast("00000000-0000-0000-0000-000000000002", poll_s=0.05, timeout_s=5)
    assert job.settled is True
    assert _Handler.calls >= 2
