# Sybilion Python SDK

Official Python SDK for the [Sybilion API](https://sybilion.dev/docs/).

```bash
pip install sybilion
```

Requires Python 3.10+.

## Quick use

```python
import os

from sybilion import Client

c = Client(token=os.environ["SYBILION_API_TOKEN"])
me = c.raw.api_v1_me_get()
print(me.user_id, me.available_eur_cents, me.api_usage_tier)
```

The token is an API key (`sk_ops_...`) created in the Developers Portal, or a dashboard session token. The default base URL is `https://api.sybilion.dev`; override per-process with `SYBILION_API_BASE_URL` or per-call via the `base_url=` argument.

## What's in the box

- `sybilion.Client` — Bearer auth, ergonomic helpers.
- `client.wait_forecast(job_id)` — polls `GET /api/v1/forecasts/{id}` until settled.
- `client.iter_usage_pages(...)`, `client.iter_jobs_pages(...)` — paginated iterators.
- `client.raw` — escape hatch to the OpenAPI-generated `DefaultApi` for any endpoint not yet wrapped.
- Typed exceptions (`sybilion.ApiException` and per-status subclasses).

## Documentation

Full guides, feature walkthroughs, API reference, and SDK patterns: **<https://sybilion.dev/docs/>**.

## Support

- Email — [support@sybilion.com](mailto:support@sybilion.com)
- Slack — [Sybilion Community](https://join.slack.com/t/sybilioncommunity/shared_invite/zt-3y6vx56nk-WJu35eLxkyFQr~Yfko6RjQ)
- Discord — [Sybilion Developers Community](https://discord.gg/CEpEvUB7)

## License

[Apache 2.0](LICENSE).
