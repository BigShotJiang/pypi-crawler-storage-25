import argparse
import sys

import pikepdf


def pdfuck(filepath, output, password):
    if not output:
        splited = filepath.rsplit('.', 1)
        prefix = splited[0]
        output = prefix + '.fucked'
        if len(splited) >= 2:
            output += '.' + splited[1]

    try:
        with pikepdf.open(filename_or_stream=filepath, password=password) as pdf:
            pdf.save(filename_or_stream=output)
        print(f"Decryption succeeded, saved to '{output}'")
    except pikepdf.PasswordError:
        print("Error: incorrect password or the file requires a password (-p).")
        sys.exit(1)
    except FileNotFoundError:
        print(f"Error: file '{filepath}' not found.")
        sys.exit(1)
    except pikepdf.PdfError as e:
        print(f"Error: {e}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="PDFuck: Remove the password of your PDF file")
    parser.add_argument("filepath", metavar="<filepath>", type=str, help="path of the source PDF file")
    parser.add_argument("-o", "--output", metavar="<filepath>", type=str, help="path of the target PDF file")
    parser.add_argument("-p", "--password", metavar="<password>", type=str, help="reading password of the source PDF file")
    args = parser.parse_args()

    pdfuck(filepath=args.filepath, output=args.output, password=args.password or "")


if __name__ == "__main__":
    main()
