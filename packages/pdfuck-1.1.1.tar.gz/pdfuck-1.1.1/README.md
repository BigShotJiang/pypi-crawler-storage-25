![](assets/logo.svg)

**English** | [简体中文](README_zh.md) 

---

## Introduction

[PDFuck](https://github.com/mmdjiji/pdfuck) is a tool to remove PDF editing password, which is used in CLI (command line) mode.

## Installation

Before installing, please ensure that you have installed Python (>=3.8) and its matching version of pip, and then enter the following command at the command prompt:

```bash
pip install pdfuck
```

Or use [uv](https://docs.astral.sh/uv/) to run directly without installing:

```bash
uvx pdfuck
```

Note: If you use this method, subsequent usage will require adding `uvx` before the command. You can also set an alias for easier use:

```bash
alias pdfuck='uvx pdfuck'
```

## Usage

### Remove PDF password

For example, if you want to remove the password from the PDF file which is located in `example.pdf`, just enter the following command:

```bash
pdfuck example.pdf
```

The default path of the output file is `example.fucked.pdf`.

### Manually specify the output file path

If you want to specify the path of the output file manually, you can use the `-o` parameter, for example:

```bash
pdfuck example.pdf -o target.pdf
```

### PDF file requires opening password

Use the `-p` parameter to manually specify the opening password, for example:

```bash
pdfuck example.pdf -p password
```

## Credit

Thanks for the following open source projects. The completion of this project is inseparable from the code contributed by these authors.

* [pikepdf](https://github.com/pikepdf/pikepdf)

## Workflow

### Configure development environment

```bash
uv pip install -e .
```

### Build

```bash
uv build
```

## License

[GPL-3.0](LICENSE)
