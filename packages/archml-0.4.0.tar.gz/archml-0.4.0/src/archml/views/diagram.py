# Copyright 2026 ArchML Contributors
# SPDX-License-Identifier: Apache-2.0

"""SVG diagram backend for ArchML architecture views.

Renders a :class:`~archml.views.topology.VizDiagram` using the pre-computed
:class:`~archml.views.placement.LayoutPlan` geometry, producing a standalone
SVG file.

All coordinates are taken directly from the layout plan — no additional layout
engine is involved.  Each :class:`~archml.views.placement.NodeLayout` maps to
a styled ``<rect>``/``<text>`` pair, each
:class:`~archml.views.placement.BoundaryLayout` to a labelled rectangle, and
each :class:`~archml.views.placement.EdgeRoute` to a ``<polyline>`` with an
explicit filled-polygon arrowhead at the target end.

Text labels are clipped to their node bounding box via SVG ``<clipPath>``
elements, so long labels never overflow the node rectangle.

Visual styles are defined in ``archml-diagram.css`` and embedded in the SVG
``<style>`` element.  CSS classes follow the ``archml-`` prefix convention used
by the JS renderer so both renderers produce identical visual output.
"""

from __future__ import annotations

import importlib.resources
import math
import xml.etree.ElementTree as ET
from pathlib import Path

from archml.views.placement import BoundaryLayout, LayoutPlan, NodeLayout
from archml.views.topology import BoundaryKind, NodeKind, VizBoundary, VizDiagram, VizNode

# ###############
# Public Interface
# ###############


def render_diagram(
    diagram: VizDiagram,
    plan: LayoutPlan,
    output_path: Path,
    *,
    scale: float = 1.0,
) -> None:
    """Render *diagram* to an SVG file at *output_path*.

    Uses the geometry recorded in *plan* to position every element.  All
    layout-unit coordinates are multiplied by *scale* to obtain SVG user units
    (at 96 dpi, 1 layout unit ≈ 1 px by default).

    The output directory is created automatically if it does not exist.

    Args:
        diagram: The topology to render, as produced by
            :func:`~archml.views.topology.build_viz_diagram`.
        plan: The pre-computed layout plan produced by
            :func:`~archml.views.placement.compute_layout`.
        output_path: Destination path for the SVG file.
        scale: Multiplier applied to all layout-unit coordinates.
            Defaults to ``1.0``.
    """
    svg = _build_svg(diagram, plan, scale)
    _write_svg(svg, output_path)


# ################
# Implementation
# ################

_FONT_FAMILY = "system-ui, -apple-system, sans-serif"
_FONT_SIZE = 15
_CORNER_RADIUS = 7
_BOUNDARY_LABEL_OFFSET = 21.0  # y distance from boundary top to title baseline
_LABEL_PADDING = 6.0  # horizontal padding inside node for text clip region

# Channel / interface node layout — must match LayoutConfig defaults.
_CHANNEL_STROKE_DASH = "5,3"

# User node icon — Heroicons 2.x "user" outline (MIT licence, viewBox 0 0 24 24).
# _USER_ICON_SIZE and _USER_ICON_PAD must match LayoutConfig.user_icon_size / user_icon_pad defaults.
_USER_ICON_SIZE = 20.0  # side length of the rendered icon (layout units)
_USER_ICON_PAD = 8.0  # gap from node top and left edges to the icon (layout units)
# Heroicons 2.x "user" outline path — viewBox 0 0 24 24 (MIT licence).
_USER_ICON_PATH = (
    "M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z"
    "M4.501 20.118a7.5 7.5 0 0 1 14.998 0"
    "A17.933 17.933 0 0 1 12 21.75"
    "c-2.676 0-5.216-.584-7.499-1.632Z"
)

# Arrowhead geometry (layout units, before scaling).
_ARROW_LEN = 9.0
_ARROW_HALF_W = 4.0

# Presentation-attribute fallbacks — mirror archml-diagram.css exactly.
# SVG viewers that do not apply embedded <style> (e.g. rsvg, Inkscape, macOS
# Preview) rely on these; CSS-capable browsers use the CSS classes instead.
_NODE_FILL: dict[str, str] = {
    "archml-node--component": "#fff7ed",
    "archml-node--system": "#eff6ff",
    "archml-node--user": "#fffbeb",
    "archml-node--channel": "#fef2f2",
    "archml-node--external": "#f8fafc",
    "archml-node--unknown": "#fefce8",
}
_NODE_STROKE: dict[str, str] = {
    "archml-node--component": "#ea580c",
    "archml-node--system": "#2563eb",
    "archml-node--user": "#d97706",
    "archml-node--channel": "#dc2626",
    "archml-node--external": "#475569",
    "archml-node--unknown": "#ca8a04",
}
_BOUNDARY_FILL: dict[str, str] = {
    "archml-boundary--system": "#eff6ff",
    "archml-boundary--component": "#fff7ed",
}
_BOUNDARY_STROKE: dict[str, str] = {
    "archml-boundary--system": "#2563eb",
    "archml-boundary--component": "#ea580c",
}
_TEXT_COLOUR = "#1e293b"
_EDGE_COLOUR = "#1e293b"
_FILL_BACKGROUND = "#ffffff"


def _load_diagram_css() -> str:
    """Return diagram CSS content for embedding in SVG files."""
    try:
        ref = importlib.resources.files("archml") / "static" / "archml-diagram.css"
        return ref.read_text(encoding="utf-8")
    except (FileNotFoundError, TypeError, ModuleNotFoundError):
        return ""


def _node_class(kind: NodeKind | None) -> str:
    """Return the CSS class string for a node rectangle of the given *kind*."""
    if kind == "component":
        return "archml-node archml-node--component"
    if kind == "system":
        return "archml-node archml-node--system"
    if kind == "user":
        return "archml-node archml-node--user"
    if kind in ("channel", "interface", "terminal"):
        return "archml-node archml-node--channel"
    if kind in ("external_component", "external_system", "external_user"):
        return "archml-node archml-node--external"
    return "archml-node archml-node--unknown"


def _boundary_class(kind: BoundaryKind | None) -> str:
    """Return the CSS class string for a boundary rectangle of the given *kind*."""
    if kind == "component":
        return "archml-boundary archml-boundary--component"
    return "archml-boundary archml-boundary--system"


def _f(value: float, scale: float) -> str:
    """Format *value* scaled to two decimal places as a string."""
    return f"{value * scale:.2f}"


def _make_clip_id(node_id: str) -> str:
    """Return a safe XML ID for the ``<clipPath>`` of *node_id*."""
    safe = node_id.replace(".", "-").replace(":", "-").replace("/", "-").replace("@", "-")
    return f"clip-{safe}"


def _build_svg(diagram: VizDiagram, plan: LayoutPlan, scale: float) -> ET.Element:
    """Construct the complete SVG element tree from *diagram* and *plan*."""
    tw = plan.total_width * scale
    th = plan.total_height * scale

    svg = ET.Element(
        "svg",
        {
            "xmlns": "http://www.w3.org/2000/svg",
            "viewBox": f"0 0 {tw:.2f} {th:.2f}",
            "width": f"{tw:.2f}",
            "height": f"{th:.2f}",
        },
    )

    # Style element (embedded CSS).
    css = _load_diagram_css()
    if css:
        style = ET.SubElement(svg, "style")
        style.text = css

    # White background rectangle.
    ET.SubElement(
        svg,
        "rect",
        {
            "x": "0",
            "y": "0",
            "width": f"{tw:.2f}",
            "height": f"{th:.2f}",
            "fill": _FILL_BACKGROUND,
            "class": "archml-bg",
        },
    )

    defs = ET.SubElement(svg, "defs")

    # Root boundary — draw a box for real entities; skip only the synthetic
    # "all" diagram whose root is labelled "Architecture" and has id "all".
    if diagram.root.id != "all":
        root_bl = plan.boundaries.get(diagram.root.id)
        if root_bl is not None:
            _render_boundary(svg, diagram.root.label, root_bl, scale, kind=diagram.root.kind)

    # Nested boundaries (expanded sub-systems/components) — rendered outermost-first so
    # inner boundaries appear on top.  Collect them in BFS order.
    nested: list[VizBoundary] = []
    _collect_nested_boundaries(diagram.root, nested)
    for bnd in nested:
        if bnd.id in plan.boundaries:
            _render_boundary(svg, bnd.label, plan.boundaries[bnd.id], scale, kind=bnd.kind)

    # Build a metadata map: node_id → (label, title, kind) for all renderable nodes.
    node_meta: dict[str, tuple[str, str | None, NodeKind | None]] = {}
    _collect_node_meta(diagram.root, node_meta)
    for node in diagram.peripheral_nodes:
        node_meta[node.id] = (node.label, node.title, node.kind)

    # Render all positioned nodes (clip paths added to <defs>).
    for node_id, nl in plan.nodes.items():
        label, title, kind = node_meta.get(node_id, (node_id, None, None))
        clip_id = _make_clip_id(node_id)
        _add_node_clip(defs, clip_id, nl, scale)
        _render_node(svg, label, title, nl, kind, scale, clip_id)

    # Render edges with explicit arrowheads.
    for edge in diagram.edges:
        route = plan.edge_routes.get(edge.id)
        if route is not None:
            _render_edge(svg, route.waypoints, edge.label, scale)

    return svg


def _collect_nested_boundaries(boundary: VizBoundary, result: list[VizBoundary]) -> None:
    """Append all nested VizBoundary children to *result* in BFS order (outermost first)."""
    for child in boundary.children:
        if isinstance(child, VizBoundary):
            result.append(child)
            _collect_nested_boundaries(child, result)


def _collect_node_meta(
    boundary: VizBoundary,
    result: dict[str, tuple[str, str | None, NodeKind | None]],
) -> None:
    """Recursively collect node metadata from all leaf VizNodes in *boundary*."""
    for child in boundary.children:
        if isinstance(child, VizNode):
            result[child.id] = (child.label, child.title, child.kind)
        elif isinstance(child, VizBoundary):
            _collect_node_meta(child, result)


def _add_node_clip(defs: ET.Element, clip_id: str, nl: NodeLayout, scale: float) -> None:
    """Add a ``<clipPath>`` for *nl* to *defs*, using the node bounds with padding."""
    clip = ET.SubElement(defs, "clipPath", {"id": clip_id})
    ET.SubElement(
        clip,
        "rect",
        {
            "x": _f(nl.x + _LABEL_PADDING, scale),
            "y": _f(nl.y, scale),
            "width": _f(nl.width - 2 * _LABEL_PADDING, scale),
            "height": _f(nl.height, scale),
        },
    )


def _render_boundary(
    svg: ET.Element,
    label: str,
    bl: BoundaryLayout,
    scale: float,
    *,
    kind: BoundaryKind | None = None,
) -> None:
    """Draw a boundary rectangle with a title label.

    *kind* selects the CSS class palette: ``"component"`` uses orange tones,
    ``"system"`` uses blue tones.  ``None`` (the default) falls back to the
    system boundary style.
    """
    cls = _boundary_class(kind)
    variant = cls.split()[-1]  # e.g. "archml-boundary--system"
    r = str(_CORNER_RADIUS)
    ET.SubElement(
        svg,
        "rect",
        {
            "x": _f(bl.x, scale),
            "y": _f(bl.y, scale),
            "width": _f(bl.width, scale),
            "height": _f(bl.height, scale),
            "rx": r,
            "ry": r,
            "fill": _BOUNDARY_FILL.get(variant, "#eff6ff"),
            "stroke": _BOUNDARY_STROKE.get(variant, "#2563eb"),
            "stroke-width": "2",
            "class": cls,
        },
    )
    stroke = _BOUNDARY_STROKE.get(variant, "#2563eb")
    title = ET.SubElement(
        svg,
        "text",
        {
            "x": _f(bl.x + bl.width / 2, scale),
            "y": _f(bl.y + _BOUNDARY_LABEL_OFFSET, scale),
            "text-anchor": "middle",
            "dominant-baseline": "middle",
            "font-family": _FONT_FAMILY,
            "font-size": str(int(_FONT_SIZE * scale * 1.1)),
            "font-weight": "bold",
            "fill": stroke,
            "class": "archml-text archml-text--boundary",
        },
    )
    title.text = label


def _render_node(
    svg: ET.Element,
    label: str,
    title: str | None,
    nl: NodeLayout,
    kind: NodeKind | None,
    scale: float,
    clip_id: str,
) -> None:
    """Draw a node rectangle with a centred, clipped label.

    For channel nodes, renders the interface name bold and centred.
    For user / external_user nodes, renders a person pictogram above the label.
    """
    cls = _node_class(kind)
    variant = cls.split()[-1]  # e.g. "archml-node--channel"
    r = str(_CORNER_RADIUS)

    rect_attrs: dict[str, str] = {
        "x": _f(nl.x, scale),
        "y": _f(nl.y, scale),
        "width": _f(nl.width, scale),
        "height": _f(nl.height, scale),
        "rx": r,
        "ry": r,
        "fill": _NODE_FILL.get(variant, "#ffffff"),
        "stroke": _NODE_STROKE.get(variant, "#475569"),
        "stroke-width": "1.5",
        "class": cls,
    }
    if kind in ("channel", "interface", "terminal"):
        rect_attrs["stroke-dasharray"] = _CHANNEL_STROKE_DASH

    ET.SubElement(svg, "rect", rect_attrs)

    cx_f = nl.x + nl.width / 2  # horizontal centre in layout units
    cx = _f(cx_f, scale)
    cy_mid = nl.y + nl.height / 2

    if kind in ("channel", "terminal", "interface"):
        # Single-line: interface name bold and centred.
        # For channel nodes the interface name is in title (falls back to label).
        iface_name = (title or "") if kind == "channel" else label
        text = ET.SubElement(
            svg,
            "text",
            {
                "x": cx,
                "y": _f(cy_mid, scale),
                "text-anchor": "middle",
                "dominant-baseline": "middle",
                "font-family": _FONT_FAMILY,
                "font-size": str(int(_FONT_SIZE * scale)),
                "font-weight": "bold",
                "fill": _TEXT_COLOUR,
                "class": "archml-text",
                "clip-path": f"url(#{clip_id})",
            },
        )
        text.text = iface_name
    elif kind in ("user", "external_user"):
        # User icon: inline path scaled from 24×24 viewBox to _USER_ICON_SIZE layout units.
        stroke_color = _NODE_STROKE.get(variant, "#475569")
        icon_x = nl.x + _USER_ICON_PAD
        icon_y = nl.y + _USER_ICON_PAD
        icon_scale = _USER_ICON_SIZE / 24.0
        transform = f"translate({icon_x * scale:.2f},{icon_y * scale:.2f}) scale({icon_scale * scale:.4f})"
        g = ET.SubElement(
            svg,
            "g",
            {
                "transform": transform,
                "fill": "none",
                "stroke": stroke_color,
                "stroke-width": "1.5",
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
            },
        )
        ET.SubElement(g, "path", {"d": _USER_ICON_PATH})
        # Label centred in the full node box.
        text = ET.SubElement(
            svg,
            "text",
            {
                "x": cx,
                "y": _f(cy_mid, scale),
                "text-anchor": "middle",
                "dominant-baseline": "middle",
                "font-family": _FONT_FAMILY,
                "font-size": str(int(_FONT_SIZE * scale)),
                "fill": _TEXT_COLOUR,
                "class": "archml-text",
                "clip-path": f"url(#{clip_id})",
            },
        )
        text.text = label
    else:
        text_attrs: dict[str, str] = {
            "x": cx,
            "y": _f(cy_mid, scale),
            "text-anchor": "middle",
            "dominant-baseline": "middle",
            "font-family": _FONT_FAMILY,
            "font-size": str(int(_FONT_SIZE * scale)),
            "fill": _TEXT_COLOUR,
            "class": "archml-text",
            "clip-path": f"url(#{clip_id})",
        }
        if kind in ("component", "system", "interface", "terminal"):
            text_attrs["font-weight"] = "bold"
        text = ET.SubElement(svg, "text", text_attrs)
        text.text = label


def _render_edge(
    svg: ET.Element,
    waypoints: list[tuple[float, float]],
    label: str,
    scale: float,
) -> None:
    """Draw an edge as a polyline body plus an explicit arrowhead polygon at the target end."""
    if len(waypoints) < 2:
        return

    # Compute the arrowhead direction from the last segment of the edge.
    x1, y1 = waypoints[-2]
    x2, y2 = waypoints[-1]
    dx, dy = x2 - x1, y2 - y1
    length = math.hypot(dx, dy)
    if length < 1e-9:
        return

    ndx, ndy = dx / length, dy / length

    # The arrow tip is at the target port anchor; the base is set back by _ARROW_LEN.
    arrow_len = min(_ARROW_LEN, length * 0.45)
    base_x = x2 - arrow_len * ndx
    base_y = y2 - arrow_len * ndy

    # Edge body: polyline stopping at the arrowhead base so it doesn't overlap it.
    body_wps = list(waypoints[:-1]) + [(base_x, base_y)]
    points_str = " ".join(f"{x * scale:.2f},{y * scale:.2f}" for x, y in body_wps)
    ET.SubElement(
        svg,
        "polyline",
        {
            "points": points_str,
            "fill": "none",
            "stroke": _EDGE_COLOUR,
            "stroke-width": "1.5",
            "class": "archml-edge",
        },
    )

    # Arrowhead: filled triangle (tip, left wing, right wing).
    lx = base_x - _ARROW_HALF_W * ndy
    ly = base_y + _ARROW_HALF_W * ndx
    rx_pt = base_x + _ARROW_HALF_W * ndy
    ry_pt = base_y - _ARROW_HALF_W * ndx
    arrow_pts = " ".join(f"{x * scale:.2f},{y * scale:.2f}" for x, y in [(x2, y2), (lx, ly), (rx_pt, ry_pt)])
    ET.SubElement(svg, "polygon", {"points": arrow_pts, "fill": _EDGE_COLOUR, "class": "archml-arrowhead"})


def _write_svg(svg: ET.Element, output_path: Path) -> None:
    """Write *svg* to *output_path* as a UTF-8 SVG file with XML declaration."""
    ET.indent(svg, space="  ")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tree = ET.ElementTree(svg)
    with output_path.open("w", encoding="utf-8") as fh:
        fh.write('<?xml version="1.0" encoding="utf-8"?>\n')
        tree.write(fh, encoding="unicode", xml_declaration=False)
