class DataItem:
    def __init__(self, data):
        self.__dict__.update(data)

    def __repr__(self):
        attrs = ', '.join(f'{k}={v}' for k, v in self.__dict__.items())
        return f"<DataItem {attrs}>"

    def to_dict(self):
        return self.__dict__.copy()

    def keys(self):
        return self.__dict__.keys()

    def __getitem__(self, key):
        return self.__dict__[key]

class DataProxy:
    def __init__(self, data_list):
        self._objects = [DataItem(item) for item in data_list]

    def __iter__(self):
        return iter(self._objects)

    def __getitem__(self, index):
        return self._objects[index]

    def __len__(self):
        return len(self._objects)

    def __repr__(self):
        return f'DataProxy({self._objects})'