import os

def method_allowed(func):
    def wrapper(self, *args, **kwargs):
        if hasattr(self, 'allowed_methods') and self.allowed_methods is not None:
            if func.__name__ not in self.allowed_methods:
                raise AttributeError(f"Method '{func.__name__}' is not allowed.")
        return func(self, *args, **kwargs)

    return wrapper

class RepositoryManager:
    allowed_methods = ['get', 'values', 'filter', 'create', 'update', 'delete']

    def __init__(self):
        self.table = self.__class__.data_source(
            table_name=self.__class__.__name__
        )
        self.objects = self.Objects(
            parent=self,
            allowed_methods=getattr(self, 'allowed_methods', None)
        )

    class Objects:
        def __init__(self, parent, allowed_methods=None):
            self.parent = parent
            self.allowed_methods = allowed_methods

        @method_allowed
        def get(self, **kwargs):
            if not kwargs:
                return self.parent.table.data

            items = self.filter(**kwargs)
            if items:
                return items[0] if isinstance(items, list) else items
            raise AttributeError(f'No item found matching {kwargs}')

        @method_allowed
        def values(self, *args):
            fields = list(args) if args else None
            return self.parent.table.values(fields=fields)

        @method_allowed
        def filter(self, **kwargs):
            if not kwargs:
                return self.parent.table.data

            expression_list = []
            for field, value in kwargs.items():
                if field.endswith('__in'):
                    clean_field = field.replace('__in', '')
                    if isinstance(value, (list, tuple, set)):
                        in_exp = '~or'.join([f'({clean_field},eq,{v})' for v in value])
                        expression_list.append(f'({in_exp})')
                else:
                    expression_list.append(f'({field},eq,{value})')

            expression = '~and'.join(expression_list)
            return self.parent.table.filter(where=expression)

        @method_allowed
        def create(self, **kwargs):
            if not kwargs:
                raise Exception('Append is broken: undefined target')
            return self.parent.table.append(target=kwargs)

        @method_allowed
        def update(self, target=None, **kwargs):
            data = target if target is not None else kwargs
            if not data or ('Id' not in data and 'id' not in data):
                raise AttributeError("Update requires an ID (Primary Key) in target data.")

            return self.parent.table.update(target=data)

        @method_allowed
        def delete(self, Id:int):
            if not Id:
                raise AttributeError("Delete requires a valid record ID.")

            return self.parent.table.delete(target={'Id': Id})

        @method_allowed
        def upload(self, file, filename=None):
            if hasattr(file, 'read'):
                content = file.read()
                name = filename or getattr(file, 'name', 'upload_file')
            else:
                with open(file, 'rb') as f:
                    content = f.read()
                    name = filename or os.path.basename(file)

            return self.parent.table._upload(content, name)