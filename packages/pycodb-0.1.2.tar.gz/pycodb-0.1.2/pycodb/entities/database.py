from .dataproxy import DataProxy

class DataBase:
    DOMAIN = ''
    NOCODB_API_KEY = ''

    def __init__(self, table_name: str):
        table = getattr(self.__class__, table_name)
        self._objects = table(
            domain=DataBase.DOMAIN,
            headers={
                'xc-token': DataBase.NOCODB_API_KEY,
                'accept': 'application/json'
            },
            view_id=table.view_id,
            table_id=table.table_id
        )

    @property
    def data(self):
        return DataProxy(self._objects._get())

    def values(self, fields=None):
        return DataProxy(self._objects._get(fields=fields))

    def filter(self, **kwargs):
        return DataProxy(self._objects._get(**kwargs))

    def append(self, target: dict):
        return self._objects._append(target)

    def update(self, target: dict):
        return self._objects._update(target)

    def delete(self, target: dict):
        return self._objects._delete(target)