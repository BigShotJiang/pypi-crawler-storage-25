"""
Example: DFT-D3 dispersion correction for a water dimer.

Demonstrates how to enable the D3 dispersion correction, which is
important for systems with non-covalent interactions.
"""
from ase import Atoms
from riper import RIPERCalculator

# Build a water dimer (two water molecules with hydrogen bond)
water_dimer = Atoms(
    symbols="OHHOHH",
    positions=[
        [0.000, 0.000, 0.117],
        [0.000, 0.757, -0.469],
        [0.000, -0.757, -0.469],
        [2.900, 0.000, 0.117],
        [2.900, 0.757, -0.469],
        [2.900, -0.757, -0.469],
    ],
)

print("=== Water Dimer - D3 Dispersion Correction ===")
print(f"PBC: {water_dimer.pbc}")
print(f"Number of atoms: {len(water_dimer)}")
print()

# Calculate WITHOUT dispersion correction
calc_no_disp = RIPERCalculator(
    functional="pbe",
    basis="def2-SVP",
    auxbasis="universal",
    charge=0,
    disp3=False,
    riper_command="riper_smp",
    directory="calculations/calc_dimer_no_disp",
)

water_dimer.calc = calc_no_disp
energy_no_disp = water_dimer.get_potential_energy()
print(f"Energy without D3: {energy_no_disp:.6f} eV")
print()

# Calculate WITH D3 dispersion correction
calc_disp = RIPERCalculator(
    functional="pbe",
    basis="def2-SVP",
    auxbasis="universal",
    charge=0,
    disp3=True,
    riper_command="riper_smp",
    directory="calculations/calc_dimer_disp",
)

water_dimer.calc = calc_disp
energy_disp = water_dimer.get_potential_energy()
print(f"Energy with D3:    {energy_disp:.6f} eV")
print()

# Dispersion contribution
disp_contribution = energy_disp - energy_no_disp
print(f"Dispersion contribution: {disp_contribution:.6f} eV")
print()

# Forces with D3
forces = water_dimer.get_forces()
print("Forces with D3 (eV/Å):")
for sym, f in zip(water_dimer.get_chemical_symbols(), forces):
    print(f"  {sym}:  {f[0]:12.6f}  {f[1]:12.6f}  {f[2]:12.6f}")