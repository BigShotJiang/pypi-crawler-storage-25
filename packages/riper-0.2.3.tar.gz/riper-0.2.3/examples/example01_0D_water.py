"""
Example: Single-point energy and forces for a water molecule (0D).

This is the simplest possible test — no periodicity, no k-points.
"""
from ase import Atoms
from riper import RIPERCalculator

# Build a water molecule manually
water = Atoms(
    symbols="OHH",
    positions=[
        [0.000, 0.000, 0.119],
        [0.000, 0.763, -0.477],
        [0.000, -0.763, -0.477],
    ],
)

# No pbc set → defaults to [False, False, False] → 0D (molecular)
print("=== Water Molecule (0D) ===")
print(f"PBC: {water.pbc}")
print(f"Number of atoms: {len(water)}")
print()

# Set up calculator
# For 0D, basis defaults to "def2-SVP" if not specified
calc = RIPERCalculator(
    functional="pbe",
    basis="def2-SVP",
    auxbasis="universal",
    charge=0,
    # riper_command="riper_smp",  
    # riper_command="riper_omp",   
    # riper_command="riper",  
    # riper_command="/opt/TURBOMOLE/bin/emt64_smp/riper_smp",  
    riper_command="/Applications/TmoleX2025/TURBOMOLE/bin/i686-apple-darwin/riper",      
    directory="calculations/calc_water",      # calculation files go here
)

water.calc = calc

# Get energy
energy = water.get_potential_energy()
print(f"Energy: {energy:.6f} eV")
print()

# Get forces
forces = water.get_forces()
print("Forces (eV/Å):")
for sym, f in zip(water.get_chemical_symbols(), forces):
    print(f"  {sym}:  {f[0]:12.6f}  {f[1]:12.6f}  {f[2]:12.6f}")
print()

# Verify forces sum to ~zero (translational invariance)
print(f"Sum of forces: {forces.sum(axis=0)}")


print(f"Maximum: {forces.max()}")