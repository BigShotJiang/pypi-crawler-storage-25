"""
Example: Adjusting SCF energy and density convergence criteria for a water molecule.

Demonstrates how to tighten the SCF energy convergence (scfconv) and
enable density convergence checking (denconv).
"""
from ase import Atoms
from riper import RIPERCalculator
from ase.build import molecule

# Create water molecule using the ase.build
water = molecule('H2O')

# Build a water molecule manually
# water = Atoms(
#     symbols="OHH",
#     positions=[
#         [0.000, 0.000, 0.119],
#         [0.000, 0.763, -0.477],
#         [0.000, -0.763, -0.477],
#     ],
# )

print("=== Water Molecule - Tight Convergence Criteria ===")
print(f"PBC: {water.pbc}")
print(f"Number of atoms: {len(water)}")
print()

# Set up calculator with tightened convergence
# scfconv=9 means energy convergence threshold of 1e-9 Hartree (default is 7 - 1e-7)
# denconv="1.0d-7" enables density convergence checking (default is off)
# scfiterlimit=100 allows more SCF iterations to reach tight convergence
calc = RIPERCalculator(
    functional="pbe",
    basis="def2-SVP",
    auxbasis="universal",
    charge=0,
    scfconv=9,
    denconv="1.0d-7",
    scfiterlimit=100,
    riper_command="riper_smp",
    directory="calculations/calc_water_tight_conv",
)

water.calc = calc

# Get energy
energy = water.get_potential_energy()
print(f"Energy: {energy:.10f} eV")
print()

# Get forces
forces = water.get_forces()
print("Forces (eV/Å):")
for sym, f in zip(water.get_chemical_symbols(), forces):
    print(f"  {sym}:  {f[0]:12.8f}  {f[1]:12.8f}  {f[2]:12.8f}")
print()

print(f"Sum of forces: {forces.sum(axis=0)}")
print(f"Maximum force component: {forces.max():.10f}")