"""
Example: Stress tensor calculation for bulk silicon (3D periodic).

Demonstrates how to request the stress tensor for a periodic system.
The stress is returned in Voigt notation [xx, yy, zz, yz, xz, xy]
in units of eV/Å³.
"""
from ase.build import bulk
from riper import RIPERCalculator

# Build bulk silicon (diamond structure)
si = bulk("Si", "diamond", a=5.43)

print("=== Bulk Silicon — Stress Tensor ===")
print(f"PBC: {si.pbc}")
print(f"Number of atoms: {len(si)}")
print(f"Cell (Å):")
for i, vec in enumerate(si.cell):
    print(f"  a{i+1}: [{vec[0]:8.4f}, {vec[1]:8.4f}, {vec[2]:8.4f}]")
print(f"Volume: {si.get_volume():.4f} ų")
print()

# Set up calculator (`calculate_stress=True` triggers $optcell in the control file)
calc = RIPERCalculator(
    functional="pbe",
    basis="pob-DZVP-rev2",
    auxbasis="universal",
    calculate_stress=True,
    nkpoints=[4, 4, 4],
    riper_command="riper_smp",
    directory="calculations/calc_si_stress",
)

si.calc = calc

# Get energy
energy = si.get_potential_energy()
print(f"Energy: {energy:.6f} eV")
print()

# Get forces
forces = si.get_forces()
print("Forces (eV/Å):")
for i, (sym, f) in enumerate(zip(si.get_chemical_symbols(), forces)):
    print(f"  {sym}{i+1}:  {f[0]:12.6f}  {f[1]:12.6f}  {f[2]:12.6f}")
print()

# Get stress tensor 
stress = si.get_stress()
print("Stress tensor (Voigt notation, eV/ų):")
labels = ["xx", "yy", "zz", "yz", "xz", "xy"]
for label, s in zip(labels, stress):
    print(f"  σ_{label}: {s:12.6f}")
print()

# Convert to GPa for more intuitive units (1 eV/ų = 160.2176634 GPa)
EV_PER_A3_TO_GPA = 160.2176634
stress_gpa = stress * EV_PER_A3_TO_GPA
print("Stress tensor (GPa):")
for label, s in zip(labels, stress_gpa):
    print(f"  σ_{label}: {s:12.4f}")
print()

# Hydrostatic pressure (negative trace / 3)
pressure = -sum(stress_gpa[:3]) / 3.0
print(f"Hydrostatic pressure: {pressure:.4f} GPa")