"""
Example: 1D periodic LiH chain.

A simple 1D periodic system: alternating Li and H atoms along the x-axis.
Periodicity is along the x-direction only.

    Li --- H --- Li --- H --- ...
    |<--- a --->|

The lattice parameter 'a' is the repeat distance along x.
"""
from ase import Atoms
import numpy as np
from riper import RIPERCalculator

# Lattice parameter for the 1D chain (in Angstrom)
a = 3.2  # Li-H repeat distance

# Create a 1D periodic LiH chain
# Li at x=0, H at x=a/2, periodic along x only
lih_chain = Atoms(
    symbols="LiH",
    positions=[
        [0.0, 0.0, 0.0],      # Li
        [a / 2, 0.0, 0.0],    # H
    ],
    cell=[
        [a, 0.0, 0.0],        # periodic direction (x)
        [0.0, 20.0, 0.0],     # vacuum (not used by riper for 1D)
        [0.0, 0.0, 20.0],     # vacuum (not used by riper for 1D)
    ],
    pbc=[True, False, False],  # 1D periodic along x
)

print("=== 1D LiH Chain ===")
print(f"PBC: {lih_chain.pbc}")
print(f"Lattice parameter a = {a} Å")
print(f"Number of atoms per unit cell: {len(lih_chain)}")
print(f"Li-H distance: {a / 2} Å")
print()

# Set up calculator
# For periodic systems, basis defaults to "pob-DZVP-rev2" if not specified
calc = RIPERCalculator(
    functional="pbe",
    basis="pob-DZVP-rev2",
    auxbasis="universal",
    nkpoints=[8, 1, 1],  # Only first value (8) is used for 1D
    charge=0,
    riper_command="riper_smp",
    directory="calculations/calc_lih_chain",
)

lih_chain.calc = calc

# Get energy
energy = lih_chain.get_potential_energy()
print(f"Energy: {energy:.6f} eV")
print(f"Energy per LiH unit: {energy / 1:.6f} eV")
print()

# Get forces
forces = lih_chain.get_forces()
print("Forces (eV/Å):")
for sym, f in zip(lih_chain.get_chemical_symbols(), forces):
    print(f"  {sym}:  {f[0]:12.6f}  {f[1]:12.6f}  {f[2]:12.6f}")
print()

# -----------------------------------------------------------------
# Optional: scan the lattice parameter to find equilibrium
# -----------------------------------------------------------------
print("=== Lattice parameter scan ===")
a_values = np.linspace(2.8, 3.8, 6)
energies = []

for a_test in a_values:
    chain = Atoms(
        symbols="LiH",
        positions=[
            [0.0, 0.0, 0.0],
            [a_test / 2, 0.0, 0.0],
        ],
        cell=[
            [a_test, 0.0, 0.0],
            [0.0, 20.0, 0.0],
            [0.0, 0.0, 20.0],
        ],
        pbc=[True, False, False],
    )

    calc_scan = RIPERCalculator(
        functional="pbe",
        basis="pob-DZVP-rev2",
        auxbasis="universal",
        nkpoints=[8, 1, 1],
        riper_command="riper_smp",
        directory=f"calculations/calc_lih_scan_{a_test:.2f}",
    )

    chain.calc = calc_scan
    e = chain.get_potential_energy()
    energies.append(e)
    print(f"  a = {a_test:.2f} Å  →  E = {e:.6f} eV")

# Find minimum
imin = np.argmin(energies)
print(f"\nLowest energy at a ≈ {a_values[imin]:.2f} Å  ({energies[imin]:.6f} eV)")