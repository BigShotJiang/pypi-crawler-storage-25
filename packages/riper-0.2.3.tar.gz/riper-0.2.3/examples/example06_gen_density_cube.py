"""
Example: Plot total electronic density and save as a cube file.

Demonstrates how to use the pointval option to generate a cube file (td.cub)
containing the total electronic density, which can be visualized with tools
like VESTA, VMD, or py3Dmol.
"""
import os
from ase import Atoms
from riper import RIPERCalculator

# Create water molecule using the ase.build
# water = molecule('H2O')
# or
# Build a water molecule manually
water = Atoms(
    symbols="OHH",
    positions=[
        [0.000, 0.000, 0.119],
        [0.000, 0.763, -0.477],
        [0.000, -0.763, -0.477],
    ],
)

print("=== Water Molecule — Electronic Density Cube File ===")
print(f"PBC: {water.pbc}")
print(f"Number of atoms: {len(water)}")
print()

# Set up calculator with pointval enabled to generate density cube file
# The cube file will be saved as "td.cub" in the working directory
calc = RIPERCalculator(
    functional="pbe",
    basis="def2-SVP",
    auxbasis="universal",
    charge=0,
    plot_dens=True,
    riper_command="riper_smp",
    directory="calculations/calc_water_density",
)

water.calc = calc

# Run calculation — this will also generate the cube file
energy = water.get_potential_energy()
print(f"Energy: {energy:.6f} eV")
print()

# Check that the cube file was generated
cube_file = os.path.join("calculations/calc_water_density", "td.cub")
if os.path.exists(cube_file):
    file_size = os.path.getsize(cube_file) / 1024  # size in KB
    print(f"Density cube file generated: {cube_file}")
    print(f"File size: {file_size:.1f} KB")
    print()

    # Print first few lines of the cube file as a preview
    print("Cube file header:")
    with open(cube_file, "r") as f:
        for i, line in enumerate(f):
            if i < 10:
                print(f"  {line.rstrip()}")
            else:
                print("  ...")
                break
    print()
    print("The cube file can be visualized with:")
    print("  - VESTA (https://jp-minerals.org/vesta/)")
    print("  - CrysX-3D Viewer   (https://www.bragitoff.com/crysx-3d-viewer/)")
else:
    print(f"WARNING: Cube file '{cube_file}' was not generated.")
    print("Check the RIPER output for errors.")