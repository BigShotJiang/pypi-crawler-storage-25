"""
Example: Geometry optimization of a water molecule (0D)
read from an XYZ file.

Uses ASE + RIPER from TURBOMOLE.
"""

from ase.io import read
from ase.optimize import LBFGS
from riper import RIPERCalculator

# Read structure from XYZ file
water = read("water.xyz")

print("=== Water Molecule Geometry Optimization (0D) ===")
print(f"PBC: {water.pbc}")
print(f"Number of atoms: {len(water)}")
print()

# Set up calculator
calc = RIPERCalculator(
    functional="pbe",
    basis="def2-SVP",
    auxbasis="universal",
    charge=0,
    riper_command="riper_smp",
    directory="calculations/opt_water",
)

water.calc = calc

# Initial energy
energy_initial = water.get_potential_energy()
print(f"Initial energy: {energy_initial:.6f} eV")
print()

# Geometry optimization
print("Starting geometry optimization...\n")

opt = LBFGS(
    water,
    trajectory="water_opt.traj",
    logfile="opt.log"
)

opt.run(fmax=0.02)

print("\nOptimization finished.\n")

# Final energy
energy_final = water.get_potential_energy()
print(f"Final energy: {energy_final:.6f} eV")
print()

# Optimized coordinates
print("Optimized geometry (Å):")
for sym, pos in zip(water.get_chemical_symbols(), water.positions):
    print(f"{sym:2s}  {pos[0]:10.6f}  {pos[1]:10.6f}  {pos[2]:10.6f}")

print()

# Final forces
forces = water.get_forces()
print("Final forces (eV/Å):")
for sym, f in zip(water.get_chemical_symbols(), forces):
    print(f"{sym:2s}  {f[0]:12.6f}  {f[1]:12.6f}  {f[2]:12.6f}")

print()
print(f"Maximum force component: {abs(forces).max():.6f} eV/Å")