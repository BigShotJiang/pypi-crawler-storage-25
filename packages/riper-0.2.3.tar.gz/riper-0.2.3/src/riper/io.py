"""
Input/Output functions for RIPER calculations.

Handles:
    - Writing TURBOMOLE coord files
    - Writing TURBOMOLE control files
    - Reading energy from RIPER output
    - Reading forces from TURBOMOLE gradient file
    - Reading stress from RIPER gradlatt output
"""

import numpy as np
import os

from riper.utils import (
    ANGSTROM_TO_BOHR,
    BOHR_TO_ANGSTROM,
    HARTREE_TO_EV,
    HARTREE_PER_BOHR_TO_EV_PER_ANGSTROM,
    cell_to_lattice_vectors,
)


def write_coord(atoms, filepath="coord"):
    """
    Write atomic coordinates in TURBOMOLE coord format (Bohr units).

    Parameters
    ----------
    atoms : ase.Atoms
        The atoms object.
    filepath : str
        Path to the output coord file.
    """
    positions_bohr = atoms.positions * ANGSTROM_TO_BOHR
    symbols = atoms.get_chemical_symbols()

    with open(filepath, "w") as f:
        f.write("$coord\n")
        for pos, sym in zip(positions_bohr, symbols):
            f.write(
                f"  {pos[0]:20.14f}  {pos[1]:20.14f}  {pos[2]:20.14f}  "
                f"{sym.lower()}\n"
            )
        f.write("$end\n")


def write_control(atoms, params, directory="."):
    """
    Write the TURBOMOLE control file for a RIPER calculation.

    Parameters
    ----------
    atoms : ase.Atoms
        The atoms object.
    params : dict
        Calculator parameters (basis, auxbasis, functional, nkpoints, etc.).
    directory : str
        Directory where control file will be written.
    """
    npdir = params.get("periodicity", 0)
    basis = params["basis"]
    auxbasis = params["auxbasis"]
    functional = params["functional"]
    nkpoints = params.get("nkpoints", [2, 2, 2])
    charge = params.get("charge", 0)
    uks = params.get("uks", False)
    smear = params.get("smear", False)
    sigma = params.get("sigma", 0.01)
    calculate_stress = params.get("calculate_stress", False)
    extra_keywords = params.get("extra_keywords", {})
    scfiterlimit = params.get("scfiterlimit", 50)
    scfconv = params.get("scfconv", 7)
    denconv = params.get("denconv", None)
    disp3 = params.get("disp3", False)
    plot_dens = params.get("plot_dens", False)

    control_path = os.path.join(directory, "control")

    lines = []

    # Coordinate file reference
    lines.append("$coord file=coord")

    # Atoms section: basis and auxiliary basis
    lines.append("$atoms")
    lines.append(f"  basis ={basis}")
    lines.append(f"  jbas  ={auxbasis}")

    # Periodicity and lattice
    if npdir > 0:
        lines.append(f"$periodic {npdir}")

        lattice_vecs = cell_to_lattice_vectors(atoms, npdir)
        lines.append("$lattice")
        for vec in lattice_vecs:
            line = "  " + "  ".join(f"{v:20.14f}" for v in vec)
            lines.append(line)

    # DFT functional
    lines.append("$dft")
    lines.append(f"  functional {functional}")

    # k-point sampling (only for periodic systems)
    if npdir > 0:
        lines.append("$kpoints")
        kpts = nkpoints[:npdir]  # Only use as many k-points as periodic directions
        kpt_str = " ".join(str(k) for k in kpts)
        lines.append(f"  nkpoints {kpt_str}")

    # Charge specification
    if charge != 0:
        lines.append("$atomdens")
        lines.append(f"  charge {charge}")

    # UKS (unrestricted Kohn-Sham)
    if uks:
        lines.append("$uhf")

    # SCF iteration limit
    lines.append(f"$scfiterlimit {scfiterlimit}")

    # SCF energy convergence criterion
    lines.append(f"$scfconv {scfconv}")

    # Density convergence criterion (only if specified)
    if denconv is not None:
        lines.append(f"$denconv {denconv}")

    # D3 dispersion correction
    if disp3:
        lines.append("$disp3")

    # RIPER-specific settings
    riper_lines = []
    if smear:
        riper_lines.append(f"  sigma {sigma}")
    # if calculate_stress and npdir > 0:
    #     riper_lines.append("  lstress on")

    # Add any extra riper keywords
    for key, val in extra_keywords.items():
        riper_lines.append(f"  {key} {val}")

    if riper_lines:
        lines.append("$riper")
        lines.extend(riper_lines)

    # Cell optimization keyword triggers stress calculation
    if calculate_stress and npdir > 0:
        lines.append("$optcell")

    # Electron density cube file output
    if plot_dens:
        lines.append("$pointvalper fmt=cub")
        lines.append("   dens")

    lines.append("$end")

    with open(control_path, "w") as f:
        f.write("\n".join(lines) + "\n")


def read_energy(output_file):
    """
    Read the total energy from the RIPER output file.

    Looks for the 'FINAL ENERGIES' section and extracts the 'TOTAL ENERGY'.

    Parameters
    ----------
    output_file : str
        Path to the RIPER output file.

    Returns
    -------
    float
        Total energy in eV.

    Raises
    ------
    RuntimeError
        If the output file is not found or energy cannot be parsed.
    """
    energy = None
    in_final_energies = False

    try:
        with open(output_file, "r") as f:
            for line in f:
                if "FINAL ENERGIES" in line:
                    in_final_energies = True
                if in_final_energies and "TOTAL ENERGY" in line:
                    parts = line.split()
                    # Find the numeric value after "TOTAL ENERGY"
                    for i, part in enumerate(parts):
                        if part == "ENERGY":
                            # Energy value is typically at index i+1 or later
                            for j in range(i + 1, len(parts)):
                                try:
                                    energy = float(parts[j])
                                    break
                                except ValueError:
                                    continue
                            break
                    if energy is not None:
                        break
    except FileNotFoundError:
        raise RuntimeError(f"Output file '{output_file}' not found.")

    if energy is None:
        raise RuntimeError(
            f"Total energy not found in the 'FINAL ENERGIES' section of '{output_file}'."
        )

    return energy * HARTREE_TO_EV


def read_forces(gradient_file, natoms):
    """
    Read atomic forces from the TURBOMOLE gradient file.

    The gradient file contains gradients (negative forces) in Hartree/Bohr.

    Parameters
    ----------
    gradient_file : str
        Path to the gradient file.
    natoms : int
        Number of atoms.

    Returns
    -------
    numpy.ndarray
        Forces array of shape (natoms, 3) in eV/Angstrom.

    Raises
    ------
    RuntimeError
        If the gradient file cannot be read or parsed.
    """
    try:
        with open(gradient_file, "r") as f:
            lines = f.readlines()
    except FileNotFoundError:
        raise RuntimeError(f"Gradient file '{gradient_file}' not found.")

    # Find $grad block
    grad_start = None
    for i, line in enumerate(lines):
        if "$grad" in line:
            grad_start = i
            break

    if grad_start is None:
        raise RuntimeError("Gradient block ($grad) not found in the gradient file.")

    # Find $end
    grad_end = None
    for i in range(len(lines) - 1, grad_start, -1):
        if "$end" in lines[i]:
            grad_end = i
            break

    if grad_end is None:
        raise RuntimeError("End of gradient block ($end) not found.")

    # The last natoms lines before $end are the gradient values
    gradient_lines = lines[grad_end - natoms : grad_end]

    gradients = []
    for line in gradient_lines:
        # Replace Fortran 'D' notation with 'E'
        values = [float(x.replace("D", "E")) for x in line.split()]
        gradients.append(values)

    gradients = np.array(gradients)

    # Forces = -gradients, convert from Hartree/Bohr to eV/Angstrom
    forces = -gradients * HARTREE_PER_BOHR_TO_EV_PER_ANGSTROM

    return forces


def read_stress(output_file, atoms):
    """
    Read the stress tensor from the RIPER output by parsing the gradlatt section
    of the control file (which riper writes when $optcell is present).

    The stress tensor is computed from the lattice gradient: the derivative of
    energy with respect to lattice vectors, converted to the Voigt stress form
    that ASE expects.

    For a periodic system, riper writes $gradlatt in the control file containing:
        cycle = N  energy = E  |dE/dlatt| = G
        lattice vectors (npdir lines with npdir components each)
        lattice gradients (npdir lines with npdir components each)

    Parameters
    ----------
    output_file : str
        Path to the RIPER output file (not used directly, but kept for API).
    atoms : ase.Atoms
        The atoms object (needed for cell volume).

    Returns
    -------
    numpy.ndarray
        Stress in Voigt notation (6 components) in eV/Angstrom^3.
        Convention: [xx, yy, zz, yz, xz, xy]

    Raises
    ------
    RuntimeError
        If stress data cannot be found or parsed.
    """
    npdir = int(np.sum(atoms.pbc))

    # Read gradlatt from control file
    try:
        with open("control", "r") as f:
            lines = f.readlines()
    except FileNotFoundError:
        raise RuntimeError("Control file not found for stress reading.")

    # Find $gradlatt
    gradlatt_start = None
    for i, line in enumerate(lines):
        if "$gradlatt" in line:
            gradlatt_start = i
            break

    if gradlatt_start is None:
        raise RuntimeError(
            "$gradlatt section not found in control file. "
            "Make sure $optcell is in the control file and the calculation completed."
        )

    # Find the last cycle in the gradlatt section
    last_cycle_line = None
    for i in range(gradlatt_start + 1, len(lines)):
        if lines[i].strip().startswith("$"):
            break
        if "cycle" in lines[i]:
            last_cycle_line = i

    if last_cycle_line is None:
        raise RuntimeError("No cycle data found in $gradlatt section.")

    # After the cycle line: npdir lines of lattice vectors, then npdir lines of gradients
    lat_lines = lines[last_cycle_line + 1 : last_cycle_line + 1 + npdir]
    grad_lines = lines[last_cycle_line + 1 + npdir : last_cycle_line + 1 + 2 * npdir]

    # Parse lattice gradients (dE/d(lattice_vector_component)) in Hartree/Bohr
    grad_latt = np.zeros((3, 3))
    for i, line in enumerate(grad_lines):
        values = [float(x.replace("D", "E")) for x in line.split()]
        for j, v in enumerate(values):
            grad_latt[i, j] = v

    # The lattice vectors from the atoms object (in Angstrom)
    cell = atoms.cell[:]

    # Volume (handles 1D, 2D, 3D)
    volume = atoms.get_volume()  # in Angstrom^3

    if volume < 1e-10:
        raise RuntimeError(
            "Cell volume is near zero. Cannot compute stress for non-periodic system."
        )

    # Build the full 3x3 lattice vector matrix in Bohr
    cell_bohr = cell * ANGSTROM_TO_BOHR

    # Stress tensor: sigma_ij = (1/V) * sum_k (dE/dh_ki) * h_kj
    # where h is the matrix of lattice vectors (columns or rows depending on convention)
    # In TURBOMOLE/RIPER, lattice vectors are rows of the matrix.
    # grad_latt[i,j] = dE/d(h_{i,j})
    #
    # The virial stress is: sigma = (1/V) * grad_latt^T @ cell_bohr
    # But we need to be careful about units and convention.
    #
    # grad_latt is in Hartree/Bohr (derivative w.r.t. lattice vector in Bohr)
    # We want stress in eV/Angstrom^3

    # Convert gradient to eV/Angstrom
    grad_latt_eV_A = grad_latt * HARTREE_PER_BOHR_TO_EV_PER_ANGSTROM

    # Stress tensor: sigma_ij = (1/V) * sum_k grad_latt[k,i] * cell[k,j]
    # Using cell in Angstrom
    stress_tensor = np.zeros((3, 3))
    for i in range(3):
        for j in range(3):
            for k in range(npdir):
                stress_tensor[i, j] += grad_latt_eV_A[k, i] * cell[k, j]
    stress_tensor /= volume

    # ASE convention: stress is the negative of the virial stress
    # and in Voigt notation: [xx, yy, zz, yz, xz, xy]
    # ASE expects the stress such that: stress = -1/V * d(E)/d(strain)
    # The gradient dE/dh relates to stress as sigma = (1/V) * (dE/dh)^T * h
    # ASE uses the convention where compressive stress is positive,
    # so we don't negate here as the gradient already gives the correct sign.

    voigt_stress = np.array([
        stress_tensor[0, 0],  # xx
        stress_tensor[1, 1],  # yy
        stress_tensor[2, 2],  # zz
        stress_tensor[1, 2],  # yz
        stress_tensor[0, 2],  # xz
        stress_tensor[0, 1],  # xy
    ])

    return voigt_stress