"""
RIPER - ASE Calculator for TURBOMOLE's RIPER module.

Provides an ASE-compatible calculator interface for performing DFT calculations
using TURBOMOLE's RIPER module for molecular and periodic systems (1D, 2D, 3D).

Usage:
    from riper import RIPERCalculator

    calc = RIPERCalculator(functional="pbe", basis="pob-DZVP-rev2")
    atoms.calc = calc
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    stress = atoms.get_stress()
"""

from riper.calculator import RIPERCalculator

__version__ = "0.1.0"
__all__ = ["RIPERCalculator"]