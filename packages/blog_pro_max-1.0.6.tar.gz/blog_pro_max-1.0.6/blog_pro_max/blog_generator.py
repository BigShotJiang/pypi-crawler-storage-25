"""
blog_generator.py — LLM 驅動的部落格文章生成引擎
"""

import os
from pathlib import Path

from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

try:
    from blog_pro_max.core import (
        render_template,
        build_system_prompt,
        get_template,
        TEMPLATES,
    )
except ImportError:
    from core import (
        render_template,
        build_system_prompt,
        get_template,
        TEMPLATES,
    )


def build_prompt(
    keyword: str,
    audience: str = "30-45 歲知識工作者",
    word_count: int = 1200,
    language: str = "zh-TW",
    template: str = "blog-skill-content",
) -> tuple[str, str]:
    """Build user prompt and system prompt from a registered template."""
    user_prompt = render_template(template, keyword, audience, word_count, language)
    system_prompt = build_system_prompt(template)
    return user_prompt, system_prompt


GITHUB_MODELS_ENDPOINT = "https://models.inference.ai.azure.com"


def _make_client() -> OpenAI:
    """Return an OpenAI-compatible client.

    Priority:
    1. GITHUB_TOKEN  → GitHub Models endpoint (free tier, no OpenAI account needed)
    2. OPENAI_API_KEY → OpenAI directly
    """
    github_token = os.getenv("GITHUB_TOKEN")
    if github_token:
        return OpenAI(api_key=github_token, base_url=GITHUB_MODELS_ENDPOINT)

    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        return OpenAI(api_key=openai_key)

    raise EnvironmentError(
        "未設定 API 金鑰。請在 .env 中設定：\n"
        "  GITHUB_TOKEN=ghp_...   ← GitHub PAT（免費，推薦）\n"
        "  OPENAI_API_KEY=sk-...  ← OpenAI API Key"
    )


def generate_article(
    keyword: str,
    audience: str = "30-45 歲知識工作者",
    word_count: int = 1200,
    language: str = "zh-TW",
    model: str = "gpt-4o",
    template: str = "blog-skill-content",
) -> str:
    client = _make_client()
    prompt, system_message = build_prompt(
        keyword, audience, word_count, language, template
    )

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_message},
            {"role": "user", "content": prompt},
        ],
        temperature=0.7,
        max_tokens=4096,
    )

    content = response.choices[0].message.content
    return content.strip()


def generate_titles(
    article_content: str,
    keyword: str,
    audience: str = "30-45 歲知識工作者",
    language: str = "zh-TW",
    model: str = "gpt-4o",
    count: int = 4,
) -> list[dict[str, str]]:
    """根據文章內容產出多個標題建議（含英文 permalink slug）。

    Returns:
        list of {"title": "中文標題", "slug": "english-permalink-slug"}
    """
    client = _make_client()

    system_prompt = (
        "你是一位部落格標題專家（blog-title-writer）。"
        "你擅長分析文章內容後，產出簡潔、專業、吸引人的標題。\n\n"
        "規則：\n"
        "1. 每個標題控制在 15-25 字（中文）以內\n"
        "2. 標題必須包含核心關鍵字或其同義詞\n"
        "3. 標題要適合目標受眾的閱讀偏好\n"
        "4. 風格多元：分別提供「直述型」「提問型」「數字型」「情感型」各一個\n"
        "5. 不要使用引號包住標題\n"
        "6. 每個標題同時提供英文版 permalink slug（全小寫、用連字號分隔、去除停用詞、適合 WordPress 網址）\n\n"
        "輸出格式（嚴格遵守）：\n"
        "TITLE: 中文標題\n"
        "SLUG: english-permalink-slug\n"
        "---"
    )

    user_prompt = (
        f"請根據以下文章內容，為目標受眾「{audience}」產出 {count} 個標題建議。\n\n"
        f"核心關鍵字：{keyword}\n"
        f"語言：{language}\n\n"
        f"文章內容（前 1500 字）：\n\n"
        f"{article_content[:1500]}"
    )

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.8,
        max_tokens=512,
    )

    raw = response.choices[0].message.content.strip()

    # Parse structured output
    import re
    results = []
    current = {}
    for line in raw.splitlines():
        line = line.strip()
        if line.startswith("TITLE:"):
            current["title"] = line[6:].strip()
        elif line.startswith("SLUG:"):
            slug = line[5:].strip().lower()
            slug = re.sub(r"[^a-z0-9-]", "-", slug)
            slug = re.sub(r"-+", "-", slug).strip("-")
            current["slug"] = slug
        elif line == "---" or (not line and "title" in current):
            if current.get("title"):
                current.setdefault("slug", "")
                results.append(current)
            current = {}

    # Catch last entry
    if current.get("title"):
        current.setdefault("slug", "")
        results.append(current)

    return results[:count]


def generate_cover_prompts(
    article_content: str,
    keyword: str,
    audience: str = "30-45 歲知識工作者",
    model: str = "gpt-4o",
    count: int = 3,
) -> list[dict[str, str]]:
    """根據文章內容產出封面圖片的 AI 繪圖提示詞。

    Returns:
        list of {"style": "風格名稱", "prompt": "英文提示詞", "description": "中文說明"}
    """
    client = _make_client()

    system_prompt = (
        "你是一位封面提示詞專家（cover-prompt-writer）。"
        "你擅長根據文章內容，產出適合用於 AI 繪圖工具（如 Midjourney、DALL-E、Stable Diffusion）"
        "的封面圖片提示詞。\n\n"
        "規則：\n"
        "1. 提示詞必須是英文（AI 繪圖工具主要支援英文）\n"
        "2. 每個提示詞包含：主體描述、風格、色調、構圖、氛圍\n"
        "3. 避免包含文字元素（AI 繪圖不擅長生成文字）\n"
        "4. 提供不同風格：寫實攝影風、插畫風、極簡設計風\n"
        "5. 每個提示詞控制在 50-100 個英文單詞\n"
        "6. 適合作為部落格文章封面，16:9 或 3:2 比例\n\n"
        "輸出格式（嚴格遵守，每個提示詞一組）：\n"
        "STYLE: 風格名稱（中文）\n"
        "PROMPT: 英文提示詞\n"
        "DESC: 中文說明（一句話描述這張圖的意境）\n"
        "---"
    )

    user_prompt = (
        f"請根據以下文章內容，產出 {count} 組封面圖片的 AI 繪圖提示詞。\n\n"
        f"核心關鍵字：{keyword}\n"
        f"目標受眾：{audience}\n\n"
        f"文章內容（前 1000 字）：\n\n"
        f"{article_content[:1000]}"
    )

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.8,
        max_tokens=1024,
    )

    raw = response.choices[0].message.content.strip()

    # Parse structured output
    results = []
    current = {}
    for line in raw.splitlines():
        line = line.strip()
        if line.startswith("STYLE:"):
            current["style"] = line[6:].strip()
        elif line.startswith("PROMPT:"):
            current["prompt"] = line[7:].strip()
        elif line.startswith("DESC:"):
            current["description"] = line[5:].strip()
        elif line == "---" or (not line and "style" in current and "prompt" in current):
            if current.get("style") and current.get("prompt"):
                current.setdefault("description", "")
                results.append(current)
            current = {}

    # Catch last entry
    if current.get("style") and current.get("prompt"):
        current.setdefault("description", "")
        results.append(current)

    return results[:count]
