#!/usr/bin/env python3
"""
content_research.py — blog-pro-max 主程式進入點

用法：
  python scripts/content_research.py --keyword "關鍵字" [選項]
"""

import argparse
import re
import sys
from datetime import date
from pathlib import Path

# Ensure UTF-8 output on all platforms (e.g., Windows cp950 terminals)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

try:
    from blog_pro_max._resources import RESOURCE_ROOT
    from blog_pro_max.core import ensure_environment, list_templates, scan_project_status, TEMPLATES
    from blog_pro_max.blog_generator import build_prompt, generate_article, generate_titles, generate_cover_prompts
    from blog_pro_max.style_checker import check_content, check_file
    from blog_pro_max.output_md2html import convert_file as md2html
except ImportError:
    RESOURCE_ROOT = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(RESOURCE_ROOT / "scripts"))
    from core import ensure_environment, list_templates, scan_project_status, TEMPLATES
    from blog_generator import build_prompt, generate_article, generate_titles, generate_cover_prompts
    from style_checker import check_content, check_file
    from output_md2html import convert_file as md2html


def slugify(text: str) -> str:
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s]+", "-", text.strip())
    return text.lower()[:80]


def resolve_keyword(args) -> str:
    """Resolve keyword from --keyword (with @file support) or --keyword-file."""
    raw = args.keyword
    kf = getattr(args, "keyword_file", None)

    if kf:
        p = Path(kf)
        if not p.exists():
            print(f"❌ 找不到關鍵字檔案：{kf}")
            sys.exit(1)
        return p.read_text(encoding="utf-8").strip()

    if raw.startswith("@"):
        p = Path(raw[1:])
        if not p.exists():
            print(f"❌ 找不到關鍵字檔案：{p}")
            sys.exit(1)
        return p.read_text(encoding="utf-8").strip()

    return raw


def main():
    available_templates = ", ".join(TEMPLATES.keys())

    parser = argparse.ArgumentParser(
        description="blog-pro-max：自動化 SEO 內容創作與部落格文章生成",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--keyword", default=None,
        help="核心關鍵字，或使用 @檔案路徑 從檔案讀取（與 --keyword-file 二擇一）",
    )
    parser.add_argument(
        "--keyword-file", default=None,
        help="從指定檔案讀取關鍵字內容（替代 --keyword）",
    )
    parser.add_argument(
        "--audience", default="30-45 歲知識工作者", help="目標讀者（預設：30-45 歲知識工作者）"
    )
    parser.add_argument(
        "--word-count", type=int, default=1200, help="目標字數（預設：1200）"
    )
    parser.add_argument(
        "--language", default="zh-TW", help="輸出語言（預設：zh-TW）"
    )
    parser.add_argument(
        "--output", default=None, help="輸出檔案路徑（預設：output/{keyword}.md）"
    )
    parser.add_argument(
        "--model", default="gpt-4o", help="OpenAI 模型（預設：gpt-4o）"
    )
    parser.add_argument(
        "--template", default="blog-skill-content",
        help=f"寫作風格模板（預設：blog-skill-content）。可用：{available_templates}",
    )
    parser.add_argument(
        "--check-only", default=None,
        help="僅對指定檔案執行風格檢查，不生成文章",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="顯示 prompt 但不呼叫 API",
    )
    parser.add_argument(
        "--status", action="store_true",
        help="顯示專案狀態報告",
    )
    parser.add_argument(
        "--list-templates", action="store_true",
        help="列出所有可用模板",
    )

    args = parser.parse_args()

    # Status mode
    if args.status:
        print(scan_project_status())
        return

    # List templates mode
    if args.list_templates:
        print("📚 可用寫作風格模板：\n")
        for name, info in list_templates().items():
            status = "✅" if info["exists"] else "❌"
            print(f"  {status} {name:25s} {info['description']}")
        return

    # Validate keyword source
    if not args.keyword and not args.keyword_file:
        parser.error("必須提供 --keyword 或 --keyword-file")

    keyword = resolve_keyword(args)

    # Environment check
    if not ensure_environment():
        print("\n❌ 環境檢查未通過，請修正上述問題。")
        sys.exit(1)

    # Style check only mode
    if args.check_only:
        print(f"🔍 檢查檔案：{args.check_only}")
        report = check_file(args.check_only, keyword)
        print(report.summary())
        sys.exit(0 if report.passed else 1)

    template = args.template
    output_path = args.output or str(
        Path.cwd() / "output" / f"{slugify(keyword)}.md"
    )

    print(f"🔑 核心關鍵字：{keyword}")
    print(f"👥 目標讀者：{args.audience}")
    print(f"📏 目標字數：{args.word_count}")
    print(f"🌐 語言：{args.language}")
    print(f"🤖 模型：{args.model}")
    print(f"🎨 模板：{template}")
    print(f"📄 輸出路徑：{output_path}")
    print()

    # Dry run mode
    if args.dry_run:
        prompt, system_prompt = build_prompt(
            keyword, args.audience, args.word_count, args.language, template
        )
        print("=" * 60)
        print("📋 System Prompt")
        print("=" * 60)
        print(system_prompt[:800] + "..." if len(system_prompt) > 800 else system_prompt)
        print()
        print("=" * 60)
        print("📝 User Prompt（文章生成指令）")
        print("=" * 60)
        print(prompt)
        return

    # Generate article
    print("⏳ 正在生成文章...")
    try:
        article = generate_article(
            keyword=keyword,
            audience=args.audience,
            word_count=args.word_count,
            language=args.language,
            model=args.model,
            template=template,
        )
    except EnvironmentError as e:
        print(f"❌ {e}")
        sys.exit(1)
    except KeyError as e:
        print(f"❌ {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ 生成失敗：{e}")
        sys.exit(1)

    # Save output
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(article, encoding="utf-8")
    print(f"✅ 文章已儲存至：{output_path}")
    print()

    # Style check
    print("🔍 正在執行風格檢查...")
    report = check_content(article, keyword)
    print(report.summary())

    if not report.passed:
        print()
        print("⚠️  文章已儲存，但有風格問題需要修正。")
    else:
        print()
        print("🎉 文章生成完成，所有檢查通過！")

    # Generate title suggestions
    print()
    print("📝 正在生成標題建議...")
    try:
        titles = generate_titles(
            article_content=article,
            keyword=keyword,
            audience=args.audience,
            language=args.language,
            model=args.model,
        )
        if titles:
            print("💡 推薦標題選項：")
            for i, t in enumerate(titles, 1):
                slug_display = f"  /{t['slug']}" if t.get('slug') else ""
                print(f"   {i}. {t['title']}{slug_display}")

            # Append title suggestions to .md
            title_block = "\n\n---\n\n## 📝 推薦標題選項\n\n"
            title_block += "> 以下由「部落格標題專家」自動產出，請人工選擇最適合的標題。\n\n"
            title_block += "| # | 標題 | WordPress Permalink |\n"
            title_block += "|---|------|--------------------|\n"
            for i, t in enumerate(titles, 1):
                slug = t.get('slug', '')
                title_block += f"| {i} | {t['title']} | `/{slug}` |\n"

            # Re-read and append (in case style check modified it)
            current_content = output_file.read_text(encoding="utf-8")
            output_file.write_text(current_content + title_block, encoding="utf-8")
            print(f"   ✅ 標題建議已附加到 {output_path}")
    except Exception as e:
        print(f"   ⚠️  標題生成失敗（不影響文章）：{e}")

    # Generate cover image prompts
    print()
    print("🎨 正在生成封面提示詞...")
    try:
        cover_prompts = generate_cover_prompts(
            article_content=article,
            keyword=keyword,
            audience=args.audience,
            model=args.model,
        )
        if cover_prompts:
            print("🖼️  推薦封面提示詞：")
            for i, cp in enumerate(cover_prompts, 1):
                print(f"   {i}. [{cp['style']}] {cp['description']}")

            cover_block = "\n\n---\n\n## 🎨 推薦封面提示詞\n\n"
            cover_block += "> 以下由「封面提示詞專家」自動產出，可直接貼到 Midjourney、DALL-E 或 Stable Diffusion 使用。\n\n"
            for i, cp in enumerate(cover_prompts, 1):
                cover_block += f"### {i}. {cp['style']}\n\n"
                cover_block += f"**Prompt:**\n\n```\n{cp['prompt']}\n```\n\n"
                if cp['description']:
                    cover_block += f"*{cp['description']}*\n\n"

            current_content = output_file.read_text(encoding="utf-8")
            output_file.write_text(current_content + cover_block, encoding="utf-8")
            print(f"   ✅ 封面提示詞已附加到 {output_path}")
    except Exception as e:
        print(f"   ⚠️  封面提示詞生成失敗（不影響文章）：{e}")

    # Convert to HTML
    html_path = str(Path(output_path).with_suffix(".html"))
    print(f"\n📄 正在轉換 HTML...")
    md2html(output_path, html_path)
    print(f"✅ HTML 已儲存至：{html_path}")

    if report.passed:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
