import logging
import os
import uuid
from datetime import datetime
from typing import Any, Optional

from kemi import dedup, lifecycle, sanitize, scoring
from kemi.adapters.base import EmbeddingAdapter, StorageAdapter
from kemi.models import (
    LifecycleState,
    MemoryConfig,
    MemoryObject,
    MemorySource,
)

logger = logging.getLogger(__name__)


class Memory:
    def __init__(
        self,
        embed: Optional[EmbeddingAdapter] = None,
        store: Optional[StorageAdapter] = None,
        config: Optional[MemoryConfig] = None,
    ) -> None:
        if embed is None:
            try:
                from kemi.adapters.embedding.fastembed import FastEmbedAdapter

                self._embed: EmbeddingAdapter = FastEmbedAdapter()
            except ImportError as e:
                raise ImportError(
                    "No embedding adapter provided and fastembed is not installed. "
                    "Install with: pip install kemi[local] or provide your own: "
                    "Memory(embed=YourAdapter())"
                ) from e
        else:
            self._embed = embed

        if store is None:
            from kemi.adapters.storage.sqlite import SQLiteStorageAdapter

            default_db_path = os.path.join(os.path.expanduser("~"), ".kemi", "memories.db")
            os.makedirs(os.path.dirname(default_db_path), exist_ok=True)
            self._store: StorageAdapter = SQLiteStorageAdapter(db_path=default_db_path)
        else:
            self._store = store

        if config is None:
            self._config: MemoryConfig = MemoryConfig()
        else:
            self._config = config

    def remember(
        self,
        user_id: str,
        content: str,
        importance: float = 0.5,
        source: MemorySource = MemorySource.USER_STATED,
        metadata: Optional[dict[str, Any]] = None,
        sanitize_input: bool = False,
    ) -> str:
        if not user_id or not user_id.strip():
            raise ValueError("user_id cannot be empty")
        if not content or not content.strip():
            raise ValueError("content cannot be empty — there is nothing to remember")
        if not isinstance(importance, (int, float)):
            raise TypeError(
                f"importance must be a number between 0.0 and 1.0, got {type(importance).__name__}"
            )

        if sanitize_input:
            content = sanitize.sanitize(content, strict=self._config.sanitize)

        embedding = self._embed.embed_single(content)
        embedding_dim = len(embedding)

        clamped_importance = max(0.0, min(1.0, importance))

        new_memory = MemoryObject(
            memory_id=str(uuid.uuid4()),
            user_id=user_id,
            content=content,
            embedding=embedding,
            score=0.0,
            created_at=datetime.utcnow(),
            last_accessed_at=datetime.utcnow(),
            source=source,
            importance=clamped_importance,
            lifecycle_state=LifecycleState.ACTIVE,
            metadata=metadata or {},
            embedding_dim=embedding_dim,
        )

        existing = self._store.get_all_by_user(
            user_id,
            lifecycle_filter=[
                LifecycleState.ACTIVE,
                LifecycleState.DECAYING,
                LifecycleState.ARCHIVED,
            ],
        )

        duplicates = dedup.find_duplicates(new_memory, existing, self._config.dedup_threshold)

        if duplicates:
            resolved = dedup.resolve_duplicate(new_memory, duplicates[0])
            self._store.update(resolved)
            logger.info(f"Resolved duplicate for user {user_id}: {resolved.memory_id}")
            return resolved.memory_id

        conflicts = dedup.find_conflicts(
            new_memory,
            existing,
            self._config.conflict_threshold,
            self._config.dedup_threshold,
        )

        if conflicts:
            new_memory.metadata["conflict_flagged"] = True
            logger.warning(
                f"Potential conflict detected for user {user_id}: "
                f"new memory '{content[:50]}...' conflicts with existing memory "
                f"'{conflicts[0].content[:50]}...'"
            )

        self._store.store(new_memory)
        return new_memory.memory_id

    def recall(
        self,
        user_id: str,
        query: str,
        top_k: int = 5,
        max_tokens: Optional[int] = None,
        lifecycle_filter: Optional[list[LifecycleState]] = None,
    ) -> list[MemoryObject]:
        if not user_id or not user_id.strip():
            raise ValueError("user_id cannot be empty")
        if not query or not query.strip():
            raise ValueError("query cannot be empty — what should kemi search for?")
        if top_k < 1:
            raise ValueError(f"top_k must be at least 1, got {top_k}")

        query_embedding = self._embed.embed_single(query)

        if lifecycle_filter is None:
            lifecycle_filter = lifecycle.get_recall_filter()

        search_results = self._store.search(
            user_id=user_id,
            query_embedding=query_embedding,
            top_k=top_k * 3,
            lifecycle_filter=lifecycle_filter,
        )

        current_dim = self._embed.dimension()
        if search_results:
            stored_dim = search_results[0].embedding_dim
            if stored_dim is not None and stored_dim != current_dim:
                raise ValueError(
                    f"Embedding dimension mismatch: stored memories use {stored_dim} dimensions "
                    f"but current adapter produces {current_dim} dimensions. "
                    f"Run memory.migrate(user_id, new_adapter) to re-embed your memories."
                )

        ranked = scoring.rank_memories(search_results, query_embedding)

        effective_max_tokens = (
            max_tokens if max_tokens is not None else self._config.max_tokens_default
        )

        if effective_max_tokens is not None:
            truncated = scoring.truncate_by_tokens(ranked, effective_max_tokens)
        else:
            truncated = ranked

        final_results = truncated[:top_k]

        for mem in final_results:
            mem.last_accessed_at = datetime.utcnow()

            new_state = lifecycle.evaluate_lifecycle(mem, self._config.decay_threshold_hours)

            if new_state != mem.lifecycle_state:
                updated = lifecycle.transition(mem, new_state)
                self._store.update(updated)

        return final_results

    def forget(
        self,
        user_id: str,
        memory_id: Optional[str] = None,
    ) -> int:
        if not user_id or not user_id.strip():
            raise ValueError("user_id cannot be empty")

        if memory_id is not None:
            deleted = self._store.delete_by_id(memory_id)
            return 1 if deleted else 0
        else:
            count = self._store.delete_by_user(user_id)
            return count

    def context_block(
        self,
        user_id: str,
        query: str,
        top_k: int = 5,
        max_tokens: int = 1500,
        prefix: str = "Relevant context from memory:",
    ) -> str:
        memories = self.recall(
            user_id=user_id,
            query=query,
            top_k=top_k,
            max_tokens=max_tokens,
        )

        if not memories:
            return ""

        lines = [prefix]
        for mem in memories:
            lines.append(f"- {mem.content}")

        return "\n".join(lines)

    async def aremember(
        self,
        user_id: str,
        content: str,
        importance: float = 0.5,
        source: MemorySource = MemorySource.USER_STATED,
        metadata: Optional[dict[str, Any]] = None,
        sanitize_input: bool = False,
    ) -> str:
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.remember(user_id, content, importance, source, metadata, sanitize_input),
        )

    async def arecall(
        self,
        user_id: str,
        query: str,
        top_k: int = 5,
        max_tokens: Optional[int] = None,
        lifecycle_filter: Optional[list[LifecycleState]] = None,
    ) -> list[MemoryObject]:
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, lambda: self.recall(user_id, query, top_k, max_tokens, lifecycle_filter)
        )

    async def aforget(
        self,
        user_id: str,
        memory_id: Optional[str] = None,
    ) -> int:
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.forget(user_id, memory_id))

    async def acontext_block(
        self,
        user_id: str,
        query: str,
        top_k: int = 5,
        max_tokens: int = 1500,
        prefix: str = "Relevant context from memory:",
    ) -> str:
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, lambda: self.context_block(user_id, query, top_k, max_tokens, prefix)
        )

    def migrate(
        self,
        user_id: str,
        new_embed_fn: EmbeddingAdapter,
        batch_size: int = 100,
    ) -> int:
        if not user_id or not user_id.strip():
            raise ValueError("user_id cannot be empty")
        if batch_size < 1:
            raise ValueError(f"batch_size must be at least 1, got {batch_size}")

        memories = self._store.get_all_by_user(
            user_id,
            lifecycle_filter=[LifecycleState.ACTIVE, LifecycleState.DECAYING],
        )

        if not memories:
            return 0

        count = 0

        for i in range(0, len(memories), batch_size):
            batch = memories[i : i + batch_size]
            contents = [m.content for m in batch]
            new_embeddings = new_embed_fn.embed(contents)
            new_dim = new_embed_fn.dimension()

            for j, mem in enumerate(batch):
                mem.embedding = new_embeddings[j]
                mem.embedding_dim = new_dim
                self._store.update(mem)
                count += 1

        logger.info(f"Migrated {count} memories for user {user_id}")
        return count

    def export(self, file_path: str) -> int:
        """Export all memories to a JSON file."""
        import json

        all_memories = self._store.get_all()
        memories_data = []
        for mem in all_memories:
            memories_data.append(
                {
                    "memory_id": mem.memory_id,
                    "user_id": mem.user_id,
                    "content": mem.content,
                    "embedding": mem.embedding,
                    "score": mem.score,
                    "created_at": mem.created_at.isoformat() if mem.created_at else None,
                    "last_accessed_at": mem.last_accessed_at.isoformat()
                    if mem.last_accessed_at
                    else None,
                    "source": mem.source.value if mem.source else None,
                    "importance": mem.importance,
                    "lifecycle_state": mem.lifecycle_state.value if mem.lifecycle_state else None,
                    "metadata": mem.metadata,
                    "embedding_dim": mem.embedding_dim,
                }
            )

        with open(file_path, "w") as f:
            json.dump(memories_data, f, indent=2)

        logger.info(f"Exported {len(memories_data)} memories to {file_path}")
        return len(memories_data)

    def import_from(self, file_path: str) -> int:
        """Import memories from a JSON file."""
        import json

        with open(file_path, "r") as f:
            memories_data = json.load(f)

        imported_count = 0
        for mem_data in memories_data:
            existing = self._store.get(mem_data["memory_id"])
            if existing is not None:
                continue

            from datetime import datetime
            from kemi.models import LifecycleState, MemorySource

            created_at = (
                datetime.fromisoformat(mem_data["created_at"])
                if mem_data.get("created_at")
                else datetime.utcnow()
            )
            last_accessed_at = (
                datetime.fromisoformat(mem_data["last_accessed_at"])
                if mem_data.get("last_accessed_at")
                else datetime.utcnow()
            )

            memory = MemoryObject(
                memory_id=mem_data["memory_id"],
                user_id=mem_data["user_id"],
                content=mem_data["content"],
                embedding=mem_data.get("embedding"),
                score=mem_data.get("score", 0.0),
                created_at=created_at,
                last_accessed_at=last_accessed_at,
                source=MemorySource(mem_data["source"])
                if mem_data.get("source")
                else MemorySource.USER_STATED,
                importance=mem_data.get("importance", 0.5),
                lifecycle_state=LifecycleState(mem_data["lifecycle_state"])
                if mem_data.get("lifecycle_state")
                else LifecycleState.ACTIVE,
                metadata=mem_data.get("metadata", {}),
                embedding_dim=mem_data.get("embedding_dim"),
            )

            self._store.store(memory)
            imported_count += 1

        logger.info(f"Imported {imported_count} memories from {file_path}")
        return imported_count

    async def aexport(self, file_path: str) -> int:
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.export(file_path))

    async def aimport_from(self, file_path: str) -> int:
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.import_from(file_path))

    def upgrade(self) -> None:
        self._store.upgrade_schema(from_version=1, to_version=1)
        logger.info("Schema upgraded to version 1")
