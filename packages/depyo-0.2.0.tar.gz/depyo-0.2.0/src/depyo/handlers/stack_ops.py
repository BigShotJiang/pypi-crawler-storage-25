"""Translated from lib/handlers/stack_ops.js"""
from __future__ import annotations

from depyo.ast_node import ASTMatch, ASTChainStore
from depyo.handlers._util import debug_log


def handleDupTop(self):
    # Track COPY pattern for match detection
    prev = self.code.Prev
    prevOpCode = prev.OpCodeID if prev is not None else None
    prevOffset = prev.Offset if prev is not None else None

    # Check if this is COPY after LOAD (potential match start)
    if prevOpCode in (self.OpCodes.LOAD_FAST_A, self.OpCodes.LOAD_NAME_A, self.OpCodes.LOAD_GLOBAL_A):
        # Save subject for later use
        self.potentialMatchSubject = self.dataStack.top()

        # First COPY after LOAD → potential match candidate
        if self.matchCandidateStart == -1:
            self.matchCandidateStart = self.code.Current.Offset
            self.lastLoadOffset = prevOffset
            self.matchParentBlock = self.curBlock
            if not self.matchPreNodesStart:
                self.matchPreNodesStart = len(self.matchParentBlock.nodes)

            debug_log(f"[DUP_TOP] Match candidate at offset {self.matchCandidateStart}")

            # Look ahead to confirm match pattern immediately
            if not self.currentMatch and self.lookAheadForMatchPattern():
                self.currentMatch = ASTMatch(self.potentialMatchSubject)
                self.currentMatch.line = self.code.Current.LineNo
                self.matchParentBlock = self.curBlock
                self.inMatchPattern = True  # Start tracking pattern operations
                self.patternOps = []  # Clear for first case
    # Second COPY without intermediate LOAD → confirm match or start new case!
    elif (self.matchCandidateStart > 0
          and prevOffset is not None
          and prevOffset > self.lastLoadOffset
          and prevOpCode == self.OpCodes.POP_TOP):

        # This COPY has no LOAD before it → reusing same subject
        # Match patterns only exist in Python 3.10+
        if (not self.currentMatch and self.potentialMatchSubject
                and self.object.Reader.versionCompare(3, 10) >= 0):
            # First time - create match (fallback if look-ahead didn't work)
            self.currentMatch = ASTMatch(self.potentialMatchSubject)
            self.currentMatch.line = self.code.Current.LineNo
            self.matchParentBlock = self.curBlock
            self.inMatchPattern = True
            self.patternOps = []
            if not self.matchPreNodesStart:
                self.matchPreNodesStart = len(self.matchParentBlock.nodes)

            subj_name = type(self.potentialMatchSubject).__name__ if self.potentialMatchSubject is not None else None
            self.debug(f"[DUP_TOP] MATCH CONFIRMED at offset {self.code.Current.Offset}! Subject: {subj_name}")
        elif self.currentMatch:
            # Subsequent case in same match - reset pattern tracking
            self.debug(f"[DUP_TOP] Starting new case at offset {self.code.Current.Offset}")
            self.inMatchPattern = True
            self.patternOps = []

    nxt = self.code.Next
    if self.dataStack.top() is None:
        self.dataStack.append(None)
    elif nxt is not None and nxt.OpCodeID == self.OpCodes.ROT_THREE:
        # double compare case
        self.skipNextJump = True
        self.code.GoNext()
    elif isinstance(self.dataStack.top(), ASTChainStore):
        chainstore = self.dataStack.pop()
        self.dataStack.append(self.dataStack.top())
        self.dataStack.append(chainstore)
    elif nxt is not None and nxt.OpCodeID == self.OpCodes.LOAD_ATTR_A:
        # Augmented assign on attribute (a.value += 1)
        # Don't create ChainStore - just duplicate the value
        self.dataStack.append(self.dataStack.top())
    else:
        # Check if this is a walrus operator pattern:
        # DUP_TOP → STORE_* → <not another STORE>
        nextOpCode = nxt.OpCodeID if nxt is not None else None
        isStoreOp = nextOpCode in (
            self.OpCodes.STORE_NAME_A,
            self.OpCodes.STORE_FAST_A,
            self.OpCodes.STORE_GLOBAL_A,
        )

        # Pre-3.8 list/set/dict comprehensions compile to
        #   BUILD_LIST 0 / DUP_TOP / STORE_NAME _[N] / ... / LIST_APPEND / ...
        # which shares the DUP→STORE→non-STORE shape with walrus. `_[N]` is
        # CPython's synthetic append slot, never a real identifier, so the
        # STORE is swallowed (see processStore) and the DUP must be too —
        # otherwise the walrus branch leaks isWalrusOperator to the next STORE
        # (the FOR_ITER's iteration variable), stealing its valueNode.
        nextName = (nxt.Name if nxt is not None and nxt.Name is not None else "") or ""
        if isStoreOp and len(nextName) >= 2 and nextName.startswith('_['):
            return

        if isStoreOp and nxt is not None and nxt.Next is not None:
            # Chain assign and nested walrus share the shape
            #   (DUP STORE)+  ending either with STORE (chain, statement)
            #                  or STORE / POP_TOP (walrus, expression).
            # Walk forward over the alternating DUP/STORE run and inspect
            # what follows the last STORE to distinguish them.
            storeOps = {
                self.OpCodes.STORE_NAME_A,
                self.OpCodes.STORE_FAST_A,
                self.OpCodes.STORE_GLOBAL_A,
                self.OpCodes.STORE_ATTR_A,
                self.OpCodes.STORE_DEREF_A,
            }
            instructions = self.code.Instructions
            idx = self.code.CurrentInstructionIndex + 1  # at STORE
            lastStoreIdx = -1
            storeCount = 0
            while idx < len(instructions):
                op = instructions[idx].OpCodeID
                if op in storeOps:
                    lastStoreIdx = idx
                    storeCount += 1
                    idx += 1
                elif op == self.OpCodes.DUP_TOP:
                    idx += 1
                else:
                    break
            afterRunOp = None
            if lastStoreIdx >= 0 and lastStoreIdx + 1 < len(instructions):
                afterRunOp = instructions[lastStoreIdx + 1].OpCodeID
            # Chain assign needs 2+ STOREs; single-STORE runs are walrus
            # regardless of what follows.
            isChainAssign = (storeCount >= 2
                             and afterRunOp is not None
                             and afterRunOp != self.OpCodes.POP_TOP)

            if not isChainAssign:
                # Nested walrus operator — mark this DUP as walrus-producing.
                self.isWalrusOperator = True
                return

        # If next opcode is NOT a store operation, this is just a temporary copy
        # (e.g., for match/case pattern matching) - don't create ChainStore
        if not isStoreOp:
            self.dataStack.append(self.dataStack.top())
            return

        # Regular chained assignment (a = b = 10)
        self.dataStack.append(self.dataStack.top())
        node = ASTChainStore([], self.dataStack.top())
        self.dataStack.append(node)


def handleCopyA(self):
    # COPY opcode (Python 3.11+): copies the i-th item to the top of the stack
    # Argument specifies which item: 1 = top, 2 = second, etc.
    depth = self.code.Current.Argument

    # Save potential match subject for COPY 1 (like DUP_TOP)
    if depth == 1:
        prev = self.code.Prev
        prevOpCode = prev.OpCodeID if prev is not None else None
        if prevOpCode in (self.OpCodes.LOAD_FAST_A, self.OpCodes.LOAD_NAME_A, self.OpCodes.LOAD_GLOBAL_A):
            self.potentialMatchSubject = self.dataStack.top()
            subj_name = type(self.potentialMatchSubject).__name__ if self.potentialMatchSubject is not None else None
            debug_log(f"[COPY] Saved potential match subject: {subj_name}")

        # COPY 1 is equivalent to DUP_TOP - same walrus detection logic
        handleDupTop(self)
    else:
        # For other depths, just copy the item
        index = len(self.dataStack) - depth
        if 0 <= index < len(self.dataStack):
            self.dataStack.append(self.dataStack[index])


def handleDupTopTwo(self):
    first = self.dataStack.pop()
    second = self.dataStack.top()

    self.dataStack.append(first)
    self.dataStack.append(second)
    self.dataStack.append(first)


def handleDupTopxA(self):
    first = []
    second = []

    for idx in range(self.code.Current.Argument):
        node = self.dataStack.pop()
        first.append(node)
        second.append(node)

    while first:
        self.dataStack.append(first.pop())

    while second:
        self.dataStack.append(second.pop())


def handleSwapA(self):
    # Python 3.11+ SWAP opcode: swaps i-th item with TOS
    # Argument specifies depth: 2 = swap top 2, 3 = swap TOS with 3rd, etc.
    depth = self.code.Current.Argument

    # Record pattern operation if in pattern matching
    if self.inMatchPattern:
        self.patternOps.append({
            'type': 'SWAP',
            'depth': depth,
        })

    if depth == 2:
        # SWAP 2: swap top two items
        handleRotTwo(self)
    elif depth == 3:
        # SWAP 3: swap TOS with third item
        one = self.dataStack.pop()
        two = self.dataStack.pop()
        three = self.dataStack.pop()

        self.dataStack.append(one)
        self.dataStack.append(two)
        self.dataStack.append(three)
    else:
        # General case: swap TOS with i-th item
        tos = self.dataStack.pop()
        index = len(self.dataStack) - (depth - 1)
        if index >= 0:
            temp = self.dataStack[index]
            self.dataStack[index] = tos
            self.dataStack.append(temp)


def handleRotTwo(self):
    # In Py3.10 match/case, ROT_TWO plays two roles:
    #   1. Sequence-pattern element-order reversal (follows UNPACK_SEQUENCE)
    #      → record SWAP so reconstructPattern's reverseOrder kicks in.
    #   2. Class-pattern binding-extraction dance (follows BINARY_SUBSCR)
    #      → record BIND_STASH so reconstructPattern can place the later
    #        STORE_FAST at the correct attribute position.
    if self.inMatchPattern:
        prev = self.code.Prev
        prev_op = prev.OpCodeID if prev is not None else None
        if prev_op == self.OpCodes.UNPACK_SEQUENCE_A:
            self.patternOps.append({'type': 'SWAP', 'depth': 2})
        elif prev_op == self.OpCodes.BINARY_SUBSCR:
            self.patternOps.append({'type': 'BIND_STASH'})
    one = self.dataStack.pop()
    if isinstance(self.dataStack.top(), ASTChainStore):
        self.dataStack.pop()
    two = self.dataStack.pop()

    self.dataStack.append(one)
    self.dataStack.append(two)


def handleRotThree(self):
    if self.inMatchPattern:
        prev = self.code.Prev
        prev_op = prev.OpCodeID if prev is not None else None
        if prev_op == self.OpCodes.BINARY_SUBSCR:
            self.patternOps.append({'type': 'BIND_STASH'})
    one = self.dataStack.pop()
    two = self.dataStack.pop()
    if isinstance(self.dataStack.top(), ASTChainStore):
        self.dataStack.pop()
    three = self.dataStack.pop()
    self.dataStack.append(one)
    self.dataStack.append(three)
    self.dataStack.append(two)


def handleRotFour(self):
    if self.inMatchPattern:
        prev = self.code.Prev
        prev_op = prev.OpCodeID if prev is not None else None
        if prev_op == self.OpCodes.BINARY_SUBSCR:
            self.patternOps.append({'type': 'BIND_STASH'})
    one = self.dataStack.pop()
    two = self.dataStack.pop()
    three = self.dataStack.pop()
    if isinstance(self.dataStack.top(), ASTChainStore):
        self.dataStack.pop()
    four = self.dataStack.pop()
    self.dataStack.append(one)
    self.dataStack.append(four)
    self.dataStack.append(three)
    self.dataStack.append(two)


def handlePushNull(self):
    self.dataStack.append(None)


def handleCache(self):
    # These "fake" opcodes are used as placeholders for optimizing
    # certain opcodes in Python 3.11+.  Since we have no need for
    # that during disassembly/decompilation, we can just treat these
    # as no-ops.
    pass


def handleNop(self):
    pass


def handleStopCode(self):
    # Early Python STOP_CODE opcode: terminate processing of instruction stream.
    self.code.CurrentInstructionIndex = len(self.code.Instructions)
