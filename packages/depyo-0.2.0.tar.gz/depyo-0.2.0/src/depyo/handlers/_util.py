"""Shared utilities for handler modules."""
from __future__ import annotations

import builtins
import sys


def _debug():
    g = getattr(builtins, 'g_cliArgs', None)
    return bool(g and getattr(g, 'debug', False))


def debug_log(msg):
    """Mimics `console.log` when g_cliArgs.debug."""
    if _debug():
        print(msg)


def debug_error(msg):
    """Mimics `console.error` when g_cliArgs.debug."""
    if _debug():
        print(msg, file=sys.stderr)
