"""Translated from lib/handlers/binary_ops.js"""
from __future__ import annotations

from depyo.ast_node import ASTBinary


def handleBinaryOpA(self):
    rVal = self.dataStack.pop()
    lVal = self.dataStack.pop()
    op = ASTBinary.from_binary_op(self.code.Current.Argument)
    if op == ASTBinary.BinOp.InvalidOp:
        # TODO: Throw and handle proper exeception.
        raise SyntaxError("Invalid op")
    node = ASTBinary(lVal, rVal, op)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleBinaryAdd(self):
    processBinaryOp(self)


def handleBinaryAnd(self):
    processBinaryOp(self)


def handleBinaryDivide(self):
    processBinaryOp(self)


def handleBinaryFloorDivide(self):
    processBinaryOp(self)


def handleBinaryLshift(self):
    processBinaryOp(self)


def handleBinaryModulo(self):
    processBinaryOp(self)


def handleBinaryMultiply(self):
    processBinaryOp(self)


def handleBinaryOr(self):
    processBinaryOp(self)


def handleBinaryPower(self):
    processBinaryOp(self)


def handleBinaryRshift(self):
    processBinaryOp(self)


def handleBinarySubtract(self):
    processBinaryOp(self)


def handleBinaryTrueDivide(self):
    processBinaryOp(self)


def handleBinaryXor(self):
    processBinaryOp(self)


def handleBinaryMatrixMultiply(self):
    processBinaryOp(self)


def handleInplaceAdd(self):
    processBinaryOp(self)


def handleInplaceAnd(self):
    processBinaryOp(self)


def handleInplaceDivide(self):
    processBinaryOp(self)


def handleInplaceFloorDivide(self):
    processBinaryOp(self)


def handleInplaceLShift(self):
    processBinaryOp(self)


def handleInplaceModulo(self):
    processBinaryOp(self)


def handleInplaceMultiply(self):
    processBinaryOp(self)


def handleInplaceOr(self):
    processBinaryOp(self)


def handleInplacePower(self):
    processBinaryOp(self)


def handleInplaceRshift(self):
    processBinaryOp(self)


def handleInplaceSubtract(self):
    processBinaryOp(self)


def handleInplaceTrueDivide(self):
    processBinaryOp(self)


def handleInplaceXor(self):
    processBinaryOp(self)


def handleInplaceMatrixMultiply(self):
    processBinaryOp(self)


def processBinaryOp(self):
    rVal = self.dataStack.pop()
    lVal = self.dataStack.pop()
    op = ASTBinary.from_opcode(self.code.Current.OpCodeID)
    if op == ASTBinary.BinOp.InvalidOp:
        # TODO: Throw and handle proper exeception.
        raise SyntaxError("Invalid op")
    node = ASTBinary(lVal, rVal, op)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)
