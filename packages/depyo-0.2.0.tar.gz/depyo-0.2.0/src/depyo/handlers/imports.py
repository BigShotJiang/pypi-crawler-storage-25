"""Translated from lib/handlers/imports.js"""
from __future__ import annotations

import sys

from depyo.ast_node import (
    ASTImport,
    ASTName,
    ASTNone,
    ASTStore,
)


def handleImportNameA(self):
    if self.object.Reader.versionCompare(2, 0) < 0:
        node = ASTImport(ASTName(self.code.Current.Name), None)
        node.line = self.code.Current.LineNo
        self.dataStack.append(node)
    else:
        fromlist = self.dataStack.pop()
        if isinstance(fromlist, ASTNone):
            fromlist = None
        dots = ''
        if self.object.Reader.versionCompare(2, 5) >= 0:
            importLevelNode = self.dataStack.pop()  # Level
            # JS `+importLevelNode?.object || -1` coerces via PythonObject.toString;
            # in Python just read Value off the Py_Int/Py_Long wrapper.
            level_obj = getattr(importLevelNode, 'object', None)
            raw = getattr(level_obj, 'Value', None) if level_obj is not None else None
            try:
                importLevel = int(raw) if raw is not None else -1
            except (TypeError, ValueError):
                importLevel = -1
            if importLevel > 0:
                dots = '.' * importLevel

        node = ASTImport(ASTName(dots + self.code.Current.Name), fromlist)
        node.line = self.code.Current.LineNo

        nxt = self.code.Next
        if nxt is not None and nxt.OpCodeID == self.OpCodes.IMPORT_STAR:
            node.add_store(ASTStore(ASTName("*"), None))
            self.code.GoNext()
        elif (fromlist is not None
              and getattr(fromlist, 'object', None) is not None
              and getattr(fromlist.object, 'ClassName', None) == 'Py_Tuple'
              and len(fromlist.object.Value) > 0):
            def _cb(name, alias):
                node.add_store(ASTStore(ASTName(name), ASTName(alias)))
            self.code.extractImportNames(fromlist.object, _cb)
        elif not fromlist:
            aliasNode = self.code.GetOpCodeByName("STORE_*")
            node.alias = ASTName(aliasNode.Label)
            self.code.GoToOffset(aliasNode.Offset)
        else:
            print('WARNING: Not covered situation in IMPORT_NAME.', file=sys.stderr)

        self.curBlock.nodes.append(node)


def handleImportFromA(self):
    pass


def handleImportStar(self):
    pass
