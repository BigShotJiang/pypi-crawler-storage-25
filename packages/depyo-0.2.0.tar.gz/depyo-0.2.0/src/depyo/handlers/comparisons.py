"""Translated from lib/handlers/comparisons.js"""
from __future__ import annotations

from depyo.ast_node import ASTMatch, ASTCompare
from depyo.handlers._util import debug_log


def handleCompareOpA(self):
    # Literal-only match patterns in 3.13+: COPY 1 + LOAD_CONST + COMPARE_OP
    # No MATCH_* opcodes appear, so initialize match tracking here.
    # Match patterns only exist in Python 3.10+
    if (not self.currentMatch and self.potentialMatchSubject and not self.inMatchPattern
            and self.object.Reader.versionCompare(3, 10) >= 0):
        self.matchSubject = self.potentialMatchSubject
        self.currentMatch = ASTMatch(self.matchSubject)
        self.currentMatch.line = self.code.Current.LineNo
        self.matchParentBlock = self.curBlock
        self.patternOps = []
        if not self.matchPreNodesStart and self.matchParentBlock:
            self.matchPreNodesStart = len(self.matchParentBlock.nodes)
    if self.currentMatch and not self.inMatchPattern:
        self.inMatchPattern = True
        self.patternOps = []
    jumpOps = [
        self.OpCodes.POP_JUMP_IF_FALSE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_FALSE_A,
        self.OpCodes.POP_JUMP_IF_TRUE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_TRUE_A,
    ]
    prev = self.code.Prev
    if self.currentMatch and self.patternOps and len(self.patternOps) and (prev is not None and prev.OpCodeID in jumpOps):
        self.patternOps = []

    right = self.dataStack.pop()
    left = self.dataStack.pop()
    arg = self.code.Current.Argument
    if self.object.Reader.versionCompare(3, 13) >= 0:
        # Py3.13: oparg = (op << 5) | (cast_bool<<4) | cache_flags. op in 0..5.
        arg >>= 5
    elif self.object.Reader.versionCompare(3, 12) >= 0:
        # Py3.12: oparg = (op << 4) | cache_flags. op in 0..5.
        arg >>= 4

    # Record pattern operation if in pattern matching
    if self.inMatchPattern:
        self.patternOps.append({
            'type': 'COMPARE',
            'op': arg,
            'left': left,
            'right': right,
        })

    # Debug: exception match (arg=10)
    if arg == 10:
        left_name = type(left).__name__ if left is not None else None
        right_name = type(right).__name__ if right is not None else None
        left_frag = left.codeFragment() if (left is not None and callable(getattr(left, 'codeFragment', None))) else left
        right_frag = right.codeFragment() if (right is not None and callable(getattr(right, 'codeFragment', None))) else right
        debug_log(f"[COMPARE_OP] EXCEPTION MATCH at offset {self.code.Current.Offset}")
        debug_log(f"  left={left_name} {left_frag}")
        debug_log(f"  right={right_name} {right_frag}")
        debug_log(f"  Stack depth: {len(self.dataStack)}")

    node = ASTCompare(left, right, arg)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleContainsOpA(self):
    right = self.dataStack.pop()
    left = self.dataStack.pop()
    # The self.code.Current.Argument will be 0 for 'in' and 1 for 'not in'.
    node = ASTCompare(left, right, ASTCompare.CompareOp.NotIn if self.code.Current.Argument else ASTCompare.CompareOp.In)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleIsOpA(self):
    right = self.dataStack.pop()
    left = self.dataStack.pop()
    # The self.code.Current.Argument will be 0 for 'is' and 1 for 'is not'.
    node = ASTCompare(left, right, ASTCompare.CompareOp.IsNot if self.code.Current.Argument else ASTCompare.CompareOp.Is)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)
