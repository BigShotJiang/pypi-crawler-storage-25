"""Translated from lib/handlers/function_calls.js"""
from __future__ import annotations

import re
from types import SimpleNamespace

from depyo.ast_node import (
    ASTKwNamesMap,
    ASTObject,
    ASTTuple,
    ASTList,
    ASTName,
    ASTCall,
    ASTLoadBuildClass,
    ASTClass,
    ASTFunction,
    ASTBinary,
    ASTComprehension,
    ASTIteratorValue,
    ASTIterBlock,
    ASTBlock,
    ASTReturn,
    ASTStore,
    ASTKeyword,
    ASTMap,
    ASTMapUnpack,
    ASTSubscr,
    ASTTypeAlias,
    ASTNone,
    ASTNamedExpr,
)
from depyo.handlers._util import debug_log, debug_error


# CPython Include/internal/pycore_intrinsics.h
INTRINSIC_1 = SimpleNamespace(
    INVALID=0,
    PRINT=1,
    IMPORT_STAR=2,
    STOPITERATION_ERROR=3,
    ASYNC_GEN_WRAP=4,
    UNARY_POSITIVE=5,
    LIST_TO_TUPLE=6,
    TYPEVAR=7,
    PARAMSPEC=8,
    TYPEVARTUPLE=9,
    SUBSCRIPT_GENERIC=10,
    TYPEALIAS=11,
)

INTRINSIC_2 = SimpleNamespace(
    INVALID=0,
    PREP_RERAISE_STAR=1,
    TYPEVAR_WITH_BOUND=2,
    TYPEVAR_WITH_CONSTRAINTS=3,
    SET_FUNCTION_TYPE_PARAMS=4,
    SET_TYPEPARAM_DEFAULT=5,  # 3.13+
)

_QUOTE_RE = re.compile(r"^['\"]|['\"]$")
_DOT_DIGITS = re.compile(r"^\.\d+$")
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _to_kw_name(v):
    # Render kwarg keys as bare identifiers (foo=1), not string literals ("foo"=1).
    raw = None
    if v is not None:
        raw = getattr(v, 'Value', None)
        if raw is None:
            raw = getattr(v, 'name', None)
        if raw is None:
            raw = v
    name = raw if isinstance(raw, str) else str(raw)
    return ASTName(_QUOTE_RE.sub('', name))


def handleKwNamesA(self):
    astNode = ASTKwNamesMap()
    keys = self.code.Current.ConstantObject
    for idx in range(len(keys) - 1, -1, -1):
        astNode.add(keys[idx], self.dataStack.pop())

    astNode.line = self.code.Current.LineNo
    self.dataStack.append(astNode)


def handleCallA(self):
    handleInstrumentedCallA(self)


def handleCallFunctionA(self):
    handleInstrumentedCallA(self)


def handleInstrumentedCallKwA(self):
    # Instrumented CALL_KW behaves like CALL_KW.
    handleCallKwA(self)


def handleCallKwA(self):
    # Python 3.13 CALL_KW: (callable, self_or_null, args[oparg], kwnames -- res)
    # kwnames is a tuple of strings; the last len(kwnames) of args[] are the kw values.
    kwnamesNode = self.dataStack.pop()
    kwNamesList = []
    if isinstance(kwnamesNode, ASTObject):
        obj = kwnamesNode.object
        if (obj is not None
                and obj.ClassName in ('Py_Tuple', 'Py_SmallTuple')
                and isinstance(obj.Value, list)):
            kwNamesList = [_to_kw_name(v) for v in obj.Value]
    elif isinstance(kwnamesNode, ASTTuple):
        kwNamesList = [_to_kw_name(v) for v in (kwnamesNode.values or [])]

    totalArgs = self.code.Current.Argument
    kwcount = len(kwNamesList)
    pcount = max(0, totalArgs - kwcount)

    kwparamList = []
    for i in range(kwcount - 1, -1, -1):
        value = self.dataStack.pop()
        kwparamList.insert(0, {'key': kwNamesList[i], 'value': value})

    pparamList = []
    for i in range(pcount):
        pparamList.insert(0, self.dataStack.pop())

    func = self.dataStack.pop()
    if func is None and len(self.dataStack) > 0:
        func = self.dataStack.pop()
    elif len(self.dataStack) > 0 and self.dataStack.top() is None:
        self.dataStack.pop()

    callNode = ASTCall(func, pparamList, kwparamList)
    callNode.line = self.code.Current.LineNo
    self.dataStack.append(callNode)


def handleEnterExecutorA(self):
    # 3.14 ENTER_EXECUTOR: instrumentation hook, ignore for decompilation.
    debug_log(f"[ENTER_EXECUTOR] arg={self.code.Current.Argument} at offset {self.code.Current.Offset}")


def handleInstrumentedCallA(self):
    kwparams = (self.code.Current.Argument & 0xFF00) >> 8
    pparams = (self.code.Current.Argument & 0xFF)
    kwparamList = []
    pparamList = []

    # This CALL invokes __build_class__ iff a LoadBuildClass marker sits on the
    # stack at exactly the depth this CALL will consume down to. Otherwise a
    # nested CALL (e.g. `type(Y)` in `class X(type(Y)):`) will falsely trigger
    # the build-class branch because LoadBuildClass is still somewhere below.
    #
    # Stack layout (bottom → top) varies by version:
    #   pre-3.6 CALL_FUNCTION:  [LBC, fn, name, ...bases, k1,v1, ...]; LBC at pparams + 2*kwparams
    #   3.6+ CALL_FUNCTION:     [LBC, fn, name, ...bases];             LBC at pparams
    #   3.11/3.12 CALL:         [NULL, LBC, fn, name, ...bases];       LBC at pparams
    #     (PUSH_NULL emitted before LOAD_BUILD_CLASS, NULL below LBC)
    #   3.13+ CALL:             [LBC, NULL, fn, name, ...bases];       LBC at pparams + 1
    #     (LOAD_BUILD_CLASS emitted before PUSH_NULL, NULL above LBC; peel in pop loop)
    def stackHas(d):
        idx = len(self.dataStack) - 1 - d
        return idx >= 0 and isinstance(self.dataStack[idx], ASTLoadBuildClass)

    loadBuildClassFound = False
    if self.object.Reader.versionCompare(3, 6) >= 0:
        loadBuildClassFound = stackHas(pparams) or stackHas(pparams + 1)
    else:
        loadBuildClassFound = stackHas(pparams + 2 * kwparams)

    if loadBuildClassFound:
        bases = []
        lbcKwparamList = []
        nbases = max(0, pparams - 2)

        if self.object.Reader.versionCompare(3, 6) < 0:
            # Pre-3.6: kwargs are alternating key/value pairs on stack.
            for i in range(kwparams):
                value = self.dataStack.pop()
                key = self.dataStack.pop()
                lbcKwparamList.insert(0, {'key': key, 'value': value})
            for i in range(nbases):
                bases.insert(0, self.dataStack.pop())
        else:
            # 3.6+: pop exactly nbases items; kwargs flow via CALL_FUNCTION_KW/KW_NAMES.
            # Bases can be arbitrary expressions (ASTName, ASTBinary, ASTCall, ASTSubscr, …).
            for i in range(nbases):
                bases.insert(0, self.dataStack.pop())

        name = self.dataStack.pop()
        functionNode = self.dataStack.pop()
        loadbuild = self.dataStack.pop()
        # 3.11+: PUSH_NULL sits between __build_class__ and the function; peel it off.
        if loadbuild is None and isinstance(self.dataStack.top(), ASTLoadBuildClass):
            loadbuild = self.dataStack.pop()
        if isinstance(loadbuild, ASTLoadBuildClass):
            callNode = ASTCall(functionNode, [], lbcKwparamList)
            callNode.line = self.code.Current.LineNo
            classNode = ASTClass(callNode, ASTTuple(bases), name)
            classNode.line = self.code.Current.LineNo
            classNode.kwargs = lbcKwparamList
            self.dataStack.append(classNode)
            return

    if self.object.Reader.versionCompare(3, 11) >= 0:
        kwparams_map = self.dataStack.top()
        if isinstance(kwparams_map, ASTKwNamesMap):
            self.dataStack.pop()
            for kwParam in kwparams_map.values:
                kwparamList.insert(0, kwParam)
                kwparams -= 1
    else:
        for idx in range(kwparams):
            value = self.dataStack.pop()
            key = self.dataStack.pop()
            kwparamList.insert(0, {'key': key, 'value': value})
    skipCallNode = False
    for idx in range(pparams):
        param = self.dataStack.pop()
        if isinstance(param, ASTFunction):
            fun_code = param.code
            code_src = fun_code.object
            function_name = code_src.Name
            if function_name == "<lambda>":
                pparamList.insert(0, param)
            elif pparams == 1:
                # Decorator used
                decorator = self.dataStack.pop()
                param.add_decorator(decorator)
                # Decorating function and returning it back to data stack
                self.dataStack.append(param)
                skipCallNode = True
                break
        elif isinstance(param, ASTClass) and pparams == 1 and len(kwparamList) == 0:
            # Class decorator: decorator(class) — attach decorator and re-push class
            # so chained class decorators (e.g. @author("Me")\n@author("You")) unwind
            # naturally on the data stack.
            decorator = self.dataStack.pop()
            param.add_decorator(decorator)
            self.dataStack.append(param)
            skipCallNode = True
            break
        else:
            pparamList.insert(0, param)

    if skipCallNode:
        return

    func = self.dataStack.pop()
    # 3.11+ CALL convention: stack is [callable, self_or_null, args...].
    # We just popped the args; `func` is actually self_or_null, and the real callable is underneath.
    if self.code.Current.OpCodeID in (self.OpCodes.CALL_A, self.OpCodes.INSTRUMENTED_CALL_A):
        if func is None and len(self.dataStack) > 0:
            # Normal call: PUSH_NULL was self_or_null, real callable below.
            func = self.dataStack.pop()
        elif len(self.dataStack) > 0 and self.dataStack.top() is None:
            # Edge case: null sits one slot deeper (rare ordering). Drop it.
            self.dataStack.pop()
        elif isinstance(func, ASTBinary) and func.op == ASTBinary.BinOp.Attr:
            # Python 3.14 LOAD_SPECIAL pushes [self, method] for __enter__/__exit__ etc.;
            # the self below is consumed by the unbound special-method call.
            attrName = getattr(func.right, 'name', None) if func.right is not None else None
            if attrName in ('__enter__', '__exit__', '__aenter__', '__aexit__'):
                if len(self.dataStack) > 0:
                    self.dataStack.pop()
        elif len(self.dataStack) > 0:
            # Bound method / decorator pattern: self_or_null is non-null, so
            # the call is real_callable(func, *args). Pop the real callable and
            # promote `func` to the first positional arg.
            below = self.dataStack.top()
            if below is not None and not isinstance(below, ASTLoadBuildClass):
                realCallable = self.dataStack.pop()
                # Decorator syntax: single ASTFunction arg with a real name → attach decorator,
                # push the decorated function back so the next STORE renders as `@decorator\ndef name(...)`.
                if (len(pparamList) == 0
                        and isinstance(func, ASTFunction)
                        and getattr(getattr(func.code, 'object', None), 'Name', None)
                        and func.code.object.Name != "<lambda>"):
                    func.add_decorator(realCallable)
                    self.dataStack.append(func)
                    return
                pparamList.insert(0, func)
                func = realCallable

    if isinstance(func, ASTFunction):
        compNames = {"<listcomp>", "<setcomp>", "<dictcomp>", "<genexpr>", "<generator expression>"}
        codeObj = getattr(func.code, 'object', None) if func.code is not None else None
        if codeObj is not None and not getattr(codeObj, 'SourceCode', None):
            from depyo.pyc_decompiler import PycDecompiler
            innerDecompiler = PycDecompiler(codeObj)
            try:
                codeObj.SourceCode = innerDecompiler.decompile()
            except Exception as e:
                import builtins
                g_cliArgs = getattr(builtins, 'g_cliArgs', None)
                if g_cliArgs is not None and getattr(g_cliArgs, 'strict', False):
                    raise
                self.errors.append({
                    'opcode': 'NESTED_DECOMPILE',
                    'codeObject': (codeObj.Name.toString() if getattr(codeObj, 'Name', None) is not None and hasattr(codeObj.Name, 'toString') else '<unknown>'),
                    'message': str(e),
                    'stack': getattr(e, '__traceback__', None),
                })
                debug_error(f"[CALL] Failed to decompile nested function: {e}")
            if innerDecompiler.errors:
                self.errors.extend(innerDecompiler.errors)

        source_code = getattr(codeObj, 'SourceCode', None) if codeObj is not None else None
        sc_list = getattr(source_code, 'list', None) if source_code is not None else None
        sourceTop = sc_list.top() if (sc_list is not None and hasattr(sc_list, 'top')) else None
        compNode = None
        if sc_list is not None and hasattr(sc_list, 'find'):
            compNode = sc_list.find(lambda n: isinstance(n, ASTComprehension))
        topType = type(sourceTop).__name__ if sourceTop is not None else 'null'
        code_name_dbg = None
        if codeObj is not None:
            code_name_dbg = getattr(codeObj, 'Name', None)
            if code_name_dbg is None:
                qn = getattr(codeObj, 'QualName', None)
                code_name_dbg = getattr(qn, 'Value', None) if qn is not None else None
        comp_name_dbg = type(compNode).__name__ if compNode is not None else 'null'
        debug_log(f"[CALL] func={code_name_dbg or '<?>'} sourceTop={topType} compNode={comp_name_dbg} hasSource={bool(source_code)} pparams={len(pparamList)}")
        # Name is usually a PythonObject (Py_String/Py_Unicode) but may already
        # be a raw str (JS .toString() on String is identity; Python str has no
        # .toString, so handle both).
        code_name_obj = getattr(codeObj, 'Name', None) if codeObj is not None else None
        if code_name_obj is None:
            codeName = ''
        elif hasattr(code_name_obj, 'toString'):
            codeName = code_name_obj.toString()
        else:
            codeName = str(code_name_obj)
        looksLikeComp = (codeName in compNames
                         or isinstance(sourceTop, ASTComprehension)
                         or isinstance(compNode, ASTComprehension)
                         or (isinstance(sourceTop, ASTReturn) and isinstance(sourceTop.value, ASTComprehension)))
        if looksLikeComp:
            resultNode = compNode or sourceTop
            if isinstance(resultNode, ASTReturn):
                resultNode = resultNode.value

            # Async comprehension: inner code uses GET_ANEXT instead of
            # FOR_ITER, so no ASTComprehension was produced. Reconstruct
            # from the decompiled source tree.
            if not isinstance(resultNode, ASTComprehension) and getattr(codeObj, 'SourceCode', None):
                yieldExpr = None
                loopVar = None
                # Seed async-ness from the code flags: async comprehensions and
                # async generator expressions carry CO_ASYNC_GENERATOR /
                # CO_COROUTINE on the inner code object, so use that as the
                # default in case the inner tree lacks an explicit AsyncFor
                # block (e.g. pre-3.8 async comprehensions use GET_ANEXT +
                # STORE instead of a FOR_ITER-driven iter block).
                flags = int(getattr(codeObj, 'Flags', 0) or 0)
                isAsyncLoop = bool(flags & ASTFunction.CodeFlags.CO_ASYNC_GENERATOR) or bool(flags & ASTFunction.CodeFlags.CO_COROUTINE)

                def searchNodes(nodes):
                    nonlocal yieldExpr, loopVar, isAsyncLoop
                    if not nodes:
                        return
                    for node in nodes:
                        if isinstance(node, ASTReturn) and node.rettype == ASTReturn.RetType.Yield and node.value:
                            yieldExpr = node.value
                        if isinstance(node, ASTStore) and not loopVar:
                            loopVar = node.dest
                        if isinstance(node, ASTIterBlock) and node.blockType in (ASTBlock.BlockType.AsyncFor, ASTBlock.BlockType.For):
                            if node.index:
                                loopVar = node.index
                                isAsyncLoop = (node.blockType == ASTBlock.BlockType.AsyncFor)
                            if getattr(node, 'nodes', None):
                                searchNodes(node.nodes)
                        if node is not None and getattr(node, 'nodes', None):
                            searchNodes(node.nodes)

                searchNodes(codeObj.SourceCode.list)
                # Listcomp/setcomp/dictcomp fallback: the yield expression was
                # saved by processListAppend/MAP_ADD when no For+comp block
                # existed.
                if not yieldExpr and getattr(codeObj, '_asyncCompYieldExpr', None):
                    yieldExpr = codeObj._asyncCompYieldExpr
                # In 3.8+ inline async comprehensions the STORE_FAST lands
                # inside a try/except block and disappears into the block
                # structure before reaching SourceCode.list. Scan the inner
                # code's instruction list: first STORE_* after GET_ANEXT is
                # the loop variable.
                if not loopVar:
                    innerOps = self.OpCodes(codeObj)
                    sawAnext = False
                    for op in (innerOps.Instructions or []):
                        if not op:
                            continue
                        if op.OpCodeID == self.OpCodes.GET_ANEXT:
                            sawAnext = True
                            continue
                        if sawAnext and op.OpCodeID in (self.OpCodes.STORE_FAST_A, self.OpCodes.STORE_NAME_A, self.OpCodes.STORE_DEREF_A):
                            name_obj = op.Name
                            # op.Name may already be a raw str (Python-port
                            # marshal readers deref the const pool for locals);
                            # only PythonObjects carry .toString().
                            if name_obj is None:
                                varName = ''
                            elif hasattr(name_obj, 'toString'):
                                varName = name_obj.toString()
                            else:
                                varName = str(name_obj)
                            if varName:
                                loopVar = ASTName(varName)
                                isAsyncLoop = True
                                break
                code_name_obj2 = getattr(codeObj, 'Name', None)
                if code_name_obj2 is None:
                    code_name_dbg2 = None
                elif hasattr(code_name_obj2, 'toString'):
                    code_name_dbg2 = code_name_obj2.toString()
                else:
                    code_name_dbg2 = str(code_name_obj2)
                yield_name = type(yieldExpr).__name__ if yieldExpr is not None else None
                loop_name = getattr(loopVar, 'name', None) if loopVar is not None else None
                debug_log(f"[CALL-RECONSTRUCT] {code_name_dbg2} yield={yield_name} loopVar={loop_name} isAsyncLoop={isAsyncLoop}")
                if yieldExpr and loopVar:
                    kind = ASTComprehension.GENERATOR
                    objName = code_name_dbg2 or ''
                    if 'listcomp' in objName:
                        kind = ASTComprehension.LIST
                    elif 'setcomp' in objName:
                        kind = ASTComprehension.SET
                    elif 'dictcomp' in objName:
                        kind = ASTComprehension.DICT
                    if kind == ASTComprehension.DICT and getattr(codeObj, '_asyncCompYieldKey', None):
                        comp = ASTComprehension(yieldExpr, codeObj._asyncCompYieldKey)
                    else:
                        comp = ASTComprehension(yieldExpr)
                    comp.kind = kind
                    genBlockType = ASTBlock.BlockType.AsyncFor if isAsyncLoop else ASTBlock.BlockType.For
                    gen = ASTIterBlock(genBlockType, 0, 0, ASTName('.0'))
                    gen.index = loopVar
                    gen.comprehension = True
                    comp.addGenerator(gen)
                    resultNode = comp

            # Map placeholder iter (.0) to actual argument for comprehensions.
            if resultNode is not None and getattr(resultNode, 'generators', None):
                iters_dbg = [(g.iter.codeFragment() if g.iter is not None and callable(getattr(g.iter, 'codeFragment', None)) else None) for g in resultNode.generators]
                debug_log(f"[CALL] iter placeholders: {iters_dbg}")
                for gen in resultNode.generators:
                    if isinstance(gen.iter, ASTName) and gen.iter.name and _DOT_DIGITS.match(gen.iter.name):
                        paramIdx = int(gen.iter.name[1:])
                        param = pparamList[paramIdx] if paramIdx < len(pparamList) else None
                        gen.iter = param.value if isinstance(param, ASTIteratorValue) else param
                        gen_iter_name = type(gen.iter).__name__ if gen.iter is not None else None
                        debug_log(f"[CALL] remapped iter .{paramIdx} -> {gen_iter_name}")
                    elif isinstance(gen.iter, ASTName) and gen.iter.name == "[outmost-iterable]":
                        # Py2.4 names the genexpr's first parameter `[outmost-iterable]`
                        param = pparamList[0] if pparamList else None
                        gen.iter = param.value if isinstance(param, ASTIteratorValue) else param

            if resultNode is not None:
                # Async listcomp/setcomp/dictcomp: the outer function
                # awaits the comprehension coroutine with GET_AWAITABLE +
                # LOAD_CONST None + YIELD_FROM. Skip these — the await is
                # implicit in the async comprehension syntax.
                if isinstance(resultNode, ASTComprehension) and resultNode.kind != ASTComprehension.GENERATOR:
                    nx1 = self.code.Next
                    nx2 = nx1.Next if nx1 is not None else None
                    nx3 = nx2.Next if nx2 is not None else None
                    if (nx1 is not None and nx2 is not None and nx3 is not None
                            and nx1.OpCodeID in (self.OpCodes.GET_AWAITABLE, self.OpCodes.GET_AWAITABLE_A)
                            and nx2.OpCodeID == self.OpCodes.LOAD_CONST_A
                            and nx3.OpCodeID == self.OpCodes.YIELD_FROM):
                        self.code.GoNext(3)
                self.dataStack.append(resultNode)
                return

    prev = self.code.Prev
    prev_source = (func.code.object.SourceCode if (isinstance(func, ASTFunction)
                                                    and getattr(func, 'code', None) is not None
                                                    and getattr(func.code, 'object', None) is not None
                                                    and getattr(func.code.object, 'SourceCode', None) is not None)
                   else None)
    prev_list = getattr(prev_source, 'list', None) if prev_source is not None else None
    if (prev is not None and prev.OpCodeID in (self.OpCodes.GET_ITER, self.OpCodes.GET_AITER)
            and isinstance(func, ASTFunction)
            and prev_list is not None and hasattr(prev_list, 'top')):
        ast = func.code.object.SourceCode.list.top()
        if not isinstance(ast, ASTKeyword):
            if isinstance(ast, ASTReturn):
                ast = ast.value
            if ast is not None and getattr(ast, 'generators', None):
                for gen in ast.generators:
                    if isinstance(gen.iter, ASTName) and _DOT_DIGITS.match(gen.iter.name or ''):
                        paramIdx = int(gen.iter.name[1:])
                        param = pparamList[paramIdx] if paramIdx < len(pparamList) else None
                        if isinstance(param, ASTIteratorValue):
                            param = param.value
                        gen.iter = param
                    elif isinstance(gen.iter, ASTName) and gen.iter.name == "[outmost-iterable]":
                        param = pparamList[0] if pparamList else None
                        if isinstance(param, ASTIteratorValue):
                            param = param.value
                        gen.iter = param
        self.dataStack.append(ast)
    else:
        # Python 3.14 with-statement pattern: when calling __enter__,
        # push the context manager (not the call) so STORE_* sets it as withBlock.expr
        if (getattr(self, '_py314WithCtxMgrForStore', None)
                and isinstance(func, ASTBinary)
                and func.op == ASTBinary.BinOp.Attr
                and getattr(func.right, 'name', None) == '__enter__'):
            self.dataStack.append(self._py314WithCtxMgrForStore)
            self._py314WithCtxMgrForStore = None
            return

        callNode = ASTCall(func, pparamList, kwparamList)
        callNode.line = self.code.Current.LineNo
        self.dataStack.append(callNode)


def handleCallFunctionVarA(self):
    variable = self.dataStack.pop()
    kwparams = (self.code.Current.Argument & 0xFF00) >> 8
    pparams = (self.code.Current.Argument & 0xFF)
    kwparamList = []
    pparamList = []
    for idx in range(kwparams):
        value = self.dataStack.pop()
        key = self.dataStack.pop()
        kwparamList.insert(0, {'key': key, 'value': value})
    for idx in range(pparams):
        pparamList.insert(0, self.dataStack.pop())
    func = self.dataStack.pop()

    callNode = ASTCall(func, pparamList, kwparamList)
    callNode.var = variable
    callNode.line = self.code.Current.LineNo
    self.dataStack.append(callNode)


def handleCallFunctionKwA(self):
    if self.object.Reader.versionCompare(3, 6) >= 0:
        # Py 3.6+: CALL_FUNCTION_KW(argc) — TOS is a tuple of kwarg names,
        # argc is total args, last len(names) are kwargs.
        kwnamesNode = self.dataStack.pop()
        kwNamesList = []
        if isinstance(kwnamesNode, ASTObject):
            obj = kwnamesNode.object
            if (obj is not None
                    and obj.ClassName in ('Py_Tuple', 'Py_SmallTuple')
                    and isinstance(obj.Value, list)):
                kwNamesList = [_to_kw_name(v) for v in obj.Value]
        elif isinstance(kwnamesNode, ASTTuple):
            kwNamesList = [_to_kw_name(v) for v in (kwnamesNode.values or [])]

        totalArgs = self.code.Current.Argument
        kwcount = len(kwNamesList)
        pcount = max(0, totalArgs - kwcount)

        kwparamList = []
        for i in range(kwcount - 1, -1, -1):
            value = self.dataStack.pop()
            kwparamList.insert(0, {'key': kwNamesList[i], 'value': value})

        pparamList = []
        for i in range(pcount):
            pparamList.insert(0, self.dataStack.pop())

        func = self.dataStack.pop()

        # 3.6+ class with kwargs uses CALL_FUNCTION_KW:
        #   LOAD_BUILD_CLASS / MAKE_FUNCTION / LOAD_CONST name / <bases>
        #   / LOAD_CONST (kwarg_names_tuple) / CALL_FUNCTION_KW argc
        # pparamList is [body_func, class_name, ...bases]; kwparamList carries
        # the class kwargs (metaclass, **__init_subclass__ kwargs, ...).
        if isinstance(func, ASTLoadBuildClass) and len(pparamList) >= 2:
            functionNode = pparamList[0]
            nameNode = pparamList[1]
            bases = pparamList[2:]
            classCall = ASTCall(functionNode, [], kwparamList)
            classCall.line = self.code.Current.LineNo
            classNode = ASTClass(classCall, ASTTuple(bases), nameNode)
            classNode.line = self.code.Current.LineNo
            classNode.kwargs = kwparamList
            self.dataStack.append(classNode)
            return

        callNode = ASTCall(func, pparamList, kwparamList)
        callNode.line = self.code.Current.LineNo
        self.dataStack.append(callNode)
        return

    kw = self.dataStack.pop()
    kwparams = (self.code.Current.Argument & 0xFF00) >> 8
    pparams = (self.code.Current.Argument & 0xFF)
    kwparamList = []
    pparamList = []
    for idx in range(kwparams):
        value = self.dataStack.pop()
        key = self.dataStack.pop()
        kwparamList.insert(0, {'key': key, 'value': value})
    for idx in range(pparams):
        pparamList.insert(0, self.dataStack.pop())
    func = self.dataStack.pop()

    callNode = ASTCall(func, pparamList, kwparamList)
    callNode.kw = kw
    callNode.line = self.code.Current.LineNo
    self.dataStack.append(callNode)


def handleCallFunctionVarKwA(self):
    kw = self.dataStack.pop()
    variable = self.dataStack.pop()
    kwparams = (self.code.Current.Argument & 0xFF00) >> 8
    pparams = (self.code.Current.Argument & 0xFF)
    kwparamList = []
    pparamList = []
    for idx in range(kwparams):
        value = self.dataStack.pop()
        key = self.dataStack.pop()
        kwparamList.insert(0, {'key': key, 'value': value})
    for idx in range(pparams):
        pparamList.insert(0, self.dataStack.pop())
    func = self.dataStack.pop()

    callNode = ASTCall(func, pparamList, kwparamList)
    callNode.kw = kw
    callNode.var = variable
    callNode.line = self.code.Current.LineNo
    self.dataStack.append(callNode)


def handleCallMethodA(self):
    pparamList = []
    for idx in range(self.code.Current.Argument):
        param = self.dataStack.pop()
        if isinstance(param, ASTFunction):
            fun_code = param.code
            code_src = fun_code.object
            function_name = getattr(code_src, 'name', None)
            if function_name == "<lambda>":
                pparamList.insert(0, param)
            else:
                # Decorator used
                decorNameNode = ASTName(function_name)
                storeNode = ASTStore(param, decorNameNode)
                storeNode.line = self.code.Current.LineNo
                self.curBlock.nodes.append(storeNode)

                pparamList.insert(0, decorNameNode)
        else:
            pparamList.insert(0, param)
    func = self.dataStack.pop()
    callNode = ASTCall(func, pparamList, [])
    callNode.line = self.code.Current.LineNo
    self.dataStack.append(callNode)


def handlePrecallA(self):
    pass


def handleBinaryCall(self):
    paramsTuple = self.dataStack.pop()
    func = self.dataStack.pop()
    params = []

    if isinstance(paramsTuple, ASTTuple):
        params = paramsTuple.values

    callNode = ASTCall(func, params)
    self.dataStack.append(callNode)


def mapKeysAreIdentifiers(mapNode):
    for entry in (mapNode.values or []):
        keyObj = entry.get('key') if isinstance(entry, dict) else getattr(entry, 'key', None)
        keyObj_obj = getattr(keyObj, 'object', None) if keyObj is not None else None
        cls = getattr(keyObj_obj, 'ClassName', None) if keyObj_obj is not None else None
        if cls not in ('Py_String', 'Py_Unicode'):
            return False
        s = keyObj.object.toString()
        if not _IDENT_RE.match(s):
            return False
    return True


def handleCallFunctionExA(self):
    # CPython 3.6+: oparg & 0x01 means kwargs mapping is on TOS; the positional
    # tuple and the callable are ALWAYS popped regardless of the flag.
    flags = self.code.Current.Argument
    kwparams = []
    pparams = []
    varArg = None
    kwSpread = None
    kwSingle = None
    if flags & 0x01:  # **kwargs
        kw = self.dataStack.pop()
        if isinstance(kw, ASTMapUnpack):
            # Py 3.6+ f(**a, **b) path: preserve individual ** sources for rendering.
            kwSpread = kw
        elif isinstance(kw, ASTMap):
            if mapKeysAreIdentifiers(kw):
                kwparams = kw.values
            else:
                # Non-identifier keys (e.g. '"', 'with space') must render as **{...}.
                kwSingle = kw
        elif (kw is not None
              and getattr(kw, 'object', None) is not None
              and getattr(kw.object, 'ClassName', None) == "Py_Dict"
              and getattr(kw.object, 'Value', None) is not None):
            kwparams = [{'key': ASTObject(entry.key), 'value': ASTObject(entry.value)}
                        for entry in kw.object.Value]
        else:
            # Single **dict argument where dict is a name/expression (not literal).
            kwSingle = kw
    args = self.dataStack.pop()
    if isinstance(args, (ASTTuple, ASTList)):
        pparams = args.values
    else:
        # *args as a non-literal expression (e.g. f(*tup_name, **kw)).
        varArg = args
    func = self.dataStack.pop()
    callNode = ASTCall(func, pparams, kwparams)
    if varArg:
        callNode.var = varArg
    if kwSpread:
        callNode.kw = kwSpread
    elif kwSingle:
        callNode.kw = kwSingle
    callNode.line = self.code.Current.LineNo
    self.dataStack.append(callNode)


def handleCallIntrinsic1(self):
    # Python 3.12+ CALL_INTRINSIC_1 opcode
    # Calls built-in intrinsic functions (argument specifies which)

    arg = self.dataStack.pop()

    arg_name = type(arg).__name__ if arg is not None else None
    debug_log(f"[CALL_INTRINSIC_1] intrinsic={self.code.Current.Argument}, arg={arg_name}")

    # PEP 695 type statement wraps tuple(name, qualname, type-fn)
    if self.code.Current.Argument == INTRINSIC_1.TYPEALIAS and isinstance(arg, ASTTuple):
        values = arg.values or []
        aliasName = None
        if values:
            v0 = values[0]
            if v0 is not None:
                obj = getattr(v0, 'object', None)
                if obj is not None and getattr(obj, 'Value', None) is not None:
                    aliasName = obj.Value
                elif getattr(v0, 'name', None) is not None:
                    aliasName = v0.name
                else:
                    cf = getattr(v0, 'codeFragment', None)
                    if callable(cf):
                        aliasName = cf()
        typeFunc = values[2] if len(values) > 2 else None

        def extractTypeValue(fn):
            if not isinstance(fn, ASTFunction):
                return fn
            body = getattr(getattr(fn.code, 'object', None), 'SourceCode', None) if fn.code is not None else None
            if body is not None and getattr(body, 'list', None) is not None and len(body.list) > 0:
                first = body.list[0]
                if isinstance(first, ASTReturn):
                    return first.value
                return first
            return fn

        typeValue = extractTypeValue(typeFunc)
        if isinstance(typeValue, ASTSubscr) and isinstance(typeValue.key, ASTTuple):
            typeValue.key.m_requireParens = False
        aliasNode = ASTTypeAlias(aliasName, typeValue)
        aliasNode.line = self.code.Current.LineNo
        self.dataStack.append(aliasNode)
        return

    # Default: preserve the argument as result
    if arg:
        self.dataStack.append(arg)


def handleCallIntrinsic2(self):
    # Python 3.12+ CALL_INTRINSIC_2 opcode
    # Calls intrinsics with 2 arguments

    debug_log(f"[CALL_INTRINSIC_2] intrinsic={self.code.Current.Argument}")

    argB = self.dataStack.pop()
    argA = self.dataStack.pop()
    args = [argA, argB]

    # PREP_RERAISE_STAR equivalent in 3.12+.
    # Do not emit; mark to skip the following conditional jump.
    if self.code.Current.Argument == INTRINSIC_2.PREP_RERAISE_STAR:
        self.ignoreNextConditional = True
        self.cleanupStackDepth = len(self.dataStack) + 1  # after we push a placeholder
        self.dataStack.append(ASTNone())
        self.inExceptionGroup = True
        return

    # SET_FUNCTION_TYPE_PARAMS — build generic function from
    # type parameters tuple + function
    if self.code.Current.Argument == INTRINSIC_2.SET_FUNCTION_TYPE_PARAMS:
        funcNode = next((a for a in args if isinstance(a, ASTFunction)), None)
        typeArg = next((a for a in args if isinstance(a, (ASTTuple, ASTList))), None)
        if funcNode is not None and typeArg is not None:
            params = []
            for v in (typeArg.values or []):
                # COPY/STORE_FAST inside the wrapper wraps each typevar in a
                # walrus ASTNamedExpr(name := typevar). Unwrap to reach the
                # underlying typevar (which carries pepDefault for PEP 696).
                source = v
                if isinstance(v, ASTNamedExpr):
                    source = v.value
                name = None
                if isinstance(v, ASTNamedExpr) and v.target is not None and getattr(v.target, 'name', None):
                    name = v.target.name
                elif isinstance(source, ASTName):
                    name = source.name
                elif (source is not None
                      and getattr(source, 'object', None) is not None
                      and getattr(source.object, 'Value', None) is not None):
                    name = source.object.Value
                else:
                    cf = getattr(source, 'codeFragment', None) if source is not None else None
                    frag = cf() if callable(cf) else None
                    name = (str(frag) if frag is not None else 'T')
                if source is not None and getattr(source, 'pepDefault', None) is not None:
                    params.append({'name': name, 'default': source.pepDefault})
                else:
                    params.append(name)
            funcNode.typeParams = params
            self.dataStack.append(funcNode)
            return

    # SET_TYPEPARAM_DEFAULT (PEP 696, 3.13+)
    # Stack: [..., typevar, default_fn] → [..., typevar_with_default]
    # The default wrapper is a zero-arg function whose return value is the default.
    if self.code.Current.Argument == INTRINSIC_2.SET_TYPEPARAM_DEFAULT:
        defaultFn = argB
        typevar = argA
        defaultValue = None

        def extractReturn(body):
            lst = getattr(body, 'list', None) if body is not None else None
            if lst is None:
                return None
            for i in range(len(lst) - 1, -1, -1):
                if isinstance(lst[i], ASTReturn) and lst[i].value:
                    return lst[i].value
            return None

        if isinstance(defaultFn, ASTFunction):
            src = getattr(getattr(defaultFn.code, 'object', None), 'SourceCode', None) if defaultFn.code is not None else None
            defaultValue = extractReturn(src)
        elif (isinstance(defaultFn, ASTObject)
              and defaultFn.object is not None
              and defaultFn.object.ClassName in ('Py_CodeObject', 'Py_CodeObject2')):
            try:
                from depyo.pyc_decompiler import PycDecompiler
                dd = PycDecompiler(defaultFn.object)
                body = dd.decompile()
                defaultFn.object.SourceCode = body
                if dd.errors:
                    self.errors.extend(dd.errors)
                defaultValue = extractReturn(body)
            except Exception:
                pass  # bare typevar
        if typevar is not None and defaultValue is not None:
            typevar.pepDefault = defaultValue
        if typevar is not None:
            self.dataStack.append(typevar)
        return

    # Default: preserve the left argument to avoid stack underflow
    if argA is not None:
        self.dataStack.append(argA)


def handleCallIntrinsic1A(self):
    # Python 3.12+ CALL_INTRINSIC_1_A opcode (wrapper)
    handleCallIntrinsic1(self)


def handleCallIntrinsic2A(self):
    # Python 3.12+ CALL_INTRINSIC_2_A opcode (wrapper)
    handleCallIntrinsic2(self)
