"""Translated from lib/handlers/load_store_names.js"""
from __future__ import annotations

from depyo.python_object import PythonObject
from depyo.ast_node import (
    ASTDelete,
    ASTBinary,
    ASTName,
    ASTImport,
    ASTObject,
    ASTNone,
    ASTTuple,
    ASTLocals,
    ASTCall,
    ASTWithBlock,
    ASTChainStore,
    ASTStore,
    ASTAnnotatedVar,
    ASTBlock,
    ASTList,
    ASTNamedExpr,
    ASTFunction,
    ASTCondBlock,
)
from depyo.handlers._util import debug_log, debug_error


def handleDeleteAttrA(self):
    name = self.dataStack.pop()
    node = ASTDelete(ASTBinary(name, ASTName(self.code.Current.Name), ASTBinary.BinOp.Attr))
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleDeleteGlobalA(self):
    self.object.Globals.add(self.code.Current.Name)
    handleDeleteNameA(self)


def handleDeleteNameA(self):
    varname = self.code.Current.Name or ""

    if not len(varname):
        return

    if len(varname) >= 2 and varname.startswith('_['):
        # Don't show deletes that are a result of list comps.
        # Clear the _listCompAppendRefs cache so the next FOR_ITER outside
        # this listcomp doesn't mistake itself for one.
        if getattr(self, '_listCompAppendRefs', None):
            self._listCompAppendRefs.pop(varname, None)
        return

    node = ASTDelete(ASTName(varname))
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleDeleteFastA(self):
    nameVal = self.code.Current.Name or ""
    if not len(nameVal):
        return
    nameNode = ASTName(nameVal)

    if nameNode.name.startswith('_['):
        # Don't show deletes that are a result of list comps.
        # Clear the _listCompAppendRefs cache so the next FOR_ITER outside
        # this listcomp doesn't mistake itself for one.
        if getattr(self, '_listCompAppendRefs', None):
            self._listCompAppendRefs.pop(nameNode.name, None)
        return

    node = ASTDelete(nameNode)
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleDeleteDerefA(self):
    freeName = self.code.Current.FreeName or ""
    if not freeName:
        return
    node = ASTDelete(ASTName(freeName))
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleLoadAttrA(self):
    name = self.dataStack.top()
    if not isinstance(name, ASTImport):
        self.dataStack.pop()

        if self.object.Reader.versionCompare(3, 12) >= 0:
            if self.code.Current.Argument & 1:
                # Changed in version 3.12:
                # If the low bit of namei is set, then a null or self is pushed to the stack
                # before the attribute or unbound method respectively.
                self.dataStack.append(None)
            self.code.Current.Argument >>= 1

        node = ASTBinary(name, ASTName(self.code.Current.Name), ASTBinary.BinOp.Attr)
        node.line = self.code.Current.LineNo
        self.dataStack.append(node)


def handleLoadConstA(self):
    constantObject = ASTObject(self.code.Current.ConstantObject)
    constantObject.line = self.code.Current.LineNo

    co_obj = constantObject.object
    if co_obj is not None and getattr(co_obj, 'ClassName', None) == 'Py_String':
        dbg_value = co_obj.Value
    else:
        dbg_value = getattr(co_obj, 'ClassName', None)
    debug_log(f"[LOAD_CONST] offset={self.code.Current.Offset}, arg={self.code.Current.Argument}, value={dbg_value}")

    if constantObject.object is None or constantObject.object.ClassName == "Py_None":
        self.dataStack.append(ASTNone())
    elif (constantObject.object.ClassName in ("Py_Tuple", "Py_SmallTuple")
            and constantObject.object.Value.empty()):
        node = ASTTuple([])
        node.line = self.code.Current.LineNo
        self.dataStack.append(node)
    else:
        self.dataStack.append(constantObject)


def handleLoadDerefA(self):
    processLoadDeref(self)


def handleLoadClassderefA(self):
    processLoadDeref(self)


def processLoadDeref(self):
    varName = self.code.Current.FreeName or ""
    if len(varName) >= 2 and varName.startswith('_['):
        cached = (self._listCompAppendRefs or {}).get(varName) if getattr(self, '_listCompAppendRefs', None) else None
        if cached:
            self.dataStack.append(cached)
        return
    node = ASTName(varName)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleLoadFastA(self):
    varName = self.code.Current.Name or ""
    if len(varName) >= 2 and varName.startswith('_['):
        # Pre-LIST_APPEND comprehensions (Python 2.3) cache `list.append` in
        # the synthetic `_[N]` slot and re-load it to call per iteration.
        # Replay the stored expression so CALL_FUNCTION has a real callable
        # instead of falling through to `##ERROR##`.
        cached = (self._listCompAppendRefs or {}).get(varName) if getattr(self, '_listCompAppendRefs', None) else None
        if cached:
            self.dataStack.append(cached)
        return

    node = ASTName(varName)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleLoadFastCheckA(self):
    # Python 3.12+: same semantics as LOAD_FAST for reconstruction.
    handleLoadFastA(self)


def handleLoadGlobalA(self):
    varName = self.code.Current.Name or ""
    if len(varName) >= 2 and varName.startswith('_['):
        cached = (self._listCompAppendRefs or {}).get(varName) if getattr(self, '_listCompAppendRefs', None) else None
        if cached:
            self.dataStack.append(cached)
        return

    if self.object.Reader.versionCompare(3, 11) >= 0:
        # Loads the global named co_names[namei>>1] onto the self.dataStack.
        if self.code.Current.Argument & 1:
            # Changed in version 3.11:
            # If the low bit of "NAMEI" (self.code.Current.Argument) is set,
            # then a null is pushed to the stack before the global variable.
            self.dataStack.append(None)
        self.code.Current.Argument >>= 1
    node = ASTName(varName)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleLoadFromDictOrDerefA(self):
    # Python 3.12+: LOAD_FROM_DICT_OR_DEREF consumes the locals dict from TOS
    # (pushed by the preceding LOAD_LOCALS) and resolves the name against it,
    # falling back to the deref cell. The argument is a localsplus index into
    # [VarNames | CellVars | FreeVars] — use FreeName which the opcode reader
    # resolved via that table.
    if isinstance(self.dataStack.top(), ASTLocals):
        self.dataStack.pop()
    varName = self.code.Current.FreeName or self.code.Current.Name or ""
    if not len(varName):
        return
    node = ASTName(varName)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleLoadLocals(self):
    node = ASTLocals()
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleStoreLocals(self):
    self.dataStack.pop()


def handleLoadMethodA(self):
    # Behave like LOAD_ATTR
    name = self.dataStack.pop()
    node = ASTBinary(name, ASTName(self.code.Current.Name), ASTBinary.BinOp.Attr)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleLoadNameA(self):
    varName = self.code.Current.Name or ""
    if len(varName) >= 2 and varName.startswith('_['):
        cached = (self._listCompAppendRefs or {}).get(varName) if getattr(self, '_listCompAppendRefs', None) else None
        if cached:
            self.dataStack.append(cached)
        return
    node = ASTName(varName)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


# Python 3.14 LOAD_SPECIAL oparg-to-method mapping (from pycore_ceval.h)
SPECIAL_METHOD_NAMES = {
    0: "__enter__",
    1: "__exit__",
    2: "__aenter__",
    3: "__aexit__",
}


def handleLoadSpecialA(self):
    # Python 3.14 LOAD_SPECIAL: oparg indexes into special method table.
    # Per CPython docs: pushes (method, self) pair onto stack.
    # - For methods: [type(obj).__xxx__, obj]
    # - For non-methods: [obj.__xxx__, NULL]
    obj = self.dataStack.pop()
    oparg = self.code.Current.Argument or 0
    attrName = SPECIAL_METHOD_NAMES.get(oparg, f"__special_{oparg}__")
    if not obj:
        obj = ASTName("##MISSING##")

    # For __exit__ (oparg 1): save the context manager expression for with-block
    # This is called BEFORE __enter__ in 3.14 bytecode pattern
    if oparg == 1:
        self._py314WithContextMgr = obj

    # For __enter__ (oparg 0): create with-block using saved context manager
    if oparg == 0:
        # Get the saved context manager from when __exit__ was loaded
        ctxMgr = getattr(self, '_py314WithContextMgr', None) or obj

        # Find with block end from exception table
        withEnd = self.code.LastOffset
        exceptionTable = self.object.ExceptionTable or []
        currentOffset = self.code.Current.Offset

        for entry in exceptionTable:
            if entry.start > currentOffset and entry.start <= currentOffset + 20:
                withEnd = entry.end or withEnd
                entry._isWithStatement = True
                break

        # Create the WITH block (don't set expr - let STORE do it via _py314WithCtxMgrForStore)
        withBlock = ASTWithBlock(currentOffset, withEnd)

        # Push the with block onto the block stack
        self.blocks.append(withBlock)
        self.curBlock = self.blocks.top()

        # Save context manager for CALL to push to stack (so STORE gets it as valueNode)
        self._py314WithCtxMgrForStore = ctxMgr

        # Clear the temporary from __exit__
        self._py314WithContextMgr = None

    method = ASTBinary(obj, ASTName(attrName), ASTBinary.BinOp.Attr)
    method.line = self.code.Current.LineNo
    # Push self_or_null and callable to match CALL convention:
    # Stack layout for CALL: [self_or_null, callable, args...]
    # For method from LOAD_SPECIAL: self_or_null=obj, callable=method
    self.dataStack.append(obj)     # self_or_null (TOS-1 for CALL)
    self.dataStack.append(method)  # callable (TOS for CALL pops this first)


def handleLoadSuperAttrA(self):
    # Python 3.12+ LOAD_SUPER_ATTR uses flags in argument to encode self/null.
    # Treat as attribute access on super(): super().<name>
    attr = ASTName(self.code.Current.Name or "")
    superCall = ASTCall(ASTName("super"), [], [])
    node = ASTBinary(superCall, attr, ASTBinary.BinOp.Attr)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleLoadSuperMethodA(self):
    # Similar to LOAD_SUPER_ATTR; represent as super().<name>
    handleLoadSuperAttrA(self)


def handleLoadZeroSuperAttrA(self):
    # Zero-cost variants; reuse super attr logic.
    handleLoadSuperAttrA(self)


def handleLoadZeroSuperMethodA(self):
    handleLoadSuperAttrA(self)


def handleStoreAttrA(self):
    if self.unpack:
        name = self.dataStack.pop()
        attrNode = ASTBinary(name, ASTName(self.code.Current.Name), ASTBinary.BinOp.Attr)

        tup = self.dataStack.top()
        if isinstance(tup, ASTTuple):
            tup.add(attrNode)
        else:
            debug_error("Something TERRIBLE happened!\n")

        self.unpack -= 1
        if self.unpack <= 0:
            self.dataStack.pop()
            seqNode = self.dataStack.pop()
            if isinstance(seqNode, ASTChainStore):
                seqNode.line = self.code.Current.LineNo
                self.append_to_chain_store(seqNode, tup)
            else:
                node = ASTStore(seqNode, tup)
                node.line = self.code.Current.LineNo
                self.curBlock.append(node)
    else:
        name = self.dataStack.pop()
        value = self.dataStack.pop()
        attrNode = ASTBinary(name, ASTName(self.code.Current.Name), ASTBinary.BinOp.Attr)
        if isinstance(value, ASTChainStore):
            self.append_to_chain_store(value, attrNode)
        else:
            node = ASTStore(value, attrNode)
            node.line = self.code.Current.LineNo
            self.curBlock.append(node)


def handleStoreDerefA(self):
    if self.unpack:
        nameNode = ASTName(self.code.Current.FreeName)
        tupleNode = self.dataStack.top()
        if isinstance(tupleNode, ASTTuple):
            tupleNode.add(nameNode)
        else:
            debug_error("Something TERRIBLE happened!\n")

        self.unpack -= 1
        if self.unpack <= 0:
            self.dataStack.pop()
            seqNode = self.dataStack.pop()

            if isinstance(seqNode, ASTChainStore):
                seqNode.line = self.code.Current.LineNo
                self.append_to_chain_store(seqNode, tupleNode)
            else:
                node = ASTStore(seqNode, tupleNode)
                node.line = self.code.Current.LineNo
                self.curBlock.append(node)
    else:
        nameNode = ASTName(self.code.Current.FreeName)

        # Closure-captured for-loop variable: STORE_DEREF to a cell var while an
        # uninitialized For block is on the stack means this is the loop index,
        # not an assignment. Py 3.0 classes with decorators closing over the
        # loop variable use this pattern (STORE_DEREF for the captured name,
        # STORE_FAST for the class afterwards).
        parentForBlock = None
        for i in range(len(self.blocks) - 1, -1, -1):
            blk = self.blocks[i]
            if (blk.blockType in (ASTBlock.BlockType.For, ASTBlock.BlockType.AsyncFor)
                    and not blk.inited):
                parentForBlock = blk
                break
        if parentForBlock:
            parentForBlock.index = nameNode
            parentForBlock.init()
            return

        valueNode = self.dataStack.pop()

        if isinstance(valueNode, ASTChainStore):
            self.append_to_chain_store(valueNode, nameNode)
        else:
            node = ASTStore(valueNode, nameNode)
            node.line = self.code.Current.LineNo
            self.curBlock.append(node)


def handleStoreFastA(self):
    processStore(self)


def handleStoreGlobalA(self):
    processStore(self)


def handleStoreNameA(self):
    processStore(self)


def handleStoreAnnotationA(self):
    # Python 3.6 only: pops the annotation type and stores it under
    # __annotations__[name]. The variable name is the opcode argument.
    # Patterns:
    #   `x: int`        → LOAD_NAME int ; STORE_ANNOTATION x
    #   `x: int = 1`    → LOAD_CONST 1 ; STORE_NAME x ; LOAD_NAME int ; STORE_ANNOTATION x
    annType = self.dataStack.pop()
    varName = self.code.Current.Name or ""
    nameNode = ASTName(varName)

    last = self.curBlock.nodes.top()
    if (isinstance(last, ASTStore)
            and isinstance(last.dest, ASTName)
            and last.dest.name == varName):
        # Combine prior `x = value` with annotation → `x: int = value`
        annotated = ASTAnnotatedVar(nameNode, annType)
        annotated.line = self.code.Current.LineNo
        last.dest = annotated
    else:
        # Standalone annotation `x: int`
        annotated = ASTAnnotatedVar(nameNode, annType)
        annotated.line = self.code.Current.LineNo
        self.curBlock.append(annotated)


_UNDEFINED = object()


def processStore(self, nameOverride=_UNDEFINED):
    from depyo.handlers.misc_other import beginMatchCaseFromPattern

    currentName = nameOverride if nameOverride is not _UNDEFINED else self.code.Current.Name

    # Pattern matching: first capture expected bindings, then start case body
    if self.inMatchPattern:
        if shouldCaptureStoreInPattern(self.patternOps):
            self.patternOps.append({
                'type': 'STORE_FAST',
                'name': currentName,
            })
            return

        if beginMatchCaseFromPattern(self, {'reason': 'store'}):
            self.unpack = 0
            self.starPos = -1
            # Fall through to normal store handling now that case body started

    if currentName and (currentName == 'b' or currentName == 'i'):
        debug_log(f"[processStore] varName={currentName}, curBlock={self.curBlock.type_str}, inited={self.curBlock.inited}, unpack={self.unpack}")
        stack_desc = ' → '.join(f"[{i}]{b.type_str}(inited={b.inited})" for i, b in enumerate(self.blocks))
        debug_log(f"  Block stack: {stack_desc}")

    # Check if we're inside an uninitialized For/AsyncFor block (could be nested inside try/container)
    parentForBlock = None
    for i in range(len(self.blocks) - 1, -1, -1):
        blk = self.blocks[i]
        if (blk.blockType in (ASTBlock.BlockType.For, ASTBlock.BlockType.AsyncFor)
                and not blk.inited):
            parentForBlock = blk
            break

    if self.unpack:
        nameNode = ASTName(currentName)

        tupleNode = self.dataStack.top()
        if isinstance(tupleNode, ASTTuple):
            if self.starPos == 0:
                nameNode.name = '*' + nameNode.name
            self.starPos -= 1
            tupleNode.add(nameNode)
        else:
            debug_error("Something TERRIBLE happened!\n")

        self.unpack -= 1
        if self.unpack <= 0:
            self.dataStack.pop()
            seqNode = self.dataStack.pop()

            if parentForBlock:
                tuple_ = tupleNode
                if tuple_ is not None:
                    tuple_.requireParens = False
                parentForBlock.index = tupleNode
                parentForBlock.init()
            elif isinstance(seqNode, ASTChainStore):
                seqNode.line = self.code.Current.LineNo
                self.append_to_chain_store(seqNode, tupleNode)
            else:
                node = ASTStore(seqNode, tupleNode)
                node.line = self.code.Current.LineNo
                self.curBlock.append(node)
    else:
        varName = currentName or ""
        if len(varName) >= 2 and varName.startswith('_['):
            # Synthetic `_[N]` is CPython bookkeeping; never in real source.
            # Listcomp case: Py2.3 stores `list.append`, Py2.4-2.6 stores
            #   the list itself. Pop + cache so later LOAD can replay.
            # Pre-PEP-343 `with` (2.5+) also uses `_[N]` to park __exit__ /
            #   __enter__() result. Those are consumed by downstream opcodes
            #   walking the stack backwards — we must NOT pop in that case.
            # Heuristic: if stack top matches listcomp shape, swallow. Else
            # leave stack untouched so the with-handler's backward scan still
            # sees the real expressions.
            top = self.dataStack[len(self.dataStack) - 1] if len(self.dataStack) > 0 else None
            isListcompList = isinstance(top, ASTList)
            isListcompAppend = (isinstance(top, ASTBinary)
                                and top.op == ASTBinary.BinOp.Attr
                                and isinstance(top.right, ASTName)
                                and top.right.name == "append")
            if isListcompList or isListcompAppend:
                self.dataStack.pop()
                if getattr(self, '_listCompAppendRefs', None) is None:
                    self._listCompAppendRefs = {}
                self._listCompAppendRefs[varName] = top
            return

        # Return private names back to their original name
        class_prefix = "_" + varName
        if varName.startswith(class_prefix + "__"):
            # NOTE: preserves JS oddity — modifies ephemeral .value, not varName itself.
            # (Original JS: `varName.value = varName.substring(...)` is a no-op on string.)
            pass

        nameNode = ASTName(varName)
        nameNode.line = self.code.Current.LineNo

        # Handle walrus operator (named expression): (n := 10)
        if self.isWalrusOperator:
            valueNode = self.dataStack.pop()
            namedExpr = ASTNamedExpr(nameNode, valueNode)
            namedExpr.line = self.code.Current.LineNo
            self.dataStack.append(namedExpr)
            self.isWalrusOperator = False
            return

        if parentForBlock:
            if parentForBlock.blockType == ASTBlock.BlockType.AsyncFor:
                debug_log(f"[processStore] Setting AsyncFor index to: {varName}")
            parentForBlock.index = nameNode
            parentForBlock.init()
        else:
            valueNode = self.dataStack.pop()
            # DUP_TOP for chain assign leaves [V, V, ChainStore] on the
            # stack, so the ChainStore is popped here as `valueNode` rather
            # than being the second-from-top importNode checked below.
            if isinstance(valueNode, ASTChainStore):
                self.dataStack.pop()  # consume the extra duplicate V
                self.append_to_chain_store(valueNode, nameNode)
                prev = self.code.Prev
                prev_op = prev.OpCodeID if prev is not None else None
                if prev_op not in (self.OpCodes.DUP_TOP, self.OpCodes.COPY_A):
                    # Terminal store — commit chainstore to block and
                    # clear the copy append_to_chain_store just pushed.
                    if self.dataStack.top() is valueNode:
                        self.dataStack.pop()
                    self.curBlock.append(valueNode)
                return
            importNode = self.dataStack.top()
            if isinstance(importNode, ASTImport):
                storeNode = ASTStore(valueNode, nameNode)
                storeNode.line = self.code.Current.LineNo
                add_store = getattr(importNode, 'add_store', None)
                if callable(add_store):
                    add_store(storeNode)
                return
            elif isinstance(importNode, ASTChainStore):
                # fall through after reusing valueNode
                self.dataStack.pop()  # remove chain store from stack
                self.append_to_chain_store(importNode, nameNode)
                prev = self.code.Prev
                if prev is None or prev.OpCodeID != self.OpCodes.DUP_TOP:
                    self.curBlock.append(importNode)
                return
            elif (self.curBlock.blockType == ASTBlock.BlockType.With
                    and not self.curBlock.inited):
                self.curBlock.expr = valueNode
                self.curBlock.var = nameNode
                self.curBlock.init()
                return

            if not valueNode:
                valueNode = ASTNone()
            if isinstance(valueNode, ASTFunction) and not valueNode.code.object.SourceCode:
                from depyo.pyc_decompiler import PycDecompiler
                decompiler = PycDecompiler(valueNode.code.object)
                valueNode.code.object.SourceCode = decompiler.decompile()
                if decompiler.errors:
                    self.errors.extend(decompiler.errors)
            lastBlockNode = self.curBlock.nodes.top()
            if (isinstance(lastBlockNode, ASTCondBlock)
                    and len(lastBlockNode.nodes) == 0
                    and self.code.Current.LineNo == lastBlockNode.line
                    and lastBlockNode.line == valueNode.line):
                valueNode = ASTBinary(
                    lastBlockNode.condition,
                    valueNode,
                    ASTBinary.BinOp.LogicalOr if lastBlockNode.negative else ASTBinary.BinOp.LogicalAnd,
                )
                self.curBlock.nodes.pop()
            node = ASTStore(valueNode, nameNode)
            node.line = self.code.Current.LineNo
            self.curBlock.append(node)

        if self.code.Current.OpCodeID == self.OpCodes.STORE_GLOBAL_A:
            self.object.Globals.add(nameNode.name)


def shouldCaptureStoreInPattern(patternOps):
    patternOps = patternOps or []
    expected = getExpectedPatternStoreCount(patternOps)
    if expected is None:
        return True
    recorded = sum(1 for op in patternOps if op.get('type') == 'STORE_FAST')
    return recorded < expected


def getExpectedPatternStoreCount(patternOps):
    matchClassOp = next((op for op in patternOps if op.get('type') == 'MATCH_CLASS'), None)
    if matchClassOp:
        attrNames = matchClassOp.get('attrNames')
        if attrNames and len(attrNames):
            return len(attrNames)
        count = matchClassOp.get('count')
        if count:
            return count
        return 0

    unpackOp = next((op for op in patternOps if op.get('type') == 'UNPACK_SEQUENCE'), None)
    if unpackOp:
        return unpackOp.get('count')

    return None


def handleReserveFastA(self):
    lst = []
    # JS: ConstantObject.Value.map(el => list[el.value] = el.key).
    # Py_Dict.Value is a list of {"key", "value"} dicts (see PythonObject.add),
    # so use dict-style access here.
    values = self.code.Current.ConstantObject.Value
    for el in values:
        key = el["key"] if isinstance(el, dict) else el.key
        val = el["value"] if isinstance(el, dict) else el.value
        idx = val.Value if hasattr(val, "Value") else val
        # Expand list as needed (sparse assignment mirrors JS array-by-index assign)
        while len(lst) <= idx:
            lst.append(None)
        lst[idx] = key
    self.dataStack.append(lst)


def handleLoadFastAndClearA(self):
    # Python 3.12+ inline comprehension save pattern:
    #   LOAD_FAST_AND_CLEAR var ; SWAP 2 ; BUILD_<LIST|SET|MAP> 0 ; SWAP 2 ; (GET_ITER)? ; FOR_ITER
    # CPython inlines comprehensions into the parent scope, saving the loop var
    # before and restoring after. Skip the save here so the comprehension stack
    # matches the simpler BUILD/SWAP/GET_ITER/FOR_ITER shape; END_FOR cleans up.
    next1 = self.code.Next
    next2 = next1.Next if next1 is not None else None
    next3 = next2.Next if next2 is not None else None
    isCompStart = (next1 is not None and next1.OpCodeID == self.OpCodes.SWAP_A and next1.Argument == 2
                   and next2 is not None and next2.OpCodeID in (self.OpCodes.BUILD_LIST_A, self.OpCodes.BUILD_SET_A, self.OpCodes.BUILD_MAP_A)
                   and next2.Argument == 0
                   and next3 is not None and next3.OpCodeID == self.OpCodes.SWAP_A and next3.Argument == 2)
    if isCompStart:
        self._inlineCompSavedVar = self.code.Current.Name
        self.code.GoNext()  # consume the SWAP 2 right after this op
        return
    handleLoadFastA(self)


def handleLoadFastBorrowA(self):
    # Python 3.14+ LOAD_FAST_BORROW - optimized LOAD_FAST
    handleLoadFastA(self)


def handleLoadFastBorrowLoadFastBorrowA(self):
    # Python 3.15+ packed borrow load (same encoding as LOAD_FAST_LOAD_FAST).
    handleLoadFastLoadFastA(self)


def handleLoadCommonConstantA(self):
    # Python 3.14+ common constants table
    mapping = {
        0: lambda: ASTNone(),
        1: lambda: ASTObject(PythonObject("Py_Bool", False)),
        2: lambda: ASTObject(PythonObject("Py_Bool", True)),
        3: lambda: ASTObject(PythonObject("Py_Int", -1)),
        4: lambda: ASTObject(PythonObject("Py_Int", 0)),
        5: lambda: ASTObject(PythonObject("Py_Int", 1)),
        6: lambda: ASTObject(PythonObject("Py_Int", 2)),
        7: lambda: ASTObject(PythonObject("Py_Int", 3)),
        8: lambda: ASTObject(PythonObject("Py_Int", 4)),
        9: lambda: ASTObject(PythonObject("Py_Int", 5)),
    }
    maker = mapping.get(self.code.Current.Argument)
    node = maker() if maker else ASTName(f"__common_const_{self.code.Current.Argument}__")
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleLoadFastLoadFastA(self):
    # CPython pushes local[hi] then local[lo]. For 3.13 the two halves are packed
    # nibble-wise in the argument (hi in upper nibble, lo in lower nibble);
    # older bytecode used bytes.
    packed = self.code.Current.Argument
    reader = getattr(self.object, 'Reader', None)
    isPackedNibbles = reader is not None and reader.versionCompare(3, 13) >= 0
    hiIdx = ((packed >> 4) & 0x0F) if isPackedNibbles else ((packed >> 8) & 0xFF)
    loIdx = (packed & 0x0F) if isPackedNibbles else (packed & 0xFF)
    varNames = (getattr(getattr(self.object, 'VarNames', None), 'Value', None)
                or getattr(getattr(getattr(getattr(self.object, 'code', None), 'object', None), 'VarNames', None), 'Value', None)
                or [])

    def _to_name(i):
        if i < len(varNames):
            v = varNames[i]
            if v is not None and hasattr(v, 'toString'):
                s = v.toString()
                if s:
                    return s
        return f"##var_{i}##"

    hiName = _to_name(hiIdx)
    loName = _to_name(loIdx)
    self.dataStack.append(ASTName(hiName))
    self.dataStack.append(ASTName(loName))


def handleStoreFastLoadFastA(self):
    # CPython: store TOS into local[hi], then push local[lo].
    packed = self.code.Current.Argument
    reader = getattr(self.object, 'Reader', None)
    isPackedNibbles = reader is not None and reader.versionCompare(3, 13) >= 0
    storeIdx = ((packed >> 4) & 0x0F) if isPackedNibbles else ((packed >> 8) & 0xFF)
    loadIdx = (packed & 0x0F) if isPackedNibbles else (packed & 0xFF)
    varNames = (getattr(getattr(self.object, 'VarNames', None), 'Value', None)
                or getattr(getattr(getattr(getattr(self.object, 'code', None), 'object', None), 'VarNames', None), 'Value', None)
                or [])

    def _to_name(i, prefix):
        if i < len(varNames):
            v = varNames[i]
            if v is not None and hasattr(v, 'toString'):
                s = v.toString()
                if s:
                    return s
        return f"##var_{i}##"

    storeName = _to_name(storeIdx, 'store')
    loadName = _to_name(loadIdx, 'load')

    if self.inMatchPattern and shouldCaptureStoreInPattern(self.patternOps):
        self.dataStack.pop()
        self.patternOps.append({'type': 'STORE_FAST', 'name': storeName})
        self.dataStack.append(ASTName(loadName))
        return

    # Route STORE through processStore so for-block target / unpack / chain-store work.
    processStore(self, storeName)
    self.dataStack.append(ASTName(loadName))


def handleStoreFastStoreFastA(self):
    # CPython: stack is [value2, value1] with value1 on TOS.
    # SETLOCAL(hi, value1); SETLOCAL(lo, value2).
    packed = self.code.Current.Argument
    reader = getattr(self.object, 'Reader', None)
    isPackedNibbles = reader is not None and reader.versionCompare(3, 13) >= 0
    hiIdx = ((packed >> 4) & 0x0F) if isPackedNibbles else ((packed >> 8) & 0xFF)
    loIdx = (packed & 0x0F) if isPackedNibbles else (packed & 0xFF)
    varNames = (getattr(getattr(self.object, 'VarNames', None), 'Value', None)
                or getattr(getattr(getattr(getattr(self.object, 'code', None), 'object', None), 'VarNames', None), 'Value', None)
                or [])

    def _to_name(i):
        if i < len(varNames):
            v = varNames[i]
            if v is not None and hasattr(v, 'toString'):
                s = v.toString()
                if s:
                    return s
        return f"##var_{i}##"

    hiName = _to_name(hiIdx)
    loName = _to_name(loIdx)

    # Delegate to processStore so unpack / for-target / chain-store paths work.
    # First store consumes TOS (high nibble target), second store consumes new TOS.
    processStore(self, hiName)
    processStore(self, loName)


def handleLoadSmallIntA(self):
    # Python 3.14+ LOAD_SMALL_INT - loads small integer constant
    value = self.code.Current.Argument
    node = ASTObject(PythonObject("Py_Int", value))
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)
