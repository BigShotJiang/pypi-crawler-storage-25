"""Translated from lib/handlers/unpack.js"""
from __future__ import annotations

from depyo.python_object import PythonObject
from depyo.ast_node import (
    ASTBlock,
    ASTTuple,
    ASTChainStore,
    ASTStore,
    ASTList,
    ASTSet,
    ASTMapUnpack,
)


def handleUnpackListA(self):
    processUnpack(self)


def handleUnpackTupleA(self):
    processUnpack(self)


def handleUnpackSequenceA(self):
    processUnpack(self)


def processUnpack(self):
    self.unpack = self.code.Current.Argument

    # Record pattern operation if in pattern matching
    if self.inMatchPattern:
        self.patternOps.append({
            'type': 'UNPACK_SEQUENCE',
            'count': self.unpack,
        })

    if self.unpack > 0:
        node = ASTTuple([])
        node.line = self.code.Current.LineNo
        self.dataStack.append(node)
    else:
        # Unpack zero values and assign it to top of stack or for loop variable.
        # E.g. [] = TOS / for [] in X
        tupleNode = ASTTuple([])
        if (self.curBlock.blockType == ASTBlock.BlockType.For
                and not self.curBlock.inited):
            tupleNode.requireParens = True
            self.curBlock.index = tupleNode
        elif isinstance(self.dataStack.top(), ASTChainStore):
            chainStore = self.dataStack.pop()
            chainStore.line = self.code.Current.LineNo
            self.append_to_chain_store(chainStore, tupleNode)
        else:
            node = ASTStore(self.dataStack.pop(), tupleNode)
            node.line = self.code.Current.LineNo
            self.curBlock.append(node)


def handleUnpackArgA(self):
    data = self.dataStack.pop()
    self.object.ArgCount = self.code.Current.Argument
    for idx in range(self.code.Current.Argument):
        self.object.VarNames.Value.append(data[idx])
    self.code.GoNext(self.code.Current.Argument)


def handleUnpackExA(self):
    self.unpack = (self.code.Current.Argument & 0xFF)
    self.starPos = self.unpack
    # Preserve JS operator precedence: `+` binds tighter than `&`
    self.unpack += (1 + (self.code.Current.Argument >> 8)) & 0xFF

    source = self.dataStack.pop()
    tuple_node = ASTTuple([])
    tuple_node.requireParens = False
    self.dataStack.append(PythonObject("Py_Null"))
    self.dataStack.append(ASTChainStore([], source))
    self.dataStack.append(tuple_node)


def handleBuildListUnpackA(self):
    processBuild(self)


def handleBuildTupleUnpackA(self):
    processBuild(self)


def handleBuildTupleUnpackWithCallA(self):
    # Python 3.6+ - same as BUILD_TUPLE_UNPACK but with better error messages
    processBuild(self)


def processBuild(self):
    values = []
    for idx in range(self.code.Current.Argument):
        values.insert(0, self.dataStack.pop())
    listNode = ASTList(values)  # Or ASTTuple based on opcode
    self.dataStack.append(listNode)


def handleBuildSetUnpackA(self):
    values = []
    for idx in range(self.code.Current.Argument):
        values.insert(0, self.dataStack.pop())
    setNode = ASTSet(values)
    self.dataStack.append(setNode)


def handleBuildMapUnpackA(self):
    # Py 3.5-3.8: count of mappings to merge for {**a, **b} dict literal.
    processBuildMapUnpack(self, False)


def handleBuildMapUnpackWithCallA(self):
    # Py 3.5 only: oparg = count + (fn_loc << 8). Lower byte is the map count,
    # upper byte locates the callable for error reporting.
    # Py 3.6-3.8: oparg = plain count (this opcode is kept for unpack-with-call
    # semantics but the fn_loc byte is dropped).
    processBuildMapUnpack(self, True)


def processBuildMapUnpack(self, withCall):
    count = self.code.Current.Argument
    if withCall and self.object.Reader.versionCompare(3, 6) < 0:
        count = count & 0xFF
    items = []
    for idx in range(count):
        items.insert(0, self.dataStack.pop())
    node = ASTMapUnpack(items)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)
