"""Translated from lib/handlers/formatting.js"""
from __future__ import annotations

from depyo.ast_node import (
    ASTFormattedValue,
    ASTTuple,
    ASTObject,
    ASTJoinedStr,
)


# PEP 750 t-strings (Python 3.14+):
#   strings_tuple ; (value ; str_repr ; [format_spec])+ ; BUILD_INTERPOLATION oparg
#   ... ; BUILD_TUPLE N ; BUILD_TEMPLATE -> Template
# BUILD_INTERPOLATION oparg layout:
#   oparg & 3        = pop count (2 = no format spec, 3 = has format spec)
#   (oparg >> 2) & 3 = conversion (0=none, 1=!s, 2=!r, 3=!a)
def handleBuildInterpolationA(self):
    oparg = self.code.Current.Argument or 0
    popCount = oparg & 3
    convCode = (oparg >> 2) & 3

    formatSpec = None
    if popCount == 3:
        formatSpec = self.dataStack.pop()
    self.dataStack.pop()  # discard str representation (used at runtime)
    value = self.dataStack.pop()

    if convCode == 0:
        conversion = ASTFormattedValue.ConversionFlag.None_
    elif convCode == 1:
        conversion = ASTFormattedValue.ConversionFlag.Str
    elif convCode == 2:
        conversion = ASTFormattedValue.ConversionFlag.Repr
    else:
        conversion = ASTFormattedValue.ConversionFlag.ASCII

    node = ASTFormattedValue(value, conversion, formatSpec)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleBuildTemplate(self):
    # Pops (strings_tuple, interpolations_tuple) and produces a Template node.
    interpolations = self.dataStack.pop()
    strings = self.dataStack.pop()

    interpVals = []
    if isinstance(interpolations, ASTTuple):
        interpVals = interpolations.values or []
    elif (interpolations is not None
          and getattr(interpolations, 'object', None) is not None
          and getattr(interpolations.object, 'Value', None)):
        interpVals = interpolations.object.Value

    # strings is loaded via LOAD_CONST as a Py_Tuple of Py_String objects
    stringVals = []
    if isinstance(strings, ASTTuple):
        stringVals = strings.values or []
    elif (strings is not None
          and getattr(strings, 'object', None) is not None
          and getattr(strings.object, 'Value', None)):
        # Wrap each Py_String in an ASTObject so ASTJoinedStr.codeFragment can render it.
        stringVals = [ASTObject(pyStr) for pyStr in strings.object.Value]

    # Interleave: str[0], interp[0], str[1], interp[1], ..., str[N]
    pieces = []
    for i in range(len(stringVals)):
        if stringVals[i]:
            pieces.append(stringVals[i])
        if i < len(interpVals):
            pieces.append(interpVals[i])

    # ASTJoinedStr's codeFragment reverses (BUILD_STRING pops in reverse). Compensate.
    pieces.reverse()
    joined = ASTJoinedStr(pieces)
    joined.isTemplateString = True
    joined.line = self.code.Current.LineNo
    self.dataStack.append(joined)
