"""Translated from lib/handlers/generators_async.js"""
from __future__ import annotations

from depyo.ast_node import (
    ASTBlock,
    ASTUnary,
    ASTBinary,
    ASTComprehension,
    ASTReturn,
    ASTAwaitable,
)
from depyo.handlers._util import debug_log


def handleInstrumentedYieldValueA(self):
    self.handleYieldValue()


def handleYieldValueA(self):
    # Python 3.12+ YIELD_VALUE with argument
    # Call the actual handleYieldValue function in this context
    handleYieldValue(self)


def handleYieldValue(self):
    value = self.dataStack.pop()

    # Skip YIELD_VALUE if we're inside await machinery
    if self.insideAwait:
        debug_log("[YIELD_VALUE] Skipping - inside await machinery")
        # Put value back on stack for END_SEND
        self.dataStack.append(value)
        return

    # Generator expression: YIELD_VALUE inside a For block tagged as comprehension
    # produces the genexpr's yielded expression. Mirror LIST_APPEND/SET_ADD pattern:
    # build an ASTComprehension on the stack so the enclosing JUMP_ABSOLUTE can
    # attach generators via addGenerator. Skip the trailing POP_TOP that balances
    # YIELD_VALUE's received-value push in the runtime model.
    # The yield may fire inside nested If blocks (genexpr with filter condition),
    # so walk up through If blocks to find the enclosing For+comprehension.
    forBlock = None
    ifBlocks = []
    if self.curBlock.blockType == ASTBlock.BlockType.For and self.curBlock.comprehension:
        forBlock = self.curBlock
    else:
        for i in range(len(self.blocks) - 1, -1, -1):
            blk = self.blocks[i]
            if blk.blockType == ASTBlock.BlockType.For and blk.comprehension:
                forBlock = blk
                break
            if blk.blockType == ASTBlock.BlockType.If:
                ifBlocks.append(blk)
            else:
                break
    if forBlock:
        for ifBlk in ifBlocks:
            cond = ifBlk.condition
            if not cond:
                continue
            if ifBlk.negative:
                cond = ASTUnary(cond, ASTUnary.UnaryOp.Not)
                cond.line = self.code.Current.LineNo
            if forBlock.condition:
                andCond = ASTBinary(forBlock.condition, cond, ASTBinary.BinOp.LogicalAnd)
                andCond.line = self.code.Current.LineNo
                forBlock.condition = andCond
            else:
                forBlock.condition = cond
        while self.curBlock is not forBlock and len(self.blocks) > 1:
            self.blocks.pop()
            self.curBlock = self.blocks.top()
        node = ASTComprehension(value)
        node.line = self.code.Current.LineNo
        node.kind = ASTComprehension.GENERATOR
        self.dataStack.append(node)
        nxt = self.code.Next
        if nxt is not None and nxt.OpCodeID == self.OpCodes.POP_TOP:
            self.code.GoNext()
        return

    # Async genexpr inner code: GET_ANEXT iteration uses SETUP_EXCEPT/FINALLY
    # rather than FOR_ITER, so no For+comp block exists when YIELD_VALUE fires
    # inside the comprehension body. Save the yielded value so the CALL-site
    # reconstruction in function_calls.js can use it as the comprehension's
    # yield expression. We still append ASTReturn below for regular async
    # generators; the save is harmless because the CALL-site only reads
    # _asyncCompYieldExpr when reconstructing a recognized comp code object.
    # Name may be a PythonObject (with .toString) or a raw str — the port's
    # marshal reader dereferences the const pool for code-object names, so
    # don't assume .toString() exists.
    name_obj = getattr(self.object, 'Name', None)
    if name_obj is None:
        objName = ''
    elif hasattr(name_obj, 'toString'):
        objName = name_obj.toString()
    else:
        objName = str(name_obj)
    if 'genexpr' in objName:
        self.object._asyncCompYieldExpr = value

    # Python 3.11+: YIELD_VALUE appears in async for loops as implementation detail
    # Skip if we're inside AsyncFor block and value looks like generator machinery
    if self.object.Reader.versionCompare(3, 11) >= 0:
        # Check if we're in an async for loop
        inAsyncFor = False
        for i in range(len(self.blocks) - 1, -1, -1):
            if self.blocks[i].blockType == ASTBlock.BlockType.AsyncFor:
                inAsyncFor = True
                break

        if inAsyncFor:
            # Check if value is generator machinery (call to __anext__, etc.)
            # In async for context, YIELD_VALUE with awaitable is implementation detail
            if value is not None and type(value).__name__ in ('ASTCall', 'ASTBinary', 'ASTNone'):
                debug_log(f"[YIELD_VALUE] Skipping generator machinery in async for: {type(value).__name__}")
                # Don't append - this is implementation detail
                return

    node = ASTReturn(value, ASTReturn.RetType.Yield)
    node.line = self.code.Current.LineNo
    self.curBlock.append(node)


def handleYieldFrom(self):
    dest = self.dataStack.pop()
    # TODO: Support yielding into a non-null destination
    valueNode = self.dataStack.top()
    if valueNode:
        node = ASTReturn(valueNode, ASTReturn.RetType.YieldFrom)
        node.line = self.code.Current.LineNo
        self.curBlock.append(node)


def handleGetAwaitable(self):
    obj = self.dataStack.pop()
    node = ASTAwaitable(obj)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)

    # Set flag: we're inside await machinery
    # SEND/YIELD_VALUE until END_SEND are implementation details
    self.insideAwait = True


def handleGetAwaitableA(self):
    # Python 3.11+ GET_AWAITABLE with argument
    handleGetAwaitable(self)


def handleGenStartA(self):
    self.dataStack.pop()


def handleEndSend(self):
    # Python 3.12+ END_SEND opcode
    # Ends a SEND operation in async generators/await
    # For decompilation: clear await flag, awaitable result is on stack
    debug_log(f"[END_SEND] at offset {self.code.Current.Offset}, insideAwait={self.insideAwait}")

    # Clear await machinery flag
    self.insideAwait = False


def handleInstrumentedEndSendA(self):
    # Instrumented variant mirrors END_SEND behavior.
    handleEndSend(self)


def handleCleanupThrow(self):
    # Python 3.12+ CLEANUP_THROW opcode
    # Exception cleanup in async generators
    # For decompilation: no-op, exception handling is implicit
    debug_log(f"[CLEANUP_THROW] at offset {self.code.Current.Offset}")


def handleSendA(self):
    # Python 3.11+ SEND opcode
    # Used in async generators to send values into awaitables
    # Stack: TOS = value to send, TOS1 = awaitable
    # In async for context: sends None into __anext__() awaitable

    debug_log(f"[SEND] at offset {self.code.Current.Offset}, jump_target={self.code.Current.Argument}")

    # For async for loops, SEND is part of iteration machinery
    # The awaitable (__anext__) is already on stack from GET_ANEXT
    # SEND will be followed by YIELD_VALUE (generator mechanics)
    # Result will be stored by subsequent STORE_FAST

    # Pop the send value (usually None for async for)
    sendValue = self.dataStack.pop()

    # Keep awaitable on stack - YIELD_VALUE will handle it
    # Or if we're in a simple async for, it stays for STORE_FAST

    send_name = type(sendValue).__name__ if sendValue is not None else None
    debug_log(f"  Send value: {send_name}, stack depth: {len(self.dataStack)}")


def handleResumeA(self):
    # Python 3.11+ RESUME opcode
    # Marks resumption points in generators/coroutines
    # Argument: 0=start, 1=yield, 2=yield from, 3=await

    arg = self.code.Current.Argument
    labels = ['start', 'yield', 'yield_from', 'await']
    resumeType = labels[arg] if (arg is not None and 0 <= arg < len(labels)) else 'unknown'
    debug_log(f"[RESUME {resumeType}] at offset {self.code.Current.Offset}")

    # No-op for decompiler - just marks resumption point for runtime optimization


def handleInstrumentedResumeA(self):
    self.handleResumeA()
