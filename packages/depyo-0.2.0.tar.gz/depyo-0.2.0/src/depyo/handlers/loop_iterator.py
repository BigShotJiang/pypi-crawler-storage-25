"""Translated from lib/handlers/loop_iterator.js"""
from __future__ import annotations

import sys

from depyo.ast_node import (
    ASTKeyword,
    ASTCondBlock,
    ASTBlock,
    ASTNone,
    ASTList,
    ASTSet,
    ASTMap,
    ASTIterBlock,
    ASTIteratorValue,
    ASTCall,
    ASTName,
    ASTBinary,
    ASTComprehension,
)
from depyo.handlers._util import debug_log, debug_error


def handleBreakLoop(self):
    keywordNode = ASTKeyword(ASTKeyword.Word.Break)
    keywordNode.line = self.code.Current.LineNo
    self.curBlock.append(keywordNode)

    # Mark code as unreachable until the end of CURRENT BLOCK (not entire loop)
    # This allows alternative branches (elif/else) to be processed correctly
    #
    # WRONG approach: unreachableUntil = loopBlock.end (too broad, skips elif!)
    # RIGHT approach: unreachableUntil = curBlock.end (only this branch)
    if self.curBlock.end > self.code.Current.Offset:
        self.unreachableUntil = self.curBlock.end

        debug_log(f"BREAK at offset {self.code.Current.Offset}: curBlock={self.curBlock.type_str} ({self.curBlock.start}-{self.curBlock.end})")
        stack_desc = ', '.join(f"[{i}]{b.type_str}({b.start}-{b.end})" for i, b in enumerate(self.blocks))
        debug_log(f"  Block stack: {stack_desc}")
        debug_log(f"  Marking unreachable until {self.unreachableUntil}")


def handleSetupLoopA(self):
    debug_log(f"[handleSetupLoopA] Creating while at offset {self.code.Current.Offset}, JumpTarget={self.code.Current.JumpTarget}")
    debug_log(f"  Data stack size: {len(self.dataStack)}")
    if len(self.dataStack) > 0:
        top = self.dataStack.top()
        top_name = type(top).__name__ if top is not None else None
        frag = top.codeFragment() if (top is not None and callable(getattr(top, 'codeFragment', None))) else top
        debug_log(f"  Stack top: {top_name} = {frag}")

    nextBlock = ASTCondBlock(ASTBlock.BlockType.While, self.code.Current.Offset, self.code.Current.JumpTarget, None, False)
    nextBlock.line = self.code.Current.LineNo
    self.blocks.append(nextBlock)
    self.curBlock = self.blocks.top()


def handleContinueLoopA(self):
    node = ASTKeyword(ASTKeyword.Word.Continue)
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleForIterA(self):
    handleInstrumentedForIterA(self)


def handleInstrumentedForIterA(self):
    iter_ = self.dataStack.pop()  # Iterable
    # Pop it? Don't pop it?

    start = self.code.Current.Offset
    end = 0
    line = self.code.Current.LineNo
    comprehension = False
    pre38ListCompDetected = False
    specialized = self.object.Reader.versionCompare(3, 13) >= 0
    sentinel = ASTNone() if specialized else None

    # before 3.8, there is a SETUP_LOOP instruction with block start and end position,
    #    the self.code.Current.Argument is usually a jump to a POP_BLOCK instruction
    # after 3.8, block extent has to be inferred implicitly; the self.code.Current.Argument is a jump to a position after the for block
    if self.object.Reader.versionCompare(3, 8) >= 0:
        end = self.code.Current.Argument
        if self.object.Reader.versionCompare(3, 10) >= 0:
            end *= 2  # BPO-27129
        nxt = self.code.Next
        end += (nxt.Offset if nxt is not None else 0)
        end = self.code.FindEndOfBlock(end)[0]
        objName = getattr(self.object, 'Name', None)
        comprehension = (self.code.Current.Name == "<listcomp>"
                         or objName == "<listcomp>"
                         or objName == "<setcomp>"
                         or objName == "<dictcomp>")
        if not comprehension:
            container = self.dataStack.top()
            if (isinstance(container, (ASTList, ASTSet, ASTMap))
                    and (len(container.values or []) == 0)):
                comprehension = True
        # 3.12+ inline comprehension: extend block end past END_FOR so the
        # for-block isn't auto-popped before handleEndFor runs the cleanup.
        # Without this, the auto-pop at PycDecompiler.js:614 closes the
        # for-block at its natural end (just past JUMP_BACKWARD), and END_FOR
        # can't reach it to call addGenerator.
        if getattr(self, '_inlineCompSavedVar', None) is not None and comprehension:
            scanOff = end
            for i in range(10):
                ins = self.code.PeekInstructionAtOffset(scanOff)
                if ins is None:
                    break
                if ins.OpCodeID == self.OpCodes.END_FOR:
                    end = ins.Offset + (ins.Size or 2)
                    break
                scanOff += (ins.Size or 2)
    else:
        top_node = self.dataStack.top()
        if (isinstance(top_node, (ASTSet, ASTList, ASTMap))
                and len(top_node.values) == 0):
            end = self.code.Current.JumpTarget
            comprehension = True
            # 2.7 inline listcomp (no `_[N]` cache, empty ASTList on stack):
            # LIST_APPEND arg=N reads the accumulator via peek-offset, so the
            # sentinel push would leave the real accumulator trapped on the
            # stack for the trailing COMPARE_OP / etc. to swallow as a
            # phantom operand. Skip the sentinel and let LIST_APPEND pop the
            # accumulator directly.
            # Dict/set comps (ASTMap/ASTSet): MAP_ADD/SET_ADD pop one entry
            # assuming the sentinel is present — keep the sentinel there.
            # 2.3-2.6 with `_[N]` cache: handled by the else-if below (top
            # of stack is the enclosing expression, not an empty list).
            # Exception: if the body has UNPACK_SEQUENCE (loop var is a
            # tuple `for k, v in …`), the STORE chain's final seqNode pop
            # would consume the accumulator list instead of a sentinel,
            # stranding the outer callable (e.g. `dict`) on the stack for
            # LIST_APPEND to eat as the "list". Keep the sentinel so STORE
            # consumes it and LIST_APPEND still finds the real accumulator.
            listcompCache = getattr(self, '_listCompAppendRefs', None)
            hasListcompCache = bool(listcompCache) and len(listcompCache.keys()) > 0
            isList = isinstance(self.dataStack.top(), ASTList)
            if not hasListcompCache and isList:
                hasUnpackInBody = False
                bodyEnd = self.code.Current.JumpTarget
                nxt = self.code.Next
                scanOff = nxt.Offset if nxt is not None else None
                i = 0
                while i < 20 and scanOff is not None and scanOff < bodyEnd:
                    ins = self.code.PeekInstructionAtOffset(scanOff)
                    if ins is None:
                        break
                    if ins.OpCodeID == self.OpCodes.UNPACK_SEQUENCE_A:
                        hasUnpackInBody = True
                        break
                    scanOff = ins.Offset + (ins.Size or 3)
                    i += 1
                if not hasUnpackInBody:
                    pre38ListCompDetected = True
        elif getattr(self, '_listCompAppendRefs', None) and len(self._listCompAppendRefs.keys()) > 0:
            # Py2.4-2.6 inline listcomp: accumulator stashed in `_[N]` via
            # DUP_TOP/STORE_NAME, so the empty-list heuristic misses it
            # (stack top is the enclosing expression — `dict` for
            # `dict([…])`, or the COMPARE_OP left-list for `assert X == […]`).
            # Body always does `LOAD _[N]` before LIST_APPEND, so the
            # accumulator reaches LIST_APPEND via the cache and the sentinel
            # survives. When the loop var is stored via plain STORE_NAME
            # (parentForBlock path, no pop), nothing consumes the sentinel
            # and it leaks into the trailing COMPARE_OP / CALL_FUNCTION.
            # Look ahead for UNPACK_SEQUENCE in the body: if present, the
            # STORE chain consumes the sentinel as its seqNode pop — keep
            # it. Otherwise skip the sentinel push.
            end = self.code.Current.JumpTarget
            comprehension = True
            hasUnpackInBody = False
            bodyEnd = self.code.Current.JumpTarget
            nxt = self.code.Next
            scanOff = nxt.Offset if nxt is not None else None
            i = 0
            while i < 20 and scanOff is not None and scanOff < bodyEnd:
                ins = self.code.PeekInstructionAtOffset(scanOff)
                if ins is None:
                    break
                if ins.OpCodeID == self.OpCodes.UNPACK_SEQUENCE_A:
                    hasUnpackInBody = True
                    break
                scanOff = ins.Offset + (ins.Size or 3)
                i += 1
            if not hasUnpackInBody:
                pre38ListCompDetected = True
        else:
            top = self.blocks.top()
            start = top.start
            end = top.end  # block end position from SETUP_LOOP
            line = top.line

            if top.blockType == ASTBlock.BlockType.While:
                self.blocks.pop()
                # Py2.4-2.6 genexpr inner code has SETUP_LOOP → While, but
                # it IS a comprehension. Detect by code object name.
                objName = getattr(self.object, 'Name', None)
                if objName == "<generator expression>" or objName == "<genexpr>":
                    comprehension = True
            else:
                comprehension = True

    forblk = ASTIterBlock(ASTBlock.BlockType.For, start, end, iter_)
    forblk.line = line
    forblk.comprehension = comprehension

    self.blocks.append(forblk)
    self.curBlock = self.blocks.top()

    # Py2.6 inline listcomp (detected via _[N] cache) has no POP_TOP at the
    # for-block end to consume the sentinel — the enclosing COMPARE_OP/etc
    # would then swallow it as a fake operand. Skip the placeholder push in
    # that case; nothing downstream needs it since the comprehension closes
    # at LIST_APPEND.
    if not pre38ListCompDetected:
        # 3.13+ FOR_ITER pushes a sentinel used by END_FOR; keep stack balanced.
        self.dataStack.append(sentinel)


def handleForLoopA(self):
    curidx = self.dataStack.pop()  # Current index
    iter_ = self.dataStack.pop()  # Iterable

    comprehension = False
    top = self.blocks.top()

    if top.blockType == ASTBlock.BlockType.While:
        self.blocks.pop()
    else:
        comprehension = True

    forblk = ASTIterBlock(ASTBlock.BlockType.For, self.code.Current.Offset, top.end, iter_)
    forblk.line = self.code.Current.LineNo
    forblk.comprehension = comprehension
    self.blocks.append(forblk)
    self.curBlock = self.blocks.top()

    self.dataStack.append(iter_)
    self.dataStack.append(curidx)
    self.dataStack.append(None)


def handleGetAiter(self):
    # Logic similar to FOR_ITER_A
    iter_ = self.dataStack.pop()  # Iterable

    # Async comprehension parameter setup: GET_AITER converts the iterable to an
    # async iterator before passing it to the genexpr/listcomp function call.
    # Don't create an AsyncFor block — just forward the iterable.
    #   3.5-3.6: GET_AITER → LOAD_CONST None → YIELD_FROM → CALL_FUNCTION
    #   3.7:     GET_AITER → CALL_FUNCTION (no YIELD_FROM needed)
    n1 = self.code.Next
    if n1 is not None:
        n2 = n1.Next
        n3 = n2.Next if n2 is not None else None
        if (n2 is not None and n3 is not None
                and n1.OpCodeID == self.OpCodes.LOAD_CONST_A
                and n2.OpCodeID == self.OpCodes.YIELD_FROM
                and n3.OpCodeID == self.OpCodes.CALL_FUNCTION_A):
            self.dataStack.append(ASTIteratorValue(iter_))
            self.code.GoNext(2)
            return
        if n1.OpCodeID == self.OpCodes.CALL_FUNCTION_A:
            self.dataStack.append(ASTIteratorValue(iter_))
            return

    start = self.code.Current.Offset
    end = 0
    line = self.code.Current.LineNo
    comprehension = False

    top = self.blocks.top()

    # Python 3.8+ removed SETUP_LOOP, so we need to infer the block end
    if (self.object.Reader.versionCompare(3, 8) >= 0
            or top.blockType != ASTBlock.BlockType.While):
        # Python 3.11+: Check exception table first for END_ASYNC_FOR location
        if (self.object.Reader.versionCompare(3, 11) >= 0
                and self.object.ExceptionTable
                and len(self.object.ExceptionTable) > 0):
            debug_log(f"[GET_AITER] Python 3.11+ with exception table ({len(self.object.ExceptionTable)} entries)")
            for i, entry in enumerate(self.object.ExceptionTable):
                debug_log(f"  Entry {i}: start={entry.start}, end={entry.end}, target={entry.target}, depth={entry.depth}")

            # Find exception handler that covers the async for loop
            # The handler's target offset should point to END_ASYNC_FOR
            # Note: exception table start may be GET_ANEXT (after GET_AITER)
            for entry in self.object.ExceptionTable:
                # Check if this entry covers range starting at/near GET_AITER
                # GET_AITER is at 'start', exception table may start at next instruction
                if entry.start - 4 <= start <= entry.start + 4:
                    # The target is the exception handler (END_ASYNC_FOR)
                    end = entry.target + 2  # END_ASYNC_FOR is 2 bytes, end is after it

                    debug_log(f"  ✓ Found END_ASYNC_FOR via exception table: target={entry.target}, end={end}")
                    break

        # If not found via exception table, fall back to search
        if end == 0:
            # Find END_ASYNC_FOR to determine block end
            # Scan forward by offset (not by instruction index)
            searchOffset = self.code.Next.Offset
            searchLimit = 200
            searchCount = 0

            debug_log(f"[GET_AITER] Fallback: searching for END_ASYNC_FOR from offset {searchOffset}")
            debug_log(f"  Last offset: {self.code.LastOffset}, instructions: {len(self.code.Instructions)}")

            while searchCount < searchLimit:
                instr = self.code.PeekInstructionAtOffset(searchOffset)
                if not instr:
                    debug_log(f"  No instruction at offset {searchOffset}, stopping search (searched {searchCount} bytes)")
                    break

                if searchCount < 30:
                    debug_log(f"  [{searchCount}] offset={instr.Offset}, opcode={instr.InstructionName}, id={instr.OpCodeID}, size={instr.Size}")

                if instr.OpCodeID == self.OpCodes.END_ASYNC_FOR:
                    instrSize = instr.Size or 2
                    end = instr.Offset + instrSize
                    debug_log(f"  ✓ Found END_ASYNC_FOR at offset {instr.Offset}, size={instrSize}, end={end}")
                    break

                # Python 3.6+ uses 2-byte (word-aligned) instructions
                instrSize = instr.Size or 2
                searchOffset += instrSize
                searchCount += instrSize

                if searchCount < 10:
                    debug_log(f"  Next search: offset={searchOffset}, count={searchCount}")

            if end == 0:
                debug_error(f"Could not find END_ASYNC_FOR for GET_AITER at offset {start}")
                end = self.code.LastOffset + 2  # Conservative fallback: run to end of code

        # Check if this is an async comprehension (generator expression)
        name = self.code.Current.Name
        comprehension = bool(name) and ("comp>" in name or "genexpr>" in name)

        forblk = ASTIterBlock(ASTBlock.BlockType.AsyncFor, start, end, iter_)
        forblk.line = line
        forblk.comprehension = comprehension
        self.blocks.append(forblk)
        self.curBlock = self.blocks.top()
        self.dataStack.append(None)
    elif top.blockType == ASTBlock.BlockType.While:
        # Python 3.7 and earlier with SETUP_LOOP: SETUP_LOOP creates While block first
        debug_log(f"[GET_AITER] Converting While to AsyncFor at offset {start}, end={top.end}")
        self.blocks.pop()
        forblk = ASTIterBlock(ASTBlock.BlockType.AsyncFor, top.start, top.end, iter_)
        forblk.line = line
        self.blocks.append(forblk)
        self.curBlock = self.blocks.top()
        self.dataStack.append(None)
    else:
        print(f"Unexpected block type for GET_AITER: {top.type_str} at offset {start}\n", file=sys.stderr, end='')


def handleGetAnext(self):
    iter_ = self.dataStack.top()
    callNode = ASTCall(ASTName('await'), [ASTBinary(iter_, ASTName('__anext__'), ASTBinary.BinOp.Attr)], [])
    callNode.line = self.code.Current.LineNo
    self.dataStack.append(callNode)


def handleGetIter(self):
    handleGetYieldFromIter(self)


def handleGetYieldFromIter(self):
    # We just entirely ignore this
    nxt = self.code.Next
    if nxt is not None and nxt.OpCodeID == self.OpCodes.CALL_FUNCTION_A:
        self.dataStack.append(ASTIteratorValue(self.dataStack.pop()))


def handleEndFor(self):
    # Python 3.13+ END_FOR opcode
    # Cleans up after for loop iteration
    # In Python 3.13, FOR_ITER pushes sentinel, END_FOR pops it
    debug_log(f"[END_FOR] at offset {self.code.Current.Offset}")

    # Inline comprehension cleanup (3.12+): closing pattern after END_FOR is
    #   POP_TOP ; SWAP 2 ; STORE_FAST <savedVar>
    # After LIST_APPEND in comprehension mode, the stack has [..., emptyList, ASTComp].
    # We rescue ASTComp, drop the empty accumulator, and skip the cleanup ops.
    if getattr(self, '_inlineCompSavedVar', None) is not None:
        top = self.dataStack.top()
        if isinstance(top, ASTComprehension):
            self.dataStack.pop()
            below = self.dataStack.top()
            if ((isinstance(below, ASTList) and len(below.values or []) == 0)
                    or (isinstance(below, ASTSet) and len(below.values or []) == 0)
                    or (isinstance(below, ASTMap) and len(below.values or []) == 0)):
                self.dataStack.pop()
            # Pop the inline-comp for-block and attach its generator to the
            # comprehension so it renders as `[expr for x in iter]`. Without
            # this, JUMP_BACKWARD in 3.11+ is a no-op and addGenerator never
            # fires (control_flow_jumps.js only handles JUMP_ABSOLUTE).
            forBlk = self.curBlock
            if forBlk and forBlk.blockType == ASTBlock.BlockType.For and forBlk.comprehension:
                top.addGenerator(forBlk)
                self.blocks.pop()
                self.curBlock = self.blocks.top()
            self.dataStack.append(top)
        saved = self._inlineCompSavedVar
        cand0 = self.code.Next
        cand1 = cand0.Next if cand0 is not None else None
        cand2 = cand1.Next if cand1 is not None else None
        if (cand0 is not None and cand0.OpCodeID == self.OpCodes.POP_TOP
                and cand1 is not None and cand1.OpCodeID == self.OpCodes.SWAP_A and cand1.Argument == 2
                and cand2 is not None and cand2.OpCodeID == self.OpCodes.STORE_FAST_A and cand2.Name == saved):
            self.code.GoNext(3)
        self._inlineCompSavedVar = None
        return

    if self.object.Reader.versionCompare(3, 13) >= 0 and len(self.dataStack) > 0:
        self.dataStack.pop()


def handleInstrumentedEndForA(self):
    # Instrumented variant mirrors END_FOR behavior.
    handleEndFor(self)


def handleInstrumentedPopIterA(self):
    # Instrumentation helper; no stack effect for decompilation.
    debug_log(f"[INSTRUMENTED_POP_ITER] at offset {self.code.Current.Offset}")
