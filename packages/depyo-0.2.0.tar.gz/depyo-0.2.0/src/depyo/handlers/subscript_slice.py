"""Translated from lib/handlers/subscript_slice.js"""
from __future__ import annotations

import sys

from depyo.ast_node import (
    ASTSubscr,
    ASTBlock,
    ASTComprehension,
    ASTMap,
    ASTSlice,
    ASTObject,
    ASTNone,
    ASTDelete,
    ASTChainStore,
    ASTStore,
    ASTTuple,
    ASTName,
    ASTAnnotatedVar,
)
from depyo.handlers._util import debug_log


def handleBinarySubscr(self):
    subscr = self.dataStack.pop()
    src = self.dataStack.pop()
    node = ASTSubscr(src, subscr)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleMapAddA(self):
    # MAP_ADD: add key/value pair to dict under construction
    # Stack (TOS at right): ... , map, key, value
    value = self.dataStack.pop()
    key = self.dataStack.pop()

    # Check if this is a dict comprehension
    if self.curBlock.blockType == ASTBlock.BlockType.For and self.curBlock.comprehension:
        self.dataStack.pop()  # Pop the empty map
        node = ASTComprehension(value, key)
        node.line = self.code.Current.LineNo
        node.kind = ASTComprehension.DICT
        self.dataStack.append(node)
        return

    # Async dict comprehension inner code: GET_ANEXT iteration uses
    # SETUP_EXCEPT/FINALLY rather than FOR_ITER, so no For+comp block
    # exists. Save the key/value so the CALL-site reconstruction can use
    # them as the comprehension's yield expression.
    forBlock = None
    for i in range(len(self.blocks) - 1, -1, -1):
        blk = self.blocks[i]
        if blk.blockType == ASTBlock.BlockType.For and blk.comprehension:
            forBlock = blk
            break
        if blk.blockType != ASTBlock.BlockType.If:
            break
    if not forBlock:
        self.object._asyncCompYieldExpr = value
        self.object._asyncCompYieldKey = key

    mapNode = self.dataStack.pop()

    if not isinstance(mapNode, ASTMap):
        # Initialize a map literal if we didn't have one
        mapNode = ASTMap([])

    mapNode.add(key, value)
    mapNode.line = self.code.Current.LineNo
    self.dataStack.append(mapNode)


def handleStoreMap(self):
    # Py2.x STORE_MAP: TOS=key, SECOND=value, THIRD=dict under construction.
    # Pops key and value, leaves dict on stack with entry added.
    # Without this, BUILD_MAP yields an empty ASTMap and the raw key/value
    # LOAD_CONSTs pile onto the stack; the trailing STORE_NAME then picks
    # up the last-pushed key (a literal int/string) instead of the dict.
    key = self.dataStack.pop()
    value = self.dataStack.pop()
    mapNode = self.dataStack.top()
    if isinstance(mapNode, ASTMap):
        mapNode.add(key, value)
        mapNode.line = self.code.Current.LineNo
    else:
        # No dict under construction — unexpected; restore stack so downstream
        # handlers still see the values and can diagnose the shape.
        self.dataStack.append(value)
        self.dataStack.append(key)


def handleBuildSliceA(self):
    if self.code.Current.Argument == 2:
        end = self.dataStack.pop()
        start = self.dataStack.pop()

        if isinstance(start, ASTObject) and (start.object is None or start.object.ClassName == 'Py_None'):
            start = None

        if isinstance(end, ASTObject) and (end.object is None or end.object.ClassName == 'Py_None'):
            end = None

        sliceOp = None
        if not start and not end:
            sliceOp = ASTSlice.SliceOp.Slice0
        elif not start:
            sliceOp = ASTSlice.SliceOp.Slice2
        elif not end:
            sliceOp = ASTSlice.SliceOp.Slice1
        else:
            sliceOp = ASTSlice.SliceOp.Slice3

        mapNode = ASTSlice(sliceOp, start or ASTNone(), end or ASTNone())
        mapNode.line = self.code.Current.LineNo
        self.dataStack.append(mapNode)
    elif self.code.Current.Argument == 3:
        step = self.dataStack.pop()
        end = self.dataStack.pop()
        start = self.dataStack.pop()

        if isinstance(start, ASTObject) and (start.object is None or start.object.ClassName == 'Py_None'):
            start = None

        if isinstance(end, ASTObject) and (end.object is None or end.object.ClassName == 'Py_None'):
            end = None

        if isinstance(step, ASTObject) and (step.object is None or step.object.ClassName == 'Py_None'):
            step = None

        sliceOp = None
        if not start and not end:
            sliceOp = ASTSlice.SliceOp.Slice0
        elif not start:
            sliceOp = ASTSlice.SliceOp.Slice2
        elif not end:
            sliceOp = ASTSlice.SliceOp.Slice1
        else:
            sliceOp = ASTSlice.SliceOp.Slice3

        lhs = ASTSlice(sliceOp, start or ASTNone(), end or ASTNone())
        lhs.line = self.code.Current.LineNo

        if not step:
            sliceOp = ASTSlice.SliceOp.Slice1
        else:
            sliceOp = ASTSlice.SliceOp.Slice3

        sliceNode = ASTSlice(sliceOp, start or ASTNone(), end or ASTNone())
        sliceNode.line = self.code.Current.LineNo
        self.dataStack.append(sliceNode)


def handleDeleteSlice0(self):
    cur = self.code.Current
    if cur is not None and getattr(cur, 'InstructionName', None) == 'NOT_TAKEN':
        debug_log(f"[NOT_TAKEN] skipping instrumentation hint at offset {cur.Offset}")
        return
    name = self.dataStack.pop()
    node = ASTDelete(ASTSubscr(name, ASTSlice(ASTSlice.SliceOp.Slice0)))
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleDeleteSlice1(self):
    upper = self.dataStack.pop()
    name = self.dataStack.pop()

    node = ASTDelete(ASTSubscr(name, ASTSlice(ASTSlice.SliceOp.Slice1, upper)))
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleDeleteSlice2(self):
    lower = self.dataStack.pop()
    name = self.dataStack.pop()

    node = ASTDelete(ASTSubscr(name, ASTSlice(ASTSlice.SliceOp.Slice2, lower)))
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleDeleteSlice3(self):
    lower = self.dataStack.pop()
    upper = self.dataStack.pop()
    name = self.dataStack.pop()

    node = ASTDelete(ASTSubscr(name, ASTSlice(ASTSlice.SliceOp.Slice3, upper, lower)))
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleDeleteSubscr(self):
    key = self.dataStack.pop()
    name = self.dataStack.pop()

    node = ASTDelete(ASTSubscr(name, key))
    node.line = self.code.Current.LineNo
    self.curBlock.nodes.append(node)


def handleSlice0(self):
    name = self.dataStack.pop()
    if isinstance(name, ASTChainStore):
        name = name.source

    sliceNode = ASTSlice(ASTSlice.SliceOp.Slice0)
    node = ASTSubscr(name, sliceNode)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleSlice1(self):
    lower = self.dataStack.pop()
    name = self.dataStack.pop()

    sliceNode = ASTSlice(ASTSlice.SliceOp.Slice1, lower)
    node = ASTSubscr(name, sliceNode)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleSlice2(self):
    upper = self.dataStack.pop()
    name = self.dataStack.pop()

    sliceNode = ASTSlice(ASTSlice.SliceOp.Slice2, None, upper)
    node = ASTSubscr(name, sliceNode)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleSlice3(self):
    upper = self.dataStack.pop()
    lower = self.dataStack.pop()
    name = self.dataStack.pop()

    sliceNode = ASTSlice(ASTSlice.SliceOp.Slice3, lower, upper)
    node = ASTSubscr(name, sliceNode)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleStoreSlice0(self):
    destNode = self.dataStack.pop()
    valueNode = self.dataStack.pop()
    node = ASTStore(valueNode,
                    ASTSubscr(destNode,
                              ASTSlice(ASTSlice.SliceOp.Slice0)))
    node.line = self.code.Current.LineNo
    self.curBlock.append(node)


def handleStoreSlice1(self):
    upper = self.dataStack.pop()
    dest = self.dataStack.pop()
    value = self.dataStack.pop()
    node = ASTStore(value,
                    ASTSubscr(dest,
                              ASTSlice(ASTSlice.SliceOp.Slice1, upper)))
    node.line = self.code.Current.LineNo
    self.curBlock.append(node)


def handleStoreSlice2(self):
    lowerNode = self.dataStack.pop()
    destNode = self.dataStack.pop()
    valueNode = self.dataStack.pop()
    node = ASTStore(valueNode,
                    ASTSubscr(destNode,
                              ASTSlice(ASTSlice.SliceOp.Slice2, None, lowerNode)))
    node.line = self.code.Current.LineNo
    self.curBlock.append(node)


def handleStoreSlice3(self):
    lowerNode = self.dataStack.pop()
    upperNode = self.dataStack.pop()
    destNode = self.dataStack.pop()
    valueNode = self.dataStack.pop()
    node = ASTStore(valueNode,
                    ASTSubscr(destNode,
                              ASTSlice(ASTSlice.SliceOp.Slice3, upperNode, lowerNode)))
    node.line = self.code.Current.LineNo
    self.curBlock.append(node)


def getAnnotationTargetName(node):
    if not node:
        return None
    if isinstance(node, ASTName):
        return node.name
    if isinstance(node, ASTObject):
        value = getattr(node.object, 'Value', None) if node.object is not None else None
        if value is not None:
            return str(value)
    code_frag_fn = getattr(node, 'codeFragment', None)
    fragment = code_frag_fn() if callable(code_frag_fn) else None
    if not fragment:
        return None
    if hasattr(fragment, 'toString'):
        fragment = fragment.toString()
    if not isinstance(fragment, str):
        return None
    trimmed = fragment.strip()
    if ((trimmed.startswith("'") and trimmed.endswith("'"))
            or (trimmed.startswith('"') and trimmed.endswith('"'))):
        return trimmed[1:-1]
    return trimmed


def storeMatchesAnnotation(storeNode, annotationKeyNode):
    if not isinstance(storeNode, ASTStore):
        return False
    annotationName = getAnnotationTargetName(annotationKeyNode)
    if not annotationName:
        return False

    dest = storeNode.dest
    if isinstance(dest, ASTName):
        return dest.name == annotationName
    return False


def handleBinarySlice(self):
    # Python 3.12+ BINARY_SLICE: (container, start, stop -- container[start:stop])
    stop = self.dataStack.pop()
    start = self.dataStack.pop()
    container = self.dataStack.pop()

    if isinstance(start, ASTObject) and (start.object is None or start.object.ClassName == 'Py_None'):
        start = None
    if isinstance(stop, ASTObject) and (stop.object is None or stop.object.ClassName == 'Py_None'):
        stop = None

    if not start and not stop:
        sliceOp = ASTSlice.SliceOp.Slice0
    elif not start:
        sliceOp = ASTSlice.SliceOp.Slice2
    elif not stop:
        sliceOp = ASTSlice.SliceOp.Slice1
    else:
        sliceOp = ASTSlice.SliceOp.Slice3

    sliceNode = ASTSlice(sliceOp, start, stop)
    sliceNode.line = self.code.Current.LineNo
    node = ASTSubscr(container, sliceNode)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleStoreSlice(self):
    # Python 3.12+ STORE_SLICE: (value, container, start, stop -- )
    # Stores container[start:stop] = value
    stop = self.dataStack.pop()
    start = self.dataStack.pop()
    container = self.dataStack.pop()
    value = self.dataStack.pop()

    if isinstance(start, ASTObject) and (start.object is None or start.object.ClassName == 'Py_None'):
        start = None
    if isinstance(stop, ASTObject) and (stop.object is None or stop.object.ClassName == 'Py_None'):
        stop = None

    if not start and not stop:
        sliceOp = ASTSlice.SliceOp.Slice0
    elif not start:
        sliceOp = ASTSlice.SliceOp.Slice2
    elif not stop:
        sliceOp = ASTSlice.SliceOp.Slice1
    else:
        sliceOp = ASTSlice.SliceOp.Slice3

    sliceNode = ASTSlice(sliceOp, start, stop)
    sliceNode.line = self.code.Current.LineNo
    node = ASTStore(value, ASTSubscr(container, sliceNode))
    node.line = self.code.Current.LineNo
    self.curBlock.append(node)


def handleStoreSubscr(self):
    if self.unpack:
        subscrNode = self.dataStack.pop()
        destNode = self.dataStack.pop()

        saveNode = ASTSubscr(destNode, subscrNode)

        tupleNode = self.dataStack.top()
        if isinstance(tupleNode, ASTTuple):
            tupleNode.add(saveNode)
        else:
            # Preserve original debug-gated warning (printed to stderr in JS).
            print("Something TERRIBLE happened!\n", file=sys.stderr, end='')

        self.unpack -= 1
        if self.unpack <= 0:
            self.dataStack.pop()
            seqNode = self.dataStack.pop()
            if isinstance(seqNode, ASTChainStore):
                seqNode.line = self.code.Current.LineNo
                self.append_to_chain_store(seqNode, tupleNode)
            else:
                node = ASTStore(seqNode, tupleNode)
                node.line = self.code.Current.LineNo
                self.curBlock.append(node)
    else:
        subscrNode = self.dataStack.pop()
        destNode = self.dataStack.pop()
        srcNode = self.dataStack.pop()

        # If variable annotations are enabled, we'll need to check for them here.
        # Python handles a variable annotation by setting:
        # __annotations__['var-name'] = type
        found_annotated_var = (self.variable_annotations
                               and isinstance(destNode, ASTName)
                               and destNode.name == "__annotations__")

        if found_annotated_var:
            # Annotations can be done alone or as part of an assignment.
            # In the case of an assignment, we'll see a NODE_STORE on the self.dataStack.
            if not self.curBlock.nodes.empty():
                # Replace the existing NODE_STORE with a new one that includes the annotation.
                store = self.curBlock.nodes.top()
                if isinstance(store, ASTStore) and storeMatchesAnnotation(store, subscrNode):
                    self.curBlock.removeLast()
                    node = ASTStore(store.src,
                                    ASTAnnotatedVar(subscrNode, srcNode))
                    node.line = self.code.Current.LineNo
                    self.curBlock.append(node)
                else:
                    node = ASTAnnotatedVar(subscrNode, srcNode)
                    node.line = self.code.Current.LineNo
                    self.curBlock.append(node)
            else:
                node = ASTAnnotatedVar(subscrNode, srcNode)
                node.line = self.code.Current.LineNo
                self.curBlock.append(node)
        else:
            if isinstance(destNode, ASTMap):
                destNode.add(subscrNode, srcNode)
            elif isinstance(srcNode, ASTChainStore):
                self.append_to_chain_store(srcNode, ASTSubscr(destNode, subscrNode))
            else:
                node = ASTStore(srcNode,
                                ASTSubscr(destNode, subscrNode))
                node.line = self.code.Current.LineNo
                self.curBlock.append(node)
