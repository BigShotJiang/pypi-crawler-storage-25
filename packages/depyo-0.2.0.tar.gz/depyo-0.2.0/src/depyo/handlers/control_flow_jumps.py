"""Translated from lib/handlers/control_flow_jumps.js"""
from __future__ import annotations

from depyo.ast_node import (
    ASTBlock,
    ASTCondBlock,
    ASTBinary,
    ASTCompare,
    ASTUnary,
    ASTNone,
    ASTCall,
    ASTName,
    ASTRaise,
    ASTKeyword,
)
from depyo.handlers._util import debug_log, debug_error


def isInsideLoop(blocks):
    return any(b.blockType in (ASTBlock.BlockType.While, ASTBlock.BlockType.For, ASTBlock.BlockType.AsyncFor) for b in blocks)


def findBackwardJump(code, startIndex, currentOffset, backJumpOpcodes):
    instructions = code.Instructions or []
    maxLookahead = 100
    i = startIndex + 1
    while i < len(instructions) and i <= startIndex + maxLookahead:
        instr = instructions[i]
        if not instr:
            break
        if instr.OpCodeID in backJumpOpcodes and instr.JumpTarget <= currentOffset:
            return instr
        # Bail out once we are well past the current conditional to avoid accidental matches.
        if instr.Offset - currentOffset > 300:
            break
        i += 1
    return None


# Detect a Py2.x (or early-Py3) boolean expression chain rooted at the current
# JUMP_IF_* instruction. An expression chain converges at a value consumer
# (STORE_*, RETURN_*, COMPARE_OP, BINARY_*, UNARY_*, CALL_*, POP_JUMP_IF_*,
# another JUMP_IF_* for nested chains) without crossing block-level opcodes.
# This distinguishes `a = b and c or d` (expression, consumer=STORE_NAME) from
# `if b: pass; if c: pass` (control flow, two separate If blocks).
def isBoolExprChain(ctx):
    OpCodes = ctx.OpCodes
    chainJumpOps = set(v for v in [
        OpCodes.JUMP_IF_FALSE_A,
        OpCodes.JUMP_IF_TRUE_A,
        OpCodes.JUMP_IF_FALSE_OR_POP_A,
        OpCodes.JUMP_IF_TRUE_OR_POP_A,
    ] if v is not None)
    valueOps = set(v for v in [
        OpCodes.LOAD_NAME_A, OpCodes.LOAD_FAST_A, OpCodes.LOAD_CONST_A,
        OpCodes.LOAD_GLOBAL_A, OpCodes.LOAD_ATTR_A, OpCodes.LOAD_DEREF_A,
        OpCodes.LOAD_CLASSDEREF_A, OpCodes.LOAD_CLOSURE_A,
        OpCodes.LOAD_FAST_CHECK_A, OpCodes.LOAD_FAST_AND_CLEAR_A,
        OpCodes.LOAD_FAST_LOAD_FAST_A,
        OpCodes.LOAD_LOCALS, OpCodes.LOAD_BUILD_CLASS,
        OpCodes.POP_TOP, OpCodes.POP_TOP_A,
        OpCodes.DUP_TOP, OpCodes.DUP_TOP_A, OpCodes.ROT_TWO, OpCodes.ROT_THREE, OpCodes.ROT_FOUR,
        OpCodes.COPY_A, OpCodes.SWAP_A,
        OpCodes.COMPARE_OP, OpCodes.COMPARE_OP_A,
        OpCodes.UNARY_POSITIVE, OpCodes.UNARY_NEGATIVE, OpCodes.UNARY_NOT, OpCodes.UNARY_INVERT, OpCodes.UNARY_CONVERT,
        OpCodes.BINARY_ADD, OpCodes.BINARY_SUBTRACT, OpCodes.BINARY_MULTIPLY, OpCodes.BINARY_DIVIDE,
        OpCodes.BINARY_TRUE_DIVIDE, OpCodes.BINARY_FLOOR_DIVIDE, OpCodes.BINARY_MODULO, OpCodes.BINARY_POWER,
        OpCodes.BINARY_LSHIFT, OpCodes.BINARY_RSHIFT, OpCodes.BINARY_AND, OpCodes.BINARY_OR, OpCodes.BINARY_XOR,
        OpCodes.BINARY_SUBSCR, OpCodes.BINARY_SUBSCR_A,
        OpCodes.BINARY_OP_A, OpCodes.BINARY_OP,
        OpCodes.BINARY_MATRIX_MULTIPLY,
        OpCodes.IS_OP_A, OpCodes.CONTAINS_OP_A,
    ] if v is not None)
    consumerOps = set(v for v in [
        OpCodes.STORE_NAME_A, OpCodes.STORE_FAST_A, OpCodes.STORE_GLOBAL_A,
        OpCodes.STORE_DEREF_A, OpCodes.STORE_ATTR_A,
        OpCodes.STORE_SUBSCR, OpCodes.STORE_SUBSCR_A,
        OpCodes.RETURN_VALUE, OpCodes.RETURN_VALUE_A, OpCodes.RETURN_CONST_A,
        OpCodes.POP_JUMP_IF_FALSE_A, OpCodes.POP_JUMP_IF_TRUE_A,
        OpCodes.POP_JUMP_FORWARD_IF_FALSE_A, OpCodes.POP_JUMP_FORWARD_IF_TRUE_A,
        OpCodes.POP_JUMP_FORWARD_IF_NONE_A, OpCodes.POP_JUMP_FORWARD_IF_NOT_NONE_A,
        OpCodes.POP_JUMP_BACKWARD_IF_NONE_A, OpCodes.POP_JUMP_BACKWARD_IF_NOT_NONE_A,
        OpCodes.POP_JUMP_IF_NONE_A, OpCodes.POP_JUMP_IF_NOT_NONE_A,
        OpCodes.CALL_FUNCTION_A, OpCodes.CALL_FUNCTION_KW_A, OpCodes.CALL_FUNCTION_EX_A,
        OpCodes.CALL_A, OpCodes.CALL_KW_A, OpCodes.CALL_METHOD_A,
        OpCodes.PRINT_ITEM, OpCodes.PRINT_ITEM_TO, OpCodes.PRINT_EXPR,
    ] if v is not None)

    startIdx = ctx.code.CurrentInstructionIndex
    instructions = ctx.code.Instructions or []
    if startIdx >= len(instructions) or not instructions[startIdx] or instructions[startIdx].OpCodeID not in chainJumpOps:
        return False

    maxTarget = instructions[startIdx].JumpTarget
    if not maxTarget or maxTarget <= instructions[startIdx].Offset:
        return False

    maxLookahead = 64
    i = startIdx + 1
    while i < len(instructions) and i - startIdx <= maxLookahead:
        instr = instructions[i]
        if not instr:
            return False
        # Reached convergence offset - inspect what's there
        if instr.Offset >= maxTarget:
            # Another JUMP_IF_* at the convergence -> nested chain continuation
            if instr.OpCodeID in chainJumpOps:
                return True
            if instr.OpCodeID in consumerOps:
                return True
            # POP_TOP at convergence = control flow cleanup (if-body), not expression.
            if instr.OpCodeID == OpCodes.POP_TOP or instr.OpCodeID == OpCodes.POP_TOP_A:
                return False
            # Any value op at the convergence means expression continues
            if instr.OpCodeID in valueOps:
                return True
            return False
        # Extend the chain by further JUMP_IF_* targets
        if instr.OpCodeID in chainJumpOps:
            if instr.JumpTarget > maxTarget:
                maxTarget = instr.JumpTarget
            i += 1
            continue
        # Only value-level opcodes allowed inside the chain window
        if instr.OpCodeID not in valueOps:
            return False
        i += 1
    return False


# Frame-based reconstruction of Py2.x (and early-Py3) boolean expression chains.
def resolveBoolChainFrames(ctx, atOffset):
    if not getattr(ctx, 'boolChainStack', None) or len(ctx.boolChainStack) == 0:
        return
    while len(ctx.boolChainStack) > 0:
        frame = ctx.boolChainStack[-1]
        if frame['target'] > atOffset:
            break
        ctx.boolChainStack.pop()
        if len(ctx.dataStack) == 0:
            # Stack underflow means we misread the chain; drop remaining frames
            ctx.boolChainStack = []
            return
        rhs = ctx.dataStack.pop()
        op = (ASTBinary.BinOp.LogicalAnd if frame['op'] == 'AND'
              else ASTBinary.BinOp.LogicalOr)
        combined = ASTBinary(frame['lhs'], rhs, op)
        combined.line = ctx.code.Current.LineNo if ctx.code.Current is not None else 0
        ctx.dataStack.append(combined)


def tryStartBoolChain(ctx):
    OpCodes = ctx.OpCodes
    peekJumps = [v for v in [OpCodes.JUMP_IF_FALSE_A, OpCodes.JUMP_IF_TRUE_A] if v is not None]
    if ctx.code.Current.OpCodeID not in peekJumps:
        return False
    if ctx.inMatchPattern:
        return False
    if len(ctx.dataStack) == 0:
        return False
    if not isBoolExprChain(ctx):
        return False

    rawTarget = ctx.code.Current.JumpTarget
    if not rawTarget or rawTarget <= ctx.code.Current.Offset:
        return False

    isFalseJump = ctx.code.Current.OpCodeID == OpCodes.JUMP_IF_FALSE_A

    target = rawTarget
    instructions = ctx.code.Instructions or []
    curIdx = ctx.code.CurrentInstructionIndex
    chainJumpOps = set(v for v in [OpCodes.JUMP_IF_FALSE_A, OpCodes.JUMP_IF_TRUE_A] if v is not None)
    popOps = set(v for v in [OpCodes.POP_TOP, OpCodes.POP_TOP_A] if v is not None)
    rawTargetIdx = -1
    for idx, ins in enumerate(instructions):
        if ins and ins.Offset == rawTarget:
            rawTargetIdx = idx
            break
    if (rawTargetIdx > curIdx + 1
            and instructions[rawTargetIdx] is not None
            and instructions[rawTargetIdx].OpCodeID in popOps):
        j = rawTargetIdx - 1
        while j > curIdx:
            instr = instructions[j]
            if not instr:
                break
            if instr.OpCodeID in chainJumpOps and instr.JumpTarget >= rawTarget:
                target = instr.Offset
                break
            j -= 1

    lhs = ctx.dataStack.pop()
    if not hasattr(ctx, 'boolChainStack') or ctx.boolChainStack is None:
        ctx.boolChainStack = []
    ctx.boolChainStack.append({'target': target, 'op': 'AND' if isFalseJump else 'OR', 'lhs': lhs})

    nxt = ctx.code.Next
    if nxt is not None and nxt.OpCodeID == OpCodes.POP_TOP:
        ctx.code.GoNext()
    return True


def tryStartConditionalExpression(ctx, cond, falseOffset):
    if not cond or falseOffset <= ctx.code.Current.Offset:
        return False
    falseIdx = ctx.code.GetIndexByOffset(falseOffset)
    if falseIdx < 0:
        return False

    storeOps = set(v for v in [
        ctx.OpCodes.STORE_FAST_A,
        ctx.OpCodes.STORE_NAME_A,
        ctx.OpCodes.STORE_GLOBAL_A,
        ctx.OpCodes.STORE_DEREF_A,
        ctx.OpCodes.STORE_ATTR_A,
        ctx.OpCodes.STORE_SUBSCR,
        ctx.OpCodes.STORE_SUBSCR_A,
        ctx.OpCodes.POP_TOP,
        ctx.OpCodes.POP_TOP_A,
        ctx.OpCodes.RETURN_VALUE,
        ctx.OpCodes.RETURN_VALUE_A,
        ctx.OpCodes.RETURN_CONST_A,
        ctx.OpCodes.RAISE_VARARGS_A,
    ] if v is not None)
    blockOpeners = set(v for v in [
        ctx.OpCodes.SETUP_EXCEPT_A,
        ctx.OpCodes.SETUP_FINALLY_A,
        ctx.OpCodes.SETUP_LOOP_A,
        ctx.OpCodes.SETUP_WITH_A,
        ctx.OpCodes.SETUP_ASYNC_WITH_A,
        ctx.OpCodes.FOR_ITER_A,
    ] if v is not None)

    joinInstr = None
    for i in range(ctx.code.CurrentInstructionIndex + 1, falseIdx):
        instr = ctx.code.Instructions[i]
        if not instr:
            continue
        if instr.OpCodeID in blockOpeners:
            return False
        if instr.OpCodeID in (ctx.OpCodes.JUMP_FORWARD_A, ctx.OpCodes.JUMP_ABSOLUTE_A):
            prev = ctx.code.Instructions[i - 1] if i - 1 >= 0 else None
            if prev and prev.OpCodeID in storeOps:
                return False
            target = instr.JumpTarget if instr.JumpTarget is not None else -1
            if target > falseOffset and target <= falseOffset + 50:
                joinInstr = instr
                break

    if not joinInstr:
        return False

    if not hasattr(ctx, 'pendingConditionalExprs') or ctx.pendingConditionalExprs is None:
        ctx.pendingConditionalExprs = []
    ctx.pendingConditionalExprs.append({
        'cond': cond,
        'falseOffset': falseOffset,
        'joinOffset': joinInstr.JumpTarget,
        'trueValue': None,
        'startOffset': ctx.code.Current.Offset,
    })
    return True


def captureTrueBranchForConditional(ctx):
    if not getattr(ctx, 'pendingConditionalExprs', None):
        return False
    target = ctx.code.Current.JumpTarget
    pending = None
    for p in ctx.pendingConditionalExprs:
        if p['joinOffset'] == target:
            pending = p
            break
    if not pending:
        return False
    if not len(ctx.dataStack):
        return False
    blockOpeners = set(v for v in [
        ctx.OpCodes.SETUP_EXCEPT_A,
        ctx.OpCodes.SETUP_FINALLY_A,
        ctx.OpCodes.SETUP_LOOP_A,
        ctx.OpCodes.SETUP_WITH_A,
        ctx.OpCodes.SETUP_ASYNC_WITH_A,
        ctx.OpCodes.FOR_ITER_A,
    ] if v is not None)
    startIdx = ctx.code.GetIndexByOffset(pending['startOffset'])
    curIdx = ctx.code.CurrentInstructionIndex
    if startIdx >= 0:
        for i in range(startIdx + 1, curIdx):
            instr = ctx.code.Instructions[i]
            if instr and instr.OpCodeID in blockOpeners:
                return False
    pending['trueValue'] = ctx.dataStack.pop()
    return True


def handleJumpIfFalseA(self):
    processJumpOps(self)


def handleJumpIfTrueA(self):
    processJumpOps(self)


def handleJumpIfFalseOrPopA(self):
    processJumpOps(self)


def handleJumpIfTrueOrPopA(self):
    processJumpOps(self)


def handlePopJumpIfFalseA(self):
    processJumpOps(self)


def handlePopJumpIfTrueA(self):
    processJumpOps(self)


def handlePopJumpForwardIfFalseA(self):
    processJumpOps(self)


def handlePopJumpForwardIfTrueA(self):
    processJumpOps(self)


def handlePopJumpForwardIfNoneA(self):
    processJumpOps(self)


def handlePopJumpForwardIfNotNoneA(self):
    processJumpOps(self)


def handlePopJumpBackwardIfNoneA(self):
    processJumpOps(self)


def handlePopJumpBackwardIfNotNoneA(self):
    processJumpOps(self)


def handlePopJumpIfNoneA(self):
    processJumpOps(self)


def handlePopJumpIfNotNoneA(self):
    processJumpOps(self)


def handleInstrumentedPopJumpIfFalseA(self):
    processJumpOps(self)


def handleInstrumentedPopJumpIfTrueA(self):
    processJumpOps(self)


def handleInstrumentedPopJumpIfNoneA(self):
    processJumpOps(self)


def handleInstrumentedPopJumpIfNotNoneA(self):
    processJumpOps(self)


def processJumpOps(self):
    if self.skipNextJump:
        self.skipNextJump = False
        nxt = self.code.Next
        if nxt is not None and nxt.OpCodeID == self.OpCodes.POP_TOP:
            self.code.GoNext()
        return

    if tryStartBoolChain(self):
        return

    def wrapNoneComparison(expectNone):
        value = self.dataStack.pop()
        cmp = ASTCompare(
            value,
            ASTNone(),
            ASTCompare.CompareOp.Is if expectNone else ASTCompare.CompareOp.IsNot,
        )
        cmp.line = self.code.Current.LineNo
        self.dataStack.append(cmp)

    jumpIfNotNoneOpcodes = [
        self.OpCodes.POP_JUMP_FORWARD_IF_NOT_NONE_A,
        self.OpCodes.POP_JUMP_BACKWARD_IF_NOT_NONE_A,
        self.OpCodes.POP_JUMP_IF_NOT_NONE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NOT_NONE_A,
    ]

    jumpIfNoneOpcodes = [
        self.OpCodes.POP_JUMP_FORWARD_IF_NONE_A,
        self.OpCodes.POP_JUMP_BACKWARD_IF_NONE_A,
        self.OpCodes.POP_JUMP_IF_NONE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NONE_A,
    ]

    if self.code.Current.OpCodeID in jumpIfNoneOpcodes:
        wrapNoneComparison(True)
    elif self.code.Current.OpCodeID in jumpIfNotNoneOpcodes:
        wrapNoneComparison(False)

    if self.inMatchPattern:
        self.debug(f"[processJumpOps] Inside match statement - tracking pattern instead of creating if block")

        if self.code.Current.OpCodeID in (
            self.OpCodes.POP_JUMP_IF_FALSE_A,
            self.OpCodes.POP_JUMP_FORWARD_IF_FALSE_A,
            self.OpCodes.POP_JUMP_IF_TRUE_A,
            self.OpCodes.POP_JUMP_FORWARD_IF_TRUE_A,
            self.OpCodes.POP_JUMP_FORWARD_IF_NONE_A,
            self.OpCodes.POP_JUMP_FORWARD_IF_NOT_NONE_A,
            self.OpCodes.POP_JUMP_BACKWARD_IF_NONE_A,
            self.OpCodes.POP_JUMP_BACKWARD_IF_NOT_NONE_A,
            self.OpCodes.POP_JUMP_IF_NONE_A,
            self.OpCodes.POP_JUMP_IF_NOT_NONE_A,
            self.OpCodes.INSTRUMENTED_POP_JUMP_IF_FALSE_A,
            self.OpCodes.INSTRUMENTED_POP_JUMP_IF_TRUE_A,
            self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NONE_A,
            self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NOT_NONE_A,
        ):
            self.dataStack.pop()

        return

    chainJumpOps = [v for v in [
        self.OpCodes.JUMP_IF_FALSE_A,
        self.OpCodes.JUMP_IF_TRUE_A,
        self.OpCodes.JUMP_IF_FALSE_OR_POP_A,
        self.OpCodes.JUMP_IF_TRUE_OR_POP_A,
    ] if v is not None]
    keepOpenForChain = (self.code.Current.OpCodeID in chainJumpOps
                        and self.curBlock.size == 0
                        and self.curBlock.end == self.code.Current.Offset
                        and self.curBlock.blockType in (ASTBlock.BlockType.If, ASTBlock.BlockType.Elif, ASTBlock.BlockType.While)
                        and isBoolExprChain(self))

    while (not keepOpenForChain
           and self.curBlock.end > 0
           and self.curBlock.end <= self.code.Current.Offset
           and self.curBlock.blockType != ASTBlock.BlockType.Main
           and len(self.blocks) > 1):

        debug_log(f"[processJumpOps] Closing ended block {self.curBlock.type_str}({self.curBlock.start}-{self.curBlock.end}) at offset {self.code.Current.Offset}")

        closedBlock = self.blocks.pop()
        self.curBlock = self.blocks.top()
        self.curBlock.append(closedBlock)

        debug_log(f"  -> Appended to {self.curBlock.type_str}({self.curBlock.start}-{self.curBlock.end}), now has {len(self.curBlock.nodes)} nodes")

    if self.ignoreNextConditional:
        self.ignoreNextConditional = False
        baseDepth = self.cleanupStackDepth if self.cleanupStackDepth else len(self.dataStack)
        while len(self.dataStack) >= baseDepth:
            self.dataStack.pop()
        self.cleanupStackDepth = None
        return

    cond = self.dataStack.top()
    ifblk = None
    popped = ASTCondBlock.InitCondition.Uninited

    if self.code.Current.OpCodeID in (
        self.OpCodes.POP_JUMP_IF_FALSE_A,
        self.OpCodes.POP_JUMP_IF_TRUE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_FALSE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_TRUE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_NONE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_NOT_NONE_A,
        self.OpCodes.POP_JUMP_BACKWARD_IF_NONE_A,
        self.OpCodes.POP_JUMP_BACKWARD_IF_NOT_NONE_A,
        self.OpCodes.POP_JUMP_IF_NONE_A,
        self.OpCodes.POP_JUMP_IF_NOT_NONE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_FALSE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_TRUE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NONE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NOT_NONE_A,
    ):
        # Pop condition before the jump
        self.dataStack.pop()
        popped = ASTCondBlock.InitCondition.PrePopped
    elif self.code.Current.OpCodeID in (
        self.OpCodes.JUMP_IF_FALSE_OR_POP_A,
        self.OpCodes.JUMP_IF_TRUE_OR_POP_A,
        self.OpCodes.JUMP_IF_FALSE_A,
        self.OpCodes.JUMP_IF_TRUE_A,
    ):
        # Pop condition only if condition is met
        self.dataStack.pop()
        popped = ASTCondBlock.InitCondition.Popped

    # "Jump if true" means "Jump if not false"
    neg = self.code.Current.OpCodeID in (
        self.OpCodes.JUMP_IF_TRUE_A, self.OpCodes.JUMP_IF_TRUE_OR_POP_A,
        self.OpCodes.POP_JUMP_IF_TRUE_A, self.OpCodes.POP_JUMP_FORWARD_IF_TRUE_A,
        self.OpCodes.POP_JUMP_BACKWARD_IF_TRUE_A, self.OpCodes.INSTRUMENTED_POP_JUMP_IF_TRUE_A,
    )

    offs = self.code.Current.Argument
    if self.object.Reader.versionCompare(3, 10) >= 0:
        offs *= 2  # BPO-27129
    if (self.object.Reader.versionCompare(3, 12) >= 0
            or self.code.Current.OpCodeID in (
                self.OpCodes.JUMP_IF_FALSE_A, self.OpCodes.JUMP_IF_TRUE_A,
                self.OpCodes.POP_JUMP_FORWARD_IF_TRUE_A, self.OpCodes.POP_JUMP_FORWARD_IF_FALSE_A,
                self.OpCodes.POP_JUMP_FORWARD_IF_NONE_A, self.OpCodes.POP_JUMP_FORWARD_IF_NOT_NONE_A,
                self.OpCodes.POP_JUMP_IF_NONE_A, self.OpCodes.POP_JUMP_IF_NOT_NONE_A,
                self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NONE_A, self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NOT_NONE_A,
            )):
        # Offset is relative in these cases
        nxt = self.code.Next
        offs += (nxt.Offset if nxt is not None else 0)

    rawJumpTarget = offs  # target before block end normalization
    offs = self.code.FindEndOfBlock(offs)[0]

    condJumpOpcodes = set([
        self.OpCodes.POP_JUMP_IF_FALSE_A,
        self.OpCodes.POP_JUMP_IF_TRUE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_FALSE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_TRUE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_NONE_A,
        self.OpCodes.POP_JUMP_FORWARD_IF_NOT_NONE_A,
        self.OpCodes.POP_JUMP_BACKWARD_IF_NONE_A,
        self.OpCodes.POP_JUMP_BACKWARD_IF_NOT_NONE_A,
        self.OpCodes.POP_JUMP_IF_NONE_A,
        self.OpCodes.POP_JUMP_IF_NOT_NONE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_FALSE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_TRUE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NONE_A,
        self.OpCodes.INSTRUMENTED_POP_JUMP_IF_NOT_NONE_A,
    ])
    backJumpOpcodes = [
        self.OpCodes.JUMP_ABSOLUTE_A,
        self.OpCodes.JUMP_BACKWARD_A,
        self.OpCodes.JUMP_BACKWARD_NO_INTERRUPT_A,
    ]

    # Python 3.8+ while-loops no longer emit SETUP_LOOP; detect via backward jumps.
    if (not self.inMatchPattern
            and self.code.Current.OpCodeID in condJumpOpcodes
            and not isInsideLoop(self.blocks)):
        backJump = findBackwardJump(self.code, self.code.CurrentInstructionIndex, self.code.Current.Offset, backJumpOpcodes)
        if backJump and offs > backJump.Offset:
            loopStart = backJump.JumpTarget
            whileBlk = ASTCondBlock(ASTBlock.BlockType.While, loopStart, offs, None, False)
            whileBlk.line = self.code.Current.LineNo
            self.blocks.append(whileBlk)
            self.curBlock = whileBlk

    isEgMatchCall = (isinstance(cond, ASTCall)
                     and isinstance(cond.func, ASTName)
                     and cond.func.name == "__check_eg_match__")
    isExceptCompare = (isinstance(cond, ASTCompare)
                       and cond.op == ASTCompare.CompareOp.Exception)

    if (not self.inMatchPattern
            and not isExceptCompare and not isEgMatchCall
            and self.code.Current.OpCodeID in condJumpOpcodes
            and tryStartConditionalExpression(self, cond, rawJumpTarget)):
        return

    if (self.code.Current.OpCodeID in (self.OpCodes.JUMP_IF_FALSE_A, self.OpCodes.JUMP_IF_TRUE_A)
            and self.code.Next is not None
            and self.code.Next.OpCodeID == self.OpCodes.POP_TOP):
        self.code.GoNext()

    cond_name = type(cond).__name__ if cond is not None else None
    debug_log(f"\nConditional jump at offset {self.code.Current.Offset}: curBlock={self.curBlock.type_str} (type={self.curBlock.blockType}), size={self.curBlock.size}, inited={self.curBlock.inited}")
    if self.curBlock.size > 0:
        debug_log(f"  Block nodes: {[type(n).__name__ for n in self.curBlock.nodes]}")

    if isExceptCompare or isEgMatchCall:
        if isExceptCompare:
            matchType = cond.right
        else:
            matchType = cond.pparams[1] if (getattr(cond, 'pparams', None) and len(cond.pparams) > 1) else None
        mt_name = type(matchType).__name__ if matchType is not None else None
        mt_frag = matchType.codeFragment() if (matchType is not None and callable(getattr(matchType, 'codeFragment', None))) else None
        debug_log(f"  EXCEPTION MATCH detected: Creating Except block with condition={mt_name} {mt_frag}")

        handlerEnd = self.findExceptionHandlerEnd(self.code.Current.Offset) if callable(getattr(self, 'findExceptionHandlerEnd', None)) else None
        if (self.curBlock.blockType == ASTBlock.BlockType.Except
                and self.curBlock.condition is None):
            self.curBlock.condition = matchType
            if handlerEnd:
                self.curBlock.end = handlerEnd
            self.curBlock.init()
            return
        else:
            end = handlerEnd or offs
            ifblk = ASTCondBlock(ASTBlock.BlockType.Except, self.code.Current.Offset, end, matchType, False)
            self.inExceptionTableHandler = True
    elif self.curBlock.blockType == ASTBlock.BlockType.Else:
        debug_log(f"  Checking ELIF conditions: size={self.curBlock.size}, blockType={self.curBlock.blockType}")
        if self.curBlock.size == 1:
            debug_log(f"    First node: {type(self.curBlock.nodes[0]).__name__}, blockType={self.curBlock.nodes[0].blockType}")

        elseHolder = self.blocks[len(self.blocks) - 2] if len(self.blocks) >= 2 else None
        priorSibling = (elseHolder.nodes[elseHolder.size - 1]
                        if (elseHolder is not None and elseHolder.size > 0)
                        else None)
        elseAttachesToIf = (isinstance(priorSibling, ASTCondBlock)
                            and (priorSibling.blockType == ASTBlock.BlockType.If
                                 or priorSibling.blockType == ASTBlock.BlockType.Elif))

        if (elseAttachesToIf
                and (self.curBlock.size == 0
                     or (self.curBlock.size == 1
                         and isinstance(self.curBlock.nodes[0], ASTCondBlock)
                         and self.curBlock.nodes[0].blockType == ASTBlock.BlockType.If))):
            # Collapse into elif statement
            debug_log(f"ELIF DETECTED: else block size={self.curBlock.size}, converting to elif at offset {self.code.Current.Offset}")
            startOffset = self.curBlock.start

            if self.curBlock.size == 1:
                self.curBlock.nodes.pop()

            self.blocks.pop()
            ifblk = ASTCondBlock(ASTBlock.BlockType.Elif, startOffset, offs, cond, neg)
    elif (self.curBlock.blockType == ASTBlock.BlockType.Else
          and self.curBlock.size > 0):
        # Else block not empty - elif not possible
        debug_log(f"ELIF NOT CREATED: else block size={self.curBlock.size} (not 0) at offset {self.code.Current.Offset}, nodes: {[type(n).__name__ for n in self.curBlock.nodes]}")

    if (self.curBlock.size == 0 and not self.curBlock.inited
            and self.curBlock.blockType == ASTBlock.BlockType.While
            and self.code.Current.LineNo == self.curBlock.line):
        # The condition for a while loop
        top = self.blocks.top()
        top.condition = cond
        top.negative = neg
        if popped:
            top.init(popped)

        cond_frag = cond.codeFragment() if (cond is not None and callable(getattr(cond, 'codeFragment', None))) else cond
        debug_log(f"[processJumpOps] Set while condition at offset {self.code.Current.Offset}: {cond_name} = {cond_frag}")
        return
    elif (self.curBlock.size == 0 and self.curBlock.end <= offs
          and self.curBlock.blockType in (ASTBlock.BlockType.If, ASTBlock.BlockType.Elif, ASTBlock.BlockType.While)):
        top = self.curBlock
        cond1 = top.condition
        self.blocks.pop()

        nxt = self.code.Next
        if (self.curBlock.end == offs
                or (nxt is not None and self.curBlock.end == nxt.Offset and not top.negative)):
            # if blah and blah
            newcond = ASTBinary(cond1, cond, ASTBinary.BinOp.LogicalAnd)
        else:
            # if <condition 1> or <condition 2>
            newcond = ASTBinary(cond1, cond, ASTBinary.BinOp.LogicalOr)
        newcond.line = self.code.Current.LineNo
        ifblk = ASTCondBlock(top.blockType, top.start, offs, newcond, neg)
    elif (self.curBlock.blockType == ASTBlock.BlockType.For
          and self.curBlock.comprehension
          and self.object.Reader.versionCompare(2, 7) >= 0):
        # Comprehension condition
        actualCond = cond
        if neg:
            actualCond = ASTUnary(cond, ASTUnary.UnaryOp.Not)
            actualCond.line = self.code.Current.LineNo
        self.curBlock.condition = actualCond
        return

    if not ifblk:
        shouldBeElif = False

        if len(self.blocks) > 0:
            parent = self.blocks.top()
            if parent.size > 0:
                lastNode = parent.nodes[parent.size - 1]

                lastNodeInStack = False
                for i in range(len(self.blocks)):
                    if self.blocks[i] is lastNode:
                        lastNodeInStack = True
                        break

                if (isinstance(lastNode, ASTCondBlock)
                        and (lastNode.blockType == ASTBlock.BlockType.If
                             or lastNode.blockType == ASTBlock.BlockType.Elif)
                        and not lastNodeInStack):

                    priorIsAssertGuard = (
                        lastNode.negative
                        and len(lastNode.nodes) == 1
                        and isinstance(lastNode.nodes[0], ASTRaise)
                    )

                    if not priorIsAssertGuard:
                        shouldBeElif = True

                        debug_log(f"ELIF DETECTED: Creating elif at offset {self.code.Current.Offset} (follows {lastNode.type_str} at {lastNode.start})")

        if shouldBeElif:
            ifblk = ASTCondBlock(ASTBlock.BlockType.Elif, self.code.Current.Offset, offs, cond, neg)
        else:
            ifblk = ASTCondBlock(ASTBlock.BlockType.If, self.code.Current.Offset, offs, cond, neg)
        ifblk.line = self.code.Current.LineNo

    if ifblk:
        if popped:
            ifblk.init(popped)

        self.blocks.append(ifblk)
        self.curBlock = self.blocks.top()


def handleJumpAbsoluteA(self):
    if self.skipNextJump:
        self.skipNextJump = False
        return

    while (self.curBlock.end > 0
           and self.curBlock.end <= self.code.Current.Offset
           and self.curBlock.blockType != ASTBlock.BlockType.Main
           and len(self.blocks) > 1):

        debug_log(f"[handleJumpAbsolute] Closing ended block {self.curBlock.type_str}({self.curBlock.start}-{self.curBlock.end}) at offset {self.code.Current.Offset}")

        closedBlock = self.blocks.pop()
        self.curBlock = self.blocks.top()
        self.curBlock.append(closedBlock)

        debug_log(f"  -> Appended to {self.curBlock.type_str}({self.curBlock.start}-{self.curBlock.end}), now has {len(self.curBlock.nodes)} nodes")

    offs = self.code.Current.Argument
    if self.object.Reader.versionCompare(3, 10) >= 0:
        offs *= 2  # 2 bytes size - BPO-27129

    if self.curBlock.blockType == ASTBlock.BlockType.Container:
        cont = self.curBlock
        nxt = self.code.Next
        cont_except = cont.except_
        if cont.hasExcept and nxt is not None and nxt.Offset <= cont_except:
            handlerEnd = cont_except
            cursor = cont_except
            for i in range(200):
                instr = self.code.PeekInstructionAtOffset(cursor)
                if not instr:
                    break
                if instr.OpCodeID == self.OpCodes.END_FINALLY:
                    handlerEnd = instr.Offset
                    break
                cursor = instr.Offset + (instr.Size or 3)
            cont.end = handlerEnd
            except_blk = ASTCondBlock(ASTBlock.BlockType.Except, self.code.Current.Offset, handlerEnd, None, False)
            except_blk.init()
            self.blocks.append(except_blk)
            self.curBlock = self.blocks.top()
            return

    nxt = self.code.Next
    if nxt is not None and offs <= nxt.Offset:
        if self.curBlock.blockType == ASTBlock.BlockType.For:
            is_jump_to_start = offs == self.curBlock.start
            should_pop_for_block = self.curBlock.comprehension
            should_add_for_block = (self.object.Reader.versionCompare(3, 8) >= 0
                                    and is_jump_to_start and not self.curBlock.comprehension)

            if should_pop_for_block or should_add_for_block:
                top = self.dataStack.top()

                from depyo.ast_node import ASTComprehension
                if isinstance(top, ASTComprehension):
                    top.addGenerator(self.curBlock)
                    self.blocks.pop()
                    self.curBlock = self.blocks.top()
                    if not (self.curBlock.blockType == ASTBlock.BlockType.For and self.curBlock.comprehension):
                        isBareStatement = top.kind == ASTComprehension.GENERATOR
                        if not isBareStatement and callable(getattr(self.code, 'PeekInstructionAtOffset', None)):
                            nxt2 = self.code.Next
                            scanOff = nxt2.Offset if nxt2 is not None else None
                            SKIP_OPS = [
                                self.OpCodes.DELETE_FAST_A,
                                self.OpCodes.DELETE_NAME_A,
                                self.OpCodes.DELETE_GLOBAL_A,
                                self.OpCodes.DELETE_DEREF_A,
                                self.OpCodes.JUMP_ABSOLUTE_A,
                                self.OpCodes.JUMP_FORWARD_A,
                            ]
                            for i in range(12):
                                if scanOff is None:
                                    break
                                ins = self.code.PeekInstructionAtOffset(scanOff)
                                if not ins:
                                    break
                                if ins.OpCodeID in SKIP_OPS:
                                    scanOff = ins.Offset + (ins.Size or 3)
                                    continue
                                if ins.OpCodeID == self.OpCodes.POP_TOP:
                                    nextIns = self.code.PeekInstructionAtOffset(ins.Offset + (ins.Size or 1))
                                    if nextIns and nextIns.OpCodeID in SKIP_OPS:
                                        scanOff = ins.Offset + (ins.Size or 1)
                                        continue
                                    isBareStatement = True
                                break
                        if isBareStatement:
                            comp = self.dataStack.pop()
                            self.curBlock.append(comp)
                else:
                    tmp = self.curBlock
                    self.blocks.pop()
                    self.curBlock = self.blocks.top()
                    if (should_add_for_block
                            or (self.curBlock is self.blocks[0] and len(self.curBlock.nodes) == 0)):
                        self.curBlock.append(tmp)
        elif self.curBlock.blockType == ASTBlock.BlockType.Else:
            self.blocks.pop()
            self.blocks.top().append(self.curBlock)
            self.curBlock = self.blocks.top()

            if (self.curBlock.blockType == ASTBlock.BlockType.Container
                    and not self.curBlock.hasFinally):
                self.blocks.pop()
                self.blocks.top().append(self.curBlock)
                self.curBlock = self.blocks.top()
        elif (self.curBlock.blockType == ASTBlock.BlockType.Except
              and callable(getattr(self.code, 'PeekInstructionAtOffset', None))
              and (self.code.Prev is None or self.code.Prev.OpCodeID not in (self.OpCodes.JUMP_ABSOLUTE_A, self.OpCodes.JUMP_FORWARD_A))
              and len(self.blocks) >= 2
              and self.blocks[len(self.blocks) - 2].blockType == ASTBlock.BlockType.Container):
            endFinallyAhead = False
            nxt2 = self.code.Next
            scan = nxt2.Offset if nxt2 is not None else None
            for i in range(4):
                if scan is None:
                    break
                instr = self.code.PeekInstructionAtOffset(scan)
                if not instr:
                    break
                if instr.OpCodeID == self.OpCodes.END_FINALLY:
                    endFinallyAhead = True
                    scan = instr.Offset + (instr.Size or 1)
                    break
                if instr.OpCodeID != self.OpCodes.POP_TOP:
                    break
                scan = instr.Offset + (instr.Size or 1)

            if endFinallyAhead:
                elseEnd = scan
                cursor = scan
                hasBody = False
                for i in range(200):
                    instr = self.code.PeekInstructionAtOffset(cursor)
                    if not instr:
                        break
                    if (instr.OpCodeID == self.OpCodes.JUMP_ABSOLUTE_A
                            and instr.JumpTarget == self.code.Current.JumpTarget):
                        elseEnd = instr.Offset + (instr.Size or 3)
                        break
                    if instr.OpCodeID == self.OpCodes.POP_BLOCK:
                        elseEnd = instr.Offset
                        break
                    hasBody = True
                    cursor = instr.Offset + (instr.Size or 3)

                if not hasBody:
                    # No else body - fall through to default jump handling.
                    pass
                else:
                    except_blk = self.blocks.pop()
                    self.curBlock = self.blocks.top()
                    if not except_blk.empty():
                        self.curBlock.append(except_blk)
                    if self.curBlock.blockType == ASTBlock.BlockType.Container:
                        self.curBlock.end = elseEnd

                    elseblk = ASTBlock(ASTBlock.BlockType.Else, self.code.Current.Offset, elseEnd)
                    elseblk.init()
                    self.blocks.append(elseblk)
                    self.curBlock = self.blocks.top()
                    return
        else:
            loopBlock = None
            for blockIdx in range(len(self.blocks) - 1, 0, -1):
                if self.blocks[blockIdx].blockType in (ASTBlock.BlockType.While, ASTBlock.BlockType.For, ASTBlock.BlockType.AsyncFor):
                    loopBlock = self.blocks[blockIdx]
                    break

            if not loopBlock:
                if (offs == self.code.Current.Offset
                        and self.object.Reader.versionCompare(3, 8) >= 0):
                    whileBlk = ASTCondBlock(ASTBlock.BlockType.While, offs, offs, None, False)
                    whileBlk.init()
                    whileBlk.line = self.code.Current.LineNo
                    whileBlk.append(ASTKeyword(ASTKeyword.Word.Pass))
                    self.curBlock.append(whileBlk)
                return

            if loopBlock.start > offs:
                if loopBlock.end > self.code.Current.Offset:
                    debug_log(f"[handleJumpAbsolute] Correcting loop end: {loopBlock.type_str}({loopBlock.start}-{loopBlock.end}) -> end={self.code.Current.Offset} (jump to outer at {offs})")
                    loopBlock.end = self.code.Current.Offset

            nxt2 = self.code.Next
            if nxt2 is not None and self.curBlock.end == nxt2.Offset:
                return

            if self.code.Prev is not None and self.code.Prev.OpCodeID in (self.OpCodes.JUMP_ABSOLUTE_A, self.OpCodes.JUMP_FORWARD_A):
                return

            if self.hasTerminatingKeyword(self.curBlock):
                return

            if (self.curBlock.blockType in (ASTBlock.BlockType.If, ASTBlock.BlockType.Elif, ASTBlock.BlockType.Else)
                    and len(self.curBlock.nodes) == 0):
                self.curBlock.append(ASTKeyword(ASTKeyword.Word.Continue))
                return

            blockEnd = loopBlock.end
            instr = self.code.PeekInstructionAtOffset(blockEnd)
            if not instr:
                return
            currentIndex = instr.InstructionIndex

            while blockEnd > loopBlock.start:
                if (instr.OpCodeID == self.OpCodes.JUMP_ABSOLUTE_A
                        and (instr.JumpTarget == loopBlock.start + 3
                             or instr.JumpTarget < loopBlock.start)):
                    currentIndex -= 1
                    instr = self.code.PeekInstructionAt(currentIndex)
                    blockEnd = instr.Offset
                else:
                    return

            if self.code.Current.Offset < blockEnd:
                self.curBlock.append(ASTKeyword(ASTKeyword.Word.Continue))

        # We're in a loop, this jumps back to the start
        return

    if self.curBlock.blockType == ASTBlock.BlockType.Container:
        cont = self.curBlock
        # EXPERIMENT
        nxt3 = self.code.Next
        cont_except = cont.except_
        if cont.hasExcept and nxt3 is not None and nxt3.Offset <= cont_except:
            except_blk = ASTCondBlock(ASTBlock.BlockType.Except, self.code.Current.Offset, self.code.Current.JumpTarget, None, False)
            except_blk.init()
            self.blocks.append(except_blk)
            self.curBlock = self.blocks.top()
        return

    prev = self.curBlock

    if len(self.blocks) > 1:
        while True:
            self.blocks.pop()
            self.blocks.top().append(prev)

            if prev.blockType in (ASTBlock.BlockType.If, ASTBlock.BlockType.Elif):
                top = self.blocks.top()
                next_blk = ASTBlock(ASTBlock.BlockType.Else, self.code.Current.Offset, top.end)
                top.end = self.code.Current.Offset
                if prev.inited == ASTCondBlock.InitCondition.PrePopped:
                    next_blk.init(ASTCondBlock.InitCondition.PrePopped)

                debug_log(f"ELSE BLOCK CREATED at offset {self.code.Current.Offset}, end={next_blk.end}")

                self.blocks.append(next_blk)
                prev = None
            elif prev.blockType == ASTBlock.BlockType.Except:
                top = self.blocks.top()
                next_blk = ASTCondBlock(ASTBlock.BlockType.Except, top.start, top.end, None, False)
                next_blk.init()

                self.blocks.append(next_blk)
                prev = None
            elif prev.blockType == ASTBlock.BlockType.Else:
                # Special case
                if self.blocks.top().blockType != ASTBlock.BlockType.Main:
                    prev = self.blocks.top()
                else:
                    prev = None
            else:
                prev = None

            if prev is None:
                break

    self.curBlock = self.blocks.top()


def handleJumpForwardA(self):
    processJumpForward(self)


def handleInstrumentedJumpForwardA(self):
    processJumpForward(self)


def handleJumpA(self):
    # Python 3.13+ JUMP: treat as forward jump
    processJumpForward(self)


def handleJumpNoInterruptA(self):
    # Python 3.13+ JUMP_NO_INTERRUPT: same as JUMP for decompilation
    processJumpForward(self)


def processJumpForward(self):
    if self.skipNextJump:
        self.skipNextJump = False
        return

    # Capture true-branch value for conditional expression (ternary) rewrites.
    if captureTrueBranchForConditional(self):
        return

    offs = self.code.Current.Argument
    if self.object.Reader.versionCompare(3, 10) >= 0:
        offs *= 2  # 2 bytes per offset as per BPO-27129

    if self.curBlock.blockType == ASTBlock.BlockType.Container:
        cont = self.curBlock
        if cont.hasExcept:
            nxt = self.code.Next
            self.curBlock.end = (nxt.Offset if nxt is not None else 0) + offs
            except_blk = ASTCondBlock(ASTBlock.BlockType.Except, self.code.Current.Offset, self.curBlock.end, None, False)
            except_blk.init()
            self.blocks.append(except_blk)
            self.curBlock = self.blocks.top()
        return

    prev = self.curBlock

    if len(self.blocks) > 1:
        while True:
            self.blocks.pop()

            if not self.blocks.empty():
                self.blocks.top().append(prev)

            if (prev.blockType == ASTBlock.BlockType.If
                    or prev.blockType == ASTBlock.BlockType.Elif):
                if offs < 3:
                    prev = None
                    if prev is None:
                        break
                    continue
                nxt = self.code.Next
                next_blk = ASTBlock(ASTBlock.BlockType.Else, self.code.Current.Offset, (nxt.Offset if nxt is not None else 0) + offs)
                if prev.inited == ASTCondBlock.InitCondition.PrePopped:
                    next_blk.init(ASTCondBlock.InitCondition.PrePopped)

                self.blocks.append(next_blk)
                prev = None
            elif prev.blockType == ASTBlock.BlockType.Except and offs > 2:
                if self.inExceptionGroup:
                    nxt = self.code.Next
                    jumpTarget = (nxt.Offset if nxt is not None else 0) + offs
                    hasNextEgMatch = False
                    scanOffset = nxt.Offset if nxt is not None else 0
                    for i in range(40):
                        if scanOffset > jumpTarget + 20:
                            break
                        instr = self.code.PeekInstructionAtOffset(scanOffset)
                        if not instr:
                            break
                        if instr.OpCodeID == self.OpCodes.CHECK_EG_MATCH:
                            hasNextEgMatch = True
                            break
                        if (instr.OpCodeID == self.OpCodes.CALL_INTRINSIC_2
                                or instr.OpCodeID == self.OpCodes.POP_EXCEPT
                                or instr.OpCodeID == self.OpCodes.RERAISE):
                            break
                        scanOffset += 2
                    if not hasNextEgMatch:
                        prev = None
                        break
                next_blk = None

                nxt = self.code.Next
                jumpTarget = (nxt.Offset if nxt is not None else 0) + offs
                nextIsElse = (nxt is not None and nxt.OpCodeID == self.OpCodes.END_FINALLY)
                if not nextIsElse and callable(getattr(self.code, 'PeekInstructionAtOffset', None)):
                    scan = nxt.Offset if nxt is not None else None
                    for i in range(4):
                        if scan is None or scan >= jumpTarget:
                            break
                        instr = self.code.PeekInstructionAtOffset(scan)
                        if not instr:
                            break
                        if instr.OpCodeID == self.OpCodes.END_FINALLY:
                            nextIsElse = True
                            break
                        if instr.OpCodeID != self.OpCodes.POP_TOP:
                            break
                        scan = instr.Offset + instr.Size

                if nextIsElse:
                    next_blk = ASTBlock(ASTBlock.BlockType.Else, self.code.Current.Offset, self.code.Current.JumpTarget)
                    next_blk.init()
                else:
                    next_blk = ASTCondBlock(ASTBlock.BlockType.Except, self.code.Current.Offset, (nxt.Offset if nxt is not None else 0) + offs, None, False)
                    next_blk.init()

                self.blocks.append(next_blk)
                prev = None
            elif prev.blockType == ASTBlock.BlockType.Else:
                prev = self.blocks.top()

                if prev.blockType == ASTBlock.BlockType.Main:
                    prev = None
            elif (prev.blockType == ASTBlock.BlockType.Try
                  and prev.end < (self.code.Next.Offset if self.code.Next is not None else 0) + offs):
                self.dataStack.pop()

                if self.blocks.top().blockType == ASTBlock.BlockType.Container:
                    cont = self.blocks.top()
                    if cont.hasExcept:
                        nxt = self.code.Next
                        except_blk = ASTCondBlock(ASTBlock.BlockType.Except, prev.end, (nxt.Offset if nxt is not None else 0) + offs, None, False)
                        except_blk.init()
                        self.blocks.append(except_blk)
                else:
                    debug_error("Something TERRIBLE happened!!\n")
                prev = None
            else:
                prev = None

            if prev is None:
                break

    self.curBlock = self.blocks.top()

    if self.curBlock.blockType == ASTBlock.BlockType.Except:
        nxt = self.code.Next
        self.curBlock.end = (nxt.Offset if nxt is not None else 0) + offs


def handleJumpBackwardA(self):
    # Python 3.11+ JUMP_BACKWARD opcode
    debug_log(f"[JUMP_BACKWARD] at offset {self.code.Current.Offset}, target_delta={self.code.Current.Argument}")
    # No action needed - loop control is implicit in block structure


def handleJumpBackwardNoInterruptA(self):
    # Python 3.11+ JUMP_BACKWARD_NO_INTERRUPT
    debug_log(f"[JUMP_BACKWARD_NO_INTERRUPT] at offset {self.code.Current.Offset}")
    # Same as JUMP_BACKWARD for decompiler purposes


def handleJumpIfNotExcMatchA(self):
    # Use same logic as other conditional jumps; stack top is comparison result.
    processJumpOps(self)


def handleNotTaken(self):
    # Instrumentation hint (3.13+) used in instrumented builds; ignore for decompilation.
    debug_log(f"[NOT_TAKEN] at offset {self.code.Current.Offset}")


def handleInstrumentedNotTakenA(self):
    # Instrumentation marker for untaken branch; no stack effect.
    debug_log(f"[INSTRUMENTED_NOT_TAKEN] at offset {self.code.Current.Offset}")
