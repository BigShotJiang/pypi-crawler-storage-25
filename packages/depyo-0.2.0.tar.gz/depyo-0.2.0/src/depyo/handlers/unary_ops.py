"""Translated from lib/handlers/unary_ops.js"""
from __future__ import annotations

from depyo.ast_node import (
    ASTCall,
    ASTFormattedValue,
    ASTConvert,
    ASTUnary,
)


def handleUnaryCall(self):
    funcNode = self.dataStack.pop()
    node = ASTCall(funcNode, [], [])
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleConvertValueA(self):
    # Python 3.14 CONVERT_VALUE: capture requested conversion for upcoming FORMAT_*.
    val = self.dataStack.pop()
    flag = self.code.Current.Argument
    conversion = ASTFormattedValue.ConversionFlag.None_

    if flag == 1:
        conversion = ASTFormattedValue.ConversionFlag.Str
    elif flag == 2:
        conversion = ASTFormattedValue.ConversionFlag.Repr
    elif flag == 3:
        conversion = ASTFormattedValue.ConversionFlag.ASCII

    if isinstance(val, ASTFormattedValue):
        val.m_conversion = conversion
        node = val
    else:
        node = ASTFormattedValue(val, conversion, None)
        node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleUnaryConvert(self):
    name = self.dataStack.pop()
    node = ASTConvert(name)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleUnaryInvert(self):
    arg = self.dataStack.pop()
    node = ASTUnary(arg, ASTUnary.UnaryOp.Invert)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleUnaryNegative(self):
    arg = self.dataStack.pop()
    node = ASTUnary(arg, ASTUnary.UnaryOp.Negative)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleUnaryNot(self):
    arg = self.dataStack.pop()
    node = ASTUnary(arg, ASTUnary.UnaryOp.Not)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleUnaryPositive(self):
    arg = self.dataStack.pop()
    node = ASTUnary(arg, ASTUnary.UnaryOp.Positive)
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleToBool(self):
    # Python 3.13+ TO_BOOL: normalize truthiness. Preserve stack value.
    arg = self.dataStack.pop()
    self.dataStack.append(arg)


def handleExitInitCheck(self):
    # Python 3.14 EXIT_INIT_CHECK: no-op for decompiler.
    pass
