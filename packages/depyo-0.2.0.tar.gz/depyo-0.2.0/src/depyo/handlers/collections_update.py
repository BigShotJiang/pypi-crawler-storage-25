"""Translated from lib/handlers/collections_update.js"""
from __future__ import annotations

from depyo.ast_node import (
    ASTBlock,
    ASTComprehension,
    ASTSubscr,
    ASTUnary,
    ASTBinary,
    ASTSet,
    ASTList,
    ASTTuple,
    ASTMap,
    ASTKwNamesMap,
    ASTConstMap,
    ASTObject,
    ASTCall,
    ASTName,
)
from depyo.handlers._util import debug_error


def handleSetAdd(self):
    handleSetAddA(self)


def handleSetAddA(self):
    value = self.dataStack.pop()

    # Check if this is a set comprehension first
    if self.curBlock.blockType == ASTBlock.BlockType.For and self.curBlock.comprehension:
        self.dataStack.pop()  # Pop the empty set
        node = ASTComprehension(value)
        node.line = self.code.Current.LineNo
        node.kind = ASTComprehension.SET
        self.dataStack.append(node)
        return

    # Normal set add
    setOffset = self.code.Current.Argument - 1 if self.code.Current.OpCodeID == self.OpCodes.SET_ADD_A else 0
    setNode = self.dataStack.top(setOffset)
    if not setNode or not callable(getattr(setNode, 'add', None)):
        debug_error(f"SET_ADD target missing or invalid at offset {self.code.Current.Offset}")
        return
    setNode.add(value)


def handleListAppend(self):
    processListAppend(self)


def handleListAppendA(self):
    processListAppend(self)


def processListAppend(self):
    value = self.dataStack.pop()
    list_node = self.dataStack.top()

    # Pre-3.8 list comprehensions can nest the LIST_APPEND inside if/and/or
    # blocks (e.g. `[o for o in xs if cond]`), so curBlock may be an If/Else
    # when the append fires. Walk up to find the enclosing For+comprehension.
    forBlock = None
    ifBlocks = []
    for i in range(len(self.blocks) - 1, -1, -1):
        blk = self.blocks[i]
        if blk.blockType == ASTBlock.BlockType.For and blk.comprehension:
            forBlock = blk
            break
        if blk.blockType == ASTBlock.BlockType.If:
            ifBlocks.append(blk)
        else:
            break

    if not forBlock:
        # Async comprehension inner code: no For+comp block exists because
        # GET_ANEXT iteration uses SETUP_EXCEPT instead of FOR_ITER.
        # Save the appended value so the reconstruction in function_calls.js
        # can use it as the comprehension's yield expression.
        self.object._asyncCompYieldExpr = value

    if forBlock:
        self.dataStack.pop()
        # Transfer any intervening if-filter conditions to the comprehension's
        # for-block, then close the intermediate if-blocks so the For+comp is
        # curBlock when JUMP_ABSOLUTE reaches the close path.
        for ifBlk in ifBlocks:
            cond = ifBlk.condition
            if not cond:
                continue
            if ifBlk.negative:
                notCond = ASTUnary(cond, ASTUnary.UnaryOp.Not)
                notCond.line = self.code.Current.LineNo
                cond = notCond
            if forBlock.condition:
                andCond = ASTBinary(forBlock.condition, cond, ASTBinary.BinOp.LogicalAnd)
                andCond.line = self.code.Current.LineNo
                forBlock.condition = andCond
            else:
                forBlock.condition = cond
        while self.curBlock is not forBlock and len(self.blocks) > 1:
            self.blocks.pop()
            self.curBlock = self.blocks.top()
        node = ASTComprehension(value)
        node.line = self.code.Current.LineNo
        self.dataStack.append(node)
    else:
        node = ASTSubscr(list_node, value)
        node.line = self.code.Current.LineNo
        self.dataStack.append(node)


def handleSetUpdateA(self):
    rhs = self.dataStack.pop()
    lhs = self.dataStack.pop()

    targetValues = list(lhs.values or []) if isinstance(lhs, ASTSet) else []
    rhsValues = collectIterableValues(rhs)

    if rhsValues is None:
        debug_error("Unsupported argument found for SET_UPDATE")
        self.dataStack.append(lhs)
        return

    node = ASTSet([*targetValues, *rhsValues])
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleListExtendA(self):
    rhs = self.dataStack.pop()
    lhs = self.dataStack.pop()

    if not isinstance(lhs, ASTList):
        debug_error("LIST_EXTEND target is not a list literal")
        self.dataStack.append(lhs)
        return

    appendValues = collectIterableValues(rhs)

    if appendValues is None or len(appendValues) == 0:
        debug_error("Unsupported argument found for LIST_EXTEND")
        self.dataStack.append(lhs)
        return

    lhs.values.extend(appendValues)

    self.dataStack.append(lhs)


def handleDictMergeA(self):
    dictToMerge = self.dataStack.pop()
    targetDict = self.dataStack.top()
    entries = collectMapEntries(dictToMerge)

    if not isinstance(targetDict, ASTMap) or entries is None:
        debug_error("Expected ASTMap for DICT_MERGE_A")
        return

    for entry in entries:
        targetDict.add(entry['key'], entry['value'])


def handleDictUpdateA(self):
    updateSource = self.dataStack.pop()
    targetDict = self.dataStack.top()

    if not isinstance(targetDict, ASTMap):
        debug_error("Expected ASTMap for DICT_UPDATE_A target")
        return

    if isinstance(updateSource, ASTCall) and isinstance(updateSource.func, ASTName) and updateSource.func.name == 'zip':
        # Handle case where updateSource is a zip of keys and values
        if len(updateSource.pparams) == 2:
            keys = updateSource.pparams[0]
            values = updateSource.pparams[1]
            if isinstance(keys, ASTList) and isinstance(values, ASTList) and len(keys.values) == len(values.values):
                for i in range(len(keys.values)):
                    targetDict.add(keys.values[i], values.values[i])
                return
            elif isinstance(keys, ASTTuple) and isinstance(values, ASTTuple) and len(keys.values) == len(values.values):
                for i in range(len(keys.values)):
                    targetDict.add(keys.values[i], values.values[i])
                return
            else:
                debug_error("Expected lists or tuples of equal length for zip in DICT_UPDATE_A")

    entries = collectMapEntries(updateSource)
    if entries is None:
        debug_error("Expected ASTMap or iterable for DICT_UPDATE_A")
        return

    for entry in entries:
        targetDict.add(entry['key'], entry['value'])


def collectIterableValues(node):
    if isinstance(node, (ASTList, ASTTuple, ASTSet)):
        return node.values or []

    if isinstance(node, ASTObject):
        obj = node.object
        if obj is not None and getattr(obj, 'ClassName', None) in ("Py_List", "Py_Tuple", "Py_SmallTuple", "Py_Set", "Py_FrozenSet"):
            return [ASTObject(value) for value in (obj.Value or [])]

    return None


def collectMapEntries(node):
    if isinstance(node, (ASTMap, ASTKwNamesMap)):
        return node.values or []

    if isinstance(node, ASTConstMap):
        keysArray = []
        if isinstance(node.keys, ASTObject):
            obj = node.keys.object
            if obj is not None and getattr(obj, 'ClassName', None) in ('Py_Tuple', 'Py_SmallTuple'):
                keysArray = [ASTObject(v) for v in (obj.Value or [])]
        elif isinstance(node.keys, list):
            keysArray = node.keys

        valuesArray = list(reversed(node.values)) if isinstance(node.values, list) else []
        count = min(len(keysArray), len(valuesArray))
        entries = []
        for i in range(count):
            entries.append({'key': keysArray[i], 'value': valuesArray[i]})
        return entries if len(entries) else None

    if isinstance(node, (ASTList, ASTTuple)):
        entries = []
        for pair in (node.values or []):
            if isinstance(pair, ASTTuple) and pair.values is not None and len(pair.values) == 2:
                entries.append({'key': pair.values[0], 'value': pair.values[1]})
        if len(entries):
            return entries

    if isinstance(node, ASTObject):
        obj = node.object
        if obj is not None and getattr(obj, 'ClassName', None) == "Py_Dict":
            return [
                {'key': ASTObject(kv['key']), 'value': ASTObject(kv['value'])}
                for kv in (obj.Value or [])
            ]

    return None
