"""Translated from lib/handlers/context_managers.js"""
from __future__ import annotations

from depyo.ast_node import (
    ASTBlock,
    ASTName,
    ASTWithBlock,
    ASTAsyncWithBlock,
    ASTObject,
    ASTNone,
    ASTReturn,
)
from depyo.handlers._util import debug_log, debug_error


# Helper function to extract WITH statement pattern from bytecode
# Pattern (Python 2.6-3.1 with SETUP_FINALLY, Python 3.2+ with SETUP_WITH):
#
# LOAD_*         (context manager)
# DUP_TOP
# LOAD_ATTR      (__exit__)
# STORE_FAST     (temp var)
# LOAD_ATTR      (__enter__)
# CALL_FUNCTION  0
# STORE_FAST     (temp var 2)
# SETUP_FINALLY/SETUP_WITH  <- we are here
# LOAD_FAST      (temp var 2)
# DELETE_FAST    (temp var 2)
# [STORE_FAST (variable) | POP_TOP]  <- variable name or no "as" clause
def extractWithPattern(self):
    # Look ahead to confirm this is a WITH pattern
    nextInstr = self.code.Next
    if not nextInstr:
        return None

    # After SETUP_FINALLY/SETUP_WITH, should have LOAD_FAST + DELETE_FAST
    if nextInstr.OpCodeID != self.OpCodes.LOAD_FAST_A:
        return None

    secondInstr = self.code.PeekInstructionAtOffset(nextInstr.Offset + 3)
    if not secondInstr or secondInstr.OpCodeID != self.OpCodes.DELETE_FAST_A:
        return None

    # Third instruction determines if there's an "as" clause
    thirdInstr = self.code.PeekInstructionAtOffset(secondInstr.Offset + 3)
    asVariable = None

    if thirdInstr and thirdInstr.OpCodeID == self.OpCodes.STORE_FAST_A:
        # Has "as variable"
        if thirdInstr.Name is None:
            raise RuntimeError(f"SETUP_WITH at offset {self.code.Current.Offset} (file offset {self.object.codeOffset + self.code.Current.Offset}): STORE_FAST has null Name (expected \"as\" variable)")
        asVariable = ASTName(str(thirdInstr.Name))
    elif thirdInstr and thirdInstr.OpCodeID == self.OpCodes.POP_TOP:
        # No "as" clause
        asVariable = None
    else:
        return None  # Not a WITH pattern

    # Look backward for the context manager expression
    ctxMgrExpr = None

    # Walk back to find LOAD_* instruction (context manager)
    # Scan by instruction index (not offset - instruction sizes vary!)
    for idx in range(self.code.CurrentInstructionIndex - 1, -1, -1):
        instr = self.code.Instructions[idx]
        if not instr:
            continue

        if instr.OpCodeID in (
            self.OpCodes.LOAD_FAST_A, self.OpCodes.LOAD_GLOBAL_A, self.OpCodes.LOAD_NAME_A,
            self.OpCodes.LOAD_DEREF_A, self.OpCodes.CALL_FUNCTION, self.OpCodes.CALL_FUNCTION_A,
            self.OpCodes.BINARY_SUBSCR, self.OpCodes.LOAD_ATTR_A,
        ):
            # Check if next instruction (by index) is DUP_TOP
            afterLoad = self.code.Instructions[idx + 1] if idx + 1 < len(self.code.Instructions) else None
            if afterLoad and afterLoad.OpCodeID == self.OpCodes.DUP_TOP:
                # Found it! Create AST node for the context manager
                if instr.OpCodeID in (
                    self.OpCodes.LOAD_FAST_A,
                    self.OpCodes.LOAD_GLOBAL_A,
                    self.OpCodes.LOAD_NAME_A,
                    self.OpCodes.LOAD_DEREF_A,
                ):
                    if instr.Name is None:
                        raise RuntimeError(f"SETUP_WITH at offset {self.code.Current.Offset} (file offset {self.object.codeOffset + self.code.Current.Offset}): {instr.InstructionName} at offset {instr.Offset} has null Name")
                    ctxMgrExpr = ASTName(str(instr.Name))
                else:
                    # CALL_FUNCTION/LOAD_ATTR/BINARY_SUBSCR: reconstructing the
                    # expression without replaying the stack isn't supported yet.
                    raise RuntimeError(f"SETUP_WITH at offset {self.code.Current.Offset} (file offset {self.object.codeOffset + self.code.Current.Offset}): unsupported context manager opcode {instr.InstructionName} at offset {instr.Offset} - needs stack replay")
                break

    return {
        'contextManager': ctxMgrExpr,
        'asVariable': asVariable,
    }


def handleSetupWithA(self):
    pattern = extractWithPattern(self)

    # Find the WITH_CLEANUP instruction to determine the actual end of the WITH block
    withEnd = self.code.Current.JumpTarget
    searchInstr = self.code.PeekInstructionAtOffset(withEnd)
    i = 0
    while i < 10 and searchInstr:
        if searchInstr.OpCodeID in (
            self.OpCodes.WITH_CLEANUP,
            self.OpCodes.WITH_CLEANUP_START,
            self.OpCodes.WITH_CLEANUP_FINISH,
        ):
            withEnd = searchInstr.Offset
            break
        searchInstr = self.code.PeekInstructionAtOffset(searchInstr.Offset + 3)
        i += 1

    withBlock = ASTWithBlock(self.code.Current.Offset, withEnd)

    if pattern:
        withBlock.expr = pattern['contextManager']
        withBlock.var = pattern['asVariable']

        # Skip the pattern instructions (LOAD_FAST, DELETE_FAST, STORE_FAST/POP_TOP)
        # These were already extracted into withBlock.expr and withBlock.var
        self.code.GoNext()  # Skip LOAD_FAST
        self.code.GoNext()  # Skip DELETE_FAST
        self.code.GoNext()  # Skip STORE_FAST or POP_TOP

    self.blocks.append(withBlock)
    self.curBlock = self.blocks.top()


def handleWithCleanupStart(self):
    handleWithCleanup(self)


def handleWithCleanup(self):
    # Async-with closure runs first because the 3.8+ pattern uses BEGIN_FINALLY
    # (no-op handler) instead of LOAD_CONST None - so the data stack may be
    # empty when WITH_CLEANUP_START fires. Don't gate on the None pop here.
    if (self.curBlock.blockType == ASTBlock.BlockType.AsyncWith
            and self.curBlock.end == self.code.Current.Offset):
        asyncWithBlock = self.curBlock

        # Skip the standard 4-op cleanup epilogue:
        #   GET_AWAITABLE, LOAD_CONST None, YIELD_FROM, WITH_CLEANUP_FINISH
        standardEpilogue = [
            self.OpCodes.GET_AWAITABLE,
            self.OpCodes.LOAD_CONST_A,
            self.OpCodes.YIELD_FROM,
            self.OpCodes.WITH_CLEANUP_FINISH,
        ]
        for expectedOp in standardEpilogue:
            nxt = self.code.Next
            if nxt is not None and nxt.OpCodeID == expectedOp:
                self.code.GoNext()
            else:
                break

        # After the standard epilogue, two patterns are possible (3.8+):
        #   Normal exit:        END_FINALLY
        #   Early return path:  POP_FINALLY 0 / LOAD_CONST X / RETURN_VALUE
        #                       / WITH_CLEANUP_START / GET_AWAITABLE / LOAD_CONST None
        #                       / YIELD_FROM / WITH_CLEANUP_FINISH / END_FINALLY
        #                       [/ LOAD_CONST None / RETURN_VALUE  -- dead implicit return]
        # For the early-return case we synthesize the explicit return into the body
        # and skip the trailing exception handler + dead implicit return.
        after = self.code.Next
        if (after is not None and (after.OpCodeID == self.OpCodes.POP_FINALLY_A
                or after.OpCodeID == self.OpCodes.POP_FINALLY)):
            self.code.GoNext()

            loadConst = self.code.Next
            returnValue = self.code.PeekNextInstruction(2)
            if (loadConst is not None and loadConst.OpCodeID == self.OpCodes.LOAD_CONST_A
                    and returnValue is not None and returnValue.OpCodeID == self.OpCodes.RETURN_VALUE):
                constObj = ASTObject(loadConst.ConstantObject)
                constObj.line = loadConst.LineNo
                if constObj.object is None or constObj.object.ClassName == "Py_None":
                    retValue = ASTNone()
                else:
                    retValue = constObj
                retNode = ASTReturn(retValue)
                retNode.line = loadConst.LineNo
                asyncWithBlock.append(retNode)
                self.code.GoNext()
                self.code.GoNext()

            exceptionHandler = [
                self.OpCodes.WITH_CLEANUP_START,
                self.OpCodes.GET_AWAITABLE,
                self.OpCodes.LOAD_CONST_A,
                self.OpCodes.YIELD_FROM,
                self.OpCodes.WITH_CLEANUP_FINISH,
                self.OpCodes.END_FINALLY,
            ]
            for expectedOp in exceptionHandler:
                nxt = self.code.Next
                if nxt is not None and nxt.OpCodeID == expectedOp:
                    self.code.GoNext()
                else:
                    break

            # Skip the dead implicit LOAD_CONST None / RETURN_VALUE if it's
            # the very tail of the function (no more instructions after).
            load = self.code.Next
            ret = self.code.PeekNextInstruction(2)
            beyond = self.code.PeekNextInstruction(3)
            if (load is not None and load.OpCodeID == self.OpCodes.LOAD_CONST_A
                    and ret is not None and ret.OpCodeID == self.OpCodes.RETURN_VALUE
                    and beyond is None):
                self.code.GoNext()
                self.code.GoNext()
        elif after is not None and after.OpCodeID == self.OpCodes.END_FINALLY:
            self.code.GoNext()

        self.blocks.pop()
        self.curBlock = self.blocks.top()
        self.curBlock.append(asyncWithBlock)

        debug_log(f"ASYNC WITH block closed, nodes count={len(asyncWithBlock.nodes)}")
        return

    # Stack top should be a None. Ignore it.
    none = self.dataStack.pop()

    none_name = type(none).__name__ if none is not None else None
    debug_log(f"WITH_CLEANUP at offset {self.code.Current.Offset}, curBlock={self.curBlock.type_str}, end={self.curBlock.end}, stackTop={none_name}")

    if not isinstance(none, ASTNone):
        debug_error("Something TERRIBLE happened!\n")
        return

    if (self.curBlock.blockType == ASTBlock.BlockType.With
            and self.curBlock.end == self.code.Current.Offset):
        withBlock = self.curBlock
        self.blocks.pop()  # Remove WITH block from stack
        self.curBlock = self.blocks.top()  # Get parent block
        self.curBlock.append(withBlock)

        expr_name = withBlock.expr.name if withBlock.expr is not None else None
        var_name = withBlock.var.name if withBlock.var is not None else None
        debug_log(f"WITH block closed successfully, nodes count={len(withBlock.nodes)}, expr={expr_name}, var={var_name}")
        debug_log(f"  Added to {self.curBlock.type_str} block")
    else:
        debug_error(f"WITH_CLEANUP mismatch: curBlock.type={self.curBlock.type_str}, curBlock.end={self.curBlock.end}, currentOffset={self.code.Current.Offset}")
        debug_error(f"Something TERRIBLE happened! No matching with block found for WITH_CLEANUP at {self.code.Current.Offset}\n")


def handleWithCleanupFinish(self):
    # Ignore this
    pass


# Handler for BEFORE_WITH opcode (Python 3.11+)
#
# In Python 3.11+, context managers use BEFORE_WITH instead of SETUP_WITH.
# BEFORE_WITH:
#   - Pops the context manager from the stack
#   - Calls __enter__() on it
#   - Pushes the result (which the next STORE_* will capture as the 'as' variable)
#
# The with block boundaries come from the exception table, not from jump targets.
def handleBeforeWith(self):
    # Pop the context manager from the stack (result of CALL opcode)
    ctxMgr = self.dataStack.pop()

    ctxMgr_name = type(ctxMgr).__name__ if ctxMgr is not None else None
    debug_log(f"[BEFORE_WITH] at offset {self.code.Current.Offset}, ctxMgr={ctxMgr_name}")

    # Find the with block end from exception table
    # In Python 3.11+, the exception table entry for with statements has depth=1
    # and covers the range from STORE_* (after BEFORE_WITH) to the end of the body
    withEnd = self.code.LastOffset
    exceptionTable = self.object.ExceptionTable or []
    currentOffset = self.code.Current.Offset

    # Find the exception table entry for this with statement
    # It should start at the STORE_* instruction that follows BEFORE_WITH
    witchExcTableEntry = None
    for entry in exceptionTable:
        # Look for entry that starts right after BEFORE_WITH
        # The entry.start is typically the STORE_* instruction offset
        if entry.start > currentOffset and entry.start <= currentOffset + 10:
            # Found the exception table entry for this with block
            # The 'end' points to the first instruction AFTER the protected body
            # We use this directly since the pre-handler WITH close logic will
            # close the block when we REACH this offset (before processing)
            withEnd = entry.end or withEnd
            witchExcTableEntry = entry
            debug_log(f"[BEFORE_WITH] Found exception table entry: start={entry.start}, end={entry.end}, withEnd={withEnd}, target={entry.target}")
            break

    # Mark this exception table entry as belonging to a with statement
    # This prevents it from being treated as a regular exception handler
    if witchExcTableEntry:
        witchExcTableEntry._isWithStatement = True

    # Create the WITH block (uninitialized - processStore will set expr and var)
    withBlock = ASTWithBlock(currentOffset, withEnd)
    # Don't set expr here - let processStore do it when it handles the STORE_* instruction
    # This is important because processStore checks for uninitialized WITH blocks

    # Push the __enter__ result to the stack
    # This will be consumed by the subsequent STORE_* instruction (for 'as' variable)
    # The processStore function will pop this and set withBlock.expr and withBlock.var
    self.dataStack.append(ctxMgr)

    # Push the with block onto the block stack
    self.blocks.append(withBlock)
    self.curBlock = self.blocks.top()

    ctxMgr_frag = ctxMgr.codeFragment() if (ctxMgr is not None and callable(getattr(ctxMgr, 'codeFragment', None))) else None
    debug_log(f"[BEFORE_WITH] Created WITH block (uninitialized), end={withEnd}, ctxMgr={ctxMgr_frag}")


# Handler for BEFORE_ASYNC_WITH (Python 3.5-3.10).
#
# Bytecode pattern for `async with EXPR [as VAR]:`:
#   LOAD_*               EXPR (context manager)
#   BEFORE_ASYNC_WITH    <-- we are here
#   GET_AWAITABLE
#   LOAD_CONST None
#   YIELD_FROM
#   SETUP_ASYNC_WITH +N  (N targets WITH_CLEANUP_START - end of body)
#   POP_TOP | STORE_FAST VAR
#   ... body ...
#   POP_BLOCK
#   LOAD_CONST None
#   WITH_CLEANUP_START   (closes block, see handleWithCleanup)
#   GET_AWAITABLE
#   LOAD_CONST None
#   YIELD_FROM
#   WITH_CLEANUP_FINISH
#   END_FINALLY
#
# We pop the context manager off the data stack, then use GoNext to consume
# the entire setup epilogue. This bypasses the GET_AWAITABLE / YIELD_FROM
# handlers (which would otherwise emit `await await(EXPR.__aenter__)` noise)
# and creates a clean ASTAsyncWithBlock for the body.
def handleBeforeAsyncWith(self):
    ctxMgr = self.dataStack.pop()

    getAwaitable = self.code.PeekNextInstruction(1)
    loadNone = self.code.PeekNextInstruction(2)
    yieldFrom = self.code.PeekNextInstruction(3)
    setupAsyncWith = self.code.PeekNextInstruction(4)

    if (not getAwaitable or getAwaitable.OpCodeID != self.OpCodes.GET_AWAITABLE
            or not loadNone or loadNone.OpCodeID != self.OpCodes.LOAD_CONST_A
            or not yieldFrom or yieldFrom.OpCodeID != self.OpCodes.YIELD_FROM
            or not setupAsyncWith or setupAsyncWith.OpCodeID != self.OpCodes.SETUP_ASYNC_WITH_A):
        ga = getAwaitable.InstructionName if getAwaitable else None
        ln = loadNone.InstructionName if loadNone else None
        yf = yieldFrom.InstructionName if yieldFrom else None
        sa = setupAsyncWith.InstructionName if setupAsyncWith else None
        raise RuntimeError(f"BEFORE_ASYNC_WITH at offset {self.code.Current.Offset}: expected GET_AWAITABLE/LOAD_CONST/YIELD_FROM/SETUP_ASYNC_WITH sequence, got {ga}/{ln}/{yf}/{sa}")

    asClause = self.code.PeekNextInstruction(5)
    asVar = None
    extraSkip = 0
    if asClause is not None and asClause.OpCodeID == self.OpCodes.STORE_FAST_A:
        if asClause.Name is None:
            raise RuntimeError(f"BEFORE_ASYNC_WITH at offset {self.code.Current.Offset}: STORE_FAST has null Name (expected \"as\" variable)")
        asVar = ASTName(str(asClause.Name))
        extraSkip = 1
    elif asClause is not None and asClause.OpCodeID == self.OpCodes.POP_TOP:
        extraSkip = 1

    # Walk forward from the body start to find the matching WITH_CLEANUP_START
    # for THIS async-with (not a nested one). Track depth so nested
    # SETUP_WITH/SETUP_ASYNC_WITH are skipped over correctly.
    #
    # Note: SETUP_ASYNC_WITH.JumpTarget is unreliable here - for the early-return
    # pattern it points to the exception-path cleanup, not the normal exit.
    blockEnd = setupAsyncWith.JumpTarget
    depth = 0
    searchIdx = self.code.CurrentInstructionIndex + 5 + extraSkip
    i = searchIdx
    while i < len(self.code.Instructions):
        instr = self.code.Instructions[i]
        if not instr:
            break
        if (instr.OpCodeID == self.OpCodes.SETUP_ASYNC_WITH_A
                or instr.OpCodeID == self.OpCodes.SETUP_WITH_A):
            depth += 1
            i += 1
            continue
        if (instr.OpCodeID == self.OpCodes.WITH_CLEANUP_START
                or instr.OpCodeID == self.OpCodes.WITH_CLEANUP):
            if depth == 0:
                blockEnd = instr.Offset
                break
            depth -= 1
        i += 1

    # Skip GET_AWAITABLE, LOAD_CONST None, YIELD_FROM, SETUP_ASYNC_WITH, [POP_TOP|STORE_FAST]
    self.code.GoNext(4 + extraSkip)

    asyncWithBlock = ASTAsyncWithBlock(self.code.Current.Offset, blockEnd)
    asyncWithBlock.expr = ctxMgr
    asyncWithBlock.var = asVar
    asyncWithBlock.init()
    self.blocks.append(asyncWithBlock)
    self.curBlock = self.blocks.top()


def handleSetupAsyncWithA(self):
    # Normally consumed by handleBeforeAsyncWith via GoNext. If we land here,
    # the lookahead failed - bail silently rather than pushing a malformed block.
    debug_error(f"SETUP_ASYNC_WITH at offset {self.code.Current.Offset}: reached without preceding BEFORE_ASYNC_WITH consumption - ignoring")
