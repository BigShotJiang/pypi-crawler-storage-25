"""Translated from lib/handlers/exceptions_blocks.js"""
from __future__ import annotations

from depyo.ast_node import (
    ASTBlock,
    ASTCondBlock,
    ASTContainerBlock,
    ASTWithBlock,
    ASTName,
    ASTCall,
    ASTCompare,
    ASTRaise,
    ASTKeyword,
    ASTStore,
    ASTNone,
    ASTComprehension,
)
from depyo.handlers._util import debug_log, debug_error


def handleSetupExceptA(self):
    if (self.curBlock.blockType == ASTBlock.BlockType.Container
            and self.curBlock.line > -1
            and self.curBlock.line == self.code.Current.LineNo):
        # JS: this.curBlock.except = ... hits the property setter (m_except).
        # `setattr(obj, 'except', v)` creates an instance attribute named
        # "except" that shadows nothing — hasExcept still sees m_except=0,
        # so the outer try/finally/except reconstruction picks the wrong path.
        self.curBlock.except_ = self.code.Current.JumpTarget
    elif (self.code.Prev is not None
          and self.code.Prev.OpCodeID == self.OpCodes.SETUP_FINALLY_A
          and self.code.Prev.LineNo > -1
          and self.code.Prev.LineNo != self.code.Current.LineNo):
        nextBlock = ASTBlock(ASTBlock.BlockType.Try, self.code.Prev.Offset, self.code.Prev.JumpTarget, True)
        self.blocks.append(nextBlock)
        nextBlock = ASTContainerBlock(self.code.Current.Offset, 0, self.code.Current.JumpTarget)
        self.blocks.append(nextBlock)
    else:
        nextBlock = ASTContainerBlock(self.code.Current.Offset, 0, self.code.Current.JumpTarget)
        self.blocks.append(nextBlock)

    tryBlock = ASTBlock(ASTBlock.BlockType.Try, self.code.Current.Offset, self.code.Current.JumpTarget, True)
    self.blocks.append(tryBlock)
    self.curBlock = self.blocks.top()

    self.need_try = False

    # Register exception handler offset
    if self.exceptionHandlerOffsets is not None:
        self.exceptionHandlerOffsets.add(self.code.Current.JumpTarget)

        debug_log(f"[SETUP_EXCEPT] Registered exception handler at offset {self.code.Current.JumpTarget}")


def handleSetupFinallyA(self):
    # In Python 2.6-3.1, SETUP_FINALLY is used for WITH statements
    withPattern = extractWithPatternForFinally(self)

    if withPattern:
        # This is a WITH statement, create ASTWithBlock
        cm_name = withPattern['contextManager'].name if withPattern['contextManager'] is not None else None
        av_name = withPattern['asVariable'].name if withPattern['asVariable'] is not None else None
        debug_log(f"Detected WITH pattern at offset {self.code.Current.Offset}: expr={cm_name}, var={av_name}")

        # Find the WITH_CLEANUP instruction to determine the actual end of the WITH block
        withEnd = self.code.Current.JumpTarget
        searchInstr = self.code.PeekInstructionAtOffset(withEnd)
        i = 0
        while i < 10 and searchInstr:
            if searchInstr.OpCodeID in (
                self.OpCodes.WITH_CLEANUP,
                self.OpCodes.WITH_CLEANUP_START,
                self.OpCodes.WITH_CLEANUP_FINISH,
            ):
                withEnd = searchInstr.Offset
                break
            searchInstr = self.code.PeekInstructionAtOffset(searchInstr.Offset + 3)
            i += 1

        withBlock = ASTWithBlock(self.code.Current.Offset, withEnd)
        withBlock.line = self.code.Current.LineNo

        if withPattern['contextManager']:
            withBlock.expr = withPattern['contextManager']
            withBlock.var = withPattern['asVariable']

        self.blocks.append(withBlock)
        self.curBlock = self.blocks.top()

        for i in range(withPattern['skipCount']):
            self.code.GoNext()

        nxt = self.code.Next
        n_off = nxt.Offset if nxt is not None else None
        n_name = nxt.InstructionName if nxt is not None else None
        debug_log(f"After skip ({withPattern['skipCount']} instructions): Current={self.code.Current.Offset}:{self.code.Current.InstructionName}, Next={n_off}:{n_name}")
        expr_name = withBlock.expr.name if withBlock.expr is not None else None
        var_name = withBlock.var.name if withBlock.var is not None else None
        debug_log(f"WITH block created: start={withBlock.start}, end={withBlock.end}, expr={expr_name}, var={var_name}")
    else:
        # Normal SETUP_FINALLY for try/finally blocks (or try/except in Python 3.8+)
        nextBlock = ASTContainerBlock(self.code.Current.Offset, self.code.Current.JumpTarget)
        nextBlock.line = self.code.Current.LineNo
        self.blocks.append(nextBlock)
        self.curBlock = self.blocks.top()

        self.need_try = True

        if self.exceptionHandlerOffsets is not None:
            self.exceptionHandlerOffsets.add(self.code.Current.JumpTarget)

            debug_log(f"[SETUP_FINALLY] offset={self.code.Current.Offset}, arg={self.code.Current.Argument}, JumpTarget={self.code.Current.JumpTarget}")


def handleSetupCleanupA(self):
    # Python 3.13+ SETUP_CLEANUP behaves like SETUP_FINALLY for decompilation.
    handleSetupFinallyA(self)


# Helper to extract WITH pattern from SETUP_FINALLY (Python 2.6-3.1)
def extractWithPatternForFinally(self):
    nextInstr = self.code.Next
    if not nextInstr:
        debug_log(f"WITH pattern check failed: no next instruction")
        return None

    # Python 2.7 pattern check
    if nextInstr.OpCodeID == self.OpCodes.LOAD_FAST_A:
        secondInstr = self.code.PeekInstructionAtOffset(nextInstr.Offset + 3)

        # Python 2.7: LOAD_FAST -> DELETE_FAST -> STORE_FAST/POP_TOP/UNPACK_SEQUENCE
        if secondInstr and secondInstr.OpCodeID == self.OpCodes.DELETE_FAST_A:
            thirdInstr = self.code.PeekInstructionAtOffset(secondInstr.Offset + 3)
            asVariable = None
            skipCount = 3  # Default: LOAD_FAST + DELETE_FAST + (STORE_FAST|POP_TOP)

            if thirdInstr and thirdInstr.OpCodeID == self.OpCodes.STORE_FAST_A:
                if thirdInstr.Name is None:
                    raise RuntimeError(f"SETUP_FINALLY (Py2.7 WITH) at offset {self.code.Current.Offset} (file offset {self.object.codeOffset + self.code.Current.Offset}): STORE_FAST has null Name")
                asVariable = ASTName(str(thirdInstr.Name))
            elif thirdInstr and thirdInstr.OpCodeID == self.OpCodes.POP_TOP:
                asVariable = None
            elif thirdInstr and thirdInstr.OpCodeID == self.OpCodes.UNPACK_SEQUENCE_A:
                raise RuntimeError(f"SETUP_FINALLY (Py2.7 WITH) at offset {self.code.Current.Offset} (file offset {self.object.codeOffset + self.code.Current.Offset}): tuple-unpack 'as (...)' clauses not yet supported (UNPACK_SEQUENCE_A at offset {thirdInstr.Offset})")
            else:
                ti_name = thirdInstr.InstructionName if thirdInstr else None
                debug_log(f"WITH pattern (Python 2.7) check failed: third={ti_name}")
                return None

            ctxMgrExpr = extractContextManager(self)

            return {
                'contextManager': ctxMgrExpr,
                'asVariable': asVariable,
                'skipCount': skipCount,
            }

    # Python 3.0+ pattern: Different forward sequence
    debug_log(f"Trying Python 3.0+ WITH pattern detection at offset {self.code.Current.Offset}")
    debug_log(f"  Next 5 instructions:")
    for i in range(5):
        instr = self.code.PeekInstructionAtOffset(self.code.Next.Offset + i * 3)
        if instr:
            debug_log(f"    [+{i}] {instr.Offset}: {instr.InstructionName} arg={instr.Argument} name={instr.Name}")

    ctxMgrExpr = extractContextManager(self)

    if ctxMgrExpr:
        handlerOffset = self.code.Current.JumpTarget
        if handlerOffset > 0:
            scanLimit = 10
            for i in range(scanLimit):
                handlerInstr = self.code.PeekInstructionAtOffset(handlerOffset + i * 2)
                if not handlerInstr:
                    break

                if handlerInstr.OpCodeID == self.OpCodes.COMPARE_OP_A and handlerInstr.Argument == 10:
                    debug_log(f"False positive: Found COMPARE_OP EXCEPTION MATCH at offset {handlerInstr.Offset} - this is try-except, not WITH")
                    return None

                if handlerInstr.OpCodeID in (self.OpCodes.WITH_CLEANUP_START, self.OpCodes.WITH_CLEANUP_FINISH):
                    debug_log(f"Confirmed WITH statement: Found {handlerInstr.InstructionName} at offset {handlerInstr.Offset}")
                    break

        asVariable = None
        skipCount = 0

        searchLimit = 15
        foundBodyStart = False

        for i in range(searchLimit):
            instr = self.code.PeekInstructionAtOffset(self.code.Next.Offset + i * 3)
            if not instr:
                break

            if instr.OpCodeID == self.OpCodes.STORE_FAST_A and i < 5:
                if instr.Name is None:
                    raise RuntimeError(f"SETUP_FINALLY (Py3 WITH) at offset {self.code.Current.Offset} (file offset {self.object.codeOffset + self.code.Current.Offset}): STORE_FAST at offset {instr.Offset} has null Name")
                asVariable = ASTName(str(instr.Name))
                skipCount = i + 1
                foundBodyStart = True
                debug_log(f"Python 3.0+ variable found: {instr.Name} at offset {instr.Offset}, skipCount={skipCount}")
                break

            # JS quirk: this.OpCodes.LOAD_CONST / this.OpCodes.CONTINUE_LOOP
            # are undefined for versions where the opcode exists as _A (Py2.x-3.10).
            # Those branches are dead in JS; mirror that by skipping them here.
            # The effect: when the with-body begins with a bare CONTINUE_LOOP,
            # JS advances past it to POP_BLOCK (skipCount=1) and the body renders
            # as `pass`. Matching that preserves fixture parity.
            if (instr.OpCodeID == self.OpCodes.SETUP_FINALLY_A
                    or instr.OpCodeID == self.OpCodes.SETUP_WITH_A
                    or (instr.OpCodeID == self.OpCodes.LOAD_FAST_A and i > 3)
                    or instr.OpCodeID == self.OpCodes.POP_BLOCK):
                skipCount = i
                foundBodyStart = True
                debug_log(f"Python 3.0+ body start found at offset {instr.Offset} ({instr.InstructionName}), skipCount={skipCount}")
                break

        if not foundBodyStart:
            skipCount = 3
            debug_log(f"Python 3.0+ using fallback skipCount=3")

        if not asVariable:
            asVariable = None

        av_name = asVariable.name if asVariable is not None else 'none'
        debug_log(f"Python 3.0+ WITH detected: expr={ctxMgrExpr.name}, var={av_name}, skip={skipCount}")

        return {
            'contextManager': ctxMgrExpr,
            'asVariable': asVariable,
            'skipCount': skipCount,
        }

    return None


def extractContextManager(self):
    ctxMgrExpr = None

    debug_log(f"Scanning backward from index {self.code.CurrentInstructionIndex}, offset {self.code.Current.Offset}")

    for idx in range(self.code.CurrentInstructionIndex - 1, -1, -1):
        instr = self.code.Instructions[idx]
        if not instr:
            continue

        debug_log(f"  [{idx}] offset={instr.Offset}, opcode={instr.InstructionName} ({instr.OpCodeID})")

        if instr.OpCodeID in (
            self.OpCodes.LOAD_FAST_A, self.OpCodes.LOAD_GLOBAL_A, self.OpCodes.LOAD_NAME_A,
            self.OpCodes.LOAD_DEREF_A, self.OpCodes.CALL_FUNCTION, self.OpCodes.CALL_FUNCTION_A,
            self.OpCodes.BINARY_SUBSCR, self.OpCodes.LOAD_ATTR_A,
        ):
            afterLoad = self.code.Instructions[idx + 1] if idx + 1 < len(self.code.Instructions) else None
            al_off = afterLoad.Offset if afterLoad else None
            al_name = afterLoad.InstructionName if afterLoad else None
            debug_log(f"    Candidate! afterLoad={al_off}:{al_name}, DUP_TOP={self.OpCodes.DUP_TOP}")

            if afterLoad and afterLoad.OpCodeID == self.OpCodes.DUP_TOP:
                debug_log(f"    FOUND! InstructionArg={getattr(instr, 'InstructionArg', None)}")

                if instr.OpCodeID in (
                    self.OpCodes.LOAD_FAST_A,
                    self.OpCodes.LOAD_GLOBAL_A,
                    self.OpCodes.LOAD_NAME_A,
                    self.OpCodes.LOAD_DEREF_A,
                ):
                    if instr.Name is None:
                        raise RuntimeError(f"extractContextManager: {instr.InstructionName} at offset {instr.Offset} has null Name")
                    ctxMgrExpr = ASTName(str(instr.Name))
                else:
                    raise RuntimeError(f"extractContextManager: unsupported context manager opcode {instr.InstructionName} at offset {instr.Offset} - needs stack replay")
                break

    name_attr = ctxMgrExpr.name if ctxMgrExpr is not None else None
    debug_log(f"Result: ctxMgrExpr={name_attr}")

    return ctxMgrExpr


def handlePopBlock(self):
    if (self.curBlock.blockType == ASTBlock.BlockType.Container
            or self.curBlock.blockType == ASTBlock.BlockType.Finally):
        # These should only be popped by an END_FINALLY
        cb_finally = self.curBlock.finally_
        if (self.code.Prev is not None
                and self.code.Prev.OpCodeID == self.OpCodes.END_FINALLY
                and self.curBlock.blockType == ASTBlock.BlockType.Container
                and cb_finally == self.code.Next.Offset + 3):
            finallyBlock = ASTBlock(ASTBlock.BlockType.Finally, cb_finally, 0, True)
            self.blocks.append(finallyBlock)
            self.curBlock = self.blocks.top()
            self.code.GoNext()
        return

    if (self.curBlock.blockType == ASTBlock.BlockType.With
            or self.curBlock.blockType == ASTBlock.BlockType.AsyncWith):
        # This should only be popped by a WITH_CLEANUP
        debug_log(f"POP_BLOCK on {self.curBlock.type_str.upper()} block ignored at offset {self.code.Current.Offset}")
        return

    # Py2.x nested genexpr/comprehension phantom POP_BLOCK handling
    if (self.curBlock.blockType == ASTBlock.BlockType.For
            and self.curBlock.comprehension
            and isinstance(self.dataStack.top(), ASTComprehension)):
        debug_log(f"POP_BLOCK ignored on For+comprehension at offset {self.code.Current.Offset} (ASTComprehension on stack)")
        return

    if (len(self.curBlock.nodes)
            and isinstance(self.curBlock.nodes.top(), ASTKeyword)):
        if self.curBlock.blockType != ASTBlock.BlockType.AsyncFor:
            self.curBlock.removeLast()

    tmp = self.blocks.pop()

    if not self.blocks.empty():
        self.curBlock = self.blocks.top()

    if (not self.blocks.empty()
            and not (tmp.blockType == ASTBlock.BlockType.Else and tmp.nodes.empty())):
        self.curBlock.append(tmp)

    nxt = self.code.Next
    if (tmp.blockType in (ASTBlock.BlockType.For, ASTBlock.BlockType.While)
            and nxt is not None and tmp.end >= nxt.Offset):
        blkElse = ASTBlock(ASTBlock.BlockType.Else, self.code.Current.Offset, tmp.end)
        self.blocks.append(blkElse)
        self.curBlock = self.blocks.top()

    if (self.curBlock.blockType == ASTBlock.BlockType.Try
            and tmp.blockType != ASTBlock.BlockType.For
            and tmp.blockType != ASTBlock.BlockType.AsyncFor
            and tmp.blockType != ASTBlock.BlockType.While):
        tmp = self.curBlock
        self.blocks.pop()
        self.curBlock = self.blocks.top()

        if not (tmp.blockType == ASTBlock.BlockType.Else and tmp.nodes.empty()):
            self.curBlock.append(tmp)

    if self.curBlock.blockType == ASTBlock.BlockType.Container:
        if tmp.blockType == ASTBlock.BlockType.Else and not self.curBlock.hasFinally:
            # Pop the container
            cont = self.curBlock
            self.blocks.pop()
            self.curBlock = self.blocks.top()
            self.curBlock.append(cont)
        elif ((tmp.blockType == ASTBlock.BlockType.Else and self.curBlock.hasFinally)
              or (tmp.blockType == ASTBlock.BlockType.Try and not self.curBlock.hasExcept)):
            cb_finally = self.curBlock.finally_
            finalStart = cb_finally if cb_finally else tmp.start
            final = ASTBlock(ASTBlock.BlockType.Finally, finalStart, 0, True)
            self.blocks.append(final)
            self.curBlock = self.blocks.top()

    nxt = self.code.Next
    if ((self.curBlock.blockType == ASTBlock.BlockType.For
            or self.curBlock.blockType == ASTBlock.BlockType.AsyncFor)
            and nxt is not None and self.curBlock.end == nxt.Offset):
        self.blocks.pop()
        self.blocks.top().append(self.curBlock)
        self.curBlock = self.blocks.top()

    if self.blocks.empty() and tmp.blockType == ASTBlock.BlockType.Main:
        self.blocks.append(tmp)
        self.curBlock = self.blocks.top()


def handlePopExcept(self):
    if not len(self.blocks) or len(self.blocks) <= 1:
        # Nothing structured to pop; keep current block stable.
        try:
            t = self.blocks.top()
        except Exception:
            t = None
        self.curBlock = t or self.curBlock or self.defBlock
        return

    exceptBlock = self.blocks.pop()
    self.curBlock = self.blocks.top()

    if not exceptBlock:
        return
    if not self.curBlock:
        self.curBlock = self.defBlock or exceptBlock

    bodyNodes = exceptBlock.nodes

    if self.curBlock.blockType == ASTBlock.BlockType.Try:
        pendingEgType = None
        if getattr(self, 'egMatchTypeStack', None):
            pendingEgType = self.egMatchTypeStack.pop(0) if self.egMatchTypeStack else None
        if not pendingEgType:
            pendingEgType = self.pendingEgMatchType
        isExceptStar = bool(self.inExceptionGroup or pendingEgType)
        matchType = pendingEgType or getattr(exceptBlock, 'condition', None)
        if matchType is not None and hasattr(matchType, 'src') and hasattr(matchType, 'dest'):
            storeSrc = matchType.src
            if (isinstance(storeSrc, ASTCall)
                    and isinstance(storeSrc.func, ASTName)
                    and storeSrc.func.name == "__check_eg_match__"):
                matchType = (storeSrc.pparams[1] if (getattr(storeSrc, 'pparams', None) and len(storeSrc.pparams) > 1) else storeSrc)
            else:
                matchType = matchType.src or matchType.dest or matchType
        elif (isinstance(matchType, ASTCall)
              and isinstance(matchType.func, ASTName)
              and matchType.func.name == "__check_eg_match__"):
            matchType = (matchType.pparams[1] if (getattr(matchType, 'pparams', None) and len(matchType.pparams) > 1) else matchType)
        if not matchType or isinstance(matchType, ASTStore):
            matchType = pendingEgType or matchType
        catchBlock = ASTCondBlock(ASTBlock.BlockType.Except, exceptBlock.start, exceptBlock.end, matchType, False)
        catchBlock.line = exceptBlock.line
        if isinstance(bodyNodes, list) and len(bodyNodes):
            catchBlock.m_nodes.extend(bodyNodes)
        catchBlock.isExceptStar = isExceptStar
        if catchBlock.condition is not None and hasattr(catchBlock.condition, 'src'):
            storeSrc = catchBlock.condition.src
            if (isinstance(storeSrc, ASTCall)
                    and isinstance(storeSrc.func, ASTName)
                    and storeSrc.func.name == "__check_eg_match__"):
                catchBlock.condition = (storeSrc.pparams[1] if (getattr(storeSrc, 'pparams', None) and len(storeSrc.pparams) > 1) else storeSrc)
            elif storeSrc:
                catchBlock.condition = storeSrc
        self.curBlock.append(catchBlock)
        self.inExceptionGroup = False
        self.inExceptionTableHandler = False
        self.pendingEgMatchType = None
    else:
        if not self.curBlock:
            self.curBlock = self.blocks.top() or exceptBlock
        if not getattr(exceptBlock, 'condition', None):
            matchType = None
            if getattr(self, 'egMatchTypeStack', None):
                matchType = self.egMatchTypeStack.pop(0) if self.egMatchTypeStack else None
            if not matchType:
                matchType = self.pendingEgMatchType or getattr(exceptBlock, 'condition', None)
            if (isinstance(matchType, ASTCall)
                    and isinstance(matchType.func, ASTName)
                    and matchType.func.name == "__check_eg_match__"):
                matchType = (matchType.pparams[1] if (getattr(matchType, 'pparams', None) and len(matchType.pparams) > 1) else matchType)
            elif matchType is not None and hasattr(matchType, 'src') and matchType.src:
                matchType = matchType.src
            exceptBlock.condition = matchType
        exceptBlock.isExceptStar = bool(self.inExceptionGroup or self.pendingEgMatchType or (getattr(self, 'egMatchTypeStack', None) and len(self.egMatchTypeStack)))
        self.curBlock.append(exceptBlock)


def handleEndFinally(self):
    debug_log(f"[handleEndFinally] curBlock={self.curBlock.type_str}, stack depth={len(self.blocks)}")

    isFinally = False
    if self.curBlock.blockType == ASTBlock.BlockType.Finally:
        final = self.curBlock
        self.blocks.pop()

        self.curBlock = self.blocks.top()
        self.curBlock.nodes.append(final)
        isFinally = True
    elif self.curBlock.blockType == ASTBlock.BlockType.Except:
        self.blocks.pop()
        prev = self.curBlock

        isUninitAsyncFor = False
        if self.blocks.top().blockType == ASTBlock.BlockType.Container:
            container = self.blocks.pop()
            asyncForBlock = self.blocks.top()
            isUninitAsyncFor = (asyncForBlock.blockType == ASTBlock.BlockType.AsyncFor and not asyncForBlock.inited)

            debug_log(f"[handleEndFinally] Container found. Next block: {asyncForBlock.type_str}, inited={asyncForBlock.inited}, isUninitAsyncFor={isUninitAsyncFor}")

            if isUninitAsyncFor:
                tryBlock = container.nodes[0] if len(container.nodes) > 0 else None
                tb_ts = tryBlock.type_str if tryBlock is not None else None
                debug_log(f"  Container has {len(container.nodes)} nodes, first is {tb_ts}")

                if tryBlock is not None and not tryBlock.nodes.empty() and tryBlock.blockType == ASTBlock.BlockType.Try:
                    store = tryBlock.nodes[0]
                    s_name = type(store).__name__ if store is not None else None
                    s_dest_name = type(store.dest).__name__ if (store is not None and store.dest is not None) else None
                    dest_frag = (store.dest.codeFragment() if (store is not None and store.dest is not None and callable(getattr(store.dest, 'codeFragment', None))) else 'no codeFragment')
                    debug_log(f"  Try block has {len(tryBlock.nodes)} nodes, first is {s_name}")
                    debug_log(f"  Store.dest = {s_dest_name}: {dest_frag}")
                    if store:
                        asyncForBlock.index = store.dest
                        i_name = type(asyncForBlock.index).__name__ if asyncForBlock.index is not None else None
                        debug_log(f"  Set asyncForBlock.index = {i_name}")
                self.curBlock = self.blocks.top()

                if not self.curBlock.inited:
                    import sys
                    print("Error when decompiling 'async for'.\n", file=sys.stderr)
            elif asyncForBlock.blockType == ASTBlock.BlockType.AsyncFor and asyncForBlock.inited:
                tryBlock = None
                for n in container.nodes:
                    if n.blockType == ASTBlock.BlockType.Try:
                        tryBlock = n
                        break
                if tryBlock and not tryBlock.nodes.empty():
                    store = None
                    for n in tryBlock.nodes:
                        if isinstance(n, ASTStore):
                            store = n
                            break
                    startIdx = (tryBlock.nodes.index(store) + 1) if store else 0
                    for i in range(startIdx, len(tryBlock.nodes)):
                        node = tryBlock.nodes[i]
                        if (node is not None and type(node).__name__ != 'ASTReturn'
                                and not (type(node).__name__ == 'ASTCall' and getattr(node.func, 'name', None) == 'await')):
                            asyncForBlock.nodes.append(node)
                    if len(asyncForBlock.nodes) == 0:
                        passNode = ASTKeyword(ASTKeyword.Word.Pass)
                        passNode.line = tryBlock.line
                        asyncForBlock.nodes.append(passNode)
                asyncForEnd = asyncForBlock.end
                self.blocks.pop()
                self.blocks.top().append(asyncForBlock)
                self.curBlock = self.blocks.top()
                self.unreachableUntil = asyncForEnd
                debug_log(f"[handleEndFinally-Except] Closed initialized AsyncFor, unreachable until {asyncForEnd}")
                return
            else:
                self.blocks.append(container)

        if not isUninitAsyncFor:
            if not self.curBlock.empty():
                self.blocks.top().append(self.curBlock)

            self.curBlock = self.blocks.top()

            # Turn it into an else statement.
            nxt = self.code.Next
            # JS reads `curBlock.hasFinally` which is undefined (→ falsy) on
            # ASTCondBlock; Python raises AttributeError. Mirror the soft-fail.
            if (nxt is not None and self.curBlock.end != nxt.Offset) or getattr(self.curBlock, "hasFinally", False):
                elseblk = ASTBlock(ASTBlock.BlockType.Else, self.code.Current.Offset, prev.end)
                elseblk.init()
                self.blocks.append(elseblk)
                self.curBlock = self.blocks.top()

    # Handle Python 3.6+ case: curBlock is "if" inside CONTAINER inside initialized AsyncFor
    if self.curBlock.blockType == ASTBlock.BlockType.If:
        if len(self.blocks) >= 3:
            parentContainer = self.blocks[len(self.blocks) - 2]
            grandparentAsyncFor = self.blocks[len(self.blocks) - 3]

            if (parentContainer is not None and parentContainer.blockType == ASTBlock.BlockType.Container
                    and grandparentAsyncFor is not None and grandparentAsyncFor.blockType == ASTBlock.BlockType.AsyncFor
                    and grandparentAsyncFor.inited):

                debug_log(f"[handleEndFinally-If] Found if->CONTAINER->AsyncFor(inited) pattern")
                debug_log(f"  Closing if block and will hide CONTAINER")

                self.blocks.pop()
                self.curBlock = self.blocks.top()

    if self.curBlock.blockType == ASTBlock.BlockType.Container:
        # This marks the end of the except block(s).
        cont = self.curBlock

        if cont.end == 0:
            cont.end = self.code.Current.Offset
            debug_log(f"[handleEndFinally-Container] Set end={cont.end} for CONTAINER({cont.start}-{cont.end})")

        if len(self.blocks) > 1:
            parentBlock = self.blocks[len(self.blocks) - 2]
            isUninitAsyncFor = (parentBlock is not None
                                and parentBlock.blockType == ASTBlock.BlockType.AsyncFor
                                and not parentBlock.inited)
            isInitAsyncFor = (parentBlock is not None
                              and parentBlock.blockType == ASTBlock.BlockType.AsyncFor
                              and parentBlock.inited)

            pb_ts = parentBlock.type_str if parentBlock is not None else None
            debug_log(f"[handleEndFinally-Container] Parent={pb_ts}, isUninitAsyncFor={isUninitAsyncFor}, isInitAsyncFor={isInitAsyncFor}")

            if isUninitAsyncFor:
                debug_log(f"  Container has {len(cont.nodes)} nodes:")
                for i, n in enumerate(cont.nodes):
                    t = n.type_str if (n is not None and hasattr(n, 'type_str')) else (type(n).__name__ if n is not None else None)
                    debug_log(f"    [{i}] {t}")

                tryBlock = None
                for n in cont.nodes:
                    if n.blockType == ASTBlock.BlockType.Try:
                        tryBlock = n
                        break
                debug_log(f"  TryBlock found: {bool(tryBlock)}, nodes: {len(tryBlock.nodes) if tryBlock else None}")

                if tryBlock and not tryBlock.nodes.empty():
                    store = None
                    for n in tryBlock.nodes:
                        if isinstance(n, ASTStore):
                            store = n
                            break

                    debug_log(f"  Found ASTStore: {bool(store)}, has dest: {bool(store.dest if store else None)}")
                    if store:
                        dt = type(store.dest).__name__ if store.dest is not None else None
                        debug_log(f"    dest type: {dt}")

                    if store and store.dest:
                        parentBlock.index = store.dest
                        parentBlock.init()
                        dest_frag = store.dest.codeFragment() if callable(getattr(store.dest, 'codeFragment', None)) else type(store.dest).__name__
                        debug_log(f"  Extracted index: {dest_frag}")

                        storeIdx = tryBlock.nodes.index(store)
                        for i in range(storeIdx + 1, len(tryBlock.nodes)):
                            node = tryBlock.nodes[i]
                            if node is not None and type(node).__name__ != 'ASTReturn':
                                parentBlock.nodes.append(node)

                        if len(parentBlock.nodes) == 0:
                            passNode = ASTKeyword(ASTKeyword.Word.Pass)
                            passNode.line = store.line
                            parentBlock.nodes.append(passNode)

                        debug_log(f"  Added {len(parentBlock.nodes)} node(s) to async for body")
                self.blocks.pop()
                self.curBlock = self.blocks.top()
                return

            if isInitAsyncFor:
                debug_log(f"  [InitAsyncFor] AsyncFor already has {len(parentBlock.nodes)} nodes")
                for i, n in enumerate(parentBlock.nodes):
                    nn = type(n).__name__ if n is not None else None
                    debug_log(f"    Existing[{i}] {nn}")
                debug_log(f"  Container has {len(cont.nodes)} nodes:")
                for i, n in enumerate(cont.nodes):
                    t = n.type_str if (n is not None and hasattr(n, 'type_str')) else (type(n).__name__ if n is not None else None)
                    debug_log(f"    [{i}] {t}")

                tryBlock = None
                for n in cont.nodes:
                    if n.blockType == ASTBlock.BlockType.Try:
                        tryBlock = n
                        break
                if tryBlock and not tryBlock.nodes.empty():
                    debug_log(f"  Try block has {len(tryBlock.nodes)} nodes:")
                    for i, n in enumerate(tryBlock.nodes):
                        nn = type(n).__name__ if n is not None else None
                        debug_log(f"    [{i}] {nn}")

                    store = None
                    for n in tryBlock.nodes:
                        if isinstance(n, ASTStore):
                            store = n
                            break

                    startIdx = (tryBlock.nodes.index(store) + 1) if store else 0

                    for i in range(startIdx, len(tryBlock.nodes)):
                        node = tryBlock.nodes[i]
                        if (node is not None and type(node).__name__ != 'ASTReturn'
                                and not (type(node).__name__ == 'ASTCall' and getattr(node.func, 'name', None) == 'await')):
                            parentBlock.nodes.append(node)

                    if len(parentBlock.nodes) == 0:
                        passNode = ASTKeyword(ASTKeyword.Word.Pass)
                        passNode.line = tryBlock.line
                        parentBlock.nodes.append(passNode)

                    debug_log(f"  Added {len(parentBlock.nodes)} node(s) to initialized async for body")

                self.blocks.pop()
                self.curBlock = self.blocks.top()

                if self.curBlock.blockType == ASTBlock.BlockType.AsyncFor:
                    asyncForEnd = self.curBlock.end
                    self.blocks.pop()
                    self.blocks.top().append(self.curBlock)
                    self.curBlock = self.blocks.top()

                    self.unreachableUntil = asyncForEnd

                    debug_log(f"  Closed AsyncFor block early, marking {self.code.Current.Offset}-{asyncForEnd} as unreachable")
                return

        if not cont.hasFinally or isFinally:
            # If there's no finally block, pop the container.
            self.blocks.pop()
            self.curBlock = self.blocks.top()
            self.curBlock.append(cont)
        if cont.hasFinally:
            pass


def handleRaiseVarargsA(self):
    paramList = []
    for idx in range(self.code.Current.Argument):
        paramList.insert(0, self.dataStack.pop())
    fromClause = (self.code.Current.Argument == 2
                  and self.object.Reader.versionCompare(3, 0) >= 0)
    node = ASTRaise(paramList, fromClause)
    node.line = self.code.Current.LineNo
    self.curBlock.append(node)

    if ((self.curBlock.blockType == ASTBlock.BlockType.If
            or self.curBlock.blockType == ASTBlock.BlockType.Else)
            and (self.object.Reader.versionCompare(2, 6) >= 0)):
        prev = self.curBlock
        self.blocks.pop()
        self.curBlock = self.blocks.top()
        self.curBlock.append(prev)

        # REMOVED: self.code.GoNext() - main loop already calls GoNext(), this was causing instructions to be skipped


def handleWithExceptStart(self):
    # Simulate calling __exit__(exc, val, tb) and push result for POP_JUMP_IF_TRUE.
    exitFunc = self.dataStack.pop()
    tb = self.dataStack.pop()
    val = self.dataStack.pop()
    exc = self.dataStack.pop()

    if not exitFunc or exc is None:
        debug_error("[WITH_EXCEPT_START] Stack underflow or missing exit function")
        return

    callNode = ASTCall(exitFunc, [exc, val, tb], [])
    callNode.line = self.code.Current.LineNo
    self.dataStack.append(callNode)


def handleWithExceptStartA(self):
    handleWithExceptStart(self)


def handleLoadAssertionError(self):
    self.dataStack.append(ASTName("AssertionError"))


def handleBeginFinally(self):
    # I might need to adjust SETUP_FINALLY_A logic based on this
    pass


def handleCallFinallyA(self):
    # Python 3.8 CALL_FINALLY: branches to finally handler.
    debug_log(f"[CALL_FINALLY] offset={self.code.Current.Offset} -> {self.code.Current.JumpTarget}")
    self.code.GoToOffset(self.code.Current.JumpTarget)


def handlePopFinallyA(self):
    # Logic might be needed within your END_FINALLY handling
    pass


def handleReraise(self):
    # Python 3.9-3.12 RERAISE opcode
    debug_log(f"[RERAISE] at offset {self.code.Current.Offset}")

    if self.curBlock and self.curBlock.blockType == ASTBlock.BlockType.Except:
        excBlock = self.blocks.pop()
        self.curBlock = self.blocks.top()
        if not self.curBlock:
            self.curBlock = self.defBlock
        if self.curBlock and self.curBlock.blockType == ASTBlock.BlockType.Try:
            catchBlock = ASTCondBlock(ASTBlock.BlockType.Except, excBlock.start, excBlock.end, excBlock.condition, False)
            catchBlock.line = excBlock.line
            catchBlock.m_nodes = excBlock.m_nodes
            catchBlock.isExceptStar = bool(self.inExceptionGroup)
            self.curBlock.append(catchBlock)
            self.inExceptionGroup = False
            self.inExceptionTableHandler = False
        else:
            self.curBlock.append(excBlock)


def handleReraiseA(self):
    # Python 3.10+ RERAISE with argument
    handleReraise(self)


def handlePushExcInfo(self):
    # Python 3.11+ bookkeeping opcode for exception groups
    nextOp = self.code.Next
    self.inExceptionGroup = nextOp is not None and nextOp.OpCodeID == self.OpCodes.CHECK_EG_MATCH

    self.dataStack.append(ASTName("__exception__"))


def handleCheckExcMatch(self):
    matchType = self.dataStack.pop()
    excValue = self.dataStack.pop()
    compare = ASTCompare(excValue, matchType, ASTCompare.CompareOp.Exception)
    compare.line = self.code.Current.LineNo
    self.dataStack.append(compare)


def handleCheckEgMatch(self):
    matchType = self.dataStack.pop()
    excValue = self.dataStack.pop()
    callNode = ASTCall(ASTName("__check_eg_match__"), [excValue, matchType], [])
    callNode.line = self.code.Current.LineNo
    self.dataStack.append(callNode)

    self.inExceptionGroup = True
    self.pendingEgMatchType = matchType
    if not getattr(self, 'egMatchTypeStack', None):
        self.egMatchTypeStack = []
    self.egMatchTypeStack.append(matchType)

    if (self.curBlock is not None
            and self.curBlock.blockType == ASTBlock.BlockType.Except
            and not self.curBlock.condition):
        self.curBlock.condition = matchType


def handlePrepReraiseStar(self):
    self.dataStack.pop()
    self.dataStack.pop()
    self.ignoreNextConditional = True
    self.cleanupStackDepth = len(self.dataStack) + 1
    self.dataStack.append(ASTNone())
    self.inExceptionGroup = True
