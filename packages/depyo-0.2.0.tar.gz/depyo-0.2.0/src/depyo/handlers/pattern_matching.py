"""Translated from lib/handlers/pattern_matching.js"""
from __future__ import annotations

from depyo.ast_node import (
    ASTMatch,
    ASTObject,
    ASTCall,
    ASTName,
    ASTTuple,
    ASTList,
)
from depyo.python_object import PythonObject
from depyo.handlers._util import debug_log


# Pattern matching opcodes for match/case statements (Python 3.10+)


def ensureMatchInitialized(self, subjectCandidate, options=None):
    if options is None:
        options = {}
    skipStackLookup = options.get('skipStackLookup', False)
    if self.currentMatch:
        return

    # Prefer subject from stack (TOS-1), fallback to provided candidate or saved potential
    stackLen = len(self.dataStack) if self.dataStack is not None else 0
    tosMinusOne = (self.dataStack[stackLen - 2]
                   if (not skipStackLookup and stackLen >= 2) else None)
    self.matchSubject = subjectCandidate or tosMinusOne

    if (not self.matchSubject
            and not skipStackLookup
            and self.dataStack is not None
            and len(self.dataStack) > 0):
        self.matchSubject = self.dataStack.top()

    if not self.matchSubject and self.potentialMatchSubject:
        self.matchSubject = self.potentialMatchSubject

    if not self.matchSubject:
        stack_len_dbg = len(self.dataStack) if self.dataStack is not None else 0
        debug_log(f"[MATCH] Unable to initialize match at offset {self.code.Current.Offset}: no subject available (stackLen={stack_len_dbg})")
        return

    self.currentMatch = ASTMatch(self.matchSubject)
    self.currentMatch.line = self.code.Current.LineNo
    self.matchParentBlock = self.curBlock
    self.inMatchPattern = True
    self.patternOps = []
    if not self.matchPreNodesStart and self.matchParentBlock:
        self.matchPreNodesStart = len(self.matchParentBlock.nodes)

    subj_name = type(self.matchSubject).__name__ if self.matchSubject is not None else None
    debug_log(f"[MATCH] Initialized new ASTMatch at offset {self.code.Current.Offset} subject={subj_name}")


def handleMatchSequence(self):
    # MATCH_SEQUENCE opcode (Python 3.10+)
    # Tests if TOS is a sequence (tuple, list, etc.) but not str/bytes/bytearray
    # Stack: TOS = value (copy from COPY 1), TOS1 = subject
    # IMPORTANT: TOS is NOT popped! Result is pushed on top.

    from depyo.handlers.misc_other import flushCurrentCaseBody

    # If we have an open case and starting a new pattern, flush the previous case first
    if self.currentMatch and self.currentCase and not self.inMatchPattern:
        debug_log(f"[MATCH_SEQUENCE] Flushing previous case before new pattern at offset {self.code.Current.Offset}")
        flushCurrentCaseBody(self)

    if not self.inMatchPattern and self.currentMatch:
        self.inMatchPattern = True
        self.patternOps = []

    value = self.dataStack.top()  # Peek at the copy (don't pop!)

    debug_log(f"[MATCH_SEQUENCE] at offset {self.code.Current.Offset}")
    debug_log(f"  currentMatch={'active' if self.currentMatch else 'null'}")
    debug_log(f"  Stack depth={len(self.dataStack)}")

    subjectCandidate = (self.dataStack[len(self.dataStack) - 2]
                        if (self.dataStack is not None and len(self.dataStack) >= 2)
                        else None)
    ensureMatchInitialized(self, subjectCandidate)

    # Mark that we're in pattern checking phase
    self.inMatchPattern = True
    self.patternOps = []  # Clear pattern operations for new case

    # Record pattern operation
    self.patternOps.append({'type': 'MATCH_SEQUENCE'})

    # Push True to indicate sequence check passed
    # (In reality, should check type, but for decompilation we assume it passes)
    node = ASTObject(PythonObject("Py_Bool", True))
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)


def handleGetLen(self):
    # GET_LEN opcode (Python 3.10+)
    # Pushes len(TOS) onto stack (TOS is not popped)
    # Used in sequence pattern matching to check length

    value = self.dataStack.top()

    # Record pattern operation if in pattern matching
    if self.inMatchPattern:
        self.patternOps.append({'type': 'GET_LEN'})

    # Create len(value) call node
    # This will be compared with expected length in subsequent COMPARE_OP
    lenNode = ASTCall(
        ASTName('len'),
        [value],
        [],
    )
    lenNode.line = self.code.Current.LineNo
    self.dataStack.append(lenNode)

    val_name = type(value).__name__ if value is not None else None
    debug_log(f"[GET_LEN] at offset {self.code.Current.Offset}, value={val_name}")


def handleMatchMapping(self):
    # MATCH_MAPPING opcode (Python 3.10+)
    # Similar to MATCH_SEQUENCE but for mappings (dicts)

    ensureMatchInitialized(self, None, {'skipStackLookup': True})

    value = self.dataStack.pop()
    if self.inMatchPattern:
        self.patternOps.append({'type': 'MATCH_MAPPING'})
    node = ASTObject(PythonObject("Py_Bool", True))
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)

    debug_log(f"[MATCH_MAPPING] Stub implementation at offset {self.code.Current.Offset}")


def handleMatchClassA(self):
    # MATCH_CLASS_A opcode (Python 3.10+)
    # Matches object against a class pattern

    count = self.code.Current.Argument

    ensureMatchInitialized(self, None, {'skipStackLookup': True})

    if not self.inMatchPattern and self.currentMatch:
        self.inMatchPattern = True
        self.patternOps = []

    attrNames = []
    prevInstr = self.code.Prev
    const_obj = getattr(prevInstr, 'ConstantObject', None) if prevInstr is not None else None
    if (const_obj is not None
            and getattr(const_obj, 'ClassName', None) == "Py_Tuple"
            and getattr(const_obj, 'Value', None)):
        attrNames = [(obj.toString() if obj is not None and hasattr(obj, 'toString') else None)
                     for obj in const_obj.Value]
    classExpr = (self.dataStack[len(self.dataStack) - 2]
                 if (self.dataStack is not None and len(self.dataStack) >= 2)
                 else None)

    # Pop class object and subject
    for i in range(count + 1):
        self.dataStack.pop()

    if self.inMatchPattern:
        self.patternOps.append({
            'type': 'MATCH_CLASS',
            'count': count,
            'attrNames': attrNames,
            'classExpr': classExpr,
        })

    # Push success placeholder
    node = ASTObject(PythonObject("Py_Bool", True))
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)

    debug_log(f"[MATCH_CLASS] Stub implementation at offset {self.code.Current.Offset}, count={count}, inMatch={self.inMatchPattern}")


def handleMatchKeys(self):
    # MATCH_KEYS opcode (Python 3.10+)
    # Used in mapping patterns

    ensureMatchInitialized(self, None, {'skipStackLookup': True})

    keysNode = self.dataStack.pop()  # keys tuple
    subject = self.dataStack.top()

    keys = extractMatchKeys(keysNode)
    if self.inMatchPattern:
        self.patternOps.append({'type': 'MATCH_KEYS', 'keys': keys})

    # Push (values_tuple, True) or None
    node = ASTTuple([])
    node.line = self.code.Current.LineNo
    self.dataStack.append(node)

    debug_log(f"[MATCH_KEYS] Stub implementation at offset {self.code.Current.Offset}")
    if keys:
        parts = ', '.join(str(k.codeFragment()) for k in keys)
        debug_log(f"  keys={parts}")


def extractMatchKeys(keysNode):
    if not keysNode:
        return []
    if isinstance(keysNode, ASTTuple) or isinstance(keysNode, ASTList):
        return keysNode.values or []
    if isinstance(keysNode, ASTObject):
        obj = keysNode.object
        if obj is not None and getattr(obj, 'ClassName', None) in ("Py_Tuple", "Py_SmallTuple", "Py_List"):
            return [ASTObject(value) for value in (obj.Value or [])]
    return []
