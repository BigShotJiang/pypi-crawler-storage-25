"""Translated from lib/handlers/misc_other.js"""
from __future__ import annotations

from depyo.ast_node import (
    ASTBinary,
    ASTBlock,
    ASTCall,
    ASTCase,
    ASTChainStore,
    ASTCompare,
    ASTCondBlock,
    ASTExec,
    ASTFormattedValue,
    ASTJoinedStr,
    ASTKeyword,
    ASTMatch,
    ASTName,
    ASTNodeList,
    ASTNone,
    ASTObject,
    ASTPattern,
    ASTPrint,
    ASTReturn,
    ASTStore,
    ASTTuple,
    ASTUnary,
    ASTComprehension,
)
from depyo.handlers._util import debug_log, debug_error


def reconstructPattern(patternOps):
    """Reconstruct pattern from recorded operations.

    Returns dict with keys 'pattern' (ASTPattern) and 'remainderOps' (list).
    """
    ops = patternOps or []
    consumed = set()

    def markConsumed(op):
        if op is not None:
            consumed.add(id(op))

    def buildResult(pattern):
        remainderOps = [op for op in ops if id(op) not in consumed]

        # AS-pattern: leftover single STORE_FAST wraps existing pattern
        asStore = next((op for op in remainderOps if op.get('type') == 'STORE_FAST'), None)
        if asStore and pattern is not None:
            markConsumed(asStore)
            pattern = ASTPattern(ASTPattern.PatternType.As, {
                'pattern': pattern,
                'name': asStore.get('name'),
            })
            remainderOps = [op for op in ops if id(op) not in consumed]

        return {'pattern': pattern, 'remainderOps': remainderOps}

    if len(ops) == 0:
        return buildResult(ASTPattern(ASTPattern.PatternType.Wildcard, '_'))

    # Find key operations
    matchSeqOp = next((op for op in ops if op.get('type') == 'MATCH_SEQUENCE'), None)
    hasMatchSeq = matchSeqOp is not None
    matchClassOp = next((op for op in ops if op.get('type') == 'MATCH_CLASS'), None)
    matchKeysOp = next((op for op in ops if op.get('type') == 'MATCH_KEYS'), None)
    matchMappingOp = next((op for op in ops if op.get('type') == 'MATCH_MAPPING'), None)
    unpackOp = next((op for op in ops if op.get('type') == 'UNPACK_SEQUENCE'), None)
    compareOp = next((op for op in ops if op.get('type') == 'COMPARE'), None)
    getLenOpIndex = next((i for i, op in enumerate(ops) if op.get('type') == 'GET_LEN'), -1)

    # In 3.13+, MATCH_SEQUENCE is preceded by GET_LEN/COMPARE length checks.
    if hasMatchSeq and getLenOpIndex >= 0:
        markConsumed(ops[getLenOpIndex])
        cmpAfterLen = next((op for op in ops[getLenOpIndex + 1:] if op.get('type') == 'COMPARE'), None)
        if cmpAfterLen is not None:
            markConsumed(cmpAfterLen)

    if matchKeysOp or matchMappingOp:
        if matchKeysOp:
            markConsumed(matchKeysOp)
        if matchMappingOp:
            markConsumed(matchMappingOp)

        keys = (matchKeysOp.get('keys') if matchKeysOp else None) or []
        stores = [op for op in ops if op.get('type') == 'STORE_FAST']
        entries = []

        idx = 0
        while idx < len(keys):
            keyNode = keys[idx]
            pattern = None
            if idx < len(stores) and stores[idx] is not None:
                pattern = ASTPattern(ASTPattern.PatternType.Variable, stores[idx].get('name'))
                markConsumed(stores[idx])
            else:
                pattern = ASTPattern(ASTPattern.PatternType.Wildcard, '_')
            entries.append({'key': keyNode, 'pattern': pattern})
            idx += 1

        # Consume any extra stores associated with mapping binding
        while idx < len(stores):
            markConsumed(stores[idx])
            idx += 1

        return buildResult(ASTPattern(
            ASTPattern.PatternType.Mapping,
            entries
        ))

    if matchClassOp:
        markConsumed(matchClassOp)
        attributes = []
        attrNames = matchClassOp.get('attrNames') or []

        # Determine how many positional attributes are expected (fallback to opcode count)
        attrCount = len(attrNames)
        if not attrCount and matchClassOp.get('count'):
            attrCount = matchClassOp.get('count')

        # Focus on operations that happen after UNPACK_SEQUENCE (if present)
        attrOpsStart = ops.index(matchClassOp) + 1
        attrOps = ops[attrOpsStart:]
        unpackIndex = next((i for i, op in enumerate(attrOps) if op.get('type') == 'UNPACK_SEQUENCE'), -1)
        hasUnpack = unpackIndex >= 0
        if hasUnpack:
            attrOps = attrOps[unpackIndex + 1:]
            if unpackOp is not None:
                markConsumed(unpackOp)

        # Handle SWAP 2 which reverses attribute evaluation order
        reverseOrder = False
        if len(attrOps) > 0 and attrOps[0].get('type') == 'SWAP' and attrOps[0].get('depth') == 2:
            markConsumed(attrOps[0])
            reverseOrder = True
            attrOps = attrOps[1:]

        # Two bytecode shapes for class-pattern attribute extraction:
        #
        #   (A) 3.11+ UNPACK_SEQUENCE shape — each attribute emits either a
        #       COMPARE (literal) or STORE_FAST (binding) inline at its
        #       position. SWAP 2 indicates reverseOrder across all attrs.
        #
        #   (B) 3.10 DUP_TOP/ROT_TWO shape — BIND_STASH marks a binding
        #       position; its STORE_FAST appears later, after any subsequent
        #       COMPAREs. STORE_FASTs are FIFO-matched to BIND_STASHes.
        if hasUnpack:
            attributeOps = []
            for op in attrOps:
                if op.get('type') == 'COMPARE' or op.get('type') == 'STORE_FAST':
                    attributeOps.append(op)
                    markConsumed(op)
                if attrCount and len(attributeOps) >= attrCount:
                    break

            if reverseOrder:
                attributeOps.reverse()

            attrIndex = 0
            for op in attributeOps:
                if attrCount and attrIndex >= attrCount:
                    break
                name = (attrNames[attrIndex] if attrIndex < len(attrNames) else None) or (f"_attr{attrIndex}" if attrNames else None) if attrNames else None
                # Match JS: attrNames.length ? (attrNames[attrIndex] || `_attr${attrIndex}`) : null
                if attrNames:
                    name = attrNames[attrIndex] if attrIndex < len(attrNames) and attrNames[attrIndex] else f"_attr{attrIndex}"
                else:
                    name = None
                if op.get('type') == 'COMPARE':
                    attributes.append({
                        'name': name,
                        'pattern': ASTPattern(ASTPattern.PatternType.Literal, op.get('right')),
                    })
                else:
                    attributes.append({
                        'name': name,
                        'pattern': ASTPattern(ASTPattern.PatternType.Variable, op.get('name')),
                    })
                attrIndex += 1
        else:
            inlineOps = []  # COMPARE or BIND_STASH in position order
            storeOps = []   # Trailing STORE_FAST queue, FIFO to stashes
            for op in attrOps:
                if op.get('type') == 'COMPARE' or op.get('type') == 'BIND_STASH':
                    if not attrCount or len(inlineOps) < attrCount:
                        inlineOps.append(op)
                        markConsumed(op)
                elif op.get('type') == 'STORE_FAST':
                    storeOps.append(op)
                    markConsumed(op)

            # Legacy fixtures (no BIND_STASH recorded) fall back to inline
            # STORE_FAST handling so pre-existing Case-4-style snapshots don't
            # regress.
            if len(inlineOps) == 0 and len(storeOps) > 0:
                attributeOps = storeOps
                attrIndex = 0
                for op in attributeOps:
                    if attrCount and attrIndex >= attrCount:
                        break
                    if attrNames:
                        name = attrNames[attrIndex] if attrIndex < len(attrNames) and attrNames[attrIndex] else (op.get('name') or f"_attr{attrIndex}")
                    else:
                        name = None
                    attributes.append({
                        'name': name,
                        'pattern': ASTPattern(ASTPattern.PatternType.Variable, op.get('name')),
                    })
                    attrIndex += 1
            else:
                stashIdx = 0
                attrIndex = 0
                for op in inlineOps:
                    if attrCount and attrIndex >= attrCount:
                        break
                    if attrNames:
                        name = attrNames[attrIndex] if attrIndex < len(attrNames) and attrNames[attrIndex] else f"_attr{attrIndex}"
                    else:
                        name = None
                    if op.get('type') == 'COMPARE':
                        attributes.append({
                            'name': name,
                            'pattern': ASTPattern(ASTPattern.PatternType.Literal, op.get('right')),
                        })
                    else:
                        storeOp = storeOps[stashIdx] if stashIdx < len(storeOps) else None
                        stashIdx += 1
                        attributes.append({
                            'name': name,
                            'pattern': (ASTPattern(ASTPattern.PatternType.Variable, storeOp.get('name'))
                                        if storeOp is not None
                                        else ASTPattern(ASTPattern.PatternType.Wildcard, '_')),
                        })
                    attrIndex += 1

        attrIndex = len(attributes)

        # If there are declared attributes without recorded ops, fill them with wildcards
        while attrIndex < len(attrNames):
            attributes.append({
                'name': attrNames[attrIndex],
                'pattern': ASTPattern(ASTPattern.PatternType.Wildcard, '_'),
            })
            attrIndex += 1

        return buildResult(ASTPattern(
            ASTPattern.PatternType.Class,
            {
                'classExpr': matchClassOp.get('classExpr'),
                'attributes': attributes,
            }
        ))

    # Literal OR pattern: multiple COMPARE_OP checks in a row
    allCompareOps = [op for op in ops if op.get('type') == 'COMPARE']
    if not hasMatchSeq and len(allCompareOps) > 1:
        orPatterns = []
        for cmp in allCompareOps:
            markConsumed(cmp)
            right = cmp.get('right')
            if isinstance(right, ASTObject):
                orPatterns.append(ASTPattern(ASTPattern.PatternType.Literal, right))
            elif isinstance(right, ASTName):
                orPatterns.append(ASTPattern(ASTPattern.PatternType.Variable, right.name))
            else:
                orPatterns.append(ASTPattern(ASTPattern.PatternType.Wildcard, '_'))
        return buildResult(ASTPattern(ASTPattern.PatternType.Or, orPatterns))

    # Literal pattern: Just COMPARE (no MATCH_SEQUENCE)
    if not hasMatchSeq and compareOp:
        markConsumed(compareOp)
        # Pure literal pattern: case 1: or case "string":
        # right operand is the literal value
        if isinstance(compareOp.get('right'), ASTObject):
            return buildResult(ASTPattern(ASTPattern.PatternType.Literal, compareOp.get('right')))
        # Fallback
        return buildResult(ASTPattern(ASTPattern.PatternType.Wildcard, '_'))

    if not hasMatchSeq:
        # No MATCH_SEQUENCE and no COMPARE → wildcard
        return buildResult(ASTPattern(ASTPattern.PatternType.Wildcard, '_'))

    if not unpackOp:
        # MATCH_SEQUENCE but no UNPACK → wildcard sequence match
        return buildResult(ASTPattern(ASTPattern.PatternType.Wildcard, '_'))

    # Build sequence pattern with unpacked elements
    count = unpackOp.get('count')
    elements = []

    # Find element patterns after UNPACK_SEQUENCE
    # Next COMPARE or STORE_FAST operations define elements
    unpackIndex = next((i for i, op in enumerate(ops) if op.get('type') == 'UNPACK_SEQUENCE'), -1)
    afterUnpack = ops[unpackIndex + 1:]

    # Check for SWAP operation (indicates element order reversal)
    hasSwap = (len(afterUnpack) > 0
               and afterUnpack[0].get('type') == 'SWAP'
               and afterUnpack[0].get('depth') == 2)

    # Skip SWAP when processing elements
    if hasSwap:
        markConsumed(afterUnpack[0])
        afterUnpack = afterUnpack[1:]

    # Process operations to extract element patterns
    elementIndex = 0
    i = 0
    while i < len(afterUnpack) and elementIndex < count:
        op = afterUnpack[i]

        if op.get('type') == 'COMPARE':
            # Literal pattern: value is compared
            # right is ASTObject with the literal value
            if isinstance(op.get('right'), ASTObject):
                literalValue = op.get('right')
                elements.append(ASTPattern(ASTPattern.PatternType.Literal, literalValue))
                markConsumed(op)
                elementIndex += 1
        elif op.get('type') == 'STORE_FAST':
            # Variable pattern: value is captured
            varName = op.get('name')
            elements.append(ASTPattern(ASTPattern.PatternType.Variable, varName))
            markConsumed(op)
            elementIndex += 1
        i += 1

    # Fill remaining with wildcards if needed
    while len(elements) < count:
        elements.append(ASTPattern(ASTPattern.PatternType.Wildcard, '_'))

    # If SWAP was used, reverse element order
    # SWAP 2 after UNPACK indicates elements were swapped to change check order
    # We need to reverse to restore source pattern order
    if hasSwap:
        elements.reverse()

    # Create sequence pattern
    markConsumed(matchSeqOp)
    markConsumed(unpackOp)
    return buildResult(ASTPattern(ASTPattern.PatternType.Sequence, elements))


def hasUpcomingMatchCase(self):
    nextOpCodeId = getattr(self.code.Next, 'OpCodeID', None) if self.code.Next is not None else None
    nextNextOpCodeId = None
    if self.code.Next is not None and getattr(self.code.Next, 'Next', None) is not None:
        nextNextOpCodeId = getattr(self.code.Next.Next, 'OpCodeID', None)

    matchOpcodes = [
        self.OpCodes.MATCH_SEQUENCE,
        self.OpCodes.MATCH_MAPPING,
        self.OpCodes.MATCH_KEYS,
        self.OpCodes.MATCH_CLASS_A,
    ]

    if nextOpCodeId in matchOpcodes:
        return True

    isCopy = ((nextOpCodeId == self.OpCodes.COPY_A and getattr(self.code.Next, 'Argument', None) == 1) or
              nextOpCodeId == self.OpCodes.DUP_TOP)
    if isCopy:
        return True

    nextIsPop = nextOpCodeId == self.OpCodes.POP_TOP
    nextNextIsCopy = nextNextOpCodeId == self.OpCodes.COPY_A
    nextNextIsMatch = nextNextOpCodeId == self.OpCodes.MATCH_SEQUENCE
    if nextIsPop and (nextNextIsCopy or nextNextIsMatch):
        return True

    # NOP followed by code (no COMPARE_OP) = default case (case _:)
    # This pattern appears in 3.10/3.11 after the last literal case
    if nextOpCodeId == self.OpCodes.NOP and self.currentMatch:
        # Check if this NOP is followed by executable code (not another pattern)
        afterNop = self.code.Next.Next if self.code.Next is not None else None
        if (afterNop is not None
                and afterNop.OpCodeID != self.OpCodes.COMPARE_OP_A
                and afterNop.OpCodeID != self.OpCodes.COPY_A
                and afterNop.OpCodeID != self.OpCodes.DUP_TOP):
            return True  # Default case ahead

    # 3.13 literal-only match compilation: sequences of CACHE/LOAD_CONST/COMPARE_OP
    scan = self.code.Next
    steps = 0
    while scan is not None and steps < 8:
        if scan.OpCodeID == self.OpCodes.COMPARE_OP_A:
            return True
        if (scan.OpCodeID == self.OpCodes.LOAD_CONST_A or
                scan.OpCodeID == self.OpCodes.CACHE or
                scan.OpCodeID == self.OpCodes.COPY_A or
                scan.OpCodeID == self.OpCodes.POP_JUMP_IF_FALSE_A):
            scan = scan.Next
            steps += 1
            continue
        break

    look = self.code.Next
    steps = 0
    while look is not None and steps < 50:
        if look.OpCodeID in matchOpcodes or look.OpCodeID == self.OpCodes.POP_TOP:
            return True
        look = look.Next
        steps += 1

    return False


def flushCurrentCaseBody(self):
    if not self.currentCase:
        return False

    startIdx = self.caseBodyStartIndex or 0
    bodyNodes = self.curBlock.nodes[startIdx:]
    guard_and_body = extractGuardFromBody(bodyNodes)
    guard = guard_and_body['guard']
    normalized = guard_and_body['bodyNodes']
    filtered = [node for node in normalized
                if not isinstance(node, ASTName) and not isinstance(node, ASTTuple)]

    def _name(n):
        return type(n).__name__ if n is not None else type(n).__name__
    debugNodes = []
    for n in filtered:
        frag = n.codeFragment() if (n is not None and hasattr(n, 'codeFragment')) else ''
        debugNodes.append(f"{_name(n)}:{frag}")
    debug_log(f"[MATCH] Case nodes: {' | '.join(str(d) for d in debugNodes)}")
    if guard:
        g_frag = guard.codeFragment() if hasattr(guard, 'codeFragment') else type(guard).__name__
        debug_log(f"[MATCH] Guard detected: {g_frag}")

    body = ASTNodeList(filtered)
    self.currentCase.m_body = body
    if guard:
        self.currentCase.m_guard = guard
    self.currentMatch.addCase(self.currentCase)
    # Truncate curBlock.nodes to startIdx (JS: this.curBlock.nodes.length = startIdx)
    del self.curBlock.nodes[startIdx:]
    self.currentCase = None

    debug_log(f"[MATCH] Case body recorded with {len(filtered)} node(s)")

    return True


def beginMatchCaseFromPattern(self, options=None):
    if options is None:
        options = {}
    if not self.currentMatch:
        return False

    # Close the previous case body when a new case starts
    flushCurrentCaseBody(self)

    pr = reconstructPattern(self.patternOps)
    pattern = pr['pattern']
    remainderOps = pr['remainderOps']
    self.caseBodyStartIndex = len(self.curBlock.nodes) if self.curBlock is not None else 0

    initialGuard = guardFromPatternRemainder(remainderOps)
    self.currentCase = ASTCase(pattern, None, initialGuard)
    self.currentCase.line = options.get('line') or self.code.Current.LineNo
    self.inMatchPattern = False
    self.patternOps = []

    debug_log(f"[MATCH] Starting case ({options.get('reason') or 'pop_top'}) at offset {self.code.Current.Offset}")
    debug_log(f"  caseBodyStartIndex={self.caseBodyStartIndex}")

    return True


def finalizeMatchCase(self):
    if not self.currentMatch:
        return False

    flushCurrentCaseBody(self)

    # Normalize guard-only cases that lost their bodies due to literal/guard separation
    def normalizeMatchCases(matchNode):
        if (matchNode is None
                or not getattr(matchNode, 'cases', None)
                or len(matchNode.cases) < 2):
            return
        wildcardType = ASTPattern.PatternType.Wildcard
        cleaned = []
        i = 0
        while i < len(matchNode.cases):
            cur = matchNode.cases[i]
            next_ = matchNode.cases[i + 1] if i + 1 < len(matchNode.cases) else None
            curBodyLen = len(cur.body.list) if (cur.body is not None and hasattr(cur.body, 'list') and cur.body.list is not None) else 0
            curHasGuard = bool(cur.guard)
            nextIsWildcard = (next_ is not None
                              and next_.pattern is not None
                              and next_.pattern.type == wildcardType
                              and not next_.guard)
            if curHasGuard and curBodyLen == 0 and nextIsWildcard:
                # Move body from wildcard fallback into guarded case
                cur.m_body = next_.body
                i += 1  # Skip the wildcard case
            # Skip empty wildcard cases (no guard, no body)
            if (cur.pattern is not None
                    and cur.pattern.type == wildcardType
                    and not cur.guard
                    and curBodyLen == 0):
                i += 1
                continue
            cleaned.append(cur)
            i += 1
        matchNode.m_cases = cleaned

    normalizeMatchCases(self.currentMatch)

    debug_log(f"[MATCH] Match complete, appending ASTMatch to parent block")

    if len(self.dataStack) > 0 and self.dataStack.top() is self.matchSubject:
        self.dataStack.pop()

    targetBlock = self.matchParentBlock or self.curBlock

    preIndex = max(0, self.matchPreNodesStart or 0)
    del targetBlock.nodes[preIndex:]
    targetBlock.append(self.currentMatch)
    self.currentMatch = None
    self.matchSubject = None
    self.matchParentBlock = None
    self.matchPreNodesStart = 0
    self.caseBodyStartIndex = 0
    return True


def handleExecStmt(self):
    if isinstance(self.dataStack.top(), ASTChainStore):
        self.dataStack.pop()
    loc = self.dataStack.pop()
    glob = self.dataStack.pop()
    stmt = self.dataStack.pop()
    node = ASTExec(stmt, glob, loc)
    node.line = self.code.Current.LineNo
    self.curBlock.append(node)


def handleFormatValueA(self):
    conversion_flag = self.code.Current.Argument
    if conversion_flag in (
        ASTFormattedValue.ConversionFlag.None_,
        ASTFormattedValue.ConversionFlag.Str,
        ASTFormattedValue.ConversionFlag.Repr,
        ASTFormattedValue.ConversionFlag.ASCII,
    ):
        val = self.dataStack.pop()
        node = ASTFormattedValue(val, conversion_flag, None)
        node.line = self.code.Current.LineNo
        self.dataStack.append(node)
    elif conversion_flag == ASTFormattedValue.ConversionFlag.FmtSpec:
        format_spec = self.dataStack.pop()
        val = self.dataStack.pop()
        node = ASTFormattedValue(val, conversion_flag, format_spec)
        node.line = self.code.Current.LineNo
        self.dataStack.append(node)
    else:
        debug_error(f"Unsupported FORMAT_VALUE_A conversion flag: {self.code.Current.Argument}\n")


def hasUpcomingStringBuild(context):
    lookahead = [
        context.OpCodes.BUILD_STRING_A,
        context.OpCodes.BUILD_INTERPOLATION_A,
        context.OpCodes.BUILD_TEMPLATE,
    ]
    earlyStops = {
        context.OpCodes.RETURN_VALUE,
        context.OpCodes.CALL_A,
        context.OpCodes.CALL_KW_A,
        context.OpCodes.CALL_FUNCTION_EX,
        context.OpCodes.STORE_FAST_A,
        context.OpCodes.STORE_NAME_A,
        context.OpCodes.STORE_GLOBAL_A,
        context.OpCodes.STORE_ATTR_A,
        context.OpCodes.STORE_DEREF_A,
    }

    # 3.11+ inline caches inflate the physical instruction stream; a single
    # f-string with a few interpolations easily spans 30+ code slots before
    # reaching BUILD_STRING. Cap generously and rely on earlyStops to bound.
    for step in range(1, 49):
        instr = context.code.PeekInstructionAtOffset(context.code.Current.Offset + step * 2)
        if instr is None:
            break
        if instr.OpCodeID in lookahead:
            return True
        if instr.OpCodeID in earlyStops:
            break
    return False


def handleFormatSimple(self):
    # Python 3.13+ FORMAT_SIMPLE: format TOS without spec (conversion may have been applied by CONVERT_VALUE)
    val = self.dataStack.pop()

    if isinstance(val, ASTFormattedValue):
        node = val
    else:
        node = ASTFormattedValue(
            val,
            ASTFormattedValue.ConversionFlag.None_,
            None,
        )
        node.line = self.code.Current.LineNo

    if not hasUpcomingStringBuild(self):
        joined = ASTJoinedStr([node])
        joined.line = node.line
        self.dataStack.append(joined)
        return

    self.dataStack.append(node)


def handleFormatWithSpec(self):
    # Python 3.14 FORMAT_WITH_SPEC: value already converted (optional) + format spec on stack.
    formatSpec = self.dataStack.pop()
    val = self.dataStack.pop()

    if isinstance(val, ASTFormattedValue):
        target = val
    else:
        target = ASTFormattedValue(val, ASTFormattedValue.ConversionFlag.None_, None)
        target.line = self.code.Current.LineNo
    target.m_format_spec = formatSpec
    if not hasUpcomingStringBuild(self):
        joined = ASTJoinedStr([target])
        joined.line = target.line
        self.dataStack.append(joined)
        return

    self.dataStack.append(target)


def handlePopTop(self):
    # Match/case: Detect transition from pattern checks to case body
    readyForWildcard = (self.currentMatch
                       and not self.inMatchPattern
                       and (len(self.patternOps) if self.patternOps else 0) == 0
                       and not hasUpcomingMatchCase(self))
    if self.inMatchPattern or readyForWildcard:
        prev_name = getattr(self.code.Prev, 'InstructionName', None) if self.code.Prev is not None else None
        debug_log(f"[POP_TOP] Evaluating match state at offset {self.code.Current.Offset}, prev={prev_name}")
        # Check if this is the success path (pattern matched)
        # Two scenarios:
        # 1. Sequence patterns: POP_JUMP → UNPACK/etc → POP_TOP (Prev is NOT jump)
        # 2. Literal patterns: POP_JUMP → POP_TOP (Prev IS jump)
        prev_op = getattr(self.code.Prev, 'OpCodeID', None) if self.code.Prev is not None else None
        prevIsJump = prev_op in (
            self.OpCodes.POP_JUMP_IF_FALSE_A,
            self.OpCodes.POP_JUMP_FORWARD_IF_FALSE_A,
            self.OpCodes.POP_JUMP_IF_TRUE_A,
            self.OpCodes.JUMP_IF_FALSE_A,
        )

        # A POP_TOP following ROT_TWO/ROT_THREE/ROT_FOUR is part of binding-extraction
        # stack cleanup inside a class/sequence pattern, not the body-start POP_TOP.
        prevIsRot = prev_op in (
            self.OpCodes.ROT_TWO,
            self.OpCodes.ROT_THREE,
            self.OpCodes.ROT_FOUR,
        )

        # If the next non-CACHE opcode is STORE_FAST/STORE_NAME, this POP_TOP is mid-pattern
        # binding cleanup (pops the match result tuple before the remaining STORE captures).
        def _nextIsStoreBinding():
            scan = self.code.Next
            steps = 0
            while scan is not None and steps < 4:
                if scan.OpCodeID == self.OpCodes.CACHE:
                    scan = scan.Next
                    steps += 1
                    continue
                return (scan.OpCodeID == self.OpCodes.STORE_FAST_A or
                        scan.OpCodeID == self.OpCodes.STORE_NAME_A)
            return False

        nextIsStoreBinding = _nextIsStoreBinding()

        patternHasOps = (len(self.patternOps) if self.patternOps else 0) > 0
        isLiteralPattern = patternHasOps and not any(
            op.get('type') in ("MATCH_SEQUENCE", "MATCH_CLASS", "MATCH_MAPPING", "MATCH_KEYS")
            for op in self.patternOps
        )
        shouldStartCase = readyForWildcard or bool(self.inMatchPattern)
        if patternHasOps:
            shouldStartCase = True
        if patternHasOps and isLiteralPattern and not prevIsJump:
            shouldStartCase = False
        if patternHasOps and prevIsRot:
            shouldStartCase = False
        if patternHasOps and nextIsStoreBinding:
            shouldStartCase = False

        # When readyForWildcard fires on the match-exit POP_TOP and the only
        # code that follows is the function's implicit `return None` tail,
        # the source didn't actually include a `case _:` clause — CPython
        # emits the tail unconditionally. Suppress the phantom wildcard.
        if readyForWildcard and not patternHasOps:
            scan = self.code.Next
            steps = 0
            sawLoadNone = False
            while scan is not None and steps < 6:
                op = scan.OpCodeID
                if (op == self.OpCodes.CACHE or
                        op == self.OpCodes.RESUME_A or
                        op == self.OpCodes.NOP):
                    scan = scan.Next
                    steps += 1
                    continue
                if op == self.OpCodes.LOAD_CONST_A and not sawLoadNone:
                    sawLoadNone = True
                    scan = scan.Next
                    steps += 1
                    continue
                if op == self.OpCodes.RETURN_VALUE or op == self.OpCodes.RETURN_CONST_A:
                    if sawLoadNone or op == self.OpCodes.RETURN_CONST_A:
                        shouldStartCase = False
                    break
                break

        if shouldStartCase:
            if beginMatchCaseFromPattern(self, {'reason': 'pop_top'}):
                return
        else:
            types_list = [op.get('type') for op in self.patternOps]
            debug_log(f"[POP_TOP] Skipping case start at offset {self.code.Current.Offset} (literal={isLiteralPattern}, prevIsJump={prevIsJump})")
            debug_log(f"  patternOps={types_list}")
        # Consume POP_TOP related to match even if no case starts
        if len(self.dataStack) > 0:
            self.dataStack.pop()
        return

    # Mid-UNPACK_SEQUENCE POP_TOP: CPython emits `a, _, b = tup` as
    # UNPACK 3 / STORE a / POP_TOP / STORE b, where POP_TOP drops the
    # middle slot. Our unpack-state-machine accumulates STORE targets
    # into a tuple; treat POP_TOP as an anonymous `_` slot so the
    # remaining STORE_FAST still sees the tuple on the stack.
    if self.unpack > 0:
        tupleNode = self.dataStack.top()
        if isinstance(tupleNode, ASTTuple):
            placeholder = ASTName("_")
            # JS: if (this.starPos-- == 0) placeholder.name = "*_"
            if self.starPos == 0:
                placeholder.name = "*_"
            self.starPos -= 1
            tupleNode.add(placeholder)
            self.unpack -= 1
            if self.unpack <= 0:
                self.dataStack.pop()
                seqNode = self.dataStack.pop()
                node = ASTStore(seqNode, tupleNode)
                node.line = self.code.Current.LineNo
                self.curBlock.append(node)
            return

    prev_op = getattr(self.code.Prev, 'OpCodeID', None) if self.code.Prev is not None else None
    if prev_op in (
        self.OpCodes.JUMP_ABSOLUTE_A,
        self.OpCodes.JUMP_FORWARD_A,
        self.OpCodes.POP_JUMP_IF_FALSE_A,
        self.OpCodes.JUMP_IF_FALSE_A,
    ):
        if self.curBlock.blockType == ASTBlock.BlockType.Except:
            # Skipping POP_TOP, POP_TOP, POP_TOP
            if prev_op in (self.OpCodes.JUMP_ABSOLUTE_A, self.OpCodes.JUMP_FORWARD_A):
                next_op = getattr(self.code.Next, 'OpCodeID', None) if self.code.Next is not None else None
                next_next_op = None
                if self.code.Next is not None and getattr(self.code.Next, 'Next', None) is not None:
                    next_next_op = getattr(self.code.Next.Next, 'OpCodeID', None)
                if next_op == self.OpCodes.POP_TOP and next_next_op == self.OpCodes.POP_TOP:
                    self.code.GoNext(2)
            elif prev_op == self.OpCodes.POP_JUMP_IF_FALSE_A:
                next_op = getattr(self.code.Next, 'OpCodeID', None) if self.code.Next is not None else None
                next_next_op = None
                if self.code.Next is not None and getattr(self.code.Next, 'Next', None) is not None:
                    next_next_op = getattr(self.code.Next.Next, 'OpCodeID', None)
                if (next_op in (self.OpCodes.STORE_NAME_A, self.OpCodes.STORE_FAST_A)
                        and next_next_op == self.OpCodes.POP_TOP):
                    exceptionTypeNode = self.curBlock.condition
                    if not isinstance(exceptionTypeNode, ASTName):
                        typeName = type(exceptionTypeNode).__name__ if exceptionTypeNode is not None else 'null'
                        debug_error(f"Expected ASTName, but got {typeName}")
                        return
                    exceptionName = ASTName(self.code.Next.Name)
                    exceptionName.line = self.code.Current.LineNo
                    self.curBlock.condition = ASTStore(exceptionTypeNode, exceptionName)
                    self.code.GoNext(2)
            elif prev_op == self.OpCodes.JUMP_IF_FALSE_A:
                next_op = getattr(self.code.Next, 'OpCodeID', None) if self.code.Next is not None else None
                next_next_op = None
                next_next_next_op = None
                if self.code.Next is not None and getattr(self.code.Next, 'Next', None) is not None:
                    next_next_op = getattr(self.code.Next.Next, 'OpCodeID', None)
                    if getattr(self.code.Next.Next, 'Next', None) is not None:
                        next_next_next_op = getattr(self.code.Next.Next.Next, 'OpCodeID', None)
                if (next_op == self.OpCodes.POP_TOP
                        and next_next_op in (self.OpCodes.STORE_NAME_A, self.OpCodes.STORE_FAST_A)
                        and next_next_next_op == self.OpCodes.POP_TOP):
                    exceptionTypeNode = self.curBlock.condition
                    if not isinstance(exceptionTypeNode, ASTName):
                        typeName = type(exceptionTypeNode).__name__ if exceptionTypeNode is not None else 'null'
                        debug_error(f"Expected ASTName, but got {typeName}")
                        return
                    exceptionName = ASTName(self.code.Next.Next.Name)
                    exceptionName.line = self.code.Current.LineNo
                    self.curBlock.condition = ASTStore(exceptionTypeNode, exceptionName)
                    self.code.GoNext(2)
        return
    elif prev_op == self.OpCodes.PRINT_ITEM_TO and isinstance(self.curBlock.nodes.top(), ASTPrint):
        printNode = self.curBlock.nodes.top()
        if printNode.stream is not None and printNode.stream == self.dataStack.top():
            self.dataStack.pop()
            return

    value = self.dataStack.pop()
    if self.appendExceptionExprs and self.curBlock.blockType == ASTBlock.BlockType.Except:
        # direct expression in handler (e.g., add_note call result is discarded)
        if value is not None and not isinstance(value, ASTNone):
            self.curBlock.append(value)
        return
    if not self.curBlock.inited:
        if self.curBlock.blockType == ASTBlock.BlockType.With:
            # POP_TOP initializing a WITH block consumes the context-manager
            # expression off the stack (Py3.0+ `with EXPR:` with no `as`).
            # The value IS the with-expr, not a body statement — return before
            # the fall-through append would add a phantom duplicate.
            self.curBlock.expr = value
            self.curBlock.init()
            return
        elif self.curBlock.blockType == ASTBlock.BlockType.If and not self.curBlock.condition:
            self.curBlock.condition = value
        # Don't initialize For/AsyncFor blocks here - they are initialized by STORE_FAST/STORE_NAME when setting the index
        if (self.curBlock.blockType != ASTBlock.BlockType.For and
                self.curBlock.blockType != ASTBlock.BlockType.AsyncFor):
            self.curBlock.init()
    elif value is None or getattr(value, 'processed', False):
        return

    if not isinstance(value, ASTObject):
        self.curBlock.append(value)

    # Python 2.3 listcomp body uses `_[1](x)` (the cached list.append call)
    # instead of LIST_APPEND. Detect this call, whether emitted directly in
    # a For+comp body or nested inside if-filters (`[x for x in y if c]`),
    # and materialize an ASTComprehension instead of leaving the call as a
    # bogus body statement.
    if isinstance(value, ASTCall):
        forBlock = None
        ifBlocks = []
        for i in range(len(self.blocks) - 1, -1, -1):
            blk = self.blocks[i]
            if blk.blockType == ASTBlock.BlockType.For and blk.comprehension:
                forBlock = blk
                break
            if blk.blockType == ASTBlock.BlockType.If:
                ifBlocks.append(blk)
            else:
                break

        listCompAppendRefs = getattr(self, '_listCompAppendRefs', None)
        funcIsCompAppend = (forBlock is not None
                            and value.func is not None
                            and listCompAppendRefs is not None
                            and value.func in list(listCompAppendRefs.values()))
        isDirectCompBody = forBlock is not None and self.curBlock is forBlock

        if funcIsCompAppend or isDirectCompBody:
            pparams = value.pparams
            if not pparams.empty():
                if funcIsCompAppend and self.curBlock is not forBlock:
                    for ifBlk in ifBlocks:
                        cond = ifBlk.condition
                        if not cond:
                            continue
                        if ifBlk.negative:
                            notCond = ASTUnary(cond, ASTUnary.UnaryOp.Not)
                            notCond.line = self.code.Current.LineNo
                            cond = notCond
                        if forBlock.condition:
                            andCond = ASTBinary(forBlock.condition, cond, ASTBinary.BinOp.LogicalAnd)
                            andCond.line = self.code.Current.LineNo
                            forBlock.condition = andCond
                        else:
                            forBlock.condition = cond
                    while self.curBlock is not forBlock and len(self.blocks) > 1:
                        self.blocks.pop()
                        self.curBlock = self.blocks.top()
                res = pparams[0]
                node = ASTComprehension(res)
                node.line = self.code.Current.LineNo
                self.dataStack.append(node)


def handlePrintExpr(self):
    processPrint(self)


def handlePrintItem(self):
    processPrint(self)


def processPrint(self):
    printNode = None
    if len(self.curBlock.nodes) > 0 and isinstance(self.curBlock.nodes.top(), ASTPrint):
        printNode = self.curBlock.nodes.top()
    if printNode is not None and printNode.stream is None and not printNode.eol:
        printNode.add(self.dataStack.pop())
    else:
        node = ASTPrint(self.dataStack.pop())
        node.line = self.code.Current.LineNo
        self.curBlock.append(node)


def handlePrintItemTo(self):
    stream = self.dataStack.pop()
    printNode = None

    if len(self.curBlock.nodes) > 0 and isinstance(self.curBlock.nodes.top(), ASTPrint):
        printNode = self.curBlock.nodes.top()

    if printNode is not None and printNode.stream == stream and not printNode.eol:
        printNode.add(self.dataStack.pop())
    else:
        node = ASTPrint(self.dataStack.pop(), stream)
        node.line = self.code.Current.LineNo
        self.curBlock.append(node)


def handlePrintNewline(self):
    printNode = None
    if not self.curBlock.empty() and isinstance(self.curBlock.nodes.top(), ASTPrint):
        printNode = self.curBlock.nodes.top()
    if printNode is not None and printNode.stream is None and not printNode.eol:
        printNode.eol = True
    else:
        node = ASTPrint()
        node.line = self.code.Current.LineNo
        self.curBlock.append(node)
    self.dataStack.pop()


def handlePrintNewlineTo(self):
    stream = self.dataStack.pop()

    printNode = None
    if not self.curBlock.empty() and isinstance(self.curBlock.nodes.top(), ASTPrint):
        printNode = self.curBlock.nodes.top()

    if printNode is not None and printNode.stream == stream and not printNode.eol:
        printNode.eol = True
    else:
        node = ASTPrint(None, stream)
        node.line = self.code.Current.LineNo
        self.curBlock.append(node)
    self.dataStack.pop()


def handleReturnGenerator(self):
    # Python 3.11+ RETURN_GENERATOR opcode
    # Appears at the start of generator/async generator functions
    # Creates the generator object - no action needed in decompiler
    debug_log(f"[RETURN_GENERATOR] at offset {self.code.Current.Offset} - generator function detected")


def handleInstrumentedReturnValueA(self):
    self.handleReturnValue()


def handleReturnValue(self):
    if self.currentMatch:
        # Only start new case if no current case AND (not in pattern OR has unflushed pattern ops)
        hasUnflushedPattern = (len(self.patternOps) if self.patternOps else 0) > 0
        needsNewCase = not self.currentCase and (not self.inMatchPattern or hasUnflushedPattern)
        # Suppress phantom wildcard when this is the function-tail implicit
        # return None: no pattern ops recorded, LOAD_CONST None precedes us,
        # and this is the last RETURN_VALUE in the code object. CPython
        # emits the tail whether or not source had `case _:`.
        top = self.dataStack.top()
        topIsNone = (isinstance(top, ASTNone) or
                     (isinstance(top, ASTObject)
                      and getattr(getattr(top, 'obj', None), 'ClassName', None) == 'Py_None'))
        isImplicitTail = not hasUnflushedPattern and topIsNone and not self.code.Next
        if needsNewCase and not isImplicitTail:
            beginMatchCaseFromPattern(self, {'reason': 'return'})

    # CRITICAL: Close blocks that have ended before processing return
    # Return statements often appear at block boundaries
    while (self.curBlock.end > 0
           and self.curBlock.end <= self.code.Current.Offset
           and self.curBlock.blockType != ASTBlock.BlockType.Main
           and len(self.blocks) > 1):

        debug_log(f"[handleReturnValue] Closing ended block {self.curBlock.type_str}({self.curBlock.start}-{self.curBlock.end}) at offset {self.code.Current.Offset}")

        closedBlock = self.blocks.pop()
        self.curBlock = self.blocks.top()
        self.curBlock.append(closedBlock)

        debug_log(f"  → Appended to {self.curBlock.type_str}({self.curBlock.start}-{self.curBlock.end}), now has {len(self.curBlock.nodes)} nodes")

    # 3.12 exception-group prolog sometimes leaves synthetic None; drop only if it's a synthetic None before PUSH_EXC_INFO.
    value = self.dataStack.pop()
    nextOp = self.code.Next
    # Only drop return if it's a synthetic None followed by PUSH_EXC_INFO (exception-group prolog pattern).
    # Real returns before exception handlers (like in with-statements) should NOT be dropped.
    if isinstance(value, ASTNone) and nextOp is not None and nextOp.OpCodeID == self.OpCodes.PUSH_EXC_INFO:
        # Check if this is a synthetic return (no explicit line number or same line as previous instruction)
        curLine = getattr(self.code.Current, 'LineNo', None) if self.code.Current is not None else None
        prevLine = getattr(self.code.Previous, 'LineNo', None) if getattr(self.code, 'Previous', None) is not None else None
        if curLine == prevLine or not curLine:
            # Likely synthetic None from exception prolog - drop it
            return
    if value is None:
        value = ASTNone()
    node = ASTReturn(value)
    node.inLambda = self.object.Name == '<lambda>'
    node.line = self.code.Current.LineNo

    self.curBlock.append(node)

    if self.currentMatch:
        def _hasDefaultAhead():
            scan = self.code.Next
            steps = 0
            retOps = [self.OpCodes.RETURN_CONST_A, self.OpCodes.RETURN_VALUE, self.OpCodes.RETURN_VALUE_A]
            skipOps = [self.OpCodes.CACHE, self.OpCodes.NOP]
            while scan is not None and steps < 4:
                if scan.OpCodeID in retOps:
                    return True
                if scan.OpCodeID in skipOps:
                    scan = scan.Next
                    steps += 1
                    continue
                break
            return False

        hasDefaultAhead = _hasDefaultAhead()
        if hasDefaultAhead:
            # Default case ahead - flush current case before default starts
            if self.currentCase:
                flushCurrentCaseBody(self)
            return
        if not hasUpcomingMatchCase(self):
            finalizeMatchCase(self)
            return
        # More cases coming - flush current case before next one starts
        if self.currentCase:
            flushCurrentCaseBody(self)

    if (not self.currentCase
            and self.curBlock.blockType in (ASTBlock.BlockType.If, ASTBlock.BlockType.Else)
            and (self.object.Reader.versionCompare(2, 6) >= 0)):
        prev = self.curBlock
        self.blocks.pop()
        self.curBlock = self.blocks.top()
        if (isinstance(prev, ASTCondBlock)
                and len(prev.nodes) == 1
                and prev.line == value.line):
            prev = ASTReturn(ASTBinary(prev.condition, value,
                                       ASTBinary.BinOp.LogicalOr if prev.negative else ASTBinary.BinOp.LogicalAnd))

        self.curBlock.append(prev)

        next_op = getattr(self.code.Next, 'OpCodeID', None) if self.code.Next is not None else None
        if next_op in (self.OpCodes.JUMP_ABSOLUTE_A, self.OpCodes.JUMP_FORWARD_A):
            self.code.GoNext()


def handleInstrumentedReturnConstA(self):
    self.handleReturnConstA()


def handleReturnConstA(self):
    # If a new pattern matched but case body not started yet, open it now
    # Only start new case if no current case AND (not in pattern OR has unflushed pattern ops)
    if self.currentMatch:
        hasUnflushedPattern = (len(self.patternOps) if self.patternOps else 0) > 0
        needsNewCase = not self.currentCase and (not self.inMatchPattern or hasUnflushedPattern)
        if needsNewCase:
            beginMatchCaseFromPattern(self, {'reason': 'return'})

    nextOp = self.code.Next
    if nextOp is not None and nextOp.OpCodeID == self.OpCodes.PUSH_EXC_INFO:
        return

    # Skip implicit return None in various contexts:
    # 1. Module-level implicit return at end
    # 2. Exception cleanup after successful except* handling (POP_EXCEPT → RETURN_CONST None → SWAP)
    constObj = self.code.Current.ConstantObject
    isNone = (constObj is None or getattr(constObj, 'ClassName', None) == 'Py_None')
    isModuleLevel = self.object.Name == '<module>'
    isAtEnd = (nextOp is None
               or nextOp.OpCodeID == self.OpCodes.RERAISE_A
               or nextOp.OpCodeID == self.OpCodes.RERAISE)
    prev_op = getattr(self.code.Prev, 'OpCodeID', None) if self.code.Prev is not None else None
    prevIsPOPExcept = prev_op == self.OpCodes.POP_EXCEPT
    nextIsSWAP = nextOp is not None and nextOp.OpCodeID == self.OpCodes.SWAP_A
    nextIsRERAISE = nextOp is not None and (nextOp.OpCodeID == self.OpCodes.RERAISE or
                                            nextOp.OpCodeID == self.OpCodes.RERAISE_A)
    isExceptCleanup = isNone and prevIsPOPExcept and nextIsSWAP
    # CPython 3.11+ places the function's implicit `return None` at the tail of an
    # except handler (POP_EXCEPT → RETURN_CONST None → RERAISE or end-of-function).
    # The source has no explicit return there; drop it so the handler body doesn't
    # inherit a phantom return.
    isExceptTailImplicitReturn = (isNone and prevIsPOPExcept
                                  and (nextIsRERAISE or nextOp is None))

    if isNone and isModuleLevel and isAtEnd:
        return  # Skip implicit return None at module end
    if isExceptCleanup:
        return  # Skip return None in exception cleanup (except* success path)
    if isExceptTailImplicitReturn:
        return  # Skip synthetic return None at end of except handler

    value = ASTObject(self.code.Current.ConstantObject)
    node = ASTReturn(value)
    node.line = self.code.Current.LineNo

    self.curBlock.append(node)

    if self.currentMatch:
        def _hasDefaultAhead():
            scan = self.code.Next
            steps = 0
            retOps = [self.OpCodes.RETURN_CONST_A, self.OpCodes.RETURN_VALUE, self.OpCodes.RETURN_VALUE_A]
            skipOps = [self.OpCodes.CACHE, self.OpCodes.NOP]
            while scan is not None and steps < 4:
                if scan.OpCodeID in retOps:
                    return True
                if scan.OpCodeID in skipOps:
                    scan = scan.Next
                    steps += 1
                    continue
                break
            return False

        hasDefaultAhead = _hasDefaultAhead()
        if hasDefaultAhead:
            # Default case ahead - flush current case before default starts
            if self.currentCase:
                flushCurrentCaseBody(self)
            return
        if not hasUpcomingMatchCase(self):
            finalizeMatchCase(self)
            return
        # More cases coming - flush current case before next one starts
        if self.currentCase:
            flushCurrentCaseBody(self)


def handleSetLinenoA(self):
    pass


def handleSetupAnnotations(self):
    self.variable_annotations = True


def handleEndAsyncFor(self):
    # Python 3.9+ END_ASYNC_FOR opcode
    # Python 3.9-3.10: finally handler for SETUP_FINALLY in async for loops
    # Python 3.11+: direct exception handler (no CONTAINER/finally wrapper)

    debug_log(f"[END_ASYNC_FOR] curBlock={self.curBlock.type_str}, stack depth={len(self.blocks)}")
    parts = ' → '.join(f"[{i}]{b.type_str}" for i, b in enumerate(self.blocks))
    debug_log(f"  Block stack: {parts}")

    # Python 3.11+: Direct async for block (no CONTAINER)
    if (self.object.Reader.versionCompare(3, 11) >= 0
            and self.curBlock.blockType == ASTBlock.BlockType.AsyncFor):

        debug_log(f"  Python 3.11+ direct AsyncFor, nodes: {len(self.curBlock.nodes)}")

        # If body is empty, add pass
        if len(self.curBlock.nodes) == 0:
            passNode = ASTKeyword(ASTKeyword.Word.Pass)
            passNode.line = self.code.Current.LineNo
            self.curBlock.nodes.append(passNode)

            debug_log(f"  ✓ Added pass statement to empty Python 3.11 async for body")

        # Close the async for block
        self.blocks.pop()
        self.blocks.top().append(self.curBlock)
        self.curBlock = self.blocks.top()

        debug_log(f"  ✓ Closed Python 3.11 AsyncFor block")

        return

    # Python 3.9-3.10: CONTAINER/finally pattern
    if self.curBlock.blockType == ASTBlock.BlockType.Finally:
        finallyBlock = self.curBlock

        # Pop the finally block
        self.blocks.pop()
        self.curBlock = self.blocks.top()

        # Check if we're in CONTAINER → AsyncFor pattern
        if (self.curBlock.blockType == ASTBlock.BlockType.Container
                and len(self.blocks) > 1):
            cont = self.curBlock
            parentBlock = self.blocks[len(self.blocks) - 2]

            if (parentBlock.blockType == ASTBlock.BlockType.AsyncFor
                    and parentBlock.inited):

                debug_log(f"  Found CONTAINER→AsyncFor(inited), hiding CONTAINER")
                debug_log(f"  AsyncFor has {len(parentBlock.nodes)} nodes, Finally has {len(finallyBlock.nodes)} nodes")

                # Extract loop body from finally block (Python 3.9 uses finally, not try)
                # Skip STORE (index already set by processStore) and skip async implementation details
                for i in range(len(finallyBlock.nodes)):
                    node = finallyBlock.nodes[i]
                    # Skip implementation details: STORE, yield from, await calls
                    if (node is not None
                            and not isinstance(node, ASTStore)
                            and type(node).__name__ != 'ASTReturn'
                            and not (type(node).__name__ == 'ASTCall'
                                     and getattr(getattr(node, 'func', None), 'name', None) == 'await')):
                        parentBlock.nodes.append(node)

                # If body is empty, add pass
                if len(parentBlock.nodes) == 0:
                    passNode = ASTKeyword(ASTKeyword.Word.Pass)
                    passNode.line = finallyBlock.line
                    parentBlock.nodes.append(passNode)

                    debug_log(f"  ✓ Added pass statement to empty async for body")

                # Pop CONTAINER without appending it
                self.blocks.pop()
                self.curBlock = self.blocks.top()

                # Close AsyncFor early and mark rest as unreachable
                if self.curBlock.blockType == ASTBlock.BlockType.AsyncFor:
                    asyncForEnd = self.curBlock.end
                    self.blocks.pop()
                    self.blocks.top().append(self.curBlock)
                    self.curBlock = self.blocks.top()

                    # Mark everything until the original AsyncFor end as unreachable
                    self.unreachableUntil = asyncForEnd

                    debug_log(f"  ✓ Closed AsyncFor, marking {self.code.Current.Offset}-{asyncForEnd} as unreachable")
                return


def handleInstrumentedEndAsyncForA(self):
    # Instrumented variant mirrors END_ASYNC_FOR behavior.
    handleEndAsyncFor(self)


def handleInstrumentedInstructionA(self):
    # Instrumentation hook; no AST impact.
    debug_log(f"[INSTRUMENTED_INSTRUCTION] at offset {self.code.Current.Offset}")


def handleInstrumentedLineA(self):
    # Line profiling hook; skip for decompilation.
    debug_log(f"[INSTRUMENTED_LINE] at offset {self.code.Current.Offset}")


def extractGuardFromBody(nodes):
    if not nodes or len(nodes) == 0:
        return {'guard': None, 'bodyNodes': []}

    raw = []
    for n in nodes:
        nm = type(n).__name__ if n is not None else type(n).__name__
        frag = n.codeFragment() if (n is not None and hasattr(n, 'codeFragment')) else ''
        raw.append(f"{nm}:{frag}")
    debug_log(f"[MATCH] Raw case nodes: {' | '.join(str(r) for r in raw)}")

    guard = None
    working = list(nodes)
    prefix = []
    while len(working) > 0 and isinstance(working[0], ASTStore):
        prefix.append(working.pop(0))

    if (len(working) == 1
            and isinstance(working[0], ASTCondBlock)
            and working[0].blockType == ASTBlock.BlockType.If
            and not working[0].negative
            and not isinstance(getattr(working[0], 'nextSibling', None), ASTBlock)):
        guard = working[0].condition
        working = prefix + (working[0].nodes or [])
    else:
        working = list(nodes)

    return {'guard': guard, 'bodyNodes': working}


def guardFromPatternRemainder(remainderOps):
    if not remainderOps or len(remainderOps) == 0:
        return None

    compareOps = [op for op in remainderOps if op.get('type') == 'COMPARE']
    if len(compareOps) == 0:
        return None

    guardExpr = None

    for comp in compareOps:
        compareNode = ASTCompare(comp.get('left'), comp.get('right'), comp.get('op'))
        if guardExpr is not None:
            guardExpr = ASTBinary(guardExpr, compareNode, ASTBinary.BinOp.LogicalAnd)
        else:
            guardExpr = compareNode

    return guardExpr
