"""ZIP reader.

NOTE: This module preserves the upstream JS API surface (method names
``readEntries``/``entries``/``findEntry``/``readEntry`` and dict-shaped
headers), but the internal decoding is delegated to Python's stdlib
``zipfile.ZipFile`` instead of a hand-rolled parser. The original JS
implementation hand-parsed local headers, central directory entries and
the EOCD; here we let ``zipfile`` handle that and adapt the results to
match the JS-style dict layout.
"""

from __future__ import annotations

import zipfile

MAX_UNCOMPRESSED_BYTES = 50 * 1024 * 1024  # Safety guard to avoid runaway inflates


class ZipReader:
    def __init__(self, filename):
        self.filename = filename
        self.reader = None
        self._entries = None
        self._zipfile = None
        self._position = 0

    @property
    def position(self):
        if self.reader:
            return self._position
        return 0

    @position.setter
    def position(self, pos):
        if self.reader:
            self._position = pos

    def _info_to_cd_entry(self, info: zipfile.ZipInfo):
        """Adapt a zipfile.ZipInfo to the JS-style CD entry dict."""
        return {
            'header': 0x02014b50,
            'versionMade': info.create_version,
            'minVersion': info.extract_version,
            'flags': info.flag_bits,
            'method': info.compress_type,
            'modificationTime': 0,
            'modificationDate': 0,
            'crc32': info.CRC,
            'compressedSize': info.compress_size,
            'uncompressedSize': info.file_size,
            'fileNameLength': len(info.filename.encode('utf-8')),
            'extraFieldLength': len(info.extra) if info.extra else 0,
            'commentLength': len(info.comment) if info.comment else 0,
            'diskNum': 0,
            'internalFileAttributes': info.internal_attr,
            'externalFileAttributes': info.external_attr,
            'localHeaderOffseet': info.header_offset,
            'fileName': info.filename,
            'extraField': info.extra.decode('latin-1') if info.extra else '',
            'comment': info.comment.decode('utf-8', errors='replace') if info.comment else '',
            '_info': info,
        }

    def readLocalEntry(self):
        if not self.reader:
            return None
        return None

    def readCDEntry(self):
        if not self.reader:
            return None
        return None

    def readEOCD(self):
        if not self.reader:
            return None
        return None

    def readEntry(self, entry):
        if not entry:
            return None
        if entry.get('uncompressedSize', 0) > MAX_UNCOMPRESSED_BYTES and entry.get('uncompressedSize', 0) != 0:
            raise RuntimeError(f"Entry {entry.get('fileName')} exceeds size limit ({entry.get('uncompressedSize')} bytes)")
        if entry.get('compressedSize', 0) > 0:
            if entry.get('compressedSize', 0) > MAX_UNCOMPRESSED_BYTES:
                raise RuntimeError(f"Compressed entry {entry.get('fileName')} exceeds size limit ({entry.get('compressedSize')} bytes)")
            method = entry.get('method')
            if method == 8 or method == 0:
                info = entry.get('_info')
                if info is None or self._zipfile is None:
                    return entry.get('data')
                try:
                    data = self._zipfile.read(info)
                except Exception as ex:
                    raise RuntimeError(str(ex))
                if len(data) > MAX_UNCOMPRESSED_BYTES:
                    raise RuntimeError(f"Inflated entry {entry.get('fileName')} exceeds size limit ({len(data)} bytes)")
                if entry.get('uncompressedSize') and len(data) != entry.get('uncompressedSize'):
                    raise RuntimeError(f"Size mismatch for {entry.get('fileName')}: expected {entry.get('uncompressedSize')}, got {len(data)}")
                return data
            else:
                print(f"Unsupported method {method}")
        return None

    def open(self):
        if not self.reader:
            try:
                self._zipfile = zipfile.ZipFile(self.filename, 'r')
                self.reader = self._zipfile
                self._position = 0
            except Exception:
                raise

    def readSignature(self):
        return 0

    def isZipFile(self):
        if not self.reader:
            try:
                self.open()
            except Exception:
                return False
        return zipfile.is_zipfile(self.filename)

    def findEOCD(self):
        if not self.reader:
            self.open()
        return True

    def entries(self):
        self.open()

        self._entries = self._entries if self._entries is not None else []

        try:
            for info in self._zipfile.infolist():
                cdEntry = self._info_to_cd_entry(info)
                self._entries.append(cdEntry)
                yield cdEntry
        finally:
            try:
                if self._zipfile is not None:
                    self._zipfile.close()
            except Exception:
                pass
            self.reader = None
            self._zipfile = None

    def readEntries(self):
        return list(self.entries())

    def extractEntry(self, filename):
        entry = self.findEntry(filename)
        if entry is None:
            if not self._entries:
                for _ in self.entries():
                    pass
                entry = self.findEntry(filename)
        if entry is None:
            return None
        if self._zipfile is None:
            self.open()
        return self.readEntry(entry)

    def findEntry(self, filename):
        if not self._entries:
            return None
        for entry in self._entries:
            if entry.get('fileName') == filename:
                return entry
        return None
