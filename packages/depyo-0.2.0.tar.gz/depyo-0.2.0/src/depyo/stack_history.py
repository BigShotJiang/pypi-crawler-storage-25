from __future__ import annotations

import copy


def classSaver(key, value):
    if value and isinstance(value, object) and not isinstance(value, (str, int, float, bool, list, dict, tuple, type(None))):
        try:
            value.___serialized__class_name = value.__class__.__name__
        except Exception:
            pass
        return value
    return value


def restoreObjectPrototype(obj):
    if obj:
        try:
            values = obj.values() if isinstance(obj, dict) else (vars(obj).values() if hasattr(obj, '__dict__') else [])
        except Exception:
            values = []
        for subObject in values:
            if subObject and not isinstance(subObject, (str, int, float, bool, type(None))):
                restoreObjectPrototype(subObject)
                cls_name = None
                if isinstance(subObject, dict):
                    cls_name = subObject.get('___serialized__class_name')
                else:
                    cls_name = getattr(subObject, '___serialized__class_name', None)
                if cls_name:
                    cls = globals().get(cls_name)
                    if cls is not None:
                        try:
                            subObject.__class__ = cls
                        except Exception:
                            pass
                    if isinstance(subObject, dict):
                        subObject.pop('___serialized__class_name', None)
                    else:
                        try:
                            delattr(subObject, '___serialized__class_name')
                        except Exception:
                            pass
                    subObject = subObject


class StackHistory:
    def __init__(self):
        self.history = []

    def push(self, historyElement):
        self.history.append(copy.deepcopy(historyElement))

    def top(self):
        if len(self.history) == 0:
            return []
        try:
            value = copy.deepcopy(self.history[len(self.history) - 1])
            restoreObjectPrototype(value)
            return value
        except Exception:
            return []

    def pop(self):
        stack = self.top()
        self.history.pop()
        return stack

    @property
    def length(self):
        return len(self.history)

    @length.setter
    def length(self, value):
        if value < len(self.history):
            del self.history[value:]
        else:
            while len(self.history) < value:
                self.history.append(None)

    def empty(self):
        return len(self.history) == 0
