#!/usr/bin/env python3
"""depyo CLI entry point.

Mechanical port of depyo.js. Preserves flag names, error messages, and exit
codes. Argument parsing uses argparse (idiomatic Python) instead of the JS
hand-rolled argv walker.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import traceback
import zlib
from pathlib import Path
from typing import Any, Optional

from depyo.pyc_reader import PycReader
from depyo.pyc_decompiler import PycDecompiler
from depyo.pyc_disassembler import PycDisassembler
from depyo.zip_reader import ZipReader


# ---------------------------------------------------------------------------
# Global state (mirrors depyo.js g_cliArgs + counters).
# ---------------------------------------------------------------------------

class CLIArgs:
    def __init__(self) -> None:
        self.debug: bool = False
        self.raw: bool = False
        self.rawSpacing: bool = False
        self.dump: bool = False
        self.asm: bool = False
        self.stats: bool = False
        self.skipSource: bool = False
        self.skipPath: bool = False
        self.sendToStdout: bool = False
        self.marshal: bool = False
        self.marshalScan: bool = False
        self.strict: bool = False
        self.pyVersion: Optional[str] = None
        self.silent: bool = False
        self.fileExt: str = "py"
        self.baseDir: Optional[str] = None
        self.filenames: list[str] = []


g_cliArgs = CLIArgs()
g_baseDir: str = "./decompiled/"
g_dirtyFiles: list[dict] = []
g_totalInThroughput: int = 0
g_totalOutThroughput: int = 0
g_totalExecTime: float = 0.0
g_totalFiles: int = 0
g_pyVersionInfo: Any = None
g_marshalScanStats: dict = {"ok": 0, "ambiguous": 0, "failed": 0}


USAGE_EPILOG = """\
Options:
  --asm               Emit .pyasm disassembly alongside source
  --debug             Verbose logging during decompilation
  --raw               Save raw .pyc next to output
  --raw-spacing       Preserve blank lines (show potential comment gaps)
  --dump              Dump marshalled object tree (.dump)
  --stats             Print throughput stats
  --skip-source-gen   Do not emit .py source (useful with --asm/--dump)
  --skip-path         Flatten output paths (write files next to inputs)
  --out               Print decompiled source to stdout instead of files
  --marshal           Treat input as raw marshalled data (no .pyc header)
  --marshal-scan      Fast scan of marshal blobs (no decompile, prints version)
  --strict            Re-throw on first opcode handler exception (default: log + continue + non-zero exit)
  --py-version <x.y>  Python bytecode version hint (auto-scan if omitted)
  --basedir <path>    Output base directory (default: alongside input)
  --file-ext <ext>    Extension for generated source (default: py)
"""


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="depyo",
        usage="depyo [options] <file.pyc|archive.zip> [...]",
        description="Python .pyc decompiler.",
        epilog=USAGE_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        add_help=True,
    )
    parser.add_argument("--asm", action="store_true", dest="asm")
    parser.add_argument("--debug", action="store_true", dest="debug")
    parser.add_argument("--raw", action="store_true", dest="raw")
    parser.add_argument("--raw-spacing", action="store_true", dest="rawSpacing")
    parser.add_argument("--dump", action="store_true", dest="dump")
    parser.add_argument("--stats", action="store_true", dest="stats")
    parser.add_argument("--skip-source-gen", action="store_true", dest="skipSource")
    parser.add_argument("--skip-path", action="store_true", dest="skipPath")
    parser.add_argument("--out", action="store_true", dest="sendToStdout")
    parser.add_argument("--marshal", action="store_true", dest="marshal")
    # --marshal-scan has an alias --marshal-smoke (handled below).
    parser.add_argument(
        "--marshal-scan",
        "--marshal-smoke",
        action="store_true",
        dest="marshalScan",
    )
    parser.add_argument("--strict", action="store_true", dest="strict")
    parser.add_argument("--py-version", dest="pyVersion", metavar="X.Y", default=None)
    parser.add_argument("--basedir", dest="baseDir", metavar="PATH", default=None)
    parser.add_argument("--file-ext", dest="fileExt", metavar="EXT", default="py")
    parser.add_argument("filenames", nargs="*", help="Input .pyc files or .zip archives")
    return parser


def parseCLIParams(argv: Optional[list[str]] = None) -> None:
    """Populate global g_cliArgs from argv (argv excludes program name)."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    g_cliArgs.asm = args.asm
    g_cliArgs.debug = args.debug
    g_cliArgs.raw = args.raw
    g_cliArgs.rawSpacing = args.rawSpacing
    g_cliArgs.dump = args.dump
    g_cliArgs.stats = args.stats
    g_cliArgs.skipSource = args.skipSource
    g_cliArgs.skipPath = args.skipPath
    g_cliArgs.sendToStdout = args.sendToStdout
    g_cliArgs.marshal = args.marshal
    g_cliArgs.marshalScan = args.marshalScan
    if args.marshalScan:
        # --marshal-scan implies --marshal (matches JS behavior).
        g_cliArgs.marshal = True
    g_cliArgs.strict = args.strict
    g_cliArgs.pyVersion = args.pyVersion
    g_cliArgs.baseDir = args.baseDir
    g_cliArgs.fileExt = args.fileExt
    g_cliArgs.filenames = [f for f in (args.filenames or []) if f and f.strip()]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _hrtime_ns() -> int:
    return time.perf_counter_ns()


def normalizeMarshalOutput(src: str) -> str:
    import re

    src = src.replace("\r\n", "\n")
    src = re.sub(r"[ \t]+$", "", src, flags=re.MULTILINE)
    src = re.sub(r"\n{3,}", "\n\n", src)
    src = re.sub(r"#[^\n]*$", "", src, flags=re.MULTILINE)
    return src.strip()


def scanMarshalBuffer(buffer: bytes, filenameLabel: str) -> None:
    global g_marshalScanStats
    if g_pyVersionInfo:
        trial = PycReader.TryParseMarshal(buffer, g_pyVersionInfo)
        if not trial:
            g_marshalScanStats["failed"] += 1
            print(f"{filenameLabel}: no parse with {g_pyVersionInfo.major}.{g_pyVersionInfo.minor}")
            return
        g_marshalScanStats["ok"] += 1
        print(
            f"{filenameLabel}: forced {g_pyVersionInfo.major}.{g_pyVersionInfo.minor} "
            f"unknown={trial.unknown}/{trial.total} remaining={trial.remaining}"
        )
        return

    results = PycReader.ScanMarshalCandidates(buffer)
    if not results:
        g_marshalScanStats["failed"] += 1
        print(f"{filenameLabel}: no candidates")
        return

    best = results[0]
    ambiguous = [
        r for r in results
        if r.unknown == best.unknown
        and r.remaining == best.remaining
        and r.unknownRatio == best.unknownRatio
    ]

    if len(ambiguous) > 1:
        g_marshalScanStats["ambiguous"] += 1
        versions = ", ".join(f"{r.versionInfo.major}.{r.versionInfo.minor}" for r in ambiguous)
        print(f"{filenameLabel}: ambiguous candidates ({versions})")
        return

    g_marshalScanStats["ok"] += 1
    print(
        f"{filenameLabel}: best={best.versionInfo.major}.{best.versionInfo.minor} "
        f"unknown={best.unknown}/{best.total} remaining={best.remaining}"
    )


def attemptMarshalDecompile(buffer: bytes, versionInfo: Any, opts: Optional[dict] = None):
    opts = opts or {}
    prevSilent = g_cliArgs.silent
    prevDebug = g_cliArgs.debug
    if opts.get("silent"):
        g_cliArgs.silent = True
        g_cliArgs.debug = False
    try:
        rdr = PycReader(buffer, {"marshal": True, "versionInfo": versionInfo})
        obj = rdr.ReadObject()
        if not obj or getattr(obj, "ClassName", None) != "Py_CodeObject":
            return None
        opcodes = versionInfo.opcode(obj)
        counts = PycReader.CountUnknownOpcodes(obj, rdr, opcodes.OpCodeList)
        unknown = counts["unknown"] if isinstance(counts, dict) else counts.unknown
        total = counts["total"] if isinstance(counts, dict) else counts.total
        unknownRatio = unknown / total if total > 0 else 1
        remaining = len(rdr.m_rdr.Reader) - rdr.m_rdr.pc

        genStartTS = _hrtime_ns()
        decompiler = PycDecompiler(obj)
        ast = decompiler.decompile()
        pycResult = ast.codeFragment()
        pySrc = str(pycResult)
        genSecs = (_hrtime_ns() - genStartTS) / 1_000_000_000

        return {
            "reader": rdr,
            "obj": obj,
            "pySrc": pySrc,
            "genSecs": genSecs,
            "cleanBuild": decompiler.cleanBuild,
            "unknown": unknown,
            "total": total,
            "unknownRatio": unknownRatio,
            "remaining": remaining,
            "versionInfo": versionInfo,
        }
    except Exception as ex:
        if opts.get("debug"):
            print(f"Marshal decompile failed for {versionInfo.major}.{versionInfo.minor}: {ex}")
        return None
    finally:
        g_cliArgs.silent = prevSilent
        g_cliArgs.debug = prevDebug


def selectMarshalCandidate(buffer: bytes):
    candidates = PycReader.ListSupportedVersions(False)
    attempts = []
    cleanCandidates = []
    baselineOutput = None
    outputsDiverged = False
    for candidate in candidates:
        result = attemptMarshalDecompile(buffer, candidate, {"silent": True})
        if not result:
            continue
        attempts.append(result)
        isWorking = result["cleanBuild"] and result["unknown"] == 0 and result["remaining"] == 0
        if isWorking:
            normalized = normalizeMarshalOutput(result.get("pySrc") or "")
            clean = dict(result)
            clean["normalized"] = normalized
            cleanCandidates.append(clean)
            if baselineOutput is None:
                baselineOutput = normalized
            elif baselineOutput != normalized:
                outputsDiverged = True

    if not cleanCandidates:
        if attempts:
            return {"best": None, "attempts": attempts, "ambiguous": False}
        return None

    if outputsDiverged:
        return {
            "best": None,
            "attempts": attempts,
            "ambiguous": True,
            "cleanCandidates": cleanCandidates,
        }

    return {"best": cleanCandidates[0], "attempts": attempts, "ambiguous": False}


def _is_bytes_like(x: Any) -> bool:
    return isinstance(x, (bytes, bytearray, memoryview))


def decompilePycObject(data: Any) -> None:
    global g_baseDir
    global g_totalInThroughput, g_totalOutThroughput, g_totalExecTime, g_totalFiles
    try:
        filename: Optional[str] = None
        obj: Any = None
        startTS = _hrtime_ns()
        buffer = data
        if not _is_bytes_like(buffer):
            buffer = Path(data).read_bytes()

        if g_cliArgs.marshalScan:
            label = data if isinstance(data, str) else "<buffer>"
            scanMarshalBuffer(buffer, label)
            return

        rdr = None
        pySrc: Optional[str] = None
        genSecs: float = 0.0

        if g_cliArgs.marshal:
            attemptResult = None
            if g_pyVersionInfo:
                attemptResult = attemptMarshalDecompile(buffer, g_pyVersionInfo)
            else:
                scan = selectMarshalCandidate(buffer)
                attemptResult = scan["best"] if scan else None
                if g_cliArgs.debug and scan and scan.get("attempts"):
                    print("Marshal scan results:")
                    for attempt in scan["attempts"]:
                        info = attempt["versionInfo"]
                        print(
                            f"  {info.major}.{info.minor}: "
                            f"clean={attempt['cleanBuild']} "
                            f"unknown={attempt['unknown']}/{attempt['total']} "
                            f"remaining={attempt['remaining']}"
                        )
                    if attemptResult:
                        info = attemptResult["versionInfo"]
                        print(f"Selected marshal version: {info.major}.{info.minor}")
                if not attemptResult and scan and scan.get("ambiguous"):
                    if scan.get("cleanCandidates"):
                        versions = ", ".join(
                            f"{c['versionInfo'].major}.{c['versionInfo'].minor}"
                            for c in scan["cleanCandidates"]
                        )
                    else:
                        versions = "unknown"
                    raise RuntimeError(
                        f"Ambiguous marshal version ({versions}). Provide --py-version X.Y to force."
                    )

            if not attemptResult:
                raise RuntimeError(
                    "No clean marshal candidate found. Provide --py-version X.Y to force."
                )
            rdr = attemptResult["reader"]
            obj = attemptResult["obj"]
            pySrc = attemptResult["pySrc"]
            genSecs = attemptResult["genSecs"]
        else:
            rdr = PycReader(buffer)
            try:
                obj = rdr.ReadObject()
            except Exception as ex:
                if isinstance(ex, PycReader.LoadError):
                    if not getattr(ex, "FileName", None):
                        if g_cliArgs.debug:
                            print(f"LoadError: {ex} at position {getattr(ex, 'position', '?')}")
                        return
                    filename = g_baseDir + ex.FileName
                    dirPath = os.path.dirname(filename)
                    if not g_cliArgs.skipPath and not os.path.exists(dirPath):
                        os.makedirs(dirPath, exist_ok=True)
                    dot = filename.rfind(".")
                    filenamePyc = (filename[:dot] if dot >= 0 else filename) + ".pyc"
                    with open(filenamePyc, "wb") as f:
                        f.write(rdr.Reader)
                    print(
                        f"Error: {ex}\nFile: {filenamePyc}\nPosition: {getattr(ex, 'position', '?')}"
                    )
                    return
                print(f"Error: {ex}\nStack:\n{traceback.format_exc()}")
                return

        if not obj:
            return
        filename = g_baseDir + obj.FileName

        if not g_cliArgs.sendToStdout:
            print(f"Processing {filename}...")

        dirPath = os.path.dirname(filename)
        dot = filename.rfind(".")
        filenameBase = filename[:dot] if dot >= 0 else filename
        if g_cliArgs.skipPath:
            filenameBase = "./" + filenameBase[len(dirPath) + 1:]

        if not g_cliArgs.sendToStdout:
            if not g_cliArgs.skipPath and not os.path.exists(dirPath):
                os.makedirs(dirPath, exist_ok=True)
            if g_cliArgs.raw:
                with open(filenameBase + ".pyc", "wb") as f:
                    f.write(rdr.Reader)
            if g_cliArgs.dump:
                dumped = PycReader.DumpObject(obj)
                mode = "wb" if isinstance(dumped, (bytes, bytearray)) else "w"
                with open(filenameBase + ".dump", mode) as f:
                    f.write(dumped)
            if g_cliArgs.asm:
                asm_src = PycDisassembler.Disassemble(rdr, obj)
                mode = "wb" if isinstance(asm_src, (bytes, bytearray)) else "w"
                with open(filenameBase + ".pyasm", mode) as f:
                    f.write(asm_src)

        if not pySrc:
            genStartTS = _hrtime_ns()
            decompiler = PycDecompiler(obj)
            ast = decompiler.decompile()
            try:
                pycResult = ast.codeFragment()
                pySrc = str(pycResult)
            except Exception as ex:
                if g_cliArgs.strict:
                    raise
                name = getattr(obj, "Name", None)
                name_str = str(name) if name is not None else "<root>"
                decompiler.errors.append({
                    "opcode": "RENDER",
                    "codeObject": name_str,
                    "message": str(ex),
                    "stack": traceback.format_exc(),
                })
                decompiler.cleanBuild = False
                pySrc = f"# DECOMPILER ERROR: codeFragment() threw: {ex}\n"
                if not g_cliArgs.silent:
                    print(f"RENDER EXCEPTION in '{name}': {ex}", file=sys.stderr)
                    if g_cliArgs.debug:
                        print(traceback.format_exc(), file=sys.stderr)
            genSecs = (_hrtime_ns() - genStartTS) / 1_000_000_000
            if not decompiler.cleanBuild:
                if isinstance(data, str):
                    file_label = data
                else:
                    file_label = getattr(obj, "FileName", None) or "<buffer>"
                g_dirtyFiles.append({
                    "file": file_label,
                    "errors": len(decompiler.errors),
                })

        if not pySrc.endswith("\n"):
            pySrc += "\n"
        genSecs = max(genSecs, 0.000000001)

        if g_cliArgs.sendToStdout:
            sys.stdout.write(pySrc)
        else:
            with open(filenameBase + "." + g_cliArgs.fileExt, "w") as f:
                f.write(pySrc)

        secs = (_hrtime_ns() - startTS) / 1_000_000_000
        g_totalExecTime += secs
        inThroughput = len(buffer) / genSecs
        outThroughput = len(pySrc) / genSecs
        g_totalInThroughput += len(buffer)
        g_totalOutThroughput += len(pySrc)
        g_totalFiles += 1
        if g_cliArgs.stats:
            data_len = len(data) if hasattr(data, "__len__") else len(buffer)
            print(
                f"Done in {genSecs:.3f}s. In: {data_len} bytes ({inThroughput:.2f} B/s). "
                f"Out: {len(pySrc)} bytes ({outThroughput:.2f} B/s)."
            )
    except Exception as ex:
        print(f"EXCEPTION: {ex}")
        if g_cliArgs.debug:
            print(traceback.format_exc())


def DecompileModule(filenames: list[str]) -> None:
    for filename in filenames:
        try:
            zipReader = ZipReader(filename)
            if zipReader.isZipFile():
                for entry in zipReader.entries():
                    uncompressedData = zlib.decompress(entry.data, -zlib.MAX_WBITS)
                    decompilePycObject(uncompressedData)
            else:
                decompilePycObject(filename)
        except Exception as ex:
            print(f"Processing of file {filename} was unsuccessful due to: {ex}")


def main() -> None:
    global g_baseDir, g_pyVersionInfo

    parseCLIParams()

    if g_cliArgs.pyVersion and not g_cliArgs.marshal:
        print("Error: --py-version requires --marshal (headerless input).")
        sys.exit(1)

    if g_cliArgs.pyVersion:
        g_pyVersionInfo = PycReader.ResolveVersionTag(g_cliArgs.pyVersion)
        if not g_pyVersionInfo:
            print(
                f'Error: unsupported --py-version "{g_cliArgs.pyVersion}". '
                f"Use format X.Y (e.g., 3.11)."
            )
            sys.exit(1)

    if len(g_cliArgs.filenames) == 0:
        _build_parser().print_help()
        sys.exit(1)

    baseInputDir = g_cliArgs.baseDir if g_cliArgs.baseDir else os.path.dirname(
        g_cliArgs.filenames[0] or "."
    )
    g_baseDir = os.path.abspath(os.path.join(baseInputDir, "decompiled")) + "/"

    DecompileModule(g_cliArgs.filenames)

    if g_cliArgs.marshalScan:
        print(
            f"Marshal scan summary: ok={g_marshalScanStats['ok']}, "
            f"ambiguous={g_marshalScanStats['ambiguous']}, "
            f"failed={g_marshalScanStats['failed']}"
        )
        if g_marshalScanStats["failed"] > 0:
            sys.exit(1)
        if g_marshalScanStats["ambiguous"] > 0:
            sys.exit(2)
        sys.exit(0)

    if not g_cliArgs.sendToStdout:
        if g_totalExecTime > 0:
            inRate = g_totalInThroughput / g_totalExecTime
            outRate = g_totalOutThroughput / g_totalExecTime
        else:
            inRate = 0.0
            outRate = 0.0
        print(
            f"Processed {g_totalFiles} files in {g_totalExecTime:.3f}s. "
            f"In: {g_totalInThroughput} bytes ({inRate:.2f} B/s). "
            f"Out: {g_totalOutThroughput} bytes ({outRate:.2f} B/s)."
        )

    if len(g_dirtyFiles) > 0:
        print(
            f"\nDirty decompile: {len(g_dirtyFiles)} file(s) had handler exceptions "
            f"(output may be partial):",
            file=sys.stderr,
        )
        for d in g_dirtyFiles[:20]:
            plural = "" if d["errors"] == 1 else "s"
            print(f"  - {d['file']}  ({d['errors']} opcode error{plural})", file=sys.stderr)
        if len(g_dirtyFiles) > 20:
            print(f"  ... and {len(g_dirtyFiles) - 20} more", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
