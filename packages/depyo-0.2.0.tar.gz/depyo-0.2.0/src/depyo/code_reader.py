from __future__ import annotations

import struct


class CodeReaderError(Exception):
    def __init__(self, message, pc, length):
        super().__init__(f"{message} (pc={pc}, length={length})")
        self.name = 'CodeReaderError'
        self.pc = pc
        self.length = length


class CodeReader:
    def __init__(self, code, endian=None):
        self.endian = endian or 'B'
        self._reader = bytes(code)
        self._pc = 0

    @property
    def pc(self):
        return self._pc

    @pc.setter
    def pc(self, pos):
        if pos > self.length or pos < 0:
            pos = self.length
        self._pc = pos

    @property
    def length(self):
        return len(self._reader)

    @property
    def EOF(self):
        return self._pc >= len(self._reader)

    def _read(self, label, size, fn):
        if self._pc + size > len(self._reader):
            raise CodeReaderError(f"{label}: read past end of buffer", self._pc, len(self._reader))
        try:
            value = fn()
            self._pc += size
            return value
        except Exception as ex:
            if isinstance(ex, CodeReaderError):
                raise
            raise CodeReaderError(f"{label}: {str(ex)}", self._pc, len(self._reader))

    def readByte(self):
        return self._read('readByte', 1, lambda: self._reader[self._pc])

    def readUShort(self):
        fmt = '<H' if self.endian == 'L' else '>H'
        return self._read('readUShort', 2, lambda: struct.unpack_from(fmt, self._reader, self._pc)[0])

    def readShort(self):
        fmt = '<h' if self.endian == 'L' else '>h'
        return self._read('readShort', 2, lambda: struct.unpack_from(fmt, self._reader, self._pc)[0])

    def readInt(self):
        fmt = '<i' if self.endian == 'L' else '>i'
        return self._read('readInt', 4, lambda: struct.unpack_from(fmt, self._reader, self._pc)[0])

    def readUInt(self):
        fmt = '<I' if self.endian == 'L' else '>I'
        return self._read('readUInt', 4, lambda: struct.unpack_from(fmt, self._reader, self._pc)[0])

    def readLong(self):
        high = self.readInt()
        low = self.readInt()
        return {'low': low, 'high': high}

    def readULong(self):
        high = self.readUInt()
        low = self.readUInt()
        return {'low': low, 'high': high}

    def readFloat(self):
        fmt = '<f' if self.endian == 'L' else '>f'
        return self._read('readFloat', 4, lambda: struct.unpack_from(fmt, self._reader, self._pc)[0])

    def readDouble(self):
        fmt = '<d' if self.endian == 'L' else '>d'
        return self._read('readDouble', 8, lambda: struct.unpack_from(fmt, self._reader, self._pc)[0])

    def readBytes(self, length):
        return self._read(f"readBytes({length})", length, lambda: self._reader[self._pc:self._pc + length])

    def readString(self, length):
        return self._read(f"readString({length})", length, lambda: self._reader[self._pc:self._pc + length].decode('utf-8'))

    def peekByte(self):
        if self._pc >= len(self._reader):
            raise CodeReaderError('peekByte: read past end of buffer', self._pc, len(self._reader))
        return self._reader[self._pc]
