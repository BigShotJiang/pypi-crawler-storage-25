"""PycReader — parses .pyc files (magic, timestamp, marshal blob)."""

from __future__ import annotations

import os
import re
import sys

from depyo.binary_reader import BinaryReader
from depyo.python_object import PythonObject, PythonCodeObject


PyLong_MARSHAL_SHIFT = 15
PyLong_MARSHAL_RATIO = 30 / PyLong_MARSHAL_SHIFT
PyLong_MARSHAL_BASE = 0x8000
PyLong_MARSHAL_MASK = 0x7FFF

TypeNull = '0'
TypeNone = 'N'
TypeFalse = 'F'
TypeTrue = 'T'
TypeStopiter = 'S'
TypeEllipsis = '.'
TypeInt = 'i'
TypeInt64 = 'I'
TypeFloat = 'f'
TypeBinaryFloat = 'g'
TypeComplex = 'x'
TypeBinaryComplex = 'y'
TypeLong = 'l'
TypeString = 's'
TypeInterned = 't'
TypeStringRef = 'R'
TypeTuple = '('
TypeList = '['
TypeDict = '{'
TypeCode = 'c'
TypeCode2 = 'C'
TypeUnicode = 'u'
TypeUnknown = '?'
TypeSet = '<'
TypeFrozenset = '>'
TypeAscii = 'a'
TypeAsciiInterned = 'A'
TypeSmallTuple = ')'
TypeShortAscii = 'z'
TypeShortAsciiInterned = 'Z'
TypeObjectReference = 'r'

KnownTypes = set([
    TypeNull, TypeNone, TypeFalse, TypeTrue, TypeStopiter, TypeEllipsis,
    TypeInt, TypeInt64, TypeFloat, TypeBinaryFloat, TypeComplex, TypeBinaryComplex,
    TypeLong, TypeString, TypeInterned, TypeStringRef, TypeTuple, TypeList,
    TypeDict, TypeCode, TypeCode2, TypeUnicode, TypeUnknown, TypeSet, TypeFrozenset,
    TypeAscii, TypeAsciiInterned, TypeSmallTuple, TypeShortAscii, TypeShortAsciiInterned,
    TypeObjectReference,
])


def _lazy_opcode(module_name):
    """Lazy-import an opcode module and wrap its OPCODES dict into an OpCodes-subclass factory."""
    def _loader():
        try:
            mod = __import__(f"depyo.bytecode.{module_name}", fromlist=["*"])
        except ImportError:
            return None
        return _build_opcode_class(module_name, mod)
    return _loader


def _build_opcode_class(module_name, mod):
    """Build a dynamic OpCodes subclass from a bytecode module's OPCODES dict.

    Each entry of mod.OPCODES is {"id": "<OpCodes attr>", "name": "<display>", "flags": {flag: True}}.
    The returned class, when instantiated with a PythonCodeObject, populates OpCodeList and runs SetupByteCode."""
    from .opcodes import OpCodes as _OpCodesBase
    from .opcode import OpCode as _OpCode

    opcodes_dict = getattr(mod, "OPCODES", None) or {}
    built_entries = []
    for idx, meta in opcodes_dict.items():
        op_id = getattr(_OpCodesBase, meta["id"], 0)
        flags = meta.get("flags") or {}
        built_entries.append((idx, _OpCode(op_id, meta["name"], flags)))

    class _DynamicOpCodes(_OpCodesBase):
        def __init__(self, co):
            super().__init__()
            # Sparse list indexed by opcode byte; extend to max idx.
            if built_entries:
                max_idx = max(idx for idx, _ in built_entries)
                self.OpCodeList = [None] * (max_idx + 1)
                for idx, opcode in built_entries:
                    self.OpCodeList[idx] = opcode.Clone()
            self.SetupByteCode(co)

    _DynamicOpCodes.__name__ = f"OpCodes_{module_name}"
    return _DynamicOpCodes


MagicToVersion = {
    0x00999902: {"major": 1, "minor": 0, "IsUnicode": False, "opcode": _lazy_opcode("python_1_0")},
    0x00999903: {"major": 1, "minor": 1, "IsUnicode": False, "opcode": _lazy_opcode("python_1_1")},  # Also covers 1.2
    0x0A0D2E89: {"major": 1, "minor": 3, "IsUnicode": False, "opcode": _lazy_opcode("python_1_3")},
    0x0A0D1704: {"major": 1, "minor": 4, "IsUnicode": False, "opcode": _lazy_opcode("python_1_4")},
    0x0A0D4E99: {"major": 1, "minor": 5, "IsUnicode": False, "opcode": _lazy_opcode("python_1_5")},

    0x0A0DC4FC: {"major": 1, "minor": 6, "IsUnicode": False, "opcode": _lazy_opcode("python_1_6")},
    0x0A0DC4FD: {"major": 1, "minor": 6, "IsUnicode": True, "opcode": _lazy_opcode("python_1_6")},


    0x0A0DC687: {"major": 2, "minor": 0, "IsUnicode": False, "opcode": _lazy_opcode("python_2_0")},
    0x0A0DC688: {"major": 2, "minor": 0, "IsUnicode": True, "opcode": _lazy_opcode("python_2_0")},

    0x0A0DEB2A: {"major": 2, "minor": 1, "IsUnicode": False, "opcode": _lazy_opcode("python_2_1")},
    0x0A0DEB2B: {"major": 2, "minor": 1, "IsUnicode": True, "opcode": _lazy_opcode("python_2_1")},

    0x0A0DED2D: {"major": 2, "minor": 2, "IsUnicode": False, "opcode": _lazy_opcode("python_2_2")},
    0x0A0DED2E: {"major": 2, "minor": 2, "IsUnicode": True, "opcode": _lazy_opcode("python_2_2")},

    0x0A0DF23B: {"major": 2, "minor": 3, "IsUnicode": False, "opcode": _lazy_opcode("python_2_3")},
    0x0A0DF23C: {"major": 2, "minor": 3, "IsUnicode": True, "opcode": _lazy_opcode("python_2_3")},

    0x0A0DF26D: {"major": 2, "minor": 4, "IsUnicode": False, "opcode": _lazy_opcode("python_2_4")},
    0x0A0DF26E: {"major": 2, "minor": 4, "IsUnicode": True, "opcode": _lazy_opcode("python_2_4")},

    0x0A0DF2B3: {"major": 2, "minor": 5, "IsUnicode": False, "opcode": _lazy_opcode("python_2_5")},
    0x0A0DF2B4: {"major": 2, "minor": 5, "IsUnicode": True, "opcode": _lazy_opcode("python_2_5")},

    0x0A0DF2D1: {"major": 2, "minor": 6, "IsUnicode": False, "opcode": _lazy_opcode("python_2_6")},
    0x0A0DF2D2: {"major": 2, "minor": 6, "IsUnicode": True, "opcode": _lazy_opcode("python_2_6")},

    0x0A0DF303: {"major": 2, "minor": 7, "IsUnicode": False, "opcode": _lazy_opcode("python_2_7")},
    0x0A0DF304: {"major": 2, "minor": 7, "IsUnicode": True, "opcode": _lazy_opcode("python_2_7")},


    0x0A0D0C3A: {"major": 3, "minor": 0, "IsUnicode": True, "opcode": _lazy_opcode("python_3_0")},
    0x0A0D0C4E: {"major": 3, "minor": 1, "IsUnicode": True, "opcode": _lazy_opcode("python_3_1")},
    0x0A0D0C6C: {"major": 3, "minor": 2, "IsUnicode": True, "opcode": _lazy_opcode("python_3_2")},
    0x0A0D0C9E: {"major": 3, "minor": 3, "IsUnicode": True, "opcode": _lazy_opcode("python_3_3")},
    0x0A0D0CEE: {"major": 3, "minor": 4, "IsUnicode": True, "opcode": _lazy_opcode("python_3_4")},
    0x0A0D0D16: {"major": 3, "minor": 5, "IsUnicode": True, "opcode": _lazy_opcode("python_3_5")},
    0x0A0D0D17: {"major": 3, "minor": 5, "revision": 3, "IsUnicode": True, "opcode": _lazy_opcode("python_3_5")},
    0x0A0D0D33: {"major": 3, "minor": 6, "IsUnicode": True, "opcode": _lazy_opcode("python_3_6")},
    0x0A0D0D41: {"major": 3, "minor": 7, "IsUnicode": True, "opcode": _lazy_opcode("python_3_7")},
    0x0A0D0D42: {"major": 3, "minor": 7, "IsUnicode": True, "opcode": _lazy_opcode("python_3_7")},
    # Python 3.8a1 (3400) and 3.8a2 (3401) predate PEP 570 — no posonly field in marshal.
    0x0A0D0D48: {"major": 3, "minor": 8, "preReleaseMarshal": True, "IsUnicode": True, "opcode": _lazy_opcode("python_3_8")},
    0x0A0D0D49: {"major": 3, "minor": 8, "preReleaseMarshal": True, "IsUnicode": True, "opcode": _lazy_opcode("python_3_8")},
    # 3.8a3 (3410) and later include posonly.
    0x0A0D0D52: {"major": 3, "minor": 8, "IsUnicode": True, "opcode": _lazy_opcode("python_3_8")},
    0x0A0D0D53: {"major": 3, "minor": 8, "IsUnicode": True, "opcode": _lazy_opcode("python_3_8")},
    0x0A0D0D54: {"major": 3, "minor": 8, "IsUnicode": True, "opcode": _lazy_opcode("python_3_8")},
    0x0A0D0D55: {"major": 3, "minor": 8, "IsUnicode": True, "opcode": _lazy_opcode("python_3_8")},
    0x0A0D0D61: {"major": 3, "minor": 9, "IsUnicode": True, "opcode": _lazy_opcode("python_3_9")},
    0x0A0D0D6F: {"major": 3, "minor": 10, "IsUnicode": True, "opcode": _lazy_opcode("python_3_10")},
    0x0A0D0DA7: {"major": 3, "minor": 11, "IsUnicode": True, "opcode": _lazy_opcode("python_3_11")},
    0x0A0D0DCB: {"major": 3, "minor": 12, "IsUnicode": True, "opcode": _lazy_opcode("python_3_12")},
    0x0A0D0DF3: {"major": 3, "minor": 13, "IsUnicode": True, "opcode": _lazy_opcode("python_3_13")},
    0x0A0D0E2B: {"major": 3, "minor": 14, "IsUnicode": True, "opcode": _lazy_opcode("python_3_14")},
    0x0A0D0E4F: {"major": 3, "minor": 15, "IsUnicode": True, "opcode": _lazy_opcode("python_3_15")},

    # PyPy magics (shares opcode tables with matching CPython release).
    # PyPy adds a handful of custom opcodes — unknowns degrade decode rather than fail.
    0x0A0DF30A: {"major": 2, "minor": 7, "IsUnicode": True, "opcode": _lazy_opcode("python_2_7"), "pypy": True},
    0x0A0D0030: {"major": 3, "minor": 2, "IsUnicode": True, "opcode": _lazy_opcode("python_3_2"), "pypy": True},
    0x0A0D0070: {"major": 3, "minor": 5, "IsUnicode": True, "opcode": _lazy_opcode("python_3_5"), "pypy": True},
    0x0A0D00A0: {"major": 3, "minor": 6, "IsUnicode": True, "opcode": _lazy_opcode("python_3_6"), "pypy": True},
    0x0A0D00F0: {"major": 3, "minor": 7, "IsUnicode": True, "opcode": _lazy_opcode("python_3_7"), "pypy": True},
}

VersionAliases = {
    "1.2": "1.1",
}

VersionToInfo = {}
for _magic, _info in MagicToVersion.items():
    if _info.get("pypy"):
        continue
    _key = f"{_info['major']}.{_info['minor']}"
    _existing = VersionToInfo.get(_key)
    _candidate = {**_info, "magic": int(_magic)}
    if not _existing or (_candidate.get("revision") or 0) > (_existing.get("revision") or 0):
        VersionToInfo[_key] = _candidate


def parseVersionTag(tag):
    if not tag:
        return None
    cleaned = re.sub(r"^python", "", str(tag).strip(), flags=re.IGNORECASE)
    cleaned = re.sub(r"^py", "", cleaned, flags=re.IGNORECASE)
    match = re.match(r"^(\d+)(?:\.(\d+))?(?:\.(\d+))?$", cleaned)
    if not match or match.group(2) is None:
        return None
    try:
        major = int(match.group(1))
        minor = int(match.group(2))
    except (TypeError, ValueError):
        return None
    return {"major": major, "minor": minor}


# Lightweight stand-in for Node's `global.g_cliArgs` — kept so the JS
# `global.g_cliArgs?.debug` checks translate mechanically.
class _GCliArgs:
    debug = False


g_cliArgs = _GCliArgs()


class PycReader:
    class LoadError(Exception):
        FileName = None
        position = -1

        def __init__(self, msg, filename=None, pc=-1):
            super().__init__(msg)
            self.FileName = filename
            self.position = pc

    Strings = []
    Objects = []
    m_rdr = None
    m_filename = None
    m_version = None

    def __init__(self, data=None, options=None):
        self.Strings = []
        self.Objects = []
        self.m_rdr = None
        self.m_filename = None
        self.m_version = None

        if not data:
            return

        opts = options or {}
        self.m_filename = opts.get("filename") or None

        buffer = data
        if isinstance(data, str):
            with open(data, "rb") as fh:
                buffer = fh.read()
        elif not isinstance(buffer, (bytes, bytearray, memoryview)):
            raise RuntimeError("PycReader accepts only String as a file path or Buffer as content.")
        self.m_rdr = BinaryReader(buffer)

        if opts.get("marshal"):
            versionInfo = opts.get("versionInfo")
            if not versionInfo and opts.get("pyVersion"):
                versionInfo = PycReader.ResolveVersionTag(opts.get("pyVersion"))
            if not versionInfo:
                raise RuntimeError("Marshal mode requires a bytecode version. Pass --py-version or pre-resolve it.")
            self.m_version = versionInfo
            if getattr(g_cliArgs, "debug", False) and not opts.get("silent"):
                print(f"Marshal mode: Python {self.m_version['major']}.{self.m_version['minor']}")
            return

        marshalVersion = self.m_rdr.readUInt32()
        self.m_version = (
            MagicToVersion.get(marshalVersion)
            or MagicToVersion.get(marshalVersion & 0xFFFFFFFE)
            or {"major": -1, "minor": -1, "IsUnicode": False}
        )

        # Fallback: pick nearest known magic if opcode table is missing (helps PyPy forks)
        if not self._opcode_of(self.m_version):
            nearest = None
            bestDiff = sys.maxsize
            for magic, info in MagicToVersion.items():
                diff = abs(int(magic) - marshalVersion)
                if diff < bestDiff:
                    bestDiff = diff
                    nearest = info
            if nearest and bestDiff <= 0x1000:
                self.m_version = nearest
                if getattr(g_cliArgs, "debug", False):
                    print(
                        f"Using nearest magic match (diff=0x{format(bestDiff, 'x')}) -> Python {nearest['major']}.{nearest['minor']}",
                        file=sys.stderr,
                    )

        flags = 0
        timeStamp = 0
        size = 0

        if self.versionCompare(3, 7) >= 0:
            flags = self.m_rdr.readUInt32()

        if flags & 1:
            self.m_rdr.readUInt32()
            self.m_rdr.readUInt32()
        else:
            timeStamp = self.m_rdr.readUInt32()

            if self.versionCompare(3, 3) >= 0:
                size = self.m_rdr.readUInt32()

        if getattr(g_cliArgs, "debug", False):
            import datetime
            print(f"Python version: {self.m_version['major']}.{self.m_version['minor']}")
            print(f"timestamp: {datetime.datetime.fromtimestamp(timeStamp)}")

    @staticmethod
    def _opcode_of(version_info):
        """Resolve the (possibly lazy) opcode entry to its concrete module/class."""
        if not version_info:
            return None
        oc = version_info.get("opcode")
        # loader is a plain function; the resolved entry may be a class (also callable).
        if oc is None or isinstance(oc, type):
            return oc
        if callable(oc):
            resolved = oc()
            version_info["opcode"] = resolved
            return resolved
        return oc

    @property
    def Reader(self):
        return self.m_rdr.Reader

    @property
    def OpCodes(self):
        return self._opcode_of(self.m_version)

    @staticmethod
    def ResolveVersionTag(tag):
        parsed = parseVersionTag(tag)
        if not parsed:
            return None
        key = f"{parsed['major']}.{parsed['minor']}"
        aliased = VersionAliases[key] if key in VersionAliases else key
        return VersionToInfo.get(aliased) or None

    @staticmethod
    def ListSupportedVersions(desc=True):
        lst = list(VersionToInfo.values())
        lst.sort(key=lambda a: (a["major"], a["minor"]))
        if desc:
            lst.reverse()
        return lst

    @staticmethod
    def GuessVersion(buffer):
        candidates = PycReader.ListSupportedVersions(True)
        best = None
        for candidate in candidates:
            trial = PycReader.TryParseMarshal(buffer, candidate)
            if not trial:
                continue
            if trial["unknown"] == 0 and trial["remaining"] == 0:
                return candidate
            if (
                not best
                or trial["unknownRatio"] < best["unknownRatio"]
                or (trial["unknownRatio"] == best["unknownRatio"] and trial["remaining"] < best["remaining"])
            ):
                best = {**trial, "candidate": candidate}
        return best["candidate"] if best else None

    @staticmethod
    def ScanMarshalCandidates(buffer):
        candidates = PycReader.ListSupportedVersions(False)
        results = []
        for candidate in candidates:
            trial = PycReader.TryParseMarshal(buffer, candidate)
            if not trial:
                continue
            results.append({**trial, "versionInfo": candidate})
        results.sort(key=lambda a: (
            a["unknownRatio"],
            a["remaining"],
            a["unknown"],
            a["versionInfo"]["major"],
            a["versionInfo"]["minor"],
        ))
        return results

    @staticmethod
    def CountUnknownOpcodes(codeObject, reader, opCodeList):
        code = None
        if codeObject is not None and getattr(codeObject, "Code", None) is not None:
            code = getattr(codeObject.Code, "Value", None)
        if not code or not opCodeList:
            return {"unknown": sys.maxsize, "total": 0}
        wordSize = reader.getInstructionWordSize()
        unknown = 0
        total = 0
        if wordSize == 2:
            offset = 0
            while offset < len(code):
                total += 1
                if not opCodeList[code[offset]] if code[offset] < len(opCodeList) else True:
                    unknown += 1
                offset += 2
        else:
            offset = 0
            while offset < len(code):
                total += 1
                opcode = code[offset]
                entry = opCodeList[opcode] if opcode < len(opCodeList) else None
                if not entry:
                    unknown += 1
                    offset += 1
                    continue
                offset += 3 if getattr(entry, "HasArgument", False) else 1
        return {"unknown": unknown, "total": total}

    @staticmethod
    def TryParseMarshal(buffer, versionInfo):
        try:
            reader = PycReader(buffer, {"marshal": True, "versionInfo": versionInfo, "silent": True})
            obj = reader.ReadObject()
            if not obj or obj.ClassName != "Py_CodeObject":
                return None
            remaining = len(reader.m_rdr.Reader) - reader.m_rdr.pc
            if remaining < 0:
                return None

            prevDebug = getattr(g_cliArgs, "debug", None)
            if g_cliArgs is not None:
                g_cliArgs.debug = False
            opcodes = None
            try:
                opcode_ctor = PycReader._opcode_of(versionInfo)
                opcodes = opcode_ctor(obj) if opcode_ctor else None
            finally:
                if g_cliArgs is not None:
                    g_cliArgs.debug = prevDebug

            op_code_list = getattr(opcodes, "OpCodeList", None) if opcodes else None
            counts = PycReader.CountUnknownOpcodes(obj, reader, op_code_list)
            unknown = counts["unknown"]
            total = counts["total"]
            unknownRatio = unknown / total if total > 0 else 1

            score = 0
            if remaining == 0:
                score += 3
            if unknown == 0:
                score += 2
            code_val = getattr(obj.Code, "Value", None) if getattr(obj, "Code", None) else None
            if code_val and isinstance(code_val, (bytes, bytearray)):
                score += 1
            if getattr(obj, "Consts", None) and obj.Consts.ClassName == "Py_Tuple":
                score += 1
            if getattr(obj, "Names", None) and obj.Names.ClassName == "Py_Tuple":
                score += 1
            return {
                "score": score,
                "remaining": remaining,
                "unknown": unknown,
                "total": total,
                "unknownRatio": unknownRatio,
            }
        except Exception:
            return None

    def ReadObject(self):
        try:
            obj = PythonObject()
            value = None
            charCode = ord(self.m_rdr.readChar()[0])
            objectType = chr(charCode & 0x7f)
            isInterned = False

            if (charCode & 0x80) == 0x80:
                self.Objects.append(obj)

            if objectType == TypeObjectReference:
                objectIndex = self.m_rdr.readInt32()
                if objectIndex >= len(self.Objects):
                    raise PycReader.LoadError("Referense is outside of the boundaries", self.m_filename, self.m_rdr.pc)
                return self.Objects[objectIndex]
            elif objectType == TypeNull:
                obj.ClassName = "Py_Null"
            elif objectType == TypeNone:
                obj.ClassName = "Py_None"
            elif objectType == TypeStopiter:
                obj.ClassName = "Py_StopIteration"
            elif objectType == TypeEllipsis:
                obj.ClassName = "Py_Ellipsis"
            elif objectType == TypeFalse:
                obj.ClassName = "Py_False"
            elif objectType == TypeTrue:
                obj.ClassName = "Py_True"
            elif objectType == TypeInt:
                obj.ClassName = "Py_Int"
                obj.Value = self.m_rdr.readInt32()
            elif objectType == TypeInt64:
                obj.ClassName = "Py_VeryLong"
                obj.Value = self.m_rdr.readBytes(8)
            elif objectType == TypeLong:
                longValue = []
                d = 0
                n = self.m_rdr.readInt32()
                if n == 0:
                    obj.ClassName = "Py_Long"
                    obj.Value = 0
                else:
                    size = 1 + (abs(n) - 1) / PyLong_MARSHAL_RATIO
                    shorts_in_top_digit = 1 + (abs(n) - 1) % PyLong_MARSHAL_RATIO

                    idx = 0
                    while idx < size - 1:
                        d = 0
                        for j in range(int(PyLong_MARSHAL_RATIO)):
                            md = self.m_rdr.readInt16()
                            if md < 0 or md > PyLong_MARSHAL_BASE:
                                raise RuntimeError("cannot demarshal a long data")
                            d += md << (j * PyLong_MARSHAL_SHIFT)
                        longValue.append(d)
                        idx += 1

                    d = 0
                    j = 0
                    while j < shorts_in_top_digit:
                        md = self.m_rdr.readInt16()
                        if md < 0 or md > PyLong_MARSHAL_BASE:
                            raise RuntimeError("cannot demarshal a long data")
                        d += md << (j * PyLong_MARSHAL_SHIFT)
                        j += 1
                    longValue.append(d)

                    obj.ClassName = "Py_VeryLong"
                    obj.Value = longValue
            elif objectType == TypeFloat:
                obj.ClassName = "Py_Float"
                obj.Value = float(self.ReadString())
            elif objectType == TypeBinaryFloat:
                obj.ClassName = "Py_Float"
                obj.Value = self.m_rdr.readDouble()
            elif objectType == TypeComplex:
                obj.ClassName = "Py_Complex"
                obj.Value = [float(self.ReadString()), float(self.ReadString())]
            elif objectType == TypeBinaryComplex:
                obj.ClassName = "Py_Complex"
                obj.Value = [self.m_rdr.readDouble(), self.m_rdr.readDouble()]
            elif objectType == TypeInterned or objectType == TypeString:
                if objectType == TypeInterned:
                    isInterned = True
                value = self.m_rdr.readBytes(self.m_rdr.readUInt32())  # .toString("ascii");
                obj.ClassName = "Py_String"
                obj.Value = value
                if isInterned:
                    self.Strings.append(value)
            elif objectType == TypeUnicode:
                value = self.ReadString(self.m_rdr.readUInt32())
                obj.ClassName = "Py_Unicode"
                obj.Value = value
            elif objectType == TypeStringRef:
                listPos = self.m_rdr.readUInt32()
                obj.ClassName = "Py_String"
                obj.Value = self.Strings[listPos] if listPos < len(self.Strings) else None
            elif objectType in (TypeAsciiInterned, TypeShortAsciiInterned, TypeAscii, TypeShortAscii):
                if objectType in (TypeAsciiInterned, TypeShortAsciiInterned):
                    isInterned = True
                length = (
                    self.m_rdr.readUInt32()
                    if objectType in (TypeAscii, TypeAsciiInterned)
                    else self.m_rdr.readByte()
                )
                ascii_bytes = self.m_rdr.readBytes(length)
                ascii = ascii_bytes.decode("ascii", errors="replace") if isinstance(ascii_bytes, (bytes, bytearray)) else str(ascii_bytes)
                obj.ClassName = "Py_String"
                obj.Value = ascii
                if isInterned:
                    self.Strings.append(ascii)
            elif objectType in (TypeSmallTuple, TypeTuple):
                nTuples = self.m_rdr.readUInt32() if objectType == TypeTuple else self.m_rdr.readByte()
                tuples = []
                for _ in range(nTuples):
                    tuples.append(self.ReadObject())
                obj.ClassName = "Py_Tuple"
                obj.Value = tuples
            elif objectType == TypeList:
                nListElements = self.m_rdr.readUInt32()
                list_ = []
                for _ in range(nListElements):
                    list_.append(self.ReadObject())
                obj.ClassName = "Py_List"
                obj.Value = list_
            elif objectType == TypeDict:
                dict_ = []
                while True:
                    key = self.ReadObject()
                    if key.ClassName == "Py_Null":
                        break
                    dictValue = self.ReadObject()
                    dict_.append({"key": key, "value": dictValue})
                obj.ClassName = "Py_Dict"
                obj.Value = dict_
            elif objectType == TypeSet:
                nSetElements = self.m_rdr.readUInt32()
                set_ = []
                for _ in range(nSetElements):
                    set_.append(self.ReadObject())
                obj.ClassName = "Py_Set"
                obj.Value = set_
            elif objectType == TypeFrozenset:
                nFSetElements = self.m_rdr.readUInt32()
                frozenSet = []
                for _ in range(nFSetElements):
                    frozenSet.append(self.ReadObject())
                obj.ClassName = "Py_FrozenSet"
                obj.Value = frozenSet
            elif objectType in (TypeCode, TypeCode2):
                codeObj = self.ReadCodeObject()
                # Copy own attributes onto obj and switch its class to PythonCodeObject.
                for prop, val in codeObj.__dict__.items():
                    setattr(obj, prop, val)
                obj.__class__ = codeObj.__class__
            else:
                if charCode == 0:
                    obj.ClassName = "Py_Null"
                else:
                    raise PycReader.LoadError(
                        f"Don't know how to handle object Type {objectType}'",
                        self.m_filename,
                        self.m_rdr.pc,
                    )

            obj.Reader = self

            return obj
        except Exception:
            raise

    # snake_case alias
    read_object = ReadObject

    @staticmethod
    def ConvertBytesToString(bytes_):
        return bytes(bytes_).decode("utf-8", errors="replace")

    def ReadString(self, size=None):
        if size is None:
            size = self.m_rdr.readByte()
        if not size:
            return ""
        return self.m_rdr.readString(size)

    # snake_case alias
    read_string = ReadString

    def ReadCodeObject(self):
        codeObject = PythonCodeObject()

        isNewCodeLayout = self.versionCompare(3, 11) >= 0

        argCount = 0

        if self.versionCompare(1, 3) >= 0 and self.versionCompare(2, 3) < 0:
            argCount = self.m_rdr.readUInt16()
        elif self.versionCompare(2, 3) >= 0:
            argCount = self.m_rdr.readUInt32()
        codeObject.ArgCount = argCount

        hasPosOnly = self.versionCompare(3, 8) >= 0 and not (self.m_version and self.m_version.get("preReleaseMarshal"))
        codeObject.PosOnlyArgCount = self.m_rdr.readUInt32() if hasPosOnly else 0
        codeObject.KWOnlyArgCount = self.m_rdr.readUInt32() if self.versionCompare(3, 0) >= 0 else 0

        codeObject.NumLocals = 0
        if self.versionCompare(1, 3) >= 0 and self.versionCompare(2, 3) < 0:
            codeObject.NumLocals = self.m_rdr.readUInt16()
        elif self.versionCompare(2, 3) >= 0 and not isNewCodeLayout:
            codeObject.NumLocals = self.m_rdr.readUInt32()

        codeObject.StackSize = 0
        if self.versionCompare(1, 5) >= 0 and self.versionCompare(2, 3) < 0:
            codeObject.StackSize = self.m_rdr.readUInt16()
        elif self.versionCompare(2, 3) >= 0:
            codeObject.StackSize = self.m_rdr.readUInt32()

        codeObject.Flags = 0
        if self.versionCompare(1, 3) >= 0 and self.versionCompare(2, 3) < 0:
            codeObject.Flags = self.m_rdr.readUInt16()
        elif self.versionCompare(2, 3) >= 0:
            codeObject.Flags = self.m_rdr.readUInt32()

        # Some fixtures carry malformed code objects (e.g., flags bytes are missing),
        # which misaligns the marshal stream and makes us read code bytes as an unknown type.
        # Heuristic: if the next byte is not a known marshal type but the previous 4th byte is,
        # rewind by 4 bytes (assume flags were absent) so code/consts parsing can proceed.
        reader_buf = self.m_rdr.Reader
        nextType = reader_buf[self.m_rdr.pc] if self.m_rdr.pc < len(reader_buf) else None
        prevType = reader_buf[self.m_rdr.pc - 4] if self.m_rdr.pc >= 4 else None
        if (
            nextType is not None
            and chr(nextType & 0x7f) not in KnownTypes
            and prevType is not None
            and chr(prevType & 0x7f) in KnownTypes
        ):
            if getattr(g_cliArgs, "debug", False):
                print(
                    f"[ReadCodeObject] Realigning code object start: rewind 4 bytes (suspect missing flags). pc={self.m_rdr.pc}",
                    file=sys.stderr,
                )
            self.m_rdr.pc -= 4
            codeObject.FlagsMisaligned = True

        codeObject.codeOffset = self.m_rdr.pc
        codeObject.Code = self.ReadObject()
        codeObject.Consts = self.ReadObject()

        if getattr(g_cliArgs, "debug", False) and self.versionCompare(3, 13) >= 0:
            consts_class = getattr(codeObject.Consts, "ClassName", None) if codeObject.Consts else None
            consts_value = getattr(codeObject.Consts, "Value", None) if codeObject.Consts else None
            consts_len = len(consts_value) if consts_value else None
            print(f"[ReadCodeObject] name={codeObject.Name or '?'}, Consts.ClassName={consts_class}, Consts.length={consts_len}")
            if consts_value:
                for i in range(min(3, len(consts_value))):
                    c = consts_value[i]
                    cn = getattr(c, "ClassName", None) if c is not None else None
                    print(f"  Consts[{i}] = {cn or 'null/undefined'} ({type(c).__name__})")

        codeObject.Names = self.ReadObject()

        if isNewCodeLayout:
            codeObject.LocalsPlusNames = self.ReadObject()
            codeObject.VarKinds = self.ReadObject()
            split = self.splitLocalsPlus(codeObject.LocalsPlusNames, codeObject.VarKinds)
            locals_ = split["locals"]
            cellVars = split["cellVars"]
            freeVars = split["freeVars"]
            codeObject.VarNames = PythonObject("Py_Tuple", locals_)
            codeObject.CellVars = PythonObject("Py_Tuple", cellVars)
            codeObject.FreeVars = PythonObject("Py_Tuple", freeVars)
            codeObject.NumLocals = len(locals_)
        else:
            codeObject.VarNames = self.ReadObject() if self.versionCompare(1, 3) >= 0 else PythonObject("Py_Tuple", [])
            codeObject.VarKinds = PythonObject("Py_String", "")
            codeObject.FreeVars = self.ReadObject() if self.versionCompare(2, 1) >= 0 else PythonObject("Py_Tuple", [])
            codeObject.CellVars = self.ReadObject() if self.versionCompare(2, 1) >= 0 else PythonObject("Py_Tuple", [])
        codeObject.FileName = self.ReadObject().toString()

        if not self.m_filename:
            self.m_filename = codeObject.FileName

        codeObject.Name = self.ReadObject().toString()
        codeObject.QualName = self.ReadObject() if self.versionCompare(3, 11) >= 0 else PythonObject("Py_String", "")

        codeObject.FirstLineNo = 0
        if self.versionCompare(1, 5) >= 0 and self.versionCompare(2, 3) < 0:
            codeObject.FirstLineNo = self.m_rdr.readUInt16()
        elif self.versionCompare(2, 3) >= 0:
            codeObject.FirstLineNo = self.m_rdr.readUInt32()

        codeObject.Methods = {}
        codeObject.LineNoTab = []
        if self.versionCompare(1, 5) >= 0:
            self.UnpackLineNumbers(codeObject)
        if self.versionCompare(3, 11) >= 0:
            codeObject.exceptTable = self.ReadObject()
            # Parse exception table into structured format
            codeObject.ExceptionTable = self.ParseExceptionTable(codeObject.exceptTable)
        else:
            codeObject.exceptTable = PythonObject("Py_String", "")
            codeObject.ExceptionTable = []

        return codeObject

    # snake_case alias
    read_code_object = ReadCodeObject

    def ParseExceptionTable(self, exceptTableObject):
        """
        Parse Python 3.11+ exception table format (wordcode units, not delta encoded)
        Each entry: start, length, target, depth|lasti (all varints)
        """
        if (
            not exceptTableObject
            or not exceptTableObject.Value
            or len(exceptTableObject.Value) == 0
        ):
            return []

        data = exceptTableObject.Value
        entries = []
        pos = [0]  # mutable index for closure

        def decodeVarint():
            # Matches CPython 3.11+ _parse_varint (big-endian 6-bit chunks)
            if pos[0] >= len(data):
                return 0
            byte = data[pos[0]]
            pos[0] += 1
            result = byte & 0x3F
            while byte & 0x40:
                if pos[0] >= len(data):
                    break
                byte = data[pos[0]]
                pos[0] += 1
                result = (result << 6) | (byte & 0x3F)
            return result

        while pos[0] < len(data):
            start = decodeVarint() * 2
            length = decodeVarint() * 2
            end = start + length
            targetOffset = decodeVarint() * 2
            depthLasti = decodeVarint()
            depth = depthLasti >> 1
            lasti = depthLasti & 1

            # Use SimpleNamespace so handlers can use .start/.end/.target/.depth/.lasti
            # (the JS baseline exposes plain object literals; Python dicts would
            # require entry["start"] everywhere — dozens of sites).
            from types import SimpleNamespace
            entries.append(SimpleNamespace(
                start=start, end=end, target=targetOffset, depth=depth, lasti=lasti,
            ))

        return entries

    parse_exception_table = ParseExceptionTable

    def UnpackLineNumbers(self, codeObject):
        codeObject.LineNoTab = []
        lineno = self.ReadObject()
        codeObject.LineNoTabObject = lineno
        if self.versionCompare(3, 11) >= 0:
            self.UnpackNewLineNumbers(codeObject)
            return

        if not lineno or not lineno.Value or len(lineno.Value) == 0:
            code_val = getattr(codeObject.Code, "Value", None) if codeObject.Code else None
            codeLen = len(code_val) if code_val else 0
            codeObject.LineNoTab = [codeObject.FirstLineNo] * codeLen
            return

        bytePos = 0
        currentBytePos = 0
        linePos = codeObject.FirstLineNo
        idx = 0
        while idx < len(lineno.Value):
            bytePos += lineno.Value[idx]
            while currentBytePos < bytePos:
                codeObject.LineNoTab.append(linePos)
                currentBytePos += 1
            linePos += lineno.Value[idx + 1]
            idx += 2

        while currentBytePos < len(codeObject.Code.Value):
            codeObject.LineNoTab.append(linePos)
            currentBytePos += 1

    unpack_line_numbers = UnpackLineNumbers

    def getInstructionWordSize(self):
        return 2 if self.versionCompare(3, 6) >= 0 else 1

    get_instruction_word_size = getInstructionWordSize

    def splitLocalsPlus(self, localsPlusNames, localsPlusKinds):
        locals_ = []
        cellVars = []
        freeVars = []

        if (
            not localsPlusNames
            or not getattr(localsPlusNames, "Value", None)
            or not localsPlusKinds
            or not getattr(localsPlusKinds, "Value", None)
        ):
            return {"locals": locals_, "cellVars": cellVars, "freeVars": freeVars}

        kindBuffer = (
            localsPlusKinds.Value
            if isinstance(localsPlusKinds.Value, (bytes, bytearray))
            else bytes(localsPlusKinds.Value)
        )

        for idx in range(len(localsPlusNames.Value)):
            name = localsPlusNames.Value[idx]
            kind = kindBuffer[idx] if idx < len(kindBuffer) else 0
            isLocal = (kind & 0x20) != 0
            isCell = (kind & 0x40) != 0
            isFree = (kind & 0x80) != 0

            if isLocal:
                locals_.append(name)
            if isCell:
                cellVars.append(name)
            if isFree:
                freeVars.append(name)

        return {"locals": locals_, "cellVars": cellVars, "freeVars": freeVars}

    split_locals_plus = splitLocalsPlus

    def scanVarint(self, buffer, offset):
        idx = offset
        if idx >= len(buffer):
            return {"value": 0, "next": idx}
        read = buffer[idx]
        idx += 1
        val = read & 0x3F
        shift = 0
        while (read & 0x40) and idx < len(buffer):
            read = buffer[idx]
            idx += 1
            shift += 6
            val |= (read & 0x3F) << shift
        return {"value": val, "next": idx}

    scan_varint = scanVarint

    def scanSignedVarint(self, buffer, offset):
        r = self.scanVarint(buffer, offset)
        value = r["value"]
        nxt = r["next"]
        signed = -(value >> 1) if (value & 1) else (value >> 1)
        return {"value": signed, "next": nxt}

    scan_signed_varint = scanSignedVarint

    def getLineDeltaFromEntry(self, buffer, offset):
        firstByte = buffer[offset]
        code = (firstByte >> 3) & 0x0F
        if code == 15:  # PY_CODE_LOCATION_INFO_NONE
            return 0
        elif code == 13 or code == 14:  # NO_COLUMNS / LONG
            r = self.scanSignedVarint(buffer, offset + 1)
            return r["value"]
        elif code == 11:  # ONE_LINE1
            return 1
        elif code == 12:  # ONE_LINE2
            return 2
        else:
            return 0

    get_line_delta_from_entry = getLineDeltaFromEntry

    def advanceLineTableOffset(self, buffer, offset):
        idx = offset
        while idx < len(buffer) and (buffer[idx] & 0x80) == 0:
            idx += 1
        return idx

    advance_line_table_offset = advanceLineTableOffset

    def UnpackNewLineNumbers(self, codeObject):
        lineTableObj = codeObject.LineNoTabObject
        codeBytes = getattr(codeObject.Code, "Value", []) if codeObject.Code else []
        wordSize = self.getInstructionWordSize()
        totalLength = len(codeBytes) if codeBytes else 0
        lineArray = [codeObject.FirstLineNo] * totalLength

        if not lineTableObj or not lineTableObj.Value or not len(lineTableObj.Value):
            codeObject.LineNoTab = lineArray
            return

        data = (
            lineTableObj.Value
            if isinstance(lineTableObj.Value, (bytes, bytearray))
            else bytes(lineTableObj.Value)
        )

        offset = 0
        computedLine = codeObject.FirstLineNo
        currentStart = 0
        currentEnd = 0
        lastLine = codeObject.FirstLineNo

        while offset < len(data):
            firstByte = data[offset]
            if (firstByte & 0x80) == 0:
                offset += 1
                continue
            lineDelta = self.getLineDeltaFromEntry(data, offset)
            computedLine += lineDelta
            currentStart = currentEnd
            currentEnd = currentStart + (((firstByte & 0x07) + 1) * wordSize)
            codeLine = lastLine if ((firstByte >> 3) & 0x0F) == 0x0F else computedLine
            idx = currentStart
            while idx < currentEnd and idx < len(lineArray):
                lineArray[idx] = codeLine
                idx += 1
            if ((firstByte >> 3) & 0x0F) != 0x0F:
                lastLine = computedLine
            offset = self.advanceLineTableOffset(data, offset + 1)

        codeObject.LineNoTab = lineArray

    unpack_new_line_numbers = UnpackNewLineNumbers

    @staticmethod
    def DumpObject(obj, level=None):
        result = ""
        level = level or 0

        for _ in range(level):
            result += "  "

        try:
            cn = obj.ClassName

            if cn == "Py_Null":
                result += "Py_NULL\n"
            elif cn == "Py_None":
                result += "Py_None\n"
            elif cn == "Py_StopIteration":
                result += f"Py_StopIteration, Value = {obj.toString()}\n"
            elif cn == "Py_Ellipsis":
                result += f"Py_Ellipsis, Value = {obj.toString()}\n"
            elif cn == "Py_False":
                result += "Py_False\n"
            elif cn == "Py_True":
                result += "Py_True\n"
            elif cn == "Py_Int":
                result += f"Py_Int, Value = {obj.toString()}\n"
            elif cn == "Py_Long":
                result += f"Py_Long, Value = {obj.toString()}\n"
            elif cn == "Py_VeryLong":
                result += f"Py_VeryLong, Value = {obj.toString()}\n"
            elif cn == "Py_Float":
                result += f"Py_Float, Value = {obj.toString()}\n"
            elif cn == "Py_Complex":
                result += f"Py_Complex, Value = {obj.toString()}\n"
            elif cn == "Py_Unicode":
                result += f'Py_Unicode, Value = "{obj.toString()}"\n'
            elif cn == "Py_String":
                result += f'Py_String, Value = "{obj.toString()}"\n'
            elif cn == "Py_Tuple":
                result += "Py_Typle:\n"
                for item in obj.Value:
                    result += PycReader.DumpObject(item, level + 1)
            elif cn == "Py_List":
                result += "Py_List:\n"
                for item in obj.Value:
                    result += PycReader.DumpObject(item, level + 1)
            elif cn == "Py_Dict":
                result += "Py_Dict:\n"
                # JS: Object.entries(obj.Value). obj.Value is a list of {key,value} dicts.
                for pair in list(obj.Value.items()) if isinstance(obj.Value, dict) else list(enumerate(obj.Value)):
                    result += "Dict Key:\n"
                    result += PycReader.DumpObject(pair[0], level + 1)
                    result += "Dict Value:\n"
                    result += PycReader.DumpObject(pair[1], level + 1)
            elif cn == "Py_Set":
                result += "Py_Set:\n"
                for item in obj.Value:
                    result += PycReader.DumpObject(item, level + 1)
            elif cn == "Py_FrozenSet":
                result += "Py_FrozenSet:\n"
                for item in obj.Value:
                    result += PycReader.DumpObject(item, level + 1)
            elif cn == "Py_CodeObject":
                result += "Py_CodeObject\n"
                codeObject = obj
                if codeObject is None:
                    return result
                pars = ""
                if codeObject.ArgCount > 0:
                    for idx in range(codeObject.ArgCount):
                        pars += (
                            codeObject.VarNames.Value[idx].toString()
                            if pars == ""
                            else ", " + codeObject.VarNames.Value[idx].toString()
                        )
                name_str = codeObject.Name and getattr(codeObject.Name, "Value", None) and codeObject.Name.toString() if hasattr(codeObject.Name, "toString") else codeObject.Name
                result += f"Code Object: {name_str} ({pars})\n"
                result += f"ArgCount = {codeObject.ArgCount}\n"
                result += f"NumLocals {codeObject.NumLocals}\n"
                result += f"StackSize {codeObject.StackSize}\n"
                result += f"Flags {codeObject.Flags}\n"
                if codeObject.Consts and codeObject.Consts.Value:
                    result += "Consts:\n"
                    for item in codeObject.Consts.Value:
                        result += PycReader.DumpObject(item, level + 1)
                if codeObject.Names and codeObject.Names.Value:
                    result += "Names:\n"
                    for item in codeObject.Names.Value:
                        result += PycReader.DumpObject(item, level + 1)
                if codeObject.VarNames and codeObject.VarNames.Value:
                    result += "VarNames:\n"
                    for item in codeObject.VarNames.Value:
                        result += PycReader.DumpObject(item, level + 1)
                if codeObject.FreeVars and codeObject.FreeVars.Value:
                    result += "FreeVars:\n"
                    for item in codeObject.FreeVars.Value:
                        result += PycReader.DumpObject(item, level + 1)
                if codeObject.CellVars and codeObject.CellVars.Value:
                    result += "CellVars:\n"
                    for item in codeObject.CellVars.Value:
                        result += PycReader.DumpObject(item, level + 1)
                fn_str = codeObject.FileName and getattr(codeObject.FileName, "Value", None) and codeObject.FileName.toString() if hasattr(codeObject.FileName, "toString") else codeObject.FileName
                result += f"FileName = {fn_str}\n"
                result += f"Name = {name_str}\n"
                result += f"FirstLineNo = {codeObject.FirstLineNo}\n"
            else:
                result += f"No such type {obj.ClassName}. Value = {obj.Value}\n"
        except Exception as ex:
            print(f"DumpObject error: {ex}")
        return result

    dump_object = DumpObject

    @staticmethod
    def GetMethodParametersString(codeObject):
        pars = ""
        if codeObject.ArgCount > 0:
            for idx in range(codeObject.ArgCount):
                pars += (
                    codeObject.VarNames[idx]
                    if pars == ""
                    else ", " + codeObject.VarNames[idx]
                )
        return pars

    get_method_parameters_string = GetMethodParametersString

    def versionCompare(self, major, minor):
        return (self.m_version["major"] - major) * 100 + (self.m_version["minor"] - minor)

    version_compare = versionCompare
