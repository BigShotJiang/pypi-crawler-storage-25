"""Binary reader for .pyc files — byte/int/float decoding with tracked PC."""

from __future__ import annotations

import struct


class BinaryReader:
    __slots__ = ("_buf", "_pc")

    def __init__(self, data: bytes | bytearray | memoryview | None = None) -> None:
        self._buf: bytes = bytes(data) if data else b""
        self._pc: int = 0

    @property
    def pc(self) -> int:
        return self._pc

    @pc.setter
    def pc(self, pos: int) -> None:
        self._pc = pos

    @property
    def eof(self) -> bool:
        return self._pc >= len(self._buf)

    # Upstream JS property name
    EOF = property(lambda self: self.eof)

    @property
    def reader(self) -> bytes:
        return self._buf

    # Upstream alias
    Reader = reader

    def _read(self, fmt: str, size: int) -> int | float:
        value = struct.unpack_from(fmt, self._buf, self._pc)[0]
        self._pc += size
        return value

    def read_byte(self) -> int:
        v = self._buf[self._pc]
        self._pc += 1
        return v

    def read_char(self) -> str:
        return chr(self.read_byte())

    def read_uint16(self) -> int:
        return self._read("<H", 2)  # type: ignore[return-value]

    def read_uint16_be(self) -> int:
        return self._read(">H", 2)  # type: ignore[return-value]

    def read_int16(self) -> int:
        return self._read("<h", 2)  # type: ignore[return-value]

    def read_int16_be(self) -> int:
        return self._read(">h", 2)  # type: ignore[return-value]

    def read_int32(self) -> int:
        return self._read("<i", 4)  # type: ignore[return-value]

    def read_int32_be(self) -> int:
        return self._read(">i", 4)  # type: ignore[return-value]

    def read_uint32(self) -> int:
        return self._read("<I", 4)  # type: ignore[return-value]

    def read_uint32_be(self) -> int:
        return self._read(">I", 4)  # type: ignore[return-value]

    def read_long(self) -> dict[str, int]:
        high = self.read_int32()
        low = self.read_int32()
        return {"low": low, "high": high}

    def read_long_be(self) -> dict[str, int]:
        high = self.read_int32_be()
        low = self.read_int32_be()
        return {"low": low, "high": high}

    def read_float(self) -> float:
        return self._read("<f", 4)  # type: ignore[return-value]

    def read_float_be(self) -> float:
        return self._read(">f", 4)  # type: ignore[return-value]

    def read_double(self) -> float:
        return self._read("<d", 8)  # type: ignore[return-value]

    def read_double_be(self) -> float:
        return self._read(">d", 8)  # type: ignore[return-value]

    def read_bytes(self, length: int) -> bytes:
        if self._pc + length > len(self._buf):
            raise ValueError("Requested more data than buffer holds")
        value = self._buf[self._pc : self._pc + length]
        self._pc += length
        return value

    def read_string(self, length: int) -> str:
        return self.read_bytes(length).decode("utf-8", errors="replace")

    # camelCase aliases — some upstream call sites still use them
    readByte = read_byte
    readChar = read_char
    readUInt16 = read_uint16
    readUInt16BE = read_uint16_be
    readInt16 = read_int16
    readInt16BE = read_int16_be
    readInt32 = read_int32
    readInt32BE = read_int32_be
    readUInt32 = read_uint32
    readUInt32BE = read_uint32_be
    readLong = read_long
    readLongBE = read_long_be
    readFloat = read_float
    readFloatBE = read_float_be
    readDouble = read_double
    readDoubleBE = read_double_be
    readBytes = read_bytes
    readString = read_string
