__version__ = "0.1.0"

# JS arrays monkey-patched with .top(n=0) and .empty() helpers; the port's
# handlers call these on plain Python lists. Patch list to match JS semantics.
try:
    from forbiddenfruit import curse

    def _list_top(self, n=0):
        if not self:
            return None
        idx = -1 - int(n)
        return self[idx] if -len(self) <= idx < len(self) else None

    def _list_empty(self):
        return len(self) == 0

    # JS `[].pop()` returns undefined on empty; Python raises IndexError.
    # The mechanical port freely calls pop() on possibly-empty data stacks.
    # Override pop() to return None when empty (JS semantics) but keep
    # the positional form (pop(i)) raising as Python does — that form is
    # reserved for genuine list mutations where emptiness really is a bug.
    _orig_pop = list.pop

    def _list_pop(self, *args):
        if not args and not self:
            return None
        return _orig_pop(self, *args)

    curse(list, "top", _list_top)
    curse(list, "empty", _list_empty)
    curse(list, "pop", _list_pop)
except Exception:  # pragma: no cover — missing forbiddenfruit is a hard failure at runtime
    pass
