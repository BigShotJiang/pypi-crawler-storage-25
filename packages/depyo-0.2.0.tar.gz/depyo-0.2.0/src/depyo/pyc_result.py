from __future__ import annotations


class PycResult:
    def __init__(self, lines=None, doNotIndent=False):
        self.result = []
        self.indent = 0
        self.doNotIndent = False
        if lines:
            self.add(lines)
        self.doNotIndent = doNotIndent

    @property
    def length(self):
        return len(self.result)

    @property
    def last(self):
        return self.result[len(self.result) - 1]

    @property
    def hasResult(self):
        return len(self.result) > 1 or (len(self.result) == 1 and len(self.result[0]) > 0)

    def increaseIndent(self):
        self.indent += 1

    def decreaseIndent(self):
        if self.indent > 0:
            self.indent -= 1

    def clear(self):
        self.indent = 0
        self.result = []

    def add(self, line):
        padding = " " * (4 * self.indent)
        lines = []

        if isinstance(line, PycResult):
            if not line.doNotIndent:
                padding = " " * (4 * (self.indent + 1))
            lines = line.result
        else:
            lines.append(line)

        for line in lines:
            self.result.append(padding + line)

    def lastLineAppend(self, data, shouldTrim=True):
        if len(self.result) == 0:
            self.result.append("")
        if isinstance(data, str):
            self.result[len(self.result) - 1] += data.strip() if shouldTrim else data
        else:
            s = None
            if data is not None and hasattr(data, 'result') and data.result:
                s = data.result.pop(0)
            self.result[len(self.result) - 1] += (s.strip() if shouldTrim else s)
            self.add(data)

    def chop(self, suffix):
        if self.last.endswith(suffix):
            self.result[len(self.result) - 1] = self.last[0:len(self.last) - len(suffix)]

    def __str__(self):
        return "\n".join(self.result)

    def toString(self):
        return "\n".join(self.result)

    # JS-semantics coercion for `pyc_result + str` / `str + pyc_result`.
    # Upstream freely concatenates; Python needs explicit dunder methods.
    def __add__(self, other):
        return self.__str__() + str(other)

    def __radd__(self, other):
        return str(other) + self.__str__()
