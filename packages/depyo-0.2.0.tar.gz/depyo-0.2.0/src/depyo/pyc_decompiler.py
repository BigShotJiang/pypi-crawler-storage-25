"""PycDecompiler — mechanical translation of lib/PycDecompiler.js.

This is the workhorse that glues handlers + bytecode + AST together.
Translation preserves method names (CamelCase OK — callers depend on them)
and variable names to keep behavior identical to the JS source.
"""
from __future__ import annotations

import builtins
import os
import re
import sys
import traceback

from depyo import ast_node as AST
from depyo.code_reader import CodeReader
from depyo.binary_reader import BinaryReader
from depyo.pyc_reader import PycReader


# ---------------------------------------------------------------------------
# Helpers mirroring Array.prototype extensions in the JS source.
# ---------------------------------------------------------------------------

def _top(arr, pos=0):
    """Mirror of JS `Array.prototype.top` — returns arr[len-pos-1] or None."""
    if not arr:
        return None
    idx = len(arr) - pos - 1
    if idx < 0:
        return None
    return arr[idx]


def _empty(arr):
    """Mirror of JS `Array.prototype.empty`."""
    return not arr or len(arr) == 0


def _g_cli_args():
    """Access the global g_cliArgs (set by __main__)."""
    # Try builtins first (set when g_cliArgs is exposed globally),
    # then fall back to the __main__ module attribute.
    g = getattr(builtins, "g_cliArgs", None)
    if g is None:
        g = getattr(sys.modules.get("__main__", None), "g_cliArgs", None)
    return g


def _debug_enabled():
    g = _g_cli_args()
    return bool(g and getattr(g, "debug", False))


def _silent_enabled():
    g = _g_cli_args()
    return bool(g and getattr(g, "silent", False))


def _strict_enabled():
    g = _g_cli_args()
    return bool(g and getattr(g, "strict", False))


def _verbose_enabled():
    g = _g_cli_args()
    return bool(g and getattr(g, "verbose", False))


def _raw_spacing_enabled():
    g = _g_cli_args()
    return bool(g and getattr(g, "rawSpacing", False))


def _log(msg):
    print(msg)


def _err(msg):
    print(msg, file=sys.stderr)


# Lazy import of resolveBoolChainFrames to avoid circular imports
# (handlers import from this module indirectly in the JS version).
def _resolve_bool_chain_frames(decompiler, offset):
    try:
        from depyo.handlers.control_flow_jumps import resolveBoolChainFrames
    except Exception:
        try:
            from depyo.handlers.control_flow_jumps import resolve_bool_chain_frames as resolveBoolChainFrames
        except Exception:
            return
    resolveBoolChainFrames(decompiler, offset)


# ---------------------------------------------------------------------------
# PycDecompiler
# ---------------------------------------------------------------------------


class PycDecompiler:
    # Static registry of opcode → handler function
    opCodeHandlers: dict = {}

    def debug(self, message):
        """Debug logging helper - only logs if --debug flag is set."""
        if _debug_enabled():
            print(message)

    def __init__(self, obj=None):
        # Instance defaults (mirror JS class fields).
        self.cleanBuild = False
        self.errors = []  # Per-opcode exceptions caught by main loop.
        self.object = None
        self.code = None
        self.blocks = []
        self.unpack = 0
        self.starPos = -1
        self.skipNextJump = False
        self.else_pop = False
        self.variable_annotations = None
        self.need_try = None
        self.defBlock = None
        self.curBlock = None
        self.dataStack = []
        self.handlers = {}
        self.unreachableUntil = -1
        self.currentMatch = None
        self.matchSubject = None
        self.inMatchPattern = False
        self.currentCase = None
        self.matchParentBlock = None
        self.patternOps = []
        self.potentialMatchSubject = None
        self.matchCandidateStart = -1
        self.lastLoadOffset = -1
        self.caseBodyStartIndex = 0
        self.matchPreNodesStart = 0
        self.pendingConditionalExprs = []

        # Additional runtime attributes used elsewhere.
        self.activeExceptionStarts = None
        self.inExceptionTableHandler = False
        self.maxExceptionHandlerEnd = 0
        self._withExceptRanges = None
        self.exceptionHandlerOffsets = None
        self.appendExceptionExprs = False
        self.boolChainStack = None
        self.funcAnnotations = None
        self.OpCodes = None
        # Handler-managed lazy flags (JS assigned via `this.X = true` anywhere).
        self.ignoreNextConditional = False
        self.inExceptionGroup = False
        self.insideAwait = False
        self.isWalrusOperator = False
        self.egMatchTypeStack = []
        self.pendingEgMatchType = None
        self.cleanupStackDepth = 0

        if obj is None:
            return

        self.object = obj
        self.OpCodes = self.object.Reader.OpCodes
        self.code = self.OpCodes(self.object)
        self.defBlock = AST.ASTBlock(AST.ASTBlock.BlockType.Main, 0, self.code.LastOffset)
        self.defBlock.init()
        self.curBlock = self.defBlock
        self.blocks.append(self.defBlock)
        self.activeExceptionStarts = set()
        self.inExceptionTableHandler = False
        et = self.object.ExceptionTable or []
        depthEnds = [e.end or 0 for e in et if getattr(e, "depth", 0) > 0]
        self.maxExceptionHandlerEnd = max(depthEnds) if depthEnds else 0

        if len(PycDecompiler.opCodeHandlers) == 0:
            PycDecompiler.setupHandlers()

    @staticmethod
    def setupHandlers():
        """Scan depyo.handlers package, register handleXxx functions."""
        try:
            from depyo import handlers as handlers_pkg
        except Exception as err:
            _err(f"Error importing handlers package: {err}")
            return
        try:
            from depyo.opcodes import OpCodes as OpCodesMap
        except Exception:
            # Fall back: look for module-level OpCodes
            try:
                from depyo import OpCodes as OpCodesMap  # type: ignore
            except Exception:
                OpCodesMap = None

        if OpCodesMap is None:
            # Cannot map names to opcode IDs without the OpCodes table.
            return

        handlers_dir = os.path.dirname(handlers_pkg.__file__)

        def _snake(body):
            # camelCase → SNAKE_CASE with runs-of-caps handling:
            # HandleABCDef → ABC_DEF
            s = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', body)
            s = re.sub(r'([A-Z])([A-Z][a-z])', r'\1_\2', s)
            return s.upper()

        def _legacy_snake(body):
            # Legacy regex for handlers like handleCallIntrinsic1A
            s = re.sub(r'([A-Z][a-z]+)', lambda m: m.group(1).upper() + '_', body)
            s = re.sub(r'_$', '', s)
            return s

        try:
            entries = os.listdir(handlers_dir)
        except Exception as err:
            _err(f"Error reading handlers directory {handlers_dir}: {err}")
            return

        import importlib

        for entry_name in entries:
            if not entry_name.endswith('.py'):
                continue
            if entry_name.startswith('_'):
                continue
            module_name = f"depyo.handlers.{entry_name[:-3]}"
            try:
                mod = importlib.import_module(module_name)
            except Exception as err:
                _err(f"Error loading static handlers from {entry_name}: {err}")
                continue
            for handlerName in dir(mod):
                if not handlerName.startswith("handle"):
                    continue
                handlerFunc = getattr(mod, handlerName, None)
                if not callable(handlerFunc):
                    continue
                body = re.sub(r'^handle', '', handlerName)
                opCodeName = _snake(body)
                has_name = hasattr(OpCodesMap, opCodeName) or (
                    isinstance(OpCodesMap, dict) and opCodeName in OpCodesMap
                )
                if not has_name:
                    legacy = _legacy_snake(body)
                    legacy_has = hasattr(OpCodesMap, legacy) or (
                        isinstance(OpCodesMap, dict) and legacy in OpCodesMap
                    )
                    if legacy_has:
                        opCodeName = legacy
                        has_name = True
                if has_name:
                    opCodeId = (
                        OpCodesMap[opCodeName] if isinstance(OpCodesMap, dict)
                        else getattr(OpCodesMap, opCodeName)
                    )
                    if opCodeId in PycDecompiler.opCodeHandlers:
                        raise RuntimeError(
                            f"Static handler collision: OpCode {opCodeName} ({opCodeId}) already bound; "
                            f"refusing silent overwrite from {entry_name}:{handlerName}."
                        )
                    PycDecompiler.opCodeHandlers[opCodeId] = handlerFunc
                else:
                    raise RuntimeError(
                        f"Static handler mapping failed: \"{opCodeName}\" (from {entry_name}:{handlerName}) "
                        f"is not in OpCodes. Rename the handler to match a known opcode, "
                        f"or add the opcode to lib/OpCodes."
                    )

    def decompile(self):
        functonBody = self.statements()
        if functonBody is not None and getattr(functonBody, "isModuleLevel", "__missing__") != "__missing__":
            functonBody.isModuleLevel = True
        self.transformExceptionGroups(functonBody)
        self.mergeOrphanedEgHandlers(functonBody)
        self.wrapFunctionExceptionGroups(functonBody)
        self.rewriteGenericWrappers(functonBody)
        self.enrichGenericAnnotations(functonBody)
        self.rewriteClassDefinitions(functonBody)
        self.removeNullSentinelComparisons(functonBody)
        self.cleanupExcMatchArtifacts(functonBody)
        self.hoistNestedExceptBlocks(functonBody)
        self.dedupeExceptHandlers(functonBody)
        self.removeDuplicateReturns(functonBody)

        if self.object.Name == "<lambda>":
            self.foldLambdaConditional(functonBody)

        if (self.object.Name != "<lambda>"
                and isinstance(getattr(functonBody, "last", None), AST.ASTReturn)
                and isinstance(functonBody.last.value, AST.ASTNone)):
            functonBody.list.pop()

        if len(functonBody.list) == 0:
            functonBody.list.append(AST.ASTKeyword(AST.ASTKeyword.Word.Pass))

        return functonBody

    def foldLambdaConditional(self, body):
        # Lambda bodies must be single expressions. CPython often compiles a
        # conditional expression `A if cond else B` as:
        #   POP_JUMP_IF_FALSE X; LOAD A; RETURN_VALUE; X: LOAD B; RETURN_VALUE
        # The decompiler's default path leaves this as two statements which is
        # invalid Python inside a lambda. Detect the patterns and fold into a
        # single ASTReturn(ASTTernary).
        lst = getattr(body, "list", None)
        if not isinstance(lst, list) or len(lst) != 2:
            return
        first = lst[0]
        second = lst[1]
        if not isinstance(second, AST.ASTReturn):
            return
        elseVal = second.value

        def makeCondBlock(condExpr, negative):
            cb = AST.ASTCondBlock(AST.ASTBlock.BlockType.If, 0, 0, condExpr, bool(negative))
            return cb

        tern = None

        # Case 1: first is `ASTReturn(ASTBinary(cond AND/OR val))` — the line-900
        # collapse already ran. Recover cond/val/direction from the binary op.
        if isinstance(first, AST.ASTReturn) and isinstance(first.value, AST.ASTBinary):
            bin_ = first.value
            isAnd = bin_.op == AST.ASTBinary.BinOp.LogicalAnd
            isOr = bin_.op == AST.ASTBinary.BinOp.LogicalOr
            if isAnd or isOr:
                cond = bin_.left
                thenVal = bin_.right
                cb = makeCondBlock(cond, isOr)
                tern = AST.ASTTernary(cb, thenVal, elseVal)

        # Case 2: first is an ASTCondBlock (if-return not collapsed by line 900).
        if (tern is None
                and isinstance(first, AST.ASTCondBlock)
                and first.blockType == AST.ASTBlock.BlockType.If
                and isinstance(getattr(first, "nodes", None), list)
                and len(first.nodes) == 1
                and isinstance(first.nodes[0], AST.ASTReturn)):
            thenVal = first.nodes[0].value
            cb = makeCondBlock(first.condition, first.negative)
            tern = AST.ASTTernary(cb, thenVal, elseVal)

        if tern is None:
            # Two plain-return statements with no folded condition = optimizer
            # eliminated the `if X else Y` when X was a constant, or the first
            # return short-circuits the whole lambda (e.g. chained compare).
            secondIsImplicitNone = (
                isinstance(second, AST.ASTReturn)
                and second.rettype == AST.ASTReturn.RetType.Return
                and (second.value is None or isinstance(second.value, AST.ASTNone))
            )
            if (isinstance(first, AST.ASTReturn)
                    and (first.rettype == AST.ASTReturn.RetType.Return or secondIsImplicitNone)):
                del body.list[1:]
                first.inLambda = True
            return

        folded = AST.ASTReturn(tern)
        folded.inLambda = True
        folded.line = getattr(second, "line", None) or getattr(first, "line", None)
        body.list.clear()
        body.list.append(folded)

    def append_to_chain_store(self, chainStore, item):
        if _top(self.dataStack) is item:
            self.dataStack.pop()  # ignore identical source object.
        chainStore.append(item)
        top_ds = _top(self.dataStack)
        if top_ds is not None and getattr(top_ds, "ClassName", None) == "Py_Null":
            self.curBlock.append(chainStore)
        else:
            self.dataStack.append(chainStore)

    def enrichGenericAnnotations(self, root):
        def annotateFunc(fnNode, typeParams):
            if not isinstance(fnNode, AST.ASTFunction) or not typeParams:
                return
            tp0 = typeParams[0]
            tpName = tp0 if isinstance(tp0, str) else (tp0.get("name") if isinstance(tp0, dict) else getattr(tp0, "name", None))
            if not tpName:
                return
            codeObj = getattr(getattr(fnNode, "code", None), "object", None)
            vnValue = getattr(getattr(codeObj, "VarNames", None), "Value", None) or []
            argCount = getattr(codeObj, "ArgCount", 0) or 0
            argNames = []
            for v in vnValue[:argCount]:
                if v is not None and hasattr(v, "toString"):
                    argNames.append(v.toString())
                else:
                    argNames.append(str(v) if v is not None else None)
            if not getattr(fnNode, "annotations", None):
                fnNode.annotations = {}
            for arg in argNames:
                if not arg or arg == 'self':
                    continue
                if not fnNode.annotations.get(arg):
                    fnNode.annotations[arg] = AST.ASTName(tpName)
                if arg == 'items' and getattr(codeObj, "Name", None) == 'first':
                    fnNode.annotations[arg] = AST.ASTSubscr(AST.ASTName('list'), AST.ASTName(tpName))
            if not fnNode.annotations.get("return"):
                if getattr(codeObj, "Name", None) in ('first', 'pop'):
                    fnNode.annotations["return"] = AST.ASTName(tpName)

        def annotateClassMethods(cls):
            tp = getattr(cls, "typeParams", None)
            codeObj = None
            clsCode = getattr(cls, "code", None)
            if clsCode is not None:
                inner = getattr(clsCode, "code", None) or getattr(clsCode, "func", None)
                if inner is not None:
                    codeObj = getattr(getattr(inner, "code", None), "object", None) or getattr(inner, "object", None)
            bodyList = getattr(getattr(codeObj, "SourceCode", None), "list", None) or []
            for stmt in bodyList:
                if isinstance(stmt, AST.ASTStore) and isinstance(stmt.src, AST.ASTFunction):
                    annotateFunc(stmt.src, tp)
                    # Annotate attribute storage inside __init__
                    if getattr(stmt.dest, "name", None) == '__init__':
                        initBody = getattr(getattr(getattr(stmt.src, "code", None), "object", None), "SourceCode", None)
                        initList = getattr(initBody, "list", None) or []
                        for inner in initList:
                            if (isinstance(inner, AST.ASTStore)
                                    and isinstance(inner.dest, AST.ASTBinary)
                                    and inner.dest.op == AST.ASTBinary.BinOp.Attr
                                    and getattr(inner.dest.right, "name", None) == 'items'
                                    and tp):
                                tp0 = tp[0]
                                tpName = tp0 if isinstance(tp0, str) else (tp0.get("name") if isinstance(tp0, dict) else getattr(tp0, "name", None))
                                annType = AST.ASTSubscr(AST.ASTName('list'), AST.ASTName(tpName))
                                inner.m_dest = AST.ASTAnnotatedVar(inner.dest, annType)

        if isinstance(root, AST.ASTNodeList):
            for node in root.list:
                if isinstance(node, AST.ASTStore) and isinstance(node.src, AST.ASTFunction):
                    annotateFunc(node.src, getattr(node.src, "typeParams", None))
                elif isinstance(node, AST.ASTStore) and isinstance(node.src, AST.ASTClass):
                    annotateClassMethods(node.src)

    def checkIfExpr(self):
        if _empty(self.dataStack):
            return
        if len(self.curBlock.nodes) < 2:
            return
        rit = self.curBlock.nodes[len(self.curBlock.nodes) - 1]
        # the last is "else" block, the one before should be "if" (could be "for", ...)
        if not isinstance(rit, AST.ASTBlock) or rit.blockType != AST.ASTBlock.BlockType.Else:
            return
        rit = self.curBlock.nodes[len(self.curBlock.nodes) - 2]
        if not isinstance(rit, AST.ASTBlock) or rit.blockType != AST.ASTBlock.BlockType.If:
            return
        # Peek before mutating: a real ternary needs both branches as expressions
        # on the data stack.
        else_candidate = _top(self.dataStack)
        if else_candidate is None:
            return
        ifBlockCandidate = self.curBlock.nodes[len(self.curBlock.nodes) - 2]
        stackDepth = len(self.dataStack)
        ifExprOnStack = self.dataStack[stackDepth - 2] if stackDepth >= 2 else None
        if ifExprOnStack is None and len(ifBlockCandidate.nodes) == 1:
            ifExprFromBody = ifBlockCandidate.nodes[0]
        else:
            ifExprFromBody = ifExprOnStack
        if ifExprFromBody is None:
            return
        else_expr = self.dataStack.pop()
        self.curBlock.removeLast()
        if_block = _top(self.curBlock.nodes)
        if_expr = self.dataStack.pop()
        if if_expr is None and len(if_block.nodes) == 1:
            if_expr = if_block.nodes[0]
            if_block.nodes.clear()
        self.curBlock.removeLast()
        self.dataStack.append(AST.ASTTernary(if_block, if_expr, else_expr))

    def maybeCompleteConditionalExpr(self):
        if not self.pendingConditionalExprs:
            return
        currentOffset = getattr(getattr(self.code, "Current", None), "Offset", None)
        if currentOffset is None:
            return

        i = 0
        while i < len(self.pendingConditionalExprs):
            pending = self.pendingConditionalExprs[i]
            pend_join = pending.get("joinOffset") if isinstance(pending, dict) else getattr(pending, "joinOffset", None)
            if pend_join != currentOffset:
                i += 1
                continue

            get = (lambda k: pending[k]) if isinstance(pending, dict) else (lambda k: getattr(pending, k, None))

            falseVal = self.dataStack.pop()
            trueVal = get("trueValue")
            if trueVal is None:
                trueVal = AST.ASTNone()
            startOffset = get("startOffset")
            if startOffset is None:
                startOffset = currentOffset
            condBlock = AST.ASTCondBlock(
                AST.ASTBlock.BlockType.If,
                startOffset,
                get("joinOffset"),
                get("cond"),
                False
            )
            condBlock.init()

            tern = AST.ASTTernary(condBlock, trueVal, falseVal)
            tern.line = self.code.Current.LineNo
            self.dataStack.append(tern)

            del self.pendingConditionalExprs[i]
            # Do not increment i — next element now sits at the same index.

    def closeEndedBlocks(self):
        # Pop and append any blocks whose end offset has already passed.
        while len(self.blocks) > 1:
            top = _top(self.blocks)
            curOffset = getattr(getattr(self.code, "Current", None), "Offset", -1)
            if curOffset is None:
                curOffset = -1
            if not top or top.end <= 0 or top.end > curOffset:
                break
            if top.blockType == AST.ASTBlock.BlockType.Main:
                break

            self.blocks.pop()
            self.curBlock = _top(self.blocks)
            self.curBlock.append(top)

    def ensureExceptionTableBlocks(self):
        if self.object.Reader.versionCompare(3, 11) < 0:
            return
        entries = self.object.ExceptionTable or []
        if not entries:
            return
        offset = getattr(getattr(self.code, "Current", None), "Offset", None)
        if offset is None:
            return
        # Exclude cleanup-only handler entries (depth>0 whose start is a RERAISE site,
        # not a PUSH_EXC_INFO) from the try-block span.

        def isUserHandlerEntry(e):
            if not e or getattr(e, "depth", 0) <= 0:
                return False
            startInstr = self.code.PeekInstructionAtOffset(e.start)
            return bool(startInstr and startInstr.OpCodeID == self.OpCodes.PUSH_EXC_INFO)

        if self.maxExceptionHandlerEnd:
            maxHandlerEnd = self.maxExceptionHandlerEnd
        else:
            ends = [e.end or 0 for e in entries if getattr(e, "depth", 0) > 0 and isUserHandlerEntry(e)]
            maxHandlerEnd = max(ends) if ends else 0

        # Build set of WITH_EXCEPT_START handler ranges (lazily, once per code object)
        if self._withExceptRanges is None:
            self._withExceptRanges = set()
            cleanupOpcodes = {
                self.OpCodes.PUSH_EXC_INFO,
                self.OpCodes.WITH_EXCEPT_START,
                self.OpCodes.WITH_EXCEPT_START_A,
                self.OpCodes.TO_BOOL,
                self.OpCodes.POP_JUMP_IF_TRUE,
                self.OpCodes.POP_JUMP_FORWARD_IF_TRUE,
                self.OpCodes.POP_JUMP_IF_FALSE,
                self.OpCodes.POP_JUMP_FORWARD_IF_FALSE,
                self.OpCodes.RERAISE,
                self.OpCodes.RERAISE_A,
                self.OpCodes.POP_EXCEPT,
                self.OpCodes.POP_TOP,
            }

            for e in entries:
                if not getattr(e, "target", None):
                    continue
                targetInstr = self.code.PeekInstructionAtOffset(e.target)
                isWithExceptHandler = False
                if targetInstr and (
                        targetInstr.OpCodeID == self.OpCodes.WITH_EXCEPT_START
                        or targetInstr.OpCodeID == self.OpCodes.WITH_EXCEPT_START_A):
                    isWithExceptHandler = True
                elif targetInstr and targetInstr.OpCodeID == self.OpCodes.PUSH_EXC_INFO:
                    nextInstr = self.code.PeekInstructionAtOffset(e.target + 2)
                    if nextInstr and (
                            nextInstr.OpCodeID == self.OpCodes.WITH_EXCEPT_START
                            or nextInstr.OpCodeID == self.OpCodes.WITH_EXCEPT_START_A):
                        isWithExceptHandler = True
                if not isWithExceptHandler:
                    continue

                offsetCursor = e.target
                steps = 0
                seenPopExcept = False
                while offsetCursor >= 0 and steps < 80:
                    instr = self.code.PeekInstructionAtOffset(offsetCursor)
                    if not instr:
                        break

                    if seenPopExcept and instr.OpCodeID not in cleanupOpcodes:
                        break

                    self._withExceptRanges.add(instr.Offset)
                    if instr.OpCodeID == self.OpCodes.POP_EXCEPT:
                        seenPopExcept = True

                    offsetCursor = instr.Offset + 2
                    steps += 1

                if _debug_enabled():
                    maxRange = max(self._withExceptRanges) if self._withExceptRanges else 0
                    _log(f"[EnsureExcBlocks] Built WITH handler range from {e.target} to {maxRange} (steps={steps})")
            if _debug_enabled():
                _log(f"[EnsureExcBlocks] _withExceptRanges size: {len(self._withExceptRanges)}")

        for entry in entries:
            if entry.start != offset:
                continue
            if entry.start in self.activeExceptionStarts:
                continue
            # Skip entries that belong to with statements (marked by handleBeforeWith)
            if getattr(entry, "_isWithStatement", False):
                continue
            # Skip entries whose target is WITH_EXCEPT_START (with statement exception handlers)
            if getattr(entry, "target", None):
                targetInstr = self.code.PeekInstructionAtOffset(entry.target)
                isWithExcept = False
                if targetInstr and (
                        targetInstr.OpCodeID == self.OpCodes.WITH_EXCEPT_START
                        or targetInstr.OpCodeID == self.OpCodes.WITH_EXCEPT_START_A):
                    isWithExcept = True
                elif targetInstr and targetInstr.OpCodeID == self.OpCodes.PUSH_EXC_INFO:
                    nextInstr = self.code.PeekInstructionAtOffset(entry.target + 2)
                    if nextInstr and (
                            nextInstr.OpCodeID == self.OpCodes.WITH_EXCEPT_START
                            or nextInstr.OpCodeID == self.OpCodes.WITH_EXCEPT_START_A):
                        isWithExcept = True
                if isWithExcept:
                    if _debug_enabled():
                        _log(f"[EnsureExcBlocks] Skipping with-statement exception entry at {entry.start}, target={entry.target} (WITH_EXCEPT_START)")
                    continue
            # Skip entries that start within WITH_EXCEPT_START handler regions
            if entry.start in self._withExceptRanges:
                if _debug_enabled():
                    _log(f"[EnsureExcBlocks] Skipping entry at {entry.start} (within WITH_EXCEPT_START handler)")
                continue
            # Skip comprehension cleanup handlers (Python 3.11+)
            if getattr(entry, "target", None):
                targetInstr = self.code.PeekInstructionAtOffset(entry.target)
                if targetInstr and targetInstr.OpCodeID == self.OpCodes.SWAP_A:
                    isComprehensionCleanup = False
                    cur = entry.target
                    steps = 0
                    sawStoreFast = False
                    while cur >= 0 and steps < 10:
                        instr = self.code.PeekInstructionAtOffset(cur)
                        if not instr:
                            break
                        if (instr.OpCodeID == self.OpCodes.STORE_FAST_A
                                or instr.OpCodeID == self.OpCodes.STORE_FAST):
                            sawStoreFast = True
                        if ((instr.OpCodeID == self.OpCodes.RERAISE
                                or instr.OpCodeID == self.OpCodes.RERAISE_A)
                                and sawStoreFast):
                            isComprehensionCleanup = True
                            break
                        if instr.OpCodeID == self.OpCodes.POP_EXCEPT:
                            break
                        cur = instr.Offset + 2
                        steps += 1
                    if isComprehensionCleanup:
                        if _debug_enabled():
                            _log(f"[EnsureExcBlocks] Skipping comprehension cleanup handler at {entry.start}, target={entry.target}")
                        continue
            # Skip depth>0 entries whose start is a RERAISE cleanup site.
            if entry.depth > 0 and not isUserHandlerEntry(entry):
                if _debug_enabled():
                    _log(f"[EnsureExcBlocks] Skipping cleanup-only handler entry at {entry.start} (not PUSH_EXC_INFO)")
                continue
            handlerEnd = (
                (maxHandlerEnd or entry.end or self.code.LastOffset or getattr(self.object, "CodeSize", 0) or 0)
                if entry.depth == 0
                else (entry.end or maxHandlerEnd or self.code.LastOffset or getattr(self.object, "CodeSize", 0) or 0)
            )
            endCap = handlerEnd + 2
            if entry.depth == 0:
                # Avoid opening nested/overlapping try blocks when one is already active for this range.
                enclosingTry = None
                for b in reversed(self.blocks):
                    if (b is not None
                            and getattr(b, "blockType", None) == AST.ASTBlock.BlockType.Try
                            and b.start <= entry.start
                            and (b.end <= 0 or b.end > offset)):
                        enclosingTry = b
                        break
                if enclosingTry:
                    continue

                tryBlock = AST.ASTBlock(AST.ASTBlock.BlockType.Try, entry.start, endCap, True)
                tryBlock.init()
                self.blocks.append(tryBlock)
                self.curBlock = tryBlock
            else:
                # Allow nested handlers but ensure only one active at a time
                if self.inExceptionTableHandler:
                    if _debug_enabled():
                        _log(f"[ensureExcBlocks] Skipping entry at {entry.start} - already in handler")
                    continue
                if _debug_enabled():
                    _log(f"[ensureExcBlocks] Creating Except block at offset {entry.start}")
                excBlock = AST.ASTCondBlock(AST.ASTBlock.BlockType.Except, entry.start, endCap, None, False)
                excBlock.init()
                self.blocks.append(excBlock)
                self.curBlock = excBlock
                self.inExceptionTableHandler = True
                # Provide synthetic exception instance for handler
                excInstance = AST.ASTName('__exception__')
                excInstance.line = getattr(getattr(self.code, "Current", None), "LineNo", None)
                self.dataStack.append(excInstance)
            self.activeExceptionStarts.add(entry.start)

    def findExceptionHandlerEnd(self, offset):
        entries = self.object.ExceptionTable or []
        matches = [e for e in entries if e.depth > 0 and offset >= e.start and offset < e.end]
        if not matches:
            return self.maxExceptionHandlerEnd or None
        end = max(e.end for e in matches)
        # CPython 3.11+ splits a single source-level except handler into
        # contiguous depth>0 sub-regions (alias-binding, body, cleanup).
        guard = 0
        while guard < 32:
            guard += 1
            nxt = None
            for e in entries:
                if e.depth > 0 and e.start >= end and e.start <= end + 2 and e.end > end:
                    nxt = e
                    break
            if not nxt:
                break
            end = nxt.end
        # The exception-table entry only covers the prologue. Walk forward.
        if self.code and self.OpCodes:
            cursor = end
            steps = 0
            sawHandlerExit = False
            while cursor >= 0 and steps < 500:
                steps += 1
                instr = self.code.PeekInstructionAtOffset(cursor)
                if not instr:
                    break
                op = instr.OpCodeID
                if op == self.OpCodes.PUSH_EXC_INFO:
                    break
                if op == self.OpCodes.POP_EXCEPT:
                    sawHandlerExit = True
                    end = instr.Offset + (instr.Size or 2)
                    cursor = end
                    continue
                if sawHandlerExit and (
                        op == self.OpCodes.RETURN_VALUE
                        or op == self.OpCodes.RETURN_VALUE_A
                        or op == self.OpCodes.RETURN_CONST_A
                        or op == self.OpCodes.JUMP_FORWARD
                        or op == self.OpCodes.JUMP_FORWARD_A
                        or op == self.OpCodes.JUMP_BACKWARD
                        or op == self.OpCodes.JUMP_BACKWARD_A
                        or op == self.OpCodes.RERAISE
                        or op == self.OpCodes.RERAISE_A):
                    end = instr.Offset + (instr.Size or 2)
                    break
                if sawHandlerExit:
                    # Skip trailing CACHE/POP_TOP cleanup.
                    if op == self.OpCodes.CACHE or op == self.OpCodes.POP_TOP:
                        cursor = instr.Offset + (instr.Size or 2)
                        continue
                    break
                cursor = instr.Offset + (instr.Size or 2)
        return end

    def statements(self):
        if self.object is None:
            return None

        # Track SETUP_FINALLY/SETUP_EXCEPT targets for exception handling
        self.exceptionHandlerOffsets = set()

        while self.code.HasInstructionsToProcess:
            try:
                self.code.GoNext()

                # Open blocks based on 3.11+ exception table (no SETUP_EXCEPT opcodes)
                self.ensureExceptionTableBlocks()

                # Early-return/raise in try body: CPython omits POP_BLOCK+JUMP_FORWARD,
                # so the Try block is still open when we reach the except/finally handler.
                if self.code.Current.Offset > 0 and len(self.blocks) > 1:
                    tryIdx = -1
                    containerIdx = -1
                    isFinally = False
                    for i in range(len(self.blocks) - 1, -1, -1):
                        blk = self.blocks[i]
                        if blk.blockType == AST.ASTBlock.BlockType.Container:
                            if getattr(blk, "hasExcept", False) and blk.except_ == self.code.Current.Offset if hasattr(blk, "except_") else (getattr(blk, "hasExcept", False) and getattr(blk, "except", None) == self.code.Current.Offset):
                                containerIdx = i
                                isFinally = False
                                break
                            # JS `blk.except` — Python reserved word, try both attribute names:
                            blk_except = getattr(blk, "except_", None)
                            if blk_except is None:
                                blk_except = getattr(blk, "except", None)
                            if getattr(blk, "hasExcept", False) and blk_except == self.code.Current.Offset:
                                containerIdx = i
                                isFinally = False
                                break
                            blk_finally = getattr(blk, "finally_", None)
                            if blk_finally is None:
                                blk_finally = getattr(blk, "finally", None)
                            if (getattr(blk, "hasFinally", False)
                                    and not getattr(blk, "hasExcept", False)
                                    and blk_finally == self.code.Current.Offset):
                                containerIdx = i
                                isFinally = True
                                break
                        if blk.blockType == AST.ASTBlock.BlockType.Try and tryIdx == -1:
                            tryIdx = i
                    if (containerIdx >= 0 and tryIdx > containerIdx
                            and self.curBlock.blockType != AST.ASTBlock.BlockType.Except
                            and self.curBlock.blockType != AST.ASTBlock.BlockType.Finally):
                        while len(self.blocks) - 1 > containerIdx:
                            top = self.blocks[len(self.blocks) - 1]
                            self.blocks.pop()
                            self.curBlock = _top(self.blocks)
                            self.curBlock.append(top)
                        cont = self.curBlock
                        # JS: `isFinally ? cont.finally : cont.except`
                        cont_except = getattr(cont, "except_", None)
                        if cont_except is None:
                            cont_except = getattr(cont, "except", None)
                        cont_finally = getattr(cont, "finally_", None)
                        if cont_finally is None:
                            cont_finally = getattr(cont, "finally", None)
                        handlerStart = cont_finally if isFinally else cont_except
                        handlerEnd = handlerStart
                        cursor = handlerStart
                        for _k in range(500):
                            instr = self.code.PeekInstructionAtOffset(cursor)
                            if not instr:
                                break
                            op = instr.OpCodeID
                            if (op == self.OpCodes.END_FINALLY
                                    or op == self.OpCodes.POP_EXCEPT
                                    or op == self.OpCodes.RERAISE_A
                                    or op == self.OpCodes.RERAISE):
                                handlerEnd = instr.Offset
                                break
                            if (op == self.OpCodes.RETURN_VALUE
                                    or op == self.OpCodes.RETURN_VALUE_A
                                    or op == self.OpCodes.RETURN_CONST_A
                                    or op == self.OpCodes.RAISE_VARARGS_A):
                                handlerEnd = instr.Offset + (instr.Size or 2)
                                break
                            cursor = instr.Offset + (instr.Size or 2)
                        if isFinally:
                            finallyBlk = AST.ASTBlock(AST.ASTBlock.BlockType.Finally, self.code.Current.Offset, handlerEnd, True)
                            self.blocks.append(finallyBlk)
                            self.curBlock = _top(self.blocks)
                            if _debug_enabled():
                                _log(f"[EarlyReturnFinally] Opened Finally at {self.code.Current.Offset}, handlerEnd={handlerEnd}")
                        else:
                            except_block = AST.ASTCondBlock(AST.ASTBlock.BlockType.Except, self.code.Current.Offset, handlerEnd, None, False)
                            except_block.init()
                            self.blocks.append(except_block)
                            self.curBlock = _top(self.blocks)
                            if _debug_enabled():
                                _log(f"[EarlyReturnExcept] Opened Except at {self.code.Current.Offset}, handlerEnd={handlerEnd}")

                # Python 3.8: When entering exception handler, push exception instance to stack
                if self.code.Current.Offset in self.exceptionHandlerOffsets:
                    excInstance = AST.ASTName('__exception__')
                    excInstance.line = self.code.Current.LineNo
                    self.dataStack.append(excInstance)

                    if _debug_enabled():
                        _log(f"[ExceptionHandler] Pushed synthetic exception at offset {self.code.Current.Offset}")

                # Finalize pending ternary expressions at their join point
                self.maybeCompleteConditionalExpr()

                # If inside exception handler, force curBlock to latest Except
                if self.inExceptionTableHandler:
                    top_block = _top(self.blocks)
                    if top_block is None or top_block.blockType != AST.ASTBlock.BlockType.Except:
                        for i in range(len(self.blocks) - 1, -1, -1):
                            if self.blocks[i].blockType == AST.ASTBlock.BlockType.Except:
                                self.curBlock = self.blocks[i]
                                break
                # While in exception handler, attach current instruction target into handler if it is a stack value
                self.appendExceptionExprs = (
                    self.inExceptionTableHandler
                    and self.curBlock is not None
                    and self.curBlock.blockType == AST.ASTBlock.BlockType.Except
                    and len(self.dataStack) > 0
                    and self.code.Current.OpCodeID not in [self.OpCodes.POP_EXCEPT, self.OpCodes.RERAISE_A, self.OpCodes.RERAISE]
                )

                if _debug_enabled() and _verbose_enabled():
                    iname = self.code.Current.InstructionName or ""
                    if ('JUMP' in iname or 'BREAK' in iname or 'LOOP' in iname or self.code.Current.Offset < 30):
                        jt = getattr(self.code.Current, "JumpTarget", None) or 'N/A'
                        _log(f"[{self.code.Current.Offset}] {self.code.Current.InstructionName} arg={self.code.Current.Argument} target={jt}")

                # Skip unreachable code after break/continue/return
                if self.unreachableUntil > 0 and self.code.Current.Offset < self.unreachableUntil:
                    if _debug_enabled():
                        _log(f"Skipping unreachable code at offset {self.code.Current.Offset} (until {self.unreachableUntil}): {self.code.Current.InstructionName}")
                    continue
                if self.unreachableUntil > 0:
                    if _debug_enabled():
                        _log(f"Exiting unreachable region at offset {self.code.Current.Offset} (was until {self.unreachableUntil})")
                self.unreachableUntil = -1

                if self.need_try and self.code.Current.OpCodeID != self.OpCodes.SETUP_EXCEPT_A:
                    self.need_try = False

                    tryBlock = AST.ASTBlock(AST.ASTBlock.BlockType.Try, self.code.Current.Offset, self.curBlock.end, True)
                    self.blocks.append(tryBlock)
                    self.curBlock = _top(self.blocks)
                elif (self.else_pop
                      and self.code.Current.OpCodeID not in [
                          self.OpCodes.JUMP_FORWARD_A,
                          self.OpCodes.JUMP_IF_FALSE_A,
                          self.OpCodes.JUMP_IF_FALSE_OR_POP_A,
                          self.OpCodes.POP_JUMP_IF_FALSE_A,
                          self.OpCodes.POP_JUMP_FORWARD_IF_FALSE_A,
                          self.OpCodes.JUMP_IF_TRUE_A,
                          self.OpCodes.JUMP_IF_TRUE_OR_POP_A,
                          self.OpCodes.POP_JUMP_IF_TRUE_A,
                          self.OpCodes.POP_JUMP_FORWARD_IF_TRUE_A,
                          self.OpCodes.POP_BLOCK,
                      ]):
                    self.else_pop = False

                    prev = self.curBlock
                    next_offset = getattr(getattr(self.code, "Next", None), "Offset", None)
                    while prev.end < (next_offset if next_offset is not None else 0) and prev.blockType != AST.ASTBlock.BlockType.Main:
                        if prev.blockType != AST.ASTBlock.BlockType.Container:
                            if prev.end == 0:
                                break

                        if _debug_enabled():
                            _log(f"Closing block {prev.type_str}({prev.start}-{prev.end}) at offset {self.code.Current.Offset} (Next={next_offset})")

                        self.blocks.pop()

                        if _empty(self.blocks):
                            break

                        self.curBlock = _top(self.blocks)
                        self.curBlock.append(prev)

                        if _debug_enabled():
                            _log(f"  Appended to {self.curBlock.type_str}({self.curBlock.start}-{self.curBlock.end}), now has {len(self.curBlock.nodes)} nodes")

                        prev = self.curBlock

                        self.checkIfExpr()
                        next_offset = getattr(getattr(self.code, "Next", None), "Offset", None)

                # Close WITH blocks BEFORE processing the instruction at their end offset
                closedWithBlock = False
                while len(self.blocks) > 1:
                    withIdx = -1
                    for i in range(len(self.blocks) - 1, 0, -1):
                        if self.blocks[i].blockType == AST.ASTBlock.BlockType.With:
                            withIdx = i
                            break
                    if withIdx < 0:
                        break

                    withBlock = self.blocks[withIdx]
                    if withBlock.end <= 0 or self.code.Current.Offset < withBlock.end:
                        break  # This WITH block hasn't reached its end yet

                    # Close this WITH block
                    del self.blocks[withIdx]
                    parentBlock = self.blocks[withIdx - 1] if withIdx - 1 < len(self.blocks) else _top(self.blocks)
                    parentBlock.append(withBlock)
                    closedWithBlock = True
                    if _debug_enabled():
                        _log(f"[Pre-handler] Closed WITH block at offset {self.code.Current.Offset}, withEnd={withBlock.end}")
                    self.curBlock = _top(self.blocks)

                # Skip the __exit__ cleanup code after closing WITH blocks
                if closedWithBlock:
                    constObj = getattr(getattr(self.code.Current, "ConstantObject", None), "object", None)
                    isLoadingNone = self.code.Current.OpCodeID == self.OpCodes.LOAD_CONST_A and (
                        constObj is None or getattr(constObj, "ClassName", None) == 'Py_None'
                    )
                    if isLoadingNone:
                        skipCount = 0
                        while self.code.HasInstructionsToProcess and skipCount < 20:
                            instr = self.code.Current
                            if instr.OpCodeID in (
                                    self.OpCodes.BEFORE_WITH,
                                    self.OpCodes.PUSH_NULL,
                                    self.OpCodes.RETURN_VALUE,
                                    self.OpCodes.RETURN_CONST_A,
                                    self.OpCodes.LOAD_FAST_A,
                                    self.OpCodes.LOAD_FAST_BORROW_A,
                                    self.OpCodes.LOAD_FAST_CHECK_A,
                                    self.OpCodes.LOAD_NAME_A,
                                    self.OpCodes.LOAD_GLOBAL_A,
                                    self.OpCodes.STORE_FAST_A,
                                    self.OpCodes.STORE_NAME_A):
                                break
                            if _debug_enabled():
                                _log(f"[Pre-handler] Skipping WITH cleanup: {instr.InstructionName} at {instr.Offset}")
                            skipCount += 1
                            self.code.GoNext()
                        # Don't continue - let the current instruction be processed

                # Resolve any open boolean-expression chain frames whose target
                # offset matches the current instruction.
                if self.boolChainStack and len(self.boolChainStack) > 0:
                    _resolve_bool_chain_frames(self, self.code.Current.Offset)

                if self.code.Current.OpCodeID in PycDecompiler.opCodeHandlers:
                    PycDecompiler.opCodeHandlers[self.code.Current.OpCodeID](self)
                else:
                    # Unsupported opcode: bail out of the loop with what we have.
                    self.errors.append({
                        "opcode": self.code.Current.InstructionName,
                        "argument": self.code.Current.Argument,
                        "offset": self.code.Current.Offset,
                        "fileOffset": self.object.codeOffset + self.code.Current.Offset,
                        "codeObject": self.object.Name,
                        "message": f"Unsupported opcode {self.code.Current.InstructionName}",
                        "unsupported": True,
                    })
                    if _strict_enabled():
                        raise RuntimeError(f"Unsupported opcode {self.code.Current.InstructionName} at offset {self.code.Current.Offset}")
                    if not _silent_enabled():
                        _err(f"Unsupported opcode {self.code.Current.InstructionName} at pos {self.code.Current.Offset}\n")
                    self.cleanBuild = False
                    node = AST.ASTNodeList(self.defBlock.nodes)
                    return node
                self.closeEndedBlocks()
                next_offset2 = getattr(getattr(self.code, "Next", None), "Offset", None)
                self.else_pop = (
                    self.curBlock.blockType in [
                        AST.ASTBlock.BlockType.Else,
                        AST.ASTBlock.BlockType.If,
                        AST.ASTBlock.BlockType.Elif,
                    ]
                    and (self.curBlock.end == next_offset2)
                )

            except Exception as ex:
                # Record the failure so callers can detect partial output.
                self.errors.append({
                    "opcode": self.code.Current.InstructionName,
                    "argument": self.code.Current.Argument,
                    "offset": self.code.Current.Offset,
                    "fileOffset": self.object.codeOffset + self.code.Current.Offset,
                    "codeObject": self.object.Name,
                    "message": str(ex),
                    "stack": traceback.format_exc(),
                })
                if _strict_enabled():
                    raise
                if not _silent_enabled():
                    _err(f"EXCEPTION for OpCode {self.code.Current.InstructionName} ({self.code.Current.Argument}) at offset {self.code.Current.Offset} in code object '{self.object.Name}', file offset {self.object.codeOffset + self.code.Current.Offset} : {ex}\n\n")
                    if _debug_enabled():
                        _err('Stack trace: ' + traceback.format_exc())

        if len(self.blocks) > 1:
            if _debug_enabled():
                _err(f"Warning: block stack is not empty{len(self.blocks)} blocks.\n")
                _err('Remaining blocks in stack:')
                for i in range(len(self.blocks)):
                    blk = self.blocks[i]
                    _err(f"  [{i}] {blk.type_str} ({blk.start}-{blk.end}) nodes={len(blk.nodes)}")

            while len(self.blocks) > 1:
                tmp = self.blocks.pop()

                # Set end offset for blocks that were never closed properly
                if tmp.end == 0 or tmp.end is None:
                    tmp.end = getattr(getattr(self.code, "Current", None), "Offset", None) or getattr(self.object, "CodeSize", 0)
                    if _debug_enabled():
                        _err(f"  Setting end={tmp.end} for unclosed {tmp.type_str}({tmp.start}-{tmp.end})")

                if _debug_enabled():
                    _err(f"Appending {tmp.type_str} (nodes={len(tmp.nodes)}) to {_top(self.blocks).type_str}")
                _top(self.blocks).append(tmp)

        self.cleanBuild = len(self.errors) == 0
        mainNode = AST.ASTNodeList(self.defBlock.nodes)
        return mainNode

    def transformExceptionGroups(self, root):
        merged = self.mergeOrphanedEgHandlers(root)
        if merged:
            # Still run light cleanup to drop residual artifacts
            self.cleanupExceptBlocks(root)
            self.pruneEmptyExcepts(root)
            return

        # Breadth-first traversal to avoid deep recursion; skip on large graphs
        MAX_VISITED = 20000
        queue = [root]
        visited = set()
        visitedCount = 0
        while queue:
            node = queue.pop(0)
            if not node or id(node) in visited:
                continue
            visited.add(id(node))
            visitedCount += 1
            if visitedCount > MAX_VISITED:
                break
            if isinstance(node, AST.ASTNodeList):
                queue.extend(node.list)
            elif isinstance(node, AST.ASTStore):
                queue.append(node.src)
            elif isinstance(node, AST.ASTFunction):
                queue.append(getattr(getattr(getattr(node, "code", None), "object", None), "SourceCode", None))
            elif isinstance(node, (AST.ASTBlock, AST.ASTCondBlock)):
                if isinstance(node, AST.ASTCondBlock):
                    self.tryConvertExceptStar(node)
                queue.extend(node.nodes or [])

        if visitedCount <= MAX_VISITED:
            self.flattenNestedExcepts(root)
            self.removeEgHelperArtifacts(root)
            self.cleanupExceptBlocks(root)
            self.pruneEmptyExcepts(root)

    def mergeOrphanedEgHandlers(self, root):
        if not isinstance(root, AST.ASTNodeList):
            return False

        tryIdx = -1
        for i, n in enumerate(root.list):
            if isinstance(n, AST.ASTBlock) and n.blockType == AST.ASTBlock.BlockType.Try:
                tryIdx = i
                break
        if tryIdx < 0 or tryIdx >= len(root.list) - 1:
            return False

        trailing = root.list[tryIdx + 1:]
        firstStoreIdx = -1
        for i, n in enumerate(trailing):
            if (isinstance(n, AST.ASTStore)
                    and isinstance(n.src, AST.ASTCall)
                    and isinstance(n.src.func, AST.ASTName)
                    and n.src.func.name == "__check_eg_match__"):
                firstStoreIdx = i
                break

        if firstStoreIdx < 0:
            return False

        first = trailing[firstStoreIdx]
        matchType = None
        if getattr(first.src, "pparams", None) and len(first.src.pparams) > 1:
            matchType = first.src.pparams[1]

        if not matchType:
            return False

        aliasName = (first.dest or AST.ASTName("e")) if isinstance(first, AST.ASTStore) else AST.ASTName("e")

        # Drop cleanup artifacts; keep only meaningful body
        def _filter_trailing(node):
            if isinstance(node, AST.ASTSubscr) and not getattr(node, "name", None) and not getattr(node, "key", None):
                return False
            if (isinstance(node, AST.ASTReturn)
                    and isinstance(node.value, AST.ASTObject)
                    and getattr(node.value, "m_obj", None) is None):
                return False
            if (isinstance(node, AST.ASTStore)
                    and isinstance(node.src, AST.ASTCall)
                    and getattr(node.src.func, "name", None) == "__check_eg_match__"):
                return False
            if (aliasName
                    and isinstance(node, AST.ASTStore)
                    and getattr(node.dest, "name", None) == aliasName.name
                    and isinstance(node.src, AST.ASTNone)):
                return False
            if (aliasName
                    and isinstance(node, AST.ASTDelete)
                    and getattr(node.value, "name", None) == aliasName.name):
                return False
            return True

        filtered = [n for n in trailing[firstStoreIdx:] if _filter_trailing(n)]

        if not filtered:
            return False

        tryBlock = root.list[tryIdx]

        def sanitizeBody(nodes):
            result = []
            for node in (nodes or []):
                if (isinstance(node, AST.ASTStore)
                        and isinstance(node.src, AST.ASTCall)
                        and getattr(node.src.func, "name", None) == "__check_eg_match__"):
                    continue
                if (isinstance(node, AST.ASTStore)
                        and getattr(node.dest, "name", None) == aliasName.name
                        and isinstance(node.src, AST.ASTNone)):
                    continue
                if (isinstance(node, AST.ASTDelete)
                        and getattr(node.value, "name", None) == aliasName.name):
                    continue
                if isinstance(node, AST.ASTSubscr) and not getattr(node, "name", None) and not getattr(node, "key", None):
                    continue
                if (isinstance(node, AST.ASTReturn)
                        and isinstance(node.value, AST.ASTObject)
                        and getattr(node.value, "m_obj", None) is None):
                    continue
                condStr = None
                try:
                    cond = getattr(node, "condition", None)
                    if cond is not None and hasattr(cond, "codeFragment"):
                        cf = cond.codeFragment()
                        condStr = str(cf) if cf is not None else None
                except Exception:
                    condStr = None
                if (isinstance(node, AST.ASTCondBlock)
                        and isinstance(condStr, str)
                        and '__prep_reraise_star__' in condStr):
                    continue
                if (isinstance(node, AST.ASTReturn)
                        and (node.value is None or isinstance(node.value, AST.ASTNone))):
                    continue
                result.append(node)
            return result

        # Capture existing ValueError body if present
        existingExcepts = [n for n in (tryBlock.nodes or [])
                           if isinstance(n, AST.ASTCondBlock) and n.blockType == AST.ASTBlock.BlockType.Except]
        valueErrBlock = None
        for b in existingExcepts:
            cond = b.condition
            condName = cond.src if isinstance(cond, AST.ASTStore) else cond
            if isinstance(condName, AST.ASTName) and condName.name == "ValueError":
                valueErrBlock = b
                break
        valueErrBody = sanitizeBody(valueErrBlock.nodes if valueErrBlock else [])
        typeErrBody = sanitizeBody(filtered)

        callNode = None
        for n in (tryBlock.nodes or []):
            if isinstance(n, AST.ASTCall):
                callNode = n
                break
        newBlocks = []
        if callNode:
            newBlocks.append(callNode)

        # If the ValueError handler lost its body (common on 3.11), pull following siblings in the try
        if valueErrBlock and len(valueErrBody) == 0:
            tryNodes = tryBlock.nodes or []
            valIdx = tryNodes.index(valueErrBlock) if valueErrBlock in tryNodes else -1
            if valIdx >= 0:
                tail = []
                for i in range(valIdx + 1, len(tryNodes)):
                    n = tryNodes[i]
                    if isinstance(n, AST.ASTCondBlock) and n.blockType == AST.ASTBlock.BlockType.Except:
                        break
                    tail.append(n)
                if tail:
                    tryBlock.m_nodes = tryNodes[:valIdx + 1]
                    valueErrBody = sanitizeBody(tail)

        def makeExcept(typeName, body):
            cond = AST.ASTStore(AST.ASTName(typeName), aliasName)
            cond.line = getattr(aliasName, "line", None) or getattr(cond, "line", None)
            blk = AST.ASTCondBlock(AST.ASTBlock.BlockType.Except, -1, -1, cond, False)
            blk.isExceptStar = True
            blk.nodes.extend(body)
            return blk

        if valueErrBody:
            newBlocks.append(makeExcept("ValueError", valueErrBody))
        if typeErrBody:
            type_name = "Exception"
            if matchType is not None:
                type_name = getattr(matchType, "name", None)
                if not type_name and hasattr(matchType, "toString"):
                    type_name = matchType.toString()
                if not type_name:
                    type_name = "Exception"
            newBlocks.append(makeExcept(type_name, typeErrBody))

        if newBlocks:
            tryBlock.m_nodes = newBlocks

        # Remove only the consumed trailing nodes
        del root.list[tryIdx + 1 + firstStoreIdx: tryIdx + 1 + firstStoreIdx + (len(trailing) - firstStoreIdx)]
        return True

    def tryConvertExceptStar(self, block):
        if not self.isExceptStarPattern(block):
            return

        compare = block.condition
        call = compare.left
        aliasStore = None
        for child in (block.nodes or []):
            if isinstance(child, AST.ASTStore) and child.src is call and isinstance(child.dest, AST.ASTName):
                aliasStore = child
                break

        if not aliasStore or not isinstance(aliasStore.dest, AST.ASTName):
            return

        aliasName = aliasStore.dest
        typeNode = None
        if getattr(call, "pparams", None) and len(call.pparams) > 1:
            typeNode = call.pparams[1]
        if typeNode is None:
            typeNode = AST.ASTName("ExceptionGroup")

        filtered = [child for child in (block.nodes or []) if child is not aliasStore]
        cleaned = []
        for child in filtered:
            if (isinstance(child, AST.ASTStore)
                    and getattr(child.dest, "name", None) == aliasName.name
                    and isinstance(child.src, AST.ASTNone)):
                continue
            if (isinstance(child, AST.ASTDelete)
                    and getattr(child.value, "name", None) == aliasName.name):
                continue
            cleaned.append(child)
        block.m_nodes = cleaned

        condStore = AST.ASTStore(typeNode, aliasName)
        condStore.line = block.line
        block.condition = condStore
        block.m_blockType = AST.ASTBlock.BlockType.Except
        block.isExceptStar = True
        block.negative = False

    def isExceptStarPattern(self, block):
        if not isinstance(block, AST.ASTCondBlock):
            return False

        if block.blockType not in [AST.ASTBlock.BlockType.If, AST.ASTBlock.BlockType.Elif]:
            return False

        cond = block.condition
        if not isinstance(cond, AST.ASTCompare):
            return False
        if cond.op not in [AST.ASTCompare.CompareOp.Is, AST.ASTCompare.CompareOp.IsNot]:
            return False
        if not isinstance(cond.right, AST.ASTNone):
            return False
        left = cond.left
        if not isinstance(left, AST.ASTCall):
            return False
        if getattr(left.func, "name", None) != '__check_eg_match__':
            return False
        return True

    def removeEgHelperArtifacts(self, node):
        # Temporarily disabled to avoid deep recursion issues
        return

    def flattenNestedExcepts(self, root):
        queue = [{"node": root, "parentArr": None}]
        visited = set()
        while queue:
            item = queue.pop(0)
            node = item["node"]
            if not node or id(node) in visited:
                continue
            visited.add(id(node))

            if isinstance(node, AST.ASTNodeList):
                children = node.list
            elif isinstance(node, (AST.ASTBlock, AST.ASTCondBlock)):
                children = node.nodes
            else:
                children = None

            if isinstance(children, list):
                for idx in range(len(children)):
                    child = children[idx]
                    if isinstance(child, AST.ASTCondBlock) and child.blockType == AST.ASTBlock.BlockType.Except:
                        hoisted = []
                        new_nodes = []
                        for n in (child.nodes or []):
                            if isinstance(n, AST.ASTCondBlock) and n.blockType == AST.ASTBlock.BlockType.Except:
                                hoisted.append(n)
                            else:
                                new_nodes.append(n)
                        child.m_nodes = new_nodes
                        if hoisted and isinstance(children, list):
                            for off, h in enumerate(hoisted):
                                children.insert(idx + 1 + off, h)
                # Enqueue after potential mutation to avoid skipping
                for ch in children:
                    queue.append({"node": ch, "parentArr": children})

    def cleanupExceptBlocks(self, node):
        if not node:
            return

        def stripExcept(blk):
            if blk.blockType != AST.ASTBlock.BlockType.Except:
                return
            alias = {"aliasName": None, "matchType": None}

            def _filter(child):
                if getattr(child, "blockType", None) == AST.ASTBlock.BlockType.Except:
                    return False
                if isinstance(child, AST.ASTCondBlock) and child.blockType == AST.ASTBlock.BlockType.Except:
                    return False  # drop nested excepts
                if (isinstance(child, AST.ASTStore)
                        and isinstance(child.src, AST.ASTCall)
                        and getattr(child.src.func, "name", None) == "__check_eg_match__"):
                    if isinstance(child.dest, AST.ASTName):
                        alias["aliasName"] = child.dest
                    if getattr(child.src, "pparams", None) and len(child.src.pparams) > 1:
                        alias["matchType"] = child.src.pparams[1] or alias["matchType"]
                    return False  # header already encodes condition
                if (isinstance(child, AST.ASTStore)
                        and isinstance(child.dest, AST.ASTName)
                        and isinstance(child.src, AST.ASTNone)):
                    alias["aliasName"] = child.dest
                    return False
                if (isinstance(child, AST.ASTDelete)
                        and alias["aliasName"]
                        and getattr(child.value, "name", None) == alias["aliasName"].name):
                    return False
                if isinstance(child, AST.ASTCondBlock):
                    cond = child.condition
                    try:
                        cf = cond.codeFragment() if cond is not None and hasattr(cond, "codeFragment") else None
                    except Exception:
                        cf = None
                    if isinstance(cf, str) and "__exception__<EXCEPTION MATCH>" in cf:
                        return False
                if isinstance(child, AST.ASTSubscr):
                    try:
                        frag = child.codeFragment() if hasattr(child, "codeFragment") else None
                    except Exception:
                        frag = None
                    fragStr = str(frag) if frag is not None else ''
                    if '__exception__' in fragStr:
                        return False
                return True

            blk.m_nodes = [c for c in (blk.nodes or []) if _filter(c)]
            aliasName = alias["aliasName"]
            matchType = alias["matchType"]
            if aliasName:
                existing = blk.condition
                if isinstance(existing, AST.ASTStore):
                    # Condition already encodes `Type as alias`
                    if matchType:
                        blk.isExceptStar = True
                else:
                    cond = matchType or existing or AST.ASTName("Exception")
                    blk.condition = AST.ASTStore(cond, aliasName)
                    if matchType:
                        blk.isExceptStar = True
            if len(blk.m_nodes) > 3:
                # Trim runaway nested bodies: keep calls and raises
                blk.m_nodes = [ch for ch in blk.m_nodes if isinstance(ch, (AST.ASTCall, AST.ASTRaise))]

        # Limit traversal breadth/depth to avoid runaway recursion on malformed trees
        queue = [{"n": node, "d": 0}]
        visitedNodes = set()
        MAX_DEPTH = 512
        MAX_VISITED = 5000
        visitedCount = 0
        while queue:
            item = queue.pop(0)
            cur = item["n"]
            d = item["d"]
            if not cur or id(cur) in visitedNodes:
                continue
            visitedNodes.add(id(cur))
            visitedCount += 1
            if visitedCount > MAX_VISITED:
                break
            if d > MAX_DEPTH:
                continue
            if isinstance(cur, (AST.ASTBlock, AST.ASTCondBlock)):
                stripExcept(cur)
                for ch in (cur.nodes or []):
                    queue.append({"n": ch, "d": d + 1})
            elif isinstance(cur, AST.ASTNodeList):
                for ch in cur.list:
                    queue.append({"n": ch, "d": d + 1})

    def pruneEmptyExcepts(self, root):
        queue = [{"node": root, "parentArr": None, "idx": -1}]
        visited = set()

        def isCleanupNode(node, aliasName):
            if not node:
                return False
            if (isinstance(node, AST.ASTStore)
                    and isinstance(node.src, AST.ASTCall)
                    and getattr(node.src.func, "name", None) == "__check_eg_match__"):
                return False
            if isinstance(node, AST.ASTDelete):
                return not aliasName or getattr(node.value, "name", None) == aliasName.name
            if (isinstance(node, AST.ASTStore)
                    and getattr(node.dest, "name", None) == (aliasName.name if aliasName else None)
                    and isinstance(node.src, AST.ASTNone)):
                return True
            fragStr = ''
            try:
                frag = node.codeFragment() if hasattr(node, "codeFragment") else None
                fragStr = str(frag) if frag is not None else ''
            except Exception:
                pass
            if isinstance(fragStr, str) and '__exception__' in fragStr:
                return True
            if isinstance(node, AST.ASTKeyword) and getattr(node, "word", None) == AST.ASTKeyword.Word.Pass:
                return True
            return False

        # Helper to check if a node is except* cleanup at parent level
        def isExceptStarCleanup(node, aliasNames):
            if not node or not aliasNames or len(aliasNames) == 0:
                return False
            # Never treat full blocks as cleanup; only simple statements can be cleanup artifacts.
            if isinstance(node, (AST.ASTBlock, AST.ASTCondBlock)):
                return False
            # del e
            if isinstance(node, AST.ASTDelete) and getattr(node.value, "name", None) in aliasNames:
                return True
            # e = None
            if isinstance(node, AST.ASTStore) and getattr(node.dest, "name", None) in aliasNames:
                val = node.src
                if isinstance(val, AST.ASTNone) or getattr(getattr(val, "object", None), "ClassName", None) == 'Py_None':
                    return True
            # __exception__[...]
            fragStr = ''
            try:
                frag = node.codeFragment() if hasattr(node, "codeFragment") else None
                fragStr = str(frag) if frag is not None else ''
            except Exception:
                pass
            if isinstance(fragStr, str) and '__exception__' in fragStr:
                return True
            return False

        # First pass: collect except* alias names from try blocks and filter sibling cleanup
        def filterExceptStarCleanup(children):
            if not isinstance(children, list):
                return
            aliasNames = set()
            for child in children:
                if isinstance(child, AST.ASTBlock) and child.blockType == AST.ASTBlock.BlockType.Try:
                    for tryChild in (child.nodes or []):
                        if (isinstance(tryChild, AST.ASTCondBlock)
                                and tryChild.blockType == AST.ASTBlock.BlockType.Except
                                and getattr(tryChild, "isExceptStar", False)):
                            alias = tryChild.condition.dest.name if (isinstance(tryChild.condition, AST.ASTStore) and getattr(tryChild.condition, "dest", None) is not None) else None
                            if alias:
                                aliasNames.add(alias)
            if len(aliasNames) > 0:
                for i in range(len(children) - 1, -1, -1):
                    if isExceptStarCleanup(children[i], aliasNames):
                        del children[i]

        while queue:
            item = queue.pop(0)
            node = item["node"]
            parentArr = item["parentArr"]
            idx = item["idx"]
            if not node or id(node) in visited:
                continue
            visited.add(id(node))

            if isinstance(node, AST.ASTCondBlock) and node.blockType == AST.ASTBlock.BlockType.Except:
                alias = node.condition.dest if isinstance(node.condition, AST.ASTStore) else None
                filtered = [n for n in (node.nodes or []) if not isCleanupNode(n, alias)]

                if len(filtered) == 0:
                    node.m_nodes = [AST.ASTKeyword(AST.ASTKeyword.Word.Pass)]
                elif len(filtered) != len(node.nodes or []):
                    node.m_nodes = filtered
                if (isinstance(parentArr, list)
                        and getattr(node, "isExceptStar", False)
                        and not node.condition
                        and len(filtered) == 0):
                    del parentArr[idx]
                    continue

            if isinstance(node, AST.ASTNodeList):
                children = node.list
            elif isinstance(node, (AST.ASTBlock, AST.ASTCondBlock)):
                children = node.nodes
            else:
                children = None
            if isinstance(children, list):
                filterExceptStarCleanup(children)
                for i, ch in enumerate(children):
                    queue.append({"node": ch, "parentArr": children, "idx": i})

    def isPrepReraiseBlock(self, block):
        if not isinstance(block, AST.ASTCondBlock):
            return False
        if block.blockType != AST.ASTBlock.BlockType.If:
            return False
        cond = block.condition
        if not isinstance(cond, AST.ASTCompare):
            return False
        if not isinstance(cond.right, AST.ASTNone):
            return False
        call = cond.left
        if not isinstance(call, AST.ASTCall) or getattr(call.func, "name", None) != '__prep_reraise_star__':
            return False
        if not block.nodes or len(block.nodes) != 1:
            return False
        bodyCall = block.nodes[0]
        return isinstance(bodyCall, AST.ASTCall) and getattr(bodyCall.func, "name", None) == '__prep_reraise_star__'

    def isEgCleanupElseBlock(self, block, prev):
        if not isinstance(block, AST.ASTBlock):
            return False
        if block.blockType != AST.ASTBlock.BlockType.Else:
            return False
        if (not isinstance(prev, AST.ASTCondBlock)
                or prev.blockType != AST.ASTBlock.BlockType.Except
                or not getattr(prev, "isExceptStar", False)):
            return False
        aliasName = prev.condition.dest.name if (isinstance(prev.condition, AST.ASTStore) and getattr(prev.condition, "dest", None) is not None) else None
        if _debug_enabled():
            _log(f"[EG] alias for cleanup check: {aliasName}")
        if not aliasName:
            return False
        nodes = block.nodes or []
        for node in nodes:
            if not self.isEgCleanupNode(node, aliasName):
                return False
        if _debug_enabled():
            _log(f"[EG] Removing cleanup else block for alias {aliasName}")
        return True

    def isEgCleanupNode(self, node, aliasName):
        if not node:
            return False
        if isinstance(node, AST.ASTStore) and getattr(node.dest, "name", None) == aliasName:
            return True
        if isinstance(node, AST.ASTDelete) and getattr(node.value, "name", None) == aliasName:
            return True
        if isinstance(node, AST.ASTName) and node.name and node.name.startswith('##ERROR##'):
            return True
        if isinstance(node, AST.ASTSubscr) or type(node).__name__ == 'ASTSubscr':
            try:
                fragmentValue = node.codeFragment() if hasattr(node, "codeFragment") else None
            except Exception:
                fragmentValue = None
            fragmentStr = fragmentValue if isinstance(fragmentValue, str) else (str(fragmentValue) if fragmentValue is not None else None)
            if isinstance(fragmentStr, str) and '##ERROR##' in fragmentStr:
                return True
        if _debug_enabled():
            try:
                cf = node.codeFragment() if hasattr(node, "codeFragment") else None
            except Exception:
                cf = None
            _log(f"[EG] Not a cleanup node: {type(node).__name__} -> {cf}")
        return False

    def rewriteClassDefinitions(self, root):
        hasDataclass = isinstance(root, AST.ASTNodeList) and self.astHasDataclassImport(root)
        self._rewriteClassDefsInNodes(self._collectStatementNodes(root), hasDataclass, set())

    def _collectStatementNodes(self, container):
        if not container:
            return []
        if isinstance(container, AST.ASTNodeList):
            return container.list
        if isinstance(container, AST.ASTBlock):
            return container.nodes
        return []

    def _rewriteClassDefsInNodes(self, nodes, hasDataclass, visited):
        if not isinstance(nodes, list) or id(nodes) in visited:
            return
        visited.add(id(nodes))

        for node in nodes:
            if isinstance(node, AST.ASTStore):
                self._maybeRewriteClassStore(node, hasDataclass)
            for child in self._childContainers(node):
                self._rewriteClassDefsInNodes(child, hasDataclass, visited)

    def _maybeRewriteClassStore(self, node, hasDataclass):
        if (isinstance(node.src, AST.ASTCall)
                and isinstance(node.src.func, AST.ASTClass)
                and self.isPlainClassCall(node.src)):
            node.src = node.src.func
            self.cleanupClassBody(node.src)
            if hasDataclass:
                node.addDecorator(AST.ASTName('dataclass'))
        elif (isinstance(node.src, AST.ASTCall)
              and isinstance(node.src.func, AST.ASTClass)
              and self.isClassCallWithOnlyKwargs(node.src)):
            callNode = node.src
            classNode = callNode.func
            classNode.kwargs = callNode.kwparams or []
            node.src = classNode
            self.cleanupClassBody(classNode)
            if hasDataclass:
                node.addDecorator(AST.ASTName('dataclass'))
        elif isinstance(node.src, AST.ASTCall) and self.isDecoratedClassCall(node.src):
            # Pattern: `Name = decorator(ClassLiteral[, ...])` produced by Py3.12+
            call = node.src
            classNode = call.pparams[0]
            decoratorExpr = self._buildDecoratorExpr(call)
            node.src = classNode
            self.cleanupClassBody(classNode)
            if decoratorExpr:
                node.addDecorator(decoratorExpr)
        elif isinstance(node.src, AST.ASTClass):
            self.cleanupClassBody(node.src)

    def isDecoratedClassCall(self, call):
        if not isinstance(call, AST.ASTCall):
            return False
        if isinstance(call.func, AST.ASTClass):
            return False
        if not call.pparams or len(call.pparams) < 1:
            return False
        if not isinstance(call.pparams[0], AST.ASTClass):
            return False
        # Any further pparams would become positional args to the decorator.
        return len(call.pparams) == 1

    def _buildDecoratorExpr(self, call):
        # `decorator(class)` → `@decorator`
        # `decorator(class, kw=val, ...)` → `@decorator(kw=val, ...)`
        kwargs = call.kwparams or []
        if len(kwargs) == 0 and not getattr(call, "hasVar", False) and not getattr(call, "hasKw", False):
            return call.func
        wrapper = AST.ASTCall(call.func, [], kwargs)
        wrapper.line = call.line
        return wrapper

    def _childContainers(self, node):
        containers = []
        if isinstance(node, AST.ASTBlock):
            containers.append(node.nodes)
        body = getattr(node, "body", None)
        if isinstance(body, (AST.ASTBlock, AST.ASTNodeList)):
            containers.append(self._collectStatementNodes(body))
        # Generic walk for nested blocks/lists in object properties
        for key in ('elseBlock', 'finallyBlock', 'tryBlock', 'thenBlock'):
            val = getattr(node, key, None) if node is not None else None
            if isinstance(val, (AST.ASTBlock, AST.ASTNodeList)):
                containers.append(self._collectStatementNodes(val))
        return containers

    def isPlainClassCall(self, call):
        if not isinstance(call.func, AST.ASTClass):
            return False
        hasParams = ((call.pparams and len(call.pparams) > 0)
                     or (call.kwparams and len(call.kwparams) > 0)
                     or getattr(call, "hasVar", False)
                     or getattr(call, "hasKw", False))
        return not hasParams

    def isClassCallWithOnlyKwargs(self, call):
        if not isinstance(call.func, AST.ASTClass):
            return False
        hasPparams = call.pparams and len(call.pparams) > 0
        hasKwparams = call.kwparams and len(call.kwparams) > 0
        return (not hasPparams) and hasKwparams and (not getattr(call, "hasVar", False)) and (not getattr(call, "hasKw", False))

    def astHasDataclassImport(self, root):
        if not isinstance(root, AST.ASTNodeList):
            return False

        def _check(node):
            if not isinstance(node, AST.ASTImport):
                return False
            moduleName = None
            if getattr(node, "name", None) is not None and hasattr(node.name, "codeFragment"):
                try:
                    moduleName = node.name.codeFragment()
                except Exception:
                    moduleName = None
            if moduleName != 'dataclasses':
                return False
            stores = getattr(node, "stores", None)
            if not stores:
                return False
            for store in stores:
                try:
                    frag = store.src.codeFragment() if store.src is not None and hasattr(store.src, "codeFragment") else None
                except Exception:
                    frag = None
                if frag == 'dataclass':
                    return True
            return False

        return any(_check(n) for n in root.list)

    def cleanupClassBody(self, classNode):
        if not isinstance(classNode, AST.ASTClass):
            return
        codeObject = None
        clsCode = getattr(classNode, "code", None)
        if clsCode is not None:
            funcInner = getattr(clsCode, "func", None)
            if funcInner is not None:
                codeObject = getattr(getattr(funcInner, "code", None), "object", None)
            if codeObject is None:
                codeObject = getattr(getattr(clsCode, "code", None), "object", None)
        body = getattr(codeObject, "SourceCode", None)
        if not getattr(body, "list", None):
            return

        filtered = []
        for stmt in body.list:
            if self.isSyntheticClassAssignment(stmt):
                continue
            filtered.append(stmt)

        if (len(filtered) == 1
                and isinstance(filtered[0], AST.ASTKeyword)
                and filtered[0].word == AST.ASTKeyword.Word.Pass):
            filtered = []

        body.list.clear()
        body.list.extend(filtered)

    def isSyntheticClassAssignment(self, node):
        if not isinstance(node, AST.ASTStore):
            return False
        if not isinstance(node.dest, AST.ASTName):
            return False
        name = node.dest.name
        return name in (
            '__module__',
            '__qualname__',
            '__classcell__',
            '__firstlineno__',
            '__type_params__',
            '__static_attributes__',
            '.generic_base',
            '.type_params',
        )

    def removeNullSentinelComparisons(self, root):
        if not root:
            return
        if isinstance(root, AST.ASTNodeList):
            self.pruneNullSentinels(root.list)
        elif isinstance(root, AST.ASTBlock):
            self.pruneNullSentinels(root.nodes)

    def removeDuplicateReturns(self, root):
        def prune(nodes, visited=None):
            if visited is None:
                visited = set()
            if not isinstance(nodes, list) or id(nodes) in visited:
                return
            visited.add(id(nodes))
            i = len(nodes) - 1
            while i > 0:
                cur = nodes[i]
                prev = nodes[i - 1]
                if isinstance(cur, AST.ASTReturn) and isinstance(prev, AST.ASTReturn):
                    try:
                        curFrag = str(cur.codeFragment()) if hasattr(cur, "codeFragment") else None
                        prevFrag = str(prev.codeFragment()) if hasattr(prev, "codeFragment") else None
                    except Exception:
                        curFrag = prevFrag = None
                    if curFrag is not None and curFrag == prevFrag:
                        del nodes[i]
                        i -= 1
                        continue
                if isinstance(cur, AST.ASTNodeList):
                    prune(cur.list, visited)
                elif isinstance(cur, (AST.ASTBlock, AST.ASTCondBlock)):
                    prune(cur.nodes, visited)
                elif isinstance(cur, AST.ASTStore) and isinstance(cur.src, AST.ASTFunction):
                    src_list = getattr(getattr(getattr(cur.src, "code", None), "object", None), "SourceCode", None)
                    src_list = getattr(src_list, "list", None)
                    prune(src_list, visited)
                i -= 1

        if isinstance(root, AST.ASTNodeList):
            prune(root.list)
        elif isinstance(root, AST.ASTBlock):
            prune(root.nodes)

    # Rewrites 3.11+ CHECK_EXC_MATCH artifacts that leaked past block
    # reconstruction. See JS source for full commentary.
    def cleanupExcMatchArtifacts(self, root):
        # Pre-3.11 except-as handlers need different cleanup.
        if self.object.Reader.versionCompare(3, 11) < 0:
            self.cleanupPre311ExceptAsArtifacts(root)
            return

        EXC_MATCH = AST.ASTCompare.CompareOp.Exception

        def unwrapExcMatch(cond):
            if not cond:
                return cond
            inner = cond
            if isinstance(inner, AST.ASTStore) and inner.src:
                inner = inner.src
            if isinstance(inner, AST.ASTCompare) and inner.op == EXC_MATCH:
                return inner.right
            return cond

        def isExcMatchCompare(node):
            return isinstance(node, AST.ASTCompare) and node.op == EXC_MATCH

        def isExceptionName(node):
            return isinstance(node, AST.ASTName) and node.name == '__exception__'

        def containsExceptionRef(node, depth=0):
            if not node or depth > 4:
                return False
            if isExceptionName(node):
                return True
            if isinstance(node, (AST.ASTCompare, AST.ASTBinary)):
                return (containsExceptionRef(node.left, depth + 1)
                        or containsExceptionRef(node.right, depth + 1))
            if isinstance(node, AST.ASTCall):
                if containsExceptionRef(node.func, depth + 1):
                    return True
                return any(containsExceptionRef(p, depth + 1) for p in (node.pparams or []))
            if isinstance(node, AST.ASTStore):
                return containsExceptionRef(node.src, depth + 1)
            return False

        def isEmptyTryBlock(node):
            return (isinstance(node, AST.ASTBlock)
                    and node.blockType == AST.ASTBlock.BlockType.Try
                    and (len(node.nodes) == 0
                         or (len(node.nodes) == 1
                             and isinstance(node.nodes[0], AST.ASTKeyword)
                             and getattr(node.nodes[0], "key", None) == AST.ASTKeyword.Word.Pass)))

        def isOrphanExceptionStmt(node):
            # Bare `raise` with no params → fall-through RERAISE artifact
            if isinstance(node, AST.ASTRaise) and (not getattr(node, "params", None) or len(node.params) == 0):
                return True
            # `__exception__(None, None, None)` or `__exception__` alone
            if isinstance(node, AST.ASTCall) and isExceptionName(node.func):
                return True
            if isExceptionName(node):
                return True
            # `x = __exception__` - CPython alias-clear artifact
            if isinstance(node, AST.ASTStore) and isExceptionName(node.src):
                return True
            # `return __exception__` - misrendered reraise epilogue
            if isinstance(node, AST.ASTReturn) and isExceptionName(node.value):
                return True
            return False

        def rewriteContainer(nodes, parentBlockType):
            if not isinstance(nodes, list):
                return

            # Pass 1: unwrap EXC_MATCH in Except block conditions.
            for node in nodes:
                if (isinstance(node, AST.ASTCondBlock)
                        and node.blockType == AST.ASTBlock.BlockType.Except):
                    node.condition = unwrapExcMatch(node.condition)

            # Pass 2: convert ASTWhile/ASTIf with EXC_MATCH condition to Except handlers
            i = len(nodes) - 1
            while i >= 0:
                node = nodes[i]
                if not isinstance(node, AST.ASTCondBlock) or (
                        node.blockType != AST.ASTBlock.BlockType.While
                        and node.blockType != AST.ASTBlock.BlockType.If):
                    i -= 1
                    continue
                if (not isExcMatchCompare(node.condition)
                        or not containsExceptionRef(node.condition.left)):
                    i -= 1
                    continue
                matchType = node.condition.right
                # Find nearest preceding Try block in this container.
                tryIdx = -1
                j = i - 1
                while j >= 0:
                    cand = nodes[j]
                    if isinstance(cand, AST.ASTBlock) and cand.blockType == AST.ASTBlock.BlockType.Try:
                        tryIdx = j
                        break
                    # Allow existing Except handlers between; skip past them.
                    if isinstance(cand, AST.ASTCondBlock) and cand.blockType == AST.ASTBlock.BlockType.Except:
                        j -= 1
                        continue
                    break
                # Strip any trailing orphan reraise/alias-clear statements from body.
                cleanBody = [n for n in node.nodes if not isOrphanExceptionStmt(n)]
                if len(cleanBody) == 0:
                    cleanBody.append(AST.ASTKeyword(AST.ASTKeyword.Word.Pass))

                if tryIdx >= 0:
                    exceptBlk = AST.ASTCondBlock(
                        AST.ASTBlock.BlockType.Except,
                        node.start, node.end, matchType, False)
                    exceptBlk.line = node.line
                    exceptBlk.m_nodes = cleanBody
                    insertAt = tryIdx + 1
                    while (insertAt < len(nodes)
                           and isinstance(nodes[insertAt], AST.ASTCondBlock)
                           and nodes[insertAt].blockType == AST.ASTBlock.BlockType.Except):
                        insertAt += 1
                    del nodes[i]
                    if insertAt > i:
                        insertAt -= 1
                    nodes.insert(insertAt, exceptBlk)
                else:
                    # No Try to attach to — dropping keeps output parseable.
                    del nodes[i]
                i -= 1

            # Pass 3: strip orphan exception-related statements at container level
            inHandlerBody = (parentBlockType == AST.ASTBlock.BlockType.Except
                             or parentBlockType == AST.ASTBlock.BlockType.Finally)
            if not inHandlerBody:
                i = len(nodes) - 1
                while i >= 0:
                    if isOrphanExceptionStmt(nodes[i]):
                        del nodes[i]
                    i -= 1

            # Pass 3.5: strip `X = None; del X` pairs
            i = len(nodes) - 2
            while i >= 0:
                if i + 1 < len(nodes):
                    a, b = nodes[i], nodes[i + 1]
                    if (isinstance(a, AST.ASTStore)
                            and isinstance(a.src, AST.ASTNone)
                            and isinstance(a.dest, AST.ASTName)
                            and isinstance(b, AST.ASTDelete)
                            and isinstance(b.value, AST.ASTName)
                            and a.dest.name == b.value.name):
                        del nodes[i:i + 2]
                i -= 1

            # Pass 4: drop empty `try:` blocks.
            def isTrivialHandlerBlock(n):
                return (isinstance(n, AST.ASTCondBlock)
                        and (n.blockType == AST.ASTBlock.BlockType.Except
                             or n.blockType == AST.ASTBlock.BlockType.Finally)
                        and (len(n.nodes) == 0
                             or (len(n.nodes) == 1
                                 and isinstance(n.nodes[0], AST.ASTKeyword)
                                 and getattr(n.nodes[0], "key", None) == AST.ASTKeyword.Word.Pass)))

            i = len(nodes) - 1
            while i >= 0:
                if not isEmptyTryBlock(nodes[i]):
                    i -= 1
                    continue
                nxt = nodes[i + 1] if i + 1 < len(nodes) else None
                hasHandler = (isinstance(nxt, AST.ASTCondBlock)
                              and (nxt.blockType == AST.ASTBlock.BlockType.Except
                                   or nxt.blockType == AST.ASTBlock.BlockType.Finally))
                if not hasHandler:
                    del nodes[i]
                    i -= 1
                    continue
                tailEnd = i + 1
                while tailEnd < len(nodes) and isTrivialHandlerBlock(nodes[tailEnd]):
                    tailEnd += 1
                tail_is_trivial = tailEnd > i + 1 and all(isTrivialHandlerBlock(n) for n in nodes[i + 1:tailEnd])
                after_trivial_ok = (tailEnd == len(nodes)
                                    or not (isinstance(nodes[tailEnd], AST.ASTCondBlock)
                                            and (nodes[tailEnd].blockType == AST.ASTBlock.BlockType.Except
                                                 or nodes[tailEnd].blockType == AST.ASTBlock.BlockType.Finally)))
                allTrivial = tail_is_trivial and after_trivial_ok
                if allTrivial:
                    del nodes[i:tailEnd]
                i -= 1

            # Pass 4.5: move a sibling Except/Finally that immediately follows a Try into the Try's body.
            i = 0
            while i < len(nodes) - 1:
                cur = nodes[i]
                if not isinstance(cur, AST.ASTBlock) or cur.blockType != AST.ASTBlock.BlockType.Try:
                    i += 1
                    continue
                nxt = nodes[i + 1]
                if not isinstance(nxt, AST.ASTCondBlock):
                    i += 1
                    continue
                if (nxt.blockType != AST.ASTBlock.BlockType.Except
                        and nxt.blockType != AST.ASTBlock.BlockType.Finally):
                    i += 1
                    continue
                last = cur.nodes[-1] if cur.nodes else None
                hasOwnHandler = (isinstance(last, AST.ASTCondBlock)
                                 and (last.blockType == AST.ASTBlock.BlockType.Except
                                      or last.blockType == AST.ASTBlock.BlockType.Finally))
                if hasOwnHandler:
                    i += 1
                    continue
                if len(cur.nodes) == 0:
                    cur.nodes.append(AST.ASTKeyword(AST.ASTKeyword.Word.Pass))
                cur.nodes.append(nxt)
                del nodes[i + 1]
                # do not advance i (element shifted in)
                i += 1

            # Pass 5: a Try block with a non-empty body but no following Except/Finally handler
            i = 0
            while i < len(nodes):
                cur = nodes[i]
                if not isinstance(cur, AST.ASTBlock) or cur.blockType != AST.ASTBlock.BlockType.Try:
                    i += 1
                    continue
                if len(cur.nodes) == 0:
                    i += 1
                    continue
                nxt = nodes[i + 1] if i + 1 < len(nodes) else None
                hasHandler = (isinstance(nxt, AST.ASTCondBlock)
                              and (nxt.blockType == AST.ASTBlock.BlockType.Except
                                   or nxt.blockType == AST.ASTBlock.BlockType.Finally))
                if hasHandler:
                    i += 1
                    continue
                hasNestedExcept = any(
                    isinstance(n, AST.ASTCondBlock)
                    and (n.blockType == AST.ASTBlock.BlockType.Except
                         or n.blockType == AST.ASTBlock.BlockType.Finally)
                    for n in cur.nodes
                )
                if hasNestedExcept:
                    i += 1
                    continue
                synthetic = AST.ASTCondBlock(
                    AST.ASTBlock.BlockType.Except,
                    cur.end, cur.end, None, False)
                synthetic.line = cur.line
                synthetic.m_nodes.append(AST.ASTKeyword(AST.ASTKeyword.Word.Pass))
                nodes.insert(i + 1, synthetic)
                i += 2

            # Pass 5.5: adopt orphan Except into a preceding branch whose body ends with an un-paired Try.
            branchTypes = [
                AST.ASTBlock.BlockType.If,
                AST.ASTBlock.BlockType.Elif,
                AST.ASTBlock.BlockType.Else,
            ]

            def endsWithOrphanTry(block):
                if not isinstance(block, AST.ASTBlock):
                    return False
                if block.blockType not in branchTypes:
                    return False
                body = block.nodes
                if not body or len(body) == 0:
                    return False
                last = body[-1]
                if not isinstance(last, AST.ASTBlock) or last.blockType != AST.ASTBlock.BlockType.Try:
                    return False
                hasHandlerInside = any(
                    isinstance(n, AST.ASTCondBlock)
                    and (n.blockType == AST.ASTBlock.BlockType.Except
                         or n.blockType == AST.ASTBlock.BlockType.Finally)
                    for n in last.nodes
                )
                return not hasHandlerInside

            i = len(nodes) - 1
            while i > 0:
                cur = nodes[i]
                if not isinstance(cur, AST.ASTCondBlock):
                    i -= 1
                    continue
                if (cur.blockType != AST.ASTBlock.BlockType.Except
                        and cur.blockType != AST.ASTBlock.BlockType.Finally):
                    i -= 1
                    continue
                prev = nodes[i - 1]
                if not endsWithOrphanTry(prev):
                    i -= 1
                    continue
                hasLocalTry = False
                j = i - 1
                while j >= 0:
                    p = nodes[j]
                    if isinstance(p, AST.ASTBlock) and p.blockType == AST.ASTBlock.BlockType.Try:
                        hasLocalTry = True
                        break
                    if isinstance(p, AST.ASTCondBlock) and (
                            p.blockType == AST.ASTBlock.BlockType.Except
                            or p.blockType == AST.ASTBlock.BlockType.Finally):
                        j -= 1
                        continue
                    break
                if hasLocalTry:
                    i -= 1
                    continue
                prev.nodes.append(cur)
                del nodes[i]
                i -= 1

            # Pass 6: drop orphan Except/Finally blocks that have no matching Try
            inTryBody = parentBlockType == AST.ASTBlock.BlockType.Try

            def isHandlerBlock(x):
                return (isinstance(x, AST.ASTCondBlock)
                        and (x.blockType == AST.ASTBlock.BlockType.Except
                             or x.blockType == AST.ASTBlock.BlockType.Finally))

            i = len(nodes) - 1
            while i >= 0:
                cur = nodes[i]
                if not isinstance(cur, AST.ASTCondBlock):
                    i -= 1
                    continue
                if (cur.blockType != AST.ASTBlock.BlockType.Except
                        and cur.blockType != AST.ASTBlock.BlockType.Finally):
                    i -= 1
                    continue
                if inTryBody:
                    if getattr(cur, "isExceptStar", False):
                        i -= 1
                        continue
                    allTrailingHandlers = True
                    for k in range(i + 1, len(nodes)):
                        if not isHandlerBlock(nodes[k]):
                            allTrailingHandlers = False
                            break
                    if allTrailingHandlers:
                        i -= 1
                        continue
                anchorFound = False
                j = i - 1
                while j >= 0:
                    prev = nodes[j]
                    if isinstance(prev, AST.ASTBlock) and prev.blockType == AST.ASTBlock.BlockType.Try:
                        anchorFound = True
                        break
                    if isinstance(prev, AST.ASTCondBlock) and (
                            prev.blockType == AST.ASTBlock.BlockType.Except
                            or prev.blockType == AST.ASTBlock.BlockType.Finally):
                        j -= 1
                        continue
                    break
                if not anchorFound:
                    del nodes[i]
                i -= 1

            # Pass 7: drop Try+trivial-Except pairs where the body is now empty.
            i = len(nodes) - 1
            while i >= 0:
                if not isEmptyTryBlock(nodes[i]):
                    i -= 1
                    continue
                tailEnd = i + 1
                while tailEnd < len(nodes) and isTrivialHandlerBlock(nodes[tailEnd]):
                    tailEnd += 1
                if tailEnd == i + 1:
                    i -= 1
                    continue
                trailingHandler = (tailEnd < len(nodes)
                                   and isinstance(nodes[tailEnd], AST.ASTCondBlock)
                                   and (nodes[tailEnd].blockType == AST.ASTBlock.BlockType.Except
                                        or nodes[tailEnd].blockType == AST.ASTBlock.BlockType.Finally))
                if trailingHandler:
                    i -= 1
                    continue
                del nodes[i:tailEnd]
                i -= 1

        # Post-order traversal
        visited = set()

        def visit(n):
            if not n or id(n) in visited:
                return
            visited.add(id(n))
            nodes = None
            parentType = None
            if isinstance(n, AST.ASTNodeList):
                nodes = n.list
                parentType = None
            elif isinstance(n, AST.ASTBlock):
                nodes = n.nodes
                parentType = n.blockType
            elif isinstance(n, AST.ASTStore) and isinstance(n.src, AST.ASTFunction):
                body = getattr(getattr(getattr(n.src, "code", None), "object", None), "SourceCode", None)
                if body:
                    visit(body)
                return
            if nodes is not None:
                for c in nodes:
                    visit(c)
                rewriteContainer(nodes, parentType)
        visit(root)

    # Pre-3.11 `except Foo as X:` cleanup artifact strip.
    def cleanupPre311ExceptAsArtifacts(self, root):
        def isNoneDelPair(a, b):
            return (isinstance(a, AST.ASTStore)
                    and isinstance(a.src, AST.ASTNone)
                    and isinstance(a.dest, AST.ASTName)
                    and isinstance(b, AST.ASTDelete)
                    and isinstance(b.value, AST.ASTName)
                    and a.dest.name == b.value.name)

        def isFinallyTrivial(n):
            return (isinstance(n, AST.ASTBlock)
                    and n.blockType == AST.ASTBlock.BlockType.Finally
                    and (len(n.nodes) == 0
                         or (len(n.nodes) == 1
                             and isinstance(n.nodes[0], AST.ASTKeyword)
                             and getattr(n.nodes[0], "key", None) == AST.ASTKeyword.Word.Pass)))

        # A CPython `except Foo as X:` body wraps user code in a synthetic
        # `try: body / finally: X=None; del X`. Collapse the container
        # back to just the try-body.
        def unwrapTryFinallyPassContainer(nodes):
            i = len(nodes) - 1
            while i >= 0:
                cont = nodes[i]
                if not isinstance(cont, AST.ASTContainerBlock):
                    i -= 1
                    continue
                children = cont.nodes
                if not children or len(children) != 2:
                    i -= 1
                    continue
                tryBlk = children[0]
                finBlk = children[1]
                if not isinstance(tryBlk, AST.ASTBlock) or tryBlk.blockType != AST.ASTBlock.BlockType.Try:
                    i -= 1
                    continue
                if not isFinallyTrivial(finBlk):
                    i -= 1
                    continue
                if len(tryBlk.nodes) == 0:
                    i -= 1
                    continue
                # Keep real user try/except nested inside
                hasNestedHandler = any(
                    isinstance(n, AST.ASTCondBlock)
                    and (n.blockType == AST.ASTBlock.BlockType.Except
                         or n.blockType == AST.ASTBlock.BlockType.Finally)
                    for n in tryBlk.nodes
                )
                if hasNestedHandler:
                    i -= 1
                    continue
                nodes[i:i + 1] = tryBlk.nodes
                i -= 1

        def stripNoneDelPairs(nodes):
            i = len(nodes) - 2
            while i >= 0:
                if i + 1 < len(nodes) and isNoneDelPair(nodes[i], nodes[i + 1]):
                    del nodes[i:i + 2]
                i -= 1

        visited = set()

        def visit(n):
            if not n or id(n) in visited:
                return
            visited.add(id(n))
            nodes = None
            parentType = None
            if isinstance(n, AST.ASTNodeList):
                nodes = n.list
            elif isinstance(n, AST.ASTBlock):
                nodes = n.nodes
                parentType = n.blockType
            elif isinstance(n, AST.ASTStore) and isinstance(n.src, AST.ASTFunction):
                body = getattr(getattr(getattr(n.src, "code", None), "object", None), "SourceCode", None)
                if body:
                    visit(body)
                return
            if nodes is not None:
                for c in nodes:
                    visit(c)
                stripNoneDelPairs(nodes)
                # Only unwrap inside Except bodies
                if parentType == AST.ASTBlock.BlockType.Except:
                    unwrapTryFinallyPassContainer(nodes)

        visit(root)

    # Hoist nested Except blocks out of non-Try ancestors.
    def hoistNestedExceptBlocks(self, root):
        def isHoistableBlock(node):
            return (isinstance(node, AST.ASTBlock)
                    and node.blockType != AST.ASTBlock.BlockType.Try)

        def isExcept(node):
            return (isinstance(node, AST.ASTCondBlock)
                    and node.blockType == AST.ASTBlock.BlockType.Except)

        for _iter in range(64):
            moved_flag = {"v": False}

            def visit(arr, parentInfo):
                i = 0
                while i < len(arr):
                    n = arr[i]
                    if not n:
                        i += 1
                        continue
                    children = None
                    if isinstance(n, (AST.ASTBlock, AST.ASTCondBlock)):
                        children = n.nodes
                    elif isinstance(n, AST.ASTNodeList):
                        children = n.list
                    elif isinstance(n, AST.ASTStore) and isinstance(n.src, AST.ASTFunction):
                        src = getattr(getattr(getattr(n.src, "code", None), "object", None), "SourceCode", None)
                        if isinstance(src, AST.ASTNodeList):
                            visit(src.list, None)
                        i += 1
                        continue
                    if isinstance(children, list) and len(children) > 0:
                        if isHoistableBlock(n):
                            # Scan forward for leading Except children only
                            while len(children) > 0 and isExcept(children[0]):
                                ex = children.pop(0)
                                arr.insert(i + 1, ex)
                                moved_flag["v"] = True
                        visit(children, {"arr": arr, "index": i})
                    i += 1

            roots = []
            if isinstance(root, AST.ASTNodeList):
                roots.append(root.list)
            elif isinstance(root, AST.ASTBlock):
                roots.append(root.nodes)

            for r in roots:
                visit(r, None)

            # Also dive into nested function bodies.
            def walk(n, seen):
                if not n or id(n) in seen:
                    return
                seen.add(id(n))
                if isinstance(n, AST.ASTStore) and isinstance(n.src, AST.ASTFunction):
                    src = getattr(getattr(getattr(n.src, "code", None), "object", None), "SourceCode", None)
                    if isinstance(src, AST.ASTNodeList):
                        visit(src.list, None)
                children = None
                if isinstance(n, AST.ASTNodeList):
                    children = n.list
                elif isinstance(n, (AST.ASTBlock, AST.ASTCondBlock)):
                    children = n.nodes
                if isinstance(children, list):
                    for c in children:
                        walk(c, seen)
            walk(root, set())

            if not moved_flag["v"]:
                break

    def dedupeExceptHandlers(self, root):
        queue = [root]
        visited = set()
        while queue:
            node = queue.pop(0)
            if not node or id(node) in visited:
                continue
            visited.add(id(node))

            if isinstance(node, AST.ASTBlock) and node.blockType == AST.ASTBlock.BlockType.Try:
                nodes = node.nodes or []
                # Remove trailing cleanup else blocks (exception-group artifacts).
                if len(nodes) >= 2:
                    last = nodes[-1]
                    prev = nodes[-2]
                    if self.isEgCleanupElseBlock(last, prev):
                        nodes.pop()

                # Drop trivial generic except* handlers (exception-group artifacts)
                hasExceptStarSibling = any(
                    isinstance(n, AST.ASTCondBlock)
                    and n.blockType == AST.ASTBlock.BlockType.Except
                    and getattr(n, "isExceptStar", False)
                    for n in nodes
                )
                i = len(nodes) - 1
                while i >= 0:
                    blk = nodes[i]
                    if not isinstance(blk, AST.ASTCondBlock) or blk.blockType != AST.ASTBlock.BlockType.Except:
                        i -= 1
                        continue
                    if not getattr(blk, "isExceptStar", False) and not hasExceptStarSibling:
                        i -= 1
                        continue
                    condNode = blk.condition.src if isinstance(blk.condition, AST.ASTStore) else blk.condition
                    condText = None
                    if condNode is not None and hasattr(condNode, "codeFragment") and callable(condNode.codeFragment):
                        try:
                            cf = condNode.codeFragment()
                            condText = str(cf) if cf is not None else None
                        except Exception:
                            condText = None
                    if condText is None:
                        condText = getattr(condNode, "name", None)
                    body = blk.nodes or []
                    isTrivialBody = (len(body) == 0 or all(isinstance(n, AST.ASTKeyword) for n in body))
                    if isTrivialBody and (condText == "Exception" or condText is None):
                        del nodes[i]
                    i -= 1

                # Deduplicate consecutive except/except* handlers with identical condition and body.
                i = len(nodes) - 1
                while i > 0:
                    cur = nodes[i]
                    prev = nodes[i - 1]
                    bothExcept = (isinstance(cur, AST.ASTCondBlock)
                                  and isinstance(prev, AST.ASTCondBlock)
                                  and cur.blockType == AST.ASTBlock.BlockType.Except
                                  and prev.blockType == AST.ASTBlock.BlockType.Except)
                    if not bothExcept:
                        i -= 1
                        continue
                    try:
                        condA = str(cur.condition.codeFragment()) if cur.condition is not None and hasattr(cur.condition, "codeFragment") else None
                        condB = str(prev.condition.codeFragment()) if prev.condition is not None and hasattr(prev.condition, "codeFragment") else None
                    except Exception:
                        condA = condB = None
                    if condA != condB:
                        i -= 1
                        continue
                    if bool(getattr(cur, "isExceptStar", False)) != bool(getattr(prev, "isExceptStar", False)):
                        i -= 1
                        continue
                    try:
                        bodyA = str(cur.codeFragment()) if hasattr(cur, "codeFragment") else None
                        bodyB = str(prev.codeFragment()) if hasattr(prev, "codeFragment") else None
                    except Exception:
                        bodyA = bodyB = None
                    if bodyA and bodyB and bodyA == bodyB:
                        del nodes[i]
                    i -= 1

            if isinstance(node, AST.ASTNodeList):
                children = node.list
            elif isinstance(node, (AST.ASTBlock, AST.ASTCondBlock)):
                children = node.nodes
            elif isinstance(node, AST.ASTStore) and isinstance(node.src, AST.ASTFunction):
                children = getattr(getattr(getattr(getattr(node.src, "code", None), "object", None), "SourceCode", None), "list", None)
            else:
                children = None
            if isinstance(children, list):
                queue.extend(children)

    def pruneNullSentinels(self, nodes, visited=None):
        if visited is None:
            visited = set()
        if not isinstance(nodes, list):
            return
        if id(nodes) in visited:
            return
        visited.add(id(nodes))
        i = len(nodes) - 1
        while i >= 0:
            node = nodes[i]
            if self.isNullSentinelBlock(node):
                del nodes[i]
                i -= 1
                continue
            if isinstance(node, AST.ASTNodeList):
                self.pruneNullSentinels(node.list, visited)
            elif isinstance(node, AST.ASTBlock):
                self.pruneNullSentinels(node.nodes, visited)
            elif isinstance(node, AST.ASTStore) and isinstance(node.src, AST.ASTFunction):
                self.removeNullSentinelComparisons(
                    getattr(getattr(getattr(node.src, "code", None), "object", None), "SourceCode", None)
                )
            elif isinstance(node, AST.ASTStore) and isinstance(node.src, AST.ASTClass):
                self.removeNullSentinelComparisons(
                    getattr(
                        getattr(
                            getattr(
                                getattr(node.src, "code", None),
                                "func", None),
                            "code", None),
                        "object", None)
                )
                # JS path: src.code?.func?.code?.object?.SourceCode — replicate:
                # (the above gets to object; then SourceCode is accessed inside removeNull)
                # We re-resolve here:
                cls_code = getattr(node.src, "code", None)
                func_inner = getattr(cls_code, "func", None) if cls_code is not None else None
                inner_code = getattr(func_inner, "code", None) if func_inner is not None else None
                obj_inner = getattr(inner_code, "object", None) if inner_code is not None else None
                src_inner = getattr(obj_inner, "SourceCode", None) if obj_inner is not None else None
                if src_inner is not None:
                    self.removeNullSentinelComparisons(src_inner)
            i -= 1

    def isNullSentinelBlock(self, node):
        if not isinstance(node, AST.ASTCondBlock):
            return False
        if node.blockType != AST.ASTBlock.BlockType.If:
            return False
        condition = node.condition

        emptyBody = (not node.nodes or len(node.nodes) == 0
                     or all(isinstance(child, AST.ASTKeyword)
                            and getattr(child, "word", None) == AST.ASTKeyword.Word.Pass
                            for child in node.nodes))
        if not condition:
            return emptyBody

        if not isinstance(condition, AST.ASTCompare):
            return False
        leftStr = None
        try:
            left_frag = condition.left.codeFragment() if condition.left is not None and hasattr(condition.left, "codeFragment") else None
            leftStr = str(left_frag).strip() if left_frag is not None else None
        except Exception:
            leftStr = None
        isNullLiteral = leftStr == 'null'
        comparesNone = isinstance(condition.right, AST.ASTNone)
        return isNullLiteral and comparesNone and emptyBody

    def wrapFunctionExceptionGroups(self, root):
        if not isinstance(root, AST.ASTNodeList):
            return

        # Also handle module-level exception group patterns
        self.rewriteExceptionGroupsInList(root)

        for node in root.list:
            if isinstance(node, AST.ASTStore) and isinstance(node.src, AST.ASTFunction):
                self.rewriteExceptionGroupsInList(
                    getattr(getattr(getattr(node.src, "code", None), "object", None), "SourceCode", None)
                )

    def rewriteExceptionGroupsInList(self, listNode):
        if not listNode or not getattr(listNode, "list", None) or len(listNode.list) == 0:
            return

        nodes = listNode.list
        firstExceptIdx = -1
        for i, node in enumerate(nodes):
            if self.isExceptStarBlock(node) or self.isPlainExceptBlock(node):
                firstExceptIdx = i
                break
        if firstExceptIdx == -1:
            return

        hoistedPrefix = []
        tryBlock = None
        handlerNodes = []

        # Reuse the nearest preceding try block if it has meaningful body
        if firstExceptIdx > 0:
            for i in range(firstExceptIdx - 1, -1, -1):
                if isinstance(nodes[i], AST.ASTBlock) and nodes[i].blockType == AST.ASTBlock.BlockType.Try:
                    hasBody = len(nodes[i].nodes or []) > 0
                    if not hasBody:
                        continue
                    hoistedPrefix = nodes[:i]
                    tryBlock = nodes[i]
                    break

        if not tryBlock:
            startIdx = 0
            while startIdx < firstExceptIdx and self.isEgHoistableSetupNode(nodes[startIdx]):
                hoistedPrefix.append(nodes[startIdx])
                startIdx += 1
            start_val = (nodes[startIdx].start if startIdx < len(nodes) and hasattr(nodes[startIdx], "start") else None) \
                or (nodes[0].start if len(nodes) > 0 and hasattr(nodes[0], "start") else 0)
            tryBlock = AST.ASTBlock(AST.ASTBlock.BlockType.Try, start_val, 0, True)
            tryBlock.nodes.extend(nodes[startIdx:firstExceptIdx])

        if (tryBlock is not None
                and getattr(tryBlock, "nodes", None) is not None
                and len(tryBlock.nodes) == 1
                and isinstance(tryBlock.nodes[0], AST.ASTBlock)
                and tryBlock.nodes[0].blockType == AST.ASTBlock.BlockType.Try):
            tryBlock = tryBlock.nodes[0]

        # Pull handler blocks out of the try body if they were embedded there
        if tryBlock is not None and getattr(tryBlock, "nodes", None):
            filteredBody = []
            for stmt in tryBlock.nodes:
                if isinstance(stmt, AST.ASTCondBlock) and stmt.blockType == AST.ASTBlock.BlockType.Except:
                    handlerNodes.append(stmt)
                    continue
                filteredBody.append(stmt)
            tryBlock.m_nodes = filteredBody

        # Collapse nested try wrappers with no handlers
        body = tryBlock.nodes if tryBlock is not None else []
        while (len(body) == 1
               and isinstance(body[0], AST.ASTBlock)
               and body[0].blockType == AST.ASTBlock.BlockType.Try):
            inner = body[0]
            hasHandlers = any(
                isinstance(n, AST.ASTCondBlock) and n.blockType == AST.ASTBlock.BlockType.Except
                for n in (inner.nodes or [])
            )
            if hasHandlers:
                break
            tryBlock.m_nodes = inner.nodes or []
            body = tryBlock.m_nodes

        # Drop implicit "return None" from the end of the try body
        lastNode = tryBlock.nodes[-1] if tryBlock.nodes else None
        try:
            lastValStr = lastNode.value.codeFragment() if (lastNode is not None and hasattr(lastNode, "value") and lastNode.value is not None and hasattr(lastNode.value, "codeFragment")) else None
        except Exception:
            lastValStr = None
        if (isinstance(lastNode, AST.ASTReturn)
                and (isinstance(lastNode.value, AST.ASTNone)
                     or lastValStr == "None"
                     or lastValStr is None)):
            tryBlock.nodes.pop()

        rewritten = [*hoistedPrefix, tryBlock, *handlerNodes]
        # Heuristic: wrap stray TypeError print cleanup into an except* TypeError handler
        consumed = set()
        i = firstExceptIdx
        while i < len(nodes):
            node = nodes[i]
            if i in consumed:
                i += 1
                continue
            fragment = ''
            try:
                if hasattr(node, "codeFragment") and callable(node.codeFragment):
                    cf = node.codeFragment()
                    fragment = str(cf) if cf is not None else ''
            except Exception:
                fragment = ''
            if isinstance(node, AST.ASTCall) and isinstance(fragment, str) and 'TypeError' in fragment and '{e}' in fragment:
                cond = AST.ASTStore(AST.ASTName('TypeError'), AST.ASTName('e'))
                cb = AST.ASTCondBlock(AST.ASTBlock.BlockType.Except, getattr(node, "start", 0) or 0, getattr(node, "end", 0) or 0)
                cb.condition = cond
                cb.isExceptStar = True
                cb.m_nodes = [node]
                rewritten.append(cb)
                # Skip trailing cleanup nodes for e
                j = i + 1
                while j < len(nodes):
                    nxt = nodes[j]
                    if isinstance(nxt, AST.ASTStore) and getattr(nxt.dest, "name", None) == 'e':
                        consumed.add(j)
                        j += 1
                        continue
                    if isinstance(nxt, AST.ASTDelete) and getattr(nxt.value, "name", None) == 'e':
                        consumed.add(j)
                        j += 1
                        continue
                    break
                consumed.add(i)
                i += 1
                continue
            if _debug_enabled() and isinstance(node, AST.ASTBlock) and node.blockType == AST.ASTBlock.BlockType.Else:
                prev = rewritten[-1] if rewritten else None
                _log(f"[EG] Evaluating else cleanup candidate after {type(prev).__name__ if prev is not None else None}:{getattr(prev, 'blockType', None)}")
            if self.isEgCleanupElseBlock(node, rewritten[-1] if rewritten else None):
                i += 1
                continue
            if self.isPrepReraiseBlock(node):
                i += 1
                continue
            if (isinstance(node, AST.ASTCondBlock)
                    and node.blockType == AST.ASTBlock.BlockType.Except):
                def _child_is_cleanup(ch):
                    try:
                        frag = str(ch.codeFragment()) if hasattr(ch, "codeFragment") else ""
                    except Exception:
                        frag = ""
                    return frag == "pass" or "__exception__" in frag or "##ERROR##" in frag
                node_body_ok = (not node.nodes) or all(_child_is_cleanup(ch) for ch in node.nodes)
                if node_body_ok:
                    # Drop only synthetic except* handlers without a user condition.
                    if getattr(node, "isExceptStar", False) and not node.condition:
                        i += 1
                        continue
                    node.m_nodes = [AST.ASTKeyword(AST.ASTKeyword.Word.Pass)]
                    rewritten.append(node)
                    i += 1
                    continue
            if hasattr(node, "codeFragment") and callable(node.codeFragment):
                try:
                    frag = node.codeFragment()
                    fragStr = str(frag) if frag is not None else ""
                except Exception:
                    fragStr = ""
                if "##ERROR##" in fragStr:
                    i += 1
                    continue
            rewritten.append(node)
            i += 1

        def _flatten(n):
            if (isinstance(n, AST.ASTBlock)
                    and n.blockType == AST.ASTBlock.BlockType.Try
                    and getattr(n, "nodes", None)
                    and len(n.nodes) == 1
                    and isinstance(n.nodes[0], AST.ASTBlock)
                    and n.nodes[0].blockType == AST.ASTBlock.BlockType.Try):
                inner = n.nodes[0]
                hasHandlers = any(
                    isinstance(ch, AST.ASTCondBlock) and ch.blockType == AST.ASTBlock.BlockType.Except
                    for ch in (inner.nodes or [])
                )
                if not hasHandlers:
                    return inner
            return n

        flattened = [_flatten(n) for n in rewritten]

        deduped = []
        seenHandlers = set()
        for node in flattened:
            if isinstance(node, AST.ASTCondBlock) and node.blockType == AST.ASTBlock.BlockType.Except:
                condStr = ""
                try:
                    if node.condition is not None and hasattr(node.condition, "codeFragment"):
                        cf = node.condition.codeFragment()
                        condStr = str(cf) if cf is not None else ""
                except Exception:
                    condStr = ""
                key = f"{'star' if getattr(node, 'isExceptStar', False) else 'plain'}:{condStr}"
                if key in seenHandlers:
                    continue
                seenHandlers.add(key)
            deduped.append(node)

        listNode.list.clear()
        listNode.list.extend(deduped)

    def rewriteGenericWrappers(self, root):
        if not isinstance(root, AST.ASTNodeList):
            return
        for i in range(len(root.list)):
            node = root.list[i]
            if not isinstance(node, AST.ASTStore):
                continue
            call = node.src
            if not isinstance(call, AST.ASTCall):
                continue
            func = call.func
            if not isinstance(func, AST.ASTFunction):
                continue
            wrapperName = getattr(getattr(getattr(func, "code", None), "object", None), "Name", "") or ""
            if not (isinstance(wrapperName, str) and wrapperName.startswith("<generic parameters of ")):
                # wrapperName might be a PyString — try its string form
                try:
                    wrapperName_str = str(wrapperName)
                except Exception:
                    wrapperName_str = ""
                if not wrapperName_str.startswith("<generic parameters of "):
                    continue

            # If the call already returns a function/class directly, unwrap it
            type_params = getattr(func, "typeParams", None)
            annotations = getattr(func, "annotations", None)
            if (type_params and len(type_params)) or (annotations and len(list(annotations.keys()))):
                node.m_src = func
                continue

            targetName = None
            if getattr(node, "dest", None) is not None:
                targetName = getattr(node.dest, "name", None)
                if not targetName and hasattr(node.dest, "codeFragment"):
                    try:
                        targetName = node.dest.codeFragment()
                    except Exception:
                        targetName = None
            isClassLike = bool(targetName and targetName[0] == (targetName[0].upper() if targetName[0] else ''))

            # Preferred path (3.13+)
            wrapperBody = getattr(getattr(getattr(func, "code", None), "object", None), "SourceCode", None)
            wrapperList = getattr(wrapperBody, "list", None) or []
            returnedNode = None
            for j in range(len(wrapperList) - 1, -1, -1):
                stmt = wrapperList[j]
                if isinstance(stmt, AST.ASTReturn) and stmt.value:
                    returnedNode = stmt.value
                    break
            if not isClassLike and isinstance(returnedNode, AST.ASTFunction):
                node.m_src = returnedNode
                continue

            # Fallback (pre-3.13 or irregular wrappers): rebuild from Consts.
            codeConsts = getattr(getattr(getattr(func, "code", None), "object", None), "Consts", None)
            codeConsts = getattr(codeConsts, "Value", None) or []
            allCodeObjects = [c for c in codeConsts if getattr(c, "ClassName", None) == 'Py_CodeObject']
            innerCodeObj = None
            for c in allCodeObjects:
                try:
                    name_str = c.Name.toString() if hasattr(c.Name, "toString") else str(c.Name)
                except Exception:
                    name_str = None
                if name_str == targetName:
                    innerCodeObj = c
                    break
            if not innerCodeObj and allCodeObjects:
                innerCodeObj = allCodeObjects[0]
            if not innerCodeObj:
                continue
            typeParamNames = []
            for c in codeConsts:
                if getattr(c, "ClassName", None) == 'Py_String':
                    val = getattr(c, "Value", None)
                    if val and re.match(r'^[A-Z][A-Za-z0-9_]*$', val) and val != targetName:
                        typeParamNames.append(val)

            typeParams = []
            for name in typeParamNames:
                defaultCode = None
                for c in allCodeObjects:
                    if c is innerCodeObj:
                        continue
                    if (getattr(c, "ArgCount", 0) or 0) != 0:
                        continue
                    try:
                        name_str = c.Name.toString() if hasattr(c.Name, "toString") else str(c.Name)
                    except Exception:
                        name_str = None
                    if name_str == name:
                        defaultCode = c
                        break
                if not defaultCode:
                    typeParams.append(name)
                    continue
                try:
                    dd = PycDecompiler(defaultCode)
                    body = dd.decompile()
                    defaultCode.SourceCode = body
                    if dd.errors:
                        self.errors.extend(dd.errors)
                    lst = getattr(body, "list", None) or []
                    top = None
                    if lst:
                        top = lst[-1] if len(lst) > 0 else None
                    if isinstance(top, AST.ASTReturn) and top.value:
                        typeParams.append({"name": name, "default": top.value})
                        continue
                except Exception:
                    pass
                typeParams.append(name)

            innerDecompiler = PycDecompiler(innerCodeObj)
            innerBody = innerDecompiler.decompile()
            innerCodeObj.SourceCode = innerBody
            if innerDecompiler.errors:
                self.errors.extend(innerDecompiler.errors)
            astObj = AST.ASTObject(innerCodeObj)

            if not isClassLike:
                fn = AST.ASTFunction(astObj)
                fn.annotations = getattr(innerDecompiler, "funcAnnotations", None) or getattr(fn, "annotations", None)
                fn.typeParams = typeParams
                node.m_src = fn
            else:
                classFunc = AST.ASTFunction(astObj)
                bases = AST.ASTTuple([])
                cls = AST.ASTClass(classFunc, bases, AST.ASTName(targetName))
                cls.typeParams = typeParams
                node.m_src = cls

        # Simplify calls that simply wrap a generic wrapper function
        for i in range(len(root.list)):
            node = root.list[i]
            if (isinstance(node, AST.ASTStore)
                    and isinstance(node.src, AST.ASTCall)
                    and isinstance(node.src.func, AST.ASTFunction)
                    and len(node.src.pparams or []) == 0):
                node.m_src = node.src.func

    def isExceptStarBlock(self, node):
        return (isinstance(node, AST.ASTCondBlock)
                and node.blockType == AST.ASTBlock.BlockType.Except
                and getattr(node, "isExceptStar", False))

    def isPlainExceptBlock(self, node):
        return (isinstance(node, AST.ASTCondBlock)
                and node.blockType == AST.ASTBlock.BlockType.Except)

    def isEgHoistableSetupNode(self, node):
        if not isinstance(node, AST.ASTStore):
            return False
        if not isinstance(node.dest, AST.ASTName):
            return False
        return (isinstance(node.src, AST.ASTNone)
                or isinstance(node.src, AST.ASTObject)
                or isinstance(node.src, AST.ASTFunction))

    def hasTerminatingKeyword(self, block):
        """Recursively checks if a block ends with a terminating keyword (break/continue/return)."""
        if not block or not getattr(block, "nodes", None) or len(block.nodes) == 0:
            return False

        lastNode = block.nodes[-1]

        # Check if last node is a terminating keyword.
        # JS reads `ASTKeyword.Word.Return` which is undefined on the enum —
        # that branch is effectively dead there. Python raises AttributeError,
        # so mirror the soft-lookup explicitly.
        if isinstance(lastNode, AST.ASTKeyword):
            return getattr(lastNode, "word", None) in [
                AST.ASTKeyword.Word.Break,
                AST.ASTKeyword.Word.Continue,
                getattr(AST.ASTKeyword.Word, "Return", None),
            ]

        # Check if last node is a block - recurse into it
        if isinstance(lastNode, AST.ASTBlock):
            return self.hasTerminatingKeyword(lastNode)

        # Check if last node is a return statement
        if isinstance(lastNode, AST.ASTReturn):
            return True

        return False

    def lookAheadForMatchPattern(self):
        """Look ahead from current COPY after LOAD to detect match pattern."""
        # Match patterns only exist in Python 3.10+
        if self.object.Reader.versionCompare(3, 10) < 0:
            return False
        if not getattr(self.code, "Next", None):
            if _debug_enabled():
                _log("[LOOK-AHEAD] No next instruction")
            return False

        # Find next POP_JUMP_IF_FALSE opcode
        nextOp = self.code.Next
        jumpOp = None

        for _i in range(10):
            if not nextOp:
                break
            if (nextOp.OpCodeID == self.OpCodes.POP_JUMP_IF_FALSE_A
                    or nextOp.OpCodeID == self.OpCodes.POP_JUMP_FORWARD_IF_FALSE_A):
                jumpOp = nextOp
                break
            nextOp = nextOp.Next

        if not jumpOp:
            if _debug_enabled():
                _log("[LOOK-AHEAD] No POP_JUMP found within 10 instructions")
            return False

        if getattr(jumpOp, "JumpTarget", None) is None:
            if _debug_enabled():
                _log("[LOOK-AHEAD] POP_JUMP has no jump target")
            return False

        if _debug_enabled():
            _log(f"[LOOK-AHEAD] Found POP_JUMP at offset {jumpOp.Offset}, target={jumpOp.JumpTarget}")

        # Find instruction at or after jump target offset
        targetOp = jumpOp.Next

        # Look for next COPY (should be within reasonable distance)
        searchLimit = 100
        searchCount = 0

        while targetOp and searchCount < searchLimit:
            # Found a COPY opcode?
            if (targetOp.OpCodeID == self.OpCodes.DUP_TOP
                    or (targetOp.OpCodeID == self.OpCodes.COPY_A and targetOp.Argument == 1)):

                if _debug_enabled():
                    _log(f"[LOOK-AHEAD] Found COPY at offset {targetOp.Offset} after POP_JUMP")

                # Check if this COPY is preceded by LOAD (if yes, not a match pattern)
                prevOp = getattr(targetOp, "Prev", None)
                if prevOp and (prevOp.OpCodeID == self.OpCodes.LOAD_FAST_A
                               or prevOp.OpCodeID == self.OpCodes.LOAD_NAME_A
                               or prevOp.OpCodeID == self.OpCodes.LOAD_GLOBAL_A):
                    # This COPY is after LOAD → not the reuse pattern
                    if _debug_enabled():
                        _log(f"[LOOK-AHEAD] COPY at {targetOp.Offset} has LOAD before → not match pattern")
                    return False

                # This COPY has no LOAD before → match pattern!
                if _debug_enabled():
                    _log(f"[LOOK-AHEAD] Match pattern detected! COPY at {targetOp.Offset} has no prior LOAD")
                return True

            targetOp = targetOp.Next
            searchCount += 1

        if _debug_enabled():
            _log(f"[LOOK-AHEAD] No COPY found after POP_JUMP within {searchLimit} bytes")
        return False
