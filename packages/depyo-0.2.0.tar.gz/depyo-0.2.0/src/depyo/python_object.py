"""PythonObject — marshal deserializer's object wrapper."""

from __future__ import annotations

import re


class _OrderedSet:
    """Minimal insertion-ordered set. Mirrors JS Set's iteration order."""

    __slots__ = ("_d",)

    def __init__(self):
        self._d = {}

    def add(self, value):
        self._d[value] = None

    def __contains__(self, value):
        return value in self._d

    def __iter__(self):
        return iter(self._d)

    def __len__(self):
        return len(self._d)

    def __bool__(self):
        return True  # JS Set is always truthy

    @property
    def size(self):
        return len(self._d)


class PythonObject:
    ClassName = None
    Value = None

    def __init__(self, class_name=None, value=None):
        self.ClassName = class_name if class_name else None
        self.Value = value if value is not None else None

    def add(self, *args):
        # JS had two overloaded `add()` methods declared back-to-back; the second
        # (Py_Dict) shadowed the first. We dispatch by arity to preserve both.
        if len(args) == 2:
            key, val = args
            if self.ClassName == "Py_Dict":
                dict_ = self.Value
                if dict_ is None:
                    dict_ = []
                    self.Value = dict_
                dict_.append({"key": key, "value": val})
            return

        if len(args) == 1:
            po = args[0]
            if self.ClassName in ("Py_List", "Py_Tuple", "Py_Set", "Py_FrozenSet"):
                list_ = self.Value
                if list_ is None:
                    list_ = []
                    self.Value = list_
                list_.append(po)

    @property
    def length(self):
        if self.ClassName in (
            "Py_String",
            "Py_List",
            "Py_Dict",
            "Py_Tuple",
            "Py_Set",
            "Py_FrozenSet",
            "Py_VeryLong",
        ):
            if self.Value and hasattr(self.Value, "__len__") and len(self.Value):
                return len(self.Value)
            else:
                return 0
        else:
            return 1

    def __len__(self):
        return self.length

    def __bool__(self):
        # JS objects are always truthy regardless of internal state. Python's
        # default falls back to __len__, which makes empty strings/lists/dicts
        # falsy — and that in turn makes `if not ast_obj.object:` treat a
        # `PythonObject(Py_String, b"")` as missing, printing "None" instead of
        # '""'. Anchor truthiness to identity, not content, to match JS.
        return True

    # TODO: Refactor to use Symbol.toPrimitive() and Object.valueOf()

    def toReprString(self):
        if self.ClassName == "Py_String" or self.ClassName == "Py_Unicode":
            raw = self.Value
            if raw is None or len(raw) == 0:
                return '""'
            raw = raw.decode("utf-8", errors="replace") if isinstance(raw, (bytes, bytearray)) else str(raw)
            escaped = (
                raw
                .replace("\\", "\\\\")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t")
            )
            escaped = re.sub(
                r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]",
                lambda m: "\\x" + format(ord(m.group(0)), "x").zfill(2),
                escaped,
            )
            quote = '"'
            if '"' in escaped:
                if "'" not in escaped:
                    quote = "'"
                else:
                    escaped = escaped.replace('"', '\\"')
            return quote + escaped + quote
        return self.toString()

    def toString(self):
        cn = self.ClassName

        if cn in ("Py_Unicode", "Py_String"):
            strValue = self.Value
            if hasattr(strValue, "ClassName") and strValue.ClassName:
                raise SyntaxError("Recursion")
            if not strValue or len(strValue) == 0:
                return ""
            strValue = strValue.decode("utf-8", errors="replace") if isinstance(strValue, (bytes, bytearray)) else str(strValue)
            if "\n" in strValue:
                strValue = strValue.replace("\n", "\\n")
            return strValue

        if cn in ("Py_Int", "Py_Long", "Py_Long64"):
            return str(self.Value) if self.Value is not None else "0"

        if cn == "Py_Interned":
            return str(self.Value) if self.Value is not None else "0"

        if cn == "Py_Float":
            if self.Value is None:
                return "0.0"
            # Mirror JS Number.toString(): NaN, Infinity, -Infinity — not
            # Python's nan/inf/-inf. Downstream comparisons expect JS form.
            v = self.Value
            if isinstance(v, float):
                if v != v:  # NaN
                    return "NaN"
                if v == float("inf"):
                    return "Infinity"
                if v == float("-inf"):
                    return "-Infinity"
                # JS Number.toString() normalizes -0 to "0"; Python keeps "-0.0".
                if v == 0.0:
                    v = 0.0
            s = f"{v}"
            # JS formats 1e-9 without leading zero in the exponent; Python
            # emits 1e-09. Strip one-or-more leading zeros so fixtures compare.
            s = re.sub(r"([eE])([+-])0+(\d)", r"\1\2\3", s)
            # Python rejects `1e+300.0`; only append `.0` when the
            # printed form is pure digits (optional sign).
            if re.match(r"^-?\d+$", s):
                s += ".0"
            return s

        if cn == "Py_VeryLong":
            if self.Value:
                if len(self.Value) < 8:
                    # JS Array.toString() joins values with "," (no brackets).
                    # Python's str(list) adds "[ ]" and ", ". Match JS here so
                    # pre-3.x long-integer constants render as "0,2" not "[0, 2]".
                    return ",".join(str(v) for v in self.Value)
                else:
                    result = "0x"
                    skipFirstZeros = True
                    shortFlag = True
                    for idx in range(len(self.Value) - 1, -1, -1):
                        value = self.Value[idx]
                        value = format(value, "x")
                        if skipFirstZeros and value == "0":
                            continue
                        elif skipFirstZeros and value:
                            skipFirstZeros = False
                        if not shortFlag:
                            value = "0" + value if len(value) < 2 else value
                        shortFlag = False
                        result += value
                    return result
            else:
                return "0"

        if cn == "Py_Null":
            return "None"

        if cn == "Py_False":
            return "False"

        if cn == "Py_True":
            return "True"

        if cn == "Py_None":
            return "None"

        if cn in ("Py_Tuple", "Py_Set", "Py_FrozenSet"):
            res = "("
            if self.Value:
                for obj in self.Value:
                    if isinstance(obj, PythonObject):
                        part = obj.toReprString()
                    elif obj is None:
                        # JS String(null) → "null"; mirror so fixture text matches.
                        part = "null"
                    else:
                        part = str(obj)
                    if res != "(":
                        res += ", " + part
                    else:
                        res += part
                res += ")"
                return res
            else:
                return "null"

        if cn == "Py_CodeObject":
            return f"<code object {self.Name.toString()}, file '{self.FileName.toString()}', line {self.FirstLineNo}>"

        if cn == "Py_Dict":
            if self.Value:
                res = "("
                for pair in self.Value:
                    if res != "(":
                        res += ", "
                    kPart = pair["key"].toReprString() if isinstance(pair["key"], PythonObject) else str(pair["key"])
                    vPart = pair["value"].toReprString() if isinstance(pair["value"], PythonObject) else str(pair["value"])
                    res += kPart + ": " + vPart
                res += ")"
                return res
            else:
                return "()"

        if cn == "Py_StringRef":
            return self.Strings[self.Value]

        if cn == "Py_Complex":
            def _fmt(v):
                # JS Number stringifies 0.0 as "0", Infinity/NaN with capital I/N;
                # mirror so complex literals come out as 0+5j / 0+Infinityj rather
                # than 0.0+5.0j / 0+infj (Python's str()).
                if isinstance(v, float):
                    if v != v:
                        return "NaN"
                    if v == float("inf"):
                        return "Infinity"
                    if v == float("-inf"):
                        return "-Infinity"
                    if v.is_integer():
                        return str(int(v))
                return str(v)
            return f"{_fmt(self.Value[0])}+{_fmt(self.Value[1])}j"

        # default
        if self.ClassName in ("Py_String",):
            return self.Value.decode("ascii", errors="replace") if isinstance(self.Value, (bytes, bytearray)) else str(self.Value)
        return None

    def __str__(self):
        result = self.toString()
        return result if result is not None else ""


class PythonCodeObject(PythonObject):
    ClassName = "Py_CodeObject"
    ArgCount = 0
    PosOnlyArgCount = 0
    KWOnlyArgCount = 0
    NumLocals = 0
    StackSize = 0
    Flags = 0
    Code = None
    FileName = None
    Name = None
    FirstLineNo = 0
    LineNoTabObject = None
    ExceptionTable = None  # Python 3.11+ exception table (raw bytes or parsed entries)
    SourceCode = None
    FuncParams = None
    FuncDecos = None
    FuncName = None
    CachedLineNo = -1

    def __init__(self, class_name=None, value=None):
        super().__init__(class_name if class_name else "Py_CodeObject", value)
        self.ClassName = "Py_CodeObject"
        self.ArgCount = 0
        self.PosOnlyArgCount = 0
        self.KWOnlyArgCount = 0
        self.NumLocals = 0
        self.StackSize = 0
        self.Flags = 0
        self.Code = None
        self.Consts = []
        self.Names = []
        self.VarNames = []
        self.FreeVars = []
        self.CellVars = []
        self.FileName = None
        self.Name = None
        self.FirstLineNo = 0
        self.LineNoTab = []
        self.LineNoTabObject = None
        self.ExceptionTable = None
        self.Methods = []
        self.SourceCode = None
        self.FuncParams = None
        self.FuncDecos = None
        self.FuncName = None
        self.ASTTree = []
        # JS uses Set which iterates in insertion order. Python's set does not,
        # so `global x; global y` would emit in arbitrary order. Use a dict
        # (insertion-ordered) and ignore values; .add delegates via the shim below.
        self.Globals = _OrderedSet()
        self.CachedLineNo = -1

    def getLineNumber(self, offset, isVer310=False):
        if offset < 0:
            return self.FirstLineNo

        if self.CachedLineNo > -1:
            return self.CachedLineNo

        if (
            not self.LineNoTabObject
            or len(self.LineNoTabObject.Value) < 2
            or offset >= len(self.Code)
        ):
            return -1

        lnTable = self.LineNoTabObject.Value
        size = len(lnTable) // 2
        sDelta = 0
        lDelta = 0

        line = self.FirstLineNo
        addr = 0
        index = 0
        while True:
            size -= 1
            if size < 0:
                break
            sDelta = lnTable[index]
            index += 1
            lDelta = lnTable[index]
            index += 1

            addr += sDelta
            if addr > offset:
                break

            if isVer310 and lDelta == -128:  # Should we treat no line number? or treat it as previous line?
                lDelta = 0

            line += lDelta
        return line

    # snake_case alias
    get_line_number = getLineNumber
