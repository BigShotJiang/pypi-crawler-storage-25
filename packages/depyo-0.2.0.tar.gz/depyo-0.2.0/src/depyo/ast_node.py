from __future__ import annotations

import json
import re
import sys

from .opcodes import OpCodes
from .pyc_result import PycResult


SPACES_PER_LEVEL = 4


def indent(level=1):
    return " " * (level * SPACES_PER_LEVEL)


def renderTypeParam(tp):
    # PEP 696: a typeparam may be {name, default: ASTNode} instead of a string.
    # JS guard `!tp.codeFragment` ensures tp itself isn't an ASTNode — mirror that.
    if (tp is not None and isinstance(tp, dict) and tp.get("name") is not None
            and tp.get("default") is not None and not hasattr(tp, "codeFragment")):
        default_val = tp.get("default")
        if hasattr(default_val, "codeFragment"):
            defFrag = default_val.codeFragment()
        elif hasattr(default_val, "toString"):
            defFrag = default_val.toString()
        else:
            defFrag = str(default_val)
        return f"{tp['name']} = {defFrag}"
    if tp is not None and hasattr(tp, "codeFragment"):
        return tp.codeFragment()
    if tp is not None and hasattr(tp, "toString"):
        return tp.toString()
    return tp if isinstance(tp, str) else str(tp)


def _get_raw_spacing():
    g = globals().get("g_cliArgs")
    if g is None:
        g = getattr(sys.modules.get("__main__", None), "g_cliArgs", None)
    if g is None:
        return None
    if isinstance(g, dict):
        return g.get("rawSpacing")
    return getattr(g, "rawSpacing", None)


def _get_debug():
    g = globals().get("g_cliArgs")
    if g is None:
        g = getattr(sys.modules.get("__main__", None), "g_cliArgs", None)
    if g is None:
        return None
    if isinstance(g, dict):
        return g.get("debug")
    return getattr(g, "debug", None)


def _list_empty(lst):
    return lst is None or len(lst) == 0


def _list_not_empty(lst):
    return lst is not None and len(lst) > 0


class ASTNode:
    # JS reads `.blockType`, `.hasFinally`, `.comprehension`, `.finally_` etc.
    # freely on any node; when the property doesn't exist JS returns undefined
    # and comparisons quietly fail. Python raises AttributeError on missing
    # attributes, so leak the equivalent default here — ASTBlock and friends
    # override these where real values exist.
    blockType = None
    hasFinally = False
    comprehension = False
    condition = None
    finally_ = None

    def __init__(self):
        self.m_lineNo = -1
        self.m_prevSibling = None
        self.m_nextSibling = None
        self.m_skip = False

    @property
    def line(self):
        return self.m_lineNo

    @line.setter
    def line(self, lineNo):
        self.m_lineNo = lineNo

    @property
    def lastLine(self):
        return self.m_lineNo

    @property
    def prevSibling(self):
        return self.m_prevSibling

    @prevSibling.setter
    def prevSibling(self, value):
        self.m_prevSibling = value

    @property
    def nextSibling(self):
        return self.m_nextSibling

    @nextSibling.setter
    def nextSibling(self, value):
        self.m_nextSibling = value

    @property
    def skip(self):
        return self.m_skip

    @skip.setter
    def skip(self, value):
        self.m_skip = value

    def codeFragment(self):
        raise RuntimeError(f"{self.__class__.__name__}.codeFragment() not implemented — subclass must override")

    @staticmethod
    def calculateSpacing(prevNode, node):
        rawSpacing = _get_raw_spacing()
        # Dict-shaped entries (e.g. {key, value} map items) delegate to key.
        if isinstance(node, dict):
            node = node.get("key")
            prevNode = prevNode.get("key") if isinstance(prevNode, dict) else prevNode
        if node is not None and getattr(node, "key", None):
            prevNode = getattr(prevNode, "key", None) if prevNode is not None else None
            node = node.key
        prev_lastLine = getattr(prevNode, "lastLine", None) if prevNode is not None else None
        node_line = getattr(node, "line", None) if node is not None else None
        if not prevNode or prev_lastLine == node_line:
            return 0
        else:
            prevLine = prev_lastLine if (prev_lastLine is not None and prev_lastLine > -1) else (node_line or -1) - 1
            node_lastLine = getattr(node, "lastLine", -1) if node is not None else -1
            node_lastLine = -1 if node_lastLine is None else node_lastLine
            if node_lastLine > -1:
                line = node_lastLine
            else:
                line = prevLine + 1 if prevLine > -1 else 1
            delta = line - prevLine
            if not rawSpacing and delta > 3:
                delta = 3
            return delta

    @staticmethod
    def renderList(list_, openBracket, closeBracket, callback=None):
        result = PycResult(openBracket, True)
        result.increaseIndent()
        prevNode = None
        rawSpacing = _get_raw_spacing()

        for node in list_:
            if callback:
                sourceFragment = callback(node)
            else:
                sourceFragment = (node.codeFragment() if node is not None else None) or "##ERROR##"
            spacing = ASTNode.calculateSpacing(prevNode, node)

            if spacing == 0:
                result.lastLineAppend((" " if prevNode else "") + str(sourceFragment) + ",", False)
            else:
                if rawSpacing:
                    blankCount = max(0, spacing - 1)
                else:
                    blankCount = 1 if spacing > 2 else 0
                for _ in range(blankCount):
                    result.add("")
                result.add(str(sourceFragment) + ",")

            prevNode = node
        result.chop(",")
        result.lastLineAppend(closeBracket)

        return result

    def toASTString(self):
        def default(o):
            if isinstance(o, bytes):
                try:
                    return o.decode("ascii")
                except Exception:
                    return str(o)
            if hasattr(o, "__dict__"):
                d = dict(o.__dict__)
                d["ast_class_name"] = o.__class__.__name__
                return d
            return str(o)
        return json.dumps(self, default=default, indent=2)


class ASTNone(ASTNode):
    def __init__(self, override=None):
        super().__init__()
        self.m_override = None
        if override:
            self.m_override = override

    def codeFragment(self):
        return self.m_override if self.m_override is not None else "None"

    def __str__(self):
        return "ASTNone"

    def toString(self):
        return self.__str__()


class ASTLocals(ASTNode):
    def __init__(self):
        super().__init__()

    def codeFragment(self):
        return ""

    def __str__(self):
        return "ASTLocals"

    def toString(self):
        return self.__str__()


class ASTNodeList(ASTNode):
    def __init__(self, nodes=None):
        super().__init__()
        self.m_list = nodes if nodes is not None else []
        self.m_isModuleLevel = False

    @property
    def list(self):
        return self.m_list

    @property
    def line(self):
        return self.m_list[0].line

    @line.setter
    def line(self, value):
        self.m_lineNo = value

    @property
    def last(self):
        # JS: arr[arr.length - 1] returns undefined for empty arrays; mirror that.
        return self.list[len(self.list) - 1] if self.list else None

    @property
    def lastLine(self):
        return self.last.line

    @property
    def isModuleLevel(self):
        return self.m_isModuleLevel

    @isModuleLevel.setter
    def isModuleLevel(self, value):
        self.m_isModuleLevel = bool(value)

    def emptyBlock(self):
        return (len(self.list) == 1 and isinstance(self.list[0], ASTReturn)
                and (self.list[0].value is None or isinstance(self.list[0].value, ASTNone)))

    def codeFragment(self):
        if self.isEgCleanupElse():
            self.skip = True
            return ""

        result = PycResult("", True)

        if self.emptyBlock():
            result.add("pass")
        else:
            prevNode = None

            for node in self.list:
                if prevNode:
                    prevNode.nextSibling = node
                node.prevSibling = prevNode
                prevNode = node
            prevNode = None

            for node in self.list:
                if node.skip:
                    continue
                # Drop implicit module-level "return None"
                if self.isModuleLevel and isinstance(node, ASTReturn):
                    val = node.value
                    isNone = val is None or isinstance(val, ASTNone)
                    if not isNone and hasattr(val, "codeFragment"):
                        try:
                            if str(val.codeFragment()) == "None":
                                isNone = True
                        except Exception:
                            pass
                    if isNone:
                        prevNode = node
                        continue
                sourceFragment = node.codeFragment()
                if not sourceFragment:
                    prevNode = node
                    continue
                rawSpacing = _get_raw_spacing()
                spacing = ASTNode.calculateSpacing(prevNode, node)
                if not rawSpacing:
                    if not self.isModuleLevel and spacing > 1:
                        spacing = 1
                    if (isinstance(prevNode, ASTStore) and isinstance(node, ASTStore)
                            and isinstance(prevNode.dest, ASTAnnotatedVar) and isinstance(node.dest, ASTAnnotatedVar)):
                        spacing = max(spacing, 1)
                    elif (isinstance(prevNode, ASTStore) and isinstance(node, ASTStore)
                            and isinstance(prevNode.src, ASTTypeAlias) and isinstance(node.src, ASTTypeAlias)):
                        spacing = max(spacing, 1)
                    elif self.requiresModuleSpacing(prevNode, node):
                        spacing = max(spacing, 2)

                # Only join with `; ` between two simple (non-compound) statements
                # that also happen to be on the same source line. A compound block
                # (if/while/for/try/function/class) must never be semicolon-joined
                # to a following sibling — doing so swallows the sibling into the
                # block's body and breaks structure.
                prevIsCompound = (isinstance(prevNode, ASTBlock) or
                                  isinstance(prevNode, ASTFunction) or
                                  isinstance(prevNode, ASTClass))
                nodeIsCompound = (isinstance(node, ASTBlock) or
                                  isinstance(node, ASTFunction) or
                                  isinstance(node, ASTClass))
                src_str = str(sourceFragment)
                # JS: sourceFragment.length == 1.
                # For a PycResult this is number-of-lines == 1; for a bare
                # string this is string-length == 1 (so string fragments
                # almost never pass). Match that form exactly.
                if hasattr(sourceFragment, "length"):
                    src_length_eq_1 = sourceFragment.length == 1
                else:
                    src_length_eq_1 = len(src_str) == 1
                if (prevNode and spacing == 0 and src_length_eq_1
                        and not prevIsCompound and not nodeIsCompound):
                    result.lastLineAppend(("; " if prevNode else "") + src_str, False)
                else:
                    if rawSpacing:
                        blankCount = max(0, spacing - 1)
                    else:
                        blankCount = 1 if spacing > 1 else 0
                    for _ in range(blankCount):
                        result.add("")
                    result.add(sourceFragment)

                prevNode = node
        return result

    def isEgCleanupElse(self):
        if getattr(self, "blockType", None) != ASTBlock.BlockType["Else"] or not getattr(self, "nodes", None) or len(self.nodes) == 0:
            return False
        def check(node):
            fragment = node.codeFragment() if hasattr(node, "codeFragment") else ''
            if isinstance(fragment, str):
                if '##ERROR##' in fragment:
                    return True
                if fragment.startswith('del '):
                    return True
                if ' = None' in fragment:
                    return True
            return False
        return all(check(node) for node in self.nodes)

    def requiresModuleSpacing(self, prevNode, node):
        if not self.isModuleLevel or not prevNode or not node:
            return False
        def isDefinition(candidate):
            return (isinstance(candidate, ASTStore) and
                    (isinstance(candidate.src, ASTFunction) or
                     isinstance(candidate.src, ASTClass) or
                     isinstance(candidate.src, ASTTypeAlias)))
        def isTypeAliasStore(candidate):
            return isinstance(candidate, ASTStore) and isinstance(candidate.src, ASTTypeAlias)
        def isAnnotatedStore(candidate):
            return isinstance(candidate, ASTStore) and isinstance(candidate.dest, ASTAnnotatedVar)
        def hasMetaTypeBase(candidate):
            if not isinstance(candidate, ASTStore) or not isinstance(candidate.src, ASTClass):
                return False
            bases = getattr(candidate.src, "bases", None)
            bvals = getattr(bases, "values", None) if bases else None
            if not isinstance(bvals, list):
                return False
            def base_check(b):
                frag = b.codeFragment() if b is not None and hasattr(b, "codeFragment") else None
                s = str(frag) if frag is not None else None
                return isinstance(s, str) and s.startswith('type(')
            return any(base_check(b) for b in bvals)

        prevIsDef = isDefinition(prevNode)
        nodeIsDef = isDefinition(node) or isinstance(node, ASTTypeAlias)

        if nodeIsDef:
            if isTypeAliasStore(prevNode) and isTypeAliasStore(node):
                return False
            if hasMetaTypeBase(node):
                return False
            return prevIsDef or isinstance(prevNode, ASTImport)

        # Ensure a blank line between a module-level definition and the following statement,
        # even when they share the same line number (3.13 adaptive cache collapses lines).
        if prevIsDef:
            return True
        if isAnnotatedStore(prevNode) and isAnnotatedStore(node):
            return True

        return False

    def __str__(self):
        return f"ASTNodeList: lines=[{self.line} - {self.lastLine}], {{\n{str(self.codeFragment())}\n}}"

    def toString(self):
        return self.__str__()


class ASTChainStore(ASTNodeList):
    def __init__(self, nodes, src):
        super().__init__(nodes)
        self.m_src = src

    @property
    def source(self):
        return self.m_src

    @property
    def line(self):
        lst = [self.m_lineNo, self.source.line] + [n.line for n in self.list if n.line > -1]
        return min(lst)

    @line.setter
    def line(self, value):
        self.m_lineNo = value

    @property
    def lastLine(self):
        lst = [self.m_lineNo, self.source.line] + [n.line for n in self.list if n.line > -1]
        return max(lst)

    def append(self, element):
        self.list.append(element)

    def codeFragment(self):
        if self.shouldSkipEgCleanupBlock():
            self.skip = True
            return ""

        result = PycResult("", True)

        if len(self.list) == 0:
            return "###FIXME###"
        chain = ' = '.join(str(node.codeFragment()) for node in self.list)
        result.add(chain)
        result.lastLineAppend(" = ", False)
        result.lastLineAppend(self.source.codeFragment())

        return result

    def __str__(self):
        return f"ASTChainStore: lines=[{self.line} - {self.lastLine}], {str(self.codeFragment())}"

    def toString(self):
        return self.__str__()

    def shouldSkipEgCleanupBlock(self):
        if getattr(self, "blockType", None) == ASTBlock.BlockType["Else"]:
            fragments = [(n.codeFragment() if hasattr(n, "codeFragment") else "") for n in (getattr(self, "nodes", None) or [])]
            if len(fragments) > 0 and all(isinstance(f, str) and ('##ERROR##' in f or ' = None' in f or f.startswith('del ')) for f in fragments):
                return True
        if (getattr(self, "blockType", None) == ASTBlock.BlockType["If"]
                and getattr(self, "nodes", None) and len(self.nodes) == 1):
            conditionStr = ""
            if getattr(self, "condition", None) and hasattr(self.condition, "codeFragment"):
                conditionStr = self.condition.codeFragment() or ""
            bodyStr = ""
            if self.nodes[0] is not None and hasattr(self.nodes[0], "codeFragment"):
                bodyStr = self.nodes[0].codeFragment() or ""
            if '__prep_reraise_star__' in str(conditionStr) and '__prep_reraise_star__' in str(bodyStr):
                return True
        return False


class ASTObject(ASTNode):
    def __init__(self, op=None):
        super().__init__()
        self.m_obj = op

    @property
    def object(self):
        return self.m_obj

    @object.setter
    def object(self, value):
        self.m_obj = value

    def codeFragment(self):
        if not self.object:
            return 'None'

        # Handle numeric literals with underscore formatting (Python 3.6+)
        if getattr(self.object, "ClassName", None) == 'Py_Int' and isinstance(getattr(self.object, "Value", None), (int, float)):
            num = self.object.Value
            # Add underscores for large integers (>= 10000) for readability
            if abs(num) >= 10000 and isinstance(num, int):
                sign = '-' if num < 0 else ''
                absStr = str(abs(num))
                # Add underscore every 3 digits from right
                parts = []
                i = len(absStr)
                while i > 0:
                    parts.insert(0, absStr[max(0, i - 3):i])
                    i -= 3
                return sign + '_'.join(parts)

        if getattr(self.object, "ClassName", None) in ("Py_String", "Py_Unicode"):
            raw = self.object.Value
            if raw is None or len(raw) == 0:
                return '""'
            if isinstance(raw, (bytes, bytearray)):
                # JS Buffer.toString() defaults to utf-8. Match that so Py2.x
                # string literals with real utf-8 bytes (BOMs, accented chars)
                # come out as the corresponding Unicode rather than the
                # latin-1 mojibake they looked like before.
                raw = raw.decode("utf-8", errors="replace")
            else:
                raw = str(raw)
            escaped = raw.replace('\\', '\\\\').replace('\n', '\\n').replace('\r', '\\r').replace('\t', '\\t')
            # Any remaining C0/DEL byte must be hex-escaped; leaving a raw
            # NUL or BEL in the source makes the output unparseable.
            escaped = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]",
                             lambda m: '\\x' + format(ord(m.group(0)), '02x'),
                             escaped)
            quote = '"'
            if '"' in escaped:
                if "'" not in escaped:
                    quote = "'"
                else:
                    escaped = escaped.replace('"', '\\"')
            return quote + escaped + quote

        result = self.object.toString() if hasattr(self.object, "toString") else str(self.object)
        if result is None:
            # JS `${null}` → "null"; Python f"{None}" → "None". PythonObject.toString()
            # returns None for classes without a case (e.g. Py_Ellipsis), and
            # fixtures expect the JS rendering here.
            return "null"
        return result

    def __str__(self):
        return f"ASTObject: lines=[{self.line} - {self.lastLine}], {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTUnary(ASTNode):
    UnaryOp = {
        "Positive": 0,
        "Negative": 1,
        "Invert": 2,
        "Not": 3,
        "Await": 4
    }
    UnaryOpString = ["+", "-", "~", "not ", "await "]

    def __init__(self, operand=None, op=None):
        super().__init__()
        self.m_op = op
        self.m_operand = operand

    @property
    def op(self):
        return self.m_op

    @property
    def operand(self):
        return self.m_operand

    def codeFragment(self):
        operand = self.operand.codeFragment() if self.operand is not None and hasattr(self.operand, "codeFragment") else '##ERROR##'
        return f"{ASTUnary.UnaryOpString[self.op]}{operand}"

    def __str__(self):
        return f"ASTUnary: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTBinary(ASTNode):
    BinOp = {
        "Attr": 0,
        "Power": 1,
        "Multiply": 2,
        "Divide": 3,
        "FloorDivide": 4,
        "Modulo": 5,
        "Add": 6,
        "Subtract": 7,
        "LeftShift": 8,
        "RightShift": 9,
        "And": 10,
        "Xor": 11,
        "Or": 12,
        "LogicalAnd": 13,
        "LogicalOr": 14,
        "MatrixMultiply": 15,
        "InplaceAdd": 16,
        "InplaceSubtract": 17,
        "InplaceMultiply": 18,
        "InplaceDivide": 19,
        "InplaceModulo": 20,
        "InplacePower": 21,
        "InplaceLeftShift": 22,
        "InplaceRightShift": 23,
        "InplaceAnd": 24,
        "InplaceXor": 25,
        "InplaceOr": 26,
        "InplaceFloorDivide": 27,
        "InplaceMatrixMultiply": 28,
        "InvalidOp": 29
    }

    def __init__(self, left=None, right=None, op=None):
        super().__init__()
        self.m_left = left
        self.m_right = right
        self.m_op = op

    @property
    def left(self):
        return self.m_left

    @property
    def right(self):
        return self.m_right

    @property
    def op(self):
        return self.m_op

    @property
    def line(self):
        return self.m_left.line if self.m_left else self.m_lineNo

    @line.setter
    def line(self, value):
        self.m_lineNo = value

    @property
    def lastLine(self):
        return self.m_right.line if self.m_right else self.m_lineNo

    @property
    def isInplace(self):
        return self.m_op >= ASTBinary.BinOp["InplaceAdd"]

    def op_str(self):
        return [
            ".", "**", " * ", " / ", " // ", " % ", " + ", " - ",
            " << ", " >> ", " & ", " ^ ", " | ", " and ", " or ", " @ ",
            " += ", " -= ", " *= ", " /= ", " %= ", " **= ", " <<= ",
            " >>= ", " &= ", " ^= ", " |= ", " //= ", " @= ", " <INVALID> "
        ][self.op]

    @staticmethod
    def from_opcode(opcode):
        if opcode == OpCodes.BINARY_ADD:
            return ASTBinary.BinOp["Add"]
        if opcode == OpCodes.BINARY_AND:
            return ASTBinary.BinOp["And"]
        if opcode == OpCodes.BINARY_DIVIDE:
            return ASTBinary.BinOp["Divide"]
        if opcode == OpCodes.BINARY_FLOOR_DIVIDE:
            return ASTBinary.BinOp["FloorDivide"]
        if opcode == OpCodes.BINARY_LSHIFT:
            return ASTBinary.BinOp["LeftShift"]
        if opcode == OpCodes.BINARY_MODULO:
            return ASTBinary.BinOp["Modulo"]
        if opcode == OpCodes.BINARY_MULTIPLY:
            return ASTBinary.BinOp["Multiply"]
        if opcode == OpCodes.BINARY_OR:
            return ASTBinary.BinOp["Or"]
        if opcode == OpCodes.BINARY_POWER:
            return ASTBinary.BinOp["Power"]
        if opcode == OpCodes.BINARY_RSHIFT:
            return ASTBinary.BinOp["RightShift"]
        if opcode == OpCodes.BINARY_SUBTRACT:
            return ASTBinary.BinOp["Subtract"]
        if opcode == OpCodes.BINARY_TRUE_DIVIDE:
            return ASTBinary.BinOp["Divide"]
        if opcode == OpCodes.BINARY_XOR:
            return ASTBinary.BinOp["Xor"]
        if opcode == OpCodes.BINARY_MATRIX_MULTIPLY:
            return ASTBinary.BinOp["MatrixMultiply"]
        if opcode == OpCodes.INPLACE_ADD:
            return ASTBinary.BinOp["InplaceAdd"]
        if opcode == OpCodes.INPLACE_AND:
            return ASTBinary.BinOp["InplaceAnd"]
        if opcode == OpCodes.INPLACE_DIVIDE:
            return ASTBinary.BinOp["InplaceDivide"]
        if opcode == OpCodes.INPLACE_FLOOR_DIVIDE:
            return ASTBinary.BinOp["InplaceFloorDivide"]
        if opcode == OpCodes.INPLACE_LSHIFT:
            return ASTBinary.BinOp["InplaceLeftShift"]
        if opcode == OpCodes.INPLACE_MODULO:
            return ASTBinary.BinOp["InplaceModulo"]
        if opcode == OpCodes.INPLACE_MULTIPLY:
            return ASTBinary.BinOp["InplaceMultiply"]
        if opcode == OpCodes.INPLACE_OR:
            return ASTBinary.BinOp["InplaceOr"]
        if opcode == OpCodes.INPLACE_POWER:
            return ASTBinary.BinOp["InplacePower"]
        if opcode == OpCodes.INPLACE_RSHIFT:
            return ASTBinary.BinOp["InplaceRightShift"]
        if opcode == OpCodes.INPLACE_SUBTRACT:
            return ASTBinary.BinOp["InplaceSubtract"]
        if opcode == OpCodes.INPLACE_TRUE_DIVIDE:
            return ASTBinary.BinOp["InplaceDivide"]
        if opcode == OpCodes.INPLACE_XOR:
            return ASTBinary.BinOp["InplaceXor"]
        if opcode == OpCodes.INPLACE_MATRIX_MULTIPLY:
            return ASTBinary.BinOp["InplaceMatrixMultiply"]
        return getattr(ASTBinary, "InvalidOp", ASTBinary.BinOp["InvalidOp"])

    @staticmethod
    def from_binary_op(operand):
        mapping = {
            0: ASTBinary.BinOp["Add"],
            1: ASTBinary.BinOp["And"],
            2: ASTBinary.BinOp["FloorDivide"],
            3: ASTBinary.BinOp["LeftShift"],
            4: ASTBinary.BinOp["MatrixMultiply"],
            5: ASTBinary.BinOp["Multiply"],
            6: ASTBinary.BinOp["Modulo"],
            7: ASTBinary.BinOp["Or"],
            8: ASTBinary.BinOp["Power"],
            9: ASTBinary.BinOp["RightShift"],
            10: ASTBinary.BinOp["Subtract"],
            11: ASTBinary.BinOp["Divide"],
            12: ASTBinary.BinOp["Xor"],
            13: ASTBinary.BinOp["InplaceAdd"],
            14: ASTBinary.BinOp["InplaceAnd"],
            15: ASTBinary.BinOp["InplaceFloorDivide"],
            16: ASTBinary.BinOp["InplaceLeftShift"],
            17: ASTBinary.BinOp["MatrixMultiply"],
            18: ASTBinary.BinOp["InplaceMultiply"],
            19: ASTBinary.BinOp["InplaceModulo"],
            20: ASTBinary.BinOp["InplaceOr"],
            21: ASTBinary.BinOp["InplacePower"],
            22: ASTBinary.BinOp["InplaceRightShift"],
            23: ASTBinary.BinOp["InplaceSubtract"],
            24: ASTBinary.BinOp["InplaceDivide"],
            25: ASTBinary.BinOp["InplaceXor"],
        }
        return mapping.get(operand, ASTBinary.BinOp["InvalidOp"])

    def codeFragment(self):
        def precedence(op):
            if op == ASTBinary.BinOp["Power"]:
                return 4
            if op in (ASTBinary.BinOp["Multiply"], ASTBinary.BinOp["Divide"],
                      ASTBinary.BinOp["FloorDivide"], ASTBinary.BinOp["Modulo"],
                      ASTBinary.BinOp["MatrixMultiply"]):
                return 3
            if op in (ASTBinary.BinOp["Add"], ASTBinary.BinOp["Subtract"]):
                return 2
            if op in (ASTBinary.BinOp["LeftShift"], ASTBinary.BinOp["RightShift"]):
                return 1
            # Python `and` binds tighter than `or`; ranking them so that
            # AND wrapping OR forces parens keeps `(b or c) and d` from
            # rendering as `b or c and d` (which parses as `b or (c and d)`).
            if op == ASTBinary.BinOp["LogicalAnd"]:
                return -1
            if op == ASTBinary.BinOp["LogicalOr"]:
                return -2
            return 0

        precThis = precedence(self.op)

        def wrapChild(child, position):
            fragment = (child.codeFragment() if child is not None and hasattr(child, "codeFragment") else None) or "##ERROR##"
            if isinstance(child, ASTBinary):
                childPrec = precedence(child.op)
                if childPrec < precThis or (self.op == ASTBinary.BinOp["Power"] and position == 'left'):
                    fragment = f"({fragment})"
            # `0.bit_length()` parses as a bad float literal; wrap integer
            # literal targets of attribute access in parens.
            if (self.op == ASTBinary.BinOp["Attr"] and position == 'left' and
                    isinstance(child, ASTObject) and
                    getattr(child.object, "ClassName", None) == 'Py_Int'):
                fragment = f"({fragment})"
            return fragment

        result = PycResult(f"{wrapChild(self.left, 'left')}{self.op_str()}", True)
        rightSideResult = wrapChild(self.right, 'right')
        result.lastLineAppend(rightSideResult)

        return result

    def __str__(self):
        return f"ASTBinary: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTCompare(ASTBinary):
    CompareOp = {
        "Less": 0,
        "LessEqual": 1,
        "Equal": 2,
        "NotEqual": 3,
        "Greater": 4,
        "GreaterEqual": 5,
        "In": 6,
        "NotIn": 7,
        "Is": 8,
        "IsNot": 9,
        "Exception": 10,
        "Bad": 11
    }

    def __init__(self, left=None, right=None, op=None):
        super().__init__(left, right, op)

    @property
    def isInplace(self):
        return False

    def op_str(self):
        return [
            " < ", " <= ", " == ", " != ", " > ", " >= ", " in ", " not in ",
            " is ", " is not ", "<EXCEPTION MATCH>", "<BAD>"
        ][self.op]

    def codeFragment(self):
        leftStr = (self.left.codeFragment() if self.left is not None else None) or "##ERROR##"
        rightStr = (self.right.codeFragment() if self.right is not None else None) or "##ERROR##"
        result = f"{leftStr}{self.op_str()}{rightStr}"
        return result

    def __str__(self):
        return f"ASTCompare: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTSlice(ASTBinary):
    SliceOp = {
        "Slice0": 0,
        "Slice1": 1,
        "Slice2": 2,
        "Slice3": 3
    }

    def __init__(self, op=None, left=None, right=None):
        left = left or ASTNone('')
        right = right or ASTNone('')
        super().__init__(left, right, op)

    @property
    def isInplace(self):
        return False

    def codeFragment(self):
        s = ''

        if self.op == ASTSlice.SliceOp["Slice0"]:
            s = '[:]'
        elif self.op == ASTSlice.SliceOp["Slice1"]:
            s = f"[{self.left.codeFragment()}:]"
        elif self.op == ASTSlice.SliceOp["Slice2"]:
            s = f"[:{self.right.codeFragment()}]"
        elif self.op == ASTSlice.SliceOp["Slice3"]:
            startRange = '' if isinstance(self.left, ASTNone) else self.left.codeFragment()
            endRange = '' if isinstance(self.right, ASTNone) else self.right.codeFragment()
            s = f"[{startRange}:{endRange}]"
        else:
            print(f"Slice op {self.op} is not defined.", file=sys.stderr)
        return s

    def __str__(self):
        return f"ASTSlice: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTStore(ASTNode):

    def __init__(self, src=None, dest=None):
        super().__init__()
        self.m_src = src
        self.m_dest = dest
        self.m_decorators = []

    @property
    def src(self):
        return self.m_src

    @src.setter
    def src(self, value):
        self.m_src = value

    @property
    def dest(self):
        return self.m_dest

    @dest.setter
    def dest(self, value):
        self.m_dest = value

    @property
    def decorators(self):
        return self.m_decorators

    @decorators.setter
    def decorators(self, value):
        self.m_decorators = value if value else []

    def addDecorator(self, decorator):
        if not self.m_decorators:
            self.m_decorators = []
        self.m_decorators.append(decorator)

    def codeFragment(self):
        result = PycResult("", True)
        argNames = []

        def toVarName(value, fallback=None):
            if value is not None and hasattr(value, "toString"):
                return value.toString()
            if value is not None:
                return str(value)
            return fallback if fallback else "###MISSING_VAR###"

        # Malformed store without source/dest – keep placeholder to avoid crashes.
        if not self.src or not self.dest:
            dest_frag = self.dest.codeFragment() if self.dest is not None and hasattr(self.dest, "codeFragment") else '##ERROR_STORE_DEST##'
            result.lastLineAppend(dest_frag)
            return result
        destName = (self.dest.codeFragment() if self.dest is not None and hasattr(self.dest, "codeFragment") else None) or '##ERROR_STORE_DEST##'

        # Handle type statements (PEP 695): prefer bare `type Name = ...`
        if isinstance(self.src, ASTTypeAlias):
            srcName = self.src.name
            if isinstance(srcName, str):
                matchName = srcName
            elif srcName is not None and hasattr(srcName, "name") and getattr(srcName, "name", None):
                matchName = srcName.name
            elif srcName is not None and hasattr(srcName, "codeFragment"):
                matchName = srcName.codeFragment()
            else:
                matchName = None
            if matchName and str(matchName) == str(destName):
                result.add(self.src.codeFragment())
                return result
            result.add(f"{destName} = {self.src.codeFragment()}")
            return result

        if isinstance(self.src, ASTFunction):
            codeObject = self.src.code.object
            inLambda = codeObject.Name == "<lambda>"

            if inLambda:
                result.add(f"{destName} = lambda")
            else:
                if not self.src.decorators.empty() if hasattr(self.src.decorators, "empty") else len(self.src.decorators) > 0:
                    for decorator in self.src.decorators:
                        dec_text = (decorator.codeFragment() if decorator is not None and hasattr(decorator, "codeFragment") else None) or '##ERROR_DECORATOR##'
                        result.add('@' + str(dec_text))
                if self.decorators and len(self.decorators) > 0:
                    for decorator in self.decorators:
                        decoText = decorator.codeFragment() if decorator is not None and hasattr(decorator, "codeFragment") else decorator
                        result.add('@' + str(decoText))
                # Check for async def (both coroutines and async generators)
                isAsync = (codeObject.Flags & ASTFunction.CodeFlags["CO_COROUTINE"]) or \
                          (codeObject.Flags & ASTFunction.CodeFlags["CO_ASYNC_GENERATOR"])
                result.add("async " if isAsync else "")
                typeParams = [renderTypeParam(tp) for tp in (self.src.typeParams or [])]
                typeParamsStr = f"[{', '.join(typeParams)}]" if typeParams else ""
                result.lastLineAppend(f"def {destName}{typeParamsStr}(")

            argIndex = 0
            if codeObject.ArgCount:
                default_params = self.src.defargs
                posOnlyCount = getattr(codeObject, "PosOnlyArgCount", 0) or 0

                # Unpack tuple defaults if needed (Python loads defaults as single tuple constant)
                if len(default_params) == 1 and isinstance(default_params[0], ASTTuple):
                    default_params = default_params[0].values

                # Process all regular args (positional-only + regular)
                for argIndex in range(codeObject.ArgCount):
                    varnames_value = codeObject.VarNames.Value if codeObject.VarNames is not None else None
                    rawName = toVarName(varnames_value[argIndex] if varnames_value is not None and argIndex < len(varnames_value) else None)
                    argName = rawName

                    # Add annotation from explicit map, if present
                    annNode = (self.src.annotations or {}).get(rawName) if self.src.annotations else None
                    if annNode:
                        ann_frag = (annNode.codeFragment() if hasattr(annNode, "codeFragment") else None) or (annNode.toString() if hasattr(annNode, "toString") else None) or '##ERROR##'
                        argName = f"{argName}: {ann_frag}"

                    # Add default value if present
                    if (argIndex + 1) > (codeObject.ArgCount - len(default_params)):
                        defaultIdx = argIndex - (codeObject.ArgCount - len(default_params))
                        defaultNode = default_params[defaultIdx]
                        annotation = self.extractAnnotationFromDefault(argName, defaultNode)
                        if annotation:
                            argName = f"{argName}: {annotation}"
                        elif defaultNode:
                            df = defaultNode.codeFragment() if hasattr(defaultNode, "codeFragment") else None
                            argName += "=" + (str(df) if df else '##ERROR##')
                    argNames.append(argName)

                    # Add / separator after positional-only args
                    if posOnlyCount > 0 and argIndex == posOnlyCount - 1:
                        argNames.append("/")

                argIndex = codeObject.ArgCount
                if codeObject.KWOnlyArgCount:
                    argNames.append("*")
                    default_params = self.src.kwdefargs
                    for kwIdx in range(codeObject.KWOnlyArgCount):
                        varnames_value = codeObject.VarNames.Value if codeObject.VarNames is not None else None
                        rawKwName = toVarName(varnames_value[argIndex] if varnames_value is not None and argIndex < len(varnames_value) else None)
                        argIndex += 1
                        argName = rawKwName

                        # Python syntax is `name: annotation = default`, so append the
                        # annotation first and the default afterwards.
                        kwAnn = (self.src.annotations or {}).get(rawKwName) if self.src.annotations else None
                        if kwAnn:
                            kw_frag = (kwAnn.codeFragment() if hasattr(kwAnn, "codeFragment") else None) or (kwAnn.toString() if hasattr(kwAnn, "toString") else None) or '##ERROR##'
                            argName = f"{argName}: {kw_frag}"
                        if default_params and len(default_params) > 0:
                            defaultIdx = kwIdx - (codeObject.KWOnlyArgCount - len(default_params))
                            if defaultIdx >= 0 and default_params[defaultIdx]:
                                dp = default_params[defaultIdx]
                                dp_value = dp['value'] if isinstance(dp, dict) else getattr(dp, 'value', None)
                                argName += "=" + (dp_value.codeFragment() if dp_value is not None else '##ERROR##')
                        argNames.append(argName)
            if codeObject.Flags & ASTFunction.CodeFlags["CO_VARARGS"]:
                varnames_value = codeObject.VarNames.Value if codeObject.VarNames is not None else None
                vaName = toVarName(varnames_value[argIndex] if varnames_value is not None and argIndex < len(varnames_value) else None)
                argIndex += 1
                entry = '*' + vaName
                vaAnn = (self.src.annotations or {}).get(vaName) if self.src.annotations else None
                if vaAnn:
                    va_frag = (vaAnn.codeFragment() if hasattr(vaAnn, "codeFragment") else None) or (vaAnn.toString() if hasattr(vaAnn, "toString") else None) or '##ERROR##'
                    entry += f": {va_frag}"
                if codeObject.KWOnlyArgCount:
                    # Replace the placeholder "*" we already pushed with the named varargs.
                    starIdx = argNames.index('*') if '*' in argNames else -1
                    if starIdx >= 0:
                        argNames[starIdx] = entry
                    else:
                        argNames.append(entry)
                else:
                    argNames.append(entry)
            if codeObject.Flags & ASTFunction.CodeFlags["CO_VARKEYWORDS"]:
                varnames_value = codeObject.VarNames.Value if codeObject.VarNames is not None else None
                vkName = toVarName(varnames_value[argIndex] if varnames_value is not None and argIndex < len(varnames_value) else None)
                argIndex += 1
                entry = '**' + vkName
                vkAnn = (self.src.annotations or {}).get(vkName) if self.src.annotations else None
                if vkAnn:
                    vk_frag = (vkAnn.codeFragment() if hasattr(vkAnn, "codeFragment") else None) or (vkAnn.toString() if hasattr(vkAnn, "toString") else None) or '##ERROR##'
                    entry += f": {vk_frag}"
                argNames.append(entry)

            # Lambda needs a space after the `lambda` keyword before params (shouldTrim would
            # eat it); `def X(` already has the opening paren and wants no leading space.
            if inLambda:
                result.lastLineAppend((" " if len(argNames) > 0 else "") + ", ".join(argNames), False)
            else:
                result.lastLineAppend(", ".join(argNames))

            if inLambda:
                result.lastLineAppend(": ", False)
            else:
                retAnn = (self.src.annotations or {}).get("return") if self.src.annotations else None
                if retAnn:
                    ret_frag = (retAnn.codeFragment() if hasattr(retAnn, "codeFragment") else None) or (retAnn.toString() if hasattr(retAnn, "toString") else None) or '##ERROR##'
                    result.lastLineAppend(f") -> {ret_frag}:")
                else:
                    result.lastLineAppend("):")

            result.increaseIndent()
            if getattr(codeObject.Globals, "size", None) or (hasattr(codeObject.Globals, "__len__") and len(codeObject.Globals) > 0):
                for globalVar in codeObject.Globals:
                    result.add("global " + str(globalVar))

            methodBody = codeObject.SourceCode.codeFragment()
            if inLambda:
                result.lastLineAppend(methodBody)
            else:
                bodyHasContent = methodBody and len(str(methodBody).strip())
                hasGlobals = codeObject.Globals and (getattr(codeObject.Globals, "size", None) or len(codeObject.Globals) > 0)
                if bodyHasContent:
                    result.add(methodBody)
                elif not hasGlobals:
                    result.add("pass")
            result.decreaseIndent()

        elif isinstance(self.src, ASTClass):
            allDecorators = list(self.src.decorators or []) + list(self.decorators or [])
            for decorator in allDecorators:
                decoText = decorator.codeFragment() if decorator is not None and hasattr(decorator, "codeFragment") else decorator
                result.add('@' + str(decoText))
            classNode = self.src
            typeParams = [renderTypeParam(tp) for tp in (classNode.typeParams or [])]
            typeParamsStr = f"[{', '.join(typeParams)}]" if typeParams else ""
            result.add(f"class {self.dest.codeFragment()}{typeParamsStr}")
            bases = (getattr(classNode.bases, "values", None) if classNode is not None and classNode.bases is not None else []) or []
            kwargs = classNode.kwargs or [] if classNode is not None else []
            baseStrs = [str((node.codeFragment() if node is not None else None) or "##ERROR##") for node in bases]
            def kwarg_str(kv):
                key = kv.get("key") if isinstance(kv, dict) else getattr(kv, "key", None)
                value = kv.get("value") if isinstance(kv, dict) else getattr(kv, "value", None)
                keyStr = None
                if key is not None and getattr(key, "object", None) and getattr(key.object, "Value", None) is not None:
                    keyStr = str(key.object.Value)
                elif key is not None and hasattr(key, "name") and getattr(key, "name", None):
                    keyStr = key.name
                elif isinstance(key, str):
                    keyStr = key
                elif key is not None and hasattr(key, "codeFragment"):
                    keyStr = str(key.codeFragment())
                valStr = str(value.codeFragment()) if value is not None and hasattr(value, "codeFragment") else "##ERROR##"
                return f"{keyStr}={valStr}"
            kwargStrs = [kwarg_str(kv) for kv in kwargs]
            headerArgs = baseStrs + kwargStrs
            if len(headerArgs) > 0:
                result.lastLineAppend(f"({', '.join(headerArgs)})", False)
            result.lastLineAppend(":")
            codeObject = None
            try:
                codeObject = classNode.code.func.code.object
            except Exception:
                pass
            if codeObject is None:
                try:
                    codeObject = classNode.code.code.object
                except Exception:
                    codeObject = {}
            src_code = getattr(codeObject, "SourceCode", None) if not isinstance(codeObject, dict) else codeObject.get("SourceCode")
            last_src = getattr(src_code, "last", None) if src_code is not None else None
            if isinstance(last_src, ASTReturn):
                src_code.list.pop()
            result.increaseIndent()
            classBodyNodeList = (getattr(src_code, "list", None) if src_code is not None else None) or []
            isSyntheticEmptyReturn = (
                len(classBodyNodeList) == 1 and
                classBodyNodeList[0].__class__.__name__ == 'ASTReturn' and
                isinstance(classBodyNodeList[0].value, ASTLocals)
            )
            if isSyntheticEmptyReturn:
                result.decreaseIndent()
                return result
            classBody = src_code.codeFragment() if src_code is not None and hasattr(src_code, "codeFragment") else None
            hasContent = classBody and len(str(classBody).strip())
            if _get_debug():
                first_cls = classBodyNodeList[0].__class__.__name__ if classBodyNodeList else None
                first_val = getattr(classBodyNodeList[0], 'value', None) if classBodyNodeList else None
                first_val_cls = first_val.__class__.__name__ if first_val is not None else None
                print(f"[ASTStore class render] name={getattr(self.dest, 'name', None)}, len={len(classBodyNodeList)}, first={first_cls}, retVal={first_val_cls}, isSyntheticEmptyReturn={isSyntheticEmptyReturn}, hasContent={hasContent}")
            if hasContent and not isSyntheticEmptyReturn:
                result.add(classBody)
            elif not isSyntheticEmptyReturn:
                result.add("pass")
            result.decreaseIndent()
        elif isinstance(self.src, ASTImport):
            result.lastLineAppend(self.src.codeFragment())
        elif isinstance(self.dest, ASTName) and self.dest.name == "__doc__" and getattr(self.src, "object", None):
            docRows = str(self.src.object).split("\\n") if not hasattr(self.src.object, "toString") else self.src.object.toString().split("\\n")
            result.add('"""')
            result.lastLineAppend(docRows.pop(0))
            for r in docRows:
                result.add(r)
            result.lastLineAppend('"""')
        else:
            if (isinstance(self.dest, ASTName) and self.dest.name == "__module__" and
                    isinstance(self.src, ASTName) and self.src.name == "__name__"):
                return ""
            if isinstance(self.dest, ASTTuple):
                self.dest.requireParens = False
            # Check if this is augmented assignment (+=, -=, etc.)
            src_op = getattr(self.src, "op", None) if self.src is not None else None
            if src_op is not None and src_op >= ASTBinary.BinOp["InplaceAdd"] and src_op != ASTBinary.BinOp["InvalidOp"]:
                # Compare dest and src.left by codeFragment to handle both simple names and attributes
                # IMPORTANT: codeFragment() returns PycResult object, need to convert to string
                destCode = str((self.dest.codeFragment() if self.dest is not None and hasattr(self.dest, "codeFragment") else '') or '')
                leftCode = str((self.src.left.codeFragment() if self.src.left is not None and hasattr(self.src.left, "codeFragment") else '') or '')

                if destCode == leftCode:
                    # Augmented assign: render as "a.value += 1" (src already contains the full expression)
                    # Don't add "a.value = " prefix - src.codeFragment() already includes "a.value += 1"
                    result.lastLineAppend((self.src.codeFragment() if self.src is not None and hasattr(self.src, "codeFragment") else None) or '##ERROR##')
                else:
                    # Regular assign where dest != src.left
                    result.lastLineAppend((self.dest.codeFragment() if self.dest is not None and hasattr(self.dest, "codeFragment") else None) or '##ERROR##')
                    result.lastLineAppend(" = ", False)
                    result.lastLineAppend((self.src.codeFragment() if self.src is not None and hasattr(self.src, "codeFragment") else None) or '##ERROR##')
            else:
                # Regular assignment
                result.lastLineAppend((self.dest.codeFragment() if self.dest is not None and hasattr(self.dest, "codeFragment") else None) or '##ERROR##')
                result.lastLineAppend(" = ", False)
                result.lastLineAppend((self.src.codeFragment() if self.src is not None and hasattr(self.src, "codeFragment") else None) or '##ERROR##')

        return result

    def extractAnnotationFromDefault(self, argName, defaultNode):
        if not isinstance(defaultNode, ASTTuple) or not defaultNode.values or len(defaultNode.values) != 2:
            return None

        keyNode, typeNode = defaultNode.values[0], defaultNode.values[1]
        keyValue = self.extractAnnotationKey(keyNode)
        if keyValue != argName:
            return None

        return self.renderAnnotationValue(typeNode)

    def extractAnnotationKey(self, node):
        if isinstance(node, ASTObject):
            v = getattr(node.object, "Value", None) if node.object is not None else None
            return str(v) if v is not None else None
        if node is not None and hasattr(node, "codeFragment"):
            fragment = node.codeFragment()
            s = str(fragment) if fragment is not None else None
            if isinstance(s, str):
                # Remove surrounding quotes if present
                if (s.startswith("'") and s.endswith("'")) or (s.startswith('"') and s.endswith('"')):
                    return s[1:len(s) - 1]
                return s
        return None

    def renderAnnotationValue(self, node):
        if not node:
            return None
        if isinstance(node, ASTName):
            return node.codeFragment()
        if hasattr(node, "codeFragment"):
            fragment = node.codeFragment()
            return str(fragment) if fragment is not None else None
        return None

    def __str__(self):
        return f"ASTStore: line={self.line}, {str(self.codeFragment())}"

    def toString(self):
        return self.__str__()


class ASTReturn(ASTNode):
    RetType = {
        "Return": 0,
        "Yield": 1,
        "YieldFrom": 2
    }

    def __init__(self, value=None, rettype=None):
        super().__init__()
        if rettype is None:
            rettype = ASTReturn.RetType["Return"]
        self.m_value = value
        self.m_rettype = rettype
        self.m_inlambda = False

    @property
    def value(self):
        return self.m_value

    @property
    def rettype(self):
        return self.m_rettype

    @property
    def inLambda(self):
        return self.m_inlambda

    @inLambda.setter
    def inLambda(self, value):
        self.m_inlambda = value

    def codeFragment(self):
        result = PycResult("", True)

        if not self.inLambda:
            if self.rettype == ASTReturn.RetType["Return"]:
                if not self.value or isinstance(self.value, ASTNone):
                    result.add("return")
                else:
                    result.add("return ")
                    result.lastLineAppend(self.value.codeFragment())
            elif self.rettype == ASTReturn.RetType["Yield"]:
                result.add("yield ")
                result.lastLineAppend(self.value.codeFragment())
            elif self.rettype == ASTReturn.RetType["YieldFrom"]:
                if isinstance(self.value, ASTAwaitable):
                    result.add("await ")
                    result.lastLineAppend((self.value.expression.codeFragment() if self.value.expression is not None else None) or "###FIXME###")
                else:
                    result.add("yield from ")
                    result.lastLineAppend(self.value.codeFragment())

            return result

        if self.rettype == ASTReturn.RetType["Yield"]:
            if not self.value or isinstance(self.value, ASTNone):
                return PycResult("(yield)", True)
            yres = PycResult("(yield ", True)
            yres.lastLineAppend(self.value.codeFragment())
            yres.lastLineAppend(")")
            return yres
        if self.rettype == ASTReturn.RetType["YieldFrom"]:
            yfres = PycResult("(yield from ", True)
            yfres.lastLineAppend(self.value.codeFragment())
            yfres.lastLineAppend(")")
            return yfres
        return (self.value.codeFragment() if self.value is not None else None) or ""

    def __str__(self):
        return f"{self.__class__.__name__}: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTNamedExpr(ASTNode):
    def __init__(self, target=None, value=None):
        super().__init__()
        self.m_target = target
        self.m_value = value
        self.m_requireParens = True

    @property
    def target(self):
        return self.m_target

    @property
    def value(self):
        return self.m_value

    @property
    def requireParens(self):
        return self.m_requireParens

    @requireParens.setter
    def requireParens(self, value):
        self.m_requireParens = value

    def codeFragment(self):
        targetStr = (self.target.codeFragment() if self.target is not None else None) or "##ERROR##"
        valueStr = (self.value.codeFragment() if self.value is not None else None) or "##ERROR##"
        expr = f"{targetStr} := {valueStr}"
        return f"({expr})" if self.requireParens else expr

    def __str__(self):
        return f"{self.__class__.__name__}: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTName(ASTNode):
    def __init__(self, name=None):
        super().__init__()
        self.m_name = name

    @property
    def name(self):
        return self.m_name

    @name.setter
    def name(self, value):
        self.m_name = value

    def codeFragment(self):
        return str(self.name) if self.name is not None else "##ERROR##"

    def __str__(self):
        return f"{self.__class__.__name__}: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTDelete(ASTNode):
    def __init__(self, value=None, rettype=None):
        super().__init__()
        self.m_value = value

    @property
    def value(self):
        return self.m_value

    def codeFragment(self):
        v = self.value.codeFragment() if self.value is not None else None
        result = f"del {str(v).strip() if v else '##ERROR##'}"
        return result

    def __str__(self):
        return f"{self.__class__.__name__}: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTFunction(ASTNode):

    CodeFlags = {
        "CO_OPTIMIZED": 0x1,
        "CO_NEWLOCALS": 0x2,
        "CO_VARARGS": 0x4,
        "CO_VARKEYWORDS": 0x8,
        "CO_NESTED": 0x10,
        "CO_GENERATOR": 0x20,
        "CO_NOFREE": 0x40,
        "CO_COROUTINE": 0x80,
        "CO_ITERABLE_COROUTINE": 0x100,
        "CO_ASYNC_GENERATOR": 0x200,
        "CO_GENERATOR_ALLOWED": 0x1000,
        "CO_FUTURE_DIVISION": 0x2000,
        "CO_FUTURE_ABSOLUTE_IMPORT": 0x4000,
        "CO_FUTURE_WITH_STATEMENT": 0x8000,
        "CO_FUTURE_PRINT_FUNCTION": 0x10000,
        "CO_FUTURE_UNICODE_LITERALS": 0x20000,
        "CO_FUTURE_BARRY_AS_BDFL": 0x40000,
        "CO_FUTURE_GENERATOR_STOP": 0x80000,
    }

    def __init__(self, code=None, defargs=None, kwdefargs=None):
        super().__init__()
        self.m_code = code
        self.m_defargs = defargs if defargs is not None else []
        self.m_kwdefargs = kwdefargs if kwdefargs is not None else []
        self.m_decorators = []
        self.m_annotations = {}
        self.m_typeParams = []

    @property
    def code(self):
        return self.m_code

    @property
    def defargs(self):
        return self.m_defargs

    @property
    def kwdefargs(self):
        return self.m_kwdefargs

    @property
    def line(self):
        return self.code.line

    @line.setter
    def line(self, _value):
        pass

    @property
    def lastLine(self):
        return self.code.lastLine

    @lastLine.setter
    def lastLine(self, _value):
        pass

    def add_decorator(self, name):
        self.m_decorators.insert(0, name)

    @property
    def decorators(self):
        return self.m_decorators

    @property
    def annotations(self):
        return self.m_annotations

    @annotations.setter
    def annotations(self, map_):
        self.m_annotations = map_ if map_ else {}

    @property
    def typeParams(self):
        return self.m_typeParams or []

    @typeParams.setter
    def typeParams(self, params):
        self.m_typeParams = params if params else []

    def codeFragment(self):
        result = "(lambda"
        codeObject = self.code.object

        argIndex = 0
        argNames = []
        if codeObject.ArgCount:
            default_params = self.defargs
            for idx in range(codeObject.ArgCount):
                argName = str(codeObject.VarNames.Value[argIndex])

                if (argIndex + 1) > (codeObject.ArgCount - len(default_params)):
                    argName += "=" + default_params[argIndex - (codeObject.ArgCount - len(default_params))].codeFragment()
                argIndex += 1
                argNames.append(argName)

            if codeObject.KWOnlyArgCount:
                default_params = self.kwdefargs
                firstFlag = True
                for idx in range(codeObject.KWOnlyArgCount):
                    argName = str(codeObject.VarNames.Value[argIndex])

                    if firstFlag:
                        argName = "*" + argName
                        firstFlag = False

                    if (argIndex + 1) > (codeObject.ArgCount - len(default_params)):
                        argName += "=" + default_params[argIndex - (codeObject.ArgCount - len(default_params))].codeFragment()
                    argIndex += 1
                    argNames.append(argName)
                if codeObject.Flags & ASTFunction.CodeFlags["CO_VARARGS"]:
                    argNames.append("*" + str(codeObject.VarNames.Value[argIndex]))
                    argIndex += 1
                if codeObject.Flags & ASTFunction.CodeFlags["CO_VARKEYWORDS"]:
                    argNames.append("**" + str(codeObject.VarNames.Value[argIndex]))
                    argIndex += 1
        result += (" " if len(argNames) > 0 else "") + ", ".join(argNames) + ": "
        codeObject.SourceCode.last.inLambda = True
        result += "; ".join(
            str(node.codeFragment()) for node in codeObject.SourceCode.list if len(str(node.codeFragment())) > 0
        ) + ")"
        return result

    def __str__(self):
        return f"{self.__class__.__name__}: lines=[{self.line} - {self.lastLine}], {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTClass(ASTNode):
    def __init__(self, code=None, bases=None, name=None):
        super().__init__()
        self.m_code = code
        self.m_bases = bases
        self.m_name = name
        self.m_typeParams = []
        self.m_kwargs = []
        self.m_decorators = []

    def add_decorator(self, decorator):
        self.m_decorators.insert(0, decorator)

    @property
    def decorators(self):
        return self.m_decorators

    @property
    def code(self):
        return self.m_code

    @property
    def bases(self):
        return self.m_bases

    @property
    def name(self):
        return self.m_name

    @property
    def kwargs(self):
        return self.m_kwargs or []

    @kwargs.setter
    def kwargs(self, value):
        self.m_kwargs = value if value else []

    @property
    def typeParams(self):
        return self.m_typeParams or []

    @typeParams.setter
    def typeParams(self, params):
        self.m_typeParams = params if params else []

    @property
    def line(self):
        return self.code.line

    @line.setter
    def line(self, _value):
        pass

    @property
    def lastLine(self):
        return self.code.lastLine

    @lastLine.setter
    def lastLine(self, _value):
        pass

    def codeFragment(self):
        result = f"#TODO {self.__class__.__name__} {self.code.codeFragment()}"
        return result

    def __str__(self):
        return f"{self.__class__.__name__}: lines=[{self.line} - {self.lastLine}], {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTCall(ASTNode):
    def __init__(self, func=None, pparams=None, kwparams=None):
        super().__init__()
        self.m_func = func
        self.m_pparams = pparams
        self.m_kwparams = kwparams
        self.m_var = None
        self.m_kw = None

    @property
    def func(self):
        return self.m_func

    @property
    def pparams(self):
        return self.m_pparams

    @property
    def kwparams(self):
        return self.m_kwparams

    @property
    def var(self):
        return self.m_var

    @var.setter
    def var(self, value):
        self.m_var = value

    @property
    def kw(self):
        return self.m_kw

    @kw.setter
    def kw(self, value):
        self.m_kw = value

    @property
    def hasVar(self):
        return self.m_var is not None

    @property
    def hasKw(self):
        return self.m_kw is not None

    def codeFragment(self):
        result = PycResult("", True)

        def formatParam(node):
            if not node:
                return "##ERROR##"
            if isinstance(node, ASTNamedExpr) and node.requireParens:
                # Avoid double-wrapping walrus expressions when used as call args.
                prev = node.requireParens
                node.requireParens = False
                frag = node.codeFragment()
                node.requireParens = prev
                return frag
            return node.codeFragment() or "##ERROR##"

        result.lastLineAppend(((self.func.codeFragment() if self.func is not None else None) or "##ERROR##") + '(')
        params = []
        if self.pparams is not None and len(self.pparams) > 0:
            params.append(', '.join(str(formatParam(n)) for n in self.pparams).strip())
        if self.kwparams is not None and len(self.kwparams) > 0:
            def render_kw(node):
                # Keyword key is stored as a Py_String/Py_Unicode; extract raw identifier
                # rather than stripping quotes from the rendered literal (which misses
                # double quotes when the name contains a single quote, etc).
                keyObj = node.get("key") if isinstance(node, dict) else getattr(node, "key", None)
                keyStr = None
                if keyObj is not None and getattr(keyObj, "object", None) and getattr(keyObj.object, "ClassName", None) in ['Py_String', 'Py_Unicode']:
                    keyStr = keyObj.object.toString() if hasattr(keyObj.object, "toString") else str(keyObj.object)
                else:
                    kf = keyObj.codeFragment() if keyObj is not None and hasattr(keyObj, "codeFragment") else ''
                    keyStr = re.sub(r"^['\"]|['\"]$", "", str(kf) if kf else '')
                val = node.get("value") if isinstance(node, dict) else getattr(node, "value", None)
                return f"{keyStr}={formatParam(val)}"
            params.append(', '.join(render_kw(n) for n in self.kwparams).strip())
        if self.hasVar:
            params.append('*' + str(self.var.codeFragment()))
        if self.hasKw:
            if isinstance(self.kw, ASTMapUnpack):
                for item in self.kw.items:
                    params.append('**' + (str(item.codeFragment()) if item is not None and hasattr(item, "codeFragment") else '##ERROR##'))
            else:
                params.append('**' + str(self.kw.codeFragment()))
        result.lastLineAppend(', '.join(params) + ')')
        return result

    def __str__(self):
        return f"{self.__class__.__name__}: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTImport(ASTNode):
    def __init__(self, name=None, fromlist=None, alias=None):
        super().__init__()
        self.m_name = name
        self.m_fromlist = fromlist
        self.m_alias = alias
        self.m_stores = []

    @property
    def name(self):
        return self.m_name

    @property
    def alias(self):
        return self.m_alias

    @alias.setter
    def alias(self, alias):
        self.m_alias = alias

    @property
    def stores(self):
        return self.m_stores

    @property
    def fromlist(self):
        return self.m_fromlist

    def add_store(self, store):
        self.stores.append(store)

    def codeFragment(self):
        result = None

        if not self.stores.empty() if hasattr(self.stores, "empty") else len(self.stores) > 0:
            name_frag = self.name.name.codeFragment() if isinstance(self.name, ASTImport) else self.name.codeFragment()
            result = f"from {name_frag} import "
            parts = []
            for el in self.stores:
                src_frag = el.src.codeFragment()
                part = f"{src_frag}"
                if el.dest and str(el.src.codeFragment()) != str(el.dest.codeFragment()):
                    part += ' as ' + str(el.dest.codeFragment())
                parts.append(part)
            result += ', '.join(parts)
        else:
            nextNode = self
            importNodes = []
            while nextNode:
                if not isinstance(nextNode, ASTImport):
                    break
                next_stores_empty = (nextNode.stores.empty() if hasattr(nextNode.stores, "empty") else len(nextNode.stores) == 0)
                if next_stores_empty and self.line == nextNode.line:
                    res = nextNode.name.codeFragment()
                    alias_frag = nextNode.alias.codeFragment() if nextNode.alias is not None else None
                    if nextNode.alias and str(nextNode.name.codeFragment()) != str(alias_frag):
                        res = f"{res} as {alias_frag}"
                    importNodes.append(str(res))
                    nextNode.skip = True
                else:
                    break
                nextNode = nextNode.nextSibling

            result = "import " + ", ".join(importNodes)
        return result

    def __str__(self):
        return f"ASTImport: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTTuple(ASTNode):
    def __init__(self, values=None):
        super().__init__()
        self.m_values = values if values is not None else []
        self.m_requireParens = True

    @property
    def values(self):
        return self.m_values

    @property
    def requireParens(self):
        return self.m_requireParens

    @requireParens.setter
    def requireParens(self, value):
        self.m_requireParens = value

    def add(self, name):
        self.values.append(name)

    def codeFragment(self):
        openParen = ''
        closeParen = ''

        if self.requireParens:
            openParen = '('
            closeParen = ')'

        # TODO: add new lines if tuple values are on different liens
        result = ASTNode.renderList(self.values, openParen, closeParen)
        return result

    def __str__(self):
        return f"ASTTuple: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTList(ASTNode):
    def __init__(self, values=None):
        super().__init__()
        self.m_values = values if values is not None else []

    @property
    def values(self):
        return self.m_values

    @property
    def line(self):
        return self.values[0].line if self.values else None

    @line.setter
    def line(self, value):
        self.m_lineNo = value

    @property
    def lastLine(self):
        return self.values[len(self.values) - 1].lastLine if self.values else None

    def codeFragment(self):
        result = ASTNode.renderList(self.values, '[', ']')
        return result

    def __str__(self):
        return f"ASTList: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTSet(ASTNode):
    def __init__(self, values=None):
        super().__init__()
        self.m_values = values if values is not None else []

    @property
    def values(self):
        return self.m_values

    @property
    def line(self):
        return self.values[0].lastLine if self.values else None

    @line.setter
    def line(self, value):
        self.m_lineNo = value

    @property
    def lastLine(self):
        return self.values[len(self.values) - 1].lastLine if self.values else None

    def add(self, value):
        # TODO: Should we validate uniqueness of the value?
        self.values.append(value)

    def codeFragment(self):
        result = ASTNode.renderList(self.values, '{', '}')
        return result

    def __str__(self):
        return f"ASTSet: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTMap(ASTNode):
    def __init__(self, values=None):
        super().__init__()
        self.m_values = values if values is not None else []

    @property
    def values(self):
        return self.m_values

    @property
    def lastLine(self):
        keys = list(self.values) if not isinstance(self.values, dict) else list(self.values.keys())
        return keys[len(keys) - 1].lastLine if keys else None

    def add(self, key, value):
        self.values.append({"key": key, "value": value})

    def codeFragment(self):
        result = ASTNode.renderList(
            self.values, '{', '}',
            lambda el: str(el["key"].codeFragment()) + ': ' + str(el["value"].codeFragment())
        )
        return result

    def __str__(self):
        return f"ASTMap: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


# Py 3.5: BUILD_MAP_UNPACK / BUILD_MAP_UNPACK_WITH_CALL push this. Each item is
# a mapping expression prefixed with ** at the source level. Items may be
# literal ASTMap or arbitrary expressions (names, subscripts, calls).
class ASTMapUnpack(ASTNode):
    def __init__(self, items=None):
        super().__init__()
        self.m_items = items if items is not None else []

    @property
    def items(self):
        return self.m_items

    def codeFragment(self):
        parts = ['**' + (str(item.codeFragment()) if item is not None and hasattr(item, "codeFragment") else '##ERROR##') for item in self.m_items]
        return '{' + ', '.join(parts) + '}'

    def __str__(self):
        return f"ASTMapUnpack: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTKwNamesMap(ASTNode):
    def __init__(self, values=None):
        super().__init__()
        self.m_values = values if isinstance(values, list) else []

    @property
    def values(self):
        return self.m_values

    @property
    def lastLine(self):
        keys = list(self.values)
        return keys[len(keys) - 1].lastLine if keys else None

    def add(self, key, value):
        if not self.m_values:
            self.m_values = []
        self.values.append({"key": key, "value": value})

    def codeFragment(self):
        result = '{' + ', '.join(str(el["key"].codeFragment()) + ': ' + str(el["value"].codeFragment()) for el in self.values) + '}'
        return result

    def __str__(self):
        return f"ASTKwNamesMap: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTConstMap(ASTNode):
    def __init__(self, keys=None, values=None):
        super().__init__()
        self.m_keys = keys if keys is not None else {}
        self.m_values = values if values is not None else {}

    @property
    def values(self):
        return self.m_values

    @property
    def keys(self):
        return self.m_keys

    @property
    def lastLine(self):
        return self.keys[len(self.keys) - 1].lastLine if self.keys else None

    def codeFragment(self):
        # Extract keys from ASTObject tuple
        keysArray = []
        if (isinstance(self.keys, ASTObject) and
                getattr(self.keys.object, "ClassName", None) in ('Py_Tuple', 'Py_SmallTuple')):
            keysArray = [ASTObject(v) for v in self.keys.object.Value]
        elif isinstance(self.keys, list):
            keysArray = self.keys

        # values is already an array (from dataStack.pop loop)
        # Reverse because values are popped from stack in reverse order
        valuesArray = list(reversed(self.values)) if isinstance(self.values, list) else []

        if len(keysArray) == 0:
            return '{}'

        pairs = []
        for i in range(len(keysArray)):
            keyStr = (keysArray[i].codeFragment() if i < len(keysArray) and keysArray[i] is not None else None) or '##ERROR##'
            valueStr = (valuesArray[i].codeFragment() if i < len(valuesArray) and valuesArray[i] is not None else None) or '##ERROR##'
            pairs.append(f"{keyStr}: {valueStr}")

        return '{' + ', '.join(pairs) + '}'

    def __str__(self):
        return f"ASTConstMap: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTSubscr(ASTNode):
    def __init__(self, name=None, key=None):
        super().__init__()
        self.m_name = name
        self.m_key = key

    @property
    def name(self):
        return self.m_name

    @property
    def key(self):
        return self.m_key

    @property
    def lastLine(self):
        return (self.key.lastLine if self.key is not None else -1) or -1

    def codeFragment(self):
        result = PycResult((self.name.codeFragment() if self.name is not None else None) or '##ERROR##', True)
        skipBrackets = isinstance(self.key, ASTSlice)

        if not skipBrackets:
            result.lastLineAppend('[')
        result.lastLineAppend((self.key.codeFragment() if self.key is not None else None) or "##ERROR##")
        if not skipBrackets:
            result.lastLineAppend(']')

        return result

    def __str__(self):
        return f"ASTSubscr: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTPrint(ASTNode):
    def __init__(self, value=None, stream=None):
        super().__init__()
        self.m_values = []
        self.m_stream = stream
        self.m_eol = False

        if value:
            self.m_values.append(value)
            self.m_eol = False
        else:
            self.m_eol = True

    @property
    def values(self):
        return self.m_values

    @property
    def stream(self):
        return self.m_stream

    @property
    def eol(self):
        return self.m_eol

    @eol.setter
    def eol(self, eol):
        self.m_eol = eol

    @property
    def lastLine(self):
        return self.values[len(self.values) - 1].lastLine if self.values else None

    def add(self, value):
        self.values.append(value)

    def codeFragment(self):
        result = "print"

        if self.stream:
            result += f" >> {self.stream.codeFragment()}"

        result += ' ' + ', '.join(str(n.codeFragment()) for n in self.values) + ('' if self.eol else ',')

        return result

    def __str__(self):
        return f"ASTPrint: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTConvert(ASTNode):
    def __init__(self, name=None):
        super().__init__()
        self.m_name = name

    @property
    def name(self):
        return self.m_name

    def codeFragment(self):
        result = "`" + self.name.codeFragment() + "`"
        return result

    def __str__(self):
        return f"ASTPrint: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTKeyword(ASTNode):
    Word = {
        "Pass": 0,
        "Break": 1,
        "Continue": 2
    }

    def __init__(self, key=None):
        super().__init__()
        self.m_key = key

    @property
    def key(self):
        return self.m_key

    @property
    def word(self):
        return ["pass", "break", "continue"][self.key]

    def codeFragment(self):
        return PycResult(self.word, True)

    def __str__(self):
        return f"ASTKeyword: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTRaise(ASTNode):
    def __init__(self, params=None, fromClause=False):
        super().__init__()
        self.m_params = params if params is not None else []
        self.m_fromClause = fromClause

    @property
    def params(self):
        return self.m_params

    @property
    def lastLine(self):
        return self.params[len(self.params) - 1].lastLine if self.params else None

    def codeFragment(self):
        if not self.params or len(self.params) == 0:
            return 'raise'
        if self.m_fromClause and len(self.params) == 2:
            return 'raise ' + str(self.params[0].codeFragment()) + ' from ' + str(self.params[1].codeFragment())
        return 'raise ' + ', '.join(str(n.codeFragment()) for n in self.params)

    def __str__(self):
        return f"ASTRaise: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTExec(ASTNode):
    def __init__(self, stmt=None, glob=None, loc=None):
        super().__init__()
        self.m_stmt = stmt
        self.m_glob = glob
        self.m_loc = loc

    @property
    def statement(self):
        return self.m_stmt

    @property
    def globals(self):
        return self.m_glob

    @property
    def locals(self):
        return self.m_loc

    def codeFragment(self):
        result = f"exec {self.statement.codeFragment()}"

        if self.globals:
            result += f" in {self.globals.codeFragment()}"
            # JS compares method references; on the same class these are
            # shared on the prototype (equal), so `exec X in G, L` collapses to
            # `exec X in G` whenever globals and locals are the same AST class.
            # Python's bound methods differ per-instance, so we compare the
            # unbound class-level functions to preserve JS parity.
            if self.locals and type(self.globals).codeFragment is not type(self.locals).codeFragment:
                result += f", {self.locals.codeFragment()}"

        return result

    def __str__(self):
        return f"ASTRaise: line={self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTIteratorValue(ASTNode):
    def __init__(self, value=None):
        super().__init__()
        self.m_value = value

    @property
    def value(self):
        return self.m_value


class ASTBlock(ASTNode):
    BlockType = {
        "Main": 0,
        "If": 1,
        "Else": 2,
        "Elif": 3,
        "Try": 4,
        "Container": 5,
        "Except": 6,
        "Finally": 7,
        "While": 8,
        "For": 9,
        "With": 10,
        "AsyncFor": 11,
        "AsyncWith": 12
    }

    def __init__(self, blockType=None, start=0, end=0, inited=0):
        super().__init__()
        if blockType is None:
            blockType = ASTBlock.BlockType["Main"]
        self.m_blockType = blockType
        self.m_nodes = []
        self.m_start = start
        self.m_end = end
        self.m_inited = inited
        self.m_isExceptStar = False

    @property
    def blockType(self):
        return self.m_blockType

    @property
    def nodes(self):
        return self.m_nodes

    @property
    def isExceptStar(self):
        return self.m_isExceptStar

    @isExceptStar.setter
    def isExceptStar(self, value):
        self.m_isExceptStar = value

    @property
    def size(self):
        return len(self.m_nodes)

    @property
    def start(self):
        return self.m_start

    @start.setter
    def start(self, value):
        self.m_start = value

    @property
    def end(self):
        return self.m_end

    @end.setter
    def end(self, value):
        self.m_end = value

    @property
    def inited(self):
        return self.m_inited

    @property
    def line(self):
        if self.m_lineNo > -1:
            return self.m_lineNo
        return (self.nodes[0].lastLine if self.nodes else -1) or -1

    @line.setter
    def line(self, lineNo):
        self.m_lineNo = lineNo

    @property
    def lastLine(self):
        return (self.nodes[len(self.nodes) - 1].lastLine if self.nodes else -1) or -1

    @property
    def type_str(self):
        return [
            "", "if", "else", "elif", "try", "CONTAINER", "except",
            "finally", "while", "for", "with", "async for", "async with"
        ][self.blockType]

    def init(self, value=1):
        if _get_debug() and self.blockType == ASTBlock.BlockType["AsyncFor"]:
            print(f"[ASTBlock.init] AsyncFor.init() called, setting inited={value}")
            import traceback
            traceback.print_stack()
        self.m_inited = value

    def removeFirst(self):
        self.nodes.pop(0)

    def removeLast(self):
        if self.nodes:
            self.nodes.pop()

    def append(self, node):
        self.nodes.append(node)

    def empty(self):
        return len(self.nodes) == 0

    def hasNestedBlocks(self):
        """
        Check if this block contains any nested blocks (if/elif/else/while/for/etc.)
        Used for elif detection to avoid converting nested if to elif
        """
        return any(isinstance(node, ASTBlock) for node in self.nodes)

    def codeFragment(self):
        result = PycResult("", True)

        if self.blockType == ASTBlock.BlockType["Else"] and (len(self.nodes) == 0):
            return ""

        header = self.type_str
        if self.blockType == ASTBlock.BlockType["Except"]:
            if self.isExceptStar:
                header = "except*"
            # Drop synthetic condition marker "__exception__<EXCEPTION MATCH>"
            condStr = None
            cond = getattr(self, "condition", None)
            if cond is not None and hasattr(cond, "codeFragment"):
                condStr = cond.codeFragment()
            isSynthetic = isinstance(condStr, str) and "__exception__<EXCEPTION MATCH>" in condStr
            if condStr and not isSynthetic:
                header += " "
                if isinstance(cond, ASTStore):
                    if cond.src:
                        header += str(cond.src.codeFragment())
                    if cond.dest:
                        header += " as " + str(cond.dest.codeFragment())
                else:
                    header += str(cond.codeFragment())
            result.add(header + ":")
            result.increaseIndent()
            firstNode = next((n for n in self.nodes if not isinstance(n, ASTBlock) and not isinstance(n, ASTCondBlock)), None)
            if firstNode:
                result.add(firstNode.codeFragment())
                if len(self.nodes) > 1:
                    nextNode = next((n for n in self.nodes if isinstance(n, ASTRaise)), None)
                    if nextNode:
                        result.add(nextNode.codeFragment())
            else:
                result.add("pass")
            result.decreaseIndent()
            return result
        result.add(header + ":")

        result.increaseIndent()
        if len(self.nodes) > 0:
            # Filter out undefined/null nodes first
            validNodes = [n for n in self.nodes if n is not None]
            # TODO: Refactor this code to use ASTNodeList that already natively handles that
            if len(validNodes) > 1 and not validNodes[0].nextSibling:
                prevNode = None

                for node in validNodes:
                    if prevNode:
                        prevNode.nextSibling = node
                    node.prevSibling = prevNode
                    prevNode = node

            # Filter synthetic cleanup/guards in except blocks
            renderNodes = validNodes
            if self.blockType == ASTBlock.BlockType["Except"]:
                def keep(node):
                    if not node or node.skip:
                        return False
                    condStr = None
                    nc = getattr(node, "condition", None)
                    if nc is not None and hasattr(nc, "codeFragment"):
                        condStr = nc.codeFragment()
                    if isinstance(node, ASTBlock) or isinstance(node, ASTCondBlock):
                        if isinstance(condStr, str) and "__exception__<EXCEPTION MATCH>" in condStr:
                            return False
                    if (isinstance(node, ASTStore) and
                            isinstance(node.dest, ASTName) and
                            isinstance(node.src, ASTNone)):
                        return False
                    return True
                renderNodes = [n for n in validNodes if keep(n)]

            if self.blockType == ASTBlock.BlockType["Except"]:
                # Render only first non-block node to avoid runaway nesting
                firstNode = next((n for n in renderNodes if not isinstance(n, ASTBlock) and not isinstance(n, ASTCondBlock)), None)
                if firstNode:
                    result.add(firstNode.codeFragment())
                else:
                    result.add("pass")
            else:
                # Emit body nodes first, then trailing dedented handlers. If
                # every body node was `skip`-ed (e.g. Try body whose sole
                # child was consumed by ternary collapse), the block would
                # print `try:` with no body — inject a `pass` placeholder so
                # the resulting source stays parseable.
                emittedBodyNode = False
                handlerTail = []
                for node in renderNodes:
                    if not node or node.skip:
                        continue
                    isHandler = (getattr(node, "blockType", None) == ASTBlock.BlockType["Except"]
                                 or getattr(node, "blockType", None) == ASTBlock.BlockType["Finally"])
                    if isHandler:
                        handlerTail.append(node)
                    else:
                        result.add(node.codeFragment())
                        emittedBodyNode = True
                if not emittedBodyNode:
                    result.add("pass")
                for h in handlerTail:
                    result.decreaseIndent()
                    result.add(h.codeFragment())
                    result.increaseIndent()
        else:
            result.add("pass")
        result.decreaseIndent()

        return result

    def __str__(self):
        return f"{self.type_str} block: {{{self.start} - {self.end}}}"

    def toString(self):
        return self.__str__()


class ASTCondBlock(ASTBlock):
    InitCondition = {
        "Uninited": 0,
        "Popped": 1,
        "PrePopped": 2
    }

    def __init__(self, blockType=None, start=0, end=0, cond=None, negative=False):
        super().__init__(blockType, start, end)
        self.m_cond = cond
        self.m_negative = negative

    @property
    def condition(self):
        return self.m_cond

    @condition.setter
    def condition(self, cond):
        self.m_cond = cond

    @property
    def negative(self):
        return self.m_negative

    @negative.setter
    def negative(self, neg):
        self.m_negative = neg

    def codeFragment(self):
        result = PycResult("", True)

        # This is the assert case
        if (self.blockType == ASTBlock.BlockType["If"] and self.negative and self.condition
                and len(self.nodes) == 1 and isinstance(self.nodes[0], ASTRaise)):
            result.lastLineAppend("assert ", False)
            result.lastLineAppend(self.condition.codeFragment())
            if (len(self.nodes) == 1 and isinstance(self.nodes[0], ASTRaise)
                    and len(self.nodes[0].params) == 1 and isinstance(self.nodes[0].params[0], ASTCall)):
                result.lastLineAppend(', ' + ", ".join(str(n.codeFragment()) for n in self.nodes[0].params[0].pparams))
            return result

        ns = self.nextSibling
        next_type = getattr(ns, "type", None) if ns is not None else None
        next_nodes = getattr(ns, "nodes", None) if ns is not None else None
        next_value_line = None
        if ns is not None and hasattr(ns, "value") and getattr(ns, "value", None) is not None:
            next_value_line = ns.value.line
        if (isinstance(self.prevSibling, ASTStore) and
                self.blockType == ASTBlock.BlockType["If"] and
                len(self.nodes) == 1 and
                isinstance(ns, ASTCondBlock) and
                next_type == ASTBlock.BlockType["Else"] and
                next_nodes is not None and len(next_nodes) == 1 and
                self.condition.line >= 0 and
                self.condition.line == self.nodes[0].line and
                self.condition.line == ns.nodes[0].line):
            result.add((self.nodes[0].codeFragment() if self.nodes[0] is not None else None) or "###ERROR###")
            result.lastLineAppend(" if", False)
            result.lastLineAppend(" not" if self.negative else "", False)
            result.lastLineAppend(" ", False)
            result.lastLineAppend((self.condition.codeFragment() if self.condition is not None else None) or "True")
            result.lastLineAppend(" else ", False)
            result.lastLineAppend((ns.nodes[0].codeFragment() if ns.nodes[0] is not None else None) or "###ERROR###")
            ns.skip = True
        elif (self.prevSibling is None and
              self.blockType == ASTBlock.BlockType["If"] and
              len(self.nodes) == 1 and
              isinstance(ns, ASTReturn) and
              self.condition.line == self.nodes[0].line and
              self.condition.line == next_value_line):
            result.add((self.nodes[0].codeFragment() if self.nodes[0] is not None else None) or "###ERROR###")
            result.lastLineAppend(" if", False)
            result.lastLineAppend(" not" if self.negative else "", False)
            result.lastLineAppend(" ", False)
            result.lastLineAppend((self.condition.codeFragment() if self.condition is not None else None) or "True")
            result.lastLineAppend(" else ", False)
            result.lastLineAppend((ns.value.codeFragment() if ns.value is not None else None) or "###ERROR###")
            ns.skip = True
        else:
            header = self.type_str
            if self.blockType == ASTBlock.BlockType["Except"] and self.isExceptStar:
                header = "except*"
            result.add(header)
            if self.blockType in (ASTBlock.BlockType["If"], ASTBlock.BlockType["Elif"], ASTBlock.BlockType["While"]):
                result.lastLineAppend(" not" if self.negative else "", False)
                result.lastLineAppend(" ", False)

                # For while loops without explicit condition (null), use "1" instead of "True" (Python convention: while 1:)
                conditionStr = self.condition.codeFragment() if self.condition is not None else None
                if not conditionStr:
                    conditionStr = "1" if self.blockType == ASTBlock.BlockType["While"] else "True"
                result.lastLineAppend(conditionStr)
            elif self.blockType == ASTBlock.BlockType["Except"] and self.condition:
                if isinstance(self.condition, ASTStore):
                    result.lastLineAppend(" ", False)
                    if self.condition.src:
                        result.lastLineAppend(self.condition.src.codeFragment())
                    result.lastLineAppend(" as ", False)
                    if self.condition.dest:
                        result.lastLineAppend(self.condition.dest.codeFragment())
                elif self.condition:
                    result.lastLineAppend(" ", False)
                    result.lastLineAppend(self.condition.codeFragment())

            result.lastLineAppend(":")
            result.increaseIndent()

            # Filter nodes for rendering (exclude synthetic __exception__ variables from except blocks)
            def keep(node):
                if not node:
                    return False
                # Filter out synthetic __exception__ variables from except blocks
                if (self.blockType == ASTBlock.BlockType["Except"] and
                        isinstance(node, ASTName) and
                        node.name == '__exception__'):
                    return False
                # Inside an except body, an empty else block is a control-flow
                # artifact (JUMP_ABSOLUTE leaving the handler with no body);
                # keeping it leaves the handler visually empty without `pass`.
                if (self.blockType == ASTBlock.BlockType["Except"] and
                        isinstance(node, ASTBlock) and
                        node.blockType == ASTBlock.BlockType["Else"] and
                        node.empty()):
                    return False
                return node and not node.skip and hasattr(node, "codeFragment")
            nodesToRender = [n for n in self.nodes if n]
            nodesToRender = [n for n in nodesToRender if keep(n)]

            if len(nodesToRender) == 0:
                result.add("pass")
            else:
                # TODO: Refactor this code to use ASTNodeList that already natively handles that
                firstRenderable = nodesToRender[0] if nodesToRender else None
                if len(nodesToRender) > 1 and firstRenderable and not firstRenderable.nextSibling:
                    prevNode = None
                    for node in nodesToRender:
                        if not node:
                            continue
                        if prevNode:
                            prevNode.nextSibling = node
                        node.prevSibling = prevNode
                        prevNode = node
                for node in nodesToRender:
                    result.add(node.codeFragment())
            result.decreaseIndent()
        return result

    def __str__(self):
        return f"{self.type_str} block: {{{self.start} - {self.end}}}"

    def toString(self):
        return self.__str__()


class ASTIterBlock(ASTBlock):
    def __init__(self, blockType=None, start=0, end=0, iter=None):
        super().__init__(blockType, start, end)
        self.m_iter = iter
        self.m_idx = None
        self.m_cond = None
        self.m_comp = False

    @property
    def start(self):
        return self.m_start

    @start.setter
    def start(self, value):
        self.m_start = value

    @property
    def iter(self):
        return self.m_iter

    @iter.setter
    def iter(self, value):
        self.m_iter = value

    @property
    def index(self):
        return self.m_idx

    @index.setter
    def index(self, value):
        self.m_idx = value

    @property
    def condition(self):
        return self.m_cond

    @condition.setter
    def condition(self, value):
        self.m_cond = value

    @property
    def comprehension(self):
        return self.m_comp

    @comprehension.setter
    def comprehension(self, value):
        self.m_comp = value

    def codeFragment(self):
        result = PycResult("", True)

        # Add "async" prefix for async for loops
        if self.blockType == ASTBlock.BlockType["AsyncFor"]:
            result.lastLineAppend("async for ", False)
        else:
            result.lastLineAppend("for ", False)

        result.lastLineAppend((self.index.codeFragment() if self.index is not None else None) or "##ERROR##")
        result.lastLineAppend(" in ", False)
        result.lastLineAppend((self.iter.codeFragment() if self.iter is not None else None) or "##ERROR##")
        result.lastLineAppend(":")
        result.increaseIndent()
        body = [n for n in self.nodes if n]
        if len(body) == 0:
            result.add("pass")
        else:
            for node in body:
                result.add(node.codeFragment())
        result.decreaseIndent()

        return result

    def __str__(self):
        return f"{self.type_str} block: {{{self.start} - {self.end}}}"

    def toString(self):
        return self.__str__()


class ASTContainerBlock(ASTBlock):
    def __init__(self, start=0, _finally=None, except_=0):
        super().__init__(ASTBlock.BlockType["Container"], start)
        self.m_finally = _finally
        self.m_except = except_

    @property
    def finally_(self):
        return self.m_finally

    @finally_.setter
    def finally_(self, value):
        self.m_finally = value

    @property
    def hasFinally(self):
        return bool(self.m_finally)

    @property
    def except_(self):
        return self.m_except

    @except_.setter
    def except_(self, value):
        self.m_except = value

    @property
    def hasExcept(self):
        return bool(self.m_except)

    def codeFragment(self):
        result = PycResult("", True)

        for node in [el for el in self.nodes if isinstance(el, ASTNode)]:
            result.add(node.codeFragment())

        return result

    def __str__(self):
        return f"{self.type_str} block: {{{self.start} - {self.end}}}"

    def toString(self):
        return self.__str__()


class ASTWithBlock(ASTBlock):
    def __init__(self, start=0, end=0):
        super().__init__(ASTBlock.BlockType["With"], start, end)
        self.m_expr = None
        self.m_var = None

    @property
    def expr(self):
        return self.m_expr

    @expr.setter
    def expr(self, value):
        self.m_expr = value

    @property
    def var(self):
        return self.m_var

    @var.setter
    def var(self, value):
        self.m_var = value

    def codeFragment(self):
        result = PycResult()
        result.doNotIndent = True

        result.lastLineAppend("with ", False)
        exprCode = self.expr.codeFragment() if self.expr is not None and hasattr(self.expr, "codeFragment") else "None"
        result.lastLineAppend(exprCode)

        if self.var:
            result.lastLineAppend(" as ", False)
            result.lastLineAppend(self.var.codeFragment())

        result.lastLineAppend(":")
        result.increaseIndent()
        body = [n for n in self.nodes if n]
        if len(body) == 0:
            result.add("pass")
        else:
            for node in body:
                result.add(node.codeFragment())
        result.decreaseIndent()

        return result

    def __str__(self):
        return f"{self.type_str} block: {{{self.start} - {self.end}}}"

    def toString(self):
        return self.__str__()


class ASTAsyncWithBlock(ASTBlock):
    def __init__(self, start=0, end=0):
        super().__init__(ASTBlock.BlockType["AsyncWith"], start, end)
        self.m_expr = None
        self.m_var = None

    @property
    def expr(self):
        return self.m_expr

    @expr.setter
    def expr(self, value):
        self.m_expr = value

    @property
    def var(self):
        return self.m_var

    @var.setter
    def var(self, value):
        self.m_var = value

    def codeFragment(self):
        result = PycResult()
        result.doNotIndent = True

        result.lastLineAppend("async with ", False)
        exprCode = self.expr.codeFragment() if self.expr is not None and hasattr(self.expr, "codeFragment") else "None"
        result.lastLineAppend(exprCode)

        if self.var:
            result.lastLineAppend(" as ", False)
            result.lastLineAppend(self.var.codeFragment())

        result.lastLineAppend(":")
        result.increaseIndent()
        body = [n for n in self.nodes if n]
        if len(body) == 0:
            result.add("pass")
        else:
            for node in body:
                result.add(node.codeFragment())
        result.decreaseIndent()

        return result

    def __str__(self):
        return f"{self.type_str} block: {{{self.start} - {self.end}}}"

    def toString(self):
        return self.__str__()


class ASTComprehension(ASTNode):

    LIST = 0
    SET = 1
    DICT = 2
    GENERATOR = 3

    def __init__(self, result=None, key=None):
        super().__init__()
        self.m_kind = ASTComprehension.LIST
        self.m_key = key
        self.m_result = result
        self.m_generators = []

    @property
    def kind(self):
        return self.m_kind

    @kind.setter
    def kind(self, value):
        self.m_kind = value

    @property
    def key(self):
        return self.m_key

    @key.setter
    def key(self, value):
        self.m_key = value

    @property
    def result(self):
        return self.m_result

    @property
    def generators(self):
        return self.m_generators

    @property
    def lastLine(self):
        return self.generators[len(self.generators) - 1].lastLine if self.generators else None

    def addGenerator(self, generator):
        self.generators.insert(0, generator)

    def codeFragment(self):
        openingBracket = '['
        closingBracket = ']'

        if self.kind in (ASTComprehension.SET, ASTComprehension.DICT):
            openingBracket = '{'
            closingBracket = '}'
        elif self.kind == ASTComprehension.GENERATOR:
            openingBracket = '('
            closingBracket = ')'

        if not self.result:
            return f"{openingBracket}##ERROR##{closingBracket}"

        result = f"{openingBracket}"
        if self.kind == ASTComprehension.DICT:
            result += ((self.key.codeFragment() if self.key is not None else None) or "##ERROR##") + ": "
        result += (self.result.codeFragment() if self.result is not None and hasattr(self.result, "codeFragment") else None) or "##ERROR##"

        gen_strs = []
        for gen in self.generators:
            asyncPrefix = 'async ' if gen.blockType == ASTBlock.BlockType["AsyncFor"] else ''
            idx_frag = gen.index.codeFragment() if gen.index is not None and hasattr(gen.index, "codeFragment") else None
            iter_frag = gen.iter.codeFragment() if gen.iter is not None and hasattr(gen.iter, "codeFragment") else None
            genString = f" {asyncPrefix}for {idx_frag or '##ERROR##'} in {iter_frag or '##ERROR##'}"

            if gen.condition:
                cond_frag = gen.condition.codeFragment() if hasattr(gen.condition, "codeFragment") else None
                genString += f" if {cond_frag or '##ERROR##'}"

            gen_strs.append(genString)
        result += "".join(gen_strs) + closingBracket

        return result

    def __str__(self):
        return f"ASTComprehension: {{{self.start} - {self.end}}}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTLoadBuildClass(ASTNode):
    def __init__(self, obj=None):
        super().__init__()
        self.m_obj = obj

    @property
    def object(self):
        return self.m_obj

    def codeFragment(self):
        return ""

    def __str__(self):
        return f"ASTLoadBuildClass: [{self.line} - {self.lastLine}], {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTAwaitable(ASTNode):
    def __init__(self, expr=None):
        super().__init__()
        self.m_expr = expr

    @property
    def expression(self):
        return self.m_expr

    def codeFragment(self):
        # await <expression>
        inner = self.m_expr.codeFragment() if self.m_expr is not None and hasattr(self.m_expr, "codeFragment") else "None"
        return f"await {inner}"

    def __str__(self):
        return f"ASTAwaitable: [{self.line} - {self.lastLine}], {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTFormattedValue(ASTNode):
    ConversionFlag = {
        "None": 0,
        "Str": 1,
        "Repr": 2,
        "ASCII": 3,
        "FmtSpec": 4
    }

    def __init__(self, val=None, conversion=None, format_spec=None):
        super().__init__()
        self.m_val = val
        self.m_conversion = conversion
        self.m_format_spec = format_spec

    @property
    def val(self):
        return self.m_val

    @property
    def conversion(self):
        return self.m_conversion

    @property
    def format_spec(self):
        return self.m_format_spec

    def codeFragment(self, outerQuote=None):
        # Format: {value} or {value!r} or {value:.2f}
        # `outerQuote` is set only when this FormattedValue is being rendered
        # inside an enclosing f-string; nested strings must then use the
        # opposite delimiter so the outer string does not close prematurely.
        if outerQuote == '"':
            innerQuote = "'"
        elif outerQuote == "'":
            innerQuote = '"'
        else:
            innerQuote = '"'
        result = "{"

        if self.m_val:
            if isinstance(self.m_val, ASTJoinedStr):
                # Only force a flipped quote when we actually have an outer
                # f-string; otherwise let the nested string keep its default.
                if outerQuote:
                    result += self.m_val.codeFragment(innerQuote)
                else:
                    result += self.m_val.codeFragment()
            else:
                result += self.m_val.codeFragment()

        # Add conversion flag (!s, !r, !a)
        if self.m_conversion == ASTFormattedValue.ConversionFlag["Str"]:
            result += "!s"
        elif self.m_conversion == ASTFormattedValue.ConversionFlag["Repr"]:
            result += "!r"
        elif self.m_conversion == ASTFormattedValue.ConversionFlag["ASCII"]:
            result += "!a"

        # Add format spec (:.2f, :x, etc.)
        if self.m_format_spec:
            result += ":"
            # Format spec can be ASTJoinedStr (nested f-string) or string constant
            if isinstance(self.m_format_spec, ASTJoinedStr):
                # Format-spec content is already inside the outer f-string's
                # braces, so its literal parts must not use the outer quote.
                specQuote = innerQuote if outerQuote else '"'
                result += self.m_format_spec.codeFragment(specQuote, True)
            elif isinstance(self.m_format_spec, ASTObject):
                # String constant like ".2f"
                spec_val = self.m_format_spec.object.Value
                if isinstance(spec_val, (bytes, bytearray)):
                    spec_val = spec_val.decode("latin-1")
                result += spec_val
            else:
                result += self.m_format_spec.codeFragment()

        result += "}"
        return result

    def __str__(self):
        return f"{self.__class__.__name__}: Line {self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTJoinedStr(ASTNode):
    def __init__(self, values=None):
        super().__init__()
        self.m_values = values

    @property
    def values(self):
        return self.m_values

    @property
    def lastLine(self):
        return self.values[len(self.values) - 1].lastLine if self.values else None

    def codeFragment(self, quoteChar='"', bareInnerForFormatSpec=False):
        # PEP 750 t-strings use t"..." prefix; otherwise f-string.
        # `quoteChar` lets nested f-strings pick the opposite delimiter so
        # they don't collide with the enclosing string. `bareInnerForFormatSpec`
        # skips the f"..." wrapper entirely (used when this ASTJoinedStr is a
        # format spec nested inside {...}).
        prefix = 't' if getattr(self, "isTemplateString", False) else 'f'
        result = "" if bareInnerForFormatSpec else f"{prefix}{quoteChar}"

        # Values are in reverse order (BUILD_STRING pops from stack)
        # So we need to reverse them
        values = list(reversed(self.m_values))

        i = 0
        while i < len(values):
            value = values[i]

            # Stack underflow during BUILD_STRING leaves undefined slots; skip them
            # rather than crashing post-decompile passes that re-render this node.
            if value is None:
                i += 1
                continue

            if isinstance(value, ASTFormattedValue):
                # Check for f-string = debugging pattern (Python 3.8+)
                # Pattern: literal ending with "varname=" followed by {varname!r}
                if i > 0 and isinstance(values[i - 1], ASTObject):
                    prevStr = (getattr(values[i - 1].object, "Value", None) if values[i - 1].object else None) or ''
                    if not isinstance(prevStr, str):
                        prevStr = str(prevStr if prevStr is not None else '')
                    match = re.search(r"([a-zA-Z_]\w*)\s*=$", prevStr)

                    if (match and isinstance(value.m_val, ASTName) and
                            value.m_val.name == match.group(1) and
                            value.m_conversion == ASTFormattedValue.ConversionFlag["Repr"] and
                            not value.m_format_spec):
                        # This is f"{varname=}" syntax
                        # Remove the "varname=" suffix from previous literal
                        prefix2 = prevStr[0:len(prevStr) - len(match.group(0))]

                        # Remove the previously added literal and replace with prefix + {var=}
                        if quoteChar == '"':
                            quoteEsc_pat = r'"'
                            quoteReplace = '\\"'
                        else:
                            quoteEsc_pat = r"'"
                            quoteReplace = "\\'"
                        needle = prevStr.replace('\\', '\\\\')
                        needle = re.sub(quoteEsc_pat, quoteReplace, needle)
                        needle = needle.replace('\n', '\\n').replace('\t', '\\t')
                        beforeLiteral = result.rfind(needle)

                        if beforeLiteral != -1:
                            result = result[0:beforeLiteral]

                        # Add prefix (escaped) if present
                        if prefix2:
                            escapedPrefix = prefix2.replace('\\', '\\\\')
                            escapedPrefix = re.sub(quoteEsc_pat, quoteReplace, escapedPrefix)
                            escapedPrefix = escapedPrefix.replace('\n', '\\n')
                            escapedPrefix = escapedPrefix.replace('\t', '\\t')
                            result += escapedPrefix

                        # Add {varname=} instead of varname={varname!r}
                        result += f"{{{match.group(1)}=}}"
                        i += 1
                        continue

                # {expression} part - pass our own quote char so nested
                # f-strings / strings inside pick a compatible delimiter.
                result += value.codeFragment(quoteChar)
                # result above calls ASTFormattedValue.codeFragment(outerQuote).
            elif isinstance(value, ASTObject) and getattr(value.object, "ClassName", None) in ('Py_String', 'Py_Unicode'):
                # Literal string part - need to escape special chars
                s = value.object.Value
                # Escape backslashes and the current quote char
                s = s.replace('\\', '\\\\')
                if quoteChar == '"':
                    s = s.replace('"', '\\"')
                else:
                    s = s.replace("'", "\\'")
                s = s.replace('\n', '\\n')
                s = s.replace('\r', '\\r')
                s = s.replace('\t', '\\t')
                s = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]",
                           lambda m: '\\x' + format(ord(m.group(0)), '02x'),
                           s)
                result += s
            else:
                # Fallback for unexpected types
                result += value.codeFragment()
            i += 1

        if not bareInnerForFormatSpec:
            result += quoteChar
        return result

    def __str__(self):
        return f"{self.__class__.__name__}: Line {self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTAnnotatedVar(ASTNode):
    def __init__(self, name=None, type=None):
        super().__init__()
        self.m_name = name
        self.m_type = type

    @property
    def name(self):
        return self.m_name

    @property
    def annotation(self):
        return self.m_type

    def formatIdentifier(self, node):
        if not node:
            return '##ERROR##'
        if isinstance(node, ASTName):
            return node.name
        if isinstance(node, ASTObject):
            value = getattr(node.object, "Value", None) if node.object is not None else None
            if value is not None:
                return str(value)
        fragment = node.codeFragment() if hasattr(node, "codeFragment") else None
        if not fragment:
            fragment = node.toString() if hasattr(node, "toString") else None
        if not fragment:
            return '##ERROR##'
        fragment = fragment.toString() if hasattr(fragment, "toString") else fragment
        if isinstance(fragment, str):
            trimmed = fragment.strip()
            if ((trimmed.startswith("'") and trimmed.endswith("'")) or
                    (trimmed.startswith('"') and trimmed.endswith('"'))):
                return trimmed[1:len(trimmed) - 1]
            return trimmed
        return fragment

    def codeFragment(self):
        name = self.formatIdentifier(self.name)
        if self.annotation is not None and hasattr(self.annotation, "codeFragment"):
            annotation = str(self.annotation.codeFragment())
        elif self.annotation is not None:
            annotation = self.annotation.toString() if hasattr(self.annotation, "toString") else str(self.annotation)
        else:
            annotation = '##ERROR##'
        return f"{name}: {annotation}"

    def __str__(self):
        return f"{self.__class__.__name__}: Line {self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


class ASTTypeAlias(ASTNode):
    def __init__(self, name=None, value=None):
        super().__init__()
        self.m_name = name
        self.m_value = value

    @property
    def name(self):
        return self.m_name

    @property
    def value(self):
        return self.m_value

    def formatName(self):
        if isinstance(self.name, str):
            return self.name
        if self.name is not None and hasattr(self.name, "codeFragment"):
            fragment = self.name.codeFragment()
            return str(fragment) if fragment is not None else '##ERROR##'
        return f"{self.name}"

    def codeFragment(self):
        name = self.formatName()
        if self.value is not None and hasattr(self.value, "codeFragment"):
            valueFragment = self.value.codeFragment()
        elif self.value is not None and hasattr(self.value, "toString"):
            valueFragment = self.value.toString()
        else:
            valueFragment = 'None'
        return f"type {name} = {valueFragment}"


class ASTTernary(ASTNode):
    def __init__(self, if_block=None, if_expr=None, else_expr=None):
        super().__init__()
        self.m_if_block = if_block
        self.m_if_expr = if_expr
        self.m_else_expr = else_expr

    @property
    def if_block(self):
        return self.m_if_block

    @property
    def if_expr(self):
        return self.m_if_expr

    @property
    def else_expr(self):
        return self.m_else_expr

    @property
    def lastLine(self):
        return self.else_expr.lastLine if self.else_expr is not None else None

    def codeFragment(self):
        neg = "not " if (self.if_block is not None and self.if_block.negative) else ""
        if_frag = (self.if_expr.codeFragment() if self.if_expr is not None else None) or '##ERROR##'
        cond_frag = (self.if_block.condition.codeFragment() if self.if_block is not None and self.if_block.condition is not None else None) or '##ERROR##'
        else_frag = (self.else_expr.codeFragment() if self.else_expr is not None else None) or '##ERROR##'
        result = f"{if_frag} if {neg}{cond_frag} else {else_frag}"
        return result

    def __str__(self):
        return f"{self.__class__.__name__}: Line {self.line}, {self.codeFragment()}"

    def toString(self):
        return self.__str__()


# Match/Case statement (Python 3.10+)
class ASTMatch(ASTNode):
    def __init__(self, subject=None, cases=None):
        super().__init__()
        self.m_subject = subject
        self.m_cases = cases if cases is not None else []

    @property
    def subject(self):
        return self.m_subject

    @property
    def cases(self):
        return self.m_cases

    def addCase(self, caseNode):
        self.m_cases.append(caseNode)

    def codeFragment(self):
        result = PycResult("", True)
        result.add(f"match {self.m_subject.codeFragment()}:")
        result.increaseIndent()

        for caseNode in self.m_cases:
            result.add(caseNode.codeFragment())

        result.decreaseIndent()
        return result

    def __str__(self):
        return f"ASTMatch: {len(self.m_cases)} cases"

    def toString(self):
        return self.__str__()


class ASTCase(ASTNode):
    def __init__(self, pattern=None, body=None, guard=None):
        super().__init__()
        self.m_pattern = pattern
        self.m_body = body
        self.m_guard = guard

    @property
    def pattern(self):
        return self.m_pattern

    @property
    def guard(self):
        return self.m_guard

    @property
    def body(self):
        return self.m_body

    def codeFragment(self):
        result = PycResult("", True)
        patternStr = (self.m_pattern.codeFragment() if self.m_pattern is not None else None) or '##ERROR##'

        if self.m_guard:
            result.add(f"case {patternStr} if {self.m_guard.codeFragment()}:")
        else:
            result.add(f"case {patternStr}:")

        result.increaseIndent()
        if self.m_body:
            result.add(self.m_body.codeFragment())
        else:
            result.add("pass")
        result.decreaseIndent()

        return result

    def __str__(self):
        pat_name = self.m_pattern.__class__.__name__ if self.m_pattern is not None else None
        return f"ASTCase: pattern={pat_name}"

    def toString(self):
        return self.__str__()


class ASTPattern(ASTNode):
    PatternType = {
        "Literal": 0,      # 1, "str", None
        "Variable": 1,     # x (captures value)
        "Wildcard": 2,     # _ (matches anything)
        "Sequence": 3,     # (x, y) or [a, b]
        "Mapping": 4,      # {"key": pattern}
        "Class": 5,        # ClassName(pattern)
        "Or": 6,           # pattern1 | pattern2
        "As": 7            # pattern as name
    }

    def __init__(self, type=None, value=None):
        super().__init__()
        self.m_type = type
        self.m_value = value

    @property
    def type(self):
        return self.m_type

    @property
    def value(self):
        return self.m_value

    def codeFragment(self):
        if self.m_type == ASTPattern.PatternType["Literal"]:
            # value is AST node for literal (ASTObject, ASTNone, etc.)
            return (self.m_value.codeFragment() if self.m_value is not None else None) or '##ERROR##'

        if self.m_type == ASTPattern.PatternType["Variable"]:
            # value is variable name (string)
            return self.m_value

        if self.m_type == ASTPattern.PatternType["Wildcard"]:
            return '_'

        if self.m_type == ASTPattern.PatternType["Sequence"]:
            # value is array of patterns
            if isinstance(self.m_value, list):
                items = ', '.join(str(p.codeFragment()) for p in self.m_value)
                return f"({items})"
            return '()'

        if self.m_type == ASTPattern.PatternType["Mapping"]:
            # value is array of {key, pattern} or plain object {key: pattern}
            def renderKey(key):
                if key is not None and hasattr(key, "codeFragment"):
                    return key.codeFragment()
                if key is not None and hasattr(key, "toString"):
                    return key.toString()
                return '##ERROR##'
            if isinstance(self.m_value, list):
                pairs = [f"{renderKey(entry['key'] if isinstance(entry, dict) else entry.key)}: {(entry['pattern'] if isinstance(entry, dict) else entry.pattern).codeFragment()}" for entry in self.m_value]
                return '{' + ', '.join(pairs) + '}'
            if isinstance(self.m_value, dict):
                pairs = []
                for key, pattern in self.m_value.items():
                    pairs.append(f"{key}: {pattern.codeFragment()}")
                return '{' + ', '.join(pairs) + '}'
            return '{}'

        if self.m_type == ASTPattern.PatternType["Class"]:
            if self.m_value:
                classExpr = self.m_value["classExpr"] if isinstance(self.m_value, dict) else getattr(self.m_value, "classExpr", None)
                if classExpr is not None and hasattr(classExpr, "codeFragment"):
                    classStr = classExpr.codeFragment()
                elif classExpr is not None and hasattr(classExpr, "__class__") and hasattr(classExpr, "codeFragment"):
                    classStr = classExpr.codeFragment()
                else:
                    classStr = classExpr or 'object'
                attrs_list = self.m_value.get("attributes", []) if isinstance(self.m_value, dict) else (getattr(self.m_value, "attributes", None) or [])
                attrs = []
                for attr in attrs_list:
                    pat = attr["pattern"] if isinstance(attr, dict) else getattr(attr, "pattern", None)
                    rhs = pat.codeFragment() if pat is not None and hasattr(pat, "codeFragment") else pat
                    name = attr["name"] if isinstance(attr, dict) else getattr(attr, "name", None)
                    attrs.append(f"{name}={rhs}" if name else rhs)
                return f"{classStr}({', '.join(str(a) for a in attrs)})"
            return 'object()'

        if self.m_type == ASTPattern.PatternType["Or"]:
            # value is array of patterns
            if isinstance(self.m_value, list):
                return ' | '.join(str(p.codeFragment()) for p in self.m_value)
            return '##ERROR##'

        if self.m_type == ASTPattern.PatternType["As"]:
            # value is {pattern, name}
            pat = self.m_value.get("pattern") if isinstance(self.m_value, dict) else getattr(self.m_value, "pattern", None) if self.m_value else None
            nm = self.m_value.get("name") if isinstance(self.m_value, dict) else getattr(self.m_value, "name", None) if self.m_value else None
            if pat and nm:
                return f"{pat.codeFragment()} as {nm}"
            return '##ERROR##'

        raise RuntimeError(f"ASTPattern.codeFragment(): unsupported pattern type '{self.m_type}'")

    def __str__(self):
        return f"ASTPattern: type={self.m_type}"

    def toString(self):
        return self.__str__()


class _EnumNS(dict):
    __slots__ = ()
    def __getattr__(self, key):
        if key in self:
            return self[key]
        if key.endswith("_") and key[:-1] in self:
            return self[key[:-1]]
        raise AttributeError(key)


for _cls, _attr in (
    (ASTUnary, "UnaryOp"),
    (ASTBinary, "BinOp"),
    (ASTCompare, "CompareOp"),
    (ASTSlice, "SliceOp"),
    (ASTReturn, "RetType"),
    (ASTFunction, "CodeFlags"),
    (ASTKeyword, "Word"),
    (ASTBlock, "BlockType"),
    (ASTCondBlock, "InitCondition"),
    (ASTFormattedValue, "ConversionFlag"),
    (ASTPattern, "PatternType"),
):
    _raw = getattr(_cls, _attr, None)
    if isinstance(_raw, dict) and not isinstance(_raw, _EnumNS):
        setattr(_cls, _attr, _EnumNS(_raw))
