"""Bytecode opcode tables by Python version."""
from __future__ import annotations

from . import (
    python_1_0, python_1_1, python_1_3, python_1_4, python_1_5, python_1_6,
    python_2_0, python_2_1, python_2_2, python_2_3, python_2_4, python_2_5,
    python_2_6, python_2_7,
    python_3_0, python_3_1, python_3_2, python_3_3, python_3_4, python_3_5,
    python_3_6, python_3_7, python_3_8, python_3_9, python_3_10, python_3_11,
    python_3_12, python_3_13, python_3_14, python_3_15,
)

VERSION_TABLES = {
    (1, 0): python_1_0, (1, 1): python_1_1, (1, 3): python_1_3, (1, 4): python_1_4,
    (1, 5): python_1_5, (1, 6): python_1_6,
    (2, 0): python_2_0, (2, 1): python_2_1, (2, 2): python_2_2, (2, 3): python_2_3,
    (2, 4): python_2_4, (2, 5): python_2_5, (2, 6): python_2_6, (2, 7): python_2_7,
    (3, 0): python_3_0, (3, 1): python_3_1, (3, 2): python_3_2, (3, 3): python_3_3,
    (3, 4): python_3_4, (3, 5): python_3_5, (3, 6): python_3_6, (3, 7): python_3_7,
    (3, 8): python_3_8, (3, 9): python_3_9, (3, 10): python_3_10, (3, 11): python_3_11,
    (3, 12): python_3_12, (3, 13): python_3_13, (3, 14): python_3_14, (3, 15): python_3_15,
}
