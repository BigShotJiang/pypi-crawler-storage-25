from __future__ import annotations


class OpCode:
    OpCodeID = 0
    InstructionName = None
    HasArgument = False
    Argument = 0
    HasName = False
    Name = None
    HasJumpRelative = False
    HasJumpAbsolute = False
    HasNegativeOffset = False
    HasConstant = False
    Constant = None
    ConstantObject = None
    HasCompare = False
    CompareOperator = None
    HasLocal = False
    LocalName = None
    HasBinaryOp = False
    BinaryOp = None
    HasIntrisic1 = False
    Intrisic1 = None
    HasIntrisic2 = False
    Intrisic2 = None
    HasFree = False
    FreeName = None
    Offset = 0
    LineNo = 0
    CodeBlock = None
    InstructionIndex = -1
    Size = 2  # Default size for Python 3.6+ word-aligned instructions

    def __init__(self, opcode=0, name=None, opts=None):
        self.OpCodeID = opcode
        self.InstructionName = name

        if opts and isinstance(opts, dict):
            for key, value in opts.items():
                if hasattr(self, key):
                    setattr(self, key, value)

    @property
    def Prev(self):
        if not self.CodeBlock or self.InstructionIndex < 1:
            return None
        return self.CodeBlock.Instructions[self.InstructionIndex - 1]

    @property
    def Next(self):
        if not self.CodeBlock or self.InstructionIndex < 0 or self.InstructionIndex >= len(self.CodeBlock.Instructions) - 1:
            return None
        return self.CodeBlock.Instructions[self.InstructionIndex + 1]

    @property
    def JumpTarget(self):
        if self.HasJumpRelative:
            # Python < 3.6: 3-byte instructions (opcode + 2 arg bytes)
            # Python 3.6+: 2-byte instructions (opcode + arg byte)
            return self.Offset + self.Size + self.Argument
        elif self.HasJumpAbsolute:
            return self.Argument
        else:
            return 0

    @property
    def Label(self):
        return self.Name or self.LocalName or self.FreeName

    def Clone(self):
        clone = OpCode()
        for key, value in self.__dict__.items():
            setattr(clone, key, value)
        return clone
