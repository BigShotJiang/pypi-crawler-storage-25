from __future__ import annotations

from .opcode import OpCode


class OpCodes:

    # No parameter word
    STOP_CODE = 0                       # Python 1.0 - 3.2
    POP_TOP = 1                         # Python 1.0 ->
    ROT_TWO = 2                         # Python 1.0 - 3.10
    ROT_THREE = 3                       # Python 1.0 - 3.10
    DUP_TOP = 4                         # Python 1.0 - 3.10
    DUP_TOP_TWO = 5                     # Python 3.2 - 3.10
    UNARY_POSITIVE = 6                  # Python 1.0 - 3.11
    UNARY_NEGATIVE = 7                  # Python 1.0 ->
    UNARY_NOT = 8                       # Python 1.0 ->
    UNARY_CONVERT = 9                   # Python 1.0 - 2.7
    UNARY_CALL = 10                     # Python 1.0 - 1.2
    UNARY_INVERT = 11                   # Python 1.0 ->
    BINARY_POWER = 12                   # Python 1.4 - 3.10
    BINARY_MULTIPLY = 13                # Python 1.0 - 3.10
    BINARY_DIVIDE = 14                  # Python 1.0 - 2.7
    BINARY_MODULO = 15                  # Python 1.0 - 3.10
    BINARY_ADD = 16                     # Python 1.0 - 3.10
    BINARY_SUBTRACT = 17                # Python 1.0 - 3.10
    BINARY_SUBSCR = 18                  # Python 1.0 ->
    BINARY_CALL = 19                    # Python 1.0 - 1.2
    SLICE_0 = 20                        # Python 1.0 - 2.7
    SLICE_1 = 21                        # Python 1.0 - 2.7
    SLICE_2 = 22                        # Python 1.0 - 2.7
    SLICE_3 = 23                        # Python 1.0 - 2.7
    STORE_SLICE_0 = 24                  # Python 1.0 - 2.7
    STORE_SLICE_1 = 25                  # Python 1.0 - 2.7
    STORE_SLICE_2 = 26                  # Python 1.0 - 2.7
    STORE_SLICE_3 = 27                  # Python 1.0 - 2.7
    DELETE_SLICE_0 = 28                 # Python 1.0 - 2.7
    DELETE_SLICE_1 = 29                 # Python 1.0 - 2.7
    DELETE_SLICE_2 = 30                 # Python 1.0 - 2.7
    DELETE_SLICE_3 = 31                 # Python 1.0 - 2.7
    STORE_SUBSCR = 32                   # Python 1.0 ->
    DELETE_SUBSCR = 33                  # Python 1.0 ->
    BINARY_LSHIFT = 34                  # Python 1.0 - 3.10
    BINARY_RSHIFT = 35                  # Python 1.0 - 3.10
    BINARY_AND = 36                     # Python 1.0 - 3.10
    BINARY_XOR = 37                     # Python 1.0 - 3.10
    BINARY_OR = 38                      # Python 1.0 - 3.10
    PRINT_EXPR = 39                     # Python 1.0 - 3.11
    PRINT_ITEM = 40                     # Python 1.0 - 2.7
    PRINT_NEWLINE = 41                  # Python 1.0 - 2.7
    BREAK_LOOP = 42                     # Python 1.0 - 3.7
    RAISE_EXCEPTION = 43                # Python 1.0 - 1.2
    LOAD_LOCALS = 44                    # Python 1.0 - 2.7, 3.12 ->
    RETURN_VALUE = 45                   # Python 1.0 ->
    LOAD_GLOBALS = 46                   # Python 1.0 - 1.2
    EXEC_STMT = 47                      # Python 1.0 - 2.7
    BUILD_FUNCTION = 48                 # Python 1.0 - 1.2
    POP_BLOCK = 49                      # Python 1.0 - 3.10
    END_FINALLY = 50                    # Python 1.0 - 3.8
    BUILD_CLASS = 51                    # Python 1.0 - 2.7
    ROT_FOUR = 52                       # Python 2.0 - 3.1, 3.8 - 3.10
    NOP = 53                            # Python 2.4 ->
    LIST_APPEND = 54                    # Python 2.4 - 2.6, 3.0
    BINARY_FLOOR_DIVIDE = 55            # Python 2.2 - 3.10
    BINARY_TRUE_DIVIDE = 56             # Python 2.2 - 3.10
    INPLACE_FLOOR_DIVIDE = 57           # Python 2.2 - 3.10
    INPLACE_TRUE_DIVIDE = 58            # Python 2.2 - 3.10
    GET_LEN = 59                        # Python 3.10 ->
    MATCH_MAPPING = 60                  # Python 3.10 ->
    MATCH_SEQUENCE = 61                 # Python 3.10 ->
    MATCH_KEYS = 62                     # Python 3.10 ->
    # Keep NOT_TAKEN distinct from legacy DELETE_SLICE_0 to avoid handler collisions.
    NOT_TAKEN = 400                     # Python 3.13+ instrumentation hint
    COPY_DICT_WITHOUT_KEYS = 63         # Python 3.10
    STORE_MAP = 64                      # Python 2.6 - 3.4
    INPLACE_ADD = 65                    # Python 2.0 - 3.10
    INPLACE_SUBTRACT = 66               # Python 2.0 - 3.10
    INPLACE_MULTIPLY = 67               # Python 2.0 - 3.10
    INPLACE_DIVIDE = 68                 # Python 2.0 - 2.7
    INPLACE_MODULO = 69                 # Python 2.0 - 3.10
    INPLACE_POWER = 70                  # Python 2.0 - 3.10
    GET_ITER = 71                       # Python 2.2 ->
    PRINT_ITEM_TO = 72                  # Python 2.0 - 2.7
    PRINT_NEWLINE_TO = 73               # Python 2.0 - 2.7
    INPLACE_LSHIFT = 74                 # Python 2.0 - 3.10
    INPLACE_RSHIFT = 75                 # Python 2.0 - 3.10
    INPLACE_AND = 76                    # Python 2.0 - 3.10
    INPLACE_XOR = 77                    # Python 2.0 - 3.10
    INPLACE_OR = 78                     # Python 2.0 - 3.10
    WITH_CLEANUP = 79                   # Python 2.5 - 3.4
    WITH_CLEANUP_START = 80             # Python 3.5 - 3.8
    WITH_CLEANUP_FINISH = 81            # Python 3.5 - 3.8
    IMPORT_STAR = 82                    # Python 2.0 - 3.11
    SETUP_ANNOTATIONS = 83              # Python 3.6 ->
    YIELD_VALUE = 84                    # Python 2.2 - 3.11
    LOAD_BUILD_CLASS = 85               # Python 3.0 ->
    STORE_LOCALS = 86                   # Python 3.0 - 3.3
    POP_EXCEPT = 87                     # Python 3.0 ->
    SET_ADD = 88                        # Python 3.0
    YIELD_FROM = 89                     # Python 3.3 - 3.10
    BINARY_MATRIX_MULTIPLY = 90         # Python 3.5 - 3.10
    INPLACE_MATRIX_MULTIPLY = 91        # Python 3.5 - 3.10
    GET_AITER = 92                      # Python 3.5 ->
    GET_ANEXT = 93                      # Python 3.5 ->
    BEFORE_ASYNC_WITH = 94              # Python 3.5 ->
    GET_YIELD_FROM_ITER = 95            # Python 3.5 ->
    GET_AWAITABLE = 96                  # Python 3.5 - 3.10
    BEGIN_FINALLY = 97                  # Python 3.8
    END_ASYNC_FOR = 98                  # Python 3.8 ->
    RERAISE = 99                        # Python 3.9
    WITH_EXCEPT_START = 100             # Python 3.9 ->
    LOAD_ASSERTION_ERROR = 101          # Python 3.9 ->
    LIST_TO_TUPLE = 102                 # Python 3.9 - 3.11
    CACHE = 103                         # Python 3.11 ->
    PUSH_NULL = 104                     # Python 3.11 ->
    PUSH_EXC_INFO = 105                 # Python 3.11 ->
    CHECK_EXC_MATCH = 106               # Python 3.11 ->
    CHECK_EG_MATCH = 107                # Python 3.11 ->
    BEFORE_WITH = 108                   # Python 3.11 ->
    RETURN_GENERATOR = 109              # Python 3.11 ->
    ASYNC_GEN_WRAP = 110                # Python 3.11
    PREP_RERAISE_STAR = 111             # Python 3.11
    INTERPRETER_EXIT = 112              # Python 3.12 ->
    END_FOR = 113                       # Python 3.12 ->
    END_SEND = 114                      # Python 3.12 ->
    RESERVED = 115                      # Python 3.12 ->
    BINARY_SLICE = 116                  # Python 3.12 ->
    STORE_SLICE = 117                   # Python 3.12 ->
    CLEANUP_THROW = 118                 # Python 3.12 ->

    # Has parameter word
    PYC_HAVE_ARG = 119
    STORE_NAME_A = PYC_HAVE_ARG         # Python 1.0 ->                names[A]
    DELETE_NAME_A = 120                 # Python 1.0 ->                names[A]
    UNPACK_TUPLE_A = 121                # Python 1.0 - 1.6             A=count
    UNPACK_LIST_A = 122                 # Python 1.0 - 1.6             A=count
    UNPACK_ARG_A = 123                  # Python 1.0 - 1.4             A=count
    STORE_ATTR_A = 124                  # Python 1.0 ->                names[A]
    DELETE_ATTR_A = 125                 # Python 1.0 ->                names[A]
    STORE_GLOBAL_A = 126                # Python 1.0 ->                names[A]
    DELETE_GLOBAL_A = 127               # Python 1.0 ->                names[A]
    ROT_N_A = 128                       # Python 3.10                  A=count
    UNPACK_VARARG_A = 129               # Python 1.0 - 1.4             A=count
    LOAD_CONST_A = 130                  # Python 1.0 ->                consts[A]
    LOAD_NAME_A = 131                   # Python 1.0 ->                names[A]
    BUILD_TUPLE_A = 132                 # Python 1.0 ->                A=size
    BUILD_LIST_A = 133                  # Python 1.0 ->                A=size
    BUILD_MAP_A = 134                   # Python 1.0 ->                A=size
    LOAD_ATTR_A = 135                   # Python 1.0 ->                names[A]
    COMPARE_OP_A = 136                  # Python 1.0 ->                cmp_ops[A]
    IMPORT_NAME_A = 137                 # Python 1.0 ->                names[A]
    IMPORT_FROM_A = 138                 # Python 1.0 ->                names[A]
    ACCESS_MODE_A = 139                 # Python 1.0 - 1.4             names[A]
    JUMP_FORWARD_A = 140                # Python 1.0 ->                rel jmp +A
    JUMP_IF_FALSE_A = 141               # Python 1.0 - 2.6, 3.0        rel jmp +A
    JUMP_IF_TRUE_A = 142                # Python 1.0 - 2.6, 3.0        rel jmp +A
    JUMP_ABSOLUTE_A = 143               # Python 1.0 - 3.10            abs jmp A
    FOR_LOOP_A = 144                    # Python 1.0 - 2.2             rel jmp +A
    LOAD_LOCAL_A = 145                  # Python 1.0 - 1.4             names[A]
    LOAD_GLOBAL_A = 146                 # Python 1.0 ->                names[A]
    SET_FUNC_ARGS_A = 147               # Python 1.1 - 1.4             A=count
    SETUP_LOOP_A = 148                  # Python 1.0 - 3.7             rel jmp +A
    SETUP_EXCEPT_A = 149                # Python 1.0 - 3.7             rel jmp +A
    SETUP_FINALLY_A = 150               # Python 1.0 - 3.10            rel jmp +A
    RESERVE_FAST_A = 151                # Python 1.0 - 1.2             A=count
    LOAD_FAST_A = 152                   # Python 1.0 ->                locals[A]
    STORE_FAST_A = 153                  # Python 1.0 ->                locals[A]
    DELETE_FAST_A = 154                 # Python 1.0 ->                locals[A]
    GEN_START_A = 155                   # Python 3.10                  ???
    SET_LINENO_A = 156                  # Python 1.0 - 2.2             A=line
    STORE_ANNOTATION_A = 157            # Python 3.6                   names[A]
    RAISE_VARARGS_A = 158               # Python 1.3 ->                A=count
    CALL_FUNCTION_A = 159               # Python 1.3 - 3.5             A=(#args)+(#kwargs<<8)
                                        # Python 3.6 - 3.10            A=#args
    MAKE_FUNCTION_A = 160               # Python 1.3 - 2.7             A=#defaults
                                        # Python 3.0 - 3.5             A=(#defaults)+(#kwdefaults<<8)+(#annotations<<16)
                                        # Python 3.6 ->                A=flags
    MAKE_FUNCTION = 272                 # Python 3.13+ ->              A=flags
    BUILD_SLICE_A = 161                 # Python 1.4 ->                A=count
    CALL_FUNCTION_VAR_A = 162           # Python 1.6 - 3.5             A=(#args)+(#kwargs<<8)
    CALL_FUNCTION_KW_A = 163            # Python 1.6 - 3.5             A=(#args)+(#kwargs<<8)
                                        # Python 3.6 - 3.10            A=#args
    CALL_FUNCTION_VAR_KW_A = 164        # Python 1.6 - 3.5             A=(#args)+(#kwargs<<8)
    CALL_FUNCTION_EX_A = 165            # Python 3.6 ->                A=flags
    UNPACK_SEQUENCE_A = 166             # Python 2.0 ->                A=count
    FOR_ITER_A = 167                    # Python 2.0 ->                rel jmp +A
    DUP_TOPX_A = 168                    # Python 2.0 - 3.1             A=count
    BUILD_SET_A = 169                   # Python 2.7 ->                A=size
    JUMP_IF_FALSE_OR_POP_A = 170        # Python 2.7, 3.1 - 3.11       abs jmp A
    JUMP_IF_TRUE_OR_POP_A = 171         # Python 2.7, 3.1 - 3.11       abs jmp A
    POP_JUMP_IF_FALSE_A = 172           # Python 2.7, 3.1 - 3.10       abs jmp A
                                        # Python 3.12 ->               rel jmp +A
    POP_JUMP_IF_TRUE_A = 173            # Python 2.7, 3.1 - 3.10       abs jmp A
                                        # Python 3.12 ->               rel jmp +A
    CONTINUE_LOOP_A = 174               # Python 2.1 - 3.7             abs jmp A
    MAKE_CLOSURE_A = 175                # Python 2.1 - 2.7             A=#defaults
                                        # Python 3.0 - 3.5             A=(#defaults)+(#kwdefaults<<8)+(#annotations<<16)
    LOAD_CLOSURE_A = 176                # Python 2.1 ->                freevars[A]
    LOAD_DEREF_A = 177                  # Python 2.1 ->                freevars[A]
    STORE_DEREF_A = 178                 # Python 2.1 ->                freevars[A]
    DELETE_DEREF_A = 179                # Python 3.2 ->                freevars[A]
    EXTENDED_ARG_A = 180                # Python 2.0 ->                A=extended_arg
    SETUP_WITH_A = 181                  # Python 2.7, 3.2 - 3.10       rel jmp +A
    SET_ADD_A = 182                     # Python 2.7, 3.1 ->           stack[A]
    MAP_ADD_A = 183                     # Python 2.7, 3.1 ->           stack[A]
    UNPACK_EX_A = 184                   # Python 3.0 ->                A=(before)+(after<<8)
    LIST_APPEND_A = 185                 # Python 2.7, 3.1 ->           stack[A]
    LOAD_CLASSDEREF_A = 186             # Python 3.4 - 3.10            (cellvars+freevars)[A]
                                        # Python 3.11                  localsplusnames[A]
    MATCH_CLASS_A = 187                 # Python 3.10 ->               A=#args
    BUILD_LIST_UNPACK_A = 188           # Python 3.5 - 3.8             A=count
    BUILD_MAP_UNPACK_A = 189            # Python 3.5 - 3.8             A=count
    BUILD_MAP_UNPACK_WITH_CALL_A = 190  # Python 3.5                   A=(count)+(fnloc<<8)
                                        # Python 3.6 - 3.8             A=count
    BUILD_TUPLE_UNPACK_A = 191          # Python 3.5 - 3.8             A=count
    BUILD_SET_UNPACK_A = 192            # Python 3.5 - 3.8             A=count
    SETUP_ASYNC_WITH_A = 193            # Python 3.5 - 3.10            rel jmp +A
    FORMAT_VALUE_A = 194                # Python 3.6 ->                A=conversion_type
    BUILD_CONST_KEY_MAP_A = 195         # Python 3.6 ->                A=count
    BUILD_STRING_A = 196                # Python 3.6 ->                A=count
    BUILD_TUPLE_UNPACK_WITH_CALL_A = 197  # Python 3.6 - 3.8             A=count
    LOAD_METHOD_A = 198                 # Python 3.7 - 3.11            names[A]
    CALL_METHOD_A = 199                 # Python 3.7 - 3.10            A=#args
    CALL_FINALLY_A = 200                # Python 3.8                   rel jmp +A
    POP_FINALLY_A = 201                 # Python 3.8                   A=flags
    IS_OP_A = 202                       # Python 3.9 ->                A=inverted
    CONTAINS_OP_A = 203                 # Python 3.9 ->                A=inverted
    RERAISE_A = 204                     # Python 3.10 ->               A=flag
    JUMP_IF_NOT_EXC_MATCH_A = 205       # Python 3.9 - 3.10            abs jmp A
    LIST_EXTEND_A = 206                 # Python 3.9 ->                stack[A]
    SET_UPDATE_A = 207                  # Python 3.9 ->                stack[A]
    DICT_MERGE_A = 208                  # Python 3.9 ->                stack[A]
    DICT_UPDATE_A = 209                 # Python 3.9 ->                stack[A]
    SWAP_A = 210                        # Python 3.11 ->               stack[A]
    POP_JUMP_FORWARD_IF_FALSE_A = 211   # Python 3.11                  rel jmp +A
    POP_JUMP_FORWARD_IF_TRUE_A = 212    # Python 3.11                  rel jmp +A
    COPY_A = 213                        # Python 3.11 ->               stack[A]
    BINARY_OP_A = 214                   # Python 3.11 ->               bin_ops[A]
    SEND_A = 215                        # Python 3.11 ->               rel jmp +A
    POP_JUMP_FORWARD_IF_NOT_NONE_A = 216  # Python 3.11                  rel jmp +A
    POP_JUMP_FORWARD_IF_NONE_A = 217    # Python 3.11                  rel jmp +A
    GET_AWAITABLE_A = 218               # Python 3.11 ->               A=awaitable_type
    JUMP_BACKWARD_NO_INTERRUPT_A = 219  # Python 3.11 ->               rel jmp -A
    MAKE_CELL_A = 220                   # Python 3.11 ->               locals[A]
    JUMP_BACKWARD_A = 221               # Python 3.11 ->               rel jmp -A
    COPY_FREE_VARS_A = 222              # Python 3.11 ->               A=count
    RESUME_A = 223                      # Python 3.11 ->               ???
    PRECALL_A = 224                     # Python 3.11                  A=#args
    CALL_A = 225                        # Python 3.11 ->               A=#args
    KW_NAMES_A = 226                    # Python 3.11 ->               consts[A]
    POP_JUMP_BACKWARD_IF_NOT_NONE_A = 227  # Python 3.11                  jmp rel -A
    POP_JUMP_BACKWARD_IF_NONE_A = 228   # Python 3.11                  jmp rel -A
    POP_JUMP_BACKWARD_IF_FALSE_A = 229  # Python 3.11                  jmp rel -A
    POP_JUMP_BACKWARD_IF_TRUE_A = 230   # Python 3.11                  jmp rel -A
    RETURN_CONST_A = 231                # Python 3.12 ->               consts[A]
    LOAD_FAST_CHECK_A = 232             # Python 3.12 ->               locals[A]
    POP_JUMP_IF_NOT_NONE_A = 233        # Python 3.12 ->               rel jmp +A
    POP_JUMP_IF_NONE_A = 234            # Python 3.12 ->               rel jmp +A
    LOAD_SUPER_ATTR_A = 235             # Python 3.12 ->               A=(flags&0x3)+names[A<<2]
    LOAD_FAST_AND_CLEAR_A = 236         # Python 3.12 ->               locals[A]
    YIELD_VALUE_A = 237                 # Python 3.12 ->               ???
    CALL_INTRINSIC_1_A = 238            # Python 3.12 ->               intrinsics_1[A]
    CALL_INTRINSIC_2_A = 239            # Python 3.12 ->               intrinsics_2[A]
    LOAD_FROM_DICT_OR_GLOBALS_A = 240   # Python 3.12 ->               names[A]
    LOAD_FROM_DICT_OR_DEREF_A = 241     # Python 3.12 ->               localsplusnames[A]

    # Instrumented opcodes
    INSTRUMENTED_NOT_TAKEN_A = 401          # Python 3.14 ->               no-op marker
    INSTRUMENTED_POP_ITER_A = 402           # Python 3.14 ->               (see POP_ITER)
    INSTRUMENTED_END_ASYNC_FOR_A = 403      # Python 3.14 ->               (see END_ASYNC_FOR)
    INSTRUMENTED_CALL_KW_A = 404            # Python 3.14 ->               (see CALL_KW)
    INSTRUMENTED_LOAD_SUPER_ATTR_A = 242    # Python 3.12 ->               (see LOAD_SUPER_ATTR)
    INSTRUMENTED_POP_JUMP_IF_NONE_A = 243   # Python 3.12 ->               (see POP_JUMP_IF_NONE)
    INSTRUMENTED_POP_JUMP_IF_NOT_NONE_A = 244  # Python 3.12 ->            (see POP_JUMP_IF_NOT_NONE)
    INSTRUMENTED_RESUME_A = 245             # Python 3.12 ->               (see RESUME)
    INSTRUMENTED_CALL_A = 246               # Python 3.12 ->               (see CALL)
    INSTRUMENTED_RETURN_VALUE_A = 247       # Python 3.12 ->               (see RETURN_VALUE)
    INSTRUMENTED_YIELD_VALUE_A = 248        # Python 3.12 ->               (see YIELD_VALUE)
    INSTRUMENTED_CALL_FUNCTION_EX_A = 249   # Python 3.12 ->               (see CALL_FUNCTION_EX)
    INSTRUMENTED_JUMP_FORWARD_A = 250       # Python 3.12 ->               (see JUMP_FORWARD)
    INSTRUMENTED_JUMP_BACKWARD_A = 251      # Python 3.12 ->               (see JUMP_BACKWARD)
    INSTRUMENTED_RETURN_CONST_A = 252       # Python 3.12 ->               (see RETURN_CONST)
    INSTRUMENTED_FOR_ITER_A = 253           # Python 3.12 ->               (see FOR_ITER)
    INSTRUMENTED_POP_JUMP_IF_FALSE_A = 254  # Python 3.12 ->               (see POP_JUMP_IF_FALSE)
    INSTRUMENTED_POP_JUMP_IF_TRUE_A = 255   # Python 3.12 ->               (see POP_JUMP_IF_TRUE)
    INSTRUMENTED_END_FOR_A = 256            # Python 3.12 ->               (see END_FOR)
    INSTRUMENTED_END_SEND_A = 257           # Python 3.12 ->               (see END_SEND)
    INSTRUMENTED_INSTRUCTION_A = 258        # Python 3.12 ->               ???
    INSTRUMENTED_LINE_A = 259               # Python 3.12 ->               ???

    # Python 3.12 intrinsic function calls
    CALL_INTRINSIC_1 = 265                  # Python 3.12 ->           intrinsics_1[A]
    CALL_INTRINSIC_2 = 266                  # Python 3.12 ->           intrinsics_2[A]

    # Aliases for handler name mapping
    CALL_INTRINSIC_1A = 238                 # Alias for CALL_INTRINSIC_1_A
    CALL_INTRINSIC_2A = 239                 # Alias for CALL_INTRINSIC_2_A

    # Python 3.13/3.14 new opcodes
    EXIT_INIT_CHECK = 267                   # Python 3.13 ->           exit __init__ check
    FORMAT_SIMPLE = 268                     # Python 3.13 ->           format without spec
    FORMAT_WITH_SPEC = 269                  # Python 3.13 ->           format with spec
    TO_BOOL = 270                           # Python 3.13 ->           convert to bool
    BUILD_TEMPLATE = 271                    # Python 3.14 ->           build template object
    LOAD_FAST_BORROW_A = 274                # Python 3.14 ->           optimized LOAD_FAST (distinct ID from MAKE_FUNCTION=272)
    LOAD_SMALL_INT_A = 275                  # Python 3.14 ->           load small integer
    LOAD_FAST_LOAD_FAST_A = 276             # Python 3.13+ ->          packed two locals
    STORE_FAST_LOAD_FAST_A = 277            # Python 3.13+ ->          store then load packed locals
    SET_FUNCTION_ATTRIBUTE_A = 278          # Python 3.13+ ->          set function attribute

    # Aliases / placeholders for 3.13+ opcodes with distinct IDs to avoid collisions
    POP_ITER = 300                          # Python 3.14 instrumentation helper
    WITH_EXCEPT_START_A = 301               # Python 3.13+ arg variant
    END_ASYNC_FOR_A = 302                   # Python 3.13+ encoded end async for
    POP_BLOCK_A = 303                       # Python 3.13+ encoded pop block
    CALL_FUNCTION_EX = 304                  # Python 3.14 CALL (EX) wrapper
    CALL_KW_A = 305                         # Python 3.14 CALL_KW wrapper
    CONVERT_VALUE_A = 306                   # Python 3.14 conversion helper
    JUMP_A = 307                            # Python 3.14 generic jump
    JUMP_NO_INTERRUPT_A = 308               # Python 3.14 jump without signal checks
    LOAD_COMMON_CONSTANT_A = 309            # Python 3.14 common constants table
    LOAD_FAST_BORROW_LOAD_FAST_BORROW_A = 310  # Python 3.14 packed borrow load
    LOAD_SPECIAL_A = 311                    # Python 3.14 LOAD_SPECIAL
    SETUP_CLEANUP_A = 312                   # Python 3.13+ cleanup setup
    STORE_FAST_MAYBE_NULL_A = 313           # Python 3.13+ tolerant store
    STORE_FAST_STORE_FAST_A = 314           # Python 3.13+ packed store/store
    ANNOTATIONS_PLACEHOLDER_A = 315         # Python 3.14 placeholder
    BUILD_INTERPOLATION_A = 316             # Python 3.14 string template builder
    ENTER_EXECUTOR_A = 317                  # Python 3.14 executor entry (ignore)
    LOAD_SUPER_METHOD_A = 318               # Python 3.13+ super method load
    LOAD_ZERO_SUPER_ATTR_A = 319            # Python 3.13+ zero-cost super attr
    LOAD_ZERO_SUPER_METHOD_A = 320          # Python 3.13+ zero-cost super method

    # Python 3.15 new opcodes
    TRACE_RECORD_A = 321                    # Python 3.15 ->           trace recording (ignore)


    # enum cmp_op
    # {
    #     PyCmp_LT, PyCmp_LE, PyCmp_EQ, PyCmp_NE, PyCmp_GT, PyCmp_GE,
    #     PyCmp_IN, PyCmp_NOT_IN, PyCmp_IS, PyCmp_IS_NOT, PyCmp_EXC_MATCH, PyCmp_BAD
    # };

    CompareOpNames = ["<", "<=", "==", "!=", ">", ">=", "in", "not in", "is", "is not", "exception match", "BAD"]

    # Bare (non-_A) aliases referenced by handlers written against the JS
    # baseline. JS resolves undefined class fields silently; Python raises
    # AttributeError on class-level access. None acts as a JS-style
    # `undefined` — never matches any real OpCodeID (all are non-negative
    # ints, and explicit `is None` / `== None` checks fall through cleanly).
    POP_JUMP_IF_TRUE = None
    POP_JUMP_IF_FALSE = None
    POP_JUMP_FORWARD_IF_TRUE = None
    POP_JUMP_FORWARD_IF_FALSE = None
    POP_JUMP_IF_NONE = None
    POP_JUMP_IF_NOT_NONE = None
    POP_JUMP_FORWARD_IF_NONE = None
    POP_JUMP_FORWARD_IF_NOT_NONE = None
    POP_JUMP_BACKWARD_IF_NONE = None
    POP_JUMP_BACKWARD_IF_NOT_NONE = None
    JUMP_FORWARD = None
    JUMP_ABSOLUTE = None
    JUMP_IF_FALSE = None
    JUMP_IF_TRUE = None
    JUMP_IF_FALSE_OR_POP = None
    JUMP_IF_TRUE_OR_POP = None
    JUMP_BACKWARD_NO_INTERRUPT = None
    JUMP_BACKWARD = None
    STORE_FAST = None
    STORE_NAME = None
    STORE_GLOBAL = None
    STORE_ATTR = None
    STORE_DEREF = None
    LOAD_FAST = None
    LOAD_NAME = None
    LOAD_GLOBAL = None
    LOAD_CONST = None
    LOAD_ATTR = None
    DELETE_NAME = None
    DELETE_FAST = None
    DELETE_GLOBAL = None
    DELETE_DEREF = None
    BUILD_MAP = None
    UNPACK_SEQUENCE = None
    RAISE_VARARGS = None
    MAKE_CLOSURE = None
    MATCH_CLASS = None
    SETUP_EXCEPT = None
    SETUP_FINALLY = None
    SETUP_WITH = None
    SETUP_ASYNC_WITH = None
    RETURN_CONST = None
    RESUME = None
    SWAP = None
    COPY = None
    INSTRUMENTED_CALL = None
    INSTRUMENTED_POP_JUMP_IF_TRUE = None
    INSTRUMENTED_POP_JUMP_IF_FALSE = None
    INSTRUMENTED_POP_JUMP_IF_NONE = None
    INSTRUMENTED_POP_JUMP_IF_NOT_NONE = None

    def __init__(self):
        self.OpCodeList = []
        self.Instructions = []
        self.CurrentInstructionIndex = -1
        self.CodeObject = []
        self.DOMINATORS = [OpCodes.SETUP_LOOP_A, OpCodes.SETUP_EXCEPT_A, OpCodes.SETUP_FINALLY_A, OpCodes.SETUP_WITH_A, OpCodes.FOR_ITER_A]

    def __getattr__(self, name):
        # JS class fields default to `undefined` on missing access. Handlers
        # written against the JS baseline reference opcodes like POP_JUMP_IF_TRUE
        # (sans _A) that only exist in some Python versions; in JS those evaluate
        # to undefined and fall out of `in Set` checks silently. Python raises
        # AttributeError, which kills whole decompile runs. Return None here to
        # mirror JS — dunder names still raise via default behavior.
        if name.startswith('__') and name.endswith('__'):
            raise AttributeError(name)
        return None

    @property
    def HasInstructionsToProcess(self):
        return self.CurrentInstructionIndex < len(self.Instructions) - 1

    @property
    def Current(self):
        return None if (self.CurrentInstructionIndex < 0 or self.CurrentInstructionIndex >= len(self.Instructions)) else self.Instructions[self.CurrentInstructionIndex]

    def GetOpCodeID(self, code, offset):
        # Bounds checking for bytecode array access
        if offset < 0 or offset >= len(code):
            import sys
            g_cliArgs = getattr(sys.modules.get("__main__"), "g_cliArgs", None)
            if g_cliArgs and getattr(g_cliArgs, "debug", False):
                print(f"GetOpCodeID: offset {offset} out of bounds [0, {len(code)})", file=sys.stderr)
            return None

        opcode = code[offset]
        opcodeEntry = self.OpCodeList[opcode] if opcode < len(self.OpCodeList) else None

        if not opcodeEntry:
            import sys
            g_cliArgs = getattr(sys.modules.get("__main__"), "g_cliArgs", None)
            if g_cliArgs and getattr(g_cliArgs, "debug", False):
                print(f"GetOpCodeID: unknown opcode {opcode} (0x{opcode:x}) at offset {offset}", file=sys.stderr)
            return None

        return opcodeEntry.OpCodeID

    def ReadExtendedArg(self, code, opOffset):
        reader = self.CodeObject.Reader
        argument = 0
        opCodeID = self.GetOpCodeID(code, opOffset)

        # If opCodeID is null, bytecode is truncated/corrupted
        if opCodeID is None:
            return [0, opOffset]

        if reader.versionCompare(3, 6) >= 0:
            while opCodeID == OpCodes.EXTENDED_ARG_A:
                opOffset += 1
                argument = (argument << 8) | code[opOffset]
                opOffset += 1
                opCodeID = self.GetOpCodeID(code, opOffset)

                # Break if we hit end of bytecode
                if opCodeID is None:
                    break
            argument <<= 8
        else:
            # Pre-3.6: EXTENDED_ARG carries a 16-bit operand that becomes
            # the upper 16 bits of the next instruction's argument. After
            # reading both operand bytes we must advance opOffset one more
            # step so the caller lands on the real opcode (not the trailing
            # operand byte of EXTENDED_ARG).
            if opCodeID == OpCodes.EXTENDED_ARG_A:
                opOffset += 1
                b0 = code[opOffset]
                opOffset += 1
                b1 = code[opOffset]
                argument = b0 | (b1 << 8)
                argument <<= 16
                opOffset += 1

        return [argument, opOffset]

    def SetupByteCode(self, co):
        if not co or not co.Code or not co.Code.Value:
            return

        self.CodeObject = co
        opOffset = 0
        opCodeID = 0
        extendedArg = 0
        instructionIndex = 0
        code = self.CodeObject.Code.Value

        while opOffset < len(code):
            extendedArg, opOffset = self.ReadExtendedArg(code, opOffset)

            bytecode = code[opOffset]
            opcodeEntry = self.OpCodeList[bytecode] if bytecode < len(self.OpCodeList) else None

            # Skip unknown/invalid opcodes
            if not opcodeEntry:
                import sys
                g_cliArgs = getattr(sys.modules.get("__main__"), "g_cliArgs", None)
                if g_cliArgs and getattr(g_cliArgs, "debug", False):
                    print(f"SetupByteCode: unknown opcode {bytecode} (0x{bytecode:x}) at offset {opOffset}", file=sys.stderr)
                opOffset += 1  # Skip this byte and continue
                continue

            opCode = opcodeEntry.Clone()
            opCode.Offset = opOffset
            opOffset += 1
            opCode.CodeBlock = self
            opCode.InstructionIndex = instructionIndex
            instructionIndex += 1

            # Set instruction size based on Python version
            if self.CodeObject.Reader.versionCompare(3, 6) >= 0:
                opCode.Size = 2  # Python 3.6+ uses 2-byte word-aligned instructions
                opCode.Argument = extendedArg | code[opOffset]
                opOffset += 1
            elif opCode.HasArgument:
                opCode.Size = 3  # Python < 3.6 with argument: opcode + 2 arg bytes
                b0 = code[opOffset]
                opOffset += 1
                b1 = code[opOffset]
                opOffset += 1
                opCode.Argument = extendedArg | b0 | (b1 << 8)
            else:
                opCode.Size = 1  # Python < 3.6 without argument: just opcode

            if opCode.HasArgument:
                if opCode.OpCodeID == OpCodes.SET_LINENO_A:
                    self.CodeObject.CachedLineNo = opCode.Argument
                else:
                    opCode.LineNo = self.CodeObject.getLineNumber(opCode.Offset)

                if opCode.HasConstant:
                    val = self.CodeObject.Consts.Value[opCode.Argument] if opCode.Argument < len(self.CodeObject.Consts.Value) else None
                    import sys
                    g_cliArgs = getattr(sys.modules.get("__main__"), "g_cliArgs", None)
                    if g_cliArgs and getattr(g_cliArgs, "debug", False) and opCode.Offset < 20:
                        consts_len = len(self.CodeObject.Consts.Value) if self.CodeObject.Consts and self.CodeObject.Consts.Value else 0
                        class_name = val.ClassName if val else 'null'
                        print(f"[SetupByteCode] offset={opCode.Offset}, arg={opCode.Argument}, Consts.length={consts_len}, val={class_name}")
                    if val:
                        opCode.ConstantObject = val
                        if val.ClassName == "Py_CodeObject":
                            opCode.Constant = opCode.Argument
                        elif val.ClassName in ("Py_Unicode", "Py_String"):
                            strVal = str(val)
                            if strVal and strVal[0] not in ('"', "'"):
                                strVal = strVal.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
                                if strVal.find("'") >= 0:
                                    opCode.Constant = f'"{strVal}"'
                                else:
                                    opCode.Constant = f"'{strVal}'"
                            else:
                                opCode.Constant = strVal
                        else:
                            opCode.Constant = str(val)
                    else:
                        # Malformed bytecode: oparg beyond consts. Keep placeholder instead of crashing.
                        opCode.Constant = f"##CONST_{opCode.Argument}##"
                elif opCode.HasName:
                    nameIndex = opCode.Argument

                    # Python 3.11+ LOAD_GLOBAL uses oparg>>1 as name index
                    if opCode.InstructionName == 'LOAD_GLOBAL' and \
                            self.CodeObject.Reader.versionCompare(3, 11) >= 0:
                        nameIndex = opCode.Argument >> 1
                    elif opCode.InstructionName in ('LOAD_ATTR', 'LOAD_METHOD') and \
                            self.CodeObject.Reader.versionCompare(3, 12) >= 0:
                        nameIndex = opCode.Argument >> 1

                    if nameIndex < len(self.CodeObject.Names.Value):
                        opCode.Name = str(self.CodeObject.Names.Value[nameIndex])
                    else:
                        import sys
                        g_cliArgs = getattr(sys.modules.get("__main__"), "g_cliArgs", None)
                        if g_cliArgs and getattr(g_cliArgs, "debug", False):
                            print(f"HasName: opCode.Argument {opCode.Argument} out of bounds (Names.length={len(self.CodeObject.Names.Value)})", file=sys.stderr)
                        opCode.Name = f"##NAME_{opCode.Argument}##"
                elif opCode.HasCompare:
                    # 3.12 encodes cmp_op in the upper bits of the argument;
                    # 3.13 shifts by 5. Match JS's soft-fail (undefined-like) for
                    # any out-of-range index to avoid crashing on newer layouts.
                    argIdx = opCode.Argument
                    if argIdx >= len(OpCodes.CompareOpNames):
                        shifted4 = argIdx >> 4
                        shifted5 = argIdx >> 5
                        if shifted5 < len(OpCodes.CompareOpNames):
                            argIdx = shifted5
                        elif shifted4 < len(OpCodes.CompareOpNames):
                            argIdx = shifted4
                    if 0 <= argIdx < len(OpCodes.CompareOpNames):
                        opCode.CompareOperator = OpCodes.CompareOpNames[argIdx]
                    else:
                        opCode.CompareOperator = None
                elif opCode.HasLocal:
                    if opCode.Argument < len(self.CodeObject.VarNames.Value):
                        opCode.Name = str(self.CodeObject.VarNames.Value[opCode.Argument])
                    elif opCode.Argument < len(self.CodeObject.Names.Value):
                        opCode.Name = str(self.CodeObject.Names.Value[opCode.Argument])
                elif opCode.HasFree:
                    # 3.11+ stores cells/frees inside localsplus, so the opcode argument
                    # is an index into [locals | cells | frees]. Strip the locals prefix
                    # before looking up into the split CellVars/FreeVars tuples.
                    reader = getattr(self.CodeObject, "Reader", None)
                    isNewLayout = reader is not None and hasattr(reader, "versionCompare") and reader.versionCompare(3, 11) >= 0
                    varnames = getattr(self.CodeObject, "VarNames", None)
                    localsLen = len(varnames.Value) if (isNewLayout and varnames and varnames.Value is not None) else 0
                    freeIdx = opCode.Argument - localsLen
                    cellvars = getattr(self.CodeObject, "CellVars", None)
                    freevars = getattr(self.CodeObject, "FreeVars", None)
                    cellLen = len(cellvars.Value) if (cellvars and cellvars.Value is not None) else 0
                    freeLen = len(freevars.Value) if (freevars and freevars.Value is not None) else 0
                    if freeIdx >= 0 and freeIdx < cellLen:
                        opCode.FreeName = str(self.CodeObject.CellVars.Value[freeIdx])
                    elif freeIdx >= cellLen and (freeIdx - cellLen) < freeLen:
                        opCode.FreeName = str(self.CodeObject.FreeVars.Value[freeIdx - cellLen])
                    else:
                        opCode.FreeName = f"##FREEVAR_{opCode.Argument}##"
            self.Instructions.append(opCode)

    def CanGoNext(self, offset=1):
        if self.CurrentInstructionIndex + offset >= 0 and self.CurrentInstructionIndex + offset < len(self.Instructions):
            return True
        return False

    def GoNext(self, offset=1):
        if self.CanGoNext(offset):
            self.CurrentInstructionIndex += offset
            return True
        return False

    def GoToOffset(self, offset):
        instructionIndex = self.GetIndexByOffset(offset)
        if instructionIndex < 0:
            return False
        self.CurrentInstructionIndex = instructionIndex
        return True

    def MoveBack(self):
        self.GoNext(-1)
        return ""

    def GetNextInstruction(self, offset=1):
        if not self.GoNext(offset):
            return None

        return self.Instructions[self.CurrentInstructionIndex]

    #
    # Look behind and look ahead functions
    #
    @property
    def Prev(self):
        if self.CanGoNext(-1):
            return self.Instructions[self.CurrentInstructionIndex - 1]
        return None

    @property
    def Next(self):
        return self.PeekNextInstruction()

    def PeekNextInstruction(self, position=1):
        if self.CurrentInstructionIndex + position >= len(self.Instructions):
            return None

        return self.Instructions[self.CurrentInstructionIndex + position]

    def PeekInstructionAt(self, position):
        if position >= len(self.Instructions) or position < 0:
            return None

        return self.Instructions[position]

    def PeekInstructionAtOffset(self, offset):
        startPos = 0
        if offset > self.Instructions[self.CurrentInstructionIndex].Offset:
            startPos = self.CurrentInstructionIndex + 1

        for position in range(startPos, len(self.Instructions)):
            if self.Instructions[position].Offset == offset:
                return self.Instructions[position]

        return None

    def PeekInstructionBeforeOffset(self, offset, backOffset=1):
        offset = self.GetIndexByOffset(offset)

        return self.PeekInstructionAt(offset - backOffset)

    @property
    def LastOffset(self):
        return self.Instructions[len(self.Instructions) - 1].Offset

    def GetIndexByOffset(self, offset):
        # TODO: Refactor this code to use binary search
        if offset < 0:
            return -1
        for position in range(len(self.Instructions)):
            if self.Instructions[position].Offset == offset:
                return position

        return -1

    def GetIndexByOpCode(self, opCodeID):
        for position in range(self.CurrentInstructionIndex + 1, len(self.Instructions)):
            if self.Instructions[position].OpCodeID == opCodeID:
                return position

        return -1

    def GetOpCodeByID(self, opCodeID, fromOffset=-1, toOffset=-1):
        startPosition = self.CurrentInstructionIndex + 1 if fromOffset < 0 else self.GetIndexByOffset(fromOffset)
        endPosition = len(self.Instructions) - 1 if toOffset <= 0 else self.GetIndexByOffset(toOffset)
        if startPosition > endPosition:
            tempPosition = startPosition
            startPosition = endPosition
            endPosition = tempPosition
        for position in range(startPosition, endPosition + 1):
            if self.Instructions[position].OpCodeID == opCodeID:
                return self.Instructions[position]

        return None

    def GetOpCodeByName(self, opCodeName, fromOffset=-1, toOffset=-1):
        partialMatch = False
        startPosition = self.CurrentInstructionIndex + 1 if fromOffset < 0 else self.GetIndexByOffset(fromOffset)
        endPosition = len(self.Instructions) - 1 if toOffset <= 0 else self.GetIndexByOffset(toOffset)
        if startPosition > endPosition:
            tempPosition = startPosition
            startPosition = endPosition
            endPosition = tempPosition

        if opCodeName.endswith("*"):
            partialMatch = True
            opCodeName = opCodeName[:len(opCodeName) - 1]

        for position in range(startPosition, endPosition + 1):
            if partialMatch:
                if self.Instructions[position].InstructionName.startswith(opCodeName):
                    return self.Instructions[position]
            elif self.Instructions[position].InstructionName == opCodeName:
                return self.Instructions[position]

        return None

    def GetOffsetByOpCode(self, opCodeID, fromOffset=-1, toOffset=-1):
        startPosition = self.CurrentInstructionIndex + 1 if fromOffset < 0 else self.GetIndexByOffset(fromOffset)
        endPosition = len(self.Instructions) - 1 if toOffset <= 0 else self.GetIndexByOffset(toOffset)
        if startPosition > endPosition:
            tempPosition = startPosition
            startPosition = endPosition
            endPosition = tempPosition
        for position in range(startPosition, endPosition + 1):
            if self.Instructions[position].OpCodeID == opCodeID:
                return self.Instructions[position].Offset

        return -1

    def GetReversedOffsetByOpCode(self, opCodeID, startOffset=-1, endOffset=-1):
        startPosition = self.CurrentInstructionIndex - 1
        endPosition = 0

        if startOffset > 0:
            startPosition = self.GetIndexByOffset(startOffset)

        if startPosition < 0 and startPosition >= len(self.Instructions):
            return -1

        if endOffset > 0:
            endPosition = self.GetIndexByOffset(endOffset)

        if endPosition < 0 and endPosition >= len(self.Instructions):
            return -1

        for position in range(startPosition, endPosition - 1, -1):
            if self.Instructions[position].OpCodeID == opCodeID:
                return self.Instructions[position].Offset

        return -1

    def GetOffsetByOpCodeName(self, opName):
        for position in range(self.CurrentInstructionIndex + 1, len(self.Instructions)):
            if self.Instructions[position].InstructionName.startswith(opName):
                return self.Instructions[position].Offset

        return -1

    def GetBackOffsetByOpCodeName(self, opName):
        for position in range(self.CurrentInstructionIndex - 1, -1, -1):
            if self.Instructions[position].InstructionName.startswith(opName):
                return self.Instructions[position].Offset

        return -1

    def GetLineOffsetRangeForOffset(self, offset):
        startOffset = self.GetIndexByOffset(offset)
        endOffset = startOffset
        line = self.CodeObject.LineNoTab[offset]

        while startOffset > 0:
            startOffset -= 1
            if self.CodeObject.LineNoTab[self.Instructions[startOffset].Offset] != line:
                startOffset += 1
                break

        while endOffset < len(self.Instructions) - 1:
            endOffset += 1
            if self.CodeObject.LineNoTab[self.Instructions[endOffset].Offset] != line:
                endOffset -= 1
                break

        startOffset = self.Instructions[startOffset].Offset
        endOffset = self.Instructions[endOffset].Offset

        return [line, startOffset, endOffset]

    def CountSpecificOpCodes(self, opCodes, offset=-1, endOffset=-1):
        startPos = 0 if offset == -1 else self.GetIndexByOffset(offset)
        endPos = len(self.Instructions) if endOffset == -1 else self.GetIndexByOffset(endOffset)
        count = 0

        if not isinstance(opCodes, list):
            opCodes = [opCodes]

        for position in range(startPos, endPos):
            if self.Instructions[position].OpCodeID in opCodes:
                count += 1

        return count

    def CheckIfOpCodesExistsInLine(self, opCodes, startOffset, endOffset):
        startPosition = self.GetIndexByOffset(startOffset)
        endPosition = self.GetIndexByOffset(endOffset)
        mapExists = {}

        for opCode in opCodes:
            mapExists[opCode] = False

        for position in range(startPosition, endPosition + 1):
            if self.Instructions[position].OpCodeID in opCodes:
                mapExists[self.Instructions[position].OpCodeID] = True

        for item in mapExists.values():
            if item == False:
                return False
        return True

    def FindEndOfBlock(self, originalOffset, currentOffset=-1):
        currentOffset = self.Instructions[self.CurrentInstructionIndex].Offset if currentOffset == -1 else currentOffset

        import sys
        g_cliArgs = getattr(sys.modules.get("__main__"), "g_cliArgs", None)
        debug = g_cliArgs and getattr(g_cliArgs, "debug", False)

        if debug:
            print(f"FindEndOfBlock(originalOffset={originalOffset}, currentOffset={currentOffset})")

        # NEW LOGIC: For backward jumps (loop/branch returns), scan forward to find
        # the actual end of the block by looking for JUMP instructions
        if originalOffset < currentOffset:
            # Try to find the end by scanning forward for JUMP instructions
            # The block ends where we find a JUMP to a DIFFERENT target
            lastMatchingJump = -1
            searchLimit = 50  # reasonable limit to avoid infinite loops

            # Start scanning from current instruction index forward
            startIdx = self.CurrentInstructionIndex
            for i in range(searchLimit):
                instr = self.PeekInstructionAt(startIdx + i)
                if not instr:
                    break

                # Found unconditional JUMP
                if instr.InstructionName == 'JUMP_ABSOLUTE' or instr.InstructionName == 'JUMP_FORWARD':
                    jumpTarget = instr.JumpTarget

                    if debug:
                        print(f"  Checking JUMP at offset {instr.Offset}: target={jumpTarget} vs originalOffset={originalOffset}")

                    # If JUMP target matches originalOffset, this is a loop-back jump
                    # Mark it as potential end, but keep scanning
                    if jumpTarget == originalOffset:
                        lastMatchingJump = instr.Offset
                        if debug:
                            print(f"    → Matching jump found at {instr.Offset}")
                    elif lastMatchingJump > 0:
                        # Found a JUMP with DIFFERENT target after a matching jump
                        # This means the matching jump was the end of the block
                        if debug:
                            print(f"    → Different target! Block ends at {lastMatchingJump}")
                        # Return the offset AFTER the matching jump as block end
                        return [lastMatchingJump + 3, None]
                    else:
                        # First JUMP has different target - this might be the block end
                        if debug:
                            print(f"    → First JUMP has different target, block might end at {instr.Offset}")
                        return [instr.Offset, None]

            # If we found matching jumps but no different target, use last matching jump
            if lastMatchingJump > 0:
                if debug:
                    print(f"  Using last matching jump at {lastMatchingJump + 3} as block end")
                return [lastMatchingJump + 3, None]

            # FALLBACK: Old dominator-based logic
            dominatorOp = self.PeekInstructionAtOffset(originalOffset)
            if dominatorOp and dominatorOp.OpCodeID in self.DOMINATORS:
                if debug:
                    print(f"  Fallback: Found dominator at {originalOffset}: {dominatorOp.InstructionName} → JumpTarget={dominatorOp.JumpTarget}")
                return [dominatorOp.JumpTarget, dominatorOp]
            dominatorOp = self.PeekInstructionAtOffset(originalOffset - 3)
            if dominatorOp and dominatorOp.OpCodeID in self.DOMINATORS:
                if debug:
                    print(f"  Fallback: Found dominator at {originalOffset - 3}: {dominatorOp.InstructionName} → JumpTarget={dominatorOp.JumpTarget}")
                return [dominatorOp.JumpTarget, dominatorOp]

        if debug:
            print(f"  No dominator found, returning originalOffset={originalOffset}")
        return [originalOffset, None]

    def extractImportNames(self, fromlist, callback):
        count = len(fromlist.Value)
        partIdx = 0
        for idx in range(self.CurrentInstructionIndex + 1, len(self.Instructions)):
            opCode = self.Instructions[idx]

            if opCode.OpCodeID == OpCodes.POP_TOP:
                self.CurrentInstructionIndex = idx
                if partIdx != count:
                    print(f"WARNING: ")
                return
            elif opCode.InstructionName.startswith("STORE_"):
                callback(str(fromlist.Value[partIdx]), opCode.Label)
                partIdx += 1


# Missing _A and legacy alias accessors referenced by handlers (JS returned
# undefined silently; in Python we alias to the base opcode ID where known
# and leave unknowns as None so hasattr(...) returns False during handler setup).
for _base, _alias in (
    ("STORE_SUBSCR", "STORE_SUBSCR_A"),
    ("BINARY_SUBSCR", "BINARY_SUBSCR_A"),
    ("DUP_TOP", "DUP_TOP_A"),
    ("POP_TOP", "POP_TOP_A"),
    ("RETURN_VALUE", "RETURN_VALUE_A"),
    ("POP_FINALLY_A", "POP_FINALLY"),
    ("CONTINUE_LOOP_A", "CONTINUE_LOOP"),
    ("CALL_FUNCTION_A", "CALL_FUNCTION"),
    ("LOAD_CONST_A", "LOAD_CONST"),
    ("COMPARE_OP_A", "COMPARE_OP"),
    ("BINARY_OP_A", "BINARY_OP"),
):
    if hasattr(OpCodes, _base) and not hasattr(OpCodes, _alias):
        setattr(OpCodes, _alias, getattr(OpCodes, _base))
