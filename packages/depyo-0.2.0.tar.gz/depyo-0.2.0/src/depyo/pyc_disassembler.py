from __future__ import annotations

from depyo.opcodes import OpCodes
from depyo.python_object import PythonCodeObject


class PycDisassembler:
    @staticmethod
    def Disassemble(reader, obj, parentPrefix=None):
        methodName = f'{parentPrefix or ""}{"." if parentPrefix else ""}{obj.Name}'
        result = f"Method name: {methodName}:\n"
        code = reader.OpCodes(obj)

        while code.HasInstructionsToProcess:
            try:
                code.GoNext()
                argValue = ""
                opCode = code.Current

                if opCode.HasConstant:
                    argValue = opCode.Constant
                elif opCode.HasName or opCode.HasLocal or opCode.HasFree:
                    argValue = opCode.Name or opCode.LocalName or opCode.FreeName
                elif opCode.HasJumpRelative:
                    argValue = opCode.Argument
                elif opCode.HasCompare:
                    argValue = opCode.CompareOperator
                if opCode.HasJumpRelative:
                    opCode.Argument += opCode.Offset + 3

                result += "\t" + " ".join([
                    pad(f"O:{opCode.Offset}, L:{obj.LineNoTab[opCode.Offset]}", 13),
                    pad(opCode.InstructionName, 19),
                    pad(opCode.Argument if opCode.HasArgument else "", 4),
                    "  ",
                    ("// Value: " + str(argValue)) if argValue != "" else ""
                ]) + "\n"
            except Exception as ex:
                result += "EXCEPTION: " + str(ex)

        for code_obj in [o for o in obj.Consts.Value if isinstance(o, PythonCodeObject)]:
            result += "\n"
            result += PycDisassembler.Disassemble(reader, code_obj, methodName)

        return result


def pad(s, length):
    spaces = ""
    strLen = len(str(s))
    for idx in range(length - strLen):
        spaces += " "
    return spaces + str(s)
