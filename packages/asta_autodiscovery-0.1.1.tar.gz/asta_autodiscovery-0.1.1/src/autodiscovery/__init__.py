"""AutoDiscovery package."""
