const examples = new Map([
  ["เจ็ด", "jed"],
  ["ลูก", "luk"],
  ["น้ำตา", "nam dta"],
  ["คนไทย", "khontai"],
  ["คิดถึงเธอ", "kit tueng ter"],
  ["ฮักเจ้าหลาย", "hak jao laai"],
  ["สบายดีไหม", "sabai dee mai"],
  ["อยู่ด้วยกัน", "yoo duay gan"],
]);

const input = document.querySelector("#thai-input");
const output = document.querySelector("#demo-output");

function updateOutput() {
  const value = input.value.trim();
  output.textContent = examples.get(value) || "Install the Python package for full romanization.";
}

input.addEventListener("input", updateOutput);

document.querySelectorAll("[data-example]").forEach((button) => {
  button.addEventListener("click", () => {
    input.value = button.dataset.example;
    updateOutput();
  });
});
