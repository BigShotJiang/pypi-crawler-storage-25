# Release Checklist

Use this before publishing `thairom` or shipping a romanization update.

## Before Release

1. Add or update romanization rules in `src/thairom/maps.py` or `src/thairom/thai.py`.
2. Add regression tests in `tests/test_romanize.py`.
3. Run:

```powershell
python -m pytest -q
```

4. If this is an update after the first PyPI publish, bump both versions:
   - `pyproject.toml`
   - `src/thairom/__init__.py`

5. Rebuild clean artifacts:

```powershell
Remove-Item -Recurse -Force dist
python -m build
python -m twine check dist\*
```

## First Publish

The current first-release version is `0.1.0`.

```powershell
$env:TWINE_USERNAME="__token__"
$env:TWINE_PASSWORD="pypi-your-token-here"
python -m twine upload dist\*
```

## Later Updates

PyPI does not allow replacing an existing uploaded version. For every update:

1. Bump the version, for example `0.1.0` to `0.1.1`.
2. Rebuild from a clean `dist` folder.
3. Upload the new version.

