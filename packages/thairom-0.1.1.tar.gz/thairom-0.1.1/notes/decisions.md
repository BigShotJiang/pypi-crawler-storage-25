﻿# Decisions

Record durable technical and product decisions here.

Use this format:

## YYYY-MM-DD - Decision Title

Decision:

Rationale:

Consequences:
