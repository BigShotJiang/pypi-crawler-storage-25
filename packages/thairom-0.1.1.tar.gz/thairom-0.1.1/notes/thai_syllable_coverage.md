# Thai Syllable Coverage Review

This is a practical review set for `thairom`, not a complete dictionary. Thai syllables combine:

- Initial consonant sound
- Vowel shape
- Final sound, including open syllables
- Tone/mark context

A full start x vowel x finish matrix across every Thai letter would create thousands of forms, many of them unnatural or not real words. This file uses real or common words to cover the important sound patterns.

## Initial Consonants

| Letter | Example | Current Target |
|---|---|---|
| ก | กา | ga |
| ข | ขา | kha |
| ฃ | ฃวด | khuad |
| ค | คน | khon |
| ฅ | ฅน | khon |
| ฆ | ฆ่า | kha |
| ง | งาน | ngan |
| จ | ใจ | jai |
| ฉ | ฉัน | chan |
| ช | ชา | cha |
| ซ | ซื้อ | sue |
| ฌ | เฌอ | choe |
| ญ | ผู้หญิง | phu ying |
| ฎ | ฎีกา | deeka |
| ฏ | ปฏัก | bpatak |
| ฐ | ฐาน | than |
| ฑ | มณฑล | monthon |
| ฒ | ผู้เฒ่า | phu thao |
| ณ | เณร | nen |
| ด | เด็ก | dek |
| ต | ตา | dta |
| ถ | ถนน | thanon |
| ท | ไทย | thai |
| ธ | ธรรม | tham |
| น | นา | na |
| บ | บ้าน | baan |
| ป | ปลา | bplaa |
| ผ | ผม | pom |
| ฝ | ฝัน | fan |
| พ | พ่อ | paw |
| ฟ | ฟัง | fang |
| ภ | ภาษา | phasaa |
| ม | มา | ma |
| ย | ยา | ya |
| ร | รัก | rak |
| ล | ลูก | luk |
| ว | วัน | wan |
| ศ | ศูนย์ | soon |
| ษ | ภาษา | phasaa |
| ส | สบาย | sabai |
| ห | ห้า | haa |
| ฬ | กีฬา | geelaa |
| อ | อร่อย | aroi |
| ฮ | ฮา | ha |

## Core Vowel Shapes

| Vowel Sound | Example | Current Target |
|---|---|---|
| a short | กะ | ga |
| aa long | กา | gaa |
| i short | กิน | gin |
| ee long | ดี | dee |
| ue short | ดึก | duek |
| uea long | เมือง | mueang |
| u short | ลุก | luk |
| oo long | ดู | du |
| e | เจ็ด | jed |
| ae | แม่ | mae |
| o short | คน | khon |
| oh long | โต | dto |
| aw | พ่อ | paw |
| eu | เธอ | ter |
| ia | เรียน | rian |
| ua | ครัว | krua |
| ai | ไทย | thai |
| ao | เข้า | khao |
| am | ทำ | tam |

## Final Sound Categories

| Final Sound | Thai Final Letters | Example | Current Target |
|---|---|---|---|
| open | none | มา | ma |
| k | ก ข ค ฆ | รัก | rak |
| t | จ ช ซ ฎ ฏ ฐ ฑ ฒ ด ต ถ ท ธ ศ ษ ส | เจ็ด | jed |
| p | บ ป พ ฟ ภ | ครับ | krap |
| n | น ณ ญ ร ล ฬ | คน | khon |
| m | ม | ผม | pom |
| ng | ง | เพลง | pleng |
| y | ย | สบาย | sabai |
| w | ว | แล้ว | laew |

## Starter Combination Matrix

These are compact start-vowel-finish examples for regression tests.

| Pattern | Example | Current Target |
|---|---|---|
| g + aa + open | กา | ga |
| g + a + k | กัก | gak |
| g + a + n | กัน | gan |
| g + a + m | กำ | gam |
| g + a + ng | กัง | gang |
| g + a + p | กับ | gap |
| g + a + t | กัด | gad |
| g + ai + open | ไก่ | gai |
| j + e + t | เจ็ด | jed |
| d + e + k | เด็ก | dek |
| dt + aa + open | ตา | dta |
| n + am + open | น้ำ | nam |
| n + am + dta | น้ำตา | nam dta |
| s + a + bai | สบาย | sabai |
| s + a + bai dee | สบายดี | sabai dee |
| y + oo + open | อยู่ | yoo |
| y + oo + duay gan | อยู่ด้วยกัน | yoo duay gan |
| t + awn + nee | ตอนนี้ | tawnnee |
| t + ee + nee | ที่นี่ | tee nee |
| kh + on + thai | คนไทย | khontai |
