﻿# Context

Project: thairom
Path: C:\code\thairom

Purpose:

- TODO: Summarize what this project does and who/what uses it.

Important files and directories:

- TODO: Add key source paths, config paths, deployment paths, and data locations.

Run/test/deploy commands:

- TODO: Add the commands future sessions should use.

Operational notes:

- TODO: Add services, URLs, ports, scheduled jobs, and environment assumptions.
