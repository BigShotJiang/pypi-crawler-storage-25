"""thairom -- Accurate Thai and Lao/Isan romanization for real-world text."""

from .thai import romanize_thai
from .lao import romanize_lao


def romanize(text, lang='th'):
    """Romanize Thai or Lao/Isan text.

    Args:
        text: Text string to romanize.
        lang: Language code -- 'th' for Thai (default), 'lo' for Lao/Isan.

    Returns:
        Lowercase romanized string.
    """
    if lang == 'lo':
        return romanize_lao(text)
    return romanize_thai(text)


__version__ = '0.1.1'
__all__ = ['romanize', 'romanize_thai', 'romanize_lao']
