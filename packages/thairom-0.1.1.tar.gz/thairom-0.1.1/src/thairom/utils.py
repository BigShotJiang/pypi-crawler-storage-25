"""Utility functions for romanization cleanup."""

import re


def cleanup_romanization(rom):
    """Strip leaked Thai/Lao characters and fix whitespace artifacts.

    After romanization, stray Thai (U+0E00-U+0E7F) or Lao (U+0E80-U+0EFF)
    characters sometimes remain. This function removes them and normalizes
    whitespace.

    Args:
        rom: Raw romanized string.

    Returns:
        Cleaned romanized string.
    """
    if not rom:
        return ''
    cleaned = re.sub(r'[\u0E00-\u0E7F\u0E80-\u0EFF]', '', rom)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned
