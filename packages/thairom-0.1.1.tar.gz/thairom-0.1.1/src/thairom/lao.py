"""Lao/Isan romanization for Thai-script Isan text."""

import re

from .maps import LAO_WORD_MAP, LAO_ROM_REPLACEMENTS


def _apply_lao_pronunciation(romanized, original_thai):
    """Apply Isan/Lao pronunciation rules to a Thai romanization.

    Isan dialect uses Lao pronunciation conventions, most notably replacing
    initial 'r' sounds with 'l'. This function applies those rules after
    the base Thai romanization.

    Args:
        romanized: Base romanized string from pythainlp.
        original_thai: Original Thai-script word (checked against LAO_WORD_MAP first).

    Returns:
        Romanized string with Lao/Isan pronunciation applied.
    """
    if original_thai in LAO_WORD_MAP:
        return LAO_WORD_MAP[original_thai]
    result = romanized.lower()
    result = re.sub(r'[\u0E00-\u0E7F\u0E80-\u0EFF]', '', result)
    for pattern, replacement in LAO_ROM_REPLACEMENTS:
        result = pattern.sub(replacement, result)
    return result.strip()


def romanize_lao(text):
    """Romanize Isan/Lao text written in Thai script.

    Uses pythainlp's newmm tokenizer and royin romanization as a base,
    then applies Lao/Isan word corrections and pronunciation rules
    (e.g., r -> l substitution).

    Args:
        text: Isan/Lao text in Thai script to romanize.

    Returns:
        Lowercase romanized string with Lao/Isan pronunciation.
    """
    if not text:
        return ''

    try:
        from pythainlp.tokenize import word_tokenize
        from pythainlp.transliterate import romanize
    except ImportError:
        return ''

    words = word_tokenize(text, engine='newmm')
    pieces = []
    for word in words:
        stripped = word.strip()
        if not stripped:
            continue
        if stripped in LAO_WORD_MAP:
            pieces.append(LAO_WORD_MAP[stripped])
            continue
        try:
            rom = romanize(stripped, engine='royin')
            rom = _apply_lao_pronunciation(rom, stripped)
            if rom:
                pieces.append(rom)
        except Exception:
            pieces.append(stripped)
    return ' '.join(pieces)
