"""Thai romanization with word-level corrections."""

import re

from .maps import THAI_WORD_MAP
from .utils import cleanup_romanization


# ==========================================================
# Systematic pronunciation fixes
# pythainlp's royin engine has consistent issues. Fix them
# all here rather than adding word-by-word map entries.
# ==========================================================

def _fix_romanization_per_word(rom, thai_word):
    """Fix systematic royin issues based on the original Thai word."""
    if not rom or not thai_word:
        return rom

    result = rom

    # 1. จ is ALWAYS "j", never "ch"
    #    royin uses "ch" for both จ and ช — fix จ words
    if thai_word and thai_word[0] == 'จ' and result.startswith('ch'):
        result = 'j' + result[2:]

    # 2. รู → "roo" not "ru" (long vowel)
    if 'รู' in thai_word and 'ru' in result:
        result = result.replace('ru', 'roo')

    # 3. Final ร is silent in many words, royin sometimes adds "n" or "r"
    #    (handled case by case in maps, hard to generalize)

    # 4. ทร → "s" sound (not "thr") in certain words
    #    e.g. ทราบ = saap, ทราย = saai
    if thai_word.startswith('ทร') and result.startswith('thr'):
        result = 's' + result[3:]

    return result


# Global post-processing — systematic royin→preferred pronunciation
_GLOBAL_FIXES = [
    # Vowels
    (re.compile(r'\bru\b'), 'roo'),           # รู → roo
    (re.compile(r'\byu\b'), 'yoo'),           # อยู่ → yoo
    (re.compile(r'\bru '), 'roo '),
    (re.compile(r'\byu '), 'yoo '),
    # จ = always j (royin uses "ch" for both จ and ช)
    # Handled per-word in _fix_romanization_per_word
    # ก็ → gaw (not kaw)
    (re.compile(r'\bkaw\b'), 'gaw'),
    # เธอ → ter (not thoe)
    (re.compile(r'\bthoe\b'), 'ter'),
    # แล้ว → laew (not laeo)
    (re.compile(r'\blaeo\b'), 'laew'),
    # เลย → loei (already correct in royin)
    # พี่ → pee (not phi)
    (re.compile(r'\bphi\b'), 'pee'),
    # ร้อง → rawng (not rong)
    (re.compile(r'\brong\b'), 'rawng'),
    # ทำ → tam (not tham)
    (re.compile(r'\btham\b'), 'tam'),
    # จ→j is handled per-word in _fix_romanization_per_word and THAI_WORD_MAP
    # Do NOT globally replace cha→ja — it breaks ช words (ช้า = cha)
    # ครับ → krap (not khrap)
    (re.compile(r'\bkhrap\b'), 'krap'),
    # คะ → ka (not kha when it's the polite particle)
    # ทร → s sound
    (re.compile(r'\bthr(?=a[ap]|ai)'), 's'),
    # User style preferences
    (re.compile(r'\bjet\b'), 'jed'),
    (re.compile(r'\blook\b'), 'luk'),
    (re.compile(r'\bsa bai\b'), 'sabai'),
    (re.compile(r'\bdi\b'), 'dee'),
    (re.compile(r'\bta\b'), 'dta'),
    (re.compile(r'\bkan\b'), 'gan'),
    (re.compile(r'\btonni\b'), 'tawnnee'),
    (re.compile(r'\bthini\b'), 'tee nee'),
    (re.compile(r'\bduaikan\b'), 'duay gan'),
]


def _apply_preferences(rom):
    """Apply systematic fixes and user preferences to final romanization."""
    if not rom:
        return rom
    result = rom
    for pattern, replacement in _GLOBAL_FIXES:
        result = pattern.sub(replacement, result)
    return result


def romanize_thai(text):
    """Romanize Thai text with improved accuracy over pythainlp alone.

    Uses pythainlp's newmm tokenizer and royin romanization engine as a base,
    then applies word-level corrections from THAI_WORD_MAP to fix common errors
    in colloquial speech, song lyrics, and everyday vocabulary.

    Args:
        text: Thai text string to romanize.

    Returns:
        Lowercase romanized string.
    """
    if not text:
        return ''

    try:
        from pythainlp.tokenize import word_tokenize
        from pythainlp.transliterate import romanize
    except ImportError:
        return ''

    words = word_tokenize(text, engine='newmm')

    # Multi-token compound map (token pairs that should merge)
    COMPOUND_MAP = {
        ('บอ', 'กว่า'): 'bok wa',
    }

    # Pre-pass: merge tokens with following ๆ if the compound is in the map,
    # and handle multi-token compounds
    merged = []
    i = 0
    while i < len(words):
        w = words[i].strip()
        # Check two-token compounds
        if i + 1 < len(words):
            pair = (w, words[i + 1].strip())
            if pair in COMPOUND_MAP:
                merged.append(('__compound__', COMPOUND_MAP[pair]))
                i += 2
                continue
            # Check ๆ compounds
            if words[i + 1].strip() == 'ๆ':
                compound = w + 'ๆ'
                if compound in THAI_WORD_MAP:
                    merged.append(compound)
                    i += 2
                    continue
        merged.append(w)
        i += 1

    pieces = []
    for stripped in merged:
        # Handle pre-resolved compound tuples
        if isinstance(stripped, tuple) and stripped[0] == '__compound__':
            pieces.append(stripped[1])
            continue
        if not stripped:
            continue
        # Handle ๆ (Mai Yamok) - repeats previous word
        if stripped == 'ๆ':
            if pieces:
                last = pieces[-1].split()[-1]
                pieces.append(last)
            continue
        if stripped in THAI_WORD_MAP:
            val = THAI_WORD_MAP[stripped]
            if val:
                pieces.append(val)
            continue
        try:
            rom = romanize(stripped, engine='royin')
            rom = cleanup_romanization(rom)
            rom = _fix_romanization_per_word(rom, stripped)
            if rom:
                pieces.append(rom)
        except Exception:
            pieces.append(stripped)
    return _apply_preferences(' '.join(pieces))
