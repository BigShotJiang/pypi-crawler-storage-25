"""Tests for thairom romanization.

Test cases derived from ground truth data covering song lyrics,
colloquial speech, common phrases, and Isan/Lao dialect.
"""

import pytest

from thairom import romanize, romanize_thai, romanize_lao


# ============================================================
# Thai romanization tests
# ============================================================

class TestRomanizeThai:
    """Test romanize_thai against ground truth Thai examples."""

    def test_empty_input(self):
        assert romanize_thai('') == ''

    def test_none_input(self):
        assert romanize_thai(None) == ''

    def test_greeting(self):
        assert romanize_thai('สวัสดีครับ') == 'sawatdee krap'

    def test_thank_you(self):
        assert romanize_thai('ขอบคุณมาก') == 'khop khun mak'

    def test_i_love_you(self):
        assert romanize_thai('ฉันรักเธอ') == 'chan rak ter'

    def test_where_have_you_been(self):
        assert romanize_thai('ไปไหนมา') == 'pai nai ma'

    def test_how_are_you(self):
        assert romanize_thai('สบายดีไหม') == 'sabai dee mai'

    def test_never_mind(self):
        assert romanize_thai('ไม่เป็นไร') == 'mai pen rai'

    def test_heart(self):
        assert romanize_thai('หัวใจ') == 'hua jai'

    def test_understand(self):
        assert romanize_thai('เข้าใจ') == 'khao jai'

    def test_tears(self):
        assert romanize_thai('น้ำตา') == 'nam dta'

    def test_six(self):
        assert romanize_thai('หก') == 'hok'

    @pytest.mark.parametrize(
        ('thai', 'expected'),
        [
            ('ศูนย์', 'soon'),
            ('หนึ่ง', 'neung'),
            ('สอง', 'song'),
            ('สาม', 'saam'),
            ('สี่', 'see'),
            ('ห้า', 'haa'),
            ('เจ็ด', 'jed'),
            ('แปด', 'paet'),
            ('เก้า', 'gao'),
            ('สิบ', 'sip'),
            ('สิบเอ็ด', 'sip et'),
            ('ยี่สิบ', 'yee sip'),
        ],
    )
    def test_numbers_preferred_style(self, thai, expected):
        assert romanize_thai(thai) == expected

    @pytest.mark.parametrize(
        ('thai', 'expected'),
        [
            ('ผม', 'pom'),
            ('เรา', 'rao'),
            ('คุณ', 'khun'),
            ('เขา', 'khao'),
            ('แม่', 'mae'),
            ('พ่อ', 'paw'),
            ('ลูก', 'luk'),
            ('เพื่อน', 'puean'),
            ('ผู้หญิง', 'phu ying'),
            ('ผู้ชาย', 'phu chai'),
            ('คนไทย', 'khontai'),
            ('ครอบครัว', 'kropkrua'),
            ('เหรอ', 'ror'),
            ('ขอโทษ', 'kho thot'),
            ('สบายดีไหม', 'sabai dee mai'),
            ('วันนี้', 'wan nee'),
            ('พรุ่งนี้', 'prung nee'),
            ('เมื่อวาน', 'muea wan'),
            ('ตอนนี้', 'tawnnee'),
            ('ที่นี่', 'tee nee'),
            ('อยู่ตรงนี้', 'yoo trong nee'),
            ('คิดถึงเธอ', 'kit tueng ter'),
            ('อยู่ด้วยกัน', 'yoo duay gan'),
        ],
    )
    def test_first_lesson_and_daily_speech_preferred_style(self, thai, expected):
        assert romanize_thai(thai) == expected

    @pytest.mark.parametrize(
        ('thai', 'expected'),
        [
            ('เด็ก', 'dek'),
            ('ดี', 'dee'),
            ('ดู', 'du'),
            ('ได้', 'dai'),
            ('ด้วย', 'duay'),
            ('คนเดียว', 'khon diao'),
        ],
    )
    def test_daw_dek_uses_d_not_dt(self, thai, expected):
        assert romanize_thai(thai) == expected

    def test_love_noun(self):
        assert romanize_thai('ความรัก') == 'khwam rak'

    def test_time(self):
        assert romanize_thai('เวลา') == 'welaa'

    def test_all_the_time(self):
        assert romanize_thai('ตลอดเวลา') == 'talod welaa'

    def test_song_lyric_pretend_to_care(self):
        assert romanize_thai('แกล้งเป็นห่วง') == 'klaeng pen huang'

    def test_song_lyric_give_importance(self):
        assert romanize_thai('ให้ความสำคัญ') == 'hai khwam sam khan'

    def test_song_lyric_waste_tears(self):
        assert romanize_thai('เสียน้ำตา') == 'sia nam dta'

    def test_song_lyric_those_are_all(self):
        assert romanize_thai('ทั้งนั้น') == 'thang nan'

    def test_song_lyric_never_bound(self):
        assert romanize_thai('ไม่เคยผูกพัน') == 'mai khoei phuk phan'

    def test_song_lyric_leave_immediately(self):
        assert romanize_thai('ทิ้งชิ่งไปทันที') == 'thing jing pai tawntee'

    def test_song_lyric_sit_and_lament(self):
        assert romanize_thai('นั่งเพ้อรำพัน') == 'nang phoe ram phan'

    def test_song_lyric_like_this(self):
        assert romanize_thai('อยู่อย่างนี้') == 'yoo yang nee'

    def test_colloquial_pup_pap(self):
        assert romanize_thai('ปุ๊บๆปั๊บๆก็คงไป') == 'pup pap gaw khong pai'

    def test_eaten_yet(self):
        assert romanize_thai('กินข้าวหรือยัง') == 'kin khao rue yang'


# ============================================================
# Lao/Isan romanization tests
# ============================================================

class TestRomanizeLao:
    """Test romanize_lao against ground truth Lao/Isan examples."""

    def test_empty_input(self):
        assert romanize_lao('') == ''

    def test_none_input(self):
        assert romanize_lao(None) == ''

    def test_love_you_much(self):
        assert romanize_lao('ฮักเจ้าหลาย') == 'hak jao laai'

    def test_dont_know_what_to_do(self):
        assert romanize_lao('บ่ฮู้จะเฮ็ดจั่งใด') == 'baw huu cha het jang dai'

    def test_we_will_go_together(self):
        assert romanize_lao('เฮาสิไปนำกัน') == 'hao si pai nam kan'

    def test_our_house_is_far(self):
        assert romanize_lao('เฮือนเฮาอยู่ไกล') == 'huean hao yuu klai'

    def test_little_sister_very(self):
        assert romanize_lao('น้องหล่าคัก') == 'nawng laa khak'

    def test_really_indeed(self):
        assert romanize_lao('อีหลีเด้อ') == 'ii lii doe'

    def test_talk_a_bit(self):
        assert romanize_lao('เว้ากันหน่อย') == 'wao kan noi'

    def test_look_and_see(self):
        assert romanize_lao('เบิ่งดูแม่น') == 'boeng du maen'

    def test_our_lady(self):
        assert romanize_lao('ผู้สาวเฮา') == 'phuu sao hao'

    def test_very_fun(self):
        assert romanize_lao('ม่วนคัก') == 'muan khak'


# ============================================================
# Top-level romanize() dispatch tests
# ============================================================

class TestRomanizeDispatch:
    """Test the top-level romanize() function dispatches correctly."""

    def test_default_is_thai(self):
        assert romanize('หัวใจ') == 'hua jai'

    def test_explicit_thai(self):
        assert romanize('น้ำตา', lang='th') == 'nam dta'

    def test_lao_dispatch(self):
        assert romanize('ฮักเจ้าหลาย', lang='lo') == 'hak jao laai'

    def test_lao_explicit(self):
        assert romanize('ม่วนคัก', lang='lo') == 'muan khak'
