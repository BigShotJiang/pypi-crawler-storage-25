# defi-analytics-py v4

DeFi analytics for NEAR Protocol.

## Requirements

Python 3.9+

## Installation

pip install pypi-defi-analytics-py-v4

## Quick Start

from defi_analytics_py_v4 import PypiDefiAnalyticsPyV4Client

client = PypiDefiAnalyticsPyV4Client()

## API Reference

### Constructor

PypiDefiAnalyticsPyV4Client(rpc_url: str = NEAR_RPC, timeout: int = 30)

### Methods

| Method | Description |
|--------|-------------|
| `get_account_balance(account_id)` | Get NEAR account balance |
| `get_ft_balance(account_id, contract_id)` | Get fungible token balance |
| `get_pools()` | Fetch all liquidity pools |
| `get_pool_tvl(pool_id)` | Get TVL for a specific pool |
| `get_top_pools_by_tvl(limit)` | Get top pools ranked by TVL |
| `get_near_price()` | Get current NEAR price in USD |
| `get_token_price(token_id)` | Get price for a specific token |
| `portfolio_summary(account_id)` | Get full portfolio summary |
| `get_network_status()` | Get NEAR network status |

## Usage Example

from defi_analytics_py_v4 import PypiDefiAnalyticsPyV4Client

client = PypiDefiAnalyticsPyV4Client()

# Get NEAR price
price = client.get_near_price()

# Get account balance
balance = client.get_account_balance("alice.near")

# Get top pools by TVL
top_pools = client.get_top_pools_by_tvl(limit=10)

# Portfolio summary
summary = client.portfolio_summary("alice.near")

# Network status
status = client.get_network_status()

## License

MIT