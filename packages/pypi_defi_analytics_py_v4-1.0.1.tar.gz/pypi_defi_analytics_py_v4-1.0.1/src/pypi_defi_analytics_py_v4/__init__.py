"""DeFi analytics for NEAR Protocol."""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

import requests

__version__ = "1.0.0"
__all__ = ["PypiDefiAnalyticsPyV4Client"]

NEAR_RPC = "https://rpc.mainnet.near.org"
REF_FINANCE_API = "https://indexer.ref.finance"


class PypiDefiAnalyticsPyV4Client:
    """DeFi analytics client for NEAR Protocol."""

    def __init__(self, rpc_url: str = NEAR_RPC, timeout: int = 30) -> None:
        self.rpc_url = rpc_url
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json"})

    # ── RPC helpers ────────────────────────────────────────────────────────

    def _rpc(self, method: str, params: Any) -> Any:
        """Send a NEAR JSON-RPC request."""
        payload = {"jsonrpc": "2.0", "id": "defi", "method": method, "params": params}
        r = self._session.post(self.rpc_url, json=payload, timeout=self.timeout)
        r.raise_for_status()
        data = r.json()
        if "error" in data:
            raise RuntimeError(data["error"])
        return data.get("result", {})

    def _view(self, contract: str, method: str, args_base64: str = "e30=") -> Any:
        """Call a NEAR view function."""
        result = self._rpc(
            "query",
            {
                "request_type": "call_function",
                "finality": "final",
                "account_id": contract,
                "method_name": method,
                "args_base64": args_base64,
            },
        )
        import base64, json
        raw = base64.b64decode(result["result"])
        return json.loads(raw)

    # ── Account / Token ────────────────────────────────────────────────────

    def get_account_balance(self, account_id: str) -> Dict[str, Any]:
        """Return NEAR balance for an account."""
        result = self._rpc(
            "query",
            {"request_type": "view_account", "finality": "final", "account_id": account_id},
        )
        yocto = int(result.get("amount", 0))
        return {
            "account_id": account_id,
            "yoctoNEAR": yocto,
            "NEAR": round(yocto / 1e24, 6),
        }

    def get_ft_balance(self, token_contract: str, account_id: str) -> Dict[str, Any]:
        """Return fungible token balance."""
        import base64, json
        args = base64.b64encode(json.dumps({"account_id": account_id}).encode()).decode()
        balance = self._view(token_contract, "ft_balance_of", args)
        meta = self._view(token_contract, "ft_metadata")
        decimals = meta.get("decimals", 18)
        raw = int(balance)
        return {
            "account_id": account_id,
            "contract": token_contract,
            "symbol": meta.get("symbol", ""),
            "raw_balance": raw,
            "balance": round(raw / 10**decimals, 6),
            "decimals": decimals,
        }

    # ── Ref Finance pools ──────────────────────────────────────────────────

    def get_pools(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Fetch top pools from Ref Finance."""
        r = self._session.get(
            f"{REF_FINANCE_API}/list-pools",
            params={"limit": limit},
            timeout=self.timeout,
        )
        if r.status_code != 200:
            return []
        data = r.json()
        pools = data if isinstance(data, list) else data.get("pools", [])
        return pools[:limit]

    def get_pool_tvl(self, pool_id: int) -> Dict[str, Any]:
        """Return TVL for a Ref Finance pool."""
        r = self._session.get(f"{REF_FINANCE_API}/get-pool", params={"pool_id": pool_id}, timeout=self.timeout)
        r.raise_for_status()
        pool = r.json()
        return {"pool_id": pool_id, "tvl": pool.get("tvl", 0), "token_symbols": pool.get("token_symbols", [])}

    def get_top_pools_by_tvl(self, top_n: int = 10) -> List[Dict[str, Any]]:
        """Return top N pools sorted by TVL."""
        pools = self.get_pools(limit=100)
        ranked = sorted(pools, key=lambda p: float(p.get("tvl", 0) or 0), reverse=True)
        return ranked[:top_n]

    # ── Price ──────────────────────────────────────────────────────────────

    def get_near_price(self) -> Dict[str, Any]:
        """Fetch current NEAR price in USD from CoinGecko."""
        r = self._session.get(
            "https://api.coingecko.com/api/v3/simple/price",
            params={"ids": "near", "vs_currencies": "usd"},
            timeout=self.timeout,
        )
        r.raise_for_status()
        price = r.json().get("near", {}).get("usd", 0)
        return {"symbol": "NEAR", "price_usd": price, "timestamp": int(time.time())}

    def get_token_price(self, token_id: str) -> Dict[str, Any]:
        """Fetch token price from Ref Finance."""
        r = self._session.get(f"{REF_FINANCE_API}/get-token-price", params={"token_id": token_id}, timeout=self.timeout)
        if r.status_code != 200:
            return {"token_id": token_id, "price": None}
        return {"token_id": token_id, **r.json()}

    # ── Portfolio ──────────────────────────────────────────────────────────

    def portfolio_summary(self, account_id: str, token_contracts: Optional[List[str]] = None) -> Dict[str, Any]:
        """Return a portfolio summary for an account."""
        near_bal = self.get_account_balance(account_id)
        near_price = self.get_near_price()
        near_usd = round(near_bal["NEAR"] * near_price["price_usd"], 4)
        tokens: List[Dict[str, Any]] = []
        for ct in (token_contracts or []):
            try:
                tokens.append(self.get_ft_balance(ct, account_id))
            except Exception:
                pass
        return {
            "account_id": account_id,
            "NEAR": near_bal["NEAR"],
            "NEAR_usd": near_usd,
            "near_price_usd": near_price["price_usd"],
            "tokens": tokens,
            "timestamp": int(time.time()),
        }

    # ── Network stats ──────────────────────────────────────────────────────

    def get_network_status(self) -> Dict[str, Any]:
        """Return basic NEAR network status."""
        status = self._rpc("status", [None])
        sync = status.get("sync_info", {})
        return {
            "chain_id": status.get("chain_id"),
            "latest_block_height": sync.get("latest_block_height"),
            "latest_block_time": sync.get("latest_block_time"),
            "node_key": status.get("node_key"),
        }