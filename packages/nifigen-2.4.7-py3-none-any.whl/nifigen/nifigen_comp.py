
"""
NiFi Automation Library
=======================
This module provides a comprehensive set of functions for automating Apache NiFi
operations through the REST API. It includes functions for managing process groups,
processors, controller services, connections, and flow deployment.

Version: 1.0.0
Author: [Your Name/Organization]
"""

import requests
import time
import json
import uuid
import os
import logging
from typing import Dict, List, Optional, Any, Union, Tuple

# ---------------------------------------------------------------------------
# Logger setup - writes to file only, never touches stdout.
# Callers can override by reconfiguring the "nifigen" logger before use.
# ---------------------------------------------------------------------------
logger = logging.getLogger("nifigen")
if not logger.handlers:
    logger.setLevel(logging.DEBUG)
    _fh = logging.FileHandler("nifigen.log", encoding="utf-8")
    _fh.setLevel(logging.DEBUG)
    _fh.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(funcName)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(_fh)
    logger.propagate = False          # don't bubble up to root logger



def get_processor_stats(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Retrieves processor statistics for a given process group.
    """
    print(f"🔍 ENTERING get_processor_stats - PG ID: {pg_id}, NiFi URL: {NIFI_URL}")
    try:
        logger.debug(f"Making GET request to {NIFI_URL}/flow/process-groups/{pg_id}")
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        processors = r.json()["processGroupFlow"]["flow"].get("processors", [])
        print(f"Found {len(processors)} processors in PG {pg_id}")

        running = 0
        stopped = 0

        for p in processors:
            state = p["component"].get("state")
            if state == "RUNNING":
                running += 1
                logger.debug(f"Processor {p['component'].get('name')} is RUNNING")
            else:
                stopped += 1
                logger.debug(f"Processor {p['component'].get('name')} is STOPPED")

        result = {
            "status": True,
            "running": running,
            "stopped": stopped,
            "total": len(processors)
        }
        print(f"📊 Processor stats - Running: {running}, Stopped: {stopped}, Total: {len(processors)}")
        print(f"✅ EXITING get_processor_stats - Success")
        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error getting processor stats for PG {pg_id}: {str(e)}")
        print(f"❌ EXITING get_processor_stats - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response format for processor stats: {str(e)}")
        print(f"❌ EXITING get_processor_stats - Failed with key error")
        return {"status": False, "error": f"Invalid response format: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error getting processor stats for PG {pg_id}: {str(e)}")
        print(f"❌ EXITING get_processor_stats - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_root_flows(NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Retrieves all flows under the ROOT process group with processor statistics.
    """
    print(f"🔍 ENTERING get_root_flows - NiFi URL: {NIFI_URL}")
    try:
        url = f"{NIFI_URL}/flow/process-groups/root"
        logger.debug(f"Making GET request to {url}")
        r = requests.get(url, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        data = r.json()["processGroupFlow"]
        flow = data["flow"]
        print(f"Root PG ID: {data['id']}")

        results = []

        # Process Groups with processor stats
        pg_count = len(flow.get("processGroups", []))
        print(f"Found {pg_count} process groups under root")
        for idx, pg in enumerate(flow.get("processGroups", []), 1):
            comp = pg["component"]
            logger.debug(f"Processing PG {idx}/{pg_count}: {comp['name']} (ID: {comp['id']})")

            stats = get_processor_stats(comp["id"], NIFI_URL, verify_ssl=verify_ssl)
            s_status = comp.get("state")
            if stats["running"] == stats["total"]:
                s_status = "RUNNING"

            results.append({
                "id": comp["id"],
                "name": comp["name"],
                "type": "PROCESS_GROUP",
                "state": s_status or comp.get("statelessGroupScheduledState"),
                "processors": {
                    "running": stats["running"],
                    "stopped": stats["stopped"],
                    "total": stats["total"]
                }
            })

        # Processors directly under ROOT
        proc_count = len(flow.get("processors", []))
        print(f"Found {proc_count} processors directly under root")
        for p in flow.get("processors", []):
            comp = p["component"]
            results.append({
                "id": comp["id"],
                "name": comp["name"],
                "type": "PROCESSOR",
                "state": comp.get("state")
            })

        # Input Ports
        ip_count = len(flow.get("inputPorts", []))
        print(f"Found {ip_count} input ports under root")
        for ip in flow.get("inputPorts", []):
            comp = ip["component"]
            results.append({
                "id": comp["id"],
                "name": comp["name"],
                "type": "INPUT_PORT",
                "state": comp.get("state")
            })

        # Output Ports
        op_count = len(flow.get("outputPorts", []))
        print(f"Found {op_count} output ports under root")
        for op in flow.get("outputPorts", []):
            comp = op["component"]
            results.append({
                "id": comp["id"],
                "name": comp["name"],
                "type": "OUTPUT_PORT",
                "state": comp.get("state")
            })

        result = {
            "status": True,
            "root_id": data["id"],
            "flows": results
        }
        print(f"✅ Root flows retrieved - Total flow items: {len(results)}")
        print(f"✅ EXITING get_root_flows - Success")
        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error getting root flows: {str(e)}")
        print(f"❌ EXITING get_root_flows - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response format for root flows: {str(e)}")
        print(f"❌ EXITING get_root_flows - Failed with key error")
        return {"status": False, "error": f"Invalid response format: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error getting root flows: {str(e)}")
        print(f"❌ EXITING get_root_flows - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def controller_service_exists(pg_id: str, name: str, NIFI_URL: str, verify_ssl: bool = False) -> Optional[Dict[str, Any]]:
    """
    Checks if a controller service exists by name in a process group.
    """
    print(f"🔍 ENTERING controller_service_exists - PG ID: {pg_id}, Service name: '{name}', NiFi URL: {NIFI_URL}")
    try:
        logger.debug(f"Making GET request to {NIFI_URL}/flow/process-groups/{pg_id}/controller-services")
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        services = r.json()["controllerServices"]
        print(f"Found {len(services)} controller services in PG {pg_id}")

        for idx, cs in enumerate(services, 1):
            cs_name = cs["component"]["name"]
            logger.debug(f"Checking service {idx}/{len(services)}: '{cs_name}'")
            if cs_name == name:
                print(f"✅ Controller service '{name}' found with ID: {cs['id']}")
                print(f"✅ EXITING controller_service_exists - Service found")
                return cs

        print(f"❌ Controller service '{name}' not found in PG {pg_id}")
        print(f"✅ EXITING controller_service_exists - Service not found")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error checking controller service existence: {str(e)}")
        print(f"❌ EXITING controller_service_exists - Failed with network error")
        return None
    except KeyError as e:
        logger.error(f"❌ Invalid response format checking controller service: {str(e)}")
        print(f"❌ EXITING controller_service_exists - Failed with key error")
        return None
    except Exception as e:
        logger.error(f"❌ Unexpected error checking controller service existence: {str(e)}")
        print(f"❌ EXITING controller_service_exists - Failed with unexpected error")
        return None


def create_controller_service(pg_id: str, cs_def: Dict[str, Any], NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Creates a new controller service in a process group.
    """
    print(f"🔍 ENTERING create_controller_service - PG ID: {pg_id}, Service name: '{cs_def.get('name', 'UNKNOWN')}', Type: '{cs_def.get('type', 'UNKNOWN')}'")
    logger.debug(f"Controller service definition: {json.dumps(cs_def, indent=2)}")
    try:
        print(f"Checking if controller service '{cs_def['name']}' already exists")
        existing = controller_service_exists(pg_id, cs_def["name"], NIFI_URL, verify_ssl=verify_ssl)
        if existing:
            print(f"✅ Controller service '{cs_def['name']}' already exists with ID: {existing['id']}")
            print(f"✅ EXITING create_controller_service - Service already exists")
            return {"status": True, "data": existing, "message": "Service already exists"}

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": cs_def["type"],
                "bundle": cs_def["bundle"],
                "name": cs_def["name"],
                "properties": cs_def["properties"],
                "comments": cs_def.get("comments", "")
            }
        }
        logger.debug(f"Creating controller service with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {NIFI_URL}/process-groups/{pg_id}/controller-services")
        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/controller-services",
            json=payload,
            verify=verify_ssl
        )

        if r.status_code == 409:
            logger.warning(f"⚠️ Conflict creating controller service - Status 409: {r.text}")
            print(f"❌ EXITING create_controller_service - Conflict")
            return {"status": False, "error": r.text}

        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")
        print(f"✅ Controller service created - ID: {r.json().get('id')}")

        print(f"✅ EXITING create_controller_service - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating controller service: {str(e)}")
        print(f"❌ EXITING create_controller_service - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid controller service definition: {str(e)}")
        print(f"❌ EXITING create_controller_service - Failed with key error")
        return {"status": False, "error": f"Invalid definition: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating controller service: {str(e)}")
        print(f"❌ EXITING create_controller_service - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_process_orch_group(parent_pg_id: str, name: str, NIFI_URL: str, 
                             position: Tuple[int, int] = (200, 200),
                             verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a new process group with orchestration naming convention.
    """
    print(f"🔍 ENTERING create_process_orch_group - Parent PG ID: {parent_pg_id}, Name: '{name}_orch', Position: {position}")
    try:
        url = f"{NIFI_URL}/process-groups/{parent_pg_id}/process-groups"
        payload = {
            "revision": {"version": 0},
            "component": {
                "name": f"{name}_orch",
                "position": {"x": position[0], "y": position[1]}
            }
        }
        logger.debug(f"Creating process group with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        pg_id = r.json().get("id")
        print(f"✅ Process group created - Name: '{name}_orch', ID: {pg_id}")

        print(f"✅ EXITING create_process_orch_group - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating process group: {str(e)}")
        print(f"❌ EXITING create_process_orch_group - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating process group: {str(e)}")
        print(f"❌ EXITING create_process_orch_group - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def enable_controller_service(cs_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Enables a controller service by ID.
    """
    print(f"🔍 ENTERING enable_controller_service - Controller Service ID: {cs_id}")
    try:
        print(f"Fetching current revision for controller service {cs_id}")
        logger.debug(f"Making GET request to {NIFI_URL}/controller-services/{cs_id}")
        r = requests.get(f"{NIFI_URL}/controller-services/{cs_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        rev = r.json()["revision"]["version"]
        print(f"Current revision version: {rev}")

        payload = {
            "revision": {"version": rev},
            "component": {"id": cs_id, "state": "ENABLED"}
        }
        logger.debug(f"Enabling service with payload: {json.dumps(payload, indent=2)}")

        print(f"Making PUT request to {NIFI_URL}/controller-services/{cs_id}")
        r2 = requests.put(
            f"{NIFI_URL}/controller-services/{cs_id}",
            json=payload,
            verify=verify_ssl
        )
        r2.raise_for_status()
        print(f"✅ PUT request successful - Status code: {r2.status_code}")
        print(f"✅ Controller service {cs_id} enabled successfully")

        print(f"✅ EXITING enable_controller_service - Success")
        return {"status": True, "data": r2.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error enabling controller service: {str(e)}")
        print(f"❌ EXITING enable_controller_service - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid controller service response: {str(e)}")
        print(f"❌ EXITING enable_controller_service - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error enabling controller service: {str(e)}")
        print(f"❌ EXITING enable_controller_service - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def import_controller_services(pg_id: str, file_path: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Imports controller services from a JSON file.
    """
    print(f"🔍 ENTERING import_controller_services - PG ID: {pg_id}, File: {file_path}")
    try:
        print(f"Loading controller service definitions from {file_path}")
        with open(file_path) as f:
            services = json.load(f)

        print(f"Loaded {len(services)} service definitions from file")
        created = []

        for idx, cs in enumerate(services, 1):
            print(f"Processing service {idx}/{len(services)}: '{cs['name']}'")
            cs_entity = create_controller_service(pg_id, cs, NIFI_URL, verify_ssl=verify_ssl)
            if cs_entity["status"]:
                created.append(cs_entity["data"])
                print(f"✅ Service '{cs['name']}' created successfully")
            else:
                logger.error(f"❌ Failed to create service: {cs['name']}")

        print(f"Enabling {len(created)} created controller services")
        for cs in created:
            print(f"Enabling service {cs['id']}")
            enable_result = enable_controller_service(cs["id"], NIFI_URL, verify_ssl=verify_ssl)
            if not enable_result["status"]:
                logger.error(f"❌ Failed to enable service: {cs['id']}")

        result = {"status": True, "created_services": created, "last_service_id": cs["id"] if created else None}
        print(f"✅ Import completed - {len(created)} services created")
        print(f"✅ EXITING import_controller_services - Success")
        return result
    except FileNotFoundError as e:
        logger.error(f"❌ Controller services file not found: {str(e)}")
        print(f"❌ EXITING import_controller_services - File not found")
        return {"status": False, "error": f"File not found: {str(e)}"}
    except json.JSONDecodeError as e:
        logger.error(f"❌ Invalid JSON in controller services file: {str(e)}")
        print(f"❌ EXITING import_controller_services - Invalid JSON")
        return {"status": False, "error": f"Invalid JSON: {str(e)}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error importing controller services: {str(e)}")
        print(f"❌ EXITING import_controller_services - Network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error importing controller services: {str(e)}")
        print(f"❌ EXITING import_controller_services - Unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_processor_in_pg(pg_id: str, comp: Dict[str, Any], NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Creates a processor in a process group using component definition.
    """
    print(f"🔍 ENTERING create_processor_in_pg - PG ID: {pg_id}, Processor name: '{comp.get('name', 'UNKNOWN')}', Type: '{comp.get('type', 'UNKNOWN')}'")
    try:
        print("Waiting 4 seconds before creating processor (rate limiting)")
        time.sleep(4)
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": comp["type"],
                "name": comp["name"],
                "position": {"x": comp["position"]["x"], "y": comp["position"]["y"]},
                "config": comp.get("config", {})
            }
        }
        logger.debug(f"Creating processor with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        proc_id = r.json().get("id")
        print(f"✅ Processor created - Name: '{comp['name']}', ID: {proc_id}")

        print(f"✅ EXITING create_processor_in_pg - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating processor: {str(e)}")
        print(f"❌ EXITING create_processor_in_pg - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid processor component definition: {str(e)}")
        print(f"❌ EXITING create_processor_in_pg - Failed with key error")
        return {"status": False, "error": f"Invalid definition: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating processor: {str(e)}")
        print(f"❌ EXITING create_processor_in_pg - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_processor_by_type(pg_id: str, processor_type: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Finds a processor by type within a process group.
    """
    print(f"🔍 ENTERING get_processor_by_type - PG ID: {pg_id}, Processor type: '{processor_type}'")
    try:
        print("Waiting 5 seconds before fetching processor (rate limiting)")
        time.sleep(5)
        logger.debug(f"Making GET request to {NIFI_URL}/flow/process-groups/{pg_id}")
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        processors = r.json()["processGroupFlow"]["flow"]["processors"]
        print(f"Found {len(processors)} processors in PG {pg_id}")

        for idx, p in enumerate(processors, 1):
            p_type = p["component"]["type"]
            p_name = p["component"]["name"]
            logger.debug(f"Checking processor {idx}/{len(processors)}: '{p_name}' (Type: {p_type})")
            if p_type == processor_type:
                print(f"✅ Found processor with type '{processor_type}' - Name: '{p_name}', ID: {p['id']}")
                print(f"✅ EXITING get_processor_by_type - Success")
                return {"status": True, "data": p}

        error_msg = f"Processor of type '{processor_type}' not found in PG {pg_id}"
        logger.error(f"❌ {error_msg}")
        print(f"❌ EXITING get_processor_by_type - Processor not found")
        return {"status": False, "error": error_msg}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error getting processor by type: {str(e)}")
        print(f"❌ EXITING get_processor_by_type - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response format getting processor by type: {str(e)}")
        print(f"❌ EXITING get_processor_by_type - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error getting processor by type: {str(e)}")
        print(f"❌ EXITING get_processor_by_type - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def bind_websocket_controller_service(processor_id: str, cs_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Binds a WebSocket controller service to a processor.
    """
    print(f"🔍 ENTERING bind_websocket_controller_service - Processor ID: {processor_id}, Controller Service ID: {cs_id}")
    try:
        print(f"Fetching current revision for processor {processor_id}")
        logger.debug(f"Making GET request to {NIFI_URL}/processors/{processor_id}")
        r = requests.get(f"{NIFI_URL}/processors/{processor_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        proc = r.json()
        rev = proc["revision"]["version"]
        print(f"Current revision version: {rev}")

        properties = proc["component"]["config"]["properties"]
        properties["WebSocket Server Controller Service"] = cs_id
        print(f"Updated WebSocket controller service property to: {cs_id}")

        payload = {
            "revision": {"version": rev},
            "component": {
                "id": processor_id,
                "config": {"properties": properties}
            }
        }
        logger.debug(f"Binding with payload: {json.dumps(payload, indent=2)}")

        print(f"Making PUT request to {NIFI_URL}/processors/{processor_id}")
        r2 = requests.put(
            f"{NIFI_URL}/processors/{processor_id}",
            json=payload,
            verify=verify_ssl
        )
        r2.raise_for_status()
        print(f"✅ PUT request successful - Status code: {r2.status_code}")

        print(f"✅ WebSocket controller service bound successfully to processor {processor_id}")

        print(f"✅ EXITING bind_websocket_controller_service - Success")
        return {"status": True, "message": "WebSocket controller service bound successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error binding WebSocket controller service: {str(e)}")
        print(f"❌ EXITING bind_websocket_controller_service - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid processor response binding WebSocket: {str(e)}")
        print(f"❌ EXITING bind_websocket_controller_service - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error binding WebSocket controller service: {str(e)}")
        print(f"❌ EXITING bind_websocket_controller_service - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_connection(pg_id: str, conn: Dict[str, Any], NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Creates a connection between components in a process group.
    """
    print(f"🔍 ENTERING create_connection - PG ID: {pg_id}, Connection name: '{conn.get('component', {}).get('name', 'UNKNOWN')}'")
    try:
        print("Waiting 5 seconds before creating connection (rate limiting)")
        time.sleep(5)
        url = f"{NIFI_URL}/process-groups/{pg_id}/connections"

        src_old = conn["component"]["source"]["id"]
        dst_old = conn["component"]["destination"]["id"]

        print(f"Source ID: {src_old}")
        print(f"Destination ID: {dst_old}")

        payload = {
            "revision": {"version": 0},
            "component": {
                "name": conn["component"].get("selectedRelationships", ["success"])[0],
                "parentGroupId": pg_id,
                "source": {
                    "id": src_old,
                    "type": conn["component"]["source"]["type"],
                    "groupId": pg_id,
                    "name": conn["component"]["source"]["name"]
                },
                "destination": {
                    "id": dst_old,
                    "type": conn["component"]["destination"]["type"],
                    "groupId": pg_id,
                    "name": conn["component"]["source"]["name"]
                },
                "selectedRelationships": conn["component"].get("selectedRelationships", ["success"]),
                "flowFileExpiration": conn["component"].get("flowFileExpiration", "0 sec"),
                "backPressureObjectThreshold": conn["component"].get("backPressureObjectThreshold", 10000),
                "backPressureDataSizeThreshold": conn["component"].get("backPressureDataSizeThreshold", "1 GB"),
                "availableRelationships": conn["component"].get("availableRelationships", [])
            }
        }
        logger.debug(f"Creating connection with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, headers={'Content-Type': 'application/json'}, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        print(f"✅ Connection created successfully - ID: {r.json().get('id')}")

        print(f"✅ EXITING create_connection - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating connection: {str(e)}")
        print(f"❌ EXITING create_connection - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid connection definition: {str(e)}")
        print(f"❌ EXITING create_connection - Failed with key error")
        return {"status": False, "error": f"Invalid definition: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating connection: {str(e)}")
        print(f"❌ EXITING create_connection - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_process_group_full(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Retrieves complete process group data including all components.
    """
    print(f"🔍 ENTERING get_process_group_full - PG ID: {pg_id}")
    try:
        print("Waiting 5 seconds before fetching process group data (rate limiting)")
        time.sleep(5)
        url = f"{NIFI_URL}/flow/process-groups/{pg_id}"
        logger.debug(f"Making GET request to {url}")
        r = requests.get(url, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        print(f"✅ Process group data retrieved successfully for PG {pg_id}")

        print(f"✅ EXITING get_process_group_full - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error getting process group full data: {str(e)}")
        print(f"❌ EXITING get_process_group_full - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error getting process group full data: {str(e)}")
        print(f"❌ EXITING get_process_group_full - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_controller_service_by_type(pg_id: str, cs_type: str, name: str, 
                                     NIFI_URL: str, properties: Optional[Dict] = None,
                                     verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a controller service by type in a process group.
    """
    print(f"🔍 ENTERING create_controller_service_by_type - PG ID: {pg_id}, Type: '{cs_type}', Name: '{name}'")
    try:
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": cs_type,
                "name": name,
                "properties": properties or {}
            }
        }
        logger.debug(f"Creating controller service with payload: {json.dumps(payload, indent=2)}")

        url = f"{NIFI_URL}/process-groups/{pg_id}/controller-services"
        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        cs_id = r.json()["id"]
        print(f"✅ Controller service created - Name: '{name}', ID: {cs_id}")

        print(f"✅ EXITING create_controller_service_by_type - Success")
        return {"status": True, "cs_id": cs_id}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating controller service by type: {str(e)}")
        print(f"❌ EXITING create_controller_service_by_type - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response creating controller service: {str(e)}")
        print(f"❌ EXITING create_controller_service_by_type - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating controller service by type: {str(e)}")
        print(f"❌ EXITING create_controller_service_by_type - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def start_processor(processor_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Starts a processor by ID.
    """
    print(f"🔍 ENTERING start_processor - Processor ID: {processor_id}")
    try:
        print(f"Fetching current revision for processor {processor_id}")
        url_get = f"{NIFI_URL}/processors/{processor_id}"
        logger.debug(f"Making GET request to {url_get}")
        resp = requests.get(url_get, verify=verify_ssl)
        resp.raise_for_status()
        print(f"✅ GET request successful - Status code: {resp.status_code}")

        processor = resp.json()
        revision = processor['revision']['version']
        processor_name = processor['component']['name']
        print(f"Processor '{processor_name}' current revision: {revision}")

        url_put = f"{NIFI_URL}/processors/{processor_id}/run-status"
        payload = {
            "revision": {"version": revision},
            "state": "RUNNING"
        }
        logger.debug(f"Starting processor with payload: {json.dumps(payload, indent=2)}")

        print(f"Making PUT request to {url_put}")
        r = requests.put(url_put, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ PUT request successful - Status code: {r.status_code}")
        print(f"✅ Processor '{processor_name}' (ID: {processor_id}) started successfully")

        print(f"✅ EXITING start_processor - Success")
        return {"status": True, "message": f"Processor {processor_id} started successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error starting processor: {str(e)}")
        print(f"❌ EXITING start_processor - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid processor response starting: {str(e)}")
        print(f"❌ EXITING start_processor - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error starting processor: {str(e)}")
        print(f"❌ EXITING start_processor - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def connect_components(
    pg_id: str,
    source_id: str,
    source_type: str,
    destination_id: str,
    destination_type: str,
    NIFI_URL: str,
    relationships: Optional[List[str]] = None,
    name: Optional[str] = None,
    flowfile_expiration: str = "0 sec",
    backpressure_count: int = 10000,
    backpressure_size: str = "1 GB",
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a connection between any two NiFi components.
    """
    print(f"🔍 ENTERING connect_components - PG ID: {pg_id}, Source: {source_type} ({source_id}), Destination: {destination_type} ({destination_id})")
    try:
        print(f"Source connection: {source_id}")
        print(f"Destination connection: {destination_id}")

        # Normalize processor types from fully qualified names
        if source_type.startswith("org.apache.nifi.processors"):
            source_type = "PROCESSOR"
            logger.debug(f"Normalized source type to PROCESSOR")
        if destination_type.startswith("org.apache.nifi.processors"):
            destination_type = "PROCESSOR"
            logger.debug(f"Normalized destination type to PROCESSOR")

        if relationships is None:
            relationships = ["success"]
            logger.debug(f"Using default relationships: {relationships}")

        if source_type == "INPUT_PORT":
            relationships = None
            logger.debug("Source is INPUT_PORT, setting relationships to None")

        url = f"{NIFI_URL}/process-groups/{pg_id}/connections"

        connection_name = name or f"{source_id[:6]}_to_{destination_id[:6]}"
        payload = {
            "revision": {"version": 0},
            "component": {
                "parentGroupId": pg_id,
                "name": connection_name,
                "source": {
                    "id": source_id,
                    "type": source_type,
                    "groupId": pg_id
                },
                "destination": {
                    "id": destination_id,
                    "type": destination_type,
                    "groupId": pg_id
                },
                "selectedRelationships": relationships,
                "flowFileExpiration": flowfile_expiration,
                "backPressureObjectThreshold": backpressure_count,
                "backPressureDataSizeThreshold": backpressure_size
            }
        }
        logger.debug(f"Creating connection with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        print(f"✅ Connected {source_type} ({source_id}) → {destination_type} ({destination_id}) relationships={relationships}")

        print(f"✅ EXITING connect_components - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error connecting components: {str(e)}")
        print(f"❌ EXITING connect_components - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid component IDs connecting: {str(e)}")
        print(f"❌ EXITING connect_components - Failed with key error")
        return {"status": False, "error": f"Invalid IDs: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error connecting components: {str(e)}")
        print(f"❌ EXITING connect_components - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_processor_by_id(processor_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Retrieves processor details by ID.
    """
    print(f"🔍 ENTERING get_processor_by_id - Processor ID: {processor_id}")
    try:
        url = f"{NIFI_URL}/processors/{processor_id}"
        logger.debug(f"Making GET request to {url}")
        r = requests.get(url, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        processor_name = r.json()["component"]["name"]
        print(f"✅ Processor found - Name: '{processor_name}', ID: {processor_id}")

        print(f"✅ EXITING get_processor_by_id - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error getting processor by ID: {str(e)}")
        print(f"❌ EXITING get_processor_by_id - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error getting processor by ID: {str(e)}")
        print(f"❌ EXITING get_processor_by_id - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_processors_in_pg(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Retrieves all processors in a process group.
    """
    print(f"🔍 ENTERING get_processors_in_pg - PG ID: {pg_id}")
    try:
        url = f"{NIFI_URL}/flow/process-groups/{pg_id}"
        logger.debug(f"Making GET request to {url}")
        r = requests.get(url, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        processors = r.json()["processGroupFlow"]["flow"]["processors"]
        print(f"Found {len(processors)} processors in PG {pg_id}")

        print(f"✅ EXITING get_processors_in_pg - Success")
        return {"status": True, "data": processors}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error getting processors in PG: {str(e)}")
        print(f"❌ EXITING get_processors_in_pg - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response getting processors: {str(e)}")
        print(f"❌ EXITING get_processors_in_pg - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error getting processors in PG: {str(e)}")
        print(f"❌ EXITING get_processors_in_pg - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def export_process_group(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Exports a process group as JSON file.
    """
    print(f"🔍 ENTERING export_process_group - PG ID: {pg_id}")
    try:
        url = f"{NIFI_URL}/flow/process-groups/{pg_id}"
        logger.debug(f"Making GET request to {url}")
        r = requests.get(url, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        pg_json = r.json()["processGroupFlow"]
        print(f"✅ Process group data exported successfully for PG {pg_id}")

        print(f"✅ EXITING export_process_group - Success")
        return {"status": True, "data": pg_json}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error exporting process group: {str(e)}")
        print(f"❌ EXITING export_process_group - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response exporting process group: {str(e)}")
        print(f"❌ EXITING export_process_group - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error exporting process group: {str(e)}")
        print(f"❌ EXITING export_process_group - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_all_child_process_group_ids(parent_pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Recursively retrieves all child process group IDs under a parent PG.
    """
    print(f"🔍 ENTERING get_all_child_process_group_ids - Parent PG ID: {parent_pg_id}")
    try:
        all_pg_ids = []

        def _walk(pg_id: str, depth: int = 0):
            indent = "  " * depth
            logger.debug(f"{indent}Walking PG: {pg_id}")
            url = f"{NIFI_URL}/process-groups/{pg_id}/process-groups"
            logger.debug(f"{indent}Making GET request to {url}")
            r = requests.get(url, verify=verify_ssl)
            r.raise_for_status()
            logger.debug(f"{indent}✅ GET request successful - Status code: {r.status_code}")

            data = r.json()
            child_pgs = data["processGroups"]
            logger.debug(f"{indent}Found {len(child_pgs)} child process groups under {pg_id}")

            for pg in child_pgs:
                child_id = pg["id"]
                child_name = pg["component"]["name"]
                all_pg_ids.append(child_id)
                logger.debug(f"{indent}Adding child PG: '{child_name}' (ID: {child_id})")
                _walk(child_id, depth + 1)

        print(f"Starting recursive walk from parent PG {parent_pg_id}")
        _walk(parent_pg_id)

        print(f"✅ Found {len(all_pg_ids)} total child process groups under {parent_pg_id}")

        print(f"✅ EXITING get_all_child_process_group_ids - Success")
        return {"status": True, "data": all_pg_ids}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error getting child PG IDs: {str(e)}")
        print(f"❌ EXITING get_all_child_process_group_ids - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error getting child PG IDs: {str(e)}")
        print(f"❌ EXITING get_all_child_process_group_ids - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def stop_all_processors(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Stops all processors in a process group.
    """
    print(f"🔍 ENTERING stop_all_processors - PG ID: {pg_id}")
    try:
        print(f"Fetching all processors in PG {pg_id}")
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        processors = r.json()["processGroupFlow"]["flow"].get("processors", [])
        print(f"Found {len(processors)} processors in PG {pg_id}")

        stopped_count = 0
        for p in processors:
            if p["component"]["state"] != "STOPPED":
                proc_id = p["id"]
                proc_name = p["component"]["name"]
                print(f"Stopping processor '{proc_name}' (ID: {proc_id})")

                pr = requests.get(f"{NIFI_URL}/processors/{proc_id}", verify=verify_ssl)
                pr.raise_for_status()
                rev = pr.json()["revision"]["version"]

                payload = {
                    "revision": {"version": rev},
                    "state": "STOPPED"
                }

                stop_resp = requests.put(
                    f"{NIFI_URL}/processors/{proc_id}/run-status",
                    json=payload,
                    verify=verify_ssl
                )
                stop_resp.raise_for_status()
                stopped_count += 1
                print(f"✅ Processor '{proc_name}' stopped")

        print(f"✅ {stopped_count} processors stopped in PG {pg_id}")

        print(f"✅ EXITING stop_all_processors - Success")
        return {"status": True, "message": f"All processors stopped in PG {pg_id}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error stopping all processors: {str(e)}")
        print(f"❌ EXITING stop_all_processors - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response stopping processors: {str(e)}")
        print(f"❌ EXITING stop_all_processors - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error stopping all processors: {str(e)}")
        print(f"❌ EXITING stop_all_processors - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def stop_all_ports(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Stops all input and output ports in a process group.
    """
    print(f"🔍 ENTERING stop_all_ports - PG ID: {pg_id}")
    try:
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        flow = r.json()["processGroupFlow"]["flow"]
        input_ports = flow.get("inputPorts", [])
        output_ports = flow.get("outputPorts", [])
        print(f"Found {len(input_ports)} input ports and {len(output_ports)} output ports in PG {pg_id}")

        stopped_count = 0
        for port_type, ports in [("inputPorts", input_ports), ("outputPorts", output_ports)]:
            port_type_api = "input-ports" if port_type == "inputPorts" else "output-ports"
            display_type = "INPUT" if port_type == "inputPorts" else "OUTPUT"

            for p in ports:
                if p["component"]["state"] != "STOPPED":
                    port_id = p["id"]
                    port_name = p["component"]["name"]
                    print(f"Stopping {display_type} port '{port_name}' (ID: {port_id})")

                    pr = requests.get(f"{NIFI_URL}/{port_type_api}/{port_id}", verify=verify_ssl)
                    pr.raise_for_status()
                    rev = pr.json()["revision"]["version"]

                    payload = {
                        "revision": {"version": rev},
                        "state": "STOPPED"
                    }

                    stop_resp = requests.put(
                        f"{NIFI_URL}/{port_type_api}/{port_id}/run-status",
                        json=payload,
                        verify=verify_ssl
                    )
                    stop_resp.raise_for_status()
                    stopped_count += 1
                    print(f"✅ {display_type} port '{port_name}' stopped")

        print(f"✅ {stopped_count} ports stopped in PG {pg_id}")

        print(f"✅ EXITING stop_all_ports - Success")
        return {"status": True, "message": f"All ports stopped in PG {pg_id}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error stopping all ports: {str(e)}")
        print(f"❌ EXITING stop_all_ports - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response stopping ports: {str(e)}")
        print(f"❌ EXITING stop_all_ports - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error stopping all ports: {str(e)}")
        print(f"❌ EXITING stop_all_ports - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def empty_all_queues(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Empties all flowfile queues in a process group.
    """
    print(f"🔍 ENTERING empty_all_queues - PG ID: {pg_id}")
    try:
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        connections = r.json()["processGroupFlow"]["flow"].get("connections", [])
        print(f"Found {len(connections)} connections in PG {pg_id}")

        emptied_count = 0
        for c in connections:
            conn_id = c["id"]
            conn_name = c.get("component", {}).get("name", "UNKNOWN")
            print(f"Emptying queue for connection '{conn_name}' (ID: {conn_id})")

            drop_resp = requests.post(
                f"{NIFI_URL}/flowfile-queues/{conn_id}/drop-requests",
                verify=verify_ssl
            )
            drop_resp.raise_for_status()
            emptied_count += 1
            print(f"✅ Queue emptied for connection {conn_id}")

        print(f"✅ {emptied_count} queues emptied in PG {pg_id}")

        print(f"✅ EXITING empty_all_queues - Success")
        return {"status": True, "message": f"All queues emptied in PG {pg_id}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error emptying all queues: {str(e)}")
        print(f"❌ EXITING empty_all_queues - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error emptying all queues: {str(e)}")
        print(f"❌ EXITING empty_all_queues - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def disable_all_controller_services(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Disables all controller services in a process group.
    """
    print(f"🔍 ENTERING disable_all_controller_services - PG ID: {pg_id}")
    try:
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        services = r.json().get("controllerServices", [])
        print(f"Found {len(services)} controller services in PG {pg_id}")

        disabled_count = 0
        for cs in services:
            cs_id = cs["id"]
            cs_name = cs["component"]["name"]
            print(f"Disabling controller service '{cs_name}' (ID: {cs_id})")

            cr = requests.get(f"{NIFI_URL}/controller-services/{cs_id}", verify=verify_ssl)
            cr.raise_for_status()
            rev = cr.json()["revision"]["version"]

            payload = {
                "revision": {"version": rev},
                "component": {
                    "id": cs_id,
                    "state": "DISABLED"
                }
            }

            disable_resp = requests.put(
                f"{NIFI_URL}/controller-services/{cs_id}",
                json=payload,
                verify=verify_ssl
            )
            disable_resp.raise_for_status()
            disabled_count += 1
            print(f"✅ Controller service '{cs_name}' disabled")

        print(f"✅ {disabled_count} controller services disabled in PG {pg_id}")

        print(f"✅ EXITING disable_all_controller_services - Success")
        return {"status": True, "message": f"All controller services disabled in PG {pg_id}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error disabling all controller services: {str(e)}")
        print(f"❌ EXITING disable_all_controller_services - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response disabling services: {str(e)}")
        print(f"❌ EXITING disable_all_controller_services - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error disabling all controller services: {str(e)}")
        print(f"❌ EXITING disable_all_controller_services - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def delete_process_group(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Deletes a process group.
    """
    print(f"🔍 ENTERING delete_process_group - PG ID: {pg_id}")
    try:
        print(f"Fetching current revision for PG {pg_id}")
        r = requests.get(f"{NIFI_URL}/process-groups/{pg_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        rev = r.json()["revision"]["version"]
        pg_name = r.json()["component"]["name"]
        print(f"PG '{pg_name}' revision: {rev}")

        print(f"Deleting process group '{pg_name}' (ID: {pg_id})")
        delete_resp = requests.delete(
            f"{NIFI_URL}/process-groups/{pg_id}",
            params={"version": rev},
            verify=verify_ssl
        )
        delete_resp.raise_for_status()
        print(f"✅ Process Group '{pg_name}' deleted")

        print(f"✅ EXITING delete_process_group - Success")
        return {"status": True, "message": f"Process Group {pg_id} deleted"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error deleting process group: {str(e)}")
        print(f"❌ EXITING delete_process_group - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response deleting process group: {str(e)}")
        print(f"❌ EXITING delete_process_group - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error deleting process group: {str(e)}")
        print(f"❌ EXITING delete_process_group - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_controller_service_by_name(pg_id: str, service_name: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Retrieves a controller service by name within a process group.
    """
    print(f"🔍 ENTERING get_controller_service_by_name - PG ID: {pg_id}, Service name: '{service_name}'")
    try:
        url = f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services"
        logger.debug(f"Making GET request to {url}")
        r = requests.get(url, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        services = r.json().get("controllerServices", [])
        print(f"Found {len(services)} controller services in PG {pg_id}")

        for idx, cs in enumerate(services, 1):
            cs_name = cs["component"]["name"]
            logger.debug(f"Checking service {idx}/{len(services)}: '{cs_name}'")
            if cs_name == service_name:
                print(f"✅ Controller service '{service_name}' found with ID: {cs['id']}")
                print(f"✅ EXITING get_controller_service_by_name - Success")
                return {"status": True, "data": cs}

        logger.error(f"❌ Controller service '{service_name}' not found")
        print(f"❌ EXITING get_controller_service_by_name - Service not found")
        return {"status": False, "error": f"Controller service '{service_name}' not found"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error getting controller service by name: {str(e)}")
        print(f"❌ EXITING get_controller_service_by_name - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response getting controller service: {str(e)}")
        print(f"❌ EXITING get_controller_service_by_name - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error getting controller service by name: {str(e)}")
        print(f"❌ EXITING get_controller_service_by_name - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_process_group_inside_pg(
    parent_pg_id: str,
    name: str,
    NIFI_URL: str,
    position: Tuple[float, float] = (200.0, 200.0),
    fail_if_exists: bool = True,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a process group inside an existing process group.
    """
    print(f"🔍 ENTERING create_process_group_inside_pg - Parent PG ID: {parent_pg_id}, Name: '{name}', Position: {position}, Fail if exists: {fail_if_exists}")
    try:
        print(f"Checking if PG '{name}' already exists under parent {parent_pg_id}")
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{parent_pg_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        existing_pgs = r.json()["processGroupFlow"]["flow"]["processGroups"]
        print(f"Found {len(existing_pgs)} existing process groups under parent")

        for pg in existing_pgs:
            if pg["component"]["name"] == name:
                pg_id = pg["component"]["id"]
                print(f"PG '{name}' already exists with ID: {pg_id}")
                if fail_if_exists:
                    print(f"❌ EXITING create_process_group_inside_pg - PG already exists and fail_if_exists=True")
                    return {
                        "status": False,
                        "id": pg_id,
                        "name": name,
                        "message": "Process Group already exists"
                    }
                else:
                    print(f"✅ EXITING create_process_group_inside_pg - PG already exists but fail_if_exists=False")
                    return {
                        "status": True,
                        "id": pg_id,
                        "name": name,
                        "message": "Process Group already exists"
                    }

        print(f"Creating new process group '{name}'")
        payload = {
            "revision": {"version": 0},
            "component": {
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                }
            }
        }
        logger.debug(f"Creating PG with payload: {json.dumps(payload, indent=2)}")

        r = requests.post(
            f"{NIFI_URL}/process-groups/{parent_pg_id}/process-groups",
            json=payload,
            verify=verify_ssl
        )
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        pg_id = r.json()["id"]
        print(f"✅ Created Process Group '{name}' with ID: {pg_id}")

        print(f"✅ EXITING create_process_group_inside_pg - Success")
        return {
            "status": True,
            "id": pg_id,
            "name": name
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating process group inside PG: {str(e)}")
        print(f"❌ EXITING create_process_group_inside_pg - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response creating process group: {str(e)}")
        print(f"❌ EXITING create_process_group_inside_pg - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating process group inside PG: {str(e)}")
        print(f"❌ EXITING create_process_group_inside_pg - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_input_port(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    position_id: int = 0,
    allow_remote_access: bool = False,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates an input port inside a process group.
    """
    print(f"🔍 ENTERING create_input_port - PG ID: {pg_id}, Name: '{name}', Position ID: {position_id}, Allow remote access: {allow_remote_access}")
    try:
        position = (400 * position_id, 0.0)
        print(f"Creating input port at position: {position}")
        url = f"{NIFI_URL}/process-groups/{pg_id}/input-ports"

        payload = {
            "revision": {"version": 0},
            "component": {
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "allowRemoteAccess": allow_remote_access
            }
        }
        logger.debug(f"Creating input port with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        port_id = r.json()["id"]
        print(f"✅ Created Input Port '{name}' with ID: {port_id}")

        print(f"✅ EXITING create_input_port - Success")
        return {
            "status": True,
            "id": port_id,
            "name": name,
            "data": r.json()
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating input port: {str(e)}")
        print(f"❌ EXITING create_input_port - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating input port: {str(e)}")
        print(f"❌ EXITING create_input_port - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_execute_stream_command(
    pg_id: str,
    NIFI_URL: str,
    name: str = "ExecuteStreamCommand",
    command: str = "",
    command_arguments: str = "",
    working_dir: str = "",
    position_id: int = 1,
    scheduling_period: str = "0 sec",
    environment: Optional[Dict[str, str]] = None,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates an ExecuteStreamCommand processor in a process group.
    """
    print(f"🔍 ENTERING create_execute_stream_command - PG ID: {pg_id}, Name: '{name}', Command: '{command}', Position ID: {position_id}")
    try:
        position = (500 * position_id, 0.0)
        print(f"Creating processor at position: {position}")
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        properties = {
            "Command Path": command,
            "Command Arguments": command_arguments,
            "Working Directory": working_dir,
            "Ignore STDIN": "false",
            "Redirect STDERR": "true",
            "Argument Delimiter": ";",
            "Max Attribute Length": "5000",
            "Output MIME Type": "application/json"
        }

        if environment:
            env_str = "\n".join(f"{k}={v}" for k, v in environment.items())
            properties["Environment Variables"] = env_str
            logger.debug(f"Added {len(environment)} environment variables")

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.ExecuteStreamCommand",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "config": {
                    "properties": properties,
                    "schedulingPeriod": scheduling_period,
                    "executionNode": "ALL",
                    "autoTerminatedRelationships": [
                        "original",
                        "nonzero status"
                    ]
                }
            }
        }
        logger.debug(f"Creating ExecuteStreamCommand with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        proc_id = r.json()["id"]
        print(f"✅ Created ExecuteStreamCommand '{name}' with ID: {proc_id}")

        print(f"✅ EXITING create_execute_stream_command - Success")
        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json()
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating ExecuteStreamCommand: {str(e)}")
        print(f"❌ EXITING create_execute_stream_command - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid configuration creating ExecuteStreamCommand: {str(e)}")
        print(f"❌ EXITING create_execute_stream_command - Failed with key error")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating ExecuteStreamCommand: {str(e)}")
        print(f"❌ EXITING create_execute_stream_command - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_output_port(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    position_id: int = 2,
    allow_remote_access: bool = False,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates an output port inside a process group.
    """
    print(f"🔍 ENTERING create_output_port - PG ID: {pg_id}, Name: '{name}', Position ID: {position_id}, Allow remote access: {allow_remote_access}")
    try:
        position = (500 * position_id, 0.0)
        print(f"Creating output port at position: {position}")
        url = f"{NIFI_URL}/process-groups/{pg_id}/output-ports"

        payload = {
            "revision": {"version": 0},
            "component": {
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "allowRemoteAccess": allow_remote_access
            }
        }
        logger.debug(f"Creating output port with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        port_id = r.json()["id"]
        print(f"✅ Created Output Port '{name}' with ID: {port_id}")

        print(f"✅ EXITING create_output_port - Success")
        return {
            "status": True,
            "id": port_id,
            "name": name,
            "data": r.json()
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating output port: {str(e)}")
        print(f"❌ EXITING create_output_port - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating output port: {str(e)}")
        print(f"❌ EXITING create_output_port - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_put_websocket(
    pg_id: str,
    name: str,
    comp: Dict[str, Any],
    NIFI_URL: str,
    position_id: int = 0,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a PutWebSocket processor.
    """
    print(f"🔍 ENTERING create_put_websocket - PG ID: {pg_id}, Name: '{name}', Position ID: {position_id}")
    try:
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.websocket.PutWebSocket",
                "name": name,
                "position": {
                    "x": 400 + (position_id * 150),
                    "y": 300
                },
                "config": {
                    "properties": {
                        "WebSocket Session Id": comp["WebSocket Session Id"],
                        "WebSocket Controller Service Id": comp["WebSocket Controller Service Id"],
                        "WebSocket Endpoint Id": comp["WebSocket Endpoint Id"],
                        "WebSocket Message Type": comp["WebSocket Message Type"]
                    },
                    "autoTerminatedRelationships": ["failure", "success"],
                    "schedulingPeriod": "0 sec",
                    "executionNode": "ALL"
                }
            }
        }
        logger.debug(f"Creating PutWebSocket with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        response = requests.post(url, json=payload, verify=verify_ssl)
        response.raise_for_status()
        print(f"✅ POST request successful - Status code: {response.status_code}")

        proc_id = response.json().get("id")
        print(f"✅ Created PutWebSocket processor '{name}' with ID: {proc_id}")

        print(f"✅ EXITING create_put_websocket - Success")
        return {"status": True, "data": response.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating PutWebSocket processor: {str(e)}")
        print(f"❌ EXITING create_put_websocket - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid configuration creating PutWebSocket: {str(e)}")
        print(f"❌ EXITING create_put_websocket - Failed with key error")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating PutWebSocket processor: {str(e)}")
        print(f"❌ EXITING create_put_websocket - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def add_handle_http_response(
    pg_id: str,
    http_cs_id: str,
    NIFI_URL: str,
    http_status_code:str ='200',
    processor_name: str = "HandleHttpResponse",
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a HandleHttpResponse processor in a process group.
    """
    print(f"🔍 ENTERING add_handle_http_response - PG ID: {pg_id}, HTTP CS ID: {http_cs_id}, Processor name: '{processor_name}'")
    try:
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        payload = {
            "revision": {"version": 0},
            "component": {
                "name": f"{processor_name}_HTTP_rep",
                "type": "org.apache.nifi.processors.standard.HandleHttpResponse",
                "config": {
                    "properties": {
                        "HTTP Status Code": http_status_code,
                        "HTTP Context Map": http_cs_id,
                        "Attributes for HTTP Response": "Content-Type:application/json"
                    },
                    "autoTerminatedRelationships": ["failure", "success"]
                }
            }
        }
        logger.debug(f"Creating HandleHttpResponse with payload: {json.dumps(payload, indent=2)}")

        headers = {"Content-Type": "application/json"}
        print(f"Making POST request to {url}")
        r = requests.post(url, headers=headers, data=json.dumps(payload), verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        proc_id = r.json().get("id")
        print(f"✅ Created HandleHttpResponse processor with ID: {proc_id}")

        print(f"✅ EXITING add_handle_http_response - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error adding HandleHttpResponse: {str(e)}")
        print(f"❌ EXITING add_handle_http_response - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid configuration adding HandleHttpResponse: {str(e)}")
        print(f"❌ EXITING add_handle_http_response - Failed with key error")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error adding HandleHttpResponse: {str(e)}")
        print(f"❌ EXITING add_handle_http_response - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def add_route_on_attribute_rule(
    route_proc_id: str,
    rule_name: str,
    expression: str,
    NIFI_URL: str,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Adds a new rule (dynamic property) to a RouteOnAttribute processor.
    """
    print(f"🔍 ENTERING add_route_on_attribute_rule - Processor ID: {route_proc_id}, Rule name: '{rule_name}', Expression: '{expression}'")
    try:
        print(f"Fetching current state for processor {route_proc_id}")
        proc = requests.get(f"{NIFI_URL}/processors/{route_proc_id}", verify=verify_ssl).json()
        rev = proc["revision"]["version"]
        proc_name = proc["component"]["name"]
        print(f"Processor '{proc_name}' revision: {rev}")

        properties = proc["component"]["config"]["properties"] or {}
        properties[rule_name] = expression
        logger.debug(f"Updated properties: {json.dumps(properties, indent=2)}")

        payload = {
            "revision": {"version": rev},
            "component": {
                "id": route_proc_id,
                "config": {
                    "properties": properties
                }
            }
        }

        print(f"Making PUT request to {NIFI_URL}/processors/{route_proc_id}")
        r = requests.put(f"{NIFI_URL}/processors/{route_proc_id}", json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ PUT request successful - Status code: {r.status_code}")

        print("Waiting 5 seconds for changes to propagate")
        time.sleep(5)

        print(f"✅ Added RouteOnAttribute rule: '{rule_name}'")

        print(f"✅ EXITING add_route_on_attribute_rule - Success")
        return {"status": True, "message": f"Rule '{rule_name}' added successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error adding RouteOnAttribute rule: {str(e)}")
        print(f"❌ EXITING add_route_on_attribute_rule - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid processor response adding route rule: {str(e)}")
        print(f"❌ EXITING add_route_on_attribute_rule - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error adding RouteOnAttribute rule: {str(e)}")
        print(f"❌ EXITING add_route_on_attribute_rule - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def connect_processor_to_child_pg(
    parent_pg_id: str,
    processor_id: str,
    child_pg_id: str,
    NIFI_URL: str,
    relationships: List[str],
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Connects a processor in a parent PG to a child PG's input port.
    """
    print(f"🔍 ENTERING connect_processor_to_child_pg - Parent PG: {parent_pg_id}, Processor ID: {processor_id}, Child PG: {child_pg_id}, Relationships: {relationships}")
    try:
        print(f"Fetching input ports for child PG {child_pg_id}")
        r = requests.get(f"{NIFI_URL}/process-groups/{child_pg_id}/input-ports", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        input_ports = r.json()["inputPorts"]
        print(f"Found {len(input_ports)} input ports in child PG")

        if not input_ports:
            error_msg = f"Child PG {child_pg_id} has no input ports"
            logger.error(f"❌ {error_msg}")
            print(f"❌ EXITING connect_processor_to_child_pg - No input ports")
            return {"status": False, "error": error_msg}

        input_port = input_ports[0]
        input_port_name = input_port["component"]["name"]
        print(f"Using input port '{input_port_name}' (ID: {input_port['id']})")

        print(f"Fetching processor {processor_id} info")
        r = requests.get(f"{NIFI_URL}/processors/{processor_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")
        processor = r.json()
        processor_name = processor["component"]["name"]

        connection_payload = {
            "revision": {"version": 0},
            "component": {
                "name": f"Connection_to_{input_port_name}",
                "source": {
                    "id": processor_id,
                    "type": "PROCESSOR",
                    "groupId": parent_pg_id
                },
                "destination": {
                    "id": input_port['id'],
                    "type": "INPUT_PORT",
                    "groupId": child_pg_id
                },
                "selectedRelationships": relationships,
                "flowFileExpiration": "0 sec",
                "backPressureDataSizeThreshold": "1 GB",
                "backPressureObjectThreshold": 10000
            }
        }
        logger.debug(f"Connection payload: {json.dumps(connection_payload, indent=2)}")

        url = f"{NIFI_URL}/process-groups/{parent_pg_id}/connections"
        print(f"Making POST request to {url}")
        r = requests.post(url, json=connection_payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        print(f"✅ Connected processor '{processor_name}' to input port '{input_port_name}' of child PG")

        print(f"✅ EXITING connect_processor_to_child_pg - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error connecting processor to child PG: {str(e)}")
        print(f"❌ EXITING connect_processor_to_child_pg - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response connecting processor to child PG: {str(e)}")
        print(f"❌ EXITING connect_processor_to_child_pg - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error connecting processor to child PG: {str(e)}")
        print(f"❌ EXITING connect_processor_to_child_pg - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_ports_in_process_group(
    process_group_id: str,
    NIFI_URL: str,
    headers: Dict[str, str] = None,
    verify_ssl: bool = False
) -> List[Dict[str, Any]]:
    """
    Get all Input Ports and Output Ports inside a NiFi Process Group.
    """
    print(f"🔍 ENTERING get_ports_in_process_group - PG ID: {process_group_id}")
    try:
        url = f"{NIFI_URL}/process-groups/{process_group_id}/connections"
        logger.debug(f"Making GET request to {url}")
        response = requests.get(url, headers=headers, verify=verify_ssl)
        response.raise_for_status()
        print(f"✅ GET request successful - Status code: {response.status_code}")

        data = response.json()['connections']
        print(f"Found {len(data)} connections in PG {process_group_id}")

        ports = []
        input_ports_found = 0
        output_ports_found = 0

        for i, conn in enumerate(data, 1):
            logger.debug(f"Processing connection {i}/{len(data)}")
            if conn['sourceType'] == "INPUT_PORT":
                ports.append({
                    "port_id": conn["sourceId"],
                    "port_type": "INPUT_PORT",
                    "version": conn["revision"]["version"]
                })
                input_ports_found += 1
                logger.debug(f"Found INPUT_PORT: {conn['sourceId']}")
            if conn['destinationType'] == "INPUT_PORT":
                ports.append({
                    "port_id": conn["destinationId"],
                    "port_type": "INPUT_PORT",
                    "version": conn["revision"]["version"]
                })
                input_ports_found += 1
                logger.debug(f"Found INPUT_PORT: {conn['destinationId']}")

        for i, conn in enumerate(data, 1):
            if conn['sourceType'] == "OUTPUT_PORT":
                ports.append({
                    "port_id": conn["sourceId"],
                    "port_type": "OUTPUT_PORT",
                    "version": conn["revision"]["version"]
                })
                output_ports_found += 1
                logger.debug(f"Found OUTPUT_PORT: {conn['sourceId']}")
            if conn['destinationType'] == "OUTPUT_PORT":
                ports.append({
                    "port_id": conn["destinationId"],
                    "port_type": "OUTPUT_PORT",
                    "version": conn["revision"]["version"]
                })
                output_ports_found += 1
                logger.debug(f"Found OUTPUT_PORT: {conn['destinationId']}")

        print(f"Found {input_ports_found} input ports and {output_ports_found} output ports in PG {process_group_id}")

        print(f"✅ EXITING get_ports_in_process_group - Success")
        return ports
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error getting ports in process group: {str(e)}")
        print(f"❌ EXITING get_ports_in_process_group - Failed with network error")
        return []
    except KeyError as e:
        logger.error(f"❌ Invalid response getting ports: {str(e)}")
        print(f"❌ EXITING get_ports_in_process_group - Failed with key error")
        return []
    except Exception as e:
        logger.error(f"❌ Unexpected error getting ports in process group: {str(e)}")
        print(f"❌ EXITING get_ports_in_process_group - Failed with unexpected error")
        return []


def stop_port_by_id(port_id: str, port_type: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Stops an InputPort or OutputPort by ID.
    """
    print(f"🔍 ENTERING stop_port_by_id - Port ID: {port_id}, Port type: {port_type}")
    try:
        port_type_api = port_type.replace("_", "-") + "s"
        print(f"Using API endpoint: {port_type_api}")

        print(f"Fetching current state for port {port_id}")
        r = requests.get(f"{NIFI_URL}/{port_type_api}/{port_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        revision = r.json()["revision"]["version"]
        name = r.json()["component"]["name"]
        print(f"Port '{name}' current revision: {revision}")

        payload = {
            "revision": {"version": revision},
            "state": "STOPPED"
        }
        logger.debug(f"Stop payload: {json.dumps(payload, indent=2)}")

        print(f"Making PUT request to {NIFI_URL}/{port_type_api}/{port_id}/run-status")
        sr = requests.put(
            f"{NIFI_URL}/{port_type_api}/{port_id}/run-status",
            json=payload,
            verify=verify_ssl
        )
        sr.raise_for_status()
        print(f"✅ PUT request successful - Status code: {sr.status_code}")

        print(f"✅ Stopped {port_type_api[:-1]}: '{name}' ({port_id})")

        print(f"✅ EXITING stop_port_by_id - Success")
        return {"status": True, "message": f"Port {port_id} stopped successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error stopping port by ID: {str(e)}")
        print(f"❌ EXITING stop_port_by_id - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response stopping port: {str(e)}")
        print(f"❌ EXITING stop_port_by_id - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error stopping port by ID: {str(e)}")
        print(f"❌ EXITING stop_port_by_id - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def start_port_by_id(port_id: str, port_type: str, NIFI_URL: str, retries: int = 5, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Starts an InputPort or OutputPort by ID with retry logic.
    """
    print(f"🔍 ENTERING start_port_by_id - Port ID: {port_id}, Port type: {port_type}, Retries: {retries}")
    port_type = str(port_type).lower().replace("_", "-") + "s"
    print(f"Using API endpoint: {port_type}")

    for attempt in range(1, retries + 1):
        print(f"Attempt {attempt}/{retries} to start port {port_id}")
        try:
            print(f"Fetching current state for port {port_id}")
            r = requests.get(f"{NIFI_URL}/{port_type}/{port_id}", verify=verify_ssl)
            r.raise_for_status()
            print(f"✅ GET request successful - Status code: {r.status_code}")

            data = r.json()
            revision = data["revision"]["version"]
            name = data["component"]["name"]
            state = data["component"]["state"]
            print(f"Port '{name}' current state: {state}, revision: {revision}")

            if state == "RUNNING":
                print(f"✅ Port already running: '{name}'")
                print(f"✅ EXITING start_port_by_id - Port already running")
                return {
                    "status": True,
                    "message": f"Port already running: {name}"
                }

            payload = {
                "revision": {"version": revision},
                "state": "RUNNING"
            }
            logger.debug(f"Start payload: {json.dumps(payload, indent=2)}")

            print(f"Making PUT request to {NIFI_URL}/{port_type}/{port_id}/run-status")
            sr = requests.put(
                f"{NIFI_URL}/{port_type}/{port_id}/run-status",
                json=payload,
                verify=verify_ssl
            )

            if sr.status_code == 409:
                logger.warning(f"⚠️ Conflict on attempt {attempt}, retrying...")
                if attempt < retries:
                    print(f"Waiting 1 second before retry")
                    time.sleep(1)
                    continue
                else:
                    logger.error(f"❌ Max retries exceeded with conflict errors")
                    print(f"❌ EXITING start_port_by_id - Max retries exceeded")
                    return {"status": False, "error": "Max retries exceeded with conflict errors"}

            sr.raise_for_status()
            print(f"✅ PUT request successful - Status code: {sr.status_code}")

            print(f"✅ Started {port_type[:-1]}: '{name}' ({port_id})")
            print(f"✅ EXITING start_port_by_id - Success")
            return {
                "status": True,
                "message": f"Port {name} started successfully"
            }

        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Network error on attempt {attempt}: {str(e)}")
            if attempt == retries:
                print(f"❌ EXITING start_port_by_id - Failed with network error after {retries} attempts")
                return {"status": False, "error": f"Network error: {str(e)}"}
            print(f"Waiting 1 second before retry")
            time.sleep(1)
        except KeyError as e:
            logger.error(f"❌ Invalid response on attempt {attempt}: {str(e)}")
            if attempt == retries:
                print(f"❌ EXITING start_port_by_id - Failed with key error after {retries} attempts")
                return {"status": False, "error": f"Invalid response: {str(e)}"}
            print(f"Waiting 1 second before retry")
            time.sleep(1)
        except Exception as e:
            logger.error(f"❌ Unexpected error on attempt {attempt}: {str(e)}")
            if attempt == retries:
                print(f"❌ EXITING start_port_by_id - Failed with unexpected error after {retries} attempts")
                return {"status": False, "error": f"Unexpected error: {str(e)}"}
            print(f"Waiting 1 second before retry")
            time.sleep(1)

    print(f"❌ EXITING start_port_by_id - Max retries exceeded")
    return {"status": False, "error": "Max retries exceeded"}


def stop_processor(processor_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Stops a processor by ID.
    """
    print(f"🔍 ENTERING stop_processor - Processor ID: {processor_id}")
    try:
        print(f"Fetching processor details for {processor_id}")
        proc_data = get_processor_by_id(processor_id, NIFI_URL, verify_ssl=verify_ssl)
        if not proc_data["status"]:
            logger.error(f"❌ Failed to fetch processor details: {proc_data.get('error')}")
            print(f"❌ EXITING stop_processor - Failed to get processor")
            return proc_data

        processor = proc_data["data"]
        processor_name = processor["component"]["name"]
        revision = processor["revision"]["version"]
        print(f"Processor '{processor_name}' current revision: {revision}")

        url = f"{NIFI_URL}/processors/{processor_id}/run-status"
        payload = {
            "revision": processor["revision"],
            "state": "STOPPED"
        }
        logger.debug(f"Stop payload: {json.dumps(payload, indent=2)}")

        print(f"Making PUT request to {url}")
        r = requests.put(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ PUT request successful - Status code: {r.status_code}")

        print(f"✅ Stopped processor: '{processor_name}'")

        print(f"✅ EXITING stop_processor - Success")
        return {"status": True, "message": f"Processor {processor_id} stopped"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error stopping processor: {str(e)}")
        print(f"❌ EXITING stop_processor - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response stopping processor: {str(e)}")
        print(f"❌ EXITING stop_processor - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error stopping processor: {str(e)}")
        print(f"❌ EXITING stop_processor - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def stop_process_group(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Stops all processors in a process group.
    """
    print(f"🔍 ENTERING stop_process_group - PG ID: {pg_id}")
    try:
        print(f"Stopping process group: {pg_id}")

        processors_data = get_processors_in_pg(pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not processors_data["status"]:
            logger.error(f"❌ Failed to get processors: {processors_data.get('error')}")
            print(f"❌ EXITING stop_process_group - Failed to get processors")
            return processors_data

        processors = processors_data["data"]
        print(f"Found {len(processors)} processors in process group")

        if not processors:
            print("No processors in process group")
            print(f"✅ EXITING stop_process_group - No processors to stop")
            return {"status": True, "message": "No processors to stop"}

        stopped_count = 0
        for p in processors:
            if p["component"]["state"] != "STOPPED":
                print(f"Stopping processor: {p['component']['name']} (ID: {p['id']})")
                stop_result = stop_processor(p["id"], NIFI_URL, verify_ssl=verify_ssl)
                if stop_result["status"]:
                    stopped_count += 1
                    print(f"✅ Processor {p['id']} stopped successfully")
                else:
                    logger.error(f"❌ Failed to stop processor {p['id']}: {stop_result.get('error')}")

        print(f"✅ {stopped_count} processors stopped in PG {pg_id}")

        print(f"✅ EXITING stop_process_group - Success")
        return {"status": True, "message": f"All processors in PG {pg_id} stopped"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error stopping process group: {str(e)}")
        print(f"❌ EXITING stop_process_group - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error stopping process group: {str(e)}")
        print(f"❌ EXITING stop_process_group - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def remove_route_on_attribute_rule(
    route_proc_id: str,
    rule_name: str,
    NIFI_URL: str,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Removes a rule (dynamic property) from a RouteOnAttribute processor.
    """
    print(f"🔍 ENTERING remove_route_on_attribute_rule - Processor ID: {route_proc_id}, Rule name: '{rule_name}'")
    try:
        print(f"Fetching current state for processor {route_proc_id}")
        proc = requests.get(f"{NIFI_URL}/processors/{route_proc_id}", verify=verify_ssl).json()
        rev = proc["revision"]["version"]
        proc_name = proc["component"]["name"]
        print(f"Processor '{proc_name}' revision: {rev}")

        properties = proc["component"]["config"]["properties"] or {}
        print(f"Current properties: {list(properties.keys())}")

        if rule_name in properties:
            print(f"Removing rule '{rule_name}'")
            properties[rule_name] = None

        payload = {
            "revision": {"version": rev},
            "component": {
                "id": route_proc_id,
                "config": {
                    "properties": properties
                }
            }
        }
        logger.debug(f"Remove rule payload: {json.dumps(payload, indent=2)}")

        print(f"Making PUT request to {NIFI_URL}/processors/{route_proc_id}")
        r = requests.put(f"{NIFI_URL}/processors/{route_proc_id}", json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ PUT request successful - Status code: {r.status_code}")

        print("Waiting 5 seconds for changes to propagate")
        time.sleep(5)

        print(f"✅ Deleted RouteOnAttribute rule: '{rule_name}'")

        print(f"✅ EXITING remove_route_on_attribute_rule - Success")
        return {"status": True, "message": f"Rule '{rule_name}' removed successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error removing RouteOnAttribute rule: {str(e)}")
        print(f"❌ EXITING remove_route_on_attribute_rule - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response removing route rule: {str(e)}")
        print(f"❌ EXITING remove_route_on_attribute_rule - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error removing RouteOnAttribute rule: {str(e)}")
        print(f"❌ EXITING remove_route_on_attribute_rule - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def delete_all_connections_to_pg(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Deletes all connections where source OR destination belongs to a process group.
    """
    print(f"🔍 ENTERING delete_all_connections_to_pg - PG ID: {pg_id}")
    try:
        print(f"Fetching all connections for PG {pg_id}")
        r = requests.get(f"{NIFI_URL}/process-groups/{pg_id}/connections", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        all_connections = []
        data = r.json()

        if isinstance(data, dict) and "connections" in data:
            all_connections = data["connections"]
            print(f"Found {len(all_connections)} connections in response (dict format)")
        elif isinstance(data, list):
            all_connections = data
            print(f"Found {len(all_connections)} connections in response (list format)")

        deleted_count = 0
        for c in all_connections:
            if isinstance(c, dict):
                src = c.get("component", {}).get("source", {})
                dest = c.get("component", {}).get("destination", {})

                if src.get("groupId") == pg_id or dest.get("groupId") == pg_id:
                    cid = c.get("id")
                    ver = c.get("revision", {}).get("version", 0)
                    conn_name = c.get("component", {}).get("name", "UNKNOWN")

                    if cid:
                        print(f"Deleting connection '{conn_name}' (ID: {cid})")
                        del_resp = requests.delete(
                            f"{NIFI_URL}/connections/{cid}",
                            params={"version": ver},
                            verify=verify_ssl
                        )
                        del_resp.raise_for_status()
                        deleted_count += 1
                        print(f"✅ Deleted connection {cid}")

        print(f"✅ {deleted_count} connections to/from PG {pg_id} deleted")

        print(f"✅ EXITING delete_all_connections_to_pg - Success")
        return {"status": True, "message": f"All connections to/from PG {pg_id} deleted"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error deleting all connections to PG: {str(e)}")
        print(f"❌ EXITING delete_all_connections_to_pg - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response deleting connections: {str(e)}")
        print(f"❌ EXITING delete_all_connections_to_pg - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error deleting all connections to PG: {str(e)}")
        print(f"❌ EXITING delete_all_connections_to_pg - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def delete_processor_to_child_pg_connection(
    parent_pg_id: str,
    processor_id: str,
    child_pg_id: str,
    NIFI_URL: str,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Deletes the connection from a processor in a parent PG to a child PG input port.
    """
    print(f"🔍 ENTERING delete_processor_to_child_pg_connection - Parent PG: {parent_pg_id}, Processor ID: {processor_id}, Child PG: {child_pg_id}")
    try:
        print(f"Fetching all connections in parent PG {parent_pg_id}")
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{parent_pg_id}", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        connections = r.json()["processGroupFlow"]["flow"].get("connections", [])
        print(f"Found {len(connections)} connections in parent PG")

        target = None
        for idx, c in enumerate(connections, 1):
            src = c["component"]["source"]
            dst = c["component"]["destination"]
            logger.debug(f"Checking connection {idx}: source={src.get('type')} {src.get('id')}, dest={dst.get('type')} {dst.get('id')}")

            if (
                src["type"] == "PROCESSOR"
                and src["id"] == processor_id
                and src["groupId"] == parent_pg_id
                and dst["type"] == "INPUT_PORT"
                and dst["groupId"] == child_pg_id
            ):
                target = c
                print(f"Found matching connection: {c.get('id')}")
                break

        if not target:
            logger.warning("⚠️ Connection not found — nothing to delete")
            print(f"✅ EXITING delete_processor_to_child_pg_connection - Connection not found")
            return {"status": True, "message": "Connection not found"}

        conn_id = target["id"]
        version = target["revision"]["version"]
        print(f"Deleting connection {conn_id} with revision {version}")

        r = requests.delete(
            f"{NIFI_URL}/connections/{conn_id}",
            params={"version": version},
            verify=verify_ssl
        )
        r.raise_for_status()
        print(f"✅ Deleted connection {conn_id}")

        print(f"✅ EXITING delete_processor_to_child_pg_connection - Success")
        return {"status": True, "message": f"Connection {conn_id} deleted"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error deleting processor to child PG connection: {str(e)}")
        print(f"❌ EXITING delete_processor_to_child_pg_connection - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response deleting connection: {str(e)}")
        print(f"❌ EXITING delete_processor_to_child_pg_connection - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error deleting processor to child PG connection: {str(e)}")
        print(f"❌ EXITING delete_processor_to_child_pg_connection - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def safe_delete_process_group(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Safely deletes a process group by stopping all components and emptying queues first.
    """
    print(f"🔍 ENTERING safe_delete_process_group - PG ID: {pg_id}")
    try:
        logger.warning(f"⚠️ Starting safe deletion of Process Group {pg_id}")

        print("Step 1: Stopping all processors")
        stop_result = stop_all_processors(pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not stop_result["status"]:
            logger.error("⚠️ Warning: Failed to stop some processors")

        print("Step 2: Stopping all ports")
        stop_ports_result = stop_all_ports(pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not stop_ports_result["status"]:
            logger.error("⚠️ Warning: Failed to stop some ports")

        print("Step 3: Emptying all queues")
        empty_queues_result = empty_all_queues(pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not empty_queues_result["status"]:
            logger.error("⚠️ Warning: Failed to empty some queues")

        print("Step 4: Disabling all controller services")
        disable_services_result = disable_all_controller_services(pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not disable_services_result["status"]:
            logger.error("⚠️ Warning: Failed to disable some controller services")

        print("Waiting 2 seconds for NiFi to settle")
        time.sleep(2)

        print(f"Step 5: Deleting process group {pg_id}")
        delete_result = delete_process_group(pg_id, NIFI_URL, verify_ssl=verify_ssl)

        if delete_result["status"]:
            print(f"✅ Process Group {pg_id} deleted safely")
            print(f"✅ EXITING safe_delete_process_group - Success")
            return {"status": True, "message": "Process Group deleted safely"}
        else:
            logger.error(f"❌ Failed to delete process group: {delete_result.get('error')}")
            print(f"❌ EXITING safe_delete_process_group - Delete failed")
            return delete_result

    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error in safe delete process group: {str(e)}")
        print(f"❌ EXITING safe_delete_process_group - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error in safe delete process group: {str(e)}")
        print(f"❌ EXITING safe_delete_process_group - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def start_process_group(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Starts all processors in a process group.
    """
    print(f"🔍 ENTERING start_process_group - PG ID: {pg_id}")
    try:
        print(f"Fetching processors in PG {pg_id}")
        processors_data = get_processors_in_pg(pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not processors_data["status"]:
            logger.error(f"❌ Failed to get processors: {processors_data.get('error')}")
            print(f"❌ EXITING start_process_group - Failed to get processors")
            return processors_data

        processors = processors_data["data"]
        print(f"Found {len(processors)} processors in process group")

        if not processors:
            print("No processors in process group")
            print(f"✅ EXITING start_process_group - No processors to start")
            return {"status": True, "message": "No processors to start"}

        started_count = 0
        for p in processors:
            if p["component"]["state"] != "RUNNING":
                print(f"Starting processor: {p['component']['name']} (ID: {p['id']})")
                start_result = start_processor(p['id'], NIFI_URL, verify_ssl=verify_ssl)
                if start_result["status"]:
                    started_count += 1
                    print(f"✅ Processor {p['id']} started successfully")
                else:
                    logger.error(f"❌ Failed to start processor {p['id']}: {start_result.get('error')}")

        print(f"✅ {started_count} processors started in PG {pg_id}")

        print(f"✅ EXITING start_process_group - Success")
        return {"status": True, "message": f"All processors in PG {pg_id} started"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error starting process group: {str(e)}")
        print(f"❌ EXITING start_process_group - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error starting process group: {str(e)}")
        print(f"❌ EXITING start_process_group - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_execute_sql_processor(
    pg_id: str,
    name: str,
    position_x: float,
    position_y: float,
    dbcp_id: str,
    sql_query: str,
    NIFI_URL: str,
    run_every_minutes: int = 10,
    concurrent_tasks: int = 1,
    start: bool = True,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates an ExecuteSQL processor using a DBCPConnectionPool service.
    """
    print(f"🔍 ENTERING create_execute_sql_processor - PG ID: {pg_id}, Name: '{name}', Position: ({position_x}, {position_y})")
    try:
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.ExecuteSQL",
                "name": name,
                "position": {"x": position_x, "y": position_y},
                "config": {
                    "schedulingStrategy": "TIMER_DRIVEN",
                    "schedulingPeriod": f"{run_every_minutes} min",
                    "concurrentlySchedulableTaskCount": concurrent_tasks,
                    "properties": {
                        "Database Connection Pooling Service": dbcp_id,
                        "SQL Query": sql_query,
                        "Max Rows Per Flow File": "0",
                        "Output Format": "JSON"
                    },
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }
        logger.debug(f"Creating ExecuteSQL processor with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {NIFI_URL}/process-groups/{pg_id}/processors")
        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=payload,
            verify=verify_ssl
        )
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        processor_id = r.json()["id"]
        print(f"✅ ExecuteSQL processor created: {processor_id}")

        if start:
            print(f"Starting ExecuteSQL processor {processor_id}")
            start_result = start_processor(processor_id, NIFI_URL, verify_ssl=verify_ssl)
            if not start_result["status"]:
                logger.error(f"⚠️ Warning: Failed to start processor {processor_id}")

        print(f"✅ EXITING create_execute_sql_processor - Success")
        return {"status": True, "processor_id": processor_id}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating ExecuteSQL processor: {str(e)}")
        print(f"❌ EXITING create_execute_sql_processor - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid configuration creating ExecuteSQL: {str(e)}")
        print(f"❌ EXITING create_execute_sql_processor - Failed with key error")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating ExecuteSQL processor: {str(e)}")
        print(f"❌ EXITING create_execute_sql_processor - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def setup_avro_to_json_services(pg_id: str, NIFI_URL: str, verify_ssl: bool = False) -> Dict[str, Any]:
    """
    Sets up AvroReader and JsonWriter controller services for data conversion.
    """
    print(f"🔍 ENTERING setup_avro_to_json_services - PG ID: {pg_id}")
    try:
        print("Creating AvroReader controller service")
        avro_reader_result = create_controller_service_by_type(
            pg_id=pg_id,
            cs_type="org.apache.nifi.avro.AvroReader",
            name="AvroReader",
            NIFI_URL=NIFI_URL,
            properties={},
            verify_ssl=verify_ssl
        )

        if not avro_reader_result["status"]:
            logger.error(f"❌ Failed to create AvroReader: {avro_reader_result.get('error')}")
            print(f"❌ EXITING setup_avro_to_json_services - Failed to create AvroReader")
            return avro_reader_result

        avro_reader_id = avro_reader_result["cs_id"]
        print(f"✅ AvroReader created with ID: {avro_reader_id}")

        print(f"Enabling AvroReader {avro_reader_id}")
        enable_avro_result = enable_controller_service(avro_reader_id, NIFI_URL, verify_ssl=verify_ssl)
        if not enable_avro_result["status"]:
            logger.error(f"⚠️ Warning: Failed to enable AvroReader {avro_reader_id}")

        print("Creating JsonRecordSetWriter controller service")
        json_writer_result = create_controller_service_by_type(
            pg_id=pg_id,
            cs_type="org.apache.nifi.json.JsonRecordSetWriter",
            name="JsonWriter",
            NIFI_URL=NIFI_URL,
            properties={},
            verify_ssl=verify_ssl
        )

        if not json_writer_result["status"]:
            logger.error(f"❌ Failed to create JsonWriter: {json_writer_result.get('error')}")
            print(f"❌ EXITING setup_avro_to_json_services - Failed to create JsonWriter")
            return json_writer_result

        json_writer_id = json_writer_result["cs_id"]
        print(f"✅ JsonWriter created with ID: {json_writer_id}")

        print(f"Enabling JsonWriter {json_writer_id}")
        enable_json_result = enable_controller_service(json_writer_id, NIFI_URL, verify_ssl=verify_ssl)
        if not enable_json_result["status"]:
            logger.error(f"⚠️ Warning: Failed to enable JsonWriter {json_writer_id}")

        result = {
            "status": True,
            "avro_reader_id": avro_reader_id,
            "json_writer_id": json_writer_id
        }
        print(f"✅ Avro to JSON services setup completed")
        print(f"✅ EXITING setup_avro_to_json_services - Success")
        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error setting up Avro to JSON services: {str(e)}")
        print(f"❌ EXITING setup_avro_to_json_services - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error setting up Avro to JSON services: {str(e)}")
        print(f"❌ EXITING setup_avro_to_json_services - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_update_attribute_processor(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    position_id: int = 0,
    additional_attributes: Optional[Dict[str, str]] = None,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates an UpdateAttribute processor to add/modify flowfile attributes.
    """
    print(f"🔍 ENTERING create_update_attribute_processor - PG ID: {pg_id}, Name: '{name}', Position ID: {position_id}")
    try:
        position = (400 * position_id, 100.0)
        print(f"Creating processor at position: {position}")
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        properties = {}

        if additional_attributes:
            print(f"Adding {len(additional_attributes)} additional attributes")
            properties.update(additional_attributes)
            logger.debug(f"Additional attributes: {json.dumps(additional_attributes, indent=2)}")

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.attributes.UpdateAttribute",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "config": {
                    "properties": properties,
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }
        logger.debug(f"Creating UpdateAttribute with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        proc_id = r.json()["id"]
        print(f"✅ Created UpdateAttribute processor '{name}' with ID: {proc_id}")

        print(f"✅ EXITING create_update_attribute_processor - Success")
        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json()
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating UpdateAttribute processor: {str(e)}")
        print(f"❌ EXITING create_update_attribute_processor - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating UpdateAttribute processor: {str(e)}")
        print(f"❌ EXITING create_update_attribute_processor - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def delete_connection_by_id(
    connection_id: str,
    NIFI_URL: str,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Deletes a NiFi connection by its ID.
    """
    print(f"🔍 ENTERING delete_connection_by_id - Connection ID: {connection_id}")
    try:
        print(f"Fetching connection details for {connection_id}")
        get_url = f"{NIFI_URL}/connections/{connection_id}"
        get_resp = requests.get(get_url, verify=verify_ssl)
        get_resp.raise_for_status()
        print(f"✅ GET request successful - Status code: {get_resp.status_code}")

        revision = get_resp.json()["revision"]
        version = revision["version"]
        client_id = revision.get("clientId", "python-client")
        print(f"Connection revision: {version}, client ID: {client_id}")

        delete_url = f"{NIFI_URL}/connections/{connection_id}"
        params = {
            "version": version,
            "clientId": client_id
        }
        print(f"Deleting connection with params: {params}")

        delete_resp = requests.delete(
            delete_url,
            params=params,
            verify=verify_ssl
        )
        delete_resp.raise_for_status()
        print(f"✅ DELETE request successful - Status code: {delete_resp.status_code}")

        print(f"✅ Connection {connection_id} deleted successfully")

        print(f"✅ EXITING delete_connection_by_id - Success")
        return {
            "status": "deleted",
            "connection_id": connection_id
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error deleting connection by ID: {str(e)}")
        print(f"❌ EXITING delete_connection_by_id - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response deleting connection: {str(e)}")
        print(f"❌ EXITING delete_connection_by_id - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error deleting connection by ID: {str(e)}")
        print(f"❌ EXITING delete_connection_by_id - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_update_record_processor(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    record_reader: str,
    record_writer: str,
    position_id: int = 0,
    record_properties: Optional[Dict[str, str]] = None,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates an UpdateRecord processor to update record fields using RecordPath.
    """
    print(f"🔍 ENTERING create_update_record_processor - PG ID: {pg_id}, Name: '{name}', Position ID: {position_id}")
    try:
        position = (400 * position_id, 200.0)
        print(f"Creating processor at position: {position}")
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        properties = {
            "Record Reader": record_reader,
            "Record Writer": record_writer
        }

        if record_properties:
            print(f"Adding {len(record_properties)} record update rules")
            properties.update(record_properties)
            logger.debug(f"Record properties: {json.dumps(record_properties, indent=2)}")

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.UpdateRecord",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "config": {
                    "properties": properties,
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }
        logger.debug(f"Creating UpdateRecord with payload: {json.dumps(payload, indent=2)}")

        print(f"Making POST request to {url}")
        r = requests.post(url, json=payload, verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        proc_id = r.json()["id"]
        print(f"✅ Created UpdateRecord processor '{name}' with ID: {proc_id}")

        print(f"✅ EXITING create_update_record_processor - Success")
        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json()
        }

    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating UpdateRecord processor: {str(e)}")
        print(f"❌ EXITING create_update_record_processor - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid configuration creating UpdateRecord: {str(e)}")
        print(f"❌ EXITING create_update_record_processor - Failed with key error")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating UpdateRecord processor: {str(e)}")
        print(f"❌ EXITING create_update_record_processor - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}
