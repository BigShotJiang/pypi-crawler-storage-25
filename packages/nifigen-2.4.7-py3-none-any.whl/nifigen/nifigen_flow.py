
"""
NiFi Automation Library
=======================
This module provides a comprehensive set of functions for automating Apache NiFi
operations through the REST API. It includes functions for managing process groups,
processors, controller services, connections, and flow deployment.

Version: 1.0.0
Author: [Your Name/Organization]
"""

import requests

from nifigen.nifigen_comp import (
    add_handle_http_response,
    connect_components,
    create_execute_sql_processor,
    create_execute_stream_command,
    create_input_port,
    create_output_port,
    create_process_group_inside_pg,
    create_put_websocket,
    create_update_attribute_processor,
    create_update_record_processor,
    delete_all_connections_to_pg,
    delete_connection_by_id,
    delete_process_group,
    delete_processor_to_child_pg_connection,
    enable_controller_service,
    get_ports_in_process_group,
    get_processor_by_id,
    remove_route_on_attribute_rule,
    setup_avro_to_json_services,
    start_port_by_id,
    start_processor,
    stop_port_by_id,
    stop_process_group,
    stop_processor,
    create_process_orch_group,
    create_controller_service,
    import_controller_services,
    create_processor_in_pg,
    get_processor_by_type,
    bind_websocket_controller_service,
    create_connection,
    get_controller_service_by_name
)

import time
import json
import uuid
import os
import logging
from typing import Dict, List, Optional, Any, Union, Tuple

# ---------------------------------------------------------------------------
# Logger setup - writes to file only, never touches stdout.
# Callers can override by reconfiguring the "nifigen" logger before use.
# ---------------------------------------------------------------------------
logger = logging.getLogger("nifigen")
if not logger.handlers:
    logger.setLevel(logging.DEBUG)
    _fh = logging.FileHandler("nifigen.log", encoding="utf-8")
    _fh.setLevel(logging.DEBUG)
    _fh.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(funcName)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(_fh)
    logger.propagate = False          # don't bubble up to root logger




def recreate_process_group_flow(
    parent_pg_id: str,
    name: str,
    pg_json: Dict[str, Any],
    NIFI_URL: str,
    service_path:str,
    position: Tuple[int, int] = (0, 0),
    id_map: Optional[Dict[str, str]] = None,
    orch_dir: Optional[str] = None,
    ws_port:int = 7777,
    http_port=7778,
    verify_ssl: bool = False,
    working_dir: str = "",
    command_arguments: str = "",
    command_path: str = ""
) -> Dict[str, Any]:
    """
    Recreates a process group from exported JSON data.
    """
    print(f"🔍 ENTERING recreate_process_group_flow - Parent PG: {parent_pg_id}, Name: '{name}', Position: {position}, WS Port: {ws_port}, HTTP Port: {http_port}")
    try:
        if id_map is None:
            id_map = {}
            logger.debug("Created new ID map")

        print(f"Step 1: Creating process group '{name}_orch'")
        new_pg_result = create_process_orch_group(parent_pg_id, name, NIFI_URL, position, verify_ssl=verify_ssl)
        if not new_pg_result["status"]:
            logger.error(f"❌ Failed to create process group: {new_pg_result.get('error')}")
            print(f"❌ EXITING recreate_process_group_flow - PG creation failed")
            return new_pg_result

        new_pg_id = new_pg_result["data"]["id"]
        print(f"✅ Created new PG: '{name}', ID: {new_pg_id}")

        cs_def = {
            "name": "http_cs",
            "type": "org.apache.nifi.http.StandardHttpContextMap",
            "bundle": {
                'group': 'org.apache.nifi',
                'artifact': 'nifi-http-context-map-nar',
                'version': '2.7.2'
            },
            "properties": {"Request Expiration": "5 min"}
        }

        sc_cs={
                "type": "org.apache.nifi.websocket.jetty.JettyWebSocketServer",
                "bundle": {
                "group": "org.apache.nifi",
                "artifact": "nifi-websocket-services-jetty-nar",
                "version": "2.7.2"
                },
                "name": "JettyWebSocketServer",
                "properties": {
                "Input Buffer Size": "4 kb",
                "Max Text Message Size": "64 kb",
                "Max Binary Message Size": "64 kb",
                "Idle Timeout": "0 sec",
                "Port": ws_port,
                "SSL Context Service": None,
                "Client Authentication": "no",
                "Basic Authentication Enabled": "false",
                "Basic Authentication Path Spec": "/*",
                "Basic Authentication Roles": "**",
                "Login Service": "hash",
                "Users Properties File": None
                }
        }

        jt = {
            "type": "org.apache.nifi.json.JsonTreeReader",
            "bundle": {
                "group": "org.apache.nifi",
                "artifact": "nifi-record-serialization-services-nar",
                "version": "2.7.2"
            },
            "name": "JsonTreeReader_out",
            "properties": {
                "Schema Access Strategy": "infer-schema",
                "Schema Registry": None,
                "Schema Name": "${schema.name}",
                "Schema Version": None,
                "Schema Branch": None,
                "Schema Text": "${avro.schema}",
                "Schema Reference Reader": None,
                "Schema Inference Cache": None,
                "Starting Field Strategy": "ROOT_NODE",
                "Starting Field Name": None,
                "Schema Application Strategy": "SELECTED_PART",
                "Max String Length": "20 MB",
                "Allow Comments": "false",
                "Date Format": None,
                "Time Format": None,
                "Timestamp Format": None
            }
        }

        jwr = {
            "type": "org.apache.nifi.json.JsonRecordSetWriter",
            "bundle": {
                "group": "org.apache.nifi",
                "artifact": "nifi-record-serialization-services-nar",
                "version": "2.7.2"
            },
            "name": "JsonWriter_out",
            "properties": {
                "Schema Write Strategy": "no-schema",
                "Schema Cache": None,
                "Schema Reference Writer": None,
                "Schema Access Strategy": "inherit-record-schema",
                "Schema Registry": None,
                "Schema Name": "${schema.name}",
                "Schema Version": None,
                "Schema Branch": None,
                "Schema Text": "${avro.schema}",
                "Schema Reference Reader": None,
                "Date Format": None,
                "Time Format": None,
                "Timestamp Format": None,
                "Pretty Print JSON": "false",
                "Suppress Null Values": "never-suppress",
                "Allow Scientific Notation": "false",
                "Output Grouping": "output-array",
                "Compression Format": "none",
                "Compression Level": "1"
            }
        }

        id_map[pg_json["id"]] = new_pg_id
        print(f"Mapped old PG ID {pg_json['id']} to new PG ID {new_pg_id}")

        print("Step 2: Creating HTTP controller service")
        http_cs_result = create_controller_service(pg_id=new_pg_id, cs_def=cs_def, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        if http_cs_result["status"]:
            print(f"✅ HTTP controller service created: {http_cs_result['data']['id']}")
        else:
            logger.error(f"❌ Failed to create HTTP controller service: {http_cs_result.get('error')}")

        print("Step 3: Creating WebSocket controller service")
        ws_cs_result = create_controller_service(pg_id=new_pg_id, cs_def=sc_cs, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        if ws_cs_result["status"]:
            print(f"✅ WebSocket controller service created: {ws_cs_result['data']['id']}")
        else:
            logger.error(f"❌ Failed to create WebSocket controller service: {ws_cs_result.get('error')}")

        print("Step 4: Creating JsonTreeReader controller service")
        json_tree_reader_out = create_controller_service(pg_id=new_pg_id, cs_def=jt, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        if json_tree_reader_out["status"]:
            print(f"✅ JsonTreeReader created: {json_tree_reader_out['data']['id']}")
        else:
            logger.error(f"❌ Failed to create JsonTreeReader: {json_tree_reader_out.get('error')}")

        print("Step 5: Creating JsonWriter controller service")
        json_wr_out = create_controller_service(pg_id=new_pg_id, cs_def=jwr, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        if json_wr_out["status"]:
            print(f"✅ JsonWriter created: {json_wr_out['data']['id']}")
        else:
            logger.error(f"❌ Failed to create JsonWriter: {json_wr_out.get('error')}")

        print("Step 6: Enabling all controller services")
        if http_cs_result["status"]:
            http_cs = http_cs_result["data"]
            enable_cs_result = enable_controller_service(cs_id=http_cs["id"], NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
            if enable_cs_result["status"]:
                print(f"✅ HTTP controller service enabled")
            else:
                logger.error(f"⚠️ Failed to enable HTTP controller service")

        if ws_cs_result["status"]:
            ws_cs = ws_cs_result['data']
            enable_ws_cs_result = enable_controller_service(cs_id=ws_cs["id"], NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
            if enable_ws_cs_result["status"]:
                print(f"✅ WebSocket controller service enabled")
            else:
                logger.error(f"⚠️ Failed to enable WebSocket controller service")

        if json_tree_reader_out["status"]:
            json_tree_reader_out_data = json_tree_reader_out['data']
            enable_json_tree_reader_out_result = enable_controller_service(cs_id=json_tree_reader_out_data["id"], NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
            if enable_json_tree_reader_out_result["status"]:
                print(f"✅ JsonTreeReader enabled")
            else:
                logger.error(f"⚠️ Failed to enable JsonTreeReader")

        if json_wr_out["status"]:
            json_wr_out_data = json_wr_out['data']
            enable_json_wr_out_result = enable_controller_service(cs_id=json_wr_out_data["id"], NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
            if enable_json_wr_out_result["status"]:
                print(f"✅ JsonWriter enabled")
            else:
                logger.error(f"⚠️ Failed to enable JsonWriter")

        print("Step 7: Importing additional controller services from file")
        import_result = import_controller_services(
            pg_id=new_pg_id,
            file_path=service_path,
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        if import_result["status"]:
            print(f"✅ Imported {len(import_result.get('created_services', []))} controller services")
        else:
            logger.error(f"⚠️ Failed to import some controller services: {import_result.get('error')}")

        cs_id = ws_cs["id"] if ws_cs_result["status"] else None

        if orch_dir and not os.path.exists(f"{orch_dir}/{new_pg_id}"):
            os.makedirs(f"{orch_dir}/{new_pg_id}")
            print(f"Created orchestration directory: {orch_dir}/{new_pg_id}")

        print("Step 8: Creating processors")
        processors = pg_json["flow"]["processors"]
        print(f"Found {len(processors)} processors to create")

        for idx, proc in enumerate(processors, 1):
            print(f"Processing processor {idx}/{len(processors)}: '{proc['component']['name']}'")
            time.sleep(2)

            comp = proc["component"]

            if comp['type'] == 'org.apache.nifi.processors.standard.ExecuteStreamCommand':
                comp["config"]["properties"]['Working Directory'] = f"{working_dir}/{new_pg_id}"
                comp["config"]["properties"]['Command Arguments'] = command_arguments
                comp["config"]["properties"]['Command Path'] = command_path
                logger.debug(f"Updated ExecuteStreamCommand: Working Directory={working_dir}, Command Arguments={command_arguments}, Command Path={command_path}")

            if comp['type'] == 'org.apache.nifi.processors.websocket.ListenWebSocket':
                comp['config']['properties']['WebSocket Server Controller Service'] = cs_id
                logger.debug("Updated ListenWebSocket properties with controller service")

            if comp['type'] == 'org.apache.nifi.processors.standard.HandleHttpRequest':
                comp['config']['properties']['HTTP Context Map'] = http_cs["id"]
                comp['config']['properties']['Allowed Paths'] = "/" + name + "_hr"
                comp['config']['properties']['Listening Port'] = http_port
                logger.debug(f"Updated HandleHttpRequest properties: Allowed Paths=/{name}_hr, Port={http_port}")

            # if comp['type'] == 'org.apache.nifi.processors.standard.ExecuteStreamCommand':
            #     comp["config"]["properties"]['Working Directory'] = f"{orch_dir}/{new_pg_id}"
            #     comp["config"]["properties"]['Command Arguments'] = f"main_orch.py"
            #     logger.debug(f"Updated ExecuteStreamCommand: Working Directory={orch_dir}/{new_pg_id}")

            if comp['type'] == 'org.apache.nifi.processors.standard.EvaluateJsonPath':
                comp["config"]["properties"]['question'] = "$.question"
                comp["config"]["descriptors"]['question'] = {
                    "name": "question",
                    "displayName": "question",
                    "description": "",
                    "required": False,
                    "sensitive": False,
                    "dynamic": False,
                    "supportsEl": False,
                    "expressionLanguageScope": "Not Supported",
                    "dependencies": []
                }
                logger.debug("Updated EvaluateJsonPath properties")

            if comp['type'] == 'org.apache.nifi.processors.jolt.JoltTransformJSON':
                comp["config"]["properties"]['Jolt Specification'] = """[\n  {\n    \"operation\": \"shift\",\n    \"spec\": {\"question\": \"question\",\n      \"session_id\": \"session_id\",\n      \"timestamp\": \"timestamp\",\n      \"status\": \"status\",\n      \"sources\": \"sources\",\n      \"selected_agents\": \"selected_agents\",\"plan\": {\n        \"agents\": \"agent_plan\"\n      }\n    }\n  },\n  {\n    \"operation\": \"modify-overwrite-beta\",\n    \"spec\": {\n      \"agent_tmp\": \"=join('--,--', @(1,selected_agents))\"\n    }\n  },\n  {\n    \"operation\": \"modify-overwrite-beta\",\n    \"spec\": {\n      \"agent\": \"=concat('--', @(1,agent_tmp), '--')\"\n    }\n  },\n  {\n    \"operation\": \"remove\",\n    \"spec\": {\n      \"agent_tmp\": \"\"\n    }\n  }\n]"""
                logger.debug("Updated JoltTransformJSON specification")

            new_proc_result = create_processor_in_pg(new_pg_id, comp, NIFI_URL, verify_ssl=verify_ssl)
            if new_proc_result["status"]:
                id_map[comp["id"]] = new_proc_result["data"]["id"]
                print(f"✅ Created processor: '{comp['name']}' with new ID: {new_proc_result['data']['id']}")
            else:
                logger.error(f"❌ Failed to create processor '{comp['name']}': {new_proc_result.get('error')}")

        print("Step 9: Creating sub-groups recursively")
        sub_pgs = pg_json["flow"]["processGroups"]
        print(f"Found {len(sub_pgs)} sub-groups to create")

        for idx, sub_pg in enumerate(sub_pgs, 1):
            print(f"Processing sub-group {idx}/{len(sub_pgs)}: '{sub_pg['component']['name']}'")
            recreate_result = recreate_process_group_flow(
                new_pg_id,
                sub_pg["component"]["name"],
                sub_pg,
                position=(position[0] + 300, position[1] + 300),
                id_map=id_map,
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )

            if not recreate_result["status"]:
                logger.error(f"⚠️ Failed to recreate sub-group {sub_pg['component']['name']}: {recreate_result.get('error')}")

        print("Step 10: Binding WebSocket controller service")
        ws_cs_result = get_processor_by_type(
            pg_id=new_pg_id,
            processor_type="org.apache.nifi.processors.websocket.ListenWebSocket",
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        if ws_cs_result["status"]:
            ws_cs_proc = ws_cs_result["data"]
            bind_result = bind_websocket_controller_service(ws_cs_proc["id"], cs_id, NIFI_URL, verify_ssl=verify_ssl)
            if bind_result["status"]:
                print(f"✅ WebSocket controller service bound successfully")
            else:
                logger.error(f"⚠️ Failed to bind WebSocket controller service: {bind_result.get('error')}")
        else:
            logger.warning("No ListenWebSocket processor found to bind")

        print("Step 11: Creating connections")
        connections = pg_json["flow"]["connections"]
        print(f"Found {len(connections)} connections to create")

        for idx, conn in enumerate(connections, 1):
            src_old = conn["component"]["source"]["id"]
            dst_old = conn["component"]["destination"]["id"]
            print(f"Processing connection {idx}/{len(connections)}: {src_old} -> {dst_old}")

            if src_old not in id_map or dst_old not in id_map:
                logger.warning(f"Skipping connection because IDs not mapped yet: src_mapped={src_old in id_map}, dst_mapped={dst_old in id_map}")
                continue

            conn_copy = conn.copy()
            conn_copy["component"]["source"]["id"] = id_map[src_old]
            conn_copy["component"]["destination"]["id"] = id_map[dst_old]

            create_conn_result = create_connection(new_pg_id, conn_copy, NIFI_URL, verify_ssl=verify_ssl)
            if create_conn_result["status"]:
                print(f"✅ Connection created successfully")
            else:
                logger.error(f"❌ Failed to create connection: {create_conn_result.get('error')}")

        result = {
            "status": True,
            "pg_id": new_pg_id,
            "id_map": id_map,
            'http_cs': http_cs['id'] if http_cs_result["status"] else None,
            'json_tree_r_out': json_tree_reader_out_data['id'] if json_tree_reader_out["status"] else None,
            'json_wr_out': json_wr_out_data['id'] if json_wr_out["status"] else None
        }

        print(f"✅ Process group recreation completed successfully")
        print(f"✅ EXITING recreate_process_group_flow - Success")
        return result

    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error recreating process group: {str(e)}")
        print(f"❌ EXITING recreate_process_group_flow - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid JSON data recreating process group: {str(e)}")
        print(f"❌ EXITING recreate_process_group_flow - Failed with key error")
        return {"status": False, "error": f"Invalid data: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error recreating process group: {str(e)}")
        print(f"❌ EXITING recreate_process_group_flow - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_nifi_connection_ports_flow(
        source_id: str,
        source_group_id: str,
        source_name: str,
        source_type: str,
        destination_id: str,
        destination_group_id: str,
        destination_name: str,
        destination_type: str,
        parent_group_id: str,
        NIFI_URL: str,
        verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a NiFi connection between source and destination components
    and starts Input/Output ports if applicable.
    """
    print(f"🔍 ENTERING create_nifi_connection_ports_flow - Parent PG: {parent_group_id}")
    print(f"Source: {source_type} '{source_name}' (ID: {source_id}, Group: {source_group_id})")
    print(f"Destination: {destination_type} '{destination_name}' (ID: {destination_id}, Group: {destination_group_id})")

    try:
        connection_body = {
            "revision": {"version": 0},
            "component": {
                "parentGroupId": parent_group_id,
                "source": {
                    "id": source_id,
                    "type": source_type,
                    "groupId": source_group_id,
                    "name": source_name
                },
                "destination": {
                    "id": destination_id,
                    "type": destination_type,
                    "groupId": destination_group_id,
                    "name": destination_name
                },
                "backPressureObjectThreshold": 10000,
                "backPressureDataSizeThreshold": "1 GB",
                "flowFileExpiration": "0 sec",
                "loadBalanceStrategy": "DO_NOT_LOAD_BALANCE"
            }
        }

        url = f"{NIFI_URL}/process-groups/{parent_group_id}/connections"
        logger.debug(f"Creating connection with payload: {json.dumps(connection_body, indent=2)}")
        print(f"Making POST request to {url}")

        response = requests.post(url, json=connection_body, verify=verify_ssl)
        response.raise_for_status()
        print(f"✅ POST request successful - Status code: {response.status_code}")

        connection = response.json()
        connection_id = connection["id"]
        print(f"✅ Connection created: {connection_id}")

        if source_type in ("INPUT_PORT", "OUTPUT_PORT"):
            port_type_api = "input-port" if source_type == "INPUT_PORT" else "output-port"
            print(f"Starting source {source_type} port {source_id}")
            start_port_by_id(
                port_id=source_id,
                port_type=port_type_api,
                NIFI_URL=NIFI_URL,
                verify=verify_ssl
            )
            print(f"Starting destination {destination_type} port {destination_id}")
            start_port_by_id(
                port_id=destination_id,
                port_type=port_type_api,
                NIFI_URL=NIFI_URL,
                verify=verify_ssl
            )

        if destination_type in ("INPUT_PORT", "OUTPUT_PORT"):
            port_type_api = "input-port" if destination_type == "INPUT_PORT" else "output-port"
            print(f"Starting destination {destination_type} port {destination_id}")
            start_port_by_id(
                port_id=destination_id,
                port_type=port_type_api,
                NIFI_URL=NIFI_URL,
                verify=verify_ssl
            )

        print(f"✅ EXITING create_nifi_connection_ports_flow - Success")
        return {
            "status": True,
            "connection_id": connection_id,
            "connection": connection
        }

    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating NiFi connection: {str(e)}")
        print(f"❌ EXITING create_nifi_connection_ports_flow - Failed with network error")
        return {
            "status": False,
            "error": f"Network error: {str(e)}"
        }
    except KeyError as e:
        logger.error(f"❌ Invalid configuration creating connection: {str(e)}")
        print(f"❌ EXITING create_nifi_connection_ports_flow - Failed with key error")
        return {
            "status": False,
            "error": f"Invalid config: {str(e)}"
        }
    except Exception as e:
        logger.error(f"❌ Unexpected error creating NiFi connection: {str(e)}")
        print(f"❌ EXITING create_nifi_connection_ports_flow - Failed with unexpected error")
        return {
            "status": False,
            "error": f"Unexpected error: {str(e)}"
        }


def create_and_start_stream_flow_no_agent_flow(
    parent_pg_id: str,
    child_pg_name: str,
    NIFI_URL: str,
    ur_json_r: str,
    ur_json_wr: str,
    additional_attributes_update: Optional[Dict[str, str]] = {"agents_ops": """${agents_ops:isEmpty():ifElse("${RouteOnAttribute.Route}","${agents_ops}--${RouteOnAttribute.Route}")}"""},
    additional_ru_update: Optional[Dict[str, str]] = {"/agents_ops": """${agents_ops}"""},
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a simple process group with input and output ports only (no agent processors).
    """
    print(f"🔍 ENTERING create_and_start_stream_flow_no_agent_flow - Parent PG: {parent_pg_id}, Child name: '{child_pg_name}'")
    try:
        print("Step 1: Creating child Process Group")
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False,
            verify_ssl=verify_ssl
        )

        if not pg_result["status"]:
            logger.error(f"❌ Failed to create process group: {pg_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow_no_agent_flow - PG creation failed")
            return pg_result

        child_pg_id = pg_result["id"]
        print(f"✅ Child process group created: {child_pg_id}")

        print("Step 2: Creating Input Port 'IN'")
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0,
            verify_ssl=verify_ssl
        )

        if not in_port_result["status"]:
            logger.error(f"❌ Failed to create input port: {in_port_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow_no_agent_flow - Input port creation failed")
            return in_port_result

        in_port = in_port_result
        print(f"✅ Input port created: {in_port['id']}")

        print("Step 3: Creating UpdateAttribute processor")
        update_attr_result = create_update_attribute_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateAttributes",
            NIFI_URL=NIFI_URL,
            position_id=1,
            additional_attributes=additional_attributes_update,
            verify_ssl=verify_ssl
        )

        if not update_attr_result["status"]:
            logger.error(f"❌ Failed to create UpdateAttribute: {update_attr_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow_no_agent_flow - UpdateAttribute creation failed")
            return update_attr_result

        update_attr = update_attr_result
        print(f"✅ UpdateAttribute processor created: {update_attr['id']}")

        print("Step 4: Creating UpdateRecord processor")
        records_update_result = create_update_record_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateRecord",
            NIFI_URL=NIFI_URL,
            record_reader=ur_json_r,
            record_writer=ur_json_wr,
            record_properties=additional_ru_update,
            verify_ssl=verify_ssl
        )

        if not records_update_result["status"]:
            logger.error(f"❌ Failed to create UpdateRecord: {records_update_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow_no_agent_flow - UpdateRecord creation failed")
            return records_update_result

        records_update = records_update_result
        print(f"✅ UpdateRecord processor created: {records_update['id']}")
        ## Http Handler
        http_cs_result = get_controller_service_by_name(
            pg_id=parent_pg_id, 
            service_name="http_cs", 
            NIFI_URL=NIFI_URL
            )
        logger.info(f"http_cs_result id: {http_cs_result['data']['id']}")
        http_sc_id =http_cs_result['data']['id']
        http_res_result = add_handle_http_response(
            pg_id=child_pg_id,
            processor_name=child_pg_name,
            NIFI_URL=NIFI_URL,
            http_cs_id=http_sc_id
        )           
        if not http_res_result["status"]:
            return http_res_result
            
        http_res = http_res_result["data"]


        print("Step 5: Creating Output Port 'OUT'")
        # out_port_result = create_output_port(
        #     pg_id=child_pg_id,
        #     name="OUT",
        #     NIFI_URL=NIFI_URL,
        #     position_id=2,
        #     verify_ssl=verify_ssl
        # )

        # if not out_port_result["status"]:
        #     logger.error(f"❌ Failed to create output port: {out_port_result.get('error')}")
        #     print(f"❌ EXITING create_and_start_stream_flow_no_agent_flow - Output port creation failed")
        #     return out_port_result

        # time.sleep(4)
        # out_port = out_port_result
        # print(f"✅ Output port created: {out_port['id']}")

        print("Step 6: Creating connections between components")
        print("Creating connection: Input Port -> UpdateAttribute")
        conn1 = connect_components(
            pg_id=child_pg_id,
            source_id=in_port["id"],
            source_type="INPUT_PORT",
            destination_id=update_attr['id'],
            destination_type="PROCESSOR",
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        print("Creating connection: UpdateAttribute -> UpdateRecord")
        conn2 = connect_components(
            pg_id=child_pg_id,
            source_id=update_attr['id'],
            source_type="PROCESSOR",
            destination_id=records_update['id'],
            destination_type="PROCESSOR",
            relationships=["success"],
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        print("Creating connection: UpdateRecord -> Output Port")
        conn3 = connect_components(
             pg_id=child_pg_id,
             source_id=records_update['id'],
             source_type="PROCESSOR",
             destination_id=http_res['id'],
             destination_type="PROCESSOR",
             relationships=["success"],
             NIFI_URL=NIFI_URL,
             verify_ssl=verify_ssl
         )

        connections = [conn1, conn2, conn3]
        for i, conn_result in enumerate(connections, 1):
            time.sleep(2)
            if conn_result["status"]:
                print(f"✅ Connection {i} created successfully")
            else:
                logger.error(f"⚠️ Failed to create connection {i}: {conn_result.get('error')}")

        print("Step 7: Starting input port")
        try:
            print(f"Starting input port: {in_port['id']}")
            start_input_result = start_port_by_id(
                port_id=in_port["id"],
                port_type="input-port",
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )
            
        except Exception as start_error:
            logger.error(f"⚠️ Error starting input port: {str(start_error)}")
            pass

        # print("Step 8: Starting output port")
        # try:
        #     print(f"Starting output port: {out_port['id']}")
        #     start_output_result = start_port_by_id(
        #         port_id=out_port["id"],
        #         port_type="output-port",
        #         NIFI_URL=NIFI_URL,
        #         verify_ssl=verify_ssl
        #     )
        #     if start_output_result["status"]:
        #         print(f"✅ Output port started successfully")
        #     else:
        #         logger.error(f"⚠️ Failed to start output port: {start_output_result.get('error')}")
        # except Exception as start_error:
        #     logger.error(f"⚠️ Error starting output port: {str(start_error)}")

        result = {
            "status": True,
            "process_group_id": child_pg_id,
            "process_group_name": child_pg_name,
            "input_port": {
                "id": in_port.get("id"),
                "name": in_port.get("name")
            },
            "http_out":{
                "id": http_res.get(id),
                "name": http_res.get("name")
            },
            "message": f"Process group '{child_pg_name}' created successfully with input/output ports"
        }

        print(f"✅ Process group '{child_pg_name}' created and started successfully")
        print(f"✅ EXITING create_and_start_stream_flow_no_agent_flow - Success")
        return result

    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating stream flow without agent: {str(e)}")
        print(f"❌ EXITING create_and_start_stream_flow_no_agent_flow - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating stream flow without agent: {str(e)}")
        print(f"❌ EXITING create_and_start_stream_flow_no_agent_flow - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_and_enable_dbcp_service(
    pg_id: str,
    name: str,
    jdbc_url: str,
    driver_class: str,
    driver_location: str,
    username: str,
    password: str,
    NIFI_URL: str,
    max_total_connections: str = "10",
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates and enables a DBCPConnectionPool controller service.
    """
    print(f"🔍 ENTERING create_and_enable_dbcp_service - PG ID: {pg_id}, Service name: '{name}'")
    logger.debug(f"JDBC URL: {jdbc_url}, Driver class: {driver_class}, Max connections: {max_total_connections}")

    try:
        print(f"Checking if DBCP service '{name}' already exists")
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services", verify=verify_ssl)
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        services = r.json().get("controllerServices", [])
        print(f"Found {len(services)} existing controller services")

        for cs in services:
            if cs["component"]["name"] == name:
                cs_id = cs["id"]
                print(f"✅ Controller service '{name}' already exists with ID: {cs_id}")

                print(f"Enabling existing service {cs_id}")
                enable_result = enable_controller_service(cs_id, NIFI_URL, verify_ssl=verify_ssl)
                if enable_result["status"]:
                    print(f"✅ Existing service enabled successfully")
                else:
                    logger.error(f"⚠️ Failed to enable existing service {cs_id}: {enable_result.get('error')}")

                print(f"✅ EXITING create_and_enable_dbcp_service - Service already exists")
                return {"status": True, "cs_id": cs_id}

        print(f"Creating new DBCP service '{name}'")
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.dbcp.DBCPConnectionPool",
                "name": name,
                "properties": {
                    "Database Connection URL": jdbc_url,
                    "Database Driver Class Name": driver_class,
                    "Database Driver Locations": driver_location,
                    "Database User": username,
                    "Password": password,
                    "Max Total Connections": max_total_connections
                }
            }
        }
        logger.debug(f"Create payload: {json.dumps(payload, indent=2)}")

        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/controller-services",
            json=payload,
            verify=verify_ssl
        )
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        cs_id = r.json()["id"]
        print(f"✅ Created controller service '{name}' with ID: {cs_id}")

        print(f"Enabling new service {cs_id}")
        enable_result = enable_controller_service(cs_id, NIFI_URL, verify_ssl=verify_ssl)
        if enable_result["status"]:
            print(f"✅ New service enabled successfully")
        else:
            logger.error(f"⚠️ Failed to enable new service {cs_id}: {enable_result.get('error')}")

        print(f"✅ EXITING create_and_enable_dbcp_service - Success")
        return {"status": True, "cs_id": cs_id}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating and enabling DBCP service: {str(e)}")
        print(f"❌ EXITING create_and_enable_dbcp_service - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid configuration creating DBCP service: {str(e)}")
        print(f"❌ EXITING create_and_enable_dbcp_service - Failed with key error")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating and enabling DBCP service: {str(e)}")
        print(f"❌ EXITING create_and_enable_dbcp_service - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_sql_to_json_jsonfile_flow(
    pg_id: str,
    sql_name: str,
    sql_query: str,
    dbcp_id: str,
    output_dir: str,
    output_filename: str,
    NIFI_URL: str,
    position_x: float = 0,
    position_y: float = 0,
    run_every_minutes: int = 10,
    start: bool = True,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a complete SQL to JSON file flow in NiFi.
    """
    print(f"🔍 ENTERING create_sql_to_json_jsonfile_flow - PG ID: {pg_id}, SQL name: '{sql_name}'")
    print(f"Output: {output_dir}/{output_filename}, Run every: {run_every_minutes} minutes")

    try:
        print("Step 1: Setting up Avro to JSON controller services")
        services_result = setup_avro_to_json_services(pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not services_result["status"]:
            logger.error(f"❌ Failed to setup Avro to JSON services: {services_result.get('error')}")
            print(f"❌ EXITING create_sql_to_json_jsonfile_flow - Services setup failed")
            return services_result

        avro_reader_id = services_result["avro_reader_id"]
        json_writer_id = services_result["json_writer_id"]
        print(f"✅ AvroReader ID: {avro_reader_id}, JsonWriter ID: {json_writer_id}")

        print("Step 2: Creating ExecuteSQL processor")
        exec_sql_result = create_execute_sql_processor(
            pg_id=pg_id,
            name=sql_name,
            position_x=position_x,
            position_y=position_y,
            dbcp_id=dbcp_id,
            sql_query=sql_query,
            run_every_minutes=run_every_minutes,
            start=False,
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        if not exec_sql_result["status"]:
            logger.error(f"❌ Failed to create ExecuteSQL processor: {exec_sql_result.get('error')}")
            print(f"❌ EXITING create_sql_to_json_jsonfile_flow - ExecuteSQL creation failed")
            return exec_sql_result

        exec_sql_proc_id = exec_sql_result["processor_id"]
        print(f"✅ ExecuteSQL processor created: {exec_sql_proc_id}")

        print("Step 3: Creating ConvertRecord processor (Avro → JSON)")
        convert_payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.ConvertRecord",
                "name": f"{sql_name}_AvroToJson",
                "position": {"x": position_x + 300, "y": position_y},
                "config": {
                    "properties": {
                        "Record Reader": avro_reader_id,
                        "Record Writer": json_writer_id
                    },
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }

        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=convert_payload,
            verify=verify_ssl
        )
        r.raise_for_status()
        convert_proc_id = r.json()["id"]
        print(f"✅ ConvertRecord processor created: {convert_proc_id}")

        print("Step 4: Creating UpdateAttribute processor (set filename)")
        update_attr_payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.attributes.UpdateAttribute",
                "name": f"{sql_name}_SetFilename",
                "position": {"x": position_x + 450, "y": position_y},
                "config": {
                    "properties": {
                        "filename": output_filename
                    },
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }

        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=update_attr_payload,
            verify=verify_ssl
        )
        r.raise_for_status()
        update_attr_id = r.json()["id"]
        print(f"✅ UpdateAttribute processor created: {update_attr_id}")

        print("Step 5: Creating PutFile processor")
        putfile_payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.PutFile",
                "name": f"{sql_name}_PutFile",
                "position": {"x": position_x + 650, "y": position_y},
                "config": {
                    "properties": {
                        "Directory": output_dir + "/" + pg_id,
                        "Conflict Resolution Strategy": "replace",
                        "Create Missing Directories": "true"
                    },
                    "autoTerminatedRelationships": ["failure", "success"]
                }
            }
        }

        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=putfile_payload,
            verify=verify_ssl
        )
        r.raise_for_status()
        putfile_id = r.json()["id"]
        print(f"✅ PutFile processor created: {putfile_id}")

        print("Step 6: Creating connections between processors")
        print("Creating connection: ExecuteSQL → ConvertRecord")
        conn1 = connect_components(
            pg_id=pg_id,
            source_id=exec_sql_proc_id,
            source_type="PROCESSOR",
            destination_id=convert_proc_id,
            destination_type="PROCESSOR",
            relationships=["success"],
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        print("Creating connection: ConvertRecord → UpdateAttribute")
        conn2 = connect_components(
            pg_id=pg_id,
            source_id=convert_proc_id,
            source_type="PROCESSOR",
            destination_id=update_attr_id,
            destination_type="PROCESSOR",
            relationships=["success"],
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        print("Creating connection: UpdateAttribute → PutFile")
        conn3 = connect_components(
            pg_id=pg_id,
            source_id=update_attr_id,
            source_type="PROCESSOR",
            destination_id=putfile_id,
            destination_type="PROCESSOR",
            relationships=["success"],
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        connections = [conn1, conn2, conn3]
        for i, conn_result in enumerate(connections, 1):
            if conn_result["status"]:
                print(f"✅ Connection {i} created successfully")
            else:
                logger.error(f"⚠️ Failed to create connection {i}: {conn_result.get('error')}")

        if start:
            print("Step 7: Starting all processors")
            processor_ids = [exec_sql_proc_id, convert_proc_id, update_attr_id, putfile_id]
            for pid in processor_ids:
                proc_result = get_processor_by_id(pid, NIFI_URL, verify_ssl=verify_ssl)
                if proc_result["status"]:
                    print(f"Starting processor {pid}")
                    start_result = start_processor(pid, NIFI_URL, verify_ssl=verify_ssl)
                    if start_result["status"]:
                        print(f"✅ Processor {pid} started")
                    else:
                        logger.error(f"⚠️ Failed to start processor {pid}: {start_result.get('error')}")
                else:
                    logger.error(f"⚠️ Failed to get processor info for {pid}")

        result = {
            "status": True,
            "pg_id": pg_id,
            "processors": {
                "execute_sql": exec_sql_proc_id,
                "convert_record": convert_proc_id,
                "update_attribute": update_attr_id,
                "putfile": putfile_id
            },
            "output": {
                "directory": output_dir,
                "filename": output_filename
            }
        }

        print(f"✅ SQL to JSON file flow created successfully")
        print(f"✅ EXITING create_sql_to_json_jsonfile_flow - Success")
        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating SQL to JSON file flow: {str(e)}")
        print(f"❌ EXITING create_sql_to_json_jsonfile_flow - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid configuration creating SQL to JSON flow: {str(e)}")
        print(f"❌ EXITING create_sql_to_json_jsonfile_flow - Failed with key error")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating SQL to JSON file flow: {str(e)}")
        print(f"❌ EXITING create_sql_to_json_jsonfile_flow - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_and_start_stream_flow(
    parent_pg_id: str,
    child_pg_name: str,
    command: str,
    http_cs_id: str,
    NIFI_URL: str,
    additional_attributes: Optional[Dict[str, str]],
    command_arguments: str = "",
    working_dir: str = "",
    verify_ssl: bool = False,
    http_status_code:str ="200"
) -> Dict[str, Any]:
    """
    Creates and starts a complete stream processing flow.
    """
    print(f"🔍 ENTERING create_and_start_stream_flow - Parent PG: {parent_pg_id}, Child name: '{child_pg_name}'")
    print(f"Command: '{command}', Working dir: '{working_dir}'")

    try:
        print("Step 1: Creating child Process Group")
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False,
            verify_ssl=verify_ssl
        )

        if not pg_result["status"]:
            logger.error(f"❌ Failed to create process group: {pg_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow - PG creation failed")
            return pg_result

        child_pg_id = pg_result["id"]
        print(f"✅ Child process group created: {child_pg_id}")

        print("Step 2: Creating Input Port 'IN'")
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0,
            verify_ssl=verify_ssl
        )

        if not in_port_result["status"]:
            logger.error(f"❌ Failed to create input port: {in_port_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow - Input port creation failed")
            return in_port_result

        in_port = in_port_result
        print(f"✅ Input port created: {in_port['id']}")

        print("Step 3: Creating UpdateAttribute processor")
        update_attr_result = create_update_attribute_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateAttributes",
            NIFI_URL=NIFI_URL,
            position_id=1,
            additional_attributes=additional_attributes,
            verify_ssl=verify_ssl
        )

        if not update_attr_result["status"]:
            logger.error(f"❌ Failed to create UpdateAttribute: {update_attr_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow - UpdateAttribute creation failed")
            return update_attr_result

        update_attr = update_attr_result
        print(f"✅ UpdateAttribute processor created: {update_attr['id']}")

        print("Step 4: Creating ExecuteStreamCommand processor")
        exec_proc_result = create_execute_stream_command(
            pg_id=child_pg_id,
            NIFI_URL=NIFI_URL,
            name="Execute_Command",
            command=command,
            command_arguments=command_arguments,
            working_dir=working_dir,
            position_id=1,
            verify_ssl=verify_ssl
        )

        if not exec_proc_result["status"]:
            logger.error(f"❌ Failed to create ExecuteStreamCommand: {exec_proc_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow - ExecuteStreamCommand creation failed")
            return exec_proc_result

        exec_proc = exec_proc_result
        print(f"✅ ExecuteStreamCommand processor created: {exec_proc['id']}")

        # print("Step 5: Creating Output Port 'OUT'")
        # out_port_result = create_output_port(
        #     pg_id=child_pg_id,
        #     name="OUT",
        #     NIFI_URL=NIFI_URL,
        #     position_id=2,
        #     verify_ssl=verify_ssl
        # )

        # if not out_port_result["status"]:
        #     logger.error(f"❌ Failed to create output port: {out_port_result.get('error')}")
        #     print(f"❌ EXITING create_and_start_stream_flow - Output port creation failed")
        #     return out_port_result

        # out_port = out_port_result
        # print(f"✅ Output port created: {out_port['id']}")

        print("Step 6: Creating PutWebSocket processor")
        ws_out_result = create_put_websocket(
            pg_id=child_pg_id,
            name=child_pg_name + "_WS_out",
            NIFI_URL=NIFI_URL,
            comp={
                "WebSocket Session Id": "${websocket.session.id}",
                "WebSocket Controller Service Id": "${websocket.controller.service.id}",
                "WebSocket Endpoint Id": "${websocket.endpoint.id}",
                "WebSocket Message Type": "TEXT"
            },
            verify_ssl=verify_ssl
        )

        if not ws_out_result["status"]:
            logger.error(f"❌ Failed to create PutWebSocket: {ws_out_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow - PutWebSocket creation failed")
            return ws_out_result

        ws_out = ws_out_result["data"]
        print(f"✅ PutWebSocket processor created: {ws_out['id']}")

        print("Step 7: Creating HandleHttpResponse processor")
        http_res_result = add_handle_http_response(
            pg_id=child_pg_id,
            processor_name=child_pg_name,
            NIFI_URL=NIFI_URL,
            http_cs_id=http_cs_id,
            verify_ssl=verify_ssl,http_status_code=http_status_code
        )

        if not http_res_result["status"]:
            logger.error(f"❌ Failed to create HandleHttpResponse: {http_res_result.get('error')}")
            print(f"❌ EXITING create_and_start_stream_flow - HandleHttpResponse creation failed")
            return http_res_result

        http_res = http_res_result["data"]
        print(f"✅ HandleHttpResponse processor created: {http_res['id']}")

        print("Step 8: Creating connections between components")
        print("Creating connection: Input Port → UpdateAttribute")
        conn1 = connect_components(
            pg_id=child_pg_id,
            source_id=in_port["id"],
            source_type="INPUT_PORT",
            destination_id=update_attr["id"],
            destination_type="PROCESSOR",
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        print("Creating connection: UpdateAttribute → ExecuteStreamCommand")
        conn2 = connect_components(
            pg_id=child_pg_id,
            source_id=update_attr["id"],
            source_type="PROCESSOR",
            destination_id=exec_proc["id"],
            destination_type="PROCESSOR",
            relationships=["success"],
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        # print("Creating connection: ExecuteStreamCommand → Output Port")
        # conn3 = connect_components(
        #     pg_id=child_pg_id,
        #     source_id=exec_proc["id"],
        #     source_type="PROCESSOR",
        #     destination_id=out_port["id"],
        #     destination_type="OUTPUT_PORT",
        #     relationships=["output stream"],
        #     NIFI_URL=NIFI_URL,
        #     verify_ssl=verify_ssl
        # )

        print("Creating connection: ExecuteStreamCommand → PutWebSocket")
        conn4 = connect_components(
            pg_id=child_pg_id,
            source_id=exec_proc["id"],
            source_type="PROCESSOR",
            destination_id=ws_out["id"],
            destination_type="PROCESSOR",
            relationships=["output stream"],
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        print("Creating connection: ExecuteStreamCommand → HandleHttpResponse")
        conn5 = connect_components(
            pg_id=child_pg_id,
            source_id=exec_proc["id"],
            source_type="PROCESSOR",
            destination_id=http_res["id"],
            destination_type="PROCESSOR",
            relationships=["output stream"],
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )

        connections = [conn1, conn2, conn4, conn5]
        for i, conn_result in enumerate(connections, 1):
            if conn_result["status"]:
                print(f"✅ Connection {i} created successfully")
            else:
                logger.error(f"⚠️ Failed to create connection {i}: {conn_result.get('error')}")

        print("Step 9: Starting all processors")
        time.sleep(4)

        processors_to_start = [
            ("ExecuteStreamCommand", exec_proc['id']),
            ("PutWebSocket", ws_out['id']),
            ("HandleHttpResponse", http_res['id']),
            ("UpdateAttribute", update_attr['id']),
        ]

        for proc_name, proc_id in processors_to_start:
            print(f"Starting {proc_name} processor: {proc_id}")
            start_result = start_processor(proc_id, NIFI_URL, verify_ssl=verify_ssl)
            if start_result["status"]:
                print(f"✅ {proc_name} processor started")
            else:
                logger.error(f"⚠️ Failed to start {proc_name} processor: {start_result.get('error')}")

        result = {
            "status": True,
            "process_group_id": child_pg_id,
            "input_port": in_port,
            "processor": exec_proc,
            #"output_port": out_port,
            "websocket_out": ws_out,
            "http_response": http_res,
            "update_attribute": update_attr,
        }

        print(f"✅ Stream flow created, connected, and started successfully")
        print(f"✅ EXITING create_and_start_stream_flow - Success")
        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating and starting stream flow: {str(e)}")
        print(f"❌ EXITING create_and_start_stream_flow - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid configuration creating stream flow: {str(e)}")
        print(f"❌ EXITING create_and_start_stream_flow - Failed with key error")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error creating and starting stream flow: {str(e)}")
        print(f"❌ EXITING create_and_start_stream_flow - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def remove_agent(
    parent_pg_id: str,
    agent_pg_id: str,
    router_id: str,
    rule_name: str,
    out_input_port: str,
    out_con_id: str,
    NIFI_URL: str,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Removes an agent from the flow by stopping components and deleting connections.
    """
    print(f"🔍 ENTERING remove_agent - Parent PG: {parent_pg_id}, Agent PG: {agent_pg_id}")
    print(f"Router ID: {router_id}, Rule name: '{rule_name}', Out input port: {out_input_port}, Out connection: {out_con_id}")

    try:
        print("Step 1: Stopping agent process group")
        stop_pg_result = stop_process_group(agent_pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not stop_pg_result["status"]:
            logger.error(f"⚠️ Failed to stop process group {agent_pg_id}: {stop_pg_result.get('error')}")

        print("Step 2: Stopping router processor")
        stop_router_result = stop_processor(router_id, NIFI_URL, verify_ssl=verify_ssl)
        if not stop_router_result["status"]:
            logger.error(f"⚠️ Failed to stop router processor {router_id}: {stop_router_result.get('error')}")

        print("Step 3: Getting and stopping all ports in agent PG")
        ports = get_ports_in_process_group(process_group_id=agent_pg_id, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        print(f"Found {len(ports)} ports in agent PG")

        for idx, port in enumerate(ports, 1):
            print(f"Stopping port {idx}/{len(ports)}: {port['port_id']} (type: {port['port_type']})")
            stop_port_by_id(port_id=port['port_id'], port_type=str(port['port_type']).lower().strip(), NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)

        print("Step 4: Stopping output input port")
        stop_port_by_id(port_id=out_input_port, port_type='input_port', NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)

        print("Step 5: Removing output connection")
        print(f"Deleting connection: {out_con_id}")
        delete_connection_result = delete_connection_by_id(connection_id=out_con_id, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        if delete_connection_result["status"] == "deleted":
            print(f"✅ Connection {out_con_id} deleted")
        else:
            logger.error(f"⚠️ Failed to delete connection: {delete_connection_result.get('error')}")

        print("Step 6: Removing route rule")
        remove_rule_result = remove_route_on_attribute_rule(
            route_proc_id=router_id,
            rule_name=rule_name,
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )
        if remove_rule_result["status"]:
            print(f"✅ Rule '{rule_name}' removed")
        else:
            logger.error(f"⚠️ Failed to remove rule '{rule_name}': {remove_rule_result.get('error')}")

        print("Step 7: Deleting all connections to agent PG")
        delete_conns_result = delete_all_connections_to_pg(agent_pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if delete_conns_result["status"]:
            print(f"✅ All connections to PG {agent_pg_id} deleted")
        else:
            logger.error(f"⚠️ Failed to delete some connections: {delete_conns_result.get('error')}")

        print("Step 8: Deleting processor to child PG connection")
        delete_proc_conn_result = delete_processor_to_child_pg_connection(
            parent_pg_id=parent_pg_id,
            processor_id=router_id,
            child_pg_id=agent_pg_id,
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )
        if delete_proc_conn_result["status"]:
            print(f"✅ Processor to child PG connection deleted")
        else:
            logger.error(f"⚠️ Failed to delete processor to child PG connection: {delete_proc_conn_result.get('error')}")

        print("Step 9: Deleting agent process group")
        delete_pg_result = delete_process_group(agent_pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not delete_pg_result["status"]:
            logger.error(f"❌ Failed to delete process group: {delete_pg_result.get('error')}")
            print(f"❌ EXITING remove_agent - PG deletion failed")
            return delete_pg_result

        print("Step 10: Restarting router processor and ports")
        print(f"Starting router processor: {router_id}")
        start_router_result = start_processor(router_id, NIFI_URL, verify_ssl=verify_ssl)

        for idx, port in enumerate(ports, 1):
            print(f"Starting port {idx}/{len(ports)}: {port['port_id']}")
            start_port_by_id(port_id=port['port_id'], port_type=str(port['port_type']).lower().strip(), NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)

        print(f"Starting output input port: {out_input_port}")
        start_port_by_id(port_id=out_input_port, port_type='input_port', NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)

        if not start_router_result["status"]:
            logger.error(f"⚠️ Failed to restart router processor {router_id}: {start_router_result.get('error')}")

        print(f"✅ Agent {agent_pg_id} removed successfully")
        print(f"✅ EXITING remove_agent - Success")
        return {"status": True, "message": f"Agent {agent_pg_id} removed successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error removing agent: {str(e)}")
        print(f"❌ EXITING remove_agent - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response removing agent: {str(e)}")
        print(f"❌ EXITING remove_agent - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error removing agent: {str(e)}")
        print(f"❌ EXITING remove_agent - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def connect_child_pg_to_processor_flow(
    parent_pg_id: str,
    child_pg_id: str,
    processor_id: str,
    NIFI_URL: str,
    output_port_name: Optional[str] = None,
    relationships: Optional[List[str]] = None,
    name: Optional[str] = None,
    flowfile_expiration: str = "0 sec",
    backpressure_count: int = 10000,
    backpressure_size: str = "1 GB"
) -> Dict[str, Any]:
    """
    Connects a child Process Group's output port to a processor in the parent Process Group.
    """
    print(f"🔍 ENTERING connect_child_pg_to_processor_flow - Parent PG: {parent_pg_id}, Child PG: {child_pg_id}, Processor ID: {processor_id}")

    try:
        print(f"Fetching output ports for child PG {child_pg_id}")
        r = requests.get(f"{NIFI_URL}/process-groups/{child_pg_id}/output-ports")
        r.raise_for_status()
        print(f"✅ GET request successful - Status code: {r.status_code}")

        output_ports = r.json()["outputPorts"]
        print(f"Found {len(output_ports)} output ports in child PG")

        if not output_ports:
            error_msg = f"Child PG {child_pg_id} has no output ports"
            logger.error(f"❌ {error_msg}")
            print(f"❌ EXITING connect_child_pg_to_processor_flow - No output ports")
            return {"status": False, "error": error_msg}

        output_port = None
        if output_port_name:
            print(f"Looking for output port with name: '{output_port_name}'")
            for port in output_ports:
                if port["component"]["name"] == output_port_name:
                    output_port = port
                    print(f"✅ Found output port: '{output_port_name}' (ID: {output_port['id']})")
                    break
            if output_port is None:
                available = [p["component"]["name"] for p in output_ports]
                error_msg = f"Output port '{output_port_name}' not found in child PG {child_pg_id}. Available: {available}"
                logger.error(f"❌ {error_msg}")
                print(f"❌ EXITING connect_child_pg_to_processor_flow - Port not found")
                return {"status": False, "error": error_msg}
        else:
            output_port = output_ports[0]
            print(f"Using first output port: '{output_port['component']['name']}' (ID: {output_port['id']})")

        print(f"Fetching destination processor info")
        r = requests.get(f"{NIFI_URL}/processors/{processor_id}")
        r.raise_for_status()
        processor = r.json()
        processor_name = processor["component"]["name"]
        print(f"Destination processor: '{processor_name}' (ID: {processor_id})")

        connection_payload = {
            "revision": {"version": 0},
            "component": {
                "name": name or f"Connection_from_{output_port['component']['name']}",
                "source": {
                    "id": output_port["id"],
                    "type": "OUTPUT_PORT",
                    "groupId": child_pg_id
                },
                "destination": {
                    "id": processor_id,
                    "type": "PROCESSOR",
                    "groupId": parent_pg_id
                },
                "flowFileExpiration": flowfile_expiration,
                "backPressureDataSizeThreshold": backpressure_size,
                "backPressureObjectThreshold": backpressure_count
            }
        }

        logger.debug(f"Connection payload: {json.dumps(connection_payload, indent=2)}")

        url = f"{NIFI_URL}/process-groups/{parent_pg_id}/connections"
        print(f"Making POST request to {url}")
        r = requests.post(url, json=connection_payload)
        r.raise_for_status()
        print(f"✅ POST request successful - Status code: {r.status_code}")

        print(f"✅ Connected output port of child PG to processor in parent PG")
        print(f"✅ EXITING connect_child_pg_to_processor_flow - Success")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error connecting child PG output port to processor: {str(e)}")
        print(f"❌ EXITING connect_child_pg_to_processor_flow - Failed with network error")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"❌ Invalid response connecting child PG output port to processor: {str(e)}")
        print(f"❌ EXITING connect_child_pg_to_processor_flow - Failed with key error")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"❌ Unexpected error connecting child PG output port to processor: {str(e)}")
        print(f"❌ EXITING connect_child_pg_to_processor_flow - Failed with unexpected error")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}
