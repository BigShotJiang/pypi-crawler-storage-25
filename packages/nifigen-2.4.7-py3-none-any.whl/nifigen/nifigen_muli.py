import requests
import time
import logging
from typing import Dict, List, Optional, Any

from nifigen.nifigen_comp import (
    connect_components,
    create_execute_stream_command,
    create_input_port,
    create_output_port,
    create_process_group_inside_pg,
    create_update_attribute_processor,
    create_update_record_processor,
    get_controller_service_by_name,
    add_handle_http_response,
    start_port_by_id,
    start_processor,
)

logger = logging.getLogger("nifigen")


# #########################################
# #########################################
# multi direction 
# ##########################################################
# #############################################
def create_evaluate_json_path(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    attributes: Dict[str, str],
    destination: str = "flowfile-attribute",
    return_type: str = "auto-detect",
    path_not_found: str = "ignore",
    null_value_representation: str = "empty string",
    position_id: int = 0,
    auto_terminate_failure: bool = True,
    auto_terminate_unmatched: bool = True,
    auto_terminate_matched: bool = False,
) -> Dict[str, Any]:
    """
    Creates an EvaluateJsonPath processor with multiple dynamic attributes.

    Each entry in the `attributes` dict becomes a dynamic property on the
    processor where the key is the resulting flowfile attribute name and the
    value is the JSONPath expression (e.g. ``$.question``).

    Args:
        pg_id: Target Process Group ID
        name: Processor display name
        NIFI_URL: Base URL of the NiFi instance (e.g. https://host:8443/nifi-api)
        attributes: Mapping of attribute-name -> JSONPath expression.
                    Example: {"question": "$.question", "session_id": "$.session_id"}
        destination: Where to put evaluated results.
                     "flowfile-attribute" (default) or "flowfile-content"
        return_type: "auto-detect" (default), "json", or "scalar"
        path_not_found: Behaviour when path is not found - "warn" (default) or "skip"
        null_value_representation: How to represent null - "empty string" (default) or "the string 'null'"
        position_id: Position multiplier for canvas layout
        auto_terminate_failure: Auto-terminate the 'failure' relationship
        auto_terminate_unmatched: Auto-terminate the 'unmatched' relationship
        auto_terminate_matched: Auto-terminate the 'matched' relationship

    Returns:
        dict with keys: status (bool), id, name, data  –  or status=False and error on failure
    """
    try:
        position = (400 * position_id, 100.0)
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        # --- static (built-in) properties ---
        properties: Dict[str, Any] = {
            "Destination": destination,
            "Return Type": return_type,
            "Path Not Found Behavior": path_not_found,
            "Null Value Representation": null_value_representation,
        }

        # --- dynamic properties (user-defined JSONPath attributes) ---
        descriptors: Dict[str, Any] = {}
        for attr_name, json_path in attributes.items():
            properties[attr_name] = json_path
            descriptors[attr_name] = {
                "name": attr_name,
                "displayName": attr_name,
                "description": "",
                "required": False,
                "sensitive": False,
                "dynamic": True,
                "supportsEl": False,
                "expressionLanguageScope": "Not Supported",
                "dependencies": [],
            }

        # --- auto-terminated relationships ---
        auto_terminated: List[str] = []
        if auto_terminate_failure:
            auto_terminated.append("failure")
        if auto_terminate_unmatched:
            auto_terminated.append("unmatched")
        if auto_terminate_matched:
            auto_terminated.append("matched")

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.EvaluateJsonPath",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1]),
                },
                "config": {
                    "properties": properties,
                    "descriptors": descriptors,
                    "autoTerminatedRelationships": auto_terminated,
                },
            },
        }

        r = requests.post(url, json=payload)
        r.raise_for_status()

        proc_id = r.json()["id"]
        logger.info(
            f"Created EvaluateJsonPath '{name}' with {len(attributes)} attribute(s) "
            f"in PG '{pg_id}'"
        )

        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json(),
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating EvaluateJsonPath: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration for EvaluateJsonPath: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating EvaluateJsonPath: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_route_on_attribute(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    rules: Dict[str, str],
    routing_strategy: str = "Route to Property name",
    position_id: int = 0,
    auto_terminate_unmatched: bool = True,
) -> Dict[str, Any]:
    """
    Creates a RouteOnAttribute processor with multiple routing rules already
    configured.

    Each entry in ``rules`` becomes a dynamic property (relationship) on the
    processor.  The key is the relationship / rule name and the value is a
    NiFi Expression Language expression that must evaluate to ``true`` for a
    FlowFile to be routed to that relationship.

    Example::

        create_route_on_attribute(
            pg_id=pg_id,
            name="Route_By_Agent",
            NIFI_URL=NIFI_URL,
            rules={
                "is_agent_a": "${selected_agents:contains('agent_a')}",
                "is_agent_b": "${selected_agents:contains('agent_b')}",
                "has_plan":   "${plan:isEmpty():not()}",
            },
        )

    Args:
        pg_id: Target Process Group ID
        name: Processor display name
        NIFI_URL: Base URL of the NiFi instance
        rules: Mapping of rule-name -> NiFi Expression Language expression.
        routing_strategy: "Route to Property name" (default) or
                          "Route to 'matched' if all match" /
                          "Route to 'matched' if any matches"
        position_id: Position multiplier for canvas layout
        auto_terminate_unmatched: Auto-terminate the 'unmatched' relationship

    Returns:
        dict with keys: status (bool), id, name, data — or status=False
        and error on failure.
    """
    try:
        position = (400 * position_id, 100.0)
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        # --- built-in property ---
        properties: Dict[str, Any] = {
            "Routing Strategy": routing_strategy,
        }

        # --- dynamic properties (routing rules) ---
        for rule_name, expression in rules.items():
            properties[rule_name] = expression

        # --- auto-terminated relationships ---
        auto_terminated: List[str] = []
        if auto_terminate_unmatched:
            auto_terminated.append("unmatched")

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.RouteOnAttribute",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1]),
                },
                "config": {
                    "properties": properties,
                    "autoTerminatedRelationships": auto_terminated,
                },
            },
        }

        r = requests.post(url, json=payload)
        r.raise_for_status()

        proc_id = r.json()["id"]
        rule_names = list(rules.keys())
        logger.info(
            f"Created RouteOnAttribute '{name}' with {len(rules)} rule(s) "
            f"{rule_names} in PG '{pg_id}'"
        )

        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json(),
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating RouteOnAttribute: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration for RouteOnAttribute: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating RouteOnAttribute: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}

def create_and_start_stream_flow_no_agent_flow_mult(
    parent_pg_id: str,
    child_pg_name: str,
    NIFI_URL: str,
    working_dir:str,
    command:str,
    command_arguments:str,
    ur_json_r: str,
    ur_json_wr: str,
    additional_attributes_update: Optional[Dict[str, str]] = {"agents_ops": """${agents_ops:isEmpty():ifElse("${RouteOnAttribute.Route}","${agents_ops}--${RouteOnAttribute.Route}")}"""},
    additional_ru_update: Optional[Dict[str, str]] = {"/agents_ops": """${agents_ops}"""},
    attribute_evjson:Dict={"next_agent": "$.next_agent", "next_agent_case": "$.next_agent_case","remaining_parallel_slots":"$.remaining_parallel_slots","res":"$.res"}
) -> Dict[str, Any]:
    """
    Creates a simple process group with input and output ports only (no agent processors).
    This is used for basic passthrough or routing flows.
    
    Args:
        parent_pg_id: Parent Process Group ID
        child_pg_name: Child process group name
        NIFI_URL: Base URL of the NiFi instance
        ur_json_r: JSON Reader controller service ID
        ur_json_wr: JSON Writer controller service ID
        additional_attributes_update: Additional attributes for UpdateAttribute processor
        additional_ru_update: Additional RecordPath updates for UpdateRecord processor
        
    Returns:
        Dictionary containing status and created component details
    """
    try:
        # Create child Process Group
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False
        )
        
        if not pg_result["status"]:
            return pg_result
            
        child_pg_id = pg_result["id"]

        # Create Input Port
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0
        )

        if not in_port_result["status"]:
            return in_port_result
            
        in_port = in_port_result

        # Create UpdateAttribute processor
        update_attr_result = create_update_attribute_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateAttributes",
            NIFI_URL=NIFI_URL,
            position_id=1,
            additional_attributes=additional_attributes_update
        )
        
        if not update_attr_result["status"]:
            return update_attr_result
            
        update_attr = update_attr_result

        # Create UpdateRecord processor
        records_update_result = create_update_record_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateRecord",
            NIFI_URL=NIFI_URL,
            record_reader=ur_json_r,
            record_writer=ur_json_wr,
            record_properties=additional_ru_update
        )
        
        if not records_update_result["status"]:
            return records_update_result
            
        records_update = records_update_result

        ### excute stream
        exec_proc_result = create_execute_stream_command(
            pg_id=child_pg_id,
            NIFI_URL=NIFI_URL,
            name=f"{child_pg_name}_Execute_Command",
            command=command,
            command_arguments=command_arguments,
            working_dir=working_dir,
            position_id=1
        )
        
        if not exec_proc_result["status"]:
            return exec_proc_result
            
        exec_proc = exec_proc_result

        ###### evaluate
        evjson_proc_result = create_evaluate_json_path(pg_id=child_pg_id,name=f"{child_pg_name}_EvaluateJsonPath",NIFI_URL=NIFI_URL,attributes=attribute_evjson)
        if not evjson_proc_result["status"]:
            return evjson_proc_result
            
        evjson_proc = evjson_proc_result

        ##########add router
        router_proc_result= create_route_on_attribute(pg_id=child_pg_id,
            NIFI_URL=NIFI_URL,
            name=f"{child_pg_name}_RouteOnAttribute",rules={"next_agent": "${res:equals('1')}"})
        if not router_proc_result["status"]:
            return router_proc_result
            
        router_proc = router_proc_result

        ###################################### HTTPhandler
        http_cs_result = get_controller_service_by_name(
            pg_id=parent_pg_id, 
            service_name="http_cs", 
            NIFI_URL=NIFI_URL
            )
        logger.info(f"http_cs_result id: {http_cs_result['data']['id']}")
        http_sc_id =http_cs_result['data']['id']
        http_res_result = add_handle_http_response(
            pg_id=child_pg_id,
            processor_name=child_pg_name,
            NIFI_URL=NIFI_URL,
            http_cs_id=http_sc_id
        )           
        if not http_res_result["status"]:
            return http_res_result
            
        http_res = http_res_result["data"]
        # Create Output Port
        out_port_result = create_output_port(
            pg_id=child_pg_id,
            name="OUT",
            NIFI_URL=NIFI_URL,
            position_id=2
        )
        
        if not out_port_result["status"]:
            return out_port_result
            
        time.sleep(4)
        out_port = out_port_result
        
        logger.info("##start out connection ==")
        
        #Create connections between components
        connections = [
            connect_components(
                pg_id=child_pg_id,
                source_id=in_port["id"],
                source_type="INPUT_PORT",
                destination_id=update_attr['id'],
                destination_type="PROCESSOR",
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=update_attr['id'],
                source_type="PROCESSOR",
                destination_id=records_update['id'],
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=records_update['id'],
                source_type="PROCESSOR",
                destination_id=exec_proc['id'],
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc['id'],
                source_type="PROCESSOR",
                destination_id=evjson_proc['id'],
                destination_type="PROCESSOR",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=evjson_proc['id'],
                source_type="PROCESSOR",
                destination_id=router_proc['id'],
                destination_type="PROCESSOR",
                relationships=["matched"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=router_proc['id'],
                source_type="PROCESSOR",
                destination_id=out_port['id'],
                destination_type="PROCESSOR",
                relationships=["next_agent"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                 pg_id=child_pg_id,
                 source_id=router_proc['id'],
                 source_type="PROCESSOR",
                 destination_id=http_res['id'],
                 destination_type="OUTPUT_PORT",
                 relationships=["unmatched"],
                 NIFI_URL=NIFI_URL
             )
        ]
        
        #Check connection results
        for conn_result in connections:
            time.sleep(2)
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        #Start input port
        try:
            logger.info(f"## Start input-port ++> {in_port['id']}")
            start_input_result = start_port_by_id(
                port_id=in_port["id"],
                port_type="input-port",
                NIFI_URL=NIFI_URL
            )
            if not start_input_result["status"]:
                logger.error(f"Warning: Failed to start input port: {start_input_result.get('error', 'Unknown error')}")
        except Exception as start_error:
            logger.error(f"Warning: Error starting input port: {str(start_error)}")

        # Start output port
        try:
            logger.info(f"## Start output-port ++> {out_port['id']}")
            start_output_result = start_port_by_id(
                port_id=out_port["id"],
                port_type="output-port",
                NIFI_URL=NIFI_URL
            )
            if not start_output_result["status"]:
                logger.error(f"Warning: Failed to start output port: {start_output_result.get('error', 'Unknown error')}")
        except Exception as start_error:
            logger.error(f"Warning: Error starting output port: {str(start_error)}")

        logger.info(f"✅ Created process group '{child_pg_name}' with input and output ports")

        return {
            "status": True,
            "process_group_id": child_pg_id,
            "process_group_name": child_pg_name,
            "input_port": {
                "id": in_port.get("id"),
                "name": in_port.get("name")
            },
            "update_attr": {
                "id": update_attr.get("id"),
                "name": update_attr.get("name")
            },
            "records_update": {
                "id": records_update.get("id"),
                "name": records_update.get("name")
            },
             "exec_proc": {
                "id": exec_proc.get("id"),
                "name": exec_proc.get("name")
            },
             "evjson_proc": {
                "id": evjson_proc.get("id"),
                "name": evjson_proc.get("name")
            },
             "router_proc": {
                "id": router_proc.get("id"),
                "name": router_proc.get("name")
            },
            "http_res": {
                "id": http_res.get("id"),
                "name": http_res.get("name")
            },
            "output_port": {
                "id": out_port.get("id"),
                "name": out_port.get("name")
            },
            "message": f"Process group '{child_pg_name}' created successfully with input/output ports"
        }
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating stream flow without agent: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating stream flow without agent: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def connect_child_pg_to_processor_flow(
    parent_pg_id: str,
    child_pg_id: str,
    processor_id: str,
    NIFI_URL: str,
    output_port_name: Optional[str] = None,
    relationships: Optional[List[str]] = None,
    name: Optional[str] = None,
    flowfile_expiration: str = "0 sec",
    backpressure_count: int = 10000,
    backpressure_size: str = "1 GB"
) -> Dict[str, Any]:
    """
    Connects a child Process Group's output port to a processor in the parent Process Group.

    This is the reverse of connect_processor_to_child_pg: data flows OUT of the child PG
    through its output port and INTO a processor that lives in the parent PG.

    Args:
        parent_pg_id: Parent Process Group ID (where the processor lives)
        child_pg_id: Child Process Group ID (where the output port lives)
        processor_id: Destination Processor ID in the parent PG
        NIFI_URL: Base URL of the NiFi instance
        output_port_name: Optional name of the output port to use.
                          If None, the first output port found is used.
        relationships: Not typically needed (output ports don't have relationships),
                       kept for API compatibility. Defaults to None.
        name: Optional connection name
        flowfile_expiration: FlowFile expiration time (default "0 sec")
        backpressure_count: Backpressure object threshold (default 10000)
        backpressure_size: Backpressure data size threshold (default "1 GB")

    Returns:
        Operation status with created connection data
    """
    try:
        # Get the child PG's output ports
        r = requests.get(f"{NIFI_URL}/process-groups/{child_pg_id}/output-ports")
        r.raise_for_status()
        output_ports = r.json()["outputPorts"]

        if not output_ports:
            raise Exception(f"Child PG {child_pg_id} has no output ports")

        # Select the output port: by name or use the first one
        output_port = None
        if output_port_name:
            for port in output_ports:
                if port["component"]["name"] == output_port_name:
                    output_port = port
                    break
            if output_port is None:
                available = [p["component"]["name"] for p in output_ports]
                raise Exception(
                    f"Output port '{output_port_name}' not found in child PG {child_pg_id}. "
                    f"Available output ports: {available}"
                )
        else:
            output_port = output_ports[0]

        # Get the destination processor info (for logging)
        r = requests.get(f"{NIFI_URL}/processors/{processor_id}")
        r.raise_for_status()
        processor = r.json()

        # Prepare the connection payload
        connection_payload = {
            "revision": {"version": 0},
            "component": {
                "name": name or f"Connection_from_{output_port['component']['name']}",
                "source": {
                    "id": output_port["id"],
                    "type": "OUTPUT_PORT",
                    "groupId": child_pg_id
                },
                "destination": {
                    "id": processor_id,
                    "type": "PROCESSOR",
                    "groupId": parent_pg_id
                },
                "flowFileExpiration": flowfile_expiration,
                "backPressureDataSizeThreshold": backpressure_size,
                "backPressureObjectThreshold": backpressure_count
            }
        }


        # Create the connection in the parent PG
        url = f"{NIFI_URL}/process-groups/{parent_pg_id}/connections"
        r = requests.post(url, json=connection_payload)
        r.raise_for_status()

        logger.info(
            f"Connected output port '{output_port['component']['name']}' of child PG "
            f"to processor '{processor['component']['name']}' in parent PG."
        )
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error connecting child PG output port to processor: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response connecting child PG output port to processor: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error connecting child PG output port to processor: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}

def create_and_start_stream_flow_mult(
    parent_pg_id: str,
    child_pg_name: str,
    command: str,
    http_cs_id: str,
    NIFI_URL: str,
    additional_attributes: Optional[Dict[str, str]],
    command_arguments: str = "",
    working_dir: str = ""
) -> Dict[str, Any]:
    """
    Creates and starts a complete stream processing flow.
    
    Args:
        parent_pg_id: Parent Process Group ID
        child_pg_name: Child process group name
        command: Command to execute
        http_cs_id: HTTP context map controller service ID
        NIFI_URL: Base URL of the NiFi instance
        additional_attributes: Additional attributes for UpdateAttribute processor
        command_arguments: Command arguments
        working_dir: Working directory
        
    Returns:
        Flow creation status and component IDs
    """
    try:
        # Create child Process Group
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False
        )
        
        if not pg_result["status"]:
            return pg_result
            
        child_pg_id = pg_result["id"]

        # Create Input Port
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0
        )
        
        if not in_port_result["status"]:
            return in_port_result
            
        in_port = in_port_result
        
        # Create UpdateAttribute processor
        # update_attr_result = create_update_attribute_processor(
        #     pg_id=child_pg_id,
        #     name=f"{child_pg_name}_UpdateAttributes",
        #     NIFI_URL=NIFI_URL,
        #     position_id=1,
        #     additional_attributes=additional_attributes
        # )
        
        # if not update_attr_result["status"]:
        #     return update_attr_result
            
        # update_attr = update_attr_result
        
        # Create ExecuteStreamCommand processor
        exec_proc_result = create_execute_stream_command(
            pg_id=child_pg_id,
            NIFI_URL=NIFI_URL,
            name="Execute_Command",
            command=command,
            command_arguments=command_arguments,
            working_dir=working_dir,
            position_id=1
        )
        
        if not exec_proc_result["status"]:
            return exec_proc_result
            
        exec_proc = exec_proc_result

        # Create Output Port
        out_port_result = create_output_port(
            pg_id=child_pg_id,
            name="OUT",
            NIFI_URL=NIFI_URL,
            position_id=2
        )
        
        if not out_port_result["status"]:
            return out_port_result
            
        out_port = out_port_result

        # Create PutWebSocket processor
        # ws_out_result = create_put_websocket(
        #     pg_id=child_pg_id,
        #     name=child_pg_name + "_WS_out",
        #     NIFI_URL=NIFI_URL,
        #     comp={
        #         "WebSocket Session Id": "${websocket.session.id}",
        #         "WebSocket Controller Service Id": "${websocket.controller.service.id}",
        #         "WebSocket Endpoint Id": "${websocket.endpoint.id}",
        #         "WebSocket Message Type": "TEXT"
        #     }
        # )
        
        # if not ws_out_result["status"]:
        #     return ws_out_result
            
        # ws_out = ws_out_result["data"]

        # Create HandleHttpResponse processor
        # http_res_result = add_handle_http_response(
        #     pg_id=child_pg_id,
        #     processor_name=child_pg_name,
        #     NIFI_URL=NIFI_URL,
        #     http_cs_id=http_cs_id
        # )
        
        # if not http_res_result["status"]:
        #     return http_res_result
            
        # http_res = http_res_result["data"]

        # Create connections between components
        connections = [
            # Input Port → UpdateAttribute
            connect_components(
                pg_id=child_pg_id,
                source_id=in_port["id"],
                source_type="INPUT_PORT",
                destination_id=exec_proc["id"],
                destination_type="PROCESSOR",
                NIFI_URL=NIFI_URL
            ),
            # UpdateAttribute → ExecuteStreamCommand
            # connect_components(
            #     pg_id=child_pg_id,
            #     source_id=update_attr["id"],
            #     source_type="PROCESSOR",
            #     destination_id=exec_proc["id"],
            #     destination_type="PROCESSOR",
            #     relationships=["success"],
            #     NIFI_URL=NIFI_URL
            # ),
            # ExecuteStreamCommand → Output Port
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc["id"],
                source_type="PROCESSOR",
                destination_id=out_port["id"],
                destination_type="OUTPUT_PORT",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL
            ),
            # ExecuteStreamCommand → PutWebSocket
            # connect_components(
            #     pg_id=child_pg_id,
            #     source_id=exec_proc["id"],
            #     source_type="PROCESSOR",
            #     destination_id=ws_out["id"],
            #     destination_type="PROCESSOR",
            #     relationships=["output stream"],
            #     NIFI_URL=NIFI_URL
            # ),
            # # ExecuteStreamCommand → HandleHttpResponse
            # connect_components(
            #     pg_id=child_pg_id,
            #     source_id=exec_proc["id"],
            #     source_type="PROCESSOR",
            #     destination_id=http_res["id"],
            #     destination_type="PROCESSOR",
            #     relationships=["output stream"],
            #     NIFI_URL=NIFI_URL
            # )
        ]
        
        # Check connection results
        for conn_result in connections:
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        # Start processors
        time.sleep(4)
        start_results = [
            start_processor(exec_proc['id'], NIFI_URL),
            #start_processor(ws_out['id'], NIFI_URL),
            #start_processor(http_res['id'], NIFI_URL),
            #start_processor(update_attr['id'], NIFI_URL),
        ]
        
        for start_result in start_results:
            if not start_result["status"]:
                logger.error("Warning: Failed to start some processors")

        logger.info("✅ Flow created, connected, and started successfully")

        return {
            "status": True,
            "process_group_id": child_pg_id,
            "input_port": in_port,
            "processor": exec_proc,
            "output_port": out_port,
            # "websocket_out": ws_out,
            # "http_response": http_res,
            #"update_attribute": update_attr,
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating and starting stream flow: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating stream flow: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating and starting stream flow: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


