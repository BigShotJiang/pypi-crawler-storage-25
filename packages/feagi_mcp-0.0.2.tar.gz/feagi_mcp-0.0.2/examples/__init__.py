"""Empty examples package marker."""
