import re


def dic_get(dic: dict, key, default=None):
    value = dic.get(key)
    if value is None:
        return default
    return value


def set_nested_value(dictionary, path, value, overwrite=True):
    keys = path.split('.')
    current = dictionary

    # 遍历除最后一个键以外的所有键
    for key in keys[:-1]:
        if key not in current:
            current[key] = dict()
        current = current[key]

    # 设置最后一个键的值
    if overwrite:
        current[keys[-1]] = value
        return True

    if keys[-1] in current:
        return False
    current[keys[-1]] = value
    return True


def get_nested_value(data, path, default=None):
    keys = path.split('.')
    temp = data
    for i in keys:
        if i.startswith('$'):
            i = int(i[1:])

        try:
            pattern = """\[(\d+)\]"""
            if type(i) is str and (_match := re.findall(pattern, i)):
                k1 = re.sub(pattern, '', i)
                temp = temp[k1]
                for k2 in _match:
                    temp = temp[int(k2)]
            else:
                temp = temp[i]
        except IndexError as e:
            # print([][1])
            temp = None
        except TypeError as e:
            # print([]['1'])
            temp = None
        except KeyError as e:
            # print({}['1'])
            temp = None

    if temp is None:
        return default
    return temp


def find_key_value(data, target_key):
    """
    遍历无限级嵌套字典/列表，查找指定key
    :param data: 嵌套字典/列表数据
    :param target_key: 要查找的key
    :return: 找到返回value，未找到返回None
    """
    # 用列表模拟队列，存放待遍历的数据
    stack = [data]

    while stack:
        # 取出一个元素
        current = stack.pop(0)  # pop() 是深度优先，pop(0) 是广度优先，效果一样

        # 如果是字典：先检查key，再把value加入待遍历
        if isinstance(current, dict):
            # 找到直接返回
            if target_key in current:
                return current[target_key]
            # 把所有value加入队列，继续遍历
            stack.extend(current.values())

        # 如果是列表/元组：直接把元素加入队列
        elif isinstance(current, (list, tuple)):
            stack.extend(current)

    return None


if '__main__' == __name__:
    d = dict(x=1, a=dict(y=1))
    set_nested_value(d, 'a.b.c', 1)
    print(d)

    d = {
        'books': [
            [
                {'id': 1, 'name': 'book1'}
            ]
        ],
        'author': 'xxx',
    }
    print(get_nested_value(d, 'books.$0.$0.name'))
    print(get_nested_value(d, 'books[0][0].name'))
    print(get_nested_value(d, 'author'))
