import time
import queue
import threading
import traceback
from typing import Any
from dataclasses import dataclass

"""
2019-09-04
本来我觉得原生的线程池应该比较好，可是我发现
from concurrent.futures import ThreadPoolExecutor, wait 
该线程池控制线程启动的时候，并不精确，我本来只想一次只运行一个

2025-03-20
线程数控制十分精确


traceback 模块打印方法的作用和区别

方法	是否需要异常	打印内容	典型场景
print_exc	✅ 必须在 except 块	异常类型 + 消息 + 栈	快速打印当前异常
print_exception	✅ 需要手动传 (type, value, tb)	异常类型 + 消息 + 栈	打印任意已知异常
print_tb	✅ 需要 traceback 对象	仅栈信息	只看调用链，不关心错误内容
print_last	❌ 依赖 sys.last_*	上一次未捕获异常的完整信息	调试程序崩溃后，查看上次错误
print_list	❌ 依赖 extracted_list	格式化打印解析后的栈列表	手动解析栈后，按标准格式输出
print_stack	❌ 不需要异常	当前调用栈	调试执行流程，无异常时看调用链
"""


@dataclass
class Task:
    main: callable
    args: tuple
    kwargs: dict
    result: Any = None
    error: Any = None

    def call(self):
        try:
            self.result = self.main(*self.args, **self.kwargs)
            return True
        except Exception as e:
            traceback.print_exc()
            self.error = e
            return False


class ThreadManager:
    def __init__(self, max_workers=4):
        self._semaphore = threading.Semaphore(max_workers)
        self._task_queue = queue.Queue()
        self._done_queue = queue.Queue()
        self._start_time = 0
        self._running = 0
        self._task_count = 0

    def __repr__(self):
        tip = [
            ('任务数', self._task_count),
            ('运行中', self._running),
            ('已完成', self._done_queue.qsize()),
            ('已用时', round((time.time_ns() - self._start_time) / 10 ** 9, 3)),
        ]
        return '; '.join([f'{_[0]}: {_[1]}' for _ in tip])

    @property
    def task_count(self):
        return self._task_count

    def _worker(self, task: Task):
        self._running += 1
        task.call()
        self._task_queue.task_done()
        self._semaphore.release()
        self._running -= 1
        self._done_queue.put(task)

    def _progress(self, tqdm_bar):
        """
        tqdm_bar = tqdm(total=total)
        """
        if not tqdm_bar:
            return

        last_finish = 0
        while True:
            residue = self._task_count - self._done_queue.qsize()
            curr_finish = self._task_count - residue
            tqdm_bar.set_description(f"{self}; 进度")
            tqdm_bar.update(curr_finish - last_finish)
            last_finish = curr_finish
            if residue <= 0:
                break

        tqdm_bar.close()

    def add(self, _func: callable, *args, **kwargs):
        self._task_queue.put(Task(_func, args, kwargs))
        self._task_count += 1

    def run(self, tqdm_bar=None):
        self._start_time = time.time_ns()
        threading.Thread(target=self._progress, args=(tqdm_bar,)).start()  # 进度条
        while True:
            if self._task_queue.qsize() <= 0:
                break
            self._semaphore.acquire()  # 阻塞直到有可用槽位
            task = self._task_queue.get()
            threading.Thread(target=self._worker, args=(task,)).start()

        self._task_queue.join()


if '__main__' == __name__:
    from tqdm import tqdm


    def ff(a=1):
        time.sleep(a)
        print(1 / 0)


    t1 = time.perf_counter()
    tm = ThreadManager(2)

    for i in range(16):
        tm.add(ff, 1)

    tm.run(tqdm(total=tm.task_count))
    # tm.run()
    print('完成', time.perf_counter() - t1)
