"""OAuth 2.1 PKCE authentication for ASIFlow MCP Connector.

Implements the full OAuth 2.1 authorization code flow with PKCE:
1. Generates a cryptographic code verifier and S256 challenge.
2. Opens the user's browser to ASIFlow's authorization endpoint.
3. Starts a transient local HTTP server to receive the redirect callback.
4. Exchanges the authorization code for access + refresh tokens.
5. Persists tokens to ``~/.asiflow/credentials.json``.
6. Refreshes tokens automatically when they expire.

No client secret is required (public client, per OAuth 2.1 spec).
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import secrets
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

from .config import (
    AUTH_TIMEOUT,
    CALLBACK_HOST,
    CALLBACK_PORT,
    CLIENT_ID,
    CREDENTIALS_DIR,
    CREDENTIALS_PATH,
    ConnectorConfig,
    DEFAULT_AUTH_URL,
    DEFAULT_TOKEN_URL,
    REDIRECT_URI,
    SCOPES,
)

logger = logging.getLogger(__name__)


def _generate_pkce_pair() -> tuple[str, str]:
    """Generate an OAuth 2.1 PKCE code verifier and S256 challenge.

    Returns:
        Tuple of (verifier, challenge) where verifier is a 43-128 char
        random string and challenge is its SHA-256 hash, base64url-encoded.
    """
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


class _CallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler that captures the OAuth redirect callback.

    Extracts the ``code`` and ``state`` query parameters from the
    redirect URL, stores them on the server instance, and responds
    with a user-friendly HTML page.
    """

    server: _CallbackServer  # type: ignore[assignment]

    def do_GET(self) -> None:  # noqa: N802 -- required by BaseHTTPRequestHandler
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        code = params.get("code", [None])[0]
        error = params.get("error", [None])[0]
        state = params.get("state", [None])[0]

        if error:
            self.server.auth_error = error
            body = (
                "<html><body style='font-family:system-ui;text-align:center;padding:40px'>"
                "<h2 style='color:#ff4444'>Authentication Failed</h2>"
                f"<p>Error: {error}</p>"
                "<p>You can close this window.</p>"
                "</body></html>"
            )
        elif code:
            self.server.auth_code = code
            self.server.auth_state = state
            body = (
                "<html><body style='font-family:system-ui;text-align:center;padding:40px'>"
                "<h2 style='color:#00FF41'>Authenticated with ASIFlow</h2>"
                "<p>You can close this window and return to your terminal.</p>"
                "</body></html>"
            )
        else:
            self.server.auth_error = "no_code"
            body = (
                "<html><body style='font-family:system-ui;text-align:center;padding:40px'>"
                "<h2 style='color:#ff4444'>Authentication Failed</h2>"
                "<p>No authorization code received.</p>"
                "</body></html>"
            )

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

        # Signal the server to shut down after handling the callback.
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        """Suppress default HTTP access logs."""
        pass


class _CallbackServer(HTTPServer):
    """HTTPServer subclass that stores the OAuth callback result."""

    auth_code: str | None = None
    auth_state: str | None = None
    auth_error: str | None = None


class AuthManager:
    """Manages OAuth 2.1 PKCE authentication for the ASIFlow connector.

    Handles login (browser-based), token storage, automatic refresh,
    and logout.  Credentials are stored in ``~/.asiflow/credentials.json``.
    """

    def __init__(
        self,
        auth_url: str = DEFAULT_AUTH_URL,
        token_url: str = DEFAULT_TOKEN_URL,
        client_id: str = CLIENT_ID,
        redirect_uri: str = REDIRECT_URI,
        scopes: str = SCOPES,
        credentials_path: Path = CREDENTIALS_PATH,
    ) -> None:
        self._auth_url = auth_url
        self._token_url = token_url
        self._client_id = client_id
        self._redirect_uri = redirect_uri
        self._scopes = scopes
        self._credentials_path = credentials_path

    @classmethod
    def from_config(cls, config: ConnectorConfig) -> AuthManager:
        """Create an AuthManager from a ConnectorConfig."""
        return cls(
            auth_url=config.auth_url,
            token_url=config.token_url,
            client_id=config.client_id,
            redirect_uri=config.redirect_uri,
            scopes=config.scopes,
            credentials_path=config.credentials_path,
        )

    # ------------------------------------------------------------------
    # Login
    # ------------------------------------------------------------------

    def login(self) -> str:
        """Run interactive OAuth 2.1 PKCE login flow.

        Opens the user's browser to the ASIFlow authorization page,
        starts a local HTTP server to capture the redirect, exchanges
        the code for tokens, and persists them.

        Returns:
            The access token string.

        Raises:
            RuntimeError: If the authorization flow fails.
        """
        verifier, challenge = _generate_pkce_pair()
        state = secrets.token_urlsafe(32)

        # Build the authorization URL.
        params = urlencode({
            "response_type": "code",
            "client_id": self._client_id,
            "redirect_uri": self._redirect_uri,
            "scope": self._scopes,
            "state": state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        })
        auth_url = f"{self._auth_url}?{params}"

        # Start the local callback server.
        server = _CallbackServer((CALLBACK_HOST, CALLBACK_PORT), _CallbackHandler)
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()

        # Open the browser.
        logger.info("Opening browser for authentication...")
        webbrowser.open(auth_url)

        # Wait for the callback (blocks until the browser redirects back).
        server_thread.join(timeout=300)  # 5 minute timeout for user interaction.
        server.server_close()

        if server.auth_error:
            raise RuntimeError(f"Authentication failed: {server.auth_error}")

        if not server.auth_code:
            raise RuntimeError("Authentication failed: no authorization code received")

        if server.auth_state != state:
            raise RuntimeError("Authentication failed: state parameter mismatch (possible CSRF)")

        # Exchange the authorization code for tokens.
        token_data = self._exchange_code(server.auth_code, verifier)
        self._save_credentials(token_data)

        access_token: str = token_data["access_token"]
        logger.info("Authentication successful")
        return access_token

    def _exchange_code(self, code: str, verifier: str) -> dict[str, Any]:
        """Exchange an authorization code for access and refresh tokens.

        Args:
            code: The authorization code from the callback.
            verifier: The PKCE code verifier.

        Returns:
            Token response dict with ``access_token``, ``refresh_token``,
            ``expires_in``, ``token_type``, etc.
        """
        payload = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self._redirect_uri,
            "client_id": self._client_id,
            "code_verifier": verifier,
        }

        with httpx.Client(timeout=AUTH_TIMEOUT) as client:
            resp = client.post(
                self._token_url,
                data=payload,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            resp.raise_for_status()
            return resp.json()

    # ------------------------------------------------------------------
    # Token retrieval and refresh
    # ------------------------------------------------------------------

    def get_token(self) -> str | None:
        """Get a valid access token, refreshing if expired.

        Returns:
            The access token string, or None if not authenticated.
        """
        creds = self._load_credentials()
        if creds is None:
            return None

        # Check expiration: refresh if within 60 seconds of expiry.
        expires_at = creds.get("expires_at", 0)
        if time.time() >= (expires_at - 60):
            refresh_token = creds.get("refresh_token")
            if not refresh_token:
                logger.warning("Token expired and no refresh token available")
                return None
            try:
                new_creds = self._refresh_access_token(refresh_token)
                self._save_credentials(new_creds)
                return new_creds["access_token"]
            except Exception as exc:
                logger.error("Token refresh failed: %s", exc)
                return None

        return creds.get("access_token")

    def _refresh_access_token(self, refresh_token: str) -> dict[str, Any]:
        """Use a refresh token to obtain a new access token.

        Args:
            refresh_token: The refresh token from the previous grant.

        Returns:
            Token response dict.
        """
        payload = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": self._client_id,
        }

        with httpx.Client(timeout=AUTH_TIMEOUT) as client:
            resp = client.post(
                self._token_url,
                data=payload,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            resp.raise_for_status()
            return resp.json()

    # ------------------------------------------------------------------
    # Credential persistence
    # ------------------------------------------------------------------

    def _save_credentials(self, token_data: dict[str, Any]) -> None:
        """Persist token data to disk.

        Calculates ``expires_at`` from ``expires_in`` if present,
        writes to ``~/.asiflow/credentials.json`` with restricted
        file permissions (owner-only read/write).
        """
        if "expires_in" in token_data and "expires_at" not in token_data:
            token_data["expires_at"] = time.time() + token_data["expires_in"]

        token_data["saved_at"] = time.time()

        CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
        self._credentials_path.write_text(
            json.dumps(token_data, indent=2),
            encoding="utf-8",
        )
        # Restrict file permissions: owner read/write only.
        self._credentials_path.chmod(0o600)
        logger.debug("Credentials saved to %s", self._credentials_path)

    def _load_credentials(self) -> dict[str, Any] | None:
        """Load stored credentials from disk.

        Returns:
            Token data dict, or None if no credentials file exists.
        """
        if not self._credentials_path.exists():
            return None
        try:
            data = json.loads(self._credentials_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return None
            return data
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Failed to read credentials: %s", exc)
            return None

    # ------------------------------------------------------------------
    # Logout
    # ------------------------------------------------------------------

    def logout(self) -> bool:
        """Clear stored credentials.

        Returns:
            True if credentials were removed, False if none existed.
        """
        if self._credentials_path.exists():
            self._credentials_path.unlink()
            logger.info("Credentials removed from %s", self._credentials_path)
            return True
        return False

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Check authentication status.

        Returns:
            Dict with ``authenticated`` (bool), and if authenticated:
            ``expires_at`` (float), ``token_type`` (str), ``scopes`` (str).
        """
        creds = self._load_credentials()
        if creds is None:
            return {"authenticated": False}

        expires_at = creds.get("expires_at", 0)
        is_expired = time.time() >= expires_at
        has_refresh = "refresh_token" in creds

        return {
            "authenticated": True,
            "expired": is_expired,
            "can_refresh": has_refresh,
            "expires_at": expires_at,
            "token_type": creds.get("token_type", "bearer"),
            "credentials_path": str(self._credentials_path),
        }
