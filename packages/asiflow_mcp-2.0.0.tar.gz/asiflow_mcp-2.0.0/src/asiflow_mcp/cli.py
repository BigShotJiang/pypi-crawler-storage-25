"""ASIFlow MCP Connector CLI.

Provides command-line access to:
- ``asiflow-mcp auth login``   -- Authenticate with ASIFlow (opens browser)
- ``asiflow-mcp auth logout``  -- Clear stored credentials
- ``asiflow-mcp auth status``  -- Check authentication status
- ``asiflow-mcp serve``        -- Start the MCP relay server (STDIO mode)
- ``asiflow-mcp setup <ide>``  -- Generate IDE configuration
- ``asiflow-mcp tools``        -- List available ASIFlow tools
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from pathlib import Path
from typing import Any

import click

from .config import CONNECTOR_VERSION, DEFAULT_API_URL


@click.group()
@click.version_option(version=CONNECTOR_VERSION, prog_name="asiflow-mcp")
def main() -> None:
    """ASIFlow MCP Connector -- AI superpowers in your IDE.

    Connect Cursor, Claude Code, VS Code, and Windsurf to ASIFlow's
    causal reasoning, multi-agent debate, and memory capabilities.
    """
    pass


# ======================================================================
# Auth command group
# ======================================================================


@main.group()
def auth() -> None:
    """Authentication commands."""
    pass


@auth.command()
@click.option("--api-url", default=DEFAULT_API_URL, help="ASIFlow API URL")
def login(api_url: str) -> None:
    """Authenticate with ASIFlow (opens browser).

    Initiates an OAuth 2.1 PKCE flow: opens your browser to ASIFlow's
    login page, waits for the redirect, and stores the token locally
    at ~/.asiflow/credentials.json.
    """
    from .auth import AuthManager
    from .config import ConnectorConfig

    config = ConnectorConfig(api_url=api_url)
    mgr = AuthManager.from_config(config)

    try:
        mgr.login()
        click.echo("Authenticated successfully.")
        click.echo(f"Token stored at {config.credentials_path}")
    except RuntimeError as exc:
        click.echo(f"Authentication failed: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"Unexpected error: {exc}", err=True)
        sys.exit(1)


@auth.command()
def logout() -> None:
    """Clear stored credentials."""
    from .auth import AuthManager

    mgr = AuthManager()
    if mgr.logout():
        click.echo("Credentials removed.")
    else:
        click.echo("No stored credentials found.")


@auth.command()
def status() -> None:
    """Check authentication status."""
    from .auth import AuthManager

    mgr = AuthManager()
    info = mgr.status()

    if not info["authenticated"]:
        click.echo("Not authenticated.")
        click.echo("Run: asiflow-mcp auth login")
        return

    if info.get("expired"):
        if info.get("can_refresh"):
            click.echo("Token expired (will auto-refresh on next use).")
        else:
            click.echo("Token expired. Run: asiflow-mcp auth login")
    else:
        import datetime

        expires_at = info.get("expires_at", 0)
        expires_dt = datetime.datetime.fromtimestamp(expires_at, tz=datetime.timezone.utc)
        click.echo(f"Authenticated. Token expires: {expires_dt.isoformat()}")

    click.echo(f"Credentials: {info.get('credentials_path', '~/.asiflow/credentials.json')}")


# ======================================================================
# Serve command
# ======================================================================


@main.command()
@click.option("--api-url", default=DEFAULT_API_URL, help="ASIFlow API URL")
@click.option("--verbose", "-v", is_flag=True, help="Enable debug logging")
def serve(api_url: str, verbose: bool) -> None:
    """Start the MCP relay server (STDIO mode).

    Reads MCP JSON-RPC requests from stdin, relays them to ASIFlow's
    backend, and writes responses to stdout.  This is the mode that
    IDEs use when they launch the connector as a subprocess.

    Requires authentication -- run ``asiflow-mcp auth login`` first.
    """
    if verbose:
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s %(name)s %(levelname)s %(message)s",
            stream=sys.stderr,
        )

    from .auth import AuthManager
    from .connector import ASIFlowConnector

    mgr = AuthManager()
    token = mgr.get_token()

    if not token:
        click.echo("Not authenticated. Run: asiflow-mcp auth login", err=True)
        sys.exit(1)

    connector = ASIFlowConnector(api_url=api_url, token=token)

    try:
        asyncio.run(connector.run_stdio())
    except KeyboardInterrupt:
        pass


# ======================================================================
# Setup command
# ======================================================================


_IDE_CHOICES = ["cursor", "claude-code", "vscode", "windsurf"]


@main.command()
@click.argument("ide", type=click.Choice(_IDE_CHOICES))
def setup(ide: str) -> None:
    """Generate IDE configuration for the ASIFlow connector.

    Creates the appropriate MCP configuration file for your IDE so that
    ASIFlow tools are available automatically.

    Supported IDEs: cursor, claude-code, vscode, windsurf
    """
    config: dict[str, Any] = {
        "mcpServers": {
            "asiflow": {
                "command": "asiflow-mcp",
                "args": ["serve"],
            }
        }
    }
    config_json = json.dumps(config, indent=2) + "\n"

    if ide == "cursor":
        path = Path(".cursor/mcp.json")
        path.parent.mkdir(exist_ok=True)
        path.write_text(config_json, encoding="utf-8")
        click.echo(f"Written to {path}")
        click.echo("Restart Cursor to pick up the new MCP server.")

    elif ide == "claude-code":
        click.echo("Run the following command to add ASIFlow to Claude Code:\n")
        click.echo("  claude mcp add asiflow -- asiflow-mcp serve\n")
        click.echo("This registers the connector as a STDIO MCP server.")

    elif ide == "vscode":
        path = Path(".vscode/mcp.json")
        path.parent.mkdir(exist_ok=True)
        path.write_text(config_json, encoding="utf-8")
        click.echo(f"Written to {path}")
        click.echo("Reload VS Code window to pick up the new MCP server.")

    elif ide == "windsurf":
        path = Path.home() / ".codeium" / "windsurf" / "mcp_config.json"
        path.parent.mkdir(parents=True, exist_ok=True)

        # Windsurf: merge with existing config if present.
        existing: dict[str, Any] = {}
        if path.exists():
            try:
                existing = json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass

        servers = existing.get("mcpServers", {})
        servers["asiflow"] = config["mcpServers"]["asiflow"]
        existing["mcpServers"] = servers

        path.write_text(json.dumps(existing, indent=2) + "\n", encoding="utf-8")
        click.echo(f"Written to {path}")
        click.echo("Restart Windsurf to pick up the new MCP server.")


# ======================================================================
# Tools command
# ======================================================================


@main.command()
@click.option("--api-url", default=DEFAULT_API_URL, help="ASIFlow API URL")
def tools(api_url: str) -> None:
    """List available ASIFlow tools.

    Connects to the ASIFlow backend, discovers all registered tools,
    and prints their names and descriptions.
    """
    from .auth import AuthManager
    from .connector import ASIFlowConnector

    mgr = AuthManager()
    token = mgr.get_token()

    if not token:
        click.echo("Not authenticated. Run: asiflow-mcp auth login", err=True)
        sys.exit(1)

    connector = ASIFlowConnector(api_url=api_url, token=token)

    try:
        asyncio.run(connector.initialize())
    except Exception as exc:
        click.echo(f"Failed to connect to ASIFlow: {exc}", err=True)
        sys.exit(1)

    tool_list = connector.tools
    if not tool_list:
        click.echo("No tools available. Check your authentication and API URL.")
        return

    click.echo("")
    click.echo("Available ASIFlow Tools:")
    click.echo("-" * 72)

    for tool in tool_list:
        name = tool.get("name", "?")
        desc = tool.get("description", "")
        # Truncate long descriptions for display.
        if len(desc) > 55:
            desc = desc[:52] + "..."
        click.echo(f"  {name:35s} {desc}")

    click.echo("-" * 72)
    click.echo(f"  {len(tool_list)} tools available")
    click.echo("")
