"""
ASIFlow MCP Connector -- Relay MCP requests to ASIFlow's cloud backend.

This module implements a local MCP server (STDIO transport) that:
1. Accepts MCP requests from IDE clients (Cursor, Claude Code, etc.)
2. Forwards them to ASIFlow's agent-core at https://api.asiflow.ai/agent-core/mcp
3. Returns responses back to the client

All 24 ASIFlow tools are available through this connector, including:
- Causal reasoning (Pearl's 3 levels)
- Advanced reasoning (ReflAct, Graph of Thoughts, Creative Solve)
- 5-type memory with cross-agent sharing
- Multi-agent debate and consensus
- Self-improving agent recommendations
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from typing import Any

import httpx

from .config import (
    CONNECTOR_NAME,
    CONNECTOR_VERSION,
    DEFAULT_API_URL,
    DEFAULT_TIMEOUT,
    DISCOVERY_TIMEOUT,
    PROTOCOL_VERSION,
)

logger = logging.getLogger(__name__)


class ASIFlowConnector:
    """Local MCP server that relays JSON-RPC requests to ASIFlow backend.

    Operates as a STDIO MCP server: reads newline-delimited JSON-RPC from
    stdin, forwards to the ASIFlow agent-core HTTP endpoint, and writes
    responses to stdout.  The ``initialize``, ``ping``, and list methods
    are handled locally (with cached data from the initial handshake) to
    minimize latency; ``tools/call``, ``resources/read``, ``prompts/get``,
    and all other methods are relayed to the backend.
    """

    def __init__(
        self,
        api_url: str = DEFAULT_API_URL,
        token: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self._api_url = api_url
        self._token = token
        self._timeout = timeout
        self._session_id: str | None = None
        self._tools: list[dict[str, Any]] = []
        self._resources: list[dict[str, Any]] = []
        self._prompts: list[dict[str, Any]] = []
        self._initialized = False

    # ------------------------------------------------------------------
    # Initialization: handshake with ASIFlow backend
    # ------------------------------------------------------------------

    async def initialize(self) -> None:
        """Connect to the ASIFlow backend and discover tools/resources/prompts.

        Performs the MCP ``initialize`` handshake, then issues ``tools/list``,
        ``resources/list``, and ``prompts/list`` to cache all available
        capabilities.  Raises ``httpx.HTTPStatusError`` on auth/network failure.
        """
        headers = self._build_headers()

        async with httpx.AsyncClient(timeout=DISCOVERY_TIMEOUT) as client:
            # Step 1: Initialize handshake.
            init_body: dict[str, Any] = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {
                        "roots": {"listChanged": True},
                        "sampling": {},
                    },
                    "clientInfo": {
                        "name": CONNECTOR_NAME,
                        "version": CONNECTOR_VERSION,
                    },
                },
            }
            resp = await client.post(self._api_url, json=init_body, headers=headers)
            resp.raise_for_status()
            session_id = resp.headers.get("Mcp-Session-Id")
            if session_id:
                self._session_id = session_id
                headers["Mcp-Session-Id"] = session_id

            # Step 2: Send initialized notification.
            notif_body: dict[str, Any] = {
                "jsonrpc": "2.0",
                "method": "notifications/initialized",
                "params": {},
            }
            await client.post(self._api_url, json=notif_body, headers=headers)

            # Step 3: Discover tools.
            tools_body: dict[str, Any] = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/list",
                "params": {},
            }
            resp = await client.post(self._api_url, json=tools_body, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            self._tools = data.get("result", {}).get("tools", [])

            # Step 4: Discover resources.
            resources_body: dict[str, Any] = {
                "jsonrpc": "2.0",
                "id": 3,
                "method": "resources/list",
                "params": {},
            }
            resp = await client.post(self._api_url, json=resources_body, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            self._resources = data.get("result", {}).get("resources", [])

            # Step 5: Discover prompts.
            prompts_body: dict[str, Any] = {
                "jsonrpc": "2.0",
                "id": 4,
                "method": "prompts/list",
                "params": {},
            }
            resp = await client.post(self._api_url, json=prompts_body, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            self._prompts = data.get("result", {}).get("prompts", [])

        self._initialized = True
        logger.info(
            "ASIFlow connected: %d tools, %d resources, %d prompts",
            len(self._tools),
            len(self._resources),
            len(self._prompts),
        )

    # ------------------------------------------------------------------
    # Request handling
    # ------------------------------------------------------------------

    async def handle_request(self, body: dict[str, Any]) -> dict[str, Any]:
        """Handle a local MCP JSON-RPC request.

        Methods handled locally (no network round-trip):
        - ``initialize`` -- returns connector capabilities
        - ``notifications/initialized`` -- acknowledged silently
        - ``ping`` -- returns empty result
        - ``tools/list`` -- returns cached tool list
        - ``resources/list`` -- returns cached resource list
        - ``prompts/list`` -- returns cached prompt list

        All other methods (``tools/call``, ``resources/read``,
        ``prompts/get``, ``resources/subscribe``, etc.) are relayed
        to the ASIFlow backend.

        Returns:
            JSON-RPC response dict, or empty dict for notifications.
        """
        method = body.get("method", "")
        request_id = body.get("id")

        # Handle initialize locally -- the IDE is initializing *us*.
        if method == "initialize":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {
                        "tools": {"listChanged": True},
                        "resources": {"subscribe": True, "listChanged": True},
                        "prompts": {"listChanged": True},
                    },
                    "serverInfo": {
                        "name": CONNECTOR_NAME,
                        "version": CONNECTOR_VERSION,
                    },
                },
            }

        # Notifications: acknowledge silently.
        if method == "notifications/initialized":
            return {}

        # Ping: respond locally.
        if method == "ping":
            return {"jsonrpc": "2.0", "id": request_id, "result": {}}

        # List methods: return cached data (fast, no network).
        if method == "tools/list":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {"tools": self._tools},
            }
        if method == "resources/list":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {"resources": self._resources},
            }
        if method == "prompts/list":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {"prompts": self._prompts},
            }

        # Everything else: relay to ASIFlow backend.
        return await self._relay(body)

    async def _relay(self, body: dict[str, Any]) -> dict[str, Any]:
        """Forward a JSON-RPC request to the ASIFlow backend.

        Uses the session ID obtained during initialization. Raises
        ``httpx.HTTPStatusError`` if the backend returns 4xx/5xx.
        """
        headers = self._build_headers()
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(self._api_url, json=body, headers=headers)
            resp.raise_for_status()
            return resp.json()

    # ------------------------------------------------------------------
    # STDIO transport
    # ------------------------------------------------------------------

    async def run_stdio(self) -> None:
        """Run as a STDIO MCP server.

        Reads newline-delimited JSON-RPC from stdin, dispatches each
        request through ``handle_request``, and writes JSON-RPC responses
        to stdout.  Empty responses (notifications) are not written.

        This method blocks until stdin is closed (EOF).
        """
        await self.initialize()

        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)
        loop = asyncio.get_event_loop()
        await loop.connect_read_pipe(lambda: protocol, sys.stdin)

        while True:
            line = await reader.readline()
            if not line:
                break

            line_str = line.decode().strip()
            if not line_str:
                continue

            try:
                body = json.loads(line_str)
            except json.JSONDecodeError as exc:
                error_resp: dict[str, Any] = {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {
                        "code": -32700,
                        "message": f"Parse error: {exc}",
                    },
                }
                sys.stdout.write(json.dumps(error_resp) + "\n")
                sys.stdout.flush()
                continue

            try:
                result = await self.handle_request(body)
                if result:  # Skip empty responses (notifications).
                    sys.stdout.write(json.dumps(result) + "\n")
                    sys.stdout.flush()
            except httpx.HTTPStatusError as exc:
                logger.error(
                    "Backend HTTP error: %d %s",
                    exc.response.status_code,
                    exc.response.text[:200],
                )
                error_resp = {
                    "jsonrpc": "2.0",
                    "id": body.get("id"),
                    "error": {
                        "code": -32000,
                        "message": f"ASIFlow backend error: {exc.response.status_code}",
                    },
                }
                sys.stdout.write(json.dumps(error_resp) + "\n")
                sys.stdout.flush()
            except Exception as exc:
                logger.error("Connector error: %s", exc, exc_info=True)
                error_resp = {
                    "jsonrpc": "2.0",
                    "id": body.get("id"),
                    "error": {"code": -32000, "message": str(exc)},
                }
                sys.stdout.write(json.dumps(error_resp) + "\n")
                sys.stdout.flush()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_headers(self) -> dict[str, str]:
        """Build HTTP headers for backend requests."""
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": f"{CONNECTOR_NAME}/{CONNECTOR_VERSION}",
        }
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    @property
    def tools(self) -> list[dict[str, Any]]:
        """Cached tool definitions from the backend."""
        return list(self._tools)

    @property
    def resources(self) -> list[dict[str, Any]]:
        """Cached resource definitions from the backend."""
        return list(self._resources)

    @property
    def prompts(self) -> list[dict[str, Any]]:
        """Cached prompt definitions from the backend."""
        return list(self._prompts)

    @property
    def is_initialized(self) -> bool:
        """Whether the connector has completed the handshake."""
        return self._initialized
