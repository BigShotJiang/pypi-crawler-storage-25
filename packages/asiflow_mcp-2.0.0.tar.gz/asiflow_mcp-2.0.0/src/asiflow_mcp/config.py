"""Configuration for ASIFlow MCP Connector.

Centralizes all configuration constants and provides a typed dataclass
for runtime configuration. Environment variables take precedence over
defaults when present.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

# Default URLs targeting ASIFlow production.
DEFAULT_API_URL = "https://api.asiflow.ai/agent-core/mcp"
DEFAULT_AUTH_URL = "https://api.asiflow.ai/mcp/oauth/authorize"
DEFAULT_TOKEN_URL = "https://api.asiflow.ai/mcp/oauth/token"
DEFAULT_REGISTER_URL = "https://api.asiflow.ai/mcp/oauth/register"

# OAuth 2.1 PKCE constants.
CLIENT_ID = "asiflow-mcp-connector"
REDIRECT_URI = "http://localhost:9876/callback"
SCOPES = "tools:read tools:execute resources:read prompts:read"

# Local credential storage.
CREDENTIALS_DIR = Path.home() / ".asiflow"
CREDENTIALS_PATH = CREDENTIALS_DIR / "credentials.json"

# Connector identity.
CONNECTOR_NAME = "asiflow-mcp-connector"
CONNECTOR_VERSION = "2.0.0"
PROTOCOL_VERSION = "2025-11-25"

# Timeouts (seconds).
DEFAULT_TIMEOUT = 120.0
AUTH_TIMEOUT = 30.0
DISCOVERY_TIMEOUT = 30.0

# Local callback server for OAuth.
CALLBACK_HOST = "localhost"
CALLBACK_PORT = 9876


@dataclass(frozen=True)
class ConnectorConfig:
    """Typed configuration for the ASIFlow MCP Connector.

    Reads from environment variables where available, falling back to
    production defaults. All URLs and credentials are immutable once set.
    """

    api_url: str = field(
        default_factory=lambda: os.environ.get("ASIFLOW_API_URL", DEFAULT_API_URL)
    )
    auth_url: str = field(
        default_factory=lambda: os.environ.get("ASIFLOW_AUTH_URL", DEFAULT_AUTH_URL)
    )
    token_url: str = field(
        default_factory=lambda: os.environ.get("ASIFLOW_TOKEN_URL", DEFAULT_TOKEN_URL)
    )
    register_url: str = field(
        default_factory=lambda: os.environ.get("ASIFLOW_REGISTER_URL", DEFAULT_REGISTER_URL)
    )
    client_id: str = field(
        default_factory=lambda: os.environ.get("ASIFLOW_CLIENT_ID", CLIENT_ID)
    )
    redirect_uri: str = field(
        default_factory=lambda: os.environ.get("ASIFLOW_REDIRECT_URI", REDIRECT_URI)
    )
    scopes: str = field(
        default_factory=lambda: os.environ.get("ASIFLOW_SCOPES", SCOPES)
    )
    timeout: float = field(
        default_factory=lambda: float(os.environ.get("ASIFLOW_TIMEOUT", str(DEFAULT_TIMEOUT)))
    )
    credentials_path: Path = field(default_factory=lambda: CREDENTIALS_PATH)
