"""
ASIFlow MCP Connector -- AI superpowers in your IDE.

Two modes of operation:

1. **Connector** (primary): Relay MCP requests from IDE clients
   (Cursor, Claude Code, VS Code, Windsurf) to ASIFlow's backend::

       pip install asiflow-mcp
       asiflow-mcp auth login
       asiflow-mcp setup cursor

2. **Server Builder** (advanced): Build custom MCP-compatible servers::

       from asiflow_mcp import MCPServer, create_mcp_app

       server = MCPServer(name="my-server", version="1.0.0")

       @server.tool("greet", description="Greet someone")
       async def greet(name: str) -> str:
           return f"Hello, {name}!"

       app = create_mcp_app(server)
"""

from .auth import AuthManager
from .config import ConnectorConfig
from .connector import ASIFlowConnector
from .models import (
    MCPPromptArgument,
    MCPPromptDef,
    MCPResourceDef,
    MCPToolAnnotations,
    MCPToolDef,
)

# Server builder requires the [server] extra (fastapi, uvicorn).
# Lazy-import so that `pip install asiflow-mcp` (connector-only) works.
try:
    from .server import MCPServer, create_mcp_app
except ImportError:
    MCPServer = None  # type: ignore[assignment,misc]
    create_mcp_app = None  # type: ignore[assignment]

__all__ = [
    # Connector (primary API).
    "ASIFlowConnector",
    "AuthManager",
    "ConnectorConfig",
    # Server builder (advanced API -- requires `pip install asiflow-mcp[server]`).
    "MCPServer",
    "create_mcp_app",
    # Models (shared).
    "MCPToolDef",
    "MCPToolAnnotations",
    "MCPResourceDef",
    "MCPPromptDef",
    "MCPPromptArgument",
]

__version__ = "2.0.0"
