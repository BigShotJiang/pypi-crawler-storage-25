"""
ASIFlow MCP Server Builder -- Build MCP-compatible servers easily.

Provides a decorator-based API for registering tools, resources, and prompts,
and serves them over the MCP 2025-11-25 Streamable HTTP transport via FastAPI.

Usage::

    from asiflow_mcp import MCPServer, create_mcp_app

    server = MCPServer(name="my-server", version="1.0.0")

    @server.tool("greet", description="Greet someone")
    async def greet(name: str) -> str:
        return f"Hello, {name}!"

    app = create_mcp_app(server)
    # Run: uvicorn app:app --port 3001
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
import sys
import time
import types
import uuid
from typing import Any, Callable, Coroutine, Union, get_type_hints

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse

from .models import (
    MCPPromptArgument,
    MCPPromptDef,
    MCPResourceDef,
    MCPToolAnnotations,
    MCPToolDef,
)

logger = logging.getLogger(__name__)

# Python type -> JSON Schema type mapping.
_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}

# Session timeout: 30 minutes.
_SESSION_TIMEOUT_SECONDS: int = 30 * 60


def _python_type_to_json_schema(annotation: Any) -> dict[str, Any]:
    """Convert a Python type annotation to a JSON Schema fragment.

    Handles basic types (str, int, float, bool), list[T], dict[K,V],
    Optional[T], unions, and literal/enum types.  Falls back to
    ``{"type": "string"}`` for unrecognized annotations.
    """
    if annotation is inspect.Parameter.empty or annotation is Any:
        return {"type": "string"}

    origin = getattr(annotation, "__origin__", None)

    # Python 3.10+ union syntax: int | str, Optional via X | None
    if sys.version_info >= (3, 10) and isinstance(annotation, types.UnionType):
        args = annotation.__args__
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return _python_type_to_json_schema(non_none[0])
        return {"type": "string"}

    # typing.Union / typing.Optional (all Python versions)
    if origin is Union:
        args = annotation.__args__
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return _python_type_to_json_schema(non_none[0])
        return {"type": "string"}

    # list[T]
    if origin is list:
        item_args = getattr(annotation, "__args__", None)
        items_schema: dict[str, Any] = {}
        if item_args:
            items_schema = _python_type_to_json_schema(item_args[0])
        return {"type": "array", "items": items_schema}

    # dict[K, V]
    if origin is dict:
        return {"type": "object"}

    # Direct type match.
    json_type = _TYPE_MAP.get(annotation)
    if json_type:
        return {"type": json_type}

    return {"type": "string"}


def _build_input_schema(func: Callable[..., Any]) -> dict[str, Any]:
    """Build a JSON Schema ``inputSchema`` from a function's signature.

    Inspects parameter names, type annotations, and default values to
    produce a schema compatible with the MCP ``tools/call`` protocol.
    """
    sig = inspect.signature(func)
    try:
        hints = get_type_hints(func)
    except Exception:
        hints = {}

    properties: dict[str, Any] = {}
    required: list[str] = []

    for param_name, param in sig.parameters.items():
        if param_name in ("self", "cls"):
            continue

        annotation = hints.get(param_name, param.annotation)
        prop_schema = _python_type_to_json_schema(annotation)

        # Incorporate default value info.
        if param.default is not inspect.Parameter.empty:
            prop_schema["default"] = param.default
        else:
            required.append(param_name)

        properties[param_name] = prop_schema

    schema: dict[str, Any] = {
        "type": "object",
        "properties": properties,
    }
    if required:
        schema["required"] = required
    return schema


class _MCPSession:
    """State for a single MCP Streamable HTTP session."""

    __slots__ = (
        "session_id", "created_at", "last_active", "initialized",
        "sse_queue", "event_counter", "resource_subscriptions",
    )

    def __init__(self, session_id: str) -> None:
        self.session_id: str = session_id
        self.created_at: float = time.monotonic()
        self.last_active: float = time.monotonic()
        self.initialized: bool = False
        self.sse_queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()
        self.event_counter: int = 0
        self.resource_subscriptions: set[str] = set()

    @property
    def is_expired(self) -> bool:
        return (time.monotonic() - self.last_active) > _SESSION_TIMEOUT_SECONDS

    def touch(self) -> None:
        self.last_active = time.monotonic()

    def next_event_id(self) -> str:
        self.event_counter += 1
        return str(self.event_counter)


class MCPServer:
    """MCP server with decorator-based registration for tools, resources, and prompts.

    Implements the MCP 2025-11-25 JSON-RPC 2.0 protocol including session
    management and Streamable HTTP transport.

    Example::

        server = MCPServer(name="demo", version="1.0.0")

        @server.tool("echo", description="Echo back the input")
        async def echo(text: str) -> str:
            return text

        @server.resource("demo://status", name="Status")
        async def status() -> dict:
            return {"ok": True}

        @server.prompt("summarize", description="Summarize text")
        async def summarize(text: str) -> list[dict]:
            return [{"role": "user", "content": {"type": "text", "text": f"Summarize: {text}"}}]
    """

    PROTOCOL_VERSION = "2025-11-25"

    def __init__(self, name: str, version: str = "1.0.0") -> None:
        self.name: str = name
        self.version: str = version
        self._tools: dict[str, MCPToolDef] = {}
        self._resources: dict[str, MCPResourceDef] = {}
        self._prompts: dict[str, MCPPromptDef] = {}
        self._sessions: dict[str, _MCPSession] = {}

    # ------------------------------------------------------------------
    # Decorator: tool
    # ------------------------------------------------------------------

    def tool(
        self,
        name: str,
        *,
        description: str = "",
        annotations: dict[str, Any] | MCPToolAnnotations | None = None,
    ) -> Callable[[Callable[..., Coroutine[Any, Any, Any]]], Callable[..., Coroutine[Any, Any, Any]]]:
        """Register an async function as an MCP tool.

        The tool's ``inputSchema`` is auto-generated from the function's
        type hints and default values.

        Args:
            name: Unique tool name exposed to MCP clients.
            description: Human-readable description of what the tool does.
            annotations: Optional MCP 2025-11-25 tool behavior annotations
                         (dict or MCPToolAnnotations instance).

        Returns:
            Decorator that registers the function and returns it unchanged.
        """
        def decorator(func: Callable[..., Coroutine[Any, Any, Any]]) -> Callable[..., Coroutine[Any, Any, Any]]:
            tool_annotations: MCPToolAnnotations | None = None
            if isinstance(annotations, dict):
                tool_annotations = MCPToolAnnotations(**annotations)
            elif isinstance(annotations, MCPToolAnnotations):
                tool_annotations = annotations

            tool_def = MCPToolDef(
                name=name,
                description=description or func.__doc__ or "",
                inputSchema=_build_input_schema(func),
                annotations=tool_annotations,
                handler=func,
            )
            self._tools[name] = tool_def
            return func
        return decorator

    # ------------------------------------------------------------------
    # Decorator: resource
    # ------------------------------------------------------------------

    def resource(
        self,
        uri: str,
        *,
        name: str = "",
        description: str = "",
        mime_type: str = "application/json",
    ) -> Callable[[Callable[..., Coroutine[Any, Any, Any]]], Callable[..., Coroutine[Any, Any, Any]]]:
        """Register an async function as an MCP resource.

        The handler is called when a client issues ``resources/read`` for
        the given URI. It should return a JSON-serializable value.

        Args:
            uri: The resource URI (e.g. ``"myapp://config"``).
            name: Human-readable resource name.
            description: Human-readable description.
            mime_type: MIME type of the resource content.

        Returns:
            Decorator that registers the function and returns it unchanged.
        """
        def decorator(func: Callable[..., Coroutine[Any, Any, Any]]) -> Callable[..., Coroutine[Any, Any, Any]]:
            resource_def = MCPResourceDef(
                uri=uri,
                name=name or func.__name__,
                description=description or func.__doc__ or "",
                mimeType=mime_type,
                handler=func,
            )
            self._resources[uri] = resource_def
            return func
        return decorator

    # ------------------------------------------------------------------
    # Decorator: prompt
    # ------------------------------------------------------------------

    def prompt(
        self,
        name: str,
        *,
        description: str = "",
        arguments: list[dict[str, Any]] | list[MCPPromptArgument] | None = None,
    ) -> Callable[[Callable[..., Coroutine[Any, Any, Any]]], Callable[..., Coroutine[Any, Any, Any]]]:
        """Register an async function as an MCP prompt template.

        The handler receives keyword arguments matching the prompt's declared
        arguments and must return a list of MCP message dicts::

            [{"role": "user", "content": {"type": "text", "text": "..."}}]

        Args:
            name: Unique prompt name.
            description: Human-readable description.
            arguments: List of prompt arguments (dicts or MCPPromptArgument).
                       If omitted, arguments are inferred from the function signature.

        Returns:
            Decorator that registers the function and returns it unchanged.
        """
        def decorator(func: Callable[..., Coroutine[Any, Any, Any]]) -> Callable[..., Coroutine[Any, Any, Any]]:
            prompt_args: list[MCPPromptArgument] = []

            if arguments is not None:
                for arg in arguments:
                    if isinstance(arg, MCPPromptArgument):
                        prompt_args.append(arg)
                    elif isinstance(arg, dict):
                        prompt_args.append(MCPPromptArgument(**arg))
            else:
                # Auto-infer arguments from the function signature.
                sig = inspect.signature(func)
                for param_name, param in sig.parameters.items():
                    if param_name in ("self", "cls"):
                        continue
                    prompt_args.append(MCPPromptArgument(
                        name=param_name,
                        description=param_name.replace("_", " "),
                        required=param.default is inspect.Parameter.empty,
                    ))

            prompt_def = MCPPromptDef(
                name=name,
                description=description or func.__doc__ or "",
                arguments=prompt_args,
                handler=func,
            )
            self._prompts[name] = prompt_def
            return func
        return decorator

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    def get_tools(self) -> list[dict[str, Any]]:
        """Return all tools in MCP protocol wire format."""
        return [t.to_protocol() for t in self._tools.values()]

    def get_resources(self) -> list[dict[str, Any]]:
        """Return all resources in MCP protocol wire format."""
        return [r.to_protocol() for r in self._resources.values()]

    def get_prompts(self) -> list[dict[str, Any]]:
        """Return all prompts in MCP protocol wire format."""
        return [p.to_protocol() for p in self._prompts.values()]

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    def _create_session(self) -> _MCPSession:
        session_id = str(uuid.uuid4())
        session = _MCPSession(session_id)
        self._sessions[session_id] = session
        logger.info("MCP session created: %s", session_id)
        return session

    def _get_session(self, session_id: str) -> _MCPSession | None:
        session = self._sessions.get(session_id)
        if session is None:
            return None
        if session.is_expired:
            logger.info("MCP session expired: %s", session_id)
            self._sessions.pop(session_id, None)
            return None
        session.touch()
        return session

    def purge_expired_sessions(self) -> int:
        """Remove all expired sessions. Returns the number purged."""
        expired = [sid for sid, s in self._sessions.items() if s.is_expired]
        for sid in expired:
            self._sessions.pop(sid, None)
        if expired:
            logger.info("Purged %d expired MCP sessions", len(expired))
        return len(expired)

    # ------------------------------------------------------------------
    # Resource subscription notifications
    # ------------------------------------------------------------------

    async def notify_resource_updated(self, uri: str) -> int:
        """Notify all subscribed sessions that a resource has been updated.

        Call this from your application code when a resource's content
        changes, so connected clients can refresh.

        Returns the number of sessions notified.
        """
        notification: dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": "notifications/resources/updated",
            "params": {"uri": uri},
        }
        notified = 0
        for session in list(self._sessions.values()):
            if session.is_expired:
                continue
            if uri in session.resource_subscriptions:
                await session.sse_queue.put(notification)
                notified += 1
        if notified:
            logger.info("Notified %d session(s) of resource update: %s", notified, uri)
        return notified

    # ------------------------------------------------------------------
    # JSON-RPC 2.0 request handling
    # ------------------------------------------------------------------

    async def handle_request(self, body: dict[str, Any], session: _MCPSession | None = None) -> dict[str, Any]:
        """Handle a single JSON-RPC 2.0 MCP request.

        Routes the request to the appropriate handler based on the ``method``
        field. Returns the JSON-RPC response dict.

        This is the core dispatch method. You normally do not call it directly;
        ``create_mcp_app`` wires it to FastAPI endpoints automatically.
        """
        method: str = body.get("method", "")
        request_id = body.get("id")
        params: dict[str, Any] = body.get("params", {})

        try:
            if method == "initialize":
                new_session = self._create_session()
                new_session.initialized = True
                result = self._handle_initialize(params)
                # Return the session ID as a custom field so the transport layer
                # can set the Mcp-Session-Id header.
                response = {"jsonrpc": "2.0", "id": request_id, "result": result}
                response["_session_id"] = new_session.session_id
                return response

            elif method == "notifications/initialized":
                # Notification per JSON-RPC 2.0: no response required.
                # Return empty dict; the transport layer will skip sending it.
                return {}

            elif method == "tools/list":
                return {"jsonrpc": "2.0", "id": request_id, "result": {"tools": self.get_tools()}}

            elif method == "tools/call":
                result = await self._handle_tool_call(params)
                return {"jsonrpc": "2.0", "id": request_id, "result": result}

            elif method == "resources/list":
                return {"jsonrpc": "2.0", "id": request_id, "result": {"resources": self.get_resources()}}

            elif method == "resources/read":
                result = await self._handle_resource_read(params)
                return {"jsonrpc": "2.0", "id": request_id, "result": result}

            elif method == "resources/subscribe":
                result = self._handle_resource_subscribe(params, session)
                return {"jsonrpc": "2.0", "id": request_id, "result": result}

            elif method == "resources/unsubscribe":
                result = self._handle_resource_unsubscribe(params, session)
                return {"jsonrpc": "2.0", "id": request_id, "result": result}

            elif method == "prompts/list":
                return {"jsonrpc": "2.0", "id": request_id, "result": {"prompts": self.get_prompts()}}

            elif method == "prompts/get":
                result = await self._handle_prompt_get(params)
                return {"jsonrpc": "2.0", "id": request_id, "result": result}

            elif method == "ping":
                return {"jsonrpc": "2.0", "id": request_id, "result": {}}

            else:
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {"code": -32601, "message": f"Method not found: {method}"},
                }

        except Exception as exc:
            logger.error("MCP request error (%s): %s", method, exc, exc_info=True)
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {"code": -32000, "message": str(exc)},
            }

    async def handle_batch(self, batch: list[dict[str, Any]], session: _MCPSession | None = None) -> list[dict[str, Any]]:
        """Handle a JSON-RPC 2.0 batch request (array of requests).

        Returns a list of JSON-RPC response dicts.
        """
        responses: list[dict[str, Any]] = []
        for item in batch:
            response = await self.handle_request(item, session=session)
            responses.append(response)
            # If the item created a session, use it for subsequent requests.
            if "_session_id" in response and session is None:
                session = self._get_session(response["_session_id"])
        return responses

    # ------------------------------------------------------------------
    # Internal handlers
    # ------------------------------------------------------------------

    def _handle_initialize(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle the ``initialize`` method."""
        capabilities: dict[str, Any] = {}
        if self._tools:
            capabilities["tools"] = {"listChanged": True}
        if self._resources:
            capabilities["resources"] = {"subscribe": True, "listChanged": True}
        if self._prompts:
            capabilities["prompts"] = {"listChanged": True}

        return {
            "protocolVersion": self.PROTOCOL_VERSION,
            "capabilities": capabilities,
            "serverInfo": {"name": self.name, "version": self.version},
        }

    async def _handle_tool_call(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle ``tools/call``: dispatch to the registered tool handler."""
        tool_name: str = params.get("name", "")
        arguments: dict[str, Any] = params.get("arguments", {})

        tool_def = self._tools.get(tool_name)
        if tool_def is None:
            return {
                "content": [{"type": "text", "text": f"Unknown tool: {tool_name}"}],
                "isError": True,
            }

        try:
            result = await tool_def.handler(**arguments)
            return self._format_tool_result(result)
        except TypeError as exc:
            logger.error("Tool '%s' argument error: %s", tool_name, exc)
            return {
                "content": [{"type": "text", "text": f"Invalid arguments for tool '{tool_name}': {exc}"}],
                "isError": True,
            }
        except Exception as exc:
            logger.error("Tool '%s' execution error: %s", tool_name, exc, exc_info=True)
            return {
                "content": [{"type": "text", "text": f"Tool '{tool_name}' failed: {exc}"}],
                "isError": True,
            }

    @staticmethod
    def _format_tool_result(result: Any) -> dict[str, Any]:
        """Normalize a tool handler's return value into MCP content format."""
        if isinstance(result, dict) and "content" in result:
            # Already MCP-formatted.
            return result
        if isinstance(result, str):
            return {"content": [{"type": "text", "text": result}], "isError": False}
        if isinstance(result, (int, float, bool)):
            return {"content": [{"type": "text", "text": str(result)}], "isError": False}
        if isinstance(result, (list, dict)):
            return {"content": [{"type": "text", "text": json.dumps(result, default=str)}], "isError": False}
        return {"content": [{"type": "text", "text": str(result)}], "isError": False}

    async def _handle_resource_read(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle ``resources/read``: dispatch to the registered resource handler."""
        uri: str = params.get("uri", "")

        resource_def = self._resources.get(uri)
        if resource_def is None:
            return {
                "contents": [{
                    "uri": uri,
                    "mimeType": "application/json",
                    "text": json.dumps({"error": f"Unknown resource: {uri}"}),
                }],
            }

        try:
            result = await resource_def.handler()
            text = result if isinstance(result, str) else json.dumps(result, default=str)
            return {
                "contents": [{
                    "uri": uri,
                    "mimeType": resource_def.mimeType,
                    "text": text,
                }],
            }
        except Exception as exc:
            logger.error("Resource '%s' read error: %s", uri, exc, exc_info=True)
            return {
                "contents": [{
                    "uri": uri,
                    "mimeType": "application/json",
                    "text": json.dumps({"error": str(exc)}),
                }],
            }

    def _handle_resource_subscribe(self, params: dict[str, Any], session: _MCPSession | None) -> dict[str, Any]:
        """Handle ``resources/subscribe``."""
        uri: str = params.get("uri", "")
        if not uri:
            raise ValueError("Missing required parameter: uri")
        if uri not in self._resources:
            raise ValueError(f"Cannot subscribe to unknown resource: {uri}")
        if session is None:
            raise ValueError("resources/subscribe requires an active session (Mcp-Session-Id header)")
        session.resource_subscriptions.add(uri)
        logger.info("Session %s subscribed to resource %s", session.session_id, uri)
        return {}

    def _handle_resource_unsubscribe(self, params: dict[str, Any], session: _MCPSession | None) -> dict[str, Any]:
        """Handle ``resources/unsubscribe``."""
        uri: str = params.get("uri", "")
        if not uri:
            raise ValueError("Missing required parameter: uri")
        if session is None:
            raise ValueError("resources/unsubscribe requires an active session (Mcp-Session-Id header)")
        session.resource_subscriptions.discard(uri)
        logger.info("Session %s unsubscribed from resource %s", session.session_id, uri)
        return {}

    async def _handle_prompt_get(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle ``prompts/get``: render a prompt template with the given arguments."""
        prompt_name: str = params.get("name", "")
        arguments: dict[str, Any] = params.get("arguments", {})

        prompt_def = self._prompts.get(prompt_name)
        if prompt_def is None:
            raise ValueError(f"Unknown prompt: {prompt_name}")

        try:
            messages = await prompt_def.handler(**arguments)
            # Normalize: if handler returns a plain string, wrap it.
            if isinstance(messages, str):
                messages = [{"role": "user", "content": {"type": "text", "text": messages}}]
            elif isinstance(messages, list):
                normalized: list[dict[str, Any]] = []
                for msg in messages:
                    if isinstance(msg, str):
                        normalized.append({"role": "user", "content": {"type": "text", "text": msg}})
                    elif isinstance(msg, dict):
                        # Ensure content is in the correct format.
                        if "content" in msg and isinstance(msg["content"], str):
                            msg = {**msg, "content": {"type": "text", "text": msg["content"]}}
                        normalized.append(msg)
                messages = normalized

            return {
                "description": prompt_def.description,
                "messages": messages,
            }
        except Exception as exc:
            logger.error("Prompt '%s' error: %s", prompt_name, exc, exc_info=True)
            raise ValueError(f"Prompt '{prompt_name}' failed: {exc}") from exc


# ------------------------------------------------------------------
# SSE stream generator
# ------------------------------------------------------------------


async def _sse_stream(session: _MCPSession) -> Any:
    """Generate SSE events from a session's queue."""
    try:
        while True:
            message = await session.sse_queue.get()
            if message is None:
                break
            event_id = session.next_event_id()
            data = json.dumps(message)
            yield f"id: {event_id}\ndata: {data}\n\n"
    except asyncio.CancelledError:
        pass


# ------------------------------------------------------------------
# FastAPI app factory
# ------------------------------------------------------------------


def create_mcp_app(
    server: MCPServer,
    *,
    prefix: str = "/mcp",
    cors_origins: list[str] | None = None,
) -> FastAPI:
    """Create a FastAPI application that serves the MCP protocol.

    The returned app exposes:
      - ``POST {prefix}``       -- JSON-RPC 2.0 endpoint (Streamable HTTP)
      - ``GET  {prefix}``       -- SSE stream for server-initiated messages
      - ``GET  {prefix}/tools`` -- Convenience: list tools as plain JSON
      - ``GET  /health``        -- Health check

    Args:
        server: The MCPServer instance with registered tools/resources/prompts.
        prefix: URL prefix for MCP endpoints (default ``"/mcp"``).
        cors_origins: Allowed CORS origins. Defaults to ``["*"]`` for dev.

    Returns:
        A FastAPI application ready to run with ``uvicorn``.
    """
    app = FastAPI(
        title=f"MCP Server: {server.name}",
        version=server.version,
        description=f"MCP 2025-11-25 Streamable HTTP server for {server.name}",
    )

    # CORS middleware.
    origins = cors_origins if cors_origins is not None else ["*"]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["*"],
        expose_headers=["Mcp-Session-Id"],
    )

    # ---- POST: JSON-RPC endpoint -------------------------------------------

    @app.post(prefix)
    async def mcp_endpoint(request: Request) -> JSONResponse:
        """Handle MCP JSON-RPC 2.0 requests over Streamable HTTP."""
        body = await request.json()

        # Resolve session from header.
        session_id = request.headers.get("mcp-session-id")
        session = server._get_session(session_id) if session_id else None

        # Batch request support.
        if isinstance(body, list):
            responses = await server.handle_batch(body, session=session)
            # Extract session ID from first initialize response.
            new_session_id: str | None = None
            for resp in responses:
                if "_session_id" in resp:
                    new_session_id = resp.pop("_session_id")
                    break
            headers: dict[str, str] = {}
            if new_session_id:
                headers["Mcp-Session-Id"] = new_session_id
            return JSONResponse(content=responses, headers=headers)

        response = await server.handle_request(body, session=session)

        # Extract internal session ID marker.
        new_session_id = response.pop("_session_id", None)
        headers = {}
        if new_session_id:
            headers["Mcp-Session-Id"] = new_session_id

        return JSONResponse(content=response, headers=headers)

    # ---- GET: SSE stream ---------------------------------------------------

    @app.get(prefix)
    async def mcp_sse_stream(request: Request) -> StreamingResponse:
        """SSE stream for server-initiated messages (notifications, sampling requests)."""
        session_id = request.headers.get("mcp-session-id")
        if not session_id:
            return JSONResponse(
                status_code=400,
                content={"error": "Mcp-Session-Id header is required for SSE stream"},
            )

        session = server._get_session(session_id)
        if session is None:
            return JSONResponse(
                status_code=404,
                content={"error": f"Session not found or expired: {session_id}"},
            )

        return StreamingResponse(
            _sse_stream(session),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Mcp-Session-Id": session_id,
            },
        )

    # ---- Convenience: list tools -------------------------------------------

    @app.get(f"{prefix}/tools")
    async def list_tools() -> JSONResponse:
        """List all registered MCP tools (convenience endpoint)."""
        return JSONResponse(content={"tools": server.get_tools()})

    # ---- Convenience: list resources ----------------------------------------

    @app.get(f"{prefix}/resources")
    async def list_resources() -> JSONResponse:
        """List all registered MCP resources (convenience endpoint)."""
        return JSONResponse(content={"resources": server.get_resources()})

    # ---- Convenience: list prompts ------------------------------------------

    @app.get(f"{prefix}/prompts")
    async def list_prompts() -> JSONResponse:
        """List all registered MCP prompts (convenience endpoint)."""
        return JSONResponse(content={"prompts": server.get_prompts()})

    # ---- Health check -------------------------------------------------------

    @app.get("/health")
    async def health() -> dict[str, Any]:
        """Health check endpoint."""
        return {
            "status": "healthy",
            "server": server.name,
            "version": server.version,
            "protocol": server.PROTOCOL_VERSION,
            "tools": len(server._tools),
            "resources": len(server._resources),
            "prompts": len(server._prompts),
            "active_sessions": len(server._sessions),
        }

    return app
