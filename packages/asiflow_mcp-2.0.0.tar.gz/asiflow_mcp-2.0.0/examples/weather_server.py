"""
Weather MCP server example.

A more complete example demonstrating multiple tools with annotations,
multiple resources, and a prompt template.

Run:
    cd examples
    pip install -e ..
    uvicorn weather_server:app --port 3002 --reload

Connect from Cursor:
    Add to .cursor/mcp.json:
    {
      "mcpServers": {
        "weather": {
          "url": "http://localhost:3002/mcp"
        }
      }
    }
"""

from __future__ import annotations

import random
from datetime import datetime, timezone

from asiflow_mcp import MCPServer, MCPToolAnnotations, create_mcp_app

server = MCPServer(name="weather-service", version="1.0.0")

# ---------------------------------------------------------------------------
# In-memory weather data (simulated)
# ---------------------------------------------------------------------------

CITIES: dict[str, dict[str, float]] = {
    "new_york": {"lat": 40.7128, "lon": -74.0060},
    "london": {"lat": 51.5074, "lon": -0.1278},
    "tokyo": {"lat": 35.6762, "lon": 139.6503},
    "sydney": {"lat": -33.8688, "lon": 151.2093},
    "paris": {"lat": 48.8566, "lon": 2.3522},
    "berlin": {"lat": 52.5200, "lon": 13.4050},
    "san_francisco": {"lat": 37.7749, "lon": -122.4194},
    "toronto": {"lat": 43.6532, "lon": -79.3832},
}

CONDITIONS = ["sunny", "partly_cloudy", "cloudy", "rain", "thunderstorm", "snow", "fog"]

ALERTS: list[dict[str, str]] = [
    {"id": "alert-001", "city": "tokyo", "severity": "warning", "message": "Typhoon approaching"},
    {"id": "alert-002", "city": "london", "severity": "advisory", "message": "Dense fog expected"},
]


def _generate_weather(city: str) -> dict:
    """Generate simulated weather data for a city."""
    seed = hash(city + datetime.now(timezone.utc).strftime("%Y-%m-%d-%H"))
    rng = random.Random(seed)
    return {
        "city": city,
        "coordinates": CITIES.get(city, {"lat": 0.0, "lon": 0.0}),
        "temperature_c": round(rng.uniform(-10, 40), 1),
        "humidity_pct": rng.randint(20, 95),
        "wind_speed_kmh": round(rng.uniform(0, 80), 1),
        "condition": rng.choice(CONDITIONS),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@server.tool(
    "get_weather",
    description="Get current weather for a city",
    annotations=MCPToolAnnotations(
        title="Get Weather",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    ),
)
async def get_weather(city: str) -> dict:
    """Fetch current weather conditions for a given city.

    The city name should be lowercase with underscores (e.g. 'new_york').
    """
    city_lower = city.lower().replace(" ", "_")
    if city_lower not in CITIES:
        available = ", ".join(sorted(CITIES.keys()))
        return {"error": f"Unknown city: {city}. Available: {available}"}
    return _generate_weather(city_lower)


@server.tool(
    "get_forecast",
    description="Get a multi-day weather forecast",
    annotations={"title": "Get Forecast", "readOnlyHint": True, "idempotentHint": True},
)
async def get_forecast(city: str, days: int = 3) -> list[dict]:
    """Return a weather forecast for the next N days."""
    city_lower = city.lower().replace(" ", "_")
    if city_lower not in CITIES:
        available = ", ".join(sorted(CITIES.keys()))
        return [{"error": f"Unknown city: {city}. Available: {available}"}]

    days = max(1, min(days, 7))
    forecasts = []
    rng = random.Random(hash(city_lower))
    for day_offset in range(days):
        forecasts.append({
            "day": day_offset,
            "high_c": round(rng.uniform(5, 38), 1),
            "low_c": round(rng.uniform(-5, 20), 1),
            "condition": rng.choice(CONDITIONS),
            "precipitation_pct": rng.randint(0, 100),
        })
    return forecasts


@server.tool(
    "compare_weather",
    description="Compare weather between two cities",
    annotations={"title": "Compare Weather", "readOnlyHint": True, "idempotentHint": True},
)
async def compare_weather(city_a: str, city_b: str) -> dict:
    """Side-by-side weather comparison for two cities."""
    a = city_a.lower().replace(" ", "_")
    b = city_b.lower().replace(" ", "_")
    if a not in CITIES or b not in CITIES:
        return {"error": "Both cities must be valid. Available: " + ", ".join(sorted(CITIES.keys()))}

    weather_a = _generate_weather(a)
    weather_b = _generate_weather(b)
    return {
        "city_a": weather_a,
        "city_b": weather_b,
        "temperature_difference_c": round(weather_a["temperature_c"] - weather_b["temperature_c"], 1),
    }


@server.tool(
    "set_alert",
    description="Create a weather alert for a city",
    annotations=MCPToolAnnotations(
        title="Set Weather Alert",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=False,
    ),
)
async def set_alert(city: str, severity: str = "advisory", message: str = "") -> dict:
    """Create a weather alert. Severity must be 'advisory', 'warning', or 'emergency'."""
    valid_severities = ("advisory", "warning", "emergency")
    if severity not in valid_severities:
        return {"error": f"Invalid severity. Must be one of: {', '.join(valid_severities)}"}

    alert_id = f"alert-{random.randint(1000, 9999)}"
    alert = {
        "id": alert_id,
        "city": city.lower().replace(" ", "_"),
        "severity": severity,
        "message": message or f"Weather alert for {city}",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    ALERTS.append(alert)
    return alert


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------


@server.resource(
    "weather://cities",
    name="Supported Cities",
    description="List of all cities with available weather data",
)
async def supported_cities() -> dict:
    """Return the list of supported cities and their coordinates."""
    return {
        "cities": [
            {"name": name, **coords}
            for name, coords in sorted(CITIES.items())
        ],
        "total": len(CITIES),
    }


@server.resource(
    "weather://alerts",
    name="Active Alerts",
    description="All currently active weather alerts",
)
async def active_alerts() -> dict:
    """Return all active weather alerts."""
    return {"alerts": ALERTS, "total": len(ALERTS)}


@server.resource(
    "weather://conditions",
    name="Condition Types",
    description="All possible weather condition types",
)
async def condition_types() -> dict:
    """Return the list of possible weather conditions."""
    return {"conditions": CONDITIONS}


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------


@server.prompt(
    "weather_report",
    description="Generate a natural-language weather report for a city",
    arguments=[
        {"name": "city", "description": "City to report on", "required": True},
        {"name": "style", "description": "Report style: formal, casual, or brief", "required": False},
    ],
)
async def weather_report(city: str, style: str = "formal") -> list[dict]:
    """Produce a prompt that asks the LLM to write a weather report."""
    weather = _generate_weather(city.lower().replace(" ", "_"))

    style_instructions = {
        "formal": "Write a professional weather report suitable for a news broadcast.",
        "casual": "Write a friendly, conversational weather update.",
        "brief": "Write a one-sentence weather summary.",
    }
    instruction = style_instructions.get(style, style_instructions["formal"])

    return [
        {
            "role": "user",
            "content": {
                "type": "text",
                "text": (
                    f"{instruction}\n\n"
                    f"City: {weather['city']}\n"
                    f"Temperature: {weather['temperature_c']}C\n"
                    f"Humidity: {weather['humidity_pct']}%\n"
                    f"Wind: {weather['wind_speed_kmh']} km/h\n"
                    f"Condition: {weather['condition']}\n"
                    f"Time: {weather['timestamp']}"
                ),
            },
        }
    ]


@server.prompt(
    "travel_advice",
    description="Get weather-based travel advice comparing two destinations",
)
async def travel_advice(destination_a: str, destination_b: str) -> list[dict]:
    """Produce a prompt asking the LLM to give travel advice based on weather."""
    weather_a = _generate_weather(destination_a.lower().replace(" ", "_"))
    weather_b = _generate_weather(destination_b.lower().replace(" ", "_"))

    return [
        {
            "role": "user",
            "content": {
                "type": "text",
                "text": (
                    "Compare the weather at these two travel destinations and recommend "
                    "which one is better for a vacation this week. Consider temperature, "
                    "humidity, wind, and conditions.\n\n"
                    f"Destination A ({weather_a['city']}): "
                    f"{weather_a['temperature_c']}C, {weather_a['condition']}, "
                    f"humidity {weather_a['humidity_pct']}%, wind {weather_a['wind_speed_kmh']} km/h\n"
                    f"Destination B ({weather_b['city']}): "
                    f"{weather_b['temperature_c']}C, {weather_b['condition']}, "
                    f"humidity {weather_b['humidity_pct']}%, wind {weather_b['wind_speed_kmh']} km/h"
                ),
            },
        }
    ]


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = create_mcp_app(server)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=3002)
