# ASIFlow MCP Connector

Connect **Cursor**, **Claude Code**, **VS Code**, and **Windsurf** to ASIFlow's AI reasoning, memory, and multi-agent capabilities -- all through the Model Context Protocol.

`asiflow-mcp` is a local STDIO relay: your IDE talks MCP to this connector, and the connector forwards requests to ASIFlow's cloud backend.  All 24 tools are available with zero configuration beyond `pip install` and login.

## Quickstart

### 1. Install

```bash
pip install asiflow-mcp
```

### 2. Authenticate

```bash
asiflow-mcp auth login
```

Opens your browser to ASIFlow's OAuth page.  Token is stored at `~/.asiflow/credentials.json`.

### 3. Connect your IDE

**Cursor:**

```bash
asiflow-mcp setup cursor
```

This creates `.cursor/mcp.json` in your project directory.  Restart Cursor.

**Claude Code:**

```bash
claude mcp add asiflow -- asiflow-mcp serve
```

**VS Code:**

```bash
asiflow-mcp setup vscode
```

**Windsurf:**

```bash
asiflow-mcp setup windsurf
```

### 4. Use ASIFlow tools from your IDE

Once connected, your AI assistant can use all ASIFlow tools directly.  For example, in Cursor or Claude Code:

> "Use the causal_reason tool to analyze why our API latency spiked after the last deploy"

> "Run a multi-agent debate on the best database choice for this feature"

> "Store this architecture decision in memory for future reference"

## Available Tools (24)

### Causal Reasoning (Pearl's 3 Levels)
| Tool | Description |
|------|-------------|
| `causal_reason` | Apply causal reasoning at any of Pearl's 3 levels (association, intervention, counterfactual) |
| `causal_discover` | Discover causal relationships from observational data |
| `causal_intervene` | Simulate "what if" interventions on causal graphs |
| `causal_counterfactual` | Answer counterfactual queries ("what would have happened if...") |

### Advanced Reasoning
| Tool | Description |
|------|-------------|
| `reason_reflact` | ReflAct reasoning: interleave thinking and acting with self-reflection |
| `reason_graph_of_thoughts` | Explore solution space as a directed graph with branching and merging |
| `reason_creative_solve` | Generate creative solutions using lateral thinking and constraint relaxation |
| `reason_chain_of_thought` | Structured multi-step reasoning with verification |

### Memory (5 Types)
| Tool | Description |
|------|-------------|
| `memory_store` | Store information with type (episodic, semantic, procedural, working, meta) |
| `memory_recall` | Recall information using semantic search across memory types |
| `memory_consolidate` | Consolidate working memory into long-term storage |
| `memory_share` | Share memory entries across agents |
| `memory_forget` | Remove specific memories (GDPR-compliant selective forgetting) |

### Multi-Agent Collaboration
| Tool | Description |
|------|-------------|
| `agent_debate` | Run a multi-agent debate between specialized agents on a topic |
| `agent_consensus` | Build consensus across agents using structured deliberation |
| `agent_delegate` | Delegate a subtask to a specialized agent |
| `agent_swarm` | Run a swarm of agents in parallel with result aggregation |

### Knowledge & Learning
| Tool | Description |
|------|-------------|
| `knowledge_query` | Query the knowledge graph for entities and relationships |
| `knowledge_ingest` | Ingest new information into the knowledge graph |
| `learning_recommend` | Get self-improving agent recommendations based on past performance |
| `learning_evaluate` | Evaluate solution quality against historical baselines |

### Code Execution
| Tool | Description |
|------|-------------|
| `code_execute` | Execute code in a sandboxed environment (Python, Node.js, shell) |
| `code_analyze` | Static analysis of code with ASIFlow's multi-model reasoning |
| `code_review` | AI-powered code review with causal analysis of potential issues |

## CLI Reference

```
asiflow-mcp auth login        # OAuth login (opens browser)
asiflow-mcp auth logout       # Clear stored credentials
asiflow-mcp auth status       # Check authentication status
asiflow-mcp serve              # Start STDIO relay (used by IDEs)
asiflow-mcp setup <ide>        # Generate IDE config (cursor|claude-code|vscode|windsurf)
asiflow-mcp tools              # List available tools from the backend
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `ASIFLOW_API_URL` | `https://api.asiflow.ai/agent-core/mcp` | Backend API URL |
| `ASIFLOW_AUTH_URL` | `https://api.asiflow.ai/mcp/oauth/authorize` | OAuth authorize URL |
| `ASIFLOW_TOKEN_URL` | `https://api.asiflow.ai/mcp/oauth/token` | OAuth token URL |
| `ASIFLOW_CLIENT_ID` | `asiflow-mcp-connector` | OAuth client ID |
| `ASIFLOW_TIMEOUT` | `120` | Request timeout in seconds |

## How It Works

```
IDE (Cursor/Claude Code/VS Code/Windsurf)
    |
    | MCP over STDIO (JSON-RPC 2.0)
    v
asiflow-mcp (this connector)
    |
    | HTTPS + Bearer token
    v
ASIFlow Agent Core (api.asiflow.ai)
    |
    +-- Causal Reasoning Engine
    +-- LLM Gateway (multi-model)
    +-- Advanced Memory (5 types)
    +-- Multi-Agent Orchestrator
    +-- Knowledge Graph
    +-- Sandboxed Code Execution
```

The connector handles:
- **Authentication**: OAuth 2.1 PKCE with automatic token refresh
- **Discovery**: Caches tool/resource/prompt lists locally for fast response
- **Relay**: Forwards `tools/call`, `resources/read`, `prompts/get` to the backend
- **Local handling**: `initialize`, `ping`, list methods are answered locally

## Server Builder (Advanced)

The package also includes the MCP server builder for creating custom MCP servers:

```python
from asiflow_mcp import MCPServer, create_mcp_app

server = MCPServer(name="my-server", version="1.0.0")

@server.tool("greet", description="Greet someone by name")
async def greet(name: str = "World") -> str:
    return f"Hello, {name}!"

@server.resource("myapp://status", name="Status")
async def status() -> dict:
    return {"ok": True}

app = create_mcp_app(server)
# Run: uvicorn my_server:app --port 3001
```

This requires the `server` optional dependency:

```bash
pip install asiflow-mcp[server]
```

See `examples/` for complete server examples.

## Protocol

- MCP version: **2025-11-25**
- Transport (connector): **STDIO** (newline-delimited JSON-RPC)
- Transport (server builder): **Streamable HTTP** via FastAPI
- Auth: **OAuth 2.1 with PKCE** (no client secret)

## License

MIT
