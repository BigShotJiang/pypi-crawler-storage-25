#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = "Daniel Baier, Julian Lengersdorff, Francois Egner, Max Ufer"
__version__ = "1.6.3.1"
debug = False # are we running in debug mode?
