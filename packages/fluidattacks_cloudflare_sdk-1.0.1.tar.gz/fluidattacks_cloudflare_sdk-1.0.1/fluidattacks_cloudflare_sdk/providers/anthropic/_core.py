"""Domain types for Anthropic provider log payloads."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fa_purity import FrozenList, Maybe


@dataclass(frozen=True)
class AnthropicThinking:
    """Thinking configuration from an Anthropic request."""

    type: str
    budget_tokens: Maybe[int]


@dataclass(frozen=True)
class AnthropicUsage:
    """Token usage from an Anthropic response."""

    input_tokens: int
    output_tokens: int
    cache_read_input_tokens: Maybe[int]
    cache_creation_input_tokens: Maybe[int]


@dataclass(frozen=True)
class AnthropicMessage:
    """A single message in an Anthropic conversation."""

    role: str
    content: FrozenList[str]


@dataclass(frozen=True)
class AnthropicErrorResponse:
    """Error payload from an Anthropic response via AI Gateway."""

    error_type: str
    message: str


@dataclass(frozen=True)
class AnthropicRequest:
    """Decoded Anthropic request payload from AI Gateway."""

    model: str
    messages: FrozenList[AnthropicMessage]
    thinking: Maybe[AnthropicThinking]


@dataclass(frozen=True)
class AnthropicResponse:
    """Decoded Anthropic response payload from AI Gateway."""

    model: str
    id: str
    role: str
    content: FrozenList[str]
    stop_reason: Maybe[str]
    usage: AnthropicUsage
