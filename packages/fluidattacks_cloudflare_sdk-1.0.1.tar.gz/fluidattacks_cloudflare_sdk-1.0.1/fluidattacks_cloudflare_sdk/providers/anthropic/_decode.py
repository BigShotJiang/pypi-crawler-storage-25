"""Decoders for raw Anthropic AI Gateway log payloads."""

from __future__ import annotations

from fa_purity import Coproduct, FrozenList, PureIterFactory, ResultE
from fa_purity.json import (
    JsonObj,
    JsonPrimitiveUnfolder,
    JsonUnfolder,
    JsonValue,
    Unfolder,
)

from fluidattacks_cloudflare_sdk.providers.anthropic._core import (
    AnthropicErrorResponse,
    AnthropicMessage,
    AnthropicRequest,
    AnthropicResponse,
    AnthropicThinking,
    AnthropicUsage,
)


def _jval_to_str(value: JsonValue) -> ResultE[str]:
    return Unfolder.to_primitive(value).bind(JsonPrimitiveUnfolder.to_str)


def _jval_to_int(value: JsonValue) -> ResultE[int]:
    return Unfolder.to_primitive(value).bind(JsonPrimitiveUnfolder.to_int)


def _decode_content_block(item: JsonValue) -> ResultE[str]:
    return Unfolder.to_json(item).map(JsonUnfolder.dumps).lash(lambda _: _jval_to_str(item))


def _decode_content_blocks(value: JsonValue) -> ResultE[FrozenList[str]]:
    return (
        Unfolder.to_list(value)
        .bind(
            lambda items: PureIterFactory.from_list(items).reduce(
                lambda acc, item: acc.bind(
                    lambda t: _decode_content_block(item).map(lambda s: (*t, s))
                ),
                ResultE[tuple[str, ...]].success(()),
            )
        )
        .lash(lambda _: _jval_to_str(value).map(lambda s: (s,)))
    )


def _decode_thinking(raw: JsonObj) -> ResultE[AnthropicThinking]:
    return JsonUnfolder.require(raw, "type", _jval_to_str).bind(
        lambda thinking_type: JsonUnfolder.optional(raw, "budget_tokens", _jval_to_int).map(
            lambda budget: AnthropicThinking(type=thinking_type, budget_tokens=budget)
        )
    )


def _decode_usage(raw: JsonObj) -> ResultE[AnthropicUsage]:
    return JsonUnfolder.require(raw, "input_tokens", _jval_to_int).bind(
        lambda input_t: JsonUnfolder.require(raw, "output_tokens", _jval_to_int).bind(
            lambda output_t: JsonUnfolder.optional(
                raw, "cache_read_input_tokens", _jval_to_int
            ).bind(
                lambda cache_read: JsonUnfolder.optional(
                    raw, "cache_creation_input_tokens", _jval_to_int
                ).map(
                    lambda cache_creation: AnthropicUsage(
                        input_tokens=input_t,
                        output_tokens=output_t,
                        cache_read_input_tokens=cache_read,
                        cache_creation_input_tokens=cache_creation,
                    )
                )
            )
        )
    )


def _decode_message(item: JsonValue) -> ResultE[AnthropicMessage]:
    return Unfolder.to_json(item).bind(
        lambda raw: JsonUnfolder.require(raw, "role", _jval_to_str).bind(
            lambda role: JsonUnfolder.require(raw, "content", _decode_content_blocks).map(
                lambda content: AnthropicMessage(role=role, content=content)
            )
        )
    )


def _decode_messages(messages: JsonValue) -> ResultE[FrozenList[AnthropicMessage]]:
    return Unfolder.to_list(messages).bind(
        lambda items: (
            ResultE[FrozenList[AnthropicMessage]].failure(TypeError("empty messages"))
            if len(items) == 0
            else PureIterFactory.from_list(items).reduce(
                lambda acc, item: acc.bind(lambda t: _decode_message(item).map(lambda m: (*t, m))),
                ResultE[tuple[AnthropicMessage, ...]].success(()),
            )
        )
    )


def decode_anthropic_request(raw: JsonObj) -> ResultE[AnthropicRequest]:
    """Decode a raw AI Gateway log request payload."""
    return JsonUnfolder.require(raw, "model", _jval_to_str).bind(
        lambda model: JsonUnfolder.require(raw, "messages", _decode_messages).bind(
            lambda messages: JsonUnfolder.optional(
                raw,
                "thinking",
                lambda v: Unfolder.to_json(v).bind(_decode_thinking),
            ).map(
                lambda thinking: AnthropicRequest(
                    model=model,
                    messages=messages,
                    thinking=thinking,
                )
            )
        )
    )


def _decode_message_response(raw: JsonObj) -> ResultE[AnthropicResponse]:
    return JsonUnfolder.require(raw, "model", _jval_to_str).bind(
        lambda model: JsonUnfolder.require(raw, "id", _jval_to_str).bind(
            lambda msg_id: JsonUnfolder.require(raw, "role", _jval_to_str).bind(
                lambda role: JsonUnfolder.require(raw, "content", _decode_content_blocks).bind(
                    lambda content: JsonUnfolder.require(
                        raw, "usage", lambda v: Unfolder.to_json(v).bind(_decode_usage)
                    ).bind(
                        lambda usage: JsonUnfolder.optional(raw, "stop_reason", _jval_to_str).map(
                            lambda stop_reason: AnthropicResponse(
                                model=model,
                                id=msg_id,
                                role=role,
                                content=content,
                                stop_reason=stop_reason,
                                usage=usage,
                            )
                        )
                    )
                )
            )
        )
    )


def _decode_error_response(raw: JsonObj) -> ResultE[AnthropicErrorResponse]:
    return JsonUnfolder.require(
        raw,
        "error",
        lambda v: Unfolder.to_json(v).bind(
            lambda err: JsonUnfolder.require(err, "type", _jval_to_str).bind(
                lambda error_type: JsonUnfolder.require(err, "message", _jval_to_str).map(
                    lambda msg: AnthropicErrorResponse(error_type=error_type, message=msg)
                )
            )
        ),
    )


def decode_anthropic_response(
    raw: JsonObj,
) -> ResultE[Coproduct[AnthropicErrorResponse, AnthropicResponse]]:
    """Decode a raw AI Gateway log response payload."""
    return JsonUnfolder.require(raw, "type", _jval_to_str).bind(
        lambda resp_type: (
            _decode_error_response(raw).map(Coproduct.inl)
            if resp_type == "error"
            else _decode_message_response(raw).map(Coproduct.inr)
        )
    )
