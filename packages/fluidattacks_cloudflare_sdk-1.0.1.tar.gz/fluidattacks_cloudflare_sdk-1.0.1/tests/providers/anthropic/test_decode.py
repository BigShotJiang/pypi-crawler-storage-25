from fa_purity import Maybe, Unsafe
from fa_purity.json import JsonObj, UnfoldedFactory

from fluidattacks_cloudflare_sdk.providers.anthropic import (
    AnthropicMessage,
    AnthropicRequest,
    AnthropicResponse,
    AnthropicThinking,
    AnthropicUsage,
    decode_anthropic_request,
    decode_anthropic_response,
)


def _to_json_obj(raw: object) -> JsonObj:
    return UnfoldedFactory.json_from_any(raw).alt(Unsafe.raise_exception).to_union()


# -- request fixtures --


def _full_request_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-opus-4-5-20251101",
            "messages": [
                {"role": "user", "content": "what is 2+2?"},
            ],
            "system": "you are a helpful assistant",
            "thinking": {"type": "enabled", "budget_tokens": 1024},
        }
    )


def _minimal_request_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-sonnet-4-6",
            "messages": [
                {"role": "user", "content": "hello"},
            ],
        }
    )


def _array_content_request_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-sonnet-4-6",
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": "describe this image"}],
                },
            ],
        }
    )


def _empty_messages_request_raw() -> JsonObj:
    return _to_json_obj(
        {
            "model": "claude-sonnet-4-6",
            "messages": [],
        }
    )


# -- response fixtures --


def _full_response_raw() -> JsonObj:
    return _to_json_obj(
        {
            "type": "message",
            "model": "claude-opus-4-5-20251101",
            "id": "msg_01ABC",
            "role": "assistant",
            "content": "4",
            "stop_reason": "end_turn",
            "usage": {
                "input_tokens": 10,
                "output_tokens": 3,
                "cache_read_input_tokens": 200,
                "cache_creation_input_tokens": 50,
            },
        }
    )


def _minimal_response_raw() -> JsonObj:
    return _to_json_obj(
        {
            "type": "message",
            "model": "claude-sonnet-4-6",
            "id": "msg_02DEF",
            "role": "assistant",
            "content": "hi",
            "usage": {
                "input_tokens": 5,
                "output_tokens": 1,
            },
        }
    )


# -- expected values --

_EXPECTED_FULL_REQUEST = AnthropicRequest(
    model="claude-opus-4-5-20251101",
    messages=(AnthropicMessage(role="user", content=("what is 2+2?",)),),
    thinking=Maybe.some(AnthropicThinking(type="enabled", budget_tokens=Maybe.some(1024))),
)

_EXPECTED_MINIMAL_REQUEST = AnthropicRequest(
    model="claude-sonnet-4-6",
    messages=(AnthropicMessage(role="user", content=("hello",)),),
    thinking=Maybe.empty(),
)

_EXPECTED_FULL_RESPONSE = AnthropicResponse(
    model="claude-opus-4-5-20251101",
    id="msg_01ABC",
    role="assistant",
    content=("4",),
    stop_reason=Maybe.some("end_turn"),
    usage=AnthropicUsage(
        input_tokens=10,
        output_tokens=3,
        cache_read_input_tokens=Maybe.some(200),
        cache_creation_input_tokens=Maybe.some(50),
    ),
)

_EXPECTED_MINIMAL_RESPONSE = AnthropicResponse(
    model="claude-sonnet-4-6",
    id="msg_02DEF",
    role="assistant",
    content=("hi",),
    stop_reason=Maybe.empty(),
    usage=AnthropicUsage(
        input_tokens=5,
        output_tokens=1,
        cache_read_input_tokens=Maybe.empty(),
        cache_creation_input_tokens=Maybe.empty(),
    ),
)


# -- request tests --


def test_decode_full_request() -> None:
    result = decode_anthropic_request(_full_request_raw()).alt(Unsafe.raise_exception).to_union()
    assert result == _EXPECTED_FULL_REQUEST


def test_decode_minimal_request_optional_fields_are_empty() -> None:
    result = decode_anthropic_request(_minimal_request_raw()).alt(Unsafe.raise_exception).to_union()
    assert result == _EXPECTED_MINIMAL_REQUEST


def test_decode_request_array_content_each_block_serialized() -> None:
    result = (
        decode_anthropic_request(_array_content_request_raw())
        .alt(Unsafe.raise_exception)
        .to_union()
    )
    last = result.messages[-1]
    assert last.role == "user"
    assert len(last.content) == 1
    assert "type" in last.content[0]


def test_decode_request_empty_messages_fails() -> None:
    assert (
        decode_anthropic_request(_empty_messages_request_raw())
        .to_coproduct()
        .map(lambda _: False, lambda _: True)
    )


# -- response tests --


def test_decode_full_response() -> None:
    cop = decode_anthropic_response(_full_response_raw()).alt(Unsafe.raise_exception).to_union()
    result = cop.map(lambda _: None, lambda r: r)
    assert result == _EXPECTED_FULL_RESPONSE


def test_decode_minimal_response_cache_fields_are_empty() -> None:
    cop = decode_anthropic_response(_minimal_response_raw()).alt(Unsafe.raise_exception).to_union()
    result = cop.map(lambda _: None, lambda r: r)
    assert result == _EXPECTED_MINIMAL_RESPONSE
