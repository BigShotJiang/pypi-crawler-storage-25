from __future__ import annotations

"""
Python 接口层：Demoboard（基于 SerialNotebook 的兼容封装）

- 面向 Python 脚本用户，提供 with 语法与 execute_command 等高层接口；
- 内部不再直接使用 SerialCore/SerialRunner，而是复用新的 SerialNotebook/SerialRW 内核；
- 当 host 非 localhost 时，通过 SerialRWClient（见 serial_rw_server）接入远程 sdev server。

说明：
- 该模块已标记为 deprecated，实现尽量保持旧接口语义，但内部实现全部走新内核；
- 为简化接口，已移除 check_alive，推荐在上层用更明确的逻辑处理存活性/诊断。
"""

from typing import Generator, List, Optional, Union

from ..modules.serial_notebook import SerialNotebook
from ..modules.serial_rw_server import DEFAULT_SERVICE_PORT


class Demoboard:
    """
    Demoboard 设备（Python API，兼容旧接口）：

    - init 阶段只负责拼装 SerialNotebook（本地或远程）；
    - connect / disconnect / with 语法管理底层连接；
    - execute_command() 通过 SerialNotebook.run() 实现一次完整交互，并转换为 str 列表/迭代器。
    """

    def __init__(
        self,
        port: str,
        baudrate: int = 115200,
        host: str = "localhost",
        service_port: int = DEFAULT_SERVICE_PORT,
    ):
        """
        创建一个 Demoboard 实例：

        - port: 串口路径（如 /dev/ttyUSB0）；
        - baudrate: 波特率，默认 115200；
        - host: 串口所在主机，默认为本机（localhost）；当为远程 IP/主机名时，通过 sdev server 转发；
        - service_port: 远程 sdev server 的 TCP 端口，默认 DEFAULT_SERVICE_PORT(7000)。
        """
        h = (host or "localhost").strip().lower()
        if h in ("", "localhost", "127.0.0.1"):
            nb = SerialNotebook(device=port, baudrate=baudrate)
        else:
            nb = SerialNotebook(device=port, baudrate=baudrate, host=host, port=service_port)
        self._nb = nb

    # --- 上下文管理：自动 connect / disconnect ---

    def connect(self) -> None:
        # 直接复用 SerialNotebook 内部的 core 连接能力
        self._nb._core.connect()

    def disconnect(self) -> None:
        self._nb._core.disconnect()

    def __enter__(self) -> "Demoboard":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    # --- 对外高层 API ---

    def execute_command(
        self,
        cmd: Optional[str],
        *,
        flag: str = " #",
        timeout: Optional[float] = None,
        wait_forever: bool = False,
        stream: bool = False,
    ) -> Union[List[str], Generator[str, None, None]]:
        """
        在板子上执行一条命令并等待提示符出现：

        - cmd 为非 None 时：发送该命令并等待其回显 + 提示符；
        - cmd 为 None 时：不发送新命令，仅被动读取当前输出，直到超时（兼容旧用法）；
        - flag：提示符结束标记（对应 CLI 中 -p 的语义）；
        - timeout：整体超时时间（overall_timeout），为 None 时表示不限制整体时间；
        - wait_forever=True：禁用响应超时（response_timeout=None），只靠整体 timeout/用户中断结束；
        - stream=False：收集所有行并返回 list[str]；
        - stream=True：返回逐行生成 str 的 generator。
        """

        # 旧接口允许 cmd=None，这里用 SerialNotebook.wait_for_silence 兼容这一行为。
        if cmd is None:
            effective_timeout = timeout if timeout is not None else 1.5
            lines = self._nb.wait_for_silence(timeout=effective_timeout)

            def _iter_none_cmd() -> Generator[str, None, None]:
                for line in lines:
                    text = getattr(line, "text", str(line))
                    yield text

            if stream:
                return _iter_none_cmd()
            return [getattr(line, "text", str(line)) for line in lines]

        response_timeout = None if wait_forever else timeout

        def _iter_cmd() -> Generator[str, None, None]:
            return self._nb.run(
                cmd=cmd,
                end_flag=flag,
                overall_timeout=timeout,
                response_timeout=response_timeout,
                stream=True,
                verbose=True,
            )
            
        if stream:
            return _iter_cmd()
        return list(_iter_cmd())

    def send_interrupt(self) -> None:
        """
        将一次「中断」请求转换为对板子的 Ctrl-C（^C）发送。
        """
        self._nb.send_interrupt()

    def check_model_type(self, timeout: Optional[float] = 2.0) -> Optional[str]:
        """
        读取设备树型号前缀，复用 SerialNotebook.check_model_type 语义。
        """
        return self._nb.get_model_type(timeout=timeout)


__all__ = ["Demoboard"]

