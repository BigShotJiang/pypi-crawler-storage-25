"""
新架构下的 sdev 包。

- modules: 底层模块（SerialCore / SerialRunner 等）
- api: Python 接口层（Demoboard 等）
"""

from importlib import metadata as _metadata

__version__ = _metadata.version("sdev")
from .modules import SerialNotebook

