from __future__ import annotations

"""
sdev CLI 入口：

- sdev run：在指定（或默认）设备上执行命令并按 README 约定格式回显；
- sdev list：扫描本地与远程串口设备、存活检测、设备类型、表格输出与 list 缓存；
- sdev server：启动/停止/重启/查看本机串口共享服务。
"""

import argparse
import contextlib
import fcntl
import hashlib
import itertools
import json
import os
import signal
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from ..modules import (
    check_port_alive_nonblock,
    scan_serial_ports,
    DEFAULT_SERVICE_PORT,
)
from ..modules.serial_notebook import SerialNotebook
from ..modules.serial_rw_server import (
    SerialRWClient,
    fetch_boards_from_host,
    get_remote_hosts,
)


def _sdev_cache_dir() -> str:
    """与 serial_core 锁目录一致：XDG_RUNTIME_DIR/sdev 或 ~/.cache/sdev。"""
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(os.path.expanduser("~"), ".cache")
    d = os.path.join(base, "sdev")
    os.makedirs(d, mode=0o700, exist_ok=True)
    return d


@contextlib.contextmanager
def _list_global_lock():
    """
    sdev list 进程级全局锁。
    本工具不支持并发 list；这里用阻塞锁串行化，避免并发扫描互相干扰。
    """
    lock_path = os.path.join(_sdev_cache_dir(), "list.lock")
    with open(lock_path, "w", encoding="utf-8") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def _run_parallel_with_spinners(specs: List[Tuple[str, Any]]) -> List[Any]:
    """
    多行并行 spinner：
    - specs: [(label, callable)]，每个 callable() 在子线程执行，返回结果组成列表。
    - 终端上每行显示 label + 旋转动画，任务完成后变为 label + ✔。
    """
    n = len(specs)
    if n == 0:
        return []

    results: List[Any] = [None] * n
    done_flags: List[bool] = [False] * n
    frame_iters = [itertools.cycle("|/-\\") for _ in range(n)]
    GREEN = "\033[32m"
    RESET = "\033[0m"

    def run_i(i: int) -> None:
        try:
            fn = specs[i][1]
            results[i] = fn()
        finally:
            done_flags[i] = True

    threads = [threading.Thread(target=run_i, args=(i,), daemon=True) for i in range(n)]
    for t in threads:
        t.start()

    def display_worker() -> None:
        while True:
            all_done = all(done_flags)
            lines: List[str] = []
            for i, (label, _) in enumerate(specs):
                if done_flags[i]:
                    line = f"{label} {GREEN}✔{RESET}"
                else:
                    frame = next(frame_iters[i])
                    line = f"{label} {frame}"
                lines.append(line)
            sys.stdout.write("\n".join(lines) + "\n")
            sys.stdout.flush()
            if all_done:
                break
            # 光标上移 n 行，刷新 spinner。
            sys.stdout.write(f"\033[{n}A")
            sys.stdout.flush()
            time.sleep(0.1)

    display_thread = threading.Thread(target=display_worker, daemon=True)
    display_thread.start()
    for t in threads:
        t.join()
    display_thread.join()

    return results


def _list_cache_path() -> str:
    return os.path.join(_sdev_cache_dir(), "list_cache.json")


def _read_list_cache() -> List[Dict[str, Any]]:
    path = _list_cache_path()
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _write_list_cache(entries: List[Dict[str, Any]]) -> None:
    with open(_list_cache_path(), "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=0)


def _device_id(host: str, port: str) -> str:
    """基于 host + port 计算 6 位 hex，供 device id 使用。"""
    raw = f"{host}:{port}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:6]


def _default_config_path() -> str:
    return os.path.join(_sdev_cache_dir(), "default.json")


def _read_default() -> Optional[Dict[str, Any]]:
    path = _default_config_path()
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _write_default(host: str, device: str, device_id: str) -> None:
    with open(_default_config_path(), "w", encoding="utf-8") as f:
        json.dump({"host": host, "device": device, "device_id": device_id}, f, ensure_ascii=False)


def _clear_default() -> None:
    path = _default_config_path()
    if os.path.isfile(path):
        os.remove(path)


def _resolve_device_to_host_port(device_id: str) -> Optional[Tuple[str, str]]:
    """从 list 缓存中按 device_id 解析出 (host, device)；未找到返回 None。"""
    for e in _read_list_cache():
        if (e.get("device_id") or "").lower() == device_id.lower():
            return (e.get("host", "localhost"), e.get("device", ""))
    return None


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sdev", add_help=True)
    subparsers = parser.add_subparsers(dest="command", required=True)

    # sdev run ...
    run_p = subparsers.add_parser(
        "run",
        help="在指定串口设备上执行命令（支持本地与远程，远程通过 server 转发）",
    )
    run_p.add_argument(
        "--port",
        "-P",
        default=None,
        help="本地串口设备路径；不指定时使用 sdev set default 配置的默认设备",
    )
    run_p.add_argument(
        "--baud",
        "-b",
        type=int,
        default=115200,
        help="波特率，默认 115200",
    )
    run_p.add_argument(
        "-p",
        "--prompt",
        dest="prompt_flag",
        default=" #",
        help="提示符结束标记（对应 README 中的 prompt flag），默认 ' #'",
    )
    run_p.add_argument(
        "-t",
        "--timeout",
        type=float,
        default=None,
        help="整体命令超时时间（秒），从发送命令开始计时；为空表示不限制",
    )
    run_p.add_argument(
        "-w",
        "--wait-forever",
        action="store_true",
        help="取消内部响应超时，永久等待直到整体超时或用户中断",
    )
    run_p.add_argument(
        "-i",
        "--interrupt-only",
        action="store_true",
        help="仅向当前会话发送一次中断信号（Ctrl-C），并尝试收集后续输出",
    )
    run_p.add_argument(
        "cmd",
        nargs=argparse.REMAINDER,
        help="要在设备上执行的命令字符串（按 shell 惯例从剩余参数拼接）",
    )

    # sdev doctor ...
    doctor_p = subparsers.add_parser(
        "doctor",
        help="对当前（或默认）设备执行串口 notebook doctor 自检",
    )
    doctor_p.add_argument(
        "--port",
        "-P",
        default=None,
        help="本地串口设备路径；不指定时使用 sdev set default 配置的默认设备",
    )
    doctor_p.add_argument(
        "--baud",
        "-b",
        type=int,
        default=115200,
        help="波特率，默认 115200",
    )
    doctor_p.add_argument(
        "-i",
        "--interrupt",
        action="store_true",
        help="使用 interrupt 模式执行 doctor：直接发送一次 Ctrl-C 并根据输出进行判定",
    )

    # sdev list [local|remote] [-f] [type=xxx] [host=xxx]
    list_p = subparsers.add_parser("list", help="列出可用串口设备")
    list_p.add_argument(
        "scope_or_filter",
        nargs="?",
        help="默认仅本地扫描；可显式传 local/remote，或直接给第一个筛选条件（如 type=xc01）",
    )
    list_p.add_argument(
        "-f",
        "--fast",
        action="store_true",
        help="找到第一个符合条件的设备即返回，不等待其余扫描",
    )
    list_p.add_argument(
        "filters",
        nargs="*",
        help="筛选条件，如 type=xc01 host=192.168.1.100",
    )

    # sdev set default <device_id> 或 sdev set <host> <serial_device>
    set_p = subparsers.add_parser("set", help="配置默认设备")
    set_p.add_argument(
        "first",
        help="'default' 表示按 device id 从 list 缓存解析；否则为 host",
    )
    set_p.add_argument(
        "second",
        nargs="?",
        help="device_id（当 first=default）或 serial device 路径（当 first=host）",
    )

    # sdev show default
    show_p = subparsers.add_parser("show", help="显示配置")
    show_p.add_argument("what", nargs="?", choices=["default"], default="default", help="default=当前默认设备")

    # sdev reset default | sdev reset all
    reset_p = subparsers.add_parser("reset", help="清空配置或缓存")
    reset_p.add_argument(
        "target",
        choices=["default", "all"],
        help="default=仅清空默认设备；all=清空所有缓存并关闭 server（若有）",
    )

    # sdev server start | stop | restart | status
    server_p = subparsers.add_parser("server", help="本地串口共享服务（TCP + zeroconf）")
    server_p.add_argument(
        "action",
        choices=["start", "stop", "restart", "status"],
        help="start=后台启动；stop=停止；restart=先停后启；status=查看状态",
    )
    server_p.add_argument(
        "--port",
        "-P",
        type=int,
        default=DEFAULT_SERVICE_PORT,
        help=f"TCP 服务端口（仅 start/restart 有效），默认 {DEFAULT_SERVICE_PORT}",
    )
    server_p.add_argument(
        "--lines",
        "-n",
        type=int,
        default=10,
        help="status 时显示的最近日志行数，默认 10",
    )

    # sdev mcp run | install
    mcp_p = subparsers.add_parser("mcp", help="MCP (Model Context Protocol) 相关工具")
    mcp_p.add_argument(
        "action",
        choices=["run", "install"],
        help="run=启动 MCP 服务(stdio传输)；install=获取可粘贴的配置信息",
    )

    return parser


def _handle_run(args: argparse.Namespace) -> int:
    # 将剩余参数拼接为单个命令字符串，忽略开头的空格。
    cmd_parts: List[str] = args.cmd or []
    cmd_str = " ".join(cmd_parts).strip()
    interrupt_only = getattr(args, "interrupt_only", False)
    if not cmd_str and not interrupt_only:
        raise SystemExit("sdev run: 缺少要执行的命令；若只想发送一次 Ctrl-C，请使用 sdev run -i")
    if interrupt_only and cmd_str:
        raise SystemExit("sdev run -i: 不应同时指定命令，请去掉命令参数或去掉 -i")

    port = getattr(args, "port", None)
    host: Optional[str] = None
    if not port:
        default_cfg = _read_default()
        if not default_cfg:
            raise SystemExit("sdev run: 未指定 --port 且未配置默认设备，请先执行 sdev set default <device_id> 或 sdev set <host> <serial_device>")
        host = (default_cfg.get("host") or "").strip() or "localhost"
        device = (default_cfg.get("device") or default_cfg.get("port") or "").strip()
        if not device:
            raise SystemExit("sdev run: 默认配置缺少 device")
    else:
        host = "localhost"
        device = port

    overall_timeout: Optional[float] = args.timeout
    # 若未显式指定整体超时，CLI 默认给一个有限的响应超时，避免在无输出设备上永久挂起。
    if args.wait_forever:
        response_timeout: Optional[float] = None
    else:
        response_timeout = overall_timeout if overall_timeout is not None else 2.0

    # CLI 统一通过 SerialNotebook 作为上层入口：
    # - 本地：直接使用本机串口；
    # - 远程：通过 SerialRWClient 由 SerialNotebook 内部接管。
    if (host or "").lower() == "localhost":
        nb = SerialNotebook(device=device, baudrate=args.baud)
    else:
        nb = SerialNotebook(device=device, baudrate=args.baud, host=host, port=DEFAULT_SERVICE_PORT)

    with nb:
        try:
            if interrupt_only:
                # 仅发送一次中断信号，然后在较短窗口内被动收集输出。
                nb.send_interrupt()
                lines = nb.wait_for_silence(timeout=response_timeout or 1.0)
                # 为保持行为简单，这里仅以灰色输出剩余行，不再额外做提示符高亮。
                GREY = "\033[90m"
                RESET = "\033[0m"
                for line in lines:
                    text = getattr(line, "text", str(line))
                    sys.stdout.write(f"{GREY}{text}{RESET}")
                sys.stdout.flush()
            else:
                # 正常执行命令。
                ret = nb.run(
                    cmd=cmd_str,
                    end_flag=args.prompt_flag,
                    overall_timeout=overall_timeout,
                    response_timeout=response_timeout,
                    stream=False,
                    verbose=False,
                    keep_type=True,
                )
                for line in ret:
                    if line.kind == 'body' or line.kind == 'error':
                        sys.stdout.write(line.text)
                        sys.stdout.flush()
            print()
        except KeyboardInterrupt:
            # 捕获本地 Ctrl-C：向开发板发送一次中断信号（Ctrl-C），尽量中断远端前台命令。
            nb.send_interrupt()
            # 提示用户本次为主动中断（黄色）。
            YELLOW = "\033[33m"
            RESET = "\033[0m"
            print(f"\n\n{YELLOW}<user interruption>{RESET}")
            # 本地进程正常结束，不再打印 traceback。
            return 0

    return 0


def _handle_doctor(args: argparse.Namespace) -> int:
    """
    sdev doctor:
    - 默认使用当前默认设备（由 sdev set 配置）；
    - 也可以通过 --port/-P 指定本地串口设备；
    - 通过 -i/--interrupt 控制是否使用 interrupt 模式。
    """
    port = getattr(args, "port", None)
    host: Optional[str]
    if not port:
        default_cfg = _read_default()
        if not default_cfg:
            raise SystemExit(
                "sdev doctor: 未指定 --port 且未配置默认设备，请先执行 sdev set default <device_id> 或 sdev set <host> <serial_device>"
            )
        host = (default_cfg.get("host") or "").strip() or "localhost"
        device = (default_cfg.get("device") or default_cfg.get("port") or "").strip()
        if not device:
            raise SystemExit("sdev doctor: 默认配置缺少 device")
    else:
        host = "localhost"
        device = port

    baud = int(getattr(args, "baud", 115200) or 115200)

    if (host or "").lower() == "localhost":
        nb = SerialNotebook(device=device, baudrate=baud)
    else:
        nb = SerialNotebook(device=device, baudrate=baud, host=host, port=DEFAULT_SERVICE_PORT)

    interrupt_mode = bool(getattr(args, "interrupt", False))

    with nb:
        # CLI 仅负责触发 doctor 逻辑，具体判定逻辑在 SerialNotebook.doctor 内部实现。
        # 这里根据 -i/--interrupt 切换 interrupt 参数：
        # - interrupt=False：先等待片刻静默，再发送 Ctrl-C 并采样输出；
        # - interrupt=True：直接发送 Ctrl-C 并在短窗口内观察响应。
        nb.doctor(interrupt=interrupt_mode)

    return 0


def _parse_list_filters(filters: List[str]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for s in filters or []:
        if "=" in s:
            k, _, v = s.partition("=")
            k, v = k.strip().lower(), v.strip()
            if k:
                out[k] = v
    return out


def _ts() -> str:
    return datetime.now().strftime("%H:%M:%S")


def _handle_list(args: argparse.Namespace) -> int:
    with _list_global_lock():
        extra_filters = list(getattr(args, "filters", None) or [])
        scope_or_filter = getattr(args, "scope_or_filter", None)

        scope: Optional[str]
        initial_filter_parts: list[str] = []
        if scope_or_filter in ("local", "remote"):
            scope = scope_or_filter
        elif scope_or_filter is None:
            # 默认不访问网络，仅扫描本地串口设备。
            scope = "local"
        else:
            # 传入筛选条件时，依然沿用默认仅本地扫描。
            scope = "local"
            initial_filter_parts.append(scope_or_filter)

        filters = _parse_list_filters(initial_filter_parts + extra_filters)
        fast = getattr(args, "fast", False)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        scan_local = scope != "remote"
        scan_remote = scope != "local"

        # 本地与远程扫描分别封装为任务，由 spinner 展示进度。
        def _scan_local_task(ports: List[str]) -> List[Dict[str, Any]]:
            entries: List[Dict[str, Any]] = []
            if not ports:
                return entries
    
            def _check_one(port: str) -> Tuple[str, Dict[str, Any]]:
                r = check_port_alive_nonblock(port, baudrate=115200, timeout=1.5)
                return (port, r)
    
            alive_ports: List[str] = []
            results: List[Tuple[str, Dict[str, Any]]] = []
            fast_exit = False
            ex = ThreadPoolExecutor(max_workers=max(len(ports), 1))
            try:
                futs = {ex.submit(_check_one, p): p for p in ports}
                if fast:
                    for fut in as_completed(futs):
                        port, r = fut.result()
                        results.append((port, r))
                        if r.get("available"):
                            fast_exit = True
                            alive_ports = [port]
                            break
                else:
                    for fut in as_completed(futs):
                        results.append(fut.result())
                    results.sort(key=lambda x: x[0])
                    for port, r in results:
                        if r.get("available"):
                            alive_ports.append(port)
            finally:
                ex.shutdown(wait=not fast_exit)
    
            def _model_one(port: str) -> Tuple[str, str]:
                try:
                    with SerialNotebook(device=port, baudrate=115200) as nb:
                        return (port, nb.get_model_type(timeout=2.0, verbose=False) or "unknown")
                except Exception as e:
                    return (port, f"error: {e}")
    
            if alive_ports:
                model_results: List[Tuple[str, str]] = []
                with ThreadPoolExecutor(max_workers=max(len(alive_ports), 1)) as ex2:
                    futs = {ex2.submit(_model_one, p): p for p in alive_ports}
                    for fut in as_completed(futs):
                        model_results.append(fut.result())
                model_results.sort(key=lambda x: x[0])
                for port, device_type in model_results:
                    entries.append({
                        "host": "localhost",
                        "device": port,
                        "device_id": _device_id("localhost", port),
                        "device_type": device_type if not device_type.startswith("error:") else "unknown",
                        "last_update": now,
                    })
            return entries
    
        def _scan_remote_task() -> List[Dict[str, Any]]:
            entries: List[Dict[str, Any]] = []
            hosts = get_remote_hosts()
            # print(f"[debug] remote hosts found by discovery: {hosts}")
            if not hosts:
                return entries
            for host, service_port in hosts:
                # print(f"[debug] fetching boards from {host}:{service_port}...")
                boards = fetch_boards_from_host(host, service_port, timeout=10.0)
                # print(f"[debug] host {host} returned {len(boards)} boards")
                for b in boards:
                    if not b.get("available"):
                        continue
                    serial_dev = (b.get("device") or b.get("port") or "").strip()
                    if not serial_dev:
                        continue
                    baud = int(b.get("baudrate") or 115200)
                    device_type = "unknown"
                    try:
                        with SerialNotebook(device=serial_dev, baudrate=baud, host=host, port=service_port) as nb:
                            device_type = nb.get_model_type(timeout=3.0, verbose=False) or "unknown"
                    except Exception as e:
                        # 如果报错，说明连接或者握手阶段就出问题了
                        # print(f"[debug] failed to get model type from {host}:{serial_dev}: {e}")
                        device_type = "unknown"
                    entries.append({
                        "host": host,
                        "device": serial_dev,
                        "device_id": _device_id(host, serial_dev),
                        "device_type": device_type if not device_type.startswith("error:") else "unknown",
                        "last_update": now,
                    })
            return entries

        specs: List[Tuple[str, Any]] = []
        local_entries: List[Dict[str, Any]] = []
        remote_entries: List[Dict[str, Any]] = []
        idx_local: Optional[int] = None
        idx_remote: Optional[int] = None

        if scan_local and scan_remote:
            ports = scan_serial_ports()
            label = f"[main] scanning {len(ports)} local port(s) and discovering remote hosts..."
            print(label)
            # 本地和远程作为两个并行任务：
            idx_local = 0
            idx_remote = 1
            specs.append(("[local] scanning local ports", lambda p=ports: _scan_local_task(p)))
            specs.append(("[remote] discovering remote hosts", _scan_remote_task))
        elif scan_local:
            ports = scan_serial_ports()
            label = f"[main] scanning {len(ports)} local port(s)..."
            print(label)
            idx_local = 0
            specs.append(("[local] scanning local ports", lambda p=ports: _scan_local_task(p)))
        else:
            # 仅远程
            print("[main] discovering remote hosts...")
            idx_remote = 0
            specs.append(("[remote] discovering remote hosts", _scan_remote_task))

        if specs:
            results = _run_parallel_with_spinners(specs)
            if idx_local is not None:
                local_entries = results[idx_local] or []
            if idx_remote is not None:
                remote_entries = results[idx_remote] or []

        entries = list(local_entries) + list(remote_entries)

        print("[main] all scanning finished.")

        # 保存本次扫描到的全部设备到缓存，便于后续 sdev run / set default 解析 host/port
        _write_list_cache(list(entries))

        # 应用筛选（仅影响本次打印）
        if "type" in filters:
            entries = [e for e in entries if (e.get("device_type") or "").lower() == filters["type"].lower()]
        if "host" in filters:
            entries = [e for e in entries if (e.get("host") or "").lower() == filters["host"].lower()]

        # 默认展示所有探测到的设备，即便型号识别为 unknown。
        # entries = [e for e in entries if (e.get("device_type") or "").lower() != "unknown"]
        if fast and len(entries) > 1:
            entries = entries[:1]

        # 表格输出
        col_host = 14
        col_port = 16
        col_id = 10
        col_type = 14
        col_time = 20
        header = f"{'HOST':<{col_host}} {'PORT':<{col_port}} {'DEVICE ID':<{col_id}} {'DEVICE TYPE':<{col_type}} {'LAST UPDATE':<{col_time}}"
        sep = "-" * (col_host + col_port + col_id + col_type + col_time + 4)
        print(header)
        print(sep)
        for e in entries:
            print(
                f"{e.get('host', ''):<{col_host}} "
                f"{e.get('device', ''):<{col_port}} "
                f"{e.get('device_id', ''):<{col_id}} "
                f"{e.get('device_type', 'unknown'):<{col_type}} "
                f"{e.get('last_update', ''):<{col_time}}"
            )
        return 0


def _handle_set(args: argparse.Namespace) -> int:
    first = (getattr(args, "first", None) or "").strip()
    second = (getattr(args, "second", None) or "").strip()
    if first.lower() == "default":
        if not second:
            raise SystemExit("sdev set default: 请提供 device_id，例如 sdev set default abc123")
        host_port = _resolve_device_to_host_port(second)
        if not host_port:
            raise SystemExit(f"sdev set default: 未在 list 缓存中找到 device_id {second!r}，请先执行 sdev list")
        host, port = host_port
        _write_default(host, port, second)
        print(f"[{_ts()}] default set: host={host} port={port} device_id={second}")
        return 0
    # sdev set <host> <serial_device>
    if not second:
        raise SystemExit("sdev set <host> <serial_device>: 请提供 host 与 serial device 路径")
    _write_default(first, second, _device_id(first, second))
    print(f"[{_ts()}] default set: host={first} port={second} device_id={_device_id(first, second)}")
    return 0


def _handle_show(args: argparse.Namespace) -> int:
    what = getattr(args, "what", "default") or "default"
    if what == "default":
        cfg = _read_default()
        if not cfg:
            print("(无默认设备)")
            return 0
        print(f"host: {cfg.get('host', '')}")
        print(f"port: {cfg.get('port', '')}")
        print(f"device_id: {cfg.get('device_id', '')}")
    return 0


def _server_pid_path() -> str:
    return os.path.join(_sdev_cache_dir(), "server.pid")


def _server_log_path() -> str:
    """与 remote_core 一致：~/.cache/sdev/server.log 或 XDG_RUNTIME_DIR/sdev/server.log。"""
    return os.path.join(_sdev_cache_dir(), "server.log")


def _server_is_running() -> Optional[int]:
    """若 server 进程存在则返回 pid，否则返回 None。"""
    path = _server_pid_path()
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            pid = int(f.read().strip())
    except (ValueError, OSError):
        return None
    try:
        os.kill(pid, 0)
    except OSError:
        return None
    return pid


def _handle_server_start(args: argparse.Namespace) -> int:
    if _server_is_running() is not None:
        print(f"[{_ts()}] server already running (see sdev server status)")
        return 0
    port = getattr(args, "port", DEFAULT_SERVICE_PORT) or DEFAULT_SERVICE_PORT
    # 与旧实现一致：项目根 = __file__ 向上三层，cwd + PYTHONPATH 保证子进程能用当前源码找到 sdev
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    _env = os.environ.copy()
    _env["PYTHONPATH"] = os.path.pathsep.join([_project_root, _env.get("PYTHONPATH", "")]).rstrip(os.path.pathsep)
    proc = subprocess.Popen(
        [sys.executable, "-m", "sdev.modules.serial_rw_server", str(port)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        start_new_session=True,
        cwd=_project_root,
        env=_env,
    )
    pid_path = _server_pid_path()
    with open(pid_path, "w", encoding="utf-8") as f:
        f.write(str(proc.pid))
    # 短暂等待：若子进程立即退出（如端口被占用），能拿到 stderr 并提示
    time.sleep(0.6)
    if proc.poll() is not None:
        try:
            os.remove(pid_path)
        except OSError:
            pass
        err = (proc.stderr and proc.stderr.read()) or b""
        err_text = err.decode("utf-8", errors="replace").strip()
        if err_text:
            print(f"[{_ts()}] server exited: {err_text.split(chr(10))[-1] if err_text else 'unknown'}", file=sys.stderr)
        else:
            print(f"[{_ts()}] server exited with code {proc.returncode}", file=sys.stderr)
        return 1
    print(f"[{_ts()}] server started (pid={proc.pid}, port={port})")
    return 0


def _handle_server_stop() -> int:
    pid = _server_is_running()
    if pid is None:
        print(f"[{_ts()}] server not running")
        return 0
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        pass
    try:
        os.remove(_server_pid_path())
    except OSError:
        pass
    print(f"[{_ts()}] server stopped (pid={pid})")
    return 0


def _handle_server_status(args: argparse.Namespace) -> None:
    """打印本机 sdev server 状态与最近日志（与旧实现一致）。"""
    _GREEN = "\033[32m"
    _RED = "\033[31m"
    _RESET = "\033[0m"
    pid = _server_is_running()
    running = pid is not None
    log_path = _server_log_path()

    if running:
        print(f"[server] {_GREEN}status: RUNNING{_RESET} (pid={pid})")
    else:
        print(f"[server] {_RED}status: NOT RUNNING{_RESET}")

    print(f"[server] log file: {log_path}")

    try:
        with open(log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except OSError:
        print("[server] 日志文件不存在。")
        return

    n = max(1, int(getattr(args, "lines", 10) or 10))
    tail = lines[-n:]
    print(f"[server] 最近 {len(tail)} 行日志：")
    for line in tail:
        print(line.rstrip("\n"))


def _handle_server(args: argparse.Namespace) -> int:
    action = getattr(args, "action", None)
    if action == "start":
        return _handle_server_start(args)
    if action == "stop":
        return _handle_server_stop()
    if action == "restart":
        _handle_server_stop()
        return _handle_server_start(args)
    if action == "status":
        _handle_server_status(args)
        return 0
    return 1


def _handle_reset(args: argparse.Namespace) -> int:
    target = getattr(args, "target", None)
    if target == "default":
        _clear_default()
        print(f"[{_ts()}] default cleared")
        return 0
    if target == "all":
        if _server_is_running() is not None:
            _handle_server_stop()
        _clear_default()
        list_path = _list_cache_path()
        if os.path.isfile(list_path):
            os.remove(list_path)
            print(f"[{_ts()}] list cache cleared")
        print(f"[{_ts()}] reset all done")
    return 0


def _handle_mcp(args: argparse.Namespace) -> int:
    action = getattr(args, "action", None)
    if action == "run":
        # 启动 MCP 服务
        from ..modules.mcp_server import mcp
        mcp.run()
        return 0
    if action == "install":
        return _mcp_show_config()
    return 1


def _mcp_show_config() -> int:
    import platform
    import json
    
    # 确定 Python 路径
    py_path = sys.executable
    # 确定项目根目录（用于 PYTHONPATH）
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    
    # 封装配置对象
    sdev_config = {
        "command": py_path,
        "args": ["-m", "sdev.modules.mcp_server"],
        "env": {
            "PYTHONPATH": project_root
        }
    }
    
    system = platform.system()
    home = os.path.expanduser("~")
    
    print(f"\n[{_ts()}] === SDEV MCP 配置指南 ===")
    
    # 1. 针对 Cursor
    print(f"\n[Cursor 推荐路径]:")
    if system == "Linux":
        print(f"  {home}/.cursor/mcp.json")
    elif system == "Darwin":
        print(f"  ~/Library/Application Support/Cursor/User/globalStorage/rosebud.cursor-ide-browser/mcp.json")
    
    print(f"\n[Cursor/Claude 粘贴内容 (sdev 字段)]: ")
    print(json.dumps(sdev_config, indent=2, ensure_ascii=False))
    
    print(f"\n[完整示例 (mcp.json)]: ")
    full_example = {
        "mcpServers": {
            "sdev": sdev_config
        }
    }
    print(json.dumps(full_example, indent=2, ensure_ascii=False))
    
    print(f"\n[{_ts()}] 请将上述内容添加到你的 MCP 配置文件中，并重启 AI 客户端。")
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "run":
        return _handle_run(args)
    if args.command == "doctor":
        return _handle_doctor(args)
    if args.command == "list":
        return _handle_list(args)
    if args.command == "set":
        return _handle_set(args)
    if args.command == "show":
        return _handle_show(args)
    if args.command == "reset":
        return _handle_reset(args)
    if args.command == "server":
        return _handle_server(args)
    if args.command == "mcp":
        return _handle_mcp(args)

    parser.error(f"未知子命令: {args.command}")
    return 1


__all__ = ["main"]

