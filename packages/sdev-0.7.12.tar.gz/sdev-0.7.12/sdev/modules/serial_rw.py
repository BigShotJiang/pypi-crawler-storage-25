import serial
import queue
import os
import re
import sys
import threading
import time
from typing import Optional

if sys.platform == "win32":
    import msvcrt
else:  # Unix
    import fcntl

CTRL_C = "\x03"
SERIAL_RW_ECHO = 0
SERIAL_RW_BODY = 1

def _device_lock_path(device: str) -> str:
    """锁文件路径：XDG_RUNTIME_DIR/sdev 或 ~/.cache/sdev，避免 /tmp。Windows 同用用户目录。"""
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(os.path.expanduser("~"), ".cache")
    lock_dir = os.path.join(base, "sdev")
    os.makedirs(lock_dir, mode=0o700, exist_ok=True)
    safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", os.path.basename(device))
    return os.path.join(lock_dir, f"device_{safe}.lock")


def _acquire_device_lock(device: str):
    """
    对设备持有跨进程排他锁（阻塞直到拿到），返回打开的 fd，调用方负责 close。
    Unix: fcntl.flock；Windows: msvcrt.locking。
    """
    path = _device_lock_path(device)
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    # 若端口已被其他进程占用，锁获取会阻塞；为避免调用方“无声等待”，在等待一段时间后打印提示。
    start = time.monotonic()
    notified = False

    if sys.platform == "win32":
        while True:
            try:
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                break
            except OSError:
                if not notified and time.monotonic() - start > 0.5:
                    sys.stderr.write(f"[sdev] waiting for device lock: {device}\n")
                    sys.stderr.flush()
                    notified = True
                time.sleep(0.1)
        return fd
    # Unix
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if not notified and time.monotonic() - start > 0.5:
                sys.stderr.write(f"[sdev] waiting for device lock: {device}\n")
                sys.stderr.flush()
                notified = True
            time.sleep(0.1)
    return fd


def _release_device_lock(fd: Optional[int]) -> None:
    if fd is None:
        return
    try:
        if sys.platform == "win32":
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        try:
            os.close(fd)
        except OSError:
            pass


def _try_acquire_device_lock(device: str) -> Optional[int]:
    """
    非阻塞尝试获取 device 的跨进程锁。成功返回 fd（调用方负责 _release_device_lock），失败返回 None（如已被占用）。
    """
    path = _device_lock_path(device)
    try:
        fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    except OSError:
        return None
    try:
        if sys.platform == "win32":
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
        else:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (OSError, BlockingIOError):
        try:
            os.close(fd)
        except OSError:
            pass
        return None
    return fd

def _content_contains_ctrl_c(text: str) -> bool:
    """是否包含设备回显的 Ctrl+C。"""
    n = text.replace("\x00", "")
    return CTRL_C in n or "^C" in n

def scan_serial_ports() -> list[str]:
    """扫描系统可用串口，并按平台做基础筛选。

    - POSIX：仅保留以 /dev/tty 开头的设备（忽略 /dev/cu.* 等非目标设备）；
    - 其他平台：直接返回 list_ports 结果。
    """
    import serial.tools.list_ports

    ports = [p.device for p in serial.tools.list_ports.comports()]
    if os.name == "posix":
        ports = [d for d in ports if d.startswith("/dev/tty")]
    return ports

def check_port_alive_nonblock(port: str, baudrate: int = 115200, timeout: float = 1.0) -> dict:
    """快速探测串口是否可用（不阻塞）。"""
    res = {"port": port, "baudrate": baudrate, "available": False, "reason": ""}
    fd = _try_acquire_device_lock(port)
    if fd is None:
        res["reason"] = "locked by another process"
        return res
    try:
        s = serial.Serial(port, baudrate, timeout=timeout)
        s.close()
        res["available"] = True
    except Exception as e:
        res["reason"] = str(e)
    finally:
        _release_device_lock(fd)
    return res

class SerialLine():
    def __init__(self, kind: int, text: str):
        self.kind = kind
        self.text = text

    def print(self):
        print(self.text, end="")
    
    def print_debug(self, tag):
        print(f'[{tag}][{self.kind}] {self.text}', end="")

class SerialRW():
    def __init__(self, device: str, baudrate: int = 115200):
        self.device = device
        self.baudrate = baudrate
        self._serial: Optional[serial.Serial] = None
        self._buffer: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None
        self._is_connected = False
        self._stop_reading = False
        self._lock_fd: Optional[int] = None
        self._scan_interval = 0.1

    def _reader_loop(self) -> None:
        while not self._stop_reading and self._serial is not None and self._serial.is_open:
            raw = self._serial.readline()
            if raw:
                try:
                    line = raw.decode("utf-8")
                    if line:
                        self._buffer.put(line)
                except UnicodeDecodeError:
                    continue


    def _forward_with_timeout(self, x, timeout=None):
        if not self._is_connected or self._serial is None:
            raise RuntimeError("not connected")

        # send message
        if x is not None:
            self._serial.write((x + "\n").encode("utf-8"))
            self._serial.flush()

        # receive message
        while True:
            try:
                yield self._buffer.get(timeout=timeout)
            except queue.Empty:
                raise TimeoutError

    def _flag_stopper(self, lines, flag=None, allow_fold=True, max_fold_lines=4):
        if allow_fold:
            def _get_lines(lines):
                fold_cache = []
                for line in lines:
                    fold_cache.append(line)
                    if len(fold_cache) > max_fold_lines:
                        fold_cache.pop(0)
                    yield line, "".join([x.rstrip("\r\n") for x in fold_cache])
        else:
            def _get_lines(lines):
                for line in lines:
                    yield line, line.rstrip("\r\n")
      
        for line, checker in _get_lines(lines):
            yield line
            if flag is not None and flag in checker or (flag == CTRL_C and _content_contains_ctrl_c(checker)):
                return

    def connect(self) -> None:
        if self._is_connected:
            return
        self._lock_fd = _acquire_device_lock(self.device)
        try:
            self._serial = serial.Serial(self.device, self.baudrate, timeout=self._scan_interval)
            if not self._serial.is_open:
                raise RuntimeError(f"无法打开串口 {self.device}")
            self._stop_reading = False
            self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True)
            self._reader_thread.start()
            self._is_connected = True
        except Exception:
            _release_device_lock(self._lock_fd)
            self._lock_fd = None
            raise

    def disconnect(self) -> None:
        if not self._is_connected:
            return
        self._stop_reading = True
        self._buffer.put(None)
        if self._reader_thread is not None and self._reader_thread.is_alive():
            self._reader_thread.join()
        self._reader_thread = None
        if self._serial is not None and self._serial.is_open:
            self._serial.close()
            self._serial = None
        _release_device_lock(self._lock_fd)
        self._lock_fd = None
        self._is_connected = False

    def dry_send(self, x: str) -> None:
        if not self._is_connected or self._serial is None:
            raise RuntimeError("not connected")
        assert x is not None
        self._serial.write((x + "\n").encode("utf-8"))
        self._serial.flush()

    def forward(self, x, flag=None, allow_fold=True, max_fold_lines=4, timeout=None, strip_echo=True):
        lines = self._forward_with_timeout(x, timeout)
        try:
            if strip_echo and x is not None:
                for line in self._flag_stopper(lines, x, allow_fold, max_fold_lines):
                    yield SerialLine(kind='echo', text=line)
            for line in self._flag_stopper(lines, flag, allow_fold, max_fold_lines):
                yield SerialLine(kind='body', text=line)
        except TimeoutError:
            yield SerialLine(kind='error', text='<sdev timeout>\n')
            
    def drain_buffer(self) -> None:
        while True:
            try:
                item = self._buffer.get_nowait()
                if item is None:
                    self._buffer.put(None)
                    return
            except queue.Empty:
                break

def serial_rw(device: str, baudrate: int = 115200):
    return SerialRW(device, baudrate)

if __name__ == "__main__":
    s = serial_rw("/dev/ttyUSB0", 115200)
    s.connect()
    for line in s.forward("ls -l", timeout=1):
        line.print_debug('test 0')
    for line in s.forward("ls -lh", timeout=1):
        line.print_debug('test 1')
    for line in s.forward("cat /proc/meminfo", flag=" #"):
        line.print_debug('test 2')
    for line in s.forward("top", timeout=3):
        line.print_debug('test 3')
    for line in s.forward(CTRL_C, flag=" #", strip_echo=False):
        line.print_debug('test 4')
    s.disconnect()