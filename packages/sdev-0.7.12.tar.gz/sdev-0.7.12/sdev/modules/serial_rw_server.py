from __future__ import annotations

import json
import queue
import socket
import threading
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Generator, Optional, List, Tuple, Dict

from loguru import logger

from .serial_rw import SerialRW, SerialLine, scan_serial_ports, check_port_alive_nonblock

DEFAULT_SERVICE_PORT = 7000
DISCOVERY_UDP_PORT = 7001

_SCAN_DONE = object()


class SerialRWClient:
    """
    远程版 SerialRW：
    - server 端本地操作串口（复用 SerialRW 实现）
    - client 端通过 TCP 与 server 通信，暴露与 SerialRW 一致的接口：connect/disconnect/forward
    """

    def __init__(self, host: str, port: int, device: str, baudrate: int = 115200):
        self.host = host
        self.port = port
        self.device = device
        self.baudrate = baudrate
        self._socket: Optional[socket.socket] = None
        self._buffer: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None
        self._is_connected = False
        self._stop_reading = False
        self._scan_interval = 0.1

    def _read_loop(self) -> None:
        buf = b""
        while not self._stop_reading and self._socket is not None:
            try:
                data = self._socket.recv(4096)
            except socket.timeout:
                # 暂无数据，继续等待
                continue
            except (OSError, ConnectionResetError, BrokenPipeError):
                break
            if not data:
                break
            buf += data
            while b"\n" in buf or (buf and self._stop_reading):
                if b"\n" not in buf:
                    break
                line_b, buf = buf.split(b"\n", 1)
                line = line_b.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(obj, dict):
                    continue
                if obj.get("scan_done") is True:
                    self._buffer.put(_SCAN_DONE)
                    continue
                if "text" in obj:
                    kind = obj.get("kind", "body")
                    self._buffer.put(SerialLine(kind=kind, text=obj["text"]))
        self._buffer.put(_SCAN_DONE)

    def _send_cmd(self, obj: dict[str, Any]) -> None:
        if self._socket is None:
            raise RuntimeError("not connected")
        msg = json.dumps(obj, ensure_ascii=False) + "\n"
        self._socket.sendall(msg.encode("utf-8"))

    def connect(self) -> None:
        if self._is_connected:
            return
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10.0)
        try:
            sock.connect((self.host, self.port))
        except OSError as e:
            raise RuntimeError(f"无法连接 {self.host}:{self.port}: {e}") from e

        init_msg = json.dumps(
            {"device": self.device, "baudrate": self.baudrate},
            ensure_ascii=False,
        ) + "\n"
        sock.sendall(init_msg.encode("utf-8"))

        sock.settimeout(5.0)
        raw = b""
        while b"\n" not in raw:
            try:
                chunk = sock.recv(4096)
            except socket.timeout:
                sock.close()
                raise RuntimeError("等待 host 初始化超时") from None
            if not chunk:
                sock.close()
                raise RuntimeError("host 关闭连接") from None
            raw += chunk

        line = raw.split(b"\n", 1)[0].decode("utf-8", errors="replace")
        try:
            resp = json.loads(line)
        except json.JSONDecodeError:
            sock.close()
            raise RuntimeError("host 返回无效 JSON") from None
        if resp.get("ok") is not True:
            sock.close()
            raise RuntimeError(resp.get("error", "host 拒绝连接"))

        self._socket = sock
        self._socket.settimeout(self._scan_interval)
        self._stop_reading = False
        self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
        self._reader_thread.start()
        self._is_connected = True

    def disconnect(self) -> None:
        if not self._is_connected:
            return
        self._stop_reading = True
        try:
            self._send_cmd({"cmd": "disconnect"})
        except Exception:
            pass
        if self._reader_thread is not None and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=2.0)
        self._reader_thread = None
        if self._socket is not None:
            try:
                self._socket.close()
            except Exception:
                pass
            self._socket = None
        self._is_connected = False

    def drain_buffer(self) -> None:
        while True:
            try:
                item = self._buffer.get_nowait()
                if item is _SCAN_DONE:
                    break
            except queue.Empty:
                break

    def forward(
        self,
        x: Optional[str],
        flag: Optional[str] = None,
        allow_fold: bool = True,
        max_fold_lines: int = 4,
        timeout: Optional[float] = None,
        strip_echo: bool = True,
    ) -> Generator[SerialLine, None, None]:
        """
        与本地 SerialRW.forward 保持一致的接口，返回 SerialLine 迭代器。
        所有参数直接透传给 server 端的 SerialRW.forward。
        """
        if not self._is_connected:
            raise RuntimeError("not connected")

        self._send_cmd(
            {
                "cmd": "forward",
                "x": x,
                "flag": flag,
                "allow_fold": allow_fold,
                "max_fold_lines": max_fold_lines,
                "timeout": timeout,
                "strip_echo": strip_echo,
            }
        )
        # 完全复用服务端 SerialRW.forward 的结束条件（flag/CTRL_C/timeout），
        # client 端不再额外施加截止时间，以保证行为与本地 SerialRW 完全一致。
        while True:
            item = self._buffer.get()
            if item is _SCAN_DONE:
                return
            yield item

class SerialRWServer:
    """
    最小实现的远程串口服务器：
    - 每个 TCP 连接对应一个 SerialRW 会话
    - 首条消息为 {"device": "...", "baudrate": 115200}
    - 之后接受 {"cmd": "forward", ...} 并将 SerialRW.forward 的输出逐行回传
    """

    def __init__(self, port: int = DEFAULT_SERVICE_PORT):
        self.port = port

    @staticmethod
    def _session_loop(conn: socket.socket, addr) -> None:
        dev: Optional[SerialRW] = None
        try:
            buf = b""
            # 读取初始化参数（device/baudrate）
            while b"\n" not in buf:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                buf += chunk
            line = buf.split(b"\n", 1)[0].decode("utf-8", errors="replace")
            try:
                init = json.loads(line)
            except json.JSONDecodeError:
                conn.sendall(b'{"ok":false,"error":"invalid json"}\n')
                return

            # 处理非会话类的管理命令
            if isinstance(init, dict):
                cmd = init.get("cmd")
                if cmd == "list":
                    logger.info(f"[server] list request from {addr}")
                    ports = scan_serial_ports()
                    boards: List[dict] = []
                    if ports:
                        def _probe(p: str):
                            return check_port_alive_nonblock(p, timeout=1.5)
                        with ThreadPoolExecutor(max_workers=min(8, len(ports))) as ex:
                            futs = {ex.submit(_probe, p): p for p in ports}
                            for fut in as_completed(futs):
                                try:
                                    r = fut.result()
                                    boards.append({
                                        "port": r["port"],
                                        "baudrate": r["baudrate"],
                                        "available": r["available"],
                                        "reason": r.get("reason", ""),
                                    })
                                except Exception as e:
                                    logger.error(f"[server] probe error for port: {e}")
                    conn.sendall(json.dumps({"boards": boards}, ensure_ascii=False).encode("utf-8") + b"\n")
                    logger.info(f"[server] list response sent to {addr} (count={len(boards)})")
                    return
                if cmd == "probe":
                    port = (init.get("device") or init.get("port") or "").strip()
                    baudrate = int(init.get("baudrate") or 115200)
                    if not port:
                        conn.sendall(b'{"ok":false,"error":"missing device"}\n')
                        return
                    result = check_port_alive_nonblock(port, baudrate=baudrate, timeout=1.5)
                    conn.sendall(json.dumps({"ok": True, "result": result}, ensure_ascii=False).encode("utf-8") + b"\n")
                    return

            device_val = (init.get("device") or init.get("port") or "").strip()
            baudrate_val = int(init.get("baudrate") or 115200)
            if not device_val:
                conn.sendall(b'{"ok":false,"error":"missing device"}\n')
                return

            logger.info(f"[server] session from {addr}: port={device_val}, baudrate={baudrate_val}")
            dev = SerialRW(device_val, baudrate_val)
            try:
                dev.connect()
                logger.info(f"[server] connected to {device_val} for {addr}")
            except Exception as e:
                logger.error(f"[server] connect failed for {device_val}: {e}")
                err = json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False).encode("utf-8") + b"\n"
                conn.sendall(err)
                return

            conn.sendall(b'{"ok":true}\n')

            # 继续处理后续命令
            buf = buf[buf.index(b"\n") + 1 :]
            while True:
                while b"\n" not in buf:
                    try:
                        chunk = conn.recv(4096)
                    except (ConnectionResetError, BrokenPipeError, OSError):
                        return
                    if not chunk:
                        return
                    buf += chunk
                msg_b, buf = buf.split(b"\n", 1)
                msg = msg_b.decode("utf-8", errors="replace").strip()
                if not msg:
                    continue
                try:
                    obj = json.loads(msg)
                except json.JSONDecodeError:
                    continue

                cmd = (obj or {}).get("cmd")
                if cmd == "disconnect":
                    return
                if cmd == "forward":
                    x = obj.get("x")
                    flag = obj.get("flag")
                    allow_fold = bool(obj.get("allow_fold", True))
                    max_fold_lines = int(obj.get("max_fold_lines", 4))
                    timeout = obj.get("timeout")
                    strip_echo = bool(obj.get("strip_echo", True))

                    for line_obj in dev.forward(
                        x,
                        flag=flag,
                        allow_fold=allow_fold,
                        max_fold_lines=max_fold_lines,
                        timeout=timeout,
                        strip_echo=strip_echo,
                    ):
                        payload = json.dumps(
                            {"kind": line_obj.kind, "text": line_obj.text},
                            ensure_ascii=False,
                        ).encode("utf-8") + b"\n"
                        try:
                            conn.sendall(payload)
                        except (BrokenPipeError, ConnectionResetError, OSError):
                            return
                    try:
                        conn.sendall(b'{"scan_done":true}\n')
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        return
        finally:
            if dev is not None:
                try:
                    dev.disconnect()
                except Exception:
                    pass
            try:
                conn.close()
            except Exception:
                pass

    def serve_forever(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", self.port))
        sock.listen(5)

        # 启动 UDP 发现
        udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        udp_sock.bind(("0.0.0.0", DISCOVERY_UDP_PORT))
        threading.Thread(target=self._discovery_udp_loop, args=(udp_sock, self.port), daemon=True).start()

        # 启动 Zeroconf 发布 (如有)
        self._zeroconf, self._zeroconf_info = self._start_zeroconf(self.port)

        while True:
            conn, addr = sock.accept()
            logger.info(f"[server] TCP connection from {addr}")
            threading.Thread(target=self._session_loop, args=(conn, addr), daemon=True).start()

    @staticmethod
    def _discovery_udp_loop(udp_sock: socket.socket, tcp_port: int) -> None:
        while True:
            try:
                data, addr = udp_sock.recvfrom(4096)
            except OSError:
                break
            if not data or data.strip() != b"SDEV_DISCOVERY":
                continue
            resp = json.dumps({"magic": "sdev-remote-v1", "port": tcp_port}, ensure_ascii=False).encode("utf-8")
            try:
                udp_sock.sendto(resp, addr)
            except OSError:
                continue

    @staticmethod
    def _start_zeroconf(port: int) -> Tuple[Any, Any]:
        if os.environ.get("SDEV_DISABLE_ZEROCONF"):
            return None, None
        try:
            from zeroconf import IPVersion, ServiceInfo, Zeroconf
            host_ip = socket.gethostbyname(socket.gethostname())
            service_type = "_sdev._tcp.local."
            service_name = f"sdev-{host_ip}-{port}.{service_type}"
            info = ServiceInfo(
                type_=service_type,
                name=service_name,
                addresses=[socket.inet_aton(host_ip)],
                port=port,
                properties={},
            )
            zc = Zeroconf(ip_version=IPVersion.V4Only)
            zc.register_service(info)
            return zc, info
        except Exception:
            return None, None

def discover_hosts_via_zeroconf(timeout: float = 0.8) -> List[Tuple[str, int]]:
    if os.environ.get("SDEV_DISABLE_ZEROCONF"):
        return []
    try:
        from zeroconf import ServiceBrowser, ServiceStateChange, Zeroconf
        found: Dict[Tuple[str, int], None] = {}
        def _on_added(zeroconf: Any, service_type: str, name: str, state_change: Any) -> None:
            if state_change is not ServiceStateChange.Added: return
            info = zeroconf.get_service_info(service_type, name, timeout=1000)
            if not info: return
            addrs = getattr(info, "parsed_addresses", lambda: [])()
            if not addrs: return
            found[(addrs[0], int(info.port))] = None
        zc = Zeroconf()
        ServiceBrowser(zc, "_sdev._tcp.local.", handlers=[_on_added])
        time.sleep(timeout)
        zc.close()
        return list(found.keys())
    except Exception:
        return []

def discover_hosts_via_udp(timeout: float = 1.5) -> List[Tuple[str, int]]:
    """
    通过 UDP 广播 / 定向探测发现远程 sdev server：
    - 优先读取环境变量 SDEV_DISCOVERY_TARGETS="host[:port],host2[:port2],..."
      按指定目标发送 discovery 报文；
    - 未指定时，退回到对 255.255.255.255:DISCOVERY_UDP_PORT 的广播。
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(timeout)
        sock.bind(("", 0))

        # 解析 SDEV_DISCOVERY_TARGETS 作为定向探测目标
        targets: List[Tuple[str, int]] = []
        raw = os.environ.get("SDEV_DISCOVERY_TARGETS", "").strip()
        if raw:
            for item in raw.split(","):
                item = item.strip()
                if not item:
                    continue
                if ":" in item:
                    h, ps = item.rsplit(":", 1)
                    try:
                        targets.append((h.strip(), int(ps)))
                    except ValueError:
                        targets.append((h.strip(), DISCOVERY_UDP_PORT))
                else:
                    targets.append((item, DISCOVERY_UDP_PORT))
        if not targets:
            targets.append(("255.255.255.255", DISCOVERY_UDP_PORT))

        for host, port in targets:
            try:
                sock.sendto(b"SDEV_DISCOVERY", (host, port))
            except OSError:
                continue

        hosts: set = set()
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                sock.settimeout(max(0.0, deadline - time.monotonic()))
                data, addr = sock.recvfrom(4096)
                if not data:
                    continue
                obj = json.loads(data.decode("utf-8"))
                if obj.get("magic") == "sdev-remote-v1":
                    hosts.add((addr[0], int(obj.get("port") or DEFAULT_SERVICE_PORT)))
            except Exception:
                continue
        return list(hosts)
    finally:
        sock.close()

def fetch_boards_from_host(host: str, port: int, timeout: float = 5.0) -> List[Dict[str, Any]]:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))
        sock.sendall(b'{"cmd":"list"}\n')
        buf = b""
        while b"\n" not in buf:
            chunk = sock.recv(4096)
            if not chunk: break
            buf += chunk
        sock.close()
        boards = json.loads(buf.decode("utf-8")).get("boards", [])
        for b in boards: b["host"] = host
        return boards
    except Exception:
        return []

def get_remote_hosts(service_port: int = DEFAULT_SERVICE_PORT) -> List[Tuple[str, int]]:
    raw = os.environ.get("SDEV_REMOTE_HOSTS", "").strip()
    if raw:
        out = []
        for s in raw.split(","):
            if ":" in s:
                h, p = s.rsplit(":", 1)
                out.append((h.strip(), int(p)))
            else:
                out.append((s.strip(), service_port))
        return out
    merged = set(discover_hosts_via_udp() + discover_hosts_via_zeroconf())
    return list(merged)


def _server_log_path() -> str:
    """
    与 CLI `_server_log_path` 保持一致：
    - 优先使用 XDG_RUNTIME_DIR/sdev/server.log
    - 否则使用 ~/.cache/sdev/server.log
    """
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(os.path.expanduser("~"), ".cache")
    d = os.path.join(base, "sdev")
    os.makedirs(d, mode=0o700, exist_ok=True)
    return os.path.join(d, "server.log")


def main() -> int:
    import sys

    port = DEFAULT_SERVICE_PORT
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass

    # 与旧实现保持一致的日志行为：只写到 server.log，不打印到前台。
    log_path = _server_log_path()
    logger.remove()
    logger.add(
        log_path,
        rotation="1 MB",
        retention=5,
        encoding="utf-8",
        enqueue=True,
        backtrace=False,
        diagnose=False,
    )
    logger.info(f"[server] listening TCP 0.0.0.0:{port}, UDP 0.0.0.0:{DISCOVERY_UDP_PORT}")

    server = SerialRWServer(port=port)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
