"""Main client for MemoryLayer.ai SDK."""

import json
import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

import httpx
from pydantic import TypeAdapter

from ._transport import (
    AetherTransport,
    HttpTransport,
    Transport,
)
from .exceptions import (
    AuthenticationError,
    AuthorizationError,
    EnterpriseRequiredError,
    MemoryLayerError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .knowledgebase import KnowledgebaseAPI
from .mcp_servers import McpServersAPI
from .models import (
    Association,
    AuthorityContext,
    ChatMessage,
    ChatThread,
    ChatThreadWithMessages,
    DatasetInfo,
    DatasetJobInfo,
    DatasetSliceResult,
    DecompositionResult,
    DocumentInfo,
    DocumentPage,
    JobInfo,
    Memory,
    PageSearchResult,
    RecallResult,
    ReflectResult,
    Session,
    SessionBriefing,
    Workspace,
)
from .skills import SkillsAPI
from .types import (
    MemoryType,
    RecallMode,
    RelationshipType,
    SearchTolerance,
)

logger = logging.getLogger(__name__)


def _to_value(v: Any) -> Any:
    """Extract string value from an enum member, or return string as-is."""
    return v.value if hasattr(v, "value") else v


class MemoryLayerClient:
    """
    Python client for MemoryLayer.ai API.

    Usage:
        async with MemoryLayerClient(
            base_url="https://api.memorylayer.ai",
            api_key="your-api-key",
            workspace_id="ws_123"
        ) as client:
            # Store a memory
            memory = await client.remember(
                content="User prefers Python",
                type=MemoryType.SEMANTIC,
                importance=0.8
            )

            # Search memories
            results = await client.recall("coding preferences")

            # Reflect on memories
            reflection = await client.reflect("summarize user preferences")
    """

    def __init__(
        self,
        base_url: str = "http://localhost:61001",
        api_key: str | None = None,
        workspace_id: str | None = None,
        session_id: str | None = None,
        timeout: float = 30.0,
        default_authority: AuthorityContext | None = None,
        *,
        transport: str | Transport = "http",
        aether_client: Any = None,
        aether_target: str = "sv::memorylayer::default",
    ):
        """
        Initialize MemoryLayer client.

        Args:
            base_url: API base URL (default: http://localhost:61001).  Used
                only by the HTTP transport.
            api_key: API key for authentication
            workspace_id: Default workspace ID for operations
            session_id: Session ID for session-based workspace resolution
            timeout: Request timeout in seconds (default: 30.0)
            default_authority: Default OBO authority applied to every request
            transport: ``"http"`` (default; direct httpx) or ``"aether"``
                (route via ``proxy_http_async`` on a shared Aether SDK
                connection).  May also be a custom ``Transport`` instance
                for tests / advanced cases.
            aether_client: Required when ``transport='aether'``.  An
                ``AsyncAgentClient`` or ``AsyncServiceClient`` from
                ``scitrera_aether_client`` that is already connected.  The
                SDK does NOT own this client (lifecycle is the caller's).
            aether_target: Target topic for Aether transport (default
                ``sv::memorylayer::default``).
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.workspace_id = workspace_id
        self.session_id = session_id
        self.timeout = timeout
        self.default_authority = default_authority
        self._transport_kind = transport
        self._aether_client = aether_client
        self._aether_target = aether_target
        # ``self._client`` remains a public-ish attribute used by the small
        # set of bespoke httpx paths in this file (file uploads, NDJSON
        # streaming).  HTTP transport sets it to its underlying httpx client;
        # Aether transport leaves it None and those paths raise.
        self._client: httpx.AsyncClient | None = None
        self._transport: Transport | None = None
        if transport == "aether" and aether_client is None:
            raise ValueError(
                "transport='aether' requires aether_client (an AsyncAgentClient or AsyncServiceClient with a live gateway connection)"
            )
        self.skills = SkillsAPI(self)
        self.mcp_servers = McpServersAPI(self)
        self.kb = KnowledgebaseAPI(self)

    async def __aenter__(self) -> "MemoryLayerClient":
        """Async context manager entry."""
        if isinstance(self._transport_kind, str):
            if self._transport_kind == "http":
                http = HttpTransport(
                    base_url=f"{self.base_url}/v1",
                    api_key=self.api_key,
                    session_id=self.session_id,
                    timeout=self.timeout,
                )
                self._transport = http
                self._client = http.httpx_client
            elif self._transport_kind == "aether":
                self._transport = AetherTransport(
                    aether_client=self._aether_client,
                    target=self._aether_target,
                    api_key=self.api_key,
                    session_id=self.session_id,
                    timeout=self.timeout,
                )
            else:
                raise ValueError(f"Unknown transport: {self._transport_kind!r} (expected 'http' or 'aether', or a Transport instance)")
        else:
            # Custom Transport instance — caller owns it.
            self._transport = self._transport_kind
        return self

    def set_session(self, session_id: str) -> None:
        """
        Set the active session ID.

        All subsequent requests will include this session ID in the
        X-Session-ID header, enabling session-based workspace resolution.

        Note: If called after entering the context manager, updates
        the underlying client headers.

        Args:
            session_id: Session ID to use
        """
        self.session_id = session_id
        if self._transport is not None and hasattr(self._transport, "set_session"):
            self._transport.set_session(session_id)
        elif self._client:
            self._client.headers["X-Session-ID"] = session_id

    def clear_session(self) -> None:
        """
        Clear the active session ID.
        """
        self.session_id = None
        if self._transport is not None and hasattr(self._transport, "clear_session"):
            self._transport.clear_session()
        elif self._client and "X-Session-ID" in self._client.headers:
            del self._client.headers["X-Session-ID"]

    def get_session_id(self) -> str | None:
        """
        Get the current session ID, if any.

        Returns:
            Current session ID or None
        """
        return self.session_id

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit.

        For HTTP transport this closes the underlying httpx client.  For
        Aether transport this is a no-op — the SDK does not own the
        ``aether_client`` connection.
        """
        if self._transport is not None:
            await self._transport.aclose()
            self._transport = None
        self._client = None

    def _ensure_client(self) -> httpx.AsyncClient:
        """Return the underlying ``httpx.AsyncClient`` (HTTP transport only).

        Most SDK paths now flow through ``self._transport`` (which works on
        both HTTP and Aether transports — including multipart uploads and
        NDJSON streaming after Phase 5.1).  This escape hatch remains for
        any future caller that genuinely needs raw httpx semantics
        (e.g. response.aiter_bytes streaming).  It raises if the SDK isn't
        entered or if the active transport isn't HTTP.
        """
        if self._transport is None:
            raise RuntimeError("Client not initialized. Use async with context manager.")
        if self._client is None:
            raise NotImplementedError("This SDK code path requires the HTTP transport. Construct the client with transport='http' for now.")
        return self._client

    def _ensure_transport(self) -> Transport:
        """Ensure the transport is initialized (works for any transport)."""
        if self._transport is None:
            raise RuntimeError("Client not initialized. Use async with context manager.")
        return self._transport

    @staticmethod
    def _encode_multipart(
        files: dict[str, tuple[str, bytes]],
        data: dict[str, str],
    ) -> tuple[bytes, str]:
        """Serialize a multipart/form-data body without depending on the transport.

        Uses ``httpx.Request`` (already a hard dep) to build the multipart bytes
        and read back the ``content-type`` header (with boundary). Both transports
        then ship the raw bytes and the caller-provided content-type — no
        transport-specific multipart machinery required, which means the
        multipart upload paths work over Aether transport too.

        Returns:
            (content_bytes, content_type_header) — pass ``content=content_bytes``
            and ``headers={"content-type": content_type_header}`` to
            ``Transport.request``.
        """
        req = httpx.Request("POST", "http://_local/_multipart", files=files, data=data)
        # ``files=`` makes the body a streaming iterator; ``read()`` materializes
        # it so we can ship the bytes through any transport unchanged.
        return req.read(), req.headers["content-type"]

    def _obo_headers(self, authority: AuthorityContext | None) -> dict[str, str]:
        """Build X-Aether-* OBO headers from an AuthorityContext."""
        effective = authority or self.default_authority
        if effective is None:
            return {}
        headers: dict[str, str] = {"X-Aether-Grant-ID": effective.grant_id}
        if effective.subject is not None:
            headers["X-Aether-Authority-Mode"] = "on_behalf_of"
            headers["X-Aether-Subject-Type"] = effective.subject.type
            headers["X-Aether-Subject-ID"] = effective.subject.id
        else:
            headers["X-Aether-Authority-Mode"] = "direct"
        return headers

    @asynccontextmanager
    async def acting_for(
        self,
        grant_id: str,
        subject: tuple[str, str] | None = None,
    ):  # type: ignore[return]
        """
        Async context manager that returns a proxy with OBO authority baked in.

        All requests made through the proxy include X-Aether-* headers for the
        given grant and subject without mutating the underlying httpx client.

        Args:
            grant_id: Aether authority grant ID
            subject: (type, id) tuple, e.g. ("user", "alice")

        Example:
            async with client.acting_for("g_abc", subject=("user", "alice")) as alice:
                await alice.recall("preferences", workspace_id="ws_work")
        """
        from .models import PrincipalRef

        principal = PrincipalRef(type=subject[0], id=subject[1]) if subject is not None else None
        authority = AuthorityContext(grant_id=grant_id, subject=principal)
        yield _OBOProxy(self, authority=authority, workspace_id=self.workspace_id)

    def for_workspace(self, workspace_id: str) -> "_OBOProxy":
        """
        Return a proxy with workspace_id baked in (uses client's default_authority).

        Args:
            workspace_id: Workspace ID to use for all operations on this proxy
        """
        return _OBOProxy(self, authority=self.default_authority, workspace_id=workspace_id)

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        enterprise_feature: str | None = None,
        authority: AuthorityContext | None = None,
    ) -> dict[str, Any]:
        """
        Make HTTP request with error handling.

        Args:
            method: HTTP method
            path: API path
            json: JSON body
            params: Query parameters
            enterprise_feature: If set, a 404 raises EnterpriseRequiredError
                instead of NotFoundError, indicating the feature needs Enterprise.
            authority: Per-request OBO authority (overrides default_authority)

        Returns:
            Response JSON

        Raises:
            AuthenticationError: Authentication failed (401)
            EnterpriseRequiredError: Enterprise-only endpoint (404 + enterprise_feature)
            NotFoundError: Resource not found (404)
            ValidationError: Validation failed (422)
            RateLimitError: Rate limit exceeded (429)
            ServerError: Server error (5xx)
            MemoryLayerError: Other errors
        """
        transport = self._ensure_transport()
        obo_headers = self._obo_headers(authority)

        try:
            response = await transport.request(method, path, json=json, params=params, headers=obo_headers)

            # Handle errors
            if response.status_code == 401:
                raise AuthenticationError(response.json().get("detail", "Authentication failed"))
            elif response.status_code == 403:
                raise AuthorizationError(response.json().get("detail", "Authorization denied"))
            elif response.status_code == 404:
                raise NotFoundError(response.json().get("detail", "Resource not found"))
            elif response.status_code == 501:
                if enterprise_feature:
                    raise EnterpriseRequiredError(feature=enterprise_feature)
                raise NotFoundError(response.json().get("detail", "Not implemented"))
            elif response.status_code == 422:
                raise ValidationError(response.json().get("detail", "Validation error"))
            elif response.status_code == 429:
                raise RateLimitError(response.json().get("detail", "Rate limit exceeded"))
            elif response.status_code >= 500:
                raise ServerError(
                    response.json().get("detail", "Server error"),
                    status_code=response.status_code,
                )
            elif response.status_code >= 400:
                raise MemoryLayerError(
                    response.json().get("detail", "Request failed"),
                    status_code=response.status_code,
                )

            response.raise_for_status()

            # Handle No Content responses
            if response.status_code == 204:
                return {}

            return response.json()

        except httpx.TimeoutException as e:
            raise MemoryLayerError(f"Request timeout: {e}") from e
        except httpx.HTTPError as e:
            raise MemoryLayerError(f"HTTP error: {e}") from e

    # Core memory operations

    async def remember(
        self,
        content: str,
        type: str | MemoryType | None = None,
        subtype: str | None = None,
        importance: float = 0.5,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        context_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        authority: AuthorityContext | None = None,
    ) -> Memory:
        """
        Store a new memory.

        Args:
            content: Memory content to store
            type: Cognitive memory type (episodic, semantic, procedural, working)
            subtype: Domain subtype (Solution, Problem, etc.)
            importance: Importance score 0.0-1.0 (default: 0.5)
            tags: Tags for categorization
            metadata: Additional metadata
            context_id: Optional context ID

        Returns:
            Created memory

        Example:
            memory = await client.remember(
                content="User prefers concise code comments",
                type=MemoryType.SEMANTIC,
                subtype="preference",
                importance=0.8,
                tags=["preferences", "coding-style"]
            )
        """
        payload = {
            "content": content,
            "importance": importance,
        }
        if type:
            payload["type"] = _to_value(type)
        if subtype:
            payload["subtype"] = _to_value(subtype)
        if tags:
            payload["tags"] = tags
        if metadata:
            payload["metadata"] = metadata
        if context_id:
            payload["context_id"] = context_id
        if user_id is not None:
            payload["user_id"] = user_id
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            payload["workspace_id"] = ws_id

        data = await self._request("POST", "/memories", json=payload, authority=authority)
        return Memory(**data["memory"])

    async def recall(
        self,
        query: str,
        types: list[str | MemoryType] | None = None,
        subtypes: list[str] | None = None,
        tags: list[str] | None = None,
        mode: str | RecallMode | None = None,
        limit: int = 10,
        min_relevance: float | None = None,
        recency_weight: float | None = None,
        tolerance: str | SearchTolerance | None = None,
        include_associations: bool | None = None,
        traverse_depth: int | None = None,
        max_expansion: int | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        authority: AuthorityContext | None = None,
    ) -> RecallResult:
        """
        Search memories by semantic query.

        Args:
            query: Natural language search query
            types: Filter by cognitive memory types
            subtypes: Filter by domain subtypes
            tags: Filter by tags
            mode: Retrieval mode (rag, llm, hybrid). None = server default.
            limit: Maximum memories to return (default: 10)
            min_relevance: Minimum relevance score 0.0-1.0 (None = server default)
            recency_weight: Weight for recency in ranking 0.0-1.0 (None = server default)
            tolerance: Search tolerance (loose, moderate, strict). None = server default.
            include_associations: Include linked memories (None = server default)
            traverse_depth: Multi-hop graph traversal depth (None = server default)
            max_expansion: Max memories discovered via graph expansion (None = server default)

        Returns:
            Recall results with memories

        Example:
            results = await client.recall(
                query="what are the user's coding preferences?",
                types=[MemoryType.SEMANTIC, MemoryType.PROCEDURAL],
                limit=5,
                min_relevance=0.7
            )
        """
        payload: dict = {
            "query": query,
            "limit": limit,
        }
        if mode is not None:
            payload["mode"] = _to_value(mode)
        if tolerance is not None:
            payload["tolerance"] = _to_value(tolerance)
        if include_associations is not None:
            payload["include_associations"] = include_associations
        if traverse_depth is not None:
            payload["traverse_depth"] = traverse_depth
        if min_relevance is not None:
            payload["min_relevance"] = min_relevance
        if recency_weight is not None:
            payload["recency_weight"] = recency_weight
        if max_expansion is not None:
            payload["max_expansion"] = max_expansion
        if types:
            payload["types"] = [_to_value(t) for t in types]
        if subtypes:
            payload["subtypes"] = [_to_value(s) for s in subtypes]
        if tags:
            payload["tags"] = tags
        if created_after is not None:
            payload["created_after"] = created_after
        if created_before is not None:
            payload["created_before"] = created_before
        if user_id is not None:
            payload["user_id"] = user_id
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            payload["workspace_id"] = ws_id

        data = await self._request("POST", "/memories/recall", json=payload, authority=authority)

        # Parse memories
        memories_adapter = TypeAdapter(list[Memory])
        memories = memories_adapter.validate_python(data.get("memories", []))

        return RecallResult(
            memories=memories,
            total_count=data.get("total_count", len(memories)),
            query_tokens=data.get("query_tokens"),
            search_latency_ms=data.get("search_latency_ms"),
        )

    async def reflect(
        self,
        query: str,
        max_tokens: int = 500,
        include_sources: bool = True,
        authority: AuthorityContext | None = None,
    ) -> ReflectResult:
        """
        Synthesize and summarize memories.

        Args:
            query: What to reflect on
            max_tokens: Maximum tokens in reflection (default: 500)
            include_sources: Include source memory IDs (default: True)
            authority: Per-request OBO authority

        Returns:
            Reflection result with synthesis

        Example:
            reflection = await client.reflect(
                query="summarize everything about user's development workflow",
                max_tokens=300
            )
        """
        payload = {
            "query": query,
            "max_tokens": max_tokens,
            "include_sources": include_sources,
        }

        data = await self._request("POST", "/memories/reflect", json=payload, authority=authority)
        return ReflectResult(**data)

    async def forget(
        self,
        memory_id: str,
        hard: bool = False,
    ) -> bool:
        """
        Delete or soft-delete a memory.

        Args:
            memory_id: ID of memory to forget
            hard: Permanently delete (default: False for soft delete)

        Returns:
            True if successful

        Example:
            await client.forget("mem_123", hard=False)
        """
        params = {"hard": "true" if hard else "false"}
        await self._request("DELETE", f"/memories/{memory_id}", params=params)
        return True

    async def get_memory(self, memory_id: str) -> Memory:
        """
        Get a specific memory by ID.

        Args:
            memory_id: Memory ID

        Returns:
            Memory object

        Example:
            memory = await client.get_memory("mem_123")
        """
        data = await self._request("GET", f"/memories/{memory_id}")
        return Memory(**data["memory"])

    async def update_memory(
        self,
        memory_id: str,
        content: str | None = None,
        importance: float | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Memory:
        """
        Update an existing memory.

        Args:
            memory_id: Memory ID
            content: New content (optional)
            importance: New importance score (optional)
            tags: New tags (optional)
            metadata: New metadata (optional)

        Returns:
            Updated memory

        Example:
            memory = await client.update_memory(
                "mem_123",
                importance=0.9,
                tags=["preferences", "high-priority"]
            )
        """
        payload = {}
        if content is not None:
            payload["content"] = content
        if importance is not None:
            payload["importance"] = importance
        if tags is not None:
            payload["tags"] = tags
        if metadata is not None:
            payload["metadata"] = metadata

        data = await self._request("PUT", f"/memories/{memory_id}", json=payload)
        return Memory(**data["memory"])

    # Association methods

    async def associate(
        self,
        source_id: str,
        target_id: str,
        relationship: str | RelationshipType,
        strength: float = 0.5,
        metadata: dict[str, Any] | None = None,
    ) -> Association:
        """
        Link two memories with a relationship.

        Args:
            source_id: Source memory ID
            target_id: Target memory ID
            relationship: Relationship type (string or RelationshipType enum)
            strength: Relationship strength 0.0-1.0 (default: 0.5)
            metadata: Additional metadata

        Returns:
            Created association

        Example:
            assoc = await client.associate(
                source_id="mem_123",
                target_id="mem_456",
                relationship=RelationshipType.SOLVES,
                strength=0.9
            )
        """
        rel_value = _to_value(relationship)
        payload = {
            "target_id": target_id,
            "relationship": rel_value,
            "strength": strength,
        }
        if metadata:
            payload["metadata"] = metadata

        data = await self._request("POST", f"/memories/{source_id}/associate", json=payload)
        return Association(**data)

    async def get_associations(
        self,
        memory_id: str,
        direction: str = "both",
    ) -> list[Association]:
        """
        Get associations for a memory.

        Args:
            memory_id: Memory ID
            direction: "outgoing", "incoming", or "both" (default: "both")

        Returns:
            List of associations

        Example:
            associations = await client.get_associations("mem_123")
        """
        params = {"direction": direction}
        data = await self._request("GET", f"/memories/{memory_id}/associations", params=params)

        associations_adapter = TypeAdapter(list[Association])
        return associations_adapter.validate_python(data.get("associations", []))

    # Session methods

    async def create_session(
        self,
        ttl_seconds: int = 3600,
        workspace_id: str | None = None,
        context_id: str | None = None,
        auto_set_session: bool = True,
    ) -> Session:
        """
        Create a new working memory session.

        Workspaces and contexts are auto-created if they don't exist,
        enabling a "just works" experience for new projects.

        Args:
            ttl_seconds: Time to live in seconds (default: 3600 = 1 hour)
            workspace_id: Workspace ID (auto-created if doesn't exist)
            context_id: Context ID (defaults to _default, auto-created if needed)
            auto_set_session: If True (default), automatically set this session
                              as the active session for subsequent requests

        Returns:
            Created session

        Example:
            session = await client.create_session(ttl_seconds=7200)
            # Or with custom workspace (auto-created from git repo name):
            session = await client.create_session(workspace_id="my-project")
        """
        payload: dict[str, Any] = {"ttl_seconds": ttl_seconds}
        if workspace_id:
            payload["workspace_id"] = workspace_id
        if context_id:
            payload["context_id"] = context_id
        data = await self._request("POST", "/sessions", json=payload)
        # Handle response format: {session: {...}} or direct session object
        if "session" in data:
            session = Session(**data["session"])
        else:
            session = Session(**data)

        if auto_set_session:
            self.set_session(session.id)

        return session

    async def get_session(self, session_id: str) -> Session:
        """
        Get a session by ID.

        Args:
            session_id: Session ID

        Returns:
            Session object
        """
        data = await self._request("GET", f"/sessions/{session_id}")
        return Session(**data)

    async def set_context(
        self,
        session_id: str,
        key: str,
        value: Any,
        ttl_seconds: int | None = None,
    ) -> None:
        """
        Set a context value in a session.

        Args:
            session_id: Session ID
            key: Context key
            value: Context value (any JSON-serializable object)
            ttl_seconds: Optional TTL for this key

        Example:
            await client.set_context(
                "sess_123",
                "current_file",
                {"path": "auth.py", "line": 42}
            )
        """
        payload = {
            "key": key,
            "value": value,
        }
        if ttl_seconds is not None:
            payload["ttl_seconds"] = ttl_seconds

        await self._request("POST", f"/sessions/{session_id}/memory", json=payload)

    async def get_context(
        self,
        session_id: str,
        keys: list[str],
    ) -> dict[str, Any]:
        """
        Get context values from a session.

        Args:
            session_id: Session ID
            keys: List of keys to retrieve

        Returns:
            Dictionary of key-value pairs

        Example:
            context = await client.get_context(
                "sess_123",
                ["current_file", "user_intent"]
            )
        """
        params = {"key": ",".join(keys)}
        data = await self._request("GET", f"/sessions/{session_id}/memory", params=params)
        return data

    async def get_briefing(
        self,
        lookback_hours: int | None = None,
        lookback_minutes: int = 60,
        detail_level: str = "abstract",
        limit: int = 10,
        include_memories: bool = True,
        include_contradictions: bool = True,
    ) -> SessionBriefing:
        """
        Get a session briefing with recent activity and context.

        Args:
            lookback_hours: DEPRECATED - Use lookback_minutes instead. If provided, overrides lookback_minutes.
            lookback_minutes: Time window in minutes for recent memories (default: 60)
            detail_level: Level of memory detail - "abstract", "overview", or "full" (default: "abstract")
            limit: Maximum number of recent memories to include (default: 10)
            include_memories: Whether to include recent memory content (default: True)
            include_contradictions: Flag contradicting memories in briefing (default: True)

        Returns:
            Session briefing

        Example:
            briefing = await client.get_briefing(lookback_minutes=120, detail_level="full")
        """
        params = {
            "lookback_minutes": lookback_hours * 60 if lookback_hours is not None else lookback_minutes,
            "detail_level": detail_level,
            "limit": limit,
            "include_memories": str(include_memories).lower(),
            "include_contradictions": str(include_contradictions).lower(),
        }
        data = await self._request("GET", "/sessions/briefing", params=params)
        return SessionBriefing(**data)

    # Workspace methods

    async def create_workspace(self, name: str) -> Workspace:
        """
        Create a new workspace.

        Args:
            name: Workspace name

        Returns:
            Created workspace

        Example:
            workspace = await client.create_workspace("my-project")
        """
        payload = {"name": name}
        data = await self._request("POST", "/workspaces", json=payload)
        return Workspace(**data)

    async def get_workspace(self, workspace_id: str | None = None) -> Workspace:
        """
        Get workspace details.

        Args:
            workspace_id: Workspace ID (uses default if not provided)

        Returns:
            Workspace object

        Example:
            workspace = await client.get_workspace()
        """
        ws_id = workspace_id or self.workspace_id
        if not ws_id:
            raise ValueError("workspace_id must be provided or set on client")

        data = await self._request("GET", f"/workspaces/{ws_id}")
        return Workspace(**data)

    async def update_workspace(
        self,
        workspace_id: str,
        name: str | None = None,
        settings: dict[str, Any] | None = None,
    ) -> Workspace:
        """
        Update an existing workspace.

        Args:
            workspace_id: Workspace ID
            name: New workspace name (optional)
            settings: New workspace settings (optional)

        Returns:
            Updated workspace

        Example:
            workspace = await client.update_workspace(
                "ws_123",
                name="New Name",
                settings={"key": "value"}
            )
        """
        payload = {}
        if name is not None:
            payload["name"] = name
        if settings is not None:
            payload["settings"] = settings

        data = await self._request("PUT", f"/workspaces/{workspace_id}", json=payload)
        return Workspace(**data.get("workspace", data))

    async def create_context(
        self,
        workspace_id: str,
        name: str,
        description: str | None = None,
        settings: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Create a context within a workspace.

        Contexts provide logical grouping of memories (e.g., by project, topic).

        Args:
            workspace_id: Parent workspace ID
            name: Context name
            description: Context description (optional)
            settings: Context settings (optional)

        Returns:
            Created context

        Example:
            context = await client.create_context(
                "ws_123",
                name="project-alpha",
                description="Memories for Project Alpha"
            )
        """
        payload: dict[str, Any] = {"name": name}
        if description is not None:
            payload["description"] = description
        if settings is not None:
            payload["settings"] = settings

        data = await self._request("POST", f"/workspaces/{workspace_id}/contexts", json=payload)
        return data.get("context", data)

    async def list_contexts(self, workspace_id: str) -> list[dict[str, Any]]:
        """
        List all contexts in a workspace.

        Args:
            workspace_id: Workspace ID

        Returns:
            List of contexts

        Example:
            contexts = await client.list_contexts("ws_123")
        """
        data = await self._request("GET", f"/workspaces/{workspace_id}/contexts")
        return data.get("contexts", [])

    async def get_workspace_schema(self, workspace_id: str) -> dict[str, Any]:
        """
        Get workspace schema including relationship types and memory subtypes.

        Args:
            workspace_id: Workspace ID

        Returns:
            Schema with relationship_types, memory_subtypes, and can_customize flag

        Example:
            schema = await client.get_workspace_schema("ws_123")
            print(schema["relationship_types"])
        """
        return await self._request("GET", f"/workspaces/{workspace_id}/schema")

    async def export_workspace(
        self,
        workspace_id: str | None = None,
        include_associations: bool = True,
        offset: int = 0,
        limit: int = 0,
    ) -> dict:
        """Export workspace memories and associations as JSON.

        Args:
            workspace_id: Workspace to export (uses default if not specified)
            include_associations: Whether to include associations
            offset: Skip first N memories (default: 0)
            limit: Maximum memories to export (default: 0 = all)

        Returns:
            Export data dictionary with memories and associations

        Example:
            data = await client.export_workspace("ws_123")
            print(f"Exported {len(data['memories'])} memories")
        """
        ws_id = workspace_id or self.workspace_id
        if not ws_id:
            raise ValueError("Workspace ID required")
        params = {
            "include_associations": str(include_associations).lower(),
            "offset": str(offset),
            "limit": str(limit),
        }

        # Fetch raw NDJSON response via the transport (works on HTTP + Aether).
        transport = self._ensure_transport()
        response = await transport.request("GET", f"/workspaces/{ws_id}/export", params=params)

        # Handle errors
        if response.status_code >= 400:
            if response.status_code == 401:
                raise AuthenticationError(response.json().get("detail", "Authentication failed"))
            elif response.status_code == 404:
                raise NotFoundError(response.json().get("detail", "Resource not found"))
            elif response.status_code == 422:
                raise ValidationError(response.json().get("detail", "Validation error"))
            else:
                raise MemoryLayerError(
                    response.json().get("detail", "Request failed"),
                    status_code=response.status_code,
                )

        response.raise_for_status()

        # Parse NDJSON response
        import json

        text = response.text
        lines = [line.strip() for line in text.strip().split("\n") if line.strip()]

        header = None
        memories = []
        associations = []

        for line in lines:
            parsed = json.loads(line)
            if parsed.get("type") == "header":
                header = parsed
            elif parsed.get("type") == "memory":
                memories.append(parsed["data"])
            elif parsed.get("type") == "association":
                associations.append(parsed["data"])

        # Build backward-compatible response
        return {
            "version": header.get("version", "1.0") if header else "1.0",
            "workspace_id": header.get("workspace_id", ws_id) if header else ws_id,
            "exported_at": header.get("exported_at", "") if header else "",
            "total_memories": header.get("total_memories", len(memories)) if header else len(memories),
            "total_associations": header.get("total_associations", len(associations)) if header else len(associations),
            "memories": memories,
            "associations": associations,
        }

    async def import_workspace(
        self,
        workspace_id: str,
        data: dict,
    ) -> dict:
        """Import memories and associations into a workspace.

        Args:
            workspace_id: Target workspace ID
            data: Export data dictionary (from export_workspace)

        Returns:
            Import results with counts of imported/skipped/errors

        Example:
            result = await client.import_workspace("ws_123", export_data)
            print(f"Imported {result['imported']} memories")
        """
        response = await self._request("POST", f"/workspaces/{workspace_id}/import", json={"data": data})
        return response

    async def export_workspace_stream(
        self,
        workspace_id: str | None = None,
        include_associations: bool = True,
        offset: int = 0,
        limit: int = 0,
    ) -> AsyncGenerator[dict, None]:
        """Export workspace as streaming NDJSON.

        Yields parsed JSON objects line-by-line (header, memory, association, footer).

        Args:
            workspace_id: Workspace to export (uses default if not specified)
            include_associations: Whether to include associations
            offset: Skip first N memories (default: 0)
            limit: Maximum memories to export (default: 0 = all)

        Yields:
            Parsed JSON objects from NDJSON stream

        Example:
            async for line in client.export_workspace_stream("ws_123"):
                if line["type"] == "memory":
                    print(f"Memory: {line['data']['content']}")
        """
        ws_id = workspace_id or self.workspace_id
        if not ws_id:
            raise ValueError("Workspace ID required")
        params = {
            "include_associations": str(include_associations).lower(),
            "offset": str(offset),
            "limit": str(limit),
        }

        transport = self._ensure_transport()
        response = await transport.request("GET", f"/workspaces/{ws_id}/export", params=params)

        if response.status_code >= 400:
            if response.status_code == 401:
                raise AuthenticationError(response.json().get("detail", "Authentication failed"))
            elif response.status_code == 404:
                raise NotFoundError(response.json().get("detail", "Resource not found"))
            elif response.status_code == 422:
                raise ValidationError(response.json().get("detail", "Validation error"))
            else:
                raise MemoryLayerError(
                    response.json().get("detail", "Request failed"),
                    status_code=response.status_code,
                )

        response.raise_for_status()

        text = response.text
        lines = [line.strip() for line in text.strip().split("\n") if line.strip()]

        for line in lines:
            yield json.loads(line)

    async def import_workspace_stream(
        self,
        workspace_id: str,
        ndjson_lines: list[dict],
    ) -> dict:
        """Import workspace from NDJSON format.

        Args:
            workspace_id: Target workspace ID
            ndjson_lines: List of dicts to serialize as NDJSON

        Returns:
            Import results with counts of imported/skipped/errors

        Example:
            lines = [
                {"type": "header", "version": "1.0", ...},
                {"type": "memory", "data": {...}},
            ]
            result = await client.import_workspace_stream("ws_123", lines)
            print(f"Imported {result['imported']} memories")
        """
        # Serialize to NDJSON
        ndjson_body = "\n".join(json.dumps(line) for line in ndjson_lines)

        transport = self._ensure_transport()
        response = await transport.request(
            "POST",
            f"/workspaces/{workspace_id}/import",
            content=ndjson_body,
            headers={"Content-Type": "application/x-ndjson"},
        )

        if response.status_code >= 400:
            if response.status_code == 401:
                raise AuthenticationError(response.json().get("detail", "Authentication failed"))
            elif response.status_code == 404:
                raise NotFoundError(response.json().get("detail", "Resource not found"))
            elif response.status_code == 422:
                raise ValidationError(response.json().get("detail", "Validation error"))
            else:
                raise MemoryLayerError(
                    response.json().get("detail", "Request failed"),
                    status_code=response.status_code,
                )

        response.raise_for_status()
        return response.json()

    # Memory extension operations

    async def decay(
        self,
        memory_id: str,
        decay_rate: float = 0.1,
    ) -> Memory:
        """
        Reduce memory importance by decay rate.

        Args:
            memory_id: Memory ID
            decay_rate: Rate of decay 0.0-1.0 (default: 0.1)

        Returns:
            Updated memory with decayed importance

        Example:
            memory = await client.decay("mem_123", decay_rate=0.2)
        """
        payload = {"decay_rate": decay_rate}
        data = await self._request("POST", f"/memories/{memory_id}/decay", json=payload)
        return Memory(**data.get("memory", data))

    async def trace_memory(self, memory_id: str) -> dict[str, Any]:
        """
        Trace memory provenance back to source.

        Returns information about the memory's origin including
        source resource, category membership, and association chain.

        Args:
            memory_id: Memory ID

        Returns:
            Trace result with provenance information

        Example:
            trace = await client.trace_memory("mem_123")
            print(trace["chain"])
        """
        data = await self._request("GET", f"/memories/{memory_id}/trace")
        return data.get("trace", data)

    async def batch_memories(
        self,
        operations: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """
        Perform multiple memory operations in a single request.

        Supported operation types:
        - create: {"type": "create", "data": {"content": "...", ...}}
        - update: {"type": "update", "data": {"memory_id": "...", "content": "..."}}
        - delete: {"type": "delete", "data": {"memory_id": "...", "hard": False}}

        Args:
            operations: List of operations to perform

        Returns:
            Results for each operation with success/error status

        Example:
            results = await client.batch_memories([
                {"type": "create", "data": {"content": "Memory 1"}},
                {"type": "create", "data": {"content": "Memory 2"}},
                {"type": "delete", "data": {"memory_id": "mem_old"}}
            ])
        """
        payload = {"operations": operations}
        return await self._request("POST", "/memories/batch", json=payload)

    # Session extension operations

    async def list_sessions(
        self,
        workspace_id: str | None = None,
        context_id: str | None = None,
        include_expired: bool = False,
    ) -> list[dict[str, Any]]:
        """
        List sessions in a workspace.

        Args:
            workspace_id: Workspace ID (defaults to client workspace)
            context_id: Optional filter by context
            include_expired: Whether to include expired sessions

        Returns:
            List of session dicts

        Example:
            sessions = await client.list_sessions()
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id
        if context_id:
            params["context_id"] = context_id
        if include_expired:
            params["include_expired"] = "true"
        data = await self._request("GET", "/sessions", params=params)
        return data.get("sessions", [])

    async def delete_session(self, session_id: str) -> bool:
        """
        Delete a session and all its context data.

        Args:
            session_id: Session ID

        Returns:
            True if successful

        Example:
            await client.delete_session("sess_123")
        """
        await self._request("DELETE", f"/sessions/{session_id}")
        return True

    async def commit_session(
        self,
        session_id: str,
        min_importance: float = 0.5,
        deduplicate: bool = True,
        categories: list[str] | None = None,
        max_memories: int = 50,
    ) -> dict[str, Any]:
        """
        Commit session working memory to long-term memory.

        Extracts memories from session working memory, deduplicates them,
        and creates new long-term memories.

        Args:
            session_id: Session ID
            min_importance: Minimum importance threshold (default: 0.5)
            deduplicate: Whether to deduplicate memories (default: True)
            categories: Filter by categories (optional)
            max_memories: Maximum memories to extract (default: 50)

        Returns:
            Commit result with extraction statistics

        Example:
            result = await client.commit_session("sess_123")
            print(f"Created {result['memories_created']} memories")
        """
        payload: dict[str, Any] = {
            "min_importance": min_importance,
            "deduplicate": deduplicate,
            "max_memories": max_memories,
        }
        if categories is not None:
            payload["categories"] = categories

        return await self._request("POST", f"/sessions/{session_id}/commit", json=payload)

    async def touch_session(self, session_id: str) -> dict[str, Any]:
        """
        Update session expiration (extend TTL).

        Args:
            session_id: Session ID

        Returns:
            Updated expiration timestamp

        Example:
            result = await client.touch_session("sess_123")
            print(f"Expires at: {result['expires_at']}")
        """
        return await self._request("POST", f"/sessions/{session_id}/touch")

    # Context Environment operations

    async def context_exec(
        self,
        code: str,
        result_var: str | None = None,
        return_result: bool = True,
        max_return_chars: int = 10_000,
    ) -> dict[str, Any]:
        """
        Execute Python code in the session's sandbox environment.

        Requires an active session (call set_session() first).

        Args:
            code: Python code to execute
            result_var: If set, store the expression result in this variable
            return_result: Whether to include the result value in response
            max_return_chars: Maximum characters for result serialization

        Returns:
            Dict with keys: output, result, error, variables_changed

        Example:
            await client.context_exec("x = [1, 2, 3]")
            result = await client.context_exec("sum(x)")
            print(result["result"])  # 6
        """
        payload: dict[str, Any] = {
            "code": code,
            "return_result": return_result,
            "max_return_chars": max_return_chars,
        }
        if result_var is not None:
            payload["result_var"] = result_var

        return await self._request("POST", "/context/execute", json=payload)

    async def context_inspect(
        self,
        variable: str | None = None,
        preview_chars: int = 200,
    ) -> dict[str, Any]:
        """
        Inspect sandbox state or a specific variable.

        Requires an active session (call set_session() first).

        Args:
            variable: Specific variable name to inspect (all if None)
            preview_chars: Maximum characters per variable preview

        Returns:
            Dict with variable names, types, and preview values

        Example:
            state = await client.context_inspect()
            print(state["variables"])
        """
        params: dict[str, Any] = {"preview_chars": preview_chars}
        if variable is not None:
            params["variable"] = variable

        return await self._request("POST", "/context/inspect", params=params)

    async def context_load(
        self,
        var: str,
        query: str,
        limit: int = 50,
        types: list[str] | None = None,
        tags: list[str] | None = None,
        min_relevance: float | None = None,
        include_embeddings: bool = False,
    ) -> dict[str, Any]:
        """
        Load memories into the sandbox as a variable.

        Runs a memory recall query and stores the results as a list
        of dicts in the specified variable.

        Requires an active session (call set_session() first).

        Args:
            var: Variable name to store results in
            query: Memory recall query
            limit: Maximum memories to recall
            types: Filter by memory types
            tags: Filter by tags
            min_relevance: Minimum relevance score
            include_embeddings: Whether to include embedding vectors

        Returns:
            Dict with count and variable info

        Example:
            result = await client.context_load("memories", "coding preferences")
            print(f"Loaded {result['count']} memories")
        """
        payload: dict[str, Any] = {
            "var": var,
            "query": query,
            "limit": limit,
            "include_embeddings": include_embeddings,
        }
        if types is not None:
            payload["types"] = types
        if tags is not None:
            payload["tags"] = tags
        if min_relevance is not None:
            payload["min_relevance"] = min_relevance

        return await self._request("POST", "/context/load", json=payload)

    async def context_inject(
        self,
        key: str,
        value: Any,
        parse_json: bool = False,
    ) -> dict[str, Any]:
        """
        Inject a value into the sandbox state.

        Requires an active session (call set_session() first).

        Args:
            key: Variable name
            value: Value to inject
            parse_json: If True, parse value as JSON string

        Returns:
            Dict confirming the injection

        Example:
            await client.context_inject("config", {"debug": True})
        """
        payload: dict[str, Any] = {
            "key": key,
            "value": value,
            "parse_json": parse_json,
        }

        return await self._request("POST", "/context/inject", json=payload)

    async def context_query(
        self,
        prompt: str,
        variables: list[str],
        max_context_chars: int | None = None,
        result_var: str | None = None,
    ) -> dict[str, Any]:
        """
        Send sandbox variables and a prompt to the LLM.

        Requires an active session (call set_session() first).

        Args:
            prompt: User prompt for the LLM
            variables: Variable names to include as context
            max_context_chars: Maximum characters for variable context
            result_var: If set, store the LLM response in this variable

        Returns:
            Dict with the LLM response text and token usage

        Example:
            result = await client.context_query(
                "Summarize the data",
                variables=["memories", "stats"]
            )
            print(result["response"])
        """
        payload: dict[str, Any] = {
            "prompt": prompt,
            "variables": variables,
        }
        if max_context_chars is not None:
            payload["max_context_chars"] = max_context_chars
        if result_var is not None:
            payload["result_var"] = result_var

        return await self._request("POST", "/context/query", json=payload)

    async def context_rlm(
        self,
        goal: str,
        memory_query: str | None = None,
        memory_limit: int = 100,
        max_iterations: int = 10,
        variables: list[str] | None = None,
        result_var: str | None = None,
        detail_level: str = "standard",
    ) -> dict[str, Any]:
        """
        Run a Recursive Language Model (RLM) loop.

        Iteratively executes code and LLM queries to achieve a goal.

        Requires an active session (call set_session() first).

        Args:
            goal: Natural language description of the goal
            memory_query: Optional memory query to load initial data
            memory_limit: Maximum memories to load
            max_iterations: Maximum reasoning iterations
            variables: Variable names to include in context
            result_var: If set, store the final result in this variable
            detail_level: Level of detail: "brief", "standard", "detailed"

        Returns:
            Dict with result, iterations performed, and execution trace

        Example:
            result = await client.context_rlm(
                goal="Analyze user preferences and find contradictions",
                memory_query="user preferences",
            )
            print(result["result"])
        """
        payload: dict[str, Any] = {
            "goal": goal,
            "memory_limit": memory_limit,
            "max_iterations": max_iterations,
            "detail_level": detail_level,
        }
        if memory_query is not None:
            payload["memory_query"] = memory_query
        if variables is not None:
            payload["variables"] = variables
        if result_var is not None:
            payload["result_var"] = result_var

        return await self._request("POST", "/context/rlm", json=payload)

    async def context_status(self) -> dict[str, Any]:
        """
        Get the status of the session's sandbox environment.

        Requires an active session (call set_session() first).

        Returns:
            Dict with variable count, memory usage, and metadata

        Example:
            status = await client.context_status()
            print(f"Variables: {status['variable_count']}")
        """
        return await self._request("GET", "/context/status")

    async def context_checkpoint(self) -> None:
        """
        Checkpoint the session's sandbox state for persistence.

        Fires persistence hooks so enterprise deployments can save sandbox
        state to durable storage. No-op for default in-memory deployments.

        Requires an active session (call set_session() first).

        Example:
            await client.context_checkpoint()
        """
        await self._request("POST", "/context/checkpoint")

    async def context_cleanup(self) -> None:
        """
        Clean up and remove the session's sandbox environment.

        Requires an active session (call set_session() first).

        Example:
            await client.context_cleanup()
        """
        await self._request("DELETE", "/context/cleanup")

    # ------------------------------------------------------------------ #
    # Chat history operations
    # ------------------------------------------------------------------ #

    async def create_thread(
        self,
        *,
        workspace_id: str | None = None,
        thread_id: str | None = None,
        user_id: str | None = None,
        context_id: str | None = None,
        observer_id: str | None = None,
        subject_id: str | None = None,
        title: str | None = None,
        metadata: dict[str, Any] | None = None,
        expires_at: str | None = None,
        scope: str | None = None,
    ) -> ChatThread:
        """
        Create a new chat thread.

        Args:
            workspace_id: Workspace ID (uses default if not provided)
            thread_id: Optional explicit thread ID
            user_id: Optional user ID to associate with the thread
            context_id: Optional context ID (default: "_default")
            observer_id: Optional observer ID
            subject_id: Optional subject ID
            title: Optional thread title
            metadata: Additional metadata
            expires_at: Optional expiry timestamp (ISO 8601 string)

        Returns:
            Created ChatThread

        Example:
            thread = await client.create_thread(user_id="user_123", title="My Chat")
        """
        payload: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            payload["workspace_id"] = ws_id
        if thread_id is not None:
            payload["id"] = thread_id
        if user_id is not None:
            payload["user_id"] = user_id
        if context_id is not None:
            payload["context_id"] = context_id
        if observer_id is not None:
            payload["observer_id"] = observer_id
        if subject_id is not None:
            payload["subject_id"] = subject_id
        if title is not None:
            payload["title"] = title
        if metadata is not None:
            payload["metadata"] = metadata
        if expires_at is not None:
            payload["expires_at"] = expires_at
        if scope is not None:
            payload["scope"] = scope

        data = await self._request("POST", "/threads", json=payload)
        return ChatThread(**data)

    async def list_threads(
        self,
        *,
        workspace_id: str | None = None,
        user_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
        scope_filter: str | None = None,
    ) -> list[ChatThread]:
        """
        List chat threads.

        Args:
            workspace_id: Workspace ID (uses default if not provided)
            user_id: Optional filter by user ID
            limit: Maximum threads to return (default: 50)
            offset: Pagination offset (default: 0)

        Returns:
            List of ChatThread objects

        Example:
            threads = await client.list_threads(limit=20)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id
        if user_id is not None:
            params["user_id"] = user_id
        if scope_filter is not None:
            params["scope_filter"] = scope_filter

        data = await self._request("GET", "/threads", params=params)
        threads_adapter = TypeAdapter(list[ChatThread])
        return threads_adapter.validate_python(data.get("threads", data if isinstance(data, list) else []))

    async def get_thread(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
    ) -> ChatThread:
        """
        Get thread metadata.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)

        Returns:
            ChatThread object

        Example:
            thread = await client.get_thread("thread_123")
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        data = await self._request("GET", f"/threads/{thread_id}", params=params or None)
        return ChatThread(**data)

    async def get_thread_full(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
        order: str = "asc",
    ) -> ChatThreadWithMessages:
        """
        Get thread with messages inlined.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)
            limit: Maximum messages to return (default: 100)
            offset: Pagination offset (default: 0)
            order: Message order "asc" or "desc" (default: "asc")

        Returns:
            ChatThreadWithMessages object

        Example:
            full = await client.get_thread_full("thread_123")
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset, "order": order}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        data = await self._request("GET", f"/threads/{thread_id}/full", params=params)
        return ChatThreadWithMessages(**data)

    async def update_thread(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
        title: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "ChatThread":
        """
        Update a thread's metadata (e.g. rename it).

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)
            title: New thread title
            metadata: Optional metadata dict to merge

        Example:
            await client.update_thread("thread_123", title="My renamed thread")
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        payload: dict[str, Any] = {}
        if title is not None:
            payload["title"] = title
        if metadata is not None:
            payload["metadata"] = metadata

        data = await self._request("PUT", f"/threads/{thread_id}", params=params or None, json=payload)
        return ChatThread(**data)

    async def delete_thread(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
    ) -> None:
        """
        Delete a thread and its messages.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)

        Example:
            await client.delete_thread("thread_123")
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        await self._request("DELETE", f"/threads/{thread_id}", params=params or None)

    async def delete_message(
        self,
        thread_id: str,
        message_id: str,
        *,
        workspace_id: str | None = None,
        authority: AuthorityContext | None = None,
    ) -> bool:
        """
        Delete a single message from a thread.

        Args:
            thread_id: Thread ID
            message_id: Message ID to delete
            workspace_id: Workspace ID (uses default if not provided)
            authority: Per-request OBO authority

        Returns:
            True if the message was found and deleted, False if not found.
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        try:
            await self._request(
                "DELETE",
                f"/threads/{thread_id}/messages/{message_id}",
                params=params or None,
                authority=authority,
            )
            return True
        except NotFoundError:
            return False

    async def append_messages(
        self,
        thread_id: str,
        messages: list[dict[str, Any]],
        *,
        workspace_id: str | None = None,
    ) -> list[ChatMessage]:
        """
        Append messages to a thread.

        Args:
            thread_id: Thread ID
            messages: List of message dicts, each with: role, content, metadata (optional)
            workspace_id: Workspace ID (uses default if not provided)

        Returns:
            List of created ChatMessage objects

        Example:
            msgs = await client.append_messages(
                "thread_123",
                [{"role": "user", "content": "Hello"}, {"role": "assistant", "content": "Hi!"}]
            )
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        payload: dict[str, Any] = {"messages": messages}
        data = await self._request(
            "POST",
            f"/threads/{thread_id}/messages",
            json=payload,
            params=params or None,
        )
        messages_adapter = TypeAdapter(list[ChatMessage])
        return messages_adapter.validate_python(data.get("messages", data if isinstance(data, list) else []))

    async def get_messages(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
        after_index: int | None = None,
        order: str = "asc",
    ) -> list[ChatMessage]:
        """
        Get messages from a thread.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)
            limit: Maximum messages to return (default: 100)
            offset: Pagination offset (default: 0)
            after_index: Only return messages after this index (optional)
            order: Message order "asc" or "desc" (default: "asc")

        Returns:
            List of ChatMessage objects

        Example:
            messages = await client.get_messages("thread_123", limit=50)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset, "order": order}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id
        if after_index is not None:
            params["after_index"] = after_index

        data = await self._request("GET", f"/threads/{thread_id}/messages", params=params)
        messages_adapter = TypeAdapter(list[ChatMessage])
        return messages_adapter.validate_python(data.get("messages", data if isinstance(data, list) else []))

    async def decompose_thread(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
    ) -> DecompositionResult:
        """
        Trigger memory decomposition for unprocessed messages.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)

        Returns:
            DecompositionResult with processing statistics

        Example:
            result = await client.decompose_thread("thread_123")
            print(f"Processed {result.messages_processed} messages")
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        data = await self._request(
            "POST",
            f"/threads/{thread_id}/decompose",
            params=params or None,
        )
        return DecompositionResult(**data)

    # ------------------------------------------------------------------ #
    # Document operations (Enterprise)
    # ------------------------------------------------------------------ #

    async def upload_document(
        self,
        file_data: bytes,
        filename: str,
        *,
        target_context_id: str = "_default",
        chunking_strategy: str = "page",
        chunk_size: int = 4096,
        chunk_overlap: int = 200,
        importance: float = 0.5,
        retain_original: bool = True,
    ) -> tuple[DocumentInfo, JobInfo]:
        """
        Upload a document for ingestion.

        Requires MemoryLayer Enterprise.  On OSS servers this raises
        ``EnterpriseRequiredError``.

        Args:
            file_data: Raw file bytes.
            filename: Original filename (used to detect type).
            target_context_id: Memory context for extracted memories.
            chunking_strategy: Chunking strategy (page, semantic, fixed).
            chunk_size: Maximum chunk size in characters.
            chunk_overlap: Overlap between chunks in characters.
            importance: Default importance for extracted memories (0.0-1.0).
            retain_original: Whether to keep the original file in blob storage.

        Returns:
            Tuple of (DocumentInfo, JobInfo).
        """
        transport = self._ensure_transport()
        body, content_type = self._encode_multipart(
            files={"file": (filename, file_data)},
            data={
                "target_context_id": target_context_id,
                "chunking_strategy": chunking_strategy,
                "chunk_size": str(chunk_size),
                "chunk_overlap": str(chunk_overlap),
                "importance": str(importance),
                "retain_original": str(retain_original).lower(),
            },
        )

        try:
            response = await transport.request(
                "POST",
                "/documents",
                content=body,
                headers={"content-type": content_type},
            )

            if response.status_code == 501:
                raise EnterpriseRequiredError(feature="Document ingestion")
            response.raise_for_status()

            data = response.json()
            return (
                DocumentInfo(**data["document"]),
                JobInfo(**data["job"]),
            )
        except EnterpriseRequiredError:
            raise
        except httpx.HTTPStatusError as exc:
            raise MemoryLayerError(
                str(exc),
                status_code=exc.response.status_code,
            )

    async def list_documents(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[DocumentInfo], int]:
        """
        List documents in the workspace.

        Returns:
            Tuple of (documents list, total_count).
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status

        data = await self._request(
            "GET",
            "/documents",
            params=params,
            enterprise_feature="Document management",
        )
        docs = [DocumentInfo(**d) for d in data.get("documents", [])]
        return docs, data.get("total_count", len(docs))

    async def get_document(self, document_id: str) -> DocumentInfo:
        """Get document metadata and processing status."""
        data = await self._request(
            "GET",
            f"/documents/{document_id}",
            enterprise_feature="Document management",
        )
        return DocumentInfo(**data)

    async def delete_document(
        self,
        document_id: str,
        *,
        delete_memories: bool = False,
    ) -> None:
        """Delete a document and optionally its extracted memories."""
        await self._request(
            "DELETE",
            f"/documents/{document_id}",
            params={"delete_memories": str(delete_memories).lower()},
            enterprise_feature="Document management",
        )

    async def search_document_pages(
        self,
        query: str,
        *,
        limit: int = 10,
        doc_ids: list[str] | None = None,
    ) -> PageSearchResult:
        """
        Search document pages using ColPali MaxSim visual similarity.

        Requires MemoryLayer Enterprise.

        Args:
            query: Natural language search query.
            limit: Maximum results to return.
            doc_ids: Optional document ID filter.

        Returns:
            PageSearchResult with ranked pages.
        """
        payload: dict[str, Any] = {"query": query, "limit": limit}
        if doc_ids:
            payload["doc_ids"] = doc_ids

        data = await self._request(
            "POST",
            "/documents/search",
            json=payload,
            enterprise_feature="Document page search",
        )
        return PageSearchResult(
            pages=[DocumentPage(**p) for p in data.get("pages", [])],
            total_count=data.get("total_count", 0),
            query=data.get("query", query),
        )

    async def get_document_pages(self, document_id: str) -> list[DocumentPage]:
        """Get all pages for a document."""
        data = await self._request(
            "GET",
            f"/documents/{document_id}/pages",
            enterprise_feature="Document pages",
        )
        return [DocumentPage(**p) for p in data.get("pages", [])]

    async def get_page_image(self, document_id: str, page_id: str) -> bytes:
        """
        Get a page image as raw PNG bytes.

        Requires MemoryLayer Enterprise.
        """
        transport = self._ensure_transport()

        try:
            response = await transport.request(
                "GET",
                f"/documents/{document_id}/pages/{page_id}/image",
            )
            if response.status_code == 501:
                raise EnterpriseRequiredError(feature="Document page images")
            response.raise_for_status()
            return response.content
        except EnterpriseRequiredError:
            raise
        except httpx.HTTPStatusError as exc:
            raise MemoryLayerError(
                str(exc),
                status_code=exc.response.status_code,
            )

    async def get_job(self, job_id: str) -> JobInfo:
        """Get ingestion job status and progress."""
        data = await self._request(
            "GET",
            f"/documents/jobs/{job_id}",
            enterprise_feature="Document ingestion jobs",
        )
        return JobInfo(**data)

    async def list_jobs(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
    ) -> list[JobInfo]:
        """List ingestion jobs in the workspace."""
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status

        data = await self._request(
            "GET",
            "/documents/jobs",
            params=params,
            enterprise_feature="Document ingestion jobs",
        )
        return [JobInfo(**j) for j in data.get("jobs", [])]

    async def cancel_job(self, job_id: str) -> None:
        """Cancel a queued or running ingestion job."""
        await self._request(
            "POST",
            f"/documents/jobs/{job_id}/cancel",
            enterprise_feature="Document ingestion jobs",
        )

    async def reprocess_document(
        self,
        document_id: str,
        *,
        target_context_id: str | None = None,
        chunking_strategy: str | None = None,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
        importance: float | None = None,
    ) -> JobInfo:
        """Reprocess a document with optionally different extraction options."""
        payload: dict[str, Any] = {}
        if target_context_id is not None:
            payload["target_context_id"] = target_context_id
        if chunking_strategy is not None:
            payload["chunking_strategy"] = chunking_strategy
        if chunk_size is not None:
            payload["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            payload["chunk_overlap"] = chunk_overlap
        if importance is not None:
            payload["importance"] = importance

        data = await self._request(
            "POST",
            f"/documents/{document_id}/reprocess",
            json=payload if payload else None,
            enterprise_feature="Document reprocessing",
        )
        return JobInfo(**data)

    # ------------------------------------------------------------------ #
    # Dataset operations (Enterprise)
    # ------------------------------------------------------------------ #

    async def upload_dataset(
        self,
        file_data: bytes,
        filename: str,
        *,
        name: str | None = None,
        target_context_id: str = "_default",
        importance: float = 0.5,
        sample_rows: int = 1000,
        detect_time_series: bool = True,
        generate_summaries: bool = True,
    ) -> tuple[DatasetInfo, DatasetJobInfo]:
        """
        Upload a dataset for profiling and memory extraction.

        Requires MemoryLayer Enterprise. On OSS servers this raises
        ``EnterpriseRequiredError``.

        Args:
            file_data: Raw file bytes.
            filename: Original filename (used to detect format).
            name: Display name (defaults to filename stem).
            target_context_id: Memory context for extracted memories.
            importance: Default importance for extracted memories (0.0-1.0).
            sample_rows: Max rows to include in LLM summary sample.
            detect_time_series: Attempt to detect temporal columns.
            generate_summaries: Generate LLM natural-language summaries.

        Returns:
            Tuple of (DatasetInfo, DatasetJobInfo).
        """
        transport = self._ensure_transport()

        form_data: dict[str, str] = {
            "target_context_id": target_context_id,
            "importance": str(importance),
            "sample_rows": str(sample_rows),
            "detect_time_series": str(detect_time_series).lower(),
            "generate_summaries": str(generate_summaries).lower(),
        }
        if name is not None:
            form_data["name"] = name

        body, content_type = self._encode_multipart(
            files={"file": (filename, file_data)},
            data=form_data,
        )

        try:
            response = await transport.request(
                "POST",
                "/datasets",
                content=body,
                headers={"content-type": content_type},
            )

            if response.status_code == 501:
                raise EnterpriseRequiredError(feature="Dataset management")
            response.raise_for_status()

            data = response.json()
            return (
                DatasetInfo(**data["dataset"]),
                DatasetJobInfo(**data["job"]),
            )
        except EnterpriseRequiredError:
            raise
        except httpx.HTTPStatusError as exc:
            raise MemoryLayerError(
                str(exc),
                status_code=exc.response.status_code,
            )

    async def list_datasets(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[DatasetInfo], int]:
        """
        List datasets in the workspace.

        Returns:
            Tuple of (datasets list, total_count).
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status

        data = await self._request(
            "GET",
            "/datasets",
            params=params,
            enterprise_feature="Dataset management",
        )
        datasets = [DatasetInfo(**d) for d in data.get("datasets", [])]
        return datasets, data.get("total_count", len(datasets))

    async def get_dataset(self, dataset_id: str) -> DatasetInfo:
        """Get dataset metadata, schema, and profile."""
        data = await self._request(
            "GET",
            f"/datasets/{dataset_id}",
            enterprise_feature="Dataset management",
        )
        return DatasetInfo(**data)

    async def delete_dataset(
        self,
        dataset_id: str,
        *,
        delete_memories: bool = False,
    ) -> None:
        """Delete a dataset and optionally its extracted memories."""
        await self._request(
            "DELETE",
            f"/datasets/{dataset_id}",
            params={"delete_memories": str(delete_memories).lower()},
            enterprise_feature="Dataset management",
        )

    async def get_dataset_memories(
        self,
        dataset_id: str,
    ) -> list[dict[str, Any]]:
        """
        Get memories extracted from a dataset.

        Returns:
            List of memory dicts with id, content, type, importance, tags, created_at.
        """
        data = await self._request(
            "GET",
            f"/datasets/{dataset_id}/memories",
            enterprise_feature="Dataset management",
        )
        return data.get("memories", [])

    async def query_dataset_slice(
        self,
        dataset_id: str,
        *,
        sql: str | None = None,
        columns: list[str] | None = None,
        filters: list[dict[str, Any]] | None = None,
        order_by: str | None = None,
        descending: bool = False,
        limit: int = 100,
        offset: int = 0,
    ) -> DatasetSliceResult:
        """
        Query a slice of dataset data using DuckDB.

        Supports both structured filters and raw SQL (SELECT only).
        The dataset is queried as a table named 'data'.

        Args:
            dataset_id: Dataset ID to query.
            sql: Raw SQL query (SELECT only, table alias is 'data').
            columns: Columns to select (if not using raw SQL).
            filters: Filter conditions [{column, op, value}].
            order_by: Column to order by.
            descending: Sort descending.
            limit: Max rows to return (1-10000).
            offset: Row offset for pagination.

        Returns:
            DatasetSliceResult with columns, rows, and metadata.
        """
        payload: dict[str, Any] = {
            "limit": limit,
            "offset": offset,
            "descending": descending,
        }
        if sql is not None:
            payload["sql"] = sql
        if columns is not None:
            payload["columns"] = columns
        if filters is not None:
            payload["filters"] = filters
        if order_by is not None:
            payload["order_by"] = order_by

        data = await self._request(
            "POST",
            f"/datasets/{dataset_id}/slice",
            json=payload,
            enterprise_feature="Dataset management",
        )
        return DatasetSliceResult(**data)

    async def get_dataset_job(self, job_id: str) -> DatasetJobInfo:
        """Get dataset processing job status and progress."""
        data = await self._request(
            "GET",
            f"/datasets/jobs/{job_id}",
            enterprise_feature="Dataset processing jobs",
        )
        return DatasetJobInfo(**data)

    async def list_dataset_jobs(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
    ) -> list[DatasetJobInfo]:
        """List dataset processing jobs in the workspace."""
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status

        data = await self._request(
            "GET",
            "/datasets/jobs",
            params=params,
            enterprise_feature="Dataset processing jobs",
        )
        return [DatasetJobInfo(**j) for j in data.get("jobs", [])]

    async def cancel_dataset_job(self, job_id: str) -> None:
        """Cancel a queued or running dataset processing job."""
        await self._request(
            "POST",
            f"/datasets/jobs/{job_id}/cancel",
            enterprise_feature="Dataset processing jobs",
        )


class _OBOProxy:
    """
    Lightweight proxy over MemoryLayerClient that injects OBO authority and/or
    a fixed workspace_id on every request.  Shares the parent's httpx.AsyncClient
    — no new HTTP connections, no mutation of shared headers.
    """

    def __init__(
        self,
        parent: MemoryLayerClient,
        authority: AuthorityContext | None,
        workspace_id: str | None,
    ) -> None:
        self._parent = parent
        self._authority = authority
        self._workspace_id = workspace_id

    # --- proxy helpers ---

    def _resolve_authority(self, authority: AuthorityContext | None) -> AuthorityContext | None:
        return authority if authority is not None else self._authority

    def _resolve_workspace(self, workspace_id: str | None) -> str | None:
        return workspace_id if workspace_id is not None else self._workspace_id

    # --- sub-proxy ---

    @asynccontextmanager
    async def acting_for(
        self,
        grant_id: str,
        subject: tuple[str, str] | None = None,
    ):  # type: ignore[return]
        """Return a new proxy with a different authority (workspace_id inherited)."""
        from .models import PrincipalRef

        principal = PrincipalRef(type=subject[0], id=subject[1]) if subject is not None else None
        authority = AuthorityContext(grant_id=grant_id, subject=principal)
        yield _OBOProxy(self._parent, authority=authority, workspace_id=self._workspace_id)

    def for_workspace(self, workspace_id: str) -> "_OBOProxy":
        """Return a new proxy with a different workspace_id (authority inherited)."""
        return _OBOProxy(self._parent, authority=self._authority, workspace_id=workspace_id)

    # --- delegated namespaces ---

    @property
    def skills(self) -> "_SkillsOBOProxy":
        """Skills namespace bound to this proxy's authority + workspace."""
        return _SkillsOBOProxy(
            self._parent.skills,
            authority=self._authority,
            workspace_id=self._workspace_id,
        )

    @property
    def mcp_servers(self) -> "_McpServersOBOProxy":
        """MCP servers namespace bound to this proxy's authority + workspace."""
        return _McpServersOBOProxy(
            self._parent.mcp_servers,
            authority=self._authority,
            workspace_id=self._workspace_id,
        )

    @property
    def kb(self) -> "_KbOBOProxy":
        """Knowledgebase namespace bound to this proxy's authority + workspace."""
        return _KbOBOProxy(
            self._parent.kb,
            authority=self._authority,
            workspace_id=self._workspace_id,
        )

    # --- delegated memory operations ---

    async def remember(
        self,
        content: str,
        type: str | MemoryType | None = None,
        subtype: str | None = None,
        importance: float = 0.5,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        context_id: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        authority: AuthorityContext | None = None,
    ) -> Memory:
        return await self._parent.remember(
            content,
            type=type,
            subtype=subtype,
            importance=importance,
            tags=tags,
            metadata=metadata,
            context_id=context_id,
            user_id=user_id,
            workspace_id=self._resolve_workspace(workspace_id),
            authority=self._resolve_authority(authority),
        )

    async def recall(
        self,
        query: str,
        types: list[str | MemoryType] | None = None,
        subtypes: list[str] | None = None,
        tags: list[str] | None = None,
        mode: str | RecallMode | None = None,
        limit: int = 10,
        min_relevance: float | None = None,
        recency_weight: float | None = None,
        tolerance: str | SearchTolerance | None = None,
        include_associations: bool | None = None,
        traverse_depth: int | None = None,
        max_expansion: int | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        user_id: str | None = None,
        workspace_id: str | None = None,
        authority: AuthorityContext | None = None,
    ) -> RecallResult:
        return await self._parent.recall(
            query,
            types=types,
            subtypes=subtypes,
            tags=tags,
            mode=mode,
            limit=limit,
            min_relevance=min_relevance,
            recency_weight=recency_weight,
            tolerance=tolerance,
            include_associations=include_associations,
            traverse_depth=traverse_depth,
            max_expansion=max_expansion,
            created_after=created_after,
            created_before=created_before,
            user_id=user_id,
            workspace_id=self._resolve_workspace(workspace_id),
            authority=self._resolve_authority(authority),
        )

    async def reflect(
        self,
        query: str,
        max_tokens: int = 500,
        include_sources: bool = True,
        authority: AuthorityContext | None = None,
    ) -> ReflectResult:
        return await self._parent.reflect(
            query,
            max_tokens=max_tokens,
            include_sources=include_sources,
            authority=self._resolve_authority(authority),
        )

    async def delete_message(
        self,
        thread_id: str,
        message_id: str,
        *,
        workspace_id: str | None = None,
        authority: AuthorityContext | None = None,
    ) -> bool:
        return await self._parent.delete_message(
            thread_id,
            message_id,
            workspace_id=self._resolve_workspace(workspace_id),
            authority=self._resolve_authority(authority),
        )


class _SkillsOBOProxy:
    """SkillsAPI namespace bound to an OBO authority + workspace_id.

    Returned from ``_OBOProxy.skills``. Forwards every call to the parent
    SkillsAPI while injecting the proxy's authority + default workspace_id
    so OBO context flows through to the server unchanged.
    """

    def __init__(
        self,
        parent: "SkillsAPI",
        authority: AuthorityContext | None,
        workspace_id: str | None,
    ) -> None:
        self._parent = parent
        self._authority = authority
        self._workspace_id = workspace_id

    def _ws(self, workspace_id: str | None) -> str | None:
        return workspace_id if workspace_id is not None else self._workspace_id

    async def list(
        self,
        scope: str | None = None,
        name: str | None = None,
        tags: list[str] | None = None,
        enabled: bool | None = None,
        include_shadowed: bool = False,
        workspace_id: str | None = None,
        authority: AuthorityContext | None = None,
    ):
        return await self._parent.list(
            scope=scope,
            name=name,
            tags=tags,
            enabled=enabled,
            include_shadowed=include_shadowed,
            workspace_id=self._ws(workspace_id),
            authority=authority if authority is not None else self._authority,
        )

    async def get(self, skill_id: str, authority: AuthorityContext | None = None):
        return await self._parent.get(
            skill_id,
            authority=authority if authority is not None else self._authority,
        )

    async def list_files(self, skill_id: str, authority: AuthorityContext | None = None):
        return await self._parent.list_files(
            skill_id,
            authority=authority if authority is not None else self._authority,
        )

    async def save(
        self,
        name: str,
        description: str,
        body: str = "",
        files: "list[tuple[str, bytes]] | None" = None,
        scope: str = "workspace",
        source_mode: str = "server",
        workspace_id: str | None = None,
        user_id: str | None = None,
        authority: AuthorityContext | None = None,
        **manifest_extras: Any,
    ):
        return await self._parent.save(
            name=name,
            description=description,
            body=body,
            files=files,
            scope=scope,
            source_mode=source_mode,
            workspace_id=self._ws(workspace_id),
            user_id=user_id,
            authority=authority if authority is not None else self._authority,
            **manifest_extras,
        )

    async def delete(self, skill_id: str, authority: AuthorityContext | None = None):
        return await self._parent.delete(
            skill_id,
            authority=authority if authority is not None else self._authority,
        )

    async def resolve(
        self,
        name: str | None = None,
        query: str | None = None,
        workspace_id: str | None = None,
        authority: AuthorityContext | None = None,
    ):
        return await self._parent.resolve(
            name=name,
            query=query,
            workspace_id=self._ws(workspace_id),
            authority=authority if authority is not None else self._authority,
        )


class _KbOBOProxy:
    """KnowledgebaseAPI namespace bound to an OBO authority + workspace_id."""

    def __init__(
        self,
        parent: "KnowledgebaseAPI",
        authority: AuthorityContext | None,
        workspace_id: str | None,
    ) -> None:
        self._parent = parent
        self._authority = authority
        self._workspace_id = workspace_id

    def _ws(self, workspace_id: str | None) -> str | None:
        return workspace_id if workspace_id is not None else self._workspace_id

    def _auth(self, authority: AuthorityContext | None) -> AuthorityContext | None:
        return authority if authority is not None else self._authority

    async def get(self, workspace_id: str | None = None, *, context_id: str | None = None, authority: AuthorityContext | None = None):
        return await self._parent.get(
            self._ws(workspace_id),
            context_id=context_id,
            authority=self._auth(authority),
        )

    async def list_articles(
        self,
        workspace_id: str | None = None,
        *,
        article_type: str | None = None,
        limit: int = 100,
        offset: int = 0,
        authority: AuthorityContext | None = None,
    ):
        return await self._parent.list_articles(
            self._ws(workspace_id),
            article_type=article_type,
            limit=limit,
            offset=offset,
            authority=self._auth(authority),
        )

    async def get_article(self, article_id: str, workspace_id: str | None = None, *, authority: AuthorityContext | None = None):
        return await self._parent.get_article(
            article_id,
            self._ws(workspace_id),
            authority=self._auth(authority),
        )

    async def generate(
        self,
        workspace_id: str | None = None,
        *,
        regenerate: bool = False,
        max_communities: int | None = None,
        max_god_nodes: int | None = None,
        include_rpg: bool = False,
        context_id: str | None = None,
        authority: AuthorityContext | None = None,
    ):
        return await self._parent.generate(
            self._ws(workspace_id),
            regenerate=regenerate,
            max_communities=max_communities,
            max_god_nodes=max_god_nodes,
            include_rpg=include_rpg,
            context_id=context_id,
            authority=self._auth(authority),
        )

    async def export_vault(self, workspace_id: str | None = None, *, authority: AuthorityContext | None = None):
        return await self._parent.export_vault(
            self._ws(workspace_id),
            authority=self._auth(authority),
        )

    async def get_graph_analysis(
        self, workspace_id: str | None = None, *, context_id: str | None = None, authority: AuthorityContext | None = None
    ):
        return await self._parent.get_graph_analysis(
            self._ws(workspace_id),
            context_id=context_id,
            authority=self._auth(authority),
        )

    async def get_community(self, community_id: int, workspace_id: str | None = None, *, authority: AuthorityContext | None = None):
        return await self._parent.get_community(
            community_id,
            self._ws(workspace_id),
            authority=self._auth(authority),
        )


class _McpServersOBOProxy:
    """McpServersAPI namespace bound to an OBO authority + workspace_id."""

    def __init__(
        self,
        parent: "McpServersAPI",
        authority: AuthorityContext | None,
        workspace_id: str | None,
    ) -> None:
        self._parent = parent
        self._authority = authority
        self._workspace_id = workspace_id

    def _ws(self, workspace_id: str | None) -> str | None:
        return workspace_id if workspace_id is not None else self._workspace_id

    async def list(self, workspace_id: str | None = None, authority: AuthorityContext | None = None, **kwargs: Any):
        return await self._parent.list(
            workspace_id=self._ws(workspace_id),
            authority=authority if authority is not None else self._authority,
            **kwargs,
        )

    async def get(self, server_id: str, authority: AuthorityContext | None = None):
        return await self._parent.get(
            server_id,
            authority=authority if authority is not None else self._authority,
        )

    async def get_by_name(self, name: str, workspace_id: str | None = None, authority: AuthorityContext | None = None, **kwargs: Any):
        return await self._parent.get_by_name(
            name,
            workspace_id=self._ws(workspace_id),
            authority=authority if authority is not None else self._authority,
            **kwargs,
        )

    async def create(self, workspace_id: str | None = None, authority: AuthorityContext | None = None, **kwargs: Any):
        return await self._parent.create(
            workspace_id=self._ws(workspace_id),
            authority=authority if authority is not None else self._authority,
            **kwargs,
        )

    async def update(self, server_id: str, authority: AuthorityContext | None = None, **kwargs: Any):
        return await self._parent.update(
            server_id,
            authority=authority if authority is not None else self._authority,
            **kwargs,
        )

    async def delete(self, server_id: str, authority: AuthorityContext | None = None):
        return await self._parent.delete(
            server_id,
            authority=authority if authority is not None else self._authority,
        )

    async def resolve(self, name: str, workspace_id: str | None = None, authority: AuthorityContext | None = None):
        return await self._parent.resolve(
            name,
            workspace_id=self._ws(workspace_id),
            authority=authority if authority is not None else self._authority,
        )
