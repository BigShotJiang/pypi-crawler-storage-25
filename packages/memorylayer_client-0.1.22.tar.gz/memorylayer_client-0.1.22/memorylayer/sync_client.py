"""Synchronous client wrapper for MemoryLayer.ai SDK."""

import json
import logging
from collections.abc import Generator
from contextlib import contextmanager
from typing import Any

import httpx
from pydantic import TypeAdapter

from .exceptions import (
    AuthenticationError,
    EnterpriseRequiredError,
    MemoryLayerError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .knowledgebase import SyncKnowledgebaseAPI
from .mcp_servers import SyncMcpServersAPI
from .models import (
    Association,
    ChatMessage,
    ChatThread,
    ChatThreadWithMessages,
    DatasetInfo,
    DatasetJobInfo,
    DatasetSliceResult,
    DecompositionResult,
    DocumentInfo,
    DocumentPage,
    JobInfo,
    Memory,
    PageSearchResult,
    RecallResult,
    ReflectResult,
    Session,
    SessionBriefing,
    Workspace,
)
from .skills import SyncSkillsAPI
from .types import (
    MemoryType,
    RecallMode,
    RelationshipType,
    SearchTolerance,
)

logger = logging.getLogger(__name__)


def _to_value(v: Any) -> Any:
    """Extract string value from an enum member, or return string as-is."""
    return v.value if hasattr(v, "value") else v


class SyncMemoryLayerClient:
    """
    Synchronous Python client for MemoryLayer.ai API.

    Usage:
        with SyncMemoryLayerClient(
            base_url="https://api.memorylayer.ai",
            api_key="your-api-key",
            workspace_id="ws_123"
        ) as client:
            # Store a memory
            memory = client.remember(
                content="User prefers Python",
                type=MemoryType.SEMANTIC,
                importance=0.8
            )

            # Search memories
            results = client.recall("coding preferences")

            # Reflect on memories
            reflection = client.reflect("summarize user preferences")
    """

    def __init__(
        self,
        base_url: str = "http://localhost:61001",
        api_key: str | None = None,
        workspace_id: str | None = None,
        session_id: str | None = None,
        timeout: float = 30.0,
    ):
        """
        Initialize MemoryLayer client.

        Args:
            base_url: API base URL (default: http://localhost:61001)
            api_key: API key for authentication
            workspace_id: Default workspace ID for operations
            session_id: Session ID for session-based workspace resolution
            timeout: Request timeout in seconds (default: 30.0)
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.workspace_id = workspace_id
        self.session_id = session_id
        self.timeout = timeout
        self._client: httpx.Client | None = None
        self.skills = SyncSkillsAPI(self)
        self.mcp_servers = SyncMcpServersAPI(self)
        self.kb = SyncKnowledgebaseAPI(self)

    def __enter__(self) -> "SyncMemoryLayerClient":
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit."""
        self.close()

    def connect(self) -> None:
        """Initialize the HTTP client."""
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.workspace_id:
            headers["X-Workspace-ID"] = self.workspace_id
        if self.session_id:
            headers["X-Session-ID"] = self.session_id

        self._client = httpx.Client(
            base_url=f"{self.base_url}/v1",
            headers=headers,
            timeout=self.timeout,
        )

    def set_session(self, session_id: str) -> None:
        """
        Set the active session ID.

        All subsequent requests will include this session ID in the
        X-Session-ID header, enabling session-based workspace resolution.

        Args:
            session_id: Session ID to use
        """
        self.session_id = session_id
        if self._client:
            self._client.headers["X-Session-ID"] = session_id

    def clear_session(self) -> None:
        """Clear the active session ID."""
        self.session_id = None
        if self._client and "X-Session-ID" in self._client.headers:
            del self._client.headers["X-Session-ID"]

    def get_session_id(self) -> str | None:
        """
        Get the current session ID, if any.

        Returns:
            Current session ID or None
        """
        return self.session_id

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            self._client.close()

    def _ensure_client(self) -> httpx.Client:
        """Ensure client is initialized."""
        if self._client is None:
            raise RuntimeError("Client not initialized. Use context manager or call connect().")
        return self._client

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        enterprise_feature: str | None = None,
    ) -> dict[str, Any]:
        """
        Make HTTP request with error handling.

        Args:
            method: HTTP method
            path: API path
            json: JSON body
            params: Query parameters
            enterprise_feature: If set, a 404 raises EnterpriseRequiredError
                instead of NotFoundError.

        Returns:
            Response JSON

        Raises:
            AuthenticationError: Authentication failed (401)
            EnterpriseRequiredError: Enterprise-only endpoint (404 + enterprise_feature)
            NotFoundError: Resource not found (404)
            ValidationError: Validation failed (422)
            RateLimitError: Rate limit exceeded (429)
            ServerError: Server error (5xx)
            MemoryLayerError: Other errors
        """
        client = self._ensure_client()

        try:
            response = client.request(method, path, json=json, params=params)

            # Handle errors
            if response.status_code == 401:
                raise AuthenticationError(response.json().get("detail", "Authentication failed"))
            elif response.status_code == 404:
                raise NotFoundError(response.json().get("detail", "Resource not found"))
            elif response.status_code == 501:
                if enterprise_feature:
                    raise EnterpriseRequiredError(feature=enterprise_feature)
                raise NotFoundError(response.json().get("detail", "Not implemented"))
            elif response.status_code == 422:
                raise ValidationError(response.json().get("detail", "Validation error"))
            elif response.status_code == 429:
                raise RateLimitError(response.json().get("detail", "Rate limit exceeded"))
            elif response.status_code >= 500:
                raise ServerError(
                    response.json().get("detail", "Server error"),
                    status_code=response.status_code,
                )
            elif response.status_code >= 400:
                raise MemoryLayerError(
                    response.json().get("detail", "Request failed"),
                    status_code=response.status_code,
                )

            response.raise_for_status()

            # Handle No Content responses
            if response.status_code == 204:
                return {}

            return response.json()

        except httpx.TimeoutException as e:
            raise MemoryLayerError(f"Request timeout: {e}") from e
        except httpx.HTTPError as e:
            raise MemoryLayerError(f"HTTP error: {e}") from e

    # Core memory operations

    def remember(
        self,
        content: str,
        type: str | MemoryType | None = None,
        subtype: str | None = None,
        importance: float = 0.5,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        context_id: str | None = None,
        user_id: str | None = None,
    ) -> Memory:
        """
        Store a new memory.

        Args:
            content: Memory content to store
            type: Cognitive memory type (episodic, semantic, procedural, working).
                Accepts MemoryType enum or plain string.
            subtype: Domain subtype (Solution, Problem, etc.).
                Plain string subtype identifier.
            importance: Importance score 0.0-1.0 (default: 0.5)
            tags: Tags for categorization
            metadata: Additional metadata
            context_id: Optional context ID

        Returns:
            Created memory

        Example:
            memory = client.remember(
                content="User prefers concise code comments",
                type=MemoryType.SEMANTIC,
                subtype="preference",
                importance=0.8,
                tags=["preferences", "coding-style"]
            )
        """
        payload = {
            "content": content,
            "importance": importance,
        }
        if type:
            payload["type"] = _to_value(type)
        if subtype:
            payload["subtype"] = _to_value(subtype)
        if tags:
            payload["tags"] = tags
        if metadata:
            payload["metadata"] = metadata
        if context_id:
            payload["context_id"] = context_id
        if user_id is not None:
            payload["user_id"] = user_id

        data = self._request("POST", "/memories", json=payload)
        return Memory(**data["memory"])

    def recall(
        self,
        query: str,
        types: list[str | MemoryType] | None = None,
        subtypes: list[str] | None = None,
        tags: list[str] | None = None,
        mode: str | RecallMode | None = None,
        limit: int = 10,
        min_relevance: float | None = None,
        recency_weight: float | None = None,
        tolerance: str | SearchTolerance | None = None,
        include_associations: bool | None = None,
        traverse_depth: int | None = None,
        max_expansion: int | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        user_id: str | None = None,
    ) -> RecallResult:
        """
        Search memories by semantic query.

        Args:
            query: Natural language search query
            types: Filter by cognitive memory types
            subtypes: Filter by domain subtypes
            tags: Filter by tags
            mode: Retrieval mode (rag, llm, hybrid). None = server default.
            limit: Maximum memories to return (default: 10)
            min_relevance: Minimum relevance score 0.0-1.0 (None = server default)
            tolerance: Search tolerance (loose, moderate, strict). None = server default.
            include_associations: Include linked memories (None = server default)
            traverse_depth: Multi-hop graph traversal depth (None = server default)
            max_expansion: Max memories discovered via graph expansion (None = server default)

        Returns:
            Recall results with memories

        Example:
            results = client.recall(
                query="what are the user's coding preferences?",
                types=[MemoryType.SEMANTIC, MemoryType.PROCEDURAL],
                limit=5,
                min_relevance=0.7
            )
        """
        payload: dict = {
            "query": query,
            "limit": limit,
        }
        if mode is not None:
            payload["mode"] = _to_value(mode)
        if tolerance is not None:
            payload["tolerance"] = _to_value(tolerance)
        if include_associations is not None:
            payload["include_associations"] = include_associations
        if traverse_depth is not None:
            payload["traverse_depth"] = traverse_depth
        if min_relevance is not None:
            payload["min_relevance"] = min_relevance
        if recency_weight is not None:
            payload["recency_weight"] = recency_weight
        if max_expansion is not None:
            payload["max_expansion"] = max_expansion
        if types:
            payload["types"] = [_to_value(t) for t in types]
        if subtypes:
            payload["subtypes"] = [_to_value(s) for s in subtypes]
        if tags:
            payload["tags"] = tags
        if created_after is not None:
            payload["created_after"] = created_after
        if created_before is not None:
            payload["created_before"] = created_before
        if user_id is not None:
            payload["user_id"] = user_id

        data = self._request("POST", "/memories/recall", json=payload)

        # Parse memories
        memories_adapter = TypeAdapter(list[Memory])
        memories = memories_adapter.validate_python(data.get("memories", []))

        return RecallResult(
            memories=memories,
            total_count=data.get("total_count", len(memories)),
            query_tokens=data.get("query_tokens"),
            search_latency_ms=data.get("search_latency_ms"),
        )

    def reflect(
        self,
        query: str,
        max_tokens: int = 500,
        include_sources: bool = True,
    ) -> ReflectResult:
        """
        Synthesize and summarize memories.

        Args:
            query: What to reflect on
            max_tokens: Maximum tokens in reflection (default: 500)
            include_sources: Include source memory IDs (default: True)

        Returns:
            Reflection result with synthesis

        Example:
            reflection = client.reflect(
                query="summarize everything about user's development workflow",
                max_tokens=300
            )
        """
        payload = {
            "query": query,
            "max_tokens": max_tokens,
            "include_sources": include_sources,
        }

        data = self._request("POST", "/memories/reflect", json=payload)
        return ReflectResult(**data)

    def forget(
        self,
        memory_id: str,
        hard: bool = False,
    ) -> bool:
        """
        Delete or soft-delete a memory.

        Args:
            memory_id: ID of memory to forget
            hard: Permanently delete (default: False for soft delete)

        Returns:
            True if successful

        Example:
            client.forget("mem_123", hard=False)
        """
        params = {"hard": "true" if hard else "false"}
        self._request("DELETE", f"/memories/{memory_id}", params=params)
        return True

    def get_memory(self, memory_id: str) -> Memory:
        """
        Get a specific memory by ID.

        Args:
            memory_id: Memory ID

        Returns:
            Memory object

        Example:
            memory = client.get_memory("mem_123")
        """
        data = self._request("GET", f"/memories/{memory_id}")
        return Memory(**data["memory"])

    def update_memory(
        self,
        memory_id: str,
        content: str | None = None,
        importance: float | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Memory:
        """
        Update an existing memory.

        Args:
            memory_id: Memory ID
            content: New content (optional)
            importance: New importance score (optional)
            tags: New tags (optional)
            metadata: New metadata (optional)

        Returns:
            Updated memory

        Example:
            memory = client.update_memory(
                "mem_123",
                importance=0.9,
                tags=["preferences", "high-priority"]
            )
        """
        payload = {}
        if content is not None:
            payload["content"] = content
        if importance is not None:
            payload["importance"] = importance
        if tags is not None:
            payload["tags"] = tags
        if metadata is not None:
            payload["metadata"] = metadata

        data = self._request("PUT", f"/memories/{memory_id}", json=payload)
        return Memory(**data["memory"])

    # Association methods

    def associate(
        self,
        source_id: str,
        target_id: str,
        relationship: str | RelationshipType,
        strength: float = 0.5,
        metadata: dict[str, Any] | None = None,
    ) -> Association:
        """
        Link two memories with a relationship.

        Args:
            source_id: Source memory ID
            target_id: Target memory ID
            relationship: Relationship type (string or RelationshipType enum)
            strength: Relationship strength 0.0-1.0 (default: 0.5)
            metadata: Additional metadata

        Returns:
            Created association

        Example:
            assoc = client.associate(
                source_id="mem_123",
                target_id="mem_456",
                relationship=RelationshipType.SOLVES,
                strength=0.9
            )
        """
        rel_value = _to_value(relationship)
        payload = {
            "target_id": target_id,
            "relationship": rel_value,
            "strength": strength,
        }
        if metadata:
            payload["metadata"] = metadata

        data = self._request("POST", f"/memories/{source_id}/associate", json=payload)
        return Association(**data)

    def get_associations(
        self,
        memory_id: str,
        direction: str = "both",
    ) -> list[Association]:
        """
        Get associations for a memory.

        Args:
            memory_id: Memory ID
            direction: "outgoing", "incoming", or "both" (default: "both")

        Returns:
            List of associations

        Example:
            associations = client.get_associations("mem_123")
        """
        params = {"direction": direction}
        data = self._request("GET", f"/memories/{memory_id}/associations", params=params)

        associations_adapter = TypeAdapter(list[Association])
        return associations_adapter.validate_python(data.get("associations", []))

    # Memory extension operations

    def decay(
        self,
        memory_id: str,
        decay_rate: float = 0.1,
    ) -> Memory:
        """
        Reduce memory importance by decay rate.

        Args:
            memory_id: Memory ID
            decay_rate: Rate of decay 0.0-1.0 (default: 0.1)

        Returns:
            Updated memory with decayed importance

        Example:
            memory = client.decay("mem_123", decay_rate=0.2)
        """
        payload = {"decay_rate": decay_rate}
        data = self._request("POST", f"/memories/{memory_id}/decay", json=payload)
        return Memory(**data.get("memory", data))

    def trace_memory(self, memory_id: str) -> dict[str, Any]:
        """
        Trace memory provenance back to source.

        Returns information about the memory's origin including
        source resource, category membership, and association chain.

        Args:
            memory_id: Memory ID

        Returns:
            Trace result with provenance information

        Example:
            trace = client.trace_memory("mem_123")
            print(trace["chain"])
        """
        data = self._request("GET", f"/memories/{memory_id}/trace")
        return data.get("trace", data)

    def batch_memories(
        self,
        operations: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """
        Perform multiple memory operations in a single request.

        Supported operation types:
        - create: {"type": "create", "data": {"content": "...", ...}}
        - update: {"type": "update", "data": {"memory_id": "...", "content": "..."}}
        - delete: {"type": "delete", "data": {"memory_id": "...", "hard": False}}

        Args:
            operations: List of operations to perform

        Returns:
            Results for each operation with success/error status

        Example:
            results = client.batch_memories([
                {"type": "create", "data": {"content": "Memory 1"}},
                {"type": "create", "data": {"content": "Memory 2"}},
                {"type": "delete", "data": {"memory_id": "mem_old"}}
            ])
        """
        payload = {"operations": operations}
        return self._request("POST", "/memories/batch", json=payload)

    # Session methods

    def create_session(self, ttl_seconds: int = 3600) -> Session:
        """
        Create a new working memory session.

        Args:
            ttl_seconds: Time to live in seconds (default: 3600 = 1 hour)

        Returns:
            Created session

        Example:
            session = client.create_session(ttl_seconds=7200)
        """
        payload = {"ttl_seconds": ttl_seconds}
        data = self._request("POST", "/sessions", json=payload)
        return Session(**data)

    def list_sessions(
        self,
        workspace_id: str | None = None,
        context_id: str | None = None,
        include_expired: bool = False,
    ) -> list[dict[str, Any]]:
        """
        List sessions in a workspace.

        Args:
            workspace_id: Workspace ID (defaults to client workspace)
            context_id: Optional filter by context
            include_expired: Whether to include expired sessions

        Returns:
            List of session dicts

        Example:
            sessions = client.list_sessions()
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id
        if context_id:
            params["context_id"] = context_id
        if include_expired:
            params["include_expired"] = "true"
        data = self._request("GET", "/sessions", params=params)
        return data.get("sessions", [])

    def get_session(self, session_id: str) -> Session:
        """
        Get a session by ID.

        Args:
            session_id: Session ID

        Returns:
            Session object
        """
        data = self._request("GET", f"/sessions/{session_id}")
        return Session(**data)

    def set_context(
        self,
        session_id: str,
        key: str,
        value: Any,
        ttl_seconds: int | None = None,
    ) -> None:
        """
        Set a context value in a session.

        Args:
            session_id: Session ID
            key: Context key
            value: Context value (any JSON-serializable object)
            ttl_seconds: Optional TTL for this key

        Example:
            client.set_context(
                "sess_123",
                "current_file",
                {"path": "auth.py", "line": 42}
            )
        """
        payload = {
            "key": key,
            "value": value,
        }
        if ttl_seconds is not None:
            payload["ttl_seconds"] = ttl_seconds

        self._request("POST", f"/sessions/{session_id}/memory", json=payload)

    def get_context(
        self,
        session_id: str,
        keys: list[str],
    ) -> dict[str, Any]:
        """
        Get context values from a session.

        Args:
            session_id: Session ID
            keys: List of keys to retrieve

        Returns:
            Dictionary of key-value pairs

        Example:
            context = client.get_context(
                "sess_123",
                ["current_file", "user_intent"]
            )
        """
        params = {"key": ",".join(keys)}
        data = self._request("GET", f"/sessions/{session_id}/memory", params=params)
        return data

    def get_briefing(
        self,
        lookback_hours: int | None = None,
        lookback_minutes: int = 60,
        detail_level: str = "abstract",
        limit: int = 10,
        include_memories: bool = True,
        include_contradictions: bool = True,
    ) -> SessionBriefing:
        """
        Get a session briefing with recent activity and context.

        Args:
            lookback_hours: DEPRECATED - Use lookback_minutes instead. If provided, overrides lookback_minutes.
            lookback_minutes: Time window in minutes for recent memories (default: 60)
            detail_level: Level of memory detail - "abstract", "overview", or "full" (default: "abstract")
            limit: Maximum number of recent memories to include (default: 10)
            include_memories: Whether to include recent memory content (default: True)
            include_contradictions: Flag contradicting memories in briefing (default: True)

        Returns:
            Session briefing

        Example:
            briefing = client.get_briefing(lookback_minutes=120, detail_level="full")
        """
        params = {
            "lookback_minutes": lookback_hours * 60 if lookback_hours is not None else lookback_minutes,
            "detail_level": detail_level,
            "limit": limit,
            "include_memories": str(include_memories).lower(),
            "include_contradictions": str(include_contradictions).lower(),
        }
        data = self._request("GET", "/sessions/briefing", params=params)
        return SessionBriefing(**data)

    def touch_session(self, session_id: str) -> dict[str, Any]:
        """
        Update session expiration (extend TTL).

        Args:
            session_id: Session ID

        Returns:
            Updated expiration timestamp

        Example:
            result = client.touch_session("sess_123")
            print(f"Expires at: {result['expires_at']}")
        """
        return self._request("POST", f"/sessions/{session_id}/touch")

    def commit_session(
        self,
        session_id: str,
        min_importance: float = 0.5,
        deduplicate: bool = True,
        categories: list[str] | None = None,
        max_memories: int = 50,
    ) -> dict[str, Any]:
        """
        Commit session working memory to long-term memory.

        Extracts memories from session working memory, deduplicates them,
        and creates new long-term memories.

        Args:
            session_id: Session ID
            min_importance: Minimum importance threshold (default: 0.5)
            deduplicate: Whether to deduplicate memories (default: True)
            categories: Filter by categories (optional)
            max_memories: Maximum memories to extract (default: 50)

        Returns:
            Commit result with extraction statistics

        Example:
            result = client.commit_session("sess_123")
            print(f"Created {result['memories_created']} memories")
        """
        payload: dict[str, Any] = {
            "min_importance": min_importance,
            "deduplicate": deduplicate,
            "max_memories": max_memories,
        }
        if categories is not None:
            payload["categories"] = categories

        return self._request("POST", f"/sessions/{session_id}/commit", json=payload)

    def delete_session(self, session_id: str) -> bool:
        """
        Delete a session and all its context data.

        Args:
            session_id: Session ID

        Returns:
            True if successful

        Example:
            client.delete_session("sess_123")
        """
        self._request("DELETE", f"/sessions/{session_id}")
        return True

    # Workspace methods

    def create_workspace(self, name: str) -> Workspace:
        """
        Create a new workspace.

        Args:
            name: Workspace name

        Returns:
            Created workspace

        Example:
            workspace = client.create_workspace("my-project")
        """
        payload = {"name": name}
        data = self._request("POST", "/workspaces", json=payload)
        return Workspace(**data)

    def get_workspace(self, workspace_id: str | None = None) -> Workspace:
        """
        Get workspace details.

        Args:
            workspace_id: Workspace ID (uses default if not provided)

        Returns:
            Workspace object

        Example:
            workspace = client.get_workspace()
        """
        ws_id = workspace_id or self.workspace_id
        if not ws_id:
            raise ValueError("workspace_id must be provided or set on client")

        data = self._request("GET", f"/workspaces/{ws_id}")
        return Workspace(**data)

    def update_workspace(
        self,
        workspace_id: str,
        name: str | None = None,
        settings: dict[str, Any] | None = None,
    ) -> Workspace:
        """
        Update an existing workspace.

        Args:
            workspace_id: Workspace ID
            name: New workspace name (optional)
            settings: New workspace settings (optional)

        Returns:
            Updated workspace

        Example:
            workspace = client.update_workspace(
                "ws_123",
                name="New Name",
                settings={"key": "value"}
            )
        """
        payload = {}
        if name is not None:
            payload["name"] = name
        if settings is not None:
            payload["settings"] = settings

        data = self._request("PUT", f"/workspaces/{workspace_id}", json=payload)
        return Workspace(**data.get("workspace", data))

    def create_context(
        self,
        workspace_id: str,
        name: str,
        description: str | None = None,
        settings: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Create a context within a workspace.

        Contexts provide logical grouping of memories (e.g., by project, topic).

        Args:
            workspace_id: Parent workspace ID
            name: Context name
            description: Context description (optional)
            settings: Context settings (optional)

        Returns:
            Created context

        Example:
            context = client.create_context(
                "ws_123",
                name="project-alpha",
                description="Memories for Project Alpha"
            )
        """
        payload: dict[str, Any] = {"name": name}
        if description is not None:
            payload["description"] = description
        if settings is not None:
            payload["settings"] = settings

        data = self._request("POST", f"/workspaces/{workspace_id}/contexts", json=payload)
        return data.get("context", data)

    def list_contexts(self, workspace_id: str) -> list[dict[str, Any]]:
        """
        List all contexts in a workspace.

        Args:
            workspace_id: Workspace ID

        Returns:
            List of contexts

        Example:
            contexts = client.list_contexts("ws_123")
        """
        data = self._request("GET", f"/workspaces/{workspace_id}/contexts")
        return data.get("contexts", [])

    def get_workspace_schema(self, workspace_id: str) -> dict[str, Any]:
        """
        Get workspace schema including relationship types and memory subtypes.

        Args:
            workspace_id: Workspace ID

        Returns:
            Schema with relationship_types, memory_subtypes, and can_customize flag

        Example:
            schema = client.get_workspace_schema("ws_123")
            print(schema["relationship_types"])
        """
        return self._request("GET", f"/workspaces/{workspace_id}/schema")

    # Context Environment operations

    def context_exec(
        self,
        code: str,
        result_var: str | None = None,
        return_result: bool = True,
        max_return_chars: int = 10_000,
    ) -> dict[str, Any]:
        """Execute Python code in the session's sandbox environment."""
        payload: dict[str, Any] = {
            "code": code,
            "return_result": return_result,
            "max_return_chars": max_return_chars,
        }
        if result_var is not None:
            payload["result_var"] = result_var
        return self._request("POST", "/context/execute", json=payload)

    def context_inspect(
        self,
        variable: str | None = None,
        preview_chars: int = 200,
    ) -> dict[str, Any]:
        """Inspect sandbox state or a specific variable."""
        params: dict[str, Any] = {"preview_chars": preview_chars}
        if variable is not None:
            params["variable"] = variable
        return self._request("POST", "/context/inspect", params=params)

    def context_load(
        self,
        var: str,
        query: str,
        limit: int = 50,
        types: list[str] | None = None,
        tags: list[str] | None = None,
        min_relevance: float | None = None,
        include_embeddings: bool = False,
    ) -> dict[str, Any]:
        """Load memories into the sandbox as a variable."""
        payload: dict[str, Any] = {
            "var": var,
            "query": query,
            "limit": limit,
            "include_embeddings": include_embeddings,
        }
        if types is not None:
            payload["types"] = types
        if tags is not None:
            payload["tags"] = tags
        if min_relevance is not None:
            payload["min_relevance"] = min_relevance
        return self._request("POST", "/context/load", json=payload)

    def context_inject(
        self,
        key: str,
        value: Any,
        parse_json: bool = False,
    ) -> dict[str, Any]:
        """Inject a value into the sandbox state."""
        payload: dict[str, Any] = {
            "key": key,
            "value": value,
            "parse_json": parse_json,
        }
        return self._request("POST", "/context/inject", json=payload)

    def context_query(
        self,
        prompt: str,
        variables: list[str],
        max_context_chars: int | None = None,
        result_var: str | None = None,
    ) -> dict[str, Any]:
        """Send sandbox variables and a prompt to the LLM."""
        payload: dict[str, Any] = {
            "prompt": prompt,
            "variables": variables,
        }
        if max_context_chars is not None:
            payload["max_context_chars"] = max_context_chars
        if result_var is not None:
            payload["result_var"] = result_var
        return self._request("POST", "/context/query", json=payload)

    def context_rlm(
        self,
        goal: str,
        memory_query: str | None = None,
        memory_limit: int = 100,
        max_iterations: int = 10,
        variables: list[str] | None = None,
        result_var: str | None = None,
        detail_level: str = "standard",
    ) -> dict[str, Any]:
        """Run a Recursive Language Model (RLM) loop."""
        payload: dict[str, Any] = {
            "goal": goal,
            "memory_limit": memory_limit,
            "max_iterations": max_iterations,
            "detail_level": detail_level,
        }
        if memory_query is not None:
            payload["memory_query"] = memory_query
        if variables is not None:
            payload["variables"] = variables
        if result_var is not None:
            payload["result_var"] = result_var
        return self._request("POST", "/context/rlm", json=payload)

    def context_status(self) -> dict[str, Any]:
        """Get the status of the session's sandbox environment."""
        return self._request("GET", "/context/status")

    def context_checkpoint(self) -> None:
        """Checkpoint the session's sandbox state for persistence."""
        self._request("POST", "/context/checkpoint")

    def context_cleanup(self) -> None:
        """Clean up and remove the session's sandbox environment."""
        self._request("DELETE", "/context/cleanup")

    # ------------------------------------------------------------------ #
    # Chat history operations
    # ------------------------------------------------------------------ #

    def create_thread(
        self,
        *,
        workspace_id: str | None = None,
        thread_id: str | None = None,
        user_id: str | None = None,
        context_id: str | None = None,
        observer_id: str | None = None,
        subject_id: str | None = None,
        title: str | None = None,
        metadata: dict[str, Any] | None = None,
        expires_at: str | None = None,
        scope: str | None = None,
    ) -> ChatThread:
        """
        Create a new chat thread.

        Args:
            workspace_id: Workspace ID (uses default if not provided)
            thread_id: Optional explicit thread ID
            user_id: Optional user ID to associate with the thread
            context_id: Optional context ID (default: "_default")
            observer_id: Optional observer ID
            subject_id: Optional subject ID
            title: Optional thread title
            metadata: Additional metadata
            expires_at: Optional expiry timestamp (ISO 8601 string)
            scope: Surface scope: 'web' | 'office' | None (≡ 'web')

        Returns:
            Created ChatThread

        Example:
            thread = client.create_thread(user_id="user_123", title="My Chat")
        """
        payload: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            payload["workspace_id"] = ws_id
        if thread_id is not None:
            payload["id"] = thread_id
        if user_id is not None:
            payload["user_id"] = user_id
        if context_id is not None:
            payload["context_id"] = context_id
        if observer_id is not None:
            payload["observer_id"] = observer_id
        if subject_id is not None:
            payload["subject_id"] = subject_id
        if title is not None:
            payload["title"] = title
        if metadata is not None:
            payload["metadata"] = metadata
        if expires_at is not None:
            payload["expires_at"] = expires_at
        if scope is not None:
            payload["scope"] = scope

        data = self._request("POST", "/threads", json=payload)
        return ChatThread(**data)

    def list_threads(
        self,
        *,
        workspace_id: str | None = None,
        user_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
        scope_filter: str | None = None,
    ) -> list[ChatThread]:
        """
        List chat threads.

        Args:
            workspace_id: Workspace ID (uses default if not provided)
            user_id: Optional filter by user ID
            limit: Maximum threads to return (default: 50)
            offset: Pagination offset (default: 0)

        Returns:
            List of ChatThread objects

        Example:
            threads = client.list_threads(limit=20)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id
        if user_id is not None:
            params["user_id"] = user_id
        if scope_filter is not None:
            params["scope_filter"] = scope_filter

        data = self._request("GET", "/threads", params=params)
        threads_adapter = TypeAdapter(list[ChatThread])
        return threads_adapter.validate_python(data.get("threads", data if isinstance(data, list) else []))

    def get_thread(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
    ) -> ChatThread:
        """
        Get thread metadata.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)

        Returns:
            ChatThread object

        Example:
            thread = client.get_thread("thread_123")
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        data = self._request("GET", f"/threads/{thread_id}", params=params or None)
        return ChatThread(**data)

    def get_thread_full(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
        order: str = "asc",
    ) -> ChatThreadWithMessages:
        """
        Get thread with messages inlined.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)
            limit: Maximum messages to return (default: 100)
            offset: Pagination offset (default: 0)
            order: Message order "asc" or "desc" (default: "asc")

        Returns:
            ChatThreadWithMessages object

        Example:
            full = client.get_thread_full("thread_123")
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset, "order": order}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        data = self._request("GET", f"/threads/{thread_id}/full", params=params)
        return ChatThreadWithMessages(**data)

    def delete_thread(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
    ) -> None:
        """
        Delete a thread and its messages.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)

        Example:
            client.delete_thread("thread_123")
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        self._request("DELETE", f"/threads/{thread_id}", params=params or None)

    def append_messages(
        self,
        thread_id: str,
        messages: list[dict[str, Any]],
        *,
        workspace_id: str | None = None,
    ) -> list[ChatMessage]:
        """
        Append messages to a thread.

        Args:
            thread_id: Thread ID
            messages: List of message dicts, each with: role, content, metadata (optional)
            workspace_id: Workspace ID (uses default if not provided)

        Returns:
            List of created ChatMessage objects

        Example:
            msgs = client.append_messages(
                "thread_123",
                [{"role": "user", "content": "Hello"}, {"role": "assistant", "content": "Hi!"}]
            )
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        payload: dict[str, Any] = {"messages": messages}
        data = self._request(
            "POST",
            f"/threads/{thread_id}/messages",
            json=payload,
            params=params or None,
        )
        messages_adapter = TypeAdapter(list[ChatMessage])
        return messages_adapter.validate_python(data.get("messages", data if isinstance(data, list) else []))

    def get_messages(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
        after_index: int | None = None,
        order: str = "asc",
    ) -> list[ChatMessage]:
        """
        Get messages from a thread.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)
            limit: Maximum messages to return (default: 100)
            offset: Pagination offset (default: 0)
            after_index: Only return messages after this index (optional)
            order: Message order "asc" or "desc" (default: "asc")

        Returns:
            List of ChatMessage objects

        Example:
            messages = client.get_messages("thread_123", limit=50)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset, "order": order}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id
        if after_index is not None:
            params["after_index"] = after_index

        data = self._request("GET", f"/threads/{thread_id}/messages", params=params)
        messages_adapter = TypeAdapter(list[ChatMessage])
        return messages_adapter.validate_python(data.get("messages", data if isinstance(data, list) else []))

    def decompose_thread(
        self,
        thread_id: str,
        *,
        workspace_id: str | None = None,
    ) -> DecompositionResult:
        """
        Trigger memory decomposition for unprocessed messages.

        Args:
            thread_id: Thread ID
            workspace_id: Workspace ID (uses default if not provided)

        Returns:
            DecompositionResult with processing statistics

        Example:
            result = client.decompose_thread("thread_123")
            print(f"Processed {result.messages_processed} messages")
        """
        params: dict[str, Any] = {}
        ws_id = workspace_id or self.workspace_id
        if ws_id:
            params["workspace_id"] = ws_id

        data = self._request(
            "POST",
            f"/threads/{thread_id}/decompose",
            params=params or None,
        )
        return DecompositionResult(**data)

    # ------------------------------------------------------------------ #
    # Document operations (Enterprise)
    # ------------------------------------------------------------------ #

    def upload_document(
        self,
        file_data: bytes,
        filename: str,
        *,
        target_context_id: str = "_default",
        chunking_strategy: str = "page",
        chunk_size: int = 4096,
        chunk_overlap: int = 200,
        importance: float = 0.5,
        retain_original: bool = True,
    ) -> tuple[DocumentInfo, JobInfo]:
        """Upload a document for ingestion (Enterprise)."""
        client = self._ensure_client()

        try:
            response = client.post(
                "/documents",
                files={"file": (filename, file_data)},
                data={
                    "target_context_id": target_context_id,
                    "chunking_strategy": chunking_strategy,
                    "chunk_size": str(chunk_size),
                    "chunk_overlap": str(chunk_overlap),
                    "importance": str(importance),
                    "retain_original": str(retain_original).lower(),
                },
            )

            if response.status_code == 501:
                raise EnterpriseRequiredError(feature="Document ingestion")
            response.raise_for_status()

            data = response.json()
            return (
                DocumentInfo(**data["document"]),
                JobInfo(**data["job"]),
            )
        except EnterpriseRequiredError:
            raise
        except httpx.HTTPStatusError as exc:
            raise MemoryLayerError(
                str(exc),
                status_code=exc.response.status_code,
            )

    def list_documents(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[DocumentInfo], int]:
        """List documents in the workspace."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status

        data = self._request(
            "GET",
            "/documents",
            params=params,
            enterprise_feature="Document management",
        )
        docs = [DocumentInfo(**d) for d in data.get("documents", [])]
        return docs, data.get("total_count", len(docs))

    def get_document(self, document_id: str) -> DocumentInfo:
        """Get document metadata and processing status."""
        data = self._request(
            "GET",
            f"/documents/{document_id}",
            enterprise_feature="Document management",
        )
        return DocumentInfo(**data)

    def delete_document(
        self,
        document_id: str,
        *,
        delete_memories: bool = False,
    ) -> None:
        """Delete a document and optionally its extracted memories."""
        self._request(
            "DELETE",
            f"/documents/{document_id}",
            params={"delete_memories": str(delete_memories).lower()},
            enterprise_feature="Document management",
        )

    def search_document_pages(
        self,
        query: str,
        *,
        limit: int = 10,
        doc_ids: list[str] | None = None,
    ) -> PageSearchResult:
        """Search document pages using ColPali MaxSim (Enterprise)."""
        payload: dict[str, Any] = {"query": query, "limit": limit}
        if doc_ids:
            payload["doc_ids"] = doc_ids

        data = self._request(
            "POST",
            "/documents/search",
            json=payload,
            enterprise_feature="Document page search",
        )
        return PageSearchResult(
            pages=[DocumentPage(**p) for p in data.get("pages", [])],
            total_count=data.get("total_count", 0),
            query=data.get("query", query),
        )

    def get_document_pages(self, document_id: str) -> list[DocumentPage]:
        """Get all pages for a document."""
        data = self._request(
            "GET",
            f"/documents/{document_id}/pages",
            enterprise_feature="Document pages",
        )
        return [DocumentPage(**p) for p in data.get("pages", [])]

    def get_page_image(self, document_id: str, page_id: str) -> bytes:
        """Get a page image as raw PNG bytes (Enterprise)."""
        client = self._ensure_client()

        try:
            response = client.get(
                f"/documents/{document_id}/pages/{page_id}/image",
            )
            if response.status_code == 501:
                raise EnterpriseRequiredError(feature="Document page images")
            response.raise_for_status()
            return response.content
        except EnterpriseRequiredError:
            raise
        except httpx.HTTPStatusError as exc:
            raise MemoryLayerError(
                str(exc),
                status_code=exc.response.status_code,
            )

    def get_job(self, job_id: str) -> JobInfo:
        """Get ingestion job status and progress."""
        data = self._request(
            "GET",
            f"/documents/jobs/{job_id}",
            enterprise_feature="Document ingestion jobs",
        )
        return JobInfo(**data)

    def list_jobs(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
    ) -> list[JobInfo]:
        """List ingestion jobs in the workspace."""
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status

        data = self._request(
            "GET",
            "/documents/jobs",
            params=params,
            enterprise_feature="Document ingestion jobs",
        )
        return [JobInfo(**j) for j in data.get("jobs", [])]

    def cancel_job(self, job_id: str) -> None:
        """Cancel a queued or running ingestion job."""
        self._request(
            "POST",
            f"/documents/jobs/{job_id}/cancel",
            enterprise_feature="Document ingestion jobs",
        )

    def reprocess_document(
        self,
        document_id: str,
        *,
        target_context_id: str | None = None,
        chunking_strategy: str | None = None,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
        importance: float | None = None,
    ) -> JobInfo:
        """Reprocess a document with different extraction options."""
        payload: dict[str, Any] = {}
        if target_context_id is not None:
            payload["target_context_id"] = target_context_id
        if chunking_strategy is not None:
            payload["chunking_strategy"] = chunking_strategy
        if chunk_size is not None:
            payload["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            payload["chunk_overlap"] = chunk_overlap
        if importance is not None:
            payload["importance"] = importance

        data = self._request(
            "POST",
            f"/documents/{document_id}/reprocess",
            json=payload if payload else None,
            enterprise_feature="Document reprocessing",
        )
        return JobInfo(**data)

    # ------------------------------------------------------------------ #
    # Dataset operations (Enterprise)
    # ------------------------------------------------------------------ #

    def upload_dataset(
        self,
        file_data: bytes,
        filename: str,
        *,
        name: str | None = None,
        target_context_id: str = "_default",
        importance: float = 0.5,
        sample_rows: int = 1000,
        detect_time_series: bool = True,
        generate_summaries: bool = True,
    ) -> tuple[DatasetInfo, DatasetJobInfo]:
        """Upload a dataset for profiling and memory extraction (Enterprise)."""
        client = self._ensure_client()

        form_data: dict[str, str] = {
            "target_context_id": target_context_id,
            "importance": str(importance),
            "sample_rows": str(sample_rows),
            "detect_time_series": str(detect_time_series).lower(),
            "generate_summaries": str(generate_summaries).lower(),
        }
        if name is not None:
            form_data["name"] = name

        try:
            response = client.post(
                "/datasets",
                files={"file": (filename, file_data)},
                data=form_data,
            )

            if response.status_code == 501:
                raise EnterpriseRequiredError(feature="Dataset management")
            response.raise_for_status()

            data = response.json()
            return (
                DatasetInfo(**data["dataset"]),
                DatasetJobInfo(**data["job"]),
            )
        except EnterpriseRequiredError:
            raise
        except httpx.HTTPStatusError as exc:
            raise MemoryLayerError(
                str(exc),
                status_code=exc.response.status_code,
            )

    def list_datasets(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[DatasetInfo], int]:
        """List datasets in the workspace."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status

        data = self._request(
            "GET",
            "/datasets",
            params=params,
            enterprise_feature="Dataset management",
        )
        datasets = [DatasetInfo(**d) for d in data.get("datasets", [])]
        return datasets, data.get("total_count", len(datasets))

    def get_dataset(self, dataset_id: str) -> DatasetInfo:
        """Get dataset metadata, schema, and profile."""
        data = self._request(
            "GET",
            f"/datasets/{dataset_id}",
            enterprise_feature="Dataset management",
        )
        return DatasetInfo(**data)

    def delete_dataset(
        self,
        dataset_id: str,
        *,
        delete_memories: bool = False,
    ) -> None:
        """Delete a dataset and optionally its extracted memories."""
        self._request(
            "DELETE",
            f"/datasets/{dataset_id}",
            params={"delete_memories": str(delete_memories).lower()},
            enterprise_feature="Dataset management",
        )

    def get_dataset_memories(
        self,
        dataset_id: str,
    ) -> list[dict[str, Any]]:
        """Get memories extracted from a dataset."""
        data = self._request(
            "GET",
            f"/datasets/{dataset_id}/memories",
            enterprise_feature="Dataset management",
        )
        return data.get("memories", [])

    def query_dataset_slice(
        self,
        dataset_id: str,
        *,
        sql: str | None = None,
        columns: list[str] | None = None,
        filters: list[dict[str, Any]] | None = None,
        order_by: str | None = None,
        descending: bool = False,
        limit: int = 100,
        offset: int = 0,
    ) -> DatasetSliceResult:
        """Query a slice of dataset data using DuckDB (Enterprise)."""
        payload: dict[str, Any] = {
            "limit": limit,
            "offset": offset,
            "descending": descending,
        }
        if sql is not None:
            payload["sql"] = sql
        if columns is not None:
            payload["columns"] = columns
        if filters is not None:
            payload["filters"] = filters
        if order_by is not None:
            payload["order_by"] = order_by

        data = self._request(
            "POST",
            f"/datasets/{dataset_id}/slice",
            json=payload,
            enterprise_feature="Dataset management",
        )
        return DatasetSliceResult(**data)

    def get_dataset_job(self, job_id: str) -> DatasetJobInfo:
        """Get dataset processing job status and progress."""
        data = self._request(
            "GET",
            f"/datasets/jobs/{job_id}",
            enterprise_feature="Dataset processing jobs",
        )
        return DatasetJobInfo(**data)

    def list_dataset_jobs(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
    ) -> list[DatasetJobInfo]:
        """List dataset processing jobs in the workspace."""
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status

        data = self._request(
            "GET",
            "/datasets/jobs",
            params=params,
            enterprise_feature="Dataset processing jobs",
        )
        return [DatasetJobInfo(**j) for j in data.get("jobs", [])]

    def cancel_dataset_job(self, job_id: str) -> None:
        """Cancel a queued or running dataset processing job."""
        self._request(
            "POST",
            f"/datasets/jobs/{job_id}/cancel",
            enterprise_feature="Dataset processing jobs",
        )

    def export_workspace(
        self,
        workspace_id: str | None = None,
        include_associations: bool = True,
        offset: int = 0,
        limit: int = 0,
    ) -> dict:
        """Export workspace memories and associations as JSON.

        Args:
            workspace_id: Workspace to export (uses default if not specified)
            include_associations: Whether to include associations
            offset: Skip first N memories (default: 0)
            limit: Maximum memories to export (default: 0 = all)

        Returns:
            Export data dictionary with memories and associations

        Example:
            data = client.export_workspace("ws_123")
            print(f"Exported {len(data['memories'])} memories")
        """
        ws_id = workspace_id or self.workspace_id
        if not ws_id:
            raise ValueError("Workspace ID required")
        params = {
            "include_associations": str(include_associations).lower(),
            "offset": str(offset),
            "limit": str(limit),
        }

        # Fetch raw NDJSON response
        client = self._ensure_client()
        response = client.get(f"/workspaces/{ws_id}/export", params=params)

        # Handle errors
        if response.status_code >= 400:
            if response.status_code == 401:
                raise AuthenticationError(response.json().get("detail", "Authentication failed"))
            elif response.status_code == 404:
                raise NotFoundError(response.json().get("detail", "Resource not found"))
            elif response.status_code == 422:
                raise ValidationError(response.json().get("detail", "Validation error"))
            else:
                raise MemoryLayerError(
                    response.json().get("detail", "Request failed"),
                    status_code=response.status_code,
                )

        response.raise_for_status()

        # Parse NDJSON response
        text = response.text
        lines = [line.strip() for line in text.strip().split("\n") if line.strip()]

        header = None
        memories = []
        associations = []

        for line in lines:
            parsed = json.loads(line)
            if parsed.get("type") == "header":
                header = parsed
            elif parsed.get("type") == "memory":
                memories.append(parsed["data"])
            elif parsed.get("type") == "association":
                associations.append(parsed["data"])

        # Build backward-compatible response
        return {
            "version": header.get("version", "1.0") if header else "1.0",
            "workspace_id": header.get("workspace_id", ws_id) if header else ws_id,
            "exported_at": header.get("exported_at", "") if header else "",
            "total_memories": header.get("total_memories", len(memories)) if header else len(memories),
            "total_associations": header.get("total_associations", len(associations)) if header else len(associations),
            "memories": memories,
            "associations": associations,
        }

    def import_workspace(
        self,
        workspace_id: str,
        data: dict,
    ) -> dict:
        """Import memories and associations into a workspace.

        Args:
            workspace_id: Target workspace ID
            data: Export data dictionary (from export_workspace)

        Returns:
            Import results with counts of imported/skipped/errors

        Example:
            result = client.import_workspace("ws_123", export_data)
            print(f"Imported {result['imported']} memories")
        """
        response = self._request("POST", f"/workspaces/{workspace_id}/import", json={"data": data})
        return response

    def export_workspace_stream(
        self,
        workspace_id: str | None = None,
        include_associations: bool = True,
        offset: int = 0,
        limit: int = 0,
    ) -> Generator[dict, None, None]:
        """Export workspace as streaming NDJSON.

        Yields parsed JSON objects line-by-line (header, memory, association, footer).

        Args:
            workspace_id: Workspace to export (uses default if not specified)
            include_associations: Whether to include associations
            offset: Skip first N memories (default: 0)
            limit: Maximum memories to export (default: 0 = all)

        Yields:
            Parsed JSON objects from NDJSON stream

        Example:
            for line in client.export_workspace_stream("ws_123"):
                if line["type"] == "memory":
                    print(f"Memory: {line['data']['content']}")
        """
        ws_id = workspace_id or self.workspace_id
        if not ws_id:
            raise ValueError("Workspace ID required")
        params = {
            "include_associations": str(include_associations).lower(),
            "offset": str(offset),
            "limit": str(limit),
        }

        client = self._ensure_client()
        response = client.get(f"/workspaces/{ws_id}/export", params=params)

        if response.status_code >= 400:
            if response.status_code == 401:
                raise AuthenticationError(response.json().get("detail", "Authentication failed"))
            elif response.status_code == 404:
                raise NotFoundError(response.json().get("detail", "Resource not found"))
            elif response.status_code == 422:
                raise ValidationError(response.json().get("detail", "Validation error"))
            else:
                raise MemoryLayerError(
                    response.json().get("detail", "Request failed"),
                    status_code=response.status_code,
                )

        response.raise_for_status()

        text = response.text
        lines = [line.strip() for line in text.strip().split("\n") if line.strip()]

        for line in lines:
            yield json.loads(line)

    def import_workspace_stream(
        self,
        workspace_id: str,
        ndjson_lines: list[dict],
    ) -> dict:
        """Import workspace from NDJSON format.

        Args:
            workspace_id: Target workspace ID
            ndjson_lines: List of dicts to serialize as NDJSON

        Returns:
            Import results with counts of imported/skipped/errors

        Example:
            lines = [
                {"type": "header", "version": "1.0", ...},
                {"type": "memory", "data": {...}},
            ]
            result = client.import_workspace_stream("ws_123", lines)
            print(f"Imported {result['imported']} memories")
        """
        # Serialize to NDJSON
        ndjson_body = "\n".join(json.dumps(line) for line in ndjson_lines)

        client = self._ensure_client()
        response = client.post(f"/workspaces/{workspace_id}/import", content=ndjson_body, headers={"Content-Type": "application/x-ndjson"})

        if response.status_code >= 400:
            if response.status_code == 401:
                raise AuthenticationError(response.json().get("detail", "Authentication failed"))
            elif response.status_code == 404:
                raise NotFoundError(response.json().get("detail", "Resource not found"))
            elif response.status_code == 422:
                raise ValidationError(response.json().get("detail", "Validation error"))
            else:
                raise MemoryLayerError(
                    response.json().get("detail", "Request failed"),
                    status_code=response.status_code,
                )

        response.raise_for_status()
        return response.json()


@contextmanager
def sync_client(
    base_url: str = "http://localhost:61001",
    api_key: str | None = None,
    workspace_id: str | None = None,
    session_id: str | None = None,
    timeout: float = 30.0,
) -> Generator[SyncMemoryLayerClient, None, None]:
    """
    Context manager for synchronous MemoryLayer client.

    Args:
        base_url: API base URL (default: http://localhost:61001)
        api_key: API key for authentication
        workspace_id: Default workspace ID for operations
        session_id: Session ID for session-based workspace resolution
        timeout: Request timeout in seconds (default: 30.0)

    Yields:
        SyncMemoryLayerClient instance

    Example:
        with sync_client(api_key="key", workspace_id="ws_123") as client:
            memory = client.remember("User prefers Python")
            results = client.recall("coding preferences")
    """
    client = SyncMemoryLayerClient(
        base_url=base_url,
        api_key=api_key,
        workspace_id=workspace_id,
        session_id=session_id,
        timeout=timeout,
    )
    with client:
        yield client
