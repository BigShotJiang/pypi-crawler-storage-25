"""
Business signals — track any business event
beyond AI token costs.

Examples:
  pradvion.signal("samsung", "email_sent", quantity=1)
  pradvion.signal("samsung", "meeting_booked", value=150.00)
"""

import hashlib
import uuid
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)


class Signal:
    """
    Represents a single business event.

    Fields:
      customer_id: Your client identifier (hashed before sending)
      event:       Event name e.g. "email_sent", "report_generated"
      quantity:    How many of this event (default 1)
      value:       Dollar value of this event (optional)
      project:     Project name (optional)
      feature:     Feature name (optional)
      team:        Team name (optional)
      environment: "production", "staging", "development" (optional)
      metadata:    Any extra key-value data (optional)
      signal_id:   Auto-generated unique ID
      timestamp:   Auto-generated UTC timestamp
    """

    __slots__ = (
        "customer_id_hash", "event", "quantity",
        "value", "project", "feature", "team",
        "environment", "metadata", "signal_id", "timestamp"
    )

    def __init__(
        self,
        customer_id: str,
        event: str,
        quantity: int = 1,
        value: Optional[float] = None,
        project: Optional[str] = None,
        feature: Optional[str] = None,
        team: Optional[str] = None,
        environment: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        if not event or not event.strip():
            raise ValueError("event name cannot be empty")
        if quantity < 0:
            raise ValueError("quantity must be >= 0")
        if value is not None and value < 0:
            raise ValueError("value must be >= 0")

        self.customer_id_hash = hashlib.sha256(
            str(customer_id).encode("utf-8")
        ).hexdigest() if customer_id else None

        self.event = event.strip().lower()
        self.quantity = quantity
        self.value = value
        self.project = project
        self.feature = feature
        self.team = team
        self.environment = environment
        self.metadata = metadata or {}
        self.signal_id = str(uuid.uuid4())
        self.timestamp = datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

    def to_payload(self) -> dict:
        payload = {
            "type": "signal",
            "signal_id": self.signal_id,
            "event": self.event,
            "quantity": self.quantity,
            "timestamp": self.timestamp,
        }
        if self.customer_id_hash:
            payload["customer_id_hash"] = self.customer_id_hash
        if self.value is not None:
            payload["value"] = round(self.value, 6)
        if self.project:
            payload["project"] = self.project
        if self.feature:
            payload["feature"] = self.feature
        if self.team:
            payload["team"] = self.team
        if self.environment:
            payload["environment"] = self.environment
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload
