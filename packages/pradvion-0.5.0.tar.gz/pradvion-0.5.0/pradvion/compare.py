"""
Multi-provider cost comparison for Pradvion SDK.
Compare AI model pricing for given token counts.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


# Pricing per 1M tokens: (input_usd_per_1m, output_usd_per_1m)
_PRICING: Dict[str, Tuple[float, float]] = {
    # ── OpenAI ────────────────────────────────────────────────────
    "gpt-4o":               (2.50,  10.00),
    "gpt-4o-mini":          (0.15,   0.60),
    "gpt-4-turbo":         (10.00,  30.00),
    "gpt-4":               (30.00,  60.00),
    "gpt-3.5-turbo":        (0.50,   1.50),
    "o1":                  (15.00,  60.00),
    "o1-mini":              (3.00,  12.00),
    "o3-mini":              (1.10,   4.40),
    # ── Anthropic ─────────────────────────────────────────────────
    "claude-3-5-sonnet-20241022": (3.00,  15.00),
    "claude-3-5-haiku-20241022":  (0.80,   4.00),
    "claude-3-opus-20240229":    (15.00,  75.00),
    "claude-3-sonnet-20240229":   (3.00,  15.00),
    "claude-3-haiku-20240307":    (0.25,   1.25),
    "claude-sonnet-4-5":          (3.00,  15.00),
    "claude-opus-4-5":           (15.00,  75.00),
    # ── Google ────────────────────────────────────────────────────
    "gemini-1.5-pro":       (1.25,   5.00),
    "gemini-1.5-flash":     (0.075,  0.30),
    "gemini-1.0-pro":       (0.50,   1.50),
}


@dataclass
class ModelCost:
    """Cost breakdown for a single model."""
    model: str
    input_cost: float
    output_cost: float
    total_cost: float
    per_1m_input: float
    per_1m_output: float


@dataclass
class ComparisonResult:
    """Result of comparing costs across multiple AI models."""
    cheapest: ModelCost
    most_expensive: ModelCost
    all_models: List[ModelCost]
    input_tokens: int
    output_tokens: int
    savings_vs_most_expensive: float


def compare_cost(
    input_tokens: int,
    output_tokens: int,
    models: Optional[List[str]] = None,
) -> ComparisonResult:
    """
    Compare costs across AI models for a given token count.

    Args:
        input_tokens:  Number of input/prompt tokens
        output_tokens: Number of output/completion tokens
        models:        Models to compare (default: all known models)

    Returns:
        ComparisonResult sorted cheapest → most expensive

    Raises:
        ValueError: If none of the requested models have pricing data

    Example:
        result = compare_cost(input_tokens=1000, output_tokens=500)
        print(f"Cheapest: {result.cheapest.model}")
        print(f"Save ${result.savings_vs_most_expensive:.4f} vs most expensive")
    """
    if models is None:
        models = list(_PRICING.keys())

    costs: List[ModelCost] = []
    for model in models:
        pricing = _PRICING.get(model)
        if pricing is None:
            continue
        per_1m_in, per_1m_out = pricing
        input_cost = (input_tokens / 1_000_000) * per_1m_in
        output_cost = (output_tokens / 1_000_000) * per_1m_out
        total_cost = input_cost + output_cost
        costs.append(ModelCost(
            model=model,
            input_cost=round(input_cost, 8),
            output_cost=round(output_cost, 8),
            total_cost=round(total_cost, 8),
            per_1m_input=per_1m_in,
            per_1m_output=per_1m_out,
        ))

    if not costs:
        raise ValueError(f"No pricing data found for models: {models}")

    costs.sort(key=lambda x: x.total_cost)
    cheapest = costs[0]
    most_expensive = costs[-1]

    return ComparisonResult(
        cheapest=cheapest,
        most_expensive=most_expensive,
        all_models=costs,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        savings_vs_most_expensive=round(
            most_expensive.total_cost - cheapest.total_cost, 8
        ),
    )


def add_custom_pricing(
    model: str,
    input_per_1m: float,
    output_per_1m: float,
) -> None:
    """
    Add or override pricing data for a model.

    Args:
        model:          Model name (e.g. "my-fine-tuned-gpt-4")
        input_per_1m:   Input token cost per 1M tokens (USD)
        output_per_1m:  Output token cost per 1M tokens (USD)

    Example:
        add_custom_pricing("my-model", input_per_1m=1.00, output_per_1m=2.00)
        result = compare_cost(1000, 500, models=["gpt-4o", "my-model"])
    """
    _PRICING[model] = (float(input_per_1m), float(output_per_1m))
