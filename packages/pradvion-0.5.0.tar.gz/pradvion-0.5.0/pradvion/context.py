"""
Thread-local context management for Pradvion SDK.

Allows setting business context (feature, team, department,
customer_id, environment, conversation_id) that is automatically
attached to all AI calls within that context.

Thread safe — Samsung's thread never sees Tesla's context.
"""

import threading
from contextlib import contextmanager
from typing import Optional, Generator


class _ContextStore:
    """Thread-local context store with stack support for nesting."""

    def __init__(self) -> None:
        self._local = threading.local()

    def _stack(self) -> list:
        if not hasattr(self._local, "stack"):
            self._local.stack = [{}]
        return self._local.stack

    def get(self) -> dict:
        """Get current context (copy)."""
        return self._stack()[-1].copy()

    def push(self, **kwargs) -> None:
        """Push new context layer inheriting from current."""
        current = self._stack()[-1].copy()
        for key, value in kwargs.items():
            if value is not None:
                current[key] = str(value)
            # None means "don't override" — inherited keys are kept
        self._stack().append(current)

    def pop(self) -> None:
        """Pop current context layer restoring previous."""
        stack = self._stack()
        if len(stack) > 1:
            stack.pop()

    def set(self, **kwargs) -> None:
        """Set values on current context layer."""
        current = self._stack()[-1]
        for key, value in kwargs.items():
            if value is not None:
                current[key] = str(value)
            elif key in current:
                del current[key]

    def clear(self) -> None:
        """Clear all context for this thread."""
        self._local.stack = [{}]


_store = _ContextStore()


@contextmanager
def context(
    feature: Optional[str] = None,
    team: Optional[str] = None,
    department: Optional[str] = None,
    customer_id: Optional[str] = None,
    environment: Optional[str] = None,
    project: Optional[str] = None,
    conversation_id: Optional[str] = None,
) -> Generator[None, None, None]:
    """
    Context manager for setting tracking context.
    All AI calls within this block are tagged automatically.
    Restores previous context on exit.

    All fields are optional. Unset fields inherit from parent
    context or are omitted from the payload.

    Args:
        feature:         Feature name (e.g. "resume-summarizer")
        team:            Team name (e.g. "hr-team")
        department:      Department name (e.g. "engineering")
        customer_id:     Customer identifier (e.g. "samsung-001")
        environment:     Environment ("production", "staging", "development")
        project:         Project name (e.g. "recruiting-tool")
        conversation_id: Conversation session ID (e.g. "conv_abc123")

    Example:
        with pradvion.context(
            feature="resume-summarizer",
            customer_id="samsung-001",
            environment="production"
        ):
            response = client.chat.completions.create(...)
    """
    _store.push(
        feature=feature,
        team=team,
        department=department,
        customer_id=customer_id,
        environment=environment,
        project=project,
        conversation_id=conversation_id,
    )
    try:
        yield
    finally:
        _store.pop()


def set_context(
    feature: Optional[str] = None,
    team: Optional[str] = None,
    department: Optional[str] = None,
    customer_id: Optional[str] = None,
    environment: Optional[str] = None,
    project: Optional[str] = None,
    conversation_id: Optional[str] = None,
) -> None:
    """
    Set tracking context for current thread.
    Use in middleware. Call clear_context() after each request.

    Example (FastAPI):
        @app.middleware("http")
        async def pradvion_middleware(request, call_next):
            user = get_current_user(request)
            pradvion.set_context(
                customer_id=user.company_id,
                environment="production"
            )
            response = await call_next(request)
            pradvion.clear_context()
            return response

    Example (Django):
        class PradvionMiddleware:
            def __call__(self, request):
                pradvion.set_context(
                    customer_id=request.user.company_id
                )
                response = self.get_response(request)
                pradvion.clear_context()
                return response
    """
    _store.set(
        feature=feature,
        team=team,
        department=department,
        customer_id=customer_id,
        environment=environment,
        project=project,
        conversation_id=conversation_id,
    )


def clear_context() -> None:
    """Clear all tracking context for current thread."""
    _store.clear()


def get_current_context() -> dict:
    """Get current tracking context for this thread."""
    return _store.get()
