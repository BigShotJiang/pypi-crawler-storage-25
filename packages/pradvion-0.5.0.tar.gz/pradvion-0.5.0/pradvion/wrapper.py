"""
AI provider client wrappers.
Drop-in replacements that track usage automatically.

Supported:
    openai.OpenAI()       — sync chat completions + streaming
    openai.AsyncOpenAI()  — async chat completions + streaming
    anthropic.Anthropic() — sync messages
"""

import logging
import time
from typing import Any, Callable, Iterator, Optional

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Real-time streaming cost tracker
# ─────────────────────────────────────────────

class StreamingCostTracker:
    """
    Real-time cost tracker for streaming responses.

    Estimates cost as tokens arrive during streaming.
    Uses output chunk count as a token proxy until
    final usage data arrives from the last chunk.

    Usage:
        tracker = StreamingCostTracker(
            provider="openai",
            model="gpt-4o",
            input_tokens=1000,
            on_token=lambda cost: print(f"~${cost:.6f}"),
        )

        for chunk in stream:
            tracker.on_chunk(chunk)
            yield chunk

        final_cost = tracker.finalize(
            actual_input_tokens=prompt_tokens,
            actual_output_tokens=completion_tokens,
        )
    """

    # Output token rates: USD per token
    _OUTPUT_RATES = {
        "openai/gpt-4o":                         0.00001,
        "openai/gpt-4o-mini":                    0.0000006,
        "openai/gpt-4-turbo":                    0.00003,
        "openai/gpt-3.5-turbo":                  0.0000015,
        "openai/o1":                             0.00006,
        "openai/o1-mini":                        0.0000044,
        "openai/o3-mini":                        0.0000044,
        "anthropic/claude-3-5-sonnet-20241022":  0.000015,
        "anthropic/claude-3-haiku-20240307":     0.00000125,
        "anthropic/claude-3-opus-20240229":      0.000075,
    }

    # Input token rates: USD per token
    _INPUT_RATES = {
        "openai/gpt-4o":                         0.0000025,
        "openai/gpt-4o-mini":                    0.00000015,
        "openai/gpt-4-turbo":                    0.00001,
        "openai/gpt-3.5-turbo":                  0.0000005,
        "openai/o1":                             0.000015,
        "openai/o1-mini":                        0.0000011,
        "openai/o3-mini":                        0.0000011,
        "anthropic/claude-3-5-sonnet-20241022":  0.000003,
        "anthropic/claude-3-haiku-20240307":     0.00000025,
        "anthropic/claude-3-opus-20240229":      0.000015,
    }

    def __init__(
        self,
        provider: str,
        model: str,
        input_tokens: int = 0,
        on_token: Optional[Callable[[float], None]] = None,
        callback_interval: int = 5,
    ) -> None:
        """
        Args:
            provider:           "openai" or "anthropic"
            model:              Model name (e.g. "gpt-4o")
            input_tokens:       Known prompt token count (optional)
            on_token:           Callback(estimated_cost: float).
                                Called every *callback_interval* chunks.
            callback_interval:  How often to fire on_token (in chunks).
        """
        self.provider = provider
        self.model = model
        self.input_tokens = input_tokens
        self.on_token = on_token
        self.callback_interval = max(1, callback_interval)

        key = f"{provider}/{model}"
        self._out_rate: float = self._OUTPUT_RATES.get(key, 0.0)
        self._in_rate: float = self._INPUT_RATES.get(key, 0.0)

        self._output_chunks: int = 0
        self._estimated_cost: float = 0.0
        self._input_cost: float = self._in_rate * input_tokens

    def on_chunk(self, chunk: Any) -> float:
        """
        Process one stream chunk and update running cost estimate.
        Fires on_token callback at the configured interval.

        Returns:
            Current estimated total cost (USD).
        """
        self._output_chunks += 1
        self._estimated_cost = (
            self._input_cost + self._out_rate * self._output_chunks
        )

        if (
            self.on_token is not None
            and self._output_chunks % self.callback_interval == 0
        ):
            try:
                self.on_token(self._estimated_cost)
            except Exception:
                pass  # Never break streaming for a callback error

        return self._estimated_cost

    def finalize(
        self,
        actual_input_tokens: int = 0,
        actual_output_tokens: int = 0,
    ) -> float:
        """
        Calculate final cost using actual token counts from the API.
        Falls back to running estimate when actuals are unavailable.

        Fires one final on_token callback with the accurate figure.

        Returns:
            Final cost in USD.
        """
        if actual_input_tokens > 0 or actual_output_tokens > 0:
            final = (
                self._in_rate * actual_input_tokens
                + self._out_rate * actual_output_tokens
            )
        else:
            final = self._estimated_cost

        if self.on_token is not None:
            try:
                self.on_token(final)
            except Exception:
                pass

        return final


# ─────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────

def monitor(client: Any, pradvion_client=None) -> Any:
    """
    One-line integration. Wraps any AI client
    and tracks all calls automatically.

    Usage:
        import pradvion
        from openai import OpenAI

        pradvion.init(api_key="nx_live_...")
        openai_client = pradvion.monitor(OpenAI())

        # All calls now tracked automatically
        response = openai_client.chat.completions.create(...)

    Supported clients:
        openai.OpenAI
        openai.AsyncOpenAI
        anthropic.Anthropic
        anthropic.AsyncAnthropic

    Returns unwrapped client if not recognized.
    Logs warning if Pradvion not initialized.
    """
    if pradvion_client is None:
        try:
            from pradvion import get_client
            pradvion_client = get_client()
        except RuntimeError:
            logger.warning(
                "pradvion.monitor() called before pradvion.init(). "
                "Call pradvion.init(api_key='nx_live_...') first."
            )
            return client

    return wrap(client, pradvion_client)


def wrap(client: Any, pradvion_client=None) -> Any:
    """
    Wrap an AI provider client for automatic cost tracking.

    Returns a drop-in replacement with identical API.
    Zero latency impact — tracking happens in background.

    Example:
        import openai
        import pradvion

        pradvion.init(api_key="nx_live_YOUR_KEY")

        # Sync
        client = pradvion.wrap(openai.OpenAI())

        # Async
        async_client = pradvion.wrap(openai.AsyncOpenAI())

        # Anthropic
        claude = pradvion.wrap(anthropic.Anthropic())
    """
    # OpenAI
    try:
        import openai as _oa
        if isinstance(client, _oa.AsyncOpenAI):
            if pradvion_client is None:
                from pradvion import get_client
                pradvion_client = get_client()
            return _AsyncOpenAIWrapper(client, pradvion_client)
        if isinstance(client, _oa.OpenAI):
            if pradvion_client is None:
                from pradvion import get_client
                pradvion_client = get_client()
            return _OpenAIWrapper(client, pradvion_client)
    except ImportError:
        pass

    # Anthropic
    try:
        import anthropic as _an
        if isinstance(client, _an.Anthropic):
            if pradvion_client is None:
                from pradvion import get_client
                pradvion_client = get_client()
            return _AnthropicWrapper(client, pradvion_client)
    except ImportError:
        pass

    logger.warning(
        "Pradvion: unsupported client type '%s' — "
        "returning unwrapped client. "
        "Supported: openai.OpenAI, openai.AsyncOpenAI, "
        "anthropic.Anthropic",
        type(client).__name__,
    )
    return client


# ─────────────────────────────────────────────
# Stream wrapper (sync)
# ─────────────────────────────────────────────

class _StreamWrapper:
    """Wraps sync streaming response to capture usage on completion."""

    def __init__(
        self,
        stream: Any,
        pradvion_client: Any,
        provider: str,
        model: str,
        start_time: float,
        ctx: dict,
        on_token: Optional[Callable[[float], None]] = None,
    ) -> None:
        self._stream = stream
        self._pradvion = pradvion_client
        self._provider = provider
        self._model = model
        self._start = start_time
        self._ctx = ctx
        self._usage = None
        self._response_id: Optional[str] = None
        self._chunk_count: int = 0
        self._error_status: int = 200
        self._cost_tracker = StreamingCostTracker(
            provider=provider,
            model=model,
            input_tokens=0,
            on_token=on_token,
            callback_interval=5,
        )

    def __iter__(self) -> Iterator:
        try:
            for chunk in self._stream:
                self._chunk_count += 1
                if self._response_id is None:
                    self._response_id = getattr(chunk, "id", None)
                usage = getattr(chunk, "usage", None)
                if usage is not None:
                    self._usage = usage
                self._cost_tracker.on_chunk(chunk)
                yield chunk
        except Exception:
            self._error_status = 500
            raise
        finally:
            self._track()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def _track(self) -> None:
        latency_ms = int((time.monotonic() - self._start) * 1000)
        input_tokens = output_tokens = cached = reasoning = 0

        if self._usage:
            input_tokens = getattr(
                self._usage, "prompt_tokens", 0
            ) or 0
            output_tokens = getattr(
                self._usage, "completion_tokens", 0
            ) or 0
            details = getattr(
                self._usage, "prompt_tokens_details", None
            )
            if details:
                cached = getattr(
                    details, "cached_tokens", 0
                ) or 0
            comp = getattr(
                self._usage, "completion_tokens_details", None
            )
            if comp:
                reasoning = getattr(
                    comp, "reasoning_tokens", 0
                ) or 0
        elif self._chunk_count > 0:
            # No usage object — use chunk count as rough output_tokens fallback
            output_tokens = self._chunk_count
            logger.debug(
                "Pradvion: no usage in stream — "
                "using chunk_count=%d as output_tokens fallback",
                self._chunk_count,
            )

        self._cost_tracker.finalize(
            actual_input_tokens=input_tokens,
            actual_output_tokens=output_tokens,
        )

        try:
            self._pradvion.track(
                provider=self._provider,
                model=self._model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                latency_ms=latency_ms,
                status_code=self._error_status,
                cached_tokens=cached,
                reasoning_tokens=reasoning,
                feature=self._ctx.get("feature"),
                team=self._ctx.get("team"),
                department=self._ctx.get("department"),
                customer_id=self._ctx.get("customer_id"),
                environment=self._ctx.get("environment"),
                conversation_id=self._ctx.get("conversation_id"),
                request_id=self._response_id,
            )
        except Exception as exc:
            logger.debug("Pradvion stream track error: %s", exc)


# ─────────────────────────────────────────────
# OpenAI sync wrapper
# ─────────────────────────────────────────────

class _ChatCompletionsWrapper:
    def __init__(
        self,
        completions: Any,
        pradvion_client: Any,
        provider: str,
    ) -> None:
        self._completions = completions
        self._pradvion = pradvion_client
        self._provider = provider

    def create(self, **kwargs) -> Any:
        # on_token is a Pradvion-specific kwarg — intercept before forwarding
        on_token = kwargs.pop("on_token", None)

        from pradvion.context import get_current_context
        model = kwargs.get("model", "unknown")
        is_stream = bool(kwargs.get("stream", False))
        ctx = get_current_context()
        start = time.monotonic()

        if is_stream:
            stream_opts = dict(kwargs.get("stream_options") or {})
            stream_opts["include_usage"] = True
            kwargs["stream_options"] = stream_opts
            stream = self._completions.create(**kwargs)
            return _StreamWrapper(
                stream=stream,
                pradvion_client=self._pradvion,
                provider=self._provider,
                model=model,
                start_time=start,
                ctx=ctx,
                on_token=on_token,
            )

        status_code = 200
        response = None
        try:
            response = self._completions.create(**kwargs)
            return response
        except Exception:
            status_code = 500
            raise
        finally:
            latency_ms = int((time.monotonic() - start) * 1000)
            input_tokens = output_tokens = cached = reasoning = 0
            response_id = None

            if response is not None:
                response_id = getattr(response, "id", None)
                usage = getattr(response, "usage", None)
                if usage:
                    input_tokens = getattr(
                        usage, "prompt_tokens", 0
                    ) or 0
                    output_tokens = getattr(
                        usage, "completion_tokens", 0
                    ) or 0
                    details = getattr(
                        usage, "prompt_tokens_details", None
                    )
                    if details:
                        cached = getattr(
                            details, "cached_tokens", 0
                        ) or 0
                    comp = getattr(
                        usage, "completion_tokens_details", None
                    )
                    if comp:
                        reasoning = getattr(
                            comp, "reasoning_tokens", 0
                        ) or 0

            try:
                self._pradvion.track(
                    provider=self._provider,
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    latency_ms=latency_ms,
                    status_code=status_code,
                    cached_tokens=cached,
                    reasoning_tokens=reasoning,
                    feature=ctx.get("feature"),
                    team=ctx.get("team"),
                    department=ctx.get("department"),
                    customer_id=ctx.get("customer_id"),
                    environment=ctx.get("environment"),
                    conversation_id=ctx.get("conversation_id"),
                    request_id=response_id,
                )
            except Exception as exc:
                logger.debug("Pradvion track error: %s", exc)


class _ChatWrapper:
    def __init__(
        self,
        chat: Any,
        pradvion_client: Any,
        provider: str,
    ) -> None:
        self._chat = chat
        self.completions = _ChatCompletionsWrapper(
            chat.completions,
            pradvion_client,
            provider,
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._chat, name)


class _OpenAIWrapper:
    """Drop-in replacement for openai.OpenAI()"""

    def __init__(self, client: Any, pradvion_client: Any) -> None:
        self._client = client
        self._pradvion = pradvion_client
        self.chat = _ChatWrapper(
            client.chat,
            self._pradvion,
            "openai",
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


# ─────────────────────────────────────────────
# OpenAI async wrapper
# ─────────────────────────────────────────────

class _AsyncStreamWrapper:
    """Wraps async streaming response."""

    def __init__(
        self,
        stream: Any,
        pradvion_client: Any,
        provider: str,
        model: str,
        start_time: float,
        ctx: dict,
        on_token: Optional[Callable[[float], None]] = None,
    ) -> None:
        self._stream = stream
        self._pradvion = pradvion_client
        self._provider = provider
        self._model = model
        self._start = start_time
        self._ctx = ctx
        self._usage = None
        self._response_id: Optional[str] = None
        self._chunk_count: int = 0
        self._error_status: int = 200
        self._cost_tracker = StreamingCostTracker(
            provider=provider,
            model=model,
            input_tokens=0,
            on_token=on_token,
            callback_interval=5,
        )

    def __aiter__(self):
        return self._aiter()

    async def _aiter(self):
        try:
            async for chunk in self._stream:
                self._chunk_count += 1
                if self._response_id is None:
                    self._response_id = getattr(chunk, "id", None)
                usage = getattr(chunk, "usage", None)
                if usage is not None:
                    self._usage = usage
                self._cost_tracker.on_chunk(chunk)
                yield chunk
        except Exception:
            self._error_status = 500
            raise
        finally:
            self._track()

    def _track(self) -> None:
        latency_ms = int((time.monotonic() - self._start) * 1000)
        input_tokens = output_tokens = cached = reasoning = 0

        if self._usage:
            input_tokens = getattr(
                self._usage, "prompt_tokens", 0
            ) or 0
            output_tokens = getattr(
                self._usage, "completion_tokens", 0
            ) or 0
        elif self._chunk_count > 0:
            output_tokens = self._chunk_count
            logger.debug(
                "Pradvion: no usage in async stream — "
                "using chunk_count=%d as output_tokens fallback",
                self._chunk_count,
            )

        self._cost_tracker.finalize(
            actual_input_tokens=input_tokens,
            actual_output_tokens=output_tokens,
        )

        try:
            self._pradvion.track(
                provider=self._provider,
                model=self._model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                latency_ms=latency_ms,
                status_code=self._error_status,
                cached_tokens=cached,
                reasoning_tokens=reasoning,
                feature=self._ctx.get("feature"),
                team=self._ctx.get("team"),
                department=self._ctx.get("department"),
                customer_id=self._ctx.get("customer_id"),
                environment=self._ctx.get("environment"),
                conversation_id=self._ctx.get("conversation_id"),
                request_id=self._response_id,
            )
        except Exception as exc:
            logger.debug("Pradvion async stream track error: %s", exc)


class _AsyncChatCompletionsWrapper:
    def __init__(
        self,
        completions: Any,
        pradvion_client: Any,
        provider: str,
    ) -> None:
        self._completions = completions
        self._pradvion = pradvion_client
        self._provider = provider

    async def create(self, **kwargs) -> Any:
        # on_token is a Pradvion-specific kwarg — intercept before forwarding
        on_token = kwargs.pop("on_token", None)

        from pradvion.context import get_current_context
        model = kwargs.get("model", "unknown")
        is_stream = bool(kwargs.get("stream", False))
        ctx = get_current_context()
        start = time.monotonic()

        if is_stream:
            stream_opts = dict(kwargs.get("stream_options") or {})
            stream_opts["include_usage"] = True
            kwargs["stream_options"] = stream_opts
            stream = await self._completions.create(**kwargs)
            return _AsyncStreamWrapper(
                stream=stream,
                pradvion_client=self._pradvion,
                provider=self._provider,
                model=model,
                start_time=start,
                ctx=ctx,
                on_token=on_token,
            )

        status_code = 200
        response = None
        try:
            response = await self._completions.create(**kwargs)
            return response
        except Exception:
            status_code = 500
            raise
        finally:
            latency_ms = int((time.monotonic() - start) * 1000)
            input_tokens = output_tokens = cached = reasoning = 0
            response_id = None

            if response is not None:
                response_id = getattr(response, "id", None)
                usage = getattr(response, "usage", None)
                if usage:
                    input_tokens = getattr(
                        usage, "prompt_tokens", 0
                    ) or 0
                    output_tokens = getattr(
                        usage, "completion_tokens", 0
                    ) or 0

            try:
                self._pradvion.track(
                    provider=self._provider,
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    latency_ms=latency_ms,
                    status_code=status_code,
                    cached_tokens=cached,
                    reasoning_tokens=reasoning,
                    feature=ctx.get("feature"),
                    team=ctx.get("team"),
                    department=ctx.get("department"),
                    customer_id=ctx.get("customer_id"),
                    environment=ctx.get("environment"),
                    conversation_id=ctx.get("conversation_id"),
                    request_id=response_id,
                )
            except Exception as exc:
                logger.debug("Pradvion async track error: %s", exc)


class _AsyncChatWrapper:
    def __init__(
        self,
        chat: Any,
        pradvion_client: Any,
        provider: str,
    ) -> None:
        self._chat = chat
        self.completions = _AsyncChatCompletionsWrapper(
            chat.completions,
            pradvion_client,
            provider,
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._chat, name)


class _AsyncOpenAIWrapper:
    """Drop-in replacement for openai.AsyncOpenAI()"""

    def __init__(self, client: Any, pradvion_client: Any) -> None:
        self._client = client
        self._pradvion = pradvion_client
        self.chat = _AsyncChatWrapper(
            client.chat,
            self._pradvion,
            "openai",
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


# ─────────────────────────────────────────────
# Anthropic sync wrapper
# ─────────────────────────────────────────────

class _MessagesWrapper:
    def __init__(
        self,
        messages: Any,
        pradvion_client: Any,
    ) -> None:
        self._messages = messages
        self._pradvion = pradvion_client

    def create(self, **kwargs) -> Any:
        from pradvion.context import get_current_context
        model = kwargs.get("model", "unknown")
        ctx = get_current_context()
        start = time.monotonic()
        status_code = 200
        response = None

        try:
            response = self._messages.create(**kwargs)
            return response
        except Exception:
            status_code = 500
            raise
        finally:
            latency_ms = int((time.monotonic() - start) * 1000)
            input_tokens = output_tokens = 0
            response_id = None

            if response is not None:
                response_id = getattr(response, "id", None)
                usage = getattr(response, "usage", None)
                if usage:
                    input_tokens = getattr(
                        usage, "input_tokens", 0
                    ) or 0
                    output_tokens = getattr(
                        usage, "output_tokens", 0
                    ) or 0

            try:
                self._pradvion.track(
                    provider="anthropic",
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    latency_ms=latency_ms,
                    status_code=status_code,
                    feature=ctx.get("feature"),
                    team=ctx.get("team"),
                    department=ctx.get("department"),
                    customer_id=ctx.get("customer_id"),
                    environment=ctx.get("environment"),
                    conversation_id=ctx.get("conversation_id"),
                    request_id=response_id,
                )
            except Exception as exc:
                logger.debug("Pradvion anthropic track error: %s", exc)


class _AnthropicWrapper:
    """Drop-in replacement for anthropic.Anthropic()"""

    def __init__(self, client: Any, pradvion_client: Any) -> None:
        self._client = client
        self._pradvion = pradvion_client
        self.messages = _MessagesWrapper(
            client.messages,
            self._pradvion,
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)
