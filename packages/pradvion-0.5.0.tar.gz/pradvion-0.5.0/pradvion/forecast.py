"""
Cost forecasting for Pradvion SDK.
Project monthly AI costs from actual spend data.
"""
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional


@dataclass
class ForecastResult:
    """Result of a monthly cost forecast."""
    projected_monthly: float   # Projected full-month spend (USD)
    daily_rate: float          # Average daily spend (USD)
    days_elapsed: int          # Days used for the forecast
    actual_spend: float        # Actual spend so far (USD)
    will_exceed_budget: bool   # True if projected > budget_limit
    days_until_budget: Optional[float]  # Days until budget exhausted
    budget_limit: Optional[float]       # Budget limit used (USD)


def forecast_monthly(
    actual_spend: float,
    days_elapsed: int,
    budget_limit: Optional[float] = None,
) -> ForecastResult:
    """
    Forecast monthly cost based on actual spend so far.

    Args:
        actual_spend: Amount spent so far (USD)
        days_elapsed: Number of days elapsed in the billing period
        budget_limit: Optional monthly budget cap (USD)

    Returns:
        ForecastResult with projected costs and budget analysis

    Example:
        result = forecast_monthly(actual_spend=10.0, days_elapsed=5)
        print(f"Projected: ${result.projected_monthly:.2f}/mo")
    """
    if days_elapsed <= 0:
        daily_rate = 0.0
        projected_monthly = 0.0
    else:
        daily_rate = actual_spend / days_elapsed
        projected_monthly = daily_rate * 30

    will_exceed = False
    days_until = None

    if budget_limit is not None and budget_limit >= 0:
        will_exceed = projected_monthly > budget_limit
        if daily_rate > 0:
            remaining = budget_limit - actual_spend
            days_until = max(0.0, remaining / daily_rate)
        else:
            days_until = None if actual_spend < (budget_limit or 0) else 0.0

    return ForecastResult(
        projected_monthly=round(projected_monthly, 8),
        daily_rate=round(daily_rate, 8),
        days_elapsed=days_elapsed,
        actual_spend=round(actual_spend, 8),
        will_exceed_budget=will_exceed,
        days_until_budget=days_until,
        budget_limit=budget_limit,
    )


def forecast_from_requests(
    requests: List[dict],
    budget_limit: Optional[float] = None,
) -> ForecastResult:
    """
    Forecast monthly cost from a list of usage request records.

    Each request dict should contain:
        - cost_usd (float): cost of the request in USD
        - timestamp (str):  ISO-8601 timestamp (e.g. "2024-01-03T12:00:00Z")

    Args:
        requests:     List of request dicts
        budget_limit: Optional monthly budget cap (USD)

    Returns:
        ForecastResult with projected costs

    Example:
        result = forecast_from_requests([
            {"cost_usd": 0.05, "timestamp": "2024-01-01T10:00:00Z"},
            {"cost_usd": 0.03, "timestamp": "2024-01-03T12:00:00Z"},
        ])
    """
    if not requests:
        return ForecastResult(
            projected_monthly=0.0,
            daily_rate=0.0,
            days_elapsed=0,
            actual_spend=0.0,
            will_exceed_budget=False,
            days_until_budget=None,
            budget_limit=budget_limit,
        )

    total_cost = sum(float(r.get("cost_usd", 0)) for r in requests)

    timestamps = []
    for r in requests:
        ts = r.get("timestamp")
        if ts:
            try:
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                timestamps.append(dt)
            except (ValueError, AttributeError):
                pass

    if len(timestamps) >= 2:
        timestamps.sort()
        delta = timestamps[-1] - timestamps[0]
        days_elapsed = max(1, delta.days + 1)
    elif len(timestamps) == 1:
        days_elapsed = 1
    else:
        days_elapsed = max(1, len(requests))

    return forecast_monthly(
        actual_spend=total_cost,
        days_elapsed=days_elapsed,
        budget_limit=budget_limit,
    )
