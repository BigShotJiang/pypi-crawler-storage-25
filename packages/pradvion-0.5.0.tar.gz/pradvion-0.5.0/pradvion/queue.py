import sqlite3
import json
import os
import logging
import threading
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)


class LocalQueue:
    """
    Persistent local queue using SQLite.
    Events survive app crashes and Pradvion downtime.
    Zero data loss guaranteed.
    """

    def __init__(self, db_path: Optional[str] = None) -> None:
        if db_path is None:
            home = Path.home()
            pradvion_dir = home / ".pradvion"
            pradvion_dir.mkdir(exist_ok=True)
            db_path = str(pradvion_dir / "queue.db")

        self.db_path = db_path
        self._lock = threading.Lock()
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        """Create queue table if not exists."""
        with self._lock:
            with self._conn() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS events (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        payload TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        attempts INTEGER DEFAULT 0,
                        last_attempt_at TEXT,
                        status TEXT DEFAULT 'pending'
                    )
                """)
                conn.execute("""
                    CREATE INDEX IF NOT EXISTS
                    idx_status ON events(status)
                """)
                conn.commit()

    def push(self, payload: dict) -> int:
        """
        Write event to local queue.
        This is instant and never fails.
        Returns event ID.
        """
        with self._lock:
            with self._conn() as conn:
                cursor = conn.execute(
                    """INSERT INTO events
                       (payload, created_at, status)
                       VALUES (?, ?, 'pending')""",
                    (
                        json.dumps(payload),
                        datetime.now(timezone.utc).isoformat(),
                    ),
                )
                conn.commit()
                return cursor.lastrowid

    def pop_pending(self, limit: int = 10) -> list:
        """
        Get pending events for sending.
        Returns list of (id, payload) tuples.
        """
        with self._lock:
            with self._conn() as conn:
                rows = conn.execute(
                    """SELECT id, payload FROM events
                       WHERE status = 'pending'
                       ORDER BY id ASC
                       LIMIT ?""",
                    (limit,),
                ).fetchall()
                return [(r["id"], json.loads(r["payload"]))
                        for r in rows]

    def mark_sent(self, event_id: int) -> None:
        """Mark event as successfully sent."""
        with self._lock:
            with self._conn() as conn:
                conn.execute(
                    """UPDATE events
                       SET status = 'sent'
                       WHERE id = ?""",
                    (event_id,),
                )
                conn.commit()

    def mark_failed(self, event_id: int) -> None:
        """Increment attempt count. Keep as pending for retry."""
        with self._lock:
            with self._conn() as conn:
                conn.execute(
                    """UPDATE events
                       SET attempts = attempts + 1,
                           last_attempt_at = ?
                       WHERE id = ?""",
                    (
                        datetime.now(timezone.utc).isoformat(),
                        event_id,
                    ),
                )
                conn.commit()

    def pending_count(self) -> int:
        """Number of pending events in queue."""
        with self._lock:
            with self._conn() as conn:
                row = conn.execute(
                    "SELECT COUNT(*) as n FROM events "
                    "WHERE status = 'pending'"
                ).fetchone()
                return row["n"] if row else 0

    def cleanup_sent(self, keep_days: int = 7) -> int:
        """Delete sent events older than keep_days."""
        with self._lock:
            with self._conn() as conn:
                cursor = conn.execute(
                    """DELETE FROM events
                       WHERE status = 'sent'
                       AND created_at < datetime('now', ?)""",
                    (f"-{keep_days} days",),
                )
                conn.commit()
                return cursor.rowcount
