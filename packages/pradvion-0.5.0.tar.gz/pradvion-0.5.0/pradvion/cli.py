"""
Pradvion Auto-Instrument CLI.

Automatically adds Pradvion tracking to your existing AI code
with zero manual changes.

Usage:
    pradvion-instrument              # instrument current directory
    pradvion-instrument src/         # instrument specific directory
    pradvion-instrument app.py       # instrument single file
    pradvion-instrument --dry-run    # preview without changes
    pradvion-instrument --undo       # remove instrumentation

How it works:
    1. Scans Python files for OpenAI/Anthropic imports
    2. Shows you exactly what will change
    3. Asks for confirmation
    4. Applies changes (or --dry-run to preview only)

What it adds:
    import pradvion
    pradvion.init(api_key=os.environ["PRADVION_API_KEY"])
    client = pradvion.monitor(client)

What it NEVER does:
    - Never modifies test files
    - Never modifies __init__.py files
    - Never changes your AI call arguments
    - Never captures prompts or responses
    - Never overwrites existing pradvion.init() calls
"""

import argparse
import difflib
import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional


# ── Skip rules ────────────────────────────────────────────────────

_SKIP_DIRS = {
    ".git", ".pytest_cache", "__pycache__",
    "node_modules", ".venv", "venv", "env",
    "dist", "build", ".eggs", "site-packages",
}

_SKIP_FILES = {
    "__init__.py", "conftest.py", "setup.py", "manage.py",
}

_SKIP_PATTERNS = [
    r"test_.*\.py$",
    r".*_test\.py$",
    r".*\.min\.py$",
]

# ── Detection patterns ────────────────────────────────────────────

_OPENAI_IMPORT_PATTERNS = [
    r"from openai import .*OpenAI",
    r"import openai",
    r"OpenAI\(",
    r"AsyncOpenAI\(",
]

_ANTHROPIC_IMPORT_PATTERNS = [
    r"from anthropic import .*Anthropic",
    r"import anthropic",
    r"Anthropic\(",
    r"AsyncAnthropic\(",
]

_ALREADY_INSTRUMENTED = r"pradvion\.monitor\s*\("
_ALREADY_INIT = r"pradvion\.init\s*\("


# ── File filtering ────────────────────────────────────────────────

def _should_skip_file(path: Path) -> bool:
    """Return True if this file should not be instrumented."""
    name = path.name

    if name in _SKIP_FILES:
        return True

    for pattern in _SKIP_PATTERNS:
        if re.search(pattern, name):
            return True

    if path.suffix != ".py":
        return True

    return False


def _should_skip_dir(path: Path) -> bool:
    """Return True if this directory should be skipped entirely."""
    return path.name in _SKIP_DIRS


def _find_python_files(root: Path) -> List[Path]:
    """Recursively collect Python files eligible for instrumentation."""
    if root.is_file():
        return [] if _should_skip_file(root) else [root]

    files: List[Path] = []
    for item in sorted(root.rglob("*.py")):
        parts = item.parts
        if any(p.startswith(".") or p in _SKIP_DIRS for p in parts):
            continue
        if not _should_skip_file(item):
            files.append(item)

    return files


# ── Detection ────────────────────────────────────────────────────

def _detect_ai_usage(content: str) -> Dict:
    """
    Detect AI library usage in Python source content.

    Returns:
        dict with keys:
            has_openai          — bool
            has_anthropic       — bool
            already_instrumented — bool
            already_init        — bool
            openai_clients      — list[str] of variable names
            anthropic_clients   — list[str] of variable names
    """
    result: Dict = {
        "has_openai": False,
        "has_anthropic": False,
        "already_instrumented": False,
        "already_init": False,
        "openai_clients": [],
        "anthropic_clients": [],
    }

    if re.search(_ALREADY_INSTRUMENTED, content):
        result["already_instrumented"] = True

    if re.search(_ALREADY_INIT, content):
        result["already_init"] = True

    for pattern in _OPENAI_IMPORT_PATTERNS:
        if re.search(pattern, content):
            result["has_openai"] = True
            break

    for pattern in _ANTHROPIC_IMPORT_PATTERNS:
        if re.search(pattern, content):
            result["has_anthropic"] = True
            break

    openai_vars = re.findall(
        r"(\w+)\s*=\s*(?:openai\.)?(?:Async)?OpenAI\s*\(",
        content,
    )
    result["openai_clients"] = list(dict.fromkeys(openai_vars))

    anthropic_vars = re.findall(
        r"(\w+)\s*=\s*(?:anthropic\.)?(?:Async)?Anthropic\s*\(",
        content,
    )
    result["anthropic_clients"] = list(dict.fromkeys(anthropic_vars))

    return result


# ── Patch generation ──────────────────────────────────────────────

def _generate_patch(content: str, detection: Dict) -> Optional[str]:
    """
    Generate instrumented file content.

    Returns None if file should not be changed (already instrumented,
    no AI usage, or patch produces identical output).
    """
    if detection["already_instrumented"]:
        return None

    if not detection["has_openai"] and not detection["has_anthropic"]:
        return None

    lines = content.splitlines(keepends=True)
    new_lines = list(lines)

    last_import_line = 0
    has_os_import = False
    has_pradvion_import = False

    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith(("import ", "from ")):
            last_import_line = i
        if re.match(r"^import os\b", stripped):
            has_os_import = True
        if "import pradvion" in stripped:
            has_pradvion_import = True

    if not has_pradvion_import:
        import_lines: List[str] = []
        if not has_os_import:
            import_lines.append("import os\n")
        import_lines.append("import pradvion\n")
        import_lines.append("\n")

        insert_pos = last_import_line + 1
        for j, imp_line in enumerate(import_lines):
            new_lines.insert(insert_pos + j, imp_line)

    patched = "".join(new_lines)

    if not detection["already_init"]:
        init_block = (
            "\n# Pradvion: AI cost tracking\n"
            "# Get your API key at https://pradvion.com\n"
            'pradvion.init(api_key=os.environ.get("PRADVION_API_KEY", ""))\n'
            "\n"
        )
        func_match = re.search(r"\n(def |class |if __name__)", patched)
        if func_match:
            insert_at = func_match.start() + 1
            patched = patched[:insert_at] + init_block + patched[insert_at:]
        else:
            patched += init_block

    for var in detection["openai_clients"]:
        if f"pradvion.monitor({var}" not in patched:
            pattern = (
                r"("
                + re.escape(var)
                + r"\s*=\s*(?:openai\.)?(?:Async)?OpenAI\s*\([^)]*\))"
            )
            patched = re.sub(pattern, r"pradvion.monitor(\1)", patched)

    for var in detection["anthropic_clients"]:
        if f"pradvion.monitor({var}" not in patched:
            pattern = (
                r"("
                + re.escape(var)
                + r"\s*=\s*(?:anthropic\.)?(?:Async)?Anthropic\s*\([^)]*\))"
            )
            patched = re.sub(pattern, r"pradvion.monitor(\1)", patched)

    if patched == content:
        return None

    return patched


# ── Diff display ─────────────────────────────────────────────────

def _show_diff(original: str, patched: str, filepath: Path) -> None:
    """Print a colored unified diff for the given file."""
    orig_lines = original.splitlines(keepends=True)
    patch_lines = patched.splitlines(keepends=True)

    print(f"\n{'─' * 60}")
    print(f"  {filepath}")
    print(f"{'─' * 60}")

    diff = difflib.unified_diff(
        orig_lines,
        patch_lines,
        fromfile=f"a/{filepath.name}",
        tofile=f"b/{filepath.name}",
        n=2,
    )

    for line in diff:
        if line.startswith("+") and not line.startswith("+++"):
            print(f"\033[32m{line}\033[0m", end="")
        elif line.startswith("-") and not line.startswith("---"):
            print(f"\033[31m{line}\033[0m", end="")
        elif line.startswith("@@"):
            print(f"\033[36m{line}\033[0m", end="")
        else:
            print(line, end="")


# ── Undo ─────────────────────────────────────────────────────────

def _undo_instrumentation(content: str) -> Optional[str]:
    """
    Remove Pradvion instrumentation added by instrument().

    Returns None if content has no pradvion references.
    """
    if "pradvion" not in content:
        return None

    lines = content.splitlines(keepends=True)
    new_lines: List[str] = []
    skip_next_blank = False

    for line in lines:
        stripped = line.strip()

        if stripped in ("import pradvion", "import os"):
            skip_next_blank = True
            continue

        if stripped.startswith("# Pradvion:"):
            continue
        if stripped.startswith("# Get your API key"):
            continue
        if stripped.startswith("pradvion.init("):
            skip_next_blank = True
            continue

        if "pradvion.monitor(" in line:
            match = re.search(r"pradvion\.monitor\((.+)\)", line)
            if match:
                inner = match.group(1)
                line = line.replace(f"pradvion.monitor({inner})", inner)

        if skip_next_blank and stripped == "":
            skip_next_blank = False
            continue

        new_lines.append(line)

    result = "".join(new_lines)
    return None if result == content else result


# ── Main instrument() function ───────────────────────────────────

def instrument(
    target: str = ".",
    dry_run: bool = False,
    undo: bool = False,
    quiet: bool = False,
) -> Dict:
    """
    Scan *target* and add (or remove) Pradvion instrumentation.

    Args:
        target:  Path to a directory or Python file (default: ".")
        dry_run: Preview changes without writing to disk
        undo:    Remove existing Pradvion instrumentation
        quiet:   Suppress all console output

    Returns:
        {
            "files_found":   int,
            "files_changed": int,
            "files_skipped": int,
            "changes":       list[str],  # absolute file paths changed
        }
    """
    root = Path(target).resolve()

    if not root.exists():
        if not quiet:
            print(f"Error: path not found: {target}")
        return {
            "files_found": 0, "files_changed": 0,
            "files_skipped": 0, "changes": [],
        }

    files = _find_python_files(root)

    if not files:
        if not quiet:
            print("No Python files found to instrument.")
        return {
            "files_found": 0, "files_changed": 0,
            "files_skipped": 0, "changes": [],
        }

    if not quiet:
        action = "Undoing instrumentation in" if undo else "Instrumenting"
        mode = " (dry run)" if dry_run else ""
        print(f"\nPradvion Auto-Instrument{mode}")
        print(f"{action} {len(files)} Python file(s) in {root}")

    files_changed = 0
    files_skipped = 0
    changes: List[str] = []

    for filepath in files:
        try:
            original = filepath.read_text(encoding="utf-8")
        except Exception as exc:
            if not quiet:
                print(f"  Skip (read error): {filepath}: {exc}")
            files_skipped += 1
            continue

        if undo:
            patched = _undo_instrumentation(original)
        else:
            detection = _detect_ai_usage(original)

            if detection["already_instrumented"]:
                if not quiet:
                    print(f"  Already instrumented: {filepath.name}")
                files_skipped += 1
                continue

            if not detection["has_openai"] and not detection["has_anthropic"]:
                files_skipped += 1
                continue

            patched = _generate_patch(original, detection)

        if patched is None:
            files_skipped += 1
            continue

        if not quiet:
            _show_diff(original, patched, filepath)

        if not dry_run:
            filepath.write_text(patched, encoding="utf-8")

        files_changed += 1
        changes.append(str(filepath))

    if not quiet:
        print(f"\n{'─' * 60}")
        if dry_run:
            print(
                f"  Dry run complete. "
                f"{files_changed} file(s) would be changed."
            )
            print("  Run without --dry-run to apply changes.")
        elif undo:
            print(f"  Removed instrumentation from {files_changed} file(s).")
        else:
            print(f"  Instrumented {files_changed} file(s).")
            if files_changed > 0:
                print(
                    "\n  Next step: set your API key:\n"
                    "  export PRADVION_API_KEY=nx_live_...\n"
                    "\n  Get your key at https://pradvion.com"
                )
        print(f"{'─' * 60}\n")

    return {
        "files_found": len(files),
        "files_changed": files_changed,
        "files_skipped": files_skipped,
        "changes": changes,
    }


# ── CLI entry point ───────────────────────────────────────────────

def main() -> None:
    """Entry point for the ``pradvion-instrument`` command."""
    parser = argparse.ArgumentParser(
        prog="pradvion-instrument",
        description="Automatically add Pradvion cost tracking to your AI code.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pradvion-instrument              Instrument current directory
  pradvion-instrument src/         Instrument src/ directory
  pradvion-instrument app.py       Instrument single file
  pradvion-instrument --dry-run    Preview without changes
  pradvion-instrument --undo       Remove instrumentation

Privacy:
  Pradvion NEVER captures prompts or responses.
  Only token counts and metadata are tracked.
  Your AI traffic goes directly to OpenAI/Anthropic.
        """,
    )

    parser.add_argument(
        "target",
        nargs="?",
        default=".",
        help="Directory or file to instrument (default: .)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview changes without modifying files",
    )
    parser.add_argument(
        "--undo",
        action="store_true",
        help="Remove existing Pradvion instrumentation",
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress output",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="pradvion-instrument 0.5.0",
    )

    args = parser.parse_args()

    instrument(
        target=args.target,
        dry_run=args.dry_run,
        undo=args.undo,
        quiet=args.quiet,
    )

    sys.exit(0)


if __name__ == "__main__":
    main()
