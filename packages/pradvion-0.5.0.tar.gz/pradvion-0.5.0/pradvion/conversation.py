"""
Conversation tracking — group multiple AI requests
into a single conversation session.

Usage:
  with pradvion.context(
      customer_id="samsung",
      conversation_id="conv_abc123"
  ):
      # All tracked requests belong to this conversation
      client.chat.completions.create(...)

Conversation ID is just a field on the event payload.
No content stored. Only token counts and metadata.
Privacy first — same as all Pradvion tracking.
"""

import uuid


def generate_conversation_id() -> str:
    """Generate a unique conversation ID."""
    return f"conv_{uuid.uuid4().hex[:12]}"


class ConversationContext:
    """
    Helper class for managing conversation context.

    Usage:
      conv_id = pradvion.new_conversation()

      with pradvion.context(
          customer_id="samsung",
          conversation_id=conv_id
      ):
          client.chat.completions.create(...)
    """

    def __init__(self, conversation_id: str = None):
        self.conversation_id = (
            conversation_id or generate_conversation_id()
        )

    def __repr__(self):
        return f"ConversationContext(id={self.conversation_id})"
