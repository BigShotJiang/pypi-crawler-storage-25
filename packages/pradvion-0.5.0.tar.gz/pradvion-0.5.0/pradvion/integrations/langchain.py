"""
LangChain integration for Pradvion SDK.

Tracks LLM calls automatically via the LangChain callback system.
No hard dependency on langchain — uses duck-typing.

Usage:
    from pradvion.integrations.langchain import PradvionCallback

    callback = PradvionCallback()            # uses pradvion.get_client()
    llm = ChatOpenAI(callbacks=[callback])
    result = llm.invoke("Hello")
"""
import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def _detect_provider(serialized: dict) -> str:
    """Infer AI provider from LangChain serialized LLM metadata."""
    id_parts = serialized.get("id", [])
    id_str = " ".join(str(p).lower() for p in id_parts)
    kwargs = serialized.get("kwargs", {})
    model = str(
        kwargs.get("model_name") or kwargs.get("model") or ""
    ).lower()

    if "anthropic" in id_str or "claude" in model:
        return "anthropic"
    if "openai" in id_str or "gpt" in model or model.startswith("o1") or model.startswith("o3"):
        return "openai"
    if "google" in id_str or "gemini" in id_str or "gemini" in model:
        return "google"
    if "cohere" in id_str:
        return "cohere"
    return "unknown"


def _extract_model(serialized: dict) -> str:
    """Extract model name from LangChain serialized LLM metadata."""
    kwargs = serialized.get("kwargs", {})
    return str(
        kwargs.get("model_name") or kwargs.get("model") or "unknown"
    )


class PradvionCallback:
    """
    LangChain callback handler that tracks LLM calls via Pradvion.

    Captures token usage and latency from every LLM invocation.
    Uses context for customer_id / feature / environment attribution.

    Usage:
        import pradvion
        from pradvion.integrations.langchain import PradvionCallback

        pradvion.init(api_key="nx_live_...")
        callback = PradvionCallback()

        llm = ChatOpenAI(model="gpt-4o", callbacks=[callback])
        llm.invoke("Hello")
    """

    def __init__(self, pradvion_client=None) -> None:
        if pradvion_client is None:
            from pradvion import get_client
            pradvion_client = get_client()
        self._pradvion = pradvion_client
        # run_id (str) -> start timestamp
        self._start_times: Dict[str, float] = {}
        # run_id (str) -> serialized dict
        self._serialized: Dict[str, dict] = {}

    # ── LLM callbacks ────────────────────────────────────────────

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: Any,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        self._start_times[key] = time.monotonic()
        self._serialized[key] = serialized or {}

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: Any,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        start = self._start_times.pop(key, None)
        serialized = self._serialized.pop(key, {})
        latency_ms = int((time.monotonic() - start) * 1000) if start else 0

        provider = _detect_provider(serialized)
        model = _extract_model(serialized)
        input_tokens = output_tokens = 0

        try:
            llm_output = getattr(response, "llm_output", None) or {}
            # Try standard token_usage key
            token_usage = llm_output.get("token_usage", {})
            if token_usage:
                input_tokens = int(token_usage.get("prompt_tokens", 0) or 0)
                output_tokens = int(token_usage.get("completion_tokens", 0) or 0)
            # Override model if LLM reported it
            reported_model = llm_output.get("model_name")
            if reported_model:
                model = str(reported_model)
        except Exception:
            pass

        from pradvion.context import get_current_context
        ctx = get_current_context()

        try:
            self._pradvion.track(
                provider=provider,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                latency_ms=latency_ms,
                status_code=200,
                feature=ctx.get("feature"),
                team=ctx.get("team"),
                department=ctx.get("department"),
                customer_id=ctx.get("customer_id"),
                environment=ctx.get("environment"),
                conversation_id=ctx.get("conversation_id"),
            )
        except Exception as exc:
            logger.debug("Pradvion LangChain on_llm_end error: %s", exc)

    def on_llm_error(
        self,
        error: Exception,
        *,
        run_id: Any,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        start = self._start_times.pop(key, None)
        serialized = self._serialized.pop(key, {})
        latency_ms = int((time.monotonic() - start) * 1000) if start else 0

        provider = _detect_provider(serialized)
        model = _extract_model(serialized)

        from pradvion.context import get_current_context
        ctx = get_current_context()

        try:
            self._pradvion.track(
                provider=provider,
                model=model,
                input_tokens=0,
                output_tokens=0,
                latency_ms=latency_ms,
                status_code=500,
                feature=ctx.get("feature"),
                team=ctx.get("team"),
                department=ctx.get("department"),
                customer_id=ctx.get("customer_id"),
                environment=ctx.get("environment"),
                conversation_id=ctx.get("conversation_id"),
            )
        except Exception as exc:
            logger.debug("Pradvion LangChain on_llm_error error: %s", exc)

    # ── Stub callbacks (required by some LangChain versions) ─────

    def on_chain_start(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_chain_end(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_chain_error(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_tool_start(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_tool_end(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_tool_error(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_text(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_agent_action(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_agent_finish(self, *args: Any, **kwargs: Any) -> None:
        pass
