"""
OpenTelemetry integration for Pradvion SDK.

Exports AI usage spans from OpenTelemetry to Pradvion.
Extracts only token counts and timing — never prompt/response text.

Usage:
    from pradvion.integrations.otel import setup_otel
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    exporter = setup_otel()
    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(exporter))
"""
import logging
from typing import Any, Sequence

logger = logging.getLogger(__name__)

# SpanExportResult constants — mirrored here so we don't need the OTEL SDK
_EXPORT_SUCCESS = 0
_EXPORT_FAILURE = 1


class PradvionSpanExporter:
    """
    OpenTelemetry SpanExporter that forwards AI usage to Pradvion.

    Reads OpenTelemetry GenAI semantic conventions from span attributes:
        gen_ai.system                — provider name (e.g. "openai")
        gen_ai.request.model         — model name
        gen_ai.usage.input_tokens    — prompt token count
        gen_ai.usage.output_tokens   — completion token count

    Span timing (nanoseconds) is used to compute latency.
    HTTP error status is derived from span status.

    Privacy: prompt and response text are never read or forwarded.
    """

    def __init__(self, pradvion_client=None) -> None:
        if pradvion_client is None:
            from pradvion import get_client
            pradvion_client = get_client()
        self._pradvion = pradvion_client

    def export(self, spans: Sequence[Any]) -> int:
        """
        Export a batch of spans.

        Returns:
            0 (SUCCESS) always — individual span errors are logged and skipped.
        """
        from pradvion.context import get_current_context

        for span in spans:
            try:
                attrs = dict(getattr(span, "attributes", None) or {})

                if not self._is_ai_span(attrs):
                    continue

                provider = str(attrs.get("gen_ai.system", "unknown"))
                model = str(
                    attrs.get(
                        "gen_ai.request.model",
                        attrs.get("gen_ai.response.model", "unknown"),
                    )
                )

                # GenAI semantic convention v1.27+
                input_tokens = int(
                    attrs.get(
                        "gen_ai.usage.input_tokens",
                        attrs.get("gen_ai.usage.prompt_tokens", 0),
                    ) or 0
                )
                output_tokens = int(
                    attrs.get(
                        "gen_ai.usage.output_tokens",
                        attrs.get("gen_ai.usage.completion_tokens", 0),
                    ) or 0
                )

                # Latency from span timing (nanoseconds → milliseconds)
                start_time = getattr(span, "start_time", None)
                end_time = getattr(span, "end_time", None)
                if start_time is not None and end_time is not None and end_time > start_time:
                    latency_ms = int((end_time - start_time) / 1_000_000)
                else:
                    latency_ms = 0

                # Status from span status code
                status_code = 200
                status_obj = getattr(span, "status", None)
                if status_obj is not None:
                    sc_str = str(getattr(status_obj, "status_code", "")).upper()
                    if "ERROR" in sc_str:
                        status_code = 500

                ctx = get_current_context()
                self._pradvion.track(
                    provider=provider,
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    latency_ms=latency_ms,
                    status_code=status_code,
                    feature=ctx.get("feature"),
                    team=ctx.get("team"),
                    department=ctx.get("department"),
                    customer_id=ctx.get("customer_id"),
                    environment=ctx.get("environment"),
                    conversation_id=ctx.get("conversation_id"),
                )
            except Exception as exc:
                logger.debug("Pradvion OTEL export span error: %s", exc)

        return _EXPORT_SUCCESS

    @staticmethod
    def _is_ai_span(attrs: dict) -> bool:
        """Return True if span attributes look like an AI/LLM call."""
        return bool(
            attrs.get("gen_ai.system")
            or attrs.get("gen_ai.usage.input_tokens")
            or attrs.get("gen_ai.usage.prompt_tokens")
            or attrs.get("gen_ai.usage.output_tokens")
            or attrs.get("gen_ai.usage.completion_tokens")
        )

    def shutdown(self) -> None:
        """No-op — no persistent resources."""

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        return True


def setup_otel(pradvion_client=None) -> PradvionSpanExporter:
    """
    Create a PradvionSpanExporter ready for use with the OTEL SDK.

    Usage:
        exporter = setup_otel()
        provider = TracerProvider()
        provider.add_span_processor(BatchSpanProcessor(exporter))
    """
    return PradvionSpanExporter(pradvion_client=pradvion_client)
