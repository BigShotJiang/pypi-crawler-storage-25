"""
LlamaIndex integration for Pradvion SDK.

Tracks LLM calls via the LlamaIndex callback system.
No hard dependency on llama_index — uses duck-typing.

Usage:
    from pradvion.integrations.llamaindex import PradvionLlamaCallback
    from llama_index.core import Settings
    from llama_index.core.callbacks import CallbackManager

    callback = PradvionLlamaCallback()
    Settings.callback_manager = CallbackManager([callback])
"""
import logging
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class PradvionLlamaCallback:
    """
    LlamaIndex callback handler that tracks LLM calls via Pradvion.

    Captures token usage and latency from LLM events.
    Uses context for customer_id / feature / environment attribution.

    Compatible with llama_index.core.callbacks.BaseCallbackHandler interface
    (duck-typed — no hard llama_index dependency).
    """

    def __init__(self, pradvion_client=None) -> None:
        if pradvion_client is None:
            from pradvion import get_client
            pradvion_client = get_client()
        self._pradvion = pradvion_client
        # event_id -> start timestamp
        self._start_times: Dict[str, float] = {}
        # event_id -> (provider, model)
        self._event_meta: Dict[str, tuple] = {}

    # ── LlamaIndex callback interface ────────────────────────────

    def on_event_start(
        self,
        event_type: Any,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> str:
        if "LLM" in str(event_type).upper():
            self._start_times[event_id] = time.monotonic()
            serialized = (payload or {}).get("serialized", {})
            model = str(
                serialized.get("model_name")
                or serialized.get("model")
                or "unknown"
            )
            serialized_str = str(serialized).lower()
            if "openai" in serialized_str:
                provider = "openai"
            elif "anthropic" in serialized_str:
                provider = "anthropic"
            else:
                provider = "unknown"
            self._event_meta[event_id] = (provider, model)
        return event_id

    def on_event_end(
        self,
        event_type: Any,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        if "LLM" not in str(event_type).upper():
            return

        start = self._start_times.pop(event_id, None)
        provider, model = self._event_meta.pop(event_id, ("unknown", "unknown"))
        latency_ms = int((time.monotonic() - start) * 1000) if start else 0

        input_tokens = output_tokens = 0
        try:
            response = (payload or {}).get("response")
            if response is not None:
                raw = getattr(response, "raw", None)
                if isinstance(raw, dict):
                    usage = raw.get("usage", {})
                    input_tokens = int(usage.get("prompt_tokens", 0) or 0)
                    output_tokens = int(usage.get("completion_tokens", 0) or 0)
        except Exception:
            pass

        from pradvion.context import get_current_context
        ctx = get_current_context()

        try:
            self._pradvion.track(
                provider=provider,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                latency_ms=latency_ms,
                status_code=200,
                feature=ctx.get("feature"),
                team=ctx.get("team"),
                department=ctx.get("department"),
                customer_id=ctx.get("customer_id"),
                environment=ctx.get("environment"),
                conversation_id=ctx.get("conversation_id"),
            )
        except Exception as exc:
            logger.debug("Pradvion LlamaIndex track error: %s", exc)

    def start_trace(self, trace_id: Optional[str] = None) -> None:
        pass

    def end_trace(
        self,
        trace_id: Optional[str] = None,
        trace_map: Optional[dict] = None,
    ) -> None:
        pass
