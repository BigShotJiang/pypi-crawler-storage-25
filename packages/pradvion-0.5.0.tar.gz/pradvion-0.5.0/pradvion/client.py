import hashlib
import json
import logging
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from .version import SDK_VERSION
from .signals import Signal

logger = logging.getLogger(__name__)


class PradvionClient:
    """
    HTTP client for Pradvion.

    All events written to local SQLite queue first.
    Background worker drains queue to Pradvion API.
    Zero data loss — events survive crashes and downtime.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: int = 5,
        async_tracking: bool = True,
        db_path: Optional[str] = None,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url
        self.timeout = timeout
        self.async_tracking = async_tracking
        self._ingest_url = f"{base_url}/sdk/ingest"

        from .queue import LocalQueue
        from .worker import QueueWorker

        self._queue = LocalQueue(db_path=db_path)
        self._worker = QueueWorker(
            queue=self._queue,
            client=self,
            flush_interval=5,
            batch_size=20,
        )
        self._worker.start()

        pending = self._queue.pending_count()
        if pending > 0:
            logger.info(
                "Pradvion: found %d unsent events from "
                "previous session — will retry",
                pending,
            )

    def track(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        latency_ms: int,
        status_code: int = 200,
        cached_tokens: int = 0,
        reasoning_tokens: int = 0,
        feature: Optional[str] = None,
        team: Optional[str] = None,
        department: Optional[str] = None,
        customer_id: Optional[str] = None,
        environment: Optional[str] = None,
        request_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> None:
        """
        Track an AI usage event.

        Event is written to local queue instantly.
        Sent to Pradvion in background.
        Zero data loss — survives crashes and downtime.
        """
        payload: dict = {
            "request_id": request_id or str(uuid.uuid4()),
            "provider": provider,
            "model": model,
            "input_tokens": max(0, input_tokens),
            "output_tokens": max(0, output_tokens),
            "cached_tokens": max(0, cached_tokens),
            "reasoning_tokens": max(0, reasoning_tokens),
            "latency_ms": max(0, latency_ms),
            "status_code": status_code,
            "timestamp": datetime.now(timezone.utc)
                         .strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

        if feature:
            payload["feature"] = feature
        if team:
            payload["team"] = team
        if department:
            payload["department"] = department
        if environment:
            payload["environment"] = environment
        if customer_id:
            payload["customer_id_hash"] = hashlib.sha256(
                customer_id.encode("utf-8")
            ).hexdigest()
        if conversation_id:
            payload["conversation_id"] = conversation_id

        self._queue.push(payload)

    def signal(
        self,
        customer_id: str,
        event: str,
        quantity: int = 1,
        value: Optional[float] = None,
        project: Optional[str] = None,
        feature: Optional[str] = None,
        team: Optional[str] = None,
        environment: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Track a business event beyond AI token costs.

        Examples:
            client.signal("samsung", "email_sent", quantity=100)
            client.signal("samsung", "meeting_booked", value=150.00)
            client.signal(
                "samsung",
                "report_generated",
                quantity=1,
                value=50.00,
                metadata={"report_type": "monthly"}
            )
        """
        sig = Signal(
            customer_id=customer_id,
            event=event,
            quantity=quantity,
            value=value,
            project=project,
            feature=feature,
            team=team,
            environment=environment,
            metadata=metadata,
        )
        self._queue.push(sig.to_payload())

    def track_batch(self, events: list) -> None:
        """
        Track multiple AI usage events in one call.

        Each element of *events* is a dict of kwargs passed to track().
        Invalid entries are skipped with a debug log.

        Example:
            client.track_batch([
                {"provider": "openai", "model": "gpt-4o",
                 "input_tokens": 100, "output_tokens": 50, "latency_ms": 200},
                {"provider": "anthropic", "model": "claude-3-5-sonnet-20241022",
                 "input_tokens": 200, "output_tokens": 100, "latency_ms": 300},
            ])
        """
        for event in events:
            try:
                self.track(**event)
            except Exception as exc:
                logger.debug("Pradvion track_batch entry error: %s", exc)

    def signal_batch(self, signals: list) -> None:
        """
        Track multiple business signal events in one call.

        Each element is a dict of kwargs passed to signal().

        Example:
            client.signal_batch([
                {"customer_id": "acme", "event": "email_sent", "quantity": 10},
                {"customer_id": "acme", "event": "meeting_booked", "value": 150.0},
            ])
        """
        for sig in signals:
            try:
                self.signal(**sig)
            except Exception as exc:
                logger.debug("Pradvion signal_batch entry error: %s", exc)

    def track_error(
        self,
        provider: str,
        model: str,
        error: Exception,
        latency_ms: int = 0,
        feature: Optional[str] = None,
        team: Optional[str] = None,
        department: Optional[str] = None,
        customer_id: Optional[str] = None,
        environment: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> None:
        """
        Track a failed AI request.

        Convenience wrapper around track() with status_code=500
        and zero token counts.

        Example:
            try:
                response = openai.chat.completions.create(...)
            except Exception as e:
                client.track_error("openai", "gpt-4o", e,
                                   customer_id="samsung-001")
                raise
        """
        error_type = type(error).__name__
        self.track(
            provider=provider,
            model=model,
            input_tokens=0,
            output_tokens=0,
            latency_ms=latency_ms,
            status_code=500,
            feature=feature,
            team=team,
            department=department,
            customer_id=customer_id,
            environment=environment,
            conversation_id=conversation_id,
            request_id=f"err_{error_type}_{uuid.uuid4().hex[:8]}",
        )

    def flush(self, timeout: float = 10.0) -> None:
        """
        Flush all pending events to Pradvion API.
        Call before process exit for guaranteed delivery.

        Usage:
            import atexit
            atexit.register(pradvion.flush)
        """
        self._worker.flush_once()

    def shutdown(self) -> None:
        """
        Stop background worker gracefully.
        Flushes remaining events before stopping.
        """
        self._worker.stop()

    def _send(self, payload: dict) -> None:
        """
        Send single event to Pradvion API.
        Raises on failure (caller handles retry).
        """
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self._ingest_url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                "X-Pradvion-SDK-Version": SDK_VERSION,
                "X-Pradvion-SDK-Language": "python",
            },
            method="POST",
        )
        with urllib.request.urlopen(
            req, timeout=self.timeout
        ) as resp:
            if resp.status not in (200, 201, 202):
                raise RuntimeError(
                    f"Pradvion returned HTTP {resp.status}"
                )
