import logging
import threading
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pradvion.queue import LocalQueue
    from pradvion.client import PradvionClient

logger = logging.getLogger(__name__)


class QueueWorker:
    """
    Background worker that drains the local queue.
    Runs in a daemon thread.
    Retries failed events on next flush.
    """

    def __init__(
        self,
        queue: "LocalQueue",
        client: "PradvionClient",
        flush_interval: int = 5,
        batch_size: int = 20,
    ) -> None:
        self._queue = queue
        self._client = client
        self._flush_interval = flush_interval
        self._batch_size = batch_size
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Start background worker thread."""
        self._thread = threading.Thread(
            target=self._run,
            daemon=True,
            name="pradvion-worker",
        )
        self._thread.start()
        logger.debug("Pradvion queue worker started")

    def stop(self) -> None:
        """Stop worker thread."""
        self._stop.set()

    def flush_once(self) -> int:
        """
        Flush pending events. Returns count sent.
        Called by background thread every N seconds.
        Also called on shutdown.
        """
        events = self._queue.pop_pending(self._batch_size)
        sent = 0

        for event_id, payload in events:
            try:
                self._client._send(payload)
                self._queue.mark_sent(event_id)
                sent += 1
            except Exception as exc:
                self._queue.mark_failed(event_id)
                logger.debug(
                    "Pradvion: failed to send event %d: %s",
                    event_id,
                    exc,
                )

        return sent

    def _run(self) -> None:
        """Main worker loop."""
        while not self._stop.is_set():
            try:
                pending = self._queue.pending_count()
                if pending > 0:
                    sent = self.flush_once()
                    logger.debug(
                        "Pradvion: flushed %d/%d events",
                        sent,
                        pending,
                    )
            except Exception as exc:
                logger.debug("Pradvion worker error: %s", exc)

            self._stop.wait(timeout=self._flush_interval)

        # Final flush on shutdown
        try:
            self.flush_once()
        except Exception:
            pass
