"""
Budget enforcement for Pradvion SDK.
Thread-safe monthly spending limits with configurable actions.
"""
import logging
import threading
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

_budget_tracker = None
_budget_lock = threading.Lock()


class BudgetExceededError(Exception):
    """Raised when a budget limit is exceeded and action='raise'."""

    def __init__(self, customer_id: str, spent: float, limit: float) -> None:
        self.customer_id = customer_id
        self.spent = spent
        self.limit = limit
        super().__init__(
            f"Budget exceeded for {customer_id!r}: "
            f"spent ${spent:.6f} of ${limit:.6f} monthly limit"
        )


class BudgetTracker:
    """
    Thread-safe in-memory monthly budget enforcement.

    Tracks spending per customer and enforces limits.
    Resets automatically on month boundary.

    Usage:
        from pradvion.budget import get_budget_tracker

        tracker = get_budget_tracker()
        tracker.set_limit("samsung-001", monthly_usd=100.0, action="raise")
        tracker.record_spend("samsung-001", 0.05)
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # customer_id -> {"limit": float, "action": str}
        self._limits: dict = {}
        # customer_id -> {"spent": float, "month": str}
        self._spending: dict = {}

    @staticmethod
    def _current_month() -> str:
        now = datetime.now(timezone.utc)
        return f"{now.year}-{now.month:02d}"

    def _get_spent_locked(self, customer_id: str) -> float:
        """Get current-month spending; resets if month changed. Must hold lock."""
        current = self._current_month()
        record = self._spending.get(customer_id, {})
        if record.get("month") != current:
            self._spending[customer_id] = {"spent": 0.0, "month": current}
            return 0.0
        return record.get("spent", 0.0)

    def set_limit(
        self,
        customer_id: str,
        monthly_usd: float,
        action: str = "warn",
    ) -> None:
        """
        Set a monthly budget limit for a customer.

        Args:
            customer_id:  Customer identifier
            monthly_usd:  Monthly budget in USD
            action:       "raise"  — raise BudgetExceededError on breach
                          "warn"   — log a warning on breach (default)
                          "ignore" — track only, no alert
        """
        if action not in ("raise", "warn", "ignore"):
            raise ValueError(
                f"action must be 'raise', 'warn', or 'ignore', got {action!r}"
            )
        with self._lock:
            self._limits[customer_id] = {
                "limit": float(monthly_usd),
                "action": action,
            }

    def record_spend(self, customer_id: str, amount_usd: float) -> None:
        """
        Record spending and enforce budget if a limit is set.

        Args:
            customer_id: Customer identifier
            amount_usd:  Amount spent in USD

        Raises:
            BudgetExceededError: If limit exceeded and action='raise'
        """
        with self._lock:
            current = self._current_month()
            record = self._spending.get(customer_id, {})
            if record.get("month") != current:
                record = {"spent": 0.0, "month": current}
            record["spent"] = record.get("spent", 0.0) + float(amount_usd)
            self._spending[customer_id] = record

            limit_cfg = self._limits.get(customer_id)
            if limit_cfg is None:
                return

            limit = limit_cfg["limit"]
            action = limit_cfg["action"]
            spent = record["spent"]

            if spent > limit:
                if action == "raise":
                    raise BudgetExceededError(customer_id, spent, limit)
                elif action == "warn":
                    logger.warning(
                        "Pradvion: budget exceeded for %r — "
                        "spent $%.6f of $%.6f monthly limit",
                        customer_id, spent, limit,
                    )
                # "ignore" — do nothing

    def get_spent(self, customer_id: str) -> float:
        """Return current-month spending for a customer."""
        with self._lock:
            return self._get_spent_locked(customer_id)

    def get_limit(self, customer_id: str) -> Optional[float]:
        """Return monthly limit for a customer, or None if not set."""
        with self._lock:
            cfg = self._limits.get(customer_id)
            return cfg["limit"] if cfg else None

    def get_action(self, customer_id: str) -> Optional[str]:
        """Return action for a customer, or None if not set."""
        with self._lock:
            cfg = self._limits.get(customer_id)
            return cfg["action"] if cfg else None

    def remaining(self, customer_id: str) -> Optional[float]:
        """Return remaining budget for a customer; None if no limit set."""
        with self._lock:
            cfg = self._limits.get(customer_id)
            if cfg is None:
                return None
            spent = self._get_spent_locked(customer_id)
            return max(0.0, cfg["limit"] - spent)

    def reset(self, customer_id: str) -> None:
        """Reset spending for a customer (useful in tests)."""
        with self._lock:
            self._spending.pop(customer_id, None)

    def remove_limit(self, customer_id: str) -> None:
        """Remove the budget limit for a customer."""
        with self._lock:
            self._limits.pop(customer_id, None)


def get_budget_tracker() -> BudgetTracker:
    """Return the global singleton BudgetTracker."""
    global _budget_tracker
    if _budget_tracker is None:
        with _budget_lock:
            if _budget_tracker is None:
                _budget_tracker = BudgetTracker()
    return _budget_tracker
