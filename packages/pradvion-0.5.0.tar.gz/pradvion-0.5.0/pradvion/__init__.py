"""
Pradvion Python SDK v0.4.0
Track AI API costs per client, project, and feature.
Generate client invoices. Protect your margins.
https://pradvion.com
"""

import atexit
import logging

from .version import __version__, SDK_VERSION
from .client import PradvionClient
from .context import context, set_context, clear_context
from .wrapper import wrap, monitor as _wrapper_monitor
from .signals import Signal
from .conversation import generate_conversation_id, ConversationContext
from .budget import BudgetTracker, BudgetExceededError, get_budget_tracker
from .forecast import ForecastResult, forecast_monthly, forecast_from_requests
from .compare import ComparisonResult, ModelCost, compare_cost, add_custom_pricing

logger = logging.getLogger(__name__)

_client: PradvionClient = None


def init(
    api_key: str,
    base_url: str = "https://pradvion-backend-production.up.railway.app",
    timeout: int = 5,
    async_tracking: bool = True,
    auto_flush: bool = True,
) -> None:
    """
    Initialize the Pradvion SDK.
    Must be called once before any tracking.

    Args:
        api_key:        Your Pradvion API key (nx_live_...)
        base_url:       Pradvion API URL (default: production)
        timeout:        HTTP request timeout in seconds
        async_tracking: Use background worker (default: True)
        auto_flush:     Register atexit handler (default: True)

    Example:
        import pradvion
        pradvion.init(api_key="nx_live_...")
    """
    global _client
    _client = PradvionClient(
        api_key=api_key,
        base_url=base_url.rstrip("/"),
        timeout=timeout,
        async_tracking=async_tracking,
    )

    if auto_flush:
        atexit.register(_auto_flush)

    logger.debug(
        "Pradvion SDK v%s initialized (base_url=%s)",
        __version__, base_url,
    )


def _auto_flush():
    """Called automatically on process exit."""
    if _client is not None:
        try:
            _client.flush(timeout=5.0)
        except Exception:
            pass


def get_client() -> PradvionClient:
    """
    Get the initialized Pradvion client.
    Raises RuntimeError if init() not called.
    """
    if _client is None:
        raise RuntimeError(
            "Pradvion not initialized. "
            "Call pradvion.init(api_key='nx_live_...') first."
        )
    return _client


def monitor(client, pradvion_client=None):
    """
    One-line integration. Wraps any AI client.

    Usage:
        import pradvion
        from openai import OpenAI

        pradvion.init(api_key="nx_live_...")
        openai = pradvion.monitor(OpenAI())
        response = openai.chat.completions.create(...)
    """
    return _wrapper_monitor(client, pradvion_client)


def signal(
    customer_id: str,
    event: str,
    quantity: int = 1,
    value: float = None,
    project: str = None,
    feature: str = None,
    team: str = None,
    environment: str = None,
    metadata: dict = None,
) -> None:
    """
    Track a business event beyond AI token costs.

    Examples:
        pradvion.signal("samsung", "email_sent", quantity=100)
        pradvion.signal("samsung", "meeting_booked", value=150.00)
    """
    get_client().signal(
        customer_id=customer_id,
        event=event,
        quantity=quantity,
        value=value,
        project=project,
        feature=feature,
        team=team,
        environment=environment,
        metadata=metadata,
    )


def track_error(
    provider: str,
    model: str,
    error: Exception,
    latency_ms: int = 0,
    feature: str = None,
    team: str = None,
    department: str = None,
    customer_id: str = None,
    environment: str = None,
    conversation_id: str = None,
) -> None:
    """
    Track a failed AI request.

    Example:
        try:
            response = openai.chat.completions.create(...)
        except Exception as e:
            pradvion.track_error("openai", "gpt-4o", e,
                                 customer_id="samsung-001")
            raise
    """
    get_client().track_error(
        provider=provider,
        model=model,
        error=error,
        latency_ms=latency_ms,
        feature=feature,
        team=team,
        department=department,
        customer_id=customer_id,
        environment=environment,
        conversation_id=conversation_id,
    )


def track_batch(events: list) -> None:
    """
    Track multiple AI usage events in one call.

    Each element is a dict of kwargs for track().

    Example:
        pradvion.track_batch([
            {"provider": "openai", "model": "gpt-4o",
             "input_tokens": 100, "output_tokens": 50, "latency_ms": 200},
        ])
    """
    get_client().track_batch(events)


def signal_batch(signals: list) -> None:
    """
    Track multiple business signal events in one call.

    Each element is a dict of kwargs for signal().

    Example:
        pradvion.signal_batch([
            {"customer_id": "acme", "event": "email_sent", "quantity": 10},
        ])
    """
    get_client().signal_batch(signals)


def new_conversation() -> str:
    """
    Generate a new unique conversation ID.

    Usage:
        conv_id = pradvion.new_conversation()
        with pradvion.context(customer_id="samsung", conversation_id=conv_id):
            client.chat.completions.create(...)
    """
    return generate_conversation_id()


def flush(timeout: float = 10.0) -> None:
    """Flush all pending events to Pradvion API."""
    if _client is not None:
        _client.flush(timeout=timeout)


def shutdown() -> None:
    """Gracefully shut down — flush pending events and stop worker."""
    if _client is not None:
        _client.shutdown()


__all__ = [
    # Core
    "init",
    "get_client",
    "__version__",

    # Tracking
    "monitor",
    "wrap",
    "signal",
    "track_error",
    "track_batch",
    "signal_batch",

    # Context
    "context",
    "set_context",
    "clear_context",

    # Conversation
    "new_conversation",

    # Lifecycle
    "flush",
    "shutdown",

    # Budget
    "get_budget_tracker",
    "BudgetTracker",
    "BudgetExceededError",

    # Forecast
    "forecast_monthly",
    "forecast_from_requests",
    "ForecastResult",

    # Compare
    "compare_cost",
    "add_custom_pricing",
    "ComparisonResult",
    "ModelCost",

    # Classes
    "PradvionClient",
    "Signal",
    "ConversationContext",
]
