"""Tests for Pradvion Python SDK."""

import hashlib
import threading
import time
import unittest
from unittest.mock import MagicMock, patch, call


class TestContext(unittest.TestCase):

    def setUp(self):
        from pradvion.context import clear_context
        clear_context()

    def tearDown(self):
        from pradvion.context import clear_context
        clear_context()

    def test_set_and_get(self):
        from pradvion.context import set_context, get_current_context
        set_context(feature="test", team="eng")
        ctx = get_current_context()
        self.assertEqual(ctx["feature"], "test")
        self.assertEqual(ctx["team"], "eng")

    def test_clear(self):
        from pradvion.context import set_context, clear_context, get_current_context
        set_context(feature="test")
        clear_context()
        self.assertEqual(get_current_context(), {})

    def test_context_manager_restores(self):
        from pradvion.context import context, set_context, get_current_context
        set_context(customer_id="outer")
        with context(feature="inner"):
            ctx = get_current_context()
            self.assertEqual(ctx["feature"], "inner")
            self.assertEqual(ctx["customer_id"], "outer")
        ctx = get_current_context()
        self.assertNotIn("feature", ctx)
        self.assertEqual(ctx["customer_id"], "outer")

    def test_nested_context_managers(self):
        from pradvion.context import context, get_current_context
        with context(feature="outer"):
            with context(feature="inner", team="eng"):
                ctx = get_current_context()
                self.assertEqual(ctx["feature"], "inner")
                self.assertEqual(ctx["team"], "eng")
            ctx = get_current_context()
            self.assertEqual(ctx["feature"], "outer")
            self.assertNotIn("team", ctx)

    def test_thread_isolation(self):
        from pradvion.context import set_context, get_current_context, clear_context
        results = {}

        def worker(name, customer_id):
            set_context(customer_id=customer_id)
            time.sleep(0.05)
            results[name] = get_current_context().get("customer_id")
            clear_context()

        t1 = threading.Thread(target=worker, args=("t1", "samsung"))
        t2 = threading.Thread(target=worker, args=("t2", "tesla"))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        self.assertEqual(results["t1"], "samsung")
        self.assertEqual(results["t2"], "tesla")

    def test_none_not_stored(self):
        from pradvion.context import set_context, get_current_context
        set_context(feature="test", team=None)
        ctx = get_current_context()
        self.assertIn("feature", ctx)
        self.assertNotIn("team", ctx)

    def test_environment_field(self):
        from pradvion.context import context, get_current_context
        with context(environment="production"):
            ctx = get_current_context()
            self.assertEqual(ctx["environment"], "production")


class TestPradvionClient(unittest.TestCase):

    def setUp(self):
        import tempfile
        self.tmp_db = tempfile.mktemp(suffix=".db")

    def tearDown(self):
        import os
        if os.path.exists(self.tmp_db):
            os.remove(self.tmp_db)

    def _make_client(self):
        from pradvion.client import PradvionClient
        return PradvionClient(
            api_key="nx_live_test",
            base_url="https://test.example.com",
            db_path=self.tmp_db,
        )

    def test_track_writes_to_queue(self):
        client = self._make_client()
        with patch.object(client._queue, "push") as mock_push:
            client.track(
                provider="openai",
                model="gpt-4o",
                input_tokens=100,
                output_tokens=50,
                latency_ms=250,
            )
            mock_push.assert_called_once()
            payload = mock_push.call_args[0][0]
            self.assertEqual(payload["provider"], "openai")
            self.assertEqual(payload["model"], "gpt-4o")
            self.assertEqual(payload["input_tokens"], 100)
            self.assertEqual(payload["output_tokens"], 50)

    def test_customer_id_hashed(self):
        client = self._make_client()
        with patch.object(client._queue, "push") as mock_push:
            client.track(
                provider="openai",
                model="gpt-4o",
                input_tokens=100,
                output_tokens=50,
                latency_ms=250,
                customer_id="samsung-001",
            )
            payload = mock_push.call_args[0][0]
            expected = hashlib.sha256(
                "samsung-001".encode()
            ).hexdigest()
            self.assertEqual(payload["customer_id_hash"], expected)
            self.assertNotIn("customer_id", payload)

    def test_environment_in_payload(self):
        client = self._make_client()
        with patch.object(client._queue, "push") as mock_push:
            client.track(
                provider="openai",
                model="gpt-4o",
                input_tokens=100,
                output_tokens=50,
                latency_ms=250,
                environment="production",
            )
            payload = mock_push.call_args[0][0]
            self.assertEqual(payload["environment"], "production")

    def test_retry_on_failure(self):
        # Worker retries by calling flush_once again on next interval.
        # Test that flush_once marks failed then succeeds on re-flush.
        client = self._make_client()
        client.track(
            provider="openai",
            model="gpt-4o",
            input_tokens=100,
            output_tokens=50,
            latency_ms=250,
        )
        call_count = 0

        def fail_twice(payload):
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise Exception("Network error")

        with patch.object(client, "_send", side_effect=fail_twice):
            client._worker.flush_once()  # attempt 1 — fails, mark_failed
            client._worker.flush_once()  # attempt 2 — fails, mark_failed
            client._worker.flush_once()  # attempt 3 — succeeds, mark_sent

        self.assertEqual(call_count, 3)
        self.assertEqual(client._queue.pending_count(), 0)

    def test_silent_failure_after_retries(self):
        client = self._make_client()
        client.track(
            provider="openai",
            model="gpt-4o",
            input_tokens=100,
            output_tokens=50,
            latency_ms=250,
        )
        with patch.object(
            client, "_send", side_effect=Exception("always fails")
        ):
            # Should not raise — worker swallows errors
            client._worker.flush_once()

    def test_sdk_version_header(self):
        client = self._make_client()
        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = MagicMock()
            mock_resp.__enter__ = lambda s: s
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_resp.status = 200
            mock_urlopen.return_value = mock_resp

            # Call _send directly to inspect headers
            client._send({"request_id": "test", "model": "gpt-4o"})

            req = mock_urlopen.call_args[0][0]
            headers = req.headers
            self.assertIn(
                "x-pradvion-sdk-version",
                {k.lower(): v for k, v in headers.items()}
            )


class TestInit(unittest.TestCase):

    def test_init_and_get_client(self):
        import pradvion
        pradvion.init(api_key="nx_live_test_key")
        client = pradvion.get_client()
        self.assertIsNotNone(client)
        self.assertEqual(client.api_key, "nx_live_test_key")

    def test_get_client_without_init_raises(self):
        import pradvion
        pradvion._client = None
        with self.assertRaises(RuntimeError) as cm:
            pradvion.get_client()
        self.assertIn("not initialized", str(cm.exception))


class TestWrap(unittest.TestCase):

    def test_wrap_unknown_returns_original(self):
        import pradvion
        pradvion.init(api_key="nx_live_test")
        original = object()
        result = pradvion.wrap(original)
        self.assertIs(result, original)


class TestLocalQueue(unittest.TestCase):

    def setUp(self):
        import tempfile
        self.tmp = tempfile.mktemp(suffix=".db")
        from pradvion.queue import LocalQueue
        self.queue = LocalQueue(db_path=self.tmp)

    def tearDown(self):
        import os
        if os.path.exists(self.tmp):
            os.remove(self.tmp)

    def test_push_and_pop(self):
        self.queue.push({"test": "event1"})
        self.queue.push({"test": "event2"})
        events = self.queue.pop_pending()
        self.assertEqual(len(events), 2)

    def test_mark_sent(self):
        event_id = self.queue.push({"test": "event"})
        self.queue.mark_sent(event_id)
        events = self.queue.pop_pending()
        self.assertEqual(len(events), 0)

    def test_pending_count(self):
        self.queue.push({"test": "e1"})
        self.queue.push({"test": "e2"})
        self.assertEqual(self.queue.pending_count(), 2)

    def test_survives_restart(self):
        # Push event
        self.queue.push({"test": "persistent"})

        # Create new queue instance with same db
        from pradvion.queue import LocalQueue
        queue2 = LocalQueue(db_path=self.tmp)

        # Event still there
        events = queue2.pop_pending()
        self.assertEqual(len(events), 1)
        self.assertEqual(
            events[0][1]["test"], "persistent"
        )

    def test_failed_stays_pending(self):
        event_id = self.queue.push({"test": "retry"})
        self.queue.mark_failed(event_id)
        # Still pending — will retry
        events = self.queue.pop_pending()
        self.assertEqual(len(events), 1)


class TestMonitor(unittest.TestCase):

    def setUp(self):
        import pradvion
        pradvion.init(api_key="nx_live_test")

    def test_monitor_unknown_client_returns_original(self):
        """monitor() with unrecognized client returns it unchanged."""
        import pradvion
        original = object()
        result = pradvion.monitor(original)
        self.assertIs(result, original)

    def test_monitor_without_init_returns_original(self):
        """monitor() before init() returns original client with warning."""
        import pradvion
        saved = pradvion._client
        pradvion._client = None
        try:
            original = object()
            result = pradvion.monitor(original)
            self.assertIs(result, original)
        finally:
            pradvion._client = saved

    def test_monitor_delegates_to_wrap(self):
        """monitor() with initialized SDK delegates to wrap()."""
        import pradvion
        pradvion.init(api_key="nx_live_test")
        original = object()
        mock_wrapped = MagicMock()
        with patch("pradvion.wrapper.wrap", return_value=mock_wrapped) as mock_wrap:
            result = pradvion.monitor(original)
            mock_wrap.assert_called_once()
        self.assertIs(result, mock_wrapped)


class TestSignals(unittest.TestCase):

    def setUp(self):
        import tempfile
        self.tmp_db = tempfile.mktemp(suffix=".db")
        from pradvion.client import PradvionClient
        self.client = PradvionClient(
            api_key="nx_live_test",
            base_url="https://test.example.com",
            db_path=self.tmp_db,
        )

    def tearDown(self):
        import os
        if os.path.exists(self.tmp_db):
            os.remove(self.tmp_db)

    def test_signal_basic(self):
        """signal() queues event with correct fields."""
        with patch.object(self.client._queue, "push") as mock_push:
            self.client.signal("samsung", "email_sent", quantity=5)
            mock_push.assert_called_once()
            payload = mock_push.call_args[0][0]
            self.assertEqual(payload["event"], "email_sent")
            self.assertEqual(payload["quantity"], 5)

    def test_signal_customer_id_hashed(self):
        """customer_id is SHA-256 hashed, never stored raw."""
        with patch.object(self.client._queue, "push") as mock_push:
            self.client.signal("test_customer", "event")
            payload = mock_push.call_args[0][0]
            expected = hashlib.sha256(
                "test_customer".encode()
            ).hexdigest()
            self.assertEqual(payload["customer_id_hash"], expected)
            self.assertNotIn("customer_id", payload)

    def test_signal_with_value(self):
        """signal() stores monetary value in payload."""
        with patch.object(self.client._queue, "push") as mock_push:
            self.client.signal("samsung", "meeting_booked", value=150.00)
            payload = mock_push.call_args[0][0]
            self.assertEqual(payload["value"], 150.00)

    def test_signal_with_metadata(self):
        """signal() stores metadata dict in payload."""
        with patch.object(self.client._queue, "push") as mock_push:
            self.client.signal(
                "samsung", "report_generated",
                metadata={"type": "monthly"}
            )
            payload = mock_push.call_args[0][0]
            self.assertEqual(payload["metadata"], {"type": "monthly"})

    def test_signal_empty_event_raises(self):
        """Signal raises ValueError for empty event name."""
        from pradvion.signals import Signal
        with self.assertRaises(ValueError):
            Signal("samsung", "")

    def test_signal_negative_quantity_raises(self):
        """Signal raises ValueError for negative quantity."""
        from pradvion.signals import Signal
        with self.assertRaises(ValueError):
            Signal("samsung", "test", quantity=-1)

    def test_signal_negative_value_raises(self):
        """Signal raises ValueError for negative value."""
        from pradvion.signals import Signal
        with self.assertRaises(ValueError):
            Signal("samsung", "test", value=-1.0)

    def test_signal_type_in_payload(self):
        """Signal payload has type='signal' discriminator field."""
        from pradvion.signals import Signal
        sig = Signal("samsung", "test_event")
        payload = sig.to_payload()
        self.assertEqual(payload["type"], "signal")

    def test_signal_has_unique_id(self):
        """Each signal gets a unique signal_id."""
        from pradvion.signals import Signal
        sig1 = Signal("samsung", "event")
        sig2 = Signal("samsung", "event")
        self.assertNotEqual(sig1.signal_id, sig2.signal_id)

    def test_signal_has_timestamp(self):
        """Signal payload has a UTC ISO-8601 timestamp."""
        from pradvion.signals import Signal
        sig = Signal("samsung", "event")
        payload = sig.to_payload()
        self.assertIsNotNone(payload["timestamp"])
        self.assertRegex(
            payload["timestamp"],
            r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z"
        )


class TestConversationTracking(unittest.TestCase):

    def setUp(self):
        import tempfile
        self.tmp_db = tempfile.mktemp(suffix=".db")

    def tearDown(self):
        import os
        if os.path.exists(self.tmp_db):
            os.remove(self.tmp_db)

    def _make_client(self):
        from pradvion.client import PradvionClient
        return PradvionClient(
            api_key="nx_live_test",
            base_url="https://test.example.com",
            db_path=self.tmp_db,
        )

    def test_new_conversation_generates_unique_ids(self):
        """generate_conversation_id() returns unique conv_ prefixed IDs."""
        from pradvion.conversation import generate_conversation_id
        id1 = generate_conversation_id()
        id2 = generate_conversation_id()
        self.assertNotEqual(id1, id2)
        self.assertTrue(id1.startswith("conv_"))
        self.assertTrue(id2.startswith("conv_"))

    def test_conversation_id_in_payload(self):
        """conversation_id passed to track() appears in payload."""
        client = self._make_client()
        with patch.object(client._queue, "push") as mock_push:
            client.track(
                provider="openai",
                model="gpt-4o",
                input_tokens=100,
                output_tokens=50,
                latency_ms=250,
                conversation_id="conv_test_123",
            )
            payload = mock_push.call_args[0][0]
            self.assertEqual(payload["conversation_id"], "conv_test_123")

    def test_no_conversation_id_not_in_payload(self):
        """conversation_id omitted from payload when not provided."""
        client = self._make_client()
        with patch.object(client._queue, "push") as mock_push:
            client.track(
                provider="openai",
                model="gpt-4o",
                input_tokens=100,
                output_tokens=50,
                latency_ms=250,
            )
            payload = mock_push.call_args[0][0]
            self.assertNotIn("conversation_id", payload)


class TestOptionalContext(unittest.TestCase):

    def setUp(self):
        import tempfile
        from pradvion.context import clear_context
        self.tmp_db = tempfile.mktemp(suffix=".db")
        clear_context()

    def tearDown(self):
        import os
        from pradvion.context import clear_context
        clear_context()
        if os.path.exists(self.tmp_db):
            os.remove(self.tmp_db)

    def _make_client(self):
        from pradvion.client import PradvionClient
        return PradvionClient(
            api_key="nx_live_test",
            base_url="https://test.example.com",
            db_path=self.tmp_db,
        )

    def test_track_with_no_context(self):
        """track() works with zero context set — no exceptions raised."""
        client = self._make_client()
        with patch.object(client._queue, "push") as mock_push:
            client.track(
                provider="openai",
                model="gpt-4o",
                input_tokens=100,
                output_tokens=50,
                latency_ms=250,
            )
            mock_push.assert_called_once()

    def test_track_with_partial_context(self):
        """track() works with only customer_id; other fields absent."""
        client = self._make_client()
        with patch.object(client._queue, "push") as mock_push:
            client.track(
                provider="openai",
                model="gpt-4o",
                input_tokens=100,
                output_tokens=50,
                latency_ms=250,
                customer_id="samsung-001",
            )
            payload = mock_push.call_args[0][0]
            self.assertIn("customer_id_hash", payload)
            self.assertNotIn("feature", payload)
            self.assertNotIn("project", payload)
            self.assertNotIn("team", payload)


class TestFlushAndShutdown(unittest.TestCase):

    def setUp(self):
        import tempfile
        self.tmp_db = tempfile.mktemp(suffix=".db")

    def tearDown(self):
        import os
        if os.path.exists(self.tmp_db):
            os.remove(self.tmp_db)

    def _make_client(self):
        from pradvion.client import PradvionClient
        return PradvionClient(
            api_key="nx_live_test",
            base_url="https://test.example.com",
            db_path=self.tmp_db,
        )

    def test_flush_sends_pending_events(self):
        """flush() drains the queue — pending count reaches zero."""
        client = self._make_client()
        client.track(
            provider="openai",
            model="gpt-4o",
            input_tokens=100,
            output_tokens=50,
            latency_ms=250,
        )
        with patch.object(client, "_send"):
            client.flush()
        self.assertEqual(client._queue.pending_count(), 0)

    def test_shutdown_stops_worker(self):
        """shutdown() sets the worker stop event."""
        client = self._make_client()
        client.shutdown()
        self.assertTrue(client._worker._stop.is_set())


if __name__ == "__main__":
    unittest.main(verbosity=2)
