"""
Tests for pradvion.compare — compare_cost() and add_custom_pricing().
"""
import unittest

from pradvion.compare import (
    compare_cost,
    add_custom_pricing,
    ComparisonResult,
    ModelCost,
    _PRICING,
)


class TestCompareCost(unittest.TestCase):

    def test_returns_comparison_result(self):
        result = compare_cost(input_tokens=1000, output_tokens=500)
        self.assertIsInstance(result, ComparisonResult)

    def test_cheapest_is_cheapest(self):
        result = compare_cost(input_tokens=1000, output_tokens=500)
        cheapest_cost = result.cheapest.total_cost
        for m in result.all_models:
            self.assertLessEqual(cheapest_cost, m.total_cost)

    def test_most_expensive_is_most_expensive(self):
        result = compare_cost(input_tokens=1000, output_tokens=500)
        expensive_cost = result.most_expensive.total_cost
        for m in result.all_models:
            self.assertGreaterEqual(expensive_cost, m.total_cost)

    def test_savings_equals_spread(self):
        result = compare_cost(input_tokens=1000, output_tokens=500)
        expected = result.most_expensive.total_cost - result.cheapest.total_cost
        self.assertAlmostEqual(
            result.savings_vs_most_expensive, expected, places=7
        )

    def test_specific_models_subset(self):
        result = compare_cost(
            input_tokens=1_000_000,
            output_tokens=1_000_000,
            models=["gpt-4o", "gpt-4o-mini"],
        )
        model_names = [m.model for m in result.all_models]
        self.assertIn("gpt-4o", model_names)
        self.assertIn("gpt-4o-mini", model_names)
        self.assertEqual(len(result.all_models), 2)

    def test_gpt4o_more_expensive_than_mini(self):
        result = compare_cost(
            input_tokens=1_000_000,
            output_tokens=1_000_000,
            models=["gpt-4o", "gpt-4o-mini"],
        )
        costs = {m.model: m.total_cost for m in result.all_models}
        self.assertGreater(costs["gpt-4o"], costs["gpt-4o-mini"])

    def test_token_counts_stored(self):
        result = compare_cost(input_tokens=100, output_tokens=200)
        self.assertEqual(result.input_tokens, 100)
        self.assertEqual(result.output_tokens, 200)

    def test_model_cost_fields(self):
        result = compare_cost(
            input_tokens=1_000_000,
            output_tokens=1_000_000,
            models=["gpt-4o"],
        )
        m = result.all_models[0]
        self.assertIsInstance(m, ModelCost)
        self.assertEqual(m.model, "gpt-4o")
        self.assertGreater(m.input_cost, 0)
        self.assertGreater(m.output_cost, 0)
        self.assertAlmostEqual(
            m.total_cost, m.input_cost + m.output_cost, places=7
        )

    def test_unknown_model_raises(self):
        with self.assertRaises(ValueError):
            compare_cost(1000, 500, models=["does-not-exist-model-xyz"])

    def test_zero_tokens_all_zero_cost(self):
        result = compare_cost(input_tokens=0, output_tokens=0)
        for m in result.all_models:
            self.assertEqual(m.total_cost, 0.0)

    def test_all_known_models_present_by_default(self):
        result = compare_cost(input_tokens=1000, output_tokens=500)
        result_models = {m.model for m in result.all_models}
        for model in _PRICING:
            self.assertIn(model, result_models)

    def test_sorted_ascending_by_cost(self):
        result = compare_cost(input_tokens=1000, output_tokens=500)
        costs = [m.total_cost for m in result.all_models]
        self.assertEqual(costs, sorted(costs))


class TestAddCustomPricing(unittest.TestCase):

    def tearDown(self):
        # Remove any test models we added
        _PRICING.pop("test-model-abc", None)
        _PRICING.pop("test-cheap-model", None)

    def test_custom_model_appears_in_compare(self):
        add_custom_pricing("test-model-abc", input_per_1m=1.0, output_per_1m=2.0)
        result = compare_cost(
            input_tokens=1_000_000,
            output_tokens=1_000_000,
            models=["test-model-abc"],
        )
        self.assertEqual(result.all_models[0].model, "test-model-abc")

    def test_custom_pricing_correct_cost(self):
        add_custom_pricing("test-cheap-model", input_per_1m=1.0, output_per_1m=2.0)
        result = compare_cost(
            input_tokens=1_000_000,
            output_tokens=1_000_000,
            models=["test-cheap-model"],
        )
        m = result.all_models[0]
        # 1M input @ $1/1M = $1.00, 1M output @ $2/1M = $2.00, total = $3.00
        self.assertAlmostEqual(m.input_cost, 1.0, places=5)
        self.assertAlmostEqual(m.output_cost, 2.0, places=5)
        self.assertAlmostEqual(m.total_cost, 3.0, places=5)

    def test_custom_pricing_overrides_existing(self):
        original_pricing = _PRICING.get("gpt-4o")
        try:
            add_custom_pricing("gpt-4o", input_per_1m=0.01, output_per_1m=0.01)
            result = compare_cost(
                input_tokens=1_000_000,
                output_tokens=1_000_000,
                models=["gpt-4o"],
            )
            self.assertAlmostEqual(result.all_models[0].total_cost, 0.02, places=5)
        finally:
            # Restore original
            if original_pricing:
                _PRICING["gpt-4o"] = original_pricing


if __name__ == "__main__":
    unittest.main()
