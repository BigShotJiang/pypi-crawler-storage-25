"""
Tests for Pradvion integrations:
  - LangChain (PradvionCallback)
  - OpenTelemetry (PradvionSpanExporter)
  - LlamaIndex (PradvionLlamaCallback)
"""
import time
import unittest
from unittest.mock import MagicMock, patch
import uuid


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_pradvion():
    mock = MagicMock()
    mock.track = MagicMock()
    return mock


# ─────────────────────────────────────────────────────────────────────────────
# LangChain
# ─────────────────────────────────────────────────────────────────────────────

class TestLangChainCallback(unittest.TestCase):

    def _make_callback(self):
        from pradvion.integrations.langchain import PradvionCallback
        return PradvionCallback(pradvion_client=_make_pradvion())

    # ── _detect_provider ─────────────────────────────────────────

    def test_detect_provider_openai(self):
        from pradvion.integrations.langchain import _detect_provider
        serialized = {"id": ["langchain_community", "chat_models", "ChatOpenAI"]}
        self.assertEqual(_detect_provider(serialized), "openai")

    def test_detect_provider_anthropic(self):
        from pradvion.integrations.langchain import _detect_provider
        serialized = {"id": ["langchain_anthropic", "ChatAnthropic"]}
        self.assertEqual(_detect_provider(serialized), "anthropic")

    def test_detect_provider_unknown(self):
        from pradvion.integrations.langchain import _detect_provider
        serialized = {"id": ["some_unknown_provider"]}
        self.assertEqual(_detect_provider(serialized), "unknown")

    def test_detect_provider_from_model_name_claude(self):
        from pradvion.integrations.langchain import _detect_provider
        serialized = {"kwargs": {"model_name": "claude-3-opus-20240229"}}
        self.assertEqual(_detect_provider(serialized), "anthropic")

    # ── _extract_model ────────────────────────────────────────────

    def test_extract_model_from_kwargs(self):
        from pradvion.integrations.langchain import _extract_model
        serialized = {"kwargs": {"model_name": "gpt-4o"}}
        self.assertEqual(_extract_model(serialized), "gpt-4o")

    def test_extract_model_fallback_unknown(self):
        from pradvion.integrations.langchain import _extract_model
        self.assertEqual(_extract_model({}), "unknown")

    # ── on_llm_start / on_llm_end ────────────────────────────────

    def test_on_llm_start_stores_timing(self):
        cb = self._make_callback()
        run_id = uuid.uuid4()
        cb.on_llm_start(
            {"id": ["ChatOpenAI"]}, ["hello"],
            run_id=run_id
        )
        self.assertIn(str(run_id), cb._start_times)

    def test_on_llm_end_calls_track(self):
        cb = self._make_callback()
        run_id = uuid.uuid4()
        cb.on_llm_start({"id": ["ChatOpenAI"]}, ["hi"], run_id=run_id)

        # Simulate LLMResult
        response = MagicMock()
        response.llm_output = {
            "token_usage": {"prompt_tokens": 10, "completion_tokens": 5},
            "model_name": "gpt-4o",
        }
        cb.on_llm_end(response, run_id=run_id)

        cb._pradvion.track.assert_called_once()
        call_kwargs = cb._pradvion.track.call_args[1]
        self.assertEqual(call_kwargs["input_tokens"], 10)
        self.assertEqual(call_kwargs["output_tokens"], 5)
        self.assertEqual(call_kwargs["model"], "gpt-4o")
        self.assertEqual(call_kwargs["status_code"], 200)

    def test_on_llm_end_cleans_up_run_id(self):
        cb = self._make_callback()
        run_id = uuid.uuid4()
        cb.on_llm_start({"id": []}, ["hi"], run_id=run_id)
        cb.on_llm_end(MagicMock(llm_output={}), run_id=run_id)
        self.assertNotIn(str(run_id), cb._start_times)
        self.assertNotIn(str(run_id), cb._serialized)

    # ── on_llm_error ─────────────────────────────────────────────

    def test_on_llm_error_tracks_status_500(self):
        cb = self._make_callback()
        run_id = uuid.uuid4()
        cb.on_llm_start({"id": ["ChatOpenAI"]}, ["hi"], run_id=run_id)
        cb.on_llm_error(RuntimeError("timeout"), run_id=run_id)

        call_kwargs = cb._pradvion.track.call_args[1]
        self.assertEqual(call_kwargs["status_code"], 500)
        self.assertEqual(call_kwargs["input_tokens"], 0)
        self.assertEqual(call_kwargs["output_tokens"], 0)

    def test_stub_methods_do_not_raise(self):
        cb = self._make_callback()
        run_id = uuid.uuid4()
        cb.on_chain_start({}, [], run_id=run_id)
        cb.on_chain_end({}, run_id=run_id)
        cb.on_chain_error(RuntimeError(), run_id=run_id)
        cb.on_tool_start({}, "input", run_id=run_id)
        cb.on_tool_end("output", run_id=run_id)
        cb.on_tool_error(RuntimeError(), run_id=run_id)
        cb.on_text("hello", run_id=run_id)
        cb.on_agent_finish(MagicMock(), run_id=run_id)


# ─────────────────────────────────────────────────────────────────────────────
# OpenTelemetry
# ─────────────────────────────────────────────────────────────────────────────

class FakeStatus:
    def __init__(self, code_str):
        self.status_code = code_str


class FakeSpan:
    def __init__(self, attrs, start_ns=None, end_ns=None, status_code="OK"):
        self.attributes = attrs
        self.start_time = start_ns or 1_000_000_000
        self.end_time = end_ns or 1_200_000_000  # 200ms
        self.status = FakeStatus(status_code)


class TestOTELExporter(unittest.TestCase):

    def _make_exporter(self):
        from pradvion.integrations.otel import PradvionSpanExporter
        pradvion = _make_pradvion()
        return PradvionSpanExporter(pradvion_client=pradvion), pradvion

    def test_export_ai_span_calls_track(self):
        exporter, pradvion = self._make_exporter()
        span = FakeSpan({
            "gen_ai.system": "openai",
            "gen_ai.request.model": "gpt-4o",
            "gen_ai.usage.input_tokens": 100,
            "gen_ai.usage.output_tokens": 50,
        })
        exporter.export([span])
        pradvion.track.assert_called_once()

    def test_export_extracts_token_counts(self):
        exporter, pradvion = self._make_exporter()
        span = FakeSpan({
            "gen_ai.system": "anthropic",
            "gen_ai.request.model": "claude-3-5-sonnet-20241022",
            "gen_ai.usage.input_tokens": 200,
            "gen_ai.usage.output_tokens": 80,
        })
        exporter.export([span])
        kw = pradvion.track.call_args[1]
        self.assertEqual(kw["input_tokens"], 200)
        self.assertEqual(kw["output_tokens"], 80)
        self.assertEqual(kw["provider"], "anthropic")
        self.assertEqual(kw["model"], "claude-3-5-sonnet-20241022")

    def test_export_calculates_latency_ms(self):
        exporter, pradvion = self._make_exporter()
        # 500ms = 500_000_000 ns
        span = FakeSpan(
            {"gen_ai.system": "openai", "gen_ai.usage.input_tokens": 10},
            start_ns=1_000_000_000,
            end_ns=1_500_000_000,  # 500ms later
        )
        exporter.export([span])
        kw = pradvion.track.call_args[1]
        self.assertEqual(kw["latency_ms"], 500)

    def test_export_error_span_sets_status_500(self):
        exporter, pradvion = self._make_exporter()
        span = FakeSpan(
            {"gen_ai.system": "openai", "gen_ai.usage.input_tokens": 10},
            status_code="ERROR",
        )
        exporter.export([span])
        kw = pradvion.track.call_args[1]
        self.assertEqual(kw["status_code"], 500)

    def test_export_non_ai_span_skipped(self):
        exporter, pradvion = self._make_exporter()
        span = FakeSpan({"http.method": "GET", "http.url": "https://example.com"})
        exporter.export([span])
        pradvion.track.assert_not_called()

    def test_export_returns_success(self):
        exporter, pradvion = self._make_exporter()
        result = exporter.export([])
        self.assertEqual(result, 0)  # SUCCESS = 0

    def test_export_multiple_spans(self):
        exporter, pradvion = self._make_exporter()
        spans = [
            FakeSpan({"gen_ai.system": "openai", "gen_ai.usage.input_tokens": 10}),
            FakeSpan({"gen_ai.system": "anthropic", "gen_ai.usage.input_tokens": 20}),
            FakeSpan({"http.method": "GET"}),  # non-AI span, should be skipped
        ]
        exporter.export(spans)
        self.assertEqual(pradvion.track.call_count, 2)

    def test_setup_otel_returns_exporter(self):
        from pradvion.integrations.otel import setup_otel, PradvionSpanExporter
        exporter = setup_otel(pradvion_client=_make_pradvion())
        self.assertIsInstance(exporter, PradvionSpanExporter)


# ─────────────────────────────────────────────────────────────────────────────
# LlamaIndex
# ─────────────────────────────────────────────────────────────────────────────

class TestLlamaIndexCallback(unittest.TestCase):

    def _make_callback(self):
        from pradvion.integrations.llamaindex import PradvionLlamaCallback
        return PradvionLlamaCallback(pradvion_client=_make_pradvion())

    def test_on_llm_event_calls_track(self):
        cb = self._make_callback()
        event_id = "evt-001"
        cb.on_event_start("CBEventType.LLM", payload={}, event_id=event_id)
        cb.on_event_end("CBEventType.LLM", payload={}, event_id=event_id)
        cb._pradvion.track.assert_called_once()

    def test_non_llm_event_skipped(self):
        cb = self._make_callback()
        event_id = "evt-002"
        cb.on_event_start("CBEventType.EMBEDDING", payload={}, event_id=event_id)
        cb.on_event_end("CBEventType.EMBEDDING", payload={}, event_id=event_id)
        cb._pradvion.track.assert_not_called()

    def test_token_usage_extracted_from_raw(self):
        cb = self._make_callback()
        event_id = "evt-003"
        cb.on_event_start("LLM", payload={}, event_id=event_id)

        response = MagicMock()
        response.raw = {
            "usage": {"prompt_tokens": 40, "completion_tokens": 20}
        }
        cb.on_event_end("LLM", payload={"response": response}, event_id=event_id)

        kw = cb._pradvion.track.call_args[1]
        self.assertEqual(kw["input_tokens"], 40)
        self.assertEqual(kw["output_tokens"], 20)

    def test_start_trace_end_trace_do_not_raise(self):
        cb = self._make_callback()
        cb.start_trace("trace-1")
        cb.end_trace("trace-1", trace_map={})

    def test_provider_detection_openai(self):
        cb = self._make_callback()
        event_id = "evt-004"
        serialized = {"model_name": "gpt-4o", "openai_key": "xxx"}
        cb.on_event_start("LLM", payload={"serialized": serialized}, event_id=event_id)
        self.assertEqual(cb._event_meta[event_id][0], "openai")


if __name__ == "__main__":
    unittest.main()
