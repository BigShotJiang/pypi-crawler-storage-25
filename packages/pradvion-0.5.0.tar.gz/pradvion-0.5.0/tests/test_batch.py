"""
Tests for batch tracking and error tracking on PradvionClient.
"""
import tempfile
import unittest
from unittest.mock import patch, MagicMock, call

from pradvion.client import PradvionClient


def _make_client():
    db = tempfile.mktemp(suffix=".db")
    return PradvionClient(
        api_key="nx_test_key",
        base_url="https://example.com",
        db_path=db,
    )


class TestTrackBatch(unittest.TestCase):

    def setUp(self):
        self.client = _make_client()

    def tearDown(self):
        self.client.shutdown()

    def test_track_batch_calls_track_for_each_event(self):
        events = [
            {"provider": "openai", "model": "gpt-4o",
             "input_tokens": 100, "output_tokens": 50, "latency_ms": 200},
            {"provider": "anthropic", "model": "claude-3-5-sonnet-20241022",
             "input_tokens": 200, "output_tokens": 80, "latency_ms": 300},
        ]
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            self.client.track_batch(events)

        self.assertEqual(len(payloads), 2)

    def test_track_batch_empty_list_does_nothing(self):
        with patch.object(self.client._queue, "push") as mock_push:
            self.client.track_batch([])
        mock_push.assert_not_called()

    def test_track_batch_payload_fields(self):
        events = [
            {"provider": "openai", "model": "gpt-4o",
             "input_tokens": 10, "output_tokens": 5, "latency_ms": 100},
        ]
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            self.client.track_batch(events)

        self.assertEqual(payloads[0]["provider"], "openai")
        self.assertEqual(payloads[0]["model"], "gpt-4o")
        self.assertEqual(payloads[0]["input_tokens"], 10)

    def test_track_batch_skips_invalid_entry(self):
        events = [
            {"provider": "openai", "model": "gpt-4o",
             "input_tokens": 10, "output_tokens": 5, "latency_ms": 100},
            {"bad_key": "invalid"},  # missing required fields → will fail
        ]
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            # Should not raise; bad entry is skipped
            self.client.track_batch(events)

        # Only the valid entry pushed
        self.assertEqual(len(payloads), 1)

    def test_track_batch_customer_id_hashed(self):
        events = [
            {"provider": "openai", "model": "gpt-4o",
             "input_tokens": 10, "output_tokens": 5, "latency_ms": 100,
             "customer_id": "samsung-001"},
        ]
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            self.client.track_batch(events)

        self.assertIn("customer_id_hash", payloads[0])
        self.assertNotIn("customer_id", payloads[0])


class TestSignalBatch(unittest.TestCase):

    def setUp(self):
        self.client = _make_client()

    def tearDown(self):
        self.client.shutdown()

    def test_signal_batch_pushes_each_signal(self):
        signals = [
            {"customer_id": "acme", "event": "email_sent", "quantity": 10},
            {"customer_id": "acme", "event": "meeting_booked", "value": 150.0},
        ]
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            self.client.signal_batch(signals)

        self.assertEqual(len(payloads), 2)

    def test_signal_batch_empty_list_does_nothing(self):
        with patch.object(self.client._queue, "push") as mock_push:
            self.client.signal_batch([])
        mock_push.assert_not_called()

    def test_signal_batch_event_name_normalized(self):
        signals = [{"customer_id": "acme", "event": "  Email_Sent  "}]
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            self.client.signal_batch(signals)

        self.assertEqual(payloads[0]["event"], "email_sent")


class TestTrackError(unittest.TestCase):

    def setUp(self):
        self.client = _make_client()

    def tearDown(self):
        self.client.shutdown()

    def test_track_error_pushes_status_500(self):
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            self.client.track_error(
                provider="openai",
                model="gpt-4o",
                error=RuntimeError("timeout"),
            )

        self.assertEqual(len(payloads), 1)
        self.assertEqual(payloads[0]["status_code"], 500)

    def test_track_error_zero_tokens(self):
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            self.client.track_error("openai", "gpt-4o", ValueError("bad"))

        self.assertEqual(payloads[0]["input_tokens"], 0)
        self.assertEqual(payloads[0]["output_tokens"], 0)

    def test_track_error_with_latency(self):
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            self.client.track_error(
                "openai", "gpt-4o", Exception("err"), latency_ms=450
            )
        self.assertEqual(payloads[0]["latency_ms"], 450)

    def test_track_error_with_customer_id(self):
        payloads = []
        with patch.object(self.client._queue, "push", side_effect=payloads.append):
            self.client.track_error(
                "openai", "gpt-4o", Exception("err"),
                customer_id="samsung-001"
            )
        self.assertIn("customer_id_hash", payloads[0])
        self.assertNotIn("customer_id", payloads[0])

    def test_module_level_track_error(self):
        """pradvion.track_error() delegates to initialized client."""
        import pradvion
        pradvion.init(
            api_key="nx_test",
            base_url="https://example.com",
            auto_flush=False,
        )
        payloads = []
        with patch.object(pradvion._client._queue, "push",
                          side_effect=payloads.append):
            pradvion.track_error("openai", "gpt-4o", RuntimeError("x"))

        self.assertEqual(len(payloads), 1)
        self.assertEqual(payloads[0]["status_code"], 500)
        pradvion._client.shutdown()


if __name__ == "__main__":
    unittest.main()
