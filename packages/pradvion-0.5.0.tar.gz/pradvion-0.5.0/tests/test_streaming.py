"""
Tests for streaming improvements in wrapper.py.
"""
import time
import unittest
from unittest.mock import patch, MagicMock

from pradvion.wrapper import _StreamWrapper, _AsyncStreamWrapper


def _make_pradvion():
    mock = MagicMock()
    mock.track = MagicMock()
    return mock


class TestStreamingImprovements(unittest.TestCase):

    # ── chunk count fallback ──────────────────────────────────────

    def test_chunk_count_used_when_no_usage(self):
        """When stream has no usage chunk, chunk_count becomes output_tokens."""
        chunks = [MagicMock(spec=[]) for _ in range(7)]  # no .usage attribute
        for c in chunks:
            del c.usage  # ensure getattr returns None
        # Rebuild without usage attr
        chunks = [object() for _ in range(7)]  # plain objects, no usage

        pradvion = _make_pradvion()
        wrapper = _StreamWrapper(
            stream=iter(chunks),
            pradvion_client=pradvion,
            provider="openai",
            model="gpt-4o",
            start_time=time.monotonic(),
            ctx={},
        )
        list(wrapper)  # consume

        call_kwargs = pradvion.track.call_args[1]
        # chunk_count = 7 → output_tokens fallback
        self.assertEqual(call_kwargs["output_tokens"], 7)

    def test_usage_object_takes_priority_over_chunk_count(self):
        """When last chunk has usage, those values are used, not chunk count."""

        class FakeUsage:
            prompt_tokens = 100
            completion_tokens = 50
            prompt_tokens_details = None
            completion_tokens_details = None

        class ChunkWithUsage:
            id = "test-id"
            usage = FakeUsage()

        chunks = [object(), object(), ChunkWithUsage()]  # 3 chunks, last has usage

        pradvion = _make_pradvion()
        wrapper = _StreamWrapper(
            stream=iter(chunks),
            pradvion_client=pradvion,
            provider="openai",
            model="gpt-4o",
            start_time=time.monotonic(),
            ctx={},
        )
        list(wrapper)

        call_kwargs = pradvion.track.call_args[1]
        self.assertEqual(call_kwargs["input_tokens"], 100)
        self.assertEqual(call_kwargs["output_tokens"], 50)

    # ── error status tracking ─────────────────────────────────────

    def test_error_during_stream_sets_status_500(self):
        """If stream raises mid-iteration, status_code=500 is tracked."""

        def failing_stream():
            yield object()
            raise RuntimeError("network error")

        pradvion = _make_pradvion()
        wrapper = _StreamWrapper(
            stream=failing_stream(),
            pradvion_client=pradvion,
            provider="openai",
            model="gpt-4o",
            start_time=time.monotonic(),
            ctx={},
        )
        with self.assertRaises(RuntimeError):
            list(wrapper)

        call_kwargs = pradvion.track.call_args[1]
        self.assertEqual(call_kwargs["status_code"], 500)

    def test_successful_stream_sets_status_200(self):
        """Successful stream sets status_code=200."""
        chunks = [object(), object()]

        pradvion = _make_pradvion()
        wrapper = _StreamWrapper(
            stream=iter(chunks),
            pradvion_client=pradvion,
            provider="openai",
            model="gpt-4o",
            start_time=time.monotonic(),
            ctx={},
        )
        list(wrapper)

        call_kwargs = pradvion.track.call_args[1]
        self.assertEqual(call_kwargs["status_code"], 200)

    # ── context propagation ───────────────────────────────────────

    def test_context_propagated_to_track(self):
        ctx = {
            "feature": "test-feature",
            "customer_id": "cust-123",
            "conversation_id": "conv-abc",
        }
        pradvion = _make_pradvion()
        wrapper = _StreamWrapper(
            stream=iter([object()]),
            pradvion_client=pradvion,
            provider="openai",
            model="gpt-4o",
            start_time=time.monotonic(),
            ctx=ctx,
        )
        list(wrapper)

        call_kwargs = pradvion.track.call_args[1]
        self.assertEqual(call_kwargs["feature"], "test-feature")
        self.assertEqual(call_kwargs["customer_id"], "cust-123")
        self.assertEqual(call_kwargs["conversation_id"], "conv-abc")

    # ── track called exactly once ─────────────────────────────────

    def test_track_called_exactly_once(self):
        pradvion = _make_pradvion()
        wrapper = _StreamWrapper(
            stream=iter([object(), object(), object()]),
            pradvion_client=pradvion,
            provider="openai",
            model="gpt-4o",
            start_time=time.monotonic(),
            ctx={},
        )
        list(wrapper)
        pradvion.track.assert_called_once()

    def test_empty_stream_still_calls_track(self):
        pradvion = _make_pradvion()
        wrapper = _StreamWrapper(
            stream=iter([]),
            pradvion_client=pradvion,
            provider="openai",
            model="gpt-4o",
            start_time=time.monotonic(),
            ctx={},
        )
        list(wrapper)
        pradvion.track.assert_called_once()

    # ── async stream wrapper ──────────────────────────────────────

    def test_async_error_sets_status_500(self):
        """AsyncStreamWrapper: error sets status_code=500."""
        import asyncio

        async def run():
            async def failing_astream():
                yield object()
                raise RuntimeError("async error")

            pradvion = _make_pradvion()
            wrapper = _AsyncStreamWrapper(
                stream=failing_astream(),
                pradvion_client=pradvion,
                provider="openai",
                model="gpt-4o",
                start_time=time.monotonic(),
                ctx={},
            )
            chunks = []
            try:
                async for chunk in wrapper:
                    chunks.append(chunk)
            except RuntimeError:
                pass

            call_kwargs = pradvion.track.call_args[1]
            assert call_kwargs["status_code"] == 500, (
                f"Expected 500, got {call_kwargs['status_code']}"
            )

        asyncio.run(run())


if __name__ == "__main__":
    unittest.main()
