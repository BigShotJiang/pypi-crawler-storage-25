"""
Tests for pradvion.forecast — forecast_monthly() and forecast_from_requests().
"""
import unittest

from pradvion.forecast import ForecastResult, forecast_monthly, forecast_from_requests


class TestForecastMonthly(unittest.TestCase):

    def test_basic_projection(self):
        # 10 days in, spent $5 → daily $0.50 → monthly $15
        result = forecast_monthly(actual_spend=5.0, days_elapsed=10)
        self.assertAlmostEqual(result.daily_rate, 0.5, places=5)
        self.assertAlmostEqual(result.projected_monthly, 15.0, places=5)
        self.assertEqual(result.days_elapsed, 10)
        self.assertAlmostEqual(result.actual_spend, 5.0, places=5)

    def test_zero_days_returns_zero(self):
        result = forecast_monthly(actual_spend=100.0, days_elapsed=0)
        self.assertEqual(result.projected_monthly, 0.0)
        self.assertEqual(result.daily_rate, 0.0)

    def test_negative_days_treated_as_zero(self):
        result = forecast_monthly(actual_spend=10.0, days_elapsed=-5)
        self.assertEqual(result.projected_monthly, 0.0)

    def test_no_budget_limit(self):
        result = forecast_monthly(actual_spend=10.0, days_elapsed=5)
        self.assertFalse(result.will_exceed_budget)
        self.assertIsNone(result.days_until_budget)
        self.assertIsNone(result.budget_limit)

    def test_within_budget(self):
        result = forecast_monthly(
            actual_spend=5.0, days_elapsed=10, budget_limit=100.0
        )
        self.assertFalse(result.will_exceed_budget)
        self.assertIsNotNone(result.days_until_budget)

    def test_exceeds_budget(self):
        # 5 days in, $50 — projects to $300/mo vs $100 limit
        result = forecast_monthly(
            actual_spend=50.0, days_elapsed=5, budget_limit=100.0
        )
        self.assertTrue(result.will_exceed_budget)

    def test_days_until_budget_calculation(self):
        # Daily rate = 1.0 USD/day. Budget = 10. Spent = 3. Remaining = 7 days.
        result = forecast_monthly(
            actual_spend=3.0, days_elapsed=3, budget_limit=10.0
        )
        self.assertAlmostEqual(result.days_until_budget, 7.0, places=5)

    def test_returns_forecast_result_type(self):
        result = forecast_monthly(5.0, 10)
        self.assertIsInstance(result, ForecastResult)

    def test_zero_spend_zero_rate(self):
        result = forecast_monthly(actual_spend=0.0, days_elapsed=15)
        self.assertEqual(result.projected_monthly, 0.0)
        self.assertEqual(result.daily_rate, 0.0)


class TestForecastFromRequests(unittest.TestCase):

    def test_empty_list_returns_zero(self):
        result = forecast_from_requests([])
        self.assertEqual(result.projected_monthly, 0.0)
        self.assertEqual(result.days_elapsed, 0)

    def test_single_request(self):
        result = forecast_from_requests([
            {"cost_usd": 0.05, "timestamp": "2024-01-01T10:00:00Z"}
        ])
        self.assertAlmostEqual(result.actual_spend, 0.05, places=5)
        self.assertEqual(result.days_elapsed, 1)

    def test_multi_day_requests(self):
        result = forecast_from_requests([
            {"cost_usd": 5.0, "timestamp": "2024-01-01T00:00:00Z"},
            {"cost_usd": 5.0, "timestamp": "2024-01-05T00:00:00Z"},  # 5 days later
        ])
        self.assertAlmostEqual(result.actual_spend, 10.0, places=5)
        # delta = 4 days → days_elapsed = max(1, 4+1) = 5
        self.assertEqual(result.days_elapsed, 5)
        self.assertAlmostEqual(result.daily_rate, 2.0, places=5)

    def test_with_budget_limit(self):
        result = forecast_from_requests(
            [{"cost_usd": 50.0, "timestamp": "2024-01-01T00:00:00Z"}],
            budget_limit=30.0,
        )
        self.assertTrue(result.will_exceed_budget)

    def test_missing_timestamp_falls_back(self):
        # No timestamps — falls back to len(requests)
        requests = [
            {"cost_usd": 1.0},
            {"cost_usd": 2.0},
            {"cost_usd": 3.0},
        ]
        result = forecast_from_requests(requests)
        self.assertAlmostEqual(result.actual_spend, 6.0, places=5)
        self.assertGreater(result.days_elapsed, 0)

    def test_missing_cost_treated_as_zero(self):
        result = forecast_from_requests([
            {"timestamp": "2024-01-01T00:00:00Z"},  # no cost_usd
        ])
        self.assertAlmostEqual(result.actual_spend, 0.0, places=5)


if __name__ == "__main__":
    unittest.main()
