"""
Tests for pradvion.cli — Auto-Instrument CLI.
"""
import tempfile
import unittest
from pathlib import Path

from pradvion.cli import (
    _detect_ai_usage,
    _find_python_files,
    _generate_patch,
    _should_skip_file,
    _undo_instrumentation,
    instrument,
)


class TestDetectAIUsage(unittest.TestCase):

    def test_detect_openai_import(self):
        content = "from openai import OpenAI\nclient = OpenAI()"
        result = _detect_ai_usage(content)
        self.assertTrue(result["has_openai"])
        self.assertFalse(result["has_anthropic"])

    def test_detect_anthropic_import(self):
        content = "from anthropic import Anthropic\nc = Anthropic()"
        result = _detect_ai_usage(content)
        self.assertTrue(result["has_anthropic"])
        self.assertFalse(result["has_openai"])

    def test_detect_already_instrumented(self):
        content = "client = pradvion.monitor(OpenAI())"
        result = _detect_ai_usage(content)
        self.assertTrue(result["already_instrumented"])

    def test_detect_already_init(self):
        content = "pradvion.init(api_key='...')"
        result = _detect_ai_usage(content)
        self.assertTrue(result["already_init"])

    def test_detect_client_variable_name(self):
        content = "from openai import OpenAI\nclient = OpenAI()"
        result = _detect_ai_usage(content)
        self.assertIn("client", result["openai_clients"])

    def test_detect_no_ai_usage(self):
        content = "import os\nprint('hello')"
        result = _detect_ai_usage(content)
        self.assertFalse(result["has_openai"])
        self.assertFalse(result["has_anthropic"])

    def test_detect_both_providers(self):
        content = (
            "from openai import OpenAI\n"
            "from anthropic import Anthropic\n"
            "oa = OpenAI()\nan = Anthropic()"
        )
        result = _detect_ai_usage(content)
        self.assertTrue(result["has_openai"])
        self.assertTrue(result["has_anthropic"])

    def test_not_already_instrumented_by_default(self):
        content = "from openai import OpenAI\nclient = OpenAI()"
        result = _detect_ai_usage(content)
        self.assertFalse(result["already_instrumented"])

    def test_detect_multiple_clients(self):
        content = (
            "from openai import OpenAI\n"
            "client1 = OpenAI()\n"
            "client2 = OpenAI(api_key='x')\n"
        )
        result = _detect_ai_usage(content)
        self.assertIn("client1", result["openai_clients"])
        self.assertIn("client2", result["openai_clients"])

    def test_detect_anthropic_client_name(self):
        content = "from anthropic import Anthropic\nant = Anthropic()"
        result = _detect_ai_usage(content)
        self.assertIn("ant", result["anthropic_clients"])


class TestGeneratePatch(unittest.TestCase):

    def test_patch_adds_pradvion_import(self):
        content = "from openai import OpenAI\nclient = OpenAI()\n"
        detection = _detect_ai_usage(content)
        patched = _generate_patch(content, detection)
        self.assertIsNotNone(patched)
        self.assertIn("import pradvion", patched)

    def test_patch_adds_init_call(self):
        content = "from openai import OpenAI\nclient = OpenAI()\n"
        detection = _detect_ai_usage(content)
        patched = _generate_patch(content, detection)
        self.assertIsNotNone(patched)
        self.assertIn("pradvion.init(", patched)

    def test_patch_wraps_client(self):
        content = "from openai import OpenAI\nclient = OpenAI()\n"
        detection = _detect_ai_usage(content)
        patched = _generate_patch(content, detection)
        self.assertIsNotNone(patched)
        self.assertIn("pradvion.monitor(", patched)

    def test_patch_skips_already_instrumented(self):
        content = "client = pradvion.monitor(OpenAI())\n"
        detection = _detect_ai_usage(content)
        patched = _generate_patch(content, detection)
        self.assertIsNone(patched)

    def test_patch_skips_no_ai_usage(self):
        content = "import os\nprint('hello')\n"
        detection = _detect_ai_usage(content)
        patched = _generate_patch(content, detection)
        self.assertIsNone(patched)

    def test_patch_adds_os_import_when_missing(self):
        content = "from openai import OpenAI\nclient = OpenAI()\n"
        detection = _detect_ai_usage(content)
        patched = _generate_patch(content, detection)
        self.assertIsNotNone(patched)
        self.assertIn("import os", patched)

    def test_patch_does_not_duplicate_os_import(self):
        content = "import os\nfrom openai import OpenAI\nclient = OpenAI()\n"
        detection = _detect_ai_usage(content)
        patched = _generate_patch(content, detection)
        self.assertIsNotNone(patched)
        self.assertEqual(patched.count("import os"), 1)

    def test_patch_anthropic_client(self):
        content = "from anthropic import Anthropic\nc = Anthropic()\n"
        detection = _detect_ai_usage(content)
        patched = _generate_patch(content, detection)
        self.assertIsNotNone(patched)
        self.assertIn("pradvion.monitor(", patched)

    def test_patch_preserves_original_code(self):
        content = (
            "from openai import OpenAI\n"
            "client = OpenAI()\n"
            "\n"
            "def my_func():\n"
            "    pass\n"
        )
        detection = _detect_ai_usage(content)
        patched = _generate_patch(content, detection)
        self.assertIsNotNone(patched)
        self.assertIn("def my_func():", patched)
        self.assertIn("    pass", patched)


class TestUndoInstrumentation(unittest.TestCase):

    def test_undo_removes_pradvion_import(self):
        content = (
            "import os\n"
            "import pradvion\n"
            "from openai import OpenAI\n"
            'pradvion.init(api_key=os.environ.get("PRADVION_API_KEY", ""))\n'
            "client = pradvion.monitor(OpenAI())\n"
        )
        result = _undo_instrumentation(content)
        self.assertIsNotNone(result)
        self.assertNotIn("import pradvion", result)

    def test_undo_removes_monitor_wrapper(self):
        content = "client = pradvion.monitor(OpenAI())\n"
        result = _undo_instrumentation(content)
        self.assertIsNotNone(result)
        self.assertNotIn("pradvion.monitor", result)

    def test_undo_no_pradvion_returns_none(self):
        content = "from openai import OpenAI\nclient = OpenAI()\n"
        result = _undo_instrumentation(content)
        self.assertIsNone(result)

    def test_undo_removes_init_call(self):
        content = (
            "import pradvion\n"
            'pradvion.init(api_key=os.environ.get("PRADVION_API_KEY", ""))\n'
            "from openai import OpenAI\n"
        )
        result = _undo_instrumentation(content)
        self.assertIsNotNone(result)
        self.assertNotIn("pradvion.init(", result)


class TestShouldSkipFile(unittest.TestCase):

    def test_skip_test_files(self):
        self.assertTrue(_should_skip_file(Path("test_app.py")))
        self.assertTrue(_should_skip_file(Path("app_test.py")))

    def test_skip_init_files(self):
        self.assertTrue(_should_skip_file(Path("__init__.py")))

    def test_skip_setup_files(self):
        self.assertTrue(_should_skip_file(Path("setup.py")))

    def test_skip_non_python(self):
        self.assertTrue(_should_skip_file(Path("app.js")))
        self.assertTrue(_should_skip_file(Path("README.md")))

    def test_allow_normal_python(self):
        self.assertFalse(_should_skip_file(Path("app.py")))
        self.assertFalse(_should_skip_file(Path("my_app.py")))

    def test_skip_conftest(self):
        self.assertTrue(_should_skip_file(Path("conftest.py")))

    def test_skip_manage_py(self):
        self.assertTrue(_should_skip_file(Path("manage.py")))


class TestFindPythonFiles(unittest.TestCase):

    def test_finds_python_files_in_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "app.py").write_text("x = 1")
            (p / "utils.py").write_text("y = 2")
            files = _find_python_files(p)
            names = {f.name for f in files}
            self.assertIn("app.py", names)
            self.assertIn("utils.py", names)

    def test_skips_test_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "app.py").write_text("x = 1")
            (p / "test_app.py").write_text("x = 1")
            files = _find_python_files(p)
            names = {f.name for f in files}
            self.assertIn("app.py", names)
            self.assertNotIn("test_app.py", names)

    def test_skips_init_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p = Path(tmpdir)
            (p / "__init__.py").write_text("")
            (p / "app.py").write_text("x = 1")
            files = _find_python_files(p)
            names = {f.name for f in files}
            self.assertNotIn("__init__.py", names)

    def test_single_file_input(self):
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f:
            Path(f.name).write_text("x = 1")
            files = _find_python_files(Path(f.name))
            self.assertEqual(len(files), 1)


class TestInstrumentFunction(unittest.TestCase):

    def test_dry_run_makes_no_changes(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            f = Path(tmpdir) / "app.py"
            f.write_text("from openai import OpenAI\nclient = OpenAI()\n")

            result = instrument(target=tmpdir, dry_run=True, quiet=True)

            self.assertNotIn("pradvion", f.read_text())
            self.assertEqual(result["files_changed"], 1)

    def test_instrument_modifies_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            f = Path(tmpdir) / "app.py"
            f.write_text("from openai import OpenAI\nclient = OpenAI()\n")

            result = instrument(target=tmpdir, dry_run=False, quiet=True)

            content = f.read_text()
            self.assertIn("import pradvion", content)
            self.assertEqual(result["files_changed"], 1)

    def test_skips_already_instrumented(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            f = Path(tmpdir) / "app.py"
            f.write_text(
                "import pradvion\nclient = pradvion.monitor(OpenAI())\n"
            )

            result = instrument(target=tmpdir, quiet=True)

            self.assertEqual(result["files_skipped"], 1)
            self.assertEqual(result["files_changed"], 0)

    def test_nonexistent_path(self):
        result = instrument(target="/nonexistent/path/xyz", quiet=True)
        self.assertEqual(result["files_found"], 0)

    def test_undo_removes_instrumentation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            f = Path(tmpdir) / "app.py"
            f.write_text(
                "import pradvion\n"
                "from openai import OpenAI\n"
                "client = pradvion.monitor(OpenAI())\n"
            )

            result = instrument(target=tmpdir, undo=True, quiet=True)

            content = f.read_text()
            self.assertNotIn("pradvion.monitor", content)
            self.assertEqual(result["files_changed"], 1)

    def test_skips_files_with_no_ai(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            f = Path(tmpdir) / "utils.py"
            f.write_text("import os\nprint('hello')\n")

            result = instrument(target=tmpdir, quiet=True)

            self.assertNotIn("pradvion", f.read_text())
            self.assertEqual(result["files_changed"], 0)

    def test_returns_correct_counts(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / "app.py").write_text(
                "from openai import OpenAI\nclient = OpenAI()\n"
            )
            (Path(tmpdir) / "utils.py").write_text("import os\n")

            result = instrument(target=tmpdir, quiet=True)

            self.assertEqual(result["files_found"], 2)
            self.assertEqual(result["files_changed"], 1)
            self.assertEqual(result["files_skipped"], 1)

    def test_changes_list_populated(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            f = Path(tmpdir) / "app.py"
            f.write_text("from openai import OpenAI\nclient = OpenAI()\n")

            result = instrument(target=tmpdir, quiet=True)

            self.assertEqual(len(result["changes"]), 1)
            self.assertIn("app.py", result["changes"][0])


if __name__ == "__main__":
    unittest.main()
