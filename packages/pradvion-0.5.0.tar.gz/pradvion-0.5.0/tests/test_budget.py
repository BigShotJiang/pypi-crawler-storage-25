"""
Tests for pradvion.budget — BudgetTracker and BudgetExceededError.
"""
import threading
import unittest

from pradvion.budget import BudgetTracker, BudgetExceededError, get_budget_tracker


class TestBudgetTracker(unittest.TestCase):

    def setUp(self):
        self.tracker = BudgetTracker()

    # ── set_limit validation ──────────────────────────────────────

    def test_set_limit_invalid_action_raises(self):
        with self.assertRaises(ValueError):
            self.tracker.set_limit("acme", monthly_usd=100.0, action="explode")

    def test_set_limit_valid_actions_accepted(self):
        for action in ("raise", "warn", "ignore"):
            self.tracker.set_limit("acme", monthly_usd=50.0, action=action)
            self.assertEqual(self.tracker.get_action("acme"), action)

    def test_get_limit_returns_none_when_not_set(self):
        self.assertIsNone(self.tracker.get_limit("nobody"))

    def test_get_limit_returns_set_value(self):
        self.tracker.set_limit("acme", monthly_usd=100.0)
        self.assertEqual(self.tracker.get_limit("acme"), 100.0)

    # ── record_spend and get_spent ────────────────────────────────

    def test_record_spend_accumulates(self):
        self.tracker.record_spend("acme", 10.0)
        self.tracker.record_spend("acme", 5.0)
        self.assertAlmostEqual(self.tracker.get_spent("acme"), 15.0)

    def test_record_spend_no_limit_does_not_raise(self):
        # No limit set — should never raise
        for _ in range(100):
            self.tracker.record_spend("acme", 999.0)

    def test_record_spend_under_limit_does_not_raise(self):
        self.tracker.set_limit("acme", monthly_usd=100.0, action="raise")
        self.tracker.record_spend("acme", 50.0)
        self.assertAlmostEqual(self.tracker.get_spent("acme"), 50.0)

    def test_record_spend_exceeds_limit_raises(self):
        self.tracker.set_limit("acme", monthly_usd=10.0, action="raise")
        with self.assertRaises(BudgetExceededError) as ctx:
            self.tracker.record_spend("acme", 20.0)
        err = ctx.exception
        self.assertEqual(err.customer_id, "acme")
        self.assertGreater(err.spent, err.limit)

    def test_record_spend_exceeds_limit_warn_does_not_raise(self):
        self.tracker.set_limit("acme", monthly_usd=1.0, action="warn")
        # Should not raise
        self.tracker.record_spend("acme", 99.0)

    def test_record_spend_exceeds_limit_ignore_silent(self):
        self.tracker.set_limit("acme", monthly_usd=1.0, action="ignore")
        self.tracker.record_spend("acme", 999.0)  # no error, no warning

    # ── remaining ────────────────────────────────────────────────

    def test_remaining_no_limit_returns_none(self):
        self.assertIsNone(self.tracker.remaining("nobody"))

    def test_remaining_decreases_with_spend(self):
        self.tracker.set_limit("acme", monthly_usd=100.0)
        self.tracker.record_spend("acme", 30.0)
        self.assertAlmostEqual(self.tracker.remaining("acme"), 70.0)

    def test_remaining_never_below_zero(self):
        self.tracker.set_limit("acme", monthly_usd=10.0, action="ignore")
        self.tracker.record_spend("acme", 50.0)
        self.assertEqual(self.tracker.remaining("acme"), 0.0)

    # ── reset / remove_limit ──────────────────────────────────────

    def test_reset_clears_spending(self):
        self.tracker.record_spend("acme", 50.0)
        self.tracker.reset("acme")
        self.assertEqual(self.tracker.get_spent("acme"), 0.0)

    def test_remove_limit_clears_limit(self):
        self.tracker.set_limit("acme", monthly_usd=100.0)
        self.tracker.remove_limit("acme")
        self.assertIsNone(self.tracker.get_limit("acme"))

    # ── thread safety ─────────────────────────────────────────────

    def test_thread_safe_accumulation(self):
        self.tracker.set_limit("acme", monthly_usd=99999.0, action="ignore")
        errors = []

        def spend():
            try:
                for _ in range(100):
                    self.tracker.record_spend("acme", 0.01)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=spend) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(errors, [])
        # 10 threads × 100 × 0.01 = 10.0
        self.assertAlmostEqual(self.tracker.get_spent("acme"), 10.0, places=5)


class TestBudgetExceededError(unittest.TestCase):

    def test_attributes_set(self):
        err = BudgetExceededError("samsung", spent=150.0, limit=100.0)
        self.assertEqual(err.customer_id, "samsung")
        self.assertEqual(err.spent, 150.0)
        self.assertEqual(err.limit, 100.0)

    def test_is_exception(self):
        err = BudgetExceededError("acme", 5.0, 1.0)
        self.assertIsInstance(err, Exception)

    def test_message_contains_customer(self):
        err = BudgetExceededError("acme", 5.0, 1.0)
        self.assertIn("acme", str(err))


class TestGetBudgetTracker(unittest.TestCase):

    def test_returns_same_singleton(self):
        a = get_budget_tracker()
        b = get_budget_tracker()
        self.assertIs(a, b)

    def test_returns_budget_tracker_instance(self):
        self.assertIsInstance(get_budget_tracker(), BudgetTracker)


if __name__ == "__main__":
    unittest.main()
