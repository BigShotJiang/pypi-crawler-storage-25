"""
Tests for StreamingCostTracker (real-time streaming cost display).
"""
import unittest
from unittest.mock import MagicMock

from pradvion.wrapper import StreamingCostTracker


class TestStreamingCostTracker(unittest.TestCase):

    # ── Initialisation ────────────────────────────────────────────

    def test_init_known_model(self):
        tracker = StreamingCostTracker(
            provider="openai",
            model="gpt-4o",
            input_tokens=1000,
        )
        self.assertGreater(tracker._in_rate, 0)
        self.assertGreater(tracker._out_rate, 0)

    def test_init_unknown_model(self):
        tracker = StreamingCostTracker(
            provider="unknown",
            model="unknown-model",
            input_tokens=100,
        )
        self.assertEqual(tracker._in_rate, 0.0)
        self.assertEqual(tracker._out_rate, 0.0)

    def test_input_cost_precomputed(self):
        # gpt-4o input rate = $0.0000025/token
        tracker = StreamingCostTracker(
            provider="openai",
            model="gpt-4o",
            input_tokens=1000,
        )
        # 0.0000025 × 1000 = 0.0025
        self.assertAlmostEqual(tracker._input_cost, 0.0025, places=6)

    def test_zero_input_tokens_zero_input_cost(self):
        tracker = StreamingCostTracker("openai", "gpt-4o", input_tokens=0)
        self.assertEqual(tracker._input_cost, 0.0)

    def test_callback_interval_minimum_one(self):
        tracker = StreamingCostTracker(
            "openai", "gpt-4o", callback_interval=0
        )
        self.assertEqual(tracker.callback_interval, 1)

    # ── on_chunk ──────────────────────────────────────────────────

    def test_on_chunk_increments_count(self):
        tracker = StreamingCostTracker("openai", "gpt-4o-mini")
        chunk = MagicMock()
        tracker.on_chunk(chunk)
        tracker.on_chunk(chunk)
        self.assertEqual(tracker._output_chunks, 2)

    def test_on_chunk_updates_cost(self):
        tracker = StreamingCostTracker("openai", "gpt-4o-mini")
        chunk = MagicMock()
        tracker.on_chunk(chunk)
        self.assertGreater(tracker._estimated_cost, 0)

    def test_on_chunk_returns_estimated_cost(self):
        tracker = StreamingCostTracker("openai", "gpt-4o")
        chunk = MagicMock()
        cost = tracker.on_chunk(chunk)
        self.assertEqual(cost, tracker._estimated_cost)

    def test_callback_called_at_interval(self):
        calls = []
        tracker = StreamingCostTracker(
            provider="openai",
            model="gpt-4o",
            input_tokens=0,
            on_token=lambda c: calls.append(c),
            callback_interval=3,
        )
        chunk = MagicMock()
        for _ in range(6):
            tracker.on_chunk(chunk)
        self.assertEqual(len(calls), 2)

    def test_callback_not_called_before_interval(self):
        calls = []
        tracker = StreamingCostTracker(
            provider="openai",
            model="gpt-4o",
            on_token=lambda c: calls.append(c),
            callback_interval=10,
        )
        chunk = MagicMock()
        for _ in range(5):
            tracker.on_chunk(chunk)
        self.assertEqual(len(calls), 0)

    def test_callback_error_does_not_raise(self):
        def bad_callback(cost):
            raise ValueError("callback error")

        tracker = StreamingCostTracker(
            provider="openai",
            model="gpt-4o",
            on_token=bad_callback,
            callback_interval=1,
        )
        chunk = MagicMock()
        # Must not raise
        tracker.on_chunk(chunk)

    def test_no_callback_no_error(self):
        tracker = StreamingCostTracker("openai", "gpt-4o", on_token=None)
        tracker.on_chunk(MagicMock())  # must not raise

    # ── finalize ──────────────────────────────────────────────────

    def test_finalize_uses_actual_tokens(self):
        # gpt-4o: in=$0.0000025, out=$0.00001
        # 1000 in + 500 out = 0.0025 + 0.005 = 0.0075
        tracker = StreamingCostTracker("openai", "gpt-4o")
        final = tracker.finalize(
            actual_input_tokens=1000,
            actual_output_tokens=500,
        )
        self.assertAlmostEqual(final, 0.0075, places=6)

    def test_finalize_falls_back_to_estimate(self):
        tracker = StreamingCostTracker(
            provider="openai",
            model="gpt-4o",
            input_tokens=100,
        )
        chunk = MagicMock()
        for _ in range(10):
            tracker.on_chunk(chunk)

        final = tracker.finalize(0, 0)
        self.assertEqual(final, tracker._estimated_cost)

    def test_finalize_fires_final_callback(self):
        final_calls = []
        tracker = StreamingCostTracker(
            provider="openai",
            model="gpt-4o",
            input_tokens=500,
            on_token=lambda c: final_calls.append(c),
            callback_interval=100,  # never triggered during stream
        )
        tracker.finalize(500, 250)
        self.assertEqual(len(final_calls), 1)

    def test_finalize_callback_error_does_not_raise(self):
        def bad_cb(cost):
            raise RuntimeError("error")

        tracker = StreamingCostTracker(
            "openai", "gpt-4o", on_token=bad_cb, callback_interval=100
        )
        # Must not raise
        tracker.finalize(100, 50)

    # ── model coverage ────────────────────────────────────────────

    def test_all_openai_models_have_rates(self):
        models = [
            "gpt-4o", "gpt-4o-mini", "gpt-4-turbo",
            "gpt-3.5-turbo", "o1", "o1-mini", "o3-mini",
        ]
        for model in models:
            tracker = StreamingCostTracker("openai", model)
            self.assertGreater(
                tracker._out_rate, 0,
                f"Missing output rate for openai/{model}",
            )
            self.assertGreater(
                tracker._in_rate, 0,
                f"Missing input rate for openai/{model}",
            )

    def test_all_anthropic_models_have_rates(self):
        models = [
            "claude-3-5-sonnet-20241022",
            "claude-3-haiku-20240307",
            "claude-3-opus-20240229",
        ]
        for model in models:
            tracker = StreamingCostTracker("anthropic", model)
            self.assertGreater(
                tracker._out_rate, 0,
                f"Missing output rate for anthropic/{model}",
            )

    def test_cost_increases_with_more_chunks(self):
        tracker = StreamingCostTracker("openai", "gpt-4o")
        chunk = MagicMock()
        cost1 = tracker.on_chunk(chunk)
        cost2 = tracker.on_chunk(chunk)
        self.assertGreater(cost2, cost1)

    def test_input_cost_included_in_estimate(self):
        # With input tokens, estimate should be > estimate without
        tracker_with = StreamingCostTracker("openai", "gpt-4o", input_tokens=1000)
        tracker_without = StreamingCostTracker("openai", "gpt-4o", input_tokens=0)
        chunk = MagicMock()
        cost_with = tracker_with.on_chunk(chunk)
        cost_without = tracker_without.on_chunk(chunk)
        self.assertGreater(cost_with, cost_without)


if __name__ == "__main__":
    unittest.main()
