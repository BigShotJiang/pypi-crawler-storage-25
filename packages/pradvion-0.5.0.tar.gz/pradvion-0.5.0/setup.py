from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="pradvion",
    version="0.5.0",
    author="Pradvion",
    author_email="hello@pradvion.com",
    description="Track AI API costs per client, project, and feature",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://pradvion.com",
    project_urls={
        "Documentation": "https://pradvion.com/docs",
        "Source": "https://github.com/pradvion/pradvion-python",
    },
    packages=find_packages(exclude=["tests*", "examples*"]),
    python_requires=">=3.9",
    install_requires=[],
    extras_require={
        "openai": ["openai>=1.0.0"],
        "anthropic": ["anthropic>=0.20.0"],
        "all": ["openai>=1.0.0", "anthropic>=0.20.0"],
    },
    entry_points={
        "console_scripts": [
            "pradvion-instrument=pradvion.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries",
    ],
    keywords=[
        "ai", "openai", "anthropic", "cost tracking",
        "llm", "observability", "billing", "agency",
    ],
)
