"""Parse the raw YC founder directory text into a clean Target_List.txt"""

import re
import sys
from pathlib import Path

RAW_TEXT = Path(__file__).parent.parent / "raw_founders.txt"
OUTPUT = Path.home() / ".config" / "x-browser" / "Target_List.txt"


def parse_founders(text: str) -> list[dict]:
    """Parse the raw text dump from YC founder directory."""
    founders = []
    lines = [l.strip() for l in text.splitlines() if l.strip()]

    i = 0
    while i < len(lines):
        line = lines[i]

        # Skip nav/header/footer junk
        if line in (
            "About", "Companies", "Library", "Y Combinator", "Partners",
            "Resources", "Startup Jobs", "Log in", "Apply", "Founder Directory",
            "Footer", "Programs", "YC Program", "Startup School",
            "Work at a Startup", "Co-Founder Matching", "Startup Directory",
            "Startup Library", "Investors", "Demo Day", "Safe", "Hacker News",
            "Launch YC", "YC Deals", "Company", "YC Blog", "Contact", "Press",
            "People", "Careers", "Privacy Policy", "Notice at Collection",
            "Security", "Terms of Use", "Twitter", "Facebook", "Instagram",
            "LinkedIn", "Youtube", "See fewer options", "Search...",
            "Make something people want.", "Search for a title...",
        ) or line.startswith("Since 2005") or line.startswith("Do you know") or \
           line.startswith("Showing ") or line.startswith("© ") or \
           line.startswith("💎") or line.startswith("See all") or \
           line.startswith("All ") or line.startswith("YC Company"):
            i += 1
            continue

        # Skip batch/industry filter labels
        if re.match(r'^[SWFP]\d{2}\d*$', line) or re.match(r'^[SWFP]\d{2}✕$', line):
            i += 1
            continue
        if re.match(r'^\d+$', line):
            i += 1
            continue
        if line in ("B2B", "Education", "Fintech", "Consumer", "Healthcare",
                     "Industrials", "Real Estate and Construction", "Founder",
                     "Co-founder", "Co-founder & CEO", "CEO", "Co-founder & CTO",
                     "Batch"):
            i += 1
            continue

        # Try to match a founder entry:
        # Line 1: Name
        # Line 2: Role at Company
        # Line 3+: Batch(es) like S21, W22, etc.
        # Last line(s): Company name(s)
        role_pattern = re.compile(
            r'^(Founder|Co-[Ff]ounder|CEO|CTO|Co-Founder|Cofounder|Founder/CEO|'
            r'Founder/Co-CEO|Founder/CTO|Founder,\s*CEO|Founder,\s*CTO|'
            r'Co-Founder\s*&\s*CEO|Co-Founder\s*&\s*CTO|Co-[Ff]ounder\s*&\s*CRO|'
            r'Co-[Ff]ounder,\s*CEO|Co-[Ff]ounder,\s*CTO|Co-[Ff]ounder,\s*COO|'
            r'CEO\s*&\s*Co-Founder|CEO\s*&\s*Founder|VP\s+Product|Founder\s*&\s*CEO|'
            r'Founder\s*\+\s*CEO|Co-[Ff]ounder\s*/\s*CEO|Co-[Ff]ounder\s*/\s*CTO|'
            r'Founder\s*and\s*CTO)'
        )

        if i + 1 < len(lines) and (" at " in lines[i + 1] or role_pattern.match(lines[i + 1])):
            name = line
            role_line = lines[i + 1]

            # Extract role and company from "Role at Company"
            if " at " in role_line:
                parts = role_line.split(" at ", 1)
                role = parts[0].strip()
                company = parts[1].strip()
            else:
                role = role_line
                company = ""

            # Collect batches
            batches = []
            j = i + 2
            batch_pattern = re.compile(r'^[SWFP]\d{2}$')
            while j < len(lines) and batch_pattern.match(lines[j]):
                batches.append(lines[j])
                j += 1

            # Next line(s) are company names (skip them)
            while j < len(lines) and not batch_pattern.match(lines[j]) and \
                  " at " not in lines[j] and \
                  (j + 1 >= len(lines) or " at " not in lines[j + 1]) and \
                  not lines[j].startswith("Footer"):
                if not company:
                    company = lines[j]
                j += 1
                # But don't consume too many — max 3 company lines
                if j > i + 2 + len(batches) + 3:
                    break

            founders.append({
                "name": name,
                "company": company,
                "batches": ", ".join(batches),
            })
            i = j
        else:
            i += 1

    return founders


def main():
    if not RAW_TEXT.exists():
        print(f"Put the raw text in {RAW_TEXT}")
        sys.exit(1)

    text = RAW_TEXT.read_text()
    founders = parse_founders(text)

    # Deduplicate by name
    seen = set()
    unique = []
    for f in founders:
        if f["name"] not in seen:
            seen.add(f["name"])
            unique.append(f)

    # Write output
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT.open("w") as fp:
        fp.write(f"# YC Founder Target List — {len(unique)} founders\n")
        fp.write(f"# Format: Name | Company | Batch(es)\n")
        fp.write(f"# Generated from YC Founder Directory\n\n")
        for f in unique:
            fp.write(f"{f['name']} | {f['company']} | {f['batches']}\n")

    print(f"Wrote {len(unique)} founders to {OUTPUT}")


if __name__ == "__main__":
    main()
