"""Engage with YC founders from Target_List.txt.

For each founder from the target list:
1. Search X for "<Name> <Company>"
2. On "Latest" tab: like top 10 posts, LLM picks 3 best, reply to each
3. On "Top" tab: like top 10 posts, LLM picks 3 best, reply to each
4. On "People" tab: search company name → follow 10, search founder name → follow 10

Usage:
    uv run --with openai python scripts/target-engage.py --headed
    uv run --with openai python scripts/target-engage.py --headed --dry-run --max-founders 3
    uv run --with openai python scripts/target-engage.py --headed --start-from 50

Requires OPENAI_API_KEY in env or .env file.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from openai import OpenAI

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import like_in_place, tweet_reply
from x_browser.history import History

TARGET_LIST = Path.home() / ".config" / "x-browser" / "Target_List.txt"

PICK_POSTS_PROMPT = """\
You are helping decide which tweets to reply to. You will be given a list of tweets.

Pick the TOP 3 tweets that are best to reply to. Prefer tweets that:
- Are about startups, product launches, or industry insights
- Are conversational and invite discussion
- Are NOT retweets, ads, or low-effort posts

Return ONLY a JSON object: {"picks": [<index1>, <index2>, <index3>], "reasons": ["<why1>", "<why2>", "<why3>"]}
Use 0-based indices. If fewer than 3 good tweets exist, return fewer.
"""

REPLY_PROMPT = """\
You are replying to a tweet on X. Write a short reply (1-2 sentences, under 280 characters) that:
- Is respectful and positive in tone
- Carries the discussion forward with a thoughtful observation or question
- Stays generalist — no strong claims, no counter-arguments, no rigid opinions, no counter-facts
- Feels natural and conversational, not corporate or robotic
- Uses at least 2 emojis naturally woven into the reply
- Does not use hashtags

Reply with ONLY the tweet text, nothing else.
"""


def _load_api_key() -> str | None:
    key = os.environ.get("OPENAI_API_KEY")
    if key:
        return key
    for env_path in [
        Path(__file__).resolve().parent.parent / ".env",
        Path.home() / ".config" / "x-browser" / ".env",
    ]:
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                line = line.strip()
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip().strip("'\"")
    return None


def load_targets(start_from: int = 0, max_founders: int | None = None) -> list[dict]:
    if not TARGET_LIST.exists():
        print(f"\u274c Target list not found: {TARGET_LIST}", file=sys.stderr)
        sys.exit(1)

    targets = []
    for line in TARGET_LIST.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split("|")
        if len(parts) >= 2:
            targets.append({
                "name": parts[0].strip(),
                "company": parts[1].strip(),
                "batches": parts[2].strip() if len(parts) > 2 else "",
            })

    targets = targets[start_from:]
    if max_founders:
        targets = targets[:max_founders]
    return targets


def pick_posts(client: OpenAI, tweets: list[dict], count: int = 3) -> list[int]:
    """Use LLM to pick the top N tweets to reply to. Returns list of indices."""
    tweets_text = "\n".join(
        f"[{i}] @{t.get('author', '?')}: {t.get('text', '')[:200]}"
        for i, t in enumerate(tweets)
        if t.get("text")
    )
    if not tweets_text:
        return [0] if tweets else []

    response = client.chat.completions.create(
        model="gpt-5-nano",
        messages=[
            {"role": "system", "content": PICK_POSTS_PROMPT},
            {"role": "user", "content": tweets_text},
        ],
        max_completion_tokens=2000,
    )
    content = response.choices[0].message.content or ""
    try:
        match = re.search(r'\{[^}]+\}', content)
        if match:
            data = json.loads(match.group())
            picks = data.get("picks", [0])
            # Validate indices
            valid = [int(idx) for idx in picks if 0 <= int(idx) < len(tweets)]
            if valid:
                return valid[:count]
    except (json.JSONDecodeError, ValueError):
        pass
    return [0] if tweets else []


def generate_reply(client: OpenAI, tweet_text: str, author: str) -> str:
    response = client.chat.completions.create(
        model="gpt-5-nano",
        messages=[
            {"role": "system", "content": REPLY_PROMPT},
            {"role": "user", "content": f"Reply to this tweet by @{author}:\n\n{tweet_text}"},
        ],
        max_completion_tokens=2000,
    )
    content = response.choices[0].message.content
    return content.strip() if content else ""


async def _extract_articles_with_data(page) -> list[tuple[object, dict]]:
    results = []
    articles = await page.query_selector_all('article[data-testid="tweet"]')
    for article in articles:
        try:
            time_el = await article.query_selector("time")
            if not time_el:
                continue
            parent_a = await time_el.evaluate_handle("el => el.closest('a')")
            if not parent_a:
                continue
            href = await parent_a.get_attribute("href")
            if not href or "/status/" not in href:
                continue
            match = re.search(r"/status/(\d+)", href)
            if not match:
                continue

            tweet_id = match.group(1)
            url = f"https://x.com{href}"
            author = ""
            user_link = await article.query_selector('div[data-testid="User-Name"] a')
            if user_link:
                user_href = await user_link.get_attribute("href") or ""
                author = user_href.strip("/").split("/")[0]
            text = ""
            text_el = await article.query_selector('div[data-testid="tweetText"]')
            if text_el:
                text = (await text_el.inner_text()).strip()

            results.append((article, {
                "id": tweet_id, "url": url, "author": author, "text": text,
            }))
        except Exception:
            continue
    return results


async def like_and_reply_on_tab(
    page,
    tab_name: str,
    search_url: str,
    client: OpenAI,
    config: Config,
    stats: dict,
    likes_count: int,
    reply_count: int,
    dry_run: bool,
    replied_history: History | None = None,
) -> None:
    """Like top N posts and reply to the best M on a search tab."""
    print(f"\n   \U0001f4cb [{tab_name}] Loading...", file=sys.stderr)
    await page.goto(search_url, wait_until="domcontentloaded")
    await page.wait_for_timeout(4000)

    # Scroll once to load more tweets
    items = await _extract_articles_with_data(page)
    if len(items) < likes_count:
        await page.evaluate("window.scrollBy(0, 800)")
        await page.wait_for_timeout(2000)
        items = await _extract_articles_with_data(page)

    if not items:
        print(f"   \u274c [{tab_name}] No tweets found", file=sys.stderr)
        return

    # Like top N in-place
    tweet_data_list = []
    for article, data in items[:likes_count]:
        tweet_data_list.append(data)
        text_preview = (data["text"][:50] + "...") if len(data.get("text", "")) > 50 else data.get("text", "")

        if dry_run:
            print(f"   \u2764\ufe0f  [DRY RUN] Would like: {text_preview}", file=sys.stderr)
            stats["liked"] += 1
        else:
            result = await like_in_place(page, article, config=config)
            if result.get("liked"):
                stats["liked"] += 1
                print(f"   \u2764\ufe0f  Liked: {text_preview}", file=sys.stderr)
            elif result.get("already_liked"):
                print(f"   \u2705 Already liked: {text_preview}", file=sys.stderr)
            elif result.get("error"):
                print(f"   \u274c Like error: {result['error']}", file=sys.stderr)

    # Pick best posts to reply to
    posts_with_text = [d for d in tweet_data_list if d.get("text")]
    if not posts_with_text:
        print(f"   \u23ed\ufe0f  [{tab_name}] No text posts to reply to", file=sys.stderr)
        return

    try:
        picked_indices = pick_posts(client, posts_with_text, count=reply_count)
        print(f"   \U0001f3af [{tab_name}] LLM picked {len(picked_indices)} posts to reply to", file=sys.stderr)
    except Exception as e:
        print(f"   \u274c [{tab_name}] LLM pick failed: {e}", file=sys.stderr)
        picked_indices = [0]

    # Generate and post replies
    for pick_idx in picked_indices:
        chosen = posts_with_text[pick_idx]

        # Skip if already replied to this tweet
        if replied_history and chosen.get("id") and chosen["id"] in replied_history:
            print(f"   \u2705 [{tab_name}] Already replied to this tweet, skipping", file=sys.stderr)
            continue

        text_preview = (chosen["text"][:60] + "...") if len(chosen["text"]) > 60 else chosen["text"]
        print(f"   \U0001f3af [{tab_name}] Replying to: {text_preview}", file=sys.stderr)

        try:
            reply_text = generate_reply(client, chosen["text"], chosen["author"])
            if not reply_text:
                print(f"   \u23ed\ufe0f  [{tab_name}] Empty LLM reply, skipping", file=sys.stderr)
                continue
            print(f"   \U0001f4ac [{tab_name}] Generated: {reply_text}", file=sys.stderr)
        except Exception as e:
            print(f"   \u274c [{tab_name}] LLM reply failed: {e}", file=sys.stderr)
            continue

        if dry_run:
            print(f"   \U0001f4e4 [{tab_name}] [DRY RUN] Would reply to @{chosen['author']}", file=sys.stderr)
            stats["commented"] += 1
            if replied_history and chosen.get("id"):
                replied_history.add(chosen["id"])
        else:
            try:
                await tweet_reply(page, chosen["url"], reply_text, config=config)
                stats["commented"] += 1
                print(f"   \u2705 [{tab_name}] Replied to @{chosen['author']}!", file=sys.stderr)
                if replied_history and chosen.get("id"):
                    replied_history.add(chosen["id"])
            except Exception as e:
                print(f"   \u274c [{tab_name}] Reply failed: {e}", file=sys.stderr)

            # Go back to search after replying (since tweet_reply navigates away)
            await page.goto(search_url, wait_until="domcontentloaded")
            await page.wait_for_timeout(3000)


async def follow_people_on_tab(
    page,
    search_query: str,
    label: str,
    config: Config,
    stats: dict,
    follow_count: int,
    dry_run: bool,
) -> None:
    """Follow top N people from the People search tab."""
    encoded = search_query.replace(" ", "%20")
    search_url = f"https://x.com/search?q={encoded}&src=typed_query&f=user"

    print(f"\n   \U0001f465 [People \u2014 \"{search_query}\"] Loading...", file=sys.stderr)
    await page.goto(search_url, wait_until="domcontentloaded")
    await page.wait_for_timeout(4000)

    # Scroll to load more results
    if follow_count > 5:
        await page.evaluate("window.scrollBy(0, 800)")
        await page.wait_for_timeout(2000)

    # Find all follow buttons on the page (data-testid contains "-follow")
    follow_buttons = await page.query_selector_all('button[data-testid$="-follow"]')
    followed = 0

    for btn in follow_buttons:
        if followed >= follow_count:
            break

        try:
            btn_text = (await btn.inner_text()).strip()
            if btn_text != "Follow":
                continue

            # Get username — try to find nearby link with profile href
            username = ""
            cell = await btn.evaluate_handle("el => el.closest('div[data-testid=\"cellInnerDiv\"]') || el.parentElement.parentElement.parentElement")
            if cell:
                links = await cell.query_selector_all("a")
                for link in links:
                    href = await link.get_attribute("href") or ""
                    if href.startswith("/") and "/" not in href[1:] and len(href) > 1:
                        username = href.strip("/")
                        break
            if not username:
                testid = await btn.get_attribute("data-testid") or ""
                username = testid.replace("-follow", "") if testid.endswith("-follow") else "?"

            if dry_run:
                print(f"   \U0001f464 [DRY RUN] Would follow @{username or '?'}", file=sys.stderr)
                followed += 1
                stats["followed"] += 1
            else:
                await config.politeness_wait()
                await btn.click()
                await page.wait_for_timeout(1000)
                followed += 1
                stats["followed"] += 1
                print(f"   \U0001f464 Followed @{username}", file=sys.stderr)

        except Exception:
            continue

    if followed == 0:
        print(f"   \u274c [People \u2014 \"{search_query}\"] No follow buttons found", file=sys.stderr)
    else:
        print(f"   \u2705 [People \u2014 \"{search_query}\"] Followed {followed} accounts", file=sys.stderr)


async def main():
    parser = argparse.ArgumentParser(description="Engage with YC founders from target list")
    parser.add_argument("--max-founders", type=int, default=None, help="Max founders to process")
    parser.add_argument("--start-from", type=int, default=0, help="Start from this index")
    parser.add_argument("--likes-per-tab", type=int, default=10, help="Posts to like per tab (default: 10)")
    parser.add_argument("--replies-per-tab", type=int, default=3, help="Posts to reply to per tab (default: 3)")
    parser.add_argument("--follows-per-search", type=int, default=10, help="People to follow per search (default: 10)")
    parser.add_argument("--min-delay", type=float, default=None, help="Min delay between actions")
    parser.add_argument("--max-delay", type=float, default=None, help="Max delay between actions")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    parser.add_argument("--dry-run", action="store_true", help="Don't actually like/reply/follow")
    args = parser.parse_args()

    api_key = _load_api_key()
    if not api_key:
        print("\u274c OPENAI_API_KEY not found.", file=sys.stderr)
        sys.exit(1)

    client = OpenAI(api_key=api_key)

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    targets = load_targets(start_from=args.start_from, max_founders=args.max_founders)
    history = History("target-engage")
    replied_history = History("target-engage-replied")

    print(f"\U0001f3af Loaded {len(targets)} founders", file=sys.stderr)
    if args.dry_run:
        print(f"\U0001f4cb DRY RUN mode", file=sys.stderr)
    print(f"\u23f3 Politeness delay: {config.min_politeness_delay}s \u2013 {config.max_politeness_delay}s", file=sys.stderr)
    print(f"\U0001f4ca Per founder: {args.likes_per_tab} likes + {args.replies_per_tab} replies per tab, {args.follows_per_search} follows per search", file=sys.stderr)
    print("\u2500" * 60, file=sys.stderr)

    stats = {"founders_processed": 0, "liked": 0, "commented": 0, "followed": 0, "skipped": 0}

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page

        for i, target in enumerate(targets):
            founder_key = f"{target['name']}|{target['company']}"
            if founder_key in history:
                print(f"\n\u23ed\ufe0f  [{args.start_from + i}] Skip {target['name']} ({target['company']}) \u2014 done", file=sys.stderr)
                stats["skipped"] += 1
                continue

            print(f"\n{'=' * 60}", file=sys.stderr)
            print(f"\U0001f464 [{args.start_from + i}] {target['name']} \u2014 {target['company']} ({target['batches']})", file=sys.stderr)
            print(f"{'=' * 60}", file=sys.stderr)

            query = f"{target['name']} {target['company']}"
            encoded = query.replace(" ", "%20")

            # --- LATEST TAB: like 10, reply to 3 ---
            await like_and_reply_on_tab(
                page,
                tab_name="Latest",
                search_url=f"https://x.com/search?q={encoded}&src=typed_query&f=live",
                client=client,
                config=config,
                stats=stats,
                likes_count=args.likes_per_tab,
                reply_count=args.replies_per_tab,
                dry_run=args.dry_run,
                replied_history=replied_history,
            )

            # --- TOP TAB: like 10, reply to 3 ---
            await like_and_reply_on_tab(
                page,
                tab_name="Top",
                search_url=f"https://x.com/search?q={encoded}&src=typed_query",
                client=client,
                config=config,
                stats=stats,
                likes_count=args.likes_per_tab,
                reply_count=args.replies_per_tab,
                dry_run=args.dry_run,
                replied_history=replied_history,
            )

            # --- PEOPLE TAB: search company name → follow 10 ---
            await follow_people_on_tab(
                page,
                search_query=target["company"],
                label="company",
                config=config,
                stats=stats,
                follow_count=args.follows_per_search,
                dry_run=args.dry_run,
            )

            # --- PEOPLE TAB: search founder name → follow 10 ---
            await follow_people_on_tab(
                page,
                search_query=target["name"],
                label="founder",
                config=config,
                stats=stats,
                follow_count=args.follows_per_search,
                dry_run=args.dry_run,
            )

            history.add(founder_key)
            stats["founders_processed"] += 1

            # Brief pause between founders
            await page.goto("https://x.com/home", wait_until="domcontentloaded")
            await page.wait_for_timeout(2000)

    print(f"\n{'=' * 60}", file=sys.stderr)
    print(f"\u2705 Done!", file=sys.stderr)
    print(f"   \U0001f464 Founders processed: {stats['founders_processed']}", file=sys.stderr)
    print(f"   \u23ed\ufe0f  Skipped: {stats['skipped']}", file=sys.stderr)
    print(f"   \u2764\ufe0f  Liked: {stats['liked']}", file=sys.stderr)
    print(f"   \U0001f4ac Commented: {stats['commented']}", file=sys.stderr)
    print(f"   \U0001f465 Followed: {stats['followed']}", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
