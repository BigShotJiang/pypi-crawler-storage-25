# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `5`

## Winner
- Config: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Score: `96`
- TPS / TTFT / PPL: `71.4` / `1791.8 ms` / `7.79`

## Quick Wow
- Recommendation ready in one run: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `medium` (top-2 gap: `2.0` points, `2.08%`)

## Stability
- Confidence: `medium`
- Top-2 gap: `2.0` points (`2.08%` of winner score)
- Notes: Winner has moderate margin; repeat run recommended for audit.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `15.0`
- Winner delta TPS: `22.10000000000001`
- Winner delta TPS p95: `23.60000000000001`
- Winner delta TTFT(ms): `-807.2`
- Winner delta TTFT p95(ms): `-908.0`
- Winner delta PPL: `0.8499999999999996`

## Agent Smoke
- Pass rate: `1/5 (0.2)`
- Diagnosis: `model_limited`
- Status: `not_agent_ready`
- Failed checks: `struct_json_1, single_tool_1, multi_tool_1, tool_args_1`
- Harness errors: `0` parse-failures: `4`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 16 --trials 5
```
