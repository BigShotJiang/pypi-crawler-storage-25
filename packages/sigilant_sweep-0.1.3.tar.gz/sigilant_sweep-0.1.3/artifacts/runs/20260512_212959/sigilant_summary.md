# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `A10G`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `ranking`

## Prompt Provenance
- Source: `default`
- Chars: `None`
- Tokens (est): `None`
- SHA12: `None`

## Winner
- Config: `GPTQ4_MARLIN · ctx:16384 · kv:k16v16 · long`
- Score: `97`
- TPS / TTFT / PPL: `181.0` / `105.1 ms` / `1.85`

## Quick Wow
- Recommendation ready in one run: `GPTQ4_MARLIN · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `medium` (top-2 gap: `4.00` points, `4.12%`)

## Stability
- Confidence: `medium`
- Top-2 gap: `4.00` points (`4.12%` of winner score)
- Notes: Winner has moderate margin; repeat run recommended for audit.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `44.00`
- Winner delta TPS: `122.40`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `-33.1`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `-0.90`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `4.00` points (`4.12%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `4.12%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware a10g --configs 16 --trials 1 --score-profile balanced
```
