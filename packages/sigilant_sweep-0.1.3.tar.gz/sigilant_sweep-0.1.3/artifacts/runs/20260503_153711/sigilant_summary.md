# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `A10G`
- Trials: `5`
- Score profile: `quality`

## Winner
- Config: `Q4_K_M · ctx:8192 · kv:k16v16 · default`
- Score: `96`
- TPS / TTFT / PPL: `66.3` / `1930.1 ms` / `7.12`

## Quick Wow
- Recommendation ready in one run: `Q4_K_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `low` (top-2 gap: `1.00` points, `1.04%`)

## Stability
- Confidence: `low`
- Top-2 gap: `1.00` points (`1.04%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `10.00`
- Winner delta TPS: `16.10`
- Winner delta TPS p95: `16.80`
- Winner delta TTFT(ms): `-619.1`
- Winner delta TTFT p95(ms): `-627.5`
- Winner delta PPL: `0.18`

## Confidence Inputs
- Target: `medium`
- Initial trials: `5`
- Top-2 gap before: `1.00` points (`1.04%`)
- Top-2 variance proxy before: `1.69%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `1.04%`
- Top-2 variance proxy after: `1.69%`

## Agent Smoke
- Pass rate: `3/5 (60.0%)`
- Diagnosis: `mixed`
- Status: `partial_agent_readiness`
- Failed checks: `multi_tool_1, tool_args_1`
- Harness errors: `0` parse-failures: `2`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware a10g --configs 16 --trials 5 --score-profile quality
```
