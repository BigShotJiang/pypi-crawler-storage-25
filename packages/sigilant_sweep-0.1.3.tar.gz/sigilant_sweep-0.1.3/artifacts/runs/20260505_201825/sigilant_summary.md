# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `A10G`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `depth_profile`

## Prompt Provenance
- Source: `/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_30k_prompt.txt`
- Chars: `127887`
- Tokens (est): `31972`
- SHA12: `310944509276`

## Winner
- Config: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Score: `99`
- TPS / TTFT / PPL: `39.5` / `1545.6 ms` / `3.05`

## Quick Wow
- Recommendation ready in one run: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `medium` (top-2 gap: `4.00` points, `4.04%`)

## Stability
- Confidence: `medium`
- Top-2 gap: `4.00` points (`4.04%` of winner score)
- Notes: Winner has moderate margin; repeat run recommended for audit.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `0.00`
- Winner delta TPS: `0.00`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `0.0`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.00`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `4.00` points (`4.04%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `4.04%`
- Top-2 variance proxy after: `n/a%`

## Context Depth Profile
- Note: These depth passes are workload-specific and not directly comparable as one ranking.
- Bucket winners: `best_at_8k=FP16_BASELINE · ctx:16384 · kv:k16v16 · long` · `best_at_14k=None` · `best_at_28k=FP16_BASELINE · ctx:32768 · kv:k8v8 · long`
- `8k` prompt: winner=`FP16_BASELINE · ctx:16384 · kv:k16v16 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_8k_prompt.txt`
- `14k` prompt: winner=`None` error=`RuntimeError: Modal job returned no results — check the output above for errors.` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_14k_prompt.txt`
- `28k` prompt: winner=`FP16_BASELINE · ctx:32768 · kv:k8v8 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_28k_prompt.txt`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware a10g --configs 4 --trials 1 --score-profile balanced
```
