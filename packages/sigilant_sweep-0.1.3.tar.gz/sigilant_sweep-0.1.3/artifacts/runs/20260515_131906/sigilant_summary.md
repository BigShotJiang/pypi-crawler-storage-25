# Sigilant Runner Summary

- Model: `Qwen/Qwen2.5-1.5B-Instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `4`
- Score profile: `balanced`
- Benchmark mode: `ranking`

## Prompt Provenance
- Source: `default`
- Chars: `None`
- Tokens (est): `None`
- SHA12: `None`

## Winner
- Config: `Q5_K_M · ctx:8192 · kv:k16v16 · default`
- Score: `98`
- TPS / TTFT / PPL: `57.6` / `2222.3 ms` / `13.59`

## Quick Wow
- Recommendation ready in one run: `Q5_K_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `low` (top-2 gap: `0.00` points, `0.00%`)

## Stability
- Confidence: `low`
- Top-2 gap: `0.00` points (`0.00%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `4.00`
- Winner delta TPS: `4.80`
- Winner delta TPS p95: `4.30`
- Winner delta TTFT(ms): `-202.2`
- Winner delta TTFT p95(ms): `-208.7`
- Winner delta PPL: `0.20`

## Confidence Inputs
- Target: `medium`
- Initial trials: `4`
- Top-2 gap before: `0.00` points (`0.00%`)
- Top-2 variance proxy before: `1.04%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `0.00%`
- Top-2 variance proxy after: `1.04%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model Qwen/Qwen2.5-1.5B-Instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 16 --trials 4 --score-profile balanced
```
