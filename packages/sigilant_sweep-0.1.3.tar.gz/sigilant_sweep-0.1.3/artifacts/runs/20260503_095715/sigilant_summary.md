# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `A10`
- Trials: `10`

## Winner
- Config: `IQ3_M · ctx:16384 · kv:k8v8 · default`
- Score: `96`
- TPS / TTFT / PPL: `69.1` / `1853.2 ms` / `7.79`

## Quick Wow
- Recommendation ready in one run: `IQ3_M · ctx:16384 · kv:k8v8 · default`
- Stability confidence:
  `low` (top-2 gap: `1.00` points, `1.04%`)

## Stability
- Confidence: `low`
- Top-2 gap: `1.00` points (`1.04%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `13.00`
- Winner delta TPS: `20.10`
- Winner delta TPS p95: `19.90`
- Winner delta TTFT(ms): `-757.4`
- Winner delta TTFT p95(ms): `-733.6`
- Winner delta PPL: `0.85`

## Confidence Inputs
- Target: `medium`
- Initial trials: `10`
- Top-2 gap before: `2.00` points (`2.08%`)
- Top-2 variance proxy before: `2.65%`
- Replay triggered: `True`
- Replay reason: `gap_pct<2.5`
- Replay extra trials: `6`
- Replay outcome: `applied`
- Top-2 gap after: `1.04%`
- Top-2 variance proxy after: `2.87%`

## Agent Smoke
- Pass rate: `3/5 (60.0%)`
- Diagnosis: `mixed`
- Status: `partial_agent_readiness`
- Failed checks: `multi_tool_1, inj_resist_1`
- Harness errors: `0` parse-failures: `2`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware a10 --configs 16 --trials 10
```
