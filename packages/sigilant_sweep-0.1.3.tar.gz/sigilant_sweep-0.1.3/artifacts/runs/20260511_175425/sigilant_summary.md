# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `A10G`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `depth_profile`

## Prompt Provenance
- Source: `default`
- Chars: `None`
- Tokens (est): `None`
- SHA12: `None`

## Winner
- Config: `FP16_BASELINE · ctx:8192 · kv:k16v16 · default`
- Score: `100`
- TPS / TTFT / PPL: `53.8` / `1503.0 ms` / `2.88`

## Quick Wow
- Recommendation ready in one run: `FP16_BASELINE · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `low` (top-2 gap: `1.00` points, `1.00%`)

## Stability
- Confidence: `low`
- Top-2 gap: `1.00` points (`1.00%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `0.00`
- Winner delta TPS: `0.00`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `0.0`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.00`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `1.00` points (`1.00%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `1.00%`
- Top-2 variance proxy after: `n/a%`

## Context Depth Profile
- Note: These depth passes are workload-specific and not directly comparable as one ranking.
- Bucket winners: `best_at_8k=FP16_BASELINE · ctx:8192 · kv:k16v16 · default` · `best_at_14k=FP16_BASELINE · ctx:16384 · kv:k8v8 · default` · `best_at_28k=None`
- `8k` prompt: winner=`FP16_BASELINE · ctx:8192 · kv:k16v16 · default` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_8k_prompt.txt`
- `14k` prompt: winner=`FP16_BASELINE · ctx:16384 · kv:k8v8 · default` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_14k_prompt.txt`
- `28k` prompt: winner=`None` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_28k_prompt.txt`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware a10g --configs 4 --trials 1 --score-profile balanced
```
