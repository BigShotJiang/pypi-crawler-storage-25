# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `A10G`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `depth_profile`

## Prompt Provenance
- Source: `default`
- Chars: `None`
- Tokens (est): `None`
- SHA12: `None`

## Winner
- Config: `AWQ4_MARLIN · ctx:16384 · kv:k16v16 · long`
- Score: `86`
- TPS / TTFT / PPL: `72.9` / `1205.1 ms` / `3.03`

## Quick Wow
- Recommendation ready in one run: `AWQ4_MARLIN · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `low` (top-2 gap: `1.00` points, `1.16%`)

## Stability
- Confidence: `low`
- Top-2 gap: `1.00` points (`1.16%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `19.00`
- Winner delta TPS: `33.60`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `-59.8`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.01`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `1.00` points (`1.16%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `1.16%`
- Top-2 variance proxy after: `n/a%`

## Context Depth Profile
- Note: These depth passes are workload-specific and not directly comparable as one ranking.
- Bucket winners: `best_at_8k=AWQ4_MARLIN · ctx:16384 · kv:k16v16 · long` · `best_at_14k=AWQ4_MARLIN · ctx:16384 · kv:k16v16 · long` · `best_at_28k=INT8_W8A8 · ctx:32768 · kv:k8v8 · long`
- `8k` prompt: winner=`AWQ4_MARLIN · ctx:16384 · kv:k16v16 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_8k_prompt.txt`
- `14k` prompt: winner=`AWQ4_MARLIN · ctx:16384 · kv:k16v16 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_14k_prompt.txt`
- `28k` prompt: winner=`INT8_W8A8 · ctx:32768 · kv:k8v8 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_28k_prompt.txt`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware a10g --configs 16 --trials 1 --score-profile balanced
```
