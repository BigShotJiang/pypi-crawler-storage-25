# Sigilant Runner Summary

- Model: `Qwen/Qwen2.5-1.5B-Instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `ranking`

## Prompt Provenance
- Source: `default`
- Chars: `None`
- Tokens (est): `None`
- SHA12: `None`

## Winner
- Config: `Q4_K_M · ctx:16384 · kv:k16v16 · long`
- Score: `97`
- TPS / TTFT / PPL: `73.3` / `1745.8 ms` / `14.32`

## Quick Wow
- Recommendation ready in one run: `Q4_K_M · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `low` (top-2 gap: `0.00` points, `0.00%`)

## Stability
- Confidence: `low`
- Top-2 gap: `0.00` points (`0.00%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `Q8_0 · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `4.00`
- Winner delta TPS: `4.90`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `-137.0`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.19`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `0.00` points (`0.00%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `0.00%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model Qwen/Qwen2.5-1.5B-Instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 16 --trials 1 --score-profile balanced
```
