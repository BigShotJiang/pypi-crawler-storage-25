# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `L4`
- Trials: `1`
- Score profile: `quality`

## Prompt Provenance
- Source: `/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_8k_prompt.txt`
- Chars: `33515`
- Tokens (est): `8379`
- SHA12: `0bf93de7cc8e`

## Winner
- Config: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Score: `99`
- TPS / TTFT / PPL: `34.7` / `2111.9 ms` / `3.07`

## Quick Wow
- Recommendation ready in one run: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `medium` (top-2 gap: `4.00` points, `4.04%`)

## Stability
- Confidence: `medium`
- Top-2 gap: `4.00` points (`4.04%` of winner score)
- Notes: Winner has moderate margin; repeat run recommended for audit.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `0.00`
- Winner delta TPS: `0.00`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `0.0`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.00`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `4.00` points (`4.04%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `4.04%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware l4 --configs 16 --trials 1 --score-profile quality
```
