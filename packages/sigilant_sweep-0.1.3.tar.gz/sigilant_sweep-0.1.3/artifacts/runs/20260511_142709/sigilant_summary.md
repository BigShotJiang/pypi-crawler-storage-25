# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `A10G`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `ranking`

## Prompt Provenance
- Source: `prompts/hard_quality_28k_prompt.txt`
- Chars: `112989`
- Tokens (est): `28247`
- SHA12: `0c134fe10250`

## Winner
- Config: `INT8_W8A8 · ctx:32768 · kv:k8v8 · long`
- Score: `100`
- TPS / TTFT / PPL: `27.3` / `5550.5 ms` / `2.84`

## Quick Wow
- Recommendation ready in one run: `INT8_W8A8 · ctx:32768 · kv:k8v8 · long`
- Stability confidence:
  `high` (top-2 gap: `13.00` points, `13.00%`)

## Stability
- Confidence: `high`
- Top-2 gap: `13.00` points (`13.00%` of winner score)
- Notes: Winner separated clearly from runner-up.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:32768 · kv:k8v8 · long`
- Winner delta score: `13.00`
- Winner delta TPS: `4.30`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `-1740.7`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `-0.17`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `13.00` points (`13.00%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `13.00%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware a10g --configs 8 --trials 1 --score-profile balanced
```
