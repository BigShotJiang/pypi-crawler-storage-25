# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `A10G`
- Trials: `5`
- Score profile: `quality`

## Winner
- Config: `Q4_K_M · ctx:8192 · kv:k16v16 · default`
- Score: `94`
- TPS / TTFT / PPL: `58.5` / `2190.4 ms` / `7.12`

## Quick Wow
- Recommendation ready in one run: `Q4_K_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `low` (top-2 gap: `0.00` points, `0.00%`)

## Stability
- Confidence: `low`
- Top-2 gap: `0.00` points (`0.00%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `10.00`
- Winner delta TPS: `15.70`
- Winner delta TPS p95: `17.40`
- Winner delta TTFT(ms): `-798.6`
- Winner delta TTFT p95(ms): `-490.9`
- Winner delta PPL: `0.20`

## Confidence Inputs
- Target: `medium`
- Initial trials: `5`
- Top-2 gap before: `1.00` points (`1.06%`)
- Top-2 variance proxy before: `2.16%`
- Replay triggered: `True`
- Replay reason: `gap_pct<2.5`
- Replay extra trials: `8`
- Replay outcome: `applied`
- Top-2 gap after: `0.00%`
- Top-2 variance proxy after: `5.60%`

## Agent Smoke
- Pass rate: `4/5 (80.0%)`
- Diagnosis: `config_ready_for_smoke`
- Status: `smoke_pass`
- Failed checks: `multi_tool_1`
- Harness errors: `0` parse-failures: `1`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware a10g --configs 16 --trials 5 --score-profile quality
```
