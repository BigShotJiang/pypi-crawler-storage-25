# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `15`

## Winner
- Config: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Score: `96`
- TPS / TTFT / PPL: `70.6` / `1814.0 ms` / `7.79`

## Quick Wow
- Recommendation ready in one run: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `medium` (top-2 gap: `2.00` points, `2.08%`)

## Stability
- Confidence: `medium`
- Top-2 gap: `2.00` points (`2.08%` of winner score)
- Notes: Winner has moderate margin; repeat run recommended for audit.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `15.00`
- Winner delta TPS: `22.50`
- Winner delta TPS p95: `23.00`
- Winner delta TTFT(ms): `-845.5`
- Winner delta TTFT p95(ms): `-913.8`
- Winner delta PPL: `0.85`

## Agent Smoke
- Pass rate: `3/5 (60.0%)`
- Diagnosis: `mixed`
- Status: `partial_agent_readiness`
- Failed checks: `multi_tool_1, inj_resist_1`
- Harness errors: `0` parse-failures: `2`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 16 --trials 15
```
