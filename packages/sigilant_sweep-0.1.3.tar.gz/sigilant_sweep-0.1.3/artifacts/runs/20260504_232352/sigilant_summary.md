# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `L4`
- Trials: `1`
- Score profile: `quality`

## Prompt Provenance
- Source: `/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_30k_prompt.txt`
- Chars: `127887`
- Tokens (est): `31972`
- SHA12: `310944509276`

## Winner
- Config: `FP16_BASELINE · ctx:16384 · kv:k8v8 · default`
- Score: `100`
- TPS / TTFT / PPL: `22.3` / `7290.7 ms` / `3.05`

## Quick Wow
- Recommendation ready in one run: `FP16_BASELINE · ctx:16384 · kv:k8v8 · default`
- Stability confidence:
  `low` (top-2 gap: `0.00` points, `0.00%`)

## Stability
- Confidence: `low`
- Top-2 gap: `0.00` points (`0.00%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:16384 · kv:k8v8 · default`
- Winner delta score: `0.00`
- Winner delta TPS: `0.00`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `0.0`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.00`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `0.00` points (`0.00%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `0.00%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware l4 --configs 16 --trials 1 --score-profile quality
```
