# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `L4`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `ranking`

## Prompt Provenance
- Source: `prompts/hard_quality_8k_prompt.txt`
- Chars: `17918`
- Tokens (est): `4479`
- SHA12: `a4757d771ce4`

## Winner
- Config: `GPTQ4_MARLIN · ctx:16384 · kv:k16v16 · long`
- Score: `92`
- TPS / TTFT / PPL: `82.3` / `1120.7 ms` / `1.85`

## Quick Wow
- Recommendation ready in one run: `GPTQ4_MARLIN · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `low` (top-2 gap: `1.00` points, `1.09%`)

## Stability
- Confidence: `low`
- Top-2 gap: `1.00` points (`1.09%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `31.00`
- Winner delta TPS: `40.20`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `52.9`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `-0.95`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `1.00` points (`1.09%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `1.09%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-sweep run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware l4 --configs 16 --trials 1 --score-profile balanced
```
