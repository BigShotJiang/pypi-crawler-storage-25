# Sigilant Runner Summary

- Model: `Qwen/Qwen2.5-1.5B-Instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `ranking`

## Prompt Provenance
- Source: `default`
- Chars: `None`
- Tokens (est): `None`
- SHA12: `None`

## Winner
- Config: `Q8_0 · ctx:16384 · kv:k8v8 · default`
- Score: `100`
- TPS / TTFT / PPL: `37.3` / `3432.2 ms` / `13.39`

## Quick Wow
- Recommendation ready in one run: `Q8_0 · ctx:16384 · kv:k8v8 · default`
- Stability confidence:
  `high` (top-2 gap: `100.00` points, `100.00%`)

## Stability
- Confidence: `high`
- Top-2 gap: `100.00` points (`100.00%` of winner score)
- Notes: Winner separated clearly from runner-up.

## Baseline Compare
- Baseline: `Q8_0 · ctx:16384 · kv:k8v8 · default`
- Winner delta score: `0.00`
- Winner delta TPS: `0.00`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `0.0`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.00`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `100.00` points (`100.00%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `100.00%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model Qwen/Qwen2.5-1.5B-Instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 1 --trials 1 --score-profile balanced
```
