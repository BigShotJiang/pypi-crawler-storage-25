# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `A10G`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `ranking`

## Prompt Provenance
- Source: `prompts/hard_quality_8k_prompt.txt`
- Chars: `17918`
- Tokens (est): `4480`
- SHA12: `a4757d771ce4`

## Winner
- Config: `INT8_W8A8 · ctx:16384 · kv:k16v16 · long`
- Score: `96`
- TPS / TTFT / PPL: `59.3` / `830.2 ms` / `2.88`

## Quick Wow
- Recommendation ready in one run: `INT8_W8A8 · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `high` (top-2 gap: `6.00` points, `6.25%`)

## Stability
- Confidence: `high`
- Top-2 gap: `6.00` points (`6.25%` of winner score)
- Notes: Winner separated clearly from runner-up.

## Baseline Compare
- Baseline: `INT8_W8A8 · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `0.00`
- Winner delta TPS: `0.00`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `0.0`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.00`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `6.00` points (`6.25%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `6.25%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware a10g --configs 4 --trials 1 --score-profile balanced
```
