# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `5`

## Winner
- Config: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Score: `96`
- TPS / TTFT / PPL: `58.2` / `2199.1 ms` / `7.79`

## Quick Wow
- Recommendation ready in one run: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `medium` (top-2 gap: `4.0` points, `4.17%`)

## Stability
- Confidence: `medium`
- Top-2 gap: `4.0` points (`4.17%` of winner score)
- Notes: Winner has moderate margin; repeat run recommended for audit.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `14.0`
- Winner delta TPS: `17.400000000000006`
- Winner delta TPS p95: `18.6`
- Winner delta TTFT(ms): `-939.3000000000002`
- Winner delta TTFT p95(ms): `-804.7000000000003`
- Winner delta PPL: `0.8700000000000001`

## Agent Smoke
- Pass rate: `1/5 (0.2)`
- Diagnosis: `model_limited`
- Status: `not_agent_ready`
- Failed checks: `struct_json_1, single_tool_1, multi_tool_1, tool_args_1`
- Harness errors: `0` parse-failures: `4`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 16 --trials 5
```
