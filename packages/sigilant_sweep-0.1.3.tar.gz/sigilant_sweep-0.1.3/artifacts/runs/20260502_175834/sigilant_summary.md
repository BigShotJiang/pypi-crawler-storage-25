# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `5`

## Winner
- Config: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Score: `94`
- TPS / TTFT / PPL: `67.5` / `1896.2 ms` / `7.79`

## Quick Wow
- Recommendation ready in one run: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `low` (top-2 gap: `1.0` points, `1.06%`)

## Stability
- Confidence: `low`
- Top-2 gap: `1.0` points (`1.06%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `12.0`
- Winner delta TPS: `20.0`
- Winner delta TPS p95: `21.699999999999996`
- Winner delta TTFT(ms): `-800.2`
- Winner delta TTFT p95(ms): `-471.0`
- Winner delta PPL: `0.8499999999999996`

## Agent Smoke
- Pass rate: `1/5 (0.2)`
- Diagnosis: `model_limited`
- Status: `not_agent_ready`
- Failed checks: `struct_json_1, single_tool_1, multi_tool_1, tool_args_1`
- Harness errors: `0` parse-failures: `4`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 16 --trials 5
```
