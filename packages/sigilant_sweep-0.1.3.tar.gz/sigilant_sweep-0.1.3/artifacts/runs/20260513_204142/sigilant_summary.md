# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `L4`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `ranking`

## Prompt Provenance
- Source: `runtime:trial_logs`
- Chars: `None`
- Tokens (est): `51`
- SHA12: `None`

## Winner
- Config: `GPTQ4_MARLIN · ctx:16384 · kv:k16v16 · long`
- Score: `96`
- TPS / TTFT / PPL: `179.9` / `146.5 ms` / `1.85`

## Quick Wow
- Recommendation ready in one run: `GPTQ4_MARLIN · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `medium` (top-2 gap: `2.00` points, `2.08%`)

## Stability
- Confidence: `medium`
- Top-2 gap: `2.00` points (`2.08%` of winner score)
- Notes: Winner has moderate margin; repeat run recommended for audit.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `43.00`
- Winner delta TPS: `121.80`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `-29.8`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `-0.95`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `2.00` points (`2.08%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `2.08%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware l4 --configs 16 --trials 1 --score-profile balanced
```
