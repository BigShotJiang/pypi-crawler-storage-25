# Sigilant Runner Summary

- Model: `anhbn/Phi-3.5-mini-instruct-quantized.w8a8`
- Backend/Engine: `modal` / `vllm`
- Hardware: `A10G`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `depth_profile`

## Prompt Provenance
- Source: `/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_30k_prompt.txt`
- Chars: `127887`
- Tokens (est): `31972`
- SHA12: `310944509276`

## Winner
- Config: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Score: `100`
- TPS / TTFT / PPL: `36.0` / `1771.5 ms` / `3.02`

## Quick Wow
- Recommendation ready in one run: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `high` (top-2 gap: `5.00` points, `5.00%`)

## Stability
- Confidence: `high`
- Top-2 gap: `5.00` points (`5.00%` of winner score)
- Notes: Winner separated clearly from runner-up.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `0.00`
- Winner delta TPS: `0.00`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `0.0`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.00`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `5.00` points (`5.00%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `5.00%`
- Top-2 variance proxy after: `n/a%`

## Context Depth Profile
- Note: These depth passes are workload-specific and not directly comparable as one ranking.
- Bucket winners: `best_at_8k=FP16_BASELINE · ctx:16384 · kv:k16v16 · long` · `best_at_14k=FP16_BASELINE · ctx:16384 · kv:k16v16 · long` · `best_at_28k=FP16_BASELINE · ctx:32768 · kv:k8v8 · long`
- `8k` prompt: winner=`FP16_BASELINE · ctx:16384 · kv:k16v16 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_8k_prompt.txt`
- `14k` prompt: winner=`FP16_BASELINE · ctx:16384 · kv:k16v16 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_14k_prompt.txt`
- `28k` prompt: winner=`FP16_BASELINE · ctx:32768 · kv:k8v8 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_28k_prompt.txt`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model anhbn/Phi-3.5-mini-instruct-quantized.w8a8 --backend modal --engine vllm --hardware a10g --configs 4 --trials 1 --score-profile balanced
```
