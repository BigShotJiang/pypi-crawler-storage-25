# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `L4`
- Trials: `1`
- Score profile: `quality`
- Benchmark mode: `depth_profile`

## Prompt Provenance
- Source: `/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_30k_prompt.txt`
- Chars: `127887`
- Tokens (est): `31972`
- SHA12: `310944509276`

## Quick Wow
- Recommendation unavailable
## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `n/a` points (`n/a%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `n/a%`
- Top-2 variance proxy after: `n/a%`

## Context Depth Profile
- Note: These depth passes are workload-specific and not directly comparable as one ranking.
- `8k` prompt: winner=`FP16_BASELINE · ctx:16384 · kv:k8v8 · default` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_8k_prompt.txt`
- `14k` prompt: winner=`FP16_BASELINE · ctx:16384 · kv:k16v16 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_14k_prompt.txt`
- `32k` prompt: winner=`None` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_30k_prompt.txt`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware l4 --configs 16 --trials 1 --score-profile quality
```
