# Sigilant Runner Summary

- Model: `Qwen/Qwen2.5-1.5B-Instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `5`

## Winner
- Config: `Q5_K_M · ctx:8192 · kv:k16v16 · default`
- Score: `98`
- TPS / TTFT / PPL: `58.6` / `2184.8 ms` / `13.59`

## Quick Wow
- Recommendation ready in one run: `Q5_K_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `low` (top-2 gap: `1.0` points, `1.02%`)

## Stability
- Confidence: `low`
- Top-2 gap: `1.0` points (`1.02%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `4.0`
- Winner delta TPS: `4.5`
- Winner delta TPS p95: `4.399999999999999`
- Winner delta TTFT(ms): `-179.19999999999982`
- Winner delta TTFT p95(ms): `-202.0`
- Winner delta PPL: `0.1999999999999993`

## Agent Smoke
- Pass rate: `1/5 (0.2)`
- Diagnosis: `model_limited`
- Status: `not_agent_ready`
- Failed checks: `struct_json_1, single_tool_1, multi_tool_1, tool_args_1`
- Harness errors: `0` parse-failures: `4`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model Qwen/Qwen2.5-1.5B-Instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 16 --trials 5
```
