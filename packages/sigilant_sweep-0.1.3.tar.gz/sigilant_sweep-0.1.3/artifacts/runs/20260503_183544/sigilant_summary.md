# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `L4`
- Trials: `5`
- Score profile: `quality`

## Winner
- Config: `FP16 · ctx:16384 · kv:k16v16 · long`
- Score: `100`
- TPS / TTFT / PPL: `57.1` / `896.8 ms` / `3.06`

## Quick Wow
- Recommendation ready in one run: `FP16 · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `low` (top-2 gap: `0.00` points, `0.00%`)

## Stability
- Confidence: `low`
- Top-2 gap: `0.00` points (`0.00%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `FP16 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `0.00`
- Winner delta TPS: `0.00`
- Winner delta TPS p95: `0.00`
- Winner delta TTFT(ms): `0.0`
- Winner delta TTFT p95(ms): `0.0`
- Winner delta PPL: `0.00`

## Confidence Inputs
- Target: `medium`
- Initial trials: `5`
- Top-2 gap before: `0.00` points (`0.00%`)
- Top-2 variance proxy before: `0.06%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `0.00%`
- Top-2 variance proxy after: `0.06%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware l4 --configs 16 --trials 5 --score-profile quality
```
