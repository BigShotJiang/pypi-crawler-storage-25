# Sigilant Runner Summary

- Model: `Qwen/Qwen2.5-1.5B-Instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `ranking`

## Prompt Provenance
- Source: `default`
- Chars: `None`
- Tokens (est): `None`
- SHA12: `None`

## Winner
- Config: `Q5_K_M · ctx:8192 · kv:k16v16 · default`
- Score: `99`
- TPS / TTFT / PPL: `68.1` / `1879.2 ms` / `13.61`

## Quick Wow
- Recommendation ready in one run: `Q5_K_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `medium` (top-2 gap: `2.00` points, `2.02%`)

## Stability
- Confidence: `medium`
- Top-2 gap: `2.00` points (`2.02%` of winner score)
- Notes: Winner has moderate margin; repeat run recommended for audit.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `7.00`
- Winner delta TPS: `8.40`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `-265.8`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `0.19`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `2.00` points (`2.02%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `2.02%`
- Top-2 variance proxy after: `n/a%`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model Qwen/Qwen2.5-1.5B-Instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 16 --trials 1 --score-profile balanced
```
