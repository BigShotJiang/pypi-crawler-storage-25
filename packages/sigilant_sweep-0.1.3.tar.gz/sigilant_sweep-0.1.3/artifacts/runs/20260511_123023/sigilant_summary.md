# Sigilant Runner Summary

- Model: `microsoft/Phi-3.5-mini-instruct`
- Backend/Engine: `modal` / `vllm`
- Hardware: `A10G`
- Trials: `1`
- Score profile: `balanced`
- Benchmark mode: `depth_profile`

## Prompt Provenance
- Source: `default`
- Chars: `None`
- Tokens (est): `None`
- SHA12: `None`

## Winner
- Config: `INT8_W8A8 · ctx:16384 · kv:k16v16 · long`
- Score: `99`
- TPS / TTFT / PPL: `44.4` / `1323.5 ms` / `2.90`

## Quick Wow
- Recommendation ready in one run: `INT8_W8A8 · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `high` (top-2 gap: `6.00` points, `6.06%`)

## Stability
- Confidence: `high`
- Top-2 gap: `6.00` points (`6.06%` of winner score)
- Notes: Winner separated clearly from runner-up.

## Baseline Compare
- Baseline: `FP16_BASELINE · ctx:16384 · kv:k16v16 · long`
- Winner delta score: `15.00`
- Winner delta TPS: `8.40`
- Winner delta TPS p95: `n/a`
- Winner delta TTFT(ms): `-453.3`
- Winner delta TTFT p95(ms): `n/a`
- Winner delta PPL: `-0.16`

## Confidence Inputs
- Target: `medium`
- Initial trials: `1`
- Top-2 gap before: `6.00` points (`6.06%`)
- Top-2 variance proxy before: `n/a%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `6.06%`
- Top-2 variance proxy after: `n/a%`

## Context Depth Profile
- Note: These depth passes are workload-specific and not directly comparable as one ranking.
- Bucket winners: `best_at_8k=INT8_W8A8 · ctx:16384 · kv:k16v16 · long` · `best_at_14k=INT8_W8A8 · ctx:16384 · kv:k16v16 · long` · `best_at_28k=INT8_W8A8 · ctx:32768 · kv:k8v8 · long`
- `8k` prompt: winner=`INT8_W8A8 · ctx:16384 · kv:k16v16 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_8k_prompt.txt`
- `14k` prompt: winner=`INT8_W8A8 · ctx:16384 · kv:k16v16 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_14k_prompt.txt`
- `28k` prompt: winner=`INT8_W8A8 · ctx:32768 · kv:k8v8 · long` error=`None` prompt_path=`/Users/diptanshukumar/PycharmProjects/sigilant-runner/prompts/hard_quality_28k_prompt.txt`

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model microsoft/Phi-3.5-mini-instruct --backend modal --engine vllm --hardware a10g --configs 8 --trials 1 --score-profile balanced
```
