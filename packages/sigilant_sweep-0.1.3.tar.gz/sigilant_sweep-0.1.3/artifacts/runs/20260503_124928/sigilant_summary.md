# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `A10G`
- Trials: `5`
- Score profile: `quality`

## Winner
- Config: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Score: `94`
- TPS / TTFT / PPL: `66.4` / `1927.4 ms` / `7.79`

## Quick Wow
- Recommendation ready in one run: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `low` (top-2 gap: `1.00` points, `1.06%`)

## Stability
- Confidence: `low`
- Top-2 gap: `1.00` points (`1.06%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `9.00`
- Winner delta TPS: `20.20`
- Winner delta TPS p95: `20.40`
- Winner delta TTFT(ms): `-840.5`
- Winner delta TTFT p95(ms): `-846.8`
- Winner delta PPL: `0.87`

## Confidence Inputs
- Target: `medium`
- Initial trials: `5`
- Top-2 gap before: `1.00` points (`1.06%`)
- Top-2 variance proxy before: `0.82%`
- Replay triggered: `False`
- Replay reason: `disabled_fixed_trials`
- Replay extra trials: `0`
- Replay outcome: `disabled`
- Top-2 gap after: `1.06%`
- Top-2 variance proxy after: `0.82%`

## Agent Smoke
- Pass rate: `4/5 (80.0%)`
- Diagnosis: `config_ready_for_smoke`
- Status: `smoke_pass`
- Failed checks: `multi_tool_1`
- Harness errors: `0` parse-failures: `1`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware a10g --configs 16 --trials 5 --score-profile quality
```
