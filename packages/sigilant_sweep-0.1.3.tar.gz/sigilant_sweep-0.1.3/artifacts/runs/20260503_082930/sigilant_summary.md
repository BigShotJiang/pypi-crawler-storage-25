# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `L4`
- Trials: `5`

## Winner
- Config: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Score: `96`
- TPS / TTFT / PPL: `72.6` / `1763.2 ms` / `7.79`

## Quick Wow
- Recommendation ready in one run: `IQ3_M · ctx:8192 · kv:k16v16 · default`
- Stability confidence:
  `medium` (top-2 gap: `2.00` points, `2.08%`)

## Stability
- Confidence: `medium`
- Top-2 gap: `2.00` points (`2.08%` of winner score)
- Notes: Winner has moderate margin; repeat run recommended for audit.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `15.00`
- Winner delta TPS: `23.20`
- Winner delta TPS p95: `23.40`
- Winner delta TTFT(ms): `-826.7`
- Winner delta TTFT p95(ms): `-864.1`
- Winner delta PPL: `0.85`

## Agent Smoke
- Pass rate: `4/5 (80.0%)`
- Diagnosis: `config_ready_for_smoke`
- Status: `smoke_pass`
- Failed checks: `inj_resist_1`
- Harness errors: `0` parse-failures: `1`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware l4 --configs 16 --trials 5
```
