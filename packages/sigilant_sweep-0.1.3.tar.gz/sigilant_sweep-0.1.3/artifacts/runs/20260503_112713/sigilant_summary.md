# Sigilant Runner Summary

- Model: `bartowski/Phi-3.5-mini-instruct-GGUF`
- Backend/Engine: `modal` / `llama.cpp`
- Hardware: `A10G`
- Trials: `10`
- Score profile: `quality`

## Winner
- Config: `IQ3_M · ctx:16384 · kv:k16v16 · long`
- Score: `94`
- TPS / TTFT / PPL: `65.5` / `1954.8 ms` / `7.79`

## Quick Wow
- Recommendation ready in one run: `IQ3_M · ctx:16384 · kv:k16v16 · long`
- Stability confidence:
  `low` (top-2 gap: `1.00` points, `1.06%`)

## Stability
- Confidence: `low`
- Top-2 gap: `1.00` points (`1.06%` of winner score)
- Notes: Near-tie winner; increase trials or run top-2 replay.

## Baseline Compare
- Baseline: `Q8_0 · ctx:8192 · kv:k16v16 · default`
- Winner delta score: `11.00`
- Winner delta TPS: `23.00`
- Winner delta TPS p95: `20.90`
- Winner delta TTFT(ms): `-1054.4`
- Winner delta TTFT p95(ms): `-1230.9`
- Winner delta PPL: `0.87`

## Confidence Inputs
- Target: `medium`
- Initial trials: `10`
- Top-2 gap before: `0.00` points (`0.00%`)
- Top-2 variance proxy before: `9.51%`
- Replay triggered: `True`
- Replay reason: `gap_pct<2.5`
- Replay extra trials: `6`
- Replay outcome: `applied`
- Top-2 gap after: `1.06%`
- Top-2 variance proxy after: `0.94%`

## Agent Smoke
- Pass rate: `3/5 (60.0%)`
- Diagnosis: `mixed`
- Status: `partial_agent_readiness`
- Failed checks: `multi_tool_1, inj_resist_1`
- Harness errors: `0` parse-failures: `2`
- Note: Smoke only. Use full Sigilant Optimizer for production agent safety, robustness, and long-context reliability certification.

## Product Boundary
- OSS scope: fast config sweep + baseline deltas + lightweight smoke.
- Use paid Sigilant Optimizer for full safety/quality certification, long-context reliability, and governance artifacts.

## Reproduce
```bash
sigilant-runner run --model bartowski/Phi-3.5-mini-instruct-GGUF --backend modal --engine llama.cpp --hardware a10g --configs 16 --trials 10 --score-profile quality
```
