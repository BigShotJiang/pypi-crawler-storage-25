# Sigilant Runner Instructions

## 1) Standard Modal Run
```bash
sigilant-runner run \
  --model Qwen/Qwen2.5-1.5B-Instruct-GGUF \
  --backend modal \
  --engine llama.cpp \
  --hardware l4 \
  --trials 10 \
  --configs 16
```

## 1b) Standard Modal Run (vLLM)
```bash
sigilant-runner run \
  --model mistralai/Mistral-7B-Instruct-v0.3 \
  --backend modal \
  --engine vllm \
  --hardware a10g \
  --trials 12 \
  --configs 16
```

## 2) Modal Run with Agent Smoke
```bash
sigilant-runner run \
  --model Qwen/Qwen2.5-1.5B-Instruct-GGUF \
  --backend modal \
  --engine llama.cpp \
  --hardware l4 \
  --trials 10 \
  --configs 16 \
  --agent-smoke
```

## 3) Compare Against Current Config
`--baseline-config` format:
`QUANT,CTX,KV,REGIME`

Example:
```bash
sigilant-runner run \
  --model Qwen/Qwen2.5-1.5B-Instruct-GGUF \
  --backend modal \
  --engine llama.cpp \
  --hardware l4 \
  --trials 10 \
  --baseline-config "Q4_K_M,8192,k16v16,default"
```

## 4) CI Drift Check
Fail run if winner differs from baseline file:
```bash
sigilant-runner run \
  --model Qwen/Qwen2.5-1.5B-Instruct-GGUF \
  --backend modal \
  --engine llama.cpp \
  --hardware l4 \
  --trials 10 \
  --check \
  --baseline-file .sigilant_baseline.json
```

Update baseline:
```bash
sigilant-runner run \
  --model Qwen/Qwen2.5-1.5B-Instruct-GGUF \
  --backend modal \
  --engine llama.cpp \
  --hardware l4 \
  --trials 10 \
  --update-baseline \
  --baseline-file .sigilant_baseline.json
```

## 5) Local Run (when GPU available)
```bash
sigilant-runner run \
  --model Qwen/Qwen2.5-1.5B-Instruct-GGUF \
  --backend local \
  --engine llama.cpp \
  --hardware auto \
  --trials 10 \
  --agent-smoke
```

## 6) Operational Notes
- Use default `--trials 12` for stable ranking.
- If top-2 scores are very close, rerun once before deployment decisions.
- PPL is a quality proxy only; do not treat as full safety evaluation.
- Agent smoke is a quick gate, not full production certification.
- RunPod currently supports only `--engine llama.cpp`.
- Agent smoke currently supports only llama.cpp paths (local/modal).
- Interpret smoke diagnosis:
  - `model_limited`: model likely not agent-ready
  - `harness_limited`: investigate runtime/parser/tool harness before model judgement
  - `mixed`: partial failures; validate with broader eval
