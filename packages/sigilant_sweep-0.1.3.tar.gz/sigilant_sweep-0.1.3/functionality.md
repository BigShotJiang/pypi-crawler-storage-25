# Sigilant Runner Functionality

## Purpose
`sigilant-runner` is a lightweight OSS optimizer that sweeps up to 16 configs and recommends the best serving config from TPS, TTFT, and PPL proxy quality.

## Implemented Features
- Backends: `local`, `modal`, `runpod`
- Engines:
  - `llama.cpp`: `local`, `modal`, `runpod`
  - `vllm`: `local`, `modal`
- Grid: 16 variants (quant × ctx × KV regime)
- Multi-trial execution with rotated start offsets
- Metrics: `TPS`, `TTFT`, `ITL`, `PPL`
- Tail metrics for stable runs: `TPS p95`, `TTFT p95` (when trials >= 4)

## Scoring
- Presets:
  - `balanced`: `40% TPS + 20% TTFT + 40% PPL`
  - `latency`: `50% TPS + 30% TTFT + 20% PPL`
  - `quality`: `30% TPS + 20% TTFT + 50% PPL`
- If PPL is unavailable, score renormalizes to TPS/TTFT only.
- TTFT normalization blends p50 + p95 when available.

## Determinism and Confidence
- Rotated trial order reduces thermal/order bias.
- Per-config aggregate uses p50; p95 tracked separately.
- Deterministic tie-breaking is applied for stable ordering.
- Confidence reporting includes top-2 gap and variance proxy.

## Baseline and Drift
- Manual baseline compare: `--baseline-config QUANT,CTX,KV,REGIME`
- Auto baseline compare when manual is omitted (max-precision feasible quant)
- CI drift controls:
  - `--check`
  - `--update-baseline`
  - `--baseline-file`

## Agent Smoke
- Optional: `--agent-smoke` on winner config
- Checks:
  - structural JSON
  - single-tool
  - multi-tool
  - tool args
  - refusal behavior
- Supported paths:
  - `local + llama.cpp`
  - `modal + llama.cpp`
- Not yet supported:
  - `vllm` smoke
  - `runpod` smoke

## Artifacts
- `sigilant_results.json`
- `sigilant_summary.md`
- `sigilant_frontier.svg`
- `sigilant_terminal.txt`
- Per-run folder: `artifacts/runs/YYYYMMDD_HHMMSS/`

## OSS Boundary
- OSS: fast config recommendation + baseline deltas + lightweight smoke triage.
- Production safety/quality certification remains in paid Sigilant Optimizer.
