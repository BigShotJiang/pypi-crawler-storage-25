# Sigilant Runner Output Contract

## Terminal Output

### Header
- model label
- hardware label
- engine
- number of configs
- score profile
- trials used

### Ranked Table
Columns (as available):
- `Config`
- `TPS`
- `TPS p95` (shown when available)
- `TTFT`
- `TTFT p95` (shown when available)
- `ITL`
- `PPL`
- `TPS%`
- `TTFT%`
- `PPL%`
- `Score`

Top row is marked `← best`.

### Post-table Summary
- `Best config`
- score formula line
- baseline compare line (manual or auto baseline)
- quick wow block (winner + immediate deltas)
- artifact paths written
- optional agent smoke summary

## Artifact Files

### 1) `sigilant_results.json`
Contains:
- schema/version
- run context (model/backend/engine/hardware/trials/repro command)
- confidence inputs (gap/variance/replay flags)
- stability block (winner confidence, top-2 gap)
- baseline compare block (when available)
- agent smoke block (when enabled)
- per-config metrics and normalized components

### 2) `sigilant_summary.md`
Human-readable summary:
- winner
- stability/confidence
- baseline deltas
- smoke summary (if enabled)
- exact rerun command

### 3) `sigilant_frontier.svg`
Frontier chart:
- x-axis: TTFT (lower better)
- y-axis: TPS (higher better)
- point color: PPL band

### 4) `.sigilant_baseline.json` (optional)
Used by `--check` / `--update-baseline`.
Stores baseline winner label for drift detection.

### 5) `sigilant_terminal.txt`
Saved terminal-style summary snapshot (simple readable report).

## Run Persistence
- Every run is persisted under:
  - `artifacts/runs/YYYYMMDD_HHMMSS/`
- Latest convenience copies are also written at repo root:
  - `sigilant_results.json`
  - `sigilant_summary.md`
  - `sigilant_frontier.svg`
  - `sigilant_terminal.txt`

## Exit Behavior
- normal success: `0`
- check drift failure (`--check`): non-zero (`2`)
- runtime/config errors: non-zero

## Agent Smoke Payload
When enabled:
- `passed`, `total`, `pass_rate`
- `diagnosis` (`model_limited` | `harness_limited` | `mixed` | `config_ready_for_smoke`)
- `status` (`not_agent_ready` | `needs_harness_fix` | `partial_agent_readiness` | `smoke_pass`)
- `failed_checks`, `error_count`, `parse_fail_count`
- per-case pass/fail and compact output excerpts
- note that this is lightweight smoke, not full safety certification

## Engine/Backend support
- `llama.cpp`: local, modal, runpod
- `vllm`: local, modal
- `runpod + vllm`: not supported
