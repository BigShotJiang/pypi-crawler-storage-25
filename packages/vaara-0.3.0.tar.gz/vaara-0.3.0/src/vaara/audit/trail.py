"""Immutable audit trail with regulatory article mapping.

Every action that passes through the Vaara execution layer gets an audit
record — whether it was allowed, denied, or escalated.  Records are:

- **Immutable**: once written, the hash chain makes tampering detectable.
- **Regulation-mapped**: each record links to specific regulatory articles
  (EU AI Act, DORA, NIS2, MiFID II, GDPR) that the action is relevant to.
- **Machine-readable AND human-readable**: structured JSON for automation,
  narrative explanation for auditors and regulators.
- **Event-sourced**: outcomes are appended as follow-up events, never
  mutated in place.  The full decision→execution→outcome lifecycle is
  preserved.

This is the evidence base that the compliance engine uses to generate
conformity assessment reports.

EU AI Act Article 12 requires "automatic recording of events" for
high-risk AI systems.  Article 14 requires records sufficient for
human oversight.  This module satisfies both.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

from vaara.taxonomy.actions import ActionRequest, RegulatoryDomain

logger = logging.getLogger(__name__)


# ── Event types ───────────────────────────────────────────────────────────

class EventType(str, Enum):
    """Lifecycle events in the audit trail."""
    ACTION_REQUESTED = "action_requested"   # Agent submitted an action
    RISK_SCORED = "risk_scored"             # Scorer produced assessment
    DECISION_MADE = "decision_made"         # Allow/deny/escalate decided
    ACTION_EXECUTED = "action_executed"      # Action was actually executed
    ACTION_BLOCKED = "action_blocked"       # Action was blocked
    ESCALATION_SENT = "escalation_sent"     # Sent to human for review
    ESCALATION_RESOLVED = "escalation_resolved"  # Human responded
    OUTCOME_RECORDED = "outcome_recorded"   # Post-execution outcome observed
    POLICY_OVERRIDE = "policy_override"     # Manual override of policy decision


# ── Regulatory article mappings ───────────────────────────────────────────

@dataclass(frozen=True)
class RegulatoryArticle:
    """A specific regulatory article that an audit record satisfies."""
    domain: RegulatoryDomain
    article: str           # e.g., "Article 12(1)" or "Article 9(2)(a)"
    requirement: str       # What the article requires
    how_satisfied: str     # How this audit record satisfies it


# Pre-built mappings — which record types satisfy which articles
EU_AI_ACT_MAPPINGS: dict[EventType, list[RegulatoryArticle]] = {
    EventType.ACTION_REQUESTED: [
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 12(1)",
            "Automatic recording of events (logging capabilities)",
            "Every action request is recorded with full context before processing",
        ),
    ],
    EventType.RISK_SCORED: [
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 9(2)(a)",
            "Risk management system shall identify and analyse known and reasonably foreseeable risks",
            "Adaptive risk scoring with conformal prediction intervals quantifies risk for every action",
        ),
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 9(7)",
            "Testing shall be suitable to identify relevant risks",
            "Conformal calibration provides distribution-free coverage guarantees on risk estimates",
        ),
    ],
    EventType.DECISION_MADE: [
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 14(1)",
            "High-risk AI systems shall be designed to be effectively overseen by natural persons",
            "Three-tier decision (allow/escalate/deny) ensures humans review borderline cases",
        ),
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 14(4)(a)",
            "The human shall be able to fully understand the capacities and limitations of the system",
            "Decision records include risk scores, confidence intervals, and contributing signals",
        ),
    ],
    EventType.ACTION_BLOCKED: [
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 9(4)(a)",
            "Appropriate risk management measures shall be adopted, including elimination or reduction of risks",
            "High-risk actions are automatically blocked with full audit trail",
        ),
    ],
    EventType.ESCALATION_SENT: [
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 14(3)(a)",
            "Human oversight shall enable the human to properly monitor the AI system",
            "Borderline decisions are escalated with full context for human review",
        ),
    ],
    EventType.ESCALATION_RESOLVED: [
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 14(4)(d)",
            "The human shall be able to decide not to use the system or to override the output",
            "Human override decisions are recorded with justification",
        ),
    ],
    EventType.OUTCOME_RECORDED: [
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 9(2)(b)",
            "Appropriate measures to eliminate or reduce risks as far as possible through adequate design",
            "Post-execution outcomes feed back into adaptive scoring to improve future risk estimates",
        ),
        RegulatoryArticle(
            RegulatoryDomain.EU_AI_ACT, "Article 61(1)",
            "Post-market monitoring system proportionate to the nature of the AI technologies",
            "Continuous outcome tracking enables post-deployment monitoring of risk accuracy",
        ),
    ],
}

DORA_MAPPINGS: dict[EventType, list[RegulatoryArticle]] = {
    EventType.ACTION_REQUESTED: [
        RegulatoryArticle(
            RegulatoryDomain.DORA, "Article 12(1)",
            "ICT-related incident detection, including automated alert mechanisms",
            "All agent actions are logged as events for incident detection",
        ),
    ],
    EventType.ACTION_BLOCKED: [
        RegulatoryArticle(
            RegulatoryDomain.DORA, "Article 10(1)",
            "ICT risk management framework shall include protection and prevention mechanisms",
            "Automated blocking of high-risk actions with full incident trail",
        ),
    ],
    EventType.OUTCOME_RECORDED: [
        RegulatoryArticle(
            RegulatoryDomain.DORA, "Article 13(1)",
            "Learning and evolving from ICT-related incidents",
            "Outcome data feeds back into risk scoring for continuous improvement",
        ),
    ],
}


# ── Audit Record ──────────────────────────────────────────────────────────

@dataclass
class AuditRecord:
    """A single immutable audit event in the trail.

    Each record is hash-chained to the previous record, forming a
    tamper-evident log.  Records are append-only — outcomes are added
    as new events referencing the original action_id, never mutated.
    """
    record_id: str
    action_id: str              # Groups all events for one action
    event_type: EventType
    timestamp: float            # Unix epoch (UTC)
    agent_id: str
    tool_name: str
    data: dict = field(default_factory=dict)
    regulatory_articles: list[dict] = field(default_factory=list)
    previous_hash: str = ""     # Hash chain — empty for first record
    record_hash: str = ""       # SHA-256 of this record's content

    def compute_hash(self) -> str:
        """Compute deterministic hash of this record's content."""
        content = {
            "record_id": self.record_id,
            "action_id": self.action_id,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp,
            "agent_id": self.agent_id,
            "tool_name": self.tool_name,
            "data": self.data,
            "previous_hash": self.previous_hash,
        }
        canonical = json.dumps(content, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode()).hexdigest()

    def to_dict(self) -> dict:
        """Serialize to dict for storage/export."""
        d = asdict(self)
        d["event_type"] = self.event_type.value
        return d

    @staticmethod
    def from_dict(d: dict) -> AuditRecord:
        """Deserialize from dict."""
        d = dict(d)
        d["event_type"] = EventType(d["event_type"])
        return AuditRecord(**d)

    @property
    def narrative(self) -> str:
        """Human-readable narrative of this event."""
        ts = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(self.timestamp))
        prefix = f"[{ts}] Agent '{self.agent_id}'"

        narratives = {
            EventType.ACTION_REQUESTED: (
                f"{prefix} requested '{self.tool_name}'"
                f" (params: {_summarize_params(self.data.get('parameters', {}))})"
            ),
            EventType.RISK_SCORED: (
                f"{prefix} action '{self.tool_name}' scored "
                f"risk={_fmt_num(self.data.get('point_estimate'))} "
                f"[{_fmt_num(self.data.get('conformal_lower'))}, "
                f"{_fmt_num(self.data.get('conformal_upper'))}]"
            ),
            EventType.DECISION_MADE: (
                f"{prefix} action '{self.tool_name}' → "
                f"{self.data.get('decision', 'unknown').upper()}"
                f" (reason: {self.data.get('reason', 'none')})"
            ),
            EventType.ACTION_EXECUTED: (
                f"{prefix} executed '{self.tool_name}' successfully"
            ),
            EventType.ACTION_BLOCKED: (
                f"{prefix} BLOCKED from executing '{self.tool_name}'"
                f" (risk={self.data.get('risk_score', '?')})"
            ),
            EventType.ESCALATION_SENT: (
                f"{prefix} action '{self.tool_name}' escalated for human review"
            ),
            EventType.ESCALATION_RESOLVED: (
                f"{prefix} escalation resolved: "
                f"{self.data.get('resolution', 'unknown')}"
                f" by {self.data.get('reviewer', 'unknown')}"
            ),
            EventType.OUTCOME_RECORDED: (
                f"{prefix} outcome for '{self.tool_name}': "
                f"severity={self.data.get('outcome_severity', '?')}"
            ),
            EventType.POLICY_OVERRIDE: (
                f"{prefix} policy overridden: "
                f"{self.data.get('override_reason', 'no reason given')}"
            ),
        }

        return narratives.get(self.event_type, f"{prefix} {self.event_type.value}")


def _fmt_num(val: Any, fmt: str = ".3f") -> str:
    """Format a number for narrative display, with fallback for missing values."""
    if val is None:
        return "?"
    try:
        return f"{float(val):{fmt}}"
    except (TypeError, ValueError):
        return str(val)


def _summarize_params(params: dict, max_len: int = 100) -> str:
    """Truncate parameter dict for narrative display."""
    s = str(params)
    if len(s) > max_len:
        return s[:max_len - 3] + "..."
    return s


# ── Audit Trail ───────────────────────────────────────────────────────────

class AuditTrail:
    """Append-only, hash-chained audit trail.

    All action lifecycle events are recorded here.  The trail is the
    single source of truth for compliance reporting.

    Storage backends are pluggable — the trail writes to an in-memory
    list and optionally to an on_record callback (for file/DB/streaming).
    """

    def __init__(
        self,
        on_record: Optional[Callable[[AuditRecord], None]] = None,
    ) -> None:
        """
        Args:
            on_record: Optional callback invoked on every new record.
                       Use this to pipe records to file, database, or stream.
        """
        self._records: list[AuditRecord] = []
        self._by_action: dict[str, list[AuditRecord]] = defaultdict(list)
        self._last_hash = ""
        self._on_record = on_record

    @property
    def size(self) -> int:
        return len(self._records)

    @property
    def chain_intact(self) -> bool:
        """Verify the hash chain is unbroken."""
        return self.verify_chain() is None

    def verify_chain(self) -> Optional[str]:
        """Verify hash chain integrity.  Returns None if intact, error string if broken."""
        prev_hash = ""
        for i, record in enumerate(self._records):
            if record.previous_hash != prev_hash:
                return (
                    f"Chain broken at record {i} ({record.record_id}): "
                    f"expected previous_hash={prev_hash!r}, "
                    f"got {record.previous_hash!r}"
                )
            expected = record.compute_hash()
            if record.record_hash != expected:
                return (
                    f"Hash mismatch at record {i} ({record.record_id}): "
                    f"expected {expected!r}, got {record.record_hash!r}"
                )
            prev_hash = record.record_hash
        return None

    # ── Recording events ──────────────────────────────────────────

    def record_action_requested(self, request: ActionRequest) -> str:
        """Record that an agent requested an action.  Returns the action_id."""
        action_id = str(uuid.uuid4())

        articles = self._get_regulatory_articles(
            EventType.ACTION_REQUESTED,
            request.action_type.regulatory_domains,
        )

        self._append(AuditRecord(
            record_id=str(uuid.uuid4()),
            action_id=action_id,
            event_type=EventType.ACTION_REQUESTED,
            timestamp=time.time(),
            agent_id=request.agent_id,
            tool_name=request.tool_name,
            data={
                "parameters": request.parameters,
                "context": request.context,
                "action_category": request.action_type.category.value,
                "reversibility": request.action_type.reversibility.value,
                "blast_radius": request.action_type.blast_radius.value,
                "urgency": request.action_type.urgency.value,
                "base_risk_score": request.action_type.base_risk_score,
                "agent_confidence": request.confidence,
                "session_id": request.session_id,
                "parent_action_id": request.parent_action_id,
                "sequence_position": request.sequence_position,
            },
            regulatory_articles=articles,
        ))

        return action_id

    def record_risk_scored(
        self,
        action_id: str,
        agent_id: str,
        tool_name: str,
        assessment: dict,
        regulatory_domains: frozenset[RegulatoryDomain] = frozenset(),
    ) -> None:
        """Record the risk scoring result."""
        articles = self._get_regulatory_articles(
            EventType.RISK_SCORED, regulatory_domains,
        )

        self._append(AuditRecord(
            record_id=str(uuid.uuid4()),
            action_id=action_id,
            event_type=EventType.RISK_SCORED,
            timestamp=time.time(),
            agent_id=agent_id,
            tool_name=tool_name,
            data=assessment,
            regulatory_articles=articles,
        ))

    def record_decision(
        self,
        action_id: str,
        agent_id: str,
        tool_name: str,
        decision: str,
        reason: str,
        risk_score: float,
        regulatory_domains: frozenset[RegulatoryDomain] = frozenset(),
    ) -> None:
        """Record the allow/deny/escalate decision."""
        event_type = (
            EventType.ACTION_BLOCKED if decision == "deny"
            else EventType.DECISION_MADE
        )

        articles = self._get_regulatory_articles(
            event_type, regulatory_domains,
        )

        self._append(AuditRecord(
            record_id=str(uuid.uuid4()),
            action_id=action_id,
            event_type=event_type,
            timestamp=time.time(),
            agent_id=agent_id,
            tool_name=tool_name,
            data={
                "decision": decision,
                "reason": reason,
                "risk_score": risk_score,
            },
            regulatory_articles=articles,
        ))

    def record_execution(
        self,
        action_id: str,
        agent_id: str,
        tool_name: str,
        result: Optional[dict] = None,
    ) -> None:
        """Record that the action was executed."""
        self._append(AuditRecord(
            record_id=str(uuid.uuid4()),
            action_id=action_id,
            event_type=EventType.ACTION_EXECUTED,
            timestamp=time.time(),
            agent_id=agent_id,
            tool_name=tool_name,
            data={"result_summary": result or {}},
        ))

    def record_escalation(
        self,
        action_id: str,
        agent_id: str,
        tool_name: str,
        escalation_target: str,
        risk_score: float,
    ) -> None:
        """Record that an action was escalated for human review."""
        articles = self._get_regulatory_articles(
            EventType.ESCALATION_SENT, frozenset({RegulatoryDomain.EU_AI_ACT}),
        )

        self._append(AuditRecord(
            record_id=str(uuid.uuid4()),
            action_id=action_id,
            event_type=EventType.ESCALATION_SENT,
            timestamp=time.time(),
            agent_id=agent_id,
            tool_name=tool_name,
            data={
                "escalation_target": escalation_target,
                "risk_score": risk_score,
            },
            regulatory_articles=articles,
        ))

    def record_escalation_resolved(
        self,
        action_id: str,
        agent_id: str,
        tool_name: str,
        resolution: str,
        reviewer: str,
        justification: str = "",
    ) -> None:
        """Record human resolution of an escalation."""
        articles = self._get_regulatory_articles(
            EventType.ESCALATION_RESOLVED, frozenset({RegulatoryDomain.EU_AI_ACT}),
        )

        self._append(AuditRecord(
            record_id=str(uuid.uuid4()),
            action_id=action_id,
            event_type=EventType.ESCALATION_RESOLVED,
            timestamp=time.time(),
            agent_id=agent_id,
            tool_name=tool_name,
            data={
                "resolution": resolution,
                "reviewer": reviewer,
                "justification": justification,
            },
            regulatory_articles=articles,
        ))

    def record_outcome(
        self,
        action_id: str,
        agent_id: str,
        tool_name: str,
        outcome_severity: float,
        description: str = "",
    ) -> None:
        """Record the actual outcome of an executed action.

        This closes the feedback loop — the outcome is used by the scorer
        to update its MWU weights and conformal calibration.
        """
        articles = self._get_regulatory_articles(
            EventType.OUTCOME_RECORDED,
            frozenset({RegulatoryDomain.EU_AI_ACT, RegulatoryDomain.DORA}),
        )

        self._append(AuditRecord(
            record_id=str(uuid.uuid4()),
            action_id=action_id,
            event_type=EventType.OUTCOME_RECORDED,
            timestamp=time.time(),
            agent_id=agent_id,
            tool_name=tool_name,
            data={
                "outcome_severity": outcome_severity,
                "description": description,
            },
            regulatory_articles=articles,
        ))

    def record_policy_override(
        self,
        action_id: str,
        agent_id: str,
        tool_name: str,
        override_reason: str,
        overrider: str,
        original_decision: str,
        new_decision: str,
    ) -> None:
        """Record a manual policy override."""
        self._append(AuditRecord(
            record_id=str(uuid.uuid4()),
            action_id=action_id,
            event_type=EventType.POLICY_OVERRIDE,
            timestamp=time.time(),
            agent_id=agent_id,
            tool_name=tool_name,
            data={
                "override_reason": override_reason,
                "overrider": overrider,
                "original_decision": original_decision,
                "new_decision": new_decision,
            },
        ))

    # ── Querying ──────────────────────────────────────────────────

    def get_action_trail(self, action_id: str) -> list[AuditRecord]:
        """Get all events for a specific action, in order."""
        return list(self._by_action.get(action_id, []))

    def get_agent_records(
        self, agent_id: str, limit: int = 100
    ) -> list[AuditRecord]:
        """Get recent records for an agent."""
        records = [r for r in self._records if r.agent_id == agent_id]
        return records[-limit:]

    def get_records_by_type(
        self, event_type: EventType, limit: int = 100
    ) -> list[AuditRecord]:
        """Get recent records of a specific event type."""
        records = [r for r in self._records if r.event_type == event_type]
        return records[-limit:]

    def get_blocked_actions(self, limit: int = 50) -> list[AuditRecord]:
        """Get recently blocked actions — useful for compliance dashboards."""
        return self.get_records_by_type(EventType.ACTION_BLOCKED, limit)

    def get_regulatory_evidence(
        self, domain: RegulatoryDomain
    ) -> list[AuditRecord]:
        """Get all records relevant to a specific regulatory domain."""
        results = []
        for record in self._records:
            for article in record.regulatory_articles:
                if article.get("domain") == domain.value:
                    results.append(record)
                    break
        return results

    def get_narrative(
        self, action_id: Optional[str] = None, limit: int = 50
    ) -> str:
        """Generate human-readable narrative of the audit trail.

        If action_id is provided, narrates that action's lifecycle.
        Otherwise, narrates the most recent events.
        """
        if action_id:
            records = self.get_action_trail(action_id)
        else:
            records = self._records[-limit:]

        lines = []
        for record in records:
            lines.append(record.narrative)
            if record.regulatory_articles:
                domains = {a.get("domain", "") for a in record.regulatory_articles}
                lines.append(f"  Regulatory: {', '.join(sorted(domains))}")
        return "\n".join(lines)

    # ── Export ────────────────────────────────────────────────────

    def export_json(self, path: Path) -> int:
        """Export full trail to JSON file.  Returns record count."""
        records = [r.to_dict() for r in self._records]
        path.write_text(json.dumps(records, indent=2, default=str))
        return len(records)

    def export_jsonl(self, path: Path) -> int:
        """Export full trail as JSON Lines (one record per line)."""
        with open(path, "w") as f:
            for record in self._records:
                f.write(json.dumps(record.to_dict(), default=str) + "\n")
        return len(self._records)

    # ── Internal ──────────────────────────────────────────────────

    def _append(self, record: AuditRecord) -> None:
        """Append a record to the trail with hash chaining."""
        record.previous_hash = self._last_hash
        record.record_hash = record.compute_hash()
        self._last_hash = record.record_hash

        self._records.append(record)
        self._by_action[record.action_id].append(record)

        if self._on_record:
            try:
                self._on_record(record)
            except Exception as e:
                logger.error("on_record callback failed: %s", e)

    def _get_regulatory_articles(
        self,
        event_type: EventType,
        action_domains: frozenset[RegulatoryDomain],
    ) -> list[dict]:
        """Collect regulatory article mappings for an event type."""
        articles = []

        # EU AI Act mappings (always included for high-risk AI systems)
        for article in EU_AI_ACT_MAPPINGS.get(event_type, []):
            articles.append({
                "domain": article.domain.value,
                "article": article.article,
                "requirement": article.requirement,
                "how_satisfied": article.how_satisfied,
            })

        # DORA mappings (for financial actions)
        if RegulatoryDomain.DORA in action_domains:
            for article in DORA_MAPPINGS.get(event_type, []):
                articles.append({
                    "domain": article.domain.value,
                    "article": article.article,
                    "requirement": article.requirement,
                    "how_satisfied": article.how_satisfied,
                })

        return articles
