"""CrewAI integration — Vaara as task-level and tool-level governance.

CrewAI orchestrates multi-agent crews where agents have roles, goals, and
tools.  Vaara integrates at two levels:

1. **Tool-level** — wraps individual tools with risk scoring (same as
   LangChain since CrewAI uses LangChain tools internally).

2. **Task-level** — a pre-execution hook that scores the entire task
   context (agent role + task description + tools) before the crew
   starts working.  This catches dangerous task assignments before
   any tool calls happen.

Integration:

    from crewai import Crew, Agent, Task
    from vaara.integrations.crewai import VaaraCrewGovernance

    pipeline = InterceptionPipeline()
    gov = VaaraCrewGovernance(pipeline)

    # Wrap tools
    safe_tools = gov.wrap_tools(agent.tools, agent_id="research-agent")

    # Or wrap entire crew execution
    result = gov.governed_kickoff(crew)

Requires: crewai >= 0.30 (not a hard dependency — imported at runtime)
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from vaara.pipeline import InterceptionPipeline
from vaara.integrations.langchain import (
    ToolExecutionBlocked,
    ToolExecutionEscalated,
)

logger = logging.getLogger(__name__)


class VaaraCrewGovernance:
    """Governance layer for CrewAI crews.

    Provides tool wrapping, task-level pre-screening, and crew-level
    execution governance.
    """

    def __init__(
        self,
        pipeline: InterceptionPipeline,
        block_on_escalate: bool = False,
    ) -> None:
        self.pipeline = pipeline
        self.block_on_escalate = block_on_escalate

    def wrap_tools(
        self,
        tools: list[Any],
        agent_id: str = "crewai-agent",
    ) -> list[Any]:
        """Wrap a list of CrewAI/LangChain tools with Vaara interception.

        CrewAI uses LangChain tools internally, so we reuse the
        LangChain tool wrapper.
        """
        from vaara.integrations.langchain import vaara_wrap_tool

        wrapped = []
        for tool in tools:
            wrapped.append(
                vaara_wrap_tool(
                    tool, self.pipeline, agent_id=agent_id,
                    block_on_escalate=self.block_on_escalate,
                )
            )
        return wrapped

    def screen_task(
        self,
        task_description: str,
        agent_role: str,
        tools: list[str],
        agent_id: str = "crewai-agent",
    ) -> dict:
        """Pre-screen a task before execution.

        Scores the task's risk based on what tools it might use and
        the agent's role.  Returns a dict with the assessment.

        This is a heuristic pre-check — the real scoring happens when
        tools are actually called.  But catching obviously dangerous
        task assignments early saves compute and reduces attack surface.
        """
        # Score the most dangerous tool the task has access to
        assessments = []
        for tool_name in tools:
            result = self.pipeline.intercept(
                agent_id=agent_id,
                tool_name=tool_name,
                parameters={"_prescreen": True},
                context={
                    "framework": "crewai",
                    "task_description": task_description[:500],
                    "agent_role": agent_role,
                    "prescreen": True,
                },
            )
            assessments.append({
                "tool": tool_name,
                "decision": result.decision,
                "risk_score": result.risk_score,
                "action_id": result.action_id,
            })

        max_risk = max(a["risk_score"] for a in assessments) if assessments else 0.0
        any_blocked = any(a["decision"] == "deny" for a in assessments)
        any_escalated = any(a["decision"] == "escalate" for a in assessments)

        return {
            "task_allowed": not any_blocked,
            "max_risk_score": max_risk,
            "blocked_tools": [a["tool"] for a in assessments if a["decision"] == "deny"],
            "escalated_tools": [a["tool"] for a in assessments if a["decision"] == "escalate"],
            "assessments": assessments,
        }

    def governed_kickoff(
        self,
        crew: Any,
        pre_screen: bool = True,
    ) -> Any:
        """Execute a CrewAI crew with Vaara governance.

        Optionally pre-screens all tasks, then wraps all agent tools.
        Falls back gracefully if CrewAI is not installed.

        Args:
            crew: A CrewAI Crew instance.
            pre_screen: If True, pre-screen all tasks before execution.

        Returns:
            The crew's kickoff result.

        Raises:
            ToolExecutionBlocked: If a task's tools are all blocked.
        """
        # Pre-screen tasks
        if pre_screen and hasattr(crew, "tasks"):
            for task in crew.tasks:
                agent = getattr(task, "agent", None)
                agent_id = getattr(agent, "role", "crewai-agent") if agent else "crewai-agent"
                tool_names = [
                    getattr(t, "name", str(t))
                    for t in (getattr(task, "tools", []) or
                              getattr(agent, "tools", []) if agent else [])
                ]
                if tool_names:
                    screening = self.screen_task(
                        task_description=getattr(task, "description", ""),
                        agent_role=agent_id,
                        tools=tool_names,
                        agent_id=agent_id,
                    )
                    if not screening["task_allowed"]:
                        raise ToolExecutionBlocked(
                            tool_name=", ".join(screening["blocked_tools"]),
                            action_id=screening["assessments"][0]["action_id"],
                            risk_score=screening["max_risk_score"],
                            risk_interval=(0.0, 1.0),
                            reason=f"Task pre-screening blocked: {screening['blocked_tools']}",
                        )

        # Wrap all agent tools
        if hasattr(crew, "agents"):
            for agent in crew.agents:
                if hasattr(agent, "tools") and agent.tools:
                    agent_id = getattr(agent, "role", "crewai-agent")
                    agent.tools = self.wrap_tools(agent.tools, agent_id=agent_id)

        return crew.kickoff()
