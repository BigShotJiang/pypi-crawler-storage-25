"""OpenAI Agents SDK integration — Vaara as a guardrail.

OpenAI's Agents SDK (March 2025) uses a guardrails pattern where
InputGuardrail / OutputGuardrail functions run before/after the agent.
Vaara plugs in as an OutputGuardrail on tool calls.

For the Responses API direct usage, Vaara wraps the function-call handler.

Integration patterns:

1. **Guardrail** (recommended for Agents SDK):

    from vaara.integrations.openai_agents import VaaraToolGuardrail
    from agents import Agent

    pipeline = InterceptionPipeline()
    guardrail = VaaraToolGuardrail(pipeline)

    agent = Agent(
        name="my-agent",
        tools=[...],
        output_guardrails=[guardrail],
    )

2. **Function wrapper** (for Responses API / custom loops):

    from vaara.integrations.openai_agents import vaara_wrap_function

    @vaara_wrap_function(pipeline, agent_id="my-bot")
    def transfer_funds(to: str, amount: float) -> str:
        return execute_transfer(to, amount)

Requires: openai >= 1.0 (not a hard dependency — imported at runtime)
"""

from __future__ import annotations

import functools
import logging
from typing import Any, Callable, Optional

from vaara.pipeline import InterceptionPipeline

logger = logging.getLogger(__name__)


class VaaraToolGuardrail:
    """OpenAI Agents SDK guardrail that intercepts tool calls.

    Implements the guardrail protocol: a callable that receives the
    agent output and returns a GuardrailResult (or raises to block).

    When used as an output_guardrail, it inspects the agent's planned
    tool calls and scores each one through Vaara before execution.
    """

    def __init__(
        self,
        pipeline: InterceptionPipeline,
        agent_id: str = "openai-agent",
        session_id: str = "",
        block_on_escalate: bool = False,
    ) -> None:
        self.pipeline = pipeline
        self.agent_id = agent_id
        self.session_id = session_id
        self.block_on_escalate = block_on_escalate

    def __call__(self, context: Any, agent: Any, output: Any) -> Any:
        """Guardrail evaluation — called by the Agents SDK runtime.

        Inspects tool_calls in the output and scores each one.
        Returns a GuardrailResult with tripwire_triggered=True to block.
        """
        try:
            from agents import GuardrailResult
        except ImportError:
            logger.warning("openai-agents SDK not installed, guardrail is a no-op")
            return None

        # Extract tool calls from the agent output
        tool_calls = self._extract_tool_calls(output)
        if not tool_calls:
            return GuardrailResult(tripwire_triggered=False, output_info={})

        blocked = []
        for tc in tool_calls:
            result = self.pipeline.intercept(
                agent_id=self.agent_id,
                tool_name=tc["name"],
                parameters=tc.get("arguments", {}),
                context={
                    "framework": "openai_agents",
                    "call_id": tc.get("id", ""),
                },
                session_id=self.session_id,
            )

            if result.decision == "deny":
                blocked.append({
                    "tool": tc["name"],
                    "action_id": result.action_id,
                    "risk_score": result.risk_score,
                    "reason": result.reason,
                })
            elif result.decision == "escalate" and self.block_on_escalate:
                blocked.append({
                    "tool": tc["name"],
                    "action_id": result.action_id,
                    "risk_score": result.risk_score,
                    "reason": f"Escalated: {result.reason}",
                })

        if blocked:
            return GuardrailResult(
                tripwire_triggered=True,
                output_info={
                    "blocked_tools": blocked,
                    "message": (
                        f"Vaara blocked {len(blocked)} tool call(s): "
                        + ", ".join(b["tool"] for b in blocked)
                    ),
                },
            )

        return GuardrailResult(tripwire_triggered=False, output_info={})

    @staticmethod
    def _extract_tool_calls(output: Any) -> list[dict]:
        """Extract tool calls from various output formats."""
        calls = []

        # OpenAI Agents SDK output format
        if hasattr(output, "tool_calls"):
            for tc in output.tool_calls:
                calls.append({
                    "id": getattr(tc, "id", ""),
                    "name": getattr(tc, "name", "") or getattr(tc.function, "name", ""),
                    "arguments": getattr(tc, "arguments", {}) or {},
                })
        # Responses API format
        elif isinstance(output, dict):
            for tc in output.get("tool_calls", []):
                calls.append({
                    "id": tc.get("id", ""),
                    "name": tc.get("function", {}).get("name", tc.get("name", "")),
                    "arguments": tc.get("function", {}).get("arguments", {}),
                })

        return calls


# ── Function wrapper ──────────────────────────────────────────────────────

def vaara_wrap_function(
    pipeline: InterceptionPipeline,
    agent_id: str = "openai-agent",
    tool_name: Optional[str] = None,
    block_on_escalate: bool = False,
) -> Callable:
    """Decorator that wraps a function with Vaara interception.

    For use with the Responses API or custom tool-calling loops.

    Example::

        @vaara_wrap_function(pipeline, agent_id="my-bot")
        def send_funds(to: str, amount: float) -> str:
            return blockchain.transfer(to, amount)

        # Now send_funds checks Vaara before executing
        result = send_funds(to="0xabc", amount=1000)
    """
    def decorator(func: Callable) -> Callable:
        name = tool_name or func.__name__

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = pipeline.intercept(
                agent_id=agent_id,
                tool_name=name,
                parameters=kwargs or {"args": list(args)},
                context={"framework": "openai_responses", "wrapper": True},
            )

            if result.decision == "deny":
                raise ToolCallBlocked(
                    f"Vaara blocked {name}: {result.reason}",
                    action_id=result.action_id,
                    risk_score=result.risk_score,
                )
            if result.decision == "escalate" and block_on_escalate:
                raise ToolCallEscalated(
                    f"Vaara escalated {name}: {result.reason}",
                    action_id=result.action_id,
                    risk_score=result.risk_score,
                )

            try:
                output = func(*args, **kwargs)
                pipeline.report_outcome(result.action_id, 0.0)
                return output
            except Exception as e:
                pipeline.report_outcome(result.action_id, 0.3, str(e))
                raise

        return wrapper
    return decorator


# ── Exceptions ────────────────────────────────────────────────────────────

class ToolCallBlocked(Exception):
    """Raised when Vaara blocks a function call."""
    def __init__(self, message: str, action_id: str, risk_score: float):
        self.action_id = action_id
        self.risk_score = risk_score
        super().__init__(message)


class ToolCallEscalated(Exception):
    """Raised when Vaara escalates a function call."""
    def __init__(self, message: str, action_id: str, risk_score: float):
        self.action_id = action_id
        self.risk_score = risk_score
        super().__init__(message)
