"""Model Context Protocol (MCP) server for agent governance.

Exposes Vaara's interception pipeline as an MCP server so that AI agents
(Claude, GPT, Cursor, etc.) can discover and use Vaara governance as a
standard tool via the MCP protocol.

The MCP server provides three tools:
1. **vaara_check** — Score an action before execution (read-only assessment)
2. **vaara_intercept** — Full interception with audit trail (blocks/allows)
3. **vaara_report_outcome** — Report what happened after execution

And two resources:
1. **vaara://status** — Current scorer status, calibration state
2. **vaara://compliance** — Latest compliance assessment

This follows Microsoft's agent-mcp-governance pattern from the Agent
Governance Toolkit, but with Vaara's adaptive scorer instead of their
static policy engine.

Architecture::

    AI Agent (Claude, GPT, etc.)
        │
        ▼
    MCP Client (in agent framework)
        │  JSON-RPC over stdio/SSE
        ▼
    VaaraMCPServer
        │
        ▼
    InterceptionPipeline
        ├── ActionRegistry (classify)
        ├── AdaptiveScorer (risk score + conformal interval)
        ├── AuditTrail (hash-chained log)
        └── ComplianceEngine (EU AI Act, DORA)

Protocol: JSON-RPC 2.0 over stdio (default) or SSE.

Usage::

    # As a standalone MCP server
    python -m vaara.integrations.mcp_server

    # In Claude Code's .claude/settings.json:
    {
        "mcpServers": {
            "vaara": {
                "command": "python",
                "args": ["-m", "vaara.integrations.mcp_server"],
                "env": {"VAARA_DB": "/path/to/audit.db"}
            }
        }
    }

    # Programmatic usage
    from vaara.integrations.mcp_server import VaaraMCPServer
    server = VaaraMCPServer()
    server.run()

Reference: Model Context Protocol specification (modelcontextprotocol.io)
"""

from __future__ import annotations

import json
import logging
import os
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Optional

from vaara.audit.sqlite_backend import SQLiteAuditBackend
from vaara.pipeline import InterceptionPipeline
from vaara.taxonomy.actions import create_default_registry

logger = logging.getLogger(__name__)


# ── MCP Protocol Types ──────────────────────────────────────────────────
# These mirror the MCP spec without depending on any MCP SDK.

@dataclass
class MCPToolDefinition:
    """MCP tool definition — describes a callable tool to the client."""
    name: str
    description: str
    inputSchema: dict  # JSON Schema for parameters

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.inputSchema,
        }


@dataclass
class MCPResourceDefinition:
    """MCP resource definition — describes a readable resource."""
    uri: str
    name: str
    description: str
    mimeType: str = "application/json"

    def to_dict(self) -> dict:
        return {
            "uri": self.uri,
            "name": self.name,
            "description": self.description,
            "mimeType": self.mimeType,
        }


# ── Tool Definitions ────────────────────────────────────────────────────

VAARA_CHECK_TOOL = MCPToolDefinition(
    name="vaara_check",
    description=(
        "Check the risk level of an action BEFORE executing it. "
        "Returns a risk assessment with point estimate, conformal interval, "
        "and recommended decision (allow/deny/escalate). Does NOT record "
        "to the audit trail — use vaara_intercept for that."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "tool_name": {
                "type": "string",
                "description": "The tool/action to check (e.g., 'tx.transfer', 'data.delete')",
            },
            "agent_id": {
                "type": "string",
                "description": "Identifier for the agent requesting the action",
                "default": "mcp-agent",
            },
            "parameters": {
                "type": "object",
                "description": "Action parameters (optional, for context)",
                "default": {},
            },
            "confidence": {
                "type": "number",
                "description": "Agent's self-assessed confidence in the action (0.0-1.0)",
                "minimum": 0.0,
                "maximum": 1.0,
            },
        },
        "required": ["tool_name"],
    },
)

VAARA_INTERCEPT_TOOL = MCPToolDefinition(
    name="vaara_intercept",
    description=(
        "Intercept an action with full risk scoring and audit trail. "
        "Classifies the action, scores risk with conformal prediction, "
        "decides allow/deny/escalate, and records everything in a "
        "tamper-evident audit trail. Returns the decision and action_id "
        "for later outcome reporting."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "tool_name": {
                "type": "string",
                "description": "The tool/action to intercept",
            },
            "agent_id": {
                "type": "string",
                "description": "Identifier for the agent",
                "default": "mcp-agent",
            },
            "parameters": {
                "type": "object",
                "description": "Action parameters",
                "default": {},
            },
            "confidence": {
                "type": "number",
                "description": "Agent's self-assessed confidence (0.0-1.0)",
                "minimum": 0.0,
                "maximum": 1.0,
            },
            "session_id": {
                "type": "string",
                "description": "Session identifier for grouping related actions",
                "default": "",
            },
        },
        "required": ["tool_name"],
    },
)

VAARA_REPORT_TOOL = MCPToolDefinition(
    name="vaara_report_outcome",
    description=(
        "Report what happened after an action was executed. "
        "This closes the feedback loop — the scorer learns from outcomes "
        "to improve future risk assessments. Provide the action_id from "
        "vaara_intercept and the observed severity."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "action_id": {
                "type": "string",
                "description": "The action_id returned by vaara_intercept",
            },
            "outcome_severity": {
                "type": "number",
                "description": "How severe was the outcome? 0.0 = completely safe, 1.0 = catastrophic",
                "minimum": 0.0,
                "maximum": 1.0,
            },
            "description": {
                "type": "string",
                "description": "Human-readable description of what happened",
                "default": "",
            },
        },
        "required": ["action_id", "outcome_severity"],
    },
)


# ── Resource Definitions ────────────────────────────────────────────────

VAARA_STATUS_RESOURCE = MCPResourceDefinition(
    uri="vaara://status",
    name="Vaara Status",
    description="Current scorer status: calibration state, MWU weights, thresholds, tracked agents",
)

VAARA_COMPLIANCE_RESOURCE = MCPResourceDefinition(
    uri="vaara://compliance",
    name="Vaara Compliance Report",
    description="Latest EU AI Act and DORA compliance assessment against the audit trail",
)


# ── MCP Server ──────────────────────────────────────────────────────────

class VaaraMCPServer:
    """MCP server that exposes Vaara governance to AI agents.

    Handles JSON-RPC 2.0 messages over stdio.
    """

    SERVER_NAME = "vaara-governance"
    SERVER_VERSION = "0.3.0"

    def __init__(
        self,
        pipeline: Optional[InterceptionPipeline] = None,
        db_path: Optional[Path] = None,
    ) -> None:
        # Set up pipeline with optional SQLite persistence
        if pipeline is not None:
            self._pipeline = pipeline
            self._backend = None
        else:
            db = db_path or Path(os.environ.get("VAARA_DB", "vaara_audit.db"))
            self._backend = SQLiteAuditBackend(db)
            from vaara.audit.trail import AuditTrail
            trail = AuditTrail(on_record=self._backend.write_record)
            self._pipeline = InterceptionPipeline(trail=trail)

        self._tools = {
            "vaara_check": VAARA_CHECK_TOOL,
            "vaara_intercept": VAARA_INTERCEPT_TOOL,
            "vaara_report_outcome": VAARA_REPORT_TOOL,
        }
        self._resources = {
            "vaara://status": VAARA_STATUS_RESOURCE,
            "vaara://compliance": VAARA_COMPLIANCE_RESOURCE,
        }

    def handle_request(self, request: dict) -> dict:
        """Handle a single JSON-RPC 2.0 request."""
        method = request.get("method", "")
        params = request.get("params", {})
        req_id = request.get("id")

        try:
            if method == "initialize":
                result = self._handle_initialize(params)
            elif method == "tools/list":
                result = self._handle_tools_list()
            elif method == "tools/call":
                result = self._handle_tools_call(params)
            elif method == "resources/list":
                result = self._handle_resources_list()
            elif method == "resources/read":
                result = self._handle_resources_read(params)
            elif method == "ping":
                result = {}
            else:
                return self._error_response(req_id, -32601, f"Method not found: {method}")
        except Exception as e:
            logger.exception("Error handling %s", method)
            return self._error_response(req_id, -32603, str(e))

        return {"jsonrpc": "2.0", "id": req_id, "result": result}

    # ── Protocol handlers ────────────────────────────────────────

    def _handle_initialize(self, params: dict) -> dict:
        return {
            "protocolVersion": "2024-11-05",
            "serverInfo": {
                "name": self.SERVER_NAME,
                "version": self.SERVER_VERSION,
            },
            "capabilities": {
                "tools": {"listChanged": False},
                "resources": {"subscribe": False, "listChanged": False},
            },
        }

    def _handle_tools_list(self) -> dict:
        return {
            "tools": [t.to_dict() for t in self._tools.values()],
        }

    def _handle_tools_call(self, params: dict) -> dict:
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        if tool_name == "vaara_check":
            return self._call_check(arguments)
        elif tool_name == "vaara_intercept":
            return self._call_intercept(arguments)
        elif tool_name == "vaara_report_outcome":
            return self._call_report(arguments)
        else:
            raise ValueError(f"Unknown tool: {tool_name}")

    def _handle_resources_list(self) -> dict:
        return {
            "resources": [r.to_dict() for r in self._resources.values()],
        }

    def _handle_resources_read(self, params: dict) -> dict:
        uri = params.get("uri", "")
        if uri == "vaara://status":
            content = json.dumps(self._pipeline.status(), indent=2)
        elif uri == "vaara://compliance":
            report = self._pipeline.run_compliance_assessment(
                system_version=self.SERVER_VERSION,
            )
            content = json.dumps({
                "overall_status": report.overall_status.value,
                "system_name": report.system_name,
                "system_version": report.system_version,
                "generated_at": report.generated_at,
                "articles": [
                    {
                        "article": ev.requirement.article,
                        "title": ev.requirement.title,
                        "status": ev.status.value,
                        "evidence_count": ev.evidence_count,
                        "gaps": ev.gaps,
                        "recommendations": ev.recommendations,
                    }
                    for ev in report.articles
                ],
            }, indent=2)
        else:
            raise ValueError(f"Unknown resource: {uri}")

        return {
            "contents": [{
                "uri": uri,
                "mimeType": "application/json",
                "text": content,
            }],
        }

    # ── Tool implementations ─────────────────────────────────────

    def _call_check(self, args: dict) -> dict:
        """Read-only risk assessment — no audit trail."""
        tool_name = args.get("tool_name", "unknown")
        agent_id = args.get("agent_id", "mcp-agent")
        confidence = args.get("confidence")

        action_type = self._pipeline.registry.classify(tool_name)
        context = {
            "tool_name": tool_name,
            "agent_id": agent_id,
            "base_risk_score": action_type.base_risk_score,
            "agent_confidence": confidence,
            "reversibility": action_type.reversibility.value,
            "blast_radius": action_type.blast_radius.value,
        }
        scorer_result = self._pipeline.scorer.evaluate(context)

        raw = scorer_result.get("raw_result", {})
        interval = raw.get("conformal_interval", [0.2, 0.8])

        return {
            "content": [{
                "type": "text",
                "text": json.dumps({
                    "tool_name": tool_name,
                    "action_type": action_type.name,
                    "category": action_type.category.value,
                    "decision": scorer_result.get("action", "escalate"),
                    "risk_score": raw.get("point_estimate", 0.5),
                    "risk_interval": interval,
                    "base_risk": action_type.base_risk_score,
                    "calibrated": self._pipeline.scorer.is_calibrated,
                    "note": "Read-only check — use vaara_intercept for audited interception",
                }, indent=2),
            }],
        }

    def _call_intercept(self, args: dict) -> dict:
        """Full interception with audit trail."""
        result = self._pipeline.intercept(
            agent_id=args.get("agent_id", "mcp-agent"),
            tool_name=args.get("tool_name", "unknown"),
            parameters=args.get("parameters", {}),
            agent_confidence=args.get("confidence"),
            session_id=args.get("session_id", ""),
        )

        return {
            "content": [{
                "type": "text",
                "text": json.dumps({
                    "allowed": result.allowed,
                    "decision": result.decision,
                    "action_id": result.action_id,
                    "risk_score": result.risk_score,
                    "risk_interval": list(result.risk_interval),
                    "reason": result.reason,
                    "action_type": result.action_type.name,
                    "evaluation_ms": round(result.evaluation_ms, 2),
                }, indent=2),
            }],
            "isError": not result.allowed and result.decision == "deny",
        }

    def _call_report(self, args: dict) -> dict:
        """Report outcome for learning."""
        action_id = args.get("action_id", "")
        severity = args.get("outcome_severity", 0.0)
        description = args.get("description", "")

        self._pipeline.report_outcome(
            action_id=action_id,
            outcome_severity=severity,
            description=description,
        )

        return {
            "content": [{
                "type": "text",
                "text": json.dumps({
                    "recorded": True,
                    "action_id": action_id,
                    "outcome_severity": severity,
                    "calibration_size": self._pipeline.scorer.calibration_size,
                }, indent=2),
            }],
        }

    # ── JSON-RPC helpers ─────────────────────────────────────────

    @staticmethod
    def _error_response(req_id: Any, code: int, message: str) -> dict:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": code, "message": message},
        }

    # ── stdio transport ──────────────────────────────────────────

    def run(self) -> None:
        """Run the MCP server on stdio (JSON-RPC over stdin/stdout)."""
        logger.info("Vaara MCP server starting on stdio")

        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                request = json.loads(line)
            except json.JSONDecodeError:
                response = self._error_response(None, -32700, "Parse error")
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()
                continue

            response = self.handle_request(request)
            sys.stdout.write(json.dumps(response) + "\n")
            sys.stdout.flush()

    def close(self) -> None:
        """Clean up resources."""
        if self._backend is not None:
            self._backend.close()


# ── CLI entry point ─────────────────────────────────────────────────────

def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        stream=sys.stderr,  # Logs go to stderr, JSON-RPC goes to stdout
    )
    server = VaaraMCPServer()
    try:
        server.run()
    finally:
        server.close()


if __name__ == "__main__":
    main()
