"""Adaptive risk scorer with conformal prediction and MWU learning.

This is the core differentiator — Microsoft's toolkit is rule-based with
static thresholds.  Vaara adds:

1. **Conformal prediction** (Angelopoulos & Bates 2022) — distribution-free
   coverage guarantees on risk scores.  The scorer wraps its point estimate
   in a prediction set that contains the true risk with probability >= 1-alpha.
   No distributional assumptions, no retraining needed when the world shifts.

2. **Multiplicative Weight Update (MWU)** — online learning that adapts
   expert weights from action outcomes.  Each "expert" is a risk signal
   (taxonomy base score, sequence pattern, agent history, etc.).  MWU
   tracks which signals actually predict bad outcomes and up-weights them.

3. **Temporal sequence reasoning** — individual actions may be safe but
   sequences can be catastrophic (e.g., read_data → export → delete is a
   data exfiltration pattern even if each action alone is benign).

4. **Cold start → learned transition** — starts with rule-based scoring,
   accumulates calibration data, flips to conformal-wrapped ML scoring
   once coverage guarantee can be maintained.

Implements Microsoft Agent Governance Toolkit's ``ExternalPolicyBackend``
protocol so it plugs directly into their PolicyEvaluator chain.
"""

from __future__ import annotations

import logging
import math
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from vaara.taxonomy.actions import (
    ActionCategory,
    ActionRequest,
    ActionType,
    BlastRadius,
    Reversibility,
    UrgencyClass,
)

logger = logging.getLogger(__name__)


# ── Decision types ────────────────────────────────────────────────────────

class Decision(str, Enum):
    """Scorer decision — compatible with MS toolkit policy actions."""
    ALLOW = "allow"
    DENY = "deny"
    ESCALATE = "escalate"  # Human review required


@dataclass
class RiskAssessment:
    """Full risk assessment for an action request.

    Carries the point estimate, conformal interval, contributing signals,
    and the final decision with thresholds used.
    """
    action_name: str
    agent_id: str
    point_estimate: float          # Combined risk score, 0.0-1.0
    conformal_lower: float         # Lower bound of prediction interval
    conformal_upper: float         # Upper bound — this drives the decision
    decision: Decision
    signals: dict[str, float]      # Named signal contributions
    mwu_weights: dict[str, float]  # Current expert weights (snapshot)
    threshold_allow: float         # Score below this → allow
    threshold_deny: float          # Score above this → deny (between = escalate)
    sequence_risk: float           # Contribution from temporal patterns
    calibration_size: int          # How many calibration points we have
    evaluation_ms: float = 0.0
    explanation: str = ""

    def to_backend_decision(self) -> dict:
        """Convert to MS toolkit BackendDecision-compatible dict."""
        return {
            "allowed": self.decision == Decision.ALLOW,
            "action": self.decision.value,
            "reason": self.explanation,
            "backend": "vaara_adaptive",
            "raw_result": {
                "point_estimate": self.point_estimate,
                "conformal_interval": [self.conformal_lower, self.conformal_upper],
                "signals": self.signals,
                "sequence_risk": self.sequence_risk,
                "calibration_size": self.calibration_size,
            },
            "evaluation_ms": self.evaluation_ms,
            "error": None,
        }


# ── Sequence pattern detection ────────────────────────────────────────────

@dataclass(frozen=True)
class SequencePattern:
    """A dangerous action sequence pattern.

    Matches ordered subsequences within a sliding window.
    """
    name: str
    actions: tuple[str, ...]       # Ordered action names to match
    risk_boost: float              # Additive risk when pattern detected
    window_size: int = 10          # How many recent actions to scan
    description: str = ""


# Built-in dangerous sequences — extensible at runtime
BUILTIN_SEQUENCES = [
    SequencePattern(
        "data_exfiltration",
        ("data.read", "data.export"),
        risk_boost=0.4,
        window_size=5,
        description="Read then export — possible data exfiltration",
    ),
    SequencePattern(
        "data_destruction",
        ("data.read", "data.delete"),
        risk_boost=0.3,
        window_size=5,
        description="Read then delete — possible evidence destruction",
    ),
    SequencePattern(
        "privilege_escalation",
        ("id.create_key", "id.grant_permission"),
        risk_boost=0.5,
        window_size=5,
        description="Create credential then grant permissions — privilege escalation",
    ),
    SequencePattern(
        "financial_drain",
        ("tx.approve", "tx.swap", "tx.transfer"),
        risk_boost=0.6,
        window_size=8,
        description="Approve → swap → transfer — possible fund drainage",
    ),
    SequencePattern(
        "governance_takeover",
        ("id.grant_permission", "gov.vote", "gov.execute_proposal"),
        risk_boost=0.7,
        window_size=10,
        description="Grant access → vote → execute — governance capture",
    ),
    SequencePattern(
        "safety_override_sequence",
        ("infra.config_change", "phy.safety_override"),
        risk_boost=0.8,
        window_size=5,
        description="Config change then safety override — disabling safeguards",
    ),
    SequencePattern(
        "rapid_rebalance",
        ("vault.rebalance", "vault.rebalance"),
        risk_boost=0.3,
        window_size=4,
        description="Repeated rebalance — possible wash trading or manipulation",
    ),
]


# ── MWU Expert System ────────────────────────────────────────────────────

class MWUExperts:
    """Multiplicative Weight Update for online expert aggregation.

    Each expert produces a risk signal in [0, 1].  MWU maintains weights
    that reflect each expert's historical accuracy.  Experts that predicted
    bad outcomes correctly get up-weighted; those that missed get penalized.

    Reference: Arora, Hazan & Kale (2012), "The Multiplicative Weights
    Update Method: a Meta-Algorithm and Applications"
    """

    def __init__(
        self,
        expert_names: list[str],
        eta: float = 0.1,
        min_weight: float = 0.01,
    ) -> None:
        self._eta = eta                # Learning rate
        self._min_weight = min_weight  # Floor to prevent expert death
        self._weights: dict[str, float] = {
            name: 1.0 / len(expert_names) for name in expert_names
        }
        self._update_count = 0

    @property
    def weights(self) -> dict[str, float]:
        return dict(self._weights)

    @property
    def update_count(self) -> int:
        return self._update_count

    def predict(self, signals: dict[str, float]) -> float:
        """Weighted combination of expert signals."""
        total_weight = sum(self._weights.values())
        if total_weight == 0:
            return 0.5

        score = 0.0
        for name, signal in signals.items():
            if name in self._weights:
                score += (self._weights[name] / total_weight) * signal
        return min(1.0, max(0.0, score))

    def update(self, signals: dict[str, float], outcome: float) -> None:
        """Update weights based on observed outcome.

        Args:
            signals: Expert predictions at decision time.
            outcome: Actual risk realized (0.0 = nothing bad, 1.0 = catastrophic).
                     This is set by the audit trail when action consequences are known.
        """
        for name, signal in signals.items():
            if name not in self._weights:
                continue
            # Loss = |prediction - outcome|.  High loss → weight decreases.
            loss = abs(signal - outcome)
            self._weights[name] *= math.exp(-self._eta * loss)
            self._weights[name] = max(self._min_weight, self._weights[name])

        # Re-normalize
        total = sum(self._weights.values())
        if total > 0:
            for name in self._weights:
                self._weights[name] /= total

        self._update_count += 1


# ── Conformal Prediction ─────────────────────────────────────────────────

class ConformalCalibrator:
    """Split conformal prediction for risk score intervals.

    Maintains a calibration set of (predicted_risk, actual_outcome) pairs.
    Produces prediction intervals that contain the true risk with
    probability >= 1 - alpha, with no distributional assumptions.

    Uses FACI-style adaptive alpha when enough data is available:
    the effective alpha tracks coverage errors online, tightening when
    the interval misses and loosening when it's too conservative.

    Reference:
    - Vovk, Gammerman & Shafer (2005), "Algorithmic Learning in a Random World"
    - Gibbs & Candes (2021), "Adaptive Conformal Inference Under Distribution Shift"
    """

    def __init__(
        self,
        alpha: float = 0.10,        # Target miscoverage rate (10%)
        min_calibration: int = 30,   # Min points before conformal kicks in
        max_calibration: int = 2000, # Rolling window size
        gamma: float = 0.005,        # FACI step size for adaptive alpha
    ) -> None:
        self._alpha = alpha
        self._alpha_t = alpha         # Adaptive alpha (FACI)
        self._min_calibration = min_calibration
        self._max_calibration = max_calibration
        self._gamma = gamma
        # Calibration residuals: |predicted - actual|
        self._residuals: deque[float] = deque(maxlen=max_calibration)

    @property
    def calibration_size(self) -> int:
        return len(self._residuals)

    @property
    def is_calibrated(self) -> bool:
        return len(self._residuals) >= self._min_calibration

    @property
    def effective_alpha(self) -> float:
        return self._alpha_t

    def add_calibration_point(self, predicted: float, actual: float) -> None:
        """Add a (predicted, actual) pair to the calibration set.

        Called by the audit trail when action outcomes are known.
        """
        residual = abs(predicted - actual)
        self._residuals.append(residual)

        # FACI adaptive alpha update
        if self.is_calibrated:
            # err_t = 1 if actual was outside the interval we would have produced
            quantile = self._get_quantile()
            covered = residual <= quantile
            err_t = 0.0 if covered else 1.0
            # alpha_t+1 = alpha_t + gamma * (alpha - err_t)
            self._alpha_t = self._alpha_t + self._gamma * (self._alpha - err_t)
            self._alpha_t = min(0.5, max(0.001, self._alpha_t))

    def _get_quantile(self) -> float:
        """Conformal quantile from calibration residuals."""
        if not self._residuals:
            return 1.0
        sorted_residuals = sorted(self._residuals)
        n = len(sorted_residuals)
        # Quantile level: ceil((1 - alpha)(n + 1)) / n
        level = math.ceil((1 - self._alpha_t) * (n + 1)) / n
        level = min(1.0, level)
        idx = min(int(level * n), n - 1)
        return sorted_residuals[idx]

    def predict_interval(self, point_estimate: float) -> tuple[float, float]:
        """Produce a conformal prediction interval around the point estimate.

        Returns (lower, upper) where true risk is in [lower, upper]
        with probability >= 1 - alpha.
        """
        if not self.is_calibrated:
            # Not enough data — return conservative interval
            return (max(0.0, point_estimate - 0.3), min(1.0, point_estimate + 0.3))

        q = self._get_quantile()
        lower = max(0.0, point_estimate - q)
        upper = min(1.0, point_estimate + q)
        return (lower, upper)


# ── Agent History Tracker ─────────────────────────────────────────────────

@dataclass
class AgentProfile:
    """Running profile of an agent's behavior."""
    agent_id: str
    total_actions: int = 0
    denied_actions: int = 0
    escalated_actions: int = 0
    bad_outcomes: int = 0        # Actions that resulted in harm
    action_counts: dict[str, int] = field(default_factory=dict)
    recent_actions: deque = field(default_factory=lambda: deque(maxlen=50))
    first_seen: float = 0.0
    last_seen: float = 0.0

    @property
    def denial_rate(self) -> float:
        if self.total_actions == 0:
            return 0.0
        return self.denied_actions / self.total_actions

    @property
    def bad_outcome_rate(self) -> float:
        if self.total_actions == 0:
            return 0.0
        return self.bad_outcomes / self.total_actions

    @property
    def age_seconds(self) -> float:
        if self.first_seen == 0:
            return 0.0
        return self.last_seen - self.first_seen

    def record_action(self, action_name: str, timestamp: float) -> None:
        self.total_actions += 1
        self.action_counts[action_name] = self.action_counts.get(action_name, 0) + 1
        self.recent_actions.append((action_name, timestamp))
        if self.first_seen == 0:
            self.first_seen = timestamp
        self.last_seen = timestamp


# ── Main Scorer ───────────────────────────────────────────────────────────

# Default expert names — each produces a [0, 1] risk signal
DEFAULT_EXPERTS = [
    "taxonomy_base",      # From ActionType.base_risk_score
    "agent_history",      # From agent's denial/outcome history
    "sequence_pattern",   # From temporal sequence matching
    "action_frequency",   # Burst detection — too many actions too fast
    "confidence_gap",     # Agent's self-reported confidence vs observed accuracy
]


class AdaptiveScorer:
    """Adaptive risk scorer with conformal guarantees.

    Implements Microsoft Agent Governance Toolkit's ``ExternalPolicyBackend``
    protocol so it can be registered directly with their ``PolicyEvaluator``.

    Lifecycle:
        1. **Cold start** — uses taxonomy base scores + rules
        2. **Calibrating** — accumulates outcome data, builds conformal set
        3. **Adaptive** — MWU-weighted experts wrapped in conformal intervals

    Usage with MS toolkit::

        from agent_os.policies.evaluator import PolicyEvaluator
        from vaara.scorer.adaptive import AdaptiveScorer

        scorer = AdaptiveScorer()
        evaluator = PolicyEvaluator()
        evaluator.add_backend(scorer)

        # Now evaluator.evaluate(context) will call scorer.evaluate(context)
    """

    def __init__(
        self,
        threshold_allow: float = 0.3,
        threshold_deny: float = 0.7,
        alpha: float = 0.10,
        mwu_eta: float = 0.1,
        sequence_patterns: Optional[list[SequencePattern]] = None,
        burst_window_seconds: float = 60.0,
        burst_threshold: int = 10,
    ) -> None:
        """
        Args:
            threshold_allow: Risk scores below this → ALLOW.
            threshold_deny:  Risk scores above this → DENY.
                             Between allow and deny → ESCALATE for human review.
            alpha: Conformal miscoverage rate (0.10 = 90% coverage guarantee).
            mwu_eta: MWU learning rate.
            sequence_patterns: Dangerous action sequences to detect.
            burst_window_seconds: Window for burst detection.
            burst_threshold: Max actions in burst window before flagging.
        """
        self._threshold_allow = threshold_allow
        self._threshold_deny = threshold_deny
        self._burst_window = burst_window_seconds
        self._burst_threshold = burst_threshold

        # MWU expert system
        self._mwu = MWUExperts(DEFAULT_EXPERTS, eta=mwu_eta)

        # Conformal calibrator
        self._conformal = ConformalCalibrator(alpha=alpha)

        # Sequence patterns
        self._sequences = list(sequence_patterns or BUILTIN_SEQUENCES)

        # Agent profiles (agent_id → AgentProfile)
        self._agents: dict[str, AgentProfile] = {}

        # Global action history for cross-agent sequence detection
        self._global_history: deque[tuple[str, str, float]] = deque(maxlen=200)

    # ── MS Toolkit Protocol ───────────────────────────────────────

    @property
    def name(self) -> str:
        """ExternalPolicyBackend.name — identifies this backend."""
        return "vaara_adaptive"

    def evaluate(self, context: dict[str, Any]) -> Any:
        """ExternalPolicyBackend.evaluate — the MS toolkit calls this.

        Accepts the toolkit's context dict and returns a BackendDecision-
        compatible object.  We return a dict that BackendDecision(**result)
        would accept, keeping us decoupled from their import.

        Args:
            context: Dict with tool_name, agent_id, action_type,
                     base_risk_score, agent_confidence, etc.
                     (produced by ActionRequest.to_policy_context())
        """
        start = time.monotonic()

        # Extract fields from MS toolkit context
        tool_name = context.get("tool_name", "unknown")
        agent_id = context.get("agent_id", "anonymous")
        base_risk = context.get("base_risk_score", 0.5)
        agent_confidence = context.get("agent_confidence")
        reversibility = context.get("reversibility", "partially_reversible")
        blast_radius = context.get("blast_radius", "local")

        # Build risk signals from each expert
        signals = self._compute_signals(
            tool_name=tool_name,
            agent_id=agent_id,
            base_risk=base_risk,
            agent_confidence=agent_confidence,
            reversibility=reversibility,
            blast_radius=blast_radius,
        )

        # MWU-weighted combination
        point_estimate = self._mwu.predict(signals)

        # Conformal interval
        lower, upper = self._conformal.predict_interval(point_estimate)

        # Decision uses the UPPER bound — conservative by design.
        # If the worst-case (within 1-alpha confidence) is safe, allow it.
        # If the best-case is dangerous, deny it.
        decision_score = upper
        if decision_score < self._threshold_allow:
            decision = Decision.ALLOW
        elif decision_score > self._threshold_deny:
            decision = Decision.DENY
        else:
            decision = Decision.ESCALATE

        # Record this action in agent profile
        now = time.time()
        profile = self._get_or_create_agent(agent_id)
        profile.record_action(tool_name, now)
        if decision == Decision.DENY:
            profile.denied_actions += 1
        elif decision == Decision.ESCALATE:
            profile.escalated_actions += 1

        # Record in global history
        self._global_history.append((agent_id, tool_name, now))

        elapsed_ms = (time.monotonic() - start) * 1000

        explanation = (
            f"{decision.value}: risk={point_estimate:.3f} "
            f"[{lower:.3f}, {upper:.3f}] "
            f"(threshold allow<{self._threshold_allow} deny>{self._threshold_deny})"
        )

        assessment = RiskAssessment(
            action_name=tool_name,
            agent_id=agent_id,
            point_estimate=point_estimate,
            conformal_lower=lower,
            conformal_upper=upper,
            decision=decision,
            signals=signals,
            mwu_weights=self._mwu.weights,
            threshold_allow=self._threshold_allow,
            threshold_deny=self._threshold_deny,
            sequence_risk=signals.get("sequence_pattern", 0.0),
            calibration_size=self._conformal.calibration_size,
            evaluation_ms=elapsed_ms,
            explanation=explanation,
        )

        logger.info(
            "Scored %s/%s: %s (%.1fms)",
            agent_id, tool_name, decision.value, elapsed_ms,
        )

        # Return MS-compatible dict
        return assessment.to_backend_decision()

    # ── Signal computation ────────────────────────────────────────

    def _compute_signals(
        self,
        tool_name: str,
        agent_id: str,
        base_risk: float,
        agent_confidence: Optional[float],
        reversibility: str,
        blast_radius: str,
    ) -> dict[str, float]:
        """Compute risk signals from each expert."""
        signals: dict[str, float] = {}

        # Expert 1: Taxonomy base risk (from ActionType metadata)
        signals["taxonomy_base"] = base_risk

        # Expert 2: Agent history
        signals["agent_history"] = self._agent_history_signal(agent_id)

        # Expert 3: Temporal sequence patterns
        signals["sequence_pattern"] = self._sequence_signal(agent_id, tool_name)

        # Expert 4: Action frequency / burst detection
        signals["action_frequency"] = self._burst_signal(agent_id)

        # Expert 5: Confidence gap
        signals["confidence_gap"] = self._confidence_gap_signal(
            agent_confidence, base_risk
        )

        return signals

    def _agent_history_signal(self, agent_id: str) -> float:
        """Risk signal from agent's track record."""
        profile = self._agents.get(agent_id)
        if profile is None or profile.total_actions < 5:
            return 0.3  # Unknown agent = moderate risk (not zero, not high)

        # Blend denial rate and bad outcome rate
        # Bad outcomes weigh 3x more than denials (denials might be overly cautious)
        risk = 0.3 * profile.denial_rate + 0.7 * profile.bad_outcome_rate

        # New agents get a slight risk premium that decays with track record
        age_discount = min(1.0, profile.total_actions / 100)
        risk = risk * age_discount + 0.2 * (1 - age_discount)

        return min(1.0, max(0.0, risk))

    def _sequence_signal(self, agent_id: str, current_tool: str) -> float:
        """Detect dangerous action sequences in recent history."""
        profile = self._agents.get(agent_id)
        if profile is None:
            return 0.0

        recent = list(profile.recent_actions)
        # Append current action for matching
        recent_names = [name for name, _ in recent] + [current_tool]

        max_boost = 0.0
        for pattern in self._sequences:
            if self._matches_subsequence(
                recent_names[-pattern.window_size:], pattern.actions
            ):
                max_boost = max(max_boost, pattern.risk_boost)
                logger.warning(
                    "Sequence pattern '%s' detected for agent %s",
                    pattern.name, agent_id,
                )

        return min(1.0, max_boost)

    @staticmethod
    def _matches_subsequence(history: list[str], pattern: tuple[str, ...]) -> bool:
        """Check if pattern appears as an ordered subsequence in history."""
        if not pattern:
            return False
        pi = 0
        for action in history:
            if action == pattern[pi]:
                pi += 1
                if pi == len(pattern):
                    return True
        return False

    def _burst_signal(self, agent_id: str) -> float:
        """Detect action bursts — too many actions in a short window."""
        now = time.time()
        cutoff = now - self._burst_window
        profile = self._agents.get(agent_id)
        if profile is None:
            return 0.0

        recent_count = sum(
            1 for _, ts in profile.recent_actions if ts > cutoff
        )

        if recent_count <= self._burst_threshold // 2:
            return 0.0
        elif recent_count <= self._burst_threshold:
            # Linear ramp from 0 to 0.5
            ratio = (recent_count - self._burst_threshold // 2) / (
                self._burst_threshold // 2
            )
            return 0.5 * ratio
        else:
            # Over threshold — high risk, capped at 0.9
            over = recent_count - self._burst_threshold
            return min(0.9, 0.5 + 0.1 * over)

    def _confidence_gap_signal(
        self, agent_confidence: Optional[float], base_risk: float
    ) -> float:
        """Risk from gap between agent's self-reported confidence and base risk.

        If an agent claims high confidence on a high-base-risk action,
        something is off — either the agent is miscalibrated or gaming the system.
        Conversely, low confidence on a low-risk action is fine.
        """
        if agent_confidence is None:
            return 0.2  # No confidence reported = slight risk

        # Confidence is [0, 1] where 1 = "I'm sure this is safe"
        # Base risk is [0, 1] where 1 = "this action type is dangerous"
        # A gap where confidence is high but risk is high is suspicious
        gap = max(0.0, agent_confidence - (1.0 - base_risk))
        return min(1.0, gap)

    # ── Agent management ──────────────────────────────────────────

    def _get_or_create_agent(self, agent_id: str) -> AgentProfile:
        if agent_id not in self._agents:
            self._agents[agent_id] = AgentProfile(agent_id=agent_id)
        return self._agents[agent_id]

    def get_agent_profile(self, agent_id: str) -> Optional[AgentProfile]:
        """Get an agent's profile (read-only access for dashboards)."""
        return self._agents.get(agent_id)

    # ── Learning interface (called by audit trail) ────────────────

    def record_outcome(
        self,
        agent_id: str,
        tool_name: str,
        predicted_risk: float,
        actual_outcome: float,
        signals: dict[str, float],
    ) -> None:
        """Record the actual outcome of an action for learning.

        Called by the audit trail when an action's consequences are known.
        Updates both MWU weights and conformal calibration.

        Args:
            agent_id: The agent that took the action.
            tool_name: The tool/action name.
            predicted_risk: What we predicted at decision time.
            actual_outcome: What actually happened (0.0 safe, 1.0 catastrophic).
            signals: The expert signals at decision time (for MWU update).
        """
        # Update MWU expert weights
        self._mwu.update(signals, actual_outcome)

        # Update conformal calibration set
        self._conformal.add_calibration_point(predicted_risk, actual_outcome)

        # Update agent profile
        profile = self._get_or_create_agent(agent_id)
        if actual_outcome > 0.5:
            profile.bad_outcomes += 1

        logger.info(
            "Outcome recorded: %s/%s predicted=%.3f actual=%.3f "
            "(calibration=%d, mwu_updates=%d)",
            agent_id, tool_name, predicted_risk, actual_outcome,
            self._conformal.calibration_size, self._mwu.update_count,
        )

    # ── Sequence pattern management ───────────────────────────────

    def add_sequence_pattern(self, pattern: SequencePattern) -> None:
        """Register a new dangerous sequence pattern."""
        self._sequences.append(pattern)

    def remove_sequence_pattern(self, name: str) -> bool:
        """Remove a sequence pattern by name."""
        before = len(self._sequences)
        self._sequences = [p for p in self._sequences if p.name != name]
        return len(self._sequences) < before

    # ── Introspection ─────────────────────────────────────────────

    @property
    def is_calibrated(self) -> bool:
        """Whether we have enough data for conformal guarantees."""
        return self._conformal.is_calibrated

    @property
    def calibration_size(self) -> int:
        return self._conformal.calibration_size

    @property
    def mwu_weights(self) -> dict[str, float]:
        return self._mwu.weights

    @property
    def mwu_update_count(self) -> int:
        return self._mwu.update_count

    @property
    def thresholds(self) -> tuple[float, float]:
        return (self._threshold_allow, self._threshold_deny)

    def status(self) -> dict[str, Any]:
        """Dashboard-friendly status snapshot."""
        return {
            "calibrated": self.is_calibrated,
            "calibration_size": self.calibration_size,
            "effective_alpha": self._conformal.effective_alpha,
            "mwu_weights": self.mwu_weights,
            "mwu_updates": self.mwu_update_count,
            "thresholds": {"allow": self._threshold_allow, "deny": self._threshold_deny},
            "tracked_agents": len(self._agents),
            "sequence_patterns": len(self._sequences),
        }


# ── Factory ───────────────────────────────────────────────────────────────

def create_default_scorer(**kwargs: Any) -> AdaptiveScorer:
    """Create a scorer with production defaults."""
    return AdaptiveScorer(**kwargs)
