"""Compliance engine — conformity assessment against EU AI Act and other regulations.

This module takes the audit trail as input and produces:

1. **Article-by-article evidence mapping**: For each relevant regulatory article,
   which audit records provide evidence of compliance.
2. **Coverage analysis**: Which articles have evidence vs which have gaps.
3. **Conformity assessment reports**: Structured reports suitable for
   notified bodies, internal audit, and regulatory submission.

Supported regulatory frameworks:
- EU AI Act (Articles 9, 11-15, 17, 61) — high-risk AI system requirements
- DORA (Articles 10, 12, 13) — ICT risk management for financial entities
- NIS2 — network and information security
- GDPR (data protection impact assessments)
- MiFID II (algorithmic trading compliance)

The engine is declarative — it doesn't know what "good" looks like in absolute
terms.  Instead, it maps evidence to requirements and flags where evidence
is missing, insufficient, or stale.

EU AI Act enforcement for high-risk systems: August 2, 2026.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from vaara.audit.trail import AuditTrail, EventType
from vaara.taxonomy.actions import RegulatoryDomain

import logging

logger = logging.getLogger(__name__)


# ── Compliance status ─────────────────────────────────────────────────────

class ComplianceStatus(str, Enum):
    """Status of compliance with a specific article."""
    COMPLIANT = "compliant"           # Evidence present and sufficient
    PARTIAL = "partial"               # Some evidence, gaps remain
    NON_COMPLIANT = "non_compliant"   # No evidence or critical gaps
    NOT_APPLICABLE = "not_applicable" # Article doesn't apply to this system


class EvidenceStrength(str, Enum):
    """How strong is the evidence for a compliance claim."""
    STRONG = "strong"         # Continuous, automated, verifiable
    MODERATE = "moderate"     # Present but manual or intermittent
    WEAK = "weak"             # Indirect or insufficient
    ABSENT = "absent"         # No evidence


# ── Regulatory requirement definitions ────────────────────────────────────

@dataclass(frozen=True)
class RegulatoryRequirement:
    """A specific regulatory requirement to check compliance against."""
    domain: RegulatoryDomain
    article: str
    title: str
    description: str
    evidence_event_types: tuple[EventType, ...]  # Which events provide evidence
    min_evidence_count: int = 1                  # Minimum records needed
    staleness_hours: float = 720.0               # Evidence older than this = stale (30 days)
    is_critical: bool = False                    # True = blocks conformity if missing


# EU AI Act requirements for high-risk AI systems
EU_AI_ACT_REQUIREMENTS = [
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 9(1)",
        "Risk Management System",
        "A risk management system shall be established, implemented, documented and maintained",
        (EventType.RISK_SCORED,),
        min_evidence_count=10,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 9(2)(a)",
        "Risk Identification and Analysis",
        "Identification and analysis of known and reasonably foreseeable risks",
        (EventType.RISK_SCORED, EventType.ACTION_BLOCKED),
        min_evidence_count=5,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 9(4)(a)",
        "Risk Mitigation Measures",
        "Elimination or reduction of risks as far as possible through adequate design and development",
        (EventType.ACTION_BLOCKED, EventType.DECISION_MADE),
        min_evidence_count=3,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 9(7)",
        "Testing Procedures",
        "Testing shall be suitable to identify relevant risks and use appropriately precise metrics",
        (EventType.RISK_SCORED, EventType.OUTCOME_RECORDED),
        min_evidence_count=10,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 11(1)",
        "Technical Documentation",
        "Technical documentation shall be drawn up before the system is placed on the market",
        (),  # Checked separately — docs exist outside audit trail
        min_evidence_count=0,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 12(1)",
        "Record-Keeping (Logging)",
        "High-risk AI systems shall technically allow for the automatic recording of events",
        (EventType.ACTION_REQUESTED, EventType.RISK_SCORED, EventType.DECISION_MADE),
        min_evidence_count=20,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 13(1)",
        "Transparency and Provision of Information",
        "High-risk AI systems shall be designed and developed to ensure their operation is sufficiently transparent",
        (EventType.RISK_SCORED, EventType.DECISION_MADE),
        min_evidence_count=5,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 14(1)",
        "Human Oversight — Design",
        "High-risk AI systems shall be designed to be effectively overseen by natural persons",
        (EventType.ESCALATION_SENT, EventType.ESCALATION_RESOLVED),
        min_evidence_count=1,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 14(4)(d)",
        "Human Oversight — Override Capability",
        "The human shall be able to decide not to use the system or to override the output",
        (EventType.ESCALATION_RESOLVED, EventType.POLICY_OVERRIDE),
        min_evidence_count=1,
        is_critical=False,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 15(1)",
        "Accuracy, Robustness and Cybersecurity",
        "High-risk AI systems shall be designed to achieve appropriate levels of accuracy",
        (EventType.OUTCOME_RECORDED,),
        min_evidence_count=10,
        staleness_hours=168.0,  # Weekly calibration
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.EU_AI_ACT,
        "Article 61(1)",
        "Post-Market Monitoring",
        "Providers shall establish a post-market monitoring system proportionate to the nature of the AI",
        (EventType.OUTCOME_RECORDED,),
        min_evidence_count=20,
        is_critical=True,
    ),
]

DORA_REQUIREMENTS = [
    RegulatoryRequirement(
        RegulatoryDomain.DORA,
        "Article 10(1)",
        "ICT Risk Management — Protection and Prevention",
        "Financial entities shall have ICT security policies and mechanisms for protection and prevention",
        (EventType.ACTION_BLOCKED, EventType.DECISION_MADE),
        min_evidence_count=5,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.DORA,
        "Article 12(1)",
        "ICT Incident Detection",
        "Financial entities shall have ICT-related incident detection capabilities with automated alert mechanisms",
        (EventType.ACTION_REQUESTED, EventType.ACTION_BLOCKED),
        min_evidence_count=10,
        is_critical=True,
    ),
    RegulatoryRequirement(
        RegulatoryDomain.DORA,
        "Article 13(1)",
        "ICT Incident Response and Learning",
        "Financial entities shall put in place response and recovery plans that include learning and evolving",
        (EventType.OUTCOME_RECORDED,),
        min_evidence_count=5,
        is_critical=False,
    ),
]


# ── Evidence assessment ───────────────────────────────────────────────────

@dataclass
class ArticleEvidence:
    """Evidence assessment for a single regulatory article."""
    requirement: RegulatoryRequirement
    status: ComplianceStatus
    strength: EvidenceStrength
    evidence_count: int
    freshest_evidence_age_hours: float
    oldest_evidence_age_hours: float
    sample_record_ids: list[str] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "domain": self.requirement.domain.value,
            "article": self.requirement.article,
            "title": self.requirement.title,
            "status": self.status.value,
            "strength": self.strength.value,
            "evidence_count": self.evidence_count,
            "freshest_evidence_age_hours": round(self.freshest_evidence_age_hours, 1),
            "oldest_evidence_age_hours": round(self.oldest_evidence_age_hours, 1),
            "gaps": self.gaps,
            "recommendations": self.recommendations,
            "sample_record_ids": self.sample_record_ids[:5],
        }


@dataclass
class ConformityReport:
    """Full conformity assessment report."""
    generated_at: float
    system_name: str
    system_version: str
    overall_status: ComplianceStatus
    critical_gaps: list[str]
    articles: list[ArticleEvidence]
    summary: str
    trail_size: int
    trail_chain_intact: bool

    def to_dict(self) -> dict:
        return {
            "generated_at": self.generated_at,
            "generated_at_iso": time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.generated_at)
            ),
            "system_name": self.system_name,
            "system_version": self.system_version,
            "overall_status": self.overall_status.value,
            "critical_gaps": self.critical_gaps,
            "trail_integrity": {
                "size": self.trail_size,
                "chain_intact": self.trail_chain_intact,
            },
            "articles": [a.to_dict() for a in self.articles],
            "summary": self.summary,
        }

    @property
    def narrative(self) -> str:
        """Human-readable conformity assessment narrative."""
        ts = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(self.generated_at))
        lines = [
            f"CONFORMITY ASSESSMENT REPORT",
            f"System: {self.system_name} v{self.system_version}",
            f"Generated: {ts}",
            f"Overall Status: {self.overall_status.value.upper()}",
            f"Audit Trail: {self.trail_size} records, "
            f"chain {'INTACT' if self.trail_chain_intact else 'BROKEN'}",
            "",
        ]

        if self.critical_gaps:
            lines.append("CRITICAL GAPS:")
            for gap in self.critical_gaps:
                lines.append(f"  - {gap}")
            lines.append("")

        # Group by domain
        by_domain: dict[str, list[ArticleEvidence]] = {}
        for article in self.articles:
            domain = article.requirement.domain.value
            by_domain.setdefault(domain, []).append(article)

        for domain, articles in sorted(by_domain.items()):
            lines.append(f"--- {domain.upper()} ---")
            for art in articles:
                status_icon = {
                    ComplianceStatus.COMPLIANT: "[OK]",
                    ComplianceStatus.PARTIAL: "[!!]",
                    ComplianceStatus.NON_COMPLIANT: "[XX]",
                    ComplianceStatus.NOT_APPLICABLE: "[--]",
                }[art.status]
                lines.append(
                    f"  {status_icon} {art.requirement.article}: "
                    f"{art.requirement.title}"
                )
                lines.append(
                    f"       Evidence: {art.evidence_count} records, "
                    f"strength={art.strength.value}"
                )
                if art.gaps:
                    for gap in art.gaps:
                        lines.append(f"       Gap: {gap}")
                if art.recommendations:
                    for rec in art.recommendations:
                        lines.append(f"       Rec: {rec}")
            lines.append("")

        lines.append(f"SUMMARY: {self.summary}")
        return "\n".join(lines)


# ── Compliance Engine ─────────────────────────────────────────────────────

class ComplianceEngine:
    """Evaluates audit trail evidence against regulatory requirements.

    The engine is stateless — it reads the audit trail and produces
    a point-in-time conformity assessment.  Run it periodically or
    on-demand for reporting.
    """

    def __init__(
        self,
        requirements: Optional[list[RegulatoryRequirement]] = None,
    ) -> None:
        """
        Args:
            requirements: Regulatory requirements to check.
                          Defaults to EU AI Act + DORA.
        """
        self._requirements = list(
            requirements or (EU_AI_ACT_REQUIREMENTS + DORA_REQUIREMENTS)
        )

    def assess(
        self,
        trail: AuditTrail,
        system_name: str = "Vaara Execution Layer",
        system_version: str = "0.1.0",
    ) -> ConformityReport:
        """Run a full conformity assessment against the audit trail.

        Returns a structured report with per-article evidence mapping,
        gap analysis, and recommendations.
        """
        now = time.time()
        articles: list[ArticleEvidence] = []
        critical_gaps: list[str] = []

        for req in self._requirements:
            evidence = self._assess_article(trail, req, now)
            articles.append(evidence)

            if (
                req.is_critical
                and evidence.status == ComplianceStatus.NON_COMPLIANT
            ):
                critical_gaps.append(
                    f"{req.article} ({req.title}): {'; '.join(evidence.gaps)}"
                )

        # Overall status: worst of critical articles
        critical_statuses = [
            a.status for a in articles if a.requirement.is_critical
        ]
        if ComplianceStatus.NON_COMPLIANT in critical_statuses:
            overall = ComplianceStatus.NON_COMPLIANT
        elif ComplianceStatus.PARTIAL in critical_statuses:
            overall = ComplianceStatus.PARTIAL
        elif critical_statuses:
            overall = ComplianceStatus.COMPLIANT
        else:
            overall = ComplianceStatus.NOT_APPLICABLE

        # Generate summary
        total = len(articles)
        compliant = sum(1 for a in articles if a.status == ComplianceStatus.COMPLIANT)
        partial = sum(1 for a in articles if a.status == ComplianceStatus.PARTIAL)
        non_compliant = sum(1 for a in articles if a.status == ComplianceStatus.NON_COMPLIANT)

        summary = (
            f"{compliant}/{total} articles compliant, "
            f"{partial} partial, {non_compliant} non-compliant. "
            f"{len(critical_gaps)} critical gaps."
        )

        chain_error = trail.verify_chain()

        return ConformityReport(
            generated_at=now,
            system_name=system_name,
            system_version=system_version,
            overall_status=overall,
            critical_gaps=critical_gaps,
            articles=articles,
            summary=summary,
            trail_size=trail.size,
            trail_chain_intact=chain_error is None,
        )

    def _assess_article(
        self,
        trail: AuditTrail,
        req: RegulatoryRequirement,
        now: float,
    ) -> ArticleEvidence:
        """Assess evidence for a single regulatory article."""
        # Special case: requirements that need external evidence (like docs)
        if not req.evidence_event_types:
            return ArticleEvidence(
                requirement=req,
                status=ComplianceStatus.PARTIAL,
                strength=EvidenceStrength.WEAK,
                evidence_count=0,
                freshest_evidence_age_hours=0,
                oldest_evidence_age_hours=0,
                gaps=["Requires manual verification (documentation, design docs)"],
                recommendations=[
                    "Provide technical documentation as per Annex IV"
                ],
            )

        # Collect evidence records
        evidence_records = []
        for event_type in req.evidence_event_types:
            evidence_records.extend(trail.get_records_by_type(event_type, limit=500))

        evidence_count = len(evidence_records)

        if evidence_count == 0:
            return ArticleEvidence(
                requirement=req,
                status=ComplianceStatus.NON_COMPLIANT,
                strength=EvidenceStrength.ABSENT,
                evidence_count=0,
                freshest_evidence_age_hours=float("inf"),
                oldest_evidence_age_hours=float("inf"),
                gaps=[f"No audit evidence found for {req.article}"],
                recommendations=[
                    f"Enable {', '.join(et.value for et in req.evidence_event_types)} "
                    f"recording in the audit trail"
                ],
            )

        # Analyze freshness
        timestamps = [r.timestamp for r in evidence_records]
        freshest_age_hours = (now - max(timestamps)) / 3600
        oldest_age_hours = (now - min(timestamps)) / 3600

        # Determine evidence strength
        gaps = []
        recommendations = []

        if evidence_count < req.min_evidence_count:
            gaps.append(
                f"Insufficient evidence: {evidence_count}/{req.min_evidence_count} "
                f"records (need {req.min_evidence_count - evidence_count} more)"
            )
            recommendations.append(
                f"Continue operating to accumulate at least "
                f"{req.min_evidence_count} records"
            )

        if freshest_age_hours > req.staleness_hours:
            gaps.append(
                f"Evidence is stale: most recent is "
                f"{freshest_age_hours:.0f}h old (threshold: {req.staleness_hours:.0f}h)"
            )
            recommendations.append(
                "Ensure the system is actively processing and logging actions"
            )

        # Assess strength
        if evidence_count >= req.min_evidence_count * 2 and freshest_age_hours < req.staleness_hours / 4:
            strength = EvidenceStrength.STRONG
        elif evidence_count >= req.min_evidence_count and freshest_age_hours < req.staleness_hours:
            strength = EvidenceStrength.MODERATE
        elif evidence_count > 0:
            strength = EvidenceStrength.WEAK
        else:
            strength = EvidenceStrength.ABSENT

        # Determine status
        if not gaps:
            status = ComplianceStatus.COMPLIANT
        elif evidence_count >= req.min_evidence_count:
            status = ComplianceStatus.PARTIAL  # Enough records but maybe stale
        else:
            status = ComplianceStatus.NON_COMPLIANT

        # Sample record IDs for reference
        sample_ids = [r.record_id for r in evidence_records[:5]]

        return ArticleEvidence(
            requirement=req,
            status=status,
            strength=strength,
            evidence_count=evidence_count,
            freshest_evidence_age_hours=freshest_age_hours,
            oldest_evidence_age_hours=oldest_age_hours,
            sample_record_ids=sample_ids,
            gaps=gaps,
            recommendations=recommendations,
        )

    # ── Utilities ─────────────────────────────────────────────────

    def add_requirement(self, requirement: RegulatoryRequirement) -> None:
        """Add a custom regulatory requirement."""
        self._requirements.append(requirement)

    @property
    def requirements(self) -> list[RegulatoryRequirement]:
        return list(self._requirements)

    def requirements_by_domain(
        self, domain: RegulatoryDomain
    ) -> list[RegulatoryRequirement]:
        return [r for r in self._requirements if r.domain == domain]


# ── Factory ───────────────────────────────────────────────────────────────

def create_default_engine(**kwargs: Any) -> ComplianceEngine:
    """Create a compliance engine with production defaults."""
    return ComplianceEngine(**kwargs)
