"""Vaara — Adaptive AI Agent Execution Layer.

Sits between AI agents and their execution environment.
Scores action risk, categorizes actions, produces compliance audit trails.

Built on top of Microsoft Agent Governance Toolkit.
"""

__version__ = "0.3.0"
