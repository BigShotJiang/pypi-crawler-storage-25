"""Example pipeline: API source -> Redshift target."""

import os
import sys
import uuid
import datetime

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

import ingestra  # noqa: E402
from finance_exchange_ds import YFinanceExchangeRateSource

def _require_env(name: str) -> str:
    """Read a required setting from environment variables."""
    value = os.getenv(name)
    if value is None or value == "":
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _optional_env(name: str, default: str = "") -> str:
    """Read an optional setting with a default fallback."""
    return os.getenv(name, default)


# Source settings (what data to fetch)
SOURCE_BASE_CURRENCY = _optional_env("SOURCE_BASE_CURRENCY", "USD")  # Source currency on the left side of the FX pair.
SOURCE_QUOTE_CURRENCY = _optional_env("SOURCE_QUOTE_CURRENCY", "SGD")  # Source currency on the right side of the FX pair.
DELTA_DAYS = int(_optional_env("DELTA_DAYS", "6"))  # How many recent days to extract in this run.

# AWS/S3 settings (where to upload temporary file)
AWS_REGION = _require_env("AWS_REGION")  # AWS region for S3 client and Redshift COPY region.
AWS_ACCESS_KEY_ID = _optional_env("AWS_ACCESS_KEY_ID")  # Optional explicit AWS access key (leave empty to use default credential chain).
AWS_SECRET_ACCESS_KEY = _optional_env("AWS_SECRET_ACCESS_KEY")  # Optional explicit AWS secret key (leave empty to use default credential chain).
AWS_SESSION_TOKEN = _optional_env("AWS_SESSION_TOKEN")  # Optional temporary session token for STS credentials.
S3_UPLOAD_PREFIX = _require_env("S3_UPLOAD_PREFIX")  # S3 prefix where local NDJSON file will be uploaded.

# Redshift settings (where final table lives)
REDSHIFT_TARGET_TABLE = _optional_env("REDSHIFT_TARGET_TABLE", "fx_rates")  # Final Redshift table name for merged rows.
REDSHIFT_TARGET_SCHEMA = _optional_env("REDSHIFT_TARGET_SCHEMA", "metric")  # Redshift schema that owns target table.
REDSHIFT_COPY_IAM_ROLE = _require_env("REDSHIFT_COPY_IAM_ROLE")  # IAM role ARN Redshift should assume for S3 COPY.
REDSHIFT_HOST = _require_env("REDSHIFT_HOST")  # Redshift endpoint host.
REDSHIFT_USER = _require_env("REDSHIFT_USER")  # Redshift login user.
REDSHIFT_PASSWORD = _require_env("REDSHIFT_PASSWORD")  # Redshift login password.
REDSHIFT_DATABASE = _require_env("REDSHIFT_DATABASE")  # Redshift database name.
REDSHIFT_PORT = int(_optional_env("REDSHIFT_PORT", "5439"))  # Redshift TCP port.

def _split_s3_uri(s3_uri: str):
    """Split ``s3://bucket/key`` into ``(bucket, key)``."""
    if not s3_uri.startswith("s3://"):
        raise ValueError(f"Invalid S3 URI: {s3_uri}")
    without_scheme = s3_uri[5:]
    bucket, _, key = without_scheme.partition("/")
    if not bucket:
        raise ValueError(f"Invalid S3 URI (missing bucket): {s3_uri}")
    return bucket, key


def _upload_file_to_s3(local_path: str, s3_prefix: str) -> str:
    """Upload the local NDJSON file to S3 and return full object URI."""
    try:
        import boto3
    except Exception as exc:
        raise RuntimeError(
            "boto3 is required for S3 upload. Install with: pip install boto3"
        ) from exc

    bucket, key_prefix = _split_s3_uri(s3_prefix)
    if key_prefix and not key_prefix.endswith("/"):
        key_prefix = key_prefix + "/"
    object_key = f"{key_prefix}{uuid.uuid4().hex}-{os.path.basename(local_path)}"

    client_kwargs = {"region_name": AWS_REGION}  # Region for S3 client endpoint.
    if AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY:
        client_kwargs["aws_access_key_id"] = AWS_ACCESS_KEY_ID  # Explicit key id override.
        client_kwargs["aws_secret_access_key"] = AWS_SECRET_ACCESS_KEY  # Explicit secret override.
        if AWS_SESSION_TOKEN:
            client_kwargs["aws_session_token"] = AWS_SESSION_TOKEN  # Optional temporary token.
    s3 = boto3.client("s3", **client_kwargs)
    s3.upload_file(local_path, bucket, object_key)
    return f"s3://{bucket}/{object_key}"


# Build source object (where rows come from).
source = YFinanceExchangeRateSource(SOURCE_BASE_CURRENCY, SOURCE_QUOTE_CURRENCY)

# Build target object (where rows should end up).
target = ingestra.Redshift(
    REDSHIFT_TARGET_TABLE,  # Final table name.
    schema_name=REDSHIFT_TARGET_SCHEMA,  # Target schema.
    primary_keys=["base_currency", "quote_currency", "as_of_ts"],  # Row identity columns for merge matching.
)
target.connection(
    host=REDSHIFT_HOST,  # DB host.
    user=REDSHIFT_USER,  # DB user.
    password=REDSHIFT_PASSWORD,  # DB password.
    database=REDSHIFT_DATABASE,  # DB name.
    port=REDSHIFT_PORT,  # DB port.
)
# Alternative for shared connection management:
# target.inherit_connection(existing_redshift_connection)

job = ingestra.Ingest(
    source,  # Data producer object.
    target,  # Data consumer object.
    deletion_rule=ingestra.KeepUntouched(),  # For overwrite mode: keep rows not present in current source batch.
    dry_run=False,  # True = print SQL only, False = execute.
    verbose=True,  # True = print generated SQL while running.
)

# 1) Extract the source table to local NDJSON.
local_path = job.extract_delta_to_local_file(
    start_time=datetime.datetime.utcnow() - datetime.timedelta(days=DELTA_DAYS),
    end_time=datetime.datetime.utcnow(),
)

# 2) Upload the extracted file to S3 so Redshift can COPY it.
s3_path = _upload_file_to_s3(local_path, S3_UPLOAD_PREFIX)  # Uploaded S3 object URI for this batch file.

# 3) Make sure final Redshift table columns are aligned.
job.create_or_update_target_schema()
# 3b) Prepare helper ``*_delta`` table and COPY data from S3 into it.
job.prepare_target_delta_from_cloud_storage(
    ingestra.CloudStorageDeltaSpec(
        uris=[s3_path],
        credentials=ingestra.AwsIamRoleCredentials(
            iam_role=REDSHIFT_COPY_IAM_ROLE  # Role Redshift uses to read S3 files.
        ),
        region=AWS_REGION,  # Region where S3 objects live.
        truncate=True,  # Clear previous rows in helper table before loading this batch.
    )
)

# 4) Apply this batch from helper table into final Redshift table.
job.upsert()
