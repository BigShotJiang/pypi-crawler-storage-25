"""Custom data source used by all example target pipelines."""

import datetime
import ingestra  # noqa: E402


class YFinanceExchangeRateSource(ingestra.DataSource):
    """Custom source that reads daily FX rates from yfinance."""

    def __init__(self, base_currency: str, quote_currency: str):
        super().__init__()
        self.base_currency = base_currency.upper()  # Source currency (left side), for example USD.
        self.quote_currency = quote_currency.upper()  # Quote currency (right side), for example SGD.
        self.symbol = f"{self.base_currency}{self.quote_currency}=X"  # yfinance ticker symbol built from the currency pair.

    def columns(self, refresh=False) -> list:
        """Describe the row shape that target tables should have."""
        return [
            ingestra.Column("base_currency", "VARCHAR", ""),  # Base-currency code column.
            ingestra.Column("quote_currency", "VARCHAR", ""),  # Quote-currency code column.
            ingestra.Column("rate", "FLOAT", ""),  # Exchange-rate numeric value.
            ingestra.Column("symbol", "VARCHAR", ""),  # yfinance symbol used for traceability.
            ingestra.Column("as_of_ts", "TIMESTAMP", ""),  # Timestamp for the rate row.
        ]

    def _iter_rates(self, start_time: datetime.datetime, end_time: datetime.datetime) -> list:
        """Yield one normalized row per day in the requested date window."""
        import pandas as pd
        import yfinance as yf

        # Download OHLC time-series for the selected FX symbol.
        frame = yf.download(
            tickers=self.symbol,  # Which instrument to download.
            start=start_time.date().isoformat(),  # Inclusive start date of requested window.
            end=end_time.date().isoformat(),  # Exclusive end date of requested window.
            interval="1d",  # One row per day.
            progress=False,  # Disable console progress bar for cleaner logs.
            auto_adjust=False,  # Keep raw close prices (no automatic adjustments).
        )
        if frame is None or frame.empty:
            return

        # Convert the pandas rows into plain dict rows for Ingestra.
        for idx, row in frame.iterrows():
            close_value = row.get("Close")
            # yfinance can return a scalar or a Series depending on returned column shape.
            if hasattr(close_value, "iloc"):
                close_value = close_value.iloc[0]
            if pd.isna(close_value):
                continue
            ts = idx.to_pydatetime()
            yield {
                "base_currency": self.base_currency,  # Base currency code.
                "quote_currency": self.quote_currency,  # Quote currency code.
                "rate": float(close_value),  # Daily close value converted to float.
                "as_of_ts": ts.strftime("%Y-%m-%d %H:%M:%S"),  # Datetime formatted for JSON serialization.
                "symbol": self.symbol,  # Original ticker symbol for auditing/debugging.
            }

    def extract(self) -> list:
        """Full extract convenience: return roughly one year of data."""
        # Full-load helper delegates to extract_delta with a broad date range.
        return self.extract_delta(datetime.datetime.utcnow() - datetime.timedelta(days=365), datetime.datetime.utcnow())

    def extract_delta(self, start_time: datetime.datetime, end_time: datetime.datetime = None) -> list:
        """Delta extract: return rows only inside the requested date range."""
        # Incremental-load method used by example pipelines.
        for row in self._iter_rates(start_time, end_time or datetime.datetime.utcnow()):
            yield self.extract_row(row)
