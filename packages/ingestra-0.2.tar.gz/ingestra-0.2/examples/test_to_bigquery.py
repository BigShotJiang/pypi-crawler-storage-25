"""Example pipeline: API source -> BigQuery target."""

import datetime
import os
import sys
import uuid

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

import ingestra  # noqa: E402
from finance_exchange_ds import YFinanceExchangeRateSource


def _require_env(name: str) -> str:
    """Read a required setting from environment variables."""
    value = os.getenv(name)
    if value is None or value == "":
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _optional_env(name: str, default: str = "") -> str:
    """Read an optional setting with a default fallback."""
    return os.getenv(name, default)


SOURCE_BASE_CURRENCY = _optional_env("SOURCE_BASE_CURRENCY", "USD")  # Source currency on the left side of the FX pair.
SOURCE_QUOTE_CURRENCY = _optional_env("SOURCE_QUOTE_CURRENCY", "SGD")  # Source currency on the right side of the FX pair.
DELTA_DAYS = int(_optional_env("DELTA_DAYS", "6"))  # How many recent days to extract in this run.

GCP_PROJECT_ID = _require_env("GCP_PROJECT_ID")  # BigQuery project id that owns the dataset/table.
GCP_DATASET_ID = _require_env("GCP_DATASET_ID")  # BigQuery dataset id that owns the target tables.
GCP_TARGET_TABLE = _optional_env("GCP_TARGET_TABLE", "fx_rates")  # Final BigQuery table name for merged rows.
GCP_SERVICE_ACCOUNT_JSON = _require_env("GCP_SERVICE_ACCOUNT_JSON")  # Path to service-account JSON file for BigQuery client auth.
GCS_UPLOAD_PREFIX = _require_env("GCS_UPLOAD_PREFIX")  # Optional GCS prefix where this script uploads local NDJSON.


def _split_gcs_uri(gcs_uri: str):
    """Split ``gs://bucket/path`` into ``(bucket, path)``."""
    if not gcs_uri.startswith("gs://"):
        raise ValueError(f"Invalid GCS URI: {gcs_uri}")
    without_scheme = gcs_uri[5:]
    bucket, _, object_path = without_scheme.partition("/")
    if not bucket:
        raise ValueError(f"Invalid GCS URI (missing bucket): {gcs_uri}")
    return bucket, object_path


def _upload_file_to_gcs(local_path: str, gcs_prefix: str, service_account_json: str) -> str:
    """Upload local file to GCS and return full object URI."""
    try:
        from google.cloud import storage
    except Exception as exc:
        raise RuntimeError(
            "google-cloud-storage is required for GCS upload. Install with: pip install google-cloud-storage"
        ) from exc

    bucket_name, object_prefix = _split_gcs_uri(gcs_prefix)
    if object_prefix and not object_prefix.endswith("/"):
        object_prefix = object_prefix + "/"
    object_name = f"{object_prefix}{uuid.uuid4().hex}-{os.path.basename(local_path)}"

    client = storage.Client.from_service_account_json(service_account_json)
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(object_name)
    blob.upload_from_filename(local_path)
    return f"gs://{bucket_name}/{object_name}"

# Build source object (where rows come from).
source = YFinanceExchangeRateSource(SOURCE_BASE_CURRENCY, SOURCE_QUOTE_CURRENCY)

# Build target object (where rows should end up).
target = ingestra.BigQuery(
    GCP_PROJECT_ID,  # Project id.
    GCP_DATASET_ID,  # Dataset id.
    GCP_TARGET_TABLE,  # Final table id.
    primary_keys=["base_currency", "quote_currency", "as_of_ts"],  # Row identity columns for upsert matching.
)
target.connection(GCP_SERVICE_ACCOUNT_JSON)  # Build BigQuery client from service account JSON.
# Alternative for shared client management:
# target.inherit_connection(existing_bigquery_client)

job = ingestra.Ingest(
    source,  # Data producer object.
    target,  # Data consumer object.
    deletion_rule=ingestra.KeepUntouched(),  # For overwrite mode: keep rows not present in current source batch.
    dry_run=False,  # True = print SQL only, False = execute.
    verbose=True,  # True = print generated SQL while running.
)

# 1) Extract the source table to local NDJSON.
local_path = job.extract_delta_to_local_file(
    start_time=datetime.datetime.utcnow() - datetime.timedelta(days=DELTA_DAYS),
    end_time=datetime.datetime.utcnow(),
)

# 2) Upload to GCS from this script when ``GCS_UPLOAD_PREFIX``.
gcs_path = _upload_file_to_gcs(local_path, GCS_UPLOAD_PREFIX, GCP_SERVICE_ACCOUNT_JSON)  # Uploaded GCS object URI for this batch file.

# 3) Make sure final table columns are aligned.
job.create_or_update_target_schema()
# 3b) Prepare helper table ``*_delta`` by pointing it to GCS files.
job.prepare_target_delta_from_cloud_storage(
    ingestra.CloudStorageDeltaSpec(
        uris=[gcs_path],  # One or more GCS URIs that BigQuery external table should read.
    )
)

# 4) Apply this batch from helper data into final BigQuery table.
job.upsert()
