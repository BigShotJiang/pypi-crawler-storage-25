"""Example pipeline: API source -> PostgreSQL target."""

import datetime
import os
import sys

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

import ingestra  # noqa: E402
from finance_exchange_ds import YFinanceExchangeRateSource


def _require_env(name: str) -> str:
    """Read a required setting from environment variables."""
    value = os.getenv(name)
    if value is None or value == "":
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _optional_env(name: str, default: str = "") -> str:
    """Read an optional setting with a default fallback."""
    return os.getenv(name, default)


SOURCE_BASE_CURRENCY = _optional_env("SOURCE_BASE_CURRENCY", "USD")  # Source currency on the left side of the FX pair.
SOURCE_QUOTE_CURRENCY = _optional_env("SOURCE_QUOTE_CURRENCY", "SGD")  # Source currency on the right side of the FX pair.
DELTA_DAYS = int(_optional_env("DELTA_DAYS", "27"))  # How many recent days to extract in this run.

POSTGRES_TARGET_TABLE = _optional_env("POSTGRES_TARGET_TABLE", "fx_rates")  # Final PostgreSQL table name for merged rows.
POSTGRES_TARGET_SCHEMA = _optional_env("POSTGRES_TARGET_SCHEMA", "public")  # PostgreSQL schema that owns the target table.
POSTGRES_HOST = _require_env("POSTGRES_HOST")  # PostgreSQL server host/IP.
POSTGRES_USER = _require_env("POSTGRES_USER")  # PostgreSQL login user.
POSTGRES_PASSWORD = _require_env("POSTGRES_PASSWORD")  # PostgreSQL login password.
POSTGRES_DATABASE = _require_env("POSTGRES_DATABASE")  # PostgreSQL database name.
POSTGRES_PORT = int(_optional_env("POSTGRES_PORT", "5432"))  # PostgreSQL TCP port.

# Build source object (where rows come from).
source = YFinanceExchangeRateSource(SOURCE_BASE_CURRENCY, SOURCE_QUOTE_CURRENCY)
# Build target object (where rows should end up).
target = ingestra.PostgreSQL(
    POSTGRES_TARGET_TABLE,  # Final PostgreSQL table name.
    schema_name=POSTGRES_TARGET_SCHEMA,  # Target schema.
    primary_keys=["base_currency", "quote_currency", "as_of_ts"],  # Row identity columns for upsert matching.
)
target.connection(
    host=POSTGRES_HOST,  # DB host.
    user=POSTGRES_USER,  # DB user.
    password=POSTGRES_PASSWORD,  # DB password.
    database=POSTGRES_DATABASE,  # DB name.
    port=POSTGRES_PORT,  # DB port.
)
# Alternative for shared connection management:
# target.inherit_connection(existing_postgres_connection)

job = ingestra.Ingest(
    source,  # Data producer object.
    target,  # Data consumer object.
    deletion_rule=ingestra.KeepUntouched(),  # For overwrite mode: keep rows not present in current source batch.
    dry_run=False,  # True = print SQL only, False = execute.
    verbose=True,  # True = print generated SQL while running.
)

# 1) Extract only recent rows into a local NDJSON file.
path = job.extract_delta_to_local_file(
    start_time=datetime.datetime.utcnow() - datetime.timedelta(days=DELTA_DAYS),  # Inclusive lower time bound.
    end_time=datetime.datetime.utcnow(),  # Exclusive upper time bound.
)

# 2) Align target schema so target columns follow source.columns().
job.create_or_update_target_schema()

# 3) Load NDJSON rows into helper delta table ``*_delta``.
job.load_target_delta_from_ndjson_file(path)

# 4) Merge helper rows from ``*_delta`` into final PostgreSQL table.
job.upsert()
