"""Automated checks for the ingestra package.

Layout (one concern per module):

- ``test_types_and_lifecycle`` — shared type names across databases; column metadata;
  rules for deleted rows.
- ``test_data_source`` — comparing target vs source column lists; row export; Redshift wiring.
- ``test_incremental_extract`` — time-sliced ``extract_delta`` (guards + SQL + row shape).
- ``test_bigquery`` — BigQuery DDL and MERGE (staging table, ALTER, overwrite, upsert).
- ``test_sql_targets`` — PostgreSQL / MySQL / Redshift targets: delta helpers, create/alter, upsert/overwrite, Ingest wiring.
- ``test_ingest`` — the high-level job that ties source and target together.
"""

import os
import unittest


def load_tests(loader, tests, pattern):
    """Discover every ``test_*.py`` in this directory (e.g. custom test runners)."""
    this_dir = os.path.dirname(__file__)
    root = os.path.abspath(os.path.join(this_dir, os.pardir, os.pardir))
    return loader.discover(this_dir, pattern="test_*.py", top_level_dir=root)
