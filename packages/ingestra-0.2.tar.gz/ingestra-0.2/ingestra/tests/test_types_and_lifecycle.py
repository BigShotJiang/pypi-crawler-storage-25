"""Logical column types across databases, and rules for deleted rows in the warehouse.

Nothing here talks to a real database: only type tables, :class:`Column`, and lifecycle rules.
"""

import unittest

import ingestra

DIALECTS = ("MySQL", "PostgreSQL", "BigQuery")


# --- Spot checks: a few important mappings everyone relies on ---


class ColumnTypesLocateTests(unittest.TestCase):
    """Turning each database’s type label into one shared internal label."""

    def test_when_postgres_stores_timezone_timestamps_we_normalize_to_timestamp(self):
        """Objective: PostgreSQL reports a time-zone-aware timestamp type.
        Expectation: We classify it as our generic “timestamp” family.
        """
        self.assertEqual(
            ingestra.ColumnTypes.locate("PostgreSQL", "TIMESTAMP WITH TIME ZONE"),
            "TIMESTAMP",
        )

    def test_when_mysql_says_int_we_normalize_to_integer(self):
        """Objective: MySQL uses INT for whole numbers.
        Expectation: We classify it as our generic integer family.
        """
        self.assertEqual(ingestra.ColumnTypes.locate("MySQL", "INT"), "INTEGER")

    def test_when_bigquery_says_string_we_normalize_to_short_text_family(self):
        """Objective: BigQuery’s STRING type should align with other engines’ string-like columns.
        Expectation: We map it to the short-text (VARCHAR) family first in our rules.
        """
        self.assertEqual(ingestra.ColumnTypes.locate("BigQuery", "STRING"), "VARCHAR")

    def test_when_type_is_unknown_we_return_nothing(self):
        """Objective: A made-up type name should not silently map somewhere wrong.
        Expectation: Lookup returns nothing (None).
        """
        self.assertIsNone(ingestra.ColumnTypes.locate("MySQL", "NOT_A_REAL_TYPE"))


class AdjustDataTypeSpotTests(unittest.TestCase):
    """Examples of how a logical family becomes a CREATE TABLE keyword per engine."""

    def test_when_target_is_bigquery_short_text_becomes_string(self):
        """Objective: We need a BigQuery column definition for our short-text family.
        Expectation: BigQuery uses STRING in DDL.
        """
        bq = ingestra.BigQuery("proj", "ds", "tbl")
        self.assertEqual(bq.adjust_data_type("VARCHAR"), "STRING")

    def test_when_target_is_postgres_short_text_uses_preferred_postgres_name(self):
        """Objective: PostgreSQL DDL should use a native name for short text.
        Expectation: We use the first preferred spelling from our table (character varying).
        """
        pg = ingestra.PostgreSQL("t", "public")
        self.assertEqual(pg.adjust_data_type("VARCHAR"), "CHARACTER VARYING")


class ColumnTests(unittest.TestCase):
    """Lightweight column metadata object."""

    def test_when_printed_column_shows_its_name(self):
        """Objective: Debugging should show which column we mean.
        Expectation: String form is a simple angle-bracket name.
        """
        col = ingestra.Column("id", "INTEGER", "pk")
        self.assertEqual(repr(col), "<id>")


class LifecycleRulesTests(unittest.TestCase):
    """What to do with rows that disappear from the next load."""

    def test_soft_delete_rule_exposes_its_flag_column_for_schema_builders(self):
        """Objective: “Mark as deleted” needs a real column definition for the warehouse.
        Expectation: The helper returns a column with the chosen name and type.
        """
        rule = ingestra.MarkAsDeleted("deleted", value=1, default_value=0, data_type="INTEGER")
        col = rule.get_column()
        self.assertEqual(col.name, "deleted")
        self.assertEqual(col.data_type, "INTEGER")

    def test_remove_row_and_leave_row_rules_are_valid_options(self):
        """Objective: Callers can pick hard delete vs leave-old-rows rules.
        Expectation: Both are accepted lifecycle rule objects.
        """
        self.assertIsInstance(ingestra.Delete(), ingestra.LifecycleRule)
        self.assertIsInstance(ingestra.KeepUntouched(), ingestra.LifecycleRule)

    def test_mark_as_deleted_validation_raises_when_flag_name_is_in_source(self):
        """Objective: The soft-delete column is target-managed; it must not duplicate a source field.
        Expectation: :func:`ingestra._validate_mark_as_deleted_source_names` raises ``ValueError``.
        """
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        with self.assertRaises(ValueError) as ctx:
            ingestra._validate_mark_as_deleted_source_names(source, rule)
        self.assertIn("is_deleted", str(ctx.exception))

    def test_mark_as_deleted_validation_allows_distinct_flag_name(self):
        ingestra._validate_mark_as_deleted_source_names(
            [ingestra.Column("id", "INTEGER", "")],
            ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0),
        )

    def test_mark_as_deleted_validation_no_op_for_non_mark_rules(self):
        ingestra._validate_mark_as_deleted_source_names(
            [ingestra.Column("is_deleted", "INTEGER", "")],
            ingestra.Delete(),
        )


# --- Matrix: every alias we document, and DDL first choice per engine ---


class ColumnTypesEveryAliasLocates(unittest.TestCase):
    """Every database-specific type label we list must land in a sensible shared bucket."""

    @staticmethod
    def _canonicals_for(dialect, alias):
        return frozenset(
            c
            for c in ingestra.ColumnTypes.SUPPORTED_TYPES
            if alias in getattr(ingestra.ColumnTypes, c).get(dialect, [])
        )

    def test_every_listed_database_type_maps_to_an_allowed_shared_bucket(self):
        """Objective: For each engine and each type name we claim to understand, classification must be consistent.
        Expectation: The result is always one of the shared families that actually list that database label (handles labels that fit more than one family).
        """
        pairs = set()
        for canonical in ingestra.ColumnTypes.SUPPORTED_TYPES:
            per_engine = getattr(ingestra.ColumnTypes, canonical)
            for dialect in DIALECTS:
                for alias in per_engine.get(dialect, []):
                    pairs.add((dialect, alias))
        for dialect, alias in sorted(pairs):
            allowed = self._canonicals_for(dialect, alias)
            found = ingestra.ColumnTypes.locate(dialect, alias)
            with self.subTest(dialect=dialect, alias=alias):
                self.assertIn(
                    found,
                    allowed,
                    msg=f"{dialect!r} {alias!r} must map to one of {sorted(allowed)}",
                )


class BigQueryStringDisambiguationTests(unittest.TestCase):
    """BigQuery STRING appears in more than one family; first rule wins."""

    def test_when_bigquery_string_could_be_short_or_long_text_we_pick_short_text_first(self):
        """Objective: STRING is valid for both short-text and long-text families in our matrix.
        Expectation: Our ordered lookup treats it as short text (VARCHAR family), not long text (TEXT family).
        """
        self.assertEqual(ingestra.ColumnTypes.locate("BigQuery", "STRING"), "VARCHAR")


class AdjustDataTypeMatrixTests(unittest.TestCase):
    """Each shared family should translate to the engine’s preferred DDL keyword."""

    def setUp(self):
        self.engines = {
            "BigQuery": ingestra.BigQuery("proj", "ds", "tbl"),
            "PostgreSQL": ingestra.PostgreSQL("t", "public"),
            "MySQL": ingestra.MySQL("t", "db"),
        }

    def test_each_shared_family_maps_to_the_first_preferred_spelling_per_engine(self):
        """Objective: For every logical family and every engine, DDL generation should use our primary spelling.
        Expectation: adjust_data_type matches the first entry in that family’s list for that engine.
        """
        for canonical in ingestra.ColumnTypes.SUPPORTED_TYPES:
            mapping = getattr(ingestra.ColumnTypes, canonical)
            for dialect, instance in self.engines.items():
                expected = mapping[dialect][0]
                with self.subTest(canonical=canonical, dialect=dialect):
                    self.assertEqual(
                        instance.adjust_data_type(canonical),
                        expected,
                    )


if __name__ == "__main__":
    unittest.main()
