"""BigQuery target: staging table SQL, ALTER TABLE alignment, and MERGE (overwrite / upsert).

All tests use string inspection or dry-run prints—no ``google.cloud`` network calls.
"""

import unittest
from unittest.mock import patch

import ingestra


def _prints_from_alter(bq, source_columns, deletion_rule):
    bq.dry_run = True
    with patch("builtins.print") as pr:
        bq.alter(source_columns, deletion_rule)
    return [c.args[0] for c in pr.call_args_list if c.args]


def _capture_overwrite_sql(bq, primary_keys, deletion_rule, columns):
    bq.dry_run = True
    with patch.object(bq, "columns", return_value=columns):
        with patch("builtins.print") as pr:
            bq.overwrite(primary_keys, deletion_rule)
    pr.assert_called_once()
    return pr.call_args[0][0]


def _capture_upsert_sql(bq, primary_keys, columns):
    bq.dry_run = True
    with patch.object(bq, "columns", return_value=columns):
        with patch("builtins.print") as pr:
            bq.upsert(primary_keys)
    pr.assert_called_once()
    return pr.call_args[0][0]


# --- External table over GCS (staging for loads) ---


class StagingExternalTableSqlTests(unittest.TestCase):
    def setUp(self):
        self.bq = ingestra.BigQuery("myproj", "myds", "events")

    def test_when_creating_staging_table_we_name_delta_and_point_at_gcs_files(self):
        """Objective: Staging table must read newline JSON from given Cloud Storage paths.
        Expectation: SQL creates …events_delta, lists column types, format NEWLINE_DELIMITED_JSON, and both URIs.
        """
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        sql = self.bq.create_external_table(cols, ["gs://b/p/1.json", "gs://b/p/2.json"])
        self.assertIn("CREATE OR REPLACE EXTERNAL TABLE `myproj.myds.events_delta`", sql)
        self.assertIn("`id` INT64", sql)
        self.assertIn("`name` STRING", sql)
        self.assertIn('"NEWLINE_DELIMITED_JSON"', sql)
        self.assertIn("'gs://b/p/1.json'", sql)
        self.assertIn("'gs://b/p/2.json'", sql)


# --- ALTER TABLE: add / drop / soft-delete column rules ---


class AlterDropColumnTests(unittest.TestCase):
    def test_when_source_omits_a_column_we_generate_drop_for_that_column(self):
        """Objective: Warehouse still has a column the source schema no longer defines.
        Expectation: Printed DDL includes dropping that column by name.
        """
        bq = ingestra.BigQuery("p", "d", "t")
        bq.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("removed", "VARCHAR", ""),
        ]
        source = [ingestra.Column("id", "INTEGER", "")]
        stmts = _prints_from_alter(bq, source, ingestra.KeepUntouched())
        drop_sql = [s for s in stmts if "DROP COLUMN" in s]
        self.assertTrue(any("`removed`" in s for s in drop_sql))


class AlterAddColumnTests(unittest.TestCase):
    def test_when_source_adds_a_column_we_generate_add_with_right_type(self):
        """Objective: Source has a new field the table does not.
        Expectation: Printed DDL adds that column using BigQuery’s string type for short text.
        """
        bq = ingestra.BigQuery("p", "d", "t")
        bq.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("extra", "VARCHAR", ""),
        ]
        stmts = _prints_from_alter(bq, source, ingestra.KeepUntouched())
        add_sql = [s for s in stmts if "ADD COLUMN" in s]
        self.assertTrue(any("`extra`" in s and "STRING" in s for s in add_sql))


class AlterSchemaAlreadyAlignedTests(unittest.TestCase):
    def test_when_definitions_already_match_we_emit_no_alter_statements(self):
        """Objective: Target and source column lists are the same.
        Expectation: No ADD or DROP on native columns; delta external table is managed separately.
        """
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        bq = ingestra.BigQuery("p", "d", "t")
        bq.cols = list(cols)
        stmts = _prints_from_alter(bq, list(cols), ingestra.KeepUntouched())
        joined = "\n".join(stmts)
        self.assertNotIn("DROP COLUMN", joined)
        self.assertNotIn("ADD COLUMN", joined)
        self.assertEqual(stmts, [])


class MarkAsDeletedSourceColumnConflictTests(unittest.TestCase):
    def test_create_raises_when_source_already_has_rule_column(self):
        bq = ingestra.BigQuery("p", "d", "t")
        bq.dry_run = True
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        with self.assertRaises(ValueError) as ctx:
            bq.create(source, rule)
        self.assertIn("is_deleted", str(ctx.exception))

    def test_alter_raises_when_source_already_has_rule_column(self):
        bq = ingestra.BigQuery("p", "d", "t")
        bq.dry_run = True
        bq.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        with self.assertRaises(ValueError) as ctx:
            bq.alter(source, rule)
        self.assertIn("is_deleted", str(ctx.exception))


class AlterSoftDeleteFlagTests(unittest.TestCase):
    def test_when_soft_delete_enabled_we_do_not_drop_the_flag_even_if_absent_from_source(self):
        """Objective: Source does not list the “deleted” flag (by design); target still has it.
        Expectation: No DROP statement targets the soft-delete column name.
        """
        bq = ingestra.BigQuery("p", "d", "t")
        bq.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        source = [ingestra.Column("id", "INTEGER", "")]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        stmts = _prints_from_alter(bq, source, rule)
        drop_sql = "\n".join(s for s in stmts if "DROP COLUMN" in s)
        self.assertNotIn("is_deleted", drop_sql)

    def test_when_soft_delete_enabled_but_flag_missing_on_table_we_add_it(self):
        """Objective: Rule requires a deleted flag but the table has no such column yet.
        Expectation: An ADD COLUMN for the flag appears in the printed DDL.
        """
        bq = ingestra.BigQuery("p", "d", "t")
        bq.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [ingestra.Column("id", "INTEGER", "")]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        stmts = _prints_from_alter(bq, source, rule)
        add_sql = "\n".join(s for s in stmts if "ADD COLUMN" in s)
        self.assertIn("is_deleted", add_sql)


# --- MERGE: overwrite (with lifecycle) vs upsert ---


class MergeOverwriteDeleteRuleTests(unittest.TestCase):
    """Rows that exist only in the warehouse but not in the new file can be removed."""

    def setUp(self):
        self.bq = ingestra.BigQuery("myproj", "myds", "events")
        self.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]

    def test_when_merging_we_join_main_table_to_staging_by_primary_key(self):
        """Objective: Load combined main + staging merge statement for a simple key.
        Expectation: MERGE names main table, _delta staging table, and matches on id.
        """
        sql = _capture_overwrite_sql(self.bq, ["id"], ingestra.Delete(), self.cols)
        self.assertIn("MERGE", sql)
        self.assertIn("`myproj.myds.events`", sql)
        self.assertIn("`myproj.myds.events_delta`", sql)
        self.assertIn("t.`id` = c.`id`", sql)

    def test_when_delete_rule_chosen_extra_warehouse_rows_are_deleted(self):
        """Objective: User wants warehouse rows absent from the new file removed.
        Expectation: SQL includes the “not matched by source” branch with DELETE.
        """
        sql = _capture_overwrite_sql(self.bq, ["id"], ingestra.Delete(), self.cols)
        self.assertIn("WHEN NOT MATCHED BY SOURCE", sql)
        self.assertRegex(sql, r"\bDELETE\b")

    def test_when_primary_key_has_two_parts_both_must_match(self):
        """Objective: Natural key is tenant plus id.
        Expectation: Join condition ANDs both key columns between main and staging.
        """
        sql = _capture_overwrite_sql(
            self.bq,
            ["tenant_id", "id"],
            ingestra.Delete(),
            self.cols + [ingestra.Column("tenant_id", "INTEGER", "")],
        )
        self.assertIn("t.`tenant_id` = c.`tenant_id`", sql)
        self.assertIn("AND t.`id` = c.`id`", sql)


class MergeOverwriteSoftDeleteRuleTests(unittest.TestCase):
    """Instead of deleting, mark warehouse-only rows with a flag."""

    def setUp(self):
        self.bq = ingestra.BigQuery("p", "d", "t")
        self.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        self.rule = ingestra.MarkAsDeleted(
            "is_deleted", value=1, default_value=0, data_type="INTEGER"
        )

    def test_when_soft_delete_rule_extra_warehouse_rows_get_flag_set_not_deleted(self):
        """Objective: Rows only in the warehouse should be marked deleted, not physically removed.
        Expectation: “Not matched by source” updates the flag to 1; no DELETE in that branch.
        """
        sql = _capture_overwrite_sql(self.bq, ["id"], self.rule, self.cols)
        self.assertIn("WHEN NOT MATCHED BY SOURCE", sql)
        self.assertIn("`is_deleted` = 1", sql)
        self.assertNotRegex(sql, r"WHEN NOT MATCHED BY SOURCE[\s\S]*\bDELETE\b")

    def test_when_row_matches_staging_we_reset_soft_delete_flag_to_default(self):
        """Objective: A row that appears again in the file should look “active.”
        Expectation: Matched-branch update sets the flag column to the default (0), not staging’s raw value for that special column.
        """
        sql = _capture_overwrite_sql(self.bq, ["id"], self.rule, self.cols)
        self.assertIn("`is_deleted` = 0", sql)


class MergeOverwriteLeaveExtrasTests(unittest.TestCase):
    def test_when_leave_old_rows_rule_we_do_not_touch_warehouse_only_rows(self):
        """Objective: User does not want deletes or flag updates for missing keys.
        Expectation: No “not matched by source” clause at all.
        """
        bq = ingestra.BigQuery("p", "d", "t")
        cols = [ingestra.Column("id", "INTEGER", "")]
        sql = _capture_overwrite_sql(bq, ["id"], ingestra.KeepUntouched(), cols)
        self.assertNotIn("WHEN NOT MATCHED BY SOURCE", sql)


class MergeUpsertTests(unittest.TestCase):
    def test_when_upserting_we_insert_or_update_but_never_remove_orphans(self):
        """Objective: Safer merge: new keys insert, existing keys update, extras left alone.
        Expectation: Has match / not matched for staging side, but no “not matched by source.”
        """
        bq = ingestra.BigQuery("p", "d", "t")
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("v", "VARCHAR", ""),
        ]
        sql = _capture_upsert_sql(bq, ["id"], cols)
        self.assertIn("WHEN MATCHED", sql)
        self.assertIn("WHEN NOT MATCHED", sql)
        self.assertNotIn("WHEN NOT MATCHED BY SOURCE", sql)
        self.assertIn("UPDATE SET", sql)
        self.assertIn("c.`v`", sql)


class BigQueryTargetDeltaPrepareTests(unittest.TestCase):
    def test_when_bigquery_prepares_delta_external_table_we_emit_create_external_table_sql(self):
        bq = ingestra.BigQuery("p", "d", "t")
        bq.dry_run = True
        source = [ingestra.Column("id", "INTEGER", "")]
        spec = ingestra.CloudStorageDeltaSpec(uris=["gs://bucket/path.json"])
        with patch("builtins.print") as pr:
            bq.prepare_target_delta_from_cloud_storage(source, spec)
        pr.assert_called_once()
        sql = pr.call_args[0][0]
        self.assertIn("CREATE OR REPLACE EXTERNAL TABLE", sql)
        self.assertIn("gs://bucket/path.json", sql)


if __name__ == "__main__":
    unittest.main()
