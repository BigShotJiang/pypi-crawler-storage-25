"""Time-sliced reads (:meth:`extract_delta`): guards, SQL shape, and row shaping.

Uses mocks only—no PostgreSQL, MySQL, or BigQuery network calls.
"""

import datetime
import unittest
from unittest.mock import MagicMock

import ingestra


def _pg_cursor_context(cursor):
    cm = MagicMock()
    cm.__enter__.return_value = cursor
    cm.__exit__.return_value = None
    return cm


# --- Guards: watermark column must be date-like unless you pass custom SQL ---


class PostgreSQLWatermarkGuardTests(unittest.TestCase):
    def test_when_watermark_is_not_a_date_column_we_refuse_without_custom_sql(self):
        """Objective: User tries to filter by “updated at” using an integer id as the watermark, with no custom query.
        Expectation: We raise an error explaining only date-like columns are supported that way.
        """
        pg = ingestra.PostgreSQL("orders", "public")
        pg.conn = MagicMock()
        pg.cols = [ingestra.Column("id", "INTEGER", "")]
        with self.assertRaises(RuntimeError) as ctx:
            list(
                pg.extract_delta(
                    "id",
                    datetime.datetime(2024, 1, 1),
                )
            )
        self.assertIn("non date/timestamp", str(ctx.exception).lower())


class MySQLWatermarkGuardTests(unittest.TestCase):
    def test_when_watermark_is_not_a_date_column_we_refuse_without_custom_sql(self):
        """Objective: Same guard as PostgreSQL for MySQL incremental reads.
        Expectation: Error if the watermark column is not date-like and no custom SQL body is given.
        """
        mysql = ingestra.MySQL("orders", "db")
        mysql.conn = MagicMock()
        mysql.cols = [ingestra.Column("id", "INTEGER", "")]
        with self.assertRaises(RuntimeError):
            list(
                mysql.extract_delta(
                    "id",
                    datetime.datetime(2024, 1, 1),
                )
            )


class BigQueryWatermarkGuardTests(unittest.TestCase):
    def test_when_watermark_is_not_a_date_column_we_refuse_without_custom_sql(self):
        """Objective: Same guard for BigQuery incremental reads.
        Expectation: Error if the watermark column is not date-like and no custom SQL body is given.
        """
        bq = ingestra.BigQuery("p", "d", "t")
        bq.conn = MagicMock()
        bq.cols = [ingestra.Column("id", "INTEGER", "")]
        with self.assertRaises(RuntimeError):
            list(
                bq.extract_delta(
                    "id",
                    datetime.datetime(2024, 1, 1),
                )
            )


# --- PostgreSQL: happy paths ---


class PostgreSQLDeltaTemporalTypesTests(unittest.TestCase):
    """PostgreSQL allows date, datetime, or timestamp as the “changed at” column."""

    def _assert_delta_executes_with_watermark(self, data_type, col_name="wm"):
        pg = ingestra.PostgreSQL("orders", "public")
        pg.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column(col_name, data_type, ""),
        ]
        cursor = MagicMock()
        cursor.fetchall.return_value = [(1, datetime.date(2024, 1, 15))]
        conn = MagicMock()
        conn.cursor.return_value = _pg_cursor_context(cursor)
        pg.conn = conn
        start = datetime.datetime(2024, 1, 1, 0, 0, 0)
        end = datetime.datetime(2024, 2, 1, 0, 0, 0)
        rows = list(pg.extract_delta(col_name, start, end_time=end))
        sql = cursor.execute.call_args[0][0]
        self.assertIn(f'"{col_name}"', sql)
        self.assertIn(">=", sql)
        self.assertIn("<", sql)
        self.assertIn("ORDER BY", sql)
        self.assertIn("DESC", sql)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["id"], 1)

    def test_when_watermark_is_date_we_filter_and_order_newest_first(self):
        """Objective: Use a calendar-date column to pull a time slice.
        Expectation: SQL references the column, applies start/end bounds, orders descending; one row comes back normalized.
        """
        self._assert_delta_executes_with_watermark("DATE")

    def test_when_watermark_is_datetime_we_filter_and_order_newest_first(self):
        """Objective: Use a date+time column without time zone for the slice.
        Expectation: Same shape of query and successful row yield as the date case.
        """
        self._assert_delta_executes_with_watermark("DATETIME")

    def test_when_watermark_is_timestamp_we_filter_and_order_newest_first(self):
        """Objective: Use a timestamp-style column for the slice.
        Expectation: Same shape of query and successful row yield as the other temporal cases.
        """
        self._assert_delta_executes_with_watermark("TIMESTAMP")


class PostgreSQLDeltaCustomFromTests(unittest.TestCase):
    def test_when_custom_sql_supplied_it_replaces_the_table_in_from_clause(self):
        """Objective: Sometimes the slice should run against a view or subquery, not the base table.
        Expectation: The generated SQL wraps the provided SELECT as a subquery alias vw.
        """
        pg = ingestra.PostgreSQL("orders", "public")
        pg.cols = [ingestra.Column("id", "INTEGER", "")]
        cursor = MagicMock()
        cursor.fetchall.return_value = []
        pg.conn = MagicMock()
        pg.conn.cursor.return_value = _pg_cursor_context(cursor)
        list(
            pg.extract_delta(
                "id",
                datetime.datetime(2024, 1, 1),
                sql_from="SELECT 1 AS id",
            )
        )
        sql = cursor.execute.call_args[0][0]
        self.assertIn("SELECT 1 AS id", sql)
        self.assertIn(") AS vw", sql)


# --- MySQL ---


class MySQLDeltaTemporalTests(unittest.TestCase):
    def _run_delta(self, data_type, col="wm"):
        mysql = ingestra.MySQL("orders", "db")
        mysql.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column(col, data_type, ""),
        ]
        cursor = MagicMock()
        cursor.fetchall.return_value = []
        mysql.conn = MagicMock()
        mysql.conn.cursor.return_value = _pg_cursor_context(cursor)
        start = datetime.datetime(2024, 6, 1, 12, 0, 0)
        list(mysql.extract_delta(col, start))
        return cursor.execute.call_args[0][0]

    def test_when_watermark_is_date_bounds_are_cast_in_sql(self):
        """Objective: MySQL needs explicit casts for literal bounds on a date column.
        Expectation: CAST appears and the date column is referenced with backticks.
        """
        sql = self._run_delta("DATE", "d")
        self.assertIn("CAST(", sql)
        self.assertIn("`d`", sql)

    def test_when_watermark_is_datetime_bounds_use_datetime_cast(self):
        """Objective: Datetime watermarks should compare as datetimes.
        Expectation: CAST present and DATETIME appears in the SQL.
        """
        sql = self._run_delta("DATETIME", "dt")
        self.assertIn("CAST(", sql)
        self.assertIn("DATETIME", sql)

    def test_when_watermark_is_timestamp_bounds_use_timestamp_cast(self):
        """Objective: Timestamp watermarks should compare as timestamps.
        Expectation: CAST present, TIMESTAMP and column name in the SQL.
        """
        sql = self._run_delta("TIMESTAMP", "updated_at")
        self.assertIn("CAST(", sql)
        self.assertIn("TIMESTAMP", sql)
        self.assertIn("`updated_at`", sql)


# --- BigQuery ---


class BigQueryDeltaTemporalTests(unittest.TestCase):
    def _delta_sql(self, data_type, col, start=None, end=None):
        bq = ingestra.BigQuery("p", "d", "t")
        bq.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column(col, data_type, ""),
        ]
        job = MagicMock()
        job.result.return_value = []
        bq.conn = MagicMock()
        bq.conn.query.return_value = job
        start = start or datetime.datetime(2024, 3, 1, 0, 0, 0)
        end = end or datetime.datetime(2024, 4, 1)
        list(bq.extract_delta(col, start, end_time=end))
        return bq.conn.query.call_args[0][0]

    def test_when_watermark_is_date_we_use_safe_casts_and_qualify_table(self):
        """Objective: BigQuery should read from the full table id and protect casts.
        Expectation: SAFE_CAST appears and the main table path and column appear in the job SQL.
        """
        sql = self._delta_sql("DATE", "d")
        self.assertIn("SAFE_CAST", sql)
        self.assertIn("`p.d.t`", sql)
        self.assertIn("`d`", sql)

    def test_when_watermark_is_datetime_literals_go_through_datetime_first(self):
        """Objective: Bounds should be parsed safely then cast to the column’s type.
        Expectation: SAFE_CAST chain includes an intermediate DATETIME cast.
        """
        sql = self._delta_sql("DATETIME", "dt")
        self.assertIn("SAFE_CAST", sql)
        self.assertIn("AS DATETIME", sql)

    def test_when_watermark_is_timestamp_both_start_and_end_appear(self):
        """Objective: End of window should narrow the slice, not only the start.
        Expectation: AND clause and the timestamp column name appear in the SQL.
        """
        sql = self._delta_sql("TIMESTAMP", "ts")
        self.assertIn("AND", sql)
        self.assertIn("`ts`", sql)


class DeltaRowShapeTests(unittest.TestCase):
    def test_when_database_returns_tuple_rows_we_build_dicts_for_export(self):
        """Objective: Driver returns positional cells matching the SELECT list order.
        Expectation: We zip names to values and the id field is readable on the output dict.
        """
        pg = ingestra.PostgreSQL("t", "public")
        pg.cols = [ingestra.Column("id", "INTEGER", "")]
        cursor = MagicMock()
        cursor.fetchall.return_value = [(99,)]
        pg.conn = MagicMock()
        pg.conn.cursor.return_value = _pg_cursor_context(cursor)
        rows = list(
            pg.extract_delta(
                "id",
                datetime.datetime(2024, 1, 1),
                sql_from="SELECT 1 AS id",
            )
        )
        self.assertEqual(rows[0]["id"], 99)


if __name__ == "__main__":
    unittest.main()
