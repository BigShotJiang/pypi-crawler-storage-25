""":class:`ingestra.DataSource` behaviour without a live connection.

* Comparing a **target** column list to a **source** list (adds, drops, type drift, exact matches).
* Normalizing a **row** for newline-delimited JSON export.
* Small wiring checks (e.g. Redshift vs PostgreSQL).
"""

import datetime
import decimal
import unittest

import ingestra


# --- Test doubles ---


class _FixedColumnsSource(ingestra.DataSource):
    """Pretend table whose ``columns()`` returns a fixed list."""

    def __init__(self, columns):
        super().__init__()
        self._columns = columns

    def columns(self, refresh=False):
        return self._columns


class _EmptyColumns(ingestra.DataSource):
    """Pretend table with no columns (only used to call ``extract_row``)."""

    def columns(self, refresh=False):
        return []


# --- Core diff helpers (used by BigQuery and by callers) ---


class SchemaDiffHelperTests(unittest.TestCase):
    """Smoke tests for :meth:`deprecated_columns`, :meth:`missing_columns`, :meth:`changed_type_columns`."""

    def setUp(self):
        self.target_cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("old_col", "VARCHAR", ""),
        ]
        self.source_cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("new_col", "VARCHAR", ""),
        ]
        self.target = _FixedColumnsSource(self.target_cols)

    def test_when_source_dropped_a_column_target_still_has_it_as_extra(self):
        """Objective: Target still has old_col; source no longer lists it.
        Expectation: old_col is reported as present only on the target.
        """
        self.assertEqual(self.target.deprecated_columns(self.source_cols), {"old_col"})

    def test_when_source_adds_a_column_target_does_not_have_it_yet(self):
        """Objective: Source lists new_col; target does not.
        Expectation: new_col is reported as missing on the target.
        """
        self.assertEqual(self.target.missing_columns(self.source_cols), {"new_col"})

    def test_when_same_name_differs_by_logical_type_we_flag_type_change(self):
        """Objective: Column x exists on both sides but as different families (short text vs long text).
        Expectation: x shows up in the type-change list.
        """
        src = [ingestra.Column("id", "INTEGER", ""), ingestra.Column("x", "VARCHAR", "")]
        tgt = _FixedColumnsSource(
            [ingestra.Column("id", "INTEGER", ""), ingestra.Column("x", "TEXT", "")]
        )
        self.assertEqual(tgt.changed_type_columns(src), {"x"})


# --- Richer alignment scenarios (exact match vs type-only mismatch) ---


class ExactMatchTests(unittest.TestCase):
    """When source and target describe the same columns the same way."""

    def test_when_both_schemas_identical_nothing_to_add_remove_or_retype(self):
        """Objective: Source and target list the same fields with the same logical types.
        Expectation: Nothing is flagged as missing, extra-only, or type-mismatched; both columns count as exact matches.
        """
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        target = _FixedColumnsSource(list(cols))
        source = list(cols)
        self.assertEqual(target.deprecated_columns(source), set())
        self.assertEqual(target.missing_columns(source), set())
        self.assertEqual(target.changed_type_columns(source), set())
        self.assertEqual(target.exact_match_columns(source), {"id", "name"})

    def test_when_both_schemas_identical_summary_matches_piece_by_piece(self):
        """Objective: One-shot summary should say the same thing as the individual checks.
        Expectation: Summary reports both columns as exact matches and leaves the other buckets empty.
        """
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        target = _FixedColumnsSource(list(cols))
        source = list(cols)
        summary = target.schema_diff_summary(source)
        self.assertEqual(summary["exact_match"], {"id", "name"})
        self.assertEqual(summary["missing"], set())
        self.assertEqual(summary["deprecated"], set())
        self.assertEqual(summary["type_changed"], set())


class AddNewColumnTests(unittest.TestCase):
    """Source introduces a field the target does not have yet."""

    def test_when_source_has_extra_field_target_lists_it_as_missing(self):
        """Objective: Target has only id; source adds email as well.
        Expectation: Email is the only “missing on target” name; nothing is “only on target.”
        """
        target = _FixedColumnsSource([ingestra.Column("id", "INTEGER", "")])
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("email", "VARCHAR", ""),
        ]
        self.assertEqual(target.missing_columns(source), {"email"})
        self.assertEqual(target.deprecated_columns(source), set())


class DeleteOldColumnTests(unittest.TestCase):
    """Target still has a field the source no longer carries."""

    def test_when_target_has_extra_field_it_is_flagged_as_removed_from_source(self):
        """Objective: Target still has legacy; source only has id.
        Expectation: Legacy is the only “only on target” name; nothing is missing from the target side.
        """
        target = _FixedColumnsSource(
            [
                ingestra.Column("id", "INTEGER", ""),
                ingestra.Column("legacy", "TEXT", ""),
            ]
        )
        source = [ingestra.Column("id", "INTEGER", "")]
        self.assertEqual(target.deprecated_columns(source), {"legacy"})
        self.assertEqual(target.missing_columns(source), set())


class SimultaneousAddAndDropTests(unittest.TestCase):
    """Renaming or swapping one column for another between versions."""

    def test_when_one_column_replaced_by_another_old_dropped_and_new_missing(self):
        """Objective: Target has old_field; source replaces it with new_field; id unchanged.
        Expectation: old_field is only on target; new_field is only on source.
        """
        target = _FixedColumnsSource(
            [
                ingestra.Column("id", "INTEGER", ""),
                ingestra.Column("old_field", "VARCHAR", ""),
            ]
        )
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("new_field", "VARCHAR", ""),
        ]
        self.assertEqual(target.deprecated_columns(source), {"old_field"})
        self.assertEqual(target.missing_columns(source), {"new_field"})


class TypeChangeOnlyTests(unittest.TestCase):
    """Same column name, different logical type."""

    def test_when_type_differs_for_shared_name_it_is_not_an_exact_match(self):
        """Objective: id matches; x is text in source but short text in target (different family).
        Expectation: x is a type-change only; id is still an exact match; no add/remove-only names.
        """
        target = _FixedColumnsSource(
            [ingestra.Column("id", "INTEGER", ""), ingestra.Column("x", "VARCHAR", "")]
        )
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("x", "TEXT", ""),
        ]
        self.assertEqual(target.changed_type_columns(source), {"x"})
        self.assertEqual(target.exact_match_columns(source), {"id"})
        self.assertEqual(target.exact_match_columns(source) & target.changed_type_columns(source), set())
        self.assertEqual(target.deprecated_columns(source), set())
        self.assertEqual(target.missing_columns(source), set())

    def test_when_only_type_changes_exact_match_is_empty(self):
        """Objective: One column exists on both sides but with different types.
        Expectation: That name appears only under type-changed, not under exact match.
        """
        target = _FixedColumnsSource([ingestra.Column("sku", "INTEGER", "")])
        source = [ingestra.Column("sku", "VARCHAR", "")]
        self.assertEqual(target.exact_match_columns(source), set())
        self.assertEqual(target.changed_type_columns(source), {"sku"})


class SharedNamesPartitionTests(unittest.TestCase):
    """Every name that exists on both sides is either a full match or a type mismatch, not both."""

    def test_when_mix_of_same_type_and_changed_type_each_shared_name_in_one_bucket(self):
        """Objective: Three shared names: one unchanged, two with different types on target vs source.
        Expectation: Shared names split cleanly: exact matches and type-changes do not overlap and together cover every shared name.
        """
        target = _FixedColumnsSource(
            [
                ingestra.Column("id", "INTEGER", ""),
                ingestra.Column("a", "VARCHAR", ""),
                ingestra.Column("b", "INTEGER", ""),
            ]
        )
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("a", "TEXT", ""),
            ingestra.Column("b", "FLOAT", ""),
        ]
        exact = target.exact_match_columns(source)
        changed = target.changed_type_columns(source)
        target_names = set(target.column_names())
        source_names = {c.name for c in source}
        shared = target_names & source_names
        self.assertEqual(shared, exact | changed)
        self.assertEqual(exact & changed, set())
        self.assertEqual(exact, {"id"})
        self.assertEqual(changed, {"a", "b"})

    def test_when_add_drop_and_match_together_summary_matches_individual_checks(self):
        """Objective: Target has id plus a column to drop; source has id plus a new column.
        Expectation: Summary fields match running missing / removed / exact / type-change helpers separately.
        """
        target = _FixedColumnsSource(
            [ingestra.Column("id", "INTEGER", ""), ingestra.Column("drop_me", "VARCHAR", "")]
        )
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("x", "TEXT", ""),
        ]
        s = target.schema_diff_summary(source)
        self.assertEqual(s["exact_match"], target.exact_match_columns(source))
        self.assertEqual(s["missing"], target.missing_columns(source))
        self.assertEqual(s["deprecated"], target.deprecated_columns(source))
        self.assertEqual(s["type_changed"], target.changed_type_columns(source))
        self.assertEqual(s["exact_match"], {"id"})
        self.assertEqual(s["missing"], {"x"})
        self.assertEqual(s["deprecated"], {"drop_me"})
        self.assertEqual(s["type_changed"], set())


class DisjointSchemasTests(unittest.TestCase):
    """No column name appears on both sides."""

    def test_when_no_shared_names_everything_is_add_or_remove_only(self):
        """Objective: Target has a; source has b; no overlap.
        Expectation: a is only on target; b is only on source; no type-change set because nothing is shared.
        """
        target = _FixedColumnsSource([ingestra.Column("a", "INTEGER", "")])
        source = [ingestra.Column("b", "INTEGER", "")]
        self.assertEqual(target.deprecated_columns(source), {"a"})
        self.assertEqual(target.missing_columns(source), {"b"})
        self.assertEqual(target.changed_type_columns(source), set())


class MultiColumnTypeChangeTests(unittest.TestCase):
    """Several columns change type at once."""

    def test_when_multiple_shared_names_change_type_all_are_listed(self):
        """Objective: id stays integer; two other columns change logical type between target and source.
        Expectation: Both changed columns appear in the type-change set together.
        """
        target = _FixedColumnsSource(
            [
                ingestra.Column("id", "INTEGER", ""),
                ingestra.Column("n1", "INTEGER", ""),
                ingestra.Column("n2", "FLOAT", ""),
            ]
        )
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("n1", "VARCHAR", ""),
            ingestra.Column("n2", "INTEGER", ""),
        ]
        self.assertEqual(target.changed_type_columns(source), {"n1", "n2"})


# --- Row export ---


class ExtractRowCoercionTests(unittest.TestCase):
    """Values that need transforming before :func:`json.dumps` on a line."""

    def setUp(self):
        self.ds = _FixedColumnsSource([])

    def test_when_cell_is_nested_mapping_it_becomes_json_text(self):
        """Objective: Nested objects cannot go raw into one JSON line as a nested object easily.
        Expectation: We serialize the dict to a JSON string in the cell.
        """
        row = {"meta": {"k": "v"}}
        out = self.ds.extract_row(row)
        self.assertEqual(out["meta"], '{"k": "v"}')

    def test_when_cell_is_list_it_becomes_json_text(self):
        """Objective: Arrays should survive export as readable JSON.
        Expectation: List becomes a JSON array string.
        """
        row = {"tags": [1, 2]}
        out = self.ds.extract_row(row)
        self.assertEqual(out["tags"], "[1, 2]")

    def test_when_cell_is_full_timestamp_we_use_fixed_string_format(self):
        """Objective: Date+time values need a stable string form for loaders.
        Expectation: Fixed pattern with date, time, and fractional seconds.
        """
        row = {"ts": datetime.datetime(2024, 6, 1, 12, 30, 45, 123456)}
        out = self.ds.extract_row(row)
        self.assertEqual(out["ts"], "2024-06-01 12:30:45.123456")

    def test_when_cell_is_date_only_we_use_iso_date(self):
        """Objective: Calendar dates should be unambiguous strings.
        Expectation: ISO year-month-day.
        """
        row = {"d": datetime.date(2024, 6, 1)}
        out = self.ds.extract_row(row)
        self.assertEqual(out["d"], "2024-06-01")

    def test_when_cell_is_decimal_we_use_float_for_json(self):
        """Objective: JSON has no native decimal; use a number.
        Expectation: Decimal becomes a float close to the same value.
        """
        row = {"n": decimal.Decimal("3.14")}
        out = self.ds.extract_row(row)
        self.assertAlmostEqual(out["n"], 3.14)

    def test_when_mysql_sends_single_byte_flags_we_map_to_zero_or_one(self):
        """Objective: Some drivers return single-byte blobs for boolean/bit columns.
        Expectation: 0x01 → 1, 0x00 → 0.
        """
        row = {"b1": b"\x01", "b0": b"\x00"}
        out = self.ds.extract_row(row)
        self.assertEqual(out["b1"], 1)
        self.assertEqual(out["b0"], 0)

    def test_when_cell_is_raw_bytes_we_decode_as_utf8_text(self):
        """Objective: Text that arrives as bytes should become a normal string.
        Expectation: UTF-8 decode of the bytes.
        """
        row = {"s": b"hello"}
        out = self.ds.extract_row(row)
        self.assertEqual(out["s"], "hello")


class ExtractRowPassThroughTests(unittest.TestCase):
    """Types we leave as-is when they already work in JSON."""

    def setUp(self):
        self.ds = _EmptyColumns()

    def test_when_cell_is_none_it_stays_empty(self):
        """Objective: Missing values should stay clearly empty.
        Expectation: Output cell is None.
        """
        self.assertIsNone(self.ds.extract_row({"x": None})["x"])

    def test_when_cell_is_whole_number_it_stays_a_number(self):
        """Objective: Integers should round-trip in JSON.
        Expectation: Same integer value.
        """
        self.assertEqual(self.ds.extract_row({"n": 42})["n"], 42)

    def test_when_cell_is_fractional_number_it_stays_a_number(self):
        """Objective: Floats should round-trip in JSON.
        Expectation: Same float value.
        """
        self.assertEqual(self.ds.extract_row({"f": 1.5})["f"], 1.5)

    def test_when_cell_is_true_or_false_we_keep_boolean(self):
        """Objective: Booleans are native JSON.
        Expectation: True and False stay as booleans.
        """
        self.assertIs(self.ds.extract_row({"a": True})["a"], True)
        self.assertIs(self.ds.extract_row({"b": False})["b"], False)

    def test_when_cell_is_plain_text_it_stays_text(self):
        """Objective: Ordinary strings need no conversion.
        Expectation: Same string.
        """
        self.assertEqual(self.ds.extract_row({"s": "plain"})["s"], "plain")

    def test_when_cell_is_empty_string_it_stays_empty_string(self):
        """Objective: Empty string is a valid value.
        Expectation: Still empty string, not null.
        """
        self.assertEqual(self.ds.extract_row({"s": ""})["s"], "")

    def test_when_cell_is_empty_object_we_emit_empty_json_object_string(self):
        """Objective: Empty dict should serialize predictably.
        Expectation: "{}" string.
        """
        self.assertEqual(self.ds.extract_row({"m": {}})["m"], "{}")

    def test_when_cell_is_empty_list_we_emit_empty_json_array_string(self):
        """Objective: Empty list should serialize predictably.
        Expectation: "[]" string.
        """
        self.assertEqual(self.ds.extract_row({"a": []})["a"], "[]")


class ExtractRowDecimalEdgeTests(unittest.TestCase):
    """Decimal values that are whole or very precise."""

    def setUp(self):
        self.ds = _EmptyColumns()

    def test_when_decimal_has_no_fraction_we_still_output_a_float(self):
        """Objective: Whole-number decimals are common from databases.
        Expectation: Float 7.0, not string.
        """
        self.assertEqual(self.ds.extract_row({"n": decimal.Decimal("7")})["n"], 7.0)

    def test_when_decimal_has_many_digits_we_preserve_value_approximately(self):
        """Objective: High-precision decimals should not explode JSON.
        Expectation: Float close to the decimal value.
        """
        out = self.ds.extract_row({"n": decimal.Decimal("1.23456789")})["n"]
        self.assertAlmostEqual(out, 1.23456789)


# --- Metadata lookup ---


class GetColumnLookupTests(unittest.TestCase):
    """Look up one column’s metadata by name."""

    def test_when_name_exists_we_get_that_columns_metadata(self):
        """Objective: Find column a in a short list.
        Expectation: Same object as in the list.
        """
        cols = [ingestra.Column("a", "INTEGER", "")]
        ds = _FixedColumnsSource(cols)
        self.assertIs(ds.get_column("a"), cols[0])

    def test_when_name_does_not_exist_we_get_nothing(self):
        """Objective: Ask for a column that is not in the table metadata.
        Expectation: None.
        """
        ds = _FixedColumnsSource([ingestra.Column("a", "INTEGER", "")])
        self.assertIsNone(ds.get_column("missing"))


# --- Engine wiring ---


class RedshiftUsesPostgresImplementationTests(unittest.TestCase):
    """Redshift is a source engine; it reuses the PostgreSQL implementation in this package."""

    def test_when_using_redshift_we_reuse_postgres_behavior(self):
        """Objective: Redshift is implemented as a thin specialization of PostgreSQL in this library.
        Expectation: The Redshift class subclasses the PostgreSQL source (same SQL/metadata patterns).
        """
        self.assertTrue(issubclass(ingestra.Redshift, ingestra.PostgreSQL))


if __name__ == "__main__":
    unittest.main()
