"""PostgreSQL and MySQL targets: heap ``*_delta`` DDL and upsert/overwrite SQL (dry-run)."""

import unittest
from unittest.mock import MagicMock, patch

import ingestra


def _prints_from_pg_create(pg, source_columns, deletion_rule, **kwargs):
    pg.dry_run = True
    with patch("builtins.print") as pr:
        pg.create(source_columns, deletion_rule, **kwargs)
    return [c.args[0] for c in pr.call_args_list if c.args]


def _capture_pg_upsert_sql(pg, primary_keys, columns):
    pg.dry_run = True
    with patch.object(pg, "columns", return_value=columns):
        with patch("builtins.print") as pr:
            pg.upsert(primary_keys)
    pr.assert_called_once()
    return pr.call_args[0][0]


def _prints_from_mysql_create(mysql, source_columns, deletion_rule, **kwargs):
    mysql.dry_run = True
    with patch("builtins.print") as pr:
        mysql.create(source_columns, deletion_rule, **kwargs)
    return [c.args[0] for c in pr.call_args_list if c.args]


def _prints_from_pg_alter(pg, source_columns, deletion_rule, **kwargs):
    pg.dry_run = True
    with patch("builtins.print") as pr:
        pg.alter(source_columns, deletion_rule, **kwargs)
    return [c.args[0] for c in pr.call_args_list if c.args]


def _prints_from_mysql_alter(mysql, source_columns, deletion_rule, **kwargs):
    mysql.dry_run = True
    with patch("builtins.print") as pr:
        mysql.alter(source_columns, deletion_rule, **kwargs)
    return [c.args[0] for c in pr.call_args_list if c.args]


class PostgreSQLDeltaHeapHelpersTests(unittest.TestCase):
    def test_when_dropping_delta_heap_we_target_schema_qualified_delta_name(self):
        """Objective: drop_delta_heap_table matches create_delta_heap_table naming."""
        pg = ingestra.PostgreSQL("orders", "warehouse")
        sql = pg.drop_delta_heap_table()
        self.assertIn("DROP TABLE IF EXISTS", sql)
        self.assertIn('"warehouse"."orders_delta"', sql)

    def test_when_creating_delta_heap_we_list_source_columns(self):
        pg = ingestra.PostgreSQL("orders", "public")
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("sku", "VARCHAR", ""),
        ]
        sql = pg.create_delta_heap_table(cols)
        self.assertIn('CREATE TABLE "public"."orders_delta"', sql)
        self.assertIn('"id"', sql)
        self.assertIn('"sku"', sql)

    def test_delta_heap_columns_queries_information_schema_for_delta_table(self):
        """Objective: Staging loads use ``*_delta`` columns, not the main table (e.g. soft-delete flag)."""
        pg = ingestra.PostgreSQL("orders", "public")
        pg.conn = MagicMock()
        cur = MagicMock()
        cm = MagicMock()
        cm.__enter__.return_value = cur
        cm.__exit__.return_value = False
        pg.conn.cursor.return_value = cm
        cur.fetchall.return_value = [
            {
                "column_name": "id",
                "data_type": "integer",
                "character_maximum_length": None,
                "numeric_precision": None,
                "numeric_scale": None,
            },
        ]
        cols = pg.delta_heap_columns(refresh=True)
        cur.execute.assert_called_once()
        self.assertIn("orders_delta", cur.execute.call_args[0][0])
        self.assertEqual([c.name for c in cols], ["id"])


class PostgreSQLTargetCreateTests(unittest.TestCase):
    def test_when_creating_target_we_build_main_and_delta_heap_tables(self):
        """Objective: PostgreSQL target mirrors BigQuery’s two-table idea without GCS."""
        pg = ingestra.PostgreSQL("events", "public")
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        stmts = _prints_from_pg_create(pg, cols, ingestra.Delete())
        joined = "\n".join(stmts)
        self.assertIn('"public"."events_delta"', joined)
        self.assertIn("DROP TABLE IF EXISTS", joined)
        self.assertIn('"public"."events"', joined)
        self.assertIn('"id" BIGINT', joined)
        self.assertIn('"name" CHARACTER VARYING', joined)

    def test_when_soft_delete_rule_we_add_flag_column_to_main_table_only(self):
        """Objective: MarkAsDeleted extends the main table DDL, not the staging extract shape."""
        pg = ingestra.PostgreSQL("events", "app")
        cols = [ingestra.Column("id", "INTEGER", "")]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        stmts = _prints_from_pg_create(pg, cols, rule)
        delta_sql = stmts[0] + stmts[1]
        main_sql = stmts[2]
        self.assertNotIn("is_deleted", delta_sql)
        self.assertIn('"is_deleted"', main_sql)

    def test_when_primary_keys_passed_create_adds_primary_key_on_main_table_only(self):
        """Objective: ON CONFLICT needs a unique constraint; PK is declared on main table, not delta."""
        pg = ingestra.PostgreSQL("events", "public", primary_keys=["id"])
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        stmts = _prints_from_pg_create(pg, cols, ingestra.Delete())
        delta_sql = stmts[0] + stmts[1]
        main_sql = stmts[2]
        self.assertNotIn("PRIMARY KEY", delta_sql)
        self.assertIn('PRIMARY KEY ("id")', main_sql)

    def test_when_primary_keys_not_columns_create_raises(self):
        pg = ingestra.PostgreSQL("events", "public", primary_keys=["nope"])
        cols = [ingestra.Column("id", "INTEGER", "")]
        with self.assertRaises(ValueError) as ctx:
            _prints_from_pg_create(pg, cols, ingestra.Delete())
        self.assertIn("nope", str(ctx.exception))


class PostgreSQLTargetUpsertTests(unittest.TestCase):
    def test_when_upserting_we_use_on_conflict_do_update(self):
        """Objective: Upsert path matches BigQuery’s “merge all columns” behavior."""
        pg = ingestra.PostgreSQL("t", "public")
        columns = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        sql = _capture_pg_upsert_sql(pg, ["id"], columns)
        self.assertRegex(
            sql,
            r'ON CONFLICT\s*\(\s*"id"\s*\)\s*DO UPDATE SET',
            msg="Upsert should use ON CONFLICT on the primary key, then DO UPDATE SET",
        )
        self.assertIn('FROM "public"."t_delta"', sql)


class PostgreSQLTargetAlterTests(unittest.TestCase):
    def test_when_source_drops_a_column_we_emit_drop_on_main_and_rebuild_delta(self):
        """Objective: alter() refreshes staging and removes columns no longer in the source."""
        pg = ingestra.PostgreSQL("t", "public")
        pg.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("legacy", "VARCHAR", ""),
        ]
        source = [ingestra.Column("id", "INTEGER", "")]
        stmts = _prints_from_pg_alter(pg, source, ingestra.KeepUntouched())
        joined = "\n".join(stmts)
        self.assertIn("DROP TABLE IF EXISTS", joined)
        self.assertIn('"public"."t_delta"', joined)
        self.assertIn("DROP COLUMN IF EXISTS", joined)
        self.assertIn('"legacy"', joined)

    def test_when_source_adds_columns_we_emit_add_on_main(self):
        pg = ingestra.PostgreSQL("t", "public")
        pg.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("extra", "VARCHAR", ""),
        ]
        stmts = _prints_from_pg_alter(pg, source, ingestra.KeepUntouched())
        add_stmts = [s for s in stmts if "ADD COLUMN" in s]
        self.assertTrue(any('"extra"' in s for s in add_stmts))

    def test_when_soft_delete_enabled_we_do_not_drop_the_flag_column(self):
        pg = ingestra.PostgreSQL("t", "public")
        pg.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        source = [ingestra.Column("id", "INTEGER", "")]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        stmts = _prints_from_pg_alter(pg, source, rule)
        drop_sql = "\n".join(s for s in stmts if "DROP COLUMN" in s)
        self.assertNotIn("is_deleted", drop_sql)

    def test_when_alter_with_primary_keys_we_emit_do_block_to_add_pk_if_missing(self):
        """Objective: existing tables without PK get one so merge ON CONFLICT can run."""
        pg = ingestra.PostgreSQL("t", "public", primary_keys=["id"])
        pg.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [ingestra.Column("id", "INTEGER", "")]
        stmts = _prints_from_pg_alter(pg, source, ingestra.KeepUntouched())
        joined = "\n".join(stmts)
        self.assertIn("DO $ingestra_ensure_pk$", joined)
        self.assertIn("ADD PRIMARY KEY", joined)
        self.assertIn('"id"', joined)


class PostgreSQLTargetOverwriteTests(unittest.TestCase):
    def test_when_overwrite_with_delete_we_emit_merge_then_delete_orphans(self):
        pg = ingestra.PostgreSQL("t", "public")
        columns = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        pg.primary_keys = ["id"]
        pg.dry_run = True
        with patch.object(pg, "columns", return_value=columns):
            with patch("builtins.print") as pr:
                pg.overwrite(None, ingestra.Delete())
        self.assertEqual(len(pr.call_args_list), 2)
        upsert, delete = pr.call_args_list[0][0][0], pr.call_args_list[1][0][0]
        self.assertRegex(
            upsert,
            r"ON CONFLICT\s*\(\s*\"id\"\s*\)",
        )
        self.assertIn("DELETE FROM", delete)
        self.assertIn("NOT EXISTS", delete)

    def test_when_overwrite_with_mark_as_deleted_we_emit_soft_delete_for_orphans(self):
        pg = ingestra.PostgreSQL("t", "public")
        columns = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        pg.primary_keys = ["id"]
        pg.dry_run = True
        with patch.object(pg, "columns", return_value=columns):
            with patch("builtins.print") as pr:
                pg.overwrite(None, rule)
        self.assertEqual(len(pr.call_args_list), 2)
        tombstone = pr.call_args_list[1][0][0]
        self.assertIn("UPDATE", tombstone)
        self.assertIn('"is_deleted"', tombstone)
        self.assertIn("NOT EXISTS", tombstone)


class MySQLDeltaHeapHelpersTests(unittest.TestCase):
    def test_when_dropping_delta_heap_we_use_backtick_delta_suffix(self):
        mysql = ingestra.MySQL("orders", "db")
        sql = mysql.drop_delta_heap_table()
        self.assertIn("DROP TABLE IF EXISTS", sql)
        self.assertIn("`orders_delta`", sql)

    def test_when_creating_delta_heap_we_list_source_columns(self):
        mysql = ingestra.MySQL("items", "db")
        cols = [ingestra.Column("id", "INTEGER", "")]
        sql = mysql.create_delta_heap_table(cols)
        self.assertIn("CREATE TABLE `items_delta`", sql)
        self.assertIn("`id`", sql)

    def test_mysql_varchar_columns_include_length_in_ddl(self):
        """MySQL rejects bare VARCHAR; we emit VARCHAR(M) from metadata or default 255."""
        mysql = ingestra.MySQL("dag", "db")
        with_len = ingestra.Column(
            "dag_id", "VARCHAR", "", character_maximum_length=250)
        no_len = ingestra.Column("note", "VARCHAR", "")
        sql = mysql.create_delta_heap_table([with_len, no_len])
        self.assertIn("`dag_id` VARCHAR(250)", sql.replace("\n", " "))
        self.assertIn("`note` VARCHAR(255)", sql.replace("\n", " "))

    def test_delta_heap_columns_queries_information_schema_for_delta_table(self):
        """Objective: Staging loads use ``*_delta`` columns, not the main table (e.g. soft-delete flag)."""
        mysql = ingestra.MySQL("orders", "db")
        mysql.conn = MagicMock()
        cur = MagicMock()
        cm = MagicMock()
        cm.__enter__.return_value = cur
        cm.__exit__.return_value = False
        mysql.conn.cursor.return_value = cm
        cur.fetchall.return_value = [
            ("id", "INT", None, None, None),
        ]
        cols = mysql.delta_heap_columns(refresh=True)
        cur.execute.assert_called_once()
        self.assertIn("orders_delta", cur.execute.call_args[0][0])
        self.assertEqual([c.name for c in cols], ["id"])


class MySQLTargetCreateTests(unittest.TestCase):
    def test_when_creating_target_we_name_delta_with_backticks(self):
        mysql = ingestra.MySQL("events", "db1")
        cols = [ingestra.Column("id", "INTEGER", "")]
        stmts = _prints_from_mysql_create(mysql, cols, ingestra.Delete())
        self.assertTrue(any("`events_delta`" in s for s in stmts))
        self.assertTrue(any("CREATE TABLE `events`" in s for s in stmts))

    def test_when_primary_keys_on_mysql_create_main_table_has_primary_key_not_delta(self):
        mysql = ingestra.MySQL("events", "db1", primary_keys=["id"])
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        stmts = _prints_from_mysql_create(mysql, cols, ingestra.Delete())
        delta_block = "\n".join(stmts[:2])
        main_sql = stmts[-1]
        self.assertNotIn("PRIMARY KEY", delta_block)
        self.assertIn("PRIMARY KEY (`id`)", main_sql)


class MySQLTargetAlterTests(unittest.TestCase):
    def test_when_source_drops_a_column_we_rebuild_delta_and_drop_column(self):
        mysql = ingestra.MySQL("t", "db")
        mysql.cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("old_col", "VARCHAR", ""),
        ]
        source = [ingestra.Column("id", "INTEGER", "")]
        stmts = _prints_from_mysql_alter(mysql, source, ingestra.KeepUntouched())
        joined = "\n".join(stmts)
        self.assertIn("`t_delta`", joined)
        self.assertTrue(any("DROP COLUMN `old_col`" in s for s in stmts))

    def test_when_source_adds_columns_we_emit_alter_add(self):
        mysql = ingestra.MySQL("t", "db")
        mysql.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("note", "TEXT", ""),
        ]
        stmts = _prints_from_mysql_alter(mysql, source, ingestra.KeepUntouched())
        self.assertTrue(any("ADD COLUMN `note`" in s for s in stmts))

    def test_when_mysql_alter_with_primary_keys_dry_run_prints_pk_ensure_hint(self):
        mysql = ingestra.MySQL("t", "db", primary_keys=["id"])
        mysql.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [ingestra.Column("id", "INTEGER", "")]
        stmts = _prints_from_mysql_alter(mysql, source, ingestra.KeepUntouched())
        joined = "\n".join(stmts)
        self.assertIn("PRIMARY KEY", joined)


class MySqlEnsurePrimaryKeyTests(unittest.TestCase):
    def test_ensure_pk_raises_clear_error_when_merge_columns_have_duplicates(self):
        """Objective: MySQL 1062 on ADD PRIMARY KEY becomes an actionable ValueError."""
        mysql = ingestra.MySQL("dag", primary_keys=["dag_id"])
        mysql.dry_run = False
        mysql.conn = MagicMock()
        cur = MagicMock()
        cm = MagicMock()
        cm.__enter__.return_value = cur
        cm.__exit__.return_value = False
        mysql.conn.cursor.return_value = cm
        cur.fetchone.side_effect = [(0,), (1,)]
        with self.assertRaises(ValueError) as ctx:
            mysql._mysql_ensure_primary_key(["dag_id"])
        self.assertIn("duplicate", str(ctx.exception).lower())
        self.assertIn("dag", str(ctx.exception))


class MySQLTargetUpsertTests(unittest.TestCase):
    def test_when_upserting_we_use_on_duplicate_key_update(self):
        mysql = ingestra.MySQL("t", "db")
        columns = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        mysql.primary_keys = ["id"]
        mysql.dry_run = True
        with patch.object(mysql, "columns", return_value=columns):
            with patch("builtins.print") as pr:
                mysql.upsert()
        pr.assert_called_once()
        sql = pr.call_args[0][0]
        self.assertIn("ON DUPLICATE KEY UPDATE", sql)
        self.assertIn("FROM `t_delta`", sql)
        self.assertIn("VALUES(`id`)", sql)


class MySQLTargetOverwriteTests(unittest.TestCase):
    def test_when_overwrite_with_delete_we_emit_upsert_then_left_join_delete(self):
        mysql = ingestra.MySQL("t", "db")
        columns = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        mysql.primary_keys = ["id"]
        mysql.dry_run = True
        with patch.object(mysql, "columns", return_value=columns):
            with patch("builtins.print") as pr:
                mysql.overwrite(None, ingestra.Delete())
        self.assertEqual(len(pr.call_args_list), 2)
        upsert, delete = pr.call_args_list[0][0][0], pr.call_args_list[1][0][0]
        self.assertIn("ON DUPLICATE KEY UPDATE", upsert)
        self.assertIn("DELETE t FROM", delete)
        self.assertIn("LEFT JOIN", delete)

    def test_when_overwrite_with_mark_as_deleted_second_statement_updates_orphans(self):
        mysql = ingestra.MySQL("t", "db")
        columns = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("deleted", "INTEGER", ""),
        ]
        rule = ingestra.MarkAsDeleted("deleted", value=1, default_value=0)
        mysql.primary_keys = ["id"]
        mysql.dry_run = True
        with patch.object(mysql, "columns", return_value=columns):
            with patch("builtins.print") as pr:
                mysql.overwrite(None, rule)
        self.assertEqual(len(pr.call_args_list), 2)
        second = pr.call_args_list[1][0][0]
        self.assertIn("UPDATE", second)
        self.assertIn("`deleted`", second)
        self.assertIn("WHERE d.`id` IS NULL", second.replace("\n", " "))


class IngestWithSqlTargetTests(unittest.TestCase):
    def test_when_target_is_empty_postgresql_we_call_create_with_source_columns(self):
        """Objective: Ingest.create_or_update_target_schema works with PostgreSQL as target (no DB)."""
        source = MagicMock()
        source.columns.return_value = [
            ingestra.Column("id", "INTEGER", ""),
        ]
        pg = ingestra.PostgreSQL("dim_customer", "staging")
        pg.cols = []
        job = ingestra.Ingest(source, pg, deletion_rule=ingestra.Delete(), dry_run=True)
        with patch.object(pg, "create", wraps=pg.create) as create_fn:
            job.create_or_update_target_schema()
        create_fn.assert_called_once()
        args, kwargs = create_fn.call_args
        self.assertEqual(args[0], source.columns.return_value)
        self.assertIsInstance(args[1], ingestra.Delete)
        self.assertEqual(kwargs, {})


class MarkAsDeletedSourceColumnConflictTests(unittest.TestCase):
    """``MarkAsDeleted`` adds a target-only column; the same name must not appear in ``source_columns``."""

    def test_postgresql_create_raises_when_source_lists_rule_column(self):
        pg = ingestra.PostgreSQL("t", "public")
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        with self.assertRaises(ValueError) as ctx:
            _prints_from_pg_create(pg, source, rule)
        self.assertIn("MarkAsDeleted", str(ctx.exception))

    def test_postgresql_alter_raises_when_source_lists_rule_column(self):
        pg = ingestra.PostgreSQL("t", "public")
        pg.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        rule = ingestra.MarkAsDeleted("is_deleted", value=1, default_value=0)
        with self.assertRaises(ValueError) as ctx:
            _prints_from_pg_alter(pg, source, rule)
        self.assertIn("is_deleted", str(ctx.exception))

    def test_mysql_create_raises_when_source_lists_rule_column(self):
        mysql = ingestra.MySQL("t", "db")
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("deleted", "INTEGER", ""),
        ]
        rule = ingestra.MarkAsDeleted("deleted", value=1, default_value=0)
        with self.assertRaises(ValueError) as ctx:
            _prints_from_mysql_create(mysql, source, rule)
        self.assertIn("deleted", str(ctx.exception))

    def test_mysql_alter_raises_when_source_lists_rule_column(self):
        mysql = ingestra.MySQL("t", "db")
        mysql.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("deleted", "INTEGER", ""),
        ]
        rule = ingestra.MarkAsDeleted("deleted", value=1, default_value=0)
        with self.assertRaises(ValueError) as ctx:
            _prints_from_mysql_alter(mysql, source, rule)
        self.assertIn("deleted", str(ctx.exception))


class CoerceNdjsonForPostgresTests(unittest.TestCase):
    """NDJSON from MySQL (0/1 flags, etc.) must map to types psycopg2 sends for PG columns."""

    def _col(self, data_type: str) -> ingestra.Column:
        return ingestra.Column("c", data_type, "")

    def test_boolean_coerces_mysql_style_integers_to_python_bool(self):
        """Objective: PG BOOLEAN rejects int parameters; MySQL-style 0/1 become bool."""
        c = self._col("BOOLEAN")
        fn = ingestra.coerce_ndjson_value_for_postgres
        self.assertIs(fn(0, c), False)
        self.assertIs(fn(1, c), True)
        self.assertIs(fn(2, c), True)
        self.assertIs(fn(True, c), True)
        self.assertIs(fn(False, c), False)
        self.assertIsNone(fn(None, c))

    def test_boolean_coerces_json_float_and_string_forms(self):
        c = self._col("BOOLEAN")
        fn = ingestra.coerce_ndjson_value_for_postgres
        self.assertIs(fn(0.0, c), False)
        self.assertIs(fn(1.0, c), True)
        self.assertIs(fn("1", c), True)
        self.assertIs(fn("0", c), False)
        self.assertIs(fn("true", c), True)
        self.assertIs(fn("FALSE", c), False)
        self.assertIs(fn("yes", c), True)
        self.assertIs(fn("off", c), False)

    def test_integer_coerces_whole_number_floats_from_json(self):
        c = self._col("INTEGER")
        fn = ingestra.coerce_ndjson_value_for_postgres
        self.assertEqual(fn(3.0, c), 3)
        self.assertEqual(fn(42, c), 42)
        self.assertEqual(fn(3.5, c), 3.5)

    def test_unknown_type_passes_value_through(self):
        c = ingestra.Column("x", None, "")
        self.assertEqual(ingestra.coerce_ndjson_value_for_postgres(7, c), 7)


class RedshiftTargetTests(unittest.TestCase):
    def test_when_redshift_creates_target_it_does_not_emit_primary_key(self):
        rs = ingestra.Redshift("events", "public", primary_keys=["id"])
        rs.dry_run = True
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        with patch("builtins.print") as pr:
            rs.create(cols, ingestra.Delete())
        joined = "\n".join(c.args[0] for c in pr.call_args_list if c.args)
        self.assertIn('"public"."events"', joined)
        self.assertNotIn('"public"."events_delta"', joined)
        self.assertNotIn("PRIMARY KEY", joined)

    def test_when_redshift_alter_with_primary_keys_it_does_not_emit_pk_do_block(self):
        rs = ingestra.Redshift("t", "public", primary_keys=["id"])
        rs.dry_run = True
        rs.cols = [ingestra.Column("id", "INTEGER", "")]
        source = [ingestra.Column("id", "INTEGER", "")]
        with patch("builtins.print") as pr:
            rs.alter(source, ingestra.KeepUntouched())
        joined = "\n".join(c.args[0] for c in pr.call_args_list if c.args)
        self.assertNotIn('"public"."t_delta"', joined)
        self.assertNotIn("DO $ingestra_ensure_pk$", joined)
        self.assertNotIn("PRIMARY KEY", joined)

    def test_when_redshift_upserts_we_emit_update_then_insert_not_exists(self):
        rs = ingestra.Redshift("t", "public", primary_keys=["id"])
        rs.dry_run = True
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        with patch.object(rs, "columns", return_value=cols):
            with patch("builtins.print") as pr:
                rs.upsert()
        self.assertEqual(len(pr.call_args_list), 2)
        update_sql = pr.call_args_list[0][0][0]
        insert_sql = pr.call_args_list[1][0][0]
        self.assertIn('UPDATE "public"."t" AS t', update_sql)
        self.assertIn('FROM "public"."t_delta" AS d', update_sql)
        self.assertIn('INSERT INTO "public"."t"', insert_sql)
        self.assertIn("WHERE NOT EXISTS", insert_sql)

    def test_when_redshift_loads_delta_from_cloud_storage_with_iam_role_we_emit_copy(self):
        rs = ingestra.Redshift("t", "public")
        rs.dry_run = True
        with patch("builtins.print") as pr:
            rs.load_delta_from_cloud_storage(
                cloud_storage_path="s3://bucket/path/prefix",
                cloud_credentials=ingestra.AwsIamRoleCredentials(
                    iam_role="arn:aws:iam::123456789012:role/redshift-copy"
                ),
                region="eu-west-1",
            )
        self.assertEqual(len(pr.call_args_list), 2)
        copy_sql = pr.call_args_list[1][0][0]
        self.assertIn("COPY", copy_sql)
        self.assertIn("IAM_ROLE", copy_sql)
        self.assertIn("FORMAT AS JSON 'auto'", copy_sql)

    def test_when_redshift_prepares_delta_from_cloud_storage_we_use_single_uri(self):
        rs = ingestra.Redshift("t", "public")
        rs.dry_run = True
        spec = ingestra.CloudStorageDeltaSpec(
            uris=["s3://bucket/path/prefix"],
            credentials=ingestra.AwsIamRoleCredentials(
                iam_role="arn:aws:iam::123456789012:role/redshift-copy"
            ),
            region="eu-west-1",
            truncate=False,
        )
        with patch("builtins.print") as pr:
            rs.prepare_target_delta_from_cloud_storage(
                [ingestra.Column("id", "INTEGER", "")], spec
            )
        printed_sql = [c.args[0] for c in pr.call_args_list if c.args]
        joined = "\n".join(printed_sql)
        self.assertIn("DROP TABLE IF EXISTS", joined)
        self.assertIn("CREATE TABLE", joined)
        self.assertIn('"public"."t_delta"', joined)
        # truncate=False keeps COPY-only load step (no TRUNCATE).
        self.assertNotIn("TRUNCATE TABLE", joined)
        self.assertIn("COPY", joined)

    def test_when_redshift_extracts_to_cloud_storage_we_emit_unload(self):
        rs = ingestra.Redshift("t", "public")
        rs.dry_run = True
        cols = [ingestra.Column("id", "INTEGER", "")]
        with patch.object(rs, "columns", return_value=cols):
            with patch("builtins.print") as pr:
                rs.extract_to_cloud_storage(
                    cloud_storage_path="s3://bucket/out/prefix",
                    cloud_credentials=ingestra.AwsIamRoleCredentials(
                        iam_role="arn:aws:iam::123456789012:role/redshift-unload"
                    ),
                )
        pr.assert_called_once()
        sql = pr.call_args[0][0]
        self.assertIn("UNLOAD", sql)
        self.assertIn("TO 's3://bucket/out/prefix'", sql)
        self.assertIn("FORMAT AS JSON 'auto'", sql)


