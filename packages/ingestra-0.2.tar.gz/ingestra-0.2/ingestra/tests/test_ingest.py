"""High-level job: extract to file and ask the target to create or patch schema."""

import json
import os
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import ingestra


class _RowsSource(ingestra.DataSource):
    def __init__(self, rows):
        super().__init__()
        self._rows = rows

    def columns(self, refresh=False):
        return []

    def extract(self):
        for row in self._rows:
            yield row


class _ApiDeltaSourceNoColumn(ingestra.DataSource):
    def columns(self, refresh=False):
        return []

    def extract(self):
        return iter(())

    def extract_delta(self, column_name=None, start_time=None, end_time=None, sql_from=None):
        yield {"base_currency": "EUR", "quote_currency": "USD", "rate": 1.1}


class ExtractToLocalFileTests(unittest.TestCase):
    def test_when_extracting_all_rows_we_write_one_json_object_per_line(self):
        """Objective: Pull every row from the source into a local file for upload.
        Expectation: File has two lines, each parses as JSON with the expected ids.
        """
        source = _RowsSource([{"id": 1}, {"id": 2}])
        target = MagicMock()
        job = ingestra.Ingest(source, target)
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".ndjson") as tmp:
            path = tmp.name
        try:
            with patch.object(job, "get_temporary_file_name", return_value=path):
                out = job.extract_to_local_file()
            self.assertEqual(out, path)
            with open(path) as fp:
                lines = fp.read().strip().split("\n")
            self.assertEqual(len(lines), 2)
            self.assertEqual(json.loads(lines[0]), {"id": 1})
            self.assertEqual(json.loads(lines[1]), {"id": 2})
        finally:
            os.unlink(path)

    def test_when_api_style_delta_source_column_name_can_be_omitted(self):
        source = _ApiDeltaSourceNoColumn()
        target = MagicMock()
        job = ingestra.Ingest(source, target)
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".ndjson") as tmp:
            path = tmp.name
        try:
            with patch.object(job, "get_temporary_file_name", return_value=path):
                out = job.extract_delta_to_local_file(
                    start_time=None,
                    end_time=None,
                )
            self.assertEqual(out, path)
            with open(path) as fp:
                rows = [json.loads(x) for x in fp.read().strip().split("\n") if x.strip()]
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["base_currency"], "EUR")
            self.assertEqual(rows[0]["quote_currency"], "USD")
        finally:
            os.unlink(path)


class CreateOrUpdateSchemaTests(unittest.TestCase):
    def test_when_target_has_no_columns_we_create_from_scratch(self):
        """Objective: Empty warehouse table should be created from the source’s column list.
        Expectation: create() runs once with source columns and passed-through options; alter() not called.
        """
        source = MagicMock()
        source.columns.return_value = [
            ingestra.Column("id", "INTEGER", ""),
        ]
        target = MagicMock()
        target.columns.return_value = []
        job = ingestra.Ingest(source, target, deletion_rule=ingestra.KeepUntouched())
        job.create_or_update_target_schema()
        target.create.assert_called_once()
        target.alter.assert_not_called()
        args, kwargs = target.create.call_args
        self.assertEqual(args[0], source.columns.return_value)
        self.assertIsInstance(args[1], ingestra.KeepUntouched)
        self.assertEqual(kwargs, {})

    def test_when_primary_keys_kwarg_it_is_forwarded_to_target_create(self):
        source = MagicMock()
        source.columns.return_value = [ingestra.Column("id", "INTEGER", "")]
        target = MagicMock()
        target.columns.return_value = []
        job = ingestra.Ingest(source, target)
        job.create_or_update_target_schema(primary_keys=["id"])
        target.create.assert_called_once()
        self.assertEqual(
            target.create.call_args[1],
            {"primary_keys": ["id"]},
        )

    def test_when_target_has_primary_keys_schema_update_needs_no_kwarg(self):
        source = MagicMock()
        source.columns.return_value = [ingestra.Column("id", "INTEGER", "")]
        pg = ingestra.PostgreSQL("t", "public", primary_keys=["id"])
        pg.dry_run = True
        job = ingestra.Ingest(source, pg, dry_run=True)
        with patch.object(pg, "columns", return_value=[]):
            with patch.object(pg, "create", wraps=pg.create) as cr:
                job.create_or_update_target_schema()
        self.assertEqual(cr.call_args[1], {})

    def test_when_target_already_has_columns_we_alter_to_match_source(self):
        """Objective: Non-empty warehouse should be brought in line with the source definition.
        Expectation: alter() runs; create() not called.
        """
        source = MagicMock()
        source.columns.return_value = []
        target = MagicMock()
        target.columns.return_value = [ingestra.Column("id", "INTEGER", "")]
        job = ingestra.Ingest(source, target)
        job.create_or_update_target_schema()
        target.alter.assert_called_once()
        target.create.assert_not_called()

    def test_create_or_update_raises_when_source_has_mark_as_deleted_column(self):
        """Objective: ``MarkAsDeleted`` owns its flag on the target; the name must not duplicate the source."""
        source = MagicMock()
        source.columns.return_value = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("is_deleted", "INTEGER", ""),
        ]
        pg = ingestra.PostgreSQL("dim", "staging")
        pg.cols = []
        job = ingestra.Ingest(
            source,
            pg,
            deletion_rule=ingestra.MarkAsDeleted("is_deleted"),
            dry_run=True,
        )
        with self.assertRaises(ValueError) as ctx:
            job.create_or_update_target_schema()
        self.assertIn("is_deleted", str(ctx.exception))


class LoadTargetDeltaFromNdjsonFileTests(unittest.TestCase):
    class _CursorCM:
        def __init__(self, cur):
            self._cur = cur

        def __enter__(self):
            return self._cur

        def __exit__(self, *args):
            return False

    def test_when_target_is_bigquery_we_raise_not_implemented(self):
        source = MagicMock()
        bq = ingestra.BigQuery("p", "d", "t")
        bq.conn = MagicMock()
        job = ingestra.Ingest(source, bq, dry_run=False)
        with self.assertRaises(NotImplementedError):
            job.load_target_delta_from_ndjson_file("/tmp/x.ndjson")

    def test_when_dry_run_we_raise_runtime_error(self):
        source = MagicMock()
        mysql = ingestra.MySQL("t")
        mysql.conn = MagicMock()
        job = ingestra.Ingest(source, mysql, dry_run=True)
        with self.assertRaises(RuntimeError):
            job.load_target_delta_from_ndjson_file("/tmp/x.ndjson")

    def test_when_target_is_mysql_we_insert_rows_from_ndjson_in_batches(self):
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".ndjson") as tmp:
            for i in range(5):
                tmp.write(json.dumps({"id": i, "name": f"n{i}"}) + "\n")
            path = tmp.name
        try:
            cur = MagicMock()
            mysql = ingestra.MySQL("items")
            mysql.conn = MagicMock()
            mysql.conn.cursor.return_value = self._CursorCM(cur)

            with patch.object(mysql, "delta_heap_columns", return_value=cols):
                n = mysql.load_delta_from_ndjson_file(path, batch_size=2)
            self.assertEqual(n, 5)
            cur.execute.assert_called_once()
            self.assertIn("TRUNCATE", cur.execute.call_args[0][0])
            self.assertEqual(cur.executemany.call_count, 3)
            mysql.conn.commit.assert_called_once()
        finally:
            os.unlink(path)

    def test_ingest_shell_delegates_to_mysql_load_delta_from_ndjson_file(self):
        cols = [
            ingestra.Column("id", "INTEGER", ""),
            ingestra.Column("name", "VARCHAR", ""),
        ]
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".ndjson") as tmp:
            tmp.write(json.dumps({"id": 1, "name": "a"}) + "\n")
            path = tmp.name
        try:
            cur = MagicMock()
            source = MagicMock()
            mysql = ingestra.MySQL("items")
            mysql.conn = MagicMock()
            mysql.conn.cursor.return_value = self._CursorCM(cur)
            job = ingestra.Ingest(source, mysql, dry_run=False)
            with patch.object(mysql, "delta_heap_columns", return_value=cols):
                n = job.load_target_delta_from_ndjson_file(path)
            self.assertEqual(n, 1)
            mysql.conn.commit.assert_called_once()
        finally:
            os.unlink(path)


class LoadTargetDeltaFromCloudStorageTests(unittest.TestCase):
    def test_when_target_has_no_cloud_loader_we_raise_not_implemented(self):
        source = MagicMock()
        mysql = ingestra.MySQL("t")
        job = ingestra.Ingest(source, mysql, dry_run=False)
        with self.assertRaises(NotImplementedError):
            job.load_target_delta_from_cloud_storage("s3://bucket/path")

    def test_when_dry_run_cloud_loader_we_raise_runtime_error(self):
        source = MagicMock()
        target = MagicMock()
        target.load_delta_from_cloud_storage = MagicMock()
        job = ingestra.Ingest(source, target, dry_run=True)
        with self.assertRaises(RuntimeError):
            job.load_target_delta_from_cloud_storage("s3://bucket/path")

    def test_when_target_is_redshift_we_delegate_copy_arguments(self):
        source = MagicMock()
        target = MagicMock()
        target.load_delta_from_cloud_storage = MagicMock(return_value=None)
        job = ingestra.Ingest(source, target, dry_run=False)
        job.load_target_delta_from_cloud_storage(
            cloud_storage_path="s3://bucket/path",
            cloud_credentials=ingestra.AwsIamRoleCredentials(
                iam_role="arn:aws:iam::123456789012:role/redshift-copy"
            ),
            region="us-east-1",
            truncate=False,
        )
        target.load_delta_from_cloud_storage.assert_called_once_with(
            cloud_storage_path="s3://bucket/path",
            cloud_credentials=ingestra.AwsIamRoleCredentials(
                iam_role="arn:aws:iam::123456789012:role/redshift-copy"
            ),
            region="us-east-1",
            truncate=False,
        )


class PrepareTargetDeltaFromCloudStorageTests(unittest.TestCase):
    def test_when_target_has_no_preparer_we_raise_not_implemented(self):
        source = MagicMock()
        mysql = ingestra.MySQL("t")
        job = ingestra.Ingest(source, mysql, dry_run=False)
        spec = ingestra.CloudStorageDeltaSpec(uris=["s3://bucket/path"])
        with self.assertRaises(NotImplementedError):
            job.prepare_target_delta_from_cloud_storage(spec)

    def test_when_target_supports_preparer_we_delegate_with_source_columns(self):
        source = MagicMock()
        source.columns.return_value = [ingestra.Column("id", "INTEGER", "")]
        target = MagicMock()
        target.prepare_target_delta_from_cloud_storage = MagicMock(return_value=None)
        job = ingestra.Ingest(source, target, dry_run=False)
        spec = ingestra.CloudStorageDeltaSpec(
            uris=["s3://bucket/path"],
            credentials=ingestra.AwsIamRoleCredentials(
                iam_role="arn:aws:iam::123456789012:role/redshift-copy"
            ),
        )
        job.prepare_target_delta_from_cloud_storage(spec)
        target.prepare_target_delta_from_cloud_storage.assert_called_once_with(
            source.columns.return_value, spec
        )


class PropagateFlagsTests(unittest.TestCase):
    def test_when_job_is_dry_run_or_verbose_both_sides_see_the_same_flags(self):
        """Objective: Operators set preview / loud mode once on the job object.
        Expectation: Source and target data sources both receive dry_run and verbose.
        """
        source = MagicMock()
        target = MagicMock()
        ingestra.Ingest(source, target, dry_run=True, verbose=True)
        self.assertTrue(source.dry_run)
        self.assertTrue(source.verbose)
        self.assertTrue(target.dry_run)
        self.assertTrue(target.verbose)


class ExtractToCloudStorageDelegationTests(unittest.TestCase):
    def test_when_source_has_no_extract_to_cloud_storage_we_raise_not_implemented(self):
        source = _RowsSource([])
        target = MagicMock()
        job = ingestra.Ingest(source, target)
        with self.assertRaises(NotImplementedError):
            job.extract_to_cloud_storage("s3://bucket/path")

    def test_when_source_supports_extract_to_cloud_storage_we_delegate(self):
        source = MagicMock()
        source.extract_to_cloud_storage = MagicMock(return_value="s3://bucket/path")
        target = MagicMock()
        job = ingestra.Ingest(source, target)
        out = job.extract_to_cloud_storage(
            cloud_storage_path="s3://bucket/path",
            cloud_credentials=ingestra.AwsIamRoleCredentials(
                iam_role="arn:aws:iam::123456789012:role/redshift-unload"
            ),
        )
        self.assertEqual(out, "s3://bucket/path")
        source.extract_to_cloud_storage.assert_called_once_with(
            cloud_storage_path="s3://bucket/path",
            cloud_credentials=ingestra.AwsIamRoleCredentials(
                iam_role="arn:aws:iam::123456789012:role/redshift-unload"
            ),
            region=None,
        )

if __name__ == "__main__":
    unittest.main()
