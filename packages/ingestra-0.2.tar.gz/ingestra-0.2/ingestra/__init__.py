"""SQL-to-SQL (and SQL-to-BigQuery) loading: extract, align schema, merge.

Model a *source* and *target* :class:`DataSource`—PostgreSQL, MySQL, BigQuery,
or Redshift. :class:`Ingest` wires extract (including NDJSON for local file/GCS
pipelines and Redshift S3 ``UNLOAD``), optional :class:`LifecycleRule`, and
dialect-specific upsert or overwrite on the target.

**Type normalization**

:class:`ColumnTypes` maps ``information_schema`` spellings to a shared logical
set (``VARCHAR``, ``INTEGER``, ``TIMESTAMP``, …) so source/target comparison
and generated DDL stay aligned.

**Staging**

- **BigQuery:** ``*_delta`` is an external table over newline-delimited JSON in
  GCS; ``upsert`` / ``overwrite`` use ``MERGE``.
- **PostgreSQL / MySQL:** ``*_delta`` is a heap table you populate (e.g.
  :meth:`PostgreSQL.load_delta_from_ndjson_file` / :meth:`MySQL.load_delta_from_ndjson_file`,
  ``COPY``, ``LOAD DATA``, ETL); ``upsert`` / ``overwrite`` use
  ``INSERT … ON CONFLICT`` or ``ON DUPLICATE KEY UPDATE``. Rows on the target
  but not in ``*_delta`` are handled by :class:`Delete` or :class:`MarkAsDeleted`
  on ``overwrite``.

**PostgreSQL dates**

:class:`PostgreSQL` registers psycopg2 casters so invalid server dates become
``None`` instead of failing the fetch loop.
"""

import copy
import json
import decimal
import jinja2
import datetime
from dataclasses import dataclass


class LifecycleRule(object):
    """Base class for how target rows are treated when absent from a delta load.

    Subclasses are interpreted by :class:`BigQuery` when building ``MERGE``
    statements (see :meth:`BigQuery.overwrite`). :class:`KeepUntouched` and the
    empty :class:`Delete` / :class:`LifecycleRule` markers exist for typing and
    future extension.
    """

    pass


class ColumnTypes(object):
    """Maps canonical logical types to dialect-specific ``information_schema`` names.

    Each attribute (``VARCHAR``, ``INTEGER``, …) is a dict keyed by engine label
    (``MySQL``, ``PostgreSQL``, ``BigQuery``) with a list of aliases that
    :meth:`locate` matches. The first alias per engine is used by
    :meth:`DataSource.adjust_data_type` for DDL.
    """

    VARCHAR = {
        "MySQL": ["VARCHAR", "BINARY", "VARBINARY", "ENUM", "CHAR", "SET"],
        "PostgreSQL": ["CHARACTER VARYING", "CHAR", "CHARACTER", "UUID", "XID", "USER-DEFINED", "NAME", "BYTEA"],
        "BigQuery": ["STRING"],
    }
    TEXT = {
        "MySQL": ["LONGTEXT", "TEXT", "MEDIUMTEXT", "TINYTEXT", "BLOB"],
        "PostgreSQL": ["TEXT", "JSON", "JSONB", "TSVECTOR", "ARRAY"],
        "BigQuery": ["STRING", "JSON"],
    }
    BOOLEAN = {
        "MySQL": ["TINYINT", "BIT"],
        "PostgreSQL": ["BOOLEAN"],
        "BigQuery": ["BOOL"],
    }
    INTEGER = {
        "MySQL": ["BIGINT", "MEDIUMINT", "INT", "SMALLINT"],
        "PostgreSQL": ["BIGINT", "INTEGER", "SMALLINT"],
        "BigQuery": ["INT64", ],
    }
    DECIMAL = {
        "MySQL": ["DECIMAL"],
        "PostgreSQL": ["NUMERIC"],
        "BigQuery": ["BIGNUMERIC", "NUMERIC"],
    }
    FLOAT = {
        "MySQL": ["DOUBLE", "FLOAT"],
        "PostgreSQL": ["DOUBLE PRECISION", "REAL"],
        "BigQuery": ["FLOAT64"],
    }
    DATE = {
        "MySQL": ["DATE"],
        "PostgreSQL": ["DATE"],
        "BigQuery": ["DATE"],
    }
    TIMESTAMP = {
        "MySQL": ["TIMESTAMP"],
        "PostgreSQL": ["TIMESTAMP WITH TIME ZONE"],
        "BigQuery": ["TIMESTAMP"],
    }
    DATETIME = {
        "MySQL": ["DATETIME"],
        "PostgreSQL": ["TIMESTAMP WITHOUT TIME ZONE"],
        "BigQuery": ["DATETIME"],
    }

    SUPPORTED_TYPES = [
        'VARCHAR',
        'TEXT',
        'BOOLEAN',
        'INTEGER',
        'DECIMAL',
        'FLOAT',
        'DATE',
        'TIMESTAMP',
        'DATETIME',
    ]

    @classmethod
    def locate(cls, dialect_name: str, data_type: str) -> str:
        """Map a dialect-specific type name (usually UPPER from metadata) to a canonical name.

        Args:
            dialect_name: Engine key matching class attributes, e.g. ``\"PostgreSQL\"``,
                ``\"MySQL\"``, ``\"BigQuery\"``.
            data_type: Raw type string from ``information_schema`` (case as returned
                by the database; callers often normalize to upper case).

        Returns:
            One of :attr:`SUPPORTED_TYPES`, or ``None`` if no alias matches.
        """
        for supported_type in cls.SUPPORTED_TYPES:
            # Each canonical type lists every vendor spelling we treat as equivalent.
            data_type_aliases = getattr(
                cls, supported_type
            ).get(dialect_name, [])
            if data_type in data_type_aliases:
                return supported_type
        # No alias matched — caller may get None and should handle unknown types.


class Column(object):
    """Logical column metadata shared by sources and targets.

    ``data_type`` should be a canonical name from :class:`ColumnTypes` after
    :meth:`ColumnTypes.locate` (or the equivalent for the engine). Optional
    fields mirror ``information_schema`` and are used when generating DDL.
    """

    def __init__(self, name: str, data_type: str, description: str, character_maximum_length: int = None,  numeric_precision: int = None, numeric_scale: int = None) -> None:
        """
        Args:
            name: Column identifier.
            data_type: Canonical type from :class:`ColumnTypes`.
            description: Human-readable meaning (often unused in DDL here).
            character_maximum_length: For variable-length string types, if known.
            numeric_precision: For decimal/numeric types, if known.
            numeric_scale: For decimal/numeric types, if known.
        """
        self.name = name
        self.data_type = data_type
        self.description = description
        self.character_maximum_length = character_maximum_length
        self.numeric_precision = numeric_precision
        self.numeric_scale = numeric_scale
        self.flag = None

    def __repr__(self) -> str:
        """Return a compact debug representation with the column name only."""
        return f"<{self.name}>"


class Delete(LifecycleRule):
    """Lifecycle rule: rows present in the target but not in the delta are removed.

    Used by :meth:`BigQuery.overwrite` to emit ``DELETE`` in the ``MERGE`` when
    ``WHEN NOT MATCHED BY SOURCE`` applies.
    """

    pass


class MarkAsDeleted(LifecycleRule):
    """Lifecycle rule: soft-delete via a flag column instead of physical delete.

    The flag column is added to the target schema if missing. On merge,
    :meth:`BigQuery.overwrite` sets this column to ``value`` for target-only
    rows, and uses ``default_value`` when inserting or updating from the delta
    for that column.
    """

    def __init__(self, column_name: str, value: int = 1, default_value: int = 0, data_type='INTEGER') -> None:
        """Configure soft-delete behavior for overwrite merges.

        Args:
            column_name: Target flag column updated when source row is absent.
            value: Value written for rows considered deleted.
            default_value: Value used for non-deleted/inserted rows.
            data_type: Canonical type name used if the flag column is created.
        """
        super().__init__()
        self.column_name = column_name
        self.value = value
        self.default_value = default_value
        self.data_type = data_type

    def get_column(self):
        """:class:`Column` definition for the soft-delete flag (for DDL helpers)."""
        return Column(
            name=self.column_name,
            data_type=self.data_type,
            description="",
            character_maximum_length=None,
            numeric_precision=None,
            numeric_scale=None,
        )


class KeepUntouched(LifecycleRule):
    """Placeholder rule: target-only rows are not deleted or soft-deleted.

    ``MERGE`` branches that handle ``WHEN NOT MATCHED BY SOURCE`` are omitted
    when the deletion rule is not :class:`Delete` or :class:`MarkAsDeleted`.
    """

    pass


@dataclass(frozen=True)
class CloudCredentials:
    """Typed base for cloud provider credentials passed to cloud-storage APIs."""


@dataclass(frozen=True)
class AwsIamRoleCredentials(CloudCredentials):
    """AWS auth via IAM role ARN (typical Redshift COPY/UNLOAD pattern)."""

    iam_role: str


@dataclass(frozen=True)
class AwsAccessKeyCredentials(CloudCredentials):
    """AWS auth via access key / secret key (+ optional session token)."""

    access_key_id: str
    secret_access_key: str
    session_token: str = None


@dataclass(frozen=True)
class GcpServiceAccountCredentials(CloudCredentials):
    """GCP auth handle for future cloud-storage integrations (e.g. GCS loaders)."""

    service_account_json: str = None


@dataclass(frozen=True)
class CloudStorageDeltaSpec:
    """Target delta staging descriptor for cloud object storage inputs."""

    uris: list
    credentials: CloudCredentials = None
    region: str = None
    truncate: bool = True
    file_format: str = "NEWLINE_DELIMITED_JSON"


class DataSource(object):
    """Abstract database handle: metadata, extract, and optional DDL/merge hooks.

    Concrete subclasses implement :meth:`connection` (or receive a client via
    :meth:`inherit_connection`), :meth:`columns`, and extraction.
    :class:`BigQuery`, :class:`PostgreSQL`, and :class:`MySQL` also implement
    :meth:`create`, :meth:`alter`, :meth:`upsert`, and :meth:`overwrite` for
    target-side loads (staging table + merge semantics differ by engine).

    Instance attributes:
        conn: Driver-specific connection or client (``None`` until connected).
        cols: Cached list of :class:`Column` from :meth:`columns`, or ``None``.
        _delta_cols: Cached columns for ``{table}_delta`` (PostgreSQL / MySQL), or ``None``.
        dry_run: If True, implementations that support it print SQL instead of executing.
        verbose: If True, print generated SQL for debugging.
    """

    def __init__(self) -> None:
        """Initialize connection/cache fields shared by all datasource implementations."""
        self.conn = None
        self.cols = None
        self._delta_cols = None
        self.dry_run = False
        self.verbose = False
        #: Merge / upsert key columns when set on a **target** (``None`` = caller must pass per call).
        self.primary_keys = None

    def _merge_primary_keys_for_ddl(self, kwargs) -> list:
        """DDL (PG/MySQL ``PRIMARY KEY``): instance ``primary_keys`` override ``kwargs``."""
        if self.primary_keys:
            return list(self.primary_keys)
        return list((kwargs or {}).get("primary_keys") or [])

    def _effective_primary_keys(self, primary_keys_passed) -> list:
        """Resolve merge keys: explicit argument wins, else :attr:`primary_keys` on this target."""
        if primary_keys_passed is not None:
            return list(primary_keys_passed)
        if self.primary_keys:
            return list(self.primary_keys)
        raise ValueError(
            f"{self.__class__.__name__}: pass primary_keys to upsert/overwrite, or set "
            "primary_keys= on the target (e.g. PostgreSQL('t', primary_keys=['id']))."
        )

    def inherit_connection(self, connection) -> None:
        """Use an existing connection/client instead of calling :meth:`connection`."""
        self.conn = connection

    def connection(self) -> None:
        """Open ``self.conn`` using subclass-specific parameters.

        Subclasses override with real credentials. The base implementation
        always raises.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__}.connect() is not implemented")

    def get_column(self, column_name) -> Column:
        """Return the :class:`Column` named ``column_name``, or ``None`` if missing."""
        for column in self.columns():
            if column.name == column_name:
                return column

    def columns(self) -> list:
        """Return table columns as :class:`Column` instances (may be cached in ``self.cols``)."""
        raise NotImplementedError(
            f"{self.__class__.__name__}.columns() is not implemented")

    def column_names(self) -> list:
        """Ordered column names as returned by :meth:`columns`."""
        return [column.name for column in self.columns()]

    def extract_row(self, row) -> dict:
        """Normalize a driver row mapping for JSON-friendly newline-delimited export.

        - ``dict`` / ``list`` values become JSON strings.
        - :class:`~datetime.datetime` uses ``%Y-%m-%d %H:%M:%S.%f``.
        - :class:`~datetime.date` uses ISO format.
        - :class:`~decimal.Decimal` becomes ``float``.
        - MySQL-style bit bytes ``b'\\x01'`` / ``b'\\x00'`` become ``1`` / ``0``.
        - Other ``bytes`` are decoded as UTF-8.

        Args:
            row: Mapping from column name to cell value (e.g. ``dict`` from DictCursor).

        Returns:
            New dict with serialized values suitable for :func:`json.dumps`.
        """
        def to_value_format(value):
            # Nested structures → JSON text so one NDJSON line stays self-contained.
            if isinstance(value, dict):
                return json.dumps(value, default=str)
            if isinstance(value, list):
                return json.dumps(value, default=str)
            if isinstance(value, datetime.datetime):
                return value.strftime("%Y-%m-%d %H:%M:%S.%f")
            if isinstance(value, decimal.Decimal):
                return float(value)
            # MySQL BIT(1) often arrives as single-byte blobs in drivers.
            if value == b'\x01':
                return 1
            if value == b'\x00':
                return 0
            if isinstance(value, bytes):
                return value.decode('utf-8')
            if isinstance(value, datetime.date):
                return value.isoformat()
            return value

        # Preserve column names from the driver dict; only cell values are coerced.
        return {k: to_value_format(v) for k, v in row.items()}

    def deprecated_columns(self, source_columns: list) -> set:
        """Column names present on *this* table but absent from ``source_columns``.

        Used when aligning target schema to a source definition (e.g. drop
        columns in :meth:`BigQuery.alter`).
        """
        source_column_names = [
            source_column.name 
            for source_column in source_columns
        ]
        column_names = self.column_names()
        return set(column_names) - set(source_column_names)

    def missing_columns(self, source_columns: list) -> set:
        """Column names present in ``source_columns`` but not on *this* table."""
        source_column_names = [
            source_column.name
            for source_column in source_columns
        ]
        column_names = self.column_names()
        return set(source_column_names) - set(column_names)

    def changed_type_columns(self, source_columns: list) -> set:
        """Names of columns that exist on both sides but with different ``data_type``."""
        source_column_names = [
            source_column.name for source_column in source_columns]
        source_column_by_name = {
            source_column.name: source_column for source_column in source_columns}
        column_names = self.column_names()
        column_by_name = {column.name: column for column in self.columns()}
        # Only compare types where the column exists on both sides.
        shared_column_names = set(source_column_names) & set(column_names)
        return {
            column_name
            for column_name in shared_column_names
            if column_by_name[column_name].data_type != source_column_by_name[column_name].data_type
        }

    def exact_match_columns(self, source_columns: list) -> set:
        """Column names present on *this* table and in ``source_columns`` with the same ``data_type``.

        For shared names, each column is either an exact type match (in this set)
        or a type mismatch (in :meth:`changed_type_columns`); the two sets are
        disjoint.
        """
        source_column_by_name = {
            source_column.name: source_column for source_column in source_columns}
        column_by_name = {column.name: column for column in self.columns()}
        shared = set(source_column_by_name) & set(column_by_name)
        return {
            name
            for name in shared
            if column_by_name[name].data_type == source_column_by_name[name].data_type
        }

    def schema_diff_summary(self, source_columns: list) -> dict:
        """Single view of name/type alignment between *this* table and ``source_columns``.

        Returns:
            dict with keys ``exact_match``, ``missing``, ``deprecated``,
            ``type_changed`` (each a set of column names). ``missing`` is
            source-only; ``deprecated`` is target-only; ``type_changed`` is
            same name, different canonical ``data_type``; ``exact_match`` is
            same name and same ``data_type``.
        """
        return {
            "exact_match": self.exact_match_columns(source_columns),
            "missing": self.missing_columns(source_columns),
            "deprecated": self.deprecated_columns(source_columns),
            "type_changed": self.changed_type_columns(source_columns),
        }

    def adjust_data_type(self, data_type) -> str:
        """Return this engine's concrete SQL type for a canonical ``data_type`` name.

        Uses the first alias in :class:`ColumnTypes` for the subclass name
        (e.g. ``BigQuery`` → ``STRING`` for ``VARCHAR``).
        """
        # [0] is the preferred spelling for DDL in that engine (see ColumnTypes dicts).
        return getattr(ColumnTypes, data_type).get(self.__class__.__name__)[0]

    def alter(self, source_columns: list, deletion_rule: LifecycleRule) -> None:
        """Bring an existing table in line with ``source_columns`` (targets that support DDL)."""
        raise NotImplementedError(
            f"{self.__class__.__name__}.alter(source_columns, deletion_rule) is not implemented")

    def create(self, source_columns: list, deletion_rule: LifecycleRule) -> None:
        """Create the target table (and staging external table) from ``source_columns``."""
        raise NotImplementedError(
            f"{self.__class__.__name__}.create(source_columns, deletion_rule) is not implemented")

    def upsert(self, primary_keys: list = None) -> None:
        """``MERGE`` delta into target updating all columns; no target-only deletes."""
        raise NotImplementedError(
            f"{self.__class__.__name__}.upsert(primary_keys) is not implemented")

    def overwrite(self, primary_keys: list = None, deletion_rule: LifecycleRule = None) -> None:
        """``MERGE`` delta into target, applying ``deletion_rule`` for unmatched target rows."""
        raise NotImplementedError(
            f"{self.__class__.__name__}.overwrite(primary_keys, deletion_rule) is not implemented")

    def extract(self) -> list:
        """Yield full-table rows as dicts (via :meth:`extract_row`)."""
        raise NotImplementedError(
            f"{self.__class__.__name__}.extract() is not implemented")

    def extract_delta(self, column_name: str, start_time: datetime.datetime, end_time: datetime.datetime = None, sql_from: str = None) -> list:
        """Yield rows where ``column_name`` is in ``[start_time, end_time)``.

        If ``sql_from`` is set, it replaces the physical table in the ``FROM``
        clause (subquery). Otherwise ``column_name`` must be a date/time
        canonical type unless the subclass documents otherwise.

        Args:
            column_name: Optional column used for the range filter and ``ORDER BY``.
            start_time: Inclusive lower bound (formatted into SQL by the subclass).
            end_time: Optional exclusive upper bound.
            sql_from: Optional raw SQL subquery body for the source relation.

        Yields:
            Row dicts in the same shape as :meth:`extract`.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__}.extract_delta(column_name, start_time, end_time, sql_from) is not implemented")

    def prepare_target_delta_from_cloud_storage(
        self, source_columns: list, delta_spec: CloudStorageDeltaSpec
    ) -> None:
        """Prepare ``*_delta`` from cloud object storage for this target."""
        raise NotImplementedError(
            f"{self.__class__.__name__}.prepare_target_delta_from_cloud_storage(source_columns, delta_spec) is not implemented")


def coerce_ndjson_value_for_postgres(value, column: Column):
    """Adapt JSON-decoded cells for :meth:`PostgreSQL.load_delta_from_ndjson_file` parameters.

    MySQL (and :meth:`DataSource.extract_row`) often emit ``0``/``1`` integers for
    boolean-like columns; PostgreSQL ``BOOLEAN`` rejects integer parameters.
    """
    if value is None:
        return None
    dt = column.data_type
    if dt is None:
        return value
    if dt == "BOOLEAN":
        if isinstance(value, bool):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return value != 0
        if isinstance(value, float):
            return bool(value)
        if isinstance(value, str):
            s = value.strip().lower()
            if s in ("true", "t", "yes", "y", "on", "1"):
                return True
            if s in ("false", "f", "no", "n", "off", "0", ""):
                return False
        return value
    if dt == "INTEGER":
        if isinstance(value, float) and value.is_integer():
            return int(value)
        return value
    return value


def _validate_optional_primary_keys(primary_keys, column_names: set) -> None:
    """Ensure ``primary_keys`` used for DDL / merge are real column names."""
    if not primary_keys:
        return
    missing = [pk for pk in primary_keys if pk not in column_names]
    if missing:
        raise ValueError(
            "primary_keys %s are not among table columns %s"
            % (missing, sorted(column_names))
        )


def _validate_mark_as_deleted_source_names(
    source_columns: list, deletion_rule: LifecycleRule
) -> None:
    """Ensure :class:`MarkAsDeleted` flag name is not already a source column (target-owned)."""
    if not isinstance(deletion_rule, MarkAsDeleted):
        return
    source_names = {c.name for c in source_columns}
    if deletion_rule.column_name in source_names:
        raise ValueError(
            "MarkAsDeleted column %r must not appear in source_columns "
            "(the target owns that column). Rename the source field or pick "
            "a different MarkAsDeleted column_name."
            % (deletion_rule.column_name,)
        )


class PostgreSQL(DataSource):
    """PostgreSQL table via psycopg2 — usable as a source (extract) or target (DDL + upsert).

    As a **target**, expects a staging table ``"schema"."{table_name}_delta"`` with the
    same column layout as your load. Load data into ``*_delta`` yourself, then call
    :meth:`upsert` or :meth:`overwrite`. Set ``primary_keys=`` on the instance (constructor)
    so DDL can emit a matching ``PRIMARY KEY`` and merges default to those columns.

    Uses ``information_schema.columns`` for metadata and builds ``SELECT`` SQL
    with Jinja2. Date/timestamp OIDs are registered with safe casters after
    connect (see :meth:`_register_safe_date_casters`).
    """

    def __init__(
        self,
        table_name: str,
        schema_name: str = 'public',
        ignore_columns: list = None,
        primary_keys: list = None,
    ):
        """
        Args:
            table_name: Physical table name in PostgreSQL.
            schema_name: Schema containing the table (default ``public``).
            ignore_columns: Column names to omit from metadata and ``SELECT`` lists.
            primary_keys: As a **target**, merge key columns; used for ``PRIMARY KEY`` DDL
                and as the default for :meth:`upsert` / :meth:`overwrite` when called without
                ``primary_keys``.
        """
        super().__init__()
        self.table_name = table_name
        self.schema_name = schema_name
        self.ignore_columns = ignore_columns or []
        if primary_keys:
            self.primary_keys = list(primary_keys)

    def _register_safe_date_casters(self):
        """Register per-connection DATE/TIMESTAMP casters that tolerate bad server values.

        Years beyond :data:`datetime.MAXYEAR` or parse errors log a short message
        and return ``None`` instead of raising in the fetch loop.
        """
        import psycopg2
        import psycopg2.extensions

        max_date_year = datetime.MAXYEAR

        def _parse_year(value):
            """Extract the year from a date/timestamp string without full parsing."""
            try:
                return int(value[:4])
            except (ValueError, IndexError):
                return None

        def safe_cast_date(value, cursor):
            if value is None:
                return None
            year = _parse_year(value)
            if year is None or year > max_date_year:
                print(f"Safe date caster: invalid date value encountered: {value} (table: {self.schema_name}.{self.table_name})")
                return None
            try:
                return psycopg2.extensions.PYDATE(value, cursor)
            except (ValueError, OverflowError):
                print(f"Safe date caster: invalid date value encountered: {value} (table: {self.schema_name}.{self.table_name})")
                return None

        def safe_cast_timestamp(value, cursor):
            if value is None:
                return None
            year = _parse_year(value)
            if year is None or year > max_date_year:
                print(f"Safe date caster: invalid timestamp value encountered: {value} (table: {self.schema_name}.{self.table_name})")
                return None
            try:
                return psycopg2.extensions.PYDATETIME(value, cursor)
            except (ValueError, OverflowError):
                print(f"Safe date caster: invalid timestamp value encountered: {value} (table: {self.schema_name}.{self.table_name})")
                return None

        # OIDs: 1082=DATE, 1114=TIMESTAMP, 1184=TIMESTAMPTZ
        DATE_OID = 1082
        TIMESTAMP_OID = 1114
        TIMESTAMPTZ_OID = 1184
        safe_date = psycopg2.extensions.new_type((DATE_OID,), "SAFE_DATE", safe_cast_date)
        safe_ts = psycopg2.extensions.new_type((TIMESTAMP_OID, TIMESTAMPTZ_OID), "SAFE_TIMESTAMP", safe_cast_timestamp)
        # Registration is per-connection; both inherit_connection and connection() call this.
        psycopg2.extensions.register_type(safe_date, self.conn)
        psycopg2.extensions.register_type(safe_ts, self.conn)

    def inherit_connection(self, connection) -> None:
        """Attach ``connection`` and register safe date/timestamp types on it."""
        self.conn = connection
        self._register_safe_date_casters()

    def connection(self, host: str, user: str, password: str, database: str, port: int = 5432):
        """Connect with ``DictCursor`` and register safe date casters."""
        import psycopg2
        import psycopg2.extras

        if self.conn is None:
            self.conn = psycopg2.connect(
                host=host,
                user=user,
                password=password,
                dbname=database,
                port=port,
                cursor_factory=psycopg2.extras.DictCursor,
            )
            self._register_safe_date_casters()

    def columns(self, refresh: bool = False) -> list:
        """Load column metadata from ``information_schema`` (cached unless ``refresh``)."""
        # Avoid hitting information_schema on every extract when schema is stable.
        if self.cols is not None and refresh is False:
            return self.cols

        with self.conn.cursor() as cursor:
            sql = jinja2.Template("""
                SELECT
                    "column_name",
                    UPPER("data_type") AS "data_type",
                    "character_maximum_length",
                    "numeric_precision",
                    "numeric_scale"
                FROM
                    "information_schema"."columns"
                WHERE
                    "table_name" = '{{ table_name }}'
                    AND "table_schema" = '{{ schema_name }}'
                ORDER BY
                    "ordinal_position" ASC;
            """).render(table_name=self.table_name, schema_name=self.schema_name)
            cursor.execute(sql)
            columns = []
            for column in cursor.fetchall():
                if column["column_name"] not in self.ignore_columns:
                    # locate() folds e.g. TIMESTAMPTZ → TIMESTAMP for cross-db comparisons.
                    columns.append(Column(
                        name=column["column_name"],
                        data_type=ColumnTypes.locate(
                            "PostgreSQL", column["data_type"]),
                        description="",
                        character_maximum_length=column["character_maximum_length"],
                        numeric_precision=column["numeric_precision"],
                        numeric_scale=column["numeric_scale"],
                    ))
            self.cols = columns
            return columns

    def delta_heap_columns(self, refresh: bool = False) -> list:
        """Column metadata for ``{schema}.{table}_delta`` (staging), not the main table.

        The heap table follows the **source** column list; columns such as a
        soft-delete flag added only on the main table by :class:`MarkAsDeleted`
        are absent here. Used by :meth:`load_delta_from_ndjson_file`.
        """
        if self._delta_cols is not None and refresh is False:
            return self._delta_cols

        delta_table = f"{self.table_name}_delta"
        with self.conn.cursor() as cursor:
            sql = jinja2.Template("""
                SELECT
                    "column_name",
                    UPPER("data_type") AS "data_type",
                    "character_maximum_length",
                    "numeric_precision",
                    "numeric_scale"
                FROM
                    "information_schema"."columns"
                WHERE
                    "table_name" = '{{ table_name }}'
                    AND "table_schema" = '{{ schema_name }}'
                ORDER BY
                    "ordinal_position" ASC;
            """).render(table_name=delta_table, schema_name=self.schema_name)
            cursor.execute(sql)
            columns = []
            for column in cursor.fetchall():
                if column["column_name"] not in self.ignore_columns:
                    columns.append(Column(
                        name=column["column_name"],
                        data_type=ColumnTypes.locate(
                            "PostgreSQL", column["data_type"]),
                        description="",
                        character_maximum_length=column["character_maximum_length"],
                        numeric_precision=column["numeric_precision"],
                        numeric_scale=column["numeric_scale"],
                    ))
            self._delta_cols = columns
            return columns

    def extract(self) -> list:
        """Yield all rows from ``schema_name.table_name`` as normalized dicts."""
        columns = self.columns()
        column_names = [column.name for column in columns]

        with self.conn.cursor() as cursor:
            sql = jinja2.Template("""
                SELECT
                    {%- for column in columns %}
                    "{{ column.name }}"{% if not loop.last %},{% endif %}
                    {%- endfor %}
                FROM
                    "{{ schema_name }}"."{{ table_name }}"
            """).render(schema_name=self.schema_name, table_name=self.table_name, columns=columns)
            if self.verbose:
                print(sql)
            cursor.execute(sql)
            for record in cursor.fetchall():
                # DictCursor rows are sequence-like; names follow the SELECT column order.
                yield self.extract_row(dict(zip(column_names, record)))

    def extract_delta(self, column_name: str, start_time: datetime.datetime, end_time: datetime.datetime = None, sql_from: str = None) -> list:
        """Incremental extract ordered by ``column_name`` descending.

        Raises:
            RuntimeError: If ``sql_from`` is omitted and ``column_name`` is not a
                date/time canonical type.
        """
        if column_name is None:
            raise ValueError(
                "PostgreSQL.extract_delta requires column_name (e.g. 'updated_at')."
            )
        columns = self.columns()
        column_names = [column.name for column in columns]
        delta_column = self.get_column(column_name)
        # Without sql_from we splice string literals into SQL; restrict to temporal types that support that.
        if sql_from is None and delta_column.data_type not in ("DATE", "DATETIME", "TIMESTAMP"):
            raise RuntimeError(
                f"Not supported delta extraction via non date/timestamp column, found {delta_column.data_type}")

        with self.conn.cursor() as cursor:
            sql = jinja2.Template("""
                SELECT
                    {%- for column in columns %}
                    "{{ column.name }}"{% if not loop.last %},{% endif %}
                    {%- endfor %}
                FROM
                    {%- if sql_from %}
                    (
                        {{ sql_from }}
                    ) AS vw
                    {%- else %}
                    "{{ schema_name }}"."{{ table_name }}"
                    {%- endif %}
                WHERE
                    "{{ column_name }}" >= '{{ start_time }}'
                    {%- if end_time %}
                    AND "{{ column_name }}" < '{{ end_time }}'
                    {%- endif %}
                ORDER BY
                    "{{ column_name }}" DESC
            """).render(schema_name=self.schema_name, table_name=self.table_name, columns=columns, column_name=column_name, start_time=start_time, end_time=end_time, sql_from=sql_from)
            # DESC: newest rows first — handy when scanning a large window in chunks from the top.
            if self.verbose:
                print(sql)
            cursor.execute(sql)
            for record in cursor.fetchall():
                yield self.extract_row(dict(zip(column_names, record)))

    def _pg_run_sqls(self, sqls: list) -> None:
        """Execute PostgreSQL SQL statements with dry-run/verbose behavior and cache reset."""
        for sql in sqls:
            if self.dry_run:
                print(sql)
                continue
            if self.verbose:
                print(sql)
            with self.conn.cursor() as cursor:
                cursor.execute(sql)
            self.conn.commit()
        if not self.dry_run:
            self.cols = None
            self._delta_cols = None

    def create_delta_heap_table(self, source_columns: list) -> str:
        """Return SQL for the heap staging table ``{schema}.{table}_delta``."""
        return jinja2.Template("""
            CREATE TABLE "{{ schema_name }}"."{{ table_name }}_delta" (
                {%- for column in columns %}
                "{{ column.name }}" {{ adjust_data_type(column.data_type) }}{% if not loop.last %},{% endif %}
                {%- endfor %}
            );
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=source_columns,
            adjust_data_type=self.adjust_data_type,
        )

    def drop_delta_heap_table(self) -> str:
        """Return SQL to drop the heap ``{table_name}_delta`` staging table if it exists."""
        return jinja2.Template("""
            DROP TABLE IF EXISTS "{{ schema_name }}"."{{ table_name }}_delta";
        """).render(schema_name=self.schema_name, table_name=self.table_name)

    def create(self, source_columns: list, deletion_rule: LifecycleRule, **kwargs) -> None:
        """Create ``schema.table`` and ``schema.table_delta`` heap tables.

        Uses :attr:`primary_keys` on this target (constructor) for a ``PRIMARY KEY`` on
        the **main** table so :meth:`upsert` / :meth:`overwrite` ``ON CONFLICT`` is valid.
        Staging ``*_delta`` stays a heap. For backward compatibility, ``kwargs['primary_keys']``
        is used only when the instance has no :attr:`primary_keys`.

        Other ``**kwargs`` are ignored so callers can share
        :meth:`Ingest.create_or_update_target_schema` with BigQuery targets.
        """
        _validate_mark_as_deleted_source_names(source_columns, deletion_rule)
        sqls = []
        sqls.append(self.drop_delta_heap_table())
        sqls.append(self.create_delta_heap_table(source_columns))
        final_source_columns = copy.copy(source_columns)
        if isinstance(deletion_rule, MarkAsDeleted):
            final_source_columns.append(deletion_rule.get_column())
        primary_keys = self._merge_primary_keys_for_ddl(kwargs)
        _validate_optional_primary_keys(
            primary_keys, {c.name for c in final_source_columns})
        sqls.append(jinja2.Template("""
            CREATE TABLE "{{ schema_name }}"."{{ table_name }}" (
                {%- for column in columns %}
                "{{ column.name }}" {{ adjust_data_type(column.data_type) }}{% if not loop.last or primary_keys %},{% endif %}
                {%- endfor %}
                {%- if primary_keys %}
                PRIMARY KEY ({% for pk in primary_keys %}"{{ pk }}"{% if not loop.last %}, {% endif %}{% endfor %})
                {%- endif %}
            );
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=final_source_columns,
            adjust_data_type=self.adjust_data_type,
            primary_keys=primary_keys,
        ))
        self._pg_run_sqls(sqls)

    def alter(self, source_columns: list, deletion_rule: LifecycleRule, **kwargs) -> None:
        """Rebuild ``*_delta``, then ``DROP COLUMN`` / ``ADD COLUMN`` on the main table.

        Uses :attr:`primary_keys` (or legacy ``kwargs['primary_keys']``) so a ``DO`` block
        can add a primary key when the main table still has none.
        """
        _validate_mark_as_deleted_source_names(source_columns, deletion_rule)
        sqls = []
        sqls.append(self.drop_delta_heap_table())
        sqls.append(self.create_delta_heap_table(source_columns))
        primary_keys = self._merge_primary_keys_for_ddl(kwargs)
        allowed_names = {c.name for c in source_columns}
        if isinstance(deletion_rule, MarkAsDeleted):
            allowed_names.add(deletion_rule.column_name)
        _validate_optional_primary_keys(primary_keys, allowed_names)
        deprecated_columns = [
            column for column in self.columns()
            if column.name in self.deprecated_columns(source_columns)
        ]
        if isinstance(deletion_rule, MarkAsDeleted):
            deprecated_columns = [
                c for c in deprecated_columns
                if c.name != deletion_rule.column_name
            ]
        for deprecated_column in deprecated_columns:
            sqls.append(jinja2.Template("""
                ALTER TABLE "{{ schema_name }}"."{{ table_name }}"
                DROP COLUMN IF EXISTS "{{ column.name }}";
            """).render(
                column=deprecated_column,
                schema_name=self.schema_name,
                table_name=self.table_name,
            ))
        missing_columns = [
            column for column in source_columns
            if column.name in self.missing_columns(source_columns)
        ]
        if isinstance(deletion_rule, MarkAsDeleted) and deletion_rule.column_name not in self.column_names():
            missing_columns.append(deletion_rule.get_column())
        if missing_columns:
            sqls.append(jinja2.Template("""
                ALTER TABLE "{{ schema_name }}"."{{ table_name }}"
                {%- for column in columns %}ADD COLUMN "{{ column.name }}" {{ adjust_data_type(column.data_type) }}{% if not loop.last %},{% endif %}{%- endfor %};
            """).render(
                adjust_data_type=self.adjust_data_type,
                columns=missing_columns,
                schema_name=self.schema_name,
                table_name=self.table_name,
            ))
        if primary_keys:
            if not self.dry_run and self.conn is not None:
                self._pg_raise_if_merge_keys_have_duplicates(primary_keys)
            sqls.append(jinja2.Template("""
                DO $ingestra_ensure_pk$
                BEGIN
                    IF NOT EXISTS (
                        SELECT 1
                        FROM pg_catalog.pg_constraint con
                        INNER JOIN pg_catalog.pg_class rel ON rel.oid = con.conrelid
                        INNER JOIN pg_catalog.pg_namespace nsp ON nsp.oid = rel.relnamespace
                        WHERE con.contype = 'p'
                            AND nsp.nspname = '{{ schema_name }}'
                            AND rel.relname = '{{ table_name }}'
                    ) THEN
                        ALTER TABLE "{{ schema_name }}"."{{ table_name }}"
                            ADD PRIMARY KEY ({% for pk in primary_keys %}"{{ pk }}"{% if not loop.last %}, {% endif %}{% endfor %});
                    END IF;
                END
                $ingestra_ensure_pk$;
            """).render(
                schema_name=self.schema_name,
                table_name=self.table_name,
                primary_keys=primary_keys,
            ))
        self._pg_run_sqls(sqls)

    def _pg_raise_if_merge_keys_have_duplicates(self, primary_keys: list) -> None:
        """Before ``ADD PRIMARY KEY``, fail fast if the main table already violates uniqueness."""
        group = ", ".join(f'"{pk}"' for pk in primary_keys)
        sql = (
            f'SELECT 1 FROM "{self.schema_name}"."{self.table_name}" '
            f"GROUP BY {group} HAVING COUNT(*) > 1 LIMIT 1"
        )
        with self.conn.cursor() as cur:
            cur.execute(sql)
            if cur.fetchone() is not None:
                raise ValueError(
                    'Cannot add PRIMARY KEY on "%s"."%s" over (%s): duplicate values exist. '
                    "Deduplicate the table first."
                    % (self.schema_name, self.table_name, ", ".join(primary_keys))
                )

    def upsert(self, primary_keys: list = None) -> None:
        """``INSERT … ON CONFLICT … DO UPDATE`` from ``*_delta`` into the main table."""
        pks = self._effective_primary_keys(primary_keys)
        columns = self.columns(refresh=True)
        sql = jinja2.Template("""
            INSERT INTO "{{ schema_name }}"."{{ table_name }}" (
                {%- for column in columns %}
                "{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            )
            SELECT
                {%- for column in columns %}
                "{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            FROM "{{ schema_name }}"."{{ table_name }}_delta"
            ON CONFLICT (
                {%- for pk in primary_keys %}
                "{{ pk }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            )
            DO UPDATE SET
                {%- for column in columns %}
                "{{ column.name }}" = EXCLUDED."{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %};
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=columns,
            primary_keys=pks,
        )
        if self.dry_run:
            print(sql)
            return
        if self.verbose:
            print(sql)
        with self.conn.cursor() as cursor:
            cursor.execute(sql)
        self.conn.commit()

    def overwrite(self, primary_keys: list = None, deletion_rule: LifecycleRule = None) -> None:
        """Upsert from ``*_delta``, then delete or soft-delete target-only rows."""
        pks = self._effective_primary_keys(primary_keys)
        columns = self.columns(refresh=True)
        mark = isinstance(deletion_rule, MarkAsDeleted)
        mark_rule = deletion_rule if mark else None
        sqls = [jinja2.Template("""
            INSERT INTO "{{ schema_name }}"."{{ table_name }}" (
                {%- for column in columns %}
                "{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            )
            SELECT
                {%- for column in columns %}
                {%- if mark_as_deleted and column.name == mark_rule.column_name %}
                {{ mark_rule.default_value }}
                {%- else %}
                d."{{ column.name }}"
                {%- endif %}
                {%- if not loop.last %},{% endif %}
                {%- endfor %}
            FROM "{{ schema_name }}"."{{ table_name }}_delta" AS d
            ON CONFLICT (
                {%- for pk in primary_keys %}
                "{{ pk }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            )
            DO UPDATE SET
                {%- for column in columns %}
                {%- if mark_as_deleted and column.name == mark_rule.column_name %}
                "{{ column.name }}" = {{ mark_rule.default_value }}
                {%- else %}
                "{{ column.name }}" = EXCLUDED."{{ column.name }}"
                {%- endif %}
                {%- if not loop.last %},{% endif %}
                {%- endfor %};
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=columns,
            primary_keys=pks,
            mark_as_deleted=mark,
            mark_rule=mark_rule,
        )]
        if isinstance(deletion_rule, Delete):
            sqls.append(jinja2.Template("""
                DELETE FROM "{{ schema_name }}"."{{ table_name }}" AS t
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM "{{ schema_name }}"."{{ table_name }}_delta" AS d
                    WHERE
                    {%- for pk in primary_keys %}
                    t."{{ pk }}" = d."{{ pk }}"{% if not loop.last %} AND{% endif %}
                    {%- endfor %}
                );
            """).render(
                schema_name=self.schema_name,
                table_name=self.table_name,
                primary_keys=pks,
            ))
        elif mark:
            sqls.append(jinja2.Template("""
                UPDATE "{{ schema_name }}"."{{ table_name }}" AS t
                SET "{{ mark_rule.column_name }}" = {{ mark_rule.value }}
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM "{{ schema_name }}"."{{ table_name }}_delta" AS d
                    WHERE
                    {%- for pk in primary_keys %}
                    t."{{ pk }}" = d."{{ pk }}"{% if not loop.last %} AND{% endif %}
                    {%- endfor %}
                );
            """).render(
                schema_name=self.schema_name,
                table_name=self.table_name,
                primary_keys=pks,
                mark_rule=mark_rule,
            ))

        for sql in sqls:
            if self.dry_run:
                print(sql)
                continue
            if self.verbose:
                print(sql)
            with self.conn.cursor() as cursor:
                cursor.execute(sql)
            self.conn.commit()

    def load_delta_from_ndjson_file(
        self, file_path: str, truncate: bool = True, batch_size: int = 500
    ) -> int:
        """Load ``*_delta`` from newline-delimited JSON (one object per line).

        Expects the same shape as :meth:`Ingest.extract_to_local_file` output: keys
        match column names on the ``*_delta`` table. Column order follows
        :meth:`delta_heap_columns`. Boolean cells from MySQL JSON (``0``/``1``)
        are coerced for PostgreSQL (see :func:`coerce_ndjson_value_for_postgres`).
        """
        if self.dry_run:
            raise RuntimeError(
                "load_delta_from_ndjson_file does nothing in dry_run mode; run with dry_run=False.")
        if self.conn is None:
            raise RuntimeError("No connection; call connection(...) first.")

        columns = self.delta_heap_columns(refresh=True)
        col_names = [c.name for c in columns]
        placeholders = ", ".join(["%s"] * len(col_names))
        col_sql = ", ".join(f'"{n}"' for n in col_names)
        delta_rel = f'"{self.schema_name}"."{self.table_name}_delta"'
        insert_sql = f"INSERT INTO {delta_rel} ({col_sql}) VALUES ({placeholders})"
        inserted = 0
        with self.conn.cursor() as cur:
            if truncate:
                if self.verbose:
                    print(f"TRUNCATE TABLE {delta_rel}")
                cur.execute(f"TRUNCATE TABLE {delta_rel}")
            if self.verbose:
                print(insert_sql)
            batch = []
            with open(file_path, encoding="utf-8") as fp:
                for line in fp:
                    line = line.strip()
                    if not line:
                        continue
                    row = json.loads(line)
                    batch.append(
                        tuple(
                            coerce_ndjson_value_for_postgres(row.get(c.name), c)
                            for c in columns
                        )
                    )
                    if len(batch) >= batch_size:
                        cur.executemany(insert_sql, batch)
                        inserted += len(batch)
                        batch.clear()
            if batch:
                cur.executemany(insert_sql, batch)
                inserted += len(batch)
        self.conn.commit()
        return inserted


class Hive(DataSource):
    """Placeholder for a future Hive / Spark SQL source implementation."""

    pass


class Redshift(PostgreSQL):
    """Amazon Redshift source/target with S3-native staging and export helpers.

    Redshift reuses PostgreSQL metadata/extract query shapes, but target merge and
    schema DDL are Redshift-specific here:

    - no ``PRIMARY KEY`` DDL assumptions during schema alignment
    - key-based merge SQL via ``UPDATE ... FROM`` + ``INSERT ... WHERE NOT EXISTS``
    - S3 staging through ``COPY`` for ``*_delta``
    - optional S3 export through ``UNLOAD``
    """

    def adjust_data_type(self, data_type) -> str:
        """Redshift follows PostgreSQL-style DDL; :class:`ColumnTypes` has no ``Redshift`` key."""
        return getattr(ColumnTypes, data_type).get("PostgreSQL")[0]

    def _redshift_run_sqls(self, sqls: list) -> None:
        """Execute Redshift statements serially with dry-run/verbose behavior and cache reset."""
        for sql in sqls:
            if self.dry_run:
                print(sql)
                continue
            if self.verbose:
                print(sql)
            with self.conn.cursor() as cursor:
                cursor.execute(sql)
            self.conn.commit()
        if not self.dry_run:
            self.cols = None
            self._delta_cols = None

    def create(self, source_columns: list, deletion_rule: LifecycleRule, **kwargs) -> None:
        """Create Redshift main table only (no ``*_delta`` side effects, no PK DDL)."""
        _validate_mark_as_deleted_source_names(source_columns, deletion_rule)
        sqls = []
        final_source_columns = copy.copy(source_columns)
        if isinstance(deletion_rule, MarkAsDeleted):
            final_source_columns.append(deletion_rule.get_column())
        sqls.append(jinja2.Template("""
            CREATE TABLE "{{ schema_name }}"."{{ table_name }}" (
                {%- for column in columns %}
                "{{ column.name }}" {{ adjust_data_type(column.data_type) }}{% if not loop.last %},{% endif %}
                {%- endfor %}
            );
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=final_source_columns,
            adjust_data_type=self.adjust_data_type,
        ))
        self._redshift_run_sqls(sqls)

    def alter(self, source_columns: list, deletion_rule: LifecycleRule, **kwargs) -> None:
        """Align Redshift main table columns only (no ``*_delta`` side effects)."""
        _validate_mark_as_deleted_source_names(source_columns, deletion_rule)
        sqls = []
        deprecated_columns = [
            column for column in self.columns()
            if column.name in self.deprecated_columns(source_columns)
        ]
        if isinstance(deletion_rule, MarkAsDeleted):
            deprecated_columns = [
                c for c in deprecated_columns
                if c.name != deletion_rule.column_name
            ]
        for deprecated_column in deprecated_columns:
            sqls.append(jinja2.Template("""
                ALTER TABLE "{{ schema_name }}"."{{ table_name }}"
                DROP COLUMN IF EXISTS "{{ column.name }}";
            """).render(
                column=deprecated_column,
                schema_name=self.schema_name,
                table_name=self.table_name,
            ))
        missing_columns = [
            column for column in source_columns
            if column.name in self.missing_columns(source_columns)
        ]
        if isinstance(deletion_rule, MarkAsDeleted) and deletion_rule.column_name not in self.column_names():
            missing_columns.append(deletion_rule.get_column())
        if missing_columns:
            sqls.append(jinja2.Template("""
                ALTER TABLE "{{ schema_name }}"."{{ table_name }}"
                {%- for column in columns %}ADD COLUMN "{{ column.name }}" {{ adjust_data_type(column.data_type) }}{% if not loop.last %},{% endif %}{%- endfor %};
            """).render(
                adjust_data_type=self.adjust_data_type,
                columns=missing_columns,
                schema_name=self.schema_name,
                table_name=self.table_name,
            ))
        self._redshift_run_sqls(sqls)

    def _redshift_s3_auth_clause(self, credentials: CloudCredentials = None) -> str:
        """Render Redshift ``COPY``/``UNLOAD`` auth clause from typed AWS credentials."""
        if isinstance(credentials, AwsIamRoleCredentials):
            return f"IAM_ROLE '{credentials.iam_role}'"
        if isinstance(credentials, AwsAccessKeyCredentials):
            creds = (
                f"aws_access_key_id={credentials.access_key_id};"
                f"aws_secret_access_key={credentials.secret_access_key}"
            )
            if credentials.session_token:
                creds += f";token={credentials.session_token}"
            return f"CREDENTIALS '{creds}'"
        raise ValueError(
            "Redshift requires AwsIamRoleCredentials or AwsAccessKeyCredentials."
        )

    def load_delta_from_cloud_storage(
        self,
        cloud_storage_path: str,
        cloud_credentials: CloudCredentials = None,
        region: str = None,
        truncate: bool = True,
    ) -> None:
        """Load ``{table}_delta`` with ``COPY`` from cloud object storage files."""
        if not cloud_storage_path:
            raise ValueError("cloud_storage_path is required for Redshift COPY.")
        auth_clause = self._redshift_s3_auth_clause(cloud_credentials)
        delta_rel = f'"{self.schema_name}"."{self.table_name}_delta"'
        sqls = []
        if truncate:
            sqls.append(f"TRUNCATE TABLE {delta_rel};")
        copy_sql = jinja2.Template("""
            COPY {{ delta_rel }}
            FROM '{{ cloud_storage_path }}'
            {{ auth_clause }}
            {%- if region %}
            REGION '{{ region }}'
            {%- endif %}
            FORMAT AS JSON 'auto'
            TIMEFORMAT 'auto'
            DATEFORMAT 'auto'
            TRUNCATECOLUMNS
            BLANKSASNULL
            EMPTYASNULL;
        """).render(
            delta_rel=delta_rel,
            cloud_storage_path=cloud_storage_path,
            auth_clause=auth_clause,
            region=region,
        )
        sqls.append(copy_sql)
        self._redshift_run_sqls(sqls)

    def prepare_target_delta_from_cloud_storage(
        self, source_columns: list, delta_spec: CloudStorageDeltaSpec
    ) -> None:
        """Recreate Redshift ``*_delta`` from source columns, then ``COPY`` from one URI."""
        if not delta_spec or not delta_spec.uris:
            raise ValueError("delta_spec.uris is required for Redshift COPY.")
        if len(delta_spec.uris) != 1:
            raise ValueError(
                "Redshift COPY expects one cloud URI/prefix; pass a single entry in delta_spec.uris."
            )
        self._redshift_run_sqls([
            self.drop_delta_heap_table(),
            self.create_delta_heap_table(source_columns),
        ])
        self.load_delta_from_cloud_storage(
            cloud_storage_path=delta_spec.uris[0],
            cloud_credentials=delta_spec.credentials,
            region=delta_spec.region,
            truncate=delta_spec.truncate,
        )

    def _render_unload_sql(
        self,
        query_sql: str,
        storage_path: str,
        cloud_credentials: CloudCredentials,
        region: str = None,
    ) -> str:
        """Build a Redshift ``UNLOAD`` statement for JSON export to cloud storage."""
        auth_clause = self._redshift_s3_auth_clause(cloud_credentials)
        return jinja2.Template("""
            UNLOAD ('{{ query_sql_escaped }}')
            TO '{{ storage_path }}'
            {{ auth_clause }}
            {%- if region %}
            REGION '{{ region }}'
            {%- endif %}
            FORMAT AS JSON 'auto'
            ALLOWOVERWRITE
            PARALLEL OFF;
        """).render(
            query_sql_escaped=query_sql.replace("'", "''"),
            storage_path=storage_path,
            auth_clause=auth_clause,
            region=region,
        )

    def extract_to_cloud_storage(
        self,
        cloud_storage_path: str,
        cloud_credentials: CloudCredentials = None,
        region: str = None,
    ) -> str:
        """Export full table to cloud object storage via ``UNLOAD`` as JSON."""
        columns = self.columns()
        query_sql = jinja2.Template("""
            SELECT
                {%- for column in columns %}
                "{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            FROM
                "{{ schema_name }}"."{{ table_name }}"
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=columns,
        )
        sql = self._render_unload_sql(
            query_sql=query_sql,
            storage_path=cloud_storage_path,
            cloud_credentials=cloud_credentials,
            region=region,
        )
        self._redshift_run_sqls([sql])
        return cloud_storage_path

    def extract_delta_to_cloud_storage(
        self,
        column_name: str,
        start_time: datetime.datetime,
        end_time: datetime.datetime = None,
        cloud_storage_path: str = None,
        cloud_credentials: CloudCredentials = None,
        region: str = None,
        sql_from: str = None,
    ) -> str:
        """Export a time-windowed slice to cloud storage via ``UNLOAD`` as JSON."""
        if not cloud_storage_path:
            raise ValueError("cloud_storage_path is required for Redshift UNLOAD.")
        columns = self.columns()
        delta_column = self.get_column(column_name)
        if sql_from is None and delta_column.data_type not in ("DATE", "DATETIME", "TIMESTAMP"):
            raise RuntimeError(
                "Not supported delta extraction via non date/timestamp column")
        query_sql = jinja2.Template("""
            SELECT
                {%- for column in columns %}
                "{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            FROM
                {%- if sql_from %}
                (
                    {{ sql_from }}
                ) AS vw
                {%- else %}
                "{{ schema_name }}"."{{ table_name }}"
                {%- endif %}
            WHERE
                "{{ column_name }}" >= '{{ start_time }}'
                {%- if end_time %}
                AND "{{ column_name }}" < '{{ end_time }}'
                {%- endif %}
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=columns,
            column_name=column_name,
            start_time=start_time,
            end_time=end_time,
            sql_from=sql_from,
        )
        sql = self._render_unload_sql(
            query_sql=query_sql,
            storage_path=cloud_storage_path,
            cloud_credentials=cloud_credentials,
            region=region,
        )
        self._redshift_run_sqls([sql])
        return cloud_storage_path

    def upsert(self, primary_keys: list = None) -> None:
        """Redshift upsert via ``UPDATE ... FROM`` + ``INSERT ... WHERE NOT EXISTS``."""
        pks = self._effective_primary_keys(primary_keys)
        columns = self.columns(refresh=True)
        sqls = [jinja2.Template("""
            UPDATE "{{ schema_name }}"."{{ table_name }}" AS t
            SET
                {%- for column in columns %}
                "{{ column.name }}" = d."{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            FROM "{{ schema_name }}"."{{ table_name }}_delta" AS d
            WHERE
                {%- for pk in primary_keys %}
                t."{{ pk }}" = d."{{ pk }}"{% if not loop.last %} AND {% endif %}
                {%- endfor %};
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=columns,
            primary_keys=pks,
        )]
        sqls.append(jinja2.Template("""
            INSERT INTO "{{ schema_name }}"."{{ table_name }}" (
                {%- for column in columns %}
                "{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            )
            SELECT
                {%- for column in columns %}
                d."{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            FROM "{{ schema_name }}"."{{ table_name }}_delta" AS d
            WHERE NOT EXISTS (
                SELECT 1
                FROM "{{ schema_name }}"."{{ table_name }}" AS t
                WHERE
                    {%- for pk in primary_keys %}
                    t."{{ pk }}" = d."{{ pk }}"{% if not loop.last %} AND {% endif %}
                    {%- endfor %}
            );
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=columns,
            primary_keys=pks,
        ))
        self._redshift_run_sqls(sqls)

    def overwrite(self, primary_keys: list = None, deletion_rule: LifecycleRule = None) -> None:
        """Upsert from ``*_delta``, then delete or soft-delete target-only rows."""
        pks = self._effective_primary_keys(primary_keys)
        columns = self.columns(refresh=True)
        mark = isinstance(deletion_rule, MarkAsDeleted)
        mark_rule = deletion_rule if mark else None
        sqls = [jinja2.Template("""
            UPDATE "{{ schema_name }}"."{{ table_name }}" AS t
            SET
                {%- for column in columns %}
                {%- if mark_as_deleted and column.name == mark_rule.column_name %}
                "{{ column.name }}" = {{ mark_rule.default_value }}
                {%- else %}
                "{{ column.name }}" = d."{{ column.name }}"
                {%- endif %}
                {%- if not loop.last %},{% endif %}
                {%- endfor %}
            FROM "{{ schema_name }}"."{{ table_name }}_delta" AS d
            WHERE
                {%- for pk in primary_keys %}
                t."{{ pk }}" = d."{{ pk }}"{% if not loop.last %} AND {% endif %}
                {%- endfor %};
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=columns,
            primary_keys=pks,
            mark_as_deleted=mark,
            mark_rule=mark_rule,
        )]
        sqls.append(jinja2.Template("""
            INSERT INTO "{{ schema_name }}"."{{ table_name }}" (
                {%- for column in columns %}
                "{{ column.name }}"{% if not loop.last %},{% endif %}
                {%- endfor %}
            )
            SELECT
                {%- for column in columns %}
                {%- if mark_as_deleted and column.name == mark_rule.column_name %}
                {{ mark_rule.default_value }}
                {%- else %}
                d."{{ column.name }}"
                {%- endif %}
                {%- if not loop.last %},{% endif %}
                {%- endfor %}
            FROM "{{ schema_name }}"."{{ table_name }}_delta" AS d
            WHERE NOT EXISTS (
                SELECT 1
                FROM "{{ schema_name }}"."{{ table_name }}" AS t
                WHERE
                    {%- for pk in primary_keys %}
                    t."{{ pk }}" = d."{{ pk }}"{% if not loop.last %} AND {% endif %}
                    {%- endfor %}
            );
        """).render(
            schema_name=self.schema_name,
            table_name=self.table_name,
            columns=columns,
            primary_keys=pks,
            mark_as_deleted=mark,
            mark_rule=mark_rule,
        ))
        if isinstance(deletion_rule, Delete):
            sqls.append(jinja2.Template("""
                DELETE FROM "{{ schema_name }}"."{{ table_name }}" AS t
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM "{{ schema_name }}"."{{ table_name }}_delta" AS d
                    WHERE
                    {%- for pk in primary_keys %}
                    t."{{ pk }}" = d."{{ pk }}"{% if not loop.last %} AND{% endif %}
                    {%- endfor %}
                );
            """).render(
                schema_name=self.schema_name,
                table_name=self.table_name,
                primary_keys=pks,
            ))
        elif mark:
            sqls.append(jinja2.Template("""
                UPDATE "{{ schema_name }}"."{{ table_name }}" AS t
                SET "{{ mark_rule.column_name }}" = {{ mark_rule.value }}
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM "{{ schema_name }}"."{{ table_name }}_delta" AS d
                    WHERE
                    {%- for pk in primary_keys %}
                    t."{{ pk }}" = d."{{ pk }}"{% if not loop.last %} AND{% endif %}
                    {%- endfor %}
                );
            """).render(
                schema_name=self.schema_name,
                table_name=self.table_name,
                primary_keys=pks,
                mark_rule=mark_rule,
            ))
        self._redshift_run_sqls(sqls)


class MySQL(DataSource):
    """MySQL / MariaDB table — source (extract) or target (heap ``{table}_delta`` + upsert).

    As a **target**, load ``{table_name}_delta`` (e.g. :meth:`load_delta_from_ndjson_file`),
    then call :meth:`upsert` or :meth:`overwrite`. The main table must have a
    ``PRIMARY KEY`` or ``UNIQUE`` key on ``primary_keys`` so ``ON DUPLICATE KEY UPDATE`` applies.
    """

    def __init__(self, table_name: str, schema_name: str = None, primary_keys: list = None):
        """
        Args:
            table_name: Table name within the database.
            schema_name: Database/schema name; set automatically on :meth:`connection` if omitted.
            primary_keys: As a **target**, merge keys and default for :meth:`upsert` / :meth:`overwrite`;
                also used for ``PRIMARY KEY`` DDL when set.
        """
        super().__init__()
        self.table_name = table_name
        self.schema_name = schema_name
        if primary_keys:
            self.primary_keys = list(primary_keys)

    def mysql_column_type_sql(self, column: Column) -> str:
        """DDL type for MySQL, including ``VARCHAR(M)`` and ``DECIMAL(p,s)`` where required.

        Unlike PostgreSQL, MySQL rejects a bare ``VARCHAR`` without a length; use
        ``character_maximum_length`` from the source (default 255 if unknown).
        """
        if column.data_type == "VARCHAR":
            m = column.character_maximum_length
            if m is None or m < 1:
                m = 255
            return f"VARCHAR({int(m)})"
        if column.data_type == "DECIMAL":
            p = column.numeric_precision
            s = column.numeric_scale
            if p is None:
                p = 10
            if s is None:
                s = 0
            return f"DECIMAL({int(p)},{int(s)})"
        return self.adjust_data_type(column.data_type)

    def connection(self, host: str, user: str, password: str, database: str, port: int = 3306) -> None:
        """Connect via MySQLdb and set ``schema_name`` to the database name if it was unset."""
        import MySQLdb

        if self.conn is None:
            self.conn = MySQLdb.connect(
                host=host,
                user=user,
                password=password,
                db=database,
                port=port,
            )
            # INFORMATION_SCHEMA uses the database name as TABLE_SCHEMA for this connector.
            self.schema_name = database

    def columns(self, refresh: bool = False) -> list:
        """Load column list for ``TABLE_SCHEMA`` / ``TABLE_NAME`` (cached unless ``refresh``)."""
        if self.cols is not None and refresh is False:
            return self.cols

        with self.conn.cursor() as cursor:
            sql = jinja2.Template("""
                SELECT
                    `COLUMN_NAME`,
                    UPPER(`DATA_TYPE`) AS `DATA_TYPE`,
                    `CHARACTER_MAXIMUM_LENGTH`,
                    `NUMERIC_PRECISION`,
                    `NUMERIC_SCALE`
                FROM
                    `INFORMATION_SCHEMA`.`COLUMNS`
                WHERE
                    `TABLE_NAME` = '{{ table_name }}'
                    AND `TABLE_SCHEMA` = '{{ schema_name }}'
                ORDER BY
                    `ORDINAL_POSITION` ASC;
            """).render(table_name=self.table_name, schema_name=self.schema_name)
            cursor.execute(sql)
            columns = []
            for column in cursor.fetchall():
                columns.append(Column(
                    name=column[0],
                    data_type=ColumnTypes.locate("MySQL", column[1]),
                    description="",
                    character_maximum_length=column[2],
                    numeric_precision=column[3],
                    numeric_scale=column[4],
                ))
            self.cols = columns
            return columns

    def delta_heap_columns(self, refresh: bool = False) -> list:
        """Column metadata for ``{table}_delta`` (staging), not the main table.

        The heap table follows the **source** column list; columns such as a
        soft-delete flag added only on the main table by :class:`MarkAsDeleted`
        are absent here. Used by :meth:`load_delta_from_ndjson_file`.
        """
        if self._delta_cols is not None and refresh is False:
            return self._delta_cols

        delta_table = f"{self.table_name}_delta"
        with self.conn.cursor() as cursor:
            sql = jinja2.Template("""
                SELECT
                    `COLUMN_NAME`,
                    UPPER(`DATA_TYPE`) AS `DATA_TYPE`,
                    `CHARACTER_MAXIMUM_LENGTH`,
                    `NUMERIC_PRECISION`,
                    `NUMERIC_SCALE`
                FROM
                    `INFORMATION_SCHEMA`.`COLUMNS`
                WHERE
                    `TABLE_NAME` = '{{ table_name }}'
                    AND `TABLE_SCHEMA` = '{{ schema_name }}'
                ORDER BY
                    `ORDINAL_POSITION` ASC;
            """).render(table_name=delta_table, schema_name=self.schema_name)
            cursor.execute(sql)
            columns = []
            for column in cursor.fetchall():
                columns.append(Column(
                    name=column[0],
                    data_type=ColumnTypes.locate("MySQL", column[1]),
                    description="",
                    character_maximum_length=column[2],
                    numeric_precision=column[3],
                    numeric_scale=column[4],
                ))
            self._delta_cols = columns
            return columns

    def extract(self) -> list:
        """Yield all rows from ``table_name`` (current schema/database) as dicts."""
        columns = self.columns()
        column_names = [column.name for column in columns]

        with self.conn.cursor() as cursor:
            sql = jinja2.Template("""
                SELECT
                    {%- for column in columns %}
                    `{{ column.name }}`{% if not loop.last %},{% endif %}
                    {%- endfor %}
                FROM
                    `{{ table_name }}`
                ;
            """).render(table_name=self.table_name, columns=columns)
            if self.verbose:
                print(sql)
            cursor.execute(sql)
            for record in cursor.fetchall():
                yield self.extract_row(dict(zip(column_names, record)))

    def extract_delta(self, column_name: str, start_time: datetime.datetime, end_time: datetime.datetime = None, sql_from: str = None) -> list:
        """Delta extract with ``CAST(... AS <column type>)`` bounds on the filter column."""
        if column_name is None:
            raise ValueError(
                "MySQL.extract_delta requires column_name (e.g. 'updated_at')."
            )
        columns = self.columns()
        column_names = [column.name for column in columns]
        delta_column = self.get_column(column_name)
        # Same guard as PostgreSQL/BigQuery: bound literals need a temporal column unless sql_from supplies logic.
        if sql_from is None and delta_column.data_type not in ("DATE", "DATETIME", "TIMESTAMP"):
            raise RuntimeError(
                "Not supported delta extraction via non date/timestamp column")

        with self.conn.cursor() as cursor:
            sql = jinja2.Template("""
                SELECT
                    {%- for column in columns %}
                    `{{ column.name }}`{% if not loop.last %},{% endif %}
                    {%- endfor %}
                FROM
                    {%- if sql_from %}
                    (
                        {{ sql_from }}
                    ) AS vw
                    {%- else %}
                    `{{ table_name }}`
                    {%- endif %}
                WHERE
                    `{{ column_name }}` >= CAST('{{ start_time }}' AS {{ column_type }})
                    {%- if end_time %}
                    AND `{{ column_name }}` < CAST('{{ end_time }}' AS {{ column_type }})
                    {%- endif %}
                ;
            """).render(table_name=self.table_name, columns=columns, column_name=column_name, column_type=(delta_column.data_type if delta_column else "DATE"), start_time=start_time, end_time=end_time, sql_from=sql_from)
            # column_type is the canonical name (DATE, TIMESTAMP, …); MySQL accepts these in CAST for the covered types.
            if self.verbose:
                print(sql)
            cursor.execute(sql)
            for record in cursor.fetchall():
                yield self.extract_row(dict(zip(column_names, record)))

    def _mysql_run_sqls(self, sqls: list) -> None:
        """Execute MySQL statements with dry-run/verbose behavior and cache reset."""
        for sql in sqls:
            if self.dry_run:
                print(sql)
                continue
            if self.verbose:
                print(sql)
            with self.conn.cursor() as cursor:
                cursor.execute(sql)
            self.conn.commit()
        if not self.dry_run:
            self.cols = None
            self._delta_cols = None

    def create_delta_heap_table(self, source_columns: list) -> str:
        """Return SQL for the heap staging table ``{table}_delta`` in the current database."""
        return jinja2.Template("""
            CREATE TABLE `{{ table_name }}_delta` (
                {%- for column in columns %}
                `{{ column.name }}` {{ mysql_column_type_sql(column) }}{% if not loop.last %},{% endif %}
                {%- endfor %}
            );
        """).render(
            table_name=self.table_name,
            columns=source_columns,
            mysql_column_type_sql=self.mysql_column_type_sql,
        )

    def drop_delta_heap_table(self) -> str:
        """Return SQL to drop the heap ``{table_name}_delta`` staging table if it exists."""
        return jinja2.Template("""
            DROP TABLE IF EXISTS `{{ table_name }}_delta`;
        """).render(table_name=self.table_name)

    def create(self, source_columns: list, deletion_rule: LifecycleRule, **kwargs) -> None:
        """Create ``table`` and ``table_delta`` in the current database.

        Uses :attr:`primary_keys` on this target for a ``PRIMARY KEY`` on the main table.
        Legacy ``kwargs['primary_keys']`` applies only when the instance has none.

        Other ``**kwargs`` are ignored for a uniform :meth:`Ingest.create_or_update_target_schema` call.
        """
        _validate_mark_as_deleted_source_names(source_columns, deletion_rule)
        sqls = []
        sqls.append(self.drop_delta_heap_table())
        sqls.append(self.create_delta_heap_table(source_columns))
        final_source_columns = copy.copy(source_columns)
        if isinstance(deletion_rule, MarkAsDeleted):
            final_source_columns.append(deletion_rule.get_column())
        primary_keys = self._merge_primary_keys_for_ddl(kwargs)
        _validate_optional_primary_keys(
            primary_keys, {c.name for c in final_source_columns})
        sqls.append(jinja2.Template("""
            CREATE TABLE `{{ table_name }}` (
                {%- for column in columns %}
                `{{ column.name }}` {{ mysql_column_type_sql(column) }}{% if not loop.last or primary_keys %},{% endif %}
                {%- endfor %}
                {%- if primary_keys %}
                PRIMARY KEY ({% for pk in primary_keys %}`{{ pk }}`{% if not loop.last %}, {% endif %}{% endfor %})
                {%- endif %}
            );
        """).render(
            table_name=self.table_name,
            columns=final_source_columns,
            mysql_column_type_sql=self.mysql_column_type_sql,
            primary_keys=primary_keys,
        ))
        self._mysql_run_sqls(sqls)

    def _mysql_ensure_primary_key(self, primary_keys: list) -> None:
        """Add ``PRIMARY KEY`` on the main table when missing (MySQL has no IF NOT EXISTS for PK)."""
        if not primary_keys:
            return
        if self.dry_run:
            cols = ", ".join(f"`{pk}`" for pk in primary_keys)
            print(
                f"-- if no PRIMARY KEY on `{self.table_name}`: "
                f"ALTER TABLE `{self.table_name}` ADD PRIMARY KEY ({cols})"
            )
            return
        if self.conn is None:
            return
        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT COUNT(*) FROM information_schema.table_constraints
                WHERE table_schema = DATABASE()
                  AND table_name = %s
                  AND constraint_type = 'PRIMARY KEY'
                """,
                (self.table_name,),
            )
            if cur.fetchone()[0]:
                return
            group_sql = ", ".join(f"`{pk}`" for pk in primary_keys)
            cur.execute(
                f"SELECT 1 FROM `{self.table_name}` "
                f"GROUP BY {group_sql} HAVING COUNT(*) > 1 LIMIT 1"
            )
            if cur.fetchone() is not None:
                raise ValueError(
                    "Cannot add PRIMARY KEY on `%s` (%s): duplicate values exist in "
                    "those columns (MySQL error 1062). Deduplicate `%s` first."
                    % (self.table_name, group_sql, self.table_name)
                )
            cols_sql = ", ".join(f"`{pk}`" for pk in primary_keys)
            cur.execute(
                f"ALTER TABLE `{self.table_name}` ADD PRIMARY KEY ({cols_sql})"
            )
        self.conn.commit()
        self.cols = None
        self._delta_cols = None

    def alter(self, source_columns: list, deletion_rule: LifecycleRule, **kwargs) -> None:
        """Rebuild ``*_delta``, then align main table columns.

        Uses :attr:`primary_keys` (or legacy ``kwargs['primary_keys']``) for optional ``ALTER`` PK.
        """
        _validate_mark_as_deleted_source_names(source_columns, deletion_rule)
        sqls = []
        sqls.append(self.drop_delta_heap_table())
        sqls.append(self.create_delta_heap_table(source_columns))
        primary_keys = self._merge_primary_keys_for_ddl(kwargs)
        allowed_names = {c.name for c in source_columns}
        if isinstance(deletion_rule, MarkAsDeleted):
            allowed_names.add(deletion_rule.column_name)
        _validate_optional_primary_keys(primary_keys, allowed_names)
        deprecated_columns = [
            column for column in self.columns()
            if column.name in self.deprecated_columns(source_columns)
        ]
        if isinstance(deletion_rule, MarkAsDeleted):
            deprecated_columns = [
                c for c in deprecated_columns
                if c.name != deletion_rule.column_name
            ]
        for deprecated_column in deprecated_columns:
            sqls.append(jinja2.Template("""
                ALTER TABLE `{{ table_name }}` DROP COLUMN `{{ column.name }}`;
            """).render(
                column=deprecated_column,
                table_name=self.table_name,
            ))
        missing_columns = [
            column for column in source_columns
            if column.name in self.missing_columns(source_columns)
        ]
        if isinstance(deletion_rule, MarkAsDeleted) and deletion_rule.column_name not in self.column_names():
            missing_columns.append(deletion_rule.get_column())
        if missing_columns:
            sqls.append(jinja2.Template("""
                ALTER TABLE `{{ table_name }}`
                {%- for column in columns %}ADD COLUMN `{{ column.name }}` {{ mysql_column_type_sql(column) }}{% if not loop.last %},{% endif %}{%- endfor %};
            """).render(
                mysql_column_type_sql=self.mysql_column_type_sql,
                columns=missing_columns,
                table_name=self.table_name,
            ))
        self._mysql_run_sqls(sqls)
        self._mysql_ensure_primary_key(primary_keys)

    def upsert(self, primary_keys: list = None) -> None:
        """``INSERT … SELECT … ON DUPLICATE KEY UPDATE`` from ``*_delta``."""
        self._effective_primary_keys(primary_keys)
        columns = self.columns(refresh=True)
        sql = jinja2.Template("""
            INSERT INTO `{{ table_name }}` (
                {%- for column in columns %}
                `{{ column.name }}`{% if not loop.last %},{% endif %}
                {%- endfor %}
            )
            SELECT
                {%- for column in columns %}
                `{{ column.name }}`{% if not loop.last %},{% endif %}
                {%- endfor %}
            FROM `{{ table_name }}_delta`
            ON DUPLICATE KEY UPDATE
                {%- for column in columns %}
                `{{ column.name }}` = VALUES(`{{ column.name }}`){% if not loop.last %},{% endif %}
                {%- endfor %};
        """).render(
            table_name=self.table_name,
            columns=columns,
        )
        if self.dry_run:
            print(sql)
            return
        if self.verbose:
            print(sql)
        with self.conn.cursor() as cursor:
            cursor.execute(sql)
        self.conn.commit()

    def overwrite(self, primary_keys: list = None, deletion_rule: LifecycleRule = None) -> None:
        """Upsert from ``*_delta``, then delete or soft-delete rows missing from delta."""
        pks = self._effective_primary_keys(primary_keys)
        columns = self.columns(refresh=True)
        mark = isinstance(deletion_rule, MarkAsDeleted)
        mark_rule = deletion_rule if mark else None
        sqls = [jinja2.Template("""
            INSERT INTO `{{ table_name }}` (
                {%- for column in columns %}
                `{{ column.name }}`{% if not loop.last %},{% endif %}
                {%- endfor %}
            )
            SELECT
                {%- for column in columns %}
                {%- if mark_as_deleted and column.name == mark_rule.column_name %}
                {{ mark_rule.default_value }}
                {%- else %}
                d.`{{ column.name }}`
                {%- endif %}
                {%- if not loop.last %},{% endif %}
                {%- endfor %}
            FROM `{{ table_name }}_delta` AS d
            ON DUPLICATE KEY UPDATE
                {%- for column in columns %}
                `{{ column.name }}` = {% if mark_as_deleted and column.name == mark_rule.column_name %}{{ mark_rule.default_value }}{% else %}VALUES(`{{ column.name }}`){% endif %}{% if not loop.last %},{% endif %}
                {%- endfor %};
        """).render(
            table_name=self.table_name,
            columns=columns,
            mark_as_deleted=mark,
            mark_rule=mark_rule,
        )]
        if isinstance(deletion_rule, Delete):
            sqls.append(jinja2.Template("""
                DELETE t FROM `{{ table_name }}` AS t
                LEFT JOIN `{{ table_name }}_delta` AS d
                    ON {% for pk in primary_keys %}{% if not loop.first %} AND {% endif %}t.`{{ pk }}` = d.`{{ pk }}`{% endfor %}
                WHERE d.`{{ primary_keys[0] }}` IS NULL;
            """).render(
                table_name=self.table_name,
                primary_keys=pks,
            ))
        elif mark:
            sqls.append(jinja2.Template("""
                UPDATE `{{ table_name }}` AS t
                LEFT JOIN `{{ table_name }}_delta` AS d
                    ON {% for pk in primary_keys %}{% if not loop.first %} AND {% endif %}t.`{{ pk }}` = d.`{{ pk }}`{% endfor %}
                SET t.`{{ mark_rule.column_name }}` = {{ mark_rule.value }}
                WHERE d.`{{ primary_keys[0] }}` IS NULL;
            """).render(
                table_name=self.table_name,
                primary_keys=pks,
                mark_rule=mark_rule,
            ))

        for sql in sqls:
            if self.dry_run:
                print(sql)
                continue
            if self.verbose:
                print(sql)
            with self.conn.cursor() as cursor:
                cursor.execute(sql)
            self.conn.commit()

    def load_delta_from_ndjson_file(
        self, file_path: str, truncate: bool = True, batch_size: int = 500
    ) -> int:
        """Load ``*_delta`` from newline-delimited JSON (one object per line).

        Expects the same shape as :meth:`Ingest.extract_to_local_file` output: keys
        match column names on the ``*_delta`` table. Column order follows
        :meth:`delta_heap_columns`.
        """
        if self.dry_run:
            raise RuntimeError(
                "load_delta_from_ndjson_file does nothing in dry_run mode; run with dry_run=False.")
        if self.conn is None:
            raise RuntimeError("No connection; call connection(...) first.")

        columns = self.delta_heap_columns(refresh=True)
        col_names = [c.name for c in columns]
        placeholders = ", ".join(["%s"] * len(col_names))
        col_sql = ", ".join(f"`{n}`" for n in col_names)
        insert_sql = (
            f"INSERT INTO `{self.table_name}_delta` ({col_sql}) VALUES ({placeholders})"
        )
        inserted = 0
        with self.conn.cursor() as cur:
            if truncate:
                if self.verbose:
                    print(f"TRUNCATE TABLE `{self.table_name}_delta`")
                cur.execute(f"TRUNCATE TABLE `{self.table_name}_delta`")
            if self.verbose:
                print(insert_sql)
            batch = []
            with open(file_path, encoding="utf-8") as fp:
                for line in fp:
                    line = line.strip()
                    if not line:
                        continue
                    row = json.loads(line)
                    batch.append(tuple(row.get(name) for name in col_names))
                    if len(batch) >= batch_size:
                        cur.executemany(insert_sql, batch)
                        inserted += len(batch)
                        batch.clear()
            if batch:
                cur.executemany(insert_sql, batch)
                inserted += len(batch)
        self.conn.commit()
        return inserted


class BigQuery(DataSource):
    """Google BigQuery table as extract target and optional source.

    Implements full pipeline pieces: metadata from ``INFORMATION_SCHEMA``,
    ``SELECT`` extract, staging :meth:`create_external_table` over GCS JSON,
    :meth:`create` / :meth:`alter` DDL, and :meth:`upsert` / :meth:`overwrite`
    ``MERGE`` statements against ``{table}_delta``.
    """

    def __init__(self, project_name: str, dataset_name: str, table_name: str, primary_keys: list = None):
        """
        Args:
            project_name: GCP project id for fully qualified table names.
            dataset_name: BigQuery dataset id.
            table_name: Table id (main table; delta uses ``{table_name}_delta``).
            primary_keys: Optional default merge keys for :meth:`upsert` / :meth:`overwrite`.
        """
        super().__init__()
        self.project_name = project_name
        self.dataset_name = dataset_name
        self.table_name = table_name
        if primary_keys:
            self.primary_keys = list(primary_keys)

    def connection(self, service_account_json: str):
        """Create a :class:`google.cloud.bigquery.Client` from a service-account JSON path."""
        from google.cloud import bigquery
        if self.conn is None:
            self.conn = bigquery.Client.from_service_account_json(
                service_account_json)

    def columns(self, refresh: bool = False) -> list:
        """Load columns from BigQuery ``INFORMATION_SCHEMA.COLUMNS`` (cached unless ``refresh``)."""
        if self.cols is not None and refresh is False:
            return self.cols

        # Cross-dataset INFORMATION_SCHEMA; table_schema here is the dataset id.
        job = self.conn.query(jinja2.Template("""
            SELECT
                column_name,
                UPPER(data_type) AS `data_type`,
            FROM
                `{{ project_name }}.{{ dataset_name }}.INFORMATION_SCHEMA.COLUMNS`
            WHERE
                table_name = '{{ table_name }}'
                AND table_schema = '{{ dataset_name }}'
            ORDER BY
                ordinal_position ASC
        """).render(
            project_name=self.project_name,
            dataset_name=self.dataset_name,
            table_name=self.table_name,
        ))

        columns = []
        for row in job.result():
            columns.append(
                Column(
                    name=row[0],
                    data_type=ColumnTypes.locate("BigQuery", row[1]),
                    description="",
                    character_maximum_length=None,
                    numeric_precision=None,
                    numeric_scale=None
                )
            )
        self.cols = columns
        return columns

    def extract(self) -> list:
        """Yield all rows from the fully qualified table as normalized dicts."""
        columns = self.columns()
        column_names = [column.name for column in columns]

        sql = jinja2.Template("""
            SELECT
                {%- for column in columns %}
                `{{ column.name }}`{% if not loop.last %},{% endif %}
                {%- endfor %}
            FROM 
                `{{ project_name }}.{{ dataset_name }}.{{ table_name }}`
        """).render(project_name=self.project_name, dataset_name=self.dataset_name, table_name=self.table_name, columns=columns)
        if self.verbose:
            print(sql)
        job = self.conn.query(sql)

        for record in job.result():
            # Row values align with column_names by position from the SELECT list.
            yield self.extract_row(dict(zip(column_names, record)))

    def extract_delta(self, column_name: str, start_time: datetime.datetime, end_time: datetime.datetime = None, sql_from: str = None) -> list:
        """Delta extract using chained ``SAFE_CAST`` for bound comparison."""
        if column_name is None:
            raise ValueError(
                "BigQuery.extract_delta requires column_name (e.g. 'updated_at')."
            )
        columns = self.columns()
        column_names = [column.name for column in columns]
        delta_column = self.get_column(column_name)
        if sql_from is None and delta_column.data_type not in ("DATE", "DATETIME", "TIMESTAMP"):
            raise RuntimeError(
                "Not supported delta extraction via non date/datetime/timestamp column")

        sql = jinja2.Template("""
            SELECT
                {%- for column in columns %}
                `{{ column.name }}`{% if not loop.last %},{% endif %}
                {%- endfor %}
            FROM 
                {%- if sql_from %}
                (
                    {{ sql_from }}
                ) AS vw
                {%- else %}
                `{{ project_name }}.{{ dataset_name }}.{{ table_name }}`
                {%- endif %}
            WHERE 
                `{{ column_name }}` >= SAFE_CAST(SAFE_CAST('{{ start_time }}' AS DATETIME) AS {{ column_type }})
                {%- if end_time %}
                AND `{{ column_name }}` < SAFE_CAST(SAFE_CAST('{{ end_time }}' AS DATETIME) AS {{ column_type }})
                {%- endif %}
        """).render(project_name=self.project_name, dataset_name=self.dataset_name, table_name=self.table_name, columns=columns, column_name=column_name, column_type=(delta_column.data_type if delta_column else "DATE"), start_time=start_time, end_time=end_time, sql_from=sql_from)
        # String literal → DATETIME first, then to column_type: avoids errors if the column is DATE/TIMESTAMP/DATETIME.
        if self.verbose:
            print(sql)
        job = self.conn.query(sql)

        for record in job.result():
            yield self.extract_row(dict(zip(column_names, record)))

    def prepare_target_delta_from_cloud_storage(
        self, source_columns: list, delta_spec: CloudStorageDeltaSpec
    ) -> None:
        """Prepare ``{table}_delta`` external table from cloud URIs (GCS for BigQuery)."""
        if not delta_spec or not delta_spec.uris:
            raise ValueError("delta_spec.uris is required for BigQuery external delta table.")
        if delta_spec.file_format != "NEWLINE_DELIMITED_JSON":
            raise ValueError(
                "BigQuery external delta currently supports file_format='NEWLINE_DELIMITED_JSON' only."
            )
        sql = self.create_external_table(source_columns, delta_spec.uris)
        if self.dry_run:
            print(sql)
            return
        if self.verbose:
            print(sql)
        job = self.conn.query(sql)
        for record in job.result():
            print(record)

    def alter(self, source_columns: list, deletion_rule: LifecycleRule, **kwargs) -> None:
        """Align main table schema with ``source_columns`` (does not touch external ``*_delta``).

        Steps (each may append SQL): ``DROP COLUMN`` for columns not in the source
        (except the soft-delete column when using :class:`MarkAsDeleted`);
        ``ADD COLUMN`` for missing source columns (and the flag column if needed).

        Args:
            source_columns: Desired :class:`Column` list (typically from a source DB).
            deletion_rule: Affects whether the soft-delete column is dropped/added.
        """
        _validate_mark_as_deleted_source_names(source_columns, deletion_rule)
        sqls = []

        deprecated_columns = [
            column for column in self.columns() 
            if column.name in self.deprecated_columns(source_columns)
        ]
        # If Mark As Deleted is activated, it will show up to be deprecated since it's missing from source
        # we need to ignore this and not drop the column
        if isinstance(deletion_rule, MarkAsDeleted):
            deprecated_columns = list(filter(lambda x: x.name != deletion_rule.column_name, deprecated_columns))

        if deprecated_columns:
            for deprecated_column in deprecated_columns:
                sqls.append(jinja2.Template("""
                ALTER TABLE `{{ project_name }}.{{ dataset_name }}.{{ table_name }}` 
                DROP COLUMN IF EXISTS `{{ column.name }}`;
                """).render(column=deprecated_column, project_name=self.project_name, dataset_name=self.dataset_name, table_name=self.table_name))

        missing_columns = [
            column 
            for column in source_columns 
            if column.name in self.missing_columns(source_columns)
        ]
        # If Mark as Deleted is activated and the column is missing from the table, we add it to the table.
        if isinstance(deletion_rule, MarkAsDeleted) and deletion_rule.column_name not in self.column_names():
            missing_columns.append(deletion_rule.get_column())

        if missing_columns:
            sqls.append(jinja2.Template("""
            ALTER TABLE `{{ project_name }}.{{ dataset_name }}.{{ table_name }}` 
            {%- for column in columns %}ADD COLUMN `{{ column.name }}` {{ adjust_data_type(column.data_type) }}{% if not loop.last %},{% endif %}{%- endfor %};
            """).render(adjust_data_type=self.adjust_data_type, columns=missing_columns, project_name=self.project_name, dataset_name=self.dataset_name, table_name=self.table_name))

        for sql in sqls:
            if self.dry_run:
                print(sql)
                continue
            if self.verbose:
                print(sql)
            
            job = self.conn.query(sql)
            # DDL jobs return empty iterators; loop drains completion and surfaces API errors.
            for record in job.result():
                print(record)

    def create_external_table(self, source_columns: list, gcs_paths: list) -> None:
        """Return SQL string for ``CREATE OR REPLACE EXTERNAL TABLE ..._delta`` over JSON URIs."""
        return jinja2.Template("""
            CREATE OR REPLACE EXTERNAL TABLE `{{ project_name }}.{{ dataset_name }}.{{ table_name }}_delta` (
                {%- for column in columns %}
                `{{ column.name }}` {{ adjust_data_type(column.data_type) }}{% if not loop.last %},{% endif %}
                {%- endfor %}
            )
            OPTIONS (
                format = "NEWLINE_DELIMITED_JSON",
                uris = [
                    {%- for gcs_path in gcs_paths %}
                    '{{ gcs_path }}'{% if not loop.last %},{% endif %}
                    {%- endfor %}
                ]
            );
        """).render(adjust_data_type=self.adjust_data_type, columns=source_columns, project_name=self.project_name, dataset_name=self.dataset_name, table_name=self.table_name, gcs_paths=gcs_paths)

    def create(self, source_columns: list, deletion_rule: LifecycleRule, **kwargs) -> None:
        """Create the main native table from ``source_columns``.

        Appends the :class:`MarkAsDeleted` column to the main table DDL when
        that rule is active.
        """
        _validate_mark_as_deleted_source_names(source_columns, deletion_rule)
        sqls = []

        # Copy so appending the soft-delete column does not mutate the caller's list.
        final_source_columns = copy.copy(source_columns)
        if isinstance(deletion_rule, MarkAsDeleted):
            final_source_columns.append(deletion_rule.get_column())

        sqls.append(jinja2.Template("""
            CREATE TABLE `{{ project_name }}.{{ dataset_name }}.{{ table_name }}` (
                {%- for column in columns %}
                `{{ column.name }}` {{ adjust_data_type(column.data_type) }}{% if not loop.last %},{% endif %}
                {%- endfor %}
            );
        """).render(adjust_data_type=self.adjust_data_type, columns=final_source_columns, project_name=self.project_name, dataset_name=self.dataset_name, table_name=self.table_name))

        for sql in sqls:
            if self.dry_run:
                print(sql)
                continue
            if self.verbose:
                print(sql)

            job = self.conn.query(sql)
            for record in job.result():
                print(record)

    def overwrite(self, primary_keys: list = None, deletion_rule: LifecycleRule = None) -> None:
        """``MERGE`` from ``{table}_delta`` into the main table with lifecycle behavior.

        Matched rows update all columns (with special handling for the
        soft-delete column). Unmatched source rows insert. If ``deletion_rule``
        is :class:`Delete` or :class:`MarkAsDeleted`, target-only rows are
        deleted or flag-updated respectively.
        """
        pks = self._effective_primary_keys(primary_keys)
        # t = existing BigQuery table; c = staging external table loaded from GCS NDJSON.
        sql = jinja2.Template("""
            MERGE
                `{{ project_name }}.{{ dataset_name }}.{{ table_name }}` t
            USING
                `{{ project_name }}.{{ dataset_name }}.{{ table_name }}_delta` c
            ON
                {%- for primary_key in primary_keys %}
                {% if not loop.first %}AND {% endif %}t.`{{ primary_key }}` = c.`{{ primary_key }}`
                {%- endfor %}
            WHEN MATCHED THEN
                UPDATE SET
                    {%- if mark_as_deleted %}
                    {%- endif %}
                    {%- for column in columns %}
                    {%- if mark_as_deleted and mark_as_deleted_rule.column_name == column.name %}
                    `{{ column.name }}` = {{ mark_as_deleted_rule.default_value }}{% if not loop.last %},{% endif %}
                    {%- else %}
                    `{{ column.name }}` = c.`{{ column.name }}`{% if not loop.last %},{% endif %}
                    {%- endif %}
                    {%- endfor %}
            WHEN NOT MATCHED THEN
                INSERT (
                    {%- for column in columns %}
                    `{{ column.name }}`{% if not loop.last %},{% endif %}
                    {%- endfor %}
                ) VALUES (
                    {%- for column in columns %}
                    {%- if mark_as_deleted and mark_as_deleted_rule.column_name == column.name %}
                    {{ mark_as_deleted_rule.default_value }}{% if not loop.last %},{% endif %}
                    {%- else %}
                    c.`{{ column.name }}`{% if not loop.last %},{% endif %}
                    {%- endif %}
                    {%- endfor %}
                )
            {%- if delete or mark_as_deleted %}
            WHEN NOT MATCHED BY SOURCE THEN
                {%- if delete %}
                DELETE
                {%- elif mark_as_deleted %}
                UPDATE SET
                    `{{ mark_as_deleted_rule.column_name }}` = {{ mark_as_deleted_rule.value }}
                {%- endif %}
            {%- endif %}
        """).render(
            project_name=self.project_name,
            dataset_name=self.dataset_name,
            table_name=self.table_name,
            primary_keys=pks,
            # refresh=True: pick up ADD/DROP from alter() so MERGE lists every physical column.
            columns=self.columns(refresh=True),
            delete=isinstance(deletion_rule, Delete),
            mark_as_deleted=isinstance(deletion_rule, MarkAsDeleted),
            mark_as_deleted_rule=deletion_rule if isinstance(
                deletion_rule, MarkAsDeleted) else None,
        )

        if self.dry_run:
            print(sql)
            return
        if self.verbose:
            print(sql)
        
        job = self.conn.query(sql)
        for record in job.result():
            print(record)

    def upsert(self, primary_keys: list = None) -> None:
        """``MERGE`` delta into target: insert new keys, update all columns on match.

        Does not define ``WHEN NOT MATCHED BY SOURCE`` (no deletes or soft-deletes).
        """
        pks = self._effective_primary_keys(primary_keys)
        # Staging table c holds the latest NDJSON load; t is the durable BigQuery table.
        sql = jinja2.Template("""
            MERGE
                `{{ project_name }}.{{ dataset_name }}.{{ table_name }}` t
            USING
                `{{ project_name }}.{{ dataset_name }}.{{ table_name }}_delta` c
            ON
                {%- for primary_key in primary_keys %}
                {% if not loop.first %}AND {% endif %}t.`{{ primary_key }}` = c.`{{ primary_key }}`
                {%- endfor %}
            WHEN MATCHED THEN
                UPDATE SET
                    {%- for column in columns %}
                    `{{ column.name }}` = c.`{{ column.name }}`{% if not loop.last %},{% endif %}
                    {%- endfor %}
            WHEN NOT MATCHED THEN
                INSERT (
                    {%- for column in columns %}
                    `{{ column.name }}`{% if not loop.last %},{% endif %}
                    {%- endfor %}
                ) VALUES (
                    {%- for column in columns %}
                    c.`{{ column.name }}`{% if not loop.last %},{% endif %}
                    {%- endfor %}
                )
        """).render(
            project_name=self.project_name,
            dataset_name=self.dataset_name,
            table_name=self.table_name,
            primary_keys=pks,
            # Same rationale as overwrite: MERGE must list columns that exist after ALTER.
            columns=self.columns(refresh=True),
        )

        if self.dry_run:
            print(sql)
            return
        if self.verbose:
            print(sql)
        
        job = self.conn.query(sql)
        for record in job.result():
            print(record)


class Ingest(object):
    """Orchestrates a ``source`` and ``target`` :class:`DataSource`.

    Mirrors ``dry_run`` and ``verbose`` to both sides.

    **PostgreSQL or MySQL target:** set :attr:`DataSource.primary_keys` on the target,
    call :meth:`create_or_update_target_schema`, load ``*_delta`` from NDJSON, then
    :meth:`upsert` or :meth:`overwrite` (merge keys default from the target).

    **BigQuery target:** export NDJSON with :meth:`extract_to_local_file` or
    :meth:`extract_delta_to_local_file`, load objects into your bucket, then
    :meth:`create_or_update_target_schema` with ``gcs_paths``, then merge.
    """

    def __init__(self, source: DataSource, target: DataSource, deletion_rule: LifecycleRule = Delete(), dry_run: bool = False, verbose: bool = False) -> None:
        """
        Args:
            source: Origin :class:`DataSource` (extract).
            target: Destination :class:`DataSource` (e.g. :class:`BigQuery`, :class:`PostgreSQL`, :class:`MySQL`).
            deletion_rule: Applied by :meth:`overwrite` on the target.
            dry_run: Passed to both sides; supported targets print DDL/merge SQL instead of running.
            verbose: Passed to both sides; print generated SQL.
        """
        self.source = source
        self.target = target
        self.deletion_rule = deletion_rule
        self.dry_run = dry_run

        # Mirror flags so lower-level SQL builders see the same mode without threading kwargs everywhere.
        self.source.dry_run = dry_run
        self.source.verbose = verbose
        self.target.dry_run = dry_run
        self.target.verbose = verbose

    def get_temporary_file_name(self, dir_name: str = '/tmp') -> str:
        """Return the path of a new empty temp file under ``dir_name`` (file is closed immediately)."""
        from tempfile import NamedTemporaryFile
        # .name survives after the temp handle is GC'd; the file exists empty on disk.
        file_name = NamedTemporaryFile("w", dir=dir_name).name
        return file_name

    def create_or_update_target_schema(self, **kwargs) -> None:
        """Call :meth:`DataSource.create` or :meth:`DataSource.alter` on the target.

        If the target has no columns yet, runs ``create`` with
        ``self.source.columns()``; otherwise ``alter``. Extra keyword
        arguments are forwarded. Only some targets use extra keys (see each
        target’s ``create`` / ``alter`` signatures).

        For :class:`PostgreSQL` / :class:`MySQL`, set ``target.primary_keys`` (or pass
        ``primary_keys`` in ``kwargs`` for backward compatibility) so DDL can add a
        ``PRIMARY KEY`` for merge.
        """
        # Empty table → no columns() yet → CREATE; any existing cols → ALTER to match source.
        if not self.target.columns():
            self.target.create(self.source.columns(), self.deletion_rule, **kwargs)
        else:
            self.target.alter(self.source.columns(), self.deletion_rule, **kwargs)

    def load_target_delta_from_ndjson_file(
        self, file_path: str, truncate: bool = True, batch_size: int = 500
    ) -> int:
        """Call :meth:`PostgreSQL.load_delta_from_ndjson_file` or :meth:`MySQL.load_delta_from_ndjson_file` on ``target``.

        ``file_path`` should be NDJSON from :meth:`extract_to_local_file` or
        :meth:`extract_delta_to_local_file` (same column keys as the target table).
        """
        loader = getattr(self.target, "load_delta_from_ndjson_file", None)
        if loader is None:
            raise NotImplementedError(
                f"{self.target.__class__.__name__} has no load_delta_from_ndjson_file."
            )
        if self.dry_run:
            raise RuntimeError(
                "load_target_delta_from_ndjson_file does nothing in dry_run mode; run with dry_run=False."
            )
        return loader(file_path, truncate=truncate, batch_size=batch_size)

    def load_target_delta_from_cloud_storage(
        self,
        cloud_storage_path: str,
        cloud_credentials: CloudCredentials = None,
        region: str = None,
        truncate: bool = True,
    ):
        """Call target ``load_delta_from_cloud_storage`` if implemented."""
        loader = getattr(self.target, "load_delta_from_cloud_storage", None)
        if loader is None:
            raise NotImplementedError(
                f"{self.target.__class__.__name__} has no load_delta_from_cloud_storage."
            )
        if self.dry_run:
            raise RuntimeError(
                "load_target_delta_from_cloud_storage does nothing in dry_run mode; run with dry_run=False."
            )
        return loader(
            cloud_storage_path=cloud_storage_path,
            cloud_credentials=cloud_credentials,
            region=region,
            truncate=truncate,
        )

    def prepare_target_delta_from_cloud_storage(
        self, delta_spec: CloudStorageDeltaSpec
    ) -> None:
        """Prepare target ``*_delta`` from cloud object storage via one target-agnostic entrypoint."""
        preparer = getattr(self.target, "prepare_target_delta_from_cloud_storage", None)
        if preparer is None:
            raise NotImplementedError(
                f"{self.target.__class__.__name__} has no prepare_target_delta_from_cloud_storage."
            )
        return preparer(self.source.columns(), delta_spec)

    def upsert(self, primary_keys: list = None) -> None:
        """Run target :meth:`DataSource.upsert` (merge from ``*_delta``; no orphan deletes).

        Omit ``primary_keys`` to use :attr:`DataSource.primary_keys` on the target.
        """
        self.target.upsert(primary_keys)

    def overwrite(self, primary_keys: list = None) -> None:
        """Run target :meth:`DataSource.overwrite` using ``self.deletion_rule``.

        Omit ``primary_keys`` to use :attr:`DataSource.primary_keys` on the target.
        """
        self.target.overwrite(primary_keys, self.deletion_rule)

    def extract_to_local_file(self, output_dir_name: str = '/tmp') -> str:
        """Stream :meth:`DataSource.extract` from source into one NDJSON file.

        Returns:
            Path to the temp file containing one JSON object per line.
        """
        local_file_path = self.get_temporary_file_name(
            dir_name=output_dir_name)
        with open(local_file_path, 'w') as fp:
            for record in self.source.extract():
                # One JSON object per line (NDJSON).
                fp.write(json.dumps(record, default=str) + "\n")

        return local_file_path

    def extract_delta_to_local_file(
        self,
        start_time: datetime.datetime,
        end_time: datetime.datetime = None,
        output_dir_name: str = '/tmp',
        *source_extract_delta_args,
        **source_extract_delta_kwargs,
    ) -> str:
        """Like :meth:`extract_to_local_file` but uses :meth:`DataSource.extract_delta`.

        ``*source_extract_delta_args`` / ``**source_extract_delta_kwargs`` are
        passed through to the source ``extract_delta`` call so each source can
        define its own extra parameters (e.g. SQL sources may need a
        ``column_name``; API sources may not).

        Note:
            Uses :func:`json.dumps` without ``default=str`` (unlike
            :meth:`extract_to_local_file`); exotic types in delta rows may need
            normalization at the source.
        """
        local_file_path = self.get_temporary_file_name(
            dir_name=output_dir_name)
        with open(local_file_path, 'w') as fp:
            for record in self.source.extract_delta(
                *source_extract_delta_args,
                start_time=start_time,
                end_time=end_time,
                **source_extract_delta_kwargs,
            ):
                fp.write(json.dumps(record) + "\n")

        return local_file_path

    def extract_to_cloud_storage(
        self,
        cloud_storage_path: str,
        cloud_credentials: CloudCredentials = None,
        region: str = None,
    ) -> str:
        """Delegate full export to source cloud-storage export when supported."""
        exporter = getattr(self.source, "extract_to_cloud_storage", None)
        if exporter is None:
            raise NotImplementedError(
                f"{self.source.__class__.__name__} has no extract_to_cloud_storage."
            )
        return exporter(
            cloud_storage_path=cloud_storage_path,
            cloud_credentials=cloud_credentials,
            region=region,
        )

    def extract_delta_to_cloud_storage(
        self,
        start_time: datetime.datetime,
        end_time: datetime.datetime = None,
        cloud_storage_path: str = None,
        cloud_credentials: CloudCredentials = None,
        region: str = None,
        *source_extract_delta_args,
        **source_extract_delta_kwargs,
    ) -> str:
        """Delegate delta export to source cloud-storage export when supported.

        ``*source_extract_delta_args`` / ``**source_extract_delta_kwargs`` are
        passed through to the source implementation so source-specific delta
        options (e.g. ``column_name`` / ``sql_from`` for SQL sources) stay out
        of the orchestration API.
        """
        exporter = getattr(self.source, "extract_delta_to_cloud_storage", None)
        if exporter is None:
            raise NotImplementedError(
                f"{self.source.__class__.__name__} has no extract_delta_to_cloud_storage."
            )
        return exporter(
            *source_extract_delta_args,
            start_time=start_time,
            end_time=end_time,
            cloud_storage_path=cloud_storage_path,
            cloud_credentials=cloud_credentials,
            region=region,
            **source_extract_delta_kwargs,
        )
