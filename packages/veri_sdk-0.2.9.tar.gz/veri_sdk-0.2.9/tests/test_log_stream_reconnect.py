"""VS-215 follow-up: SDK reconnects the SSE log stream until the job is terminal.

The 2026-05-15 observation: `veri train` saw zero log lines for the whole
run, despite bootstrap.log being populated server-side. CloudWatch showed
the SDK hit `GET /v1/training_jobs/{id}/logs` once, got 400 ("Job has not
been submitted yet" — runner_id wasn't set yet at the time of the call),
and `_log_stream_loop` exited permanently.

Fix: the consumer must reconnect with backoff through the pre-provisioning
window (400/404), tolerate mid-stream drops, and only exit on a terminal
sentinel or when `job.status` reaches a terminal value.
"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import pytest

from veri_sdk import _decorators


@pytest.mark.asyncio
async def test_log_stream_reconnects_after_pre_provisioning_400(monkeypatch):
    """First connect: server returns 400 (runner not assigned yet) → empty.
    Second connect: real lines arrive. The consumer must surface those lines.
    """
    monkeypatch.setattr(_decorators, "_LOG_HEARTBEAT_INTERVAL", 100.0)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_INITIAL", 0.005)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_MAX", 0.005)

    connects = {"n": 0}

    async def fake_iter(_job_id, _client):
        connects["n"] += 1
        if connects["n"] == 1:
            # 400 surface: _iter_log_lines yielded nothing. Simulate by
            # returning an empty async iterator.
            return
            yield  # pragma: no cover
        # Second connect: real lines, then terminal sentinel.
        yield "installing vllm 0.15.1..."
        yield "install complete"
        yield "[Job completed]"

    monkeypatch.setattr(_decorators, "_iter_log_lines", fake_iter)

    job = MagicMock()
    job.id = "tj_abc"
    job.status = "queued"

    lines: list[str] = []

    async def collect(msg: str) -> None:
        lines.append(msg)

    await _decorators._log_stream_loop(job, MagicMock(), safe_log=collect)

    worker_lines = [ln for ln in lines if "[worker]" in ln]
    assert any("installing vllm" in ln for ln in worker_lines), (
        f"Expected install line after reconnect; saw: {lines!r}"
    )
    assert connects["n"] >= 2, "Consumer must reconnect after early empty stream"


@pytest.mark.asyncio
async def test_log_stream_exits_when_job_terminal(monkeypatch):
    """If the status loop marks job terminal, the log loop must stop
    reconnecting — otherwise we leak the stream task forever."""
    monkeypatch.setattr(_decorators, "_LOG_HEARTBEAT_INTERVAL", 100.0)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_INITIAL", 0.005)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_MAX", 0.005)

    connects = {"n": 0}

    async def fake_iter(_job_id, _client):
        connects["n"] += 1
        # Always empty — pre-provisioning forever.
        return
        yield  # pragma: no cover

    monkeypatch.setattr(_decorators, "_iter_log_lines", fake_iter)

    job = MagicMock()
    job.id = "tj_abc"
    job.status = "queued"

    async def collect(_msg: str) -> None: pass

    # After 3 reconnects, simulate the status loop seeing terminal.
    async def flip_after_delay() -> None:
        await asyncio.sleep(0.02)
        job.status = "failed"

    flip_task = asyncio.create_task(flip_after_delay())

    await asyncio.wait_for(
        _decorators._log_stream_loop(job, MagicMock(), safe_log=collect),
        timeout=2.0,
    )
    flip_task.cancel()


@pytest.mark.asyncio
async def test_log_stream_handles_mid_stream_http_drop(monkeypatch):
    """Stream connects, yields a few lines, then drops (httpx.HTTPError).
    Loop must reconnect and continue surfacing later lines."""
    import httpx

    monkeypatch.setattr(_decorators, "_LOG_HEARTBEAT_INTERVAL", 100.0)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_INITIAL", 0.005)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_MAX", 0.005)

    connects = {"n": 0}

    async def fake_iter(_job_id, _client):
        connects["n"] += 1
        if connects["n"] == 1:
            yield "step 1 loss=4.5"
            raise httpx.ReadError("connection reset")
        yield "step 2 loss=4.2"
        yield "[Job completed]"

    monkeypatch.setattr(_decorators, "_iter_log_lines", fake_iter)

    job = MagicMock()
    job.id = "tj_abc"
    job.status = "running"

    lines: list[str] = []

    async def collect(msg: str) -> None: lines.append(msg)

    await _decorators._log_stream_loop(job, MagicMock(), safe_log=collect)

    worker_lines = [ln for ln in lines if "[worker]" in ln]
    assert any("step 1" in ln for ln in worker_lines)
    assert any("step 2" in ln for ln in worker_lines)


@pytest.mark.asyncio
async def test_log_stream_surfaces_non_200_status_once(monkeypatch):
    """Visibility fix: when the SSE endpoint returns non-200 repeatedly, the
    SDK must announce *what* the server said (not just retry in silence).
    Print the diagnostic once per state change, not once per retry."""
    monkeypatch.setattr(_decorators, "_LOG_HEARTBEAT_INTERVAL", 100.0)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_INITIAL", 0.005)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_MAX", 0.005)

    connects = {"n": 0}

    async def fake_iter(_job_id, _client):
        connects["n"] += 1
        if connects["n"] <= 3:
            # Pre-provisioning 400 three times in a row.
            raise _decorators._SSEConnectError(400, "Job has not been submitted yet")
        # Then real lines.
        yield "install starting"
        yield "[Job completed]"

    monkeypatch.setattr(_decorators, "_iter_log_lines", fake_iter)

    job = MagicMock()
    job.id = "tj_abc"
    job.status = "queued"

    lines: list[str] = []

    async def collect(msg: str) -> None:
        lines.append(msg)

    await _decorators._log_stream_loop(job, MagicMock(), safe_log=collect)

    # The diagnostic must appear at least once so the user sees what happened.
    diag_lines = [ln for ln in lines if "[stream] 400" in ln]
    assert len(diag_lines) >= 1, f"Expected the 400 diagnostic; got: {lines!r}"
    # But not more than once per state — three retries should produce one diag,
    # not three. (We're testing dedup, not the literal count.)
    assert len(diag_lines) <= 2, (
        f"Expected the 400 diagnostic to be deduped, got {len(diag_lines)}: {lines!r}"
    )
    # After reconnect succeeds, we should see a "connected" line + worker lines.
    assert any("connected" in ln for ln in lines), (
        f"Expected a 'connected' line after recovery; got: {lines!r}"
    )
    assert any("install starting" in ln for ln in lines)


@pytest.mark.asyncio
async def test_iter_log_lines_raises_typed_error_on_non_200(monkeypatch):
    """The low-level SSE consumer must surface the server's status code so
    the outer loop can describe it. Prior behavior silently returned, which
    is what caused the original 'silent black box' regression."""
    import httpx

    class _FakeResp:
        def __init__(self, status):
            self.status_code = status

        async def aiter_bytes(self):
            yield b'{"detail": "Job has not been submitted yet"}'

        async def aiter_lines(self):
            if False:
                yield ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, *exc):
            return None

    class _FakeAC:
        def stream(self, *_a, **_k):
            return _FakeResp(400)

        async def __aenter__(self):
            return self

        async def __aexit__(self, *exc):
            return None

    monkeypatch.setattr(httpx, "AsyncClient", lambda *a, **k: _FakeAC())

    client = MagicMock()
    client.api_url = "http://test"
    client._http.headers = {"Authorization": "Bearer t"}

    with pytest.raises(_decorators._SSEConnectError) as exc_info:
        async for _ in _decorators._iter_log_lines("tj_abc", client):
            pass

    assert exc_info.value.status_code == 400
    assert "submitted" in exc_info.value.body
