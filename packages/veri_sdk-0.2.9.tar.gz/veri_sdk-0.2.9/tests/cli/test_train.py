"""Tests for the @training_job decorator and `veri train` CLI command.

We never hit the network here — the SDK Client is monkeypatched with a stub
that records calls and returns fake IDs. The full upload→submit→wait path
is exercised end-to-end against the stub.
"""

from __future__ import annotations

import os
import subprocess
import sys
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import pytest
import respx
from typer.testing import CliRunner

from veri_sdk import Client, training_job
from veri_sdk.cli.main import app
from veri_sdk._decorators import (
    _LOCAL_ENTRYPOINTS,
    _TRAINING_JOBS,
    _iter_log_lines,
    _log_stream_loop,
    _portable_source,
)


runner = CliRunner()


@pytest.fixture(autouse=True)
def _reset_registries():
    """The decorator appends to module-level registries; isolate tests."""
    _TRAINING_JOBS.clear()
    _LOCAL_ENTRYPOINTS.clear()
    yield
    _TRAINING_JOBS.clear()
    _LOCAL_ENTRYPOINTS.clear()


# --- decorator behavior ------------------------------------------------------


def test_decorator_stores_config_without_running():
    @training_job(
        base_model="m", dataset="ds_x", gpu_type="A100-80GB", gpu_count=1,
    )
    def my_reward(completions, answer, **kwargs):
        return [1.0]

    assert my_reward.config["base_model"] == "m"
    assert my_reward.config["dataset"] == "ds_x"
    assert my_reward.config["output_name"] == "my_reward"
    assert my_reward.config["reward_name"] == "my_reward"


def test_decorated_function_is_transparently_callable():
    @training_job(
        base_model="m", dataset="ds_x", gpu_type="A100-80GB", gpu_count=1,
    )
    def reward(completions, answer, **kwargs):
        return [42.0 for _ in completions]

    assert reward([{"content": "x"}], answer=["y"]) == [42.0]
    assert reward.local([{"content": "x"}], answer=["y"]) == [42.0]


def test_use_unsloth_with_multi_gpu_rejected_at_decorator_time():
    """Unsloth's upstream multi-GPU support is preliminary and we haven't
    wired the DDP glue — opting in on >1 GPU would either silently waste GPUs
    or crash mid-training. Fail loud at decoration so the user fixes it
    before submission (not 10 min into a cold install)."""
    import pytest as _pytest

    with _pytest.raises(ValueError, match="use_unsloth"):
        @training_job(
            base_model="m", dataset="ds_x",
            gpu_type="A100-80GB", gpu_count=2,
            hyperparameters={"use_unsloth": True},
        )
        def _reward(completions, answer, **kwargs):  # pragma: no cover
            return [1.0]


def test_use_unsloth_with_single_gpu_allowed():
    """Single-GPU + Unsloth is the supported path — typically used for big
    models (~14B+) that need the VRAM optimization."""
    @training_job(
        base_model="m", dataset="ds_x",
        gpu_type="A100-80GB", gpu_count=1,
        hyperparameters={"use_unsloth": True},
    )
    def reward(completions, answer, **kwargs):
        return [1.0]

    assert reward.config["hyperparameters"]["use_unsloth"] is True


def test_unsloth_off_by_default():
    """Default (no flag set) must NOT enable unsloth — the upstream torch.compile
    GRPO shape bug (unsloth #3069, open/no-fix) hit prod on job 2a85626753ac.
    Vanilla TRL is the stable default."""
    @training_job(
        base_model="m", dataset="ds_x",
        gpu_type="A100-80GB", gpu_count=1,
        hyperparameters={"learning_rate": 1e-6},
    )
    def reward(completions, answer, **kwargs):
        return [1.0]

    # The decorator doesn't insert a default; the runner reads
    # hyperparameters.get("use_unsloth", False). Both behaviors must hold.
    assert "use_unsloth" not in reward.config["hyperparameters"]


def test_decorator_registers_for_cli_discovery():
    @training_job(
        base_model="m", dataset="ds_x", gpu_type="A100-80GB", gpu_count=1,
    )
    def reward(completions, answer, **kwargs):
        return [1.0]

    assert len(_TRAINING_JOBS) == 1
    assert _TRAINING_JOBS[0] is reward


def test_decorator_carries_dataset_config_in_cfg():
    """dataset_config kwarg lands in the decorator's stored cfg dict, so
    _resolve_dataset can forward it as huggingface_config.config_name when
    auto-connecting an HF dataset. Required for multi-config datasets like
    gsm8k where HF refuses to load without a chosen config (VS-217)."""
    @training_job(
        base_model="m",
        dataset="hf:openai/gsm8k",
        gpu_type="A100-80GB",
        gpu_count=1,
        dataset_config="main",
    )
    def reward(completions, **kwargs):
        return [1.0]

    assert reward.config["dataset_config"] == "main"


def test_decorator_dataset_config_defaults_to_none():
    @training_job(
        base_model="m", dataset="ds_x", gpu_type="A100-80GB", gpu_count=1,
    )
    def reward(completions, **kwargs):
        return [1.0]

    assert reward.config["dataset_config"] is None


# --- portable source generation ---------------------------------------------


def test_portable_source_strips_veri_decorator_and_import(tmp_path: Path):
    script = tmp_path / "fine_tune.py"
    script.write_text(
        textwrap.dedent('''
        from veri_sdk import training_job

        @training_job(
            base_model="m",
            dataset="ds_x",
            gpu_type="A100-80GB",
            gpu_count=1,
        )
        def reward(completions, answer, **kwargs):
            return [1.0]
        ''').strip()
    )

    portable = _portable_source(script)

    assert "training_job" not in portable
    assert "from veri_sdk" not in portable
    assert "import veri" not in portable
    assert "def reward" in portable
    assert "return [1.0]" in portable


def test_portable_source_preserves_unrelated_imports_and_decorators(tmp_path: Path):
    script = tmp_path / "fine_tune.py"
    script.write_text(
        textwrap.dedent('''
        import re
        from functools import lru_cache
        from veri_sdk import training_job

        @lru_cache
        def normalize(text):
            return text.strip()

        @training_job(
            base_model="m", dataset="ds_x", gpu_type="A100", gpu_count=1,
        )
        def reward(completions, answer, **kwargs):
            return [1.0]
        ''').strip()
    )

    portable = _portable_source(script)

    assert "import re" in portable
    assert "from functools import lru_cache" in portable
    assert "@lru_cache" in portable
    assert "from veri_sdk" not in portable


# --- CLI: training_job discovery ---------------------------------------------


@dataclass
class _StubDataset:
    id: str


@dataclass
class _StubRewardFn:
    id: str


@dataclass
class _StubJob:
    id: str
    status: str
    dashboard_url: str | None
    download_url: str | None
    error: dict | None
    cost_usd: float | None


class _StubClient:
    """Minimal stand-in for veri_sdk.Client that records calls."""

    def __init__(self):
        self.calls: list[tuple[str, dict]] = []
        self.datasets = self  # so client.datasets.connect works
        self.reward_functions = self  # client.reward_functions.upload
        self.training_jobs = self  # client.training_jobs.create/get

    def connect(self, **kwargs):
        self.calls.append(("datasets.connect", kwargs))
        return _StubDataset(id="ds_abc")

    def upload(self, path, *, name, format):
        self.calls.append(
            ("reward_functions.upload", {"path": path, "name": name, "format": format})
        )
        return _StubRewardFn(id="rf_abc")

    def create(self, **kwargs):
        self.calls.append(("training_jobs.create", kwargs))
        return _StubJob(
            id="tj_abc",
            status="completed",  # skip the wait loop entirely
            dashboard_url="https://veri.studio/jobs/tj_abc",
            download_url=None,
            error=None,
            cost_usd=0.5,
        )

    def get(self, job_id):
        self.calls.append(("training_jobs.get", {"job_id": job_id}))
        return _StubJob(
            id=job_id, status="completed", dashboard_url="https://veri.studio/jobs/tj_abc",
            download_url=None, error=None, cost_usd=0.5,
        )


def _write_user_script(tmp_path: Path, body: str) -> Path:
    script = tmp_path / "fine_tune.py"
    script.write_text(textwrap.dedent(body).strip() + "\n")
    return script


def test_veri_train_invokes_decorator(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    stub = _StubClient()
    monkeypatch.setattr("veri_sdk._decorators.Client", lambda: stub)

    script = _write_user_script(
        tmp_path,
        '''
        from veri_sdk import training_job

        @training_job(
            base_model="Qwen/Qwen2.5-0.5B-Instruct",
            dataset="hf:openai/gsm8k",
            dataset_config="main",
            column_mapping={"question": "prompt"},
            gpu_type="A100-80GB",
            gpu_count=1,
            hyperparameters={"max_steps": 50},
        )
        def reward(completions, answer, **kwargs):
            return [0.5 for _ in completions]
        ''',
    )

    result = runner.invoke(app, ["train", str(script)])
    assert result.exit_code == 0, result.stdout + result.stderr

    call_names = [c[0] for c in stub.calls]
    assert "datasets.connect" in call_names
    assert "reward_functions.upload" in call_names
    assert "training_jobs.create" in call_names

    create_kwargs = next(c[1] for c in stub.calls if c[0] == "training_jobs.create")
    assert create_kwargs["base_model"] == "Qwen/Qwen2.5-0.5B-Instruct"
    assert create_kwargs["gpu_type"] == "A100-80GB"
    assert create_kwargs["hyperparameters"] == {"max_steps": 50}

    # dataset_config must be plumbed into the connect call so the worker
    # sees an HF config name. Without it, multi-config datasets like
    # gsm8k blow up at load time (VS-217).
    connect_kwargs = next(c[1] for c in stub.calls if c[0] == "datasets.connect")
    assert connect_kwargs["huggingface_config"]["config_name"] == "main"


def test_veri_train_errors_when_no_decorator(tmp_path: Path):
    script = _write_user_script(tmp_path, "x = 1")
    result = runner.invoke(app, ["train", str(script)])
    assert result.exit_code != 0
    assert "No @training_job decorator" in (result.stdout + result.stderr)


def test_veri_train_requires_function_arg_when_ambiguous(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr("veri_sdk._decorators.Client", lambda: _StubClient())
    script = _write_user_script(
        tmp_path,
        '''
        from veri_sdk import training_job

        @training_job(base_model="m", dataset="ds_x", gpu_type="A100", gpu_count=1)
        def reward_a(completions, answer, **kwargs):
            return [1.0]

        @training_job(base_model="m", dataset="ds_x", gpu_type="A100", gpu_count=1)
        def reward_b(completions, answer, **kwargs):
            return [1.0]
        ''',
    )

    result = runner.invoke(app, ["train", str(script)])
    assert result.exit_code != 0
    combined = (result.stdout + result.stderr).replace("\n", " ")
    assert "Multiple @training_job" in combined
    assert "--function" in combined


def test_unrun_hint_fires_for_direct_python_invocation(tmp_path: Path):
    """`python script.py` (i.e. fn.__module__ == '__main__') without invoking
    .train()/.local() should print a stderr hint pointing to `veri train`."""
    script = _write_user_script(
        tmp_path,
        '''
        from veri_sdk import training_job

        @training_job(base_model="m", dataset="ds_x", gpu_type="A100", gpu_count=1)
        def reward(completions, answer, **kwargs):
            return [1.0]
        ''',
    )

    # Prefer the sdk venv's python over sys.executable — `uv run pytest` may
    # be running under a parent Python (miniconda/system) that doesn't have
    # veri_sdk installed; same workaround as the doc-test harness.
    here = Path(__file__).resolve()
    sdk_venv = here.parents[2] / ".venv" / "bin" / "python3"
    python = str(sdk_venv) if sdk_venv.exists() else sys.executable
    result = subprocess.run(
        [python, str(script)],
        capture_output=True,
        text=True,
        env={**os.environ, "VERI_CLI_TRAIN": ""},  # explicitly NOT CLI-driven
    )

    assert result.returncode == 0
    assert "registered a @training_job but never ran it" in result.stderr
    assert "veri train" in result.stderr


def test_unrun_hint_suppressed_when_cli_drives(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    """The CLI sets VERI_CLI_TRAIN=1 before importing the user script,
    which suppresses the hint."""
    monkeypatch.setattr("veri_sdk._decorators.Client", lambda: _StubClient())
    script = _write_user_script(
        tmp_path,
        '''
        from veri_sdk import training_job

        @training_job(base_model="m", dataset="ds_x", gpu_type="A100", gpu_count=1)
        def reward(completions, answer, **kwargs):
            return [1.0]
        ''',
    )

    result = runner.invoke(app, ["train", str(script)])

    assert result.exit_code == 0, result.stdout + result.stderr
    combined = result.stdout + result.stderr
    assert "registered a @training_job but never ran it" not in combined


def test_veri_train_local_entrypoint_overrides_auto_run(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    """When @local_entrypoint exists, the CLI calls it instead of auto-running
    the training_job. The entrypoint can then drive the flow manually."""
    stub = _StubClient()
    monkeypatch.setattr("veri_sdk._decorators.Client", lambda: stub)

    script = _write_user_script(
        tmp_path,
        '''
        from veri_sdk import training_job, local_entrypoint

        @training_job(base_model="m", dataset="ds_x", gpu_type="A100", gpu_count=1)
        def reward(completions, answer, **kwargs):
            return [1.0]

        @local_entrypoint()
        def main():
            # explicitly DON'T call .train() — just demonstrate the override worked
            print("entrypoint ran")
        ''',
    )

    result = runner.invoke(app, ["train", str(script)])
    assert result.exit_code == 0, result.stdout + result.stderr
    assert "entrypoint ran" in result.stdout
    # The auto-run path should NOT have called the SDK at all.
    assert stub.calls == []


# -------------------- log streaming (Plan B) --------------------


def _make_test_client(monkeypatch: pytest.MonkeyPatch) -> Client:
    """Construct a Client without touching the real config file."""
    monkeypatch.setattr(
        "veri_sdk.cli.utils.config.load",
        lambda: {"api_key": "vk_test", "api_url": "https://api.veri.test"},
    )
    return Client()


@pytest.mark.asyncio
async def test_iter_log_lines_parses_sse_data_frames(monkeypatch: pytest.MonkeyPatch):
    """SSE frames look like `data: <payload>\\n\\n`. The iterator should
    strip the prefix and yield only the payload, one event at a time."""
    client = _make_test_client(monkeypatch)
    body = "data: line one\n\ndata: line two\n\ndata: [Job completed]\n\n"
    with respx.mock(base_url="https://api.veri.test") as mock:
        mock.get("/v1/training_jobs/tj_x/logs").mock(
            return_value=httpx.Response(
                200, headers={"content-type": "text/event-stream"}, content=body,
            )
        )
        out = []
        async for line in _iter_log_lines("tj_x", client):
            out.append(line)
    assert out == ["line one", "line two", "[Job completed]"]


@pytest.mark.asyncio
async def test_iter_log_lines_raises_typed_error_on_non_200(monkeypatch: pytest.MonkeyPatch):
    """If the server returns 4xx/5xx, the iterator must raise a typed
    `_SSEConnectError` carrying the status code. The reconnect loop in
    `_log_stream_loop` uses that code to surface a one-line diagnostic
    instead of retrying silently (the prior 'black box' bug)."""
    from veri_sdk._decorators import _SSEConnectError

    client = _make_test_client(monkeypatch)
    with respx.mock(base_url="https://api.veri.test") as mock:
        mock.get("/v1/training_jobs/tj_x/logs").mock(
            return_value=httpx.Response(404)
        )
        with pytest.raises(_SSEConnectError) as exc_info:
            async for _ in _iter_log_lines("tj_x", client):
                pass
    assert exc_info.value.status_code == 404


@pytest.mark.asyncio
async def test_log_stream_loop_stops_on_terminal_sentinel(
    monkeypatch: pytest.MonkeyPatch,
):
    """Server emits `[Job completed]` (or failed/cancelled) when the run
    terminates. The loop should consume it and return without printing
    the sentinel as a worker log line."""
    client = _make_test_client(monkeypatch)
    body = "data: training step 1\n\ndata: training step 2\n\ndata: [Job completed]\n\n"
    printed: list[str] = []

    async def fake_safe_log(msg: str) -> None:
        printed.append(msg)

    job = _StubJob(
        id="tj_x", status="running", dashboard_url=None,
        download_url=None, error=None, cost_usd=None,
    )

    with respx.mock(base_url="https://api.veri.test") as mock:
        mock.get("/v1/training_jobs/tj_x/logs").mock(
            return_value=httpx.Response(
                200, headers={"content-type": "text/event-stream"}, content=body,
            )
        )
        await _log_stream_loop(job, client, safe_log=fake_safe_log)

    assert printed == ["[worker] training step 1", "[worker] training step 2"], (
        f"Expected worker lines printed (and sentinel NOT printed); got {printed!r}"
    )
