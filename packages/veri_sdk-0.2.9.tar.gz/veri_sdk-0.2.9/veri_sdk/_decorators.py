"""Decorator API for one-shot training runs.

Modal-style: `@training_job` is **registration only**. It records configuration
alongside the user's reward function and does nothing at import time — no
network, no Client(). Submission, polling, and download happen via
`veri train <script.py>` (the canonical entry point) or `.train()` (the
programmatic equivalent).

For deployments and evals, use the SDK directly. Their lifecycles don't fit
the single-shot decorator shape.
"""

from __future__ import annotations

import ast
import asyncio
import atexit
import functools
import hashlib
import inspect
import os
import random
import sys
import tempfile
from pathlib import Path
from typing import Any, AsyncIterator, Callable, Optional

import httpx

from .client import Client, TrainingJob, VeriError, VeriServerError

# Registries populated as the user's script is imported. The CLI reads them
# to decide what to run. Module-level state is the right shape here — every
# user script runs in its own process, so there's no isolation concern.
_TRAINING_JOBS: list["TrainingJobFunction"] = []
_LOCAL_ENTRYPOINTS: list[Callable[..., Any]] = []

# Set by `veri train` before importing the user's script. When set, the
# "you imported but didn't invoke" hint suppresses, because the CLI itself
# is doing the orchestration. Direct `python script.py` invocation leaves
# this unset and gets the hint.
_CLI_DRIVING_ENV = "VERI_CLI_TRAIN"


class TrainingJobFunction:
    """Wrapper around a user's reward function that carries training config.

    Callable transparently — the trainer-side process calls `reward(...)` and
    it dispatches to the underlying function. Local tests can use `.local(...)`
    for an explicit "I am not submitting a job" call.
    """

    def __init__(self, fn: Callable[..., Any], config: dict[str, Any]) -> None:
        self.fn = fn
        self.config = config
        self._invoked = False  # tracks whether user ran train/local/__call__
        functools.update_wrapper(self, fn)
        _TRAINING_JOBS.append(self)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        self._invoked = True
        return self.fn(*args, **kwargs)

    def local(self, *args: Any, **kwargs: Any) -> Any:
        """Run the reward function in-process. Same as __call__, kept for clarity."""
        self._invoked = True
        return self.fn(*args, **kwargs)

    def train(
        self,
        *,
        client: Optional[Client] = None,
        verbose: bool = True,
        detach: bool = False,
    ) -> TrainingJob:
        """Submit the training job.

        Default: block until completion, with SDK ownership (Ctrl+C cancels
        the GPU within ~5s, network drop reaps within heartbeat_timeout_seconds).

        `detach=True`: submit and return immediately, without streaming. The
        server treats the job as unowned — it runs to natural completion or
        until the user explicitly cancels. Equivalent to `veri train --detach`.

        `veri train <script.py>` calls this internally.
        """
        self._invoked = True
        return _run_training_job(
            self, client or Client(), verbose=verbose, detach=detach
        )


def training_job(
    *,
    base_model: str,
    dataset: str,
    gpu_type: str,
    gpu_count: int,
    split: str = "train",
    dataset_config: Optional[str] = None,
    column_mapping: Optional[dict[str, str]] = None,
    method: str = "grpo",
    hyperparameters: Optional[dict[str, Any]] = None,
    output_name: Optional[str] = None,
    reward_name: Optional[str] = None,
    reward_format: str = "trl",
    volume: Optional[str] = None,
) -> Callable[[Callable[..., Any]], TrainingJobFunction]:
    """Register a reward function as a single-shot training job.

    Metadata-only at import time. Run with `veri train <script.py>` or by
    calling `.train()` on the decorated function.

    Args:
        base_model: HF model identifier, e.g. "Qwen/Qwen2.5-0.5B-Instruct".
        dataset: Either "hf:<org>/<name>" to auto-connect a Hugging Face dataset,
            or "ds_<id>" to reference an existing Veri dataset.
        gpu_type: GPU SKU, e.g. "A100-80GB".
        gpu_count: Number of GPUs.
        split: HF split when dataset is "hf:..." Default "train".
        dataset_config: HF dataset config name (a.k.a. subset) when dataset is
            "hf:..." Required for multi-config datasets like gsm8k ("main" or
            "socratic"). Leave None for single-config datasets.
        column_mapping: HF column → Veri schema mapping when dataset is "hf:..."
            e.g. {"question": "prompt", "answer": "label"}.
        method: Training method. Default "grpo".
        hyperparameters: Method-specific hyperparameters.
        output_name: Output checkpoint name. Defaults to the function name.
        reward_name: Uploaded reward function name. Defaults to the function name.
        reward_format: Reward function format. Default "trl".
    """

    hp = dict(hyperparameters or {})
    # Fail loud at decorator time if the user opts into Unsloth on >1 GPU.
    # Unsloth's multi-GPU is still "preliminary" upstream and we haven't
    # wired the DDP/Accelerate glue — running it would either silently fall
    # back to one GPU (paying for unused devices) or crash at training step 1.
    # Better to surface this before submission than after a 10-min cold install.
    if hp.get("use_unsloth") and gpu_count > 1:
        raise ValueError(
            f"use_unsloth=True is not supported with gpu_count={gpu_count}. "
            "Unsloth currently has only preliminary multi-GPU support upstream. "
            "Either drop use_unsloth (vanilla TRL works on multi-GPU) or set "
            "gpu_count=1."
        )

    def decorator(fn: Callable[..., Any]) -> TrainingJobFunction:
        config = {
            "base_model": base_model,
            "dataset": dataset,
            "gpu_type": gpu_type,
            "gpu_count": gpu_count,
            "split": split,
            "dataset_config": dataset_config,
            "column_mapping": dict(column_mapping or {}),
            "method": method,
            "hyperparameters": hp,
            "output_name": output_name or fn.__name__,
            "reward_name": reward_name or fn.__name__,
            "reward_format": reward_format,
            "volume": volume,
        }
        return TrainingJobFunction(fn, config)

    return decorator


def _emit_unrun_hint() -> None:
    """At-exit hint: warn users who ran `python script.py` directly.

    Fires only when:
      * The CLI didn't drive the import (VERI_CLI_TRAIN unset).
      * At least one @training_job was defined in the __main__ module.
      * No `.train()`, `.local()`, or `__call__` was made on it.

    Anything else — pytest imports, `veri train`, deliberate `.local()`
    test invocations — leaves this silent.
    """
    if os.environ.get(_CLI_DRIVING_ENV) == "1":
        return
    main_jobs = [j for j in _TRAINING_JOBS if j.fn.__module__ == "__main__"]
    if not main_jobs:
        return
    if any(j._invoked for j in main_jobs):
        return
    script = sys.argv[0] if sys.argv and sys.argv[0] else "<script.py>"
    sys.stderr.write(
        f"\nNote: {script!r} registered a @training_job but never ran it.\n"
        f"  To submit:  veri train {script}\n"
        f"  To test:    use `reward.local(...)` for in-process invocation.\n"
    )


atexit.register(_emit_unrun_hint)


def local_entrypoint() -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Mark a function as the local entry point for `veri train`.

    If a script defines a @local_entrypoint, the CLI calls it instead of
    auto-running the @training_job. The entrypoint can then call `.train()`,
    `.local()`, `.download()`, etc. in whatever sequence the user wants.
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        _LOCAL_ENTRYPOINTS.append(fn)
        return fn

    return decorator


# --- portable source generation ----------------------------------------------


def _is_veri_decorator(node: ast.expr) -> bool:
    """True if `node` is `@training_job(...)` or `@local_entrypoint(...)`,
    bare or attribute-style (veri.training_job, veri_sdk.training_job)."""
    if isinstance(node, ast.Call):
        node = node.func
    if isinstance(node, ast.Name):
        return node.id in ("training_job", "local_entrypoint")
    if isinstance(node, ast.Attribute):
        return node.attr in ("training_job", "local_entrypoint")
    return False


def _is_veri_import(node: ast.stmt) -> bool:
    """True if the statement imports from veri or veri_sdk."""
    if isinstance(node, ast.Import):
        return any(alias.name in ("veri", "veri_sdk") for alias in node.names)
    if isinstance(node, ast.ImportFrom):
        return node.module in ("veri", "veri_sdk")
    return False


def _portable_source(file_path: Path) -> str:
    """Strip veri-specific decorators and imports from the user's script.

    The result is a Python file the trainer can run without veri-sdk
    installed: the decorated `def reward(...)` becomes a plain definition
    and `from veri_sdk import training_job` lines disappear.
    """
    source = file_path.read_text()
    tree = ast.parse(source)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            node.decorator_list = [
                d for d in node.decorator_list if not _is_veri_decorator(d)
            ]

    tree.body = [s for s in tree.body if not _is_veri_import(s)]

    return ast.unparse(tree)


# --- orchestration -----------------------------------------------------------


def _run_training_job(
    wrapper: TrainingJobFunction,
    client: Client,
    *,
    verbose: bool,
    detach: bool = False,
) -> TrainingJob:
    cfg = wrapper.config
    source_file = inspect.getsourcefile(wrapper.fn)
    if not source_file:
        raise RuntimeError(
            f"Cannot locate source for {wrapper.fn.__name__}. The @training_job "
            "decorator requires the function to live in a file on disk."
        )
    src_path = Path(source_file)

    log = print if verbose else (lambda *_a, **_k: None)

    log(f"[1/4] Bundling reward function from {src_path.name}...")
    portable = _portable_source(src_path)
    tmp = tempfile.NamedTemporaryFile(
        "w", suffix=".py", delete=False, prefix=f"{cfg['reward_name']}_"
    )
    try:
        tmp.write(portable)
        tmp.close()
        log(f"[2/4] Uploading reward function (name={cfg['reward_name']})...")
        reward_fn = client.reward_functions.upload(
            tmp.name, name=cfg["reward_name"], format=cfg["reward_format"]
        )
        log(f"      reward_fn.id = {reward_fn.id}")
    finally:
        Path(tmp.name).unlink(missing_ok=True)

    log(f"[3/4] Resolving dataset {cfg['dataset']!r}...")
    dataset_id = _resolve_dataset(client, cfg, log=log)

    log(
        f"[4/4] Submitting training job ({cfg['base_model']}, "
        f"{cfg['gpu_type']} x{cfg['gpu_count']})..."
    )
    job = client.training_jobs.create(
        base_model=cfg["base_model"],
        dataset_id=dataset_id,
        reward_function_id=reward_fn.id,
        output_name=cfg["output_name"],
        method=cfg["method"],
        hyperparameters=cfg["hyperparameters"],
        gpu_type=cfg["gpu_type"],
        gpu_count=cfg["gpu_count"],
        volume=cfg.get("volume"),
        requires_heartbeat=not detach,
    )
    log(f"      job.id = {job.id}")

    if detach:
        # Server-owned run — exit without streaming. The job continues to
        # natural completion or until the user cancels via the dashboard
        # or `veri jobs cancel`. requires_heartbeat=False (above) tells
        # the reconciler not to reap this job for missing heartbeats.
        if job.dashboard_url:
            log(f"      dashboard: {job.dashboard_url}")
        log(f"      detached — job continues server-side. Cancel with: veri jobs cancel {job.id}")
        return job

    return _stream_wait(job, client, log=log)


def _resolve_dataset(client: Client, cfg: dict[str, Any], *, log: Callable) -> str:
    ds = cfg["dataset"]
    if ds.startswith("hf:"):
        hf_name = ds[len("hf:") :]
        dataset_config = cfg.get("dataset_config")
        # Name datasets deterministically so re-running the same script reuses
        # the same dataset record (server should treat connect as idempotent).
        # dataset_config goes into the digest too — gsm8k:main and gsm8k:socratic
        # are different datasets and must not collide on the same record.
        digest = hashlib.sha256(
            f"{hf_name}|{dataset_config}|{cfg['split']}|{cfg['column_mapping']}".encode()
        ).hexdigest()[:8]
        hf_config: dict[str, Any] = {
            "split": cfg["split"],
            "column_mapping": cfg["column_mapping"],
        }
        if dataset_config:
            hf_config["config_name"] = dataset_config
        dataset = client.datasets.connect(
            name=f"{cfg['reward_name']}-{digest}",
            source_type="hf",
            huggingface_dataset=hf_name,
            huggingface_config=hf_config,
        )
        log(f"      dataset.id = {dataset.id} (connected from {hf_name!r})")
        return dataset.id
    if ds.startswith("ds_") or len(ds) == 12:  # ds_ prefix or bare 12-char id
        log(f"      using existing dataset {ds}")
        return ds
    raise ValueError(
        f"Unrecognized dataset {ds!r}. Use 'hf:<org>/<name>' to auto-connect "
        "a Hugging Face dataset, or 'ds_<id>' to reference an existing one."
    )


_TERMINAL_STATUSES = ("completed", "failed", "cancelled")
_STATUS_POLL_SECONDS = 15
_HEARTBEAT_INTERVAL_SECONDS = 30  # VS-218 Part D-3 — paired with server timeout (default 300s)
_LOG_HEARTBEAT_INTERVAL = 30      # VS-215 — synthetic line every N seconds of log silence
_LOG_RECONNECT_INITIAL = 1.0      # VS-215 reconnect: SSE drops or returns early during the
_LOG_RECONNECT_MAX = 5.0          # pre-provisioning window (400 "not submitted yet"). Capped
                                  # low because re-attempts are cheap and we want fast recovery.


class _SSEConnectError(Exception):
    """Server returned non-200 on the SSE connect. Carries status code so the
    reconnect loop can surface a useful diagnostic to the user instead of
    silently retrying forever (the prior behavior — VS-215 follow-up)."""

    def __init__(self, status_code: int, body: str = ""):
        self.status_code = status_code
        self.body = body
        super().__init__(f"SSE connect returned {status_code}")


def _describe_sse_error(status_code: int, job_status: Optional[str]) -> str:
    """Map a non-200 SSE response to a one-line human description."""
    if status_code == 400:
        return f"job still {job_status or 'pending'} — waiting for runner"
    if status_code == 404:
        return "job not found"
    if status_code in (401, 403):
        return "auth error — check VERI_API_KEY"
    if 500 <= status_code < 600:
        return f"server error ({status_code})"
    return f"unexpected status {status_code}"


def _stream_wait(
    job: TrainingJob, client: Client, *, log: Callable
) -> TrainingJob:
    """Sync entry point: bridge to the async streamer via asyncio.run.

    Two concurrent tasks run inside the loop — one polls the control plane
    for status transitions, the other consumes the worker's stdout via the
    server's SSE log endpoint and prints lines as they arrive. Output is
    serialized through an asyncio.Lock so worker stdout doesn't interleave
    mid-line with status updates.

    SIGINT (Ctrl+C) is treated as "stop the GPU now" — VS-218 Part B. We
    catch KeyboardInterrupt from asyncio.run, fire a best-effort cancel API
    call (its failure mode is the heartbeat-timeout reap that Part D adds),
    print one-line status, and return cleanly so the caller sees a normal
    `cancelled` job instead of a traceback. Users who want server-owned
    runs opt in with `veri train --detach`.
    """
    try:
        return asyncio.run(_stream_wait_async(job, client, log=log))
    except KeyboardInterrupt:
        try:
            client.training_jobs.cancel(job.id)
        except Exception:
            # Best-effort. Part D's heartbeat-timeout reaps the pod if the
            # cancel call itself drops on the floor (network blip, auth
            # expiry, server returning "job already terminal").
            pass
        log("")
        log("      ^C — stopped, pod is terminating.")
        log(f"      Job:  {job.id}")
        log("      Tip:  pass `--detach` next time if you want the job to keep running.")
        job.status = "cancelled"
        return job


async def _stream_wait_async(
    job: TrainingJob, client: Client, *, log: Callable
) -> TrainingJob:
    print_lock = asyncio.Lock()

    async def safe_log(msg: str) -> None:
        async with print_lock:
            log(msg)

    await safe_log("      waiting for completion (polls every 15s)...")

    status_task = asyncio.create_task(
        _status_loop(job, client, safe_log=safe_log)
    )
    log_task = asyncio.create_task(
        _log_stream_loop(job, client, safe_log=safe_log)
    )
    heartbeat_task = asyncio.create_task(
        _heartbeat_loop(job, client, safe_log=safe_log)
    )

    try:
        await status_task
    finally:
        for task in (log_task, heartbeat_task):
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    if job.status == "completed":
        cost = (
            f"${job.cost_usd:.4f}"
            if job.cost_usd is not None
            else "(not reported)"
        )
        await safe_log(f"      cost: {cost}")
    else:
        await safe_log(f"      error: {job.error_message}")

    return job


async def _status_loop(
    job: TrainingJob, client: Client, *, safe_log: Callable
) -> None:
    """Poll status until terminal. Mutates `job` in place on each refresh.

    Refreshes `cost_usd` here in addition to status/url so completed jobs
    have the final cost populated when the wait returns — the SDK's own
    `TrainingJob.wait()` misses that.
    """
    last_status: Optional[str] = None
    url_printed = False
    while job.status not in _TERMINAL_STATUSES:
        if not url_printed and job.dashboard_url:
            await safe_log(f"      dashboard: {job.dashboard_url}")
            url_printed = True
        if job.status != last_status:
            await safe_log(f"      status: {job.status}")
            last_status = job.status
        await asyncio.sleep(_STATUS_POLL_SECONDS)
        refreshed = await _poll_with_retry(client, job.id, safe_log=safe_log)
        job.status = refreshed.status
        job.dashboard_url = refreshed.dashboard_url
        job.download_url = refreshed.download_url
        job.error = refreshed.error
        job.cost_usd = refreshed.cost_usd

    if job.status != last_status:
        await safe_log(f"      status: {job.status}")


async def _heartbeat_loop(
    job: TrainingJob, client: Client, *, safe_log: Callable
) -> None:
    """VS-218 Part D-3 — keep the server's heartbeat ownership counter fresh.

    Pings POST /heartbeat every ~30s while the job is non-terminal. A
    single failed ping is silently swallowed — the server's reconciler
    timeout (default 300s) is ~10x our interval, so any transient blip
    has plenty of recovery room. The real ownership signal is the
    aggregate liveness of the SDK process: if it dies, pings stop, and
    the reconciler reaps the pod.
    """
    while job.status not in _TERMINAL_STATUSES:
        try:
            await asyncio.to_thread(client.training_jobs.heartbeat, job.id)
        except Exception:
            pass
        await asyncio.sleep(_HEARTBEAT_INTERVAL_SECONDS)


_POLL_BACKOFF_INITIAL = 1.0
_POLL_BACKOFF_MAX = 30.0


async def _poll_with_retry(
    client: Client, job_id: str, *, safe_log: Callable
) -> TrainingJob:
    """Resilient polling — retry transient errors with backoff.

    A multi-hour training run survives transient API blips (gateway 502s,
    upstream-induced 60s ReadTimeouts, brief network drops). We do not bound
    retry attempts because the user has already chosen to wait for the job —
    losing the local stream to a momentary blip is strictly worse than
    waiting an extra few seconds. The job state is server-authoritative
    (re-attach by job id), so reconnecting at any point is safe.

    Non-transient errors (4xx, auth) propagate — a permanent failure must
    not hang the loop forever. The trade-off: a real auth drift terminates
    the local stream cleanly; the user still sees job state on the dashboard.
    """
    delay = _POLL_BACKOFF_INITIAL
    while True:
        try:
            return await asyncio.to_thread(client.training_jobs.get, job_id)
        except (
            httpx.TimeoutException,
            httpx.NetworkError,
            httpx.RemoteProtocolError,
        ) as exc:
            kind = type(exc).__name__
        except VeriServerError as exc:
            # VS-218 Part A converted 5xx to VeriServerError (used to be
            # httpx.HTTPStatusError). Retry it — a multi-hour training run
            # shouldn't die because the API had a 30s blip.
            kind = f"server: {exc!s:.80}"
        except VeriError:
            # 4xx — auth / not-found / bad-request — propagate; not transient.
            raise

        jittered = delay + random.uniform(0, delay * 0.25)
        await safe_log(
            f"      [warn] transient: {kind} — retrying in {jittered:.0f}s"
        )
        await asyncio.sleep(jittered)
        delay = min(delay * 2, _POLL_BACKOFF_MAX)


async def _log_stream_loop(
    job: TrainingJob, client: Client, *, safe_log: Callable
) -> None:
    """Consume the server's SSE log endpoint and print each line as it arrives.

    Server emits `data: <line>\\n\\n` per log line; terminal sentinels like
    `[Job completed]` / `[Log stream timeout]` signal end-of-stream. Any
    network or auth failure is swallowed silently — log streaming is
    best-effort decoration, the status loop is the source of truth for
    completion.

    Reconnects until the job is terminal. The initial SSE connect can land
    before `runner_id` is assigned (server returns 400 "Job has not been
    submitted yet") — without retry, the consumer goes silent for the whole
    run even though bootstrap.log fills up moments later. Reconnect also
    rescues mid-stream drops without losing tail visibility.

    VS-215: if no log line arrives within _LOG_HEARTBEAT_INTERVAL, print a
    synthetic "still booting" line so the terminal doesn't look frozen
    during the 10-min cold-install window. Stops as soon as the worker
    starts streaming real logs.
    """
    last_line_at = asyncio.get_event_loop().time()

    async def _emit_heartbeats() -> None:
        while True:
            await asyncio.sleep(_LOG_HEARTBEAT_INTERVAL)
            elapsed = asyncio.get_event_loop().time() - last_line_at
            if elapsed >= _LOG_HEARTBEAT_INTERVAL:
                await safe_log(
                    f"      [heartbeat] still booting — {int(elapsed)}s without "
                    f"worker output (cold installs typically take 8-12 min)"
                )

    hb_task = asyncio.create_task(_emit_heartbeats())
    backoff = _LOG_RECONNECT_INITIAL
    last_diag_msg: Optional[str] = None
    saw_any_line = False
    try:
        while job.status not in _TERMINAL_STATUSES:
            saw_terminal_sentinel = False
            try:
                async for line in _iter_log_lines(job.id, client):
                    last_line_at = asyncio.get_event_loop().time()
                    # Reset backoff on healthy traffic so a mid-stream drop
                    # reconnects fast instead of staying at the max delay.
                    backoff = _LOG_RECONNECT_INITIAL
                    if not saw_any_line:
                        if last_diag_msg is not None:
                            await safe_log("      [stream] connected — logs flowing")
                        saw_any_line = True
                        last_diag_msg = None
                    if line.startswith("[Job ") or line == "[Log stream timeout]":
                        saw_terminal_sentinel = True
                        break
                    await safe_log(f"[worker] {line}")
            except asyncio.CancelledError:
                return
            except _SSEConnectError as exc:
                # Print *once per state change* so the loop doesn't spam
                # the same "still queued" line every 1s during the
                # pre-provisioning window.
                msg = (
                    f"[stream] {exc.status_code} — "
                    f"{_describe_sse_error(exc.status_code, job.status)}"
                )
                if msg != last_diag_msg:
                    await safe_log(f"      {msg}")
                    last_diag_msg = msg
            except (httpx.HTTPError, Exception):
                # Mid-stream drop or unexpected blip — never crash the
                # wait loop; backoff + reconnect.
                pass
            if saw_terminal_sentinel:
                return
            if job.status in _TERMINAL_STATUSES:
                return
            await asyncio.sleep(backoff)
            backoff = min(max(backoff * 2, _LOG_RECONNECT_INITIAL), _LOG_RECONNECT_MAX)
    finally:
        hb_task.cancel()
        try:
            await hb_task
        except asyncio.CancelledError:
            pass


async def _iter_log_lines(
    job_id: str, client: Client
) -> AsyncIterator[str]:
    """Connect to /v1/training_jobs/{id}/logs (SSE) and yield each line.

    Pulls base URL + auth from the existing sync Client. We do not reuse
    `client._http` because it's an httpx.Client (sync); SSE needs the
    async variant.
    """
    auth_header = client._http.headers.get("Authorization", "")
    url = f"{client.api_url.rstrip('/')}/v1/training_jobs/{job_id}/logs"
    headers = {
        "Authorization": auth_header,
        "Accept": "text/event-stream",
    }
    async with httpx.AsyncClient(timeout=None) as ac:
        async with ac.stream("GET", url, headers=headers) as resp:
            if resp.status_code != 200:
                # Read a small slice of the body for diagnostics, then raise
                # a typed error the reconnect loop can describe in one line.
                # Prior behavior silently returned — the user saw nothing
                # while the SDK retried in the background.
                body_bytes = b""
                try:
                    async for chunk in resp.aiter_bytes():
                        body_bytes += chunk
                        if len(body_bytes) >= 512:
                            break
                except Exception:
                    pass
                raise _SSEConnectError(
                    resp.status_code,
                    body_bytes[:512].decode(errors="replace"),
                )
            async for raw in resp.aiter_lines():
                if raw.startswith("data:"):
                    yield raw[5:].lstrip()
