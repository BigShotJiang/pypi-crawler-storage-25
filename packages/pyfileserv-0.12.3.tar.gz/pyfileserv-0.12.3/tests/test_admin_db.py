"""管理员权限控制 - DatabaseUserStore 测试"""
from datetime import datetime
from unittest.mock import MagicMock, patch

import pytest

from file_server.db import DatabaseUserStore, DatabaseConnection


@pytest.fixture
def mock_db():
    """创建模拟数据库连接"""
    with patch('file_server.db.psycopg2'):
        db = MagicMock(spec=DatabaseConnection)
        return db


@pytest.fixture
def db_user_store(mock_db):
    """创建 DatabaseUserStore 实例"""
    return DatabaseUserStore(mock_db)


class TestDatabaseUserStoreAdmin:
    """DatabaseUserStore 管理员功能测试"""

    def test_add_user_default_not_admin(self, db_user_store, mock_db):
        """测试添加用户默认为非管理员"""
        db_user_store.add_user("testuser", "hashed_password")
        
        # 验证 SQL 调用
        mock_db.execute.assert_called_once()
        call_args = mock_db.execute.call_args
        assert "is_admin" in call_args[0][0]
        assert call_args[0][1][2] is False  # 第三个参数是 is_admin

    def test_add_user_as_admin(self, db_user_store, mock_db):
        """测试添加管理员用户"""
        db_user_store.add_user("admin", "hashed_password", is_admin=True)
        
        # 验证 SQL 调用
        mock_db.execute.assert_called_once()
        call_args = mock_db.execute.call_args
        assert call_args[0][1][2] is True  # 第三个参数是 is_admin

    def test_is_admin_returns_true_for_admin(self, db_user_store, mock_db):
        """测试 is_admin 对管理员返回 True"""
        # 模拟数据库返回
        mock_db.execute_one.return_value = {
            'username': 'admin',
            'password_hash': 'hash',
            'is_admin': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
        
        result = db_user_store.is_admin("admin")
        
        assert result is True
        mock_db.execute_one.assert_called_once()

    def test_is_admin_returns_false_for_normal_user(self, db_user_store, mock_db):
        """测试 is_admin 对普通用户返回 False"""
        # 模拟数据库返回
        mock_db.execute_one.return_value = {
            'username': 'user1',
            'password_hash': 'hash',
            'is_admin': False,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
        
        result = db_user_store.is_admin("user1")
        
        assert result is False

    def test_is_admin_returns_false_for_nonexistent_user(self, db_user_store, mock_db):
        """测试 is_admin 对不存在的用户返回 False"""
        # 模拟数据库返回 None
        mock_db.execute_one.return_value = None
        
        result = db_user_store.is_admin("nonexistent")
        
        assert result is False

    def test_set_admin_status_to_true(self, db_user_store, mock_db):
        """测试设置用户为管理员"""
        db_user_store.set_admin_status("user1", True)
        
        # 验证 SQL 调用
        mock_db.execute.assert_called_once()
        call_args = mock_db.execute.call_args
        assert "UPDATE users SET is_admin" in call_args[0][0]
        assert call_args[0][1][0] is True  # 第一个参数是 is_admin
        assert call_args[0][1][1] == "user1"  # 第二个参数是 username

    def test_set_admin_status_to_false(self, db_user_store, mock_db):
        """测试取消用户管理员状态"""
        db_user_store.set_admin_status("admin", False)
        
        # 验证 SQL 调用
        mock_db.execute.assert_called_once()
        call_args = mock_db.execute.call_args
        assert call_args[0][1][0] is False

    def test_load_users_includes_is_admin(self, db_user_store, mock_db):
        """测试加载用户时包含 is_admin 字段"""
        # 模拟数据库返回
        mock_db.execute.return_value = [
            {
                'username': 'admin',
                'password_hash': 'hash1',
                'is_admin': True,
                'created_at': datetime.now(),
                'updated_at': datetime.now()
            },
            {
                'username': 'user1',
                'password_hash': 'hash2',
                'is_admin': False,
                'created_at': datetime.now(),
                'updated_at': datetime.now()
            }
        ]
        
        users = db_user_store.load_users()
        
        assert "admin" in users
        assert "user1" in users
        assert users["admin"]["is_admin"] is True
        assert users["user1"]["is_admin"] is False

    def test_get_user_includes_is_admin(self, db_user_store, mock_db):
        """测试获取单个用户时包含 is_admin 字段"""
        # 模拟数据库返回
        mock_db.execute_one.return_value = {
            'username': 'admin',
            'password_hash': 'hash',
            'is_admin': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
        
        user_data = db_user_store.get_user("admin")
        
        assert user_data is not None
        assert user_data["is_admin"] is True

    def test_get_user_nonexistent(self, db_user_store, mock_db):
        """测试获取不存在的用户"""
        mock_db.execute_one.return_value = None
        
        user_data = db_user_store.get_user("nonexistent")
        
        assert user_data is None

    def test_multiple_users_mixed_admin_status(self, db_user_store, mock_db):
        """测试多个用户混合管理员状态"""
        # 模拟数据库返回
        mock_db.execute.return_value = [
            {'username': 'admin1', 'password_hash': 'h1', 'is_admin': True, 
             'created_at': datetime.now(), 'updated_at': datetime.now()},
            {'username': 'admin2', 'password_hash': 'h2', 'is_admin': True,
             'created_at': datetime.now(), 'updated_at': datetime.now()},
            {'username': 'user1', 'password_hash': 'h3', 'is_admin': False,
             'created_at': datetime.now(), 'updated_at': datetime.now()},
            {'username': 'user2', 'password_hash': 'h4', 'is_admin': False,
             'created_at': datetime.now(), 'updated_at': datetime.now()}
        ]
        
        users = db_user_store.load_users()
        
        assert users["admin1"]["is_admin"] is True
        assert users["admin2"]["is_admin"] is True
        assert users["user1"]["is_admin"] is False
        assert users["user2"]["is_admin"] is False

    def test_sql_query_selects_is_admin(self, db_user_store, mock_db):
        """测试 SQL 查询包含 is_admin 字段"""
        mock_db.execute.return_value = []
        
        db_user_store.load_users()
        
        call_args = mock_db.execute.call_args
        assert "is_admin" in call_args[0][0]

    def test_set_admin_status_updates_timestamp(self, db_user_store, mock_db):
        """测试设置管理员状态时更新时间戳"""
        db_user_store.set_admin_status("user1", True)
        
        call_args = mock_db.execute.call_args
        sql = call_args[0][0]
        assert "updated_at = CURRENT_TIMESTAMP" in sql
