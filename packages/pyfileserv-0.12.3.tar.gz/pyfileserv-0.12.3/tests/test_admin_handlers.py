"""管理员权限控制 - AdminHandler 测试"""
import json
from io import BytesIO
from unittest.mock import MagicMock, patch

import pytest

from file_server.core.auth import UserStore
from file_server.handle.admin import AdminHandler


@pytest.fixture
def mock_user_store():
    """创建模拟用户存储"""
    store = MagicMock(spec=UserStore)
    return store


@pytest.fixture
def admin_handler(mock_user_store):
    """创建 AdminHandler 实例"""
    return AdminHandler(mock_user_store)


@pytest.fixture
def mock_handler():
    """创建模拟 HTTP 请求处理器"""
    handler = MagicMock()
    handler.headers = {}
    handler.rfile = BytesIO()
    return handler


class TestAdminHandlerPermission:
    """AdminHandler 权限控制测试"""

    def test_handle_admin_page_admin_access_allowed(self, admin_handler, mock_user_store, mock_handler):
        """测试管理员可以访问管理页面"""
        # 设置当前用户为管理员
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        mock_user_store.load_users.return_value = {
            "admin": {"password": "hash", "created_at": "1234567890", "is_admin": True}
        }
        
        admin_handler.handle_admin_page(mock_handler)
        
        # 验证没有返回错误
        mock_handler.send_error.assert_not_called()
        mock_handler._send_html_response.assert_called_once()

    def test_handle_admin_page_non_admin_access_denied(self, admin_handler, mock_user_store, mock_handler):
        """测试非管理员访问管理页面被拒绝"""
        # 设置当前用户为非管理员
        mock_handler.get_current_username.return_value = "user1"
        mock_user_store.is_admin.return_value = False
        
        admin_handler.handle_admin_page(mock_handler)
        
        # 验证返回 403 错误
        mock_handler.send_error.assert_called_once_with(403, "Forbidden - Admin access required")
        mock_handler._send_html_response.assert_not_called()

    def test_handle_create_user_admin_can_create(self, admin_handler, mock_user_store, mock_handler):
        """测试管理员可以创建用户"""
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        mock_user_store.user_exists.return_value = False
        
        # 准备请求数据
        request_data = json.dumps({
            "username": "newuser",
            "password": "password123",
            "is_admin": False
        }).encode('utf-8')
        
        mock_handler.headers = {'Content-Length': str(len(request_data))}
        mock_handler.rfile = BytesIO(request_data)
        
        admin_handler.handle_create_user(mock_handler)
        
        # 验证用户被创建
        mock_user_store.add_user.assert_called_once()
        mock_handler._send_json_response.assert_called_once()

    def test_handle_create_user_non_admin_denied(self, admin_handler, mock_user_store, mock_handler):
        """测试非管理员创建用户被拒绝"""
        mock_handler.get_current_username.return_value = "user1"
        mock_user_store.is_admin.return_value = False
        
        admin_handler.handle_create_user(mock_handler)
        
        # 验证返回 403 错误
        mock_handler._send_error_response.assert_called_once()
        call_args = mock_handler._send_error_response.call_args
        assert call_args[0][1] == 403  # 第二个参数是状态码
        mock_user_store.add_user.assert_not_called()

    def test_handle_create_user_with_admin_flag(self, admin_handler, mock_user_store, mock_handler):
        """测试创建管理员用户"""
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        mock_user_store.user_exists.return_value = False
        
        # 准备请求数据，创建管理员
        request_data = json.dumps({
            "username": "newadmin",
            "password": "password123",
            "is_admin": True
        }).encode('utf-8')
        
        mock_handler.headers = {'Content-Length': str(len(request_data))}
        mock_handler.rfile = BytesIO(request_data)
        
        admin_handler.handle_create_user(mock_handler)
        
        # 验证调用 add_user 时传递了 is_admin=True
        call_args = mock_user_store.add_user.call_args
        assert call_args[0][2] is True  # 第三个参数是 is_admin

    def test_handle_delete_user_admin_can_delete(self, admin_handler, mock_user_store, mock_handler):
        """测试管理员可以删除用户"""
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        mock_user_store.user_exists.return_value = True
        mock_user_store.delete_user.return_value = True
        
        admin_handler.handle_delete_user(mock_handler, "usertodelete")
        
        # 验证用户被删除
        mock_user_store.delete_user.assert_called_once_with("usertodelete")
        mock_handler._send_json_response.assert_called_once()

    def test_handle_delete_user_non_admin_denied(self, admin_handler, mock_user_store, mock_handler):
        """测试非管理员删除用户被拒绝"""
        mock_handler.get_current_username.return_value = "user1"
        mock_user_store.is_admin.return_value = False
        
        admin_handler.handle_delete_user(mock_handler, "usertodelete")
        
        # 验证返回 403 错误
        mock_handler._send_error_response.assert_called_once()
        call_args = mock_handler._send_error_response.call_args
        assert call_args[0][1] == 403
        mock_user_store.delete_user.assert_not_called()

    def test_handle_change_password_admin_can_change(self, admin_handler, mock_user_store, mock_handler):
        """测试管理员可以修改用户密码"""
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        mock_user_store.user_exists.return_value = True
        
        # 准备请求数据
        request_data = json.dumps({
            "new_password": "newpass123"
        }).encode('utf-8')
        
        mock_handler.headers = {'Content-Length': str(len(request_data))}
        mock_handler.rfile = BytesIO(request_data)
        
        admin_handler.handle_change_password(mock_handler, "targetuser")
        
        # 验证密码被更新
        mock_user_store.update_password.assert_called_once()
        mock_handler._send_json_response.assert_called_once()

    def test_handle_change_password_non_admin_denied(self, admin_handler, mock_user_store, mock_handler):
        """测试非管理员修改密码被拒绝"""
        mock_handler.get_current_username.return_value = "user1"
        mock_user_store.is_admin.return_value = False
        
        admin_handler.handle_change_password(mock_handler, "targetuser")
        
        # 验证返回 403 错误
        mock_handler._send_error_response.assert_called_once()
        call_args = mock_handler._send_error_response.call_args
        assert call_args[0][1] == 403
        mock_user_store.update_password.assert_not_called()

    def test_handle_admin_page_includes_is_admin_in_response(self, admin_handler, mock_user_store, mock_handler):
        """测试管理页面响应包含 is_admin 字段"""
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        mock_user_store.load_users.return_value = {
            "admin": {"password": "hash", "created_at": "1234567890", "is_admin": True},
            "user1": {"password": "hash", "created_at": "1234567890", "is_admin": False}
        }
        
        admin_handler.handle_admin_page(mock_handler)
        
        # 验证 HTML 被发送
        mock_handler._send_html_response.assert_called_once()
        html = mock_handler._send_html_response.call_args[0][0]
        assert isinstance(html, str)
        assert len(html) > 0

    def test_permission_check_logs_warning_for_non_admin(self, admin_handler, mock_user_store, mock_handler):
        """测试非管理员尝试访问时记录警告日志"""
        mock_handler.get_current_username.return_value = "user1"
        mock_user_store.is_admin.return_value = False
        
        with patch('file_server.handle.admin.logger') as mock_logger:
            admin_handler.handle_admin_page(mock_handler)
            
            # 验证记录了警告日志
            mock_logger.warning.assert_called_once()
            assert "非管理员" in mock_logger.warning.call_args[0][0]


class TestAdminHandlerValidation:
    """AdminHandler 输入验证测试"""

    def test_handle_create_user_empty_username(self, admin_handler, mock_user_store, mock_handler):
        """测试创建用户时用户名为空"""
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        
        request_data = json.dumps({
            "username": "",
            "password": "password123"
        }).encode('utf-8')
        
        mock_handler.headers = {'Content-Length': str(len(request_data))}
        mock_handler.rfile = BytesIO(request_data)
        
        admin_handler.handle_create_user(mock_handler)
        
        # 验证返回错误
        mock_handler._send_error_response.assert_called_once()
        assert "用户名不能为空" in mock_handler._send_error_response.call_args[0][0]

    def test_handle_create_user_short_password(self, admin_handler, mock_user_store, mock_handler):
        """测试创建用户时密码过短"""
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        
        request_data = json.dumps({
            "username": "newuser",
            "password": "12345"  # 少于6位
        }).encode('utf-8')
        
        mock_handler.headers = {'Content-Length': str(len(request_data))}
        mock_handler.rfile = BytesIO(request_data)
        
        admin_handler.handle_create_user(mock_handler)
        
        # 验证返回错误
        mock_handler._send_error_response.assert_called_once()
        assert "密码长度至少为6位" in mock_handler._send_error_response.call_args[0][0]

    def test_handle_create_user_duplicate_username(self, admin_handler, mock_user_store, mock_handler):
        """测试创建已存在的用户"""
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        mock_user_store.user_exists.return_value = True
        
        request_data = json.dumps({
            "username": "existinguser",
            "password": "password123"
        }).encode('utf-8')
        
        mock_handler.headers = {'Content-Length': str(len(request_data))}
        mock_handler.rfile = BytesIO(request_data)
        
        admin_handler.handle_create_user(mock_handler)
        
        # 验证返回错误
        mock_handler._send_error_response.assert_called_once()
        assert "已存在" in mock_handler._send_error_response.call_args[0][0]

    def test_handle_change_password_short_password(self, admin_handler, mock_user_store, mock_handler):
        """测试修改密码时新密码过短"""
        mock_handler.get_current_username.return_value = "admin"
        mock_user_store.is_admin.return_value = True
        mock_user_store.user_exists.return_value = True
        
        request_data = json.dumps({
            "new_password": "12345"  # 少于6位
        }).encode('utf-8')
        
        mock_handler.headers = {'Content-Length': str(len(request_data))}
        mock_handler.rfile = BytesIO(request_data)
        
        admin_handler.handle_change_password(mock_handler, "targetuser")
        
        # 验证返回错误
        mock_handler._send_error_response.assert_called_once()
        assert "密码长度至少为6位" in mock_handler._send_error_response.call_args[0][0]
