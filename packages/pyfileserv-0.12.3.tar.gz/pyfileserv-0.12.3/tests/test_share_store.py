"""测试 JSON 分享数据存储模块"""
import json
import tempfile
import time
from pathlib import Path

from file_server.core.auth import PasswordHasher
from file_server.core.share_store import ShareStore


class TestShareStore:
    """测试 ShareStore 类（JSON 后端）"""

    def setup_method(self):
        """每个测试前创建临时数据文件"""
        self.temp_dir = tempfile.mkdtemp()
        self.data_file = Path(self.temp_dir) / "shares.json"
        self.hasher = PasswordHasher(rounds=4)
        self.store = ShareStore(self.data_file, self.hasher)

    def teardown_method(self):
        """清理临时目录"""
        import shutil
        shutil.rmtree(self.temp_dir)

    # ========== 初始化测试 ==========

    def test_init_new_file(self):
        """新文件初始化 — 空存储"""
        assert self.data_file.exists() is False
        shares = self.store.list_shares_for_management()
        assert shares == []

    def test_init_existing_file(self):
        """从已有文件加载"""
        test_data = {
            "share1": {
                "file_path": "test.txt",
                "password_hash": self.hasher.hash_password("test123"),
                "expires_at": time.time() + 3600,
                "max_downloads": 5,
                "download_count": 0,
                "created_at": time.time(),
                "created_by": "admin",
                "is_deleted": False,
            }
        }
        with open(self.data_file, 'w') as f:
            json.dump(test_data, f)

        store2 = ShareStore(self.data_file, self.hasher)
        shares = store2.list_shares_for_management()
        assert len(shares) == 1
        assert shares[0]['share_id'] == 'share1'

    # ========== CRUD 测试 ==========

    def test_create_and_get_share(self):
        """创建后读取"""
        share_data = {
            'file_path': 'docs/report.pdf',
            'password_hash': self.hasher.hash_password('secret'),
            'expires_at': time.time() + 86400,
            'max_downloads': 10,
            'download_count': 0,
            'created_at': time.time(),
            'created_by': 'admin',
            'is_deleted': False,
        }
        self.store.create_share('sid1', share_data)
        retrieved = self.store.get_share('sid1')
        assert retrieved is not None
        assert retrieved['file_path'] == 'docs/report.pdf'
        assert retrieved['max_downloads'] == 10

    def test_get_share_not_exists(self):
        """获取不存在的分享"""
        assert self.store.get_share('nonexistent') is None

    def test_get_share_deleted(self):
        """获取已软删除的分享应返回 None"""
        share_data = {
            'file_path': 'f.txt',
            'password_hash': None,
            'expires_at': None,
            'max_downloads': None,
            'download_count': 0,
            'created_at': time.time(),
            'created_by': 'admin',
            'is_deleted': True,
        }
        self.store.create_share('sid_del', share_data)
        assert self.store.get_share('sid_del') is None

    def test_get_share_expired(self):
        """获取已过期的分享应返回 None"""
        share_data = {
            'file_path': 'f.txt',
            'password_hash': None,
            'expires_at': time.time() - 100,  # 已过期
            'max_downloads': None,
            'download_count': 0,
            'created_at': time.time() - 200,
            'created_by': 'admin',
            'is_deleted': False,
        }
        self.store.create_share('sid_exp', share_data)
        assert self.store.get_share('sid_exp') is None

    def test_get_share_any(self):
        """get_share_any 应返回任意状态的分享"""
        share_data = {
            'file_path': 'f.txt',
            'password_hash': None,
            'expires_at': time.time() - 100,
            'max_downloads': None,
            'download_count': 0,
            'created_at': time.time() - 200,
            'created_by': 'admin',
            'is_deleted': False,
        }
        self.store.create_share('sid_any', share_data)
        retrieved = self.store.get_share_any('sid_any')
        assert retrieved is not None
        assert retrieved['share_id'] == 'sid_any'

    # ========== 列出分享 ==========

    def test_list_shares_for_management(self):
        """列出所有分享，含状态分类"""
        now = time.time()
        self.store.create_share('s_active', {
            'file_path': 'a.txt', 'password_hash': None,
            'expires_at': now + 3600, 'max_downloads': None,
            'download_count': 0, 'created_at': now - 100,
            'created_by': 'admin', 'is_deleted': False,
        })
        self.store.create_share('s_expired', {
            'file_path': 'b.txt', 'password_hash': None,
            'expires_at': now - 100, 'max_downloads': None,
            'download_count': 0, 'created_at': now - 200,
            'created_by': 'admin', 'is_deleted': False,
        })
        self.store.create_share('s_deleted', {
            'file_path': 'c.txt', 'password_hash': None,
            'expires_at': now + 3600, 'max_downloads': None,
            'download_count': 0, 'created_at': now - 300,
            'created_by': 'admin', 'is_deleted': True,
        })

        shares = self.store.list_shares_for_management()
        assert len(shares) == 3
        statuses = {s['share_id']: s['status'] for s in shares}
        assert statuses['s_active'] == 'active'
        assert statuses['s_expired'] == 'expired'
        assert statuses['s_deleted'] == 'deleted'
        # 验证 has_password 字段
        for s in shares:
            assert 'has_password' in s
            assert s['has_password'] is False

    def test_list_shares_has_password(self):
        """有密码的分享 has_password 应为 True"""
        self.store.create_share('s_pwd', {
            'file_path': 'x.txt',
            'password_hash': self.hasher.hash_password('pwd'),
            'expires_at': time.time() + 3600,
            'max_downloads': None, 'download_count': 0,
            'created_at': time.time(), 'created_by': 'admin',
            'is_deleted': False,
        })
        shares = self.store.list_shares_for_management()
        assert shares[0]['has_password'] is True

    # ========== 更新测试 ==========

    def test_update_share_success(self):
        """成功更新字段"""
        self.store.create_share('sid', {
            'file_path': 'f.txt', 'password_hash': None,
            'expires_at': time.time() + 3600, 'max_downloads': 5,
            'download_count': 0, 'created_at': time.time(),
            'created_by': 'admin', 'is_deleted': False,
        })
        new_expires = time.time() + 7200
        result = self.store.update_share('sid', {'expires_at': new_expires, 'max_downloads': 10})
        assert result is True

        share = self.store.get_share('sid')
        assert share['max_downloads'] == 10
        assert abs(share['expires_at'] - new_expires) < 1

    def test_update_share_invalid_field(self):
        """更新不允许的字段应被忽略"""
        self.store.create_share('sid', {
            'file_path': 'f.txt', 'password_hash': None,
            'expires_at': time.time() + 3600, 'max_downloads': 5,
            'download_count': 0, 'created_at': time.time(),
            'created_by': 'admin', 'is_deleted': False,
        })
        result = self.store.update_share('sid', {'file_path': 'hack.txt'})
        assert result is False  # 无允许的字段

    def test_update_share_not_exists(self):
        """更新不存在的分享返回 False"""
        assert self.store.update_share('nonexistent', {'max_downloads': 10}) is False

    # ========== 软删除测试 ==========

    def test_soft_delete(self):
        """软删除后 get_share 返回 None，管理页面仍可见"""
        self.store.create_share('sid', {
            'file_path': 'f.txt', 'password_hash': None,
            'expires_at': time.time() + 3600, 'max_downloads': None,
            'download_count': 0, 'created_at': time.time(),
            'created_by': 'admin', 'is_deleted': False,
        })
        assert self.store.soft_delete_share('sid') is True
        assert self.store.get_share('sid') is None
        # 管理页面仍可见
        shares = self.store.list_shares_for_management()
        assert len(shares) == 1
        assert shares[0]['status'] == 'deleted'

    def test_soft_delete_already_deleted(self):
        """重复软删除返回 False"""
        self.store.create_share('sid', {
            'file_path': 'f.txt', 'password_hash': None,
            'expires_at': time.time() + 3600, 'max_downloads': None,
            'download_count': 0, 'created_at': time.time(),
            'created_by': 'admin', 'is_deleted': True,
        })
        assert self.store.soft_delete_share('sid') is False

    def test_soft_delete_not_exists(self):
        """软删除不存在的分享返回 False"""
        assert self.store.soft_delete_share('nonexistent') is False

    # ========== 永久删除测试 ==========

    def test_permanent_delete_success(self):
        """永久删除已软删除的分享"""
        self.store.create_share('sid', {
            'file_path': 'f.txt', 'password_hash': None,
            'expires_at': time.time() + 3600, 'max_downloads': None,
            'download_count': 0, 'created_at': time.time(),
            'created_by': 'admin', 'is_deleted': True,
        })
        assert self.store.permanent_delete_share('sid') is True
        # 管理页面也不可见
        assert self.store.list_shares_for_management() == []

    def test_permanent_delete_active(self):
        """永久删除活跃分享应失败（需先软删除）"""
        self.store.create_share('sid', {
            'file_path': 'f.txt', 'password_hash': None,
            'expires_at': time.time() + 3600, 'max_downloads': None,
            'download_count': 0, 'created_at': time.time(),
            'created_by': 'admin', 'is_deleted': False,
        })
        assert self.store.permanent_delete_share('sid') is False
        # 分享仍存在
        assert self.store.get_share('sid') is not None

    # ========== 下载计数测试 ==========

    def test_record_download(self):
        """记录下载应增加计数"""
        self.store.create_share('sid', {
            'file_path': 'f.txt', 'password_hash': None,
            'expires_at': time.time() + 3600, 'max_downloads': 5,
            'download_count': 0, 'created_at': time.time(),
            'created_by': 'admin', 'is_deleted': False,
        })
        self.store.record_download('sid')
        share = self.store.get_share('sid')
        assert share['download_count'] == 1

        self.store.record_download('sid')
        share = self.store.get_share('sid')
        assert share['download_count'] == 2

    def test_record_download_not_exists(self):
        """记录不存在的分享不应报错"""
        self.store.record_download('nonexistent')  # 不应抛出异常

    # ========== 文件分享查询 ==========

    def test_get_file_shares(self):
        """按文件路径查询分享"""
        now = time.time()
        base = {
            'password_hash': None, 'max_downloads': None,
            'download_count': 0, 'created_by': 'admin',
            'is_deleted': False,
        }
        self.store.create_share('s1', {**base, 'file_path': 'a.txt', 'expires_at': now + 3600, 'created_at': now})
        self.store.create_share('s2', {**base, 'file_path': 'a.txt', 'expires_at': now + 7200, 'created_at': now})
        self.store.create_share('s3', {**base, 'file_path': 'b.txt', 'expires_at': now + 3600, 'created_at': now})
        # 过期的不应出现
        self.store.create_share('s4', {**base, 'file_path': 'a.txt', 'expires_at': now - 100, 'created_at': now})
        # 删除的不应出现
        self.store.create_share('s5', {**base, 'file_path': 'a.txt', 'expires_at': now + 3600, 'created_at': now, 'is_deleted': True})

        result = self.store.get_file_shares('a.txt')
        assert len(result) == 2
        ids = [r['share_id'] for r in result]
        assert 's1' in ids
        assert 's2' in ids


class TestShareStorePasswordMigration:
    """测试明文密码迁移"""

    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.data_file = Path(self.temp_dir) / "shares.json"
        self.hasher = PasswordHasher(rounds=4)

    def teardown_method(self):
        import shutil
        shutil.rmtree(self.temp_dir)

    def test_migrate_plaintext_password(self):
        """旧格式明文密码 → bcrypt hash"""
        old_data = {
            "sid1": {
                "file_path": "doc.pdf",
                "password": "plaintext_secret",
                "expires_at": time.time() + 3600,
                "max_downloads": 10,
                "download_count": 2,
                "created_at": time.time(),
                "created_by": "admin"
            }
        }
        with open(self.data_file, 'w') as f:
            json.dump(old_data, f)

        store = ShareStore(self.data_file, self.hasher)
        share = store.get_share('sid1')
        assert share is not None
        # 应有 password_hash，没有 password
        assert 'password_hash' in share
        assert 'password' not in share
        # hash 应该可以验证原始密码
        assert self.hasher.verify_password('plaintext_secret', share['password_hash'])
        # is_deleted 被补全
        assert share.get('is_deleted') is False

    def test_migrate_no_password(self):
        """旧格式无密码分享也应迁移"""
        old_data = {
            "sid": {
                "file_path": "f.txt",
                "password": None,
                "expires_at": None,
                "max_downloads": None,
                "download_count": 0,
                "created_at": time.time(),
                "created_by": None
            }
        }
        with open(self.data_file, 'w') as f:
            json.dump(old_data, f)

        store = ShareStore(self.data_file, self.hasher)
        share = store.get_share('sid')
        assert share is not None
        assert 'password' not in share

    def test_load_corrupt_json(self):
        """损坏的 JSON 文件不应崩溃"""
        with open(self.data_file, 'w') as f:
            f.write("this is not valid json {{{")

        store = ShareStore(self.data_file, self.hasher)
        assert store.list_shares_for_management() == []


class TestShareStoreConcurrency:
    """测试线程安全"""

    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.data_file = Path(self.temp_dir) / "shares.json"
        self.hasher = PasswordHasher(rounds=4)
        self.store = ShareStore(self.data_file, self.hasher)

    def teardown_method(self):
        import shutil
        shutil.rmtree(self.temp_dir)

    def test_concurrent_create(self):
        """多个线程同时创建分享"""
        import threading
        import random

        results = []

        def _create():
            share_data = {
                'file_path': f'file_{random.randint(1, 10000)}.txt',
                'password_hash': None,
                'expires_at': time.time() + 86400,
                'max_downloads': None,
                'download_count': 0,
                'created_at': time.time(),
                'created_by': 'admin',
                'is_deleted': False,
            }
            self.store.create_share(f'sid_{random.randint(1, 1000000)}', share_data)
            results.append(True)

        threads = [threading.Thread(target=_create) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(results) == 10
        # 所有分享都在管理列表中
        shares = self.store.list_shares_for_management()
        assert len(shares) == 10

    def test_concurrent_read_write(self):
        """并发读写不冲突"""
        import threading

        self.store.create_share('sid', {
            'file_path': 'f.txt', 'password_hash': None,
            'expires_at': time.time() + 3600, 'max_downloads': 10,
            'download_count': 0, 'created_at': time.time(),
            'created_by': 'admin', 'is_deleted': False,
        })

        errors = []

        def _reader():
            try:
                for _ in range(100):
                    self.store.get_share('sid')
            except Exception as e:
                errors.append(e)

        def _writer():
            try:
                for _ in range(100):
                    self.store.record_download('sid')
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=_reader) for _ in range(4)] + \
                   [threading.Thread(target=_writer) for _ in range(2)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == []
        share = self.store.get_share('sid')
        assert share['download_count'] == 200
