"""配置集成测试 - 测试不同配置参数组合"""
import os
from pathlib import Path

import pytest

from file_server.config import ServerConfig, DatabaseConfig, get_default_config_yaml


class TestConfigYamlParsing:
    """YAML 配置文件解析测试"""

    def test_parse_full_config(self, tmp_path):
        """Test parsing full config file"""
        config_content = '''# pyfileserv config file
server:
  port: 9000
  host: "0.0.0.0"

paths:
  serve_dir: "/srv/files"
  static_dir: "/srv/static"
  users_file: "myusers.json"

ssl:
  cert_file: "/etc/ssl/cert.pem"
  key_file: "/etc/ssl/key.pem"

database:
  type: "postgres"
  host: "db.example.com"
  port: 5433
  database: "mydb"
  username: "myuser"
  password: "mypass"
  pool_size: 10
  max_overflow: 20

session:
  timeout: 7200

security:
  bcrypt_rounds: 8

ip_restriction:
  whitelist:
    - "192.168.1.0/24"
    - "10.0.0.1"
  blacklist:
    - "192.168.2.5"
    - "192.168.2.6"
'''
        config_file = tmp_path / "config.yml"
        config_file.write_text(config_content)

        config = ServerConfig.from_yaml(config_file)

        assert config.port == 9000
        assert config.host == "0.0.0.0"
        # 在 Windows 上，/srv/files 会被转换为相对于配置文件目录的绝对路径
        # 我们检查路径是否正确，而不是绝对路径的具体值
        assert str(config.serve_dir).endswith("srv" + os.sep + "files")
        assert str(config.static_dir).endswith("srv" + os.sep + "static")
        assert config.users_file == "myusers.json"
        assert str(config.ssl_cert).endswith("etc" + os.sep + "ssl" + os.sep + "cert.pem")
        assert str(config.ssl_key).endswith("etc" + os.sep + "ssl" + os.sep + "key.pem")
        assert config.database.type == "postgres"
        assert config.database.host == "db.example.com"
        assert config.database.port == 5433
        assert config.database.database == "mydb"
        assert config.database.username == "myuser"
        assert config.database.password == "mypass"
        assert config.database.pool_size == 10
        assert config.database.max_overflow == 20
        assert config.session_timeout == 7200
        assert config.bcrypt_rounds == 8
        assert config.use_https is True
        assert config.use_database is True
        assert config.ip_whitelist == ["192.168.1.0/24", "10.0.0.1"]
        assert config.ip_blacklist == ["192.168.2.5", "192.168.2.6"]

    def test_parse_minimal_config(self, tmp_path):
        """Test parsing minimal config file"""
        config_content = '''# Minimal config
server:
  port: 8000
'''
        config_file = tmp_path / "config.yml"
        config_file.write_text(config_content)

        config = ServerConfig.from_yaml(config_file)

        assert config.port == 8000
        assert config.host == ""  # 默认值
        assert config.serve_dir is None
        assert config.users_file == "users.json"  # 默认值
        assert config.database.type == "json"  # 默认值
        assert config.session_timeout == 3600  # 默认值
        assert config.bcrypt_rounds == 12  # 默认值
        assert config.use_https is False
        assert config.use_database is False

    def test_parse_json_database_config(self, tmp_path):
        """测试解析 JSON 数据库配置"""
        config_content = '''database:
  type: "json"
'''
        config_file = tmp_path / "config.yml"
        config_file.write_text(config_content)

        config = ServerConfig.from_yaml(config_file)

        assert config.database.type == "json"
        assert config.use_database is False

    def test_parse_postgres_config_only(self, tmp_path):
        """测试解析仅 PostgreSQL 配置"""
        config_content = '''database:
  type: "postgres"
  host: "localhost"
  database: "pyfileserv"
'''
        config_file = tmp_path / "config.yml"
        config_file.write_text(config_content)

        config = ServerConfig.from_yaml(config_file)

        assert config.database.type == "postgres"
        assert config.database.host == "localhost"
        assert config.database.port == 5432  # 默认值
        assert config.database.database == "pyfileserv"
        assert config.database.username is None  # 默认值
        assert config.database.password is None  # 默认值
        assert config.use_database is True

    def test_parse_ssl_config_only(self, tmp_path):
        """测试解析仅 SSL 配置"""
        config_content = '''ssl:
  cert_file: "cert.pem"
  key_file: "key.pem"
'''
        config_file = tmp_path / "config.yml"
        config_file.write_text(config_content)

        config = ServerConfig.from_yaml(config_file)

        # 从 YAML 加载时，相对路径会转换为相对于配置文件目录的绝对路径
        assert config.ssl_cert == config_file.parent / "cert.pem"
        assert config.ssl_key == config_file.parent / "key.pem"
        assert config.use_https is True

    def test_save_and_load_yaml(self, tmp_path):
        """测试保存和加载 YAML 配置"""
        original_config = ServerConfig(
            port=9999,
            host="127.0.0.1",
            users_file="custom.json",
            session_timeout=1800,
            bcrypt_rounds=10
        )
        original_config.serve_dir = Path("/test/path")
        original_config.ssl_cert = Path("test_cert.pem")
        original_config.ssl_key = Path("test_key.pem")
        original_config.database.type = "postgres"
        original_config.database.host = "test.db"

        config_file = tmp_path / "saved_config.yml"
        original_config.save_yaml(config_file)

        loaded_config = ServerConfig.from_yaml(config_file)

        assert loaded_config.port == original_config.port
        assert loaded_config.host == original_config.host
        assert loaded_config.users_file == original_config.users_file
        assert loaded_config.session_timeout == original_config.session_timeout
        assert loaded_config.bcrypt_rounds == original_config.bcrypt_rounds
        # 在 Windows 上路径处理不同，我们检查相对路径是否正确转换
        assert str(loaded_config.serve_dir).endswith("test" + os.sep + "path")
        # 从 YAML 加载时，相对路径会转换为相对于配置文件目录的绝对路径
        assert loaded_config.ssl_cert == config_file.parent / "test_cert.pem"
        assert loaded_config.ssl_key == config_file.parent / "test_key.pem"
        assert loaded_config.database.type == original_config.database.type
        assert loaded_config.database.host == original_config.database.host


class TestConfigEnvironmentVariables:
    """环境变量配置测试"""

    @pytest.fixture
    def clear_env(self):
        """清除所有相关环境变量"""
        env_vars = [
            'PYFILESERV_PORT', 'PYFILESERV_HOST',
            'PYFILESERV_SERVE_DIR', 'PYFILESERV_STATIC_DIR', 'PYFILESERV_USERS_FILE',
            'PYFILESERV_SSL_CERT', 'PYFILESERV_SSL_KEY',
            'PYFILESERV_DB_TYPE', 'PYFILESERV_DB_HOST', 'PYFILESERV_DB_PORT',
            'PYFILESERV_DB_NAME', 'PYFILESERV_DB_USER', 'PYFILESERV_DB_PASSWORD',
            'PYFILESERV_SESSION_TIMEOUT', 'PYFILESERV_BCRYPT_ROUNDS',
            'PYFILESERV_IP_WHITELIST', 'PYFILESERV_IP_BLACKLIST'
        ]
        for var in env_vars:
            if var in os.environ:
                del os.environ[var]
        yield
        for var in env_vars:
            if var in os.environ:
                del os.environ[var]

    def test_env_var_port(self, clear_env, monkeypatch):
        """测试环境变量 PORT"""
        monkeypatch.setenv('PYFILESERV_PORT', '9001')
        config = ServerConfig()
        config.load_from_env()
        assert config.port == 9001

    def test_env_var_host(self, clear_env, monkeypatch):
        """测试环境变量 HOST"""
        monkeypatch.setenv('PYFILESERV_HOST', '192.168.1.100')
        config = ServerConfig()
        config.load_from_env()
        assert config.host == '192.168.1.100'

    def test_env_var_paths(self, clear_env, monkeypatch):
        """测试环境变量路径"""
        monkeypatch.setenv('PYFILESERV_SERVE_DIR', '/env/serve')
        monkeypatch.setenv('PYFILESERV_STATIC_DIR', '/env/static')
        monkeypatch.setenv('PYFILESERV_USERS_FILE', 'env_users.json')
        config = ServerConfig()
        config.load_from_env()
        assert config.serve_dir == Path('/env/serve')
        assert config.static_dir == Path('/env/static')
        assert config.users_file == 'env_users.json'

    def test_env_var_ssl(self, clear_env, monkeypatch):
        """测试环境变量 SSL"""
        monkeypatch.setenv('PYFILESERV_SSL_CERT', '/env/cert.pem')
        monkeypatch.setenv('PYFILESERV_SSL_KEY', '/env/key.pem')
        config = ServerConfig()
        config.load_from_env()
        assert config.ssl_cert == Path('/env/cert.pem')
        assert config.ssl_key == Path('/env/key.pem')

    def test_env_var_database(self, clear_env, monkeypatch):
        """测试环境变量数据库"""
        monkeypatch.setenv('PYFILESERV_DB_TYPE', 'postgres')
        monkeypatch.setenv('PYFILESERV_DB_HOST', 'env.db.com')
        monkeypatch.setenv('PYFILESERV_DB_PORT', '5433')
        monkeypatch.setenv('PYFILESERV_DB_NAME', 'envdb')
        monkeypatch.setenv('PYFILESERV_DB_USER', 'envuser')
        monkeypatch.setenv('PYFILESERV_DB_PASSWORD', 'envpass')
        config = ServerConfig()
        config.load_from_env()
        assert config.database.type == 'postgres'
        assert config.database.host == 'env.db.com'
        assert config.database.port == 5433
        assert config.database.database == 'envdb'
        assert config.database.username == 'envuser'
        assert config.database.password == 'envpass'

    def test_env_var_session(self, clear_env, monkeypatch):
        """测试环境变量会话"""
        monkeypatch.setenv('PYFILESERV_SESSION_TIMEOUT', '1800')
        monkeypatch.setenv('PYFILESERV_BCRYPT_ROUNDS', '8')
        config = ServerConfig()
        config.load_from_env()
        assert config.session_timeout == 1800
        assert config.bcrypt_rounds == 8

    def test_multiple_env_vars(self, clear_env, monkeypatch):
        """测试多个环境变量同时设置"""
        monkeypatch.setenv('PYFILESERV_PORT', '1234')
        monkeypatch.setenv('PYFILESERV_HOST', '0.0.0.0')
        monkeypatch.setenv('PYFILESERV_DB_TYPE', 'postgres')
        monkeypatch.setenv('PYFILESERV_SESSION_TIMEOUT', '9999')
        config = ServerConfig()
        config.load_from_env()
        assert config.port == 1234
        assert config.host == '0.0.0.0'
        assert config.database.type == 'postgres'
        assert config.session_timeout == 9999

    def test_env_var_ip_restriction(self, clear_env, monkeypatch):
        """测试环境变量 IP 限制"""
        monkeypatch.setenv('PYFILESERV_IP_WHITELIST', '192.168.1.0/24, 10.0.0.1')
        monkeypatch.setenv('PYFILESERV_IP_BLACKLIST', '192.168.2.5, 192.168.2.6')
        config = ServerConfig()
        config.load_from_env()
        assert config.ip_whitelist == ["192.168.1.0/24", "10.0.0.1"]
        assert config.ip_blacklist == ["192.168.2.5", "192.168.2.6"]


class TestIpRestriction:
    """IP 限制功能测试"""

    def test_no_restriction_allows_all(self):
        """测试没有限制时允许所有 IP"""
        config = ServerConfig()
        assert config.is_ip_allowed("192.168.1.1") is True
        assert config.is_ip_allowed("10.0.0.1") is True
        assert config.is_ip_allowed("8.8.8.8") is True

    def test_whitelist_only_allowed_ips(self):
        """测试白名单只允许指定 IP"""
        config = ServerConfig()
        config.ip_whitelist = ["192.168.1.1", "192.168.1.2"]

        assert config.is_ip_allowed("192.168.1.1") is True
        assert config.is_ip_allowed("192.168.1.2") is True
        assert config.is_ip_allowed("192.168.1.3") is False
        assert config.is_ip_allowed("10.0.0.1") is False

    def test_blacklist_blocks_specific_ips(self):
        """测试黑名单禁止指定 IP"""
        config = ServerConfig()
        config.ip_blacklist = ["10.0.0.1", "10.0.0.2"]

        assert config.is_ip_allowed("192.168.1.1") is True
        assert config.is_ip_allowed("10.0.0.1") is False
        assert config.is_ip_allowed("10.0.0.2") is False
        assert config.is_ip_allowed("10.0.0.3") is True

    def test_whitelist_has_priority(self):
        """测试白名单优先于黑名单"""
        config = ServerConfig()
        config.ip_whitelist = ["192.168.1.1"]
        config.ip_blacklist = ["192.168.1.1"]

        assert config.is_ip_allowed("192.168.1.1") is True

    def test_cidr_format_support(self):
        """测试 CIDR 格式支持"""
        config = ServerConfig()
        config.ip_whitelist = ["192.168.1.0/24"]

        assert config.is_ip_allowed("192.168.1.1") is True
        assert config.is_ip_allowed("192.168.1.254") is True
        assert config.is_ip_allowed("192.168.2.1") is False


class TestConfigProperties:
    """配置属性测试"""

    def test_use_https_property(self):
        """测试 use_https 属性"""
        config = ServerConfig()
        assert config.use_https is False

        config.ssl_cert = Path('cert.pem')
        assert config.use_https is False

        config.ssl_key = Path('key.pem')
        assert config.use_https is True

    def test_use_database_property(self):
        """测试 use_database 属性"""
        config = ServerConfig()
        assert config.use_database is False

        config.database.type = 'postgres'
        assert config.use_database is True

        config.database.type = 'json'
        assert config.use_database is False

    def test_get_users_file_path(self, tmp_path):
        """测试获取用户文件路径"""
        config = ServerConfig()
        assert config.get_users_file_path() == Path('users.json')

        config.config_dir = tmp_path
        assert config.get_users_file_path() == tmp_path / 'users.json'

        config.users_file = 'custom.json'
        assert config.get_users_file_path() == tmp_path / 'custom.json'

    def test_get_config_file_path(self, tmp_path):
        """测试获取配置文件路径"""
        config = ServerConfig()
        config.config_dir = tmp_path
        assert config.get_config_file_path() == tmp_path / 'config.yml'


class TestDatabaseConfig:
    """DatabaseConfig 独立测试"""

    def test_database_config_defaults(self):
        """测试数据库配置默认值"""
        db_config = DatabaseConfig()
        assert db_config.type == 'json'
        assert db_config.host == 'localhost'
        assert db_config.port == 5432
        assert db_config.database == 'pyfileserv'
        assert db_config.username is None
        assert db_config.password is None
        assert db_config.pool_size == 5
        assert db_config.max_overflow == 10

    def test_database_config_custom(self):
        """测试数据库配置自定义值"""
        db_config = DatabaseConfig(
            type='postgres',
            host='db.example.com',
            port=5433,
            database='mydb',
            username='user',
            password='pass',
            pool_size=20,
            max_overflow=30
        )
        assert db_config.type == 'postgres'
        assert db_config.host == 'db.example.com'
        assert db_config.port == 5433
        assert db_config.database == 'mydb'
        assert db_config.username == 'user'
        assert db_config.password == 'pass'
        assert db_config.pool_size == 20
        assert db_config.max_overflow == 30

    def test_database_config_to_dict(self):
        """测试数据库配置转换为字典"""
        db_config = DatabaseConfig(
            type='postgres',
            host='test.host',
            port=1234,
            database='testdb',
            username='testuser',
            password='testpass',
            pool_size=8,
            max_overflow=15
        )
        data = db_config.to_dict()
        assert data['type'] == 'postgres'
        assert data['host'] == 'test.host'
        assert data['port'] == 1234
        assert data['database'] == 'testdb'
        assert data['username'] == 'testuser'
        assert data['password'] == 'testpass'
        assert data['pool_size'] == 8
        assert data['max_overflow'] == 15

    def test_database_config_from_dict(self):
        """测试从字典创建数据库配置"""
        data = {
            'type': 'postgres',
            'host': 'dict.host',
            'port': 5678,
            'database': 'dictdb',
            'username': 'dictuser',
            'password': 'dictpass',
            'pool_size': 12,
            'max_overflow': 18
        }
        db_config = DatabaseConfig.from_dict(data)
        assert db_config.type == 'postgres'
        assert db_config.host == 'dict.host'
        assert db_config.port == 5678
        assert db_config.database == 'dictdb'
        assert db_config.username == 'dictuser'
        assert db_config.password == 'dictpass'
        assert db_config.pool_size == 12
        assert db_config.max_overflow == 18


class TestDefaultConfigYaml:
    """默认配置 YAML 测试"""

    def test_get_default_config_yaml_returns_string(self):
        """测试获取默认配置返回字符串"""
        content = get_default_config_yaml()
        assert isinstance(content, str)
        assert len(content) > 0

    def test_get_default_config_yaml_contains_sections(self):
        """测试默认配置包含所有必需的段"""
        content = get_default_config_yaml()
        assert 'server:' in content
        assert 'paths:' in content
        assert 'ssl:' in content
        assert 'database:' in content
        assert 'session:' in content
        assert 'security:' in content
        assert 'ip_restriction:' in content

    def test_get_default_config_yaml_contains_timestamp(self):
        """测试默认配置包含时间戳"""
        content = get_default_config_yaml()
        assert '生成时间:' in content
