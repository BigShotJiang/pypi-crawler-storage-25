"""管理员页面功能测试"""
import json
import tempfile
from pathlib import Path


def test_imports():
    """测试导入是否正常"""
    from file_server.template import render_admin_page
    assert render_admin_page is not None

    from file_server.handle.admin import AdminHandler
    assert AdminHandler is not None

    from file_server.handlers import SecureHTTPRequestHandler
    assert SecureHTTPRequestHandler is not None

    from file_server.server import run_server
    assert run_server is not None


def test_admin_template():
    """测试管理员模板渲染"""
    from file_server.template import render_admin_page

    users = [
        {'username': 'admin', 'created_at': '2024-01-01 12:00:00'},
        {'username': 'user1', 'created_at': '2024-01-02 13:00:00'},
        {'username': 'user2', 'created_at': '2024-01-03 14:00:00'},
    ]

    html = render_admin_page('admin', users)

    assert '<title>用户管理 - 文件服务器</title>' in html
    assert 'admin' in html
    assert 'user1' in html
    assert 'user2' in html
    assert '创建新用户' in html
    assert len(html) > 0


def test_admin_handler():
    """测试管理员处理器"""
    from file_server.handle.admin import AdminHandler
    from file_server.core.auth import UserStore

    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({
            'admin': {'password': 'test_hash', 'created_at': '1234567890'},
            'user1': {'password': 'test_hash', 'created_at': '1234567891'}
        }, f)
        temp_file = f.name

    try:
        user_store = UserStore(Path(temp_file))
        admin_handler = AdminHandler(user_store)
        assert admin_handler is not None

        users_data = user_store.load_users()
        assert 'admin' in users_data
        assert 'user1' in users_data
    finally:
        Path(temp_file).unlink()
