"""管理员权限控制 - UserStore 测试"""
import json
import tempfile
from pathlib import Path

import pytest

from file_server.core.auth import UserStore


@pytest.fixture
def temp_users_file():
    """创建临时用户文件"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({}, f)
        temp_path = Path(f.name)
    yield temp_path
    # 清理
    if temp_path.exists():
        temp_path.unlink()


@pytest.fixture
def user_store(temp_users_file):
    """创建 UserStore 实例"""
    return UserStore(temp_users_file)


class TestUserStoreAdmin:
    """UserStore 管理员功能测试"""

    def test_add_user_default_not_admin(self, user_store):
        """测试添加用户默认为非管理员"""
        user_store.add_user("testuser", "hashed_password")
        
        user_data = user_store.get_user("testuser")
        assert user_data is not None
        assert user_data.get("is_admin") is False

    def test_add_user_as_admin(self, user_store):
        """测试添加管理员用户"""
        user_store.add_user("admin", "hashed_password", is_admin=True)
        
        user_data = user_store.get_user("admin")
        assert user_data is not None
        assert user_data.get("is_admin") is True

    def test_add_user_explicit_not_admin(self, user_store):
        """测试显式添加非管理员用户"""
        user_store.add_user("user1", "hashed_password", is_admin=False)
        
        user_data = user_store.get_user("user1")
        assert user_data is not None
        assert user_data.get("is_admin") is False

    def test_is_admin_returns_true_for_admin(self, user_store):
        """测试 is_admin 对管理员返回 True"""
        user_store.add_user("admin", "hashed_password", is_admin=True)
        
        assert user_store.is_admin("admin") is True

    def test_is_admin_returns_false_for_normal_user(self, user_store):
        """测试 is_admin 对普通用户返回 False"""
        user_store.add_user("user1", "hashed_password", is_admin=False)
        
        assert user_store.is_admin("user1") is False

    def test_is_admin_returns_false_for_nonexistent_user(self, user_store):
        """测试 is_admin 对不存在的用户返回 False"""
        assert user_store.is_admin("nonexistent") is False

    def test_set_admin_status_to_true(self, user_store):
        """测试设置用户为管理员"""
        user_store.add_user("user1", "hashed_password", is_admin=False)
        
        result = user_store.set_admin_status("user1", True)
        
        assert result is True
        assert user_store.is_admin("user1") is True

    def test_set_admin_status_to_false(self, user_store):
        """测试取消用户管理员状态"""
        user_store.add_user("admin", "hashed_password", is_admin=True)
        
        result = user_store.set_admin_status("admin", False)
        
        assert result is True
        assert user_store.is_admin("admin") is False

    def test_set_admin_status_nonexistent_user(self, user_store):
        """测试设置不存在用户的管理员状态"""
        result = user_store.set_admin_status("nonexistent", True)
        
        assert result is False

    def test_load_users_includes_is_admin(self, user_store):
        """测试加载用户时包含 is_admin 字段"""
        user_store.add_user("admin", "hash1", is_admin=True)
        user_store.add_user("user1", "hash2", is_admin=False)
        
        users = user_store.load_users()
        
        assert "admin" in users
        assert "user1" in users
        assert users["admin"]["is_admin"] is True
        assert users["user1"]["is_admin"] is False

    def test_backward_compatibility_missing_is_admin(self, temp_users_file):
        """测试向后兼容性 - 缺少 is_admin 字段的旧数据"""
        # 手动创建不包含 is_admin 的旧格式数据
        old_data = {
            "olduser": {
                "password": "old_hash",
                "created_at": "1234567890"
            }
        }
        with open(temp_users_file, 'w') as f:
            json.dump(old_data, f)
        
        user_store = UserStore(temp_users_file)
        
        # get_user 应该能正常读取
        user_data = user_store.get_user("olduser")
        assert user_data is not None
        assert user_data.get("is_admin", False) is False
        
        # is_admin 应该返回 False
        assert user_store.is_admin("olduser") is False

    def test_multiple_users_mixed_admin_status(self, user_store):
        """测试多个用户混合管理员状态"""
        user_store.add_user("admin1", "hash1", is_admin=True)
        user_store.add_user("admin2", "hash2", is_admin=True)
        user_store.add_user("user1", "hash3", is_admin=False)
        user_store.add_user("user2", "hash4", is_admin=False)
        
        assert user_store.is_admin("admin1") is True
        assert user_store.is_admin("admin2") is True
        assert user_store.is_admin("user1") is False
        assert user_store.is_admin("user2") is False

    def test_toggle_admin_status(self, user_store):
        """测试切换管理员状态"""
        user_store.add_user("user1", "hash", is_admin=False)
        
        # 切换为管理员
        user_store.set_admin_status("user1", True)
        assert user_store.is_admin("user1") is True
        
        # 再切换回普通用户
        user_store.set_admin_status("user1", False)
        assert user_store.is_admin("user1") is False

    def test_admin_status_persists_after_reload(self, user_store, temp_users_file):
        """测试管理员状态在重新加载后保持"""
        user_store.add_user("admin", "hash", is_admin=True)
        
        # 创建新的 UserStore 实例（模拟重启）
        new_store = UserStore(temp_users_file)
        
        assert new_store.is_admin("admin") is True
