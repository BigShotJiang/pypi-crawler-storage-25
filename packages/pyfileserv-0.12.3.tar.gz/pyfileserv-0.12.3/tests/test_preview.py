"""测试 file_server.handle.preview PreviewMixin 预览分发逻辑"""
import sys
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestPreviewDispatch:
    """测试预览请求分发到正确的处理器方法"""

    @pytest.fixture
    def handler(self):
        """创建一个模拟的 handler 实例"""
        # 动态组装一个类，包含 PreviewMixin 和必要的依赖
        from file_server.handle.preview import PreviewMixin

        class MockHandler(PreviewMixin):
            def __init__(self):
                self.directory = None
                self.path = '/preview/'
                self.config = None
                self.session_manager = None
                self.user_store = None
                self._wfile = Mock()
                self._sent_response = None

            def is_authenticated(self):
                return True

            def get_current_username(self):
                return 'testuser'

            def send_error(self, code, msg):
                self._sent_response = ('error', code, msg)

            def _send_html_response(self, html):
                self._sent_response = ('html', html)

            def _serve_raw_file(self, file_path):
                self._sent_response = ('raw', str(file_path))

        return MockHandler()

    def _setup_handler(self, handler, filename, directory):
        """设置 handler 来模拟预览请求"""
        handler.directory = str(directory)
        handler.path = f'/preview/{filename}'

    def test_dispatch_to_image_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            img = dir_path / 'photo.jpg'
            img.write_bytes(b'fake-jpeg')
            self._setup_handler(handler, 'photo.jpg', dir_path)

            with patch.object(handler, '_handle_image_preview') as mock_img:
                handler._handle_preview()
                mock_img.assert_called_once()

    def test_dispatch_to_video_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            vid = dir_path / 'movie.mp4'
            vid.write_bytes(b'fake-mp4')
            self._setup_handler(handler, 'movie.mp4', dir_path)

            with patch.object(handler, '_handle_video_preview') as mock_vid:
                handler._handle_preview()
                mock_vid.assert_called_once()

    def test_dispatch_to_audio_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            aud = dir_path / 'song.mp3'
            aud.write_bytes(b'fake-mp3')
            self._setup_handler(handler, 'song.mp3', dir_path)

            with patch.object(handler, '_handle_audio_preview') as mock_aud:
                handler._handle_preview()
                mock_aud.assert_called_once()

    def test_dispatch_to_pdf_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'doc.pdf'
            f.write_bytes(b'fake-pdf')
            self._setup_handler(handler, 'doc.pdf', dir_path)

            with patch.object(handler, '_handle_pdf_preview') as mock_pdf:
                handler._handle_preview()
                mock_pdf.assert_called_once()

    def test_dispatch_to_markdown_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'README.md'
            f.write_bytes(b'# Hello')
            self._setup_handler(handler, 'README.md', dir_path)

            with patch.object(handler, '_handle_markdown_preview') as mock_md:
                handler._handle_preview()
                mock_md.assert_called_once()

    def test_dispatch_to_xmind_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'mindmap.xmind'
            f.write_bytes(b'fake-xmind')
            self._setup_handler(handler, 'mindmap.xmind', dir_path)

            with patch.object(handler, '_handle_xmind_preview') as mock_xm:
                handler._handle_preview()
                mock_xm.assert_called_once()

    def test_dispatch_to_docx_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'report.docx'
            f.write_bytes(b'fake-docx')
            self._setup_handler(handler, 'report.docx', dir_path)

            with patch.object(handler, '_handle_docx_preview') as mock_docx:
                handler._handle_preview()
                mock_docx.assert_called_once()

    def test_dispatch_to_xlsx_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'data.xlsx'
            f.write_bytes(b'fake-xlsx')
            self._setup_handler(handler, 'data.xlsx', dir_path)

            with patch.object(handler, '_handle_xlsx_preview') as mock_xlsx:
                handler._handle_preview()
                mock_xlsx.assert_called_once()

    def test_dispatch_to_pptx_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'slides.pptx'
            f.write_bytes(b'fake-pptx')
            self._setup_handler(handler, 'slides.pptx', dir_path)

            with patch.object(handler, '_handle_pptx_preview') as mock_pptx:
                handler._handle_preview()
                mock_pptx.assert_called_once()

    def test_dispatch_to_json_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'config.json'
            f.write_bytes(b'{"key": "value"}')
            self._setup_handler(handler, 'config.json', dir_path)

            with patch.object(handler, '_handle_json_preview') as mock_json:
                handler._handle_preview()
                mock_json.assert_called_once()

    def test_dispatch_to_text_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'script.py'
            f.write_bytes(b'print("hello")')
            self._setup_handler(handler, 'script.py', dir_path)

            with patch.object(handler, '_handle_text_preview') as mock_text:
                handler._handle_preview()
                mock_text.assert_called_once()

    def test_dispatch_to_html_preview(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'test.html'
            f.write_bytes(b'<h1>Test</h1>')
            self._setup_handler(handler, 'test.html', dir_path)

            with patch.object(handler, '_handle_html_preview') as mock_html:
                handler._handle_preview()
                mock_html.assert_called_once()

    def test_dispatch_other_type_raw_serve(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'archive.zip'
            f.write_bytes(b'fake-zip')
            self._setup_handler(handler, 'archive.zip', dir_path)

            handler._handle_preview()
            assert handler._sent_response is not None
            assert handler._sent_response[0] == 'raw'

    def test_unauthenticated_rejected(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            f = dir_path / 'test.txt'
            f.write_bytes(b'hello')
            self._setup_handler(handler, 'test.txt', dir_path)
            handler.is_authenticated = lambda: False

            handler._handle_preview()
            assert handler._sent_response == ('error', 403, 'Forbidden')

    def test_path_traversal_rejected(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            handler.directory = str(dir_path)
            handler.path = '/preview/../../../etc/passwd'

            handler._handle_preview()
            assert handler._sent_response == ('error', 403, 'Forbidden')

    def test_nonexistent_file_returns_404(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            handler.directory = str(dir_path)
            handler.path = '/preview/nonexistent.txt'

            handler._handle_preview()
            assert handler._sent_response == ('error', 404, 'File not found')


class TestMediaPreviewDispatch:
    """测试 _handle_media_preview 通用方法"""

    @pytest.fixture
    def handler(self):
        from file_server.handle.preview import PreviewMixin

        class MockHandler(PreviewMixin):
            def __init__(self):
                self.directory = None
                self.config = None
                self.session_manager = None
                self.user_store = None
                self._html = None

            def _send_html_response(self, html):
                self._html = html

        return MockHandler()

    def test_media_preview_collects_sibling_files(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            (dir_path / 'photo1.jpg').write_bytes(b'')
            (dir_path / 'photo2.jpg').write_bytes(b'')
            (dir_path / 'not_an_image.txt').write_bytes(b'')
            handler.directory = str(dir_path)

            def render_func(username, file_path, file_name, urls, index, is_admin):
                assert len(urls) == 2
                assert 'photo1.jpg' in urls[0]
                assert 'photo2.jpg' in urls[1]
                assert urls
                return '<html>test</html>'

            handler._handle_media_preview('user', 'photo1.jpg', 'photo1.jpg',
                                          'image', render_func)
            assert handler._html == '<html>test</html>'

    def test_media_preview_gets_current_index(self, handler):
        with tempfile.TemporaryDirectory() as td:
            dir_path = Path(td)
            (dir_path / 'a.jpg').write_bytes(b'')
            (dir_path / 'b.jpg').write_bytes(b'')
            (dir_path / 'c.jpg').write_bytes(b'')
            handler.directory = str(dir_path)

            def render_func(username, file_path, file_name, urls, index, is_admin):
                assert index == 1  # b.jpg is the second image
                return '<html>ok</html>'

            handler._handle_media_preview('user', 'b.jpg', 'b.jpg',
                                          'image', render_func)
            assert handler._html == '<html>ok</html>'
