"""测试 PostgreSQL 分享数据存储模块"""
import os
import time

import pytest

# 仅在 PostgreSQL 可用时运行
try:
    import psycopg2
    from psycopg2.extras import DictCursor
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False

# 获取数据库连接参数
DB_HOST = os.environ.get("PYFILESERV_TEST_DB_HOST", "localhost")
DB_PORT = int(os.environ.get("PYFILESERV_TEST_DB_PORT", "5432"))
DB_NAME = os.environ.get("PYFILESERV_TEST_DB_NAME", "pyfileserv_test")
DB_USER = os.environ.get("PYFILESERV_TEST_DB_USER", "postgres")
DB_PASS = os.environ.get("PYFILESERV_TEST_DB_PASS", "")


pytestmark = pytest.mark.skipif(
    not POSTGRES_AVAILABLE,
    reason="psycopg2 not installed, run: pip install psycopg2-binary"
)


def _get_db():
    """创建测试数据库连接"""
    return psycopg2.connect(
        host=DB_HOST, port=DB_PORT, database=DB_NAME,
        user=DB_USER, password=DB_PASS
    )


def _setup_test_table(conn):
    """创建测试表"""
    with conn.cursor() as cur:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS shares (
                share_id VARCHAR(32) PRIMARY KEY,
                file_path TEXT NOT NULL,
                password_hash TEXT,
                expires_at DOUBLE PRECISION,
                max_downloads INTEGER,
                download_count INTEGER DEFAULT 0,
                created_at DOUBLE PRECISION NOT NULL,
                created_by VARCHAR(255),
                is_deleted BOOLEAN DEFAULT FALSE,
                deleted_at DOUBLE PRECISION
            )
        """)
        cur.execute("TRUNCATE shares")
    conn.commit()


def _drop_test_table(conn):
    """删除测试表"""
    with conn.cursor() as cur:
        cur.execute("DROP TABLE IF EXISTS shares")
    conn.commit()


class TestDatabaseShareStore:
    """测试 DatabaseShareStore 类"""

    @classmethod
    def setup_class(cls):
        """创建数据库连接和表"""
        try:
            cls.conn = _get_db()
            _setup_test_table(cls.conn)
        except psycopg2.OperationalError as e:
            pytest.skip(f"PostgreSQL test database not available: {e}")
        from file_server.db import DatabaseConnection, DatabaseShareStore
        cls.db = DatabaseConnection(
            host=DB_HOST, port=DB_PORT, database=DB_NAME,
            username=DB_USER, password=DB_PASS
        )
        cls.db.connect()
        cls.store = DatabaseShareStore(cls.db)

    @classmethod
    def teardown_class(cls):
        """清理数据库"""
        if hasattr(cls, 'conn'):
            _drop_test_table(cls.conn)
            cls.conn.close()
        if hasattr(cls, 'db'):
            cls.db.disconnect()

    def _make_data(self, file_path="test.txt", password_hash=None,
                   expires_in=3600, max_downloads=None, is_deleted=False):
        """辅助函数：构造分享数据"""
        return {
            'file_path': file_path,
            'password_hash': password_hash,
            'expires_at': time.time() + expires_in if expires_in else None,
            'max_downloads': max_downloads,
            'download_count': 0,
            'created_at': time.time(),
            'created_by': 'test_user',
            'is_deleted': is_deleted,
        }

    # ========== 创建和获取 ==========

    def test_create_and_get(self):
        """创建后读取"""
        data = self._make_data()
        self.store.create_share('db_test_1', data)
        share = self.store.get_share('db_test_1')
        assert share is not None
        assert share['file_path'] == 'test.txt'
        assert share['share_id'] == 'db_test_1'

    def test_get_not_exists(self):
        assert self.store.get_share('nonexistent_db') is None

    def test_get_expired(self):
        """过期分享 get_share 返回 None"""
        data = self._make_data(expires_in=-100)
        self.store.create_share('db_expired', data)
        assert self.store.get_share('db_expired') is None

    def test_get_deleted(self):
        """删除分享 get_share 返回 None"""
        data = self._make_data(is_deleted=True)
        self.store.create_share('db_deleted', data)
        assert self.store.get_share('db_deleted') is None

    def test_get_share_any(self):
        """get_share_any 返回任意状态"""
        data = self._make_data(expires_in=-100)
        self.store.create_share('db_any', data)
        share = self.store.get_share_any('db_any')
        assert share is not None

    # ========== 管理列表 ==========

    def test_list_shares_for_management(self):
        """列出所有分享含状态"""
        self.store.create_share('m_active', self._make_data(expires_in=86400))
        self.store.create_share('m_expired', self._make_data(expires_in=-100))
        self.store.create_share('m_deleted', self._make_data(expires_in=86400, is_deleted=True))

        shares = self.store.list_shares_for_management()
        # 查找我们的测试数据
        test_shares = [s for s in shares if s['share_id'].startswith('m_')]
        statuses = {s['share_id']: s['status'] for s in test_shares}
        assert statuses.get('m_active') == 'active'
        assert statuses.get('m_expired') == 'expired'
        assert statuses.get('m_deleted') == 'deleted'

    def test_list_shares_has_password(self):
        """has_password 标志"""
        from file_server.core.auth import PasswordHasher
        hasher = PasswordHasher(rounds=4)
        self.store.create_share('m_pwd', self._make_data(
            password_hash=hasher.hash_password('secret')
        ))
        shares = [s for s in self.store.list_shares_for_management() if s['share_id'] == 'm_pwd']
        assert len(shares) == 1
        assert shares[0]['has_password'] is True

    # ========== 更新 ==========

    def test_update_share(self):
        """更新字段"""
        self.store.create_share('db_up', self._make_data(max_downloads=5))
        new_expires = time.time() + 7200
        ok = self.store.update_share('db_up', {'expires_at': new_expires, 'max_downloads': 10})
        assert ok is True
        share = self.store.get_share('db_up')
        assert share['max_downloads'] == 10

    def test_update_invalid_field(self):
        """非白名单字段被忽略"""
        self.store.create_share('db_up2', self._make_data())
        ok = self.store.update_share('db_up2', {'file_path': 'hack.txt'})
        assert ok is False

    # ========== 删除 ==========

    def test_soft_delete(self):
        """软删除"""
        self.store.create_share('db_sd', self._make_data())
        assert self.store.soft_delete_share('db_sd') is True
        assert self.store.get_share('db_sd') is None
        # 管理页可见
        any_share = self.store.get_share_any('db_sd')
        assert any_share['is_deleted'] is True
        assert any_share['deleted_at'] is not None

    def test_soft_double_delete(self):
        """重复软删除返回 False"""
        self.store.create_share('db_sd2', self._make_data(is_deleted=True))
        assert self.store.soft_delete_share('db_sd2') is False

    def test_permanent_delete(self):
        """永久删除"""
        self.store.create_share('db_pd', self._make_data(is_deleted=True))
        assert self.store.permanent_delete_share('db_pd') is True
        assert self.store.get_share_any('db_pd') is None

    def test_permanent_delete_active(self):
        """活跃分享不可永久删除"""
        self.store.create_share('db_pd2', self._make_data())
        assert self.store.permanent_delete_share('db_pd2') is False

    # ========== 下载 ==========

    def test_record_download(self):
        """记录下载"""
        self.store.create_share('db_dl', self._make_data())
        self.store.record_download('db_dl')
        share = self.store.get_share('db_dl')
        assert share['download_count'] == 1

    # ========== 按文件查询 ==========

    def test_get_file_shares(self):
        """按文件查询有效分享"""
        self.store.create_share('db_f1', self._make_data('f1.txt', expires_in=86400))
        self.store.create_share('db_f2', self._make_data('f1.txt', expires_in=86400))
        self.store.create_share('db_f3', self._make_data('f2.txt', expires_in=86400))
        self.store.create_share('db_f4', self._make_data('f1.txt', expires_in=-100))

        result = self.store.get_file_shares('f1.txt')
        ids = [r['share_id'] for r in result]
        assert 'db_f1' in ids
        assert 'db_f2' in ids
        assert 'db_f4' not in ids  # 过期
