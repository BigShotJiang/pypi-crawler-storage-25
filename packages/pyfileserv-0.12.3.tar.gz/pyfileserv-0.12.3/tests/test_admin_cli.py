"""管理员权限控制 - CLI 命令测试"""
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from file_server.cli import _create_user, _list_users, _set_admin_status
from file_server.core.auth import UserStore, PasswordHasher


@pytest.fixture
def temp_users_file():
    """创建临时用户文件"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({}, f)
        temp_path = Path(f.name)
    yield temp_path
    if temp_path.exists():
        temp_path.unlink()


@pytest.fixture
def user_store(temp_users_file):
    """创建 UserStore 实例"""
    return UserStore(temp_users_file)


@pytest.fixture
def hasher():
    """创建密码哈希器"""
    return PasswordHasher()


class TestCLICreateUserAdmin:
    """CLI 创建用户管理员功能测试"""

    def test_create_user_as_admin(self, user_store, hasher):
        """测试创建管理员用户"""
        # 模拟用户输入
        inputs = iter(["yes"])  # 设置为管理员
        
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            with patch('getpass.getpass', return_value="password123"):
                _create_user(user_store, hasher, "admin")
        
        # 验证用户被创建为管理员
        assert user_store.is_admin("admin") is True

    def test_create_user_as_normal_user(self, user_store, hasher):
        """测试创建普通用户"""
        # 模拟用户输入
        inputs = iter(["no"])  # 不设置为管理员
        
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            with patch('getpass.getpass', return_value="password123"):
                _create_user(user_store, hasher, "user1")
        
        # 验证用户被创建为普通用户
        assert user_store.is_admin("user1") is False

    def test_create_user_default_not_admin(self, user_store, hasher):
        """测试创建用户默认为非管理员（空输入）"""
        # 模拟用户输入
        inputs = iter([""])  # 空输入，默认为 no
        
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            with patch('getpass.getpass', return_value="password123"):
                _create_user(user_store, hasher, "user2")
        
        # 验证用户默认为非管理员
        assert user_store.is_admin("user2") is False

    def test_create_user_output_shows_admin_status(self, user_store, hasher, capsys):
        """测试创建用户输出显示管理员状态"""
        inputs = iter(["yes"])
        
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            with patch('getpass.getpass', return_value="password123"):
                _create_user(user_store, hasher, "admin")
        
        captured = capsys.readouterr()
        assert "[管理员]" in captured.out


class TestCLIListUsersAdmin:
    """CLI 列出用户管理员功能测试"""

    def test_list_users_shows_admin_marker(self, user_store, hasher, capsys):
        """测试列出用户时显示管理员标记"""
        user_store.add_user("admin", "hash1", is_admin=True)
        user_store.add_user("user1", "hash2", is_admin=False)
        user_store.add_user("user2", "hash3", is_admin=False)
        
        _list_users(user_store)
        
        captured = capsys.readouterr()
        assert "admin [管理员]" in captured.out
        assert "user1" in captured.out
        assert "[管理员]" not in captured.out.split("user1")[1].split("user2")[0]

    def test_list_users_multiple_admins(self, user_store, hasher, capsys):
        """测试列出多个管理员用户"""
        user_store.add_user("admin1", "hash1", is_admin=True)
        user_store.add_user("admin2", "hash2", is_admin=True)
        user_store.add_user("user1", "hash3", is_admin=False)
        
        _list_users(user_store)
        
        captured = capsys.readouterr()
        assert "admin1 [管理员]" in captured.out
        assert "admin2 [管理员]" in captured.out
        assert "user1" in captured.out

    def test_list_users_no_admins(self, user_store, hasher, capsys):
        """测试列出无管理员的用户列表"""
        user_store.add_user("user1", "hash1", is_admin=False)
        user_store.add_user("user2", "hash2", is_admin=False)
        
        _list_users(user_store)
        
        captured = capsys.readouterr()
        assert "[管理员]" not in captured.out


class TestCLISetAdminStatus:
    """CLI 设置管理员状态功能测试"""

    def test_set_user_as_admin(self, user_store, capsys):
        """测试设置用户为管理员"""
        user_store.add_user("user1", "hash", is_admin=False)
        
        # 模拟用户输入
        inputs = iter(["yes"])
        
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            _set_admin_status(user_store, "user1")
        
        # 验证用户被设置为管理员
        assert user_store.is_admin("user1") is True
        
        captured = capsys.readouterr()
        assert "已设置为管理员" in captured.out

    def test_unset_admin_status(self, user_store, capsys):
        """测试取消用户管理员状态"""
        user_store.add_user("admin", "hash", is_admin=True)
        
        # 模拟用户输入
        inputs = iter(["no"])
        
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            _set_admin_status(user_store, "admin")
        
        # 验证用户被取消管理员状态
        assert user_store.is_admin("admin") is False
        
        captured = capsys.readouterr()
        assert "已设置为普通用户" in captured.out

    def test_set_admin_status_nonexistent_user(self, user_store, capsys):
        """测试设置不存在用户的管理员状态"""
        _set_admin_status(user_store, "nonexistent")
        
        captured = capsys.readouterr()
        assert "不存在" in captured.out

    def test_set_admin_status_no_change(self, user_store, capsys):
        """测试管理员状态未改变"""
        user_store.add_user("user1", "hash", is_admin=False)
        
        # 模拟用户输入，保持为非管理员
        inputs = iter(["no"])
        
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            _set_admin_status(user_store, "user1")
        
        captured = capsys.readouterr()
        assert "未改变" in captured.out

    def test_set_admin_status_invalid_input(self, user_store, capsys):
        """测试设置管理员状态时输入无效"""
        user_store.add_user("user1", "hash", is_admin=False)
        
        # 模拟用户输入无效值
        inputs = iter(["invalid"])
        
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            _set_admin_status(user_store, "user1")
        
        captured = capsys.readouterr()
        assert "请输入 yes 或 no" in captured.out

    def test_set_admin_status_shows_current_status(self, user_store, capsys):
        """测试显示当前管理员状态"""
        user_store.add_user("user1", "hash", is_admin=False)
        
        inputs = iter(["yes"])
        
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            _set_admin_status(user_store, "user1")
        
        captured = capsys.readouterr()
        assert "当前管理员状态:" in captured.out

    def test_set_admin_status_yes_variants(self, user_store):
        """测试 'yes' 的各种变体输入"""
        user_store.add_user("user1", "hash", is_admin=False)
        
        for yes_input in ["yes", "YES", "Yes", "y", "Y"]:
            user_store.set_admin_status("user1", False)  # 重置
            
            inputs = iter([yes_input])
            with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
                _set_admin_status(user_store, "user1")
            
            assert user_store.is_admin("user1") is True

    def test_set_admin_status_no_variants(self, user_store):
        """测试 'no' 的各种变体输入"""
        user_store.add_user("admin", "hash", is_admin=True)
        
        for no_input in ["no", "NO", "No", "n", "N"]:
            user_store.set_admin_status("admin", True)  # 重置
            
            inputs = iter([no_input])
            with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
                _set_admin_status(user_store, "admin")
            
            assert user_store.is_admin("admin") is False


class TestCLIIntegration:
    """CLI 集成测试"""

    def test_full_workflow_create_and_promote(self, user_store, hasher, capsys):
        """测试完整工作流程：创建用户并提升为管理员"""
        # 1. 创建普通用户
        inputs = iter(["no"])
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            with patch('getpass.getpass', return_value="password123"):
                _create_user(user_store, hasher, "newuser")
        
        assert user_store.is_admin("newuser") is False
        
        # 2. 提升为管理员
        inputs = iter(["yes"])
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            _set_admin_status(user_store, "newuser")
        
        assert user_store.is_admin("newuser") is True

    def test_full_workflow_demote_admin(self, user_store, hasher, capsys):
        """测试完整工作流程：创建管理员并降级为普通用户"""
        # 1. 创建管理员
        inputs = iter(["yes"])
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            with patch('getpass.getpass', return_value="password123"):
                _create_user(user_store, hasher, "tempadmin")
        
        assert user_store.is_admin("tempadmin") is True
        
        # 2. 降级为普通用户
        inputs = iter(["no"])
        with patch('builtins.input', side_effect=lambda prompt: next(inputs)):
            _set_admin_status(user_store, "tempadmin")
        
        assert user_store.is_admin("tempadmin") is False
