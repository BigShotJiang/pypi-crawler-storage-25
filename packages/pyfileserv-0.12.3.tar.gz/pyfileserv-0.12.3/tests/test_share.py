"""测试文件分享模块 — ShareManager 业务逻辑层"""
import tempfile
import time
from pathlib import Path

from file_server.core.auth import PasswordHasher
from file_server.core.share import ShareManager
from file_server.core.share_store import ShareStore


class TestShareManager:
    """测试 ShareManager 类（业务逻辑层 + JSON 存储）"""

    def setup_method(self):
        """每个测试前创建 ShareStore + PasswordHasher + ShareManager"""
        self.temp_dir = tempfile.mkdtemp()
        self.data_file = Path(self.temp_dir) / "shares.json"
        self.hasher = PasswordHasher(rounds=4)  # 低轮数以加速测试
        self.store = ShareStore(self.data_file, self.hasher)
        self.share_manager = ShareManager(self.store, self.hasher)

    def teardown_method(self):
        """清理临时目录"""
        import shutil
        shutil.rmtree(self.temp_dir)

    # ========== 创建分享 ==========

    def test_create_share(self):
        """创建分享 — 密码哈希存储，明文仅返回一次"""
        result = self.share_manager.create_share(
            file_path="test.txt",
            password="123456",
            expires_in=3600,
            max_downloads=5
        )

        assert "share_id" in result
        assert result["file_path"] == "test.txt"
        assert result["password"] == "123456"       # 返回明文
        assert "password_hash" not in result         # 不暴露哈希
        assert result["expires_at"] is not None
        assert result["max_downloads"] == 5
        assert result["download_count"] == 0

        # 存储中应为哈希值
        stored = self.store.get_share(result["share_id"])
        assert stored is not None
        assert stored.get("password_hash") is not None
        assert "password" not in stored
        assert self.hasher.verify_password("123456", stored["password_hash"])

    def test_create_share_without_password(self):
        """创建无密码分享"""
        result = self.share_manager.create_share(file_path="test.txt")
        assert result["password"] is None

    def test_create_share_without_expiration(self):
        """创建永不过期的分享"""
        result = self.share_manager.create_share(file_path="test.txt", expires_in=None)
        assert result["expires_at"] is None

    # ========== 获取分享 ==========

    def test_get_share_exists(self):
        """获取存在的分享"""
        result = self.share_manager.create_share("test.txt", "123456")
        retrieved = self.share_manager.get_share(result["share_id"])
        assert retrieved is not None
        assert retrieved["file_path"] == "test.txt"
        assert retrieved["has_password"] is True

    def test_get_share_not_exists(self):
        """获取不存在的分享"""
        assert self.share_manager.get_share("nonexistent") is None

    def test_get_share_expired(self):
        """获取过期的分享应返回 None（不再自动硬删除）"""
        result = self.share_manager.create_share("test.txt", expires_in=-3600)
        retrieved = self.share_manager.get_share(result["share_id"])
        assert retrieved is None
        # 过期分享仍存在于存储中（管理页面可见）
        any_share = self.store.get_share_any(result["share_id"])
        assert any_share is not None

    def test_get_share_no_password(self):
        """无密码分享 has_password 应为 False"""
        result = self.share_manager.create_share("test.txt")
        retrieved = self.share_manager.get_share(result["share_id"])
        assert retrieved["has_password"] is False

    # ========== 验证访问 ==========

    def test_validate_access_valid(self):
        """有效密码验证"""
        result = self.share_manager.create_share("test.txt", "correct")
        valid, info = self.share_manager.validate_access(result["share_id"], "correct")
        assert valid is True
        assert info["share_id"] == result["share_id"]

    def test_validate_access_wrong_password(self):
        """错误密码验证"""
        result = self.share_manager.create_share("test.txt", "correct")
        valid, error = self.share_manager.validate_access(result["share_id"], "wrong")
        assert valid is False
        assert "密码错误" in error

    def test_validate_access_no_password_required(self):
        """无需密码的分享不需要验证"""
        result = self.share_manager.create_share("test.txt")
        valid, info = self.share_manager.validate_access(result["share_id"])
        assert valid is True

    def test_validate_access_no_password_but_provided(self):
        """无密码分享提供密码也应通过（宽松行为）"""
        result = self.share_manager.create_share("test.txt")
        valid, info = self.share_manager.validate_access(result["share_id"], "anything")
        assert valid is True

    def test_validate_access_expired(self):
        """过期分享验证失败"""
        result = self.share_manager.create_share("test.txt", expires_in=-3600)
        valid, error = self.share_manager.validate_access(result["share_id"])
        assert valid is False
        assert "不存在或已过期" in error

    def test_validate_access_max_downloads(self):
        """下载次数超限验证失败"""
        result = self.share_manager.create_share("test.txt", max_downloads=2)
        self.share_manager.record_download(result["share_id"])
        self.share_manager.record_download(result["share_id"])
        valid, error = self.share_manager.validate_access(result["share_id"])
        assert valid is False
        assert "下载次数已达上限" in error

    # ========== 记录下载 ==========

    def test_record_download(self):
        """记录下载次数递增"""
        result = self.share_manager.create_share("test.txt", max_downloads=5)
        share = self.share_manager.get_share(result["share_id"])
        assert share["download_count"] == 0

        self.share_manager.record_download(result["share_id"])
        share = self.share_manager.get_share(result["share_id"])
        assert share["download_count"] == 1

    # ========== 软删除 ==========

    def test_delete_share_soft(self):
        """删除分享现在是软删除"""
        result = self.share_manager.create_share("test.txt")
        deleted = self.share_manager.delete_share(result["share_id"])
        assert deleted is True
        # get_share 返回 None
        assert self.share_manager.get_share(result["share_id"]) is None
        # 管理页仍可见
        shares = self.share_manager.list_shares()
        assert len(shares) == 1
        assert shares[0]["status"] == "deleted"

    def test_delete_share_not_exists(self):
        """删除不存在的分享返回 False"""
        assert self.share_manager.delete_share("nonexistent") is False

    # ========== 永久删除 ==========

    def test_permanent_delete_success(self):
        """软删除后可永久删除"""
        result = self.share_manager.create_share("test.txt")
        self.share_manager.delete_share(result["share_id"])
        assert self.share_manager.permanent_delete_share(result["share_id"]) is True
        assert self.share_manager.list_shares() == []

    def test_permanent_delete_active_fails(self):
        """活跃分享不能直接永久删除"""
        result = self.share_manager.create_share("test.txt")
        assert self.share_manager.permanent_delete_share(result["share_id"]) is False
        # 分享仍活跃
        assert self.share_manager.get_share(result["share_id"]) is not None

    # ========== 更新分享 ==========

    def test_update_share_expires(self):
        """更新过期时间"""
        result = self.share_manager.create_share("test.txt", expires_in=3600)
        new_expires = time.time() + 7200
        success = self.share_manager.update_share(result["share_id"], {"expires_at": new_expires})
        assert success is True
        share = self.share_manager.get_share(result["share_id"])
        assert abs(share["expires_at"] - new_expires) < 1

    def test_update_share_clear_expiry(self):
        """设置过期时间为 None（永不过期）"""
        result = self.share_manager.create_share("test.txt", expires_in=3600)
        success = self.share_manager.update_share(result["share_id"], {"expires_at": None})
        assert success is True
        share = self.share_manager.get_share(result["share_id"])
        assert share["expires_at"] is None

    def test_update_share_expired_fails(self):
        """过期分享不可修改"""
        result = self.share_manager.create_share("test.txt", expires_in=-3600)
        success = self.share_manager.update_share(result["share_id"], {"max_downloads": 10})
        assert success is False

    def test_update_share_not_exists(self):
        """不存在分享不可修改"""
        assert self.share_manager.update_share("nonexistent", {"max_downloads": 10}) is False

    # ========== 列出分享 ==========

    def test_list_shares(self):
        """列出所有分享含状态分类"""
        self.share_manager.create_share("active.txt", expires_in=3600)
        self.share_manager.create_share("expired.txt", expires_in=-3600)
        r = self.share_manager.create_share("deleted.txt", expires_in=3600)
        self.share_manager.delete_share(r["share_id"])

        shares = self.share_manager.list_shares()
        assert len(shares) == 3
        statuses = {s["status"] for s in shares}
        assert statuses == {"active", "expired", "deleted"}

    # ========== 获取文件分享 ==========

    def test_get_file_shares(self):
        """按文件路径查询有效分享"""
        s1 = self.share_manager.create_share("file1.txt")
        s2 = self.share_manager.create_share("file1.txt")
        s3 = self.share_manager.create_share("file2.txt")
        # 过期的不应出现
        s4 = self.share_manager.create_share("file1.txt", expires_in=-3600)

        result = self.share_manager.get_file_shares("file1.txt")
        # 只返回有效分享（非过期非删除）
        assert len(result) >= 1  # s1 和 s2 应该有效

    # ========== 线程安全 ==========

    def test_concurrent_access(self):
        """并发创建分享"""
        import threading
        import random

        results = []

        def _create():
            result = self.share_manager.create_share(
                f"file_{random.randint(1, 10000)}.txt"
            )
            results.append(result)

        threads = [threading.Thread(target=_create) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(results) == 10
        share_ids = [r["share_id"] for r in results]
        assert len(set(share_ids)) == 10
