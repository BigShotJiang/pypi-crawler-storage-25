"""测试 HTTP 处理器模块"""
import platform
import sys
import tempfile
from pathlib import Path

import pytest

# 确保使用本地源代码
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from file_server.handle.utils import _is_safe_path, _resolve_safe_path, _sanitize_filename


class TestIsSafePath:
    """测试路径安全验证函数"""

    def test_safe_path_inside_base(self):
        """测试基础目录内的路径是安全的"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "subdir" / "file.txt"
            # 创建文件
            target.parent.mkdir(parents=True, exist_ok=True)
            target.touch()

            assert _is_safe_path(base, target) is True

    def test_safe_path_direct_child(self):
        """测试直接子文件是安全的"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "file.txt"
            target.touch()

            assert _is_safe_path(base, target) is True

    def test_unsafe_path_traversal_parent(self):
        """测试路径遍历攻击 (../)"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 尝试访问父目录
            target = base / ".." / "etc" / "passwd"

            assert _is_safe_path(base, target) is False

    def test_unsafe_path_absolute_outside(self):
        """测试绝对路径访问外部目录"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 绝对路径到系统目录
            target = Path("/etc/passwd")

            assert _is_safe_path(base, target) is False

    def test_unsafe_path_deep_traversal(self):
        """测试多层路径遍历攻击"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "subdir" / ".." / ".." / ".." / "etc" / "passwd"

            assert _is_safe_path(base, target) is False

    @pytest.mark.skipif(platform.system() == "Windows", reason="Windows requires admin for symlinks")
    def test_safe_path_symlink_inside(self):
        """测试符号链接在基础目录内"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            real_file = base / "real.txt"
            real_file.touch()

            symlink = base / "link.txt"
            symlink.symlink_to(real_file)

            # 符号链接指向基础目录内的文件，应该是安全的
            assert _is_safe_path(base, symlink) is True

    def test_nonexistent_path(self):
        """测试不存在的路径"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "nonexistent" / "file.txt"

            # 不存在的路径解析后仍在基础目录内，应该是安全的
            assert _is_safe_path(base, target) is True

    def test_base_dir_itself(self):
        """测试基础目录本身"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)

            # 基础目录本身是安全的
            assert _is_safe_path(base, base) is True

    def test_relative_path_with_dots(self):
        """测试包含点号的相对路径"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 创建子目录和文件
            subdir = base / "subdir"
            subdir.mkdir()
            (subdir / "file.txt").touch()

            # 使用点号的路径
            target = base / "subdir" / "." / "file.txt"

            assert _is_safe_path(base, target) is True


class TestResolveSafePath:
    """测试安全路径解析函数"""

    def test_resolve_safe_path_valid(self):
        """测试有效路径解析"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            (base / "subdir").mkdir()
            (base / "subdir" / "file.txt").touch()

            result = _resolve_safe_path(base, "subdir/file.txt")
            assert result is not None
            assert result.name == "file.txt"

    def test_resolve_safe_path_traversal(self):
        """测试路径遍历攻击防护"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            result = _resolve_safe_path(base, "../outside.txt")
            assert result is None

    def test_resolve_safe_path_nonexistent(self):
        """测试不存在的路径解析"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            result = _resolve_safe_path(base, "nonexistent/file.txt")
            # 路径不存在但位置安全，应返回解析后的 Path
            assert result is not None
            assert result.name == "file.txt"

    def test_resolve_safe_path_absolute_outside(self):
        """测试外部绝对路径解析"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 使用系统路径
            result = _resolve_safe_path(base, "/etc/passwd" if platform.system() != "Windows" else "C:/Windows/System32")
            assert result is None


class TestSanitizeFilename:
    """测试文件名清理函数"""

    def test_sanitize_filename_normal(self):
        """测试正常文件名"""
        assert _sanitize_filename("file.txt") == "file.txt"
        assert _sanitize_filename("my-file 123.jpg") == "my-file 123.jpg"

    def test_sanitize_filename_replaces_dangerous_chars(self):
        """测试替换危险字符为下划线"""
        assert _sanitize_filename("file.txt") == "file.txt"
        assert _sanitize_filename("file/with/slashes.txt") == "slashes.txt"  # basename 只保留最后部分
        assert _sanitize_filename('file"with"quotes.txt') == "file_with_quotes.txt"
        assert _sanitize_filename("file<with>angle.txt") == "file_with_angle.txt"
        assert _sanitize_filename("file|with|pipes.txt") == "file_with_pipes.txt"
        assert _sanitize_filename("file?with?marks.txt") == "file_with_marks.txt"
        assert _sanitize_filename("file*with*stars.txt") == "file_with_stars.txt"

    def test_sanitize_filename_removes_leading_dots(self):
        """测试移除开头的点号"""
        assert _sanitize_filename(".htaccess") == "htaccess"
        assert _sanitize_filename("..") == "unnamed_file"
        assert _sanitize_filename("...") == "unnamed_file"

    def test_sanitize_filename_empty_result(self):
        """测试清理后为空的情况"""
        assert _sanitize_filename("") == "unnamed_file"
        assert _sanitize_filename("...") == "unnamed_file"
        assert _sanitize_filename("<<<>>>") == "______"  # 替换为下划线
        assert _sanitize_filename('""""') == "____"

    def test_sanitize_filename_removes_path_components(self):
        """测试移除路径组件 (只保留 basename)"""
        assert _sanitize_filename("../../etc/passwd") == "passwd"
        assert _sanitize_filename("/absolute/path/file.txt") == "file.txt"
        assert _sanitize_filename("dir/subdir/file.txt") == "file.txt"
