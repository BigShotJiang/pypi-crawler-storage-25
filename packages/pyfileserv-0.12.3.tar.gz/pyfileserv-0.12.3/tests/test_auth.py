"""认证模块测试"""
import time
from unittest.mock import MagicMock, patch

from file_server.core.auth import (
    Authenticator,
    LoginAttemptTracker,
    MemorySessionStorage,
    PasswordHasher,
    RedisSessionStorage,
    Session,
    SessionManager,
    UserStore,
)


class TestPasswordHasher:
    def test_hash_and_verify(self):
        hasher = PasswordHasher(rounds=4)  # 使用较少轮次加速测试
        password = "test_password_123"
        hashed = hasher.hash_password(password)

        assert hashed != password
        assert hasher.verify_password(password, hashed) is True
        assert hasher.verify_password("wrong_password", hashed) is False

    def test_different_salts(self):
        hasher = PasswordHasher(rounds=4)
        password = "same_password"
        hash1 = hasher.hash_password(password)
        hash2 = hasher.hash_password(password)

        # 相同密码应该产生不同的哈希值（因为盐不同）
        assert hash1 != hash2
        assert hasher.verify_password(password, hash1)
        assert hasher.verify_password(password, hash2)

    def test_empty_password(self):
        hasher = PasswordHasher(rounds=4)
        hashed = hasher.hash_password("")

        assert hasher.verify_password("", hashed) is True
        assert hasher.verify_password("a", hashed) is False


class TestUserStore:
    def test_load_empty_users(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        users = store.load_users()
        assert users == {}

    def test_save_and_load_users(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        test_users = {"test_user": {"password": "hashed_value"}}
        store.save_users(test_users)

        loaded = store.load_users()
        assert loaded == test_users

    def test_add_user(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        store.add_user("new_user", "hashed_password")

        assert store.user_exists("new_user")
        user_data = store.get_user("new_user")
        assert user_data["password"] == "hashed_password"

    def test_delete_user(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        store.add_user("to_delete", "hashed")
        assert store.user_exists("to_delete")

        result = store.delete_user("to_delete")
        assert result is True
        assert not store.user_exists("to_delete")

    def test_delete_nonexistent_user(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        result = store.delete_user("nonexistent")
        assert result is False


class TestSessionManager:
    def test_create_and_validate_session(self):
        manager = SessionManager(timeout_seconds=3600)

        session_id = manager.create_session("test_user")
        valid, username = manager.validate_session(session_id)

        assert valid is True
        assert username == "test_user"

    def test_invalid_session(self):
        manager = SessionManager()

        valid, username = manager.validate_session("invalid_id")

        assert valid is False
        assert username is None

    def test_destroy_session(self):
        manager = SessionManager()
        session_id = manager.create_session("test_user")

        username = manager.destroy_session(session_id)

        assert username == "test_user"
        valid, _ = manager.validate_session(session_id)
        assert valid is False

    def test_get_username(self):
        manager = SessionManager()
        session_id = manager.create_session("test_user")

        username = manager.get_username(session_id)
        assert username == "test_user"

        # 无效会话
        assert manager.get_username("invalid") is None


class TestMemorySessionStorage:
    """测试内存会话存储"""

    def test_save_and_get(self):
        storage = MemorySessionStorage()
        session = Session(
            session_id="test123",
            username="test_user",
            expires=time.time() + 3600,
            created_at=time.time(),
        )

        storage.save(session)
        retrieved = storage.get("test123")

        assert retrieved is not None
        assert retrieved.username == "test_user"
        assert retrieved.session_id == "test123"

    def test_delete(self):
        storage = MemorySessionStorage()
        session = Session(
            session_id="test123",
            username="test_user",
            expires=time.time() + 3600,
            created_at=time.time(),
        )

        storage.save(session)
        assert storage.delete("test123") is True
        assert storage.get("test123") is None

    def test_exists(self):
        storage = MemorySessionStorage()
        session = Session(
            session_id="test123",
            username="test_user",
            expires=time.time() + 3600,
            created_at=time.time(),
        )

        storage.save(session)
        assert storage.exists("test123") is True
        assert storage.exists("nonexistent") is False


class TestRedisSessionStorage:
    """测试 Redis 会话存储（需要 Redis 服务器）"""

    def test_redis_storage_basic(self):
        """基本功能测试 - 仅在 Redis 可用时运行"""
        try:
            storage = RedisSessionStorage(
                host="localhost",
                port=6379,
                db=15,  # 使用测试数据库
                key_prefix="test:session:",
            )
        except (ImportError, Exception):
            # 如果 Redis 不可用，跳过测试
            import pytest
            pytest.skip("Redis 服务器不可用或未安装 redis 模块")
            return

        session = Session(
            session_id="test_redis_123",
            username="redis_user",
            expires=time.time() + 3600,
            created_at=time.time(),
        )

        # 保存会话
        storage.save(session)

        # 获取会话
        retrieved = storage.get("test_redis_123")
        assert retrieved is not None
        assert retrieved.username == "redis_user"

        # 检查存在性
        assert storage.exists("test_redis_123") is True

        # 删除会话
        assert storage.delete("test_redis_123") is True
        assert storage.get("test_redis_123") is None


class TestSessionManagerWithStorage:
    """测试 SessionManager 使用不同存储"""

    def test_with_memory_storage(self):
        """使用内存存储的 SessionManager"""
        storage = MemorySessionStorage()
        manager = SessionManager(timeout_seconds=3600, storage=storage)

        session_id = manager.create_session("test_user")
        valid, username = manager.validate_session(session_id)

        assert valid is True
        assert username == "test_user"

    def test_default_storage_is_memory(self):
        """默认使用内存存储"""
        manager = SessionManager(timeout_seconds=3600)

        assert isinstance(manager.storage, MemorySessionStorage)

        session_id = manager.create_session("test_user")
        valid, username = manager.validate_session(session_id)

        assert valid is True
        assert username == "test_user"


class TestLoginAttemptTracker:
    """测试登录尝试跟踪器"""

    def test_record_failed_attempts(self):
        """记录失败尝试"""
        tracker = LoginAttemptTracker(max_attempts=3, lockout_duration=60)

        # 记录 2 次失败
        tracker.record_attempt("user1", False)
        tracker.record_attempt("user1", False)

        # 应该还有 1 次机会
        assert tracker.get_remaining_attempts("user1") == 1

        # 检查未锁定
        locked, _ = tracker.is_locked("user1")
        assert locked is False

    def test_lock_after_max_attempts(self):
        """超过最大尝试次数后锁定"""
        tracker = LoginAttemptTracker(max_attempts=3, lockout_duration=60)

        # 记录 3 次失败
        tracker.record_attempt("user1", False)
        tracker.record_attempt("user1", False)
        tracker.record_attempt("user1", False)

        # 应该被锁定
        locked, remaining = tracker.is_locked("user1")
        assert locked is True
        assert remaining > 0
        assert remaining <= 60

    def test_successful_login_clears_attempts(self):
        """成功登录后清除失败记录"""
        tracker = LoginAttemptTracker(max_attempts=3, lockout_duration=60)

        # 记录 2 次失败
        tracker.record_attempt("user1", False)
        tracker.record_attempt("user1", False)

        # 成功登录
        tracker.record_attempt("user1", True)

        # 应该重置为最大次数
        assert tracker.get_remaining_attempts("user1") == 3

    def test_lockout_expires(self):
        """锁定过期后自动解锁"""
        tracker = LoginAttemptTracker(max_attempts=2, lockout_duration=3)  # 1秒锁定

        # 记录 2 次失败
        tracker.record_attempt("user1", False)
        tracker.record_attempt("user1", False)

        # 应该被锁定
        locked, _ = tracker.is_locked("user1")
        assert locked is True

        # 等待锁定过期
        time.sleep(3.1)

        # 应该自动解锁
        locked, remaining = tracker.is_locked("user1")
        assert locked is False
        assert remaining == 0

    def test_reset_attempts(self):
        """手动重置尝试记录"""
        tracker = LoginAttemptTracker(max_attempts=3, lockout_duration=60)

        # 记录失败
        tracker.record_attempt("user1", False)
        tracker.record_attempt("user1", False)

        # 重置
        tracker.reset("user1")

        # 应该重置为最大次数
        assert tracker.get_remaining_attempts("user1") == 3

    def test_different_users_independent(self):
        """不同用户的尝试记录独立"""
        tracker = LoginAttemptTracker(max_attempts=3, lockout_duration=60)

        # user1 失败 2 次
        tracker.record_attempt("user1", False)
        tracker.record_attempt("user1", False)

        # user2 应该不受影响
        assert tracker.get_remaining_attempts("user2") == 3
        assert tracker.get_remaining_attempts("user1") == 1

    def test_old_attempts_cleanup(self):
        """清理过期的尝试记录"""
        tracker = LoginAttemptTracker(max_attempts=3, lockout_duration=1)  # 1秒

        # 记录失败
        tracker.record_attempt("user1", False)
        tracker.record_attempt("user1", False)

        # 等待过期
        time.sleep(1.1)

        # 记录新的失败
        tracker.record_attempt("user1", False)

        # 应该只有 1 次记录（旧的已清理）
        assert tracker.get_remaining_attempts("user1") == 2

    def test_is_locked_fresh_user(self):
        """从未尝试过的用户不应被锁定"""
        tracker = LoginAttemptTracker(max_attempts=3, lockout_duration=60)
        locked, remaining = tracker.is_locked("never_attempted")
        assert locked is False
        assert remaining == 0

    def test_is_locked_after_lockout_expires(self):
        """锁定过期后清理记录并解锁"""
        tracker = LoginAttemptTracker(max_attempts=2, lockout_duration=2)
        tracker.record_attempt("user1", False)
        tracker.record_attempt("user1", False)
        locked, _ = tracker.is_locked("user1")
        assert locked is True
        # 等待锁定过期
        time.sleep(2.1)
        locked, remaining = tracker.is_locked("user1")
        assert locked is False
        assert remaining == 0  # 记录已被清理

    def test_reset_nonexistent_user(self):
        """重置不存在的用户不应报错"""
        tracker = LoginAttemptTracker(max_attempts=3, lockout_duration=60)
        tracker.reset("nonexistent")  # 不应抛出异常


class TestSessionSerialization:
    """测试 Session 的序列化/反序列化"""

    def test_to_dict(self):
        now = time.time()
        session = Session(
            session_id="abc123",
            username="user1",
            expires=now + 3600,
            created_at=now,
        )
        d = session.to_dict()
        assert d["session_id"] == "abc123"
        assert d["username"] == "user1"
        assert d["expires"] == session.expires
        assert d["created_at"] == session.created_at

    def test_from_dict(self):
        now = time.time()
        data = {
            "session_id": "xyz789",
            "username": "user2",
            "expires": now + 7200,
            "created_at": now,
        }
        session = Session.from_dict(data)
        assert session.session_id == "xyz789"
        assert session.username == "user2"
        assert session.expires == data["expires"]
        assert session.created_at == data["created_at"]

    def test_from_dict_missing_key(self):
        """缺失键时应引发 KeyError"""
        with pytest.raises(KeyError):
            Session.from_dict({"session_id": "x"})

    def test_roundtrip(self):
        now = time.time()
        original = Session("sid", "user", now + 3600, now)
        restored = Session.from_dict(original.to_dict())
        assert restored.session_id == original.session_id
        assert restored.username == original.username
        assert restored.expires == original.expires
        assert restored.created_at == original.created_at


class TestMemorySessionStorageEdgeCases:
    """测试内存会话存储的边界情况"""

    def test_delete_nonexistent(self):
        storage = MemorySessionStorage()
        assert storage.delete("nonexistent") is False

    def test_get_nonexistent(self):
        storage = MemorySessionStorage()
        assert storage.get("nonexistent") is None

    def test_exists_nonexistent(self):
        storage = MemorySessionStorage()
        assert storage.exists("nonexistent") is False


class TestPasswordHasherEdgeCases:
    """测试密码哈希的边界情况"""

    def test_verify_with_garbage_hash(self):
        """验证垃圾哈希值不应崩溃，应返回 False"""
        hasher = PasswordHasher()
        assert hasher.verify_password("anything", "not_a_valid_bcrypt_hash") is False

    def test_verify_with_empty_hash(self):
        """验证空哈希值不应崩溃"""
        hasher = PasswordHasher()
        assert hasher.verify_password("anything", "") is False

    def test_custom_rounds(self):
        """测试自定义轮数"""
        hasher = PasswordHasher(rounds=4)
        hashed = hasher.hash_password("test")
        assert hashed.startswith("$2b$04$")
        assert hasher.verify_password("test", hashed)


class TestUserStoreEdgeCases:
    """测试 UserStore 边界情况"""

    def test_update_password(self, tmp_path):
        store = UserStore(tmp_path / "users.json")
        store.add_user("user1", "old_hash")
        store.update_password("user1", "new_hash")
        user = store.get_user("user1")
        assert user["password"] == "new_hash"

    def test_update_password_nonexistent(self, tmp_path):
        """更新不存在用户的密码应静默忽略"""
        store = UserStore(tmp_path / "users.json")
        store.update_password("nonexistent", "hash")  # 不应抛出异常

    def test_save_users_chmod_fallback(self, tmp_path):
        """chmod 失败时不应中断保存"""
        store = UserStore(tmp_path / "users.json")
        with patch('os.chmod', side_effect=OSError("permission denied")):
            store.save_users({"user1": {"password": "hash"}})
        assert store.user_exists("user1")

    def test_get_user_nonexistent(self, tmp_path):
        store = UserStore(tmp_path / "users.json")
        assert store.get_user("nonexistent") is None

    def test_save_users_creates_parent_dir(self, tmp_path):
        """保存时应创建不存在的父目录"""
        store = UserStore(tmp_path / "subdir" / "users.json")
        store.save_users({"user1": {"password": "hash"}})
        assert (tmp_path / "subdir" / "users.json").exists()


class TestSessionManagerEdgeCases:
    """测试 SessionManager 边界情况"""

    def test_validate_empty_session_id(self):
        manager = SessionManager()
        valid, username = manager.validate_session("")
        assert valid is False
        assert username is None

    def test_validate_none_session_id(self):
        manager = SessionManager()
        valid, username = manager.validate_session(None)
        assert valid is False
        assert username is None

    def test_validate_expired_session(self):
        manager = SessionManager(timeout_seconds=0)  # 立即过期的会话
        session_id = manager.create_session("user1")
        time.sleep(0.01)
        valid, username = manager.validate_session(session_id)
        assert valid is False
        assert username is None
        # 过期会话应该被删除
        assert not manager.storage.exists(session_id)

    def test_destroy_nonexistent_session(self):
        manager = SessionManager()
        assert manager.destroy_session("nonexistent") is None

    def test_destroy_returns_username(self):
        manager = SessionManager()
        session_id = manager.create_session("alice")
        assert manager.destroy_session(session_id) == "alice"


class TestAuthenticator:
    """测试 Authenticator - 整合认证流程"""

    def _make_authenticator(self, max_attempts=5, lockout_duration=900):
        """创建测试用的 Authenticator 实例"""
        user_store = UserStore.__new__(UserStore)
        hasher = PasswordHasher(rounds=4)
        session_manager = SessionManager(timeout_seconds=3600)
        login_tracker = LoginAttemptTracker(
            max_attempts=max_attempts,
            lockout_duration=lockout_duration,
        )
        return Authenticator(user_store, hasher, session_manager, login_tracker)

    def test_successful_login(self, tmp_path):
        auth = self._make_authenticator()
        hasher = auth.hasher
        # 使用真实 UserStore 添加用户
        store = UserStore(tmp_path / "users.json")
        store.add_user("alice", hasher.hash_password("secret"))
        auth.user_store = store

        success, result = auth.authenticate("alice", "secret")
        assert success is True
        assert result is not None  # session_id
        assert len(result) == 64  # token_hex(32)

    def test_wrong_password(self, tmp_path):
        auth = self._make_authenticator(max_attempts=5)
        store = UserStore(tmp_path / "users.json")
        store.add_user("alice", auth.hasher.hash_password("secret"))
        auth.user_store = store

        success, result = auth.authenticate("alice", "wrongpass")
        assert success is False
        assert "还剩 4 次尝试机会" in result

    def test_nonexistent_user(self):
        auth = self._make_authenticator()
        auth.user_store = UserStore.__new__(UserStore)
        auth.user_store.get_user = MagicMock(return_value=None)

        success, result = auth.authenticate("ghost", "any")
        assert success is False
        assert "用户不存在或密码错误" in result

    def test_account_locked(self):
        auth = self._make_authenticator(max_attempts=3, lockout_duration=900)
        auth.user_store = UserStore.__new__(UserStore)
        auth.user_store.get_user = MagicMock(return_value={
            "password": auth.hasher.hash_password("secret"),
        })
        # 失败 3 次触发锁定
        auth.authenticate("bob", "wrong")
        auth.authenticate("bob", "wrong")
        auth.authenticate("bob", "wrong")
        # 第 4 次应报告锁定
        success, result = auth.authenticate("bob", "wrong")
        assert success is False
        assert "账户已锁定" in result

    def test_password_error_escalates_to_lockout(self, tmp_path):
        """密码错误次数用完后提示锁定"""
        auth = self._make_authenticator(max_attempts=3, lockout_duration=900)
        store = UserStore(tmp_path / "users.json")
        store.add_user("user1", auth.hasher.hash_password("right"))
        auth.user_store = store

        auth.authenticate("user1", "wrong1")  # 1
        auth.authenticate("user1", "wrong2")  # 2
        success, result = auth.authenticate("user1", "wrong3")  # 3 → locked
        assert success is False
        assert "密码错误次数过多" in result or "账户已锁定" in result

    def test_success_clears_failed_attempts(self, tmp_path):
        """登录成功后应清除之前的失败记录"""
        auth = self._make_authenticator(max_attempts=5)
        store = UserStore(tmp_path / "users.json")
        store.add_user("user1", auth.hasher.hash_password("right"))
        auth.user_store = store

        auth.authenticate("user1", "wrong")
        auth.authenticate("user1", "wrong")
        assert auth.login_tracker.get_remaining_attempts("user1") == 3

        auth.authenticate("user1", "right")
        assert auth.login_tracker.get_remaining_attempts("user1") == 5

    def test_default_login_tracker(self):
        """测试未提供 login_tracker 时使用默认值"""
        user_store = UserStore.__new__(UserStore)
        hasher = PasswordHasher()
        session_manager = SessionManager()
        auth = Authenticator(user_store, hasher, session_manager)
        assert auth.login_tracker is not None
        assert auth.login_tracker.max_attempts == 5
        assert auth.login_tracker.lockout_duration == 900


import pytest

from file_server.handle.auth import AuthMixin


class TestAuthMixin:
    """测试 AuthMixin 认证处理方法"""

    @staticmethod
    def _bind(mixin_cls, handler):
        for name in ('_redirect_to_login', '_handle_login_page',
                      '_handle_login', '_handle_logout'):
            method = getattr(mixin_cls, name)
            setattr(handler, name, method.__get__(handler, type(handler)))

    # ── _redirect_to_login ──────────────────────────────

    def test_redirect_to_login(self):
        handler = MagicMock()
        handler.path = '/secret.txt'
        self._bind(AuthMixin, handler)
        handler._redirect_to_login()
        handler.send_response.assert_called_with(302)
        handler.send_header.assert_called_with('Location', '/login')
        handler.end_headers.assert_called_once()

    # ── _handle_login_page ──────────────────────────────

    def test_login_page_default_timeout(self):
        handler = MagicMock()
        handler.config = None
        self._bind(AuthMixin, handler)
        with patch('file_server.template.render_login_page',
                   return_value='<html>login</html>') as mock_render:
            handler._handle_login_page("error")
        mock_render.assert_called_with("error", 3600)
        handler._send_html_response.assert_called_with('<html>login</html>')

    def test_login_page_custom_timeout(self):
        handler = MagicMock()
        handler.config = MagicMock(session_timeout=1800)
        self._bind(AuthMixin, handler)
        with patch('file_server.template.render_login_page',
                   return_value='<html>x</html>') as mock_render:
            handler._handle_login_page("")
        mock_render.assert_called_with("", 1800)

    def test_login_page_no_error(self):
        handler = MagicMock()
        handler.config = MagicMock(session_timeout=3600)
        self._bind(AuthMixin, handler)
        with patch('file_server.template.render_login_page',
                   return_value='<html>x</html>') as mock_render:
            handler._handle_login_page()
        mock_render.assert_called_with("", 3600)

    # ── _handle_login ───────────────────────────────────

    def test_login_success(self):
        handler = MagicMock()
        handler.headers = {'Content-Length': '25'}
        handler.rfile.read.return_value = b'username=alice&password=secret'
        handler.authenticator = MagicMock()
        handler.authenticator.authenticate.return_value = (True, 'sess123')
        handler.config = MagicMock(use_https=False)
        self._bind(AuthMixin, handler)
        handler._handle_login()
        handler.send_response.assert_called_with(302)
        set_cookie = [a for a in handler.send_header.call_args_list
                      if a[0][0] == 'Set-Cookie'][0][0][1]
        assert 'session_id=sess123' in set_cookie
        assert 'Secure' not in set_cookie

    def test_login_success_https(self):
        handler = MagicMock()
        handler.headers = {'Content-Length': '25'}
        handler.rfile.read.return_value = b'username=alice&password=secret'
        handler.authenticator = MagicMock()
        handler.authenticator.authenticate.return_value = (True, 'sess_https')
        handler.config = MagicMock(use_https=True)
        self._bind(AuthMixin, handler)
        handler._handle_login()
        set_cookie = [a for a in handler.send_header.call_args_list
                      if a[0][0] == 'Set-Cookie'][0][0][1]
        assert 'Secure' in set_cookie

    def test_login_bad_password(self):
        handler = MagicMock()
        handler.headers = {'Content-Length': '25'}
        handler.rfile.read.return_value = b'username=alice&password=wrong'
        handler.authenticator = MagicMock()
        handler.authenticator.authenticate.return_value = (False, "BAD_PASSWORD")
        handler.config = MagicMock(session_timeout=3600)
        self._bind(AuthMixin, handler)
        handler._handle_login_page = MagicMock()
        handler._handle_login()
        handler._handle_login_page.assert_called_with("BAD_PASSWORD")

    def test_login_no_authenticator(self):
        handler = MagicMock()
        handler.headers = {'Content-Length': '15'}
        handler.rfile.read.return_value = b'username=a&pass=b'
        handler.authenticator = None
        handler.config = MagicMock(session_timeout=3600)
        self._bind(AuthMixin, handler)
        handler._handle_login_page = MagicMock()
        handler._handle_login()
        handler._handle_login_page.assert_called_with("用户名或密码错误")

    def test_login_empty_body(self):
        handler = MagicMock()
        handler.headers = {'Content-Length': '0'}
        handler.rfile.read.return_value = b''
        handler.authenticator = MagicMock()
        handler.authenticator.authenticate.return_value = \
            (False, "用户不存在或密码错误")
        handler.config = MagicMock(session_timeout=3600)
        self._bind(AuthMixin, handler)
        handler._handle_login_page = MagicMock()
        handler._handle_login()
        handler.authenticator.authenticate.assert_called_with('', '')

    # ── _handle_logout ──────────────────────────────────

    def test_logout_normal(self):
        handler = MagicMock()
        handler._get_session_id = MagicMock(return_value='sess123')
        handler.session_manager = MagicMock()
        handler.session_manager.destroy_session.return_value = 'alice'
        handler.config = MagicMock(use_https=False)
        self._bind(AuthMixin, handler)
        handler._handle_logout()
        handler._get_session_id.assert_called_once()
        handler.session_manager.destroy_session.assert_called_with('sess123')
        handler.send_response.assert_called_with(302)
        handler.send_header.assert_any_call('Location', '/login')

    def test_logout_https(self):
        handler = MagicMock()
        handler._get_session_id = MagicMock(return_value='sess456')
        handler.session_manager = MagicMock()
        handler.session_manager.destroy_session.return_value = 'bob'
        handler.config = MagicMock(use_https=True)
        self._bind(AuthMixin, handler)
        handler._handle_logout()
        set_cookie = [a for a in handler.send_header.call_args_list
                      if a[0][0] == 'Set-Cookie'][0][0][1]
        assert 'Secure' in set_cookie
        assert 'Max-Age=0' in set_cookie

    def test_logout_no_session_id(self):
        handler = MagicMock()
        handler._get_session_id = MagicMock(return_value=None)
        handler.session_manager = MagicMock()
        handler.config = MagicMock(use_https=False)
        self._bind(AuthMixin, handler)
        handler._handle_logout()
        handler.session_manager.destroy_session.assert_not_called()

    def test_logout_no_session_manager(self):
        handler = MagicMock()
        handler._get_session_id = MagicMock(return_value='sess')
        handler.session_manager = None
        handler.config = MagicMock(use_https=False)
        self._bind(AuthMixin, handler)
        handler._handle_logout()
        handler.send_response.assert_called_with(302)

    def test_logout_no_config(self):
        handler = MagicMock()
        handler._get_session_id = MagicMock(return_value='sess')
        handler.session_manager = MagicMock()
        handler.session_manager.destroy_session.return_value = 'user'
        handler.config = None
        self._bind(AuthMixin, handler)
        handler._handle_logout()
        set_cookie = [a for a in handler.send_header.call_args_list
                      if a[0][0] == 'Set-Cookie'][0][0][1]
        assert 'Secure' not in set_cookie
