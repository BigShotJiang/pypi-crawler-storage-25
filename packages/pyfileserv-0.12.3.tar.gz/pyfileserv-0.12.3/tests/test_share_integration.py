"""测试分享功能的完整流程"""
import tempfile
from pathlib import Path

import pytest

from file_server.core.share import ShareManager
from file_server.core.share_store import ShareStore
from file_server.template import (
    render_share_access_page,
    render_share_detail_page,
)


class MockPasswordHasher:
    """用于测试的密码哈希器（明文对比，避免 bcrypt 性能开销）"""
    def hash_password(self, password: str) -> str:
        return password
    def verify_password(self, password: str, hashed_password: str) -> bool:
        return password == hashed_password


class TestShareFileDownload:
    """测试单个文件分享的下载和查看"""

    def setup_method(self):
        """每个测试方法执行前的设置"""
        self.temp_dir = tempfile.mkdtemp()
        self.data_file = Path(self.temp_dir) / "shares.json"
        self.share_manager = ShareManager(ShareStore(self.data_file), MockPasswordHasher())
        
        # 创建测试文件
        self.test_file = Path(self.temp_dir) / "test.txt"
        self.test_file.write_text("Hello, World!", encoding="utf-8")
        
    def teardown_method(self):
        """每个测试方法执行后的清理"""
        import shutil
        shutil.rmtree(self.temp_dir)

    def test_create_file_share(self):
        """测试创建文件分享"""
        result = self.share_manager.create_share(
            file_path="test.txt",
            password=None,
            expires_in=3600
        )
        
        assert "share_id" in result
        assert result["file_path"] == "test.txt"
        assert result["password"] is None
        
    def test_create_file_share_with_password(self):
        """测试创建带密码的文件分享"""
        result = self.share_manager.create_share(
            file_path="test.txt",
            password="123456"
        )
        
        assert result["password"] == "123456"
        
    def test_access_file_share_without_password(self):
        """测试访问无密码的文件分享"""
        # 创建分享
        share = self.share_manager.create_share(file_path="test.txt")
        share_id = share["share_id"]
        
        # 验证访问
        valid, info = self.share_manager.validate_access(share_id)
        assert valid is True
        assert info["file_path"] == "test.txt"
        
    def test_access_file_share_with_correct_password(self):
        """测试使用正确密码访问文件分享"""
        share = self.share_manager.create_share(
            file_path="test.txt",
            password="secret"
        )
        share_id = share["share_id"]
        
        valid, info = self.share_manager.validate_access(share_id, "secret")
        assert valid is True
        
    def test_access_file_share_with_wrong_password(self):
        """测试使用错误密码访问文件分享"""
        share = self.share_manager.create_share(
            file_path="test.txt",
            password="secret"
        )
        share_id = share["share_id"]
        
        valid, error = self.share_manager.validate_access(share_id, "wrong")
        assert valid is False
        assert "密码" in error
        
    def test_file_share_record_download(self):
        """测试文件分享记录下载次数"""
        share = self.share_manager.create_share(
            file_path="test.txt",
            max_downloads=5
        )
        share_id = share["share_id"]
        
        # 初始为0
        assert share["download_count"] == 0
        
        # 记录一次下载
        self.share_manager.record_download(share_id)
        
        # 验证次数增加
        updated_share = self.share_manager.get_share(share_id)
        assert updated_share["download_count"] == 1
        
    def test_render_share_access_page_for_file(self):
        """测试渲染文件的分享访问页面"""
        html = render_share_access_page(
            file_name="document.pdf",
            has_password=False,
            is_folder=False
        )
        
        assert "document.pdf" in html
        assert "文件" in html  # 应该显示"文件"而不是"文件夹"
        assert "📎" in html  # 文件图标
        
    def test_render_share_access_page_for_file_with_password(self):
        """测试渲染带密码的文件分享访问页面"""
        html = render_share_access_page(
            file_name="secret.docx",
            has_password=True,
            is_folder=False
        )
        
        assert "访问密码" in html
        assert 'type="password"' in html
        assert "下载文件" in html


class TestShareFolderBrowse:
    """测试目录分享的浏览、下载、子路径操作"""

    def setup_method(self):
        """每个测试方法执行前的设置"""
        self.temp_dir = tempfile.mkdtemp()
        self.data_file = Path(self.temp_dir) / "shares.json"
        self.share_manager = ShareManager(ShareStore(self.data_file), MockPasswordHasher())
        
        # 创建测试目录结构
        self.test_folder = Path(self.temp_dir) / "myfolder"
        self.test_folder.mkdir()
        
        # 创建子目录
        self.subfolder = self.test_folder / "subdir"
        self.subfolder.mkdir()
        
        # 创建文件
        (self.test_folder / "file1.txt").write_text("File 1 content", encoding="utf-8")
        (self.test_folder / "file2.pdf").write_text("File 2 content", encoding="utf-8")
        (self.subfolder / "file3.txt").write_text("File 3 content", encoding="utf-8")
        
    def teardown_method(self):
        """每个测试方法执行后的清理"""
        import shutil
        shutil.rmtree(self.temp_dir)

    def test_create_folder_share(self):
        """测试创建文件夹分享"""
        result = self.share_manager.create_share(
            file_path="myfolder",
            password=None
        )
        
        assert "share_id" in result
        assert result["file_path"] == "myfolder"
        
    def test_access_folder_share(self):
        """测试访问文件夹分享"""
        share = self.share_manager.create_share(file_path="myfolder")
        share_id = share["share_id"]
        
        valid, info = self.share_manager.validate_access(share_id)
        assert valid is True
        assert info["file_path"] == "myfolder"
        
    def test_render_share_detail_page_with_files_and_folders(self):
        """测试渲染包含文件和文件夹的分享详情页"""
        items = [
            {"name": "file1.txt", "is_dir": False, "size": 1024, "path": "myfolder/file1.txt"},
            {"name": "file2.pdf", "is_dir": False, "size": 2048, "path": "myfolder/file2.pdf"},
            {"name": "subdir", "is_dir": True, "size": 0, "path": "myfolder/subdir"},
        ]
        
        html = render_share_detail_page(
            share_id="abc123",
            root_name="myfolder",
            items=items,
            current_path=""
        )
        
        # 检查文件名
        assert "file1.txt" in html
        assert "file2.pdf" in html
        assert "subdir" in html
        
        # 检查下载链接
        assert "/share/file/abc123/myfolder/file1.txt" in html
        assert "/share/file/abc123/myfolder/file2.pdf" in html
        
        # 检查文件夹导航
        assert "navigateTo" in html
        
        # 检查下载全部按钮和函数
        assert "下载全部" in html
        assert "downloadAll" in html
        assert "/share/download/" in html  # JavaScript中包含此路径模式
        
    def test_render_share_detail_page_empty_folder(self):
        """测试渲染空文件夹的分享详情页"""
        html = render_share_detail_page(
            share_id="xyz789",
            root_name="empty",
            items=[],
            current_path=""
        )
        
        assert "此目录为空" in html
        
    def test_render_share_detail_page_with_breadcrumb(self):
        """测试分享详情页的面包屑导航"""
        items = []
        html = render_share_detail_page(
            share_id="abc123",
            root_name="myfolder",
            items=items,
            current_path="subdir/nested"
        )
        
        assert "首页" in html
        assert "subdir" in html
        assert "nested" in html
        
    def test_render_share_access_page_for_folder(self):
        """测试渲染文件夹的分享访问页面"""
        html = render_share_access_page(
            file_name="myfolder",
            has_password=False,
            is_folder=True
        )
        
        assert "myfolder" in html
        assert "文件夹" in html  # 应该显示"文件夹"
        assert "📁" in html  # 文件夹图标
        assert "下载文件夹" in html
        
    def test_folder_share_navigation_simulation(self):
        """模拟文件夹分享的导航流程"""
        # 创建分享
        share = self.share_manager.create_share(file_path="myfolder")
        share_id = share["share_id"]
        
        # 验证可以访问根目录
        valid, _ = self.share_manager.validate_access(share_id)
        assert valid is True
        
        # 验证可以访问子目录（通过路径参数）
        subfolder_path = "myfolder/subdir"
        subfolder_full = Path(self.temp_dir) / subfolder_path
        assert subfolder_full.exists()
        assert subfolder_full.is_dir()
        
    def test_folder_share_file_download_paths(self):
        """测试文件夹分享中各文件的下载路径"""
        items = [
            {"name": "file1.txt", "is_dir": False, "size": 100, "path": "myfolder/file1.txt"},
            {"name": "file3.txt", "is_dir": False, "size": 200, "path": "myfolder/subdir/file3.txt"},
        ]
        
        html = render_share_detail_page(
            share_id="test123",
            root_name="myfolder",
            items=items,
            current_path=""
        )
        
        # 验证根目录文件的下载链接
        assert "/share/file/test123/myfolder/file1.txt" in html
        
        # 验证子目录文件的下载链接
        assert "/share/file/test123/myfolder/subdir/file3.txt" in html
        
    def test_folder_share_download_all_button(self):
        """测试文件夹分享的'下载全部'按钮"""
        html = render_share_detail_page(
            share_id="folder456",
            root_name="documents",
            items=[],
            current_path=""
        )
        
        # 验证下载全部按钮存在
        assert "下载全部" in html
        assert "downloadAll" in html
        assert "/share/download/" in html  # JavaScript中包含此路径模式
        

class TestShareSubdirectoryOperations:
    """测试子目录下的查看和下载操作"""

    def setup_method(self):
        """每个测试方法执行前的设置"""
        self.temp_dir = tempfile.mkdtemp()
        self.data_file = Path(self.temp_dir) / "shares.json"
        self.share_manager = ShareManager(ShareStore(self.data_file), MockPasswordHasher())
        
        # 创建深层目录结构
        self.root_folder = Path(self.temp_dir) / "project"
        self.root_folder.mkdir()
        
        self.level1 = self.root_folder / "docs"
        self.level1.mkdir()
        
        self.level2 = self.level1 / "api"
        self.level2.mkdir()
        
        self.level3 = self.level2 / "v1"
        self.level3.mkdir()
        
        # 在各层创建文件
        (self.root_folder / "README.md").write_text("# Project", encoding="utf-8")
        (self.level1 / "guide.txt").write_text("Guide", encoding="utf-8")
        (self.level2 / "spec.json").write_text("{}", encoding="utf-8")
        (self.level3 / "endpoint.txt").write_text("API v1", encoding="utf-8")
        
    def teardown_method(self):
        """每个测试方法执行后的清理"""
        import shutil
        shutil.rmtree(self.temp_dir)

    def test_navigate_to_subdirectory(self):
        """测试导航到子目录"""
        share = self.share_manager.create_share(file_path="project")
        share_id = share["share_id"]
        
        # 模拟访问子目录
        sub_path = "project/docs/api"
        target_path = Path(self.temp_dir) / sub_path
        
        assert target_path.exists()
        assert target_path.is_dir()
        
    def test_render_subdirectory_contents(self):
        """测试渲染子目录内容"""
        # 模拟在 api 目录下
        items = [
            {"name": "v1", "is_dir": True, "size": 0, "path": "project/docs/api/v1"},
            {"name": "spec.json", "is_dir": False, "size": 2, "path": "project/docs/api/spec.json"},
        ]
        
        html = render_share_detail_page(
            share_id="deep123",
            root_name="project",
            items=items,
            current_path="docs/api"
        )
        
        assert "v1" in html
        assert "spec.json" in html
        
        # 面包屑应显示完整路径
        assert "docs" in html
        assert "api" in html
        
    def test_download_file_from_deep_subdirectory(self):
        """测试从深层子目录下载文件"""
        items = [
            {"name": "endpoint.txt", "is_dir": False, "size": 6, 
             "path": "project/docs/api/v1/endpoint.txt"},
        ]
        
        html = render_share_detail_page(
            share_id="deep456",
            root_name="project",
            items=items,
            current_path="docs/api/v1"
        )
        
        # 验证下载链接包含完整路径
        assert "/share/file/deep456/project/docs/api/v1/endpoint.txt" in html
        
    def test_breadcrumb_navigation_upwards(self):
        """测试通过面包屑向上导航"""
        html = render_share_detail_page(
            share_id="nav789",
            root_name="project",
            items=[],
            current_path="docs/api/v1"
        )
        
        # 应该有返回首页的链接
        assert "navigateTo('')" in html or "首页" in html
        
        # 应该有返回各级目录的链接
        assert "docs" in html
        assert "api" in html
        assert "v1" in html
        
    def test_subdirectory_security_check(self):
        """测试子目录访问的安全性检查"""
        share = self.share_manager.create_share(file_path="project")
        share_root = Path(self.temp_dir) / "project"
        
        # 合法路径
        valid_path = share_root / "docs" / "api"
        assert str(valid_path).startswith(str(share_root))
        
        # 非法路径（尝试跳出分享根目录）
        invalid_path = Path(self.temp_dir) / "../etc/passwd"
        assert not str(invalid_path).startswith(str(share_root))


class TestShareEdgeCases:
    """测试分享功能的边界情况"""

    def setup_method(self):
        """每个测试方法执行前的设置"""
        self.temp_dir = tempfile.mkdtemp()
        self.data_file = Path(self.temp_dir) / "shares.json"
        self.share_manager = ShareManager(ShareStore(self.data_file), MockPasswordHasher())
        
    def teardown_method(self):
        """每个测试方法执行后的清理"""
        import shutil
        shutil.rmtree(self.temp_dir)

    def test_share_with_special_characters_in_name(self):
        """测试文件名包含特殊字符的分享"""
        # 创建特殊文件名的文件
        special_file = Path(self.temp_dir) / "file with spaces & symbols.txt"
        special_file.write_text("content", encoding="utf-8")
        
        share = self.share_manager.create_share(
            file_path="file with spaces & symbols.txt"
        )
        
        assert share["file_path"] == "file with spaces & symbols.txt"
        
    def test_share_unicode_filenames(self):
        """测试Unicode文件名的分享"""
        unicode_file = Path(self.temp_dir) / "文档_файл_文件.txt"
        unicode_file.write_text("内容", encoding="utf-8")
        
        share = self.share_manager.create_share(
            file_path="文档_файл_文件.txt"
        )
        
        assert "文档" in share["file_path"]
        
    def test_share_nested_empty_folders(self):
        """测试嵌套空文件夹的分享"""
        # 创建嵌套空文件夹
        empty_nested = Path(self.temp_dir) / "a" / "b" / "c"
        empty_nested.mkdir(parents=True)
        
        share = self.share_manager.create_share(file_path="a")
        
        # 应该能成功创建分享
        assert share["file_path"] == "a"
        
    def test_share_mixed_content(self):
        """测试混合内容的文件夹分享（文件+文件夹）"""
        mixed_folder = Path(self.temp_dir) / "mixed"
        mixed_folder.mkdir()
        (mixed_folder / "file.txt").write_text("text", encoding="utf-8")
        (mixed_folder / "empty_dir").mkdir()
        (mixed_folder / "nested").mkdir()
        ((mixed_folder / "nested") / "deep.txt").write_text("deep", encoding="utf-8")
        
        items = [
            {"name": "file.txt", "is_dir": False, "size": 4, "path": "mixed/file.txt"},
            {"name": "empty_dir", "is_dir": True, "size": 0, "path": "mixed/empty_dir"},
            {"name": "nested", "is_dir": True, "size": 0, "path": "mixed/nested"},
        ]
        
        html = render_share_detail_page(
            share_id="mix123",
            root_name="mixed",
            items=items,
            current_path=""
        )
        
        # 验证所有内容都显示
        assert "file.txt" in html
        assert "empty_dir" in html
        assert "nested" in html


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
