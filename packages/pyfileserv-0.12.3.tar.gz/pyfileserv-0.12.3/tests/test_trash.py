"""测试回收站模块"""
import json
import os
import shutil
import tempfile
import time
from pathlib import Path
from time import sleep

from file_server.core.trash import TrashManager


class TestTrashManager:
    """测试 TrashManager 类"""

    def setup_method(self):
        """每个测试方法执行前的设置"""
        self.temp_dir = tempfile.mkdtemp()
        self.serve_dir = Path(self.temp_dir) / "serve"
        self.serve_dir.mkdir()
        self.trash_manager = TrashManager(self.serve_dir)

    def teardown_method(self):
        """每个测试方法执行后的清理"""
        # 清理临时目录
        shutil.rmtree(self.temp_dir)

    def test_init(self):
        """测试初始化"""
        # 检查回收站目录是否创建
        trash_dir = self.serve_dir / TrashManager.TRASH_DIR_NAME
        assert trash_dir.exists()
        assert trash_dir.is_dir()

        # 检查元数据文件
        metadata_file = trash_dir / TrashManager.METADATA_FILE
        assert metadata_file.exists()

    def test_move_to_trash_file(self):
        """测试移动文件到回收站"""
        # 创建测试文件
        test_file = self.serve_dir / "test.txt"
        test_file.write_text("Hello, World!")

        # 移动到回收站
        item_id = self.trash_manager.move_to_trash("test.txt")

        assert item_id is not None
        assert isinstance(item_id, str)

        # 检查文件是否被移动
        assert not test_file.exists()

        # 检查回收站中是否有文件（不包括元数据文件）
        trash_dir = self.serve_dir / TrashManager.TRASH_DIR_NAME
        trash_files = [f for f in trash_dir.iterdir() if f.name != TrashManager.METADATA_FILE]
        assert len(trash_files) == 1
        assert trash_files[0].name.startswith("test_")

        # 检查元数据
        items = self.trash_manager.list_items()
        assert len(items) == 1
        assert items[0]["original_path"] == "test.txt"
        assert items[0]["is_dir"] is False
        assert items[0]["size"] == 13  # "Hello, World!" 的长度

    def test_move_to_trash_directory(self):
        """测试移动目录到回收站"""
        # 创建测试目录
        test_dir = self.serve_dir / "test_dir"
        test_dir.mkdir()
        (test_dir / "file1.txt").write_text("file1")
        (test_dir / "file2.txt").write_text("file2")

        # 移动到回收站
        item_id = self.trash_manager.move_to_trash("test_dir")

        assert item_id is not None

        # 检查目录是否被移动
        assert not test_dir.exists()

        # 检查元数据
        items = self.trash_manager.list_items()
        assert len(items) == 1
        assert items[0]["original_path"] == "test_dir"
        assert items[0]["is_dir"] is True
        assert items[0]["size"] == 10  # file1(5) + file2(5)

    def test_move_to_trash_not_exists(self):
        """测试移动不存在的文件"""
        item_id = self.trash_manager.move_to_trash("nonexistent.txt")
        assert item_id is None

    def test_move_to_trash_path_traversal(self):
        """测试路径遍历攻击防护"""
        # 尝试访问服务目录外的文件
        outside_file = Path(self.temp_dir) / "outside.txt"
        outside_file.write_text("outside content")

        item_id = self.trash_manager.move_to_trash(f"../{os.path.basename(self.temp_dir)}/outside.txt")
        assert item_id is None

    def test_move_to_trash_name_conflict(self):
        """测试处理文件名冲突"""
        # 创建第一个文件
        test_file1 = self.serve_dir / "test.txt"
        test_file1.write_text("file1")

        # 移动到回收站
        item_id1 = self.trash_manager.move_to_trash("test.txt")

        # 创建第二个同名文件
        test_file2 = self.serve_dir / "test.txt"
        test_file2.write_text("file2")

        # 再次移动到回收站
        item_id2 = self.trash_manager.move_to_trash("test.txt")

        # 应该有两个不同的文件在回收站
        assert item_id1 is not None
        assert item_id2 is not None
        assert item_id1 != item_id2

        items = self.trash_manager.list_items()
        assert len(items) == 2

    def test_restore_file(self):
        """测试恢复文件"""
        # 创建并移动文件
        test_file = self.serve_dir / "test.txt"
        test_file.write_text("Hello, World!")
        item_id = self.trash_manager.move_to_trash("test.txt")

        # 恢复文件
        restored = self.trash_manager.restore(item_id)

        assert restored is True

        # 检查文件是否恢复
        assert test_file.exists()
        assert test_file.read_text() == "Hello, World!"

        # 检查元数据是否删除
        items = self.trash_manager.list_items()
        assert len(items) == 0

    def test_restore_directory(self):
        """测试恢复目录"""
        # 创建并移动目录
        test_dir = self.serve_dir / "test_dir"
        test_dir.mkdir()
        (test_dir / "file.txt").write_text("content")
        item_id = self.trash_manager.move_to_trash("test_dir")

        # 恢复目录
        restored = self.trash_manager.restore(item_id)

        assert restored is True

        # 检查目录是否恢复
        assert test_dir.exists()
        assert (test_dir / "file.txt").exists()

    def test_restore_not_exists(self):
        """测试恢复不存在的项目"""
        result = self.trash_manager.restore("nonexistent_id")
        assert result is False

    def test_restore_with_conflict(self):
        """测试恢复时处理文件名冲突"""
        # 创建并移动文件
        test_file = self.serve_dir / "test.txt"
        test_file.write_text("original")
        item_id = self.trash_manager.move_to_trash("test.txt")

        # 在原位置创建同名文件
        test_file.write_text("new content")

        # 恢复文件（应该添加后缀）
        restored = self.trash_manager.restore(item_id)

        assert restored is True

        # 检查原文件未被覆盖
        assert test_file.read_text() == "new content"

        # 检查恢复的文件内容正确，且名称不与原文件冲突
        restored_files = [f for f in self.serve_dir.iterdir() if
                          f.is_file() and f.name != test_file.name and f.suffix == '.txt']
        assert len(restored_files) == 1
        assert restored_files[0].read_text() == "original"

    def test_permanent_delete(self):
        """测试永久删除"""
        # 创建并移动文件
        test_file = self.serve_dir / "test.txt"
        test_file.write_text("Hello, World!")
        item_id = self.trash_manager.move_to_trash("test.txt")

        # 永久删除
        deleted = self.trash_manager.permanent_delete(item_id)

        assert deleted is True

        # 检查文件是否被删除（不包括元数据文件）
        trash_dir = self.serve_dir / TrashManager.TRASH_DIR_NAME
        trash_files = [f for f in trash_dir.iterdir() if f.name != TrashManager.METADATA_FILE]
        assert len(trash_files) == 0

        # 检查元数据是否删除
        items = self.trash_manager.list_items()
        assert len(items) == 0

    def test_permanent_delete_directory(self):
        """测试永久删除目录"""
        # 创建并移动目录
        test_dir = self.serve_dir / "test_dir"
        test_dir.mkdir()
        (test_dir / "file.txt").write_text("content")
        item_id = self.trash_manager.move_to_trash("test_dir")

        # 永久删除
        deleted = self.trash_manager.permanent_delete(item_id)

        assert deleted is True

        # 检查目录是否被删除
        trash_dir = self.serve_dir / TrashManager.TRASH_DIR_NAME
        trash_files = [f for f in trash_dir.iterdir() if f.name != TrashManager.METADATA_FILE]
        assert len(trash_files) == 0

    def test_permanent_delete_not_exists(self):
        """测试永久删除不存在的项目"""
        result = self.trash_manager.permanent_delete("nonexistent_id")
        assert result is False

    def test_empty_trash(self):
        """测试清空回收站"""
        # 创建多个项目
        test_file1 = self.serve_dir / "file1.txt"
        test_file1.write_text("content1")
        self.trash_manager.move_to_trash("file1.txt")

        test_file2 = self.serve_dir / "file2.txt"
        test_file2.write_text("content2")
        self.trash_manager.move_to_trash("file2.txt")

        # 清空回收站
        count = self.trash_manager.empty_trash()

        assert count == 2

        # 检查回收站为空
        items = self.trash_manager.list_items()
        assert len(items) == 0

        # 检查文件是否被删除
        trash_dir = self.serve_dir / TrashManager.TRASH_DIR_NAME
        trash_files = [f for f in trash_dir.iterdir() if f.name != TrashManager.METADATA_FILE]
        assert len(trash_files) == 0

    def test_list_items_orphaned_metadata(self):
        """测试列出项目时自动清理孤立的元数据"""
        # 手动创建元数据但不存在实际文件
        metadata_file = self.serve_dir / TrashManager.TRASH_DIR_NAME / TrashManager.METADATA_FILE
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump({
                "item1": {"original_path": "file1.txt", "trash_name": "nonexistent_file.txt", "deleted_at": time.time(),
                    "is_dir": False, "size": 100}}, f)

        # 列出项目（应该自动清理孤立元数据）
        items = self.trash_manager.list_items()

        assert len(items) == 0

    def test_calculate_size(self):
        """测试计算目录大小"""
        # 创建一个目录结构
        test_dir = self.serve_dir / "test_dir"
        test_dir.mkdir()

        (test_dir / "file1.txt").write_text("a" * 100)  # 100 bytes
        (test_dir / "file2.txt").write_text("b" * 200)  # 200 bytes

        # 创建子目录
        sub_dir = test_dir / "subdir"
        sub_dir.mkdir()
        (sub_dir / "file3.txt").write_text("c" * 50)  # 50 bytes

        # 计算大小
        size = self.trash_manager._calculate_size(test_dir)
        assert size == 350  # 100 + 200 + 50

    def test_generate_trash_name(self):
        """测试生成回收站文件名"""
        # 使用不同的时间戳来测试
        import time
        time.sleep(0.01)  # 确保时间戳不同

        name1 = self.trash_manager._generate_trash_name("test.txt")
        sleep(0.01)
        name2 = self.trash_manager._generate_trash_name("test.txt")

        # 文件名应该包含时间戳和扩展名
        assert name1.endswith(".txt")
        assert name2.endswith(".txt")
        assert name1 != name2  # 时间戳不同

        # 测试无扩展名的情况
        name3 = self.trash_manager._generate_trash_name("README").strip()
        assert name3.startswith("README")  # 没有点，只有文件名
        assert name3.find('.') == -1

    def test_load_error_handling(self):
        """测试加载元数据错误处理"""
        # 创建无效的JSON文件
        metadata_file = self.serve_dir / TrashManager.TRASH_DIR_NAME / TrashManager.METADATA_FILE
        with open(metadata_file, 'w', encoding='utf-8') as f:
            f.write("invalid json")

        # 重新初始化，应该不会崩溃
        new_manager = TrashManager(self.serve_dir)
        assert new_manager._items == {}

    def test_save_error_handling(self, caplog):
        """测试保存元数据错误处理"""
        import logging
        import stat

        # 创建文件
        test_file = self.serve_dir / "test.txt"
        test_file.write_text("content")
        self.trash_manager.move_to_trash("test.txt")

        # 设置文件为只读
        metadata_file = self.serve_dir / TrashManager.TRASH_DIR_NAME / TrashManager.METADATA_FILE
        if os.name == 'nt':
            # Windows: 移除写权限
            os.chmod(metadata_file, stat.S_IREAD)
        else:
            os.chmod(metadata_file, 0o444)

        # 尝试再次移动文件（应该记录错误但不会崩溃）
        with caplog.at_level(logging.ERROR):
            test_file2 = self.serve_dir / "test2.txt"
            test_file2.write_text("content2")
            self.trash_manager.move_to_trash("test2.txt")

        # 恢复文件权限以便清理
        try:
            if os.name == 'nt':
                os.chmod(metadata_file, stat.S_IREAD | stat.S_IWRITE)
            else:
                os.chmod(metadata_file, 0o644)
        except OSError:
            pass

        # 检查是否有错误日志
        assert "保存回收站元数据失败" in caplog.text

        # 检查文件是否仍然被移动
        items = self.trash_manager.list_items()
        assert len(items) == 2  # 文件仍被移动，只是元数据保存失败
