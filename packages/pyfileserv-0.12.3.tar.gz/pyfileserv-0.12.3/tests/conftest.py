"""pytest 配置文件"""
import sys
from pathlib import Path

# 确保使用本地源代码而不是已安装的包
src_path = Path(__file__).parent.parent / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))
