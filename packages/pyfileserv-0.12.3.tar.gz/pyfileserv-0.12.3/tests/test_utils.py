"""测试 file_server.handle.utils 工具函数"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from file_server.handle.utils import (
    detect_file_type,
    _is_safe_path,
    _parse_multipart,
    _resolve_safe_path,
    _sanitize_filename,
)


class TestDetectFileType:
    """测试文件类型检测"""

    def test_image_extensions(self):
        for ext in ('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg', '.ico'):
            assert detect_file_type(f'file{ext}') == 'image'
            assert detect_file_type(f'FILE{ext}') == 'image'  # case insensitive

    def test_audio_extensions(self):
        for ext in ('.mp3', '.wav', '.ogg', '.flac', '.aac', '.m4a', '.wma'):
            assert detect_file_type(f'audio{ext}') == 'audio'

    def test_video_extensions(self):
        for ext in ('.mp4', '.webm', '.avi', '.mov', '.mkv'):
            assert detect_file_type(f'video{ext}') == 'video'

    def test_pdf(self):
        assert detect_file_type('doc.PDF') == 'pdf'
        assert detect_file_type('doc.pdf') == 'pdf'

    def test_markdown(self):
        assert detect_file_type('README.md') == 'markdown'
        assert detect_file_type('README.markdown') == 'markdown'
        assert detect_file_type('README.MD') == 'markdown'

    def test_xmind(self):
        assert detect_file_type('mindmap.xmind') == 'xmind'

    def test_docx(self):
        assert detect_file_type('report.docx') == 'docx'

    def test_xlsx(self):
        assert detect_file_type('data.xlsx') == 'xlsx'

    def test_pptx(self):
        assert detect_file_type('slides.pptx') == 'pptx'

    def test_json(self):
        assert detect_file_type('config.json') == 'json'

    def test_text_extensions(self):
        text_exts = ('.txt', '.py', '.js', '.html', '.css', '.xml', '.yaml', '.log')
        for ext in text_exts:
            assert detect_file_type(f'file{ext}') == 'text'

    def test_unknown_extension(self):
        assert detect_file_type('binary.dat') == 'other'
        assert detect_file_type('archive.zip') == 'other'
        assert detect_file_type('noextension') == 'other'

    def test_filename_with_multiple_dots(self):
        assert detect_file_type('archive.tar.gz') == 'other'


class TestParseMultipart:
    """测试 multipart/form-data 解析"""

    def generate_multipart(self, fields, boundary="testboundary"):
        """生成 multipart/form-data 数据"""
        body_parts = []
        for field in fields:
            body_parts.append(f'--{boundary}'.encode())
            disp = f'Content-Disposition: form-data; name="{field["name"]}"'
            if 'filename' in field:
                disp += f'; filename="{field["filename"]}"'
            body_parts.append(disp.encode())
            if 'content_type' in field:
                body_parts.append(f'Content-Type: {field["content_type"]}'.encode())
            body_parts.append(b'')
            body_parts.append(field.get('data', b''))
        body_parts.append(f'--{boundary}--'.encode())
        return b'\r\n'.join(body_parts)

    def test_single_text_field(self):
        data = self.generate_multipart([
            {'name': 'username', 'data': b'admin'},
        ])
        parts = _parse_multipart(data, 'testboundary')
        assert len(parts) == 1
        assert parts[0]['name'] == 'username'
        assert parts[0]['data'] == b'admin'
        assert parts[0]['filename'] is None

    def test_single_file_field(self):
        data = self.generate_multipart([
            {'name': 'file', 'filename': 'test.txt', 'data': b'hello world',
             'content_type': 'text/plain'},
        ])
        parts = _parse_multipart(data, 'testboundary')
        assert len(parts) == 1
        assert parts[0]['name'] == 'file'
        assert parts[0]['filename'] == 'test.txt'
        assert parts[0]['data'] == b'hello world'
        assert parts[0]['content_type'] == 'text/plain'

    def test_multiple_fields(self):
        data = self.generate_multipart([
            {'name': 'username', 'data': b'admin'},
            {'name': 'file', 'filename': 'doc.txt', 'data': b'content',
             'content_type': 'text/plain'},
        ])
        parts = _parse_multipart(data, 'testboundary')
        assert len(parts) == 2
        assert parts[0]['name'] == 'username'
        assert parts[1]['name'] == 'file'

    def test_field_with_content(self):
        data = self.generate_multipart([
            {'name': 'field', 'data': b'some value'},
        ])
        parts = _parse_multipart(data, 'testboundary')
        assert len(parts) == 1
        assert parts[0]['name'] == 'field'
        assert parts[0]['data'] == b'some value'

    def test_default_content_type(self):
        data = self.generate_multipart([
            {'name': 'file', 'filename': 'data.bin', 'data': b'binary'},
        ])
        parts = _parse_multipart(data, 'testboundary')
        assert parts[0]['content_type'] == 'application/octet-stream'

    def test_binary_data(self):
        data = self.generate_multipart([
            {'name': 'file', 'filename': 'photo.jpg',
             'data': bytes(range(256)),
             'content_type': 'image/jpeg'},
        ])
        parts = _parse_multipart(data, 'testboundary')
        assert len(parts) == 1
        assert parts[0]['data'] == bytes(range(256))

    def test_no_matching_fields(self):
        data = b'--testboundary--'
        parts = _parse_multipart(data, 'testboundary')
        assert parts == []

    def test_custom_boundary(self):
        boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
        data = self.generate_multipart(
            [{'name': 'file', 'filename': 'test.js', 'data': b'console.log(1)'}],
            boundary=boundary
        )
        parts = _parse_multipart(data, boundary)
        assert len(parts) == 1
        assert parts[0]['filename'] == 'test.js'
        assert parts[0]['data'] == b'console.log(1)'

    def test_empty_part_between_boundaries(self):
        """两个连续边界标记之间的空部分应被跳过 (line 104)"""
        boundary = "testboundary"
        # --boundary 后紧跟 --boundary（无 headers 和 body），产生空 raw_part
        payload = (
            f'--{boundary}\r\n'
            f'--{boundary}\r\n'  # 连续两个边界，中间 raw_part 为空
            f'Content-Disposition: form-data; name="ok"\r\n'
            f'\r\n'
            f'good\r\n'
            f'--{boundary}--'
        ).encode()
        parts = _parse_multipart(payload, boundary)
        assert len(parts) == 1
        assert parts[0]['name'] == 'ok'
        assert parts[0]['data'] == b'good'

    def test_part_without_header_body_separator(self):
        """缺少 CRLF-CRLF 分隔符的 part 应被跳过 (line 109)"""
        boundary = "testboundary"
        payload = (
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="bad"\r\n'
            f'no-separator-body\r\n'  # 缺少空行分隔 headers 和 body
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="good"\r\n'
            f'\r\n'
            f'data\r\n'
            f'--{boundary}--'
        ).encode()
        parts = _parse_multipart(payload, boundary)
        assert len(parts) == 1
        assert parts[0]['name'] == 'good'
        assert parts[0]['data'] == b'data'

    def test_part_without_content_disposition(self):
        """没有 Content-Disposition 头的 part 应被跳过 (line 125)"""
        boundary = "testboundary"
        payload = (
            f'--{boundary}\r\n'
            f'Content-Type: text/plain\r\n'  # 只有 Content-Type，没有 Content-Disposition
            f'\r\n'
            f'ignored data\r\n'
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="valid"\r\n'
            f'\r\n'
            f'valid data\r\n'
            f'--{boundary}--'
        ).encode()
        parts = _parse_multipart(payload, boundary)
        assert len(parts) == 1
        assert parts[0]['name'] == 'valid'
        assert parts[0]['data'] == b'valid data'

    def test_trailing_crlf_stripped_from_body(self):
        """body 末尾的 CRLF 应被去除 (line 140)"""
        boundary = "testboundary"
        payload = (
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="field"\r\n'
            f'\r\n'
            f'data with trailing crlf\r\n'
            f'--{boundary}--'
        ).encode()
        parts = _parse_multipart(payload, boundary)
        assert len(parts) == 1
        assert parts[0]['data'] == b'data with trailing crlf'
        # 确认末尾 CRLF 已去除
        assert not parts[0]['data'].endswith(b'\r\n')


class TestIsSafePath:
    """测试路径安全验证"""

    def test_safe_path_within_base(self, tmp_path):
        base = tmp_path / "root"
        base.mkdir()
        file = base / "file.txt"
        file.write_text("content")
        assert _is_safe_path(base, file)

    def test_traversal_attack(self, tmp_path):
        base = tmp_path / "root"
        base.mkdir()
        (tmp_path / "evil.txt").write_text("secret")
        # 路径遍历攻击被拒绝
        assert not _is_safe_path(base, tmp_path / "root" / ".." / "evil.txt")

    def test_symlink_traversal(self, tmp_path):
        base = tmp_path / "root"
        base.mkdir()
        # 不同的路径不应被视为 safe
        outside = tmp_path / "outside.txt"
        outside.write_text("secret")
        assert not _is_safe_path(base, outside)

    def test_safe_subdirectory(self, tmp_path):
        base = tmp_path / "root"
        base.mkdir()
        sub = base / "sub"
        sub.mkdir()
        file = sub / "deep.txt"
        file.write_text("deep")
        assert _is_safe_path(base, file)


class TestSanitizeFilename:
    """测试文件名清理"""

    def test_normal_filename(self):
        assert _sanitize_filename("hello.txt") == "hello.txt"

    def test_path_traversal(self):
        """路径遍历字符应被移除"""
        assert _sanitize_filename("../../../etc/passwd") == "passwd"

    def test_dangerous_chars(self):
        """危险字符应被替换为下划线"""
        result = _sanitize_filename("file<name>.txt")
        assert result == "file_name_.txt"

    def test_pipe_char(self):
        """管道字符应被替换"""
        assert _sanitize_filename("cmd|test.txt") == "cmd_test.txt"

    def test_null_byte(self):
        """NULL 字节应被替换"""
        assert _sanitize_filename("test\x00file.txt") == "test_file.txt"

    def test_leading_dot_removed(self):
        """开头的点应被移除"""
        assert _sanitize_filename(".hidden") == "hidden"

    def test_leading_space_removed(self):
        """开头的空格应被移除"""
        assert _sanitize_filename("  file.txt") == "file.txt"

    def test_all_dots_and_spaces(self):
        """只包含点和空格的文件名应回退为默认名"""
        assert _sanitize_filename("...") == "unnamed_file"
        assert _sanitize_filename("   ") == "unnamed_file"
        assert _sanitize_filename("") == "unnamed_file"


class TestResolveSafePath:
    """测试安全路径解析"""

    def test_valid_path(self, tmp_path):
        base = tmp_path / "root"
        base.mkdir()
        (base / "file.txt").write_text("hi")
        result = _resolve_safe_path(base, "file.txt")
        assert result is not None
        assert result.name == "file.txt"

    def test_traversal_rejected(self, tmp_path):
        base = tmp_path / "root"
        base.mkdir()
        result = _resolve_safe_path(base, "../etc/passwd")
        assert result is None

    def test_relative_path(self, tmp_path):
        base = tmp_path / "root"
        base.mkdir()
        result = _resolve_safe_path(base, ".")
        assert result is not None
