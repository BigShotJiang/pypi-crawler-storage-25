"""测试 HTML 模板模块"""
import sys
import time
from datetime import datetime
from pathlib import Path

# 确保使用本地源代码
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from file_server.template import (
    format_size, format_time, render_file_list_page, _escape_html,
    render_login_page, render_upload_page, render_json_view_page,
    render_image_preview_page, render_audio_preview_page, render_text_preview_page
)


class TestFormatSize:
    """测试文件大小格式化函数"""

    def test_format_size_bytes(self):
        """测试字节单位"""
        assert format_size(0) == "0 B"
        assert format_size(100) == "100 B"
        assert format_size(1023) == "1023 B"

    def test_format_size_kilobytes(self):
        """测试 KB 单位"""
        assert format_size(1024) == "1.0 KB"
        assert format_size(2048) == "2.0 KB"
        assert format_size(1536) == "1.5 KB"
        assert format_size(1024 * 1024 - 1) == "1024.0 KB"

    def test_format_size_megabytes(self):
        """测试 MB 单位"""
        assert format_size(1024 * 1024) == "1.0 MB"
        assert format_size(2 * 1024 * 1024) == "2.0 MB"
        assert format_size(1536 * 1024) == "1.5 MB"

    def test_format_size_gigabytes(self):
        """测试 GB 单位"""
        assert format_size(1024 * 1024 * 1024) == "1.0 GB"
        assert format_size(2 * 1024 * 1024 * 1024) == "2.0 GB"


class TestFormatTime:
    """测试时间格式化函数"""

    def test_format_time_valid(self):
        """测试有效时间戳格式化"""
        # 使用一个固定的时间戳进行测试
        test_timestamp = 1700000000.0  # 2023-11-14 左右
        result = format_time(test_timestamp)

        # 验证格式是 YYYY-MM-DD HH:MM:SS
        assert len(result) == 19
        assert result[4] == '-'
        assert result[7] == '-'
        assert result[10] == ' '
        assert result[13] == ':'
        assert result[16] == ':'

        # 验证可以解析回 datetime
        parsed = datetime.strptime(result, '%Y-%m-%d %H:%M:%S')
        assert parsed is not None

    def test_format_time_current(self):
        """测试当前时间格式化"""
        current_time = time.time()
        result = format_time(current_time)
        # 只需要验证格式正确，不需要验证具体值
        assert len(result) == 19


class TestRenderFileListPage:
    """测试文件列表页面渲染"""

    def test_render_file_list_page_basic(self):
        """测试基本页面渲染"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        # 验证页面包含必要元素
        assert "<!DOCTYPE html>" in html
        assert "文件列表" in html
        assert "testuser" in html
        assert "根目录" in html

    def test_render_file_list_page_with_directories(self):
        """测试带有目录的页面渲染"""
        test_time = time.time()
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[("mydir", test_time)],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        assert "mydir" in html
        assert "📁" in html
        assert "1 个目录" in html

    def test_render_file_list_page_with_files(self):
        """测试带有文件的页面渲染"""
        test_time = time.time()
        html = render_file_list_page(
            username="testuser",
            files_by_type={
                'json': [("data.json", 512, test_time)],
                'text': [("index.html", 1024, test_time), ("doc.txt", 256, test_time)],
                'xmind': [("test.xmind", 2048, test_time)]
            },
            directories=[],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        assert "index.html" in html
        assert "test.xmind" in html
        assert "data.json" in html
        assert "doc.txt" in html
        assert "1.0 KB" in html
        assert format_time(test_time) in html

    def test_render_file_list_page_with_subdirectory(self):
        """测试子目录路径渲染"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path="subdir1/subdir2",
            sort_by="name",
            search_query=""
        )

        # 验证面包屑导航
        assert "根目录" in html
        assert "subdir1" in html
        assert "subdir2" in html

    def test_render_file_list_page_sort_options(self):
        """测试排序选项"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path=".",
            sort_by="time",
            search_query=""
        )

        assert 'value="time" selected' in html or 'value="time"' in html
        assert "按时间" in html

    def test_render_file_list_page_search_query(self):
        """测试搜索查询"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path=".",
            sort_by="name",
            search_query="test"
        )

        assert 'value="test"' in html

    def test_render_file_list_page_javascript_functions(self):
        """测试 JavaScript 函数存在"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        assert "filterFiles" in html
        assert "changeSort" in html
        assert "dirList" in html
        assert "dirCount" in html

    def test_render_file_list_page_statistics(self):
        """测试统计信息"""
        test_time = time.time()
        html = render_file_list_page(
            username="testuser",
            files_by_type={
                'text': [("a.html", 100, test_time), ("b.html", 200, test_time)]
            },
            directories=[("dir1", test_time), ("dir2", test_time)],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        assert "2 个目录" in html
        assert "2 个文件" in html
        assert "300 B" in html  # 总大小

    def test_render_file_list_page_dark_mode_support(self):
        """测试深色模式支持"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        # 检查深色模式相关的 CSS 和 JavaScript（已迁移到外部文件）
        assert '/static/css/common.css' in html
        assert '/static/js/theme.js' in html
        assert "toggleTheme" in html

    def test_render_file_list_page_toast_notifications(self):
        """测试 Toast 通知功能"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        assert "toast" in html
        assert "showToast" in html
        assert "toast-container" in html

    def test_render_file_list_page_modal_dialogs(self):
        """测试模态对话框功能"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        assert "modal" in html
        assert "deleteModal" in html
        assert "renameModal" in html
        assert "moveModal" in html
        assert "mkdirModal" in html

    def test_render_file_list_page_file_operation_buttons(self):
        """测试文件操作按钮"""
        test_time = time.time()
        html = render_file_list_page(
            username="testuser",
            files_by_type={
                'text': [("test.html", 100, test_time)]
            },
            directories=[("mydir", test_time)],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        # 检查文件操作按钮
        assert "✏️" in html
        assert "📤" in html
        assert "📋" in html
        assert "🗑️" in html

    def test_render_file_list_page_mkdir_button(self):
        """测试创建目录按钮"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        assert "创建目录" in html
        assert "showMkdirModal" in html

    def test_render_file_list_page_api_endpoints(self):
        """测试 API 端点引用"""
        html = render_file_list_page(
            username="testuser",
            files_by_type={},
            directories=[],
            current_path=".",
            sort_by="name",
            search_query=""
        )

        assert "/api/delete" in html
        assert "/api/rename" in html
        assert "/api/move" in html
        assert "/api/copy" in html
        assert "/api/mkdir" in html
        assert "/api/directories" in html


class TestEscapeHtml:
    """测试 HTML 转义函数"""

    def test_escape_html_basic(self):
        """测试基本的 HTML 转义"""
        assert _escape_html("<script>") == "&lt;script&gt;"
        assert _escape_html("&") == "&amp;"
        assert _escape_html('"') == "&quot;"
        assert _escape_html("'") == "&#039;"

    def test_escape_html_combined(self):
        """测试组合的 HTML 转义"""
        assert _escape_html('<a href="test">link</a>') == "&lt;a href=&quot;test&quot;&gt;link&lt;/a&gt;"

    def test_escape_html_no_change(self):
        """测试不需要转义的字符串"""
        assert _escape_html("normal text 123") == "normal text 123"
        assert _escape_html("") == ""


class TestRenderLoginPage:
    """测试登录页面渲染"""

    def test_render_login_page_basic(self):
        """测试基本登录页面渲染"""
        html = render_login_page()
        assert "<!DOCTYPE html>" in html
        assert "登录" in html
        assert "username" in html
        assert "password" in html

    def test_render_login_page_with_error(self):
        """测试带错误信息的登录页面"""
        html = render_login_page(error_msg="用户名或密码错误")
        assert "用户名或密码错误" in html

    def test_render_login_page_css(self):
        """测试登录页面 CSS 样式（已迁移到外部文件）"""
        html = render_login_page()
        assert '/static/css/common.css' in html
        assert '/static/css/forms.css' in html


class TestRenderUploadPage:
    """测试上传页面渲染"""

    def test_render_upload_page_basic(self):
        """测试基本上传页面渲染"""
        html = render_upload_page(username="testuser")
        assert "<!DOCTYPE html>" in html
        assert "上传文件" in html
        assert "testuser" in html

    def test_render_upload_page_drop_zone(self):
        """测试拖拽上传区域"""
        html = render_upload_page(username="testuser")
        assert "dropZone" in html
        assert "拖拽" in html


class TestRenderJsonViewPage:
    """测试 JSON 查看页面渲染"""

    def test_render_json_view_page_basic(self):
        """测试基本 JSON 查看页面渲染"""
        html = render_json_view_page(
            username="testuser",
            filename="data.json",
            json_content='{"test": "value"}'
        )
        assert "<!DOCTYPE html>" in html
        assert "data.json" in html
        assert '{\"test\": \"value\"}' in html or "test" in html  # 可能被转义

    def test_render_json_view_page_copy_button(self):
        """测试复制按钮"""
        html = render_json_view_page(
            username="testuser",
            filename="data.json",
            json_content="{}"
        )
        assert "复制内容" in html
        assert "copyContent" in html

    def test_render_json_view_page_dark_mode(self):
        """测试 JSON 页面的深色模式"""
        html = render_json_view_page(
            username="testuser",
            filename="data.json",
            json_content="{}"
        )
        assert "toggleTheme" in html
        assert '/static/css/header.css' in html


class TestRenderImagePreviewPage:
    """测试图片预览页面渲染"""

    def test_render_image_preview_basic(self):
        """测试基本图片预览页面"""
        image_urls = ["image1.jpg", "image2.jpg", "image3.jpg"]
        html = render_image_preview_page(
            username="testuser",
            file_path="photos/image1.jpg",
            file_name="image1.jpg",
            image_urls=image_urls,
            current_index=0
        )
        
        assert "<!DOCTYPE html>" in html
        assert "图片预览" in html
        assert "testuser" in html
        assert "image1.jpg" in html
        assert "download" in html  # 下载链接

    def test_render_image_preview_navigation_elements(self):
        """测试导航元素"""
        image_urls = ["img1.jpg", "img2.jpg", "img3.jpg"]
        html = render_image_preview_page(
            username="testuser",
            file_path="photos/img1.jpg",
            file_name="img1.jpg",
            image_urls=image_urls,
            current_index=1
        )
        
        # 检查导航按钮
        assert "◀" in html or "prev" in html
        assert "▶" in html or "next" in html
        
        # 检查计数器
        assert "2 / 3" in html

    def test_render_image_preview_image_names_array(self):
        """测试图片名称数组生成"""
        image_urls = ["photos/cat.jpg", "photos/dog.png", "photos/bird.gif"]
        html = render_image_preview_page(
            username="testuser",
            file_path="photos/cat.jpg",
            file_name="cat.jpg",
            image_urls=image_urls,
            current_index=0
        )
        
        # 检查 JavaScript 中是否有图片名称数组
        assert "imageNames" in html
        assert "cat.jpg" in html
        assert "dog.png" in html
        assert "bird.gif" in html

    def test_render_image_preview_download_link(self):
        """测试下载链接使用 /download/ 路由"""
        html = render_image_preview_page(
            username="testuser",
            file_path="photos/test.jpg",
            file_name="test.jpg",
            image_urls=["photos/test.jpg"],
            current_index=0
        )
        
        # 确保使用 /download/ 而不是 /preview/
        assert '/download/' in html
        # 不应该有指向 /preview/ 的图片 src
        import re
        img_srcs = re.findall(r'<img[^>]+src="([^"]+)"', html)
        for src in img_srcs:
            assert '/preview/' not in src, f"图片 src 不应使用 /preview/ 路由: {src}"

    def test_render_image_preview_toolbar_title_id(self):
        """测试工具栏标题具有 ID 属性"""
        html = render_image_preview_page(
            username="testuser",
            file_path="photos/photo.jpg",
            file_name="photo.jpg",
            image_urls=["photos/photo.jpg"],
            current_index=0
        )
        
        # 检查标题元素有 ID
        assert 'id="imageTitle"' in html
        # 检查下载按钮有 ID
        assert 'id="downloadBtn"' in html

    def test_render_image_preview_javascript_sync_function(self):
        """测试 JavaScript 同步更新功能"""
        html = render_image_preview_page(
            username="testuser",
            file_path="photos/test.jpg",
            file_name="test.jpg",
            image_urls=["photos/test.jpg", "photos/test2.jpg"],
            current_index=0
        )
        
        # 检查 navigateImage 函数存在
        assert "navigateImage" in html
        
        # 检查是否更新标题
        assert "imageTitle" in html
        assert "textContent" in html
        
        # 检查是否更新下载链接
        assert "downloadBtn" in html
        assert "href" in html


class TestRenderAudioPreviewPage:
    """测试音频预览页面渲染"""

    def test_render_audio_preview_basic(self):
        """测试基本音频预览页面"""
        audio_urls = ["song1.mp3", "song2.mp3"]
        html = render_audio_preview_page(
            username="testuser",
            file_path="music/song1.mp3",
            file_name="song1.mp3",
            audio_urls=audio_urls,
            current_index=0
        )
        
        assert "<!DOCTYPE html>" in html
        assert "音频预览" in html
        assert "testuser" in html
        assert "song1.mp3" in html
        assert "<audio" in html

    def test_render_audio_preview_navigation_elements(self):
        """测试导航元素"""
        audio_urls = ["track1.mp3", "track2.mp3", "track3.mp3"]
        html = render_audio_preview_page(
            username="testuser",
            file_path="music/track1.mp3",
            file_name="track1.mp3",
            audio_urls=audio_urls,
            current_index=1
        )
        
        # 检查导航按钮
        assert "上一首" in html or "prev" in html
        assert "下一首" in html or "next" in html
        
        # 检查计数器
        assert "2 / 3" in html

    def test_render_audio_preview_audio_names_array(self):
        """测试音频名称数组生成"""
        audio_urls = ["music/jazz.mp3", "music/rock.wav", "music/pop.ogg"]
        html = render_audio_preview_page(
            username="testuser",
            file_path="music/jazz.mp3",
            file_name="jazz.mp3",
            audio_urls=audio_urls,
            current_index=0
        )
        
        # 检查 JavaScript 中是否有音频名称数组
        assert "audioNames" in html
        assert "jazz.mp3" in html
        assert "rock.wav" in html
        assert "pop.ogg" in html

    def test_render_audio_preview_download_link(self):
        """测试下载链接使用 /download/ 路由"""
        html = render_audio_preview_page(
            username="testuser",
            file_path="music/test.mp3",
            file_name="test.mp3",
            audio_urls=["music/test.mp3"],
            current_index=0
        )
        
        # 确保使用 /download/ 而不是 /preview/
        assert '/download/' in html
        
        # 检查 audio source 使用 /download/
        import re
        audio_sources = re.findall(r'<source[^>]+src="([^"]+)"', html)
        for src in audio_sources:
            assert '/preview/' not in src, f"音频 src 不应使用 /preview/ 路由: {src}"

    def test_render_audio_preview_toolbar_title_id(self):
        """测试工具栏标题具有 ID 属性"""
        html = render_audio_preview_page(
            username="testuser",
            file_path="music/song.mp3",
            file_name="song.mp3",
            audio_urls=["music/song.mp3"],
            current_index=0
        )
        
        # 检查标题元素有 ID
        assert 'id="audioTitle"' in html
        # 检查下载按钮有 ID
        assert 'id="downloadBtn"' in html

    def test_render_audio_preview_javascript_sync_function(self):
        """测试 JavaScript 同步更新功能"""
        html = render_audio_preview_page(
            username="testuser",
            file_path="music/test.mp3",
            file_name="test.mp3",
            audio_urls=["music/test.mp3", "music/test2.mp3"],
            current_index=0
        )
        
        # 检查 navigateAudio 函数存在
        assert "navigateAudio" in html
        
        # 检查是否更新标题
        assert "audioTitle" in html
        assert "textContent" in html
        
        # 检查是否更新音频名称
        assert "audioName" in html
        
        # 检查是否更新下载链接
        assert "downloadBtn" in html


class TestRenderTextPreviewPage:
    """测试文本/代码预览页面渲染"""

    def test_render_text_preview_basic(self):
        """测试基本文本预览页面"""
        content = "Hello World\nThis is a test."
        html = render_text_preview_page(
            username="testuser",
            file_path="code/test.py",
            file_name="test.py",
            content=content,
            language="python"
        )
        
        assert "<!DOCTYPE html>" in html
        assert "代码预览" in html
        assert "testuser" in html
        assert "test.py" in html
        assert "python" in html

    def test_render_text_preview_line_numbers(self):
        """测试行号生成"""
        content = "line1\nline2\nline3"
        html = render_text_preview_page(
            username="testuser",
            file_path="test.txt",
            file_name="test.txt",
            content=content,
            language="plaintext"
        )
        
        # 检查行号
        assert "1" in html
        assert "2" in html
        assert "3" in html
        assert "line-numbers" in html

    def test_render_text_preview_html_escaping(self):
        """测试 HTML 转义"""
        content = '<script>alert("XSS")</script>'
        html = render_text_preview_page(
            username="testuser",
            file_path="test.html",
            file_name="test.html",
            content=content,
            language="html"
        )
        
        # 检查特殊字符被转义
        assert "&lt;script&gt;" in html
        assert "&quot;" in html or "&#039;" in html

    def test_render_text_preview_whitespace_preservation(self):
        """测试空白字符保留样式"""
        content = "def hello():\n    print('world')"
        html = render_text_preview_page(
            username="testuser",
            file_path="hello.py",
            file_name="hello.py",
            content=content,
            language="python"
        )
        
        # 检查 white-space: pre 样式
        assert "white-space" in html
        assert "pre" in html

    def test_render_text_preview_scroll_sync_javascript(self):
        """测试滚动同步 JavaScript"""
        content = "line1\n" * 100  # 多行内容以触发滚动
        html = render_text_preview_page(
            username="testuser",
            file_path="long.txt",
            file_name="long.txt",
            content=content,
            language="plaintext"
        )
        
        # 检查滚动同步代码
        assert "scroll" in html
        assert "scrollTop" in html
        assert "lineNumbers" in html or "line-numbers" in html

    def test_render_text_preview_copy_function(self):
        """测试复制功能"""
        html = render_text_preview_page(
            username="testuser",
            file_path="test.py",
            file_name="test.py",
            content="print('hello')",
            language="python"
        )
        
        # 检查复制按钮和函数
        assert "复制" in html or "copy" in html.lower()
        assert "copyCode" in html
        assert "clipboard" in html or "execCommand" in html

    def test_render_text_preview_highlight_js_integration(self):
        """测试 highlight.js 集成"""
        html = render_text_preview_page(
            username="testuser",
            file_path="test.js",
            file_name="test.js",
            content="console.log('test');",
            language="javascript"
        )
        
        # 检查 highlight.js 引用
        assert "highlight.js" in html or "hljs" in html
        
        # 检查语言类名
        assert "language-javascript" in html
        
        # 检查初始化调用
        assert "highlightAll" in html or "hljs.highlight" in html

    def test_render_text_preview_code_block_structure(self):
        """测试代码块结构"""
        html = render_text_preview_page(
            username="testuser",
            file_path="test.py",
            file_name="test.py",
            content="code",
            language="python"
        )
        
        # 检查代码容器结构
        assert "code-container" in html
        assert "code-header" in html
        assert "code-body" in html
        assert "code-content" in html
        assert "<pre>" in html
        assert "<code" in html

    def test_render_text_preview_file_info_display(self):
        """测试文件信息显示"""
        content = "line1\nline2\nline3"
        html = render_text_preview_page(
            username="testuser",
            file_path="test.py",
            file_name="test.py",
            content=content,
            language="python"
        )
        
        # 检查文件名显示
        assert "test.py" in html
        
        # 检查行数显示
        assert "3 行" in html or "3" in html
        
        # 检查语言显示
        assert "python" in html


# 为了测试访问 CSS 常量，导入它们
from file_server.template import CSS_GRADIENT_PRIMARY
