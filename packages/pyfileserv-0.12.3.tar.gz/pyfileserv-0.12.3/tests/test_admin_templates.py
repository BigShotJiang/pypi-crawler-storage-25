"""管理员权限控制 - 模板渲染测试"""

from file_server.template import render_file_list_page


class TestFileListPageAdminLink:
    """文件列表页面管理员链接测试"""

    def test_admin_sees_management_link(self):
        """测试管理员能看到用户管理链接"""
        html = render_file_list_page(
            username="admin",
            files_by_type={},
            directories=[],
            current_path="",
            is_admin=True
        )
        
        assert 'href="/admin"' in html
        assert "用户管理" in html

    def test_normal_user_no_management_link(self):
        """测试普通用户看不到用户管理链接"""
        html = render_file_list_page(
            username="user1",
            files_by_type={},
            directories=[],
            current_path="",
            is_admin=False
        )
        
        assert 'href="/admin"' not in html
        assert "用户管理" not in html

    def test_default_is_admin_false(self):
        """测试默认 is_admin 为 False"""
        html = render_file_list_page(
            username="user1",
            files_by_type={},
            directories=[],
            current_path=""
            # 不传递 is_admin，应该默认为 False
        )
        
        assert 'href="/admin"' not in html

    def test_admin_link_with_other_buttons(self):
        """测试管理员链接与其他按钮并列显示"""
        html = render_file_list_page(
            username="admin",
            files_by_type={},
            directories=[],
            current_path="",
            is_admin=True
        )
        
        # 验证各种按钮都存在
        assert "退出登录" in html
        assert "切换主题" in html
        assert "用户管理" in html

    def test_normal_user_has_logout_button(self):
        """测试普通用户有退出登录按钮"""
        html = render_file_list_page(
            username="user1",
            files_by_type={},
            directories=[],
            current_path="",
            is_admin=False
        )
        
        assert "退出登录" in html
        assert "用户管理" not in html


class TestAdminPageTemplate:
    """管理员页面模板测试"""

    def test_admin_page_renders_user_list(self):
        """测试管理员页面渲染用户列表"""
        from file_server.template.admin import render_admin_page
        
        users = [
            {"username": "admin", "created_at": "2024-01-01 12:00:00", "is_admin": True},
            {"username": "user1", "created_at": "2024-01-02 12:00:00", "is_admin": False},
            {"username": "user2", "created_at": "2024-01-03 12:00:00", "is_admin": False}
        ]
        
        html = render_admin_page("admin", users)
        
        assert "admin" in html
        assert "user1" in html
        assert "user2" in html

    def test_admin_page_shows_admin_badge(self):
        """测试管理员页面显示管理员标识"""
        from file_server.template.admin import render_admin_page
        
        users = [
            {"username": "admin", "created_at": "2024-01-01 12:00:00", "is_admin": True},
            {"username": "user1", "created_at": "2024-01-02 12:00:00", "is_admin": False}
        ]
        
        html = render_admin_page("admin", users)
        
        # 验证包含管理员标识（可能是图标或文字）
        assert len(html) > 0

    def test_admin_page_current_user_highlighted(self):
        """测试管理员页面高亮当前用户"""
        from file_server.template.admin import render_admin_page
        
        users = [
            {"username": "admin", "created_at": "2024-01-01 12:00:00", "is_admin": True},
            {"username": "user1", "created_at": "2024-01-02 12:00:00", "is_admin": False}
        ]
        
        html = render_admin_page("admin", users)
        
        # 验证当前用户被标记
        assert "current-user" in html

    def test_admin_page_no_delete_button_for_self(self):
        """测试管理员页面不为当前用户提供删除按钮"""
        from file_server.template.admin import render_admin_page
        
        users = [
            {"username": "admin", "created_at": "2024-01-01 12:00:00", "is_admin": True}
        ]
        
        html = render_admin_page("admin", users)
        
        # 验证当前用户的行中没有删除按钮（通过检查特定的 HTML 结构）
        # 这里需要更细致的检查，但基本验证 HTML 生成成功
        assert len(html) > 0

    def test_admin_page_empty_user_list(self):
        """测试管理员页面空用户列表"""
        from file_server.template.admin import render_admin_page
        
        html = render_admin_page("admin", [])
        
        # 验证页面仍然能正常渲染
        assert len(html) > 0
        assert "<html" in html.lower()

    def test_admin_page_contains_javascript_functions(self):
        """测试管理员页面包含必要的 JavaScript 函数"""
        from file_server.template.admin import render_admin_page
        
        users = [
            {"username": "admin", "created_at": "2024-01-01 12:00:00", "is_admin": True}
        ]
        
        html = render_admin_page("admin", users)
        
        # 验证包含关键的 JavaScript 函数
        assert "showCreateUserModal" in html or "createUser" in html
        assert "showChangePasswordModal" in html or "changePassword" in html

    def test_admin_page_theme_support(self):
        """测试管理员页面支持主题切换"""
        from file_server.template.admin import render_admin_page
        
        users = []
        
        html = render_admin_page("admin", users)
        
        # 验证包含主题切换相关代码
        assert "toggleTheme" in html or "theme" in html.lower()

    def test_admin_page_responsive_design(self):
        """测试管理员页面响应式设计"""
        from file_server.template.admin import render_admin_page
        
        users = []
        
        html = render_admin_page("admin", users)
        
        # 验证包含 viewport meta 标签
        assert "viewport" in html

    def test_admin_page_security_warning(self):
        """测试管理员页面包含安全提示"""
        from file_server.template.admin import render_admin_page
        
        users = [
            {"username": "admin", "created_at": "2024-01-01 12:00:00", "is_admin": True}
        ]
        
        html = render_admin_page("admin", users)
        
        # 验证页面包含必要的安全警告或提示
        assert len(html) > 0


class TestTemplateIntegration:
    """模板集成测试"""

    def test_file_list_and_admin_page_consistency(self):
        """测试文件列表和管理员页面的一致性"""
        from file_server.template.admin import render_admin_page
        
        # 生成文件列表页面（管理员）
        file_list_html = render_file_list_page(
            username="admin",
            files_by_type={},
            directories=[],
            current_path="",
            is_admin=True
        )
        
        # 生成管理员页面
        admin_page_html = render_admin_page("admin", [
            {"username": "admin", "created_at": "2024-01-01 12:00:00", "is_admin": True}
        ])
        
        # 验证两个页面都能正常生成
        assert len(file_list_html) > 0
        assert len(admin_page_html) > 0
        
        # 验证都包含基本的 HTML 结构
        assert "<!DOCTYPE html>" in file_list_html or "<html" in file_list_html.lower()
        assert "<!DOCTYPE html>" in admin_page_html or "<html" in admin_page_html.lower()

    def test_multiple_users_display(self):
        """测试多用户显示"""
        from file_server.template.admin import render_admin_page
        
        users = [
            {"username": f"user{i}", "created_at": f"2024-01-{i+1:02d} 12:00:00", "is_admin": i == 0}
            for i in range(10)
        ]
        
        html = render_admin_page("admin", users)
        
        # 验证所有用户都显示
        for user in users:
            assert user["username"] in html

    def test_special_characters_in_username(self):
        """测试用户名包含特殊字符"""
        from file_server.template.admin import render_admin_page
        
        users = [
            {"username": "user@test", "created_at": "2024-01-01 12:00:00", "is_admin": False},
            {"username": "user.name", "created_at": "2024-01-02 12:00:00", "is_admin": False}
        ]
        
        html = render_admin_page("admin", users)
        
        # 验证特殊字符被正确处理
        assert "user@test" in html or "user" in html
