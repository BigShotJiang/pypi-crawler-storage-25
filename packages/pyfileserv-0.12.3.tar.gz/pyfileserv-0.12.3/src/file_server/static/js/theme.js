function initTheme() {
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const theme = savedTheme || (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
    updateThemeBtn(theme);
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    const newTheme = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeBtn(newTheme);
    if (typeof showToast === 'function') {
        showToast(newTheme === 'dark' ? '已切换到深色模式' : '已切换到浅色模式', 'info');
    }
}

function updateThemeBtn(theme) {
    var btn = document.querySelector('.dropdown-item[onclick="toggleTheme()"]');
    if (btn) {
        btn.innerHTML = (theme === 'dark' ? '☀️' : '🌙') + ' 切换主题';
    }
}
