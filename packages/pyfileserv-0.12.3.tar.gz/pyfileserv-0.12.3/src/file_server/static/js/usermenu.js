function toggleUserMenu(e) {
    e.stopPropagation();
    var dd = document.getElementById('userDropdown');
    if (dd) dd.classList.toggle('show');
}

document.addEventListener('click', function(e) {
    var dd = document.getElementById('userDropdown');
    if (dd && !dd.contains(e.target) && !e.target.classList.contains('user-badge')) {
        dd.classList.remove('show');
    }
});
