"""HTTP 请求处理器

通过 Mixin 多重继承组合所有功能模块。
"""
import http.server
import logging
from typing import Optional

from .config import ServerConfig
from .core.auth import Authenticator, SessionManager, UserStore
from .core.share import ShareManager
from .core.trash import TrashManager
from .handle.admin import AdminHandler
from .handle.auth import AuthMixin
from .handle.base_mixin import BaseMixin
from .handle.file_ops import FileOpsMixin
from .handle.preview import PreviewMixin
from .handle.share import ShareMixin
from .handle.trash import TrashMixin

logger = logging.getLogger(__name__)


class SecureHTTPRequestHandler(
    BaseMixin, AuthMixin, PreviewMixin, FileOpsMixin,
    ShareMixin, TrashMixin, http.server.SimpleHTTPRequestHandler
):
    """安全文件服务器请求处理器

    通过多重继承组合以下 Mixin:
    - BaseMixin: IP检查、JSON响应、静态文件、HTTP路由分发
    - AuthMixin: 认证（login/logout/session）
    - PreviewMixin: 文件预览（图片、视频、Office文档等）
    - FileOpsMixin: 文件操作（上传、下载、删除、重命名等）
    - ShareMixin: 分享功能（创建、管理分享链接）
    - TrashMixin: 回收站功能
    """

    # 类级别注入依赖（所有 mixin 共享这些属性）
    authenticator: Optional[Authenticator] = None
    session_manager: Optional[SessionManager] = None
    config: Optional[ServerConfig] = None
    share_manager: Optional[ShareManager] = None
    trash_manager: Optional[TrashManager] = None
    user_store: Optional[UserStore] = None
    admin_handler: Optional[AdminHandler] = None
