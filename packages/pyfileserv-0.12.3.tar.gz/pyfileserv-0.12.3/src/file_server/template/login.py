"""登录页面模板"""
from .base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    css_links,
)


def render_login_page(error_msg: str = "", session_timeout: int = 3600) -> str:
    """渲染登录页面"""
    timeout_text = f"{session_timeout // 3600}小时" if session_timeout >= 3600 else f"{session_timeout // 60}分钟"
    error_html = f'<div class="error">{error_msg}</div>' if error_msg else ""

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - 文件服务器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'forms.css', 'error.css', 'buttons.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: {CSS_GRADIENT_PRIMARY};
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }}
        .login-container {{
            background: var(--bg-secondary);
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            padding: 40px;
            width: 100%;
            max-width: 400px;
        }}
        .login-header {{
            text-align: center;
            margin-bottom: 30px;
        }}
        .login-header .logo {{
            margin-bottom: 15px;
        }}
        .login-header h1 {{
            color: var(--text-primary);
            font-size: 28px;
            margin-bottom: 10px;
        }}
        .form-group {{
            margin-bottom: 20px;
        }}
        .form-group label {{
            display: block;
            margin-bottom: 8px;
            color: var(--text-primary);
            font-weight: 600;
            font-size: 14px;
        }}
        .btn-login {{
            width: 100%;
        }}
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo">{LOGO_SVG}</div>
            <h1>文件服务器</h1>
        </div>
        {error_html}
        <form method="POST" action="/do_login">
            <div class="form-group">
                <label for="username">用户名</label>
                <input type="text" id="username" name="username" required autofocus>
            </div>
            <div class="form-group">
                <label for="password">密码</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn-login btn-primary">登录</button>
        </form>
    </div>
</body>
</html>
"""


__all__ = ['render_login_page']
