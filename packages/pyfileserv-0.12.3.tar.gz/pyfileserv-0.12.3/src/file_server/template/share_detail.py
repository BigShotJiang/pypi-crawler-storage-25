"""share_detail template"""

from .base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    format_size,
    _escape_html,
    css_links,
    js_scripts,
)

def render_share_detail_page(share_id: str, root_name: str, items: list, current_path: str) -> str:
    """渲染分享详情页面（验证通过后显示文件列表）

    Args:
        share_id: 分享ID
        root_name: 根目录/文件名
        items: 文件/文件夹列表，每项为字典包含:
            - name: 名称
            - is_dir: 是否为目录
            - size: 文件大小（字节）
            - path: 相对路径
        current_path: 当前浏览的路径
    """
    # 生成文件列表HTML
    items_html = ""
    if not items:
        items_html = '<div class="empty-tip">此目录为空</div>'
    else:
        for item in items:
            name = _escape_html(item['name'])
            is_dir = item['is_dir']
            size = format_size(item.get('size', 0)) if not is_dir else '-'
            icon = "📁" if is_dir else "📄"
            item_path = quote_path(item['path'], leading_slash=False)

            if is_dir:
                # 文件夹：点击进入
                items_html += f"""
                <div class="file-item folder" onclick="navigateTo('{item_path}')">
                    <span class="file-icon">{icon}</span>
                    <span class="file-name">{name}</span>
                    <span class="file-size">{size}</span>
                </div>"""
            else:
                # 文件：点击下载
                download_url = f'/share/file/{share_id}/{item_path}'
                items_html += f"""
                <div class="file-item file">
                    <span class="file-icon">{icon}</span>
                    <span class="file-name">{name}</span>
                    <span class="file-size">{size}</span>
                    <a href="{download_url}" class="download-link" download title="下载">⬇️</a>
                </div>"""

    # 面包屑导航
    breadcrumb_parts = ['<a href="#" onclick="navigateTo(\'\')" class="breadcrumb-link">🏠 首页</a>']
    if current_path:
        parts = current_path.split('/')
        accumulated = ''
        for i, part in enumerate(parts):
            if part:
                accumulated = accumulated + '/' + part if accumulated else part
                encoded_path = quote_path(accumulated, leading_slash=False)
                breadcrumb_parts.append(f'<a href="#" onclick="navigateTo(\'{encoded_path}\')" class="breadcrumb-link">{_escape_html(part)}</a>')
    breadcrumb_html = ' / '.join(breadcrumb_parts)

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(root_name)} - 分享详情</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header {{
            background: {CSS_GRADIENT_PRIMARY};
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .breadcrumb {{
            background: var(--bg-secondary);
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            color: var(--text-secondary);
        }}
        .breadcrumb-link {{
            color: #667eea;
            text-decoration: none;
            transition: color 0.2s;
        }}
        .breadcrumb-link:hover {{
            color: #764ba2;
            text-decoration: underline;
        }}
        .file-list {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .file-item {{
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 8px;
            transition: all 0.2s;
            cursor: pointer;
        }}
        .file-item:hover {{
            background: var(--bg-hover);
            transform: translateX(5px);
        }}
        .file-item.folder {{
            color: var(--text-primary);
        }}
        .file-item.file {{
            color: var(--text-primary);
        }}
        .file-icon {{
            font-size: 24px;
            margin-right: 15px;
            min-width: 30px;
        }}
        .file-name {{
            flex: 1;
            font-size: 15px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}
        .file-size {{
            color: var(--text-secondary);
            font-size: 13px;
            margin: 0 15px;
            min-width: 80px;
            text-align: right;
        }}
        .download-link {{
            font-size: 20px;
            text-decoration: none;
            opacity: 0.6;
            transition: opacity 0.2s;
            margin-left: 10px;
        }}
        .download-link:hover {{
            opacity: 1;
        }}
        .empty-tip {{
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
            font-size: 16px;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>🔗 文件分享</h1>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📁 {_escape_html(root_name)}</h2>
            <button class="btn btn-primary" onclick="downloadAll()">📦 下载全部</button>
        </div>

        <div class="breadcrumb">
            {breadcrumb_html}
        </div>

        <div class="file-list">
            {items_html}
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js')}
    <script>
        const shareId = '{share_id}';

        function navigateTo(path) {{
            const url = `/share/access/${{shareId}}?path=${{encodeURIComponent(path)}}`;
            window.location.href = url;
        }}

        function downloadAll() {{
            window.location.href = `/share/download/${{shareId}}`;
        }}
    </script>
</body>
</html>
"""

__all__ = ['render_share_detail_page']
