"""share template"""
import os
from typing import Optional

from .base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_share_page(username: str, file_path: str, share_id: str,
                      share_password: Optional[str], share_expires: Optional[str],
                      share_url: str, is_admin: bool = False) -> str:
    """渲染分享创建结果页面

    Args:
        username: 当前用户名
        file_path: 被分享的文件相对路径
        share_id: 分享ID
        share_password: 分享密码（可为None）
        share_expires: 过期时间字符串（可为None）
        share_url: 分享链接URL
        is_admin: 是否为管理员
    """
    file_name = os.path.basename(file_path.replace(os.sep, '/'))
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'

    password_section = f"""
        <div class="share-item">
            <div class="share-label">🔒 访问密码</div>
            <div class="share-value" id="passwordValue">{_escape_html(share_password)}</div>
        </div>""" if share_password else ""

    expires_section = f"""
        <div class="share-item">
            <div class="share-label">⏰ 过期时间</div>
            <div class="share-value">{_escape_html(share_expires)}</div>
        </div>""" if share_expires else ""

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分享链接 - {_escape_html(file_name)}</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 700px;
            margin: 0 auto;
        }}
        .share-card {{
            background: var(--bg-secondary);
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 40px;
        }}
        .share-card h2 {{
            font-size: 22px;
            color: var(--text-primary);
            margin-bottom: 30px;
            text-align: center;
        }}
        .share-item {{
            margin-bottom: 20px;
            padding: 15px 20px;
            background: var(--bg-primary);
            border-radius: 10px;
        }}
        .share-label {{
            font-size: 13px;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }}
        .share-value {{
            font-size: 16px;
            color: var(--text-primary);
            word-break: break-all;
            font-weight: 500;
        }}
        .share-url {{
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            color: #667eea;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .share-actions {{
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
            flex-wrap: wrap;
        }}
        .success-icon {{
            text-align: center;
            font-size: 60px;
            margin-bottom: 10px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>文件分享</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="share-card">
            <div class="success-icon">✅</div>
            <h2>分享创建成功</h2>

            <div class="share-item">
                <div class="share-label">📄 文件名</div>
                <div class="share-value">{_escape_html(file_name)}</div>
            </div>

            <div class="share-item">
                <div class="share-label">🔗 分享链接</div>
                <div class="share-value share-url" id="shareUrl">{_escape_html(share_url)}</div>
            </div>

            {password_section}
            {expires_section}

            <div class="share-actions">
                <button onclick="copyShareLink()" class="btn btn-primary">📋 复制链接</button>
                <a href="{parent_link}" class="btn btn-secondary">↩️ 返回文件列表</a>
            </div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        function copyShareLink() {{
            const url = document.getElementById('shareUrl').textContent;
            const passwordEl = document.getElementById('passwordValue');
            let text = url;
            if (passwordEl) {{
                text += '\\n密码: ' + passwordEl.textContent;
            }}
            copyToClipboard(text).then(() => {{
                showToast('已复制分享链接到剪贴板');
            }}).catch(err => {{
                showToast('复制失败: ' + err, 'error');
            }});
        }}

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_share_page']
