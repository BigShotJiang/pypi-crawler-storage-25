"""upload template"""

from .base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    css_links,
    js_scripts,
)

def render_upload_page(username: str, error_msg: str = "", success_msg: str = "", is_admin: bool = False) -> str:
    """渲染文件上传页面"""
    error_html = f'<div class="error">{error_msg}</div>' if error_msg else ""
    success_html = f'<div class="success" style="background:var(--success-bg);border:1px solid var(--success-border);color:#155724;padding:12px;border-radius:6px;margin-bottom:20px;font-size:14px;">{success_msg}</div>' if success_msg else ""

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>上传文件 - 文件服务器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css', 'error.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 24px;
        }}
        .upload-container {{
            max-width: 600px;
            margin: 0 auto;
            background: var(--bg-secondary);
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 40px;
        }}
        .upload-area {{
            border: 3px dashed #667eea;
            border-radius: 15px;
            padding: 60px 40px;
            text-align: center;
            background: rgba(102, 126, 234, 0.05);
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
        }}
        .upload-area:hover {{
            background: rgba(102, 126, 234, 0.1);
            border-color: #4834d4;
        }}
        .upload-area.dragover {{
            background: rgba(102, 126, 234, 0.15);
            border-color: #4834d4;
        }}
        .upload-icon {{
            font-size: 64px;
            margin-bottom: 20px;
        }}
        .upload-text {{
            color: var(--text-primary);
            font-size: 18px;
            margin-bottom: 10px;
        }}
        .upload-hint {{
            color: var(--text-secondary);
            font-size: 14px;
        }}
        .file-input {{
            display: none;
        }}
        .file-list {{
            margin-top: 20px;
        }}
        .file-item {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px;
            background: rgba(102, 126, 234, 0.05);
            border-radius: 8px;
            margin-bottom: 10px;
        }}
        .file-item .file-name {{
            color: var(--text-primary);
            font-weight: 500;
        }}
        .file-item .file-size {{
            color: var(--text-secondary);
            font-size: 13px;
            margin-left: 10px;
        }}
        .file-item .remove-btn {{
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 5px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 13px;
        }}
        .file-item .remove-btn:hover {{
            background: #ee5a5a;
        }}
        .button-group {{
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }}
        .submit-btn {{
            flex: 1;
            padding: 14px;
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }}
        .submit-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .submit-btn:disabled {{
            background: #ccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }}
        .cancel-btn {{
            flex: 1;
            padding: 14px;
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }}
        .cancel-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>上传文件</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="upload-container">
        {error_html}
        {success_html}
        <form method="POST" action="/upload" enctype="multipart/form-data" id="uploadForm">
            <div class="upload-area" id="dropZone">
                <div class="upload-icon">📁</div>
                <div class="upload-text">点击或拖拽文件到此处上传</div>
                <div class="upload-hint">支持任意类型文件</div>
                <input type="file" name="files" class="file-input" id="fileInput" multiple>
            </div>
            <div class="file-list" id="fileList"></div>
            <div class="button-group">
                <a href="/" class="cancel-btn">↩️ 返回文件列表</a>
                <button type="submit" class="submit-btn" id="submitBtn" disabled>📤 上传文件</button>
            </div>
        </form>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');
        const fileList = document.getElementById('fileList');
        const submitBtn = document.getElementById('submitBtn');
        const uploadForm = document.getElementById('uploadForm');
        let selectedFiles = [];

        dropZone.addEventListener('click', () => fileInput.click());

        dropZone.addEventListener('dragover', (e) => {{
            e.preventDefault();
            dropZone.classList.add('dragover');
        }});

        dropZone.addEventListener('dragleave', () => {{
            dropZone.classList.remove('dragover');
        }});

        dropZone.addEventListener('drop', (e) => {{
            e.preventDefault();
            dropZone.classList.remove('dragover');
            addFiles(e.dataTransfer.files);
        }});

        fileInput.addEventListener('change', (e) => {{
            addFiles(e.target.files);
        }});

        function addFiles(files) {{
            for (let file of files) {{
                if (!selectedFiles.some(f => f.name === file.name && f.size === file.size)) {{
                    selectedFiles.push(file);
                }}
            }}
            updateFileList();
        }}

        function updateFileList() {{
            fileList.innerHTML = '';
            selectedFiles.forEach((file, index) => {{
                const item = document.createElement('div');
                item.className = 'file-item';
                item.innerHTML = `
                    <span>
                        <span class="file-name">${{file.name}}</span>
                        <span class="file-size">(${{formatSize(file.size)}})</span>
                    </span>
                    <button type="button" class="remove-btn" onclick="removeFile(${{index}})">移除</button>
                `;
                fileList.appendChild(item);
            }});
            submitBtn.disabled = selectedFiles.length === 0;
        }}

        function removeFile(index) {{
            selectedFiles.splice(index, 1);
            updateFileList();
        }}

        function formatSize(bytes) {{
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
            if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
            return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
        }}

        uploadForm.addEventListener('submit', (e) => {{
            if (selectedFiles.length === 0) {{
                e.preventDefault();
                return;
            }}

            const dt = new DataTransfer();
            selectedFiles.forEach(file => dt.items.add(file));
            fileInput.files = dt.files;
        }});

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_upload_page']
