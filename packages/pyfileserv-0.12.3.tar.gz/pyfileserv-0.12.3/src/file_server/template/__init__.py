"""HTML 模板模块

提供各个页面的 HTML 渲染功能。
"""
from .admin import render_admin_page
# 从基础模块导入公共内容
from .base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    format_size,
    format_time,
    quote_path,
    css_links,
    js_scripts,
    _escape_html,
)
from .file_list import render_file_list_page
# 从各页面模块导入
from .login import render_login_page
from .preview import (
    render_image_preview_page,
    render_text_preview_page,
    render_html_preview_page,
    render_markdown_preview_page,
    render_docx_preview_page,
    render_xlsx_preview_page,
    render_pptx_preview_page,
    render_xmind_preview_page,
    render_audio_preview_page,
    render_pdf_preview_page,
    render_video_preview_page,
    render_json_preview_page,
    render_json_view_page,
)
from .share_access import render_share_access_page
from .share_create import render_share_page
from .share_detail import render_share_detail_page
from .share_management import render_share_management_page
from .trash import render_trash_page
from .upload import render_upload_page

__all__ = [
    # 基础模块内容
    'CSS_GRADIENT_PRIMARY',
    'LOGO_SVG',
    'format_size',
    'format_time',
    'quote_path',
    'css_links',
    'js_scripts',
    '_escape_html',
    # 页面渲染函数
    'render_login_page',
    'render_upload_page',
    'render_file_list_page',
    'render_image_preview_page',
    'render_text_preview_page',
    'render_html_preview_page',
    'render_markdown_preview_page',
    'render_docx_preview_page',
    'render_xlsx_preview_page',
    'render_pptx_preview_page',
    'render_xmind_preview_page',
    'render_audio_preview_page',
    'render_pdf_preview_page',
    'render_video_preview_page',
    'render_share_page',
    'render_share_access_page',
    'render_share_detail_page',
    'render_share_management_page',
    'render_trash_page',
    'render_admin_page',
    'render_json_preview_page',
    'render_json_view_page',
]
