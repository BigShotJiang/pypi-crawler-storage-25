"""pptx preview template"""
import json
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_pptx_preview_page(username: str, file_path: str, file_name: str,
                             slide_htmls: list, slide_count: int, is_admin: bool = False) -> str:
    """渲染 PowerPoint 演示文稿预览页面（iframe + srcdoc 幻灯片导航）

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        slide_htmls: 每张幻灯片的 HTML 字符串列表
        slide_count: 幻灯片总数
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'

    slides_json = json.dumps(slide_htmls)
    has_slides = len(slide_htmls) > 0

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - PowerPoint 预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 1100px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
            word-wrap: break-word;
            word-break: break-all;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .btn-nav {{
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            border: 1px solid var(--border-color);
            background: var(--bg-secondary);
            color: var(--text-primary);
        }}
        .btn-nav:hover:not(:disabled) {{
            background: #667eea;
            color: white;
            border-color: #667eea;
        }}
        .btn-nav:disabled {{
            opacity: 0.4;
            cursor: not-allowed;
        }}
        .nav-bar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 10px 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }}
        .slide-indicator {{
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            min-width: 60px;
            text-align: center;
        }}
        .slide-frame {{
            background: var(--bg-secondary);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }}
        .slide-frame iframe {{
            width: 100%;
            height: 75vh;
            border: none;
            display: block;
        }}
        .error-msg {{
            color: var(--error-text);
            background: var(--error-bg);
            border: 1px solid var(--error-border);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }}
        .unavailable-msg {{
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }}
        .unavailable-msg h2 {{
            color: var(--text-primary);
            margin-bottom: 16px;
        }}
        .unavailable-msg pre {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            display: inline-block;
            text-align: left;
            margin: 10px 0;
        }}
        [data-theme="dark"] .unavailable-msg pre {{
            background: #1e1e1e;
            color: #d4d4d4;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>PowerPoint 演示文稿预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📽️ {_escape_html(file_name)} ({slide_count} 张幻灯片)</h2>
            <a href="{download_url}" class="btn btn-secondary">⬇️ 下载</a>
        </div>

        <div class="nav-bar">
            <button class="btn-nav" id="prevBtn" onclick="prevSlide()">◀ 上一张</button>
            <span class="slide-indicator" id="slideIndicator">1 / {slide_count}</span>
            <button class="btn-nav" id="nextBtn" onclick="nextSlide()">下一张 ▶</button>
        </div>

        <div class="slide-frame">
            <iframe id="slideFrame" sandbox="allow-scripts allow-same-origin"></iframe>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        var slideData = {slides_json};
        var currentSlide = 0;
        var slideCount = {slide_count};

        function showSlide(index) {{
            if (index < 0 || index >= slideCount) return;
            currentSlide = index;
            var frame = document.getElementById('slideFrame');
            frame.srcdoc = slideData[index];
            document.getElementById('slideIndicator').textContent =
                (index + 1) + ' / ' + slideCount;
            document.getElementById('prevBtn').disabled = (index === 0);
            document.getElementById('nextBtn').disabled = (index === slideCount - 1);
        }}

        function prevSlide() {{
            if (currentSlide > 0) showSlide(currentSlide - 1);
        }}

        function nextSlide() {{
            if (currentSlide < slideCount - 1) showSlide(currentSlide + 1);
        }}

        // 初始化
        if (slideCount > 0) {{
            showSlide(0);
        }}
        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_pptx_preview_page']
