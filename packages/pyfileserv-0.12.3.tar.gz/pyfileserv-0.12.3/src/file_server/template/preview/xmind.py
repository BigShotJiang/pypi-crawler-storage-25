"""xmind preview template"""
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_xmind_preview_page(username: str, file_path: str, file_name: str,
                              content_json: str, is_admin: bool = False) -> str:
    """渲染XMind预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        content_json: XMind文件的content.json内容（或错误信息）
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'
    escaped_content = _escape_html(content_json)

    # Build line numbers for source view
    lines = content_json.split('\n')
    line_numbers = '\n'.join(str(i + 1) for i in range(len(lines)))

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - XMind预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .tab-bar {{
            background: var(--bg-secondary);
            border-radius: 10px 10px 0 0;
            padding: 0 20px;
            display: flex;
            gap: 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .tab-btn {{
            padding: 12px 25px;
            background: transparent;
            color: var(--text-secondary);
            border: none;
            border-bottom: 3px solid transparent;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }}
        .tab-btn.active {{
            color: #667eea;
            border-bottom-color: #667eea;
        }}
        .tab-btn:hover {{
            color: var(--text-primary);
        }}
        .tab-content {{
            background: var(--bg-secondary);
            border-radius: 0 0 10px 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }}
        .tab-pane {{
            display: none;
        }}
        .tab-pane.active {{
            display: block;
        }}
        .preview-pane {{
            padding: 30px;
            color: var(--text-primary);
            line-height: 1.8;
            max-height: 75vh;
            overflow-y: auto;
        }}
        .xmind-tree {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }}
        .tree-node {{
            margin-left: 20px;
            padding: 5px 0;
        }}
        .tree-root {{
            margin-left: 0;
        }}
        .tree-item {{
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            user-select: none;
        }}
        .tree-item:hover {{
            background: rgba(102, 126, 234, 0.2);
            transform: translateX(3px);
        }}
        .tree-toggle {{
            width: 20px;
            height: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-right: 8px;
            font-size: 12px;
            color: #667eea;
            cursor: pointer;
            transition: transform 0.2s;
        }}
        .tree-toggle.collapsed {{
            transform: rotate(-90deg);
        }}
        .tree-toggle.hidden {{
            visibility: hidden;
        }}
        .tree-title {{
            font-size: 14px;
            color: var(--text-primary);
            font-weight: 500;
        }}
        .tree-children {{
            margin-left: 20px;
            border-left: 2px solid rgba(102, 126, 234, 0.2);
            padding-left: 10px;
        }}
        .tree-children.collapsed {{
            display: none;
        }}
        .preview-info {{
            background: rgba(102, 126, 234, 0.1);
            border-left: 4px solid #667eea;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }}
        .preview-info h3 {{
            margin-top: 0;
            color: #667eea;
        }}
        .preview-info ul {{
            margin: 10px 0;
            padding-left: 20px;
        }}
        .preview-info li {{
            margin: 8px 0;
        }}
        .source-body {{
            display: flex;
            overflow: auto;
            max-height: 75vh;
            background: #1e1e1e;
        }}
        .line-numbers {{
            padding: 15px 12px 15px 12px;
            background: #1e1e1e;
            color: #636d83;
            text-align: right;
            user-select: none;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            border-right: 1px solid #333;
            min-width: 50px;
            white-space: pre;
        }}
        .source-content {{
            padding: 15px 20px 15px 20px;
            flex: 1;
            overflow: visible;
            background: #1e1e1e;
            color: #d4d4d4;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            white-space: pre;
            word-break: normal;
            overflow-wrap: normal;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>XMind 预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>🧠 {_escape_html(file_name)}</h2>
            <button onclick="copySource()" class="btn btn-primary">📋 复制源码</button>
            <a href="{download_url}" class="btn btn-secondary">⬇️ 下载</a>
        </div>

        <div class="tab-bar">
            <button class="tab-btn active" onclick="switchTab('preview', this)">效果</button>
            <button class="tab-btn" onclick="switchTab('source', this)">源码</button>
        </div>
        <div class="tab-content">
            <div class="tab-pane active" id="previewPane">
                <div class="preview-pane">
                   <div class="preview-toolbar">
                        <button onclick="expandAll()" class="btn btn-secondary">📂 全部展开</button>
                        <button onclick="collapseAll()" class="btn btn-secondary">📁 全部折叠</button>
                    </div>
                    <div id="xmindTreeContainer" class="xmind-tree"></div>
                </div>
            </div>
            <div class="tab-pane" id="sourcePane">
                <div class="source-body">
                    <div class="line-numbers">{line_numbers}</div>
                    <div class="source-content" id="sourceContent">{escaped_content}</div>
                </div>
            </div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        function switchTab(tabName, btnEl) {{
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            btnEl.classList.add('active');
            document.getElementById(tabName + 'Pane').classList.add('active');
        }}

        function copySource() {{
            const source = document.getElementById('sourceContent').textContent;
            copyToClipboard(source);
        }}

        // Sync scroll for source view
        document.addEventListener('DOMContentLoaded', () => {{
            const sourceBody = document.querySelector('.source-body');
            const lineNumbers = document.querySelector('.line-numbers');

            if (sourceBody && lineNumbers) {{
                sourceBody.addEventListener('scroll', () => {{
                    lineNumbers.scrollTop = sourceBody.scrollTop;
                }});
            }}

            // Render XMind tree structure
            renderXmindTree();
        }});

        function renderXmindTree() {{
            const container = document.getElementById('xmindTreeContainer');
            const sourceContent = document.getElementById('sourceContent');

            if (!container || !sourceContent) return;

            try {{
                const jsonText = sourceContent.textContent;
                const data = JSON.parse(jsonText);

                // XMind Zen format: array with root object
                let rootTopic = null;
                if (Array.isArray(data) && data.length > 0) {{
                    rootTopic = data[0].rootTopic || data[0].root;
                }} else if (data.rootTopic) {{
                    rootTopic = data.rootTopic;
                }} else if (data.root) {{
                    rootTopic = data.root;
                }}

                if (rootTopic) {{
                    const treeHtml = buildTreeNode(rootTopic, true);
                    container.innerHTML = treeHtml;
                }} else {{
                    container.innerHTML = '<div class="preview-info"><h3>⚠️ 无法解析 XMind 结构</h3><p>JSON 格式不符合预期的 XMind 结构。</p></div>';
                }}
            }} catch (e) {{
                container.innerHTML = '<div class="preview-info"><h3>⚠️ 解析错误</h3><p>无法解析 JSON 内容: ' + e.message + '</p></div>';
            }}
        }}

        function buildTreeNode(node, isRoot) {{
            if (!node) return '';

            const title = node.title || node.topic || '未命名主题';

            // XMind children structure: node.children.attached or node.children
            let children = [];
            if (node.children) {{
                if (Array.isArray(node.children)) {{
                    children = node.children;
                }} else if (node.children.attached && Array.isArray(node.children.attached)) {{
                    children = node.children.attached;
                }} else if (node.children.detached && Array.isArray(node.children.detached)) {{
                    // Also include detached children
                    children = children.concat(node.children.detached);
                }}
            }}

            const hasChildren = children.length > 0;
            const nodeClass = isRoot ? 'tree-node tree-root' : 'tree-node';

            let html = `<div class="${{nodeClass}}">`;
            html += `<div class="tree-item" onclick="toggleNode(this)">`;
            html += `<span class="tree-toggle ${{hasChildren ? '' : 'hidden'}}">▼</span>`;
            html += `<span class="tree-title">${{escapeHtml(title)}}</span>`;
            html += `</div>`;

            if (hasChildren) {{
                html += '<div class="tree-children">';
                children.forEach(child => {{
                    html += buildTreeNode(child, false);
                }});
                html += '</div>';
            }}

            html += '</div>';
            return html;
        }}

        function toggleNode(element) {{
            const children = element.nextElementSibling;
            const toggle = element.querySelector('.tree-toggle');

            if (children && children.classList.contains('tree-children')) {{
                children.classList.toggle('collapsed');
                toggle.classList.toggle('collapsed');
            }}
        }}

        function expandAll() {{
            const treeChildren = document.querySelectorAll('.tree-children');
            const toggles = document.querySelectorAll('.tree-toggle:not(.hidden)');

            treeChildren.forEach(child => {{
                child.classList.remove('collapsed');
            }});

            toggles.forEach(toggle => {{
                toggle.classList.remove('collapsed');
            }});

            showToast('已全部展开', 'info');
        }}

        function collapseAll() {{
            const treeChildren = document.querySelectorAll('.tree-children');
            const toggles = document.querySelectorAll('.tree-toggle:not(.hidden)');

            treeChildren.forEach(child => {{
                child.classList.add('collapsed');
            }});

            toggles.forEach(toggle => {{
                toggle.classList.add('collapsed');
            }});

            showToast('已全部折叠', 'info');
        }}

        function escapeHtml(text) {{
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }}

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_xmind_preview_page']
