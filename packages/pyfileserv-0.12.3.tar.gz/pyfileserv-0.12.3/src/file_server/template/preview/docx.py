"""docx preview template"""
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_docx_preview_page(username: str, file_path: str, file_name: str,
                             rendered_html: str, is_admin: bool = False) -> str:
    """渲染 Word 文档预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        rendered_html: 从 .docx 提取并转 HTML 后的内容
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - Word 预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 900px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
            word-wrap: break-word;
            word-break: break-all;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .doc-content {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 40px 50px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            color: var(--text-primary);
            line-height: 1.8;
            max-height: 75vh;
            overflow-y: auto;
        }}
        .doc-content h1 {{ font-size: 2em; margin: 24px 0 16px 0; border-bottom: 2px solid var(--border-color); padding-bottom: 8px; }}
        .doc-content h2 {{ font-size: 1.5em; margin: 20px 0 12px 0; border-bottom: 1px solid var(--border-color); padding-bottom: 6px; }}
        .doc-content h3 {{ font-size: 1.25em; margin: 16px 0 10px 0; }}
        .doc-content h4 {{ font-size: 1.1em; margin: 12px 0 8px 0; }}
        .doc-content h5 {{ font-size: 1em; margin: 10px 0 6px 0; }}
        .doc-content h6 {{ font-size: 0.9em; margin: 8px 0 4px 0; color: var(--text-secondary); }}
        .doc-content p {{ margin-bottom: 12px; }}
        .doc-content strong {{ font-weight: 700; }}
        .doc-content em {{ font-style: italic; }}
        .doc-content u {{ text-decoration: underline; }}
        .doc-content ul, .doc-content ol {{ margin: 12px 0; padding-left: 24px; }}
        .doc-content li {{ margin: 4px 0; }}
        .doc-content img {{ max-width: 100%; height: auto; border-radius: 4px; }}
        .doc-content a {{ color: #667eea; text-decoration: underline; }}
        .doc-content table {{
            border-collapse: collapse;
            width: 100%;
            margin: 16px 0;
        }}
        .doc-content th {{
            border: 1px solid var(--border-color);
            padding: 8px 12px;
            background: rgba(102, 126, 234, 0.08);
            font-weight: 700;
            text-align: left;
        }}
        .doc-content td {{
            border: 1px solid var(--border-color);
            padding: 8px 12px;
        }}
        .doc-content tr:nth-child(even) td {{
            background: rgba(102, 126, 234, 0.03);
        }}
        .error-msg {{
            color: var(--error-text);
            background: var(--error-bg);
            border: 1px solid var(--error-border);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }}
        .unavailable-msg {{
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }}
        .unavailable-msg h2 {{
            color: var(--text-primary);
            margin-bottom: 16px;
        }}
        .unavailable-msg pre {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            display: inline-block;
            text-align: left;
            margin: 10px 0;
        }}
        [data-theme="dark"] .unavailable-msg pre {{
            background: #1e1e1e;
            color: #d4d4d4;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>Word 文档预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📄 {_escape_html(file_name)}</h2>
            <a href="{download_url}" class="btn btn-secondary">⬇️ 下载</a>

        </div>

        <div class="doc-content">
            {rendered_html}
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_docx_preview_page']
