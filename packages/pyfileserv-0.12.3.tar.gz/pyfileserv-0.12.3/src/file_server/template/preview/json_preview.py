"""json preview template"""
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_json_preview_page(username: str, file_path: str, file_name: str,
                             content: str, formatted_json: str, is_admin: bool = False) -> str:
    """渲染JSON预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        content: JSON源文件内容
        formatted_json: 格式化后的JSON内容
        is_admin: 是否是管理员
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'
    escaped_content = _escape_html(content)

    # Build line numbers for source view
    lines = content.split('\n')
    line_numbers = '\n'.join(str(i + 1) for i in range(len(lines)))

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - JSON预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .tab-bar {{
            background: var(--bg-secondary);
            border-radius: 10px 10px 0 0;
            padding: 0 20px;
            display: flex;
            gap: 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .tab-btn {{
            padding: 12px 25px;
            background: transparent;
            color: var(--text-secondary);
            border: none;
            border-bottom: 3px solid transparent;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }}
        .tab-btn.active {{
            color: #667eea;
            border-bottom-color: #667eea;
        }}
        .tab-btn:hover {{
            color: var(--text-primary);
        }}
        .tab-content {{
            background: var(--bg-secondary);
            border-radius: 0 0 10px 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }}
        .tab-pane {{
            display: none;
        }}
        .tab-pane.active {{
            display: block;
        }}
        .preview-pane {{
            padding: 20px;
            color: var(--text-primary);
            max-height: 75vh;
            overflow-y: auto;
        }}
        .json-formatted {{
            background: #f8f9fa;
            color: #333;
            padding: 20px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            line-height: 1.6;
            white-space: pre-wrap;
            word-break: break-all;
        }}
        [data-theme="dark"] .json-formatted {{
            background: #1e1e1e;
            color: #d4d4d4;
        }}
        .source-body {{
            display: flex;
            overflow: auto;
            max-height: 75vh;
            background: #f8f9fa;
        }}
        [data-theme="dark"] .source-body {{
            background: #1e1e1e;
        }}
        .line-numbers {{
            padding: 15px 12px 15px 12px;
            background: #f8f9fa;
            color: #6c757d;
            text-align: right;
            user-select: none;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            border-right: 1px solid #dee2e6;
            min-width: 50px;
            white-space: pre;
        }}
        [data-theme="dark"] .line-numbers {{
            background: #1e1e1e;
            color: #636d83;
            border-right-color: #333;
        }}
        .source-content {{
            padding: 15px 20px 15px 20px;
            flex: 1;
            overflow: visible;
            background: #f8f9fa;
            color: #333;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            white-space: pre;
            word-break: normal;
            overflow-wrap: normal;
        }}
        [data-theme="dark"] .source-content {{
            background: #1e1e1e;
            color: #d4d4d4;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>JSON 预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📄 {_escape_html(file_name)}</h2>
            <button onclick="copySource()" class="btn btn-primary">📋 复制源码</button>
            <a href="{download_url}" class="btn btn-secondary">⬇️ 下载</a>

        </div>

        <div class="tab-bar">
            <button class="tab-btn active" onclick="switchTab('preview', this)">效果</button>
            <button class="tab-btn" onclick="switchTab('source', this)">源码</button>
        </div>
        <div class="tab-content">
            <div class="tab-pane active" id="previewPane">
                <div class="preview-pane">
                    <div class="json-formatted">{_escape_html(formatted_json)}</div>
                </div>
            </div>
            <div class="tab-pane" id="sourcePane">
                <div class="source-body">
                    <div class="line-numbers">{line_numbers}</div>
                    <div class="source-content" id="sourceContent">{escaped_content}</div>
                </div>
            </div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        function switchTab(tabName, btnEl) {{
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            btnEl.classList.add('active');
            document.getElementById(tabName + 'Pane').classList.add('active');
        }}

        function copySource() {{
            const source = document.getElementById('sourceContent').textContent;
            copyToClipboard(source);
        }}

        // Sync scroll for source view
        document.addEventListener('DOMContentLoaded', () => {{
            const sourceBody = document.querySelector('.source-body');
            const lineNumbers = document.querySelector('.line-numbers');

            if (sourceBody && lineNumbers) {{
                sourceBody.addEventListener('scroll', () => {{
                    lineNumbers.scrollTop = sourceBody.scrollTop;
                }});
            }}
        }});

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_json_preview_page']
