"""pdf preview template"""
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_pdf_preview_page(username: str, file_path: str, file_name: str, is_admin: bool = False) -> str:
    """渲染 PDF 预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    # 直接使用文件路径，让服务器自动设置正确的 Content-Type
    pdf_url = f'/{quote_path(file_path, leading_slash=False)}'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - PDF 预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 100%;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
            word-wrap: break-word;
            word-break: break-all;
            overflow-wrap: break-word;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .pdf-container {{
            background: var(--bg-secondary);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            height: calc(100vh - 200px);
            min-height: 600px;
            border: 2px solid var(--border-color);
            transition: border-color 0.3s;
        }}
        .pdf-viewer {{
            width: 100%;
            height: 100%;
            border: none;
        }}
        .pdf-fallback {{
            padding: 40px;
            text-align: center;
            color: var(--text-secondary);
        }}
        .pdf-fallback a {{
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }}
        .pdf-fallback a:hover {{
            text-decoration: underline;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>PDF 预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📄 {_escape_html(file_name)}</h2>
            <a href="{download_url}" class="btn btn-primary" download>⬇️ 下载</a>

        </div>

        <div class="pdf-container">
            <object data="{pdf_url}#toolbar=1&navpanes=1" type="application/pdf" class="pdf-viewer">
                <div class="pdf-fallback">
                    <p>您的浏览器不支持内嵌 PDF 预览。</p>
                    <p><a href="{pdf_url}" target="_blank">点击此处在新窗口中打开 PDF</a></p>
                    <p>或者 <a href="{download_url}" download>下载 PDF 文件</a></p>
                </div>
            </object>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_pdf_preview_page']
