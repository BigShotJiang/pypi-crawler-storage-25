"""text preview template"""
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_text_preview_page(username: str, file_path: str, file_name: str,
                             content: str, language: str, is_admin: bool = False) -> str:
    """渲染文本/代码预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        content: 文件内容
        language: 代码语言（从扩展名检测）
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'

    # Build line numbers
    lines = content.split('\n')
    line_numbers = '\n'.join(str(i + 1) for i in range(len(lines)))

    # HTML 转义以防止 XSS，浏览器会将实体转换回原始字符供 highlight.js 处理
    escaped_content = _escape_html(content)

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - 代码预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .code-container {{
            background: var(--bg-secondary);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            border: 1px solid var(--border-color);
        }}
        .code-header {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            padding: 10px 20px;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .code-body {{
            display: flex;
            overflow: auto;
            max-height: 75vh;
            background: #f8f9fa;
        }}
        [data-theme="dark"] .code-body {{
            background: #282c34;
        }}
        .line-numbers {{
            padding: 15px 12px 15px 12px;
            background: #f8f9fa;
            color: #6c757d;
            text-align: right;
            user-select: none;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            border-right: 1px solid #dee2e6;
            min-width: 50px;
            white-space: pre;
        }}
        [data-theme="dark"] .line-numbers {{
            background: #282c34;
            color: #636d83;
            border-right-color: #3a3f4b;
        }}
        .code-content {{
            padding: 15px 20px 15px 20px;
            flex: 1;
            overflow: visible;
            background: #f8f9fa;
        }}
        [data-theme="dark"] .code-content {{
            background: #282c34;
        }}
        .code-content pre {{
            margin: 0;
            padding: 0;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            white-space: pre;
            overflow: visible;
            background: transparent;
        }}
        .code-content code {{
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.6;
            display: block;
            white-space: pre;
            overflow: visible;
            background: transparent;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>代码预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📝 {_escape_html(file_name)}</h2>
            <button onclick="copyCode()" class="btn btn-primary">📋 复制</button>
            <a href="{download_url}" class="btn btn-secondary">⬇️ 下载</a>

        </div>

        <div class="code-container">
            <div class="code-header">
                <span>{_escape_html(language) if language else 'text'}</span>
                <span>{len(lines)} 行</span>
            </div>
            <div class="code-body">
                <div class="line-numbers">{line_numbers}</div>
                <div class="code-content">
                    <pre><code id="codeBlock" class="language-{_escape_html(language) if language else 'text'}">{escaped_content}</code></pre>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
    {js_scripts('theme.js', 'toast.js', 'usermenu.js', 'clipboard.js')}
    <script>
        // Highlight.js init
        document.addEventListener('DOMContentLoaded', () => {{
            hljs.highlightAll();

            // Sync scroll between line numbers and code content
            const codeBody = document.querySelector('.code-body');
            const lineNumbers = document.querySelector('.line-numbers');

            if (codeBody && lineNumbers) {{
                codeBody.addEventListener('scroll', () => {{
                    lineNumbers.scrollTop = codeBody.scrollTop;
                }});
            }}
        }});

        function copyCode() {{
            const code = document.getElementById('codeBlock').textContent;
            copyToClipboard(code);
        }}

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_text_preview_page']
