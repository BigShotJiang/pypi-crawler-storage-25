"""image preview template"""
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_image_preview_page(username: str, file_path: str, file_name: str,
                              image_urls: list, current_index: int, is_admin: bool = False) -> str:
    """渲染图片预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        image_urls: 同目录下所有图片的路径列表
        current_index: 当前图片在列表中的索引
    """
    total = len(image_urls)
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    # 使用 /download/ 路由获取原始图片数据，而不是 /preview/ （后者返回HTML页面）
    image_url = f'/download/{quote_path(file_path, leading_slash=False)}'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'

    # Build navigation URLs as JS array - 使用 /download/ 路由
    image_urls_json = ','.join(f'"/download/{quote_path(p, leading_slash=False)}"' for p in image_urls)

    # Build image names array for display
    image_names_json = ','.join(f'"{_escape_html(os.path.basename(p.replace(os.sep, "/")))}"' for p in image_urls)

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - 图片预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .image-viewer {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            flex-direction: column;
            align-items: center;
        }}
        .image-wrapper {{
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            min-height: 400px;
            max-height: 75vh;
        }}
        .image-wrapper img {{
            max-width: 100%;
            max-height: 75vh;
            object-fit: contain;
            border-radius: 8px;
        }}
        .nav-arrow {{
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            padding: 15px 12px;
            border-radius: 50%;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 10;
        }}
        .nav-arrow:hover {{
            background: rgba(0, 0, 0, 0.7);
        }}
        .nav-arrow.prev {{
            left: 10px;
        }}
        .nav-arrow.next {{
            right: 10px;
        }}
        .nav-arrow:disabled {{
            opacity: 0.3;
            cursor: not-allowed;
        }}
        .image-counter {{
            text-align: center;
            color: var(--text-secondary);
            font-size: 14px;
            margin-top: 15px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>图片预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2 id="imageTitle">🖼️ {_escape_html(file_name)}</h2>
            <a href="{download_url}" class="btn btn-primary" id="downloadBtn" download>⬇️ 下载</a>

        </div>

        <div class="image-viewer">
            <div class="image-wrapper">
                <button class="nav-arrow prev" id="prevBtn" onclick="navigateImage(-1)">◀</button>
                <img id="previewImg" src="{image_url}" alt="{_escape_html(file_name)}">
                <button class="nav-arrow next" id="nextBtn" onclick="navigateImage(1)">▶</button>
            </div>
            <div class="image-counter" id="imageCounter">{current_index + 1} / {total}</div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        const imageUrls = [{image_urls_json}];
        const imageNames = [{image_names_json}];
        let currentIndex = {current_index};

        function navigateImage(direction) {{
            currentIndex += direction;
            if (currentIndex < 0 || currentIndex >= imageUrls.length) {{
                currentIndex -= direction;
                return;
            }}
            // Update image source
            document.getElementById('previewImg').src = imageUrls[currentIndex];
            // Update image title
            document.getElementById('imageTitle').textContent = '🖼️ ' + imageNames[currentIndex];
            // Update counter
            document.getElementById('imageCounter').textContent = (currentIndex + 1) + ' / ' + imageUrls.length;
            // Update download link
            document.getElementById('downloadBtn').href = imageUrls[currentIndex];
            updateNavButtons();
        }}

        function updateNavButtons() {{
            document.getElementById('prevBtn').disabled = currentIndex === 0;
            document.getElementById('nextBtn').disabled = currentIndex === imageUrls.length - 1;
        }}

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {{
            if (e.key === 'ArrowLeft') navigateImage(-1);
            if (e.key === 'ArrowRight') navigateImage(1);
        }});

        initTheme();
        updateNavButtons();
    </script>
</body>
</html>
"""

__all__ = ['render_image_preview_page']
