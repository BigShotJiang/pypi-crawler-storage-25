"""xlsx preview template"""
import os

from ..base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    _escape_html,
    css_links,
    js_scripts,
)


def render_xlsx_preview_page(username: str, file_path: str, file_name: str,
                             rendered_html: str, sheet_names: list, is_admin: bool = False) -> str:
    """渲染 Excel 表格预览页面

    Args:
        username: 当前用户名
        file_path: 文件相对路径
        file_name: 文件名
        rendered_html: 从 .xlsx 提取的 HTML 表格内容
        sheet_names: 工作表名称列表
    """
    parent_path = '/'.join(file_path.replace(os.sep, '/').split('/')[:-1])
    parent_link = quote_path(parent_path, leading_slash=True) if parent_path else '/'
    download_url = f'/download/{quote_path(file_path, leading_slash=False)}'

    # 生成工作表标签
    tabs_html = ''
    for i, name in enumerate(sheet_names):
        active_class = 'active' if i == 0 else ''
        tabs_html += f'<button class="tab-btn {active_class}" onclick="switchSheet({i}, this)">{_escape_html(name)}</button>\n'

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - Excel 预览</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 100%;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
            word-wrap: break-word;
            word-break: break-all;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .tab-bar {{
            background: var(--bg-secondary);
            border-radius: 10px 10px 0 0;
            padding: 0 20px;
            display: flex;
            gap: 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow-x: auto;
        }}
        .tab-btn {{
            padding: 12px 25px;
            background: transparent;
            color: var(--text-secondary);
            border: none;
            border-bottom: 3px solid transparent;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            white-space: nowrap;
        }}
        .tab-btn.active {{
            color: #667eea;
            border-bottom-color: #667eea;
        }}
        .tab-btn:hover {{
            color: var(--text-primary);
        }}
        .sheet-content {{
            background: #ffffff;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            color: #333333;
        }}
        .sheet-pane {{
            display: none;
        }}
        .sheet-pane.active {{
            display: block;
        }}
        .sheet-title {{
            margin: 0;
            padding: 15px 20px;
            font-size: 16px;
            color: #333333;
            background: rgba(102, 126, 234, 0.05);
            border-bottom: 1px solid #e0e0e0;
        }}
        .table-wrapper {{
            overflow-x: auto;
            max-height: 65vh;
            overflow-y: auto;
        }}
        .table-wrapper table {{
            border-collapse: collapse;
            width: 100%;
            font-size: 13px;
        }}
        .table-wrapper table td, .table-wrapper table th {{
            border: 1px solid #e0e0e0;
            padding: 6px 12px;
            color: #333333;
            white-space: nowrap;
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .table-wrapper table td:hover {{
            background: 7eb252 !important;
        }}
        .error-msg {{
            color: var(--error-text);
            background: var(--error-bg);
            border: 1px solid var(--error-border);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }}
        .unavailable-msg {{
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }}
        .unavailable-msg h2 {{
            color: var(--text-primary);
            margin-bottom: 16px;
        }}
        .unavailable-msg pre {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            display: inline-block;
            text-align: left;
            margin: 10px 0;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>Excel 表格预览</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <div class="container">
        <div class="toolbar">
            <h2>📊 {_escape_html(file_name)}</h2>
            <a href="{download_url}" class="btn btn-secondary">⬇️ 下载</a>

        </div>

        <div class="tab-bar" id="sheetTabs">
            {tabs_html}
        </div>
        <div class="sheet-content">
            {rendered_html}
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        function switchSheet(index, btnEl) {{
            document.querySelectorAll('#sheetTabs .tab-btn').forEach(b => b.classList.remove('active'));
            btnEl.classList.add('active');
            document.querySelectorAll('.sheet-pane').forEach(p => p.classList.remove('active'));
            const target = document.getElementById('sheet-' + index);
            if (target) target.classList.add('active');
        }}

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_xlsx_preview_page']
