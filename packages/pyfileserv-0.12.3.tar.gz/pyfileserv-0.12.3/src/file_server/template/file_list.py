"""file_list template"""
import os
from datetime import datetime
from typing import Tuple, List

from .base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    quote_path,
    format_size,
    format_time,
    _escape_html,
    css_links,
    js_scripts,
)

# 文件类型显示名称映射
_TYPE_LABELS = {
    'image': '图片',
    'audio': '音频',
    'video': '视频',
    'pdf': 'PDF',
    'text': '文本/代码',
    'markdown': 'Markdown',
    'xmind': 'XMind',
    'json': 'JSON',
    'docx': 'Word',
    'xlsx': 'Excel',
    'pptx': 'PowerPoint',
    'other': '其他',
}

def render_file_list_page(username: str, files_by_type: dict,
        directories: List[Tuple[str, float]], current_path: str, sort_by: str = "name",
        search_query: str = "", file_type_filter: str = "", is_admin: bool = False) -> str:
    """渲染文件列表页面

    Args:
        username: 当前用户名
        files_by_type: 按类型分组的文件 {type: [(名称, 大小, 修改时间), ...]}
        directories: 目录列表 [(目录名, 修改时间), ...]
        current_path: 当前相对路径
        sort_by: 排序方式 (name, size, time)
        search_query: 搜索关键词
        file_type_filter: 文件类型筛选
        is_admin: 是否为管理员
    """
    # 合并所有文件和目录为一个列表
    all_items = []

    # 添加目录（标记为 directory 类型）
    for dirname, mtime in directories:
        all_items.append((dirname, None, mtime, 'directory'))

    # 添加文件（标记具体类型）
    for ftype, file_list in files_by_type.items():
        for filename, size, mtime in file_list:
            all_items.append((filename, size, mtime, ftype))

    # 根据文件类型筛选（目录不参与类型筛选：搜索时不显示不符合类型的目录）
    if file_type_filter and file_type_filter != 'all':
        all_items = [item for item in all_items if item[3] == file_type_filter]

    # 排序：目录始终排在前面，然后按指定方式排序
    def sort_key(item):
        name, size, mtime, item_type = item
        # 目录优先
        type_priority = 0 if item_type == 'directory' else 1

        if sort_by == "size":
            # 目录没有大小，排在前面的用 0
            size_val = size if size is not None else 0
            return (type_priority, -size_val, name.lower())
        elif sort_by == "time":
            return (type_priority, -mtime, name.lower())
        else:  # name
            return (type_priority, name.lower())

    all_items_sorted = sorted(all_items, key=sort_key)

    # 生成目录面包屑导航
    breadcrumb_items = []
    # 统一使用 / 作为分隔符（current_path 已经从后端转换为正斜杠格式）
    path_parts = [] if current_path == '.' or current_path == '' else current_path.split('/')
    current_breadcrumb_path = ''

    # 添加根目录
    breadcrumb_items.append('<a href="/" class="breadcrumb-link">根目录</a>')

    for i, part in enumerate(path_parts):
        if part:
            current_breadcrumb_path += '/' + part
            if i == len(path_parts) - 1:
                breadcrumb_items.append(f'<span class="breadcrumb-current">{part}</span>')
            else:
                quoted_path = quote_path(current_breadcrumb_path, leading_slash=True)
                breadcrumb_items.append(f'<a href="{quoted_path}" class="breadcrumb-link">{part}</a>')

    breadcrumb_html = ' / '.join(breadcrumb_items)

    # 生成文件项的辅助函数
    def generate_file_item(name: str, size: int, mtime: float, file_type: str, path_rel: str, link: str, info_extra: str = "") -> str:
        full_path = f"{current_path}/{name}" if current_path else name
        full_path_quoted = quote_path(full_path, leading_slash=False)
        size_str = format_size(size) if size is not None else ""
        time_str = format_time(mtime)
        info_parts = [p for p in [size_str, time_str, info_extra] if p]
        info = ' | '.join(info_parts)

        # 检测文件扩展名以确定是否可预览
        ext = os.path.splitext(name.lower())[1]
        previewable_exts = {
            # 图片
            '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg', '.ico',
            # 音频
            '.mp3', '.wav', '.ogg', '.flac', '.aac', '.m4a', '.wma',
            # 视频
            '.mp4', '.webm', '.avi', '.mov', '.mkv',
            # PDF
            '.pdf',
            # 文本/代码
            '.txt', '.log', '.cfg', '.ini', '.conf', '.yaml', '.yml', '.toml',
            '.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.c', '.cpp', '.h', '.hpp',
            '.cs', '.go', '.rs', '.rb', '.php', '.swift', '.kt', '.scala',
            '.html', '.htm', '.css', '.scss', '.less', '.xml', '.sql',
            '.sh', '.bash', '.zsh', '.bat', '.ps1',
            '.dockerfile', '.makefile', '.cmake',
            '.r', '.R', '.m', '.pl', '.lua',
            # Markdown
            '.md', '.markdown',
            # XMind
            '.xmind',
            # JSON
            '.json',
            # Office
            '.docx', '.xlsx', '.pptx',
        }

        # 判断是否为可预览文件
        is_previewable = ext in previewable_exts

        # 如果是可预览文件，使用预览链接；否则使用原有链接
        file_link = f'/preview/{full_path_quoted}' if is_previewable else link

        # 根据是否可预览决定按钮文本
        action_text = '点击查看' if is_previewable else '点击下载'

        return f"""
                    <li class="file-item" data-file-type="{file_type}" data-name="{name.lower()}" data-size="{size or 0}" data-type="file" data-path="{_escape_html(full_path)}">
                        <div class="file-checkbox">
                            <input type="checkbox" class="file-select" data-path="{_escape_html(full_path)}" onchange="updateSelection()">
                        </div>
                        <div class="file-main">
                            <a href="{file_link}" class="file-link" target="_blank">{_escape_html(name)}</a>
                            <span class="file-info">{_escape_html(info)}</span>
                        </div>
                        <div class="file-actions">
                            <button class="action-btn" onclick="showShareModal('{_escape_html(full_path)}')" title="分享">🔗</button>
                            <button class="action-btn" onclick="showRenameModal('{_escape_html(full_path)}', '{_escape_html(name)}')" title="重命名">✏️</button>
                            <button class="action-btn" onclick="showMoveModal('{_escape_html(full_path)}')" title="移动">📤</button>
                            <button class="action-btn" onclick="copyItem('{_escape_html(full_path)}')" title="复制">📋</button>
                            <button class="action-btn danger" onclick="showDeleteModal('{_escape_html(full_path)}', '{_escape_html(name)}')" title="删除">🗑️</button>
                        </div>
                    </li>
        """

    # 生成统一的项目列表（目录 + 文件）
    items_html = ""
    for name, size, mtime, item_type in all_items_sorted:
        if item_type == 'directory':
            # 生成目录项
            dir_url = current_path + '/' + name if current_path else name
            quoted_dir_url = quote_path(dir_url, leading_slash=True)
            full_path = f"{current_path}/{name}" if current_path else name
            full_path_quoted = quote_path(full_path, leading_slash=False)
            items_html += f"""
                    <li class="file-item directory" data-name="{name.lower()}" data-type="directory" data-path="{_escape_html(full_path)}">
                        <div class="file-checkbox">
                            <input type="checkbox" class="file-select" data-path="{_escape_html(full_path)}" onchange="updateSelection()">
                        </div>
                        <div class="file-main">
                            <a href="{quoted_dir_url}" class="file-link" target="_blank">📁 {_escape_html(name)}</a>
                            <span class="file-info">{format_time(mtime)}</span>
                        </div>
                        <div class="file-actions">
                            <button class="action-btn" onclick="showShareModal('{_escape_html(full_path)}')" title="分享">🔗</button>
                            <button class="action-btn" onclick="showRenameModal('{_escape_html(full_path)}', '{_escape_html(name)}')" title="重命名">✏️</button>
                            <button class="action-btn" onclick="showMoveModal('{_escape_html(full_path)}')" title="移动">📤</button>
                            <button class="action-btn" onclick="copyItem('{_escape_html(full_path)}')" title="复制">📋</button>
                            <button class="action-btn danger" onclick="showDeleteModal('{_escape_html(full_path)}', '{_escape_html(name)}')" title="删除">🗑️</button>
                        </div>
                    </li>
            """
        else:
            # 生成文件项（generate_file_item 内部根据扩展名决定预览/下载链接）
            download_path = current_path + '/' + name if current_path else name
            quoted_download_path = quote_path(download_path, leading_slash=False)
            items_html += generate_file_item(name, size, mtime, item_type, current_path, f'/download/{quoted_download_path}')

    if not all_items_sorted:
        items_html = '<li class="file-item">暂无内容</li>'

    # 统计文件数量（基于 all_items，确保筛选后数据一致）
    filtered_dir_count = len([item for item in all_items if item[3] == 'directory'])
    total_files = len([item for item in all_items if item[3] != 'directory'])
    total_size = sum(s for _, s, _, item_type in all_items if item_type != 'directory' and s is not None)

    # 生成类型筛选下拉选项
    type_filter_options = '\n'.join(
        f'                        <option value="{ftype}" {"selected" if file_type_filter == ftype else ""}>{_TYPE_LABELS.get(ftype, ftype)}</option>'
        for ftype in sorted(files_by_type.keys(), key=lambda t: _TYPE_LABELS.get(t, t))
    )

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>文件列表</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'modal.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            padding: 20px;
        }}
        .toolbar {{
            max-width: 1200px;
            margin: 0 auto 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }}
        .toolbar-row {{
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }}
        .toolbar-search {{
            background: var(--bg-secondary);
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .toolbar-actions {{
            justify-content: flex-end;
        }}
        .search-box {{
            flex: 1;
            min-width: 250px;
            position: relative;
        }}
        .search-box input {{
            width: 100%;
            padding: 12px 15px 12px 40px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            background: var(--bg-secondary);
            color: var(--text-primary);
            transition: border-color 0.3s;
        }}
        .search-box input:focus {{
            outline: none;
            border-color: #667eea;
        }}
        .search-box::before {{
            content: "🔍";
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 14px;
        }}
        .sort-controls {{
            display: flex;
            gap: 10px;
            align-items: center;
        }}
        .sort-controls label {{
            color: var(--text-secondary);
            font-size: 14px;
        }}
        .sort-controls select {{
            padding: 10px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            background: var(--bg-secondary);
            color: var(--text-primary);
        }}
        .sort-controls select:focus {{
            outline: none;
            border-color: #667eea;
        }}
        .filter-group {{
            display: flex;
            gap: 10px;
            align-items: center;
        }}
        .action-buttons {{
            display: flex;
            gap: 10px;
        }}
        .quick-actions {{
            display: flex;
            gap: 10px;
        }}
        .quick-btn {{
            padding: 10px 18px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            display: flex;
            align-items: center;
            gap: 6px;
        }}
        .quick-btn.primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .quick-btn.share {{
            background: var(--btn-share);
            color: white;
        }}
        .quick-btn.trash {{
            background: var(--btn-trash);
            color: white;
        }}
        .quick-btn.create {{
            background: var(--btn-create);
            color: white;
        }}
        .quick-btn.upload {{
            background: var(--btn-upload);
            color: white;
        }}
        .quick-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }}
        .selection-bar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: none;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }}
        .selection-bar.show {{
            display: flex;
        }}
        .selection-info {{
            color: var(--text-primary);
            font-weight: 500;
        }}
        .selection-actions {{
            display: flex;
            gap: 10px;
        }}
        .file-checkbox {{
            flex-shrink: 0;
            width: 24px;
            display: flex;
            align-items: center;
        }}
        .file-select {{
            width: 18px;
            height: 18px;
            cursor: pointer;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .file-list {{
            list-style: none;
        }}
        .file-item {{
            margin: 10px 0;
            padding: 15px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background: var(--bg-primary);
            transition: all 0.3s;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
        }}
        .file-item:hover {{
            background: rgba(102, 126, 234, 0.05);
            border-color: #667eea;
            transform: translateX(5px);
        }}
        .file-main {{
            display: flex;
            flex-direction: column;
            gap: 5px;
            flex: 1;
            min-width: 0;
        }}
        .file-item[data-file-type] {{
            background: rgba(102, 126, 234, 0.05);
            border-color: rgba(102, 126, 234, 0.2);
        }}
        .file-item[data-file-type]:hover {{
            background: rgba(102, 126, 234, 0.1);
        }}
        .file-item.hidden {{
            display: none;
        }}
        .file-item {{
            color: var(--text-primary);
        }}
        .file-link {{
            text-decoration: none;
            color: #667eea;
            font-weight: 600;
            font-size: 16px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}
        .file-link:hover {{
            color: #4834d4;
        }}
        .file-info {{
            color: var(--text-secondary);
            font-size: 13px;
        }}
        .file-item.directory {{
            background: rgba(102, 126, 234, 0.08);
            border-color: rgba(102, 126, 234, 0.2);
        }}
        .file-item.directory:hover {{
            background: rgba(102, 126, 234, 0.12);
        }}
        .file-actions {{
            display: flex;
            gap: 5px;
            flex-shrink: 0;
        }}
        .action-btn {{
            padding: 6px 10px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s;
            background: rgba(102, 126, 234, 0.1);
        }}
        .action-btn:hover {{
            background: rgba(102, 126, 234, 0.2);
            transform: scale(1.1);
        }}
        .action-btn.danger {{
            background: rgba(255, 65, 108, 0.1);
        }}
        .action-btn.danger:hover {{
            background: rgba(255, 65, 108, 0.2);
        }}
        .breadcrumb {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
        }}
        .breadcrumb-link {{
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }}
        .breadcrumb-link:hover {{
            color: #4834d4;
            text-decoration: underline;
        }}
        .breadcrumb-current {{
            color: var(--text-primary);
            font-weight: 600;
        }}
        .path-info {{
            color: var(--text-secondary);
            font-size: 14px;
            margin-top: 20px;
            padding: 15px;
            background: var(--bg-primary);
            border-radius: 8px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
        }}
        .path-info div {{
            display: flex;
            gap: 5px;
        }}
        .no-results {{
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
            display: none;
        }}
        .form-group {{
            margin-bottom: 15px;
        }}
        .form-group label {{
            display: block;
            margin-bottom: 8px;
            color: var(--text-primary);
            font-weight: 500;
            font-size: 14px;
        }}
        .form-group select {{
            width: 100%;
            padding: 12px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            background: var(--bg-secondary);
            color: var(--text-primary);
        }}
        .form-group select:focus {{
            outline: none;
            border-color: #667eea;
        }}
        .form-group input {{
            width: 100%;
            padding: 12px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            background: var(--bg-secondary);
            color: var(--text-primary);
            transition: border-color 0.3s;
        }}
        .form-group input:focus {{
            outline: none;
            border-color: #667eea;
        }}
        @media (max-width: 768px) {{
            .toolbar-search {{
                flex-direction: column;
            }}

            .search-box {{
                width: 100%;
                min-width: unset;
            }}

            .filter-group {{
                width: 100%;
                justify-content: space-between;
            }}

            .toolbar-actions {{
                justify-content: stretch;
            }}

            .action-buttons {{
                width: 100%;
                justify-content: space-between;
            }}

            .quick-btn {{
                flex: 1;
                justify-content: center;
                font-size: 13px;
                padding: 10px 12px;
            }}

            .file-item {{
                flex-direction: column;
                align-items: stretch;
            }}
            .file-actions {{
                justify-content: flex-end;
            }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="40" height="40"')}</div>
            <h1>文件列表</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <!-- 多选操作栏 -->
    <div class="selection-bar" id="selectionBar">
        <div class="selection-info">
            已选择 <span id="selectedCount">0</span> 项
        </div>
        <div class="selection-actions">
            <button class="quick-btn primary" onclick="downloadZip()">📦 ZIP下载</button>
            <button class="quick-btn" onclick="clearSelection()">✖️ 取消选择</button>
        </div>
    </div>

    <div class="toolbar">
        <!-- 第一行：搜索和筛选 -->
        <div class="toolbar-row toolbar-search">
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="搜索文件..." value="{_escape_html(search_query)}">
            </div>
            <div class="filter-group">
                <div class="sort-controls">
                    <label for="typeFilter">类型:</label>
                    <select id="typeFilter" onchange="filterByType(this.value)">
                        <option value="all" {"selected" if file_type_filter == "all" or not file_type_filter else ""}>全部</option>
{type_filter_options}
                    </select>
                </div>
                <div class="sort-controls">
                    <label for="sortSelect">排序:</label>
                    <select id="sortSelect" onchange="changeSort(this.value)">
                        <option value="name" {"selected" if sort_by == "name" else ""}>按名称</option>
                        <option value="size" {"selected" if sort_by == "size" else ""}>按大小</option>
                        <option value="time" {"selected" if sort_by == "time" else ""}>按时间</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- 第二行：快捷操作 -->
        <div class="toolbar-row toolbar-actions">
            <div class="action-buttons">
                <a href="/shares" class="quick-btn share">🔗 分享管理</a>
                <a href="/trash" class="quick-btn trash">🗑️ 回收站</a>
                <a href="#" class="quick-btn create" onclick="showMkdirModal();return false;">📁 创建目录</a>
                <a href="/upload" class="quick-btn upload">📤 上传文件</a>
            </div>
        </div>
    </div>

    <div class="breadcrumb">
        {breadcrumb_html}
    </div>
    <div class="container">
        <div class="section">
            <ul class="file-list" id="itemList">
                {items_html}
            </ul>
        </div>

        <div class="no-results" id="noResults">
            未找到匹配的内容
        </div>

        <div class="path-info">
            <div><strong>服务器时间:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
            <div><strong>目录数:</strong> {filtered_dir_count} 个目录</div>
            <div><strong>文件数:</strong> {total_files} 个文件</div>
            <div><strong>总大小:</strong> {format_size(total_size)}</div>
        </div>
    </div>

    <!-- 删除确认模态框 -->
    <div class="modal-overlay" id="deleteModal">
        <div class="modal">
            <h3 class="modal-title">确认删除</h3>
            <p class="modal-content">确定要删除 "<span id="deleteItemName"></span>" 吗？此操作不可撤销。</p>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeModal('deleteModal')">取消</button>
                <button class="modal-btn danger" onclick="confirmDelete()">删除</button>
            </div>
        </div>
    </div>

    <!-- 重命名模态框 -->
    <div class="modal-overlay" id="renameModal">
        <div class="modal">
            <h3 class="modal-title">重命名</h3>
            <div class="form-group">
                <label for="newName">新名称:</label>
                <input type="text" id="newName" placeholder="输入新名称">
            </div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeModal('renameModal')">取消</button>
                <button class="modal-btn primary" onclick="confirmRename()">确定</button>
            </div>
        </div>
    </div>

    <!-- 移动模态框 -->
    <div class="modal-overlay" id="moveModal">
        <div class="modal">
            <h3 class="modal-title">移动到</h3>
            <div class="form-group">
                <label for="targetDir">目标目录:</label>
                <select id="targetDir"></select>
            </div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeModal('moveModal')">取消</button>
                <button class="modal-btn primary" onclick="confirmMove()">确定</button>
            </div>
        </div>
    </div>

    <!-- 创建目录模态框 -->
    <div class="modal-overlay" id="mkdirModal">
        <div class="modal">
            <h3 class="modal-title">创建目录</h3>
            <div class="form-group">
                <label for="dirName">目录名称:</label>
                <input type="text" id="dirName" placeholder="输入目录名称">
            </div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeModal('mkdirModal')">取消</button>
                <button class="modal-btn primary" onclick="confirmMkdir()">创建</button>
            </div>
        </div>
    </div>

    <!-- 分享模态框 -->
    <div class="modal-overlay" id="shareModal">
        <div class="modal" style="max-width:500px;">
            <h3 class="modal-title">🔗 创建分享链接</h3>
            <p style="color:var(--text-secondary);margin-bottom:15px;font-size:14px;">文件: <span id="shareFileName"></span></p>
            <div class="form-group">
                <label for="sharePassword">访问密码 (可选):</label>
                <input type="text" id="sharePassword" placeholder="留空则无需密码">
            </div>
            <div class="form-group">
                <label for="shareExpires">过期时间 (小时, 可选):</label>
                <input type="number" id="shareExpires" placeholder="留空则永不过期" min="1">
            </div>
            <div class="form-group">
                <label for="shareMaxDownloads">最大下载次数 (可选):</label>
                <input type="number" id="shareMaxDownloads" placeholder="留空则不限制" min="1">
            </div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeModal('shareModal')">取消</button>
                <button class="modal-btn primary" onclick="confirmShare()">创建分享</button>
            </div>
        </div>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js', 'modal.js')}
    <script>
        const searchInput = document.getElementById('searchInput');
        const itemList = document.getElementById('itemList');
        const noResults = document.getElementById('noResults');
        const itemCount = document.getElementById('itemCount');

        let currentPath = '{_escape_html(current_path if current_path != "." else "")}';
        let deletePath = '';
        let renamePath = '';
        let movePath = '';
        let directories = [];
        const dirList = directories;
        const dirCount = {len(directories)};

        // 删除操作
        function showDeleteModal(path, name) {{
            deletePath = path;
            document.getElementById('deleteItemName').textContent = name;
            showModal('deleteModal');
        }}

        async function confirmDelete() {{
            try {{
                const response = await fetch(`/api/delete/${{encodeURIComponent(deletePath)}}`, {{ method: 'POST' }});
                const data = await response.json();
                if (data.success) {{
                    showToast('删除成功');
                    closeModal('deleteModal');
                    setTimeout(() => location.reload(), 500);
                }} else {{
                    showToast(data.error || '删除失败', 'error');
                }}
            }} catch (e) {{
                showToast('删除失败: ' + e.message, 'error');
            }}
        }}

        // 重命名操作
        function showRenameModal(path, name) {{
            renamePath = path;
            document.getElementById('newName').value = name;
            showModal('renameModal');
            setTimeout(() => document.getElementById('newName').focus(), 100);
        }}

        async function confirmRename() {{
            const newName = document.getElementById('newName').value.trim();
            if (!newName) {{
                showToast('请输入新名称', 'warning');
                return;
            }}

            try {{
                const response = await fetch('/api/rename', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ old_path: renamePath, new_name: newName }})
                }});
                const data = await response.json();
                if (data.success) {{
                    showToast('重命名成功');
                    closeModal('renameModal');
                    setTimeout(() => location.reload(), 500);
                }} else {{
                    showToast(data.error || '重命名失败', 'error');
                }}
            }} catch (e) {{
                showToast('重命名失败: ' + e.message, 'error');
            }}
        }}

        // 复制操作
        async function copyItem(path) {{
            try {{
                const response = await fetch('/api/copy', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ src_path: path }})
                }});
                const data = await response.json();
                if (data.success) {{
                    showToast('复制成功');
                    setTimeout(() => location.reload(), 500);
                }} else {{
                    showToast(data.error || '复制失败', 'error');
                }}
            }} catch (e) {{
                showToast('复制失败: ' + e.message, 'error');
            }}
        }}

        // 移动操作
        async function showMoveModal(path) {{
            movePath = path;
            await loadDirectories();
            showModal('moveModal');
        }}

        async function loadDirectories() {{
            try {{
                const response = await fetch('/api/directories');
                const data = await response.json();
                if (data.success) {{
                    directories = data.directories;
                    const select = document.getElementById('targetDir');
                    select.innerHTML = '';
                    data.directories.forEach(dir => {{
                        const option = document.createElement('option');
                        option.value = dir;
                        option.textContent = dir || '/ (根目录)';
                        select.appendChild(option);
                    }});
                    select.value = currentPath;
                }}
            }} catch (e) {{
                showToast('加载目录列表失败', 'error');
            }}
        }}

        async function confirmMove() {{
            const targetDir = document.getElementById('targetDir').value;
            try {{
                const response = await fetch('/api/move', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ src_path: movePath, dest_dir: targetDir }})
                }});
                const data = await response.json();
                if (data.success) {{
                    showToast('移动成功');
                    closeModal('moveModal');
                    setTimeout(() => location.reload(), 500);
                }} else {{
                    showToast(data.error || '移动失败', 'error');
                }}
            }} catch (e) {{
                showToast('移动失败: ' + e.message, 'error');
            }}
        }}

        // 创建目录操作
        function showMkdirModal() {{
            document.getElementById('dirName').value = '';
            showModal('mkdirModal');
            setTimeout(() => document.getElementById('dirName').focus(), 100);
        }}

        async function confirmMkdir() {{
            const dirName = document.getElementById('dirName').value.trim();
            if (!dirName) {{
                showToast('请输入目录名称', 'warning');
                return;
            }}

            try {{
                const response = await fetch('/api/mkdir', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ dir_name: dirName, parent_dir: currentPath }})
                }});
                const data = await response.json();
                if (data.success) {{
                    showToast('创建目录成功');
                    closeModal('mkdirModal');
                    setTimeout(() => location.reload(), 500);
                }} else {{
                    showToast(data.error || '创建目录失败', 'error');
                }}
            }} catch (e) {{
                showToast('创建目录失败: ' + e.message, 'error');
            }}
        }}

        // 分享功能
        let sharePath = '';

        function showShareModal(filePath) {{
            sharePath = filePath;
            const fileName = filePath.split('/').pop();
            document.getElementById('shareFileName').textContent = fileName;
            document.getElementById('sharePassword').value = '';
            document.getElementById('shareExpires').value = '';
            document.getElementById('shareMaxDownloads').value = '';
            showModal('shareModal');
        }}

        async function confirmShare() {{
            const password = document.getElementById('sharePassword').value.trim() || null;
            const expiresInput = document.getElementById('shareExpires').value.trim();
            const maxDownloadsInput = document.getElementById('shareMaxDownloads').value.trim();

            const expiresIn = expiresInput ? parseInt(expiresInput) * 3600 : null;
            const maxDownloads = maxDownloadsInput ? parseInt(maxDownloadsInput) : null;

            try {{
                const response = await fetch('/api/share', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        file_path: sharePath,
                        password: password,
                        expires_in: expiresIn,
                        max_downloads: maxDownloads
                    }})
                }});
                const data = await response.json();
                if (data.success) {{
                    const shareUrl = window.location.origin + '/share/access/' + data.share.share_id;
                    window.open(shareUrl, '_blank');
                    showToast('分享链接创建成功');
                    closeModal('shareModal');
                }} else {{
                    showToast(data.error || '创建分享失败', 'error');
                }}
            }} catch (e) {{
                showToast('创建分享失败: ' + e.message, 'error');
            }}
        }}

        // ZIP批量下载
        function updateSelection() {{
            const checkboxes = document.querySelectorAll('.file-select:checked');
            const count = checkboxes.length;
            document.getElementById('selectedCount').textContent = count;

            const selectionBar = document.getElementById('selectionBar');
            if (count > 0) {{
                selectionBar.classList.add('show');
            }} else {{
                selectionBar.classList.remove('show');
            }}
        }}

        function clearSelection() {{
            document.querySelectorAll('.file-select').forEach(function(cb) {{ cb.checked = false; }});
            updateSelection();
        }}

        async function downloadZip() {{
            const checkboxes = document.querySelectorAll('.file-select:checked');
            const paths = Array.from(checkboxes).map(function(cb) {{ return cb.dataset.path; }});

            if (paths.length === 0) {{
                showToast('请先选择要下载的文件', 'warning');
                return;
            }}

            try {{
                showToast('正在生成ZIP文件...', 'info');
                const response = await fetch('/api/zip-download', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ paths: paths }})
                }});

                if (response.ok) {{
                    const blob = await response.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'download.zip';
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    document.body.removeChild(a);
                    showToast('ZIP下载已开始');
                    clearSelection();
                }} else {{
                    const data = await response.json();
                    showToast(data.error || 'ZIP下载失败', 'error');
                }}
            }} catch (e) {{
                showToast('ZIP下载失败: ' + e.message, 'error');
            }}
        }}

        // 搜索和筛选
        searchInput.addEventListener('input', function() {{
            filterFiles(this.value);
        }});

        function filterFiles(query) {{
            query = query.toLowerCase();
            let visibleCount = 0;

            itemList.querySelectorAll('.file-item').forEach(function(item) {{
                const name = item.dataset.name || '';
                const type = item.dataset.fileType || 'other';
                const typeFilter = document.getElementById('typeFilter').value;

                const nameMatch = name.includes(query);
                const typeMatch = typeFilter === 'all' || typeFilter === type;

                const shouldShow = (nameMatch || query === '') && typeMatch;
                item.classList.toggle('hidden', !shouldShow);
                if (shouldShow) visibleCount++;
            }});

            itemCount.textContent = visibleCount + ' 个项目';
            noResults.style.display = visibleCount === 0 ? 'block' : 'none';
        }}

        function filterByType(type) {{
            const url = new URL(window.location.href);
            if (type === 'all') {{
                url.searchParams.delete('type');
            }} else {{
                url.searchParams.set('type', type);
            }}
            window.location.href = url.toString();
        }}

        function changeSort(sortBy) {{
            const url = new URL(window.location.href);
            url.searchParams.set('sort', sortBy);
            if (searchInput.value) {{
                url.searchParams.set('q', searchInput.value);
            }}
            const typeFilter = document.getElementById('typeFilter').value;
            if (typeFilter && typeFilter !== 'all') {{
                url.searchParams.set('type', typeFilter);
            }} else {{
                url.searchParams.delete('type');
            }}
            window.location.href = url.toString();
        }}

        // 按 ESC 关闭模态框
        document.addEventListener('keydown', function(e) {{
            if (e.key === 'Escape') {{
                ['deleteModal', 'renameModal', 'moveModal', 'mkdirModal', 'shareModal'].forEach(function(id) {{
                    var el = document.getElementById(id);
                    if (el) el.classList.remove('show');
                }});
            }}
        }});

        // 初始化
        initTheme();
        if (searchInput.value) {{
            filterFiles(searchInput.value);
        }}
    </script>
</body>
</html>
"""

__all__ = ['render_file_list_page']
