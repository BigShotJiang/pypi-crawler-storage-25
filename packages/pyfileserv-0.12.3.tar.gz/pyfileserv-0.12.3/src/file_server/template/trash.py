"""trash template"""

from .base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    format_size,
    _escape_html,
    css_links,
    js_scripts,
)

def render_trash_page(username: str, items: list, is_admin: bool = False) -> str:
    """渲染回收站页面

    Args:
        username: 当前用户名
        items: 已删除文件列表，每项为字典包含:
            - id: 项目ID
            - original_path: 原始路径
            - file_name: 文件名
            - deleted_time: 删除时间
            - size: 文件大小
    """
    item_rows = ""
    if not items:
        item_rows = '<tr><td colspan="5" style="text-align:center;color:var(--text-secondary);padding:40px;">回收站为空</td></tr>'
    else:
        for item in items:
            item_id = _escape_html(str(item.get('id', '')))
            original_path = _escape_html(item.get('original_path', ''))
            file_name = _escape_html(item.get('file_name', ''))
            deleted_time = _escape_html(item.get('deleted_time', ''))
            size = format_size(item.get('size', 0)) if item.get('size') is not None else '-'
            item_rows += f"""
                    <tr>
                        <td data-label="文件名">{file_name}</td>
                        <td data-label="原始路径">{original_path}</td>
                        <td data-label="删除时间">{deleted_time}</td>
                        <td data-label="大小">{size}</td>
                        <td data-label="操作" class="action-cell">
                            <button class="action-btn restore-btn" onclick="restoreItem('{item_id}')">♻️ 还原</button>
                            <button class="action-btn delete-btn" onclick="permanentDelete('{item_id}', '{file_name}')">🗑️ 永久删除</button>
                        </td>
                    </tr>"""

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>回收站 - 文件服务器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'modal.css', 'header.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            min-height: 100vh;
            padding: 20px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: var(--bg-secondary);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: var(--text-primary);
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: none;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-danger {{
            background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
            color: white;
        }}
        .btn-danger:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(255, 65, 108, 0.4);
        }}
        .btn-secondary {{
            background: var(--bg-secondary);
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .trash-table {{
            width: 100%;
            background: var(--bg-secondary);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border-collapse: separate;
            border-spacing: 0;
            overflow: hidden;
        }}
        .trash-table thead th {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            padding: 14px 18px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
        }}
        .trash-table tbody td {{
            padding: 12px 18px;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
            font-size: 14px;
        }}
        .trash-table tbody tr:last-child td {{
            border-bottom: none;
        }}
        .trash-table tbody tr:hover {{
            background: rgba(102, 126, 234, 0.05);
        }}
        .action-cell {{
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }}
        .action-btn {{
            padding: 6px 14px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }}
        .restore-btn {{
            background: rgba(102, 126, 234, 0.1);
            color: #667eea;
        }}
        .restore-btn:hover {{
            background: #667eea;
            color: white;
        }}
        .delete-btn {{
            background: rgba(255, 65, 108, 0.1);
            color: #ff416c;
        }}
        .delete-btn:hover {{
            background: #ff416c;
            color: white;
        }}
        @media (max-width: 768px) {{
            .trash-table thead {{ display: none; }}
            .trash-table tbody tr {{
                display: block;
                margin-bottom: 15px;
                border: 1px solid var(--border-color);
                border-radius: 8px;
                padding: 10px;
            }}
            .trash-table tbody td {{
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 8px 10px;
                border-bottom: 1px solid rgba(0,0,0,0.05);
            }}
            .trash-table tbody td::before {{
                content: attr(data-label);
                font-weight: 600;
                color: var(--text-secondary);
            }}
            .trash-table tbody td:last-child {{
                border-bottom: none;
            }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>回收站</h1>
        </div>
        <div class="user-info">
            <span class="user-badge" onclick="toggleUserMenu(event)">👤 {username}</span>
            <div class="user-dropdown" id="userDropdown">
                <button class="dropdown-item" onclick="toggleTheme()">🌙 切换主题</button>
                {f'<a href="/admin" class="dropdown-item"  target="_blank">⚙️ 用户管理</a>' if is_admin else ''}
                <a href="/logout" class="dropdown-item">🚪 退出登录</a>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <!-- 永久删除确认模态框 -->
    <div class="modal-overlay" id="deleteModal">
        <div class="modal">
            <div class="modal-title">⚠️ 永久删除确认</div>
            <div class="modal-content">确定要永久删除 "<span id="deleteFileName"></span>" 吗？此操作不可恢复。</div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeDeleteModal()">取消</button>
                <button class="modal-btn danger" id="confirmDeleteBtn" onclick="confirmPermanentDelete()">永久删除</button>
            </div>
        </div>
    </div>

    <!-- 清空回收站确认模态框 -->
    <div class="modal-overlay" id="emptyTrashModal">
        <div class="modal">
            <div class="modal-title">⚠️ 清空回收站确认</div>
            <div class="modal-content">确定要清空回收站吗？所有文件将被永久删除，此操作不可恢复。</div>
            <div class="modal-actions">
                <button class="modal-btn cancel" onclick="closeEmptyTrashModal()">取消</button>
                <button class="modal-btn danger" onclick="confirmEmptyTrash()">清空回收站</button>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="toolbar">
            <h2>🗑️ 回收站 ({len(items)} 项)</h2>
            <button onclick="showEmptyTrashModal()" class="btn btn-danger" {'disabled' if not items else ''}>🧹 清空回收站</button>
            <a href="/" class="btn btn-secondary">↩️ 返回文件列表</a>
        </div>

        <table class="trash-table">
            <thead>
                <tr>
                    <th>文件名</th>
                    <th>原始路径</th>
                    <th>删除时间</th>
                    <th>大小</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                {item_rows}
            </tbody>
        </table>
    </div>

    {js_scripts('theme.js', 'toast.js', 'usermenu.js')}
    <script>
        let pendingDeleteId = null;

        function restoreItem(itemId) {{
            fetch('/api/trash/restore', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{ item_id: itemId }})
            }}).then(response => response.json()).then(data => {{
                if (data.success) {{
                    showToast('文件已还原');
                    setTimeout(() => location.reload(), 1000);
                }} else {{
                    showToast(data.error || '还原失败', 'error');
                }}
            }}).catch(err => {{
                showToast('还原失败: ' + err, 'error');
            }});
        }}

        function permanentDelete(itemId, fileName) {{
            pendingDeleteId = itemId;
            document.getElementById('deleteFileName').textContent = fileName;
            document.getElementById('deleteModal').classList.add('show');
        }}

        function closeDeleteModal() {{
            document.getElementById('deleteModal').classList.remove('show');
            pendingDeleteId = null;
        }}

        function confirmPermanentDelete() {{
            if (!pendingDeleteId) return;
            fetch(`/api/trash/delete/${{pendingDeleteId}}`, {{
                method: 'POST',
            }}).then(response => response.json()).then(data => {{
                if (data.success) {{
                    showToast('文件已永久删除');
                    setTimeout(() => location.reload(), 1000);
                }} else {{
                    showToast(data.error || '删除失败', 'error');
                }}
            }}).catch(err => {{
                showToast('删除失败: ' + err, 'error');
            }}).finally(() => {{
                closeDeleteModal();
            }});
        }}

        function showEmptyTrashModal() {{
            document.getElementById('emptyTrashModal').classList.add('show');
        }}

        function closeEmptyTrashModal() {{
            document.getElementById('emptyTrashModal').classList.remove('show');
        }}

        function confirmEmptyTrash() {{
            fetch('/api/trash/empty', {{
                method: 'POST',
            }}).then(response => response.json()).then(data => {{
                if (data.success) {{
                    showToast('回收站已清空');
                    setTimeout(() => location.reload(), 1000);
                }} else {{
                    showToast(data.error || '清空失败', 'error');
                }}
            }}).catch(err => {{
                showToast('清空失败: ' + err, 'error');
            }}).finally(() => {{
                closeEmptyTrashModal();
            }});
        }}

        // ESC 关闭模态框
        document.addEventListener('keydown', (e) => {{
            if (e.key === 'Escape') {{
                closeDeleteModal();
                closeEmptyTrashModal();
            }}
        }});

        initTheme();
    </script>
</body>
</html>
"""

__all__ = ['render_trash_page']
