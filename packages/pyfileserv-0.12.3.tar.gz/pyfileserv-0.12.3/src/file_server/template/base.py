"""HTML 模板 - 基础模块（公共 CSS/JS/工具函数）"""
import os
import urllib.parse
from datetime import datetime

CSS_GRADIENT_PRIMARY = "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"

# Logo SVG (内嵌)
LOGO_SVG = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="48" height="48">
  <defs>
    <linearGradient id="logoGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea"/>
      <stop offset="100%" style="stop-color:#764ba2"/>
    </linearGradient>
  </defs>
  <circle cx="64" cy="64" r="60" fill="url(#logoGrad1)"/>
  <path d="M24 45 L24 95 C24 100 28 104 33 104 L95 104 C100 104 104 100 104 95 L104 52 C104 47 100 43 95 43 L60 43 L52 35 C50 33 47 32 44 32 L33 32 C28 32 24 36 24 41 L24 45 Z" fill="white" opacity="0.95"/>
  <path d="M24 50 L24 95 C24 100 28 104 33 104 L95 104 C100 104 104 100 104 95 L104 52 C104 47 100 43 95 43 L33 43 C28 43 24 47 24 52 L24 50 Z" fill="white"/>
  <circle cx="90" cy="78" r="24" fill="url(#logoGrad1)"/>
  <rect x="78" y="74" width="24" height="20" rx="3" fill="white"/>
  <path d="M82 74 L82 66 C82 60 86 56 90 56 C94 56 98 60 98 66 L98 74" stroke="white" stroke-width="5" fill="none" stroke-linecap="round"/>
  <circle cx="90" cy="83" r="3" fill="url(#logoGrad1)"/>
  <rect x="88" y="83" width="4" height="6" fill="url(#logoGrad1)"/>
</svg>'''

def format_size(size: int) -> str:
    """格式化文件大小"""
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    elif size < 1024 * 1024 * 1024:
        return f"{size / (1024 * 1024):.1f} MB"
    else:
        return f"{size / (1024 * 1024 * 1024):.1f} GB"


def format_time(timestamp: float) -> str:
    """格式化时间戳为可读格式"""
    return datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')


def quote_path(path: str, leading_slash: bool = True) -> str:
    """正确编码路径，只编码文件名部分，保留斜杠

    Args:
        path: 要编码的路径
        leading_slash: 是否在结果前添加前导斜杠，用于页面链接（True）或下载/查看链接（False）
    """
    if not path or path == '.':
        return '/' if leading_slash else ''
    # 统一使用正斜杠分隔
    path = path.replace(os.sep, '/')
    parts = path.split('/')
    quoted_parts = [urllib.parse.quote(part) for part in parts if part]
    result = '/'.join(quoted_parts)
    return '/' + result if leading_slash else result


def css_links(*filenames: str) -> str:
    """Generate <link> tags for CSS files in /static/css/

    Includes a blocking inline script that sets the data-theme attribute
    before any CSS loads, preventing a flash of incorrect theme (FIT).
    """
    preload = """    <script>
        (function(){var t=localStorage.getItem('theme')||(window.matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light');document.documentElement.setAttribute('data-theme',t);})();
    </script>"""
    links = '\n'.join(
        f'    <link rel="stylesheet" href="/static/css/{fn}">'
        for fn in filenames
    )
    return preload + '\n' + links


def js_scripts(*filenames: str) -> str:
    """Generate <script> tags for JS files in /static/js/

    Scripts are loaded synchronously (without defer) so that inline
    <script> blocks appearing after them can safely call their functions.
    """
    return '\n'.join(
        f'    <script src="/static/js/{fn}"></script>'
        for fn in filenames
    ).strip()


def _escape_html(text: str) -> str:
    """转义 HTML 特殊字符"""
    if not text:
        return text
    return (text.replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;')
            .replace("'", '&#039;'))


# 导出所有公共内容
__all__ = [
    'CSS_GRADIENT_PRIMARY',
    'LOGO_SVG',
    'format_size',
    'format_time',
    'quote_path',
    'css_links',
    'js_scripts',
    '_escape_html',
]
