"""share_access template"""

from .base import (
    CSS_GRADIENT_PRIMARY,
    LOGO_SVG,
    _escape_html,
    css_links,
    js_scripts,
)

def render_share_access_page(file_name: str, has_password: bool,
                             error_msg: str = "", is_folder: bool = False) -> str:
    """渲染分享访问页面（访客使用，无需登录）

    Args:
        file_name: 文件名
        has_password: 是否需要密码
        error_msg: 错误消息
        is_folder: 是否为文件夹
    """
    error_html = f'<div class="error">{_escape_html(error_msg)}</div>' if error_msg else ""
    password_html = f"""
        <div class="form-group">
            <label for="password">访问密码</label>
            <input type="password" id="password" name="password" placeholder="请输入访问密码" {'required' if has_password else ''}>
        </div>""" if has_password else ""

    # 根据是否为文件夹显示不同的按钮文本和图标
    download_btn_text = "📦 下载文件夹" if is_folder else "⬇️ 下载文件"
    file_icon = "📁" if is_folder else "📎"

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape_html(file_name)} - 文件分享</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    {css_links('common.css', 'toast.css', 'forms.css', 'buttons.css', 'error.css')}
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: {CSS_GRADIENT_PRIMARY};
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }}
        .share-container {{
            background: var(--bg-secondary);
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            padding: 40px;
            width: 100%;
            max-width: 450px;
        }}
        .share-header {{
            text-align: center;
            margin-bottom: 30px;
        }}
        .share-header .logo {{
            margin-bottom: 15px;
        }}
        .share-header h1 {{
            color: var(--text-primary);
            font-size: 24px;
            margin-bottom: 10px;
            word-wrap: break-word;
            word-break: break-all;
            overflow-wrap: break-word;
            line-height: 1.4;
        }}
        .share-header p {{
            color: var(--text-secondary);
            font-size: 14px;
        }}
        .file-icon {{
            font-size: 48px;
            margin-bottom: 15px;
        }}
        .form-group {{
            margin-bottom: 20px;
        }}
        .form-group label {{
            display: block;
            margin-bottom: 8px;
            color: var(--text-primary);
            font-weight: 600;
            font-size: 14px;
        }}
        .btn-primary {{
            width: 100%;
        }}
    </style>
</head>
<body>
    <div class="share-container">
        <div class="share-header">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <div class="file-icon">{file_icon}</div>
            <h1>{_escape_html(file_name)}</h1>
            <p>有人与您分享了{"文件夹" if is_folder else "文件"}</p>
        </div>

        <div class="toast-container" id="toastContainer"></div>

        {error_html}

        <form method="POST" action="">
            {password_html}
            <button type="submit" class="btn-primary">{download_btn_text}</button>
        </form>
    </div>

    {js_scripts('theme.js', 'toast.js')}
</body>
</html>
"""

__all__ = ['render_share_access_page']
