"""回收站模块"""
import json
import logging
import os
import secrets
import shutil
import time
from pathlib import Path
from typing import Optional, Dict, List, Any

logger = logging.getLogger(__name__)


class TrashManager:
    """管理回收站"""

    TRASH_DIR_NAME = '.trash'
    METADATA_FILE = 'metadata.json'

    def __init__(self, serve_dir: Path):
        """初始化回收站管理器

        Args:
            serve_dir: 文件服务目录
        """
        self._serve_dir = serve_dir
        self._trash_dir = serve_dir / self.TRASH_DIR_NAME
        self._metadata_file = self._trash_dir / self.METADATA_FILE
        self._items: Dict[str, Dict[str, Any]] = {}
        self._ensure_trash_dir()
        self._load()

    def _ensure_trash_dir(self) -> None:
        """确保回收站目录存在"""
        self._trash_dir.mkdir(exist_ok=True)
        if not self._metadata_file.exists():
            with open(self._metadata_file, 'w', encoding='utf-8') as f:
                json.dump({}, f)

    def _load(self) -> None:
        """从文件加载元数据"""
        if self._metadata_file.exists():
            try:
                with open(self._metadata_file, 'r', encoding='utf-8') as f:
                    self._items = json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                logger.error(f"加载回收站元数据失败: {e}")
                self._items = {}

    def _save(self) -> None:
        """保存元数据到文件"""
        try:
            with open(self._metadata_file, 'w', encoding='utf-8') as f:
                json.dump(self._items, f, ensure_ascii=False, indent=2)
        except IOError as e:
            logger.error(f"保存回收站元数据失败: {e}")

    def _generate_trash_name(self, original_name: str) -> str:
        """生成回收站中的文件名，避免冲突

        Args:
            original_name: 原始文件名

        Returns:
            回收站中的文件名
        """
        timestamp = int(time.time()*1000)
        name, ext = os.path.splitext(original_name)
        return f"{name}_{timestamp}{ext}"

    def move_to_trash(self, file_path: str) -> Optional[str]:
        """将文件/目录移动到回收站

        Args:
            file_path: 相对于 serve_dir 的文件路径

        Returns:
            回收站项目ID，失败返回 None
        """
        # 统一路径分隔符为正斜杠，避免 Windows 反斜杠问题
        file_path = file_path.replace('\\', '/')
        
        full_path = self._serve_dir / file_path

        if not full_path.exists():
            logger.error(f"要删除的文件不存在: {full_path}")
            return None

        # 安全检查
        try:
            if not str(full_path.resolve()).startswith(str(self._serve_dir.resolve())):
                logger.error(f"路径遍历攻击: {file_path}")
                return None
        except Exception:
            return None

        # 生成回收站文件名
        trash_name = self._generate_trash_name(full_path.name)
        trash_path = self._trash_dir / trash_name

        # 处理冲突
        counter = 1
        while trash_path.exists():
            name, ext = os.path.splitext(trash_name)
            trash_path = self._trash_dir / f"{name}_{counter}{ext}"
            counter += 1

        try:
            shutil.move(str(full_path), str(trash_path))

            # 生成项目ID
            item_id = os.path.basename(trash_path.name) + "_" + secrets.token_hex(4)

            # 记录元数据
            is_dir = trash_path.is_dir()
            size = self._calculate_size(trash_path) if is_dir else trash_path.stat().st_size

            self._items[item_id] = {
                'original_path': file_path,
                'trash_name': trash_path.name,
                'deleted_at': time.time(),
                'is_dir': is_dir,
                'size': size,
            }
            self._save()

            logger.info(f"已移动到回收站: {file_path} -> {trash_path.name}")
            return item_id
        except Exception as e:
            logger.error(f"移动到回收站失败: {file_path}, 错误: {e}")
            return None

    def restore(self, item_id: str) -> bool:
        """从回收站恢复文件

        Args:
            item_id: 回收站项目ID

        Returns:
            是否恢复成功
        """
        if item_id not in self._items:
            return False

        item = self._items[item_id]
        trash_path = self._trash_dir / item['trash_name']
        
        # 统一路径分隔符为正斜杠，避免 Windows 反斜杠问题
        original_path = item['original_path'].replace('\\', '/')
        restore_path = self._serve_dir / original_path

        if not trash_path.exists():
            logger.error(f"回收站文件不存在: {trash_path}")
            del self._items[item_id]
            self._save()
            return False

        # 确保恢复目标目录存在
        restore_path.parent.mkdir(parents=True, exist_ok=True)

        # 处理冲突
        if restore_path.exists():
            name, ext = os.path.splitext(restore_path.name)
            counter = 1
            while restore_path.exists():
                restore_path = restore_path.parent / f"{name}_restored_{counter}{ext}"
                counter += 1

        try:
            shutil.move(str(trash_path), str(restore_path))
            del self._items[item_id]
            self._save()
            logger.info(f"已恢复: {item['original_path']}")
            return True
        except Exception as e:
            logger.error(f"恢复失败: {item_id}, 错误: {e}")
            return False

    def permanent_delete(self, item_id: str) -> bool:
        """永久删除回收站项目

        Args:
            item_id: 回收站项目ID

        Returns:
            是否删除成功
        """
        if item_id not in self._items:
            return False

        item = self._items[item_id]
        trash_path = self._trash_dir / item['trash_name']

        try:
            if trash_path.exists():
                if trash_path.is_dir():
                    shutil.rmtree(trash_path)
                else:
                    trash_path.unlink()

            del self._items[item_id]
            self._save()
            logger.info(f"永久删除: {item['original_path']}")
            return True
        except Exception as e:
            logger.error(f"永久删除失败: {item_id}, 错误: {e}")
            return False

    def empty_trash(self) -> int:
        """清空回收站

        Returns:
            删除的项目数
        """
        count = 0
        for item_id in list(self._items.keys()):
            if self.permanent_delete(item_id):
                count += 1
        return count

    def list_items(self) -> List[Dict[str, Any]]:
        """列出回收站所有项目"""
        # 检查回收站文件是否实际存在
        valid_items = {}
        for item_id, item in self._items.items():
            trash_path = self._trash_dir / item['trash_name']
            if trash_path.exists():
                valid_items[item_id] = item
            # If file doesn't exist, skip it (it's orphaned metadata)

        if len(valid_items) != len(self._items):
            self._items = valid_items
            self._save()

        return [{'id': item_id, **item} for item_id, item in self._items.items()]

    def _calculate_size(self, path: Path) -> int:
        """计算目录大小"""
        total = 0
        for root, dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return total
