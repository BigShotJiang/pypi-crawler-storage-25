"""文件分享模块 — 业务逻辑层"""
import logging
import secrets
import time
from typing import Optional, Dict, List, Any

logger = logging.getLogger(__name__)


class ShareManager:
    """管理文件分享链接（业务逻辑层，委托存储后端）"""

    def __init__(self, store, password_hasher):
        """初始化分享管理器

        Args:
            store: ShareStore 或 DatabaseShareStore 实例
            password_hasher: PasswordHasher 实例，用于分享密码哈希
        """
        self._store = store
        self._hasher = password_hasher

    def create_share(self, file_path: str, password: Optional[str] = None,
                     expires_in: Optional[int] = None, max_downloads: Optional[int] = None,
                     created_by: Optional[str] = None) -> Dict[str, Any]:
        """创建分享链接

        Args:
            file_path: 文件相对路径
            password: 访问密码 (可选)
            expires_in: 过期时间（秒），None 表示永不过期
            max_downloads: 最大下载次数，None 表示不限制
            created_by: 创建者用户名 (可选)

        Returns:
            分享信息字典，包含 share_id, password 等（password 返回明文，仅此一次）
        """
        share_id = secrets.token_urlsafe(16)
        expires_at = time.time() + expires_in if expires_in else None

        share_data = {
            'file_path': file_path,
            'password_hash': self._hasher.hash_password(password) if password else None,
            'expires_at': expires_at,
            'max_downloads': max_downloads,
            'download_count': 0,
            'created_at': time.time(),
            'created_by': created_by,
            'is_deleted': False,
        }

        self._store.create_share(share_id, share_data)

        logger.info(f"创建分享链接: {share_id}, 文件: {file_path}")

        result = {'share_id': share_id, **share_data}
        result['password'] = password  # 明文密码仅返回一次
        del result['password_hash']     # 不暴露哈希值
        return result

    def get_share(self, share_id: str) -> Optional[Dict[str, Any]]:
        """获取分享信息（仅有效分享）

        Args:
            share_id: 分享ID

        Returns:
            分享信息字典，如果不存在/已过期/已删除返回 None
        """
        share = self._store.get_share(share_id)
        if share:
            share['has_password'] = bool(share.get('password_hash'))
        return share

    def validate_access(self, share_id: str, password: Optional[str] = None) -> tuple:
        """验证分享访问权限

        Args:
            share_id: 分享ID
            password: 访问密码

        Returns:
            (valid, share_info_or_error_message)
        """
        share = self.get_share(share_id)
        if not share:
            return False, '分享链接不存在或已过期'

        # 检查密码 — 使用 bcrypt 验证
        stored_hash = share.get('password_hash')
        if stored_hash and (not password or not self._hasher.verify_password(password, stored_hash)):
            return False, '密码错误'

        # 检查下载次数
        if share.get('max_downloads') and share['download_count'] >= share['max_downloads']:
            return False, '下载次数已达上限'

        return True, share

    def record_download(self, share_id: str) -> None:
        """记录下载次数"""
        self._store.record_download(share_id)

    def delete_share(self, share_id: str) -> bool:
        """删除分享链接（软删除）

        Args:
            share_id: 分享ID

        Returns:
            是否成功软删除
        """
        if self._store.soft_delete_share(share_id):
            logger.info(f"软删除分享链接: {share_id}")
            return True
        return False

    def permanent_delete_share(self, share_id: str) -> bool:
        """永久删除分享（仅限已软删除的）

        Args:
            share_id: 分享ID

        Returns:
            是否成功永久删除
        """
        if self._store.permanent_delete_share(share_id):
            logger.info(f"永久删除分享链接: {share_id}")
            return True
        return False

    def update_share(self, share_id: str, updates: dict) -> bool:
        """更新分享（仅允许未过期/未删除的分享）

        Args:
            share_id: 分享ID
            updates: 要更新的字段（expires_at, max_downloads）

        Returns:
            是否更新成功
        """
        share = self._store.get_share(share_id)
        if not share:
            return False
        return self._store.update_share(share_id, updates)

    def list_shares(self) -> List[Dict[str, Any]]:
        """列出所有分享（含过期和软删除），用于管理页面"""
        return self._store.list_shares_for_management()

    def get_file_shares(self, file_path: str) -> List[Dict[str, Any]]:
        """获取文件的所有分享链接（仅有效分享）"""
        return self._store.get_file_shares(file_path)
