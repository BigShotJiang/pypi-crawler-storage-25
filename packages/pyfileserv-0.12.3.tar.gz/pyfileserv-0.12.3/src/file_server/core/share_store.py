"""分享数据存储模块 — JSON 文件后端"""
import json
import logging
import threading
import time
from pathlib import Path
from typing import Optional, Dict, List

logger = logging.getLogger(__name__)


class ShareStore:
    """基于 JSON 文件的分享数据存储"""

    def __init__(self, data_file: Path, password_hasher=None):
        """初始化分享存储

        Args:
            data_file: JSON 数据文件路径
            password_hasher: PasswordHasher 实例，用于密码迁移
        """
        self._data_file = data_file
        self._shares: Dict[str, Dict] = {}
        self._lock = threading.Lock()
        self._hasher = password_hasher
        self._load()
        self._migrate()

    def _load(self) -> None:
        """从文件加载分享数据"""
        if self._data_file.exists():
            try:
                with open(self._data_file, 'r', encoding='utf-8') as f:
                    self._shares = json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                logger.error(f"加载分享数据失败: {e}")
                self._shares = {}

    def _save(self) -> None:
        """保存分享数据到文件"""
        try:
            with open(self._data_file, 'w', encoding='utf-8') as f:
                json.dump(self._shares, f, ensure_ascii=False, indent=2)
        except IOError as e:
            logger.error(f"保存分享数据失败: {e}")

    def _migrate(self) -> None:
        """数据迁移：明文密码 -> bcrypt hash，补全 is_deleted 字段"""
        if not self._shares:
            return
        changed = False
        for sid, s in self._shares.items():
            # 迁移明文密码
            if 'password' in s and s['password'] and 'password_hash' not in s:
                if self._hasher:
                    s['password_hash'] = self._hasher.hash_password(s['password'])
                else:
                    # 无 hasher 时保留原密码标记为已哈希（不应发生）
                    s['password_hash'] = s['password']
                del s['password']
                changed = True
            elif 'password' in s:
                del s['password']
                changed = True
            # 补全 is_deleted
            if 'is_deleted' not in s:
                s['is_deleted'] = False
                changed = True
        if changed:
            self._save()

    # --- 与 DatabaseShareStore 一致的接口 ---

    def create_share(self, share_id: str, share_data: dict) -> None:
        """创建分享记录"""
        with self._lock:
            self._shares[share_id] = share_data
            self._save()

    def get_share(self, share_id: str) -> Optional[Dict]:
        """获取有效分享（非过期、非删除）"""
        with self._lock:
            share = self._shares.get(share_id)
            if not share:
                return None
            if share.get('is_deleted', False):
                return None
            if share.get('expires_at') and time.time() > share['expires_at']:
                return None
            return {'share_id': share_id, **share}

    def get_share_any(self, share_id: str) -> Optional[Dict]:
        """获取任意状态分享（含过期/删除）"""
        with self._lock:
            share = self._shares.get(share_id)
            if not share:
                return None
            return {'share_id': share_id, **share}

    def list_shares_for_management(self) -> List[Dict]:
        """列出所有分享（含过期和软删除），用于管理页面"""
        now = time.time()
        with self._lock:
            shares = []
            for sid, s in self._shares.items():
                share = {'share_id': sid, **s}
                if s.get('is_deleted', False):
                    share['status'] = 'deleted'
                elif s.get('expires_at') and now > s['expires_at']:
                    share['status'] = 'expired'
                else:
                    share['status'] = 'active'
                share['has_password'] = bool(s.get('password_hash'))
                shares.append(share)
            # 按创建时间倒序
            shares.sort(key=lambda x: x.get('created_at', 0), reverse=True)
            return shares

    def update_share(self, share_id: str, updates: dict) -> bool:
        """更新分享字段（仅允许 expires_at, max_downloads）"""
        allowed = {'expires_at', 'max_downloads'}
        filtered = {k: v for k, v in updates.items() if k in allowed}
        if not filtered:
            return False
        with self._lock:
            if share_id not in self._shares:
                return False
            self._shares[share_id].update(filtered)
            self._save()
            return True

    def soft_delete_share(self, share_id: str) -> bool:
        """软删除分享"""
        with self._lock:
            share = self._shares.get(share_id)
            if not share or share.get('is_deleted', False):
                return False
            share['is_deleted'] = True
            share['deleted_at'] = time.time()
            self._save()
            return True

    def permanent_delete_share(self, share_id: str) -> bool:
        """永久删除分享（仅允许已软删除的）"""
        with self._lock:
            share = self._shares.get(share_id)
            if not share or not share.get('is_deleted', False):
                return False
            del self._shares[share_id]
            self._save()
            return True

    def record_download(self, share_id: str) -> None:
        """记录下载次数"""
        with self._lock:
            if share_id in self._shares:
                self._shares[share_id]['download_count'] = \
                    self._shares[share_id].get('download_count', 0) + 1
                self._save()

    def get_file_shares(self, file_path: str) -> List[Dict]:
        """获取文件的所有分享链接（仅有效分享）"""
        now = time.time()
        with self._lock:
            return [
                {'share_id': sid, **s} for sid, s in self._shares.items()
                if s.get('file_path') == file_path
                and not s.get('is_deleted', False)
                and not (s.get('expires_at') and now > s['expires_at'])
            ]
