"""HTTP 处理器 - 文档预览渲染模块 + 预览功能 Mixin"""
import json
import logging
import re
import urllib.parse
import zipfile
from pathlib import Path

from .utils import detect_file_type

logger = logging.getLogger(__name__)

# Optional markdown support
try:
    import markdown as _markdown
    MARKDOWN_AVAILABLE = True
except ImportError:
    MARKDOWN_AVAILABLE = False

# Optional Office document support
try:
    import mammoth
    MAMMOTH_AVAILABLE = True
except ImportError:
    MAMMOTH_AVAILABLE = False

try:
    from spire.xls import Workbook, Stream as XlsStream
    from spire.xls.common import *
    XLSX_AVAILABLE = True
except ImportError:
    XLSX_AVAILABLE = False

try:
    from spire.presentation import Presentation, FileFormat
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False

# 任务列表正则：匹配 <li>[ ] 或 <li>[x] 或 <li>[X]
_TASKLIST_RE = re.compile(r'<li>\[([ xX])\]\s*')


def _render_task_lists(html: str) -> str:
    """将 Markdown 任务列表语法转换为可点击的复选框 HTML"""
    def _replace(match: re.Match) -> str:
        state = match.group(1)
        checked = ' checked' if state in ('x', 'X') else ''
        return f'<li class="task-list-item"><input type="checkbox"{checked} disabled>'
    return _TASKLIST_RE.sub(_replace, html)


def _render_office_unavailable(doc_type: str) -> str:
    """当 Office 库不可用时，返回提示 HTML"""
    return f"""<div class="unavailable-msg">
    <h2>预览不可用</h2>
    <p>{doc_type} 文档预览需要安装额外的依赖库。</p>
    <p>请运行以下命令安装：</p>
    <pre><code>pip install pyfileserv[office]</code></pre>
    <p>或单独安装：</p>
    <pre><code>pip install Spire.Presentation.Free Spire.Xls.Free mammoth</code></pre>
</div>"""


class PreviewMixin:
    """预览功能方法（图片、视频、音频、PDF、Office文档、文本、Markdown、HTML、XMind、JSON）"""

    config = None
    session_manager = None
    user_store = None

    def _handle_preview(self) -> None:
        """处理文件预览请求"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self.send_error(403, "Forbidden")
            return

        file_path_rel = self.path[len('/preview/'):].lstrip('/')
        file_path_rel = urllib.parse.unquote(file_path_rel)
        file_path = Path(self.directory) / file_path_rel

        from .utils import _is_safe_path
        if not _is_safe_path(Path(self.directory), file_path):
            self.send_error(403, "Forbidden")
            return

        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "File not found")
            return

        file_name = file_path.name
        file_type = detect_file_type(file_name)

        if file_type == 'image':
            self._handle_image_preview(username, file_path_rel, file_name)
        elif file_type == 'video':
            self._handle_video_preview(username, file_path_rel, file_name)
        elif file_type == 'audio':
            self._handle_audio_preview(username, file_path_rel, file_name)
        elif file_type == 'pdf':
            self._handle_pdf_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'markdown':
            self._handle_markdown_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'xmind':
            self._handle_xmind_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'docx':
            self._handle_docx_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'xlsx':
            self._handle_xlsx_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'pptx':
            self._handle_pptx_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'json':
            self._handle_json_preview(username, file_path_rel, file_name, file_path)
        elif file_type == 'text':
            ext = os.path.splitext(file_name)[1].lower()
            if ext in ('.html', '.htm'):
                self._handle_html_preview(username, file_path_rel, file_name, file_path)
            else:
                self._handle_text_preview(username, file_path_rel, file_name, file_path)
        else:
            self._serve_raw_file(file_path)

    def _handle_media_preview(self, username: str, file_path_rel: str, file_name: str,
                              media_type: str, render_func) -> None:
        """通用媒体预览（图片/视频/音频）"""
        parent_dir = (Path(self.directory) / file_path_rel).parent
        media_urls = []
        current_index = 0

        try:
            for f in sorted(os.listdir(parent_dir)):
                if not f.startswith('.') and os.path.isfile(os.path.join(parent_dir, f)):
                    if detect_file_type(f) == media_type:
                        rel = os.path.join(os.path.dirname(file_path_rel), f) if os.path.dirname(file_path_rel) else f
                        media_urls.append(rel)
                        if f == file_name:
                            current_index = len(media_urls) - 1
        except OSError:
            media_urls = [file_path_rel]
            current_index = 0

        is_admin = False
        if self.user_store:
            is_admin = self.user_store.is_admin(username)
        html = render_func(username, file_path_rel, file_name, media_urls, current_index, is_admin=is_admin)
        self._send_html_response(html)

    def _handle_image_preview(self, username: str, file_path_rel: str, file_name: str) -> None:
        """图片预览"""
        from ..template import render_image_preview_page
        self._handle_media_preview(username, file_path_rel, file_name, 'image', render_image_preview_page)

    def _handle_video_preview(self, username: str, file_path_rel: str, file_name: str) -> None:
        """视频预览"""
        from ..template import render_video_preview_page
        self._handle_media_preview(username, file_path_rel, file_name, 'video', render_video_preview_page)

    def _handle_audio_preview(self, username: str, file_path_rel: str, file_name: str) -> None:
        """音频预览"""
        from ..template import render_audio_preview_page
        self._handle_media_preview(username, file_path_rel, file_name, 'audio', render_audio_preview_page)

    def _handle_pdf_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """PDF 预览"""
        try:
            if file_path.stat().st_size > 50 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 50MB）')
                return

            from ..template import render_pdf_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_pdf_preview_page(username, file_path_rel, file_name, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"PDF 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_docx_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """Word 文档预览（使用 Mammoth 转换为 HTML）"""
        try:
            if file_path.stat().st_size > 50 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 50MB）')
                return

            from ..template import render_docx_preview_page

            rendered_html = ''
            if MAMMOTH_AVAILABLE:
                try:
                    with open(file_path, 'rb') as f:
                        result = mammoth.convert_to_html(f)
                    rendered_html = result.value
                    if result.messages:
                        logger.warning(f"Mammoth 转换警告: {result.messages}")
                except Exception as e:
                    logger.warning(f"DOCX 解析出错: {e}")
                    rendered_html = '<div class="error-msg">文档解析失败</div>'
            else:
                rendered_html = _render_office_unavailable('Word (.docx)')

            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_docx_preview_page(username, file_path_rel, file_name, rendered_html, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"DOCX 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_xlsx_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """Excel 表格预览（使用 Spire.Xls 转换为 HTML）"""
        try:
            if file_path.stat().st_size > 50 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 50MB）')
                return

            from ..template import render_xlsx_preview_page

            rendered_html = ''
            sheet_names = []
            if XLSX_AVAILABLE:
                try:
                    wb = Workbook()
                    wb.LoadFromFile(str(file_path))
                    sheet_names = [wb.Worksheets[i].Name for i in range(wb.Worksheets.Count)]
                    parts = []
                    for i, name in enumerate(sheet_names):
                        stream = XlsStream()
                        wb.Worksheets[i].SaveToHtml(stream)
                        table_html = bytes(stream.ToArray()).decode('utf-8')
                        stream.Close()
                        active = 'active' if i == 0 else ''
                        parts.append(f'<div class="sheet-pane {active}" id="sheet-{i}">')
                        parts.append(f'<div class="table-wrapper">{table_html}</div>')
                        parts.append('</div>')
                    rendered_html = '\n'.join(parts)
                    wb.Dispose()
                except Exception as e:
                    logger.warning(f"XLSX 解析出错: {e}")
                    rendered_html = '<div class="error-msg">表格解析失败</div>'
            else:
                rendered_html = _render_office_unavailable('Excel (.xlsx)')

            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_xlsx_preview_page(username, file_path_rel, file_name, rendered_html, sheet_names, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"XLSX 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_pptx_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """PowerPoint 演示文稿预览（使用 Spire.Presentation 转换为 HTML，iframe 嵌入）"""
        import tempfile

        try:
            if file_path.stat().st_size > 50 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 50MB）')
                return

            from ..template import render_pptx_preview_page

            slide_htmls = []
            slide_count = 0
            if PPTX_AVAILABLE:
                try:
                    ppt = Presentation()
                    ppt.LoadFromFile(str(file_path))
                    slide_count = ppt.Slides.Count
                    with tempfile.TemporaryDirectory() as tmpdir:
                        for i in range(slide_count):
                            tmp_path = os.path.join(tmpdir, f'slide_{i}.html')
                            ppt.Slides[i].SaveToFile(tmp_path, FileFormat.Html)
                            with open(tmp_path, 'r', encoding='utf-8') as f:
                                slide_htmls.append(f.read())
                    ppt.Dispose()
                except Exception as e:
                    logger.warning(f"PPTX 解析出错: {e}")

            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_pptx_preview_page(username, file_path_rel, file_name, slide_htmls, slide_count, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"PPTX 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_text_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """文本/代码预览"""
        try:
            if file_path.stat().st_size > 5 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 5MB）')
                return

            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            ext = os.path.splitext(file_name)[1].lower()
            lang_map = {
                '.py': 'python', '.js': 'javascript', '.ts': 'typescript',
                '.java': 'java', '.c': 'c', '.cpp': 'cpp', '.h': 'c',
                '.hpp': 'cpp', '.cs': 'csharp', '.go': 'go', '.rs': 'rust',
                '.rb': 'ruby', '.php': 'php', '.swift': 'swift',
                '.html': 'html', '.htm': 'html', '.css': 'css',
                '.scss': 'scss', '.xml': 'xml', '.sql': 'sql',
                '.sh': 'bash', '.bash': 'bash', '.yaml': 'yaml', '.yml': 'yaml',
                '.toml': 'toml', '.json': 'json', '.ini': 'ini',
                '.cfg': 'ini', '.conf': 'ini',
            }
            language = lang_map.get(ext, 'plaintext')

            from ..template import render_text_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_text_preview_page(username, file_path_rel, file_name, content, language, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"文本预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_markdown_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """Markdown 预览"""
        try:
            if file_path.stat().st_size > 5 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 5MB）')
                return

            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            rendered_html = ''
            if MARKDOWN_AVAILABLE:
                try:
                    rendered_html = _markdown.markdown(
                        content,
                        extensions=['extra', 'codehilite', 'tables', 'fenced_code'],
                        extension_configs={'codehilite': {'css_class': 'highlight'}}
                    )
                    rendered_html = _render_task_lists(rendered_html)
                except Exception as e:
                    logger.warning(f"Markdown 渲染出错，使用备用方案: {e}")
                    from ..template import _escape_html
                    rendered_html = f'<pre style="white-space: pre-wrap; word-wrap: break-word;">{_escape_html(content)}</pre>'
            else:
                from ..template import _escape_html
                rendered_html = f'<pre style="white-space: pre-wrap; word-wrap: break-word;">{_escape_html(content)}</pre>'

            from ..template import render_markdown_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_markdown_preview_page(username, file_path_rel, file_name, content, rendered_html, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"Markdown 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_html_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """HTML 预览"""
        try:
            if file_path.stat().st_size > 5 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 5MB）')
                return

            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            from ..template import render_html_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_html_preview_page(username, file_path_rel, file_name, content, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"HTML 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_xmind_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """XMind 预览"""
        try:
            if file_path.stat().st_size > 10 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 10MB）')
                return

            content_json = ''
            try:
                with zipfile.ZipFile(file_path, 'r') as zf:
                    if 'content.json' in zf.namelist():
                        with zf.open('content.json') as cf:
                            raw_data = cf.read().decode('utf-8', errors='replace')
                            try:
                                parsed = json.loads(raw_data)
                                content_json = json.dumps(parsed, indent=2, ensure_ascii=False)
                            except json.JSONDecodeError:
                                content_json = raw_data
                    else:
                        file_list = '\\n'.join(zf.namelist())
                        content_json = f"# XMind 文件结构\\n\\n此 XMind 文件包含以下文件:\\n\\n{file_list}\\n\\n注意: 未找到 content.json，可能是旧版 XMind 格式。"
            except zipfile.BadZipFile:
                content_json = "# 错误\\n\\n此文件不是有效的 ZIP 格式，可能已损坏或不是真正的 XMind 文件。"
            except Exception as e:
                content_json = f"# 读取错误\\n\\n无法读取 XMind 文件内容: {str(e)}"

            from ..template import render_xmind_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_xmind_preview_page(username, file_path_rel, file_name, content_json, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"XMind 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")

    def _handle_json_preview(self, username: str, file_path_rel: str, file_name: str, file_path: Path) -> None:
        """JSON 预览"""
        try:
            if file_path.stat().st_size > 5 * 1024 * 1024:
                self._send_error_response('文件过大，无法预览（最大 5MB）')
                return

            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            formatted_json = content
            try:
                json_data = json.loads(content)
                formatted_json = json.dumps(json_data, indent=2, ensure_ascii=False)
            except json.JSONDecodeError:
                pass

            from ..template import render_json_preview_page
            is_admin = False
            if self.user_store:
                is_admin = self.user_store.is_admin(username)
            html = render_json_preview_page(username, file_path_rel, file_name, content, formatted_json, is_admin=is_admin)
            self._send_html_response(html)
        except Exception as e:
            logger.error(f"JSON 预览失败 - 文件: {file_path_rel}, 错误: {e}")
            self.send_error(500, "Preview error")


__all__ = [
    '_render_task_lists',
    '_render_office_unavailable',
    'PreviewMixin',
]
