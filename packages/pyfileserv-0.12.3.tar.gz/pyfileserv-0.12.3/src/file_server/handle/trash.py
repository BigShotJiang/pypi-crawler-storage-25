"""回收站功能 Mixin"""
import json
import logging

logger = logging.getLogger(__name__)


class TrashMixin:
    """回收站功能方法（回收站页面、恢复、永久删除、清空）"""

    config = None
    session_manager = None
    user_store = None
    trash_manager = None

    def _handle_trash_page(self) -> None:
        """处理回收站页面"""
        from ..template import render_trash_page
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self.send_error(403, "Forbidden")
            return

        if not self.trash_manager:
            self._send_error_response('回收站功能未启用')
            return

        items = self.trash_manager.list_items()
        is_admin = False
        if self.user_store:
            is_admin = self.user_store.is_admin(username)
        html = render_trash_page(username, items, is_admin=is_admin)
        self._send_html_response(html)

    def _handle_trash_restore(self) -> None:
        """处理回收站恢复"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        if not self.trash_manager:
            self._send_error_response('回收站功能未启用')
            return

        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))

            item_id = data.get('item_id', '').strip()
            if not item_id:
                self._send_error_response('缺少项目ID')
                return

            if self.trash_manager.restore(item_id):
                logger.info(f"恢复成功 - 用户: {username}, 项目: {item_id}")
                self._send_json_response({'success': True})
            else:
                self._send_error_response('恢复失败')
        except Exception as e:
            logger.error(f"恢复失败 - 用户: {username}, 错误: {e}")
            self._send_error_response('恢复失败，请稍后重试')

    def _handle_trash_permanent_delete(self) -> None:
        """处理回收站永久删除"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        if not self.trash_manager:
            self._send_error_response('回收站功能未启用')
            return

        item_id = self.path[len('/api/trash/delete/'):].lstrip('/')
        if self.trash_manager.permanent_delete(item_id):
            logger.info(f"永久删除 - 用户: {username}, 项目: {item_id}")
            self._send_json_response({'success': True})
        else:
            self._send_error_response('删除失败')

    def _handle_trash_empty(self) -> None:
        """处理清空回收站"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        if not self.trash_manager:
            self._send_error_response('回收站功能未启用')
            return

        count = self.trash_manager.empty_trash()
        logger.info(f"清空回收站 - 用户: {username}, 删除数量: {count}")
        self._send_json_response({'success': True, 'deleted_count': count})
