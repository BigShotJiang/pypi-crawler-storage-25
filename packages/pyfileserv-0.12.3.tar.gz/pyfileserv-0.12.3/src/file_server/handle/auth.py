"""认证功能 Mixin"""
import logging
import urllib.parse

logger = logging.getLogger(__name__)


class AuthMixin:
    """认证相关方法（login/logout/session）"""

    authenticator = None
    session_manager = None
    config = None

    def _redirect_to_login(self) -> None:
        """重定向到登录页"""
        logger.info(f"未认证用户访问 {self.path}, 重定向到登录页")
        self.send_response(302)
        self.send_header('Location', '/login')
        self.end_headers()

    def _handle_login_page(self, error_msg: str = "") -> None:
        """显示登录页面"""
        from ..template import render_login_page
        session_timeout = self.config.session_timeout if self.config else 3600
        html = render_login_page(error_msg, session_timeout)
        self._send_html_response(html)

    def _handle_login(self) -> None:
        """处理登录请求"""
        # 解析表单数据
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')
        params = urllib.parse.parse_qs(post_data)

        username = params.get('username', [''])[0].strip()
        password = params.get('password', [''])[0]

        logger.info(f"登录尝试 - 用户名: {username}")

        # 认证
        if self.authenticator:
            success, result = self.authenticator.authenticate(username, password)
            if success:
                # 登录成功，result 是 session_id
                self.send_response(302)
                self.send_header('Location', '/')
                cookie_flags = 'Path=/; HttpOnly; SameSite=Strict'
                if self.config and self.config.use_https:
                    cookie_flags += '; Secure'
                self.send_header('Set-Cookie',
                                 f'session_id={result}; {cookie_flags}')
                self.end_headers()
                return
            else:
                self._handle_login_page(str(result))
                return

        # 登录失败（无 authenticator 时）
        self._handle_login_page("用户名或密码错误")

    def _handle_logout(self) -> None:
        """处理登出"""
        session_id = self._get_session_id()
        username = None
        if session_id and self.session_manager:
            username = self.session_manager.destroy_session(session_id)

        logger.info(f"用户登出: {username or '未知用户'}")

        self.send_response(302)
        self.send_header('Location', '/login')
        cookie_flags = 'Max-Age=0; Path=/; HttpOnly; SameSite=Strict'
        if self.config and self.config.use_https:
            cookie_flags += '; Secure'
        self.send_header('Set-Cookie',
                         f'session_id=; {cookie_flags}')
        self.end_headers()
