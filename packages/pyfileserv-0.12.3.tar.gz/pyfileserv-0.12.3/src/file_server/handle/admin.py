"""管理员页面和API处理"""
import json
import logging
from datetime import datetime

from ..config import MIN_PASSWORD_LENGTH
from ..core.auth import PasswordHasher, UserStore
from ..template.admin import render_admin_page

logger = logging.getLogger(__name__)


def _format_created_at(created_at: str) -> str:
    """将时间戳字符串转换为可读日期格式"""
    try:
        if created_at and created_at.replace('.', '').isdigit():
            dt = datetime.fromtimestamp(float(created_at))
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        return created_at
    except (ValueError, OSError):
        return '未知'


class AdminHandler:
    """管理员处理器 - 处理用户管理相关请求"""

    def __init__(self, user_store: UserStore):
        self.user_store = user_store
        self.hasher = PasswordHasher()

    def handle_admin_page(self, handler) -> None:
        """处理管理员页面GET请求
        
        Args:
            handler: HTTP请求处理器实例
        """
        username = handler.get_current_username() or 'Unknown'
        
        # 检查是否为管理员
        if not self.user_store.is_admin(username):
            logger.warning(f"非管理员尝试访问管理页面: {username}")
            handler.send_error(403, "Forbidden - Admin access required")
            return
        
        # 获取所有用户列表
        users_data = self.user_store.load_users()
        users_list = []
        
        for uname, udata in users_data.items():
            created_at = udata.get('created_at', '')
            is_admin = udata.get('is_admin', False)

            users_list.append({
                'username': uname,
                'created_at': _format_created_at(created_at),
                'is_admin': is_admin
            })
        
        # 按用户名排序
        users_list.sort(key=lambda x: x['username'])
        
        html = render_admin_page(username, users_list)
        handler._send_html_response(html)

    def handle_get_users(self, handler) -> None:
        """处理获取用户列表API请求（GET /api/admin/users）
        
        Args:
            handler: HTTP请求处理器实例
        """
        users_data = self.user_store.load_users()
        users_list = []
        
        for uname, udata in users_data.items():
            created_at = udata.get('created_at', '')

            users_list.append({
                'username': uname,
                'created_at': _format_created_at(created_at)
            })

        users_list.sort(key=lambda x: x['username'])
        handler._send_json_response({'success': True, 'users': users_list})

    def handle_create_user(self, handler) -> None:
        """处理创建用户API请求（POST /api/admin/users）
        
        Args:
            handler: HTTP请求处理器实例
        """
        # 检查是否为管理员
        username = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(username):
            logger.warning(f"非管理员尝试创建用户: {username}")
            handler._send_error_response('需要管理员权限', 403)
            return
        
        try:
            content_length = int(handler.headers.get('Content-Length', 0))
            body = handler.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))
            
            new_username = data.get('username', '').strip()
            password = data.get('password', '')
            is_admin = data.get('is_admin', False)
            
            # 验证参数
            if not new_username:
                handler._send_error_response('用户名不能为空')
                return
            
            if len(password) < MIN_PASSWORD_LENGTH:
                handler._send_error_response(f'密码长度至少为{MIN_PASSWORD_LENGTH}位')
                return
            
            # 检查用户是否已存在
            if self.user_store.user_exists(new_username):
                handler._send_error_response(f'用户 {new_username} 已存在')
                return
            
            # 创建用户
            password_hash = self.hasher.hash_password(password)
            self.user_store.add_user(new_username, password_hash, is_admin)
            
            logger.info(f"管理员创建用户: {new_username}, is_admin={is_admin}")
            handler._send_json_response({'success': True, 'message': '用户创建成功'})
            
        except json.JSONDecodeError:
            handler._send_error_response('无效的JSON数据')
        except Exception as e:
            logger.error(f"创建用户失败: {e}")
            handler._send_error_response('创建用户失败，请稍后重试')

    def handle_delete_user(self, handler, username: str) -> None:
        """处理删除用户API请求（DELETE /api/admin/users/{username}）
        
        Args:
            handler: HTTP请求处理器实例
            username: 要删除的用户名
        """
        # 检查是否为管理员
        current_user = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(current_user):
            logger.warning(f"非管理员尝试删除用户: {current_user}")
            handler._send_error_response('需要管理员权限', 403)
            return
        
        try:
            # 检查用户是否存在
            if not self.user_store.user_exists(username):
                handler._send_error_response(f'用户 {username} 不存在')
                return
            
            # 删除用户
            success = self.user_store.delete_user(username)
            
            if success:
                logger.info(f"管理员删除用户: {username}")
                handler._send_json_response({'success': True, 'message': '用户删除成功'})
            else:
                handler._send_error_response('删除失败')
                
        except Exception as e:
            logger.error(f"删除用户失败: {e}")
            handler._send_error_response('删除用户失败，请稍后重试')

    def handle_change_password(self, handler, username: str) -> None:
        """处理修改密码API请求（PUT /api/admin/users/{username}/password）
        
        Args:
            handler: HTTP请求处理器实例
            username: 要修改密码的用户名
        """
        # 检查是否为管理员
        current_user = handler.get_current_username() or 'Unknown'
        if not self.user_store.is_admin(current_user):
            logger.warning(f"非管理员尝试修改密码: {current_user}")
            handler._send_error_response('需要管理员权限', 403)
            return
        
        try:
            content_length = int(handler.headers.get('Content-Length', 0))
            body = handler.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))
            
            new_password = data.get('new_password', '')
            
            # 验证参数
            if len(new_password) < MIN_PASSWORD_LENGTH:
                handler._send_error_response(f'密码长度至少为{MIN_PASSWORD_LENGTH}位')
                return
            
            # 检查用户是否存在
            if not self.user_store.user_exists(username):
                handler._send_error_response(f'用户 {username} 不存在')
                return
            
            # 更新密码
            password_hash = self.hasher.hash_password(new_password)
            self.user_store.update_password(username, password_hash)
            
            logger.info(f"管理员修改用户密码: {username}")
            handler._send_json_response({'success': True, 'message': '密码修改成功'})
            
        except json.JSONDecodeError:
            handler._send_error_response('无效的JSON数据')
        except Exception as e:
            logger.error(f"修改密码失败: {e}")
            handler._send_error_response('修改密码失败，请稍后重试')
