"""分享功能 Mixin"""
import json
import logging
import os
import time
import urllib.parse
import zipfile
from pathlib import Path

from .utils import _resolve_safe_path

logger = logging.getLogger(__name__)


class ShareMixin:
    """分享功能方法（创建、删除、更新、访问、下载分享链接）"""

    config = None
    session_manager = None
    user_store = None
    share_manager = None

    def _handle_create_share(self) -> None:
        """处理创建分享链接"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        if not self.share_manager:
            self._send_error_response('分享功能未启用')
            return

        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))

            file_path = data.get('file_path', '').strip()
            password = data.get('password')
            expires_in = data.get('expires_in')
            max_downloads = data.get('max_downloads')

            if not file_path:
                self._send_error_response('缺少文件路径')
                return

            file_path = file_path.lstrip('/')

            resolved = _resolve_safe_path(Path(self.directory), file_path)
            if not resolved or not resolved.exists():
                self._send_error_response('文件不存在')
                return

            share_info = self.share_manager.create_share(
                file_path=file_path,
                password=password,
                expires_in=expires_in,
                max_downloads=max_downloads,
                created_by=username,
            )

            logger.info(f"创建分享 - 用户: {username}, 文件: {file_path}, 分享ID: {share_info['share_id']}")
            self._send_json_response({'success': True, 'share': share_info})
        except Exception as e:
            logger.error(f"创建分享失败 - 用户: {username}, 错误: {e}")
            self._send_error_response('创建分享失败，请稍后重试')

    def _handle_delete_share(self) -> None:
        """处理删除分享链接"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        if not self.share_manager:
            self._send_error_response('分享功能未启用')
            return

        share_id = self.path[len('/api/share/delete/'):].lstrip('/')
        if self.share_manager.delete_share(share_id):
            self._send_json_response({'success': True})
        else:
            self._send_error_response('分享链接不存在或已删除')

    def _handle_update_share(self) -> None:
        """处理更新分享（修改过期时间等）"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        if not self.share_manager:
            self._send_error_response('分享功能未启用')
            return

        share_id = self.path[len('/api/share/update/'):].lstrip('/')
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))

            expires_in = data.get('expires_in')
            max_downloads = data.get('max_downloads')

            updates = {}
            if expires_in is not None:
                expires_in_val = int(expires_in)
                updates['expires_at'] = time.time() + expires_in_val if expires_in_val > 0 else None
            if max_downloads is not None:
                updates['max_downloads'] = int(max_downloads) if int(max_downloads) > 0 else None

            if not updates:
                self._send_error_response('没有需要更新的字段')
                return

            if self.share_manager.update_share(share_id, updates):
                logger.info(f"更新分享 - 用户: {username}, ID: {share_id}")
                self._send_json_response({'success': True})
            else:
                self._send_error_response('分享不存在、已过期或已删除')
        except Exception as e:
            logger.error(f"更新分享失败 - 用户: {username}, 错误: {e}")
            self._send_error_response('更新分享失败，请稍后重试')

    def _handle_permanent_delete_share(self) -> None:
        """处理永久删除分享（仅限已软删除的）"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self._send_error_response('未认证', 403)
            return

        if not self.share_manager:
            self._send_error_response('分享功能未启用')
            return

        share_id = self.path[len('/api/share/permanent-delete/'):].lstrip('/')
        if self.share_manager.permanent_delete_share(share_id):
            logger.info(f"永久删除分享 - 用户: {username}, ID: {share_id}")
            self._send_json_response({'success': True})
        else:
            self._send_error_response('分享不存在或未被删除')

    def _handle_share_access(self) -> None:
        """处理分享链接访问"""
        from ..template import render_share_access_page

        share_id = ''
        password = None

        if self.command == 'POST':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length).decode('utf-8')
            params = urllib.parse.parse_qs(post_data)
            share_id = params.get('share_id', [''])[0]
            password = params.get('password', [''])[0] or None
            logger.info(f"分享访问 POST - share_id: {share_id}, has_password: {bool(password)}")
        else:
            if self.path.startswith('/share/access/'):
                share_id = self.path[len('/share/access/'):].lstrip('/')
                if '?' in share_id:
                    share_id, query = share_id.split('?', 1)
                    params = urllib.parse.parse_qs(query)
                    password = params.get('password', [''])[0] or None
                logger.info(f"分享访问 GET - share_id: {share_id}, has_password: {bool(password)}")

        if not share_id:
            logger.error("分享访问失败 - share_id 为空")
            self.send_error(400, "Invalid share link")
            return

        if not self.share_manager:
            self.send_error(404, "Share not available")
            return

        share = self.share_manager.get_share(share_id)
        if not share:
            logger.warning(f"分享链接不存在或已过期 - share_id: {share_id}")
            html = render_share_access_page('未知文件', False, '分享链接不存在或已过期', False)
            self._send_html_response(html)
            return

        # GET请求：始终显示密码输入页面
        if self.command == 'GET':
            logger.info(f"分享访问 GET - 显示密码输入页 - share_id: {share_id}")
            file_path_check = Path(self.directory) / share['file_path']
            is_folder = file_path_check.is_dir() if file_path_check.exists() else False
            has_password = bool(share.get('has_password', False))

            html = render_share_access_page(
                os.path.basename(share['file_path']),
                has_password,
                '',
                is_folder
            )
            safe_share_id = share_id.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')
            hidden_input = f'<input type="hidden" name="share_id" value="{safe_share_id}">'
            html = html.replace('<form method="POST" action="">',
                               f'<form method="POST" action="">{hidden_input}')
            self._send_html_response(html)
            return

        # POST请求：验证密码并下载
        logger.info(f"分享访问 POST - 尝试验证 - share_id: {share_id}")

        valid, result = self.share_manager.validate_access(share_id, password)
        if not valid:
            logger.warning(f"分享验证失败 - share_id: {share_id}, 原因: {result}")
            file_path_check = Path(self.directory) / share['file_path']
            is_folder = file_path_check.is_dir() if file_path_check.exists() else False
            html = render_share_access_page(
                os.path.basename(share['file_path']),
                bool(share.get('has_password', False)),
                result,
                is_folder
            )
            safe_share_id = share_id.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')
            hidden_input = f'<input type="hidden" name="share_id" value="{safe_share_id}">'
            html = html.replace('<form method="POST" action="">',
                               f'<form method="POST" action="">{hidden_input}')
            self._send_html_response(html)
            return

        # Access granted - 直接下载文件（ZIP格式）
        logger.info(f"分享访问成功 - share_id: {share_id}, 文件: {share['file_path']}")
        file_path_rel = share['file_path']

        share_root = Path(self.directory) / file_path_rel

        if not share_root.exists():
            logger.error(f"分享文件不存在 - 文件路径: {share_root}")
            html = render_share_access_page(
                os.path.basename(file_path_rel),
                False, '文件已被删除',
                False
            )
            self._send_html_response(html)
            return

        self.share_manager.record_download(share_id)

        if share_root.is_file():
            file_size = share_root.stat().st_size
            encoded_filename = urllib.parse.quote(share_root.name)

            logger.info(f"分享文件下载 - 文件名: {share_root.name}, 大小: {file_size}")
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Disposition', f"attachment; filename*=UTF-8''{encoded_filename}")
            self.send_header('Content-Length', str(file_size))
            self.end_headers()

            with open(share_root, 'rb') as f:
                self.copyfile(f, self.wfile)
        else:
            self._zip_and_send_directory(share_root)

    def _handle_share_download(self) -> None:
        """处理分享文件下载（直接下载链接）"""
        share_id = self.path[len('/share/download/'):].lstrip('/')
        if not self.share_manager:
            self.send_error(404, "Not found")
            return

        share = self.share_manager.get_share(share_id)
        if not share:
            self.send_error(404, "Share not found or expired")
            return

        file_path = Path(self.directory) / share['file_path']
        if not file_path.exists():
            self.send_error(404, "File not found")
            return

        self.share_manager.record_download(share_id)

        if file_path.is_file():
            file_size = file_path.stat().st_size
            encoded_filename = urllib.parse.quote(file_path.name)

            logger.info(f"分享文件下载 - 文件名: {file_path.name}, 大小: {file_size}")
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Disposition', f"attachment; filename*=UTF-8''{encoded_filename}")
            self.send_header('Content-Length', str(file_size))
            self.end_headers()

            with open(file_path, 'rb') as f:
                self.copyfile(f, self.wfile)
        else:
            self._zip_and_send_directory(file_path)

    def _handle_share_file_download(self) -> None:
        """处理分享文件下载（详情页中的单个文件下载）"""
        parts = self.path[len('/share/file/'):].lstrip('/').split('/', 1)
        if len(parts) != 2:
            self.send_error(400, "Invalid path")
            return

        share_id = parts[0]
        file_path_rel = urllib.parse.unquote(parts[1])

        if not self.share_manager:
            self.send_error(404, "Share not available")
            return

        share = self.share_manager.get_share(share_id)
        if not share:
            self.send_error(404, "Share not found or expired")
            return

        share_root = Path(self.directory) / share['file_path']
        file_path = Path(self.directory) / file_path_rel

        try:
            share_root_resolved = share_root.resolve()
            file_path_resolved = file_path.resolve()

            if share_root_resolved.is_file():
                if file_path_resolved != share_root_resolved:
                    logger.warning(f"分享文件路径不匹配 - 期望: {share_root_resolved}, 实际: {file_path_resolved}")
                    self.send_error(403, "Forbidden - access denied")
                    return
            elif share_root_resolved.is_dir():
                if not str(file_path_resolved).startswith(str(share_root_resolved)):
                    logger.warning(f"分享路径越权 - 根目录: {share_root_resolved}, 请求: {file_path_resolved}")
                    self.send_error(403, "Forbidden - access denied")
                    return
        except Exception as e:
            logger.error(f"路径验证失败: {e}")
            self.send_error(403, "Forbidden - path validation error")
            return

        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "File not found")
            return

        self.share_manager.record_download(share_id)

        file_size = file_path.stat().st_size
        encoded_filename = urllib.parse.quote(file_path.name)
        content_disposition = f"attachment; filename*=UTF-8''{encoded_filename}"

        logger.info(f"分享文件下载 - 文件名: {file_path.name}, 大小: {file_size}")
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Disposition', content_disposition)
        self.send_header('Content-Length', str(file_size))
        self.end_headers()

        with open(file_path, 'rb') as f:
            self.copyfile(f, self.wfile)

    def _zip_and_send_directory(self, directory: Path) -> None:
        """将目录打包为 ZIP 并发送给客户端"""
        import tempfile
        tmp_fd, tmp_path = tempfile.mkstemp(suffix='.zip')
        os.close(tmp_fd)

        try:
            with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for root, dirs, files in os.walk(directory):
                    for f in files:
                        file_abs = Path(root) / f
                        arc_name = str(file_abs.relative_to(directory))
                        zf.write(file_abs, arc_name)

            zip_size = os.path.getsize(tmp_path)
            encoded_filename = urllib.parse.quote(directory.name + '.zip')

            logger.info(f"分享文件夹ZIP下载 - 名称: {directory.name}, 大小: {zip_size}")
            self.send_response(200)
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition', f"attachment; filename*=UTF-8''{encoded_filename}")
            self.send_header('Content-Length', str(zip_size))
            self.end_headers()

            with open(tmp_path, 'rb') as f:
                self.copyfile(f, self.wfile)
        finally:
            os.unlink(tmp_path)

    def _handle_share_list(self) -> None:
        """处理分享目录列表请求（AJAX）"""
        share_id = self.path[len('/share/list/'):].lstrip('/')

        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        sub_path = params.get('path', [''])[0]

        if not self.share_manager:
            self._send_json_response({'success': False, 'error': '分享功能不可用'}, 404)
            return

        share = self.share_manager.get_share(share_id)
        if not share:
            self._send_json_response({'success': False, 'error': '分享不存在或已过期'}, 404)
            return

        share_root = Path(self.directory) / share['file_path']
        if sub_path:
            target_path = share_root / sub_path
        else:
            target_path = share_root

        try:
            share_root_resolved = share_root.resolve()
            target_path_resolved = target_path.resolve()

            if share_root_resolved.is_file():
                self._send_json_response({'success': False, 'error': '分享的是文件，不支持目录浏览'}, 403)
                return

            if not str(target_path_resolved).startswith(str(share_root_resolved)):
                self._send_json_response({'success': False, 'error': '访问被拒绝'}, 403)
                return
        except Exception as e:
            logger.error(f"目录列表路径验证失败: {e}")
            self._send_json_response({'success': False, 'error': '路径验证失败'}, 403)
            return

        if not target_path.exists() or not target_path.is_dir():
            self._send_json_response({'success': False, 'error': '目录不存在'}, 404)
            return

        items = self._get_directory_items(target_path, str(target_path.relative_to(Path(self.directory))))
        self._send_json_response({'success': True, 'items': items})

    def _handle_share_management(self) -> None:
        """处理分享管理页面"""
        from ..template import render_share_management_page
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            self.send_error(403, "Forbidden")
            return

        if not self.share_manager:
            self._send_error_response('分享功能未启用')
            return

        shares = self.share_manager.list_shares()
        is_admin = False
        if self.user_store:
            is_admin = self.user_store.is_admin(username)
        html = render_share_management_page(username, shares, is_admin=is_admin)
        self._send_html_response(html)
