"""数据库模块 - PostgreSQL 支持"""
import logging
from typing import Dict, Optional, List

logger = logging.getLogger(__name__)

# 检查 PostgreSQL 支持
try:
    import psycopg2
    from psycopg2 import sql
    from psycopg2.extras import DictCursor
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False
    logger.warning("psycopg2-binary not installed. PostgreSQL support disabled.")


# SQL 建表语句
CREATE_TABLES_SQL = """
-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);

-- 分享表
CREATE TABLE IF NOT EXISTS shares (
    share_id VARCHAR(32) PRIMARY KEY,
    file_path TEXT NOT NULL,
    password_hash TEXT,
    expires_at DOUBLE PRECISION,
    max_downloads INTEGER,
    download_count INTEGER DEFAULT 0,
    created_at DOUBLE PRECISION NOT NULL,
    created_by VARCHAR(255),
    is_deleted BOOLEAN DEFAULT FALSE,
    deleted_at DOUBLE PRECISION
);
CREATE INDEX IF NOT EXISTS idx_shares_is_deleted ON shares(is_deleted);
"""


class DatabaseConnection:
    """数据库连接管理"""

    def __init__(self, host: str = "localhost", port: int = 5432,
                 database: str = "pyfileserv",
                 username: Optional[str] = None,
                 password: Optional[str] = None):
        if not POSTGRES_AVAILABLE:
            raise ImportError("psycopg2-binary is required for PostgreSQL support. "
                            "Install it with: pip install psycopg2-binary")

        self.host = host
        self.port = port
        self.database = database
        self.username = username
        self.password = password
        self._conn = None

    def connect(self) -> None:
        """连接数据库"""
        if self._conn is not None:
            return

        self._conn = psycopg2.connect(
            host=self.host,
            port=self.port,
            database=self.database,
            user=self.username,
            password=self.password
        )
        logger.info(f"Connected to PostgreSQL: {self.host}:{self.port}/{self.database}")

    def disconnect(self) -> None:
        """断开连接"""
        if self._conn is not None:
            self._conn.close()
            self._conn = None
            logger.info("Disconnected from PostgreSQL")

    def get_connection(self):
        """获取数据库连接"""
        if self._conn is None:
            self.connect()
        return self._conn

    def initialize_tables(self) -> None:
        """初始化数据库表"""
        conn = self.get_connection()
        with conn.cursor() as cur:
            cur.execute(CREATE_TABLES_SQL)
        conn.commit()
        logger.info("Database tables initialized")

    def execute(self, query: str, params: Optional[tuple] = None,
                fetch: bool = False) -> Optional[List[Dict]]:
        """执行 SQL 查询

        Args:
            query: SQL 查询语句
            params: 查询参数
            fetch: 是否返回结果

        Returns:
            查询结果列表（如果 fetch=True）
        """
        conn = self.get_connection()
        with conn.cursor(cursor_factory=DictCursor) as cur:
            cur.execute(query, params or ())
            if fetch:
                return [dict(row) for row in cur.fetchall()]
            conn.commit()
        return None

    def execute_one(self, query: str, params: Optional[tuple] = None) -> Optional[Dict]:
        """执行 SQL 查询并返回单条结果"""
        results = self.execute(query, params, fetch=True)
        return results[0] if results else None


class DatabaseUserStore:
    """基于 PostgreSQL 的用户存储"""

    def __init__(self, db: DatabaseConnection):
        self.db = db

    def load_users(self) -> Dict[str, Dict]:
        """加载所有用户"""
        rows = self.db.execute(
            "SELECT username, password_hash, is_admin, created_at, updated_at FROM users",
            fetch=True
        )
        users = {}
        for row in rows or []:
            users[row['username']] = {
                'password': row['password_hash'],
                'is_admin': row['is_admin'],
                'created_at': row['created_at'].isoformat() if row['created_at'] else None,
                'updated_at': row['updated_at'].isoformat() if row['updated_at'] else None,
            }
        return users

    def get_user(self, username: str) -> Optional[Dict]:
        """获取单个用户"""
        row = self.db.execute_one(
            "SELECT username, password_hash, is_admin, created_at, updated_at FROM users WHERE username = %s",
            (username,)
        )
        if row:
            return {
                'password': row['password_hash'],
                'is_admin': row['is_admin'],
                'created_at': row['created_at'].isoformat() if row['created_at'] else None,
                'updated_at': row['updated_at'].isoformat() if row['updated_at'] else None,
            }
        return None

    def user_exists(self, username: str) -> bool:
        """检查用户是否存在"""
        row = self.db.execute_one(
            "SELECT 1 FROM users WHERE username = %s",
            (username,)
        )
        return row is not None

    def add_user(self, username: str, password_hash: str, is_admin: bool = False) -> None:
        """添加用户
        
        Args:
            username: 用户名
            password_hash: 密码哈希
            is_admin: 是否为管理员，默认 False
        """
        self.db.execute(
            "INSERT INTO users (username, password_hash, is_admin) VALUES (%s, %s, %s)",
            (username, password_hash, is_admin)
        )

    def update_password(self, username: str, password_hash: str) -> None:
        """更新用户密码"""
        self.db.execute(
            "UPDATE users SET password_hash = %s, updated_at = CURRENT_TIMESTAMP WHERE username = %s",
            (password_hash, username)
        )

    def delete_user(self, username: str) -> None:
        """删除用户"""
        self.db.execute(
            "DELETE FROM users WHERE username = %s",
            (username,)
        )

    def set_admin_status(self, username: str, is_admin: bool) -> None:
        """设置用户管理员状态
        
        Args:
            username: 用户名
            is_admin: 是否为管理员
        """
        self.db.execute(
            "UPDATE users SET is_admin = %s, updated_at = CURRENT_TIMESTAMP WHERE username = %s",
            (is_admin, username)
        )

    def is_admin(self, username: str) -> bool:
        """检查用户是否为管理员

        Args:
            username: 用户名

        Returns:
            是否为管理员
        """
        user_data = self.get_user(username)
        if user_data:
            return user_data.get("is_admin", False)
        return False


class DatabaseShareStore:
    """基于 PostgreSQL 的分享数据存储"""

    def __init__(self, db: DatabaseConnection):
        self.db = db

    def create_share(self, share_id: str, share_data: dict) -> None:
        """创建分享记录"""
        self.db.execute(
            """INSERT INTO shares (share_id, file_path, password_hash, expires_at,
               max_downloads, download_count, created_at, created_by)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
            (share_id, share_data['file_path'], share_data.get('password_hash'),
             share_data.get('expires_at'), share_data.get('max_downloads'),
             share_data.get('download_count', 0), share_data['created_at'],
             share_data.get('created_by'))
        )

    def get_share(self, share_id: str) -> Optional[Dict]:
        """获取有效分享（非过期、非删除）"""
        import time
        now = time.time()
        row = self.db.execute_one(
            """SELECT * FROM shares WHERE share_id = %s
               AND is_deleted = FALSE
               AND (expires_at IS NULL OR expires_at > %s)""",
            (share_id, now)
        )
        if row:
            result = dict(row)
            result['share_id'] = share_id
            return result
        return None

    def get_share_any(self, share_id: str) -> Optional[Dict]:
        """获取任意状态分享（含过期/删除），用于检查存在性"""
        row = self.db.execute_one(
            "SELECT * FROM shares WHERE share_id = %s",
            (share_id,)
        )
        if row:
            result = dict(row)
            result['share_id'] = share_id
            return result
        return None

    def list_shares_for_management(self) -> List[Dict]:
        """列出所有分享（含过期和软删除），用于管理页面"""
        import time
        now = time.time()
        rows = self.db.execute(
            """SELECT * FROM shares ORDER BY created_at DESC""",
            fetch=True
        )
        shares = []
        for row in rows:
            s = dict(row)
            s['share_id'] = row['share_id']
            # 计算状态
            if s.get('is_deleted'):
                s['status'] = 'deleted'
            elif s.get('expires_at') and now > s['expires_at']:
                s['status'] = 'expired'
            else:
                s['status'] = 'active'
            # has_password 标志方便模板使用
            s['has_password'] = bool(s.get('password_hash'))
            shares.append(s)
        return shares

    def update_share(self, share_id: str, updates: dict) -> bool:
        """更新分享字段（仅允许 expires_at, max_downloads）"""
        allowed = {'expires_at', 'max_downloads'}
        filtered = {k: v for k, v in updates.items() if k in allowed}
        if not filtered:
            return False

        set_clause = ', '.join(f"{k} = %s" for k in filtered)
        values = list(filtered.values()) + [share_id]
        self.db.execute(
            f"UPDATE shares SET {set_clause} WHERE share_id = %s",
            tuple(values)
        )
        return True

    def soft_delete_share(self, share_id: str) -> bool:
        """软删除分享"""
        import time
        now = time.time()
        row = self.db.execute_one(
            "SELECT share_id FROM shares WHERE share_id = %s AND is_deleted = FALSE",
            (share_id,)
        )
        if not row:
            return False
        self.db.execute(
            "UPDATE shares SET is_deleted = TRUE, deleted_at = %s WHERE share_id = %s",
            (now, share_id)
        )
        return True

    def permanent_delete_share(self, share_id: str) -> bool:
        """永久删除分享"""
        row = self.db.execute_one(
            "SELECT share_id FROM shares WHERE share_id = %s AND is_deleted = TRUE",
            (share_id,)
        )
        if not row:
            return False
        self.db.execute("DELETE FROM shares WHERE share_id = %s", (share_id,))
        return True

    def record_download(self, share_id: str) -> None:
        """记录下载次数"""
        self.db.execute(
            "UPDATE shares SET download_count = download_count + 1 WHERE share_id = %s",
            (share_id,)
        )

    def get_file_shares(self, file_path: str) -> List[Dict]:
        """获取文件的所有分享链接（仅有效分享）"""
        import time
        now = time.time()
        rows = self.db.execute(
            """SELECT * FROM shares WHERE file_path = %s
               AND is_deleted = FALSE
               AND (expires_at IS NULL OR expires_at > %s)""",
            (file_path, now),
            fetch=True
        )
        return [dict(r) for r in (rows or [])]
