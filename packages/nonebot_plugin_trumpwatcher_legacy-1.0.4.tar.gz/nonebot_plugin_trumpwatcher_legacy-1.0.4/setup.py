from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="nonebot-plugin-trumpwatcher-legacy",
    version="1.0.4",
    author="BG4JEC",
    author_email="BG4JEC@hotmail.com",
    description="监控特朗普 Truth Social 动态并推送到订阅群",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/2580m/nonebot-plugin-trumpwatcher",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Framework :: Robot Framework :: Library",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.10",
    install_requires=[
        "nonebot2>=2.4.0",
        "nonebot-adapter-onebot>=2.4.0",
        "nonebot-plugin-orm>=0.8.0",
        "nonebot-plugin-apscheduler>=0.4.0",
        "httpx>=0.27.0",
    ],
    entry_points={
        "nonebot.plugin": [
            "nonebot-plugin-trumpwatcher-legacy = nonebot_plugin_trumpwatcher",
        ],
    },
)
