# Changelog

All notable changes to `rageval-ai` are documented here. The format is based on
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project follows
[Semantic Versioning](https://semver.org/spec/v2.0.0.html) once it reaches 1.0.

## [0.2.4] — 2026-05-23

### Added
- "Open in HF Spaces" badge in the README pointing at the live
  interactive demo at https://huggingface.co/spaces/seali/rageval-ai.
  The demo is a chat-based RAG flow over a small built-in knowledge
  base, with `evaluate()` running on every turn so visitors can see
  the metric breakdown without writing any code.

### Fixed
- Missing `h2` runtime dependency. The shared `httpx.AsyncClient` is
  instantiated with `http2=True` (`_llm_client.py`), but `h2` was not
  declared as an install requirement. Calls to `evaluate()` crashed with
  `Using http2=True, but the 'h2' package is not installed.` for anyone
  who installed `rageval-ai` from PyPI. Dependency tightened to
  `httpx[http2]>=0.24.0` so the extra is pulled in on install.

### Changed
- Roadmap: dropped "HuggingFace Space demo" from the v0.4 line — it's
  shipped.

## [0.2.3] — 2026-05-22

### Added
- Comparison table vs Ragas / DeepEval / TruLens in the README.
- `examples/` directory with LangChain, LlamaIndex and OpenRouter samples.
- Expanded PyPI keywords (LlamaIndex, OpenRouter, Azure, Anthropic, …).
- Additional project URLs (Documentation, Changelog, Examples, Source).
- Author and maintainer metadata in `pyproject.toml`.

### Changed
- README rewritten with a clearer "Why rageval-ai?" intro and badges
  (PyPI version, downloads, Python versions, license, stars).

## [0.2.2] — 2026-04-XX

### Added
- LangChain `RagEvalCallback` lazy import.
- Server-mode `RagEvalClient` with webhook support.
- Background `RagEvaluator` with worker pool.

## [0.2.1] — 2026-04-XX

### Added
- Two-stage judge (cheap + strong model) pipeline.
- Custom `EvalConfig` for OpenRouter / Azure / self-hosted endpoints.

## [0.1.1] — 2026-04-XX

### Added
- Initial public release on PyPI.
- `evaluate()`, `evaluate_batch()`, `evaluate_trace()` API.
- Faithfulness, hallucination, answer relevancy, context precision/recall metrics.
