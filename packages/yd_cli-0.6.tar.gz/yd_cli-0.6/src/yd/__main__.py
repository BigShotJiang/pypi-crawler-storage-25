# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""CLI entry point."""

from __future__ import annotations

if __name__ == "__main__":
    from yd import cli

    cli.app()
