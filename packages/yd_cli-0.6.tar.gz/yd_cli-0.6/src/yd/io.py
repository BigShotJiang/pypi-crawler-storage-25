# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""Data I/O."""

from __future__ import annotations

import datetime as dt
import logging
import os
import re
import shutil
from pathlib import Path

import msgspec

from yd import types

TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import Iterable
    from typing import Literal, overload

    @overload
    def _find_binary(binary: str, /) -> str: ...
    @overload
    def _find_binary(binary: str, /, accept_failure: Literal[True]) -> str | None: ...


log = logging.getLogger(__name__)

__all__ = [
    "capture_environment",
    "load_command_group",
    "list_available_configs",
    "decode_from_stdout",
    "decode_from_stderr",
    "encode_error",
]


def _getenv[T](env_var: str, /, default: T) -> T:
    if (v := os.getenv(env_var)) is None:
        return default
    return type(default)(v)


def _find_binary(binary: str, /, accept_failure: bool = False) -> str | None:
    if (abs_path := shutil.which(binary)) is None:
        if accept_failure:
            return None
        raise FileNotFoundError(f"executable '{binary}' not found")
    return abs_path


# Public function intentionally raise a single error type to avoid convoluting the
# interface code with verbose error handling that serves no purpose except error
# message creation.


def capture_environment() -> types.Environment:
    """Capture environment.

    Raises `types.ConfigLoadError` in case of failure.
    """
    home_dir = Path.home()
    if not home_dir.exists():
        raise types.EnvCaptureError(f"home dir `{home_dir}` does not exist")
    if not home_dir.is_dir():
        raise types.EnvCaptureError(
            f"home dir `{home_dir}` exists but is not a directory"
        )

    config_dir = Path(os.getenv("XDG_CONFIG_HOME", ".config"), "yd")
    if not config_dir.is_absolute():
        config_dir = home_dir / config_dir
    config_dir = config_dir.resolve()
    if config_dir.exists() and not config_dir.is_dir():
        raise types.EnvCaptureError(
            f"config dir `{config_dir}` exists but is not a directory"
        )
    config_dir.mkdir(exist_ok=True, parents=True)

    try:
        rsync_bin = _find_binary(_getenv("YD_RSYNC", "rsync"))
    except FileNotFoundError as err:
        raise types.EnvCaptureError("rsync binary not found") from err
    try:
        echo_bin = _find_binary(_getenv("YD_ECHO", "echo"))
    except FileNotFoundError as err:
        raise types.EnvCaptureError("echo binary not found") from err
    editor_bin = _find_binary(_getenv("EDITOR", "vim"), accept_failure=True)

    try:
        log_level: int | None = int(os.getenv("YD_LOGLEVEL", ""))
    except ValueError:
        log_level = None

    return types.Environment(
        current_time=dt.datetime.now(),
        log_level=log_level,
        home_dir=home_dir,
        config_dir=config_dir,
        rsync_bin=rsync_bin,
        echo_bin=echo_bin,
        editor_bin=editor_bin,
    )


def load_command_group(path: Path, /) -> types.CommandGroup:
    """Load command group from file.

    Parameters
    ----------
    path
        Path to TOML file specifying the program.
    """
    try:
        with path.open(mode="rb") as fh:
            return msgspec.toml.decode(fh.read(), type=types.CommandGroup)
    except FileNotFoundError as err:
        log.exception("missing configuration file `%s`", path)
        raise types.ConfigLoadError(
            f"configuration file `{path}` does not exist"
        ) from err
    except (PermissionError, OSError) as err:
        log.exception("system-level read failure file `%s`", path)
        raise types.ConfigLoadError(
            f"failed to read file `{path}` (permission or OS issue)"
        ) from err
    except msgspec.DecodeError as err:
        log.exception("TOML decoding error `%s`", path)
        raise types.ConfigLoadError(f"invalid TOML syntax in file {path}") from err
    except msgspec.ValidationError as err:
        log.exception("invalid configuration in file `%s`", path)
        raise types.ConfigLoadError(f"configuration in `{path}` is invalid") from err


def list_available_configs(config_dir: Path, /) -> Iterable[types.AvailableConfig]:
    for path in sorted(config_dir.glob("*.toml")):
        if not path.is_file():
            continue
        try:
            with path.open(encoding="utf-8") as fh:
                # Benchmarked variants using one or more of `itertools.takewhile` and
                # `yield` but this had best runtime.
                lines = []
                for line in fh:
                    if not line.startswith("#"):
                        break
                    lines.append(line.removeprefix("#").rstrip())
        except (PermissionError, OSError) as err:
            log.exception("system-level read failure file `%s`", path)
            raise types.ConfigLoadError(
                f"failed to read file `{path}` (permission or OS issue)"
            ) from err

        if lines:
            yield types.AvailableConfig(name=path.stem, description="\n".join(lines))
        else:
            yield types.AvailableConfig(name=path.stem, description=None)


_STDOUT_PATTERNS = (
    (
        re.compile(r"created\s1\sdirectory\sfor\s(?P<filepath>.+?)"),
        lambda m: types.Transaction(
            filename=m.group("filepath"), transfer_bytes=0, info="c          "
        ),
    ),
    (re.compile(r"created\sdirectory\s.+"), lambda _: None),
    (
        re.compile(r"cannot\sdelete\snon-empty\sdirectory:\s+(?P<filepath>.*?)"),
        lambda m: f"Kept non-empty directory {m.group('filepath')}",
    ),
)
_decode_transaction = msgspec.json.Decoder(types.Transaction).decode


def decode_from_stdout(text: str, /) -> types.Transaction | str | None:
    if not (stripped_text := text.strip()):
        return None
    for pattern, act in _STDOUT_PATTERNS:
        if (m := pattern.fullmatch(stripped_text)) is not None:
            return act(m)
    try:
        return _decode_transaction(stripped_text)
    except msgspec.DecodeError:
        log.exception("unexpected format on stdout: `%s`", stripped_text)
        return stripped_text
    except msgspec.ValidationError:
        log.exception("invalid content on stdout: `%s`", stripped_text)
        return stripped_text


def decode_from_stderr(text: str, /) -> types.Transaction | str | None:
    if not (stripped_text := text.strip()):
        return None
    return stripped_text


def encode_error(text: str, /) -> str:
    return text
