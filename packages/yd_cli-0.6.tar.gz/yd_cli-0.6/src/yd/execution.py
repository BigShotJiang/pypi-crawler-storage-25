# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""Command execution."""

from __future__ import annotations

import asyncio
import contextlib
import logging

from yd import types

TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, Callable, Coroutine
    from typing import Any

    type Parser[T] = Callable[[str], T]
    type Consumer[T] = Callable[[T], Coroutine[Any, Any, None]]

log = logging.getLogger(__name__)

__all__ = ["run"]


async def _consume_stream[T](
    stream: asyncio.StreamReader,
    parser: Parser[T],
    *,
    queue: asyncio.Queue[T],
) -> None:
    try:
        while not stream.at_eof():
            line_bytes = await stream.readline()
            if not line_bytes:
                # Happens only at EOF as linebreaks are included.
                break

            try:
                line = line_bytes.decode("utf-8", errors="replace")
            except UnicodeDecodeError:
                log.exception("UTF-8 decoding error")
                continue

            log.debug("captured line: `%s`.", line)

            try:
                parsed_value = parser(line)
            except Exception as err:
                log.exception("parsing error for line `%s`", line)
                raise types.OutputParseError(
                    "got unexpected input by another process"
                ) from err

            log.debug("extracted `%s` from `%s`", parsed_value, line)

            if parsed_value is not None:
                await queue.put(parsed_value)
    except asyncio.CancelledError:
        log.exception("stream consumption cancelled")
        raise


# https://github.com/mikeshardmind/async-utils/blob/main/src/async_utils/_merge_gens.py
# provides an elegant queue-free solution (`_consume_stream` would need to be
# AsyncGenerators to use it).
async def _zip_streams[T](
    *streams_and_parsers: tuple[asyncio.StreamReader | None, Parser[T]],
) -> AsyncGenerator[T]:
    active_streams = [
        (stream, parser)
        for (stream, parser) in streams_and_parsers
        if stream is not None
    ]
    if not active_streams:
        return

    # None signals end of stream.
    queue: asyncio.Queue[T] = asyncio.Queue()
    consumers = set()
    try:
        async with asyncio.TaskGroup() as tg:
            for stream, parser in active_streams:
                con = tg.create_task(
                    _consume_stream(stream, parser, queue=queue),
                    name=f"consuming-{stream}",
                )
                consumers.add(con)
            # Use of shutdown mechanism taken from
            # https://discuss.python.org/t/asyncio-how-to-merge-two-streams/106616/2
            all_done = tg.create_task(
                asyncio.wait(consumers, return_when=asyncio.ALL_COMPLETED),
                name="queue-shutdown",
            )
            all_done.add_done_callback(lambda _: queue.shutdown())

            with contextlib.suppress(asyncio.QueueShutDown):
                while True:
                    try:
                        yield await queue.get()
                    except TimeoutError:
                        continue
    except* types.OutputParseError as err_gr:
        raise types.OutputParseError(
            "\n".join(str(err) for err in err_gr.exceptions)
        ) from err_gr


# The binary/args separation ensures at least one command components (opposed to *cmd).
async def run[T](
    binary: str,
    *args: str,
    parser_stdout: Parser[T],
    parser_stderr: Parser[T],
    consumer: Consumer[T],
) -> int:
    proc: asyncio.subprocess.Process | None = None
    try:
        proc = await asyncio.create_subprocess_exec(
            binary,
            *args,
            # Explicitly closing stdin.
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        async for out in _zip_streams(
            (proc.stdout, parser_stdout), (proc.stderr, parser_stderr)
        ):
            try:
                await consumer(out)
            except Exception as err:
                log.exception("output consumption failure of `%s`", out)
                raise types.OutputConsumeError(
                    "failed to consume parsed output"
                ) from err

        await proc.communicate()

        assert proc.returncode is not None, "unterminated process detected"
        return proc.returncode
    except asyncio.CancelledError:
        if proc is not None:
            proc.kill()
        raise
    except Exception:
        if proc is not None:
            proc.kill()
        cmd = " ".join((binary, *args))
        log.exception("exception occurred for `%s`", cmd)
        raise
