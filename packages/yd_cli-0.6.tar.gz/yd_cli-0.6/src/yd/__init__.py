# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""The yd synchronization tool.

Do not directly import items from this module (e.g. `from yd import io`) which
triggers `__getattr__` and thereby eager importing of the module. Instead, import
`yd` and use attribute access.
"""

from __future__ import annotations

import importlib
import importlib.metadata

TYPE_CHECKING = False
if TYPE_CHECKING:
    from types import ModuleType

    from yd import commands, execution, io, types
else:

    def __getattr__(key: str, /) -> ModuleType:
        if key in __all__:
            return importlib.import_module(f"{__package__}.{key}", package=__package__)
        raise AttributeError(f"module `{__name__}` has not attribute `{key}`")


__version__ = importlib.metadata.version("yd-cli")
__all__ = ["__version__", "commands", "io", "execution", "types"]
