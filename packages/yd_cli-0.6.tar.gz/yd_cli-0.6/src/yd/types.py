# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""Shared data structures."""

from __future__ import annotations

import dataclasses
import enum
from typing import TYPE_CHECKING, Annotated

import msgspec

if TYPE_CHECKING:
    import datetime as dt
    from pathlib import Path


class SyfError(RuntimeError): ...


class ConfigLoadError(SyfError):
    """Exception raised when loading a configuration fails."""


class EnvCaptureError(SyfError):
    """Exception raised when capturing the environment fails."""


class CommandBuildError(SyfError):
    """Exception raised when building the rsync command fails."""


class OutputParseError(SyfError):
    """Exception raised when parsing output of other CLI apps fails."""


class OutputConsumeError(SyfError):
    """Exception raised when the consumption of parsed output fails."""


@dataclasses.dataclass(slots=True, kw_only=True)
class Environment:
    current_time: dt.datetime
    log_level: int | None

    home_dir: Path
    config_dir: Path

    rsync_bin: str
    echo_bin: str
    editor_bin: str | None


@dataclasses.dataclass(slots=True, frozen=True)
class AvailableConfig:
    name: str
    description: str | None


type _NonemptyStr = Annotated[str, msgspec.Meta(min_length=1)]


# Does not explicitly omit default values as not used for serialization.
class CommandGroup(msgspec.Struct, kw_only=True, forbid_unknown_fields=True):
    """Configuration for a group of rsync commands.

    Parameters
    ----------
    src_home/target_home
        Absolute path used to turn relative src/target path in individual commands into
        absolute paths.

        The `target_home` is passed to `datetime.strftime` via the `format` parameter,
        that is, placeholders for date/time components like `%Y`, `%m`, etc., are
        replaced with the actual values at runtime.
    mtp_target
        Set True if communication with the target works with MTP. Due to
        technical limitations of that protocol, synchronization needs to be done
        in-place (rather than copying to a temporary file and renaming once
        done). This may lead to corrupted files if the process is interrupted;
        don't set unless necessary.
    backup
        Path to backup directory. Added to each command and if relative, then taken
        as relative to target home. If None, a default relative path is used.

        The `target` is passed to `datetime.strftime` via the `format` parameter, that
        is, placeholders for date/time components like `%Y`, `%m`, etc., are replaced
        with the actual values at runtime.
    exclude
        Exclude pattern joined to each command's individual exclude patterns.

        Patterns are matched against every file/directory to be transferred.
        - If not `/` or `**` is included in the pattern, then matches against full path.
        - Otherwise matches against filename.
        - Trailing `/` only matches directories.
        - `*` matches any number of non-`/` characters; `**` any number of any chars.
        - If pattern starts with `/` it's anchored at the start of the path.
        - `?` matches a single character; `[123]` matches one of 1, 2, or 3.
    """

    src_home: _NonemptyStr | None = None
    target_home: _NonemptyStr | None = None

    mtp_target: bool = False
    backup: _NonemptyStr | None = None
    exclude: list[_NonemptyStr] = msgspec.field(default_factory=list)

    commands: Annotated[list[Command], msgspec.Meta(min_length=1)]


class Command(msgspec.Struct, kw_only=True, forbid_unknown_fields=True):
    """Individual rsync command specification.

    Parameters
    ----------
    src, target
        Source/target directory. Required to be relative (to src_home/target_home) path.

        The `target` is passed to `datetime.strftime` via the `format` parameter, that
        is, placeholders for date/time components like `%Y`, `%m`, etc., are replaced
        with the actual values at runtime.
    delete_extra
        If `True`, then elements present in `target` but not `src` are deleted.
    exclude
        Patterns describing contents of `src` which is not transferred.
        Will be joined with settings in the containing `CommandGroup` object.
    """

    src: _NonemptyStr
    target: _NonemptyStr | None = None

    delete_extra: bool = True
    exclude: list[_NonemptyStr] = msgspec.field(default_factory=list)


class Action(enum.StrEnum):
    DELETE = "*"
    CREATE = "c"
    COPY = ">"
    ATTRUPDATE = "."
    HARDLINK = "h"

    def __str__(self) -> str:
        return self.name.lower()


class Transaction(msgspec.Struct):
    filename: str
    transfer_bytes: int
    info: Annotated[
        # The first character alternative match the non-`*`-options in `Action`.
        str, msgspec.Meta(min_length=11, max_length=11, pattern=r"^(\*|c|>|h|\.)")
    ]

    # Custom `dec_hook` requires an obj type unknown to msgspec to be triggered.
    @property
    def action(self) -> Action:
        return Action(self.info[0])
