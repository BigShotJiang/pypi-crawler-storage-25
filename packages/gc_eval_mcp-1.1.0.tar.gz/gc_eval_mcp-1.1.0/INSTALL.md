# GC-Eval MCP — Install Guide for Teams

> **Get BizChat Gov Cloud quality evaluation data directly in your Copilot CLI sessions.**
> No repo access needed. No cloning. Works from any project folder.
> Requires a Microsoft corporate account (Entra ID / AAD).

---

## ⚡ Quick Setup (~2 minutes)

### Step 1: Install from PyPI

```bash
pip install gc-eval-mcp
```

---

### Step 2: Sign in to Azure (one-time)

The data is hosted in Azure Blob Storage and requires Microsoft Entra ID authentication:

```bash
az login
```

> This uses your @microsoft.com account. If you're already signed in via VS Code or Azure CLI, you're good — no extra step needed.

---

### Step 3: Add to your project's MCP configuration

Create or edit `.copilot/mcp.json` in your repository root:

```json
{
  "mcpServers": {
    "GC-Eval": {
      "command": "gc-eval-mcp"
    }
  }
}
```

Commit this file so your whole team gets the MCP automatically.

---

### Step 4: Restart Copilot CLI

That's it. The GC-Eval tools are now available in every Copilot CLI session within your repo.

---

## 🔧 Verify It Works

In Copilot CLI, ask:

> "What's the status of the GC-Eval server?"

Or:

> "List all Gov Cloud quality metrics"

You should see the 23 scorecard metrics with their certification levels.

---

## 🛠️ Available Tools (auto-registered)

| Tool | What it does |
|------|-------------|
| `list_metrics` | Lists all 23 scorecard metrics with certification level (L1/L2/L3) |
| `get_metrics_report(item_id)` | Full HTML research report for a specific metric |
| `get_metrics_certification(item_id)` | Certification details for a metric |
| `search_metrics(query)` | Search metrics by name or metadata |
| `get_scorecard` | The Gov Cloud Minimal Scorecard document |
| `get_baseline_scorecard` | Baseline Quality Scorecard one-pager |
| `get_gated_metrics` | FR Gated Metrics Reference (hard gates & thresholds) |
| `get_certifications` | Full certifications JSON for all metrics |
| `query_certifications(key_path)` | Query certifications by dot-path (e.g., `sydney-reliability.enterprise_grounded`) |
| `get_status` | Server health, manifest version, cache info |
| `list_datasets` | All available datasets |
| `refresh_cache` | Force re-fetch of latest data |

---

## 💬 Example Prompts

Just ask naturally in Copilot CLI:

| What you want | What to ask |
|---|---|
| Check all metrics | "What's the certification status of our Gov Cloud metrics?" |
| Deep dive on a metric | "Show me the research report for sydney-reliability" |
| Find thresholds | "What are the hard gate thresholds for our gated metrics?" |
| Compare metrics | "Which metrics have EQS scores below 95?" |
| Check scorecard | "Give me a summary of the Gov Cloud scorecard" |

---

## ⚙️ Optional Configuration

The server works with zero configuration (uses the default storage account). Override if needed:

| Environment Variable | Default | Description |
|---|---|---|
| `GC_EVAL_STORAGE_ACCOUNT` | `gcevalmcpdata` | Azure Storage account name |
| `GC_EVAL_CONTAINER` | `eval-data` | Blob container name |
| `GC_EVAL_MANIFEST_BLOB` | `manifest.json` | Path to manifest within container |
| `GC_EVAL_CACHE_DIR` | `~/.cache/gc-eval-mcp` | Local cache location |
| `GC_EVAL_CACHE_TTL` | `3600` (1 hour) | How often to refresh data |

Set these in your `.copilot/mcp.json` if needed:

```json
{
  "mcpServers": {
    "GC-Eval": {
      "command": "gc-eval-mcp",
      "env": {
        "GC_EVAL_CACHE_TTL": "1800"
      }
    }
  }
}
```

---

## 📋 Requirements

- Python 3.10+
- `pip` (any recent version)
- Copilot CLI (with MCP support)
- Microsoft corporate account (Entra ID) — sign in via `az login`

---

## 🔄 Staying Up-to-Date

**Data updates are automatic.** The MCP server fetches the latest quality data from our hosted endpoint at runtime (cached for 1 hour). When new metrics or reports are added, you see them automatically — no reinstall needed.

**Server updates** (rare — only when new data-type support is added):
```bash
pip install --upgrade gc-eval-mcp
```

---

## ❓ Troubleshooting

| Issue | Fix |
|---|---|
| Tools not appearing | Restart Copilot CLI after editing `mcp.json` |
| "DefaultAzureCredential failed" | Run `az login` with your @microsoft.com account |
| Stale data | Ask: "refresh the GC-Eval cache" |
| Server not starting | Run `gc-eval-mcp` in terminal to see error output |
| Package not found | Ensure Python 3.10+ and pip are on your PATH |

---

## 📬 Questions?

- **PyPI package:** [https://pypi.org/project/gc-eval-mcp/](https://pypi.org/project/gc-eval-mcp/)
- **Issues / feedback:** Reach out to the BizChat Quality in RE team
