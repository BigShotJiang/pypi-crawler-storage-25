# GC-Eval MCP — Quality Evals at Your Fingertips

**What:** A local MCP server that gives any Copilot CLI agent instant access to our Gov Cloud quality evaluation data — metrics, reports, scorecard, certifications — without needing to be in the `quality-through-evals` folder.

---

## 🚀 Setup (one-time, ~2 minutes)

**1. Install dependency:**

```bash
pip install "mcp>=1.0.0"
```

**2. Add to your project's `.copilot/mcp.json`** (create the file if it doesn't exist):

```json
{
  "mcpServers": {
    "GC-Eval": {
      "command": "python",
      "args": ["C:\\Users\\vasanthv\\OneDrive - Microsoft\\MSRepos\\Bizchat Quality in RE\\Bizchat-quality-Restricted-Environments\\quality-through-evals\\mcp-server\\server.py"]
    }
  }
}
```

> ⚠️ Adjust the path to match where you cloned the repo on your machine.

**3. Restart Copilot CLI.** The `GC-Eval` tools will now appear automatically.

---

## 🛠️ Available Tools

| Tool | What it does |
|------|-------------|
| `list_metrics` | Lists all 23 scorecard metrics with certification level, EQS score, and owner |
| `get_metric_report(metric_id)` | Returns the full HTML research report for a metric |
| `get_metric_certification(metric_id)` | Shows L1/L2/L3 certification details for a metric |
| `get_scorecard` | Returns the full Gov Cloud Scorecard markdown |
| `get_document(name)` | Reads any doc from the docs/ folder |
| `search(query)` | Full-text search across docs, scripts, and reports |
| `list_files(directory)` | Browse the project file tree |
| `get_file(path)` | Read any file by relative path |

---

## 💬 Example Prompts (just ask naturally)

**Check metric status:**

> "What's the certification status of all our metrics?"
>
> → Agent calls `list_metrics` and summarizes the 23 metrics with their L1/L2/L3 levels.

**Deep-dive on a specific metric:**

> "Show me the research report for sydney-reliability"
>
> → Agent calls `get_metric_report("sydney-reliability")` and returns the full analysis.

**Find information across the project:**

> "Search for anything related to RAI jailbreak in our eval docs"
>
> → Agent calls `search("jailbreak")` and shows matching files and lines.

**Get the scorecard overview:**

> "Give me a summary of our Gov Cloud scorecard — what categories do we cover?"
>
> → Agent calls `get_scorecard()` and summarizes the 23-metric structure.

**Compare metrics:**

> "Which metrics have EQS scores below 95?"
>
> → Agent calls `list_metrics`, filters by EQS, and reports the ones below threshold.

**Read a reference doc:**

> "What does our FR-Gated-Metrics-Reference say about hard gates?"
>
> → Agent calls `get_document("FR-Gated-Metrics-Reference.md")` and answers from it.

**Browse project files:**

> "What scripts do we have for building evidence?"
>
> → Agent calls `list_files("scripts")` and describes what's available.

---

## 📝 Notes

- The MCP runs **locally** — no data leaves your machine
- It reads directly from your local clone of the repo (always up-to-date with your branch)
- Works from **any project folder** — you don't need to be in the evals repo
- Metric IDs use kebab-case: `chatsati-signal-sat-rate`, `sydney-reliability`, `rai-hate-fairness`, etc.

---

Questions? Ping Vasanth or check `quality-through-evals/mcp-server/README.md`.
