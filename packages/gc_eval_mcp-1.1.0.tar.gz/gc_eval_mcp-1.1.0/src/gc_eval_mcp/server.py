"""
GC-Eval MCP Server — Manifest-driven quality evaluation data server.

Fetches a remote manifest describing available datasets,
registers tools dynamically per dataset type, and serves data via MCP.
"""

import json
import sys

from mcp.server.fastmcp import FastMCP

from gc_eval_mcp.config import AZURE_STORAGE_ACCOUNT, AZURE_CONTAINER, CACHE_DIR
from gc_eval_mcp.manifest import fetch_manifest, Manifest, ManifestError
from gc_eval_mcp.handlers import get_handler
from gc_eval_mcp.cache import clear_cache

# Create MCP server instance
mcp = FastMCP("GC-Eval")

# Server state
_manifest: Manifest | None = None
_startup_error: str | None = None


def _register_dataset_tools(manifest: Manifest) -> int:
    """Register tools for each dataset in the manifest. Returns count of registered datasets."""
    registered = 0
    for dataset in manifest.datasets:
        handler_class = get_handler(dataset.type)
        if handler_class is None:
            continue
        handler = handler_class(dataset, manifest.base_path)
        handler.register_tools(mcp)
        registered += 1
    return registered


def _startup():
    """Fetch manifest and register tools. Called before mcp.run()."""
    global _manifest, _startup_error

    try:
        _manifest = fetch_manifest()
        count = _register_dataset_tools(_manifest)
        print(
            f"[GC-Eval] Loaded manifest v{_manifest.schema_version} "
            f"(data: {_manifest.data_version}) — {count} datasets registered",
            file=sys.stderr,
        )
    except ManifestError as e:
        _startup_error = str(e)
        print(f"[GC-Eval] WARNING: {e}", file=sys.stderr)
        print("[GC-Eval] Starting with diagnostic tools only.", file=sys.stderr)


# --- Static tools (always available) ---

@mcp.tool()
def get_status() -> str:
    """Get the current status of the GC-Eval MCP server.

    Shows manifest info, connected datasets, cache location, and any errors.
    """
    status = {
        "server": "GC-Eval MCP",
        "storage_account": AZURE_STORAGE_ACCOUNT,
        "container": AZURE_CONTAINER,
        "cache_dir": str(CACHE_DIR),
    }
    if _manifest:
        status["manifest_loaded"] = True
        status["schema_version"] = _manifest.schema_version
        status["data_version"] = _manifest.data_version
        status["datasets"] = [
            {"id": ds.id, "type": ds.type, "description": ds.description}
            for ds in _manifest.datasets
        ]
    else:
        status["manifest_loaded"] = False
        status["error"] = _startup_error or "Unknown error"
    return json.dumps(status, indent=2)


@mcp.tool()
def list_datasets() -> str:
    """List all available datasets with their types and descriptions."""
    if not _manifest:
        return json.dumps({"error": _startup_error or "No manifest loaded"})
    return json.dumps([
        {
            "id": ds.id,
            "type": ds.type,
            "tool_prefix": ds.tool_prefix,
            "description": ds.description,
        }
        for ds in _manifest.datasets
    ], indent=2)


@mcp.tool()
def refresh_cache() -> str:
    """Clear the local cache and re-fetch the manifest.

    Use this if data seems stale. Note: new datasets/tools require reconnecting the MCP client.
    """
    global _manifest, _startup_error

    clear_cache()
    try:
        _manifest = fetch_manifest()
        return json.dumps({
            "success": True,
            "data_version": _manifest.data_version,
            "datasets": len(_manifest.datasets),
            "note": "Cache cleared. If new datasets were added, reconnect your MCP client.",
        })
    except ManifestError as e:
        _startup_error = str(e)
        return json.dumps({"success": False, "error": str(e)})


def run():
    """Main entry point — fetch manifest, register tools, start server."""
    _startup()
    mcp.run()
