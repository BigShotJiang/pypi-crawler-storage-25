"""GC-Eval MCP Server — Manifest-driven quality evaluation data server."""

__version__ = "1.1.0"
