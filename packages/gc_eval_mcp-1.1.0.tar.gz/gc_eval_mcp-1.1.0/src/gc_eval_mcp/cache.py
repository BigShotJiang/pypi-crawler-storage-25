"""Local file cache backed by Azure Blob Storage with Entra ID (AAD) auth."""

import json
import sys
import time
import tempfile
import shutil
from pathlib import Path
from typing import Optional

from gc_eval_mcp.config import (
    AZURE_STORAGE_ACCOUNT,
    AZURE_CONTAINER,
    CACHE_DIR,
    CACHE_TTL_SECONDS,
    MAX_DOWNLOAD_SIZE,
)


def _get_blob_client():
    """Create an authenticated BlobServiceClient using DefaultAzureCredential."""
    from azure.identity import DefaultAzureCredential
    from azure.storage.blob import BlobServiceClient

    credential = DefaultAzureCredential()
    account_url = f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net"
    return BlobServiceClient(account_url, credential=credential)


def _ensure_cache_dir() -> Path:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    return CACHE_DIR


def _cache_key(blob_path: str) -> str:
    """Convert blob path to a safe filesystem cache key."""
    import hashlib
    return hashlib.sha256(blob_path.encode()).hexdigest()[:32]


def _meta_path(key: str) -> Path:
    return _ensure_cache_dir() / f"{key}.meta.json"


def _data_path(key: str) -> Path:
    return _ensure_cache_dir() / f"{key}.data"


def _load_meta(key: str) -> dict:
    meta_file = _meta_path(key)
    if meta_file.exists():
        return json.loads(meta_file.read_text(encoding="utf-8"))
    return {}


def _save_meta(key: str, meta: dict):
    _meta_path(key).write_text(json.dumps(meta), encoding="utf-8")


def fetch_or_cache(blob_path: str, force_refresh: bool = False) -> Optional[bytes]:
    """Fetch a blob from Azure Storage, using cached version if fresh.

    Args:
        blob_path: Path within the container (e.g., 'metrics_dict/certifications.json')
        force_refresh: Bypass cache and re-download

    Returns:
        File contents as bytes, or None on failure.
    """
    key = _cache_key(blob_path)
    meta = _load_meta(key)
    data_file = _data_path(key)

    # Return cached if fresh and not forced
    if not force_refresh and data_file.exists():
        fetched_at = meta.get("fetched_at", 0)
        if (time.time() - fetched_at) < CACHE_TTL_SECONDS:
            return data_file.read_bytes()

    # Fetch from Azure Blob Storage
    try:
        service = _get_blob_client()
        container = service.get_container_client(AZURE_CONTAINER)
        blob = container.get_blob_client(blob_path)

        # Check ETag for conditional fetch
        cached_etag = meta.get("etag")
        if cached_etag and data_file.exists() and not force_refresh:
            props = blob.get_blob_properties()
            if props.etag == cached_etag:
                # Not modified
                _save_meta(key, {**meta, "fetched_at": time.time()})
                return data_file.read_bytes()

        # Download
        download = blob.download_blob()
        content = download.readall()

        # Check size
        if len(content) > MAX_DOWNLOAD_SIZE:
            print(f"[GC-Eval] Blob '{blob_path}' exceeds max size, using cache", file=sys.stderr)
            if data_file.exists():
                return data_file.read_bytes()
            return None

        # Atomic write
        _ensure_cache_dir()
        tmp_fd, tmp_path = tempfile.mkstemp(dir=CACHE_DIR)
        try:
            with open(tmp_fd, "wb") as f:
                f.write(content)
            shutil.move(tmp_path, data_file)
        except Exception:
            Path(tmp_path).unlink(missing_ok=True)
            raise

        # Update metadata
        props = blob.get_blob_properties()
        new_meta = {
            "fetched_at": time.time(),
            "etag": props.etag,
            "size": len(content),
            "blob_path": blob_path,
        }
        _save_meta(key, new_meta)
        return content

    except Exception as e:
        # Network/auth failure — return cached if available
        print(f"[GC-Eval] Fetch failed for '{blob_path}': {e}", file=sys.stderr)
        if data_file.exists():
            return data_file.read_bytes()
        return None


def fetch_text(blob_path: str, force_refresh: bool = False) -> Optional[str]:
    """Fetch a blob and return as text."""
    data = fetch_or_cache(blob_path, force_refresh)
    if data is None:
        return None
    return data.decode("utf-8")


def clear_cache():
    """Remove all cached files."""
    if CACHE_DIR.exists():
        shutil.rmtree(CACHE_DIR)
