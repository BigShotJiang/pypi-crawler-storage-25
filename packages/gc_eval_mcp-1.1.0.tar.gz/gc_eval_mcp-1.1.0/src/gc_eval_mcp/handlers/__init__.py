"""Handler registry."""

from gc_eval_mcp.handlers.base import BaseHandler
from gc_eval_mcp.handlers.html_collection import HtmlCollectionHandler
from gc_eval_mcp.handlers.markdown import MarkdownHandler
from gc_eval_mcp.handlers.json_data import JsonHandler
from gc_eval_mcp.handlers.sqlite_handler import SqliteHandler

HANDLER_MAP = {
    "html-collection": HtmlCollectionHandler,
    "markdown": MarkdownHandler,
    "json": JsonHandler,
    "sqlite": SqliteHandler,
}


def get_handler(dataset_type: str) -> type[BaseHandler] | None:
    return HANDLER_MAP.get(dataset_type)
