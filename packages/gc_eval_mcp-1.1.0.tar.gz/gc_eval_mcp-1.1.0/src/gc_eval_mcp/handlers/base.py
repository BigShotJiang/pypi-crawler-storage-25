"""Base handler — abstract interface for all dataset types."""

from abc import ABC, abstractmethod

from mcp.server.fastmcp import FastMCP
from gc_eval_mcp.manifest import Dataset


class BaseHandler(ABC):
    """Base class for dataset handlers. Each handler registers MCP tools for its dataset."""

    def __init__(self, dataset: Dataset, base_path: str):
        self.dataset = dataset
        self.base_path = base_path

    def resolve_blob_path(self, path: str) -> str:
        """Resolve a relative path against the manifest base_path."""
        return f"{self.base_path}{path}"

    @abstractmethod
    def register_tools(self, mcp: FastMCP) -> None:
        """Register MCP tools for this dataset."""
        ...
