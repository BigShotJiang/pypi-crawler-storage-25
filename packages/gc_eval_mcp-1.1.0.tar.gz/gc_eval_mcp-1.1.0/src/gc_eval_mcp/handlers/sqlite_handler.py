"""Handler for SQLite datasets — download, cache, and query read-only."""

import json
import sqlite3
import re
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from gc_eval_mcp.handlers.base import BaseHandler
from gc_eval_mcp.cache import fetch_or_cache
from gc_eval_mcp.config import CACHE_DIR

# Only allow SELECT and WITH statements
ALLOWED_SQL_RE = re.compile(r"^\s*(SELECT|WITH)\s", re.IGNORECASE)
MAX_ROWS = 500


class SqliteHandler(BaseHandler):
    """Handles SQLite database datasets with read-only SQL query access."""

    def _get_db_path(self) -> Path:
        """Get the local cached path for this SQLite DB."""
        import hashlib
        blob_path = self.resolve_blob_path(self.dataset.path)
        key = hashlib.sha256(blob_path.encode()).hexdigest()[:32]
        return CACHE_DIR / f"{key}.sqlite"

    def _ensure_db(self) -> Path | None:
        """Download the SQLite DB if not cached, return local path."""
        blob_path = self.resolve_blob_path(self.dataset.path)
        data = fetch_or_cache(blob_path)
        if data is None:
            return None

        db_path = self._get_db_path()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        db_path.write_bytes(data)
        return db_path

    def register_tools(self, mcp: FastMCP) -> None:
        prefix = self.dataset.tool_prefix
        description = self.dataset.description
        handler = self

        @mcp.tool(name=f"query_{prefix}")
        def query_db(sql: str) -> str:
            """Run a read-only SQL query against the database.

            Args:
                sql: A SELECT or WITH query. No modifications allowed.
            """
            # Validate query
            if not ALLOWED_SQL_RE.match(sql):
                return json.dumps({
                    "error": "Only SELECT and WITH queries are allowed."
                })

            # Reject dangerous patterns
            dangerous = ["ATTACH", "DETACH", "PRAGMA", "LOAD_EXTENSION"]
            sql_upper = sql.upper()
            for keyword in dangerous:
                if keyword in sql_upper:
                    return json.dumps({"error": f"'{keyword}' is not allowed."})

            db_path = handler._ensure_db()
            if db_path is None:
                return json.dumps({"error": "Could not download database."})

            try:
                # Open read-only
                uri = f"file:{db_path}?mode=ro&immutable=1"
                conn = sqlite3.connect(uri, uri=True)
                conn.execute("SELECT 1")  # verify connection
                cursor = conn.cursor()
                cursor.execute(sql)
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                rows = cursor.fetchmany(MAX_ROWS)
                conn.close()

                result = {
                    "columns": columns,
                    "rows": [list(row) for row in rows],
                    "row_count": len(rows),
                    "truncated": len(rows) == MAX_ROWS,
                }
                return json.dumps(result, indent=2, default=str)

            except sqlite3.Error as e:
                return json.dumps({"error": f"SQL error: {e}"})

        query_db.__doc__ = (
            f"Query {description} with read-only SQL (SELECT/WITH only). "
            f"Max {MAX_ROWS} rows returned. Args: sql — the query."
        )

        @mcp.tool(name=f"describe_{prefix}")
        def describe_db() -> str:
            """List all tables and their columns in the database."""
            db_path = handler._ensure_db()
            if db_path is None:
                return json.dumps({"error": "Could not download database."})

            try:
                uri = f"file:{db_path}?mode=ro&immutable=1"
                conn = sqlite3.connect(uri, uri=True)
                cursor = conn.cursor()

                # Get tables
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
                tables = [row[0] for row in cursor.fetchall()]

                schema = {}
                for table in tables:
                    cursor.execute(f"PRAGMA table_info('{table}')")
                    columns = [{"name": row[1], "type": row[2]} for row in cursor.fetchall()]
                    schema[table] = columns

                conn.close()
                return json.dumps(schema, indent=2)

            except sqlite3.Error as e:
                return json.dumps({"error": f"Error reading schema: {e}"})

        describe_db.__doc__ = f"Describe the schema (tables and columns) of: {description}."
