"""Handler for HTML collection datasets (e.g., metric research reports)."""

import json
from typing import Optional

from mcp.server.fastmcp import FastMCP
from gc_eval_mcp.handlers.base import BaseHandler
from gc_eval_mcp.manifest import Dataset
from gc_eval_mcp.cache import fetch_text


class HtmlCollectionHandler(BaseHandler):
    """Handles datasets that are collections of HTML files with a JSON index."""

    def __init__(self, dataset: Dataset, base_path: str):
        super().__init__(dataset, base_path)
        self._index_cache: Optional[dict] = None

    def _get_index(self) -> dict:
        """Fetch and cache the index file (e.g., certifications.json)."""
        if self._index_cache is not None:
            return self._index_cache

        if not self.dataset.index:
            return {}

        blob_path = self.resolve_blob_path(self.dataset.index)
        raw = fetch_text(blob_path)
        if raw is None:
            return {}

        try:
            self._index_cache = json.loads(raw)
        except json.JSONDecodeError:
            self._index_cache = {}
        return self._index_cache

    def register_tools(self, mcp: FastMCP) -> None:
        prefix = self.dataset.tool_prefix
        description = self.dataset.description
        handler = self  # capture for closures

        @mcp.tool(name=f"list_{prefix}", description=f"List all items in: {description}. Returns JSON with IDs, certification levels, and metadata.")
        def list_items() -> str:
            index = handler._get_index()
            results = []
            for item_id, info in index.items():
                level = "L0"
                if info.get("human_review", {}).get("completed"):
                    level = "L3 (Human Reviewed)"
                elif info.get("enterprise_grounded", {}).get("completed"):
                    level = "L2 (Enterprise Grounded)"
                elif info.get("first_run", {}).get("completed"):
                    level = "L1 (First Run)"

                results.append({
                    "id": item_id,
                    "level": level,
                    "eqs": info.get("enterprise_grounded", {}).get("eqs"),
                    "owner": info.get("enterprise_grounded", {}).get("owner"),
                })
            return json.dumps(results, indent=2)

        @mcp.tool(name=f"get_{prefix}_report", description=f"Get the full HTML report for an item in: {description}. Args: item_id — the identifier (e.g., 'sydney-reliability').")
        def get_report(item_id: str) -> str:
            url = handler.resolve_blob_path(f"{handler.dataset.path}{item_id}.html")
            content = fetch_text(url)
            if content is None:
                index = handler._get_index()
                return json.dumps({
                    "error": f"Report not found for '{item_id}'",
                    "available": list(index.keys()),
                })
            return content

        @mcp.tool(name=f"get_{prefix}_certification", description=f"Get certification details for an item in: {description}. Args: item_id — the identifier.")
        def get_certification(item_id: str) -> str:
            index = handler._get_index()
            if item_id not in index:
                return json.dumps({
                    "error": f"Item '{item_id}' not found",
                    "available": list(index.keys()),
                })
            return json.dumps(index[item_id], indent=2)

        @mcp.tool(name=f"search_{prefix}", description=f"Search items in: {description}. Args: query — regex pattern to match against IDs and metadata.")
        def search_items(query: str) -> str:
            import re
            pattern = re.compile(query, re.IGNORECASE)
            index = handler._get_index()
            results = []
            for item_id, info in index.items():
                searchable = json.dumps({"id": item_id, **info})
                if pattern.search(searchable):
                    results.append({"id": item_id, "info": info})
            if not results:
                return json.dumps({"message": f"No matches for '{query}'"})
            return json.dumps(results[:20], indent=2)


