"""Handler for Markdown datasets."""

import json

from mcp.server.fastmcp import FastMCP
from gc_eval_mcp.handlers.base import BaseHandler
from gc_eval_mcp.cache import fetch_text


class MarkdownHandler(BaseHandler):
    """Handles single markdown file datasets."""

    def register_tools(self, mcp: FastMCP) -> None:
        prefix = self.dataset.tool_prefix
        description = self.dataset.description
        handler = self

        @mcp.tool(name=f"get_{prefix}", description=f"Get the full content of: {description}.")
        def get_document() -> str:
            """Retrieve the document content."""
            blob_path = handler.resolve_blob_path(handler.dataset.path)
            content = fetch_text(blob_path)
            if content is None:
                return json.dumps({"error": f"Could not fetch: {handler.dataset.path}"})
            return content

        get_document.__doc__ = f"Get the full content of: {description}."
