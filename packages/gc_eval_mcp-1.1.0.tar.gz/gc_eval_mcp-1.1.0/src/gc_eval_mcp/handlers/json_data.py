"""Handler for JSON datasets."""

import json

from mcp.server.fastmcp import FastMCP
from gc_eval_mcp.handlers.base import BaseHandler
from gc_eval_mcp.cache import fetch_text


class JsonHandler(BaseHandler):
    """Handles JSON file datasets with query support."""

    def register_tools(self, mcp: FastMCP) -> None:
        prefix = self.dataset.tool_prefix
        description = self.dataset.description
        handler = self

        @mcp.tool(name=f"get_{prefix}")
        def get_json() -> str:
            """Get the full JSON dataset."""
            blob_path = handler.resolve_blob_path(handler.dataset.path)
            content = fetch_text(blob_path)
            if content is None:
                return json.dumps({"error": f"Could not fetch: {handler.dataset.path}"})
            # Validate it's actually JSON
            try:
                data = json.loads(content)
                return json.dumps(data, indent=2)
            except json.JSONDecodeError:
                return json.dumps({"error": "Remote file is not valid JSON"})

        get_json.__doc__ = f"Get the full JSON content of: {description}."

        @mcp.tool(name=f"query_{prefix}")
        def query_json(key_path: str) -> str:
            """Query a JSON dataset by dot-separated key path.

            Args:
                key_path: Dot-separated path (e.g., 'sydney-reliability.enterprise_grounded.eqs')
            """
            blob_path = handler.resolve_blob_path(handler.dataset.path)
            content = fetch_text(blob_path)
            if content is None:
                return json.dumps({"error": f"Could not fetch: {handler.dataset.path}"})

            try:
                data = json.loads(content)
            except json.JSONDecodeError:
                return json.dumps({"error": "Remote file is not valid JSON"})

            # Navigate the key path
            keys = key_path.split(".")
            current = data
            for key in keys:
                if isinstance(current, dict):
                    if key in current:
                        current = current[key]
                    else:
                        return json.dumps({
                            "error": f"Key '{key}' not found",
                            "available_keys": list(current.keys())[:20],
                        })
                elif isinstance(current, list):
                    try:
                        current = current[int(key)]
                    except (ValueError, IndexError):
                        return json.dumps({"error": f"Invalid index '{key}' for array"})
                else:
                    return json.dumps({"error": f"Cannot navigate into {type(current).__name__}"})

            if isinstance(current, (dict, list)):
                return json.dumps(current, indent=2)
            return json.dumps({"value": current})

        query_json.__doc__ = (
            f"Query {description} by dot-separated key path. "
            f"Args: key_path — e.g., 'some-key.nested.field'."
        )
