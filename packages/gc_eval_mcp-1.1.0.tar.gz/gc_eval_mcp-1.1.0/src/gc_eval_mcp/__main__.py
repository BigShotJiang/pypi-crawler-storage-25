"""Entry point for gc-eval-mcp command."""

from gc_eval_mcp.server import run


def main():
    run()


if __name__ == "__main__":
    main()
