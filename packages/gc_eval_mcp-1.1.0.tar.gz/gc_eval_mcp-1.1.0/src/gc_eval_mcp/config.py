"""Configuration — environment variables and defaults."""

import os
from pathlib import Path

# Azure Blob Storage settings
AZURE_STORAGE_ACCOUNT = os.environ.get("GC_EVAL_STORAGE_ACCOUNT", "gcevalmcpdata")
AZURE_CONTAINER = os.environ.get("GC_EVAL_CONTAINER", "eval-data")

# Manifest blob path within the container
MANIFEST_BLOB_PATH = os.environ.get("GC_EVAL_MANIFEST_BLOB", "manifest.json")

# Local cache directory
CACHE_DIR = Path(os.environ.get(
    "GC_EVAL_CACHE_DIR",
    Path.home() / ".cache" / "gc-eval-mcp"
))

# Cache TTL in seconds (fallback when ETag is not available)
CACHE_TTL_SECONDS = int(os.environ.get("GC_EVAL_CACHE_TTL", "3600"))

# Maximum file size to download (50 MB)
MAX_DOWNLOAD_SIZE = int(os.environ.get("GC_EVAL_MAX_DOWNLOAD_MB", "50")) * 1024 * 1024

# Manifest fetch timeout (seconds)
MANIFEST_TIMEOUT = int(os.environ.get("GC_EVAL_MANIFEST_TIMEOUT", "10"))

# Supported dataset types
SUPPORTED_TYPES = {"html-collection", "markdown", "json", "sqlite"}
