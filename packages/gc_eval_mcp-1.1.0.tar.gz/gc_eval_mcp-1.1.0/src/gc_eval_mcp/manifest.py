"""Manifest fetching, validation, and parsing."""

import json
import re
import sys
from dataclasses import dataclass, field
from typing import Optional

from gc_eval_mcp.cache import fetch_text
from gc_eval_mcp.config import MANIFEST_BLOB_PATH, SUPPORTED_TYPES

# Valid tool prefix pattern
TOOL_PREFIX_RE = re.compile(r"^[a-z][a-z0-9_]{0,30}$")


@dataclass
class Dataset:
    id: str
    type: str
    path: str
    description: str
    tool_prefix: str
    index: Optional[str] = None
    search_index: Optional[str] = None
    schema_file: Optional[str] = None
    sha256: Optional[str] = None
    max_size_mb: Optional[int] = None


@dataclass
class Manifest:
    schema_version: str
    data_version: str
    base_path: str
    datasets: list[Dataset] = field(default_factory=list)


class ManifestError(Exception):
    pass


def fetch_manifest() -> Manifest:
    """Fetch and validate the manifest from Azure Blob Storage."""
    raw = fetch_text(MANIFEST_BLOB_PATH)
    if raw is None:
        raise ManifestError(
            f"Cannot fetch manifest from blob '{MANIFEST_BLOB_PATH}'. "
            f"Check your Azure credentials (az login) and storage account access."
        )
    return parse_manifest(raw)


def parse_manifest(raw: str) -> Manifest:
    """Parse and validate a manifest JSON string."""
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        raise ManifestError(f"Invalid manifest JSON: {e}")

    # Validate top-level fields
    schema_version = data.get("schema_version")
    if not schema_version:
        raise ManifestError("Missing 'schema_version' in manifest")

    base_path = data.get("base_path", "")
    # Ensure trailing slash if non-empty
    if base_path and not base_path.endswith("/"):
        base_path += "/"

    data_version = data.get("data_version", "unknown")

    # Parse datasets
    datasets = []
    for ds in data.get("datasets", []):
        ds_type = ds.get("type", "")
        if ds_type not in SUPPORTED_TYPES:
            continue  # Skip unsupported types gracefully

        ds_id = ds.get("id", "")
        tool_prefix = ds.get("tool_prefix", ds_id.replace("-", "_"))

        if not TOOL_PREFIX_RE.match(tool_prefix):
            raise ManifestError(
                f"Invalid tool_prefix '{tool_prefix}' for dataset '{ds_id}'. "
                f"Must match: {TOOL_PREFIX_RE.pattern}"
            )

        # Validate path doesn't escape
        path = ds.get("path", "")
        if ".." in path or path.startswith("/"):
            raise ManifestError(f"Invalid path in dataset '{ds_id}': {path}")

        datasets.append(Dataset(
            id=ds_id,
            type=ds_type,
            path=path,
            description=ds.get("description", ""),
            tool_prefix=tool_prefix,
            index=ds.get("index"),
            search_index=ds.get("search_index"),
            schema_file=ds.get("schema"),
            sha256=ds.get("sha256"),
            max_size_mb=ds.get("max_size_mb"),
        ))

    return Manifest(
        schema_version=schema_version,
        data_version=data_version,
        base_path=base_path,
        datasets=datasets,
    )
