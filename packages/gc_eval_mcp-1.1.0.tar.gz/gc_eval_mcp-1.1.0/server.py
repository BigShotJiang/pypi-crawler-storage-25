"""
Quality Evals MCP Server
Exposes BizChat Gov Cloud quality evaluation data via Model Context Protocol.
"""

import json
import os
import re
from pathlib import Path

from mcp.server.fastmcp import FastMCP

# Project root is one level up from mcp-server/
PROJECT_ROOT = Path(__file__).parent.parent.resolve()
HTML_DIR = PROJECT_ROOT / "html"
METRICS_DIR = HTML_DIR / "metrics_dict"
DOCS_DIR = PROJECT_ROOT / "docs"
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
CERTIFICATIONS_FILE = METRICS_DIR / "certifications.json"

mcp = FastMCP("GC-Eval")


def _load_certifications() -> dict:
    """Load the certifications.json file."""
    if CERTIFICATIONS_FILE.exists():
        return json.loads(CERTIFICATIONS_FILE.read_text(encoding="utf-8"))
    return {}


@mcp.tool()
def list_metrics() -> str:
    """List all 23 Gov Cloud scorecard metrics with their certification status.

    Returns a JSON array with metric name, certification level, EQS score, and owner.
    """
    certs = _load_certifications()
    results = []
    for metric_id, info in certs.items():
        level = "L0"
        if info.get("human_review", {}).get("completed"):
            level = "L3 (Human Reviewed)"
        elif info.get("enterprise_grounded", {}).get("completed"):
            level = "L2 (Enterprise Grounded)"
        elif info.get("first_run", {}).get("completed"):
            level = "L1 (First Run)"

        results.append({
            "metric_id": metric_id,
            "level": level,
            "eqs": info.get("enterprise_grounded", {}).get("eqs"),
            "owner": info.get("enterprise_grounded", {}).get("owner"),
            "has_report": (METRICS_DIR / f"{metric_id}.html").exists(),
        })
    return json.dumps(results, indent=2)


@mcp.tool()
def get_metric_report(metric_id: str) -> str:
    """Get the full HTML research report for a specific metric.

    Args:
        metric_id: The metric identifier (e.g., 'chatsati-signal-sat-rate', 'sydney-reliability')
    """
    report_path = METRICS_DIR / f"{metric_id}.html"
    if not report_path.exists():
        available = [f.stem for f in METRICS_DIR.glob("*.html")]
        return json.dumps({
            "error": f"No report found for '{metric_id}'",
            "available_metrics": available,
        })
    return report_path.read_text(encoding="utf-8")


@mcp.tool()
def get_metric_certification(metric_id: str) -> str:
    """Get detailed certification status for a specific metric.

    Args:
        metric_id: The metric identifier (e.g., 'chatsati-signal-sat-rate')
    """
    certs = _load_certifications()
    if metric_id not in certs:
        return json.dumps({
            "error": f"Metric '{metric_id}' not found",
            "available": list(certs.keys()),
        })
    return json.dumps(certs[metric_id], indent=2)


@mcp.tool()
def get_scorecard() -> str:
    """Get the Gov Cloud Scorecard documentation (the 23-metric minimal scorecard).

    Returns the full markdown content of the scorecard reference document.
    """
    scorecard_path = DOCS_DIR / "Gov-Cloud-Scorecard.md"
    if scorecard_path.exists():
        return scorecard_path.read_text(encoding="utf-8")
    return json.dumps({"error": "Scorecard document not found"})


@mcp.tool()
def get_document(name: str) -> str:
    """Read a document from the docs folder.

    Args:
        name: Document filename (e.g., 'Baseline-Quality-Scorecard.md', 'README.md')
    """
    doc_path = DOCS_DIR / name
    if not doc_path.exists():
        available = [f.name for f in DOCS_DIR.iterdir() if f.is_file()]
        return json.dumps({
            "error": f"Document '{name}' not found",
            "available": available,
        })
    # Prevent path traversal
    if not doc_path.resolve().is_relative_to(DOCS_DIR.resolve()):
        return json.dumps({"error": "Access denied"})
    return doc_path.read_text(encoding="utf-8")


@mcp.tool()
def search(query: str, file_pattern: str = "*") -> str:
    """Full-text search across all project files (docs, scripts, HTML reports).

    Args:
        query: Text or regex pattern to search for (case-insensitive)
        file_pattern: Glob pattern to filter files (default: '*' for all files)
    """
    results = []
    pattern = re.compile(query, re.IGNORECASE)

    search_dirs = [DOCS_DIR, SCRIPTS_DIR, METRICS_DIR]
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for filepath in search_dir.rglob(file_pattern):
            if not filepath.is_file():
                continue
            try:
                content = filepath.read_text(encoding="utf-8")
                matches = []
                for i, line in enumerate(content.splitlines(), 1):
                    if pattern.search(line):
                        matches.append({"line": i, "text": line.strip()[:200]})
                if matches:
                    results.append({
                        "file": str(filepath.relative_to(PROJECT_ROOT)),
                        "matches": matches[:10],  # Cap at 10 matches per file
                    })
            except (UnicodeDecodeError, PermissionError):
                continue

    if not results:
        return json.dumps({"message": f"No matches found for '{query}'"})
    return json.dumps(results[:20], indent=2)  # Cap at 20 files


@mcp.tool()
def list_files(directory: str = "") -> str:
    """List files in the project tree.

    Args:
        directory: Relative subdirectory to list (default: project root).
                   Examples: 'docs', 'html/metrics_dict', 'scripts'
    """
    target = PROJECT_ROOT / directory if directory else PROJECT_ROOT
    if not target.exists() or not target.is_dir():
        return json.dumps({"error": f"Directory '{directory}' not found"})
    if not target.resolve().is_relative_to(PROJECT_ROOT.resolve()):
        return json.dumps({"error": "Access denied"})

    entries = []
    for item in sorted(target.iterdir()):
        if item.name.startswith("."):
            continue
        entries.append({
            "name": item.name,
            "type": "directory" if item.is_dir() else "file",
            "size": item.stat().st_size if item.is_file() else None,
        })
    return json.dumps(entries, indent=2)


@mcp.tool()
def get_file(path: str) -> str:
    """Read any file by relative path from the project root.

    Args:
        path: Relative path from project root (e.g., 'scripts/gen_index.py', 'html/index.html')
    """
    file_path = PROJECT_ROOT / path
    if not file_path.exists():
        return json.dumps({"error": f"File '{path}' not found"})
    if not file_path.is_file():
        return json.dumps({"error": f"'{path}' is not a file"})
    if not file_path.resolve().is_relative_to(PROJECT_ROOT.resolve()):
        return json.dumps({"error": "Access denied"})

    try:
        content = file_path.read_text(encoding="utf-8")
        # Truncate very large files
        if len(content) > 100_000:
            content = content[:100_000] + "\n\n... [TRUNCATED at 100KB] ..."
        return content
    except UnicodeDecodeError:
        return json.dumps({"error": f"Cannot read '{path}' as text (binary file)"})


if __name__ == "__main__":
    mcp.run()
