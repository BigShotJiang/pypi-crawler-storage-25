from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.telemetry_envelope_capture_mode import TelemetryEnvelopeCaptureMode
from ..types import UNSET, Unset

T = TypeVar("T", bound="TelemetryEnvelope")


@_attrs_define
class TelemetryEnvelope:
    """Minimal shared telemetry payload shape for gateway and worker code.

    Attributes:
        run_id (str):
        process_id (None | str | Unset):
        request_id (None | str | Unset):
        traceparent (None | str | Unset):
        requested_at (datetime.datetime | None | Unset):
        simulation_kind (None | str | Unset):
        geography_code (None | str | Unset):
        geography_type (None | str | Unset):
        config_hash (None | str | Unset):
        capture_mode (TelemetryEnvelopeCaptureMode | Unset):  Default: TelemetryEnvelopeCaptureMode.DISABLED.
    """

    run_id: str
    process_id: None | str | Unset = UNSET
    request_id: None | str | Unset = UNSET
    traceparent: None | str | Unset = UNSET
    requested_at: datetime.datetime | None | Unset = UNSET
    simulation_kind: None | str | Unset = UNSET
    geography_code: None | str | Unset = UNSET
    geography_type: None | str | Unset = UNSET
    config_hash: None | str | Unset = UNSET
    capture_mode: TelemetryEnvelopeCaptureMode | Unset = TelemetryEnvelopeCaptureMode.DISABLED

    def to_dict(self) -> dict[str, Any]:
        run_id = self.run_id

        process_id: None | str | Unset
        if isinstance(self.process_id, Unset):
            process_id = UNSET
        else:
            process_id = self.process_id

        request_id: None | str | Unset
        if isinstance(self.request_id, Unset):
            request_id = UNSET
        else:
            request_id = self.request_id

        traceparent: None | str | Unset
        if isinstance(self.traceparent, Unset):
            traceparent = UNSET
        else:
            traceparent = self.traceparent

        requested_at: None | str | Unset
        if isinstance(self.requested_at, Unset):
            requested_at = UNSET
        elif isinstance(self.requested_at, datetime.datetime):
            requested_at = self.requested_at.isoformat()
        else:
            requested_at = self.requested_at

        simulation_kind: None | str | Unset
        if isinstance(self.simulation_kind, Unset):
            simulation_kind = UNSET
        else:
            simulation_kind = self.simulation_kind

        geography_code: None | str | Unset
        if isinstance(self.geography_code, Unset):
            geography_code = UNSET
        else:
            geography_code = self.geography_code

        geography_type: None | str | Unset
        if isinstance(self.geography_type, Unset):
            geography_type = UNSET
        else:
            geography_type = self.geography_type

        config_hash: None | str | Unset
        if isinstance(self.config_hash, Unset):
            config_hash = UNSET
        else:
            config_hash = self.config_hash

        capture_mode: str | Unset = UNSET
        if not isinstance(self.capture_mode, Unset):
            capture_mode = self.capture_mode.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "run_id": run_id,
            }
        )
        if process_id is not UNSET:
            field_dict["process_id"] = process_id
        if request_id is not UNSET:
            field_dict["request_id"] = request_id
        if traceparent is not UNSET:
            field_dict["traceparent"] = traceparent
        if requested_at is not UNSET:
            field_dict["requested_at"] = requested_at
        if simulation_kind is not UNSET:
            field_dict["simulation_kind"] = simulation_kind
        if geography_code is not UNSET:
            field_dict["geography_code"] = geography_code
        if geography_type is not UNSET:
            field_dict["geography_type"] = geography_type
        if config_hash is not UNSET:
            field_dict["config_hash"] = config_hash
        if capture_mode is not UNSET:
            field_dict["capture_mode"] = capture_mode

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        run_id = d.pop("run_id")

        def _parse_process_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        process_id = _parse_process_id(d.pop("process_id", UNSET))

        def _parse_request_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        request_id = _parse_request_id(d.pop("request_id", UNSET))

        def _parse_traceparent(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        traceparent = _parse_traceparent(d.pop("traceparent", UNSET))

        def _parse_requested_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                requested_at_type_0 = isoparse(data)

                return requested_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        requested_at = _parse_requested_at(d.pop("requested_at", UNSET))

        def _parse_simulation_kind(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        simulation_kind = _parse_simulation_kind(d.pop("simulation_kind", UNSET))

        def _parse_geography_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        geography_code = _parse_geography_code(d.pop("geography_code", UNSET))

        def _parse_geography_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        geography_type = _parse_geography_type(d.pop("geography_type", UNSET))

        def _parse_config_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        config_hash = _parse_config_hash(d.pop("config_hash", UNSET))

        _capture_mode = d.pop("capture_mode", UNSET)
        capture_mode: TelemetryEnvelopeCaptureMode | Unset
        if isinstance(_capture_mode, Unset):
            capture_mode = UNSET
        else:
            capture_mode = TelemetryEnvelopeCaptureMode(_capture_mode)

        telemetry_envelope = cls(
            run_id=run_id,
            process_id=process_id,
            request_id=request_id,
            traceparent=traceparent,
            requested_at=requested_at,
            simulation_kind=simulation_kind,
            geography_code=geography_code,
            geography_type=geography_type,
            config_hash=config_hash,
            capture_mode=capture_mode,
        )

        return telemetry_envelope
