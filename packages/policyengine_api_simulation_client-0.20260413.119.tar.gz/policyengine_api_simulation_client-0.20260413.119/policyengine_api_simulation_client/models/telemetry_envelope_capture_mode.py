from enum import Enum


class TelemetryEnvelopeCaptureMode(str, Enum):
    ALWAYS = "always"
    DISABLED = "disabled"
    FAILURES = "failures"
    SAMPLED = "sampled"
    THRESHOLD = "threshold"

    def __str__(self) -> str:
        return str(self.value)
