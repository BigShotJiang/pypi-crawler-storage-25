from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.telemetry_envelope import TelemetryEnvelope


T = TypeVar("T", bound="SimulationRequest")


@_attrs_define
class SimulationRequest:
    """Request model for simulation submission.

    Attributes:
        country (str):
        version (None | str | Unset):
        telemetry (None | TelemetryEnvelope | Unset):
    """

    country: str
    version: None | str | Unset = UNSET
    telemetry: None | TelemetryEnvelope | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.telemetry_envelope import TelemetryEnvelope

        country = self.country

        version: None | str | Unset
        if isinstance(self.version, Unset):
            version = UNSET
        else:
            version = self.version

        telemetry: dict[str, Any] | None | Unset
        if isinstance(self.telemetry, Unset):
            telemetry = UNSET
        elif isinstance(self.telemetry, TelemetryEnvelope):
            telemetry = self.telemetry.to_dict()
        else:
            telemetry = self.telemetry

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "country": country,
            }
        )
        if version is not UNSET:
            field_dict["version"] = version
        if telemetry is not UNSET:
            field_dict["telemetry"] = telemetry

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.telemetry_envelope import TelemetryEnvelope

        d = dict(src_dict)
        country = d.pop("country")

        def _parse_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version = _parse_version(d.pop("version", UNSET))

        def _parse_telemetry(data: object) -> None | TelemetryEnvelope | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                telemetry_type_0 = TelemetryEnvelope.from_dict(data)

                return telemetry_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TelemetryEnvelope | Unset, data)

        telemetry = _parse_telemetry(d.pop("telemetry", UNSET))

        simulation_request = cls(
            country=country,
            version=version,
            telemetry=telemetry,
        )

        simulation_request.additional_properties = d
        return simulation_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
