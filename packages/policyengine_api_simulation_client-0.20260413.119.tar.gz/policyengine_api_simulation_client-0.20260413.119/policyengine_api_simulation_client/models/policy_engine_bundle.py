from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="PolicyEngineBundle")


@_attrs_define
class PolicyEngineBundle:
    """Resolved runtime provenance returned by the gateway.

    Attributes:
        model_version (str):
        policyengine_version (None | str | Unset):
        data_version (None | str | Unset):
        dataset (None | str | Unset):
    """

    model_version: str
    policyengine_version: None | str | Unset = UNSET
    data_version: None | str | Unset = UNSET
    dataset: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        model_version = self.model_version

        policyengine_version: None | str | Unset
        if isinstance(self.policyengine_version, Unset):
            policyengine_version = UNSET
        else:
            policyengine_version = self.policyengine_version

        data_version: None | str | Unset
        if isinstance(self.data_version, Unset):
            data_version = UNSET
        else:
            data_version = self.data_version

        dataset: None | str | Unset
        if isinstance(self.dataset, Unset):
            dataset = UNSET
        else:
            dataset = self.dataset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "model_version": model_version,
            }
        )
        if policyengine_version is not UNSET:
            field_dict["policyengine_version"] = policyengine_version
        if data_version is not UNSET:
            field_dict["data_version"] = data_version
        if dataset is not UNSET:
            field_dict["dataset"] = dataset

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        model_version = d.pop("model_version")

        def _parse_policyengine_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        policyengine_version = _parse_policyengine_version(d.pop("policyengine_version", UNSET))

        def _parse_data_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        data_version = _parse_data_version(d.pop("data_version", UNSET))

        def _parse_dataset(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        dataset = _parse_dataset(d.pop("dataset", UNSET))

        policy_engine_bundle = cls(
            model_version=model_version,
            policyengine_version=policyengine_version,
            data_version=data_version,
            dataset=dataset,
        )

        policy_engine_bundle.additional_properties = d
        return policy_engine_bundle

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
