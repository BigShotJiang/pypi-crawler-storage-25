"""High-level Pyronova application class with decorator syntax."""

from __future__ import annotations

import time
import sys
from typing import Callable, TypedDict
import inspect

import os

from pyronova.engine import PyronovaApp as _PyronovaApp, Response, init_logger, emit_python_log
from pyronova.mcp import MCPServer


class LogConfig(TypedDict, total=False):
    """Logging configuration dictionary.

    Keys:
        level: "OFF", "ERROR", "WARN", "INFO", "DEBUG", "TRACE"
        access_log: Whether to log every HTTP request (method, path, status, latency)
        format: "text" (human-readable) or "json" (structured, for ELK/Datadog)
    """
    level: str
    access_log: bool
    format: str

def _is_worker() -> bool:
    """Check if we're running inside a sub-interpreter worker."""
    return os.environ.get("PYRONOVA_WORKER") == "1"


def _setup_python_logging_bridge(rust_level: str = "DEBUG") -> None:
    """Hijack Python's root logger to route all logs through Rust tracing.

    Replaces default StreamHandler (synchronous, GIL-blocking I/O) with a
    lightweight handler that crosses FFI into Rust's tracing system.
    The actual filtering, formatting, and I/O happen in Rust — Python only
    does the minimal work of extracting the log record fields.

    The ``rust_level`` parameter syncs Rust's EnvFilter level to Python's
    root logger, so calls below the threshold (e.g. logger.debug() when
    level=ERROR) are rejected by Python's own level check *before* any
    getMessage() formatting or FFI crossing occurs.
    """
    import logging

    _LEVEL_MAP = {
        "TRACE": logging.DEBUG,
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARN": logging.WARNING,
        "WARNING": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
        "OFF": logging.CRITICAL + 10,  # above CRITICAL — blocks everything
    }

    class PyronovaRustHandler(logging.Handler):
        """logging.Handler that bridges to Rust tracing via FFI."""

        def emit(self, record: logging.LogRecord) -> None:
            try:
                msg = record.getMessage()
                # Preserve exception tracebacks (logger.exception / exc_info=True)
                if record.exc_info and not record.exc_text:
                    record.exc_text = self.formatException(record.exc_info)
                if record.exc_text:
                    msg = f"{msg}\n{record.exc_text}"
                emit_python_log(
                    level=record.levelname,
                    name=record.name,
                    message=msg,
                    pathname=record.pathname or "",
                    lineno=record.lineno or 0,
                )
            except Exception:
                # Fallback to Python's built-in error handler — prints to stderr
                self.handleError(record)

    root = logging.getLogger()
    # Don't clear existing handlers — user may have Sentry, DataDog, etc.
    # Only add Pyronova bridge if not already present.
    if not any(isinstance(h, PyronovaRustHandler) for h in root.handlers):
        root.addHandler(PyronovaRustHandler())
    # Sync Python's level gate with Rust's EnvFilter — avoids wasted
    # getMessage() + FFI calls for records that Rust would discard anyway
    root.setLevel(_LEVEL_MAP.get(rust_level.upper(), logging.DEBUG))


class Pyronova:
    """Pyronova web framework — decorator-friendly wrapper around the Rust engine.

    Usage::

        from pyronova import Pyronova

        app = Pyronova()

        @app.get("/")
        def index(req):
            return "Hello from Pyronova!"

        app.run()

    Auto-detects ``def`` vs ``async def`` and routes to the right pool::

        @app.get("/fast")
        def fast(req):              # → sync pool (220k req/s)
            return "hello"

        @app.get("/io")
        async def io(req):          # → async pool (133k req/s)
            await asyncio.sleep(0.1)
            return "done"

        @app.get("/numpy", gil=True)
        def compute(req):           # → GIL main interpreter
            import numpy as np
            return {"mean": float(np.mean([1,2,3]))}

        app.run()                   # zero config, auto dual-pool
    """

    def __init__(
        self,
        debug: bool = False,
        log_config: LogConfig | None = None,
    ) -> None:
        self._engine = _PyronovaApp()
        self._fallback_handler: Callable | None = None
        self._fallback_name: str | None = None
        self._mcp = MCPServer()
        self.debug = debug
        self._startup_hooks: list[Callable] = []
        self._shutdown_hooks: list[Callable] = []
        self._routes_meta: list[dict] = []
        self._fast_routes_meta: list[dict] = []
        self._readiness_checks: list[tuple[str, Callable]] = []
        self._health_probes_enabled: bool = False

        # Resolve final logging config: debug mode defaults vs production defaults.
        # Actual init_logger call is deferred to run() so enable_logging() can
        # adjust the config before the tracing subscriber is locked in.
        user = log_config or {}
        if self.debug:
            self._log_config: LogConfig = {
                "level": user.get("level", "DEBUG"),
                "access_log": user.get("access_log", True),
                "format": user.get("format", "text"),
            }
        else:
            self._log_config: LogConfig = {
                "level": user.get("level", "ERROR"),
                "access_log": user.get("access_log", False),
                "format": user.get("format", "json"),
            }
        self._logger_initialized = False

    @property
    def mcp(self) -> MCPServer:
        """MCP (Model Context Protocol) server for AI tool integration."""
        return self._mcp

    @property
    def max_body_size(self) -> int:
        """Max request body size in bytes. Default: 10 MB."""
        return 10 * 1024 * 1024  # getter returns default; actual value is in Rust

    @max_body_size.setter
    def max_body_size(self, size: int) -> None:
        """Set max request body size. Example: ``app.max_body_size = 50 * 1024 * 1024``"""
        self._engine.set_max_body_size(size)

    def enable_compression(
        self,
        *,
        min_size: int = 512,
        gzip: bool = True,
        brotli: bool = True,
        gzip_level: int = 6,
        brotli_quality: int = 4,
    ) -> None:
        """Enable gzip / brotli response compression.

        Disabled by default; call once at startup to turn on. The server
        negotiates with the client's ``Accept-Encoding`` header and prefers
        brotli when both are enabled. Skips responses under ``min_size``,
        non-text content types (images, octet-stream), streaming responses
        (SSE), and responses that set ``Content-Encoding`` explicitly.

        Args:
            min_size: minimum body size (bytes) to compress. Default 512.
            gzip: enable gzip (``Content-Encoding: gzip``). Default True.
            brotli: enable brotli (``Content-Encoding: br``). Default True.
            gzip_level: 1..=9, default 6 (balanced speed/ratio).
            brotli_quality: 0..=11, default 4 (production sweet spot).
        """
        self._engine.configure_compression(
            True, min_size, gzip, brotli, gzip_level, brotli_quality
        )

    def disable_compression(self) -> None:
        """Disable response compression. No-op if already disabled."""
        self._engine.configure_compression(False)

    def add_fast_response(
        self,
        method: str,
        path: str,
        body: bytes | str,
        *,
        content_type: str = "text/plain",
        status_code: int = 200,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Register a route that returns a pre-built response without
        entering Python.

        Use for constant-body endpoints — health checks, ``/robots.txt``,
        ``/pipeline`` probe routes, maintenance pages. The accept loop
        serves the exact bytes stored here on every match, skipping GIL
        acquisition, handler dispatch, and response serialization.

        Match is exact ``(method, path)`` — no path parameters, no
        globbing. If you need those, register a normal decorator route.

        Example::

            app.add_fast_response("GET", "/health", b'{"ok":true}',
                                  content_type="application/json")
            app.add_fast_response("GET", "/robots.txt",
                                  b"User-agent: *\\nDisallow: /\\n")
        """
        if isinstance(body, str):
            body = body.encode("utf-8")
        self._engine.add_fast_response(
            method.upper(),
            path,
            body,
            content_type=content_type,
            status_code=status_code,
            headers=headers,
        )
        self._fast_routes_meta.append({
            "method": method.upper(),
            "path": path,
            "status_code": status_code,
            "content_type": content_type,
            "bytes": len(body),
        })

    @property
    def state(self):
        """Shared state across all sub-interpreters (nanosecond latency).

        Usage::

            app.state["session:user_1"] = json.dumps({"role": "admin"})
            data = json.loads(app.state["session:user_1"])
        """
        return self._engine.state

    # ------------------------------------------------------------------
    # Route registration (decorator + direct call)
    # ------------------------------------------------------------------

    def get(self, path: str, handler: Callable | None = None, *, gil: bool = False, model: type | None = None) -> Callable:
        return self._route("GET", path, handler, gil=gil, model=model)

    def post(self, path: str, handler: Callable | None = None, *, gil: bool = False, model: type | None = None, stream: bool = False) -> Callable:
        return self._route("POST", path, handler, gil=gil, model=model, stream=stream)

    def put(self, path: str, handler: Callable | None = None, *, gil: bool = False, model: type | None = None, stream: bool = False) -> Callable:
        return self._route("PUT", path, handler, gil=gil, model=model, stream=stream)

    def delete(self, path: str, handler: Callable | None = None, *, gil: bool = False, model: type | None = None) -> Callable:
        return self._route("DELETE", path, handler, gil=gil, model=model)

    def patch(self, path: str, handler: Callable | None = None, *, gil: bool = False, model: type | None = None, stream: bool = False) -> Callable:
        return self._route("PATCH", path, handler, gil=gil, model=model, stream=stream)

    def options(self, path: str, handler: Callable | None = None, *, gil: bool = False, model: type | None = None) -> Callable:
        return self._route("OPTIONS", path, handler, gil=gil, model=model)

    def head(self, path: str, handler: Callable | None = None, *, gil: bool = False, model: type | None = None) -> Callable:
        return self._route("HEAD", path, handler, gil=gil, model=model)

    def route(self, method: str, path: str, handler: Callable | None = None, *, gil: bool = False, model: type | None = None, stream: bool = False) -> Callable:
        return self._route(method.upper(), path, handler, gil=gil, model=model, stream=stream)

    def _route(self, method: str, path: str, handler: Callable | None, *, gil: bool = False, model: type | None = None, stream: bool = False) -> Callable:
        def _wrap_with_model(fn: Callable, mdl: type) -> Callable:
            """Wrap handler to auto-validate request body with Pydantic model."""
            import inspect
            sig = inspect.signature(fn)
            params = list(sig.parameters.values())
            is_async = inspect.iscoroutinefunction(fn)

            if is_async:
                async def wrapper(req):
                    try:
                        validated = mdl.model_validate_json(req.body)
                    except Exception as e:
                        return Response(
                            body=str(e),
                            status_code=422,
                            content_type="text/plain",
                        )
                    if len(params) >= 2:
                        return await fn(req, validated)
                    return await fn(validated)
            else:
                def wrapper(req):
                    try:
                        validated = mdl.model_validate_json(req.body)
                    except Exception as e:
                        return Response(
                            body=str(e),
                            status_code=422,
                            content_type="text/plain",
                        )
                    if len(params) >= 2:
                        return fn(req, validated)
                    return fn(validated)

            wrapper.__name__ = fn.__name__
            wrapper.__qualname__ = fn.__qualname__
            return wrapper

        def _record(fn: Callable) -> None:
            self._routes_meta.append({
                "method": method,
                "path": path,
                "handler": getattr(fn, "__qualname__", getattr(fn, "__name__", repr(fn))),
                "gil": gil,
                "stream": stream,
                "model": model.__name__ if model is not None else None,
                "async": inspect.iscoroutinefunction(fn),
            })

        if handler is not None:
            if model is not None:
                handler = _wrap_with_model(handler, model)
            self._engine.route(method, path, handler, gil, stream)
            _record(handler)
            return handler

        def decorator(fn: Callable) -> Callable:
            wrapped = _wrap_with_model(fn, model) if model is not None else fn
            self._engine.route(method, path, wrapped, gil, stream)
            _record(fn)
            return fn  # Return original for type hints

        return decorator

    # ------------------------------------------------------------------
    # Middleware
    # ------------------------------------------------------------------

    def enable_cors(
        self,
        allow_origins: str | list[str] = "*",
        allow_methods: str | list[str] = "GET, POST, PUT, DELETE, PATCH, OPTIONS",
        allow_headers: str | list[str] = "*",
        expose_headers: str | list[str] = "",
        allow_credentials: bool = False,
        max_age: int = 86400,
    ) -> None:
        """Enable CORS (Cross-Origin Resource Sharing).

        Usage::

            app.enable_cors()  # Allow all origins

            app.enable_cors(
                allow_origins=["https://example.com", "https://app.example.com"],
                allow_credentials=True,
            )
        """
        if isinstance(allow_origins, list):
            allow_origins = ", ".join(allow_origins)
        if isinstance(allow_methods, list):
            allow_methods = ", ".join(allow_methods)
        if isinstance(allow_headers, list):
            allow_headers = ", ".join(allow_headers)
        if isinstance(expose_headers, list):
            expose_headers = ", ".join(expose_headers)

        cors_headers = {
            "access-control-allow-origin": allow_origins,
            "access-control-allow-methods": allow_methods,
            "access-control-allow-headers": allow_headers,
        }
        if expose_headers:
            cors_headers["access-control-expose-headers"] = expose_headers
        if allow_credentials:
            cors_headers["access-control-allow-credentials"] = "true"
        if max_age:
            cors_headers["access-control-max-age"] = str(max_age)

        # Handle preflight OPTIONS + add CORS headers to all responses
        def _cors_before(req):
            if req.method == "OPTIONS":
                return Response(body="", status_code=204, headers=cors_headers)
            return None

        self._engine.before_request(_cors_before)

        # CORS response headers are applied in Rust layer only (handlers.rs)
        # to avoid duplicate headers which violate W3C CORS spec.
        # Pass full config so allow_credentials + expose_headers appear on
        # every response (GET/POST/etc.), not just OPTIONS preflight.
        self._engine.set_cors_config(
            allow_origins,
            allow_methods,
            allow_headers,
            expose_headers or None,
            allow_credentials,
        )

    # ------------------------------------------------------------------

    def rpc(self, path: str, *, proto_model: type | None = None) -> Callable:
        """Register an RPC endpoint with content negotiation.

        Supports MsgPack, JSON, and optional Protobuf auto-decode/encode.

        Usage::

            @app.rpc("/rpc/get_data")
            def get_data(req):
                return {"prices": [150.1, 150.2]}
        """
        from pyronova.rpc import rpc_decorator
        return rpc_decorator(self, path, proto_model)

    # ------------------------------------------------------------------

    def before_request(self, handler: Callable | None = None) -> Callable:
        """Register a before-request hook. Use as decorator or direct call.

        The hook receives ``(request)`` and should return ``None`` to continue
        or a response to short-circuit.
        """
        if handler is not None:
            self._engine.before_request(handler)
            return handler

        def decorator(fn: Callable) -> Callable:
            self._engine.before_request(fn)
            return fn

        return decorator

    def after_request(self, handler: Callable | None = None) -> Callable:
        """Register an after-request hook. Use as decorator or direct call.

        The hook receives ``(request, response)`` and must return a
        ``Response``.
        """
        if handler is not None:
            self._engine.after_request(handler)
            return handler

        def decorator(fn: Callable) -> Callable:
            self._engine.after_request(fn)
            return fn

        return decorator

    # ------------------------------------------------------------------
    # Lifecycle hooks
    # ------------------------------------------------------------------

    def on_startup(self, handler: Callable | None = None) -> Callable:
        """Register a startup hook. Called before the server starts accepting requests.

        Usage::

            @app.on_startup
            def init_db():
                app.state["db"] = create_pool()
        """
        if handler is not None:
            self._startup_hooks.append(handler)
            return handler

        def decorator(fn: Callable) -> Callable:
            self._startup_hooks.append(fn)
            return fn

        return decorator

    def on_shutdown(self, handler: Callable | None = None) -> Callable:
        """Register a shutdown hook. Called after the server stops.

        Usage::

            @app.on_shutdown
            def cleanup():
                close_pool(app.state["db"])
        """
        if handler is not None:
            self._shutdown_hooks.append(handler)
            return handler

        def decorator(fn: Callable) -> Callable:
            self._shutdown_hooks.append(fn)
            return fn

        return decorator

    # ------------------------------------------------------------------
    # Observability — X-Request-ID + /metrics
    # ------------------------------------------------------------------

    def enable_request_id(self, header: str = "X-Request-ID") -> None:
        """Guarantee every response carries an ``X-Request-ID`` header.

        If the client sent one, it's echoed back verbatim (so trace IDs
        propagated from an upstream proxy survive). If not, a fresh UUID
        v4 hex is minted. Idempotent.
        """
        if getattr(self, "_request_id_enabled", False):
            return
        from pyronova.observability import install_request_id
        install_request_id(self, header)
        self._request_id_enabled = True

    def enable_metrics(self, path: str = "/metrics") -> None:
        """Expose Prometheus metrics at ``path`` (default ``/metrics``).

        Registers a ``GET /metrics`` route plus before/after-request hooks
        that maintain counters in ``app.state``. The scrape endpoint does
        not count itself. Idempotent.
        """
        if getattr(self, "_metrics_enabled", False):
            return
        from pyronova.observability import install_metrics
        install_metrics(self, path)
        self._metrics_enabled = True

    # ------------------------------------------------------------------
    # Health probes — /livez + /readyz
    # ------------------------------------------------------------------

    def enable_health_probes(
        self,
        *,
        livez_path: str = "/livez",
        readyz_path: str = "/readyz",
        gil: bool = True,
    ) -> None:
        """Register Kubernetes-style ``/livez`` and ``/readyz`` routes.

        ``/livez`` always returns 200 — the process is alive. ``/readyz``
        runs every function registered with ``@app.readiness_check(name)``
        and returns 200 only when all pass; any failure produces 503 with a
        JSON body listing the failing check.

        Call once at startup, typically right after ``Pyronova()``. Idempotent —
        calling again is a no-op.

        Args:
            livez_path: route for the liveness probe (default ``/livez``).
            readyz_path: route for the readiness probe (default ``/readyz``).
            gil: whether probes run on the main interpreter. Default True
                 because most readiness checks touch globals (DB pools,
                 cache clients) that live on the main interp.
        """
        if self._health_probes_enabled:
            return
        from pyronova.health import _build_livez_handler, _build_readyz_handler

        self._route("GET", livez_path, _build_livez_handler(), gil=gil)
        self._route(
            "GET",
            readyz_path,
            _build_readyz_handler(self._readiness_checks),
            gil=gil,
        )
        self._health_probes_enabled = True

    def readiness_check(self, name: str) -> Callable:
        """Register a readiness check. Sync or async. Decorator form::

            @app.readiness_check("db")
            def _db_ready():
                pool.fetch_scalar("SELECT 1")

        A check passes when it returns any value that isn't ``False`` and
        doesn't raise. ``False`` or an exception → the check is reported
        as failing in ``/readyz`` and the whole probe returns 503.
        """
        def decorator(fn: Callable) -> Callable:
            self._readiness_checks.append((name, fn))
            return fn

        return decorator

    # ------------------------------------------------------------------
    # Fallback (custom 404)
    # ------------------------------------------------------------------

    def fallback(self, handler: Callable | None = None) -> Callable:
        """Register a fallback handler for unmatched routes."""
        if handler is not None:
            self._engine.fallback(handler)
            return handler

        def decorator(fn: Callable) -> Callable:
            self._engine.fallback(fn)
            return fn

        return decorator

    # ------------------------------------------------------------------
    # WebSocket
    # ------------------------------------------------------------------

    def websocket(self, path: str, handler: Callable | None = None) -> Callable:
        """Register a WebSocket handler. Use as decorator or direct call.

        The handler receives a ``WebSocket`` object with ``recv()``,
        ``send(msg)``, and ``close()`` methods::

            @app.websocket("/ws")
            def ws_handler(ws):
                while True:
                    msg = ws.recv()
                    if msg is None:
                        break
                    ws.send(f"echo: {msg}")
        """
        if handler is not None:
            self._engine.websocket(path, handler)
            return handler

        def decorator(fn: Callable) -> Callable:
            self._engine.websocket(path, fn)
            return fn

        return decorator

    # ------------------------------------------------------------------
    # Static files
    # ------------------------------------------------------------------

    def static(self, prefix: str, directory: str) -> None:
        """Serve static files from *directory* under URL *prefix*.

        Example::

            app.static("/static", "./public")
        """
        self._engine.static_dir(prefix, directory)

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    def enable_logging(
        self,
        level: str = "info",
        sample: int = 1,
        always_log_status: int = 0,
    ) -> None:
        """Enable structured request/response logging.

        This activates both:
        - Rust-side access log (method, path, status, latency_us) via tracing
        - Python-side formatted output for GIL mode (human-readable)

        :param level: minimum log level — "debug" / "info" / "warn" / "error".
        :param sample: log 1 in every ``sample`` requests. ``1`` (default)
            logs every request. ``100`` keeps roughly 1% — production knob
            to recover the 25-30% throughput tax of full access logging
            while retaining a usable observability sample. Per-route
            atomic counter; sampling decision is global.
        :param always_log_status: bypass sampling for responses whose
            status is >= this value. ``400`` keeps full visibility of
            4xx/5xx errors while sampling 2xx success traffic. ``0``
            (default) applies sampling uniformly.

        Output format (GIL mode, text format)::

            2026-03-24 17:30:01 [INFO]  GET /api/trade → 200 (2.3ms)
            2026-03-24 17:30:01 [ERROR] POST /rpc/add → 500 (0.4ms) TypeError: ...
        """
        from datetime import datetime

        _timings: dict[int, float] = {}
        _MAX_TIMINGS = 10000  # Cap to prevent memory leak from SSE/stream requests
        _min_level = {"debug": 0, "info": 1, "warn": 2, "error": 3}.get(level.lower(), 1)

        def _log_before(req):
            if len(_timings) > _MAX_TIMINGS:
                _timings.clear()  # Emergency cleanup — stream requests skip after_hook
            _timings[id(req)] = time.monotonic()
            return None

        def _log_after(req, resp):
            start = _timings.pop(id(req), None)
            elapsed = (time.monotonic() - start) * 1000 if start else 0
            status = getattr(resp, "status_code", 200)
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # Determine log level by status code
            if status >= 500:
                tag, lvl = "ERROR", 3
            elif status >= 400:
                tag, lvl = "WARN ", 2
            else:
                tag, lvl = "INFO ", 1

            if lvl >= _min_level:
                # Extract error message from body if 500
                err = ""
                if status >= 500:
                    body = getattr(resp, "body", "")
                    if isinstance(body, str) and "error" in body:
                        # Try to extract error from JSON response
                        try:
                            import json
                            err = " " + json.loads(body).get("error", "")[:100]
                        except Exception:
                            pass

                print(f"  {ts} [{tag}] {req.method} {req.path} → {status} ({elapsed:.1f}ms){err}", flush=True)

            return resp

        self._engine.before_request(_log_before)
        self._engine.after_request(_log_after)

        # Also enable Rust-level logging for sub-interpreter mode (per-instance)
        self._engine.enable_request_logging(True)
        # Sampling / always-log knobs land on the Rust route table; the
        # decision happens inside each handler's logging path.
        if sample > 1 or always_log_status > 0:
            self._engine.set_request_log_sampling(sample, always_log_status)

        # Upgrade log config so the deferred init_logger picks up access_log
        level_map = {"debug": "DEBUG", "info": "INFO", "warn": "WARN", "error": "ERROR"}
        rust_level = level_map.get(level.lower(), "INFO")
        if self._log_config.get("level", "ERROR") in ("ERROR", "OFF"):
            self._log_config["level"] = rust_level
        self._log_config["access_log"] = True

    # ------------------------------------------------------------------
    # Run
    # ------------------------------------------------------------------

    @property
    def routes(self) -> list[dict]:
        """List of registered routes (dicts with method/path/handler/gil/stream/async/model).

        Populated as routes are registered via decorators or direct calls.
        Fast-path routes (``add_fast_response``) appear in ``fast_routes``.
        """
        return list(self._routes_meta)

    @property
    def fast_routes(self) -> list[dict]:
        """Routes registered via ``add_fast_response``."""
        return list(self._fast_routes_meta)

    def run(
        self,
        *,
        host: str | None = None,
        port: int | None = None,
        workers: int | None = None,
        mode: str | None = None,
        reload: bool = False,
        io_workers: int | None = None,
        tls_cert: str | None = None,
        tls_key: str | None = None,
    ) -> None:
        """Start the Pyronova server.

        Args:
            workers: Python sub-interpreter count (default: CPU count).
            io_workers: Tokio async I/O thread count + accept loop count
                        (default: CPU count). Independent of workers.
            tls_cert: Path to PEM certificate chain (enables HTTPS).
                      Required together with ``tls_key``. Default None → plain HTTP.
            tls_key:  Path to PEM private key. Required together with ``tls_cert``.
        """
        # Priority: param > env var > default
        host = host or os.environ.get("PYRONOVA_HOST", "127.0.0.1")
        port = port or int(os.environ.get("PYRONOVA_PORT", "8000"))
        workers = workers or (int(os.environ.get("PYRONOVA_WORKERS")) if os.environ.get("PYRONOVA_WORKERS") else None)
        io_workers = io_workers or (int(os.environ.get("PYRONOVA_IO_WORKERS")) if os.environ.get("PYRONOVA_IO_WORKERS") else None)
        tls_cert = tls_cert or os.environ.get("PYRONOVA_TLS_CERT")
        tls_key = tls_key or os.environ.get("PYRONOVA_TLS_KEY")

        # Hot reload: watch .py files, restart on change
        reload = reload or os.environ.get("PYRONOVA_RELOAD") == "1"
        if reload and os.environ.get("_PYRONOVA_RELOAD_CHILD") != "1":
            self._run_with_reload()
            return

        # Auto-enable logging if PYRONOVA_LOG=1 or debug=True
        if (os.environ.get("PYRONOVA_LOG") == "1" or self.debug) and not hasattr(self, "_logging_enabled"):
            self.enable_logging()
            self._logging_enabled = True

        # Initialize Rust tracing engine (deferred from __init__ so
        # enable_logging() can adjust the config first)
        if not self._logger_initialized:
            self._logger_initialized = True
            # Expose level to sub-interpreter bootstrap via env var
            os.environ["PYRONOVA_LOG_LEVEL"] = self._log_config["level"]
            init_logger(
                self._log_config["level"],
                self._log_config["access_log"],
                self._log_config["format"],
            )
            _setup_python_logging_bridge(self._log_config["level"])
        # Auto-register /mcp endpoint if any MCP handlers exist
        if self._mcp._tools or self._mcp._resources or self._mcp._prompts:
            mcp = self._mcp

            def _mcp_handler(req):
                body = req.text()
                result = mcp.handle_request(body)
                return Response(
                    body=result,
                    content_type="application/json",
                )

            self._engine.route("POST", "/mcp", _mcp_handler, True)  # gil=True
            print(f"  MCP: {len(mcp._tools)} tools, {len(mcp._resources)} resources, {len(mcp._prompts)} prompts → POST /mcp")

        # Auto-detect best mode if not explicitly set
        if mode is None:
            mode = "subinterp"

        # In worker mode (sub-interpreter), don't start the server —
        # just loading the script to register routes is enough.
        if _is_worker():
            return

        import signal
        import threading
        # Suppress Python's noisy KeyboardInterrupt during threading shutdown
        # (only works in main thread — TestClient runs in a background thread)
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, signal.SIG_DFL)

        # Run startup hooks
        for hook in self._startup_hooks:
            hook()

        try:
            self._engine.run(
                host=host,
                port=port,
                workers=workers,
                mode=mode,
                io_workers=io_workers,
                tls_cert=tls_cert,
                tls_key=tls_key,
            )
        finally:
            # Run shutdown hooks (even if server exits abnormally)
            for hook in self._shutdown_hooks:
                try:
                    hook()
                except Exception as e:
                    print(f"  [shutdown] Hook {hook.__name__} error: {e}")

    def _run_with_reload(self):
        """Watch .py files and restart server on changes using OS-native events."""
        import subprocess

        script = sys.argv[0] if sys.argv else None
        if not script:
            print("  [reload] Cannot determine script path, running without reload")
            return

        watch_dir = os.path.dirname(os.path.abspath(script)) or "."

        try:
            import watchfiles
        except ImportError:
            print("  [reload] Install 'watchfiles' for efficient file watching:")
            print("           pip install watchfiles")
            print("  [reload] Falling back to polling mode...")
            return self._run_with_reload_poll(watch_dir, script)

        print(f"  [reload] Watching {watch_dir} for .py changes (watchfiles)...")

        while True:
            env = {**os.environ, "_PYRONOVA_RELOAD_CHILD": "1"}
            proc = subprocess.Popen([sys.executable, script], env=env)

            try:
                for changes in watchfiles.watch(
                    watch_dir,
                    watch_filter=watchfiles.PythonFilter(),
                    stop_event=None,
                    debounce=500,  # 500ms debounce — wait for IDE to finish writing
                ):
                    changed = [os.path.basename(c[1]) for c in list(changes)[:3]]
                    print(f"\n  [reload] File changed: {', '.join(changed)}")
                    print(f"  [reload] Restarting...\n")
                    proc.terminate()
                    try:
                        proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                    break
                else:
                    break
            except KeyboardInterrupt:
                proc.terminate()
                proc.wait()
                break

    def _run_with_reload_poll(self, watch_dir: str, script: str):
        """Fallback polling watcher when watchfiles is not installed."""
        import subprocess
        import hashlib
        import glob

        print(f"  [reload] Watching {watch_dir} for .py changes (polling)...")

        def _snapshot():
            files = {}
            for f in glob.glob(os.path.join(watch_dir, "**/*.py"), recursive=True):
                # Skip common large directories
                if "/.venv/" in f or "/node_modules/" in f or "/__pycache__/" in f:
                    continue
                try:
                    with open(f, "rb") as fh:
                        files[f] = hashlib.md5(fh.read()).hexdigest()
                except Exception:
                    pass
            return files

        while True:
            env = {**os.environ, "_PYRONOVA_RELOAD_CHILD": "1"}
            proc = subprocess.Popen([sys.executable, script], env=env)
            snap = _snapshot()

            try:
                while proc.poll() is None:
                    time.sleep(1)
                    current = _snapshot()
                    if current != snap:
                        # Debounce: wait 0.5s for IDE to finish writing all files
                        time.sleep(0.5)
                        snap = _snapshot()  # Re-snapshot after debounce
                        changed = [f for f in snap if snap.get(f) != current.get(f)]
                        print(f"\n  [reload] File changed: {', '.join(os.path.basename(f) for f in changed[:3])}")
                        print(f"  [reload] Restarting...\n")
                        proc.terminate()
                        try:
                            proc.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            proc.kill()
                        break
                else:
                    break
            except KeyboardInterrupt:
                proc.terminate()
                proc.wait()
                break
