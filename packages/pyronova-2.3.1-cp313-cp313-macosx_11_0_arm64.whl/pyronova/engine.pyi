"""Type stubs for pyronova.engine (Rust extension module)."""

from typing import Optional

def init_logger(level: str, access_log: bool, format: str) -> None:
    """Initialize the Rust tracing engine. Call once at startup."""
    ...

def emit_python_log(
    level: str,
    name: str,
    message: str,
    pathname: str,
    lineno: int,
    worker_id: Optional[int] = None,
) -> None:
    """Route a Python log record through Rust tracing."""
    ...

class Request:
    method: str
    path: str
    params: dict[str, str]
    query: str
    headers: dict[str, str]
    client_ip: str
    body: bytes
    query_params: dict[str, str]
    """Query parameters as Dict[str, str]. On duplicate keys, the FIRST
    value wins (HTTP parameter pollution defense — aligns with common
    WAF / reverse-proxy behavior). Use `query_params_all` for duplicates."""
    query_params_all: dict[str, list[str]]
    """Query parameters preserving all values per key. Use when the
    handler legitimately accepts multiple occurrences of the same key."""
    def text(self) -> str: ...
    def json(self) -> dict: ...

class Response:
    body: object
    status_code: int
    content_type: Optional[str]
    headers: dict[str, str]
    def __init__(
        self,
        body: object,
        status_code: int = 200,
        content_type: Optional[str] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> None: ...

class WebSocket:
    def recv(self) -> Optional[str]: ...
    def send(self, msg: str) -> None: ...
    def close(self) -> None: ...

class PyronovaApp:
    def __init__(self) -> None: ...
    def get(self, path: str, handler: object, gil: bool = False) -> None: ...
    def post(self, path: str, handler: object, gil: bool = False) -> None: ...
    def put(self, path: str, handler: object, gil: bool = False) -> None: ...
    def delete(self, path: str, handler: object, gil: bool = False) -> None: ...
    def route(self, method: str, path: str, handler: object, gil: bool = False) -> None: ...
    def before_request(self, handler: object) -> None: ...
    def after_request(self, handler: object) -> None: ...
    def fallback(self, handler: object) -> None: ...
    def websocket(self, path: str, handler: object) -> None: ...
    def static_dir(self, prefix: str, directory: str) -> None: ...
    def set_cors_origin(self, origin: str) -> None: ...
    def set_cors_config(
        self,
        origin: str,
        methods: str,
        headers: str,
        expose_headers: Optional[str] = None,
        allow_credentials: bool = False,
    ) -> None: ...
    def enable_request_logging(self, enabled: bool) -> None: ...
    def run(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        workers: Optional[int] = None,
        mode: Optional[str] = None,
    ) -> None: ...
