::: lume.base.CommandWrapper
