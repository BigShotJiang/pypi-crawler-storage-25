"""Figures for :func:`~batem.core.building.variation` sweeps (last floor, dual-axis energy + comfort).

Splines interpolate simulation sample points (same abscissa values as the sweep); markers show
the exact evaluation points. Layout is inspired by :meth:`~batem.core.lambdahouse.ReportGenerator.add_parametric`
but uses smoothing curves and BATEM polygon-prism sweep keys.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import numpy as np
from scipy.interpolate import make_interp_spline

from batem.core.building import BuildingData

# Keep this module import-light (avoid pulling optional lambdahouse / flexible stacks).
_DEFAULT_FIG_INCHES: tuple[int, int] = (10, 6)

PerformanceKey = tuple[str, int, float]
PerformanceRow = tuple[float, float, float, float, float]

# Seven scalar sweeps (instance index 0 in :func:`~batem.core.building.variation`).
VARIATION_SCALAR_PARAMS: tuple[tuple[str, int], ...] = (
    ("z_rotation_angle_deg", 0),
    ("glazing_solar_factor", 0),
    ("normal_heating_setpoint", 0),
    ("normal_cooling_setpoint", 0),
    ("low_heating_setpoint", 0),
    ("regular_air_renewal_rate_vol_per_hour", 0),
    ("regular_ventilation_heat_recovery_efficiency", 0),
)


def last_floor_window_side_indices(building_data: BuildingData) -> list[int]:
    """Façade indices with strictly positive glazing area on the top occupied storey (one “window” each)."""
    fi: int = building_data.n_floors - 1
    out: list[int] = []
    for i in range(building_data.n_sides):
        if building_data.sides_glazing_floor_vsurface_m2_by_floor[fi][i] > 1e-9:
            out.append(i)
    if not out:
        return list(range(building_data.n_sides))
    return out


def _pretty_param(parameter_name: str) -> str:
    return parameter_name.replace("_", " ")


def _collapse_duplicate_x(
    x: np.ndarray, *y_cols: np.ndarray
) -> tuple[np.ndarray, list[np.ndarray]]:
    """Average *y* values that share the same *x* (after rounding), then sort by *x*."""
    if len(x) == 0:
        return x, [np.array([]) for _ in y_cols]
    keys: list[float] = []
    buckets: dict[float, list[list[float]]] = {}
    rnd = 12
    for i in range(len(x)):
        k = round(float(x[i]), rnd)
        if k not in buckets:
            buckets[k] = [[] for _ in y_cols]
            keys.append(k)
        for j, yc in enumerate(y_cols):
            buckets[k][j].append(float(yc[i]))
    keys.sort()
    xs = np.array(keys, dtype=float)
    ys_out: list[np.ndarray] = []
    for j in range(len(y_cols)):
        ys_out.append(np.array([np.mean(buckets[k][j]) for k in keys], dtype=float))
    return xs, ys_out


def _sorted_series_for_param(
    performances: dict[PerformanceKey, PerformanceRow],
    parameter_name: str,
    instance: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None:
    xs: list[float] = []
    h_wh: list[float] = []
    c_wh: list[float] = []
    t_wh: list[float] = []
    t_lo: list[float] = []
    t_hi: list[float] = []
    for (pname, inst, pval), perf in performances.items():
        if pname != parameter_name or inst != instance:
            continue
        heat_wh, cool_wh, total_wh, avginf5, avgsup5 = perf
        xs.append(float(pval))
        h_wh.append(float(heat_wh))
        c_wh.append(float(cool_wh))
        t_wh.append(float(total_wh))
        t_lo.append(float(avginf5))
        t_hi.append(float(avgsup5))
    if not xs:
        return None
    x0 = np.array(xs, dtype=float)
    y0 = np.array(h_wh, dtype=float)
    y1 = np.array(c_wh, dtype=float)
    y2 = np.array(t_wh, dtype=float)
    y3 = np.array(t_lo, dtype=float)
    y4 = np.array(t_hi, dtype=float)
    x0, (y0, y1, y2, y3, y4) = _collapse_duplicate_x(x0, y0, y1, y2, y3, y4)
    order = np.argsort(x0)
    return (
        x0[order],
        y0[order],
        y1[order],
        y2[order],
        y3[order],
        y4[order],
    )


def _spline_dense(x: np.ndarray, y: np.ndarray, n_fine: int = 160) -> tuple[np.ndarray, np.ndarray]:
    """Cubic (or lower) spline through knots ``(x, y)``; returns fine grid and values."""
    if len(x) == 0:
        return x, y
    if len(x) == 1:
        return x, y
    k = int(min(3, len(x) - 1))
    if k < 1:
        k = 1
    spl = make_interp_spline(x, y, k=k)
    xf = np.linspace(float(x[0]), float(x[-1]), max(n_fine, len(x) * 12))
    return xf, spl(xf)


def _plot_dual_axis_parametric_axis(
    ax1,
    x: np.ndarray,
    heat_kwh: np.ndarray,
    cool_kwh: np.ndarray,
    total_kwh: np.ndarray,
    t_low_c: np.ndarray,
    t_high_c: np.ndarray,
    xlabel: str,
    title: str,
) -> None:
    left_label = "Last floor energy needs in kWh/year"
    right_label = "5% last floor temperatures during occupation (°C)"

    m = (
        np.isfinite(x)
        & np.isfinite(heat_kwh)
        & np.isfinite(cool_kwh)
        & np.isfinite(total_kwh)
        & np.isfinite(t_low_c)
        & np.isfinite(t_high_c)
    )
    x = x[m]
    heat_kwh = heat_kwh[m]
    cool_kwh = cool_kwh[m]
    total_kwh = total_kwh[m]
    t_low_c = t_low_c[m]
    t_high_c = t_high_c[m]
    if len(x) < 2:
        ax1.text(0.5, 0.5, "Not enough finite samples for curves.", ha="center", va="center", transform=ax1.transAxes)
        ax1.set_title(title)
        return

    def _to_kwh(wh: np.ndarray) -> np.ndarray:
        return wh / 1000.0

    h_k = _to_kwh(heat_kwh)
    c_k = _to_kwh(cool_kwh)
    t_k = _to_kwh(total_kwh)

    colors_left = ("C0", "C1", "C2")
    for yi, lab, c in zip(
        (h_k, c_k, t_k),
        ("Heating needs", "Cooling needs", "Total needs"),
        colors_left,
    ):
        xf, yf = _spline_dense(x, yi)
        ax1.plot(xf, yf, "-", color=c, linewidth=1.8, alpha=0.9, label=lab)
        ax1.plot(x, yi, "o", color=c, markersize=5, alpha=0.85)

    ax1.set_xlabel(xlabel)
    ax1.set_ylabel(left_label)
    ax1.grid(True, alpha=0.35)
    ax1.legend(loc="upper left", fontsize=8)
    ax1.set_title(title, fontsize=10)

    ax2 = ax1.twinx()
    colors_right = ("C3", "C4")
    for yi, lab, ls, c in zip(
        (t_low_c, t_high_c),
        ("Avg lowest 5% occupied temperature", "Avg highest 5% occupied temperature"),
        ("--", ":"),
        colors_right,
    ):
        xf, yf = _spline_dense(x, yi)
        ax2.plot(xf, yf, ls, color=c, linewidth=1.8, alpha=0.9, label=lab)
        ax2.plot(x, yi, "o", color=c, markersize=5, alpha=0.85)

    ax2.set_ylabel(right_label)
    ax2.legend(loc="upper right", fontsize=8)


def _matplotlib_gui_backend() -> bool:
    be = matplotlib.get_backend().lower()
    if "inline" in be or be.endswith("inline"):
        return False
    return be not in ("agg", "svg", "pdf", "ps", "template")


def plot_building_variation_figures(
    performances: dict[PerformanceKey, PerformanceRow],
    building_data: BuildingData,
    *,
    show: bool = True,
    suptitle_prefix: str = "",
    save_dir: Path | None = None,
) -> list[Path] | None:
    """Open **(n_windows + 7)** matplotlib figures from a :func:`~batem.core.building.variation` result dict.

    * One figure per last-floor window (façade with glazing) sweeping ``side_glazing_ratios``.
    * One figure per scalar parameter in :data:`VARIATION_SCALAR_PARAMS`.

    Left axis: PHVAC-derived energies (kWh/year). Right axis: mean of coldest / warmest 5% of
    occupied operative temperatures on the last floor (same convention as the sweep worker).

    If ``save_dir`` is set, PNG files are written there (recommended from ``baterm`` when the
    backend may be non-interactive). When ``show`` is true and a GUI backend is active,
    :func:`matplotlib.pyplot.show` blocks until windows are closed.
    """
    w: int = int(_DEFAULT_FIG_INCHES[0])
    h: int = int(_DEFAULT_FIG_INCHES[1])
    window_sides: list[int] = last_floor_window_side_indices(building_data)

    figures: list[tuple[str, Figure]] = []

    for order_i, side_i in enumerate(window_sides):
        win_name = f"side{side_i}"
        ser = _sorted_series_for_param(performances, "side_glazing_ratios", side_i)
        fig, ax = plt.subplots(figsize=(w * 0.65, h * 0.65))
        if ser is None:
            ax.text(0.5, 0.5, "No sweep points for this façade.", ha="center", va="center", transform=ax.transAxes)
            ax.set_title(f"Last floor — {win_name} (no data)")
        else:
            x, h_wh, c_wh, t_wh, t_lo, t_hi = ser
            _plot_dual_axis_parametric_axis(
                ax,
                x,
                h_wh,
                c_wh,
                t_wh,
                t_lo,
                t_hi,
                xlabel="Glazing ratio (–)",
                title=f"Last floor — {win_name}",
            )
        if suptitle_prefix:
            fig.suptitle(suptitle_prefix, fontsize=10, y=1.02)
        fig.tight_layout()
        figures.append((f"01_glazing_last_floor_{order_i:02d}_{win_name}", fig))

    for pname, inst in VARIATION_SCALAR_PARAMS:
        ser = _sorted_series_for_param(performances, pname, inst)
        fig, ax = plt.subplots(figsize=(w * 0.65, h * 0.65))
        if ser is None:
            ax.text(0.5, 0.5, "No data for this parameter in the sweep.", ha="center", va="center", transform=ax.transAxes)
            ax.set_title(_pretty_param(pname))
        else:
            x, h_wh, c_wh, t_wh, t_lo, t_hi = ser
            _plot_dual_axis_parametric_axis(
                ax,
                x,
                h_wh,
                c_wh,
                t_wh,
                t_lo,
                t_hi,
                xlabel=_pretty_param(pname),
                title=f"Last floor — {_pretty_param(pname)}",
            )
        if suptitle_prefix:
            fig.suptitle(suptitle_prefix, fontsize=10, y=1.02)
        fig.tight_layout()
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in pname)
        figures.append((f"02_{safe}", fig))

    saved: list[Path] = []
    if save_dir is not None:
        out = Path(save_dir)
        out.mkdir(parents=True, exist_ok=True)
        for stem, fig in figures:
            path = out / f"{stem}.png"
            fig.savefig(path, dpi=160, bbox_inches="tight")
            saved.append(path)

    if show and _matplotlib_gui_backend():
        plt.show()
    else:
        plt.close("all")

    return saved if save_dir is not None else None
