"""Electricity cost from HVAC load and PV production under regulated retail tariffs.

Hourly series convention (BATEM default timestep = 3600 s):

- ``HVAC_ELEC:building#sim`` — electrical energy per step in Wh
- ``PV:power_W`` — mean electrical power over the step in W (energy Wh = W × 1 h)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Sequence

HVAC_ELEC_BUILDING_VAR: str = "HVAC_ELEC:building#sim"
PV_POWER_VAR: str = "PV:power_W"
ENERCOST_HOUR_VAR: str = "ENERCOST:hour#sim"
GRID_IMPORT_KWH_VAR: str = "GRID_IMPORT:kWh#sim"
GRID_EXPORT_KWH_VAR: str = "GRID_EXPORT:kWh#sim"


class RegulatedTariffOption(str, Enum):
    """French *tarif réglementé de vente* style options (indicative €/kWh, TTC-like)."""

    BASE = "base"
    HP_HC = "hp_hc"


@dataclass(frozen=True)
class RegulatedElectricityTariff:
    """Regulated retail tariff parameters for net-metering style hourly billing.

    * **base** — single energy price (option *Base*).
    * **hp_hc** — off-peak / peak split (option *Heures pleines / Heures creuses*).

    Default off-peak window matches the common Linky schedule: 22:00–06:00 every day.
    Prices are indicative; override via CLI or when constructing this dataclass.
    """

    option: RegulatedTariffOption = RegulatedTariffOption.HP_HC
    base_eur_per_kwh: float = 0.2516
    hp_eur_per_kwh: float = 0.2700
    hc_eur_per_kwh: float = 0.2068
    export_eur_per_kwh: float = 0.0
    off_peak_start_hour: int = 22
    off_peak_end_hour: int = 6

    def import_price_eur_per_kwh(self, dt: datetime | None, hour_index: int | None = None) -> float:
        """Return the import €/kWh for one timestep."""
        if self.option == RegulatedTariffOption.BASE:
            return self.base_eur_per_kwh
        hour = dt.hour if dt is not None else (hour_index if hour_index is not None else 12)
        if self._is_off_peak(hour):
            return self.hc_eur_per_kwh
        return self.hp_eur_per_kwh

    def _is_off_peak(self, hour: int) -> bool:
        start, end = self.off_peak_start_hour, self.off_peak_end_hour
        if start > end:
            return hour >= start or hour < end
        return start <= hour < end


@dataclass(frozen=True)
class EnercostResult:
    """Aggregated annual electricity cost and grid exchange."""

    tariff: RegulatedElectricityTariff
    hvac_kwh: float
    pv_kwh: float
    grid_import_kwh: float
    grid_export_kwh: float
    cost_with_pv_eur: float
    cost_without_pv_eur: float
    hourly_cost_eur: list[float]
    hourly_import_kwh: list[float]
    hourly_export_kwh: list[float]

    @property
    def savings_eur(self) -> float:
        return self.cost_without_pv_eur - self.cost_with_pv_eur


def _power_w_to_kwh(power_w: float, sample_time_in_secs: int) -> float:
    return power_w * sample_time_in_secs / 3_600_000.0


def _wh_to_kwh(energy_wh: float) -> float:
    return energy_wh / 1000.0


def compute_enercost(
    hvac_elec_wh: Sequence[float],
    pv_power_w: Sequence[float],
    *,
    tariff: RegulatedElectricityTariff | None = None,
    datetimes: Sequence[datetime] | None = None,
    sample_time_in_secs: int = 3600,
) -> EnercostResult:
    """Compute hourly grid exchange and cost from HVAC Wh and PV power (W).

    Net import at step *k* is ``max(0, hvac_kwh - pv_kwh)``; net export is the surplus.
    """
    if len(hvac_elec_wh) != len(pv_power_w):
        raise ValueError(
            f"HVAC and PV series must have the same length "
            f"({len(hvac_elec_wh)} != {len(pv_power_w)})."
        )
    n = len(hvac_elec_wh)
    tariff = tariff or RegulatedElectricityTariff()
    if datetimes is not None and len(datetimes) != n:
        raise ValueError(f"datetimes length {len(datetimes)} != series length {n}.")

    hvac_kwh_series: list[float] = [_wh_to_kwh(v) for v in hvac_elec_wh]
    pv_kwh_series: list[float] = [
        _power_w_to_kwh(w, sample_time_in_secs) for w in pv_power_w
    ]
    import_kwh: list[float] = []
    export_kwh: list[float] = []
    hourly_cost: list[float] = []
    cost_without_pv = 0.0

    for k in range(n):
        hvac_k = hvac_kwh_series[k]
        pv_k = pv_kwh_series[k]
        drawn = max(0.0, hvac_k - pv_k)
        injected = max(0.0, pv_k - hvac_k)
        import_kwh.append(drawn)
        export_kwh.append(injected)
        dt = datetimes[k] if datetimes is not None else None
        price = tariff.import_price_eur_per_kwh(dt, hour_index=k % 24)
        cost_without_pv += hvac_k * price
        if drawn > 0.0:
            hourly_cost.append(drawn * price - injected * tariff.export_eur_per_kwh)
        elif injected > 0.0:
            hourly_cost.append(-injected * tariff.export_eur_per_kwh)
        else:
            hourly_cost.append(0.0)

    return EnercostResult(
        tariff=tariff,
        hvac_kwh=sum(hvac_kwh_series),
        pv_kwh=sum(pv_kwh_series),
        grid_import_kwh=sum(import_kwh),
        grid_export_kwh=sum(export_kwh),
        cost_with_pv_eur=sum(hourly_cost),
        cost_without_pv_eur=cost_without_pv,
        hourly_cost_eur=hourly_cost,
        hourly_import_kwh=import_kwh,
        hourly_export_kwh=export_kwh,
    )
