"""Render the outdoor Givoni psychrometric chart in a **fresh** interpreter (Agg only).

``batem.baterm`` runs ``context psychro`` via this worker so matplotlib does not share
the cmd2/readline process. The figure is drawn with **numpy + matplotlib only** (no
``psychrochart`` / ``psychrolib``): those libraries have been observed to **SIGSEGV**
on some macOS stacks when building the full chart.

Usage::

    python -m batem.tools.psychro_chart_worker /path/to/payload.pkl
"""

from __future__ import annotations

import pickle
import sys
from pathlib import Path

# SI psychrometrics at sea-level pressure (matches psychrochart default altitude 0).
_P_ATM_PA = 101325.0
_DBT_MIN_C = 0.0
_DBT_MAX_C = 50.0
_W_MAX_G_KG = 40.0


def _p_ws_pa(temp_c):
    """Saturation vapor pressure over liquid water (Pa), Magnus-type (ASHRAE-style)."""
    import numpy as np

    t = np.asarray(temp_c, dtype=float)
    return 611.2 * np.exp(17.67 * t / (t + 243.5))


def _humidity_ratio_kg_kg(temp_c, rh: float, p_pa: float = _P_ATM_PA):
    """Humidity ratio (kg/kg dry air) from dry-bulb temperature (°C) and RH in (0, 1]."""
    import numpy as np

    pws = _p_ws_pa(temp_c)
    rh = float(rh)
    pw = np.clip(rh * pws, 0.0, pws * 0.999999)
    return 0.622 * pw / (p_pa - pw)


def _render(out_png: Path, dry: list[float], abs_h: list[float], width: float, height: float) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.patches import Polygon

    fig, ax = plt.subplots(figsize=(width, height))

    t_axis = np.linspace(_DBT_MIN_C, _DBT_MAX_C, 400)
    w_sat_g = 1000.0 * _humidity_ratio_kg_kg(t_axis, 1.0, _P_ATM_PA)
    ax.plot(t_axis, w_sat_g, color=(0.855, 0.004, 0.278), linewidth=2.5, label="Saturation")

    rh_levels = (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)
    for rh in rh_levels:
        w_g = 1000.0 * _humidity_ratio_kg_kg(t_axis, rh, _P_ATM_PA)
        w_g = np.minimum(w_g, w_sat_g * 0.999)
        ax.plot(t_axis, w_g, color=(0.0, 0.498, 1.0), linewidth=0.8, linestyle="-.", alpha=0.7)

    # Light grids similar to a textbook psychrometric chart
    for tc in np.arange(5.0, _DBT_MAX_C, 5.0):
        ax.axvline(tc, color=(0.85, 0.15, 0.11), linewidth=0.4, linestyle=":", alpha=0.5)
    for wg in np.arange(2.0, _W_MAX_G_KG, 2.0):
        ax.axhline(wg, color=(0.0, 0.125, 0.376), linewidth=0.4, linestyle=":", alpha=0.5)

    temp_min = 20.0
    temp_max = 25.0
    rh_min = 0.20
    rh_max = 0.80

    def calc_abs_humidity_g_kg(temp_c: float, rh: float) -> float:
        return float(1000.0 * _humidity_ratio_kg_kg(temp_c, rh, _P_ATM_PA))

    abs_hum_min_temp_min_rh = calc_abs_humidity_g_kg(temp_min, rh_min)
    abs_hum_max_temp_min_rh = calc_abs_humidity_g_kg(temp_min, rh_max)
    abs_hum_max_temp_max_rh = calc_abs_humidity_g_kg(temp_max, rh_max)
    abs_hum_min_temp_max_rh = calc_abs_humidity_g_kg(temp_max, rh_min)

    comfort_zone = Polygon(
        [
            [temp_min, abs_hum_min_temp_min_rh],
            [temp_min, abs_hum_max_temp_min_rh],
            [temp_max, abs_hum_max_temp_max_rh],
            [temp_max, abs_hum_min_temp_max_rh],
        ],
        closed=True,
        edgecolor="green",
        facecolor="none",
        linewidth=2.5,
        linestyle="-",
        label="Comfort zone",
    )
    ax.add_patch(comfort_zone)

    dry_a = np.asarray(dry, dtype=float)
    w_a = 1000.0 * np.asarray(abs_h, dtype=float)
    if dry_a.size:
        ax.scatter(dry_a, w_a, marker="o", alpha=0.1, color="0.2", s=8, linewidths=0)

    ax.set_xlim(_DBT_MIN_C, _DBT_MAX_C)
    ax.set_ylim(0.0, _W_MAX_G_KG)
    ax.set_xlabel("Dry-bulb temperature, °C")
    ax.set_ylabel("Humidity ratio $w$, g/kg$_{da}$")
    ax.set_title("Psychrometric diagram: Outdoor comfort (Givoni)")
    ax.grid(True, alpha=0.22)
    fig.tight_layout()
    fig.savefig(str(out_png), dpi=150, bbox_inches="tight")
    plt.close("all")


def main() -> None:
    path = Path(sys.argv[1])
    payload = pickle.loads(path.read_bytes())
    out_png = Path(payload["out_png"])
    _render(
        out_png,
        payload["dry_bulb_temperature_deg"],
        payload["absolute_humidity_kg_kg"],
        float(payload["fig_width"]),
        float(payload["fig_height"]),
    )


if __name__ == "__main__":
    main()
