"""Run :class:`~batem.core.utils.TimeSeriesPlotter` in a fresh interpreter.

Used from ``baterm`` so Tk opens outside the cmd2 process (stable on macOS).

Usage::

    python -m batem.tools.time_series_plot_worker /path/to/payload.pkl
"""

from __future__ import annotations

import pickle
import sys
from pathlib import Path


def main() -> None:
    path = Path(sys.argv[1])
    payload = pickle.loads(path.read_bytes())
    from batem.core.utils import TimeSeriesPlotter

    # Match :meth:`~batem.core.data.DataProvider.plot` with no variable names:
    # interactive Tk checklist + Plotly figures on demand.
    TimeSeriesPlotter(
        variable_values=payload["variable_values"],
        datetimes=payload["datetimes"],
    )


if __name__ == "__main__":
    main()
