"""Small CLI helpers (e.g. subprocess workers for GUIs)."""
