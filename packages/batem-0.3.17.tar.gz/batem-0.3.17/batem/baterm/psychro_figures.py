"""Outdoor psychrometric (Givoni) chart via a **subprocess** worker (stable under cmd2)."""

from __future__ import annotations

import os
import pickle
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from batem.baterm.config import BATEM_REPO_ROOT


def show_context_psychro_figure(lpd: Any) -> None:
    """Build the Givoni chart in a child Python process, then open the PNG (no ``plt.show`` in baterm)."""
    if not bool(lpd("enable_psychrochart")):
        raise RuntimeError(
            "Psychrometric chart is disabled on this lambda-house dataset (enable_psychrochart=False). "
            "Enable it in the lambda-house parameters if you need this plot."
        )

    from batem.core.lambdahouse import plot_size

    dry_bulb_temperature_deg: list[float] = lpd("outdoor_temperatures_deg")
    absolute_humidity_kg_kg: list[float] = lpd("absolute_humidity_kg_kg")

    fd_pkl, pkl_path = tempfile.mkstemp(suffix=".pkl")
    os.close(fd_pkl)
    fd_png, out_png = tempfile.mkstemp(suffix=".png")
    os.close(fd_png)
    Path(out_png).unlink(missing_ok=True)

    payload = {
        "dry_bulb_temperature_deg": dry_bulb_temperature_deg,
        "absolute_humidity_kg_kg": absolute_humidity_kg_kg,
        "fig_width": float(plot_size[0]),
        "fig_height": float(plot_size[1]),
        "out_png": out_png,
    }
    Path(pkl_path).write_bytes(pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL))

    pp = os.environ.get("PYTHONPATH", "")
    env = {**os.environ, "PYTHONPATH": str(BATEM_REPO_ROOT) + (os.pathsep + pp if pp else "")}

    try:
        completed = subprocess.run(
            [sys.executable, "-m", "batem.tools.psychro_chart_worker", pkl_path],
            cwd=str(BATEM_REPO_ROOT),
            env=env,
            check=False,
            capture_output=True,
            text=True,
        )
        if completed.returncode != 0:
            msg = (completed.stderr or completed.stdout or "").strip() or f"exit {completed.returncode}"
            raise RuntimeError(f"Psychrometric worker failed: {msg}")
        if not Path(out_png).is_file():
            raise RuntimeError("Psychrometric worker did not write the PNG file.")

        if sys.platform == "darwin":
            subprocess.run(["open", out_png], check=False)
        elif os.name == "nt":
            os.startfile(out_png)  # type: ignore[attr-defined]
        else:
            subprocess.run(["xdg-open", out_png], check=False)
    finally:
        try:
            Path(pkl_path).unlink(missing_ok=True)
        except OSError:
            pass
