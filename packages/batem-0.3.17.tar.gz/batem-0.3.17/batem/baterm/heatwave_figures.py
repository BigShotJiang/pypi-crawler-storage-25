"""3-day min/max/avg felt temperature plot from :meth:`batem.core.lambdahouse.Analyzes.climate` (outdoor comfort)."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

import matplotlib.pyplot as plt
import numpy
from matplotlib.lines import Line2D

from batem.core.comfort import OutdoorTemperatureIndices


def show_context_heatwave_figure(lpd: Any) -> None:
    """Single time-series plot: 72 h rolling min/max/avg felt temperature + decile + tropical nights."""
    from batem.core.lambdahouse import plot_size

    datetimes: list[datetime] = lpd("datetimes")
    felt_temperatures_deg: list[float] = [
        OutdoorTemperatureIndices.feels_like(
            lpd("outdoor_temperatures_deg")[i],
            lpd("humidities_percentage")[i],
            lpd("wind_speeds_m_s")[i],
        )
        for i in range(len(datetimes))
    ]

    min_feel_like_temperatures_deg: list[float] = []
    max_feel_like_temperatures_deg: list[float] = []
    avg_feel_like_temperatures_deg: list[float] = []
    for i in range(len(datetimes)):
        if i < 72:
            min_feel_like_temperatures_deg.append(felt_temperatures_deg[i])
            max_feel_like_temperatures_deg.append(felt_temperatures_deg[i])
            avg_feel_like_temperatures_deg.append(felt_temperatures_deg[i])
        else:
            lo = i - 72
            window = felt_temperatures_deg[lo:i]
            min_feel_like_temperatures_deg.append(min(window))
            max_feel_like_temperatures_deg.append(max(window))
            avg_feel_like_temperatures_deg.append(sum(window) / 72)

    tropical_night_datetimes: list[datetime] = []
    tropical_night_threshold = 20.0
    outdoor_t = lpd("outdoor_temperatures_deg")

    current_date = None
    for i in range(len(datetimes)):
        dt = datetimes[i]
        date = dt.date()
        hour = dt.hour

        if hour == 18 and date != current_date:
            current_date = date
            night_end_idx = i
            for j in range(i, min(i + 15, len(datetimes))):
                if datetimes[j].date() == date + timedelta(days=1) and datetimes[j].hour == 6:
                    night_end_idx = j
                    break
            else:
                night_end_idx = min(i + 12, len(datetimes) - 1)

            night_temperatures = outdoor_t[i:night_end_idx + 1]
            if night_temperatures and min(night_temperatures) >= tropical_night_threshold:
                tropical_night_datetimes.append(dt)

    last_decile_feel_like_temperature: float = list(numpy.percentile(felt_temperatures_deg, [0, 90]))[-1]

    fig, axis = plt.subplots(figsize=(float(plot_size[0]), float(plot_size[1])))

    axis.plot(datetimes, min_feel_like_temperatures_deg, "r-", alpha=1, linewidth=2, label="3 days min felt temperature")
    axis.plot(datetimes, max_feel_like_temperatures_deg, "r--", alpha=0.7, linewidth=2, label="3 days max felt temperature")
    axis.plot(datetimes, avg_feel_like_temperatures_deg, "b-", alpha=0.7, linewidth=2, label="3 days avg felt temperature")
    axis.plot(
        [datetimes[0], datetimes[-1]],
        [last_decile_feel_like_temperature, last_decile_feel_like_temperature],
        "r-.",
        alpha=0.5,
        linewidth=1.5,
        label="Last decile threshold",
    )

    tropical_night_line = None
    for tropical_night_dt in tropical_night_datetimes:
        line = axis.axvline(x=tropical_night_dt, color="blue", linestyle="--", alpha=0.7, linewidth=2)
        if tropical_night_line is None:
            tropical_night_line = line

    if tropical_night_line is not None:
        tropical_night_proxy = Line2D([0], [0], color="blue", linestyle="--", linewidth=2, alpha=0.7, label="Tropical nights")
        handles, labels = axis.get_legend_handles_labels()
        handles.append(tropical_night_proxy)
        labels.append("Tropical nights")
        axis.legend(handles, labels)
    else:
        axis.legend()

    axis.set_xlabel("Time")
    axis.set_ylabel("Felt temperature (°C)")
    axis.set_title("3 days min/max/avg Felt temperature")
    axis.grid()
    plt.show()
