"""Helpers shared by cmd2 ``complete_*`` tab-completion methods."""

from __future__ import annotations


def completion_fragment_looks_pathish(fragment: str) -> bool:
    """True when a token is probably a filesystem path (shorthand ``context <path>``, ``load`` args, …)."""
    if not fragment:
        return False
    if fragment[0] in "/~":
        return True
    if fragment.startswith("."):
        return True
    if len(fragment) >= 2 and fragment[1] == ":":
        return True
    return False
