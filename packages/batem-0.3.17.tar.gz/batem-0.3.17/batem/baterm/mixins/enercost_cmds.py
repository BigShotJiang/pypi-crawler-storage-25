"""``enercost`` command: regulated tariff billing from HVAC and PV hourly series."""

from __future__ import annotations

import shlex

import prettytable

from batem.core.enercost import (
    ENERCOST_HOUR_VAR,
    GRID_EXPORT_KWH_VAR,
    GRID_IMPORT_KWH_VAR,
    HVAC_ELEC_BUILDING_VAR,
    PV_POWER_VAR,
    RegulatedElectricityTariff,
    RegulatedTariffOption,
    compute_enercost,
)


class EnercostCommandsMixin:
    def _parse_enercost_args(self, arg: str) -> RegulatedElectricityTariff | None:
        """Parse ``enercost [base|hp_hc] [--base €] [--hp €] [--hc €] [--export €]``."""
        tokens = shlex.split(arg)
        option = RegulatedTariffOption.HP_HC
        base_price = 0.2516
        hp_price = 0.2700
        hc_price = 0.2068
        export_price = 0.0
        i = 0
        while i < len(tokens):
            tok = tokens[i]
            if tok in ("base", "hp_hc"):
                option = RegulatedTariffOption.BASE if tok == "base" else RegulatedTariffOption.HP_HC
                i += 1
                continue
            if tok in ("--base", "--hp", "--hc", "--export") and i + 1 < len(tokens):
                try:
                    value = float(tokens[i + 1])
                except ValueError:
                    self.perror(f"Invalid number after {tok}: {tokens[i + 1]!r}")
                    return None
                if tok == "--base":
                    base_price = value
                elif tok == "--hp":
                    hp_price = value
                elif tok == "--hc":
                    hc_price = value
                else:
                    export_price = value
                i += 2
                continue
            self.perror(
                f"Unknown argument: {tok!r}. "
                "Usage: enercost [base|hp_hc] [--base €/kWh] [--hp €/kWh] [--hc €/kWh] [--export €/kWh]"
            )
            return None
        return RegulatedElectricityTariff(
            option=option,
            base_eur_per_kwh=base_price,
            hp_eur_per_kwh=hp_price,
            hc_eur_per_kwh=hc_price,
            export_eur_per_kwh=export_price,
        )

    def _enercost_register_on_dp(self, result) -> None:
        dp = self.data_provider
        if dp is None:
            return
        try:
            dp.add_var(ENERCOST_HOUR_VAR, list(result.hourly_cost_eur), force=True)
            dp.add_var(GRID_IMPORT_KWH_VAR, list(result.hourly_import_kwh), force=True)
            dp.add_var(GRID_EXPORT_KWH_VAR, list(result.hourly_export_kwh), force=True)
        except Exception as exc:  # noqa: BLE001
            self.pwarning(f"Could not register cost series on DataProvider: {exc}")
            return
        self.poutput(
            f"Registered {ENERCOST_HOUR_VAR}, {GRID_IMPORT_KWH_VAR}, {GRID_EXPORT_KWH_VAR} on DataProvider."
        )

    def _print_enercost_summary(self, result, tariff: RegulatedElectricityTariff) -> None:
        opt_label = "Base (single rate)" if tariff.option == RegulatedTariffOption.BASE else "HP / HC"
        table = prettytable.PrettyTable()
        table.field_names = ["metric", "value"]
        table.align["metric"] = "l"
        table.align["value"] = "r"
        rows = [
            ("tariff option", opt_label),
            ("HVAC electricity", f"{result.hvac_kwh:.0f} kWh"),
            ("PV production", f"{result.pv_kwh:.0f} kWh"),
            ("grid import", f"{result.grid_import_kwh:.0f} kWh"),
            ("grid export", f"{result.grid_export_kwh:.0f} kWh"),
            ("cost without PV", f"{result.cost_without_pv_eur:.2f} €"),
            ("cost with PV", f"{result.cost_with_pv_eur:.2f} €"),
            ("PV savings", f"{result.savings_eur:.2f} €"),
        ]
        if tariff.option == RegulatedTariffOption.BASE:
            rows.insert(1, ("import price", f"{tariff.base_eur_per_kwh:.4f} €/kWh"))
        else:
            rows.insert(1, ("HP price", f"{tariff.hp_eur_per_kwh:.4f} €/kWh"))
            rows.insert(2, ("HC price", f"{tariff.hc_eur_per_kwh:.4f} €/kWh"))
            rows.insert(
                3,
                ("off-peak hours", f"{tariff.off_peak_start_hour:02d}:00–{tariff.off_peak_end_hour:02d}:00"),
            )
        if tariff.export_eur_per_kwh > 0.0:
            rows.append(("export credit", f"{tariff.export_eur_per_kwh:.4f} €/kWh"))
        for row in rows:
            table.add_row(row)
        self.poutput(table)

    def help_enercost(self) -> None:
        """Help for the ``enercost`` command."""
        self.poutput(
            "\n".join(
                [
                    "enercost — annual electricity bill from building HVAC and PV.",
                    "",
                    "Requires a simulated building and PV on the same DataProvider:",
                    f"  {HVAC_ELEC_BUILDING_VAR}  (run 'building simulate')",
                    f"  {PV_POWER_VAR}            (run 'pv simulate')",
                    "",
                    "Usage:",
                    "  enercost [base|hp_hc] [options]",
                    "",
                    "Tariff options (French regulated retail, indicative default prices):",
                    "  hp_hc   Heures pleines / heures creuses (default; HC 22:00–06:00)",
                    "  base    Single energy price (option Base)",
                    "",
                    "Price overrides (€/kWh):",
                    "  --base <price>     Base option import price",
                    "  --hp <price>       Peak (HP) import price",
                    "  --hc <price>       Off-peak (HC) import price",
                    "  --export <price>   Surplus injection credit (default 0)",
                    "",
                    "Registers hourly series: ENERCOST:hour#sim, GRID_IMPORT:kWh#sim, GRID_EXPORT:kWh#sim",
                ]
            )
        )

    def do_enercost(self, arg: str) -> None:
        """Compute regulated-tariff cost from HVAC_ELEC and PV:power_W."""
        dp = self.data_provider
        if dp is None:
            self.perror("No DataProvider loaded. Load a context and run 'building simulate' first.")
            return
        tariff = self._parse_enercost_args(arg)
        if tariff is None and arg.strip():
            return
        if tariff is None:
            tariff = RegulatedElectricityTariff()

        missing: list[str] = []
        if HVAC_ELEC_BUILDING_VAR not in dp:
            missing.append(HVAC_ELEC_BUILDING_VAR)
        if PV_POWER_VAR not in dp:
            missing.append(PV_POWER_VAR)
        if missing:
            self.perror(
                "Missing series on DataProvider: " + ", ".join(missing) + ". "
                "Run 'building simulate' and 'pv simulate' first."
            )
            return

        hvac_wh = [float(dp(HVAC_ELEC_BUILDING_VAR, k)) for k in dp.ks]
        pv_w = [float(dp(PV_POWER_VAR, k)) for k in dp.ks]
        try:
            result = compute_enercost(
                hvac_wh,
                pv_w,
                tariff=tariff,
                datetimes=dp.datetimes,
                sample_time_in_secs=dp.sample_time_in_secs,
            )
        except ValueError as exc:
            self.perror(str(exc))
            return

        self._print_enercost_summary(result, tariff)
        self._enercost_register_on_dp(result)
