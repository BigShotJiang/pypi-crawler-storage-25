"""``pv`` command: PVplantData session management, simulation, and figures."""

from __future__ import annotations

import json
import shlex
import tempfile
from dataclasses import asdict
from pathlib import Path

from batem.core.building import ContextData

from batem.core.solar import PVplant, PVplantData, PVplantView

from batem.baterm.completion_utils import completion_fragment_looks_pathish
from batem.baterm.deserialize import (
    pvplant_data_from_json_str_data,
    pvplant_data_to_json_dict,
    run_python,
)
from batem.baterm.scripts import PVPLANT_3D_SCRIPT, PVPLANT_FORM_SCRIPT

PV_FILE_EXTENSION: str = ".pv"
# Hourly total plant power (W); registered on the DataProvider by ``pv simulate``.
PV_TOTAL_POWER_VAR: str = "PV:power_W"

_PV_SUBCOMMANDS: tuple[str, ...] = (
    "new",
    "edit",
    "load",
    "save",
    "delete",
    "dir",
    "3d",
    "simulate",
    "heliodon",
    "results",
    "plot",
    "vars",
)


class PvCommandsMixin:
    @staticmethod
    def _context_data_equal(left: ContextData, right: ContextData) -> bool:
        """Compare site context payloads (JSON round-trip handles NaN fields)."""
        return json.dumps(asdict(left), sort_keys=True) == json.dumps(asdict(right), sort_keys=True)

    def _clear_pv_simulation_cache(self) -> None:
        self._pv_plant = None
        self._pv_powers_W = None

    def _sync_context_from_pv_data(self) -> None:
        if self.pv_plant_data is None:
            return
        new_context = self.pv_plant_data.context_data
        context_changed = (
            self.context_data is None
            or not self._context_data_equal(self.context_data, new_context)
        )
        self.context_data = new_context
        if context_changed or self.building is None:
            self._refresh_building()

    @staticmethod
    def _with_pv_suffix(path: Path) -> Path:
        """Ensure ``path`` uses the ``.pv`` extension (``myplant`` → ``myplant.pv``)."""
        if path.suffix.lower() == PV_FILE_EXTENSION:
            return path
        return path.with_suffix(PV_FILE_EXTENSION)

    @staticmethod
    def _list_pv_files(folder: Path) -> list[Path]:
        """Return regular files in ``folder`` whose extension is exactly ``.pv``."""
        return sorted(
            (
                path
                for path in folder.iterdir()
                if path.is_file() and path.suffix.lower() == PV_FILE_EXTENSION
            ),
            key=lambda path: path.name.lower(),
        )

    def _ensure_context_for_pv(self) -> bool:
        """Ensure a site :class:`ContextData` exists; open the context form if needed."""
        if self.context_data is not None:
            return True
        self.poutput(
            "No site context loaded. Open the context editor first "
            "(or use 'context load <path>' / 'context new')."
        )
        context_data: ContextData | None = self._open_context_form(blank=True)
        if context_data is None:
            self.poutput("PV plant creation canceled (site context is required).")
            return False
        self.context_data = context_data
        self._refresh_building()
        self.poutput(f"Context set: {context_data.location} (year {context_data.simulated_year}).")
        return True

    def _open_pv_form(self, *, blank: bool = False, lock_context: bool = False) -> PVplantData | None:
        with tempfile.TemporaryDirectory(prefix="baterm_pv_") as tmp_dir:
            inp = Path(tmp_dir) / "input.json"
            out = Path(tmp_dir) / "output.json"
            if blank or self.pv_plant_data is None:
                initial_payload = None
            else:
                initial_payload = pvplant_data_to_json_dict(self.pv_plant_data)
            fixed_context: ContextData | None = None
            if lock_context:
                fixed_context = self.context_data
                if fixed_context is None and self.pv_plant_data is not None:
                    fixed_context = self.pv_plant_data.context_data
            payload: dict[str, object] = {
                "initial": initial_payload,
                "fixed_context_data": asdict(fixed_context) if fixed_context is not None else None,
                "edit_context": not lock_context,
            }
            inp.write_text(json.dumps(payload), encoding="utf-8")
            if run_python(PVPLANT_FORM_SCRIPT, str(inp), str(out)) != 0 or not out.exists():
                return None
            return pvplant_data_from_json_str_data(json.loads(out.read_text(encoding="utf-8")))

    def _load_pv_file(self, path: Path) -> bool:
        path = self._with_pv_suffix(path.expanduser())
        if not path.exists():
            self.perror(f"File not found: {path}")
            return False
        try:
            self.pv_plant_data = pvplant_data_from_json_str_data(json.loads(path.read_text(encoding="utf-8")))
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not load PV plant from {path}: {exc}")
            return False
        self._clear_pv_simulation_cache()
        self._sync_context_from_pv_data()
        self.poutput(f"PV plant loaded: {path}")
        return True

    def _save_pv_file(self, path: Path) -> bool:
        if self.pv_plant_data is None:
            self.perror("No PV plant data to save. Use 'pv new', 'pv load <path>', or 'pv <path>' first.")
            return False
        path = self._with_pv_suffix(path.expanduser())
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(pvplant_data_to_json_dict(self.pv_plant_data), indent=2), encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not save PV plant to {path}: {exc}")
            return False
        self.poutput(f"PV plant saved: {path}")
        return True

    def _new_pv(self) -> None:
        if not self._ensure_context_for_pv():
            return
        pv_data = self._open_pv_form(blank=True, lock_context=True)
        if pv_data is None:
            self.poutput("PV plant creation canceled.")
            return
        self.pv_plant_data = pv_data
        self._clear_pv_simulation_cache()
        self._sync_context_from_pv_data()
        self.poutput("PV plant created from GUI editor.")

    def _edit_pv(self) -> None:
        if self.pv_plant_data is None:
            self.perror("No PV plant loaded. Use 'pv new' or 'pv load <path>' first.")
            return
        if self.context_data is None:
            self.context_data = self.pv_plant_data.context_data
            if self.building_data is not None:
                self._refresh_building()
        pv_data = self._open_pv_form(lock_context=True)
        if pv_data is None:
            self.poutput("PV plant edit canceled.")
            return
        self.pv_plant_data = pv_data
        self._clear_pv_simulation_cache()
        self._sync_context_from_pv_data()
        self.poutput("PV plant updated from GUI editor.")

    def _delete_pv(self) -> None:
        if self.pv_plant_data is None:
            self.poutput("No PV plant loaded.")
            return
        self.pv_plant_data = None
        self._clear_pv_simulation_cache()
        self.poutput("PV plant deleted from memory.")

    def _pv_dir(self, folder: Path | None = None) -> None:
        """List ``.pv`` plant files in ``folder`` (default: current working directory)."""
        root = (folder if folder is not None else Path.cwd()).expanduser()
        if not root.exists():
            self.perror(f"Folder not found: {root}")
            return
        if not root.is_dir():
            self.perror(f"Not a folder: {root}")
            return
        files = self._list_pv_files(root)
        if not files:
            self.poutput(f"No {PV_FILE_EXTENSION} files found in {root}.")
            return
        import prettytable

        table = prettytable.PrettyTable()
        table.field_names = ["#", "name", "size"]
        for index, path in enumerate(files, start=1):
            table.add_row([index, path.name, path.stat().st_size])
        table.align["name"] = "l"
        table.align["size"] = "r"
        self.poutput(f"{PV_FILE_EXTENSION} files in {root}:")
        self.poutput(table)

    def _require_pv_data(self) -> PVplantData | None:
        if self.pv_plant_data is None:
            self.perror("No PV plant loaded. Use 'pv new' or 'pv load <path>' first.")
            return None
        return self.pv_plant_data

    def _get_pv_plant(self) -> PVplant | None:
        pv_data = self._require_pv_data()
        if pv_data is None:
            return None
        if self._pv_plant is None:
            try:
                self._pv_plant = pv_data.pv_plant_maker()
            except Exception as exc:  # noqa: BLE001
                self.perror(f"Could not build PV plant model: {exc}")
                return None
        return self._pv_plant

    def _register_pv_series_on_data_provider(
        self, plant: PVplant, total_powers_W: list[float],
    ) -> bool:
        """Write per-collector and total PV power series onto the session :attr:`data_provider`."""
        dp = self.data_provider
        if dp is None:
            self.perror(
                "No DataProvider to register PV results. Reload the PV plant context first."
            )
            return False
        collector_powers = plant.solar_system.powers_W(gather_collectors=False)
        if not isinstance(collector_powers, dict):
            self.perror("Unexpected collector layout from powers_W(gather_collectors=False).")
            return False
        try:
            for name, series in collector_powers.items():
                dp.add_var(name, list(series), force=True)
            dp.add_var(PV_TOTAL_POWER_VAR, list(total_powers_W), force=True)
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not register PV series on DataProvider: {exc}")
            return False
        n_collectors = len(collector_powers)
        self.poutput(
            f"Registered {n_collectors} collector series and {PV_TOTAL_POWER_VAR} "
            f"on DataProvider ({dp.location})."
        )
        return True

    def _print_pv_summary(self) -> None:
        pv_data = self.pv_plant_data
        if pv_data is None:
            return
        ctx = pv_data.context_data
        table_rows: list[tuple[str, str]] = [
            ("context", f"{ctx.location} ({ctx.latitude_north_deg:g}°N, {ctx.longitude_east_deg:g}°E), year {ctx.simulated_year}"),
            ("mount_type", pv_data.mount_type.name.lower()),
            ("exposure_deg", f"{pv_data.exposure_deg:g}"),
            ("slope_deg", f"{pv_data.slope_deg:g}"),
            ("number_of_panels", str(pv_data.number_of_panels)),
            ("peak_power_kW", f"{pv_data.peak_power_kW:g}"),
            ("surface_pv_m2", f"{pv_data.surface_pv_m2:g}"),
            ("distance_between_arrays_m", f"{pv_data.distance_between_arrays_m:g}"),
        ]
        plant = self._get_pv_plant()
        if plant is not None:
            zones = PVplantView(plant).zone_panel_counts()
            table_rows.append(("zones (front/middle/rear)", f"{zones['front']} / {zones['middle']} / {zones['rear']}"))
        import prettytable

        table = prettytable.PrettyTable()
        table.field_names = ["field", "value"]
        for name, value in table_rows:
            table.add_row([name, value])
        table.align["field"] = "l"
        table.align["value"] = "l"
        self.poutput("PVplantData:")
        self.poutput(table)
        if self._pv_powers_W is not None:
            self.poutput(f"Cached annual production: {sum(self._pv_powers_W) / 1000:.1f} kWh (run 'pv simulate' to refresh).")

    def _pv_3d(self) -> None:
        if self.pv_plant_data is None:
            self.perror("No PV plant loaded. Use 'pv new' or 'pv load <path>' first.")
            return
        payload = pvplant_data_to_json_dict(self.pv_plant_data)
        with tempfile.TemporaryDirectory(prefix="baterm_pv3d_") as tmp_dir:
            inp = Path(tmp_dir) / "input.json"
            inp.write_text(json.dumps(payload), encoding="utf-8")
            try:
                run_python(PVPLANT_3D_SCRIPT, str(inp))
            except Exception as exc:  # noqa: BLE001
                self.perror(f"Could not render PV 3D layout: {exc}")

    def _pv_simulate(self) -> None:
        plant = self._get_pv_plant()
        if plant is None:
            return
        try:
            powers = plant.powers_W()
            if isinstance(powers, dict):
                self.perror("Unexpected collector dict from powers_W(); expected a flat power series.")
                return
            self._pv_powers_W = list(powers)
            if not self._register_pv_series_on_data_provider(plant, self._pv_powers_W):
                return
            self.poutput(f"Annual PV production: {sum(self._pv_powers_W) / 1000:.1f} kWh")
            plant.print_month_hour_power_W()
        except Exception as exc:  # noqa: BLE001
            self.perror(f"PV simulation failed: {exc}")

    def _pv_results(self) -> None:
        plant = self._get_pv_plant()
        if plant is None:
            return
        self.poutput(str(plant))
        if self._pv_powers_W is None:
            self.poutput("No cached hourly production. Run 'pv simulate' for kWh totals and monthly table.")
            return
        self.poutput(f"Total production: {sum(self._pv_powers_W) / 1000:.1f} kWh")

    def _pv_heliodon(self) -> None:
        pv_data = self._require_pv_data()
        if pv_data is None:
            return
        import matplotlib.pyplot as plt

        try:
            solar_model = pv_data.solar_model
        except Exception as exc:  # noqa: BLE001
            self.perror(f"No solar model available: {exc}")
            return
        ctx = pv_data.context_data
        solar_model.plot_heliodon(
            name=ctx.location or "PV site",
            year=int(ctx.simulated_year),
            observer_elevation_m=0.0,
            mask=None,
        )
        plt.show()

    def _pv_plot(self) -> None:
        if self._require_pv_data() is None:
            return
        dp = self.data_provider
        if dp is None:
            self.perror("No DataProvider. Load the PV plant (or its context) first.")
            return
        self._time_series_plot_worker_subprocess(
            dp,
            origin="pv",
            empty_message=(
                "No plottable PV variables in the DataProvider. Run 'pv simulate' first."
            ),
        )

    def help_pv(self) -> None:
        lines: list[str] = [
            "pv — manage a photovoltaic plant (PVplantData / PVplant).",
            "",
            "Usage:",
            "  pv                              Summary of the current PV plant.",
            "  pv <path>                       Shorthand for 'pv load <path>'.",
            "",
            "State management:",
            "  pv new                          GUI editor (requires session context; see Notes).",
            "  pv edit                         GUI editor for the current plant.",
            f"  pv load <path>                  Load a {PV_FILE_EXTENSION} JSON file (extension added if missing).",
            f"  pv save <path>                  Save to {PV_FILE_EXTENSION} (extension added if missing).",
            "  pv delete                       Forget the current PV plant (keeps context if synced).",
            f"  pv dir [folder]                 List {PV_FILE_EXTENSION} files only (default: cwd).",
            "",
            "Analysis & figures:",
            "  pv 3d                           3D schematic layout (PVplantView).",
            "  pv simulate                     Hourly PV power (collectors + PV:power_W on DataProvider).",
            "  pv results                      Plant description and cached production total.",
            "  pv heliodon                     Sun-path diagram for the embedded site context.",
            "  pv plot                         Time-series picker (PV collector variables only; see 'pv vars').",
            "  pv vars                         List DataProvider variables from the PV plant (collectors).",
            "",
            "Notes:",
            "  - 'pv new' requires a site context: load/create one first, or the context editor opens automatically.",
            "  - The PV form does not edit context (use 'context edit'); it only configures the array.",
            "  - Loading or editing a PV plant also sets the session ContextData from its embedded context.",
            f"  - Paths for load/save may omit {PV_FILE_EXTENSION}; it is appended automatically.",
            f"  - Use 'pv dir' (or workspace 'dir') to browse {PV_FILE_EXTENSION} plant files.",
        ]
        self.poutput("\n".join(lines))

    def do_pv(self, arg: str) -> None:
        """Manage the current PV plant (see ``help pv``)."""
        usage = (
            "Usage: pv | pv new | pv edit | pv load <path> | pv save <path> | pv delete | pv dir [folder] | "
            "pv 3d | pv simulate | pv heliodon | pv results | pv plot | pv vars | pv <path>"
        )
        tokens = shlex.split(arg)
        if not tokens:
            if self.pv_plant_data is None:
                self.poutput("No PV plant loaded.")
                return
            self._print_pv_summary()
            return

        action, *rest = tokens
        if action == "new":
            if rest:
                self.perror("Usage: pv new")
                return
            self._new_pv()
            return
        if action == "edit":
            if rest:
                self.perror("Usage: pv edit")
                return
            self._edit_pv()
            return
        if action == "load":
            if len(rest) != 1:
                self.perror("Usage: pv load <path>")
                return
            self._load_pv_file(Path(rest[0]))
            return
        if action == "save":
            if len(rest) != 1:
                self.perror("Usage: pv save <path>")
                return
            self._save_pv_file(Path(rest[0]))
            return
        if action == "delete":
            if rest:
                self.perror("Usage: pv delete")
                return
            self._delete_pv()
            return
        if action == "dir":
            if len(rest) > 1:
                self.perror("Usage: pv dir [folder]")
                return
            folder = Path(rest[0]).expanduser() if rest else None
            self._pv_dir(folder)
            return
        if action == "3d":
            if rest:
                self.perror("Usage: pv 3d")
                return
            self._pv_3d()
            return
        if action == "simulate":
            if rest:
                self.perror("Usage: pv simulate")
                return
            self._pv_simulate()
            return
        if action == "heliodon":
            if rest:
                self.perror("Usage: pv heliodon")
                return
            self._pv_heliodon()
            return
        if action == "results":
            if rest:
                self.perror("Usage: pv results")
                return
            self._pv_results()
            return
        if action == "plot":
            if rest:
                self.perror("Usage: pv plot")
                return
            self._pv_plot()
            return
        if action == "vars":
            if rest:
                self.perror("Usage: pv vars")
                return
            if self.pv_plant_data is None:
                self.perror("No PV plant loaded. Use 'pv new' or 'pv load <path>' first.")
                return
            self._print_data_provider_vars("pv")
            return

        if len(tokens) != 1:
            self.perror(usage)
            return
        self._load_pv_file(Path(action))

    def complete_pv(self, text: str, line: str, begidx: int, endidx: int) -> list[str]:
        tokens, _raw = self.tokens_for_completion(line, begidx, endidx)
        if not tokens:
            return []
        if len(tokens) == 2:
            frag = tokens[1]
            if frag == "":
                return list(_PV_SUBCOMMANDS)
            if completion_fragment_looks_pathish(frag):
                return self.path_complete(text, line, begidx, endidx)
            return [v for v in _PV_SUBCOMMANDS if v.startswith(frag)]
        if len(tokens) >= 3 and tokens[1] in ("load", "save", "dir"):
            return self._complete_pv_paths(text, line, begidx, endidx)
        return []

    def _complete_pv_paths(self, text: str, line: str, begidx: int, endidx: int) -> list[str]:
        """Tab-complete paths, preferring existing ``.pv`` files when the fragment has no extension."""
        completions = self.path_complete(text, line, begidx, endidx)
        if not completions or "." in text.split("/")[-1].split("\\")[-1]:
            return completions
        extra: list[str] = []
        for entry in completions:
            candidate = Path(entry)
            if candidate.suffix:
                continue
            pv_name = str(candidate) + PV_FILE_EXTENSION
            if Path(pv_name).exists() and pv_name not in completions:
                extra.append(pv_name)
        return completions + extra
