"""``sidemask`` command, 3D preview, and shared mask collection helpers."""

from __future__ import annotations

import json
import shlex
import tempfile
from dataclasses import asdict
from math import isfinite
from pathlib import Path

import prettytable
from prettytable.prettytable import PrettyTable

from batem.core.building import SideMaskData

from batem.baterm.deserialize import run_python
from batem.baterm.completion_utils import completion_fragment_looks_pathish
from batem.baterm.scripts import PLOT_SIDE_MASKS_SCRIPT, SIDEMASK_FORM_SCRIPT

_SIDEMASK_SUBCOMMANDS: tuple[str, ...] = ("new", "edit", "load", "save", "delete", "3d")


class SideMaskCommandsMixin:
    def _open_sidemask_form(self, initial: SideMaskData | None = None) -> SideMaskData | None:
        """Open :meth:`SideMaskData.form` in a child Python process and return the result."""
        with tempfile.TemporaryDirectory(prefix="baterm_sidemask_") as tmp_dir:
            inp = Path(tmp_dir) / "input.json"
            out = Path(tmp_dir) / "output.json"
            inp.write_text(
                json.dumps(asdict(initial) if initial is not None else None),
                encoding="utf-8",
            )
            if run_python(SIDEMASK_FORM_SCRIPT, str(inp), str(out)) != 0 or not out.exists():
                return None
            return SideMaskData(**json.loads(out.read_text(encoding="utf-8")))

    def _collect_side_masks(self, highlight: SideMaskData | None) -> list[SideMaskData]:
        """Return all known side masks deduplicated, with ``highlight`` placed last."""
        seen: list[dict] = []
        unique: list[SideMaskData] = []
        sources: list[list[SideMaskData]] = [self.side_masks]
        if self.context_data is not None:
            sources.append(self.context_data.side_masks)
        for source in sources:
            for mask in source:
                payload = asdict(mask)
                if payload in seen:
                    continue
                seen.append(payload)
                unique.append(mask)
        if highlight is not None:
            highlight_payload = asdict(highlight)
            unique = [m for m in unique if asdict(m) != highlight_payload] + [highlight]
        return unique

    @staticmethod
    def _format_mask_value(value: float | str) -> str:
        if isinstance(value, float):
            return "" if not isfinite(value) else f"{value:g}"
        return str(value)

    def _print_side_masks_table(self, *, highlight: SideMaskData | None = None) -> None:
        """Print all known side masks as a PrettyTable."""
        masks = self._collect_side_masks(highlight)
        if not masks:
            self.poutput("No side masks.")
            return

        table: PrettyTable = prettytable.PrettyTable()
        table.field_names = [
            "#",
            "name",
            "x",
            "y",
            "width",
            "height",
            "elev.",
            "exposure",
            "slope",
            "normal angle",
        ]
        for index, mask in enumerate(masks, start=1):
            table.add_row(
                [
                    index,
                    mask.name or "",
                    self._format_mask_value(mask.x_center),
                    self._format_mask_value(mask.y_center),
                    self._format_mask_value(mask.width),
                    self._format_mask_value(mask.height),
                    self._format_mask_value(mask.elevation),
                    self._format_mask_value(mask.exposure_deg),
                    self._format_mask_value(mask.slope_deg),
                    self._format_mask_value(mask.normal_angle_with_south_deg),
                ]
            )
        table.align = "r"
        table.align["name"] = "l"
        self.poutput(table)

    def _plot_side_masks_3d(
        self,
        *,
        highlight: SideMaskData | None = None,
        names: list[str] | None = None,
    ) -> None:
        """Render the 3D preview in a child Python process so the cmd2 loop stays responsive."""
        masks = self._collect_side_masks(highlight)
        if names:
            requested = list(dict.fromkeys(names))
            available = {mask.name for mask in masks if mask.name}
            missing = [n for n in requested if n not in available]
            if missing:
                self.perror(f"Unknown side mask name(s): {', '.join(missing)}.")
            kept = set(requested) - set(missing)
            masks = [mask for mask in masks if mask.name in kept]
        if not masks:
            self.poutput("No side masks to display.")
            return
        payload = {
            "masks": [asdict(mask) for mask in masks],
            "highlight": asdict(highlight) if highlight is not None else None,
        }
        with tempfile.TemporaryDirectory(prefix="baterm_sidemask_plot_") as tmp_dir:
            inp = Path(tmp_dir) / "input.json"
            inp.write_text(json.dumps(payload), encoding="utf-8")
            try:
                run_python(PLOT_SIDE_MASKS_SCRIPT, str(inp))
            except Exception as exc:  # noqa: BLE001
                self.perror(f"Could not render 3D preview: {exc}")

    @staticmethod
    def _unique_side_mask_name(name: str, existing_names: set[str]) -> str:
        """Return ``name`` if free, otherwise append ``_N`` until it is unique."""
        if name not in existing_names:
            return name
        counter = 2
        while f"{name}_{counter}" in existing_names:
            counter += 1
        return f"{name}_{counter}"

    @staticmethod
    def _with_sidemask_suffix(path: Path) -> Path:
        """Ensure ``path`` ends with the ``.sidemask`` extension."""
        return path if path.suffix == ".sidemask" else path.with_suffix(path.suffix + ".sidemask")

    def _find_sidemask_by_name(self, name: str) -> SideMaskData | None:
        """Return the first known mask matching ``name`` (session list first, then context)."""
        for mask in self.side_masks:
            if mask.name == name:
                return mask
        if self.context_data is not None:
            for mask in self.context_data.side_masks:
                if mask.name == name:
                    return mask
        return None

    def _remove_sidemask_by_name(self, name: str) -> bool:
        """Remove every mask called ``name`` from session and context lists."""
        before_session = len(self.side_masks)
        self.side_masks = [m for m in self.side_masks if m.name != name]
        removed = len(self.side_masks) != before_session
        if self.context_data is not None:
            before_context = len(self.context_data.side_masks)
            self.context_data.side_masks = [m for m in self.context_data.side_masks if m.name != name]
            if len(self.context_data.side_masks) != before_context:
                removed = True
                self._refresh_building()
        return removed

    def _register_sidemask(self, sidemask: SideMaskData) -> bool:
        """Append ``sidemask`` to the session and context lists with dedup + rename."""
        existing_masks = self._collect_side_masks(highlight=None)
        existing_payloads = [asdict(mask) for mask in existing_masks]
        existing_names = {mask.name for mask in existing_masks if mask.name}

        if asdict(sidemask) in existing_payloads:
            self.poutput("Side mask already exists; ignored.")
            return False

        if sidemask.name and sidemask.name in existing_names:
            unique_name = self._unique_side_mask_name(sidemask.name, existing_names)
            self.poutput(f"Renamed side mask '{sidemask.name}' -> '{unique_name}' for uniqueness.")
            sidemask.name = unique_name

        self.side_masks.append(sidemask)
        self.poutput(f"Side mask added (total: {len(self.side_masks)}).")

        if self.context_data is None:
            self.poutput("No context loaded yet; side mask not attached to a ContextData.")
        else:
            self.context_data.side_masks.append(sidemask)
            self.poutput("Side mask appended to context_data.side_masks.")
            self._refresh_building()
        return True

    def _sidemask_new(self) -> None:
        sidemask = self._open_sidemask_form()
        if sidemask is None:
            self.poutput("Side mask creation canceled.")
            return
        if not self._register_sidemask(sidemask):
            return
        self._print_side_masks_table(highlight=sidemask)

    def _sidemask_edit(self, name: str) -> None:
        existing = self._find_sidemask_by_name(name)
        if existing is None:
            self.perror(f"Side mask not found: {name!r}.")
            return
        edited = self._open_sidemask_form(initial=existing)
        if edited is None:
            self.poutput("Side mask edit canceled.")
            return
        self._remove_sidemask_by_name(name)
        if not self._register_sidemask(edited):
            return
        self._print_side_masks_table(highlight=edited)
        self._plot_side_masks_3d(highlight=edited)

    def _sidemask_load(self, name: str) -> None:
        path = self._with_sidemask_suffix(Path(name).expanduser())
        if not path.exists():
            self.perror(f"File not found: {path}")
            return
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            sidemask = SideMaskData(**payload)
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not load side mask from {path}: {exc}")
            return
        self.poutput(f"Side mask loaded: {path}")
        if not self._register_sidemask(sidemask):
            return
        self._print_side_masks_table(highlight=sidemask)
        self._plot_side_masks_3d(highlight=sidemask)

    def _sidemask_delete(self, name: str) -> None:
        if not self._remove_sidemask_by_name(name):
            self.perror(f"Side mask not found: {name!r}.")
            return
        self.poutput(f"Side mask deleted: {name}")
        self._print_side_masks_table()

    def _sidemask_save_one(self, mask: SideMaskData) -> bool:
        """Write one mask to ``<mask.name>.sidemask`` in the current folder."""
        if not mask.name:
            self.perror("Cannot save side mask with empty name.")
            return False
        path = self._with_sidemask_suffix(Path(mask.name).expanduser())
        try:
            path.write_text(json.dumps(asdict(mask), indent=2), encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not save side mask {mask.name!r} to {path}: {exc}")
            return False
        self.poutput(f"Side mask saved: {path}")
        return True

    def _sidemask_save(self, names: list[str]) -> None:
        """Save the given masks (or every mask in memory when ``names`` is empty)."""
        all_masks = self._collect_side_masks(highlight=None)
        if not names:
            named_masks = [mask for mask in all_masks if mask.name]
            unnamed_count = len(all_masks) - len(named_masks)
            if not named_masks:
                self.perror("No named side masks to save.")
                return
            for mask in named_masks:
                self._sidemask_save_one(mask)
            if unnamed_count:
                self.poutput(f"Skipped {unnamed_count} side mask(s) without a name.")
            return

        masks_by_name: dict[str, SideMaskData] = {}
        for mask in all_masks:
            if mask.name and mask.name not in masks_by_name:
                masks_by_name[mask.name] = mask

        for name in names:
            mask = masks_by_name.get(name)
            if mask is None:
                self.perror(f"Side mask not found: {name!r}.")
                continue
            self._sidemask_save_one(mask)

    def do_sidemask(self, arg: str) -> None:
        """Manage side masks via sub-commands."""
        usage = (
            "Usage: sidemask | "
            "sidemask new | "
            "sidemask edit <name> | "
            "sidemask load <name> | "
            "sidemask save [<name> ...] | "
            "sidemask delete <name> | "
            "sidemask 3d [<name> ...]"
        )
        tokens = shlex.split(arg)
        if not tokens:
            self._print_side_masks_table()
            return

        action, *rest = tokens
        if action == "new":
            if rest:
                self.perror("Usage: sidemask new")
                return
            self._sidemask_new()
            return
        if action == "edit":
            if len(rest) != 1:
                self.perror("Usage: sidemask edit <name>")
                return
            self._sidemask_edit(rest[0])
            return
        if action == "load":
            if len(rest) != 1:
                self.perror("Usage: sidemask load <name>")
                return
            self._sidemask_load(rest[0])
            return
        if action == "save":
            self._sidemask_save(rest)
            return
        if action == "delete":
            if len(rest) != 1:
                self.perror("Usage: sidemask delete <name>")
                return
            self._sidemask_delete(rest[0])
            return
        if action == "3d":
            self._plot_side_masks_3d(names=rest)
            return

        self.perror(f"Unknown sidemask action: {action!r}.")
        self.perror(usage)

    def _known_sidemask_names(self) -> list[str]:
        return sorted({m.name for m in self._collect_side_masks(highlight=None) if m.name})

    def complete_sidemask(self, text: str, line: str, begidx: int, endidx: int) -> list[str]:
        """Tab-complete ``sidemask`` subcommands, paths for ``load``, and mask names where relevant."""
        tokens, _raw = self.tokens_for_completion(line, begidx, endidx)
        if not tokens:
            return []
        if len(tokens) == 2:
            frag = tokens[1]
            if frag == "":
                return list(_SIDEMASK_SUBCOMMANDS)
            if completion_fragment_looks_pathish(frag):
                return self.path_complete(text, line, begidx, endidx)
            return [v for v in _SIDEMASK_SUBCOMMANDS if v.startswith(frag)]
        if len(tokens) >= 3:
            action = tokens[1]
            if action == "load":
                return self.path_complete(text, line, begidx, endidx)
            if action in ("edit", "delete"):
                frag = tokens[-1]
                return [n for n in self._known_sidemask_names() if n.startswith(frag)]
            if action == "3d":
                frag = tokens[-1]
                return [n for n in self._known_sidemask_names() if n.startswith(frag)]
            if action == "save":
                frag = tokens[-1]
                return [n for n in self._known_sidemask_names() if n.startswith(frag)]
        return []
