"""cmd2 mixins for :class:`batem.baterm.app.Baterm` (one module per command family)."""

from batem.baterm.mixins.building_cmds import BuildingCommandsMixin
from batem.baterm.mixins.context_cmds import ContextCommandsMixin
from batem.baterm.mixins.enercost_cmds import EnercostCommandsMixin
from batem.baterm.mixins.plotting import PlottingMixin
from batem.baterm.mixins.pv_cmds import PvCommandsMixin
from batem.baterm.mixins.sidemask_cmds import SideMaskCommandsMixin
from batem.baterm.mixins.summary import SummaryMixin
from batem.baterm.mixins.workspace_cmds import WorkspaceCommandsMixin

__all__ = [
    "BuildingCommandsMixin",
    "ContextCommandsMixin",
    "EnercostCommandsMixin",
    "PlottingMixin",
    "PvCommandsMixin",
    "SideMaskCommandsMixin",
    "SummaryMixin",
    "WorkspaceCommandsMixin",
]
