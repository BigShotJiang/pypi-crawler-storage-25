"""Workspace helpers: ``load``, ``dir``, ``status``, ``vars``, ``plot``, ``workshops``, ``script``, ``run``."""

from __future__ import annotations

import os
import shlex
import subprocess
import sys
from pathlib import Path

import prettytable
from cmd2 import Cmd2ArgumentParser, with_argparser
from prettytable.prettytable import PrettyTable

from batem.baterm.config import BATEM_PACKAGE_DIR, BATEM_REPO_ROOT
from batem.baterm.workshops import list_workshop_notebooks, resolve_workshop_notebook
from batem.core.data import DataProvider


class WorkspaceCommandsMixin:
    @staticmethod
    def _workshops_root() -> Path:
        """Directory where ``workshop*.ipynb`` notebooks are discovered (process cwd)."""
        return Path.cwd().resolve()

    load_parser: Cmd2ArgumentParser = Cmd2ArgumentParser()
    load_parser.add_argument("path", help="Path to a file to load")

    _DIR_SCRIPT_SUFFIXES: frozenset[str] = frozenset({".context", ".building", ".pv", ".baterm"})
    _SHELL_SCRIPT_SUFFIXES: frozenset[str] = frozenset({".sh", ".bash", ".zsh", ".bat", ".cmd"})

    @with_argparser(load_parser)
    def do_load(self, args) -> None:
        """Load a file."""
        path = Path(args.path).expanduser()
        if not path.exists():
            self.perror(f"File not found: {path}")
            return
        self.current_file = path
        self.poutput(f"Loaded: {path}")

    def do_dir(self, arg: str) -> None:
        """List workspace script files (.context, .building, .pv, .baterm)."""
        tokens: list[str] = shlex.split(arg)
        if len(tokens) > 1:
            self.perror("Usage: dir [folder]")
            return

        folder: Path = Path(tokens[0]).expanduser() if tokens else Path.cwd()
        if not folder.exists():
            self.perror(f"Folder not found: {folder}")
            return
        if not folder.is_dir():
            self.perror(f"Not a folder: {folder}")
            return

        files: list[Path] = sorted(
            [path for path in folder.iterdir() if path.is_file() and path.suffix in self._DIR_SCRIPT_SUFFIXES],
            key=lambda path: (path.suffix, path.name.lower()),
        )
        if not files:
            self.poutput(f"No .context, .building, .pv, or .baterm files found in {folder}.")
            return

        table: PrettyTable = prettytable.PrettyTable()
        table.field_names = ["#", "name", "type", "size"]
        for index, path in enumerate(files, start=1):
            table.add_row([index, path.stem, path.suffix.lstrip("."), path.stat().st_size])
        table.align["name"] = "l"
        table.align["type"] = "l"
        table.align["size"] = "r"
        self.poutput(f"Files in {folder}:")
        self.poutput(table)

    def do_status(self, arg: str) -> None:
        """Show current state."""
        self.poutput(f"Current file: {self.current_file}" if self.current_file else "No file loaded.")
        self.poutput(
            f"Context location: {self.context_data.location}" if self.context_data else "No context loaded."
        )
        if self.building is not None:
            self.poutput("Model: full Building (simulation-ready).")
        elif self.data_provider is not None:
            self.poutput("Weather: loaded (context-only DataProvider).")
        else:
            self.poutput("Weather: not loaded (load a context first).")
        self.poutput(f"Side masks (session): {len(self.side_masks)}")
        if self.pv_plant_data is not None:
            self.poutput(
                f"PV plant: {self.pv_plant_data.number_of_panels} panels, "
                f"{self.pv_plant_data.mount_type.name.lower()} mount"
            )
        else:
            self.poutput("PV plant: not loaded.")

    _BUILDING_VAR_PREFIXES: tuple[str, ...] = (
        "GAIN_SOLAR:",
        "GAIN_OCCUPANCY:",
        "GAIN:",
        "PCO2:",
        "PRESENCE:",
        "OCCUPANCY:",
        "PHVAC:",
        "HVAC_ELEC:",
        "PSOLW:",
        "TZ:",
        "TZ_OP:",
    )

    def _is_pv_series_name(self, name: str) -> bool:
        """True if ``name`` matches a :class:`~batem.core.solar.PVplant` collector or total power series."""
        if self.pv_plant_data is None and self._pv_plant is None:
            return False
        if name.startswith("PV:"):
            return True
        if name in ("front_clear", "rear_clear"):
            return True
        return name.startswith(("front_shadow", "rear_shadow"))

    def _is_building_series_name(self, name: str) -> bool:
        """True if ``name`` was produced by the building pipeline (inputs or ``#sim`` outputs)."""
        if name.endswith("#sim"):
            return True
        return any(name.startswith(prefix) for prefix in self._BUILDING_VAR_PREFIXES)

    def _series_origin(self, name: str) -> str:
        """Return ``context``, ``building``, or ``pv`` for a DataProvider series name."""
        if self._is_pv_series_name(name):
            return "pv"
        if self.building is not None and self._is_building_series_name(name):
            return "building"
        return "context"

    def _data_provider_series_by_origin(
        self, dp: DataProvider, origin: str,
    ) -> dict[str, list[float]]:
        """Return plottable time series from ``dp`` whose :meth:`_series_origin` matches ``origin``."""
        variable_values: dict[str, list[float]] = {}
        indep_names: set[str] = set(dp.independent_variable_set.variable_names)
        param_formula_names: set[str] = set(dp.parameterized_variable_set.variable_names)
        for name in sorted(indep_names | param_formula_names):
            if self._series_origin(name) != origin:
                continue
            try:
                variable_values[name] = dp.series(name)
            except (ValueError, KeyError):
                continue
        return variable_values

    def _print_data_provider_vars(self, origin: str | None = None) -> None:
        """Print DataProvider series names, optionally filtered by origin (context, building, pv)."""
        dp = self.data_provider
        if dp is None:
            self.perror(
                "No DataProvider available. Load a context ('context load' / 'context new') "
                "or a building first."
            )
            return

        title = "all origins" if origin is None else origin
        self.poutput(
            f"DataProvider — {dp.location}  |  "
            f"{dp.starting_stringdate} → {dp.ending_stringdate}  |  {len(dp)} time step(s)  |  {title}"
        )

        indep_names: set[str] = set(dp.independent_variable_set.variable_names)
        param_formula_names: set[str] = set(dp.parameterized_variable_set.variable_names)

        table: PrettyTable = PrettyTable()
        if origin is None:
            table.field_names = ["name", "kind"]
            table.align["kind"] = "l"
        else:
            table.field_names = ["name"]
        table.align["name"] = "l"

        origins_count: dict[str, int] = {"context": 0, "building": 0, "pv": 0}
        shown = 0

        for name in sorted(indep_names | param_formula_names):
            name_origin = self._series_origin(name)
            origins_count[name_origin] = origins_count.get(name_origin, 0) + 1
            if origin is not None and name_origin != origin:
                continue
            if origin is None:
                table.add_row([name, name_origin])
            else:
                table.add_row([name])
            shown += 1

        if origin is None or origin == "context":
            for name in sorted(dp.parameter_names):
                if origin == "context":
                    table.add_row([name])
                    shown += 1
                elif origin is None:
                    table.add_row([name, "context"])

        if shown == 0:
            if origin == "context":
                self.poutput("No context variables in this DataProvider.")
            elif origin == "building":
                self.poutput("No building variables in this DataProvider (run 'building simulate' first).")
            elif origin == "pv":
                self.poutput(
                    "No PV variables in this DataProvider. Run 'pv simulate' to register "
                    "collector series and PV:power_W."
                )
            else:
                self.poutput("No variables registered in this DataProvider.")
            return

        self.poutput(table)
        if origin is None:
            self.poutput(
                f"{len(indep_names | param_formula_names)} series "
                f"(context: {origins_count['context']}, building: {origins_count['building']}, "
                f"pv: {origins_count['pv']}), {len(dp.parameter_names)} parameter(s)."
            )
        else:
            self.poutput(f"{shown} variable(s) with origin '{origin}'.")

    def help_vars(self) -> None:
        """Detailed help for the ``vars`` command."""
        self.poutput(
            "vars — list all DataProvider variable names with origin (context, building, or pv).\n\n"
            "Filtered lists: 'context vars', 'building vars', 'pv vars'.\n\n"
            "Requires a loaded context (see 'status'). Use 'plot' for the interactive time-series viewer."
        )

    def help_plot(self) -> None:
        """Detailed help for the ``plot`` command."""
        self.poutput(
            "plot — DataProvider time-series plotter (Plotly).\n\n"
            "Usage:\n"
            "  plot                    Tk variable picker (DataProvider.plot()).\n"
            "  plot <var> [<var> ...]  Plot named series directly (DataProvider.plot(var, ...)).\n\n"
            "Requires a loaded context or building (see 'status'). Variable names are "
            "quoted with shlex when they contain spaces."
        )

    def do_plot(self, arg: str) -> None:
        """Open :meth:`~batem.core.data.DataProvider.plot` for the active DataProvider (see ``help plot``)."""
        variable_names = shlex.split(arg)
        self._launch_data_provider_plot(*variable_names)

    def do_vars(self, arg: str) -> None:
        """List variable names available in the active DataProvider (see ``help vars``)."""
        if shlex.split(arg):
            self.perror("Usage: vars")
            return
        self._print_data_provider_vars(None)

    def _print_workshop_notebook_list(self, root: Path, notebooks: list[Path]) -> None:
        table: PrettyTable = PrettyTable()
        table.field_names = ["#", "notebook"]
        table.align["notebook"] = "l"
        for index, path in enumerate(notebooks, start=1):
            table.add_row([index, path.name])
        self.poutput(f"Workshop notebooks in {root}:")
        self.poutput(table)

    def _jupyterlab_workshop_env(self) -> dict[str, str]:
        pp = os.environ.get("PYTHONPATH", "")
        return {
            **os.environ,
            "PYTHONPATH": str(BATEM_REPO_ROOT) + (os.pathsep + pp if pp else ""),
        }

    def _launch_workshops_jupyterlab(self, root: Path, notebook: Path | None) -> None:
        try:
            import jupyterlab  # noqa: F401
        except ImportError:
            self.perror(
                "JupyterLab is not installed in this Python environment. "
                "Install it with: pip install jupyterlab"
            )
            return

        existing = getattr(self, "_workshops_jupyter_proc", None)
        if existing is not None and existing.poll() is None:
            self.poutput(
                f"JupyterLab is already running in the background (pid {existing.pid}). "
                "Use your browser to open the lab UI (typically http://127.0.0.1:8888/lab)."
            )
            return

        cmd: list[str] = [
            sys.executable,
            "-m",
            "jupyterlab",
            f"--notebook-dir={root}",
        ]
        if notebook is not None:
            cmd.append(str(notebook.resolve()))

        log_dir = root / ".baterm"
        log_dir.mkdir(exist_ok=True)
        log_path = log_dir / "jupyterlab_workshops.log"

        popen_kwargs: dict = {
            "cwd": str(root),
            "env": self._jupyterlab_workshop_env(),
            "stdin": subprocess.DEVNULL,
        }
        if os.name == "nt":
            popen_kwargs["creationflags"] = (
                subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
            )
        else:
            popen_kwargs["start_new_session"] = True

        try:
            with log_path.open("a", encoding="utf-8") as log_file:
                log_file.write(f"\n--- JupyterLab started ({cmd!r}) ---\n")
                log_file.flush()
                proc = subprocess.Popen(
                    cmd,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    **popen_kwargs,
                )
        except OSError as exc:
            self.perror(f"Could not start JupyterLab: {exc}")
            return

        self._workshops_jupyter_proc = proc
        self.poutput(f"JupyterLab started in the background (pid {proc.pid}).")
        self.poutput(f"Notebook directory: {root}")
        if notebook is not None:
            self.poutput(f"Requested notebook: {notebook.name}")
        else:
            self.poutput("Pick a workshopXX_*.ipynb file in the JupyterLab file browser.")
        self.poutput(
            "Your browser should open automatically; otherwise try http://127.0.0.1:8888/lab"
        )
        self.poutput(f"Server log: {log_path}")
        self.poutput("baterm stays interactive — quit JupyterLab from its UI or kill the process.")

    def help_workshops(self) -> None:
        """Detailed help for the ``workshops`` command."""
        self.poutput(
            "workshops — start JupyterLab for BATEM teaching notebooks.\n\n"
            "Usage:\n"
            "  workshops              Launch JupyterLab in the current working directory.\n"
            "  workshops list         List workshopXX_*.ipynb files in cwd.\n"
            "  workshops <id|name>    Launch JupyterLab and open one notebook.\n\n"
            "Examples:\n"
            "  workshops 1            → workshop01_sun.ipynb\n"
            "  workshops 09           → workshop09_photovoltaic.ipynb\n"
            "  workshops workshop05_dynamic.ipynb\n\n"
            "Notebooks are searched in the process working directory (``cd`` there first).\n"
            "JupyterLab runs in the background; baterm remains usable.\n"
            "BATEM is on PYTHONPATH so ``import batem`` works in notebooks.\n"
            "Server log: <cwd>/.baterm/jupyterlab_workshops.log"
        )

    def do_workshops(self, arg: str) -> None:
        """Start JupyterLab for ``workshopXX_*.ipynb`` notebooks (see ``help workshops``)."""
        tokens = shlex.split(arg)
        root = self._workshops_root()
        notebooks = list_workshop_notebooks(root)
        if not notebooks:
            self.perror(f"No workshop*.ipynb notebooks found in {root}.")
            return

        if len(tokens) > 1:
            self.perror("Usage: workshops | workshops list | workshops <id|name>")
            return

        if len(tokens) == 1 and tokens[0].lower() == "list":
            self._print_workshop_notebook_list(root, notebooks)
            return

        notebook: Path | None = None
        if len(tokens) == 1:
            notebook = resolve_workshop_notebook(root, tokens[0])
            if notebook is None:
                self.perror(f"No unique workshop notebook matching {tokens[0]!r}.")
                self.poutput("Use 'workshops list' to see available notebooks.")
                return

        self._launch_workshops_jupyterlab(root, notebook)

    def complete_workshops(self, text: str, line: str, begidx: int, endidx: int) -> list[str]:
        """Tab-complete ``workshops`` subcommands and notebook names."""
        tokens, _frag = self.tokens_for_completion(line, begidx, endidx)
        if len(tokens) <= 1:
            return ["list"]
        if len(tokens) == 2 and tokens[1] == "list":
            return []
        if len(tokens) == 2:
            choices = ["list", *[nb.stem for nb in list_workshop_notebooks(self._workshops_root())]]
            return [c for c in choices if c.startswith(text)]
        return []

    def _resolve_script_path(self, raw: str) -> Path | None:
        """Resolve a user-supplied script reference.

        Search order:

        1. The path as given (after ``~`` expansion), against cwd or as absolute.
        2. The same path with ``.baterm`` appended when no suffix is provided.
        3. Both of the above resolved relative to :data:`BATEM_REPO_ROOT`.
        """
        candidate = Path(raw).expanduser()
        candidates: list[Path] = [candidate]
        if candidate.suffix == "":
            candidates.append(candidate.with_suffix(".baterm"))
        if not candidate.is_absolute():
            candidates.append(BATEM_REPO_ROOT / candidate)
            if candidate.suffix == "":
                candidates.append(BATEM_REPO_ROOT / candidate.with_suffix(".baterm"))
        for path in candidates:
            if path.is_file():
                return path.resolve()
        return None

    def do_script(self, arg: str) -> None:
        """Run a baterm batch file (``.baterm``) or a shell script (``.sh``)."""
        parts: list[str] = shlex.split(arg)
        if not parts:
            self.perror("Usage: script <path> [arg ...]")
            return
        path = self._resolve_script_path(parts[0])
        if path is None:
            self.perror(f"Not a file: {parts[0]}")
            return
        extra: list[str] = parts[1:]

        if path.suffix in self._SHELL_SCRIPT_SUFFIXES:
            self._run_shell_script(path, extra)
            return

        if extra:
            self.pwarning(f"Ignoring extra arguments for baterm batch: {extra}")

        try:
            with path.open(encoding="utf-8") as source:
                lines: list[str] = [line.rstrip("\n") for line in source]
        except OSError as exc:
            self.perror(f"Could not read script {path}: {exc}")
            return

        commands: list[str] = [line for line in lines if line.strip() and not line.lstrip().startswith("#")]
        if not commands:
            self.poutput(f"No commands to run in {path}.")
            return

        self.poutput(f"Running baterm script: {path}")
        self.runcmds_plus_hooks(commands, stop_on_keyboard_interrupt=True)

    def _run_shell_script(self, path: Path, extra: list[str]) -> None:
        """Execute *path* as a shell script with cwd at the repo root."""
        root = str(BATEM_PACKAGE_DIR)
        try:
            if os.name == "nt":
                cmd_line = subprocess.list2cmdline([str(path), *extra])
                completed = subprocess.run(cmd_line, cwd=root, shell=True, check=False)
            else:
                completed = subprocess.run(["/bin/sh", str(path), *extra], cwd=root, check=False)
        except OSError as exc:
            self.perror(f"Could not run script: {exc}")
            return
        if completed.returncode != 0:
            self.perror(f"Script exited with code {completed.returncode}.")

    def do_pyscript(self, arg: str) -> None:
        """Run a Python file with this interpreter, cwd = package root."""
        parts: list[str] = shlex.split(arg)
        if not parts:
            self.perror("Usage: pyscript <path> [arg ...]")
            return
        path = Path(parts[0]).expanduser()
        if not path.is_file():
            self.perror(f"Not a file: {path}")
            return
        extra: list[str] = parts[1:]
        root = str(BATEM_PACKAGE_DIR)
        try:
            completed = subprocess.run(
                [sys.executable, str(path.resolve()), *extra],
                cwd=root,
                check=False,
            )
        except OSError as exc:
            self.perror(f"Could not run Python script: {exc}")
            return
        if completed.returncode != 0:
            self.perror(f"Python script exited with code {completed.returncode}.")

    def do_run(self, arg: str) -> None:
        """Run a simple command."""
        parts: list[str] = shlex.split(arg)
        if not parts:
            self.perror("Usage: run <command>")
            return
        command, *arguments = parts
        if command == "echo":
            self.poutput(" ".join(arguments))
        else:
            self.perror(f"Unknown internal command: {command}")

    def do_exit(self, arg: str) -> bool:
        """Exit the terminal."""
        self.poutput("Goodbye.")
        return True

    do_quit = do_exit
