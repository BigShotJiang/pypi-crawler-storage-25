"""PrettyTable helpers shared by ``context`` / ``building`` bare commands."""

from __future__ import annotations

import json
from dataclasses import asdict, fields, is_dataclass
from math import isfinite
from typing import Any

import prettytable
from prettytable.prettytable import PrettyTable

from batem.core.building import SideMaskData


class SummaryMixin:
    """Format dataclass fields for cmd2 tabular output."""

    def _format_value_for_summary_table(self, value: Any, *, max_len: int = 240) -> str:
        """Turn a dataclass field value into a single-line string for PrettyTable."""
        if value is None:
            return ""
        if isinstance(value, float):
            return "" if not isfinite(value) else f"{value:g}"
        if isinstance(value, (bool, int)):
            return str(value)
        if isinstance(value, str):
            return value if len(value) <= max_len else value[: max_len - 3] + "..."
        if isinstance(value, SideMaskData):
            payload = json.dumps(asdict(value), ensure_ascii=False)
            return payload if len(payload) <= max_len else payload[: max_len - 3] + "..."
        if isinstance(value, list) and value and isinstance(value[0], SideMaskData):
            labels = [m.name or "(unnamed)" for m in value]
            tail = ", ".join(labels[:12]) + ("..." if len(labels) > 12 else "")
            return f"{len(value)} mask(s): {tail}"
        try:
            encoded = json.dumps(value, default=str, ensure_ascii=False)
        except TypeError:
            encoded = repr(value)
        if len(encoded) <= max_len:
            return encoded
        return encoded[: max_len - 3] + "..."

    def _print_dataclass_summary(self, heading: str, obj: Any) -> None:
        """Print one PrettyTable row per dataclass field (``field`` | ``value``)."""
        if not is_dataclass(obj):
            self.perror(f"Internal error: expected a dataclass instance, got {type(obj)!r}.")
            return
        table: PrettyTable = prettytable.PrettyTable()
        table.field_names = ["field", "value"]
        for field in fields(obj):
            table.add_row([field.name, self._format_value_for_summary_table(getattr(obj, field.name))])
        table.align["field"] = "l"
        table.align["value"] = "l"
        self.poutput(heading)
        self.poutput(table)
