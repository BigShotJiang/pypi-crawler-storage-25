"""BATEM terminal (``baterm``): cmd2 shell split into mixins under ``batem.baterm.mixins``."""

from __future__ import annotations

import os


def _configure_matplotlib_for_baterm() -> None:
    """Select a GUI backend before any ``pyplot`` import from :mod:`batem.core`.

    Otherwise the default is often ``Agg`` and :func:`matplotlib.pyplot.show` does not open
    windows, so commands like ``building variation`` appear to finish with no figures.
    """
    if os.environ.get("BATERM_HEADLESS", "").lower() in ("1", "true", "yes"):
        return
    import matplotlib

    for backend in ("macosx", "tkagg", "qt5agg", "qtagg"):
        try:
            matplotlib.use(backend, force=True)
            return
        except Exception:
            continue


_configure_matplotlib_for_baterm()

from batem.baterm.app import Baterm, main  # noqa: E402

__all__ = ["Baterm", "main"]
