"""Matplotlib figures mirroring selected :mod:`batem.core.lambdahouse` climate plots."""

from __future__ import annotations

import calendar
from datetime import datetime
from typing import Any

import matplotlib.pyplot as plt
from matplotlib.axes import Axes

from batem.core.weather import SiteWeatherData


def lambda_parametric_from_site_weather(swd: SiteWeatherData, year: int) -> Any:
    """Build :class:`~batem.core.lambdahouse.LambdaParametricData` (HVAC periods from weather analysis)."""
    from batem.core.lambdahouse import LambdaParametricData

    return LambdaParametricData(swd, year, swd.albedo, swd.pollution)


def collect_climate_datetime_marks(lpd: Any, datetimes: list[datetime]) -> list[datetime]:
    """Same boundary datetimes as :meth:`batem.core.lambdahouse.Analyzes.climate` (for vertical guides)."""
    datetime_marks: list[datetime] = []
    max_index = len(datetimes) - 1
    heating_period_indices = lpd("heating_period_indices")
    if heating_period_indices is not None and len(heating_period_indices) >= 2:
        if len(heating_period_indices) == 2:
            idx0, idx1 = int(heating_period_indices[0]), int(heating_period_indices[1])
            if 0 <= idx0 <= max_index and 0 <= idx1 <= max_index:
                datetime_marks.append(datetimes[idx0])
                datetime_marks.append(datetimes[idx1])
        elif len(heating_period_indices) == 4:
            idx1, idx2 = int(heating_period_indices[1]), int(heating_period_indices[2])
            if 0 <= idx1 <= max_index and 0 <= idx2 <= max_index:
                datetime_marks.append(datetimes[idx1])
                datetime_marks.append(datetimes[idx2])

    cooling_period_indices = lpd("cooling_period_indices")
    cooling_duration_days = round(lpd("cooling_period_duration_h") / 24)
    if cooling_period_indices is not None and len(cooling_period_indices) >= 2 and cooling_duration_days > 0:
        if len(cooling_period_indices) == 2:
            idx0, idx1 = int(cooling_period_indices[0]), int(cooling_period_indices[1])
            if 0 <= idx0 <= max_index and 0 <= idx1 <= max_index:
                datetime_marks.append(datetimes[idx0])
                datetime_marks.append(datetimes[idx1])
        elif len(cooling_period_indices) == 4:
            idx1, idx2 = int(cooling_period_indices[1]), int(cooling_period_indices[2])
            if 0 <= idx1 <= max_index and 0 <= idx2 <= max_index:
                datetime_marks.append(datetimes[idx1])
                datetime_marks.append(datetimes[idx2])
    return datetime_marks


def _heating_cooling_spans_for_axes(lpd: Any) -> tuple[tuple[int, ...] | None, tuple[int, ...] | None]:
    """Return period index tuples for shading only when lambdahouse detected a non-zero duration."""
    heat_idx: tuple[int, ...] | None = None
    if lpd("heating_period_duration_h") > 0:
        hi = lpd("heating_period_indices")
        if hi is not None and len(hi) >= 2:
            heat_idx = tuple(int(x) for x in hi)
    cool_idx: tuple[int, ...] | None = None
    if lpd("cooling_period_duration_h") > 0:
        ci = lpd("cooling_period_indices")
        if ci is not None and len(ci) >= 2:
            cool_idx = tuple(int(x) for x in ci)
    return heat_idx, cool_idx


def draw_outdoor_temperature_time_series_axis(
    axis: Axes,
    datetimes: list[datetime],
    outdoor_deg: list[float],
    smooth_deg: list[float],
    *,
    winter_trigger_deg: float,
    summer_trigger_deg: float,
    heating_period_indices: tuple[int, ...] | None,
    cooling_period_indices: tuple[int, ...] | None,
    datetime_marks: list[datetime],
) -> None:
    """Upper panel: outdoor + smoothed series, thresholds, HVAC spans (see :class:`ReportGenerator`)."""
    min_value, max_value = None, None
    for val in outdoor_deg:
        if val is None:
            continue
        if min_value is None:
            min_value = max_value = val
        else:
            min_value = min(min_value, val)
            max_value = max(max_value, val)

    if heating_period_indices is not None:
        if len(heating_period_indices) == 2:
            axis.axvspan(
                datetimes[heating_period_indices[0]],
                datetimes[heating_period_indices[1]],
                color="red",
                alpha=0.15,
                zorder=0,
            )
        elif len(heating_period_indices) == 4:
            axis.axvspan(datetimes[0], datetimes[heating_period_indices[1]], color="red", alpha=0.15, zorder=0)
            axis.axvspan(datetimes[heating_period_indices[2]], datetimes[-1], color="red", alpha=0.15, zorder=0)

    if cooling_period_indices is not None:
        if len(cooling_period_indices) == 2:
            axis.axvspan(
                datetimes[cooling_period_indices[0]],
                datetimes[cooling_period_indices[1]],
                color="orange",
                alpha=0.15,
                zorder=0,
            )
        elif len(cooling_period_indices) == 4:
            axis.axvspan(datetimes[0], datetimes[cooling_period_indices[1]], color="orange", alpha=0.15, zorder=0)
            axis.axvspan(datetimes[cooling_period_indices[2]], datetimes[-1], color="orange", alpha=0.15, zorder=0)

    axis.plot(datetimes, outdoor_deg, alpha=1, label="Outdoor temperature", color="tab:blue")
    axis.plot(datetimes, smooth_deg, ":", alpha=0.7, linewidth=2, label="averaged values", color="tab:orange")

    if min_value is not None and max_value is not None:
        for dt_mark in datetime_marks:
            axis.plot([dt_mark, dt_mark], [min_value, max_value], "r-.", alpha=0.5)
        for v_mark in (winter_trigger_deg, summer_trigger_deg):
            axis.plot([datetimes[0], datetimes[-1]], [v_mark, v_mark], "r-.", alpha=0.5)

    axis.set_title("Outdoor temperature and averaged values with heating/cooling periods")
    axis.legend()
    axis.grid(True)


def draw_outdoor_temperature_monotone_axis(
    axis: Axes,
    datetimes: list[datetime],
    outdoor_deg: list[float],
    *,
    value_marks: tuple[float, float],
    datetime_marks: list[datetime],
) -> None:
    """Lower panel: monotone (same logic as :meth:`ReportGenerator.add_monotonic`)."""
    from batem.core.lambdahouse import sort_values

    n = len(outdoor_deg)
    if n < 2:
        axis.text(0.5, 0.5, "Not enough samples for monotone plot.", ha="center", va="center", transform=axis.transAxes)
        return
    indices = [100 * i / (n - 1) for i in range(n)]
    sorted_months, sorted_outdoor_temperatures = sort_values(datetimes, outdoor_deg)
    axis.fill_between(indices, sorted_outdoor_temperatures, alpha=1)
    min_value, max_value = min(outdoor_deg), max(outdoor_deg)
    if value_marks:
        min_value = min(min_value, min(value_marks))
        max_value = max(max_value, max(value_marks))
    avg_value = sum(outdoor_deg) / len(outdoor_deg)
    for value_mark in value_marks:
        axis.plot([0, 100], [value_mark, value_mark], "r:")
    axis.plot([0, 100], [avg_value, avg_value], "b")
    axis.set_ylim(bottom=min_value, top=max_value)
    axis.set_xlim(left=0, right=100)
    axis.grid(True)
    axis.set_xlabel("% of the year")
    axis.set_ylabel("°C")
    axis.set_title("Monotone of the outdoor temperatures in Celsius")
    for label in axis.get_xticklabels():
        label.set_visible(True)
    ax2 = axis.twinx()
    ax2.plot(indices, sorted_months, ".c")
    ax2.set_ylabel("month number")
    for datetime_mark in datetime_marks:
        month_index = datetime_mark.month
        month_days = calendar.monthrange(datetime_mark.year, month_index)[1]
        fractional_month = month_index + (datetime_mark.day - 1) / month_days
        ax2.axhline(fractional_month, color="red", linestyle="--", alpha=0.6, linewidth=1.5)


def show_context_temperature_figure(lpd: Any) -> None:
    """Open a two-row figure: time series (~2/3 height) + monotone (~1/3)."""
    from batem.core.lambdahouse import plot_size

    datetimes: list[datetime] = lpd("datetimes")
    outdoor = lpd("outdoor_temperatures_deg")
    smooth = lpd("smooth_outdoor_temperatures_for_hvac_periods_deg")
    winter_t = float(lpd("winter_hvac_trigger_temperature_deg"))
    summer_t = float(lpd("summer_hvac_trigger_temperature_deg"))
    marks = collect_climate_datetime_marks(lpd, datetimes)
    heat_span, cool_span = _heating_cooling_spans_for_axes(lpd)

    fig, (ax_top, ax_bot) = plt.subplots(
        2,
        1,
        figsize=(plot_size[0], int(plot_size[1] * 2.2)),
        layout="tight",
        gridspec_kw={"height_ratios": [2, 1]},
    )
    draw_outdoor_temperature_time_series_axis(
        ax_top,
        datetimes,
        outdoor,
        smooth,
        winter_trigger_deg=winter_t,
        summer_trigger_deg=summer_t,
        heating_period_indices=heat_span,
        cooling_period_indices=cool_span,
        datetime_marks=marks,
    )
    draw_outdoor_temperature_monotone_axis(
        ax_bot,
        datetimes,
        outdoor,
        value_marks=(winter_t, summer_t),
        datetime_marks=marks,
    )
    plt.show()
