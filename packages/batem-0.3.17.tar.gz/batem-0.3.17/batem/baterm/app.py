"""cmd2 application class composed from per-domain mixins."""

from __future__ import annotations

import subprocess
from pathlib import Path

import cmd2

from batem.core.building import Building, BuildingData, Context, ContextData, SideMaskData
from batem.core.data import DataProvider
from batem.core.solar import PVplant, PVplantData

from batem.baterm.mixins.building_cmds import BuildingCommandsMixin
from batem.baterm.mixins.context_cmds import ContextCommandsMixin
from batem.baterm.mixins.enercost_cmds import EnercostCommandsMixin
from batem.baterm.mixins.plotting import PlottingMixin
from batem.baterm.mixins.pv_cmds import PvCommandsMixin
from batem.baterm.mixins.sidemask_cmds import SideMaskCommandsMixin
from batem.baterm.mixins.summary import SummaryMixin
from batem.baterm.mixins.workspace_cmds import WorkspaceCommandsMixin


class Baterm(
    SummaryMixin,
    PlottingMixin,
    ContextCommandsMixin,
    BuildingCommandsMixin,
    PvCommandsMixin,
    EnercostCommandsMixin,
    SideMaskCommandsMixin,
    WorkspaceCommandsMixin,
    cmd2.Cmd,
):
    """BATEM interactive terminal: extend by adding mixins or ``do_*`` methods on a subclass."""

    intro: str = "Welcome to BATEM Terminal. Type help or ? to list commands."
    prompt: str = "baterm > "

    def __init__(self) -> None:
        super().__init__()
        self.aliases["run_script"] = "script"
        self.aliases["run_pyscript"] = "pyscript"
        self.prompt = Baterm.prompt
        # Print ``Elapsed: HH:MM:SS.ffffff`` after every command (built-in cmd2 setting).
        # Use ``set timing False`` at the prompt to turn it off for a session.
        self.timing = True
        # Make the elapsed-time feedback go to stdout (default would route to stderr).
        self.feedback_to_output = True
        self.context_data: ContextData | None = None
        self.building_data: BuildingData | None = None
        self.current_file: Path | None = None
        self.building: Building | None = None
        self._context_shell: Context | None = None
        self.side_masks: list[SideMaskData] = []
        self.pv_plant_data: PVplantData | None = None
        self._pv_plant: PVplant | None = None
        self._pv_powers_W: list[float] | None = None
        self._workshops_jupyter_proc: subprocess.Popen | None = None

    @property
    def data_provider(self) -> DataProvider | None:
        """Active weather :class:`~batem.core.data.DataProvider` if a context or full building is loaded."""
        if self.building is not None:
            return self.building.dp
        if self._context_shell is not None:
            return self._context_shell.dp
        return None

    def _refresh_building(self) -> None:
        """Rebuild :attr:`building` when both context and building data exist."""
        self.building = None
        self._context_shell = None
        if self.context_data is None:
            return
        if self.building_data is not None:
            self.building = Building(context_data=self.context_data, building_data=self.building_data)
            return
        self._context_shell = Context(self.context_data)


def main() -> None:
    """Console entry point for ``[project.scripts]`` / ``python -m batem.baterm``."""
    Baterm().cmdloop()
