"""JSON helpers and child-process launcher for GUI subprocesses."""

from __future__ import annotations

import os
import subprocess
import sys
from dataclasses import fields
from subprocess import CompletedProcess
from typing import Any

from dataclasses import asdict, fields

from batem.core.building import BuildingData, ContextData, SideMaskData
from batem.core.solar import MOUNT_TYPES, PVplantData

from batem.baterm.config import BATEM_REPO_ROOT


def context_data_from_json_str_data(json_str_data: dict[str, str]) -> ContextData:
    """Rebuild a :class:`ContextData` from a JSON-decoded payload."""
    json_str_data = dict[str, str](json_str_data)
    json_str_data["side_masks"] = [
        SideMaskData(**json_str_sidemask) for json_str_sidemask in json_str_data.get("side_masks", [])
    ]
    return ContextData(**json_str_data)


def pvplant_data_to_json_dict(pv_data: PVplantData) -> dict[str, Any]:
    """Serialize :class:`PVplantData` for JSON (enum names, nested context)."""
    payload: dict[str, Any] = asdict(pv_data)
    payload["mount_type"] = pv_data.mount_type.name
    return payload


def pvplant_data_from_json_str_data(json_str_data: dict[str, Any]) -> PVplantData:
    """Rebuild :class:`PVplantData` from a JSON-decoded payload."""
    raw: dict[str, Any] = dict(json_str_data)
    raw["context_data"] = context_data_from_json_str_data(dict(raw["context_data"]))
    mount_type = raw.get("mount_type")
    if isinstance(mount_type, str):
        raw["mount_type"] = MOUNT_TYPES[mount_type.upper()]
    elif isinstance(mount_type, int):
        raw["mount_type"] = MOUNT_TYPES(mount_type)
    allowed: set[str] = {field.name for field in fields(PVplantData)}
    filtered: dict[str, Any] = {key: value for key, value in raw.items() if key in allowed}
    if "number_of_cell_rows" in filtered:
        filtered["number_of_cell_rows"] = max(1, int(round(filtered["number_of_cell_rows"])))
    return PVplantData(**filtered)


def building_data_from_json_str_data(json_str_data: dict[str, str]) -> BuildingData:
    """Rebuild a :class:`BuildingData` from a JSON-decoded payload (legacy keys + unknown fields filtered)."""
    raw: dict[str, Any] = dict(json_str_data)
    if raw.get("max_floor_heating_power") is None and raw.get("max_heating_power") is not None:
        raw["max_floor_heating_power"] = raw["max_heating_power"]
    if raw.get("max_floor_cooling_power") is None and raw.get("max_cooling_power") is not None:
        raw["max_floor_cooling_power"] = raw["max_cooling_power"]
    allowed_fields: set[str] = {field.name for field in fields(BuildingData)}
    filtered: dict[str, Any] = {key: value for key, value in raw.items() if key in allowed_fields}
    return BuildingData(**filtered)


def run_python(script: str, *args: str) -> int:
    """Run inline Python ``script`` with ``args`` in a child interpreter.

    The child uses :data:`BATEM_REPO_ROOT` as ``cwd`` and prepends it to ``PYTHONPATH``
    so freshly-added source modules / dataclass fields resolve, even when an older
    ``batem`` package is also installed in ``site-packages``.
    """
    existing_pp = os.environ.get("PYTHONPATH", "")
    env = {
        **os.environ,
        "PYTHONPATH": str(BATEM_REPO_ROOT) + (os.pathsep + existing_pp if existing_pp else ""),
    }
    completed: CompletedProcess[bytes] = subprocess.run(
        [sys.executable, "-c", script, *args],
        cwd=str(BATEM_REPO_ROOT),
        env=env,
        check=False,
    )
    return completed.returncode
