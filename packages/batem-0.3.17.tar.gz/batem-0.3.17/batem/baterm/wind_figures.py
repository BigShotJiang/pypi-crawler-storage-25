"""Matplotlib windrose + speed/direction distributions (from :mod:`batem.core.lambdahouse` climate plots)."""

from __future__ import annotations

from typing import Any

import matplotlib.pyplot as plt
import numpy
from matplotlib import cm
from matplotlib.figure import Figure
from matplotlib.gridspec import GridSpec
from matplotlib.ticker import PercentFormatter


def _draw_wind_distributions_pair(ax_speed, ax_dir, wind_speeds_km_h: list[float], wind_directions_deg: list[float]) -> None:
    """Same histograms as ``ReportGenerator.add_wind_distributions`` (two axes, one row)."""
    if not wind_speeds_km_h or not wind_directions_deg:
        ax_speed.text(0.5, 0.5, "No wind data.", ha="center", va="center", transform=ax_speed.transAxes)
        ax_dir.text(0.5, 0.5, "No wind data.", ha="center", va="center", transform=ax_dir.transAxes)
        return

    max_speed = max(wind_speeds_km_h)
    if max_speed <= 0:
        max_speed = 1.0
    value_counts, category_bin_edges = numpy.histogram(wind_speeds_km_h, 20, range=(0, max_speed))
    width = 0.8 * (category_bin_edges[1] - category_bin_edges[0])
    ax_speed.bar(
        category_bin_edges[:-1],
        [count / len(wind_speeds_km_h) for count in value_counts],
        width=width,
        align="center",
    )
    ax_speed.grid(True)
    ax_speed.set_xlabel("Wind speed (km/h)")
    ax_speed.set_ylabel("Probability")
    ax_speed.yaxis.set_major_formatter(PercentFormatter(1))
    ax_speed.set_title("Wind speed distribution over the year")

    direction_categories = ("N", "", "N-E", "", "E", "", "S-E", "", "S", "", "S-W", "", "W", "", "N-W", "")
    direction_width = 360 * 0.8 / len(direction_categories)
    value_counts_dir, category_bin_edges_dir = numpy.histogram(
        wind_directions_deg, len(direction_categories), range=(0, 360)
    )
    ax_dir.bar(
        category_bin_edges_dir[:-1],
        [count / len(wind_directions_deg) for count in value_counts_dir],
        width=direction_width,
        align="center",
    )
    ax_dir.set_xticks(category_bin_edges_dir[:-1])
    ax_dir.set_xticklabels(direction_categories)
    ax_dir.grid(True)
    ax_dir.set_xlabel("Wind direction (coming from)")
    ax_dir.set_ylabel("Probability")
    ax_dir.yaxis.set_major_formatter(PercentFormatter(1))
    ax_dir.set_title("Wind direction distribution over the year")


def show_context_wind_figure(lpd: Any) -> None:
    """Two-row figure: windrose (top), speed + direction histograms (bottom row)."""
    try:
        __import__("windrose")  # registers ``projection='windrose'``
    except ImportError as exc:
        raise ImportError("The windrose package is required for `context wind`. Install with: pip install windrose") from exc

    from batem.core.lambdahouse import plot_size

    wind_directions_deg: list[float] = lpd("wind_directions_deg")
    wind_speeds_m_s: list[float] = lpd("wind_speeds_m_s")
    wind_speeds_km_h = [3.6 * s for s in wind_speeds_m_s]

    w_in, h_in = float(plot_size[0]), float(plot_size[1])
    fig: Figure = plt.figure(figsize=(w_in * 1.25, h_in * 2.15), layout="constrained")
    gs = GridSpec(2, 1, figure=fig, height_ratios=[1.15, 1.0])

    ax_rose = fig.add_subplot(gs[0], projection="windrose")
    ax_rose.contourf(
        direction=wind_directions_deg,
        var=wind_speeds_km_h,
        bins=20,
        normed=True,
        cmap=cm.hot,
    )
    ax_rose.contour(
        direction=wind_directions_deg,
        var=wind_speeds_km_h,
        bins=20,
        normed=True,
        colors="black",
        linewidth=0.5,
    )
    ax_rose.set_legend()
    ax_rose.set_xlabel("radius stands for number of occurrences")
    ax_rose.set_title("windrose where color stands for wind speed in km/h")
    ax_rose.yaxis.set_major_formatter(PercentFormatter(100))

    inner = gs[1].subgridspec(1, 2, wspace=0.28)
    ax_spd = fig.add_subplot(inner[0, 0])
    ax_dir = fig.add_subplot(inner[0, 1])
    _draw_wind_distributions_pair(ax_spd, ax_dir, wind_speeds_km_h, wind_directions_deg)

    plt.show()
