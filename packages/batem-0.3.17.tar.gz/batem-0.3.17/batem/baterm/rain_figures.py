"""Matplotlib (2, 2) rain / cloudiness figure mirroring :meth:`batem.core.lambdahouse.Analyzes.climate` plots."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import matplotlib.pyplot as plt
import numpy
from matplotlib.axes import Axes
from matplotlib.colors import LinearSegmentedColormap
from batem.core.timemg import datetime_to_stringdate


def draw_precipitations_time_series_axis(
    axis: Axes,
    datetimes: list[datetime],
    precipitations_mm_per_hour: list[float],
    snowfalls_mm_per_hour: list[float],
) -> None:
    """Same series as ``ReportGenerator.add_time_plot`` for precipitations + snowfalls (dashed)."""
    axis.plot(datetimes, precipitations_mm_per_hour, alpha=1, label="Precipitations (rain + hail + snow) along time in mm/h", color="tab:blue")
    axis.plot(
        datetimes,
        snowfalls_mm_per_hour,
        ":",
        alpha=0.7,
        linewidth=2,
        label="snowfalls",
        color="tab:orange",
    )
    axis.set_title("Precipitations (rain + hail + snow) along time in mm/h")
    axis.legend()
    axis.grid(True)


def draw_cloudiness_monthly_heatmap_axis(axis: Axes, datetimes: list[datetime], cloudiness_percentage: list[float]) -> None:
    """Monthly heatmap (logic from ``ReportGenerator.add_monthly_heatmap``)."""
    heatmap_data = numpy.full((31, 12), numpy.nan)
    value_counts = numpy.zeros((31, 12))

    for i, dt in enumerate(datetimes):
        month_idx = dt.month - 1
        day_idx = dt.day - 1
        if numpy.isnan(heatmap_data[day_idx, month_idx]):
            heatmap_data[day_idx, month_idx] = cloudiness_percentage[i]
            value_counts[day_idx, month_idx] = 1
        else:
            current_sum = heatmap_data[day_idx, month_idx] * value_counts[day_idx, month_idx]
            heatmap_data[day_idx, month_idx] = (current_sum + cloudiness_percentage[i]) / (value_counts[day_idx, month_idx] + 1)
            value_counts[day_idx, month_idx] += 1

    monthly_averages: list[float] = []
    for month_idx in range(12):
        month_data = heatmap_data[:, month_idx]
        valid_data = month_data[~numpy.isnan(month_data)]
        if len(valid_data) > 0:
            monthly_averages.append(float(numpy.mean(valid_data)))
        else:
            monthly_averages.append(float("nan"))

    extended_heatmap_data = numpy.full((32, 12), numpy.nan)
    extended_heatmap_data[:31, :] = heatmap_data
    extended_heatmap_data[31, :] = monthly_averages

    im = axis.imshow(extended_heatmap_data, aspect="auto", cmap="YlGnBu", interpolation="nearest", origin="upper")
    month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    axis.set_xticks(range(12))
    axis.set_xticklabels(month_names)
    axis.set_xlabel("Month")
    y_ticks = list(range(0, 31, 5)) + [31]
    y_labels = [str(i) for i in range(1, 32, 5)] + ["Avg"]
    axis.set_yticks(y_ticks)
    axis.set_yticklabels(y_labels)
    axis.set_ylabel("Day of month / Monthly average")
    for month_idx in range(12):
        if not numpy.isnan(monthly_averages[month_idx]):
            text = f"{monthly_averages[month_idx]:.1f}"
            axis.text(
                month_idx,
                31,
                text,
                ha="center",
                va="center",
                fontweight="bold",
                color="white" if monthly_averages[month_idx] > numpy.nanmean(monthly_averages) else "black",
                fontsize=7,
            )
    axis.figure.colorbar(im, ax=axis, fraction=0.046, pad=0.04).set_label("Cloudiness (%)", rotation=270, labelpad=12)
    axis.set_title("Heatmap of the cloudiness in percentage of the sky covered by clouds")


def draw_precipitation_event_axis(axis: Axes, datetimes: list[datetime], values: list[float]) -> None:
    """Event heatmap (logic from ``ReportGenerator.add_event_plot``)."""
    resolution = 20
    days_with_rain: list[str] = []
    days: list[str] = []
    rain_duration_h_quantity_mm_n_events: dict[tuple[float, float], int] = {}
    was_raining = False
    rain_duration_h = 0
    rain_quantity_mm = 0.0
    max_duration = 0
    max_quantity = 0
    threshold = 0.1

    for k, precipitation in enumerate(values):
        stringdate: str = datetime_to_stringdate(datetimes[k]).split(" ")[0]
        if stringdate not in days:
            days.append(stringdate)
        if was_raining and precipitation > 0:
            rain_duration_h += 1
            rain_quantity_mm += precipitation
            if stringdate not in days_with_rain:
                days_with_rain.append(stringdate)
        elif was_raining and precipitation == 0:
            rain_duration_h_quantity_mm: tuple[int, int] = (rain_duration_h, round(rain_quantity_mm, 0))
            max_duration = max(max_duration, rain_duration_h_quantity_mm[0])
            max_quantity = max(max_quantity, rain_duration_h_quantity_mm[1])
            if rain_duration_h_quantity_mm in rain_duration_h_quantity_mm_n_events:
                rain_duration_h_quantity_mm_n_events[rain_duration_h_quantity_mm] += 1
            else:
                rain_duration_h_quantity_mm_n_events[rain_duration_h_quantity_mm] = 1
            was_raining = False
            rain_duration_h = 0
            rain_quantity_mm = 0
        elif not was_raining and precipitation > threshold:
            if stringdate not in days_with_rain:
                days_with_rain.append(stringdate)
            rain_duration_h = 1
            rain_quantity_mm = precipitation
            was_raining = True

    if max_duration <= 0 or max_quantity <= 0:
        axis.text(0.5, 0.5, "No precipitation events in range.", ha="center", va="center", transform=axis.transAxes)
        axis.set_title("Rain, hail or snow events: duration, intensity and occurrences")
        return

    rain_duration_scale: list[float] = [_ / resolution * max_duration for _ in range(resolution)]
    rain_quantity_scale: list[float] = [_ / resolution * max_quantity for _ in range(resolution)]
    rain_duration_quantity_events: list[list[float]] = [[float("NaN") for _ in range(resolution)] for _ in range(resolution)]
    max_number_of_rain_events = 0
    for rain_duration_h_quantity_mm in rain_duration_h_quantity_mm_n_events:
        rd, rq = rain_duration_h_quantity_mm
        n_events = rain_duration_h_quantity_mm_n_events[rain_duration_h_quantity_mm]
        rain_duration_h_index = min(resolution - 1, int(rd / max_duration * resolution))
        rain_quantity_mm_index = min(resolution - 1, int(rq / max_quantity * resolution))
        rain_duration_quantity_events[rain_duration_h_index][rain_quantity_mm_index] = n_events
        max_number_of_rain_events = max(max_number_of_rain_events, n_events)

    cmap: LinearSegmentedColormap = LinearSegmentedColormap.from_list(
        "custom", ["green", "orange", "red", "purple", "blue"], N=max(max_number_of_rain_events, 1)
    )
    im = axis.imshow(
        rain_duration_quantity_events,
        aspect="auto",
        origin="lower",
        extent=[rain_duration_scale[0], rain_duration_scale[-1], rain_quantity_scale[0], rain_quantity_scale[-1]],
        cmap=cmap,
    )
    axis.figure.colorbar(im, ax=axis, fraction=0.046, pad=0.04, orientation="horizontal").ax.set_ylabel("# events", rotation=-90, va="bottom")
    axis.set_title(
        "Rain, hail or snow events: duration, intensity and occurrences\n"
        f"({len(days_with_rain)} raining days out of {len(days)})"
    )
    axis.set_xlabel("duration in hours")
    axis.set_ylabel("quantity in mm/event")


def draw_month_week_cumulated_axis(
    axis: Axes,
    datetimes: list[datetime],
    values: list[float],
    snowfall_values: list[float] | None,
) -> None:
    """Month & week cumulated series (logic from ``ReportGenerator.add_month_week_averages``)."""
    month_accumulator: list[float] = []
    month_cumulated_precipitations: list[float] = []
    month_snowfall_accumulator: list[float] = []
    month_cumulated_snowfalls: list[float] = []
    current_month_number: int = datetimes[0].month
    week_accumulator: list[float] = []
    week_cumulated_precipitations: list[float] = []
    week_snowfall_accumulator: list[float] = []
    week_cumulated_snowfalls: list[float] = []
    week_number: int = datetimes[0].isocalendar().week

    for k, precipitation_mm_per_hour in enumerate(values):
        month: int = datetimes[k].month
        if current_month_number != month or k == len(values) - 1:
            month_quantity = sum(month_accumulator)
            month_cumulated_precipitations.extend([month_quantity for _ in range(len(month_accumulator))])
            month_accumulator = [precipitation_mm_per_hour]
            if snowfall_values is not None:
                month_snowfall_quantity = sum(month_snowfall_accumulator)
                month_cumulated_snowfalls.extend([month_snowfall_quantity for _ in range(len(month_snowfall_accumulator))])
                month_snowfall_accumulator = [snowfall_values[k] if k < len(snowfall_values) else 0.0]
            current_month_number = month
        else:
            month_accumulator.append(precipitation_mm_per_hour)
            if snowfall_values is not None:
                month_snowfall_accumulator.append(snowfall_values[k] if k < len(snowfall_values) else 0.0)

        week: int = datetimes[k].isocalendar().week
        if week_number != week or k == len(values) - 1:
            week_quantity = sum(week_accumulator)
            week_cumulated_precipitations.extend([week_quantity for _ in range(len(week_accumulator))])
            week_accumulator = [precipitation_mm_per_hour]
            if snowfall_values is not None:
                week_snowfall_quantity = sum(week_snowfall_accumulator)
                week_cumulated_snowfalls.extend([week_snowfall_quantity for _ in range(len(week_snowfall_accumulator))])
                week_snowfall_accumulator = [snowfall_values[k] if k < len(snowfall_values) else 0.0]
            week_number = week
        else:
            week_accumulator.append(precipitation_mm_per_hour)
            if snowfall_values is not None:
                week_snowfall_accumulator.append(snowfall_values[k] if k < len(snowfall_values) else 0.0)

    axis.stairs(month_cumulated_precipitations, datetimes, fill=True, color="cyan", label="Monthly cumulated precipitation", alpha=0.6)
    axis.stairs(week_cumulated_precipitations, datetimes, fill=True, color="pink", label="Weekly cumulated precipitation", alpha=0.6)
    if snowfall_values is not None:
        axis.stairs(month_cumulated_snowfalls, datetimes, fill=True, color="lightblue", label="Monthly cumulated snowfall", alpha=0.8)
        axis.stairs(week_cumulated_snowfalls, datetimes, fill=True, color="lightcoral", label="Weekly cumulated snowfall", alpha=0.8)
    axis.set_xlabel("times")
    axis.set_ylabel("quantity (mm)")
    axis.set_title("Month & week cumulated rain, hail or snow")
    axis.legend(fontsize=7)
    axis.grid(True)


def show_context_rain_figure(lpd: Any) -> None:
    """(2, 2) layout: precipitations (0,0), cloudiness (0,1), events (1,0), month/week (1,1)."""
    from batem.core.lambdahouse import plot_size

    datetimes: list[datetime] = lpd("datetimes")
    precip = lpd("precipitations_mm_per_hour")
    snow = lpd("snowfalls_mm_per_hour")
    cloud = lpd("cloudiness_percentage")

    w_in, h_in = float(plot_size[0]), float(plot_size[1])
    fig, axes = plt.subplots(2, 2, figsize=(w_in * 1.15, h_in * 1.15), layout="constrained")

    draw_precipitations_time_series_axis(axes[0, 0], datetimes, precip, snow)
    draw_cloudiness_monthly_heatmap_axis(axes[0, 1], datetimes, cloud)
    draw_precipitation_event_axis(axes[1, 0], datetimes, precip)
    draw_month_week_cumulated_axis(axes[1, 1], datetimes, precip, snow)

    plt.show()
