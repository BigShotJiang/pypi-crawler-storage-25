"""Context solar figures (unit 1 m² collectors), aligned with :meth:`batem.core.lambdahouse.Analyzes.solar`."""

from __future__ import annotations

from datetime import datetime, time

import matplotlib.pyplot as plt
import numpy
from matplotlib.axes import Axes

from batem.core.lambdahouse import plot_size
from batem.core.library import DIRECTIONS_SREF, SLOPES
from batem.core.solar import Collector, SolarModel, SolarSystem


def _unit_canonic_powers_W(solar_model: SolarModel) -> dict[str, list[float]]:
    """Hourly collected power (W) per 1 m² for each canonical orientation + horizontal up."""
    unit_system = SolarSystem(solar_model)
    for direction in DIRECTIONS_SREF:
        Collector(
            unit_system,
            direction.name,
            exposure_deg=direction.value,
            slope_deg=SLOPES.VERTICAL.value,
            surface_m2=1.0,
            solar_factor=1.0,
        )
    Collector(
        unit_system,
        "HORIZONTAL_UP",
        exposure_deg=DIRECTIONS_SREF.SOUTH.value,
        slope_deg=SLOPES.HORIZONTAL_UP.value,
        surface_m2=1.0,
        solar_factor=1.0,
    )
    out = unit_system.powers_W(gather_collectors=False)
    if not isinstance(out, dict):
        raise TypeError("Expected collector powers as a dict[str, list[float]].")
    return out


def _daily_horizontal_kwh_m2(datetimes: list[datetime], horizontal_W: list[float]) -> tuple[list[datetime], list[float]]:
    """Sum hourly W/m² equivalent over each calendar day → kWh/m²/day (same convention as ``Analyzes.solar``)."""
    daily_kwh: list[float] = []
    daily_dt: list[datetime] = []
    current_date = None
    daily_sum_W = 0.0

    for i, dt in enumerate(datetimes):
        date = dt.date()
        if current_date is None:
            current_date = date
            daily_sum_W = horizontal_W[i]
        elif date == current_date:
            daily_sum_W += horizontal_W[i]
        else:
            daily_kwh.append(daily_sum_W / 1000.0)
            daily_dt.append(datetime.combine(current_date, time(12, 0)))
            current_date = date
            daily_sum_W = horizontal_W[i]

    if current_date is not None:
        daily_kwh.append(daily_sum_W / 1000.0)
        daily_dt.append(datetime.combine(current_date, time(12, 0)))

    return daily_dt, daily_kwh


def _draw_monthly_heatmap_solar_axis(axis: Axes, datetimes: list[datetime], values: list[float], *, value_label: str) -> None:
    """Month × day-of-month heatmap + monthly average row (logic from ``ReportGenerator.add_monthly_heatmap``)."""
    heatmap_data = numpy.full((31, 12), numpy.nan)
    value_counts = numpy.zeros((31, 12))

    for i, dt in enumerate(datetimes):
        month_idx = dt.month - 1
        day_idx = dt.day - 1
        if numpy.isnan(heatmap_data[day_idx, month_idx]):
            heatmap_data[day_idx, month_idx] = values[i]
            value_counts[day_idx, month_idx] = 1
        else:
            current_sum = heatmap_data[day_idx, month_idx] * value_counts[day_idx, month_idx]
            heatmap_data[day_idx, month_idx] = (current_sum + values[i]) / (value_counts[day_idx, month_idx] + 1)
            value_counts[day_idx, month_idx] += 1

    monthly_averages: list[float] = []
    for month_idx in range(12):
        month_data = heatmap_data[:, month_idx]
        valid_data = month_data[~numpy.isnan(month_data)]
        monthly_averages.append(float(numpy.mean(valid_data)) if len(valid_data) > 0 else float("nan"))

    extended = numpy.full((32, 12), numpy.nan)
    extended[:31, :] = heatmap_data
    extended[31, :] = monthly_averages

    im = axis.imshow(extended, aspect="auto", cmap="YlOrRd", interpolation="nearest", origin="upper")
    month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    axis.set_xticks(range(12))
    axis.set_xticklabels(month_names)
    axis.set_xlabel("Month")
    y_ticks = list(range(0, 31, 5)) + [31]
    y_labels = [str(i) for i in range(1, 32, 5)] + ["Avg"]
    axis.set_yticks(y_ticks)
    axis.set_yticklabels(y_labels)
    axis.set_ylabel("Day of month / Monthly average")
    for month_idx in range(12):
        if not numpy.isnan(monthly_averages[month_idx]):
            text = f"{monthly_averages[month_idx]:.1f}"
            axis.text(
                month_idx,
                31,
                text,
                ha="center",
                va="center",
                fontweight="bold",
                color="white" if monthly_averages[month_idx] > numpy.nanmean(monthly_averages) else "black",
                fontsize=7,
            )
    cbar = axis.figure.colorbar(im, ax=axis, fraction=0.046, pad=0.04)
    cbar.set_label(value_label, rotation=270, labelpad=12)


def show_context_solar_figure(solar_model: SolarModel) -> None:
    """1×2 figure: daily horizontal solar energy heatmap + annual energy per 1 m² surface orientation."""
    powers = _unit_canonic_powers_W(solar_model)
    datetimes = solar_model.site_weather_data.datetimes
    horizontal = powers["HORIZONTAL_UP"]
    if len(datetimes) != len(horizontal):
        n = min(len(datetimes), len(horizontal))
        datetimes = datetimes[:n]
        horizontal = horizontal[:n]

    daily_dt, daily_kwh = _daily_horizontal_kwh_m2(datetimes, horizontal)

    w_in, h_in = float(plot_size[0]), float(plot_size[1])
    fig, (ax_left, ax_right) = plt.subplots(1, 2, figsize=(w_in * 2.35, h_in * 1.08), layout="constrained")

    _draw_monthly_heatmap_solar_axis(
        ax_left,
        daily_dt,
        daily_kwh,
        value_label="kWh/day.m2",
    )
    ax_left.set_title("Solar energy in kWh/day.m2")

    categories = list(powers.keys())
    annual_kwh_m2 = [sum(powers[name]) / 1000.0 for name in categories]
    x = numpy.arange(len(categories))
    ax_right.bar(x, annual_kwh_m2, color="tab:orange", edgecolor="0.25", linewidth=0.5, alpha=0.88)
    ax_right.set_xticks(x)
    ax_right.set_xticklabels(categories, rotation=25, ha="right")
    ax_right.set_ylabel("kWh/m2.year")
    ax_right.set_title("Collected solar energy on different surfaces")
    ax_right.grid(True, axis="y", alpha=0.35)

    plt.show()
