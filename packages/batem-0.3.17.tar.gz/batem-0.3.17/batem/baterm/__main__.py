from batem.baterm import main

if __name__ == "__main__":
    main()
