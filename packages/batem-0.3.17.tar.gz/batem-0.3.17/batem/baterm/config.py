"""Paths and constants for the BATEM terminal."""

from pathlib import Path

# Directory containing ``core/``, ``tools/``, this ``baterm/`` package, etc.
# (``batem/baterm/config.py`` -> parent is ``batem/baterm/``, grandparent is ``batem/``.)
BATEM_PACKAGE_DIR: Path = Path(__file__).resolve().parent.parent

# Parent of the ``batem`` package: add this to ``PYTHONPATH`` for ``python -m batem.tools...``
# workers so ``import batem`` resolves (repo root in editable checkouts; ``site-packages``
# when ``batem`` is installed as a normal package).
BATEM_REPO_ROOT: Path = BATEM_PACKAGE_DIR.parent
