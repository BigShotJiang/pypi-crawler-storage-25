"""Long-horizon outdoor climate figures (same logic as :meth:`batem.core.lambdahouse.Analyzes.evolution`)."""

from __future__ import annotations

from datetime import datetime

import matplotlib.pyplot as plt
import numpy
from matplotlib.axes import Axes

from batem.core.building import ContextData
from batem.core.lambdahouse import plot_size
from batem.core.weather import SWDbuilder, SiteWeatherData, convert_from_to_naming


def load_full_archive_site_weather(context_data: ContextData) -> SiteWeatherData:
    """Return :class:`~batem.core.weather.SiteWeatherData` for the whole span stored in the location JSON."""
    swd_builder = SWDbuilder(
        location=context_data.location,
        latitude_north_deg=context_data.latitude_north_deg,
        longitude_east_deg=context_data.longitude_east_deg,
        initial_year=1980,
        end_year=None,
    )
    return swd_builder(
        from_stringdate=None,
        to_stringdate=None,
        albedo=context_data.albedo,
        pollution=context_data.pollution,
        from_to_naming=convert_from_to_naming(),
    )


def _draw_annual_temperature_trend_axis(
    axis: Axes,
    title: str,
    datetimes: list[datetime],
    temperatures: list[float],
    reference_year: int,
    *,
    start_year: int = 1980,
) -> None:
    """Match :meth:`batem.core.lambdahouse.ReportGenerator.add_annual_temperature_trend` (matplotlib part)."""
    year_temperatures: dict[int, list[float]] = {}
    for i, dt in enumerate(datetimes):
        year = dt.year
        if start_year <= year <= reference_year:
            if year not in year_temperatures:
                year_temperatures[year] = []
            if temperatures[i] is not None:
                year_temperatures[year].append(temperatures[i])

    years = sorted(year_temperatures.keys())
    if len(years) < 2:
        axis.text(0.5, 0.5, "Not enough yearly samples for a trend (need ≥ 2 years).", ha="center", va="center", transform=axis.transAxes)
        axis.set_title(title)
        return

    avg_temperatures = [sum(year_temperatures[y]) / len(year_temperatures[y]) for y in years]
    years_array = numpy.array(years)
    temps_array = numpy.array(avg_temperatures)
    coeffs = numpy.polyfit(years_array, temps_array, 1)
    slope = float(coeffs[0])
    intercept = float(coeffs[1])
    trend_line = slope * years_array + intercept

    axis.scatter(years, avg_temperatures, alpha=0.6, s=50, label="Annual average temperature", color="blue")
    axis.plot(years, trend_line, "r-", linewidth=2, label=f"Trend: {slope:.4f} °C/year", alpha=0.8)
    axis.set_xlabel("Year")
    axis.set_ylabel("Average temperature (°C)")
    axis.set_title(f"{title}\nTrend: {slope:.4f} °C/year")
    axis.legend()
    axis.grid(True, alpha=0.3)


def _draw_annual_rainfall_trend_axis(
    axis: Axes,
    title: str,
    datetimes: list[datetime],
    precipitations: list[float],
    reference_year: int,
    *,
    start_year: int = 1980,
) -> None:
    """Match :meth:`batem.core.lambdahouse.ReportGenerator.add_annual_rainfall_trend` (matplotlib part)."""
    year_precipitations: dict[int, list[float]] = {}
    for i, dt in enumerate(datetimes):
        year = dt.year
        if start_year <= year <= reference_year:
            if year not in year_precipitations:
                year_precipitations[year] = []
            if precipitations[i] is not None and precipitations[i] >= 0:
                year_precipitations[year].append(precipitations[i])

    years = sorted(year_precipitations.keys())
    if len(years) < 2:
        axis.text(0.5, 0.5, "Not enough yearly samples for a trend (need ≥ 2 years).", ha="center", va="center", transform=axis.transAxes)
        axis.set_title(title)
        return

    cumulative_rainfall = [sum(year_precipitations[y]) for y in years]
    years_array = numpy.array(years)
    rainfall_array = numpy.array(cumulative_rainfall)
    coeffs = numpy.polyfit(years_array, rainfall_array, 1)
    slope = float(coeffs[0])
    intercept = float(coeffs[1])
    trend_line = slope * years_array + intercept

    axis.scatter(years, cumulative_rainfall, alpha=0.6, s=50, label="Annual cumulative rainfall", color="blue")
    axis.plot(years, trend_line, "r-", linewidth=2, label=f"Trend: {slope:.2f} mm/year", alpha=0.8)
    axis.set_xlabel("Year")
    axis.set_ylabel("Cumulative rainfall (mm)")
    axis.set_title(f"{title}\nTrend: {slope:.2f} mm/year")
    axis.legend()
    axis.grid(True, alpha=0.3)


def show_context_evolution_figure(context_data: ContextData) -> None:
    """1×2 figure aligned with ``Analyzes.evolution`` / annual temperature + rainfall trend plots."""
    swd = load_full_archive_site_weather(context_data)
    datetimes: list[datetime] = swd.datetimes
    if not datetimes:
        raise ValueError("Weather archive has no timestamps.")

    try:
        temps = swd.get("temperature")
        precip = swd.get("precipitation")
    except ValueError as exc:
        raise ValueError("Archive is missing temperature or precipitation series.") from exc

    reference_year = int(context_data.simulated_year)
    n = min(len(datetimes), len(temps), len(precip))
    datetimes = datetimes[:n]
    temps = temps[:n]
    precip = precip[:n]

    w_in, h_in = float(plot_size[0]), float(plot_size[1])
    fig, (ax_left, ax_right) = plt.subplots(1, 2, figsize=(w_in * 2.2, h_in * 1.05), layout="constrained")

    _draw_annual_temperature_trend_axis(
        ax_left,
        "Long term outdoor temperature evolution",
        datetimes,
        temps,
        reference_year,
        start_year=1980,
    )
    _draw_annual_rainfall_trend_axis(
        ax_right,
        "Long term outdoor rainfalls evolution (annual cumulated)",
        datetimes,
        precip,
        reference_year,
        start_year=1980,
    )

    plt.show()
