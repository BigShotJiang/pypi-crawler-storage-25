"""Discover and resolve BATEM workshop notebooks (``workshopXX_*.ipynb``)."""

from __future__ import annotations

import re
from pathlib import Path


def list_workshop_notebooks(root: Path) -> list[Path]:
    """Return ``workshop*.ipynb`` files under ``root``, sorted by name."""
    return sorted(root.glob("workshop*.ipynb"), key=lambda path: path.name.lower())


def resolve_workshop_notebook(root: Path, token: str) -> Path | None:
    """Resolve a user token to a single workshop notebook path, or ``None`` if ambiguous/missing."""
    notebooks = list_workshop_notebooks(root)
    key = token.strip().lower()
    if not key:
        return None

    for notebook in notebooks:
        if notebook.name.lower() == key or notebook.stem.lower() == key:
            return notebook

    number_match = re.fullmatch(r"(?:workshop)?(\d{1,2})", key.replace("workshop", ""))
    if number_match:
        prefix = f"workshop{int(number_match.group(1)):02d}_"
        numbered = [nb for nb in notebooks if nb.name.lower().startswith(prefix)]
        if len(numbered) == 1:
            return numbered[0]
        return None

    partial = [nb for nb in notebooks if key in nb.name.lower()]
    if len(partial) == 1:
        return partial[0]
    return None
