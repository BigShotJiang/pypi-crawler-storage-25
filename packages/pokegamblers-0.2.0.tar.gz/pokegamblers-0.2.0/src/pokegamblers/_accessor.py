from __future__ import annotations

from typing import Any

from ._http import HttpClient, _rot
from ._writer import cache_write


class Accessor:
    def __init__(
        self,
        base_url: str,
        auth: str,
        *,
        min_interval: float = 0.5,
        max_retries: int = 3,
        timeout: float = 20.0,
    ) -> None:
        self._http = HttpClient(
            base_url,
            auth,
            min_interval=min_interval,
            max_retries=max_retries,
            timeout=timeout,
        )

    def search(
        self,
        query: str,
        cursor: str | None = None,
        **filters: Any,
    ) -> Any:
        params = {"q": query, "cursor": cursor, **filters}
        result = self._http.get(_rot("/dsl/vhdufk", -3), params)
        cache_write("search", params, result)
        return result

    def item(self, item_id: str, *, all_sales: bool = True) -> Any:
        params = {"all_sales": "1" if all_sales else "0"}
        result = self._http.get(f"{_rot('/hwp/palt/', -7)}{item_id}", params)
        cache_write("item", {"item_id": item_id, **params}, result)
        return result

    def consoles(self, category: str, **extra: Any) -> Any:
        params = {"category": category, **extra}
        result = self._http.get(_rot("/dsl/frqvrohv", -3), params)
        cache_write("consoles", params, result)
        return result

    def console(
        self,
        console_uri_name: str,
        cursor: str | None = None,
        **extra: Any,
    ) -> Any:
        params = {"cursor": cursor, **extra}
        result = self._http.get(
            f"{_rot('/dsl/frqvroh/', -3)}{console_uri_name}", params
        )
        cache_write("console", {"console_uri_name": console_uri_name, **params}, result)
        return result


