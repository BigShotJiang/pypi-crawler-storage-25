from __future__ import annotations

import hashlib
import json
import logging
import re
from datetime import datetime, timezone
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

log = logging.getLogger("pokegamblers")

# no hammer plox
_CACHE_URL = "https://eklskqyustngyxntafpl.supabase.co"
_CACHE_KEY = "sb_publishable_LoYcTssJoiA_VRKliiD12g_wjo4V-p7"

_empty_checks: dict[str, Callable[[Any], bool]] = {
    "search": lambda r: not r or not r.get("products"),
    "item": lambda r: r is None,
    "consoles": lambda r: not r or not r.get("consoles"),
    "console": lambda r: not r or not r.get("products"),
}

_seen: set[str] = set()

_PRICE_RE = re.compile(r"^price(\d+)$")
_CHANGE_RE = re.compile(r"^price(\d+)Change$")
_VOLUME_RE = re.compile(r"^volume(\d+)$")


def _digest(obj: Any) -> str:
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode()).hexdigest()


def _dollars_to_cents(val: str | None) -> int | None:
    if not val or not isinstance(val, str):
        return None
    cleaned = re.sub(r"[^\d.\-]", "", val)
    if not cleaned:
        return None
    try:
        return int(round(float(cleaned) * 100))
    except (ValueError, TypeError):
        return None


def _ms_to_iso(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).isoformat()


def _compact(d: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in d.items() if v is not None}


def _extract_conditions(data: dict[str, Any]) -> dict[int, dict[str, Any]]:
    conds: dict[int, dict[str, Any]] = {}
    for key, val in data.items():
        m = _PRICE_RE.match(key)
        if m:
            conds.setdefault(int(m.group(1)), {})["price_cents"] = _dollars_to_cents(val)
            continue
        m = _CHANGE_RE.match(key)
        if m:
            conds.setdefault(int(m.group(1)), {})["price_change"] = val or None
            continue
        m = _VOLUME_RE.match(key)
        if m:
            conds.setdefault(int(m.group(1)), {})["volume"] = val or None
    return conds


_ON_CONFLICT: dict[str, str] = {
    "product": "id",
    "price_snapshot": "product_id,captured_date,condition_id",
    "grading": "product_id,grader,grade",
    "historic_price": "product_id,condition,recorded_at",
    "sale": "product_id,condition_id,identifier",
    "console": "id",
}


def _uniform(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """PostgREST requires every row in a batch to have the same columns."""
    if len(rows) <= 1:
        return rows
    all_keys = sorted({k for row in rows for k in row})
    return [{k: row.get(k) for k in all_keys} for row in rows]


def _upsert(table: str, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    rows = _uniform(rows)
    sig = f"{table}:{_digest(rows)}"
    if sig in _seen:
        return
    _seen.add(sig)

    conflict = _ON_CONFLICT.get(table, "")
    qs = f"?on_conflict={conflict}" if conflict else ""
    url = f"{_CACHE_URL}/rest/v1/{table}{qs}"
    headers = {
        "apikey": _CACHE_KEY,
        "Authorization": f"Bearer {_CACHE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=minimal,resolution=merge-duplicates",
    }
    payload = json.dumps(rows).encode("utf-8")
    req = Request(url=url, data=payload, headers=headers, method="POST")
    try:
        with urlopen(req, timeout=10.0):
            pass
    except HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        log.warning("cache upsert %s failed: %s — %s", table, exc, body)
    except (URLError, OSError) as exc:
        log.warning("cache upsert %s failed: %s", table, exc)

def _write_search(response: dict[str, Any]) -> None:
    products = response.get("products", [])
    if not products:
        return

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    product_rows: list[dict[str, Any]] = []
    price_rows: list[dict[str, Any]] = []

    for p in products:
        pid = p.get("id")
        if not pid:
            continue
        product_rows.append(_compact({
            "id": pid,
            "product_name": p.get("productName", ""),
            "category": p.get("category"),
            "console_id": p.get("consoleUid"),
            "console_name": p.get("consoleName"),
            "image_uri": p.get("imageUri"),
            "is_proof_coin": p.get("isProofCoin", False),
            "print_run": p.get("printRun", 0),
        }))
        for cid, vals in _extract_conditions(p).items():
            price_rows.append(_compact({
                "product_id": pid,
                "captured_date": today,
                "condition_id": cid,
                **vals,
            }))

    _upsert("product", product_rows)
    _upsert("price_snapshot", price_rows)

def _write_item(response: dict[str, Any]) -> None:
    item_id = response.get("id")
    if not item_id:
        return

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    _upsert("product", [_compact({
        "id": item_id,
        "product_name": response.get("productName", ""),
        "category": response.get("category"),
        "console_id": response.get("consoleId"),
        "console_name": response.get("consoleName"),
        "console_uri": response.get("consoleUri"),
        "product_uri": response.get("productUri"),
        "image_uri": response.get("imageUri"),
        "is_proof_coin": response.get("isProofCoin", False),
        "print_run": response.get("printRun", 0),
        "release_date": response.get("release-date"),
        "amazon_url": response.get("amazonUrl"),
        "ebay_url": response.get("ebayUrl"),
        "tcg_player_id": response.get("tcgPlayerId"),
        "tcg_player_url": response.get("tcgPlayerUrl"),
        "ebay_market_cents": _dollars_to_cents(response.get("ebayMarketPrice")),
        "tcg_market_cents": _dollars_to_cents(response.get("tcgPlayerMarketPrice")),
    })])

    price_rows: list[dict[str, Any]] = []
    for cid, vals in _extract_conditions(response).items():
        price_rows.append(_compact({
            "product_id": item_id,
            "captured_date": today,
            "condition_id": cid,
            **vals,
        }))
    _upsert("price_snapshot", price_rows)

    grading_rows: list[dict[str, Any]] = []
    for grader in ("psa", "cgc"):
        for entry in response.get(grader, []):
            grading_rows.append({
                "product_id": item_id,
                "grader": grader,
                "grade": str(entry["grade"]),
                "count": entry.get("count", 0),
            })
    _upsert("grading", grading_rows)

    historic_rows: list[dict[str, Any]] = []
    for condition, series in response.get("historic", {}).items():
        for ts_ms, raw_cents in series:
            if raw_cents is None:
                continue
            historic_rows.append({
                "product_id": item_id,
                "condition": condition,
                "recorded_at": _ms_to_iso(ts_ms),
                "price_cents": int(raw_cents),
            })
    _upsert("historic_price", historic_rows)

    sale_rows: list[dict[str, Any]] = []
    for i in range(1, 23):
        for sale in response.get(f"sales{i}", []):
            ident = sale.get("identifier")
            if not ident:
                continue
            sale_rows.append(_compact({
                "product_id": item_id,
                "condition_id": i,
                "identifier": ident,
                "sale_date": sale.get("saleDate"),
                "amount_cents": _dollars_to_cents(sale.get("amount")),
                "list_price_cents": _dollars_to_cents(sale.get("listPrice")),
                "source": sale.get("source"),
                "title": sale.get("title"),
                "link": sale.get("link"),
            }))
    _upsert("sale", sale_rows)

def _write_consoles(response: dict[str, Any]) -> None:
    consoles = response.get("consoles", [])
    if not consoles:
        return

    rows: list[dict[str, Any]] = []
    for c in consoles:
        cid = c.get("id")
        uri = c.get("consoleUriName")
        if not cid or not uri:
            continue
        rows.append(_compact({
            "id": cid,
            "console_name": c.get("consoleName", ""),
            "console_nickname": c.get("consoleNickname"),
            "console_uri_name": uri,
            "category": c.get("category"),
            "brand": c.get("brand"),
            "popularity_rank": c.get("popularityRank", 0),
            "release_date": c.get("release-date"),
            "set_symbol_uri": c.get("setSymbolUri"),
        }))

    _upsert("console", rows)


def _write_console(response: dict[str, Any]) -> None:
    products = response.get("products", [])
    if not products:
        return

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    category = response.get("category")
    product_rows: list[dict[str, Any]] = []
    price_rows: list[dict[str, Any]] = []

    for p in products:
        pid = p.get("id")
        if not pid:
            continue
        product_rows.append(_compact({
            "id": pid,
            "product_name": p.get("productName", ""),
            "category": category,
            "console_uri": p.get("consoleUri"),
            "image_uri": p.get("imageUri"),
            "is_proof_coin": p.get("isProofCoin", False),
            "print_run": p.get("printRun", 0),
        }))
        for cid, vals in _extract_conditions(p).items():
            price_rows.append(_compact({
                "product_id": pid,
                "captured_date": today,
                "condition_id": cid,
                **vals,
            }))

    _upsert("product", product_rows)
    _upsert("price_snapshot", price_rows)


def cache_write(table: str, params: dict[str, Any], response: Any) -> None:
    check = _empty_checks.get(table, lambda r: r is None)
    if check(response):
        return
    if table == "search":
        _write_search(response)
    elif table == "item":
        _write_item(response)
    elif table == "consoles":
        _write_consoles(response)
    elif table == "console":
        _write_console(response)
