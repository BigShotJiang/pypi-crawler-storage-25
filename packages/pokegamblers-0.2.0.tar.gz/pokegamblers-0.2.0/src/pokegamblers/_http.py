from __future__ import annotations

import json
import logging
import random
import threading
import time
from typing import Any
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

log = logging.getLogger("pokegamblers")

_INTERVAL_FLOOR = 0.3 # no hammer plox

def _rot(s: str, n: int) -> str:
    out: list[str] = []
    for c in s:
        if "a" <= c <= "z":
            out.append(chr((ord(c) - 97 + n) % 26 + 97))
        elif "A" <= c <= "Z":
            out.append(chr((ord(c) - 65 + n) % 26 + 65))
        else:
            out.append(c)
    return "".join(out)


class HttpClient:
    def __init__(
        self,
        base_url: str,
        auth: str,
        *,
        min_interval: float = 1.0,
        max_retries: int = 5,
        timeout: float = 20.0,
        user_agent: str = "okhttp/5.3.2",
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._auth = auth
        self._min_interval = max(min_interval, _INTERVAL_FLOOR)
        self._max_retries = max_retries
        self._timeout = timeout
        self._user_agent = user_agent
        self._lock = threading.Lock()
        self._next_at = 0.0

    def _reserve_slot(self) -> float:
        with self._lock:
            now = time.monotonic()
            delay = self._next_at - now
            self._next_at = max(now, self._next_at) + self._min_interval
        return max(delay, 0.0)

    def _headers(self) -> dict[str, str]:
        return {
            "Accept": "application/json",
            "Accept-Language": "en-US",
            "User-Agent": self._user_agent,
            "Authorization": self._auth,
        }

    def get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        *,
        base_url: str | None = None,
    ) -> Any:
        base = (base_url or self._base_url).rstrip("/")
        url = f"{base}/{path.lstrip('/')}"
        if params:
            filtered = {k: v for k, v in params.items() if v is not None}
            if filtered:
                url = f"{url}?{urlencode(filtered, doseq=True)}"

        for attempt in range(self._max_retries + 1):
            delay = self._reserve_slot()
            if delay > 0:
                time.sleep(delay)

            req = Request(url=url, headers=self._headers(), method="GET")
            try:
                with urlopen(req, timeout=self._timeout) as resp:
                    body = resp.read().decode("utf-8")
                    if not body:
                        return None
                    ct = resp.headers.get("Content-Type", "")
                    if "application/json" in ct.lower():
                        return json.loads(body)
                    try:
                        return json.loads(body)
                    except json.JSONDecodeError:
                        return body
            except HTTPError as exc:
                if exc.code != 429 or attempt >= self._max_retries:
                    raise

                retry_after = exc.headers.get("Retry-After") if exc.headers else None
                if retry_after:
                    try:
                        backoff = float(retry_after)
                    except ValueError:
                        backoff = _exp_backoff(attempt)
                else:
                    backoff = _exp_backoff(attempt)

                log.warning(
                    "429 — retrying in %.1fs (%d/%d)",
                    backoff,
                    attempt + 1,
                    self._max_retries,
                )
                time.sleep(backoff)

        raise RuntimeError("unreachable")


def _exp_backoff(attempt: int) -> float:
    return min(2**attempt, 60) + random.uniform(0, 1)
