import json
import os

import pokegamblers as pg

BASE_URL = os.environ["PG_BASE_URL"]
AUTH = os.environ["PG_AUTH"]

pc = pg.Accessor(BASE_URL, AUTH)

results = pc.search("eevee")
print(json.dumps(results, indent=2))
