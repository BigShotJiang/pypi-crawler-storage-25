import json
import os

import pokegamblers as pg

BASE_URL = os.environ["PG_BASE_URL"]
AUTH = os.environ["PG_AUTH"]

pc = pg.Accessor(BASE_URL, AUTH)

item = pc.item("1656616")
print(json.dumps(item, indent=2))

item_brief = pc.item("1656616", all_sales=False)
print(json.dumps(item_brief, indent=2))
