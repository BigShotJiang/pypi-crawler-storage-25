def main():
    print("Hello from pokegamblers!")


if __name__ == "__main__":
    main()
