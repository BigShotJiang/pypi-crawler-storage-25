# pokegamblers

## Quickstart

```
pip install pokegamblers
```

```python
import pokegamblers as pg

pc = pg.Accessor("https://example.com", "Bearer YOUR_TOKEN")
results = pc.search("eevee")
```

## Setup

**uv**

```
git clone <repo-url>
cd pokegamblers
uv sync
```

**pip**

```
pip install .
```

### Constructor

```python
pc = pg.Accessor(
    "https://example.com",
    "Bearer YOUR_TOKEN",
    min_interval=0.5,
    max_retries=3,
    timeout=20.0,
)
```

## API Reference

### search

```python
pc.search("prismatic")
pc.search("prismatic", cursor="abc123")
pc.search("prismatic", category="pokemon-cards")
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `query` | `str` | required | Search query |
| `cursor` | `str \| None` | `None` | Pagination cursor |
| `**filters` | `Any` | | Additional query parameters |

### item

```python
pc.item("8244610")
pc.item("8244610", all_sales=False)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `item_id` | `str` | required | Item ID |
| `all_sales` | `bool` | `True` | Include full sales history across conditions, be careful |

### consoles

```python
pc.consoles("pokemon-cards")
pc.consoles("pokemon-cards", page_size=50)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `category` | `str` | required | Console category slug |
| `**extra` | `Any` | | Additional query parameters |

### console

```python
pc.console("pokemon-prismatic-evolutions")
pc.console("pokemon-prismatic-evolutions", cursor="abc123")
pc.console("pokemon-prismatic-evolutions", page_size=50)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `console_uri_name` | `str` | required | Console URI name (slug) |
| `cursor` | `str \| None` | `None` | Pagination cursor |
| `**extra` | `Any` | | Additional query parameters |