import unittest

from sheafsegment import boundaries, find_gaps, merge_segments


class SegmentTests(unittest.TestCase):
    def test_merge_segments(self) -> None:
        self.assertEqual(merge_segments([(0, 2), (1, 4), (7, 9)]), [(0, 4), (7, 9)])

    def test_boundaries(self) -> None:
        self.assertEqual(boundaries([(0, 2), (1, 4)]), [0, 4])

    def test_find_gaps(self) -> None:
        self.assertEqual(find_gaps([(1, 3), (5, 6)], lower=0, upper=8), [(0, 1), (3, 5), (6, 8)])

