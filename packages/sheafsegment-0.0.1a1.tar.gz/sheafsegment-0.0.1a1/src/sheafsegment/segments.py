from __future__ import annotations


def merge_segments(segments: list[tuple[int, int]]) -> list[tuple[int, int]]:
    if not segments:
        return []
    segments = sorted(segments)
    merged = [segments[0]]
    for start, end in segments[1:]:
        last_start, last_end = merged[-1]
        if start <= last_end:
            merged[-1] = (last_start, max(last_end, end))
        else:
            merged.append((start, end))
    return merged


def boundaries(segments: list[tuple[int, int]]) -> list[int]:
    merged = merge_segments(segments)
    output: list[int] = []
    for start, end in merged:
        output.extend([start, end])
    return output


def find_gaps(segments: list[tuple[int, int]], *, lower: int, upper: int) -> list[tuple[int, int]]:
    merged = merge_segments(segments)
    cursor = lower
    gaps: list[tuple[int, int]] = []
    for start, end in merged:
        if start > cursor:
            gaps.append((cursor, start))
        cursor = max(cursor, end)
    if cursor < upper:
        gaps.append((cursor, upper))
    return gaps

