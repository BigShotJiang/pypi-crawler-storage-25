def project_info() -> dict[str, str]:
    return {
        "name": "sheafsegment",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheafsegment-python",
    }

