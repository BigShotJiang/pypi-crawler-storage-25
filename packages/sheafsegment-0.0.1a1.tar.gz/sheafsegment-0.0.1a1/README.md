# sheafsegment

`sheafsegment` is the official Python package namespace for lightweight segment
and boundary helpers used by the SheafLab project.

This initial public release covers interval merging, boundary extraction, and
gap finding for compact locality and segmentation work.

