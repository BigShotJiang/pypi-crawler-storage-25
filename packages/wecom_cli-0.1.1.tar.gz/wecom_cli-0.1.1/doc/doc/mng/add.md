# 新建文档

## 最后更新：2025/07/16

该接口用于新建文档、表格及智能表格，新建收集表可前往 [收集表管理](#43942) 查看。

### 请求方式
POST（**HTTPS**）

### 请求地址
https://qyapi.weixin.qq.com/cgi-bin/wedoc/create_doc?access_token=ACCESS_TOKEN

### 参数说明

| 参数 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| spaceid | string | 否 | 空间spaceid。若指定`spaceid`，则`fatherid`也要同时指定 |
| fatherid | string | 否 | 父目录fileid, 在根目录时为空间spaceid |
| doc_type | uint32 | 是 | 文档类型, 3:文档 4:表格 10:智能表格 |
| doc_name | string | 是 | 文档名字（注意：文件名最多填255个字符, 超过255个字符会被截断） |
| admin_users | string[] | 否 | 文档管理员userid |

### 返回示例

```json
{
    "errcode": 0,
    "errmsg": "ok",
    "url": "URL",
    "docid": "DOCID"
}

参数说明
参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
url	string	新建文档的访问链接
docid	string	新建文档的docid。docid仅在创建时返回，需要开发者妥善保存