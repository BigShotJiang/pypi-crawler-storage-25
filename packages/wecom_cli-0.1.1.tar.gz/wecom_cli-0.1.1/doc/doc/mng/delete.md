删除文档
=======

最后更新：2025/12/25

该接口用于删除指定文档、表格、智能表格及收集表。

**请求方式**：POST（**HTTPS**）

**请求地址**: https://qyapi.weixin.qq.com/cgi-bin/wedoc/del\_doc?access\_token=ACCESS\_TOKEN

**请求包体**

```json
{
	"docid": "DOCID",
	"formid": "FORMID"
}


点击复制

参数说明
参数	类型	是否必须	说明
docid	string	否	文档docid（docid、formid只能填其中一个），仅可删除应用自己创建的文档
formid	string	否	收集表id（docid、formid只能填其中一个），仅可删除应用自己创建的收集表
返回示例
{
	"errcode": 0,
	"errmsg": "ok"
}


点击复制

参数说明
参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明