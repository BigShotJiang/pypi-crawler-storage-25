# 分享文档

## 最后更新：2024/05/30

该接口用于获取文档、表格、智能表格及收集表的分享链接。

### 请求方式
POST（HTTPS）

### 请求地址
https://qyapi.weixin.qq.com/cgi-bin/wedoc/doc\_share?access\_token=ACCESS\_TOKEN 

### 参数说明

| 参数 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| docid | string | 否 | 文档id（docid、formid只能填其中一个） |

### 返回示例

```json
{
    "errcode": 0,
    "errmsg": "ok",
    "share_url": "URL1"
}

参数说明
参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
share_url	string	文档分享链接