# 重命名文档

## 最后更新：2024/10/28

该接口用于对指定文档、表格、智能表格及收集表进行重命名。

### 请求方式
POST（**HTTPS**）

### 请求地址
https://qyapi.weixin.qq.com/cgi-bin/wedoc/rename_doc?access_token=ACCESS_TOKEN

### 参数说明

| 参数 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| docid | string | 否 | 文档docid（docid、formid只能填其中一个），仅可修改应用自己创建的文档 |
| formid | string | 否 | 收集表id（docid、formid只能填其中一个），仅可修改应用自己创建的收集表 |
| new_name | string | 是 | 重命名后的文档名（注意：文档名最多填255个字符，英文算1个，汉字算2个，超过255个字符会被截断） |

### 返回示例
```json
{
    "errcode": 0,
    "errmsg": "ok"
}

参数说明
参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明