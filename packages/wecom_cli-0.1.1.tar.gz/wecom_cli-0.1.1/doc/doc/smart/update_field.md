更新字段
最后更新：2025/06/06
更新字段
参数详细说明
      UpdateField
更新字段
本接口用于更新智能中的某个子表里的一个或多个字段的标题和字段属性信息。
注意
该接口只能更新字段名、字段属性，不能更新字段类型。
请求方式：POST(HTTPS)
请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/update_fields?access_token=ACCESS_TOKEN

请求包体：

{
	"docid": "DOCID",
	"sheet_id": "SHEETID",
	"fields": [{
		"field_id": "FIELD_ID",
		"field_title": "TITLE",
		"field_type": "FIELD_TYPE_TEXT"
	}]
}
参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	表格ID
fields	object [](UpdateField)	是	字段详情
 

权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例

{
	"errcode": 0,
	"errmsg": "ok",
	"fields": [{
		"field_id": "FIELDID",
		"field_title": "TITLE",
		"field_type": "FIELD_TYPE_TEXT"
	}]
}
参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
fields	object [](Field)	字段详情
参数详细说明
UpdateField
字段信息：
注意
字段属性与字段类型是匹配的，一种字段类型对应一种字段属性
更新时field_title和property_number至少需要传一个，field_title不能被更新为原值
 

参数名	类型	是否必填	描述
field_id	string	是	字段 ID，更新字段属性时需要填写该字段，但字段 ID 不能被更新
field_title	string	否	字段标题，需要更新为的字段标题
field_type	string	是	字段类型，见FieldType ，必须为原属性
property_text	object	否	文本 类型的字段属性为空
property_number	object(NumberFieldProperty)	否	数字 类型的字段属性
property_checkbox	object(CheckboxFieldProperty)	否	复选框 类型的字段属性
property_date_time	object(DateTimeFieldProperty)	否	日期 类型的字段属性
property_attachment	object(AttachmentFieldProperty)	否	文件 类型的字段属性
property_user	object(UserFieldProperty)	否	人员 类型的字段属性
property_url	object(UrlFieldProperty)	否	超链接 类型的字段属性
property_select	object(SelectFieldProperty)	否	多选 类型的字段属性
property_created_user	object	否	创建人 类型的字段属性为空
property_modified_user	object	否	最后编辑人 类型的字段属性为空
property_created_time	object(CreatedTimeFieldProperty)	否	创建时间 类型的字段属性
property_modified_time	object(ModifiedTimeFieldProperty)	否	最后编辑时间 类型的字段属性
property_progress	object(ProgressFieldProperty)	否	进度 类型的字段属性
property_single_select	object(SingleSelectFieldProperty)	否	单选 类型的字段属性
property_reference	object(PropertyReference)	否	引用 类型的字段属性
property_location	object(LocationFieldProperty)	否	地理位置 类型的字段属性
property_auto_number	object(AutoNumberFieldProperty)	否	自动编号 类型的字段属性
property_currency	object(CurrencyFieldProperty)	否	货币 类型的字段属性
property_ww_group	object(WwGroupFieldProperty)	否	群 类型的字段属性
property_percentage	object(PercentageFieldProperty)	否	百分数 类型的字段属性
property_barcode	object(BarcodeFieldProperty)	否	条码 类型的字段属性
上一篇
删除字段
下一篇
查询字段
