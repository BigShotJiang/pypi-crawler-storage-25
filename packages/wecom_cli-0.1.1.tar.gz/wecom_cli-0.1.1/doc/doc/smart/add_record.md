添加记录
最后更新：2026/03/06
添加记录
参数详细说明
      CellValueKeyType
      AddRecord
      CommonRecord
      Value
      CellTextValue
      CellImageValue
      CellAttachmentValue
      CellUserValue
      CellUrlValue
      Option
      CellLocationValue
添加记录
本接口用于在 Smartsheet 中的某个子表里添加一行或多行新记录。单表最多允许有100000行记录，15000000个单元格。单次添加建议在500行内
注意
不能通过添加记录接口给创建时间、最后编辑时间、创建人和最后编辑人四种类型的字段添加记录。

请求方式：POST(HTTPS)
请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/add_records?access_token=ACCESS_TOKEN

请求包体：

{
	"docid": "DOCID",
	"sheet_id": "123Abc",
	"key_type": "CELL_VALUE_KEY_TYPE_FIELD_TITLE",
	"records": [{
		"values": {
			"FIELD_TITLE": [{
				"type": "text",
				"text": "文本内容"
			}]
		}
	}]
}
或

{
	"docid": "DOCID",
	"sheet_id": "123Abc",
	"key_type": "CELL_VALUE_KEY_TYPE_FIELD_ID",
	"records": [{
		"values": {
			"FIELD_ID": [{
				"type": "text",
				"text": "文本内容"
			}]
		}
	}]
}
FIELD_TITLE和FIELD_ID需要替换为字段标题或者字段ID
 

参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	Smartsheet 子表ID
key_type	string(CellValueKeyType)	否	返回记录中单元格的key类型，默认用标题
records	Object[](AddRecord)	是	需要添加的记录的具体内容组成的 JSON 数组
 

权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例

{
    "errcode": 0,
    "errmsg": "ok",
    "records": [
			
    ]
}
参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
records	Object[](CommonRecord)	由添加成功的记录的具体内容组成的 JSON 数组
参数详细说明
 

CellValueKeyType
记录(CommonRecord 或 AddRecord)中key的类型

枚举类型	描述
CELL_VALUE_KEY_TYPE_FIELD_TITLE	key用字段标题表示
CELL_VALUE_KEY_TYPE_FIELD_ID	key用字段 ID 表示
AddRecord
添加记录：

参数名	类型	描述
values	Object	记录的具体内容，key 为字段标题或字段 ID ，value 详见(Value)
CommonRecord
在 Smartsheet 的某个表格中添加记录响应、更新记录请求和更新记录响应的通用参数：

参数名	类型	描述
record_id	string	记录 ID
values	Object	记录的具体内容，key 为字段标题或字段 ID ，value 详见(Value)
 

Value
各种类型的字段对应的单元格的值

字段类型	单元格值类型	描述
文本(FIELD_TYPE_TEXT)	Object[](CellTextValue)	 
数字(FIELD_TYPE_NUMBER)	double	 
复选框(FIELD_TYPE_CHECKBOX)	bool	 
日期(FIELD_TYPE_DATE_TIME)	string(以毫秒为单位的unix时间戳)	 
图片(FIELD_TYPE_IMAGE)	Object[](CellImageValue)	 
文件(FIELD_TYPE_ATTACHMENT)	Object[](CellAttachmentValue)	 
成员(FIELD_TYPE_USER)	Object[](CellUserValue)	 
链接(FIELD_TYPE_URL)	Object[](CellUrlValue)	数组类型为预留能力，目前只支持展示一个链接，建议只传入一个链接
多选(FIELD_TYPE_SELECT)	Object[](Option)	 
进度(FIELD_TYPE_PROGRESS)	double	 
电话(FIELD_TYPE_PHONE_NUMBER)	string	 
邮箱(FIELD_TYPE_EMAIL)	string	 
单选(FIELD_TYPE_SINGLE_SELECT)	Object[](Option)	 
地理位置(FIELD_TYPE_LOCATION)	Object[](CellLocationValue)	长度不大于1的数组。
货币(FIELD_TYPE_CURRENCY)	double	
百分数(FIELD_TYPE_PERCENTAGE)	double	
条码(FIELD_TYPE_BARCODE)	string	 
 

CellTextValue
文本类型字段的单元值类型

参数名	类型	描述
type	string	内容为文本(值为text)、内容为链接(值为url)
text	string	单元格内容
link	string	当type时url时，表示链接跳转url
CellImageValue
参数名	类型	描述
id	string	图片 ID,自定义id
title	string	图片标题
image_url	string	图片链接，通过上传图片接口获取
width	int32	图片宽度
height	int32	图片高度
CellAttachmentValue
示例

{
	"doc_type": 2,
	"file_ext": "SMARTSHEET",
	"file_id": "FILEID",
	"file_type": "70",
	"file_url": "https://doc.weixin.qq.com/smartsheet/xxx",
	"name": "智能表格",
	"size": 3267
}
参数名	类型	描述
name	string	文件名
size	int32	文件大小
file_ext	string	文件扩展名。文件夹为空，文件为对应文件拓展名，收集表为FORM，文档为DOC，表格为SHEET，幻灯片为SLIDE，思维导图为MIND，流程图为FLOWCHART，智能表为SMARTSHEET
file_id	string	文件ID
file_url	string	文件url ，如果是微盘文档则通过获取分享链接获得，如果是文档，则为文档url
file_type	string	文件类型。文件夹为Folder，微盘文件为Wedrive，收集表为30，文档为50，表格是51，幻灯片为52，思维导图为54，流程图为55，智能表为70
doc_type	string	文件类型，用于区分文件夹和文件，1为文件夹，2为文件
CellUserValue
参数名	类型	描述
user_id	string	成员ID
CellUrlValue
数组类型为预留能力，目前只支持展示一个链接，建议只传入一个链接
示例

{
	"link": "https://developer.work.weixin.qq.com/document/path/97392",
	"text": "企业微信开发者中心",
	"type": "url"
}
参数名	类型	描述
type	string	填url
text	string	链接显示文本
link	string	链接跳转url
 

Option
示例

{
	"id": "1"
}
参数名	类型	描述
id	string	选项ID，当选项存在时，通过ID识别选项，当需要新增选项，则不填写此字段
style	int(Style)	选项颜色。新增选项时填写
text	string	要填写的选项内容。新增选项时填写，已经存在时优先匹配已经存在的选项，否则会新增选项
CellLocationValue
示例

{
	"id": "14313005936863363130",
	"latitude": "23.10647",
	"longitude": "113.32446",
	"source_type": 1,
	"title": "广州塔"
}
参数名	类型	描述
source_type	uint32	填1，表示来源为腾讯地图。目前只支持腾讯地图来源
id	string	地点ID
latitude	string	纬度
longitude	string	经度
title	string	地点名称
上一篇
查询字段
下一篇
删除记录
