删除子表
=======

最后更新：2024/09/12

目录

* [删除子表](#%E5%88%A0%E9%99%A4%E5%AD%90%E8%A1%A8)

### 删除子表

本接口用于删除在线表格中的某个智能表。

**请求方式**：POST(HTTPS)  
**请求地址**：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/delete_sheet?access_token=ACCESS\_TOKEN

**请求包体**：

```json
{
    "docid": "DOCID",
    "sheet_id": "123Abc"
}


点击复制

参数说明
参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	删除的Smartsheet 子表 ID
返回示例
{
    "errcode": 0,
    "errmsg": "ok"
}