查询子表
=======

**请求方式**: POST(HTTPS)

**请求地址**: https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/get_sheet?access_token=ACCESS_TOKEN

**参数说明**

| 参数 | 类型 | 是否必须 | 说明 |
| --- | --- | --- | --- |
| docid | string | 是 | 文档的docid |
| sheet_id | string | 否 | 指定子表ID查询 |
| need_all_type_sheet | bool | 否 | 获取所有类型子表。为true时可获取包含仪表盘和说明页在内的所有类型的子表 |

**返回示例**

```json
{
    "errcode": 0,
    "errmsg": "ok",
    "sheet_list": [
        {
            "sheet_id": "123abc",
            "title": "XXXX",
            "is_visible": true,
            "type": "smartsheet"
        },
        {
            "sheet_id": "456abc",
            "title": "仪表盘1",
            "is_visible": true,
            "type": "dashboard"
        },
        {
            "sheet_id": "789abc",
            "title": "如何搭建自己的智能表格",
            "is_visible": true,
            "type": "external"
        }
    ]
}


参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
sheet_list	object[] 智能表信息	
sheet_list.sheet_id	string 智能表ID	
sheet_list.title	string 智能表名称	
sheet_list.is_visible	bool 智能表是否可见	
sheet_list.type	string 智能表类型。“dashboard” 仪表盘。“external” 说明页，“smartsheet” 智能表	