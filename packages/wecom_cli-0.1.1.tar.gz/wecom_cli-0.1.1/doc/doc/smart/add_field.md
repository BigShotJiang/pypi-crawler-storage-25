
## [](https://developer.work.weixin.qq.com/document/path/99904#%E6%B7%BB%E5%8A%A0%E5%AD%97%E6%AE%B5)添加字段

本接口用于在智能表中的某个子表里添加一列或多列新字段。单表最多允许有150个字段。

**请求方式**：POST(HTTPS)  
**请求地址**：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/add_fields?access_token=ACCESS_TOKEN

**请求包体**：

```json
{
	"docid": "DOCID",
	"sheet_id": "SHEETID",
	"fields": [{
		"field_title": "TITLE",
		"field_type": "FIELD_TYPE_TEXT"
	}]
}
```

**参数说明**

|参数|类型|是否必须|说明|
|:--|---|---|---|
|docid|string|是|文档的docid|
|sheet_id|string|是|表格ID|
|fields|object [] [(AddFiled)](https://developer.work.weixin.qq.com/document/path/99904#addfield)|是|字段详情|

**权限说明**

- 自建应用需配置到“[可调用应用](https://developer.work.weixin.qq.com/document/path/99904#43883)”列表中的应用secret所获取的accesstoken来调用（[accesstoken如何获取？](https://developer.work.weixin.qq.com/document/path/99904#10013/%E7%AC%AC%E4%B8%89%E6%AD%A5%EF%BC%9A%E8%8E%B7%E5%8F%96access_token)）
- 第三方应用需具有“文档”权限
- 代开发自建应用需具有“文档”权限

**返回示例**

```json
{
	"errcode": 0,
	"errmsg": "ok",
	"fields": [{
		"field_id": "FIELDID",
		"field_title": "TITLE",
		"field_type": "FIELD_TYPE_TEXT"
	}]
}
```

**参数说明**

|参数|类型|说明|
|:--|---|---|
|errcode|int32|错误码|
|errmsg|string|错误码说明|
|fields|object [] [(Filed)](https://developer.work.weixin.qq.com/document/path/99904#53117/field)|字段详情|

## [](https://developer.work.weixin.qq.com/document/path/99904#%E5%8F%82%E6%95%B0%E8%AF%A6%E7%BB%86%E8%AF%B4%E6%98%8E)参数详细说明

### [](https://developer.work.weixin.qq.com/document/path/99904#addfield)AddField

字段信息：

![](data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHJ4PSI4IiBmaWxsPSIjQjM2NzFEIi8+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04IDNDNy40NDc3MiAzIDcgMy40NDc3MiA3IDRWOEM3IDguNTUyMjggNy40NDc3MiA5IDggOUM4LjU1MjI4IDkgOSA4LjU1MjI4IDkgOFY0QzkgMy40NDc3MiA4LjU1MjI4IDMgOCAzWk04IDExQzcuNDQ3NzIgMTEgNyAxMS40NDc3IDcgMTJDNyAxMi41NTIzIDcuNDQ3NzIgMTMgOCAxM0M4LjU1MjI4IDEzIDkgMTIuNTUyMyA5IDEyQzkgMTEuNDQ3NyA4LjU1MjI4IDExIDggMTFaIiBmaWxsPSJ3aGl0ZSIvPjwvc3ZnPg==)注意

字段属性与字段类型是匹配的，一种字段类型对应一种字段属性  

|参数名|类型|是否必填|描述|
|:--|---|---|---|
|field_title|string|是|字段标题|
|field_type|string|是|字段类型，见[FieldType](https://developer.work.weixin.qq.com/document/path/99904#53114/fieldtype) ，必须为原属性|
|property_number|object([NumberFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/numberfieldproperty))|是|`数字` 类型的字段属性|
|property_checkbox|object([CheckboxFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/checkboxfieldproperty))|否|`复选框` 类型的字段属性|
|property_date_time|object([DateTimeFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/datetimefieldproperty))|是|`日期` 类型的字段属性|
|property_attachment|object([AttachmentFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/attachmentfieldproperty))|否|`文件` 类型的字段属性|
|property_user|object([UserFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/userfieldproperty))|否|`人员` 类型的字段属性|
|property_url|object([UrlFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/urlfieldproperty))|是|`超链接` 类型的字段属性|
|property_select|object([SelectFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/selectfieldproperty))|是|`多选` 类型的字段属性|
|property_created_time|object([CreatedTimeFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/createdtimefieldproperty))|是|`创建时间` 类型的字段属性|
|property_modified_time|object([ModifiedTimeFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/modifiedtimefieldproperty))|是|`最后编辑时间` 类型的字段属性|
|property_progress|object([ProgressFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/progressfieldproperty))|是|`进度` 类型的字段属性|
|property_single_select|object([SingleSelectFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/singleselectfieldproperty))|是|`单选` 类型的字段属性|
|property_reference|object([ReferenceFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/referencefieldproperty))|是|`引用` 类型的字段属性|
|property_location|object([LocationFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/locationfieldproperty))|是|`地理位置` 类型的字段属性|
|property_auto_number|object([AutoNumberFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/autonumberfieldproperty))|是|`自动编号` 类型的字段属性|
|property_currency|object([CurrencyFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/autonumberfieldproperty))|是|`货币` 类型的字段属性|
|property_ww_group|object([WwGroupFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/wwgroupfieldproperty))|否|`群` 类型的字段属性|
|property_percentage|object([PercentageFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/percentagefieldproperty))|否|`百分数` 类型的字段属性|
|property_barcode|object([BarcodeFieldProperty](https://developer.work.weixin.qq.com/document/path/99904#53114/barcodefieldproperty))|否|`条码` 类型的字段属性|

### [](https://developer.work.weixin.qq.com/document/path/99904#fieldtype)FieldType

|字段类型|说明|
|---|---|
|FIELD_TYPE_TEXT|文本|
|FIELD_TYPE_NUMBER|数字|
|FIELD_TYPE_CHECKBOX|复选框|
|FIELD_TYPE_DATE_TIME|日期|
|FIELD_TYPE_IMAGE|图片|
|FIELD_TYPE_ATTACHMENT|文件|
|FIELD_TYPE_USER|成员|
|FIELD_TYPE_URL|超链接|
|FIELD_TYPE_SELECT|多选|
|FIELD_TYPE_CREATED_USER|创建人|
|FIELD_TYPE_MODIFIED_USER|最后编辑人|
|FIELD_TYPE_CREATED_TIME|创建时间|
|FIELD_TYPE_MODIFIED_TIME|最后编辑时间|
|FIELD_TYPE_PROGRESS|进度|
|FIELD_TYPE_PHONE_NUMBER|电话|
|FIELD_TYPE_EMAIL|邮件|
|FIELD_TYPE_SINGLE_SELECT|单选|
|FIELD_TYPE_REFERENCE|关联|
|FIELD_TYPE_LOCATION|地理位置|
|FIELD_TYPE_CURRENCY|货币|
|FIELD_TYPE_WWGROUP|群|
|FIELD_TYPE_AUTONUMBER|自动编号|
|FIELD_TYPE_PERCENTAGE|百分数|
|FIELD_TYPE_BARCODE|条码|

### [](https://developer.work.weixin.qq.com/document/path/99904#numberfieldproperty)NumberFieldProperty

数字类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|decimal_places|int([DecimalPlaces](https://developer.work.weixin.qq.com/document/path/99904#53117/decimalplaces))|表示小数点的位数，即数字精度|
|use_separate|bool|是否使用千位符，设置此属性后数字字段将以英文逗号分隔千分位，如 1,000|

### [](https://developer.work.weixin.qq.com/document/path/99904#checkboxfieldproperty)CheckboxFieldProperty

复选框类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|checked|bool|新增时是否默认勾选|

### [](https://developer.work.weixin.qq.com/document/path/99904#datetimefieldproperty)DateTimeFieldProperty

日期类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|format|string([Format](https://developer.work.weixin.qq.com/document/path/99904#53117/format))|设置日期格式|
|auto_fill|bool|新建记录时，是否自动填充时间|

### [](https://developer.work.weixin.qq.com/document/path/99904#attachmentfieldproperty)AttachmentFieldProperty

文件类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|display_mode|string([DisplayMode](https://developer.work.weixin.qq.com/document/path/99904#53117/displaymode))|设置日期格式|

### [](https://developer.work.weixin.qq.com/document/path/99904#userfieldproperty)UserFieldProperty

成员类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|is_multiple|bool|允许添加多个人员|
|is_notified|bool|添加人员时通知用户，关闭后不通知|

### [](https://developer.work.weixin.qq.com/document/path/99904#urlfieldproperty)UrlFieldProperty

超链接类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|type|string([LinkType](https://developer.work.weixin.qq.com/document/path/99904#53117/linktype))|超链接展示样式|

### [](https://developer.work.weixin.qq.com/document/path/99904#selectfieldproperty)SelectFieldProperty

多选类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|is_quick_add|bool|是否允许填写时新增选项，用户不需要设置该参数|
|options|object [] ]([Option](https://developer.work.weixin.qq.com/document/path/99904#53117/option))|多选选项的格式设置|

### [](https://developer.work.weixin.qq.com/document/path/99904#createdtimefieldproperty)CreatedTimeFieldProperty

创建时间类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|format|string([Format](https://developer.work.weixin.qq.com/document/path/99904#53117/format))|设置日期格式|

### [](https://developer.work.weixin.qq.com/document/path/99904#modifiedtimefieldproperty)ModifiedTimeFieldProperty

最后编辑时间类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|format|string([Format](https://developer.work.weixin.qq.com/document/path/99904#53117/format))|设置日期格式|

### [](https://developer.work.weixin.qq.com/document/path/99904#progressfieldproperty)ProgressFieldProperty

进度类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|decimal_places|int([DecimalPlaces](https://developer.work.weixin.qq.com/document/path/99904#53117/decimalplaces))|小数位数|

### [](https://developer.work.weixin.qq.com/document/path/99904#singleselectfieldproperty)SingleSelectFieldProperty

单选类型字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|is_quick_add|bool|是否允许填写时新增选项，用户不需要设置该参数|
|options|object [] ([Option](https://developer.work.weixin.qq.com/document/path/99904#53117/option))|单选选项的格式设置|

### [](https://developer.work.weixin.qq.com/document/path/99904#referencefieldproperty)ReferenceFieldProperty

关联字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|sub_id|string|关联的子表id，为空时，表示关联本子表|
|filed_id|string|关联的字段id|
|is_multiple|bool|是否允许多选|
|view_id|string|视图id|

### [](https://developer.work.weixin.qq.com/document/path/99904#locationfieldproperty)LocationFieldProperty

地理位置字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|input_type|string([LocationInputType](https://developer.work.weixin.qq.com/document/path/99904#53117/locationinputtype))|输入类型|

### [](https://developer.work.weixin.qq.com/document/path/99904#locationfieldproperty-3)LocationFieldProperty

地理位置字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|input_type|string([LocationInputType](https://developer.work.weixin.qq.com/document/path/99904#53117/locationinputtype))|输入类型|

### [](https://developer.work.weixin.qq.com/document/path/99904#autonumberfieldproperty)AutoNumberFieldProperty

自动编号字段属性信息：

|参数名|类型|描述|
|:--|---|---|
|type|string([NumberType](https://developer.work.weixin.qq.com/document/path/99904#53117/numbertype))|输入类型|
|rules|object[] ([NumberRule](https://developer.work.weixin.qq.com/document/path/99904#53117/numberrule))|自定义规则|
|reformat_existing_record|bool|是否应用于已有编号|

### [](https://developer.work.weixin.qq.com/document/path/99904#currencyfieldproperty)CurrencyFieldProperty

货币类型字段属性

|参数名|类型|描述|
|:--|---|---|
|currency_type|string([CurrencyType](https://developer.work.weixin.qq.com/document/path/99904#53117/currencytype))|输入类型|
|decimal_places|int([DecimalPlaces](https://developer.work.weixin.qq.com/document/path/99904#53117/decimalplaces))|表示小数点的位数，即数字精度|
|use_separate|bool|是否使用千位符，设置此属性后数字字段将以英文逗号分隔千分位，如 1,000|

### [](https://developer.work.weixin.qq.com/document/path/99904#wwgroupfieldproperty)WwGroupFieldProperty

群类型的字段属性

|参数名|类型|描述|
|:--|---|---|
|allow_multiple|bool|是否允许多个群聊|

### [](https://developer.work.weixin.qq.com/document/path/99904#percentagefieldproperty)PercentageFieldProperty

百分数类型的字段属性

|参数名|类型|描述|
|:--|---|---|
|decimal_places|int([DecimalPlaces](https://developer.work.weixin.qq.com/document/path/99904#53117/decimalplaces))|表示小数点的位数，即数字精度|
|use_separate|bool|是否使用千位符，设置此属性后数字字段将以英文逗号分隔千分位，如 1,000|

### [](https://developer.work.weixin.qq.com/document/path/99904#barcodefieldproperty)BarcodeFieldProperty

条码类型的字段属性

|参数名|类型|描述|
|:--|---|---|
|mobile_scan_only|bool|仅限手机扫描录入|

[上一篇](https://developer.work.weixin.qq.com/document/path/101155)查询视图

[下一篇](https://developer.work.weixin.qq.com/document/path/99905)删除字段