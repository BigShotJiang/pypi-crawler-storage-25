删除字段
最后更新：2024/09/12
删除字段
删除字段
本接口用于删除智能表中的某个子表里的一列或多列字段。。

请求方式：POST(HTTPS)
请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/delete_fields?access_token=ACCESS_TOKEN

请求包体：

{
	"docid": "DOCID",
	"sheet_id": "SHEETID",
	"field_ids": [
		"FIELDID"
	]
}
参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	表格ID
field_ids	string[]	是	需要删除的字段id列表
权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例

{
    "errcode": 0,
    "errmsg": "ok"
}
参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
