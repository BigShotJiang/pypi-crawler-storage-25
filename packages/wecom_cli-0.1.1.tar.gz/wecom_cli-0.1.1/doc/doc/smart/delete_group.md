复制到剪贴板 反馈纠错
删除编组
最后更新：2025/08/19
删除编组
删除编组
本接口用于删除智能表的某个子表中的一个或多个编组。

请求方式：POST(HTTPS)
请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/delete_field_groups?access_token=ACCESS_TOKEN

请求包体：

{
	"docid": "DOCID",
	"sheet_id": "123Abc",
	"field_group_ids": [
		"fgCLYCF",
		"fgCLYCM"
	]
}
参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	子表ID
field_group_ids	string[]	是	要删除的编组 ID
权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例

{
    "errcode": 0,
    "errmsg": "ok"
}
参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
上一篇
添加编组
下一篇
更新编组
