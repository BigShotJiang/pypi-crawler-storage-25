## [](https://developer.work.weixin.qq.com/document/path/99902#%E6%9B%B4%E6%96%B0%E8%A7%86%E5%9B%BE)更新视图

本接口用于更新 Smartsheet 中的某个视图。

**请求方式**：POST(HTTPS)  
**请求地址**：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/update_view?access_token=ACCESS_TOKEN

**请求包体**：

```json
{
	"docid": "DOCID",
	"sheet_id": "123Abc",
	"view_id": "VIEWID",
	"view_title": "XXX",
	"property": {
	}
}
```

**参数说明**

|参数|类型|是否必须|说明|
|:--|---|---|---|
|docid|string|是|文档的docid|
|sheet_id|string|是|Smartsheet 子表ID|
|view_id|string|是|视图ID|
|view_title|string|否|视图标题|
|property|object([ViewProperty](https://developer.work.weixin.qq.com/document/path/99902#viewproperty))|否|视图的排序/过滤/分组/填色配置，详见[ViewProperty](https://developer.work.weixin.qq.com/document/path/99902#viewproperty)|

**权限说明**

- 自建应用需配置到“[可调用应用](https://developer.work.weixin.qq.com/document/path/99902#43883)”列表中的应用secret所获取的accesstoken来调用（[accesstoken如何获取？](https://developer.work.weixin.qq.com/document/path/99902#10013/%E7%AC%AC%E4%B8%89%E6%AD%A5%EF%BC%9A%E8%8E%B7%E5%8F%96access_token)）
- 第三方应用需具有“文档”权限
- 代开发自建应用需具有“文档”权限

**返回示例**

```json
{
	"errcode": 0,
	"errmsg": "ok",
	"view": {
	}
}
```

**参数说明**

|参数|类型|说明|
|:--|---|---|
|errcode|int32|错误码|
|errmsg|string|错误码说明|
|view|object([View](https://developer.work.weixin.qq.com/document/path/99902#view))|更新成功的视图内容|

## [](https://developer.work.weixin.qq.com/document/path/99902#%E5%8F%82%E6%95%B0%E8%AF%A6%E7%BB%86%E8%AF%B4%E6%98%8E)参数详细说明

### [](https://developer.work.weixin.qq.com/document/path/99902#view)View

**示例**

```json
{
	"view_id": "vabcde",
	"view_title": "默认视图",
	"view_type": "VIEW_TYPE_GRID",
	"property": {
	}
}
```

视图信息：

|参数名|类型|描述|
|:--|---|---|
|view_id|string|视图 ID|
|view_title|string|视图标题|
|view_type|string|视图类型。见[ViewType](https://developer.work.weixin.qq.com/document/path/99902#53110/viewtype)|
|property|object([ViewProperty](https://developer.work.weixin.qq.com/document/path/99902#viewproperty))|视图属性|

### [](https://developer.work.weixin.qq.com/document/path/99902#viewproperty)ViewProperty

**示例**

```json
{
	"auto_sort": false,
	"sort_spec": {},
	"filter_spec": {},
	"group_spec": {},
	"is_field_stat_enabled": false,
	"field_visibility": {
		"f1gHSR": false,
		"fabcde": false
	},
	"frozen_field_count": 0,
	"color_config": {
		"conditions": [{
			"id": "4840474257",
			"type": "VIEW_COLOR_CONDITION_TYPE_CELL",
			"color": "chromeAmberLighten_5",
			"condition": {
				"field_id": "fRCjJz",
				"field_type": "FIELD_TYPE_TEXT",
				"operator": "OPERATOR_CONTAINS",
				"string_value": {
					"value": [
						"5555"
					]
				}
			}
		}]
	}
}
```

**参数说明**

|参数名|类型|是否必须|描述|
|:--|---|---|---|
|auto_sort|bool|否|记录变更后自动重新排序|
|sort_spec|object([SortSpec](https://developer.work.weixin.qq.com/document/path/99902#sortspec))|否|排序设置|
|group_spec|object([GroupSpec](https://developer.work.weixin.qq.com/document/path/99902#groupspec))|否|分组设置|
|filter_spec|object([FilterSpec](https://developer.work.weixin.qq.com/document/path/99902#filterspec))|否|过滤设置|
|is_field_stat_enabled|bool|否|是否使用数据统计|
|field_visibility|object|否|类似map。 key为字段ID, value为布尔值表示是否显示|
|frozen_field_count|int32|否|冻结列数量，从首列开始|
|color_config|object([ViewColorConfig](https://developer.work.weixin.qq.com/document/path/99902#viewcolorconfig))|否|填色设置|

### [](https://developer.work.weixin.qq.com/document/path/99902#sortspec)SortSpec

**示例**

```json
{
	 "sort_infos": [
	 	{
			"field_id": "FIELDID1",
			"desc": false
		},
		{
			"field_id": "FIELDID2",
			"desc": true
		}
	 ]
}
```

**参数说明**

|参数名|类型|是否必须|描述|
|:--|---|---|---|
|sort_infos|object[]|否|参与排序的字段列表|
|sort_infos.field_id|string|是|字段id|
|sort_infoes.desc|bool|否|是否降序|

### [](https://developer.work.weixin.qq.com/document/path/99902#groupspec)GroupSpec

**示例**

```json
{
	 "groups": [
	 	{
			"field_id": "FIELDID1",
			"desc": false
		},
		{
			"field_id": "FIELDID2",
			"desc": true
		}
	 ]
}
```

**参数说明**

|参数名|类型|是否必须|描述|
|:--|---|---|---|
|groups|object[]|否|参与分组的字段列表|
|groups.field_id|string|是|字段id|
|groups.desc|bool|否|是否降序|

### [](https://developer.work.weixin.qq.com/document/path/99902#filterspec)FilterSpec

**示例**

```json
{
	"conjunction": "CONJUNCTION_AND",
	"conditions": [
	]
}
```

**参数说明**

|参数名|类型|是否必须|描述|
|:--|---|---|---|
|conjunction|string|是|多个conditions之间是以and(`CONJUNCTION_AND`)还是or(`CONJUNCTION_OR`)进行组合|
|conditions|object[]([Condition](https://developer.work.weixin.qq.com/document/path/99902#condition))|是|判断条件|

### [](https://developer.work.weixin.qq.com/document/path/99902#condition)Condition

**注：不同字段类型支持的筛选不同，需要根据智能表格不同字段类型实际支持的筛选条件进行组合**

**示例1**  
过滤`FIELDID1`字段包含文本`hello world`的记录

```json
{
	"field_id": "FIELDID1",
	"operator": "OPERATOR_CONTAINS",
	"string_value": {
		"value": ["hello world"]
	}
}
```

**示例2**  
过滤`FIELDID2`字段为用户`USERID1`的记录

```json
{
	"field_id": "FIELDID2",
	"operator": "OPERATOR_IS",
	"user_value": {
		"value": ["USERID1"]
	}
}
```

**示例3**  
过滤`FIELDID3`字段为日期`2025年5月14日`的记录

```json
{
	"field_id": "FIELDID3",
	"field_type": "FIELD_TYPE_DATE_TIME",
	"operator": "OPERATOR_IS",
	"date_time_value": {
		"type": "DATE_TIME_TYPE_DETAIL_DATE",
		"value": [
			"1747152000000"
		]
	}
}
```

**参数说明**

|参数名|类型|是否必须|描述|
|:--|---|---|---|
|field_id|string|是|字段ID|
|field_type|stiring|是|字段类型|
|operator|string|是|判断类型。见[Operator](https://developer.work.weixin.qq.com/document/path/99902#operator)|
|string_value.value|string[]|否|文本、网址、电话、邮箱、地理位置、单选、多选等列类型使用。选项列为选项ID；其它为文本值|
|number_value.value|double|否|数字、进度列类型使用|
|bool_value.value|bool|否|复选框列类型使用|
|user_value.value|string[]|否|人员、创建人、最后编辑人列类型使用，值为成员ID|
|date_time_value|object([FilterDataTimeValue](https://developer.work.weixin.qq.com/document/path/99902#filterdatetimevalue))|否|日期、创建时间、最后编辑时间列类型使用|

### [](https://developer.work.weixin.qq.com/document/path/99902#operator)Operator

|筛选值判断操作类型|说明|
|:--|---|
|OPERATOR_UNKNOWN|未知|
|OPERATOR_IS|等于|
|OPERATOR_IS_NOT|不等于|
|OPERATOR_CONTAINS|包含|
|OPERATOR_DOES_NOT_CONTAIN|不包含|
|OPERATOR_IS_GREATER|大于|
|OPERATOR_IS_GREATER_OR_EQUAL|大于或等于|
|OPERATOR_IS_LESS|小于|
|OPERATOR_IS_LESS_OR_EQUAL|小于或等于|
|OPERATOR_IS_EMPTY|为空|
|OPERATOR_IS_NOT_EMPTY|不为空|

### [](https://developer.work.weixin.qq.com/document/path/99902#filterdatatimevalue)FilterDataTimeValue

|参数名|类型|是否必须|描述|
|:--|---|---|---|
|type|string|是|日期类型。见[DateTimeType](https://developer.work.weixin.qq.com/document/path/99902#datetimetype)|
|value|string[]|是|具体日期值，type为具体日期(`DATE_TIME_TYPE_DETAIL_DATE`)|

### [](https://developer.work.weixin.qq.com/document/path/99902#datetimetype)DateTimeType

|日期值类型|说明|
|:--|---|
|DATE_TIME_TYPE_DETAIL_DATE|具体时间|
|DATE_TIME_TYPE_TODAY|今天|
|DATE_TIME_TYPE_TOMORROW|明天|
|DATE_TIME_TYPE_YESTERDAY|昨天|
|DATE_TIME_TYPE_CURRENT_WEEK|本周|
|DATE_TIME_TYPE_LAST_WEEK|上周|
|DATE_TIME_TYPE_CURRENT_MONTH|本月|
|DATE_TIME_TYPE_THE_PAST_7_DAYS|过去 7 天内|
|DATE_TIME_TYPE_THE_NEXT_7_DAYS|接下来 7 天内|
|DATE_TIME_TYPE_LAST_MONTH|上月|
|DATE_TIME_TYPE_THE_PAST_30_DAYS|过去 30 天内|
|DATE_TIME_TYPE_THE_NEXT_30_DAYS|接下来 30 天内|

### [](https://developer.work.weixin.qq.com/document/path/99902#viewcolorconfig)ViewColorConfig

**示例**

```json
{
	"conditions": [
	]
}
```

**参数说明**

|参数名|类型|是否必须|描述|
|:--|---|---|---|
|conditions|object[]([ViewColorCondition](https://developer.work.weixin.qq.com/document/path/99902#viewcolorcondition))|是|判断条件|

### [](https://developer.work.weixin.qq.com/document/path/99902#viewcolorcondition)ViewColorCondition

**示例**

```json
{
	"id": "5599107762",
	"type": "VIEW_COLOR_CONDITION_TYPE_CELL",
	"color": "chromeOrangeLighten_5",
	"condition": {
		"field_id": "fMPZMg",
		"field_type": "FIELD_TYPE_NUMBER",
		"operator": "OPERATOR_IS",
		"number_value": {
			"value": 5
		}
	}
}
```

**参数说明**

|参数名|类型|是否必须|描述|
|:--|---|---|---|
|id|string|否|填色id，新增时不需要传入，更新时传入|
|type|string|是|填色类型,见([ViewColorConditionType](https://developer.work.weixin.qq.com/document/path/99902#viewcolorconditiontype))|
|color|string|是|颜色，见([ViewColor](https://developer.work.weixin.qq.com/document/path/99902#viewcolor))|
|conditions|object[]([Condition](https://developer.work.weixin.qq.com/document/path/99902#condition))|是|判断条件|

### [](https://developer.work.weixin.qq.com/document/path/99902#viewcolorconditiontype)ViewColorConditionType

|填色类型|说明|
|:--|---|
|VIEW_COLOR_CONDITION_TYPE_ROW|行|
|VIEW_COLOR_CONDITION_TYPE_COLUMN|列|
|VIEW_COLOR_CONDITION_TYPE_CELL|单元格|

### [](https://developer.work.weixin.qq.com/document/path/99902#viewcolor)ViewColor

|颜色值|描述|
|:--|---|
|fillColorGray_5|灰色_5|
|accentBlueLighten_5|蓝色_5|
|chromeCyanLighten_5|青色_5|
|chromeMintLighten_5|薄荷色_5|
|chromeRedLighten_5|红色_5|
|chromeOrangeLighten_5|橙色_5|
|chromeAmberLighten_5|琥珀色_5|
|chromeVioletLighten_5|紫色_5|
|chromePinkLighten_5|粉色_5|
|fillColorGray_4|灰色_4|
|accentBlueLighten_4|蓝色_4|
|chromeCyanLighten_4|青色_4|
|chromeMintLighten_4|薄荷色_4|
|chromeRedLighten_4|红色_4|
|chromeOrangeLighten_4|橙色_4|
|chromeAmberLighten_4|琥珀色_4|
|chromeVioletLighten_4|紫色_4|
|chromePinkLighten_4|粉色_4|
|fillColorGray_3|灰色_3|
|accentBlueLighten_3|蓝色_3|
|chromeCyanLighten_3|青色_3|
|chromeMintLighten_3|薄荷色_3|
|chromeRedLighten_3|红色_3|
|chromeOrangeLighten_3|橙色_3|
|chromeAmberLighten_3|琥珀色_3|
|chromeVioletLighten_3|紫色_3|
|chromePinkLighten_3|粉色_3|
