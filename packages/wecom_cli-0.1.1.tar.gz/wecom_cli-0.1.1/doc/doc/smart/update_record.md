更新记录
最后更新：2026/01/12
更新记录
参数详细说明
      CellValueKeyType
      UpdateRecord
      CommonRecord
更新记录
本接口用于更新 Smartsheet 中的某个子表里的一行或多行记录。单次更新建议在500行内
注意
不能通过更新记录接口给创建时间、最后编辑时间、创建人和最后编辑人四种类型的字段更新记录。

请求方式：POST(HTTPS)
请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/update_records?access_token=ACCESS_TOKEN

请求包体：

{
	"docid": "DOCID",
	"sheet_id": "123Abc",
	"key_type": "CELL_VALUE_KEY_TYPE_FIELD_TITLE",
	"records": [
	]
}
参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	Smartsheet 子表ID
key_type	string(CellValueKeyType)	否	返回记录中单元格的key类型
records	Object[](UpdateRecord)	是	由需要更新的记录组成的 JSON 数组
 

权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例

{
    "errcode": 0,
    "errmsg": "ok",
    "records": [
    ]
}
参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
records	Object[](CommonRecord)	由更新成功的记录的具体内容组成的 JSON 数组
参数详细说明
CellValueKeyType
记录(CommonRecord)中key的类型

枚举类型	描述
CELL_VALUE_KEY_TYPE_FIELD_TITLE	key用字段标题表示
CELL_VALUE_KEY_TYPE_FIELD_ID	key用字段 ID 表示
UpdateRecord
参数名	类型	描述
record_id	string	记录 ID
values	Object	记录的具体内容，key 为字段标题或字段 ID ，value 详见(Value)
CommonRecord
 

参数名	类型	描述
record_id	string	记录 ID
values	Object	记录的具体内容，key 为字段标题或字段 ID ，value 详见(Value)
 

上一篇
删除记录
下一篇
查询记录
