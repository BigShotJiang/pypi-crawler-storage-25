# 更新子表

## 最后更新：2024/09/12

### 目录

* [更新子表](#%E6%9B%B4%E6%96%B0%E5%AD%90%E8%A1%A8)

---

## 更新子表

本接口用于修改表格中某个子表的标题。

**请求方式**：POST(HTTPS)  
**请求地址**：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/update_sheet?access_token=ACCESS_TOKEN

**请求包体**：

```json
{
    "docid": "DOCID",
    "properties": {
        "sheet_id": "123abc",
        "title": "XXXX"
    }
}

参数说明
参数	类型	是否必须	说明
docid	string	是	文档的docid
properties.sheet_id	string	是	子表 ID
properties.title	string	否	子表标题
权限说明
自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例
{
    "errcode": 0,
    "errmsg": "ok"
}

参数说明
参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明