复制到剪贴板 反馈纠错
更新编组
最后更新：2025/09/03
更新编组
本接口用于在智能表中的某个子表里更新已有编组。每个编组最多允许有150个字段。字段只能同时存在于一个编组。

请求方式：POST(HTTPS)
请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/update_field_group?access_token=ACCESS_TOKEN

请求包体：

{
	"docid": "DOCID",
	"sheet_id": "SHEETID",
	"field_group_id":"FIELD_GROUP_ID",
	"name":"编组名称",
	"children": [
		{
			"field_id": "FIELD_ID"
		},
		{
			"field_id": "FIELD_ID"
		}]
}
参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	表格ID
field_group_id	string	是	编组id
name	string	否	编组名称，不能和已有名称重复
children	object[]	否	编组内容
children.field_id	string	否	字段id
权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例

{
	"errcode": 0,
	"errmsg": "ok",
	"field_group": {
		"field_group_id": "FIELD_GROUP_ID",
		"name": "编组名称",
		"children": [{
				"field_id": "FIELD_ID"
			},
			{
				"field_id": "FIELD_ID"
			}
		]
	}
}
参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
field_group_id	string	编组id
name	string	编组名称
children	object[]	编组内容
children.field_id	string	字段id
上一篇
删除编组
下一篇
获取编组
