# 添加视图

#### View

**示例**

```json
{
  "view_id": "vabcde",
  "view_title": "默认视图",
  "view_type": "VIEW_TYPE_GRID"
}


视图信息：

参数名	类型	描述
view_id	string	视图 ID
view_title	string	视图标题
view_type	string	视图类型。见ViewType
ViewType

视图类型：

枚举类型	描述
VIEW_UNKNOWN	未知类型视图，传递该值不合法
VIEW_TYPE_GRID	表格视图
VIEW_TYPE_KANBAN	看板视图
VIEW_TYPE_GALLERY	画册视图
VIEW_TYPE_GANTT	甘特视图
VIEW_TYPE_CALENDAR	日历视图
GanttViewProperty

甘特设置

参数名	类型	是否必须	描述
start_date_field_id	string	是	时间条起点字段ID，只允许日期类型(FIELD_TYPE_DATE_TIME)的字段ID
end_date_field_id	string	是	时间条终点字段ID，只允许日期类型(FIELD_TYPE_DATE_TIME)的字段ID
CalendarViewProperty

日历设置

参数名	类型	是否必须	描述
start_date_field_id	string	是	时间条起点字段ID，只允许日期类型(FIELD_TYPE_DATE_TIME)的字段ID
end_date_field_id	string	是	时间条终点字段ID，只允许日期类型(FIELD_TYPE_DATE_TIME)的字段ID
添加视图

本接口用于在 Smartsheet 中的某个子表里添加一个新视图。单表最多允许有200个视图。

请求方式：POST(HTTPS)

请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/add_view?access_token=ACCESS_TOKEN

请求包体：

{
    "docid": "DOCID",
    "sheet_id": "123Abc",
    "view_title": "XXX",
    "view_type": "VIEW_TYPE_GRID"
}


参数说明

| 参数名 || 类型 || 是否必须 || 描述 ||

| --------------:—:----:---------------------:-----------------------------------------------:-------------------------------:|

| docid : boolean : is : 文档的docid ||

| sheet_id : boolean : is : Smartsheet 子表ID ||

| view_title : string : is : 视图标题 ||

| view_type : string : is : 视图类型。见ViewType ||