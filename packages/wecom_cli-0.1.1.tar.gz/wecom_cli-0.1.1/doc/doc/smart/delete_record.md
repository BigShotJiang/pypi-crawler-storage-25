复制到剪贴板 反馈纠错
删除记录
最后更新：2026/01/12
删除记录
删除记录
本接口用于删除 Smartsheet 的某个子表中的一行或多行记录。单次删除建议在500行内

请求方式：POST(HTTPS)
请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/delete_records?access_token=ACCESS_TOKEN

请求包体：

{
	"docid": "DOCID",
	"sheet_id": "123Abc",
	"record_ids": [
		"re9IqD",
		"rpS0P9"
	]
}
参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	Smartsheet 子表ID
record_ids	string[]	是	要删除的记录 ID
权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例

{
    "errcode": 0,
    "errmsg": "ok"
}
参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
上一篇
添加记录
下一篇
更新记录
