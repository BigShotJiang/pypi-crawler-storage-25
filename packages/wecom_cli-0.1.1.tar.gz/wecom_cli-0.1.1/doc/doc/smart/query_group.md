复制到剪贴板 反馈纠错
获取编组
最后更新：2025/08/18
获取编组
本接口用于在智能表中的某个子表里获取已有的编组。

请求方式：POST(HTTPS)
请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/get_field_groups?access_token=ACCESS_TOKEN

请求包体：

{
	"docid": "DOCID",
	"sheet_id": "SHEETID",
	"offset":0,
	"limit":10
}
参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	表格ID
offset	uint32	否	偏移量，初始值为 0
limit	uint32	否	分页大小 , 每页返回多少条数据
权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例

{
	"errcode": 0,
	"errmsg": "ok",
	"total": 1,
	"has_more": false,
	"next": 0,
	"field_groups": [{
		"field_group_id": "FIELD_GROUP_ID",
		"name": "编组名称",
		"children": [{
			"field_id": "FIELD_ID"
		}]
	}]
}
参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
total	uint32	编组数量
has_more	bool	是否还有更多数据
next	uint32	下一偏移位置
field_groups	obj[]	编组列表
field_groups.field_group_id	string	编组id
field_groups.name	string	编组名称
field_groups.children	object[]	编组内容
field_groups.children.field_id	string	字段id
上一篇
更新编组
下一篇
获取文档权限信息
