删除视图
=======

最后更新：2024/09/12

目录

* [删除视图](#%E5%88%A0%E9%99%A4%E8%A7%86%E5%9B%BE)

### 删除视图

本接口用于在 smartsheet 中的某个子表里删除若干个视图。

**请求方式**：POST(HTTPS)  
**请求地址**：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/delete_views?access_token=ACCESS\_TOKEN

**请求包体**：

```json
{
    "docid": "DOCID",
    "sheet_id": "123Abc",
    "view_ids": [
        "VIEWID1", "VIEWID2"
    ]
}


参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	Smartsheet 子表ID
view_ids	string[]	是	要删除的视图ID列表

权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限

返回示例

{
    "errcode": 0,
    "errmsg": "ok"
}


参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
返回示例
{
    "errcode": 0,
    "errmsg": "ok"
}

返回示例
{
    "errcode": 0,
    "errmsg": "ok"
}
