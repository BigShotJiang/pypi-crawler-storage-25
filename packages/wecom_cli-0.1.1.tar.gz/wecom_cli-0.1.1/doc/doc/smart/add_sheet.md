# 添加子表

## 添加子表

本接口用于在表格的某个位置添加一个智能表，该智能表不存在视图、记录和字段，可以使用 API 在该智能表中添加视图、记录和字段。

**请求方式**：POST(HTTPS)  
**请求地址**：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/add_sheet?access_token=ACCESS_TOKEN

**请求包体**：

```json
{
    "docid": "DOCID",
    "properties": {
        "title": "智能表",
        "index": 3
    }
}

参数说明
参数	类型	是否必须	说明
docid	string	是	文档的docid
properties	object	否	智能表属性
properties.title	string	否	智能表标题
properties.index	int32	否	智能表下标
权限说明
自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例
{
    "errcode": 0,
    "errmsg": "ok",
    "properties": {
        "title": "智能表",
        "index": 3,
        "sheet_id": "123abc"
    }
}

参数说明
参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
properties.sheet_id	string	智能表 ID，创建子表时生成的 6 位随机 ID
properties.title	string	智能表标题
properties.index	int32	智能表下标
连接微信