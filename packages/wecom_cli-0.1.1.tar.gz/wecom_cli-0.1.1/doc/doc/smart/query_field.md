复制到剪贴板 反馈纠错
查询字段
最后更新：2025/11/05
查询字段
参数详细说明
      Field
      FieldType
      NumberFieldProperty
      CheckboxFieldProperty
      DateTimeFieldProperty
      AttachmentFieldProperty
      UserFieldProperty
      UrlFieldProperty
      SelectFieldProperty
      CreatedTimeFieldProperty
      ModifiedTimeFieldProperty
      ProgressFieldProperty
      SingleSelectFieldProperty
      ReferenceFieldProperty
      LocationFieldProperty
      AutoNumberFieldProperty
      CurrencyFieldProperty
      WwGroupFieldProperty
      PercentageFieldProperty
      BarcodeFieldProperty
      DecimalPlaces
      Format
      LinkType
      Option
      Style
      DisplayMode
      LocationInputType
      NumberType
      NumberRule
      CreateTimeFormat
      NumberRuleType
      CurrencyType
查询字段
本接口用于获取智能表中某个子表下字段信息，该接口可以完成下面三种功能：获取全部字段信息、依据字段名获取对应字段、依据字段 ID 获取对应字段信息。

请求方式：POST(HTTPS)
请求地址：https://qyapi.weixin.qq.com/cgi-bin/wedoc/smartsheet/get_fields?access_token=ACCESS_TOKEN

请求包体：

{
	"docid": "DOCID",
	"sheet_id": "SHEETID",
	"offset": 0,
	"limit": 10
}
参数说明

参数	类型	是否必须	说明
docid	string	是	文档的docid
sheet_id	string	是	表格ID
view_id	string	否	视图 ID
field_ids	string []	否	由字段 ID 组成的 JSON 数组
field_titles	string []	否	由字段标题组成的 JSON 数组
offset	int	否	偏移量，初始值为 0
limit	int	否	分页大小 , 每页返回多少条数据；当不填写该参数或将该参数设置为 0 时，如果总数大于 1000，一次性返回 1000 个字段，当总数小于 1000 时，返回全部字段；limit 最大值为 1000
权限说明

自建应用需配置到“可调用应用”列表中的应用secret所获取的accesstoken来调用（accesstoken如何获取？）
第三方应用需具有“文档”权限
代开发自建应用需具有“文档”权限
返回示例

{
	"errcode": 0,
	"errmsg": "ok",
	"total": 1,
	"fields": [{
		"field_id": "ID1",
		"field_title": "TITLE1",
		"field_type": "FIELD_TYPE_TEXT"
	}]
}
参数说明

参数	类型	说明
errcode	int32	错误码
errmsg	string	错误码说明
total	Object	字段总数
fields	object [](Field)	字段详情
参数详细说明
Field
字段信息：
注意
字段属性与字段类型是匹配的，一种字段类型对应一种字段属性
 

参数名	类型	描述
field_id	string	字段 ID
field_title	string	字段标题
field_type	string	字段类型，见FieldType
property_number	object(NumberFieldProperty)	数字 类型的字段属性
property_checkbox	object(CheckboxFieldProperty)	复选框 类型的字段属性
property_date_time	object(DateTimeFieldProperty)	日期 类型的字段属性
property_attachment	object(AttachmentFieldProperty)	文件 类型的字段属性
property_user	object(UserFieldProperty)	人员 类型的字段属性
property_url	object(UrlFieldProperty)	超链接 类型的字段属性
property_select	object(SelectFieldProperty)	多选 类型的字段属性
property_created_time	object(CreatedTimeFieldProperty)	创建时间 类型的字段属性
property_modified_time	object(ModifiedTimeFieldProperty)	最后编辑时间 类型的字段属性
property_progress	object(ProgressFieldProperty)	进度 类型的字段属性
property_single_select	object(SingleSelectFieldProperty)	单选 类型的字段属性
property_reference	object(PropertyReference)	引用 类型的字段属性
property_location	object(LocationFieldProperty)	地理位置 类型的字段属性
property_auto_number	object(AutoNumberFieldProperty)	自动编号 类型的字段属性
property_currency	object(CurrencyFieldProperty)	货币 类型的字段属性
property_ww_group	object(WwGroupFieldProperty)	群 类型的字段属性
property_percentage	object(PercentageFieldProperty)	百分数 类型的字段属性
property_barcode	object(BarcodeFieldProperty)	条码 类型的字段属性
FieldType
字段类型	说明
FIELD_TYPE_TEXT	文本
FIELD_TYPE_NUMBER	数字
FIELD_TYPE_CHECKBOX	复选框
FIELD_TYPE_DATE_TIME	日期
FIELD_TYPE_IMAGE	图片
FIELD_TYPE_ATTACHMENT	文件
FIELD_TYPE_USER	成员
FIELD_TYPE_URL	超链接
FIELD_TYPE_SELECT	多选
FIELD_TYPE_CREATED_USER	创建人
FIELD_TYPE_MODIFIED_USER	最后编辑人
FIELD_TYPE_CREATED_TIME	创建时间
FIELD_TYPE_MODIFIED_TIME	最后编辑时间
FIELD_TYPE_PROGRESS	进度
FIELD_TYPE_PHONE_NUMBER	电话
FIELD_TYPE_EMAIL	邮件
FIELD_TYPE_SINGLE_SELECT	单选
FIELD_TYPE_REFERENCE	关联
FIELD_TYPE_LOCATION	地理位置
FIELD_TYPE_FORMULA	公式
FIELD_TYPE_CURRENCY	货币
FIELD_TYPE_WWGROUP	群
FIELD_TYPE_AUTONUMBER	自动编号
FIELD_TYPE_PERCENTAGE	百分数
FIELD_TYPE_BARCODE	条码
NumberFieldProperty
数字类型字段属性信息：

参数名	类型	描述
decimal_places	int(DecimalPlaces)	表示小数点的位数，即数字精度
use_separate	bool	是否使用千位符，设置此属性后数字字段将以英文逗号分隔千分位，如 1,000
CheckboxFieldProperty
复选框类型字段属性信息：

参数名	类型	描述
checked	bool	新增时是否默认勾选
DateTimeFieldProperty
日期类型字段属性信息：

参数名	类型	描述
format	string(Format)	设置日期格式
auto_fill	bool	新建记录时，是否自动填充时间
AttachmentFieldProperty
文件类型字段属性信息：

参数名	类型	描述
display_mode	string(DisplayMode)	展示样式
UserFieldProperty
成员类型字段属性信息：

参数名	类型	描述
is_multiple	bool	允许添加多个人员
is_notified	bool	添加人员时通知用户，关闭后不通知
UrlFieldProperty
超链接类型字段属性信息：

参数名	类型	描述
type	string(LinkType)	超链接展示样式
SelectFieldProperty
多选类型字段属性信息：

参数名	类型	描述
is_quick_add	bool	是否允许填写时新增选项，用户不需要设置该参数
options	object [] ](Option)	多选选项的格式设置
CreatedTimeFieldProperty
创建时间类型字段属性信息：

参数名	类型	描述
format	string(Format)	设置日期格式
ModifiedTimeFieldProperty
最后编辑时间类型字段属性信息：

参数名	类型	描述
format	string(Format)	设置日期格式
ProgressFieldProperty
进度类型字段属性信息：

参数名	类型	描述
decimal_places	int(DecimalPlaces)	小数位数
SingleSelectFieldProperty
单选类型字段属性信息：

参数名	类型	描述
is_quick_add	bool	是否允许填写时新增选项，用户不需要设置该参数
options	object [] (Option)	单选选项的格式设置
ReferenceFieldProperty
关联字段属性信息：

参数名	类型	描述
sub_id	string	关联的子表id，为空时，表示关联本子表
filed_id	string	关联的字段id
is_multiple	bool	是否允许多选
view_id	string	视图id
LocationFieldProperty
地理位置字段属性信息：

参数名	类型	描述
input_type	string(LocationInputType)	输入类型
AutoNumberFieldProperty
自动编号字段属性信息：

参数名	类型	描述
type	string(NumberType)	输入类型
rules	object[] (NumberRule)	自定义规则
reformat_existing_record	bool	是否应用于已有编号
CurrencyFieldProperty
货币类型字段属性

参数名	类型	描述
currency_type	string(CurrencyType)	输入类型
decimal_places	int(DecimalPlaces)	表示小数点的位数，即数字精度
use_separate	bool	是否使用千位符，设置此属性后数字字段将以英文逗号分隔千分位，如 1,000
 

WwGroupFieldProperty
群类型的字段属性

参数名	类型	描述
allow_multiple	bool	是否允许多个群聊
PercentageFieldProperty
百分数类型的字段属性

参数名	类型	描述
decimal_places	int(DecimalPlaces)	表示小数点的位数，即数字精度
use_separate	bool	是否使用千位符，设置此属性后数字字段将以英文逗号分隔千分位，如 1,000
BarcodeFieldProperty
条码类型的字段属性

参数名	类型	描述
mobile_scan_only	bool	仅限手机扫描录入
DecimalPlaces
小数点后的位数：

数值	描述
-1	显示原值
0	代表整数
1	精确到小数点后一位（1.0）
2	精确到小数点后两位（1.00）
3	精确到小数点后三位（1.000）
4	精确到小数点后四位（1.0000）
Format
日期格式：

字符串	描述
yyyy"年"m"月"d"日"	2018 年 4 月 20 日
yyyy-mm-dd"	2018-04-20
yyyy/m/d	2018/4/20
m"月"d"日"	4 月 20 日
yyyy"年"m"月"d"日" dddd	2018 年 4 月 20 日 星期五
yyyy"年"m"月"d"日" hh:mm	2018 年 4 月 20 日 14:00
yyyy-mm-dd hh:mm	2018-04-20 14:00
m/d/yyyy	4/20/2018
d/m/yyyy	20/4/2018
LinkType
超链接展示样式可选值：

样式	描述
LINK_TYPE_PURE_TEXT	文字
LINK_TYPE_ICON_TEXT	图标文字
Option
Option 参数：

参数名	类型	描述
id	string	选项 ID
text	string	要填写的选项内容
style	int(Style)	选项颜色
Style
选项颜色：

数值	描述
1	浅红1
2	浅橙1
3	浅天蓝1
4	浅绿1
5	浅紫1
6	浅粉红1
7	浅灰1
8	白
9	灰
10	浅蓝1
11	浅蓝2
12	蓝
13	浅天蓝2
14	天蓝
15	浅绿2
16	绿
17	浅红2
18	红
19	浅橙2
20	橙
21	浅黄1
22	浅黄2
23	黄
24	浅紫2
25	紫
26	浅粉红2
27	粉红
DisplayMode
展示样式

展示样式	说明
DISPLAY_MODE_LIST	列表样式
DISPLAY_MODE_GRID	宫格样式
LocationInputType
地理位置输入类型

地理位置输入类型	说明
LOCATION_INPUT_TYPE_MANUAL	手动输入
LOCATION_INPUT_TYPE_AUTO	自动定位
NumberType
自动编号类型

自动编号类型	说明
NUMBER_TYPE_INCR	自增数字类型
NUMBER_TYPE_CUSTOM	自定义类型
NumberRule
自动编号规则	类型		说明
type	stringNumberRuleType	规则类型	 
value	string	存放创建时间格式CreateTimeFormat 或固定字符，自增数字位数	 
CreateTimeFormat
格式	说明
YYYYMMDD	20240301
YYYYMM	202403
MMDD	0301
YYYY	2024
MM	03
DD	01
NumberRuleType
数字规则类型

数字规则类型	说明
NUMBER_RULE_TYPE_INCR	自增id
NUMBER_RULE_TYPE_FIXED_CHAR	固定字符
NUMBER_RULE_TYPE_TIME	创建时间
CurrencyType
货币符号

货币符号类型	说明
CURRENCY_TYPE_CNY	人民币
CURRENCY_TYPE_USD	美元
CURRENCY_TYPE_EUR	欧元
CURRENCY_TYPE_GBP	英镑
CURRENCY_TYPE_JPY	日元
CURRENCY_TYPE_KRW	韩元
CURRENCY_TYPE_HKD	港元
CURRENCY_TYPE_MOP	澳门元
CURRENCY_TYPE_TWD	新台币
CURRENCY_TYPE_AED	阿联酋迪拉姆
CURRENCY_TYPE_AUD	澳大利亚元
CURRENCY_TYPE_BRL	巴西雷亚尔
CURRENCY_TYPE_CAD	加拿大元
CURRENCY_TYPE_CHF	瑞士法郎
CURRENCY_TYPE_IDR	印尼卢比
CURRENCY_TYPE_INR	印度卢比
CURRENCY_TYPE_MXN	墨西哥比索
CURRENCY_TYPE_MYR	马来西亚林吉特
CURRENCY_TYPE_PHP	菲律宾比索
CURRENCY_TYPE_PLN	波兰兹罗提
CURRENCY_TYPE_RUB	俄罗斯卢布
CURRENCY_TYPE_SGD	新加坡元
CURRENCY_TYPE_THB	泰国铢
CURRENCY_TYPE_TRY	土耳其里拉
CURRENCY_TYPE_VND	越南盾
上一篇
更新字段
下一篇
添加记录
