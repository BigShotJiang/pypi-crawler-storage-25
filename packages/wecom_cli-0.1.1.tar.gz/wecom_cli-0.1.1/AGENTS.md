# AGENTS.md - AI Agent 开发规范

## 开发流程

- 项目管理：本项目采用 uv 作为项目的环境依赖管理，请你全程采用`uv run xxx`来运行 python 程序
- 项目目录：每个功能的代码单独存放在自己目录当中，非必要不要存放在其他目录

### 1. 梳理需求

开发前确定好需求，并将需求放在 `plan/feature/` 之下，命名规则为 `xxx-xxx-feature.md`。文件最末尾是开发任务表，每个任务项都有一个对应的二级标题的任务详情描述；当需求完成时任务项也标记勾选了。请务必遵循此规则。

### 2. 建立开发分支

确定好需求之后，就使用 `enterprise-git-spec` 技能来建立分支。

### 3. 按照需求开发

按照当前功能的需求文档 `plan/feature/xxx-xxx-feature.md` 的任务项(如是修bug则 plan/fix/xxx-xxx-fix.md)，及其任务细节来逐步实现功能。开发使用 `python-testing-patterns` 技能来开发，全程严格地遵循 TDD 原则。

- 使用 test-driven-development 技能全程严格地遵循 TDD 原则, 并使用 python-testing-patterns 技能来编写测试用例 -> 测试驱动开发;
- 使用 python-design-patterns 技能进行构思代码的设计 -> 设计模式;
- 使用 python-code-style 技能规范 python 的注释编写, 主要遵循 Google 的风格样式 -> 注释即文档;
- 其他的编码最佳实践: python-error-handling -> 错误处理, python-resource-management -> 资源管理, python-anti-patterns -> 反面案例, python-type-safety -> 类型安全.

**重要原则：所有测试必须通过**
- 开发过程中，必须确保所有测试用例都通过，包括新功能的测试和现有功能的测试
- 运行 `uv run pytest` 时，不允许有任何失败的测试
- 如果发现现有测试失败，必须立即修复，确保新功能不会破坏旧功能
- 只有在所有测试都通过的情况下，才能认为开发完成

### 4. 沉淀开发经验

在实现功能过程中，将适用于任何项目的编码好想法、好思想、注意点等有助于项目推进的内容，及时追加到 `AGENTS.md` 中。这些经验是跨功能、跨项目的通用知识，帮助后续开发少走弯路。

### 5. 更新项目结构文档

每次功能开发完成后，更新 `structs.md` 文件。该文件记录整个项目的目录结构和每个模块的简要功能描述，便于每次迭代功能时快速理解整个项目全貌。

### 6. 更新使用文档

每次功能开发完成后，更新 `README.md` 文件。确保文档包含新增功能的使用示例、命令说明和注意事项，帮助用户快速上手。

### 7. 提交分支

所有测试通过之后，就使用 `enterprise-git-spec` 技能来提交分支。
