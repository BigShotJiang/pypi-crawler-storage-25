import stat
from pathlib import Path

import pytest

from wecom_cli.config import (
    delete_config_value,
    get_config_dict,
    get_config_dir,
    get_config_path,
    get_config_value,
    parse_key_path,
    save_config_dict,
    set_config_value,
)


class TestConfigDir:
    def test_default_dir_is_under_home_config(self, monkeypatch):
        monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
        config_dir = get_config_dir()
        assert config_dir == Path.home() / ".config" / "wecom-cli"

    def test_respects_xdg_config_home(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config_dir = get_config_dir()
        assert config_dir == tmp_path / "wecom-cli"


class TestParseKeyPath:
    def test_simple_key_path(self):
        result = parse_key_path("a.b.c")
        assert result == ["a", "b", "c"]

    def test_single_key(self):
        result = parse_key_path("key")
        assert result == ["key"]

    def test_quoted_key_path_with_single_quotes(self):
        result = parse_key_path("'a.b.c'")
        assert result == ["a.b.c"]

    def test_quoted_key_path_with_double_quotes(self):
        result = parse_key_path('"a.b.c"')
        assert result == ["a.b.c"]

    def test_mixed_quoted_and_unquoted(self):
        result = parse_key_path("a.'b.c'.d")
        assert result == ["a", "b.c", "d"]

    def test_empty_key_raises_error(self):
        with pytest.raises(ValueError, match="键路径不能为空"):
            parse_key_path("")

    def test_key_starting_with_dot_raises_error(self):
        with pytest.raises(ValueError, match="键路径不能以点开头"):
            parse_key_path(".a.b")

    def test_key_ending_with_dot_raises_error(self):
        with pytest.raises(ValueError, match="键路径不能以点结尾"):
            parse_key_path("a.b.")

    def test_key_with_consecutive_dots_raises_error(self):
        with pytest.raises(ValueError, match="键路径不能包含连续的点"):
            parse_key_path("a..b")

    def test_unmatched_quotes_raises_error(self):
        with pytest.raises(ValueError, match="引号不匹配"):
            parse_key_path("'a.b.c")

    def test_empty_quoted_key_raises_error(self):
        with pytest.raises(ValueError, match="键名不能为空"):
            parse_key_path("''")


class TestConfigDict:
    def test_get_config_dict_returns_empty_dict_when_file_missing(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config = get_config_dict()
        assert config == {}

    def test_save_and_load_config_dict(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config_dict = {
            "agents": {"defaults": {"model": {"primary": "doubao/doubao-seed-2-0-lite-260215"}}}
        }
        save_config_dict(config_dict)
        loaded = get_config_dict()
        assert loaded == config_dict

    def test_save_config_dict_creates_directory(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config_dict = {"key": "value"}
        save_config_dict(config_dict)
        assert get_config_path().exists()

    def test_save_config_dict_sets_file_permission_600(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config_dict = {"key": "value"}
        save_config_dict(config_dict)
        mode = get_config_path().stat().st_mode
        assert mode & stat.S_IRUSR
        assert mode & stat.S_IWUSR
        assert not (mode & stat.S_IRGRP)
        assert not (mode & stat.S_IWGRP)


class TestGetConfigValue:
    def test_get_simple_value(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config_dict = {"tools": {"exec": {"host": "gateway"}}}
        save_config_dict(config_dict)
        value = get_config_value("tools.exec.host")
        assert value == "gateway"

    def test_get_nested_value(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config_dict = {
            "agents": {"defaults": {"model": {"primary": "doubao/doubao-seed-2-0-lite-260215"}}}
        }
        save_config_dict(config_dict)
        value = get_config_value("agents.defaults.model.primary")
        assert value == "doubao/doubao-seed-2-0-lite-260215"

    def test_get_dict_value(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config_dict = {
            "models": {
                "providers": {
                    "doubao": {
                        "baseUrl": "https://ark.cn-beijing.volces.com/api/v3",
                        "apiKey": "test-key",
                    }
                }
            }
        }
        save_config_dict(config_dict)
        value = get_config_value("models.providers.doubao")
        assert isinstance(value, dict)
        assert value["baseUrl"] == "https://ark.cn-beijing.volces.com/api/v3"
        assert value["apiKey"] == "test-key"

    def test_get_list_value(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config_dict = {
            "models": {
                "providers": {
                    "doubao": {
                        "models": [
                            {"id": "model1", "name": "Model 1"},
                            {"id": "model2", "name": "Model 2"},
                        ]
                    }
                }
            }
        }
        save_config_dict(config_dict)
        value = get_config_value("models.providers.doubao.models")
        assert isinstance(value, list)
        assert len(value) == 2
        assert value[0]["id"] == "model1"

    def test_get_nonexistent_key_returns_none(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        config_dict = {"key": "value"}
        save_config_dict(config_dict)
        value = get_config_value("nonexistent.key")
        assert value is None

    def test_get_value_from_empty_config(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        value = get_config_value("any.key")
        assert value is None


class TestSetConfigValue:
    def test_set_simple_value(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("tools.exec.host", "gateway")
        value = get_config_value("tools.exec.host")
        assert value == "gateway"

    def test_set_nested_value_creates_intermediate_structure(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("agents.defaults.model.primary", "doubao/doubao-seed-2-0-lite-260215")
        config = get_config_dict()
        assert "agents" in config
        assert "defaults" in config["agents"]
        assert "model" in config["agents"]["defaults"]
        assert (
            config["agents"]["defaults"]["model"]["primary"] == "doubao/doubao-seed-2-0-lite-260215"
        )

    def test_set_dict_value(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        provider_config = {
            "baseUrl": "https://ark.cn-beijing.volces.com/api/v3",
            "apiKey": "test-key",
            "api": "openai-completions",
        }
        set_config_value("models.providers.doubao", provider_config)
        value = get_config_value("models.providers.doubao")
        assert value == provider_config

    def test_set_list_value(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        models = [{"id": "model1", "name": "Model 1"}, {"id": "model2", "name": "Model 2"}]
        set_config_value("models.providers.doubao.models", models)
        value = get_config_value("models.providers.doubao.models")
        assert value == models

    def test_set_empty_string_deletes_key(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("tools.exec.host", "gateway")
        assert get_config_value("tools.exec.host") == "gateway"
        set_config_value("tools.exec.host", "")
        assert get_config_value("tools.exec.host") is None

    def test_set_none_deletes_key(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("tools.exec.host", "gateway")
        assert get_config_value("tools.exec.host") == "gateway"
        set_config_value("tools.exec.host", None)
        assert get_config_value("tools.exec.host") is None

    def test_overwrite_existing_value(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("tools.exec.host", "gateway")
        assert get_config_value("tools.exec.host") == "gateway"
        set_config_value("tools.exec.host", "new-gateway")
        assert get_config_value("tools.exec.host") == "new-gateway"


class TestDeleteConfigValue:
    def test_delete_simple_key(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("key", "value")
        assert get_config_value("key") == "value"
        delete_config_value("key")
        assert get_config_value("key") is None

    def test_delete_nested_key(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("a.b.c", "value")
        assert get_config_value("a.b.c") == "value"
        delete_config_value("a.b.c")
        assert get_config_value("a.b.c") is None

    def test_delete_key_cleans_empty_dicts(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("a.b.c", "value")
        delete_config_value("a.b.c")
        config = get_config_dict()
        assert "a" not in config

    def test_delete_nonexistent_key_does_not_error(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        delete_config_value("nonexistent.key")
        assert True

    def test_delete_last_key_makes_config_empty(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("key", "value")
        delete_config_value("key")
        config = get_config_dict()
        assert config == {}

    def test_delete_key_with_siblings_keeps_other_keys(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        set_config_value("a.b.c1", "value1")
        set_config_value("a.b.c2", "value2")
        delete_config_value("a.b.c1")
        assert get_config_value("a.b.c1") is None
        assert get_config_value("a.b.c2") == "value2"
