import time
from unittest.mock import patch

import httpx
import pytest

from wecom_cli.api.auth import get_access_token, is_token_valid, refresh_token
from wecom_cli.config import get_config_value, save_config_dict


@pytest.fixture
def config_dir(monkeypatch, tmp_path):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))


@pytest.fixture
def valid_config(config_dir):
    config = {
        "auth": {"corpid": "test_corp", "corpsecret": "test_secret"},
        "cache": {"access_token": "cached_token", "expires_at": int(time.time()) + 3600},
    }
    save_config_dict(config)
    return config


@pytest.fixture
def expired_config(config_dir):
    config = {
        "auth": {"corpid": "test_corp", "corpsecret": "test_secret"},
        "cache": {"access_token": "old_token", "expires_at": int(time.time()) - 100},
    }
    save_config_dict(config)
    return config


def _make_token_transport(token="new_token", expires_in=7200):
    return httpx.MockTransport(
        lambda req: httpx.Response(
            200,
            json={
                "errcode": 0,
                "errmsg": "ok",
                "access_token": token,
                "expires_in": expires_in,
            },
        )
    )


class TestIsTokenValid:
    def test_valid_token(self, valid_config):
        assert is_token_valid() is True

    def test_expired_token(self, expired_config):
        assert is_token_valid() is False

    def test_no_token(self, config_dir):
        assert is_token_valid() is False


class TestGetAccessToken:
    def test_returns_cached_token_when_valid(self, valid_config):
        token = get_access_token(transport=_make_token_transport())
        assert token == "cached_token"

    def test_fetches_new_token_when_expired(self, expired_config):
        token = get_access_token(transport=_make_token_transport("fresh_token"))
        assert token == "fresh_token"

    def test_fetches_new_token_when_none_cached(self, config_dir):
        config = {"auth": {"corpid": "test_corp", "corpsecret": "test_secret"}}
        save_config_dict(config)
        token = get_access_token(transport=_make_token_transport("first_token"))
        assert token == "first_token"

    def test_caches_new_token_after_fetch(self, expired_config):
        get_access_token(transport=_make_token_transport("new_cached"))
        assert get_config_value("cache.access_token") == "new_cached"
        assert (get_config_value("cache.expires_at") or 0) > int(time.time())


class TestRefreshToken:
    def test_forces_new_token_even_if_cached(self, valid_config):
        token = refresh_token(transport=_make_token_transport("forced_token"))
        assert token == "forced_token"

    def test_updates_cache_after_refresh(self, valid_config):
        refresh_token(transport=_make_token_transport("refreshed"))
        assert get_config_value("cache.access_token") == "refreshed"


class TestAuthWithProxy:
    @patch("wecom_cli.api.auth.httpx.Client")
    def test_refresh_token_uses_proxy_config(self, mock_client_class, config_dir):
        mock_client = mock_client_class.return_value
        mock_client.get.return_value.json.return_value = {
            "errcode": 0,
            "errmsg": "ok",
            "access_token": "test_token",
            "expires_in": 7200,
        }

        proxy_config = {"https_url": "https://proxy.example.com:8443"}
        refresh_token(proxy_config=proxy_config)

        mock_client_class.assert_called_once()
        call_kwargs = mock_client_class.call_args[1]
        assert call_kwargs.get("proxy") == "https://proxy.example.com:8443"

    @patch("wecom_cli.api.auth.httpx.Client")
    def test_get_access_token_uses_proxy_from_config(self, mock_client_class, config_dir):
        mock_client = mock_client_class.return_value
        mock_client.get.return_value.json.return_value = {
            "errcode": 0,
            "errmsg": "ok",
            "access_token": "test_token",
            "expires_in": 7200,
        }

        config = {
            "auth": {"corpid": "test_corp", "corpsecret": "test_secret"},
            "proxy": {"https_url": "https://proxy.example.com:8443"},
        }
        save_config_dict(config)

        token = get_access_token()

        assert token == "test_token"
        mock_client_class.assert_called_once()
        call_kwargs = mock_client_class.call_args[1]
        assert call_kwargs.get("proxy") == "https://proxy.example.com:8443"
