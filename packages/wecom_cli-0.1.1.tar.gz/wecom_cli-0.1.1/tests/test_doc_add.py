from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from wecom_cli.cli import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def clean_registry(monkeypatch, tmp_path):
    """Clean up registry before and after each test with config isolation."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

    yield


def test_doc_add_basic():
    """Test adding a document with minimal parameters."""
    with patch("wecom_cli.commands.doc.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.add.create_doc") as mock_create:
            mock_create.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "url": "https://doc.weixin.qq.com/doc/ABC123",
                "docid": "DOC123",
            }

            result = runner.invoke(app, ["doc", "add", "--name", "Test Doc", "--type", "doc"])

            assert result.exit_code == 0
            assert "文档创建成功" in result.stdout or "created" in result.stdout.lower()
            mock_create.assert_called_once()


def test_doc_add_with_space_and_father():
    """Test adding a document with space and father IDs."""
    with patch("wecom_cli.commands.doc.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.add.create_doc") as mock_create:
            mock_create.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "url": "https://doc.weixin.qq.com/doc/ABC123",
                "docid": "DOC123",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "add",
                    "--name",
                    "Test Doc",
                    "--type",
                    "sheet",
                    "--spaceid",
                    "SPACE123",
                    "--fatherid",
                    "FATHER123",
                ],
            )

            assert result.exit_code == 0
            mock_create.assert_called_once()


def test_doc_add_registers_docid():
    """Test that docid is registered after creation."""
    with patch("wecom_cli.commands.doc.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.add.create_doc") as mock_create:
            mock_create.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "url": "https://doc.weixin.qq.com/doc/ABC123",
                "docid": "DOC456",
            }

            result = runner.invoke(app, ["doc", "add", "--name", "Registered Doc", "--type", "doc"])

            assert result.exit_code == 0

            from wecom_cli.doc_registry import get_docid

            assert get_docid("Registered Doc") == "DOC456"


def test_doc_add_missing_name():
    """Test adding a document without name raises error."""
    result = runner.invoke(app, ["doc", "add", "--type", "doc"])

    assert result.exit_code != 0


def test_doc_add_invalid_type():
    """Test adding a document with invalid type raises error."""
    result = runner.invoke(app, ["doc", "add", "--name", "Test", "--type", "invalid"])

    assert result.exit_code != 0


def test_doc_add_with_admin_users():
    """Test adding a document with admin users."""
    with patch("wecom_cli.commands.doc.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.add.create_doc") as mock_create:
            mock_create.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "url": "https://doc.weixin.qq.com/doc/ABC123",
                "docid": "DOC123",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "add",
                    "--name",
                    "Test Doc",
                    "--type",
                    "doc",
                    "--admin",
                    "user1",
                    "--admin",
                    "user2",
                    "--admin",
                    "user3",
                ],
            )

            assert result.exit_code == 0
            mock_create.assert_called_once()
            call_args = mock_create.call_args
            assert call_args.kwargs["admin_users"] == ["user1", "user2", "user3"]
