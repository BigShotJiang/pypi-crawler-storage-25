"""测试CLI命令"""

import subprocess


def test_cli_help():
    """测试CLI帮助命令"""
    result = subprocess.run(["wecom-cli", "--help"], capture_output=True, text=True)
    assert result.returncode == 0
    assert "企业微信命令行工具" in result.stdout


def test_doc_command():
    """测试doc命令"""
    result = subprocess.run(["wecom-cli", "doc", "--help"], capture_output=True, text=True)
    assert result.returncode == 0
    assert "文档相关命令" in result.stdout


def test_smart_create_command():
    """测试smart create命令"""
    result = subprocess.run(
        ["wecom-cli", "doc", "smart", "create", "--help"], capture_output=True, text=True
    )
    assert result.returncode == 0
    assert "创建智能文档" in result.stdout
