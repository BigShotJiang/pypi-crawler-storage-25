from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from wecom_cli.cli import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def clean_registry(monkeypatch, tmp_path):
    """Clean up registry before and after each test with config isolation."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

    yield


def test_record_add_basic():
    """Test adding records with minimal parameters."""
    with patch("wecom_cli.commands.doc.smart.record.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.add.add_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [{"record_id": "r1"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "add",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    '--record',
                    '{"values": {"名称": [{"type": "text", "text": "test"}]}}',
                ],
            )

            assert result.exit_code == 0
            assert "记录" in result.stdout or "record" in result.stdout.lower()
            mock_api.assert_called_once()


def test_record_add_multiple_records():
    """Test adding multiple records."""
    with patch("wecom_cli.commands.doc.smart.record.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.add.add_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [{"record_id": "r1"}, {"record_id": "r2"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "add",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    '--record',
                    '{"values": {"名称": [{"type": "text", "text": "test1"}]}}',
                    '--record',
                    '{"values": {"名称": [{"type": "text", "text": "test2"}]}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_add_with_key_type():
    """Test adding records with custom key type."""
    with patch("wecom_cli.commands.doc.smart.record.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.add.add_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [{"record_id": "r1"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "add",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--key-type",
                    "CELL_VALUE_KEY_TYPE_FIELD_ID",
                    '--record',
                    '{"values": {"f1": [{"type": "text", "text": "test"}]}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_add_missing_record():
    """Test adding records without record raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "add",
            "--docid",
            "DOC123",
            "--sheet-id",
            "s1",
        ],
    )

    assert result.exit_code != 0


def test_record_add_both_docid_and_name():
    """Test adding records with both docid and name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "add",
            "--docid",
            "DOC123",
            "--name",
            "Test Doc",
            "--sheet-id",
            "s1",
            '--record',
            '{"values": {"名称": [{"type": "text", "text": "test"}]}}',
        ],
    )

    assert result.exit_code != 0


def test_record_add_neither_docid_nor_name():
    """Test adding records without docid or name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "add",
            "--sheet-id",
            "s1",
            '--record',
            '{"values": {"名称": [{"type": "text", "text": "test"}]}}',
        ],
    )

    assert result.exit_code != 0


def test_record_add_with_registered_name():
    """Test adding records using registered doc name."""
    from wecom_cli.doc_registry import register_doc

    register_doc("My Doc", "DOC456")

    with patch("wecom_cli.commands.doc.smart.record.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.add.add_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [{"record_id": "r1"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "add",
                    "--name",
                    "My Doc",
                    "--sheet-id",
                    "s1",
                    '--record',
                    '{"values": {"名称": [{"type": "text", "text": "test"}]}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_delete_basic():
    """Test deleting records with docid."""
    with patch("wecom_cli.commands.doc.smart.record.delete.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.delete.delete_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "delete",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--record-id",
                    "r1",
                    "--record-id",
                    "r2",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_delete_missing_record_id():
    """Test deleting records without record id raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "delete",
            "--docid",
            "DOC123",
            "--sheet-id",
            "s1",
        ],
    )

    assert result.exit_code != 0


def test_record_delete_both_docid_and_name():
    """Test deleting records with both docid and name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "delete",
            "--docid",
            "DOC123",
            "--name",
            "Test Doc",
            "--sheet-id",
            "s1",
            "--record-id",
            "r1",
        ],
    )

    assert result.exit_code != 0


def test_record_delete_neither_docid_nor_name():
    """Test deleting records without docid or name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "delete",
            "--sheet-id",
            "s1",
            "--record-id",
            "r1",
        ],
    )

    assert result.exit_code != 0


def test_record_delete_with_registered_name():
    """Test deleting records using registered doc name."""
    from wecom_cli.doc_registry import register_doc

    register_doc("My Doc", "DOC456")

    with patch("wecom_cli.commands.doc.smart.record.delete.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.delete.delete_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "delete",
                    "--name",
                    "My Doc",
                    "--sheet-id",
                    "s1",
                    "--record-id",
                    "r1",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_basic():
    """Test querying records with docid."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [
                    {
                        "record_id": "r1",
                        "values": {"名称": [{"type": "text", "text": "test"}]},
                    }
                ],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_record_ids():
    """Test querying records with specific record ids."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [
                    {
                        "record_id": "r1",
                        "values": {"名称": [{"type": "text", "text": "test"}]},
                    }
                ],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--record-id",
                    "r1",
                    "--record-id",
                    "r2",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_field_titles():
    """Test querying records with specific field titles."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--field-title",
                    "名称",
                    "--field-title",
                    "年龄",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_field_ids():
    """Test querying records with specific field ids."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--field-id",
                    "f1",
                    "--field-id",
                    "f2",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_sort():
    """Test querying records with sort."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    '--sort',
                    '{"field_title":"名称","desc":true}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_multiple_sort():
    """Test querying records with multiple sort criteria."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    '--sort',
                    '{"field_title":"名称","desc":true}',
                    '--sort',
                    '{"field_title":"年龄","desc":false}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_filter():
    """Test querying records with filter."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    '--filter',
                    '{"field_id":"f1","field_type":"FIELD_TYPE_TEXT","operator":"OPERATOR_CONTAINS","string_value":{"value":["hello"]}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_multiple_filters():
    """Test querying records with multiple filters."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    '--filter',
                    '{"field_id":"f1","field_type":"FIELD_TYPE_TEXT","operator":"OPERATOR_CONTAINS","string_value":{"value":["hello"]}}',
                    '--filter',
                    '{"field_id":"f2","field_type":"FIELD_TYPE_NUMBER","operator":"OPERATOR_GREATER_THAN","number_value":{"value":10}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_filter_conjunction_or():
    """Test querying records with OR filter conjunction."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--filter-conjunction",
                    "CONJUNCTION_OR",
                    '--filter',
                    '{"field_id":"f1","field_type":"FIELD_TYPE_TEXT","operator":"OPERATOR_CONTAINS","string_value":{"value":["hello"]}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_offset_and_limit():
    """Test querying records with offset and limit."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--offset",
                    "0",
                    "--limit",
                    "10",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_with_key_type():
    """Test querying records with custom key type."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--key-type",
                    "CELL_VALUE_KEY_TYPE_FIELD_ID",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_both_docid_and_name():
    """Test querying records with both docid and name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "query",
            "--docid",
            "DOC123",
            "--name",
            "Test Doc",
            "--sheet-id",
            "s1",
        ],
    )

    assert result.exit_code != 0


def test_record_query_neither_docid_nor_name():
    """Test querying records without docid or name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "query",
            "--sheet-id",
            "s1",
        ],
    )

    assert result.exit_code != 0


def test_record_query_with_registered_name():
    """Test querying records using registered doc name."""
    from wecom_cli.doc_registry import register_doc

    register_doc("My Doc", "DOC456")

    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [],
                "has_more": False,
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--name",
                    "My Doc",
                    "--sheet-id",
                    "s1",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_update_basic():
    """Test updating records with docid."""
    with patch("wecom_cli.commands.doc.smart.record.update.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.update.update_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [{"record_id": "r1"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "update",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    '--record',
                    '{"record_id":"r1","values":{"名称":[{"type":"text","text":"updated"}]}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_update_multiple_records():
    """Test updating multiple records."""
    with patch("wecom_cli.commands.doc.smart.record.update.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.update.update_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [{"record_id": "r1"}, {"record_id": "r2"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "update",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    '--record',
                    '{"record_id":"r1","values":{"名称":[{"type":"text","text":"updated1"}]}}',
                    '--record',
                    '{"record_id":"r2","values":{"名称":[{"type":"text","text":"updated2"}]}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_update_with_key_type():
    """Test updating records with custom key type."""
    with patch("wecom_cli.commands.doc.smart.record.update.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.update.update_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [{"record_id": "r1"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "update",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--key-type",
                    "CELL_VALUE_KEY_TYPE_FIELD_ID",
                    '--record',
                    '{"record_id":"r1","values":{"f1":[{"type":"text","text":"updated"}]}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_update_missing_record():
    """Test updating records without record raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "update",
            "--docid",
            "DOC123",
            "--sheet-id",
            "s1",
        ],
    )

    assert result.exit_code != 0


def test_record_update_both_docid_and_name():
    """Test updating records with both docid and name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "update",
            "--docid",
            "DOC123",
            "--name",
            "Test Doc",
            "--sheet-id",
            "s1",
            '--record',
            '{"record_id":"r1","values":{"名称":[{"type":"text","text":"updated"}]}}',
        ],
    )

    assert result.exit_code != 0


def test_record_update_neither_docid_nor_name():
    """Test updating records without docid or name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "record",
            "update",
            "--sheet-id",
            "s1",
            '--record',
            '{"record_id":"r1","values":{"名称":[{"type":"text","text":"updated"}]}}',
        ],
    )

    assert result.exit_code != 0


def test_record_update_with_registered_name():
    """Test updating records using registered doc name."""
    from wecom_cli.doc_registry import register_doc

    register_doc("My Doc", "DOC456")

    with patch("wecom_cli.commands.doc.smart.record.update.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.update.update_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "records": [{"record_id": "r1"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "update",
                    "--name",
                    "My Doc",
                    "--sheet-id",
                    "s1",
                    '--record',
                    '{"record_id":"r1","values":{"名称":[{"type":"text","text":"updated"}]}}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_all_flag():
    """Test querying all records with --all flag uses auto-pagination."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_all_records") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "total": 5,
                "has_more": False,
                "records": [
                    {"record_id": "r1"},
                    {"record_id": "r2"},
                    {"record_id": "r3"},
                    {"record_id": "r4"},
                    {"record_id": "r5"},
                ],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--all",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_record_query_all_flag_with_json():
    """Test querying all records with --all and --json flags."""
    with patch("wecom_cli.commands.doc.smart.record.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.record.query.get_all_records") as mock_api:
            mock_api.return_value = {
                "total": 3,
                "has_more": False,
                "records": [
                    {"record_id": "r1", "values": {"name": "a"}},
                    {"record_id": "r2", "values": {"name": "b"}},
                    {"record_id": "r3", "values": {"name": "c"}},
                ],
            }

            result = runner.invoke(
                app,
                [
                    "--json",
                    "doc",
                    "smart",
                    "record",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--all",
                ],
            )

            assert result.exit_code == 0
            import json

            output = json.loads(result.stdout)
            assert output["success"] is True
            assert len(output["data"]["records"]) == 3


def test_record_query_all_conflicts_with_offset():
    """Test that --all conflicts with --offset."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "record",
            "query",
            "--docid",
            "DOC123",
            "--sheet-id",
            "s1",
            "--all",
            "--offset",
            "10",
        ],
    )

    assert result.exit_code != 0


def test_record_query_all_conflicts_with_limit():
    """Test that --all conflicts with --limit."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "record",
            "query",
            "--docid",
            "DOC123",
            "--sheet-id",
            "s1",
            "--all",
            "--limit",
            "10",
        ],
    )

    assert result.exit_code != 0
