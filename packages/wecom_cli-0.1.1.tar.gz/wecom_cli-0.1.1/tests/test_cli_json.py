"""Test CLI JSON option functionality."""

import json

from typer.testing import CliRunner

from wecom_cli.cli import app

runner = CliRunner()


class TestCliJsonOption:
    """Test --json option in CLI."""

    def test_version_command_without_json(self):
        """Test version command without --json flag."""
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert "wecom-cli" in result.stdout
        assert "v0.1.0" in result.stdout

    def test_version_command_with_json(self):
        """Test version command with --json flag before command."""
        result = runner.invoke(app, ["--json", "version"])
        assert result.exit_code == 0

        output = json.loads(result.stdout)
        assert output["success"] is True
        assert "data" in output
        assert "version" in output["data"]
        assert output["data"]["version"] == "v0.1.0"

    def test_json_flag_at_app_level(self):
        """Test that --json flag is available at app level."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "--json" in result.stdout

    def test_json_option_persists_to_subcommands(self):
        """Test that --json option persists to subcommands."""
        result = runner.invoke(app, ["--json", "version"])
        assert result.exit_code == 0

        output = json.loads(result.stdout)
        assert output["success"] is True
