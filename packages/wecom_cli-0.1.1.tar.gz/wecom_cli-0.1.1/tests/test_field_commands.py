from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from wecom_cli.cli import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def clean_registry(monkeypatch, tmp_path):
    """Clean up registry before and after each test with config isolation."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

    yield


def test_field_add_basic():
    """Test adding a field with minimal parameters."""
    with patch("wecom_cli.commands.doc.smart.field.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.add.add_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "field_id": "f1",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "add",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--title",
                    "名称",
                    "--type",
                    "FIELD_TYPE_TEXT",
                ],
            )

            assert result.exit_code == 0
            assert "字段" in result.stdout or "field" in result.stdout.lower()
            mock_api.assert_called_once()


def test_field_add_missing_sheet_id():
    """Test adding a field without sheet id raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "add",
            "--docid",
            "DOC123",
            "--title",
            "名称",
            "--type",
            "FIELD_TYPE_TEXT",
        ],
    )

    assert result.exit_code != 0


def test_field_add_missing_title():
    """Test adding a field without title raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "add",
            "--docid",
            "DOC123",
            "--sheet-id",
            "s1",
            "--type",
            "FIELD_TYPE_TEXT",
        ],
    )

    assert result.exit_code != 0


def test_field_add_missing_type():
    """Test adding a field without type raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "add",
            "--docid",
            "DOC123",
            "--sheet-id",
            "s1",
            "--title",
            "名称",
        ],
    )

    assert result.exit_code != 0


def test_field_add_with_properties():
    """Test adding a field with properties."""
    with patch("wecom_cli.commands.doc.smart.field.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.add.add_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "field_id": "f1",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "add",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--title",
                    "名称",
                    "--type",
                    "FIELD_TYPE_TEXT",
                    "--property",
                    'property_number={"decimal_places":2}',
                    "--property",
                    'property_checkbox={"checked":true}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_add_both_docid_and_name():
    """Test adding a field with both docid and name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "add",
            "--docid",
            "DOC123",
            "--name",
            "Test Doc",
            "--sheet-id",
            "s1",
            "--title",
            "名称",
            "--type",
            "FIELD_TYPE_TEXT",
        ],
    )

    assert result.exit_code != 0


def test_field_add_neither_docid_nor_name():
    """Test adding a field without docid or name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "add",
            "--sheet-id",
            "s1",
            "--title",
            "名称",
            "--type",
            "FIELD_TYPE_TEXT",
        ],
    )

    assert result.exit_code != 0


def test_field_add_with_registered_name():
    """Test adding a field using registered doc name."""
    from wecom_cli.doc_registry import register_doc

    register_doc("My Doc", "DOC456")

    with patch("wecom_cli.commands.doc.smart.field.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.add.add_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "field_id": "f1",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "add",
                    "--name",
                    "My Doc",
                    "--sheet-id",
                    "s1",
                    "--title",
                    "名称",
                    "--type",
                    "FIELD_TYPE_TEXT",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_add_json_mode():
    """Test adding a field in JSON mode."""
    with patch("wecom_cli.commands.doc.smart.field.add.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.add.add_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "field_id": "f1",
            }

            result = runner.invoke(
                app,
                [
                    "--json",
                    "doc",
                    "smart",
                    "field",
                    "add",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--title",
                    "名称",
                    "--type",
                    "FIELD_TYPE_TEXT",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_delete_basic():
    """Test deleting fields with docid."""
    with patch("wecom_cli.commands.doc.smart.field.delete.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.delete.delete_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "delete",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--field-id",
                    "f1",
                    "--field-id",
                    "f2",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_delete_missing_field_id():
    """Test deleting fields without field id raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "delete",
            "--docid",
            "DOC123",
            "--sheet-id",
            "s1",
        ],
    )

    assert result.exit_code != 0


def test_field_delete_both_docid_and_name():
    """Test deleting fields with both docid and name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "delete",
            "--docid",
            "DOC123",
            "--name",
            "Test Doc",
            "--sheet-id",
            "s1",
            "--field-id",
            "f1",
        ],
    )

    assert result.exit_code != 0


def test_field_delete_neither_docid_nor_name():
    """Test deleting fields without docid or name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "delete",
            "--sheet-id",
            "s1",
            "--field-id",
            "f1",
        ],
    )

    assert result.exit_code != 0


def test_field_delete_with_registered_name():
    """Test deleting fields using registered doc name."""
    from wecom_cli.doc_registry import register_doc

    register_doc("My Doc", "DOC456")

    with patch("wecom_cli.commands.doc.smart.field.delete.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.delete.delete_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "delete",
                    "--name",
                    "My Doc",
                    "--sheet-id",
                    "s1",
                    "--field-id",
                    "f1",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_query_basic():
    """Test querying fields with docid."""
    with patch("wecom_cli.commands.doc.smart.field.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.query.get_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "fields": [
                    {"field_id": "f1", "title": "名称", "type": "FIELD_TYPE_TEXT"},
                    {"field_id": "f2", "title": "年龄", "type": "FIELD_TYPE_NUMBER"},
                ],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_query_with_field_ids():
    """Test querying fields with specific field ids."""
    with patch("wecom_cli.commands.doc.smart.field.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.query.get_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "fields": [{"field_id": "f1", "title": "名称", "type": "FIELD_TYPE_TEXT"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--field-id",
                    "f1",
                    "--field-id",
                    "f2",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_query_with_field_titles():
    """Test querying fields with specific field titles."""
    with patch("wecom_cli.commands.doc.smart.field.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.query.get_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "fields": [{"field_id": "f1", "title": "名称", "type": "FIELD_TYPE_TEXT"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--field-title",
                    "名称",
                    "--field-title",
                    "年龄",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_query_with_offset_and_limit():
    """Test querying fields with offset and limit."""
    with patch("wecom_cli.commands.doc.smart.field.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.query.get_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "fields": [{"field_id": "f1", "title": "名称", "type": "FIELD_TYPE_TEXT"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "query",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--offset",
                    "0",
                    "--limit",
                    "10",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_query_both_docid_and_name():
    """Test querying fields with both docid and name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "query",
            "--docid",
            "DOC123",
            "--name",
            "Test Doc",
            "--sheet-id",
            "s1",
        ],
    )

    assert result.exit_code != 0


def test_field_query_neither_docid_nor_name():
    """Test querying fields without docid or name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "query",
            "--sheet-id",
            "s1",
        ],
    )

    assert result.exit_code != 0


def test_field_query_with_registered_name():
    """Test querying fields using registered doc name."""
    from wecom_cli.doc_registry import register_doc

    register_doc("My Doc", "DOC456")

    with patch("wecom_cli.commands.doc.smart.field.query.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.query.get_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "fields": [],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "query",
                    "--name",
                    "My Doc",
                    "--sheet-id",
                    "s1",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_update_basic():
    """Test updating a field with docid."""
    with patch("wecom_cli.commands.doc.smart.field.update.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.update.update_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "fields": [{"field_id": "f1", "field_title": "新名称", "field_type": "FIELD_TYPE_TEXT"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "update",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--field-id",
                    "f1",
                    "--title",
                    "新名称",
                    "--type",
                    "FIELD_TYPE_TEXT",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_update_with_title():
    """Test updating a field with new title."""
    with patch("wecom_cli.commands.doc.smart.field.update.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.update.update_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "field_id": "f1",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "update",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--field-id",
                    "f1",
                    "--title",
                    "新名称",
                    "--type",
                    "FIELD_TYPE_TEXT",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_update_with_properties():
    """Test updating a field with properties."""
    with patch("wecom_cli.commands.doc.smart.field.update.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.update.update_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "fields": [{"field_id": "f1", "field_title": "名称", "field_type": "FIELD_TYPE_NUMBER"}],
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "update",
                    "--docid",
                    "DOC123",
                    "--sheet-id",
                    "s1",
                    "--field-id",
                    "f1",
                    "--type",
                    "FIELD_TYPE_NUMBER",
                    "--property",
                    'property_number={"decimal_places":2,"use_separate":true}',
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()


def test_field_update_both_docid_and_name():
    """Test updating a field with both docid and name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "update",
            "--docid",
            "DOC123",
            "--name",
            "Test Doc",
            "--sheet-id",
            "s1",
            "--field-id",
            "f1",
            "--type",
            "FIELD_TYPE_TEXT",
        ],
    )

    assert result.exit_code != 0


def test_field_update_neither_docid_nor_name():
    """Test updating a field without docid or name raises error."""
    result = runner.invoke(
        app,
        [
            "doc",
            "smart",
            "sheet",
            "field",
            "update",
            "--sheet-id",
            "s1",
            "--field-id",
            "f1",
            "--type",
            "FIELD_TYPE_TEXT",
        ],
    )

    assert result.exit_code != 0


def test_field_update_with_registered_name():
    """Test updating a field using registered doc name."""
    from wecom_cli.doc_registry import register_doc

    register_doc("My Doc", "DOC456")

    with patch("wecom_cli.commands.doc.smart.field.update.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.smart.field.update.update_fields") as mock_api:
            mock_api.return_value = {
                "errcode": 0,
                "errmsg": "ok",
                "field_id": "f1",
            }

            result = runner.invoke(
                app,
                [
                    "doc",
                    "smart",
                    "field",
                    "update",
                    "--name",
                    "My Doc",
                    "--sheet-id",
                    "s1",
                    "--field-id",
                    "f1",
                    "--title",
                    "新名称",
                    "--type",
                    "FIELD_TYPE_TEXT",
                ],
            )

            assert result.exit_code == 0
            mock_api.assert_called_once()
