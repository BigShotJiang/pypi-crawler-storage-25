from unittest.mock import call, patch

import pytest
from typer.testing import CliRunner

from wecom_cli.cli import app
from wecom_cli.doc_registry import get_docid, register_doc

runner = CliRunner()


@pytest.fixture(autouse=True)
def clean_registry(monkeypatch, tmp_path):
    """Clean up registry before and after each test with config isolation."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

    yield


def test_doc_rename_by_name():
    """Test renaming a document by name."""
    register_doc("Old Name", "DOC123")

    with patch("wecom_cli.commands.doc.rename.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.rename.rename_doc") as mock_rename:
            result = runner.invoke(
                app, ["doc", "rename", "--name", "Old Name", "--new-name", "New Name"]
            )

            assert result.exit_code == 0
            assert "重命名" in result.stdout
            assert mock_rename.called
            assert (
                call(
                    access_token="test_token",
                    docid="DOC123",
                    new_name="New Name",
                    proxy_config=None,
                )
                in mock_rename.call_args_list
            )


def test_doc_rename_by_docid():
    """Test renaming a document by docid."""
    with patch("wecom_cli.commands.doc.rename.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.rename.rename_doc") as mock_rename:
            result = runner.invoke(
                app, ["doc", "rename", "--docid", "DOC456", "--new-name", "New Name"]
            )

            assert result.exit_code == 0
            assert "重命名" in result.stdout
            assert mock_rename.called
            assert (
                call(
                    access_token="test_token",
                    docid="DOC456",
                    new_name="New Name",
                    proxy_config=None,
                )
                in mock_rename.call_args_list
            )


def test_doc_rename_updates_registry():
    """Test that rename by name updates the registry."""
    register_doc("Old Name", "DOC123")
    assert get_docid("Old Name") == "DOC123"

    with patch("wecom_cli.commands.doc.rename.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.rename.rename_doc"):
            result = runner.invoke(
                app, ["doc", "rename", "--name", "Old Name", "--new-name", "New Name"]
            )

            assert result.exit_code == 0
            assert get_docid("Old Name") is None
            assert get_docid("New Name") == "DOC123"


def test_doc_rename_not_found():
    """Test renaming a non-existent document."""
    with patch("wecom_cli.commands.doc.rename.get_access_token"):
        result = runner.invoke(app, ["doc", "rename", "--name", "Nonexistent", "--new-name", "New"])

        assert result.exit_code != 0
        assert "未找到" in result.stdout


def test_doc_rename_missing_both():
    """Test renaming without docid or name raises error."""
    result = runner.invoke(app, ["doc", "rename", "--new-name", "New"])

    assert result.exit_code != 0


def test_doc_rename_both_docid_and_name():
    """Test renaming with both docid and name raises error."""
    result = runner.invoke(app, ["doc", "rename", "--docid", "DOC123", "--name", "Old", "--new-name", "New"])

    assert result.exit_code != 0


def test_doc_rename_missing_new_name():
    """Test renaming without new name raises error."""
    result = runner.invoke(app, ["doc", "rename", "--name", "Old"])

    assert result.exit_code != 0
