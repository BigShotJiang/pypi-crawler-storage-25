import json
import time

import pytest
from typer.testing import CliRunner

from wecom_cli.cli import app
from wecom_cli.config import get_config_value, save_config_dict

runner = CliRunner()


@pytest.fixture
def config_dir(monkeypatch, tmp_path):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))


class TestConfigShow:
    def test_show_displays_config_with_masked_secret(self, config_dir):
        config = {
            "auth": {"corpid": "corp123", "corpsecret": "secret456"},
            "cache": {"access_token": "tok_abcdef123", "expires_at": 9999},
        }
        save_config_dict(config)
        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0
        assert "corp123" in result.output
        assert "secr****" in result.output
        assert "secret456" not in result.output

    def test_show_warns_when_no_config(self, config_dir):
        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0
        assert "未找到配置" in result.output or "config init" in result.output


class TestConfigSet:
    def test_set_string_value(self, config_dir):
        result = runner.invoke(app, ["config", "set", "tools.exec.host", "gateway"])
        assert result.exit_code == 0
        assert "配置已更新" in result.output
        value = get_config_value("tools.exec.host")
        assert value == "gateway"

    def test_set_nested_key_path(self, config_dir):
        result = runner.invoke(
            app,
            [
                "config",
                "set",
                "agents.defaults.model.primary",
                "doubao/doubao-seed-2-0-lite-260215",
            ],
        )
        assert result.exit_code == 0
        value = get_config_value("agents.defaults.model.primary")
        assert value == "doubao/doubao-seed-2-0-lite-260215"

    def test_set_json_value(self, config_dir):
        json_value = '{"baseUrl": "https://ark.cn-beijing.volces.com/api/v3", "apiKey": "test-key"}'
        result = runner.invoke(
            app, ["config", "set", "models.providers.doubao", "--json", json_value]
        )
        assert result.exit_code == 0
        value = get_config_value("models.providers.doubao")
        assert isinstance(value, dict)
        assert value["baseUrl"] == "https://ark.cn-beijing.volces.com/api/v3"
        assert value["apiKey"] == "test-key"

    def test_set_json_array_value(self, config_dir):
        json_value = '[{"id": "model1", "name": "Model 1"}, {"id": "model2", "name": "Model 2"}]'
        result = runner.invoke(app, ["config", "set", "models.list", "--json", json_value])
        assert result.exit_code == 0
        value = get_config_value("models.list")
        assert isinstance(value, list)
        assert len(value) == 2
        assert value[0]["id"] == "model1"

    def test_set_empty_string_deletes_key(self, config_dir):
        runner.invoke(app, ["config", "set", "tools.exec.host", "gateway"])
        assert get_config_value("tools.exec.host") == "gateway"
        result = runner.invoke(app, ["config", "set", "tools.exec.host", ""])
        assert result.exit_code == 0
        assert get_config_value("tools.exec.host") is None

    def test_set_null_deletes_key(self, config_dir):
        runner.invoke(app, ["config", "set", "tools.exec.host", "gateway"])
        assert get_config_value("tools.exec.host") == "gateway"
        result = runner.invoke(app, ["config", "set", "tools.exec.host", "--json", "null"])
        assert result.exit_code == 0
        assert get_config_value("tools.exec.host") is None

    def test_set_invalid_json_shows_error(self, config_dir):
        result = runner.invoke(app, ["config", "set", "test.key", "--json", "{invalid}"])
        assert result.exit_code != 0
        assert "JSON" in result.output or "解析" in result.output

    def test_set_invalid_key_path_shows_error(self, config_dir):
        result = runner.invoke(app, ["config", "set", ".invalid.path", "value"])
        assert result.exit_code != 0
        assert "键路径" in result.output or "无效" in result.output


class TestConfigGet:
    def test_get_string_value(self, config_dir):
        runner.invoke(app, ["config", "set", "tools.exec.host", "gateway"])
        result = runner.invoke(app, ["config", "get", "tools.exec.host"])
        assert result.exit_code == 0
        assert "gateway" in result.output

    def test_get_json_value_formatted(self, config_dir):
        json_value = '{"baseUrl": "https://ark.cn-beijing.volces.com/api/v3", "apiKey": "test-key"}'
        runner.invoke(app, ["config", "set", "models.providers.doubao", "--json", json_value])
        result = runner.invoke(app, ["config", "get", "models.providers.doubao"])
        assert result.exit_code == 0
        assert "baseUrl" in result.output
        assert "https://ark.cn-beijing.volces.com/api/v3" in result.output

    def test_get_nonexistent_key_shows_message(self, config_dir):
        result = runner.invoke(app, ["config", "get", "nonexistent.key"])
        assert result.exit_code == 0
        assert "不存在" in result.output or "未找到" in result.output

    def test_get_nested_value(self, config_dir):
        runner.invoke(
            app,
            [
                "config",
                "set",
                "agents.defaults.model.primary",
                "doubao/doubao-seed-2-0-lite-260215",
            ],
        )
        result = runner.invoke(app, ["config", "get", "agents.defaults.model.primary"])
        assert result.exit_code == 0
        assert "doubao/doubao-seed-2-0-lite-260215" in result.output


class TestConfigShowUpdated:
    def test_show_with_key_displays_single_value(self, config_dir):
        runner.invoke(app, ["config", "set", "tools.exec.host", "gateway"])
        result = runner.invoke(app, ["config", "show", "tools.exec.host"])
        assert result.exit_code == 0
        assert "gateway" in result.output

    def test_show_without_key_displays_all_config(self, config_dir):
        runner.invoke(app, ["config", "set", "tools.exec.host", "gateway"])
        runner.invoke(app, ["config", "set", "agents.defaults.model.primary", "doubao"])
        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0
        assert "tools" in result.output
        assert "agents" in result.output
        assert "gateway" in result.output
        assert "doubao" in result.output

    def test_show_nonexistent_key_shows_message(self, config_dir):
        result = runner.invoke(app, ["config", "show", "nonexistent.key"])
        assert result.exit_code == 0
        assert "不存在" in result.output or "未找到" in result.output


class TestConfigList:
    def test_list_displays_all_keys(self, config_dir):
        runner.invoke(app, ["config", "set", "tools.exec.host", "gateway"])
        runner.invoke(app, ["config", "set", "agents.defaults.model.primary", "doubao"])
        result = runner.invoke(app, ["config", "list"])
        assert result.exit_code == 0
        assert "tools" in result.output
        assert "agents" in result.output
        assert "exec" in result.output
        assert "defaults" in result.output

    def test_list_sorted_alphabetically(self, config_dir):
        runner.invoke(app, ["config", "set", "z.key", "value"])
        runner.invoke(app, ["config", "set", "a.key", "value"])
        result = runner.invoke(app, ["config", "list"])
        assert result.exit_code == 0
        output_lines = result.output.split("\n")
        a_index = None
        z_index = None
        for i, line in enumerate(output_lines):
            if line.strip().startswith("├── a") or line.strip().startswith("└── a"):
                a_index = i
            if line.strip().startswith("├── z") or line.strip().startswith("└── z"):
                z_index = i
        assert a_index is not None
        assert z_index is not None
        assert a_index < z_index

    def test_list_empty_config_shows_message(self, config_dir):
        result = runner.invoke(app, ["config", "list"])
        assert result.exit_code == 0
        assert "空" in result.output or "无" in result.output or "没有" in result.output


class TestConfigToken:
    def test_token_shows_valid_status(self, config_dir):
        config = {
            "auth": {"corpid": "c", "corpsecret": "s"},
            "cache": {"access_token": "abc123xyz", "expires_at": int(time.time()) + 3600},
        }
        save_config_dict(config)
        result = runner.invoke(app, ["config", "token"])
        assert result.exit_code == 0
        assert "abc123xy" in result.output
        assert "有效" in result.output

    def test_token_shows_expired_status(self, config_dir):
        config = {
            "auth": {"corpid": "c", "corpsecret": "s"},
            "cache": {"access_token": "old_tok", "expires_at": int(time.time()) - 100},
        }
        save_config_dict(config)
        result = runner.invoke(app, ["config", "token"])
        assert result.exit_code == 0
        assert "过期" in result.output or "失效" in result.output

    def test_token_shows_no_token_when_empty(self, config_dir):
        config = {"auth": {"corpid": "c", "corpsecret": "s"}}
        save_config_dict(config)
        result = runner.invoke(app, ["config", "token"])
        assert result.exit_code == 0
        assert "无" in result.output or "未获取" in result.output


class TestConfigInit:
    def test_init_creates_default_config(self, config_dir):
        result = runner.invoke(app, ["config", "init"], input="test_corpid\ntest_secret\n")
        assert result.exit_code == 0
        assert get_config_value("auth.corpid") == "test_corpid"
        assert get_config_value("auth.corpsecret") == "test_secret"


class TestConfigProxy:
    def test_proxy_shows_current_config(self, config_dir):
        config = {
            "auth": {"corpid": "test_corp", "corpsecret": "test_secret"},
            "proxy": {
                "http_url": "http://proxy.example.com:8080",
                "https_url": "https://proxy.example.com:8443",
            },
        }
        save_config_dict(config)
        result = runner.invoke(app, ["config", "proxy"])
        assert result.exit_code == 0
        assert "http://proxy.example.com:8080" in result.output
        assert "https://proxy.example.com:8443" in result.output

    def test_proxy_shows_empty_when_not_configured(self, config_dir):
        config = {"auth": {"corpid": "test_corp", "corpsecret": "test_secret"}}
        save_config_dict(config)
        result = runner.invoke(app, ["config", "proxy"])
        assert result.exit_code == 0
        assert "未配置" in result.output

    def test_proxy_sets_http_proxy(self, config_dir):
        result = runner.invoke(app, ["config", "proxy", "--http", "http://proxy.example.com:8080"])
        assert result.exit_code == 0
        assert get_config_value("proxy.http_url") == "http://proxy.example.com:8080"
        assert "代理配置已更新" in result.output

    def test_proxy_sets_https_proxy(self, config_dir):
        result = runner.invoke(
            app, ["config", "proxy", "--https", "https://proxy.example.com:8443"]
        )
        assert result.exit_code == 0
        assert get_config_value("proxy.https_url") == "https://proxy.example.com:8443"
        assert "代理配置已更新" in result.output

    def test_proxy_sets_both_proxies(self, config_dir):
        result = runner.invoke(
            app,
            [
                "config",
                "proxy",
                "--http",
                "http://proxy.example.com:8080",
                "--https",
                "https://proxy.example.com:8443",
            ],
        )
        assert result.exit_code == 0
        assert get_config_value("proxy.http_url") == "http://proxy.example.com:8080"
        assert get_config_value("proxy.https_url") == "https://proxy.example.com:8443"
        assert "代理配置已更新" in result.output

    def test_proxy_clears_proxy_when_empty_string(self, config_dir):
        config = {
            "auth": {"corpid": "test_corp", "corpsecret": "test_secret"},
            "proxy": {
                "http_url": "http://proxy.example.com:8080",
                "https_url": "https://proxy.example.com:8443",
            },
        }
        save_config_dict(config)
        result = runner.invoke(app, ["config", "proxy", "--http", "", "--https", ""])
        assert result.exit_code == 0
        assert get_config_value("proxy.http_url") is None
        assert get_config_value("proxy.https_url") is None


class TestConfigJsonOutput:
    """Test JSON output for config commands."""

    def test_config_set_json_mode(self, config_dir):
        """Test config set command with --json flag."""
        result = runner.invoke(app, ["--json", "config", "set", "test.key", "value"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is True
        assert get_config_value("test.key") == "value"

    def test_config_set_invalid_key_json_mode(self, config_dir):
        """Test config set with invalid key in JSON mode."""
        result = runner.invoke(app, ["--json", "config", "set", ".invalid", "value"])
        assert result.exit_code != 0
        output = json.loads(result.output)
        assert output["success"] is False
        assert "error" in output

    def test_config_get_json_mode(self, config_dir):
        """Test config get command with --json flag."""
        save_config_dict({"test": {"key": "value"}})
        result = runner.invoke(app, ["--json", "config", "get", "test.key"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is True
        assert output["data"] == "value"

    def test_config_get_nonexistent_json_mode(self, config_dir):
        """Test config get with nonexistent key in JSON mode."""
        result = runner.invoke(app, ["--json", "config", "get", "nonexistent"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is False
        assert "error" in output

    def test_config_show_json_mode(self, config_dir):
        """Test config show command with --json flag."""
        config = {"test": {"key": "value"}}
        save_config_dict(config)
        result = runner.invoke(app, ["--json", "config", "show"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is True
        assert "data" in output
        assert "test" in output["data"]

    def test_config_list_json_mode(self, config_dir):
        """Test config list command with --json flag."""
        config = {"key1": "value1", "key2": {"nested": "value2"}}
        save_config_dict(config)
        result = runner.invoke(app, ["--json", "config", "list"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is True
        assert "data" in output

    def test_config_token_json_mode(self, config_dir):
        """Test config token command with --json flag."""
        config = {
            "auth": {"corpid": "test", "corpsecret": "secret"},
            "cache": {"access_token": "token123", "expires_at": int(time.time()) + 3600},
        }
        save_config_dict(config)
        result = runner.invoke(app, ["--json", "config", "token"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is True
        assert "data" in output
        assert "valid" in output["data"]

    def test_config_token_no_token_json_mode(self, config_dir):
        """Test config token with no token in JSON mode."""
        config = {"auth": {"corpid": "test", "corpsecret": "secret"}}
        save_config_dict(config)
        result = runner.invoke(app, ["--json", "config", "token"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is False
        assert "error" in output

    def test_config_proxy_show_json_mode(self, config_dir):
        """Test config proxy show command with --json flag."""
        config = {
            "proxy": {"http_url": "http://proxy.com:8080", "https_url": "https://proxy.com:8443"},
        }
        save_config_dict(config)
        result = runner.invoke(app, ["--json", "config", "proxy"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is True
        assert "data" in output
        assert "http" in output["data"]

    def test_config_proxy_set_json_mode(self, config_dir):
        """Test config proxy set command with --json flag."""
        result = runner.invoke(
            app, ["--json", "config", "proxy", "--http", "http://proxy.com:8080"]
        )
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is True
        assert get_config_value("proxy.http_url") == "http://proxy.com:8080"
