from unittest.mock import Mock, patch

import pytest

from wecom_cli.api.client import WeComAPIError


def test_create_doc_basic():
    """Test creating a document with minimal parameters."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "url": "https://doc.weixin.qq.com/doc/ABC123",
        "docid": "DOC123",
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import create_doc

        result = create_doc(
            access_token="test_token",
            doc_type=3,
            doc_name="Test Document",
            spaceid=None,
            fatherid=None,
            admin_users=None,
        )

        assert result["docid"] == "DOC123"
        assert result["url"] == "https://doc.weixin.qq.com/doc/ABC123"
        mock_client.post.assert_called_once_with(
            "wedoc/create_doc",
            {
                "doc_type": 3,
                "doc_name": "Test Document",
            },
        )


def test_create_doc_with_space_and_father():
    """Test creating a document with spaceid and fatherid."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "url": "https://doc.weixin.qq.com/doc/ABC123",
        "docid": "DOC123",
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import create_doc

        result = create_doc(
            access_token="test_token",
            doc_type=4,
            doc_name="Test Sheet",
            spaceid="SPACE123",
            fatherid="FATHER123",
            admin_users=None,
        )

        assert result["docid"] == "DOC123"
        mock_client.post.assert_called_once_with(
            "wedoc/create_doc",
            {
                "spaceid": "SPACE123",
                "fatherid": "FATHER123",
                "doc_type": 4,
                "doc_name": "Test Sheet",
            },
        )


def test_create_doc_with_admin_users():
    """Test creating a document with admin users."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "url": "https://doc.weixin.qq.com/doc/ABC123",
        "docid": "DOC123",
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import create_doc

        result = create_doc(
            access_token="test_token",
            doc_type=10,
            doc_name="Test Smart Doc",
            spaceid=None,
            fatherid=None,
            admin_users=["user1", "user2"],
        )

        assert result["docid"] == "DOC123"
        mock_client.post.assert_called_once_with(
            "wedoc/create_doc",
            {
                "doc_type": 10,
                "doc_name": "Test Smart Doc",
                "admin_users": ["user1", "user2"],
            },
        )


def test_delete_doc():
    """Test deleting a document."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import delete_doc

        delete_doc(access_token="test_token", docid="DOC123")

        mock_client.post.assert_called_once_with("wedoc/del_doc", {"docid": "DOC123"})


def test_delete_doc_raises_on_error():
    """Test that delete_doc raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid docid")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import delete_doc

        with pytest.raises(WeComAPIError) as exc_info:
            delete_doc(access_token="test_token", docid="INVALID")

        assert exc_info.value.errcode == 40001


def test_rename_doc():
    """Test renaming a document."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import rename_doc

        rename_doc(access_token="test_token", docid="DOC123", new_name="New Name")

        mock_client.post.assert_called_once_with(
            "wedoc/rename_doc", {"docid": "DOC123", "new_name": "New Name"}
        )


def test_share_doc():
    """Test getting document share link."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "share_url": "https://doc.weixin.qq.com/share/ABC123",
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import share_doc

        url = share_doc(access_token="test_token", docid="DOC123")

        assert url == "https://doc.weixin.qq.com/share/ABC123"
        mock_client.post.assert_called_once_with("wedoc/doc_share", {"docid": "DOC123"})


def test_add_sheet_basic():
    """Test adding a sheet with minimal parameters."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "properties": {
            "title": "智能表",
            "index": 3,
            "sheet_id": "123abc",
        },
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import add_sheet

        result = add_sheet(
            access_token="test_token",
            docid="DOC123",
            title="智能表",
            index=None,
            proxy_config=None,
        )

        assert result["properties"]["sheet_id"] == "123abc"
        assert result["properties"]["title"] == "智能表"
        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/add_sheet",
            {"docid": "DOC123", "properties": {"title": "智能表"}},
        )


def test_add_sheet_with_index():
    """Test adding a sheet with index parameter."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "properties": {
            "title": "智能表",
            "index": 5,
            "sheet_id": "456def",
        },
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import add_sheet

        result = add_sheet(
            access_token="test_token",
            docid="DOC123",
            title="智能表",
            index=5,
            proxy_config=None,
        )

        assert result["properties"]["sheet_id"] == "456def"
        assert result["properties"]["index"] == 5
        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/add_sheet",
            {"docid": "DOC123", "properties": {"title": "智能表", "index": 5}},
        )


def test_delete_sheet():
    """Test deleting a sheet."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import delete_sheet

        delete_sheet(
            access_token="test_token", docid="DOC123", sheet_id="123abc", proxy_config=None
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/delete_sheet", {"docid": "DOC123", "sheet_id": "123abc"}
        )


def test_delete_sheet_raises_on_error():
    """Test that delete_sheet raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid sheet_id")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import delete_sheet

        with pytest.raises(WeComAPIError) as exc_info:
            delete_sheet(
                access_token="test_token",
                docid="DOC123",
                sheet_id="INVALID",
                proxy_config=None,
            )

        assert exc_info.value.errcode == 40001


def test_update_sheet():
    """Test updating a sheet title."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import update_sheet

        update_sheet(
            access_token="test_token",
            docid="DOC123",
            sheet_id="123abc",
            title="新标题",
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/update_sheet",
            {"docid": "DOC123", "properties": {"sheet_id": "123abc", "title": "新标题"}},
        )


def test_update_sheet_raises_on_error():
    """Test that update_sheet raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid sheet_id")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import update_sheet

        with pytest.raises(WeComAPIError) as exc_info:
            update_sheet(
                access_token="test_token",
                docid="DOC123",
                sheet_id="INVALID",
                title="新标题",
                proxy_config=None,
            )

        assert exc_info.value.errcode == 40001


def test_get_sheet():
    """Test getting sheet information with sheet_id."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "sheet_list": [
            {
                "sheet_id": "123abc",
                "title": "智能表",
                "is_visible": True,
                "type": "smartsheet",
            }
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_sheet

        result = get_sheet(
            access_token="test_token",
            docid="DOC123",
            sheet_id="123abc",
            proxy_config=None,
        )

        assert result["sheet_list"][0]["sheet_id"] == "123abc"
        assert result["sheet_list"][0]["title"] == "智能表"
        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_sheet",
            {"docid": "DOC123", "sheet_id": "123abc"},
        )


def test_get_sheet_without_sheet_id():
    """Test getting all sheets without sheet_id."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "sheet_list": [
            {"sheet_id": "s1", "title": "表1", "is_visible": True, "type": "smartsheet"},
            {"sheet_id": "s2", "title": "仪表盘", "is_visible": True, "type": "dashboard"},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_sheet

        result = get_sheet(
            access_token="test_token",
            docid="DOC123",
            proxy_config=None,
        )

        assert len(result["sheet_list"]) == 2
        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_sheet",
            {"docid": "DOC123"},
        )


def test_get_sheet_with_all_type():
    """Test getting all types of sheets."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "sheet_list": [
            {"sheet_id": "s1", "title": "表1", "is_visible": True, "type": "smartsheet"},
            {"sheet_id": "s2", "title": "仪表盘", "is_visible": True, "type": "dashboard"},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_sheet

        get_sheet(
            access_token="test_token",
            docid="DOC123",
            need_all_type_sheet=True,
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_sheet",
            {"docid": "DOC123", "need_all_type_sheet": True},
        )


def test_get_sheet_raises_on_error():
    """Test that get_sheet raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid sheet_id")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_sheet

        with pytest.raises(WeComAPIError) as exc_info:
            get_sheet(
                access_token="test_token",
                docid="DOC123",
                sheet_id="INVALID",
                proxy_config=None,
            )

        assert exc_info.value.errcode == 40001
