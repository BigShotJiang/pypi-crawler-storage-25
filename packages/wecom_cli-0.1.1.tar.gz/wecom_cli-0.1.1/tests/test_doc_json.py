"""Test JSON output for doc commands."""

import json

import pytest
from typer.testing import CliRunner

from wecom_cli.cli import app
from wecom_cli.doc_registry import register_doc

runner = CliRunner()


class TestDocJsonOutput:
    """Test JSON output for doc commands."""

    def test_doc_list_json_mode(self, tmp_path, monkeypatch):
        """Test doc list command with --json flag."""
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        result = runner.invoke(app, ["--json", "doc", "list"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is True
        assert "data" in output

    def test_doc_list_with_docs_json_mode(self, tmp_path, monkeypatch):
        """Test doc list with existing docs in JSON mode."""
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

        register_doc("doc1", "id1")
        register_doc("doc2", "id2")

        result = runner.invoke(app, ["--json", "doc", "list"])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["success"] is True
        assert "data" in output
        assert "doc1" in output["data"]
        assert "doc2" in output["data"]

    def test_doc_add_missing_name_json_mode(self, tmp_path, monkeypatch):
        """Test doc add with missing name in JSON mode."""
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

        result = runner.invoke(app, ["--json", "doc", "add", "--name", ""])
        assert result.exit_code != 0
        output = json.loads(result.output)
        assert output["success"] is False
        assert "error" in output

    def test_doc_delete_not_found_json_mode(self, tmp_path, monkeypatch):
        """Test doc delete with not found in JSON mode."""
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

        result = runner.invoke(app, ["--json", "doc", "delete", "--name", "nonexistent"])
        assert result.exit_code != 0
        output = json.loads(result.output)
        assert output["success"] is False
        assert "error" in output

    def test_doc_rename_not_found_json_mode(self, tmp_path, monkeypatch):
        """Test doc rename with not found in JSON mode."""
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

        result = runner.invoke(
            app, ["--json", "doc", "rename", "--name", "nonexistent", "--new-name", "new"]
        )
        assert result.exit_code != 0
        output = json.loads(result.output)
        assert output["success"] is False
        assert "error" in output

    def test_doc_share_not_found_json_mode(self, tmp_path, monkeypatch):
        """Test doc share with not found in JSON mode."""
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

        result = runner.invoke(app, ["--json", "doc", "share", "--name", "nonexistent"])
        assert result.exit_code != 0
        output = json.loads(result.output)
        assert output["success"] is False
        assert "error" in output
