from unittest.mock import call, patch

import pytest
from typer.testing import CliRunner

from wecom_cli.cli import app
from wecom_cli.doc_registry import get_docid, register_doc

runner = CliRunner()


@pytest.fixture(autouse=True)
def clean_registry(monkeypatch, tmp_path):
    """Clean up registry before and after each test with config isolation."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

    yield


def test_doc_delete_by_name():
    """Test deleting a document by name."""
    register_doc("Test Doc", "DOC123")

    with patch("wecom_cli.commands.doc.delete.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.delete.delete_doc") as mock_delete:
            result = runner.invoke(app, ["doc", "delete", "--name", "Test Doc"])

            assert result.exit_code == 0
            assert "删除成功" in result.stdout
            assert mock_delete.called
            assert (
                call(access_token="test_token", docid="DOC123", proxy_config=None)
                in mock_delete.call_args_list
            )


def test_doc_delete_by_docid():
    """Test deleting a document by docid."""
    with patch("wecom_cli.commands.doc.delete.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.delete.delete_doc") as mock_delete:
            result = runner.invoke(app, ["doc", "delete", "--docid", "DOC456"])

            assert result.exit_code == 0
            assert "删除成功" in result.stdout
            assert mock_delete.called
            assert (
                call(access_token="test_token", docid="DOC456", proxy_config=None)
                in mock_delete.call_args_list
            )


def test_doc_delete_removes_from_registry():
    """Test that deletion by name removes doc from registry."""
    register_doc("Test Doc", "DOC123")
    assert get_docid("Test Doc") == "DOC123"

    with patch("wecom_cli.commands.doc.delete.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.delete.delete_doc"):
            result = runner.invoke(app, ["doc", "delete", "--name", "Test Doc"])

            assert result.exit_code == 0
            assert get_docid("Test Doc") is None


def test_doc_delete_by_docid_does_not_affect_registry():
    """Test that deletion by docid does not remove from registry."""
    register_doc("Test Doc", "DOC123")

    with patch("wecom_cli.commands.doc.delete.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.delete.delete_doc"):
            result = runner.invoke(app, ["doc", "delete", "--docid", "DOC123"])

            assert result.exit_code == 0
            assert get_docid("Test Doc") == "DOC123"


def test_doc_delete_not_found():
    """Test deleting a non-existent document by name."""
    with patch("wecom_cli.commands.doc.delete.get_access_token"):
        result = runner.invoke(app, ["doc", "delete", "--name", "Nonexistent"])

        assert result.exit_code != 0
        assert "未找到" in result.stdout


def test_doc_delete_missing_both():
    """Test deleting without docid or name raises error."""
    result = runner.invoke(app, ["doc", "delete"])

    assert result.exit_code != 0


def test_doc_delete_both_docid_and_name():
    """Test deleting with both docid and name raises error."""
    result = runner.invoke(app, ["doc", "delete", "--docid", "DOC123", "--name", "Test Doc"])

    assert result.exit_code != 0
