from __future__ import annotations

from unittest.mock import Mock, patch

import pytest

from wecom_cli.api.client import WeComAPIError


def test_add_fields_basic():
    """Test adding fields with minimal parameters."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "field_list": [
            {"field_id": "field1", "title": "Name"},
            {"field_id": "field2", "title": "Age"},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import add_fields

        result = add_fields(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            fields=[{"title": "Name"}, {"title": "Age"}],
            proxy_config=None,
        )

        assert result["field_list"][0]["field_id"] == "field1"
        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/add_fields",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "fields": [{"title": "Name"}, {"title": "Age"}],
            },
        )


def test_add_fields_multiple_fields():
    """Test adding multiple fields."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "field_list": [
            {"field_id": "f1", "title": "Name"},
            {"field_id": "f2", "title": "Email"},
            {"field_id": "f3", "title": "Phone"},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import add_fields

        result = add_fields(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            fields=[
                {"title": "Name", "type": "text"},
                {"title": "Email", "type": "text"},
                {"title": "Phone", "type": "text"},
            ],
            proxy_config=None,
        )

        assert len(result["field_list"]) == 3
        mock_client.post.assert_called_once()


def test_delete_fields():
    """Test deleting fields."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import delete_fields

        delete_fields(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            field_ids=["field1", "field2"],
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/delete_fields",
            {"docid": "DOC123", "sheet_id": "SHEET123", "field_ids": ["field1", "field2"]},
        )


def test_delete_fields_raises_on_error():
    """Test that delete_fields raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid field_ids")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import delete_fields

        with pytest.raises(WeComAPIError) as exc_info:
            delete_fields(
                access_token="test_token",
                docid="DOC123",
                sheet_id="SHEET123",
                field_ids=["invalid"],
                proxy_config=None,
            )

        assert exc_info.value.errcode == 40001


def test_get_fields_basic():
    """Test getting all fields with no filters."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "field_list": [
            {"field_id": "f1", "title": "Name"},
            {"field_id": "f2", "title": "Age"},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_fields

        result = get_fields(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            field_ids=None,
            field_titles=None,
            offset=None,
            limit=None,
            proxy_config=None,
        )

        assert result["field_list"][0]["field_id"] == "f1"
        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_fields",
            {"docid": "DOC123", "sheet_id": "SHEET123"},
        )


def test_get_fields_with_field_ids():
    """Test getting fields with specific field_ids."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "field_list": [{"field_id": "f1", "title": "Name"}],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_fields

        result = get_fields(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            field_ids=["f1", "f2"],
            field_titles=None,
            offset=None,
            limit=None,
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_fields",
            {"docid": "DOC123", "sheet_id": "SHEET123", "field_ids": ["f1", "f2"]},
        )


def test_get_fields_with_field_titles():
    """Test getting fields with specific field_titles."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "field_list": [{"field_id": "f1", "title": "Name"}],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_fields

        result = get_fields(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            field_ids=None,
            field_titles=["Name", "Age"],
            offset=None,
            limit=None,
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_fields",
            {"docid": "DOC123", "sheet_id": "SHEET123", "field_titles": ["Name", "Age"]},
        )


def test_get_fields_with_pagination():
    """Test getting fields with pagination parameters."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "field_list": [{"field_id": "f1", "title": "Name"}],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_fields

        result = get_fields(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            field_ids=None,
            field_titles=None,
            offset=10,
            limit=20,
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_fields",
            {"docid": "DOC123", "sheet_id": "SHEET123", "offset": 10, "limit": 20},
        )


def test_get_fields_raises_on_error():
    """Test that get_fields raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid sheet_id")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_fields

        with pytest.raises(WeComAPIError) as exc_info:
            get_fields(
                access_token="test_token",
                docid="DOC123",
                sheet_id="INVALID",
                field_ids=None,
                field_titles=None,
                offset=None,
                limit=None,
                proxy_config=None,
            )

        assert exc_info.value.errcode == 40001


def test_update_fields():
    """Test updating fields."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import update_fields

        update_fields(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            fields=[{"field_id": "f1", "title": "New Name"}],
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/update_fields",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "fields": [{"field_id": "f1", "title": "New Name"}],
            },
        )


def test_update_fields_multiple():
    """Test updating multiple fields."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import update_fields

        update_fields(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            fields=[
                {"field_id": "f1", "title": "New Name"},
                {"field_id": "f2", "title": "New Age"},
            ],
            proxy_config=None,
        )

        mock_client.post.assert_called_once()


def test_update_fields_raises_on_error():
    """Test that update_fields raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid field_id")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import update_fields

        with pytest.raises(WeComAPIError) as exc_info:
            update_fields(
                access_token="test_token",
                docid="DOC123",
                sheet_id="SHEET123",
                fields=[{"field_id": "invalid", "title": "Name"}],
                proxy_config=None,
            )

        assert exc_info.value.errcode == 40001


def test_add_records_basic():
    """Test adding records with minimal parameters."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {"record_id": "r1", "fields": [{"field_id": "f1", "text": "John"}]},
            {"record_id": "r2", "fields": [{"field_id": "f1", "text": "Jane"}]},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import add_records

        result = add_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            records=[
                {"fields": [{"field_id": "f1", "text": "John"}]},
                {"fields": [{"field_id": "f1", "text": "Jane"}]},
            ],
            proxy_config=None,
        )

        assert result["records"][0]["record_id"] == "r1"
        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/add_records",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "key_type": 1,
                "records": [
                    {"fields": [{"field_id": "f1", "text": "John"}]},
                    {"fields": [{"field_id": "f1", "text": "Jane"}]},
                ],
            },
        )


def test_add_records_multiple():
    """Test adding multiple records."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {"record_id": "r1"},
            {"record_id": "r2"},
            {"record_id": "r3"},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import add_records

        result = add_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=2,
            records=[
                {"fields": [{"field_id": "f1", "text": "A"}]},
                {"fields": [{"field_id": "f1", "text": "B"}]},
                {"fields": [{"field_id": "f1", "text": "C"}]},
            ],
            proxy_config=None,
        )

        assert len(result["records"]) == 3
        mock_client.post.assert_called_once()


def test_delete_records():
    """Test deleting records."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import delete_records

        delete_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            record_ids=["r1", "r2"],
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/delete_records",
            {"docid": "DOC123", "sheet_id": "SHEET123", "record_ids": ["r1", "r2"]},
        )


def test_delete_records_raises_on_error():
    """Test that delete_records raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid record_ids")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import delete_records

        with pytest.raises(WeComAPIError) as exc_info:
            delete_records(
                access_token="test_token",
                docid="DOC123",
                sheet_id="SHEET123",
                record_ids=["invalid"],
                proxy_config=None,
            )

        assert exc_info.value.errcode == 40001


def test_get_records_basic():
    """Test getting all records with no filters."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {
                "record_id": "r1",
                "fields": [{"field_id": "f1", "text": "John"}],
            }
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_records

        result = get_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            record_ids=None,
            field_titles=None,
            field_ids=None,
            sort=None,
            offset=None,
            limit=None,
            filter_spec=None,
            proxy_config=None,
        )

        assert result["records"][0]["record_id"] == "r1"
        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_records",
            {"docid": "DOC123", "sheet_id": "SHEET123", "key_type": 1},
        )


def test_get_records_with_record_ids():
    """Test getting records with specific record_ids."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {"record_id": "r1", "fields": [{"field_id": "f1", "text": "John"}]},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_records

        result = get_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            record_ids=["r1", "r2"],
            field_titles=None,
            field_ids=None,
            sort=None,
            offset=None,
            limit=None,
            filter_spec=None,
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_records",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "key_type": 1,
                "record_ids": ["r1", "r2"],
            },
        )


def test_get_records_with_field_ids():
    """Test getting records with specific field_ids."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {"record_id": "r1", "fields": [{"field_id": "f1", "text": "John"}]},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_records

        result = get_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            record_ids=None,
            field_titles=None,
            field_ids=["f1", "f2"],
            sort=None,
            offset=None,
            limit=None,
            filter_spec=None,
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_records",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "key_type": 1,
                "field_ids": ["f1", "f2"],
            },
        )


def test_get_records_with_field_titles():
    """Test getting records with specific field_titles."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {"record_id": "r1", "fields": [{"field_id": "f1", "text": "John"}]},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_records

        result = get_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            record_ids=None,
            field_titles=["Name", "Age"],
            field_ids=None,
            sort=None,
            offset=None,
            limit=None,
            filter_spec=None,
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_records",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "key_type": 1,
                "field_titles": ["Name", "Age"],
            },
        )


def test_get_records_with_sort():
    """Test getting records with sort parameter."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {"record_id": "r1", "fields": [{"field_id": "f1", "text": "John"}]},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_records

        result = get_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            record_ids=None,
            field_titles=None,
            field_ids=None,
            sort={"field_id": "f1", "type": "asc"},
            offset=None,
            limit=None,
            filter_spec=None,
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_records",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "key_type": 1,
                "sort": {"field_id": "f1", "type": "asc"},
            },
        )


def test_get_records_with_pagination():
    """Test getting records with pagination parameters."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {"record_id": "r1", "fields": [{"field_id": "f1", "text": "John"}]},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_records

        result = get_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            record_ids=None,
            field_titles=None,
            field_ids=None,
            sort=None,
            offset=10,
            limit=20,
            filter_spec=None,
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_records",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "key_type": 1,
                "offset": 10,
                "limit": 20,
            },
        )


def test_get_records_with_filter_spec():
    """Test getting records with filter_spec parameter."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {"record_id": "r1", "fields": [{"field_id": "f1", "text": "John"}]},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_records

        result = get_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            record_ids=None,
            field_titles=None,
            field_ids=None,
            sort=None,
            offset=None,
            limit=None,
            filter_spec={"conditions": [{"field_id": "f1", "value": "John"}]},
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_records",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "key_type": 1,
                "filter_spec": {"conditions": [{"field_id": "f1", "value": "John"}]},
            },
        )


def test_get_records_with_all_params():
    """Test getting records with all optional parameters."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "records": [
            {"record_id": "r1", "fields": [{"field_id": "f1", "text": "John"}]},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_records

        result = get_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            record_ids=["r1"],
            field_titles=["Name"],
            field_ids=["f1"],
            sort={"field_id": "f1", "type": "desc"},
            offset=0,
            limit=10,
            filter_spec={"conditions": [{"field_id": "f1", "value": "John"}]},
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/get_records",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "key_type": 1,
                "record_ids": ["r1"],
                "field_titles": ["Name"],
                "field_ids": ["f1"],
                "sort": {"field_id": "f1", "type": "desc"},
                "offset": 0,
                "limit": 10,
                "filter_spec": {"conditions": [{"field_id": "f1", "value": "John"}]},
            },
        )


def test_get_records_raises_on_error():
    """Test that get_records raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid sheet_id")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_records

        with pytest.raises(WeComAPIError) as exc_info:
            get_records(
                access_token="test_token",
                docid="DOC123",
                sheet_id="INVALID",
                key_type=1,
                record_ids=None,
                field_titles=None,
                field_ids=None,
                sort=None,
                offset=None,
                limit=None,
                filter_spec=None,
                proxy_config=None,
            )

        assert exc_info.value.errcode == 40001


def test_update_records():
    """Test updating records."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import update_records

        update_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            records=[
                {"record_id": "r1", "fields": [{"field_id": "f1", "text": "New John"}]}
            ],
            proxy_config=None,
        )

        mock_client.post.assert_called_once_with(
            "wedoc/smartsheet/update_records",
            {
                "docid": "DOC123",
                "sheet_id": "SHEET123",
                "key_type": 1,
                "records": [
                    {"record_id": "r1", "fields": [{"field_id": "f1", "text": "New John"}]}
                ],
            },
        )


def test_update_records_multiple():
    """Test updating multiple records."""
    mock_client = Mock()
    mock_client.post.return_value = {"errcode": 0, "errmsg": "ok"}

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import update_records

        update_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=2,
            records=[
                {"record_id": "r1", "fields": [{"field_id": "f1", "text": "A"}]},
                {"record_id": "r2", "fields": [{"field_id": "f1", "text": "B"}]},
            ],
            proxy_config=None,
        )

        mock_client.post.assert_called_once()


def test_update_records_raises_on_error():
    """Test that update_records raises on API error."""
    mock_client = Mock()
    mock_client.post.side_effect = WeComAPIError(errcode=40001, errmsg="Invalid record_id")

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import update_records

        with pytest.raises(WeComAPIError) as exc_info:
            update_records(
                access_token="test_token",
                docid="DOC123",
                sheet_id="SHEET123",
                key_type=1,
                records=[{"record_id": "invalid", "fields": []}],
                proxy_config=None,
            )

        assert exc_info.value.errcode == 40001


def test_get_all_records_single_page():
    """Test getting all records when response fits in one page."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "total": 3,
        "has_more": False,
        "records": [
            {"record_id": "r1"},
            {"record_id": "r2"},
            {"record_id": "r3"},
        ],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_all_records

        result = get_all_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            proxy_config=None,
        )

        assert len(result["records"]) == 3
        assert result["total"] == 3
        assert result["has_more"] is False
        mock_client.post.assert_called_once()


def test_get_all_records_multi_page():
    """Test getting all records across multiple pages."""
    mock_client = Mock()
    page1 = {
        "errcode": 0,
        "errmsg": "ok",
        "total": 5,
        "has_more": True,
        "records": [{"record_id": "r1"}, {"record_id": "r2"}, {"record_id": "r3"}],
    }
    page2 = {
        "errcode": 0,
        "errmsg": "ok",
        "total": 5,
        "has_more": False,
        "records": [{"record_id": "r4"}, {"record_id": "r5"}],
    }
    mock_client.post.side_effect = [page1, page2]

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_all_records

        result = get_all_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            proxy_config=None,
        )

        assert len(result["records"]) == 5
        assert result["total"] == 5
        assert result["has_more"] is False
        assert mock_client.post.call_count == 2


def test_get_all_records_with_filter():
    """Test getting all records with filter passes filter to each page."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "total": 1,
        "has_more": False,
        "records": [{"record_id": "r1"}],
    }

    filter_spec = {
        "conjunction": "CONJUNCTION_AND",
        "conditions": [{"field_id": "f1", "operator": "OPERATOR_IS"}],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_all_records

        result = get_all_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            filter_spec=filter_spec,
            proxy_config=None,
        )

        assert len(result["records"]) == 1
        call_args = mock_client.post.call_args
        assert call_args[0][1]["filter_spec"] == filter_spec


def test_get_all_records_with_sort():
    """Test getting all records with sort passes sort to each page."""
    mock_client = Mock()
    page1 = {
        "errcode": 0,
        "errmsg": "ok",
        "total": 3,
        "has_more": True,
        "records": [{"record_id": "r1"}, {"record_id": "r2"}],
    }
    page2 = {
        "errcode": 0,
        "errmsg": "ok",
        "total": 3,
        "has_more": False,
        "records": [{"record_id": "r3"}],
    }
    mock_client.post.side_effect = [page1, page2]

    sort_spec = [{"field_title": "名称", "desc": True}]

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_all_records

        result = get_all_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            sort=sort_spec,
            proxy_config=None,
        )

        assert len(result["records"]) == 3
        for call in mock_client.post.call_args_list:
            assert call[0][1]["sort"] == sort_spec


def test_get_all_records_empty():
    """Test getting all records when there are none."""
    mock_client = Mock()
    mock_client.post.return_value = {
        "errcode": 0,
        "errmsg": "ok",
        "total": 0,
        "has_more": False,
        "records": [],
    }

    with patch("wecom_cli.api.doc.WeComClient", return_value=mock_client):
        from wecom_cli.api.doc import get_all_records

        result = get_all_records(
            access_token="test_token",
            docid="DOC123",
            sheet_id="SHEET123",
            key_type=1,
            proxy_config=None,
        )

        assert len(result["records"]) == 0
        assert result["total"] == 0
