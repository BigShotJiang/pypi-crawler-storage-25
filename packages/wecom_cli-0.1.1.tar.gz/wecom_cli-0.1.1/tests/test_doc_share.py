from unittest.mock import call, patch

import pytest
from typer.testing import CliRunner

from wecom_cli.cli import app
from wecom_cli.doc_registry import register_doc

runner = CliRunner()


@pytest.fixture(autouse=True)
def clean_registry(monkeypatch, tmp_path):
    """Clean up registry before and after each test with config isolation."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

    yield


def test_doc_share_by_name():
    """Test getting document share URL by name."""
    register_doc("Test Doc", "DOC123")

    with patch("wecom_cli.commands.doc.share.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.share.share_doc") as mock_share:
            mock_share.return_value = "https://doc.weixin.qq.com/share/ABC123"

            result = runner.invoke(app, ["doc", "share", "--name", "Test Doc"])

            assert result.exit_code == 0
            assert "https://doc.weixin.qq.com/share/ABC123" in result.stdout
            assert mock_share.called
            assert (
                call(access_token="test_token", docid="DOC123", proxy_config=None)
                in mock_share.call_args_list
            )


def test_doc_share_by_docid():
    """Test getting document share URL by docid."""
    with patch("wecom_cli.commands.doc.share.get_access_token") as mock_token:
        mock_token.return_value = "test_token"

        with patch("wecom_cli.commands.doc.share.share_doc") as mock_share:
            mock_share.return_value = "https://doc.weixin.qq.com/share/XYZ789"

            result = runner.invoke(app, ["doc", "share", "--docid", "DOC456"])

            assert result.exit_code == 0
            assert "https://doc.weixin.qq.com/share/XYZ789" in result.stdout
            assert mock_share.called
            assert (
                call(access_token="test_token", docid="DOC456", proxy_config=None)
                in mock_share.call_args_list
            )


def test_doc_share_not_found():
    """Test sharing a non-existent document."""
    with patch("wecom_cli.commands.doc.share.get_access_token"):
        result = runner.invoke(app, ["doc", "share", "--name", "Nonexistent"])

        assert result.exit_code != 0
        assert "未找到" in result.stdout


def test_doc_share_missing_both():
    """Test sharing without docid or name raises error."""
    result = runner.invoke(app, ["doc", "share"])

    assert result.exit_code != 0


def test_doc_share_both_docid_and_name():
    """Test sharing with both docid and name raises error."""
    result = runner.invoke(app, ["doc", "share", "--docid", "DOC123", "--name", "Test Doc"])

    assert result.exit_code != 0
