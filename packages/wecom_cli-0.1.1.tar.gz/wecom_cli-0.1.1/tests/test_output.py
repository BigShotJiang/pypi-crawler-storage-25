"""Test output utility functions."""

import json

from wecom_cli.output import print_error, print_json, print_message


class TestPrintJson:
    """Test JSON output function."""

    def test_print_json_outputs_valid_json(self, capsys):
        """Test that print_json outputs valid JSON to stdout."""
        data = {"key": "value", "number": 42}
        print_json(data)

        captured = capsys.readouterr()
        output = json.loads(captured.out)

        assert output == data
        assert captured.err == ""

    def test_print_json_handles_complex_data(self, capsys):
        """Test that print_json handles nested structures."""
        data = {
            "success": True,
            "data": {
                "users": [
                    {"id": 1, "name": "Alice"},
                    {"id": 2, "name": "Bob"},
                ]
            },
        }
        print_json(data)

        captured = capsys.readouterr()
        output = json.loads(captured.out)

        assert output == data

    def test_print_json_handles_empty_dict(self, capsys):
        """Test that print_json handles empty dictionary."""
        print_json({})

        captured = capsys.readouterr()
        output = json.loads(captured.out)

        assert output == {}


class TestPrintMessage:
    """Test print_message function."""

    def test_print_message_in_json_mode_success(self, capsys):
        """Test print_message in JSON mode with success."""
        print_message("Operation successful", json_mode=True, success=True)

        captured = capsys.readouterr()
        output = json.loads(captured.out)

        assert output == {"success": True}
        assert captured.err == ""

    def test_print_message_in_json_mode_with_data(self, capsys):
        """Test print_message in JSON mode with data."""
        data = {"id": 123, "name": "test"}
        print_message("Created", json_mode=True, success=True, data=data)

        captured = capsys.readouterr()
        output = json.loads(captured.out)

        assert output == {"success": True, "data": data}

    def test_print_message_in_normal_mode(self, capsys):
        """Test print_message in normal mode."""
        print_message("Operation successful", json_mode=False, success=True)

        captured = capsys.readouterr()

        assert "Operation successful" in captured.out
        assert captured.err == ""

    def test_print_message_failure_in_json_mode(self, capsys):
        """Test print_message in JSON mode with failure."""
        print_message("Operation failed", json_mode=True, success=False)

        captured = capsys.readouterr()
        output = json.loads(captured.out)

        assert output == {"success": False}


class TestPrintError:
    """Test print_error function."""

    def test_print_error_in_json_mode(self, capsys):
        """Test print_error in JSON mode."""
        print_error("Something went wrong", json_mode=True)

        captured = capsys.readouterr()
        output = json.loads(captured.out)

        assert output == {"success": False, "error": "Something went wrong"}
        assert captured.err == ""

    def test_print_error_in_normal_mode(self, capsys):
        """Test print_error in normal mode."""
        print_error("Something went wrong", json_mode=False)

        captured = capsys.readouterr()

        assert "Something went wrong" in captured.out
        assert captured.err == ""

    def test_print_error_with_long_message(self, capsys):
        """Test print_error with a long error message."""
        long_message = (
            "This is a very long error message that contains a lot of details about what went wrong"
        )
        print_error(long_message, json_mode=True)

        captured = capsys.readouterr()
        output = json.loads(captured.out)

        assert output["success"] is False
        assert output["error"] == long_message
