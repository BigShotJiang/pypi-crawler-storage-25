import pytest

from wecom_cli.doc_registry import get_docid, list_docs, register_doc, unregister_doc


@pytest.fixture(autouse=True)
def clean_registry(monkeypatch, tmp_path):
    """Clean up registry before and after each test with config isolation."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

    yield


def test_register_doc():
    """Test registering a document."""
    register_doc("test_doc", "DOC123")
    assert get_docid("test_doc") == "DOC123"


def test_register_multiple_docs():
    """Test registering multiple documents."""
    register_doc("doc1", "DOC1")
    register_doc("doc2", "DOC2")
    register_doc("doc3", "DOC3")

    assert get_docid("doc1") == "DOC1"
    assert get_docid("doc2") == "DOC2"
    assert get_docid("doc3") == "DOC3"


def test_get_docid_not_found():
    """Test getting docid for non-existent document."""
    assert get_docid("nonexistent") is None


def test_unregister_doc():
    """Test unregistering a document."""
    register_doc("test_doc", "DOC123")
    assert get_docid("test_doc") == "DOC123"

    unregister_doc("test_doc")
    assert get_docid("test_doc") is None


def test_unregister_nonexistent_doc():
    """Test unregistering non-existent document should not raise error."""
    unregister_doc("nonexistent")


def test_list_docs():
    """Test listing all registered documents."""
    register_doc("doc1", "DOC1")
    register_doc("doc2", "DOC2")

    docs = list_docs()
    assert docs == {"doc1": "DOC1", "doc2": "DOC2"}


def test_list_empty():
    """Test listing when no documents are registered."""
    docs = list_docs()
    assert docs == {}


def test_register_overwrites_existing():
    """Test that registering overwrites existing entry."""
    register_doc("test_doc", "OLD_DOC")
    assert get_docid("test_doc") == "OLD_DOC"

    register_doc("test_doc", "NEW_DOC")
    assert get_docid("test_doc") == "NEW_DOC"
