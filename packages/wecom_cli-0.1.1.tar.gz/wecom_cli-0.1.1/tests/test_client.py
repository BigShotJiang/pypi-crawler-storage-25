import json
import os

import httpx
import pytest

from wecom_cli.api.client import WeComAPIError, WeComClient, _create_proxy_url


class TestWeComClientGet:
    def test_get_sends_request_with_access_token(self):
        transport = httpx.MockTransport(
            lambda req: httpx.Response(
                200,
                json={"errcode": 0, "errmsg": "ok", "data": "test"},
            )
        )
        client = WeComClient(access_token="test_token", transport=transport)
        result = client.get("test/path")
        assert result["errcode"] == 0
        assert result["data"] == "test"

    def test_get_injects_access_token_param(self):
        captured_req = {}

        def handler(req):
            captured_req["url"] = str(req.url)
            return httpx.Response(200, json={"errcode": 0, "errmsg": "ok"})

        transport = httpx.MockTransport(handler)
        client = WeComClient(access_token="my_token", transport=transport)
        client.get("test/path")
        assert "access_token=my_token" in captured_req["url"]


class TestWeComClientPost:
    def test_post_sends_json_body(self):
        captured_req = {}

        def handler(req):
            captured_req["body"] = json.loads(req.content.decode())
            return httpx.Response(200, json={"errcode": 0, "errmsg": "ok"})

        transport = httpx.MockTransport(handler)
        client = WeComClient(access_token="test_token", transport=transport)
        client.post("test/path", {"key": "value"})
        assert captured_req["body"] == {"key": "value"}


class TestWeComClientErrors:
    def test_raises_api_error_on_non_zero_errcode(self):
        transport = httpx.MockTransport(
            lambda req: httpx.Response(200, json={"errcode": 40001, "errmsg": "invalid credential"})
        )
        client = WeComClient(access_token="bad_token", transport=transport)
        with pytest.raises(WeComAPIError) as exc_info:
            client.get("test/path")
        assert exc_info.value.errcode == 40001
        assert "invalid credential" in str(exc_info.value)


class TestCreateProxyUrl:
    def test_returns_none_when_proxy_config_is_none(self):
        proxy_url = _create_proxy_url(None)
        assert proxy_url is None

    def test_returns_none_when_proxy_config_is_empty(self):
        config = {"http_url": "", "https_url": ""}
        proxy_url = _create_proxy_url(config)
        assert proxy_url is None

    def test_returns_https_proxy_when_both_configured(self):
        config = {
            "http_url": "http://proxy.example.com:8080",
            "https_url": "https://proxy.example.com:8443",
        }
        proxy_url = _create_proxy_url(config)
        assert proxy_url == "https://proxy.example.com:8443"

    def test_returns_http_proxy_when_only_http_configured(self):
        config = {"http_url": "http://proxy.example.com:8080"}
        proxy_url = _create_proxy_url(config)
        assert proxy_url == "http://proxy.example.com:8080"

    def test_returns_https_proxy_when_only_https_configured(self):
        config = {"https_url": "https://proxy.example.com:8443"}
        proxy_url = _create_proxy_url(config)
        assert proxy_url == "https://proxy.example.com:8443"

    def test_raises_value_error_for_invalid_http_url(self):
        config = {"http_url": "invalid-url"}
        with pytest.raises(ValueError, match="无效的 HTTP 代理 URL"):
            _create_proxy_url(config)

    def test_raises_value_error_for_invalid_https_url(self):
        config = {"https_url": "invalid-url"}
        with pytest.raises(ValueError, match="无效的 HTTPS 代理 URL"):
            _create_proxy_url(config)

    def test_accepts_http_and_https_protocols(self):
        config = {"https_url": "https://proxy.com:8443"}
        proxy_url = _create_proxy_url(config)
        assert proxy_url is not None


class TestWeComClientWithProxy:
    @pytest.fixture(autouse=True)
    def clear_proxy_env(self):
        """Clear proxy environment variables for these tests."""
        old_env = {}
        proxy_vars = [
            "http_proxy",
            "https_proxy",
            "HTTP_PROXY",
            "HTTPS_PROXY",
            "all_proxy",
            "ALL_PROXY",
            "socks_proxy",
            "SOCKS_PROXY",
        ]
        for var in proxy_vars:
            if var in os.environ:
                old_env[var] = os.environ[var]
                del os.environ[var]
        yield
        for var, val in old_env.items():
            os.environ[var] = val

    def test_uses_proxy_config_when_transport_not_provided(self):
        config = {"https_url": "https://proxy.example.com:8443"}
        client = WeComClient(access_token="test_token", proxy_config=config)
        assert client is not None

    def test_does_not_use_proxy_when_config_empty(self):
        config = {}
        client = WeComClient(access_token="test_token", proxy_config=config)
        assert client is not None

    def test_transport_parameter_takes_precedence(self):
        transport = httpx.MockTransport(
            lambda req: httpx.Response(200, json={"errcode": 0, "errmsg": "ok"})
        )
        config = {"https_url": "https://proxy.example.com:8443"}
        client = WeComClient(access_token="test_token", proxy_config=config, transport=transport)
        assert client is not None
