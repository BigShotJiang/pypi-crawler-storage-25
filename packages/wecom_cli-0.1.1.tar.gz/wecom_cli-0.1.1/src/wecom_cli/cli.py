import typer
from rich.console import Console
from typer import Context

from wecom_cli.commands.config.config_app import config_app
from wecom_cli.commands.doc.doc_app import doc_app
from wecom_cli.output import print_json

app = typer.Typer(
    name="wecom",
    help="企业微信命令行工具",
    no_args_is_help=True,
)
app.add_typer(config_app, name="config", help="配置管理命令")
app.add_typer(doc_app, name="doc", help="文档相关命令")

console = Console()


def _json_callback(value: bool, ctx: Context) -> None:
    """Store JSON mode in context."""
    ctx.ensure_object(dict)
    ctx.obj["json_mode"] = value


@app.callback()
def main(
    ctx: Context,
    json_mode: bool = typer.Option(
        False,
        "--json",
        help="Output in JSON format",
        callback=_json_callback,
        is_eager=True,
    ),
) -> None:
    """Main CLI callback."""
    pass


@app.command()
def version(ctx: Context):
    """查看版本信息"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if json_mode:
        print_json({"success": True, "data": {"version": "v0.1.0"}})
    else:
        console.print("[bold green]wecom-cli[/bold green] v0.1.0")
