"""Output utility functions for JSON and normal mode."""

import json
import sys
from typing import Any


def print_json(data: dict[str, Any]) -> None:
    """Print data as JSON to stdout.

    Args:
        data: Dictionary to print as JSON.
    """
    json.dump(data, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")


def print_message(
    message: str,
    json_mode: bool,
    success: bool = True,
    data: dict[str, Any] | None = None,
) -> None:
    """Print message in JSON or normal format.

    Args:
        message: Message to print.
        json_mode: If True, output in JSON format.
        success: Whether the operation was successful.
        data: Optional data to include in JSON output.
    """
    if json_mode:
        output = {"success": success}
        if data:
            output["data"] = data
        print_json(output)
    else:
        print(message)


def print_error(message: str, json_mode: bool) -> None:
    """Print error message in JSON or normal format.

    Args:
        message: Error message to print.
        json_mode: If True, output in JSON format.
    """
    if json_mode:
        print_json({"success": False, "error": message})
    else:
        print(message)
