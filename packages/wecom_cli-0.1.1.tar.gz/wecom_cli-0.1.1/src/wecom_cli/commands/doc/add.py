from __future__ import annotations

import typer
from rich.console import Console

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import DOC_TYPE_DOC, DOC_TYPE_SHEET, DOC_TYPE_SMART, create_doc
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import register_doc
from wecom_cli.output import print_error, print_json

console = Console()


def add(
    name: str,
    doc_type: str = "doc",
    spaceid: str | None = None,
    fatherid: str | None = None,
    admin_users: list[str] | None = None,
    json_mode: bool = False,
) -> None:
    """Create a new document.

    Args:
        name: Document name.
        doc_type: Document type (doc/sheet/smart).
        spaceid: Space ID (optional).
        fatherid: Parent directory ID (optional).
        admin_users: List of admin user IDs (optional).
        json_mode: If True, output in JSON format.
    """
    if not name:
        print_error("文档名称不能为空", json_mode)
        raise typer.Exit(1)

    type_map = {"doc": DOC_TYPE_DOC, "sheet": DOC_TYPE_SHEET, "smart": DOC_TYPE_SMART}

    if doc_type not in type_map:
        print_error(f"无效的文档类型 '{doc_type}'，必须是 doc/sheet/smart 之一", json_mode)
        raise typer.Exit(1)

    doc_type_value = type_map[doc_type]

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        result = create_doc(
            access_token=access_token,
            doc_type=doc_type_value,
            doc_name=name,
            spaceid=spaceid,
            fatherid=fatherid,
            admin_users=admin_users,
            proxy_config=proxy_config,
        )

        docid = result["docid"]
        url = result["url"]

        register_doc(name, docid)

        if json_mode:
            print_json(
                {
                    "success": True,
                    "data": {
                        "docid": docid,
                        "name": name,
                        "type": doc_type,
                        "url": url,
                    },
                }
            )
        else:
            console.print("[green]✓[/green] 文档创建成功")
            console.print(f"  名称: {name}")
            console.print(f"  类型: {doc_type}")
            console.print(f"  DocID: {docid}")
            console.print(f"  访问链接: {url}")

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
