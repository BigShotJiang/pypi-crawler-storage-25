import typer
from rich.console import Console
from typer import Context

from wecom_cli.commands.doc.add import add
from wecom_cli.commands.doc.delete import delete
from wecom_cli.commands.doc.rename import rename
from wecom_cli.commands.doc.share import share
from wecom_cli.commands.doc.smart.smart_app import smart_app
from wecom_cli.output import print_json

doc_app = typer.Typer(help="文档相关命令")
console = Console()

doc_app.add_typer(smart_app, name="smart", help="智能文档命令")


@doc_app.command("add")
def add_cmd(
    ctx: Context,
    name: str = typer.Option(..., "--name", "-n", help="文档名称", rich_help_panel="必需参数"),
    doc_type: str = typer.Option(
        "doc",
        "--type",
        "-t",
        help="文档类型 (doc/sheet/smart)",
        rich_help_panel="可选参数",
    ),
    spaceid: str | None = typer.Option(
        None, "--spaceid", help="空间ID", rich_help_panel="可选参数"
    ),
    fatherid: str | None = typer.Option(
        None, "--fatherid", help="父目录ID", rich_help_panel="可选参数"
    ),
    admin_users: list[str] | None = typer.Option(
        None,
        "--admin",
        "-a",
        help="文档管理员userid（可多次使用）",
        rich_help_panel="可选参数",
    ),
):
    """创建新文档"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False
    add(
        name=name,
        doc_type=doc_type,
        spaceid=spaceid,
        fatherid=fatherid,
        admin_users=admin_users,
        json_mode=json_mode,
    )


@doc_app.command("delete")
def delete_cmd(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", "-n", help="文档名称"),
):
    """删除文档"""
    delete(ctx=ctx, docid=docid, name=name)


@doc_app.command("rename")
def rename_cmd(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", "-n", help="原文档名称"),
    new_name: str = typer.Option(..., "--new-name", help="新文档名称"),
):
    """重命名文档"""
    rename(ctx=ctx, docid=docid, name=name, new_name=new_name)


@doc_app.command("share")
def share_cmd(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", "-n", help="文档名称"),
):
    """获取文档分享链接"""
    share(ctx=ctx, docid=docid, name=name)


@doc_app.command()
def list(ctx: Context):
    """列出所有文档"""
    from wecom_cli.doc_registry import list_docs

    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    docs = list_docs()
    if json_mode:
        print_json({"success": True, "data": docs})
    else:
        if not docs:
            console.print("[yellow]暂无注册的文档[/yellow]")
        else:
            console.print("[bold blue]文档列表:[/bold blue]")
            for name, docid in docs.items():
                if len(docid) > 20:
                    short_docid = f"{docid[:8]}...{docid[-8:]}"
                else:
                    short_docid = docid
                console.print(f"  [cyan]{name}[/cyan]: [dim]{short_docid}[/dim]")
