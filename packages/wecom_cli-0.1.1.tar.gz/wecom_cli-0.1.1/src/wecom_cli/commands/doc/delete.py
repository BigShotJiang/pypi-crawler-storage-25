from __future__ import annotations

import typer
from rich.console import Console
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import delete_doc
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid, unregister_doc
from wecom_cli.output import print_error, print_json

console = Console()


def delete(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
) -> None:
    """删除文档"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    resolved_name = name

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        delete_doc(access_token=access_token, docid=docid, proxy_config=proxy_config)

        if resolved_name:
            unregister_doc(resolved_name)

        if json_mode:
            print_json({"success": True, "data": {"docid": docid, "name": resolved_name}})
        else:
            label = f"'{resolved_name}'" if resolved_name else docid
            console.print(f"[green]✓[/green] 文档 {label} 删除成功")

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
