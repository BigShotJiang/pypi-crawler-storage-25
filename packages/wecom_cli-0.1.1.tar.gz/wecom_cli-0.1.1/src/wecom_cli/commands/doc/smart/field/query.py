from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import get_fields
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid
from wecom_cli.output import print_error, print_json

console = Console()


def query(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
    sheet_id: str = typer.Option(..., "--sheet-id", "-s", help="子表 ID"),
    field_ids: list[str] | None = typer.Option(None, "--field-id", "-f", help="字段 ID，可多次指定"),
    field_titles: list[str] | None = typer.Option(None, "--field-title", help="字段标题，可多次指定"),
    offset: int | None = typer.Option(None, "--offset", help="偏移量，默认 0"),
    limit: int | None = typer.Option(None, "--limit", help="分页大小，默认返回全部"),
) -> None:
    """查询字段

    可通过 --field-id 或 --field-title 查询指定字段，不指定则返回全部字段。
    """
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        result = get_fields(
            access_token=access_token,
            docid=docid,
            sheet_id=sheet_id,
            field_ids=field_ids if field_ids else None,
            field_titles=field_titles if field_titles else None,
            offset=offset,
            limit=limit,
            proxy_config=proxy_config,
        )

        if json_mode:
            print_json({"success": True, "data": result})
        else:
            fields = result.get("fields", [])
            total = result.get("total", len(fields))
            console.print(f"[green]✓[/green] 共 {total} 个字段")

            table = Table()
            table.add_column("Field ID", style="cyan")
            table.add_column("标题", style="green")
            table.add_column("类型")

            for field in fields:
                table.add_row(
                    field.get("field_id", ""),
                    field.get("field_title", ""),
                    field.get("field_type", ""),
                )
            console.print(table)

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
