import typer

from wecom_cli.commands.doc.smart.record.add import add
from wecom_cli.commands.doc.smart.record.delete import delete
from wecom_cli.commands.doc.smart.record.query import query
from wecom_cli.commands.doc.smart.record.update import update

record_app = typer.Typer(help="智能表格记录操作命令")

record_app.command()(add)
record_app.command()(delete)
record_app.command()(update)
record_app.command()(query)
