from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import get_sheet
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid
from wecom_cli.output import print_error, print_json

console = Console()


def query(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
    sheet_id: str | None = typer.Option(None, "--sheet-id", "-s", help="子表 ID（不指定则返回全部子表）"),
    all_type: bool = typer.Option(False, "--all-type", help="获取所有类型子表（包含仪表盘和说明页）"),
) -> None:
    """查询子表

    不指定 --sheet-id 时返回文档下所有子表，指定时返回单个子表信息。
    """
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        result = get_sheet(
            access_token=access_token,
            docid=docid,
            sheet_id=sheet_id,
            need_all_type_sheet=all_type if all_type else None,
            proxy_config=proxy_config,
        )

        sheet_list = result.get("sheet_list", [])

        if json_mode:
            print_json({"success": True, "data": {"sheet_list": sheet_list, "total": len(sheet_list)}})
        else:
            console.print(f"[green]✓[/green] 共 {len(sheet_list)} 个子表")

            table = Table()
            table.add_column("Sheet ID", style="cyan")
            table.add_column("标题", style="green")
            table.add_column("可见")
            table.add_column("类型")

            for sheet_info in sheet_list:
                is_visible = sheet_info.get("is_visible", False)
                table.add_row(
                    sheet_info.get("sheet_id", ""),
                    sheet_info.get("title", ""),
                    "是" if is_visible else "否",
                    sheet_info.get("type", ""),
                )
            console.print(table)

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
