from __future__ import annotations

import json

import typer
from rich.console import Console
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import update_fields
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid
from wecom_cli.output import print_error, print_json

console = Console()


def update(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
    sheet_id: str = typer.Option(..., "--sheet-id", "-s", help="子表 ID"),
    field_id: str = typer.Option(..., "--field-id", "-f", help="字段 ID"),
    title: str | None = typer.Option(None, "--title", "-t", help="新字段标题"),
    field_type: str = typer.Option(..., "--type", help="字段类型（必须为原类型）"),
    property_list: list[str] | None = typer.Option(None, "--property", "-p", help="字段属性 JSON，可多次指定，格式: 属性名=JSON值"),
) -> None:
    """更新字段

    只能更新字段标题和字段属性，不能更新字段类型（--type 必须为原类型）。

    字段属性示例:
      --property property_number='{"decimal_places":2,"use_separate":true}'
      --property property_select='{"options":[{"text":"选项1","style":1}]}'
    """
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    if not title and not property_list:
        print_error("必须提供 --title 或 --property 至少一个", json_mode)
        raise typer.Exit(1)

    field_data: dict = {"field_id": field_id, "field_type": field_type}
    if title:
        field_data["field_title"] = title

    if property_list:
        for prop in property_list:
            if "=" in prop:
                prop_name, prop_value = prop.split("=", 1)
                try:
                    field_data[prop_name] = json.loads(prop_value)
                except json.JSONDecodeError:
                    print_error(f"无效的 JSON 属性值: {prop_value}", json_mode)
                    raise typer.Exit(1)
            else:
                print_error(f"属性格式错误，应为: 属性名=JSON值，实际: {prop}", json_mode)
                raise typer.Exit(1)

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        result = update_fields(
            access_token=access_token,
            docid=docid,
            sheet_id=sheet_id,
            fields=[field_data],
            proxy_config=proxy_config,
        )

        if json_mode:
            print_json({"success": True, "data": result})
        else:
            console.print("[green]✓[/green] 字段更新成功")
            for field in result.get("fields", []):
                console.print(f"  Field ID: {field.get('field_id', '')}")
                console.print(f"  标题: {field.get('field_title', '')}")
                console.print(f"  类型: {field.get('field_type', '')}")

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
