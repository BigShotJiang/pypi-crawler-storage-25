import typer

from wecom_cli.commands.doc.smart.field.add import add
from wecom_cli.commands.doc.smart.field.delete import delete
from wecom_cli.commands.doc.smart.field.query import query
from wecom_cli.commands.doc.smart.field.update import update

field_app = typer.Typer(help="智能表格字段操作命令")

field_app.command()(add)
field_app.command()(delete)
field_app.command()(update)
field_app.command()(query)
