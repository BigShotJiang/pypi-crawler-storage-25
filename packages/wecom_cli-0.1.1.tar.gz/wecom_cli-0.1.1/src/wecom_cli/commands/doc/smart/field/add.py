from __future__ import annotations

import json

import typer
from rich.console import Console
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import add_fields
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid
from wecom_cli.output import print_error, print_json

console = Console()


def add(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
    sheet_id: str = typer.Option(..., "--sheet-id", "-s", help="子表 ID"),
    title: str = typer.Option(..., "--title", "-t", help="字段标题"),
    field_type: str = typer.Option(..., "--type", help="字段类型，如 FIELD_TYPE_TEXT, FIELD_TYPE_NUMBER 等"),
    property_list: list[str] | None = typer.Option(None, "--property", "-p", help="字段属性 JSON，可多次指定，格式: 属性名=JSON值"),
) -> None:
    """添加字段

    支持的字段类型: FIELD_TYPE_TEXT, FIELD_TYPE_NUMBER, FIELD_TYPE_CHECKBOX,
    FIELD_TYPE_DATE_TIME, FIELD_TYPE_IMAGE, FIELD_TYPE_ATTACHMENT, FIELD_TYPE_USER,
    FIELD_TYPE_URL, FIELD_TYPE_SELECT, FIELD_TYPE_CREATED_USER, FIELD_TYPE_MODIFIED_USER,
    FIELD_TYPE_CREATED_TIME, FIELD_TYPE_MODIFIED_TIME, FIELD_TYPE_PROGRESS,
    FIELD_TYPE_PHONE_NUMBER, FIELD_TYPE_EMAIL, FIELD_TYPE_SINGLE_SELECT,
    FIELD_TYPE_REFERENCE, FIELD_TYPE_LOCATION, FIELD_TYPE_CURRENCY,
    FIELD_TYPE_WWGROUP, FIELD_TYPE_AUTONUMBER, FIELD_TYPE_PERCENTAGE, FIELD_TYPE_BARCODE

    字段属性示例:
      --property property_number='{"decimal_places":2,"use_separate":true}'
      --property property_select='{"options":[{"text":"选项1","style":1}]}'
      --property property_date_time='{"format":"yyyy-mm-dd","auto_fill":true}'
    """
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    field_data: dict = {"field_title": title, "field_type": field_type}

    if property_list:
        for prop in property_list:
            if "=" in prop:
                prop_name, prop_value = prop.split("=", 1)
                try:
                    field_data[prop_name] = json.loads(prop_value)
                except json.JSONDecodeError:
                    print_error(f"无效的 JSON 属性值: {prop_value}", json_mode)
                    raise typer.Exit(1)
            else:
                print_error(f"属性格式错误，应为: 属性名=JSON值，实际: {prop}", json_mode)
                raise typer.Exit(1)

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        result = add_fields(
            access_token=access_token,
            docid=docid,
            sheet_id=sheet_id,
            fields=[field_data],
            proxy_config=proxy_config,
        )

        if json_mode:
            print_json({"success": True, "data": result})
        else:
            console.print("[green]✓[/green] 字段添加成功")
            for field in result.get("fields", []):
                console.print(f"  Field ID: {field.get('field_id', '')}")
                console.print(f"  标题: {field.get('field_title', '')}")
                console.print(f"  类型: {field.get('field_type', '')}")

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
