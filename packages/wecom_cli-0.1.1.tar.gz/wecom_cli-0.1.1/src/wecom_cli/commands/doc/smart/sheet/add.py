from __future__ import annotations

import typer
from rich.console import Console
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import add_sheet
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid
from wecom_cli.output import print_error, print_json

console = Console()


def add(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
    title: str = typer.Option(..., "--title", "-t", help="子表标题"),
    index: int | None = typer.Option(None, "--index", "-i", help="子表位置"),
) -> None:
    """添加子表"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        result = add_sheet(
            access_token=access_token,
            docid=docid,
            title=title,
            index=index,
            proxy_config=proxy_config,
        )

        sheet_id = result["properties"]["sheet_id"]
        returned_title = result["properties"]["title"]
        returned_index = result["properties"].get("index")

        if json_mode:
            print_json(
                {
                    "success": True,
                    "data": {
                        "sheet_id": sheet_id,
                        "title": returned_title,
                        "index": returned_index,
                    },
                }
            )
        else:
            console.print("[green]✓[/green] 子表添加成功")
            console.print(f"  Sheet ID: {sheet_id}")
            console.print(f"  标题: {returned_title}")
            if returned_index is not None:
                console.print(f"  位置: {returned_index}")

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
