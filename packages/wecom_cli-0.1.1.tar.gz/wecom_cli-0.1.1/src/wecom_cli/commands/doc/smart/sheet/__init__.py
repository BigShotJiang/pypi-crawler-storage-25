import typer

from wecom_cli.commands.doc.smart.sheet.add import add
from wecom_cli.commands.doc.smart.sheet.delete import delete
from wecom_cli.commands.doc.smart.sheet.query import query
from wecom_cli.commands.doc.smart.sheet.update import update

sheet_app = typer.Typer(help="智能表格子表操作命令")

sheet_app.command()(add)
sheet_app.command()(delete)
sheet_app.command()(update)
sheet_app.command()(query)
