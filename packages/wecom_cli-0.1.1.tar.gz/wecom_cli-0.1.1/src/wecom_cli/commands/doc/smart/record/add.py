from __future__ import annotations

import json

import typer
from rich.console import Console
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import add_records
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid
from wecom_cli.output import print_error, print_json

console = Console()


def add(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
    sheet_id: str = typer.Option(..., "--sheet-id", "-s", help="子表 ID"),
    key_type: str = typer.Option(
        "CELL_VALUE_KEY_TYPE_FIELD_TITLE",
        "--key-type",
        help="key 类型: CELL_VALUE_KEY_TYPE_FIELD_TITLE (字段标题) 或 CELL_VALUE_KEY_TYPE_FIELD_ID (字段 ID)",
    ),
    records: list[str] = typer.Option(..., "--record", "-r", help="记录数据 JSON，可多次指定。格式: '{\"values\": {\"字段标题\": [{\"type\":\"text\",\"text\":\"值\"}]}}'"),
) -> None:
    """添加记录

    通过 --record 传入 JSON 格式的记录数据，可多次指定添加多行记录。

    记录值类型说明:
      文本: [{"type":"text","text":"文本内容"}]
      数字: 123.45
      复选框: true/false
      日期: "1715846245084" (毫秒时间戳)
      成员: [{"user_id":"成员ID"}]
      链接: [{"type":"url","text":"显示文本","link":"https://..."}]
      多选/单选: [{"id":"选项ID"}] 或 [{"text":"新选项"}]
      进度: 0.5
      电话: "13800138000"
      邮箱: "test@example.com"
      地理位置: [{"source_type":1,"id":"地点ID","latitude":"23.1","longitude":"113.3","title":"地点名"}]
      货币: 99.99
      百分数: 0.75
      条码: "barcode_string"
    """
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    parsed_records: list[dict] = []
    for record_str in records:
        try:
            parsed_records.append(json.loads(record_str))
        except json.JSONDecodeError:
            print_error(f"无效的记录 JSON: {record_str}", json_mode)
            raise typer.Exit(1)

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        result = add_records(
            access_token=access_token,
            docid=docid,
            sheet_id=sheet_id,
            key_type=key_type,
            records=parsed_records,
            proxy_config=proxy_config,
        )

        if json_mode:
            print_json({"success": True, "data": result})
        else:
            returned_records = result.get("records", [])
            console.print(f"[green]✓[/green] 添加 {len(returned_records)} 条记录成功")
            for rec in returned_records:
                console.print(f"  Record ID: {rec.get('record_id', '')}")

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
