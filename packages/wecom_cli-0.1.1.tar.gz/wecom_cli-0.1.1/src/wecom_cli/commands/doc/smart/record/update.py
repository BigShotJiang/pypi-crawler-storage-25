from __future__ import annotations

import json

import typer
from rich.console import Console
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import update_records
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid
from wecom_cli.output import print_error, print_json

console = Console()


def update(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
    sheet_id: str = typer.Option(..., "--sheet-id", "-s", help="子表 ID"),
    key_type: str = typer.Option(
        "CELL_VALUE_KEY_TYPE_FIELD_TITLE",
        "--key-type",
        help="key 类型: CELL_VALUE_KEY_TYPE_FIELD_TITLE (字段标题) 或 CELL_VALUE_KEY_TYPE_FIELD_ID (字段 ID)",
    ),
    records: list[str] = typer.Option(..., "--record", "-r", help="更新记录 JSON，可多次指定。格式: '{\"record_id\":\"记录ID\",\"values\":{...}}'"),
) -> None:
    """更新记录

    通过 --record 传入 JSON 格式的记录数据，需包含 record_id 和 values。

    注意: 不能通过更新记录接口给创建时间、最后编辑时间、创建人和最后编辑人四种类型的字段更新记录。

    记录值类型说明同 record add 命令。
    """
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    parsed_records: list[dict] = []
    for record_str in records:
        try:
            parsed_records.append(json.loads(record_str))
        except json.JSONDecodeError:
            print_error(f"无效的记录 JSON: {record_str}", json_mode)
            raise typer.Exit(1)

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        result = update_records(
            access_token=access_token,
            docid=docid,
            sheet_id=sheet_id,
            key_type=key_type,
            records=parsed_records,
            proxy_config=proxy_config,
        )

        if json_mode:
            print_json({"success": True, "data": result})
        else:
            returned_records = result.get("records", [])
            console.print(f"[green]✓[/green] 更新 {len(returned_records)} 条记录成功")
            for rec in returned_records:
                console.print(f"  Record ID: {rec.get('record_id', '')}")

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
