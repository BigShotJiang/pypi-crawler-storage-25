import typer
from rich.console import Console

from wecom_cli.commands.doc.smart.field.field_app import field_app
from wecom_cli.commands.doc.smart.record.record_app import record_app
from wecom_cli.commands.doc.smart.sheet.sheet_app import sheet_app

smart_app = typer.Typer(help="智能文档命令")
console = Console()

smart_app.add_typer(sheet_app, name="sheet")
smart_app.add_typer(field_app, name="field")
smart_app.add_typer(record_app, name="record")
