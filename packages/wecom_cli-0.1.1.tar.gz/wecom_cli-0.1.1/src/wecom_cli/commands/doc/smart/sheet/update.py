from __future__ import annotations

import typer
from rich.console import Console
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import update_sheet
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid
from wecom_cli.output import print_error, print_json

console = Console()


def update(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
    sheet_id: str = typer.Option(..., "--sheet-id", "-s", help="子表 ID"),
    title: str = typer.Option(..., "--title", "-t", help="新标题"),
) -> None:
    """更新子表"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()
        update_sheet(
            access_token=access_token,
            docid=docid,
            sheet_id=sheet_id,
            title=title,
            proxy_config=proxy_config,
        )

        if json_mode:
            print_json({"success": True, "data": {"sheet_id": sheet_id, "title": title}})
        else:
            console.print("[green]✓[/green] 子表更新成功")
            console.print(f"  Sheet ID: {sheet_id}")
            console.print(f"  新标题: {title}")

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
