from __future__ import annotations

import json

import typer
from rich.console import Console
from typer import Context

from wecom_cli.api.auth import get_access_token
from wecom_cli.api.doc import get_all_records, get_records
from wecom_cli.config import get_config_dict
from wecom_cli.doc_registry import get_docid
from wecom_cli.output import print_error, print_json

console = Console()

FILTER_HELP = """
过滤条件，JSON 格式，可多次指定。每个 --filter 代表一个 Condition，多个条件之间通过 --filter-conjunction 组合。

Condition JSON 格式:
  {"field_id":"字段ID", "field_type":"字段类型", "operator":"操作符", "值类型":{...}}

支持的字段类型 (field_type):
  FIELD_TYPE_TEXT (文本), FIELD_TYPE_NUMBER (数字), FIELD_TYPE_CHECKBOX (复选框),
  FIELD_TYPE_DATE_TIME (日期), FIELD_TYPE_USER (成员), FIELD_TYPE_URL (链接),
  FIELD_TYPE_SELECT (多选), FIELD_TYPE_SINGLE_SELECT (单选),
  FIELD_TYPE_CREATED_USER (创建人), FIELD_TYPE_MODIFIED_USER (最后编辑人),
  FIELD_TYPE_CREATED_TIME (创建时间), FIELD_TYPE_MODIFIED_TIME (最后编辑时间),
  FIELD_TYPE_PROGRESS (进度), FIELD_TYPE_PHONE_NUMBER (电话),
  FIELD_TYPE_EMAIL (邮箱), FIELD_TYPE_LOCATION (地理位置),
  FIELD_TYPE_IMAGE (图片), FIELD_TYPE_ATTACHMENT (文件)

支持的操作符 (operator):
  OPERATOR_IS (等于), OPERATOR_IS_NOT (不等于),
  OPERATOR_CONTAINS (包含), OPERATOR_DOES_NOT_CONTAIN (不包含),
  OPERATOR_IS_GREATER (大于), OPERATOR_IS_GREATER_OR_EQUAL (大于或等于),
  OPERATOR_IS_LESS (小于), OPERATOR_IS_LESS_OR_EQUAL (小于或等于),
  OPERATOR_IS_EMPTY (为空), OPERATOR_IS_NOT_EMPTY (不为空)

值类型:
  string_value: 文本/网址/电话/邮箱/地理位置/单选/多选 - {"value":["文本值"]}
  number_value: 数字/进度 - {"value": 123}
  bool_value: 复选框 - {"value": true}
  user_value: 人员/创建人/最后编辑人 - {"value": ["成员ID"]}
  date_time_value: 日期/创建时间/最后编辑时间 - {"type":"日期类型","value":["时间戳"]}

日期值类型 (date_time_value.type):
  DATE_TIME_TYPE_DETAIL_DATE (具体时间，需提供 value 毫秒时间戳),
  DATE_TIME_TYPE_TODAY (今天), DATE_TIME_TYPE_TOMORROW (明天),
  DATE_TIME_TYPE_YESTERDAY (昨天), DATE_TIME_TYPE_CURRENT_WEEK (本周),
  DATE_TIME_TYPE_LAST_WEEK (上周), DATE_TIME_TYPE_CURRENT_MONTH (本月),
  DATE_TIME_TYPE_THE_PAST_7_DAYS (过去7天), DATE_TIME_TYPE_THE_NEXT_7_DAYS (未来7天),
  DATE_TIME_TYPE_LAST_MONTH (上月),
  DATE_TIME_TYPE_THE_PAST_30_DAYS (过去30天), DATE_TIME_TYPE_THE_NEXT_30_DAYS (未来30天)

示例:
  文本包含: --filter '{"field_id":"f1","field_type":"FIELD_TYPE_TEXT","operator":"OPERATOR_CONTAINS","string_value":{"value":["hello"]}}'
  数字大于: --filter '{"field_id":"f2","field_type":"FIELD_TYPE_NUMBER","operator":"OPERATOR_IS_GREATER","number_value":{"value":10}}'
  日期为今天: --filter '{"field_id":"f3","field_type":"FIELD_TYPE_DATE_TIME","operator":"OPERATOR_IS","date_time_value":{"type":"DATE_TIME_TYPE_TODAY"}}'
  为空判断: --filter '{"field_id":"f4","field_type":"FIELD_TYPE_TEXT","operator":"OPERATOR_IS_EMPTY"}'
  用户筛选: --filter '{"field_id":"f5","field_type":"FIELD_TYPE_USER","operator":"OPERATOR_IS","user_value":{"value":["UserID1"]}}'

注意: filter_spec 不支持和 --sort 一起使用。
""".strip()


def query(
    ctx: Context,
    docid: str | None = typer.Option(None, "--docid", help="文档 ID"),
    name: str | None = typer.Option(None, "--name", help="文档名称"),
    sheet_id: str = typer.Option(..., "--sheet-id", "-s", help="子表 ID"),
    key_type: str = typer.Option(
        "CELL_VALUE_KEY_TYPE_FIELD_TITLE",
        "--key-type",
        help="key 类型: CELL_VALUE_KEY_TYPE_FIELD_TITLE (字段标题) 或 CELL_VALUE_KEY_TYPE_FIELD_ID (字段 ID)",
    ),
    record_ids: list[str] | None = typer.Option(None, "--record-id", "-r", help="记录 ID，可多次指定"),
    field_titles: list[str] | None = typer.Option(None, "--field-title", help="返回指定字段标题，可多次指定"),
    field_ids: list[str] | None = typer.Option(None, "--field-id", help="返回指定字段 ID，可多次指定"),
    sort: list[str] | None = typer.Option(None, "--sort", help="排序 JSON，可多次指定。格式: '{\"field_title\":\"名称\",\"desc\":true}'。注意: 不支持和 --filter 同时使用"),
    offset: int | None = typer.Option(None, "--offset", help="偏移量，默认 0"),
    limit: int | None = typer.Option(None, "--limit", help="分页大小，默认 0 返回全部，最大 1000"),
    filters: list[str] | None = typer.Option(None, "--filter", help=FILTER_HELP),
    filter_conjunction: str = typer.Option(
        "CONJUNCTION_AND",
        "--filter-conjunction",
        help="过滤条件组合方式: CONJUNCTION_AND (所有条件都满足) 或 CONJUNCTION_OR (任一条件满足)",
    ),
    fetch_all: bool = typer.Option(False, "--all", help="自动分页获取全部记录（与 --offset/--limit 互斥）"),
) -> None:
    """查询记录

    支持分页、排序、字段筛选和条件过滤。filter 是重点功能，支持多种字段类型和操作符的组合筛选。

    使用 --filter 传入 JSON 格式的过滤条件，详细说明请参考 --filter 选项的帮助信息。

    使用 --all 自动分页获取全部记录，无需手动处理 offset/limit。
    """
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if not docid and not name:
        print_error("必须提供 --docid 或 --name 之一", json_mode)
        raise typer.Exit(1)

    if docid and name:
        print_error("--docid 和 --name 不能同时提供", json_mode)
        raise typer.Exit(1)

    if fetch_all and offset is not None:
        print_error("--all 和 --offset 不能同时使用", json_mode)
        raise typer.Exit(1)

    if fetch_all and limit is not None:
        print_error("--all 和 --limit 不能同时使用", json_mode)
        raise typer.Exit(1)

    if name:
        resolved_docid = get_docid(name)
        if not resolved_docid:
            print_error(f"未找到文档 '{name}'", json_mode)
            raise typer.Exit(1)
        docid = resolved_docid

    if filters and sort:
        print_error("filter 和 sort 不能同时使用", json_mode)
        raise typer.Exit(1)

    parsed_sort = None
    if sort:
        parsed_sort = []
        for sort_str in sort:
            try:
                parsed_sort.append(json.loads(sort_str))
            except json.JSONDecodeError:
                print_error(f"无效的排序 JSON: {sort_str}", json_mode)
                raise typer.Exit(1)

    filter_spec = None
    if filters:
        conditions = []
        for filter_str in filters:
            try:
                conditions.append(json.loads(filter_str))
            except json.JSONDecodeError:
                print_error(f"无效的过滤条件 JSON: {filter_str}", json_mode)
                raise typer.Exit(1)
        filter_spec = {
            "conjunction": filter_conjunction,
            "conditions": conditions,
        }

    try:
        config_dict = get_config_dict()
        proxy_config = config_dict.get("proxy") if config_dict else None
        access_token = get_access_token()

        if fetch_all:
            result = get_all_records(
                access_token=access_token,
                docid=docid,
                sheet_id=sheet_id,
                key_type=key_type,
                record_ids=record_ids if record_ids else None,
                field_titles=field_titles if field_titles else None,
                field_ids=field_ids if field_ids else None,
                sort=parsed_sort,
                filter_spec=filter_spec,
                proxy_config=proxy_config,
            )
        else:
            result = get_records(
                access_token=access_token,
                docid=docid,
                sheet_id=sheet_id,
                key_type=key_type,
                record_ids=record_ids if record_ids else None,
                field_titles=field_titles if field_titles else None,
                field_ids=field_ids if field_ids else None,
                sort=parsed_sort,
                offset=offset,
                limit=limit,
                filter_spec=filter_spec,
                proxy_config=proxy_config,
            )

        if json_mode:
            print_json({"success": True, "data": result})
        else:
            total = result.get("total", 0)
            has_more = result.get("has_more", False)
            records_list = result.get("records", [])
            console.print(f"[green]✓[/green] 共 {total} 条记录" + (" (还有更多)" if has_more else ""))

            for rec in records_list:
                console.print(f"\n  Record ID: {rec.get('record_id', '')}")
                console.print(f"  创建时间: {rec.get('create_time', '')}")
                console.print(f"  更新时间: {rec.get('update_time', '')}")
                values = rec.get("values", {})
                if values:
                    console.print("  值:")
                    for key, val in values.items():
                        console.print(f"    {key}: {json.dumps(val, ensure_ascii=False) if isinstance(val, (dict, list)) else val}")

    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
