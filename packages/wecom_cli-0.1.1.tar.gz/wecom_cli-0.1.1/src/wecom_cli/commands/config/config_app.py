import json
import time

import typer
from rich.console import Console
from rich.tree import Tree
from typer import Context

from wecom_cli.api.auth import is_token_valid
from wecom_cli.config import (
    get_config_dict,
    get_config_value,
    parse_key_path,
    set_config_value,
)
from wecom_cli.output import print_error, print_json, print_message

config_app = typer.Typer(help="配置管理命令")
console = Console()


def _mask(value: str, visible: int = 4) -> str:
    if len(value) <= visible:
        return "****"
    return value[:visible] + "****"


def _mask_token(token: str, visible: int = 8) -> str:
    if len(token) <= visible:
        return token + "..."
    return token[:visible] + "..."


@config_app.command()
def init(ctx: Context):
    """初始化配置文件"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    corpid = typer.prompt("请输入企业ID (corpid)")
    corpsecret = typer.prompt("请输入应用密钥 (corpsecret)")
    set_config_value("auth.corpid", corpid)
    set_config_value("auth.corpsecret", corpsecret)

    if json_mode:
        print_message("配置文件已初始化", json_mode=True, success=True)
    else:
        console.print("[bold green]✓ 配置文件已初始化[/bold green]")


@config_app.command()
def set(
    ctx: Context,
    key: str = typer.Argument(..., help="配置键路径"),
    value: str = typer.Argument(..., help="配置值"),
    json_flag: bool = typer.Option(False, "--json", help="值是 JSON 格式"),
):
    """设置配置项"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    try:
        parse_key_path(key)
    except ValueError as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)

    try:
        parsed_value = value
        if json_flag:
            parsed_value = json.loads(value)
        set_config_value(key, parsed_value)
        print_message("配置已更新", json_mode=json_mode, success=True)
    except json.JSONDecodeError as e:
        print_error(f"JSON 解析失败 - {e}", json_mode)
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)


@config_app.command()
def get(
    ctx: Context,
    key: str = typer.Argument(..., help="配置键路径"),
):
    """获取配置项"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    try:
        value = get_config_value(key)
        if value is None:
            print_error(f"配置项 '{key}' 不存在", json_mode)
            return

        if json_mode:
            print_json({"success": True, "data": value})
        else:
            if isinstance(value, (dict, list)):
                console.print(json.dumps(value, indent=2, ensure_ascii=False))
            else:
                console.print(str(value))
    except ValueError as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e), json_mode)
        raise typer.Exit(1)


@config_app.command(name="show")
def show_config(
    ctx: Context,
    key: str = typer.Argument(None, help="配置键路径（可选）"),
):
    """显示当前配置"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if key:
        try:
            value = get_config_value(key)
            if value is None:
                print_error(f"配置项 '{key}' 不存在", json_mode)
                return

            if json_mode:
                print_json({"success": True, "data": value})
            else:
                if isinstance(value, (dict, list)):
                    console.print(json.dumps(value, indent=2, ensure_ascii=False))
                else:
                    console.print(str(value))
        except ValueError as e:
            print_error(str(e), json_mode)
            raise typer.Exit(1)
        except Exception as e:
            print_error(str(e), json_mode)
            raise typer.Exit(1)
    else:
        config_dict = get_config_dict()
        if not config_dict:
            if json_mode:
                print_error("未找到配置，请先运行 wecom config init", json_mode)
            else:
                console.print(
                    "[yellow]未找到配置，请先运行 [bold]wecom config init[/bold][/yellow]"
                )
            return

        masked_dict = _mask_sensitive_values(config_dict)
        if json_mode:
            print_json({"success": True, "data": masked_dict})
        else:
            console.print("[bold]当前配置:[/bold]")
            console.print(json.dumps(masked_dict, indent=2, ensure_ascii=False))


def _mask_sensitive_values(data: dict) -> dict:
    """递归掩码敏感字段"""
    if not isinstance(data, dict):
        return data

    result = {}
    sensitive_keys = {"corpsecret", "apiKey", "access_token", "password", "secret"}

    for key, value in data.items():
        if isinstance(value, dict):
            result[key] = _mask_sensitive_values(value)
        elif isinstance(value, str) and any(
            sensitive_key in key.lower() for sensitive_key in sensitive_keys
        ):
            result[key] = _mask(value)
        else:
            result[key] = value

    return result


@config_app.command(name="list")
def list_config(ctx: Context):
    """列出所有配置项"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    config_dict = get_config_dict()
    if not config_dict:
        if json_mode:
            print_json({"success": True, "data": {}})
        else:
            console.print("[yellow]配置为空[/yellow]")
        return

    if json_mode:
        print_json({"success": True, "data": config_dict})
    else:
        tree = Tree("[bold]配置项:[/bold]")
        _add_to_tree(tree, config_dict)
        console.print(tree)


def _add_to_tree(tree: Tree, data: dict, prefix: str = "") -> None:
    """递归添加配置到树"""
    if not isinstance(data, dict):
        return

    for key in sorted(data.keys()):
        value = data[key]
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            branch = tree.add(f"[cyan]{key}[/cyan]")
            _add_to_tree(branch, value, full_key)
        elif isinstance(value, list):
            branch = tree.add(f"[cyan]{key}[/cyan] [dim](list, {len(value)} items)[/dim]")
        else:
            tree.add(f"[cyan]{key}[/cyan]: [green]{value}[/green]")


@config_app.command(name="token")
def show_token(ctx: Context):
    """显示 token 状态"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    access_token = get_config_value("cache.access_token")
    if not access_token:
        print_error("尚未获取 access_token", json_mode)
        return

    if is_token_valid():
        expires_at = get_config_value("cache.expires_at") or 0
        remaining = expires_at - int(time.time())
        if json_mode:
            print_json(
                {
                    "success": True,
                    "data": {
                        "valid": True,
                        "token": _mask_token(access_token),
                        "remaining_seconds": remaining,
                    },
                }
            )
        else:
            console.print("[bold green]access_token 有效[/bold green]")
            console.print(f"  token:   {_mask_token(access_token)}")
            console.print(f"  剩余:    {remaining} 秒")
    else:
        if json_mode:
            print_json(
                {
                    "success": True,
                    "data": {
                        "valid": False,
                        "token": _mask_token(access_token),
                        "reason": "expired_or_invalid",
                    },
                }
            )
        else:
            console.print("[bold red]access_token 已过期或失效[/bold red]")
            console.print(f"  token:   {_mask_token(access_token)}")


@config_app.command()
def proxy(
    ctx: Context,
    http_url: str = typer.Option(None, "--http", "-h", help="HTTP 代理地址"),
    https_url: str = typer.Option(None, "--https", "-s", help="HTTPS 代理地址"),
):
    """设置或查看代理配置"""
    json_mode = ctx.obj.get("json_mode", False) if ctx.obj else False

    if http_url is None and https_url is None:
        http_value = get_config_value("proxy.http_url")
        https_value = get_config_value("proxy.https_url")
        if json_mode:
            print_json(
                {
                    "success": True,
                    "data": {
                        "http": http_value,
                        "https": https_value,
                    },
                }
            )
        else:
            console.print("[yellow]当前代理配置:[/yellow]")
            console.print(f"  HTTP:  {http_value or '（未配置）'}")
            console.print(f"  HTTPS: {https_value or '（未配置）'}")
        return

    if http_url is not None:
        set_config_value("proxy.http_url", http_url)
    if https_url is not None:
        set_config_value("proxy.https_url", https_url)
    print_message("代理配置已更新", json_mode=json_mode, success=True)
