from __future__ import annotations

from typing import Any

from wecom_cli.api.client import WeComClient

DOC_TYPE_DOC = 3
DOC_TYPE_SHEET = 4
DOC_TYPE_SMART = 10


def create_doc(
    access_token: str,
    doc_type: int,
    doc_name: str,
    spaceid: str | None,
    fatherid: str | None,
    admin_users: list[str] | None,
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Create a new document.

    Args:
        access_token: Access token for API authentication.
        doc_type: Document type (3: doc, 4: sheet, 10: smart).
        doc_name: Document name.
        spaceid: Space ID (optional).
        fatherid: Parent directory ID (optional).
        admin_users: List of admin user IDs (optional).
        proxy_config: Proxy configuration (optional).

    Returns:
        API response containing docid and url.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    data: dict[str, Any] = {"doc_type": doc_type, "doc_name": doc_name}

    if spaceid:
        data["spaceid"] = spaceid
    if fatherid:
        data["fatherid"] = fatherid
    if admin_users:
        data["admin_users"] = admin_users

    return client.post("wedoc/create_doc", data)


def delete_doc(access_token: str, docid: str, proxy_config: dict | None = None) -> None:
    """Delete a document.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID to delete.
        proxy_config: Proxy configuration (optional).
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    client.post("wedoc/del_doc", {"docid": docid})


def rename_doc(
    access_token: str,
    docid: str,
    new_name: str,
    proxy_config: dict | None = None,
) -> None:
    """Rename a document.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID to rename.
        new_name: New document name.
        proxy_config: Proxy configuration (optional).
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    client.post("wedoc/rename_doc", {"docid": docid, "new_name": new_name})


def share_doc(access_token: str, docid: str, proxy_config: dict | None = None) -> str:
    """Get document share URL.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID to share.
        proxy_config: Proxy configuration (optional).

    Returns:
        Share URL for the document.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    response = client.post("wedoc/doc_share", {"docid": docid})
    return response["share_url"]


def add_sheet(
    access_token: str,
    docid: str,
    title: str,
    index: int | None = None,
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Add a new sheet to a smart document.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        title: Sheet title.
        index: Sheet position (optional).
        proxy_config: Proxy configuration (optional).

    Returns:
        API response containing sheet_id, title, and index.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    data: dict[str, Any] = {"docid": docid, "properties": {"title": title}}

    if index is not None:
        data["properties"]["index"] = index

    return client.post("wedoc/smartsheet/add_sheet", data)


def delete_sheet(
    access_token: str,
    docid: str,
    sheet_id: str,
    proxy_config: dict | None = None,
) -> None:
    """Delete a sheet from a smart document.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID to delete.
        proxy_config: Proxy configuration (optional).
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    client.post("wedoc/smartsheet/delete_sheet", {"docid": docid, "sheet_id": sheet_id})


def update_sheet(
    access_token: str,
    docid: str,
    sheet_id: str,
    title: str,
    proxy_config: dict | None = None,
) -> None:
    """Update a sheet's title.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID to update.
        title: New sheet title.
        proxy_config: Proxy configuration (optional).
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    client.post(
        "wedoc/smartsheet/update_sheet",
        {"docid": docid, "properties": {"sheet_id": sheet_id, "title": title}},
    )


def get_sheet(
    access_token: str,
    docid: str,
    sheet_id: str | None = None,
    need_all_type_sheet: bool | None = None,
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Get sheet information.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID to query (optional, returns all sheets if not specified).
        need_all_type_sheet: Whether to get all types of sheets including dashboards.
        proxy_config: Proxy configuration (optional).

    Returns:
        API response containing sheet information.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    body: dict[str, Any] = {"docid": docid}
    if sheet_id:
        body["sheet_id"] = sheet_id
    if need_all_type_sheet is not None:
        body["need_all_type_sheet"] = need_all_type_sheet
    return client.post("wedoc/smartsheet/get_sheet", body)


def add_fields(
    access_token: str,
    docid: str,
    sheet_id: str,
    fields: list[dict[str, Any]],
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Add fields to a smart sheet.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID.
        fields: List of field definitions to add.
        proxy_config: Proxy configuration (optional).

    Returns:
        API response containing added field details.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    return client.post(
        "wedoc/smartsheet/add_fields",
        {"docid": docid, "sheet_id": sheet_id, "fields": fields},
    )


def delete_fields(
    access_token: str,
    docid: str,
    sheet_id: str,
    field_ids: list[str],
    proxy_config: dict | None = None,
) -> None:
    """Delete fields from a smart sheet.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID.
        field_ids: List of field IDs to delete.
        proxy_config: Proxy configuration (optional).
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    client.post(
        "wedoc/smartsheet/delete_fields",
        {"docid": docid, "sheet_id": sheet_id, "field_ids": field_ids},
    )


def get_fields(
    access_token: str,
    docid: str,
    sheet_id: str,
    field_ids: list[str] | None = None,
    field_titles: list[str] | None = None,
    offset: int | None = None,
    limit: int | None = None,
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Get field information from a smart sheet.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID.
        field_ids: List of field IDs to query (optional).
        field_titles: List of field titles to query (optional).
        offset: Offset for pagination (optional).
        limit: Page size for pagination (optional).
        proxy_config: Proxy configuration (optional).

    Returns:
        API response containing field information.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    data: dict[str, Any] = {"docid": docid, "sheet_id": sheet_id}
    if field_ids is not None:
        data["field_ids"] = field_ids
    if field_titles is not None:
        data["field_titles"] = field_titles
    if offset is not None:
        data["offset"] = offset
    if limit is not None:
        data["limit"] = limit
    return client.post("wedoc/smartsheet/get_fields", data)


def update_fields(
    access_token: str,
    docid: str,
    sheet_id: str,
    fields: list[dict[str, Any]],
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Update fields in a smart sheet.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID.
        fields: List of field definitions to update.
        proxy_config: Proxy configuration (optional).

    Returns:
        API response containing updated field details.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    return client.post(
        "wedoc/smartsheet/update_fields",
        {"docid": docid, "sheet_id": sheet_id, "fields": fields},
    )


def add_records(
    access_token: str,
    docid: str,
    sheet_id: str,
    key_type: str,
    records: list[dict[str, Any]],
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Add records to a smart sheet.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID.
        key_type: Key type for cell values
            (CELL_VALUE_KEY_TYPE_FIELD_TITLE or CELL_VALUE_KEY_TYPE_FIELD_ID).
        records: List of record data to add.
        proxy_config: Proxy configuration (optional).

    Returns:
        API response containing added record details.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    return client.post(
        "wedoc/smartsheet/add_records",
        {"docid": docid, "sheet_id": sheet_id, "key_type": key_type, "records": records},
    )


def delete_records(
    access_token: str,
    docid: str,
    sheet_id: str,
    record_ids: list[str],
    proxy_config: dict | None = None,
) -> None:
    """Delete records from a smart sheet.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID.
        record_ids: List of record IDs to delete.
        proxy_config: Proxy configuration (optional).
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    client.post(
        "wedoc/smartsheet/delete_records",
        {"docid": docid, "sheet_id": sheet_id, "record_ids": record_ids},
    )


def get_records(
    access_token: str,
    docid: str,
    sheet_id: str,
    key_type: str,
    record_ids: list[str] | None = None,
    field_titles: list[str] | None = None,
    field_ids: list[str] | None = None,
    sort: list[dict[str, Any]] | None = None,
    offset: int | None = None,
    limit: int | None = None,
    filter_spec: dict[str, Any] | None = None,
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Get records from a smart sheet.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID.
        key_type: Key type for cell values.
        record_ids: List of record IDs to query (optional).
        field_titles: List of field titles to return (optional).
        field_ids: List of field IDs to return (optional).
        sort: Sort specification (optional).
        offset: Offset for pagination (optional).
        limit: Page size for pagination (optional).
        filter_spec: Filter specification (optional).
        proxy_config: Proxy configuration (optional).

    Returns:
        API response containing record information.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    data: dict[str, Any] = {"docid": docid, "sheet_id": sheet_id, "key_type": key_type}
    if record_ids is not None:
        data["record_ids"] = record_ids
    if field_titles is not None:
        data["field_titles"] = field_titles
    if field_ids is not None:
        data["field_ids"] = field_ids
    if sort is not None:
        data["sort"] = sort
    if offset is not None:
        data["offset"] = offset
    if limit is not None:
        data["limit"] = limit
    if filter_spec is not None:
        data["filter_spec"] = filter_spec
    return client.post("wedoc/smartsheet/get_records", data)


def get_all_records(
    access_token: str,
    docid: str,
    sheet_id: str,
    key_type: str,
    record_ids: list[str] | None = None,
    field_titles: list[str] | None = None,
    field_ids: list[str] | None = None,
    sort: list[dict[str, Any]] | None = None,
    filter_spec: dict[str, Any] | None = None,
    page_size: int = 1000,
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Get all records from a smart sheet with automatic pagination.

    Automatically fetches all pages of records by looping until has_more is False.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID.
        key_type: Key type for cell values.
        record_ids: List of record IDs to query (optional).
        field_titles: List of field titles to return (optional).
        field_ids: List of field IDs to return (optional).
        sort: Sort specification (optional).
        filter_spec: Filter specification (optional).
        page_size: Number of records per page (default 1000, max allowed by API).
        proxy_config: Proxy configuration (optional).

    Returns:
        Merged API response with all records, total count, and has_more=False.
    """
    all_records: list[dict[str, Any]] = []
    offset = 0
    total = 0

    while True:
        result = get_records(
            access_token=access_token,
            docid=docid,
            sheet_id=sheet_id,
            key_type=key_type,
            record_ids=record_ids,
            field_titles=field_titles,
            field_ids=field_ids,
            sort=sort,
            offset=offset,
            limit=page_size,
            filter_spec=filter_spec,
            proxy_config=proxy_config,
        )

        records = result.get("records", [])
        total = result.get("total", 0)
        all_records.extend(records)

        if not result.get("has_more", False):
            break

        offset += len(records)

    return {
        "total": total,
        "has_more": False,
        "records": all_records,
    }


def update_records(
    access_token: str,
    docid: str,
    sheet_id: str,
    key_type: str,
    records: list[dict[str, Any]],
    proxy_config: dict | None = None,
) -> dict[str, Any]:
    """Update records in a smart sheet.

    Args:
        access_token: Access token for API authentication.
        docid: Document ID.
        sheet_id: Sheet ID.
        key_type: Key type for cell values.
        records: List of record data to update (must include record_id and values).
        proxy_config: Proxy configuration (optional).

    Returns:
        API response containing updated record details.
    """
    client = WeComClient(access_token=access_token, proxy_config=proxy_config)
    return client.post(
        "wedoc/smartsheet/update_records",
        {"docid": docid, "sheet_id": sheet_id, "key_type": key_type, "records": records},
    )
