from __future__ import annotations

from typing import Any

import httpx

BASE_URL = "https://qyapi.weixin.qq.com/cgi-bin/"


class WeComAPIError(Exception):
    def __init__(self, errcode: int, errmsg: str) -> None:
        self.errcode = errcode
        self.errmsg = errmsg
        super().__init__(f"[{errcode}] {errmsg}")


def _create_proxy_url(proxy_config: dict | None = None) -> str | None:
    if not proxy_config:
        return None

    https_url = proxy_config.get("https_url")
    http_url = proxy_config.get("http_url")

    if https_url:
        if not https_url.startswith(("http://", "https://")):
            raise ValueError(f"无效的 HTTPS 代理 URL: {https_url}")
        return https_url
    elif http_url:
        if not http_url.startswith(("http://", "https://")):
            raise ValueError(f"无效的 HTTP 代理 URL: {http_url}")
        return http_url

    return None


def _create_transport(proxy_config: dict | None = None) -> httpx.BaseTransport | None:
    proxy_url = _create_proxy_url(proxy_config)
    if proxy_url is None:
        return None
    return httpx.HTTPTransport(proxy=proxy_url)


class WeComClient:
    def __init__(
        self,
        access_token: str,
        proxy_config: dict | None = None,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self._access_token = access_token
        if transport is None:
            proxy_url = _create_proxy_url(proxy_config)
            self._client = httpx.Client(
                base_url=BASE_URL,
                proxy=proxy_url,
                trust_env=False,
            )
        else:
            self._client = httpx.Client(
                base_url=BASE_URL,
                transport=transport,
                trust_env=False,
            )

    def get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        merged = {"access_token": self._access_token}
        if params:
            merged.update(params)
        resp = self._client.get(path, params=merged)
        data = resp.json()
        self._check_error(data)
        return data

    def post(self, path: str, json_data: dict[str, Any] | None = None) -> dict[str, Any]:
        params = {"access_token": self._access_token}
        resp = self._client.post(path, params=params, json=json_data)
        data = resp.json()
        self._check_error(data)
        return data

    def _check_error(self, data: dict[str, Any]) -> None:
        errcode = data.get("errcode", 0)
        if errcode != 0:
            raise WeComAPIError(errcode=errcode, errmsg=data.get("errmsg", ""))
