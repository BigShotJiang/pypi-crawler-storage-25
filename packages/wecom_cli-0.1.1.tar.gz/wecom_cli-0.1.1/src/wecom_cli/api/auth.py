from __future__ import annotations

import time

import httpx

from wecom_cli.api.client import _create_proxy_url
from wecom_cli.config import get_config_dict, get_config_value, set_config_value

EXPIRY_BUFFER = 300


def is_token_valid() -> bool:
    access_token = get_config_value("cache.access_token")
    if not access_token:
        return False
    expires_at = get_config_value("cache.expires_at") or 0
    return time.time() < expires_at - EXPIRY_BUFFER


def get_access_token(transport: httpx.BaseTransport | None = None) -> str:
    if is_token_valid():
        return get_config_value("cache.access_token") or ""
    config_dict = get_config_dict()
    proxy_config = config_dict.get("proxy") if config_dict else None
    return refresh_token(transport=transport, proxy_config=proxy_config)


def refresh_token(
    transport: httpx.BaseTransport | None = None,
    proxy_config: dict | None = None,
) -> str:
    if transport is None:
        proxy_url = _create_proxy_url(proxy_config)
        client = httpx.Client(
            base_url="https://qyapi.weixin.qq.com/cgi-bin/",
            proxy=proxy_url,
            trust_env=False,
        )
    else:
        client = httpx.Client(
            base_url="https://qyapi.weixin.qq.com/cgi-bin/",
            transport=transport,
            trust_env=False,
        )
    corpid = get_config_value("auth.corpid")
    corpsecret = get_config_value("auth.corpsecret")
    resp = client.get("gettoken", params={"corpid": corpid, "corpsecret": corpsecret})
    data = resp.json()
    if data.get("errcode", 0) != 0:
        raise RuntimeError(
            f"Failed to get access_token: [{data.get('errcode')}] {data.get('errmsg')}"
        )
    set_config_value("cache.access_token", data["access_token"])
    set_config_value("cache.expires_at", int(time.time()) + data["expires_in"])
    return data["access_token"]
