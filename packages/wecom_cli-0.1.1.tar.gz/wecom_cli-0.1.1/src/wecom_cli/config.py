from __future__ import annotations

import os
import stat
import tomllib
from pathlib import Path

import tomli_w


def get_config_dir() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "wecom-cli"
    return Path.home() / ".config" / "wecom-cli"


def get_config_path() -> Path:
    return get_config_dir() / "config.toml"


def parse_key_path(key: str) -> list[str]:
    if not key:
        raise ValueError("键路径不能为空")

    if key.startswith("."):
        raise ValueError("键路径不能以点开头")

    if key.endswith("."):
        raise ValueError("键路径不能以点结尾")

    if ".." in key:
        raise ValueError("键路径不能包含连续的点")

    parts = []
    i = 0
    n = len(key)

    while i < n:
        if key[i] in ("'", '"'):
            quote_char = key[i]
            i += 1
            start = i
            while i < n and key[i] != quote_char:
                i += 1
            if i >= n:
                raise ValueError("引号不匹配")
            quoted_part = key[start:i]
            if not quoted_part:
                raise ValueError("键名不能为空")
            parts.append(quoted_part)
            i += 1
            if i < n and key[i] != ".":
                raise ValueError("引号后必须跟随点或结束")
            elif i < n and key[i] == ".":
                i += 1
        else:
            start = i
            while i < n and key[i] not in ("'", '"', "."):
                i += 1
            part = key[start:i]
            if not part:
                raise ValueError("键名不能为空")
            parts.append(part)
            if i < n and key[i] == ".":
                i += 1

    return parts


def get_config_dict() -> dict:
    path = get_config_path()
    if not path.exists():
        return {}
    with open(path, "rb") as f:
        return tomllib.load(f)


def save_config_dict(config: dict) -> None:
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        tomli_w.dump(config, f)
    path.chmod(stat.S_IRUSR | stat.S_IWUSR)


def get_config_value(key: str):
    config = get_config_dict()
    key_parts = parse_key_path(key)
    value = config
    for part in key_parts:
        if isinstance(value, dict) and part in value:
            value = value[part]
        else:
            return None
    return value


def set_config_value(key: str, value) -> None:
    if value is None or value == "":
        delete_config_value(key)
        return

    config = get_config_dict()
    key_parts = parse_key_path(key)
    current = config
    for part in key_parts[:-1]:
        if part not in current:
            current[part] = {}
        elif not isinstance(current[part], dict):
            current[part] = {}
        current = current[part]
    current[key_parts[-1]] = value
    save_config_dict(config)


def delete_config_value(key: str) -> None:
    config = get_config_dict()
    key_parts = parse_key_path(key)
    current = config
    path = []

    for part in key_parts[:-1]:
        if not isinstance(current, dict) or part not in current:
            return
        path.append((current, part))
        current = current[part]

    if not isinstance(current, dict) or key_parts[-1] not in current:
        return

    del current[key_parts[-1]]

    for parent, part in reversed(path):
        if isinstance(parent[part], dict) and not parent[part]:
            del parent[part]
        else:
            break

    save_config_dict(config)
