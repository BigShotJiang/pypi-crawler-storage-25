from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

from wecom_cli import config


def register_doc(name: str, docid: str) -> None:
    """Register a document in the registry.

    Args:
        name: Document name.
        docid: Document ID.
    """
    cfg = config.get_config_dict()
    if "doc_registry" not in cfg:
        cfg["doc_registry"] = {}
    cfg["doc_registry"][name] = docid
    config.save_config_dict(cfg)


def get_docid(name: str) -> str | None:
    """Get docid by document name.

    Args:
        name: Document name.

    Returns:
        Document ID if found, None otherwise.
    """
    cfg = config.get_config_dict()
    if "doc_registry" not in cfg:
        return None
    return cfg["doc_registry"].get(name)


def unregister_doc(name: str) -> None:
    """Remove a document from the registry.

    Args:
        name: Document name.
    """
    cfg = config.get_config_dict()
    if "doc_registry" not in cfg:
        return
    if name in cfg["doc_registry"]:
        del cfg["doc_registry"][name]
        config.save_config_dict(cfg)


def list_docs() -> dict[str, str]:
    """List all registered documents.

    Returns:
        Dictionary mapping document names to docids.
    """
    cfg = config.get_config_dict()
    if "doc_registry" not in cfg:
        return {}
    return dict(cfg["doc_registry"])
