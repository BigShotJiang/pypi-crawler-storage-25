# JSON 输出格式功能需求

## 功能描述

为所有 CLI 命令添加 `--json` 参数，支持以 JSON 格式输出命令执行结果。当不指定 `--json` 时，保持现有的默认输出格式（使用 Rich 格式化）。

## 需求详情

### 1. 功能需求

1. **全局参数**：为所有命令添加 `--json` 选项
   - 当指定 `--json` 时，输出格式为标准 JSON
   - 当不指定 `--json` 时，保持现有的默认输出格式
   - JSON 输出应该包含命令执行的关键信息

2. **输出格式要求**：
   - 成功时：JSON 对象包含 `success: true` 和相关数据
   - 失败时：JSON 对象包含 `success: false` 和错误信息
   - 错误时也应该以 JSON 格式输出，便于程序解析

3. **涉及命令**：
   - `wecom version` - 版本信息
   - `wecom config init` - 初始化配置
   - `wecom config set` - 设置配置项
   - `wecom config get` - 获取配置项
   - `wecom config show` - 显示配置
   - `wecom config list` - 列出配置项
   - `wecom config token` - 显示 token 状态
   - `wecom config proxy` - 代理配置
   - `wecom doc add` - 创建文档
   - `wecom doc delete` - 删除文档
   - `wecom doc rename` - 重命名文档
   - `wecom doc share` - 获取文档分享链接
   - `wecom doc list` - 列出文档
   - `wecom doc smart create` - 创建智能文档

### 2. 设计考虑

1. **实现方式**：
   - 使用 Typer 的 `Context` 对象传递 `--json` 参数
   - 创建一个输出工具模块，统一处理 JSON 和普通格式的输出
   - 保持现有代码结构，最小化改动

2. **JSON 输出结构**：
   - 成功：`{"success": true, "data": {...}}`
   - 失败：`{"success": false, "error": "错误信息"}`
   - 无数据（如 init）：`{"success": true}`

3. **向后兼容**：
   - 默认行为保持不变
   - JSON 输出仅在显式指定时启用

## 开发任务

### [x] 任务 1：创建输出工具模块

创建 `src/wecom_cli/output.py` 模块，提供统一的输出处理函数：

- `print_json(data: dict)`: 输出 JSON 格式
- `print_message(message: str, json_mode: bool, success: bool = True, data: dict | None = None)`: 根据 json_mode 输出相应格式
- `print_error(message: str, json_mode: bool)`: 根据 json_mode 输出错误信息

### [x] 任务 2：修改 CLI 主入口

修改 `src/wecom_cli/cli.py`：

- 在主 app 上添加 `--json` 选项
- 使用 `callback` 函数将 `json_mode` 存储到 Context 中

### [x] 任务 3：修改 config 命令组

修改 `src/wecom_cli/commands/config/config_app.py`：

- 为每个命令函数添加 `json_mode` 参数（从 Context 获取）
- 修改输出逻辑，使用新的输出工具模块
- 涉及命令：init, set, get, show, list, token, proxy

### [x] 任务 4：修改 doc 命令组入口

修改 `src/wecom_cli/commands/doc/doc_app.py`：

- 为每个命令函数添加 `json_mode` 参数（从 Context 获取）
- 修改输出逻辑，使用新的输出工具模块
- 涉及命令：add, delete, rename, share, list

### [x] 任务 5：修改 doc 命令实现

修改以下文件：

- `src/wecom_cli/commands/doc/add.py` - 修改 add 函数，添加 json_mode 参数
- `src/wecom_cli/commands/doc/delete.py` - 修改 delete 函数，添加 json_mode 参数
- `src/wecom_cli/commands/doc/rename.py` - 修改 rename 函数，添加 json_mode 参数
- `src/wecom_cli/commands/doc/share.py` - 修改 share 函数，添加 json_mode 参数

### [x] 任务 6：修改 smart 命令组

修改 `src/wecom_cli/commands/doc/smart/create.py`：

- 为 create 命令添加 json_mode 参数
- 修改输出逻辑，使用新的输出工具模块

### [x] 任务 7：编写测试

为 JSON 输出功能编写测试：

- 测试输出工具模块的功能
- 测试每个命令的 JSON 输出格式
- 测试错误情况的 JSON 输出
- 确保默认输出不受影响

### [x] 任务 8：更新文档

更新 `README.md` 和 `structs.md`：

- 在 README 中说明 `--json` 参数的使用方法
- 在 structs.md 中添加 output.py 模块的说明

## 验收标准

1. 所有命令都支持 `--json` 参数
2. JSON 输出格式正确，易于程序解析
3. 错误信息也能以 JSON 格式输出
4. 默认输出（不使用 `--json`）保持不变
5. 所有测试通过
6. 文档更新完整
