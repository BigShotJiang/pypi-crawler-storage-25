# 字段与记录增删改查功能

## 背景

根据企业微信智能表格 API，需要提供字段（field）和记录（record）的完整 CRUD 功能：
- 字段操作：添加字段、删除字段、查询字段、更新字段
- 记录操作：添加记录、删除记录、查询记录、更新记录

重要特性：
- 字段和记录操作均需指定文档 ID（docid）和子表 ID（sheet_id）
- 支持 --docid 直接传入和 --name 通过注册表查找两种方式
- 查询记录支持 filter_spec 过滤（重点功能），需完整支持所有过滤条件
- 查询记录支持分页（offset/limit）、排序（sort）、字段筛选（field_titles/field_ids）
- 添加/更新记录支持通过字段标题或字段 ID 作为 key（key_type）
- 添加字段支持多种字段类型及其属性配置

## 技术选型

| 项目 | 选择 | 说明 |
|------|------|------|
| HTTP 客户端 | httpx | 复用现有 WeComClient |
| 命令框架 | typer | 复用现有命令结构 |
| JSON 输出 | 与现有命令一致 | {"success": True, "data": {...}} |
| filter_spec 解析 | CLI 选项转 JSON | 通过多个 --filter 选项构建，每个选项接收 JSON 字符串 |

## 命令设计

### 命令结构

```
wecom doc smart sheet field add     # 添加字段
wecom doc smart sheet field delete  # 删除字段
wecom doc smart sheet field query   # 查询字段
wecom doc smart sheet field update  # 更新字段
wecom doc smart sheet record add    # 添加记录
wecom doc smart sheet record delete # 删除记录
wecom doc smart sheet record query  # 查询记录
wecom doc smart sheet record update # 更新记录
```

### field add 命令

选项：
- --docid：文档 ID（与 --name 二选一）
- --name：文档名称（与 --docid 二选一）
- --sheet-id：子表 ID（必填）
- --title：字段标题（必填）
- --type：字段类型（必填，如 FIELD_TYPE_TEXT）
- --property：字段属性（可选，JSON 字符串，可多次指定）

### field delete 命令

选项：
- --docid / --name：文档标识（二选一）
- --sheet-id：子表 ID（必填）
- --field-id：字段 ID（必填，可多次指定）

### field query 命令

选项：
- --docid / --name：文档标识（二选一）
- --sheet-id：子表 ID（必填）
- --field-id：字段 ID（可选，可多次指定）
- --field-title：字段标题（可选，可多次指定）
- --offset：偏移量（可选，默认 0）
- --limit：分页大小（可选，默认 0 表示全部）

### field update 命令

选项：
- --docid / --name：文档标识（二选一）
- --sheet-id：子表 ID（必填）
- --field-id：字段 ID（必填）
- --title：新字段标题（可选）
- --type：字段类型（必填，必须为原类型）
- --property：字段属性 JSON（可选，可多次指定）

### record add 命令

选项：
- --docid / --name：文档标识（二选一）
- --sheet-id：子表 ID（必填）
- --key-type：key 类型（可选，默认 CELL_VALUE_KEY_TYPE_FIELD_TITLE）
- --record：记录数据（必填，JSON 字符串，可多次指定）

### record delete 命令

选项：
- --docid / --name：文档标识（二选一）
- --sheet-id：子表 ID（必填）
- --record-id：记录 ID（必填，可多次指定）

### record query 命令（重点：完整支持 filter_spec）

选项：
- --docid / --name：文档标识（二选一）
- --sheet-id：子表 ID（必填）
- --key-type：key 类型（可选，默认 CELL_VALUE_KEY_TYPE_FIELD_TITLE）
- --record-id：记录 ID（可选，可多次指定）
- --field-title：返回指定字段标题（可选，可多次指定）
- --field-id：返回指定字段 ID（可选，可多次指定）
- --sort：排序（可选，JSON 字符串，可多次指定）
- --offset：偏移量（可选，默认 0）
- --limit：分页大小（可选，默认 0 表示全部）
- --filter：过滤条件（可选，JSON 字符串，可多次指定）
- --filter-conjunction：过滤条件组合方式（可选，默认 CONJUNCTION_AND）

filter_spec 完整说明见 T10。

### record update 命令

选项：
- --docid / --name：文档标识（二选一）
- --sheet-id：子表 ID（必填）
- --key-type：key 类型（可选，默认 CELL_VALUE_KEY_TYPE_FIELD_TITLE）
- --record：更新记录数据（必填，JSON 字符串，可多次指定，需包含 record_id 和 values）

## 开发任务表

- [x] T1: API 层扩展 - 字段和记录 API 函数
- [x] T2: field 子命令组
- [x] T3: record 子命令组
- [x] T4: field add 命令
- [x] T5: field delete 命令
- [x] T6: field query 命令
- [x] T7: field update 命令
- [x] T8: record add 命令
- [x] T9: record delete 命令
- [x] T10: record query 命令（含 filter_spec 完整支持）
- [x] T11: record update 命令
- [x] T12: 测试用例

---

## T1: API 层扩展 - 字段和记录 API 函数

### 目标

在 api/doc.py 中添加字段和记录相关的 API 函数。

### 实现要求

1. 字段 API 端点
   - 添加字段：wedoc/smartsheet/add_fields
   - 删除字段：wedoc/smartsheet/delete_fields
   - 查询字段：wedoc/smartsheet/get_fields
   - 更新字段：wedoc/smartsheet/update_fields

2. 记录 API 端点
   - 添加记录：wedoc/smartsheet/add_records
   - 删除记录：wedoc/smartsheet/delete_records
   - 查询记录：wedoc/smartsheet/get_records
   - 更新记录：wedoc/smartsheet/update_records

3. 函数定义
   - add_fields(access_token, docid, sheet_id, fields, proxy_config) -> dict
   - delete_fields(access_token, docid, sheet_id, field_ids, proxy_config) -> None
   - get_fields(access_token, docid, sheet_id, field_ids, field_titles, offset, limit, proxy_config) -> dict
   - update_fields(access_token, docid, sheet_id, fields, proxy_config) -> dict
   - add_records(access_token, docid, sheet_id, key_type, records, proxy_config) -> dict
   - delete_records(access_token, docid, sheet_id, record_ids, proxy_config) -> None
   - get_records(access_token, docid, sheet_id, key_type, record_ids, field_titles, field_ids, sort, offset, limit, filter_spec, proxy_config) -> dict
   - update_records(access_token, docid, sheet_id, key_type, records, proxy_config) -> dict

### 修改文件
- src/wecom_cli/api/doc.py

---

## T2: field 子命令组

### 目标

创建 field 子命令组，作为 wecom doc smart sheet field 的入口。

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/field/__init__.py
- src/wecom_cli/commands/doc/smart/sheet/field/field_app.py

### 修改文件
- src/wecom_cli/commands/doc/smart/sheet/sheet_app.py

---

## T3: record 子命令组

### 目标

创建 record 子命令组，作为 wecom doc smart sheet record 的入口。

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/record/__init__.py
- src/wecom_cli/commands/doc/smart/sheet/record/record_app.py

### 修改文件
- src/wecom_cli/commands/doc/smart/sheet/sheet_app.py

---

## T4: field add 命令

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/field/add.py

---

## T5: field delete 命令

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/field/delete.py

---

## T6: field query 命令

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/field/query.py

---

## T7: field update 命令

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/field/update.py

---

## T8: record add 命令

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/record/add.py

---

## T9: record delete 命令

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/record/delete.py

---

## T10: record query 命令（含 filter_spec 完整支持）

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/record/query.py

### filter_spec 完整说明

filter_spec 用于对记录进行过滤查询，支持多种字段类型和操作符的组合筛选。

格式：通过 --filter 传入 JSON 字符串，每个 --filter 代表一个 Condition，多个 --filter 之间通过 --filter-conjunction 指定 AND 或 OR 组合。

Condition JSON 格式：
```json
{
  "field_id": "字段ID",
  "field_type": "字段类型",
  "operator": "操作符",
  "string_value": {"value": ["文本值"]},
  "number_value": {"value": 123},
  "bool_value": {"value": true},
  "user_value": {"value": ["成员ID"]},
  "date_time_value": {"type": "日期类型", "value": ["时间戳"]}
}
```

支持的字段类型（field_type）：
- FIELD_TYPE_TEXT / FIELD_TYPE_NUMBER / FIELD_TYPE_CHECKBOX / FIELD_TYPE_DATE_TIME
- FIELD_TYPE_IMAGE / FIELD_TYPE_ATTACHMENT / FIELD_TYPE_USER / FIELD_TYPE_URL
- FIELD_TYPE_SELECT / FIELD_TYPE_CREATED_USER / FIELD_TYPE_MODIFIED_USER
- FIELD_TYPE_CREATED_TIME / FIELD_TYPE_MODIFIED_TIME / FIELD_TYPE_PROGRESS
- FIELD_TYPE_PHONE_NUMBER / FIELD_TYPE_EMAIL / FIELD_TYPE_SINGLE_SELECT
- FIELD_TYPE_LOCATION

支持的操作符（operator）：
- OPERATOR_IS / OPERATOR_IS_NOT / OPERATOR_CONTAINS / OPERATOR_DOES_NOT_CONTAIN
- OPERATOR_IS_GREATER / OPERATOR_IS_GREATER_OR_EQUAL / OPERATOR_IS_LESS / OPERATOR_IS_LESS_OR_EQUAL
- OPERATOR_IS_EMPTY / OPERATOR_IS_NOT_EMPTY

Condition 值类型：
- string_value：文本、网址、电话、邮箱、地理位置、单选、多选等列类型使用，value 为字符串数组
- number_value：数字、进度列类型使用，value 为数字
- bool_value：复选框列类型使用，value 为布尔值
- user_value：人员、创建人、最后编辑人列类型使用，value 为成员 ID 数组
- date_time_value：日期、创建时间、最后编辑时间列类型使用

日期值类型（date_time_value.type）：
- DATE_TIME_TYPE_DETAIL_DATE：具体时间
- DATE_TIME_TYPE_TODAY / DATE_TIME_TYPE_TOMORROW / DATE_TIME_TYPE_YESTERDAY
- DATE_TIME_TYPE_CURRENT_WEEK / DATE_TIME_TYPE_LAST_WEEK / DATE_TIME_TYPE_CURRENT_MONTH
- DATE_TIME_TYPE_THE_PAST_7_DAYS / DATE_TIME_TYPE_THE_NEXT_7_DAYS
- DATE_TIME_TYPE_LAST_MONTH / DATE_TIME_TYPE_THE_PAST_30_DAYS / DATE_TIME_TYPE_THE_NEXT_30_DAYS

注意：filter_spec 不支持和 sort 一起使用。

---

## T11: record update 命令

### 新增文件
- src/wecom_cli/commands/doc/smart/sheet/record/update.py

---

## T12: 测试用例

### 新增文件
- tests/test_api_field_record.py：API 层测试
- tests/test_field_commands.py：字段命令测试
- tests/test_record_commands.py：记录命令测试
