# 认证与配置管理功能

## 背景

企业微信 API 调用需要 access_token 作为鉴权凭证。根据官方文档要求：

- access_token 有效期为 7200 秒（2 小时），需缓存，不能频繁调用 gettoken 接口
- 企业微信可能会提前使 token 失效，需实现重新获取逻辑
- 每个 secret 对应独立的 access_token

本功能为 wecom-cli 提供完整的配置管理和认证基础设施。

## 技术选型

| 项目 | 选择 | 说明 |
|------|------|------|
| 配置文件格式 | TOML | Python 3.12 内置 tomllib，写入使用 tomli_w |
| HTTP 客户端 | httpx | 现代同步/异步 HTTP 客户端 |
| Token 过期策略 | 提前 300 秒 | 过期前 5 分钟自动刷新 |

## 配置文件结构

路径：`~/.config/wecom-cli/config.toml`

```toml
[auth]
corpid = ""
corpsecret = ""

[cache]
access_token = ""
expires_at = 0
```

文件权限：600（仅用户可读写）。

## 开发任务表

- [x] T1: 配置文件管理模块 (config.py)
- [x] T2: API 基础客户端封装 (api/client.py)
- [x] T3: Token 缓存与刷新 (api/auth.py)
- [x] T4: config 命令组 (commands/config/)

---

## T1: 配置文件管理模块 (config.py)

### 目标

提供配置文件的读写能力，管理配置目录和文件。

### 实现要求

1. **配置目录管理**
   - 使用 `pathlib.Path` 和 `os` 模块确定跨平台配置目录
   - Linux/macOS: `~/.config/wecom-cli/`
   - 目录不存在时自动创建
   - 配置文件不存在时返回默认配置

2. **配置读写**
   - 读取：使用 `tomllib`（Python 3.12 内置）解析 TOML
   - 写入：使用 `tomli_w` 序列化 TOML
   - 提供 `get_config()` 和 `save_config(config)` 函数
   - 配置文件权限设为 600

3. **数据模型**
   - 使用 dataclass 定义配置结构：
     - `AuthConfig(corpid: str, corpsecret: str)`
     - `CacheConfig(access_token: str, expires_at: int)`
     - `AppConfig(auth: AuthConfig, cache: CacheConfig)`

4. **验证**
   - 保存前验证 corpid 和 corpsecret 非空
   - 提供默认空配置生成

### 新增文件
- `src/wecom_cli/config.py`

### 新增依赖
- `tomli_w>=1.0.0`（TOML 写入）

---

## T2: API 基础客户端封装 (api/client.py)

### 目标

封装通用的 HTTP 请求逻辑，处理鉴权注入、错误重试和响应解析。

### 实现要求

1. **HTTP 客户端**
   - 使用 `httpx.Client` 作为同步 HTTP 客户端
   - 基础 URL: `https://qyapi.weixin.qq.com/cgi-bin/`
   - 使用 context manager 管理连接生命周期

2. **鉴权注入**
   - 每次请求自动附加 `access_token` 参数
   - Token 过期时自动刷新后重试

3. **错误处理**
   - 解析企业微信返回的 errcode
   - errcode=0 表示成功
   - errcode=40014 或 42001（token 失效）时自动刷新 token 并重试
   - 其他错误码抛出明确的异常信息

4. **异常定义**
   - `WeComAPIError(errcode, errmsg)` - API 调用错误
   - `WeComAuthError(errcode, errmsg)` - 认证相关错误

5. **请求方法**
   - `get(path, params)` - GET 请求
   - `post(path, json_data)` - POST 请求

### 新增文件
- `src/wecom_cli/api/__init__.py`
- `src/wecom_cli/api/client.py`

### 新增依赖
- `httpx>=0.27.0`

---

## T3: Token 缓存与刷新 (api/auth.py)

### 目标

实现 access_token 的获取、缓存和自动刷新逻辑。

### 实现要求

1. **Token 获取逻辑**
   - API: `GET https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=ID&corpsecret=SECRET`
   - 返回：`{"errcode": 0, "access_token": "xxx", "expires_in": 7200}`

2. **缓存机制**
   - 将 token 和过期时间写入配置文件的 `[cache]` 段
   - 过期时间 = 当前时间 + expires_in（Unix timestamp）

3. **过期判断**
   - 当前时间 >= expires_at - 300 时视为过期（提前 5 分钟）
   - 过期时自动调用 API 获取新 token

4. **核心函数**
   - `get_access_token() -> str`：获取有效 token，自动处理缓存和刷新
   - `refresh_token() -> str`：强制刷新 token（忽略缓存）
   - `is_token_valid() -> bool`：检查当前缓存 token 是否有效

5. **失效重试**
   - 当 API 返回 token 无效错误码时，自动清除缓存并重新获取
   - 最多重试 1 次，避免死循环

### 新增文件
- `src/wecom_cli/api/auth.py`

---

## T4: config 命令组 (commands/config/)

### 目标

提供 `wecom config` 子命令组，让用户管理配置和查看 token 状态。

### 实现要求

1. **命令注册**
   - 在 `cli.py` 中注册 config 子命令组
   - 命令风格与现有 doc 命令保持一致

2. **子命令列表**

   | 命令 | 说明 |
   |------|------|
   | `wecom config init` | 初始化配置文件（交互式引导输入 corpid 和 corpsecret） |
   | `wecom config set` | 设置配置项，`--corpid` 和 `--corpsecret` 选项 |
   | `wecom config show` | 显示当前配置（corpsecret 脱敏显示） |
   | `wecom config token` | 显示当前 token 状态（是否有效、过期时间） |

3. **安全要求**
   - `show` 命令中 corpsecret 只显示前 4 位 + `****`
   - `token` 命令中 access_token 只显示前 8 位 + `...`

4. **错误处理**
   - 配置文件不存在时提示用户运行 `wecom config init`
   - 配置项缺失时给出明确提示

### 新增文件
- `src/wecom_cli/commands/config/__init__.py`
- `src/wecom_cli/commands/config/config_app.py`

### 修改文件
- `src/wecom_cli/cli.py`（注册 config 命令组）
