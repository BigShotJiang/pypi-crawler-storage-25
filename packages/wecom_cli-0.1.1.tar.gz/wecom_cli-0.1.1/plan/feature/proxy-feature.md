# 代理功能设计文档

**日期**: 2026-04-21
**主题**: 添加 HTTP/HTTPS 代理支持
**状态**: 已批准

## 背景

企业微信 API 调用需要从特定可信 IP 访问。用户已在服务器配置了正向代理，需要在内网环境中通过代理调用企业微信 API。当前项目使用 httpx 进行网络请求，httpx 原生支持代理配置。

## 需求

1. 支持配置 HTTP 和 HTTPS 代理地址
2. 代理配置保存在配置文件中（TOML 格式）
3. 代理为可选配置，未配置时直连企微 API
4. 提供命令行工具设置和查看代理配置
5. 所有 API 调用（包括 token 刷新）都应使用相同的代理配置

## 设计方案

### 1. 配置数据结构

在 `config.py` 中添加 `ProxyConfig` 数据类：

```python
@dataclass
class ProxyConfig:
    http_url: str = ""
    https_url: str = ""
```

在 `AppConfig` 中添加 `proxy` 字段：

```python
@dataclass
class AppConfig:
    auth: AuthConfig = field(default_factory=AuthConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)
    proxy: ProxyConfig = field(default_factory=ProxyConfig)
```

配置文件格式：

```toml
[auth]
corpid = "..."
corpsecret = "..."

[cache]
access_token = "..."
expires_at = 1234567890

[proxy]
http_url = "http://proxy.example.com:8080"
https_url = "https://proxy.example.com:8443"
```

### 2. Transport 创建逻辑

在 `api/client.py` 中添加辅助函数创建带代理的 transport：

```python
def _create_transport(proxy_config: ProxyConfig | None = None) -> httpx.BaseTransport | None:
    if not proxy_config or (not proxy_config.http_url and not proxy_config.https_url):
        return None

    proxies = {}
    if proxy_config.http_url:
        if not proxy_config.http_url.startswith(("http://", "https://")):
            raise ValueError(f"无效的 HTTP 代理 URL: {proxy_config.http_url}")
        proxies["http://"] = proxy_config.http_url
    if proxy_config.https_url:
        if not proxy_config.https_url.startswith(("http://", "https://")):
            raise ValueError(f"无效的 HTTPS 代理 URL: {proxy_config.https_url}")
        proxies["https://"] = proxy_config.https_url

    return httpx.HTTPTransport(proxy=proxies)
```

### 3. WeComClient 集成代理

修改 `WeComClient.__init__` 支持代理配置：

```python
def __init__(
    self,
    access_token: str,
    proxy_config: ProxyConfig | None = None,
    transport: httpx.BaseTransport | None = None,
) -> None:
    self._access_token = access_token
    if transport is None:
        transport = _create_transport(proxy_config)
    self._client = httpx.Client(
        base_url=BASE_URL,
        transport=transport,
    )
```

### 4. auth.py 集成代理

修改 `refresh_token` 和 `get_access_token` 使用代理：

```python
def refresh_token(proxy_config: ProxyConfig | None = None) -> str:
    config = get_config()
    transport = _create_transport(proxy_config)
    client = httpx.Client(
        base_url="https://qyapi.weixin.qq.com/cgi-bin/",
        transport=transport,
    )
    resp = client.get(
        "gettoken",
        params={"corpid": config.auth.corpid, "corpsecret": config.auth.corpsecret},
    )
    data = resp.json()
    if data.get("errcode", 0) != 0:
        raise RuntimeError(
            f"Failed to get access_token: [{data.get('errcode')}] {data.get('errmsg')}"
        )
    config.cache.access_token = data["access_token"]
    config.cache.expires_at = int(time.time()) + data["expires_in"]
    save_config(config)
    return config.cache.access_token

def get_access_token() -> str:
    if is_token_valid():
        return get_config().cache.access_token
    config = get_config()
    return refresh_token(proxy_config=config.proxy)
```

### 5. 配置文件读写更新

修改 `get_config()` 读取代理配置：

```python
def get_config() -> AppConfig:
    path = get_config_path()
    if not path.exists():
        return default_config()
    with open(path, "rb") as f:
        data = tomllib.load(f)
    auth_data = data.get("auth", {})
    cache_data = data.get("cache", {})
    proxy_data = data.get("proxy", {})
    return AppConfig(
        auth=AuthConfig(
            corpid=auth_data.get("corpid", ""),
            corpsecret=auth_data.get("corpsecret", ""),
        ),
        cache=CacheConfig(
            access_token=cache_data.get("access_token", ""),
            expires_at=cache_data.get("expires_at", 0),
        ),
        proxy=ProxyConfig(
            http_url=proxy_data.get("http_url", ""),
            https_url=proxy_data.get("https_url", ""),
        ),
    )
```

修改 `save_config()` 保存代理配置：

```python
def save_config(config: AppConfig) -> None:
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "auth": {
            "corpid": config.auth.corpid,
            "corpsecret": config.auth.corpsecret,
        },
        "cache": {
            "access_token": config.cache.access_token,
            "expires_at": config.cache.expires_at,
        },
        "proxy": {
            "http_url": config.proxy.http_url,
            "https_url": config.proxy.https_url,
        },
    }
    with open(path, "wb") as f:
        tomli_w.dump(data, f)
    path.chmod(stat.S_IRUSR | stat.S_IWUSR)
```

### 6. 配置命令

在 `commands/config/config_app.py` 中添加代理设置命令：

```python
@config_app.command()
def proxy(
    http_url: str = typer.Option("", "--http", "-h", help="HTTP 代理地址"),
    https_url: str = typer.Option("", "--https", "-s", help="HTTPS 代理地址"),
):
    """设置或查看代理配置"""
    config = get_config()
    if not http_url and not https_url:
        console.print("[yellow]当前代理配置:[/yellow]")
        console.print(f"  HTTP:  {config.proxy.http_url or '（未配置）'}")
        console.print(f"  HTTPS: {config.proxy.https_url or '（未配置）'}")
        return

    config.proxy.http_url = http_url
    config.proxy.https_url = https_url
    save_config(config)
    console.print("[bold green]✓ 代理配置已更新[/bold green]")
```

### 7. API 调用层集成

所有使用 `WeComClient` 的地方传递代理配置：

```python
from wecom_cli.api.auth import get_access_token
from wecom_cli.api.client import WeComClient
from wecom_cli.config import get_config

def example_api_call():
    config = get_config()
    access_token = get_access_token()
    client = WeComClient(
        access_token=access_token,
        proxy_config=config.proxy
    )
    # ... 使用 client 调用 API
```

## 开发任务表

### 任务 0: 编写设计文档

**状态**: 已完成

**任务详情**:
- 已完成代理功能的设计文档编写
- 设计文档包含了完整的技术方案和实现细节
- 设计文档已提交到 git 仓库

---

### 任务 1: 添加 ProxyConfig 数据类

**状态**: 已完成

**任务详情**:
- 在 `src/wecom_cli/config.py` 中添加 `ProxyConfig` 数据类
- `ProxyConfig` 包含两个字段：`http_url: str = ""` 和 `https_url: str = ""`
- 在 `AppConfig` 数据类中添加 `proxy: ProxyConfig = field(default_factory=ProxyConfig)` 字段
- 修改 `default_config()` 函数，确保返回的 `AppConfig` 包含空的 `ProxyConfig`
- 修改 `get_config()` 和 `save_config()` 支持代理配置的读写
- 添加了 5 个测试用例覆盖代理配置功能

**验收标准**:
- `ProxyConfig` 类定义正确
- `AppConfig.proxy` 字段添加成功
- 默认配置包含空的代理配置
- 配置文件可以正确读取和保存代理配置
- 所有测试通过

---

### 任务 2: 实现 Transport 创建逻辑

**状态**: 已完成

**任务详情**:
- 在 `src/wecom_cli/api/client.py` 中添加 `_create_proxy_url` 和 `_create_transport` 函数
- `_create_proxy_url` 函数根据代理配置返回代理 URL（优先使用 HTTPS 代理）
- `_create_transport` 函数根据代理配置返回 transport 或 `None`
- 验证 URL 必须以 `http://` 或 `https://` 开头，否则抛出 `ValueError`
- 添加了 8 个测试用例覆盖代理 URL 创建逻辑

**验收标准**:
- 函数在无代理配置时返回 `None`
- 函数在有代理配置时返回正确的代理 URL
- 优先使用 HTTPS 代理，其次使用 HTTP 代理
- 无效 URL 抛出 `ValueError` 异常
- 所有测试通过

---

### 任务 3: 修改 WeComClient 集成代理

**状态**: 已完成

**任务详情**:
- 修改 `WeComClient.__init__` 方法签名，添加 `proxy_config: ProxyConfig | None = None` 参数
- 修改初始化逻辑：如果 `transport` 为 `None`，则使用代理配置创建 `httpx.Client`
- 保持向后兼容性，`transport` 参数优先级高于 `proxy_config`
- 添加了 3 个测试用例验证 WeComClient 使用代理配置

**验收标准**:
- `WeComClient` 支持通过 `proxy_config` 参数传递代理配置
- 未传递任何参数时，`WeComClient` 使用默认直连
- 传递 `transport` 参数时，优先使用自定义 transport
- 所有测试通过

---

### 任务 4: 修改 auth.py 支持代理

**状态**: 已完成

**任务详情**:
- 修改 `refresh_token` 函数签名，添加 `proxy_config: ProxyConfig | None = None` 参数
- 在函数内使用 `_create_proxy_url(proxy_config)` 创建代理 URL
- 修改 `get_access_token` 函数，调用 `refresh_token` 时传递 `config.proxy`
- 确保从 `wecom_cli.api.client` 导入 `_create_proxy_url` 函数
- 添加了 2 个测试用例验证代理配置的使用

**验收标准**:
- `refresh_token` 支持通过 `proxy_config` 参数使用代理
- `get_access_token` 自动从配置文件读取代理配置并传递给 `refresh_token`
- Token 刷新过程使用正确的代理配置
- 所有测试通过

---

### 任务 5: 更新配置文件读写

**状态**: 已完成

**任务详情**:
- 修改 `get_config()` 函数：
  - 读取配置文件中的 `proxy` 节点
  - 解析 `http_url` 和 `https_url` 字段
- 修改 `save_config()` 函数：
  - 在保存的字典中添加 `proxy` 节点
  - 保存 `http_url` 和 `https_url` 字段
- 这个任务在任务 1 中已经完成

**验收标准**:
- 配置文件可以正确读取代理配置
- 配置文件可以正确保存代理配置
- 旧的配置文件（无 proxy 节点）可以正常读取，代理配置为空
- 所有测试通过
  - 创建 `ProxyConfig` 实例并传递给 `AppConfig`
- 修改 `save_config()` 函数：
  - 在保存的字典中添加 `proxy` 节点
  - 保存 `http_url` 和 `https_url` 字段
- 更新 `get_config()` 中的导入，确保可以正确导入 `ProxyConfig`

**验收标准**:
- 配置文件可以正确读取代理配置
- 配置文件可以正确保存代理配置
- 旧的配置文件（无 proxy 节点）可以正常读取，代理配置为空

---

### 任务 6: 添加代理配置命令

**状态**: 已完成

**任务详情**:
- 在 `src/wecom_cli/commands/config/config_app.py` 中添加 `proxy` 命令
- 命令参数：
  - `--http` / `-h`: HTTP 代理地址，可选
  - `--https` / `-s`: HTTPS 代理地址，可选
- 命令逻辑：
  - 如果两个参数都为 None，显示当前代理配置
  - 否则更新代理配置并保存到配置文件
  - 使用 `rich.console.Console` 输出友好的提示信息
- 命令帮助文本：`设置或查看代理配置`
- 添加了 6 个测试用例验证代理配置命令

**验收标准**:
- `wecom config proxy` 显示当前代理配置
- `wecom config proxy --http http://proxy.com:8080` 设置 HTTP 代理
- `wecom config proxy --https https://proxy.com:8443` 设置 HTTPS 代理
- `wecom config proxy --http xxx --https yyy` 同时设置两个代理
- 所有测试通过

---

### 任务 7: 添加代理功能测试

**状态**: 已完成

**任务详情**:
- 在 `tests/test_config.py` 中添加测试：
  - 测试 `ProxyConfig` 序列化和反序列化
  - 测试包含代理配置的完整配置读写
- 在 `tests/test_client.py` 中添加测试：
  - 测试 `_create_proxy_url` 在无代理时返回 `None`
  - 测试 `_create_proxy_url` 创建正确的代理 URL
  - 测试 `_create_proxy_url` 对无效 URL 抛出 `ValueError`
  - 测试 `WeComClient` 使用代理配置正确初始化
- 在 `tests/test_auth.py` 中添加测试：
  - Mock `httpx.Client` 验证 `refresh_token` 使用代理配置
- 在 `tests/test_config_commands.py` 中添加测试：
  - 测试 `proxy` 命令设置和显示配置

**验收标准**:
- 所有测试用例通过（共 57 个测试）
- 测试覆盖率达到要求
- 使用 pytest 运行测试全部通过

---

### 任务 8: 更新 README.md

**状态**: 已完成

**任务详情**:
- 在 `README.md` 中添加代理配置说明章节
- 说明如何使用 `wecom config proxy` 命令配置代理
- 提供配置示例和代理 URL 格式说明
- 说明代理是可选配置，未配置时直连企微 API
- 添加了代理配置的注意事项

**验收标准**:
- README.md 包含清晰的代理配置说明
- 提供了完整的命令示例
- 用户能够根据文档成功配置代理

---

### 任务 9: 更新 structs.md

**状态**: 已完成

**任务详情**:
- 在 `structs.md` 中更新 `config.py` 模块描述，说明包含代理配置
- 更新 `api/client.py` 模块描述，说明支持代理配置
- 更新 `api/auth.py` 模块描述，说明 token 刷新支持代理
- 更新 `commands/config/config_app.py` 模块描述，说明包含 proxy 命令
- 更新测试统计信息
- 更新模块依赖关系，添加代理配置说明
- 确保文档与实际代码结构一致

**验收标准**:
- `structs.md` 准确反映项目的最新结构
- 代理相关的模块和功能都有对应的描述
- 文档格式与其他部分一致

## 测试策略

### config.py 测试

- 测试 `ProxyConfig` 的序列化和反序列化
- 测试包含代理配置的完整配置读写

### api/client.py 测试

- 测试 `_create_transport` 在无代理时返回 `None`
- 测试 `_create_transport` 创建正确的代理配置
- 测试 `_create_transport` 对无效 URL 抛出 `ValueError`
- 测试 `WeComClient` 使用代理配置正确初始化

### api/auth.py 测试

- 测试 `refresh_token` 使用代理配置
- Mock `httpx.Client` 验证代理参数正确传递

### config 命令测试

- 测试 `wecom config proxy --http` 设置 HTTP 代理
- 测试 `wecom config proxy --https` 设置 HTTPS 代理
- 测试 `wecom config proxy` 显示当前配置

## 错误处理

- 无效的代理 URL 格式：抛出 `ValueError` 异常
- 代理连接失败：由 httpx 自动处理，抛出 `httpx.HTTPError`

## 向后兼容性

- 保持现有 API 兼容，`WeComClient` 的 `transport` 参数优先
- 未配置代理时自动直连，不影响现有功能
- 现有配置文件可以正常读取，代理配置为空时使用默认值
