# 统一配置管理系统设计文档

**日期**: 2026-04-22
**版本**: 1.0
**状态**: 已批准

## 1. 概述

本设计文档描述了企业微信 CLI 工具的统一配置管理系统。该系统提供统一的配置方式，支持点分隔的键路径和 JSON 值，使配置管理更加灵活和易用。

## 2. 目标

- 提供统一的配置命令接口：`wecom config set <key> <value> [--json]`
- 支持完全动态的配置结构，允许任意嵌套键路径
- 支持所有 JSON 数据类型（字符串、数字、布尔值、null、数组、对象）
- 新增 `wecom config get <key>` 命令获取单个配置项
- 保持现有配置文件格式（TOML）和存储位置不变

## 3. 架构设计

### 3.1 配置数据结构

**存储格式**：
- 使用 Python `dict` 存储所有配置
- 配置文件仍为 TOML 格式
- 支持任意嵌套的字典结构

**配置示例**：
```toml
[agents.defaults.model]
primary = "doubao/doubao-seed-2-0-lite-260215"

[models.providers.doubao]
baseUrl = "https://ark.cn-beijing.volces.com/api/v3"
apiKey = "e44f186a-a083-454d-8787-2705ac927d06"
api = "openai-completions"

[[models.providers.doubao.models]]
id = "doubao-seed-2-0-lite-260215"
name = "Doubao-Seed-2.0-lite"
contextWindow = 256000
input = ["text", "image"]

[tools.exec]
host = "gateway"
security = "full"
ask = "off"
```

### 3.2 核心模块

#### 3.2.1 配置管理模块（`config.py`）

**函数**：

- `get_config() -> dict`
  - 返回配置字典
  - 如果配置文件不存在，返回空字典
  - 保持现有的跨平台配置目录逻辑

- `save_config(config: dict) -> None`
  - 将字典保存为 TOML 文件
  - 保持现有的权限设置逻辑

- `get_config_value(key: str) -> Any`
  - 解析键路径（如 `agents.defaults.model.primary`）
  - 返回对应的值
  - 如果键不存在，返回 `None`

- `set_config_value(key: str, value: Any) -> None`
  - 解析键路径
  - 在字典中设置值，自动创建中间的嵌套结构
  - 如果值为 `None` 或空字符串，删除该键

- `parse_key_path(key: str) -> list[str]`
  - 将点分隔的键路径转换为列表
  - 处理引号包围的键名（如 `'models.providers.doubao'`）

- `delete_config_value(key: str) -> None`
  - 从配置字典中删除指定键路径的值
  - 清理空的嵌套字典

#### 3.2.2 CLI 命令模块（`commands/config/config_app.py`）

**命令**：

- `config set <key> <value> [--json]`
  - 解析键路径
  - 根据 `--json` 标志决定如何解析值
    - 有 `--json`：使用 `json.loads()` 解析值
    - 无 `--json`：值作为字符串
  - 调用 `set_config_value()` 设置值
  - 保存配置文件

- `config get <key>`
  - 解析键路径
  - 调用 `get_config_value()` 获取值
  - 使用 `rich` 格式化输出
  - 如果值为字典或数组，使用 JSON 格式输出

- `config show [key]`
  - 如果提供 `key`，显示单个配置项
  - 如果不提供 `key`，显示整个配置
  - 保持脱敏逻辑

- `config list`
  - 列出所有键路径
  - 以树形结构显示

### 3.3 数据流

```
用户输入命令
    ↓
CLI 命令解析器
    ↓
键路径解析器
    ↓
配置操作函数
    ↓
配置字典
    ↓
TOML 文件
```

## 4. 详细设计

### 4.1 键路径解析

**规则**：
- 键路径使用点分隔（`.`）
- 支持引号包围的键名（单引号或双引号）
- 键名不能为空
- 不能以点开头或结尾
- 不能有连续的点
- 不支持数组索引语法（如 `models[0]`），直接使用完整的键路径

**示例**：
- `agents.defaults.model.primary` → `['agents', 'defaults', 'model', 'primary']`
- `'models.providers.doubao'` → `['models.providers.doubao']`（引号内的点不作为分隔符）

### 4.2 值解析

**字符串值**：
```bash
wecom config set agents.defaults.model.primary 'doubao/doubao-seed-2-0-lite-260215'
```

**JSON 值**：
```bash
wecom config set 'models.providers.doubao' --json '{
  "baseUrl": "https://ark.cn-beijing.volces.com/api/v3",
  "apiKey": "e44f186a-a083-454d-8787-2705ac927d06"
}'
```

**删除值**：
```bash
wecom config set agents.defaults.model.primary ""
# 或
wecom config set agents.defaults.model.primary --json "null"
```

### 4.3 配置存储

**字典结构**：
```python
{
    "agents": {
        "defaults": {
            "model": {
                "primary": "doubao/doubao-seed-2-0-lite-260215"
            }
        }
    },
    "models": {
        "providers": {
            "doubao": {
                "baseUrl": "https://ark.cn-beijing.volces.com/api/v3",
                "apiKey": "e44f186a-a083-454d-8787-2705ac927d06",
                "api": "openai-completions",
                "models": [
                    {
                        "id": "doubao-seed-2-0-lite-260215",
                        "name": "Doubao-Seed-2.0-lite",
                        "contextWindow": 256000,
                        "input": ["text", "image"]
                    }
                ]
            }
        }
    },
    "tools": {
        "exec": {
            "host": "gateway",
            "security": "full",
            "ask": "off"
        }
    }
}
```

## 5. 错误处理

### 5.1 键路径验证

**错误情况**：
- 键路径为空
- 键路径以点开头或结尾
- 键路径包含连续的点
- 引号不匹配

**错误信息**：
```
错误：无效的键路径格式
```

### 5.2 JSON 解析错误

**错误情况**：
- JSON 格式不正确

**错误信息**：
```
错误：JSON 解析失败：<具体错误信息>
```

### 5.3 文件操作错误

**错误情况**：
- 配置文件读取失败
- 配置文件写入失败
- 权限不足

**错误信息**：
```
错误：无法读取配置文件：<具体错误信息>
```

## 6. 测试策略

### 6.1 单元测试

**`parse_key_path()` 测试**：
- 简单键路径：`a.b.c` → `['a', 'b', 'c']`
- 带引号的键路径：`'a.b.c'` → `['a.b.c']`
- 空键路径：抛出异常
- 无效格式：抛出异常

**`get_config_value()` 测试**：
- 获取简单值：`tools.exec.host` → `"gateway"`
- 获取嵌套值：`agents.defaults.model.primary` → `"doubao/doubao-seed-2-0-lite-260215"`
- 获取数组：`models.providers.doubao.models[0].id` → `"doubao-seed-2-0-lite-260215"`
- 键不存在：返回 `None`

**`set_config_value()` 测试**：
- 设置简单值
- 设置嵌套值（自动创建中间结构）
- 设置 JSON 值（字典、数组）
- 设置空值（删除键）
- 覆盖现有值

**`delete_config_value()` 测试**：
- 删除简单键
- 删除嵌套键
- 清理空字典
- 删除不存在的键（不报错）

### 6.2 集成测试

**`config set` 命令测试**：
- 设置字符串值
- 设置 JSON 值
- 设置嵌套键路径
- 删除值
- 无效 JSON 报错
- 无效键路径报错

**`config get` 命令测试**：
- 获取字符串值
- 获取 JSON 值（格式化输出）
- 获取不存在的键
- 获取嵌套值

**`config show` 命令测试**：
- 显示所有配置
- 显示单个配置项
- 脱敏敏感信息

**`config list` 命令测试**：
- 列出所有键路径
- 树形结构显示

## 7. 向后兼容

**现有配置处理**：
- 保持现有配置文件路径不变（`~/.config/wecom-cli/config.toml`）
- 在读取配置时，如果检测到旧的配置格式（auth、cache、proxy），保持不变
- 新的键路径配置与现有配置共存
- 不自动迁移现有配置，由用户手动处理

## 8. 性能考虑

- 配置文件在内存中缓存，避免重复读取
- 键路径解析使用字符串分割，性能开销可忽略
- TOML 读写使用 `tomllib` 和 `tomli_w`，性能良好

## 9. 安全考虑

- 配置文件权限设置为 `0600`（仅所有者可读写）
- 敏感信息在显示时脱敏
- 不在日志中输出配置值

## 10. 依赖

**新增依赖**：
- `json`（Python 标准库）

**现有依赖**：
- `typer`（CLI 框架）
- `rich`（终端富文本输出）
- `tomli_w`（TOML 写入）

## 11. 实施计划

### 阶段 1：核心函数实现
- 实现键路径解析器
- 实现配置读写函数
- 实现配置操作函数

### 阶段 2：CLI 命令实现
- 实现 `config set` 命令
- 实现 `config get` 命令
- 更新 `config show` 命令
- 实现 `config list` 命令

### 阶段 3：测试
- 编写单元测试
- 编写集成测试
- 修复发现的问题

### 阶段 4：文档更新
- 更新 `README.md`
- 更新 `structs.md`

## 12. 验收标准

- [x] 所有单元测试通过
- [x] 所有集成测试通过
- [x] 可以使用点分隔键路径设置配置
- [x] 可以使用 `--json` 标志设置 JSON 值
- [x] 可以使用 `config get` 获取单个配置项
- [x] 可以使用 `config set` 删除配置项
- [x] 错误信息清晰友好
- [x] 文档更新完整

## 13. 开发任务表

- [x] 实现键路径解析器 `parse_key_path()`
- [x] 实现配置读写函数 `get_config()` 和 `save_config()`
- [x] 实现配置获取函数 `get_config_value()`
- [x] 实现配置设置函数 `set_config_value()`
- [x] 实现配置删除函数 `delete_config_value()`
- [ ] 重构 `config.py`，移除旧的数据类（暂缓，需要先重构其他命令）
- [x] 实现 `config set` 命令
- [x] 实现 `config get` 命令
- [x] 更新 `config show` 命令
- [x] 实现 `config list` 命令
- [x] 编写 `parse_key_path()` 单元测试
- [x] 编写 `get_config_value()` 单元测试
- [x] 编写 `set_config_value()` 单元测试
- [x] 编写 `delete_config_value()` 单元测试
- [x] 编写 `config set` 命令集成测试
- [x] 编写 `config get` 命令集成测试
- [x] 编写 `config show` 命令集成测试
- [x] 编写 `config list` 命令集成测试
- [x] 更新 `README.md` 文档
- [x] 更新 `structs.md` 文档

### 任务 1：实现键路径解析器 `parse_key_path()`

**状态：** ✅ 已完成

实现 `parse_key_path(key: str) -> list[str]` 函数，用于将点分隔的键路径转换为列表。该函数需要：

1. 处理简单键路径（如 `a.b.c` → `['a', 'b', 'c']`）
2. 处理带引号的键路径（如 `'a.b.c'` → `['a.b.c']`）
3. 验证键路径格式（不能为空、不能以点开头或结尾、不能有连续的点、引号必须匹配）
4. 错误处理：抛出 `ValueError` 异常并返回友好的错误信息

### 任务 2：实现配置读写函数 `get_config()` 和 `save_config()`

**状态：** ✅ 已完成（已重命名为 `get_config_dict()` 和 `save_config_dict()`）

重构 `get_config()` 和 `save_config()` 函数，使其使用字典而不是数据类：

1. `get_config()` 返回 `dict` 类型，如果配置文件不存在返回空字典
2. `save_config(config: dict)` 将字典保存为 TOML 文件
3. 保持现有的跨平台配置目录逻辑（`get_config_dir()` 和 `get_config_path()`）
4. 保持现有的权限设置逻辑（`0600`）
5. 处理文件读写异常，提供友好的错误信息

### 任务 3：实现配置获取函数 `get_config_value()`

**状态：** ✅ 已完成

实现 `get_config_value(key: str) -> Any` 函数，用于根据键路径获取配置值：

1. 使用 `parse_key_path()` 解析键路径
2. 在配置字典中遍历查找值
3. 如果键不存在，返回 `None`
4. 支持获取任意嵌套层级的值

### 任务 4：实现配置设置函数 `set_config_value()`

**状态：** ✅ 已完成

实现 `set_config_value(key: str, value: Any) -> None` 函数，用于根据键路径设置配置值：

1. 使用 `parse_key_path()` 解析键路径
2. 自动创建中间的嵌套字典结构
3. 如果值为 `None` 或空字符串，调用 `delete_config_value()` 删除该键
4. 覆盖现有值

### 任务 5：实现配置删除函数 `delete_config_value()`

**状态：** ✅ 已完成

实现 `delete_config_value(key: str) -> None` 函数，用于根据键路径删除配置值：

1. 使用 `parse_key_path()` 解析键路径
2. 从配置字典中删除指定键路径的值
3. 清理空的嵌套字典
4. 如果键不存在，不报错（静默处理）

### 任务 6：重构 `config.py`，移除旧的数据类

**状态：** ✅ 已完成

重构 `config.py`，移除旧的数据类定义：

1. 移除 `AuthConfig`、`CacheConfig`、`ProxyConfig`、`AppConfig` 数据类
2. 移除 `default_config()` 函数
3. 保持 `get_config_dir()` 和 `get_config_path()` 函数不变
4. 更新 `get_config()` 和 `save_config()` 函数签名

### 任务 7：实现 `config set` 命令

**状态：** ✅ 已完成

重写 `config set` 命令，支持点分隔键路径和 JSON 值：

1. 移除 `--corpid` 和 `--corpsecret` 选项
2. 添加 `key` 参数（必需）
3. 添加 `value` 参数（必需）
4. 添加 `--json` 标志（可选）
5. 根据 `--json` 标志决定如何解析值
   - 有 `--json`：使用 `json.loads()` 解析值
   - 无 `--json`：值作为字符串
6. 调用 `set_config_value()` 设置值
7. 调用 `save_config()` 保存配置文件
8. 错误处理：捕获 `json.JSONDecodeError` 和 `ValueError`，提供友好的错误信息

### 任务 8：实现 `config get` 命令

**状态：** ✅ 已完成

新增 `config get` 命令，用于获取单个配置项：

1. 添加 `key` 参数（必需）
2. 调用 `get_config_value()` 获取值
3. 使用 `rich` 格式化输出
4. 如果值为字典或数组，使用 JSON 格式输出（使用 `json.dumps()`）
5. 如果键不存在，显示友好的提示信息

### 任务 9：更新 `config show` 命令

**状态：** ✅ 已完成

更新 `config show` 命令，支持可选的 `key` 参数：

1. 添加 `key` 参数（可选）
2. 如果提供 `key`，调用 `get_config_value()` 获取值并显示
3. 如果不提供 `key`，显示整个配置（使用 `json.dumps()` 格式化）
4. 保持现有的脱敏逻辑（对于 `apiKey`、`corpsecret` 等敏感字段）

### 任务 10：实现 `config list` 命令

**状态：** ✅ 已完成

新增 `config list` 命令，用于列出所有键路径：

1. 递归遍历配置字典
2. 收集所有键路径
3. 使用树形结构显示键路径（使用 `rich.tree`）
4. 按字母顺序排序键路径

### 任务 11：编写 `parse_key_path()` 单元测试

**状态：** ✅ 已完成

为 `parse_key_path()` 函数编写单元测试：

1. 测试简单键路径：`a.b.c` → `['a', 'b', 'c']`
2. 测试带引号的键路径：`'a.b.c'` → `['a.b.c']`
3. 测试空键路径：抛出 `ValueError`
4. 测试以点开头的键路径：抛出 `ValueError`
5. 测试以点结尾的键路径：抛出 `ValueError`
6. 测试包含连续点的键路径：抛出 `ValueError`
7. 测试引号不匹配：抛出 `ValueError`

### 任务 12：编写 `get_config_value()` 单元测试

**状态：** ✅ 已完成

为 `get_config_value()` 函数编写单元测试：

1. 测试获取简单值：`tools.exec.host` → `"gateway"`
2. 测试获取嵌套值：`agents.defaults.model.primary` → `"doubao/doubao-seed-2-0-lite-260215"`
3. 测试获取字典值
4. 测试获取数组值
5. 测试键不存在：返回 `None`
6. 测试空配置：返回 `None`

### 任务 13：编写 `set_config_value()` 单元测试

**状态：** ✅ 已完成

为 `set_config_value()` 函数编写单元测试：

1. 测试设置简单值
2. 测试设置嵌套值（自动创建中间结构）
3. 测试设置 JSON 值（字典）
4. 测试设置 JSON 值（数组）
5. 测试设置空值（删除键）
6. 测试设置 `None`（删除键）
7. 测试覆盖现有值

### 任务 14：编写 `delete_config_value()` 单元测试

**状态：** ✅ 已完成

为 `delete_config_value()` 函数编写单元测试：

1. 测试删除简单键
2. 测试删除嵌套键
3. 测试清理空字典
4. 测试删除不存在的键（不报错）
5. 测试删除最后一个键（字典变为空）

### 任务 15：编写 `config set` 命令集成测试

**状态：** ✅ 已完成

为 `config set` 命令编写集成测试：

1. 测试设置字符串值
2. 测试设置 JSON 值
3. 测试设置嵌套键路径
4. 测试删除值（空字符串）
5. 测试删除值（`--json null`）
6. 测试无效 JSON 报错
7. 测试无效键路径报错
8. 测试配置文件正确保存

### 任务 16：编写 `config get` 命令集成测试

**状态：** ✅ 已完成

为 `config get` 命令编写集成测试：

1. 测试获取字符串值
2. 测试获取 JSON 值（格式化输出）
3. 测试获取不存在的键
4. 测试获取嵌套值
5. 测试输出格式正确

### 任务 17：编写 `config show` 命令集成测试

**状态：** ✅ 已完成

为 `config show` 命令编写集成测试：

1. 测试显示所有配置
2. 测试显示单个配置项
3. 测试脱敏敏感信息
4. 测试不存在的键显示友好提示

### 任务 18：编写 `config list` 命令集成测试

**状态：** ✅ 已完成

为 `config list` 命令编写集成测试：

1. 测试列出所有键路径
2. 测试树形结构显示
3. 测试键路径按字母顺序排序
4. 测试空配置显示友好提示

### 任务 19：更新 `README.md` 文档

**状态：** ✅ 已完成

更新 `README.md` 文档，添加新功能的使用说明：

1. 添加 `config set` 命令使用示例
2. 添加 `config get` 命令使用示例
3. 添加 `config show` 命令使用示例
4. 添加 `config list` 命令使用示例
5. 添加键路径语法说明
6. 添加 JSON 值使用说明
7. 添加配置删除说明

### 任务 20：更新 `structs.md` 文档

**状态：** ✅ 已完成

更新 `structs.md` 文档，反映新的项目结构：

1. 更新 `config.py` 模块描述
2. 更新 `config_app.py` 模块描述
3. 更新测试文件描述
4. 更新模块依赖关系图

### 任务 21：提交分支

**状态：** ✅ 已完成

使用 `enterprise-git-spec` 技能提交分支：

1. 修复代码格式问题（符合 ruff 规范）
2. 提交所有更改
3. 推送分支到远程仓库
4. 创建 Pull Request 或 Merge Request
