# 智能表格子表操作功能

## 背景

根据企业微信智能表格 API，我们需要提供子表的基本管理功能，包括：
- 添加子表
- 删除子表
- 更新子表（标题）
- 查询子表

重要特性：
- 子表操作需要指定文档 ID（docid）
- 支持 --docid 直接传入和 --name 通过注册表查找两种方式
- 子表 ID（sheet_id）在创建时生成，后续操作需要使用
- 添加子表时可以指定位置（index），不指定则添加到末尾

## 技术选型

| 项目 | 选择 | 说明 |
|------|------|------|
| HTTP 客户端 | httpx | 复用现有的 WeComClient |
| 命令框架 | typer | 复用现有的命令结构 |
| JSON 输出 | 与现有命令一致 | {"success": True, "data": {...}} |

## 命令设计

### 命令结构

```
wecom doc smart sheet add    # 添加子表
wecom doc smart sheet delete # 删除子表
wecom doc smart sheet update # 更新子表
wecom doc smart sheet query  # 查询子表
```

### add 命令

**选项：**
- `--docid`：文档 ID（与 --name 二选一）
- `--name`：文档名称（与 --docid 二选一，从注册表查找）
- `--title`：子表标题（必填）
- `--index`：子表位置（可选，默认添加到末尾）

**输出（JSON 模式）：**
```json
{
  "success": true,
  "data": {
    "sheet_id": "123abc",
    "title": "智能表",
    "index": 3
  }
}
```

### delete 命令

**选项：**
- `--docid`：文档 ID（与 --name 二选一）
- `--name`：文档名称（与 --docid 二选一，从注册表查找）
- `--sheet-id`：子表 ID（必填）

**输出（JSON 模式）：**
```json
{
  "success": true,
  "data": {
    "sheet_id": "123abc"
  }
}
```

### update 命令

**选项：**
- `--docid`：文档 ID（与 --name 二选一）
- `--name`：文档名称（与 --docid 二选一，从注册表查找）
- `--sheet-id`：子表 ID（必填）
- `--title`：新标题（必填）

**输出（JSON 模式）：**
```json
{
  "success": true,
  "data": {
    "sheet_id": "123abc",
    "title": "新标题"
  }
}
```

### query 命令

**选项：**
- `--docid`：文档 ID（与 --name 二选一）
- `--name`：文档名称（与 --docid 二选一，从注册表查找）
- `--sheet-id`：子表 ID（必填）

**输出（JSON 模式）：**
```json
{
  "success": true,
  "data": {
    "sheet_id": "123abc",
    "title": "智能表",
    "is_visible": true,
    "type": "smartsheet"
  }
}
```

## 开发任务表

- [x] T1: 智能表格 API 模块扩展 (api/doc.py)
- [x] T2: sheet 子命令组 (commands/doc/smart/sheet_app.py)
- [x] T3: sheet add 命令
- [x] T4: sheet delete 命令
- [x] T5: sheet update 命令
- [x] T6: sheet query 命令

---

## T1: 智能表格 API 模块扩展 (api/doc.py)

### 目标

在 `api/doc.py` 中添加子表相关的 API 函数。

### 实现要求

1. **API 端点**
   - 添加子表：`wedoc/smartsheet/add_sheet`
   - 删除子表：`wedoc/smartsheet/delete_sheet`
   - 更新子表：`wedoc/smartsheet/update_sheet`
   - 查询子表：`wedoc/smartsheet/get_sheet`

2. **函数定义**
   - `add_sheet(access_token, docid, title, index, proxy_config)` -> dict
   - `delete_sheet(access_token, docid, sheet_id, proxy_config)` -> None
   - `update_sheet(access_token, docid, sheet_id, title, proxy_config)` -> None
   - `get_sheet(access_token, docid, sheet_id, proxy_config)` -> dict

3. **参数说明**
   - `title`：子表标题（add_sheet, update_sheet）
   - `index`：子表位置（add_sheet，可选）
   - `sheet_id`：子表 ID（delete_sheet, update_sheet, get_sheet）

### 修改文件
- `src/wecom_cli/api/doc.py`

---

## T2: sheet 子命令组 (commands/doc/smart/sheet_app.py)

### 目标

创建 `sheet` 子命令组，作为 `wecom doc smart sheet` 的入口。

### 实现要求

1. **创建 typer.Typer 实例**
   - 使用 `help` 参数提供帮助信息

2. **注册子命令**
   - add
   - delete
   - update
   - query

3. **修改 smart_app.py**
   - 在 `smart_app` 中注册 `sheet_app` 作为子命令组

### 新增文件
- `src/wecom_cli/commands/doc/smart/sheet_app.py`

### 修改文件
- `src/wecom_cli/commands/doc/smart/smart_app.py`

---

## T3: sheet add 命令

### 目标

提供 `wecom doc smart sheet add` 命令，添加新的子表。

### 实现要求

1. **命令选项**
   - `--docid`：文档 ID（与 --name 二选一）
   - `--name`：文档名称（与 --docid 二选一）
   - `--title`：子表标题（必填）
   - `--index`：子表位置（可选，默认添加到末尾）

2. **功能流程**
   - 验证 --docid 或 --name 必须提供一个
   - 如果是 --name，从注册表获取 docid
   - 如果 docid 不存在，提示错误
   - 验证 --title 必填
   - 调用 add_sheet API 添加子表
   - 显示成功信息和返回的 sheet_id

3. **错误处理**
   - --docid 和 --name 都未提供时提示
   -- --docid 和 --name 同时提供时提示
   - --title 未提供时提示
   - API 调用失败时显示错误信息

### 新增文件
- `src/wecom_cli/commands/doc/smart/sheet/add.py`

### 修改文件
- `src/wecom_cli/commands/doc/smart/sheet_app.py`（注册 add 命令）

---

## T4: sheet delete 命令

### 目标

提供 `wecom doc smart sheet delete` 命令，删除指定的子表。

### 实现要求

1. **命令选项**
   - `--docid`：文档 ID（与 --name 二选一）
   - `--name`：文档名称（与 --docid 二选一）
   - `--sheet-id`：子表 ID（必填）

2. **功能流程**
   - 验证 --docid 或 --name 必须提供一个
   - 如果是 --name，从注册表获取 docid
   - 如果 docid 不存在，提示错误
   - 验证 --sheet-id 必填
   - 调用 delete_sheet API 删除子表
   - 显示删除成功信息

3. **错误处理**
   - --docid 和 --name 都未提供时提示
   - --docid 和 --name 同时提供时提示
   - --sheet-id 未提供时提示
   - API 调用失败时显示错误信息

### 新增文件
- `src/wecom_cli/commands/doc/smart/sheet/delete.py`

### 修改文件
- `src/wecom_cli/commands/doc/smart/sheet_app.py`（注册 delete 命令）

---

## T5: sheet update 命令

### 目标

提供 `wecom doc smart sheet update` 命令，更新子表标题。

### 实现要求

1. **命令选项**
   - `--docid`：文档 ID（与 --name 二选一）
   - `--name`：文档名称（与 --docid 二选一）
   - `--sheet-id`：子表 ID（必填）
   - `--title`：新标题（必填）

2. **功能流程**
   - 验证 --docid 或 --name 必须提供一个
   - 如果是 --name，从注册表获取 docid
   - 如果 docid 不存在，提示错误
   - 验证 --sheet-id 和 --title 必填
   - 调用 update_sheet API 更新子表
   - 显示更新成功信息

3. **错误处理**
   - --docid 和 --name 都未提供时提示
   - --docid 和 --name 同时提供时提示
   - --sheet-id 或 --title 未提供时提示
   - API 调用失败时显示错误信息

### 新增文件
- `src/wecom_cli/commands/doc/smart/sheet/update.py`

### 修改文件
- `src/wecom_cli/commands/doc/smart/sheet_app.py`（注册 update 命令）

---

## T6: sheet query 命令

### 目标

提供 `wecom doc smart sheet query` 命令，查询指定子表的信息。

### 实现要求

1. **命令选项**
   - `--docid`：文档 ID（与 --name 二选一）
   - `--name`：文档名称（与 --docid 二选一）
   - `--sheet-id`：子表 ID（必填）

2. **功能流程**
   - 验证 --docid 或 --name 必须提供一个
   - 如果是 --name，从注册表获取 docid
   - 如果 docid 不存在，提示错误
   - 验证 --sheet-id 必填
   - 调用 get_sheet API 查询子表
   - 显示子表信息（sheet_id, title, is_visible, type）

3. **错误处理**
   - --docid 和 --name 都未提供时提示
   - --docid 和 --name 同时提供时提示
   - --sheet-id 未提供时提示
   - API 调用失败时显示错误信息

### 新增文件
- `src/wecom_cli/commands/doc/smart/sheet/query.py`

### 修改文件
- `src/wecom_cli/commands/doc/smart/sheet_app.py`（注册 query 命令）
