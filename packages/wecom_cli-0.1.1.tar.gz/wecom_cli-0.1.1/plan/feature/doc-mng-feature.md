# 文档管理功能

## 背景

根据企业微信文档 API，我们需要提供文档的基本管理功能，包括：
- 新建文档、表格和智能表格
- 删除文档
- 重命名文档
- 获取分享链接

重要特性：
- 创建文档时会返回 docid，但该 docid **仅在创建时返回**，需要妥善保存
- 应用只能操作自己创建的文档
- 文档位置由 spaceid（空间ID）和 fatherid（父目录ID）确定

## 技术选型

| 项目 | 选择 | 说明 |
|------|------|------|
| 文档注册表 | 配置文件 `[doc_registry]` 段 | 存储文档名称与 docid 的映射关系 |
| HTTP 客户端 | httpx | 复用现有的 WeComClient |

## 配置文件结构

路径：`~/.config/wecom-cli/config.toml`

```toml
[doc_registry]
"文档名称1" = "DOCID1"
"文档名称2" = "DOCID2"
```

## 开发任务表

- [x] T1: 文档注册表管理 (doc_registry.py)
- [x] T2: 文档 API 模块 (api/doc.py)
- [x] T3: doc add 命令
- [x] T4: doc delete 命令
- [x] T5: doc rename 命令
- [x] T6: doc share 命令

---

## T1: 文档注册表管理 (doc_registry.py)

### 目标

管理文档名称与 docid 的映射关系，支持通过文档名称查找 docid。

### 实现要求

1. **配置文件段**
   - 使用 `[doc_registry]` 段存储映射关系
   - 格式：`"文档名称" = "docid"`

2. **核心函数**
   - `register_doc(name: str, docid: str) -> None`：注册新文档
   - `get_docid(name: str) -> str | None`：通过名称获取 docid
   - `unregister_doc(name: str) -> None`：删除文档注册
   - `list_docs() -> dict[str, str]`：列出所有已注册文档

3. **冲突处理**
   - 如果文档名称已存在，提示用户是否覆盖

### 新增文件
- `src/wecom_cli/doc_registry.py`

---

## T2: 文档 API 模块 (api/doc.py)

### 目标

封装文档相关的 API 调用。

### 实现要求

1. **API 端点**
   - 创建文档：`wedoc/create_doc`
   - 删除文档：`wedoc/del_doc`
   - 重命名文档：`wedoc/rename_doc`
   - 分享文档：`wedoc/doc_share`

2. **函数定义**
   - `create_doc(doc_type: int, doc_name: str, spaceid: str | None, fatherid: str | None, admin_users: list[str] | None) -> dict[str, Any]`
   - `delete_doc(docid: str) -> None`
   - `rename_doc(docid: str, new_name: str) -> None`
   - `share_doc(docid: str) -> str`

3. **文档类型常量**
   - `DOC_TYPE_DOC = 3`：文档
   - `DOC_TYPE_SHEET = 4`：表格
   - `DOC_TYPE_SMART = 10`：智能表格

### 新增文件
- `src/wecom_cli/api/doc.py`

---

## T3: doc add 命令

### 目标

提供 `wecom doc add` 命令，支持创建文档、表格和智能表格。

### 实现要求

1. **命令选项**
   - `--name`：文档名称（必填）
   - `--type`：文档类型，doc/sheet/smart（默认：doc）
   - `--spaceid`：空间 ID（可选）
   - `--fatherid`：父目录 ID（可选，默认为 spaceid）

2. **功能流程**
   - 调用 create_doc API 创建文档
   - 提取返回的 docid 和 url
   - 将文档名称和 docid 注册到配置文件
   - 显示创建成功信息和访问链接

3. **错误处理**
   - 文档名称为空时提示
   - 创建失败时显示错误信息

### 新增文件
- `src/wecom_cli/commands/doc/add.py`

### 修改文件
- `src/wecom_cli/commands/doc/doc_app.py`（注册 add 命令）

---

## T4: doc delete 命令

### 目标

提供 `wecom doc delete` 命令，删除指定文档。

### 实现要求

1. **命令选项**
   - `--name`：文档名称（必填）

2. **功能流程**
   - 通过文档名称从注册表获取 docid
   - 如果 docid 不存在，提示文档未找到
   - 调用 delete_doc API 删除文档
   - 从注册表中移除文档记录
   - 显示删除成功信息

### 新增文件
- `src/wecom_cli/commands/doc/delete.py`

### 修改文件
- `src/wecom_cli/commands/doc/doc_app.py`（注册 delete 命令）

---

## T5: doc rename 命令

### 目标

提供 `wecom doc rename` 命令，重命名指定文档。

### 实现要求

1. **命令选项**
   - `--name`：原文档名称（必填）
   - `--new-name`：新文档名称（必填）

2. **功能流程**
   - 通过原名称从注册表获取 docid
   - 如果 docid 不存在，提示文档未找到
   - 调用 rename_doc API 重命名文档
   - 更新注册表中的文档名称（删除旧记录，添加新记录）
   - 显示重命名成功信息

### 新增文件
- `src/wecom_cli/commands/doc/rename.py`

### 修改文件
- `src/wecom_cli/commands/doc/doc_app.py`（注册 rename 命令）

---

## T6: doc share 命令

### 目标

提供 `wecom doc share` 命令，获取文档分享链接。

### 实现要求

1. **命令选项**
   - `--name`：文档名称（必填）

2. **功能流程**
   - 通过文档名称从注册表获取 docid
   - 如果 docid 不存在，提示文档未找到
   - 调用 share_doc API 获取分享链接
   - 显示分享链接

### 新增文件
- `src/wecom_cli/commands/doc/share.py`

### 修改文件
- `src/wecom_cli/commands/doc/doc_app.py`（注册 share 命令）
