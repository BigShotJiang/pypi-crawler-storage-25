# Bugfix: 测试 fixture 删除用户 proxy 配置

## 问题描述

`test_doc_share.py`、`test_doc_delete.py`、`test_doc_rename.py` 三个测试文件中的 `autouse=True` fixture 在清理 `doc_registry` 的同时，**无条件删除了 `proxy` 配置**，且没有使用 `monkeypatch`/`tmp_path` 隔离，直接操作用户真实配置文件 `~/.config/wecom-cli/config.toml`。

每次运行这些测试，用户的 proxy 配置就会被清除。

## 影响范围

- `tests/test_doc_share.py:18-20` — 删除 proxy
- `tests/test_doc_delete.py:18-20` — 删除 proxy
- `tests/test_doc_rename.py:18-20` — 删除 proxy

## 修复方案

1. 为这3个测试文件的 `clean_registry` fixture 添加 `monkeypatch` + `tmp_path` 参数，将配置目录隔离到临时目录（参考 `test_config_commands.py` 的 `config_dir` fixture）
2. 移除 fixture 中删除 proxy 的代码（隔离后无需清理 proxy，因为临时目录本身就没有 proxy）

## 任务表

- [x] 为 test_doc_share.py 添加配置隔离
- [x] 为 test_doc_delete.py 添加配置隔离
- [x] 为 test_doc_rename.py 添加配置隔离
- [ ] 全部测试通过
