# WeCom CLI 项目结构

```
wecom-cli/
├── AGENTS.md                          # AI Agent 开发规范与流程
├── structs.md                         # 本文件 - 项目结构文档
├── pyproject.toml                     # 项目配置、依赖、构建
├── uv.lock                            # 依赖锁定文件
├── README.md                          # 项目说明
├── .python-version                    # Python 版本要求 (3.12)
├── .gitignore
│
 ├── plan/                              # 需求文档
 │   └── feature/
 │       ├── auth-and-config-feature.md # 认证与配置管理功能需求
 │       ├── unified-config-feature.md  # 统一配置管理系统功能需求
 │       └── field-record-crud-feature.md # 字段与记录增删改查功能需求
│
├── doc/                               # 企业微信 API 参考文档
│   ├── token/
│   │   └── get_token.md              # 获取 access_token 接口文档
│   └── doc/
│       ├── overview.md               # 文档功能概述
│       ├── mng/                      # 文档管理接口 (增删改查)
│       ├── smart/                    # 智能表格接口 (字段/记录/视图等)
│       └── attachment/               # 附件接口 (图片上传等)
│
  ├── src/wecom_cli/                     # 主源码目录
  │   ├── __init__.py                   # 包入口，定义 __version__
  │   ├── cli.py                        # CLI 主入口，注册所有命令组 (config, doc, version)，支持全局 --json 选项
  │   ├── config.py                     # 配置文件管理：TOML 读写、键路径解析、配置操作、跨平台配置目录
  │   ├── doc_registry.py              # 文档注册表：名称到 docid 的映射
  │   ├── output.py                     # 输出工具模块：统一的 JSON 和普通格式输出处理
  │   │
  │   ├── api/                          # 企业微信 API 封装
  │   │   ├── __init__.py
  │   │   ├── client.py                 # 通用 HTTP 客户端：鉴权注入、错误处理 (WeComAPIError)、GET/POST 方法、代理配置支持
  │   │   └── auth.py                   # Token 管理：缓存、过期检测 (提前5分钟)、自动刷新、代理配置支持
  │   │   └── doc.py                    # 文档和智能表格 API：文档 CRUD、子表 CRUD、字段 CRUD、记录 CRUD
  │   │
  │   └── commands/                     # CLI 命令组（每子目录对应一个 typer 子命令）
  │       ├── __init__.py
  │       ├── config/                   # `wecom config` 命令组
  │       │   ├── __init__.py
  │       │   └── config_app.py         # 子命令：init/set/get/show/list/token/proxy，所有命令支持 --json
  │       └── doc/                      # `wecom doc` 命令组
  │           ├── __init__.py
  │           ├── doc_app.py            # 文档命令入口，注册 smart 子命令，支持 --json 输出
  │           ├── add.py                # add 命令：创建文档
  │           ├── delete.py             # delete 命令：删除文档
  │           ├── rename.py             # rename 命令：重命名文档
  │           ├── share.py              # share 命令：获取文档分享链接
│           └── smart/                # `wecom doc smart` 命令组
│               ├── __init__.py
│               ├── smart_app.py      # 智能文档命令入口，注册 sheet/field/record 子命令
│               ├── create.py         # create 命令：创建智能文档
│               ├── field/            # `wecom doc smart field` 命令组
│               │   ├── __init__.py
│               │   ├── field_app.py  # 字段命令入口，注册 add/delete/update/query
│               │   ├── add.py        # add 命令：添加字段，支持 --title/--type/--property
│               │   ├── delete.py     # delete 命令：删除字段，支持 --field-id (多个)
│               │   ├── update.py     # update 命令：更新字段标题/属性，支持 --property
│               │   └── query.py      # query 命令：查询字段，支持 --field-id/--field-title/--offset/--limit
│               ├── record/           # `wecom doc smart record` 命令组
│               │   ├── __init__.py
│               │   ├── record_app.py # 记录命令入口，注册 add/delete/update/query
│               │   ├── add.py        # add 命令：添加记录，支持 --key-type/--record JSON
│               │   ├── delete.py     # delete 命令：删除记录，支持 --record-id (多个)
│               │   ├── update.py     # update 命令：更新记录，支持 --key-type/--record JSON
│               │   └── query.py      # query 命令：查询记录，完整支持 filter_spec 过滤
│               └── sheet/            # `wecom doc smart sheet` 命令组
│                   ├── __init__.py
│                   ├── sheet_app.py  # 子表命令入口，注册 add/delete/update/query
│                   ├── add.py        # add 命令：添加子表
│                   ├── delete.py     # delete 命令：删除子表
│                   ├── update.py     # update 命令：更新子表标题
│                   └── query.py      # query 命令：查询子表信息
│
 └── tests/                             # 测试目录
     ├── __init__.py
     ├── test_config.py                # config.py 测试 (48 tests)
     ├── test_client.py                # api/client.py 测试 (15 tests)
     ├── test_auth.py                  # api/auth.py 测试 (11 tests)
     ├── test_config_commands.py       # config CLI 命令测试 (30 tests)
     ├── test_cli.py                   # CLI 集成测试 (3 tests)
     ├── test_api_doc.py               # api/doc.py 测试：文档和子表 API (15 tests)
     ├── test_api_field_record.py      # api/doc.py 测试：字段和记录 API (28 tests)
     ├── test_field_commands.py        # 字段 CLI 命令测试 (27 tests)
     └── test_record_commands.py       # 记录 CLI 命令测试 (33 tests)
```

## 模块依赖关系

```
cli.py
  ├── commands/config/config_app.py ──→ config.py (配置读写)
  │                                    └→ api/auth.py (token 状态查询)
  └── commands/doc/doc_app.py
       └── commands/doc/smart/smart_app.py
            ├── commands/doc/smart/sheet/sheet_app.py
            │    ├── add.py ──→ api/doc.add_sheet
            │    ├── delete.py ──→ api/doc.delete_sheet
            │    ├── update.py ──→ api/doc.update_sheet
            │    └── query.py ──→ api/doc.query_sheet
            ├── commands/doc/smart/field/field_app.py
            │    ├── add.py ──→ api/doc.add_fields
            │    ├── delete.py ──→ api/doc.delete_fields
            │    ├── update.py ──→ api/doc.update_fields
            │    └── query.py ──→ api/doc.get_fields
            └── commands/doc/smart/record/record_app.py
                 ├── add.py ──→ api/doc.add_records
                 ├── delete.py ──→ api/doc.delete_records
                 ├── update.py ──→ api/doc.update_records
                 └── query.py ──→ api/doc.get_records (含 filter_spec)

api/doc.py ──→ api/client.py (WeComClient, WeComAPIError)
             └→ 所有文档/子表/字段/记录 API 函数

api/auth.py ──→ config.py (缓存 token、读取代理配置)
               └→ httpx (调用企业微信 gettoken API)

api/client.py ──→ config.py (读取代理配置)
                └→ httpx (通用 HTTP 客户端)
```

## 关键依赖

| 依赖 | 用途 |
|------|------|
| typer | CLI 框架 |
| rich | 终端富文本输出 |
| httpx | HTTP 客户端 |
| tomli_w | TOML 写入 |
| pytest | 测试框架 |
| ruff | 代码检查与格式化 |
