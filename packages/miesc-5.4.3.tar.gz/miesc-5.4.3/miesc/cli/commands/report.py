"""
MIESC CLI - Report Commands

Commands for generating formatted security reports from audit results.

Author: Fernando Boiero
License: AGPL-3.0
"""

import json
import logging
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Match, cast

import click

from miesc import __version__ as VERSION
from miesc.cli.utils import (
    RICH_AVAILABLE,
    console,
    error,
    get_data_path,
    get_root_dir,
    info,
    print_banner,
    success,
    warning,
)

# Import Rich components if available
if RICH_AVAILABLE:
    pass  # Rich imports handled via console

logger = logging.getLogger(__name__)

# Get ROOT_DIR for template paths
ROOT_DIR = get_root_dir()


# =============================================================================
# Helper Functions
# =============================================================================


def _get_impact_description(severity: str, category: str = "") -> str:
    """Get impact description based on severity and vulnerability category."""
    cat = category.lower().replace("-", " ").replace("_", " ") if category else ""
    # Category-specific impact descriptions
    category_impacts = {
        "reentrancy": "An attacker can recursively call the vulnerable function before state updates complete, draining contract funds in a single transaction. This is one of the most exploited vulnerability classes in DeFi (e.g., The DAO hack, $60M lost).",
        "selfdestruct": "An unprotected selfdestruct allows any caller to permanently destroy the contract and redirect all remaining ETH to an arbitrary address. Post-EIP-6780 (Dencun upgrade), selfdestruct only sends ETH without destroying storage, but the funds loss risk remains.",
        "uninitialized state": "Uninitialized state variables default to zero values, which for address types means address(0). Funds sent to uninitialized addresses are permanently lost. For boolean flags, uninitialized means false, potentially bypassing access controls.",
        "unchecked send": "Low-level calls (send, call) can silently fail without reverting the transaction. If the return value is not checked, the contract state advances as if the transfer succeeded, leading to accounting inconsistencies and potential fund loss.",
        "weak randomness": "Using block.timestamp, block.number, or blockhash for randomness is predictable by miners/validators. An attacker can manipulate or predict these values to consistently win lotteries, bypass random checks, or front-run randomness-dependent logic.",
        "tx origin": "Using tx.origin for authentication allows phishing attacks: if the contract owner interacts with a malicious contract, that contract can call the vulnerable function and pass the tx.origin check. Always use msg.sender for authentication.",
        "access control": "Missing or incorrect access control allows unauthorized users to execute privileged functions such as minting tokens, modifying state, transferring ownership, or withdrawing funds.",
        "integer overflow": "Arithmetic overflow/underflow can cause balances to wrap around, enabling attackers to mint tokens or manipulate accounting. Solidity 0.8+ has built-in overflow protection, but unchecked blocks and assembly bypass this.",
        "front running": "Pending transactions in the mempool are visible to anyone. An attacker can observe a profitable transaction and submit their own with higher gas to be executed first, extracting value (sandwich attacks, DEX arbitrage).",
        "oracle": "Price oracle manipulation allows attackers to distort asset prices used by the protocol, enabling exploits such as flash loan attacks that drain lending pools or manipulate collateral ratios.",
        "flash loan": "Flash loan attacks allow borrowing unlimited capital with zero collateral within a single transaction. Combined with other vulnerabilities (oracle manipulation, reentrancy), this enables catastrophic fund drainage.",
    }
    for key, desc in category_impacts.items():
        if key in cat:
            return desc
    # Fallback to severity-based
    severity_impacts = {
        "critical": "Complete loss of funds or contract takeover possible. Immediate exploitation risk with high likelihood of active exploitation.",
        "high": "Significant financial loss or contract compromise possible. Exploitation requires moderate effort but impact is severe.",
        "medium": "Limited financial impact or requires specific pre-conditions to exploit. Should be addressed before mainnet deployment.",
        "low": "Minor impact on contract functionality, gas efficiency, or code quality. Low risk but recommended to fix for best practices.",
        "info": "Informational finding for code quality improvement. No direct security impact.",
    }
    return severity_impacts.get(severity, "Impact assessment pending.")


def _get_recommendation(category: str, severity: str = "") -> str:
    """Get specific recommendation based on vulnerability category."""
    cat = category.lower().replace("-", " ").replace("_", " ") if category else ""
    recommendations = {
        "reentrancy": "Apply the Checks-Effects-Interactions pattern: verify conditions, update state, then make external calls. Consider using OpenZeppelin's ReentrancyGuard modifier.",
        "selfdestruct": "Remove selfdestruct entirely (deprecated since Solidity 0.8.24). If contract cleanup is needed, implement a migration pattern with proper access control instead.",
        "uninitialized state": "Explicitly initialize all state variables in the constructor or at declaration. Use require() checks to ensure addresses are non-zero before transferring funds.",
        "unchecked send": "Always check the return value of low-level calls. Use OpenZeppelin's Address.sendValue() or SafeERC20 for token transfers which handle failures automatically.",
        "weak randomness": "Use Chainlink VRF or a commit-reveal scheme for cryptographically secure randomness. Never use block.timestamp, block.number, or blockhash as entropy sources.",
        "tx origin": "Replace tx.origin with msg.sender for all authentication checks. tx.origin should only be used to verify that the caller is an EOA (not a contract), never for authorization.",
        "access control": "Implement role-based access control using OpenZeppelin's AccessControl or Ownable2Step. Use modifier-based checks and emit events on all privileged operations.",
        "unspecific solidity pragma": "Pin the Solidity version to a specific release (e.g., pragma solidity 0.8.20;) instead of a range (^0.8.0). This ensures consistent compilation and avoids unexpected behavior from compiler updates.",
        "zero address check": "Add require(addr != address(0)) validation for all address parameters in functions that assign state variables or transfer funds.",
        "unindexed events": "Add the indexed keyword to event parameters that will be used for filtering (typically addresses and IDs). Each event can have up to 3 indexed parameters.",
        "unsafe erc20": "Use OpenZeppelin's SafeERC20 library which handles non-standard ERC20 implementations (tokens that don't return bool on transfer).",
        "push zero opcode": "Set the Solidity compiler target to >= 0.8.20 to take advantage of the PUSH0 opcode (EIP-3855) which saves gas on contract deployment.",
        "solc version": "Update to a recent stable Solidity version (0.8.20+) for the latest security fixes, gas optimizations, and language features.",
    }
    for key, rec in recommendations.items():
        if key in cat:
            return rec
    return "Review and fix according to smart contract security best practices. See SWC Registry for detailed remediation guidance."


def _extract_attack_scenarios(findings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Extract attack scenarios from intelligence-enhanced findings."""
    scenarios = []
    for f in findings:
        exploit = f.get("exploit_scenario", [])
        if exploit:
            scenarios.append(
                {
                    "title": f.get("type", "Unknown"),
                    "severity": f.get("severity", "Medium"),
                    "steps": exploit if isinstance(exploit, list) else [str(exploit)],
                    "confidence": f.get("confidence", 0.5),
                }
            )
    return scenarios[:10]


def _extract_remediations(findings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Extract code remediations from intelligence-enhanced findings."""
    remediations = []
    for f in findings:
        fix = f.get("fix_code") or f.get("recommendation", "")
        if fix and len(fix) > 20:
            remediations.append(
                {
                    "finding": f.get("type", "Unknown"),
                    "severity": f.get("severity", "Medium"),
                    "fix": fix,
                    "canonical_category": f.get("canonical_category", ""),
                }
            )
    return remediations[:10]


def _extract_category_summary(findings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Build per-category summary from intelligence metadata."""
    from collections import Counter

    cats = Counter(f.get("canonical_category", "other") for f in findings)
    return [{"category": cat, "count": count} for cat, count in cats.most_common()]


def _extract_confidence_level(findings: list[dict[str, Any]]) -> str:
    """Overall confidence level from intelligence scores."""
    if not findings:
        return "N/A"
    confs = [
        f.get("confidence", 0.5) for f in findings if isinstance(f.get("confidence"), (int, float))
    ]
    if not confs:
        return "Medium"
    avg = sum(confs) / len(confs)
    if avg >= 0.85:
        return "High"
    if avg >= 0.60:
        return "Medium"
    return "Low"


def _get_swc_references(category: str, swc_id: str = "") -> list[str]:
    """Auto-generate references based on SWC/CWE classification."""
    refs = []
    cat = category.lower().replace("-", " ").replace("_", " ") if category else ""
    # SWC mapping
    swc_map = {
        "reentrancy": ("SWC-107", "https://swcregistry.io/docs/SWC-107"),
        "selfdestruct": ("SWC-106", "https://swcregistry.io/docs/SWC-106"),
        "unchecked": ("SWC-104", "https://swcregistry.io/docs/SWC-104"),
        "tx origin": ("SWC-115", "https://swcregistry.io/docs/SWC-115"),
        "weak random": ("SWC-120", "https://swcregistry.io/docs/SWC-120"),
        "integer overflow": ("SWC-101", "https://swcregistry.io/docs/SWC-101"),
        "access control": ("SWC-105", "https://swcregistry.io/docs/SWC-105"),
        "front running": ("SWC-114", "https://swcregistry.io/docs/SWC-114"),
        "dos": ("SWC-113", "https://swcregistry.io/docs/SWC-113"),
        "uninitialized": ("SWC-109", "https://swcregistry.io/docs/SWC-109"),
    }
    # If explicit SWC ID provided
    if swc_id and swc_id.startswith("SWC"):
        num = swc_id.replace("SWC-", "").replace("SWC", "")
        refs.append(f"[{swc_id}](https://swcregistry.io/docs/SWC-{num})")
    else:
        for key, (swc, _url) in swc_map.items():
            if key in cat:
                refs.append(f"[{swc}](https://swcregistry.io/docs/{swc})")
                break
    # Always add OWASP SC Top 10
    refs.append(
        "[OWASP Smart Contract Top 10](https://owasp.org/www-project-smart-contract-top-10/)"
    )
    return refs


def _extract_source_code(
    contract_path: str, line_number: int, context: int = 5, base_dir: str = ""
) -> str:
    """Extract actual source code lines from the contract file."""
    if not contract_path or contract_path == "unknown" or not line_number:
        return ""
    try:
        path = Path(contract_path)
        if not path.exists():
            # Try relative to base_dir (from results JSON "contract" field)
            search_dirs = [Path.cwd()]
            if base_dir:
                bd = Path(base_dir)
                search_dirs.insert(0, bd)
                # If base_dir is a file, use its parent
                if bd.is_file():
                    search_dirs.insert(0, bd.parent)
            search_dirs.extend([Path("/contracts"), Path("/tmp")])
            for base in search_dirs:
                candidate = base / contract_path
                if candidate.exists():
                    path = candidate
                    break
            else:
                return ""
        lines = path.read_text(encoding="utf-8").splitlines()
        start = max(0, line_number - context - 1)
        end = min(len(lines), line_number + context)
        snippet_lines = []
        for i in range(start, end):
            marker = " >> " if i == line_number - 1 else "    "
            snippet_lines.append(f"{marker}{i + 1:4d} | {lines[i]}")
        return "\n".join(snippet_lines)
    except Exception:
        return ""


def _interactive_wizard(variables: dict[str, Any], console: Any) -> dict[str, Any]:
    """
    Interactive wizard for report metadata.
    Only asks for client and auditor info - everything else comes from audit data.
    """
    from rich.prompt import Prompt

    def is_missing(value: Any) -> bool:
        if value is None:
            return True
        if isinstance(value, str):
            return value.strip() == "" or value.lower() in ("n/a", "unknown", "none")
        return False

    fields_to_ask = []

    if is_missing(variables.get("client_name")):
        fields_to_ask.append(("client_name", "Client/Project Name"))

    if is_missing(variables.get("auditor_name")):
        fields_to_ask.append(("auditor_name", "Auditor Name"))

    if not fields_to_ask:
        console.print("[green]✓ Report metadata complete.[/green]")
        return variables

    console.print("\n[bold cyan]MIESC Report Wizard[/bold cyan]")
    console.print("[dim]Press Enter to skip.[/dim]\n")

    changes = 0
    for key, label in fields_to_ask:
        value = Prompt.ask(f"[yellow]{label}[/yellow]", default="")
        if value.strip():
            variables[key] = value.strip()
            changes += 1

    if changes:
        console.print(f"[green]✓ {changes} field(s) updated.[/green]\n")

    return variables


def _calculate_risk_level(summary: dict[str, Any]) -> str:
    """Calculate overall risk level from summary."""
    critical = summary.get("critical", 0)
    high = summary.get("high", 0)
    medium = summary.get("medium", 0)

    if critical > 0:
        return "CRITICAL"
    elif high > 2:
        return "HIGH"
    elif high > 0 or medium > 3:
        return "MEDIUM"
    elif medium > 0:
        return "LOW"
    return "MINIMAL"


def _render_template(template: str, variables: dict[str, Any]) -> str:
    """Render template using Jinja2 if available, otherwise simple replacement."""
    try:
        from jinja2 import BaseLoader, Environment

        # Create Jinja2 environment with proper settings
        env = Environment(loader=BaseLoader())
        jinja_template = env.from_string(template)
        return cast(str, jinja_template.render(**variables))
    except ImportError:
        # Fallback to simple rendering
        return _simple_render_template(template, variables)


def _simple_render_template(template: str, variables: dict[str, Any]) -> str:
    """Simple template rendering fallback without Jinja2."""
    output = template

    # Replace variables with default values {{ var | default('value') }}
    def replace_with_default(match: Match[str]) -> str:
        var_name = match.group(1).strip()
        default_val = match.group(2).strip().strip("'\"")
        return str(variables.get(var_name, default_val))

    output = re.sub(
        r"\{\{\s*(\w+)\s*\|\s*default\s*\(\s*['\"]?([^'\")\s]+)['\"]?\s*\)\s*\}\}",
        replace_with_default,
        output,
    )

    # Replace simple variables {{ var }}
    for key, value in variables.items():
        if not isinstance(value, (list, dict)):
            output = output.replace("{{ " + key + " }}", str(value))
            output = output.replace("{{" + key + "}}", str(value))

    # Handle generic for loops (including {%- and -%} whitespace control)
    loop_pattern = r"\{%-?\s*for\s+(\w+)\s+in\s+(\w+)\s*-?%\}(.*?)\{%-?\s*endfor\s*-?%\}"

    def replace_loop(match: Match[str]) -> str:
        item_name = match.group(1)
        list_name = match.group(2)
        loop_body = match.group(3)

        items = variables.get(list_name, [])
        if not items:
            return ""

        result = ""
        for item in items:
            item_output = loop_body
            if isinstance(item, dict):
                for key, value in item.items():
                    if isinstance(value, list):
                        value = ", ".join(str(v) for v in value)
                    item_output = item_output.replace(f"{{{{ {item_name}.{key} }}}}", str(value))
                    item_output = item_output.replace(f"{{{{{item_name}.{key}}}}}", str(value))
            else:
                item_output = item_output.replace(f"{{{{ {item_name} }}}}", str(item))
            result += item_output
        return result

    # Process all loops (may need multiple passes for nested loops)
    for _ in range(5):  # Max 5 passes for nested loops
        new_output = re.sub(loop_pattern, replace_loop, output, flags=re.DOTALL)
        if new_output == output:
            break
        output = new_output

    # Handle conditionals (including {%- and -%} whitespace control)
    # Remove entire if/else/endif blocks that weren't processed
    output = re.sub(r"\{%-?\s*if\s+[^%]+%\}.*?\{%-?\s*endif\s*-?%\}", "", output, flags=re.DOTALL)

    # Clean up any remaining Jinja2 syntax
    output = re.sub(r"\{%-?\s*else\s*-?%\}", "", output)
    output = re.sub(r"\{%-?\s*elif\s+[^%]+%\}", "", output)

    # Remove leftover unprocessed variables with defaults
    output = re.sub(r"\{\{\s*\w+\s*\|\s*default\s*\([^)]+\)\s*\}\}", "", output)

    # Remove leftover unprocessed simple variables
    output = re.sub(r"\{\{\s*\w+\s*\}\}", "", output)

    # Clean up multiple blank lines
    output = re.sub(r"\n{4,}", "\n\n\n", output)

    return output


def _markdown_to_html(markdown: str, title: str, use_premium_css: bool = True) -> str:
    """Convert markdown to HTML with professional styling."""
    try:
        import markdown as md

        html_body = md.markdown(markdown, extensions=["tables", "fenced_code", "toc", "attr_list"])
    except ImportError:
        # Fallback: wrap in pre tag
        html_body = f"<pre>{markdown}</pre>"

    # Try to load premium CSS
    css_content = ""
    if use_premium_css:
        css_path = ROOT_DIR / "docs" / "templates" / "reports" / "profesional.css"
        if css_path.exists():
            css_content = css_path.read_text(encoding="utf-8")

    # Fallback to basic CSS if premium not available
    if not css_content:
        css_content = """
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 900px; margin: 0 auto; padding: 2rem; line-height: 1.6; }
        h1, h2, h3 { color: #1a1a2e; }
        table { border-collapse: collapse; width: 100%; margin: 1rem 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #1a1a2e; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        code { background-color: #f4f4f4; padding: 2px 6px; border-radius: 3px; }
        pre { background-color: #f4f4f4; padding: 1rem; border-radius: 5px; overflow-x: auto; }
        .critical { color: #dc3545; font-weight: bold; }
        .high { color: #fd7e14; font-weight: bold; }
        .medium { color: #ffc107; }
        .low { color: #17a2b8; }
        """

    # Enhance HTML with severity badges
    html_body = _enhance_html_severity(html_body)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
{css_content}
    </style>
</head>
<body>
{html_body}
    <script>
        // Auto-enhance severity badges
        document.querySelectorAll('td, strong').forEach(el => {{
            const text = el.textContent.trim();
            if (['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'].includes(text)) {{
                el.innerHTML = '<span class="severity-' + text.toLowerCase() + '">' + text + '</span>';
            }}
        }});
    </script>
</body>
</html>"""


def _enhance_html_severity(html: str) -> str:
    """Add CSS classes to severity indicators in HTML."""
    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
        # Wrap **SEVERITY** in spans
        html = re.sub(
            rf"\*\*({sev})\*\*", rf'<span class="severity-{sev.lower()}">{sev}</span>', html
        )
        # Also handle plain text in tables
        html = re.sub(
            rf"<td>({sev})</td>",
            rf'<td><span class="severity-{sev.lower()}">{sev}</span></td>',
            html,
        )

    return html


# =============================================================================
# Report Command
# =============================================================================


@click.command()
@click.argument("results_file", type=click.Path(exists=True))
@click.option(
    "--template",
    "-t",
    type=click.Choice(
        ["professional", "executive", "technical", "github-pr", "simple", "profesional", "premium"]
    ),
    default="simple",
    help="Report template to use (premium/profesional include CVSS scores, attack scenarios, and deployment recommendations)",
)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
@click.option(
    "--format",
    "-f",
    "output_format",
    type=click.Choice(["markdown", "html", "pdf"]),
    default="markdown",
    help="Output format",
)
@click.option("--client", type=str, help="Client name for the report")
@click.option("--auditor", type=str, help="Auditor name for the report")
@click.option("--title", type=str, help="Custom report title")
@click.option("--contract-name", type=str, help="Contract name (overrides auto-detected)")
@click.option("--repository", type=str, help="Repository URL or path")
@click.option("--commit", type=str, help="Commit hash for the audited code")
@click.option(
    "--network",
    type=str,
    default="Ethereum Mainnet",
    help="Target network (e.g., Ethereum Mainnet, Polygon)",
)
@click.option(
    "--classification",
    type=str,
    default="CONFIDENTIAL",
    help="Report classification (CONFIDENTIAL, PUBLIC, etc.)",
)
@click.option(
    "--llm-interpret",
    is_flag=True,
    default=False,
    help="Use LLM to interpret findings and generate executive insights (requires Ollama)",
)
@click.option(
    "--interactive",
    "-i",
    is_flag=True,
    default=False,
    help="Interactive wizard mode: prompt for missing/unknown values before generating report",
)
def report(
    results_file: str,
    template: str,
    output: str | None,
    output_format: str,
    client: str | None,
    auditor: str | None,
    title: str | None,
    contract_name: str | None,
    repository: str | None,
    commit: str | None,
    network: str,
    classification: str,
    llm_interpret: bool,
    interactive: bool,
) -> None:
    """Generate formatted security reports from audit results.

    Takes JSON audit results and applies a template to generate
    professional security reports.

    Examples:

      miesc report results.json -t professional -o report.md

      miesc report results.json -t executive --client "Acme" -o summary.md

      miesc report results.json -t premium --client "Acme Corp" --auditor "Security Team" \\
          --contract-name "TokenV2.sol" --repository "github.com/acme/token" \\
          --network "Polygon" -o audit.pdf -f pdf

      miesc report results.json -t premium -i  # Interactive wizard mode

      miesc report results.json -t github-pr  # Output to stdout
    """
    print_banner()

    # Load results
    try:
        with open(results_file, encoding="utf-8") as results_handle:
            results: dict[str, Any] = json.load(results_handle)
    except json.JSONDecodeError as e:
        error(f"Invalid JSON in {results_file}: {e}")
        sys.exit(1)
    except Exception as e:
        error(f"Failed to read {results_file}: {e}")
        sys.exit(1)

    info(f"Loaded results from {results_file}")

    # Locate template (package data first, repo root fallback)
    template_file = get_data_path("templates", "reports", f"{template}.md")
    if not template_file.exists():
        template_file = get_data_path("docs", "templates", "reports", f"{template}.md")
    if not template_file.exists():
        error(f"Template not found: {template_file}")
        info("Available templates: professional, executive, technical, github-pr, simple, premium")
        sys.exit(1)

    # Load template
    template_content = template_file.read_text(encoding="utf-8")

    # Extract data from results
    summary = results.get("summary", {})

    # For batch results, use aggregated_summary if available
    if not summary and "aggregated_summary" in results:
        summary = results.get("aggregated_summary", {})

    # Extract findings from results (can be at root level, within tool results, or in batch format)
    findings: list[dict[str, Any]] = results.get("findings", [])

    # Smart audit format: prefer ML-enhanced findings (adjusted severities) over raw
    if not findings:
        ml_enhanced = results.get("ml_enhanced", {})
        if (
            isinstance(ml_enhanced, dict)
            and isinstance(ml_enhanced.get("findings"), list)
            and ml_enhanced["findings"]
        ):
            findings = ml_enhanced["findings"]
        elif (
            isinstance(ml_enhanced, dict)
            and isinstance(ml_enhanced.get("top_findings"), list)
            and ml_enhanced["top_findings"]
        ):
            findings = ml_enhanced["top_findings"]
        elif "raw_findings" in results and results["raw_findings"].get("findings"):
            findings = results["raw_findings"]["findings"]

    if not findings:
        # Extract from tool results (single contract format)
        for tool_result in results.get("results", []):
            tool_findings = tool_result.get("findings", [])
            for f in tool_findings:
                f["tool"] = tool_result.get("tool", "unknown")
            findings.extend(tool_findings)

    if not findings:
        # Extract from batch format: contracts[].results[].findings
        for contract_data in results.get("contracts", []):
            contract_file = contract_data.get("contract", "unknown")
            for tool_result in contract_data.get("results", []):
                tool_findings = tool_result.get("findings", [])
                for f in tool_findings:
                    f["tool"] = tool_result.get("tool", "unknown")
                    f["source_contract"] = contract_file
                findings.extend(tool_findings)

    # Normalize summary keys (can be uppercase or lowercase)
    if summary:
        summary = {k.lower(): v for k, v in summary.items()}

    # Calculate severity counts from summary or from findings
    if summary:
        critical_count = summary.get("critical", 0)
        high_count = summary.get("high", 0)
        medium_count = summary.get("medium", 0)
        low_count = summary.get("low", 0)
        info_count = summary.get("info", summary.get("informational", 0))
    else:
        # Calculate from findings if summary is not available
        critical_count = sum(1 for f in findings if f.get("severity", "").lower() == "critical")
        high_count = sum(1 for f in findings if f.get("severity", "").lower() == "high")
        medium_count = sum(1 for f in findings if f.get("severity", "").lower() == "medium")
        low_count = sum(1 for f in findings if f.get("severity", "").lower() == "low")
        info_count = sum(
            1 for f in findings if f.get("severity", "").lower() in ("info", "informational")
        )

    def get_status(count: int, severity: str) -> str:
        if count == 0:
            return "✅ None Found"
        elif severity in ("critical", "high"):
            return f"⚠️ {count} Issue{'s' if count > 1 else ''} - Action Required"
        else:
            return f"ℹ️ {count} Issue{'s' if count > 1 else ''}"

    # Get tools used per layer
    tools_by_layer = results.get("tools_by_layer", {})
    tool_list = results.get("tools", [])
    if not tool_list:
        tool_set: set[str] = set()
        for r in results.get("results", []):
            if r.get("tool"):
                tool_set.add(r["tool"])
        for f in findings:
            t = f.get("tool") or f.get("source", "")
            if t:
                tool_set.add(t)
        tool_list = sorted(tool_set)

    # Generate risk summary based on findings
    overall_risk = _calculate_risk_level(summary)
    risk_summaries = {
        "CRITICAL": "**CRITICAL RISK**: This contract contains critical vulnerabilities that could lead to complete loss of funds or contract takeover. Immediate remediation is required before deployment.",
        "HIGH": "**HIGH RISK**: Significant security issues were identified that could result in substantial financial loss or contract compromise. These issues should be addressed before deployment.",
        "MEDIUM": "**MEDIUM RISK**: Several security concerns were found that could potentially be exploited under certain conditions. Recommended to address before deployment.",
        "LOW": "**LOW RISK**: Minor issues were identified that should be addressed to improve code quality and security posture.",
        "MINIMAL": "**MINIMAL RISK**: No significant security issues were identified. The contract follows security best practices.",
    }

    # =========================================================================
    # Deduplicate findings by (type + location) — keep highest severity
    # =========================================================================
    severity_rank = {
        "critical": 5,
        "high": 4,
        "medium": 3,
        "low": 2,
        "info": 1,
        "informational": 1,
    }

    def _finding_dedup_key(f: dict[str, Any]) -> tuple[str, str]:
        """Build deduplication key from type + location."""
        f_type = f.get("type") or f.get("check") or f.get("title") or ""
        loc = f.get("location", {})
        if isinstance(loc, dict):
            loc_str = f"{loc.get('file', '')}:{loc.get('line', '')}"
        else:
            loc_str = str(loc)
        return (f_type.lower().strip(), loc_str.lower().strip())

    seen_findings: Dict[tuple[str, str], dict[str, Any]] = {}
    for f in findings:
        dedup_key = _finding_dedup_key(f)
        existing = seen_findings.get(dedup_key)
        if existing is None:
            seen_findings[dedup_key] = f
        else:
            # Keep the one with higher severity
            cur_rank = severity_rank.get(f.get("severity", "").lower(), 0)
            old_rank = severity_rank.get(existing.get("severity", "").lower(), 0)
            if cur_rank > old_rank:
                seen_findings[dedup_key] = f
    findings = list(seen_findings.values())

    # Recalculate severity counts after deduplication
    if not summary:
        critical_count = sum(1 for f in findings if f.get("severity", "").lower() == "critical")
        high_count = sum(1 for f in findings if f.get("severity", "").lower() == "high")
        medium_count = sum(1 for f in findings if f.get("severity", "").lower() == "medium")
        low_count = sum(1 for f in findings if f.get("severity", "").lower() == "low")
        info_count = sum(
            1 for f in findings if f.get("severity", "").lower() in ("info", "informational")
        )

    # Prepare template variables
    # CLI parameters override auto-detected values from results
    # Support multiple JSON formats: contract, contract_path, path
    detected_contract_full_path = (
        results.get("contract") or results.get("contract_path") or results.get("path") or "Unknown"
    )
    detected_contract = detected_contract_full_path
    # Extract just the filename from path
    if "/" in detected_contract:
        detected_contract = detected_contract.split("/")[-1]

    variables = {
        "contract_name": contract_name or detected_contract,
        "audit_date": results.get("timestamp", datetime.now().isoformat())[:10],
        "generation_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "client_name": client or "Client",
        "auditor_name": auditor or "MIESC Security",
        "version": results.get("version", VERSION),
        "critical_count": critical_count,
        "high_count": high_count,
        "medium_count": medium_count,
        "low_count": low_count,
        "info_count": info_count,
        "total_findings": len(findings),
        "files_count": results.get("files_count", results.get("contracts_analyzed", 1)),
        "tools_count": len(tool_list),
        "overall_risk": overall_risk,
        "miesc_version": VERSION,
        # Additional fields for professional template
        "repository": repository or results.get("repository", "Local Analysis"),
        "commit_hash": commit or results.get("commit", "N/A"),
        "lines_of_code": results.get("lines_of_code", "N/A"),
        "audit_duration": results.get("duration", "N/A"),
        "critical_status": get_status(critical_count, "critical"),
        "high_status": get_status(high_count, "high"),
        "medium_status": get_status(medium_count, "medium"),
        "low_status": get_status(low_count, "low"),
        "info_status": get_status(info_count, "info"),
        "risk_summary": risk_summaries.get(overall_risk, "Risk assessment pending."),
        # Layer tools
        "layer1_tools": ", ".join(
            tools_by_layer.get("static_analysis", ["slither", "aderyn", "solhint"])
        ),
        "layer2_tools": ", ".join(
            tools_by_layer.get("dynamic_testing", ["echidna", "medusa", "foundry"])
        ),
        "layer3_tools": ", ".join(
            tools_by_layer.get("symbolic_execution", ["mythril", "manticore", "halmos"])
        ),
        "layer4_tools": ", ".join(
            tools_by_layer.get("formal_verification", ["certora", "smtchecker"])
        ),
        "layer5_tools": ", ".join(tools_by_layer.get("property_testing", ["propertygpt"])),
        "layer6_tools": ", ".join(
            tools_by_layer.get("ai_analysis", ["smartllm", "gptscan", "llmsmartaudit"])
        ),
        "layer7_tools": ", ".join(tools_by_layer.get("ml_detection", ["dagnn", "smartbugs_ml"])),
        "layer8_tools": ", ".join(tools_by_layer.get("defi", ["defi", "mev_detector"])),
        "layer9_tools": ", ".join(
            tools_by_layer.get("specialized", ["gas_analyzer", "threat_model"])
        ),
        # Empty lists for optional sections
        "swc_mappings": [],
        "owasp_mappings": [],
        "tool_outputs": [],
        "files_analyzed": [],  # Will be populated below
        "files_in_scope": [],  # Will be populated below
        # LLM interpretation placeholders (populated if --llm-interpret is used)
        "llm_executive_summary": "",
        "llm_risk_narrative": "",
        "llm_remediation_priority": [],
        "llm_critical_interpretations": [],
        "llm_enabled": False,
        # Profesional template variables (populated for profesional template)
        "cvss_scores": [],
        "risk_matrix": {},
        "overall_risk_score": 0,
        "deployment_recommendation": "CONDITIONAL",
        "deployment_justification": "",
        "deployment_recommendation_color": "#ff9800",
        "deployment_recommendation_bg": "#fff8e1",
        "quick_wins": [],
        "effort_impact_matrix": {},
        "attack_scenarios": _extract_attack_scenarios(findings),
        "code_remediations": _extract_remediations(findings),
        "category_summary": _extract_category_summary(findings),
        "exploitability_rating": "Medium",
        "business_impact": "Medium",
        "confidence_level": _extract_confidence_level(findings),
        "value_at_risk": None,
        "out_of_scope": [],
        "engagement_type": "Security Audit",
        "target_network": network,
        "classification": classification,
        "report_version": "1.0",
    }

    # =========================================================================
    # Generate Key Takeaways (§1.1)
    # =========================================================================
    high_critical_count = critical_count + high_count
    # Find top vulnerability type from findings
    from collections import Counter

    vuln_types: Counter[str] = Counter()
    for f in findings:
        vtype = f.get("canonical_category") or f.get("category") or f.get("type") or "general"
        vuln_types[vtype] += 1
    top_vuln_type = vuln_types.most_common(1)[0][0] if vuln_types else "general"

    if critical_count > 0:
        deploy_note = "Deployment must be halted until critical issues are resolved."
    elif high_count > 0:
        deploy_note = "Immediate remediation required before deployment."
    elif medium_count > 0:
        deploy_note = "Address medium-severity issues before production deployment."
    elif low_count > 0:
        deploy_note = "Minor improvements recommended; deployment acceptable."
    else:
        deploy_note = "No significant issues identified; contract is suitable for deployment."

    if high_critical_count > 0:
        key_takeaways = (
            f"{high_critical_count} high-severity vulnerabilit{'ies' if high_critical_count != 1 else 'y'} "
            f"identified, primarily {top_vuln_type.replace('-', ' ').replace('_', ' ')} issues. "
            f"{deploy_note}"
        )
    elif medium_count > 0:
        key_takeaways = (
            f"{medium_count} medium-severity finding{'s' if medium_count != 1 else ''} detected, "
            f"mainly related to {top_vuln_type.replace('-', ' ').replace('_', ' ')}. {deploy_note}"
        )
    elif len(findings) > 0:
        key_takeaways = (
            f"{len(findings)} low-severity or informational finding{'s' if len(findings) != 1 else ''} "
            f"identified. {deploy_note}"
        )
    else:
        key_takeaways = "No vulnerabilities identified during the audit. " + deploy_note

    variables["key_takeaways"] = key_takeaways
    # Also set llm_executive_summary if not already set by LLM
    if not variables.get("llm_executive_summary"):
        variables["llm_executive_summary"] = key_takeaways

    # =========================================================================
    # Generate Files Analyzed / Files In Scope
    # =========================================================================
    files_analyzed: list[dict[str, Any]] = []
    files_in_scope: list[dict[str, Any]] = []
    total_lines = 0

    # Check if batch audit (has "contracts" array)
    if "contracts" in results:
        for idx, contract_data in enumerate(results.get("contracts", []), 1):
            contract_path = contract_data.get("contract", "Unknown")
            contract_name_short = (
                Path(contract_path).name if contract_path != "Unknown" else f"Contract {idx}"
            )
            contract_findings = contract_data.get("total_findings", 0)

            # Try to get lines of code
            lines: int | str = "N/A"
            try:
                if contract_path and Path(contract_path).exists():
                    with open(contract_path, encoding="utf-8") as contract_handle:
                        lines = len(contract_handle.readlines())
                        total_lines += lines
            except Exception:
                pass

            files_analyzed.append(
                {
                    "path": contract_name_short,
                    "full_path": contract_path,
                    "lines": lines,
                    "findings": contract_findings,
                }
            )
            files_in_scope.append(
                {"path": contract_name_short, "lines": lines, "description": "Smart Contract"}
            )
    else:
        # Single contract - try multiple sources for contract path
        contract_path = results.get(
            "contract", results.get("contract_path", results.get("path", "Unknown"))
        )

        # If not found at root level, try to get from first result
        if contract_path == "Unknown" and results.get("results"):
            for r in results.get("results", []):
                if r.get("contract"):
                    contract_path = r.get("contract")
                    break

        contract_name_short = (
            Path(contract_path).name if contract_path and contract_path != "Unknown" else "Contract"
        )

        lines = 0
        functions_count = 0
        try:
            resolved_path = None
            if contract_path and contract_path != "Unknown":
                p = Path(contract_path)
                if p.exists():
                    resolved_path = p
                else:
                    # Try resolving relative to results file directory
                    results_dir = Path(results_file).parent
                    search_candidates = [
                        results_dir / contract_path,
                        results_dir.parent / contract_path,
                        Path.cwd() / contract_path,
                        Path("/contracts") / Path(contract_path).name,
                        Path("/tmp") / Path(contract_path).name,
                    ]
                    for candidate in search_candidates:
                        if candidate.exists():
                            resolved_path = candidate
                            break

            if resolved_path and resolved_path.is_file():
                content = resolved_path.read_text(encoding="utf-8")
                lines = len(content.splitlines())
                total_lines = lines
                # Count functions
                functions_count = len(re.findall(r"\bfunction\s+\w+\s*\(", content))
        except Exception:
            lines = "N/A"

        files_analyzed.append(
            {
                "path": contract_name_short,
                "full_path": contract_path,
                "lines": lines,
                "functions": functions_count,
                "findings": len(findings),
            }
        )
        files_in_scope.append(
            {
                "path": contract_name_short,
                "lines": lines,
                "functions": functions_count,
                "description": "Smart Contract",
            }
        )

    variables["files_analyzed"] = files_analyzed
    variables["files_in_scope"] = files_in_scope
    variables["files_count"] = len(files_analyzed)
    if total_lines > 0:
        variables["lines_of_code"] = total_lines

    # =========================================================================
    # Enhanced Tool Execution Summary
    # =========================================================================
    # Get tool results - handle multiple audit formats
    tool_results = results.get("results", [])
    if not tool_results and "contracts" in results:
        # Batch audit format: aggregate results from all contracts
        for contract_data in results.get("contracts", []):
            tool_results.extend(contract_data.get("results", []))

    # Smart audit format: build tool_results from tools_run/success/failed
    if not tool_results and "tools_run" in results:
        tools_run = results.get("tools_run", [])
        tools_success = set(results.get("tools_success", []))
        tools_failed = set(results.get("tools_failed", []))
        raw_findings = results.get("raw_findings", {}).get("findings", [])
        ml_findings = results.get("ml_filtered", {}).get("findings", [])
        all_findings = ml_findings if ml_findings else raw_findings

        # Group findings by tool
        findings_by_tool: Dict[str, list] = {}
        for f in all_findings:
            tool = f.get("tool", "unknown")
            if tool not in findings_by_tool:
                findings_by_tool[tool] = []
            findings_by_tool[tool].append(f)

        # Build tool_results from tools_run
        for tool in tools_run:
            tool_findings = findings_by_tool.get(tool, [])
            if tool in tools_success:
                status = "success"
            elif tool in tools_failed:
                status = "failed"
            else:
                status = "unknown"
            tool_results.append(
                {
                    "tool": tool,
                    "status": status,
                    "findings": tool_findings,
                    "duration": "N/A",
                }
            )

    tools_execution_summary = []
    layer_summary: Dict[str, Any] = {}

    # Layer name mapping
    layer_names = {
        "static_analysis": "Layer 1: Static Analysis",
        "dynamic_testing": "Layer 2: Dynamic Testing",
        "symbolic_execution": "Layer 3: Symbolic Execution",
        "formal_verification": "Layer 4: Formal Verification",
        "property_testing": "Layer 5: Property Testing",
        "ai_analysis": "Layer 6: AI/LLM Analysis",
        "ml_detection": "Layer 7: ML Detection",
        "defi": "Layer 8: DeFi Security",
        "specialized": "Layer 9: Specialized Analysis",
    }

    # Tool to layer mapping (when layer not specified by adapter)
    TOOL_LAYER_MAP = {
        # Layer 1: Static Analysis
        "slither": "static_analysis",
        "aderyn": "static_analysis",
        "solhint": "static_analysis",
        "semgrep": "static_analysis",
        "solc": "static_analysis",
        "wake": "static_analysis",
        # Layer 2: Dynamic Testing
        "echidna": "dynamic_testing",
        "foundry": "dynamic_testing",
        "hardhat": "dynamic_testing",
        "medusa": "dynamic_testing",
        "dogefuzz": "dynamic_testing",
        "vertigo": "dynamic_testing",
        # Layer 3: Symbolic Execution
        "mythril": "symbolic_execution",
        "manticore": "symbolic_execution",
        "halmos": "symbolic_execution",
        "hevm": "symbolic_execution",
        "oyente": "symbolic_execution",
        # Layer 4: Formal Verification
        "certora": "formal_verification",
        "scribble": "formal_verification",
        "pyrometer": "formal_verification",
        "smtchecker": "formal_verification",
        "propertygpt": "formal_verification",
        # Layer 5: AI Analysis
        "smartllm": "ai_analysis",
        "gptscan": "ai_analysis",
        "llmsmartaudit": "ai_analysis",
        "4naly3er": "ai_analysis",
        "gpt-4": "ai_analysis",
        # Layer 6: ML Detection
        "dagnn": "ml_detection",
        "smartbugs_ml": "ml_detection",
        "smartbugs_detector": "ml_detection",
        "smartguard": "ml_detection",
        "ml-detector": "ml_detection",
        # Layer 7: DeFi Security
        "defi": "defi",
        "defi-scanner": "defi",
        "mev_detector": "defi",
        # Layer 8: Specialized Analysis
        "threat_model": "specialized",
        "gas_analyzer": "specialized",
        "contract_clone_detector": "specialized",
        "advanced_detector": "specialized",
        "token-analyzer": "specialized",
    }

    for tool_result in tool_results:
        tool_name = tool_result.get("tool", "unknown")
        tool_status = tool_result.get("status", "unknown")
        tool_duration = tool_result.get("duration", "N/A")
        tool_findings = tool_result.get("findings", [])
        tool_layer = tool_result.get("layer") or TOOL_LAYER_MAP.get(tool_name.lower(), "unknown")
        tool_error = tool_result.get("error", "")

        # Map status to human-readable
        status_map = {
            "success": "Success",
            "failed": "Failed",
            "skipped": "Skipped",
            "timeout": "Timeout",
            "error": "Error",
        }
        display_status = status_map.get(
            tool_status, tool_status.capitalize() if isinstance(tool_status, str) else "Unknown"
        )

        tools_execution_summary.append(
            {
                "name": tool_name,
                "status": display_status,
                "status_icon": (
                    "✅"
                    if tool_status == "success"
                    else ("⚠️" if tool_status in ("failed", "error", "timeout") else "⏭️")
                ),
                "duration": (
                    f"{tool_duration}s"
                    if isinstance(tool_duration, (int, float))
                    else str(tool_duration)
                ),
                "findings_count": len(tool_findings),
                "layer": layer_names.get(tool_layer, tool_layer),
                "error": tool_error[:100] if tool_error else "",
            }
        )

        # Aggregate by layer
        layer_key = tool_layer if tool_layer else "unknown"
        if layer_key not in layer_summary:
            layer_summary[layer_key] = {
                "name": layer_names.get(layer_key, layer_key),
                "tools_executed": [],
                "tools_success": 0,
                "tools_failed": 0,
                "findings_count": 0,
            }
        layer_summary[layer_key]["tools_executed"].append(tool_name)
        layer_summary[layer_key]["findings_count"] += len(tool_findings)
        if tool_status == "success":
            layer_summary[layer_key]["tools_success"] += 1
        elif tool_status in ("failed", "error", "timeout"):
            layer_summary[layer_key]["tools_failed"] += 1

    # Enrich layer_summary with tools/findings from confirming_tools metadata.
    # This handles both the empty case (no tool_results) and the case where
    # tool_results has per-tool metadata but findings are in a consolidated
    # miesc-intelligence result.
    seen_tools_in_findings: set = set()
    for f in findings:
        f_tools = f.get("confirming_tools", [])
        if not f_tools:
            t = f.get("tool", "")
            if t and t != "miesc-intelligence":
                f_tools = [t]
        for tool_name in f_tools:
            tool_name_lower = tool_name.lower().strip()
            if tool_name_lower and tool_name_lower not in seen_tools_in_findings:
                seen_tools_in_findings.add(tool_name_lower)
                tool_layer = TOOL_LAYER_MAP.get(tool_name_lower, "unknown")
                layer_key = tool_layer if tool_layer else "unknown"
                if layer_key not in layer_summary:
                    layer_summary[layer_key] = {
                        "name": layer_names.get(layer_key, layer_key),
                        "tools_executed": [],
                        "tools_success": 0,
                        "tools_failed": 0,
                        "findings_count": 0,
                    }
                if tool_name_lower not in [
                    t.lower() for t in layer_summary[layer_key]["tools_executed"]
                ]:
                    layer_summary[layer_key]["tools_executed"].append(tool_name)
                    layer_summary[layer_key]["tools_success"] += 1

    # Attribute findings to layers via their confirming tools
    for f in findings:
        f_tools = f.get("confirming_tools", [])
        if not f_tools:
            t = f.get("tool", "")
            if t and t != "miesc-intelligence":
                f_tools = [t]
        if f_tools:
            tool_layer = TOOL_LAYER_MAP.get(f_tools[0].lower().strip(), "unknown")
            if tool_layer in layer_summary:
                layer_summary[tool_layer]["findings_count"] += 1

    # Convert layer_summary to list sorted by layer order
    layer_order = [
        "static_analysis",
        "dynamic_testing",
        "symbolic_execution",
        "formal_verification",
        "property_testing",
        "ai_analysis",
        "ml_detection",
        "defi",
        "specialized",
    ]
    layer_summary_list = []
    for layer_key in layer_order:
        if layer_key in layer_summary:
            ls = layer_summary[layer_key]
            layer_summary_list.append(
                {
                    "name": ls["name"],
                    "tools": ", ".join(ls["tools_executed"]) if ls["tools_executed"] else "None",
                    "success_count": ls["tools_success"],
                    "failed_count": ls["tools_failed"],
                    "findings_count": ls["findings_count"],
                    "coverage_status": (
                        "✅ Complete"
                        if ls["tools_success"] > 0 and ls["tools_failed"] == 0
                        else ("⚠️ Partial" if ls["tools_success"] > 0 else "❌ Not Executed")
                    ),
                }
            )

    # Expand "miesc-intelligence" entries in tools_execution_summary
    # to show the actual underlying tools from findings' confirming_tools
    actual_tools_from_findings: set = set()
    for f in findings:
        for t in f.get("confirming_tools", []):
            if t and t.lower() != "miesc-intelligence":
                actual_tools_from_findings.add(t.lower().strip())

    if actual_tools_from_findings:
        expanded_tools_summary = []
        for entry in tools_execution_summary:
            if entry["name"].lower() == "miesc-intelligence":
                # Replace with actual tools
                for actual_tool in sorted(actual_tools_from_findings):
                    tool_layer = TOOL_LAYER_MAP.get(actual_tool, "unknown")
                    expanded_tools_summary.append(
                        {
                            "name": actual_tool,
                            "status": entry["status"],
                            "status_icon": entry["status_icon"],
                            "duration": entry["duration"],
                            "findings_count": sum(
                                1
                                for f in findings
                                if actual_tool
                                in [ct.lower().strip() for ct in f.get("confirming_tools", [])]
                            ),
                            "layer": layer_names.get(tool_layer, tool_layer),
                            "error": "",
                        }
                    )
            else:
                expanded_tools_summary.append(entry)
        tools_execution_summary = expanded_tools_summary

    variables["tools_execution_summary"] = tools_execution_summary
    variables["layer_summary"] = layer_summary_list
    variables["total_tools_executed"] = len(tools_execution_summary)

    # Populate layer coverage status for methodology section (§2.3)
    layer_coverage_map = {
        "static_analysis": "layer1_coverage",
        "dynamic_testing": "layer2_coverage",
        "symbolic_execution": "layer3_coverage",
        "formal_verification": "layer4_coverage",
        "property_testing": "layer5_coverage",
        "ai_analysis": "layer6_coverage",
        "ml_detection": "layer7_coverage",
        "defi": "layer8_coverage",
        "specialized": "layer9_coverage",
    }
    for lk, var_name in layer_coverage_map.items():
        if lk in layer_summary:
            ls = layer_summary[lk]
            if ls["tools_success"] > 0 and ls["tools_failed"] == 0:
                variables[var_name] = "✅ Complete"
            elif ls["tools_success"] > 0:
                variables[var_name] = "⚠️ Partial"
            else:
                variables[var_name] = "❌ Failed"
        else:
            variables[var_name] = "-- Not Run"

    # Populate tool_outputs for Appendix A (detailed tool execution)
    tool_outputs = []
    for tool_result in tool_results:
        tool_name = tool_result.get("tool", "unknown")
        tool_status = tool_result.get("status", "unknown")
        tool_duration = tool_result.get("execution_time", "N/A")
        tool_findings = tool_result.get("findings", [])
        tool_error = tool_result.get("error", "")

        # Build output summary
        output_lines = []
        if tool_status == "success":
            output_lines.append("Analysis completed successfully.")
            output_lines.append(f"Findings detected: {len(tool_findings)}")
            if tool_findings:
                output_lines.append("")
                output_lines.append("Findings summary:")
                for i, f in enumerate(tool_findings[:10], 1):
                    sev = f.get("severity", "unknown").upper()
                    ftype = f.get("type", f.get("title", "unknown"))
                    loc = f.get("location", {})
                    line = loc.get("line", "?")
                    output_lines.append(f"  {i}. [{sev}] {ftype} (line {line})")
                if len(tool_findings) > 10:
                    output_lines.append(f"  ... and {len(tool_findings) - 10} more")
        elif tool_error:
            output_lines.append(f"Error: {tool_error}")
        else:
            output_lines.append(f"Status: {tool_status}")

        tool_outputs.append(
            {
                "name": tool_name,
                "duration": (
                    f"{tool_duration}s"
                    if isinstance(tool_duration, (int, float))
                    else str(tool_duration)
                ),
                "exit_code": 0 if tool_status == "success" else 1,
                "findings_count": len(tool_findings),
                "output": "\n".join(output_lines),
            }
        )

    variables["tool_outputs"] = tool_outputs

    # Interactive wizard mode
    if interactive and RICH_AVAILABLE:
        variables = _interactive_wizard(variables, console)
    variables["tools_success_count"] = sum(
        1 for t in tools_execution_summary if t["status"] == "Success"
    )
    variables["tools_failed_count"] = sum(
        1 for t in tools_execution_summary if t["status"] in ("Failed", "Error", "Timeout")
    )

    # =========================================================================
    # LLM Interpretation (if enabled)
    # =========================================================================
    if llm_interpret:
        info("LLM interpretation enabled - generating AI-powered insights...")
        try:
            from src.reports.llm_interpreter import LLMReportInterpreter

            # Get contract code if available
            contract_path = results.get("contract_path") or results.get("contract")
            contract_code = ""
            if contract_path:
                try:
                    contract_file = Path(contract_path)
                    if contract_file.exists():
                        contract_code = contract_file.read_text(encoding="utf-8")[
                            :10000
                        ]  # Limit to 10k chars
                except Exception:
                    pass

            interpreter = LLMReportInterpreter()

            if interpreter.is_available():
                variables["llm_enabled"] = True
                variables["llm_model"] = interpreter.config.model

                # Generate executive interpretation
                info("Generating executive summary interpretation...")
                exec_summary = interpreter.generate_executive_interpretation(
                    findings=findings,
                    summary=summary,
                    contract_name=results.get("contract", "Unknown"),
                )
                variables["llm_executive_summary"] = exec_summary

                # Generate risk narrative
                info("Generating risk narrative...")
                risk_narrative = interpreter.generate_risk_narrative(
                    summary=summary, findings=findings
                )
                variables["llm_risk_narrative"] = risk_narrative

                # Interpret critical findings
                critical_high = [
                    f for f in findings if f.get("severity", "").lower() in ("critical", "high")
                ]
                if critical_high:
                    info(f"Interpreting {len(critical_high[:5])} critical/high findings...")
                    interpreted = interpreter.interpret_critical_findings(
                        critical_findings=critical_high[:5], contract_code=contract_code  # Top 5
                    )
                    variables["llm_critical_interpretations"] = interpreted

                # Generate remediation priority
                if findings:
                    info("Generating remediation priority recommendations...")
                    priority = interpreter.suggest_remediation_priority(
                        findings=findings[:10]  # Top 10
                    )
                    variables["llm_remediation_priority"] = priority

                success("LLM interpretation complete!")
            else:
                warning("Ollama not available - skipping LLM interpretation")
                warning("Start Ollama with: ollama serve && ollama pull deepseek-coder:6.7b")

        except ImportError as e:
            warning(f"LLM interpreter not available: {e}")
        except Exception as e:
            warning(f"LLM interpretation failed: {e}")

    # =========================================================================
    # Profesional Template Processing
    # =========================================================================
    if template in ("profesional", "premium"):
        info("Generating premium report data (CVSS scores, risk matrix, etc.)...")
        try:
            from src.reports.risk_calculator import calculate_premium_risk_data

            # Enrich findings with category field for CVSS differentiation
            # The risk calculator uses finding["category"] to select CVSS vectors.
            # Many adapters store type info in "type", "check", or "canonical_category"
            # but not always in "category".
            for f in findings:
                if not f.get("category"):
                    f["category"] = (
                        f.get("canonical_category") or f.get("type") or f.get("check") or "unknown"
                    )

            # Calculate risk data
            risk_data = calculate_premium_risk_data(findings)

            # Post-process risk score: cap by severity band
            # Only reach 100 if there are CRITICAL findings
            raw_score = risk_data.get("overall_risk_score", 0)
            has_critical = critical_count > 0
            has_high = high_count > 0
            has_medium = medium_count > 0
            has_low = low_count > 0
            has_info_only = (
                info_count > 0
                and not has_low
                and not has_medium
                and not has_high
                and not has_critical
            )

            if not findings:
                capped_score = 0
            elif has_critical:
                capped_score = max(85, min(100, raw_score))
            elif has_high:
                capped_score = max(60, min(85, raw_score))
            elif has_medium:
                capped_score = max(40, min(60, raw_score))
            elif has_low:
                capped_score = max(20, min(40, raw_score))
            elif has_info_only:
                capped_score = max(10, min(20, raw_score))
            else:
                capped_score = min(20, raw_score)

            risk_data["overall_risk_score"] = capped_score

            # Update variables with risk data
            variables.update(
                {
                    "cvss_scores": risk_data.get("cvss_scores", []),
                    "risk_matrix": risk_data.get("risk_matrix", {}),
                    "overall_risk_score": risk_data.get("overall_risk_score", 0),
                    "deployment_recommendation": risk_data.get(
                        "deployment_recommendation", "CONDITIONAL"
                    ),
                    "deployment_justification": risk_data.get("deployment_justification", ""),
                    "deployment_recommendation_color": risk_data.get(
                        "deployment_recommendation_color", "#ff9800"
                    ),
                    "deployment_recommendation_bg": risk_data.get(
                        "deployment_recommendation_bg", "#fff8e1"
                    ),
                    "quick_wins": risk_data.get("quick_wins", []),
                    "effort_impact_matrix": risk_data.get("effort_impact_matrix", {}),
                    "critical_percent": risk_data.get("critical_percent", 0),
                    "high_percent": risk_data.get("high_percent", 0),
                    "medium_percent": risk_data.get("medium_percent", 0),
                    "low_percent": risk_data.get("low_percent", 0),
                    "info_percent": risk_data.get("info_percent", 0),
                }
            )

            # Calculate category summary
            categories: Dict[str, Any] = {}
            for f in findings:
                cat = f.get("category") or f.get("type", "General")
                if cat not in categories:
                    categories[cat] = {"count": 0, "severities": []}
                categories[cat]["count"] += 1
                categories[cat]["severities"].append(f.get("severity", "unknown").lower())

            category_summary = []
            for cat, data in sorted(categories.items(), key=lambda x: -x[1]["count"]):
                sev_counts: Dict[str, int] = {}
                for s in data["severities"]:
                    sev_counts[s] = sev_counts.get(s, 0) + 1
                breakdown = ", ".join([f"{v} {k}" for k, v in sorted(sev_counts.items())])
                category_summary.append(
                    {
                        "name": cat,
                        "count": data["count"],
                        "breakdown": breakdown,
                    }
                )
            variables["category_summary"] = category_summary

            # =================================================================
            # Generate SWC Registry Compliance
            # =================================================================
            SWC_MAPPING = {
                "reentrancy": ("SWC-107", "Reentrancy"),
                "reentrant": ("SWC-107", "Reentrancy"),
                "integer-overflow": ("SWC-101", "Integer Overflow and Underflow"),
                "overflow": ("SWC-101", "Integer Overflow and Underflow"),
                "underflow": ("SWC-101", "Integer Overflow and Underflow"),
                "unchecked-call": ("SWC-104", "Unchecked Call Return Value"),
                "unchecked-return": ("SWC-104", "Unchecked Call Return Value"),
                "tx-origin": ("SWC-115", "Authorization through tx.origin"),
                "tx.origin": ("SWC-115", "Authorization through tx.origin"),
                "access-control": ("SWC-105", "Unprotected Ether Withdrawal"),
                "delegatecall": ("SWC-112", "Delegatecall to Untrusted Callee"),
                "timestamp": ("SWC-116", "Block values as a proxy for time"),
                "block-timestamp": ("SWC-116", "Block values as a proxy for time"),
                "denial-of-service": ("SWC-113", "DoS with Failed Call"),
                "dos": ("SWC-113", "DoS with Failed Call"),
                "assembly": ("SWC-127", "Arbitrary Jump with Function Type Variable"),
                "uninitialized": ("SWC-109", "Uninitialized Storage Pointer"),
                "floating-pragma": ("SWC-103", "Floating Pragma"),
                "pragma": ("SWC-103", "Floating Pragma"),
                "outdated-compiler": ("SWC-102", "Outdated Compiler Version"),
                "solc-version": ("SWC-102", "Outdated Compiler Version"),
                "shadowing": ("SWC-119", "Shadowing State Variables"),
                "visibility": ("SWC-100", "Function Default Visibility"),
            }

            swc_found: Dict[str, Any] = {}
            for f in findings:
                f_type = (
                    (f.get("type") or f.get("check") or f.get("category") or "")
                    .lower()
                    .replace("_", "-")
                    .replace(" ", "-")
                )
                f_title = (f.get("title") or f.get("name") or "").lower()

                # Try to match by type or title
                for key, (swc_id, swc_title) in SWC_MAPPING.items():
                    if key in f_type or key in f_title:
                        if swc_id not in swc_found:
                            swc_found[swc_id] = {
                                "id": swc_id,
                                "title": swc_title,
                                "count": 0,
                                "status": "Found",
                                "status_icon": "⚠️",
                                "finding_ids": [],
                            }
                        swc_found[swc_id]["count"] += 1
                        swc_found[swc_id]["finding_ids"].append(
                            f"F{len(swc_found[swc_id]['finding_ids'])+1}"
                        )
                        break

            # Add common SWC entries that were checked but not found
            common_swc = [
                ("SWC-107", "Reentrancy"),
                ("SWC-101", "Integer Overflow and Underflow"),
                ("SWC-104", "Unchecked Call Return Value"),
                ("SWC-115", "Authorization through tx.origin"),
                ("SWC-103", "Floating Pragma"),
                ("SWC-102", "Outdated Compiler Version"),
            ]
            for swc_id, swc_title in common_swc:
                if swc_id not in swc_found:
                    swc_found[swc_id] = {
                        "id": swc_id,
                        "title": swc_title,
                        "count": 0,
                        "status": "Not Found",
                        "status_icon": "✅",
                        "finding_ids": "--",
                    }

            # Convert finding_ids list to string
            for swc in swc_found.values():
                if isinstance(swc["finding_ids"], list):
                    swc["finding_ids"] = (
                        ", ".join(swc["finding_ids"]) if swc["finding_ids"] else "--"
                    )

            variables["swc_mappings"] = sorted(swc_found.values(), key=lambda x: x["id"])

            # =================================================================
            # Generate OWASP Smart Contract Top 10 Compliance
            # =================================================================
            OWASP_MAPPING = {
                "reentrancy": (1, "SC01", "Reentrancy Attacks"),
                "access-control": (2, "SC02", "Access Control Vulnerabilities"),
                "arithmetic": (3, "SC03", "Arithmetic Issues"),
                "overflow": (3, "SC03", "Arithmetic Issues"),
                "unchecked": (4, "SC04", "Unchecked Return Values"),
                "dos": (5, "SC05", "Denial of Service"),
                "denial-of-service": (5, "SC05", "Denial of Service"),
                "randomness": (6, "SC06", "Bad Randomness"),
                "front-running": (7, "SC07", "Front-Running"),
                "timestamp": (8, "SC08", "Time Manipulation"),
                "short-address": (9, "SC09", "Short Address Attack"),
                "unknown-unknowns": (10, "SC10", "Unknown Unknowns"),
            }

            owasp_found: Dict[str, Any] = {}
            for f in findings:
                f_type = (
                    (f.get("type") or f.get("check") or f.get("category") or "")
                    .lower()
                    .replace("_", "-")
                )
                f_title = (f.get("title") or f.get("name") or "").lower()

                for key, (rank, owasp_id, owasp_category) in OWASP_MAPPING.items():
                    if key in f_type or key in f_title:
                        if owasp_id not in owasp_found:
                            owasp_found[owasp_id] = {
                                "rank": rank,
                                "id": owasp_id,
                                "category": owasp_category,
                                "count": 0,
                                "status": "Found",
                                "status_icon": "⚠️",
                            }
                        owasp_found[owasp_id]["count"] += 1
                        break

            # Add top OWASP entries that were checked
            top_owasp = [
                (1, "SC01", "Reentrancy Attacks"),
                (2, "SC02", "Access Control Vulnerabilities"),
                (3, "SC03", "Arithmetic Issues"),
                (4, "SC04", "Unchecked Return Values"),
                (5, "SC05", "Denial of Service"),
            ]
            for rank, owasp_id, owasp_category in top_owasp:
                if owasp_id not in owasp_found:
                    owasp_found[owasp_id] = {
                        "rank": rank,
                        "id": owasp_id,
                        "category": owasp_category,
                        "count": 0,
                        "status": "Not Found",
                        "status_icon": "✅",
                    }

            variables["owasp_mappings"] = sorted(owasp_found.values(), key=lambda x: x["rank"])

            # Add layer coverage bars
            for layer in variables.get("layer_summary", []):
                success_count = layer.get("success_count", 0)
                failed_count = layer.get("failed_count", 0)
                total = success_count + failed_count
                if total > 0:
                    percentage = int(success_count / total * 100)
                    bar = "█" * (percentage // 10) + "░" * (10 - percentage // 10)
                    layer["coverage_bar"] = f"{bar} {percentage}%"
                else:
                    layer["coverage_bar"] = "░░░░░░░░░░ N/A"

            # If LLM is enabled and premium, use premium insights
            if llm_interpret and variables.get("llm_enabled"):
                try:
                    from src.reports.llm_interpreter import generate_premium_report_insights

                    info(
                        "Generating premium LLM insights (attack scenarios, deployment recommendation)..."
                    )

                    # Get contract code if available
                    contract_path = results.get("contract_path") or results.get("contract")
                    contract_code = ""
                    if contract_path:
                        try:
                            contract_file = Path(contract_path)
                            if contract_file.exists():
                                contract_code = contract_file.read_text(encoding="utf-8")[:10000]
                        except Exception:
                            pass

                    premium_insights = generate_premium_report_insights(
                        findings=findings,
                        summary=summary,
                        contract_name=results.get("contract", "Unknown"),
                        contract_code=contract_code,
                    )

                    if premium_insights.get("available"):
                        # LLM deployment recommendation - only allow stricter recommendations
                        # Severity order: NO-GO > CONDITIONAL > GO
                        if premium_insights.get("deployment_recommendation"):
                            llm_rec = premium_insights["deployment_recommendation"]
                            calc_rec = variables.get("deployment_recommendation", "GO")
                            severity_order = {"NO-GO": 3, "CONDITIONAL": 2, "GO": 1}

                            # Only use LLM recommendation if it's stricter (or equal)
                            llm_severity = severity_order.get(llm_rec, 1)
                            calc_severity = severity_order.get(calc_rec, 1)

                            if llm_severity >= calc_severity:
                                variables["deployment_recommendation"] = llm_rec
                                variables["deployment_justification"] = premium_insights.get(
                                    "deployment_justification", ""
                                )
                            else:
                                # Keep calculated recommendation, but add LLM justification as note
                                existing_just = variables.get("deployment_justification", "")
                                if existing_just:
                                    variables["deployment_justification"] = existing_just

                        # Add attack scenarios
                        if premium_insights.get("attack_scenarios"):
                            variables["attack_scenarios"] = premium_insights["attack_scenarios"]

                        # Add code remediations
                        if premium_insights.get("code_remediations"):
                            variables["code_remediations"] = premium_insights["code_remediations"]

                        # Update remediation priority with effort
                        if premium_insights.get("remediation_priority"):
                            variables["llm_remediation_priority"] = premium_insights[
                                "remediation_priority"
                            ]

                        success("Profesional LLM insights generated!")

                except Exception as e:
                    warning(f"Profesional LLM insights failed: {e}")

            success("Profesional report data generated!")

        except ImportError as e:
            warning(f"Risk calculator not available: {e}")
        except Exception as e:
            warning(f"Profesional report processing failed: {e}")

    # =========================================================================
    # Proof of Concept Generation (for Critical/High findings)
    # =========================================================================
    if template in ("profesional", "premium"):
        try:
            from src.poc.poc_generator import PoCGenerator

            poc_generator = PoCGenerator()
            contract_name_for_poc = (
                results.get("contract")
                or results.get("contract_path")
                or results.get("path")
                or "Unknown"
            )
            # For batch format, strip trailing slash from directory path
            if contract_name_for_poc.endswith("/"):
                contract_name_for_poc = "Unknown"

            critical_high_for_poc = [
                f
                for f in findings
                if f.get("severity", "").lower() in ("critical", "high") and f.get("type")
            ]

            if critical_high_for_poc:
                info(
                    f"Generating PoC exploits for {len(critical_high_for_poc)} critical/high findings..."
                )
                for finding in critical_high_for_poc:
                    try:
                        # Use per-finding source_contract (batch) or global contract name
                        target = finding.get("source_contract") or contract_name_for_poc
                        # Fix #11: If target is still "Unknown", try to extract
                        # the contract name from the finding's location
                        if target == "Unknown":
                            loc = finding.get("location", {})
                            if isinstance(loc, dict) and loc.get("file"):
                                target = loc["file"]
                            elif isinstance(loc, str) and ":" in loc:
                                target = loc.split(":")[0]
                        poc = poc_generator.generate(finding, target_contract=target)
                        finding["poc"] = poc.solidity_code
                        finding["poc_available"] = True
                        finding["poc_name"] = poc.name
                        finding["poc_prerequisites"] = poc.prerequisites
                        finding["poc_expected_outcome"] = poc.expected_outcome
                    except Exception as e:
                        logger.debug(f"PoC generation failed for {finding.get('type')}: {e}")

                poc_count = sum(1 for f in critical_high_for_poc if f.get("poc_available"))
                if poc_count:
                    success(f"Generated {poc_count} PoC exploit templates")
        except ImportError:
            logger.debug("PoCGenerator not available")
        except Exception as e:
            warning(f"PoC generation failed: {e}")

    # Prepare findings for template
    formatted_findings = []
    for i, finding in enumerate(findings, 1):
        # Handle location (can be string or dict)
        location = finding.get("location", {})
        if isinstance(location, dict):
            loc_str = f"{location.get('file', 'unknown')}:{location.get('line', '?')}"
            if location.get("function"):
                loc_str += f" ({location.get('function')})"
        else:
            loc_str = str(location) if location else "unknown"

        # Get title from various possible fields
        title_field = (
            finding.get("title") or finding.get("type") or finding.get("message", "Unknown")[:50]
        )

        # Get category from swc_id, owasp_category, or type
        category = (
            finding.get("category")
            or finding.get("owasp_category")
            or finding.get("swc_id")
            or finding.get("type", "general")
        )

        # Severity display helpers for premium template
        severity_lower = finding.get("severity", "unknown").lower()
        severity_badges = {
            "critical": "**CRITICAL**",
            "high": "**HIGH**",
            "medium": "MEDIUM",
            "low": "LOW",
            "info": "INFO",
            "informational": "INFO",
        }
        severity_colors = {
            "critical": "#dc3545",
            "high": "#fd7e14",
            "medium": "#ffc107",
            "low": "#28a745",
            "info": "#17a2b8",
            "informational": "#17a2b8",
        }

        # Get CVSS score if available
        cvss_score = None
        for score in variables.get("cvss_scores", []):
            if score.get("title") == title_field or score.get("finding_id") == f"F-{i:03d}":
                cvss_score = score.get("base_score")
                break

        # Get attack scenario — first from global list, then from intelligence engine
        attack_scenario = None
        attack_steps = []
        for scenario in variables.get("attack_scenarios", []):
            if scenario.get("title") == title_field:
                attack_scenario = scenario.get("scenario_description")
                attack_steps = scenario.get("attack_steps", scenario.get("steps", []))
                break
        # v5.2.0: fallback to intelligence engine's exploit_scenario field
        if not attack_steps and finding.get("exploit_scenario"):
            attack_steps = finding["exploit_scenario"]
            attack_scenario = attack_steps[0] if attack_steps else None

        # Get code remediation — first from global list, then from intelligence engine
        remediation_code = None
        remediation_effort = None
        fix_time = None
        for remediation in variables.get("code_remediations", []):
            if remediation.get("title") == title_field:
                remediation_code = remediation.get("diff")
                remediation_effort = remediation.get("effort")
                fix_time = remediation.get("fix_time")
                break
        # v5.2.0: fallback to intelligence engine's fix_code field
        if not remediation_code and finding.get("fix_code"):
            remediation_code = finding["fix_code"]

        # Fix #5: Default remediation effort and fix_time based on severity
        severity_effort_map = {
            "critical": ("Immediate (1-2 hours)", "1-2 hours"),
            "high": ("Immediate (1-2 hours)", "1-2 hours"),
            "medium": ("Short-term (2-4 hours)", "2-4 hours"),
            "low": ("Low priority (optional)", "Optional"),
            "info": ("N/A (informational only)", "N/A"),
            "informational": ("N/A (informational only)", "N/A"),
        }
        if not remediation_effort:
            effort_tuple = severity_effort_map.get(severity_lower, ("Medium", "1-2 hours"))
            remediation_effort = effort_tuple[0]
        if not fix_time:
            effort_tuple = severity_effort_map.get(severity_lower, ("Medium", "1-2 hours"))
            fix_time = effort_tuple[1]

        # Fix #4: Detected By — use confirming_tools if available
        confirming = finding.get("confirming_tools", [])
        if confirming:
            detected_by = ", ".join(confirming)
        else:
            raw_tool = finding.get("tool", "unknown")
            if raw_tool == "miesc-intelligence":
                # Fall back to any tool info from the finding itself
                detected_by = finding.get("original_tool", raw_tool)
            else:
                detected_by = raw_tool

        # Fix #10: Include confidence in status display
        raw_status = finding.get("status", "Open")
        confidence_val = finding.get("confidence")
        if isinstance(confidence_val, (int, float)) and confidence_val > 0:
            conf_display = f"{confidence_val:.0%}"
            status_display = f"{raw_status} ({conf_display} conf.)"
        else:
            status_display = raw_status

        formatted_findings.append(
            {
                "id": f"F-{i:03d}",
                "title": title_field,
                "severity": severity_lower,
                "severity_badge": severity_badges.get(severity_lower, severity_lower.upper()),
                "severity_color": severity_colors.get(severity_lower, "#6c757d"),
                "category": category,
                "location": loc_str,
                "description": finding.get("description", finding.get("message", "")),
                "recommendation": (
                    _get_recommendation(category, severity_lower)
                    if not finding.get("recommendation")
                    or finding.get("recommendation", "").startswith("Review and fix")
                    else finding["recommendation"]
                ),
                "tool": detected_by,
                "status": status_display,
                "impact": (
                    _get_impact_description(severity_lower, category)
                    if not finding.get("impact")
                    or finding.get("impact", "").startswith("Significant financial")
                    or finding.get("impact", "").startswith("Minor impact")
                    else finding["impact"]
                ),
                "poc": finding.get("poc", ""),
                "vulnerable_code": finding.get("vulnerable_code")
                or _extract_source_code(
                    (
                        finding.get("location", {}).get("file", "")
                        if isinstance(finding.get("location"), dict)
                        else str(finding.get("location", "")).split(":")[0]
                    ),
                    (
                        finding.get("location", {}).get("line", 0)
                        if isinstance(finding.get("location"), dict)
                        else (
                            int(str(finding.get("location", "0")).split(":")[-1].split(" ")[0] or 0)
                            if ":" in str(finding.get("location", ""))
                            else 0
                        )
                    ),
                    base_dir=detected_contract_full_path,
                )
                or "// Source code not available for this finding",
                "references": finding.get("references")
                or _get_swc_references(
                    category, finding.get("swc_id", finding.get("category", ""))
                ),
                # Premium fields
                "cvss_score": cvss_score,
                "attack_scenario": attack_scenario,
                "attack_steps": attack_steps,
                "remediation_code": remediation_code,
                "remediation_effort": remediation_effort,
                "fix_time": fix_time,
                "llm_interpretation": finding.get("llm_interpretation", ""),
                # Intelligence engine fields (v5.2.0)
                "confidence": finding.get("confidence", 0.5),
                "confidence_pct": (
                    f"{finding.get('confidence', 0.5):.0%}"
                    if isinstance(finding.get("confidence"), (int, float))
                    else ""
                ),
                "canonical_category": finding.get("canonical_category", ""),
                "confirming_tools": finding.get("confirming_tools", []),
                "tool_count": finding.get("tool_count", 1),
                "cross_validated_static": finding.get("cross_validated_static", False),
                "cross_validated_llm": finding.get("cross_validated_llm", False),
                # PoC fields
                "poc_available": finding.get("poc_available", False),
                "poc_name": finding.get("poc_name", ""),
                "poc_prerequisites": finding.get("poc_prerequisites", []),
                "poc_expected_outcome": finding.get("poc_expected_outcome", ""),
            }
        )

    variables["findings"] = formatted_findings
    variables["critical_high_findings"] = [
        f for f in formatted_findings if f["severity"] in ("critical", "high")
    ]
    variables["medium_low_findings"] = [
        f for f in formatted_findings if f["severity"] in ("medium", "low")
    ]

    # Simple template rendering (basic variable substitution)
    output_content = _render_template(template_content, variables)

    # Handle output
    if output:
        output_path = Path(output)

        if output_format == "html":
            output_content = _markdown_to_html(output_content, title or "MIESC Security Report")
        elif output_format == "pdf":
            # Generate PDF from HTML using weasyprint (preferred) or pandoc fallback
            html_content = _markdown_to_html(output_content, title or "MIESC Security Report")
            pdf_generated = False

            # Try weasyprint first (available in Docker image)
            try:
                from weasyprint import CSS, HTML
                from weasyprint.text.fonts import FontConfiguration

                info("Generating PDF with WeasyPrint...")
                font_config = FontConfiguration()

                # Load premium CSS if available
                css_path = ROOT_DIR / "docs" / "templates" / "reports" / "profesional.css"
                if css_path.exists():
                    css_content = css_path.read_text(encoding="utf-8")
                    css = CSS(string=css_content, font_config=font_config)
                    HTML(string=html_content).write_pdf(
                        output_path, stylesheets=[css], font_config=font_config
                    )
                else:
                    HTML(string=html_content).write_pdf(output_path)

                pdf_generated = True
                success(f"PDF report saved to {output_path}")
                return
            except ImportError:
                info("WeasyPrint not available, trying pandoc...")
            except Exception as e:
                warning(f"WeasyPrint PDF generation failed: {e}")

            # Fallback to pandoc
            if not pdf_generated:
                try:
                    import subprocess

                    temp_html = output_path.with_suffix(".tmp.html")
                    temp_html.write_text(html_content, encoding="utf-8")
                    subprocess.run(
                        [
                            "pandoc",
                            str(temp_html),
                            "-o",
                            str(output_path),
                            "--pdf-engine=wkhtmltopdf",
                        ],
                        check=True,
                        capture_output=True,
                    )
                    temp_html.unlink()
                    success(f"PDF report saved to {output_path}")
                    return
                except FileNotFoundError:
                    warning(
                        "PDF generation requires weasyprint or pandoc. "
                        "Install with: pip install weasyprint"
                    )
                    output_path = output_path.with_suffix(".html")
                    output_content = html_content
                    warning(f"Saved as HTML instead: {output_path}")
                except subprocess.CalledProcessError as e:
                    warning(f"PDF generation failed: {e}")
                    output_path = output_path.with_suffix(".html")
                    output_content = html_content
                    warning(f"Saved as HTML instead: {output_path}")

        output_path.write_text(output_content, encoding="utf-8")
        success(f"Report saved to {output_path}")
    else:
        # Output to stdout
        print(output_content)  # noqa: T201

    # Summary
    if RICH_AVAILABLE and output:
        console.print(
            f"\n[bold]Report Summary:[/bold] "
            f"[red]{variables['critical_count']}[/red] critical, "
            f"[red]{variables['high_count']}[/red] high, "
            f"[yellow]{variables['medium_count']}[/yellow] medium, "
            f"[cyan]{variables['low_count']}[/cyan] low"
        )
