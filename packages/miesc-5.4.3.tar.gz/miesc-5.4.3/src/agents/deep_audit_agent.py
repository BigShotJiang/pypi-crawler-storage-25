"""
MIESC Deep Audit Agent - Agentic Security Analysis

Implements a 4-phase iterative audit loop:
  Phase 1: Reconnaissance (call graph, taint, risk profiling)
  Phase 2: Targeted Scan (adaptive tool selection)
  Phase 3: Deep Investigation (agentic loop with RAG enrichment)
  Phase 4: Synthesis (correlation, exploit chains, LLM narrative)

DPGA Compliant: 100% local execution, no telemetry, privacy-preserving.
Ollama/Claude API are optional - graceful degradation to ML-only.

Author: Fernando Boiero
License: AGPL-3.0
"""

import logging
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from src.agents.base_agent import BaseAgent

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class DeepAuditConfig:
    """Configuration for the agentic deep audit.

    LLM priority (local-first, cloud optional):
      1. Ollama (local) - default, DPGA compliant
      2. Anthropic Claude API - if ANTHROPIC_API_KEY set
      3. OpenAI API - if OPENAI_API_KEY set
      4. No LLM - graceful degradation to template narrative
    """

    timeout_seconds: int = 600
    max_iterations: int = 5
    min_severity_for_deep: str = "high"
    enable_llm: bool = True
    llm_provider: str = "auto"  # "auto", "ollama", "anthropic", "openai"
    llm_model: str = "mistral:latest"
    enable_rag: bool = True
    enable_taint: bool = True
    enable_call_graph: bool = True
    enable_exploit_chains: bool = True
    fp_threshold: float = 0.5
    max_workers: int = 4


class AuditPhase(Enum):
    RECONNAISSANCE = "reconnaissance"
    TARGETED_SCAN = "targeted_scan"
    DEEP_INVESTIGATION = "deep_investigation"
    SYNTHESIS = "synthesis"


# ---------------------------------------------------------------------------
# Internal result dataclasses
# ---------------------------------------------------------------------------


@dataclass
class ReconResult:
    """Phase 1 output."""

    call_graph: Any = None
    taint_results: List[Any] = field(default_factory=list)
    risk_profile: Dict[str, Any] = field(default_factory=dict)
    entry_points: List[str] = field(default_factory=list)
    external_calls: List[str] = field(default_factory=list)
    attack_surface_score: float = 0.0
    framework: str = "unknown"
    duration_ms: float = 0.0


@dataclass
class ScanResult:
    """Phase 2 output."""

    tools_run: List[str] = field(default_factory=list)
    tools_available: List[str] = field(default_factory=list)
    raw_findings: List[Dict[str, Any]] = field(default_factory=list)
    filtered_findings: List[Dict[str, Any]] = field(default_factory=list)
    severity_distribution: Dict[str, int] = field(default_factory=dict)
    duration_ms: float = 0.0


# ---------------------------------------------------------------------------
# Risk Profile Patterns
# ---------------------------------------------------------------------------

RISK_PATTERNS = {
    "defi": [
        r"\bswap\b",
        r"\bliquidity\b",
        r"\bpool\b",
        r"\boracle\b",
        r"\bflash\s*loan\b",
        r"\bprice\b",
        r"\bamm\b",
        r"\bvault\b",
        r"\byield\b",
        r"\bstake\b",
        r"\blend\b",
        r"\bborrow\b",
    ],
    "token": [
        r"\bTransfer\b",
        r"\bApproval\b",
        r"\bbalanceOf\b",
        r"\btotalSupply\b",
        r"\bmint\b",
        r"\bburn\b",
        r"\bERC20\b",
        r"\bERC721\b",
        r"\bERC1155\b",
    ],
    "proxy": [
        r"\bdelegatecall\b",
        r"\bimplementation\b",
        r"\bupgradeTo\b",
        r"\bUUPS\b",
        r"\bBeacon\b",
        r"\bTransparentProxy\b",
        r"\bInitializable\b",
    ],
    "bridge": [
        r"\block\b.*\bunlock\b",
        r"\brelay\b",
        r"\bcrosschain\b",
        r"\bmessage\b.*\bpass\b",
        r"\bbridge\b",
        r"\bwormhole\b",
    ],
}


# ---------------------------------------------------------------------------
# DeepAuditAgent
# ---------------------------------------------------------------------------


class DeepAuditAgent(BaseAgent):
    """
    Agentic deep audit agent with iterative investigation loop.

    Unlike ``audit smart`` which runs a fixed set of tools, this agent:
    - Analyzes contract structure before selecting tools
    - Adaptively chooses tools based on risk profile
    - Iteratively investigates HIGH/CRITICAL findings
    - Enriches findings with RAG vulnerability knowledge
    - Detects exploit chains across findings
    - Generates LLM narrative (local Ollama, optional Claude API)
    """

    def __init__(self, config: Optional[DeepAuditConfig] = None):
        super().__init__(
            agent_name="DeepAuditAgent",
            capabilities=[
                "agentic_audit",
                "adaptive_tool_selection",
                "iterative_investigation",
                "rag_enrichment",
                "exploit_chain_detection",
            ],
            agent_type="coordinator",
        )
        self.config = config or DeepAuditConfig()
        self._start_time: float = 0.0
        self._current_phase = AuditPhase.RECONNAISSANCE

    def get_context_types(self) -> List[str]:
        return [
            "deep_audit_reconnaissance",
            "deep_audit_initial_findings",
            "deep_audit_enriched_findings",
            "deep_audit_report",
        ]

    # -----------------------------------------------------------------------
    # Main entry point
    # -----------------------------------------------------------------------

    def analyze(self, contract_path: str, **kwargs) -> Dict[str, Any]:
        """Run the 4-phase agentic deep audit."""
        self._start_time = time.monotonic()
        self.contract_path = contract_path
        source_code = Path(contract_path).read_text()

        logger.info(f"DeepAuditAgent starting on {contract_path}")
        report = {
            "contract": contract_path,
            "agent": "DeepAuditAgent",
            "phases": {},
            "findings": [],
            "exploit_chains": [],
            "metadata": {"config": self.config.__dict__.copy()},
        }

        # Phase 1: Reconnaissance
        self._current_phase = AuditPhase.RECONNAISSANCE
        logger.info("Phase 1: Reconnaissance")
        recon = self._phase_reconnaissance(contract_path, source_code)
        report["phases"]["reconnaissance"] = {
            "risk_profile": recon.risk_profile,
            "entry_points": recon.entry_points[:10],
            "attack_surface_score": recon.attack_surface_score,
            "framework": recon.framework,
            "duration_ms": recon.duration_ms,
        }
        self.publish_findings("deep_audit_reconnaissance", report["phases"]["reconnaissance"])

        if self._timeout_exceeded():
            report["metadata"]["timed_out_in"] = "reconnaissance"
            return report

        # Phase 2: Targeted Scan
        self._current_phase = AuditPhase.TARGETED_SCAN
        logger.info("Phase 2: Targeted Scan")
        scan = self._phase_targeted_scan(contract_path, recon)
        report["phases"]["targeted_scan"] = {
            "tools_run": scan.tools_run,
            "raw_count": len(scan.raw_findings),
            "filtered_count": len(scan.filtered_findings),
            "severity_distribution": scan.severity_distribution,
            "duration_ms": scan.duration_ms,
        }
        self.publish_findings(
            "deep_audit_initial_findings",
            {
                "findings": scan.filtered_findings,
                "tools_run": scan.tools_run,
            },
        )

        if self._timeout_exceeded():
            report["findings"] = scan.filtered_findings
            report["metadata"]["timed_out_in"] = "targeted_scan"
            return report

        # Phase 3: Deep Investigation (agentic loop)
        self._current_phase = AuditPhase.DEEP_INVESTIGATION
        logger.info("Phase 3: Deep Investigation (agentic loop)")
        investigation = self._phase_deep_investigation(contract_path, source_code, recon, scan)
        report["phases"]["deep_investigation"] = {
            "iterations": investigation.get("iterations", 0),
            "findings_enriched": investigation.get("enriched_count", 0),
            "additional_tools": investigation.get("additional_tools", []),
            "chains_detected": len(investigation.get("exploit_chains", [])),
            "mitigated": investigation.get("mitigated_count", 0),
            # Bloque 3 counters — expose the new Phase 3 metrics in the top-level report
            "properties_generated": investigation.get("properties_generated", 0),
            "defi_confirmed": investigation.get("defi_confirmed_count", 0),
            "needs_manual_review": investigation.get("needs_manual_review_count", 0),
        }

        if self._timeout_exceeded():
            report["findings"] = investigation.get("findings", scan.filtered_findings)
            report["exploit_chains"] = investigation.get("exploit_chains", [])
            report["metadata"]["timed_out_in"] = "deep_investigation"
            return report

        # Phase 4: Synthesis
        self._current_phase = AuditPhase.SYNTHESIS
        logger.info("Phase 4: Synthesis")
        synthesis = self._phase_synthesis(contract_path, source_code, recon, scan, investigation)
        report["findings"] = synthesis.get("findings", [])
        report["exploit_chains"] = synthesis.get("exploit_chains", [])
        report["phases"]["synthesis"] = {
            "final_count": len(report["findings"]),
            "chains": len(report["exploit_chains"]),
            "llm_narrative": synthesis.get("has_llm_narrative", False),
        }
        report["summary"] = synthesis.get("summary", {})
        report["narrative"] = synthesis.get("narrative", "")

        self.publish_findings("deep_audit_report", report)

        elapsed = (time.monotonic() - self._start_time) * 1000
        report["metadata"]["total_duration_ms"] = elapsed
        logger.info(
            f"DeepAuditAgent complete: {len(report['findings'])} findings, "
            f"{len(report['exploit_chains'])} chains, {elapsed:.0f}ms"
        )
        return report

    # -----------------------------------------------------------------------
    # Phase 1: Reconnaissance
    # -----------------------------------------------------------------------

    def _phase_reconnaissance(self, contract_path: str, source_code: str) -> ReconResult:
        t0 = time.monotonic()
        result = ReconResult()

        # Call graph analysis
        if self.config.enable_call_graph:
            result.call_graph, result.entry_points, result.external_calls = self._build_call_graph(
                source_code
            )

        # Taint analysis
        if self.config.enable_taint:
            result.taint_results = self._run_taint_analysis(source_code)

        # Risk profiling
        result.risk_profile = self._classify_risk_profile(source_code)

        # Framework detection
        result.framework = self._detect_framework(contract_path)

        # Attack surface score
        result.attack_surface_score = self._compute_attack_surface(
            result.entry_points, result.external_calls, result.taint_results
        )

        result.duration_ms = (time.monotonic() - t0) * 1000
        logger.info(
            f"Recon complete: profile={result.risk_profile.get('primary', 'general')}, "
            f"entries={len(result.entry_points)}, surface={result.attack_surface_score:.1f}"
        )
        return result

    def _build_call_graph(self, source_code: str):
        """Build call graph and extract entry points."""
        try:
            from src.ml.call_graph import CallGraphBuilder

            builder = CallGraphBuilder()
            cg = builder.build_from_source(source_code)
            entries = (
                [n.name for n in cg.get_entry_points()] if hasattr(cg, "get_entry_points") else []
            )
            ext_calls = []
            if hasattr(cg, "external_call_chains"):
                for chain in cg.external_call_chains():
                    ext_calls.extend([str(c) for c in chain[:2]])
            return cg, entries, ext_calls[:20]
        except Exception as e:
            logger.debug(f"Call graph analysis failed: {e}")
            return None, [], []

    def _run_taint_analysis(self, source_code: str):
        """Run taint analysis to find data flow vulnerabilities."""
        try:
            from src.ml.taint_analysis import TaintAnalyzer

            analyzer = TaintAnalyzer()
            return analyzer.analyze(source_code)
        except Exception as e:
            logger.debug(f"Taint analysis failed: {e}")
            return []

    def _classify_risk_profile(self, source_code: str) -> Dict[str, Any]:
        """Classify contract risk profile based on code patterns."""
        scores: Dict[str, int] = {}
        code_lower = source_code.lower()
        for profile, patterns in RISK_PATTERNS.items():
            count = sum(1 for p in patterns if re.search(p, code_lower))
            if count > 0:
                scores[profile] = count

        primary = max(scores, key=scores.get) if scores else "general"
        return {
            "primary": primary,
            "scores": scores,
            "is_defi": scores.get("defi", 0) >= 2,
            "is_token": scores.get("token", 0) >= 2,
            "is_proxy": scores.get("proxy", 0) >= 1,
            "is_bridge": scores.get("bridge", 0) >= 1,
            "has_external_calls": bool(
                re.search(r"\.call\{|\.delegatecall|\.send\(|\.transfer\(", source_code)
            ),
            "has_selfdestruct": "selfdestruct" in code_lower,
            "has_assembly": "assembly" in code_lower,
            "solidity_version": self._extract_solidity_version(source_code),
        }

    def _extract_solidity_version(self, source_code: str) -> str:
        m = re.search(r"pragma\s+solidity\s+([^;]+)", source_code)
        return m.group(1).strip() if m else "unknown"

    def _detect_framework(self, contract_path: str) -> str:
        """Detect if contract uses known frameworks."""
        try:
            code = Path(contract_path).read_text()
            if "@openzeppelin" in code:
                return "openzeppelin"
            if "solmate" in code:
                return "solmate"
            if "solady" in code:
                return "solady"
        except Exception:
            pass
        return "custom"

    def _compute_attack_surface(
        self, entries: List[str], ext_calls: List[str], taint: list
    ) -> float:
        """Compute attack surface score 0-100."""
        score = min(len(entries) * 5, 30)
        score += min(len(ext_calls) * 10, 40)
        score += min(len(taint) * 5, 30) if isinstance(taint, list) else 0
        return min(score, 100.0)

    # -----------------------------------------------------------------------
    # Phase 2: Targeted Scan
    # -----------------------------------------------------------------------

    def _phase_targeted_scan(self, contract_path: str, recon: ReconResult) -> ScanResult:
        t0 = time.monotonic()
        result = ScanResult()

        # Select tools based on risk profile
        selected_tools = self._select_tools(recon)
        result.tools_run = selected_tools

        logger.info(
            f"Selected tools for profile '{recon.risk_profile.get('primary')}': {selected_tools}"
        )

        # Use MLOrchestrator for reliable tool execution (same as audit smart)
        ml_orch = self._get_ml_orchestrator()
        if ml_orch:
            try:
                timeout_per_tool = int(
                    self._remaining_seconds() * 0.7 / max(len(selected_tools), 1)
                )
                ml_result = ml_orch.analyze(
                    contract_path=contract_path,
                    tools=selected_tools,
                    timeout=max(timeout_per_tool, 30),
                )
                result.raw_findings = (
                    ml_result.raw_findings if hasattr(ml_result, "raw_findings") else []
                )
                result.filtered_findings = (
                    ml_result.ml_filtered_findings
                    if hasattr(ml_result, "ml_filtered_findings")
                    else result.raw_findings
                )
                result.tools_run = (
                    ml_result.tools_success
                    if hasattr(ml_result, "tools_success")
                    else selected_tools
                )
            except Exception as e:
                logger.warning(f"MLOrchestrator failed, falling back to direct execution: {e}")
                result.raw_findings = self._run_tools_parallel(selected_tools, contract_path)
                result.filtered_findings = self._filter_false_positives(result.raw_findings)
        else:
            # Fallback: direct adapter execution
            result.raw_findings = self._run_tools_parallel(selected_tools, contract_path)
            result.filtered_findings = self._filter_false_positives(result.raw_findings)

        # v5.2.0: Intelligence engine — cross-tool scoring, semantic dedup,
        # zero-recall pattern detection, context-aware FP suppression,
        # LLM↔static cross-validation, severity calibration.
        try:
            from src.core.intelligence import enhance_findings

            if result.filtered_findings:
                try:
                    code_text = open(contract_path).read()
                except Exception:
                    code_text = ""
                # Pass only the filename (not full path) to avoid false test-file
                # suppression when the contract lives under a directory that
                # contains "test" in its name (e.g. pytest tmp dirs).
                enhanced = enhance_findings(
                    result.filtered_findings,
                    source_code=code_text,
                    file_path=Path(contract_path).name,
                )
                non_suppressed = [f for f in enhanced if not f.get("fp_suppressed")]
                suppressed_count = sum(1 for f in enhanced if f.get("fp_suppressed"))
                deduped = len(result.filtered_findings) - len(enhanced)
                result.filtered_findings = non_suppressed
                if suppressed_count > 0:
                    logger.info(
                        f"Intelligence engine: suppressed {suppressed_count} likely false positives"
                    )
                if deduped > 0:
                    logger.info(
                        f"Intelligence engine: merged {deduped} duplicate findings across tools"
                    )
        except Exception as e:
            logger.debug(f"Intelligence engine skipped in Phase 2: {e}")

        # Severity distribution
        for f in result.filtered_findings:
            sev = f.get("severity", "unknown").lower()
            result.severity_distribution[sev] = result.severity_distribution.get(sev, 0) + 1

        result.duration_ms = (time.monotonic() - t0) * 1000
        logger.info(
            f"Scan complete: {len(result.tools_run)} tools, "
            f"{len(result.raw_findings)} raw -> {len(result.filtered_findings)} filtered"
        )
        return result

    def _get_ml_orchestrator(self):
        """Get MLOrchestrator instance (same as audit smart)."""
        try:
            from miesc.cli.utils import get_ml_orchestrator

            return get_ml_orchestrator()
        except Exception:
            try:
                from src.core.ml_orchestrator import MLOrchestrator

                return MLOrchestrator()
            except Exception:
                return None

    def _select_tools(self, recon: ReconResult) -> List[str]:
        """Adaptively select tools based on risk profile."""
        tools = ["slither", "aderyn"]
        profile = recon.risk_profile

        if profile.get("is_defi"):
            tools.extend(["defi", "mev_detector"])
        if profile.get("is_token"):
            tools.append("advanced_detector")
        if profile.get("is_proxy"):
            tools.append("upgradability_checker")
        if profile.get("is_bridge"):
            tools.extend(["crosschain", "bridge_monitor"])
        if profile.get("has_external_calls"):
            tools.append("mythril")
        if profile.get("has_selfdestruct"):
            tools.append("mythril")
        if profile.get("has_assembly"):
            tools.append("halmos")

        # Deduplicate preserving order
        seen: Set[str] = set()
        unique = []
        for t in tools:
            if t not in seen:
                seen.add(t)
                unique.append(t)
        return unique

    def _get_available_tools(self) -> List[str]:
        """Get list of actually available/installed tools."""
        try:
            from miesc.cli.utils import load_adapters

            adapters = load_adapters()
            available = []
            for name, adapter in adapters.items():
                try:
                    if hasattr(adapter, "is_available") and adapter.is_available():
                        available.append(name)
                    else:
                        available.append(name)
                except Exception:
                    pass
            return available
        except Exception:
            return ["slither", "aderyn"]

    def _run_tools_parallel(self, tools: List[str], contract_path: str) -> List[Dict[str, Any]]:
        """Run multiple tools in parallel and collect findings."""
        all_findings: List[Dict[str, Any]] = []
        remaining = self._remaining_seconds() * 0.8

        try:
            from miesc.cli.utils import load_adapters

            adapters = load_adapters()
        except Exception as e:
            logger.warning(f"Could not load adapters: {e}")
            return []

        timeout_per_tool = max(30, remaining / max(len(tools), 1))

        with ThreadPoolExecutor(max_workers=self.config.max_workers) as executor:
            futures = {}
            for tool_name in tools:
                adapter = adapters.get(tool_name)
                if not adapter:
                    continue
                future = executor.submit(
                    self._run_single_tool, adapter, tool_name, contract_path, timeout_per_tool
                )
                futures[future] = tool_name

            for future in as_completed(futures, timeout=remaining):
                tool_name = futures[future]
                try:
                    findings = future.result(timeout=10)
                    for f in findings:
                        f["tool"] = tool_name
                    all_findings.extend(findings)
                except Exception as e:
                    logger.debug(f"Tool {tool_name} failed: {e}")

        return all_findings

    def _run_single_tool(
        self, adapter, tool_name: str, contract_path: str, timeout: float
    ) -> List[Dict[str, Any]]:
        """Run a single tool adapter and return normalized findings."""
        try:
            result = adapter.analyze(contract_path, timeout=int(timeout))
            findings = result.get("findings", []) if isinstance(result, dict) else []
            return findings if isinstance(findings, list) else []
        except Exception as e:
            logger.debug(f"{tool_name} error: {e}")
            return []

    def _filter_false_positives(self, findings: List[Dict]) -> List[Dict]:
        """Apply FP filter to findings."""
        try:
            from src.ml.fp_filter import FalsePositiveFilter

            fp = FalsePositiveFilter()
            source = Path(self.contract_path).read_text() if self.contract_path else ""
            result = fp.filter_findings(findings, source)
            return result.get("filtered", findings) if isinstance(result, dict) else findings
        except Exception:
            return findings

    # -----------------------------------------------------------------------
    # Phase 3: Deep Investigation (Agentic Loop)
    # -----------------------------------------------------------------------

    def _phase_deep_investigation(
        self,
        contract_path: str,
        source_code: str,
        recon: ReconResult,
        scan: ScanResult,
    ) -> Dict[str, Any]:
        investigated: Set[str] = set()
        enriched_findings: List[Dict[str, Any]] = []
        additional_tools: List[str] = set()
        mitigated_count = 0
        exploit_chains: List[Dict] = []

        # Start with HIGH/CRITICAL from initial scan
        queue = [
            f
            for f in scan.filtered_findings
            if f.get("severity", "").lower() in ("critical", "high")
        ]

        iteration = 0
        while queue and iteration < self.config.max_iterations and not self._timeout_exceeded():
            iteration += 1
            logger.info(
                f"Investigation iteration {iteration}: {len(queue)} findings to investigate"
            )
            next_queue: List[Dict] = []

            for finding in queue:
                fid = finding.get("id", finding.get("title", str(hash(str(finding)))))
                if fid in investigated:
                    continue
                investigated.add(fid)

                enriched = dict(finding)
                enriched["investigation"] = {}
                ftype = finding.get("type", "").lower()
                fsev = finding.get("severity", "").lower()

                # Step 1: RAG enrichment + mitigation verification
                if self.config.enable_rag:
                    rag_data = self._enrich_with_rag(finding)
                    enriched["investigation"]["rag"] = rag_data
                    if rag_data.get("fix_pattern_present"):
                        if self._check_mitigation(source_code, rag_data):
                            enriched["mitigated"] = True
                            enriched["severity"] = "low"
                            enriched["investigation"]["mitigation_verified"] = True
                            mitigated_count += 1
                            logger.info(f"Finding {fid}: mitigated (fix pattern found in code)")
                        else:
                            enriched["investigation"]["mitigation_verified"] = False
                            logger.info(f"Finding {fid}: fix pattern known but NOT implemented")

                # Step 2: Finding-driven targeted analysis
                #
                # Use the canonical taxonomy rather than substring keyword
                # matching. This makes Phase-3 branches fire on real
                # Slither/Aderyn detector names (arbitrary-send-eth,
                # suicidal, unprotected-upgrade, reentrancy-eth, ...)
                # not just MIESC-native vocabulary.
                from src.core.finding_taxonomy import CanonicalCategory, normalize_finding_type

                canonical = normalize_finding_type(finding)
                enriched["investigation"]["canonical_category"] = (
                    canonical.value if canonical else None
                )
                func = self._extract_function_name(finding)

                # Taint confirmation for call-flow / reentrancy shapes
                if self.config.enable_taint and func:
                    if canonical in (
                        CanonicalCategory.REENTRANCY,
                        CanonicalCategory.UNCHECKED_CALL,
                        CanonicalCategory.PROXY_UPGRADE,
                    ):
                        taint = self._targeted_taint_for_function(source_code, func)
                        enriched["investigation"]["taint_paths"] = len(taint)
                        if taint:
                            enriched["investigation"]["taint_confirmed"] = True
                            logger.info(
                                f"Finding {fid}: taint analysis CONFIRMS data flow vulnerability"
                            )

                # Oracle/price/flash-loan → DeFi pattern detector
                if canonical in (
                    CanonicalCategory.ORACLE_MANIPULATION,
                    CanonicalCategory.FLASH_LOAN,
                ):
                    defi_matches = self._targeted_defi_scan(source_code, func)
                    enriched["investigation"]["analysis_type"] = "oracle_dependency"
                    enriched["investigation"]["defi_patterns_matched"] = len(defi_matches)
                    if defi_matches:
                        enriched["investigation"]["defi_patterns"] = defi_matches
                        enriched["investigation"]["oracle_dependency_confirmed"] = True
                        logger.info(
                            f"Finding {fid}: DeFi detector CONFIRMS oracle-dependency "
                            f"({len(defi_matches)} pattern matches)"
                        )

                # Access control → generate a CVL rule the auditor can run
                if canonical in (
                    CanonicalCategory.ACCESS_CONTROL,
                    CanonicalCategory.CENTRALIZATION,
                ):
                    prop = self._targeted_property_for_function(finding, func)
                    enriched["investigation"]["analysis_type"] = "access_control_audit"
                    if prop is not None:
                        enriched["investigation"]["generated_property"] = prop
                        enriched["investigation"]["property_generated"] = True
                        logger.info(
                            f"Finding {fid}: Generated CVL rule '{prop.get('rule_name')}' "
                            f"targeting {func}"
                        )

                # Step 3: Call graph attack paths (for confirmed findings)
                if self.config.enable_call_graph and recon.call_graph and func:
                    paths = self._find_attack_paths(recon.call_graph, func)
                    enriched["investigation"]["attack_paths"] = paths
                    if paths:
                        enriched["investigation"]["reachable_from_entry"] = True

                # Step 4: Trigger additional tools based on finding type
                extra_tool = self._should_trigger_tool(finding, scan.tools_run, additional_tools)
                if extra_tool:
                    logger.info(f"Triggering additional tool: {extra_tool} (based on {ftype})")
                    additional_tools.add(extra_tool)
                    new_findings = self._run_tools_parallel([extra_tool], contract_path)
                    high_new = [
                        f
                        for f in new_findings
                        if f.get("severity", "").lower() in ("critical", "high")
                    ]
                    next_queue.extend(high_new)
                    scan.filtered_findings.extend(new_findings)

                # Step 5: Multi-LLM consensus for CRITICAL and HIGH findings
                # (HIGH included because real tools rarely emit CRITICAL — most
                # reentrancy/access-control findings land at HIGH with Slither/Aderyn)
                if (
                    fsev in ("critical", "high")
                    and self.config.enable_llm
                    and not self._timeout_exceeded()
                ):
                    consensus = self._get_llm_consensus(finding, source_code)
                    if consensus:
                        enriched["investigation"]["llm_consensus"] = consensus

                        # Apply confidence delta to the finding
                        base_conf = float(enriched.get("confidence", 0.7))
                        new_conf = max(0.0, min(1.0, base_conf + consensus["confidence_delta"]))
                        enriched["confidence"] = round(new_conf, 2)

                        if consensus["consensus"] == "agree_confirmed":
                            enriched["investigation"]["llm_confirmed"] = True
                            logger.info(
                                f"Finding {fid}: consensus CONFIRMED by "
                                f"{consensus['confirmed_count']} models — "
                                f"confidence {base_conf:.2f} → {new_conf:.2f}"
                            )
                        elif consensus["consensus"] == "agree_rejected":
                            enriched["severity"] = "high"
                            enriched["investigation"]["llm_downgraded"] = True
                            logger.info(
                                f"Finding {fid}: consensus REJECTED — "
                                f"downgraded CRITICAL → HIGH (confidence {new_conf:.2f})"
                            )
                        elif consensus["consensus"] == "disagreement":
                            enriched["needs_manual_review"] = True
                            enriched["investigation"][
                                "manual_review_reason"
                            ] = "Models disagree on whether this is a real vulnerability"
                            logger.warning(
                                f"Finding {fid}: models DISAGREE — flagged for manual review "
                                f"({consensus['confirmed_count']} confirm, "
                                f"{consensus['rejected_count']} reject)"
                            )

                enriched_findings.append(enriched)

            queue = next_queue

        # Exploit chain detection
        if self.config.enable_exploit_chains:
            exploit_chains = self._detect_exploit_chains(
                enriched_findings
                + [
                    f
                    for f in scan.filtered_findings
                    if f.get("severity", "").lower() not in ("critical", "high")
                ]
            )

        # Aggregate counters
        needs_review_count = sum(1 for f in enriched_findings if f.get("needs_manual_review"))
        property_count = sum(
            1 for f in enriched_findings if f.get("investigation", {}).get("property_generated")
        )
        defi_confirmed = sum(
            1
            for f in enriched_findings
            if f.get("investigation", {}).get("oracle_dependency_confirmed")
        )

        return {
            "findings": enriched_findings
            + [
                f
                for f in scan.filtered_findings
                if f.get("id", f.get("title", "")) not in investigated
            ],
            "exploit_chains": exploit_chains,
            "iterations": iteration,
            "enriched_count": len(enriched_findings),
            "additional_tools": list(additional_tools),
            "mitigated_count": mitigated_count,
            "needs_manual_review_count": needs_review_count,
            "properties_generated": property_count,
            "defi_confirmed_count": defi_confirmed,
        }

    def _enrich_with_rag(self, finding: Dict) -> Dict[str, Any]:
        """Enrich a finding with RAG vulnerability knowledge."""
        try:
            from src.llm.embedding_rag import EmbeddingRAG

            rag = EmbeddingRAG()
            results = rag.search_by_finding(finding)
            if not results:
                return {"matched": False}

            top = results[0] if isinstance(results, list) else results
            doc = top if isinstance(top, dict) else getattr(top, "__dict__", {})
            return {
                "matched": True,
                "similar_vuln": doc.get("title", ""),
                "real_exploit": doc.get("real_exploit", ""),
                "fix_pattern": doc.get("fixed_code", ""),
                "fix_pattern_present": bool(doc.get("fixed_code")),
                "severity_match": doc.get("severity", "") == finding.get("severity", ""),
                "similarity": doc.get("similarity", 0.0),
            }
        except Exception as e:
            logger.debug(f"RAG enrichment failed: {e}")
            return {"matched": False, "error": str(e)}

    def _check_mitigation(self, source_code: str, rag_data: Dict) -> bool:
        """Check if the fix pattern from RAG is present in source code."""
        fix = rag_data.get("fix_pattern", "")
        if not fix:
            return False
        keywords = re.findall(r"\b\w{4,}\b", fix)
        matches = sum(1 for kw in keywords if kw.lower() in source_code.lower())
        return matches >= 2

    def _query_llm_verifier(
        self, finding: Dict, source_code: str, model: str, host: str
    ) -> Optional[Dict]:
        """Query a specific Ollama model for finding verification. Returns parsed JSON or None."""
        import json as json_mod
        import urllib.request

        title = finding.get("title", finding.get("type", "unknown"))
        desc = finding.get("description", "")[:300]
        loc_obj = finding.get("location", {})
        func = loc_obj.get("function", "unknown") if isinstance(loc_obj, dict) else ""
        code_snippet = source_code[:3000]

        prompt = f"""A security tool flagged this as CRITICAL. Verify whether it is a real vulnerability.

FINDING: {title}
DESCRIPTION: {desc}
FUNCTION: {func}

CONTRACT CODE (first 3000 chars):
{code_snippet}

Respond ONLY with JSON of the shape:
{{"confirmed": true|false, "reasoning": "<1-2 sentences>", "actual_severity": "CRITICAL|HIGH|MEDIUM|LOW"}}
"""
        try:
            payload = json_mod.dumps(
                {
                    "model": model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {"temperature": 0.1, "num_predict": 512},
                }
            ).encode()
            req = urllib.request.Request(
                f"{host}/api/generate",
                data=payload,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json_mod.loads(resp.read())
            text = result.get("response", "")
            try:
                start = text.index("{")
                end = text.rindex("}") + 1
                parsed = json_mod.loads(text[start:end])
                parsed["_model"] = model
                return parsed
            except (ValueError, json_mod.JSONDecodeError):
                return {"confirmed": True, "reasoning": text[:200], "_model": model}
        except Exception as e:
            logger.debug(f"LLM verifier ({model}) failed: {e}")
            return None

    def _get_llm_consensus(self, finding: Dict, source_code: str) -> Optional[Dict[str, Any]]:
        """
        Multi-LLM consensus check: query the primary code-analysis model AND a
        verification-focused model, then reconcile their verdicts.

        Returns a dict with keys:
          - opinions: List[Dict] (raw model answers)
          - models_queried: List[str]
          - confirmed_count / rejected_count
          - consensus: "agree_confirmed" | "agree_rejected" | "disagreement"
          - confidence_delta: float — suggested boost/penalty to the finding's confidence
          - needs_manual_review: bool
        """
        try:
            from src.core.llm_config import (
                USE_CASE_CODE_ANALYSIS,
                USE_CASE_VERIFICATION,
                get_model,
                get_ollama_host,
            )

            primary_model = get_model(USE_CASE_CODE_ANALYSIS)
            verifier_model = get_model(USE_CASE_VERIFICATION)
            host = get_ollama_host()
        except Exception:
            primary_model = self.config.llm_model
            verifier_model = self.config.llm_model
            host = "http://localhost:11434"

        models_queried: List[str] = []
        opinions: List[Dict[str, Any]] = []

        for model in dict.fromkeys([primary_model, verifier_model]):  # de-dup, preserve order
            op = self._query_llm_verifier(finding, source_code, model, host)
            models_queried.append(model)
            if op is not None:
                opinions.append(op)
            if self._timeout_exceeded():
                break

        if not opinions:
            return None

        confirmed = [o for o in opinions if bool(o.get("confirmed"))]
        rejected = [o for o in opinions if not bool(o.get("confirmed"))]

        if len(opinions) == 1:
            consensus = "single_opinion"
            confidence_delta = 0.0
            needs_manual_review = False
        elif len(confirmed) == len(opinions):
            consensus = "agree_confirmed"
            confidence_delta = +0.20
            needs_manual_review = False
        elif len(rejected) == len(opinions):
            consensus = "agree_rejected"
            confidence_delta = -0.30
            needs_manual_review = False
        else:
            consensus = "disagreement"
            confidence_delta = -0.10
            needs_manual_review = True

        return {
            "opinions": opinions,
            "models_queried": models_queried,
            "confirmed_count": len(confirmed),
            "rejected_count": len(rejected),
            "consensus": consensus,
            "confidence_delta": confidence_delta,
            "needs_manual_review": needs_manual_review,
        }

    # Kept for backwards compat (existing callers/tests); delegates to the new consensus flow.
    def _get_llm_second_opinion(self, finding: Dict, source_code: str) -> Optional[Dict]:
        consensus = self._get_llm_consensus(finding, source_code)
        if consensus is None:
            return None
        if consensus.get("opinions"):
            # Return the first opinion for legacy shape compatibility, but carry
            # the consensus metadata alongside for newer callers.
            merged = dict(consensus["opinions"][0])
            merged["consensus"] = consensus["consensus"]
            merged["needs_manual_review"] = consensus["needs_manual_review"]
            merged["confidence_delta"] = consensus["confidence_delta"]
            return merged
        return None

    def _targeted_taint_for_function(self, source_code: str, func_name: str) -> list:
        """Run taint analysis targeting a specific function."""
        try:
            from src.ml.taint_analysis import TaintAnalyzer

            analyzer = TaintAnalyzer()
            results = analyzer.analyze(source_code)
            if isinstance(results, list):
                return [r for r in results if func_name in str(r)]
            return []
        except Exception:
            return []

    def _targeted_defi_scan(
        self, source_code: str, func_name: Optional[str]
    ) -> List[Dict[str, Any]]:
        """
        Run DeFi pattern detector focused on the vulnerable function.

        Triggered when a finding is oracle-/price-related — gives us concrete
        evidence (e.g. spot-price read, missing TWAP) to confirm the finding.
        Returns a list of matched DeFi patterns serialized as dicts.
        """
        try:
            from src.ml.defi_patterns import DeFiPatternDetector

            detector = DeFiPatternDetector()
            matches = detector.analyze_code(source_code) or []
            matches_list: List[Dict[str, Any]] = []
            for m in matches:
                # Normalize to dict (DeFiPatternMatch is a dataclass)
                if hasattr(m, "to_dict"):
                    d = m.to_dict()
                elif hasattr(m, "__dict__"):
                    d = dict(m.__dict__)
                    # Enums → plain strings for JSON safety
                    if hasattr(d.get("vuln_type"), "value"):
                        d["vuln_type"] = d["vuln_type"].value
                else:
                    d = {"match": str(m)}
                if func_name:
                    loc = " ".join(str(v) for v in d.values()).lower()
                    if func_name.lower() in loc:
                        matches_list.append(d)
                else:
                    matches_list.append(d)
            return matches_list[:5]
        except Exception as e:
            logger.debug(f"Targeted DeFi scan failed: {e}")
            return []

    def _targeted_property_for_function(
        self, finding: Dict[str, Any], func_name: Optional[str]
    ) -> Optional[Dict[str, Any]]:
        """
        Generate a formal-verification property (CVL rule) targeting the function
        that triggered an access-control finding.

        The generated rule becomes actionable evidence the auditor can feed to
        `certoraRun` / `miesc verify` directly.
        """
        if not func_name:
            return None
        try:
            from src.formal.spec_generator import SpecFormat, SpecGenerator

            generator = SpecGenerator()
            # Force the function name into the finding so the generator targets it
            enriched_input = dict(finding)
            loc = (
                dict(enriched_input.get("location", {}))
                if isinstance(enriched_input.get("location"), dict)
                else {}
            )
            loc["function"] = func_name
            enriched_input["location"] = loc
            specs = generator.generate_specs([enriched_input], format=SpecFormat.CVL)
            if not specs:
                return None
            spec = specs[0]
            return {
                "format": "cvl",
                "rule_name": getattr(spec, "rule_name", None) or spec.__dict__.get("rule_name"),
                "content": getattr(spec, "content", None) or spec.__dict__.get("content"),
                "target_function": func_name,
            }
        except Exception as e:
            logger.debug(f"Property generation for {func_name} failed: {e}")
            return None

    def _find_attack_paths(self, call_graph, func_name: str) -> List[str]:
        """Find attack paths from entry points to the vulnerable function."""
        if not call_graph or not func_name:
            return []
        try:
            if hasattr(call_graph, "paths_to_sink"):
                paths = call_graph.paths_to_sink(func_name)
                return [" -> ".join(str(n) for n in p[:5]) for p in paths[:3]]
        except Exception:
            pass
        return []

    def _extract_function_name(self, finding: Dict) -> Optional[str]:
        """Extract function name from finding location."""
        loc = finding.get("location", {})
        if isinstance(loc, dict):
            func = loc.get("function", "")
            if func and func != "unknown":
                return func
        loc_str = str(loc)
        m = re.search(r"function\s+(\w+)", loc_str)
        if m:
            return m.group(1)
        return None

    def _should_trigger_tool(
        self, finding: Dict, tools_run: List[str], already_triggered: Set[str]
    ) -> Optional[str]:
        """Decide if an additional tool should be triggered for this finding."""
        ftype = finding.get("type", "").lower()
        sev = finding.get("severity", "").lower()

        if sev not in ("critical", "high"):
            return None

        # Reentrancy without symbolic execution confirmation
        if (
            "reentran" in ftype
            and "mythril" not in tools_run
            and "mythril" not in already_triggered
        ):
            return "mythril"

        # Delegatecall without formal verification
        if (
            "delegatecall" in ftype
            and "halmos" not in tools_run
            and "halmos" not in already_triggered
        ):
            return "halmos"

        # Access control without fuzzing
        if "access" in ftype and "echidna" not in tools_run and "echidna" not in already_triggered:
            return "echidna"

        return None

    def _detect_exploit_chains(self, findings: List[Dict]) -> List[Dict]:
        """Detect exploit chains across findings."""
        try:
            from src.ml.correlation_engine import ExploitChainAnalyzer

            analyzer = ExploitChainAnalyzer()
            chains = analyzer.analyze(findings)
            if isinstance(chains, list):
                return [c.__dict__ if hasattr(c, "__dict__") else c for c in chains]
            return []
        except Exception as e:
            logger.debug(f"Exploit chain detection failed: {e}")
            return []

    # -----------------------------------------------------------------------
    # Phase 4: Synthesis
    # -----------------------------------------------------------------------

    def _phase_synthesis(
        self,
        contract_path: str,
        source_code: str,
        recon: ReconResult,
        scan: ScanResult,
        investigation: Dict[str, Any],
    ) -> Dict[str, Any]:
        findings = investigation.get("findings", scan.filtered_findings)
        chains = investigation.get("exploit_chains", [])

        # Correlation pass
        correlated = self._correlate_findings(findings)

        # Compute severity distribution
        summary = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for f in correlated:
            sev = f.get("severity", "unknown").upper()
            if sev in summary:
                summary[sev] += 1

        summary["total"] = sum(summary.values())
        summary["tools_used"] = scan.tools_run
        summary["iterations"] = investigation.get("iterations", 0)
        summary["exploit_chains"] = len(chains)
        summary["risk_profile"] = recon.risk_profile.get("primary", "general")
        summary["attack_surface"] = recon.attack_surface_score

        # LLM narrative (optional)
        narrative = ""
        has_llm = False
        if self.config.enable_llm and not self._timeout_exceeded():
            narrative = self._generate_narrative(correlated, summary, chains)
            has_llm = bool(narrative)

        if not narrative:
            narrative = self._template_narrative(summary, chains)

        return {
            "findings": correlated,
            "exploit_chains": chains,
            "summary": summary,
            "narrative": narrative,
            "has_llm_narrative": has_llm,
        }

    def _correlate_findings(self, findings: List[Dict]) -> List[Dict]:
        """Correlate and deduplicate findings."""
        try:
            from src.ml.correlation_engine import correlate_findings

            result = correlate_findings(findings)
            if isinstance(result, dict):
                return result.get("findings", findings)
            return findings
        except Exception:
            return findings

    def _generate_narrative(self, findings: List[Dict], summary: Dict, chains: List[Dict]) -> str:
        """Generate LLM narrative using available provider (local-first).

        Priority: Ollama (local) -> Anthropic Claude -> OpenAI -> template.
        """
        provider = self.config.llm_provider

        # Try LLMOrchestrator (supports Ollama, Anthropic, OpenAI with fallback)
        if provider == "auto" or provider in ("anthropic", "openai"):
            narrative = self._try_llm_orchestrator(findings, summary, chains)
            if narrative:
                return narrative

        # Try Ollama directly (local-first default)
        if provider in ("auto", "ollama"):
            narrative = self._try_ollama_interpreter(findings, summary)
            if narrative:
                return narrative

        return ""

    def _try_llm_orchestrator(self, findings: List[Dict], summary: Dict, chains: List[Dict]) -> str:
        """Try LLMOrchestrator with multi-provider fallback."""
        try:
            import asyncio
            import os

            from src.llm.llm_orchestrator import (
                LLMConfig,
                LLMOrchestrator,
                LLMProvider,
            )

            configs = []
            provider = self.config.llm_provider

            # Local-first: always add Ollama
            if provider in ("auto", "ollama"):
                configs.append(
                    LLMConfig(
                        provider=LLMProvider.OLLAMA,
                        model=self.config.llm_model,
                        base_url="http://localhost:11434",
                    )
                )

            # Anthropic Claude (optional, if API key available)
            if provider in ("auto", "anthropic") and os.getenv("ANTHROPIC_API_KEY"):
                configs.append(
                    LLMConfig(
                        provider=LLMProvider.ANTHROPIC,
                        model="claude-sonnet-4-20250514",
                        api_key=os.getenv("ANTHROPIC_API_KEY"),
                    )
                )

            # OpenAI (optional, if API key available)
            if provider in ("auto", "openai") and os.getenv("OPENAI_API_KEY"):
                configs.append(
                    LLMConfig(
                        provider=LLMProvider.OPENAI,
                        model="gpt-4o",
                        api_key=os.getenv("OPENAI_API_KEY"),
                    )
                )

            if not configs:
                return ""

            orch = LLMOrchestrator(configs=configs)

            # Build prompt
            contract_name = Path(self.contract_path).stem if self.contract_path else "Contract"
            critical = summary.get("CRITICAL", 0)
            high = summary.get("HIGH", 0)
            total = summary.get("total", 0)
            chain_count = len(chains)

            top_findings = "\n".join(
                f"- [{f.get('severity', '?').upper()}] {f.get('title', f.get('type', '?'))}: {f.get('description', '')[:100]}"
                for f in findings[:8]
            )

            prompt = f"""Analyze this smart contract security audit for {contract_name} and write a 200-word executive summary.

Findings: {total} total ({critical} critical, {high} high)
Exploit chains detected: {chain_count}

Top findings:
{top_findings}

Focus on: business risk, deployment recommendation (GO/NO-GO/CONDITIONAL), and top 3 remediation priorities.
Write for a non-technical executive audience."""

            async def run():
                await orch.initialize()
                response = await orch.analyze(prompt)
                return response.content if response else ""

            result = asyncio.run(run())
            if result:
                logger.info("LLM narrative generated via LLMOrchestrator")
            return result
        except Exception as e:
            logger.debug(f"LLMOrchestrator narrative failed: {e}")
            return ""

    def _try_ollama_interpreter(self, findings: List[Dict], summary: Dict) -> str:
        """Try Ollama via LLMReportInterpreter (existing module)."""
        try:
            from src.reports.llm_interpreter import LLMReportInterpreter

            interp = LLMReportInterpreter()
            if not interp.is_available():
                return ""
            result = interp.generate_executive_interpretation(
                findings=findings,
                summary=summary,
                contract_name=Path(self.contract_path).stem if self.contract_path else "Contract",
            )
            return result if isinstance(result, str) else ""
        except Exception as e:
            logger.debug(f"Ollama interpreter failed: {e}")
            return ""

    def _template_narrative(self, summary: Dict, chains: List[Dict]) -> str:
        """Generate template-based narrative without LLM."""
        total = summary.get("total", 0)
        critical = summary.get("CRITICAL", 0)
        high = summary.get("HIGH", 0)
        chain_count = len(chains)

        if critical > 0:
            risk = "CRITICAL"
            action = "Immediate remediation required before deployment."
        elif high > 0:
            risk = "HIGH"
            action = "Address high-severity findings before mainnet deployment."
        elif total > 0:
            risk = "MEDIUM"
            action = "Review findings and apply recommended fixes."
        else:
            risk = "LOW"
            action = "No significant security issues detected."

        parts = [
            f"The deep agentic audit analyzed the contract across {len(summary.get('tools_used', []))} "
            f"tools in {summary.get('iterations', 0)} investigation iterations.",
            f"\n\nOverall risk level: {risk}. {total} findings detected "
            f"({critical} critical, {high} high).",
        ]
        if chain_count:
            parts.append(
                f"\n\n{chain_count} exploit chain(s) detected, indicating "
                f"vulnerabilities that can be combined for cascading attacks."
            )
        parts.append(f"\n\nRecommendation: {action}")
        return "".join(parts)

    # -----------------------------------------------------------------------
    # Timeout management
    # -----------------------------------------------------------------------

    def _timeout_exceeded(self) -> bool:
        return (time.monotonic() - self._start_time) > self.config.timeout_seconds

    def _remaining_seconds(self) -> float:
        return max(0, self.config.timeout_seconds - (time.monotonic() - self._start_time))


# ---------------------------------------------------------------------------
# Convenience function
# ---------------------------------------------------------------------------


def run_deep_audit(contract_path: str, **kwargs) -> Dict[str, Any]:
    """Run a deep agentic audit on a contract.

    Args:
        contract_path: Path to Solidity contract file.
        **kwargs: Override DeepAuditConfig fields.

    Returns:
        Dict with findings, exploit chains, summary, and narrative.
    """
    config = DeepAuditConfig(
        **{k: v for k, v in kwargs.items() if k in DeepAuditConfig.__dataclass_fields__}
    )
    agent = DeepAuditAgent(config=config)
    return agent.analyze(contract_path)
