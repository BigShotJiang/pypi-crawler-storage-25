"""
PropertyGPT Adapter - Layer 4: Formal Verification Enhancement
===============================================================

LLM-driven automated formal property generation for Certora verification.
Based on NDSS 2025 research (arXiv:2405.02580) - achieves 80% recall on
ground-truth properties from real-world Certora projects.

Solves the major bottleneck in formal verification: writing specifications.

Key Features:
- Automated CVL property generation
- Contract-specific invariant discovery
- State-machine property inference
- Pre-condition/post-condition synthesis
- Integration with Certora Prover

Author: Fernando Boiero <fboiero@frvm.utn.edu.ar>
Date: 2025-01-13
Version: 1.0.0
Paper: NDSS Symposium 2025, arXiv:2405.02580
"""

import json
import logging
import os
import re
import time
from typing import Any, Dict, List, Optional

from src.core.llm_config import get_ollama_host
from src.core.ollama_models import list_ollama_models, select_ollama_model
from src.core.tool_protocol import (
    ToolAdapter,
    ToolCapability,
    ToolCategory,
    ToolMetadata,
    ToolStatus,
)

# Try to import EmbeddingRAG (optional dependency)
try:
    from src.llm.embedding_rag import EmbeddingRAG

    _EMBEDDING_RAG_AVAILABLE = True
except ImportError:
    _EMBEDDING_RAG_AVAILABLE = False
    EmbeddingRAG = None

logger = logging.getLogger(__name__)


class PropertyGPTAdapter(ToolAdapter):
    """
    PropertyGPT: LLM-driven formal property generation for smart contracts.

    Automatically generates Certora Verification Language (CVL) properties
    using advanced prompt engineering and contract analysis.

    Research Foundation:
    - NDSS 2025 publication
    - 80% recall on ground-truth properties
    - Tested on 9 real Certora projects
    - Reduces property writing time by 90%

    Property Types Generated:
    - Invariants (state preservation)
    - Pre/post conditions (function correctness)
    - State machine properties (transition validity)
    - Access control properties (authorization)
    - Economic properties (conservation laws)
    """

    # Property templates based on PropertyGPT research
    PROPERTY_TEMPLATES = {
        "invariant": {
            "pattern": "invariant {name}()\n    {condition};",
            "description": "State invariant that must hold across all transactions",
        },
        "rule": {
            "pattern": "rule {name}(method f) {\n    {precondition}\n    env e;\n    calldataarg args;\n    f(e, args);\n    {postcondition}\n}",
            "description": "Pre/post condition property for function correctness",
        },
        "parametric": {
            "pattern": "rule {name}(method f, method g) filtered {{ f -> f.selector != g.selector }} {\n    {body}\n}",
            "description": "Parametric rule checking multiple function interactions",
        },
    }

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize PropertyGPT adapter.

        Args:
            config: Configuration dict with optional:
                - llm_backend: "gpt-4", "claude", "ollama" (default: "ollama")
                - ollama_model: Model for Ollama (default: "openhermes")
                - max_properties: Maximum properties to generate (default: 10)
                - min_confidence: Minimum confidence threshold (default: 0.7)
                - enable_validation: Validate generated CVL syntax (default: True)
        """
        super().__init__()
        self.config = config or {}
        self.llm_backend = self.config.get("llm_backend", "ollama")
        self.ollama_model = self.config.get("ollama_model", "qwen2.5-coder:32b")
        self.max_properties = self.config.get("max_properties", 10)
        self.min_confidence = self.config.get("min_confidence", 0.7)
        self.enable_validation = self.config.get("enable_validation", True)

        # Initialize EmbeddingRAG if available
        self._embedding_rag = None
        self._use_rag = False
        if _EMBEDDING_RAG_AVAILABLE:
            try:
                self._embedding_rag = EmbeddingRAG()
                self._use_rag = True
                logger.debug("PropertyGPT: EmbeddingRAG (ChromaDB) enabled")
            except Exception as e:
                logger.debug(f"PropertyGPT: EmbeddingRAG unavailable: {e}")

    def get_metadata(self) -> ToolMetadata:
        return ToolMetadata(
            name="propertygpt",
            version="1.0.0",
            category=ToolCategory.FORMAL_VERIFICATION,
            author="Fernando Boiero (Based on NDSS 2025 research)",
            license="AGPL-3.0",
            homepage="https://github.com/fboiero/MIESC",
            repository="https://github.com/fboiero/MIESC",
            documentation="https://github.com/fboiero/MIESC/blob/main/docs/TOOL_INTEGRATION_GUIDE.md",
            installation_cmd="# LLM backend required: OpenAI API, Anthropic API, or Ollama (local)",
            capabilities=[
                ToolCapability(
                    name="automated_property_generation",
                    description="LLM-driven automated formal property generation (CVL)",
                    supported_languages=["solidity"],
                    detection_types=[
                        "invariant_generation",
                        "precondition_synthesis",
                        "postcondition_synthesis",
                        "state_machine_properties",
                        "access_control_properties",
                        "economic_properties",
                    ],
                )
            ],
            cost=0.0,  # Using local Ollama by default
            requires_api_key=False,  # Optional for cloud LLMs
            is_optional=True,
        )

    def is_available(self) -> ToolStatus:
        """Check if PropertyGPT backend (LLM) is available."""
        import urllib.error
        import urllib.request

        try:
            if self.llm_backend == "ollama":
                # Check if Ollama is running via HTTP API
                ollama_host = get_ollama_host()
                tags_url = f"{ollama_host}/api/tags"

                req = urllib.request.Request(tags_url, method="GET")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    if resp.status == 200:
                        data = json.loads(resp.read().decode())
                        models = [m.get("name", "") for m in data.get("models", [])]
                        selected = select_ollama_model(
                            [
                                self.ollama_model,
                                "qwen2.5-coder:32b",
                                "qwen2.5-coder:14b",
                                "qwen2.5-coder",
                                "codellama:13b",
                                "codellama",
                                "mistral:7b",
                                "mistral",
                                "llama3.2:3b",
                            ],
                            installed=models,
                        )

                        if selected:
                            self.ollama_model = selected
                            logger.info(
                                "PropertyGPT: Ollama available at %s with model %s",
                                ollama_host,
                                self.ollama_model,
                            )
                            return ToolStatus.AVAILABLE
                        else:
                            logger.warning("PropertyGPT: no compatible local Ollama model found.")
                            return ToolStatus.NOT_INSTALLED
                    else:
                        logger.warning(f"PropertyGPT: Ollama returned status {resp.status}")
                        return ToolStatus.NOT_INSTALLED

            elif self.llm_backend == "gpt-4":
                # Check for OpenAI API key
                api_key = os.getenv("OPENAI_API_KEY")
                if api_key:
                    return ToolStatus.AVAILABLE
                else:
                    logger.warning("OPENAI_API_KEY not set")
                    return ToolStatus.CONFIGURATION_ERROR

            elif self.llm_backend == "claude":
                # Check for Anthropic API key
                api_key = os.getenv("ANTHROPIC_API_KEY")
                if api_key:
                    return ToolStatus.AVAILABLE
                else:
                    logger.warning("ANTHROPIC_API_KEY not set")
                    return ToolStatus.CONFIGURATION_ERROR
            else:
                logger.error(f"Unknown LLM backend: {self.llm_backend}")
                return ToolStatus.CONFIGURATION_ERROR

        except urllib.error.URLError as e:
            logger.info(f"PropertyGPT: Ollama not reachable: {e}")
            return ToolStatus.NOT_INSTALLED
        except FileNotFoundError:
            logger.info("PropertyGPT backend not available. Install Ollama or configure API keys.")
            return ToolStatus.NOT_INSTALLED
        except Exception as e:
            logger.error(f"PropertyGPT availability check failed: {e}")
            return ToolStatus.CONFIGURATION_ERROR

    def analyze(self, contract_path: str, **kwargs) -> Dict[str, Any]:
        """
        Generate formal properties for a Solidity contract.

        Args:
            contract_path: Path to Solidity contract file
            **kwargs:
                - output_cvl_file: Path to save generated CVL spec (optional)
                - property_types: List of property types to generate (optional)

        Returns:
            Dict containing:
                - success: bool
                - properties: List of generated CVL properties
                - cvl_spec: Complete CVL specification
                - confidence_scores: Per-property confidence
                - execution_time: Analysis duration
        """
        start_time = time.time()

        try:
            # Read contract source
            with open(contract_path, "r", encoding="utf-8") as f:
                contract_source = f.read()

            # Extract contract metadata
            contract_info = self._analyze_contract_structure(contract_source)

            timeout = int(kwargs.get("timeout", 120))

            # Generate properties using LLM
            logger.info(f"Generating formal properties using {self.llm_backend}...")
            properties = self._generate_properties_llm(
                contract_source, contract_info, timeout=timeout
            )

            # Filter by confidence threshold
            high_confidence_properties = [
                p for p in properties if p.get("confidence", 0) >= self.min_confidence
            ][: self.max_properties]

            # Build complete CVL specification
            cvl_spec = self._build_cvl_spec(contract_info, high_confidence_properties)

            # Validate CVL syntax if enabled
            validation_result = {}
            if self.enable_validation:
                validation_result = self._validate_cvl_syntax(cvl_spec)

            # Save to file if requested
            output_file = kwargs.get("output_cvl_file")
            if output_file:
                with open(output_file, "w") as f:
                    f.write(cvl_spec)
                logger.info(f"CVL specification saved to {output_file}")

            execution_time = time.time() - start_time

            result = {
                "tool": "propertygpt",
                "version": "1.0.0",
                "status": "success",
                "properties": high_confidence_properties,
                "cvl_spec": cvl_spec,
                "metadata": {
                    "contract_name": contract_info.get("name", "Unknown"),
                    "functions_analyzed": len(contract_info.get("functions", [])),
                    "state_vars_analyzed": len(contract_info.get("state_vars", [])),
                    "properties_generated": len(high_confidence_properties),
                    "llm_backend": self.llm_backend,
                    "validation": validation_result,
                },
                "execution_time": round(execution_time, 2),
            }

            return result

        except FileNotFoundError:
            return {
                "tool": "propertygpt",
                "version": "1.0.0",
                "status": "error",
                "error": f"Contract file not found: {contract_path}",
                "properties": [],
                "execution_time": time.time() - start_time,
            }
        except Exception as e:
            logger.error(f"PropertyGPT analysis failed: {e}")
            return {
                "tool": "propertygpt",
                "version": "1.0.0",
                "status": "error",
                "error": str(e),
                "properties": [],
                "execution_time": time.time() - start_time,
            }

    def _analyze_contract_structure(self, source_code: str) -> Dict[str, Any]:
        """
        Extract contract structure for property generation context.

        Returns:
            Dict with contract name, functions, state vars, events, modifiers
        """
        info = {
            "name": "UnknownContract",
            "functions": [],
            "state_vars": [],
            "events": [],
            "modifiers": [],
        }

        # Extract contract name
        contract_match = re.search(r"contract\s+(\w+)", source_code)
        if contract_match:
            info["name"] = contract_match.group(1)

        # Extract functions
        function_pattern = r"function\s+(\w+)\s*\(([^)]*)\)\s*(public|external|internal|private)?\s*(view|pure|payable|nonpayable)?"
        for match in re.finditer(function_pattern, source_code):
            info["functions"].append(
                {
                    "name": match.group(1),
                    "params": match.group(2),
                    "visibility": match.group(3) or "public",
                    "mutability": match.group(4) or "nonpayable",
                }
            )

        # Extract state variables
        state_var_pattern = r"(public|private|internal)\s+(\w+)\s+(\w+)\s*;"
        for match in re.finditer(state_var_pattern, source_code):
            info["state_vars"].append(
                {"visibility": match.group(1), "type": match.group(2), "name": match.group(3)}
            )

        # Extract events
        event_pattern = r"event\s+(\w+)\s*\(([^)]*)\)"
        for match in re.finditer(event_pattern, source_code):
            info["events"].append({"name": match.group(1), "params": match.group(2)})

        # Extract modifiers
        modifier_pattern = r"modifier\s+(\w+)\s*\(([^)]*)\)"
        for match in re.finditer(modifier_pattern, source_code):
            info["modifiers"].append({"name": match.group(1), "params": match.group(2)})

        return info

    def _generate_properties_llm(
        self, contract_source: str, contract_info: Dict, timeout: int = 120
    ) -> List[Dict[str, Any]]:
        """
        Generate formal properties using LLM backend.

        Uses PropertyGPT prompt engineering techniques from NDSS 2025 paper.
        """
        # Build PropertyGPT-style prompt
        prompt = self._build_propertygpt_prompt(contract_source, contract_info)

        # Call LLM backend
        if self.llm_backend == "ollama":
            properties = self._generate_with_ollama(prompt, timeout=timeout)
        elif self.llm_backend == "gpt-4":
            properties = self._generate_with_openai(prompt)
        elif self.llm_backend == "claude":
            properties = self._generate_with_anthropic(prompt)
        else:
            raise ValueError(f"Unsupported LLM backend: {self.llm_backend}")

        return properties

    def _build_propertygpt_prompt(self, contract_source: str, contract_info: Dict) -> str:
        """
        Build PropertyGPT-style prompt for formal property generation.

        Based on techniques from arXiv:2405.02580
        """
        # Get RAG context for vulnerability patterns to inform property generation
        rag_context = ""
        if self._use_rag and self._embedding_rag:
            try:
                results = self._embedding_rag.search(query=contract_source[:2000], n_results=3)
                if results:
                    rag_context = "\n\nKNOWN VULNERABILITY PATTERNS TO VERIFY AGAINST:\n"
                    for r in results:
                        rag_context += (
                            f"- {r.document.title} ({r.document.swc_id or 'Pattern'}): "
                            f"{r.document.description[:100]}...\n"
                        )
                    logger.debug(f"PropertyGPT: Added RAG context ({len(results)} patterns)")
            except Exception as e:
                logger.debug(f"PropertyGPT: RAG context failed: {e}")

        prompt = f"""You are PropertyGPT, an expert in formal verification of smart contracts.
Based on the NDSS 2025 methodology (arXiv:2405.02580), generate formal properties.

CONTRACT: {contract_info['name']}
Functions: {', '.join(f['name'] for f in contract_info['functions'][:10])}
State Variables: {', '.join(v.get('name','?') for v in contract_info['state_vars'][:10])}

```solidity
{contract_source}
```

ANALYSIS STEPS:
1. Identify what this contract MUST guarantee (invariants):
   - Total supply conservation (if token)
   - Balance consistency (sum of balances == totalSupply)
   - Monotonicity (values that should only increase/decrease)
   - Access control (only authorized callers for sensitive ops)

2. For each public function, determine:
   - Preconditions: What must be true BEFORE the call?
   - Postconditions: What must be true AFTER the call?
   - State transitions: What changes and what stays the same?

3. Look for economic properties:
   - No value creation from nothing (conservation laws)
   - No extraction beyond entitlement (fair withdrawal)
   - Bounded slippage (for AMMs/DEXs)

EXAMPLE CVL PROPERTY (for reference):
```cvl
// Invariant: total supply equals sum of all balances
invariant totalSupplyIsSumOfBalances()
    totalSupply() == sum(balanceOf(address))
    {{
        preserved with (env e) {{
            require e.msg.sender != 0;
        }}
    }}
```
{rag_context}
Generate {self.max_properties} properties. For each:
- type: invariant | rule | parametric_rule
- name: descriptive camelCase
- cvl_code: VALID Certora CVL syntax
- description: what it verifies and WHY it matters for security
- confidence: 0.0-1.0 (higher if property directly prevents known attacks)

Output: JSON array. Only generate properties relevant to THIS contract's logic.
"""
        return prompt

    def _generate_with_ollama(self, prompt: str, timeout: int = 120) -> List[Dict[str, Any]]:
        """Generate properties using local Ollama HTTP API."""
        import urllib.error
        import urllib.request

        try:
            if self.llm_backend == "ollama" and not self.ollama_model:
                self.ollama_model = select_ollama_model(
                    ["qwen2.5-coder:32b", "qwen2.5-coder", "codellama", "mistral"],
                    installed=list_ollama_models(),
                )

            ollama_host = get_ollama_host()
            generate_url = f"{ollama_host}/api/generate"

            payload = json.dumps(
                {
                    "model": self.ollama_model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,
                        "num_ctx": 8192,
                    },
                }
            ).encode("utf-8")

            req = urllib.request.Request(
                generate_url,
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )

            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode())
                    response_text = data.get("response", "").strip()

                    # Extract JSON array (may be embedded in markdown)
                    json_match = re.search(r"\[.*\]", response_text, re.DOTALL)
                    if json_match:
                        properties = json.loads(json_match.group(0))
                        return properties
                    else:
                        logger.warning("Could not parse Ollama response as JSON")
                        return self._generate_fallback_properties()
                else:
                    logger.error(f"Ollama returned status {resp.status}")
                    return self._generate_fallback_properties()

        except urllib.error.URLError as e:
            logger.error(f"Ollama API error: {e}")
            return self._generate_fallback_properties()
        except Exception as e:
            logger.error(f"Ollama property generation failed: {e}")
            return self._generate_fallback_properties()

    def _generate_with_openai(self, prompt: str) -> List[Dict[str, Any]]:
        """Generate properties using OpenAI GPT-4."""
        # Placeholder - requires openai library
        logger.warning("OpenAI backend not yet implemented, using fallback")
        return self._generate_fallback_properties()

    def _generate_with_anthropic(self, prompt: str) -> List[Dict[str, Any]]:
        """Generate properties using Anthropic Claude."""
        # Placeholder - requires anthropic library
        logger.warning("Anthropic backend not yet implemented, using fallback")
        return self._generate_fallback_properties()

    def _generate_fallback_properties(self) -> List[Dict[str, Any]]:
        """
        Generate basic fallback properties using heuristics.

        Used when LLM is unavailable. Based on common smart contract patterns.
        """
        properties = [
            {
                "type": "invariant",
                "name": "totalSupplyIntegrity",
                "cvl_code": "invariant totalSupplyMatchesBalances()\n    totalSupply() == sumOfBalances();",
                "description": "Total token supply equals sum of all balances",
                "confidence": 0.85,
            },
            {
                "type": "rule",
                "name": "transferPreservesSupply",
                "cvl_code": "rule transferPreservesSupply(address to, uint256 amount) {\n    env e;\n    uint256 supplyBefore = totalSupply();\n    transfer(e, to, amount);\n    uint256 supplyAfter = totalSupply();\n    assert supplyBefore == supplyAfter;\n}",
                "description": "Transfers do not change total supply",
                "confidence": 0.90,
            },
            {
                "type": "rule",
                "name": "onlyOwnerCanMint",
                "cvl_code": "rule onlyOwnerCanMint(uint256 amount) {\n    env e;\n    require e.msg.sender != owner();\n    mint@withrevert(e, amount);\n    assert lastReverted;\n}",
                "description": "Only owner can mint new tokens",
                "confidence": 0.80,
            },
        ]
        return properties[: self.max_properties]

    def _build_cvl_spec(self, contract_info: Dict, properties: List[Dict]) -> str:
        """Build complete CVL specification file."""
        cvl_lines = [
            f"// CVL Specification for {contract_info['name']}",
            "// Generated by PropertyGPT (MIESC)",
            f"// Date: {time.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "methods {",
            f"    // Contract: {contract_info['name']}",
        ]

        # Add function signatures
        for func in contract_info.get("functions", []):
            params = func.get("params", "")
            cvl_lines.append(f"    function {func['name']}({params}) external;")

        cvl_lines.append("}")
        cvl_lines.append("")

        # Add generated properties
        for prop in properties:
            cvl_lines.append(f"// {prop.get('description', 'Property')}")
            cvl_lines.append(f"// Confidence: {prop.get('confidence', 0.0):.2f}")
            cvl_lines.append(prop.get("cvl_code", ""))
            cvl_lines.append("")

        return "\n".join(cvl_lines)

    def _validate_cvl_syntax(self, cvl_spec: str) -> Dict[str, Any]:
        """
        Validate CVL syntax (basic check).

        Note: Full validation requires Certora Prover.
        """
        validation = {"valid": True, "errors": [], "warnings": []}

        # Basic syntax checks
        if "invariant" not in cvl_spec and "rule" not in cvl_spec:
            validation["warnings"].append("No properties found in CVL spec")

        # Check for balanced braces
        if cvl_spec.count("{") != cvl_spec.count("}"):
            validation["valid"] = False
            validation["errors"].append("Unbalanced braces in CVL spec")

        # Check for required sections
        if "methods {" not in cvl_spec:
            validation["warnings"].append("Missing 'methods' section")

        return validation

    def normalize_findings(self, raw_output: Any) -> List[Dict[str, Any]]:
        """
        Convert PropertyGPT output to MIESC findings format.

        Properties become "recommendations" rather than vulnerabilities.
        """
        if isinstance(raw_output, dict) and "properties" in raw_output:
            findings = []
            for prop in raw_output["properties"]:
                finding = {
                    "id": f"PROPERTY-{prop.get('name', 'UNKNOWN')}",
                    "type": "formal_property_recommendation",
                    "severity": "Info",
                    "confidence": prop.get("confidence", 0.0),
                    "location": {"file": "Generated CVL", "line": 0},
                    "message": f"Generated formal property: {prop.get('name')}",
                    "description": prop.get("description", ""),
                    "recommendation": f"Add this property to Certora verification:\n{prop.get('cvl_code', '')}",
                    "cvl_code": prop.get("cvl_code", ""),
                    "property_type": prop.get("type", "unknown"),
                }
                findings.append(finding)
            return findings
        return []

    def can_analyze(self, contract_path: str) -> bool:
        """Check if file is a Solidity contract."""
        return contract_path.endswith(".sol")

    def get_default_config(self) -> Dict[str, Any]:
        """Return default configuration."""
        return {
            "llm_backend": "ollama",
            "ollama_model": "openhermes",
            "max_properties": 10,
            "min_confidence": 0.7,
            "enable_validation": True,
        }


# Adapter registration
def register_adapter():
    """Register PropertyGPT adapter with MIESC."""
    return {"adapter_class": PropertyGPTAdapter, "metadata": PropertyGPTAdapter().get_metadata()}
