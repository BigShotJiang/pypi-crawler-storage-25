# Extractors

* Emails
  * RFC5322
  * Practical
  * Gmail
  * Outlook
  * ICloud
  * Yahoo
  * ProtonMail
* URLs
  * Github Accounts
  * LinkedIn Accounts
  * Instagram Accounts
  * Facebook Accounts
  * Generic function (to get account of any site - name passed as parameter)
* Datetime
  * Dates
    * Day
    * Month
    * Year
  * Times
    * Hours
    * Minutes
    * Seconds
    * Milliseconds
  * Timezones
* Phone numbers
  * Phone number
  * Counrty Code
* UUID
  * UUID1
  * UUID2
  * UUID3
  * UUID4
* CopyRights
  * From code files/Comments
* OpenSource Licenses
