# Email Address Providers

Major Email Address Providers

1. Gmail
2. Outlook
3. Icloud
4. Yahoo
5. Proton mail (security focused options)
6. Zoho email



# Gmail Rules

Gmail usernames must be 6–30 characters long, containing only letters (a-z), numbers (0-9), and periods (.). They cannot start or end with a period, nor contain consecutive periods (e.g., `user..name@gmail.com` is invalid). Gmail ignores periods and case, meaning `John.Doe@gmail.com` is the same as `johndoe@gmail.com`. ![Google Help]()Google Help** +4**

**Key Gmail Address Rules & Features:**

* **Allowed Characters:** **Only alphanumeric characters and periods.**
* **Forbidden Characters:** **No spaces, underscores (**`_`), dashes (`-`), ampersands (`&`), equals signs (`=`), apostrophes (`'`), plus signs (`+`), commas (`,`), or brackets (`<,>`).
* **Case Insensitivity:** `Username@gmail.com` **is treated the same as** `username@gmail.com`.
* **The Dot Trick:** **Adding or removing dots (**`.`) does not create a new account; `john.doe@gmail.com` **and** `john.d.o.e@gmail.com` **both belong to** `johndoe@gmail.com`.
* **The Plus Trick:** **You can add a plus sign and any word after your username to create aliases (e.g.,** `username+shopping@gmail.com`) for filtering, with all mail going to your main inbox.



# Generic Email Length Rules

According to technical standards (RFC 3696/5321), the maximum length for an email address is  =**320 characters**= . This includes 64 characters for the local part (before the @), 255 characters for the domain part (after the @), and the @ symbol itself. ![ZeroBounce]()ZeroBounce** +1**

**Key Breakdown:**

* **Total Maximum Length:** **320 characters.**
* **Local Part (Before @):** **64 characters.**
* **Domain Part (After @):** **255 characters.**
* **Practical Limit:** **While 320 is the strict technical maximum, some systems (like older SMTP implementations) might limit it to 256 characters.**


# Consecuritve ++ in email: 

Yes, an email address can contain consecutive plus signs (`++`) in the local part (before the @ symbol). While individual email providers may have stricter rules, standard email protocols (RFCs) generally allow special characters like `+` to appear consecutively, such as `user++name@example.com`



# ICLOUD MAIL

iCloud email address rules =require a unique username (3-20 characters), ending in @icloud.com or @me.com, and must be created on an Apple device

**Allowed Characters**

* **Letters** **: Standard Latin alphabet (a-z or A-Z)**
* **Numbers** **: Digits** 0-9
* **Special Characters** **: Only** **periods** **(**`.`) and **underscores** **(**`_`) are standard.
* **Hyphens** **: While hyphens (**`-`) are common in general email standards, they are sometimes restricted or not recommended when creating new iCloud addresses or Apple IDs


# HotMail

Hotmail is a pioneering free web-based email service= launched in 1996 and acquired by Microsoft in 1997. It was rebranded and migrated to **[Outlook.com](https://www.google.com/search?q=Outlook.com&sca_esv=f0f46d557053f7c4&sxsrf=ANbL-n73FBcUcuCsLGTHrP9Gv2sx0KsCcw%3A1776114542768&ei=blvdab_ILp2J9u8P7dSJoQU&biw=1536&bih=695&ved=2ahUKEwjmwNCn3uuTAxXR9LsIHbSzFyUQgK4QegYIAQgAEAQ&uact=5&oq=what+is+hotmail&gs_lp=Egxnd3Mtd2l6LXNlcnAiD3doYXQgaXMgaG90bWFpbDILEAAYgAQYkQIYigUyCxAAGIAEGJECGIoFMgoQABiABBgUGIcCMgUQABiABDIFEAAYgAQyChAAGIAEGBQYhwIyBRAAGIAEMgUQABiABDIFEAAYgAQyBRAAGIAESMkkUJECWMQicAd4AZABAZgBmwOgAeclqgEIMi0xNS4yLjG4AQPIAQD4AQGYAhigAoYkwgIKEAAYsAMY1gQYR8ICDRAAGIAEGLADGEMYigXCAhcQLhiwAxi4BhjYAhjIAxjaBhjcBtgBAcICBBAjGCfCAgoQIxiABBgnGIoFwgIQEAAYgAQYsQMYQxiDARiKBcICEBAuGIAEGNEDGEMYxwEYigXCAggQABiABBixA8ICDRAAGIAEGLEDGEMYigXCAg4QABiABBixAxiDARiKBcICCxAAGIAEGLEDGIoFwgILEAAYgAQYsQMYgwHCAgcQABiABBgNmAMAiAYBkAYUugYGCAEQARgZkgcKNy4wLjE0LjIuMaAHmJABsgcIMi0xNC4yLjG4B_EjwgcGMC4yMS4zyAcvgAgA&sclient=gws-wiz-serp)** in 2013. While new @hotmail.com addresses cannot be created, existing accounts remain fully functional, using the same username and password to log in through the **Outlook website**
