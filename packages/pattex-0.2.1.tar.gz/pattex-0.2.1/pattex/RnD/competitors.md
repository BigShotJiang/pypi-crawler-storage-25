# Competitors: 

* https://github.com/InQuest/iocextract
