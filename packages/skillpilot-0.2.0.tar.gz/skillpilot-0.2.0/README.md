# devpilot

258 AI skills for developers — companion CLI for the devpilot formation.

## Install

pip install devpilot

## Usage

devpilot init
devpilot list
devpilot run <skill> --input "your code"
