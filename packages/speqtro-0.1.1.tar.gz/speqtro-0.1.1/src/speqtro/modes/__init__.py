"""speqtro pipeline modes package."""
