"""speqtro web interface package."""
