"""Forge Verify middleware for LangGraph / LangChain.

Intercepts every tool call and verifies it against Forge policies before execution.

Usage:
    from forge_langgraph import ForgeVerifyMiddleware

    middleware = ForgeVerifyMiddleware(policy="finance-controls")

    agent = create_react_agent(
        model="gpt-4.1",
        tools=[send_payment, read_balance],
        middleware=[middleware],
    )
"""

__version__ = "0.1.0"

from .middleware import ForgeVerifyMiddleware, forge_verify_tool

__all__ = ["ForgeVerifyMiddleware", "forge_verify_tool"]
