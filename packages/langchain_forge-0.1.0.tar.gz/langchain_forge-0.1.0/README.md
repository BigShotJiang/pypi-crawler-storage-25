# langchain-forge

Forge Verify middleware for [LangGraph](https://github.com/langchain-ai/langgraph) and [LangChain](https://github.com/langchain-ai/langchain). Verifies every AI agent tool call against your policies **before** execution.

## Install

```bash
pip install langchain-forge
```

## Quick Start

```python
import os
from langgraph.prebuilt import create_react_agent
from langchain_core.tools import tool
from forge_langgraph import ForgeVerifyMiddleware

os.environ["VERITERA_API_KEY"] = "vt_live_..."
os.environ["OPENAI_API_KEY"] = "sk-..."

@tool
def send_payment(amount: float, recipient: str) -> str:
    """Send a payment to a recipient."""
    return f"Sent ${amount} to {recipient}"

@tool
def delete_record(record_id: str) -> str:
    """Delete a database record."""
    return f"Deleted {record_id}"

# Add Forge middleware — one line
middleware = ForgeVerifyMiddleware(policy="finance-controls")

agent = create_react_agent(
    model="gpt-4.1",
    tools=[send_payment, delete_record],
    middleware=[middleware],
)

# Every tool call is verified before execution
result = agent.invoke({"messages": [("user", "Send $500 to vendor@acme.com")]})
```

## How It Works

1. LangGraph decides to call a tool
2. **Before execution**, the middleware calls Forge `/v1/verify`
3. If **approved**: the tool runs normally
4. If **denied**: the LLM receives a denial message and can explain why

## Standalone Tool

If you prefer the LLM to call verification explicitly:

```python
from forge_langgraph import forge_verify_tool

verify = forge_verify_tool(policy="finance-controls")
agent = create_react_agent(model, tools=[send_payment, verify])
```

## Configuration

```python
middleware = ForgeVerifyMiddleware(
    api_key="vt_live_...",           # or VERITERA_API_KEY env var
    agent_id="prod-finance-bot",
    policy="finance-controls",
    fail_closed=True,                # deny when API is unreachable
    skip_actions=["read_balance"],   # skip read-only tools
    on_blocked=lambda a, r: print(f"BLOCKED: {a} — {r}"),
    on_verified=lambda a, r: print(f"APPROVED: {a}"),
)
```

## License

MIT — [Veritera AI](https://veritera.ai)
