"""
IBKR Signal Agent — polls Supabase for trade signals and places orders via IB Gateway.
"""
import logging
import os
import time
import urllib.request
import urllib.error
import json
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler

from dotenv import dotenv_values
from supabase import create_client
from zoneinfo import ZoneInfo

from quantglide_ibkr.adapter import IBKRGatewayAdapter

EASTERN = ZoneInfo("America/New_York")

POLL_INTERVAL_S = 2
MIN_CREDIT = 0.10

EXCHANGE_URL = "https://app.quantglide.com/api/ibkr/exchange"


# ── Config ───────────────────────────────────────────────────────────────────

def load_config(env_path: str) -> dict:
    vals = dotenv_values(env_path)
    def get(key, default=""):
        return (vals.get(key) or os.environ.get(key) or default).strip()
    return {
        "QUANTGLIDE_TOKEN": get("QUANTGLIDE_TOKEN"),
        "IBKR_HOST":        get("IBKR_HOST", "127.0.0.1"),
        "IBKR_PORT":        int(get("IBKR_PORT", "4001")),
        "IBKR_CLIENT_ID":   int(get("IBKR_CLIENT_ID", "10")),
    }


# ── Logger ───────────────────────────────────────────────────────────────────

def setup_logger() -> logging.Logger:
    lgr = logging.getLogger("quantglide_ibkr")
    if lgr.handlers:
        return lgr  # already configured
    lgr.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    fh = RotatingFileHandler("ibkr_agent.log", maxBytes=5 * 1024 * 1024, backupCount=2)
    fh.setFormatter(fmt)
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    lgr.addHandler(fh)
    lgr.addHandler(ch)
    return lgr


# ── Credential exchange ───────────────────────────────────────────────────────

def exchange_token(token: str, logger: logging.Logger) -> dict:
    """
    Exchange the permanent UUID token for fresh credentials from QuantGlide.
    Called on every startup — no local credential storage needed.
    """
    logger.info("[AUTH] Fetching credentials from QuantGlide...")
    body = json.dumps({"token": token}).encode()
    req = urllib.request.Request(
        EXCHANGE_URL,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            payload = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        if e.code == 401 or e.code == 404:
            raise RuntimeError(
                "Setup token not recognised.\n"
                "Re-copy your token from the QuantGlide dashboard and re-run:\n"
                "    quantglide-ibkr --token <token>"
            )
        raise RuntimeError(f"Credential exchange failed ({e.code}): {body}")
    except urllib.error.URLError as e:
        raise RuntimeError(
            f"Could not reach QuantGlide ({e.reason}).\n"
            "Check your internet connection and try again."
        )

    required = {"supabase_url", "supabase_key", "refresh_token", "user_id"}
    missing = required - payload.keys()
    if missing:
        raise RuntimeError(f"Incomplete response from exchange endpoint: missing {missing}")

    logger.info(f"[AUTH] Credentials received  user={payload['user_id']}")
    return payload


# ── Supabase auth ─────────────────────────────────────────────────────────────

def get_supabase(creds: dict, logger: logging.Logger):
    sb = create_client(creds["supabase_url"], creds["supabase_key"])
    result = sb.auth.refresh_session(creds["refresh_token"])
    if not result.session:
        raise RuntimeError(
            "Supabase session could not be established.\n"
            "This is unusual — try re-running the agent. If it persists, "
            "re-copy your token from the QuantGlide dashboard."
        )
    logger.info("[AUTH] Authenticated with QuantGlide")
    return sb


# ── Active check ──────────────────────────────────────────────────────────────

def is_agent_active(sb, user_id: str, logger: logging.Logger) -> bool:
    try:
        resp = (
            sb.table("trading_config")
            .select("active")
            .eq("user_id", user_id)
            .execute()
        )
        if resp.data and not resp.data[0].get("active", True):
            return False
    except Exception as e:
        logger.warning(f"[ACTIVE] Check failed, proceeding: {e}")
    return True


# ── Order execution ───────────────────────────────────────────────────────────

def execute_signal(signal: dict, ibkr: IBKRGatewayAdapter, logger: logging.Logger) -> tuple[str, float | None]:
    direction    = signal["direction"]
    is_put       = direction == "bull_put"
    short_strike = float(signal["short_strike"])
    long_strike  = float(signal["long_strike"])
    qty          = int(signal["qty"])
    expiry_ibkr  = signal["expiration_date"].replace("-", "")
    limit_credit = signal.get("limit_credit")

    logger.info(
        f"[EXEC] {direction} {short_strike}/{long_strike} qty={qty} expiry={expiry_ibkr}"
        + (f" hint_credit={limit_credit:.2f}" if limit_credit else "")
    )

    try:
        trade = ibkr.place_credit_spread(
            symbol="SPX",
            expiration=expiry_ibkr,
            short_strike=short_strike,
            long_strike=long_strike,
            is_put=is_put,
            qty=qty,
            limit_price=limit_credit,
            min_credit=MIN_CREDIT,
        )
    except Exception as e:
        logger.error(f"[EXEC] Error: {e}")
        return "error", None

    if trade and trade.orderStatus.status == "Filled":
        fill_price = abs(trade.orderStatus.avgFillPrice)
        logger.info(f"[EXEC] FILLED @ {fill_price:.2f}")
        return "filled", fill_price

    logger.info("[EXEC] Not filled")
    return "not_filled", None


def update_signal(sb, signal_id: str, status: str, fill_price=None, error=None, logger=None):
    update = {
        "status": status,
        "agent_result": status,
        "agent_completed_at": datetime.now(timezone.utc).isoformat(),
    }
    if fill_price is not None:
        update["agent_fill_price"] = fill_price
    if error:
        update["agent_error"] = error
    try:
        sb.table("trade_signals").update(update).eq("id", signal_id).execute()
    except Exception as e:
        if logger:
            logger.error(f"[RELAY] Failed to update signal {signal_id}: {e}")


# ── Main loop ─────────────────────────────────────────────────────────────────

def run(env_path: str, no_time_gate: bool = False, dry_run: bool = False):
    cfg = load_config(env_path)
    logger = setup_logger()

    if not cfg["QUANTGLIDE_TOKEN"]:
        print("No setup token found. Run:")
        print("    quantglide-ibkr --token <paste_token_from_dashboard>")
        raise SystemExit(1)

    # Exchange UUID for fresh credentials on every startup — nothing to rotate locally
    creds = exchange_token(cfg["QUANTGLIDE_TOKEN"], logger)
    user_id = creds["user_id"]

    port = cfg["IBKR_PORT"]
    mode = "paper" if port == 4002 else "live"
    logger.info(f"[BOOT] QuantGlide IBKR Agent  user={user_id}  gateway={cfg['IBKR_HOST']}:{port} ({mode})")
    if no_time_gate:
        logger.info("[BOOT] Time gate disabled")
    if dry_run:
        logger.info("[BOOT] Dry run — signals will be claimed but no orders placed")

    sb = get_supabase(creds, logger)

    logger.info("[DB] Checking Supabase connection...")
    try:
        sb.table("trade_signals").select("id").eq("target_user_id", user_id).limit(1).execute()
        logger.info("[DB] Connected OK")
    except Exception as e:
        logger.warning(f"[DB] Could not read trade_signals: {e}")

    ibkr = IBKRGatewayAdapter(
        host=cfg["IBKR_HOST"],
        port=port,
        client_id=cfg["IBKR_CLIENT_ID"],
        account=None,
    )

    logger.info(f"[GW] Connecting to IB Gateway at {cfg['IBKR_HOST']}:{port}...")
    try:
        ibkr.connect()
        logger.info(f"[GW] Connected  account={ibkr.acct_id}")
    except Exception as e:
        logger.warning(
            f"[GW] Could not reach IB Gateway — {e}\n"
            f"      Make sure IB Gateway is running with API connections enabled.\n"
            f"      The agent will retry when a signal arrives."
        )

    processed_today: set[str] = set()
    last_date = None

    while True:
        now = datetime.now(EASTERN)
        today = now.date()

        if last_date != today:
            processed_today.clear()
            last_date = today
            logger.info(f"[DAY] {today}")

        if not no_time_gate:
            h, m = now.hour, now.minute
            if today.weekday() >= 5 or h < 10 or (h == 10 and m < 25) or h >= 13:
                time.sleep(30 if h < 13 else 3600)
                continue

        ibkr.ensure_connected()

        try:
            resp = (
                sb.table("trade_signals")
                .select("*")
                .eq("status", "pending")
                .eq("signal_date", str(today))
                .eq("target_user_id", user_id)
                .execute()
            )
        except Exception as e:
            logger.error(f"[POLL] Query failed: {e}")
            time.sleep(10)
            continue

        for signal in (resp.data or []):
            sig_id = signal["id"]
            if sig_id in processed_today:
                continue

            logger.info(f"[SIGNAL] {signal['direction']} {signal['short_strike']}/{signal['long_strike']} qty={signal['qty']}")

            try:
                claim = sb.table("trade_signals").update({
                    "status": "claimed",
                    "agent_claimed_at": datetime.now(timezone.utc).isoformat(),
                }).eq("id", sig_id).eq("status", "pending").execute()
                if not claim.data:
                    processed_today.add(sig_id)
                    continue
            except Exception as e:
                logger.error(f"[SIGNAL] Claim failed: {e}")
                continue

            processed_today.add(sig_id)

            try:
                check = sb.table("trade_signals").select("status").eq("id", sig_id).execute()
                if check.data and check.data[0]["status"] == "cancelled":
                    logger.info(f"[SIGNAL] {sig_id} cancelled before execution")
                    continue
            except Exception:
                pass

            if not is_agent_active(sb, user_id, logger):
                logger.info("[SKIP] Bot is deactivated in dashboard")
                update_signal(sb, sig_id, "skip", logger=logger)
                continue

            if dry_run:
                logger.info(f"[DRY RUN] Would place {signal['direction']} {signal['short_strike']}/{signal['long_strike']} qty={signal['qty']}")
                update_signal(sb, sig_id, "filled", fill_price=signal.get("limit_credit"), logger=logger)
                continue

            if not ibkr.ensure_connected():
                logger.error("[IBKR] Connection failed, cannot execute signal")
                update_signal(sb, sig_id, "error", error="Gateway not reachable", logger=logger)
                continue

            result, fill_price = execute_signal(signal, ibkr, logger)
            update_signal(sb, sig_id, result, fill_price=fill_price, logger=logger)

        time.sleep(POLL_INTERVAL_S)
