# ibkr_adapter_gw.py
"""
IBKR order adapter using the IB Gateway socket API (ib_insync).

Requires IB Gateway or TWS running:
  - Port 4001: IB Gateway live
  - Port 4002: IB Gateway paper
  - Port 7496: TWS live
  - Port 7497: TWS paper
"""
import asyncio
import logging
import math
import time

# ib_insync (via eventkit) calls asyncio.get_event_loop() at import time,
# which raises RuntimeError in Python 3.14+ when no loop exists yet.
try:
    asyncio.get_event_loop()
except RuntimeError:
    asyncio.set_event_loop(asyncio.new_event_loop())

from ib_insync import IB, Option, Contract, ComboLeg, LimitOrder, MarketOrder

logger = logging.getLogger('quantglide_ibkr.adapter')

TICK_SIZE = 0.05
MIN_CREDIT_DEFAULT = 0.10  # IBKR rejects < $0.10 as "guaranteed-to-lose"
POLL_INTERVAL_S = 3
MAX_REPRICE_STEPS = 6
STEP_WAIT_S = 8  # seconds to wait at each price level before repricing

RECONNECT_BACKOFF_S = [1, 2, 5, 10, 30, 60]
MAX_RECONNECT_ATTEMPTS = 10


class IBKRGatewayAdapter:
    """IBKR order adapter using IB Gateway socket API (ib_insync)."""

    def __init__(self, host='127.0.0.1', port=4001, client_id=1, account=None):
        self.ib = IB()
        self.host = host
        self.port = port
        self.client_id = client_id
        self._connected = False
        self._intentional_disconnect = False
        self.acct_id = None
        self._account_override = account  # explicit sub-account for FA accounts
        self.ib.disconnectedEvent += self._on_disconnect

    @property
    def connected(self) -> bool:
        """True only if the underlying socket is actually connected."""
        return self._connected and self.ib.isConnected()

    # ── Connection ──────────────────────────────────────────────────────

    def _on_disconnect(self):
        """Callback fired by ib_insync when the socket drops."""
        self._connected = False
        if not self._intentional_disconnect:
            logger.warning("[IBKR] Disconnected from gateway (disconnectedEvent fired)")

    def connect(self):
        """Connect to IB Gateway via socket."""
        if self.ib.isConnected():
            self.ib.disconnect()
        self.ib.connect(
            host=self.host,
            port=self.port,
            clientId=self.client_id,
            timeout=20,
        )
        accounts = self.ib.managedAccounts()
        if not accounts:
            raise RuntimeError("No IBKR accounts found")
        if self._account_override:
            if self._account_override not in accounts:
                raise RuntimeError(
                    f"Specified ibkr_account '{self._account_override}' not in "
                    f"managed accounts: {accounts}"
                )
            self.acct_id = self._account_override
        else:
            self.acct_id = accounts[0]
        self._connected = True
        logger.info(
            f"[IBKR] Connected via Gateway socket "
            f"{self.host}:{self.port}, account={self.acct_id} "
            f"(managed: {accounts})"
        )

    def ensure_connected(self) -> bool:
        """Check connection and reconnect if needed. Returns True if connected."""
        if self.connected:
            return True
        logger.warning("[IBKR] Connection lost, attempting to reconnect...")
        for attempt in range(1, MAX_RECONNECT_ATTEMPTS + 1):
            backoff = RECONNECT_BACKOFF_S[min(attempt - 1, len(RECONNECT_BACKOFF_S) - 1)]
            try:
                self.connect()
                logger.info(f"[IBKR] Reconnected on attempt {attempt}")
                return True
            except Exception as e:
                logger.warning(
                    f"[IBKR] Reconnect attempt {attempt}/{MAX_RECONNECT_ATTEMPTS} "
                    f"failed: {e}  (retry in {backoff}s)"
                )
                time.sleep(backoff)
        logger.error(
            f"[IBKR] Failed to reconnect after {MAX_RECONNECT_ATTEMPTS} attempts"
        )
        return False

    def disconnect(self):
        if self._connected or self.ib.isConnected():
            self._intentional_disconnect = True
            self.ib.disconnect()
            self._connected = False
            self._intentional_disconnect = False
            logger.info("[IBKR] Disconnected")

    # ── Market data helpers ────────────────────────────────────────────

    def _get_option_mid(self, contract) -> float | None:
        """Request snapshot market data and return mid price.
        Uses regulatory snapshot ($0.03/req for options) — no subscription needed."""
        self.ib.reqMarketDataType(1)  # 1 = live
        self.ib.reqMktData(contract, snapshot=False, regulatorySnapshot=True)
        self.ib.sleep(3)
        ticker = self.ib.ticker(contract)
        if ticker is None:
            return None

        bid = ticker.bid
        ask = ticker.ask

        # bid/ask can be nan or -1 when unavailable
        bid_ok = bid is not None and math.isfinite(bid) and bid > 0
        ask_ok = ask is not None and math.isfinite(ask) and ask > 0

        if bid_ok and ask_ok:
            return (bid + ask) / 2.0
        if bid_ok:
            return bid
        if ask_ok:
            return ask
        return None

    def _get_spread_mid_credit(self, short_contract, long_contract) -> float | None:
        """Compute mid-price credit for a vertical spread from IBKR market data."""
        short_mid = self._get_option_mid(short_contract)
        long_mid = self._get_option_mid(long_contract)

        logger.info(
            f"[IBKR] Leg prices: short_mid={short_mid} long_mid={long_mid}"
        )

        if short_mid is None or long_mid is None:
            return None

        credit = short_mid - long_mid
        return credit if credit > 0 else None

    @staticmethod
    def _round_down_tick(price: float) -> float:
        """Round price DOWN to nearest tick (float-safe)."""
        return round(math.floor(round(price, 4) / TICK_SIZE) * TICK_SIZE, 2)

    @staticmethod
    def _round_tick(price: float) -> float:
        """Round price to nearest tick."""
        return round(round(price / TICK_SIZE) * TICK_SIZE, 2)

    def _cancel_and_wait(self, trade, timeout_s=5) -> bool:
        """Cancel an order and wait for acknowledgement. Returns True if confirmed cancelled."""
        try:
            self.ib.cancelOrder(trade.order)
        except Exception as e:
            logger.warning(f"[IBKR] Cancel request failed: {e}")
            return False
        elapsed = 0
        while elapsed < timeout_s:
            self.ib.sleep(1)
            elapsed += 1
            status = trade.orderStatus.status
            if status in ('Cancelled', 'ApiCancelled'):
                return True
            if status == 'Filled':
                return False  # filled during cancel
        logger.warning(
            f"[IBKR] Cancel not confirmed after {timeout_s}s, "
            f"status={trade.orderStatus.status}"
        )
        return False

    # ── Place orders ────────────────────────────────────────────────────

    def place_credit_spread(
        self,
        symbol,
        expiration,      # "YYYYMMDD"
        short_strike,    # float
        long_strike,     # float
        is_put,          # bool
        qty,             # int
        limit_price=None,  # optional override; if None, adapter fetches mid
        min_credit=MIN_CREDIT_DEFAULT,
    ):
        """
        Place a vertical credit spread with linear reprice.

        1. Qualify contracts & fetch IBKR market data for mid credit.
        2. Place limit order at mid (rounded to tick).
        3. Poll for fill; step price down by one tick each step.
        4. If price hits min_credit, final poll then cancel if unfilled.

        Returns ib_insync Trade object if filled, None otherwise.
        """
        if not self.ensure_connected():
            logger.error("[IBKR] Not connected and reconnect failed")
            return None

        right = "P" if is_put else "C"

        short_contract = Option(symbol, expiration, short_strike, right, 'CBOE')
        long_contract = Option(symbol, expiration, long_strike, right, 'CBOE')

        try:
            self.ib.qualifyContracts(short_contract, long_contract)
        except Exception as e:
            logger.warning(f"[IBKR] Contract qualification failed: {e} — retrying after reconnect")
            if not self.ensure_connected():
                logger.error("[IBKR] Reconnect failed, cannot qualify contracts")
                return None
            # Re-create contracts since qualification may have partially mutated them
            short_contract = Option(symbol, expiration, short_strike, right, 'CBOE')
            long_contract = Option(symbol, expiration, long_strike, right, 'CBOE')
            try:
                self.ib.qualifyContracts(short_contract, long_contract)
            except Exception as e2:
                logger.error(f"[IBKR] Contract qualification failed after reconnect: {e2}")
                return None

        if not short_contract.conId or not long_contract.conId:
            logger.error(
                f"[IBKR] Missing conIds after qualify: "
                f"short={short_contract.conId} long={long_contract.conId}"
            )
            return None

        # ── Get mid credit from IBKR market data ──
        mid_credit = self._get_spread_mid_credit(short_contract, long_contract)

        if mid_credit is not None and mid_credit > 0:
            start_price = self._round_down_tick(mid_credit)
        elif limit_price is not None and limit_price > 0:
            logger.warning(
                f"[IBKR] Could not get mid from IBKR, using caller price: {limit_price:.2f}"
            )
            start_price = self._round_tick(limit_price)
        else:
            logger.error("[IBKR] No valid price available for spread")
            return None

        start_price = max(start_price, min_credit)

        logger.info(
            f"[IBKR] Spread pricing: mid_credit={mid_credit} "
            f"start_price={start_price:.2f} min_credit={min_credit:.2f}"
        )

        # ── Build combo (BAG) contract ──
        combo = Contract()
        combo.symbol = symbol
        combo.secType = 'BAG'
        combo.currency = 'USD'
        combo.exchange = 'SMART'

        leg1 = ComboLeg()
        leg1.conId = short_contract.conId
        leg1.ratio = 1
        leg1.action = 'SELL'
        leg1.exchange = 'CBOE'

        leg2 = ComboLeg()
        leg2.conId = long_contract.conId
        leg2.ratio = 1
        leg2.action = 'BUY'
        leg2.exchange = 'CBOE'

        combo.comboLegs = [leg1, leg2]

        # ── Linear reprice loop ──
        price = start_price
        last_trade = None

        for step in range(MAX_REPRICE_STEPS):
            price = round(price, 2)

            order = LimitOrder(
                action='BUY',
                totalQuantity=qty,
                lmtPrice=-price,
                tif='DAY',
                account=self.acct_id,
            )

            logger.info(
                f"[IBKR] Step {step}: placing credit spread {symbol} "
                f"{short_strike}/{long_strike} {right} qty={qty} "
                f"@ ${price:.2f} credit | "
                f"short_conId={short_contract.conId} long_conId={long_contract.conId}"
            )

            try:
                trade = self.ib.placeOrder(combo, order)
                last_trade = trade
                logger.info(
                    f"[IBKR] Order submitted: orderId={trade.order.orderId} "
                    f"status={trade.orderStatus.status}"
                )
            except Exception as e:
                logger.error(f"[IBKR] Failed to place spread: {e}")
                return None

            # Poll for fill
            elapsed = 0
            while elapsed < STEP_WAIT_S:
                self.ib.sleep(POLL_INTERVAL_S)
                elapsed += POLL_INTERVAL_S
                status = trade.orderStatus.status
                logger.info(
                    f"[IBKR] Poll orderId={trade.order.orderId} "
                    f"status={status} filled={trade.orderStatus.filled}"
                )
                if status == 'Filled':
                    logger.info(
                        f"[IBKR] FILLED @ ${price:.2f} credit "
                        f"(step={step}, orderId={trade.order.orderId})"
                    )
                    return trade
                if status in ('Cancelled', 'ApiCancelled', 'Inactive'):
                    logger.warning(f"[IBKR] Order rejected: {status}")
                    return None

            # Not filled — check if we can reprice lower
            next_price = round(price - TICK_SIZE, 2)
            if next_price < min_credit:
                logger.info(f"[IBKR] At credit floor ${price:.2f}, final poll...")
                extra = 0
                while extra < STEP_WAIT_S:
                    self.ib.sleep(POLL_INTERVAL_S)
                    extra += POLL_INTERVAL_S
                    if trade.orderStatus.status == 'Filled':
                        logger.info(f"[IBKR] FILLED at floor @ ${price:.2f}")
                        return trade
                self._cancel_and_wait(trade)
                if trade.orderStatus.status == 'Filled':
                    logger.info(f"[IBKR] Filled during cancel @ ${price:.2f}")
                    return trade
                logger.info("[IBKR] Cancelled unfilled order at credit floor")
                return None

            self._cancel_and_wait(trade)
            if trade.orderStatus.status == 'Filled':
                logger.info(f"[IBKR] Filled during cancel @ ${price:.2f}")
                return trade
            if trade.orderStatus.status not in ('Cancelled', 'ApiCancelled'):
                logger.warning(
                    f"[IBKR] Cancel not confirmed (status={trade.orderStatus.status}), "
                    f"aborting reprice to avoid duplicate orders"
                )
                return None

            logger.info(
                f"[IBKR] Cancelled orderId={trade.order.orderId} "
                f"for reprice {price:.2f} -> {next_price:.2f}"
            )
            price = next_price

        if last_trade and last_trade.orderStatus.status not in (
            'Filled', 'Cancelled', 'ApiCancelled', 'Inactive'
        ):
            self._cancel_and_wait(last_trade)
            if last_trade.orderStatus.status == 'Filled':
                return last_trade
        logger.info(f"[IBKR] Exhausted {MAX_REPRICE_STEPS} reprice steps, no fill")
        return None
