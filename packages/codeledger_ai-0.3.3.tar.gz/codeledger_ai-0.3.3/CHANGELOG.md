# Changelog

## 0.3.3 — 2026-04-17

### Fixed
- BLOCKING: `credential_manager` crashed with `keyring.errors.NoKeyringError`
  on clean installs in any environment without a system keyring — headless
  Linux, CI, and minimal venvs. `serve` could not start because
  `AuthService` needed to write a JWT signing key through keyring.
  Now falls back to an encrypted file store at
  `<vault_dir>/vault.fallback.enc` (AES-256-GCM + PBKDF2-HMAC-SHA256,
  600,000 iterations) with a machine-local key at `.credential_key`
  (0o600). The fallback uses a separate filename from `config.vault_path`
  so it never collides with an existing explicit-passphrase vault.
  System keyring is still used when available — desktop installs are
  unchanged.

## 0.3.2 — 2026-04-16

### Fixed
- Republish of the 0.3.1 `click` pin fix. The 0.3.1 artifact on PyPI did
  not reflect the widened `click>=8.1,<9.0` pin in practice, so users
  continued to see the `typer>=0.24` conflict. 0.3.2 is a clean rebuild
  from the post-fix tree with no code changes versus 0.3.1's intent.

## 0.3.1 — 2026-04-16

### Fixed
- Widen `click` dependency pin from `~=8.1.0` (which excluded 8.2+) to
  `>=8.1,<9.0`. The prior pin conflicted with `typer>=0.24` (requires
  `click>=8.2.1`) and with any environment that had already upgraded
  `click` to 8.2 or 8.3, causing pip to downgrade `click` on install and
  break unrelated tools in the user's Python environment.

## 0.3.0 — 2026-04-16

### Added — passive decision inference (GR-1 through GR-10)
- `backend/intelligence/inference_evidence.py` — evidence taxonomy with 13
  typed signals, a 129-module Python stdlib blocklist, a noise-packages
  list, and the `classify_import` helper used to reject `import json` as
  architectural noise (GR-10).
- `backend/intelligence/decision_inferrer.py` extended with a full
  evidence pipeline: library-grouped `Add <pkg> dependency` candidates,
  config-file / migration-file detection, 10-second `asyncio.wait_for`
  budget (GR-5), semantic-search deduplication against existing
  decisions (GR-7), and structured evidence persisted to a new
  `inferred_decisions.evidence` column (GR-4).
- Calibrated confidence scoring — single-signal cap at 0.65, multi-signal
  cap at 0.85, `MIN_VIABLE_CONFIDENCE` filter at 0.20 (GR-2). The
  previous 0.75 single-file ladder is gone by design.

### Added — context verification layer (VGR-1 through VGR-7)
- `backend/verification/context_verifier.py` — `ContextVerifier` stamps
  every retrieved decision with `verification_status` (VERIFIED, DRIFTED,
  STALE, SUPERSEDED, UNVERIFIED, INFERRED), action guidance, and (when
  drifted) the exact violating file and line.
- SUPERSEDED decisions are filtered before triage and reported on a
  separate excluded list (VGR-5); DRIFTED decisions are kept with a
  `[DRIFT]` marker so the agent can see both the intent and the
  violation (VGR-4).
- `backend/advanced/drift_detector.py` now persists violations to a
  cached `drift_violations` table and exposes
  `get_violations_for_decision` as a pure SELECT — the verifier reads
  from cache, never re-walks the filesystem (VGR-3).
- `backend/verification/harness.py` gained a `score_verification_health`
  sensor + `VerificationHealth` result; `score_session` now reports a
  1.0 / 0.7 / 0.5 / 0.4 / unavailable score based on how the session
  engaged with drifted context (VGR-6).
- Context retrieval is wired into all six surfaces: `context.get_relevant`,
  `context.get_for_file`, `context.before_edit`,
  `ensure_session_and_inject_context`, `hooks.session_context`,
  `hooks.file_context`. `context_retrieval` session events feed the
  harness sensor.
- `backend/intelligence/context_triage.py` formatter renders `[DRIFT]`,
  `[SUPERSEDED BY]`, and `[→]` guidance lines inline; token budgeting is
  unchanged.

### Schema
- Migration v9 — `inferred_decisions.evidence TEXT NOT NULL DEFAULT '[]'`.
- Migration v10 — `drift_violations` cache table with
  `(project_id, status)` and `(decision_id, status)` indexes.

### Tests
- 15 new verification guard-rail tests (VGR-1..VGR-7) and 62 inference
  guard-rail tests (GR-1..GR-10, plus taxonomy coverage).
- Full suite: 960 passed, 6 skipped, 0 failed.

## 0.2.4 — 2026-04-16

### Added
- Intelligent instruction-file manager (`backend/utils/instruction_file_manager.py`):
  creates `CLAUDE.md`, `.cursorrules`, `.windsurfrules`, and `.clinerules`
  when missing; updates the CodeLedger-managed block in place when present;
  never destroys content outside that block.
- `codeledger sync [--client all|claude-code|cursor|windsurf|cline]` — re-sync
  per-client instruction files without re-running full init.
- `codeledger desktop-guide` — prints a paste-in briefing for Claude Desktop
  users who have no project-file surface area.
- `codeledger init` now generates all four instruction files automatically.
- `codeledger connect` re-syncs instruction files with the resolved server URL
  so team servers and port overrides propagate into CLAUDE.md / .cursorrules.
- Onboarding step 2 lists all four supported clients and calls out the new
  `codeledger desktop-guide` and `codeledger sync` commands.
- `POST /api/projects` REST endpoint backed by `handlers.project_create`.
- Frontend `api.projects.{list, create}` client methods; project picker now
  persists to `localStorage` and round-trips new projects to the server.

### Fixed
- MCP tools no longer require the caller to pass an explicit `user_id`:
  `AuthMiddleware` now publishes the resolved user through a `ContextVar`
  which `_resolve_user_id` reads as a fallback. Solo-mode Claude Code /
  Cursor / Windsurf sessions can call `session.list`, `decision.create`,
  etc. without knowing their synthetic user UUID.
- "New project…" button in the header project picker now actually creates
  a project — previous behavior updated Zustand state only and lost it on
  refresh. State is now persisted to `localStorage` and mirrored to the
  backend.

## 0.1.8 — 2026-04-16

### Fixed
- Sessions, Memory, and Decisions tabs now render proper empty states
  instead of a blank container when there is no data.
- Sprint velocity chart hides when there are no completed sprints and
  shows an explanatory placeholder; x/y axes now have labels.
- Sprint kanban columns use readable labels (Backlog, In Progress,
  In Review, Done) with a story-count badge, replacing raw enums.
- Explorer tab's stub-data notice is now a prominent banner with UMAP
  axis labels and a per-type colour legend.
- Theme toggle is consolidated in Settings → Appearance; the button
  label and icon now reflect the current theme instead of the inverse.
- MCP Servers list adds an expandable tool panel, a kebab menu
  (Edit / Copy URL / Disconnect), and an auth-type tooltip.
- Settings: security invariants are now expandable with full
  descriptions; Personal Access Tokens section adds a copy-to-clipboard
  button and documentation link.
- Provenance tab shows an onboarding callout when no decisions exist,
  a concise intro, and a colour/shape legend.

### Added
- Header project picker — rename the active project, create a new
  project, and switch between projects inline.
- Header live indicator (30s auto-refresh) with manual refresh button
  and a disconnected state.
- Hash-based deep-linking for every tab (`#memory`, `#decisions`,
  `#sprint`, `#sessions`, `#explorer`, `#provenance`, `#mcp-servers`,
  `#settings`) plus browser back/forward support.
- Memory search: relevance / type sort, page-size selector
  (10 / 25 / 50), previous / next pagination, and in-result term
  highlighting via `<mark>`.
- Decisions detail panel: sticky header with ID + close, status and
  tag chips, "View provenance →" jump, and a per-decision note field.
- Sprint board: "+ Add story" modal (title, description, points,
  priority) and HTML5 drag-and-drop between lanes.
- Settings → Connected services: GitHub, Linear, Jira, and Slack cards
  with connect / disconnect and last-sync timestamps.
- Accessibility pass: visible focus rings on every interactive
  control, `aria-pressed` on filter buttons, `aria-selected` on tabs,
  `role="status"` on empty / loading regions, and explicit foreground
  colour on all select elements.
- Main layout now reserves bottom safe-area padding so externally
  injected overlays (e.g. Claude agent controls) no longer obscure
  app content.

## 0.1.7 — 2026-04-16

### Added
- `codeledger token show` — print the solo bearer token and a
  ready-to-paste MCP config snippet, with the correct Claude Desktop
  config path for the current platform.
- `codeledger token write-config --client claude-desktop|cursor|windsurf`
  — merge the CodeLedger MCP entry into the selected client's config
  automatically, preserving existing `mcpServers` entries.
- `codeledger config set-oauth --provider google|github` — configure
  OAuth client credentials for dashboard login.
- `codeledger init` now prompts for optional Google and GitHub OAuth
  credentials on interactive TTYs; press Enter to skip either.
- New public endpoint `GET /api/auth/oauth/providers` reports which
  OAuth providers are configured, so the login page can disable
  unconfigured buttons instead of producing a confusing error.
- Windows path added to Claude Desktop auto-detection in
  `codeledger connect` (`%APPDATA%\Claude\claude_desktop_config.json`).

### Fixed
- Solo bearer tokens (`cl_solo_…`) are now accepted by `AuthMiddleware`,
  so pasting the token into the dashboard login form actually signs
  the user in instead of looping back to 401.
- OAuth initiate route `/api/auth/oauth/{provider}` is now public and
  returns a 503 with an actionable `setup_command` when credentials
  are missing — replaces the misleading 401 "Missing credentials"
  error the dashboard surfaced when Google or GitHub was clicked
  without configuration.
- `codeledger connect` now prints a clear fallback message pointing at
  `codeledger token write-config --client claude-desktop` when the
  Claude Desktop config directory hasn't been created yet (Desktop has
  not been launched).
- Dashboard login page now shows the solo bearer token field first and
  documents `codeledger token show`; OAuth buttons are disabled with
  an inline setup command when the corresponding provider isn't
  configured.

## 0.1.6 — 2026-04-16

### Fixed
- Dashboard accessible at http://localhost:8100 without credentials
- Root route / and /assets/* added to public paths in auth middleware
- Frontend index.html served at root when frontend/dist exists
- Pre-built frontend now bundled in the wheel (backend/frontend_dist/)

## 0.1.5 — 2026-04-16

### Fixed
- Removed all references to codeledger.dev (domain not live yet)
- Replaced with github.com/codeledgerAI/codeledger throughout

## 0.1.4 — 2026-04-16

### Fixed
- **`codeledger serve` on Windows (and any platform) now bails with an
  actionable error when run before `codeledger init`.** Previously the
  CLI fell through to `uvicorn.run("backend.main:app", ...)` which then
  surfaced the cryptic *"Attribute app not found in module
  backend.main"* — caused by `backend/main.py`'s module-level
  `app = create_app()` raising `FileNotFoundError` (no
  `codeledger.toml` to load) and being silently suppressed. The CLI
  now checks for `codeledger.toml` in the current directory before
  invoking uvicorn and prints:

  ```
  CodeLedger is not initialised in this directory.
    Looked for: /full/path/to/codeledger.toml
    Run `codeledger init` here first.
  ```

  Exit code is `2`. After running `codeledger init`, `codeledger serve`
  works as before.

### Verified — no other Windows-startup blockers
- No unix-only signal handlers in `backend/main.py`.
- No `fcntl`/`termios`/`pty`/`grp`/`pwd` imports anywhere.
- No hardcoded `/tmp`, `/var`, `/etc`, `/usr` paths in the CLI or the
  app factory.
- All home-directory references use `Path.home()` (cross-platform).
- `/health` endpoint exists at `backend/main.py:318`, gated outside
  `AuthMiddleware` (per SEC-05) — npm bootstrap probe will resolve.

## 0.1.3 — 2026-04-16

### Fixed
- **Windows compatibility: `asyncpg`** moved from required to the new
  `[postgres]` optional extra. Team-mode PostgreSQL users run
  `pip install codeledger-ai[postgres]`; solo SQLite users no longer
  pay the native-build cost (asyncpg has no Windows wheel on Python
  3.14 as of this release).
- **Windows compatibility: `tiktoken`** moved to the `[tiktoken]`
  optional extra. When tiktoken is absent, `count_tokens` and
  `_truncate_to_tokens` fall back to a character-based approximation
  (~4 chars/token for `cl100k_base` English). Context-budget math
  stays conservative; install tiktoken for exact counts.
- **`uvloop`** was never a direct dependency in this project — no
  change needed.

### Install matrix
- Solo SQLite (default, no compilation):
  `pip install codeledger-ai`
- Team PostgreSQL:
  `pip install codeledger-ai[postgres]`
- Exact token accounting:
  `pip install codeledger-ai[tiktoken]`
- Local embedding fallback (no Ollama):
  `pip install codeledger-ai[local-embed]`
- Everything:
  `pip install codeledger-ai[postgres,tiktoken,local-embed]`

### No behaviour change when the extras are present
Projects that already install `asyncpg` and `tiktoken` (explicitly or
via an extra) see identical behaviour to 0.1.2. Fallbacks engage only
when the optional dependency is not importable.

## 0.1.2 — 2026-04-16

### Fixed
- **Windows compatibility.** Replaced `sqlite-vss` (no Windows wheel
  published) with `sqlite-vec`, the actively-maintained successor by
  the same author. Windows wheels are available for all supported
  CPython versions, so `pip install codeledger-ai` now works on
  Windows, macOS, and Linux without additional native-toolchain
  prerequisites.

### Changed
- Internal vector index now uses `sqlite-vec`'s `vec0` virtual table
  with `distance_metric=cosine` (was `sqlite-vss`'s `vss0` with
  squared-L2). Scoring semantics are preserved: `score = 1 - distance`
  gives cosine similarity in `[-1.0, 1.0]`. Vectors are serialized as
  packed `float32` bytes instead of JSON strings — smaller index size
  for the same data.
- Internal table renamed: `vss_items` → `vec_items`. The
  `SqliteVssStore` class name is retained for API stability.

### Migration
- New installs on 0.1.2 get the new schema automatically.
- Upgrading from 0.1.1 on Linux/macOS: existing vectors live in the
  old `vss_items` virtual table, which no longer exists in 0.1.2. The
  simplest reset is to delete `data/codeledger.db` and re-run
  `codeledger init` for a clean slate — decisions, stories, sessions,
  and provenance records rebuild from source via the change-detection
  backend on the next commit or file save. 0.1.1 was available for
  under a day, so the migration impact is minimal.

## 0.1.1 — 2026-04-16

First real PyPI release. Full MCP server with ~50 tools:
bidirectional code provenance, active context injection via Claude
Code hooks, independent quality harness, drift detection,
tautological-test detection, rollback impact planning. Solo mode
free; team mode with shared decision history. Onboarding walkthrough
at `http://localhost:8100`. Linux and macOS support (Windows blocked
by sqlite-vss native wheel — fixed in 0.1.2).

## 0.0.1 — 0.0.2

Name-reservation placeholders. Yanked.
