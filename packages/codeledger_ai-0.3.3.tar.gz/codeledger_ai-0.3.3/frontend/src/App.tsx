import { useState, useEffect } from "react";
import { Layout } from "./components/Layout";
import { LoginView } from "./views/LoginView";
import { MemoryView } from "./views/MemoryView";
import { DecisionsView } from "./views/DecisionsView";
import { SprintView } from "./views/SprintView";
import { SessionsView } from "./views/SessionsView";
import { ExplorerView } from "./views/ExplorerView";
import { ProvenanceView } from "./views/ProvenanceView";
import { MCPServersView } from "./views/MCPServersView";
import { SettingsView } from "./views/SettingsView";
import { OnboardingView } from "./views/OnboardingView";
import { useAppStore } from "./store/appStore";

type SetupState = "loading" | "onboarding" | "dashboard";

export default function App() {
  const activeTab = useAppStore((s) => s.activeTab);
  const [authed, setAuthed] = useState<boolean>(() =>
    Boolean(localStorage.getItem("cl.token")),
  );
  const [setupState, setSetupState] = useState<SetupState>("loading");

  useEffect(() => {
    // Keep auth state in sync if the token is removed elsewhere.
    const onStorage = () =>
      setAuthed(Boolean(localStorage.getItem("cl.token")));
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  useEffect(() => {
    // On every load, ask the server whether the onboarding walkthrough
    // still needs to run. The endpoint is unauthenticated so this works
    // before the developer has configured any credentials.
    let cancelled = false;
    fetch("/api/setup/status")
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        setSetupState(data?.setup_complete ? "dashboard" : "onboarding");
      })
      .catch(() => {
        if (cancelled) return;
        // Server not reachable — render the login screen as a fallback.
        setSetupState("dashboard");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (setupState === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted">
        Loading CodeLedger…
      </div>
    );
  }

  if (setupState === "onboarding") {
    return (
      <OnboardingView onComplete={() => setSetupState("dashboard")} />
    );
  }

  if (!authed) {
    return <LoginView onLogin={() => setAuthed(true)} />;
  }

  return (
    <Layout>
      {activeTab === "memory" && <MemoryView />}
      {activeTab === "decisions" && <DecisionsView />}
      {activeTab === "sprint" && <SprintView />}
      {activeTab === "sessions" && <SessionsView />}
      {activeTab === "explorer" && <ExplorerView />}
      {activeTab === "provenance" && <ProvenanceView />}
      {activeTab === "mcp" && <MCPServersView />}
      {activeTab === "settings" && <SettingsView />}
    </Layout>
  );
}
