import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Copy,
  ExternalLink,
  HelpCircle,
  Moon,
  Palette,
  Shield,
  Sun,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { api } from "../api/client";
import { useAppStore } from "../store/appStore";
import { useProjectStore } from "../store/projectStore";
import { Badge, Button, Card } from "../components/ui";

const SEC_DESCRIPTIONS: Record<string, string> = {
  "SEC-01":
    "No credentials stored in the database — only one-way hashes (Argon2id, SHA-256).",
  "SEC-02":
    "No credentials leaked in logs — all log output passes through a redactor.",
  "SEC-03": "No credentials returned from MCP tool responses.",
  "SEC-04":
    "Plaintext credentials never written to disk outside the OS keyring.",
  "SEC-05":
    "Authentication required on every HTTP endpoint and MCP tool call.",
  "SEC-06":
    "OAuth flows enforce state parameter and PKCE with S256 challenge.",
  "SEC-07":
    "Password hashing uses Argon2id (64MB, 3 iterations, parallelism 4).",
  "SEC-08": "JWT signing key lives exclusively in the credential vault.",
  "SEC-09": "Config, vault, and database files are not world-readable.",
  "SEC-10": "Personal access tokens are SHA-256 hashed before storage.",
  "SEC-11":
    "Every structural AST change produces a linked decision or an audit record.",
};

const AVAILABLE_SERVICES = [
  { id: "github", name: "GitHub", hint: "Push decisions to issues and PRs" },
  { id: "linear", name: "Linear", hint: "Sync stories to Linear issues" },
  { id: "jira", name: "Jira", hint: "Link decisions to Jira tickets" },
  { id: "slack", name: "Slack", hint: "Post standups and conflict alerts" },
];

function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      /* clipboard API unavailable — leave state as-is */
    }
  };
  return (
    <button
      type="button"
      onClick={copy}
      aria-label={label ?? "Copy to clipboard"}
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium border border-[var(--border-mid)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-strong)] transition-all focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
    >
      {copied ? (
        <>
          <Check size={11} strokeWidth={2.5} className="text-[var(--success)]" />
          <span className="text-[var(--success)]">Copied</span>
        </>
      ) : (
        <>
          <Copy size={11} strokeWidth={2} />
          <span>Copy</span>
        </>
      )}
    </button>
  );
}

function SectionHeading({
  icon: Icon,
  children,
}: {
  icon: LucideIcon;
  children: React.ReactNode;
}) {
  return (
    <h2 className="text-xs font-semibold uppercase tracking-widest text-[var(--text-secondary)] flex items-center gap-2">
      <Icon size={13} className="text-[var(--accent-bright)]" aria-hidden={true} />
      {children}
    </h2>
  );
}

export function SettingsView() {
  const { data: status } = useQuery({
    queryKey: ["security-status"],
    queryFn: () => api.security.status(),
    retry: false,
  });
  const theme = useAppStore((s) => s.theme);
  const toggleTheme = useAppStore((s) => s.toggleTheme);
  const backend = useProjectStore((s) => s.changeDetectionBackend);

  const [connected, setConnected] = useState<Record<string, string | null>>({});
  const [openSec, setOpenSec] = useState<Set<string>>(new Set());

  const connect = (id: string) =>
    setConnected((prev) => ({ ...prev, [id]: new Date().toISOString() }));
  const disconnect = (id: string) =>
    setConnected((prev) => ({ ...prev, [id]: null }));

  const toggleSec = (id: string) =>
    setOpenSec((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  return (
    <div className="grid grid-cols-3 gap-6">
      <div className="space-y-6">
        <section className="space-y-3">
          <SectionHeading icon={ExternalLink}>Connected services</SectionHeading>
          <div className="space-y-2">
            {AVAILABLE_SERVICES.map((svc) => {
              const ts = connected[svc.id];
              const isConnected = Boolean(ts);
              return (
                <Card key={svc.id} glow className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm text-[var(--text-primary)]">
                          {svc.name}
                        </span>
                        {isConnected && <Badge variant="success">Connected</Badge>}
                      </div>
                      <div className="text-xs text-[var(--text-secondary)] mt-0.5">
                        {svc.hint}
                      </div>
                    </div>
                    {isConnected ? (
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={() => disconnect(svc.id)}
                      >
                        Disconnect
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        variant="primary"
                        size="sm"
                        onClick={() => connect(svc.id)}
                      >
                        Connect
                      </Button>
                    )}
                  </div>
                  {isConnected && ts && (
                    <div className="mt-2 text-xs text-[var(--text-tertiary)] font-mono">
                      last sync {new Date(ts).toLocaleString()}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </section>

        <section className="space-y-3">
          <SectionHeading icon={Zap}>Personal access tokens</SectionHeading>
          <Card className="p-4 space-y-3">
            <p className="text-xs text-[var(--text-secondary)]">
              Manage PATs from the CLI.
            </p>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-xs font-mono bg-[var(--bg-elevated)] border border-[var(--border-dim)] rounded-md px-3 py-2 text-[var(--accent-bright)] overflow-x-auto">
                codeledger token generate
              </code>
              <CopyButton
                text="codeledger token generate"
                label="Copy token generate command"
              />
            </div>
            <a
              href="https://github.com/deepsaini80537/codeledge#personal-access-tokens"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-xs text-[var(--accent-bright)] hover:text-[var(--accent)] underline focus:ring-2 focus:ring-[var(--accent)] focus:outline-none rounded"
            >
              View token documentation
              <ExternalLink size={11} strokeWidth={2} />
            </a>
          </Card>
        </section>
      </div>

      <div className="space-y-6">
        <section className="space-y-3">
          <SectionHeading icon={Palette}>Appearance</SectionHeading>
          <Card className="p-4 space-y-3">
            <div className="text-xs text-[var(--text-secondary)]">
              Current theme:{" "}
              <span className="text-[var(--text-primary)] font-medium">
                {theme === "dark" ? "Dark" : "Light"}
              </span>
            </div>
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={
                theme === "dark" ? "Switch to light mode" : "Switch to dark mode"
              }
              className="inline-flex items-center gap-2 rounded-lg border border-[var(--border-mid)] bg-[var(--bg-elevated)] text-[var(--text-primary)] px-3 py-2 text-sm hover:border-[var(--border-strong)] hover:shadow-glow-sm transition-all focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
            >
              {theme === "dark" ? (
                <Moon size={14} className="text-[var(--accent-bright)]" />
              ) : (
                <Sun size={14} className="text-[var(--warning)]" />
              )}
              <span>{theme === "dark" ? "Dark mode" : "Light mode"}</span>
            </button>
          </Card>
        </section>

        <section className="space-y-3">
          <SectionHeading icon={HelpCircle}>Project</SectionHeading>
          <Card className="p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-[var(--text-secondary)]">
                Change detection backend
              </span>
              <Badge variant={backend === "git" ? "cyan" : "warning"}>
                <span className="font-mono">{backend}</span>
              </Badge>
            </div>
            {backend === "file_watcher" && (
              <p className="text-xs text-[var(--warning)] mt-2">
                CI verification unavailable. Run{" "}
                <code className="font-mono text-[var(--accent-bright)]">
                  git init && codeledger init --reinstall-hooks
                </code>{" "}
                to enable.
              </p>
            )}
          </Card>
        </section>
      </div>

      <section className="space-y-3">
        <SectionHeading icon={Shield}>Security status</SectionHeading>
        <div className="space-y-1.5">
          {status?.invariants.map((inv) => {
            const isOpen = openSec.has(inv.id);
            const passed = inv.status === "pass";
            return (
              <Card key={inv.id} className="overflow-hidden p-0">
                <button
                  type="button"
                  onClick={() => toggleSec(inv.id)}
                  aria-expanded={isOpen}
                  className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-[var(--bg-hover)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent)]"
                >
                  <span className="flex items-center gap-2">
                    {isOpen ? (
                      <ChevronDown size={12} className="text-[var(--text-tertiary)]" />
                    ) : (
                      <ChevronRight size={12} className="text-[var(--text-tertiary)]" />
                    )}
                    <span className="font-mono text-[var(--text-primary)]">
                      {inv.id}
                    </span>
                  </span>
                  <span className="flex items-center gap-2">
                    {inv.id === "SEC-11" && inv.total_unlinked !== undefined && (
                      <span className="text-xs font-mono text-[var(--text-tertiary)]">
                        {inv.total_unlinked} total (
                        {inv.unlinked_commits ?? 0} git,{" "}
                        {inv.unlinked_file_changes ?? 0} file watcher)
                      </span>
                    )}
                    <Badge variant={passed ? "success" : "warning"}>
                      {passed && (
                        <CheckCircle2 size={10} strokeWidth={2.5} className="mr-1" />
                      )}
                      {inv.status}
                    </Badge>
                  </span>
                </button>
                {isOpen && (
                  <div className="px-3 pb-3 pt-1 border-t border-[var(--border-dim)] text-xs text-[var(--text-secondary)] leading-relaxed">
                    {SEC_DESCRIPTIONS[inv.id] ?? "No description available."}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      </section>
    </div>
  );
}
