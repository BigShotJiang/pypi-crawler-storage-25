import { useEffect, useRef, useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  MoreVertical,
  Server as ServerIcon,
} from "lucide-react";
import { Badge, Button, Card, Input, Select } from "../components/ui";

type Transport = "http" | "sse" | "stdio";
type AuthKind = "oauth" | "api_key" | "none";

interface ServerEntry {
  name: string;
  url: string;
  transport: Transport;
  auth: AuthKind;
  toolCount: number;
  tools?: string[];
  status: "connected" | "disconnected";
  connectedSince?: string;
}

const AUTH_LABELS: Record<AuthKind, string> = {
  oauth: "Authenticated via OAuth",
  api_key: "Authenticated via API Key",
  none: "No authentication",
};

const DEFAULT_TOOLS = [
  "context.create",
  "context.read",
  "context.list",
  "decision.create",
  "decision.trace",
  "story.create",
  "story.update",
  "sprint.status",
  "session.start",
  "session.end",
  "verify.status",
  "harness.score",
  "provenance.forward",
  "provenance.reverse",
  "session.conflicts",
  "standup.generate",
];

function ServerCard({
  entry,
  onDisconnect,
  onEdit,
}: {
  entry: ServerEntry;
  onDisconnect: () => void;
  onEdit: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [menuOpen]);

  const copyUrl = async () => {
    try {
      await navigator.clipboard.writeText(entry.url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
    setMenuOpen(false);
  };

  return (
    <Card glow className="overflow-hidden p-0">
      <div className="flex items-center gap-4 p-4">
        <div className="w-10 h-10 rounded-lg bg-[var(--accent-dim)] border border-[var(--border-dim)] flex items-center justify-center">
          <ServerIcon size={18} className="text-[var(--accent-bright)]" aria-hidden="true" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-[var(--text-primary)] truncate">
              {entry.name}
            </span>
            <span
              aria-hidden="true"
              className={`w-1.5 h-1.5 rounded-full ${
                entry.status === "connected"
                  ? "bg-[var(--success)] animate-pulse"
                  : "bg-[var(--danger)]"
              }`}
            />
          </div>
          <div className="text-xs text-[var(--text-secondary)] font-mono truncate">
            {entry.url}
          </div>
          {entry.connectedSince && (
            <div className="text-xs text-[var(--text-tertiary)] font-mono">
              connected since {new Date(entry.connectedSince).toLocaleString()}
            </div>
          )}
        </div>
        <Badge variant="ghost" title={`Transport: ${entry.transport}`}>
          <span className="font-mono">{entry.transport}</span>
        </Badge>
        <Badge variant="cyan" title={AUTH_LABELS[entry.auth]}>
          <span className="font-mono">{entry.auth}</span>
        </Badge>
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          aria-expanded={expanded}
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium text-[var(--accent-bright)] border border-[var(--border-dim)] bg-[var(--accent-dim)] hover:border-[var(--border-mid)] transition-all focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
        >
          {expanded ? (
            <ChevronDown size={12} strokeWidth={2} />
          ) : (
            <ChevronRight size={12} strokeWidth={2} />
          )}
          {entry.toolCount} tools
        </button>
        <div ref={menuRef} className="relative">
          <button
            type="button"
            aria-label="Server actions"
            aria-haspopup="menu"
            onClick={() => setMenuOpen((v) => !v)}
            className="w-8 h-8 rounded-lg flex items-center justify-center border border-[var(--border-dim)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-mid)] transition-all focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
          >
            <MoreVertical size={13} strokeWidth={2} />
          </button>
          {menuOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-40 rounded-lg border border-[var(--border-mid)] bg-[var(--bg-overlay)] shadow-elevated z-20 text-sm overflow-hidden">
              <button
                onClick={() => {
                  onEdit();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors"
              >
                Edit
              </button>
              <button
                onClick={copyUrl}
                className="w-full text-left px-3 py-1.5 text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors"
              >
                {copied ? "Copied!" : "Copy URL"}
              </button>
              <button
                onClick={() => {
                  onDisconnect();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 text-[var(--danger)] hover:bg-[var(--danger-dim)] transition-colors"
              >
                Disconnect
              </button>
            </div>
          )}
        </div>
      </div>
      {expanded && (
        <div
          className="border-t border-[var(--border-dim)] px-4 py-3 overflow-y-auto text-xs text-[var(--text-secondary)] font-mono bg-[var(--bg-base)]"
          style={{ maxHeight: 200 }}
        >
          {(entry.tools ?? DEFAULT_TOOLS).map((t) => (
            <div key={t} className="py-0.5">
              {t}
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

export function MCPServersView() {
  const [servers, setServers] = useState<ServerEntry[]>([
    {
      name: "codeledger",
      url: "http://localhost:8100/mcp",
      transport: "http",
      auth: "api_key",
      toolCount: 16,
      tools: DEFAULT_TOOLS,
      status: "connected",
      connectedSince: new Date().toISOString(),
    },
  ]);
  const [form, setForm] = useState<Partial<ServerEntry>>({
    transport: "http",
    auth: "none",
  });

  const removeServer = (name: string) =>
    setServers((prev) => prev.filter((s) => s.name !== name));
  const editServer = (name: string) =>
    setForm(servers.find((s) => s.name === name) ?? {});

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        {servers.map((s) => (
          <ServerCard
            key={s.name}
            entry={s}
            onDisconnect={() => removeServer(s.name)}
            onEdit={() => editServer(s.name)}
          />
        ))}
      </div>

      <Card variant="glass" className="p-5">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const name = form.name;
            const url = form.url;
            if (name && url) {
              const entry: ServerEntry = {
                name,
                url,
                transport: (form.transport as Transport) ?? "http",
                auth: (form.auth as AuthKind) ?? "none",
                toolCount: 0,
                status: "disconnected",
              };
              setServers((prev) => [
                ...prev.filter((s) => s.name !== name),
                entry,
              ]);
              setForm({ transport: "http", auth: "none" });
            }
          }}
          className="space-y-3"
        >
          <h3 className="font-display text-base font-semibold text-[var(--text-primary)]">
            Add MCP server
          </h3>
          <Input
            placeholder="Name"
            aria-label="Server name"
            value={form.name ?? ""}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <Input
            placeholder="URL or command"
            aria-label="Server URL or command"
            value={form.url ?? ""}
            onChange={(e) => setForm({ ...form, url: e.target.value })}
          />
          <div className="flex gap-2">
            <Select
              value={form.transport}
              onChange={(e) =>
                setForm({ ...form, transport: e.target.value as Transport })
              }
              aria-label="Transport"
              className="w-40"
            >
              <option value="http">HTTP/SSE</option>
              <option value="sse">SSE</option>
              <option value="stdio">stdio</option>
            </Select>
            <Select
              value={form.auth}
              onChange={(e) =>
                setForm({ ...form, auth: e.target.value as AuthKind })
              }
              aria-label="Authentication"
              className="w-40"
            >
              <option value="none">No auth</option>
              <option value="oauth">OAuth</option>
              <option value="api_key">API key</option>
            </Select>
            <div className="ml-auto">
              <Button type="submit" variant="primary" size="md">
                Connect
              </Button>
            </div>
          </div>
        </form>
      </Card>
    </div>
  );
}
