import { create } from "zustand";

export type Tab =
  | "memory"
  | "decisions"
  | "sprint"
  | "sessions"
  | "explorer"
  | "provenance"
  | "mcp"
  | "settings";

export type Theme = "light" | "dark";

const VALID_TABS: Tab[] = [
  "memory",
  "decisions",
  "sprint",
  "sessions",
  "explorer",
  "provenance",
  "mcp",
  "settings",
];

interface AppState {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  theme: Theme;
  toggleTheme: () => void;
}

function tabFromHash(): Tab {
  if (typeof window === "undefined") return "memory";
  const raw = window.location.hash.replace(/^#/, "").replace(/^\//, "");
  const key = raw === "mcp-servers" ? "mcp" : raw;
  return (VALID_TABS as string[]).includes(key) ? (key as Tab) : "memory";
}

const initialTheme: Theme =
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";

function writeHash(tab: Tab) {
  if (typeof window === "undefined") return;
  const slug = tab === "mcp" ? "mcp-servers" : tab;
  const target = `#${slug}`;
  if (window.location.hash !== target) {
    window.history.pushState(null, "", target);
  }
}

export const useAppStore = create<AppState>((set, get) => ({
  activeTab: tabFromHash(),
  setActiveTab: (tab) => {
    writeHash(tab);
    set({ activeTab: tab });
  },
  theme: initialTheme,
  toggleTheme: () => {
    const next = get().theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    set({ theme: next });
  },
}));

if (typeof window !== "undefined") {
  window.addEventListener("popstate", () => {
    useAppStore.setState({ activeTab: tabFromHash() });
  });
  window.addEventListener("hashchange", () => {
    useAppStore.setState({ activeTab: tabFromHash() });
  });
}
