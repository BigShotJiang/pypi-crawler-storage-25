"""FastMCP server registering all Phase 1 CodeLedger tools.

Each namespace (context, decision, story, sprint, session, standup) is exposed
as a single MCP tool with a ``method`` parameter that selects the operation.
Tools dispatch into ``ToolHandlers`` for the actual business logic.

The user id is expected on the MCP request context (injected by the transport
layer). For stdio/CI contexts, a fallback ``user_id`` parameter is accepted.

Security invariants enforced:
- SEC-05: ``_resolve_user_id`` refuses requests with no user context.
- SEC-03: Responses surface only domain fields (never tokens, secrets).
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any

from fastmcp import FastMCP

from backend.auth.auth_middleware import get_current_user
from backend.mcp.tool_handlers import HandlerError

if TYPE_CHECKING:
    from backend.mcp.tool_handlers import ToolHandlers


def _uuid_or_none(raw: str | None) -> uuid.UUID | None:
    if raw is None or raw == "":
        return None
    return uuid.UUID(raw)


def _uuid(raw: str) -> uuid.UUID:
    return uuid.UUID(raw)


def _resolve_user_id(user_id: str | None) -> uuid.UUID:
    """Return the acting user's UUID.

    Priority:
    1. Explicit ``user_id`` argument (team mode, tests, stdio callers).
    2. Authenticated user from the request ContextVar set by AuthMiddleware —
       covers solo mode and any MCP caller that authenticated via bearer
       token, cookie, or CODELEDGER_TOKEN without needing to know its own
       internal UUID.
    """
    if user_id:
        return uuid.UUID(user_id)
    user = get_current_user()
    if user is not None:
        return user.id
    raise HandlerError("user_id is required")


def create_mcp_server(handlers: ToolHandlers) -> FastMCP:
    """Register every Phase 1 MCP tool on a new FastMCP instance."""
    mcp: FastMCP = FastMCP("codeledger")

    async def _bootstrap_session(
        cwd: str | None,
        agent_name: str | None,
        project_id: str | None,
        first_message: str | None,
        user_id: uuid.UUID | None,
    ) -> Any:
        """Universal session-bootstrap hook — applies to every tool.

        When the caller supplies all three of ``cwd``, ``agent_name``,
        and ``project_id``, the session lifecycle machinery activates:
        an existing active session is matched or a new session is
        created with a triaged context block. Handlers that predate
        this layer (and tests) pass the fields as ``None`` and the
        bootstrap is a no-op.
        """
        try:
            return await handlers.ensure_session_and_inject_context(
                cwd=cwd,
                agent_name=agent_name,
                project_id=project_id,
                first_message=first_message,
                user_id=user_id,
            )
        except Exception:
            return None

    def _inject_context(result: Any, ctx: Any) -> Any:
        """Attach session_context to the response when a new session fired."""
        if ctx is None or not getattr(ctx, "is_new_session", False):
            return result
        if not isinstance(result, dict):
            return result
        merged = dict(result)
        merged["session_context"] = {
            "session_id": ctx.session_id,
            "context_block": ctx.context_block,
            "context_items_count": ctx.context_items_count,
            "tokens_used": ctx.tokens_used,
        }
        return merged

    @mcp.tool()
    async def context(
        method: str,
        user_id: str | None = None,
        item_id: str | None = None,
        content: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
        session_id: str | None = None,
        limit: int = 100,
        # Phase 2 — semantic retrieval parameters
        query: str | None = None,
        file_path: str | None = None,
        file_content: str | None = None,
        project_id: str | None = None,
        token_budget: int | None = None,
        top_k: int = 10,
        # Phase 5 — persona re-ranking
        persona: str | None = None,
        # Hybrid search blend weight — 1.0 = pure vector, 0.0 = pure keyword,
        # 0.6 = default for get_relevant, 0.5 for get_for_file.
        blend_weight: float = 0.6,
        # Universal active context — every MCP tool carries these so any
        # client (Claude Code, Cursor, Windsurf, …) bootstraps a session
        # on its first tool call without needing a hooks layer.
        cwd: str | None = None,
        agent_name: str | None = None,
    ) -> Any:
        """Context operations.

        Methods:
            create|read|update|delete|list — Phase 1 CRUD.
            get_relevant — semantic retrieval with token-budget triage.
            get_for_file — file-scoped semantic retrieval shortcut.
        """
        uid = _resolve_user_id(user_id)
        ctx = await _bootstrap_session(
            cwd=cwd,
            agent_name=agent_name,
            project_id=project_id,
            first_message=query or content or file_path,
            user_id=uid,
        )
        if method == "create":
            result = await handlers.context_create(
                user_id=uid,
                content=content or "",
                source=source or "",
                tags=tags,
                session_id=_uuid_or_none(session_id),
            )
            return _inject_context(result, ctx)
        if method == "before_edit":
            if not file_path:
                raise HandlerError("file_path is required for before_edit")
            if not cwd or not agent_name or not project_id:
                raise HandlerError(
                    "cwd, agent_name, and project_id are required for before_edit"
                )
            result = await handlers.context_before_edit(
                user_id=uid,
                file_path=file_path,
                file_content=file_content or "",
                cwd=cwd,
                agent_name=agent_name,
                project_id=project_id,
            )
            return _inject_context(result, ctx)
        if method == "read":
            return await handlers.context_read(
                user_id=uid, item_id=_uuid(item_id or "")
            )
        if method == "update":
            return await handlers.context_update(
                user_id=uid,
                item_id=_uuid(item_id or ""),
                content=content,
                source=source,
                tags=tags,
            )
        if method == "delete":
            return await handlers.context_delete(
                user_id=uid, item_id=_uuid(item_id or "")
            )
        if method == "list":
            return await handlers.context_list(
                user_id=uid,
                session_id=_uuid_or_none(session_id),
                limit=limit,
            )
        if method == "get_relevant":
            return await handlers.context_get_relevant(
                user_id=uid,
                query=query,
                file_path=file_path,
                file_content=file_content,
                project_id=project_id,
                token_budget=token_budget,
                top_k=top_k,
                persona=persona,
                blend_weight=blend_weight,
            )
        if method == "get_for_file":
            if not file_path:
                raise HandlerError("file_path is required for get_for_file")
            return await handlers.context_get_for_file(
                user_id=uid,
                file_path=file_path,
                file_content=file_content or "",
                project_id=project_id,
                token_budget=token_budget,
                top_k=top_k,
                blend_weight=blend_weight if blend_weight != 0.6 else 0.5,
            )
        raise HandlerError(f"Unknown context method: {method!r}")

    @mcp.tool()
    async def decision(
        method: str,
        user_id: str | None = None,
        decision_id: str | None = None,
        title: str | None = None,
        description: str | None = None,
        tags: list[str] | None = None,
        session_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
        # Phase 2 — provenance tracing parameters
        file_path: str | None = None,
        entity_name: str | None = None,
        # Passive inference parameters
        inferred_decision_id: str | None = None,
        reason: str | None = None,
        project_id: str | None = None,
        # Staleness lifecycle parameters
        new_decision_id: str | None = None,
        # Conflict resolution parameters
        conflict_id: str | None = None,
        resolution_decision_id: str | None = None,
        notes: str | None = None,
    ) -> Any:
        """Decision operations.

        Methods:
            create|read|list — Phase 1 CRUD.
            trace — forward provenance (decision → commits → AST changes).
            reverse_trace — reverse provenance (file/entity → decisions).
            confirm_inferred|reject_inferred|list_pending_inferred —
                passive-inference candidate lifecycle.
        """
        uid = _resolve_user_id(user_id)
        if method == "create":
            return await handlers.decision_create(
                user_id=uid,
                title=title or "",
                description=description or "",
                tags=tags,
                session_id=_uuid_or_none(session_id),
            )
        if method == "read":
            return await handlers.decision_read(
                user_id=uid, decision_id=_uuid(decision_id or "")
            )
        if method == "list":
            return await handlers.decision_list(
                user_id=uid, status=status, limit=limit
            )
        if method == "trace":
            return await handlers.decision_trace(
                user_id=uid, decision_id=_uuid(decision_id or "")
            )
        if method == "reverse_trace":
            if not file_path or not entity_name:
                raise HandlerError(
                    "file_path and entity_name are required for reverse_trace"
                )
            return await handlers.decision_reverse_trace(
                user_id=uid,
                file_path=file_path,
                entity_name=entity_name,
            )
        if method == "search":
            if not title:
                raise HandlerError("title (query) is required for search")
            return await handlers.decision_search(
                user_id=uid, query=title, limit=limit
            )
        if method == "confirm_inferred":
            if not inferred_decision_id:
                raise HandlerError(
                    "inferred_decision_id is required for confirm_inferred"
                )
            return await handlers.decision_confirm_inferred(
                user_id=uid,
                inferred_decision_id=_uuid(inferred_decision_id),
                description=description,
                tags=tags,
            )
        if method == "reject_inferred":
            if not inferred_decision_id or not reason:
                raise HandlerError(
                    "inferred_decision_id and reason are required for reject_inferred"
                )
            return await handlers.decision_reject_inferred(
                user_id=uid,
                inferred_decision_id=_uuid(inferred_decision_id),
                reason=reason,
            )
        if method == "list_pending_inferred":
            return await handlers.decision_list_pending_inferred(
                user_id=uid,
                project_id=project_id,
                session_id=_uuid_or_none(session_id),
            )
        if method == "supersede":
            if not decision_id or not new_decision_id or not reason:
                raise HandlerError(
                    "decision_id, new_decision_id, and reason are required"
                )
            return await handlers.decision_supersede(
                user_id=uid,
                decision_id=_uuid(decision_id),
                new_decision_id=_uuid(new_decision_id),
                reason=reason,
            )
        if method == "staleness_report":
            return await handlers.decision_staleness_report(
                user_id=uid, project_id=project_id
            )
        if method == "confirm_fresh":
            if not decision_id:
                raise HandlerError("decision_id is required for confirm_fresh")
            return await handlers.decision_confirm_fresh(
                user_id=uid, decision_id=_uuid(decision_id)
            )
        if method == "list_conflicts":
            return await handlers.decision_list_conflicts(
                user_id=uid, project_id=project_id
            )
        if method == "resolve_conflict":
            if not conflict_id or not resolution_decision_id or not notes:
                raise HandlerError(
                    "conflict_id, resolution_decision_id, and notes are required"
                )
            return await handlers.decision_resolve_conflict(
                user_id=uid,
                conflict_id=_uuid(conflict_id),
                resolution_decision_id=_uuid(resolution_decision_id),
                notes=notes,
            )
        raise HandlerError(f"Unknown decision method: {method!r}")

    @mcp.tool()
    async def story(
        method: str,
        user_id: str | None = None,
        story_id: str | None = None,
        title: str | None = None,
        description: str | None = None,
        acceptance_criteria: list[str] | None = None,
        status: str | None = None,
        points: int | None = None,
        sprint_id: str | None = None,
        limit: int = 100,
    ) -> Any:
        """Story CRUD: create|read|update|list."""
        uid = _resolve_user_id(user_id)
        if method == "create":
            return await handlers.story_create(
                user_id=uid,
                title=title or "",
                description=description or "",
                acceptance_criteria=acceptance_criteria,
                points=points,
                sprint_id=_uuid_or_none(sprint_id),
            )
        if method == "read":
            return await handlers.story_read(
                user_id=uid, story_id=_uuid(story_id or "")
            )
        if method == "update":
            return await handlers.story_update(
                user_id=uid,
                story_id=_uuid(story_id or ""),
                title=title,
                description=description,
                acceptance_criteria=acceptance_criteria,
                status=status,
                points=points,
                sprint_id=_uuid_or_none(sprint_id),
            )
        if method == "list":
            return await handlers.story_list(
                user_id=uid,
                sprint_id=_uuid_or_none(sprint_id),
                status=status,
                limit=limit,
            )
        if method == "search":
            if not title:
                raise HandlerError("title (query) is required for search")
            return await handlers.story_search(
                user_id=uid, query=title, limit=limit
            )
        raise HandlerError(f"Unknown story method: {method!r}")

    @mcp.tool()
    async def sprint(
        method: str,
        user_id: str | None = None,
        sprint_id: str | None = None,
        name: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        lookback_sprints: int = 6,
    ) -> Any:
        """Sprint tools: create|status|burndown|velocity|retrospective."""
        from datetime import datetime

        uid = _resolve_user_id(user_id)
        if method == "create":
            start = datetime.fromisoformat(start_date) if start_date else None
            end = datetime.fromisoformat(end_date) if end_date else None
            return await handlers.sprint_create(
                user_id=uid,
                name=name or "",
                start_date=start,
                end_date=end,
            )
        if method == "status":
            return await handlers.sprint_status(
                user_id=uid, sprint_id=_uuid(sprint_id or "")
            )
        if method == "burndown":
            return await handlers.sprint_burndown(
                user_id=uid, sprint_id=_uuid(sprint_id or "")
            )
        if method == "velocity":
            return await handlers.sprint_velocity(
                user_id=uid, lookback_sprints=lookback_sprints
            )
        if method == "retrospective":
            return await handlers.sprint_retrospective(
                user_id=uid, sprint_id=_uuid(sprint_id or "")
            )
        raise HandlerError(f"Unknown sprint method: {method!r}")

    @mcp.tool()
    async def session(
        method: str,
        user_id: str | None = None,
        session_id: str | None = None,
        agent_name: str | None = None,
        status: str | None = None,
        for_current_user: bool = False,
        limit: int = 50,
        # Phase 3 — session.end enforcement
        force: bool = False,
        override_reason: str | None = None,
        # Phase 3 — conflict lookup
        project_id: str | None = None,
        # Passive inference auto-confirm
        auto_confirm_threshold: float | None = None,
    ) -> Any:
        """Session tools: start|end|list|replay|conflicts."""
        uid = _resolve_user_id(user_id)
        if method == "start":
            return await handlers.session_start(
                user_id=uid, agent_name=agent_name or ""
            )
        if method == "end":
            return await handlers.session_end(
                user_id=uid,
                session_id=_uuid(session_id or ""),
                force=force,
                override_reason=override_reason,
                auto_confirm_threshold=auto_confirm_threshold,
            )
        if method == "list":
            return await handlers.session_list(
                user_id=uid,
                status=status,
                for_current_user=for_current_user,
                limit=limit,
            )
        if method == "replay":
            return await handlers.session_replay(
                user_id=uid, session_id=_uuid(session_id or "")
            )
        if method == "conflicts":
            return await handlers.session_conflicts(
                user_id=uid,
                session_id=_uuid(session_id or ""),
                project_id=project_id,
            )
        if method == "search":
            if not agent_name:
                raise HandlerError("agent_name (query) is required for search")
            return await handlers.session_search(
                user_id=uid, query=agent_name, limit=limit
            )
        raise HandlerError(f"Unknown session method: {method!r}")

    @mcp.tool()
    async def verify(
        method: str,
        user_id: str | None = None,
        decision_id: str | None = None,
        project_id: str | None = None,
    ) -> Any:
        """Verification tools: status|list_unverified."""
        uid = _resolve_user_id(user_id)
        if method == "status":
            return await handlers.verify_status(
                user_id=uid, decision_id=_uuid(decision_id or "")
            )
        if method == "list_unverified":
            return await handlers.verify_list_unverified(
                user_id=uid, project_id=project_id
            )
        raise HandlerError(f"Unknown verify method: {method!r}")

    @mcp.tool()
    async def provenance(
        method: str,
        user_id: str | None = None,
        decision_id: str | None = None,
        file_path: str | None = None,
        entity_name: str | None = None,
        project_id: str | None = None,
    ) -> Any:
        """Provenance tools: forward|reverse."""
        uid = _resolve_user_id(user_id)
        if method == "forward":
            return await handlers.provenance_forward(
                user_id=uid, decision_id=_uuid(decision_id or "")
            )
        if method == "reverse":
            if not file_path or not entity_name:
                raise HandlerError(
                    "file_path and entity_name are required for reverse"
                )
            return await handlers.provenance_reverse(
                user_id=uid,
                file_path=file_path,
                entity_name=entity_name,
                project_id=project_id,
            )
        raise HandlerError(f"Unknown provenance method: {method!r}")

    @mcp.tool()
    async def drift(
        method: str,
        user_id: str | None = None,
        project_id: str | None = None,
        repo_path: str | None = None,
    ) -> Any:
        """Architectural drift detection: check|report."""
        uid = _resolve_user_id(user_id)
        if method in ("check", "report"):
            return await handlers.drift_check(
                user_id=uid, project_id=project_id, repo_path=repo_path
            )
        raise HandlerError(f"Unknown drift method: {method!r}")

    @mcp.tool()
    async def test(
        method: str,
        user_id: str | None = None,
        project_id: str | None = None,
        repo_path: str | None = None,
    ) -> Any:
        """Tautological test detection: check_tautology."""
        uid = _resolve_user_id(user_id)
        if method == "check_tautology":
            return await handlers.test_check_tautology(
                user_id=uid, project_id=project_id, repo_path=repo_path
            )
        raise HandlerError(f"Unknown test method: {method!r}")

    @mcp.tool()
    async def rollback(
        method: str,
        user_id: str | None = None,
        decision_id: str | None = None,
    ) -> Any:
        """Rollback planning: plan."""
        uid = _resolve_user_id(user_id)
        if method == "plan":
            return await handlers.rollback_plan(
                user_id=uid, decision_id=_uuid(decision_id or "")
            )
        raise HandlerError(f"Unknown rollback method: {method!r}")

    @mcp.tool()
    async def knowledge(
        method: str,
        user_id: str | None = None,
        decision_ids: list[str] | None = None,
        pack_name: str | None = None,
        pack_payload: dict[str, Any] | None = None,
        project_id: str | None = None,
    ) -> Any:
        """Knowledge pack ops: export|import|list_exportable|list_packs."""
        uid = _resolve_user_id(user_id)
        if method == "export":
            return await handlers.knowledge_export(
                user_id=uid,
                decision_ids=list(decision_ids or []),
                pack_name=pack_name or "unnamed",
                project_id=project_id,
            )
        if method == "import":
            return await handlers.knowledge_import(
                user_id=uid,
                pack_payload=dict(pack_payload or {}),
                project_id=project_id,
            )
        if method == "list_exportable":
            return await handlers.knowledge_list_exportable(
                user_id=uid, project_id=project_id
            )
        if method == "list_packs":
            return await handlers.knowledge_list_packs(
                user_id=uid, project_id=project_id
            )
        raise HandlerError(f"Unknown knowledge method: {method!r}")

    @mcp.tool()
    async def agent(
        method: str,
        user_id: str | None = None,
        agent_name: str | None = None,
        story_id: str | None = None,
        project_id: str | None = None,
    ) -> Any:
        """Agent profiling: profile|recommend|context_adjustment."""
        uid = _resolve_user_id(user_id)
        if method == "profile":
            return await handlers.agent_profile(
                user_id=uid,
                agent_name=agent_name or "",
                project_id=project_id,
            )
        if method == "recommend":
            return await handlers.agent_recommend(
                user_id=uid,
                story_id=_uuid(story_id or ""),
                project_id=project_id,
            )
        if method == "context_adjustment":
            return await handlers.agent_context_adjustment(
                user_id=uid,
                agent_name=agent_name or "",
                story_id=_uuid(story_id or ""),
            )
        raise HandlerError(f"Unknown agent method: {method!r}")

    @mcp.tool()
    async def project(
        method: str,
        user_id: str | None = None,
        project_id: str | None = None,
        name: str | None = None,
    ) -> Any:
        """Project management: create|list|switch|members."""
        uid = _resolve_user_id(user_id)
        if method == "create":
            return await handlers.project_create(
                user_id=uid, project_id=project_id or "", name=name or ""
            )
        if method == "list":
            return await handlers.project_list(user_id=uid)
        if method == "switch":
            return await handlers.project_switch(
                user_id=uid, project_id=project_id or ""
            )
        if method == "members":
            return await handlers.project_members(
                user_id=uid, project_id=project_id
            )
        raise HandlerError(f"Unknown project method: {method!r}")

    @mcp.tool()
    async def retrospective(
        method: str = "generate",
        user_id: str | None = None,
        sprint_id: str | None = None,
    ) -> Any:
        """Sprint retrospective: generate."""
        uid = _resolve_user_id(user_id)
        if method == "generate":
            return await handlers.retrospective_generate(
                user_id=uid, sprint_id=_uuid(sprint_id or "")
            )
        raise HandlerError(f"Unknown retrospective method: {method!r}")

    @mcp.tool()
    async def harness(
        method: str,
        user_id: str | None = None,
        session_id: str | None = None,
        commit_hash: str | None = None,
        project_id: str | None = None,
    ) -> Any:
        """Quality harness: score|score_commit."""
        uid = _resolve_user_id(user_id)
        if method == "score":
            return await handlers.harness_score(
                user_id=uid,
                session_id=_uuid(session_id or ""),
                project_id=project_id,
            )
        if method == "score_commit":
            if not commit_hash:
                raise HandlerError("commit_hash is required for score_commit")
            return await handlers.harness_score_commit(
                user_id=uid, commit_hash=commit_hash, project_id=project_id
            )
        raise HandlerError(f"Unknown harness method: {method!r}")

    @mcp.tool()
    async def standup(
        method: str = "generate",
        user_id: str | None = None,
        lookback_hours: int = 24,
    ) -> Any:
        """Standup generation."""
        uid = _resolve_user_id(user_id)
        if method == "generate":
            return await handlers.standup_generate(
                user_id=uid, lookback_hours=lookback_hours
            )
        raise HandlerError(f"Unknown standup method: {method!r}")

    @mcp.tool()
    async def detection(
        method: str,
        user_id: str | None = None,
        project_id: str | None = None,
        new_source: str | None = None,
        agent_id: str | None = None,
        session_id: str | None = None,
        files: list[str] | None = None,
        change_summary: str | None = None,
    ) -> Any:
        """Detection registry: report_agent_edit|source_status|switch_source.

        ``report_agent_edit`` enqueues an ``agent_reported``
        :class:`ChangeEvent` for the calling MCP agent.
        ``source_status`` returns the per-project status snapshot.
        ``switch_source`` updates the preferred source (any
        authenticated caller may call this — see handler docstring).
        """
        uid = _resolve_user_id(user_id)
        if method == "report_agent_edit":
            return await handlers.detection_report_agent_edit(
                user_id=uid,
                agent_id=agent_id or "",
                files=files or [],
                session_id=session_id or "",
                project_id=project_id,
                change_summary=change_summary,
            )
        if method == "source_status":
            return await handlers.detection_source_status(
                user_id=uid, project_id=project_id
            )
        if method == "switch_source":
            if not new_source:
                raise HandlerError("new_source is required for switch_source")
            return await handlers.detection_switch_source(
                user_id=uid,
                new_source=new_source,
                project_id=project_id,
            )
        raise HandlerError(f"Unknown detection method: {method!r}")

    return mcp
