"""FastAPI application factory mounting the MCP server, API routes, and middleware.

Assembles the CodeLedger runtime from its component modules:
- Loads configuration from ``codeledger.toml``
- Configures logging via ``log_sanitizer.setup_logging``
- Opens the database connection and runs migrations on startup
- Mounts the FastMCP server at ``/mcp``
- Registers REST API routes under ``/api``
- Applies ``AuthMiddleware`` to every non-public route
- Exposes ``/health`` as the single unauthenticated endpoint

Security invariants enforced:
- SEC-02: ``setup_logging`` installs the sanitizing formatter before any
  component logs.
- SEC-05: Every route except ``/health`` is gated by ``AuthMiddleware``.
"""

from __future__ import annotations

import hmac
import logging
import os
import pathlib
from contextlib import asynccontextmanager, suppress
from typing import TYPE_CHECKING, Any, Literal, cast

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from backend.advanced.agent_profiler import AgentProfiler
from backend.advanced.drift_detector import DriftDetector
from backend.advanced.knowledge_packs import KnowledgePackManager
from backend.advanced.rollback_planner import RollbackPlanner
from backend.advanced.tautology_detector import TautologyDetector
from backend.api.routes import create_api_router
from backend.auth.auth_middleware import AuthMiddleware
from backend.auth.auth_service import AuthService, AuthSettings
from backend.auth.credential_manager import CredentialManager
from backend.config import load_config
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker, ASTTrackerError
from backend.intelligence.decision_inferrer import DecisionInferrer
from backend.intelligence.staleness_scorer import StalenessScorer
from backend.mcp.mcp_server import create_mcp_server
from backend.mcp.tool_handlers import ToolHandlers
from backend.middleware.security import SecurityHeadersMiddleware
from backend.utils.log_sanitizer import setup_logging
from backend.verification.conflict_detector import ConflictDetector
from backend.verification.harness import QualityHarness
from backend.verification.provenance import ProvenanceEngine
from backend.verification.verifier import Verifier

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from backend.config import CodeLedgerConfig


# ---------------------------------------------------------------------------
# Public paths (the ONLY unauthenticated endpoints)
# ---------------------------------------------------------------------------

_PUBLIC_PATHS = frozenset(
    {
        "/health",
        "/api/hooks/post-commit",
        "/api/hooks/file-change",
        # Onboarding endpoints must be reachable before auth is configured.
        "/api/setup/status",
        "/api/setup/complete",
        # Dashboard shell — SPA entry point. Auth is enforced on the JSON API
        # it talks to, so serving the unauth'd HTML/asset shell is safe.
        "/",
        "/index.html",
        "/favicon.ico",
    }
)

_PUBLIC_PREFIXES: tuple[str, ...] = (
    "/assets/",
    "/static/",
    # OAuth initiate, callback, and provider-status endpoints. These handle
    # their own authentication through the upstream provider, so they must
    # be reachable without an existing session.
    "/api/auth/oauth/",
)


def _resolve_frontend_dist() -> pathlib.Path | None:
    # Wheel install: hatch force-include copies frontend/dist → backend/frontend_dist
    # Source checkout: the sibling frontend/dist/ directory after `npm run build`
    candidates = [
        pathlib.Path(__file__).parent / "frontend_dist",
        pathlib.Path(__file__).parent.parent / "frontend" / "dist",
    ]
    for candidate in candidates:
        if (candidate / "index.html").exists():
            return candidate
    return None

_WEBHOOK_PROVIDER = "webhooks"
_WEBHOOK_SECRET_KEY = "default"

_logger = logging.getLogger(__name__)


async def _close_inactive_sessions_loop(
    handlers: ToolHandlers,
    inactivity_timeout_minutes: int,
    interval_seconds: int,
) -> None:
    """Background task: close sessions idle longer than the inactivity window.

    Runs :meth:`ToolHandlers.close_inactive_sessions` on a fixed
    cadence. Disabled (returns immediately) when either input is zero
    or negative so tests can opt out by configuring
    ``SessionConfig.inactivity_timeout_minutes = 0``.
    """
    import asyncio

    if inactivity_timeout_minutes <= 0 or interval_seconds <= 0:
        return
    while True:
        try:
            closed = await handlers.close_inactive_sessions(
                inactivity_timeout_minutes=inactivity_timeout_minutes
            )
            if closed:
                _logger.info(
                    "Inactivity sweep: closed %d session(s) (> %d min idle)",
                    len(closed),
                    inactivity_timeout_minutes,
                )
        except asyncio.CancelledError:
            raise
        except Exception:
            _logger.warning("Inactivity sweep failed", exc_info=True)
        await asyncio.sleep(interval_seconds)


async def _run_staleness_loop(
    scorer: StalenessScorer,
    interval_seconds: int,
) -> None:
    """Recurring background task: rescore staleness and detect contradictions.

    Runs forever on a ``interval_seconds`` cadence. Logs counts at INFO
    level. Any scorer error is caught so the loop continues.
    """
    import asyncio

    while True:
        try:
            scored = await scorer.score_project("default")
            flagged = sum(1 for _id, s, _sig in scored if s > 0.3)
            _logger.info(
                "Staleness sweep: scored %d decisions, %d above 0.3 threshold",
                len(scored),
                flagged,
            )
            try:
                conflicts = await scorer.detect_contradictions("default")
                _logger.info(
                    "Contradiction sweep: %d active conflict(s)",
                    len(conflicts),
                )
            except Exception:
                _logger.warning(
                    "Contradiction sweep failed", exc_info=True
                )
        except asyncio.CancelledError:
            raise
        except Exception:
            _logger.warning("Staleness sweep failed", exc_info=True)
        await asyncio.sleep(interval_seconds)


async def _build_snapshot_diff(
    db: SQLiteBackend,
    before_snapshot_id: object,
    after_snapshot_id: str,
    file_path: str,
) -> str:
    """Turn two snapshot IDs into a unified diff via :class:`SnapshotStore`.

    ``before_snapshot_id`` may be ``None`` when this is the first time
    CodeLedger has seen the file — in that case we diff against an
    empty string so every top-level entity shows up as an addition.
    """
    from backend.utils.snapshot_store import SnapshotStore

    store = SnapshotStore(db)
    if before_snapshot_id in (None, "", "None"):
        # First-ever sighting — diff against an empty baseline.
        after_snap = await store._fetch_snapshot(after_snapshot_id)
        import difflib

        return "".join(
            difflib.unified_diff(
                [],
                after_snap.content.splitlines(keepends=True),
                fromfile=f"a/{file_path}",
                tofile=f"b/{file_path}",
                n=3,
            )
        )
    return await store.diff_snapshots(
        str(before_snapshot_id), after_snapshot_id
    )


def _validate_webhook_secret(
    request: Request, creds: CredentialManager
) -> None:
    """Compare ``X-Webhook-Secret`` against the stored secret in constant time.

    Raises :class:`HTTPException` 401 when the header is missing, the
    secret is not configured on the server, or the values do not match.
    """
    provided = request.headers.get("X-Webhook-Secret", "")
    if not provided:
        raise HTTPException(status_code=401, detail="Missing webhook secret")
    try:
        expected = creds.get(_WEBHOOK_PROVIDER, _WEBHOOK_SECRET_KEY)
    except Exception as exc:
        _logger.warning("Webhook secret lookup failed: %s", exc)
        raise HTTPException(
            status_code=500, detail="Webhook secret unavailable"
        ) from exc
    if not expected:
        raise HTTPException(
            status_code=401, detail="Webhook secret not configured"
        )
    if not hmac.compare_digest(provided, expected):
        raise HTTPException(status_code=401, detail="Invalid webhook secret")


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------


def create_app(config: CodeLedgerConfig | None = None) -> FastAPI:
    """Construct the full CodeLedger FastAPI application.

    All subsystems (logging, config, DB, auth, MCP, API) are wired up here.
    The returned app is ready to serve via ``uvicorn``.
    """
    if config is None:
        config = load_config()

    setup_logging(config.server.log_level.upper())

    project_root = config.project_root
    sqlite_path = project_root / config.database.sqlite_path
    sqlite_path.parent.mkdir(parents=True, exist_ok=True)

    db = SQLiteBackend(sqlite_path)
    creds = CredentialManager(config.vault)
    auth = AuthService(
        db,
        creds,
        AuthSettings(
            jwt_expiry_hours=config.auth.jwt_expiry_hours,
            argon2_memory_cost_kb=config.auth.argon2_memory_cost_kb,
            argon2_time_cost=config.auth.argon2_time_cost,
            argon2_parallelism=config.auth.argon2_parallelism,
        ),
    )
    verifier = Verifier(db)
    quality_harness = QualityHarness(db)
    conflict_detector = ConflictDetector(db)
    provenance_engine = ProvenanceEngine(db)
    ast_tracker = ASTTracker(db=db)
    drift_detector = DriftDetector(db=db, ast_tracker=ast_tracker)
    tautology_detector = TautologyDetector(db=db, ast_tracker=ast_tracker)
    rollback_planner = RollbackPlanner(db=db, provenance=provenance_engine)
    knowledge_packs = KnowledgePackManager(db=db)
    backend_name: Literal["git", "file_watcher"] = (
        "file_watcher"
        if config.change_detection.backend == "file_watcher"
        else "git"
    )
    agent_profiler = AgentProfiler(db=db, change_detection_backend=backend_name)
    decision_inferrer = DecisionInferrer(
        db=db,
        ast_tracker=ast_tracker,
        # ``semantic_search`` is wired in by ``ToolHandlers`` when the
        # embedder + vector store are available. The inferrer tolerates
        # ``None`` — dedup (GR-7) is skipped in that case.
        semantic_search=None,
    )
    staleness_scorer = StalenessScorer(db=db)
    # Context verifier (Phase 4 — VGR-1..VGR-7). Reads cached drift
    # state from ``DriftDetector.get_violations_for_decision`` and
    # staleness from the ``decisions`` row directly.
    from backend.verification.context_verifier import ContextVerifier

    context_verifier = ContextVerifier(
        db=db,
        drift_detector=drift_detector,
        staleness_scorer=staleness_scorer,
    )
    handlers = ToolHandlers(
        db=db,
        verifier=verifier,
        harness=quality_harness,
        conflict_detector=conflict_detector,
        provenance=provenance_engine,
        drift_detector=drift_detector,
        tautology_detector=tautology_detector,
        rollback_planner=rollback_planner,
        knowledge_packs=knowledge_packs,
        agent_profiler=agent_profiler,
        decision_inferrer=decision_inferrer,
        staleness_scorer=staleness_scorer,
        context_verifier=context_verifier,
        change_detection_backend=config.change_detection.backend,
        project_root=str(project_root),
        auto_confirm_threshold=config.session.auto_confirm_threshold,
    )
    mcp_server = create_mcp_server(handlers)
    mcp_app = mcp_server.http_app(path="/")

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        _ = app  # signature required by FastAPI lifespan contract
        await db.connect()
        await apply_migrations(db)
        import asyncio

        staleness_task = asyncio.create_task(
            _run_staleness_loop(staleness_scorer, interval_seconds=86400)
        )
        # Inactivity sweep runs every 5 minutes; timeout window read from
        # SessionConfig. Clamped floor in close_inactive_sessions itself.
        inactivity_task = asyncio.create_task(
            _close_inactive_sessions_loop(
                handlers=handlers,
                inactivity_timeout_minutes=config.session.inactivity_timeout_minutes,
                interval_seconds=300,
            )
        )
        try:
            # FastAPI does not propagate lifespan events to mounted sub-apps,
            # so FastMCP's streamable-HTTP session manager must be started here.
            async with mcp_app.lifespan(app):
                yield
        finally:
            for task in (staleness_task, inactivity_task):
                task.cancel()
                with suppress(asyncio.CancelledError, Exception):
                    await task
            await db.close()

    app = FastAPI(
        title="CodeLedger",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Health check (SEC-05 exemption)
    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    # -- Onboarding (SEC-05 exemption — reachable before auth is configured) --

    @app.get("/api/setup/status")
    async def setup_status() -> dict[str, object]:
        """Return first-time setup progress for the browser walkthrough."""
        rows = await db.execute_raw(
            "SELECT setup_complete, step_reached FROM _setup WHERE id = 1"
        )
        row = rows[0] if rows else {}
        setup_complete = bool(row.get("setup_complete") or 0)
        step_reached = int(row.get("step_reached") or 1)
        decisions = await db.query(
            "decisions", order_by="created_at DESC", limit=1
        )
        sessions = await db.query(
            "sessions", order_by="started_at DESC", limit=1
        )
        decisions_count_rows = await db.execute_raw(
            "SELECT COUNT(*) AS n FROM decisions"
        )
        sessions_count_rows = await db.execute_raw(
            "SELECT COUNT(*) AS n FROM sessions"
        )
        _ = decisions, sessions
        return {
            "setup_complete": setup_complete,
            "step_reached": step_reached,
            "project_name": config.project_root.name,
            "change_detection_backend": config.change_detection.backend,
            "mode": config.server.mode,
            "port": config.server.port,
            "decisions_count": int(
                decisions_count_rows[0].get("n") or 0
            ) if decisions_count_rows else 0,
            "sessions_count": int(
                sessions_count_rows[0].get("n") or 0
            ) if sessions_count_rows else 0,
        }

    # -- OAuth dashboard login (SEC-05 exemption — auth is delegated to the
    #    upstream provider and validated via state/PKCE before a session is
    #    issued). Routes live under /api/auth/oauth/ which is listed in
    #    _PUBLIC_PREFIXES so AuthMiddleware doesn't reject the initiation
    #    request or the provider callback. -----------------------------------

    @app.get("/api/auth/oauth/providers", include_in_schema=False)
    async def oauth_providers() -> dict[str, object]:
        """Report which OAuth providers have credentials configured.

        The LoginView uses this to disable buttons and show setup hints
        instead of navigating users into a confusing 401 or 503 page.
        """
        from backend.auth.oauth_manager import load_providers

        try:
            registry = load_providers(config.providers.registry_path)
        except Exception:
            registry = {}

        def _has_creds(name: str) -> bool:
            prov = registry.get(name)
            if prov is None:
                return False
            try:
                env_id = os.environ.get(prov.client_id_env, "") if prov.client_id_env else ""
                env_secret = (
                    os.environ.get(prov.client_secret_env, "") if prov.client_secret_env else ""
                )
                cid = env_id or (creds.get(name, "client_id") or "")
                sec = env_secret or (creds.get(name, "client_secret") or "")
                return bool(cid) and bool(sec)
            except Exception:
                return False

        return {
            "google": {
                "configured": _has_creds("google"),
                "setup_command": "codeledger config set-oauth --provider google",
            },
            "github": {
                "configured": _has_creds("github"),
                "setup_command": "codeledger config set-oauth --provider github",
            },
        }

    @app.get("/api/auth/oauth/{provider}", include_in_schema=False)
    async def oauth_initiate(provider: str) -> Any:
        """Redirect to the upstream provider's authorization URL.

        Returns a 503 JSON response with an actionable setup command
        when the provider's client ID or secret is missing from the
        vault — replaces the previous generic 401 "Missing credentials"
        surface that confused users.
        """
        from backend.auth.oauth_manager import (
            OAuthError,
            OAuthManager,
            generate_pkce,
            generate_state,
            load_providers,
            build_auth_url,
        )

        if provider not in ("google", "github"):
            return JSONResponse(
                status_code=404,
                content={"detail": f"Unknown OAuth provider: {provider}"},
            )

        try:
            registry = load_providers(config.providers.registry_path)
        except Exception as exc:
            _logger.warning("OAuth provider registry failed to load: %s", exc)
            return JSONResponse(
                status_code=500,
                content={"detail": "Provider registry unavailable"},
            )

        manager = OAuthManager(registry, creds)
        try:
            provider_cfg = manager.get_provider(provider)
            client_id, _ = manager.get_client_credentials(provider_cfg)
        except OAuthError:
            return JSONResponse(
                status_code=503,
                content={
                    "detail": (
                        f"{provider.title()} OAuth is not configured. "
                        f"Run: codeledger config set-oauth --provider {provider}"
                    ),
                    "provider": provider,
                    "configured": False,
                    "setup_command": (
                        f"codeledger config set-oauth --provider {provider}"
                    ),
                },
            )

        state = generate_state()
        code_challenge: str | None = None
        if provider_cfg.pkce:
            _, code_challenge = generate_pkce()

        redirect_uri = f"http://{config.server.host}:{config.server.port}/api/auth/oauth/{provider}/callback"
        url = build_auth_url(
            provider_cfg, client_id, redirect_uri, state, code_challenge
        )
        from fastapi.responses import RedirectResponse

        return RedirectResponse(url=url, status_code=302)

    @app.post("/api/setup/complete")
    async def setup_complete(request: Request) -> dict[str, object]:
        """Mark onboarding as complete or record the step the user reached."""
        try:
            body = await request.json()
        except Exception:
            body = {}
        step = int(body.get("step_reached") or 5)
        mark_complete = bool(body.get("complete", True))
        await db.execute_raw(
            "UPDATE _setup SET setup_complete = ?, step_reached = ?, "
            "updated_at = datetime('now') WHERE id = 1",
            (1 if mark_complete else 0, step),
        )
        return {"setup_complete": mark_complete, "step_reached": step}

    # Webhook endpoints — SEC-05 exemption for bearer auth; gated by
    # X-Webhook-Secret header validated against the vault.
    @app.post("/api/hooks/post-commit")
    async def post_commit_hook(request: Request) -> dict[str, object]:
        """Receive a git post-commit hook and run the change-event pipeline."""
        _validate_webhook_secret(request, creds)
        body = await request.json()
        commit_hash = str(body.get("commit_hash", ""))
        diff_text = str(body.get("diff_text", ""))
        project_id = str(body.get("project_id", ""))
        active_session_id = body.get("active_session_id")
        if not commit_hash or not project_id:
            raise HTTPException(
                status_code=400,
                detail="commit_hash and project_id are required",
            )
        # Forward-only actor enrichment: the pre-v11 hook template did
        # not POST author_email, so legacy deployments leave this
        # field empty and the row persists with actor_id=NULL. Hook
        # templates updated after v11 include ``author_email``.
        author_email = body.get("author_email") or None
        try:
            result = await ast_tracker.process_change_event(
                change_event_id=commit_hash,
                change_event_source="git_commit",
                diff_text=diff_text,
                project_id=project_id,
                active_session_id=(
                    str(active_session_id) if active_session_id else None
                ),
                actor_type="human",
                actor_id=str(author_email) if author_email else None,
            )
        except ASTTrackerError as exc:
            _logger.warning("post-commit hook: %s", exc)
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {
            "received": True,
            "linked_changes": result["linked_changes"],
            "unlinked_changes": result["unlinked_changes"],
        }

    @app.post("/api/hooks/file-change")
    async def file_change_hook(request: Request) -> dict[str, object]:
        """Receive a file-watcher change event and run the pipeline."""
        _validate_webhook_secret(request, creds)
        body = await request.json()
        file_path = str(body.get("file_path", ""))
        project_id = str(body.get("project_id", ""))
        after_snapshot_id = str(body.get("after_snapshot_id", ""))
        before_snapshot_id = body.get("before_snapshot_id")
        active_session_id = body.get("active_session_id")
        if not project_id or not after_snapshot_id:
            raise HTTPException(
                status_code=400,
                detail="project_id and after_snapshot_id are required",
            )
        # The diff text is computed by the SnapshotStore from the two
        # snapshot IDs. We fetch them lazily here so the watcher stays
        # focused on filesystem events.
        diff_text = await _build_snapshot_diff(
            db, before_snapshot_id, after_snapshot_id, file_path
        )
        try:
            result = await ast_tracker.process_change_event(
                change_event_id=after_snapshot_id,
                change_event_source="file_snapshot",
                diff_text=diff_text,
                project_id=project_id,
                active_session_id=(
                    str(active_session_id) if active_session_id else None
                ),
                actor_type="human",
                actor_id=None,
            )
        except ASTTrackerError as exc:
            _logger.warning("file-change hook: %s", exc)
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {
            "received": True,
            "linked_changes": result["linked_changes"],
            "unlinked_changes": result["unlinked_changes"],
        }

    # Explicit 308 for POST /mcp → /mcp/. Starlette's Mount would otherwise emit
    # a 307, and some MCP HTTP clients (Claude Code) do not follow redirects on
    # POST, breaking the initialize handshake. 308 preserves the method per
    # RFC 7538, so clients that do follow it re-POST to the canonical path.
    @app.api_route(
        "/mcp",
        methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
    )
    async def _mcp_trailing_slash_redirect(request: Request) -> "RedirectResponse":
        from fastapi.responses import RedirectResponse

        target = "/mcp/"
        if request.url.query:
            target = f"{target}?{request.url.query}"
        return RedirectResponse(url=target, status_code=308)

    # Mount MCP server (mcp_app is created above so its lifespan can be nested).
    app.mount("/mcp", mcp_app)

    # Register REST API
    app.include_router(create_api_router(handlers), prefix="/api")

    # Global exception handler — never leak stack traces to clients.
    @app.exception_handler(Exception)
    async def _generic_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        _ = request
        if isinstance(exc, HTTPException):
            raise exc
        _logger.error(
            "Unhandled exception: %s", type(exc).__name__, exc_info=True
        )
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"},
        )

    # Body size limit — reject requests over 10 MB before they ever hit a
    # handler. Implemented inline rather than via a third-party dep so
    # there is no uncommon supply-chain footprint on the hot path.
    max_body_size = 10 * 1024 * 1024

    @app.middleware("http")
    async def _body_size_limit(
        request: Request, call_next: Any
    ) -> Any:
        cl = request.headers.get("content-length")
        if cl is not None:
            try:
                if int(cl) > max_body_size:
                    return JSONResponse(
                        status_code=413,
                        content={
                            "detail": (
                                f"Payload too large. Maximum is "
                                f"{max_body_size} bytes."
                            )
                        },
                    )
            except ValueError:
                pass
        result = await call_next(request)
        return cast(JSONResponse, result)

    # Rate limiting. Scopes by URL prefix:
    # auth/register/login — 5/minute
    # /api/embeddings (context.get_relevant et al) — 30/minute
    # All other /mcp routes — 120/minute
    limiter = Limiter(key_func=get_remote_address, default_limits=[])
    app.state.limiter = limiter

    @app.exception_handler(RateLimitExceeded)
    async def _rate_limit_handler(
        request: Request, exc: RateLimitExceeded
    ) -> JSONResponse:
        _ = (request, exc)
        return JSONResponse(
            status_code=429,
            content={"detail": "Rate limit exceeded. Please retry shortly."},
        )

    # Track requests per (remote_addr, route_tier) to avoid depending on
    # slowapi private APIs. slowapi's Limiter is kept on app.state so
    # handlers can still opt into per-route decorators if they want.
    import time as _time
    from collections import defaultdict as _defaultdict

    rate_buckets: dict[tuple[str, str], list[float]] = _defaultdict(list)

    def _tier_for(path: str) -> tuple[str, int] | None:
        if path.startswith("/api/auth/"):
            return "auth", 5
        if path.startswith("/mcp"):
            return "mcp", 120
        if path.startswith("/api/context/relevant") or path.startswith(
            "/api/context/for-file"
        ):
            return "embedding", 30
        return None

    @app.middleware("http")
    async def _apply_rate_limits(
        request: Request, call_next: Any
    ) -> Any:
        tier = _tier_for(request.url.path)
        if tier is not None:
            tier_name, per_minute = tier
            now = _time.monotonic()
            key = (get_remote_address(request) or "anon", tier_name)
            bucket = rate_buckets[key]
            # Drop entries older than 60s.
            while bucket and now - bucket[0] > 60.0:
                bucket.pop(0)
            if len(bucket) >= per_minute:
                return JSONResponse(
                    status_code=429,
                    content={
                        "detail": "Rate limit exceeded. Please retry shortly."
                    },
                )
            bucket.append(now)
        result = await call_next(request)
        return cast(JSONResponse, result)

    # CORS — solo mode is strictly loopback; team mode allows the origin
    # configured for the dashboard (falls back to the localhost dev server).
    cors_origins: list[str] = ["http://localhost:5173", "http://127.0.0.1:5173"]
    if config.server.mode == "solo":
        cors_origins = [
            "http://localhost:5173",
            "http://127.0.0.1:5173",
            f"http://localhost:{config.server.port}",
            f"http://127.0.0.1:{config.server.port}",
        ]
    else:
        # Team mode — allow any origin the dashboard is served from plus
        # the dev origins. A wildcard is NOT set — that would break
        # ``allow_credentials=True`` anyway per the CORS spec.
        team_origin_env = os.environ.get("CODELEDGER_ALLOWED_ORIGINS", "")
        if team_origin_env.strip() == "*":
            _logger.warning(
                "CODELEDGER_ALLOWED_ORIGINS=* is not supported with "
                "credentialed requests. Pin to an explicit list of URLs."
            )
        elif team_origin_env:
            cors_origins.extend(
                [o.strip() for o in team_origin_env.split(",") if o.strip()]
            )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        allow_headers=["Authorization", "Content-Type"],
    )

    # Auth middleware runs before Security in the ASGI onion so that 401
    # responses still pass through Security on the way back out. Added
    # first means it sits deeper; the outermost middleware wraps its
    # responses with security headers.
    frontend_dist = _resolve_frontend_dist()

    @app.get("/", include_in_schema=False)
    async def serve_root() -> Any:
        if frontend_dist is not None:
            return FileResponse(frontend_dist / "index.html")
        return {"message": "CodeLedger API", "docs": "/docs", "health": "/health"}

    if frontend_dist is not None:
        assets_dir = frontend_dist / "assets"
        if assets_dir.exists():
            app.mount(
                "/assets",
                StaticFiles(directory=str(assets_dir)),
                name="assets",
            )

        favicon = frontend_dist / "favicon.ico"
        if favicon.exists():
            @app.get("/favicon.ico", include_in_schema=False)
            async def serve_favicon() -> FileResponse:
                return FileResponse(favicon)

    app.add_middleware(
        AuthMiddleware,
        auth_service=auth,
        public_paths=_PUBLIC_PATHS,
        public_prefixes=_PUBLIC_PREFIXES,
        credentials=creds,
    )

    # Security headers — added last so it's outermost and attaches the
    # headers to every response, including the 401s emitted by Auth.
    app.add_middleware(SecurityHeadersMiddleware)

    # Expose internals for testing / CLI introspection
    app.state.db = db
    app.state.auth = auth
    app.state.handlers = handlers
    app.state.config = config
    app.state.mcp = mcp_server
    app.state.ast_tracker = ast_tracker
    app.state.credentials = creds

    return app


# Module-level ``app`` for ``uvicorn backend.main:app``. Built lazily at
# import time so:
#   - ``codeledger serve`` (which has already validated codeledger.toml
#     exists) gets a real app when uvicorn imports this module.
#   - Tests that import ``create_app`` from this module don't fail at
#     import time when the test process has no codeledger.toml in cwd —
#     the suppress lets them proceed to call create_app() with an
#     explicit config fixture.
# When ``app`` ends up unbound (no config present), the CLI's ``serve``
# command catches that case earlier with an actionable error; if a user
# invokes uvicorn directly without a config, they see the standard
# "Attribute 'app' not found" — at which point they need ``codeledger
# init``.
with suppress(FileNotFoundError):
    app = create_app()
