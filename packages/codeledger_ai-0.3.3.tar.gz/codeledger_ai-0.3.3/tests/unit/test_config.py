"""Tests for backend.config — configuration loading and validation.

Covers: valid config loading, permission rejection (SEC-09), path traversal
rejection, missing file handling, default values, env var resolution, value
validation, and config immutability.
"""

from __future__ import annotations

import dataclasses
import sys
import textwrap
from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    from pathlib import Path

from backend.config import (
    CodeLedgerConfig,
    ConfigError,
    ContextConfig,
    CredentialConfig,
    DatabaseConfig,
    EmbeddingConfig,
    GitConfig,
    OAuthProviderConfig,
    ProvidersConfig,
    ServerConfig,
    load_config,
)


def _write_toml(tmp_path: Path, content: str, mode: int = 0o600) -> Path:
    """Write TOML content to a temp config file with the given permissions."""
    config_file = tmp_path / "codeledger.toml"
    config_file.write_text(content, encoding="utf-8")
    if sys.platform != "win32":
        config_file.chmod(mode)
    return config_file


_FULL_TOML = textwrap.dedent("""\
    [server]
    mode = "team"
    host = "0.0.0.0"
    port = 9200
    log_level = "debug"

    [database]
    backend = "postgresql"
    sqlite_path = "data/codeledger.db"
    pg_dsn_env = "MY_PG_DSN"

    [vault]
    backend = "file"
    vault_path = "~/.codeledger/vault.enc"

    [embeddings]
    ollama_url = "http://gpu-server:11434"
    model = "custom-embed"
    batch_size = 64

    [auth]
    jwt_expiry_hours = 48
    cookie_secure = false
    cookie_samesite = "strict"
    argon2_memory_cost_kb = 131072
    argon2_time_cost = 5
    argon2_parallelism = 8

    [auth.google]
    client_id_env = "MY_GOOGLE_ID"
    client_secret_env = "MY_GOOGLE_SECRET"

    [auth.github]
    client_id_env = "MY_GITHUB_ID"
    client_secret_env = "MY_GITHUB_SECRET"

    [context]
    default_token_budget = 16000
    max_token_budget = 64000

    [git]
    install_hooks = false

    [providers]
    registry_path = "providers.toml"
""")


# ---------------------------------------------------------------------------
# Valid config loading
# ---------------------------------------------------------------------------


class TestLoadValidConfig:
    """Tests for successfully loading valid configurations."""

    def test_full_config(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, _FULL_TOML)
        cfg = load_config(config_file, project_root=tmp_path)

        assert cfg.server.mode == "team"
        assert cfg.server.host == "0.0.0.0"
        assert cfg.server.port == 9200
        assert cfg.server.log_level == "debug"
        assert cfg.database.backend == "postgresql"
        assert cfg.database.pg_dsn_env == "MY_PG_DSN"
        assert cfg.vault.backend == "file"
        assert cfg.vault.vault_path == "~/.codeledger/vault.enc"
        assert cfg.embeddings.ollama_url == "http://gpu-server:11434"
        assert cfg.embeddings.model == "custom-embed"
        assert cfg.embeddings.batch_size == 64
        assert cfg.auth.jwt_expiry_hours == 48
        assert cfg.auth.cookie_secure is False
        assert cfg.auth.cookie_samesite == "strict"
        assert cfg.auth.argon2_memory_cost_kb == 131072
        assert cfg.auth.argon2_time_cost == 5
        assert cfg.auth.argon2_parallelism == 8
        assert cfg.auth.google.client_id_env == "MY_GOOGLE_ID"
        assert cfg.auth.google.client_secret_env == "MY_GOOGLE_SECRET"
        assert cfg.auth.github.client_id_env == "MY_GITHUB_ID"
        assert cfg.auth.github.client_secret_env == "MY_GITHUB_SECRET"
        assert cfg.context.default_token_budget == 16000
        assert cfg.context.max_token_budget == 64000
        assert cfg.git.install_hooks is False
        assert cfg.providers.registry_path == "providers.toml"
        assert cfg.project_root == tmp_path

    def test_empty_config_uses_defaults(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "")
        cfg = load_config(config_file, project_root=tmp_path)

        assert cfg.server == ServerConfig()
        assert cfg.database == DatabaseConfig()
        assert cfg.vault == CredentialConfig()
        assert cfg.embeddings == EmbeddingConfig()
        assert cfg.auth.jwt_expiry_hours == 24
        assert cfg.auth.cookie_secure is True
        assert cfg.auth.google == OAuthProviderConfig()
        assert cfg.auth.github == OAuthProviderConfig()
        assert cfg.context == ContextConfig()
        assert cfg.git == GitConfig()
        assert cfg.providers == ProvidersConfig()

    def test_partial_config_merges_with_defaults(self, tmp_path: Path) -> None:
        toml = textwrap.dedent("""\
            [server]
            mode = "team"
            port = 9000
        """)
        config_file = _write_toml(tmp_path, toml)
        cfg = load_config(config_file, project_root=tmp_path)

        assert cfg.server.mode == "team"
        assert cfg.server.port == 9000
        assert cfg.server.host == "127.0.0.1"
        assert cfg.server.log_level == "info"
        assert cfg.database == DatabaseConfig()

    def test_unknown_keys_ignored(self, tmp_path: Path) -> None:
        toml = textwrap.dedent("""\
            [server]
            mode = "solo"
            future_feature = true
        """)
        config_file = _write_toml(tmp_path, toml)
        cfg = load_config(config_file, project_root=tmp_path)
        assert cfg.server.mode == "solo"
        assert not hasattr(cfg.server, "future_feature")

    def test_project_root_defaults_to_config_parent(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "")
        cfg = load_config(config_file)
        assert cfg.project_root == config_file.parent

    def test_explicit_project_root_used(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "")
        custom_root = tmp_path / "project"
        custom_root.mkdir()
        cfg = load_config(config_file, project_root=custom_root)
        assert cfg.project_root == custom_root

    def test_frozen_config_is_immutable(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "")
        cfg = load_config(config_file, project_root=tmp_path)
        with pytest.raises(dataclasses.FrozenInstanceError):
            cfg.server = ServerConfig(mode="team")  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Missing file handling
# ---------------------------------------------------------------------------


class TestMissingFile:
    """Tests for missing config file error reporting."""

    def test_nonexistent_file_raises(self, tmp_path: Path) -> None:
        missing = tmp_path / "nonexistent.toml"
        with pytest.raises(FileNotFoundError, match="Config file not found"):
            load_config(missing)

    def test_directory_instead_of_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError, match="Config file not found"):
            load_config(tmp_path)


# ---------------------------------------------------------------------------
# SEC-09: Permission validation
# ---------------------------------------------------------------------------


class TestPermissionValidation:
    """Tests for SEC-09: config file must not be world-readable."""

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX permissions only")
    def test_world_readable_rejected(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "", mode=0o644)
        with pytest.raises(ConfigError, match="world-readable"):
            load_config(config_file, project_root=tmp_path)

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX permissions only")
    def test_world_readable_writable_rejected(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "", mode=0o666)
        with pytest.raises(ConfigError, match="world-readable"):
            load_config(config_file, project_root=tmp_path)

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX permissions only")
    def test_owner_only_accepted(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "", mode=0o600)
        cfg = load_config(config_file, project_root=tmp_path)
        assert isinstance(cfg, CodeLedgerConfig)

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX permissions only")
    def test_group_readable_accepted(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "", mode=0o640)
        cfg = load_config(config_file, project_root=tmp_path)
        assert isinstance(cfg, CodeLedgerConfig)


# ---------------------------------------------------------------------------
# Path traversal prevention
# ---------------------------------------------------------------------------


class TestPathTraversal:
    """Tests for rejecting relative paths that escape the project root."""

    def test_sqlite_path_traversal_rejected(self, tmp_path: Path) -> None:
        toml = '[database]\nsqlite_path = "../../etc/shadow"'
        config_file = _write_toml(tmp_path, toml)
        with pytest.raises(ConfigError, match="Path traversal.*database.sqlite_path"):
            load_config(config_file, project_root=tmp_path)

    def test_providers_path_traversal_rejected(self, tmp_path: Path) -> None:
        toml = '[providers]\nregistry_path = "../../../etc/passwd"'
        config_file = _write_toml(tmp_path, toml)
        with pytest.raises(ConfigError, match="Path traversal.*providers.registry_path"):
            load_config(config_file, project_root=tmp_path)

    def test_vault_relative_traversal_rejected(self, tmp_path: Path) -> None:
        toml = '[vault]\nvault_path = "../../../tmp/evil.enc"'
        config_file = _write_toml(tmp_path, toml)
        with pytest.raises(ConfigError, match="Path traversal.*vault.vault_path"):
            load_config(config_file, project_root=tmp_path)

    def test_valid_relative_path_accepted(self, tmp_path: Path) -> None:
        toml = '[database]\nsqlite_path = "data/codeledger.db"'
        config_file = _write_toml(tmp_path, toml)
        cfg = load_config(config_file, project_root=tmp_path)
        assert cfg.database.sqlite_path == "data/codeledger.db"

    def test_subdirectory_relative_path_accepted(self, tmp_path: Path) -> None:
        toml = '[database]\nsqlite_path = "data/sub/deep/db.sqlite"'
        config_file = _write_toml(tmp_path, toml)
        cfg = load_config(config_file, project_root=tmp_path)
        assert cfg.database.sqlite_path == "data/sub/deep/db.sqlite"

    def test_home_tilde_path_accepted(self, tmp_path: Path) -> None:
        toml = '[vault]\nvault_path = "~/.codeledger/vault.enc"'
        config_file = _write_toml(tmp_path, toml)
        cfg = load_config(config_file, project_root=tmp_path)
        assert cfg.vault.vault_path == "~/.codeledger/vault.enc"

    def test_absolute_path_accepted(self, tmp_path: Path) -> None:
        toml = '[vault]\nvault_path = "/opt/codeledger/vault.enc"'
        config_file = _write_toml(tmp_path, toml)
        cfg = load_config(config_file, project_root=tmp_path)
        assert cfg.vault.vault_path == "/opt/codeledger/vault.enc"


# ---------------------------------------------------------------------------
# Env var resolution for config path
# ---------------------------------------------------------------------------


class TestEnvVarResolution:
    """Tests for CODELEDGER_CONFIG environment variable."""

    def test_env_var_config_path(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config_file = _write_toml(tmp_path, '[server]\nmode = "team"')
        monkeypatch.setenv("CODELEDGER_CONFIG", str(config_file))
        cfg = load_config(project_root=tmp_path)
        assert cfg.server.mode == "team"

    def test_explicit_path_overrides_env_var(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        env_file = _write_toml(tmp_path, '[server]\nmode = "team"')

        explicit_dir = tmp_path / "other"
        explicit_dir.mkdir()
        explicit_file = explicit_dir / "codeledger.toml"
        explicit_file.write_text('[server]\nmode = "solo"', encoding="utf-8")
        if sys.platform != "win32":
            explicit_file.chmod(0o600)

        monkeypatch.setenv("CODELEDGER_CONFIG", str(env_file))
        cfg = load_config(explicit_file, project_root=tmp_path)
        assert cfg.server.mode == "solo"


# ---------------------------------------------------------------------------
# Value validation (enums, port range, TOML syntax)
# ---------------------------------------------------------------------------


class TestValueValidation:
    """Tests for config value validation."""

    def test_invalid_server_mode(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, '[server]\nmode = "cluster"')
        with pytest.raises(ConfigError, match="Invalid server.mode"):
            load_config(config_file, project_root=tmp_path)

    def test_invalid_log_level(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, '[server]\nlog_level = "verbose"')
        with pytest.raises(ConfigError, match="Invalid server.log_level"):
            load_config(config_file, project_root=tmp_path)

    def test_invalid_db_backend(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, '[database]\nbackend = "mysql"')
        with pytest.raises(ConfigError, match="Invalid database.backend"):
            load_config(config_file, project_root=tmp_path)

    def test_invalid_vault_backend(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, '[vault]\nbackend = "redis"')
        with pytest.raises(ConfigError, match="Invalid vault.backend"):
            load_config(config_file, project_root=tmp_path)

    def test_port_zero_rejected(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "[server]\nport = 0")
        with pytest.raises(ConfigError, match="Invalid server.port"):
            load_config(config_file, project_root=tmp_path)

    def test_port_too_high_rejected(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "[server]\nport = 70000")
        with pytest.raises(ConfigError, match="Invalid server.port"):
            load_config(config_file, project_root=tmp_path)

    def test_malformed_toml_rejected(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, "this is [not valid{{{")
        with pytest.raises(ConfigError, match="Malformed TOML"):
            load_config(config_file, project_root=tmp_path)

    def test_section_not_table_rejected(self, tmp_path: Path) -> None:
        config_file = _write_toml(tmp_path, 'server = "not a table"')
        with pytest.raises(ConfigError, match="must be a TOML table"):
            load_config(config_file, project_root=tmp_path)

    def test_nested_section_not_table_rejected(self, tmp_path: Path) -> None:
        toml = textwrap.dedent("""\
            [auth]
            google = "not a table"
        """)
        config_file = _write_toml(tmp_path, toml)
        with pytest.raises(ConfigError, match="must be a TOML table"):
            load_config(config_file, project_root=tmp_path)
