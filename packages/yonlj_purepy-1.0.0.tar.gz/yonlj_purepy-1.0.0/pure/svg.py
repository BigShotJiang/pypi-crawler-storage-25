from .core.SVG import SVG


def a(*args):
    return SVG("a", args)


def animate(*args):
    return SVG("animate", args)


def animateMotion(*args):
    return SVG("animateMotion", args)


def animateTransform(*args):
    return SVG("animateTransform", args)


def circle(*args):
    return SVG("circle", args)


def clipPath(*args):
    return SVG("clipPath", args)


def defs(*args):
    return SVG("defs", args)


def desc(*args):
    return SVG("desc", args)


def ellipse(*args):
    return SVG("ellipse", args)


def feBlend(*args):
    return SVG("feBlend", args)


def feColorMatrix(*args):
    return SVG("feColorMatrix", args)


def feComponentTransfer(*args):
    return SVG("feComponentTransfer", args)


def feComposite(*args):
    return SVG("feComposite", args)


def feConvolveMatrix(*args):
    return SVG("feConvolveMatrix", args)


def feDiffuseLighting(*args):
    return SVG("feDiffuseLighting", args)


def feDisplacementMap(*args):
    return SVG("feDisplacementMap", args)


def feDistantLight(*args):
    return SVG("feDistantLight", args)


def feDropShadow(*args):
    return SVG("feDropShadow", args)


def feFlood(*args):
    return SVG("feFlood", args)


def feFuncA(*args):
    return SVG("feFuncA", args)


def feFuncB(*args):
    return SVG("feFuncB", args)


def feFuncG(*args):
    return SVG("feFuncG", args)


def feFuncR(*args):
    return SVG("feFuncR", args)


def feGaussianBlur(*args):
    return SVG("feGaussianBlur", args)


def feImage(*args):
    return SVG("feImage", args)


def feMerge(*args):
    return SVG("feMerge", args)


def feMergeNode(*args):
    return SVG("feMergeNode", args)


def feMorphology(*args):
    return SVG("feMorphology", args)


def feOffset(*args):
    return SVG("feOffset", args)


def fePointLight(*args):
    return SVG("fePointLight", args)


def feSpecularLighting(*args):
    return SVG("feSpecularLighting", args)


def feSpotLight(*args):
    return SVG("feSpotLight", args)


def feTile(*args):
    return SVG("feTile", args)


def feTurbulence(*args):
    return SVG("feTurbulence", args)


def filter(*args):
    return SVG("filter", args)


def foreignObject(*args):
    return SVG("foreignObject", args)


def g(*args):
    return SVG("g", args)


def image(*args):
    return SVG("image", args)


def line(*args):
    return SVG("line", args)


def linearGradient(*args):
    return SVG("linearGradient", args)


def marker(*args):
    return SVG("marker", args)


def mask(*args):
    return SVG("mask", args)


def metadata(*args):
    return SVG("metadata", args)


def mpath(*args):
    return SVG("mpath", args)


def path(*args):
    return SVG("path", args)


def pattern(*args):
    return SVG("pattern", args)


def polygon(*args):
    return SVG("polygon", args)


def polyline(*args):
    return SVG("polyline", args)


def radialGradient(*args):
    return SVG("radialGradient", args)


def rect(*args):
    return SVG("rect", args)


def script(*args):
    return SVG("script", args)


def set(*args):
    return SVG("set", args)


def stop(*args):
    return SVG("stop", args)


def style(*args):
    return SVG("style", args)


def svg(*args):
    return SVG("svg", args)


def switch(*args):
    return SVG("switch", args)


def symbol(*args):
    return SVG("symbol", args)


def text(*args):
    return SVG("text", args)


def textPath(*args):
    return SVG("textPath", args)


def title(*args):
    return SVG("title", args)


def tspan(*args):
    return SVG("tspan", args)


def use(*args):
    return SVG("use", args)


def view(*args):
    return SVG("view", args)
