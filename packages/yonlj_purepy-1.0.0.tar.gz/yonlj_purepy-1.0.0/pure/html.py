from .core.HTML import HTML


def a(*args):
    return HTML("a", args)


def abbr(*args):
    return HTML("abbr", args)


def address(*args):
    return HTML("address", args)


def area(*args):
    return HTML("area", args)


def article(*args):
    return HTML("article", args)


def aside(*args):
    return HTML("aside", args)


def audio(*args):
    return HTML("audio", args)


def b(*args):
    return HTML("b", args)


def base(*args):
    return HTML("base", args)


def bdi(*args):
    return HTML("bdi", args)


def bdo(*args):
    return HTML("bdo", args)


def blockquote(*args):
    return HTML("blockquote", args)


def body(*args):
    return HTML("body", args)


def br(*args):
    return HTML("br", args)


def button(*args):
    return HTML("button", args)


def canvas(*args):
    return HTML("canvas", args)


def caption(*args):
    return HTML("caption", args)


def cite(*args):
    return HTML("cite", args)


def code(*args):
    return HTML("code", args)


def col(*args):
    return HTML("col", args)


def colgroup(*args):
    return HTML("colgroup", args)


def data(*args):
    return HTML("data", args)


def datalist(*args):
    return HTML("datalist", args)


def dd(*args):
    return HTML("dd", args)


def Del(*args):
    return HTML("del", args)


def details(*args):
    return HTML("details", args)


def dfn(*args):
    return HTML("dfn", args)


def dialog(*args):
    return HTML("dialog", args)


def div(*args):
    return HTML("div", args)


def dl(*args):
    return HTML("dl", args)


def dt(*args):
    return HTML("dt", args)


def em(*args):
    return HTML("em", args)


def embed(*args):
    return HTML("embed", args)


def fieldset(*args):
    return HTML("fieldset", args)


def figcaption(*args):
    return HTML("figcaption", args)


def figure(*args):
    return HTML("figure", args)


def footer(*args):
    return HTML("footer", args)


def form(*args):
    return HTML("form", args)


def h1(*args):
    return HTML("h1", args)


def h2(*args):
    return HTML("h2", args)


def h3(*args):
    return HTML("h3", args)


def h4(*args):
    return HTML("h4", args)


def h5(*args):
    return HTML("h5", args)


def h6(*args):
    return HTML("h6", args)


def head(*args):
    return HTML("head", args)


def header(*args):
    return HTML("header", args)


def hgroup(*args):
    return HTML("hgroup", args)


def hr(*args):
    return HTML("hr", args)


def html(*args):
    return HTML("html", args)


def i(*args):
    return HTML("i", args)


def iframe(*args):
    return HTML("iframe", args)


def img(*args):
    return HTML("img", args)


def input(*args):
    return HTML("input", args)


def ins(*args):
    return HTML("ins", args)


def kbd(*args):
    return HTML("kbd", args)


def label(*args):
    return HTML("label", args)


def legend(*args):
    return HTML("legend", args)


def li(*args):
    return HTML("li", args)


def link(*args):
    return HTML("link", args)


def main(*args):
    return HTML("main", args)


def map(*args):
    return HTML("map", args)


def mark(*args):
    return HTML("mark", args)


def menu(*args):
    return HTML("menu", args)


def meta(*args):
    return HTML("meta", args)


def meter(*args):
    return HTML("meter", args)


def nav(*args):
    return HTML("nav", args)


def noscript(*args):
    return HTML("noscript", args)


def object(*args):
    return HTML("object", args)


def ol(*args):
    return HTML("ol", args)


def optgroup(*args):
    return HTML("optgroup", args)


def option(*args):
    return HTML("option", args)


def output(*args):
    return HTML("output", args)


def p(*args):
    return HTML("p", args)


def picture(*args):
    return HTML("picture", args)


def pre(*args):
    return HTML("pre", args)


def progress(*args):
    return HTML("progress", args)


def q(*args):
    return HTML("q", args)


def rp(*args):
    return HTML("rp", args)


def rt(*args):
    return HTML("rt", args)


def ruby(*args):
    return HTML("ruby", args)


def s(*args):
    return HTML("s", args)


def samp(*args):
    return HTML("samp", args)


def script(*args):
    return HTML("script", args)


def section(*args):
    return HTML("section", args)


def select(*args):
    return HTML("select", args)


def slot(*args):
    return HTML("slot", args)


def small(*args):
    return HTML("small", args)


def source(*args):
    return HTML("source", args)


def span(*args):
    return HTML("span", args)


def strong(*args):
    return HTML("strong", args)


def style(*args):
    return HTML("style", args)


def sub(*args):
    return HTML("sub", args)


def summary(*args):
    return HTML("summary", args)


def sup(*args):
    return HTML("sup", args)


def table(*args):
    return HTML("table", args)


def tbody(*args):
    return HTML("tbody", args)


def td(*args):
    return HTML("td", args)


def template(*args):
    return HTML("template", args)


def textarea(*args):
    return HTML("textarea", args)


def tfoot(*args):
    return HTML("tfoot", args)


def th(*args):
    return HTML("th", args)


def thead(*args):
    return HTML("thead", args)


def time(*args):
    return HTML("time", args)


def title(*args):
    return HTML("title", args)


def tr(*args):
    return HTML("tr", args)


def track(*args):
    return HTML("track", args)


def u(*args):
    return HTML("u", args)


def ul(*args):
    return HTML("ul", args)


def video(*args):
    return HTML("video", args)


def wbr(*args):
    return HTML("wbr", args)
