# Changelog

All notable changes to `threatcluster-cli` (the `tc` command) are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
versioning follows [SemVer](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] — TBD

### Added
- Initial release.
- `tc auth login | status | logout` — paste-token credential flow with
  OS-keyring storage (Keychain / SecretService / Credential Manager) and
  0600-file fallback.
- Read commands: `tc threats {list,get,iocs,stix}`, `tc iocs {feed,export}`,
  `tc entities {search,get,related,trending}`, `tc vulns {list,get}`,
  `tc darkweb {ransomware victims, breaches, keyword-hits}`,
  `tc feeds {list,get}`.
- Write command: `tc alerts ack <id>` (only write in v1; idempotent).
- Bearer-JWT auth model with in-process caching, ~30s pre-expiry refresh,
  one-shot 401 retry.
- Plaintext-HTTP rejection to non-loopback hosts.
- `Authorization` and `X-API-Key` redaction from debug logs.
- Subprocess auth-env hygiene (`TC_PROPAGATE_AUTH=1` to opt in).
- `--api-key` flag rejected (process-table leak prevention).
