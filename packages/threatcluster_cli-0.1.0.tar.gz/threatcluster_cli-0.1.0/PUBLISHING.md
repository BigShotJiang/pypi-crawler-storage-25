# Publishing `threatcluster-cli` to PyPI

The PyPI project is `threatcluster-cli`; it installs the `tc` console script.

One-time setup (Phases 1–3), then every release is `git tag` + `git push --tags`.

## One-time setup

### 1. Reserve the name on PyPI

1. Sign in / sign up at https://pypi.org.
2. Enable 2FA (PyPI requires it for publishing).
3. You don't need to upload a placeholder — Trusted Publishing creates the
   project on first successful publish. You're claiming the name by being the
   first to publish to it.

### 2. Configure Trusted Publishing on PyPI

PyPI → your account → **Publishing** → **Add a new pending publisher**:

| Field            | Value                                                        |
|------------------|--------------------------------------------------------------|
| PyPI project     | `threatcluster-cli`                                          |
| Owner            | the GitHub org or user that holds this repo                  |
| Repository name  | `threatcluster-cli`                                          |
| Workflow filename| `publish.yml`                                         |
| Environment name | `pypi`                                                       |

This binds PyPI to a specific GitHub Actions workflow in a specific repo.
No API token is created or stored.

### 3. Create the GitHub `pypi` environment

Repo → **Settings** → **Environments** → **New environment** → name it `pypi`.

Highly recommended: enable **Required reviewers** and add yourself. Every
publish then pauses for a manual click — cheap insurance against an
accidental tag push.

Optionally restrict to tags matching `v*.*.*` under **Deployment branches**.

## Every release

1. Bump `version` in `cli/pyproject.toml`.
2. Move the corresponding section in `cli/CHANGELOG.md` from `[Unreleased]`
   to a dated `[X.Y.Z] - YYYY-MM-DD` heading.
3. Commit and tag:
   ```bash
   git commit -am "threatcluster-cli vX.Y.Z"
   git tag vX.Y.Z
   git push && git push --tags
   ```
4. The publish workflow fires. It refuses to publish if the tag and the
   `pyproject.toml` version disagree.
5. Approve the deploy in the **Actions** tab (if you set up Required
   reviewers).
6. After the workflow finishes, `pipx install threatcluster-cli==X.Y.Z`
   works for anyone.

## What lives where

- `cli/pyproject.toml` — package metadata, version, deps, console script (`tc`).
- `cli/CHANGELOG.md` — release notes (Keep-a-Changelog format).
- `.github/workflows/publish.yml` — tag-triggered build + publish.
- `.github/workflows/test.yml` — pytest on push/PR.

## Repo layout

This repo is the entire `threatcluster-cli` Python package. `python -m build`
at the repo root produces a self-contained wheel. Tests live in `tests/`.

## Yanking a bad release

PyPI → project → Manage → Releases → **Yank**. Yank doesn't delete the file
(downloads still work for pinned versions) but hides it from `pip install`
without a version pin. Always prefer yank over delete.

## TestPyPI dry run (optional, recommended for first release)

TestPyPI is a sandbox — same flow, throwaway:

1. Sign up at https://test.pypi.org/ (separate account from PyPI).
2. Add a **pending publisher** there with the same settings as Phase 2.
3. Temporarily edit the publish step in `publish.yml`:
   ```yaml
   - uses: pypa/gh-action-pypi-publish@release/v1
     with:
       packages-dir: dist/
       repository-url: https://test.pypi.org/legacy/
   ```
4. Tag a pre-release: `git tag v0.1.0rc1 && git push --tags`.
5. After it succeeds, install from TestPyPI:
   ```bash
   pipx install --pip-args="--index-url https://test.pypi.org/simple/" \
     threatcluster-cli==0.1.0rc1
   ```
6. If happy, revert the workflow change.
