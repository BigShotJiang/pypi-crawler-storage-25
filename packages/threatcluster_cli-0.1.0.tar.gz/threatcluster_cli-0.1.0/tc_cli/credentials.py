"""Refresh-credential storage.

Storage priority on read:
    1. TC_REFRESH_TOKEN env var (intended for CI / one-shot)
    2. OS keyring (default for interactive use)
    3. 0600 file at ~/.config/tc-cli/credentials (fallback when keyring is
       unavailable, e.g. headless Linux without a secret service)

Storage on write: keyring if available, otherwise 0600 file.
"""
from __future__ import annotations

import os
import stat
from pathlib import Path
from typing import Optional

KEYRING_SERVICE = "tc-cli"
KEYRING_USER = "default"

CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "tc-cli"
CRED_FILE = CONFIG_DIR / "credentials"
ENV_VAR = "TC_REFRESH_TOKEN"


class CredentialError(Exception):
    """Raised on storage policy violations (bad file mode, missing keyring)."""


def _keyring():
    try:
        import keyring  # type: ignore
        return keyring
    except Exception:
        return None


def load() -> Optional[str]:
    """Return the refresh credential, or None if absent. Raises on bad mode."""
    val = os.environ.get(ENV_VAR)
    if val:
        return val

    kr = _keyring()
    if kr is not None:
        try:
            v = kr.get_password(KEYRING_SERVICE, KEYRING_USER)
            if v:
                return v
        except Exception:
            # keyring backend may be present but unusable; fall through to file
            pass

    if CRED_FILE.exists():
        st = CRED_FILE.stat()
        if (st.st_mode & 0o777) != 0o600:
            raise CredentialError(
                f"{CRED_FILE} has insecure mode {oct(st.st_mode & 0o777)}; "
                "run `chmod 0600` on it or delete and re-login."
            )
        if hasattr(os, "geteuid") and st.st_uid != os.geteuid():
            raise CredentialError(
                f"{CRED_FILE} is not owned by the current user; refusing to load."
            )
        return CRED_FILE.read_text().strip() or None
    return None


def save(refresh_token: str) -> str:
    """Persist the refresh credential. Returns 'keyring' or path of file used."""
    kr = _keyring()
    if kr is not None:
        try:
            kr.set_password(KEYRING_SERVICE, KEYRING_USER, refresh_token)
            return "keyring"
        except Exception:
            pass

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    # Write atomically with strict mode from the start.
    tmp = CRED_FILE.with_suffix(".tmp")
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, refresh_token.encode())
    finally:
        os.close(fd)
    os.replace(str(tmp), str(CRED_FILE))
    return str(CRED_FILE)


def clear() -> None:
    kr = _keyring()
    if kr is not None:
        try:
            kr.delete_password(KEYRING_SERVICE, KEYRING_USER)
        except Exception:
            pass
    if CRED_FILE.exists():
        try:
            CRED_FILE.unlink()
        except Exception:
            pass
