"""--watch helper: re-poll a list endpoint and emit only new items.

Dedupe key is configurable per command (cluster_id, cve_id, victim_id, ...).
On Ctrl+C, exits cleanly.

Polling cadence default is 60s — high enough to be polite to the server,
low enough that an analyst keeping a tab open feels live.
"""
from __future__ import annotations

import json
import sys
import time
from typing import Any, Callable, Iterable


def watch_loop(
    *,
    fetch: Callable[[], Any],     # returns parsed response
    extract: Callable[[Any], Iterable[dict]],  # returns the items list
    dedupe_key: str,              # key on each item
    interval: float = 60.0,
) -> None:
    seen: set = set()
    first = True
    try:
        while True:
            try:
                resp = fetch()
                items = list(extract(resp) or [])
            except Exception as e:
                print(f"watch: fetch failed: {e}", file=sys.stderr)
                time.sleep(interval)
                continue

            new = [it for it in items if it.get(dedupe_key) not in seen]
            for it in items:
                key = it.get(dedupe_key)
                if key is not None:
                    seen.add(key)

            # First tick: emit nothing (just seed). Subsequent: emit new items only.
            if not first:
                for it in new:
                    json.dump(it, sys.stdout, default=str)
                    sys.stdout.write("\n")
                    sys.stdout.flush()
            first = False
            time.sleep(interval)
    except KeyboardInterrupt:
        sys.exit(0)
