"""JSON output. No table mode in v1 (plan §6 cuts)."""
import json
import sys
from typing import Any


def emit(data: Any) -> None:
    json.dump(data, sys.stdout, default=str, indent=2, sort_keys=True)
    sys.stdout.write("\n")
