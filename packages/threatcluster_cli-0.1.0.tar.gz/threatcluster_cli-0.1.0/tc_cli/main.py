"""tc — ThreatCluster CLI entrypoint."""
from __future__ import annotations

import os
import sys

import typer

from .client import CLIError, TCClient
from .commands import (
    auth as auth_cmd,
    cluster as cluster_cmd,
    darkweb as darkweb_cmd,
    entities as entities_cmd,
    feeds as feeds_cmd,
    iocs as iocs_cmd,
    search as search_cmd,
    threats as threats_cmd,
    vulns as vulns_cmd,
)

app = typer.Typer(
    no_args_is_help=True,
    add_completion=True,  # exposes --install-completion / --show-completion
    pretty_exceptions_enable=False,  # we handle our own; tracebacks leak detail
    help="Command-line client for ThreatCluster.",
)

app.add_typer(auth_cmd.app,     name="auth",     help="Authentication.")
app.add_typer(threats_cmd.app,  name="threats",  help="Threat clusters.")
app.add_typer(iocs_cmd.app,     name="iocs",     help="Indicators of Compromise.")
app.add_typer(entities_cmd.app, name="entities", help="Entities (actors, malware, tools).")
app.add_typer(vulns_cmd.app,    name="vulns",    help="Vulnerabilities (CVEs).")
app.add_typer(darkweb_cmd.app,  name="darkweb",  help="Dark web (ransomware, breaches, markets).")
app.add_typer(feeds_cmd.app,    name="feeds",    help="Custom intel feeds.")
app.add_typer(cluster_cmd.app,  name="cluster",  help="Analyst pivots: open cluster URLs, etc.")

# `tc search <query>` is a flat command, not a sub-group, so flags parse cleanly.
app.command("search", help="Smart search across threats + entities.")(search_cmd.search)


@app.callback()
def _root(
    ctx: typer.Context,
    api_key: str = typer.Option(
        None,
        "--api-key",
        hidden=True,
        help="REJECTED: pass refresh credential via TC_REFRESH_TOKEN env or `tc auth login`.",
    ),
):
    """Build a single TCClient and stash on ctx.obj."""
    if api_key is not None:
        # Refuse rather than silently use it — argv leaks via /proc/<pid>/cmdline.
        typer.secho(
            "--api-key is not supported (process-table leak). "
            "Set TC_REFRESH_TOKEN or run `tc auth login`.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(2)

    # Subprocess hygiene: by default, do not propagate auth env to children.
    if os.environ.get("TC_PROPAGATE_AUTH") != "1":
        for k in ("TC_REFRESH_TOKEN",):
            os.environ.pop(k + "_PROPAGATE", None)

    ctx.obj = {"client": None}  # client is built lazily by commands that need it


def _run() -> None:
    try:
        app()
    except CLIError as e:
        typer.secho(str(e), fg=typer.colors.RED, err=True)
        raise SystemExit(1)


if __name__ == "__main__":
    _run()
