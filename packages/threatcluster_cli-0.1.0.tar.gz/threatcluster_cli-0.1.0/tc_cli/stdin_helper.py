"""Stdin helpers for command chaining.

Convention: any command that takes a positional `id`/`identifier` accepts the
literal `-` to mean "read whitespace-separated ids from stdin." Each input is
yielded one at a time so the command can fan out.

Used like:
    tc threats list --json | jq -r '.threats[].cluster_id' | tc threats get -
"""
from __future__ import annotations

import sys
from typing import Iterable


def expand_id(arg: str) -> Iterable[str]:
    """Yield ids: a single literal, or many from stdin if arg == '-'.

    For multi-id stdin we strip JSON quoting and ignore blanks/comments.
    """
    if arg != "-":
        yield arg
        return
    if sys.stdin.isatty():
        # Friendlier than waiting silently for input.
        raise SystemExit(
            "error: '-' was given but stdin is a TTY. "
            "Pipe ids in, e.g. `echo cluster-uuid | tc threats get -`."
        )
    for raw in sys.stdin.read().splitlines():
        line = raw.strip().strip('",[] ')
        if not line or line.startswith("#"):
            continue
        yield line
