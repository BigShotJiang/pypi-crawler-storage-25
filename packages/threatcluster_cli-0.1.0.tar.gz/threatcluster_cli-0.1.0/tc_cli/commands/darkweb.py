"""tc darkweb — ransomware, breaches, keyword-hits."""
from __future__ import annotations

from typing import Optional

import typer

from ..context import client as _client
from ..output import emit

app = typer.Typer(no_args_is_help=True, add_completion=False)

ransomware = typer.Typer(no_args_is_help=True, add_completion=False)
app.add_typer(ransomware, name="ransomware")


@ransomware.command("victims")
def ransomware_victims(
    ctx: typer.Context,
    group: Optional[str] = typer.Option(None, "--group", help="Filter by ransomware group (e.g. lockbit, akira)."),
    days: int = typer.Option(30, "--days", min=1, max=90),
    limit: int = typer.Option(50, "--limit", "-n", min=1, max=500),
    watch: bool = typer.Option(False, "--watch", help="Poll forever and emit new victims as NDJSON."),
    interval: float = typer.Option(60.0, "--interval"),
) -> None:
    """List ransomware victims. Use --watch for a live feed."""
    params: dict = {"limit": limit, "days": days}
    if group: params["group"] = group
    c = _client(ctx)
    if watch:
        from ..watch import watch_loop
        watch_loop(
            fetch=lambda: c.get("/api/public/v1/darkweb/ransomware/victims", params=params),
            extract=lambda r: r.get("victims") or [],
            dedupe_key="id",
            interval=interval,
        )
        return
    emit(c.get("/api/public/v1/darkweb/ransomware/victims", params=params))


@app.command("breaches")
def breaches(
    ctx: typer.Context,
    since: Optional[str] = typer.Option(None, "--since"),
    watch: bool = typer.Option(False, "--watch", help="Poll forever and emit new breaches as NDJSON."),
    interval: float = typer.Option(60.0, "--interval"),
) -> None:
    """List dark-web breaches. Use --watch for a live feed."""
    params: dict = {}
    if since: params["since"] = since
    c = _client(ctx)
    if watch:
        from ..watch import watch_loop
        watch_loop(
            fetch=lambda: c.get("/api/public/v1/darkweb/breaches", params=params),
            extract=lambda r: r.get("breaches") or [],
            dedupe_key="id",
            interval=interval,
        )
        return
    emit(c.get("/api/public/v1/darkweb/breaches", params=params))


@app.command("keyword-hits")
def keyword_hits(ctx: typer.Context) -> None:
    emit(_client(ctx).get("/api/public/v1/darkweb/keyword-hits"))
