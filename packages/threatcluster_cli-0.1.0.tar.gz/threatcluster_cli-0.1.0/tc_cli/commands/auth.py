"""tc auth — login, status, logout.

v1 login flow is paste-token: the user mints an agent key in the web UI
(Settings -> API keys -> "Mint agent key"), copies it once, and pastes it
here. The CLI stores it in keyring (or a 0600 file), validates it by
minting one bearer, and is ready to use.

We deliberately avoid implementing the Auth0 device-code flow until the
server-side endpoints for it are wired and tested — see plan §2.
"""
from __future__ import annotations

import os
import sys

import typer

from .. import credentials
from ..client import CLIError, TCClient
from ..output import emit

app = typer.Typer(no_args_is_help=True, add_completion=False)


@app.command("login")
def login(
    paste: bool = typer.Option(
        True,
        "--paste/--no-paste",
        help="Paste a refresh credential minted from the web UI.",
    ),
) -> None:
    """Store a refresh credential for future commands."""
    if not paste:
        raise typer.BadParameter("--no-paste login is not implemented in v1.")

    typer.echo(
        "1. Visit https://threatcluster.io/settings?tab=cli\n"
        "2. Click \"Mint key\", choose scopes, copy the key.\n"
        "3. Paste it below (input hidden).",
        err=True,
    )
    token = typer.prompt("refresh token", hide_input=True, err=True)
    token = token.strip()
    if not (token.startswith("tc_agent_") or token.startswith("tc_live_")):
        typer.secho(
            "rejected: token must start with 'tc_agent_' or 'tc_live_'.",
            fg=typer.colors.RED, err=True,
        )
        raise typer.Exit(2)

    # Validate by minting one bearer.
    client = TCClient()
    client.set_refresh(token)
    try:
        client._mint_bearer()  # raises CLIError on failure
    except CLIError as e:
        typer.secho(f"validation failed: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    where = credentials.save(token)
    typer.secho(f"saved to {where}.", fg=typer.colors.GREEN, err=True)


def _decode_bearer_claims(bearer: str) -> dict:
    import base64, json as _json
    payload_b64 = bearer.split(".")[1]
    padded = payload_b64 + "=" * (-len(payload_b64) % 4)
    return _json.loads(base64.urlsafe_b64decode(padded))


@app.command("status")
def status(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Include storage backend details and bearer cache state."),
) -> None:
    """Show current credential status (no secret values printed)."""
    try:
        token = credentials.load()
    except credentials.CredentialError as e:
        typer.secho(str(e), fg=typer.colors.RED, err=True)
        raise typer.Exit(2)

    if not token:
        emit({"authenticated": False})
        return

    client = TCClient()
    client.set_refresh(token)
    bearer = client._mint_bearer()
    claims = _decode_bearer_claims(bearer)

    out = {
        "authenticated": True,
        "storage": "env" if os.environ.get(credentials.ENV_VAR) else "keyring_or_file",
        "token_prefix": token[:12] + "…",
        "key_id": claims.get("kid"),
        "scopes": claims.get("scopes", []),
        "org_id": claims.get("org_id"),
        "org_name": claims.get("org_name"),
        "bearer_expires_in": claims.get("exp", 0) - claims.get("iat", 0),
        "api_url": client.base,
    }

    if verbose:
        # Storage detail — best-effort; some keyring backends expose name.
        backend = "env" if os.environ.get(credentials.ENV_VAR) else None
        if backend is None:
            kr = credentials._keyring()
            if kr is not None:
                try:
                    backend = f"keyring:{type(kr.get_keyring()).__name__}"
                except Exception:
                    backend = "keyring:unknown"
            else:
                backend = f"file:{credentials.CRED_FILE}"
        out["storage_detail"] = backend
        out["bearer_jti"] = claims.get("jti")
        out["bearer_session_id"] = claims.get("session_id")
        out["bearer_max_requests"] = claims.get("max_requests")

    emit(out)


@app.command("logout")
def logout(
    keep_remote: bool = typer.Option(
        False, "--keep-remote",
        help="Clear local credential only; leave the key valid server-side.",
    ),
) -> None:
    """Revoke the credential server-side and clear local storage.

    Default: hard logout — the credential dies everywhere. Pass --keep-remote
    if you only want to clear this machine (e.g. you're moving the key).
    """
    try:
        token = credentials.load()
    except credentials.CredentialError:
        token = None

    revoked = None
    if token and not keep_remote:
        client = TCClient()
        client.set_refresh(token)
        try:
            client.post("/api/auth/agent/self-revoke")
            revoked = True
        except CLIError as e:
            typer.secho(f"server-side revoke failed: {e}", fg=typer.colors.YELLOW, err=True)
            revoked = False

    credentials.clear()
    msg = "local credential cleared"
    if revoked is True:
        msg += "; server-side revoked"
    elif revoked is False:
        msg += "; server-side revoke FAILED — revoke at https://threatcluster.io/settings?tab=cli"
    elif keep_remote:
        msg += " (--keep-remote: server-side credential still valid)"
    typer.secho(msg, fg=typer.colors.GREEN if revoked is not False else typer.colors.YELLOW, err=True)
