"""tc iocs — feed, export."""
from __future__ import annotations

from typing import Optional

import typer

from ..context import client as _client
from ..output import emit

app = typer.Typer(no_args_is_help=True, add_completion=False)


@app.command("feed")
def ioc_feed(
    ctx: typer.Context,
    type: Optional[str] = typer.Option(None, "--type", help="ip, domain, sha256, url, ..."),
    since: Optional[str] = typer.Option(None, "--since"),
) -> None:
    """Stream IOC feed. Server returns one IOC per line as text/plain."""
    params: dict = {}
    if type: params["type"] = type
    if since: params["since"] = since
    result = _client(ctx).get("/api/public/v1/iocs/feed", params=params)
    # Endpoint returns text/plain (one IOC per line). Print raw, not JSON.
    if isinstance(result, str):
        import sys; sys.stdout.write(result if result.endswith("\n") else result + "\n")
    else:
        emit(result)


@app.command("export")
def ioc_export(
    ctx: typer.Context,
    fmt: str = typer.Option("json", "--format", help="json, csv, stix"),
) -> None:
    result = _client(ctx).get("/api/public/v1/iocs/export", params={"format": fmt})
    if isinstance(result, str):
        import sys; sys.stdout.write(result if result.endswith("\n") else result + "\n")
    else:
        emit(result)
