"""tc feeds — list, get."""
from __future__ import annotations

import typer

from ..context import client as _client
from ..output import emit
from ..stdin_helper import expand_id

app = typer.Typer(no_args_is_help=True, add_completion=False)


@app.command("list")
def feeds_list(ctx: typer.Context) -> None:
    emit(_client(ctx).get("/api/public/v1/feeds"))


@app.command("get")
def feeds_get(ctx: typer.Context, feed_id: str) -> None:
    """Get a feed's entities. Pass `-` to read feed ids from stdin."""
    c = _client(ctx)
    for fid in expand_id(feed_id):
        emit(c.get(f"/api/public/v1/feeds/{fid}/entities"))
