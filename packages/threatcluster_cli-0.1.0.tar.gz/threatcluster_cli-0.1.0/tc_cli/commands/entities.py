"""tc entities — search, get, related, trending."""
from __future__ import annotations

from typing import Optional

import typer

from ..context import client as _client
from ..output import emit

app = typer.Typer(no_args_is_help=True, add_completion=False)


@app.command("search")
def entities_search(
    ctx: typer.Context,
    query: str,
    type: Optional[str] = typer.Option(None, "--type"),
) -> None:
    params = {"q": query}
    if type: params["type"] = type
    emit(_client(ctx).get("/api/public/v1/entities/search", params=params))


@app.command("get")
def entities_get(ctx: typer.Context, type: str, value: str) -> None:
    emit(_client(ctx).get(f"/api/public/v1/entities/{type}/{value}"))


@app.command("related")
def entities_related(ctx: typer.Context, type: str, value: str) -> None:
    emit(_client(ctx).get(f"/api/public/v1/entities/{type}/{value}/related"))


@app.command("trending")
def entities_trending(
    ctx: typer.Context,
    window: str = typer.Option("24h", "--window"),
) -> None:
    emit(_client(ctx).get("/api/public/v1/entities/trending",
                                  params={"window": window}))
