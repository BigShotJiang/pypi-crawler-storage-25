"""tc cluster — analyst-pivot helpers.

Today: `tc cluster open <id>` prints (and optionally opens) the web URL.
Future: `tc cluster timeline`, `tc cluster compare`, etc.
"""
from __future__ import annotations

import os
import subprocess
import sys

import typer

from ..stdin_helper import expand_id

app = typer.Typer(no_args_is_help=True, add_completion=False)


def _web_base() -> str:
    api = os.environ.get("TC_API_URL", "https://api.threatcluster.io").rstrip("/")
    # Convention: web frontend is the same origin minus an `api.` subdomain.
    if "://api." in api:
        return api.replace("://api.", "://", 1)
    return api  # local dev (http://localhost:8000) serves both


@app.command("open")
def cluster_open(
    identifier: str,
    no_browser: bool = typer.Option(False, "--no-browser", help="Print URL only, don't open."),
) -> None:
    """Print (and open) the web URL for a cluster. Pass `-` for stdin ids."""
    base = _web_base()
    for ident in expand_id(identifier):
        url = f"{base}/threat/{ident}"
        print(url)
        if no_browser:
            continue
        # Best-effort opener; silent if not available (CI, headless).
        for opener in ("xdg-open", "open"):
            try:
                subprocess.Popen(
                    [opener, url],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                )
                break
            except FileNotFoundError:
                continue
