"""tc threats — list, get, iocs, stix."""
from __future__ import annotations

from typing import Optional

import typer

from ..context import client as _client
from ..output import emit
from ..stdin_helper import expand_id

app = typer.Typer(no_args_is_help=True, add_completion=False)


@app.command("list")
def list_threats(
    ctx: typer.Context,
    query: Optional[str] = typer.Option(None, "--query", "-q"),
    since: Optional[str] = typer.Option(None, "--since", help="ISO date or relative (e.g. 24h)"),
    limit: int = typer.Option(20, "--limit", "-n", min=1, max=200),
    watch: bool = typer.Option(False, "--watch", help="Poll forever and emit new clusters as NDJSON."),
    interval: float = typer.Option(60.0, "--interval", help="Watch poll interval (seconds)."),
) -> None:
    """List threat clusters."""
    params: dict = {"limit": limit}
    if query: params["keyword"] = query
    if since: params["since"] = since
    c = _client(ctx)
    if watch:
        from ..watch import watch_loop
        watch_loop(
            fetch=lambda: c.get("/api/public/v1/threats", params=params),
            extract=lambda r: r.get("threats") or [],
            dedupe_key="cluster_id",
            interval=interval,
        )
        return
    emit(c.get("/api/public/v1/threats", params=params))


@app.command("get")
def get_threat(ctx: typer.Context, identifier: str) -> None:
    """Get one threat cluster by id or short_id. Pass `-` to read ids from stdin."""
    c = _client(ctx)
    for ident in expand_id(identifier):
        emit(c.get(f"/api/public/v1/threats/{ident}"))


@app.command("iocs")
def threat_iocs(
    ctx: typer.Context,
    identifier: str,
    types: str = typer.Option("all", "--types"),
    fmt: str = typer.Option("json", "--format"),
) -> None:
    """List IOCs for a threat cluster. Pass `-` to read ids from stdin."""
    c = _client(ctx)
    for ident in expand_id(identifier):
        emit(c.get(
            f"/api/public/v1/threats/{ident}/iocs",
            params={"types": types, "format": fmt},
        ))


@app.command("stix")
def threat_stix(ctx: typer.Context, identifier: str) -> None:
    """STIX 2.1 export. Pass `-` to read ids from stdin."""
    import sys
    c = _client(ctx)
    for ident in expand_id(identifier):
        result = c.get(f"/api/public/v1/threats/{ident}/stix")
        if isinstance(result, str):
            sys.stdout.write(result if result.endswith("\n") else result + "\n")
        else:
            emit(result)
