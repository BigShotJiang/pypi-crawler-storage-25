"""tc search — smart router across entities + threats.

Single command (no sub-commands) so flags like --limit parse cleanly.
"""
from __future__ import annotations

from typing import Optional

import typer

from ..context import client as _client
from ..output import emit

# A bare Typer with one default callback is the cleanest "command with args"
# shape that still composes via add_typer in main.py.
app = typer.Typer(no_args_is_help=False, add_completion=False)


def search(
    ctx: typer.Context,
    query: str = typer.Argument(..., help="Search term."),
    limit: int = typer.Option(10, "--limit", "-n", min=1, max=100),
    only: Optional[str] = typer.Option(
        None, "--only",
        help="Restrict to one source: entities | threats",
    ),
) -> None:
    """Search threats and entities, merged. Use `--only entities|threats` to narrow."""
    c = _client(ctx)
    out: list = []

    if only in (None, "entities"):
        try:
            r = c.get("/api/public/v1/entities/search", params={"q": query})
            for e in (r.get("entities") or r.get("results") or []):
                out.append({
                    "kind": "entity",
                    "type": e.get("entity_type") or e.get("type") or e.get("category"),
                    "value": e.get("entity_value") or e.get("value") or e.get("name"),
                    "score": e.get("score") or e.get("relevance") or e.get("article_count"),
                    "raw": e,
                })
        except Exception as e:
            out.append({"kind": "error", "source": "entities", "message": str(e)})

    if only in (None, "threats"):
        try:
            r = c.get("/api/public/v1/threats", params={"keyword": query, "limit": limit})
            for t in (r.get("threats") or []):
                out.append({
                    "kind": "threat",
                    "id": t.get("cluster_id"),
                    "title": t.get("ai_title") or t.get("title"),
                    "score": t.get("threat_score"),
                    "summary": (t.get("ai_summary") or "")[:200],
                })
        except Exception as e:
            out.append({"kind": "error", "source": "threats", "message": str(e)})

    out = out[:limit]
    emit({"query": query, "count": len(out), "results": out})
