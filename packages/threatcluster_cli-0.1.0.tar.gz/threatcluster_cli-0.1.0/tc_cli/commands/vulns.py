"""tc vulns — list, get."""
from __future__ import annotations

from typing import Optional

import typer

from ..context import client as _client
from ..output import emit
from ..stdin_helper import expand_id

app = typer.Typer(no_args_is_help=True, add_completion=False)


@app.command("list")
def vulns_list(
    ctx: typer.Context,
    severity: Optional[str] = typer.Option(None, "--severity"),
    since: Optional[str] = typer.Option(None, "--since"),
    limit: int = typer.Option(20, "--limit", "-n", min=1, max=200),
    watch: bool = typer.Option(False, "--watch", help="Poll forever and emit new CVEs as NDJSON."),
    interval: float = typer.Option(120.0, "--interval", help="CVE feed updates slowly; default 2 min."),
) -> None:
    """List CVEs. Use --watch for a live feed."""
    params: dict = {"limit": limit}
    if severity: params["severity"] = severity
    if since: params["since"] = since
    c = _client(ctx)
    if watch:
        from ..watch import watch_loop
        watch_loop(
            fetch=lambda: c.get("/api/public/v1/vulnerabilities", params=params),
            extract=lambda r: r.get("cves") or [],
            dedupe_key="cve_id",
            interval=interval,
        )
        return
    emit(c.get("/api/public/v1/vulnerabilities", params=params))


@app.command("get")
def vulns_get(ctx: typer.Context, cve_id: str) -> None:
    """Get one CVE. Pass `-` to read CVE ids from stdin."""
    c = _client(ctx)
    for cid in expand_id(cve_id):
        emit(c.get(f"/api/public/v1/vulnerabilities/{cid}"))
