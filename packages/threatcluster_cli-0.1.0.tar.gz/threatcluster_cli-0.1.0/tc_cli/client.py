"""HTTP client for threatcluster-cli (the `tc` command).

Responsibilities:
  - Resolve API base URL; refuse plaintext to non-loopback hosts.
  - Mint a bearer JWT from the refresh credential and cache it in-process
    until ~30s before expiry.
  - Send Authorization: Bearer on data calls.
  - Strip auth headers from any logged request.
  - Reject the --api-key flag (callers must use env / keyring / file).
"""
from __future__ import annotations

import base64
import json
import logging
import os
import sys
import time
from typing import Any, Optional
from urllib.parse import urlparse

import httpx

from . import credentials

logger = logging.getLogger("tc_cli")

DEFAULT_BASE = "https://api.threatcluster.io"

# Headers we never want to see in logs.
_REDACT_HEADERS = {"authorization", "x-api-key"}


class CLIError(Exception):
    """Surface a clean error message to the user without a traceback."""


def _is_loopback(host: str) -> bool:
    return host in {"localhost", "127.0.0.1", "::1"}


def _resolve_base() -> str:
    base = os.environ.get("TC_API_URL", DEFAULT_BASE).rstrip("/")
    parsed = urlparse(base)
    if parsed.scheme == "http" and not _is_loopback(parsed.hostname or ""):
        raise CLIError(
            f"refusing plaintext HTTP to non-loopback host: {base!r}. "
            "Use https:// or set TC_API_URL=http://127.0.0.1:..."
        )
    if parsed.scheme not in {"http", "https"}:
        raise CLIError(f"TC_API_URL must be http(s): {base!r}")
    return base


def _redact_request_for_log(request: httpx.Request) -> dict:
    headers = {
        k: ("<redacted>" if k.lower() in _REDACT_HEADERS else v)
        for k, v in request.headers.items()
    }
    return {"method": request.method, "url": str(request.url), "headers": headers}


def _decode_bearer_exp(token: str) -> int:
    """Pull `exp` out of a JWT without verifying signature. Used only for
    cache TTL — the server is the only authority on validity."""
    try:
        payload_b64 = token.split(".")[1]
        # JWT base64url, no padding
        padded = payload_b64 + "=" * (-len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded))
        return int(payload.get("exp", 0))
    except Exception:
        return 0


class TCClient:
    """Synchronous httpx wrapper. One per process."""

    def __init__(self, base: Optional[str] = None) -> None:
        self.base = base or _resolve_base()
        self._refresh: Optional[str] = None
        self._bearer: Optional[str] = None
        self._bearer_exp: int = 0
        # Strict TLS: system trust store. No pinning (plan §6).
        self._http = httpx.Client(timeout=30.0, follow_redirects=False)

    # -- credential plumbing -------------------------------------------------

    def _get_refresh(self) -> str:
        if self._refresh:
            return self._refresh
        token = credentials.load()
        if not token:
            raise CLIError(
                "no refresh credential — run `tc auth login` first."
            )
        self._refresh = token
        return token

    def set_refresh(self, token: str) -> None:
        self._refresh = token
        self._bearer = None
        self._bearer_exp = 0

    # -- bearer mint ---------------------------------------------------------

    def _mint_bearer(self) -> str:
        refresh = self._get_refresh()
        body: dict[str, Any] = {}
        scope_override = os.environ.get("TC_SCOPES")
        if scope_override:
            body["scopes"] = [s.strip() for s in scope_override.split(",") if s.strip()]
        if os.environ.get("TC_SESSION_ID"):
            body["session_id"] = os.environ["TC_SESSION_ID"]
        if os.environ.get("TC_MAX_REQUESTS"):
            try:
                body["max_requests"] = int(os.environ["TC_MAX_REQUESTS"])
            except ValueError:
                raise CLIError("TC_MAX_REQUESTS must be an integer")

        try:
            resp = self._http.post(
                f"{self.base}/api/auth/agent/token",
                headers={"X-API-Key": refresh, "Content-Type": "application/json"},
                content=json.dumps(body),
            )
        except httpx.ConnectError as e:
            raise CLIError(
                f"could not reach {self.base}: {e}. "
                "Set TC_API_URL to your backend (e.g. http://localhost:8000)."
            )
        except httpx.TimeoutException as e:
            raise CLIError(f"timed out contacting {self.base}: {e}")
        except httpx.RequestError as e:
            raise CLIError(f"network error contacting {self.base}: {e}")
        if resp.status_code != 200:
            raise CLIError(self._format_error(resp))
        token = resp.json()["access_token"]
        self._bearer = token
        self._bearer_exp = _decode_bearer_exp(token)
        return token

    def _bearer_is_fresh(self) -> bool:
        if not self._bearer:
            return False
        # Refresh ~30s early so we don't race the server clock.
        return self._bearer_exp - int(time.time()) > 30

    def _bearer_token(self) -> str:
        if self._bearer_is_fresh():
            return self._bearer  # type: ignore[return-value]
        return self._mint_bearer()

    # -- error formatting ----------------------------------------------------

    @staticmethod
    def _format_error(resp: httpx.Response) -> str:
        try:
            j = resp.json()
            detail = j.get("detail", j)
            if isinstance(detail, dict):
                msg = detail.get("message") or detail.get("error") or str(detail)
                return f"HTTP {resp.status_code}: {msg}"
            return f"HTTP {resp.status_code}: {detail}"
        except Exception:
            return f"HTTP {resp.status_code}: {resp.text[:200]}"

    # -- request -------------------------------------------------------------

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict] = None,
        json_body: Optional[dict] = None,
        auth: bool = True,
    ) -> Any:
        url = f"{self.base}{path}"
        headers = {"Accept": "application/json"}
        if auth:
            headers["Authorization"] = f"Bearer {self._bearer_token()}"
        if json_body is not None:
            headers["Content-Type"] = "application/json"

        if os.environ.get("TC_DEBUG") == "1":
            req = self._http.build_request(method, url, params=params, headers=headers,
                                           content=json.dumps(json_body) if json_body is not None else None)
            print(json.dumps(_redact_request_for_log(req)), file=sys.stderr)

        try:
            resp = self._http.request(
                method, url,
                params=params, headers=headers,
                content=json.dumps(json_body) if json_body is not None else None,
            )
            # Bearer expired between cache refresh and request — mint once and retry.
            if resp.status_code == 401 and auth:
                self._bearer = None
                self._bearer_exp = 0
                headers["Authorization"] = f"Bearer {self._bearer_token()}"
                resp = self._http.request(
                    method, url,
                    params=params, headers=headers,
                    content=json.dumps(json_body) if json_body is not None else None,
                )
        except httpx.ConnectError as e:
            raise CLIError(
                f"could not reach {self.base}: {e}. "
                "Set TC_API_URL to your backend (e.g. http://localhost:8000)."
            )
        except httpx.TimeoutException as e:
            raise CLIError(f"timed out contacting {self.base}: {e}")
        except httpx.RequestError as e:
            raise CLIError(f"network error contacting {self.base}: {e}")

        if resp.status_code >= 400:
            raise CLIError(self._format_error(resp))
        if resp.headers.get("content-type", "").startswith("application/json"):
            return resp.json()
        return resp.text

    def get(self, path: str, **kw):  return self.request("GET",  path, **kw)
    def post(self, path: str, **kw): return self.request("POST", path, **kw)
    def delete(self, path: str, **kw): return self.request("DELETE", path, **kw)
