"""Helper for command modules to lazily fetch the shared TCClient.

Lives in its own module to avoid circular imports between main.py and
the command modules.
"""
from __future__ import annotations

import typer

from .client import TCClient


def client(ctx: typer.Context) -> TCClient:
    if ctx.obj.get("client") is None:
        ctx.obj["client"] = TCClient()
    return ctx.obj["client"]
