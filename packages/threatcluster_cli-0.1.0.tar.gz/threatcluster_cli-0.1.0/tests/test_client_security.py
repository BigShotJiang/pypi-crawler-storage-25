"""Plaintext rejection, log redaction, --api-key flag rejection."""
from __future__ import annotations

import io
import os
import sys

import pytest
import typer
from typer.testing import CliRunner

from tc_cli import client as client_mod
from tc_cli.client import CLIError, TCClient, _redact_request_for_log


def test_plaintext_to_non_loopback_rejected(monkeypatch):
    monkeypatch.setenv("TC_API_URL", "http://example.com")
    with pytest.raises(CLIError) as exc:
        TCClient()
    assert "plaintext" in str(exc.value).lower()


def test_plaintext_to_loopback_allowed(monkeypatch):
    monkeypatch.setenv("TC_API_URL", "http://127.0.0.1:8000")
    c = TCClient()
    assert c.base == "http://127.0.0.1:8000"


def test_https_to_anywhere_allowed(monkeypatch):
    monkeypatch.setenv("TC_API_URL", "https://api.threatcluster.io")
    c = TCClient()
    assert c.base == "https://api.threatcluster.io"


def test_log_redaction_strips_authorization():
    import httpx
    req = httpx.Request(
        "GET",
        "https://example.com/x",
        headers={
            "Authorization": "Bearer SECRET_TOKEN_NEVER_LOG",
            "X-API-Key": "tc_agent_NEVER_LOG",
            "Accept": "application/json",
        },
    )
    redacted = _redact_request_for_log(req)
    assert "SECRET_TOKEN_NEVER_LOG" not in str(redacted)
    assert "tc_agent_NEVER_LOG" not in str(redacted)
    assert redacted["headers"]["accept"] == "application/json"


def test_api_key_flag_rejected(monkeypatch):
    """--api-key on argv must be refused (process-table leak)."""
    from tc_cli.main import app
    runner = CliRunner()
    result = runner.invoke(app, ["--api-key", "tc_agent_secret", "threats", "list"])
    assert result.exit_code != 0
    # Stdout/stderr both safe to check — secret value should not appear.
    combined = (result.output or "") + (result.stderr or "" if hasattr(result, "stderr") else "")
    assert "tc_agent_secret" not in combined


def test_invalid_scheme_rejected(monkeypatch):
    monkeypatch.setenv("TC_API_URL", "ftp://example.com")
    with pytest.raises(CLIError):
        TCClient()
