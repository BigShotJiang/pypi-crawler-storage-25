import os
import sys
from pathlib import Path

# Make the in-tree package importable without `pip install -e`.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Some env vars must be set BEFORE tc_cli imports anything that reads them.
os.environ.setdefault("TC_API_URL", "http://127.0.0.1:8000")
