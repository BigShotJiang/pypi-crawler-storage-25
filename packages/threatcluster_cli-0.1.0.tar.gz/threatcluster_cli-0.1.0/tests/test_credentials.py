"""File-permission and storage-policy tests for credential storage."""
from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from tc_cli import credentials


@pytest.fixture
def tmp_config(monkeypatch, tmp_path):
    """Redirect XDG_CONFIG_HOME to a tmpdir; force keyring-unavailable."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    # Re-import constants under the new env.
    monkeypatch.setattr(credentials, "CONFIG_DIR", tmp_path / "tc-cli")
    monkeypatch.setattr(credentials, "CRED_FILE", tmp_path / "tc-cli" / "credentials")
    # Force file-fallback path.
    monkeypatch.setattr(credentials, "_keyring", lambda: None)
    monkeypatch.delenv(credentials.ENV_VAR, raising=False)
    return tmp_path / "tc-cli" / "credentials"


def test_save_writes_0600(tmp_config):
    path_used = credentials.save("tc_agent_xxxxxxxxxxxxxxxxxxxx")
    p = Path(path_used)
    assert p.exists()
    mode = stat.S_IMODE(p.stat().st_mode)
    assert mode == 0o600, f"expected 0o600, got {oct(mode)}"


def test_load_round_trip(tmp_config):
    credentials.save("tc_agent_xxxxxxxxxxxxxxxxxxxx")
    assert credentials.load() == "tc_agent_xxxxxxxxxxxxxxxxxxxx"


def test_load_refuses_loose_mode(tmp_config):
    credentials.save("tc_agent_xxxxxxxxxxxxxxxxxxxx")
    p = tmp_config
    os.chmod(p, 0o644)
    with pytest.raises(credentials.CredentialError) as exc:
        credentials.load()
    assert "0o644" in str(exc.value) or "insecure" in str(exc.value)


def test_env_overrides_file(tmp_config, monkeypatch):
    credentials.save("tc_agent_FROMFILE___________________")
    monkeypatch.setenv(credentials.ENV_VAR, "tc_agent_FROMENV____________________")
    assert credentials.load() == "tc_agent_FROMENV____________________"


def test_clear_removes_file(tmp_config):
    credentials.save("tc_agent_xxxxxxxxxxxxxxxxxxxx")
    credentials.clear()
    assert not Path(tmp_config).exists()
