"""
:mod:`tests.meta.test_m_installer_docs` module.

Guardrails for supported installer documentation and release smoke coverage.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import pytest

from tests.meta.pytest_meta_support import REPO_ROOT
from tests.meta.pytest_meta_support import TextSnippetCase
from tests.meta.pytest_meta_support import text_snippet_case_id

# SECTION: CONSTANTS ======================================================== #


README_PATH = REPO_ROOT / 'README.md'
RELEASE_CHECKLIST_PATH = REPO_ROOT / 'RELEASE-CHECKLIST.md'
COMPATIBILITY_PATH = REPO_ROOT / 'docs/source/getting-started/compatibility.md'

CI_WORKFLOW_PATH = REPO_ROOT / '.github/workflows/ci.yml'
INSTALLER_SMOKE_ACTION_PATH = REPO_ROOT / '.github/actions/installer-smoke/action.yml'

CONDA_STATUS_DOC_PATHS = (
    README_PATH,
    COMPATIBILITY_PATH,
    RELEASE_CHECKLIST_PATH,
)

CROSS_PLATFORM_SMOKE_SNIPPETS = (
    'os: [macos-latest, windows-latest]',
    'etlplus --version',
    'etlplus --help',
    'etlplus check --help',
)
CONDA_STATUS_SNIPPETS = (
    'conda-forge',
    'tagged',
    'published',
)

# SECTION: SUPPORT ========================================================== #


@dataclass(frozen=True, slots=True)
class InstallerContract:
    """Documented installer command and matching smoke-action pattern."""

    name: str
    docs_command: str
    smoke_pattern: re.Pattern[str]


INSTALLER_CONTRACTS = (
    InstallerContract(
        name='pip',
        docs_command='pip install etlplus',
        smoke_pattern=re.compile(r'-m pip install \$\{\{ inputs\.artifact-wheel \}\}'),
    ),
    InstallerContract(
        name='pipx',
        docs_command='pipx install etlplus',
        smoke_pattern=re.compile(r'-m pipx install \$\{\{ inputs\.artifact-wheel \}\}'),
    ),
    InstallerContract(
        name='uv',
        docs_command='uv tool install etlplus',
        smoke_pattern=re.compile(
            r'uv tool install --force \$\{\{ inputs\.artifact-wheel \}\}',
        ),
    ),
)
INSTALLER_CONTRACT_IDS = [contract.name for contract in INSTALLER_CONTRACTS]

CONDA_STATUS_CASES: tuple[TextSnippetCase, ...] = tuple(
    (path, snippet)
    for path in CONDA_STATUS_DOC_PATHS
    for snippet in CONDA_STATUS_SNIPPETS
)


# SECTION: FIXTURES ========================================================= #


@pytest.fixture(name='compatibility_text', scope='module')
def compatibility_text_fixture() -> str:
    """Return the published compatibility page source."""
    return COMPATIBILITY_PATH.read_text(encoding='utf-8')


@pytest.fixture(name='installer_smoke_action_text', scope='module')
def installer_smoke_action_text_fixture() -> str:
    """Return the supported installer smoke action source."""
    return INSTALLER_SMOKE_ACTION_PATH.read_text(encoding='utf-8')


@pytest.fixture(name='readme_text', scope='module')
def readme_text_fixture() -> str:
    """Return the repository README text."""
    return README_PATH.read_text(encoding='utf-8')


# SECTION: TESTS ============================================================ #


@pytest.mark.parametrize(
    ('path', 'snippet'),
    CONDA_STATUS_CASES,
    ids=[text_snippet_case_id(case) for case in CONDA_STATUS_CASES],
)
def test_conda_status_is_documented_as_validated_but_unpublished(
    path: Path,
    snippet: str,
) -> None:
    """
    Test that conda packaging is documented as support-gate validated without
    claiming user-facing install availability before feedstock publication.
    """
    normalized_text = path.read_text(encoding='utf-8').lower()

    assert snippet in normalized_text


@pytest.mark.parametrize('snippet', CROSS_PLATFORM_SMOKE_SNIPPETS)
def test_cross_platform_smoke_checks_cli_help_surfaces(snippet: str) -> None:
    """Test macOS/Windows smoke coverage checks stable CLI help surfaces."""
    workflow_text = CI_WORKFLOW_PATH.read_text(encoding='utf-8')

    assert snippet in workflow_text


def test_installer_smoke_resolves_tool_installer_entrypoint_from_path(
    installer_smoke_action_text: str,
) -> None:
    """
    Test that tool-installer smoke checks do not assume a fixed app-bin path.
    """
    assert '$HOME/.local/bin/etlplus' not in installer_smoke_action_text
    assert 'etlplus_bin="$(command -v etlplus)"' in installer_smoke_action_text


@pytest.mark.parametrize(
    'contract',
    INSTALLER_CONTRACTS,
    ids=INSTALLER_CONTRACT_IDS,
)
def test_supported_installer_commands_are_documented_and_smoke_tested(
    contract: InstallerContract,
    readme_text: str,
    compatibility_text: str,
    installer_smoke_action_text: str,
) -> None:
    """
    Test that supported installer commands stay aligned with release smoke
    coverage.
    """
    assert contract.docs_command in readme_text
    assert contract.docs_command in compatibility_text
    assert contract.smoke_pattern.search(installer_smoke_action_text) is not None
