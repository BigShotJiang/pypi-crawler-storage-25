# SPDX-License-Identifier: Apache-2.0
"""serve module — implementation lands in spec harbor-serve-and-bosun."""

from __future__ import annotations

__all__: list[str] = []
