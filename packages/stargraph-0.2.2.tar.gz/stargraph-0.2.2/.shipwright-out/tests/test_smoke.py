# SPDX-License-Identifier: Apache-2.0
"""Auto-generated smoke test for the generated_graph graph."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.mark.integration
def test_smoke() -> None:
    # Smoke: import the State to confirm the module loads.
    from state import State

    assert State() is not None
