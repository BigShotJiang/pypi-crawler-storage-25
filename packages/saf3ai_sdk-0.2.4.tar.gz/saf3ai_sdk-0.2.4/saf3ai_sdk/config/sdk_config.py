"""
SDK Configuration dataclass for Saf3AI SDK initialization.

This module provides a configuration object to reduce the number of parameters
passed to the init() function.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Union


@dataclass
class SDKConfig:
    """SDK configuration object for initializing the Saf3AI SDK."""
    
    # Required parameters
    agent_id: str
    api_key: str
    safeai_collector_agent: str
    
    # Optional parameters with defaults
    service_name: Optional[str] = None
    api_key_header_name: Optional[str] = None
    environment: Optional[str] = None
    safeai_collector_headers: Optional[Dict[str, str]] = None
    log_level: Optional[Union[str, int]] = None
    debug_mode: Optional[bool] = None
    console_output: Optional[bool] = None
    error_severity_map: Optional[Dict[str, str]] = None
    auth_enabled: Optional[bool] = None
    scanner_endpoint: Optional[str] = None
    scanner_api_key: Optional[str] = None
    
    def __post_init__(self):
        """Set defaults after initialization."""
        if not self.service_name:
            self.service_name = self.agent_id
        if not self.api_key_header_name:
            self.api_key_header_name = "X-API-Key"
