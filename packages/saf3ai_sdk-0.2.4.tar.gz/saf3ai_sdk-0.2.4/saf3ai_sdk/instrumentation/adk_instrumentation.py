"""Auto-instrumentation for Google ADK agents and LLMs."""

import functools
import json
import asyncio
import uuid
import random
import threading
from opentelemetry import trace, context
from opentelemetry.trace import SpanContext, TraceFlags, NonRecordingSpan, Status, StatusCode
from opentelemetry import context as context_api

from saf3ai_sdk.logging import logger
from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
from saf3ai_sdk.core.tracer import TraceContext

_last_span_context_per_session = {}
_session_context_lock = threading.Lock()
_session_trace_links = {}
_session_links_lock = threading.Lock()
_current_persistent_session_id = None
_persistent_session_lock = threading.Lock()
_current_agent_span = threading.local()
_sdk_config = None
_last_adk_session_id = None
_adk_session_lock = threading.Lock()

def _check_and_reset_on_new_adk_session(adk_session_id: str) -> bool:
    """
    Track ADK session ID for debugging only. Do NOT reset persistent session
    when session_id changes - that would create a new conversation_id for every
    tool call, threat detection, or new turn. All spans in the same logical
    conversation must share one conversation_id (adk_session_xxx).
    Use reset_conversation() from the app when starting a new conversation.
    
    Returns:
        bool: False (never auto-reset)
    """
    global _last_adk_session_id
    
    if not adk_session_id:
        return False
    
    with _adk_session_lock:
        if adk_session_id != _last_adk_session_id:
            logger.debug(
                f"ADK session_id changed to {adk_session_id} (was {_last_adk_session_id}). "
                "Keeping same conversation_id for stitching; call reset_conversation() for new chat."
            )
            _last_adk_session_id = adk_session_id
        return False  # Never auto-reset: one conversation_id for entire flow

def categorize_error(error: Exception, span=None) -> str:
    """
    ⚠️ CUSTOM HELPER: Categorize errors as security vs. operational.
    
    This is an OPTIONAL helper function you can call to better categorize errors.
    
    Args:
        error: The exception to categorize
        span: Optional OTel span to add attributes to
    
    Returns:
        str: Error category ('security', 'operational', 'user_error', 'unknown')
    
    Example:
        # In your callback:
        from saf3ai_sdk.instrumentation.adk_instrumentation import categorize_error
        
        try:
            result = risky_operation()
        except Exception as e:
            current_span = trace.get_current_span()
            category = categorize_error(e, current_span)
            
            if category == 'security':
                # Alert security team
                pass
    """
    error_name = type(error).__name__
    error_msg = str(error).lower()
    
    # Security-related errors
    security_indicators = [
        'permission', 'denied', 'unauthorized', 'forbidden', 'authentication',
        'credential', 'token', 'invalid signature', 'csrf', 'xss', 'injection',
        'blocked', 'threat', 'malicious', 'suspicious'
    ]
    
    # User input errors
    user_error_indicators = [
        'invalid input', 'validation', 'required field', 'parse error',
        'bad request', 'invalid format'
    ]
    
    # Operational errors
    operational_indicators = [
        'timeout', 'connection', 'network', 'unavailable', 'rate limit',
        'quota', 'overload', 'busy', 'retry'
    ]
    
    category = 'unknown'
    
    if any(indicator in error_msg for indicator in security_indicators):
        category = 'security'
    elif any(indicator in error_msg for indicator in user_error_indicators):
        category = 'user_error'
    elif any(indicator in error_msg for indicator in operational_indicators):
        category = 'operational'
    
    # Add to span if provided
    if span and span.is_recording():
        span.set_attribute("error.category", category)
        span.set_attribute("error.type", error_name)
        span.set_attribute("error.message", str(error))
        
        # Add severity based on category (from config or default)
        # Use the SDK config's error_severity_map if available
        if _sdk_config and hasattr(_sdk_config, 'error_severity_map'):
            severity_map = _sdk_config.error_severity_map
        else:
            # Fallback to default severity mapping
            severity_map = {
                'security': 'critical',
                'operational': 'warning',
                'user_error': 'info',
                'unknown': 'error'
            }
        span.set_attribute("error.severity", severity_map.get(category, 'error'))
    
    return category


def _add_trace_to_session_links(session_id: str, trace_context: TraceContext):
    """
    Add a trace context to the session's trace links for later linking.
    """
    with _session_links_lock:
        if session_id not in _session_trace_links:
            _session_trace_links[session_id] = []
        _session_trace_links[session_id].append(trace_context)
        logger.debug(f"Added trace {trace_context.span.get_span_context().trace_id:x} to session {session_id} links")

def _create_trace_links_for_session(session_id: str, current_trace_context: TraceContext):
    """
    Create trace links between the current trace and all previous traces in the session.
    """
    with _session_links_lock:
        if session_id not in _session_trace_links:
            return []
        
        links = []
        current_span_context = current_trace_context.span.get_span_context()
        
        for prev_trace_context in _session_trace_links[session_id]:
            if prev_trace_context.span.get_span_context().trace_id != current_span_context.trace_id:
                # Create a link to the previous trace
                from opentelemetry.trace import Link
                prev_span_context = prev_trace_context.span.get_span_context()
                link = Link(prev_span_context, attributes={
                    "link.type": "session_continuation",
                    "session.id": session_id,
                    "link.description": "Previous trace in same session"
                })
                links.append(link)
                logger.debug(f"Created link from trace {current_span_context.trace_id:x} to trace {prev_span_context.trace_id:x}")
        
        return links

def _cleanup_old_session_data():
    """
    Clean up old session data to prevent memory leaks.
    Keep only the last 10 traces per session.
    """
    with _session_links_lock:
        for session_id in list(_session_trace_links.keys()):
            if len(_session_trace_links[session_id]) > 10:
                # Keep only the last 10 traces
                _session_trace_links[session_id] = _session_trace_links[session_id][-10:]
                logger.debug(f"Cleaned up old traces for session {session_id}, keeping last 10")

def _get_or_create_persistent_session_id():
    """
    Get the current persistent session ID, or create a new one if none exists.
    This ID persists across agent handoffs within the same ADK web session.
    """
    global _current_persistent_session_id
    
    with _persistent_session_lock:
        if _current_persistent_session_id is None:
            _current_persistent_session_id = f"adk_session_{uuid.uuid4().hex[:8]}"
            logger.info(f"🔗 Created new persistent session ID: {_current_persistent_session_id}")
        
        return _current_persistent_session_id

def reset_persistent_session():
    """
    Reset the persistent session ID to create a new session.
    This should be called when starting a new ADK web session.
    """
    global _current_persistent_session_id
    
    with _persistent_session_lock:
        old_session_id = _current_persistent_session_id
        _current_persistent_session_id = f"adk_session_{uuid.uuid4().hex[:8]}"
        logger.debug(f"Reset persistent session ID: {_current_persistent_session_id}")
        
        # Clean up old session data
        if old_session_id and old_session_id in _session_trace_links:
            with _session_links_lock:
                del _session_trace_links[old_session_id]
                logger.debug(f"Cleaned up old session data for {old_session_id}")
        
        return _current_persistent_session_id

def _get_repaired_context(adk_session_id: str = None):
    """
    Checks for a valid trace context. If it's lost (NonRecordingSpan),
    this function attempts to find the active root trace (matching adk_session_id
    if provided, otherwise the most recent) from the Saf3AI TracingCore
    and returns a new context parented to that trace. Returns None if repair fails.
    """
    current_span = trace.get_current_span()

    if current_span and current_span.is_recording():
        # Context is valid, proceed as normal.
        # logger.debug("OTel context is valid.")
        return context.get_current()

    # Context is LOST. Attempt to find the parent trace from our SDK's active list.
    logger.debug("OTel context lost. Attempting repair.")
    active_traces = saf3ai_tracer_core.get_active_traces()
    parent_span = None

    if not active_traces:
        logger.warning("Could not repair OTel context: No active traces found in SDK.")
        return None # Cannot repair if no traces are active

    # 1. Try to find the trace using the specific session ID
    if adk_session_id:
        try:
            # Ensure the key format matches how it's stored in _patch_llm_agent
            trace_id_str = f"{int(adk_session_id.replace('-', '')[:32], 16):x}"
            if trace_id_str in active_traces:
                parent_span = active_traces[trace_id_str].span
                logger.debug(f"Context repair: Found active trace matching session ID {adk_session_id}.")
            else:
                logger.debug(f"Context repair: No active trace found for session ID {adk_session_id}.")
        except (ValueError, TypeError):
             logger.warning(f"Context repair: Could not derive trace ID from session ID: {adk_session_id}")

    # 2. If session ID didn't match, fall back to the most recently added trace
    if not parent_span:
        try:
            parent_trace_context = list(active_traces.values())[-1]
            parent_span = parent_trace_context.span
            logger.debug("Context repair: Using most recent active trace as parent.")
        except Exception as e:
             logger.error(f"Context repair: Failed to get most recent active trace: {e}")
             return None # Failed to get parent

    # 3. Create the repaired context object
    if parent_span:
        try:
            repaired_context = trace.set_span_in_context(parent_span)
            logger.debug(f"Repaired broken trace context. Re-parenting to trace {parent_span.get_span_context().trace_id:x}")
            return repaired_context
        except Exception as e:
            logger.error(f"Failed to create repaired context object: {e}")

    # If all attempts failed
    logger.error("Failed to repair OTel context after all attempts.")
    return None


def _patch_llm_agent(tracer):
    """
    Patches LlmAgent.run_async. Creates a new root trace ONLY if necessary,
    attempting to LINK it to the previous trace segment for the same session.
    Otherwise creates a child span using repaired context.
    """
    try:
        from google.adk.agents import LlmAgent
        
        # REMOVED: Debug print statements - not needed for production
        # Reason: These print statements were for debugging during development.
        # Production code should use logger instead. Keeping logger.debug/info for error tracking.
        # print(f"🚨 PRINT: _patch_llm_agent called!")
        
        if hasattr(LlmAgent, '_saf3ai_instrumented_agent'):
            # print(f"🚨 PRINT: LlmAgent already instrumented.")
            logger.debug("LlmAgent already instrumented.")
            return True

        original_run_async = LlmAgent.run_async

        @functools.wraps(original_run_async)
        async def instrumented_run_async(self, *args, **kwargs):
            # REMOVED: Debug print statements - not needed for production
            # print(f"🚨 PRINT: LlmAgent {self.name} - instrumented_run_async called!")
            
            # Try to extract session ID from multiple sources
            adk_session_id = kwargs.get('session_id')
            if not adk_session_id and args:
                # Try to extract from args (ADK context)
                for arg in args:
                    if hasattr(arg, 'session') and hasattr(arg.session, 'id'):
                        adk_session_id = arg.session.id
                        # print(f"🚨 PRINT: Found session ID in args: {adk_session_id}")
                        break
            
            # Check if this is a new ADK session and auto-reset telemetry if needed
            # This ensures conversation continuity within the same ADK web session
            if adk_session_id:
                    _check_and_reset_on_new_adk_session(adk_session_id)
            
            # For trace linking, use a persistent session ID that doesn't change between agent handoffs
            # This ensures all traces in the same ADK web session are linked together
            persistent_session_id = _get_or_create_persistent_session_id()
            # REMOVED: Debug print statements
            # print(f"🚨 PRINT: Using persistent session ID for linking: {persistent_session_id}")
            
            # REMOVED: Debug print statements - verbose debugging not needed in production
            # print(f"🚨 PRINT: LlmAgent {self.name} - session_id from kwargs: {adk_session_id}")
            # print(f"🚨 PRINT: LlmAgent {self.name} - all kwargs keys: {list(kwargs.keys())}")
            # print(f"🚨 PRINT: LlmAgent {self.name} - args count: {len(args) if args else 0}")
            # if args:
            #     print(f"🚨 PRINT: LlmAgent {self.name} - first arg type: {type(args[0])}")
            #     if hasattr(args[0], 'session'):
            #         print(f"🚨 PRINT: LlmAgent {self.name} - session in first arg: {args[0].session}")
            
            # Keeping logger.info for important tracking, but reducing verbosity
            logger.debug(f"LlmAgent {self.name} - session_id from kwargs: {adk_session_id}")
            logger.debug(f"LlmAgent {self.name} - all kwargs keys: {list(kwargs.keys())}")
            logger.debug(f"LlmAgent {self.name} - args: {args}")
            repaired_context = _get_repaired_context(adk_session_id) # Attempt repair first

            is_new_trace = (not trace.get_current_span().is_recording()) and (repaired_context is None)

            current_span_context = None # Variable to store context for linking

            if is_new_trace:
                # PATH 1: ROOT AGENT / NEW TRACE SEGMENT
                # Use persistent session ID for linking, but individual session ID for trace ID generation
                linking_session_id = persistent_session_id
                trace_session_id = adk_session_id or str(uuid.uuid4())
                
                try:
                    trace_id_int = int(trace_session_id.replace('-', '')[:32], 16)
                except (ValueError, TypeError):
                    logger.error(f"Failed to create trace ID from session ID: {trace_session_id}. Generating random trace ID.")
                    trace_id_int = random.getrandbits(128)

                span_id_int = random.getrandbits(64)
                span_context = SpanContext(
                    trace_id=trace_id_int, span_id=span_id_int, is_remote=False,
                    trace_flags=TraceFlags(0x01) # SAMPLED
                )
                span_name = f"{self.name}.run_async"
                otel_tracer = saf3ai_tracer_core.get_tracer("saf3ai.adk_instrumentation")

                links = []
                if linking_session_id:
                    with _session_links_lock:
                        if linking_session_id in _session_trace_links:
                            for prev_trace_context in _session_trace_links[linking_session_id]:
                                from opentelemetry.trace import Link
                                prev_span_context = prev_trace_context.span.get_span_context()
                                link = Link(prev_span_context, attributes={
                                    "link.type": "session_continuation",
                                    "session.id": linking_session_id,
                                    "link.description": "Previous trace in same session"
                                })
                                links.append(link)

                # Create the root span properly using the tracer
                # Get agent ID from tags/config
                agent_id = getattr(saf3ai_tracer_core, '_agent_id', None)
                
                # Get custom attributes from tracer
                # This includes agent_id, framework, and any user-set custom attributes
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                logger.debug(f"ROOT AGENT - Retrieved custom_attrs: {custom_attrs}")
                
                # CRITICAL: Get or create conversation_id for proper stitching
                # Use unified helper FIRST - this is the single source of truth
                from saf3ai_sdk.core.tracer import get_conversation_id_unified, set_conversation_id_unified
                conversation_id = get_conversation_id_unified()
                
                # CRITICAL: Root agent MUST use only persistent_session_id (adk_session_xxx).
                # Never use trace_session_id (ADK UUID) as conversation_id - that creates
                # duplicate conversation IDs and splits spans across multiple conversation rows.
                if not conversation_id or not (isinstance(conversation_id, str) and conversation_id.startswith("adk_session_")):
                    conversation_id = linking_session_id
                
                # CRITICAL: Always use persistent_session_id (adk_session_xxx) for root agent
                # Force=True to overwrite any wrong IDs (UUIDs) that may have been set earlier
                if conversation_id:
                    use_force = True  # Always force for root agent - it's the authority
                    set_conversation_id_unified(conversation_id, source="adk_root_agent", update_spans=False, force=use_force)
                    logger.info(f"[ADK Root Agent] Set conversation_id: {conversation_id} (force={use_force}, linking_session_id={linking_session_id})")
                else:
                    logger.warning(f"[ADK Root Agent] No conversation_id available - spans may not be stitched correctly")
                
                # Build span attributes
                span_attributes = {
                    "agent.name": self.name,
                    "agent.id": str(agent_id) if agent_id else "unknown",
                    "span.kind": "agent_session",
                    "adk.session_id": conversation_id or linking_session_id,  # CRITICAL: Use conversation_id, not UUID
                    "session.id": linking_session_id,
                    "trace.type": "root_agent"
                }
                
                # CRITICAL: Set conversation_id on agent span
                if conversation_id:
                    span_attributes["gen_ai.conversation.id"] = conversation_id
                    span_attributes["conversation_id"] = conversation_id
                
                # Add custom attributes (includes agent_id, framework, and any user-set attributes)
                span_attributes.update(custom_attrs)
                
                # CRITICAL: Use start_as_current_span to ensure proper parent-child linking
                # This ensures child spans (LLM calls) are properly linked to the agent span
                ctx_with_span = trace.set_span_in_context(
                    otel_tracer.start_span(
                        span_name,
                        attributes=span_attributes,
                        links=links
                    )
                )
                span = trace.get_current_span()
                current_span_context = span.get_span_context() # Store context for next link

                # Store the agent span globally so callbacks can access it
                _current_agent_span.span = span

                # Attach the context so child spans are properly linked
                token = context_api.attach(ctx_with_span)
                trace_context_obj = TraceContext(span, token)
                trace_id_str_key = f"{trace_id_int:x}"
                with saf3ai_tracer_core._traces_lock:
                    saf3ai_tracer_core._active_traces[trace_id_str_key] = trace_context_obj
                
                # Add this trace to the session links for future linking
                if linking_session_id:
                    logger.debug(f"Adding trace {trace_id_str_key} to session {linking_session_id} links")
                    _add_trace_to_session_links(linking_session_id, trace_context_obj)
                else:
                    logger.debug("No linking_session_id to add trace to session links")
                
                logger.debug(f"Root agent {self.name} called. Creating new trace: {trace_id_str_key}")

                try:
                    # Store the agent span globally so callbacks can access it
                    _current_agent_span.span = trace_context_obj.span
                    
                    # CRITICAL: Ensure span is set as current context for child spans
                    # Child LLM spans will automatically be linked to this span
                    ctx = trace.set_span_in_context(trace_context_obj.span)
                    context_api.detach(token)  # Detach old token
                    token = context_api.attach(ctx)  # Attach new context
                    trace_context_obj.token = token  # Update token
                    
                    # Now call the original method - LLM calls should be children of this span
                    # CRITICAL: Yield events as they come (don't collect first - breaks async generator)
                    # Child spans will be created and linked automatically
                    # Now call the original method - LLM calls should be children of this span
                    # CRITICAL: Yield events as they come (don't collect first - breaks async generator)
                    # Child spans will be created and linked automatically
                    async for event in original_run_async(self, *args, **kwargs):
                        yield event
                    
                    # CRITICAL: After generator completes, wait briefly for callbacks to finish
                    # Then end span IMMEDIATELY before finally block
                    # This ensures span is ended and exported even if generator is not fully consumed
                    if trace_context_obj.span and trace_context_obj.span.is_recording():
                        # Small delay to ensure all callbacks (response scanning) complete
                        import asyncio
                        await asyncio.sleep(0.1)  # 100ms delay for callbacks to complete
                        
                        import time
                        end_time = time.time()
                        if not trace_context_obj.span.attributes.get("gen_ai.request.end_time"):
                            trace_context_obj.span.set_attribute("gen_ai.request.end_time", end_time)
                        
                        trace_context_obj.span.set_status(Status(StatusCode.OK))
                        span_ctx = trace_context_obj.span.get_span_context()
                        logger.info(f"[ADK Export] Root agent '{self.name}' ending span immediately after generator completion, "
                                   f"span_id={span_ctx.span_id:x}, trace_id={span_ctx.trace_id:x}")
                        
                        # End span immediately - triggers export via SimpleSpanProcessor
                        trace_context_obj.span.end()
                        logger.info(f"[ADK Export] ✅ Root agent '{self.name}' span ended and exported immediately")
                        
                        # Clear the span reference so finally block doesn't try to end it again
                        trace_context_obj.span = None
                        
                except Exception as e:
                    if trace_context_obj.span and trace_context_obj.span.is_recording():
                        trace_context_obj.span.set_status(Status(StatusCode.ERROR, str(e)))
                        trace_context_obj.span.set_attribute("error.message", str(e))
                        import time
                        end_time = time.time()
                        if not trace_context_obj.span.attributes.get("gen_ai.request.end_time"):
                            trace_context_obj.span.set_attribute("gen_ai.request.end_time", end_time)
                        
                        span_ctx = trace_context_obj.span.get_span_context()
                        logger.info(f"[ADK Export] Root agent '{self.name}' ending span on error, "
                                   f"span_id={span_ctx.span_id:x}, trace_id={span_ctx.trace_id:x}")
                        trace_context_obj.span.end()
                        logger.info(f"[ADK Export] ✅ Root agent '{self.name}' span ended on error and exported")
                        trace_context_obj.span = None
                    raise
                finally:
                    # CRITICAL: Only end span here if it wasn't already ended above
                    # This is a safety net in case the try block didn't execute properly
                    if trace_context_obj.span and trace_context_obj.span.is_recording():
                        span_ctx = trace_context_obj.span.get_span_context()
                        logger.warning(f"[ADK Export] Root agent '{self.name}' span still active in finally block, ending now, "
                                     f"span_id={span_ctx.span_id:x}, trace_id={span_ctx.trace_id:x}")
                        import time
                        end_time = time.time()
                        if not trace_context_obj.span.attributes.get("gen_ai.request.end_time"):
                            trace_context_obj.span.set_attribute("gen_ai.request.end_time", end_time)
                        trace_context_obj.span.end()
                        logger.info(f"[ADK Export] ✅ Root agent '{self.name}' span ended in finally block and exported")
                    
                    # Detach the context
                    if token:
                        context_api.detach(token)
                # Trace remains in _active_traces for context repair, but span is ended and exported

            else:
                # PATH 2: SUB-AGENT or SESSION CONTINUATION
                logger.debug(f"Sub-agent or continuation for {self.name}. Creating child span.")
                final_context = repaired_context or context.get_current()
                span_name = f"{self.name}.run_async"
                
                # CRITICAL: Get conversation_id using unified helper FIRST - this is the single source of truth
                from saf3ai_sdk.core.tracer import get_conversation_id_unified, set_conversation_id_unified, ensure_conversation_id_on_span
                conversation_id = get_conversation_id_unified()
                # Only accept adk_session_xxx as valid; ignore UUIDs (would split conversation)
                if conversation_id and (not isinstance(conversation_id, str) or not conversation_id.startswith("adk_session_")):
                    conversation_id = None
                
                # CRITICAL: Get persistent_session_id AFTER checking conversation_id
                # If conversation_id exists and is adk_session_*, use it as persistent_session_id
                if conversation_id:
                    persistent_session_id = conversation_id
                    global _current_persistent_session_id
                    with _persistent_session_lock:
                        if _current_persistent_session_id != conversation_id:
                            logger.debug(f"[ADK Sub Agent] Syncing persistent_session_id to match conversation_id: {conversation_id}")
                            _current_persistent_session_id = conversation_id
                else:
                    persistent_session_id = _get_or_create_persistent_session_id()
                
                # CRITICAL: NEVER create new conversation_id - always use existing or persistent
                # If get_conversation_id_unified() returns None/invalid, check parent span attributes
                if not conversation_id:
                    # Check parent span (current span might be tool span or agent span)
                    try:
                        current_span = trace.get_current_span()
                        if current_span and current_span.is_recording():
                            parent_conv_id = current_span.attributes.get("gen_ai.conversation.id") or current_span.attributes.get("conversation_id")
                            if parent_conv_id:
                                parent_conv_id = str(parent_conv_id)
                                # Only use parent if it is adk_session_xxx, not UUID
                                if parent_conv_id.startswith("adk_session_"):
                                    conversation_id = parent_conv_id
                                    logger.debug(f"[ADK Sub Agent] Found conversation_id in parent span: {conversation_id}")
                                    set_conversation_id_unified(conversation_id, source="adk_sub_agent_parent", update_spans=False, force=False)
                    except Exception as e:
                        logger.debug(f"[ADK Sub Agent] Could not check parent span: {e}")
                
                # Only if STILL no conversation_id, use persistent_session_id (NOT adk_session_id UUID)
                if not conversation_id:
                    # ADK-specific: Use persistent_session_id (adk_session_xxx) NOT adk_session_id (UUID)
                    # This ensures we don't create new conversation IDs for sub-agents
                    conversation_id = persistent_session_id
                    if conversation_id:
                        # Prefer our persistent ID; overwrite stray UUID if we're setting adk_session_xxx
                        use_force = (isinstance(conversation_id, str) and conversation_id.startswith("adk_session_"))
                        set_conversation_id_unified(conversation_id, source="adk_sub_agent", update_spans=False, force=use_force)
                        logger.debug(f"[ADK Sub Agent] Created conversation_id from persistent_session_id: {conversation_id} (force={use_force})")
                    else:
                        logger.warning(f"[ADK Sub Agent] No conversation_id found and no persistent_session_id available - sub-agent spans may not be stitched correctly")
                else:
                    logger.debug(f"[ADK Sub Agent] Using existing conversation_id: {conversation_id}")
                
                # CRITICAL: Log conversation_id before creating sub-agent span
                logger.info(f"[ADK Sub Agent] '{self.name}' - conversation_id: {conversation_id}, persistent_session_id: {persistent_session_id}, adk_session_id: {adk_session_id}")
                
                with tracer.start_as_current_span(span_name, context=final_context) as span:
                    current_span_context = span.get_span_context() # Store context for next link
                    
                    # Store the agent span globally so callbacks can access it
                    _current_agent_span.span = span
                    
                    span.set_attribute("agent.name", self.name)
                    span.set_attribute("span.kind", "agent_task")
                    
                    # CRITICAL: Ensure conversation_id on sub-agent span using unified helper
                    ensure_conversation_id_on_span(span, conversation_id)
                    
                    # CRITICAL: Set adk.session_id to conversation_id (persistent session ID), NOT UUID
                    # This ensures UI groups all spans in the same conversation together
                    if conversation_id:
                        span.set_attribute("adk.session_id", conversation_id)
                        span.set_attribute("session.id", persistent_session_id)
                        span.set_attribute("trace.type", "sub_agent")
                    elif adk_session_id:
                        # Fallback: if no conversation_id, use persistent_session_id (still not UUID)
                        span.set_attribute("adk.session_id", persistent_session_id)
                        span.set_attribute("session.id", persistent_session_id)
                        span.set_attribute("trace.type", "sub_agent")
                    
                    # Add custom attributes (includes agent_id, framework, and any user-set attributes)
                    custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                    logger.debug(f"SUB AGENT - Retrieved custom_attrs: {custom_attrs}")
                    logger.debug(f"SUB AGENT - Setting {len(custom_attrs)} custom attributes on span")
                    for key, value in custom_attrs.items():
                        # Don't overwrite conversation_id if already set
                        if key in ("gen_ai.conversation.id", "conversation_id") and conversation_id:
                            continue
                        logger.debug(f"SUB AGENT - Setting attribute: {key} = {value}")
                        span.set_attribute(key, value)
                    
                    # AUTOMATIC CLIENT DATA CAPTURE: Extract and add client data automatically
                    try:
                        import os
                        client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
                        if client_data_capture_enabled and span.is_recording():
                            from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                            client_data = extract_comprehensive_client_data()
                            if client_data.get('ip_address') or client_data.get('user_agent'):
                                _add_client_data_to_span(span, client_data)
                    except Exception as e:
                        logger.debug(f"Could not extract client data in ADK instrumentation: {e}")
                    try:
                        async for event in original_run_async(self, *args, **kwargs):
                            yield event
                        span.set_status(Status(StatusCode.OK))
                    except Exception as e:
                        span.set_status(Status(StatusCode.ERROR, str(e)))
                        span.set_attribute("error.message", str(e))
                        raise
                    finally:
                        # CRITICAL: Ensure sub-agent span is properly ended and exported
                        if span.is_recording():
                            span_ctx = span.get_span_context()
                            logger.debug(f"ADK sub-agent '{self.name}' ending span, "
                                       f"span_id={span_ctx.span_id:x}, "
                                       f"trace_id={span_ctx.trace_id:x}, "
                                       f"is_recording={span.is_recording()}")
                            # CRITICAL: End the span explicitly - this triggers export via SimpleSpanProcessor
                            span.end()
                            
                            # CRITICAL: Force flush to ensure immediate export
                            try:
                                from opentelemetry import trace as otel_trace
                                provider = otel_trace.get_tracer_provider()
                                if provider and hasattr(provider, 'force_flush'):
                                    provider.force_flush(timeout_millis=5000)
                            except Exception:
                                pass  # Non-critical
                            
                            logger.debug(f"[ADK Export] ✅ Sub-agent '{self.name}' span ended and exported")
                        else:
                            logger.warning(f"ADK sub-agent '{self.name}' span was not recording, may not be exported")

            # --- Store context for next interaction ---
            if current_span_context and persistent_session_id:
                 with _session_context_lock:
                     _last_span_context_per_session[persistent_session_id] = current_span_context
                     logger.debug(f"Updated last span context for session {persistent_session_id} to span {current_span_context.span_id:x}")
            # --- End store context ---


        setattr(LlmAgent, 'run_async', instrumented_run_async)
        setattr(LlmAgent, '_saf3ai_instrumented_agent', True)
        # REMOVED: Debug print statement - not needed for production
        # print(f"🚨 PRINT: Successfully instrumented LlmAgent.run_async!")
        logger.debug("Successfully instrumented LlmAgent.run_async")
        return True

    except ImportError:
        logger.warning("google.adk.agents.LlmAgent not found. Skipping root agent instrumentation.")
        return False
    except Exception as e:
        logger.error(f"❌ Failed to instrument LlmAgent: {e}")
        return False


def _patch_agent_tool(tracer):
    """Instrument AgentTool.run_async to capture sub-agent handoff."""
    try:
        from google.adk.tools.agent_tool import AgentTool

        if hasattr(AgentTool, '_saf3ai_instrumented_tool'):
            logger.debug("AgentTool already instrumented.")
            return True

        original_run_async = AgentTool.run_async

        @functools.wraps(original_run_async)
        async def instrumented_run_async(self, *, args, tool_context):
            adk_session_id = tool_context.get('session_id') if isinstance(tool_context, dict) else None
            logger.debug(f"AgentTool - session_id from tool_context: {adk_session_id}")
            logger.debug(f"AgentTool - tool_context type: {type(tool_context)}")
            logger.debug(f"AgentTool - tool_context keys: {list(tool_context.keys()) if isinstance(tool_context, dict) else 'Not a dict'}")
            # Use the current OpenTelemetry context for proper parent-child relationships
            current_context = context.get_current()
            agent_name = getattr(self.agent, 'name', 'unknown_agent')
            span_name = f"agent_tool.handoff.{agent_name}"

            # CRITICAL: Get conversation_id FIRST - this is the single source of truth
            # Tool calls should NOT create new conversation IDs - they inherit from parent
            from saf3ai_sdk.core.tracer import get_conversation_id_unified, ensure_conversation_id_on_span, set_conversation_id_unified
            conversation_id = get_conversation_id_unified()
            # Only accept adk_session_xxx; ignore UUIDs so tool calls stay in same conversation
            if conversation_id and (not isinstance(conversation_id, str) or not conversation_id.startswith("adk_session_")):
                conversation_id = None
            
            # CRITICAL: Get persistent_session_id - use as conversation_id so all spans share one ID
            if conversation_id:
                persistent_session_id = conversation_id
                global _current_persistent_session_id
                with _persistent_session_lock:
                    if _current_persistent_session_id != conversation_id:
                        logger.debug(f"[ADK Tool] Syncing persistent_session_id to match conversation_id: {conversation_id}")
                        _current_persistent_session_id = conversation_id
            else:
                persistent_session_id = _get_or_create_persistent_session_id()
                conversation_id = persistent_session_id
                if conversation_id:
                    # Overwrite any stray UUID in unified store so tool spans use adk_session_xxx
                    set_conversation_id_unified(conversation_id, source="adk_tool_persistent", update_spans=False, force=True)
                    logger.debug(f"AgentTool - Using persistent_session_id as conversation_id: {conversation_id}")
            
            logger.info(f"[ADK Tool] AgentTool '{agent_name}' - conversation_id: {conversation_id}, persistent_session_id: {persistent_session_id}")
            logger.debug(f"AgentTool - Inherited conversation_id from parent: {conversation_id}")

            with tracer.start_as_current_span(span_name, context=current_context) as span:
                span.set_attribute("tool.type", "agent_tool")
                span.set_attribute("tool.agent_name", agent_name)
                
                # CRITICAL: Ensure conversation_id on tool span AND in unified store
                # This ensures tool calls and sub-agents are part of the same conversation lineage
                ensure_conversation_id_on_span(span, conversation_id)
                
                # CRITICAL: Also store in unified store so sub-agents can inherit it
                if conversation_id:
                    set_conversation_id_unified(conversation_id, source="adk_tool", update_spans=False, force=False)
                
                # CRITICAL: Set adk.session_id to conversation_id (persistent session ID), NOT UUID
                # This ensures UI groups all spans in the same conversation together
                if conversation_id:
                    span.set_attribute("adk.session_id", conversation_id)
                    span.set_attribute("session.id", persistent_session_id)
                    span.set_attribute("trace.type", "agent_handoff")
                elif adk_session_id:
                    # Fallback: if no conversation_id, use persistent_session_id (still not UUID)
                    span.set_attribute("adk.session_id", persistent_session_id)
                    span.set_attribute("session.id", persistent_session_id)
                    span.set_attribute("trace.type", "agent_handoff")
                if args:
                    span.set_attribute("tool.args", str(args))

                try:
                    # CRITICAL: Log conversation_id before calling sub-agent to track propagation
                    final_conv_id = get_conversation_id_unified()
                    logger.info(f"[ADK Tool] Calling sub-agent '{agent_name}' with conversation_id: {final_conv_id}")
                    
                    result = await original_run_async(self, args=args, tool_context=tool_context)
                    # Note: We don't store tool results - only track that the tool was called
                    # Results are not stored in telemetry/UI
                    span.set_status(Status(StatusCode.OK))
                    
                    # CRITICAL: Verify conversation_id after sub-agent call
                    post_conv_id = get_conversation_id_unified()
                    if post_conv_id != final_conv_id:
                        logger.warning(f"[ADK Tool] Conversation ID changed during sub-agent call: {final_conv_id} -> {post_conv_id}")
                    
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    raise
                finally:
                    # CRITICAL: Ensure tool span is properly ended and exported
                    if span.is_recording():
                        span_ctx = span.get_span_context()
                        conv_id = span.attributes.get("gen_ai.conversation.id") or span.attributes.get("conversation_id")
                        logger.debug(f"[ADK Tool] Tool span ending: span_id={span_ctx.span_id:x}, conversation_id={conv_id}")
                        # Span will be auto-ended by context manager, but ensure it's exported
                        try:
                            from opentelemetry import trace as otel_trace
                            provider = otel_trace.get_tracer_provider()
                            if provider and hasattr(provider, 'force_flush'):
                                provider.force_flush(timeout_millis=1000)
                        except Exception:
                            pass  # Non-critical

        setattr(AgentTool, 'run_async', instrumented_run_async)
        setattr(AgentTool, '_saf3ai_instrumented_tool', True)
        logger.debug("Successfully instrumented AgentTool.run_async")
        return True

    except ImportError:
        logger.warning("google.adk.tools.agent_tool.AgentTool not found. Skipping agent tool instrumentation.")
        return False
    except Exception as e:
        logger.error(f"❌ Failed to instrument AgentTool: {e}")
        return False


def _patch_gemini_llm(tracer):
    """Instrument Google ADK LLM calls (Gemini.generate_content_async)."""
    try:
        from google.adk.models.google_llm import Gemini

        if hasattr(Gemini, '_saf3ai_instrumented_llm'):
            logger.debug("Gemini LLM already instrumented.")
            return True

        original_generate_content_async = Gemini.generate_content_async

        @functools.wraps(original_generate_content_async)
        def instrumented_generate_content_async(self, *args, **kwargs):

            async def _instrumented_generator():
                # REMOVED: Debug print statements - not needed for production
                # print(f"🚨 PRINT: LLM instrumentation called!")
                adk_session_id = None
                config = kwargs.get('config')
                if config and hasattr(config, 'labels') and isinstance(config.labels, dict):
                     adk_session_id = config.labels.get('adk_session_id') or config.labels.get('session_id')
                
                persistent_session_id = _get_or_create_persistent_session_id()
                
                # Try to get the current active span to enhance it
                current_span = trace.get_current_span()
                # REMOVED: Debug print statements - verbose debugging not needed in production
                # print(f"🚨 PRINT: LLM - current active span: {current_span}")
                # print(f"🚨 PRINT: LLM - is recording: {current_span.is_recording() if current_span else 'N/A'}")
                
                # Create a NEW child span for LLM call instead of enhancing
                # This gives us proper span hierarchy and visibility
                # print(f"🚨 PRINT: Creating child LLM span under: {current_span.name if current_span else 'no parent'}")
                
                span_name = "call_llm"
                
                # AUTOMATIC CLIENT DATA CAPTURE: Will be added to span after creation
                
                # CRITICAL: Get conversation_id from parent agent span using unified helper
                from saf3ai_sdk.core.tracer import get_conversation_id_unified, ensure_conversation_id_on_span
                conversation_id = get_conversation_id_unified()
                
                with tracer.start_as_current_span(span_name) as llm_span:
                    llm_span.set_attribute("llm.provider", "google")
                    llm_span.set_attribute("llm.model", getattr(self, 'model', 'unknown'))
                    
                    # CRITICAL: Ensure conversation_id on LLM span using unified helper
                    ensure_conversation_id_on_span(llm_span, conversation_id)
                    
                    # CRITICAL: Set adk.session_id to conversation_id (persistent session ID), NOT UUID
                    # This ensures UI groups all spans in the same conversation together
                    if conversation_id:
                        llm_span.set_attribute("adk.session_id", conversation_id)
                        llm_span.set_attribute("session.id", persistent_session_id)
                        llm_span.set_attribute("trace.type", "llm_call")
                    elif adk_session_id:
                        # Fallback: if no conversation_id, use persistent_session_id (still not UUID)
                        llm_span.set_attribute("adk.session_id", persistent_session_id)
                        llm_span.set_attribute("session.id", persistent_session_id)
                        llm_span.set_attribute("trace.type", "llm_call")
                    
                    # Add custom attributes (includes agent_id, framework, and any user-set attributes)
                    custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                    for key, value in custom_attrs.items():
                        # Don't overwrite conversation_id if already set
                        if key in ("gen_ai.conversation.id", "conversation_id") and conversation_id:
                            continue
                        llm_span.set_attribute(key, value)
                    
                    # AUTOMATIC CLIENT DATA CAPTURE: Extract and add client data automatically
                    try:
                        import os
                        client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
                        if client_data_capture_enabled and llm_span.is_recording():
                            from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                            client_data = extract_comprehensive_client_data()
                            if client_data.get('ip_address') or client_data.get('user_agent'):
                                _add_client_data_to_span(llm_span, client_data)
                    except Exception as e:
                        logger.debug(f"Could not extract client data in ADK LLM instrumentation: {e}")
                    
                    # Process the LLM call and add response data
                    try:
                        prompt_data = kwargs.get('contents', args[0] if args else None)
                        if prompt_data:
                            try:
                                llm_span.set_attribute("llm.prompt", json.dumps(prompt_data))
                            except TypeError:
                                llm_span.set_attribute("llm.prompt", str(prompt_data))
                            
                        async_generator = original_generate_content_async(self, *args, **kwargs)
                        
                        # Note: We don't record LLM responses in spans - only scan them for security
                        # Responses are handled by security callbacks but not stored in telemetry
                        last_response = None
                        async for response in async_generator:
                            last_response = response
                            yield response
                        
                        # Extract token usage from Gemini response if available
                        if last_response:
                            try:
                                usage = getattr(last_response, 'usage_metadata', None)
                                if usage:
                                    input_tokens = getattr(usage, 'prompt_token_count', None) or getattr(usage, 'input_tokens', None)
                                    output_tokens = getattr(usage, 'candidates_token_count', None) or getattr(usage, 'output_tokens', None)
                                    total_tokens = getattr(usage, 'total_token_count', None) or getattr(usage, 'total_tokens', None)
                                    if input_tokens is not None:
                                        llm_span.set_attribute("gen_ai.usage.input_tokens", input_tokens)
                                    if output_tokens is not None:
                                        llm_span.set_attribute("gen_ai.usage.output_tokens", output_tokens)
                                    if total_tokens is not None:
                                        llm_span.set_attribute("gen_ai.usage.total_tokens", total_tokens)
                            except Exception:
                                pass  # Non-critical
                        
                        llm_span.set_status(Status(StatusCode.OK))
                        
                    except Exception as e:
                        llm_span.set_status(Status(StatusCode.ERROR, str(e)))
                        llm_span.set_attribute("error.message", str(e))
                        raise

            return _instrumented_generator()

        setattr(Gemini, 'generate_content_async', instrumented_generate_content_async)
        setattr(Gemini, '_saf3ai_instrumented_llm', True)
        logger.debug("Successfully instrumented Google ADK LLM calls")
        return True

    except ImportError:
        logger.warning("google.adk.models.google_llm.Gemini not found. Skipping LLM instrumentation.")
        return False
    except Exception as e:
        logger.error(f"❌ Failed to instrument ADK LLM calls: {e}")
        return False

def instrument_adk(tracer, config=None):
    """
    Auto-instrument Google ADK agents and LLMs. Ensures patches are applied only once.
    
    Args:
        tracer: The OTel Tracer instance (from saf3ai_tracer_core.get_tracer())
        config: Optional SDK Config instance (for error_severity_map access)
    """
    global _sdk_config
    
    # Store config globally for error categorization
    if config:
        _sdk_config = config
        logger.debug("Stored SDK config for error categorization")
    
    results = {
        "root_agent_instrumentation": False,
        "sub_agent_instrumentation": False,
        "llm_instrumentation": False,
    }
    
    results["root_agent_instrumentation"] = _patch_llm_agent(tracer)
    results["sub_agent_instrumentation"] = _patch_agent_tool(tracer)
    results["llm_instrumentation"] = _patch_gemini_llm(tracer)
    
    _cleanup_old_session_data()
    return results