"""
Auto-instrumentation for OpenAI SDK.

This module automatically patches OpenAI client classes to add Saf3AI telemetry
(OpenTelemetry spans and attributes) without requiring manual callback attachment.

Note: Security scanning is optional and handled separately via callbacks
(e.g., create_framework_security_callbacks()).
"""

import functools
import logging
import os
from typing import Any, Dict, Optional

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

from saf3ai_sdk.logging import logger
from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core

# Global storage for SDK config
_sdk_config = None

# Feature flag for automatic threat detection in OpenAI instrumentation.
ENABLE_AUTO_THREAT_DETECTION = os.getenv("SAF3AI_OPENAI_AUTO_SCAN", "true").lower() in ("true", "1", "yes", "on")


def _is_custom_framework_context() -> bool:
    """Return True when current SDK context is custom/rest framework."""
    try:
        custom_attrs = saf3ai_tracer_core.get_custom_attributes()
        framework = str(custom_attrs.get("framework") or custom_attrs.get("saf3ai.framework") or "").lower().strip()
        return framework in ("custom", "rest", "rest-api", "generic")
    except Exception:
        return False


def _extract_threats_from_scan_results(scan_results: Dict[str, Any]) -> list:
    """Extract threat keys from scanner response variants."""
    threats_found = []
    if not isinstance(scan_results, dict):
        return threats_found
    detection_results = scan_results.get("detection_results", {})
    if isinstance(detection_results, dict):
        threats_found.extend([
            k for k, v in detection_results.items()
            if isinstance(v, dict) and v.get("result") == "MATCH_FOUND"
        ])
    threats = scan_results.get("threats", {})
    if isinstance(threats, dict):
        items = threats.get("items", [])
        if isinstance(items, list):
            for item in items:
                threat_type = item.get("type") if isinstance(item, dict) else None
                if threat_type:
                    threats_found.append(str(threat_type))
    return list(dict.fromkeys(threats_found))


def _normalize_security_callback_result(callback_result: Any) -> tuple[Optional[Dict[str, Any]], bool]:
    """Normalize callback return shapes to (scan_results, should_allow)."""
    scan_results: Optional[Dict[str, Any]] = None
    should_allow = True
    if isinstance(callback_result, tuple) and len(callback_result) == 2:
        maybe_results, maybe_allow = callback_result
        if isinstance(maybe_results, dict):
            scan_results = maybe_results
        should_allow = bool(maybe_allow)
    elif isinstance(callback_result, dict):
        scan_results = callback_result
    elif isinstance(callback_result, bool):
        should_allow = callback_result
    return scan_results, should_allow


def _patch_openai_chat_completions(tracer):
    """Patch OpenAI ChatCompletion.create and acreate methods."""
    try:
        from openai import OpenAI
        from openai.resources.chat import completions
        
        if hasattr(completions.Completions, '_saf3ai_instrumented'):
            logger.debug("OpenAI ChatCompletions already instrumented.")
            return True
        
        original_create = completions.Completions.create
        original_acreate = getattr(completions.Completions, "acreate", None)
        
        @functools.wraps(original_create)
        def instrumented_create(self, *args, **kwargs):
            """Instrumented ChatCompletion.create with telemetry."""
            if not saf3ai_tracer_core.initialized:
                return original_create(self, *args, **kwargs)
            
            from saf3ai_sdk.core.tracer import get_conversation_id_unified, ensure_conversation_id_on_span, set_conversation_id_unified
            conversation_id = get_conversation_id_unified()
            
            span_name = "openai.chat.completions.create"
            with tracer.start_as_current_span(span_name) as span:
                conversation_id = ensure_conversation_id_on_span(span, conversation_id)
                
                if conversation_id:
                    set_conversation_id_unified(conversation_id, source="openai_llm", update_spans=False, force=False)
                
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                for key, value in custom_attrs.items():
                    if key in ("gen_ai.conversation.id", "conversation_id") and conversation_id:
                        continue
                    span.set_attribute(key, value)
                
                try:
                    import os
                    client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
                    if client_data_capture_enabled and span.is_recording():
                        from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                        client_data = extract_comprehensive_client_data()
                        if client_data.get('ip_address') or client_data.get('user_agent'):
                            _add_client_data_to_span(span, client_data)
                except Exception as e:
                    logger.debug(f"Could not extract client data in OpenAI instrumentation: {e}")
                
                messages = kwargs.get('messages', args[0] if args else [])
                prompt_text = None
                if messages:
                    if _is_custom_framework_context():
                        for msg in reversed(messages):
                            if isinstance(msg, dict) and msg.get('role') == 'user':
                                content = msg.get('content', '')
                                if isinstance(content, str) and content.strip():
                                    prompt_text = content.strip()
                                else:
                                    try:
                                        prompt_text = str(content).strip()
                                    except Exception:
                                        prompt_text = None
                                break
                    else:
                        user_messages = [msg.get('content', '') for msg in messages if isinstance(msg, dict) and msg.get('role') == 'user']
                        prompt_text = " ".join(user_messages)
                    if prompt_text:
                        span.set_attribute("llm.prompt", prompt_text)
                
                if 'model' in kwargs:
                    span.set_attribute("llm.model", kwargs['model'])
                
                if prompt_text and ENABLE_AUTO_THREAT_DETECTION:
                    try:
                        from saf3ai_sdk.core.traceable import _get_global_security_callbacks
                        prompt_callback, _ = _get_global_security_callbacks()
                        scan_results = None
                        should_allow = True
                        if prompt_callback:
                            logger.debug(f"Scanning OpenAI prompt ({len(prompt_text)} chars)")
                            try:
                                callback_result = prompt_callback(prompt_text)
                                scan_results, should_allow = _normalize_security_callback_result(callback_result)
                            except ValueError:
                                raise
                            except Exception as e:
                                logger.error(f"Prompt scan error: {e}", exc_info=True)
                        else:
                            if _is_custom_framework_context():
                                try:
                                    from saf3ai_sdk.callbacks.callbacks import get_callback_manager
                                    callback_manager = get_callback_manager()
                                    if callback_manager and callback_manager.security_callback and callback_manager.security_callback.enabled:
                                        scan_results, should_allow = callback_manager.scan_before_llm(
                                            prompt=prompt_text,
                                            model_name=kwargs.get("model", "unknown"),
                                            conversation_id=conversation_id,
                                            metadata={"source": "openai_instrumentation"},
                                        )
                                except Exception as e:
                                    logger.debug(f"Could not run callback manager scan in OpenAI instrumentation: {e}")

                        if isinstance(scan_results, dict):
                            threats_found = _extract_threats_from_scan_results(scan_results)
                            span.set_attribute("security.prompt_scan.enabled", True)
                            span.set_attribute("security.prompt_threats_found", len(threats_found) > 0)
                            span.set_attribute("security.prompt_threat_count", len(threats_found))
                            span.set_attribute("security.threats_found", len(threats_found) > 0)
                            span.set_attribute("security.threat_count", len(threats_found))
                            if threats_found:
                                threat_csv = ",".join(threats_found)
                                span.set_attribute("security.prompt_threat_types", threat_csv)
                                span.set_attribute("security.threat_types", threat_csv)
                                span.set_attribute("security.conversation.threat_detected", True)
                                span.set_attribute("security.conversation.threat_count", len(threats_found))
                                span.set_attribute("security.conversation.severity", "critical")
                                logger.warning(f"Threats detected in prompt: {threat_csv}")
                        if not should_allow:
                            span.set_attribute("security.user_decision", "block")
                            span.set_attribute("security.blocked_by", "user_callback")
                            span.set_status(Status(StatusCode.ERROR, "Security violation detected"))
                            raise ValueError("Security policy blocked request")
                    except Exception as e:
                        logger.debug(f"Could not get global security callbacks: {e}")
                
                try:
                    result = original_create(self, *args, **kwargs)
                    span.set_status(Status(StatusCode.OK))
                    
                    try:
                        if hasattr(result, 'usage') and result.usage:
                            usage = result.usage
                            if hasattr(usage, 'prompt_tokens') and usage.prompt_tokens is not None:
                                span.set_attribute("gen_ai.usage.input_tokens", usage.prompt_tokens)
                            if hasattr(usage, 'completion_tokens') and usage.completion_tokens is not None:
                                span.set_attribute("gen_ai.usage.output_tokens", usage.completion_tokens)
                            if hasattr(usage, 'total_tokens') and usage.total_tokens is not None:
                                span.set_attribute("gen_ai.usage.total_tokens", usage.total_tokens)
                        if hasattr(result, 'model') and result.model:
                            span.set_attribute("gen_ai.response.model", result.model)
                    except Exception as e:
                        logger.debug(f"Could not extract token usage from OpenAI response: {e}")
                    
                    response_text = None
                    if hasattr(result, 'choices') and result.choices:
                        response_text = result.choices[0].message.content if hasattr(result.choices[0].message, 'content') else ""
                    
                    if response_text and ENABLE_AUTO_THREAT_DETECTION:
                        try:
                            from saf3ai_sdk.core.traceable import _get_global_security_callbacks
                            _, response_callback = _get_global_security_callbacks()
                            if response_callback:
                                logger.debug(f"Scanning OpenAI response ({len(response_text)} chars)")
                                try:
                                    scan_results = response_callback(response_text)
                                    if isinstance(scan_results, dict):
                                        detection_results = scan_results.get("detection_results", {})
                                        threats_found = [k for k, v in detection_results.items() 
                                                       if v.get("result") == "MATCH_FOUND"]
                                        span.set_attribute("security.response_scan.enabled", True)
                                        span.set_attribute("security.response_threats_found", len(threats_found) > 0)
                                        span.set_attribute("security.response_threat_count", len(threats_found))
                                        if threats_found:
                                            span.set_attribute("security.response_threat_types", ",".join(threats_found))
                                            logger.warning(f"Threats detected in response: {', '.join(threats_found)}")
                                            span.set_attribute("security.response.threat_detected", True)
                                            span.set_attribute("llm.response", response_text)
                                        else:
                                            logger.debug("Response scan passed")
                                except Exception as e:
                                    logger.error(f"Response scan error: {e}", exc_info=True)
                        except Exception as e:
                            logger.debug(f"Could not get global security callbacks: {e}")
                    
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    raise
        
        async def instrumented_acreate(self, *args, **kwargs):
            """Instrumented ChatCompletion.acreate with telemetry."""
            if not original_acreate:
                raise AttributeError("Completions.acreate is not available in this OpenAI SDK version")
            if not saf3ai_tracer_core.initialized:
                return await original_acreate(self, *args, **kwargs)
            
            from saf3ai_sdk.core.tracer import get_conversation_id_unified, ensure_conversation_id_on_span, set_conversation_id_unified
            conversation_id = get_conversation_id_unified()
            
            span_name = "openai.chat.completions.acreate"
            with tracer.start_as_current_span(span_name) as span:
                conversation_id = ensure_conversation_id_on_span(span, conversation_id)
                
                if conversation_id:
                    set_conversation_id_unified(conversation_id, source="openai_llm_async", update_spans=False, force=False)
                
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                for key, value in custom_attrs.items():
                    if key in ("gen_ai.conversation.id", "conversation_id") and conversation_id:
                        continue
                    span.set_attribute(key, value)
                
                try:
                    import os
                    client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
                    if client_data_capture_enabled and span.is_recording():
                        from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                        client_data = extract_comprehensive_client_data()
                        if client_data.get('ip_address') or client_data.get('user_agent'):
                            _add_client_data_to_span(span, client_data)
                except Exception as e:
                    logger.debug(f"Could not extract client data in OpenAI async instrumentation: {e}")
                
                messages = kwargs.get('messages', args[0] if args else [])
                prompt_text = None
                if messages:
                    if _is_custom_framework_context():
                        for msg in reversed(messages):
                            if isinstance(msg, dict) and msg.get('role') == 'user':
                                content = msg.get('content', '')
                                if isinstance(content, str) and content.strip():
                                    prompt_text = content.strip()
                                else:
                                    try:
                                        prompt_text = str(content).strip()
                                    except Exception:
                                        prompt_text = None
                                break
                    else:
                        user_messages = [msg.get('content', '') for msg in messages if isinstance(msg, dict) and msg.get('role') == 'user']
                        prompt_text = " ".join(user_messages)
                    if prompt_text:
                        span.set_attribute("llm.prompt", prompt_text)
                
                if 'model' in kwargs:
                    span.set_attribute("llm.model", kwargs['model'])
                
                if prompt_text and ENABLE_AUTO_THREAT_DETECTION:
                    try:
                        from saf3ai_sdk.core.traceable import _get_global_security_callbacks
                        prompt_callback, _ = _get_global_security_callbacks()
                        scan_results = None
                        should_allow = True
                        if prompt_callback:
                            logger.debug(f"Scanning OpenAI async prompt ({len(prompt_text)} chars)")
                            try:
                                callback_result = prompt_callback(prompt_text)
                                scan_results, should_allow = _normalize_security_callback_result(callback_result)
                            except ValueError:
                                raise
                            except Exception as e:
                                logger.error(f"Prompt scan error: {e}", exc_info=True)
                        else:
                            if _is_custom_framework_context():
                                try:
                                    from saf3ai_sdk.callbacks.callbacks import get_callback_manager
                                    callback_manager = get_callback_manager()
                                    if callback_manager and callback_manager.security_callback and callback_manager.security_callback.enabled:
                                        scan_results, should_allow = callback_manager.scan_before_llm(
                                            prompt=prompt_text,
                                            model_name=kwargs.get("model", "unknown"),
                                            conversation_id=conversation_id,
                                            metadata={"source": "openai_instrumentation_async"},
                                        )
                                except Exception as e:
                                    logger.debug(f"Could not run callback manager scan in OpenAI async instrumentation: {e}")

                        if isinstance(scan_results, dict):
                            threats_found = _extract_threats_from_scan_results(scan_results)
                            span.set_attribute("security.prompt_scan.enabled", True)
                            span.set_attribute("security.prompt_threats_found", len(threats_found) > 0)
                            span.set_attribute("security.prompt_threat_count", len(threats_found))
                            span.set_attribute("security.threats_found", len(threats_found) > 0)
                            span.set_attribute("security.threat_count", len(threats_found))
                            if threats_found:
                                threat_csv = ",".join(threats_found)
                                span.set_attribute("security.prompt_threat_types", threat_csv)
                                span.set_attribute("security.threat_types", threat_csv)
                                span.set_attribute("security.conversation.threat_detected", True)
                                span.set_attribute("security.conversation.threat_count", len(threats_found))
                                span.set_attribute("security.conversation.severity", "critical")
                                logger.warning(f"Threats detected in prompt: {threat_csv}")
                        if not should_allow:
                            span.set_attribute("security.user_decision", "block")
                            span.set_attribute("security.blocked_by", "user_callback")
                            span.set_status(Status(StatusCode.ERROR, "Security violation detected"))
                            raise ValueError("Security policy blocked request")
                    except Exception as e:
                        logger.debug(f"Could not get global security callbacks: {e}")
                
                try:
                    result = await original_acreate(self, *args, **kwargs)
                    span.set_status(Status(StatusCode.OK))
                    
                    try:
                        if hasattr(result, 'usage') and result.usage:
                            usage = result.usage
                            if hasattr(usage, 'prompt_tokens') and usage.prompt_tokens is not None:
                                span.set_attribute("gen_ai.usage.input_tokens", usage.prompt_tokens)
                            if hasattr(usage, 'completion_tokens') and usage.completion_tokens is not None:
                                span.set_attribute("gen_ai.usage.output_tokens", usage.completion_tokens)
                            if hasattr(usage, 'total_tokens') and usage.total_tokens is not None:
                                span.set_attribute("gen_ai.usage.total_tokens", usage.total_tokens)
                        if hasattr(result, 'model') and result.model:
                            span.set_attribute("gen_ai.response.model", result.model)
                    except Exception as e:
                        logger.debug(f"Could not extract token usage from OpenAI async response: {e}")
                    
                    response_text = None
                    if hasattr(result, 'choices') and result.choices:
                        response_text = result.choices[0].message.content if hasattr(result.choices[0].message, 'content') else ""
                    
                    if response_text and ENABLE_AUTO_THREAT_DETECTION:
                        try:
                            from saf3ai_sdk.core.traceable import _get_global_security_callbacks
                            _, response_callback = _get_global_security_callbacks()
                            if response_callback:
                                logger.info(f"🔍 Automatically scanning OpenAI async response ({len(response_text)} chars)")
                                try:
                                    scan_results = response_callback(response_text)
                                    if isinstance(scan_results, dict):
                                        detection_results = scan_results.get("detection_results", {})
                                        threats_found = [k for k, v in detection_results.items() 
                                                       if v.get("result") == "MATCH_FOUND"]
                                        span.set_attribute("security.response_scan.enabled", True)
                                        span.set_attribute("security.response_threats_found", len(threats_found) > 0)
                                        span.set_attribute("security.response_threat_count", len(threats_found))
                                        if threats_found:
                                            span.set_attribute("security.response_threat_types", ",".join(threats_found))
                                            logger.warning(f"⚠️ Threats detected in async response: {', '.join(threats_found)}")
                                            span.set_attribute("security.response.threat_detected", True)
                                            span.set_attribute("llm.response", response_text)
                                        else:
                                            logger.info("✅ Async response scan passed - no threats detected")
                                except Exception as e:
                                    logger.error(f"Async response scan error: {e}", exc_info=True)
                        except Exception as e:
                            logger.debug(f"Could not get global security callbacks: {e}")
                    
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    raise
        
        completions.Completions.create = instrumented_create
        if original_acreate:
            instrumented_acreate = functools.wraps(original_acreate)(instrumented_acreate)
            completions.Completions.acreate = instrumented_acreate
        completions.Completions._saf3ai_instrumented = True
        logger.info("✅ Successfully instrumented OpenAI ChatCompletions")
        return True
    
    except ImportError:
        logger.warning("OpenAI not found. Skipping OpenAI instrumentation.")
        return False
    except Exception as e:
        logger.error(f"❌ Failed to instrument OpenAI: {e}")
        return False


def instrument_openai(tracer, config=None):
    """
    Auto-instrument OpenAI SDK. Ensures patches are applied only once.
    
    Args:
        tracer: The OTel Tracer instance (from saf3ai_tracer_core.get_tracer())
        config: Optional SDK Config instance
    
    Note:
        Automatic threat detection is enabled by default but can be disabled:
        - Set environment variable: SAF3AI_OPENAI_AUTO_SCAN=false
        - Or set: openai_instrumentation.ENABLE_AUTO_THREAT_DETECTION = False
    """
    global _sdk_config
    
    if config:
        _sdk_config = config
        logger.debug("Stored SDK config for OpenAI instrumentation")
    
    results = {
        "chat_completions_instrumentation": False,
    }
    
    logger.info("🔧 Starting OpenAI auto-instrumentation...")
    
    # Log feature flag status
    if ENABLE_AUTO_THREAT_DETECTION:
        logger.info("✅ Automatic threat detection in OpenAI instrumentation: ENABLED (trial feature)")
    else:
        logger.info("⚠️ Automatic threat detection in OpenAI instrumentation: DISABLED")
    
    results["chat_completions_instrumentation"] = _patch_openai_chat_completions(tracer)
    
    logger.info(f"🎯 OpenAI auto-instrumentation complete: {results}")
    return results

