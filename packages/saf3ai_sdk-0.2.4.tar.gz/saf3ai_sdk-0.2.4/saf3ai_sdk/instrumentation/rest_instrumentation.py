"""Auto-instrumentation for REST/custom agents."""

from saf3ai_sdk.logging import logger

_sdk_config = None


def instrument_rest(tracer, config=None):
    """Auto-instrument REST API."""
    global _sdk_config
    if config:
        _sdk_config = config
    results = {"rest_instrumentation": True, "openai_instrumentation": False}
    try:
        from .openai_instrumentation import instrument_openai
        openai_results = instrument_openai(tracer, config)
        if isinstance(openai_results, dict):
            results["openai_instrumentation"] = bool(
                openai_results.get("chat_completions_instrumentation")
            )
        else:
            results["openai_instrumentation"] = bool(openai_results)
    except Exception as e:
        logger.debug(f"OpenAI instrumentation skipped in rest/custom flow: {e}")
    return results
