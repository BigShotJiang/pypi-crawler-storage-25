"""
Auto-instrumentation for LangChain chains and LLMs.

This module automatically patches LangChain classes to add Saf3AI telemetry
(OpenTelemetry spans and attributes) without requiring manual callback attachment.

ROBUST CONVERSATION ID PROPAGATION:

1. Checks custom attributes FIRST (highest priority) - respects app-provided IDs
2. Checks parent span attributes - propagates conversation_id down the chain
3. Sets conversation_id on all spans - ensures proper stitching
4. Never overwrites existing IDs - respects what's already set

This works seamlessly with the callback system to ensure conversation stitching.
"""

import functools
import logging
import threading
from typing import Any, Dict, Optional, List
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode
from saf3ai_sdk.logging import logger
from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core

# Global storage for SDK config
_sdk_config = None

# Global storage for Current LangChain Span (for callbacks to access)
# This stores the main chain/LLM span that gets exported to OTEL collector
_current_langchain_span = threading.local()

# Use unified conversation ID helper from core.tracer
from saf3ai_sdk.core.tracer import get_conversation_id_unified as _get_conversation_id_for_span

def _set_gen_ai_usage_attributes(span, usage: Dict[str, Any]) -> None:
    """Normalize token usage keys and set GenAI usage attributes."""
    if not span or not usage or not isinstance(usage, dict):
        return

    input_tokens = (
        usage.get("prompt_tokens")
        or usage.get("input_tokens")
        or usage.get("prompt_token_count")
        or usage.get("input_token_count")
    )
    output_tokens = (
        usage.get("completion_tokens")
        or usage.get("output_tokens")
        or usage.get("candidates_token_count")
        or usage.get("output_token_count")
    )
    total_tokens = usage.get("total_tokens") or usage.get("total_token_count")

    if total_tokens is None and input_tokens is not None and output_tokens is not None:
        try:
            total_tokens = int(input_tokens) + int(output_tokens)
        except Exception:
            total_tokens = None

    if input_tokens is not None:
        span.set_attribute("gen_ai.usage.input_tokens", input_tokens)
    if output_tokens is not None:
        span.set_attribute("gen_ai.usage.output_tokens", output_tokens)
    if total_tokens is not None:
        span.set_attribute("gen_ai.usage.total_tokens", total_tokens)


def _extract_and_set_token_usage(span, result) -> None:
    """Extract token usage across LangChain/CrewAI variants and set span attributes."""
    if not span or result is None:
        return

    usage_candidate = None
    model_name = None

    # Primary path: llm_output on LLMResult
    llm_output = getattr(result, "llm_output", None)
    if isinstance(llm_output, dict):
        usage_candidate = (
            llm_output.get("token_usage")
            or llm_output.get("usage")
            or llm_output.get("usage_metadata")
        )
        model_name = llm_output.get("model_name") or llm_output.get("model")

    # Fallback path: usage metadata on first generation message
    if not usage_candidate:
        generations = getattr(result, "generations", None)
        if generations and isinstance(generations, list) and generations[0]:
            first_generation = generations[0][0]
            message = getattr(first_generation, "message", None)
            if message is not None:
                usage_candidate = getattr(message, "usage_metadata", None) or getattr(message, "usage", None)
                model_name = model_name or getattr(message, "response_metadata", {}).get("model_name")

    if isinstance(usage_candidate, dict):
        _set_gen_ai_usage_attributes(span, usage_candidate)
    elif usage_candidate is not None:
        try:
            _set_gen_ai_usage_attributes(span, dict(usage_candidate))
        except Exception:
            pass

    if model_name:
        span.set_attribute("gen_ai.response.model", model_name)

def _patch_llm_chain(tracer):
    """
    Patch LangChain LLMChain to automatically add Saf3AI callbacks.
    
    This patches the __call__ method to wrap execution with telemetry spans.
    """
    try:
        # Try newer LangChain import path first
        try:
            from langchain.chains import LLMChain
        except ImportError:
            # Try alternative import path for different LangChain versions
            from langchain.chains.llm import LLMChain
        
        if hasattr(LLMChain, '_saf3ai_instrumented_chain'):
            logger.debug("LLMChain already instrumented.")
            return True
        
        original_call = LLMChain.__call__
        
        @functools.wraps(original_call)
        def instrumented_call(self, inputs: Any, return_only_outputs: bool = False, **kwargs: Any):
            """Instrumented LLMChain.__call__ with telemetry."""
            if not saf3ai_tracer_core.initialized:
                return original_call(self, inputs, return_only_outputs=return_only_outputs, **kwargs)
            
            otel_tracer = tracer
            span_name = f"langchain.chain.{self.__class__.__name__}"
            
            # CRITICAL: Get conversation_id BEFORE creating new span
            # This ensures conversation_id propagates from parent/custom attributes
            # Works for both Streamlit (UUID) and LangChain agents (trace_id)
            conversation_id = _get_conversation_id_for_span()
            
            with otel_tracer.start_as_current_span(span_name) as span:
                try:
                    # Store the chain span globally so callbacks can access it
                    _current_langchain_span.span = span
                    
                    # CRITICAL: Ensure conversation_id on span using unified helper
                    # This ensures all spans in the same conversation share the same ID
                    from saf3ai_sdk.core.tracer import ensure_conversation_id_on_span, set_conversation_id_unified
                    conversation_id = ensure_conversation_id_on_span(span, conversation_id)
                    
                    # CRITICAL: Store conversation_id in unified store so child spans inherit it
                    if conversation_id:
                        set_conversation_id_unified(conversation_id, source="langchain_chain", update_spans=False, force=False)
                        logger.debug(f"Set conversation_id from parent/custom: {conversation_id}")
                except Exception as e:
                    logger.warning(f"Error setting conversation_id on span: {e}", exc_info=False)
                
                # Add custom attributes (includes agent_id, framework, and any user-set attributes)
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                for key, value in custom_attrs.items():
                    # Don't overwrite conversation_id if already set from parent/custom
                    if key in ("gen_ai.conversation.id", "conversation_id") and conversation_id:
                        continue
                    span.set_attribute(key, value)
                
                # AUTOMATIC CLIENT DATA CAPTURE: Extract and add client data automatically
                try:
                    import os
                    client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
                    if client_data_capture_enabled and span.is_recording():
                        from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                        client_data = extract_comprehensive_client_data()
                        if client_data.get('ip_address') or client_data.get('user_agent'):
                            _add_client_data_to_span(span, client_data)
                except Exception as e:
                    logger.debug(f"Could not extract client data in LangChain instrumentation: {e}")
                
                # Add chain metadata
                span.set_attribute("langchain.chain.type", self.__class__.__name__)
                if hasattr(self, 'llm') and hasattr(self.llm, 'model_name'):
                    span.set_attribute("langchain.llm.model", str(self.llm.model_name))
                if hasattr(self, 'prompt') and hasattr(self.prompt, 'template'):
                    span.set_attribute("langchain.prompt.template", str(self.prompt.template))
                
                # Extract input text for scanning
                input_text = str(inputs) if inputs else ""
                if isinstance(inputs, dict):
                    input_text = inputs.get('input', inputs.get('query', str(inputs)))
                
                span.set_attribute("langchain.input", str(input_text))
                
                try:
                    result = original_call(self, inputs, return_only_outputs=return_only_outputs, **kwargs)
                    
                    # Extract output text
                    output_text = str(result) if result else ""
                    if isinstance(result, dict):
                        output_text = result.get('output', result.get('text', str(result)))
                    
                    span.set_attribute("langchain.output", str(output_text))
                    span.set_status(Status(StatusCode.OK))
                    
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    span.set_attribute("error.type", type(e).__name__)
                    raise
        
        setattr(LLMChain, '__call__', instrumented_call)
        setattr(LLMChain, '_saf3ai_instrumented_chain', True)
        logger.debug("✅ Successfully instrumented LLMChain")
        return True
        
    except ImportError:
        # LLMChain not found - this is normal when using ChatOpenAI directly
        logger.debug("LLMChain not found. Skipping LLMChain instrumentation (not needed for ChatOpenAI).")
        return False
    except Exception as e:
        logger.debug(f"LLMChain instrumentation skipped: {e}")
        return False

def _patch_base_llm(tracer):
    """
    Patch LangChain BaseLLM to automatically add telemetry.
    
    This patches the _call and _generate methods to capture LLM calls.
    """
    try:
        # Try newer LangChain import path first
        try:
            from langchain.llms.base import BaseLLM
        except ImportError:
            # Try alternative import path for different LangChain versions
            try:
                from langchain_core.language_models.llms import BaseLLM
            except ImportError:
                from langchain.llms import BaseLLM
        
        if hasattr(BaseLLM, '_saf3ai_instrumented_llm'):
            logger.debug("BaseLLM already instrumented.")
            return True
        
        original_generate = BaseLLM.generate
        original_agenerate = None
        if hasattr(BaseLLM, 'agenerate'):
            original_agenerate = BaseLLM.agenerate
        
        @functools.wraps(original_generate)
        def instrumented_generate(self, prompts: List[str], stop: Optional[List[str]] = None, **kwargs: Any):
            """Instrumented BaseLLM.generate with telemetry."""
            if not saf3ai_tracer_core.initialized:
                return original_generate(self, prompts, stop=stop, **kwargs)
            
            otel_tracer = tracer
            span_name = f"langchain.llm.{self.__class__.__name__}.generate"
            
            # CRITICAL: Get conversation_id BEFORE creating new span
            # This ensures conversation_id propagates from parent/custom attributes
            conversation_id = _get_conversation_id_for_span()
            
            with otel_tracer.start_as_current_span(span_name) as span:
                try:
                    # Store the LLM span globally so callbacks can access it
                    _current_langchain_span.span = span
                    
                    # Set conversation ID if we have it
                    # This ensures all spans in the same conversation share the same ID
                    # Use unified helper to ensure conversation_id on span
                    from saf3ai_sdk.core.tracer import ensure_conversation_id_on_span, set_conversation_id_unified
                    conversation_id = ensure_conversation_id_on_span(span, conversation_id)
                    
                    # CRITICAL: Store conversation_id in unified store so child spans inherit it
                    if conversation_id:
                        set_conversation_id_unified(conversation_id, source="langchain_llm", update_spans=False, force=False)
                        logger.debug(f"Set conversation_id from parent/custom: {conversation_id}")
                except Exception as e:
                    logger.warning(f"Error setting conversation_id on span: {e}", exc_info=False)
                
                # Add custom attributes
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                for key, value in custom_attrs.items():
                    if key in ("gen_ai.conversation.id", "conversation_id") and conversation_id:
                        continue
                    span.set_attribute(key, value)
                
                # Add LLM metadata
                span.set_attribute("langchain.llm.type", self.__class__.__name__)
                if hasattr(self, 'model_name'):
                    span.set_attribute("langchain.llm.model", str(self.model_name))
                if hasattr(self, 'temperature'):
                    span.set_attribute("langchain.llm.temperature", float(self.temperature))
                
                # Add prompt information
                if prompts:
                    combined_prompt = " ".join(prompts)
                    span.set_attribute("langchain.prompt", str(combined_prompt))
                    span.set_attribute("langchain.prompt_count", len(prompts))
                
                try:
                    result = original_generate(self, prompts, stop=stop, **kwargs)
                    
                    # Add generation metadata
                    if hasattr(result, 'generations') and result.generations:
                        generation_texts = []
                        for gen_list in result.generations:
                            for gen in gen_list:
                                if hasattr(gen, 'text'):
                                    generation_texts.append(gen.text)
                        
                        if generation_texts:
                            combined_output = " ".join(generation_texts)
                            span.set_attribute("langchain.output", str(combined_output))
                            span.set_attribute("langchain.generation_count", len(generation_texts))
                    
                    # Extract token usage from LangChain/CrewAI result formats
                    try:
                        _extract_and_set_token_usage(span, result)
                    except Exception as e:
                        logger.debug(f"Could not extract token usage from LangChain LLMResult: {e}")
                    
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    span.set_attribute("error.type", type(e).__name__)
                    raise
        
        setattr(BaseLLM, 'generate', instrumented_generate)
        
        # Patch async generate if available
        if original_agenerate:
            @functools.wraps(original_agenerate)
            async def instrumented_agenerate(self, prompts: List[str], stop: Optional[List[str]] = None, **kwargs: Any):
                """Instrumented BaseLLM.agenerate with telemetry."""
                if not saf3ai_tracer_core.initialized:
                    return await original_agenerate(self, prompts, stop=stop, **kwargs)
                
                otel_tracer = tracer
                span_name = f"langchain.llm.{self.__class__.__name__}.agenerate"
                
                conversation_id = _get_conversation_id_for_span()
                
                with otel_tracer.start_as_current_span(span_name) as span:
                    _current_langchain_span.span = span
                    
                    # Use unified helper to ensure conversation_id on span
                    from saf3ai_sdk.core.tracer import ensure_conversation_id_on_span, set_conversation_id_unified
                    conversation_id = ensure_conversation_id_on_span(span, conversation_id)
                    
                    # CRITICAL: Store conversation_id in unified store so child spans inherit it
                    if conversation_id:
                        set_conversation_id_unified(conversation_id, source="langchain_llm_agenerate", update_spans=False, force=False)
                    
                    custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                    for key, value in custom_attrs.items():
                        if key in ("gen_ai.conversation.id", "conversation_id") and conversation_id:
                            continue
                        span.set_attribute(key, value)
                    
                    span.set_attribute("langchain.llm.type", self.__class__.__name__)
                    if hasattr(self, 'model_name'):
                        span.set_attribute("langchain.llm.model", str(self.model_name))
                    if prompts:
                        combined_prompt = " ".join(prompts)
                        span.set_attribute("langchain.prompt", str(combined_prompt))
                    
                    try:
                        result = await original_agenerate(self, prompts, stop=stop, **kwargs)
                        
                        # Extract token usage from LangChain/CrewAI result formats
                        try:
                            _extract_and_set_token_usage(span, result)
                        except Exception as e:
                            logger.debug(f"Could not extract token usage from LangChain async LLMResult: {e}")
                        
                        span.set_status(Status(StatusCode.OK))
                        return result
                    except Exception as e:
                        span.set_status(Status(StatusCode.ERROR, str(e)))
                        span.set_attribute("error.message", str(e))
                        raise
            
            setattr(BaseLLM, 'agenerate', instrumented_agenerate)
        
        setattr(BaseLLM, '_saf3ai_instrumented_llm', True)
        logger.debug("✅ Successfully instrumented BaseLLM")
        return True
        
    except ImportError:
        # BaseLLM not found - this is normal when using ChatOpenAI directly
        logger.debug("BaseLLM not found. Skipping BaseLLM instrumentation (not needed for ChatOpenAI).")
        return False
    except Exception as e:
        logger.debug(f"BaseLLM instrumentation skipped: {e}")
        return False

def _patch_chat_models(tracer):
    """
    Patch LangChain ChatModels to automatically add telemetry.
    
    This patches ChatOpenAI, ChatAnthropic, etc. to capture chat model calls.
    """
    try:
        # Try newer LangChain import path first
        try:
            from langchain.chat_models.base import BaseChatModel
        except ImportError:
            # Try alternative import path for different LangChain versions
            try:
                from langchain_core.language_models.chat_models import BaseChatModel
            except ImportError:
                from langchain.chat_models import BaseChatModel
        
        if hasattr(BaseChatModel, '_saf3ai_instrumented_chat'):
            logger.debug("BaseChatModel already instrumented.")
            return True
        
        original_generate = BaseChatModel.generate
        original_agenerate = None
        if hasattr(BaseChatModel, 'agenerate'):
            original_agenerate = BaseChatModel.agenerate
        
        @functools.wraps(original_generate)
        def instrumented_generate(self, messages: List[Any], stop: Optional[List[str]] = None, **kwargs: Any):
            """Instrumented BaseChatModel.generate with telemetry."""
            if not saf3ai_tracer_core.initialized:
                return original_generate(self, messages, stop=stop, **kwargs)
            
            otel_tracer = tracer
            span_name = f"langchain.chat.{self.__class__.__name__}.generate"
            
            # CRITICAL: Get conversation_id BEFORE creating new span
            # This ensures conversation_id propagates from parent/custom attributes
            conversation_id = _get_conversation_id_for_span()
            
            with otel_tracer.start_as_current_span(span_name) as span:
                try:
                    # Store the chat model span globally so callbacks can access it
                    _current_langchain_span.span = span
                    
                    # Set conversation ID if we have it
                    # This ensures all spans in the same conversation share the same ID
                    # Use unified helper to ensure conversation_id on span
                    from saf3ai_sdk.core.tracer import ensure_conversation_id_on_span, set_conversation_id_unified
                    conversation_id = ensure_conversation_id_on_span(span, conversation_id)
                    
                    # CRITICAL: Store conversation_id in unified store so child spans inherit it
                    if conversation_id:
                        set_conversation_id_unified(conversation_id, source="langchain_chat_generate", update_spans=False, force=False)
                        logger.debug(f"Set conversation_id from parent/custom: {conversation_id}")
                except Exception as e:
                    logger.warning(f"Error setting conversation_id on span: {e}", exc_info=False)
                
                # Add custom attributes
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                for key, value in custom_attrs.items():
                    if key in ("gen_ai.conversation.id", "conversation_id") and conversation_id:
                        continue
                    span.set_attribute(key, value)
                
                span.set_attribute("langchain.chat.type", self.__class__.__name__)
                if hasattr(self, 'model_name'):
                    span.set_attribute("langchain.chat.model", str(self.model_name))
                
                # Extract messages
                if messages:
                    message_texts = []
                    for msg in messages:
                        if hasattr(msg, 'content'):
                            message_texts.append(str(msg.content))
                        elif isinstance(msg, dict):
                            message_texts.append(str(msg.get('content', '')))
                    
                    if message_texts:
                        combined_messages = " ".join(message_texts)
                        span.set_attribute("langchain.messages", str(combined_messages))
                        span.set_attribute("langchain.message_count", len(messages))
                
                try:
                    result = original_generate(self, messages, stop=stop, **kwargs)
                    
                    # Capture response if enabled (default: enabled)
                    try:
                        import os
                        capture_responses = os.getenv("SAF3AI_CAPTURE_RESPONSES", "true").lower() == "true"
                        if capture_responses and result:
                            # Extract response text from result
                            response_text = ""
                            if hasattr(result, 'generations') and result.generations:
                                for gen_list in result.generations:
                                    for gen in gen_list:
                                        if hasattr(gen, 'text'):
                                            response_text += str(gen.text) + "\n"
                                        elif hasattr(gen, 'message') and hasattr(gen.message, 'content'):
                                            response_text += str(gen.message.content) + "\n"
                            
                            if response_text:
                                span.set_attribute("llm.response", response_text.strip())
                                span.set_attribute("llm.response_length", len(response_text.strip()))
                    except Exception as e:
                        logger.debug(f"Error capturing response: {e}")
                    
                    # Extract token usage from LangChain/CrewAI result formats
                    try:
                        _extract_and_set_token_usage(span, result)
                    except Exception as e:
                        logger.debug(f"Could not extract token usage from LangChain ChatModel result: {e}")
                    
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    raise
        
        setattr(BaseChatModel, 'generate', instrumented_generate)
        
        if original_agenerate:
            @functools.wraps(original_agenerate)
            async def instrumented_agenerate(self, messages: List[Any], stop: Optional[List[str]] = None, **kwargs: Any):
                """Instrumented BaseChatModel.agenerate with telemetry."""
                if not saf3ai_tracer_core.initialized:
                    return await original_agenerate(self, messages, stop=stop, **kwargs)
                
                otel_tracer = tracer
                span_name = f"langchain.chat.{self.__class__.__name__}.agenerate"
                
                conversation_id = _get_conversation_id_for_span()
                
                with otel_tracer.start_as_current_span(span_name) as span:
                    try:
                        # Store the chat model span globally so callbacks can access it
                        _current_langchain_span.span = span
                        
                        # Set conversation ID if we have it
                        # This ensures all spans in the same conversation share the same ID
                        # Use unified helper to ensure conversation_id on span
                        from saf3ai_sdk.core.tracer import ensure_conversation_id_on_span, set_conversation_id_unified
                        conversation_id = ensure_conversation_id_on_span(span, conversation_id)
                        
                        # CRITICAL: Store conversation_id in unified store so child spans inherit it
                        if conversation_id:
                            set_conversation_id_unified(conversation_id, source="langchain_chat_agenerate", update_spans=False, force=False)
                            logger.debug(f"Set conversation_id from parent/custom: {conversation_id}")
                    except Exception as e:
                        logger.warning(f"Error setting conversation_id on span: {e}", exc_info=False)
                    
                    # Add custom attributes
                    custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                    for key, value in custom_attrs.items():
                        if key in ("gen_ai.conversation.id", "conversation_id") and conversation_id:
                            continue
                        span.set_attribute(key, value)
                    
                    span.set_attribute("langchain.chat.type", self.__class__.__name__)
                    if hasattr(self, 'model_name'):
                        span.set_attribute("langchain.chat.model", str(self.model_name))
                    
                    try:
                        result = await original_agenerate(self, messages, stop=stop, **kwargs)
                        
                        # Capture response if enabled (default: enabled)
                        try:
                            import os
                            capture_responses = os.getenv("SAF3AI_CAPTURE_RESPONSES", "true").lower() == "true"
                            if capture_responses and result:
                                # Extract response text from result
                                response_text = ""
                                if hasattr(result, 'generations') and result.generations:
                                    for gen_list in result.generations:
                                        for gen in gen_list:
                                            if hasattr(gen, 'text'):
                                                response_text += str(gen.text) + "\n"
                                            elif hasattr(gen, 'message') and hasattr(gen.message, 'content'):
                                                response_text += str(gen.message.content) + "\n"
                                
                                if response_text:
                                    span.set_attribute("llm.response", response_text.strip())
                                    span.set_attribute("llm.response_length", len(response_text.strip()))
                        except Exception as e:
                            logger.debug(f"Error capturing response: {e}")
                        
                        # Extract token usage from LangChain/CrewAI result formats
                        try:
                            _extract_and_set_token_usage(span, result)
                        except Exception as e:
                            logger.debug(f"Could not extract token usage from LangChain async ChatModel: {e}")
                        
                        span.set_status(Status(StatusCode.OK))
                        return result
                    except Exception as e:
                        span.set_status(Status(StatusCode.ERROR, str(e)))
                        span.set_attribute("error.message", str(e))
                        raise
            
            setattr(BaseChatModel, 'agenerate', instrumented_agenerate)
        
        setattr(BaseChatModel, '_saf3ai_instrumented_chat', True)
        logger.debug("✅ Successfully instrumented BaseChatModel (ChatOpenAI, etc.)")
        return True
        
    except ImportError:
        logger.debug("BaseChatModel not found. Skipping ChatModel instrumentation.")
        return False
    except Exception as e:
        logger.debug(f"BaseChatModel instrumentation skipped: {e}")
        return False

def _patch_retrievers(tracer):
    """
    Patch LangChain retrievers to capture retrieved documents and their source files.
    
    This is critical for RAG systems where agents retrieve documents from SharePoint, etc.
    """
    try:
        # Try to import BaseRetriever
        try:
            from langchain_core.retrievers import BaseRetriever
        except ImportError:
            try:
                from langchain.schema import BaseRetriever
            except ImportError:
                logger.debug("BaseRetriever not found, skipping retriever instrumentation")
                return False
        
        if hasattr(BaseRetriever, '_saf3ai_instrumented_retriever'):
            logger.debug("BaseRetriever already instrumented.")
            return True
        
        # Patch get_relevant_documents and invoke methods
        original_get_relevant = None
        original_invoke = None
        
        if hasattr(BaseRetriever, 'get_relevant_documents'):
            original_get_relevant = BaseRetriever.get_relevant_documents
        if hasattr(BaseRetriever, 'invoke'):
            original_invoke = BaseRetriever.invoke
        
        def instrumented_get_relevant(self, query: str, **kwargs: Any):
            """Instrumented get_relevant_documents to track source files.
            
            Automatically tracks documents from:
            1. Direct document objects returned by retriever
            2. OTEL span attributes (if LangChain OTEL instrumentation set them)
            """
            if not saf3ai_tracer_core.initialized:
                return original_get_relevant(self, query, **kwargs) if original_get_relevant else []
            
            current_span = trace.get_current_span()
            if not current_span or not current_span.is_recording():
                return original_get_relevant(self, query, **kwargs) if original_get_relevant else []
            
            try:
                # Call original method to retrieve documents
                documents = original_get_relevant(self, query, **kwargs) if original_get_relevant else []
                
                # Extract and log document metadata using OpenInference conventions
                if documents:
                    try:
                        from saf3ai_sdk.core.metadata_extraction import log_retrieved_documents
                        log_retrieved_documents(documents, span=current_span, query=query)
                    except Exception as e:
                        logger.debug(f"Error logging retrieved documents: {e}")
                
                return documents
            except Exception as e:
                logger.debug(f"Error tracking retriever documents: {e}")
                return original_get_relevant(self, query, **kwargs) if original_get_relevant else []
        
        def instrumented_invoke(self, input: Any, config: Optional[Any] = None, **kwargs: Any):
            """Instrumented invoke to track source files.
            
            Automatically tracks documents from:
            1. Direct document objects returned by retriever
            2. OTEL span attributes (if LangChain OTEL instrumentation set them)
            """
            if not saf3ai_tracer_core.initialized:
                return original_invoke(self, input, config=config, **kwargs) if original_invoke else []
            
            current_span = trace.get_current_span()
            if not current_span or not current_span.is_recording():
                return original_invoke(self, input, config=config, **kwargs) if original_invoke else []
            
            try:
                # Extract query string from input
                query_str = str(input) if input else None
                if isinstance(input, dict):
                    query_str = input.get('query') or input.get('input') or str(input)
                
                # Call original method to retrieve documents
                documents = original_invoke(self, input, config=config, **kwargs) if original_invoke else []
                
                # Extract and log document metadata using OpenInference conventions
                if documents:
                    try:
                        from saf3ai_sdk.core.metadata_extraction import log_retrieved_documents
                        log_retrieved_documents(documents, span=current_span, query=query_str)
                    except Exception as e:
                        logger.debug(f"Error logging retrieved documents: {e}")
                
                return documents
            except Exception as e:
                logger.debug(f"Error tracking retriever documents (invoke): {e}")
                return original_invoke(self, input, config=config, **kwargs) if original_invoke else []
        
        if original_get_relevant:
            setattr(BaseRetriever, 'get_relevant_documents', instrumented_get_relevant)
        if original_invoke:
            setattr(BaseRetriever, 'invoke', instrumented_invoke)
        
        setattr(BaseRetriever, '_saf3ai_instrumented_retriever', True)
        logger.debug("✅ Successfully instrumented BaseRetriever")
        return True
        
    except Exception as e:
        logger.debug(f"Could not instrument retrievers: {e}")
        return False

def instrument_langchain(tracer, config=None):
    """
    Auto-instrument LangChain chains and LLMs. Ensures patches are applied only once.
    
    Args:
        tracer: The OTel Tracer instance (from saf3ai_tracer_core.get_tracer())
        config: Optional SDK Config instance (for error_severity_map access)
    """
    global _sdk_config
    
    # Store config globally for error categorization
    if config:
        _sdk_config = config
        logger.debug("Stored SDK config for LangChain instrumentation")
    
    results = {
        "chain_instrumentation": False,
        "llm_instrumentation": False,
        "chat_model_instrumentation": False,
        "retriever_instrumentation": False,
    }
    
    results["chain_instrumentation"] = _patch_llm_chain(tracer)
    results["llm_instrumentation"] = _patch_base_llm(tracer)
    results["chat_model_instrumentation"] = _patch_chat_models(tracer)
    results["retriever_instrumentation"] = _patch_retrievers(tracer)
    
    successful = [k.replace('_instrumentation', '') for k, v in results.items() if v]
    if successful:
        logger.debug(f"LangChain instrumentation: {', '.join(successful)}")
    return results
