"""
Auto-instrumentation for CrewAI.

CrewAI uses LangChain under the hood, so we leverage LangChain instrumentation.
Additionally, this module patches CrewAI-specific components (Agent, Task, Crew)
to add comprehensive telemetry and conversation tracking.
"""

import functools
import logging
import threading
from typing import Any, Dict, Optional

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

from saf3ai_sdk.logging import logger
from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
from saf3ai_sdk.core.constants import AttributeNames

# Global storage for SDK config
_sdk_config = None

# Global storage for Current CrewAI Span
_current_crewai_span = threading.local()

# Use unified conversation ID helper from core.tracer
from saf3ai_sdk.core.tracer import get_conversation_id_unified as _get_conversation_id_for_span
from saf3ai_sdk.core.tracer import ensure_conversation_id_on_span


def _patch_crewai_agent(tracer):
    """Patch CrewAI Agent class to add telemetry."""
    try:
        from crewai import Agent
        
        if hasattr(Agent, '_saf3ai_instrumented'):
            logger.debug("CrewAI Agent already instrumented.")
            return True
        
        original_execute = getattr(Agent, 'execute', None)
        if not original_execute:
            logger.debug("CrewAI Agent.execute not found, skipping instrumentation")
            return False
        
        @functools.wraps(original_execute)
        def instrumented_execute(self, task: Any, context: Optional[str] = None, **kwargs: Any):
            """Instrumented Agent.execute with telemetry."""
            if not saf3ai_tracer_core.initialized:
                return original_execute(self, task, context=context, **kwargs)
            
            otel_tracer = tracer
            agent_name = getattr(self, 'role', 'unknown') or getattr(self, 'name', 'unknown') or 'unknown'
            span_name = f"crewai.agent.{agent_name}"
            
            conversation_id = _get_conversation_id_for_span()
            
            with otel_tracer.start_as_current_span(span_name) as span:
                try:
                    _current_crewai_span.span = span
                    
                    ensure_conversation_id_on_span(span, conversation_id)
                    
                    # Add CrewAI-specific attributes
                    span.set_attribute("crewai.agent.role", getattr(self, 'role', 'unknown'))
                    span.set_attribute("crewai.agent.goal", getattr(self, 'goal', 'unknown'))
                    span.set_attribute("crewai.agent.backstory", getattr(self, 'backstory', 'unknown'))
                    span.set_attribute("crewai.agent.verbose", getattr(self, 'verbose', False))
                    span.set_attribute("crewai.agent.allow_delegation", getattr(self, 'allow_delegation', False))
                    
                    if task:
                        span.set_attribute("crewai.task.description", getattr(task, 'description', 'unknown'))
                        span.set_attribute("crewai.task.expected_output", getattr(task, 'expected_output', 'unknown'))
                    
                    # Add custom attributes
                    custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                    for key, value in custom_attrs.items():
                        if key in (AttributeNames.GEN_AI_CONVERSATION_ID, AttributeNames.CONVERSATION_ID) and conversation_id:
                            continue
                        span.set_attribute(key, value)
                    
                    # Extract and add client data
                    try:
                        import os
                        client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
                        if client_data_capture_enabled and span.is_recording():
                            from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                            client_data = extract_comprehensive_client_data()
                            if client_data.get('ip_address') or client_data.get('user_agent'):
                                _add_client_data_to_span(span, client_data)
                    except Exception as e:
                        logger.debug(f"Could not extract client data in CrewAI Agent: {e}")
                    
                    # Execute the agent
                    result = original_execute(self, task, context=context, **kwargs)
                    
                    span.set_status(Status(StatusCode.OK))
                    return result
                    
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    span.set_attribute("error.type", type(e).__name__)
                    logger.error(f"Error in CrewAI Agent execution: {e}")
                    raise
                finally:
                    if hasattr(_current_crewai_span, 'span'):
                        delattr(_current_crewai_span, 'span')
        
        Agent.execute = instrumented_execute
        Agent._saf3ai_instrumented = True
        logger.info("✅ CrewAI Agent class instrumented")
        return True
        
    except ImportError:
        logger.debug("CrewAI Agent not available for instrumentation")
        return False
    except Exception as e:
        logger.warning(f"Could not instrument CrewAI Agent: {e}")
        return False


def _patch_crewai_crew(tracer):
    """Patch CrewAI Crew class to add telemetry."""
    try:
        from crewai import Crew
        
        if hasattr(Crew, '_saf3ai_instrumented'):
            logger.debug("CrewAI Crew already instrumented.")
            return True
        
        original_kickoff = getattr(Crew, 'kickoff', None)
        if not original_kickoff:
            logger.debug("CrewAI Crew.kickoff not found, skipping instrumentation")
            return False
        
        @functools.wraps(original_kickoff)
        def instrumented_kickoff(self, inputs: Optional[Dict[str, Any]] = None, **kwargs: Any):
            """Instrumented Crew.kickoff with telemetry."""
            if not saf3ai_tracer_core.initialized:
                return original_kickoff(self, inputs=inputs, **kwargs)
            
            otel_tracer = tracer
            crew_id = getattr(self, 'crew_id', None) or id(self)
            span_name = f"crewai.crew.{crew_id}"
            
            conversation_id = _get_conversation_id_for_span()
            
            with otel_tracer.start_as_current_span(span_name) as span:
                try:
                    _current_crewai_span.span = span
                    
                    # CRITICAL: Ensure conversation_id on span and store in unified store
                    from saf3ai_sdk.core.tracer import set_conversation_id_unified
                    conversation_id = ensure_conversation_id_on_span(span, conversation_id)
                    
                    # CRITICAL: Store conversation_id in unified store so child spans inherit it
                    if conversation_id:
                        set_conversation_id_unified(conversation_id, source="crewai_crew", update_spans=False, force=False)
                    
                    # Add CrewAI-specific attributes
                    agents = getattr(self, 'agents', [])
                    tasks = getattr(self, 'tasks', [])
                    
                    span.set_attribute("crewai.crew.agent_count", len(agents))
                    span.set_attribute("crewai.crew.task_count", len(tasks))
                    
                    if agents:
                        agent_roles = [getattr(agent, 'role', 'unknown') for agent in agents]
                        span.set_attribute("crewai.crew.agent_roles", ",".join(agent_roles))
                    
                    if tasks:
                        task_descriptions = [getattr(task, 'description', 'unknown')[:50] for task in tasks]
                        span.set_attribute("crewai.crew.task_descriptions", " | ".join(task_descriptions))
                    
                    if inputs:
                        span.set_attribute("crewai.crew.inputs", str(inputs)[:500])
                    
                    # Add custom attributes
                    custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                    for key, value in custom_attrs.items():
                        if key in (AttributeNames.GEN_AI_CONVERSATION_ID, AttributeNames.CONVERSATION_ID) and conversation_id:
                            continue
                        span.set_attribute(key, value)
                    
                    # Extract and add client data
                    try:
                        import os
                        client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
                        if client_data_capture_enabled and span.is_recording():
                            from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                            client_data = extract_comprehensive_client_data()
                            if client_data.get('ip_address') or client_data.get('user_agent'):
                                _add_client_data_to_span(span, client_data)
                    except Exception as e:
                        logger.debug(f"Could not extract client data in CrewAI Crew: {e}")
                    
                    # Execute the crew
                    result = original_kickoff(self, inputs=inputs, **kwargs)
                    
                    span.set_status(Status(StatusCode.OK))
                    return result
                    
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    span.set_attribute("error.type", type(e).__name__)
                    logger.error(f"Error in CrewAI Crew execution: {e}")
                    raise
                finally:
                    if hasattr(_current_crewai_span, 'span'):
                        delattr(_current_crewai_span, 'span')
        
        Crew.kickoff = instrumented_kickoff
        Crew._saf3ai_instrumented = True
        logger.info("✅ CrewAI Crew class instrumented")
        return True
        
    except ImportError:
        logger.debug("CrewAI Crew not available for instrumentation")
        return False
    except Exception as e:
        logger.warning(f"Could not instrument CrewAI Crew: {e}")
        return False


def instrument_crewai(tracer, config=None):
    """
    Auto-instrument CrewAI.
    
    Since CrewAI uses LangChain, we apply LangChain instrumentation.
    Additionally, we patch CrewAI-specific components (Agent, Task, Crew).
    
    Args:
        tracer: The OTel Tracer instance (from saf3ai_tracer_core.get_tracer())
        config: Optional SDK Config instance
    
    Returns:
        Dict with instrumentation status
    """
    global _sdk_config
    
    if config:
        _sdk_config = config
        logger.debug("Stored SDK config for CrewAI instrumentation")
    
    instrumentation_results = {
        "crewai_instrumentation": False,
        "langchain_instrumentation": False,
        "crewai_agent_patched": False,
        "crewai_crew_patched": False,
    }
    
    # First, apply LangChain instrumentation (CrewAI uses LangChain)
    try:
        from saf3ai_sdk.instrumentation import instrument_langchain
        langchain_result = instrument_langchain(tracer, config)
        if langchain_result:
            instrumentation_results["langchain_instrumentation"] = True
            logger.info("✅ LangChain instrumentation applied for CrewAI")
    except ImportError:
        logger.warning("LangChain instrumentation not available for CrewAI")
    
    # Patch CrewAI-specific components
    try:
        agent_patched = _patch_crewai_agent(tracer)
        instrumentation_results["crewai_agent_patched"] = agent_patched
        
        crew_patched = _patch_crewai_crew(tracer)
        instrumentation_results["crewai_crew_patched"] = crew_patched
        
        if agent_patched or crew_patched:
            instrumentation_results["crewai_instrumentation"] = True
            logger.info("✅ CrewAI-specific components instrumented")
    except Exception as e:
        logger.warning(f"Could not patch CrewAI components: {e}")
    
    return instrumentation_results

