"""Saf3AI SDK main entry point."""

import os
from typing import Optional, Dict, Union, Any, Literal, Tuple

from saf3ai_sdk.config import Config
from saf3ai_sdk.config.sdk_config import SDKConfig
from saf3ai_sdk.core.tracer import tracer, TracingCore
from saf3ai_sdk.core.auth import auth_manager
from saf3ai_sdk.logging import logger
from saf3ai_sdk.core.constants import AttributeNames, FrameworkMessages


from saf3ai_sdk.core.traceable import traceable, set_global_security_callbacks, set_scanner_config, get_traceable_context

from saf3ai_sdk.scanner import scan_prompt, scan_response, scan_prompt_and_response
from saf3ai_sdk.frameworks import get_framework_adapter, list_supported_frameworks


__all__ = [
    "init",
    "tracer",
    "get_tracer",
    "traceable",
    "set_global_security_callbacks",
    "set_scanner_config",
    "reset_conversation",
    "set_custom_attributes",
    "get_custom_attributes",
    "clear_custom_attributes",
    "create_security_callback",
    "scan_prompt",
    "scan_response",
    "scan_prompt_and_response",
    "get_detected_framework",
    "SDKConfig",
]

def create_security_callback(*args, **kwargs):
    """
    Create ADK security callback for prompt/response scanning.
    
    ⚠️ WARNING: This function is ONLY for ADK framework (framework="adk" or "google-adk").
    
    For 'custom' framework or other frameworks, use create_framework_security_callbacks() instead:
        create_framework_security_callbacks(framework='custom', ...)
    
    This is a lazy import wrapper that only imports ADK callbacks when needed.
    
    Args:
        *args, **kwargs: Arguments passed to adk_callbacks.create_security_callback
        
    Returns:
        ADK security callback function(s)
        
    Raises:
        ImportError: If ADK is not available and this function is called
    """
    # Lazy import - only import when actually needed
    from saf3ai_sdk.callbacks.adk_callbacks import create_security_callback as _create_adk_callback
    return _create_adk_callback(*args, **kwargs)


def get_tracer(name: str = "saf3ai"):
    """
    Get a tracer from the Saf3AI SDK's TracerProvider.
    
    This ensures spans are processed by our span processors.
    
    Args:
        name: Name of the tracer
        
    Returns:
        Tracer instance from our TracerProvider
    """
    return tracer.get_tracer(name)


def set_custom_attributes(attributes: Dict[str, Any]) -> None:
    """Set custom attributes to be added to all future spans."""
    tracer.set_custom_attributes(attributes)


def get_custom_attributes() -> Dict[str, Any]:
    """Get current custom attributes."""
    return tracer.get_custom_attributes()


def clear_custom_attributes() -> None:
    """Clear all custom attributes."""
    tracer.clear_custom_attributes()


def init(
    agent_id: Union[str, SDKConfig] = None,
    api_key: Optional[str] = None,
    safeai_collector_agent: Optional[str] = None,
    service_name: Optional[str] = None,
    api_key_header_name: Optional[str] = None,
    environment: Optional[str] = None,
    safeai_collector_headers: Optional[Dict[str, str]] = None,
    log_level: Optional[Union[str, int]] = None,
    debug_mode: Optional[bool] = None,
    console_output: Optional[bool] = None,
    error_severity_map: Optional[Dict[str, str]] = None,  # Custom severity mapping
    auth_enabled: Optional[bool] = None,
    scanner_endpoint: Optional[str] = None,
    scanner_api_key: Optional[str] = None,
    **kwargs
) -> TracingCore:
    """
    Initialize the Saf3AI SDK.
    
    Configures the global tracer, sets up exporters, and applies
    automatic instrumentation for the detected framework.
    
    The SDK automatically detects which framework is being used (ADK, CrewAI, LangChain, or Custom).
    If a framework is detected but not available, initialization will fail with a warning.
    
    Args:
        agent_id: Either a unique identifier for this agent (alphanumeric, e.g., 'financial-coordinator-b14fd') 
                 OR an SDKConfig object. If SDKConfig is provided, other parameters are ignored.
        api_key: Organization API key for authentication (required if agent_id is a string)
        safeai_collector_agent: Saf3AI Collector endpoint URL (required if agent_id is a string)
        service_name: Name of the service being instrumented (optional, defaults to agent_id)
        api_key_header_name: HTTP header name used for the API key (optional, defaults to 'X-API-Key')
        environment: Environment name (development, staging, production). Default: 'development'
        safeai_collector_headers: Additional headers for Saf3AI Collector requests (e.g., Authorization)
        log_level: Logging level for Saf3AI SDK (DEBUG, INFO, WARNING, ERROR)
        debug_mode: Enable debug logging
        console_output: Print telemetry to console
        error_severity_map: Custom mapping of error categories to severity levels
                            Default: {'security': 'critical', 'operational': 'warning', 
                                     'user_error': 'info', 'unknown': 'error'}
        auth_enabled: Enable or disable SDK-level authentication
        scanner_endpoint: Scanner API endpoint URL. If not provided, automatically reads from 
                         SAF3AI_SCANNER_ENDPOINT environment variable.
        scanner_api_key: Optional override for scanner auth. If omitted, the scanner uses the same
                        API key as the collector (`api_key` / SAF3AI_API_KEY). SAF3AI_SCANNER_API_KEY
                        is still read as a legacy override when set.
        **kwargs: Additional configuration parameters passed to config.configure()
        
    Returns:
        TracingCore: The initialized tracer instance
        
    Raises:
        ValueError: If any required parameter is missing or empty
        RuntimeError: If detected framework is not available/installed
    
    Example:
        ```python
        from saf3ai_sdk import init
        
        # Simple initialization - only required parameters
        init(
            agent_id="agent-123",
            api_key="your-api-key",
            safeai_collector_agent="https://collector.example.com"
        )
        
        # Or using SDKConfig object (recommended for many parameters)
        from saf3ai_sdk.config import SDKConfig
        config = SDKConfig(
            agent_id="agent-123",
            api_key="your-api-key",
            safeai_collector_agent="https://collector.example.com",
            environment="production"
        )
        init(config)
        ```
    """
    
    # Check if first argument is an SDKConfig object
    if isinstance(agent_id, SDKConfig):
        sdk_config = agent_id
        agent_id = sdk_config.agent_id
        api_key = sdk_config.api_key
        safeai_collector_agent = sdk_config.safeai_collector_agent
        service_name = sdk_config.service_name
        api_key_header_name = sdk_config.api_key_header_name
        environment = sdk_config.environment
        safeai_collector_headers = sdk_config.safeai_collector_headers
        log_level = sdk_config.log_level
        debug_mode = sdk_config.debug_mode
        console_output = sdk_config.console_output
        error_severity_map = sdk_config.error_severity_map
        auth_enabled = sdk_config.auth_enabled
        scanner_endpoint = sdk_config.scanner_endpoint
        scanner_api_key = sdk_config.scanner_api_key
    
    # Set defaults for optional parameters
    if not service_name:
        service_name = agent_id  # Use agent_id as default service name
    
    if not api_key_header_name:
        api_key_header_name = "X-API-Key"  # Default header name
    
    # Validate required parameters
    if not agent_id or not agent_id.strip():
        raise ValueError("'agent_id' is required and cannot be empty")
    
    # Auto-detect framework
    framework, detection_error = _auto_detect_framework()
    
    if detection_error:
        raise RuntimeError(f"Framework detection failed: {detection_error}")
    
    if not framework:
        framework = 'custom'
    
    framework_lower = framework.lower().strip()
    
    is_available, availability_error = _check_framework_available(framework)
    if not is_available:
        error_msg = f"Detected framework '{framework}' is not available. {availability_error}"
        logger.error(error_msg)
        raise RuntimeError(error_msg)
    
    logger.info(f"Framework '{framework}' detected and initialized")
    
    # Validate required parameters; allow api_key from environment if not passed
    if not api_key or not api_key.strip():
        api_key = os.getenv("SAF3AI_API_KEY")
    if not api_key or not api_key.strip():
        raise ValueError(
            "'api_key' is required and cannot be empty. "
            "Pass api_key to init() or set SAF3AI_API_KEY environment variable."
        )
    
    if not safeai_collector_agent or not safeai_collector_agent.strip():
        raise ValueError("'safeai_collector_agent' is required and cannot be empty")
    
    config = Config()
    
    config.configure(
        service_name=service_name,  # Uses agent_id as default if not provided
        environment=environment,
        safeai_endpoint=safeai_collector_agent,
        safeai_headers=safeai_collector_headers,
        log_level=log_level,
        debug_mode=debug_mode,
        console_output=console_output,
        error_severity_map=error_severity_map,
        auth_enabled=auth_enabled,
        api_key=api_key,
        api_key_header_name=api_key_header_name,  # Defaults to "X-API-Key" if not provided
        **kwargs
    )
    
    # Store detected framework globally for later use
    global _detected_framework
    _detected_framework = framework
    
    # Set initial custom attributes (agent_id, framework) that are always included
    # Users can add more custom attributes later using set_custom_attributes()
    set_custom_attributes({
        'agent_id': agent_id,
        'framework': framework,
        'saf3ai.framework': framework
    })
    
    auth_manager.configure(
        enabled=config.auth_enabled,
        api_key=config.api_key,
        header_name=config.api_key_header_name,
    )

    # Initialize the core tracer
    tracer.initialize(config)
    
    if config.client_data_capture:
        logger.debug("Automatic client data capture enabled")
        try:
            _setup_automatic_client_data_capture()
        except Exception as e:
            logger.debug(f"Could not set up automatic client data capture middleware: {e}")
    
    # Apply framework-specific auto-instrumentation based on detected framework
    framework_lower = framework.lower().strip()

    if framework_lower in ['adk', 'google-adk']:
        try:
            from saf3ai_sdk.instrumentation import instrument_adk
            instrument_adk(tracer.get_tracer("saf3ai-adk"), config)
        except ImportError as e:
            logger.warning(f"ADK instrumentation not available: {e}")
    elif framework_lower in ['langchain', 'langflow']:
        try:
            from saf3ai_sdk.instrumentation import instrument_langchain
            instrument_langchain(tracer.get_tracer("saf3ai-langchain"), config)
        except ImportError as e:
            logger.warning(f"LangChain instrumentation not available: {e}")
    elif framework_lower in ['crewai', 'crew-ai']:
        try:
            from saf3ai_sdk.instrumentation import instrument_crewai
            instrument_crewai(tracer.get_tracer("saf3ai-crewai"), config)
        except ImportError as e:
            logger.warning(f"CrewAI instrumentation not available: {e}")
    elif framework_lower in ['rest', 'rest-api', 'generic', 'custom']:
        try:
            from saf3ai_sdk.instrumentation import instrument_rest
            instrument_rest(tracer.get_tracer("saf3ai-rest"), config)
        except ImportError as e:
            logger.warning(f"REST API instrumentation not available: {e}")
    
    # Auto-configure scanner from environment if not explicitly provided

    if not scanner_endpoint:
        scanner_endpoint = os.getenv("SAF3AI_SCANNER_ENDPOINT")
    if not scanner_api_key:
        scanner_api_key = os.getenv("SAF3AI_SCANNER_API_KEY")
    if not scanner_api_key:
        scanner_api_key = api_key

    # Configure scanner if endpoint is provided
    if scanner_endpoint:
        from saf3ai_sdk.core.traceable import set_scanner_config
        set_scanner_config(scanner_endpoint=scanner_endpoint, scanner_api_key=scanner_api_key)
        logger.info(f"✅ Scanner configured: {scanner_endpoint}")
    
    logger.info(f"✅ Saf3AI SDK initialized successfully with framework: '{framework}'")
    return tracer


def _setup_automatic_client_data_capture():
    """Set up automatic client data capture middleware for Flask/FastAPI."""
    flask_setup = False
    try:
        from flask import Flask, has_app_context
        import flask
        
        if has_app_context():
            app = flask.current_app
            if app and not hasattr(app, '_saf3ai_client_data_setup'):
                @app.before_request
                def _saf3ai_capture_client_data():
                    from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _set_client_data_in_custom_attrs
                    try:
                        client_data = extract_comprehensive_client_data()
                        if client_data.get('ip_address') or client_data.get('user_agent'):
                            _set_client_data_in_custom_attrs(client_data)
                    except Exception:
                        pass
                
                app._saf3ai_client_data_setup = True
                flask_setup = True
                logger.debug("✅ Automatic client data capture middleware set up for Flask")
    except (ImportError, AttributeError):
        pass
    except Exception as e:
        logger.debug(f"Could not set up Flask middleware: {e}")
    
    if not flask_setup:
        try:
            import sys
            import flask
            for module_name, module in sys.modules.items():
                if hasattr(module, '__dict__'):
                    for obj_name, obj in module.__dict__.items():
                        if isinstance(obj, flask.Flask) and not hasattr(obj, '_saf3ai_client_data_setup'):
                            @obj.before_request
                            def _saf3ai_capture_client_data():
                                from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _set_client_data_in_custom_attrs
                                try:
                                    client_data = extract_comprehensive_client_data()
                                    if client_data.get('ip_address') or client_data.get('user_agent'):
                                        _set_client_data_in_custom_attrs(client_data)
                                except Exception:
                                    pass
                            
                            obj._saf3ai_client_data_setup = True
                            flask_setup = True
                            logger.debug(f"✅ Automatic client data capture middleware set up for Flask app: {obj_name}")
                            break
                    if flask_setup:
                        break
        except Exception as e:
            logger.debug(f"Could not find Flask app in modules: {e}")


def _auto_detect_framework() -> Tuple[Optional[str], Optional[str]]:
    """
    Auto-detect which framework is being used by checking for installed packages.
    
    Detection priority:
    1. Google ADK (google-adk)
    2. CrewAI (checked before LangChain since CrewAI uses LangChain)
    3. LangChain (langchain or langchain_core)
    4. Custom (fallback - no framework detected)
    
    Returns:
        Tuple of (detected_framework, error_message)
        - detected_framework: Framework name if detected, None if custom
        - error_message: None if successful, error message if detection failed
    """
    # Check for Google ADK
    try:
        from google.adk.agents.callback_context import CallbackContext
        from google.adk.models.llm_request import LlmRequest
        logger.info("Auto-detected framework: 'adk' (Google ADK)")
        return ('adk', None)
    except ImportError:
        pass
    
    # Check for CrewAI (BEFORE LangChain since CrewAI uses LangChain)
    # This ensures CrewAI is detected when both are installed
    try:
        from crewai import Agent, Task, Crew
        logger.info(FrameworkMessages.AUTO_DETECTED_FRAMEWORK_CREWAI)
        return ('crewai', None)
    except ImportError:
        pass
    
    # Check for LangChain
    try:
        try:
            from langchain_core.callbacks import BaseCallbackHandler
            logger.info(FrameworkMessages.AUTO_DETECTED_FRAMEWORK_LANGCHAIN)
            return ('langchain', None)
        except ImportError:
            try:
                from langchain.callbacks.base import BaseCallbackHandler
                logger.info(FrameworkMessages.AUTO_DETECTED_FRAMEWORK_LANGCHAIN)
                return ('langchain', None)
            except ImportError:
                try:
                    from langchain.callbacks import BaseCallbackHandler
                    logger.info(FrameworkMessages.AUTO_DETECTED_FRAMEWORK_LANGCHAIN)
                    return ('langchain', None)
                except ImportError:
                    pass
    except Exception as e:
        logger.debug(f"LangChain detection error: {e}")
    
    # No framework detected - use custom
    logger.info(FrameworkMessages.NO_FRAMEWORK_DETECTED)
    return ('custom', None)


def _check_framework_available(framework: str) -> Tuple[bool, Optional[str]]:
    """
    Check if a framework is actually available (not just if adapter exists).
    
    Args:
        framework: Framework name to check
        
    Returns:
        Tuple of (is_available, error_message)
        - is_available: True if framework can be used
        - error_message: None if available, or error message if not available
    """
    framework_lower = framework.lower()
    
    # Generic frameworks don't require specific dependencies - always available
    if framework_lower in ['custom', 'rest', 'rest-api', 'generic']:
        return (True, None)
    
    # Check framework-specific availability
    if framework_lower in ['adk', 'google-adk']:
        try:
            from google.adk.agents.callback_context import CallbackContext
            from google.adk.models.llm_request import LlmRequest
            return (True, None)
        except ImportError:
            return (False, f"Framework '{framework}' is not available. ADK dependencies are not installed.")
    
    elif framework_lower == 'langchain':
        # Use lazy detection - try all possible import paths
        try:
            try:
                from langchain_core.callbacks import BaseCallbackHandler
                return (True, None)
            except ImportError:
                try:
                    from langchain.callbacks.base import BaseCallbackHandler
                    return (True, None)
                except ImportError:
                    try:
                        from langchain.callbacks import BaseCallbackHandler
                        return (True, None)
                    except ImportError:
                        return (False, f"Framework '{framework}' is not available. LangChain is not installed.")
        except Exception as e:
            return (False, f"Framework '{framework}' detection error: {e}")
    
    elif framework_lower in ['crewai', 'crew-ai']:
        try:
            from crewai import Agent, Task, Crew
            return (True, None)
        except ImportError:
            return (False, f"Framework '{framework}' is not available. CrewAI is not installed.")
    
    return (False, f"Framework '{framework}' is not supported. Supported frameworks: adk, langchain, crewai, custom")


# Global variable to store detected framework
_detected_framework: Optional[str] = None


def get_detected_framework() -> Optional[str]:
    """
    Get the framework that was auto-detected during SDK initialization.
    
    Returns:
        Framework name (e.g., 'adk', 'langchain', 'custom') or None if SDK not initialized
    """
    return _detected_framework


def create_framework_security_callbacks(
    api_endpoint: str,
    agent_identifier: str,
    framework: Optional[str] = None,
    api_key: Optional[str] = None,
    timeout: int = 10,
    on_scan_complete: Optional[Any] = None,
    scan_responses: bool = True  # CHANGED: Default to True for automatic response scanning
):
    """
    Create framework-specific security callbacks.
    
    This function automatically detects the framework used in your application
    (CrewAI, LangChain, ADK, etc.) and creates the appropriate security callbacks.
    
    **Framework Auto-Detection (Recommended):**
    The SDK automatically detects your framework during init(). You should NOT
    pass the `framework` parameter unless you have a specific reason to override
    the auto-detected framework.
    
    Example (recommended - no framework parameter):
        callbacks = create_framework_security_callbacks(
            api_endpoint="https://scanner.example.com",
            agent_identifier="my-agent"
        )
    
    Args:
        api_endpoint: URL of the on-prem scanning API
        agent_identifier: Agent identifier for custom guardrails
        framework: **DEPRECATED/RARE USE ONLY** - Framework name override.
                   Leave as None to use auto-detected framework from init().
                   Only specify if you need to override auto-detection.
        api_key: Optional API key for authentication
        timeout: Request timeout in seconds
        on_scan_complete: Optional callback function(text, scan_results, text_type) -> bool
        scan_responses: Whether to also scan responses (default: True for automatic security scanning)
    
    Returns:
        Framework-specific callback(s) - format depends on framework
        Returns None if framework is not available or if there's an error
    """
    if not framework:
        framework = get_detected_framework() or 'custom'
        logger.info(f"Using auto-detected framework: '{framework}' (no framework parameter provided)")
    else:
        logger.debug(f"Using explicitly specified framework: '{framework}'")
    
    if scan_responses is None:
        import os
        scan_responses = os.getenv("SAF3AI_SCAN_RESPONSES", "true").lower() == "true"
    
    # Check if adapter exists
    adapter_class = get_framework_adapter(framework)
    
    if not adapter_class:
        logger.error(f"Unknown framework: '{framework}'. Supported frameworks: {', '.join(sorted(list_supported_frameworks()))}")
        return None
    
    # Check if framework is actually available (skip for generic frameworks like 'custom')
    framework_lower = framework.lower()
    if framework_lower not in ['custom', 'rest', 'rest-api', 'generic']:
        is_available, error_message = _check_framework_available(framework)
        if not is_available:
            logger.error(error_message)
            return None
    
    # Create the adapter instance
    try:
        adapter = adapter_class(
            api_endpoint=api_endpoint,
            agent_identifier=agent_identifier,
            api_key=api_key,
            timeout=timeout,
            on_scan_complete=on_scan_complete
        )
    except Exception as e:
        logger.error(f"Failed to create framework adapter for '{framework}': {e}")
        return None
    
    # Try to create callbacks - handle gracefully if framework isn't available
    try:
        # For ADK, use framework-native callback creation
        if framework.lower() in ['adk', 'google-adk']:
            callback_result = adapter.create_callbacks(scan_responses=scan_responses)
            if callback_result is None:
                logger.error(f"Framework '{framework}' is not available. Cannot create security callbacks.")
                return None
            return callback_result

        # For LangChain/CrewAI, use a single BaseCallbackHandler that supports
        # both prompt and response scanning when scan_responses=True.
        if framework.lower() in ['langchain', 'langflow', 'crewai', 'crew-ai']:
            callback_result = adapter.create_callbacks(scan_responses=scan_responses)
            if callback_result is None:
                logger.error(f"Framework '{framework}' is not available. Cannot create security callbacks.")
                return None
            return callback_result
        
        # For other frameworks, return both callbacks
        prompt_callback = adapter.create_prompt_callback()
        if prompt_callback is None:
            logger.error(f"Framework '{framework}' is not available. Cannot create security callbacks.")
            return None
        
        if scan_responses:
            response_callback = adapter.create_response_callback()
            if response_callback is None:
                logger.warning(f"Could not create response callback for '{framework}', returning prompt callback only")
                # Set global callbacks for automatic integration with @traceable and OpenAI instrumentation
                set_global_security_callbacks(prompt_callback=prompt_callback, response_callback=None)
                return prompt_callback
            set_global_security_callbacks(prompt_callback=prompt_callback, response_callback=response_callback)
            return (prompt_callback, response_callback)
        else:
            set_global_security_callbacks(prompt_callback=prompt_callback, response_callback=None)
            return prompt_callback
    except Exception as e:
        logger.error(f"Failed to create callbacks for framework '{framework}': {e}")
        return None


def reset_session():
    """
    Reset the current persistent session to create a new session.
    Call this when you want to start a new ADK web session.
    This will create a new persistent session ID and clean up old session data.
    """
    try:
        from saf3ai_sdk.instrumentation.adk_instrumentation import reset_persistent_session
        return reset_persistent_session()
    except ImportError:
        logger.debug("ADK instrumentation not available")
        return None


def reset_conversation():
    """Reset the current conversation ID to create a new conversation."""
    custom_attrs = tracer.get_custom_attributes()
    custom_attrs.pop(AttributeNames.GEN_AI_CONVERSATION_ID, None)
    custom_attrs.pop(AttributeNames.CONVERSATION_ID, None)
    tracer.set_custom_attributes(custom_attrs)
    return True


def call_llm_with_saf3ai(
    llm_function: callable,
    prompt: str,
    model_name: str = "unknown",
    conversation_id: Optional[str] = None,
    security_callback: Optional[Any] = None,
    scan_response: bool = False,
    **llm_kwargs
) -> Any:
    """
    Wrapper function for custom LLM calls that automatically handles telemetry and security scanning.
    
    This function works like ADK/LangChain - you just wrap your LLM call and it automatically:
    1. Creates spans for telemetry
    2. Scans prompts/responses for security threats
    3. Sends telemetry to collector
    
    Args:
        llm_function: Your LLM function to call (e.g., openai_client.chat.completions.create)
        prompt: The prompt to send to the LLM
        model_name: Name of the LLM model (e.g., "gpt-4", "claude-3")
        conversation_id: Optional conversation ID for tracking
        security_callback: Optional security callback from create_framework_security_callbacks()
        scan_response: Whether to also scan the LLM response
        **llm_kwargs: Additional arguments to pass to your LLM function
        
    Returns:
        The result from your LLM function
        
    Example:
        ```python
        from saf3ai_sdk import init, create_framework_security_callbacks, call_llm_with_saf3ai
        import openai
        
        # Initialize SDK (framework auto-detected)
        init(service_name="my-service", ...)
        
        # Create security callback (optional)
        prompt_callback = create_framework_security_callbacks(
            framework='custom',
            api_endpoint='https://scanner.example.com',
            agent_identifier='my-agent-id'
        )
        
        # Use your LLM with automatic telemetry and security scanning
        client = openai.OpenAI()
        response = call_llm_with_saf3ai(
            llm_function=lambda p: client.chat.completions.create(
                model="gpt-4",
                messages=[{"role": "user", "content": p}]
            ),
            prompt="Hello, how are you?",
            model_name="gpt-4",
            security_callback=prompt_callback,
            scan_response=True
        )
        ```
    """
    from opentelemetry import trace
    from opentelemetry.trace import Status, StatusCode
    
    if not tracer.initialized:
        logger.warning("SDK not initialized. Call init() first. Executing LLM call without telemetry.")
        return llm_function(prompt, **llm_kwargs)
    
    # Get tracer
    otel_tracer = tracer.get_tracer("saf3ai-custom")
    
    # Get conversation ID from current span or custom attributes if not provided
    if not conversation_id:
        try:
            current_span = trace.get_current_span()
            if current_span and current_span.is_recording():
                conversation_id = current_span.attributes.get(AttributeNames.GEN_AI_CONVERSATION_ID)
            if not conversation_id:
                custom_attrs = tracer.get_custom_attributes()
                conversation_id = custom_attrs.get(AttributeNames.GEN_AI_CONVERSATION_ID) or custom_attrs.get(AttributeNames.CONVERSATION_ID)
        except Exception:
            pass
    
    # Normalize security callbacks:
    # - callable => use for prompt and response
    # - tuple/list => (prompt_callback, response_callback)
    # - dict => {"prompt": fn, "response": fn}
    prompt_security_callback = None
    response_security_callback = None
    if security_callback:
        if callable(security_callback):
            prompt_security_callback = security_callback
            response_security_callback = security_callback
        elif isinstance(security_callback, (tuple, list)):
            if len(security_callback) > 0:
                prompt_security_callback = security_callback[0]
            if len(security_callback) > 1:
                response_security_callback = security_callback[1]
        elif isinstance(security_callback, dict):
            prompt_security_callback = security_callback.get("prompt")
            response_security_callback = security_callback.get("response")

    def _extract_usage_from_llm_response(result: Any) -> Dict[str, Any]:
        """Extract usage across common response shapes for custom/core LLM clients."""
        usage: Dict[str, Any] = {}
        if result is None:
            return usage

        candidate = None
        if isinstance(result, dict):
            candidate = result.get("usage") or result.get("token_usage") or result.get("usage_metadata")
            if candidate is None:
                nested = result.get("response") or result.get("result") or result.get("llm_response")
                if isinstance(nested, dict):
                    candidate = nested.get("usage") or nested.get("token_usage") or nested.get("usage_metadata")
                elif nested is not None:
                    candidate = (
                        getattr(nested, "usage", None)
                        or getattr(nested, "token_usage", None)
                        or getattr(nested, "usage_metadata", None)
                    )
        else:
            candidate = (
                getattr(result, "usage", None)
                or getattr(result, "token_usage", None)
                or getattr(result, "usage_metadata", None)
            )

        if isinstance(candidate, dict):
            usage.update(candidate)
        elif candidate is not None:
            for key in (
                "prompt_tokens", "completion_tokens", "total_tokens",
                "input_tokens", "output_tokens", "prompt_token_count",
                "candidates_token_count", "total_token_count",
            ):
                value = getattr(candidate, key, None)
                if value is not None:
                    usage[key] = value

        return usage

    def _set_usage_attributes(span, usage: Dict[str, Any]) -> None:
        """Normalize and set GenAI usage attributes for cost calculation."""
        if not span or not span.is_recording() or not usage:
            return
        input_tokens = (
            usage.get("prompt_tokens")
            or usage.get("input_tokens")
            or usage.get("prompt_token_count")
            or usage.get("input_token_count")
        )
        output_tokens = (
            usage.get("completion_tokens")
            or usage.get("output_tokens")
            or usage.get("candidates_token_count")
            or usage.get("output_token_count")
        )
        total_tokens = usage.get("total_tokens") or usage.get("total_token_count")
        if total_tokens is None and input_tokens is not None and output_tokens is not None:
            try:
                total_tokens = int(input_tokens) + int(output_tokens)
            except Exception:
                total_tokens = None
        if input_tokens is not None:
            span.set_attribute(AttributeNames.GEN_AI_USAGE_INPUT_TOKENS, input_tokens)
        if output_tokens is not None:
            span.set_attribute(AttributeNames.GEN_AI_USAGE_OUTPUT_TOKENS, output_tokens)
        if total_tokens is not None:
            span.set_attribute(AttributeNames.GEN_AI_USAGE_TOTAL_TOKENS, total_tokens)

    def _extract_threats(scan_results: Dict[str, Any]) -> list:
        """Extract threat keys from scanner response variants."""
        threats_found = []
        if not isinstance(scan_results, dict):
            return threats_found
        detection_results = scan_results.get("detection_results", {})
        if isinstance(detection_results, dict):
            threats_found.extend([k for k, v in detection_results.items() if isinstance(v, dict) and v.get("result") == "MATCH_FOUND"])
        threats = scan_results.get("threats", {})
        if isinstance(threats, dict):
            items = threats.get("items", [])
            if isinstance(items, list):
                for item in items:
                    threat_type = item.get("type") if isinstance(item, dict) else None
                    if threat_type:
                        threats_found.append(str(threat_type))
        return list(dict.fromkeys(threats_found))

    # Create main LLM call span with rich metadata
    import time
    llm_start_time = time.time()
    with otel_tracer.start_as_current_span("llm.call") as llm_span:
        # LLM attributes (single name per value: llm.*, trace.id, gen_ai.conversation.id)
        llm_span.set_attribute("llm.model", model_name)
        llm_span.set_attribute(AttributeNames.LLM_PROMPT_LENGTH, len(prompt))
        llm_span.set_attribute("llm.prompt", prompt)
        llm_span.set_attribute("gen_ai.request.start_time", llm_start_time)
        llm_span.set_attribute("gen_ai.request.timestamp", int(llm_start_time * 1000))
        try:
            trace_id = format(llm_span.get_span_context().trace_id, '032x')
            llm_span.set_attribute("trace.id", trace_id)
        except Exception:
            pass
        if conversation_id:
            llm_span.set_attribute(AttributeNames.GEN_AI_CONVERSATION_ID, conversation_id)
        
        # AUTOMATIC CLIENT DATA CAPTURE: Extract and add client data automatically
        # Works for all frameworks - no manual setup needed
        try:
            import os
            client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
            if client_data_capture_enabled:
                from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                client_data = extract_comprehensive_client_data()
                if client_data.get('ip_address') or client_data.get('user_agent'):
                    _add_client_data_to_span(llm_span, client_data)
        except Exception as e:
            logger.debug(f"Could not extract client data in call_llm_with_saf3ai: {e}")
        
        # Add custom attributes (single name per value - no gen_ai.* duplicate)
        custom_attrs = tracer.get_custom_attributes()
        for key, value in custom_attrs.items():
            if key in (AttributeNames.GEN_AI_CONVERSATION_ID, AttributeNames.CONVERSATION_ID) and conversation_id:
                continue
            if key.startswith(('client.', 'http.', 'browser_id', 'ip_address', 'user_agent')):
                continue
            llm_span.set_attribute(key, value)
        
        # Extract and add comprehensive client data (IP, user agent, browser ID, device info, etc.)
        try:
            from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
            client_data = extract_comprehensive_client_data()
            
            # Add all client data to span attributes (includes parsed browser/device/OS info)
            _add_client_data_to_span(llm_span, client_data)
        except Exception as e:
            logger.debug(f"Could not extract client data in call_llm_with_saf3ai: {e}")
        
        # Security scan span (if callback provided)
        if prompt_security_callback:
            with otel_tracer.start_as_current_span("llm.security_scan") as scan_span:
                scan_span.set_attribute("security.scan.enabled", True)
                scan_span.set_attribute("security.scan.type", "prompt")
                try:
                    # Call security callback
                    scan_results = prompt_security_callback(prompt)
                    
                    # Extract threat information
                    if isinstance(scan_results, dict):
                        threats_found = _extract_threats(scan_results)
                        scan_span.set_attribute("security.scan.passed", len(threats_found) == 0)
                        scan_span.set_attribute("security.scan.threats_found", len(threats_found) > 0)
                        scan_span.set_attribute("security.scan.threat_count", len(threats_found))
                        # Mirror key security fields on main span for conversation-level aggregation
                        llm_span.set_attribute("security.threats_found", len(threats_found) > 0)
                        llm_span.set_attribute("security.threat_count", len(threats_found))
                        llm_span.set_attribute("security.scan.threat_count", len(threats_found))
                        if threats_found:
                            llm_span.set_attribute("security.threat_types", ",".join(threats_found))
                            llm_span.set_attribute("security.conversation.threat_detected", True)
                            llm_span.set_attribute("security.conversation.threat_count", len(threats_found))
                            llm_span.set_attribute("security.conversation.severity", "critical")
                        if threats_found:
                            scan_span.set_attribute("security.scan.threat_types", ",".join(threats_found))
                            llm_span.set_status(Status(StatusCode.ERROR, "Security violation detected"))
                            raise ValueError(f"Security policy blocked request. Threats: {', '.join(threats_found)}")
                except ValueError:
                    # Re-raise security violations
                    raise
                except Exception as e:
                    logger.error(f"Security scan error: {e}", exc_info=True)
                    scan_span.set_attribute("security.scan.error", str(e))
                    # Continue on scan errors (fail open)
        
        # Execute LLM call
        try:
            response = llm_function(prompt, **llm_kwargs)
            
            # Extract response text (handle different response formats)
            response_text = None
            if hasattr(response, 'choices') and response.choices:
                # OpenAI-style response
                response_text = response.choices[0].message.content if hasattr(response.choices[0].message, 'content') else str(response.choices[0])
            elif hasattr(response, 'text'):
                response_text = response.text
            elif isinstance(response, str):
                response_text = response
            elif hasattr(response, 'content'):
                response_text = response.content
            
            # Note: We don't store LLM responses in spans - only scan them for security
            # Responses are handled by security callbacks but not stored in telemetry
            if response_text:
                llm_span.set_attribute(AttributeNames.LLM_RESPONSE_LENGTH, len(response_text))
                # Response text is NOT stored - only length for metrics

            # Extract token usage from custom/core LLM response shape
            usage = _extract_usage_from_llm_response(response)
            _set_usage_attributes(llm_span, usage)
            detected_model = None
            if hasattr(response, "model"):
                detected_model = getattr(response, "model")
            elif isinstance(response, dict):
                detected_model = response.get("model") or response.get("model_name")
            if detected_model:
                llm_span.set_attribute(AttributeNames.GEN_AI_RESPONSE_MODEL, str(detected_model))
            
            # Use config default if scan_response is None
            import os
            if scan_response is None:
                scan_response = os.getenv("SAF3AI_SCAN_RESPONSES", "true").lower() == "true"
            
            # Also check if response capturing is enabled
            capture_responses = os.getenv("SAF3AI_CAPTURE_RESPONSES", "true").lower() == "true"
            
            # Capture response (single name: llm.response, llm.response_length)
            if capture_responses and response_text:
                llm_span.set_attribute("llm.response", response_text)
                llm_span.set_attribute(AttributeNames.LLM_RESPONSE_LENGTH, len(response_text))
            
            # Scan response if callback provided (automatic response scanning)
            # Note: scan_response parameter is for explicit control, but if security_callback
            # is provided, we should scan responses by default for security
            should_scan_response = scan_response or (response_security_callback is not None)
            if should_scan_response and response_security_callback and response_text:
                with otel_tracer.start_as_current_span("llm.response_scan") as resp_scan_span:
                    resp_scan_span.set_attribute("security.scan.enabled", True)
                    resp_scan_span.set_attribute("security.scan.type", "response")
                    try:
                        # For response scanning, we need to use scan_response if available
                        # Check if callback supports response scanning
                        if hasattr(response_security_callback, '__call__'):
                            # Try to call as response callback
                            try:
                                scan_results = response_security_callback(response_text)
                                if isinstance(scan_results, dict):
                                    threats_found = _extract_threats(scan_results)
                                    has_threats = len(threats_found) > 0
                                    resp_scan_span.set_attribute("security.scan.passed", not has_threats)
                                    resp_scan_span.set_attribute("security.scan.threats_found", has_threats)
                                    resp_scan_span.set_attribute("security.scan.threat_count", len(threats_found))
                                    # Mirror key fields on main span for dashboard aggregation
                                    llm_span.set_attribute("security.response_threats_found", has_threats)
                                    llm_span.set_attribute("security.response_threat_count", len(threats_found))
                                    if has_threats:
                                        llm_span.set_attribute("security.response_threat_types", ",".join(threats_found))
                                        llm_span.set_attribute("security.conversation.threat_detected", True)
                                        llm_span.set_attribute("security.conversation.threat_count", len(threats_found))
                                        llm_span.set_attribute("security.conversation.severity", "critical")
                                    if threats_found:
                                        resp_scan_span.set_attribute("security.scan.threat_types", ",".join(threats_found))
                                    
                                    # SECURITY FEATURE: Store response text when threats are detected
                                    # This enables security auditing and forensics for flagged responses
                                    if has_threats and response_text:
                                        resp_scan_span.set_attribute("security.response.threat_detected", True)
                                        resp_scan_span.set_attribute("llm.response", response_text)
                                        resp_scan_span.set_attribute(AttributeNames.LLM_RESPONSE_LENGTH, len(response_text))
                                        logger.debug(f"Stored response text due to detected threats: {', '.join(threats_found)}")
                            except Exception as e:
                                logger.debug(f"Response scan error: {e}")
                    except Exception as e:
                        logger.error(f"Response scan error: {e}", exc_info=True)
            
            # Add end time and duration
            llm_end_time = time.time()
            llm_duration_ms = (llm_end_time - llm_start_time) * 1000
            llm_span.set_attribute("gen_ai.request.end_time", llm_end_time)
            llm_span.set_attribute("gen_ai.request.duration_ms", llm_duration_ms)
            llm_span.set_attribute("gen_ai.request.duration_seconds", llm_end_time - llm_start_time)
            
            if response_text:
                llm_span.set_attribute(AttributeNames.LLM_RESPONSE_LENGTH, len(response_text))
            
            llm_span.set_status(Status(StatusCode.OK))
            return response
            
        except Exception as e:
            llm_span.set_status(Status(StatusCode.ERROR, str(e)))
            llm_span.set_attribute("error.message", str(e))
            llm_span.set_attribute("error.type", type(e).__name__)
            raise


# Alias init_telemetry for compatibility (was init_telemetry in adk-otel)
init_telemetry = init