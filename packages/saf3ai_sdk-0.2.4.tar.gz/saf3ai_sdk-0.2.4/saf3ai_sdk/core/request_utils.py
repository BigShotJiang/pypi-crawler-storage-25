"""
Utility functions for extracting HTTP request information like user agent, IP address,
and browser/client metadata.

This module provides framework-agnostic utilities to extract request metadata
from common web frameworks (Flask, FastAPI, Django, etc.) or from custom attributes.
"""

import logging
import hashlib
import json
from typing import Optional, Dict, Tuple

logger = logging.getLogger(__name__)


def extract_user_agent_and_ip() -> Tuple[Optional[str], Optional[str]]:
    """
    Extract user agent and IP address from the current request context.
    
    This function uses the comprehensive extraction and returns just user agent and IP.
    For full browser/client data, use extract_comprehensive_client_data() instead.
    
    Returns:
        Tuple of (user_agent, ip_address) - both may be None if not available
    """
    client_data = extract_comprehensive_client_data()
    return client_data.get('user_agent'), client_data.get('ip_address')


def _parse_user_agent(user_agent: Optional[str]) -> Dict[str, Optional[str]]:
    """
    Parse user agent string to extract browser, device, and machine information.
    
    Returns:
        Dictionary with parsed user agent information:
        - browser_name: Browser name (Chrome, Firefox, Safari, etc.)
        - browser_version: Browser version
        - device_type: Device type (Desktop, Mobile, Tablet, Bot, etc.)
        - os_name: Operating system name (Windows, macOS, Linux, iOS, Android, etc.)
        - os_version: Operating system version
        - platform: Platform type (Windows, Mac, Linux, iPhone, iPad, Android, etc.)
    """
    parsed = {
        'browser_name': None,
        'browser_version': None,
        'device_type': None,
        'os_name': None,
        'os_version': None,
        'platform': None,
    }
    
    if not user_agent:
        return parsed
    
    ua_lower = user_agent.lower()
    
    # Detect browser
    if 'chrome' in ua_lower and 'edg' not in ua_lower and 'opr' not in ua_lower:
        parsed['browser_name'] = 'Chrome'
        # Extract Chrome version
        import re
        match = re.search(r'chrome/([\d.]+)', ua_lower)
        if match:
            parsed['browser_version'] = match.group(1)
    elif 'firefox' in ua_lower:
        parsed['browser_name'] = 'Firefox'
        import re
        match = re.search(r'firefox/([\d.]+)', ua_lower)
        if match:
            parsed['browser_version'] = match.group(1)
    elif 'safari' in ua_lower and 'chrome' not in ua_lower:
        parsed['browser_name'] = 'Safari'
        import re
        match = re.search(r'version/([\d.]+)', ua_lower)
        if match:
            parsed['browser_version'] = match.group(1)
    elif 'edg' in ua_lower:
        parsed['browser_name'] = 'Edge'
        import re
        match = re.search(r'edg/([\d.]+)', ua_lower)
        if match:
            parsed['browser_version'] = match.group(1)
    elif 'opr' in ua_lower or 'opera' in ua_lower:
        parsed['browser_name'] = 'Opera'
        import re
        match = re.search(r'(?:opr|opera)/([\d.]+)', ua_lower)
        if match:
            parsed['browser_version'] = match.group(1)
    
    # Detect device type and OS
    if 'mobile' in ua_lower or 'android' in ua_lower:
        parsed['device_type'] = 'Mobile'
        if 'android' in ua_lower:
            parsed['os_name'] = 'Android'
            parsed['platform'] = 'Android'
            import re
            match = re.search(r'android ([\d.]+)', ua_lower)
            if match:
                parsed['os_version'] = match.group(1)
        elif 'iphone' in ua_lower:
            parsed['os_name'] = 'iOS'
            parsed['platform'] = 'iPhone'
            import re
            match = re.search(r'os ([\d_]+)', ua_lower)
            if match:
                parsed['os_version'] = match.group(1).replace('_', '.')
    elif 'ipad' in ua_lower:
        parsed['device_type'] = 'Tablet'
        parsed['os_name'] = 'iOS'
        parsed['platform'] = 'iPad'
        import re
        match = re.search(r'os ([\d_]+)', ua_lower)
        if match:
            parsed['os_version'] = match.group(1).replace('_', '.')
    elif 'windows' in ua_lower:
        parsed['device_type'] = 'Desktop'
        parsed['os_name'] = 'Windows'
        parsed['platform'] = 'Windows'
        import re
        match = re.search(r'windows nt ([\d.]+)', ua_lower)
        if match:
            version = match.group(1)
            # Map Windows NT versions to friendly names
            version_map = {
                '10.0': '10/11',
                '6.3': '8.1',
                '6.2': '8',
                '6.1': '7',
            }
            parsed['os_version'] = version_map.get(version, version)
    elif 'mac os x' in ua_lower or 'macintosh' in ua_lower:
        parsed['device_type'] = 'Desktop'
        parsed['os_name'] = 'macOS'
        parsed['platform'] = 'Mac'
        import re
        match = re.search(r'mac os x ([\d_]+)', ua_lower)
        if match:
            parsed['os_version'] = match.group(1).replace('_', '.')
    elif 'linux' in ua_lower:
        parsed['device_type'] = 'Desktop'
        parsed['os_name'] = 'Linux'
        parsed['platform'] = 'Linux'
    elif 'bot' in ua_lower or 'crawler' in ua_lower or 'spider' in ua_lower:
        parsed['device_type'] = 'Bot'
    
    return parsed


def extract_comprehensive_client_data() -> Dict[str, Optional[str]]:
    """
    Extract comprehensive browser/client data automatically from request context.
    
    This function extracts:
    - IP address (with proxy handling)
    - User agent
    - Browser ID (fingerprint based on headers)
    - Accept-Language
    - Accept-Encoding
    - Accept
    - Referer
    - Origin
    - X-Requested-With
    - And other browser/client metadata
    
    Returns:
        Dictionary with all extracted client data
    """
    # Check if client data capture is enabled
    try:
        import os
        client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
        if not client_data_capture_enabled:
            logger.debug("Client data capture is disabled via SAF3AI_CLIENT_DATA_CAPTURE")
            return {}
    except Exception:
        pass  # Default to enabled if check fails
    
    client_data = {
        'ip_address': None,
        'user_agent': None,
        'browser_id': None,
        'accept_language': None,
        'accept_encoding': None,
        'accept': None,
        'referer': None,
        'origin': None,
        'x_requested_with': None,
        'connection': None,
        'cache_control': None,
        'dnt': None,  # Do Not Track
        'sec_fetch_site': None,
        'sec_fetch_mode': None,
        'sec_fetch_user': None,
        'sec_fetch_dest': None,
        'sec_ch_ua': None,  # Client Hints
        'sec_ch_ua_platform': None,
        'sec_ch_ua_mobile': None,
        # Parsed user agent fields
        'browser_name': None,
        'browser_version': None,
        'device_type': None,
        'os_name': None,
        'os_version': None,
        'platform': None,
    }
    
    # AUTOMATIC EXTRACTION: Try Flask/FastAPI first (automatic detection)
    # This ensures we capture data automatically without requiring manual setup
    # Try multiple methods to detect Flask context for maximum compatibility
    flask_detected = False
    try:
        from flask import request, has_request_context
        if has_request_context():
            _extract_from_flask_request(client_data)
            flask_detected = True
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"Flask extraction failed: {e}")
    
    # Try alternative Flask detection method (in case has_request_context() doesn't work)
    if not flask_detected:
        try:
            import flask
            # Try to access request directly
            if hasattr(flask, 'request') and flask.request:
                try:
                    _extract_from_flask_request(client_data)
                    flask_detected = True
                except (RuntimeError, AttributeError):
                    pass
        except (ImportError, AttributeError, Exception):
            pass
    
    # If Flask data was extracted, process and return it
    if flask_detected and (client_data['ip_address'] or client_data['user_agent']):
        # Parse user agent for browser/device info
        if client_data['user_agent']:
            parsed_ua = _parse_user_agent(client_data['user_agent'])
            client_data.update(parsed_ua)
        
        # Generate browser ID
        if not client_data['browser_id']:
            client_data['browser_id'] = _generate_browser_id(client_data)
        
        # Automatically set in custom attributes for future spans
        try:
            from saf3ai_sdk.core.tracer import tracer
            _set_client_data_in_custom_attrs(client_data)
        except Exception:
            pass
        
        return client_data
    
    # Try FastAPI (automatic detection)
    try:
        from starlette.requests import Request
        from starlette_context import context
        # Check if we're in a FastAPI/Starlette request context
        if hasattr(context, 'get') and context.get('request'):
            request = context.get('request')
            if isinstance(request, Request):
                _extract_from_fastapi_request(client_data, request)
                if client_data['ip_address'] or client_data['user_agent']:
                    # Parse user agent
                    if client_data['user_agent']:
                        parsed_ua = _parse_user_agent(client_data['user_agent'])
                        client_data.update(parsed_ua)
                    
                    # Generate browser ID
                    if not client_data['browser_id']:
                        client_data['browser_id'] = _generate_browser_id(client_data)
                    
                    # Automatically set in custom attributes
                    try:
                        from saf3ai_sdk.core.tracer import tracer
                        _set_client_data_in_custom_attrs(client_data)
                    except Exception:
                        pass
                    
                    return client_data
    except (ImportError, AttributeError):
        pass
    except Exception as e:
        logger.debug(f"FastAPI extraction failed: {e}")
    
    # Fallback: Check custom attributes (if manually set)
    try:
        from saf3ai_sdk.core.tracer import tracer
        custom_attrs = tracer.get_custom_attributes()
        
        # Extract from custom attributes if available
        client_data['ip_address'] = (
            custom_attrs.get('ip_address') or 
            custom_attrs.get('client.ip') or 
            custom_attrs.get('http.client_ip')
        )
        client_data['user_agent'] = (
            custom_attrs.get('user_agent') or 
            custom_attrs.get('http.user_agent')
        )
        client_data['browser_id'] = custom_attrs.get('browser_id') or custom_attrs.get('client.id')
        
        # Parse user agent if available
        if client_data['user_agent']:
            parsed_ua = _parse_user_agent(client_data['user_agent'])
            client_data.update(parsed_ua)
        
        # If we have basic data from custom attributes, try to get more
        if client_data['ip_address'] or client_data['user_agent']:
            # Try to get additional headers from Flask/FastAPI if available
            _extract_headers_from_frameworks(client_data)
            
            # Generate browser ID if not already set
            if not client_data['browser_id']:
                client_data['browser_id'] = _generate_browser_id(client_data)
            
            return client_data
    except Exception as e:
        logger.debug(f"Could not check custom attributes: {e}")
    
    # Try environment variables
    try:
        import os
        _extract_from_environment(client_data)
        if client_data['ip_address'] or client_data['user_agent']:
            # Generate browser ID
            if not client_data['browser_id']:
                client_data['browser_id'] = _generate_browser_id(client_data)
            # Set in custom attributes and return
            try:
                from saf3ai_sdk.core.tracer import tracer
                _set_client_data_in_custom_attrs(client_data)
            except Exception:
                pass
            return client_data
    except Exception as e:
        logger.debug(f"Environment extraction failed: {e}")
    
    # FALLBACK 1: Try to get IP from system network interfaces
    if not client_data['ip_address']:
        try:
            client_data['ip_address'] = _get_system_ip_address()
            if client_data['ip_address']:
                logger.debug(f"Captured IP from system network interface: {client_data['ip_address']}")
        except Exception as e:
            logger.debug(f"Could not get system IP address: {e}")
    
    # FALLBACK 2: Try to get hostname and use it as identifier
    if not client_data['ip_address']:
        try:
            import socket
            hostname = socket.gethostname()
            if hostname:
                # Try to resolve hostname to IP
                try:
                    ip = socket.gethostbyname(hostname)
                    if ip and ip != '127.0.0.1':
                        client_data['ip_address'] = ip
                        logger.debug(f"Captured IP from hostname resolution: {ip}")
                except Exception:
                    # If resolution fails, use hostname as identifier
                    client_data['ip_address'] = f"hostname:{hostname}"
                    logger.debug(f"Using hostname as identifier: {hostname}")
        except Exception as e:
            logger.debug(f"Could not get hostname: {e}")
    
    # FALLBACK 3: Get agent ID from SDK initialization (ALWAYS try this)
    try:
        from saf3ai_sdk.core.tracer import tracer
        custom_attrs = tracer.get_custom_attributes()
        agent_id = custom_attrs.get('agent_id') or custom_attrs.get('gen_ai.agent_id')
        if agent_id:
            # Store agent ID in client data
            client_data['agent_id'] = agent_id
            # Create a user agent-like identifier from agent ID if no user agent exists
            if not client_data.get('user_agent'):
                client_data['user_agent'] = f"Saf3AI-Agent/{agent_id}"
                logger.debug(f"Created user agent from agent ID: {agent_id}")
            else:
                logger.debug(f"Found agent ID in custom attributes: {agent_id}")
    except Exception as e:
        logger.debug(f"Could not get agent ID: {e}")
    
    # FALLBACK 4: Generate system-based user agent
    if not client_data.get('user_agent'):
        try:
            import platform
            import sys
            system_info = {
                'platform': platform.system(),
                'release': platform.release(),
                'machine': platform.machine(),
                'python_version': sys.version.split()[0]
            }
            # Create a user agent from system info
            ua_parts = [
                f"Saf3AI-SDK",
                f"({system_info['platform']} {system_info['release']})",
                f"Python/{system_info['python_version']}"
            ]
            client_data['user_agent'] = ' '.join(ua_parts)
            logger.debug(f"Generated system-based user agent: {client_data['user_agent']}")
        except Exception as e:
            logger.debug(f"Could not generate system user agent: {e}")
    
    # FALLBACK 5: Get OS/platform information
    try:
        import platform
        if not client_data.get('os_name'):
            client_data['os_name'] = platform.system()
        if not client_data.get('os_version'):
            client_data['os_version'] = platform.release()
        if not client_data.get('platform'):
            client_data['platform'] = platform.platform()
        if not client_data.get('device_type'):
            # Determine device type from platform
            if platform.system() in ['Windows', 'Linux', 'Darwin']:
                client_data['device_type'] = 'Server' if client_data.get('ip_address') else 'Desktop'
            else:
                client_data['device_type'] = 'Unknown'
    except Exception as e:
        logger.debug(f"Could not get platform information: {e}")
    
    # FALLBACK 6: Generate unique agent identifier if we have any data
    if client_data.get('ip_address') or client_data.get('user_agent'):
        if not client_data.get('browser_id'):
            client_data['browser_id'] = _generate_agent_identifier(client_data)
            logger.debug(f"Generated agent identifier: {client_data['browser_id']}")
    
    # Always set in custom attributes for future spans (even if minimal data)
    try:
        from saf3ai_sdk.core.tracer import tracer
        _set_client_data_in_custom_attrs(client_data)
    except Exception:
        pass
    
    return client_data


def _extract_from_flask_request(client_data: Dict[str, Optional[str]]) -> None:
    """Extract client data from Flask request object."""
    try:
        from flask import request
        
        # IP address (with proxy handling)
        client_data['ip_address'] = (
            request.headers.get('X-Forwarded-For', '').split(',')[0].strip() or
            request.headers.get('X-Real-IP') or
            request.remote_addr
        )
        
        # User agent
        client_data['user_agent'] = request.headers.get('User-Agent')
        
        # Additional headers
        client_data['accept_language'] = request.headers.get('Accept-Language')
        client_data['accept_encoding'] = request.headers.get('Accept-Encoding')
        client_data['accept'] = request.headers.get('Accept')
        client_data['referer'] = request.headers.get('Referer')
        client_data['origin'] = request.headers.get('Origin')
        client_data['x_requested_with'] = request.headers.get('X-Requested-With')
        client_data['connection'] = request.headers.get('Connection')
        client_data['cache_control'] = request.headers.get('Cache-Control')
        client_data['dnt'] = request.headers.get('DNT')
        client_data['sec_fetch_site'] = request.headers.get('Sec-Fetch-Site')
        client_data['sec_fetch_mode'] = request.headers.get('Sec-Fetch-Mode')
        client_data['sec_fetch_user'] = request.headers.get('Sec-Fetch-User')
        client_data['sec_fetch_dest'] = request.headers.get('Sec-Fetch-Dest')
        client_data['sec_ch_ua'] = request.headers.get('Sec-CH-UA')
        client_data['sec_ch_ua_platform'] = request.headers.get('Sec-CH-UA-Platform')
        client_data['sec_ch_ua_mobile'] = request.headers.get('Sec-CH-UA-Mobile')
    except Exception as e:
        logger.debug(f"Flask header extraction failed: {e}")


def _extract_from_fastapi_request(client_data: Dict[str, Optional[str]], request) -> None:
    """Extract client data from FastAPI/Starlette request object."""
    try:
        # IP address (with proxy handling)
        forwarded_for = request.headers.get('X-Forwarded-For', '')
        client_ip = forwarded_for.split(',')[0].strip() if forwarded_for else None
        client_data['ip_address'] = (
            client_ip or
            request.headers.get('X-Real-IP') or
            (request.client.host if request.client else None)
        )
        
        # User agent
        client_data['user_agent'] = request.headers.get('User-Agent')
        
        # Additional headers
        client_data['accept_language'] = request.headers.get('Accept-Language')
        client_data['accept_encoding'] = request.headers.get('Accept-Encoding')
        client_data['accept'] = request.headers.get('Accept')
        client_data['referer'] = request.headers.get('Referer')
        client_data['origin'] = request.headers.get('Origin')
        client_data['x_requested_with'] = request.headers.get('X-Requested-With')
        client_data['connection'] = request.headers.get('Connection')
        client_data['cache_control'] = request.headers.get('Cache-Control')
        client_data['dnt'] = request.headers.get('DNT')
        client_data['sec_fetch_site'] = request.headers.get('Sec-Fetch-Site')
        client_data['sec_fetch_mode'] = request.headers.get('Sec-Fetch-Mode')
        client_data['sec_fetch_user'] = request.headers.get('Sec-Fetch-User')
        client_data['sec_fetch_dest'] = request.headers.get('Sec-Fetch-Dest')
        client_data['sec_ch_ua'] = request.headers.get('Sec-CH-UA')
        client_data['sec_ch_ua_platform'] = request.headers.get('Sec-CH-UA-Platform')
        client_data['sec_ch_ua_mobile'] = request.headers.get('Sec-CH-UA-Mobile')
    except Exception as e:
        logger.debug(f"FastAPI header extraction failed: {e}")


def _set_client_data_in_custom_attrs(client_data: Dict[str, Optional[str]]) -> None:
    """Automatically set client data in custom attributes for propagation to all spans.
    
    Uses single format per attribute (gen_ai.*) to avoid duplicates.
    """
    try:
        from saf3ai_sdk.core.tracer import tracer
        
        attrs = {}
        # OTEL standard attributes only (client.ip, http.user_agent, client.id)
        if client_data.get('ip_address'):
            attrs['client.ip'] = client_data['ip_address']
        if client_data.get('user_agent'):
            attrs['http.user_agent'] = client_data['user_agent']
        if client_data.get('browser_id'):
            attrs['client.id'] = client_data['browser_id']
        for key in ['device_type', 'os_name', 'os_version', 'platform']:
            if client_data.get(key):
                attrs[f'client.{key}'] = client_data[key]
        
        if attrs:
            tracer.set_custom_attributes(attrs)
            logger.debug(f"Automatically set client data in custom attributes: {list(attrs.keys())[:10]}...")
    except Exception as e:
        logger.debug(f"Could not set client data in custom attributes: {e}")


def _extract_headers_from_frameworks(client_data: Dict[str, Optional[str]]) -> None:
    """Try to extract headers from available frameworks."""
    # Try Flask - check multiple ways to detect Flask context
    try:
        from flask import request, has_request_context
        if has_request_context():
            _extract_from_flask_request(client_data)
            return
    except (ImportError, Exception):
        pass
    
    # Try Flask - check if we can get the current app
    try:
        import flask
        if hasattr(flask, 'current_app') and flask.current_app:
            try:
                if has_request_context():
                    _extract_from_flask_request(client_data)
                    return
            except Exception:
                pass
    except (ImportError, Exception):
        pass
    
    # Try FastAPI - check starlette context
    try:
        from starlette_context import context
        if hasattr(context, 'get') and context.get('request'):
            from starlette.requests import Request
            request = context.get('request')
            if isinstance(request, Request):
                _extract_from_fastapi_request(client_data, request)
                return
    except (ImportError, AttributeError, Exception):
        pass


def _extract_from_environment(client_data: Dict[str, Optional[str]]) -> None:
    """Extract client data from environment variables."""
    import os
    
    # IP address
    client_data['ip_address'] = (
        os.getenv('HTTP_X_FORWARDED_FOR', '').split(',')[0].strip() or
        os.getenv('HTTP_X_REAL_IP') or
        os.getenv('REMOTE_ADDR') or
        os.getenv('CLIENT_IP')
    )
    
    # User agent
    client_data['user_agent'] = (
        os.getenv('HTTP_USER_AGENT') or
        os.getenv('USER_AGENT')
    )
    
    # Additional headers (CGI/WSGI format: HTTP_* prefix, uppercase, hyphens to underscores)
    client_data['accept_language'] = os.getenv('HTTP_ACCEPT_LANGUAGE')
    client_data['accept_encoding'] = os.getenv('HTTP_ACCEPT_ENCODING')
    client_data['accept'] = os.getenv('HTTP_ACCEPT')
    client_data['referer'] = os.getenv('HTTP_REFERER')
    client_data['origin'] = os.getenv('HTTP_ORIGIN')
    client_data['x_requested_with'] = os.getenv('HTTP_X_REQUESTED_WITH')
    client_data['connection'] = os.getenv('HTTP_CONNECTION')
    client_data['cache_control'] = os.getenv('HTTP_CACHE_CONTROL')
    client_data['dnt'] = os.getenv('HTTP_DNT')
    client_data['sec_fetch_site'] = os.getenv('HTTP_SEC_FETCH_SITE')
    client_data['sec_fetch_mode'] = os.getenv('HTTP_SEC_FETCH_MODE')
    client_data['sec_fetch_user'] = os.getenv('HTTP_SEC_FETCH_USER')
    client_data['sec_fetch_dest'] = os.getenv('HTTP_SEC_FETCH_DEST')
    client_data['sec_ch_ua'] = os.getenv('HTTP_SEC_CH_UA')
    client_data['sec_ch_ua_platform'] = os.getenv('HTTP_SEC_CH_UA_PLATFORM')
    client_data['sec_ch_ua_mobile'] = os.getenv('HTTP_SEC_CH_UA_MOBILE')


def _get_system_ip_address() -> Optional[str]:
    """
    Get IP address from system network interfaces.
    Tries multiple methods to get a non-localhost IP address.
    """
    try:
        import socket
        # Method 1: Connect to external address to get local IP
        # This doesn't actually send data, just determines the route
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # Connect to a public DNS server (doesn't actually connect)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            if ip and ip != '127.0.0.1':
                return ip
        except Exception:
            pass
        
        # Method 2: Get IP from network interfaces
        try:
            import socket
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname)
            if ip and ip != '127.0.0.1' and not ip.startswith('169.254'):  # Exclude link-local
                return ip
        except Exception:
            pass
        
        # Method 3: Try to get from network interfaces (platform-specific)
        try:
            import platform
            if platform.system() == "Windows":
                import subprocess
                result = subprocess.run(['ipconfig'], capture_output=True, text=True, timeout=2)
                # Parse IPv4 address from ipconfig output
                for line in result.stdout.split('\n'):
                    if 'IPv4' in line or 'IP Address' in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            ip = parts[1].strip()
                            if ip and ip != '127.0.0.1' and not ip.startswith('169.254'):
                                return ip
            else:
                # Linux/Mac: use ifconfig or ip command
                import subprocess
                try:
                    result = subprocess.run(['hostname', '-I'], capture_output=True, text=True, timeout=2)
                    if result.returncode == 0:
                        ips = result.stdout.strip().split()
                        for ip in ips:
                            if ip and ip != '127.0.0.1' and not ip.startswith('169.254'):
                                return ip
                except Exception:
                    pass
        except Exception:
            pass
        
    except Exception as e:
        logger.debug(f"Error getting system IP: {e}")
    
    return None


def _generate_agent_identifier(client_data: Dict[str, Optional[str]]) -> Optional[str]:
    """
    Generate a unique agent identifier from available client data.
    This is used when browser ID cannot be generated (no user agent).
    """
    try:
        fingerprint_data = {}
        
        # Include IP address (partial for privacy)
        if client_data.get('ip_address'):
            ip = client_data['ip_address']
            # Use first 3 octets for IPv4, or first part for hostname
            if '.' in ip and ip.count('.') == 3:
                parts = ip.split('.')
                fingerprint_data['ip_prefix'] = '.'.join(parts[:3])
            else:
                fingerprint_data['ip'] = ip
        
        # Include user agent if available
        if client_data.get('user_agent'):
            fingerprint_data['ua'] = client_data['user_agent']
        
        # Include OS/platform info
        if client_data.get('os_name'):
            fingerprint_data['os'] = client_data['os_name']
        if client_data.get('platform'):
            fingerprint_data['platform'] = client_data['platform']
        
        # Include agent ID if available
        try:
            from saf3ai_sdk.core.tracer import tracer
            custom_attrs = tracer.get_custom_attributes()
            agent_id = custom_attrs.get('agent_id') or custom_attrs.get('gen_ai.agent_id')
            if agent_id:
                fingerprint_data['agent_id'] = agent_id
        except Exception:
            pass
        
        # Generate hash-based ID
        if fingerprint_data:
            fingerprint_str = json.dumps(fingerprint_data, sort_keys=True)
            agent_id_hash = hashlib.sha256(fingerprint_str.encode()).hexdigest()[:16]
            return f"agent_{agent_id_hash}"
        
    except Exception as e:
        logger.debug(f"Could not generate agent identifier: {e}")
    
    return None


def _generate_browser_id(client_data: Dict[str, Optional[str]]) -> Optional[str]:
    """
    Generate a browser/client ID (fingerprint) based on available client data.
    
    This creates a consistent identifier for the same browser/client based on:
    - User agent
    - Accept-Language
    - Accept-Encoding
    - IP address (first 3 octets for privacy)
    - Platform hints
    """
    fingerprint_data = {}
    
    # Include user agent (most important)
    if client_data.get('user_agent'):
        fingerprint_data['ua'] = client_data['user_agent']
    
    # Include language
    if client_data.get('accept_language'):
        fingerprint_data['lang'] = client_data['accept_language'].split(',')[0].strip()  # Primary language only
    
    # Include encoding
    if client_data.get('accept_encoding'):
        fingerprint_data['enc'] = client_data['accept_encoding']
    
    # Include platform hints
    if client_data.get('sec_ch_ua_platform'):
        fingerprint_data['platform'] = client_data['sec_ch_ua_platform']
    if client_data.get('sec_ch_ua_mobile'):
        fingerprint_data['mobile'] = client_data['sec_ch_ua_mobile']
    
    # Include partial IP (first 3 octets for privacy/consistency)
    if client_data.get('ip_address'):
        try:
            ip_parts = client_data['ip_address'].split('.')
            if len(ip_parts) == 4:  # IPv4
                fingerprint_data['ip_prefix'] = '.'.join(ip_parts[:3])  # First 3 octets
        except Exception:
            pass
    
    # Generate hash-based ID
    if fingerprint_data:
        try:
            fingerprint_str = json.dumps(fingerprint_data, sort_keys=True)
            browser_id = hashlib.sha256(fingerprint_str.encode()).hexdigest()[:16]  # 16-char ID
            return f"browser_{browser_id}"
        except Exception as e:
            logger.debug(f"Could not generate browser ID: {e}")
    
    return None


def _add_client_data_to_span(span, client_data: Dict[str, Optional[str]]) -> None:
    """Helper function to add client data attributes to a span. Uses single format (gen_ai.*) to avoid duplicates."""
    try:
        if not span or not span.is_recording():
            return
        
        # Check if attributes already exist to avoid duplicates
        existing_attrs = dict(span.attributes) if hasattr(span, 'attributes') else {}
        
        # Client data - OTEL standard attributes only (client.ip, http.user_agent, client.id)
        if client_data.get('user_agent') and 'http.user_agent' not in existing_attrs:
            span.set_attribute("http.user_agent", client_data['user_agent'])
        if client_data.get('ip_address') and 'client.ip' not in existing_attrs:
            span.set_attribute("client.ip", client_data['ip_address'])
        if client_data.get('browser_id') and 'client.id' not in existing_attrs:
            span.set_attribute("client.id", client_data['browser_id'])
        for key in ['device_type', 'os_name', 'os_version', 'platform']:
            attr = f"client.{key}"
            if client_data.get(key) and attr not in existing_attrs:
                span.set_attribute(attr, client_data[key])
    except Exception as e:
        logger.debug(f"Could not add client data to span: {e}")


def set_request_metadata(
    user_agent: Optional[str] = None, 
    ip_address: Optional[str] = None,
    request_headers: Optional[Dict[str, str]] = None
) -> None:
    """
    Manually set user agent, IP address, and other browser/client metadata in custom attributes.
    
    This is useful when you have access to the request object in your application
    and want to ensure the SDK captures this information.
    
    Args:
        user_agent: User agent string (e.g., from request.headers.get('User-Agent'))
        ip_address: Client IP address (e.g., from request.remote_addr or request.client.host)
        request_headers: Optional dictionary of request headers to extract additional metadata
    
    Example (Flask):
        ```python
        from saf3ai_sdk.core.request_utils import set_request_metadata
        from flask import request
        
        @app.route('/api/chat')
        def chat():
            set_request_metadata(
                user_agent=request.headers.get('User-Agent'),
                ip_address=request.remote_addr,
                request_headers=dict(request.headers)  # Extract all headers automatically
            )
            # ... rest of your code
        ```
    
    Example (FastAPI):
        ```python
        from saf3ai_sdk.core.request_utils import set_request_metadata
        from fastapi import Request
        
        @app.post('/api/chat')
        async def chat(request: Request):
            # Extract IP from FastAPI request
            client_ip = request.client.host if request.client else None
            forwarded_for = request.headers.get('X-Forwarded-For', '').split(',')[0].strip()
            ip_address = forwarded_for or client_ip
            
            set_request_metadata(
                user_agent=request.headers.get('User-Agent'),
                ip_address=ip_address,
                request_headers=dict(request.headers)  # Extract all headers automatically
            )
            # ... rest of your code
        ```
    """
    try:
        from saf3ai_sdk.core.tracer import tracer
        
        attrs = {}
        # OTEL standard attributes only (no duplicates)
        if user_agent:
            attrs['http.user_agent'] = user_agent
        if ip_address:
            attrs['client.ip'] = ip_address
        
        # Extract additional headers if provided
        if request_headers:
            # Extract browser/client metadata from headers
            header_mappings = {
                'Accept-Language': ('accept_language', 'http.accept_language'),
                'Accept-Encoding': ('accept_encoding', 'http.accept_encoding'),
                'Accept': ('accept', 'http.accept'),
                'Referer': ('referer', 'http.referer'),
                'Origin': ('origin', 'http.origin'),
                'X-Requested-With': ('x_requested_with', 'http.x_requested_with'),
                'Connection': ('connection', 'http.connection'),
                'Cache-Control': ('cache_control', 'http.cache_control'),
                'DNT': ('dnt', 'http.dnt'),
                'Sec-Fetch-Site': ('sec_fetch_site', 'http.sec_fetch_site'),
                'Sec-Fetch-Mode': ('sec_fetch_mode', 'http.sec_fetch_mode'),
                'Sec-Fetch-User': ('sec_fetch_user', 'http.sec_fetch_user'),
                'Sec-Fetch-Dest': ('sec_fetch_dest', 'http.sec_fetch_dest'),
                'Sec-CH-UA': ('sec_ch_ua', 'http.sec_ch_ua'),
                'Sec-CH-UA-Platform': ('sec_ch_ua_platform', 'http.sec_ch_ua_platform'),
                'Sec-CH-UA-Mobile': ('sec_ch_ua_mobile', 'http.sec_ch_ua_mobile'),
            }
            
            for header_name, (_attr_key, http_attr_key) in header_mappings.items():
                value = request_headers.get(header_name)
                if value:
                    attrs[http_attr_key] = value
        
        # Generate browser ID if we have enough data (single name: client.id)
        if user_agent or ip_address:
            temp_client_data = {
                'user_agent': user_agent,
                'ip_address': ip_address,
                'accept_language': attrs.get('http.accept_language'),
                'accept_encoding': attrs.get('http.accept_encoding'),
                'sec_ch_ua_platform': attrs.get('http.sec_ch_ua_platform'),
                'sec_ch_ua_mobile': attrs.get('http.sec_ch_ua_mobile'),
            }
            browser_id = _generate_browser_id(temp_client_data)
            if browser_id:
                attrs['client.id'] = browser_id
        
        if attrs:
            tracer.set_custom_attributes(attrs)
            logger.debug(f"Set request metadata: {list(attrs.keys())}")
    except Exception as e:
        logger.warning(f"Could not set request metadata: {e}")

