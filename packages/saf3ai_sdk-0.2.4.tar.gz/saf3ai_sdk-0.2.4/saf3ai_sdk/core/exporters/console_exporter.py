"""Console exporter for Saf3AI SDK debug mode."""

import json
from typing import Sequence
from datetime import datetime
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.trace.status import StatusCode

from saf3ai_sdk.logging import logger


class ConsoleTelemetryExporter(SpanExporter):
    """Console exporter that prints telemetry data to stdout for debugging."""
    
    def __init__(self, debug_mode: bool = False):
        self.debug_mode = debug_mode
        self.span_count = 0
        self.llm_interactions = 0
        self.agent_interactions = 0
    
    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """Export spans to console with detailed information."""
        # NOTE: Console exporter is intentionally verbose for debugging purposes.
        # These print statements are kept because console_output is an explicit debug feature.
        # Users enable this via SAF3AI_CONSOLE_OUTPUT=true for debugging.
        if not spans:
            return SpanExportResult.SUCCESS
        
        for span in spans:
            self.span_count += 1
            # REMOVED: Verbose debug print - console exporter already shows span details
            # print(f"🔍 DEBUG: Processing span: {span.name}")
            self._print_span(span)
        
        return SpanExportResult.SUCCESS
    
    def _print_span(self, span: ReadableSpan):
        """Print span information to console."""
        span_name = span.name.lower()
        
        if self._is_llm_span(span_name, span.attributes):
            self._print_llm_span(span)
        elif self._is_agent_span(span_name, span.attributes):
            self._print_agent_span(span)
        else:
            self._print_general_span(span)
    
    def _is_llm_span(self, span_name: str, attributes: dict) -> bool:
        """Check if this is an LLM-related span."""
        # *** MODIFIED: Added 'call_llm' from ADK logs ***
        llm_keywords = [
            'llm', 'openai', 'anthropic', 'gemini', 'model', 
            'completion', 'chat', 'gpt', 'call_llm'
        ]
        
        if any(keyword in span_name for keyword in llm_keywords):
            return True
        
        # *** MODIFIED: Added specific ADK attribute keys ***
        adk_keys = ['gen_ai.request.model', 'gcp.vertex.agent.llm_request']
        for key in adk_keys:
            if key in attributes:
                return True
                
        return False
    
    def _is_agent_span(self, span_name: str, attributes: dict) -> bool:
        """Check if this is an agent-related span."""
        # *** MODIFIED: Added 'invoke_agent' and 'run_async' from logs ***
        agent_keywords = [
            'agent', 'financial', 'coordinator', 'analyst', 
            'task', 'workflow', 'invoke_agent', 'run_async'
        ]
        return any(keyword in span_name for keyword in agent_keywords) or \
               any(keyword in str(attributes).lower() for keyword in agent_keywords)
    
    def _print_llm_span(self, span: ReadableSpan):
        """Print LLM-specific span with special formatting."""
        self.llm_interactions += 1
        
        print("\n" + "🤖" + "="*78)
        print(f"🤖 LLM INTERACTION #{self.llm_interactions} - {span.name}")
        print("🤖" + "="*78)
        
        print(f"🤖 Duration: {self._format_duration(span.end_time - span.start_time)}")
        print(f"🤖 Status: {span.status.status_code}")
        print(f"🤖 Trace ID: {span.context.trace_id:032x}")
        
        print("\n🤖 LLM Data:")
        
        # --- SAF3AI SDK ATTRIBUTES (our custom spans) ---
        
        # Model
        if "llm.model" in span.attributes:
            print(f"🤖 📊 Model: {span.attributes['llm.model']}")
        elif "gen_ai.request.model" in span.attributes:
            print(f"🤖 📊 Model: {span.attributes['gen_ai.request.model']}")
        
        # Provider
        if "llm.provider" in span.attributes:
            print(f"🤖 🔧 Provider: {span.attributes['llm.provider']}")
        
        # Prompt (Saf3AI SDK format)
        if "llm.prompt" in span.attributes:
            prompt_text = span.attributes["llm.prompt"]
            print(f"🤖 📝 Prompt:")
            print(f"🤖    {self._format_text(prompt_text)}")
        # Prompt (ADK format)
        elif "gcp.vertex.agent.llm_request" in span.attributes:
            try:
                request_data = json.loads(span.attributes["gcp.vertex.agent.llm_request"])
                # Extract the prompt from the complex structure
                prompt_text = "System: " + request_data.get('config', {}).get('system_instruction', '')
                prompt_text += "\nUser: " + request_data.get('contents', [{}])[0].get('parts', [{}])[0].get('text', '[prompt not parsed]')
                print(f"🤖 📝 Prompt:")
                print(f"🤖    {self._format_text(prompt_text)}")
            except:
                print(f"🤖 📝 Prompt (raw): {self._format_text(str(span.attributes['gcp.vertex.agent.llm_request']))}")
        
        # Response (Saf3AI SDK format)
        if "llm.response" in span.attributes:
            response_text = span.attributes["llm.response"]
            print(f"🤖 💬 Response:")
            print(f"🤖    {self._format_text(response_text)}")
        # Response (ADK format)
        elif "gcp.vertex.agent.llm_response" in span.attributes:
            try:
                response_data = json.loads(span.attributes["gcp.vertex.agent.llm_response"])
                # Extract text or thought
                parts = response_data.get('content', {}).get('parts', [{}])
                if 'text' in parts[0]:
                    response_text = parts[0]['text']
                elif 'thought_signature' in parts[0]:
                     response_text = f"[Agent Thought: {parts[0]['thought_signature'][:100]}...]"
                else:
                    response_text = '[response not parsed]'
                print(f"🤖 💬 Response:")
                print(f"🤖    {self._format_text(response_text)}")
            except:
                print(f"🤖 💬 Response (raw): {self._format_text(str(span.attributes['gcp.vertex.agent.llm_response']))}")

        # Response length (Saf3AI SDK format)
        if "llm.response_length" in span.attributes:
            print(f"🤖 📊 Response Length: {span.attributes['llm.response_length']} characters")

        # Tokens (ADK format)
        if "gen_ai.usage.input_tokens" in span.attributes:
            print(f"🤖 📊 Input Tokens: {span.attributes['gen_ai.usage.input_tokens']}")
        if "gen_ai.usage.output_tokens" in span.attributes:
            print(f"🤖 📊 Output Tokens: {span.attributes['gen_ai.usage.output_tokens']}")
        
        # --- END OF SAF3AI SDK ATTRIBUTES ---

        print("="*78)
    
    def _print_agent_span(self, span: ReadableSpan):
        """Print agent-specific span."""
        self.agent_interactions += 1
        
        print("\n" + "="*78)
        print(f"AGENT INTERACTION #{self.agent_interactions} - {span.name}")
        print("="*78)
        
        print(f"Duration: {self._format_duration(span.end_time - span.start_time)}")
        print(f"Status: {span.status.status_code}")
        print(f"Trace ID: {span.context.trace_id:032x}")
        
        key_attrs = ['service.name', 'span.kind', 'function.name', 'agent.name']
        for attr in key_attrs:
            if attr in span.attributes:
                print(f"{attr}: {span.attributes[attr]}")
        
        # Print client data (IP, user agent, browser ID)
        self._print_client_data(span)
        
        # Print file/data sources accessed
        self._print_data_sources(span)
        
        if span.status.status_code == StatusCode.ERROR:
            error_attrs = {k: v for k, v in span.attributes.items() if 'error' in k.lower()}
            if error_attrs:
                print(f"\nERROR Details:")
                for key, value in error_attrs.items():
                    print(f"    {key}: {value}")
        
        print("="*78)
    
    def _print_client_data(self, span: ReadableSpan):
        """Print client data (IP, user agent, browser ID, agent ID, etc.)."""
        client_attrs = {}
        
        # Collect all client-related attributes
        client_keys = [
            'agent_id', 'gen_ai.agent_id', 'gen_ai.agent.name',
            'ip_address', 'client.ip', 'http.client_ip', 'gen_ai.client.ip',
            'user_agent', 'http.user_agent', 'gen_ai.user_agent',
            'browser_id', 'client.id', 'gen_ai.client.id',
            'browser_name', 'browser_version', 'device_type',
            'os_name', 'os_version', 'platform',
            'accept_language', 'accept_encoding', 'referer', 'origin'
        ]
        
        for key in client_keys:
            if key in span.attributes:
                client_attrs[key] = span.attributes[key]
        
        if client_attrs:
            print(f"\nClient Data:")
            # Show agent ID first (most important)
            if any(k in client_attrs for k in ['agent_id', 'gen_ai.agent_id', 'gen_ai.agent.name']):
                agent_id = client_attrs.get('agent_id') or client_attrs.get('gen_ai.agent_id') or client_attrs.get('gen_ai.agent.name')
                print(f"    Agent ID: {agent_id}")
            
            # Group related attributes
            if any(k in client_attrs for k in ['ip_address', 'client.ip', 'http.client_ip', 'gen_ai.client.ip']):
                ip = client_attrs.get('ip_address') or client_attrs.get('client.ip') or client_attrs.get('http.client_ip') or client_attrs.get('gen_ai.client.ip')
                print(f"    IP Address: {ip}")
            
            if any(k in client_attrs for k in ['user_agent', 'http.user_agent', 'gen_ai.user_agent']):
                ua = client_attrs.get('user_agent') or client_attrs.get('http.user_agent') or client_attrs.get('gen_ai.user_agent')
                print(f"    User Agent: {ua}")
            
            if any(k in client_attrs for k in ['browser_id', 'client.id', 'gen_ai.client.id']):
                bid = client_attrs.get('browser_id') or client_attrs.get('client.id') or client_attrs.get('gen_ai.client.id')
                print(f"    Browser/Agent ID: {bid}")
            
            if client_attrs.get('browser_name'):
                print(f"    Browser: {client_attrs.get('browser_name')} {client_attrs.get('browser_version', '')}")
            
            if client_attrs.get('device_type'):
                print(f"    Device: {client_attrs.get('device_type')}")
            
            if client_attrs.get('os_name'):
                print(f"    OS: {client_attrs.get('os_name')} {client_attrs.get('os_version', '')}")
        else:
            print(f"\nWARNING: No client data captured (Agent ID, IP, user agent, etc.)")
    
    def _print_data_sources(self, span: ReadableSpan):
        """Print data sources accessed (files, URLs, SharePoint, etc.)."""
        source_attrs = {}
        
        # Collect all file/data source attributes
        source_keys = [
            'file_access.path', 'file_access.name', 'file_access.source_type',
            'file_access.original_source', 'file_access.original_source_type',
            'uploaded_file.path', 'uploaded_file.name',
            'accessed_file.path', 'accessed_file.name',
            'data_source.file', 'data_source.name',
            'file.path', 'file.name'
        ]
        
        for key in source_keys:
            if key in span.attributes:
                source_attrs[key] = span.attributes[key]
        
        # Check for search queries
        search_query = span.attributes.get('data_source.search.query')
        
        if source_attrs:
            print(f"\nData Sources Accessed:")
            
            # Show original source if available (most important)
            if source_attrs.get('file_access.original_source'):
                print(f"    Original Source: {source_attrs['file_access.original_source']}")
                print(f"    Source Type: {source_attrs.get('file_access.original_source_type', 'unknown')}")
                if source_attrs.get('file_access.cached_path'):
                    print(f"    Cached Path: {source_attrs['file_access.cached_path']}")
            elif source_attrs.get('file_access.path'):
                print(f"    Source: {source_attrs['file_access.path']}")
                print(f"    Source Type: {source_attrs.get('file_access.source_type', 'unknown')}")
            
            if source_attrs.get('file_access.name'):
                print(f"    File Name: {source_attrs['file_access.name']}")
            
            # Show metadata if available
            metadata_keys = [k for k in span.attributes.keys() if k.startswith('file_access.metadata.')]
            if metadata_keys:
                print(f"    Metadata:")
                for key in metadata_keys[:5]:  # Show first 5 metadata items
                    print(f"        {key.replace('file_access.metadata.', '')}: {span.attributes[key]}")
        
        # Show search queries if present
        if search_query:
            print(f"\nSearch Queries:")
            print(f"    Query: {search_query}")
            print(f"    Source: {span.attributes.get('data_source.search.source', 'unknown')}")
            if span.attributes.get('data_source.search.result_count'):
                print(f"    Results: {span.attributes['data_source.search.result_count']}")
        
        # Show data lineage if present
        if span.attributes.get('data_lineage.enabled'):
            print(f"\nData Lineage:")
            print(f"    Source: {span.attributes.get('data_lineage.source', 'unknown')}")
            print(f"    Source Type: {span.attributes.get('data_lineage.source_type', 'unknown')}")
            file_count = span.attributes.get('data_lineage.file_count', 0)
            if file_count:
                print(f"    Files Accessed: {file_count}")
                # Show first few files
                for idx in range(min(5, file_count)):
                    file_name = span.attributes.get(f'data_lineage.file.{idx}.name')
                    original_source = span.attributes.get(f'data_lineage.file.{idx}.original_source')
                    if file_name:
                        print(f"       {idx+1}. {file_name}")
                        if original_source:
                            print(f"          Source: {original_source}")
                        content_length = span.attributes.get(f'data_lineage.file.{idx}.content_length')
                        if content_length:
                            print(f"          Content: {content_length} chars")
        
        if not source_attrs and not search_query and not span.attributes.get('data_lineage.enabled'):
            print(f"\nWARNING: No data sources tracked (files, URLs, SharePoint, search, etc.)")
    
    def _print_general_span(self, span: ReadableSpan):
        """Print general span information."""
        if self.debug_mode:
            print(f"\n[{self.span_count}] {span.name} ({self._format_duration(span.end_time - span.start_time)})")
            # In debug mode, also show client data and sources
            self._print_client_data(span)
            self._print_data_sources(span)
        else:
            if span.status.status_code == StatusCode.ERROR or span.end_time - span.start_time > 100_000_000:  # > 100ms
                print(f"\n⚠️  [{self.span_count}] {span.name} ({self._format_duration(span.end_time - span.start_time)}) - {span.status.status_code.name}")
                # Show client data and sources for errors or slow spans
                self._print_client_data(span)
                self._print_data_sources(span)
    
    def _extract_llm_attributes(self, attributes: dict) -> dict:
        """(No longer primary method for LLM spans, but kept for fallback)"""
        llm_attrs = {}
        llm_keywords = ['llm', 'prompt', 'response', 'model', 'token', 'input', 'output', 'completion', 'chat']
        
        for key, value in attributes.items():
            if any(keyword in key.lower() for keyword in llm_keywords):
                llm_attrs[key] = value
        
        adk_keys = [
            'gen_ai.request.model', 'gcp.vertex.agent.llm_request',
            'gcp.vertex.agent.llm_response', 'gen_ai.usage.input_tokens',
            'gen_ai.usage.output_tokens'
        ]
        for key in adk_keys:
            if key in attributes:
                llm_attrs[key] = attributes[key]
        
        return llm_attrs
    
    def _format_text(self, text: str) -> str:
        """Format long text for better readability."""
        if len(text) > 1000: # Increased limit
            return text[:1000] + "..."
        return text.replace('\n', '\n🤖    ') # Indent newlines
    
    def _format_duration(self, nanoseconds: int) -> str:
        """Format duration in human-readable format."""
        if nanoseconds < 1000:
            return f"{nanoseconds}ns"
        elif nanoseconds < 1_000_000:
            return f"{nanoseconds/1000:.1f}μs"
        elif nanoseconds < 1_000_000_000:
            return f"{nanoseconds/1_000_000:.1f}ms"
        else:
            return f"{nanoseconds/1_000_000_000:.2f}s"
    
    def shutdown(self) -> None:
        """Shutdown the exporter."""
        print(f"\nConsole Telemetry Summary:")
        print(f"Total spans exported: {self.span_count}")
        print(f"LLM interactions: {self.llm_interactions}")
        print(f"Agent interactions: {self.agent_interactions}")
        print("Console exporter shutdown complete")