"""Saf3AI Collector exporter for Saf3AI SDK."""

import threading
from typing import Dict, Optional, Sequence
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExportResult

from saf3ai_sdk.logging import logger


class Saf3AIOTLPExporter(OTLPSpanExporter):
    """Custom Saf3AI Collector exporter that sends telemetry data to Saf3AI Collector using HTTP."""
    
    def __init__(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        service_name: str = "saf3ai-agent",
        environment: str = "development",
        **kwargs
    ):
        """
        Initialize the Saf3AI Collector exporter.
        
        Args:
            endpoint: Saf3AI Collector HTTP endpoint (required, should be provided via SDK initialization)
            headers: Additional headers for Saf3AI Collector requests
            service_name: Name of the service being instrumented
            environment: Environment name
            **kwargs: Additional arguments passed to parent exporter
        """
        # Store endpoint and headers for debugging
        self._endpoint = endpoint
        self._headers = headers
        
        super().__init__(endpoint=endpoint, headers=headers, **kwargs)
        self.service_name = service_name
        self.environment = environment
        self._lock = threading.Lock()
        
        # Log headers (masked for security)
        if headers:
            masked_headers = {}
            for key, value in headers.items():
                if key.lower() in ['authorization', 'x-api-key', 'api-key']:
                    # Mask sensitive headers
                    if len(value) > 8:
                        masked_headers[key] = f"{value[:4]}...{value[-4:]}"
                    else:
                        masked_headers[key] = "****"
                else:
                    masked_headers[key] = value
            logger.info(f"OTLP exporter initialized with {len(headers)} header(s): {list(headers.keys())}")
            logger.debug(f"OTLP exporter headers (masked): {masked_headers}")
        else:
            logger.warning("OTLP exporter initialized WITHOUT headers - authentication may fail!")
        
        logger.info(f"Saf3AI Collector exporter initialized for {service_name} ({environment}) → {endpoint}")
    
    def _deduplicate_attributes(self, span: ReadableSpan) -> None:
        """
        Remove duplicate attributes from span to ensure each data point is logged only once.
        
        Deduplication rules:
        - Keep gen_ai.* format for GenAI-specific attributes
        - Keep standard OTEL formats (client.*, http.*) for compatibility
        - Remove redundant duplicates (e.g., ip_address, user_agent, browser_id without prefix)
        """
        if not hasattr(span, 'attributes') or not span.attributes:
            return
        
        try:
            span_attrs = dict(span.attributes)
            attrs_to_remove = set()
            
            # SDK now sends only OTEL standard attributes: client.ip, http.user_agent, client.id
            # (no gen_ai.client.ip / http.client_ip / ip_address duplicates)
            # Log if legacy duplicate keys appear (e.g. from older SDK or manual attrs)
            standard_client = {'client.ip', 'http.user_agent', 'client.id'}
            legacy = [k for k in span_attrs if k in ('ip_address', 'http.client_ip', 'gen_ai.client.ip', 'gen_ai.http.user_agent', 'gen_ai.client.id', 'user_agent', 'browser_id')]
            if legacy and any(k in span_attrs for k in standard_client):
                for dep_attr in legacy:
                    attrs_to_remove.add(dep_attr)
            if attrs_to_remove:
                logger.debug(
                    f"Span '{span.name}' has duplicate attributes that should be removed: {attrs_to_remove}. "
                    f"These should be fixed at the source to avoid duplicates in OpenSearch."
                )
        except Exception as e:
            logger.debug(f"Could not deduplicate attributes for span '{span.name}': {e}")
    
    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """
        Export spans to Saf3AI Collector.
        
        This exporter ensures all span attributes, including client data (IP, user agent, browser ID),
        are properly exported to OpenSearch via the Saf3AI Collector.
        It also checks for duplicate attributes and logs warnings.
        
        Args:
            spans: Sequence of spans to export
            
        Returns:
            SpanExportResult indicating success or failure
        """
        if not spans:
            return SpanExportResult.SUCCESS
        
        try:
            # CRITICAL: Log export attempt with details for debugging ADK export issues
            logger.info(f"[OpenSearch Export] Attempting to export {len(spans)} span(s) to {self._endpoint}")
            
            # Log span details for debugging
            for i, span in enumerate(spans):
                span_ctx = span.get_span_context()
                conv_id = span.attributes.get("gen_ai.conversation.id") or span.attributes.get("conversation_id")
                logger.debug(f"[OpenSearch Export] Span {i+1}/{len(spans)}: name='{span.name}', "
                           f"trace_id={span_ctx.trace_id:x}, span_id={span_ctx.span_id:x}, "
                           f"conversation_id={conv_id}")
            
            if self._headers:
                auth_header_present = "Authorization" in self._headers or "X-API-Key" in self._headers
                logger.debug(f"[OpenSearch Export] Headers present: Authorization={auth_header_present}")
            
            # Check for duplicate attributes and log warnings
            for span in spans:
                self._deduplicate_attributes(span)
            
            # Use parent OTLP exporter - it automatically exports all span attributes
            # All attributes set via span.set_attribute() will be included in the export
            result = super().export(spans)
            
            if result == SpanExportResult.SUCCESS:
                logger.info(f"[OpenSearch Export] ✅ Successfully exported {len(spans)} span(s) to Saf3AI Collector at {self._endpoint}")
            else:
                logger.error(f"[OpenSearch Export] ❌ Failed to export {len(spans)} span(s) to Saf3AI Collector at {self._endpoint}")
                logger.error(f"[OpenSearch Export]    This may indicate authentication failure or network issues. Check endpoint and headers.")
                logger.error(f"[OpenSearch Export]    Endpoint: {self._endpoint}")
                logger.error(f"[OpenSearch Export]    Headers keys: {list(self._headers.keys()) if self._headers else 'None'}")
            
            return result
            
        except Exception as e:
            error_msg = str(e)
            # Log more details for debugging
            logger.error(f"❌ Exception exporting spans to Saf3AI Collector: {error_msg}")
            logger.error(f"   Endpoint: {self._endpoint}")
            logger.error(f"   Spans count: {len(spans) if spans else 0}")
            logger.error(f"   Error type: {type(e).__name__}")
            if self._headers:
                logger.error(f"   Headers present: {list(self._headers.keys())}")
            # Log full exception for debugging
            import traceback
            logger.debug(f"Full traceback: {traceback.format_exc()}")
            return SpanExportResult.FAILURE
    
    def shutdown(self) -> None:
        """Shutdown the exporter."""
        try:
            # super().shutdown()
            logger.debug("Saf3AI Collector exporter shutdown complete")
        except Exception as e:
            logger.error(f"Error during Saf3AI Collector exporter shutdown: {e}")
