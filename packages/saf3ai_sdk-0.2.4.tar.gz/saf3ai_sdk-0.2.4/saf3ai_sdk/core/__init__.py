"""Core functionality for Saf3AI SDK."""

from .tracer import TracingCore, TraceContext, tracer
from .decorators import trace, agent, task, tool, workflow
from .traceable import traceable
from .metadata_extraction import (
    extract_document_metadata,
    extract_content_preview,
    log_retrieved_documents,
    extract_metadata_from_response
)

__all__ = [
    "TracingCore",
    "TraceContext", 
    "tracer",
    "trace",
    "agent",
    "task",
    "tool",
    "workflow",
    "traceable",
    "extract_document_metadata",
    "extract_content_preview",
    "log_retrieved_documents",
    "extract_metadata_from_response",
]
