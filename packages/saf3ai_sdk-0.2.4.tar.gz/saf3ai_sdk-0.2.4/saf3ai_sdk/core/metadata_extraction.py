"""
Metadata extraction utilities for capturing document metadata from retrieved sources.

This module provides utilities to extract metadata from documents retrieved by agents,
following OpenInference semantic conventions for document retrieval tracking.
"""

import json
import logging
from typing import Any, Dict, List, Optional, Union
from opentelemetry import trace

logger = logging.getLogger(__name__)


def extract_document_metadata(doc: Any) -> Dict[str, Any]:
    """
    Extract metadata from a LangChain Document object or similar document structure.
    
    Args:
        doc: Document object (LangChain Document, or dict-like object)
    
    Returns:
        Dictionary containing extracted metadata with standardized keys
    """
    metadata = {}
    
    try:
        # Handle LangChain Document objects
        if hasattr(doc, 'metadata') and doc.metadata:
            metadata.update(doc.metadata)
        
        # Handle dict-like objects
        elif isinstance(doc, dict):
            if 'metadata' in doc:
                metadata.update(doc['metadata'])
            # Also check if the dict itself is metadata
            elif 'filename' in doc or 'source' in doc or 'file_path' in doc:
                metadata.update(doc)
        
        # Extract common metadata fields
        extracted = {}
        
        # Filename extraction (try multiple common keys)
        # Prefer explicit filename fields, fallback to extracting from source/path
        filename = (
            metadata.get('filename') or 
            metadata.get('file_name') or 
            metadata.get('name')
        )
        
        # File path extraction (prefer explicit path fields)
        file_path = (
            metadata.get('file_path') or 
            metadata.get('filepath') or 
            metadata.get('path')
        )
        
        # Source extraction (original source URL/path)
        source = metadata.get('source') or metadata.get('url') or metadata.get('uri')
        
        # If we have source but no file_path, use source as file_path
        if source and not file_path:
            file_path = source
        
        # Extract filename from file_path if filename not explicitly set
        if not filename and file_path:
            import os
            # If file_path looks like a path, extract basename
            if '/' in file_path or '\\' in file_path:
                filename = os.path.basename(file_path)
            else:
                # If it's just a filename, use it as-is
                filename = file_path
        
        # If still no filename but we have source, use source
        if not filename and source:
            import os
            # If source looks like a path, extract basename
            if '/' in source or '\\' in source:
                filename = os.path.basename(source)
            else:
                filename = source
        
        if filename:
            extracted['filename'] = filename
        
        if file_path:
            extracted['file_path'] = str(file_path)
        
        if source:
            extracted['original_source'] = str(source)
        
        # Source type extraction
        source_type = (
            metadata.get('source_type') or 
            metadata.get('source') or
            metadata.get('type')
        )
        if source_type:
            extracted['source_type'] = str(source_type)
        
        # Original source (URL, file path, etc.)
        original_source = (
            metadata.get('original_source') or
            metadata.get('url') or
            metadata.get('uri') or
            file_path
        )
        if original_source:
            extracted['original_source'] = str(original_source)
        
        # Page number (for PDFs, etc.)
        if 'page' in metadata:
            extracted['page'] = metadata['page']
        elif 'page_number' in metadata:
            extracted['page'] = metadata['page_number']
        
        # Chunk index
        if 'chunk_index' in metadata:
            extracted['chunk_index'] = metadata['chunk_index']
        
        # Add any other custom metadata fields
        for key, value in metadata.items():
            if key not in ['filename', 'file_name', 'name', 'file_path', 'filepath', 
                          'path', 'source_type', 'source', 'type', 'original_source',
                          'url', 'uri', 'page', 'page_number', 'chunk_index']:
                # Only include simple types that can be serialized
                if isinstance(value, (str, int, float, bool, type(None))):
                    extracted[f'metadata.{key}'] = value
        
        return extracted
        
    except Exception as e:
        logger.debug(f"Error extracting document metadata: {e}")
        return {}


def extract_content_preview(doc: Any, max_length: int = 200) -> str:
    """
    Extract a preview of document content.
    
    Args:
        doc: Document object
        max_length: Maximum length of preview
    
    Returns:
        Content preview string
    """
    try:
        # LangChain Document objects
        if hasattr(doc, 'page_content'):
            content = doc.page_content
        elif hasattr(doc, 'content'):
            content = doc.content
        # Dict-like objects
        elif isinstance(doc, dict):
            content = doc.get('page_content') or doc.get('content') or doc.get('text', '')
        else:
            content = str(doc)
        
        if isinstance(content, str):
            if len(content) > max_length:
                return content[:max_length] + "..."
            return content
        return str(content)[:max_length] if content else ""
        
    except Exception as e:
        logger.debug(f"Error extracting content preview: {e}")
        return ""


def log_retrieved_documents(
    documents: List[Any],
    span: Optional[trace.Span] = None,
    query: Optional[str] = None
) -> None:
    """
    Log retrieved documents to OpenTelemetry span using OpenInference conventions.
    
    This function follows OpenInference semantic conventions:
    - gen_ai.retrieval.documents[*].id
    - gen_ai.retrieval.documents[*].content
    - gen_ai.retrieval.documents[*].metadata.*
    
    Args:
        documents: List of Document objects retrieved
        span: OpenTelemetry span to log to (if None, uses current span)
        query: The query that triggered the retrieval (optional)
    """
    if not documents:
        return
    
    try:
        # Get current span if not provided
        if span is None:
            span = trace.get_current_span()
        
        if not span or not span.is_recording():
            return
        
        # Set retrieval query if provided
        if query:
            span.set_attribute("gen_ai.retrieval.query", str(query))
        
        # Set number of retrieved documents
        span.set_attribute("gen_ai.retrieval.documents_count", len(documents))
        
        # Extract and log each document
        document_attributes = []
        
        for idx, doc in enumerate(documents):
            try:
                # Extract metadata
                doc_metadata = extract_document_metadata(doc)
                
                # Extract content preview
                content_preview = extract_content_preview(doc, max_length=500)
                
                # Create document ID (use filename with index for readability)
                filename = doc_metadata.get('filename', '')
                if filename:
                    # Include index in ID for clarity: "filename_0", "filename_1", etc.
                    doc_id = f"{filename}_{idx}" if len(documents) > 1 else filename
                else:
                    doc_id = f"doc_{idx}"
                
                # Build document attributes following OpenInference conventions
                doc_attrs = {
                    "id": doc_id,
                    "content": content_preview,
                }
                
                # Add metadata fields
                if doc_metadata:
                    doc_attrs["metadata"] = doc_metadata
                
                document_attributes.append(doc_attrs)
                
                # Set individual document attributes on span
                # Using OpenInference convention: gen_ai.retrieval.documents[*]
                prefix = f"gen_ai.retrieval.documents[{idx}]"
                
                # Document ID (readable format: filename_index or doc_index)
                span.set_attribute(f"{prefix}.id", doc_id)
                
                # Content preview (truncated)
                if content_preview:
                    span.set_attribute(f"{prefix}.content", content_preview)
                
                # Set metadata fields (standardized format)
                if doc_metadata.get('filename'):
                    span.set_attribute(f"{prefix}.metadata.filename", doc_metadata['filename'])
                if doc_metadata.get('file_path'):
                    # Ensure file_path shows actual path, not just filename
                    span.set_attribute(f"{prefix}.metadata.file_path", doc_metadata['file_path'])
                if doc_metadata.get('original_source'):
                    span.set_attribute(f"{prefix}.metadata.original_source", doc_metadata['original_source'])
                if doc_metadata.get('source_type'):
                    span.set_attribute(f"{prefix}.metadata.source_type", doc_metadata['source_type'])
                if doc_metadata.get('page'):
                    span.set_attribute(f"{prefix}.metadata.page", doc_metadata['page'])
                if doc_metadata.get('chunk_index') is not None:
                    span.set_attribute(f"{prefix}.metadata.chunk_index", doc_metadata['chunk_index'])
                
                # Set other metadata fields (custom metadata from document)
                for key, value in doc_metadata.items():
                    if key not in ['filename', 'file_path', 'source_type', 'original_source', 'page', 'chunk_index']:
                        if isinstance(value, (str, int, float, bool)):
                            # Clean key name for attribute (replace dots/spaces with underscores)
                            clean_key = key.replace('.', '_').replace(' ', '_').replace('-', '_')
                            span.set_attribute(f"{prefix}.metadata.{clean_key}", str(value))
                
            except Exception as e:
                logger.debug(f"Error logging document {idx}: {e}")
                continue
        
        # Also set a JSON representation of all documents (for complex queries)
        try:
            # Create simplified representation
            docs_summary = [
                {
                    "id": doc_attrs.get("id", f"doc_{i}"),
                    "filename": doc_attrs.get("metadata", {}).get("filename", ""),
                    "source_type": doc_attrs.get("metadata", {}).get("source_type", ""),
                }
                for i, doc_attrs in enumerate(document_attributes)
            ]
            span.set_attribute("gen_ai.retrieval.documents_summary", json.dumps(docs_summary))
        except Exception:
            pass
        
        logger.debug(f"Logged {len(document_attributes)} retrieved documents to span")
        
    except Exception as e:
        logger.debug(f"Error logging retrieved documents: {e}")


def extract_metadata_from_response(response: Any) -> List[Dict[str, Any]]:
    """
    Extract document metadata from LLM response objects.
    
    Some frameworks include source documents in the response.
    This function attempts to extract them.
    
    Args:
        response: LLM response object (varies by framework)
    
    Returns:
        List of document metadata dictionaries
    """
    documents = []
    
    try:
        # LangChain: Check for source_documents in response
        if hasattr(response, 'source_documents'):
            for doc in response.source_documents:
                metadata = extract_document_metadata(doc)
                if metadata:
                    documents.append(metadata)
        
        # Dict responses
        elif isinstance(response, dict):
            # Check common keys
            if 'source_documents' in response:
                for doc in response['source_documents']:
                    metadata = extract_document_metadata(doc)
                    if metadata:
                        documents.append(metadata)
            elif 'sources' in response:
                for source in response['sources']:
                    if isinstance(source, dict) and 'metadata' in source:
                        metadata = extract_document_metadata(source)
                        if metadata:
                            documents.append(metadata)
        
    except Exception as e:
        logger.debug(f"Error extracting metadata from response: {e}")
    
    return documents
