"""Core tracing functionality for Saf3AI SDK."""

import atexit
import threading
from typing import Optional, Any, Dict, Union, Callable
from opentelemetry import trace, metrics
from opentelemetry.sdk.trace import TracerProvider, Span
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor
from opentelemetry.sdk.resources import Resource
from opentelemetry.trace.status import StatusCode
from opentelemetry import context as context_api

from saf3ai_sdk.config import Config
from saf3ai_sdk.logging import logger
from saf3ai_sdk.core.constants import AttributeNames

# Unified conversation ID helpers - used by all frameworks for consistency
def get_conversation_id_unified() -> Optional[str]:
    """
    Unified helper to get conversation_id - used by ALL frameworks (ADK, LangChain, Custom).
    
    UNIFIED PRIORITY ORDER (same across all frameworks):
    1. Custom attributes (set via set_custom_attributes) - **SINGLE SOURCE OF TRUTH** (checked FIRST)
    2. Current span attributes (gen_ai.conversation.id) - only if custom_attributes is empty
    3. Parent span attributes - fallback for child spans, only if custom_attributes is empty
    4. None - will be auto-generated if needed
    
    CRITICAL: Custom attributes is the SINGLE SOURCE OF TRUTH and checked FIRST.
    This prevents individual spans with wrong conversation_ids from overriding the correct one.
    If a span has a conversation_id but custom_attributes is empty, we store it in custom_attributes
    so future calls use the same ID.
    
    All frameworks MUST use this function to get conversation_id.
    Never generate new IDs if this function returns a value.
    
    This ensures consistent conversation stitching across ADK, LangChain, and custom agents.
    
    Returns:
        Conversation ID string or None
    """
    try:
        # CRITICAL FIX: Custom attributes MUST be checked FIRST - it's the SINGLE SOURCE OF TRUTH
        # If custom_attributes has a conversation_id, use that. Don't let individual spans override it.
        # Priority 1: Custom attributes (set by callbacks/instrumentation) - SINGLE SOURCE OF TRUTH
        custom_attrs = tracer.get_custom_attributes()
        conv_id = custom_attrs.get(AttributeNames.GEN_AI_CONVERSATION_ID) or custom_attrs.get(AttributeNames.CONVERSATION_ID)
        if conv_id:
            logger.debug(f"[UNIFIED] Found conversation_id in custom attributes (SINGLE SOURCE): {conv_id}")
            return str(conv_id)
        
        # Priority 2: Current span attributes (only if custom_attributes is empty)
        # This allows spans to inherit from parent spans when custom_attributes hasn't been set yet
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            conv_id = current_span.attributes.get(AttributeNames.GEN_AI_CONVERSATION_ID)
            if conv_id:
                logger.debug(f"[UNIFIED] Found conversation_id in current span (no custom_attrs): {conv_id}")
                # CRITICAL: Store in custom_attributes so future calls use it
                tracer.set_custom_attributes({
                    AttributeNames.GEN_AI_CONVERSATION_ID: str(conv_id),
                    AttributeNames.CONVERSATION_ID: str(conv_id),
                })
                return str(conv_id)
        
        # Priority 3: Parent span attributes (for child spans, only if custom_attributes is empty)
        if current_span and current_span.is_recording():
            attrs = getattr(current_span, 'attributes', None)
            if attrs:
                conv_id = attrs.get(AttributeNames.GEN_AI_CONVERSATION_ID) or attrs.get(AttributeNames.CONVERSATION_ID)
                if conv_id:
                    logger.debug(f"[UNIFIED] Found conversation_id in parent span (no custom_attrs): {conv_id}")
                    # CRITICAL: Store in custom_attributes so future calls use it
                    tracer.set_custom_attributes({
                        AttributeNames.GEN_AI_CONVERSATION_ID: str(conv_id),
                        AttributeNames.CONVERSATION_ID: str(conv_id),
                    })
                    return str(conv_id)
    except Exception as e:
        logger.debug(f"[UNIFIED] Error getting conversation_id: {e}")
    
    return None


def set_conversation_id_unified(conversation_id: str, source: str = "unknown", update_spans: bool = True, force: bool = False) -> None:
    """
    Unified helper to set conversation_id - used by ALL frameworks (ADK, LangChain, Custom).
    
    CRITICAL: This is the SINGLE SOURCE OF TRUTH for setting conversation IDs.
    All frameworks MUST use this function to set conversation_id.
    
    This ensures all spans in the same conversation share the same ID for proper stitching.
    
    Args:
        conversation_id: The conversation ID to set
        source: Where the ID came from (for debugging)
        update_spans: If True, also updates current span and framework-specific spans
        force: If True, overwrites existing conversation_id. If False, preserves existing ID.
    """
    try:
        # CRITICAL: Check if conversation_id already exists - NEVER overwrite unless forced
        if not force:
            existing_conv_id = get_conversation_id_unified()
            if existing_conv_id and existing_conv_id != conversation_id:
                logger.info(f"[UNIFIED] Conversation_id already exists ({existing_conv_id}), not overwriting with {conversation_id} from {source}")
                return
            elif existing_conv_id == conversation_id:
                logger.debug(f"[UNIFIED] Conversation_id already set to {conversation_id} from {source}")
                return
        
        # Set in custom attributes (highest priority - propagates to all future spans)
        tracer.set_custom_attributes({
            AttributeNames.GEN_AI_CONVERSATION_ID: conversation_id,
            AttributeNames.CONVERSATION_ID: conversation_id,
        })
        logger.info(f"[UNIFIED] Set conversation_id from {source}: {conversation_id} (force={force})")
        
        # CRITICAL: If conversation_id is adk_session_*, sync ADK's persistent_session_id
        # This ensures persistent_session_id matches conversation_id in custom_attributes
        if isinstance(conversation_id, str) and conversation_id.startswith("adk_session_"):
            try:
                from saf3ai_sdk.instrumentation.adk_instrumentation import _persistent_session_lock
                import saf3ai_sdk.instrumentation.adk_instrumentation as adk_module
                with _persistent_session_lock:
                    if adk_module._current_persistent_session_id != conversation_id:
                        logger.debug(f"[UNIFIED] Syncing ADK persistent_session_id to match conversation_id: {conversation_id}")
                        adk_module._current_persistent_session_id = conversation_id
            except (ImportError, AttributeError) as e:
                logger.debug(f"Could not sync ADK persistent_session_id: {e}")
        
        if update_spans:
            # Update current span if it exists
            try:
                current_span = trace.get_current_span()
                if current_span and current_span.is_recording():
                    current_span.set_attribute(AttributeNames.GEN_AI_CONVERSATION_ID, conversation_id)
                    current_span.set_attribute(AttributeNames.CONVERSATION_ID, conversation_id)
                    logger.debug(f"Updated current span with conversation_id: {conversation_id}")
            except Exception as e:
                logger.debug(f"Could not update current span: {e}")
            
            # Update framework-specific spans if they exist
            # LangChain span
            try:
                from saf3ai_sdk.instrumentation.langchain_instrumentation import _current_langchain_span
                langchain_span = getattr(_current_langchain_span, 'span', None)
                if langchain_span and langchain_span.is_recording():
                    langchain_span.set_attribute(AttributeNames.GEN_AI_CONVERSATION_ID, conversation_id)
                    langchain_span.set_attribute(AttributeNames.CONVERSATION_ID, conversation_id)
                    logger.debug(f"Updated LangChain span with conversation_id: {conversation_id}")
            except (ImportError, AttributeError) as e:
                logger.debug(f"Could not update LangChain span: {e}")
            
            # ADK agent span
            try:
                from saf3ai_sdk.instrumentation.adk_instrumentation import _current_agent_span
                agent_span = getattr(_current_agent_span, 'span', None)
                if agent_span and agent_span.is_recording():
                    agent_span.set_attribute(AttributeNames.GEN_AI_CONVERSATION_ID, conversation_id)
                    agent_span.set_attribute(AttributeNames.CONVERSATION_ID, conversation_id)
                    logger.debug(f"Updated ADK agent span with conversation_id: {conversation_id}")
            except (ImportError, AttributeError) as e:
                logger.debug(f"Could not update ADK agent span: {e}")
    except Exception as e:
        logger.debug(f"Failed to set conversation_id: {e}")


def ensure_conversation_id_on_span(span, conversation_id: Optional[str] = None) -> Optional[str]:
    """
    Ensure a span has conversation_id set - used by ALL frameworks.
    
    If conversation_id is not provided, gets it using unified logic.
    If span doesn't have conversation_id, sets it.
    
    Args:
        span: The span to ensure conversation_id on
        conversation_id: Optional conversation_id (if None, will be retrieved)
    
    Returns:
        The conversation_id that was set/retrieved
    """
    if not span or not span.is_recording():
        return conversation_id
    
    # Get conversation_id if not provided
    if not conversation_id:
        # First check if span already has it
        conversation_id = span.attributes.get(AttributeNames.GEN_AI_CONVERSATION_ID)
        if not conversation_id:
            # Use unified helper
            conversation_id = get_conversation_id_unified()
    
    # Set on span if we have one
    if conversation_id:
        span.set_attribute(AttributeNames.GEN_AI_CONVERSATION_ID, conversation_id)
        span.set_attribute(AttributeNames.CONVERSATION_ID, conversation_id)
    
    return conversation_id

# Get SDK version from package metadata
try:
    from importlib.metadata import version, PackageNotFoundError
    try:
        SDK_VERSION = version("saf3ai-sdk")
    except PackageNotFoundError:
        # Fallback if package not installed (e.g., during development)
        SDK_VERSION = "0.1.0"
except ImportError:
    # Python < 3.8 fallback
    try:
        import importlib_metadata
        SDK_VERSION = importlib_metadata.version("saf3ai-sdk")
    except Exception:
        SDK_VERSION = "0.1.0"


class TraceContext:
    """Context manager for trace spans."""
    
    def __init__(self, span: Span, token: Optional[context_api.Token] = None):
        self.span = span
        self.token = token
        self._end_state = StatusCode.UNSET
    
    def __enter__(self) -> "TraceContext":
        """Enter the trace context."""
        return self
    
    def __exit__(self, exc_type: Optional[type], exc_val: Optional[Exception], exc_tb: Optional[Any]) -> bool:
        """Exit the trace context and end the trace."""
        if exc_type is not None:
            self._end_state = StatusCode.ERROR
            if exc_val:
                logger.debug(f"Trace exiting with exception: {exc_val}")
        else:
            self._end_state = StatusCode.OK
        
        try:
            tracer.end_trace(self, self._end_state)
        except Exception as e:
            logger.error(f"Error ending trace in context manager: {e}")
        
        return False


class TracingCore:
    """Central component for tracing in Saf3AI SDK."""
    
    def __init__(self) -> None:
        """Initialize the tracing core."""
        self.provider: Optional[TracerProvider] = None
        self._initialized = False
        self._config: Optional[Config] = None
        self._active_traces: Dict[str, TraceContext] = {}
        self._traces_lock = threading.Lock()
        self._agent_id: Optional[str] = None  # Store agent ID
        self._custom_attributes: Dict[str, Any] = {}  # Store custom attributes like user_id, employee_id
        
        # Register shutdown handler
        atexit.register(self.shutdown)
    
    def _build_exporter_headers(self, config: Config) -> Dict[str, str]:
        """
        Build HTTP headers for the OTLP exporter including authentication.
        
        When api_key is provided (in init or env), auth headers are set automatically.
        No need to pass safeai_collector_headers or set auth in env.
        
        Strategy:
        - If user provided custom auth headers: use only those (respect user choice).
        - If api_key is set and valid: automatically add BOTH X-API-Key and Authorization Bearer.
        - Server accepts EITHER header (OR condition) - both are set for maximum compatibility.
        - User doesn't need to configure headers manually - automatic when api_key is verified.
        
        Args:
            config: SDK configuration containing headers and api_key
            
        Returns:
            Dictionary of HTTP headers for the exporter
        """
        headers: Dict[str, str] = {}
        
        # Start with user-provided custom headers (if any) - highest priority
        if config.safeai_headers:
            try:
                headers.update(config.safeai_headers)
                logger.debug(f"Added {len(config.safeai_headers)} custom header(s) to exporter")
            except (TypeError, ValueError) as e:
                logger.warning(f"Invalid safeai_headers format, skipping: {e}")
        
        # Auto-set auth from api_key when key is passed (no header config needed)
        # Automatically add BOTH headers - server accepts EITHER one (OR condition)
        if config.api_key:
            api_key = config.api_key.strip()
            if not api_key:
                logger.warning("api_key is empty after stripping whitespace, skipping auth headers")
            else:
                # Only add if user did not already set auth headers
                has_auth = any(
                    k.lower() in ('authorization', 'x-api-key', 'api-key')
                    for k in headers.keys()
                )
                if has_auth:
                    logger.debug("Auth header(s) already provided, not adding automatic auth")
                else:
                    # Automatically set BOTH headers - server accepts EITHER one (OR condition)
                    # This ensures compatibility with both on-prem (X-API-Key) and SaaS (Bearer) systems
                    headers["X-API-Key"] = api_key
                    headers["Authorization"] = f"Bearer {api_key}"
                    masked = f"{api_key[:4]}...{api_key[-4:]}" if len(api_key) > 8 else "****"
                    logger.info(
                        f"Auto-added auth headers (X-API-Key + Authorization Bearer) from api_key (key: {masked}). "
                        f"Server accepts either header (OR condition)."
                    )
        else:
            logger.debug("No api_key configured, exporter will not include authentication headers")
        
        return headers
    
    def initialize(self, config: Config) -> None:
        """Initialize the tracing core with configuration."""
        if self._initialized:
            logger.debug("Tracing core already initialized")
            return
        
        self._config = config
        config.validate()
        
        # Create resource attributes
        resource_attrs = {
            "service.name": config.service_name,
            "service.environment": config.environment,
            "service.version": SDK_VERSION,
            "saf3ai.sdk.version": SDK_VERSION,
            "saf3ai.sdk.type": "agent_telemetry",
        }
        
        # Extract agent_id from custom attributes if present
        # Note: Custom attributes may be set before or after initialization
        if 'agent_id' in self._custom_attributes:
            self._agent_id = self._custom_attributes['agent_id']
        
        resource = Resource(resource_attrs)

        # --- CREATE OUR OWN TRACERPROVIDER ---
        # Always create our own TracerProvider instance
        self.provider = TracerProvider(resource=resource)
        logger.info("Created new TracerProvider instance")
        
        # Force our TracerProvider to be the global one
        # This ensures all spans (including ADK spans) go through our processors
        current_provider = trace.get_tracer_provider()
        if isinstance(current_provider, trace.NoOpTracerProvider):
            trace.set_tracer_provider(self.provider)
            logger.info("Set our TracerProvider as the global provider")
        else:
            logger.warning("An existing TracerProvider is already set globally")
            logger.warning("Forcing our TracerProvider to be the global one")
            # Force our provider to be used globally
            trace.set_tracer_provider(self.provider)
            logger.info("Successfully overrode the global TracerProvider")
        # --- END OF TRACERPROVIDER LOGIC ---
        
        # Create and add span processor
        logger.info(f"Console output enabled: {config.console_output}")
        logger.info(f"Debug mode enabled: {config.debug_mode}")
        
        # Create exporters and processors
        exporters = []
        processors = []
        
        # Always add Saf3AI Collector exporter for telemetry collection
        from saf3ai_sdk.core.exporters import Saf3AIOTLPExporter
        
        # Build headers for OTLP exporter with authentication
        exporter_headers = self._build_exporter_headers(config)
        
        # Log header building result
        if exporter_headers:
            logger.info(f"Built {len(exporter_headers)} header(s) for OTLP exporter: {list(exporter_headers.keys())}")
            if "Authorization" in exporter_headers:
                masked_auth = exporter_headers["Authorization"][:15] + "..." if len(exporter_headers["Authorization"]) > 15 else "****"
                logger.info(f"  ✓ Authorization header present: {masked_auth}")
            else:
                logger.warning("  ⚠ No Authorization header in exporter headers - authentication may fail!")
        else:
            logger.warning("⚠ No headers built for OTLP exporter - authentication will fail!")
        
        try:
            otlp_exporter = Saf3AIOTLPExporter(
                endpoint=config.safeai_endpoint,
                headers=exporter_headers if exporter_headers else None,
                service_name=config.service_name,
                environment=config.environment
            )
            exporters.append(otlp_exporter)
            logger.info(f"Saf3AI Collector exporter initialized successfully → {config.safeai_endpoint}")
        except Exception as e:
            logger.error(f"Failed to initialize Saf3AI Collector exporter: {e}")
            raise RuntimeError(f"Failed to initialize telemetry exporter: {e}") from e
        
        if config.console_output:
            # Add console exporter for debugging
            from saf3ai_sdk.core.exporters.console_exporter import ConsoleTelemetryExporter
            console_exporter = ConsoleTelemetryExporter(debug_mode=config.debug_mode)
            exporters.append(console_exporter)
            logger.info("Console telemetry output enabled - all spans will be printed to terminal")
        
        # Create processors for each exporter
        for i, exporter in enumerate(exporters):
            # Use SimpleSpanProcessor for console exporter (immediate export)
            # Use SimpleSpanProcessor for Saf3AI Collector exporter (immediate export)
            if config.console_output and i == len(exporters) - 1:  # Last exporter is console
                processor = SimpleSpanProcessor(exporter)
                logger.info(f"Using SimpleSpanProcessor for console exporter (immediate export)")
            else:
                processor = SimpleSpanProcessor(exporter)  # Changed to SimpleSpanProcessor for immediate export
                logger.info(f"Using SimpleSpanProcessor for Saf3AI Collector exporter (immediate export)")
            processors.append(processor)
        
        logger.info(f"Created {len(processors)} span processors for {len(exporters)} exporters")
        
        # Add all processors we created
        if hasattr(self.provider, 'add_span_processor'):
            for i, processor in enumerate(processors):
                self.provider.add_span_processor(processor)
                logger.info(f"Added span processor {i+1}/{len(processors)} to provider: {type(processor).__name__}")
            logger.info(f"Added {len(processors)} span processors to provider")
        else:
            logger.error(f"Cannot add span processor to provider of type {type(self.provider)}. Telemetry will not work.")
        
        self._initialized = True
        logger.info(f"Saf3AI tracing core initialized for service: {config.service_name}")
    
    @property
    def initialized(self) -> bool:
        """Check if the tracing core is initialized."""
        return self._initialized
    
    def get_tracer(self, name: str = "saf3ai") -> trace.Tracer:
        """Get a tracer with the given name."""
        if not self._initialized:
            raise RuntimeError("Tracing core not initialized")
        
        # Use our own TracerProvider instance instead of the global one
        # This ensures spans are processed by our span processors
        if self.provider:
            logger.debug(f"Getting tracer '{name}' from our TracerProvider instance")
            return self.provider.get_tracer(name)
        else:
            logger.warning(f"TracerProvider not available, falling back to global provider")
            return trace.get_tracer(name)
    
    def get_current_span(self):
        """Get the current active span."""
        return trace.get_current_span()
    
    def get_active_trace(self):
        """Get the currently active trace if any."""
        with self._traces_lock:
            if self._active_traces:
                # Return the most recent active trace
                return list(self._active_traces.values())[-1]
        return None
    
    def start_as_current_span(self, name: str, **kwargs):
        """Start a span and set it as the current span with proper context propagation."""
        tracer = self.get_tracer()
        
        # If context is provided, use it; otherwise use current context
        context = kwargs.get('context', context_api.get_current())
        
        # Remove context from kwargs to avoid passing it to start_span
        span_kwargs = {k: v for k, v in kwargs.items() if k != 'context'}
        
        # Start span with the specified context
        span = tracer.start_span(name, context=context, **span_kwargs)
        
        # Return a context manager that sets the span as current
        return trace.use_span(span, end_on_exit=True)
    
    def start_as_current_span_with_parent(self, name: str, parent_span: Span, **kwargs):
        """Start a span with an explicit parent span and set it as current."""
        tracer = self.get_tracer()
        parent_context = trace.set_span_in_context(parent_span)
        return tracer.start_as_current_span(name, context=parent_context, **kwargs)
    
    def start_trace(
        self, 
        trace_name: str = "session", 
        tags: Optional[Dict[str, Any]] = None
    ) -> Optional[TraceContext]:
        """Start a new trace (root span) and return its context."""
        if not self._initialized:
            logger.warning("Tracing core not initialized. Cannot start trace.")
            return None
        
        # Build trace attributes
        attributes = {
            "trace.name": trace_name,
            "trace.type": "session",
            "service.name": self._config.service_name,
            "service.environment": self._config.environment,
            "saf3ai.sdk.version": SDK_VERSION,  # CHANGED: Use dynamic version instead of hardcoded "0.1.0"
            "saf3ai.sdk.type": "agent_telemetry",
        }
        
        if tags:
            attributes.update(tags)
        
        # Create span
        span, context_token = self._create_span(
            operation_name=trace_name,
            span_kind="session",
            attributes=attributes
        )
        
        logger.debug(f"Trace '{trace_name}' started with span ID: {span.get_span_context().span_id}")
        
        trace_context = TraceContext(span, token=context_token)
        
        # Track the active trace
        with self._traces_lock:
            try:
                trace_id = f"{span.get_span_context().trace_id:x}"
            except (TypeError, ValueError):
                trace_id = str(span.get_span_context().trace_id)
            
            self._active_traces[trace_id] = trace_context
            logger.debug(f"Added trace {trace_id} to active traces. Total active: {len(self._active_traces)}")
        
        return trace_context
    
    def end_trace(
        self, 
        trace_context: Optional[TraceContext] = None, 
        end_state: Union[StatusCode, str] = StatusCode.OK
    ) -> None:
        """End a trace (its root span) and finalizes it."""
        if not self._initialized:
            logger.warning("Tracing core not initialized. Cannot end trace.")
            return
        
        # If no specific trace_context provided, end all active traces
        if trace_context is None:
            with self._traces_lock:
                active_traces = list(self._active_traces.values())
                logger.debug(f"Ending all {len(active_traces)} active traces")
            
            for active_trace in active_traces:
                self._end_single_trace(active_trace, end_state)
            return
        
        # End specific trace
        self._end_single_trace(trace_context, end_state)
    
    def _end_single_trace(self, trace_context: TraceContext, end_state: Union[StatusCode, str]) -> None:
        """Internal method to end a single trace."""
        if not trace_context or not trace_context.span:
            logger.warning("Invalid TraceContext or span provided to end trace.")
            return
        
        span = trace_context.span
        token = trace_context.token
        
        try:
            trace_id = f"{span.get_span_context().trace_id:x}"
        except (TypeError, ValueError):
            trace_id = str(span.get_span_context().trace_id)
        
        logger.debug(f"Ending trace with span ID: {span.get_span_context().span_id}")
        
        try:
            # Set span status
            if isinstance(end_state, StatusCode):
                span.set_status(end_state)
            else:
                # Convert string to StatusCode
                if end_state.lower() in ["success", "ok"]:
                    span.set_status(StatusCode.OK)
                elif end_state.lower() in ["error", "failed"]:
                    span.set_status(StatusCode.ERROR)
                else:
                    span.set_status(StatusCode.UNSET)
            
            # End the span
            span.end()
            
            # Detach context token
            if token:
                context_api.detach(token)
            
            # Remove from active traces
            with self._traces_lock:
                if trace_id in self._active_traces:
                    del self._active_traces[trace_id]
                    logger.debug(f"Removed trace {trace_id} from active traces. Remaining: {len(self._active_traces)}")
            
        except Exception as e:
            logger.error(f"Error ending trace: {e}")
    
    def _create_span(
        self,
        operation_name: str,
        span_kind: str = "internal",
        attributes: Optional[Dict[str, Any]] = None,
        parent_span: Optional[Span] = None
    ) -> tuple[Span, context_api.Token]:
        """Create a span and return it with context token."""
        tracer = self.get_tracer()
        
        # Create span name
        span_name = f"{operation_name}.{span_kind}"
        
        # Build default attributes
        default_attributes = {
            "service.name": self._config.service_name,
            "service.environment": self._config.environment,
            "saf3ai.sdk.version": SDK_VERSION,  # CHANGED: Use dynamic version instead of hardcoded "0.1.0"
            "saf3ai.sdk.type": "agent_telemetry",
        }
        
        # AUTOMATIC CLIENT DATA CAPTURE: Extract and add client data to attributes
        # This ensures all spans created via _create_span have client data automatically
        # This runs on EVERY span creation, ensuring client data is always captured
        try:
            import os
            client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
            if client_data_capture_enabled:
                from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data
                client_data = extract_comprehensive_client_data()
                
                # Log client data capture for verification (only log once per unique combination)
                if client_data.get('ip_address') or client_data.get('user_agent') or client_data.get('agent_id'):
                    logger.debug("Client data captured automatically")
                else:
                    logger.debug("No client data captured - using fallback methods")
                
                # Add agent ID (ALWAYS include if available) - Keep gen_ai format for agent_id (not client data)
                if client_data.get('agent_id'):
                    default_attributes["gen_ai.agent_id"] = client_data['agent_id']
                    default_attributes["gen_ai.agent.name"] = client_data['agent_id']
                
                # Add client data - OTEL standard attributes only (no gen_ai/http duplicates)
                if client_data.get('user_agent'):
                    default_attributes["http.user_agent"] = client_data['user_agent']
                if client_data.get('ip_address'):
                    default_attributes["client.ip"] = client_data['ip_address']
                if client_data.get('browser_id'):
                    default_attributes["client.id"] = client_data['browser_id']
                for key in ['device_type', 'os_name', 'os_version', 'platform']:
                    if client_data.get(key):
                        default_attributes[f"client.{key}"] = client_data[key]
        except Exception as e:
            logger.debug(f"Could not extract client data in _create_span: {e}")
        
        # Merge with provided attributes
        if attributes:
            default_attributes.update(attributes)
        
        # Determine the context to use
        if parent_span:
            # Use the provided parent span's context
            parent_context = trace.set_span_in_context(parent_span)
            span = tracer.start_span(span_name, context=parent_context, attributes=default_attributes)
        else:
            # Get current context
            current_context = context_api.get_current()
            span = tracer.start_span(span_name, context=current_context, attributes=default_attributes)
        
        # AUTOMATIC CLIENT DATA CAPTURE: Also add to span after creation (in case extraction happened after)
        try:
            import os
            client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
            if client_data_capture_enabled and span and span.is_recording():
                from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                client_data = extract_comprehensive_client_data()
                if client_data.get('ip_address') or client_data.get('user_agent'):
                    _add_client_data_to_span(span, client_data)
        except Exception as e:
            logger.debug(f"Could not add client data to span after creation: {e}")
        
        # Set span as current context
        ctx = trace.set_span_in_context(span)
        token = context_api.attach(ctx)
        
        return span, token
    
    def get_active_traces(self) -> Dict[str, TraceContext]:
        """Get a copy of currently active traces."""
        with self._traces_lock:
            return self._active_traces.copy()
    
    def get_active_trace_count(self) -> int:
        """Get the number of currently active traces."""
        with self._traces_lock:
            return len(self._active_traces)
    
    def shutdown(self) -> None:
        """Shutdown the tracing core and clean up resources."""
        if not self._initialized:
            return
        
        try:
            # End all active traces
            with self._traces_lock:
                active_traces = list(self._active_traces.values())
                logger.debug(f"Shutting down tracer with {len(active_traces)} active traces")
            
            for trace_context in active_traces:
                try:
                    self._end_single_trace(trace_context, StatusCode.OK)
                except Exception as e:
                    logger.error(f"Error ending trace during shutdown: {e}")
            
            # Force flush all processors
            if self.provider:
                self.provider.force_flush()
                self.provider.shutdown()
            
            logger.debug("Tracing core shutdown complete")
            
        except Exception as e:
            logger.error(f"Error during tracing core shutdown: {e}")
        
        finally:
            self._initialized = False
    
    def set_custom_attributes(self, attributes: Dict[str, Any]) -> None:
        """Set custom attributes to be added to all future spans."""
        self._custom_attributes.update(attributes)
        logger.debug(f"Custom attributes updated: {list(attributes.keys())}")
        
        # Extract agent_id if it's in the custom attributes
        if 'agent_id' in attributes:
            self._agent_id = attributes['agent_id']
    
    def get_custom_attributes(self) -> Dict[str, Any]:
        """Get current custom attributes."""
        return self._custom_attributes.copy()
    
    def clear_custom_attributes(self) -> None:
        """Clear all custom attributes."""
        self._custom_attributes.clear()
        logger.debug("Custom attributes cleared")
    
    def get_custom_attribute(self, key: str) -> Any:
        """Get a specific custom attribute."""
        return self._custom_attributes.get(key)


# Global tracer instance
tracer = TracingCore()
