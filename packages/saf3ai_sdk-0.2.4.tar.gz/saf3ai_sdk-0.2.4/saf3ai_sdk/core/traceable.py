"""
Traceable decorator for custom agents without built-in telemetry.

This module provides a @traceable decorator similar to LangSmith's traceable decorator,
which automatically creates OpenTelemetry spans for agent conversations, LLM calls,
and tool invocations.

The decorator automatically:
- Creates conversation context
- Tracks user input and responses
- Automatically captures LLM calls (OpenAI, Anthropic, etc.) as child spans
- Tracks tool/function calls as child spans
- Manages conversation IDs

Usage:
    ```python
    from saf3ai_sdk import init, traceable
    import openai
    
    # Initialize SDK
    init(service_name="my-agent", ...)  # Framework auto-detected
    
    @traceable(name="my_agent")
    def my_agent(user_input: str):
        # LLM calls are automatically traced (if SDK instrumentation is enabled)
        client = openai.OpenAI()
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": user_input}]
        )
        return response.choices[0].message.content
    
    # Or with conversation_id:
    @traceable(name="my_agent", conversation_id="user-123-session-456")
    def my_agent(user_input: str):
        ...
    ```
"""

import functools
import inspect
import threading
import uuid
import time
import sys
import os
import traceback
import json
from typing import Any, Callable, Dict, Optional, Union, List
from opentelemetry import trace, context as context_api
from opentelemetry.trace import Status, StatusCode

from saf3ai_sdk.core.tracer import tracer
from saf3ai_sdk.logging import logger
from saf3ai_sdk.core.constants import AttributeNames

# Thread-local storage for traceable context
_traceable_context = threading.local()

# Global security callback storage (for automatic integration)
_global_security_callback = None
_global_response_callback = None

# Global scanner configuration (for automatic scanning in @traceable)
_scanner_endpoint = None
_scanner_api_key = None
_scanner_enabled = False

# Use unified conversation ID helpers from core.tracer
from saf3ai_sdk.core.tracer import get_conversation_id_unified as _get_conversation_id, set_conversation_id_unified as _set_conversation_id


def _set_usage_attributes_from_dict(span, usage: Dict[str, Any]) -> None:
    """Normalize common token usage keys and set span attributes."""
    if not span or not span.is_recording() or not isinstance(usage, dict):
        return

    input_tokens = (
        usage.get("prompt_tokens")
        or usage.get("input_tokens")
        or usage.get("prompt_token_count")
        or usage.get("input_token_count")
    )
    output_tokens = (
        usage.get("completion_tokens")
        or usage.get("output_tokens")
        or usage.get("candidates_token_count")
        or usage.get("output_token_count")
    )
    total_tokens = usage.get("total_tokens") or usage.get("total_token_count")

    if total_tokens is None and input_tokens is not None and output_tokens is not None:
        try:
            total_tokens = int(input_tokens) + int(output_tokens)
        except Exception:
            total_tokens = None

    if input_tokens is not None:
        span.set_attribute(AttributeNames.GEN_AI_USAGE_INPUT_TOKENS, input_tokens)
    if output_tokens is not None:
        span.set_attribute(AttributeNames.GEN_AI_USAGE_OUTPUT_TOKENS, output_tokens)
    if total_tokens is not None:
        span.set_attribute(AttributeNames.GEN_AI_USAGE_TOTAL_TOKENS, total_tokens)


def _extract_and_set_usage_from_result(span, result: Any) -> None:
    """
    Extract token usage from common custom-agent return shapes.

    Supports:
    - dict with usage/token_usage/usage_metadata
    - objects with usage or usage_metadata attrs
    - OpenAI-style response.usage (prompt/completion/total tokens)
    """
    if not span or not span.is_recording() or result is None:
        return

    usage_candidate = None

    if isinstance(result, dict):
        usage_candidate = result.get("usage") or result.get("token_usage") or result.get("usage_metadata")
        if usage_candidate is None:
            nested = result.get("response") or result.get("result") or result.get("llm_response")
            if isinstance(nested, dict):
                usage_candidate = nested.get("usage") or nested.get("token_usage") or nested.get("usage_metadata")
            elif nested is not None:
                usage_candidate = (
                    getattr(nested, "usage", None)
                    or getattr(nested, "token_usage", None)
                    or getattr(nested, "usage_metadata", None)
                )
    else:
        usage_candidate = (
            getattr(result, "usage", None)
            or getattr(result, "token_usage", None)
            or getattr(result, "usage_metadata", None)
        )

    if isinstance(usage_candidate, dict):
        _set_usage_attributes_from_dict(span, usage_candidate)
        return

    if usage_candidate is not None:
        usage_dict: Dict[str, Any] = {}
        for source_key, target_key in (
            ("prompt_tokens", "prompt_tokens"),
            ("completion_tokens", "completion_tokens"),
            ("total_tokens", "total_tokens"),
            ("input_tokens", "input_tokens"),
            ("output_tokens", "output_tokens"),
            ("prompt_token_count", "prompt_token_count"),
            ("candidates_token_count", "candidates_token_count"),
            ("total_token_count", "total_token_count"),
        ):
            value = getattr(usage_candidate, source_key, None)
            if value is not None:
                usage_dict[target_key] = value
        if usage_dict:
            _set_usage_attributes_from_dict(span, usage_dict)


def _extract_text_from_result(result: Any) -> Optional[str]:
    """Extract response text from common custom-agent return shapes."""
    if result is None:
        return None

    if isinstance(result, str):
        return result

    if isinstance(result, dict):
        for key in ("response", "output", "text", "content", "answer", "result"):
            value = result.get(key)
            if isinstance(value, str) and value.strip():
                return value
            if isinstance(value, dict):
                nested = _extract_text_from_result(value)
                if nested:
                    return nested

    for attr in ("text", "content", "response", "output", "answer"):
        value = getattr(result, attr, None)
        if isinstance(value, str) and value.strip():
            return value

    # OpenAI-style object response
    try:
        choices = getattr(result, "choices", None)
        if choices:
            first = choices[0]
            message = getattr(first, "message", None)
            content = getattr(message, "content", None) if message else None
            if isinstance(content, str) and content.strip():
                return content
    except Exception:
        pass

    return None


def _extract_model_from_result(result: Any) -> Optional[str]:
    """Extract model name from common response shapes."""
    if result is None:
        return None
    if isinstance(result, dict):
        for key in ("model", "model_name", "llm_model"):
            value = result.get(key)
            if value:
                return str(value)
        nested = result.get("response") or result.get("result") or result.get("llm_response")
        if nested is not None:
            return _extract_model_from_result(nested)
    for attr in ("model", "model_name"):
        value = getattr(result, attr, None)
        if value:
            return str(value)
    return None


def _extract_threats_and_categories(scan_result: Dict[str, Any]) -> tuple[list, list]:
    """Extract threat/category names from scanner response variants."""
    threats_found: List[str] = []
    categories_found: List[str] = []

    if not isinstance(scan_result, dict):
        return threats_found, categories_found

    detection_results = scan_result.get("detection_results", {})
    if isinstance(detection_results, dict):
        threats_found.extend([k for k, v in detection_results.items() if isinstance(v, dict) and v.get("result") == "MATCH_FOUND"])

    threats = scan_result.get("threats", {})
    if isinstance(threats, dict):
        items = threats.get("items", [])
        if isinstance(items, list):
            for item in items:
                threat_type = item.get("type") if isinstance(item, dict) else None
                if threat_type:
                    threats_found.append(str(threat_type))

    out_of_scope = scan_result.get("OutofScopeAnalysis", {})
    if isinstance(out_of_scope, dict):
        detected_categories = out_of_scope.get("detected_categories", [])
        if isinstance(detected_categories, list):
            for item in detected_categories[:5]:
                if isinstance(item, dict):
                    category = item.get("category")
                    if category:
                        categories_found.append(str(category))

    categories = scan_result.get("categories", {})
    if isinstance(categories, dict):
        items = categories.get("items", [])
        if isinstance(items, list):
            for item in items[:5]:
                name = item.get("name") if isinstance(item, dict) else None
                if name:
                    categories_found.append(str(name))

    return list(dict.fromkeys(threats_found)), list(dict.fromkeys(categories_found))


def _add_callback_scan_results_to_span(span, scan_result: Dict[str, Any], scan_type: str) -> None:
    """Apply framework-consistent security attributes for callback-based scanning."""
    if not span or not span.is_recording() or not isinstance(scan_result, dict):
        return

    threats_found, categories_found = _extract_threats_and_categories(scan_result)
    has_threats = len(threats_found) > 0

    span.set_attribute("security.scan.enabled", True)
    span.set_attribute("security.scan.status", "completed")
    span.set_attribute("security.threats_found", has_threats)
    span.set_attribute("security.threat_count", len(threats_found))
    span.set_attribute("security.scan.threat_count", len(threats_found))
    span.set_attribute("security.scan.has_threats", has_threats)
    span.set_attribute("security.scan.passed", not has_threats)

    if threats_found:
        threat_csv = ",".join(threats_found)
        span.set_attribute("security.threat_types", threat_csv)
        span.set_attribute("security.scan.threat_types", threat_csv)
        if scan_type == "response":
            span.set_attribute("security.response_threat_count", len(threats_found))
            span.set_attribute("security.response_threat_types", threat_csv)

    if categories_found:
        span.set_attribute("security.categories", ",".join(categories_found))
        span.set_attribute("security.category_count", len(categories_found))

    try:
        scan_json = json.dumps(scan_result)
        if len(scan_json) <= 4000:
            if scan_type == "response":
                span.set_attribute("security.response_scan.full_results", scan_json)
            else:
                span.set_attribute("security.scan.full_results", scan_json)
    except Exception:
        pass


def _invoke_security_callback_for_traceable(text: str, scan_type: str, span) -> bool:
    """Invoke global callbacks (set via create_framework_security_callbacks) inside @traceable."""
    if not text or not text.strip():
        return True

    prompt_callback, response_callback = _get_global_security_callbacks()
    callback = prompt_callback if scan_type == "prompt" else response_callback
    if not callback:
        return True

    try:
        callback_result = callback(text)
    except TypeError:
        # Support callbacks that expect (text, scan_results, text_type)-style signatures.
        callback_result = callback(text, {}, scan_type)
    except Exception as e:
        logger.error(f"Security {scan_type} callback failed in @traceable: {e}")
        if span and span.is_recording():
            span.set_attribute("security.scan.status", "error")
            span.set_attribute("security.scan.error", str(e))
        return True  # fail-open for callback execution failures

    should_allow = True
    scan_result = None

    if isinstance(callback_result, tuple) and len(callback_result) == 2:
        scan_result, should_allow = callback_result
    elif isinstance(callback_result, dict):
        scan_result = callback_result
    elif isinstance(callback_result, bool):
        should_allow = callback_result

    if isinstance(scan_result, dict):
        _add_callback_scan_results_to_span(span, scan_result, scan_type)

    if span and span.is_recording():
        span.set_attribute(
            "security.user_decision",
            "allow" if should_allow else "block"
        )
        if not should_allow:
            span.set_attribute("security.blocked_by", "user_callback")

    return bool(should_allow)


def set_global_security_callbacks(prompt_callback=None, response_callback=None):
    """
    Set global security callbacks that will be automatically used by @traceable.
    
    This allows automatic security scanning without explicitly passing callbacks.
    """
    global _global_security_callback, _global_response_callback
    _global_security_callback = prompt_callback
    _global_response_callback = response_callback
    logger.debug("Global security callbacks set")


def _get_global_security_callbacks():
    """Get global security callbacks if available."""
    return _global_security_callback, _global_response_callback


def set_scanner_config(scanner_endpoint: Optional[str] = None, scanner_api_key: Optional[str] = None):
    """
    Set global scanner configuration for automatic security scanning in @traceable.
    
    When configured, @traceable will automatically scan user inputs and function results
    using scan_prompt/scan_response and add scan results to span attributes.
    
    Args:
        scanner_endpoint: URL of the scanner API endpoint
        scanner_api_key: API key for scanner requests (same organization key as the collector unless overridden)
    """
    global _scanner_endpoint, _scanner_api_key, _scanner_enabled
    _scanner_endpoint = scanner_endpoint
    _scanner_api_key = scanner_api_key
    _scanner_enabled = bool(scanner_endpoint)
    if _scanner_enabled:
        logger.debug(f"Scanner configured: {scanner_endpoint}")


def _get_scanner_config():
    """Get global scanner configuration."""
    return _scanner_endpoint, _scanner_api_key, _scanner_enabled


def _execute_scan(text: str, scan_type: str, scanner_endpoint: str, scanner_api_key: Optional[str],
                 model_name: str, conversation_id: Optional[str]) -> Optional[Dict[str, Any]]:
    """Execute the actual scan based on scan type."""
    from saf3ai_sdk.scanner import scan_prompt, scan_response
    
    scan_params = {
        "api_endpoint": scanner_endpoint,
        "model_name": model_name,
        "conversation_id": conversation_id,
        "api_key": scanner_api_key,
        "timeout": 10
    }
    
    if scan_type == "prompt":
        return scan_prompt(prompt=text, **scan_params)
    elif scan_type == "response":
        return scan_response(response=text, **scan_params)
    return None


def _add_scan_results_to_span(scan_result: Dict[str, Any], scan_type: str, span) -> None:
    """Add scan results to span attributes."""
    if not (scan_result and span and span.is_recording()):
        return
    
    threats = scan_result.get("threats", {}) if isinstance(scan_result.get("threats", {}), dict) else {}
    threat_count = threats.get("total_count", 0)
    detection_results = scan_result.get("detection_results", {})
    detection_threats = []
    if isinstance(detection_results, dict):
        detection_threats = [k for k, v in detection_results.items() if isinstance(v, dict) and v.get("result") == "MATCH_FOUND"]
    if (not threat_count) and detection_threats:
        threat_count = len(detection_threats)
    
    span.set_attribute("security.scan.passed", threat_count == 0)
    span.set_attribute("security.scan.threat_count", threat_count)
    span.set_attribute("security.scan.has_threats", threat_count > 0)
    span.set_attribute("security.threat_count", threat_count)
    span.set_attribute("security.threats_found", threat_count > 0)
    span.set_attribute(f"security.scan.{scan_type}.scanned", True)
    
    if threat_count > 0:
        threat_types = detection_threats
        if not threat_types:
            threat_items = threats.get("items", []) if isinstance(threats.get("items", []), list) else []
            threat_types = [t.get("type") for t in threat_items if isinstance(t, dict) and t.get("type")]
        if threat_types:
            span.set_attribute("security.scan.threat_types", ",".join(threat_types))
            span.set_attribute("security.threat_types", ",".join(threat_types))
            span.set_attribute("security.scan.max_severity", threats.get("max_severity", "unknown"))
        span.set_attribute("security.conversation.threat_detected", True)
        span.set_attribute("security.conversation.threat_count", threat_count)
        span.set_attribute("security.conversation.severity", threats.get("max_severity", "critical"))
        logger.warning(f"Security threat detected in {scan_type}: {threat_types}")


def _perform_automatic_scan(text: str, scan_type: str, conversation_id: Optional[str], 
                            model_name: str = "unknown", span=None) -> Optional[Dict[str, Any]]:
    """
    Perform automatic security scanning if scanner is configured.
    
    Args:
        text: Text to scan
        scan_type: "prompt" or "response"
        conversation_id: Conversation ID for tracking
        model_name: Model name
        span: OpenTelemetry span to add scan results to
        
    Returns:
        Scan result dict or None
    """
    scanner_endpoint, scanner_api_key, scanner_enabled = _get_scanner_config()
    
    if not scanner_enabled or not text or not text.strip():
        return None
    
    try:
        scan_result = _execute_scan(text, scan_type, scanner_endpoint, scanner_api_key, 
                                   model_name, conversation_id)
        if scan_result:
            _add_scan_results_to_span(scan_result, scan_type, span)
        return scan_result
        
    except Exception as e:
        logger.error(f"Automatic security scan failed for {scan_type}: {e}")
        if span and span.is_recording():
            span.set_attribute("security.scan.error", str(e))
        return None


def _extract_function_metadata(func: Callable) -> Dict[str, Any]:
    """Extract comprehensive metadata about a function."""
    metadata = {
        "function.name": func.__name__,
        "function.qualname": getattr(func, '__qualname__', func.__name__),
        "function.module": func.__module__ or "unknown",
    }
    
    try:
        # Get source file and line number
        source_file = inspect.getfile(func)
        metadata["function.source_file"] = source_file
        metadata["function.source_file_name"] = os.path.basename(source_file)
        
        # Get line numbers
        try:
            lines, start_line = inspect.getsourcelines(func)
            metadata["function.source_line_start"] = start_line
            metadata["function.source_line_end"] = start_line + len(lines) - 1
        except Exception:
            pass
    except Exception:
        pass
    
    # Get function signature
    try:
        sig = inspect.signature(func)
        metadata["function.signature"] = str(sig)
        metadata["function.parameter_count"] = len(sig.parameters)
        metadata["function.parameters"] = list(sig.parameters.keys())
    except Exception:
        pass
    
    # Get docstring
    try:
        doc = inspect.getdoc(func)
        if doc:
            metadata["function.docstring"] = doc[:500]  # First 500 chars
    except Exception:
        pass
    
    return metadata


def _extract_documents_from_result(result: Any) -> List[Dict[str, Any]]:
    """
    Automatically extract document access information from function results.
    
    Detects common patterns:
    - List of dicts with 'metadata' containing 'source'
    - Dict with 'sources' key
    - Dict with 'search_results' or 'results' containing document metadata
    
    Args:
        result: Function result to analyze
    
    Returns:
        List of document info dicts with 'source', 'file_name', 'file_path'
    """
    documents = []
    
    if not result:
        return documents
    
    try:
        # Pattern 1: List of dicts with metadata.source (common in vector store search results)
        if isinstance(result, list):
            for item in result:
                if isinstance(item, dict):
                    # Check for metadata.source pattern
                    if 'metadata' in item and isinstance(item['metadata'], dict):
                        metadata = item['metadata']
                        if 'source' in metadata:
                            doc_info = {
                                'source': metadata.get('source', ''),
                                'file_name': metadata.get('source', ''),
                                'file_path': metadata.get('file_path', metadata.get('source', '')),
                            }
                            # Add all metadata
                            doc_info['metadata'] = metadata
                            documents.append(doc_info)
                    
                    # Check for direct source field
                    elif 'source' in item:
                        doc_info = {
                            'source': item.get('source', ''),
                            'file_name': item.get('source', ''),
                            'file_path': item.get('file_path', item.get('source', '')),
                        }
                        documents.append(doc_info)
        
        # Pattern 2: Dict with 'sources' key
        elif isinstance(result, dict):
            if 'sources' in result and isinstance(result['sources'], list):
                for source in result['sources']:
                    if isinstance(source, str):
                        documents.append({
                            'source': source,
                            'file_name': source,
                            'file_path': source
                        })
            
            # Pattern 3: Dict with 'search_results' or 'results'
            for key in ['search_results', 'results', 'documents', 'context_used']:
                if key in result and isinstance(result[key], list):
                    for item in result[key]:
                        if isinstance(item, dict) and 'metadata' in item:
                            metadata = item['metadata']
                            if 'source' in metadata:
                                doc_info = {
                                    'source': metadata.get('source', ''),
                                    'file_name': metadata.get('source', ''),
                                    'file_path': metadata.get('file_path', metadata.get('source', '')),
                                }
                                doc_info['metadata'] = metadata
                                documents.append(doc_info)
                        elif isinstance(item, str):
                            documents.append({
                                'source': item,
                                'file_name': item,
                                'file_path': item
                            })
            
            # Pattern 4: Direct metadata in result dict
            if 'metadata' in result and isinstance(result['metadata'], dict):
                metadata = result['metadata']
                if 'source' in metadata:
                    documents.append({
                        'source': metadata.get('source', ''),
                        'file_name': metadata.get('source', ''),
                        'file_path': metadata.get('file_path', metadata.get('source', '')),
                        'metadata': metadata
                    })
    
    except Exception as e:
        logger.debug(f"Could not extract documents from result: {e}")
    
    return documents


def _track_document_access_automatic(
    result: Any,
    span,
    query: Optional[str] = None,
    conversation_id: Optional[str] = None
):
    """
    Automatically track document access from function results.
    
    This function detects document access patterns in function results and
    automatically adds document tracking attributes to the span using OpenInference conventions.
    
    Args:
        result: Function result to analyze
        span: OpenTelemetry span to add attributes to
        query: Query that triggered document access (optional)
        conversation_id: Conversation ID (optional)
    """
    if not span or not span.is_recording():
        return
    
    try:
        documents = _extract_documents_from_result(result)
        
        if not documents:
            return
        
        # Convert to Document-like objects for metadata extraction
        from saf3ai_sdk.core.metadata_extraction import log_retrieved_documents
        
        # Convert extracted documents to format expected by log_retrieved_documents
        doc_objects = []
        for doc in documents:
            # Create a dict-like object with metadata
            doc_obj = {}
            if 'metadata' in doc and isinstance(doc['metadata'], dict):
                # Use existing metadata, but ensure proper field mapping
                metadata = doc['metadata'].copy()
                # Ensure file_path is set if we have source but no explicit file_path
                if 'source' in metadata and 'file_path' not in metadata:
                    metadata['file_path'] = metadata['source']
                doc_obj['metadata'] = metadata
            else:
                # Create metadata dict from doc fields
                source = doc.get('source', '')
                file_path = doc.get('file_path', source)  # Use source as fallback
                doc_obj['metadata'] = {
                    'source': source,
                    'file_name': doc.get('file_name', ''),
                    'file_path': file_path,
                    'original_source': source,  # Preserve original source
                }
            # Add page_content if available
            if 'content' in doc:
                doc_obj['page_content'] = doc['content']
            elif 'text' in doc:
                doc_obj['page_content'] = doc['text']
            
            doc_objects.append(doc_obj)
        
        # Use the standardized OpenInference format
        log_retrieved_documents(doc_objects, span=span, query=query)
        
        logger.debug(f"Automatically tracked {len(documents)} document(s) in span '{span.name}' using OpenInference format")
    
    except Exception as e:
        logger.debug(f"Could not automatically track document access: {e}")


def _detect_tool_call(func: Callable) -> bool:
    """
    Detect if a function call might be a tool.
    
    Heuristics:
    - Function name contains 'tool', 'search', 'api', 'call', 'execute'
    - Function has docstring mentioning 'tool'
    - Function is not a builtin or standard library function
    """
    func_name = func.__name__.lower()
    tool_indicators = ['tool', 'search', 'api', 'call', 'execute', 'fetch', 'get', 'post', 'request']
    
    # Check name
    if any(indicator in func_name for indicator in tool_indicators):
        return True
    
    # Check docstring
    try:
        doc = inspect.getdoc(func) or ""
        if 'tool' in doc.lower() or 'function' in doc.lower():
            return True
    except Exception:
        pass
    
    # Check if it's a builtin (probably not a tool)
    if func.__module__ in ['builtins', '__builtin__']:
        return False
    
    return False


def _trace_tool_call(tool_func: Callable, args: tuple, kwargs: dict, result: Any, 
                     _parent_span, conversation_id: Optional[str] = None):
    """Create a span for a tool call."""
    otel_tracer = tracer.get_tracer("saf3ai-custom")
    tool_name = tool_func.__name__
    
    # CRITICAL: Get conversation_id using unified helper FIRST - prevents creating new IDs
    # Priority: 1) Provided conversation_id, 2) Existing from unified helper, 3) None
    if not conversation_id:
        conversation_id = _get_conversation_id()
        if conversation_id:
            logger.debug(f"[Tool Call] Found existing conversation_id: {conversation_id}")
    
    # CRITICAL: Store conversation_id in unified store so child spans (LLM calls, sub-agents) inherit it
    if conversation_id:
        _set_conversation_id(conversation_id, source="tool_call", force=False)
    
    with otel_tracer.start_as_current_span(f"tool.{tool_name}") as tool_span:
        # Tool metadata
        tool_span.set_attribute("tool.name", tool_name)
        tool_span.set_attribute("tool.type", "function_call")
        tool_span.set_attribute("tool.module", tool_func.__module__ or "unknown")
        
        # AUTOMATIC SEARCH QUERY DETECTION: If function name contains "search", try to extract query
        if 'search' in tool_name.lower():
            try:
                # Try to extract query from args/kwargs
                query = None
                if args and len(args) > 0:
                    query = str(args[0]) if args[0] else None
                elif 'query' in kwargs:
                    query = str(kwargs['query'])
                elif 'q' in kwargs:
                    query = str(kwargs['q'])
                elif 'keywords' in kwargs:
                    query = str(kwargs['keywords'])
                
                # File tracking removed
            except Exception as e:
                logger.debug(f"Could not auto-detect search query: {e}")
        
        # Add function metadata
        func_metadata = _extract_function_metadata(tool_func)
        for key, value in func_metadata.items():
            tool_span.set_attribute(f"tool.{key}", value)
        
        # CRITICAL: Ensure conversation_id on tool span using unified helper
        # This ensures tool spans have conversation_id and child spans inherit it
        from saf3ai_sdk.core.tracer import ensure_conversation_id_on_span
        conversation_id = ensure_conversation_id_on_span(tool_span, conversation_id)
        
        # Add tool arguments (truncated)
        if args:
            args_str = str(args)[:500]  # Limit length
            tool_span.set_attribute("tool.args", args_str)
            tool_span.set_attribute("tool.arg_count", len(args))
        
        if kwargs:
            kwargs_str = str(kwargs)[:500]  # Limit length
            tool_span.set_attribute("tool.kwargs", kwargs_str)
            tool_span.set_attribute("tool.kwarg_count", len(kwargs))
        
        # Add result metadata (not the actual result)
        if result is not None:
            tool_span.set_attribute("tool.result_type", type(result).__name__)
            if hasattr(result, '__len__') and not isinstance(result, str):
                tool_span.set_attribute("tool.result_length", len(result))
        
        tool_span.set_status(Status(StatusCode.OK))
        return result


def traceable(
    func_or_name: Optional[Union[str, Callable]] = None,
    name: Optional[str] = None,
    conversation_id: Optional[str] = None,
    auto_generate_conversation_id: bool = True,
    tags: Optional[Dict[str, Any]] = None,
    **kwargs
):
    """
    Decorator to automatically trace custom agent functions with full telemetry.
    
    Similar to LangSmith's @traceable - just place it above your function and it automatically:
    - Creates conversation context and manages conversation IDs
    - Tracks user input and agent responses
    - Automatically captures LLM calls (OpenAI, Anthropic, etc.) as child spans
    - Tracks function calls that might be tools
    - Creates spans for telemetry (sent to Saf3AI Collector)
    
    The decorator works with existing SDK instrumentation - LLM calls are automatically
    traced as child spans when they occur within a traceable function.
    
    Args:
        func_or_name: Function to decorate or span name
        name: Name for the span (if func_or_name is a function)
        conversation_id: Optional conversation ID. If not provided, will:
                       1. Use existing conversation_id from context
                       2. Auto-generate if auto_generate_conversation_id=True
        auto_generate_conversation_id: If True, auto-generates conversation_id if not found
        tags: Additional tags/attributes to add to the span
        **kwargs: Additional span attributes
    
    Returns:
        Decorated function with automatic telemetry
    
    Example:
        ```python
        import openai
        
        @traceable(name="my_agent")
        def my_agent(user_input: str):
            # LLM calls are automatically traced as child spans
            client = openai.OpenAI()
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[{"role": "user", "content": user_input}]
            )
            return response.choices[0].message.content
        
        # With conversation_id:
        @traceable(name="my_agent", conversation_id="user-123")
        def my_agent(user_input: str):
            ...
        
        # With tags:
        @traceable(name="my_agent", tags={"user_id": "123", "session": "abc"})
        def my_agent(user_input: str):
            ...
        ```
    """
    def actual_decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **func_kwargs):
            if not tracer.initialized:
                logger.warning("Tracer not initialized, executing function without instrumentation")
                return func(*args, **func_kwargs)
            
            # Determine span name
            span_name = name or func.__name__
            
            # CRITICAL: Get conversation ID using unified helper FIRST - single source of truth
            # Priority: 1) Explicit conversation_id parameter, 2) Existing from unified helper, 3) From kwargs, 4) Auto-generate
            conv_id = conversation_id
            
            # CRITICAL: Check existing conversation_id FIRST to prevent duplicates
            if not conv_id:
                conv_id = _get_conversation_id()
                if conv_id:
                    logger.debug(f"@traceable (sync) Found existing conversation_id: {conv_id}")
            
            # Only check kwargs if no existing conversation_id
            if not conv_id:
                # Try to get from function kwargs (for dynamic conversation_id support)
                if 'conversation_id' in func_kwargs:
                    conv_id = func_kwargs.get('conversation_id')
                elif 'session_id' in func_kwargs:
                    conv_id = func_kwargs.get('session_id')
            
            # Only auto-generate if no conversation_id exists anywhere
            if not conv_id and auto_generate_conversation_id:
                conv_id = str(uuid.uuid4())
                logger.debug(f"@traceable (sync) Auto-generated conversation_id: {conv_id}")
            
            # CRITICAL: Set conversation ID if we have one - use force=False to prevent overwriting
            if conv_id:
                _set_conversation_id(conv_id, source="traceable_decorator", force=False)
                logger.debug(f"@traceable (sync) using conversation_id: {conv_id}")
            
            # Build attributes with rich metadata for data lineage
            start_time = time.time()
            
            # Extract comprehensive function metadata
            func_metadata = _extract_function_metadata(func)
            
            attributes = {
                "span.kind": "agent",
                "gen_ai.agent.name": span_name,
                "gen_ai.request.start_time": start_time,
                "gen_ai.request.timestamp": int(start_time * 1000),  # milliseconds
            }
            
            # Add all function metadata
            attributes.update(func_metadata)
            
            # Add source information
            try:
                frame = inspect.currentframe()
                if frame and frame.f_back:
                    caller_frame = frame.f_back
                    attributes["caller.file"] = caller_frame.f_code.co_filename
                    attributes["caller.function"] = caller_frame.f_code.co_name
                    attributes["caller.line"] = caller_frame.f_lineno
            except Exception:
                pass
            
            if conv_id:
                attributes[AttributeNames.GEN_AI_CONVERSATION_ID] = conv_id
            
            # Add trace ID for data lineage (single standard: trace.id)
            try:
                trace_id = format(trace.get_current_span().get_span_context().trace_id, '032x')
                attributes["trace.id"] = trace_id
            except Exception:
                pass
            
            if tags:
                attributes.update(tags)
            
            attributes.update(kwargs)
            
            # Add custom attributes (single name per value - no gen_ai.* duplicate)
            custom_attrs = tracer.get_custom_attributes()
            for key, value in custom_attrs.items():
                if key in (AttributeNames.GEN_AI_CONVERSATION_ID, AttributeNames.CONVERSATION_ID) and conv_id:
                    continue
                if key.startswith(('client.', 'http.', 'browser_id', 'ip_address', 'user_agent')):
                    continue
                attributes[key] = value
            
            # Extract and add comprehensive client data (IP, user agent, browser ID, device info, etc.)
            # This checks Flask/FastAPI context, custom attributes, and environment variables
            try:
                from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                client_data = extract_comprehensive_client_data()
                
                # Use the helper function to set client data on the span (standard OTEL format)
                # This ensures all client data attributes are properly set without duplicates
                # Client data is set directly on span, not in attributes dict to avoid duplication
                if span and span.is_recording():
                    _add_client_data_to_span(span, client_data)
            except Exception as e:
                logger.debug(f"Could not extract client data in traceable: {e}")
            
            # Extract user input from args/kwargs for telemetry
            user_input = None
            if args:
                # Try to find string input in args
                for arg in args:
                    if isinstance(arg, str) and len(arg) > 0:
                        user_input = arg
                        break
                    elif hasattr(arg, '__dict__'):
                        # Try common attributes
                        for attr_name in ['input', 'query', 'message', 'prompt', 'text']:
                            if hasattr(arg, attr_name):
                                attr_value = getattr(arg, attr_name)
                                if isinstance(attr_value, str) and len(attr_value) > 0:
                                    user_input = attr_value
                                    break
                        if user_input:
                            break
            
            if not user_input:
                # Try kwargs
                for key in ['input', 'query', 'message', 'prompt', 'text', 'user_input']:
                    if key in func_kwargs:
                        value = func_kwargs[key]
                        if isinstance(value, str) and len(value) > 0:
                            user_input = value
                            break
            
            if user_input:
                attributes["llm.prompt"] = user_input
                attributes[AttributeNames.LLM_PROMPT_LENGTH] = len(user_input)
            
            # AUTOMATIC CLIENT DATA CAPTURE: Extract client data right before creating span
            # This ensures we capture IP, user agent, browser ID automatically on every span
            # Works for Flask, FastAPI, and any web context - no manual setup needed
            try:
                import os
                client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
                if client_data_capture_enabled:
                    from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                    # Extract client data automatically (tries Flask, FastAPI, custom attributes, env vars)
                    client_data = extract_comprehensive_client_data()
                    # Add to attributes dict so it's included when span is created
                    if client_data.get('user_agent'):
                        attributes["http.user_agent"] = client_data['user_agent']
                    if client_data.get('ip_address'):
                        attributes["client.ip"] = client_data['ip_address']
                    if client_data.get('browser_id'):
                        attributes["client.id"] = client_data['browser_id']
                    for key in ['browser_name', 'browser_version', 'device_type', 'os_name', 'os_version', 'platform']:
                        if client_data.get(key):
                            attributes[f"client.{key}"] = client_data[key]
            except Exception as e:
                logger.debug(f"Automatic client data capture failed in traceable: {e}")
            
            # Create span and set as current context
            # This ensures LLM calls (via existing instrumentation) become child spans
            otel_tracer = tracer.get_tracer("saf3ai-custom")
            span, context_token = tracer._create_span(
                operation_name=span_name,
                span_kind="agent",
                attributes=attributes
            )
            
            # Set client data on span after creation (in case extraction happened after attributes were set)
            try:
                import os
                client_data_capture_enabled = os.getenv("SAF3AI_CLIENT_DATA_CAPTURE", "true").lower() == "true"
                if client_data_capture_enabled and span and span.is_recording():
                    from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                    client_data = extract_comprehensive_client_data()
                    if client_data.get('ip_address') or client_data.get('user_agent'):
                        _add_client_data_to_span(span, client_data)
            except Exception as e:
                logger.debug(f"Could not add client data to span after creation: {e}")
            
            # Set span as current context so LLM/tool calls become children
            ctx = trace.set_span_in_context(span)
            trace_token = context_api.attach(ctx)
            
            # CRITICAL: Log span creation for debugging OpenSearch export issues
            logger.debug(f"@traceable created span '{span_name}' with conversation_id='{conv_id}', "
                        f"span_id={span.get_span_context().span_id:x}, "
                        f"trace_id={span.get_span_context().trace_id:x}")
            
            # Store traceable context for potential tool detection
            _traceable_context.span = span
            _traceable_context.conversation_id = conv_id
            
            # Perform automatic security scanning on user input if scanner is configured
            scan_result = None
            if user_input:
                # Detect model name from attributes or use default
                model_name = attributes.get(AttributeNames.LLM_MODEL, attributes.get(AttributeNames.GEN_AI_MODEL_NAME, "unknown"))
                scan_result = _perform_automatic_scan(user_input, "prompt", conv_id, model_name, span)
                # Store scan result in context for retrieval if needed
                _traceable_context.scan_result = scan_result
            
            # Log all captured data for debugging
            logger.info("=" * 80)
            logger.info(f"📊 @traceable CAPTURED DATA for '{span_name}'")
            logger.info("=" * 80)
            logger.info(f"  Function: {func.__name__}")
            logger.info(f"  Module: {func.__module__}")
            logger.info(f"  Conversation ID: {conv_id}")
            logger.info(f"  User Input: {user_input[:100] if user_input else 'None'}...")
            logger.info(f"  Attributes Count: {len(attributes)}")
            logger.info("  All Attributes:")
            for key, value in sorted(attributes.items()):
                value_str = str(value)
                if len(value_str) > 100:
                    value_str = value_str[:100] + "..."
                logger.info(f"    - {key}: {value_str}")
            logger.info("=" * 80)
            
            try:
                # Execute function
                # Any LLM calls (OpenAI, Anthropic, etc.) will automatically be traced
                # as child spans by existing SDK instrumentation
                result = func(*args, **func_kwargs)
                _extract_and_set_usage_from_result(span, result)
                
                # Perform automatic security scanning on result if it's a string and scanner is configured
                if result and isinstance(result, str) and result.strip():
                    model_name = attributes.get(AttributeNames.LLM_MODEL, attributes.get(AttributeNames.GEN_AI_MODEL_NAME, "unknown"))
                    _perform_automatic_scan(result, "response", conv_id, model_name, span)
                elif result is not None:
                    response_text = _extract_text_from_result(result)
                    if response_text:
                        model_name = attributes.get(AttributeNames.LLM_MODEL, attributes.get(AttributeNames.GEN_AI_MODEL_NAME, "unknown"))
                        _perform_automatic_scan(response_text, "response", conv_id, model_name, span)

                # Invoke framework-style callback pipeline in custom @traceable flow
                if user_input:
                    allowed = _invoke_security_callback_for_traceable(user_input, "prompt", span)
                    if not allowed:
                        raise ValueError("Security policy blocked prompt in @traceable callback")

                response_text = _extract_text_from_result(result)
                if response_text:
                    allowed = _invoke_security_callback_for_traceable(response_text, "response", span)
                    if not allowed:
                        raise ValueError("Security policy blocked response in @traceable callback")
                    span.set_attribute(AttributeNames.LLM_RESPONSE_LENGTH, len(response_text))

                detected_model = _extract_model_from_result(result)
                if detected_model:
                    span.set_attribute(AttributeNames.GEN_AI_RESPONSE_MODEL, detected_model)
                    if not attributes.get(AttributeNames.LLM_MODEL):
                        span.set_attribute(AttributeNames.LLM_MODEL, detected_model)
                
                # AUTOMATIC DOCUMENT ACCESS TRACKING: Detect and track document access from results
                # This automatically captures when agents access documents (e.g., from vector store searches)
                if result is not None:
                    # Extract query from user input or function args
                    detected_query = user_input
                    if not detected_query and args:
                        for arg in args:
                            if isinstance(arg, str) and len(arg) > 10:  # Likely a query
                                detected_query = arg
                                break
                    
                    # Track document access automatically
                    _track_document_access_automatic(
                        result=result,
                        span=span,
                        query=detected_query,
                        conversation_id=conv_id
                    )
                
                # Note: We don't record agent responses - only user inputs, LLM calls, and tool calls
                # The response is handled by LLM call spans if applicable
                
                # Add minimal result information (type only, no content)
                if result is not None:
                    span.set_attribute("function.result_type", type(result).__name__)
                    if hasattr(result, '__len__') and not isinstance(result, str):
                        span.set_attribute("function.result_length", len(result))
                
                # Add end time and duration for data lineage
                end_time = time.time()
                duration_ms = (end_time - start_time) * 1000
                span.set_attribute("gen_ai.request.end_time", end_time)
                span.set_attribute("gen_ai.request.duration_ms", duration_ms)
                span.set_attribute("gen_ai.request.duration_seconds", end_time - start_time)
                
                # Log final span data
                logger.debug(f"@traceable completed '{span_name}' in {duration_ms:.2f}ms")
                
                span.set_status(Status(StatusCode.OK))
                return result
                
            except Exception as e:
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.set_attribute("error.message", str(e))
                span.set_attribute("error.type", type(e).__name__)
                logger.error(f"Error in {span_name}: {e}")
                raise
                
            finally:
                # CRITICAL: Ensure span is properly ended and exported
                # Log before ending to track span lifecycle
                logger.debug(f"@traceable ending span '{span_name}', "
                           f"span_id={span.get_span_context().span_id:x}, "
                           f"trace_id={span.get_span_context().trace_id:x}, "
                           f"is_recording={span.is_recording()}")
                
                # Clean up context
                context_api.detach(trace_token)
                if context_token:
                    context_api.detach(context_token)
                
                # Clear traceable context
                if hasattr(_traceable_context, 'span'):
                    delattr(_traceable_context, 'span')
                if hasattr(_traceable_context, 'conversation_id'):
                    delattr(_traceable_context, 'conversation_id')
                if hasattr(_traceable_context, 'scan_result'):
                    delattr(_traceable_context, 'scan_result')
                if hasattr(_traceable_context, 'result_scan'):
                    delattr(_traceable_context, 'result_scan')
                
                # CRITICAL: End span explicitly - this triggers export via SimpleSpanProcessor
                if span.is_recording():
                    span.end()
                    logger.debug(f"@traceable span '{span_name}' ended successfully and should be exported")
                else:
                    logger.warning(f"@traceable span '{span_name}' was not recording, may not be exported")
        
        @functools.wraps(func)
        async def async_wrapper(*args, **func_kwargs):
            if not tracer.initialized:
                logger.warning("Tracer not initialized, executing function without instrumentation")
                return await func(*args, **func_kwargs)
            
            # Determine span name
            span_name = name or func.__name__
            
            # CRITICAL: Get conversation ID using unified helper FIRST - single source of truth
            # Priority: 1) Explicit conversation_id parameter, 2) Existing from unified helper, 3) From kwargs, 4) Auto-generate
            conv_id = conversation_id
            
            # CRITICAL: Check existing conversation_id FIRST to prevent duplicates
            if not conv_id:
                conv_id = _get_conversation_id()
                if conv_id:
                    logger.debug(f"@traceable (async) Found existing conversation_id: {conv_id}")
            
            # Only check kwargs if no existing conversation_id
            if not conv_id:
                # Try to get from function kwargs (for dynamic conversation_id support)
                if 'conversation_id' in func_kwargs:
                    conv_id = func_kwargs.get('conversation_id')
                elif 'session_id' in func_kwargs:
                    conv_id = func_kwargs.get('session_id')
            
            # Only auto-generate if no conversation_id exists anywhere
            if not conv_id and auto_generate_conversation_id:
                conv_id = str(uuid.uuid4())
                logger.debug(f"@traceable (async) Auto-generated conversation_id: {conv_id}")
            
            # CRITICAL: Set conversation ID if we have one - use force=False to prevent overwriting
            if conv_id:
                _set_conversation_id(conv_id, source="traceable_decorator", force=False)
                logger.debug(f"@traceable (async) using conversation_id: {conv_id}")
            
            # Build attributes with rich metadata (same as sync version)
            start_time = time.time()
            
            # Extract comprehensive function metadata
            func_metadata = _extract_function_metadata(func)
            
            attributes = {
                "span.kind": "agent",
                "gen_ai.agent.name": span_name,
                "gen_ai.request.start_time": start_time,
                "gen_ai.request.timestamp": int(start_time * 1000),  # milliseconds
            }
            
            # Add all function metadata
            attributes.update(func_metadata)
            
            # Add source information
            try:
                frame = inspect.currentframe()
                if frame and frame.f_back:
                    caller_frame = frame.f_back
                    attributes["caller.file"] = caller_frame.f_code.co_filename
                    attributes["caller.function"] = caller_frame.f_code.co_name
                    attributes["caller.line"] = caller_frame.f_lineno
            except Exception:
                pass
            
            if conv_id:
                attributes[AttributeNames.GEN_AI_CONVERSATION_ID] = conv_id
            
            # Add trace ID for data lineage (single standard: trace.id)
            try:
                trace_id = format(trace.get_current_span().get_span_context().trace_id, '032x')
                attributes["trace.id"] = trace_id
            except Exception:
                pass
            
            if tags:
                attributes.update(tags)
            
            attributes.update(kwargs)
            
            # Add custom attributes (single name per value - no gen_ai.* duplicate)
            custom_attrs = tracer.get_custom_attributes()
            for key, value in custom_attrs.items():
                if key in (AttributeNames.GEN_AI_CONVERSATION_ID, AttributeNames.CONVERSATION_ID) and conv_id:
                    continue
                if key.startswith(('client.', 'http.', 'browser_id', 'ip_address', 'user_agent')):
                    continue
                attributes[key] = value
            
            # Extract and add comprehensive client data (IP, user agent, browser ID, etc.)
            try:
                from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data
                client_data = extract_comprehensive_client_data()
                
                # Add all client data to attributes
                if client_data.get('user_agent'):
                    attributes["http.user_agent"] = client_data['user_agent']
                if client_data.get('ip_address'):
                    attributes["client.ip"] = client_data['ip_address']
                if client_data.get('browser_id'):
                    attributes["client.id"] = client_data['browser_id']
                for key in ['accept_language', 'accept_encoding', 'accept', 'referer', 'origin',
                           'sec_ch_ua_platform', 'sec_ch_ua_mobile', 'sec_fetch_site', 'sec_fetch_mode',
                           'browser_name', 'browser_version', 'device_type', 'os_name', 'os_version', 'platform']:
                    if client_data.get(key):
                        key_attr = f"http.{key}" if key in ('accept_language', 'accept_encoding', 'accept', 'referer', 'origin', 'sec_ch_ua_platform', 'sec_ch_ua_mobile', 'sec_fetch_site', 'sec_fetch_mode') else f"client.{key}"
                        attributes[key_attr] = client_data[key]
            except Exception as e:
                logger.debug(f"Could not extract client data in traceable (async): {e}")
            
            # Extract user input (same as sync version)
            user_input = None
            if args:
                # Try to find string input in args
                for arg in args:
                    if isinstance(arg, str) and len(arg) > 0:
                        user_input = arg
                        break
                    elif hasattr(arg, '__dict__'):
                        # Try common attributes
                        for attr_name in ['input', 'query', 'message', 'prompt', 'text']:
                            if hasattr(arg, attr_name):
                                attr_value = getattr(arg, attr_name)
                                if isinstance(attr_value, str) and len(attr_value) > 0:
                                    user_input = attr_value
                                    break
                        if user_input:
                            break
            
            if not user_input:
                # Try kwargs
                for key in ['input', 'query', 'message', 'prompt', 'text', 'user_input']:
                    if key in func_kwargs:
                        value = func_kwargs[key]
                        if isinstance(value, str) and len(value) > 0:
                            user_input = value
                            break
            
            if user_input:
                attributes["llm.prompt"] = user_input
                attributes[AttributeNames.LLM_PROMPT_LENGTH] = len(user_input)
            
            # Create span and set as current context
            otel_tracer = tracer.get_tracer("saf3ai-custom")
            span, context_token = tracer._create_span(
                operation_name=span_name,
                span_kind="agent",
                attributes=attributes
            )
            
            # Set span as current context so LLM/tool calls become children
            ctx = trace.set_span_in_context(span)
            trace_token = context_api.attach(ctx)
            
            # Store traceable context
            _traceable_context.span = span
            _traceable_context.conversation_id = conv_id
            
            # Perform automatic security scanning on user input if scanner is configured
            scan_result = None
            if user_input:
                # Detect model name from attributes or use default
                model_name = attributes.get(AttributeNames.LLM_MODEL, attributes.get(AttributeNames.GEN_AI_MODEL_NAME, "unknown"))
                scan_result = _perform_automatic_scan(user_input, "prompt", conv_id, model_name, span)
                # Store scan result in context for retrieval if needed
                _traceable_context.scan_result = scan_result
            
            # Log all captured data for debugging
            logger.info("=" * 80)
            logger.info(f"📊 @traceable CAPTURED DATA (ASYNC) for '{span_name}'")
            logger.info("=" * 80)
            logger.info(f"  Function: {func.__name__}")
            logger.info(f"  Module: {func.__module__}")
            logger.info(f"  Conversation ID: {conv_id}")
            logger.info(f"  User Input: {user_input[:100] if user_input else 'None'}...")
            logger.info(f"  Attributes Count: {len(attributes)}")
            logger.info("  All Attributes:")
            for key, value in sorted(attributes.items()):
                value_str = str(value)
                if len(value_str) > 100:
                    value_str = value_str[:100] + "..."
                logger.info(f"    - {key}: {value_str}")
            logger.info("=" * 80)
            
            try:
                # Execute async function
                # Any LLM calls will automatically be traced as child spans
                result = await func(*args, **func_kwargs)
                _extract_and_set_usage_from_result(span, result)
                
                # Perform automatic security scanning on result if it's a string and scanner is configured
                result_scan = None
                if result and isinstance(result, str) and result.strip():
                    model_name = attributes.get("llm.model", attributes.get("gen_ai.model.name", "unknown"))
                    result_scan = _perform_automatic_scan(result, "response", conv_id, model_name, span)
                    # Store result scan in context
                    _traceable_context.result_scan = result_scan
                elif result is not None:
                    response_text = _extract_text_from_result(result)
                    if response_text:
                        model_name = attributes.get("llm.model", attributes.get("gen_ai.model.name", "unknown"))
                        result_scan = _perform_automatic_scan(response_text, "response", conv_id, model_name, span)
                        _traceable_context.result_scan = result_scan

                # Invoke framework-style callback pipeline in custom @traceable flow
                if user_input:
                    allowed = _invoke_security_callback_for_traceable(user_input, "prompt", span)
                    if not allowed:
                        raise ValueError("Security policy blocked prompt in @traceable callback")

                response_text = _extract_text_from_result(result)
                if response_text:
                    allowed = _invoke_security_callback_for_traceable(response_text, "response", span)
                    if not allowed:
                        raise ValueError("Security policy blocked response in @traceable callback")
                    span.set_attribute(AttributeNames.LLM_RESPONSE_LENGTH, len(response_text))

                detected_model = _extract_model_from_result(result)
                if detected_model:
                    span.set_attribute(AttributeNames.GEN_AI_RESPONSE_MODEL, detected_model)
                    if not attributes.get(AttributeNames.LLM_MODEL):
                        span.set_attribute(AttributeNames.LLM_MODEL, detected_model)
                
                # AUTOMATIC DOCUMENT ACCESS TRACKING: Detect and track document access from results
                # This automatically captures when agents access documents (e.g., from vector store searches)
                if result is not None:
                    # Extract query from user input or function args
                    detected_query = user_input
                    if not detected_query and args:
                        for arg in args:
                            if isinstance(arg, str) and len(arg) > 10:  # Likely a query
                                detected_query = arg
                                break
                    
                    # Track document access automatically
                    _track_document_access_automatic(
                        result=result,
                        span=span,
                        query=detected_query,
                        conversation_id=conv_id
                    )
                
                # Note: We don't record agent responses - only user inputs, LLM calls, and tool calls
                # The response is handled by LLM call spans if applicable
                
                # Add minimal result information (type only, no content)
                if result is not None:
                    span.set_attribute("function.result_type", type(result).__name__)
                    if hasattr(result, '__len__') and not isinstance(result, str):
                        span.set_attribute("function.result_length", len(result))
                
                # Add end time and duration for data lineage
                end_time = time.time()
                duration_ms = (end_time - start_time) * 1000
                span.set_attribute("gen_ai.request.end_time", end_time)
                span.set_attribute("gen_ai.request.duration_ms", duration_ms)
                span.set_attribute("gen_ai.request.duration_seconds", end_time - start_time)
                
                # Log final span data
                logger.debug(f"@traceable completed (async) '{span_name}' in {duration_ms:.2f}ms")
                
                span.set_status(Status(StatusCode.OK))
                return result
                
            except Exception as e:
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.set_attribute("error.message", str(e))
                span.set_attribute("error.type", type(e).__name__)
                logger.error(f"Error in {span_name}: {e}")
                raise
                
            finally:
                # CRITICAL: Ensure span is properly ended and exported
                # Log before ending to track span lifecycle
                logger.debug(f"@traceable ending span '{span_name}' (async), "
                           f"span_id={span.get_span_context().span_id:x}, "
                           f"trace_id={span.get_span_context().trace_id:x}, "
                           f"is_recording={span.is_recording()}")
                
                # Clean up context
                context_api.detach(trace_token)
                if context_token:
                    context_api.detach(context_token)
                
                # Clear traceable context
                if hasattr(_traceable_context, 'span'):
                    delattr(_traceable_context, 'span')
                if hasattr(_traceable_context, 'conversation_id'):
                    delattr(_traceable_context, 'conversation_id')
                if hasattr(_traceable_context, 'scan_result'):
                    delattr(_traceable_context, 'scan_result')
                if hasattr(_traceable_context, 'result_scan'):
                    delattr(_traceable_context, 'result_scan')
                
                # CRITICAL: End span explicitly - this triggers export via SimpleSpanProcessor
                if span.is_recording():
                    span.end()
                    logger.debug(f"@traceable span '{span_name}' (async) ended successfully and should be exported")
                else:
                    logger.warning(f"@traceable span '{span_name}' (async) was not recording, may not be exported")
        
        # Return appropriate wrapper based on function type
        if inspect.iscoroutinefunction(func):
            return async_wrapper
        else:
            return wrapper
    
    # Handle both @traceable and @traceable(name="...") syntax
    if callable(func_or_name):
        return actual_decorator(func_or_name)
    else:
        return actual_decorator


def get_traceable_context():
    """
    Get the current traceable context (span, conversation_id, and scan results).
    
    This can be used by instrumentation or other code to access the current
    traceable agent span, conversation ID, and scan results.
    
    Returns:
        Dict with 'span', 'conversation_id', 'scan_result', and 'result_scan' keys, 
        or None if not in traceable context
    """
    if hasattr(_traceable_context, 'span'):
        return {
            'span': getattr(_traceable_context, 'span', None),
            'conversation_id': getattr(_traceable_context, 'conversation_id', None),
            'scan_result': getattr(_traceable_context, 'scan_result', None),  # Input scan result
            'result_scan': getattr(_traceable_context, 'result_scan', None)   # Output scan result
        }
    return None
