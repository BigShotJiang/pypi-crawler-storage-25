"""
Constants for OpenTelemetry attributes and SDK configuration.

This module contains all string literals used throughout the SDK to avoid duplication.
"""

# OpenTelemetry attribute names
class AttributeNames:
    """OpenTelemetry attribute names."""
    # Conversation ID attributes
    GEN_AI_CONVERSATION_ID = "gen_ai.conversation.id"
    CONVERSATION_ID = "conversation_id"
    
    # Model attributes
    LLM_MODEL = "llm.model"
    GEN_AI_MODEL_NAME = "gen_ai.model.name"
    
    # Response attributes (use _length suffix to avoid ES/OpenSearch mapping conflict with llm.response as text)
    LLM_RESPONSE_LENGTH = "llm.response_length"
    GEN_AI_RESPONSE_LENGTH = "gen_ai.response_length"
    
    # Prompt attributes (use _length to avoid ES mapping conflict with llm.prompt as text)
    LLM_PROMPT_LENGTH = "llm.prompt_length"
    GEN_AI_PROMPT_LENGTH = "gen_ai.prompt_length"
    
    # Token usage attributes (GenAI semantic conventions)
    GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    GEN_AI_USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
    GEN_AI_USAGE_TOTAL_TOKENS = "gen_ai.usage.total_tokens"
    GEN_AI_RESPONSE_MODEL = "gen_ai.response.model"


# Framework detection messages
class FrameworkMessages:
    """Framework detection messages."""
    AUTO_DETECTED_FRAMEWORK_LANGCHAIN = "Auto-detected framework: 'langchain' (LangChain)"
    AUTO_DETECTED_FRAMEWORK_ADK = "Auto-detected framework: 'adk' (Google ADK)"
    AUTO_DETECTED_FRAMEWORK_CREWAI = "Auto-detected framework: 'crewai' (CrewAI)"
    NO_FRAMEWORK_DETECTED = "No framework detected, using 'custom' framework"
