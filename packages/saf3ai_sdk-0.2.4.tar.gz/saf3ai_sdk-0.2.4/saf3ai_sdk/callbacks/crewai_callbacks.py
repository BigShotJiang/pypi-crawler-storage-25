"""
CrewAI-native callbacks for security scanning.

This module provides callbacks that integrate with CrewAI's callback system.
Since CrewAI uses LangChain under the hood, we leverage LangChain's callback system
but add CrewAI-specific enhancements for Agent, Task, and Crew tracking.
"""

import logging
import os
import threading
from typing import Optional, TYPE_CHECKING, Any, Dict, List

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode
from saf3ai_sdk.core.constants import AttributeNames

logger = logging.getLogger(__name__)

# CrewAI availability check
CREWAI_AVAILABLE = False
try:
    from crewai import Agent, Task, Crew
    CREWAI_AVAILABLE = True
except ImportError:
    logger.debug("CrewAI not available - callbacks will not work")

# LangChain callback cache (CrewAI uses LangChain)
_LANGCHAIN_CACHE = {
    'BaseCallbackHandler': None,
    'LLMResult': None,
    'available': None,
    'version_info': None,
}

def _detect_langchain_for_crewai():
    """Detect LangChain classes for CrewAI (since CrewAI uses LangChain)."""
    if _LANGCHAIN_CACHE['available'] is not None:
        return (
            _LANGCHAIN_CACHE['BaseCallbackHandler'],
            _LANGCHAIN_CACHE['LLMResult'],
            _LANGCHAIN_CACHE['version_info']
        )
    
    import_paths = [
        ('langchain_core.callbacks', 'BaseCallbackHandler', 'langchain_core.outputs', 'LLMResult', 'v0.1+ (langchain_core)'),
        ('langchain.callbacks.base', 'BaseCallbackHandler', 'langchain.schema', 'LLMResult', 'v0.0.x (langchain)'),
        ('langchain.callbacks', 'BaseCallbackHandler', 'langchain.schema.output', 'LLMResult', 'alternative (langchain)'),
    ]
    
    for callback_module, callback_class, result_module, result_class, version_info in import_paths:
        try:
            import importlib
            callback_mod = importlib.import_module(callback_module)
            result_mod = importlib.import_module(result_module)
            
            base_callback_handler = getattr(callback_mod, callback_class)
            llm_result = getattr(result_mod, result_class)
            
            if not (isinstance(base_callback_handler, type) and isinstance(llm_result, type)):
                continue
            
            _LANGCHAIN_CACHE['BaseCallbackHandler'] = base_callback_handler
            _LANGCHAIN_CACHE['LLMResult'] = llm_result
            _LANGCHAIN_CACHE['available'] = True
            _LANGCHAIN_CACHE['version_info'] = version_info
            
            logger.debug(f"LangChain detected for CrewAI: {version_info}")
            return (base_callback_handler, llm_result, version_info)
            
        except (ImportError, AttributeError, ModuleNotFoundError):
            continue
        except Exception as e:
            logger.debug(f"Unexpected error detecting LangChain for CrewAI: {e}")
            continue
    
    _LANGCHAIN_CACHE['available'] = False
    _LANGCHAIN_CACHE['version_info'] = None
    return (None, None, None)

def _is_langchain_available_for_crewai():
    """Check if LangChain is available (required for CrewAI)."""
    if _LANGCHAIN_CACHE['available'] is None:
        _detect_langchain_for_crewai()
    return _LANGCHAIN_CACHE['available'] is True

def _get_langchain_base_handler():
    """Get BaseCallbackHandler class (lazy-loaded)."""
    if _LANGCHAIN_CACHE['BaseCallbackHandler'] is None:
        _detect_langchain_for_crewai()
    return _LANGCHAIN_CACHE['BaseCallbackHandler']

# Use unified conversation ID helper from core.tracer
from saf3ai_sdk.core.tracer import set_conversation_id_unified as _set_conversation_id_in_attributes

# Registry for CrewAI run tracking (similar to LangChain)
_crewai_run_registry = {}
_crewai_registry_lock = threading.Lock()
_MAX_REGISTRY_SIZE = 5000

def _register_crewai_run(run_id: str, trace_id: str):
    """Register a CrewAI run_id → trace_id mapping."""
    if not run_id or not trace_id:
        return
    
    try:
        with _crewai_registry_lock:
            if len(_crewai_run_registry) >= _MAX_REGISTRY_SIZE:
                items_to_remove = list(_crewai_run_registry.keys())[:int(_MAX_REGISTRY_SIZE * 0.25)]
                for key in items_to_remove:
                    del _crewai_run_registry[key]
                logger.debug(f"CrewAI registry cleanup: removed {len(items_to_remove)} entries")
            
            _crewai_run_registry[run_id] = trace_id
            logger.debug(f"Registered CrewAI run_id={run_id} → trace_id={trace_id}")
    except Exception as e:
        logger.debug(f"Error registering CrewAI run_trace: {e}")

def _get_trace_id_from_crewai_registry(run_id: str) -> Optional[str]:
    """Get trace_id from CrewAI registry by run_id."""
    if not run_id:
        return None
    try:
        with _crewai_registry_lock:
            return _crewai_run_registry.get(run_id)
    except Exception:
        return None

def _extract_crewai_conversation_id(kwargs: Dict[str, Any], use_provided_id: Optional[str] = None) -> Optional[str]:
    """
    Extract conversation ID from CrewAI/LangChain callback kwargs.
    
    CrewAI uses LangChain's callback system, so we use similar logic.
    
    Priority order:
    1. Provided conversation_id (from app, e.g., Streamlit UUID)
    2. LangChain run.trace_id (groups all runs in conversation)
    3. LangChain parent_run_id → lookup in registry
    4. CrewAI-specific metadata (crew_id, task_id, agent_id)
    5. LangChain run.id or run.run_id
    """
    try:
        # Priority 1: Use provided conversation_id FIRST
        if use_provided_id:
            logger.debug(f"Using provided conversation_id: {use_provided_id}")
            return str(use_provided_id)
        
        # Priority 2: Extract from LangChain run object (CrewAI uses LangChain)
        run = kwargs.get("run")
        if run:
            trace_id = getattr(run, "trace_id", None)
            run_id = getattr(run, "id", None) or getattr(run, "run_id", None)
            parent_run_id = getattr(run, "parent_run_id", None) or kwargs.get("parent_run_id")
            
            # Register run_id → trace_id mapping
            if run_id and trace_id:
                _register_crewai_run(str(run_id), str(trace_id))
            
            if trace_id:
                logger.debug(f"Extracted CrewAI/LangChain trace_id: {trace_id}")
                return str(trace_id)
            
            # If we have parent_run_id, try to find parent's trace_id from registry
            if parent_run_id:
                parent_trace_id = _get_trace_id_from_crewai_registry(str(parent_run_id))
                if parent_trace_id:
                    logger.debug(f"Found parent trace_id via CrewAI registry: {parent_trace_id}")
                    if run_id:
                        _register_crewai_run(str(run_id), parent_trace_id)
                    return parent_trace_id
            
            # Fallback to run_id
            if run_id:
                logger.debug(f"Extracted CrewAI/LangChain run_id: {run_id}")
                return str(run_id)
        
        # Priority 3: CrewAI-specific metadata
        metadata = kwargs.get("metadata", {})
        if isinstance(metadata, dict):
            # Check for CrewAI-specific IDs
            crew_id = metadata.get("crew_id") or metadata.get("crew.id")
            task_id = metadata.get("task_id") or metadata.get("task.id")
            agent_id = metadata.get("agent_id") or metadata.get("agent.id")
            
            if crew_id:
                logger.debug(f"Extracted CrewAI crew_id: {crew_id}")
                return str(crew_id)
            if task_id:
                logger.debug(f"Extracted CrewAI task_id: {task_id}")
                return str(task_id)
            if agent_id:
                logger.debug(f"Extracted CrewAI agent_id: {agent_id}")
                return str(agent_id)
            
            # Fallback to LangChain metadata
            trace_id = metadata.get("trace_id") or metadata.get("langsmith_trace_id")
            if trace_id:
                logger.debug(f"Extracted trace_id from CrewAI metadata: {trace_id}")
                return str(trace_id)
        
        # Priority 4: Direct run_id in kwargs
        run_id = kwargs.get("run_id")
        if run_id:
            logger.debug(f"Extracted run_id from CrewAI kwargs: {run_id}")
            return str(run_id)
        
    except Exception as e:
        logger.debug(f"Error extracting conversation ID from CrewAI kwargs: {e}")
    
    return None

def _extract_conversation_id_from_span(span) -> Optional[str]:
    """Extract conversation ID from span with fallback strategies."""
    try:
        if span and span.is_recording():
            conv_id = span.attributes.get(AttributeNames.GEN_AI_CONVERSATION_ID)
            if conv_id:
                logger.debug(f"Found conversation_id in CrewAI span attributes: {conv_id}")
                return str(conv_id)
            
            # Use OpenTelemetry trace_id as fallback
            span_context = span.get_span_context()
            if span_context and span_context.is_valid:
                trace_id = format(span_context.trace_id, '032x')
                logger.debug(f"No conversation ID found, using OpenTelemetry trace_id: {trace_id}")
                return trace_id
    except Exception as e:
        logger.debug(f"Could not extract conversation ID from CrewAI span: {e}")
    
    return None

# Create CrewAI SecurityCallback class dynamically
def _create_crewai_security_callback_class():
    """Dynamically create CrewAISecurityCallback class that inherits from LangChain's BaseCallbackHandler."""
    langchain_base_handler = _get_langchain_base_handler()
    
    if langchain_base_handler is None:
        class CrewAISecurityCallback:
            """CrewAI security callback - LangChain not available. Install langchain to use with CrewAI."""
            pass
        return CrewAISecurityCallback
    
    # LangChain is available - create proper subclass
    class CrewAISecurityCallback(langchain_base_handler):
        """
        CrewAI BaseCallbackHandler that scans prompts and optionally responses for security threats.
        
        This callback can be passed to CrewAI Agents, Tasks, or Crews via the callbacks parameter.
        Since CrewAI uses LangChain, this inherits from LangChain's BaseCallbackHandler.
        
        ROBUST CONVERSATION ID MANAGEMENT:
        - Accepts conversation_id parameter in __init__ (app can pass persisted ID)
        - Automatically extracts from CrewAI/LangChain if not provided
        - Walks parent_run_id chain to find root trace_id
        - Respects existing IDs - never overwrites if already set
        """
        
        def __init__(
            self,
            api_endpoint: str,
            api_key: Optional[str] = None,
            timeout: int = 10,
            on_scan_complete: Optional[callable] = None,
            scan_responses: Optional[bool] = None,
            agent_identifier: Optional[str] = None,
            conversation_id: Optional[str] = None,
        ):
            """
            Initialize the CrewAI security callback.
            
            Args:
                api_endpoint: URL of the on-prem scanning API
                api_key: Optional API key for authentication
                timeout: Request timeout in seconds
                on_scan_complete: Optional callback function(text, scan_results, text_type) -> bool
                scan_responses: If True, also scans responses after generation
                agent_identifier: Optional agent identifier for custom guardrails enforcement
                conversation_id: Optional conversation ID (if provided, SDK will use this instead of extracting)
            """
            try:
                super().__init__()
            except TypeError:
                pass
            
            self.api_endpoint = api_endpoint
            self.api_key = api_key
            self.timeout = timeout
            self.on_scan_complete = on_scan_complete
            
            if scan_responses is None:
                import os
                self.scan_responses = os.getenv("SAF3AI_SCAN_RESPONSES", "true").lower() == "true"
            else:
                self.scan_responses = scan_responses
            
            self.agent_identifier = agent_identifier
            self._provided_conversation_id = conversation_id
            
            import os
            self.capture_responses = os.getenv("SAF3AI_CAPTURE_RESPONSES", "true").lower() == "true"
            
            try:
                from saf3ai_sdk.scanner import scan_prompt as _scan_prompt
                from saf3ai_sdk.scanner import scan_response as _scan_response
                self._scan_prompt = _scan_prompt
                self._scan_response = _scan_response
            except ImportError:
                logger.error("scanner module not available")
                self._scan_prompt = None
                self._scan_response = None
            
            if self._provided_conversation_id:
                _set_conversation_id_in_attributes(self._provided_conversation_id, source="app_provided_crewai")
                logger.debug(f"Using provided conversation_id for CrewAI: {self._provided_conversation_id}")
        
        def on_chain_start(
            self, 
            serialized: Dict[str, Any], 
            inputs: Dict[str, Any], 
            **kwargs: Any
        ) -> None:
            """CrewAI callback method called when a chain starts."""
            conversation_id = None
            try:
                from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                existing_conv_id = custom_attrs.get(AttributeNames.GEN_AI_CONVERSATION_ID) or custom_attrs.get(AttributeNames.CONVERSATION_ID)
                
                if existing_conv_id:
                    conversation_id = existing_conv_id
                    logger.debug(f"Using existing conversation_id from custom attributes: {conversation_id}")
            except Exception as e:
                logger.debug(f"Could not check existing conversation_id: {e}")
            
            if not conversation_id:
                conversation_id = _extract_crewai_conversation_id(
                    kwargs, 
                    use_provided_id=self._provided_conversation_id
                )
                
                if conversation_id:
                    _set_conversation_id_in_attributes(conversation_id, source="crewai_chain_start")
                else:
                    try:
                        span = trace.get_current_span()
                        if span:
                            conversation_id = _extract_conversation_id_from_span(span)
                            if conversation_id:
                                _set_conversation_id_in_attributes(conversation_id, source="crewai_span_fallback")
                    except Exception as e:
                        logger.debug(f"Failed to extract conversation ID in CrewAI on_chain_start: {e}")
        
        def on_llm_start(
            self, 
            serialized: Dict[str, Any], 
            prompts: List[str], 
            **kwargs: Any
        ) -> None:
            """CrewAI callback method called before LLM is invoked."""
            conversation_id = None
            try:
                from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                existing_conv_id = custom_attrs.get(AttributeNames.GEN_AI_CONVERSATION_ID) or custom_attrs.get(AttributeNames.CONVERSATION_ID)
                
                if existing_conv_id:
                    conversation_id = existing_conv_id
                    logger.debug(f"Using existing conversation_id from custom attributes: {conversation_id}")
            except Exception as e:
                logger.debug(f"Could not check existing conversation_id: {e}")
            
            if not conversation_id:
                conversation_id = _extract_crewai_conversation_id(
                    kwargs,
                    use_provided_id=self._provided_conversation_id
                )
                
                if conversation_id:
                    _set_conversation_id_in_attributes(conversation_id, source="crewai_llm_start")
                else:
                    try:
                        span = trace.get_current_span()
                        if span:
                            conversation_id = _extract_conversation_id_from_span(span)
                            if conversation_id:
                                _set_conversation_id_in_attributes(conversation_id, source="crewai_span_llm_fallback")
                    except Exception as e:
                        logger.debug(f"Failed to extract conversation ID in CrewAI on_llm_start: {e}")
            
            if not self._scan_prompt:
                logger.warning("Scanner not available, skipping security scan")
                return
            
            span = trace.get_current_span()
            
            model_name = serialized.get("id", ["unknown"])[-1] if isinstance(serialized.get("id"), list) else serialized.get("name", "unknown")
            
            spans_to_update = []
            if span and span.is_recording():
                spans_to_update.append(span)
            
            for prompt in prompts:
                if not prompt:
                    logger.debug("Empty prompt, skipping security scan")
                    continue
                
                for target_span in spans_to_update:
                    target_span.set_attribute("security.scan.enabled", True)
                    target_span.set_attribute("security.scan.prompt_length", len(prompt))
                    target_span.set_attribute("security.scan.model", model_name)
                    target_span.set_attribute("security.scan.prompt", prompt)
                    target_span.set_attribute("llm.prompt", prompt)
                    
                    if conversation_id:
                        target_span.set_attribute(AttributeNames.GEN_AI_CONVERSATION_ID, conversation_id)
                    
                    try:
                        from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                        client_data = extract_comprehensive_client_data()
                        _add_client_data_to_span(target_span, client_data)
                    except Exception as e:
                        logger.debug(f"Could not extract client data in CrewAI callback: {e}")
                
                try:
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.add_event("security_scan_started", {"prompt_length": len(prompt)})
                    
                    metadata = {"agent_identifier": self.agent_identifier} if self.agent_identifier else {}
                    
                    scan_results = self._scan_prompt(
                        prompt=prompt,
                        api_endpoint=self.api_endpoint,
                        model_name=model_name,
                        conversation_id=conversation_id,
                        api_key=self.api_key,
                        timeout=self.timeout,
                        metadata=metadata
                    )
                    
                    scan_duration = scan_results.get("scan_metadata", {}).get("duration_ms", 0)
                    detection_results = scan_results.get("detection_results", {})
                    
                    threats_found = []
                    for threat_type, result_data in detection_results.items():
                        if result_data.get("result") == "MATCH_FOUND":
                            threats_found.append(threat_type)
                    
                    out_of_scope = scan_results.get("OutofScopeAnalysis", {})
                    detected_categories = out_of_scope.get("detected_categories", [])
                    
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.set_attribute("security.scan.duration_ms", scan_duration)
                            target_span.set_attribute("security.scan.api_status", 200)
                            target_span.set_attribute("security.threats_found", len(threats_found) > 0)
                            target_span.set_attribute("security.threat_count", len(threats_found))
                            
                            if threats_found:
                                target_span.set_attribute("security.threat_types", ",".join(threats_found))
                            
                            if detected_categories:
                                category_names = [c.get("category", "").split("/")[1] for c in detected_categories[:3] if c.get("category")]
                                if category_names:
                                    target_span.set_attribute("security.categories", ",".join(category_names))
                                target_span.set_attribute("security.category_count", len(detected_categories))
                            
                            import json
                            try:
                                scan_results_json = json.dumps(scan_results)
                                if len(scan_results_json) <= 4000:
                                    target_span.set_attribute("security.scan.full_results", scan_results_json)
                                else:
                                    summary = {
                                        "detection_results": detection_results,
                                        "category_count": len(detected_categories),
                                        "top_categories": detected_categories[:3]
                                    }
                                    target_span.set_attribute("security.scan.full_results", json.dumps(summary))
                            except Exception as e:
                                logger.warning(f"Could not serialize scan results: {e}")
                            
                            target_span.add_event("security_scan_completed", {
                                "threats": len(threats_found),
                                "categories": len(detected_categories)
                            })
                    
                    logger.info(
                        f"CrewAI security scan completed: {len(threats_found)} threats, "
                        f"{len(detected_categories)} categories"
                    )
                    
                    should_allow = True
                    if self.on_scan_complete:
                        try:
                            should_allow = self.on_scan_complete(prompt, scan_results, "prompt")
                            logger.info(f"CrewAI user callback returned: allow={should_allow}")
                            
                            for target_span in spans_to_update:
                                if target_span and target_span.is_recording():
                                    target_span.set_attribute("security.user_decision", "allow" if should_allow else "block")
                                    if not should_allow:
                                        target_span.set_attribute("security.blocked_by", "user_callback")
                        
                        except Exception as callback_error:
                            logger.error(f"Error in CrewAI user callback: {callback_error}", exc_info=True)
                            should_allow = True
                            for target_span in spans_to_update:
                                if target_span and target_span.is_recording():
                                    target_span.set_attribute("security.callback_error", str(callback_error))
                    
                    if not should_allow:
                        threat_messages = {
                            "CSAM": "inappropriate content involving minors",
                            "Dangerous": "dangerous or harmful content",
                            "HateSpeech": "hate speech or discriminatory content",
                            "Harassment": "harassing or bullying content",
                            "SexualExplicit": "sexually explicit content",
                            "PIandJailbreak": "an attempt to bypass security controls",
                            "MaliciousURIs": "potentially malicious links",
                            "SenstiveData": "sensitive personal information"
                        }
                        
                        detected_issues = [threat_messages.get(t, t.lower()) for t in threats_found]
                        
                        if len(detected_issues) == 0:
                            issues_text = "content that violates security policy"
                        elif len(detected_issues) == 1:
                            issues_text = detected_issues[0]
                        else:
                            issues_text = ", ".join(detected_issues[:-1]) + f" and {detected_issues[-1]}"
                        
                        error_message = (
                            f"I'm sorry, but I cannot assist with this request. "
                            f"The system detected {issues_text}. "
                            f"This system is not allowed to answer questions of this nature."
                        )
                        
                        logger.warning(f"CrewAI user callback blocked LLM call: {error_message}")
                        
                        for target_span in spans_to_update:
                            if target_span and target_span.is_recording():
                                target_span.set_status(Status(StatusCode.ERROR, "Security violation detected"))
                                target_span.add_event("security_request_blocked", {
                                    "threat_types": ",".join(threats_found)
                                })
                        
                        raise ValueError(error_message)
                    
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.set_attribute("security.scan.status", "completed")
                            target_span.set_status(Status(StatusCode.OK))
                
                except ValueError:
                    raise
                
                except Exception as e:
                    error_msg = f"CrewAI scanning error: {str(e)}"
                    logger.error(error_msg, exc_info=True)
                    
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.set_attribute("security.scan.status", "error")
                            target_span.set_attribute("security.scan.error", error_msg)
        
        def on_llm_end(self, response, **kwargs: Any) -> None:
            """CrewAI callback method called after LLM finishes generating."""
            if not self.scan_responses or not self._scan_response:
                return
            
            conversation_id = None
            try:
                from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                existing_conv_id = custom_attrs.get(AttributeNames.GEN_AI_CONVERSATION_ID) or custom_attrs.get(AttributeNames.CONVERSATION_ID)
                
                if existing_conv_id:
                    conversation_id = existing_conv_id
                    logger.debug(f"Using existing conversation_id from custom attributes: {conversation_id}")
            except Exception as e:
                logger.debug(f"Could not check existing conversation_id: {e}")
            
            if not conversation_id:
                conversation_id = _extract_crewai_conversation_id(
                    kwargs,
                    use_provided_id=self._provided_conversation_id
                )
                
                if conversation_id:
                    _set_conversation_id_in_attributes(conversation_id, source="crewai_llm_end")
            
            span = trace.get_current_span()
            
            if not conversation_id:
                conversation_id = _extract_conversation_id_from_span(span)
                if conversation_id:
                    _set_conversation_id_in_attributes(conversation_id, source="crewai_span_llm_end_fallback")
            
            response_text = _extract_response_from_llm_result(response)
            if not response_text:
                logger.warning("No response text extracted from CrewAI LLMResult - skipping response scan")
                return
            
            logger.debug(f"Extracted CrewAI response text length: {len(response_text)} chars")
            
            spans_to_update = []
            if span and span.is_recording():
                spans_to_update.append(span)
            
            for target_span in spans_to_update:
                target_span.set_attribute("security.response_scan.enabled", True)
                target_span.set_attribute("security.response_scan.length", len(response_text))
                
                if self.capture_responses and response_text:
                    target_span.set_attribute("llm.response", response_text)
                    target_span.set_attribute(AttributeNames.LLM_RESPONSE_LENGTH, len(response_text))
                
                if conversation_id:
                    target_span.set_attribute(AttributeNames.GEN_AI_CONVERSATION_ID, conversation_id)
                
                try:
                    from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                    client_data = extract_comprehensive_client_data()
                    _add_client_data_to_span(target_span, client_data)
                except Exception as e:
                    logger.debug(f"Could not extract client data in CrewAI response callback: {e}")
            
            try:
                for target_span in spans_to_update:
                    if target_span and target_span.is_recording():
                        target_span.add_event("security_response_scan_started", {"response_length": len(response_text)})
                
                metadata = {"agent_identifier": self.agent_identifier} if self.agent_identifier else {}
                
                scan_results = self._scan_response(
                    response=response_text,
                    api_endpoint=self.api_endpoint,
                    model_name="unknown",
                    conversation_id=conversation_id,
                    api_key=self.api_key,
                    timeout=self.timeout,
                    metadata=metadata
                )
                
                detection_results = scan_results.get("detection_results", {})
                threats_found = [k for k, v in detection_results.items() if v.get("result") == "MATCH_FOUND"]
                has_threats = len(threats_found) > 0
                
                for target_span in spans_to_update:
                    if target_span and target_span.is_recording():
                        target_span.set_attribute("security.response_threats_found", has_threats)
                        target_span.set_attribute("security.response_threat_count", len(threats_found))
                        if threats_found:
                            target_span.set_attribute("security.response_threat_types", ",".join(threats_found))
                        
                        if has_threats and response_text:
                            target_span.set_attribute("security.response.threat_detected", True)
                            target_span.set_attribute("llm.response", response_text)
                            target_span.set_attribute(AttributeNames.LLM_RESPONSE_LENGTH, len(response_text))
                            logger.debug(f"Stored CrewAI response text due to detected threats: {', '.join(threats_found)}")
                        
                        import json
                        try:
                            scan_results_json = json.dumps(scan_results)
                            if len(scan_results_json) <= 4000:
                                target_span.set_attribute("security.response_scan.full_results", scan_results_json)
                            else:
                                out_of_scope = scan_results.get("OutofScopeAnalysis", {})
                                detected_categories = out_of_scope.get("detected_categories", [])
                                summary = {
                                    "detection_results": detection_results,
                                    "category_count": len(detected_categories),
                                    "top_categories": detected_categories[:3]
                                }
                                target_span.set_attribute("security.response_scan.full_results", json.dumps(summary))
                        except Exception as e:
                            logger.warning(f"Could not serialize CrewAI response scan results: {e}")
                
                should_allow = True
                if self.on_scan_complete:
                    try:
                        should_allow = self.on_scan_complete(response_text, scan_results, "response")
                        logger.info(f"CrewAI user callback for response: allow={should_allow}")
                        
                        for target_span in spans_to_update:
                            if target_span and target_span.is_recording():
                                target_span.set_attribute("security.response_user_decision", "allow" if should_allow else "block")
                    except Exception as e:
                        logger.error(f"Error in CrewAI response callback: {e}", exc_info=True)
                        should_allow = True
                
                if not should_allow:
                    error_message = (
                        f"🚫 Security Violation: The generated response contains security concerns. "
                        f"Detected: {', '.join(threats_found)}."
                    )
                    logger.warning(f"CrewAI response blocked: {error_message}")
                    
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.set_status(Status(StatusCode.ERROR, "Response security violation"))
                            target_span.add_event("security_response_blocked", {
                                "threat_types": ",".join(threats_found)
                            })
            
            except Exception as e:
                logger.error(f"Error scanning CrewAI response: {e}", exc_info=True)
    
    return CrewAISecurityCallback

# Create CrewAISecurityCallback class at module load time (lazy-loaded)
CrewAISecurityCallback = _create_crewai_security_callback_class()

def _extract_response_from_llm_result(llm_result) -> str:
    """Extract ONLY the textual content from a LangChain LLMResult (used by CrewAI)."""
    try:
        response_parts: List[str] = []
        
        generations = getattr(llm_result, "generations", None)
        if not generations:
            return ""
        
        for generation_list in generations:
            if not generation_list:
                continue
                
            for generation in generation_list:
                text_value = None
                
                if hasattr(generation, "text"):
                    text_attr = generation.text
                    if isinstance(text_attr, str) and text_attr.strip():
                        text_value = text_attr
                    elif text_attr:
                        try:
                            text_value = str(text_attr).strip()
                            if not text_value:
                                continue
                        except Exception:
                            continue
                
                if not text_value and hasattr(generation, "message"):
                    message = generation.message
                    content = getattr(message, "content", None)
                    
                    if isinstance(content, str) and content.strip():
                        text_value = content
                    elif isinstance(content, list):
                        for chunk in content:
                            chunk_text = getattr(chunk, "text", None)
                            if chunk_text and isinstance(chunk_text, str) and chunk_text.strip():
                                response_parts.append(chunk_text)
                        continue
                    elif content:
                        try:
                            text_value = str(content).strip()
                            if not text_value:
                                continue
                        except Exception:
                            continue
                
                if text_value:
                    response_parts.append(text_value)
        
        if response_parts:
            result = "\n".join(response_parts)
            logger.debug(f"Extracted {len(response_parts)} text parts from CrewAI LLMResult, total length: {len(result)} chars")
            return result
        
        return ""
    except Exception as e:
        logger.error(f"Error extracting response from CrewAI LLMResult: {e}", exc_info=True)
        return ""

def create_security_callback(
    api_endpoint: str, 
    api_key: Optional[str] = None, 
    timeout: int = 10, 
    on_scan_complete: Optional[callable] = None,
    scan_responses: Optional[bool] = None,
    agent_identifier: Optional[str] = None,
    conversation_id: Optional[str] = None,
):
    """
    Create CrewAI callbacks that scan prompts and optionally responses for security threats.
    
    This function returns a BaseCallbackHandler instance that can be passed to CrewAI
    Agents, Tasks, or Crews via the callbacks parameter.
    
    IMPORTANT: The Saf3AI SDK must be initialized before creating callbacks.
    Call saf3ai_sdk.init(...) first. The SDK will auto-detect CrewAI framework.
    
    Args:
        api_endpoint: URL of the on-prem scanning API
        api_key: Optional API key for authentication
        timeout: Request timeout in seconds
        on_scan_complete: Optional callback function(text, scan_results, text_type) -> bool
        scan_responses: If True, also scans responses after generation
        agent_identifier: Optional agent identifier for custom guardrails enforcement
        conversation_id: Optional conversation ID (if provided, SDK will use this instead of extracting)
    
    Returns:
        A CrewAISecurityCallback instance (BaseCallbackHandler subclass) that can be used as a CrewAI callback
    
    Example:
        ```python
        from saf3ai_sdk import init
        from saf3ai_sdk.callbacks.crewai_callbacks import create_security_callback
        from crewai import Agent, Task, Crew
        
        # Initialize SDK
        init(agent_id="my-agent", api_key="...", safeai_collector_agent="...")
        
        # Create security callback
        callback = create_security_callback(
            api_endpoint="https://scanner.example.com",
            agent_identifier="my-crewai-agent"
        )
        
        # Use with CrewAI
        agent = Agent(
            role="Researcher",
            goal="Research topics",
            backstory="You are a researcher",
            callbacks=[callback]  # Add security scanning
        )
        ```
    """
    if not CREWAI_AVAILABLE:
        error_msg = (
            f"CrewAI not available - cannot create security callback.\n"
            f"Please install CrewAI: pip install crewai"
        )
        logger.error(error_msg)
        return None
    
    if not _is_langchain_available_for_crewai():
        error_msg = (
            f"LangChain not available - CrewAI requires LangChain.\n"
            f"Please install LangChain: pip install langchain langchain-core"
        )
        logger.error(error_msg)
        return None
    
    global CrewAISecurityCallback
    if CrewAISecurityCallback is None or (hasattr(CrewAISecurityCallback, '__doc__') and 'LangChain not available' in str(CrewAISecurityCallback.__doc__)):
        CrewAISecurityCallback = _create_crewai_security_callback_class()
    
    try:
        from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
        if not saf3ai_tracer_core.initialized:
            raise RuntimeError(
                "Saf3AI SDK not initialized. "
                "Please call saf3ai_sdk.init(...) before creating callbacks. "
                "The SDK will auto-detect CrewAI framework.\n"
                "Example:\n"
                "  from saf3ai_sdk import init\n"
                "  init(agent_id='...', api_key='...', safeai_collector_agent='...')\n"
                "  from saf3ai_sdk.callbacks.crewai_callbacks import create_security_callback\n"
                "  callback = create_security_callback(...)"
            )
    except ImportError:
        raise RuntimeError(
            "Saf3AI SDK not initialized. "
            "Please call saf3ai_sdk.init(...) before creating callbacks. "
            "The SDK will auto-detect CrewAI framework."
        )
    
    return CrewAISecurityCallback(
        api_endpoint=api_endpoint,
        api_key=api_key,
        timeout=timeout,
        on_scan_complete=on_scan_complete,
        scan_responses=scan_responses,
        agent_identifier=agent_identifier,
        conversation_id=conversation_id,
    )
