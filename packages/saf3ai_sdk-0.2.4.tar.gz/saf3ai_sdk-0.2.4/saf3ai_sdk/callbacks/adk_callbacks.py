"""
ADK-native callbacks for security scanning.

This module provides callbacks that integrate with ADK's built-in callback system
instead of monkey-patching. This is the clean, official way to intercept LLM calls.
"""

import logging
import os
from typing import Optional, TYPE_CHECKING

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode
from saf3ai_sdk.core.constants import AttributeNames

logger = logging.getLogger(__name__)

# Import ADK types
try:
    from google.adk.agents.callback_context import CallbackContext
    from google.adk.models.llm_request import LlmRequest
    from google.adk.models.llm_response import LlmResponse
    ADK_AVAILABLE = True
except ImportError:
    ADK_AVAILABLE = False
    # Only log at debug level - this is expected when ADK is not installed
    # A warning will be logged if someone actually tries to use ADK features
    logger.debug("ADK not available - callbacks will not work")
    # Define stub types for type checking when ADK is not available
    if TYPE_CHECKING:
        from typing import Any
        CallbackContext = Any
        LlmRequest = Any
        LlmResponse = Any
    else:
        # Use string literals for runtime type hints when ADK is not available
        CallbackContext = "CallbackContext"
        LlmRequest = "LlmRequest"
        LlmResponse = "LlmResponse"


def create_security_callback(api_endpoint: str, api_key: Optional[str] = None, 
                            timeout: int = 10, on_scan_complete: Optional[callable] = None,
                            scan_responses: Optional[bool] = None, agent_identifier: Optional[str] = None):
    """
    Create ADK callbacks that scan prompts and optionally responses for security threats.
    
    This function returns callback(s) that can be passed to LlmAgent's callback parameters.
    
    Args:
        api_endpoint: URL of the on-prem scanning API
        api_key: Optional API key for authentication
        timeout: Request timeout in seconds
        on_scan_complete: Optional callback function(text, scan_results, text_type) -> bool
                         Should return True to allow, False to block
                         text_type will be "prompt" or "response"
        scan_responses: If True, also returns after_model_callback to scan responses. If None, uses config default (default: True).
        agent_identifier: Optional agent identifier for custom guardrails enforcement
    
    Returns:
        If scan_responses=False: A before_model_callback function
        If scan_responses=True: Tuple of (before_model_callback, after_model_callback)
        
    Example:
        ```python
        def my_policy(prompt, scan_results):
            return scan_results["threats"]["max_severity"] not in ["high", "critical"]
        
        import os
        callback = create_security_callback(
            api_endpoint=os.getenv("ONPREM_SCANNER_API_URL"),  # CHANGED: Use env var instead of hardcoded localhost
            on_scan_complete=my_policy
        )
        
        agent = LlmAgent(
            name="my_agent",
            model="gemini-2.5-flash",
            before_model_callback=callback
        )
        ```
    """
    if not ADK_AVAILABLE:
        # Only warn at debug level to avoid noise when framework is not ADK
        # The warning will still appear if someone explicitly tries to use ADK features
        logger.debug(
            "ADK not available - cannot create security callback. "
            "This is expected when framework is not 'adk' or 'google-adk'."
        )
        return None
    
    # Import the security scanner
    try:
        from saf3ai_sdk.scanner import scan_prompt as _scan_prompt
    except ImportError:
        logger.error("scanner module not available")
        return None
    
    def security_callback(*, callback_context: CallbackContext, llm_request: LlmRequest) -> Optional[LlmResponse]:
        """
        ADK before_model_callback that scans prompts for security threats.
        
        Args:
            callback_context: CallbackContext from ADK
            llm_request: The LLM request about to be sent
        
        Returns:
            None to allow the request, or an LlmResponse to block it
        """
        # CRITICAL: Set single conversation_id first so this callback and all spans use one ID
        _ensure_single_conversation_id_at_callback_start(callback_context)
        # Get the current span for telemetry
        # In ADK callbacks, this will be the call_llm span
        span = trace.get_current_span()
        
        # ALSO get the agent span (the one that gets exported)
        # We store a reference to it in the instrumentation
        agent_span = None
        try:
            from saf3ai_sdk.instrumentation.adk_instrumentation import _current_agent_span
            agent_span = getattr(_current_agent_span, 'span', None)
        except (ImportError, AttributeError):
            # Gracefully handle if instrumentation module is not available
            pass
        
        # Extract the prompt from the request
        prompt = _extract_prompt_from_request(llm_request)
        if not prompt:
            logger.debug("No prompt found in request, skipping security scan")
            return None
        
        # Get model name
        model_name = getattr(llm_request, 'model', 'unknown')
        
        # Get conversation ID from context or span
        conversation_id = _extract_conversation_id(callback_context, span)
        
        # Add security scan attributes to current span AND agent span
        # The current span might be call_llm, but we also need to add to the agent span
        spans_to_update = []
        if span and span.is_recording():
            spans_to_update.append(span)
        
        # Add the agent span (the one that gets exported to Jaeger/OpenSearch)
        if agent_span and agent_span.is_recording():
            spans_to_update.append(agent_span)
            logger.debug(f"Adding attributes to both call_llm span and agent span")
        
        for target_span in spans_to_update:
            target_span.set_attribute("security.scan.enabled", True)
            target_span.set_attribute("security.scan.prompt_length", len(prompt))
            target_span.set_attribute("security.scan.model", model_name)
            
            target_span.set_attribute("security.scan.prompt", prompt)
            target_span.set_attribute("llm.prompt", prompt)
            if conversation_id:
                target_span.set_attribute(AttributeNames.GEN_AI_CONVERSATION_ID, conversation_id)
            
            # Extract and add comprehensive client data (IP, user agent, browser ID, device info, etc.)
            try:
                from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data, _add_client_data_to_span
                client_data = extract_comprehensive_client_data()
                
                # Add all client data to span attributes (includes parsed browser/device/OS info)
                _add_client_data_to_span(target_span, client_data)
            except Exception as e:
                logger.debug(f"Could not extract client data in ADK callback: {e}")
        
        try:
            if span and span.is_recording():
                span.add_event("security_scan_started", {"prompt_length": len(prompt)})
            
            # Call the scanner function with agent_identifier
            metadata = {"agent_identifier": agent_identifier} if agent_identifier else {}
            scan_results = _scan_prompt(
                prompt=prompt,
                api_endpoint=api_endpoint,
                model_name=model_name,
                conversation_id=conversation_id,
                api_key=api_key,
                timeout=timeout,
                metadata=metadata
            )
            
            # Get scan duration from results
            scan_duration = scan_results.get("scan_metadata", {}).get("duration_ms", 0)
            
            if span and span.is_recording():
                span.set_attribute("security.scan.duration_ms", scan_duration)
                span.set_attribute("security.scan.api_status", 200)
                
            # Extract detection results from raw API response
            detection_results = scan_results.get("detection_results", {})
            
            # Check if any threats were found
            threats_found = []
            for threat_type, result_data in detection_results.items():
                if result_data.get("result") == "MATCH_FOUND":
                    threats_found.append(threat_type)
            
            # Extract categories
            out_of_scope = scan_results.get("OutofScopeAnalysis", {})
            detected_categories = out_of_scope.get("detected_categories", [])
            
            # Add attributes to ALL spans (both call_llm and agent span)
            for target_span in spans_to_update:
                if target_span and target_span.is_recording():
                    target_span.set_attribute("security.threats_found", len(threats_found) > 0)
                    target_span.set_attribute("security.threat_count", len(threats_found))
                    
                    if threats_found:
                        target_span.set_attribute("security.threat_types", ",".join(threats_found))
                        # Conversation-level attributes so dashboard can mark conversation as threat (red)
                        target_span.set_attribute("security.conversation.threat_detected", True)
                        target_span.set_attribute("security.conversation.threat_count", len(threats_found))
                        target_span.set_attribute("security.conversation.severity", "critical")
                    
                    if detected_categories:
                        # CRITICAL FIX: Handle categories that don't have "/" separator
                        category_names = []
                        for c in detected_categories[:3]:
                            category = c.get("category", "")
                            if category:
                                # Split by "/" if present, otherwise use full category name
                                parts = category.split("/")
                                if len(parts) > 1:
                                    category_names.append(parts[1])
                                else:
                                    category_names.append(category)
                        if category_names:
                            target_span.set_attribute("security.categories", ",".join(category_names))
                        target_span.set_attribute("security.category_count", len(detected_categories))
                    
                    # CRITICAL: Store scan results for ALL prompts (with or without threats)
                    # This ensures security scan metadata is always available in OpenSearch
                    import json
                    try:
                        scan_results_json = json.dumps(scan_results)
                        # Store as attribute (truncate if too large for span attributes)
                        if len(scan_results_json) <= 4000:
                            target_span.set_attribute("security.scan.full_results", scan_results_json)
                        else:
                            # If too large, store summary
                            summary = {
                                "detection_results": detection_results,
                                "category_count": len(detected_categories),
                                "top_categories": detected_categories[:3]
                            }
                            target_span.set_attribute("security.scan.full_results", json.dumps(summary))
                        logger.debug(f"Stored prompt scan results in span (threats: {len(threats_found)})")
                    except Exception as e:
                        logger.warning(f"Could not serialize scan results: {e}")
                    
                    target_span.add_event("security_scan_completed", {
                        "threats": len(threats_found),
                        "categories": len(detected_categories)
                    })
            
            logger.info(
                f"Security scan completed: {len(threats_found)} threats, "
                f"{len(detected_categories)} categories"
            )
            
            # Call user's callback if provided
            should_allow = True
            if on_scan_complete:
                try:
                    # REMOVED: Debug print statements - not needed for production
                    # Reason: These print statements were for debugging during development.
                    # Production code should use logger instead. Keeping logger.info for error tracking.
                    # print(f"\n🔍 Calling user's security policy callback...")
                    # print(f"   Prompt: {prompt[:50]}...")
                    # print(f"   Scan results keys: {list(scan_results.keys())}")
                    
                    should_allow = on_scan_complete(prompt, scan_results, "prompt")
                    
                    # REMOVED: Debug print statement
                    # print(f"   User callback returned: allow={should_allow}")
                    logger.info(f"User callback returned: allow={should_allow}")
                    
                    # Add decision to ALL spans (both call_llm and agent span)
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.set_attribute("security.user_decision", "allow" if should_allow else "block")
                            if not should_allow:
                                target_span.set_attribute("security.blocked_by", "user_callback")
                
                except Exception as callback_error:
                    logger.error(f"Error in user callback: {callback_error}", exc_info=True)
                    # Default to allowing on callback error (fail open)
                    should_allow = True
                    if span and span.is_recording():
                        span.set_attribute("security.callback_error", str(callback_error))
            
            if not should_allow:
                # BLOCK THE REQUEST by returning an error response
                # Create a user-friendly error message based on detected threats
                threat_messages = {
                    "CSAM": "inappropriate content involving minors",
                    "Dangerous": "dangerous or harmful content",
                    "HateSpeech": "hate speech or discriminatory content",
                    "Harassment": "harassing or bullying content",
                    "SexualExplicit": "sexually explicit content",
                    "PIandJailbreak": "an attempt to bypass security controls",
                    "MaliciousURIs": "potentially malicious links",
                    "SenstiveData": "sensitive personal information"
                }
                
                # Get friendly descriptions for detected threats
                detected_issues = [threat_messages.get(t, t.lower()) for t in threats_found]
                
                # Handle no-threat, single-threat, multi-threat scenarios gracefully
                if len(detected_issues) == 0:
                    issues_text = "content that violates security policy"
                elif len(detected_issues) == 1:
                    issues_text = detected_issues[0]
                else:
                    issues_text = ", ".join(detected_issues[:-1]) + f" and {detected_issues[-1]}"
                
                error_message = (
                    f"I'm sorry, but I cannot assist with this request. "
                    f"The system detected {issues_text}. "
                    f"This system is not allowed to answer questions of this nature."
                )
                
                logger.warning(f"User callback blocked LLM call: {error_message}")
                
                if span and span.is_recording():
                    span.set_status(Status(StatusCode.ERROR, "Security violation detected"))
                    span.add_event("security_request_blocked", {
                        "threat_types": ",".join(threats_found)
                    })
                
                # Return an LlmResponse to block the request
                return _create_error_response(error_message)
            
            # Allow the request
            if span and span.is_recording():
                span.set_attribute("security.scan.status", "completed")
                span.set_status(Status(StatusCode.OK))
            
            return None  # None means "proceed with normal LLM call"
        
        except Exception as e:
            error_msg = f"Scanning error: {str(e)}"
            logger.error(error_msg, exc_info=True)
            
            if span and span.is_recording():
                span.set_attribute("security.scan.status", "error")
                span.set_attribute("security.scan.error", error_msg)
            
            # Fail open - allow on errors
            return None
    
    # Use config default if scan_responses is None
    if scan_responses is None:
        import os
        scan_responses = os.getenv("SAF3AI_SCAN_RESPONSES", "true").lower() == "true"
    
    # Get response capture setting
    import os
    capture_responses = os.getenv("SAF3AI_CAPTURE_RESPONSES", "true").lower() == "true"
    
    # Create after_model_callback if response scanning is enabled
    if scan_responses:
        def response_security_callback(*, callback_context: CallbackContext, llm_response: LlmResponse) -> Optional[LlmResponse]:
            """
            ADK after_model_callback that scans LLM responses for security threats.
            
            Args:
                callback_context: CallbackContext from ADK
                llm_response: The LLM response that was generated
            
            Returns:
                None to allow the response, or a modified LlmResponse to block it
            """
            # CRITICAL: Set single conversation_id first so this callback and all spans use one ID
            _ensure_single_conversation_id_at_callback_start(callback_context)
            # Get the current span
            span = trace.get_current_span()
            
            # Extract response text
            response_text = _extract_response_from_llm_response(llm_response)
            if not response_text:
                logger.warning(
                    "No response text extracted from LlmResponse - skipping response scan. "
                    f"LlmResponse type: {type(llm_response)}, has candidates: {hasattr(llm_response, 'candidates')}, "
                    f"has content: {hasattr(llm_response, 'content')}"
                )
                return None
            
            # Log extracted response length for debugging
            logger.debug(f"Extracted response text length: {len(response_text)} chars")
            
            # Get model name and conversation ID
            model_name = "unknown"
            conversation_id = _extract_conversation_id(callback_context, span)
            
            # Add response scan attributes to current span AND agent span
            # Get the agent span (the one that gets exported)
            agent_span = None
            try:
                from saf3ai_sdk.instrumentation.adk_instrumentation import _current_agent_span
                agent_span = getattr(_current_agent_span, 'span', None)
            except (ImportError, AttributeError):
                # Gracefully handle if instrumentation module is not available
                pass
            
            spans_to_update = []
            if span and span.is_recording():
                spans_to_update.append(span)
            
            # Add the agent span
            if agent_span and agent_span.is_recording():
                spans_to_update.append(agent_span)
            
            for target_span in spans_to_update:
                target_span.set_attribute("security.response_scan.enabled", True)
                target_span.set_attribute("security.response_scan.length", len(response_text))
                
                # Capture response text if enabled (default: enabled)
                if capture_responses and response_text:
                    target_span.set_attribute("llm.response", response_text)
                    target_span.set_attribute("llm.response_length", len(response_text))
                
                # Extract and add comprehensive client data (IP, user agent, browser ID, etc.)
                try:
                    from saf3ai_sdk.core.request_utils import extract_comprehensive_client_data
                    client_data = extract_comprehensive_client_data()
                    
                    # Add all client data to span attributes - STANDARD OTEL FORMAT ONLY (removed duplicates)
                    if client_data.get('user_agent'):
                        target_span.set_attribute("http.user_agent", client_data['user_agent'])  # Standard OTEL only
                    
                    if client_data.get('ip_address'):
                        target_span.set_attribute("client.ip", client_data['ip_address'])  # Standard OTEL only
                    
                    if client_data.get('browser_id'):
                        target_span.set_attribute("client.id", client_data['browser_id'])  # Standard OTEL only
                    
                    # Add additional browser metadata - STANDARD OTEL FORMAT ONLY
                    for key in ['accept_language', 'accept_encoding', 'accept', 'referer', 'origin',
                               'sec_ch_ua_platform', 'sec_ch_ua_mobile', 'sec_fetch_site', 'sec_fetch_mode']:
                        if client_data.get(key):
                            target_span.set_attribute(f"http.{key}", client_data[key])
                except Exception as e:
                    logger.debug(f"Could not extract client data in ADK response callback: {e}")
            
            try:
                if span and span.is_recording():
                    span.add_event("security_response_scan_started", {"response_length": len(response_text)})
                
                # Scan the response using scanner module
                from saf3ai_sdk.scanner import scan_response as _scan_response
                
                metadata = {"agent_identifier": agent_identifier} if agent_identifier else {}
                scan_results = _scan_response(
                    response=response_text,
                    api_endpoint=api_endpoint,
                    model_name=model_name,
                    conversation_id=conversation_id,
                    api_key=api_key,
                    timeout=timeout,
                    metadata=metadata
                )
                
                # Extract detection results
                detection_results = scan_results.get("detection_results", {})
                threats_found = [k for k, v in detection_results.items() if v.get("result") == "MATCH_FOUND"]
                has_threats = len(threats_found) > 0
                
                # Add telemetry to ALL spans (both call_llm and agent span)
                # CRITICAL: Prioritize agent_span to ensure all data is in the exported span
                for target_span in spans_to_update:
                    if target_span and target_span.is_recording():
                        target_span.set_attribute("security.response_threats_found", has_threats)
                        target_span.set_attribute("security.response_threat_count", len(threats_found))
                        if threats_found:
                            target_span.set_attribute("security.response_threat_types", ",".join(threats_found))
                            # Conversation-level attributes so dashboard can mark conversation as threat (red)
                            target_span.set_attribute("security.conversation.threat_detected", True)
                            target_span.set_attribute("security.conversation.threat_count", len(threats_found))
                            target_span.set_attribute("security.conversation.severity", "critical")
                        
                        # SECURITY FEATURE: Store response text when threats are detected
                        # This enables security auditing and forensics for flagged responses
                        if has_threats and response_text:
                            target_span.set_attribute("security.response.threat_detected", True)
                            # Ensure response text is stored (may already be stored above, but ensure it's here too)
                            target_span.set_attribute("llm.response", response_text)
                            target_span.set_attribute("llm.response_length", len(response_text))
                            logger.debug(f"Stored response text due to detected threats: {', '.join(threats_found)}")
                
                # CRITICAL FIX: Ensure agent_span gets ALL response data, especially for normal responses
                # The agent_span is the primary span that gets exported to OpenSearch
                if agent_span and agent_span.is_recording():
                    # Ensure response text is stored in agent_span for ALL responses (not just threats)
                    # This was already done above, but we ensure it's definitely in agent_span
                    if capture_responses and response_text:
                        # Double-check response is in agent_span (may have been set above, but ensure it's there)
                        if not agent_span.attributes.get("llm.response"):
                            agent_span.set_attribute("llm.response", response_text)
                            agent_span.set_attribute("llm.response_length", len(response_text))
                            logger.debug(f"Ensured response text is stored in agent_span for OpenSearch export")
                    
                    # CRITICAL: Store scan results for ALL responses (with or without threats)
                    # This ensures security scan metadata is always available in OpenSearch
                    import json
                    try:
                        scan_results_json = json.dumps(scan_results)
                        if len(scan_results_json) <= 4000:
                            agent_span.set_attribute("security.response_scan.full_results", scan_results_json)
                        else:
                            # If too large, store summary
                            out_of_scope = scan_results.get("OutofScopeAnalysis", {})
                            detected_categories = out_of_scope.get("detected_categories", [])
                            summary = {
                                "detection_results": detection_results,
                                "category_count": len(detected_categories),
                                "top_categories": detected_categories[:3]
                            }
                            agent_span.set_attribute("security.response_scan.full_results", json.dumps(summary))
                        logger.debug(f"Stored response scan results in agent_span (threats: {len(threats_found)})")
                    except Exception as e:
                        logger.warning(f"Could not serialize response scan results: {e}")
                
                # Call user's callback if provided
                should_allow = True
                if on_scan_complete:
                    try:
                        should_allow = on_scan_complete(response_text, scan_results, "response")
                        logger.info(f"User callback for response: allow={should_allow}")
                        
                        # Add decision to ALL spans
                        for target_span in spans_to_update:
                            if target_span and target_span.is_recording():
                                target_span.set_attribute("security.response_user_decision", "allow" if should_allow else "block")
                    except Exception as e:
                        logger.error(f"Error in response callback: {e}", exc_info=True)
                        should_allow = True  # Fail open
                
                if not should_allow:
                    # Block the response
                    error_message = (
                        f"🚫 Security Violation: The generated response contains security concerns and cannot be shown. "
                        f"Detected: {', '.join(threats_found)}."
                    )
                    logger.warning(f"Response blocked: {error_message}")
                    
                    if span and span.is_recording():
                        span.set_status(Status(StatusCode.ERROR, "Response security violation"))
                    
                    return _create_error_response(error_message)
                
                return None  # Allow the response
            
            except Exception as e:
                logger.error(f"Error scanning response: {e}", exc_info=True)
                return None  # Fail open
        
        return (security_callback, response_security_callback)
    
    return security_callback


def _extract_prompt_from_request(llm_request: "LlmRequest") -> str:
    """
    Extract the LATEST USER MESSAGE from an LlmRequest.
    
    ADK sends the full conversation history, but we only want to scan
    the most recent user input.
    """
    try:
        # Try to get contents from the request
        if hasattr(llm_request, 'contents'):
            contents = llm_request.contents
            
            if isinstance(contents, str):
                return contents
            
            elif isinstance(contents, list):
                # ADK sends conversation as list of Content objects
                # Each has a 'role' (user/model) and 'parts' (text content)
                # We want the LAST user message
                
                user_messages = []
                for item in contents:
                    # Check if this is a user message
                    role = getattr(item, 'role', None)
                    
                    if role == 'user':
                        # Extract text from this user message
                        if hasattr(item, 'parts'):
                            for part in item.parts:
                                if hasattr(part, 'text') and part.text:
                                    user_messages.append(part.text)
                        elif hasattr(item, 'text') and item.text:
                            user_messages.append(item.text)
                
                # Return the LAST user message (most recent)
                if user_messages:
                    latest_user_message = user_messages[-1]
                    if latest_user_message:
                        logger.debug(f"Extracted latest user message: {latest_user_message[:50]}...")
                        return latest_user_message
                
                # Fallback: concatenate everything if we can't find role
                prompt_parts = []
                for item in contents:
                    if isinstance(item, str):
                        prompt_parts.append(item)
                    elif hasattr(item, 'text') and item.text:
                        prompt_parts.append(item.text)
                    elif hasattr(item, 'parts'):
                        for part in item.parts:
                            if hasattr(part, 'text') and part.text:
                                prompt_parts.append(part.text)
                
                # Filter out None values before joining
                prompt_parts = [p for p in prompt_parts if p is not None]
                return "\n".join(prompt_parts) if prompt_parts else ""
        
        # Fallback to string representation
        return str(llm_request)
    except Exception as e:
        logger.error(f"Error extracting prompt: {e}", exc_info=True)
        return ""


def _extract_response_from_llm_response(llm_response: LlmResponse) -> str:
    """
    Extract ONLY the text content from an LlmResponse, not metadata.
    
    ADK responses expose candidates[].content.parts[].text. We walk that
    structure and concatenate any string parts we find. If nothing is found,
    we return an empty string (never str(llm_response)).
    """
    try:
        text_parts = []
        
        # Single robust path: candidates -> content -> parts -> text
        if hasattr(llm_response, "candidates") and llm_response.candidates:
            for candidate in llm_response.candidates:
                content = getattr(candidate, "content", None)
                if not content:
                    continue
                
                parts = getattr(content, "parts", None)
                if not parts:
                    continue
                
                for part in parts:
                    text_value = getattr(part, "text", None)
                    if not text_value:
                        continue
                    
                    # Only extract if it's a string, not an object
                    if isinstance(text_value, str):
                        text_value = text_value.strip()
                        if text_value:  # Only add non-empty strings
                            text_parts.append(text_value)
                    else:
                        # If part.text is not a string, try to convert it
                        try:
                            converted = str(text_value).strip()
                            if converted:
                                text_parts.append(converted)
                        except Exception:
                            logger.debug(f"Skipping non-string part.text of type: {type(text_value)}")
                
                if text_parts:
                    result = "\n".join(text_parts)
                    logger.debug(f"Extracted {len(text_parts)} text parts from LlmResponse, total length: {len(result)} chars")
                    return result
        
        # Try alternative path: direct content -> parts (if no candidates)
        if hasattr(llm_response, 'content') and llm_response.content:
            content = llm_response.content
            if hasattr(content, 'parts') and content.parts:
                for part in content.parts:
                    text_value = getattr(part, 'text', None)
                    if text_value:
                        if isinstance(text_value, str):
                            text_value = text_value.strip()
                            if text_value:
                                text_parts.append(text_value)
                        else:
                            try:
                                converted = str(text_value).strip()
                                if converted:
                                    text_parts.append(converted)
                            except Exception:
                                pass
                
                if text_parts:
                    result = "\n".join(text_parts)
                    logger.debug(f"Extracted {len(text_parts)} text parts from LlmResponse.content, total length: {len(result)} chars")
                    return result
        
        # No text found - return empty string (never return str(llm_response))
        logger.warning(
            "No text found in LlmResponse. "
            f"Has candidates: {hasattr(llm_response, 'candidates')}, "
            f"has content: {hasattr(llm_response, 'content')}, "
            f"response type: {type(llm_response)}"
        )
        return ""
    except Exception as e:
        logger.error(f"Error extracting response text: {e}", exc_info=True)
        return ""


def _ensure_single_conversation_id_at_callback_start(callback_context: "CallbackContext") -> Optional[str]:
    """
    Call at the very start of every ADK security callback (before + after) so that
    one conversation uses a single conversation_id. Prevents multiple conversation IDs
    for the same session (e.g. one for root, one for tool calls, one for threat scans).
    """
    try:
        from saf3ai_sdk.core.tracer import get_conversation_id_unified, set_conversation_id_unified
        existing = get_conversation_id_unified()
        if existing and isinstance(existing, str) and existing.startswith("adk_session_"):
            return existing
        if existing:
            # Overwrite non-persistent (e.g. UUID) with persistent so all spans share one ID
            pass
        try:
            from saf3ai_sdk.instrumentation.adk_instrumentation import _get_or_create_persistent_session_id
            persistent_id = _get_or_create_persistent_session_id()
            if persistent_id:
                set_conversation_id_unified(persistent_id, source="adk_callback_unified", force=True)
                logger.debug(f"[ADK Callback] Set single conversation_id at callback start: {persistent_id}")
                return persistent_id
        except (ImportError, AttributeError):
            pass
        # Fallback: use callback_context.state so we reuse same ID within same session
        state = getattr(callback_context, "state", None)
        if state is not None and hasattr(state, "get"):
            stored = state.get("saf3ai_conversation_id")
            if stored:
                set_conversation_id_unified(str(stored), source="adk_callback_state", force=False)
                return str(stored)
        session = getattr(callback_context, "session", None)
        if session is not None:
            sid = getattr(session, "id", None) or getattr(session, "session_id", None)
            if sid and isinstance(sid, str) and sid.startswith("adk_session_"):
                if state is not None and hasattr(state, "__setitem__"):
                    state["saf3ai_conversation_id"] = sid
                set_conversation_id_unified(sid, source="adk_callback_session", force=True)
                return sid
        return get_conversation_id_unified()
    except Exception as e:
        logger.debug(f"[ADK Callback] ensure_single_conversation_id: {e}")
    return None


def _extract_conversation_id(ctx: CallbackContext, span) -> Optional[str]:
    """
    Extract conversation ID from ADK context or span.
    
    CRITICAL: For ADK we MUST use the same conversation_id as instrumentation
    (adk_session_xxx / persistent_session_id). We must NOT set ctx.session.id
    (UUID) into the unified store, or spans split: one tab with adk_session (1 span),
    others with UUID (many spans). So we always prefer/use the instrumentation's
    persistent session ID when none exists.
    
    UNIFIED PRIORITY ORDER:
    1. Existing conversation_id from unified helper (prevents duplicates)
    2. ADK instrumentation persistent_session_id (adk_session_xxx) - single ID for all spans
    3. None (instrumentation will set)
    """
    try:
        # CRITICAL: Ensure single conversation ID is set at callback entry (so all spans use it)
        conv_id = _ensure_single_conversation_id_at_callback_start(ctx)
        if conv_id:
            return conv_id
        # Legacy path: Check existing conversation_id FIRST - prevents duplicates
        from saf3ai_sdk.core.tracer import get_conversation_id_unified, set_conversation_id_unified
        existing_conv_id = get_conversation_id_unified()
        # Only use existing if it is our persistent ID (adk_session_xxx), never ADK's session UUID
        if existing_conv_id and isinstance(existing_conv_id, str) and existing_conv_id.startswith("adk_session_"):
            logger.debug(f"[ADK Callback] Using existing conversation_id: {existing_conv_id}")
            return existing_conv_id
        if existing_conv_id:
            logger.debug(f"[ADK Callback] Ignoring non-persistent conversation_id (use adk_session_xxx): {existing_conv_id[:20]}...")

        # CRITICAL: Do NOT set ctx.session.id (UUID) - it creates a second conversation ID.
        # Use the same ID as instrumentation: persistent_session_id (adk_session_xxx).
        try:
            from saf3ai_sdk.instrumentation.adk_instrumentation import _get_or_create_persistent_session_id
            persistent_id = _get_or_create_persistent_session_id()
            if persistent_id:
                # Force overwrite if existing ID was a UUID (stray from ADK session) so all spans use adk_session_xxx
                set_conversation_id_unified(persistent_id, source="adk_callback_persistent", force=True)
                logger.debug(f"[ADK Callback] Using instrumentation persistent_session_id as conversation_id: {persistent_id}")
                return persistent_id
        except (ImportError, AttributeError):
            pass

        # CRITICAL: Do NOT use ctx.session.id (UUID) as fallback - it will create wrong conversation IDs
        # Let the root agent instrumentation set the correct conversation_id instead
        logger.debug("[ADK Callback] No conversation_id found, will be set by root agent instrumentation")
        return None
    except Exception as e:
        logger.debug(f"[ADK Callback] Could not extract conversation ID: {e}")

    return None


def _create_error_response(error_message: str) -> LlmResponse:
    """Create an LlmResponse containing an error message."""
    try:
        from google.adk.models.llm_response import LlmResponse
        from google.genai import types
        
        # Create a response with the error message
        # LlmResponse has 'content' field, not 'candidates'
        response = LlmResponse(
            content=types.Content(
                parts=[types.Part(text=error_message)],
                role="model"
            ),
            turn_complete=True
        )
        return response
    except Exception as e:
        logger.error(f"Error creating error response: {e}", exc_info=True)
        # If we can't create a proper response, return None (allow the request)
        return None

