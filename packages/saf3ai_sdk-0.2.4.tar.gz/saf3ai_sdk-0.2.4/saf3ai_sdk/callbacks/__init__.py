"""
Callbacks module for Saf3AI SDK.

This module contains all callback implementations for different frameworks.
"""

# Import main callback classes and functions
from .callbacks import (
    LLMSecurityCallback,
    LLMCallbackManager,
    get_callback_manager,
    register_security_callback
)

# Lazy imports for framework-specific callbacks
# These are only imported when needed to avoid unnecessary dependencies
# DO NOT import adk_callbacks or langchain_callbacks at module level
# to prevent ADK/LangChain availability checks when using 'custom' framework

__all__ = [
    "LLMSecurityCallback",
    "LLMCallbackManager",
    "get_callback_manager",
    "register_security_callback",
]

# Re-export for backward compatibility (lazy imports only)
# Users can still import from saf3ai_sdk.callbacks directly
# But we don't import adk_callbacks/langchain_callbacks here to avoid
# triggering availability checks when framework is 'custom'
