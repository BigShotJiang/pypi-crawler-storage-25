"""
CrewAI framework adapter.

CrewAI is built on top of LangChain, so it can leverage LangChain's callback system.
This adapter provides CrewAI-specific integration.
"""

import logging
from typing import Optional, Callable

from .base import BaseFrameworkAdapter

logger = logging.getLogger(__name__)


class CrewAIFrameworkAdapter(BaseFrameworkAdapter):
    """
    Framework adapter for CrewAI.
    
    Since CrewAI is built on LangChain, it can use LangChain's callback system.
    This adapter provides CrewAI-specific integration points.
    
    Example Usage:
        ```python
        from saf3ai_sdk import init, create_framework_security_callbacks
        from crewai import Agent, Task, Crew
        
        # Initialize SDK - it will auto-detect CrewAI
        init(
            agent_id='my-crewai-agent-abc123',
            api_key='your-api-key',
            safeai_collector_agent='https://collector.example.com'
        )
        
        # Create callbacks - framework is auto-detected, no need to specify
        callback = create_framework_security_callbacks(
            api_endpoint='http://localhost:8082',
            agent_identifier='my-crewai-agent-abc123'
        )
        
        # CrewAI uses LangChain under the hood, so LangChain callbacks work
        # The callback can be added to CrewAI agents/tasks
        ```
    """
    
    def get_framework_name(self) -> str:
        return "crewai"
    
    def create_prompt_callback(self):
        """
        Create CrewAI-specific callback for prompt scanning.
        
        Uses CrewAI callbacks which leverage LangChain's callback system.
        
        Returns:
            CrewAI-compatible BaseCallbackHandler instance
        """
        try:
            # Import CrewAI callback (uses LangChain under the hood)
            from saf3ai_sdk.callbacks.crewai_callbacks import create_security_callback
            
            return create_security_callback(
                api_endpoint=self.api_endpoint,
                api_key=self.api_key,
                timeout=self.timeout,
                on_scan_complete=self.on_scan_complete,
                scan_responses=False,  # Only prompt scanning for prompt callback
                agent_identifier=self.agent_identifier
            )
        
        except ImportError:
            logger.warning("CrewAI callbacks not available - CrewAI adapter requires CrewAI and LangChain")
            return None
    
    def create_response_callback(self):
        """
        Create CrewAI-specific callback for response scanning.
        
        Returns:
            CrewAI-compatible BaseCallbackHandler instance
        """
        try:
            # Import CrewAI callback (uses LangChain under the hood)
            from saf3ai_sdk.callbacks.crewai_callbacks import create_security_callback
            
            return create_security_callback(
                api_endpoint=self.api_endpoint,
                api_key=self.api_key,
                timeout=self.timeout,
                on_scan_complete=self.on_scan_complete,
                scan_responses=True,  # Enable response scanning
                agent_identifier=self.agent_identifier
            )
        
        except ImportError:
            logger.warning("CrewAI callbacks not available - CrewAI adapter requires CrewAI and LangChain")
            return None
    
    def create_callbacks(self, scan_responses: bool = True):
        """
        Create a CrewAI callback with optional response scanning.
        
        Args:
            scan_responses: If True, also creates response callback
        
        Returns:
            CrewAI-compatible BaseCallbackHandler instance
        """
        try:
            from saf3ai_sdk.callbacks.crewai_callbacks import create_security_callback

            return create_security_callback(
                api_endpoint=self.api_endpoint,
                api_key=self.api_key,
                timeout=self.timeout,
                on_scan_complete=self.on_scan_complete,
                scan_responses=scan_responses,
                agent_identifier=self.agent_identifier,
            )
        except ImportError:
            logger.warning("CrewAI callbacks not available - CrewAI adapter requires CrewAI and LangChain")
            return None