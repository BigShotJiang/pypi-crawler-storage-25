"""
Framework-specific integrations for Saf3AI SDK.

Supported Frameworks:
- ADK (Google Agent Development Kit)
- LangChain
- CrewAI
- REST API (Custom agents)
"""

from .base import BaseFrameworkAdapter

__all__ = ["BaseFrameworkAdapter", "get_framework_adapter", "list_supported_frameworks"]

FRAMEWORK_ADAPTERS = {}


def register_framework_adapter(framework_name: str, adapter_class):
    """Register a framework adapter."""
    FRAMEWORK_ADAPTERS[framework_name.lower()] = adapter_class


def get_framework_adapter(framework_name: str):
    """Get a framework adapter by name."""
    return FRAMEWORK_ADAPTERS.get(framework_name.lower())


def list_supported_frameworks():
    """List all registered framework adapters."""
    return list(FRAMEWORK_ADAPTERS.keys())


try:
    from .adk import ADKFrameworkAdapter
    register_framework_adapter('adk', ADKFrameworkAdapter)
    register_framework_adapter('google-adk', ADKFrameworkAdapter)
except ImportError:
    pass

try:
    from .langchain import LangChainFrameworkAdapter
    register_framework_adapter('langchain', LangChainFrameworkAdapter)
except ImportError:
    pass

try:
    from .crewai_adapter import CrewAIFrameworkAdapter
    register_framework_adapter('crewai', CrewAIFrameworkAdapter)
    register_framework_adapter('crew-ai', CrewAIFrameworkAdapter)
except ImportError:
    pass

try:
    from .rest_adapter import RESTAPIFrameworkAdapter
    register_framework_adapter('rest', RESTAPIFrameworkAdapter)
    register_framework_adapter('rest-api', RESTAPIFrameworkAdapter)
    register_framework_adapter('generic', RESTAPIFrameworkAdapter)
    register_framework_adapter('custom', RESTAPIFrameworkAdapter)
except ImportError:
    pass
