# -*- coding: utf-8 -*-
"""
川流/UnendingX CLI 单元测试

覆盖：format.py 格式化工具、config.py 配置管理（mock）、client.py 基本请求构造

运行：
    pytest cli/tests/ -v
"""
import sys
from pathlib import Path

# 确保 cli/ 在路径中
CLI_ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(CLI_ROOT))

# ── format.py 测试 ────────────────────────────────────────
def test_print_table_headers_only():
    """print_table 接收空行列表时应正常返回（不抛异常）"""
    from unendingx.format import print_table
    # 不抛异常即可
    print_table(["名称", "类型", "状态"], [], title="测试表格")


def test_print_table_with_rows():
    """print_table 带数据行时应正常返回"""
    from unendingx.format import print_table
    rows = [
        ["Agent-Alpha", "agent", "active"],
        ["Agent-Beta", "agent", "inactive"],
    ]
    print_table(["名称", "类型", "状态"], rows, title="代理列表")


def test_print_json_basic():
    """print_json 接收字典时应正常返回"""
    from unendingx.format import print_json
    data = {"id": "123", "name": "TestAgent", "active": True}
    print_json(data)


def test_print_json_list():
    """print_json 接收列表时应正常返回"""
    from unendingx.format import print_json
    data = [{"id": "1"}, {"id": "2"}]
    print_json(data)


def test_print_error():
    """print_error 应正常返回（不抛异常）"""
    from unendingx.format import print_error
    print_error("测试错误信息")


def test_print_success():
    """print_success 应正常返回（不抛异常）"""
    from unendingx.format import print_success
    print_success("测试成功信息")


def test_print_warning_not_exists():
    """print_warning 目前不存在于 format.py"""
    import pytest
    pytest.skip("print_warning not implemented yet")


# ── config.py 测试（mock 环境）────────────────────────────
def test_token_expiry_check(monkeypatch, tmp_path):
    """is_token_expired 正确识别过期/未过期 token（使用时间戳）"""
    import time
    import json
    from unendingx import config as cfg_mod

    # Monkey-patch CONFIG_FILE to use temp location
    cfg_file = tmp_path / "config.json"
    monkeypatch.setattr(cfg_mod, "CONFIG_FILE", cfg_file)

    # 写一个未过期的 token（当前时间 + 3600秒）
    cfg = {
        "agent_id": "test-001",
        "access_token": "tok_valid",
        "refresh_token": "refresh",
        "base_url": "http://localhost:8000",
        "device_id": "dev-001",
        "token_expires_at": time.time() + 3600,
    }
    cfg_mod.save(cfg)
    assert not cfg_mod.is_token_expired()

    # 写一个已过期的 token（1秒前过期）
    cfg["token_expires_at"] = time.time() - 1
    cfg_mod.save(cfg)
    assert cfg_mod.is_token_expired()


def test_update_access_token(monkeypatch, tmp_path):
    """update_access_token 应正确更新 token"""
    import time
    from unendingx import config as cfg_mod

    cfg_file = tmp_path / "config.json"
    monkeypatch.setattr(cfg_mod, "CONFIG_FILE", cfg_file)

    cfg = {
        "agent_id": "test-001",
        "access_token": "old_token",
        "refresh_token": "old_refresh",
        "base_url": "http://localhost:8000",
        "device_id": "dev-001",
        "token_expires_at": time.time() - 10,
    }
    cfg_mod.save(cfg)
    cfg_mod.update_access_token("new_access_token", "new_refresh_token", 7200)
    loaded = cfg_mod.load()
    assert loaded["access_token"] == "new_access_token"
    assert loaded["refresh_token"] == "new_refresh_token"


# ── client.py 测试 ───────────────────────────────────────
def test_api_client_base_url():
    """APIClient 正确使用 base_url"""
    from unendingx.client import APIClient
    client = APIClient("http://custom:9000")
    assert client.base_url == "http://custom:9000"


def test_api_client_default_url():
    """APIClient 使用默认 base_url"""
    from unendingx.client import APIClient
    client = APIClient()
    # 默认应为 http://localhost:8000
    assert "localhost" in client.base_url or "127.0.0.1" in client.base_url


# ── 集成冒烟：CLI 命令行入口可导入 ────────────────────────
def test_cli_module_import():
    """unendingx.cli 主模块应可正常导入"""
    from unendingx import cli as cli_module
    assert hasattr(cli_module, "cli")
    assert hasattr(cli_module, "_auto_register")


def test_gui_module_import():
    """unendingx_gui.cli 模块应可正常导入（若存在）"""
    try:
        from unendingx_gui import cli as gui_cli
        # gui_cli 是 cli.py 模块，验证其包含 gui 命令和 main 入口
        assert hasattr(gui_cli, "gui"), "gui/cli.py should have a 'gui' ClickCommand"
        assert hasattr(gui_cli, "main"), "gui/cli.py should have a 'main' entry point"
    except ImportError:
        pass  # GUI 可能未安装，跳过


if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main([__file__, "-v"]))
