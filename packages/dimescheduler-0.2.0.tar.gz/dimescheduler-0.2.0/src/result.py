from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx
from dimescheduler.errors import DimeSchedulerError, classify


@dataclass(frozen=True)
class Result:
    """Outcome of a Dime.Scheduler API call.

    Mirrors the openapi-fetch ``{ data, error, response }`` shape used by the
    JS SDK and the ``Result<T>`` type used by the .NET SDK. ``data`` holds the
    parsed JSON body on success, ``error`` holds the parsed JSON error body on
    a 4xx/5xx, and ``response`` is the underlying ``httpx.Response`` for cases
    where you need headers, status code, or the raw bytes.

    Use :meth:`raise_for_error` if you'd rather opt into typed exceptions than
    branch on :attr:`ok`.
    """

    data: Any
    error: Any
    response: httpx.Response

    @property
    def ok(self) -> bool:
        return self.response.is_success

    def raise_for_error(self) -> None:
        """Raise a typed :class:`DimeSchedulerError` if the call failed.

        Mirrors :meth:`httpx.Response.raise_for_status` but yields the right
        :class:`~dimescheduler.errors.DimeSchedulerError` subclass
        (:class:`~dimescheduler.errors.RateLimitError`,
        :class:`~dimescheduler.errors.NotFoundError`, …) so callers can write
        ``except RateLimitError`` instead of inspecting status codes.
        """

        if self.ok:
            return
        raise classify(self.response, self.error)

    def to_error(self) -> DimeSchedulerError | None:
        """Return the typed error for a failed call, or ``None`` on success.

        Useful when you want to inspect / branch on the error category without
        actually raising it.
        """

        if self.ok:
            return None
        return classify(self.response, self.error)
