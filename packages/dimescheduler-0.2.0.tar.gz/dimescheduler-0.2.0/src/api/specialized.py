from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from typing import Any

from dimescheduler.api.crud import CrudApi
from dimescheduler.dispatcher import UNSET, Dispatcher, TimeoutT, timeout_kw
from dimescheduler.result import Result


def _iso(value: datetime | str) -> str:
    return value if isinstance(value, str) else value.isoformat()


class AppointmentApi(CrudApi):
    def __init__(self, dispatcher: Dispatcher) -> None:
        super().__init__(dispatcher, "/appointment")

    def get(
        self,
        start_date: datetime | str,
        end_date: datetime | str,
        resources: list[str] | None = None,
        *,
        timeout: TimeoutT = UNSET,
    ) -> Result:
        return self._dispatcher.request(
            "GET",
            self._route,
            params={"startDate": _iso(start_date), "endDate": _iso(end_date), "resources": resources},
            **timeout_kw(timeout),
        )


class ResourceCapacityApi(CrudApi):
    def __init__(self, dispatcher: Dispatcher) -> None:
        super().__init__(dispatcher, "/resourceCapacity")

    def get(self, start: datetime | str, end: datetime | str, *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request(
            "GET",
            self._route,
            params={"start": _iso(start), "end": _iso(end)},
            **timeout_kw(timeout),
        )


class NotificationApi(CrudApi):
    def __init__(self, dispatcher: Dispatcher) -> None:
        super().__init__(dispatcher, "/notification")

    def get(
        self,
        page: int,
        limit: int,
        *,
        sort: str | None = None,
        group: str | None = None,
        filter: str | None = None,
        timeout: TimeoutT = UNSET,
    ) -> Result:
        return self._dispatcher.request(
            "GET",
            self._route,
            params={"page": page, "limit": limit, "sort": sort, "group": group, "filter": filter},
            **timeout_kw(timeout),
        )


class _ReadOnlyApi:
    def __init__(self, dispatcher: Dispatcher, route: str) -> None:
        self._dispatcher = dispatcher
        self._route = route

    def get_all(self, *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("GET", self._route, **timeout_kw(timeout))


class AppointmentDependencyApi(_ReadOnlyApi):
    def __init__(self, dispatcher: Dispatcher) -> None:
        super().__init__(dispatcher, "/appointmentDependency")


class CalendarApi(_ReadOnlyApi):
    def __init__(self, dispatcher: Dispatcher) -> None:
        super().__init__(dispatcher, "/calendar")


class ResourceTypeApi(_ReadOnlyApi):
    def __init__(self, dispatcher: Dispatcher) -> None:
        super().__init__(dispatcher, "/resourcetype")


class AppointmentFieldApi(_ReadOnlyApi):
    def __init__(self, dispatcher: Dispatcher) -> None:
        super().__init__(dispatcher, "/appointmentField")


class GeocodeApi:
    def __init__(self, dispatcher: Dispatcher) -> None:
        self._dispatcher = dispatcher

    def geocode(self, address: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/geocode", body=address, **timeout_kw(timeout))

    def geocode_text(self, address: str, country: str, *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request(
            "GET", "/geocode", params={"address": address, "country": country}, **timeout_kw(timeout)
        )


class OptimizationApi:
    def __init__(self, dispatcher: Dispatcher) -> None:
        self._dispatcher = dispatcher

    def field_service(self, request: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/optimization/fieldService", body=request, **timeout_kw(timeout))

    def professional_services(self, request: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request(
            "POST", "/optimization/professionalServices", body=request, **timeout_kw(timeout)
        )

    def daily_route(self, request: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/optimization/dailyRoute", body=request, **timeout_kw(timeout))


class RecommendationApi:
    def __init__(self, dispatcher: Dispatcher) -> None:
        self._dispatcher = dispatcher

    def get(self, request: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/recommendation", body=request, **timeout_kw(timeout))

    def scorers(self, *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("GET", "/recommendation/scorers", **timeout_kw(timeout))


class MessageApi:
    def __init__(self, dispatcher: Dispatcher) -> None:
        self._dispatcher = dispatcher

    def send(self, message: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/message", body=message, **timeout_kw(timeout))


class ConnectorApi:
    def __init__(self, dispatcher: Dispatcher) -> None:
        self._dispatcher = dispatcher

    def create(self, request: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/connector", body=request, **timeout_kw(timeout))


class UserApi:
    def __init__(self, dispatcher: Dispatcher) -> None:
        self._dispatcher = dispatcher

    def create(self, user: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/user", body=user, **timeout_kw(timeout))


class RecurringAppointmentApi:
    def __init__(self, dispatcher: Dispatcher) -> None:
        self._dispatcher = dispatcher

    def create(self, request: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/appointmentRecurring", body=request, **timeout_kw(timeout))

    def delete(self, request: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("DELETE", "/appointmentRecurring", body=request, **timeout_kw(timeout))


class ImportApi:
    def __init__(self, dispatcher: Dispatcher) -> None:
        self._dispatcher = dispatcher

    def run(self, payload: Mapping[str, Any] | list[Mapping[str, Any]], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/import", body=payload, **timeout_kw(timeout))

    def setup(self, payload: Mapping[str, Any], *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", "/import/setup", body=payload, **timeout_kw(timeout))
