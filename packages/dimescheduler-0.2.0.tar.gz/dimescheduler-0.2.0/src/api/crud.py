from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Union

from dimescheduler.dispatcher import UNSET, Dispatcher, TimeoutT, timeout_kw
from dimescheduler.result import Result

Entity = Mapping[str, Any]
EntityOrList = Union[Entity, Sequence[Entity]]


class CrudApi:
    """Generic CRUD client. Same call surface for every import-shaped entity.

    Mirrors the .NET ``CrudApi<T>`` class: ``create`` / ``update`` / ``delete``
    accept either a single entity (mapping) or a list of entities; ``get_all``
    issues a GET against the same route with optional query parameters.

    Every method accepts a kwarg-only ``timeout`` (the per-request cancellation
    analog): a float in seconds, an ``httpx.Timeout``, or ``None`` to wait
    indefinitely. Omit it to inherit the client-level timeout.
    """

    def __init__(self, dispatcher: Dispatcher, route: str) -> None:
        self._dispatcher = dispatcher
        self._route = route

    def create(self, entity: EntityOrList, *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("POST", self._route, body=entity, **timeout_kw(timeout))

    def update(self, entity: EntityOrList, *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("PUT", self._route, body=entity, **timeout_kw(timeout))

    def delete(self, entity: EntityOrList, *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("DELETE", self._route, body=entity, **timeout_kw(timeout))

    def get_all(self, query: dict[str, Any] | None = None, *, timeout: TimeoutT = UNSET) -> Result:
        return self._dispatcher.request("GET", self._route, params=query, **timeout_kw(timeout))
