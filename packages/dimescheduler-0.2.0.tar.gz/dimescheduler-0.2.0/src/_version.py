# Kept in sync with the [project] version field in pyproject.toml by the manual
# release workflow (.github/workflows/release.yml). Do not edit by hand.
__version__ = "0.2.0"
