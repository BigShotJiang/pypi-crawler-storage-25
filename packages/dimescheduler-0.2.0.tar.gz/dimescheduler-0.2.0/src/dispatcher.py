from __future__ import annotations

from typing import Any, Union

import httpx
from dimescheduler.result import Result

# Sentinel: distinguishes "caller didn't pass a timeout" (inherit the
# client-level value) from "caller explicitly passed None" (wait indefinitely).
# Exported so the API accessors can share it instead of defining their own.
UNSET: Any = object()
TimeoutT = Union[float, httpx.Timeout, None]


def timeout_kw(value: Any) -> dict[str, Any]:
    """Build a kwargs dict that forwards ``timeout`` only when the caller set it."""
    return {} if value is UNSET else {"timeout": value}


class Dispatcher:
    """Internal HTTP dispatcher used by every domain accessor.

    Wraps an ``httpx.Client`` and converts each call into a :class:`Result`.
    Never raises on non-2xx status — the caller inspects ``result.error`` or
    ``result.response.status_code`` and decides how to react.
    """

    def __init__(self, http: httpx.Client) -> None:
        self._http = http

    def request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        params: dict[str, Any] | None = None,
        timeout: Any = UNSET,
    ) -> Result:
        kwargs: dict[str, Any] = {}
        if body is not None:
            kwargs["json"] = body
        if params is not None:
            kwargs["params"] = _drop_none(params)
        if timeout is not UNSET:
            kwargs["timeout"] = timeout

        response = self._http.request(method, path, **kwargs)
        payload = _parse_json(response)

        if response.is_success:
            return Result(data=payload, error=None, response=response)
        return Result(data=None, error=payload, response=response)


def _parse_json(response: httpx.Response) -> Any:
    if not response.content:
        return None
    content_type = response.headers.get("content-type", "")
    if "json" not in content_type:
        return None
    try:
        return response.json()
    except ValueError:
        return None


def _drop_none(params: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in params.items() if v is not None}
