"""Typed exception hierarchy for Dime.Scheduler API failures.

The dispatcher does not raise these on its own — it surfaces failures via
:class:`~dimescheduler.result.Result`. Call :meth:`Result.raise_for_error` to
opt into idiomatic Python exception handling.
"""

from __future__ import annotations

import email.utils
from datetime import datetime, timezone
from typing import Any

import httpx


class DimeSchedulerError(Exception):
    """Base class for every typed error raised by the SDK.

    Pattern-match on the concrete subclass (:class:`RateLimitError`,
    :class:`NotFoundError`, …) to react to specific failure categories instead
    of inspecting status codes.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        body: Any = None,
        response: httpx.Response | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body
        self.response = response


class ValidationError(DimeSchedulerError):
    """400 / 422 — request body or query params failed server-side validation."""


class AuthenticationError(DimeSchedulerError):
    """401 — credentials are missing, malformed, or revoked."""


class AuthorizationError(DimeSchedulerError):
    """403 — credentials are valid but lack permission for the resource."""


class NotFoundError(DimeSchedulerError):
    """404 — the requested resource does not exist."""


class ConflictError(DimeSchedulerError):
    """409 — the request conflicts with the current state of the resource."""


class RateLimitError(DimeSchedulerError):
    """429 — rate limit exceeded.

    ``retry_after`` mirrors the server's ``Retry-After`` header (in seconds)
    when one was sent. Sleeping for that long before retrying is the
    documented recovery path.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        body: Any = None,
        response: httpx.Response | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(message, status_code=status_code, body=body, response=response)
        self.retry_after = retry_after


class ServerError(DimeSchedulerError):
    """5xx — server-side failure."""


class NetworkError(DimeSchedulerError):
    """Transport-level failure (DNS, TCP, TLS, timeout, etc.). No HTTP response was received."""

    def __init__(self, message: str, *, cause: BaseException | None = None) -> None:
        super().__init__(message, status_code=0, body=None, response=None)
        self.__cause__ = cause


def classify(response: httpx.Response, body: Any = None) -> DimeSchedulerError:
    """Build the most specific :class:`DimeSchedulerError` for ``response``.

    ``body`` is the parsed JSON payload (when present) — passed in by the
    dispatcher so we don't double-parse.
    """

    status = response.status_code
    message = _message_from(body, default=f"HTTP {status}")

    if status in (400, 422):
        return ValidationError(message, status_code=status, body=body, response=response)
    if status == 401:
        return AuthenticationError(message, status_code=status, body=body, response=response)
    if status == 403:
        return AuthorizationError(message, status_code=status, body=body, response=response)
    if status == 404:
        return NotFoundError(message, status_code=status, body=body, response=response)
    if status == 409:
        return ConflictError(message, status_code=status, body=body, response=response)
    if status == 429:
        return RateLimitError(
            message,
            status_code=status,
            body=body,
            response=response,
            retry_after=parse_retry_after(response.headers.get("retry-after")),
        )
    if 500 <= status < 600:
        return ServerError(message, status_code=status, body=body, response=response)
    return DimeSchedulerError(message, status_code=status, body=body, response=response)


def parse_retry_after(value: str | None) -> float | None:
    """Parse a ``Retry-After`` header value (seconds or HTTP-date) into seconds."""

    if not value:
        return None
    value = value.strip()
    try:
        return max(0.0, float(value))
    except ValueError:
        pass
    try:
        target = email.utils.parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    if target is None:
        return None
    if target.tzinfo is None:
        target = target.replace(tzinfo=timezone.utc)
    delta = (target - datetime.now(timezone.utc)).total_seconds()
    return max(0.0, delta)


def _message_from(body: Any, *, default: str) -> str:
    if isinstance(body, dict):
        for key in ("message", "error", "detail", "title"):
            value = body.get(key)
            if isinstance(value, str) and value:
                return value
    if isinstance(body, str) and body:
        return body
    return default
