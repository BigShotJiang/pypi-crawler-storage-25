from enum import Enum


class Environment(str, Enum):
    Test = "https://test.api.dimescheduler.com"
    Sandbox = "https://sandbox.api.dimescheduler.com"
    Production = "https://api.dimescheduler.com"
