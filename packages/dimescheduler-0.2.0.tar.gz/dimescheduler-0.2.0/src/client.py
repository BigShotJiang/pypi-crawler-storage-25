from __future__ import annotations

from typing import Any, Literal

import httpx
from dimescheduler._version import __version__
from dimescheduler.api.crud import CrudApi
from dimescheduler.api.specialized import (
    AppointmentApi,
    AppointmentDependencyApi,
    AppointmentFieldApi,
    CalendarApi,
    ConnectorApi,
    GeocodeApi,
    ImportApi,
    MessageApi,
    NotificationApi,
    OptimizationApi,
    RecommendationApi,
    RecurringAppointmentApi,
    ResourceCapacityApi,
    ResourceTypeApi,
    UserApi,
)
from dimescheduler.dispatcher import Dispatcher
from dimescheduler.environment import Environment
from dimescheduler.retry import RetryConfig, RetryTransport

USER_AGENT = f"dimescheduler-python/{__version__}"


class DimeSchedulerClient:
    """Domain-grouped client for the Dime.Scheduler HTTP API.

    Every entity hangs off a typed accessor (``client.categories``,
    ``client.appointments``, ``client.resources``, …) — the surface mirrors the
    .NET and JS SDKs 1:1 so cross-language code reads the same. CRUD-shaped
    entities expose ``create`` / ``update`` / ``delete`` / ``get_all``;
    specialized endpoints get purpose-built methods.
    """

    def __init__(
        self,
        api_key: str,
        environment: Environment = Environment.Production,
        *,
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        retry: RetryConfig | None | Literal[False] = None,
        transport: httpx.BaseTransport | None = None,
        **httpx_kwargs: Any,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")

        merged_headers: dict[str, str] = {
            "X-API-KEY": api_key,
            "User-Agent": USER_AGENT,
        }
        if headers:
            # Caller-supplied headers win, including a custom User-Agent.
            merged_headers.update(headers)

        effective_transport = (
            transport if retry is False else RetryTransport(config=retry, inner=transport)
        )

        self._http = httpx.Client(
            base_url=environment.value,
            headers=merged_headers,
            timeout=timeout,
            transport=effective_transport,
            **httpx_kwargs,
        )
        self._environment = environment
        d = Dispatcher(self._http)

        self.action_uris = CrudApi(d, "/actionUri")
        self.appointment_categories = CrudApi(d, "/appointmentCategory")
        self.appointment_contents = CrudApi(d, "/appointmentcontent")
        self.appointment_containers = CrudApi(d, "/appointmentContainer")
        self.appointment_field_values = CrudApi(d, "/appointmentFieldValue")
        self.appointment_importances = CrudApi(d, "/appointmentImportance")
        self.appointment_locked = CrudApi(d, "/appointmentLocked")
        self.appointment_planning_quantities = CrudApi(d, "/appointmentPlanningQuantity")
        self.appointment_time_markers = CrudApi(d, "/appointmentTimeMarker")
        self.appointment_uris = CrudApi(d, "/appointmentUri")
        self.assignments = CrudApi(d, "/assignment")
        self.captions = CrudApi(d, "/caption")
        self.categories = CrudApi(d, "/category")
        self.containers = CrudApi(d, "/container")
        self.filter_groups = CrudApi(d, "/filterGroup")
        self.filter_values = CrudApi(d, "/filterValue")
        self.jobs = CrudApi(d, "/job")
        self.pins = CrudApi(d, "/pin")
        self.resources = CrudApi(d, "/resource")
        self.resource_calendars = CrudApi(d, "/resourceCalendar")
        self.resource_certificates = CrudApi(d, "/resourceCertificate")
        self.resource_filter_values = CrudApi(d, "/resourceFilterValue")
        self.resource_gps_trackings = CrudApi(d, "/resourceGpsTracking")
        self.resource_uris = CrudApi(d, "/resourceUri")
        self.tasks = CrudApi(d, "/task")
        self.task_containers = CrudApi(d, "/taskContainer")
        self.task_filter_values = CrudApi(d, "/taskFilterValue")
        self.task_locked = CrudApi(d, "/taskLocked")
        self.task_uris = CrudApi(d, "/taskUri")
        self.time_markers = CrudApi(d, "/timeMarker")

        self.appointments = AppointmentApi(d)
        self.appointment_dependencies = AppointmentDependencyApi(d)
        self.appointment_fields = AppointmentFieldApi(d)
        self.notifications = NotificationApi(d)
        self.resource_capacities = ResourceCapacityApi(d)
        self.resource_types = ResourceTypeApi(d)
        self.calendars = CalendarApi(d)

        self.connectors = ConnectorApi(d)
        self.geocoding = GeocodeApi(d)
        self.imports = ImportApi(d)
        self.messages = MessageApi(d)
        self.optimization = OptimizationApi(d)
        self.recommendation = RecommendationApi(d)
        self.recurring_appointments = RecurringAppointmentApi(d)
        self.users = UserApi(d)

    @property
    def base_url(self) -> str:
        return str(self._http.base_url).rstrip("/")

    @property
    def environment(self) -> Environment:
        return self._environment

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> DimeSchedulerClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
