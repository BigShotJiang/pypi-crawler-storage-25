"""Retry policy shared by every Dime.Scheduler request.

The wrapped transport retries idempotent transport-level failures and a small
set of "the server is having a bad time" status codes. Defaults match the JS
and .NET SDKs so behaviour is identical regardless of runtime.
"""

from __future__ import annotations

import email.utils
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable

import httpx

# Status codes that trigger a retry by default.
DEFAULT_RETRY_STATUS_CODES: tuple[int, ...] = (408, 429, 500, 502, 503, 504)


@dataclass(frozen=True)
class RetryConfig:
    """Retry policy.

    Set ``max_retries=0`` to effectively disable retrying without removing the
    transport wrapper.
    """

    max_retries: int = 3
    initial_delay_s: float = 0.5
    max_delay_s: float = 30.0
    backoff_multiplier: float = 2.0
    retry_status_codes: tuple[int, ...] = field(default_factory=lambda: DEFAULT_RETRY_STATUS_CODES)
    respect_retry_after: bool = True


class RetryTransport(httpx.BaseTransport):
    """httpx transport that wraps an inner transport with retry behaviour.

    Retries on:
      - ``ConnectError``, ``ReadError``, ``WriteError``, ``ConnectTimeout``,
        ``ReadTimeout``, ``WriteTimeout``, ``PoolTimeout`` (transient I/O).
      - HTTP responses with status codes in ``config.retry_status_codes``.

    Honours ``Retry-After`` (delta-seconds or HTTP-date) on retryable responses
    when ``config.respect_retry_after`` is true. The ``Retry-After`` value is
    capped by ``config.max_delay_s``.

    Backoff is "full jitter": ``random() * min(initial * multiplier**n, cap)``.
    """

    _RETRYABLE_EXCEPTIONS: tuple[type[BaseException], ...] = (
        httpx.ConnectError,
        httpx.ReadError,
        httpx.WriteError,
        httpx.ConnectTimeout,
        httpx.ReadTimeout,
        httpx.WriteTimeout,
        httpx.PoolTimeout,
    )

    def __init__(
        self,
        config: RetryConfig | None = None,
        inner: httpx.BaseTransport | None = None,
        *,
        sleep: Callable[[float], None] = time.sleep,
        rng: Callable[[], float] = random.random,
        now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ) -> None:
        self._config = config or RetryConfig()
        self._inner = inner or httpx.HTTPTransport()
        self._sleep = sleep
        self._rng = rng
        self._now = now

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        cfg = self._config
        last_exc: BaseException | None = None
        last_response: httpx.Response | None = None

        for attempt in range(cfg.max_retries + 1):
            try:
                response = self._inner.handle_request(request)
            except self._RETRYABLE_EXCEPTIONS as exc:
                last_exc = exc
                if attempt == cfg.max_retries:
                    raise
                self._sleep(self._compute_backoff(attempt))
                continue

            if attempt == cfg.max_retries or response.status_code not in cfg.retry_status_codes:
                return response

            # Drain so the connection can be reused.
            response.read()
            response.close()
            last_response = response

            delay = self._delay_for(response, attempt)
            self._sleep(delay)

        # Loop body always returns or raises on the final attempt, so this is
        # unreachable. Belt-and-braces guard for static analysers.
        if last_response is not None:
            return last_response
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("retry loop exited without a result")

    def close(self) -> None:
        self._inner.close()

    def _delay_for(self, response: httpx.Response, attempt: int) -> float:
        if self._config.respect_retry_after:
            ra = response.headers.get("retry-after")
            parsed = self._parse_retry_after(ra) if ra else None
            if parsed is not None:
                return min(parsed, self._config.max_delay_s)
        return self._compute_backoff(attempt)

    def _compute_backoff(self, attempt: int) -> float:
        cfg = self._config
        exponential = cfg.initial_delay_s * (cfg.backoff_multiplier ** attempt)
        capped = min(exponential, cfg.max_delay_s)
        # Full jitter — random in [0, capped].
        return self._rng() * capped

    def _parse_retry_after(self, value: str) -> float | None:
        value = value.strip()
        if not value:
            return None
        try:
            seconds = float(value)
            return max(0.0, seconds)
        except ValueError:
            pass
        try:
            target = email.utils.parsedate_to_datetime(value)
        except (TypeError, ValueError):
            return None
        if target is None:
            return None
        if target.tzinfo is None:
            target = target.replace(tzinfo=timezone.utc)
        delta = (target - self._now()).total_seconds()
        return max(0.0, delta)
