# Dime.Scheduler SDK for Python

The official Python SDK for [Dime.Scheduler](https://docs.dimescheduler.com).

> **Status:** alpha. The domain-grouped accessor surface is in place; typed entity models are landing.

## Installation

```bash
pip install dimescheduler
# or
uv add dimescheduler
```

### Prereleases

Alpha / beta / release-candidate builds (e.g. `0.1.1b0` for `0.1.1-beta.0`) ship as PyPI prereleases. To opt into them:

```bash
pip install --pre dimescheduler
```

## Quick start

```python
from dimescheduler import DimeSchedulerClient, Environment

with DimeSchedulerClient(api_key="MY_API_KEY", environment=Environment.Sandbox) as client:
    result = client.categories.create({
        "name": "INSTALL",
        "displayName": "Install",
        "color": "#22d3ee",
    })
    if not result.ok:
        raise RuntimeError(result.error)
```

By default the client targets `Environment.Production`. Switch to `Sandbox` or `Test` for non-prod.

## API surface

Every entity hangs off a typed accessor on the client. CRUD-shaped entities expose `create` / `update` / `delete` / `get_all`:

```python
client.categories.create(category)
client.categories.update(category)
client.categories.delete(category)
result = client.categories.get_all()
```

Endpoints with required parameters expose them directly:

```python
client.appointments.get(start_date, end_date, resources=["R1", "R2"])
client.notifications.get(page=1, limit=50, sort="createdAt:desc")
client.geocoding.geocode_text("221B Baker Street", "GB")
client.optimization.field_service(request)
```

Every method returns a `Result`:

```python
result = client.categories.get_all()
result.ok                 # bool — convenience over response.is_success
result.data               # parsed JSON body on success, else None
result.error              # parsed JSON error body on 4xx/5xx, else None
result.response           # underlying httpx.Response
```

The accessor names mirror the .NET and JS SDKs 1:1 (with idiomatic `snake_case`), so cross-language code reads the same.

## Development

This package is part of the [`dime-scheduler/sdk`](https://github.com/dime-scheduler/sdk) monorepo. From `packages/python/`:

```bash
uv sync --extra dev          # install runtime + dev deps
uv run pytest                # run unit tests
uv run ruff check             # lint
./scripts/codegen.sh          # regenerate typed client from ../../spec/openapi.json
```

## License

[MIT](../../LICENSE)
