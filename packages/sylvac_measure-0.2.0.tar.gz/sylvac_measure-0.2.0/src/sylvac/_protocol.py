"""Low-level decode functions for Sylvac SDS GATT characteristics.

Based on: Sylvac SA, "Bluetooth Profile Specifications", MEM-PM 292-1806-01
https://github.com/SylvacDev/BluetoothDevTools/blob/main/
Sylvac-Custom-Bluetooth-GATT-Profiles/
MEM-PM%20292-1806-01-Bluetooth%20Profile%20Specifications.pdf
"""

import math
import struct
from dataclasses import dataclass
from enum import Enum

from sylvac._constants import MEASUREMENT_SENTINEL, RES_MAP, UNIT_MAP

INPUT_DATE_FORMAT = "%Y-%m-%d"
WIRE_DATE_FORMAT = "%d.%m.%Y"


class BatteryState(Enum):
    """Battery state reported by the ``BAT?`` command."""

    OK = "BAT1"
    LOW = "BAT0"

    def __str__(self) -> str:
        return "OK" if self == BatteryState.OK else "low"

    @classmethod
    def _missing_(cls, value: object) -> "BatteryState":
        return cls.LOW


class ResolutionMode(Enum):
    """Resolution mode reported by the ``RES?`` command."""

    RES1 = "RES1"
    RES2 = "RES2"
    RES3 = "RES3"

    def __str__(self) -> str:
        return self.value

    @classmethod
    def _missing_(cls, value: object) -> "ResolutionMode":
        return cls.RES1


class DisplayStatus(Enum):
    """Display freeze status reported by the ``STO?`` command."""

    LIVE = "STO0"
    FROZEN = "STO1"

    def __str__(self) -> str:
        return "live" if self == DisplayStatus.LIVE else "frozen"

    @classmethod
    def _missing_(cls, value: object) -> "DisplayStatus":
        return cls.LIVE


class MeasuringMode(Enum):
    """Measuring mode reported by the SDS Parameters characteristic."""

    NORMAL = 0b00
    MIN = 0b01
    MAX = 0b10
    DELTA = 0b11

    def __str__(self) -> str:
        return self.name.lower()

    @classmethod
    def _missing_(cls, value: object) -> "MeasuringMode":
        return cls.NORMAL


class Unit(Enum):
    """Measurement unit reported by the SDS Parameters characteristic."""

    UNKNOWN = "?"
    MM = "mm"
    INCH = "in"
    RAD = "rad"
    DEG = "°"
    DEG_MIN = "°'"

    def __str__(self) -> str:
        return self.value

    @classmethod
    def _missing_(cls, value: object) -> "Unit":
        return cls.UNKNOWN


@dataclass(frozen=True)
class DeviceInfo:
    """Device identification data read from the BLE DIS service (0x180A)."""

    manufacturer: str | None
    model_number: str | None
    serial_number: str | None
    firmware_revision: str | None
    hardware_revision: str | None

    def __str__(self) -> str:
        parts = []
        if self.manufacturer:
            parts.append(self.manufacturer)
        if self.model_number:
            parts.append(f"model {self.model_number}")
        if self.serial_number:
            parts.append(f"S/N {self.serial_number}")
        if self.firmware_revision:
            parts.append(f"FW {self.firmware_revision}")
        if self.hardware_revision:
            parts.append(f"HW {self.hardware_revision}")
        return ", ".join(parts) if parts else "unknown device"


@dataclass(frozen=True)
class Measurement:
    """A single decoded measurement from a Sylvac instrument.

    ``value`` is expressed in ``unit`` and already converted from the raw SI
    value using the Parameters characteristic.
    ``resolution`` is the smallest increment in the same unit (e.g. 0.01 for
    0.01 mm), or None if unknown.
    """

    value: float
    unit: Unit
    resolution: float | None
    mode: MeasuringMode
    manual: bool = False

    def format(self) -> str:
        """Return a human-readable string, e.g. '20.58 mm'."""
        if self.resolution is not None and self.resolution > 0:
            decimals = max(0, -int(round(math.log10(self.resolution))))
            return f"{self.value:.{decimals}f}"
        return f"{self.value:.6g}"


def decode_measurement(data: bytes, exponent: int) -> float | None:
    """Decode a 4-byte SDS Measurement notification payload.

    Returns the value in SI base units (metres for length, radians for angle),
    or None if the sentinel value is present (instrument not notifying yet).

    Args:
        data:     Raw 4-byte notify payload.
        exponent: Scaling exponent from the CPFD descriptor (e.g. -9 for nm).
    """
    (raw,) = struct.unpack("<i", data)  # Signed int32, little-endian
    if raw == MEASUREMENT_SENTINEL:
        return None
    return raw * (10 ** exponent)


def decode_parameters(data: bytes) -> tuple[Unit, float | None, MeasuringMode]:
    """Decode a 2-byte SDS Parameters notification payload.

    Returns:
        unit:       Display unit as a :class:`Unit` enum member.
        resolution: Smallest increment in SI units, or None if unspecified.
        mode:       Measuring mode as a :class:`MeasuringMode` enum member.
    """
    (value,) = struct.unpack("<H", data)
    unit = Unit(UNIT_MAP.get((value >> 12) & 0xF, "?"))
    res = RES_MAP.get((value >> 8) & 0xF)
    mode = MeasuringMode(value & 0x3)
    return unit, res, mode


def si_to_display(si_value: float, unit: Unit) -> float:
    """Convert a raw SI measurement (metres or radians) to the display unit."""
    if unit == Unit.MM:
        return si_value * 1e3
    if unit == Unit.INCH:
        return si_value / 0.0254
    if unit in (Unit.DEG, Unit.DEG_MIN):
        return si_value * (180.0 / math.pi)
    return si_value  # rad or unknown: return as-is


def resolution_in_display_unit(si_res: float, unit: Unit) -> float:
    """Convert a SI resolution value to the display unit."""
    return si_to_display(si_res, unit)
