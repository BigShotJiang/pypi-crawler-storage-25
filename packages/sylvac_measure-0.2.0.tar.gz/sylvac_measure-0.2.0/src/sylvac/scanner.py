"""BLE scanner for Sylvac instruments."""

import asyncio
import logging

from bleak import BleakScanner
from bleak.backends.device import BLEDevice

from sylvac._constants import DEVICE_NAME_PREFIXES

logger = logging.getLogger(__name__)


async def scan(
    timeout: float = 10.0,
    name_prefix: str = "SY",
) -> BLEDevice | None:
    """Scan for BLE devices and return the first Sylvac instrument found.

    Args:
        timeout:     Maximum scan duration in seconds.
        name_prefix: Device name prefix to match (default: ``"SY"``).
                     Sylvac instruments advertise names like ``SY289``, ``SY295``.
                     Use ``"MTY"`` for OEM-branded instruments.

    Returns:
        The first matching :class:`~bleak.backends.device.BLEDevice`, or
        ``None`` if no device is found within *timeout* seconds.
    """
    logger.debug(
        "Scanning for Sylvac devices (prefix=%r, timeout=%.1fs)…", name_prefix, timeout
    )

    found: BLEDevice | None = None

    def _detection_callback(device: BLEDevice, _adv) -> None:
        nonlocal found
        if found is None and (device.name or "").startswith(name_prefix):
            logger.debug("Found candidate: %s (%s)", device.name, device.address)
            found = device

    async with BleakScanner(detection_callback=_detection_callback):
        loop = asyncio.get_event_loop()
        deadline = loop.time() + timeout
        while found is None and loop.time() < deadline:
            await asyncio.sleep(0.1)

    if found is None:
        logger.warning(
            "No Sylvac device found (prefix=%r, timeout=%.1fs).", name_prefix, timeout
        )
    else:
        logger.debug("Found: %s (%s)", found.name, found.address)

    return found


async def scan_all(
    timeout: float = 10.0,
    name_prefix: str = "SY",
):
    """Async iterator that yields each newly discovered Sylvac instrument.

    Scans for *timeout* seconds and yields a
    :class:`~bleak.backends.device.BLEDevice` each time a previously unseen
    device is detected. Completes (raises :exc:`StopAsyncIteration`) when the
    scan window expires.

    Args:
        timeout:     Scan duration in seconds.
        name_prefix: Device name prefix to match (default: ``"SY"``).

    Example::

        async for device in scan_all(timeout=10):
            print(device.name, device.address)
    """
    logger.debug(
        "Scanning for all Sylvac devices (prefix=%r, timeout=%.1fs)…", name_prefix, timeout
    )

    seen: set[str] = set()
    queue: asyncio.Queue[BLEDevice] = asyncio.Queue()

    def _detection_callback(device: BLEDevice, _adv) -> None:
        if (device.name or "").startswith(name_prefix):
            if device.address not in seen:
                seen.add(device.address)
                logger.debug("Found: %s (%s)", device.name, device.address)
                queue.put_nowait(device)

    async with BleakScanner(detection_callback=_detection_callback):
        deadline = asyncio.get_event_loop().time() + timeout
        while True:
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                break
            try:
                device = await asyncio.wait_for(queue.get(), timeout=remaining)
                yield device
            except asyncio.TimeoutError:
                break

    logger.debug("Scan complete: %d device(s) found.", len(seen))
