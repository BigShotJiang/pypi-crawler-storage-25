"""sylvac — Python package for Sylvac Bluetooth measurement instruments.

Typical usage::

    import asyncio
    import sylvac

    async def main():
        device = await sylvac.scan(timeout=10)
        if device is None:
            return
        async with sylvac.Device(device.address) as dev:
            async for m in dev.measurements():
                print(m.format())

    asyncio.run(main())
"""

from sylvac.device import Device
from sylvac.scanner import scan, scan_all
from sylvac._protocol import BatteryState, DeviceInfo, DisplayStatus, Measurement, MeasuringMode, ResolutionMode, Unit

__all__ = [
    "Device",
    "scan",
    "scan_all",
    "BatteryState",
    "DeviceInfo",
    "DisplayStatus",
    "Measurement",
    "MeasuringMode",
    "ResolutionMode",
    "Unit",
]
