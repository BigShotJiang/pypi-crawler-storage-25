"""``sylvac config get`` and ``sylvac config set`` subcommands."""

import argparse
import logging
from datetime import datetime

from sylvac.device import Device
from sylvac._protocol import ResolutionMode, Unit, INPUT_DATE_FORMAT, WIRE_DATE_FORMAT
from sylvac.cli._common import add_connection_args, resolve_address

logger = logging.getLogger(__name__)


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    config_parser = subparsers.add_parser(
        "config",
        help="Read or write instrument configuration.",
    )
    config_subs = config_parser.add_subparsers(
        dest="config_command", metavar="<subcommand>"
    )
    config_subs.required = True

    # --- get ---
    get_p = config_subs.add_parser(
        "get",
        help="Read and display instrument settings.",
    )
    add_connection_args(get_p)
    get_p.add_argument(
        "setting",
        nargs="?",
        choices=[
            "unit",
            "keyboard-locked",
            "resolution",
            "preset",
            "display",
            "last-calibration",
            "next-calibration",
            "eco",
            "id",
            "number",
            "favorites",
            "standby-timeout",
            "output"
        ],
        help="Setting to read (if omitted, shows all settings)",
    )
    get_p.set_defaults(func=run_get)

    # --- set ---
    set_p = config_subs.add_parser(
        "set",
        help="Write a setting to the instrument.",
    )
    add_connection_args(set_p)
    set_p.add_argument(
        "setting",
        choices=[
            "unit",
            "unit-locked",
            "keyboard-locked",
            "resolution",
            "preset",
            "display",
            "last-calibration",
            "next-calibration",
            "eco",
            "number",
            "standby-timeout",
            "output"
        ],
        help="Setting to write",
    )
    set_p.add_argument(
        "value",
        help="Value to write",
    )
    set_p.set_defaults(func=run_set)


async def run_get(args: argparse.Namespace) -> None:
    address = await resolve_address(args)

    async with Device(address) as dev:
        if args.setting is None:
            settings = await dev.get_all_settings()
            for setting, value in settings.items():
                if isinstance(value, datetime):
                    value = value.strftime(INPUT_DATE_FORMAT)
                print(f"{setting}: {value}")
        else:
            # Show specific setting
            setting = args.setting
            if setting == "id":
                print(await dev.get_id())
            elif setting == "number":
                print(await dev.get_number())
            elif setting == "unit":
                print(await dev.get_unit())
            elif setting == "resolution":
                print(await dev.get_resolution())
            elif setting == "preset":
                print(await dev.get_preset())
            elif setting == "display":
                print(await dev.get_display_status())
            elif setting == "eco":
                print(await dev.get_eco_mode())
            elif setting == "keyboard-locked":
                print(await dev.get_keyboard_lock())
            elif setting == "last-calibration":
                last_cal = await dev.get_last_calibration_date()
                print(last_cal.strftime(INPUT_DATE_FORMAT) if last_cal else None)
            elif setting == "next-calibration":
                next_cal = await dev.get_next_calibration_date()
                print(next_cal.strftime(INPUT_DATE_FORMAT) if next_cal else None)
            elif setting == "favorites":
                print(await dev.get_favorites())
            elif setting == "standby-timeout":
                print(await dev.get_standby_timeout())
            elif setting == "output":
                print(await dev.get_output())


async def run_set(args: argparse.Namespace) -> None:
    address = await resolve_address(args)
    setting = args.setting
    value = args.value

    async with Device(address) as dev:
        if setting == "unit":
            if value not in [u.value for u in Unit if u != Unit.UNKNOWN]:
                valid = ", ".join(u.value for u in Unit if u != Unit.UNKNOWN)
                raise argparse.ArgumentTypeError(
                    f"Invalid unit {value!r}. Valid options: {valid}"
                )
            unit = Unit(value)
            await dev.set_unit(unit)
            logger.info("Set unit to %s", unit)

        elif setting == "unit-locked":
            locked = _parse_bool(value)
            await dev.set_unit_lock(locked)
            logger.info("Set unit locked to %s", locked)

        elif setting == "keyboard-locked":
            locked = _parse_bool(value)
            await dev.set_keyboard_lock(locked)
            logger.info("Set keyboard locked to %s", locked)

        elif setting == "resolution":
            if value not in [r.value for r in ResolutionMode]:
                valid = ", ".join(r.value for r in ResolutionMode)
                raise argparse.ArgumentTypeError(
                    f"Invalid resolution {value!r}. Valid options: {valid}"
                )
            resolution = ResolutionMode(value)
            await dev.set_resolution(resolution)
            logger.info("Set resolution to %s", value)

        elif setting == "preset":
            try:
                preset_value = float(value)
            except ValueError:
                raise argparse.ArgumentTypeError(
                    f"Invalid preset value {value!r}. Expected a number."
                )
            await dev.set_preset(preset_value)
            logger.info("Set preset to %g", preset_value)

        elif setting == "display":
            if value not in ["live", "frozen"]:
                raise argparse.ArgumentTypeError(
                    f"Invalid display-status {value!r}. Valid options: live, frozen"
                )
            frozen = value == "frozen"
            await dev.set_display_status(frozen)
            logger.info("Set display status to %s", value)

        elif setting == "last-calibration":
            date_value = _parse_date(value)
            await dev.set_last_calibration_date(date_value)
            logger.info("Set last calibration date to %s", date_value.strftime(INPUT_DATE_FORMAT))

        elif setting == "next-calibration":
            date_value = _parse_date(value)
            await dev.set_next_calibration_date(date_value)
            logger.info("Set next calibration date to %s", date_value.strftime(INPUT_DATE_FORMAT))

        elif setting == "eco":
            economy_value = _parse_bool(value)
            await dev.set_eco_mode(economy_value)
            logger.info("Set economy mode to %s", economy_value)

        elif setting == "standby-timeout":
            try:
                minutes = int(value)
                if minutes < 0:
                    raise ValueError()
            except ValueError:
                raise argparse.ArgumentTypeError(
                    f"Invalid standby timeout {value!r}. Expected a non-negative integer."
                )
            await dev.set_standby_timeout(minutes)
            logger.info("Set standby timeout to %d minutes", minutes)

        elif setting == "number":
            await dev.set_number(value)
            logger.info("Set instrument number to %s", value)

        elif setting == "output":
            output_value = _parse_bool(value)
            await dev.set_output(output_value)
            logger.info("Set output to %s", output_value)


def _parse_date(value: str) -> datetime:
    try:
        return datetime.strptime(value, INPUT_DATE_FORMAT)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"Invalid date {value!r}. Expected format: YYYY-MM-DD"
        )


def _parse_bool(value: str) -> bool:
    if value.lower() in ("1", "true", "yes", "on"):
        return True
    if value.lower() in ("0", "false", "no", "off"):
        return False
    raise argparse.ArgumentTypeError(f"Expected a boolean value, got {value!r}")
