"""Single entry point for the ``sylvac`` command.

Subcommands:
  sylvac list             — scan for available Sylvac BLE devices
  sylvac info             — show device identification and status
  sylvac measure          — take a single measurement (or stream with -f)
  sylvac config get       — read and display instrument settings
  sylvac config set       — write instrument settings
"""

import argparse
import asyncio
import logging

from sylvac.cli import measure, config, info, list_devices, device_control
from sylvac.cli._common import setup_logging, add_connection_args, add_json_arg

logger = logging.getLogger(__name__)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="sylvac",
        description="Interact with a Sylvac BLE measurement instrument.",
    )
    parser.add_argument(
        "--log-level", default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging verbosity (default: INFO)",
    )
    add_connection_args(parser)
    add_json_arg(parser)
    parser.set_defaults(func=info.run)

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")

    list_devices.add_subparser(subparsers)
    info.add_subparser(subparsers)
    measure.add_subparser(subparsers)
    config.add_subparser(subparsers)
    device_control.add_subparsers(subparsers)

    args = parser.parse_args()
    setup_logging(args)

    try:
        asyncio.run(args.func(args))
    except KeyboardInterrupt:
        logger.debug("Disconnected.")


if __name__ == "__main__":
    main()
