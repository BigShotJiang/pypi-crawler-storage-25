"""``sylvac poweroff``, ``sylvac reset``, and ``sylvac standby`` subcommands."""

import argparse
import logging

from sylvac import Device
from sylvac.cli._common import add_connection_args, resolve_address

logger = logging.getLogger(__name__)


def add_subparsers(subparsers: argparse._SubParsersAction) -> None:
    # --- poweroff ---
    p = subparsers.add_parser(
        "poweroff",
        help="Put the instrument into sleep mode (saves battery).",
    )
    add_connection_args(p)
    p.set_defaults(func=run_poweroff)

    # --- reset ---
    p = subparsers.add_parser(
        "reset",
        help="Reset instrument user settings.",
    )
    add_connection_args(p)
    p.set_defaults(func=run_reset)

    # --- standby ---
    p = subparsers.add_parser(
        "standby",
        help="Put the instrument into standby mode.",
    )
    add_connection_args(p)
    p.set_defaults(func=run_standby)


async def run_poweroff(args: argparse.Namespace) -> None:
    address = await resolve_address(args)
    async with Device(address) as device:
        await device.poweroff()
        logger.debug("Instrument powered off.")


async def run_reset(args: argparse.Namespace) -> None:
    address = await resolve_address(args)
    async with Device(address) as device:
        await device.reset()
        logger.debug("Instrument reset.")


async def run_standby(args: argparse.Namespace) -> None:
    address = await resolve_address(args)
    async with Device(address) as device:
        await device.standby()
        logger.debug("Instrument in standby.")
