#!/usr/bin/env python3
"""Standalone script — delegates to the sylvac package CLI.

Can be run directly without installing the package:
    python sylvac.py [--timeout 10] [--prefix SY] [--address ADDR]

When the package is installed via pip, the ``sylvac`` console script
is available instead (defined in pyproject.toml).
"""

from sylvac.__main__ import main

if __name__ == "__main__":
    main()
