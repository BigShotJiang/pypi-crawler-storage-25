
{
    "version": "2026.5.24",
    "target": "default",
    "variant": "cpu"
}
