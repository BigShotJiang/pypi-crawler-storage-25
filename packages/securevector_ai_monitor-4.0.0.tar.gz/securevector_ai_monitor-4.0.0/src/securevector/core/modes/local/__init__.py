# Local mode implementation
