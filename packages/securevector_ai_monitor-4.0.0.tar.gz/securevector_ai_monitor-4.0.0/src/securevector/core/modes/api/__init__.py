# API mode implementation
