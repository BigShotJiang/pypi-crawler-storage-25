from __future__ import annotations

import argparse
import hashlib
import importlib.resources as resources
import json
import os
import tempfile
from pathlib import Path

import zipfile
import zstandard as zstd


_MANIFEST = json.loads(resources.files(__package__).joinpath("asset_manifest.json").read_text(encoding="utf-8"))
_SHARDS = [
    ("ore_cancer_generation_v18_shard01", "part-0001.bin")
]


def _default_target_dir() -> Path:
    if os.name == "nt":
        return Path.cwd()
    return Path("/tmp")


def _file_digest(path: Path, chunk_size: int = 1024 * 1024) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
            size += len(chunk)
    return digest.hexdigest(), size


def _target_path(target_dir: str | os.PathLike[str] | None) -> Path:
    base_dir = _default_target_dir() if target_dir is None else Path(target_dir)
    base_dir.mkdir(parents=True, exist_ok=True)
    return base_dir.resolve() / _MANIFEST["original_filename"]


def ensure_asset(target_dir: str | os.PathLike[str] | None = None, force: bool = False) -> str:
    destination = _target_path(target_dir)
    if destination.exists() and not force:
        current_hash, current_size = _file_digest(destination)
        if current_hash == _MANIFEST["original_sha256"] and current_size == _MANIFEST["original_size"]:
            return str(destination)

    temp_handle = tempfile.NamedTemporaryFile(
        mode="wb",
        prefix=f"{destination.name}.",
        suffix=".tmp",
        delete=False,
        dir=str(destination.parent),
    )
    tmp_path = Path(temp_handle.name)
    original_hash = hashlib.sha256()
    compressed_hash = hashlib.sha256()
    written_size = 0
    try:
        with temp_handle:
            decompressor = zstd.ZstdDecompressor().decompressobj()
            for module_name, part_filename in _SHARDS:
                resource = resources.files(f"{module_name}._data").joinpath(part_filename)
                with resource.open("rb") as shard_handle:
                    while True:
                        chunk = shard_handle.read(1024 * 1024)
                        if not chunk:
                            break
                        compressed_hash.update(chunk)
                        output = decompressor.decompress(chunk)
                        if output:
                            original_hash.update(output)
                            written_size += len(output)
                            temp_handle.write(output)
            tail = decompressor.flush()
            if tail:
                original_hash.update(tail)
                written_size += len(tail)
                temp_handle.write(tail)

        if compressed_hash.hexdigest() != _MANIFEST["compressed_sha256"]:
            raise RuntimeError("Compressed shard digest mismatch.")
        if original_hash.hexdigest() != _MANIFEST["original_sha256"]:
            raise RuntimeError("Restored asset digest mismatch.")
        if written_size != _MANIFEST["original_size"]:
            raise RuntimeError("Restored asset size mismatch.")

        os.replace(tmp_path, destination)
        return str(destination)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise



def unzip_asset(
    asset_path: str | os.PathLike[str] | None = None,
    extract_path: str | os.PathLike[str] = "./",
    force: bool = False,
) -> str:
    zip_path = Path(ensure_asset(".", force=force)) if asset_path is None else Path(asset_path).expanduser()
    if not zip_path.exists():
        raise FileNotFoundError(f"Zip asset does not exist: {zip_path}")

    destination = Path(extract_path).expanduser()
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(destination)
    return str(destination.resolve())



def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Restore the packaged asset into a target directory.")
    parser.add_argument("--target-dir", default=None, help="Directory where the restored asset will be written.")
    parser.add_argument("--force", action="store_true", help="Force regeneration even if the target already matches.")
    args = parser.parse_args(argv)
    print(ensure_asset(args.target_dir, force=args.force))
    return 0
