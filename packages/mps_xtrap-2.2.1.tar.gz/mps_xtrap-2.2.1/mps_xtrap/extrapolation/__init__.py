"""
Multilevel Richardson Extrapolation for MPS quantum circuit simulation.

Theory
------
MPS truncation error in an expectation value <O> scales approximately as:

    <O>(χ) ≈ <O>(∞) + a₁/χ^α + a₂/χ^(2α) + ...

When bond dimensions are chosen as a geometric sequence χ, s·χ, s²·χ, ...
where s is the scaling factor (e.g. s=2 means each χ doubles), the error
at successive bond dimensions has ratio:

    r = 1/s^α   (the error ratio)

Because f(s·χ) has error a/(s·χ)^α = (1/s^α) · a/χ^α = r · error(χ).

Richardson extrapolation cancels successive powers of the error using r:

    Level-1: E₁[i] = (f(χᵢ₊₁) - r · f(χᵢ)) / (1 - r)
    Level-2: E₂[i] = (E₁[i+1] - r · E₁[i]) / (1 - r)
    ...

This is analogous to Romberg integration applied to bond-dimension convergence.

The key assumption is that truncation error decays as a power law in χ.
This holds well for:
  - Gapped 1D systems (area-law entanglement)
  - Circuits in the weakly-entangled regime
  - Deep circuits at large enough χ (tail of entanglement spectrum)

Reliability diagnostics:
  - Convergence ratio test: successive corrections should decrease geometrically
  - Error bar estimation from spread of extrapolated values
  - Consistency check across multiple extrapolation orders

References
----------
- Richardson (1911), Romberg (1955) for the extrapolation framework
- Vidal (2003), Schollwöck (2011) for MPS and bond-dimension convergence
"""

from __future__ import annotations
import numpy as np
from numpy.typing import NDArray
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict, Callable
import warnings
import logging

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class ExtrapolationResult:
    """
    Result of Richardson extrapolation.

    Attributes
    ----------
    bond_dims : list of int
        Bond dimensions used.
    raw_values : list of float
        Expectation values at each bond dimension.
    extrapolated : float
        Best extrapolated estimate.
    uncertainty : float
        Estimated uncertainty of extrapolated value.
    table : ndarray
        Full Richardson tableau (rows = levels, cols = bond dims).
    convergence_ratios : list of float
        Ratios of successive corrections (should be ~r = 1/s^α for reliable result).
    is_reliable : bool
        Whether the extrapolation passes reliability diagnostics.
    reliability_notes : list of str
        Explanations of any reliability concerns.
    alpha : float
        Estimated truncation error exponent.
    scaling_factor : float
        The bond dimension scaling factor s (e.g. 2.0 means chi doubles each level).
        Note: the error ratio r = 1/s^alpha is derived from this.
    """
    bond_dims: List[int]
    raw_values: List[float]
    extrapolated: float
    uncertainty: float
    table: NDArray
    convergence_ratios: List[float]
    is_reliable: bool
    reliability_notes: List[str]
    alpha: float
    scaling_factor: float

    def summary(self) -> str:
        lines = [
            "=" * 60,
            "Richardson Extrapolation Result",
            "=" * 60,
            f"Bond dimensions: {self.bond_dims}",
            f"Raw values:      {[f'{v:.8f}' for v in self.raw_values]}",
            f"Extrapolated:    {self.extrapolated:.8f} ± {self.uncertainty:.2e}",
            f"Alpha (exponent): {self.alpha:.3f}",
            f"Reliable:        {self.is_reliable}",
        ]
        if self.reliability_notes:
            lines.append("Notes:")
            for note in self.reliability_notes:
                lines.append(f"  • {note}")
        lines.append("=" * 60)
        return '\n'.join(lines)

    def improvement_factor(self) -> float:
        """How much the extrapolation improved over the largest raw value."""
        best_raw = self.raw_values[-1]
        if abs(self.extrapolated - best_raw) < 1e-15:
            return 1.0
        return abs(self.raw_values[0] - self.raw_values[-1]) / \
               max(abs(self.extrapolated - best_raw), 1e-15)


@dataclass
class MultiObservableResult:
    """Results for multiple observables extrapolated simultaneously."""
    observables: Dict[str, ExtrapolationResult]
    bond_dims: List[int]

    def summary(self) -> str:
        lines = ["Multi-Observable Richardson Extrapolation", "=" * 50]
        lines.append(f"Bond dims: {self.bond_dims}")
        for name, res in self.observables.items():
            rel = "✓" if res.is_reliable else "⚠"
            lines.append(
                f"  {rel} {name:20s}: {res.extrapolated:.8f} ± {res.uncertainty:.2e}"
            )
        return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Core extrapolation engine (internal)
# ---------------------------------------------------------------------------

class _RichardsonExtrapolator:
    """
    Internal Richardson extrapolation engine.

    This class is not part of the public API. Users should interact exclusively
    through MultiChiRunner, which guarantees that bond dimensions are always
    generated from a known scaling factor s. This means r = 1/s^alpha is exact
    and never needs to be inferred from data.

    Parameters
    ----------
    scaling_factor : float
        The factor s by which successive bond dimensions are scaled.
        The error ratio r = 1/s^alpha is derived from this.
    alpha : float or None
        Known truncation error exponent. If None, estimated from data.
    """

    def __init__(
        self,
        scaling_factor: float,
        alpha: Optional[float] = None,
    ):
        self.scaling_factor = scaling_factor
        self.alpha = alpha

    def _estimate_alpha(self, bond_dims: List[int], values: List[float]) -> float:
        """
        Estimate the truncation error exponent α from observed convergence.
        Uses log-log regression of |f(χᵢ₊₁) - f(χᵢ)| vs χᵢ.
        """
        if len(values) < 3:
            return 1.0

        diffs = [abs(values[i + 1] - values[i]) for i in range(len(values) - 1)]
        diffs = [d for d in diffs if d > 1e-15]

        if len(diffs) < 2:
            return 1.0

        log_chi = np.log([bond_dims[i] for i in range(len(diffs))])
        log_diff = np.log(diffs)

        coeffs = np.polyfit(log_chi, log_diff, 1)
        alpha = float(np.clip(-coeffs[0], 0.1, 10.0))
        return alpha

    def _richardson_step(
        self,
        f_lo: float,
        f_hi: float,
        alpha: float,
    ) -> float:
        """
        Single Richardson extrapolation step canceling O(chi^{-alpha}) error.

        Error ratio r = 1/s^alpha, where s is self.scaling_factor.
        Formula: f_extrapolated = (f_hi - r * f_lo) / (1 - r)
        """
        r = (1.0 / self.scaling_factor) ** alpha
        return (f_hi - r * f_lo) / (1.0 - r)

    def _run(
        self,
        bond_dims: List[int],
        values: List[float],
    ) -> ExtrapolationResult:
        """
        Apply multilevel Richardson extrapolation.

        bond_dims must be generated by SweepConfig.bond_dims — i.e. a uniform
        geometric sequence with ratio exactly self.scaling_factor. This is
        guaranteed when called through MultiChiRunner.
        """
        n = len(values)

        # Determine alpha
        used_alpha = (
            self.alpha
            if self.alpha is not None
            else self._estimate_alpha(bond_dims, values)
        )

        # Error ratio — exact because scaling_factor comes directly from SweepConfig
        r = (1.0 / self.scaling_factor) ** used_alpha

        # Build Richardson tableau
        # table[level][i] = extrapolated value at this level using points i..i+level
        table = np.full((n, n), np.nan)
        table[0, :] = values  # Level 0 = raw values

        for level in range(1, n):
            for i in range(n - level):
                f_lo = table[level - 1, i]
                f_hi = table[level - 1, i + 1]
                # scaling_factor is the same uniform s at every tableau level,
                # so r = 1/s^alpha is constant throughout — no per-pair inference needed.
                table[level, i] = self._richardson_step(f_lo, f_hi, used_alpha)

        # Best estimate: highest level, leftmost entry
        max_level = n - 1
        extrapolated = table[max_level, 0]

        # Uncertainty: spread across the top few extrapolation levels
        alternative_estimates = [
            table[lvl, 0]
            for lvl in range(max(1, max_level - 2), max_level + 1)
            if not np.isnan(table[lvl, 0])
        ]
        if len(alternative_estimates) > 1:
            uncertainty = float(np.std(alternative_estimates))
        else:
            # Fallback: scale last raw difference by (1 - r)
            uncertainty = abs(values[-1] - values[-2]) / (1.0 - r)

        # Convergence ratio diagnostics
        corrections = [
            abs(table[level, 0] - table[level - 1, 0])
            for level in range(1, max_level + 1)
            if not np.isnan(table[level, 0]) and not np.isnan(table[level - 1, 0])
        ]
        conv_ratios = [
            corrections[i] / corrections[i + 1]
            for i in range(len(corrections) - 1)
            if corrections[i + 1] > 1e-15
        ]

        # Reliability checks
        notes = []
        is_reliable = True

        # Check 1: Monotone convergence in raw values
        diffs = [values[i + 1] - values[i] for i in range(n - 1)]
        if not (all(d >= 0 for d in diffs) or all(d <= 0 for d in diffs)):
            notes.append("Raw values are not monotonically converging with bond dimension.")
            is_reliable = False

        # Check 2: Richardson corrections decreasing
        if len(corrections) >= 2 and corrections[-1] > corrections[-2] * 1.5:
            notes.append("Richardson corrections are not decreasing — extrapolation may be unreliable.")
            is_reliable = False

        # Check 3: Uncertainty relative to signal
        signal = abs(extrapolated)
        if signal > 1e-10 and uncertainty / signal > 0.5:
            notes.append(
                f"Uncertainty ({uncertainty:.2e}) is large relative to signal ({signal:.2e}). "
                "Consider increasing n_levels."
            )
            is_reliable = False

        # Check 4: Alpha plausibility
        if used_alpha < 0.3 or used_alpha > 8.0:
            notes.append(
                f"Estimated alpha={used_alpha:.2f} is outside plausible range [0.3, 8.0]. "
                "Truncation error may not follow a power law."
            )
            is_reliable = False

        if not notes:
            notes.append("All reliability checks passed.")

        return ExtrapolationResult(
            bond_dims=list(bond_dims),
            raw_values=list(values),
            extrapolated=float(np.real(extrapolated)),
            uncertainty=float(uncertainty),
            table=table,
            convergence_ratios=conv_ratios,
            is_reliable=is_reliable,
            reliability_notes=notes,
            alpha=used_alpha,
            scaling_factor=self.scaling_factor,
        )

    def _run_multi(
        self,
        bond_dims: List[int],
        values_dict: Dict[str, List[float]],
    ) -> MultiObservableResult:
        """Extrapolate multiple observables using the same bond_dims."""
        results = {}
        for obs_name, vals in values_dict.items():
            try:
                results[obs_name] = self._run(bond_dims, vals)
            except Exception as e:
                logger.warning(f"Extrapolation failed for {obs_name}: {e}")
        return MultiObservableResult(observables=results, bond_dims=list(bond_dims))


# ---------------------------------------------------------------------------
# Public configuration and runner
# ---------------------------------------------------------------------------

@dataclass
class SweepConfig:
    """
    Configuration for a multi-bond-dimension sweep.

    This is the single place where chi values are defined. Bond dimensions
    are always auto-generated as a uniform geometric sequence:

        chi_0 = base_chi
        chi_1 = base_chi * scaling_factor
        chi_2 = base_chi * scaling_factor^2
        ...

    Users never supply raw bond dimension lists — the scaling factor is always
    known exactly, which makes the error ratio r = 1/s^alpha exact throughout.

    Parameters
    ----------
    base_chi : int
        Smallest bond dimension to simulate (default 64).
    scaling_factor : float
        Factor s by which chi grows at each level (default 2).
        Note: this is NOT the error ratio r. The error ratio r = 1/s^alpha
        is computed internally by the extrapolator.
    n_levels : int
        Number of bond dimensions to simulate, including base_chi (default 3).
        e.g. base_chi=16, scaling_factor=2, n_levels=3 → chi = [16, 32, 64].
    alpha : float or None
        Truncation error exponent. If None, estimated from the simulation data.
    """
    base_chi: int = 64
    scaling_factor: float = 2.0
    n_levels: int = 3
    alpha: Optional[float] = None

    @property
    def bond_dims(self) -> List[int]:
        """Auto-generate bond dimensions from base_chi and scaling_factor."""
        return [int(self.base_chi * self.scaling_factor ** i) for i in range(self.n_levels)]

    def effective_chi(self) -> int:
        """Equivalent bond dimension of the extrapolated result."""
        return int(self.bond_dims[-1] * self.scaling_factor)


class MultiChiRunner:
    """
    The single public entry point for Richardson extrapolation.

    Runs a circuit at multiple bond dimensions (auto-generated from SweepConfig)
    and applies Richardson extrapolation to estimate the infinite-chi limit.

    Users only need to specify:
        - base_chi       : starting bond dimension
        - scaling_factor : how much chi grows each level (default 2)
        - n_levels       : how many chi values to simulate (default 3)
        - alpha          : truncation error exponent (estimated if not provided)
        - device         : 'cpu' (default) or 'cuda' for GPU acceleration

    Parameters
    ----------
    config : SweepConfig
        Sweep configuration. If None, defaults are used.
    verbose : bool
        Print progress during simulation.
    device : str
        'cpu' (default) or 'cuda'. Passed to each MPSSimulator run.
        Falls back to CPU automatically if CuPy is unavailable.

    Example
    -------
        runner = MultiChiRunner(
            SweepConfig(base_chi=16, scaling_factor=2, n_levels=3),
            device='cuda',
        )
        result = runner.run(circuit, observables={'Z0': ('Z', 0)})
        print(result.summary())
    """

    def __init__(
        self,
        config: Optional[SweepConfig] = None,
        verbose: bool = True,
        device: str = 'cpu',
    ):
        self.config = config or SweepConfig()
        self._extrapolator = _RichardsonExtrapolator(
            scaling_factor=self.config.scaling_factor,
            alpha=self.config.alpha,
        )
        self.verbose = verbose
        self.device = device

    def run(
        self,
        circuit,
        observables: Optional[Dict[str, Tuple[str, int]]] = None,
        measure: Optional[Dict[str, Tuple[int, str]]] = None,
    ) -> MultiObservableResult:
        """
        Simulate the circuit at each auto-generated chi and extrapolate.

        Both expectation values (Pauli observables) and measurement
        probabilities are extrapolated using the same Richardson machinery.
        Probabilities obey the same truncation-error power law as expectation
        values, because they are themselves expectation values of projector
        operators:  P(k, s) = <psi| P_k^(s) |psi>.

        Parameters
        ----------
        circuit : Circuit
            The circuit to simulate.
        observables : dict, optional
            Mapping of label to (observable_type, site).
            E.g., {'Z0': ('Z', 0), 'Z1': ('Z', 1)}
        measure : dict, optional
            Mapping of label to (site, outcome_key) for Born-rule probabilities.
            outcome_key is 'prob0' or 'prob1'.
            E.g., {'P0_q1': (1, 'prob0'), 'P1_q2': (2, 'prob1')}
            Extrapolated results appear in the returned MultiObservableResult
            alongside ordinary expectation values.

        Returns
        -------
        MultiObservableResult
        """
        from ..circuits import MPSSimulator
        from ..measurement import MeasurementEngine
        from ..license import _check_and_consume_credit

        # One logical simulation run = 1 credit regardless of n_levels
        _check_and_consume_credit(1)

        observables = observables or {}
        measure = measure or {}

        bond_dims = self.config.bond_dims
        all_names = list(observables) + list(measure)
        values_dict: Dict[str, List[float]] = {name: [] for name in all_names}

        for chi in bond_dims:
            if self.verbose:
                print(f"  Simulating chi={chi}...", end=" ", flush=True)

            sim = MPSSimulator(chi=chi, device=self.device)
            state = sim.run(circuit, _skip_credit=True)

            for name, (obs, site) in observables.items():
                values_dict[name].append(sim.expectation_value(state, obs, site))

            if measure:
                meng = MeasurementEngine(state)
                for name, (site, outcome_key) in measure.items():
                    mres = meng.measure_qubit(site, collapse=False)
                    if outcome_key == 'prob0':
                        values_dict[name].append(mres.prob0)
                    elif outcome_key == 'prob1':
                        values_dict[name].append(mres.prob1)
                    else:
                        raise ValueError(
                            f"Unknown outcome_key {outcome_key!r} for '{name}'. "
                            "Use 'prob0' or 'prob1'."
                        )

            if self.verbose:
                print(f"done (trunc_err={state.total_truncation_error():.2e})")

        return self._extrapolator._run_multi(bond_dims, values_dict)
