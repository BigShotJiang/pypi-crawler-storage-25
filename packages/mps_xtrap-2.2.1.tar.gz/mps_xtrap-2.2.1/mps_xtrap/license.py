"""
mps_xtrap License & Access Control
=====================================
Subscription-based credit system for mps_xtrap simulator access.

Access Tiers
------------
  FREE TRIAL  - 20 simulation runs per calendar month (auto-resets)
  SUBSCRIBED  - Unlimited runs per month upon valid activation key

To upgrade:
  1. Pay $15/month via: https://flutterwave.com/pay/6yptuvqab8cu
  2. Email proof of payment to: oscinspire@gmail.com
  3. Receive your activation key and unlock unlimited access.

Usage
-----
  from mps_xtrap.license import activate, show_status
  activate("XXXX-XXXX-XXXX-XXXX")   # activate with your key
  show_status()                       # view current credit status
"""

from __future__ import annotations

import hashlib
import hmac
import json
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FREE_MONTHLY_CREDITS = 20
_STORAGE_DIR = Path.home() / ".mps_xtrap"
_STATE_FILE  = _STORAGE_DIR / "license.json"

_HMAC_SECRET  = b"mps_xtrap_2025_osc_inspire_secret_v1"
PAYMENT_LINK  = "https://flutterwave.com/pay/6yptuvqab8cu"
SUPPORT_EMAIL = "oscinspire@gmail.com"

_WARN_AT = {10, 5, 3, 2, 1}   # remaining-credit thresholds for nudge messages

# ---------------------------------------------------------------------------
# Messaging helpers
# ---------------------------------------------------------------------------

def _line(text="", width=64):
    pad = width - len(text)
    return "║ " + text + " " * max(pad - 1, 0) + "║"

def _sep(width=64):
    return "╠" + "═" * width + "╣"

def _top(width=64):
    return "╔" + "═" * width + "╗"

def _bot(width=64):
    return "╚" + "═" * width + "╝"

W = 64   # inner width of all message boxes

# ── Welcome (first-ever run) ───────────────────────────────────────────────
MSG_WELCOME = "\n".join([
    _top(W),
    _line("  Welcome to mps_xtrap!  🎉", W),
    _sep(W),
    _line("  You have 20 FREE simulation runs per calendar month.", W),
    _line("  Credits reset automatically on the 1st of each month.", W),
    _sep(W),
    _line("  WANT UNLIMITED ACCESS? — only $15 / month", W),
    _line("", W),
    _line("  HOW TO SUBSCRIBE:", W),
    _line("  ─────────────────", W),
    _line("  STEP 1:  Visit the payment link below and pay $15:", W),
    _line("  " + PAYMENT_LINK, W),
    _line("", W),
    _line("  STEP 2:  Email a screenshot or receipt of your payment to:", W),
    _line("  " + SUPPORT_EMAIL, W),
    _line("", W),
    _line("  STEP 3:  You will receive an activation key by email.", W),
    _line("  Enter it in Python like this:", W),
    _line("", W),
    _line("       from mps_xtrap.license import activate", W),
    _line('       activate("XXXX-XXXX-XXXX-XXXX")', W),
    _sep(W),
    _line("  Check your credit balance at any time:", W),
    _line("       from mps_xtrap.license import show_status", W),
    _line("       show_status()", W),
    _bot(W),
])

# ── Per-run credit tick (inline, one line) ─────────────────────────────────
def msg_credit_tick(remaining, month):
    bar = chr(0x2588) * remaining + chr(0x2591) * (FREE_MONTHLY_CREDITS - remaining)
    return (
        f"  [mps_xtrap] Run recorded. "
        f"{remaining}/{FREE_MONTHLY_CREDITS} free credits left this month ({month})  "
        f"|{bar}|"
    )

# ── Low-credit nudge ───────────────────────────────────────────────────────
def msg_low_credit(remaining):
    s = "run" if remaining == 1 else "runs"
    return "\n".join([
        _top(W),
        _line(f"  ⚠  Only {remaining} free {s} remaining this month!", W),
        _sep(W),
        _line("  Upgrade to UNLIMITED for $15/month — don't get cut off:", W),
        _line("", W),
        _line("  STEP 1:  Pay at:", W),
        _line("  " + PAYMENT_LINK, W),
        _line("", W),
        _line("  STEP 2:  Email your payment proof to:", W),
        _line("  " + SUPPORT_EMAIL, W),
        _line("", W),
        _line("  STEP 3:  Activate the key you receive:", W),
        _line("       from mps_xtrap.license import activate", W),
        _line('       activate("XXXX-XXXX-XXXX-XXXX")', W),
        _bot(W),
    ])

# ── Exhausted (blocking) ───────────────────────────────────────────────────
def msg_exhausted(used, month):
    return "\n".join([
        _top(W),
        _line(f"  ✗  FREE TRIAL LIMIT REACHED  ({used}/{FREE_MONTHLY_CREDITS} runs used in {month})", W),
        _sep(W),
        _line("  Your free credits are used up for this month.", W),
        _line("  They will reset automatically on the 1st of next month.", W),
        _line("  OR subscribe now for unlimited access:", W),
        _sep(W),
        _line("  STEP 1 — Click or copy this payment link and pay $15:", W),
        _line("", W),
        _line("  " + PAYMENT_LINK, W),
        _line("", W),
        _sep(W),
        _line("  STEP 2 — Email a screenshot or receipt of your payment:", W),
        _line("", W),
        _line("  " + SUPPORT_EMAIL, W),
        _line("", W),
        _sep(W),
        _line("  STEP 3 — You will receive an activation key by email.", W),
        _line("  Paste it into Python like this:", W),
        _line("", W),
        _line("       from mps_xtrap.license import activate", W),
        _line('       activate("XXXX-XXXX-XXXX-XXXX")', W),
        _line("", W),
        _sep(W),
        _line("  Questions or issues?  Contact us at:", W),
        _line("  " + SUPPORT_EMAIL, W),
        _bot(W),
    ])

# ── Activation success ─────────────────────────────────────────────────────
MSG_ACTIVATED = "\n".join([
    _top(W),
    _line("  ✓  ACTIVATION SUCCESSFUL — Welcome to Unlimited!  🚀", W),
    _sep(W),
    _line("  You now have UNLIMITED simulation runs every month.", W),
    _line("  No credit limits. No interruptions.", W),
    _sep(W),
    _line("  Your subscription renews monthly. To manage it, contact:", W),
    _line("  " + SUPPORT_EMAIL, W),
    _sep(W),
    _line("  Check your status anytime:", W),
    _line("       from mps_xtrap.license import show_status", W),
    _line("       show_status()", W),
    _bot(W),
])

# ── Activation failure ─────────────────────────────────────────────────────
def msg_invalid_key(snippet):
    return "\n".join([
        _top(W),
        _line("  ✗  ACTIVATION FAILED — Key not recognised", W),
        _sep(W),
        _line(f"  Key entered: {snippet}", W),
        _sep(W),
        _line("  Possible reasons:", W),
        _line("  • Typo or copy/paste error — check dashes and spacing", W),
        _line("  • Key may have already been used or is for another version", W),
        _sep(W),
        _line("  To get a valid key:", W),
        _line("  1.  Pay $15 at:  " + PAYMENT_LINK, W),
        _line("  2.  Email proof to:  " + SUPPORT_EMAIL, W),
        _line("  3.  You will receive your key by email", W),
        _sep(W),
        _line("  Already paid and have a key?  Double-check and try again.", W),
        _line("  Still stuck?  Email us:  " + SUPPORT_EMAIL, W),
        _bot(W),
    ])


# ---------------------------------------------------------------------------
# Key validation
# ---------------------------------------------------------------------------

def _verify_key(key):
    key = key.strip().upper()
    parts = key.split("-")
    if len(parts) != 4:
        return False
    try:
        prefix       = "-".join(parts[:3])
        supplied_sig = parts[3]
        expected_sig = hmac.new(
            _HMAC_SECRET, prefix.encode("utf-8"), hashlib.sha256
        ).hexdigest()[:8].upper()
        return hmac.compare_digest(supplied_sig, expected_sig)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Persistent state helpers
# ---------------------------------------------------------------------------

def _load_state():
    _STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    if _STATE_FILE.exists():
        try:
            with open(_STATE_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return {}

def _save_state(state):
    _STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    with open(_STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def _month_key():
    now = datetime.now(timezone.utc)
    return f"{now.year}-{now.month:02d}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def activate(key):
    """
    Activate mps_xtrap with a subscription key for unlimited access.

    Parameters
    ----------
    key : str
        The activation key received by email after subscribing.

    Returns
    -------
    bool
        True if activation succeeded, False otherwise.

    Example
    -------
    >>> from mps_xtrap.license import activate
    >>> activate("AABBCC-DDEEFF-GGHH11-3BA175CE")
    """
    key = key.strip().upper()
    if _verify_key(key):
        state = _load_state()
        state["activation_key"] = key
        state["activated_at"]   = datetime.now(timezone.utc).isoformat()
        _save_state(state)
        print()
        print(MSG_ACTIVATED)
        print()
        return True
    else:
        snippet = (key[:22] + "...") if len(key) > 22 else key
        print()
        print(msg_invalid_key(snippet))
        print()
        return False


def deactivate():
    """Remove the stored activation key, reverting to the free trial tier."""
    state = _load_state()
    state.pop("activation_key", None)
    state.pop("activated_at",   None)
    _save_state(state)
    print("\n  mps_xtrap: Activation key removed. Reverted to free trial.\n")


def show_status():
    """
    Print your current license tier and remaining simulation credits.

    Example
    -------
    >>> from mps_xtrap.license import show_status
    >>> show_status()
    """
    state     = _load_state()
    month     = _month_key()
    key       = state.get("activation_key", "")
    is_sub    = bool(key) and _verify_key(key)
    used      = state.get("credits_used", {}).get(month, 0)
    remaining = max(0, FREE_MONTHLY_CREDITS - used)
    bar_on    = chr(0x2588)
    bar_off   = chr(0x2591)

    print()
    print(_top(W))
    print(_line("  mps_xtrap — License & Credit Status", W))
    print(_sep(W))

    if is_sub:
        since = state.get("activated_at", "")[:10]
        print(_line("  Tier    :  SUBSCRIBED  (Unlimited runs)", W))
        print(_line(f"  Key     :  {key[:18]}...", W))
        print(_line(f"  Since   :  {since}", W))
        print(_sep(W))
        print(_line("  You have unlimited simulation runs — enjoy!", W))
    else:
        bar = bar_on * remaining + bar_off * (FREE_MONTHLY_CREDITS - remaining)
        print(_line("  Tier      :  FREE TRIAL", W))
        print(_line(f"  Month     :  {month}", W))
        print(_line(f"  Used      :  {used} / {FREE_MONTHLY_CREDITS} runs", W))
        print(_line(f"  Remaining :  {remaining} runs  |{bar}|", W))
        print(_sep(W))
        print(_line("  Upgrade to Unlimited — $15 / month:", W))
        print(_line("  1.  Pay at:  " + PAYMENT_LINK, W))
        print(_line("  2.  Email proof to:  " + SUPPORT_EMAIL, W))
        print(_line("  3.  You receive a key — activate it with:", W))
        print(_line("       from mps_xtrap.license import activate", W))
        print(_line('       activate("XXXX-XXXX-XXXX-XXXX")', W))

    print(_bot(W))
    print()


# ---------------------------------------------------------------------------
# Internal credit gate
# ---------------------------------------------------------------------------

def _check_and_consume_credit(n_credits=1):
    """
    Called automatically before every simulation run.

    Behaviour
    ---------
    Subscribed    : silent pass-through.
    Free, 1st run : prints Welcome box, then credit tick.
    Free, credit  : prints one-line tick; prints nudge box at 10/5/3/2/1 left.
    Free, no credit: raises CreditExhaustedError with full step-by-step guidance.
    """
    state = _load_state()
    month = _month_key()
    key   = state.get("activation_key", "")

    if key and _verify_key(key):
        return  # subscribed — no tracking needed

    credits_used     = state.setdefault("credits_used", {})
    used_this_month  = credits_used.get(month, 0)
    is_first_ever    = not state.get("seen_welcome", False)

    # Hard limit check (before consuming)
    if used_this_month + n_credits > FREE_MONTHLY_CREDITS:
        raise CreditExhaustedError(
            "\n\n" + msg_exhausted(used_this_month, month)
        )

    # Consume
    credits_used[month] = used_this_month + n_credits
    remaining = FREE_MONTHLY_CREDITS - credits_used[month]

    if is_first_ever:
        state["seen_welcome"] = True
        _save_state(state)
        print()
        print(MSG_WELCOME)
        print()
    else:
        _save_state(state)

    # One-line tick
    print(msg_credit_tick(remaining, month))

    # Nudge box at key thresholds
    if remaining in _WARN_AT:
        print()
        print(msg_low_credit(remaining))
        print()


class CreditExhaustedError(RuntimeError):
    """Raised when the free-trial monthly credit limit is reached."""
    pass
