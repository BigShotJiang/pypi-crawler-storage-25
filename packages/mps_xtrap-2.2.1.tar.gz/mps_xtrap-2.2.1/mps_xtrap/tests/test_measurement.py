"""
Tests for the v2.2.0 qubit measurement feature.

Covers:
- Projector operator correctness
- Single-qubit measurement probabilities vs exact state vector
- Probability normalization (prob0 + prob1 == 1)
- Post-measurement state collapse and renormalization
- Multi-qubit joint probabilities and marginals
- Joint probability sum-to-one
- sample_counts Born-rule accuracy
- full_distribution correctness
- Richardson extrapolation of probabilities via MultiChiRunner.run(measure=...)
- MeasurementEngine on known states (|0>, |1>, |+>, Bell)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import unittest

from mps_xtrap import (
    Circuit, MPSSimulator, MPS, SweepConfig, MultiChiRunner,
    projector, P0, P1,
    MeasurementEngine,
    SingleMeasurementResult, MultiQubitMeasurementResult, SampledCounts,
    measure_qubit, measure_qubits, sample_counts, full_distribution,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_state(circuit: Circuit, chi: int = 256) -> MPS:
    return MPSSimulator(chi=chi).run(circuit)


def bell_state() -> MPS:
    """Return (|00> + |11>) / sqrt(2) as MPS."""
    c = Circuit(2)
    c.h(0).cx(0, 1)
    return make_state(c)


def product_plus() -> MPS:
    """Return |+> ⊗ |+> = H|0> ⊗ H|0>."""
    c = Circuit(2)
    c.h(0).h(1)
    return make_state(c)


def state_zero(n: int = 2) -> MPS:
    """Return |00...0>."""
    return MPS(n, chi=4)


def state_one(site: int, n: int = 4) -> MPS:
    """Return |0...010...0> with X on `site`."""
    c = Circuit(n)
    c.x(site)
    return make_state(c)


# ---------------------------------------------------------------------------
# Projector operator tests
# ---------------------------------------------------------------------------

class TestProjectors(unittest.TestCase):

    def test_p0_matrix(self):
        P = projector(0)
        expected = np.array([[1, 0], [0, 0]], dtype=complex)
        np.testing.assert_allclose(P, expected)

    def test_p1_matrix(self):
        P = projector(1)
        expected = np.array([[0, 0], [0, 1]], dtype=complex)
        np.testing.assert_allclose(P, expected)

    def test_p0_is_projector(self):
        P = projector(0)
        np.testing.assert_allclose(P @ P, P, atol=1e-15)

    def test_p1_is_projector(self):
        P = projector(1)
        np.testing.assert_allclose(P @ P, P, atol=1e-15)

    def test_p0_p1_sum_to_identity(self):
        np.testing.assert_allclose(P0 + P1, np.eye(2, dtype=complex), atol=1e-15)

    def test_invalid_outcome(self):
        with self.assertRaises(ValueError):
            projector(2)

    def test_module_level_constants(self):
        np.testing.assert_allclose(P0, projector(0))
        np.testing.assert_allclose(P1, projector(1))


# ---------------------------------------------------------------------------
# Single-qubit measurement on known states
# ---------------------------------------------------------------------------

class TestSingleQubitMeasurement(unittest.TestCase):

    def test_zero_state_prob0_is_1(self):
        state = state_zero(n=3)
        for site in range(3):
            res = measure_qubit(state, site)
            self.assertAlmostEqual(res.prob0, 1.0, places=10)
            self.assertAlmostEqual(res.prob1, 0.0, places=10)

    def test_x_gate_flips_to_one(self):
        """After X gate, qubit should measure |1> with probability 1."""
        state = state_one(0, n=3)
        res = measure_qubit(state, 0)
        self.assertAlmostEqual(res.prob1, 1.0, places=10)
        self.assertAlmostEqual(res.prob0, 0.0, places=10)

    def test_hadamard_equal_superposition(self):
        """H|0> gives prob0 = prob1 = 0.5."""
        c = Circuit(1)
        c.h(0)
        state = make_state(c)
        res = measure_qubit(state, 0)
        self.assertAlmostEqual(res.prob0, 0.5, places=10)
        self.assertAlmostEqual(res.prob1, 0.5, places=10)

    def test_normalization_always_sums_to_one(self):
        """prob0 + prob1 == 1 for any state."""
        for circuit_fn in [
            lambda: Circuit(4).h(0).cx(0, 1).cx(1, 2).cx(2, 3),
            lambda: Circuit(4).rx(0.7, 0).ry(1.3, 1).rz(0.4, 2),
            lambda: Circuit(4).h(0).h(1).h(2).h(3),
        ]:
            c = circuit_fn()
            state = make_state(c)
            for site in range(4):
                res = measure_qubit(state, site)
                total = res.prob0 + res.prob1
                self.assertAlmostEqual(total, 1.0, places=10,
                    msg=f"prob0+prob1={total} at site {site}")

    def test_prob_matches_projector_expectation(self):
        """P(0) should equal <psi|P0|psi> computed directly."""
        c = Circuit(3)
        c.ry(0.8, 0).ry(1.2, 1).cx(0, 1).ry(0.4, 2)
        state = make_state(c)
        for site in range(3):
            res = measure_qubit(state, site)
            # Direct projector expectation value
            direct_p0 = float(np.real(state.expectation_single(P0, site)))
            direct_p1 = float(np.real(state.expectation_single(P1, site)))
            self.assertAlmostEqual(res.prob0, direct_p0, places=12)
            self.assertAlmostEqual(res.prob1, direct_p1, places=12)

    def test_prob_matches_statevector(self):
        """Probabilities match |amplitude|^2 from the statevector."""
        c = Circuit(4)
        c.h(0).cx(0, 1).ry(0.7, 2).cx(1, 2).h(3)
        state = make_state(c)
        sv = state.to_statevector()
        n = 4

        for site in range(n):
            # Exact probability from statevector
            exact_p0 = sum(
                abs(sv[i]) ** 2
                for i in range(2 ** n)
                if not ((i >> (n - 1 - site)) & 1)
            )
            res = measure_qubit(state, site)
            self.assertAlmostEqual(res.prob0, exact_p0, places=10,
                msg=f"site={site}: prob0={res.prob0}, exact={exact_p0}")

    def test_result_summary_string(self):
        state = state_zero(2)
        res = measure_qubit(state, 0)
        s = res.summary()
        self.assertIn("P(0)", s)
        self.assertIn("P(1)", s)

    def test_most_likely_zero_state(self):
        state = state_zero(2)
        res = measure_qubit(state, 0)
        self.assertEqual(res.most_likely(), 0)

    def test_most_likely_one_state(self):
        state = state_one(1, n=3)
        res = measure_qubit(state, 1)
        self.assertEqual(res.most_likely(), 1)


# ---------------------------------------------------------------------------
# Post-measurement collapse
# ---------------------------------------------------------------------------

class TestCollapse(unittest.TestCase):

    def test_collapse_zero_state_to_zero(self):
        """Collapsing |0> to outcome 0 should give a valid normalized state."""
        state = state_zero(2)
        res = measure_qubit(state, 0, collapse=True)
        self.assertIsNotNone(res.post_state_0)
        # Post-collapse state norm should be 1
        norm = res.post_state_0._norm_mps()
        self.assertAlmostEqual(norm, 1.0, places=10)

    def test_collapse_zero_state_outcome_1_is_none(self):
        """Outcome 1 from |0> has prob=0, so post_state_1 is None."""
        state = state_zero(2)
        res = measure_qubit(state, 0, collapse=True)
        self.assertIsNone(res.post_state_1)

    def test_collapse_hadamard_both_states(self):
        """H|0> collapses to either |0> or |1> with equal probability."""
        c = Circuit(2)
        c.h(0)
        state = make_state(c)
        res = measure_qubit(state, 0, collapse=True)
        self.assertIsNotNone(res.post_state_0)
        self.assertIsNotNone(res.post_state_1)
        # Both collapsed states should be normalized
        self.assertAlmostEqual(res.post_state_0._norm_mps(), 1.0, places=10)
        self.assertAlmostEqual(res.post_state_1._norm_mps(), 1.0, places=10)

    def test_collapse_post_state_probabilities(self):
        """After collapsing to |0>, remeasuring site 0 should give P(0)=1."""
        c = Circuit(3)
        c.h(0).ry(0.5, 1)
        state = make_state(c)
        res = measure_qubit(state, 0, collapse=True)
        if res.post_state_0 is not None:
            re_res = measure_qubit(res.post_state_0, 0)
            self.assertAlmostEqual(re_res.prob0, 1.0, places=10)
        if res.post_state_1 is not None:
            re_res = measure_qubit(res.post_state_1, 0)
            self.assertAlmostEqual(re_res.prob1, 1.0, places=10)

    def test_bell_state_anticorrelated_collapse(self):
        """
        Bell state (|00>+|11>)/sqrt(2):
        - Measuring qubit 0 gives P(0)=P(1)=0.5
        - After collapsing qubit 0 to 0, qubit 1 must be 0 with prob 1.
        - After collapsing qubit 0 to 1, qubit 1 must be 1 with prob 1.
        """
        state = bell_state()
        res = measure_qubit(state, 0, collapse=True)
        self.assertAlmostEqual(res.prob0, 0.5, places=10)
        self.assertAlmostEqual(res.prob1, 0.5, places=10)

        # After collapse to |0>, qubit 1 should be |0>
        if res.post_state_0 is not None:
            res1 = measure_qubit(res.post_state_0, 1)
            self.assertAlmostEqual(res1.prob0, 1.0, places=8)

        # After collapse to |1>, qubit 1 should be |1>
        if res.post_state_1 is not None:
            res1 = measure_qubit(res.post_state_1, 1)
            self.assertAlmostEqual(res1.prob1, 1.0, places=8)


# ---------------------------------------------------------------------------
# Multi-qubit joint measurement
# ---------------------------------------------------------------------------

class TestMultiQubitMeasurement(unittest.TestCase):

    def test_joint_probs_sum_to_one(self):
        """Sum of all joint probabilities should be 1."""
        state = bell_state()
        res = measure_qubits(state, [0, 1])
        total = sum(res.probabilities.values())
        self.assertAlmostEqual(total, 1.0, places=10)

    def test_bell_state_joint_probs(self):
        """Bell state: only |00> and |11> have nonzero probability."""
        state = bell_state()
        res = measure_qubits(state, [0, 1])
        self.assertAlmostEqual(res.probabilities[(0, 0)], 0.5, places=10)
        self.assertAlmostEqual(res.probabilities[(1, 1)], 0.5, places=10)
        self.assertAlmostEqual(res.probabilities[(0, 1)], 0.0, places=10)
        self.assertAlmostEqual(res.probabilities[(1, 0)], 0.0, places=10)

    def test_product_state_independent(self):
        """For |+>⊗|+>, all four outcomes should have prob=0.25."""
        state = product_plus()
        res = measure_qubits(state, [0, 1])
        for bits, prob in res.probabilities.items():
            self.assertAlmostEqual(prob, 0.25, places=10,
                msg=f"|{bits[0]}{bits[1]}> prob={prob}")

    def test_marginals_consistent_with_single(self):
        """Marginals from measure_qubits should match measure_qubit."""
        c = Circuit(4)
        c.h(0).cx(0, 1).ry(0.6, 2).cx(1, 2)
        state = make_state(c)
        res = measure_qubits(state, [0, 1, 2])
        for site in [0, 1, 2]:
            single = measure_qubit(state, site)
            marg = res.marginals[site]
            self.assertAlmostEqual(marg.prob0, single.prob0, places=8,
                msg=f"site={site} marginal prob0")
            self.assertAlmostEqual(marg.prob1, single.prob1, places=8,
                msg=f"site={site} marginal prob1")

    def test_most_likely_bitstring(self):
        """Zero state should have |00...0> as most likely bitstring."""
        state = state_zero(3)
        res = measure_qubits(state, [0, 1, 2])
        self.assertEqual(res.most_likely_bitstring(), (0, 0, 0))

    def test_joint_probability_method(self):
        """joint_probability should match measure_qubits enumeration."""
        state = bell_state()
        engine = MeasurementEngine(state)
        res = measure_qubits(state, [0, 1])
        for bits, prob_enum in res.probabilities.items():
            prob_direct = engine.joint_probability([0, 1], list(bits))
            self.assertAlmostEqual(prob_direct, prob_enum, places=10,
                msg=f"bits={bits}")

    def test_summary_string(self):
        state = bell_state()
        res = measure_qubits(state, [0, 1])
        s = res.summary()
        self.assertIn("00", s)
        self.assertIn("11", s)

    def test_joint_matches_statevector(self):
        """Joint probabilities match |amp|^2 from statevector contraction."""
        c = Circuit(3)
        c.h(0).cx(0, 1).ry(0.9, 2)
        state = make_state(c)
        sv = state.to_statevector()
        n = 3

        res = measure_qubits(state, [0, 1, 2])
        for bits, prob in res.probabilities.items():
            # Exact probability: sum |sv[i]|^2 where bits match
            idx = sum(b << (n - 1 - s) for s, b in enumerate(bits))
            exact = abs(sv[idx]) ** 2
            self.assertAlmostEqual(prob, exact, places=10,
                msg=f"bits={bits}: mps={prob:.8f}, exact={exact:.8f}")

    def test_empty_sites_raises(self):
        state = state_zero(2)
        with self.assertRaises(ValueError):
            measure_qubits(state, [])

    def test_too_many_sites_raises(self):
        state = MPS(25, chi=4)
        with self.assertRaises(ValueError):
            measure_qubits(state, list(range(21)))


# ---------------------------------------------------------------------------
# sample_counts
# ---------------------------------------------------------------------------

class TestSampleCounts(unittest.TestCase):

    def test_zero_state_all_zeros(self):
        """Measuring |00...0> should always yield '000'."""
        state = state_zero(3)
        sc = sample_counts(state, [0, 1, 2], shots=50, seed=0)
        self.assertEqual(sc.counts.get('000', 0), 50)

    def test_one_state_all_ones(self):
        """After X on all qubits, should always yield '111'."""
        c = Circuit(3)
        c.x(0).x(1).x(2)
        state = make_state(c)
        sc = sample_counts(state, [0, 1, 2], shots=50, seed=0)
        self.assertEqual(sc.counts.get('111', 0), 50)

    def test_shot_count_matches(self):
        state = bell_state()
        sc = sample_counts(state, [0, 1], shots=200, seed=42)
        self.assertEqual(sc.shots, 200)
        self.assertEqual(sum(sc.counts.values()), 200)

    def test_bell_only_00_and_11(self):
        """Bell state samples should only be '00' or '11'."""
        state = bell_state()
        sc = sample_counts(state, [0, 1], shots=500, seed=7)
        for bs in sc.counts:
            self.assertIn(bs, ('00', '11'),
                msg=f"Unexpected bitstring '{bs}' from Bell state")

    def test_hadamard_empirical_probabilities(self):
        """H|0> should give ~50% '0' and ~50% '1' over many shots."""
        c = Circuit(1)
        c.h(0)
        state = make_state(c)
        sc = sample_counts(state, [0], shots=2000, seed=123)
        p0 = sc.counts.get('0', 0) / sc.shots
        p1 = sc.counts.get('1', 0) / sc.shots
        # Allow ±5% tolerance (very loose for unit test)
        self.assertAlmostEqual(p0, 0.5, delta=0.05)
        self.assertAlmostEqual(p1, 0.5, delta=0.05)

    def test_reproducible_with_seed(self):
        """Same seed should give identical counts."""
        c = Circuit(3)
        c.h(0).cx(0, 1).ry(0.5, 2)
        state = make_state(c)
        sc1 = sample_counts(state, [0, 1, 2], shots=100, seed=99)
        sc2 = sample_counts(state, [0, 1, 2], shots=100, seed=99)
        self.assertEqual(sc1.counts, sc2.counts)

    def test_different_seeds_different_counts(self):
        """Different seeds should (very likely) give different counts."""
        c = Circuit(2)
        c.h(0).h(1)
        state = make_state(c)
        sc1 = sample_counts(state, [0, 1], shots=50, seed=1)
        sc2 = sample_counts(state, [0, 1], shots=50, seed=2)
        # It's theoretically possible they match, but astronomically unlikely
        self.assertNotEqual(sc1.counts, sc2.counts)

    def test_sampled_counts_summary(self):
        state = bell_state()
        sc = sample_counts(state, [0, 1], shots=100, seed=0)
        s = sc.summary()
        self.assertIn("shots=100", s)

    def test_empirical_probs_method(self):
        state = state_zero(2)
        sc = sample_counts(state, [0, 1], shots=100, seed=0)
        probs = sc.probabilities()
        self.assertAlmostEqual(probs.get('00', 0.0), 1.0, places=10)


# ---------------------------------------------------------------------------
# full_distribution
# ---------------------------------------------------------------------------

class TestFullDistribution(unittest.TestCase):

    def test_zero_state_distribution(self):
        state = state_zero(3)
        dist = full_distribution(state)
        self.assertAlmostEqual(dist['000'], 1.0, places=12)
        for bs, p in dist.items():
            if bs != '000':
                self.assertAlmostEqual(p, 0.0, places=12)

    def test_bell_state_distribution(self):
        state = bell_state()
        dist = full_distribution(state)
        self.assertAlmostEqual(dist['00'], 0.5, places=10)
        self.assertAlmostEqual(dist['11'], 0.5, places=10)
        self.assertAlmostEqual(dist['01'], 0.0, places=10)
        self.assertAlmostEqual(dist['10'], 0.0, places=10)

    def test_distribution_sums_to_one(self):
        c = Circuit(4)
        c.h(0).cx(0, 1).ry(0.8, 2).cx(2, 3)
        state = make_state(c)
        dist = full_distribution(state)
        self.assertAlmostEqual(sum(dist.values()), 1.0, places=10)

    def test_distribution_keys_are_bitstrings(self):
        state = state_zero(3)
        dist = full_distribution(state)
        self.assertEqual(len(dist), 2 ** 3)
        for bs in dist:
            self.assertEqual(len(bs), 3)
            self.assertTrue(all(c in '01' for c in bs))

    def test_distribution_matches_statevector(self):
        """full_distribution should match |sv|^2 exactly."""
        c = Circuit(4)
        c.h(0).cx(0, 1).ry(1.1, 2).cx(1, 2).h(3)
        state = make_state(c)
        sv = state.to_statevector()
        dist = full_distribution(state)
        n = 4
        for i, p_exact in enumerate(np.abs(sv) ** 2):
            bs = format(i, f'0{n}b')
            self.assertAlmostEqual(dist[bs], float(p_exact), places=10,
                msg=f"|{bs}> dist={dist[bs]:.8f}, exact={p_exact:.8f}")

    def test_too_large_raises(self):
        state = MPS(25, chi=4)
        with self.assertRaises(ValueError):
            full_distribution(state)


# ---------------------------------------------------------------------------
# MeasurementEngine on known states
# ---------------------------------------------------------------------------

class TestMeasurementEngine(unittest.TestCase):

    def test_ry_rotation_probability(self):
        """
        Ry(theta)|0> gives:
          prob0 = cos(theta/2)^2
          prob1 = sin(theta/2)^2
        """
        import math
        for theta in [0.0, 0.3, np.pi / 4, np.pi / 2, np.pi, 1.7]:
            c = Circuit(1)
            c.ry(theta, 0)
            state = make_state(c)
            res = measure_qubit(state, 0)
            expected_p0 = math.cos(theta / 2) ** 2
            expected_p1 = math.sin(theta / 2) ** 2
            self.assertAlmostEqual(res.prob0, expected_p0, places=10,
                msg=f"theta={theta}: prob0={res.prob0}, expected={expected_p0}")
            self.assertAlmostEqual(res.prob1, expected_p1, places=10,
                msg=f"theta={theta}: prob1={res.prob1}, expected={expected_p1}")

    def test_rx_probability(self):
        """Rx(theta)|0> gives prob1 = sin(theta/2)^2."""
        import math
        for theta in [np.pi / 3, np.pi / 2, np.pi]:
            c = Circuit(1)
            c.rx(theta, 0)
            state = make_state(c)
            res = measure_qubit(state, 0)
            expected_p1 = math.sin(theta / 2) ** 2
            self.assertAlmostEqual(res.prob1, expected_p1, places=10,
                msg=f"Rx({theta}): prob1={res.prob1}, expected={expected_p1}")

    def test_site_out_of_range(self):
        state = state_zero(3)
        with self.assertRaises(ValueError):
            measure_qubit(state, 3)
        with self.assertRaises(ValueError):
            measure_qubit(state, -1)


# ---------------------------------------------------------------------------
# Richardson extrapolation of probabilities via MultiChiRunner
# ---------------------------------------------------------------------------

class TestExtrapolatedMeasurement(unittest.TestCase):

    def test_runner_measure_kwarg_accepted(self):
        """MultiChiRunner.run should accept a measure= dict without error."""
        c = Circuit(3)
        c.h(0).cx(0, 1).cx(1, 2)
        cfg = SweepConfig(base_chi=8, scaling_factor=2.0, n_levels=3)
        runner = MultiChiRunner(cfg, verbose=False)
        result = runner.run(
            c,
            observables={'Z0': ('Z', 0)},
            measure={'P0_q0': (0, 'prob0'), 'P1_q0': (0, 'prob1')},
        )
        self.assertIn('Z0', result.observables)
        self.assertIn('P0_q0', result.observables)
        self.assertIn('P1_q0', result.observables)

    def test_extrapolated_probs_in_range(self):
        """Extrapolated probabilities should be in [0, 1] (approximately)."""
        c = Circuit(4)
        c.h(0).cx(0, 1).cx(1, 2).cx(2, 3)
        cfg = SweepConfig(base_chi=8, scaling_factor=2.0, n_levels=3)
        runner = MultiChiRunner(cfg, verbose=False)
        result = runner.run(
            c,
            measure={'P0_q0': (0, 'prob0'), 'P1_q0': (0, 'prob1')},
        )
        p0 = result.observables['P0_q0'].extrapolated
        p1 = result.observables['P1_q0'].extrapolated
        # GHZ-like state: P(0) ≈ P(1) ≈ 0.5
        self.assertAlmostEqual(p0, 0.5, delta=0.05)
        self.assertAlmostEqual(p1, 0.5, delta=0.05)

    def test_extrapolated_probs_sum_to_one(self):
        """Extrapolated P(0) + P(1) should be close to 1."""
        c = Circuit(3)
        c.ry(0.7, 0).cx(0, 1).ry(1.1, 2)
        cfg = SweepConfig(base_chi=8, scaling_factor=2.0, n_levels=3)
        runner = MultiChiRunner(cfg, verbose=False)
        result = runner.run(
            c,
            measure={
                'P0_q1': (1, 'prob0'),
                'P1_q1': (1, 'prob1'),
            },
        )
        p0 = result.observables['P0_q1'].extrapolated
        p1 = result.observables['P1_q1'].extrapolated
        self.assertAlmostEqual(p0 + p1, 1.0, delta=0.01,
            msg=f"P0+P1={p0+p1} should be close to 1")

    def test_extrapolated_zero_state_prob0_is_one(self):
        """Zero state: extrapolated P(0) should be 1 at any chi."""
        c = Circuit(3)  # identity — stays in |000>
        cfg = SweepConfig(base_chi=4, scaling_factor=2.0, n_levels=3)
        runner = MultiChiRunner(cfg, verbose=False)
        result = runner.run(
            c,
            measure={'P0_q0': (0, 'prob0')},
        )
        p0 = result.observables['P0_q0'].extrapolated
        self.assertAlmostEqual(p0, 1.0, delta=1e-6)

    def test_measure_only_no_observables(self):
        """measure= works without any observables= dict."""
        c = Circuit(2)
        c.h(0).cx(0, 1)
        cfg = SweepConfig(base_chi=8, scaling_factor=2.0, n_levels=3)
        runner = MultiChiRunner(cfg, verbose=False)
        result = runner.run(c, measure={'P1_q1': (1, 'prob1')})
        self.assertIn('P1_q1', result.observables)

    def test_invalid_outcome_key_raises(self):
        """Invalid outcome_key in measure= should raise ValueError."""
        c = Circuit(2)
        c.h(0)
        cfg = SweepConfig(base_chi=4, scaling_factor=2.0, n_levels=2)
        runner = MultiChiRunner(cfg, verbose=False)
        with self.assertRaises(ValueError):
            runner.run(c, measure={'bad': (0, 'probX')})

    def test_extrapolation_result_has_raw_values(self):
        """ExtrapolationResult for a probability should have n_levels raw values."""
        c = Circuit(2)
        c.h(0).cx(0, 1)
        n_levels = 3
        cfg = SweepConfig(base_chi=8, scaling_factor=2.0, n_levels=n_levels)
        runner = MultiChiRunner(cfg, verbose=False)
        result = runner.run(c, measure={'P0_q0': (0, 'prob0')})
        self.assertEqual(len(result.observables['P0_q0'].raw_values), n_levels)

    def test_combined_observables_and_measure(self):
        """Simultaneous observables and measure should both appear in results."""
        c = Circuit(4)
        c.h(0).cx(0, 1).cx(1, 2).ry(0.5, 3)
        cfg = SweepConfig(base_chi=8, scaling_factor=2.0, n_levels=3)
        runner = MultiChiRunner(cfg, verbose=False)
        result = runner.run(
            c,
            observables={'Z0': ('Z', 0), 'Z3': ('Z', 3)},
            measure={'P0_q2': (2, 'prob0'), 'P1_q2': (2, 'prob1')},
        )
        for key in ('Z0', 'Z3', 'P0_q2', 'P1_q2'):
            self.assertIn(key, result.observables)


# ---------------------------------------------------------------------------
# Version check
# ---------------------------------------------------------------------------

class TestVersion(unittest.TestCase):
    def test_version_is_220(self):
        import mps_xtrap
        self.assertEqual(mps_xtrap.__version__, "2.2.0")

    def test_measurement_in_top_level_namespace(self):
        import mps_xtrap
        for name in ('measure_qubit', 'measure_qubits', 'sample_counts',
                     'full_distribution', 'projector', 'P0', 'P1',
                     'MeasurementEngine', 'SingleMeasurementResult',
                     'MultiQubitMeasurementResult', 'SampledCounts'):
            self.assertTrue(hasattr(mps_xtrap, name),
                msg=f"mps_xtrap.{name} not found")


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    unittest.main(verbosity=2)
