"""
Test suite for mps_xtrap.

Tests cover:
- MPS initialization and basic operations
- Gate application correctness
- Single and two-qubit gate accuracy vs exact state vector
- Richardson extrapolation correctness and reliability diagnostics
- End-to-end circuit simulation
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import unittest

from mps_xtrap import Circuit, MPSSimulator, MPS, SweepConfig, MultiChiRunner
from mps_xtrap.extrapolation import _RichardsonExtrapolator
from mps_xtrap.gates import H, X, Y, Z, CNOT, CZ, Rx, Ry, Rz, get_gate


# ---------------------------------------------------------------------------
# Helper: run extrapolation directly via internal engine
# ---------------------------------------------------------------------------

def _run_extrap(chi_list, values, scaling_factor=2.0, alpha=None):
    """Convenience wrapper around the internal extrapolation engine."""
    ext = _RichardsonExtrapolator(scaling_factor=scaling_factor, alpha=alpha)
    return ext._run(chi_list, values)

def _run_extrap_multi(chi_list, values_dict, scaling_factor=2.0, alpha=None):
    ext = _RichardsonExtrapolator(scaling_factor=scaling_factor, alpha=alpha)
    return ext._run_multi(chi_list, values_dict)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def run_circuit_exact(circuit: Circuit) -> np.ndarray:
    """Run circuit with very large chi to get near-exact result."""
    sim = MPSSimulator(chi=512)
    state = sim.run(circuit)
    return state.to_statevector()


def exact_z_expectation(sv: np.ndarray, qubit: int, n: int) -> float:
    """Compute <Z_qubit> from statevector."""
    vals = []
    for i, amp in enumerate(sv):
        bit = (i >> (n - 1 - qubit)) & 1
        eigenval = 1 - 2 * bit
        vals.append(eigenval * abs(amp) ** 2)
    return float(np.real(sum(vals)))


# ---------------------------------------------------------------------------
# MPS initialization tests
# ---------------------------------------------------------------------------

class TestMPSInit(unittest.TestCase):
    def test_zero_state(self):
        mps = MPS(4, 32)
        sv = mps.to_statevector()
        assert abs(sv[0] - 1.0) < 1e-12, "Should start in |0000>"
        assert abs(np.linalg.norm(sv) - 1.0) < 1e-12

    def test_bond_dims_initial(self):
        mps = MPS(5, 32)
        bonds = mps.bond_dimensions()
        assert all(b == 1 for b in bonds), "Product state has all bond dims = 1"

    def test_norm_initial(self):
        mps = MPS(4, 32)
        assert abs(mps._norm_mps() - 1.0) < 1e-12

    def test_copy(self):
        mps = MPS(4, 32)
        mps2 = mps.copy()
        mps2.tensors[0] *= 2
        assert abs(mps.to_statevector()[0] - 1.0) < 1e-12

    def test_device_default_cpu(self):
        mps = MPS(4, 32)
        assert mps.device == 'cpu'

    def test_device_cuda_fallback(self):
        # No GPU in test env — should silently fall back to cpu
        mps = MPS(4, 32, device='cuda')
        assert mps.device == 'cpu'

    def test_to_device(self):
        mps = MPS(4, 32)
        mps2 = mps.to('cpu')
        assert mps2.device == 'cpu'


# ---------------------------------------------------------------------------
# Gate tests
# ---------------------------------------------------------------------------

class TestGates(unittest.TestCase):
    def test_h_gate_shape(self):
        assert H().shape == (2, 2)

    def test_h_unitary(self):
        h = H()
        assert np.allclose(h @ h.conj().T, np.eye(2))

    def test_cnot_shape(self):
        assert CNOT().shape == (2, 2, 2, 2)

    def test_rx_unitary(self):
        for theta in [0, np.pi/4, np.pi/2, np.pi]:
            rx = Rx(theta)
            assert np.allclose(rx @ rx.conj().T, np.eye(2))

    def test_get_gate_single(self):
        assert np.allclose(get_gate('H'), H())

    def test_get_gate_parametric(self):
        assert np.allclose(get_gate('Rx', np.pi / 3), Rx(np.pi / 3))

    def test_get_gate_two(self):
        assert get_gate('CNOT').shape == (2, 2, 2, 2)

    def test_get_gate_unknown(self):
        with self.assertRaises(ValueError):
            get_gate('NotAGate')


# ---------------------------------------------------------------------------
# Single-qubit gate application tests
# ---------------------------------------------------------------------------

class TestSingleQubitGates(unittest.TestCase):
    def _run_and_sv(self, circuit):
        return MPSSimulator(chi=64).run(circuit).to_statevector()

    def test_x_gate(self):
        c = Circuit(2); c.x(0)
        sv = self._run_and_sv(c)
        assert abs(sv[2] - 1.0) < 1e-12

    def test_h_gate_superposition(self):
        c = Circuit(1); c.h(0)
        sv = self._run_and_sv(c)
        assert abs(sv[0] - 1 / np.sqrt(2)) < 1e-12
        assert abs(sv[1] - 1 / np.sqrt(2)) < 1e-12

    def test_rx_rotation(self):
        c = Circuit(1); c.rx(np.pi, 0)
        sv = self._run_and_sv(c)
        assert abs(abs(sv[1]) - 1.0) < 1e-12

    def test_z_expectation_zero_state(self):
        state = MPSSimulator(chi=16).run(Circuit(3))
        assert abs(state.expectation_pauli_z(0) - 1.0) < 1e-12

    def test_z_expectation_after_x(self):
        c = Circuit(1); c.x(0)
        state = MPSSimulator(chi=16).run(c)
        assert abs(state.expectation_pauli_z(0) + 1.0) < 1e-12

    def test_x_expectation_after_h(self):
        c = Circuit(1); c.h(0)
        state = MPSSimulator(chi=16).run(c)
        assert abs(state.expectation_pauli_x(0) - 1.0) < 1e-12


# ---------------------------------------------------------------------------
# Two-qubit gate tests
# ---------------------------------------------------------------------------

class TestTwoQubitGates(unittest.TestCase):
    def _run_and_sv(self, circuit):
        return MPSSimulator(chi=256).run(circuit).to_statevector()

    def test_cnot_creates_bell(self):
        c = Circuit(2); c.h(0).cx(0, 1)
        sv = self._run_and_sv(c)
        assert abs(sv[0] - 1 / np.sqrt(2)) < 1e-10
        assert abs(sv[1]) < 1e-10
        assert abs(sv[2]) < 1e-10
        assert abs(sv[3] - 1 / np.sqrt(2)) < 1e-10

    def test_cnot_normalization(self):
        c = Circuit(3); c.h(0).cx(0, 1).cx(1, 2)
        assert abs(np.linalg.norm(self._run_and_sv(c)) - 1.0) < 1e-10

    def test_cz_gate(self):
        c = Circuit(2); c.x(0).x(1).cz(0, 1)
        assert abs(self._run_and_sv(c)[3] + 1.0) < 1e-10

    def test_ghz_state(self):
        n = 5
        c = Circuit(n); c.h(0)
        for i in range(n - 1): c.cx(i, i + 1)
        sv = self._run_and_sv(c)
        assert abs(sv[0] - 1 / np.sqrt(2)) < 1e-10
        assert abs(sv[-1] - 1 / np.sqrt(2)) < 1e-10
        assert all(abs(sv[i]) < 1e-10 for i in range(1, len(sv) - 1))

    def test_expectation_value_ghz(self):
        n = 4
        c = Circuit(n); c.h(0)
        for i in range(n - 1): c.cx(i, i + 1)
        state = MPSSimulator(chi=64).run(c)
        for q in range(n):
            assert abs(state.expectation_pauli_z(q)) < 1e-10


# ---------------------------------------------------------------------------
# Richardson extrapolation tests (via internal engine)
# ---------------------------------------------------------------------------

class TestRichardsonExtrapolation(unittest.TestCase):
    def _fake(self, true_val, alpha, chi_list):
        return [true_val + 1.0 / chi ** alpha for chi in chi_list]

    def test_extrapolation_known_alpha(self):
        true_val, alpha = 0.7654321, 1.0
        chi_list = [16, 32, 64]
        result = _run_extrap(chi_list, self._fake(true_val, alpha, chi_list),
                             scaling_factor=2.0, alpha=alpha)
        assert abs(result.extrapolated - true_val) < 1e-8

    def test_extrapolation_estimated_alpha(self):
        true_val, alpha = 0.5, 2.0
        chi_list = [32, 64, 128, 256]
        result = _run_extrap(chi_list, self._fake(true_val, alpha, chi_list),
                             scaling_factor=2.0)
        assert abs(result.extrapolated - true_val) < 1e-4

    def test_extrapolation_scaling_factor_3(self):
        true_val, alpha = 0.314159, 1.0
        chi_list = [10, 30, 90]
        result = _run_extrap(chi_list, self._fake(true_val, alpha, chi_list),
                             scaling_factor=3.0, alpha=alpha)
        assert abs(result.extrapolated - true_val) < 1e-8

    def test_reliability_monotone(self):
        result = _run_extrap([16, 32, 64], [0.5, 0.7, 0.6], scaling_factor=2.0)
        assert not result.is_reliable
        assert any("monoton" in n.lower() for n in result.reliability_notes)

    def test_result_summary(self):
        chi_list = [16, 32, 64]
        result = _run_extrap(chi_list, self._fake(0.5, 1.0, chi_list))
        assert "Extrapolated" in result.summary()

    def test_multi_observable(self):
        chi_list = [16, 32, 64]
        vd = {'Z0': self._fake(0.3, 1.0, chi_list),
              'Z1': self._fake(-0.3, 1.0, chi_list)}
        result = _run_extrap_multi(chi_list, vd, scaling_factor=2.0, alpha=1.0)
        assert 'Z0' in result.observables
        assert 'Z1' in result.observables
        assert abs(result.observables['Z0'].extrapolated - 0.3) < 1e-6

    def test_insufficient_data_raises(self):
        ext = _RichardsonExtrapolator(scaling_factor=2.0)
        with self.assertRaises(Exception):
            ext._run([64], [0.5])


# ---------------------------------------------------------------------------
# SweepConfig tests
# ---------------------------------------------------------------------------

class TestSweepConfig(unittest.TestCase):
    def test_bond_dims(self):
        cfg = SweepConfig(base_chi=16, scaling_factor=2.0, n_levels=4)
        assert cfg.bond_dims == [16, 32, 64, 128]

    def test_effective_chi(self):
        # bond_dims = [64, 128, 256], effective = 256 * 2 = 512
        cfg = SweepConfig(base_chi=64, scaling_factor=2.0, n_levels=3)
        assert cfg.effective_chi() == 512


# ---------------------------------------------------------------------------
# End-to-end integration tests
# ---------------------------------------------------------------------------

class TestEndToEnd(unittest.TestCase):
    def test_ising_model_z_expectation(self):
        n, theta = 6, 0.3
        c = Circuit(n)
        for q in range(n): c.ry(theta, q)
        for q in range(n - 1): c.zz(theta, q, q + 1)
        state = MPSSimulator(chi=64).run(c)
        for q in range(n):
            z = state.expectation_pauli_z(q)
            assert -1.0 <= z <= 1.0

    def test_random_circuit_normalization(self):
        np.random.seed(42)
        n = 6; c = Circuit(n)
        for _ in range(20):
            q = np.random.randint(n)
            c.ry(np.random.uniform(0, 2 * np.pi), q)
            if np.random.random() < 0.5 and q < n - 1:
                c.cx(q, q + 1)
        state = MPSSimulator(chi=64).run(c)
        assert abs(state._norm_mps() - 1.0) < 1e-8

    def test_multi_chi_runner_basic(self):
        n = 4; c = Circuit(n); c.h(0)
        for i in range(n - 1): c.cx(i, i + 1)
        cfg = SweepConfig(base_chi=8, scaling_factor=2.0, n_levels=3)
        result = MultiChiRunner(cfg, verbose=False).run(c, {'Z0': ('Z', 0)})
        assert abs(result.observables['Z0'].extrapolated) < 0.1

    def test_multi_chi_runner_device_cpu(self):
        n = 4; c = Circuit(n); c.h(0).cx(0, 1)
        cfg = SweepConfig(base_chi=8, scaling_factor=2.0, n_levels=2)
        result = MultiChiRunner(cfg, verbose=False, device='cpu').run(
            c, {'Z0': ('Z', 0)})
        assert 'Z0' in result.observables

    def test_circuit_builder_api(self):
        c = (Circuit(4).h(0).cx(0, 1).rz(np.pi / 4, 2)
             .ry(np.pi / 3, 3).cz(1, 2).x(0))
        assert len(c.instructions) == 6
        assert c.n == 4


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    
    unittest.main(verbosity=2)
