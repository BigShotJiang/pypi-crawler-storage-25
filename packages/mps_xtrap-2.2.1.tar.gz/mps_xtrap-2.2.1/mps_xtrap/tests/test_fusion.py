"""
Test suite for mps_xtrap gate fusion (v2.1.0).

Sections
--------
1.  GateFuser construction and repr
2.  Single-qubit fusion — matrix correctness
3.  Two-qubit fusion — matrix correctness
4.  Instruction-count reduction
5.  Simulation accuracy — fused vs unfused results match
6.  Idempotency — fusing twice gives the same result
7.  max_window limiting
8.  fuse_single / fuse_two flags
9.  fuse() convenience function
10. fusion_report()
11. MPSSimulator fusion=True / fusion=False / fusion=GateFuser
12. MPSSimulator.fusion property setter
13. Callable on list[GateInstruction]
14. Edge cases (empty circuit, 1-gate circuit, non-adjacent 2q gates)
15. Trotter-style circuit (many repeated ZZ gates)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import unittest

from mps_xtrap import Circuit, MPSSimulator, GateFuser, fuse
from mps_xtrap.circuits import GateInstruction
from mps_xtrap.gates import H, X, Z, Rx, Ry, Rz, CNOT, CZ, SWAP
from mps_xtrap.fusion import _fuse_single_qubit_matrices, _fuse_two_qubit_matrices


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _z_exp(state, q):
    return state.expectation_pauli_z(q)


def _build_ghz(n):
    c = Circuit(n)
    c.h(0)
    for i in range(n - 1):
        c.cx(i, i + 1)
    return c


def _almost_equal_matrix(a, b, tol=1e-12):
    return np.max(np.abs(a - b)) < tol


# ---------------------------------------------------------------------------
# Section 1 — GateFuser construction and repr
# ---------------------------------------------------------------------------

class TestGateFuserConstruction(unittest.TestCase):

    def test_default_construction(self):
        f = GateFuser()
        self.assertTrue(f.fuse_single)
        self.assertTrue(f.fuse_two)
        self.assertIsNone(f.max_window)

    def test_custom_flags(self):
        f = GateFuser(fuse_single=False, fuse_two=True, max_window=3)
        self.assertFalse(f.fuse_single)
        self.assertTrue(f.fuse_two)
        self.assertEqual(f.max_window, 3)

    def test_repr_contains_params(self):
        f = GateFuser(fuse_single=True, fuse_two=False, max_window=5)
        r = repr(f)
        self.assertIn("fuse_single=True", r)
        self.assertIn("fuse_two=False", r)
        self.assertIn("max_window=5", r)


# ---------------------------------------------------------------------------
# Section 2 — Single-qubit matrix fusion correctness
# ---------------------------------------------------------------------------

class TestSingleQubitFusionMatrix(unittest.TestCase):

    def test_two_hadamards_is_identity(self):
        h = H()
        fused = _fuse_single_qubit_matrices([h, h])
        self.assertTrue(_almost_equal_matrix(fused, np.eye(2, dtype=complex)))

    def test_three_rx_adds_angles(self):
        a, b, c = 0.3, 0.7, 1.1
        fused = _fuse_single_qubit_matrices([Rx(a), Rx(b), Rx(c)])
        direct = Rx(a + b + c)
        self.assertTrue(_almost_equal_matrix(fused, direct))

    def test_xz_order(self):
        x, z = X(), Z()
        # Applied order: X first, then Z  →  fused = Z @ X
        fused = _fuse_single_qubit_matrices([x, z])
        expected = z @ x
        self.assertTrue(_almost_equal_matrix(fused, expected))

    def test_single_element_unchanged(self):
        h = H()
        fused = _fuse_single_qubit_matrices([h])
        self.assertTrue(_almost_equal_matrix(fused, h))

    def test_random_product(self):
        rng = np.random.default_rng(42)
        def rand_unitary():
            m = rng.standard_normal((2, 2)) + 1j * rng.standard_normal((2, 2))
            q, _ = np.linalg.qr(m)
            return q
        gates = [rand_unitary() for _ in range(5)]
        fused = _fuse_single_qubit_matrices(gates)
        expected = gates[4] @ gates[3] @ gates[2] @ gates[1] @ gates[0]
        self.assertTrue(_almost_equal_matrix(fused, expected))


# ---------------------------------------------------------------------------
# Section 3 — Two-qubit matrix fusion correctness
# ---------------------------------------------------------------------------

class TestTwoQubitFusionMatrix(unittest.TestCase):

    def test_two_cnots_is_identity(self):
        cx = CNOT()
        fused = _fuse_two_qubit_matrices([cx, cx])
        eye4 = np.eye(4, dtype=complex).reshape(2, 2, 2, 2)
        self.assertTrue(_almost_equal_matrix(fused, eye4))

    def test_two_swaps_is_identity(self):
        sw = SWAP()
        fused = _fuse_two_qubit_matrices([sw, sw])
        eye4 = np.eye(4, dtype=complex).reshape(2, 2, 2, 2)
        self.assertTrue(_almost_equal_matrix(fused, eye4))

    def test_single_element_unchanged(self):
        cx = CNOT()
        fused = _fuse_two_qubit_matrices([cx])
        self.assertTrue(_almost_equal_matrix(fused, cx))

    def test_cz_cz_is_identity(self):
        cz = CZ()
        fused = _fuse_two_qubit_matrices([cz, cz])
        eye4 = np.eye(4, dtype=complex).reshape(2, 2, 2, 2)
        self.assertTrue(_almost_equal_matrix(fused, eye4))

    def test_product_order(self):
        cx = CNOT()
        sw = SWAP()
        fused = _fuse_two_qubit_matrices([cx, sw])
        # fused(4x4) = SW @ CX
        expected = (sw.reshape(4, 4) @ cx.reshape(4, 4)).reshape(2, 2, 2, 2)
        self.assertTrue(_almost_equal_matrix(fused, expected))


# ---------------------------------------------------------------------------
# Section 4 — Instruction count reduction
# ---------------------------------------------------------------------------

class TestInstructionCount(unittest.TestCase):

    def _fuse(self, c):
        return GateFuser()(c)

    def test_single_qubit_run_fused(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0).rx(0.3, 0)   # 3 gates on q0
        fc = self._fuse(c)
        self.assertEqual(len(fc.instructions), 1)

    def test_two_qubit_run_fused(self):
        c = Circuit(3)
        c.cx(0, 1).cx(0, 1).cx(0, 1)   # 3 CNOTs on (0,1)
        fc = self._fuse(c)
        self.assertEqual(len(fc.instructions), 1)

    def test_interleaved_not_fused(self):
        c = Circuit(3)
        c.h(0).h(1).h(0)   # q1 gate breaks the q0 run
        fc = self._fuse(c)
        # h(0), h(1), h(0): first two h(0) aren't consecutive because h(1) is between them
        self.assertEqual(len(fc.instructions), 3)

    def test_mixed_circuit(self):
        c = Circuit(4)
        c.h(0).rz(0.5, 0).rx(0.3, 0)   # 3 → 1
        c.cx(0, 1).cx(0, 1)             # 2 → 1
        c.h(2).s(2)                     # 2 → 1
        fc = self._fuse(c)
        self.assertEqual(len(fc.instructions), 3)

    def test_no_fusion_when_single_gates(self):
        c = Circuit(3)
        c.h(0).h(1).cx(0, 1)
        fc = self._fuse(c)
        self.assertEqual(len(fc.instructions), 3)

    def test_fused_label_contains_names(self):
        c = Circuit(2)
        c.h(0).rz(0.5, 0)
        fc = GateFuser()(c)
        label = fc.instructions[0].label
        self.assertIn("H", label)
        self.assertIn("Rz", label)


# ---------------------------------------------------------------------------
# Section 5 — Simulation accuracy: fused vs unfused
# ---------------------------------------------------------------------------

class TestSimulationAccuracy(unittest.TestCase):

    TOL = 1e-10

    def _compare(self, circuit, n_qubits):
        sim = MPSSimulator(chi=128)
        sim_fused = MPSSimulator(chi=128, fusion=True)
        s_orig = sim.run(circuit)
        s_fused = sim_fused.run(circuit)
        for q in range(n_qubits):
            self.assertAlmostEqual(
                s_orig.expectation_pauli_z(q),
                s_fused.expectation_pauli_z(q),
                delta=self.TOL,
                msg=f"Z mismatch at qubit {q}",
            )
            self.assertAlmostEqual(
                s_orig.expectation_pauli_x(q),
                s_fused.expectation_pauli_x(q),
                delta=self.TOL,
                msg=f"X mismatch at qubit {q}",
            )

    def test_ghz_4(self):
        self._compare(_build_ghz(4), 4)

    def test_many_single_qubit_gates(self):
        c = Circuit(3)
        for _ in range(10):
            c.rx(0.1, 0).ry(0.2, 0).rz(0.3, 0)
        self._compare(c, 3)

    def test_repeated_cnot_pairs(self):
        c = Circuit(4)
        for _ in range(5):
            c.cx(0, 1).cx(1, 2).cx(2, 3)
        self._compare(c, 4)

    def test_two_cnots_on_same_pair(self):
        # Two CNOTs cancel to identity
        c = Circuit(3)
        c.h(0).cx(0, 1).cx(0, 1)
        self._compare(c, 3)

    def test_rotation_chain(self):
        c = Circuit(5)
        for q in range(5):
            c.h(q)
        for _ in range(4):
            for q in range(5):
                c.rz(0.15 * (q + 1), q)
            for q in range(4):
                c.cx(q, q + 1)
        self._compare(c, 5)

    def test_statevector_matches(self):
        c = Circuit(4)
        c.h(0).rz(0.5, 0).rx(0.3, 0).cx(0, 1).cx(0, 1).h(2).s(2)
        sim = MPSSimulator(chi=512)
        sim_f = MPSSimulator(chi=512, fusion=True)
        sv_orig = sim.run(c).to_statevector()
        sv_fused = sim_f.run(c).to_statevector()
        self.assertTrue(np.allclose(sv_orig, sv_fused, atol=1e-11))


# ---------------------------------------------------------------------------
# Section 6 — Idempotency
# ---------------------------------------------------------------------------

class TestIdempotency(unittest.TestCase):

    def test_fuse_twice_same_result(self):
        c = Circuit(4)
        c.h(0).rz(0.5, 0).cx(0, 1).cx(0, 1).h(2)
        fuser = GateFuser()
        fc1 = fuser(c)
        fc2 = fuser(fc1)
        # Count should be the same after second fuse (already fused)
        self.assertEqual(len(fc1.instructions), len(fc2.instructions))

    def test_fuse_twice_same_statevector(self):
        c = Circuit(3)
        c.h(0).rz(0.4, 0).rx(0.3, 0).cx(0, 1).cx(0, 1)
        fuser = GateFuser()
        fc1 = fuser(c)
        fc2 = fuser(fc1)
        sim = MPSSimulator(chi=128)
        sv1 = sim.run(fc1).to_statevector()
        sv2 = sim.run(fc2).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-12))


# ---------------------------------------------------------------------------
# Section 7 — max_window limiting
# ---------------------------------------------------------------------------

class TestMaxWindow(unittest.TestCase):

    def test_max_window_1_no_fusion(self):
        c = Circuit(2)
        c.h(0).rz(0.5, 0).rx(0.3, 0)   # would fuse to 1 without limit
        fc = GateFuser(max_window=1)(c)
        self.assertEqual(len(fc.instructions), 3)

    def test_max_window_2_partial_fusion(self):
        c = Circuit(2)
        c.h(0).rz(0.5, 0).rx(0.3, 0)   # 3 gates; window 2 → 2+1=2 outputs
        fc = GateFuser(max_window=2)(c)
        self.assertEqual(len(fc.instructions), 2)

    def test_max_window_unlimited_full_fusion(self):
        c = Circuit(2)
        c.h(0).rz(0.5, 0).rx(0.3, 0).ry(0.1, 0)
        fc = GateFuser(max_window=None)(c)
        self.assertEqual(len(fc.instructions), 1)

    def test_max_window_accuracy(self):
        c = Circuit(2)
        c.h(0).rz(0.5, 0).rx(0.3, 0).ry(0.2, 0)
        sim = MPSSimulator(chi=64)
        sim2 = MPSSimulator(chi=64, fusion=GateFuser(max_window=2))
        sv1 = sim.run(c).to_statevector()
        sv2 = sim2.run(c).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-12))


# ---------------------------------------------------------------------------
# Section 8 — fuse_single / fuse_two flags
# ---------------------------------------------------------------------------

class TestFusionFlags(unittest.TestCase):

    def test_fuse_single_only(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0)   # should fuse
        c.cx(0, 1).cx(0, 1) # should NOT fuse (fuse_two=False)
        fc = GateFuser(fuse_single=True, fuse_two=False)(c)
        # 1q run fused → 1; 2q pair stays → 2; total = 3
        self.assertEqual(len(fc.instructions), 3)

    def test_fuse_two_only(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0)   # should NOT fuse (fuse_single=False)
        c.cx(0, 1).cx(0, 1) # should fuse
        fc = GateFuser(fuse_single=False, fuse_two=True)(c)
        # 1q pair stays → 2; 2q run fused → 1; total = 3
        self.assertEqual(len(fc.instructions), 3)

    def test_both_false_no_change(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0).cx(0, 1).cx(0, 1)
        fc = GateFuser(fuse_single=False, fuse_two=False)(c)
        self.assertEqual(len(fc.instructions), len(c.instructions))

    def test_accuracy_fuse_single_only(self):
        c = Circuit(3)
        c.h(0).rz(0.4, 0).cx(0, 1).cx(0, 1)
        sim = MPSSimulator(chi=64)
        sim_f = MPSSimulator(chi=64, fusion=GateFuser(fuse_single=True, fuse_two=False))
        sv1 = sim.run(c).to_statevector()
        sv2 = sim_f.run(c).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-12))

    def test_accuracy_fuse_two_only(self):
        c = Circuit(3)
        c.h(0).rz(0.4, 0).cx(0, 1).cx(0, 1)
        sim = MPSSimulator(chi=64)
        sim_f = MPSSimulator(chi=64, fusion=GateFuser(fuse_single=False, fuse_two=True))
        sv1 = sim.run(c).to_statevector()
        sv2 = sim_f.run(c).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-12))


# ---------------------------------------------------------------------------
# Section 9 — fuse() convenience function
# ---------------------------------------------------------------------------

class TestFuseFunction(unittest.TestCase):

    def test_fuse_returns_circuit(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0)
        fc = fuse(c)
        self.assertIsInstance(fc, Circuit)

    def test_fuse_does_not_modify_original(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0)
        n_before = len(c.instructions)
        _ = fuse(c)
        self.assertEqual(len(c.instructions), n_before)

    def test_fuse_reduces_count(self):
        c = Circuit(2)
        c.h(0).rz(0.5, 0).rx(0.3, 0)
        fc = fuse(c)
        self.assertLess(len(fc.instructions), len(c.instructions))

    def test_fuse_with_flags(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0).cx(0, 1).cx(0, 1)
        fc = fuse(c, fuse_single=True, fuse_two=False)
        # 1q fused (3→1), 2q untouched (2 stays)
        self.assertEqual(len(fc.instructions), 3)

    def test_fuse_accuracy(self):
        c = Circuit(4)
        c.h(0).rz(0.5, 0).cx(0, 1).cx(0, 1).h(2).s(2)
        sim = MPSSimulator(chi=64)
        sv1 = sim.run(c).to_statevector()
        sv2 = sim.run(fuse(c)).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-12))


# ---------------------------------------------------------------------------
# Section 10 — fusion_report()
# ---------------------------------------------------------------------------

class TestFusionReport(unittest.TestCase):

    def test_report_keys(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0).cx(0, 1).cx(0, 1)
        report = GateFuser().fusion_report(c)
        for key in ('original_count', 'fused_count', 'saved',
                    'single_qubit_fusions', 'two_qubit_fusions'):
            self.assertIn(key, report)

    def test_report_values(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0)   # 2→1, one 1q fusion
        c.cx(0, 1).cx(0, 1) # 2→1, one 2q fusion
        report = GateFuser().fusion_report(c)
        self.assertEqual(report['original_count'], 4)
        self.assertEqual(report['fused_count'], 2)
        self.assertEqual(report['saved'], 2)
        self.assertEqual(report['single_qubit_fusions'], 1)
        self.assertEqual(report['two_qubit_fusions'], 1)

    def test_no_fusion_report(self):
        c = Circuit(3)
        c.h(0).h(1).cx(0, 1)   # nothing fusible
        report = GateFuser().fusion_report(c)
        self.assertEqual(report['saved'], 0)
        self.assertEqual(report['single_qubit_fusions'], 0)
        self.assertEqual(report['two_qubit_fusions'], 0)

    def test_report_does_not_modify_circuit(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0)
        n = len(c.instructions)
        GateFuser().fusion_report(c)
        self.assertEqual(len(c.instructions), n)


# ---------------------------------------------------------------------------
# Section 11 — MPSSimulator fusion parameter
# ---------------------------------------------------------------------------

class TestMPSSimulatorFusion(unittest.TestCase):

    def _base_circuit(self):
        c = Circuit(4)
        c.h(0).rz(0.5, 0).cx(0, 1).cx(0, 1).h(2).s(2)
        return c

    def test_fusion_false_default(self):
        sim = MPSSimulator(chi=64)
        self.assertIsNone(sim.fusion)

    def test_fusion_true(self):
        sim = MPSSimulator(chi=64, fusion=True)
        self.assertIsNotNone(sim.fusion)
        self.assertIsInstance(sim.fusion, GateFuser)

    def test_fusion_gatesfuser_instance(self):
        f = GateFuser(fuse_single=True, fuse_two=False)
        sim = MPSSimulator(chi=64, fusion=f)
        self.assertIs(sim.fusion, f)

    def test_fusion_true_accuracy(self):
        c = self._base_circuit()
        sim = MPSSimulator(chi=128)
        sim_f = MPSSimulator(chi=128, fusion=True)
        sv1 = sim.run(c).to_statevector()
        sv2 = sim_f.run(c).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-11))

    def test_run_from_with_fusion(self):
        c1 = Circuit(3)
        c1.h(0).cx(0, 1)
        c2 = Circuit(3)
        c2.h(0).rz(0.4, 0).cx(0, 1).cx(0, 1)
        sim = MPSSimulator(chi=64)
        sim_f = MPSSimulator(chi=64, fusion=True)
        base_state = sim.run(c1)
        s1 = sim.run_from(c2, base_state)
        s2 = sim_f.run_from(c2, base_state)
        for q in range(3):
            self.assertAlmostEqual(
                s1.expectation_pauli_z(q),
                s2.expectation_pauli_z(q),
                delta=1e-11,
            )


# ---------------------------------------------------------------------------
# Section 12 — MPSSimulator.fusion property setter
# ---------------------------------------------------------------------------

class TestFusionPropertySetter(unittest.TestCase):

    def test_set_true(self):
        sim = MPSSimulator(chi=64)
        sim.fusion = True
        self.assertIsInstance(sim.fusion, GateFuser)

    def test_set_none(self):
        sim = MPSSimulator(chi=64, fusion=True)
        sim.fusion = None
        self.assertIsNone(sim.fusion)

    def test_set_false(self):
        sim = MPSSimulator(chi=64, fusion=True)
        sim.fusion = False
        self.assertIsNone(sim.fusion)

    def test_set_gatesfuser(self):
        f = GateFuser(fuse_single=False, fuse_two=True)
        sim = MPSSimulator(chi=64)
        sim.fusion = f
        self.assertIs(sim.fusion, f)

    def test_setter_affects_run(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0).cx(0, 1).cx(0, 1)
        sim = MPSSimulator(chi=64)
        sv1 = sim.run(c).to_statevector()
        sim.fusion = True
        sv2 = sim.run(c).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-11))


# ---------------------------------------------------------------------------
# Section 13 — Callable on list[GateInstruction]
# ---------------------------------------------------------------------------

class TestCallableOnList(unittest.TestCase):

    def test_returns_list(self):
        c = Circuit(3)
        c.h(0).rz(0.5, 0).cx(0, 1)
        result = GateFuser()(c.instructions)
        self.assertIsInstance(result, list)

    def test_list_fusion_reduces_count(self):
        c = Circuit(2)
        c.h(0).rz(0.5, 0).rx(0.3, 0)
        fused_list = GateFuser()(c.instructions)
        self.assertLess(len(fused_list), len(c.instructions))

    def test_list_fusion_gate_is_instruction(self):
        c = Circuit(2)
        c.h(0).rz(0.5, 0)
        fused_list = GateFuser()(c.instructions)
        self.assertIsInstance(fused_list[0], GateInstruction)


# ---------------------------------------------------------------------------
# Section 14 — Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases(unittest.TestCase):

    def test_empty_circuit(self):
        c = Circuit(4)
        fc = GateFuser()(c)
        self.assertEqual(len(fc.instructions), 0)

    def test_single_gate_circuit(self):
        c = Circuit(2)
        c.h(0)
        fc = GateFuser()(c)
        self.assertEqual(len(fc.instructions), 1)

    def test_non_adjacent_two_qubit_not_fused(self):
        # Gates on different pairs are not fused
        c = Circuit(4)
        c.cx(0, 1).cx(1, 2).cx(0, 1)
        fc = GateFuser()(c)
        # (0,1) then (1,2) breaks the (0,1) run; then (0,1) starts new run
        # so: [cx(0,1)], [cx(1,2)], [cx(0,1)] → all separate
        self.assertEqual(len(fc.instructions), 3)

    def test_same_qubit_pair_different_order_not_fused(self):
        # (0,1) and (1,0) are different ordered pairs
        c = Circuit(3)
        c.cx(0, 1).cx(1, 0)
        fc = GateFuser()(c)
        self.assertEqual(len(fc.instructions), 2)

    def test_n1_circuit(self):
        c = Circuit(1)
        c.h(0).rz(0.5, 0).x(0)
        fc = GateFuser()(c)
        self.assertEqual(len(fc.instructions), 1)
        sim = MPSSimulator(chi=4)
        sv1 = sim.run(c).to_statevector()
        sv2 = sim.run(fc).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-12))

    def test_large_single_qubit_run(self):
        c = Circuit(2)
        for _ in range(50):
            c.rx(0.01, 0)
        fc = GateFuser()(c)
        self.assertEqual(len(fc.instructions), 1)
        sim = MPSSimulator(chi=16)
        sv1 = sim.run(c).to_statevector()
        sv2 = sim.run(fc).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-10))

    def test_custom_matrix_gate_fused(self):
        # GateInstruction with explicit matrix should be fused like named gates
        h_mat = np.array([[1, 1], [1, -1]], dtype=complex) / np.sqrt(2)
        inst1 = GateInstruction(name='custom_H', qubits=[0], matrix=h_mat)
        inst2 = GateInstruction(name='custom_H', qubits=[0], matrix=h_mat)
        fused = GateFuser()([inst1, inst2])
        self.assertEqual(len(fused), 1)
        fused_mat = fused[0].matrix
        self.assertTrue(_almost_equal_matrix(fused_mat, np.eye(2, dtype=complex)))


# ---------------------------------------------------------------------------
# Section 15 — Trotter-style circuit (many repeated ZZ gates)
# ---------------------------------------------------------------------------

class TestTrotterFusion(unittest.TestCase):

    def test_trotter_step_count_reduced(self):
        """Trotter ZZ layers: each ZZ on same pair should fuse."""
        c = Circuit(4)
        n_steps = 8
        dt = 0.05
        for _ in range(n_steps):
            c.zz(dt, 0, 1)
            c.zz(dt, 1, 2)
            c.zz(dt, 2, 3)
        # Without fusion: 24 gates; with fusion on same pairs
        # Pairs (0,1): 8 consecutive zz — but they're interleaved with (1,2) and (2,3)
        # So actual consecutive runs per pair = 1 each per Trotter step
        # Full circuit interleaves pairs so runs are length 1 — no fusion here.
        # Let's build a circuit where each pair IS consecutive:
        c2 = Circuit(4)
        for _ in range(n_steps):
            c2.zz(dt, 0, 1)   # 8 consecutive on (0,1)
        for _ in range(n_steps):
            c2.zz(dt, 1, 2)   # 8 consecutive on (1,2)
        fc = GateFuser()(c2)
        # Each run of 8 fuses to 1 → 2 instructions total
        self.assertEqual(len(fc.instructions), 2)

    def test_trotter_accuracy(self):
        """Fused Trotter circuit gives same state as unfused."""
        c = Circuit(4)
        n_steps = 6
        dt = 0.05
        for _ in range(n_steps):
            c.zz(dt, 0, 1)
        for _ in range(n_steps):
            c.zz(dt, 1, 2)
        sim = MPSSimulator(chi=64)
        sim_f = MPSSimulator(chi=64, fusion=True)
        sv1 = sim.run(c).to_statevector()
        sv2 = sim_f.run(c).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-11))

    def test_single_qubit_layer_fused(self):
        """Per-qubit Rz runs fuse when built qubit-by-qubit (not interleaved)."""
        c = Circuit(4)
        n_layers = 6
        # Build qubit-by-qubit so each qubit's gates are consecutive
        for q in range(4):
            for _ in range(n_layers):
                c.rz(0.1 * (q + 1), q)   # 6 rz per qubit, consecutive → fuses to 1
        fc = GateFuser()(c)
        # 4 qubits × 1 fused gate each = 4 instructions
        self.assertEqual(len(fc.instructions), 4)

    def test_ansatz_layer_accuracy(self):
        """QAOA-like ansatz with repeated single-qubit rotations."""
        c = Circuit(4)
        for _ in range(5):
            for q in range(4):
                c.rx(0.12, q).rz(0.34, q)
            for q in range(3):
                c.cx(q, q + 1)
        sim = MPSSimulator(chi=64)
        sim_f = MPSSimulator(chi=64, fusion=True)
        sv1 = sim.run(c).to_statevector()
        sv2 = sim_f.run(c).to_statevector()
        self.assertTrue(np.allclose(sv1, sv2, atol=1e-10))


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    sections = [
        TestGateFuserConstruction,
        TestSingleQubitFusionMatrix,
        TestTwoQubitFusionMatrix,
        TestInstructionCount,
        TestSimulationAccuracy,
        TestIdempotency,
        TestMaxWindow,
        TestFusionFlags,
        TestFuseFunction,
        TestFusionReport,
        TestMPSSimulatorFusion,
        TestFusionPropertySetter,
        TestCallableOnList,
        TestEdgeCases,
        TestTrotterFusion,
    ]

    section_names = [
        "1.  GateFuser construction and repr",
        "2.  Single-qubit matrix fusion correctness",
        "3.  Two-qubit matrix fusion correctness",
        "4.  Instruction count reduction",
        "5.  Simulation accuracy — fused vs unfused",
        "6.  Idempotency",
        "7.  max_window limiting",
        "8.  fuse_single / fuse_two flags",
        "9.  fuse() convenience function",
        "10. fusion_report()",
        "11. MPSSimulator fusion parameter",
        "12. MPSSimulator.fusion property setter",
        "13. Callable on list[GateInstruction]",
        "14. Edge cases",
        "15. Trotter-style circuit",
    ]

    total_passed = 0
    total_failed = 0
    failures = []

    print("\n" + "=" * 60)
    print("  mps_xtrap v2.1.0 — Gate Fusion Test Suite")
    print("=" * 60)

    for cls, name in zip(sections, section_names):
        s = loader.loadTestsFromTestCase(cls)
        runner = unittest.TextTestRunner(verbosity=0, stream=open(os.devnull, 'w'))
        result = runner.run(s)
        n = s.countTestCases()
        f = len(result.failures) + len(result.errors)
        p = n - f
        total_passed += p
        total_failed += f
        status = "✓" if f == 0 else "✗"
        print(f"  {status} Section {name}  ({p}/{n})")
        for fail in result.failures + result.errors:
            failures.append(fail)

    print()
    print("=" * 60)
    print("  FINAL RESULTS")
    print("=" * 60)
    print(f"  PASSED: {total_passed}")
    print(f"  FAILED: {total_failed}")

    if failures:
        print("\n  FAILURES:")
        for test, tb in failures:
            print(f"\n  {test}")
            print(tb)
    else:
        print()
        print("  ✓ All fusion tests passed!")

    print()
    raise SystemExit(0 if total_failed == 0 else 1)
