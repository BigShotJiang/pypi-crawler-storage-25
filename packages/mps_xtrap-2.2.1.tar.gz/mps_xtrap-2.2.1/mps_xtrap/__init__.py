"""
mps_xtrap — MPS-based quantum circuit simulator with Richardson extrapolation.

Quick start
-----------
>>> from mps_xtrap import Circuit, MPSSimulator, MultiChiRunner, SweepConfig
>>>
>>> # Simple simulation at a fixed bond dimension
>>> c = Circuit(4)
>>> c.h(0).cx(0,1).cx(1,2).cx(2,3)
>>> sim = MPSSimulator(chi=64)
>>> state = sim.run(c)
>>> print(state.expectation_pauli_z(0))
>>>
>>> # Extrapolated simulation — just set base_chi, scaling_factor, n_levels
>>> # Bond dimensions are auto-generated: [16, 32, 64]
>>> runner = MultiChiRunner(SweepConfig(base_chi=16, scaling_factor=2, n_levels=3))
>>> result = runner.run(c, observables={'Z0': ('Z', 0)})
>>> print(result.summary())
>>>
>>> # Qubit measurement via projector operators (v2.2.0)
>>> from mps_xtrap import measure_qubit, measure_qubits, sample_counts
>>> mres = measure_qubit(state, site=0)
>>> print(mres.summary())
>>>
>>> # Extrapolate measurement probabilities (v2.2.0)
>>> runner = MultiChiRunner(SweepConfig(base_chi=16, scaling_factor=2, n_levels=3))
>>> result = runner.run(
...     c,
...     observables={'Z0': ('Z', 0)},
...     measure={'P0_q0': (0, 'prob0'), 'P1_q0': (0, 'prob1')},
... )
>>> print(result.summary())

License & Access (v2.2.1)
--------------------------
mps_xtrap uses a credit-based access system.

  FREE TRIAL  — 20 simulation runs / calendar month (auto-resets)
  SUBSCRIBED  — Unlimited runs / month after activation

To subscribe ($15/month):
  1. Pay at https://flutterwave.com/pay/6yptuvqab8cu
  2. Email proof of payment to oscinspire@gmail.com
  3. Receive your activation key, then run:

     from mps_xtrap.license import activate
     activate("XXXX-XXXX-XXXX-XXXX")

Check your current status:
     from mps_xtrap.license import show_status
     show_status()
"""

from .core.mps import MPS
from .circuits import Circuit, MPSSimulator
from .extrapolation import (
    MultiChiRunner,
    SweepConfig,
    ExtrapolationResult,
    MultiObservableResult,
)
from .gates import get_gate
from .fusion import GateFuser, fuse
from .measurement import (
    projector,
    P0,
    P1,
    MeasurementEngine,
    SingleMeasurementResult,
    MultiQubitMeasurementResult,
    SampledCounts,
    measure_qubit,
    measure_qubits,
    sample_counts,
    full_distribution,
)
from .license import activate, deactivate, show_status, CreditExhaustedError

__version__ = "2.2.1"
__author__ = "MPS Sim"

__all__ = [
    # Core
    "MPS",
    "Circuit",
    "MPSSimulator",
    # Extrapolation
    "MultiChiRunner",
    "SweepConfig",
    "ExtrapolationResult",
    "MultiObservableResult",
    # Gates
    "get_gate",
    # Fusion
    "GateFuser",
    "fuse",
    # Measurement (v2.2.0)
    "projector",
    "P0",
    "P1",
    "MeasurementEngine",
    "SingleMeasurementResult",
    "MultiQubitMeasurementResult",
    "SampledCounts",
    "measure_qubit",
    "measure_qubits",
    "sample_counts",
    "full_distribution",
    # License (v2.2.1)
    "activate",
    "deactivate",
    "show_status",
    "CreditExhaustedError",
]
