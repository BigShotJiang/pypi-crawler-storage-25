"""
Gate Fusion for MPS quantum circuit simulation.

Gate fusion merges sequences of adjacent gates into a single combined gate
before simulation. This reduces the number of SVD truncations (for two-qubit
gates) and einsum contractions (for single-qubit gates), often giving a
significant speedup.

Overview
--------
Two fusion modes are supported:

1. **Single-qubit fusion** — consecutive single-qubit gates on the same qubit
   are multiplied together into one (2×2) matrix gate.  This replaces k
   matrix–vector products with 1, and avoids re-canonicalizing the MPS
   between gates.

2. **Two-qubit fusion** — consecutive two-qubit gates on the *same* pair of
   adjacent qubits are contracted into one (2,2,2,2) gate. This is the most
   impactful optimisation because each two-qubit gate incurs an SVD
   truncation; fusing k such gates into 1 saves k−1 SVDs.

Usage
-----
The simplest way to use fusion is via the ``fuse`` callable attached to
``MPSSimulator``::

    sim = MPSSimulator(chi=64, fusion=True)          # enable fusion globally
    state = sim.run(circuit)

Or call the ``GateFuser`` directly for more control::

    from mps_xtrap.fusion import GateFuser

    fuser = GateFuser(
        fuse_single=True,   # merge single-qubit gate runs
        fuse_two=True,      # merge two-qubit gate runs on same qubit pair
        max_window=None,    # None → fuse unlimited length runs (default)
    )
    fused_circuit = fuser(circuit)       # GateFuser is callable
    state = sim.run(fused_circuit)

``GateFuser`` is also callable with a plain list of ``GateInstruction``
objects, returning a new list — useful when building custom pipelines.

Performance guidance
--------------------
* Single-qubit fusion is almost always beneficial — zero accuracy impact,
  small overhead for the matrix multiply.
* Two-qubit fusion is beneficial when the same qubit pair is targeted
  consecutively (e.g. variational ansatz layers, Trotter steps).
* ``max_window=k`` caps how many gates are merged in one block.  For most
  circuits, ``None`` (unlimited) is fine; set a limit if you want to
  control block size explicitly.

Notes
-----
* Fusion never changes the mathematical operation — the fused gate is
  exactly the product of the original gates.
* Custom matrices (``GateInstruction.matrix is not None``) are handled
  seamlessly alongside named gates.
* Non-adjacent two-qubit gates (SWAP-chain targets) are handled correctly:
  only gates on the *exact same ordered qubit pair* are fused.
"""

from __future__ import annotations

import numpy as np
from typing import List, Optional, Union
import logging

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _fuse_single_qubit_matrices(matrices: List[np.ndarray]) -> np.ndarray:
    """
    Multiply a sequence of (2,2) single-qubit matrices left-to-right.

    The rightmost gate in ``matrices`` is the first to be applied to the
    state (standard quantum-circuit convention), so we reduce right-to-left::

        result = matrices[-1] @ matrices[-2] @ ... @ matrices[0]

    Wait — in circuit convention gate[0] is applied first, meaning:

        |ψ'> = G[k] … G[1] G[0] |ψ>

    The combined matrix is  G[k] @ … @ G[0]  (last gate leftmost in numpy).

    Parameters
    ----------
    matrices : list of ndarray, each shape (2, 2)

    Returns
    -------
    ndarray, shape (2, 2)
    """
    result = matrices[0]
    for m in matrices[1:]:
        result = m @ result   # m applied after result
    return result


def _fuse_two_qubit_matrices(matrices: List[np.ndarray]) -> np.ndarray:
    """
    Fuse a sequence of (2,2,2,2) two-qubit gate tensors.

    Convention: op[s1', s2', s1, s2].  Fusion reshapes each to (4,4),
    multiplies left-to-right (later gates left), then reshapes back.

    Parameters
    ----------
    matrices : list of ndarray, each shape (2, 2, 2, 2)

    Returns
    -------
    ndarray, shape (2, 2, 2, 2)
    """
    mats = [m.reshape(4, 4) for m in matrices]
    result = mats[0]
    for m in mats[1:]:
        result = m @ result
    return result.reshape(2, 2, 2, 2)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class GateFuser:
    """
    Callable that fuses gate sequences in a circuit or instruction list.

    Parameters
    ----------
    fuse_single : bool
        If True (default), merge runs of consecutive single-qubit gates on
        the same qubit into one fused gate.
    fuse_two : bool
        If True (default), merge runs of consecutive two-qubit gates on the
        same adjacent qubit pair into one fused gate.
    max_window : int or None
        Maximum number of gates to merge in a single fusion block.
        ``None`` (default) means unlimited.

    Examples
    --------
    >>> from mps_xtrap import Circuit
    >>> from mps_xtrap.fusion import GateFuser
    >>> c = Circuit(3)
    >>> c.h(0).rz(0.5, 0).rx(0.3, 0).cx(0, 1).cx(0, 1)
    >>> fuser = GateFuser()
    >>> fc = fuser(c)          # returns a new Circuit
    >>> print(len(c.instructions), '->', len(fc.instructions))
    5 -> 2
    """

    def __init__(
        self,
        fuse_single: bool = True,
        fuse_two: bool = True,
        max_window: Optional[int] = None,
    ):
        self.fuse_single = fuse_single
        self.fuse_two = fuse_two
        self.max_window = max_window

    # ------------------------------------------------------------------
    # Callable interface
    # ------------------------------------------------------------------

    def __call__(
        self,
        circuit_or_instructions,
    ):
        """
        Fuse gates in *circuit_or_instructions*.

        Parameters
        ----------
        circuit_or_instructions : Circuit or list of GateInstruction
            Input to fuse.

        Returns
        -------
        Circuit or list of GateInstruction
            Same type as input, with gate runs merged.
        """
        # Import here to avoid circular imports at module load time
        from ..circuits import Circuit, GateInstruction  # noqa: F401

        if isinstance(circuit_or_instructions, Circuit):
            instructions = circuit_or_instructions.instructions
            fused = self._fuse_instructions(instructions)
            out = Circuit(circuit_or_instructions.n)
            out.instructions = fused
            n_before = len(instructions)
            n_after = len(fused)
            if n_before != n_after:
                logger.debug(
                    "GateFuser: %d instructions → %d (saved %d gate applications)",
                    n_before, n_after, n_before - n_after,
                )
            return out
        else:
            # Plain list of GateInstruction
            return self._fuse_instructions(list(circuit_or_instructions))

    # ------------------------------------------------------------------
    # Core fusion logic
    # ------------------------------------------------------------------

    def _fuse_instructions(self, instructions: list) -> list:
        """
        Pass through the instruction list and merge eligible runs.

        A 'run' is a maximal consecutive sequence of gates that:
        - All act on exactly the same qubits (same ordered tuple)
        - Have the same qubit-count (single or two-qubit)
        - Do not exceed ``max_window`` length
        """
        if not instructions:
            return []

        output: list = []
        i = 0
        while i < len(instructions):
            inst = instructions[i]
            n_qubits = len(inst.qubits)

            # Only attempt fusion on 1q and 2q gates
            if n_qubits == 1 and self.fuse_single:
                run, i = self._collect_run(instructions, i, tuple(inst.qubits))
                output.extend(self._fuse_single_run(run))
            elif n_qubits == 2 and self.fuse_two:
                run, i = self._collect_run(instructions, i, tuple(inst.qubits))
                output.extend(self._fuse_two_run(run))
            else:
                output.append(inst)
                i += 1

        return output

    def _collect_run(self, instructions: list, start: int, target_qubits: tuple):
        """
        Collect a maximal run of consecutive instructions on *target_qubits*
        starting at *start*, respecting *max_window*.

        Returns
        -------
        run : list of GateInstruction
        next_i : int
            Index of the first instruction not in the run.
        """
        run = []
        i = start
        while i < len(instructions):
            inst = instructions[i]
            if tuple(inst.qubits) != target_qubits:
                break
            if self.max_window is not None and len(run) >= self.max_window:
                break
            run.append(inst)
            i += 1
        return run, i

    def _fuse_single_run(self, run: list) -> list:
        """
        Fuse a run of single-qubit gates.  Returns a list with one element
        (the fused gate) if len(run) > 1, otherwise returns the run unchanged.
        """
        if len(run) <= 1:
            return run

        from ..circuits import GateInstruction

        matrices = [inst.get_matrix() for inst in run]
        fused_mat = _fuse_single_qubit_matrices(matrices)
        names = "+".join(inst.name for inst in run)
        fused_inst = GateInstruction(
            name="fused_1q",
            qubits=list(run[0].qubits),
            params=[],
            matrix=fused_mat,
            label=f"[{names}]",
        )
        return [fused_inst]

    def _fuse_two_run(self, run: list) -> list:
        """
        Fuse a run of two-qubit gates on the same adjacent qubit pair.
        Returns a list with one element if len(run) > 1, else unchanged.
        """
        if len(run) <= 1:
            return run

        from ..circuits import GateInstruction

        matrices = [inst.get_matrix() for inst in run]
        try:
            fused_mat = _fuse_two_qubit_matrices(matrices)
        except Exception as exc:
            # Defensive: if fusion fails for any reason, return original run
            logger.warning("GateFuser: two-qubit fusion failed (%s), skipping.", exc)
            return run

        names = "+".join(inst.name for inst in run)
        fused_inst = GateInstruction(
            name="fused_2q",
            qubits=list(run[0].qubits),
            params=[],
            matrix=fused_mat,
            label=f"[{names}]",
        )
        return [fused_inst]

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    def fusion_report(self, circuit) -> dict:
        """
        Return a dict summarising what fusion would do (without modifying
        the circuit).

        Returns
        -------
        dict with keys:
            original_count : int
            fused_count : int
            saved : int
            single_qubit_fusions : int   (number of runs merged)
            two_qubit_fusions : int
        """
        from ..circuits import Circuit

        before = len(circuit.instructions)
        fused_circuit = self(circuit)
        after = len(fused_circuit.instructions)

        # Count fusion events per type
        fused_1q = sum(
            1 for inst in fused_circuit.instructions
            if inst.name == "fused_1q"
        )
        fused_2q = sum(
            1 for inst in fused_circuit.instructions
            if inst.name == "fused_2q"
        )

        return {
            "original_count": before,
            "fused_count": after,
            "saved": before - after,
            "single_qubit_fusions": fused_1q,
            "two_qubit_fusions": fused_2q,
        }

    def __repr__(self) -> str:
        return (
            f"GateFuser(fuse_single={self.fuse_single}, "
            f"fuse_two={self.fuse_two}, max_window={self.max_window})"
        )


# ---------------------------------------------------------------------------
# Module-level convenience instance
# ---------------------------------------------------------------------------

#: Default fuser with both single- and two-qubit fusion enabled.
default_fuser = GateFuser(fuse_single=True, fuse_two=True)


def fuse(circuit, fuse_single: bool = True, fuse_two: bool = True,
         max_window: Optional[int] = None):
    """
    Convenience function: fuse gates in *circuit* and return a new circuit.

    Parameters
    ----------
    circuit : Circuit
        Input circuit.
    fuse_single : bool
        Fuse consecutive single-qubit gates on the same qubit (default True).
    fuse_two : bool
        Fuse consecutive two-qubit gates on the same qubit pair (default True).
    max_window : int or None
        Maximum block size for fusion (None = unlimited).

    Returns
    -------
    Circuit
        New circuit with fused gate instructions.

    Examples
    --------
    >>> from mps_xtrap import Circuit, MPSSimulator
    >>> from mps_xtrap.fusion import fuse
    >>> c = Circuit(4)
    >>> c.h(0).rz(0.5, 0).rx(0.3, 0)   # 3 gates on qubit 0 → fused to 1
    >>> fc = fuse(c)
    >>> sim = MPSSimulator(chi=64)
    >>> state = sim.run(fc)
    """
    return GateFuser(
        fuse_single=fuse_single,
        fuse_two=fuse_two,
        max_window=max_window,
    )(circuit)


__all__ = ["GateFuser", "fuse", "default_fuser"]
