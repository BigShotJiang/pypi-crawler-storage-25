"""
Quantum circuit representation and gate application on MPS.

A Circuit is an ordered list of gate instructions. The Simulator
applies these instructions to an MPS, performing SVD truncations
at two-qubit gates.
"""

from __future__ import annotations
import numpy as np
from numpy.typing import NDArray
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Union, Dict, Any
import logging

from ..core.mps import MPS
from ..gates import get_gate, SINGLE_QUBIT_GATES, TWO_QUBIT_GATES

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Gate instruction
# ---------------------------------------------------------------------------

@dataclass
class GateInstruction:
    """
    A single gate application.

    Attributes
    ----------
    name : str
        Gate name (e.g., 'H', 'CNOT', 'Rx').
    qubits : list of int
        Target qubits. Length 1 for single-qubit gates, 2 for two-qubit.
    params : list of float
        Gate parameters (e.g., rotation angles).
    matrix : ndarray or None
        Explicit gate matrix (overrides name lookup if provided).
    label : str
        Human-readable label for circuit diagrams.
    """
    name: str
    qubits: List[int]
    params: List[float] = field(default_factory=list)
    matrix: Optional[NDArray] = None
    label: str = ""

    def __post_init__(self):
        if not self.label:
            self.label = self.name
        if not isinstance(self.qubits, list):
            self.qubits = list(self.qubits)

    def get_matrix(self) -> NDArray:
        if self.matrix is not None:
            return self.matrix
        return get_gate(self.name, *self.params)

    def __repr__(self) -> str:
        q = ",".join(map(str, self.qubits))
        p = f"({','.join(f'{x:.4f}' for x in self.params)})" if self.params else ""
        return f"{self.name}{p}[{q}]"


# ---------------------------------------------------------------------------
# Circuit
# ---------------------------------------------------------------------------

class Circuit:
    """
    A quantum circuit as an ordered list of gate instructions.

    Supports a fluent builder API:
        c = Circuit(4)
        c.h(0).cx(0,1).rz(np.pi/4, 2).measure_all()
    """

    def __init__(self, n_qubits: int):
        self.n = n_qubits
        self.instructions: List[GateInstruction] = []

    # ------------------------------------------------------------------
    # Builder API
    # ------------------------------------------------------------------

    def _add(self, name: str, qubits, params=None, matrix=None) -> 'Circuit':
        if isinstance(qubits, int):
            qubits = [qubits]
        inst = GateInstruction(
            name=name,
            qubits=list(qubits),
            params=list(params) if params else [],
            matrix=matrix,
        )
        self.instructions.append(inst)
        return self

    # Single-qubit gates
    def i(self, q): return self._add('I', [q])
    def x(self, q): return self._add('X', [q])
    def y(self, q): return self._add('Y', [q])
    def z(self, q): return self._add('Z', [q])
    def h(self, q): return self._add('H', [q])
    def s(self, q): return self._add('S', [q])
    def t(self, q): return self._add('T', [q])
    def sdg(self, q): return self._add('Sdg', [q])
    def tdg(self, q): return self._add('Tdg', [q])

    def rx(self, theta: float, q: int): return self._add('Rx', [q], [theta])
    def ry(self, theta: float, q: int): return self._add('Ry', [q], [theta])
    def rz(self, theta: float, q: int): return self._add('Rz', [q], [theta])
    def p(self, phi: float, q: int): return self._add('P', [q], [phi])
    def u(self, theta, phi, lam, q): return self._add('U', [q], [theta, phi, lam])

    # Two-qubit gates
    def cx(self, ctrl, tgt): return self._add('CNOT', [ctrl, tgt])
    def cnot(self, ctrl, tgt): return self._add('CNOT', [ctrl, tgt])
    def cz(self, q1, q2): return self._add('CZ', [q1, q2])
    def swap(self, q1, q2): return self._add('SWAP', [q1, q2])
    def iswap(self, q1, q2): return self._add('iSWAP', [q1, q2])
    def xx(self, theta, q1, q2): return self._add('XX', [q1, q2], [theta])
    def yy(self, theta, q1, q2): return self._add('YY', [q1, q2], [theta])
    def zz(self, theta, q1, q2): return self._add('ZZ', [q1, q2], [theta])
    def crz(self, theta, ctrl, tgt): return self._add('CRz', [ctrl, tgt], [theta])
    def cp(self, phi, ctrl, tgt): return self._add('CP', [ctrl, tgt], [phi])

    # Custom matrix
    def unitary(self, matrix: NDArray, qubits): return self._add('U_custom', qubits, matrix=matrix)

    # ------------------------------------------------------------------
    # Helpers for common circuit patterns
    # ------------------------------------------------------------------

    def barrier(self, *qubits):
        """Barrier is a no-op for simulation but marks a layer boundary."""
        return self  # no-op

    def __len__(self):
        return len(self.instructions)

    def depth(self) -> int:
        """Estimate circuit depth (number of non-overlapping gate layers)."""
        last_use = [-1] * self.n
        max_layer = -1
        for inst in self.instructions:
            d = max(last_use[q] for q in inst.qubits) + 1
            max_layer = max(max_layer, d)
            for q in inst.qubits:
                last_use[q] = d
        return max_layer + 1  # convert 0-indexed layer to count

    def two_qubit_count(self) -> int:
        return sum(1 for inst in self.instructions if len(inst.qubits) == 2)

    def __repr__(self) -> str:
        return (f"Circuit(n={self.n}, gates={len(self.instructions)}, "
                f"depth≈{self.depth()}, 2q={self.two_qubit_count()})")

    def draw(self) -> str:
        """Simple text-based circuit diagram."""
        lines = [f"q{i}: " for i in range(self.n)]
        for inst in self.instructions:
            label = str(inst)
            for i, q in enumerate(inst.qubits):
                lines[q] += f"──{label}──"
            # Pad other qubits
            max_len = max(len(l) for l in lines)
            lines = [l + '─' * (max_len - len(l)) for l in lines]
        return '\n'.join(lines)


# ---------------------------------------------------------------------------
# MPS Simulator
# ---------------------------------------------------------------------------

class MPSSimulator:
    """
    Applies a Circuit to an MPS state.

    Two-qubit gates on non-adjacent qubits are handled by first
    swapping qubits into adjacent positions, applying the gate,
    then swapping back.

    Parameters
    ----------
    chi : int
        Maximum bond dimension for SVD truncation.
    svd_threshold : float
        Singular values below this are discarded before bond-dim cap.
    device : str
        'cpu' (default) or 'cuda'. With 'cuda', all tensor operations
        run on the GPU via CuPy. Falls back to CPU automatically if
        CuPy is not installed or no GPU is detected.
    fusion : bool or GateFuser
        Gate fusion strategy applied before simulation.

        * ``False`` (default) — no fusion.
        * ``True`` — use the default :class:`~mps_xtrap.fusion.GateFuser`
          with both single-qubit and two-qubit fusion enabled.
        * A :class:`~mps_xtrap.fusion.GateFuser` instance — use that fuser
          directly, giving full control over ``fuse_single``, ``fuse_two``,
          and ``max_window``.

        Fusion never changes simulation accuracy; it only reduces the number
        of gate applications (and therefore SVD calls) by merging consecutive
        gates on the same qubit or qubit pair into a single combined gate.

    Examples
    --------
    >>> sim = MPSSimulator(chi=64, fusion=True)           # default fusion
    >>> state = sim.run(circuit)

    >>> from mps_xtrap.fusion import GateFuser
    >>> fuser = GateFuser(fuse_single=True, fuse_two=True, max_window=4)
    >>> sim = MPSSimulator(chi=64, fusion=fuser)
    >>> state = sim.run(circuit)
    """

    def __init__(
        self,
        chi: int,
        svd_threshold: float = 1e-14,
        device: str = 'cpu',
        fusion=False,
    ):
        self.chi = chi
        self.svd_threshold = svd_threshold
        self.device = device

        # Resolve fusion argument to None or a GateFuser instance
        if fusion is False or fusion is None:
            self._fuser = None
        elif fusion is True:
            from ..fusion import GateFuser
            self._fuser = GateFuser(fuse_single=True, fuse_two=True)
        else:
            # Assume a GateFuser (or any callable that accepts a Circuit)
            self._fuser = fusion

    # ------------------------------------------------------------------
    # Public property for inspection / replacement after construction
    # ------------------------------------------------------------------

    @property
    def fusion(self):
        """The active :class:`~mps_xtrap.fusion.GateFuser`, or ``None``."""
        return self._fuser

    @fusion.setter
    def fusion(self, value):
        from ..fusion import GateFuser
        if value is False or value is None:
            self._fuser = None
        elif value is True:
            self._fuser = GateFuser(fuse_single=True, fuse_two=True)
        else:
            self._fuser = value

    def run(self, circuit: Circuit, _skip_credit: bool = False) -> MPS:
        """
        Simulate circuit from |0...0> and return final MPS state.

        If a fusion strategy is configured (``fusion=True`` or a
        :class:`~mps_xtrap.fusion.GateFuser` instance was passed at
        construction), the circuit is fused before simulation.  The
        original circuit object is never modified.

        Returns
        -------
        MPS
            Final state after all gates applied (on self.device).

        Raises
        ------
        CreditExhaustedError
            If the free-tier monthly credit limit has been reached.
            Subscribe at https://flutterwave.com/pay/6yptuvqab8cu
        """
        if not _skip_credit:
            from ..license import _check_and_consume_credit
            _check_and_consume_credit(1)
        if self._fuser is not None:
            circuit = self._fuser(circuit)
        state = MPS(circuit.n, self.chi, device=self.device)
        self._apply_circuit(circuit, state)
        return state

    def run_from(self, circuit: Circuit, state: MPS) -> MPS:
        """Apply circuit to an existing MPS state (modifies a copy).

        Fusion (if configured) is applied before simulation.
        """
        if self._fuser is not None:
            circuit = self._fuser(circuit)
        new_state = state.copy()
        new_state.chi = self.chi
        self._apply_circuit(circuit, new_state)
        return new_state

    def _apply_circuit(self, circuit: Circuit, state: MPS):
        for inst in circuit.instructions:
            if len(inst.qubits) == 1:
                self._apply_single(inst, state)
            elif len(inst.qubits) == 2:
                self._apply_two(inst, state)
            else:
                raise ValueError(f"Gates on >2 qubits not yet supported: {inst}")

    def _apply_single(self, inst: GateInstruction, state: MPS):
        """Apply single-qubit gate via matrix multiplication on physical index."""
        from ..core.mps import _to_backend
        xp = state.xp
        q = inst.qubits[0]
        gate = _to_backend(inst.get_matrix(), xp)   # (2,2) on device
        t = state.get_tensor(q)                      # (chi_l, 2, chi_r) on device
        state.set_tensor(q, xp.einsum("sp,lpr->lsr", gate, t))
        state.center = None

    def _apply_two(self, inst: GateInstruction, state: MPS):
        """Apply two-qubit gate with SVD truncation."""
        from ..core.mps import _to_backend
        xp = state.xp
        q1, q2 = inst.qubits

        # Handle non-adjacent qubits via SWAP chain
        if abs(q1 - q2) != 1:
            self._apply_two_nonlocal(inst, state)
            return

        # Ensure q1 < q2
        if q1 > q2:
            q1, q2 = q2, q1
            gate = inst.get_matrix()
            gate = gate.transpose(1, 0, 3, 2)   # swap qubit ordering
        else:
            gate = inst.get_matrix()

        gate = _to_backend(gate, xp)

        # Build theta: two-site tensor
        A = state.get_tensor(q1)   # (chi_l, 2, chi_m)
        B = state.get_tensor(q2)   # (chi_m, 2, chi_r)
        theta = xp.einsum("lir,rjs->lijs", A, B)            # (chi_l, 2, 2, chi_r)
        theta = xp.einsum("abij,lijs->labs", gate, theta)   # apply gate

        state.apply_svd_truncation(q1, theta, chi=self.chi, svd_threshold=self.svd_threshold)
        state.center = None

    def _apply_two_nonlocal(self, inst: GateInstruction, state: MPS):
        """
        Apply a gate on non-adjacent qubits via SWAP chain.
        Brings qubits adjacent, applies gate, swaps back.
        """
        from ..gates import SWAP as make_swap
        q1, q2 = inst.qubits
        if q1 > q2:
            q1, q2 = q2, q1

        # Bubble q2 adjacent to q1
        swap_gate = make_swap()
        swap_inst = GateInstruction('SWAP', [0, 1], matrix=swap_gate)

        for pos in range(q2, q1 + 1, -1):
            swap_inst.qubits = [pos - 1, pos]
            swap_inst.matrix = swap_gate
            self._apply_two(swap_inst, state)

        # Now apply actual gate at (q1, q1+1)
        modified_inst = GateInstruction(
            inst.name, [q1, q1 + 1],
            inst.params, inst.matrix, inst.label
        )
        self._apply_two(modified_inst, state)

        # Swap back
        for pos in range(q1 + 1, q2):
            swap_inst.qubits = [pos, pos + 1]
            self._apply_two(swap_inst, state)

    def expectation_value(
        self,
        state: MPS,
        observable: str,
        site: int,
        site2: Optional[int] = None,
    ) -> float:
        """
        Convenience wrapper to compute expectation values.

        Parameters
        ----------
        state : MPS
        observable : str
            'X', 'Y', 'Z', 'ZZ', 'XX', etc.
        site : int
            Primary site.
        site2 : int, optional
            Second site for two-qubit observables.
        """
        if observable == 'Z':
            return state.expectation_pauli_z(site)
        elif observable == 'X':
            return state.expectation_pauli_x(site)
        elif observable == 'Y':
            return state.expectation_pauli_y(site)
        elif observable in ('ZZ', 'XX', 'YY') and site2 is not None:
            from ..gates import Z, X, Y
            ops = {'ZZ': Z, 'XX': X, 'YY': Y}
            op1 = ops[observable]()
            op = np.einsum('ij,kl->ikjl', op1, op1)
            if abs(site - site2) == 1:
                return float(np.real(state.expectation_two(op, min(site, site2))))
            else:
                raise NotImplementedError("Non-adjacent two-site observables not implemented")
        else:
            raise ValueError(f"Unknown observable: {observable}")
