from setuptools import setup, find_packages

setup(
    name="mps_xtrap",
    version="2.2.1",
    description="MPS-based quantum circuit simulator with multilevel Richardson extrapolation, gate fusion, and qubit measurement",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
    install_requires=["numpy>=1.21"],
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "mps_xtrap=mps_xtrap.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering :: Physics",
    ],
)
