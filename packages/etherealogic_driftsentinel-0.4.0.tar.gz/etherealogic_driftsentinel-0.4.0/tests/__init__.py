"""DriftSentinel test suite."""
