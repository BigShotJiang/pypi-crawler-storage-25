"""
Output formatters for CLI.
"""

import json
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax

console = Console()


def print_json(data: Any) -> None:
    """Print data as formatted JSON."""
    console.print(Syntax(json.dumps(data, indent=2, default=str), "json"))


def print_error(message: str) -> None:
    """Print error message."""
    console.print(f"[red]Error:[/red] {message}")


def print_success(message: str) -> None:
    """Print success message."""
    console.print(f"[green]Success:[/green] {message}")


def print_warning(message: str) -> None:
    """Print warning message."""
    console.print(f"[yellow]Warning:[/yellow] {message}")


def print_info(message: str) -> None:
    """Print info message."""
    console.print(f"[blue]Info:[/blue] {message}")


def print_operations_table(operations: list[dict[str, Any]]) -> None:
    """Print operations as a table."""
    table = Table(title="Available Operations")

    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("Category", style="yellow")
    table.add_column("Type", style="magenta")
    table.add_column("Risk", style="red")

    for op in operations:
        risk_style = {
            "low": "green",
            "medium": "yellow",
            "high": "red",
            "critical": "bold red",
        }.get(op.get("risk_level", "low"), "white")

        table.add_row(
            op["id"],
            op["name"],
            op["category"],
            op["operation_type"],
            f"[{risk_style}]{op['risk_level']}[/{risk_style}]",
        )

    console.print(table)


def print_operation_detail(op: dict[str, Any]) -> None:
    """Print detailed operation info."""
    console.print(Panel(f"[bold]{op['name']}[/bold]", subtitle=op["id"]))
    console.print(f"\n[dim]{op['description']}[/dim]\n")

    # Metadata
    console.print(f"[cyan]Category:[/cyan] {op['category']}")
    console.print(f"[cyan]Type:[/cyan] {op['operation_type']}")
    console.print(f"[cyan]Risk Level:[/cyan] {op['risk_level']}")
    console.print(f"[cyan]Database:[/cyan] {op['database']}")

    # Inputs
    if op.get("inputs"):
        console.print("\n[bold]Inputs:[/bold]")
        for name, field in op["inputs"].items():
            required = "[red]*[/red]" if field.get("required", True) else ""
            console.print(f"  {required}[cyan]{name}[/cyan] ({field.get('type', 'string')})")
            if field.get("description"):
                console.print(f"    [dim]{field['description']}[/dim]")
            if field.get("example"):
                console.print(f"    [dim]Example: {field['example']}[/dim]")


def print_execution_result(result: dict[str, Any]) -> None:
    """Print execution result."""
    success = result.get("success", False)
    dry_run = result.get("dry_run", True)

    # Header
    if dry_run:
        console.print(Panel("[yellow]DRY-RUN MODE - No changes were made[/yellow]"))
    else:
        if success:
            console.print(Panel("[green]Execution Complete[/green]"))
        else:
            console.print(Panel("[red]Execution Failed[/red]"))

    # Details
    console.print(f"\n[cyan]Operation:[/cyan] {result.get('operation_id')}")
    console.print(f"[cyan]Success:[/cyan] {success}")
    console.print(f"[cyan]Affected Rows:[/cyan] {result.get('affected_rows', 0)}")
    console.print(f"[cyan]Execution Time:[/cyan] {result.get('execution_time_ms', 0):.2f}ms")

    if result.get("message"):
        console.print(f"\n[cyan]Message:[/cyan]\n{result['message']}")

    if result.get("error"):
        console.print(f"\n[red]Error:[/red]\n{result['error']}")

    if result.get("data"):
        console.print("\n[cyan]Data:[/cyan]")
        print_json(result["data"])
