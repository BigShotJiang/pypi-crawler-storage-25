"""
MCP Server for Claude Desktop integration.

This server runs locally and exposes CS operations as MCP tools.
Claude Desktop can then call these tools to execute CS operations.

Tools are automatically filtered based on the user's API key role:
  cs_lead   - Read ops + write ops (medium risk max), logs
  cs_admin  - All ops + rollback, logs
  superuser - Everything (raw SQL, NRQL, audit)

Usage:
    harmony-cs mcp-server

Claude Desktop config (~/.claude/claude_desktop_config.json):
    {
      "mcpServers": {
        "harmony-cs": {
          "command": "harmony-cs",
          "args": ["mcp-server"]
        }
      }
    }
"""

import asyncio
import json
from typing import Any

from mcp.server import Server, InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    CallToolResult,
    ServerCapabilities,
)

from .api_client import HarmonyCSClient, APIError
from .config import get_api_key, get_api_url


def create_mcp_server() -> Server:
    """Create and configure the MCP server."""
    server = Server("harmony-cs")

    # Cache for operations and user info
    _operations_cache: list[dict] | None = None
    _user_info_cache: dict | None = None

    def get_client() -> HarmonyCSClient:
        """Get API client with MCP source identification."""
        api_url = get_api_url()
        api_key = get_api_key()

        if not api_url or not api_key:
            raise ValueError(
                "Not configured. Run 'harmony-cs config set-url <url>' and 'harmony-cs auth login'"
            )

        return HarmonyCSClient(api_url=api_url, api_key=api_key, source="mcp")

    def _get_user_permissions(info: dict) -> dict:
        """Extract permissions from /info response."""
        permissions = info.get("permissions", {})
        return {
            "role": info.get("user_role", "cs_lead"),
            "raw_query": permissions.get("raw_query", False),
            "raw_nrql": permissions.get("raw_nrql", False),
            "rollback": permissions.get("rollback", False),
            "audit": permissions.get("audit", False),
        }

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """List available tools based on CS operations and user role."""
        nonlocal _operations_cache, _user_info_cache

        try:
            client = get_client()
            _user_info_cache = client.info()
            _operations_cache = client.list_operations()
        except Exception as e:
            # Return basic tools if we can't fetch operations
            return [
                Tool(
                    name="harmony_cs_status",
                    description="Check Harmony CS connection status",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    },
                ),
            ]

        perms = _get_user_permissions(_user_info_cache)

        # Available databases for raw queries
        databases = [
            "harmony_transaction",
            "harmony_product",
            "harmony_channel",
            "harmony_auth",
            "harmony_portal",
            "harmony_review",
            "harmony_disbursement",
        ]

        tools = [
            # Meta tools (available to all roles)
            Tool(
                name="harmony_cs_status",
                description="Check Harmony CS connection status and your role",
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
            Tool(
                name="harmony_cs_list_operations",
                description="List all available CS operations. Optionally filter by category.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "category": {
                            "type": "string",
                            "description": "Filter by category (transaction, product, channel, batch)",
                        },
                    },
                },
            ),
            Tool(
                name="harmony_cs_show_operation",
                description="Show details of a specific CS operation including required inputs",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "operation_id": {
                            "type": "string",
                            "description": "The operation ID (e.g., 'transaction.refund-ship-rejected')",
                        },
                    },
                    "required": ["operation_id"],
                },
            ),
        ]

        # Raw SQL Query tools (superuser only)
        if perms["raw_query"]:
            tools.extend([
                Tool(
                    name="harmony_cs_query",
                    description=(
                        "[SUPERUSER] Execute a raw SELECT query on any Harmony database. "
                        "Use this for flexible data investigation when predefined operations are insufficient. "
                        "Only SELECT queries are allowed - write operations are blocked (enforced by DB-level readonly user). "
                        "Supports dev/staging/production environments. "
                        "Use harmony_cs_schema first to understand table structures."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "database": {
                                "type": "string",
                                "description": "Target database",
                                "enum": databases,
                            },
                            "sql": {
                                "type": "string",
                                "description": "SELECT query to execute (e.g., 'SELECT * FROM table WHERE id = ...')",
                            },
                            "environment": {
                                "type": "string",
                                "description": "Target environment (default: development)",
                                "enum": ["development", "staging", "production"],
                                "default": "development",
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Maximum rows to return (default: 100, max: 1000)",
                                "default": 100,
                            },
                        },
                        "required": ["database", "sql"],
                    },
                ),
            ])

        # Schema tools (available to all roles)
        tools.extend([
            Tool(
                name="harmony_cs_schema",
                description=(
                    "Get database schema information including tables, columns, and relationships. "
                    "Use this before running raw queries to understand the data structure."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "database": {
                            "type": "string",
                            "description": "Database to get schema for",
                            "enum": databases,
                        },
                    },
                    "required": ["database"],
                },
            ),
            Tool(
                name="harmony_cs_list_schemas",
                description="List all available databases and their schema endpoints.",
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
        ])

        # Log query tools (available to all roles)
        tools.extend([
            Tool(
                name="harmony_cs_query_logs",
                description=(
                    "Query application logs from New Relic. "
                    "Search by service (transaction/product/channel/auth/portal/disbursement/review), "
                    "component (api/bo/worker/cronjob/etc.), environment, and keywords. "
                    "Use search_term to find logs containing a transaction_id, sku_id, error message, etc."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "service": {
                            "type": "string",
                            "description": "Harmony service name",
                            "enum": [
                                "transaction", "product", "channel",
                                "auth", "portal", "disbursement", "review", "worker",
                            ],
                        },
                        "component": {
                            "type": "string",
                            "description": "Service component (api, bo, worker, background-worker, event-consumer, cronjob, data, outbox-worker, celery). Omit to search all components.",
                        },
                        "environment": {
                            "type": "string",
                            "description": "Deployment environment (default: development)",
                            "enum": ["development", "staging", "production"],
                            "default": "development",
                        },
                        "search_term": {
                            "type": "string",
                            "description": "Search term to find in log messages (e.g., transaction_id, sku_id, error text)",
                        },
                        "level": {
                            "type": "string",
                            "description": "Log level filter (ERROR, WARN, INFO, DEBUG)",
                        },
                        "since": {
                            "type": "string",
                            "description": "Time range in NRQL format (default: '1 HOUR AGO'). Examples: '30 MINUTES AGO', '1 DAY AGO', '2 HOURS AGO'",
                            "default": "1 HOUR AGO",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max log entries to return (default: 100, max: 2000)",
                            "default": 100,
                        },
                    },
                    "required": ["service"],
                },
            ),
            Tool(
                name="harmony_cs_query_trace",
                description=(
                    "Query all logs for a specific trace.id. "
                    "Use this after finding an error log to see the full request flow across services. "
                    "Returns logs sorted by timestamp for easy trace reading."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "trace_id": {
                            "type": "string",
                            "description": "The trace.id value from a log entry (e.g., '1af60575b158849366c034110187f420')",
                        },
                        "environment": {
                            "type": "string",
                            "description": "Deployment environment (default: development)",
                            "enum": ["development", "staging", "production"],
                            "default": "development",
                        },
                        "service": {
                            "type": "string",
                            "description": "Limit to a specific service. Omit to search all services.",
                            "enum": [
                                "transaction", "product", "channel",
                                "auth", "portal", "disbursement", "review", "worker",
                            ],
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max log entries (default: 500)",
                            "default": 500,
                        },
                    },
                    "required": ["trace_id"],
                },
            ),
        ])

        # Raw NRQL (superuser only)
        if perms["raw_nrql"]:
            tools.append(
                Tool(
                    name="harmony_cs_query_nrql",
                    description=(
                        "[SUPERUSER] Execute a raw NRQL query against New Relic. "
                        "For advanced log investigation. Example: "
                        "SELECT * FROM Log WHERE message LIKE '%error%' SINCE 1 HOUR AGO LIMIT 50"
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "nrql": {
                                "type": "string",
                                "description": "NRQL query to execute",
                            },
                            "environment": {
                                "type": "string",
                                "description": "Environment context (default: development)",
                                "enum": ["development", "staging", "production"],
                                "default": "development",
                            },
                        },
                        "required": ["nrql"],
                    },
                ),
            )

        # Log services list (available to all roles)
        tools.append(
            Tool(
                name="harmony_cs_log_services",
                description="List available services and their components for log queries.",
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
        )

        # Rollback tools (cs_admin + superuser)
        if perms["rollback"]:
            tools.extend([
                Tool(
                    name="harmony_cs_list_rollbacks",
                    description=(
                        "[CS_ADMIN+] List available rollback snapshots. "
                        "Shows previous write operations that can be rolled back."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "database": {
                                "type": "string",
                                "description": "Target database (default: harmony_transaction)",
                                "enum": databases,
                                "default": "harmony_transaction",
                            },
                            "environment": {
                                "type": "string",
                                "description": "Target environment (default: development)",
                                "enum": ["development", "staging", "production"],
                                "default": "development",
                            },
                        },
                    },
                ),
                Tool(
                    name="harmony_cs_execute_rollback",
                    description=(
                        "[CS_ADMIN+] Execute a rollback to restore data to its before-state. "
                        "Use harmony_cs_list_rollbacks first to find the execution_id."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "execution_id": {
                                "type": "string",
                                "description": "Execution ID from rollback list",
                            },
                            "database": {
                                "type": "string",
                                "description": "Target database (default: harmony_transaction)",
                                "enum": databases,
                                "default": "harmony_transaction",
                            },
                            "dry_run": {
                                "type": "boolean",
                                "description": "Preview rollback without executing (default: true)",
                                "default": True,
                            },
                        },
                        "required": ["execution_id"],
                    },
                ),
            ])

        # Add a tool for each operation (already filtered by server based on role)
        for op in _operations_cache:
            # Build input schema from operation inputs
            properties = {}
            required = []

            for name, field in op.get("inputs", {}).items():
                prop = {
                    "type": "string",  # Simplified - all as strings
                    "description": field.get("description", name),
                }
                if field.get("example"):
                    prop["description"] += f" (e.g., {field['example']})"

                properties[name] = prop

                if field.get("required", True):
                    required.append(name)

            # Add dry_run parameter
            properties["dry_run"] = {
                "type": "boolean",
                "description": "If true, show what would happen without making changes (default: true)",
                "default": True,
            }

            # Add environment parameter
            properties["environment"] = {
                "type": "string",
                "description": "Target environment (default: development)",
                "enum": ["development", "staging", "production"],
                "default": "development",
            }

            tool = Tool(
                name=f"harmony_cs_execute_{op['id'].replace('.', '_').replace('-', '_')}",
                description=f"[{op['risk_level'].upper()}] {op['name']}: {op['description']}",
                inputSchema={
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            )
            tools.append(tool)

        return tools

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> CallToolResult:
        """Execute a tool."""
        try:
            client = get_client()

            # Meta tools
            if name == "harmony_cs_status":
                info = client.info()
                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps({
                                "status": "connected",
                                "api_url": get_api_url(),
                                "user_role": info.get("user_role"),
                                "permissions": info.get("permissions"),
                            }, indent=2),
                        )
                    ]
                )

            elif name == "harmony_cs_list_operations":
                category = arguments.get("category")
                operations = client.list_operations(category=category)

                # Format for readability
                result = []
                for op in operations:
                    result.append({
                        "id": op["id"],
                        "name": op["name"],
                        "category": op["category"],
                        "type": op["operation_type"],
                        "risk": op["risk_level"],
                    })

                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(result, indent=2),
                        )
                    ]
                )

            elif name == "harmony_cs_show_operation":
                operation_id = arguments.get("operation_id")
                operation = client.get_operation(operation_id)

                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(operation, indent=2),
                        )
                    ]
                )

            elif name == "harmony_cs_query":
                # Raw SQL query (superuser only)
                database = arguments.get("database")
                sql = arguments.get("sql")
                limit = arguments.get("limit", 100)
                environment = arguments.get("environment", "development")

                result = client.query(database, sql, limit=limit, environment=environment)

                if result.get("success"):
                    response = {
                        "success": True,
                        "database": result.get("database"),
                        "row_count": result.get("row_count"),
                        "columns": result.get("columns"),
                        "data": result.get("data"),
                        "execution_time_ms": result.get("execution_time_ms"),
                    }
                    if result.get("warning"):
                        response["warning"] = result.get("warning")
                else:
                    response = {
                        "success": False,
                        "error": result.get("error"),
                    }

                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(response, indent=2, default=str),
                        )
                    ]
                )

            elif name == "harmony_cs_schema":
                # Get database schema
                database = arguments.get("database")
                result = client.get_schema(database)

                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=result.get("schema_markdown", json.dumps(result, indent=2)),
                        )
                    ]
                )

            elif name == "harmony_cs_list_schemas":
                # List available schemas
                result = client.list_schemas()

                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(result, indent=2),
                        )
                    ]
                )

            elif name == "harmony_cs_query_logs":
                result = client.query_logs(
                    service=arguments.get("service"),
                    component=arguments.get("component"),
                    environment=arguments.get("environment", "development"),
                    search_term=arguments.get("search_term"),
                    level=arguments.get("level"),
                    since=arguments.get("since", "1 HOUR AGO"),
                    limit=arguments.get("limit", 100),
                )

                if result.get("success"):
                    # Format logs for readability
                    logs = result.get("logs", [])
                    formatted = {
                        "success": True,
                        "service": result.get("service"),
                        "component": result.get("component"),
                        "environment": result.get("environment"),
                        "total_count": result.get("total_count"),
                        "nrql": result.get("nrql"),
                        "logs": [
                            {
                                "timestamp": log.get("timestamp"),
                                "level": log.get("level"),
                                "message": log.get("message"),
                                "entity_name": log.get("entity_name"),
                                "hostname": log.get("hostname"),
                                "trace_id": log.get("trace_id"),
                            }
                            for log in logs
                        ],
                        "execution_time_ms": result.get("execution_time_ms"),
                    }
                else:
                    formatted = {
                        "success": False,
                        "error": result.get("error"),
                        "nrql": result.get("nrql"),
                    }

                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(formatted, indent=2, default=str),
                        )
                    ]
                )

            elif name == "harmony_cs_query_trace":
                result = client.query_trace(
                    trace_id=arguments.get("trace_id"),
                    environment=arguments.get("environment", "development"),
                    service=arguments.get("service"),
                    limit=arguments.get("limit", 500),
                )

                if result.get("success"):
                    logs = result.get("logs", [])
                    formatted = {
                        "success": True,
                        "trace_id": arguments.get("trace_id"),
                        "environment": result.get("environment"),
                        "total_count": result.get("total_count"),
                        "nrql": result.get("nrql"),
                        "logs": [
                            {
                                "timestamp": log.get("timestamp"),
                                "level": log.get("level"),
                                "message": log.get("message"),
                                "entity_name": log.get("entity_name"),
                                "hostname": log.get("hostname"),
                                "span_id": log.get("span_id"),
                            }
                            for log in logs
                        ],
                    }
                else:
                    formatted = {
                        "success": False,
                        "error": result.get("error"),
                        "nrql": result.get("nrql"),
                    }

                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(formatted, indent=2, default=str),
                        )
                    ]
                )

            elif name == "harmony_cs_query_nrql":
                result = client.query_nrql(
                    nrql=arguments.get("nrql"),
                    environment=arguments.get("environment", "development"),
                )
                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(result, indent=2, default=str),
                        )
                    ]
                )

            elif name == "harmony_cs_log_services":
                result = client.list_log_services()
                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(result, indent=2),
                        )
                    ]
                )

            elif name == "harmony_cs_list_rollbacks":
                database = arguments.get("database", "harmony_transaction")
                environment = arguments.get("environment", "development")
                result = client.list_rollbacks(database=database)
                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(result, indent=2, default=str),
                        )
                    ]
                )

            elif name == "harmony_cs_execute_rollback":
                execution_id = arguments.get("execution_id")
                database = arguments.get("database", "harmony_transaction")
                dry_run = arguments.get("dry_run", True)
                result = client.execute_rollback(
                    execution_id=execution_id,
                    database=database,
                    dry_run=dry_run,
                )

                response = {
                    "success": result.get("success"),
                    "execution_id": result.get("execution_id"),
                    "message": result.get("message"),
                    "rows_restored": result.get("rows_restored"),
                    "dry_run": dry_run,
                }
                if result.get("error"):
                    response["error"] = result.get("error")
                if dry_run and result.get("success"):
                    response["next_step"] = (
                        "This was a dry-run. To execute rollback for real, "
                        "call this tool again with dry_run=false"
                    )

                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(response, indent=2, default=str),
                        )
                    ]
                )

            elif name.startswith("harmony_cs_execute_"):
                # Extract operation ID from tool name
                op_id_part = name.replace("harmony_cs_execute_", "")
                # Convert back: transaction_refund_ship_rejected -> transaction.refund-ship-rejected
                parts = op_id_part.split("_")
                operation_id = parts[0] + "." + "-".join(parts[1:])

                # Get flags
                dry_run = arguments.pop("dry_run", True)
                environment = arguments.pop("environment", "development")

                # Execute
                result = client.execute(operation_id, arguments, dry_run=dry_run, environment=environment)

                # Format response
                response = {
                    "success": result.get("success"),
                    "dry_run": result.get("dry_run"),
                    "operation_id": result.get("operation_id"),
                    "message": result.get("message"),
                    "affected_rows": result.get("affected_rows"),
                    "execution_time_ms": result.get("execution_time_ms"),
                }

                if result.get("error"):
                    response["error"] = result.get("error")

                if result.get("data"):
                    response["data"] = result.get("data")

                # Add guidance
                if dry_run and result.get("success"):
                    response["next_step"] = (
                        "This was a dry-run. To execute for real, "
                        "call this tool again with dry_run=false"
                    )

                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=json.dumps(response, indent=2, default=str),
                        )
                    ]
                )

            else:
                return CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=f"Unknown tool: {name}",
                        )
                    ],
                    isError=True,
                )

        except APIError as e:
            return CallToolResult(
                content=[
                    TextContent(
                        type="text",
                        text=json.dumps({
                            "error": e.detail,
                            "status_code": e.status_code,
                        }),
                    )
                ],
                isError=True,
            )
        except Exception as e:
            return CallToolResult(
                content=[
                    TextContent(
                        type="text",
                        text=json.dumps({"error": str(e)}),
                    )
                ],
                isError=True,
            )

    return server


async def run_mcp_server():
    """Run the MCP server."""
    server = create_mcp_server()

    init_options = InitializationOptions(
        server_name="harmony-cs",
        server_version="0.1.0",
        capabilities=ServerCapabilities(
            tools={"listChanged": True},
        ),
    )

    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, init_options)


def main():
    """Entry point for MCP server."""
    asyncio.run(run_mcp_server())


if __name__ == "__main__":
    main()
