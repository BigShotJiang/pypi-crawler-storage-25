"""
Harmony CS CLI - Command-line interface for CS operations.

Usage:
    harmony-cs config set-url <url>     # Set API URL
    harmony-cs auth login               # Store API key
    harmony-cs operations list          # List operations
    harmony-cs execute <operation-id>   # Execute operation
"""

import json
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.prompt import Prompt, Confirm

from . import __version__
from .api_client import HarmonyCSClient, APIError
from .config import (
    get_api_key,
    get_api_url,
    set_api_key,
    set_api_url,
    clear_credentials,
)
from .output import (
    console,
    print_error,
    print_success,
    print_info,
    print_json,
    print_operations_table,
    print_operation_detail,
    print_execution_result,
)

app = typer.Typer(
    name="harmony-cs",
    help="Harmony CS operations CLI",
    no_args_is_help=True,
)

# Sub-command groups
config_app = typer.Typer(help="Configuration commands")
auth_app = typer.Typer(help="Authentication commands")
ops_app = typer.Typer(help="Operation commands")
rollback_app = typer.Typer(help="Rollback commands")
db_app = typer.Typer(help="Database management commands")

app.add_typer(config_app, name="config")
app.add_typer(auth_app, name="auth")
app.add_typer(ops_app, name="operations")
app.add_typer(rollback_app, name="rollback")
app.add_typer(db_app, name="db")


# ============================================================
# Version
# ============================================================


@app.callback()
def main(
    version: Annotated[
        bool,
        typer.Option("--version", "-v", help="Show version"),
    ] = False,
):
    """Harmony CS CLI - Customer service operations."""
    if version:
        console.print(f"harmony-cs version {__version__}")
        raise typer.Exit()


# ============================================================
# Config commands
# ============================================================


@config_app.command("set-url")
def config_set_url(url: str):
    """Set the API server URL."""
    set_api_url(url)
    print_success(f"API URL set to: {url}")


@config_app.command("show")
def config_show():
    """Show current configuration."""
    api_url = get_api_url()
    api_key = get_api_key()

    console.print("[bold]Current Configuration:[/bold]")
    console.print(f"  API URL: {api_url or '[dim]not set[/dim]'}")
    console.print(f"  API Key: {'[dim]****' + api_key[-4:] + '[/dim]' if api_key else '[dim]not set[/dim]'}")


# ============================================================
# Auth commands
# ============================================================


@auth_app.command("login")
def auth_login(
    api_key: Annotated[
        Optional[str],
        typer.Option("--api-key", "-k", help="API key (or enter interactively)"),
    ] = None,
):
    """Store API key for authentication."""
    if not api_key:
        api_key = Prompt.ask("Enter your API key", password=True)

    if not api_key:
        print_error("API key is required")
        raise typer.Exit(1)

    set_api_key(api_key)
    print_success("API key stored successfully")

    # Test connection
    try:
        api_url = get_api_url()
        if api_url:
            client = HarmonyCSClient()
            info = client.info()
            print_info(f"Authenticated as: {info.get('user_role')}")
    except Exception as e:
        print_error(f"Could not verify credentials: {e}")


@auth_app.command("logout")
def auth_logout():
    """Clear stored credentials."""
    clear_credentials()
    print_success("Credentials cleared")


@auth_app.command("status")
def auth_status():
    """Check authentication status."""
    api_url = get_api_url()
    api_key = get_api_key()

    if not api_url:
        print_error("API URL not configured. Run: harmony-cs config set-url <url>")
        raise typer.Exit(1)

    if not api_key:
        print_error("Not logged in. Run: harmony-cs auth login")
        raise typer.Exit(1)

    try:
        client = HarmonyCSClient()
        info = client.info()
        print_success(f"Authenticated as: {info.get('user_role')}")
        console.print(f"  Can execute write operations: {info.get('can_write')}")
    except APIError as e:
        print_error(f"Authentication failed: {e.detail}")
        raise typer.Exit(1)


# ============================================================
# Operation commands
# ============================================================


@ops_app.command("list")
def operations_list(
    category: Annotated[
        Optional[str],
        typer.Option("--category", "-c", help="Filter by category"),
    ] = None,
    operation_type: Annotated[
        Optional[str],
        typer.Option("--type", "-t", help="Filter by type (read/write)"),
    ] = None,
    output_json: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON"),
    ] = False,
):
    """List available operations."""
    try:
        client = HarmonyCSClient()
        operations = client.list_operations(category=category, operation_type=operation_type)

        if output_json:
            print_json(operations)
        else:
            print_operations_table(operations)

    except APIError as e:
        print_error(e.detail)
        raise typer.Exit(1)


@ops_app.command("categories")
def operations_categories():
    """List operation categories."""
    try:
        client = HarmonyCSClient()
        categories = client.list_categories()

        console.print("[bold]Categories:[/bold]")
        for cat in categories:
            console.print(f"  - {cat}")

    except APIError as e:
        print_error(e.detail)
        raise typer.Exit(1)


@ops_app.command("show")
def operations_show(
    operation_id: str,
    output_json: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON"),
    ] = False,
):
    """Show operation details."""
    try:
        client = HarmonyCSClient()
        operation = client.get_operation(operation_id)

        if output_json:
            print_json(operation)
        else:
            print_operation_detail(operation)

    except APIError as e:
        print_error(e.detail)
        raise typer.Exit(1)


# ============================================================
# Execute command
# ============================================================


@app.command("execute")
def execute(
    operation_id: str,
    params: Annotated[
        Optional[str],
        typer.Option("--params", "-p", help="Parameters as JSON string"),
    ] = None,
    param: Annotated[
        Optional[list[str]],
        typer.Option("--param", help="Individual param as key=value"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--no-dry-run", help="Dry run mode (default: true)"),
    ] = True,
    two_phase: Annotated[
        bool,
        typer.Option("--two-phase", help="Use two-phase execution (preview -> commit)"),
    ] = False,
    confirm: Annotated[
        bool,
        typer.Option("--confirm", "-y", help="Skip confirmation prompt"),
    ] = False,
    output_json: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON"),
    ] = False,
):
    """Execute a CS operation.

    For write operations, use --two-phase for safer execution with rollback support.
    """
    try:
        client = HarmonyCSClient()

        # Get operation details
        operation = client.get_operation(operation_id)

        # Parse parameters
        parsed_params = {}
        if params:
            parsed_params = json.loads(params)
        if param:
            for p in param:
                key, value = p.split("=", 1)
                parsed_params[key] = value

        # Interactive parameter input if missing required params
        for name, field in operation.get("inputs", {}).items():
            if field.get("required") and name not in parsed_params:
                description = field.get("description", name)
                example = field.get("example", "")
                prompt_text = f"{description}"
                if example:
                    prompt_text += f" (e.g., {example})"

                value = Prompt.ask(prompt_text)
                parsed_params[name] = value

        # Validate
        validation = client.validate_operation(operation_id, parsed_params)
        if not validation.get("valid"):
            print_error("Validation failed:")
            for err in validation.get("errors", []):
                console.print(f"  - {err}")
            raise typer.Exit(1)

        # Show operation details
        if not output_json:
            console.print(f"\n[bold]Operation:[/bold] {operation['name']}")
            console.print(f"[bold]Risk Level:[/bold] {operation['risk_level']}")
            console.print(f"[bold]Parameters:[/bold]")
            for k, v in parsed_params.items():
                console.print(f"  {k}: {v}")

        # Two-phase execution for write operations
        if two_phase and operation.get("operation_type") == "write":
            # Phase 1: Preview
            if not output_json:
                console.print("\n[bold cyan]Phase 1: Preview[/bold cyan]")

            preview_result = client.preview(operation_id, parsed_params)

            if not preview_result.get("success"):
                print_error(f"Preview failed: {preview_result.get('error')}")
                raise typer.Exit(1)

            if not output_json:
                console.print(f"  Preview ID: {preview_result['preview_id']}")
                console.print(f"  Affected rows: {preview_result.get('affected_rows', 0)}")
                console.print(f"  Affected tables: {', '.join(preview_result.get('affected_tables', []))}")
                console.print(f"  Supports rollback: {preview_result.get('supports_rollback', False)}")
                console.print(f"  Expires: {preview_result.get('preview_expires_at')}")

                # Show warnings
                for warning in preview_result.get("warnings", []):
                    console.print(f"  [yellow]Warning: {warning}[/yellow]")

                # Show before/after diff
                before = preview_result.get("before_state", {})
                after = preview_result.get("after_preview", {})
                if before or after:
                    console.print("\n[bold]Changes preview:[/bold]")
                    for table in set(before.keys()) | set(after.keys()):
                        before_count = len(before.get(table, []))
                        after_count = len(after.get(table, []))
                        console.print(f"  {table}: {before_count} -> {after_count} rows")

            if dry_run:
                if output_json:
                    print_json(preview_result)
                else:
                    print_success("[PREVIEW] Changes shown above were NOT committed")
                    console.print("\n[dim]To commit, run with --no-dry-run --confirm[/dim]")
                return

            # Confirm before commit
            if not confirm:
                if operation.get("risk_level") == "critical":
                    console.print("\n[bold red]WARNING: This is a CRITICAL operation![/bold red]")

                if not Confirm.ask("\nProceed with commit?"):
                    print_info("Operation cancelled")
                    raise typer.Exit(0)

            # Phase 2: Commit
            if not output_json:
                console.print("\n[bold cyan]Phase 2: Commit[/bold cyan]")

            commit_result = client.commit(
                operation_id,
                preview_result["preview_id"],
                parsed_params,
            )

            if output_json:
                print_json(commit_result)
            else:
                if commit_result.get("success"):
                    print_success(f"Committed successfully!")
                    console.print(f"  Execution ID: {commit_result['execution_id']}")
                    console.print(f"  Affected rows: {commit_result.get('affected_rows', 0)}")
                    if commit_result.get("rollback_available"):
                        console.print(f"  Rollback available until: {commit_result.get('rollback_expires_at')}")
                        console.print(f"\n[dim]To rollback: harmony-cs rollback execute {commit_result['execution_id']}[/dim]")
                else:
                    print_error(f"Commit failed: {commit_result.get('error')}")
                    raise typer.Exit(1)

        else:
            # Legacy single-phase execution
            if not output_json:
                console.print(f"[bold]Dry Run:[/bold] {dry_run}")

            # Confirm for non-dry-run write operations
            if not dry_run and operation.get("operation_type") == "write":
                if not confirm:
                    if operation.get("risk_level") == "critical":
                        console.print("\n[bold red]WARNING: This is a CRITICAL operation![/bold red]")

                    if not Confirm.ask("\nProceed with execution?"):
                        print_info("Operation cancelled")
                        raise typer.Exit(0)

            # Execute
            result = client.execute(operation_id, parsed_params, dry_run=dry_run)

            if output_json:
                print_json(result)
            else:
                print_execution_result(result)

            # Suggest next step for dry-run
            if dry_run and result.get("success") and operation.get("operation_type") == "write":
                console.print("\n[dim]To execute for real, run with --no-dry-run --confirm[/dim]")
                console.print("[dim]For safer execution with rollback, use --two-phase[/dim]")

    except APIError as e:
        print_error(e.detail)
        raise typer.Exit(1)
    except json.JSONDecodeError:
        print_error("Invalid JSON in --params")
        raise typer.Exit(1)


# ============================================================
# Rollback commands
# ============================================================


@rollback_app.command("list")
def rollback_list(
    database: Annotated[
        str,
        typer.Option("--database", "-d", help="Target database"),
    ] = "harmony_transaction",
    operation_id: Annotated[
        Optional[str],
        typer.Option("--operation", "-o", help="Filter by operation ID"),
    ] = None,
    status_filter: Annotated[
        str,
        typer.Option("--status", "-s", help="Status filter (available/all)"),
    ] = "available",
    limit: Annotated[
        int,
        typer.Option("--limit", "-l", help="Maximum results"),
    ] = 20,
    output_json: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON"),
    ] = False,
):
    """List available rollback snapshots."""
    try:
        client = HarmonyCSClient()
        result = client.list_rollbacks(
            database=database,
            operation_id=operation_id,
            status=status_filter,
            limit=limit,
        )

        if output_json:
            print_json(result)
        else:
            rollbacks = result.get("rollbacks", [])
            if not rollbacks:
                print_info("No rollback snapshots found")
                return

            console.print(f"\n[bold]Available Rollbacks ({result.get('total', 0)} total):[/bold]\n")
            for rb in rollbacks:
                status_color = "green" if rb["rollback_status"] == "available" else "dim"
                console.print(f"  [{status_color}]{rb['execution_id'][:8]}...[/{status_color}]")
                console.print(f"    Operation: {rb['operation_name']}")
                console.print(f"    Executed: {rb['executed_at']} by {rb['executed_by']}")
                console.print(f"    Status: {rb['rollback_status']}")
                console.print(f"    Expires: {rb['expires_at']}")
                console.print()

    except APIError as e:
        print_error(e.detail)
        raise typer.Exit(1)


@rollback_app.command("show")
def rollback_show(
    execution_id: str,
    database: Annotated[
        str,
        typer.Option("--database", "-d", help="Target database"),
    ] = "harmony_transaction",
    output_json: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON"),
    ] = False,
):
    """Show rollback snapshot details."""
    try:
        client = HarmonyCSClient()
        result = client.get_rollback(execution_id, database=database)

        if output_json:
            print_json(result)
        else:
            console.print(f"\n[bold]Rollback Snapshot:[/bold] {result['execution_id']}")
            console.print(f"  Operation: {result['operation_name']}")
            console.print(f"  Executed: {result['executed_at']} by {result['executed_by']}")
            console.print(f"  Status: {result['rollback_status']}")
            console.print(f"  Risk Level: {result['risk_level']}")
            console.print(f"  Expires: {result['expires_at']}")
            console.print(f"\n[bold]Parameters:[/bold]")
            for k, v in result.get("params", {}).items():
                console.print(f"    {k}: {v}")
            console.print(f"\n[bold]Before Snapshot:[/bold]")
            for table, rows in result.get("before_snapshot", {}).items():
                console.print(f"    {table}: {len(rows)} rows")

    except APIError as e:
        print_error(e.detail)
        raise typer.Exit(1)


@rollback_app.command("execute")
def rollback_execute(
    execution_id: str,
    database: Annotated[
        str,
        typer.Option("--database", "-d", help="Target database"),
    ] = "harmony_transaction",
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--no-dry-run", help="Dry run mode"),
    ] = True,
    confirm: Annotated[
        bool,
        typer.Option("--confirm", "-y", help="Skip confirmation"),
    ] = False,
    output_json: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON"),
    ] = False,
):
    """Execute rollback to restore before-state."""
    try:
        client = HarmonyCSClient()

        # Get rollback details first
        snapshot = client.get_rollback(execution_id, database=database)

        if not output_json:
            console.print(f"\n[bold]Rollback:[/bold] {snapshot['operation_name']}")
            console.print(f"  Execution ID: {execution_id}")
            console.print(f"  Original execution: {snapshot['executed_at']}")

            before_snapshot = snapshot.get("before_snapshot", {})
            total_rows = sum(len(rows) for rows in before_snapshot.values())
            console.print(f"  Rows to restore: {total_rows}")

        # Confirm for non-dry-run
        if not dry_run and not confirm:
            console.print("\n[bold yellow]WARNING: This will restore data to its previous state![/bold yellow]")
            if not Confirm.ask("Proceed with rollback?"):
                print_info("Rollback cancelled")
                raise typer.Exit(0)

        # Execute rollback
        result = client.execute_rollback(
            execution_id,
            database=database,
            dry_run=dry_run,
        )

        if output_json:
            print_json(result)
        else:
            if result.get("success"):
                if dry_run:
                    print_success(f"[DRY-RUN] Would restore {result.get('rows_restored', 0)} rows")
                    console.print("\n[dim]To execute for real, run with --no-dry-run --confirm[/dim]")
                else:
                    print_success(f"Restored {result.get('rows_restored', 0)} rows")
            else:
                print_error(f"Rollback failed: {result.get('error')}")

            if result.get("rollback_sql"):
                console.print("\n[bold]Rollback SQL:[/bold]")
                console.print(f"[dim]{result['rollback_sql'][:500]}...[/dim]" if len(result.get("rollback_sql", "")) > 500 else f"[dim]{result.get('rollback_sql')}[/dim]")

    except APIError as e:
        print_error(e.detail)
        raise typer.Exit(1)


# ============================================================
# Database Management Commands
# ============================================================


CS_CREATE_SQL = """
CREATE TABLE IF NOT EXISTS cs_preview_cache (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    preview_id      UUID NOT NULL UNIQUE,
    operation_id    VARCHAR(100) NOT NULL,
    params          JSONB NOT NULL,
    before_snapshot JSONB NOT NULL,
    after_preview   JSONB NOT NULL,
    affected_count  INTEGER NOT NULL,
    affected_tables TEXT[] NOT NULL,
    prepared_sql    TEXT NOT NULL,
    created_by      VARCHAR(100) NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ NOT NULL,
    state_hash      VARCHAR(64) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cs_preview_id ON cs_preview_cache(preview_id);
CREATE INDEX IF NOT EXISTS idx_cs_preview_expires ON cs_preview_cache(expires_at);
CREATE TABLE IF NOT EXISTS cs_rollback_snapshot (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    execution_id    UUID NOT NULL UNIQUE,
    preview_id      UUID,
    operation_id    VARCHAR(100) NOT NULL,
    operation_name  VARCHAR(200) NOT NULL,
    risk_level      VARCHAR(20) NOT NULL,
    database_name   VARCHAR(50) NOT NULL,
    executed_by     VARCHAR(100) NOT NULL,
    executed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    params          JSONB NOT NULL,
    before_snapshot JSONB NOT NULL,
    affected_ids    JSONB NOT NULL,
    executed_sql    TEXT NOT NULL,
    after_snapshot  JSONB,
    rollback_status VARCHAR(20) NOT NULL DEFAULT 'available',
    rolled_back_at  TIMESTAMPTZ,
    rolled_back_by  VARCHAR(100),
    rollback_sql    TEXT,
    create_dt       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    update_dt       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ NOT NULL,
    CONSTRAINT valid_rollback_status CHECK (
        rollback_status IN ('available', 'rolled_back', 'expired', 'invalidated')
    ),
    CONSTRAINT valid_risk_level CHECK (
        risk_level IN ('low', 'medium', 'high', 'critical')
    )
);
CREATE INDEX IF NOT EXISTS idx_cs_rollback_execution_id ON cs_rollback_snapshot(execution_id);
CREATE INDEX IF NOT EXISTS idx_cs_rollback_operation ON cs_rollback_snapshot(operation_id);
CREATE INDEX IF NOT EXISTS idx_cs_rollback_status ON cs_rollback_snapshot(rollback_status);
CREATE INDEX IF NOT EXISTS idx_cs_rollback_created ON cs_rollback_snapshot(create_dt DESC);
CREATE INDEX IF NOT EXISTS idx_cs_rollback_expires ON cs_rollback_snapshot(expires_at)
    WHERE rollback_status = 'available';
"""

CS_TARGET_DBS = [
    "harmony_transaction",
    "harmony_product",
    "harmony_channel",
    "harmony_review",
]


@db_app.command("status")
def db_status(
    environment: str = typer.Option("development", help="Target environment"),
):
    """Check CS rollback table status in each service database."""
    try:
        client = HarmonyCSClient()
        import httpx
        response = httpx.get(
            f"{client.api_url}/admin/cs-tables/status",
            params={"environment": environment},
            headers=client._get_headers(),
        )
        data = response.json()

        if response.status_code != 200:
            print_error(data.get("detail", "Failed to check status"))
            raise typer.Exit(1)

        console.print(f"\n[bold]CS Tables Status ({environment})[/bold]\n")
        for db_name, tables in data.get("databases", {}).items():
            preview = "[green]OK[/green]" if tables.get("cs_preview_cache") else "[red]MISSING[/red]"
            snapshot = "[green]OK[/green]" if tables.get("cs_rollback_snapshot") else "[red]MISSING[/red]"
            console.print(f"  {db_name}: preview_cache {preview}  rollback_snapshot {snapshot}")

        if data.get("all_ok"):
            print_success("\nAll CS tables are ready.")
        else:
            print_error("\nSome CS tables are missing. Run: harmony-cs db setup --db-url '...'")
    except Exception as e:
        print_error(f"Error: {e}")


@db_app.command("setup")
def db_setup(
    db_url: str = typer.Option(
        ...,
        help="DB URL pattern with DDL-capable user. "
             "Use {db_name} as placeholder. "
             "Example: postgresql://admin:pass@host:5432/{db_name}",
    ),
):
    """Create CS rollback tables in all service databases.

    Requires a DB user with CREATE TABLE privilege.
    The cs_ tables are independent from service tables and won't affect service operations.

    Example:
        harmony-cs db setup --db-url 'postgresql://admin:pass@host:5432/{db_name}'
    """
    import psycopg

    console.print("\n[bold]Creating CS tables in service databases...[/bold]\n")

    success_count = 0
    for db_name in CS_TARGET_DBS:
        url = db_url.replace("{db_name}", db_name)
        try:
            with psycopg.connect(url) as conn:
                with conn.cursor() as cur:
                    cur.execute(CS_CREATE_SQL)
                conn.commit()
            console.print(f"  [green]OK[/green]  {db_name}")
            success_count += 1
        except Exception as e:
            console.print(f"  [red]FAIL[/red] {db_name}: {e}")

    console.print(f"\nResult: {success_count}/{len(CS_TARGET_DBS)} databases ready.")
    if success_count == len(CS_TARGET_DBS):
        print_success("All CS tables created successfully.")


# ============================================================
# MCP Server command
# ============================================================


@app.command("mcp-server")
def mcp_server():
    """Start the MCP server for Claude Desktop integration."""
    try:
        from .mcp_server import main as run_mcp
        run_mcp()
    except ImportError:
        print_error(
            "MCP dependencies not installed. "
            "Install with: pip install harmony-cs[mcp]"
        )
        raise typer.Exit(1)


# ============================================================
# Entry point
# ============================================================


def main_cli():
    """CLI entry point."""
    app()


if __name__ == "__main__":
    main_cli()
