"""
Client configuration management.
Stores API URL and credentials locally.
"""

import json
from pathlib import Path
from typing import Any

# Config directory
CONFIG_DIR = Path.home() / ".harmony-cs"
CONFIG_FILE = CONFIG_DIR / "config.json"
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"


def ensure_config_dir() -> None:
    """Ensure config directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict[str, Any]:
    """Load configuration from file."""
    ensure_config_dir()
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def save_config(config: dict[str, Any]) -> None:
    """Save configuration to file."""
    ensure_config_dir()
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_api_url() -> str | None:
    """Get configured API URL. Env var takes precedence."""
    import os
    if url := os.environ.get("HARMONY_CS_API_URL"):
        return url
    config = load_config()
    return config.get("api_url")


def set_api_url(url: str) -> None:
    """Set API URL."""
    config = load_config()
    config["api_url"] = url.rstrip("/")
    save_config(config)


def get_api_key() -> str | None:
    """Get stored API key. Env var takes precedence."""
    import os
    if key := os.environ.get("HARMONY_CS_API_KEY"):
        return key
    ensure_config_dir()
    if CREDENTIALS_FILE.exists():
        creds = json.loads(CREDENTIALS_FILE.read_text())
        return creds.get("api_key")
    return None


def set_api_key(api_key: str) -> None:
    """Store API key."""
    ensure_config_dir()
    # Set restrictive permissions on credentials file
    CREDENTIALS_FILE.write_text(json.dumps({"api_key": api_key}, indent=2))
    CREDENTIALS_FILE.chmod(0o600)


def clear_credentials() -> None:
    """Clear stored credentials."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def get_default_env() -> str:
    """Get default environment (prod/stage)."""
    config = load_config()
    return config.get("default_env", "prod")


def set_default_env(env: str) -> None:
    """Set default environment."""
    config = load_config()
    config["default_env"] = env
    save_config(config)
