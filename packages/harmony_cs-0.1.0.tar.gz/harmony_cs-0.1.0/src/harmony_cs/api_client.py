"""
API client for communicating with Harmony CS Server.
"""

from typing import Any

import httpx

from .config import get_api_key, get_api_url


class APIError(Exception):
    """API error with status code and detail."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"[{status_code}] {detail}")


class HarmonyCSClient:
    """Client for Harmony CS API."""

    def __init__(
        self,
        api_url: str | None = None,
        api_key: str | None = None,
        source: str = "cli",
    ):
        self.api_url = api_url or get_api_url()
        self.api_key = api_key or get_api_key()
        self.source = source  # "cli" or "mcp"

        if not self.api_url:
            raise ValueError(
                "API URL not configured. Run 'harmony-cs config set-url <url>'"
            )

        if not self.api_key:
            raise ValueError(
                "API key not configured. Run 'harmony-cs auth login'"
            )

    def _get_headers(self) -> dict[str, str]:
        """Get request headers with auth and source identification."""
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": f"harmony-cs-{self.source}/0.1.0",
        }
        if self.source == "mcp":
            headers["X-MCP-Client"] = "claude-desktop"
        elif self.source == "cli":
            headers["X-CLI-Version"] = "0.1.0"
        return headers

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle API response."""
        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise APIError(response.status_code, detail)

        return response.json()

    # ============================================================
    # Info endpoints
    # ============================================================

    def health(self) -> dict[str, Any]:
        """Check API health."""
        with httpx.Client() as client:
            response = client.get(f"{self.api_url}/health")
            return self._handle_response(response)

    def info(self) -> dict[str, Any]:
        """Get API info and user role."""
        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/info",
                headers=self._get_headers(),
            )
            return self._handle_response(response)

    # ============================================================
    # Operation endpoints
    # ============================================================

    def list_operations(
        self,
        category: str | None = None,
        operation_type: str | None = None,
    ) -> list[dict[str, Any]]:
        """List available operations."""
        params = {}
        if category:
            params["category"] = category
        if operation_type:
            params["operation_type"] = operation_type

        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/operations",
                headers=self._get_headers(),
                params=params,
            )
            return self._handle_response(response)

    def list_categories(self) -> list[str]:
        """List operation categories."""
        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/operations/categories",
                headers=self._get_headers(),
            )
            result = self._handle_response(response)
            return result.get("categories", [])

    def get_operation(self, operation_id: str) -> dict[str, Any]:
        """Get operation details."""
        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/operations/{operation_id}",
                headers=self._get_headers(),
            )
            return self._handle_response(response)

    def validate_operation(
        self,
        operation_id: str,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Validate operation inputs."""
        with httpx.Client() as client:
            response = client.post(
                f"{self.api_url}/operations/{operation_id}/validate",
                headers=self._get_headers(),
                json={"operation_id": operation_id, "params": params},
            )
            return self._handle_response(response)

    def execute(
        self,
        operation_id: str,
        params: dict[str, Any],
        dry_run: bool = True,
        environment: str = "development",
    ) -> dict[str, Any]:
        """Execute an operation (legacy API)."""
        with httpx.Client(timeout=300) as client:  # 5 min timeout
            response = client.post(
                f"{self.api_url}/operations/{operation_id}/execute",
                headers=self._get_headers(),
                json={
                    "operation_id": operation_id,
                    "params": params,
                    "dry_run": dry_run,
                    "environment": environment,
                },
            )
            return self._handle_response(response)

    # ============================================================
    # Two-Phase Execution endpoints
    # ============================================================

    def preview(
        self,
        operation_id: str,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Phase 1: Preview operation with before/after state capture.

        Returns preview_id to use with commit().
        """
        with httpx.Client(timeout=300) as client:
            response = client.post(
                f"{self.api_url}/operations/{operation_id}/preview",
                headers=self._get_headers(),
                json={
                    "operation_id": operation_id,
                    "params": params,
                },
            )
            return self._handle_response(response)

    def commit(
        self,
        operation_id: str,
        preview_id: str,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Phase 2: Commit previewed operation.

        Requires preview_id from preview().
        """
        with httpx.Client(timeout=300) as client:
            response = client.post(
                f"{self.api_url}/operations/{operation_id}/commit",
                headers=self._get_headers(),
                json={
                    "operation_id": operation_id,
                    "preview_id": preview_id,
                    "params": params,
                },
            )
            return self._handle_response(response)

    # ============================================================
    # Rollback endpoints
    # ============================================================

    def list_rollbacks(
        self,
        database: str = "harmony_transaction",
        operation_id: str | None = None,
        status: str = "available",
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List available rollback snapshots."""
        params = {
            "database": database,
            "status": status,
            "limit": limit,
            "offset": offset,
        }
        if operation_id:
            params["operation_id"] = operation_id

        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/rollbacks",
                headers=self._get_headers(),
                params=params,
            )
            return self._handle_response(response)

    def get_rollback(
        self,
        execution_id: str,
        database: str = "harmony_transaction",
    ) -> dict[str, Any]:
        """Get rollback snapshot details."""
        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/rollbacks/{execution_id}",
                headers=self._get_headers(),
                params={"database": database},
            )
            return self._handle_response(response)

    def execute_rollback(
        self,
        execution_id: str,
        database: str = "harmony_transaction",
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Execute rollback to restore before-state."""
        with httpx.Client(timeout=300) as client:
            response = client.post(
                f"{self.api_url}/rollbacks/{execution_id}/execute",
                headers=self._get_headers(),
                params={"database": database},
                json={
                    "execution_id": execution_id,
                    "dry_run": dry_run,
                },
            )
            return self._handle_response(response)

    # ============================================================
    # Raw SQL Query endpoints (Superuser only)
    # ============================================================

    def list_schemas(self) -> dict[str, Any]:
        """List available database schemas."""
        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/schema",
                headers=self._get_headers(),
            )
            return self._handle_response(response)

    def get_schema(self, database: str) -> dict[str, Any]:
        """Get schema information for a database.

        Args:
            database: Database name (e.g., harmony_transaction, harmony_product)

        Returns:
            Schema info with tables list and documentation
        """
        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/schema/{database}",
                headers=self._get_headers(),
            )
            return self._handle_response(response)

    def query(
        self,
        database: str,
        sql: str,
        limit: int = 100,
        environment: str = "development",
    ) -> dict[str, Any]:
        """Execute a raw SELECT query on the specified database.

        **Superuser only** - allows free-form SELECT queries.
        Write operations are blocked (enforced by DB-level readonly user).

        Args:
            database: Target database (harmony_transaction, harmony_product, etc.)
            sql: SELECT query to execute
            limit: Maximum rows to return (default 100, max 1000)
            environment: Target environment (development, staging, production)

        Returns:
            Query results with columns and data
        """
        with httpx.Client(timeout=300) as client:
            response = client.post(
                f"{self.api_url}/query/{database}",
                headers=self._get_headers(),
                json={
                    "database": database,
                    "sql": sql,
                    "limit": limit,
                    "environment": environment,
                },
            )
            return self._handle_response(response)

    # ============================================================
    # Log Query endpoints (New Relic)
    # ============================================================

    def query_logs(
        self,
        service: str,
        component: str | None = None,
        environment: str = "development",
        search_term: str | None = None,
        level: str | None = None,
        since: str = "1 HOUR AGO",
        limit: int = 100,
    ) -> dict[str, Any]:
        """Query application logs from New Relic."""
        body: dict[str, Any] = {
            "service": service,
            "environment": environment,
            "since": since,
            "limit": limit,
        }
        if component:
            body["component"] = component
        if search_term:
            body["search_term"] = search_term
        if level:
            body["level"] = level

        with httpx.Client(timeout=60) as client:
            response = client.post(
                f"{self.api_url}/logs/query",
                headers=self._get_headers(),
                json=body,
            )
            return self._handle_response(response)

    def query_trace(
        self,
        trace_id: str,
        environment: str = "development",
        service: str | None = None,
        limit: int = 500,
    ) -> dict[str, Any]:
        """Query all logs for a specific trace.id across services."""
        body: dict[str, Any] = {
            "trace_id": trace_id,
            "environment": environment,
            "limit": limit,
        }
        if service:
            body["service"] = service

        with httpx.Client(timeout=60) as client:
            response = client.post(
                f"{self.api_url}/logs/trace",
                headers=self._get_headers(),
                json=body,
            )
            return self._handle_response(response)

    def query_nrql(
        self,
        nrql: str,
        environment: str = "development",
    ) -> dict[str, Any]:
        """Execute raw NRQL query (superuser only)."""
        with httpx.Client(timeout=60) as client:
            response = client.post(
                f"{self.api_url}/logs/nrql",
                headers=self._get_headers(),
                json={"nrql": nrql, "environment": environment},
            )
            return self._handle_response(response)

    def list_log_entities(
        self,
        service: str | None = None,
        environment: str | None = None,
    ) -> dict[str, Any]:
        """List available New Relic entity GUIDs."""
        params: dict[str, str] = {}
        if service:
            params["service"] = service
        if environment:
            params["environment"] = environment

        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/logs/entities",
                headers=self._get_headers(),
                params=params,
            )
            return self._handle_response(response)

    def list_log_services(self) -> dict[str, Any]:
        """List available services and components for log queries."""
        with httpx.Client() as client:
            response = client.get(
                f"{self.api_url}/logs/services",
                headers=self._get_headers(),
            )
            return self._handle_response(response)
