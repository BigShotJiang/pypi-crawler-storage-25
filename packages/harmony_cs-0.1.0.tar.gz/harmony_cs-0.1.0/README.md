# Harmony CS CLI

Command-line interface for Harmony CS operations.

## Installation

```bash
pip install harmony-cs

# With MCP support (for Claude Desktop)
pip install harmony-cs[mcp]
```

## Quick Start

```bash
# Configure API URL
harmony-cs config set-url https://cs-api.harmony.internal

# Login (stores API key locally)
harmony-cs auth login

# List operations
harmony-cs operations list

# Execute operation (dry-run by default)
harmony-cs execute transaction.get-sku-status --param sku_id=517aed7c-...

# Execute for real
harmony-cs execute transaction.refund-ship-rejected \
  --param sku_id=517aed7c-... \
  --no-dry-run --confirm
```

## Commands

### Configuration

```bash
harmony-cs config set-url <url>    # Set API URL
harmony-cs config show             # Show current config
```

### Authentication

```bash
harmony-cs auth login              # Store API key
harmony-cs auth logout             # Clear credentials
harmony-cs auth status             # Check auth status
```

### Operations

```bash
harmony-cs operations list              # List all operations
harmony-cs operations list -c channel   # Filter by category
harmony-cs operations list -t read      # Filter by type
harmony-cs operations categories        # List categories
harmony-cs operations show <id>         # Show operation details
```

### Execution

```bash
# Interactive mode (prompts for missing params)
harmony-cs execute <operation-id>

# With parameters
harmony-cs execute <operation-id> --param key1=value1 --param key2=value2

# JSON parameters
harmony-cs execute <operation-id> -p '{"key": "value"}'

# Execute for real (not dry-run)
harmony-cs execute <operation-id> --no-dry-run --confirm
```

## Claude Desktop Integration

Add to `~/.claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "harmony-cs": {
      "command": "harmony-cs",
      "args": ["mcp-server"]
    }
  }
}
```

Then in Claude Desktop, you can:
- "List available CS operations"
- "Show details for transaction.refund-ship-rejected"
- "Execute transaction.get-sku-status with sku_id=517aed7c-..."
