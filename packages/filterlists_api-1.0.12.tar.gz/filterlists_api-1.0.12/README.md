# filterlists-api

Python client bindings for the FilterLists Directory API, tracked as a repo-local generated client with manual regeneration, validation, and release steps.

## What this repo contains

- generated client code under `filterlists_api/`
- generated endpoint/model docs under `docs/`
- repo-local regeneration helper under `scripts/automation/update-client`
- repo-local validation entrypoints under `scripts/ci/`
- repo-local release entrypoints under `scripts/release/`
- optional systemd timer units under `contrib/systemd/`

The canonical browse URL for this repository is:

    https://latebrum.com/git/actx/filterlists_api/

## Requirements

For normal validation and release work:

- Python 3.8+
- `python3 -m venv`

For client regeneration:

- `curl`
- `jq`
- `node` / `npm` so `npx @openapitools/openapi-generator-cli` can run

## Local installation

Install directly from the working tree:

```sh
python3 -m pip install .
```

Or build release artifacts first and install from the staged wheel:

```sh
scripts/release/build pypi vX.Y.Z
python3 -m pip install artifacts/release/pypi/*.whl
```

## Regenerating the client

To fetch the upstream OpenAPI document, derive the next patch version, and regenerate the client in place:

```sh
scripts/automation/update-client
```

That script intentionally leaves the resulting diff, commit, and tag decisions manual. For release builds, the passed tag is authoritative.

## Validation

Run the standard repo-local checks with:

```sh
scripts/ci/check
scripts/ci/full
scripts/ci/release-check vX.Y.Z
```

## Release flow

Build sdist and wheel artifacts locally for a chosen target repository surface:

```sh
scripts/release/build testpypi vX.Y.Z
scripts/release/build pypi vX.Y.Z
```

Publish to TestPyPI or PyPI using the workstation's configured Python packaging credentials:

```sh
scripts/release/publish testpypi vX.Y.Z
scripts/release/publish pypi vX.Y.Z
```

TestPyPI defaults to `https://test.pypi.org/legacy/`. PyPI uses Twine's default repository unless `TWINE_REPOSITORY_URL` is explicitly set.

## Optional timer-driven refresh

If you want periodic upstream-change checks on a host, install the units under `contrib/systemd/` and wire them to a local clone of this repository.

## API docs

Generated API and model documentation lives under `docs/`.
