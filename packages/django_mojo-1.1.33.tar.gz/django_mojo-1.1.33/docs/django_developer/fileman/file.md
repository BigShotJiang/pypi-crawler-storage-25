# File Model — Django Developer Reference

## Overview

`File` tracks uploaded files with metadata and delegates storage to a `FileManager` backend (local, S3, etc.). Each file goes through an upload lifecycle: `pending` → `uploading` → `completed` (or `failed`/`expired`).

## Inheritance

```python
class File(models.Model, MojoModel):
```

## Key Fields

| Field | Type | Description |
|---|---|---|
| `filename` | CharField | User-provided filename |
| `storage_filename` | CharField | Generated unique filename in storage |
| `storage_file_path` | TextField | Full path in storage backend |
| `content_type` | CharField | MIME type |
| `category` | CharField | Auto-detected: `image`, `document`, `video`, etc. |
| `file_size` | BigIntegerField | Size in bytes |
| `checksum` | CharField | MD5/SHA256 checksum |
| `upload_status` | CharField | `pending`, `uploading`, `completed`, `failed`, `expired` |
| `upload_token` | CharField | Unique token for tracking direct uploads |
| `is_public` | BooleanField | Publicly accessible without auth |
| `is_active` | BooleanField | Active/accessible flag |
| `metadata` | JSONField | Arbitrary file metadata |
| `group` | FK → Group | Owning group |
| `user` | FK → User | Uploader |
| `file_manager` | FK → FileManager | Storage backend config |
| `download_url` | TextField | Cached persistent download URL |
| `shortlink_code` | CharField(10) | Cached tier-1 shortlink code (`/s/<code>`) for this file's download URL. Null until the first `generate_download_url()` call when shortlinks are enabled. |

## Upload Flow

### Option 1: Direct Upload (Multipart)

POST a multipart form with the file. The framework handles storage automatically.

```python
# REST handler
@md.POST('upload')
def on_upload(request):
    file = request.FILES.get("file")
    instance = File.create_from_file(file, file.name, request=request)
    return instance.on_rest_get(request)
```

### Option 2: Presigned URL (S3/Cloud)

1. Create a File record to get a presigned upload URL
2. Client uploads directly to storage
3. Client confirms completion

```python
file = File(filename="report.pdf", file_size=102400)
file.file_manager = FileManager.get_from_request(request)
file.save()
url = file.request_upload_url()
# Return url to client for direct upload
```

### Option 3: Base64 Inline (in JSON payload)

When a related model has a `ForeignKey` to `File`, you can pass base64-encoded data inline:

```json
{
  "name": "My Product",
  "avatar": "data:image/png;base64,iVBORw0KGgo..."
}
```

The framework calls `File.on_rest_related_save()` automatically to decode and store the file.

## Creating Files Programmatically

```python
from mojo.apps.fileman.models import File

# From a Django UploadedFile
file_instance = File.create_from_file(
    file=uploaded_file,
    name=uploaded_file.name,
    request=request,
    user=request.user,
    group=request.group
)

# From BytesIO (e.g., generated file)
import io
buf = io.BytesIO(b"PDF content here...")
buf.name = "report.pdf"
buf.size = len(buf.getvalue())
buf.content_type = "application/pdf"
file_instance = File.create_from_file(buf, "report.pdf", user=user, group=group)
```

## Download URLs

```python
url = file_instance.generate_download_url()
```

When `mojo.apps.shortlink` is installed and shortlinks are enabled (global `FILEMAN_USE_SHORTLINKS=True`, or per-FileManager `use_shortlinks=True`), this returns a `/s/<code>` short URL backed by a tier-1 `ShortLink` row. The short URL resolver regenerates the underlying backend URL on every click, so presigned URLs stay fresh without rotating the surface URL.

When shortlinks are disabled or the app is not installed, behavior is identical to the pre-shortlink implementation:
- Public files return a permanent CDN/storage URL (cached in `download_url`)
- Private files return a time-limited presigned URL (TTL from `urls_expire_in` FileManager setting)

To bypass shortlink wrapping and get the raw backend URL directly (e.g., from within the shortlink resolver itself), call:

```python
url = file_instance.get_direct_download_url()
```

`get_direct_download_url()` never produces a short URL and never recurses into the shortlink system. Use it when you need the actual fetch URL, not the stable surface URL.

See [shortlinks.md](shortlinks.md) for the full pipeline, per-manager toggles, and the tier-1/tier-2 distinction.

## Upload Status Management

```python
file.mark_as_uploading(commit=True)
file.mark_as_completed(file_size=1024, checksum="abc123", commit=True)
file.mark_as_failed(error_message="Storage error", commit=True)
```

`mark_as_completed` enqueues an async rendition job via `mojo.apps.jobs` (channel `"renditions"`). Renditions appear shortly after completion but are not available immediately. See [renditions.md](renditions.md).

## Renditions

Renditions (thumbnails, previews, transcoded video/audio) are produced asynchronously after `mark_as_completed()` succeeds. The `renditions` map may be empty `{}` immediately after completion — re-fetch after a short delay.

```python
thumbnail_url = file_instance.thumbnail  # URL of thumbnail rendition, or None
renditions = file_instance.renditions    # objict of all renditions by role
rendition = file_instance.get_rendition_by_role("thumbnail")
```

To manually enqueue or re-enqueue rendition work:

```python
file_instance.publish_renditions()                          # enqueue default renditions
file_instance.publish_regenerate_renditions(roles=["thumbnail"])  # regenerate specific roles
```

## File on Related Models

Use `ForeignKey` to `fileman.File` on any model to link files:

```python
class Product(models.Model, MojoModel):
    image = models.ForeignKey("fileman.File", null=True, on_delete=models.SET_NULL)
```

The framework will automatically handle inline base64 upload when `image` is passed as a data URL in a REST POST.

## RestMeta

```python
class RestMeta:
    VIEW_PERMS = ["view_fileman", "manage_files"]
    CAN_DELETE = True
    GRAPHS = {
        "basic": {"fields": ["id", "filename", "content_type", "category"], "extra": ["url", "thumbnail"]},
        "default": {"extra": ["url", "renditions"]},
        "upload": {"fields": ["id", "filename", "content_type", "file_size", "upload_url"]},
        "list": {"extra": ["url", "renditions"], "graphs": {"group": "basic", "user": "basic"}},
    }
```

## Metadata

```python
file_instance.get_metadata("width")            # returns None if not set
file_instance.set_metadata("width", 1920)
file_instance.save()
```

### `expires_at` — automatic expiry

Set `metadata["expires_at"]` to an ISO 8601 timestamp to mark a file for automatic deletion by the cleanup job:

```python
from django.utils import timezone
from datetime import timedelta

file_instance.metadata = {
    "source": "my_export",
    "expires_at": (timezone.now() + timedelta(days=14)).isoformat(),
}
file_instance.save()
```

The cleanup job (`mojo.apps.fileman.asyncjobs.cleanup_expired_files`) runs daily at 04:00 UTC. It finds all active files with an `expires_at` key and deletes any whose timestamp has passed. Deletion calls `on_rest_pre_delete()` before removing the record — which cleans up the storage backend file.

This pattern is used by the assistant `export_data` tool. You can use it for any time-limited generated file.

## Cleanup Job

`mojo/apps/fileman/cronjobs.py` registers a cron job that runs daily:

```python
@schedule(minutes="0", hours="4")
def cleanup_expired_files():
    jobs.publish(func="mojo.apps.fileman.asyncjobs.cleanup_expired_files", channel="cleanup", payload={})
```

The job is registered automatically when `mojo.apps.fileman` is in `INSTALLED_APPS`. No additional configuration is needed. It only deletes files with `metadata.expires_at` set — files without this key are never touched.

## Access Control

```python
can_access = file_instance.can_be_accessed_by(user=request.user, group=request.group)
```
