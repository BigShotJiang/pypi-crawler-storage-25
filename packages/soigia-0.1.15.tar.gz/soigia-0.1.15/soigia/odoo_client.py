from __future__ import annotations

import base64
import json
import logging
import os
import time
import xmlrpc.client
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import wraps
from http.cookiejar import CookieJar
from typing import TYPE_CHECKING, Any, Callable, Iterable, Mapping
from urllib.error import HTTPError, URLError
from urllib.request import HTTPCookieProcessor, Request, build_opener, urlopen

if TYPE_CHECKING:
    import pandas as pd

__all__ = [
    "OdooClient",
    "OdooConnectionInfo",
    "OdooEnv",
    "OdooModel",
    "OdooQuerySet",
    "OdooManager",
    "OdooRecord",
    "OdooRecordSet",
    "OdooError",
    "OdooAuthenticationError",
    "OdooRpcError",
    "OdooJson2Error",
    "OdooHttpError",
]


class OdooError(RuntimeError):
    """Base exception for Odoo client failures."""


class OdooAuthenticationError(OdooError):
    """Raised when Odoo authentication fails."""


class OdooRpcError(OdooError):
    """Raised when an XML-RPC call fails."""


class OdooJson2Error(OdooError):
    """Raised when a JSON-2 call fails."""


class OdooHttpError(OdooError):
    """Raised when a web JSON request fails."""


@dataclass(slots=True)
class OdooConnectionInfo:
    base_url: str
    database: str
    login: str | None = None
    password: str | None = None
    api_key: str | None = None
    timeout: float = 30.0
    user_agent: str = "soigia-odoo-client/0.1"


def _normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def _coerce_id_list(ids: int | Iterable[int]) -> list[int]:
    if isinstance(ids, int):
        return [ids]
    return [int(record_id) for record_id in ids]


def _domain_from_lookup(filters: Mapping[str, Any]) -> list[list[Any]]:
    domain: list[list[Any]] = []
    operators = {
        "icontains": "ilike",
        "contains": "like",
        "in": "in",
        "gt": ">",
        "gte": ">=",
        "lt": "<",
        "lte": "<=",
    }
    for key, value in filters.items():
        if "__" in key:
            field_name, lookup = key.split("__", 1)
            domain.append([field_name, operators.get(lookup, "="), value])
        else:
            domain.append([key, "=", value])
    return domain


def _to_data_table(rows: list[dict[str, Any]], fields: list[str] | None = None) -> "pd.DataFrame":
    import pandas as pd

    if fields is not None:
        rows = [{field: row.get(field) for field in fields} for row in rows]
    return pd.DataFrame.from_records(rows)


def _normalize_records_payload(records: Any) -> list[dict[str, Any]]:
    if records is None:
        return []
    if isinstance(records, Mapping):
        return [dict(records)]
    if hasattr(records, "to_dict"):
        try:
            rows = records.to_dict(orient="records")
            if isinstance(rows, list):
                return [dict(row) for row in rows]
        except TypeError:
            pass
    if isinstance(records, Iterable) and not isinstance(records, (str, bytes)):
        normalized = []
        for row in records:
            if isinstance(row, Mapping):
                normalized.append(dict(row))
            else:
                raise TypeError("Batch payload items must be mappings/dicts")
        return normalized
    raise TypeError("records must be a mapping, iterable of mappings, DataFrame, or DataTable")


def _chunked(items: list[dict[str, Any]], chunk_size: int) -> list[list[dict[str, Any]]]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be > 0")
    return [items[index : index + chunk_size] for index in range(0, len(items), chunk_size)]


def _resolve_logger(target: Any) -> logging.Logger:
    if hasattr(target, "client") and hasattr(target.client, "logger"):
        return target.client.logger
    if hasattr(target, "logger"):
        return target.logger
    return logging.getLogger(__name__)


def _resolve_operation_name(target: Any, default_name: str) -> str:
    if hasattr(target, "model"):
        model_name = getattr(target, "model")
        if isinstance(model_name, str):
            return f"{model_name}.{default_name}"
    return default_name


def _timed_logged_method(operation_name: str | None = None) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
            logger = _resolve_logger(self)
            resolved_name = _resolve_operation_name(self, operation_name or func.__name__)
            started_at = datetime.now(timezone.utc)
            started_perf = time.perf_counter()
            logger.info(
                "Odoo operation started",
                extra={
                    "operation": resolved_name,
                    "started_at": started_at.isoformat(),
                    "status": "started",
                },
            )
            try:
                result = func(self, *args, **kwargs)
            except Exception:
                finished_at = datetime.now(timezone.utc)
                logger.exception(
                    "Odoo operation failed",
                    extra={
                        "operation": resolved_name,
                        "started_at": started_at.isoformat(),
                        "finished_at": finished_at.isoformat(),
                        "duration_seconds": round(time.perf_counter() - started_perf, 6),
                        "status": "error",
                    },
                )
                raise
            finished_at = datetime.now(timezone.utc)
            logger.info(
                "Odoo operation finished",
                extra={
                    "operation": resolved_name,
                    "started_at": started_at.isoformat(),
                    "finished_at": finished_at.isoformat(),
                    "duration_seconds": round(time.perf_counter() - started_perf, 6),
                    "status": "success",
                },
            )
            return result

        return wrapper

    return decorator


class OdooRecord:
    """Mutable Odoo record with save/refresh/delete helpers."""

    def __init__(self, model: "OdooModel", values: Mapping[str, Any] | None = None) -> None:
        object.__setattr__(self, "_model", model)
        object.__setattr__(self, "_values", dict(values or {}))

    def __getattr__(self, name: str) -> Any:
        try:
            return self._values[name]
        except KeyError as exc:
            raise AttributeError(name) from exc

    def __setattr__(self, name: str, value: Any) -> None:
        if name in {"_model", "_values"}:
            object.__setattr__(self, name, value)
            return
        self._values[name] = value

    def __repr__(self) -> str:
        important = []
        for field_name in ("id", "name", "email", "phone"):
            if field_name in self._values and self._values[field_name] not in (None, False, ""):
                important.append(f"{field_name}={self._values[field_name]!r}")
        suffix = " ".join(important) if important else f"values={self._values!r}"
        return f"<OdooRecord {self._model.model} {suffix}>"

    @property
    def id(self) -> int | None:
        value = self._values.get("id")
        return int(value) if value is not None else None

    def to_dict(self) -> dict[str, Any]:
        return dict(self._values)

    def call(self, method: str, *args: Any, **kwargs: Any) -> Any:
        if self.id is None:
            raise ValueError("Cannot call a record method on an unsaved OdooRecord")
        transport = str(kwargs.pop("transport", "auto"))
        return self._model.client.call_method(
            self._model.model,
            method,
            args=[[self.id], *list(args)],
            kwargs=kwargs,
            transport=transport,
        )

    def save(self) -> "OdooRecord":
        if self.id is None:
            record_id = self._model.client.create(self._model.model, self._model._write_values(self._values))
            self._values["id"] = int(record_id)
            return self.refresh()
        self._model.client.write(self._model.model, self.id, self._model._write_values(self._values))
        return self.refresh()

    def refresh(self) -> "OdooRecord":
        if self.id is None:
            raise ValueError("Cannot refresh an unsaved OdooRecord")
        fresh = self._model.objects.get(id=self.id)
        object.__setattr__(self, "_values", fresh.to_dict())
        return self

    def delete(self) -> None:
        if self.id is not None:
            self._model.client.unlink(self._model.model, self.id)
            self._values["id"] = None


class OdooRecordSet:
    """A lightweight recordset wrapper for multiple Odoo ids."""

    def __init__(self, model: "OdooModel", ids: int | Iterable[int]) -> None:
        self.model = model
        self.ids = _coerce_id_list(ids)

    def __repr__(self) -> str:
        return f"<OdooRecordSet {self.model.model} ids={self.ids!r}>"

    def __iter__(self):
        return iter(self.records())

    def __len__(self) -> int:
        return len(self.ids)

    def exists(self) -> bool:
        if not self.ids:
            return False
        existing_ids = set(self.model.client.search(self.model.model, [["id", "in", self.ids]]))
        return any(record_id in existing_ids for record_id in self.ids)

    def read(self, fields: list[str] | None = None) -> list[dict[str, Any]]:
        if not self.ids:
            return []
        return self.model.client.read(self.model.model, self.ids, fields=fields or self.model.selected_fields)

    def records(self, fields: list[str] | None = None) -> list[OdooRecord]:
        return [self.model.record(row) for row in self.read(fields=fields)]

    def first(self) -> OdooRecord | None:
        records = self.records()
        return records[0] if records else None

    def count(self) -> int:
        return len(self.ids)

    def call(self, method: str, *args: Any, **kwargs: Any) -> Any:
        transport = str(kwargs.pop("transport", "auto"))
        return self.model.client.execute(self.model.model, method, self.ids, *args, transport=transport, **kwargs)

    def write(self, values: Mapping[str, Any]) -> bool:
        return self.model.client.write(self.model.model, self.ids, values)

    def unlink(self) -> bool:
        return self.model.client.unlink(self.model.model, self.ids)

    def delete(self) -> bool:
        return self.unlink()

    def refresh(self) -> "OdooRecordSet":
        existing_ids = self.model.client.search(self.model.model, [["id", "in", self.ids]])
        self.ids = [record_id for record_id in self.ids if record_id in existing_ids]
        return self

    def to_dicts(self, fields: list[str] | None = None) -> list[dict[str, Any]]:
        return self.read(fields=fields)

    def datatable(self, fields: list[str] | None = None) -> "pd.DataFrame":
        return _to_data_table(self.to_dicts(fields=fields), fields=fields)


class OdooQuerySet:
    """Small Django-like query helper bound to one Odoo model."""

    def __init__(
        self,
        model: "OdooModel",
        domain: list[list[Any]] | None = None,
        *,
        limit: int | None = None,
        offset: int = 0,
        order: str | None = None,
    ) -> None:
        self.model = model
        self.domain = list(domain or [])
        self._limit = limit
        self._offset = offset
        self._order = order

    def __iter__(self):
        return iter(self.all())

    def filter(self, **kwargs: Any) -> "OdooQuerySet":
        return OdooQuerySet(
            self.model,
            [*self.domain, *_domain_from_lookup(kwargs)],
            limit=self._limit,
            offset=self._offset,
            order=self._order,
        )

    def limit(self, value: int) -> "OdooQuerySet":
        return OdooQuerySet(self.model, self.domain, limit=value, offset=self._offset, order=self._order)

    def offset(self, value: int) -> "OdooQuerySet":
        return OdooQuerySet(self.model, self.domain, limit=self._limit, offset=value, order=self._order)

    def order_by(self, value: str) -> "OdooQuerySet":
        return OdooQuerySet(self.model, self.domain, limit=self._limit, offset=self._offset, order=value)

    def all(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        order: str | None = None,
    ) -> list[OdooRecord]:
        rows = self.model.client.search_read(
            self.model.model,
            self.domain,
            fields=self.model.selected_fields,
            limit=self._limit if limit is None else limit,
            offset=self._offset if offset is None else offset,
            order=self._order if order is None else order,
        )
        return [self.model.record(row) for row in rows]

    def first(self) -> OdooRecord | None:
        rows = self.limit(1).all()
        return rows[0] if rows else None

    def count(self) -> int:
        return self.model.client.search_count(self.model.model, self.domain)

    def exists(self) -> bool:
        return self.count() > 0

    def values(self, *field_names: str, limit: int | None = None) -> list[dict[str, Any]]:
        fields = list(field_names) or self.model.selected_fields
        return self.model.client.search_read(
            self.model.model,
            self.domain,
            fields=fields,
            limit=self._limit if limit is None else limit,
            offset=self._offset,
            order=self._order,
        )

    def values_list(self, *field_names: str, flat: bool = False, limit: int | None = None) -> list[Any]:
        fields = list(field_names) or self.model.selected_fields
        if not fields:
            raise ValueError("values_list() requires at least one field name when the model has no selected_fields")
        rows = self.values(*fields, limit=limit)
        if flat:
            if len(fields) != 1:
                raise ValueError("flat=True requires exactly one field")
            return [row.get(fields[0]) for row in rows]
        return [tuple(row.get(field) for field in fields) for row in rows]

    def datatable(self, *field_names: str, limit: int | None = None) -> "pd.DataFrame":
        rows = self.values(*field_names, limit=limit)
        return _to_data_table(rows, fields=list(field_names) or self.model.selected_fields)

    def get(self, **kwargs: Any) -> OdooRecord:
        queryset = self.filter(**kwargs) if kwargs else self
        record = queryset.first()
        if record is None:
            raise LookupError(f"{self.model.model} matching query does not exist")
        return record

    def create(self, **kwargs: Any) -> OdooRecord:
        record_id = self.model.client.create(self.model.model, self.model._write_values(kwargs))
        return self.model.objects.get(id=int(record_id))

    def browse(self) -> OdooRecordSet:
        ids = self.model.client.search(
            self.model.model,
            self.domain,
            offset=self._offset,
            limit=self._limit,
            order=self._order,
        )
        return self.model.browse(ids)

    def update(self, **values: Any) -> bool:
        return self.browse().write(self.model._write_values(values))

    def delete(self) -> bool:
        return self.browse().unlink()


class OdooManager:
    def __init__(self, model: "OdooModel") -> None:
        self.model = model

    def all(self, *, limit: int = 20, offset: int = 0, order: str | None = None) -> list[OdooRecord]:
        return OdooQuerySet(self.model).all(limit=limit, offset=offset, order=order)

    def filter(self, **kwargs: Any) -> OdooQuerySet:
        return OdooQuerySet(self.model).filter(**kwargs)

    def get(self, **kwargs: Any) -> OdooRecord:
        return self.filter(**kwargs).get()

    def create(self, **kwargs: Any) -> OdooRecord:
        return OdooQuerySet(self.model).create(**kwargs)

    def browse(self, ids: int | Iterable[int]) -> OdooRecordSet:
        return self.model.browse(ids)

    def count(self) -> int:
        return OdooQuerySet(self.model).count()

    def exists(self) -> bool:
        return OdooQuerySet(self.model).exists()

    def order_by(self, value: str) -> OdooQuerySet:
        return OdooQuerySet(self.model).order_by(value)

    def limit(self, value: int) -> OdooQuerySet:
        return OdooQuerySet(self.model).limit(value)

    def values(self, *field_names: str, limit: int | None = None) -> list[dict[str, Any]]:
        return OdooQuerySet(self.model).values(*field_names, limit=limit)

    def values_list(self, *field_names: str, flat: bool = False, limit: int | None = None) -> list[Any]:
        return OdooQuerySet(self.model).values_list(*field_names, flat=flat, limit=limit)

    def datatable(self, *field_names: str, limit: int | None = None) -> "pd.DataFrame":
        return OdooQuerySet(self.model).datatable(*field_names, limit=limit)

    def get_or_create(self, defaults: Mapping[str, Any] | None = None, **lookup: Any) -> tuple[OdooRecord, bool]:
        record = self.filter(**lookup).first()
        if record is not None:
            return record, False
        create_values = dict(defaults or {})
        create_values.update(lookup)
        return self.create(**create_values), True

    def update_or_create(self, defaults: Mapping[str, Any] | None = None, **lookup: Any) -> tuple[OdooRecord, bool]:
        record = self.filter(**lookup).first()
        if record is None:
            create_values = dict(defaults or {})
            create_values.update(lookup)
            return self.create(**create_values), True
        for key, value in dict(defaults or {}).items():
            setattr(record, key, value)
        record.save()
        return record, False

    def bulk_create(self, values_list: Iterable[Mapping[str, Any]]) -> OdooRecordSet:
        ids = self.model.client.bulk_create(self.model.model, values_list)
        return self.model.browse(ids)

    def bulk_write(self, ids: int | Iterable[int], values: Mapping[str, Any]) -> bool:
        return self.model.client.bulk_write(self.model.model, ids, values)

    def insert_many(self, records: Any, *, chunk_size: int = 200) -> OdooRecordSet:
        return self.model.insert_many(records, chunk_size=chunk_size)

    def update_many(self, records: Any, *, id_field: str = "id", chunk_size: int = 200) -> int:
        return self.model.update_many(records, id_field=id_field, chunk_size=chunk_size)

    def delete_many(self, ids_or_records: Any, *, id_field: str = "id", chunk_size: int = 500) -> int:
        return self.model.delete_many(ids_or_records, id_field=id_field, chunk_size=chunk_size)

    def delete_by_keys(
        self,
        records: Any,
        *,
        key_fields: list[str] | tuple[str, ...] | None = None,
        chunk_size: int = 500,
        strict: bool = True,
    ) -> int:
        return self.model.delete_by_keys(records, key_fields=key_fields, chunk_size=chunk_size, strict=strict)

    def upsert_many(
        self,
        records: Any,
        *,
        key_fields: list[str] | tuple[str, ...] | None = None,
        chunk_size: int = 200,
        fields: list[str] | None = None,
        strict: bool = True,
    ) -> dict[str, Any]:
        return self.model.upsert_many(
            records,
            key_fields=key_fields,
            chunk_size=chunk_size,
            fields=fields,
            strict=strict,
        )


class OdooModel:
    def __init__(
        self,
        client: "OdooClient",
        model: str,
        *,
        fields: list[str] | None = None,
        key_fields: list[str] | tuple[str, ...] | None = None,
    ) -> None:
        self.client = client
        self.model = model
        self._selected_fields = list(fields) if fields is not None else None
        self._key_fields = list(key_fields) if key_fields is not None else None
        self.objects = OdooManager(self)

    def __repr__(self) -> str:
        return (
            f"OdooModel(model={self.model!r}, selected_fields={self._selected_fields!r}, "
            f"key_fields={self._key_fields!r})"
        )

    @property
    def selected_fields(self) -> list[str] | None:
        return list(self._selected_fields) if self._selected_fields is not None else None

    @property
    def key_fields(self) -> list[str] | None:
        return list(self._key_fields) if self._key_fields is not None else None

    @property
    def fields(self) -> dict[str, Any]:
        return self.client.model_fields(self.model)

    @property
    def field_names(self) -> list[str]:
        return list(self.fields.keys())

    @property
    def functions(self) -> list[str]:
        return self.client.model_functions(self.model)

    @property
    def methods(self) -> dict[str, Any]:
        return self.client.model_methods(self.model)

    def record(self, values: Mapping[str, Any] | None = None) -> OdooRecord:
        return OdooRecord(self, values)

    def new(self, **values: Any) -> OdooRecord:
        return self.record(values)

    def call(self, method: str, *args: Any, **kwargs: Any) -> Any:
        transport = str(kwargs.pop("transport", "auto"))
        return self.client.execute(self.model, method, *args, transport=transport, **kwargs)

    def browse(self, ids: int | Iterable[int]) -> OdooRecordSet:
        return OdooRecordSet(self, ids)

    @_timed_logged_method()
    def validate(
        self,
        records: Any,
        *,
        operation: str = "save",
        id_field: str = "id",
        key_fields: list[str] | tuple[str, ...] | None = None,
        strict: bool = True,
        require_non_empty: bool = False,
    ) -> "pd.DataFrame":
        normalized = _normalize_records_payload(records)
        if require_non_empty and not normalized:
            raise ValueError("validate() requires at least one record")

        resolved_key_fields = list(key_fields or self._key_fields or [])
        if operation in {"update", "delete"}:
            missing = [index for index, row in enumerate(normalized) if id_field not in row]
            if missing:
                raise ValueError(f"Each record must include {id_field!r} for {operation} validation")
        if operation in {"save", "upsert", "delete_by_keys"}:
            if not resolved_key_fields:
                raise ValueError(f"validate(operation={operation!r}) requires key_fields or model key_fields")
            missing = [
                {"row": index, "missing": [field for field in resolved_key_fields if field not in row]}
                for index, row in enumerate(normalized)
                if any(field not in row for field in resolved_key_fields)
            ]
            if missing:
                raise ValueError(f"Missing key fields for {operation} validation: {missing}")
            if strict:
                seen: dict[tuple[Any, ...], int] = {}
                duplicates: list[dict[str, Any]] = []
                for index, row in enumerate(normalized):
                    key = tuple(row[field] for field in resolved_key_fields)
                    if key in seen:
                        duplicates.append({"first_row": seen[key], "duplicate_row": index, "key": dict(zip(resolved_key_fields, key))})
                    else:
                        seen[key] = index
                if duplicates:
                    raise ValueError(f"Duplicate key rows detected for {operation} validation: {duplicates}")
        return _to_data_table(normalized)

    @_timed_logged_method()
    def insert(self, records: Any, *, chunk_size: int = 200) -> OdooRecordSet:
        return self.insert_many(records, chunk_size=chunk_size)

    @_timed_logged_method()
    def insert_many(self, records: Any, *, chunk_size: int = 200) -> OdooRecordSet:
        validated = self.validate(records, operation="insert")
        normalized = [self._write_values(row) for row in _normalize_records_payload(validated)]
        created_ids: list[int] = []
        for chunk in _chunked(normalized, chunk_size):
            created_ids.extend(self.client.bulk_create(self.model, chunk))
        return self.browse(created_ids)

    @_timed_logged_method()
    def update(self, records: Any, *, id_field: str = "id", chunk_size: int = 200) -> int:
        return self.update_many(records, id_field=id_field, chunk_size=chunk_size)

    @_timed_logged_method()
    def update_many(self, records: Any, *, id_field: str = "id", chunk_size: int = 200) -> int:
        validated = self.validate(records, operation="update", id_field=id_field)
        normalized = _normalize_records_payload(validated)
        updated = 0
        for chunk in _chunked(normalized, chunk_size):
            for row in chunk:
                record_id = int(row[id_field])
                values = {key: value for key, value in self._write_values(row).items() if key != id_field}
                if values:
                    self.client.write(self.model, record_id, values)
                updated += 1
        return updated

    @_timed_logged_method()
    def delete(self, ids_or_records: Any, *, id_field: str = "id", chunk_size: int = 500) -> int:
        return self.delete_many(ids_or_records, id_field=id_field, chunk_size=chunk_size)

    @_timed_logged_method()
    def delete_many(self, ids_or_records: Any, *, id_field: str = "id", chunk_size: int = 500) -> int:
        try:
            validated = self.validate(ids_or_records, operation="delete", id_field=id_field)
            normalized = _normalize_records_payload(validated)
        except TypeError:
            normalized = []
        except ValueError:
            raise
        if normalized:
            ids_list = [int(row[id_field]) for row in normalized]
        elif isinstance(ids_or_records, Iterable) and not isinstance(ids_or_records, (str, bytes)):
            ids_list = [int(item) for item in ids_or_records]
        else:
            ids_list = [int(ids_or_records)]
        deleted = 0
        for chunk in [ids_list[index : index + chunk_size] for index in range(0, len(ids_list), chunk_size)]:
            if chunk:
                self.client.unlink(self.model, chunk)
                deleted += len(chunk)
        return deleted

    @_timed_logged_method()
    def delete_by_keys(
        self,
        records: Any,
        *,
        key_fields: list[str] | tuple[str, ...] | None = None,
        chunk_size: int = 500,
        strict: bool = True,
    ) -> int:
        resolved_key_fields = list(key_fields or self._key_fields or [])
        if not resolved_key_fields:
            raise ValueError("delete_by_keys() requires key_fields or model key_fields")
        validated = self.validate(records, operation="delete_by_keys", key_fields=resolved_key_fields, strict=strict)
        normalized = _normalize_records_payload(validated)
        ids_to_delete: list[int] = []
        for row in normalized:
            lookup = {field: row[field] for field in resolved_key_fields if field in row}
            matches = self.client.search_read(
                self.model,
                _domain_from_lookup(lookup),
                fields=["id"],
                limit=2 if strict else None,
            )
            if strict and len(matches) > 1:
                raise OdooError(f"delete_by_keys() expected at most one existing {self.model} record for lookup={lookup!r}")
            ids_to_delete.extend(int(match["id"]) for match in matches if "id" in match)
        if not ids_to_delete:
            return 0
        return self.delete_many(sorted(set(ids_to_delete)), chunk_size=chunk_size)

    @_timed_logged_method()
    def upsert_many(
        self,
        records: Any,
        *,
        key_fields: list[str] | tuple[str, ...] | None = None,
        chunk_size: int = 200,
        fields: list[str] | None = None,
        strict: bool = True,
    ) -> dict[str, Any]:
        resolved_key_fields = list(key_fields or self._key_fields or [])
        if not resolved_key_fields:
            raise ValueError("upsert_many() requires key_fields or model key_fields")
        validated = self.validate(records, operation="upsert", key_fields=resolved_key_fields, strict=strict)
        normalized = _normalize_records_payload(validated)
        created_ids: list[int] = []
        updated_ids: list[int] = []
        for chunk in _chunked(normalized, chunk_size):
            for row in chunk:
                lookup = {field: row[field] for field in resolved_key_fields if field in row}
                record, created = self.client.upsert(
                    self.model,
                    lookup=lookup,
                    values={key: value for key, value in row.items() if key not in resolved_key_fields},
                    fields=fields,
                    strict=strict,
                )
                if created:
                    created_ids.append(int(record["id"]))
                else:
                    updated_ids.append(int(record["id"]))
        return {
            "created_ids": created_ids,
            "updated_ids": updated_ids,
            "created_count": len(created_ids),
            "updated_count": len(updated_ids),
        }

    @_timed_logged_method()
    def upsert(
        self,
        records: Any,
        *,
        key_fields: list[str] | tuple[str, ...] | None = None,
        chunk_size: int = 200,
        fields: list[str] | None = None,
        strict: bool = True,
    ) -> dict[str, Any]:
        return self.upsert_many(
            records,
            key_fields=key_fields,
            chunk_size=chunk_size,
            fields=fields,
            strict=strict,
        )

    @_timed_logged_method()
    def save(
        self,
        records: Any,
        *,
        key_fields: list[str] | tuple[str, ...] | None = None,
        chunk_size: int = 200,
        fields: list[str] | None = None,
        strict: bool = True,
    ) -> dict[str, Any]:
        return self.upsert(
            records,
            key_fields=key_fields,
            chunk_size=chunk_size,
            fields=fields,
            strict=strict,
        )

    def _write_values(self, values: Mapping[str, Any]) -> dict[str, Any]:
        if self._selected_fields is None:
            return {key: value for key, value in values.items() if key != "id"}
        return {field: values[field] for field in self._selected_fields if field != "id" and field in values}


class OdooEnv:
    """Model registry accessor, similar to Odoo's env lookup style."""

    def __init__(self, client: "OdooClient") -> None:
        self.client = client

    def __getitem__(self, model: str) -> OdooModel:
        return self.client.model(model)

    def model(
        self,
        model: str,
        *,
        fields: list[str] | None = None,
        key_fields: list[str] | tuple[str, ...] | None = None,
    ) -> OdooModel:
        return self.client.model(model, fields=fields, key_fields=key_fields)


class OdooClient:
    """Odoo 19 client with JSON-2-first helpers and XML-RPC compatibility."""

    def __init__(
        self,
        base_url: str,
        database: str,
        *,
        login: str | None = None,
        password: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
        context: Mapping[str, Any] | None = None,
        user_agent: str = "soigia-odoo-client/0.1",
        opener: Any | None = None,
        urlopen_func: Callable[..., Any] | None = None,
        server_proxy_factory: Callable[..., Any] | None = None,
        retry_count: int = 0,
        retry_delay: float = 0.5,
        logger: logging.Logger | None = None,
    ) -> None:
        self.base_url = _normalize_base_url(base_url)
        self.database = database
        self.login = login
        self.password = password
        self.api_key = api_key
        self.timeout = float(timeout)
        self.context = dict(context or {})
        self.user_agent = user_agent
        self.uid: int | None = None
        self.env = OdooEnv(self)
        self._fields_cache: dict[str, dict[str, Any]] = {}
        self._model_doc_cache: dict[str, dict[str, Any]] = {}
        self.retry_count = max(0, int(retry_count))
        self.retry_delay = max(0.0, float(retry_delay))
        self.logger = logger or logging.getLogger(__name__)

        self._cookie_jar = CookieJar()
        self._opener = opener or build_opener(HTTPCookieProcessor(self._cookie_jar))
        self._urlopen = urlopen_func or urlopen
        self._server_proxy_factory = server_proxy_factory or xmlrpc.client.ServerProxy

    @classmethod
    def from_env(
        cls,
        *,
        prefix: str = "ODOO_",
        timeout: float = 30.0,
        context: Mapping[str, Any] | None = None,
        user_agent: str = "soigia-odoo-client/0.1",
        retry_count: int = 0,
        retry_delay: float = 0.5,
        logger: logging.Logger | None = None,
    ) -> "OdooClient":
        base_url = os.environ.get(f"{prefix}URL")
        database = os.environ.get(f"{prefix}DB")
        if not base_url or not database:
            raise OdooAuthenticationError(
                f"Environment variables {prefix}URL and {prefix}DB are required to build OdooClient.from_env()"
            )
        return cls(
            base_url,
            database,
            login=os.environ.get(f"{prefix}LOGIN"),
            password=os.environ.get(f"{prefix}PASSWORD"),
            api_key=os.environ.get(f"{prefix}API_KEY"),
            timeout=timeout,
            context=context,
            user_agent=user_agent,
            retry_count=retry_count,
            retry_delay=retry_delay,
            logger=logger,
        )

    @classmethod
    def from_django_settings(
        cls,
        settings: Any | None = None,
        *,
        prefix: str = "ODOO_",
        default_section: str = "ODOO",
    ) -> "OdooClient":
        if settings is None:
            from django.conf import settings as django_settings

            settings = django_settings

        section = getattr(settings, default_section, None)
        if isinstance(section, Mapping):
            config = dict(section)
            base_url = config.get("URL") or config.get("url")
            database = config.get("DB") or config.get("db") or config.get("DATABASE")
            if base_url and database:
                return cls(
                    base_url,
                    database,
                    login=config.get("LOGIN") or config.get("login"),
                    password=config.get("PASSWORD") or config.get("password"),
                    api_key=config.get("API_KEY") or config.get("api_key"),
                    timeout=float(config.get("TIMEOUT", config.get("timeout", 30.0))),
                    context=config.get("CONTEXT") or config.get("context"),
                    user_agent=str(config.get("USER_AGENT", config.get("user_agent", "soigia-odoo-client/0.1"))),
                    retry_count=int(config.get("RETRY_COUNT", config.get("retry_count", 0))),
                    retry_delay=float(config.get("RETRY_DELAY", config.get("retry_delay", 0.5))),
                )

        return cls(
            getattr(settings, f"{prefix}URL"),
            getattr(settings, f"{prefix}DB"),
            login=getattr(settings, f"{prefix}LOGIN", None),
            password=getattr(settings, f"{prefix}PASSWORD", None),
            api_key=getattr(settings, f"{prefix}API_KEY", None),
            timeout=float(getattr(settings, f"{prefix}TIMEOUT", 30.0)),
            context=getattr(settings, f"{prefix}CONTEXT", None),
            user_agent=str(getattr(settings, f"{prefix}USER_AGENT", "soigia-odoo-client/0.1")),
            retry_count=int(getattr(settings, f"{prefix}RETRY_COUNT", 0)),
            retry_delay=float(getattr(settings, f"{prefix}RETRY_DELAY", 0.5)),
        )

    @property
    def connection_info(self) -> OdooConnectionInfo:
        return OdooConnectionInfo(
            base_url=self.base_url,
            database=self.database,
            login=self.login,
            password=self.password,
            api_key=self.api_key,
            timeout=self.timeout,
            user_agent=self.user_agent,
        )

    def __enter__(self) -> "OdooClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        self.close()
        return False

    def with_context(self, **context: Any) -> "OdooClient":
        merged_context = dict(self.context)
        merged_context.update(context)
        clone = OdooClient(
            self.base_url,
            self.database,
            login=self.login,
            password=self.password,
            api_key=self.api_key,
            timeout=self.timeout,
            context=merged_context,
            user_agent=self.user_agent,
            opener=self._opener,
            urlopen_func=self._urlopen,
            server_proxy_factory=self._server_proxy_factory,
            retry_count=self.retry_count,
            retry_delay=self.retry_delay,
            logger=self.logger,
        )
        clone.uid = self.uid
        return clone

    def with_lang(self, lang: str) -> "OdooClient":
        return self.with_context(lang=lang)

    def with_timezone(self, timezone: str) -> "OdooClient":
        return self.with_context(tz=timezone)

    def with_company(self, company_id: int, *, allowed_company_ids: Iterable[int] | None = None) -> "OdooClient":
        company_ids = [int(company_id)]
        if allowed_company_ids is not None:
            company_ids = [int(value) for value in allowed_company_ids]
            if int(company_id) not in company_ids:
                company_ids.insert(0, int(company_id))
        return self.with_context(company_id=int(company_id), allowed_company_ids=company_ids)

    def model(
        self,
        model: str,
        *,
        fields: list[str] | None = None,
        key_fields: list[str] | tuple[str, ...] | None = None,
    ) -> OdooModel:
        return OdooModel(self, model, fields=fields, key_fields=key_fields)

    def __getitem__(self, model: str) -> OdooModel:
        return self.model(model)

    def _xmlrpc_proxy(self, path: str) -> Any:
        return self._server_proxy_factory(f"{self.base_url}{path}", allow_none=True)

    def _call_with_retry(
        self,
        operation: str,
        callback: Callable[[], Any],
        *,
        retriable: tuple[type[BaseException], ...],
    ) -> Any:
        attempts = self.retry_count + 1
        for attempt in range(1, attempts + 1):
            try:
                return callback()
            except retriable as exc:
                self.logger.warning("Odoo operation failed", extra={"operation": operation, "attempt": attempt})
                if attempt >= attempts:
                    raise
                time.sleep(self.retry_delay)
        raise RuntimeError(f"Unexpected retry state for {operation}")

    def version_info(self) -> dict[str, Any]:
        return dict(self._xmlrpc_proxy("/xmlrpc/2/common").version())

    def model_fields(
        self,
        model: str,
        *,
        attributes: list[str] | None = None,
        refresh: bool = False,
    ) -> dict[str, Any]:
        cache_key = f"{model}|{','.join(attributes or [])}"
        if not refresh and cache_key in self._fields_cache:
            return dict(self._fields_cache[cache_key])
        metadata = self.fields_get(model, attributes=attributes or ["string", "type", "help", "readonly", "required"])
        self._fields_cache[cache_key] = dict(metadata)
        return dict(metadata)

    def model_doc(self, model: str, *, refresh: bool = False) -> dict[str, Any]:
        if not refresh and model in self._model_doc_cache:
            return dict(self._model_doc_cache[model])

        if self.api_key:
            request = Request(
                f"{self.base_url}/doc-bearer/{model}.json",
                headers={
                    "Authorization": f"bearer {self.api_key}",
                    "X-Odoo-Database": self.database,
                    "User-Agent": self.user_agent,
                },
            )
            result = self._json_request(request)
        else:
            self.web_authenticate()
            request = Request(
                f"{self.base_url}/doc/{model}.json",
                headers={"User-Agent": self.user_agent},
            )
            result = self._json_request(request, use_opener=True)

        if not isinstance(result, Mapping):
            raise OdooHttpError(f"Odoo doc metadata for model {model!r} returned an invalid payload")
        self._model_doc_cache[model] = dict(result)
        return dict(result)

    def model_functions(self, model: str, *, refresh: bool = False) -> list[str]:
        doc = self.model_doc(model, refresh=refresh)
        methods = doc.get("methods", {})
        if isinstance(methods, Mapping):
            return sorted(str(name) for name in methods)
        if isinstance(methods, list):
            return sorted(str(name) for name in methods)
        return []

    def model_methods(self, model: str, *, refresh: bool = False) -> dict[str, Any]:
        doc = self.model_doc(model, refresh=refresh)
        methods = doc.get("methods", {})
        return dict(methods) if isinstance(methods, Mapping) else {}

    def list_databases(self) -> list[str]:
        result = self._web_json("/web/database/list", payload={})
        return [str(name) for name in result]

    def _auth_secret(self) -> str:
        secret = self.password or self.api_key
        if not secret:
            raise OdooAuthenticationError("Odoo login requires either a password or an API key")
        return secret

    def authenticate(self, *, context: Mapping[str, Any] | None = None) -> int:
        if not self.login:
            raise OdooAuthenticationError("Odoo login is required for XML-RPC authentication")
        auth_context = dict(self.context)
        if context:
            auth_context.update(context)
        try:
            uid = self._xmlrpc_proxy("/xmlrpc/2/common").authenticate(
                self.database,
                self.login,
                self._auth_secret(),
                auth_context,
            )
        except xmlrpc.client.Fault as exc:
            raise OdooRpcError(exc.faultString) from exc
        if not uid:
            raise OdooAuthenticationError(
                f"Odoo authentication failed for user {self.login!r} on database {self.database!r}"
            )
        self.uid = int(uid)
        return self.uid

    def _require_uid(self) -> int:
        return self.uid if self.uid is not None else self.authenticate()

    def execute_kw(
        self,
        model: str,
        method: str,
        args: Iterable[Any] | None = None,
        kwargs: Mapping[str, Any] | None = None,
    ) -> Any:
        rpc_args = list(args or [])
        rpc_kwargs = dict(kwargs or {})
        if self.context:
            rpc_kwargs.setdefault("context", dict(self.context))

        def run() -> Any:
            return self._xmlrpc_proxy("/xmlrpc/2/object").execute_kw(
                self.database,
                self._require_uid(),
                self._auth_secret(),
                model,
                method,
                rpc_args,
                rpc_kwargs,
            )

        try:
            return self._call_with_retry(
                f"xmlrpc:{model}.{method}",
                run,
                retriable=(OSError, xmlrpc.client.ProtocolError),
            )
        except xmlrpc.client.Fault as exc:
            raise OdooRpcError(exc.faultString) from exc

    def web_authenticate(self) -> dict[str, Any]:
        if not self.login or not self.password:
            raise OdooAuthenticationError("Web session authentication requires both login and password")
        result = self._web_json(
            "/web/session/authenticate",
            payload={
                "db": self.database,
                "login": self.login,
                "password": self.password,
            },
        )
        uid = result.get("uid")
        if not uid:
            raise OdooAuthenticationError(
                f"Odoo web authentication failed for user {self.login!r} on database {self.database!r}"
            )
        self.uid = int(uid)
        return dict(result)

    def session_info(self) -> dict[str, Any]:
        return dict(self._web_json("/web/session/get_session_info", payload={}))

    def web_call_kw(
        self,
        model: str,
        method: str,
        *,
        args: Iterable[Any] | None = None,
        kwargs: Mapping[str, Any] | None = None,
        context: Mapping[str, Any] | None = None,
    ) -> Any:
        call_kwargs = dict(kwargs or {})
        merged_context = dict(self.context)
        if "context" in call_kwargs and isinstance(call_kwargs["context"], Mapping):
            merged_context.update(call_kwargs["context"])
        if context:
            merged_context.update(context)
        if merged_context:
            call_kwargs["context"] = merged_context
        return self._web_json(
            f"/web/dataset/call_kw/{model}/{method}",
            payload={
                "model": model,
                "method": method,
                "args": list(args or []),
                "kwargs": call_kwargs,
            },
        )

    def create_api_key(
        self,
        *,
        name: str = "soigia json-2 key",
        duration: str = "1",
        password: str | None = None,
        store: bool = True,
    ) -> str:
        secret = password or self.password
        if not secret:
            raise OdooAuthenticationError("API key bootstrap requires the account password")

        self.web_authenticate()
        wizard_record = self.web_call_kw(
            "res.users.apikeys.description",
            "create",
            args=[[{"name": name, "duration": duration}]],
        )
        wizard_id = wizard_record[0] if isinstance(wizard_record, list) else wizard_record
        action = self.web_call_kw(
            "res.users.apikeys.description",
            "make_key",
            args=[[wizard_id]],
        )

        if isinstance(action, Mapping) and action.get("res_model") == "res.users.identitycheck":
            identity_id = action.get("res_id")
            if not identity_id:
                raise OdooHttpError("Odoo identity check wizard did not return a record id")
            action = self.web_call_kw(
                "res.users.identitycheck",
                "run_check",
                args=[[identity_id]],
                kwargs={"context": {"password": secret}},
            )

        api_key = None
        if isinstance(action, Mapping):
            api_key = action.get("context", {}).get("default_key")
        if not api_key:
            raise OdooHttpError("Odoo did not return a new API key")
        if store:
            self.api_key = str(api_key)
        return str(api_key)

    def revoke_api_key(self, key: str | None = None) -> bool:
        key_to_revoke = key or self.api_key
        if not key_to_revoke:
            raise OdooAuthenticationError("No API key is available to revoke")
        result = self.json2_call("res.users.apikeys", "revoke", {"key": key_to_revoke})
        if key_to_revoke == self.api_key:
            self.api_key = None
        return bool(result)

    def ensure_api_key(
        self,
        *,
        name: str = "soigia auto key",
        duration: str = "1",
        password: str | None = None,
    ) -> str:
        if self.api_key:
            return self.api_key
        return self.create_api_key(name=name, duration=duration, password=password, store=True)

    def ensure_authenticated(
        self,
        *,
        prefer_api_key: bool = False,
        api_key_name: str = "soigia auto key",
        api_key_duration: str = "1",
    ) -> "OdooClient":
        if prefer_api_key:
            self.ensure_api_key(name=api_key_name, duration=api_key_duration)
            return self
        self.authenticate()
        return self

    def ping(self) -> dict[str, Any]:
        version = self.version_info()
        return {
            "ok": True,
            "base_url": self.base_url,
            "database": self.database,
            "server_version": version.get("server_version"),
            "server_serie": version.get("server_serie"),
        }

    def clear_caches(self) -> None:
        self._fields_cache.clear()
        self._model_doc_cache.clear()

    def close(self) -> None:
        self.clear_caches()

    def json2_call(
        self,
        model: str,
        method: str,
        payload: Mapping[str, Any] | None = None,
        *,
        api_key: str | None = None,
        database: str | None = None,
    ) -> Any:
        bearer_token = api_key or self.api_key
        if not bearer_token:
            raise OdooAuthenticationError("JSON-2 calls require an API key")
        request_body = json.dumps(dict(payload or {})).encode("utf-8")
        request = Request(
            f"{self.base_url}/json/2/{model}/{method}",
            data=request_body,
            headers={
                "Content-Type": "application/json; charset=utf-8",
                "Authorization": f"bearer {bearer_token}",
                "X-Odoo-Database": database or self.database,
                "User-Agent": self.user_agent,
            },
        )
        try:
            with self._urlopen(request, timeout=self.timeout) as response:
                raw_body = response.read().decode("utf-8")
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise OdooJson2Error(f"JSON-2 {model}.{method} failed with HTTP {exc.code}: {detail}") from exc
        except URLError as exc:
            raise OdooJson2Error(f"JSON-2 {model}.{method} failed: {exc}") from exc

        if not raw_body.strip():
            return None
        try:
            return json.loads(raw_body)
        except json.JSONDecodeError as exc:
            raise OdooJson2Error(f"JSON-2 {model}.{method} returned invalid JSON: {raw_body!r}") from exc

    def call_method(
        self,
        model: str,
        method: str,
        *,
        args: Iterable[Any] | None = None,
        kwargs: Mapping[str, Any] | None = None,
        transport: str = "auto",
    ) -> Any:
        selected_transport = transport
        if transport == "auto":
            selected_transport = "json2" if self.api_key and not list(args or []) else "xmlrpc"

        if selected_transport == "json2":
            payload = dict(kwargs or {})
            extra_args = list(args or [])
            if extra_args:
                payload["args"] = extra_args
            return self.json2_call(model, method, payload)
        if selected_transport == "xmlrpc":
            return self.execute_kw(model, method, args=args, kwargs=kwargs)
        raise ValueError("transport must be one of: auto, json2, xmlrpc")

    def execute(
        self,
        model: str,
        method: str,
        *args: Any,
        transport: str = "auto",
        **kwargs: Any,
    ) -> Any:
        return self.call_method(model, method, args=args, kwargs=kwargs, transport=transport)

    def search(
        self,
        model: str,
        domain: list[list[Any]],
        *,
        offset: int = 0,
        limit: int | None = None,
        order: str | None = None,
    ) -> list[int]:
        json2_payload = {"domain": domain, "offset": offset}
        xmlrpc_kwargs = {"offset": offset}
        if limit is not None:
            json2_payload["limit"] = limit
            xmlrpc_kwargs["limit"] = limit
        if order is not None:
            json2_payload["order"] = order
            xmlrpc_kwargs["order"] = order
        if self.api_key:
            return [int(value) for value in self.json2_call(model, "search", json2_payload)]
        return [int(value) for value in self.execute_kw(model, "search", args=[domain], kwargs=xmlrpc_kwargs)]

    def search_count(self, model: str, domain: list[list[Any]]) -> int:
        if self.api_key:
            return int(self.json2_call(model, "search_count", {"domain": domain}))
        return int(self.execute_kw(model, "search_count", args=[domain]))

    def read(
        self,
        model: str,
        ids: int | Iterable[int],
        *,
        fields: list[str] | None = None,
        load: str | None = None,
    ) -> list[dict[str, Any]]:
        id_list = _coerce_id_list(ids)
        json2_payload: dict[str, Any] = {"ids": id_list}
        xmlrpc_kwargs: dict[str, Any] = {}
        if fields is not None:
            json2_payload["fields"] = fields
            xmlrpc_kwargs["fields"] = fields
        if load is not None:
            json2_payload["load"] = load
            xmlrpc_kwargs["load"] = load
        if self.api_key:
            return list(self.json2_call(model, "read", json2_payload))
        return list(self.execute_kw(model, "read", args=[id_list], kwargs=xmlrpc_kwargs))

    def search_read(
        self,
        model: str,
        domain: list[list[Any]],
        *,
        fields: list[str] | None = None,
        offset: int = 0,
        limit: int | None = None,
        order: str | None = None,
    ) -> list[dict[str, Any]]:
        json2_payload: dict[str, Any] = {"domain": domain, "offset": offset}
        xmlrpc_kwargs: dict[str, Any] = {"offset": offset}
        if fields is not None:
            json2_payload["fields"] = fields
            xmlrpc_kwargs["fields"] = fields
        if limit is not None:
            json2_payload["limit"] = limit
            xmlrpc_kwargs["limit"] = limit
        if order is not None:
            json2_payload["order"] = order
            xmlrpc_kwargs["order"] = order
        if self.api_key:
            return list(self.json2_call(model, "search_read", json2_payload))
        return list(self.execute_kw(model, "search_read", args=[domain], kwargs=xmlrpc_kwargs))

    def search_read_iter(
        self,
        model: str,
        domain: list[list[Any]],
        *,
        fields: list[str] | None = None,
        batch_size: int = 100,
        order: str | None = None,
    ):
        offset = 0
        while True:
            rows = self.search_read(
                model,
                domain,
                fields=fields,
                offset=offset,
                limit=batch_size,
                order=order,
            )
            if not rows:
                break
            for row in rows:
                yield row
            if len(rows) < batch_size:
                break
            offset += batch_size

    def search_read_all(
        self,
        model: str,
        domain: list[list[Any]],
        *,
        fields: list[str] | None = None,
        batch_size: int = 100,
        order: str | None = None,
    ) -> list[dict[str, Any]]:
        return list(self.search_read_iter(model, domain, fields=fields, batch_size=batch_size, order=order))

    def fields_get(
        self,
        model: str,
        *,
        attributes: list[str] | None = None,
        allfields: list[str] | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if attributes is not None:
            payload["attributes"] = attributes
        if allfields is not None:
            payload["allfields"] = allfields
        if self.api_key:
            return dict(self.json2_call(model, "fields_get", payload))
        kwargs = dict(payload)
        return dict(self.execute_kw(model, "fields_get", args=[], kwargs=kwargs))

    def default_get(self, model: str, fields: list[str]) -> dict[str, Any]:
        payload = {"fields": fields}
        if self.api_key:
            return dict(self.json2_call(model, "default_get", payload))
        return dict(self.execute_kw(model, "default_get", args=[fields]))

    def name_search(
        self,
        model: str,
        name: str = "",
        *,
        args: list[list[Any]] | None = None,
        operator: str = "ilike",
        limit: int = 100,
    ) -> list[list[Any]]:
        json2_payload = {"name": name, "operator": operator, "limit": limit}
        xmlrpc_kwargs = {"operator": operator, "limit": limit}
        if args is not None:
            json2_payload["args"] = args
            xmlrpc_kwargs["args"] = args
        if self.api_key:
            return list(self.json2_call(model, "name_search", json2_payload))
        return list(self.execute_kw(model, "name_search", args=[name], kwargs=xmlrpc_kwargs))

    def read_group(
        self,
        model: str,
        domain: list[list[Any]],
        *,
        fields: list[str],
        groupby: list[str],
        offset: int = 0,
        limit: int | None = None,
        orderby: str | None = None,
        lazy: bool = True,
    ) -> list[dict[str, Any]]:
        json2_payload: dict[str, Any] = {
            "domain": domain,
            "fields": fields,
            "groupby": groupby,
            "offset": offset,
            "lazy": lazy,
        }
        xmlrpc_kwargs: dict[str, Any] = {
            "offset": offset,
            "lazy": lazy,
        }
        if limit is not None:
            json2_payload["limit"] = limit
            xmlrpc_kwargs["limit"] = limit
        if orderby is not None:
            json2_payload["orderby"] = orderby
            xmlrpc_kwargs["orderby"] = orderby
        if self.api_key:
            return list(self.json2_call(model, "read_group", json2_payload))
        return list(self.execute_kw(model, "read_group", args=[domain, fields, groupby], kwargs=xmlrpc_kwargs))

    def export_data(self, model: str, ids: int | Iterable[int], fields: list[str]) -> list[list[Any]]:
        records = self.execute_kw(model, "export_data", args=[_coerce_id_list(ids), fields])
        if isinstance(records, Mapping):
            data = records.get("datas", [])
            return list(data) if isinstance(data, list) else []
        return list(records)

    def create(self, model: str, values: Mapping[str, Any] | list[Mapping[str, Any]]) -> int | list[int]:
        if isinstance(values, Mapping):
            if self.api_key:
                created = self.json2_call(model, "create", {"vals_list": [dict(values)]})
                return int(created[0])
            return int(self.execute_kw(model, "create", args=[dict(values)]))

        vals_list = [dict(item) for item in values]
        if self.api_key:
            return [int(item) for item in self.json2_call(model, "create", {"vals_list": vals_list})]
        created = self.execute_kw(model, "create", args=[vals_list])
        return [int(item) for item in created] if isinstance(created, list) else [int(created)]

    def bulk_create(self, model: str, values_list: Iterable[Mapping[str, Any]]) -> list[int]:
        created = self.create(model, list(values_list))
        return [int(item) for item in created] if isinstance(created, list) else [int(created)]

    def write(self, model: str, ids: int | Iterable[int], values: Mapping[str, Any]) -> bool:
        id_list = _coerce_id_list(ids)
        vals = dict(values)
        if self.api_key:
            return bool(self.json2_call(model, "write", {"ids": id_list, "vals": vals}))
        return bool(self.execute_kw(model, "write", args=[id_list, vals]))

    def bulk_write(self, model: str, ids: int | Iterable[int], values: Mapping[str, Any]) -> bool:
        return self.write(model, ids, values)

    def insert_many(self, model: str, records: Any, *, chunk_size: int = 200) -> list[int]:
        normalized = _normalize_records_payload(records)
        created_ids: list[int] = []
        for chunk in _chunked(normalized, chunk_size):
            created_ids.extend(self.bulk_create(model, chunk))
        return created_ids

    def update_many(self, model: str, records: Any, *, id_field: str = "id", chunk_size: int = 200) -> int:
        normalized = _normalize_records_payload(records)
        updated = 0
        for chunk in _chunked(normalized, chunk_size):
            for row in chunk:
                if id_field not in row:
                    raise ValueError(f"Each record must include {id_field!r} for update_many()")
                record_id = int(row[id_field])
                values = {key: value for key, value in row.items() if key != id_field}
                if values:
                    self.write(model, record_id, values)
                updated += 1
        return updated

    def delete_many(self, model: str, ids_or_records: Any, *, id_field: str = "id", chunk_size: int = 500) -> int:
        ids_list: list[int] = []
        try:
            normalized = _normalize_records_payload(ids_or_records)
        except TypeError:
            normalized = []
        if normalized:
            ids_list = [int(row[id_field]) for row in normalized]
        elif isinstance(ids_or_records, Iterable) and not isinstance(ids_or_records, (str, bytes)):
            ids_list = [int(item) for item in ids_or_records]
        else:
            ids_list = [int(ids_or_records)]
        deleted = 0
        for chunk in [ids_list[index : index + chunk_size] for index in range(0, len(ids_list), chunk_size)]:
            if chunk:
                self.unlink(model, chunk)
                deleted += len(chunk)
        return deleted

    def delete_by_keys(
        self,
        model: str,
        records: Any,
        *,
        key_fields: list[str] | tuple[str, ...] | None = None,
        chunk_size: int = 500,
        strict: bool = True,
    ) -> int:
        return self.model(model, key_fields=key_fields).delete_by_keys(
            records,
            key_fields=key_fields,
            chunk_size=chunk_size,
            strict=strict,
        )

    def upsert_many(
        self,
        model: str,
        records: Any,
        *,
        key_fields: list[str] | tuple[str, ...] | None = None,
        chunk_size: int = 200,
        fields: list[str] | None = None,
        strict: bool = True,
    ) -> dict[str, Any]:
        return self.model(model, fields=fields, key_fields=key_fields).upsert_many(
            records,
            key_fields=key_fields,
            chunk_size=chunk_size,
            fields=fields,
            strict=strict,
        )

    def upsert(
        self,
        model: str,
        *,
        lookup: Mapping[str, Any],
        values: Mapping[str, Any] | None = None,
        fields: list[str] | None = None,
        strict: bool = True,
    ) -> tuple[dict[str, Any], bool]:
        domain = _domain_from_lookup(lookup)
        existing = self.search_read(model, domain, fields=fields, limit=2 if strict else 1)
        if strict and len(existing) > 1:
            raise OdooError(f"upsert() expected at most one existing {model} record for lookup={lookup!r}")
        if existing:
            record = dict(existing[0])
            payload = dict(values or {})
            if payload:
                self.write(model, int(record["id"]), payload)
                record = self.read(model, int(record["id"]), fields=fields)[0]
            return record, False

        create_values = dict(lookup)
        create_values.update(values or {})
        record_id = int(self.create(model, create_values))
        return self.read(model, record_id, fields=fields)[0], True

    def unlink(self, model: str, ids: int | Iterable[int]) -> bool:
        id_list = _coerce_id_list(ids)
        if self.api_key:
            return bool(self.json2_call(model, "unlink", {"ids": id_list}))
        return bool(self.execute_kw(model, "unlink", args=[id_list]))

    def upload_attachment(
        self,
        *,
        name: str,
        content: bytes | str,
        res_model: str | None = None,
        res_id: int | None = None,
        mimetype: str = "application/octet-stream",
    ) -> int:
        if isinstance(content, str):
            payload_bytes = content.encode("utf-8")
        else:
            payload_bytes = content
        values: dict[str, Any] = {
            "name": name,
            "type": "binary",
            "datas": base64.b64encode(payload_bytes).decode("ascii"),
            "mimetype": mimetype,
        }
        if res_model is not None:
            values["res_model"] = res_model
        if res_id is not None:
            values["res_id"] = int(res_id)
        return int(self.create("ir.attachment", values))

    def download_attachment(self, attachment_id: int) -> bytes:
        records = self.read("ir.attachment", [attachment_id], fields=["datas"])
        if not records:
            raise OdooError(f"Attachment {attachment_id} was not found")
        encoded = records[0].get("datas")
        if not encoded:
            return b""
        return base64.b64decode(encoded)

    def browse(self, model: str, ids: int | Iterable[int], *, fields: list[str] | None = None) -> OdooRecordSet:
        return self.model(model, fields=fields).browse(ids)

    def create_wizard(
        self,
        model: str,
        values: Mapping[str, Any] | None = None,
        *,
        transport: str = "xmlrpc",
    ) -> int:
        return int(self.execute(model, "create", dict(values or {}), transport=transport))

    def run_wizard(
        self,
        model: str,
        action_method: str,
        *,
        values: Mapping[str, Any] | None = None,
        wizard_id: int | None = None,
        transport: str = "xmlrpc",
        **kwargs: Any,
    ) -> Any:
        record_id = wizard_id or self.create_wizard(model, values, transport=transport)
        return self.execute(model, action_method, [record_id], transport=transport, **kwargs)

    def download_report(
        self,
        report_name: str,
        ids: int | Iterable[int],
        *,
        converter: str = "pdf",
        data: Mapping[str, Any] | None = None,
        context: Mapping[str, Any] | None = None,
    ) -> bytes:
        self.web_authenticate()
        id_list = _coerce_id_list(ids)
        id_path = ",".join(str(value) for value in id_list)
        url = f"{self.base_url}/report/{converter}/{report_name}/{id_path}"
        request = Request(url, headers={"User-Agent": self.user_agent})
        if data is not None or context is not None:
            payload = {"data": dict(data or {}), "context": dict(context or self.context)}
            request = Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": self.user_agent},
            )
        return self._binary_request(request, use_opener=True)

    def _web_json(self, path: str, payload: Mapping[str, Any]) -> Any:
        request_body = json.dumps({"jsonrpc": "2.0", "params": dict(payload)}).encode("utf-8")
        request = Request(
            f"{self.base_url}{path}",
            data=request_body,
            headers={
                "Content-Type": "application/json",
                "User-Agent": self.user_agent,
            },
        )

        return self._json_request(request, use_opener=True)

    def _binary_request(self, request: Request, *, use_opener: bool = False) -> bytes:
        opener = self._opener.open if use_opener else self._urlopen

        def run() -> bytes:
            with opener(request, timeout=self.timeout) as response:
                return response.read()

        try:
            return self._call_with_retry(
                f"http:{request.full_url}",
                run,
                retriable=(HTTPError, URLError, OSError),
            )
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise OdooHttpError(f"HTTP request failed with HTTP {exc.code}: {detail}") from exc
        except URLError as exc:
            raise OdooHttpError(f"HTTP request failed: {exc}") from exc

    def _json_request(self, request: Request, *, use_opener: bool = False) -> Any:
        raw_body = self._binary_request(request, use_opener=use_opener).decode("utf-8")

        try:
            payload = json.loads(raw_body)
        except json.JSONDecodeError as exc:
            raise OdooHttpError(f"HTTP request returned invalid JSON: {raw_body!r}") from exc

        if "error" in payload:
            message = payload["error"].get("message", "Unknown Odoo web error")
            raise OdooHttpError(f"HTTP JSON request failed: {message}")
        if isinstance(payload, Mapping) and "result" in payload:
            return payload.get("result")
        return payload
