__version__ = "0.1.15"

__all__ = [
    "__version__",
    "domain",
    "Model",
    "fields",
    "setup",
    "use_storage",
    "config",
    "DataTable",
    "datatable",
    "df",
    "ui",
    "db",
    "pipeline",
    "Pipeline",
    "BasePipeline",
    "BaseStep",
    "FunctionStep",
    "PipelineContext",
    "PipelineStatus",
    "StepOutcome",
    "ConfigStore",
    "default_config",
    "load_config",
    "save_config",
    "resolve_config_path",
    "get_accounts",
    "get_account",
    "upsert_account",
    "delete_account",
    "DatabaseConnector",
    "db_connector",
    "from_sql",
    "from_mysql_db",
    "from_maria_db",
    "from_oracle_db",
    "from_postgres_db",
    "from_sqlite_db",
    "from_faker",
    "from_factory",
    "Tester",
    "odoo_client",
    "OdooClient",
    "OdooConnectionInfo",
    "OdooEnv",
    "OdooModel",
    "OdooQuerySet",
    "OdooManager",
    "OdooRecord",
    "OdooRecordSet",
    "OdooError",
    "OdooAuthenticationError",
    "OdooRpcError",
    "OdooJson2Error",
    "OdooHttpError",
]

_MODULE_EXPORTS = {
    "domain": ".domain",
    "datatable": ".datatable",
    "ui": ".ui",
    "pipeline": ".pipeline",
    "db": ".db",
    "config": ".config",
    "tester": ".tester",
    "odoo_client": ".odoo_client",
}

_ERP_EXPORTS = {"Model", "fields", "setup", "use_storage"}
_PIPELINE_EXPORTS = {
    "Pipeline",
    "BasePipeline",
    "BaseStep",
    "FunctionStep",
    "PipelineContext",
    "PipelineStatus",
    "StepOutcome",
}
_CONFIG_EXPORTS = {
    "ConfigStore",
    "default_config",
    "load_config",
    "save_config",
    "resolve_config_path",
    "get_accounts",
    "get_account",
    "upsert_account",
    "delete_account",
}
_DATATABLE_EXPORTS = {
    "DataTable",
    "df",
    "DatabaseConnector",
    "db_connector",
    "from_sql",
    "from_mysql_db",
    "from_maria_db",
    "from_oracle_db",
    "from_postgres_db",
    "from_sqlite_db",
    "from_faker",
    "from_factory",
}
_ODOO_EXPORTS = {
    "OdooClient",
    "OdooConnectionInfo",
    "OdooEnv",
    "OdooModel",
    "OdooQuerySet",
    "OdooManager",
    "OdooRecord",
    "OdooRecordSet",
    "OdooError",
    "OdooAuthenticationError",
    "OdooRpcError",
    "OdooJson2Error",
    "OdooHttpError",
}


def _import_and_cache(module_name: str):
    from importlib import import_module

    module = import_module(_MODULE_EXPORTS[module_name], __name__)
    globals()[module_name] = module
    return module


def __getattr__(name):
    """Lazy import optional public helpers."""
    if name in _MODULE_EXPORTS:
        return _import_and_cache(name)

    if name in _ERP_EXPORTS:
        from .erp import Model, fields, setup, use_storage

        exports = {
            "Model": Model,
            "fields": fields,
            "setup": setup,
            "use_storage": use_storage,
        }
        globals().update(exports)
        return exports[name]

    if name in _PIPELINE_EXPORTS:
        from .pipeline import (
            BasePipeline,
            BaseStep,
            FunctionStep,
            Pipeline,
            PipelineContext,
            PipelineStatus,
            StepOutcome,
        )

        exports = {
            "Pipeline": Pipeline,
            "BasePipeline": BasePipeline,
            "BaseStep": BaseStep,
            "FunctionStep": FunctionStep,
            "PipelineContext": PipelineContext,
            "PipelineStatus": PipelineStatus,
            "StepOutcome": StepOutcome,
        }
        globals().update(exports)
        return exports[name]

    if name in _DATATABLE_EXPORTS:
        from .datatable import (
            DatabaseConnector,
            DataTable,
            db_connector,
            from_factory,
            from_faker,
            from_maria_db,
            from_mysql_db,
            from_oracle_db,
            from_postgres_db,
            from_sql,
            from_sqlite_db,
        )

        exports = {
            "DataTable": DataTable,
            "df": DataTable,
            "DatabaseConnector": DatabaseConnector,
            "db_connector": db_connector,
            "from_sql": from_sql,
            "from_mysql_db": from_mysql_db,
            "from_maria_db": from_maria_db,
            "from_oracle_db": from_oracle_db,
            "from_postgres_db": from_postgres_db,
            "from_sqlite_db": from_sqlite_db,
            "from_faker": from_faker,
            "from_factory": from_factory,
        }
        globals().update(exports)
        return exports[name]

    if name in _CONFIG_EXPORTS:
        from .config import (
            ConfigStore,
            default_config,
            delete_account,
            get_account,
            get_accounts,
            load_config,
            resolve_config_path,
            save_config,
            upsert_account,
        )

        exports = {
            "ConfigStore": ConfigStore,
            "default_config": default_config,
            "load_config": load_config,
            "save_config": save_config,
            "resolve_config_path": resolve_config_path,
            "get_accounts": get_accounts,
            "get_account": get_account,
            "upsert_account": upsert_account,
            "delete_account": delete_account,
        }
        globals().update(exports)
        return exports[name]

    if name in _ODOO_EXPORTS:
        from .odoo_client import (
            OdooAuthenticationError,
            OdooClient,
            OdooConnectionInfo,
            OdooEnv,
            OdooError,
            OdooHttpError,
            OdooJson2Error,
            OdooManager,
            OdooModel,
            OdooQuerySet,
            OdooRecord,
            OdooRecordSet,
            OdooRpcError,
        )

        exports = {
            "OdooClient": OdooClient,
            "OdooConnectionInfo": OdooConnectionInfo,
            "OdooEnv": OdooEnv,
            "OdooModel": OdooModel,
            "OdooQuerySet": OdooQuerySet,
            "OdooManager": OdooManager,
            "OdooRecord": OdooRecord,
            "OdooRecordSet": OdooRecordSet,
            "OdooError": OdooError,
            "OdooAuthenticationError": OdooAuthenticationError,
            "OdooRpcError": OdooRpcError,
            "OdooJson2Error": OdooJson2Error,
            "OdooHttpError": OdooHttpError,
        }
        globals().update(exports)
        return exports[name]

    if name == "Tester":
        from .tester import Tester

        globals()["Tester"] = Tester
        return Tester

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(__all__))
