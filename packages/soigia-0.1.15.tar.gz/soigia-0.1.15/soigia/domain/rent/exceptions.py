"""Exceptions for rent workflows."""

from __future__ import annotations


class RentDomainError(Exception):
    """Base error for rent failures."""


class InvalidRentalContractError(RentDomainError, ValueError):
    """Raised when a rental contract is invalid."""


class InvalidRentalPlanError(RentDomainError, ValueError):
    """Raised when a rental plan is invalid."""


class InvalidRentalTransitionError(RentDomainError, ValueError):
    """Raised when a rental transition is invalid."""
