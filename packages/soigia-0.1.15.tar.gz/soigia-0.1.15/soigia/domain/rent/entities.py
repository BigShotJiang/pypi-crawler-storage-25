"""Rent domain entities."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

from ..common.entities import Customer, Product
from ..common.value_objects import Money, Quantity
from ..inventory.entities import InventoryLocation
from ..inventory.services import InventoryService
from ..purchases.entities import PurchaseOrder
from ..sales.entities import SalesOrder, SalesOrderLine
from .enums import RentalState
from .exceptions import InvalidRentalContractError, InvalidRentalPlanError, InvalidRentalTransitionError
from .value_objects import RentalCode, RentalPeriod


@dataclass(frozen=True)
class RentalPlan:
    name: str
    rental_period: RentalPeriod
    daily_rate_multiplier: Decimal = Decimal("1")
    deposit_rate: Decimal = Decimal("0.20")

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise InvalidRentalPlanError("plan name cannot be empty")
        if not isinstance(self.rental_period, RentalPeriod):
            raise InvalidRentalPlanError("rental_period must be a RentalPeriod instance")
        if isinstance(self.daily_rate_multiplier, bool) or not isinstance(self.daily_rate_multiplier, Decimal):
            raise InvalidRentalPlanError("daily_rate_multiplier must be a Decimal")
        if self.daily_rate_multiplier <= 0:
            raise InvalidRentalPlanError("daily_rate_multiplier must be greater than zero")
        if isinstance(self.deposit_rate, bool) or not isinstance(self.deposit_rate, Decimal):
            raise InvalidRentalPlanError("deposit_rate must be a Decimal")
        if self.deposit_rate < 0 or self.deposit_rate > 1:
            raise InvalidRentalPlanError("deposit_rate must be between 0 and 1")


@dataclass(frozen=True)
class RentalLine:
    product: Product
    quantity: Quantity
    daily_rate: Money
    deposit_rate: Decimal = Decimal("0")

    def __post_init__(self) -> None:
        if not isinstance(self.product, Product):
            raise InvalidRentalContractError("product must be a Product instance")
        if not isinstance(self.quantity, Quantity):
            raise InvalidRentalContractError("quantity must be a Quantity instance")
        if not isinstance(self.daily_rate, Money):
            raise InvalidRentalContractError("daily_rate must be a Money instance")
        if isinstance(self.deposit_rate, bool) or not isinstance(self.deposit_rate, Decimal):
            raise InvalidRentalContractError("deposit_rate must be a Decimal")
        if self.deposit_rate < 0 or self.deposit_rate > 1:
            raise InvalidRentalContractError("deposit_rate must be between 0 and 1")

    def subtotal(self, days: int) -> Money:
        return self.daily_rate.scaled_by(self.quantity.amount * days)

    def deposit(self, days: int) -> Money:
        return self.subtotal(days).percentage(self.deposit_rate)

    def total(self, days: int) -> Money:
        return self.subtotal(days) + self.deposit(days)


@dataclass
class RentalContract:
    code: RentalCode
    customer: Customer
    plan: RentalPlan
    start_date: date
    end_date: date
    state: RentalState = RentalState.DRAFT
    lines: list[RentalLine] = field(default_factory=list)
    sales_order: SalesOrder | None = None
    purchase_order: PurchaseOrder | None = None
    stock_location: InventoryLocation | None = None
    metadata: dict[str, object] = field(default_factory=dict)
    reserved: bool = False
    closed_at: date | None = None
    canceled_reason: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.code, RentalCode):
            raise InvalidRentalContractError("code must be a RentalCode instance")
        if not isinstance(self.customer, Customer):
            raise InvalidRentalContractError("customer must be a Customer instance")
        if not isinstance(self.plan, RentalPlan):
            raise InvalidRentalContractError("plan must be a RentalPlan instance")
        if not isinstance(self.start_date, date) or not isinstance(self.end_date, date):
            raise InvalidRentalContractError("start_date and end_date must be dates")
        if self.end_date <= self.start_date:
            raise InvalidRentalContractError("end_date must be after start_date")
        if not isinstance(self.state, RentalState):
            raise InvalidRentalContractError("invalid rental state")
        if any(not isinstance(line, RentalLine) for line in self.lines):
            raise InvalidRentalContractError("lines must contain RentalLine instances")
        if self.sales_order is not None and not isinstance(self.sales_order, SalesOrder):
            raise InvalidRentalContractError("sales_order must be a SalesOrder instance or None")
        if self.purchase_order is not None and not isinstance(self.purchase_order, PurchaseOrder):
            raise InvalidRentalContractError("purchase_order must be a PurchaseOrder instance or None")
        if self.stock_location is not None and not isinstance(self.stock_location, InventoryLocation):
            raise InvalidRentalContractError("stock_location must be an InventoryLocation instance or None")
        if not isinstance(self.reserved, bool):
            raise InvalidRentalContractError("reserved must be a boolean")
        if self.closed_at is not None and not isinstance(self.closed_at, date):
            raise InvalidRentalContractError("closed_at must be a date or None")
        if self.canceled_reason is not None and (not isinstance(self.canceled_reason, str) or not self.canceled_reason.strip()):
            raise InvalidRentalContractError("canceled_reason must be a non-empty string when provided")

    @property
    def rental_days(self) -> int:
        return (self.end_date - self.start_date).days

    def add_line(
        self,
        product: Product,
        quantity: Quantity,
        *,
        daily_rate: Money,
        deposit_rate: Decimal | None = None,
    ) -> RentalLine:
        self._ensure_editable()
        line = RentalLine(
            product=product,
            quantity=quantity,
            daily_rate=daily_rate,
            deposit_rate=self.plan.deposit_rate if deposit_rate is None else deposit_rate,
        )
        self.lines.append(line)
        return line

    @property
    def subtotal(self) -> Money:
        if not self.lines:
            return Money.zero()
        total = Money.zero()
        for line in self.lines:
            total = total + line.subtotal(self.rental_days)
        return total

    @property
    def deposit(self) -> Money:
        if not self.lines:
            return Money.zero()
        total = Money.zero()
        for line in self.lines:
            total = total + line.deposit(self.rental_days)
        return total

    @property
    def total(self) -> Money:
        return self.subtotal + self.deposit

    def reserve_inventory(self, inventory_service: InventoryService) -> None:
        if not isinstance(inventory_service, InventoryService):
            raise InvalidRentalContractError("inventory_service must be an InventoryService instance")
        if self.stock_location is None:
            raise InvalidRentalContractError("stock_location is required to reserve inventory")
        for line in self.lines:
            inventory_service.ledger.reserve(line.product, self.stock_location, line.quantity)
        self.reserved = True
        self.state = RentalState.RESERVED

    def activate(self) -> None:
        self._transition({RentalState.DRAFT, RentalState.RESERVED}, RentalState.ACTIVE)

    def mark_overdue(self) -> None:
        self._transition({RentalState.ACTIVE}, RentalState.OVERDUE)

    def close(self, closed_at: date | None = None) -> None:
        self._transition({RentalState.ACTIVE, RentalState.OVERDUE}, RentalState.CLOSED)
        self.closed_at = closed_at or date.today()

    def cancel(self, reason: str) -> None:
        if not isinstance(reason, str) or not reason.strip():
            raise InvalidRentalContractError("cancel reason must be a non-empty string")
        self.canceled_reason = reason.strip()
        if self.state == RentalState.CLOSED:
            raise InvalidRentalTransitionError("closed contracts cannot be canceled")
        self.state = RentalState.CANCELED

    def to_sales_order(self) -> SalesOrder:
        order = SalesOrder(customer=self.customer, name=f"Rental {self.code.value}")
        for line in self.lines:
            order.add_line(line.product, line.quantity, unit_price=line.daily_rate, discount_rate=Decimal("0"))
        return order

    def _transition(self, allowed_from: set[RentalState], target_state: RentalState) -> None:
        if self.state not in allowed_from:
            raise InvalidRentalTransitionError(f"cannot move rental from {self.state.value} to {target_state.value}")
        self.state = target_state

    def _ensure_editable(self) -> None:
        if self.state in {RentalState.CANCELED, RentalState.CLOSED}:
            raise InvalidRentalContractError("rental contract is closed")
