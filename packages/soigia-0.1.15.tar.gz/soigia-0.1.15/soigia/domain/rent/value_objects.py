"""Rent domain value objects."""

from __future__ import annotations

import re
from dataclasses import dataclass

from .exceptions import InvalidRentalContractError, InvalidRentalPlanError

_CODE_PATTERN = re.compile(r"^[A-Z0-9][A-Z0-9_-]{1,31}$")


@dataclass(frozen=True)
class RentalCode:
    value: str

    def __post_init__(self) -> None:
        if not isinstance(self.value, str):
            raise InvalidRentalContractError("rental code must be a string")
        code = self.value.strip().upper()
        if not _CODE_PATTERN.fullmatch(code):
            raise InvalidRentalContractError("rental code must be 2-32 chars of A-Z, 0-9, _ or -")
        object.__setattr__(self, "value", code)


@dataclass(frozen=True)
class RentalPeriod:
    days: int

    def __post_init__(self) -> None:
        if isinstance(self.days, bool) or not isinstance(self.days, int):
            raise InvalidRentalPlanError("rental period must be an integer")
        if self.days <= 0:
            raise InvalidRentalPlanError("rental period must be greater than zero")
