"""Rent domain enums."""

from __future__ import annotations

from enum import Enum


class RentalState(str, Enum):
    DRAFT = "draft"
    RESERVED = "reserved"
    ACTIVE = "active"
    OVERDUE = "overdue"
    CLOSED = "closed"
    CANCELED = "canceled"
