from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from ..common.entities import Customer, Product
from ..common.value_objects import Money, Quantity, SKU
from ..inventory.entities import InventoryLocation
from ..inventory.enums import InventoryLocationUsage
from ..inventory.services import InventoryService
from ..purchases.entities import PurchaseOrder, Supplier
from ..sales.entities import SalesOrder
from . import (
    DefaultRentalPolicy,
    InvalidRentalContractError,
    InvalidRentalPlanError,
    InvalidRentalTransitionError,
    RentalCode,
    RentalContract,
    RentalPlan,
    RentalPricingService,
    RentalState,
    RentalWorkflowService,
    RentalPeriod,
)


def test_rental_value_objects_and_plan_validate() -> None:
    assert RentalCode("rent-001").value == "RENT-001"
    assert RentalPeriod(7).days == 7

    with pytest.raises(InvalidRentalContractError):
        RentalCode(" ")

    with pytest.raises(InvalidRentalPlanError):
        RentalPeriod(0)


def test_rental_creates_from_sales_and_purchase_context_and_reserves_inventory() -> None:
    customer = Customer(name="Acme")
    product = Product(sku=SKU("SKU-R-01"), name="Projector", price=Money(Decimal("1500000")), stock_qty=3)
    sales_order = SalesOrder(customer=customer, name="Rental quote")
    sales_order.add_line(product, Quantity(1), unit_price=Money(Decimal("120000")))
    purchase_order = PurchaseOrder(supplier=Supplier(name="Vendor"))
    plan = RentalPlan(name="Weekly", rental_period=RentalPeriod(7), deposit_rate=Decimal("0.25"))
    stock_location = InventoryLocation(code="WH/Stock", name="Stock", usage=InventoryLocationUsage.INTERNAL)
    inventory = InventoryService()
    inventory.ledger.increase(product, stock_location, 3)

    service = RentalWorkflowService()
    contract = service.create(
        "rent-001",
        plan,
        customer=customer,
        start_date=date(2026, 4, 4),
        end_date=date(2026, 4, 11),
        stock_location=stock_location,
        sales_order=sales_order,
        purchase_order=purchase_order,
    )
    service.reserve(contract, inventory)
    service.activate(contract)

    assert contract.state == RentalState.ACTIVE
    assert contract.reserved is True
    assert contract.purchase_order == purchase_order
    assert contract.subtotal == Money(Decimal("840000"))
    assert contract.deposit == Money(Decimal("210000"))
    assert contract.total == Money(Decimal("1050000"))


def test_rental_mark_overdue_close_and_billing_preview() -> None:
    customer = Customer(name="Beta")
    product = Product(sku=SKU("SKU-R-02"), name="Speaker", price=Money(Decimal("500000")), stock_qty=2)
    plan = RentalPlan(name="Daily", rental_period=RentalPeriod(1), deposit_rate=Decimal("0.10"))
    contract = RentalContract(
        code=RentalCode("RENT-100"),
        customer=customer,
        plan=plan,
        start_date=date(2026, 4, 4),
        end_date=date(2026, 4, 7),
    )
    contract.add_line(product, Quantity(1), daily_rate=Money(Decimal("50000")))

    service = RentalWorkflowService()
    service.activate(contract)
    service.mark_overdue(contract)
    service.close(contract, closed_at=date(2026, 4, 8))

    preview = service.bill_preview(contract, on_date=date(2026, 4, 8))
    assert contract.state == RentalState.CLOSED
    assert preview["subtotal"] == Money(Decimal("150000"))
    assert preview["deposit"] == Money(Decimal("15000"))
    assert preview["total"] == Money(Decimal("165000"))


def test_rental_policy_blocks_invalid_transitions() -> None:
    plan = RentalPlan(name="Monthly", rental_period=RentalPeriod(30))
    contract = RentalContract(
        code=RentalCode("RENT-200"),
        customer=Customer(name="Gamma"),
        plan=plan,
        start_date=date(2026, 4, 4),
        end_date=date(2026, 5, 4),
    )
    policy = DefaultRentalPolicy()

    assert policy.can_activate(contract) is True
    assert policy.can_close(contract) is False

    contract.state = RentalState.CLOSED
    assert policy.can_cancel(contract) is False

    with pytest.raises(InvalidRentalTransitionError):
        contract.mark_overdue()


def test_rental_rejects_closed_contract_edits() -> None:
    plan = RentalPlan(name="Monthly", rental_period=RentalPeriod(30))
    contract = RentalContract(
        code=RentalCode("RENT-300"),
        customer=Customer(name="Delta"),
        plan=plan,
        start_date=date(2026, 4, 4),
        end_date=date(2026, 5, 4),
    )
    contract.cancel("customer request")

    with pytest.raises(InvalidRentalContractError):
        contract.add_line(
            Product(sku=SKU("SKU-R-03"), name="Mixer", price=Money(Decimal("300000")), stock_qty=1),
            Quantity(1),
            daily_rate=Money(Decimal("10000")),
        )
