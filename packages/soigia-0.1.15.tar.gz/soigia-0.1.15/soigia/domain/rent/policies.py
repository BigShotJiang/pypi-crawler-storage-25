"""Policies for rent workflows."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from .entities import RentalContract
from .enums import RentalState


class RentalPolicy(Protocol):
    def can_activate(self, contract: RentalContract) -> bool: ...
    def can_close(self, contract: RentalContract) -> bool: ...
    def can_cancel(self, contract: RentalContract) -> bool: ...
    def can_mark_overdue(self, contract: RentalContract) -> bool: ...


@dataclass(frozen=True)
class DefaultRentalPolicy:
    def can_activate(self, contract: RentalContract) -> bool:
        if not isinstance(contract, RentalContract):
            raise TypeError("contract must be a RentalContract instance")
        return contract.state in {RentalState.DRAFT, RentalState.RESERVED}

    def can_close(self, contract: RentalContract) -> bool:
        if not isinstance(contract, RentalContract):
            raise TypeError("contract must be a RentalContract instance")
        return contract.state in {RentalState.ACTIVE, RentalState.OVERDUE}

    def can_cancel(self, contract: RentalContract) -> bool:
        if not isinstance(contract, RentalContract):
            raise TypeError("contract must be a RentalContract instance")
        return contract.state != RentalState.CLOSED

    def can_mark_overdue(self, contract: RentalContract) -> bool:
        if not isinstance(contract, RentalContract):
            raise TypeError("contract must be a RentalContract instance")
        return contract.state == RentalState.ACTIVE
