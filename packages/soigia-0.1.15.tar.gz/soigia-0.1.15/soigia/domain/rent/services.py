"""Services for rent workflows."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from ..common.value_objects import Money
from ..inventory.entities import InventoryLocation
from ..inventory.services import InventoryService
from ..purchases.entities import PurchaseOrder
from ..sales.entities import SalesOrder
from .entities import RentalContract, RentalLine, RentalPlan
from .enums import RentalState
from .exceptions import InvalidRentalContractError, InvalidRentalPlanError
from .policies import DefaultRentalPolicy, RentalPolicy
from .value_objects import RentalCode


@dataclass(frozen=True)
class RentalPricingService:
    def calculate_subtotal(self, contract: RentalContract) -> Money:
        return contract.subtotal

    def calculate_deposit(self, contract: RentalContract) -> Money:
        return contract.deposit

    def calculate_total(self, contract: RentalContract) -> Money:
        return contract.total


@dataclass
class RentalWorkflowService:
    policy: RentalPolicy = field(default_factory=DefaultRentalPolicy)
    pricing_service: RentalPricingService = field(default_factory=RentalPricingService)

    def create(
        self,
        code: str | RentalCode,
        plan: RentalPlan,
        *,
        customer,
        start_date: date,
        end_date: date,
        stock_location: InventoryLocation | None = None,
        sales_order: SalesOrder | None = None,
        purchase_order: PurchaseOrder | None = None,
    ) -> RentalContract:
        if isinstance(code, str):
            code = RentalCode(code)
        if not isinstance(code, RentalCode):
            raise InvalidRentalContractError("code must be a RentalCode instance or string")
        if not isinstance(plan, RentalPlan):
            raise InvalidRentalPlanError("plan must be a RentalPlan instance")
        contract = RentalContract(
            code=code,
            customer=customer,
            plan=plan,
            start_date=start_date,
            end_date=end_date,
            stock_location=stock_location,
            sales_order=sales_order,
            purchase_order=purchase_order,
        )
        if sales_order is not None:
            for line in sales_order.lines:
                contract.lines.append(
                    RentalLine(
                        product=line.product,
                        quantity=line.quantity,
                        daily_rate=Money(line.discounted_unit_price.amount * plan.daily_rate_multiplier),
                        deposit_rate=plan.deposit_rate,
                    )
                )
        return contract

    def reserve(self, contract: RentalContract, inventory_service: InventoryService) -> RentalContract:
        if not isinstance(contract, RentalContract):
            raise InvalidRentalContractError("contract must be a RentalContract instance")
        contract.reserve_inventory(inventory_service)
        return contract

    def activate(self, contract: RentalContract) -> RentalContract:
        if not isinstance(contract, RentalContract):
            raise InvalidRentalContractError("contract must be a RentalContract instance")
        if not self.policy.can_activate(contract):
            raise InvalidRentalContractError("contract cannot be activated")
        contract.activate()
        return contract

    def mark_overdue(self, contract: RentalContract) -> RentalContract:
        if not isinstance(contract, RentalContract):
            raise InvalidRentalContractError("contract must be a RentalContract instance")
        if not self.policy.can_mark_overdue(contract):
            raise InvalidRentalContractError("contract cannot be marked overdue")
        contract.mark_overdue()
        return contract

    def close(self, contract: RentalContract, closed_at: date | None = None) -> RentalContract:
        if not isinstance(contract, RentalContract):
            raise InvalidRentalContractError("contract must be a RentalContract instance")
        if not self.policy.can_close(contract):
            raise InvalidRentalContractError("contract cannot be closed")
        contract.close(closed_at=closed_at)
        return contract

    def cancel(self, contract: RentalContract, reason: str) -> RentalContract:
        if not isinstance(contract, RentalContract):
            raise InvalidRentalContractError("contract must be a RentalContract instance")
        if not self.policy.can_cancel(contract):
            raise InvalidRentalContractError("contract cannot be canceled")
        contract.cancel(reason)
        return contract

    def bill_preview(self, contract: RentalContract, on_date: date | None = None) -> dict[str, object]:
        if not isinstance(contract, RentalContract):
            raise InvalidRentalContractError("contract must be a RentalContract instance")
        on_date = on_date or date.today()
        return {
            "code": contract.code.value,
            "customer": contract.customer.name,
            "state": contract.state,
            "invoice_date": on_date,
            "subtotal": self.pricing_service.calculate_subtotal(contract),
            "deposit": self.pricing_service.calculate_deposit(contract),
            "total": self.pricing_service.calculate_total(contract),
        }
