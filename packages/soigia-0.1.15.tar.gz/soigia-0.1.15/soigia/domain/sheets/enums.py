"""Spreadsheet domain enums."""

from __future__ import annotations

from enum import Enum


class CellDataType(str, Enum):
    TEXT = "text"
    NUMBER = "number"
    BOOLEAN = "boolean"
    DATE = "date"
    EMPTY = "empty"


class SortDirection(str, Enum):
    ASC = "asc"
    DESC = "desc"


class SyncMode(str, Enum):
    APPEND = "append"
    UPSERT = "upsert"
    REPLACE = "replace"
