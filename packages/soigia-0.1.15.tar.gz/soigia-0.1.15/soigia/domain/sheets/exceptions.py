"""Exceptions for the spreadsheet domain."""

from __future__ import annotations


class SheetsError(Exception):
    """Base error for spreadsheet workflows."""


class InvalidSpreadsheetError(SheetsError, ValueError):
    """Raised when a spreadsheet is invalid."""


class InvalidSheetError(SheetsError, ValueError):
    """Raised when a sheet is invalid."""


class DuplicateSheetError(SheetsError, ValueError):
    """Raised when a sheet name already exists."""


class InvalidCellAddressError(SheetsError, ValueError):
    """Raised when a cell address cannot be parsed or used."""


class InvalidRowError(SheetsError, ValueError):
    """Raised when a row is invalid."""
