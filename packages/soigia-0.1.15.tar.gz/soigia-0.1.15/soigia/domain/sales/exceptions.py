"""Sales domain exceptions."""

from __future__ import annotations


class SalesError(Exception):
    """Base class for sales domain errors."""


class InvalidSalesOrderError(SalesError, ValueError):
    """Raised when a sales order is invalid."""


class InvalidSalesOrderLineError(SalesError, ValueError):
    """Raised when a sales order line is invalid."""


class InvalidSalesTransitionError(SalesError, ValueError):
    """Raised when a sales order transition is invalid."""
