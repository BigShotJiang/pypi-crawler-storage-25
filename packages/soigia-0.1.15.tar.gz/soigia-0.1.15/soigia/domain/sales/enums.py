"""Sales domain enums."""

from __future__ import annotations

from enum import Enum


class SalesOrderState(str, Enum):
    """Sales order lifecycle state."""

    QUOTATION = "quotation"
    SENT = "sent"
    SALE = "sale"
    DONE = "done"
    CANCELLED = "cancelled"
