"""CRM domain exceptions."""

from __future__ import annotations


class CrmError(Exception):
    """Base class for CRM domain errors."""


class InvalidContactError(CrmError, ValueError):
    """Raised when a CRM contact is invalid."""


class InvalidLeadError(CrmError, ValueError):
    """Raised when a CRM lead is invalid."""


class InvalidStageError(CrmError, ValueError):
    """Raised when a CRM stage is invalid."""


class InvalidActivityError(CrmError, ValueError):
    """Raised when a CRM activity is invalid."""


class InvalidEmailError(CrmError, ValueError):
    """Raised when an email address is invalid."""


class InvalidPhoneError(CrmError, ValueError):
    """Raised when a phone number is invalid."""


class InvalidLeadScoreError(CrmError, ValueError):
    """Raised when a lead score is invalid."""


class InvalidTransitionError(CrmError, ValueError):
    """Raised when a workflow transition is not allowed."""
