"""CRM enums."""

from __future__ import annotations

from enum import Enum


class LeadType(str, Enum):
    """Lead classification."""

    LEAD = "lead"
    OPPORTUNITY = "opportunity"


class LeadState(str, Enum):
    """Lead lifecycle state."""

    NEW = "new"
    QUALIFIED = "qualified"
    WON = "won"
    LOST = "lost"


class LeadPriority(str, Enum):
    """Lead priority."""

    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    VERY_HIGH = "very_high"


class ActivityState(str, Enum):
    """Activity execution state."""

    PLANNED = "planned"
    DONE = "done"
    CANCELLED = "cancelled"
