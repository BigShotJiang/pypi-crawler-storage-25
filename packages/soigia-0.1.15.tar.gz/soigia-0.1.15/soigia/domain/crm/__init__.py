"""Pure CRM domain for lead and opportunity management."""

from .enums import ActivityState, LeadPriority, LeadState, LeadType
from .entities import Activity, Contact, Lead, Stage
from .exceptions import (
    CrmError,
    InvalidActivityError,
    InvalidContactError,
    InvalidEmailError,
    InvalidLeadError,
    InvalidLeadScoreError,
    InvalidPhoneError,
    InvalidStageError,
    InvalidTransitionError,
)
from .policies import DefaultLeadStagePolicy, LeadStagePolicy
from .services import LeadScoringService, LeadWorkflowService
from .value_objects import EmailAddress, LeadScore, PhoneNumber

__all__ = [
    "ActivityState",
    "LeadPriority",
    "LeadState",
    "LeadType",
    "Activity",
    "Contact",
    "Lead",
    "Stage",
    "CrmError",
    "InvalidActivityError",
    "InvalidContactError",
    "InvalidEmailError",
    "InvalidLeadError",
    "InvalidLeadScoreError",
    "InvalidPhoneError",
    "InvalidStageError",
    "InvalidTransitionError",
    "DefaultLeadStagePolicy",
    "LeadStagePolicy",
    "LeadScoringService",
    "LeadWorkflowService",
    "EmailAddress",
    "LeadScore",
    "PhoneNumber",
]
