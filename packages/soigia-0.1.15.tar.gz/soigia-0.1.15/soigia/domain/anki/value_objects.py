"""Anki domain value objects."""

from __future__ import annotations

from dataclasses import dataclass

from .exceptions import InvalidCardError, InvalidDeckError, InvalidTagError


def _normalize_text(value: str, *, error_cls: type[Exception], field_name: str) -> str:
    if not isinstance(value, str):
        raise error_cls(f"{field_name} must be a string")
    normalized = value.strip()
    if not normalized:
        raise error_cls(f"{field_name} cannot be empty")
    return normalized


@dataclass(frozen=True)
class DeckName:
    value: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "value", _normalize_text(self.value, error_cls=InvalidDeckError, field_name="deck name")
        )


@dataclass(frozen=True)
class CardText:
    value: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "value", _normalize_text(self.value, error_cls=InvalidCardError, field_name="card text")
        )


@dataclass(frozen=True)
class Tag:
    value: str

    def __post_init__(self) -> None:
        normalized = _normalize_text(self.value, error_cls=InvalidTagError, field_name="tag")
        object.__setattr__(self, "value", normalized.lower())
