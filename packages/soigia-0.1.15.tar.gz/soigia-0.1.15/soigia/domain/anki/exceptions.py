"""Anki domain exceptions."""

from __future__ import annotations


class AnkiError(Exception):
    """Base class for Anki domain errors."""


class InvalidDeckError(AnkiError, ValueError):
    """Raised when a deck is invalid."""


class InvalidCardError(AnkiError, ValueError):
    """Raised when a card is invalid."""


class InvalidTagError(AnkiError, ValueError):
    """Raised when a tag is invalid."""


class InvalidReviewError(AnkiError, ValueError):
    """Raised when a review or rating is invalid."""
