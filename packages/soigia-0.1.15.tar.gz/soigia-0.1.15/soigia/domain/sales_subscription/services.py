"""Services for sales subscriptions."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from ..crm.entities import Lead
from ..sales.entities import SalesOrder
from .entities import Subscription, SubscriptionPlan
from .exceptions import InvalidSubscriptionError, InvalidSubscriptionPlanError
from .policies import DefaultSubscriptionPolicy, SubscriptionPolicy
from .value_objects import SubscriptionCode


@dataclass(frozen=True)
class SubscriptionBillingService:
    def calculate_recurring_amount(self, subscription: Subscription):
        if not isinstance(subscription, Subscription):
            raise InvalidSubscriptionError("subscription must be a Subscription instance")
        return subscription.recurring_amount

    def preview_invoice(self, subscription: Subscription, *, on_date: date | None = None) -> dict[str, object]:
        if not isinstance(subscription, Subscription):
            raise InvalidSubscriptionError("subscription must be a Subscription instance")
        on_date = on_date or date.today()
        return {
            "subscription_code": subscription.code.value,
            "customer": subscription.customer.name,
            "state": subscription.state,
            "invoice_date": on_date,
            "next_invoice_date": subscription.next_invoice_date,
            "amount": self.calculate_recurring_amount(subscription),
        }


@dataclass
class SubscriptionWorkflowService:
    policy: SubscriptionPolicy = field(default_factory=DefaultSubscriptionPolicy)
    billing_service: SubscriptionBillingService = field(default_factory=SubscriptionBillingService)

    def create(
        self,
        code: str | SubscriptionCode,
        plan: SubscriptionPlan,
        *,
        customer,
        lead: Lead | None = None,
        source_order: SalesOrder | None = None,
    ) -> Subscription:
        if isinstance(code, str):
            code = SubscriptionCode(code)
        if not isinstance(code, SubscriptionCode):
            raise InvalidSubscriptionError("code must be a SubscriptionCode instance or string")
        if not isinstance(plan, SubscriptionPlan):
            raise InvalidSubscriptionPlanError("plan must be a SubscriptionPlan instance")
        subscription = Subscription(code=code, customer=customer, plan=plan, lead=lead, source_order=source_order)
        if lead is not None and subscription.contact is None:
            subscription.contact = lead.contact
        if source_order is not None:
            for line in source_order.lines:
                subscription.lines.append(line)
        return subscription

    def activate(self, subscription: Subscription, on_date: date | None = None) -> Subscription:
        if not isinstance(subscription, Subscription):
            raise InvalidSubscriptionError("subscription must be a Subscription instance")
        if not self.policy.can_activate(subscription):
            raise InvalidSubscriptionError("subscription cannot be activated")
        subscription.activate(on_date=on_date)
        return subscription

    def pause(self, subscription: Subscription) -> Subscription:
        if not isinstance(subscription, Subscription):
            raise InvalidSubscriptionError("subscription must be a Subscription instance")
        if not self.policy.can_pause(subscription):
            raise InvalidSubscriptionError("subscription cannot be paused")
        subscription.pause()
        return subscription

    def resume(self, subscription: Subscription) -> Subscription:
        if not isinstance(subscription, Subscription):
            raise InvalidSubscriptionError("subscription must be a Subscription instance")
        if not self.policy.can_resume(subscription):
            raise InvalidSubscriptionError("subscription cannot be resumed")
        subscription.resume()
        return subscription

    def cancel(self, subscription: Subscription, reason: str) -> Subscription:
        if not isinstance(subscription, Subscription):
            raise InvalidSubscriptionError("subscription must be a Subscription instance")
        if not self.policy.can_cancel(subscription):
            raise InvalidSubscriptionError("subscription cannot be canceled")
        subscription.cancel(reason)
        return subscription

    def renew(self, subscription: Subscription, on_date: date | None = None) -> Subscription:
        if not isinstance(subscription, Subscription):
            raise InvalidSubscriptionError("subscription must be a Subscription instance")
        if not self.policy.can_renew(subscription):
            raise InvalidSubscriptionError("subscription cannot be renewed")
        subscription.renew(on_date=on_date)
        return subscription

    def from_sales_order(
        self,
        code: str | SubscriptionCode,
        plan: SubscriptionPlan,
        order: SalesOrder,
        *,
        lead: Lead | None = None,
    ) -> Subscription:
        if not isinstance(order, SalesOrder):
            raise InvalidSubscriptionError("order must be a SalesOrder instance")
        subscription = self.create(code, plan, customer=order.customer, lead=lead, source_order=order)
        return subscription

    def bill(self, subscription: Subscription, on_date: date | None = None) -> dict[str, object]:
        if not isinstance(subscription, Subscription):
            raise InvalidSubscriptionError("subscription must be a Subscription instance")
        return self.billing_service.preview_invoice(subscription, on_date=on_date)
