"""Sales subscription value objects."""

from __future__ import annotations

import re
from dataclasses import dataclass

from .exceptions import InvalidSubscriptionError, InvalidSubscriptionPlanError

_CODE_PATTERN = re.compile(r"^[A-Z0-9][A-Z0-9_-]{1,31}$")


@dataclass(frozen=True)
class SubscriptionCode:
    value: str

    def __post_init__(self) -> None:
        if not isinstance(self.value, str):
            raise InvalidSubscriptionError("subscription code must be a string")
        code = self.value.strip().upper()
        if not _CODE_PATTERN.fullmatch(code):
            raise InvalidSubscriptionError("subscription code must be 2-32 chars of A-Z, 0-9, _ or -")
        object.__setattr__(self, "value", code)


@dataclass(frozen=True)
class BillingInterval:
    months: int

    def __post_init__(self) -> None:
        if isinstance(self.months, bool) or not isinstance(self.months, int):
            raise InvalidSubscriptionPlanError("billing interval must be an integer")
        if self.months <= 0:
            raise InvalidSubscriptionPlanError("billing interval must be greater than zero")
