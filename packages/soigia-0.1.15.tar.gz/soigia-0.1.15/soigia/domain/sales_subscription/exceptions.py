"""Exceptions for sales subscriptions."""

from __future__ import annotations


class SalesSubscriptionError(Exception):
    """Base error for sales subscription failures."""


class InvalidSubscriptionError(SalesSubscriptionError, ValueError):
    """Raised when a subscription is invalid."""


class InvalidSubscriptionPlanError(SalesSubscriptionError, ValueError):
    """Raised when a subscription plan is invalid."""


class InvalidSubscriptionTransitionError(SalesSubscriptionError, ValueError):
    """Raised when a subscription transition is invalid."""
