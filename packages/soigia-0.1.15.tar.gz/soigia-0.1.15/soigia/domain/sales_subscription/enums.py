"""Sales subscription enums."""

from __future__ import annotations

from enum import Enum


class SubscriptionState(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    PAUSED = "paused"
    CANCELED = "canceled"
    EXPIRED = "expired"
