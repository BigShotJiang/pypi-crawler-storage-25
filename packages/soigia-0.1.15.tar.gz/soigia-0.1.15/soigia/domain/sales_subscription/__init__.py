"""Sales subscription domain built on sales and CRM primitives."""

from .entities import Subscription, SubscriptionPlan
from .enums import SubscriptionState
from .exceptions import (
    InvalidSubscriptionError,
    InvalidSubscriptionPlanError,
    InvalidSubscriptionTransitionError,
    SalesSubscriptionError,
)
from .policies import DefaultSubscriptionPolicy, SubscriptionPolicy
from .services import SubscriptionBillingService, SubscriptionWorkflowService
from .value_objects import BillingInterval, SubscriptionCode

__all__ = [
    "Subscription",
    "SubscriptionPlan",
    "SubscriptionState",
    "InvalidSubscriptionError",
    "InvalidSubscriptionPlanError",
    "InvalidSubscriptionTransitionError",
    "SalesSubscriptionError",
    "DefaultSubscriptionPolicy",
    "SubscriptionPolicy",
    "SubscriptionBillingService",
    "SubscriptionWorkflowService",
    "BillingInterval",
    "SubscriptionCode",
]
