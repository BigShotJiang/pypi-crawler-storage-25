"""Policies for sales subscriptions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from .entities import Subscription
from .enums import SubscriptionState


class SubscriptionPolicy(Protocol):
    def can_activate(self, subscription: Subscription) -> bool: ...
    def can_pause(self, subscription: Subscription) -> bool: ...
    def can_resume(self, subscription: Subscription) -> bool: ...
    def can_cancel(self, subscription: Subscription) -> bool: ...
    def can_renew(self, subscription: Subscription) -> bool: ...


@dataclass(frozen=True)
class DefaultSubscriptionPolicy:
    def can_activate(self, subscription: Subscription) -> bool:
        if not isinstance(subscription, Subscription):
            raise TypeError("subscription must be a Subscription instance")
        return subscription.state == SubscriptionState.DRAFT

    def can_pause(self, subscription: Subscription) -> bool:
        if not isinstance(subscription, Subscription):
            raise TypeError("subscription must be a Subscription instance")
        return subscription.state == SubscriptionState.ACTIVE

    def can_resume(self, subscription: Subscription) -> bool:
        if not isinstance(subscription, Subscription):
            raise TypeError("subscription must be a Subscription instance")
        return subscription.state == SubscriptionState.PAUSED

    def can_cancel(self, subscription: Subscription) -> bool:
        if not isinstance(subscription, Subscription):
            raise TypeError("subscription must be a Subscription instance")
        return subscription.state not in {SubscriptionState.CANCELED, SubscriptionState.EXPIRED}

    def can_renew(self, subscription: Subscription) -> bool:
        if not isinstance(subscription, Subscription):
            raise TypeError("subscription must be a Subscription instance")
        return subscription.state in {SubscriptionState.ACTIVE, SubscriptionState.PAUSED}
