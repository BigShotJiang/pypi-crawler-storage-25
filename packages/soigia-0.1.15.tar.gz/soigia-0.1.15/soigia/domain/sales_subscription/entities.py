"""Sales subscription entities."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal

from ..common.entities import Customer, Product
from ..common.value_objects import Money, Quantity
from ..crm.entities import Contact, Lead
from ..sales.entities import SalesOrder, SalesOrderLine
from .enums import SubscriptionState
from .exceptions import InvalidSubscriptionError, InvalidSubscriptionPlanError, InvalidSubscriptionTransitionError
from .value_objects import BillingInterval, SubscriptionCode


@dataclass(frozen=True)
class SubscriptionPlan:
    name: str
    billing_interval: BillingInterval
    recurring_price: Money
    trial_days: int = 0
    auto_renew: bool = True

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise InvalidSubscriptionPlanError("plan name cannot be empty")
        if not isinstance(self.billing_interval, BillingInterval):
            raise InvalidSubscriptionPlanError("billing_interval must be a BillingInterval instance")
        if not isinstance(self.recurring_price, Money):
            raise InvalidSubscriptionPlanError("recurring_price must be a Money instance")
        if isinstance(self.trial_days, bool) or not isinstance(self.trial_days, int) or self.trial_days < 0:
            raise InvalidSubscriptionPlanError("trial_days must be a non-negative integer")
        if not isinstance(self.auto_renew, bool):
            raise InvalidSubscriptionPlanError("auto_renew must be a boolean")

    @property
    def recurring_period_days(self) -> int:
        return self.billing_interval.months * 30


@dataclass
class Subscription:
    code: SubscriptionCode
    customer: Customer
    plan: SubscriptionPlan
    state: SubscriptionState = SubscriptionState.DRAFT
    start_date: date = field(default_factory=date.today)
    next_invoice_date: date | None = None
    lead: Lead | None = None
    contact: Contact | None = None
    source_order: SalesOrder | None = None
    lines: list[SalesOrderLine] = field(default_factory=list)
    canceled_reason: str | None = None
    renewal_count: int = 0
    metadata: dict[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.code, SubscriptionCode):
            raise InvalidSubscriptionError("code must be a SubscriptionCode instance")
        if not isinstance(self.customer, Customer):
            raise InvalidSubscriptionError("customer must be a Customer instance")
        if not isinstance(self.plan, SubscriptionPlan):
            raise InvalidSubscriptionError("plan must be a SubscriptionPlan instance")
        if not isinstance(self.state, SubscriptionState):
            raise InvalidSubscriptionError("invalid subscription state")
        if not isinstance(self.start_date, date):
            raise InvalidSubscriptionError("start_date must be a date")
        if self.next_invoice_date is not None and not isinstance(self.next_invoice_date, date):
            raise InvalidSubscriptionError("next_invoice_date must be a date or None")
        if self.lead is not None and not isinstance(self.lead, Lead):
            raise InvalidSubscriptionError("lead must be a Lead instance or None")
        if self.contact is not None and not isinstance(self.contact, Contact):
            raise InvalidSubscriptionError("contact must be a Contact instance or None")
        if self.source_order is not None and not isinstance(self.source_order, SalesOrder):
            raise InvalidSubscriptionError("source_order must be a SalesOrder instance or None")
        if any(not isinstance(line, SalesOrderLine) for line in self.lines):
            raise InvalidSubscriptionError("lines must contain SalesOrderLine instances")
        if self.canceled_reason is not None and (not isinstance(self.canceled_reason, str) or not self.canceled_reason.strip()):
            raise InvalidSubscriptionError("canceled_reason must be a non-empty string when provided")
        if isinstance(self.renewal_count, bool) or not isinstance(self.renewal_count, int) or self.renewal_count < 0:
            raise InvalidSubscriptionError("renewal_count must be a non-negative integer")

    def add_line(
        self,
        product: Product,
        quantity: Quantity,
        *,
        unit_price: Money | None = None,
        discount_rate: Decimal = Decimal("0"),
    ) -> SalesOrderLine:
        self._ensure_editable()
        line = SalesOrderLine(product=product, quantity=quantity, unit_price=unit_price, discount_rate=discount_rate)
        self.lines.append(line)
        return line

    @property
    def recurring_amount(self) -> Money:
        total = Money.zero()
        if not self.lines:
            return self.plan.recurring_price
        for line in self.lines:
            total = total + line.total
        return total

    def activate(self, *, on_date: date | None = None) -> None:
        self._transition(SubscriptionState.ACTIVE)
        on_date = on_date or self.start_date
        self.next_invoice_date = on_date + timedelta(days=self.plan.trial_days + self.plan.recurring_period_days)

    def pause(self) -> None:
        self._transition(SubscriptionState.PAUSED)

    def resume(self) -> None:
        self._transition(SubscriptionState.ACTIVE)

    def cancel(self, reason: str) -> None:
        if not isinstance(reason, str) or not reason.strip():
            raise InvalidSubscriptionError("cancel reason must be a non-empty string")
        self.canceled_reason = reason.strip()
        self._transition(SubscriptionState.CANCELED)

    def expire(self) -> None:
        self._transition(SubscriptionState.EXPIRED)

    def renew(self, *, on_date: date | None = None) -> None:
        if self.state not in {SubscriptionState.ACTIVE, SubscriptionState.PAUSED}:
            raise InvalidSubscriptionTransitionError("only active or paused subscriptions can be renewed")
        on_date = on_date or date.today()
        self.renewal_count += 1
        self.next_invoice_date = on_date + timedelta(days=self.plan.recurring_period_days)

    def create_sales_order(self) -> SalesOrder:
        order = SalesOrder(customer=self.customer, name=f"Subscription {self.code.value}")
        for line in self.lines:
            order.add_line(
                line.product,
                line.quantity,
                unit_price=line.unit_price,
                discount_rate=line.discount_rate,
            )
        return order

    def _transition(self, target_state: SubscriptionState) -> None:
        allowed = {
            SubscriptionState.DRAFT: {SubscriptionState.ACTIVE, SubscriptionState.CANCELED},
            SubscriptionState.ACTIVE: {SubscriptionState.PAUSED, SubscriptionState.CANCELED, SubscriptionState.EXPIRED},
            SubscriptionState.PAUSED: {SubscriptionState.ACTIVE, SubscriptionState.CANCELED, SubscriptionState.EXPIRED},
            SubscriptionState.CANCELED: set(),
            SubscriptionState.EXPIRED: {SubscriptionState.CANCELED},
        }
        if target_state not in allowed[self.state]:
            raise InvalidSubscriptionTransitionError(f"cannot move subscription from {self.state.value} to {target_state.value}")
        self.state = target_state

    def _ensure_editable(self) -> None:
        if self.state in {SubscriptionState.CANCELED, SubscriptionState.EXPIRED}:
            raise InvalidSubscriptionError("subscription is closed")
