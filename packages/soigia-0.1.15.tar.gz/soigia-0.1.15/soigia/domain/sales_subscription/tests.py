from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from ..common.entities import Customer, Product
from ..common.value_objects import Money, Quantity, SKU
from ..crm.entities import Contact, Lead, Stage
from ..crm.enums import LeadPriority, LeadType
from ..crm.value_objects import EmailAddress, PhoneNumber
from ..sales.entities import SalesOrder
from . import (
    BillingInterval,
    DefaultSubscriptionPolicy,
    InvalidSubscriptionError,
    InvalidSubscriptionPlanError,
    InvalidSubscriptionTransitionError,
    Subscription,
    SubscriptionBillingService,
    SubscriptionCode,
    SubscriptionPlan,
    SubscriptionState,
    SubscriptionWorkflowService,
)


def test_subscription_value_objects_and_plan_validate() -> None:
    assert SubscriptionCode("sub-001").value == "SUB-001"
    assert BillingInterval(1).months == 1

    with pytest.raises(InvalidSubscriptionError):
        SubscriptionCode(" ")

    with pytest.raises(InvalidSubscriptionPlanError):
        BillingInterval(0)


def test_subscription_created_from_sales_order_and_crm_context() -> None:
    customer = Customer(name="Acme")
    product = Product(sku=SKU("SKU-SUB-01"), name="Support", price=Money(Decimal("1200000")), stock_qty=10)
    order = SalesOrder(customer=customer, name="Subscription order")
    order.add_line(product, Quantity(1), discount_rate=Decimal("0.10"))

    lead = Lead(
        name="Enterprise trial",
        stage=Stage(name="New", sequence=1, probability=Decimal("0.10")),
        contact=Contact(
            name="Alice",
            email=EmailAddress("alice@example.com"),
            phone=PhoneNumber("+84901234567"),
            company="Acme",
        ),
        lead_type=LeadType.OPPORTUNITY,
        priority=LeadPriority.HIGH,
    )
    plan = SubscriptionPlan(
        name="Monthly Support",
        billing_interval=BillingInterval(1),
        recurring_price=Money(Decimal("1000000")),
    )
    service = SubscriptionWorkflowService()

    subscription = service.from_sales_order("sub-001", plan, order, lead=lead)
    assert subscription.customer == customer
    assert subscription.source_order == order
    assert subscription.lead == lead
    assert subscription.contact == lead.contact
    assert subscription.recurring_amount == Money(Decimal("1080000"))

    activated = service.activate(subscription, on_date=date(2026, 4, 4))
    assert activated.state == SubscriptionState.ACTIVE
    assert activated.next_invoice_date == date(2026, 5, 4)


def test_subscription_pause_resume_renew_and_billing() -> None:
    customer = Customer(name="Beta")
    plan = SubscriptionPlan(
        name="Annual Plan",
        billing_interval=BillingInterval(12),
        recurring_price=Money(Decimal("12000000")),
        auto_renew=True,
    )
    subscription = Subscription(code=SubscriptionCode("SUB-100"), customer=customer, plan=plan)
    service = SubscriptionWorkflowService()
    billing = SubscriptionBillingService()

    service.activate(subscription, on_date=date(2026, 4, 4))
    service.pause(subscription)
    assert subscription.state == SubscriptionState.PAUSED

    service.resume(subscription)
    assert subscription.state == SubscriptionState.ACTIVE

    service.renew(subscription, on_date=date(2026, 5, 4))
    assert subscription.renewal_count == 1
    assert subscription.next_invoice_date == date(2027, 4, 29)

    invoice = billing.preview_invoice(subscription, on_date=date(2026, 5, 4))
    assert invoice["amount"] == Money(Decimal("12000000"))
    assert invoice["subscription_code"] == "SUB-100"


def test_subscription_policy_and_transition_guards() -> None:
    plan = SubscriptionPlan(
        name="Monthly",
        billing_interval=BillingInterval(1),
        recurring_price=Money(Decimal("1000000")),
    )
    subscription = Subscription(code=SubscriptionCode("SUB-200"), customer=Customer(name="Gamma"), plan=plan)
    policy = DefaultSubscriptionPolicy()

    assert policy.can_activate(subscription) is True
    assert policy.can_pause(subscription) is False

    subscription.state = SubscriptionState.CANCELED
    assert policy.can_cancel(subscription) is False

    with pytest.raises(InvalidSubscriptionTransitionError):
        subscription.pause()


def test_subscription_rejects_invalid_closed_operations() -> None:
    plan = SubscriptionPlan(
        name="Monthly",
        billing_interval=BillingInterval(1),
        recurring_price=Money(Decimal("1000000")),
    )
    subscription = Subscription(code=SubscriptionCode("SUB-300"), customer=Customer(name="Delta"), plan=plan)
    subscription.cancel("customer request")

    with pytest.raises(InvalidSubscriptionError):
        subscription.add_line(
            Product(sku=SKU("SKU-SUB-02"), name="Addon", price=Money(Decimal("250000")), stock_qty=5),
            Quantity(1),
        )
