"""Purchases domain enums."""

from __future__ import annotations

from enum import Enum


class PurchaseOrderState(str, Enum):
    """Purchase order lifecycle state."""

    DRAFT = "draft"
    RFQ_SENT = "rfq_sent"
    TO_APPROVE = "to_approve"
    PURCHASE = "purchase"
    DONE = "done"
    CANCELLED = "cancelled"
