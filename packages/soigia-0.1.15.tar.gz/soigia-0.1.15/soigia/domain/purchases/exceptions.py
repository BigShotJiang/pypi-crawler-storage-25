"""Purchases domain exceptions."""

from __future__ import annotations


class PurchaseError(Exception):
    """Base class for purchases domain errors."""


class InvalidSupplierError(PurchaseError, ValueError):
    """Raised when a supplier is invalid."""


class InvalidPurchaseOrderError(PurchaseError, ValueError):
    """Raised when a purchase order is invalid."""


class InvalidPurchaseOrderLineError(PurchaseError, ValueError):
    """Raised when a purchase order line is invalid."""


class InvalidPurchaseTransitionError(PurchaseError, ValueError):
    """Raised when a purchase order transition is invalid."""


class InvalidPurchaseApprovalError(PurchaseError, ValueError):
    """Raised when a purchase approval decision is invalid."""
