"""Shared domain primitives used by multiple business modules."""

from .enums import CustomerType
from .entities import Customer, Order, OrderLine, Product
from .exceptions import (
    DomainError,
    InsufficientStockError,
    InvalidMoneyError,
    InvalidOrderError,
    InvalidQuantityError,
    InvalidSKUError,
)
from .decorators import DecoratorMetadata, constrains, depends, get_decorator_metadata, has_decorator, hook, onchange
from .events import DomainEvent, EventfulEntity
from .services import InventoryService, PricingService
from .value_objects import Money, Quantity, SKU

__all__ = [
    "CustomerType",
    "Customer",
    "Order",
    "OrderLine",
    "Product",
    "DomainError",
    "InsufficientStockError",
    "InvalidMoneyError",
    "InvalidOrderError",
    "InvalidQuantityError",
    "InvalidSKUError",
    "DecoratorMetadata",
    "DomainEvent",
    "EventfulEntity",
    "constrains",
    "depends",
    "get_decorator_metadata",
    "has_decorator",
    "hook",
    "onchange",
    "InventoryService",
    "PricingService",
    "Money",
    "Quantity",
    "SKU",
]
