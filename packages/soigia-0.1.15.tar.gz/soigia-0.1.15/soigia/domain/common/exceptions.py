"""Domain-specific exceptions."""

from __future__ import annotations


class DomainError(Exception):
    """Base class for all domain errors."""


class InvalidMoneyError(DomainError, ValueError):
    """Raised when a money value is invalid."""


class InvalidQuantityError(DomainError, ValueError):
    """Raised when a quantity is invalid."""


class InvalidSKUError(DomainError, ValueError):
    """Raised when a SKU is invalid."""


class InsufficientStockError(DomainError, ValueError):
    """Raised when stock is not enough for a reservation."""


class InvalidOrderError(DomainError, ValueError):
    """Raised when an order or order operation is invalid."""
