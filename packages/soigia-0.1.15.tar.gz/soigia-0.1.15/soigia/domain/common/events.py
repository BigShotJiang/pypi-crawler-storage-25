"""Shared domain event primitives."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass(frozen=True)
class DomainEvent:
    name: str
    source: str
    payload: dict[str, Any] = field(default_factory=dict)
    occurred_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class EventfulEntity:
    def _events(self) -> list[DomainEvent]:
        events = getattr(self, "_domain_events", None)
        if events is None:
            events = []
            setattr(self, "_domain_events", events)
        return events

    def record_event(self, name: str, **payload: Any) -> DomainEvent:
        if not isinstance(name, str) or not name.strip():
            raise ValueError("event name must be a non-empty string")
        event = DomainEvent(name=name.strip(), source=self.__class__.__name__, payload=dict(payload))
        self._events().append(event)
        return event

    def pull_events(self) -> list[DomainEvent]:
        events = list(self._events())
        self._events().clear()
        return events

    def peek_events(self) -> list[DomainEvent]:
        return list(self._events())
