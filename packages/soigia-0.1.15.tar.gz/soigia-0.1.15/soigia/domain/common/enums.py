"""Domain enums."""

from __future__ import annotations

from enum import Enum


class CustomerType(str, Enum):
    """Supported customer types."""

    NORMAL = "normal"
    VIP = "vip"
