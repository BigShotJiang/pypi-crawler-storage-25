"""Pure Obsidian-style knowledge base domain."""

from .enums import CanvasNodeType, NoteState, TaskState
from .entities import Canvas, CanvasEdge, CanvasNode, Link, Note, Task, Template, Vault
from .exceptions import (
    InvalidCanvasError,
    InvalidLinkError,
    InvalidNoteError,
    InvalidReferenceError,
    InvalidSearchError,
    InvalidTaskError,
    InvalidTagError,
    InvalidTemplateError,
    InvalidVaultError,
    ObsidianError,
)
from .policies import DefaultVaultPolicy, VaultPolicy
from .services import CanvasService, ContentDiscoveryService, TaskService, TemplateService, VaultService
from .value_objects import Alias, CanvasName, NotePath, NoteTitle, TagName, TaskText, TemplateName, VaultName

__all__ = [
    "CanvasNodeType",
    "NoteState",
    "TaskState",
    "Canvas",
    "CanvasEdge",
    "CanvasNode",
    "Link",
    "Note",
    "Task",
    "Template",
    "Vault",
    "InvalidCanvasError",
    "InvalidLinkError",
    "InvalidNoteError",
    "InvalidReferenceError",
    "InvalidSearchError",
    "InvalidTaskError",
    "InvalidTagError",
    "InvalidTemplateError",
    "InvalidVaultError",
    "ObsidianError",
    "DefaultVaultPolicy",
    "VaultPolicy",
    "CanvasService",
    "ContentDiscoveryService",
    "TaskService",
    "TemplateService",
    "VaultService",
    "Alias",
    "CanvasName",
    "NotePath",
    "NoteTitle",
    "TagName",
    "TaskText",
    "TemplateName",
    "VaultName",
]
