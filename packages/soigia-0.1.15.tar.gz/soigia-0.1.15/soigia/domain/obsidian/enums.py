"""Obsidian domain enums."""

from __future__ import annotations

from enum import Enum


class NoteState(str, Enum):
    ACTIVE = "active"
    ARCHIVED = "archived"
    TRASHED = "trashed"


class TaskState(str, Enum):
    OPEN = "open"
    DONE = "done"
    CANCELLED = "cancelled"


class CanvasNodeType(str, Enum):
    NOTE = "note"
    TEXT = "text"
    GROUP = "group"
