"""Obsidian domain exceptions."""

from __future__ import annotations


class ObsidianError(Exception):
    """Base class for Obsidian domain errors."""


class InvalidVaultError(ObsidianError, ValueError):
    """Raised when a vault is invalid."""


class InvalidNoteError(ObsidianError, ValueError):
    """Raised when a note is invalid."""


class InvalidReferenceError(ObsidianError, ValueError):
    """Raised when a note reference or path is invalid."""


class InvalidTagError(ObsidianError, ValueError):
    """Raised when a tag is invalid."""


class InvalidLinkError(ObsidianError, ValueError):
    """Raised when a link is invalid."""


class InvalidSearchError(ObsidianError, ValueError):
    """Raised when a search query is invalid."""


class InvalidTemplateError(ObsidianError, ValueError):
    """Raised when a template is invalid."""


class InvalidTaskError(ObsidianError, ValueError):
    """Raised when a task is invalid."""


class InvalidCanvasError(ObsidianError, ValueError):
    """Raised when a canvas or canvas item is invalid."""
