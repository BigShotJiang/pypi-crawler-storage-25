"""Inventory enums."""

from __future__ import annotations

from enum import Enum


class InventoryLocationUsage(str, Enum):
    INTERNAL = "internal"
    SUPPLIER = "supplier"
    CUSTOMER = "customer"
    INVENTORY = "inventory"
    TRANSIT = "transit"
    PRODUCTION = "production"


class StockMoveState(str, Enum):
    DRAFT = "draft"
    CONFIRMED = "confirmed"
    ASSIGNED = "assigned"
    DONE = "done"
    CANCELLED = "cancelled"


class StockPickingType(str, Enum):
    RECEIPT = "receipt"
    DELIVERY = "delivery"
    INTERNAL = "internal"
    INVENTORY = "inventory"
