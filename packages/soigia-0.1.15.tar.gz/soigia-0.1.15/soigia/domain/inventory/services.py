"""Inventory workflow services."""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from ..common.entities import Product
from ..common.value_objects import Quantity
from .entities import InventoryLocation, ReorderingRule, StockLot, StockMove, StockPicking, StockQuant, Warehouse
from .enums import InventoryLocationUsage, StockMoveState, StockPickingType
from .exceptions import InvalidStockMoveError, InvalidStockQuantError
from .policies import DefaultStockMoveTransitionPolicy, StockMoveTransitionPolicy


@dataclass
class InventoryLedger:
    quants: dict[tuple[str, str], StockQuant] = field(default_factory=dict)

    def _key(self, product: Product, location: InventoryLocation) -> tuple[str, str]:
        return product.sku.code, location.code

    def get_quant(self, product: Product, location: InventoryLocation, *, create: bool = False) -> StockQuant | None:
        if not location.is_stockable():
            return None
        key = self._key(product, location)
        quant = self.quants.get(key)
        if quant is None and create:
            quant = StockQuant(product=product, location=location)
            self.quants[key] = quant
        return quant

    def on_hand(self, product: Product, location: InventoryLocation) -> Decimal:
        quant = self.get_quant(product, location)
        return quant.quantity if quant is not None else Decimal("0")

    def available(self, product: Product, location: InventoryLocation) -> Decimal:
        quant = self.get_quant(product, location)
        return quant.available_quantity if quant is not None else Decimal("0")

    def increase(self, product: Product, location: InventoryLocation, quantity: Decimal | int | str | Quantity) -> None:
        quant = self.get_quant(product, location, create=True)
        if quant is None:
            raise InvalidStockQuantError("location is not stockable")
        quant.increase(quantity)

    def reserve(self, product: Product, location: InventoryLocation, quantity: Decimal | int | str | Quantity) -> None:
        quant = self.get_quant(product, location, create=True)
        if quant is None:
            raise InvalidStockQuantError("location is not stockable")
        quant.reserve(quantity)

    def release(self, product: Product, location: InventoryLocation, quantity: Decimal | int | str | Quantity) -> None:
        quant = self.get_quant(product, location)
        if quant is None:
            raise InvalidStockQuantError("location is not stockable")
        quant.release(quantity)

    def consume_reserved(
        self, product: Product, location: InventoryLocation, quantity: Decimal | int | str | Quantity
    ) -> None:
        quant = self.get_quant(product, location)
        if quant is None:
            raise InvalidStockQuantError("location is not stockable")
        quant.consume_reserved(quantity)

    def decrease(self, product: Product, location: InventoryLocation, quantity: Decimal | int | str | Quantity) -> None:
        quant = self.get_quant(product, location, create=True)
        if quant is None:
            raise InvalidStockQuantError("location is not stockable")
        quant.decrease(quantity)

    def apply_move(self, move: StockMove) -> None:
        if move.state not in {StockMoveState.CONFIRMED, StockMoveState.ASSIGNED}:
            raise InvalidStockMoveError("only confirmed or assigned stock moves can be applied to the ledger")

        if move.source_location.is_stockable():
            quant = self.get_quant(move.product, move.source_location, create=True)
            if quant is None:
                raise InvalidStockQuantError("source location is not stockable")
            if move.reserved_quantity == move.quantity:
                quant.consume_reserved(move.quantity)
            else:
                quant.decrease(move.quantity)
            if move.lot is not None:
                move.lot.remove_quantity(move.quantity)

        if move.destination_location.is_stockable():
            self.increase(move.product, move.destination_location, move.quantity)
            if move.lot is not None:
                move.lot.add_quantity(move.quantity)


@dataclass
class InventoryService:
    ledger: InventoryLedger = field(default_factory=InventoryLedger)
    transition_policy: StockMoveTransitionPolicy = field(default_factory=DefaultStockMoveTransitionPolicy)
    supplier_location: InventoryLocation = field(
        default_factory=lambda: InventoryLocation(
            code="VENDOR",
            name="Vendor",
            usage=InventoryLocationUsage.SUPPLIER,
        )
    )
    customer_location: InventoryLocation = field(
        default_factory=lambda: InventoryLocation(
            code="CUSTOMER",
            name="Customer",
            usage=InventoryLocationUsage.CUSTOMER,
        )
    )
    inventory_location: InventoryLocation = field(
        default_factory=lambda: InventoryLocation(
            code="INVENTORY",
            name="Inventory Adjustment",
            usage=InventoryLocationUsage.INVENTORY,
        )
    )
    moves: list[StockMove] = field(default_factory=list)

    def create_move(
        self,
        product: Product,
        quantity: Decimal | int | str | Quantity,
        source_location: InventoryLocation,
        destination_location: InventoryLocation,
        *,
        lot: StockLot | None = None,
        reference: str | None = None,
    ) -> StockMove:
        return StockMove(
            product=product,
            quantity=quantity,
            source_location=source_location,
            destination_location=destination_location,
            lot=lot,
            reference=reference,
        )

    def create_picking(
        self,
        name: str,
        picking_type: StockPickingType,
        warehouse: Warehouse,
        moves: list[StockMove] | None = None,
    ) -> StockPicking:
        picking = StockPicking(name=name, picking_type=picking_type, warehouse=warehouse, moves=list(moves or []))
        picking.confirm()
        return picking

    def confirm(self, move: StockMove) -> StockMove:
        self._validate_move(move)
        move.confirm(policy=self.transition_policy)
        return move

    def assign(self, move: StockMove) -> StockMove:
        self._validate_move(move)
        if move.state == StockMoveState.DRAFT:
            move.confirm(policy=self.transition_policy)

        if move.requires_reservation:
            self.ledger.reserve(move.product, move.source_location, move.quantity)
            move.reserve()

        move.assign(policy=self.transition_policy)
        return move

    def validate_move(self, move: StockMove) -> StockMove:
        self._validate_move(move)
        if move.state == StockMoveState.DRAFT:
            move.confirm(policy=self.transition_policy)

        if move.requires_reservation:
            if move.state != StockMoveState.ASSIGNED:
                self.assign(move)
            else:
                if not move.is_reserved:
                    self.ledger.reserve(move.product, move.source_location, move.quantity)
                    move.reserve()
        elif move.state == StockMoveState.CONFIRMED:
            pass
        elif move.state == StockMoveState.DRAFT:
            raise InvalidStockMoveError("draft moves must be confirmed before validation")

        self.ledger.apply_move(move)
        move.done(policy=self.transition_policy)
        self.moves.append(move)
        return move

    def receive(
        self,
        product: Product,
        quantity: Decimal | int | str | Quantity,
        destination_location: InventoryLocation,
        *,
        lot: StockLot | None = None,
        reference: str | None = None,
    ) -> StockMove:
        move = self.create_move(
            product,
            quantity,
            self.supplier_location,
            destination_location,
            lot=lot,
            reference=reference,
        )
        return self.validate_move(move)

    def deliver(
        self,
        product: Product,
        quantity: Decimal | int | str | Quantity,
        source_location: InventoryLocation,
        *,
        lot: StockLot | None = None,
        reference: str | None = None,
    ) -> StockMove:
        move = self.create_move(
            product,
            quantity,
            source_location,
            self.customer_location,
            lot=lot,
            reference=reference,
        )
        return self.validate_move(move)

    def transfer(
        self,
        product: Product,
        quantity: Decimal | int | str | Quantity,
        source_location: InventoryLocation,
        destination_location: InventoryLocation,
        *,
        lot: StockLot | None = None,
        reference: str | None = None,
    ) -> StockMove:
        move = self.create_move(
            product,
            quantity,
            source_location,
            destination_location,
            lot=lot,
            reference=reference,
        )
        return self.validate_move(move)

    def adjust_count(
        self,
        product: Product,
        location: InventoryLocation,
        counted_quantity: Decimal | int | str | Quantity,
        *,
        lot: StockLot | None = None,
        reference: str | None = None,
    ) -> StockMove | None:
        counted = (
            Decimal(str(counted_quantity.amount))
            if isinstance(counted_quantity, Quantity)
            else Decimal(str(counted_quantity))
        )
        current = self.ledger.on_hand(product, location)
        delta = counted - current

        if delta == 0:
            return None

        if delta > 0:
            move = self.create_move(product, delta, self.inventory_location, location, lot=lot, reference=reference)
        else:
            move = self.create_move(
                product, abs(delta), location, self.inventory_location, lot=lot, reference=reference
            )

        return self.validate_move(move)

    def process_picking(self, picking: StockPicking) -> StockPicking:
        if not isinstance(picking, StockPicking):
            raise InvalidStockMoveError("picking must be a StockPicking instance")
        for move in picking.moves:
            self.validate_move(move)
        picking.done()
        return picking

    def replenish(self, rule: ReorderingRule, *, reference: str | None = None) -> StockMove | None:
        if not isinstance(rule, ReorderingRule):
            raise InvalidStockQuantError("rule must be a ReorderingRule instance")
        quantity = rule.suggest_quantity(self.available(rule.product, rule.location))
        if quantity <= 0:
            return None
        move = self.create_move(rule.product, quantity, self.supplier_location, rule.location, reference=reference)
        return self.validate_move(move)

    def stock_on_hand(self, product: Product, location: InventoryLocation) -> Decimal:
        return self.ledger.on_hand(product, location)

    def available(self, product: Product, location: InventoryLocation) -> Decimal:
        return self.ledger.available(product, location)

    def _validate_move(self, move: StockMove) -> None:
        if not isinstance(move, StockMove):
            raise InvalidStockMoveError("move must be a StockMove instance")
