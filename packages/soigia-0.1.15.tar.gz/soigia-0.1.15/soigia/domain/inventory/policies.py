"""Inventory transition policies."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from .enums import StockMoveState
from .exceptions import InvalidStockTransitionError


class StockMoveTransitionPolicy(Protocol):
    def can_transition(self, current: StockMoveState, target: StockMoveState, move=None) -> bool: ...

    def ensure_transition(self, current: StockMoveState, target: StockMoveState, move=None) -> None: ...


@dataclass(frozen=True)
class DefaultStockMoveTransitionPolicy:
    def can_transition(self, current: StockMoveState, target: StockMoveState, move=None) -> bool:
        if not isinstance(current, StockMoveState) or not isinstance(target, StockMoveState):
            raise TypeError("current and target must be StockMoveState instances")
        if current == target:
            return True

        if current == StockMoveState.DRAFT:
            return target in {StockMoveState.CONFIRMED, StockMoveState.CANCELLED}

        if current == StockMoveState.CONFIRMED:
            if target == StockMoveState.ASSIGNED:
                return True
            if target == StockMoveState.DONE and move is not None:
                return not move.requires_reservation
            return target == StockMoveState.CANCELLED

        if current == StockMoveState.ASSIGNED:
            return target in {StockMoveState.DONE, StockMoveState.CANCELLED}

        return False

    def ensure_transition(self, current: StockMoveState, target: StockMoveState, move=None) -> None:
        if not self.can_transition(current, target, move=move):
            raise InvalidStockTransitionError(f"cannot transition from {current.value} to {target.value}")
