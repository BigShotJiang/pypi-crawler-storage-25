"""Inventory domain exceptions."""

from __future__ import annotations

from ..common.exceptions import DomainError


class InventoryError(DomainError):
    """Base class for inventory domain errors."""


class InvalidInventoryLocationError(InventoryError, ValueError):
    """Raised when a location is invalid."""


class InvalidWarehouseError(InventoryError, ValueError):
    """Raised when a warehouse is invalid."""


class InvalidStockQuantError(InventoryError, ValueError):
    """Raised when a stock quant is invalid."""


class InvalidStockMoveError(InventoryError, ValueError):
    """Raised when a stock move is invalid."""


class InvalidStockTransitionError(InventoryError, ValueError):
    """Raised when a stock move transition is invalid."""
