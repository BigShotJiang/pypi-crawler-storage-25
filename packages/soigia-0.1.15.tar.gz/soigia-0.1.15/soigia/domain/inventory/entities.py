"""Inventory entities following the stock workflow style from Odoo."""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, ROUND_CEILING
from typing import Any

from ..common.entities import Product
from ..common.events import EventfulEntity
from ..common.exceptions import InsufficientStockError
from ..common.value_objects import Quantity
from .enums import InventoryLocationUsage, StockMoveState, StockPickingType
from .exceptions import (
    InvalidInventoryLocationError,
    InvalidStockMoveError,
    InvalidStockQuantError,
    InvalidStockTransitionError,
    InvalidWarehouseError,
)


def _coerce_decimal(value: Any, *, allow_zero: bool = False) -> Decimal:
    if isinstance(value, bool):
        raise InvalidStockQuantError("quantity must be decimal compatible")
    if isinstance(value, Decimal):
        result = value
    elif isinstance(value, int):
        result = Decimal(value)
    elif isinstance(value, str):
        result = Decimal(value)
    elif isinstance(value, Quantity):
        result = Decimal(value.amount)
    else:
        raise InvalidStockQuantError(f"unsupported quantity value: {value!r}")

    if result < 0 or (not allow_zero and result == 0):
        bound = "greater than or equal to zero" if allow_zero else "greater than zero"
        raise InvalidStockQuantError(f"quantity must be {bound}")
    return result


@dataclass
class InventoryLocation:
    code: str
    name: str
    usage: InventoryLocationUsage = InventoryLocationUsage.INTERNAL
    parent: "InventoryLocation | None" = None
    allow_negative_stock: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.code, str) or not self.code.strip():
            raise InvalidInventoryLocationError("location code cannot be empty")
        if not isinstance(self.name, str) or not self.name.strip():
            raise InvalidInventoryLocationError("location name cannot be empty")
        if not isinstance(self.usage, InventoryLocationUsage):
            raise InvalidInventoryLocationError("invalid location usage")
        if self.parent is not None and not isinstance(self.parent, InventoryLocation):
            raise InvalidInventoryLocationError("parent must be an InventoryLocation")
        if not isinstance(self.allow_negative_stock, bool):
            raise InvalidInventoryLocationError("allow_negative_stock must be a boolean")

        self.code = self.code.strip()
        self.name = self.name.strip()

    def is_stockable(self) -> bool:
        return self.usage in {
            InventoryLocationUsage.INTERNAL,
            InventoryLocationUsage.TRANSIT,
            InventoryLocationUsage.PRODUCTION,
        }

    def is_virtual(self) -> bool:
        return not self.is_stockable()


@dataclass
class Warehouse:
    code: str
    name: str
    stock_location: InventoryLocation
    input_location: InventoryLocation | None = None
    output_location: InventoryLocation | None = None
    inventory_loss_location: InventoryLocation | None = None
    transit_location: InventoryLocation | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.code, str) or not self.code.strip():
            raise InvalidWarehouseError("warehouse code cannot be empty")
        if not isinstance(self.name, str) or not self.name.strip():
            raise InvalidWarehouseError("warehouse name cannot be empty")
        if not isinstance(self.stock_location, InventoryLocation):
            raise InvalidWarehouseError("stock_location must be an InventoryLocation")
        if not self.stock_location.is_stockable():
            raise InvalidWarehouseError("stock_location must be stockable")
        for location_name in ("input_location", "output_location", "inventory_loss_location", "transit_location"):
            location = getattr(self, location_name)
            if location is not None and not isinstance(location, InventoryLocation):
                raise InvalidWarehouseError(f"{location_name} must be an InventoryLocation")

        self.code = self.code.strip()
        self.name = self.name.strip()
        if self.inventory_loss_location is None:
            self.inventory_loss_location = InventoryLocation(
                code=f"{self.code}/INV",
                name=f"{self.name} Inventory Loss",
                usage=InventoryLocationUsage.INVENTORY,
            )

    @property
    def receipt_location(self) -> InventoryLocation:
        return self.input_location or self.stock_location

    @property
    def delivery_location(self) -> InventoryLocation:
        return self.output_location or self.stock_location

    @property
    def inventory_location(self) -> InventoryLocation:
        assert self.inventory_loss_location is not None
        return self.inventory_loss_location


@dataclass
class StockQuant:
    product: Product
    location: InventoryLocation
    quantity: Decimal = Decimal("0")
    reserved_quantity: Decimal = Decimal("0")

    def __post_init__(self) -> None:
        if not isinstance(self.product, Product):
            raise InvalidStockQuantError("product must be a Product")
        if not isinstance(self.location, InventoryLocation):
            raise InvalidStockQuantError("location must be an InventoryLocation")
        if not self.location.is_stockable():
            raise InvalidStockQuantError("stock quants can only exist on stockable locations")
        self.quantity = _coerce_decimal(self.quantity, allow_zero=True)
        self.reserved_quantity = _coerce_decimal(self.reserved_quantity, allow_zero=True)
        if self.reserved_quantity > self.quantity:
            raise InvalidStockQuantError("reserved quantity cannot exceed on-hand quantity")

    @property
    def available_quantity(self) -> Decimal:
        return self.quantity - self.reserved_quantity

    def increase(self, amount: Decimal | int | str | Quantity) -> None:
        increment = _coerce_decimal(amount)
        self.quantity += increment

    def reserve(self, amount: Decimal | int | str | Quantity) -> None:
        reserve_amount = _coerce_decimal(amount)
        if reserve_amount > self.available_quantity and not self.location.allow_negative_stock:
            raise InsufficientStockError(
                f"not enough stock for {self.product.sku.code}: requested={reserve_amount}, "
                f"available={self.available_quantity}"
            )
        self.reserved_quantity += reserve_amount

    def release(self, amount: Decimal | int | str | Quantity) -> None:
        release_amount = _coerce_decimal(amount)
        if release_amount > self.reserved_quantity:
            raise InvalidStockQuantError("cannot release more stock than reserved")
        self.reserved_quantity -= release_amount

    def consume_reserved(self, amount: Decimal | int | str | Quantity) -> None:
        consumed = _coerce_decimal(amount)
        if consumed > self.reserved_quantity:
            raise InvalidStockQuantError("cannot consume more than the reserved quantity")
        if consumed > self.quantity and not self.location.allow_negative_stock:
            raise InsufficientStockError(
                f"not enough stock for {self.product.sku.code}: requested={consumed}, available={self.quantity}"
            )
        self.quantity -= consumed
        self.reserved_quantity -= consumed

    def decrease(self, amount: Decimal | int | str | Quantity) -> None:
        decreased = _coerce_decimal(amount)
        if decreased > self.available_quantity and not self.location.allow_negative_stock:
            raise InsufficientStockError(
                f"not enough stock for {self.product.sku.code}: requested={decreased}, "
                f"available={self.available_quantity}"
            )
        self.quantity -= decreased


@dataclass
class StockMove(EventfulEntity):
    product: Product
    quantity: Decimal | int | str | Quantity
    source_location: InventoryLocation
    destination_location: InventoryLocation
    lot: "StockLot | None" = None
    state: StockMoveState = StockMoveState.DRAFT
    reference: str | None = None
    reserved_quantity: Decimal = Decimal("0")

    def __post_init__(self) -> None:
        if not isinstance(self.product, Product):
            raise InvalidStockMoveError("product must be a Product")
        self.quantity = _coerce_decimal(self.quantity)
        if not isinstance(self.source_location, InventoryLocation):
            raise InvalidStockMoveError("source_location must be an InventoryLocation")
        if not isinstance(self.destination_location, InventoryLocation):
            raise InvalidStockMoveError("destination_location must be an InventoryLocation")
        if self.source_location.code == self.destination_location.code:
            raise InvalidStockMoveError("source and destination locations cannot be the same")
        if self.lot is not None and not isinstance(self.lot, StockLot):
            raise InvalidStockMoveError("lot must be a StockLot or None")
        if self.lot is not None and self.lot.product.sku != self.product.sku:
            raise InvalidStockMoveError("lot product must match move product")
        if not isinstance(self.state, StockMoveState):
            raise InvalidStockMoveError("invalid stock move state")
        if self.reference is not None and (not isinstance(self.reference, str) or not self.reference.strip()):
            raise InvalidStockMoveError("reference must be a non-empty string when provided")
        self.reference = self.reference.strip() if self.reference is not None else None

    @property
    def requires_reservation(self) -> bool:
        return self.source_location.is_stockable() and not self.source_location.allow_negative_stock

    @property
    def is_reserved(self) -> bool:
        return self.reserved_quantity == self.quantity

    def reserve(self) -> None:
        if not self.requires_reservation:
            return
        self.reserved_quantity = self.quantity
        self.record_event(
            "inventory.stock_move.reserved",
            product=self.product.sku.code,
            quantity=str(self.quantity),
            source_location=self.source_location.code,
            reference=self.reference,
        )

    def release(self) -> None:
        self.reserved_quantity = Decimal("0")
        self.record_event(
            "inventory.stock_move.released",
            product=self.product.sku.code,
            quantity=str(self.quantity),
            source_location=self.source_location.code,
            reference=self.reference,
        )

    def confirm(self, *, policy: "StockMoveTransitionPolicy | None" = None) -> None:
        self._transition(StockMoveState.CONFIRMED, policy=policy)

    def assign(self, *, policy: "StockMoveTransitionPolicy | None" = None) -> None:
        self._transition(StockMoveState.ASSIGNED, policy=policy)

    def done(self, *, policy: "StockMoveTransitionPolicy | None" = None) -> None:
        self._transition(StockMoveState.DONE, policy=policy)

    def cancel(self, *, policy: "StockMoveTransitionPolicy | None" = None) -> None:
        self._transition(StockMoveState.CANCELLED, policy=policy)

    def _transition(self, target_state: StockMoveState, *, policy: "StockMoveTransitionPolicy | None" = None) -> None:
        from .policies import DefaultStockMoveTransitionPolicy

        if policy is None:
            policy = DefaultStockMoveTransitionPolicy()
        previous_state = self.state
        if not policy.can_transition(self.state, target_state, move=self):
            raise InvalidStockTransitionError(f"cannot move stock move from {self.state.value} to {target_state.value}")
        self.state = target_state
        self.record_event(
            "inventory.stock_move.state_changed",
            product=self.product.sku.code,
            from_state=previous_state.value,
            to_state=target_state.value,
            quantity=str(self.quantity),
            reference=self.reference,
        )


@dataclass
class StockLot:
    product: Product
    name: str
    quantity: Decimal | int | str | Quantity = Decimal("0")
    expiration_date: "date | None" = None
    reference: str | None = None

    def __post_init__(self) -> None:
        from datetime import date

        if not isinstance(self.product, Product):
            raise InvalidStockQuantError("product must be a Product")
        if not isinstance(self.name, str) or not self.name.strip():
            raise InvalidStockQuantError("lot name cannot be empty")
        self.quantity = _coerce_decimal(self.quantity, allow_zero=True)
        if self.expiration_date is not None and not isinstance(self.expiration_date, date):
            raise InvalidStockQuantError("expiration_date must be a date or None")
        if self.reference is not None and (not isinstance(self.reference, str) or not self.reference.strip()):
            raise InvalidStockQuantError("reference must be a non-empty string when provided")
        self.name = self.name.strip()
        self.reference = self.reference.strip() if self.reference is not None else None

    @property
    def is_expired(self) -> bool:
        from datetime import date

        return self.expiration_date is not None and self.expiration_date < date.today()

    def add_quantity(self, amount: Decimal | int | str | Quantity) -> None:
        self.quantity += _coerce_decimal(amount)

    def remove_quantity(self, amount: Decimal | int | str | Quantity) -> None:
        removed = _coerce_decimal(amount)
        if removed > self.quantity:
            raise InvalidStockQuantError("cannot remove more quantity than available in lot")
        self.quantity -= removed


@dataclass
class ReorderingRule:
    product: Product
    location: InventoryLocation
    min_quantity: Decimal | int | str | Quantity
    max_quantity: Decimal | int | str | Quantity
    multiple: Decimal | int | str | Quantity = Decimal("1")
    lead_time_days: int = 0

    def __post_init__(self) -> None:
        if not isinstance(self.product, Product):
            raise InvalidStockQuantError("product must be a Product")
        if not isinstance(self.location, InventoryLocation):
            raise InvalidStockQuantError("location must be an InventoryLocation")
        if not self.location.is_stockable():
            raise InvalidStockQuantError("location must be stockable")
        self.min_quantity = _coerce_decimal(self.min_quantity, allow_zero=True)
        self.max_quantity = _coerce_decimal(self.max_quantity, allow_zero=True)
        self.multiple = _coerce_decimal(self.multiple)
        if self.max_quantity < self.min_quantity:
            raise InvalidStockQuantError("max_quantity must be greater than or equal to min_quantity")
        if self.lead_time_days < 0:
            raise InvalidStockQuantError("lead_time_days cannot be negative")

    def needs_replenishment(self, available_quantity: Decimal | int | str | Quantity) -> bool:
        available = _coerce_decimal(available_quantity, allow_zero=True)
        return available <= self.min_quantity

    def suggest_quantity(self, available_quantity: Decimal | int | str | Quantity) -> Decimal:
        available = _coerce_decimal(available_quantity, allow_zero=True)
        if not self.needs_replenishment(available):
            return Decimal("0")
        target = self.max_quantity - available
        if target <= 0:
            return Decimal("0")
        if self.multiple <= 1:
            return target
        quotient = (target / self.multiple).to_integral_value(rounding=ROUND_CEILING)
        return quotient * self.multiple


@dataclass
class StockPicking(EventfulEntity):
    name: str
    picking_type: StockPickingType
    warehouse: Warehouse
    moves: list[StockMove] = field(default_factory=list)
    state: str = "draft"

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise InvalidStockMoveError("picking name cannot be empty")
        if not isinstance(self.picking_type, StockPickingType):
            raise InvalidStockMoveError("invalid picking type")
        if not isinstance(self.warehouse, Warehouse):
            raise InvalidStockMoveError("warehouse must be a Warehouse")
        if any(not isinstance(move, StockMove) for move in self.moves):
            raise InvalidStockMoveError("moves must contain StockMove instances")
        self.name = self.name.strip()
        self.state = self.state.strip()

    @property
    def is_done(self) -> bool:
        return self.state == "done"

    @property
    def is_cancelled(self) -> bool:
        return self.state == "cancelled"

    def add_move(self, move: StockMove) -> StockMove:
        if not isinstance(move, StockMove):
            raise InvalidStockMoveError("move must be a StockMove instance")
        self.moves.append(move)
        self.record_event(
            "inventory.picking.move_added",
            picking=self.name,
            product=move.product.sku.code,
            quantity=str(move.quantity),
        )
        return move

    def confirm(self) -> None:
        self.state = "confirmed"
        self.record_event("inventory.picking.confirmed", picking=self.name, type=self.picking_type.value)

    def done(self) -> None:
        self.state = "done"
        self.record_event("inventory.picking.done", picking=self.name, type=self.picking_type.value)

    def cancel(self) -> None:
        self.state = "cancelled"
        self.record_event("inventory.picking.cancelled", picking=self.name, type=self.picking_type.value)
