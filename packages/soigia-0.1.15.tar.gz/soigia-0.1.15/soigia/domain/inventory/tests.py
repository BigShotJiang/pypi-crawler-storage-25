from decimal import Decimal

import pytest

from ..common.entities import Product
from ..common.exceptions import InsufficientStockError
from ..common.value_objects import Money, Quantity, SKU
from . import (
    InventoryLocation,
    InventoryLocationUsage,
    InventoryService,
    ReorderingRule,
    StockLot,
    StockMoveState,
    StockPickingType,
    Warehouse,
)


def test_inventory_service_receipt_creates_stock_in_internal_location() -> None:
    service = InventoryService()
    product = Product(sku=SKU("SKU-INV-001"), name="Keyboard", price=Money(Decimal("500000")), stock_qty=0)
    stock_location = InventoryLocation(code="WH/Stock", name="Stock", usage=InventoryLocationUsage.INTERNAL)
    warehouse = Warehouse(code="WH", name="Main Warehouse", stock_location=stock_location)

    move = service.receive(product, Quantity(10), warehouse.stock_location, reference="IN/0001")

    assert move.state == StockMoveState.DONE
    assert service.stock_on_hand(product, warehouse.stock_location) == Decimal("10")
    assert service.available(product, warehouse.stock_location) == Decimal("10")


def test_inventory_service_transfer_reserves_source_and_moves_stock() -> None:
    service = InventoryService()
    product = Product(sku=SKU("SKU-INV-002"), name="Mouse", price=Money(Decimal("250000")), stock_qty=0)
    source = InventoryLocation(code="WH/Stock", name="Stock", usage=InventoryLocationUsage.INTERNAL)
    destination = InventoryLocation(code="WH/PACK", name="Packing", usage=InventoryLocationUsage.INTERNAL)
    service.ledger.increase(product, source, 8)

    move = service.transfer(product, 3, source, destination, reference="INT/0001")

    assert move.state == StockMoveState.DONE
    assert service.stock_on_hand(product, source) == Decimal("5")
    assert service.stock_on_hand(product, destination) == Decimal("3")


def test_inventory_service_transfer_raises_when_not_enough_stock() -> None:
    service = InventoryService()
    product = Product(sku=SKU("SKU-INV-003"), name="Monitor", price=Money(Decimal("2500000")), stock_qty=0)
    source = InventoryLocation(code="WH/Stock", name="Stock", usage=InventoryLocationUsage.INTERNAL)
    destination = InventoryLocation(code="WH/OUT", name="Delivery", usage=InventoryLocationUsage.INTERNAL)
    service.ledger.increase(product, source, 1)

    with pytest.raises(InsufficientStockError):
        service.transfer(product, Quantity(2), source, destination, reference="INT/0002")

    assert service.stock_on_hand(product, source) == Decimal("1")
    assert service.stock_on_hand(product, destination) == Decimal("0")


def test_inventory_adjustment_uses_delta_against_inventory_location() -> None:
    service = InventoryService()
    product = Product(sku=SKU("SKU-INV-004"), name="Chair", price=Money(Decimal("1000000")), stock_qty=0)
    stock_location = InventoryLocation(code="WH/Stock", name="Stock", usage=InventoryLocationUsage.INTERNAL)
    service.ledger.increase(product, stock_location, 10)

    move = service.adjust_count(product, stock_location, Quantity(7), reference="INV/0001")

    assert move is not None
    assert move.state == StockMoveState.DONE
    assert service.stock_on_hand(product, stock_location) == Decimal("7")


def test_inventory_service_tracks_lots_and_replenishment() -> None:
    service = InventoryService()
    stock = InventoryLocation(code="WH/Stock", name="Stock", usage=InventoryLocationUsage.INTERNAL)
    product = Product(sku=SKU("SKU-INV-005"), name="Cable", price=Money(Decimal("50000")), stock_qty=0)
    lot = StockLot(product=product, name="LOT-001")

    move = service.receive(product, Quantity(5), stock, lot=lot, reference="IN/0002")
    rule = ReorderingRule(product=product, location=stock, min_quantity=Decimal("10"), max_quantity=Decimal("20"))

    assert move.peek_events()[0].name == "inventory.stock_move.state_changed"
    assert lot.quantity == Decimal("5")
    assert service.replenish(rule, reference="PO/0001") is not None


def test_inventory_picking_creation_records_state_and_events() -> None:
    service = InventoryService()
    stock = InventoryLocation(code="WH/Stock", name="Stock", usage=InventoryLocationUsage.INTERNAL)
    pack = InventoryLocation(code="WH/Pack", name="Pack", usage=InventoryLocationUsage.INTERNAL)
    warehouse = Warehouse(code="WH", name="Main", stock_location=stock, output_location=pack)
    product = Product(sku=SKU("SKU-INV-006"), name="Mousepad", price=Money(Decimal("10000")), stock_qty=0)

    service.ledger.increase(product, stock, 1)
    picking = service.create_picking("PICK/0002", StockPickingType.INTERNAL, warehouse)
    picking.add_move(service.create_move(product, Quantity(1), stock, pack))
    service.process_picking(picking)

    assert picking.is_done is True
    assert [event.name for event in picking.peek_events()] == [
        "inventory.picking.confirmed",
        "inventory.picking.move_added",
        "inventory.picking.done",
    ]
