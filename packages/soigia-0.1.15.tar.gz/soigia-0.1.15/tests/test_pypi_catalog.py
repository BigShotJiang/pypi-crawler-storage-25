from __future__ import annotations

import json
import shutil
from pathlib import Path
import runpy
import sys
from urllib.error import HTTPError, URLError

import pytest

import soigia.pypi_catalog as catalog


class _FakeResponse:
    def __init__(self, payload: bytes):
        self.payload = payload

    def read(self) -> bytes:
        return self.payload

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


def _sandbox(name: str) -> Path:
    path = Path.cwd() / ".test_artifacts" / name
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def test_package_record_and_simple_index_helpers():
    parser = catalog._SimpleIndexHTMLParser()
    parser.feed('<a href="/project-one/">One</a><span>skip</span><a href="https://pypi.org/project-two/">Two</a>')
    assert parser.projects == ["project-one", "project-two"]
    parser.handle_starttag("div", [])
    parser.handle_starttag("a", [("href", None)])
    parser.handle_starttag("a", [("href", "")])

    record = catalog.PackageRecord(package_name="demo", pypi_url="https://pypi.org/project/demo/")
    row = record.as_csv_row()
    assert row["package_name"] == "demo"
    assert row["pypi_url"].endswith("/demo/")


def test_request_helpers_build_headers_and_decode(monkeypatch):
    seen = {}

    def fake_urlopen(request, timeout=20):
        seen["url"] = request.full_url
        seen["headers"] = dict(request.header_items())
        seen["timeout"] = timeout
        return _FakeResponse(b'{"ok": true}')

    monkeypatch.setattr(catalog, "urlopen", fake_urlopen)

    assert catalog._json_request("https://example.test/api", headers={"Accept": "application/json"}) == {"ok": True}
    assert catalog._text_request("https://example.test/text", headers={"X-Test": "1"}) == '{"ok": true}'
    assert seen["url"] == "https://example.test/text"
    assert seen["timeout"] == 20
    assert "User-agent" in seen["headers"]


def test_fetch_pypi_project_names_prefers_json_and_falls_back_to_html(monkeypatch):
    monkeypatch.setattr(catalog, "_json_request", lambda *args, **kwargs: {"projects": [{"name": "alpha"}, {"name": ""}]})
    assert catalog.fetch_pypi_project_names() == ["alpha"]

    monkeypatch.setattr(catalog, "_json_request", lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("boom")))
    monkeypatch.setattr(catalog, "_text_request", lambda *args, **kwargs: '<a href="/beta/">beta</a><a href="/gamma/">g</a>')
    assert catalog.fetch_pypi_project_names() == ["beta", "gamma"]


def test_github_repo_normalization_and_selection():
    assert catalog._normalize_github_repo("https://github.com/owner/repo") == "owner/repo"
    assert catalog._normalize_github_repo("https://github.com/owner/repo.git") == "owner/repo"
    assert catalog._normalize_github_repo("https://github.com/owner/issues") is None
    assert catalog._normalize_github_repo("https://gitlab.com/owner/repo") is None
    assert catalog._normalize_github_repo("https://github.com/owner/repo/issues") is None
    assert catalog._normalize_github_repo("https://github.com//") is None
    assert catalog._normalize_github_repo("https://github.com/owner/") is None
    fake_matcher = type("FakeMatcher", (), {"match": lambda self, value: type("M", (), {"groups": lambda self: ("", "")})()})()
    original_re = catalog.GITHUB_REPO_RE
    catalog.GITHUB_REPO_RE = fake_matcher
    try:
        assert catalog._normalize_github_repo("https://github.com/owner/repo") is None
    finally:
        catalog.GITHUB_REPO_RE = original_re

    repo, selected = catalog.find_github_repo(
        {
            "project_urls": {
                "Source": "https://github.com/acme/project",
                "Homepage": "https://example.test",
            },
            "project_url": "https://github.com/acme/project-web",
            "home_page": "https://example.test/home",
        }
    )
    assert repo == "acme/project"
    assert selected["source_url"] == "https://github.com/acme/project"
    assert selected["project_url"] == "https://github.com/acme/project-web"
    assert selected["home_page"] == "https://example.test/home"
    assert list(catalog._candidate_urls({"project_urls": {}, "download_url": "https://example.test/dl"}))[-1][0] == "download_url"
    assert catalog.find_github_repo({"project_urls": {"Homepage": "https://github.com/acme/home"}})[0] == "acme/home"
    assert catalog.find_github_repo({"project_urls": {"Project": "https://example.test/project"}})[0] is None


def test_fetch_package_record_handles_success_and_error_branches(monkeypatch):
    payloads = {
        "https://pypi.org/pypi/demo/json": {
            "info": {
                "summary": "Demo package",
                "project_urls": {"Source": "https://github.com/acme/demo"},
            }
        },
        "https://api.github.com/repos/acme/demo": {
            "stargazers_count": 10,
            "forks_count": 2,
            "open_issues_count": 1,
            "archived": False,
            "disabled": False,
        },
    }

    def fake_json_request(url, headers=None, timeout=20):
        if url in payloads:
            return payloads[url]
        raise AssertionError(url)

    monkeypatch.setattr(catalog, "_json_request", fake_json_request)

    record = catalog.fetch_package_record("demo", github_token="secret")
    assert record.summary == "Demo package"
    assert record.github_repo == "acme/demo"
    assert record.stars == "10"
    assert record.error == ""

    monkeypatch.setattr(
        catalog,
        "_json_request",
        lambda *args, **kwargs: (_ for _ in ()).throw(HTTPError("https://x", 404, "missing", {}, None)),
    )
    assert catalog.fetch_package_record("missing").error == "pypi_http_404"

    monkeypatch.setattr(
        catalog,
        "_json_request",
        lambda *args, **kwargs: (_ for _ in ()).throw(URLError("offline")),
    )
    assert catalog.fetch_package_record("offline").error == "pypi_url_offline"
    monkeypatch.setattr(
        catalog,
        "_json_request",
        lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("boom")),
    )
    assert catalog.fetch_package_record("offline").error == "pypi_error_RuntimeError"

    calls = {"count": 0}

    def github_failure(url, headers=None, timeout=20):
        calls["count"] += 1
        if calls["count"] == 1:
            return {"info": {"summary": "x", "project_urls": {"Source": "https://github.com/acme/demo"}}}
        raise HTTPError(url, 403, "forbidden", {}, None)

    monkeypatch.setattr(catalog, "_json_request", github_failure)
    assert catalog.fetch_package_record("demo").error == "github_rate_limited_or_forbidden"

    monkeypatch.setattr(
        catalog,
        "_json_request",
        lambda url, headers=None, timeout=20: {"info": {"summary": "x", "project_urls": {"Source": "https://github.com/acme/demo"}}}
        if "pypi" in url
        else (_ for _ in ()).throw(HTTPError(url, 500, "missing", {}, None)),
    )
    assert catalog.fetch_package_record("demo").error == "github_http_500"

    monkeypatch.setattr(
        catalog,
        "_json_request",
        lambda url, headers=None, timeout=20: {"info": {"summary": "x", "project_urls": {"Source": "https://github.com/acme/demo"}}}
        if "pypi" in url
        else (_ for _ in ()).throw(HTTPError(url, 404, "missing", {}, None)),
    )
    assert catalog.fetch_package_record("demo").error == "github_repo_not_found"

    monkeypatch.setattr(
        catalog,
        "_json_request",
        lambda url, headers=None, timeout=20: {"info": {"summary": "x", "project_urls": {"Source": "https://github.com/acme/demo"}}}
        if "pypi" in url
        else (_ for _ in ()).throw(URLError("down")),
    )
    assert catalog.fetch_package_record("demo").error == "github_url_down"

    monkeypatch.setattr(
        catalog,
        "_json_request",
        lambda url, headers=None, timeout=20: {"info": {"summary": "x", "project_urls": {"Source": "https://github.com/acme/demo"}}}
        if "pypi" in url
        else (_ for _ in ()).throw(RuntimeError("boom")),
    )
    assert catalog.fetch_package_record("demo").error == "github_error_RuntimeError"
    monkeypatch.setattr(catalog, "_json_request", lambda *args, **kwargs: {"info": {"summary": "x", "project_urls": {}}})
    assert catalog.fetch_package_record("norepo").github_repo == ""


def test_export_catalog_writes_rows_and_supports_resume(monkeypatch):
    output = _sandbox("pypi_catalog_export") / "catalog.csv"
    monkeypatch.setattr(catalog, "fetch_pypi_project_names", lambda: ["alpha", "beta", "gamma"])

    def fake_fetch(name, github_token=None):
        return catalog.PackageRecord(
            package_name=name,
            pypi_url=f"https://pypi.org/project/{name}/",
            github_repo="acme/" + name if name != "beta" else "",
        )

    monkeypatch.setattr(catalog, "fetch_package_record", fake_fetch)
    monkeypatch.setattr(catalog.time, "sleep", lambda seconds: None)

    totals = catalog.export_catalog(
        output,
        limit=2,
        offset=1,
        workers=2,
        github_token=None,
        sleep_seconds=0.1,
        resume=False,
    )
    assert totals == {
        "pypi_projects_seen": 2,
        "rows_written": 2,
        "github_rows": 1,
        "skipped_existing": 0,
    }
    rows = output.read_text(encoding="utf-8").strip().splitlines()
    assert rows[0].startswith("package_name,")
    assert "beta" in rows[1]
    assert "gamma" in rows[2]
    assert catalog._load_existing_package_names(output) == {"beta", "gamma"}
    catalog._write_csv_header_if_needed(output)

    totals = catalog.export_catalog(
        output,
        limit=None,
        offset=0,
        workers=1,
        github_token=None,
        sleep_seconds=0.0,
        resume=True,
    )
    assert totals["skipped_existing"] == 2
    assert totals["rows_written"] == 1
    assert catalog._load_existing_package_names(output)
    assert catalog._load_existing_package_names(output.with_name("missing.csv")) == set()
    bad_output = output.with_name("bad.csv")
    bad_output.write_text("{", encoding="utf-8")
    assert catalog._load_existing_package_names(bad_output) == set()

    calls = []
    monkeypatch.setattr(catalog, "fetch_pypi_project_names", lambda: ["alpha", "beta", "gamma"])
    monkeypatch.setattr(
        catalog,
        "fetch_package_record",
        lambda name, github_token=None: calls.append(name)
        or catalog.PackageRecord(package_name=name, pypi_url=f"https://pypi.org/project/{name}/"),
    )
    totals = catalog.export_catalog(
        output.with_name("queue.csv"),
        workers=2,
        limit=3,
        offset=0,
        github_token=None,
        sleep_seconds=0.0,
        resume=False,
    )
    assert totals["rows_written"] == 3
    assert calls == ["alpha", "beta", "gamma"]


def test_build_parser_and_main(monkeypatch, capsys):
    parser = catalog.build_parser()
    args = parser.parse_args(["--output", "x.csv", "--limit", "5", "--resume"])
    assert args.output == "x.csv"
    assert args.limit == 5
    assert args.resume is True

    output = _sandbox("pypi_catalog_main") / "result.csv"
    monkeypatch.setattr(
        catalog,
        "export_catalog",
        lambda *args, **kwargs: {"pypi_projects_seen": 1, "rows_written": 1, "github_rows": 0, "skipped_existing": 0},
    )

    assert catalog.main(["--output", str(output)]) == 0
    captured = capsys.readouterr()
    stdout_payload = json.loads(captured.out)
    assert stdout_payload["output"] == str(output.resolve())
    assert "GITHUB_TOKEN" in captured.err

    def raise_interrupt(*args, **kwargs):
        raise KeyboardInterrupt

    monkeypatch.setattr(catalog, "export_catalog", raise_interrupt)
    assert catalog.main(["--output", str(output), "--github-token", "set"]) == 130

    monkeypatch.setattr(
        catalog,
        "export_catalog",
        lambda *args, **kwargs: {"pypi_projects_seen": 0, "rows_written": 0, "github_rows": 0, "skipped_existing": 0},
    )
    assert catalog.main(["--output", str(output), "--github-token", "set"]) == 0


def test_pypi_catalog_main_entrypoint_with_fake_network(monkeypatch):
    output = _sandbox("pypi_catalog_entrypoint") / "out.csv"
    monkeypatch.setattr(sys, "argv", ["pypi_catalog.py", "--output", str(output), "--limit", "0"])

    def fake_urlopen(request, timeout=20):
        return _FakeResponse(b'{"projects": []}')

    monkeypatch.setattr(__import__("urllib.request").request, "urlopen", fake_urlopen)

    with pytest.raises(SystemExit) as exc_info:
        runpy.run_module("soigia.pypi_catalog", run_name="__main__")

    assert exc_info.value.code == 0
