from __future__ import annotations

import argparse
import importlib.util
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

import pytest


def _load_cli_module():
    spec = importlib.util.spec_from_file_location("soigia_cli_more", Path("soigia/cli.py"))
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _sandbox(name: str) -> Path:
    path = Path.cwd() / ".test_artifacts" / f"{name}_{time.time_ns()}"
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


class _Parser:
    def error(self, message):
        raise RuntimeError(message)


def _args(**overrides):
    payload = {
        "cwd": None,
        "completion_shell": None,
        "profile": None,
        "pane_title": None,
        "pane_cmd": None,
        "extra": None,
        "target": "4",
        "wizard": False,
        "list_presets": False,
        "install_completion": False,
        "dry_run": False,
        "show_layout": False,
    }
    payload.update(overrides)
    return argparse.Namespace(**payload)


def test_cli_low_level_helpers_and_errors(monkeypatch):
    cli = _load_cli_module()
    tmp_path = _sandbox("cli_low_level")

    assert cli._powershell_script("Hello", "C:/x")[0] == "powershell.exe"
    assert cli._powershell_command("dir", "C:/x")[-1].endswith("dir")
    assert cli.PRESETS["trade"].pane_titles == ("market", "orders", "logs", "notes")

    with pytest.raises(argparse.ArgumentTypeError):
        cli._positive_int("x")
    with pytest.raises(argparse.ArgumentTypeError):
        cli._positive_int("0")
    assert cli._positive_int("2") == 2

    monkeypatch.setattr(cli.sys, "platform", "linux")
    assert cli._is_windows() is False

    monkeypatch.setattr(cli.shutil, "which", lambda name: None)
    monkeypatch.delenv("LOCALAPPDATA", raising=False)
    with pytest.raises(cli.CliError):
        cli._find_wt_executable()

    wt_path = tmp_path / "wt.exe"
    wt_path.write_text("", encoding="utf-8")
    monkeypatch.setattr(cli.shutil, "which", lambda name: str(wt_path) if name == "wt.exe" else None)
    assert cli._find_wt_executable() == str(wt_path)

    monkeypatch.setenv("SHELL", "")
    monkeypatch.setattr(cli.sys, "platform", "win32")
    monkeypatch.delenv("PSModulePath", raising=False)
    monkeypatch.setenv("COMSPEC", r"C:\Windows\System32\cmd.exe")
    assert cli._detect_shell() == "powershell"

    recent = tmp_path / "recent.json"
    monkeypatch.setenv(cli.RECENT_ENV_PATH, str(recent))
    assert cli._recent_path() == recent.resolve()
    assert cli._load_recent_layouts() == []
    recent.write_text("{", encoding="utf-8")
    assert cli._load_recent_layouts() == []
    recent.write_text(json.dumps({"x": 1}), encoding="utf-8")
    assert cli._load_recent_layouts() == []
    recent.write_text(json.dumps(["a", 1, "b"]), encoding="utf-8")
    assert cli._load_recent_layouts() == ["a", "b"]

    monkeypatch.setattr(cli, "_recent_path", lambda: tmp_path / "missing" / "recent.json")
    cli._save_recent_layouts(["a", "b", "c", "d"])
    assert json.loads((tmp_path / "missing" / "recent.json").read_text(encoding="utf-8")) == ["a", "b", "c"]

    class _BadParent:
        def mkdir(self, *args, **kwargs):
            return None

    class _BadPath:
        parent = _BadParent()

        def write_text(self, *args, **kwargs):
            raise OSError("nope")

    monkeypatch.setattr(cli, "_recent_path", lambda: _BadPath())
    cli._save_recent_layouts(["a"])

    with pytest.raises(argparse.ArgumentTypeError):
        cli._resolve_layout_target("unknown")
    with pytest.raises(argparse.ArgumentTypeError):
        cli._parse_pane_command("   ")

    assert cli._normalize_command_template(("cd", "{cwd}"), "C:/tmp") == ("cd", "C:/tmp")
    command = ["wt.exe"]
    cli._append_segment(command, ["split-pane"])
    assert command == ["wt.exe", "split-pane"]
    cli._append_segment(command, ["move-focus"])
    assert command == ["wt.exe", "split-pane", ";", "move-focus"]
    assert cli._pane_segment("pane", "C:/tmp", ("cd", "{cwd}"))[-1] == "C:/tmp"
    assert len(cli._build_default_pane_specs(2)) == 2
    assert len(cli._build_default_workspace_pane_specs(2, str(tmp_path))) == 2


def test_cli_rendering_builders_and_launch_paths(monkeypatch):
    cli = _load_cli_module()
    parser = _Parser()
    tmp_path = _sandbox("cli_builders")

    app_file = tmp_path / "app.py"
    app_file.write_text("print('x')", encoding="utf-8")
    monkeypatch.setattr(cli, "DEFAULT_STREAMLIT_APP", app_file)

    specs = cli._build_default_workspace_pane_specs(4, str(tmp_path))
    assert specs[0].title == "app-1"

    custom = cli._build_pane_specs(
        5,
        pane_titles=["a", "b", "c", "d", "e"],
        pane_commands=[("pwsh",), ("pytest",)],
        cwd=str(tmp_path),
    )
    assert [spec.title for spec in custom] == ["a", "b", "c", "d", "e"]
    assert custom[0].command_template == ("pwsh",)
    assert custom[1].command_template == ("pytest",)

    monkeypatch.setattr(cli, "_find_wt_executable", lambda: "wt.exe")
    built = cli._build_wt_command(tuple(cli.PaneSpec(f"p{i}") for i in range(1, 6)), str(tmp_path))
    assert built[0] == "wt.exe"
    assert built.count("split-pane") >= 4
    with pytest.raises(cli.CliError):
        cli._build_wt_command([], str(tmp_path))

    run_calls = []
    monkeypatch.setattr(cli.subprocess, "run", lambda command, check: run_calls.append((command, check)))
    cli._run_command(["wt.exe"])
    assert run_calls == [(["wt.exe"], True)]
    assert ";" in cli._render_command(["wt.exe", ";", "split-pane"])

    printed = []
    monkeypatch.setattr(cli.console, "print", lambda value=None: printed.append(value))
    monkeypatch.setattr(cli, "_render_command", lambda command: "rendered")
    cli._render_suggestions()
    cli._menu_box("T", ["a", "b"])
    cli._render_menu_group("Group", "cyan", [("k", "desc")])
    cli._render_presets_table()
    cli._preview_layout("dev", [cli.PaneSpec("a", ("python",))])
    cli._show_command_preview(["wt.exe"])
    cli._print_install_result(tmp_path / "profile.ps1", "powershell")
    assert printed

    answers = iter(["2"])
    monkeypatch.setattr(cli.Prompt, "ask", lambda *args, **kwargs: next(answers))
    assert cli._menu_prompt("Menu", [("one", "desc"), ("two", "desc")]) == "two"

    preview_calls = []
    show_calls = []
    launch_calls = []
    monkeypatch.setattr(cli, "_preview_layout", lambda *args: preview_calls.append(args))
    monkeypatch.setattr(cli, "_show_command_preview", lambda command: show_calls.append(command))
    monkeypatch.setattr(cli, "_build_wt_command", lambda pane_specs, cwd: ["wt.exe", cwd, str(len(pane_specs))])
    monkeypatch.setattr(cli, "_run_command", lambda command: launch_calls.append(command))
    monkeypatch.setattr(cli, "_remember_layout", lambda target: launch_calls.append(("remember", target)))

    assert cli._launch_layout(parser, "dev", str(tmp_path), preset=cli.PRESETS["dev"], show_layout=True) == 0
    assert preview_calls
    assert cli._launch_layout(parser, "dev", str(tmp_path), preset=cli.PRESETS["dev"], dry_run=True) == 0
    assert show_calls
    assert cli._launch_layout(parser, "dev", str(tmp_path), preset=cli.PRESETS["dev"]) == 0
    assert ("remember", "dev") in launch_calls
    with pytest.raises(RuntimeError):
        cli._launch_layout(parser, "99", str(tmp_path), pane_count=cli.MAX_AUTO_LAYOUT_PANES + 1)


def test_cli_completion_profiles_and_wizard(monkeypatch, capsys):
    cli = _load_cli_module()
    parser = _Parser()
    tmp_path = _sandbox("cli_completion")

    with pytest.raises(cli.CliError):
        cli._completion_script("fish")
    assert "compgen" in cli._completion_script("bash")
    assert "#compdef" in cli._completion_script("zsh")

    monkeypatch.setattr(cli.Path, "home", lambda: tmp_path)
    assert cli._profile_path("bash") == tmp_path / ".bashrc"
    assert cli._profile_path("zsh") == tmp_path / ".zshrc"
    assert cli._profile_path("powershell").name.endswith(".ps1")
    with pytest.raises(cli.CliError):
        cli._profile_path("fish")

    profile = tmp_path / "profile.ps1"
    profile.write_text("before\n", encoding="utf-8")
    path = cli._install_completion("powershell", str(profile))
    assert path == profile.resolve()
    assert cli.INSTALL_MARKER_START in profile.read_text(encoding="utf-8")
    path = cli._install_completion("powershell", str(profile))
    assert path == profile.resolve()

    cli._print_completion("powershell")
    assert "Register-ArgumentCompleter" in capsys.readouterr().out
    assert cli._normalize_cwd(str(tmp_path)) == str(tmp_path.resolve())

    monkeypatch.setattr(cli, "_render_presets_table", lambda: None)
    monkeypatch.setattr(cli.console, "print", lambda *args, **kwargs: None)
    monkeypatch.setattr(cli.Prompt, "ask", lambda *args, **kwargs: "custom")
    assert cli._prompt_wizard_target() == "custom"

    prompt_answers = iter(["pane-a", "echo hi", "pane-b"])
    confirm_answers = iter([True, False])
    monkeypatch.setattr(cli.Prompt, "ask", lambda *args, **kwargs: next(prompt_answers))
    monkeypatch.setattr(cli.Confirm, "ask", lambda *args, **kwargs: next(confirm_answers))
    titles, commands = cli._prompt_wizard_spec(2, None)
    assert titles == ["pane-a", "pane-b"]
    assert commands == [("echo", "hi")]

    monkeypatch.setattr(cli, "_prompt_wizard_target", lambda: "dev")
    prompt_answers = iter([str(tmp_path)])
    monkeypatch.setattr(cli.Prompt, "ask", lambda *args, **kwargs: next(prompt_answers))
    monkeypatch.setattr(cli, "_prompt_wizard_spec", lambda pane_count, preset: (["a", "b", "c"], [("pwsh",)]))
    monkeypatch.setattr(cli, "_build_pane_specs", lambda *args, **kwargs: (cli.PaneSpec("a"),))
    previewed = []
    launched = []
    monkeypatch.setattr(cli.Confirm, "ask", lambda *args, **kwargs: True)
    monkeypatch.setattr(cli, "_preview_layout", lambda *args: previewed.append(args))
    monkeypatch.setattr(cli, "_build_wt_command", lambda pane_specs, cwd: ["wt.exe"])
    monkeypatch.setattr(cli, "_run_command", lambda command: launched.append(command))
    monkeypatch.setattr(cli, "_remember_layout", lambda target: launched.append(("remember", target)))
    assert cli._run_wizard(parser, _args()) == 0
    assert previewed and ("remember", "dev") in launched


def test_cli_menu_and_main_branches(monkeypatch):
    cli = _load_cli_module()
    parser = _Parser()
    tmp_path = _sandbox("cli_menu")
    args = _args(cwd=str(tmp_path))

    monkeypatch.setattr(cli, "_menu_preview_header", lambda: None)
    monkeypatch.setattr(cli, "_render_main_menu", lambda: None)
    monkeypatch.setattr(cli.console, "print", lambda *args, **kwargs: None)
    monkeypatch.setattr(cli, "_menu_prompt", lambda title, options: "recent")
    monkeypatch.setattr(cli, "_load_recent_layouts", lambda: [])
    assert cli._run_menu(parser, args) == 0

    prompts = iter(["recent", "7"])
    monkeypatch.setattr(cli, "_menu_prompt", lambda title, options: next(prompts))
    monkeypatch.setattr(cli, "_load_recent_layouts", lambda: ["3"])
    monkeypatch.setattr(cli, "_launch_layout", lambda *args, **kwargs: 7)
    assert cli._run_menu(parser, args) == 7

    for choice in ["suggest", "completion", "install-completion"]:
        monkeypatch.setattr(cli, "_menu_prompt", lambda title, options, choice=choice: choice)
        monkeypatch.setattr(cli, "_render_suggestions", lambda: None)
        monkeypatch.setattr(cli, "_print_completion", lambda shell: None)
        monkeypatch.setattr(cli, "_install_completion", lambda shell, profile: tmp_path / "profile")
        monkeypatch.setattr(cli, "_print_install_result", lambda path, shell: None)
        assert cli._run_menu(parser, args) == 0

    prompts = iter(["custom", "2", "pane-1", "pane-2", str(tmp_path), "pwsh -NoExit"])
    confirms = iter([True, False])
    monkeypatch.setattr(cli, "_menu_prompt", lambda title, options: next(prompts))
    monkeypatch.setattr(cli.Prompt, "ask", lambda *args, **kwargs: next(prompts))
    monkeypatch.setattr(cli.Confirm, "ask", lambda *args, **kwargs: next(confirms))
    monkeypatch.setattr(cli, "_launch_layout", lambda *args, **kwargs: 11)
    assert cli._run_menu(parser, args) == 11

    monkeypatch.setattr(cli, "_menu_prompt", lambda title, options: "dry-run")
    prompt_answers = iter(["dev"])
    monkeypatch.setattr(cli.Prompt, "ask", lambda *args, **kwargs: next(prompt_answers))
    monkeypatch.setattr(cli, "_show_command_preview", lambda command: None)
    monkeypatch.setattr(cli, "_build_wt_command", lambda pane_specs, cwd: ["wt.exe"])
    assert cli._run_menu(parser, args) == 0

    monkeypatch.setattr(cli, "_menu_prompt", lambda title, options: "weird")
    with pytest.raises(RuntimeError):
        cli._run_menu(parser, args)

    monkeypatch.setattr(cli, "_menu_box", lambda *args, **kwargs: None)
    monkeypatch.setattr(cli, "_menu_prompt", lambda title, options: "back")
    monkeypatch.setattr(cli, "_run_menu", lambda parser, args: 5)
    assert cli._preset_submenu(parser, args, cli.PRESETS["dev"]) == 5

    for action in ["preview", "dry-run", "launch"]:
        monkeypatch.setattr(cli, "_menu_prompt", lambda title, options, action=action: action)
        monkeypatch.setattr(cli, "_preview_layout", lambda *args: None)
        monkeypatch.setattr(cli, "_show_command_preview", lambda command: None)
        monkeypatch.setattr(cli, "_build_wt_command", lambda pane_specs, cwd: ["wt.exe"])
        monkeypatch.setattr(cli, "_run_command", lambda command: None)
        monkeypatch.setattr(cli, "_remember_layout", lambda target: None)
        assert cli._preset_submenu(parser, args, cli.PRESETS["dev"]) == 0

    confirm_answers = iter([True, True])
    monkeypatch.setattr(cli, "_menu_prompt", lambda title, options: "customize")
    monkeypatch.setattr(cli, "_prompt_wizard_spec", lambda pane_count, preset: (["x", "y", "z"], [("pwsh",)]))
    monkeypatch.setattr(cli.Confirm, "ask", lambda *args, **kwargs: next(confirm_answers))
    monkeypatch.setattr(cli, "_preview_layout", lambda *args: None)
    monkeypatch.setattr(cli, "_show_command_preview", lambda command: None)
    assert cli._preset_submenu(parser, args, cli.PRESETS["dev"]) == 0

    monkeypatch.setattr(cli, "_menu_prompt", lambda title, options: "invalid")
    with pytest.raises(RuntimeError):
        cli._preset_submenu(parser, args, cli.PRESETS["dev"])

    class _MainParser:
        def __init__(self, namespace):
            self.namespace = namespace
            self.errors = []

        def parse_args(self, argv):
            return self.namespace

        def error(self, message):
            self.errors.append(message)
            raise RuntimeError(message)

    monkeypatch.setattr(cli, "_build_parser", lambda: _MainParser(_args(list_presets=True)))
    monkeypatch.setattr(cli, "_render_presets_table", lambda: None)
    assert cli.main([]) == 0

    monkeypatch.setattr(cli, "_build_parser", lambda: _MainParser(_args(install_completion=True)))
    monkeypatch.setattr(cli, "_install_completion", lambda shell, profile: tmp_path / "profile")
    monkeypatch.setattr(cli, "_print_install_result", lambda path, shell: None)
    assert cli.main([]) == 0

    monkeypatch.setattr(cli, "_build_parser", lambda: _MainParser(_args()))
    monkeypatch.setattr(cli, "_is_windows", lambda: False)
    with pytest.raises(RuntimeError):
        cli.main([])

    monkeypatch.setattr(cli, "_is_windows", lambda: True)
    for namespace, func_name, func in [
        (_args(target="wizard"), "_run_wizard", lambda parser, args: 1),
        (_args(target="menu"), "_run_menu", lambda parser, args: 2),
        (_args(target="suggest"), "_render_suggestions", lambda: None),
    ]:
        monkeypatch.setattr(cli, "_build_parser", lambda ns=namespace: _MainParser(ns))
        monkeypatch.setattr(cli, func_name, func)
        result = cli.main([])
        assert result in {0, 1, 2}

    monkeypatch.setattr(cli, "_build_parser", lambda: _MainParser(_args(target="completion", extra="bash")))
    monkeypatch.setattr(cli, "_print_completion", lambda shell: None)
    assert cli.main([]) == 0

    monkeypatch.setattr(cli, "_build_parser", lambda: _MainParser(_args(target="4")))
    monkeypatch.setattr(cli, "_launch_layout", lambda *args, **kwargs: 9)
    assert cli.main([]) == 9

    for exc in [
        argparse.ArgumentTypeError("bad"),
        cli.CliError("bad"),
        FileNotFoundError(),
        subprocess.CalledProcessError(7, "wt"),
    ]:
        monkeypatch.setattr(cli, "_build_parser", lambda: _MainParser(_args(target="4")))
        monkeypatch.setattr(cli, "_launch_layout", lambda *args, exc=exc, **kwargs: (_ for _ in ()).throw(exc))
        with pytest.raises(RuntimeError):
            cli.main([])
