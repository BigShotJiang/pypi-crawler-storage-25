from __future__ import annotations

from pathlib import Path

import pytest

from soigia.domain import run_tests


def test_collect_test_files_supports_default_targets_and_deduplicates():
    collected = run_tests.collect_test_files()

    assert collected
    assert any(path.endswith(str(Path("anki") / "tests.py")) for path in collected)
    assert len(collected) == len(set(collected))


def test_collect_test_files_accepts_app_name_and_explicit_path():
    anki_path = Path(run_tests.PACKAGE_DIR) / "anki" / "tests.py"

    assert run_tests.collect_test_files(["anki"]) == [str(anki_path)]
    assert run_tests.collect_test_files([str(anki_path), "anki"]) == [str(anki_path.resolve())]


def test_collect_test_files_raises_for_missing_target():
    with pytest.raises(FileNotFoundError):
        run_tests.collect_test_files(["missing-app"])


def test_build_parser_and_main_paths(monkeypatch):
    parser = run_tests.build_parser()
    args = parser.parse_args(["anki"])
    assert args.targets == ["anki"]

    monkeypatch.setattr(run_tests, "collect_test_files", lambda targets=None: ["x/tests.py"])
    captured = {}

    class FakePytest:
        @staticmethod
        def main(argv):
            captured["argv"] = argv
            return 7

    monkeypatch.setitem(__import__("sys").modules, "pytest", FakePytest)

    assert run_tests.main(["anki", "-q"]) == 7
    assert captured["argv"] == ["x/tests.py", "-q"]


def test_main_raises_system_exit_when_no_domain_tests(monkeypatch):
    monkeypatch.setattr(run_tests, "collect_test_files", lambda targets=None: [])

    with pytest.raises(SystemExit, match="no domain tests found"):
        run_tests.main([])

