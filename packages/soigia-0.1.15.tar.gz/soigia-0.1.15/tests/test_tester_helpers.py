from __future__ import annotations

import runpy
import sys
import time
from pathlib import Path

import pytest

import soigia.tester as tester_mod
from soigia.tester import CommandResult, TestMode, TestPlan, TestRecipe, Tester


def _sandbox(name: str) -> Path:
    path = Path.cwd() / ".test_artifacts" / f"{name}_{time.time_ns()}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def test_tester_low_level_helpers_and_mode_objects(monkeypatch):
    root = _sandbox("tester_helpers_root")
    monkeypatch.chdir(root)

    assert tester_mod._slug("  a/b c  ") == "a_b_c"
    assert tester_mod._as_path("x.txt").name == "x.txt"
    assert tester_mod._norm("a\r\nb \r\n") == "a\nb"

    text_path = root / "rows.tsv"
    tester_mod._write_csv(text_path, [[" a ", "b"], ["c", " d "]])
    assert tester_mod._csv_rows(text_path) == [["a", "b"], ["c", "d"]]
    assert tester_mod._read_text(text_path).startswith(" a ")

    spec = tester_mod.TEST_MODE_SPECS[0]
    recipe = tester_mod.TEST_MODE_RECIPES[0]
    assert spec.as_dict()["mode"] == spec.mode.value
    assert "# FlowTest Recipe" in recipe.as_markdown()

    plan = TestPlan(mode=TestMode.FLOW, subject="My Subject", case="Case A", recipe=recipe)
    assert plan.name == "flow_My_Subject_Case_A"
    assert plan.title == "FlowTest Recipe"
    assert plan.as_dict()["recipe"]["mode"] == "flow"
    assert "Case" in plan.as_markdown()
    assert plan.with_recipe(recipe).recipe is recipe


def test_tester_taxonomy_guides_recommendations_and_io():
    tester = Tester(root=_sandbox("tester_taxonomy"))

    assert tester.mode_spec("flow").mode is TestMode.FLOW
    assert tester.recipe("step").mode is TestMode.STEP
    assert tester.flow_recipe().mode is TestMode.FLOW
    assert tester.step_recipe().mode is TestMode.STEP
    assert tester.snapshot_recipe().mode is TestMode.SNAPSHOT
    assert tester.contract_recipe().mode is TestMode.CONTRACT
    assert tester.flow_plan("sales").mode is TestMode.FLOW
    assert tester.step_plan("normalize").mode is TestMode.STEP
    assert tester.snapshot_plan("report").mode is TestMode.SNAPSHOT
    assert tester.contract_plan("api").mode is TestMode.CONTRACT
    assert tester.flow_case("sales", "ok").case == "ok"
    assert tester.http_contract("rest").mode is TestMode.CONTRACT
    assert tester.boundary_contract("sheet", "sync").subject == "sheet_sync"
    assert tester.execute(TestPlan(mode=TestMode.FLOW, subject="sales")).__class__.__name__ == "PipelineScenario"
    assert tester.execute(TestPlan(mode=TestMode.STEP, subject="step")).__class__.__name__ == "Scenario"
    assert tester.start(TestPlan(mode=TestMode.STEP, subject="step")).__class__.__name__ == "Scenario"
    assert tester.run(TestPlan(mode=TestMode.STEP, subject="step")).__class__.__name__ == "Scenario"
    assert tester.recipes() == tester_mod.TEST_MODE_RECIPES
    assert "modes" in tester.taxonomy()
    assert "Soigia Test Taxonomy" in tester.mode_guide()
    assert "flow" in tester.examples()
    assert "Soigia Tester Examples" in tester.examples_markdown()
    assert "Soigia Test Recipes" in tester.recipe_markdown()
    assert "recipes" in tester.recipe_guide()
    assert tester.naming_convention()["file_pattern"].startswith("tests/")
    assert tester.test_name("flow", "sales flow", "happy path") == "test_flow_sales_flow_happy_path"
    assert tester.recommend_mode("csv snapshot artifact") is TestMode.SNAPSHOT
    assert tester.recommend_mode("api contract") is TestMode.CONTRACT
    assert tester.recommend_mode("isolated unit step") is TestMode.STEP
    assert tester.recommend_mode("full pipeline flow") is TestMode.FLOW

    tester.write_json("a.json", {"x": 1})
    assert tester.read_json("a.json") == {"x": 1}
    tester.write_yaml("a.yaml", {"x": 1})
    assert tester.read_yaml("a.yaml") == {"x": 1}
    tester.write_csv("a.tsv", [["x"], ["1"]])
    assert tester.read_csv("a.tsv") == [["x"], ["1"]]
    sqlite_path = tester.write_sqlite_table("a.db", [{"id": 1, "name": "Alice"}], table_name="demo")
    assert sqlite_path.exists()
    empty_sqlite = tester.write_sqlite_table("b.db", [], table_name="demo")
    assert empty_sqlite.exists()
    assert tester.golden_dir().name == "golden"


def test_tester_invalid_mode_and_command_result():
    tester = Tester()

    with pytest.raises(ValueError):
        tester.mode_spec("bad")
    with pytest.raises(ValueError):
        tester.recipe("bad")
    with pytest.raises(ValueError):
        tester.plan("bad", "subject")

    result = CommandResult(
        command=["python", "-V"],
        cwd=Path.cwd(),
        returncode=1,
        stdout="out",
        stderr="err",
        duration_seconds=0.1,
        started_at=1.0,
        finished_at=1.1,
    )
    assert result.success is False
    assert "Command failed" in result.format_failure()
    assert result.as_dict()["success"] is False
    with pytest.raises(AssertionError):
        result.check()


def test_tester_main_entrypoints(monkeypatch):
    monkeypatch.setattr(tester_mod, "main", lambda argv=None: 5, raising=False)
    module = runpy.run_module("soigia.tester", run_name="__main__")
    assert module["__name__"] == "__main__"
    assert "soigia.tester" in sys.modules


def test_tester_scenario_and_ui_runtime_branches(monkeypatch):
    tester = Tester(root=_sandbox("tester_runtime"))
    scenario = tester.scenario("Case 1")
    source = tester.write_text("source.txt", "copied")
    scenario.given_text("a.txt", "hello").given_json("a.json", {"x": 1}).given_yaml("a.yaml", {"x": 1})
    scenario.given_csv("a.tsv", [["id"], ["1"]]).given_file(source, "copy.txt")

    ok_result = CommandResult(["cmd"], Path.cwd(), 0, "stdout ok", "stderr ok", 0.1, 1.0, 1.1)
    scenario.result = ok_result
    scenario.then_exit_code(0).then_no_traceback().then_stdout_contains("stdout").then_stderr_contains("stderr")
    scenario.then_file_exists("a.txt").then_text_contains("a.txt", "hello").then_text_equals("a.txt", "hello")
    scenario.then_json_equals("a.json", {"x": 1}).then_yaml_equals("a.yaml", {"x": 1}).then_csv_equals("a.tsv", [["id"], ["1"]])
    sqlite_rel = "case.db"
    tester.write_sqlite_table(str(scenario.path(sqlite_rel).relative_to(tester.artifacts_dir())), [{"id": 1}], table_name="data")
    scenario.then_sqlite_row_count(sqlite_rel, 1)
    assert scenario.dump_debug().exists()

    for action in (
        lambda: tester.scenario("bad").then_exit_code(),
        lambda: tester.scenario("bad").then_no_traceback(),
    ):
        with pytest.raises(AssertionError):
            action()

    failing = tester.scenario("fail").given_text("a.txt", "hello")
    failing.result = CommandResult(["cmd"], Path.cwd(), 1, "x", "Traceback: boom", 0.1, 1.0, 1.1)
    with pytest.raises(AssertionError): failing.then_exit_code(0)
    with pytest.raises(AssertionError): failing.then_no_traceback()
    with pytest.raises(AssertionError): failing.then_stdout_contains("missing")
    with pytest.raises(AssertionError): failing.then_stderr_contains("missing")
    with pytest.raises(AssertionError): failing.then_file_exists("missing.txt")
    with pytest.raises(AssertionError): failing.then_text_contains("a.txt", "missing")
    with pytest.raises(AssertionError): failing.then_text_equals("a.txt", "other")

    pipe = tester.pipeline("Pipe")
    pipe_dir = tester.root_dir() / "data" / "Pipe"
    pipe_dir.mkdir(parents=True, exist_ok=True)
    (pipe_dir / "pipeline_summary.md").write_text("summary ok", encoding="utf-8")
    log_dir = tester.root_dir() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    (log_dir / "Pipe.log").write_text("log ok", encoding="utf-8")
    pipe_csv = pipe_dir / "result.tsv"
    tester_mod._write_csv(pipe_csv, [["id"], ["1"]])
    with tester_mod.sqlite3.connect(pipe_dir / "data.db") as connection:
        connection.execute('CREATE TABLE IF NOT EXISTS data ("id" TEXT)')
        connection.execute("DELETE FROM data")
        connection.execute('INSERT INTO data ("id") VALUES (?)', ["1"])
        connection.commit()
    pipe.then_pipeline_summary_exists().then_pipeline_summary_contains("summary")
    pipe.then_pipeline_log_contains("log").then_pipeline_artifact_exists("result.tsv")
    pipe.then_pipeline_csv_equals("result.tsv", [["id"], ["1"]]).then_pipeline_sqlite_row_count("data.db", 1)

    with pytest.raises(AssertionError): tester.pipeline("Missing").then_pipeline_summary_exists()
    with pytest.raises(AssertionError): tester.pipeline("Missing").then_pipeline_log_contains("x")
    with pytest.raises(AssertionError): tester.pipeline("Missing").then_pipeline_artifact_exists("x")

    copied = tester.copy_file(source, "copied.txt")
    tester.write_json("a.json", {"x": 1})
    tester.write_yaml("a.yaml", {"x": 1})
    tester.write_csv("a.tsv", [["id"], ["1"]])
    assert copied.exists()
    tester.assert_file_exists("copied.txt")
    tester.assert_text_contains("copied.txt", "copied")
    tester.assert_text_equals("copied.txt", "copied")
    tester.assert_json_equals("a.json", {"x": 1})
    tester.assert_yaml_equals("a.yaml", {"x": 1})
    tester.assert_csv_equals("a.tsv", [["id"], ["1"]])
    tester.assert_sqlite_row_count(str(scenario.path(sqlite_rel).relative_to(tester.artifacts_dir())), 1)
    tester.assert_sqlite_columns(str(scenario.path(sqlite_rel).relative_to(tester.artifacts_dir())), ["id"])
    tester.cleanup()


def test_tester_subprocess_wrappers(monkeypatch):
    tester = Tester(root=_sandbox("tester_subprocess"))

    class Completed:
        returncode = 0
        stdout = "ok"
        stderr = ""

    monkeypatch.setattr(tester_mod.subprocess, "run", lambda *args, **kwargs: Completed())
    assert tester.run_command(["python", "-V"], check=True).success is True
    assert tester.run_module("demo.mod").success is True
    script = tester.write_text("script.py", "print('x')")
    assert tester.run_script(script).success is True

    pipeline_tester = tester_mod.PipelineTester(root=tester.root_dir())
    assert pipeline_tester.pipeline_dir("Pipe").name == "Pipe"
    assert pipeline_tester.pipeline_summary_path("Pipe").name == "pipeline_summary.md"
    assert pipeline_tester.pipeline_log_path("Pipe").name == "Pipe.log"

    class Proc:
        def __init__(self):
            self.returncode = None
            self._polls = 0
        def poll(self):
            self._polls += 1
            return None if self._polls == 1 else 0
        def terminate(self): self.returncode = 0
        def kill(self): self.returncode = -9
        def communicate(self, timeout=None): self.returncode = self.returncode if self.returncode is not None else 0; return ("out", "err")

    monkeypatch.setattr(tester_mod.subprocess, "Popen", lambda *args, **kwargs: Proc())

    class _Opened:
        def __enter__(self): return self
        def __exit__(self, exc_type, exc, tb): return False

    monkeypatch.setattr(tester_mod.urllib.request, "urlopen", lambda *args, **kwargs: _Opened())
    ui_tester = tester_mod.UITester(root=tester.root_dir())
    assert ui_tester.run_streamlit_script(script).returncode == 0
