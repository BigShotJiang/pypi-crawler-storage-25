from __future__ import annotations

from importlib import import_module


EMBEDDED_TEST_MODULES = [
    "soigia.domain.anki.tests",
    "soigia.domain.common.tests",
    "soigia.domain.crm.tests",
    "soigia.domain.inventory.tests",
    "soigia.domain.obsidian.tests",
    "soigia.domain.purchases.tests",
    "soigia.domain.rent.tests",
    "soigia.domain.sales.tests",
    "soigia.domain.sales_subscription.tests",
    "soigia.domain.sheets.tests",
]


def _wrap_test_function(function):
    def _wrapped():
        function()

    _wrapped.__name__ = function.__name__
    _wrapped.__doc__ = function.__doc__
    return _wrapped


for module_name in EMBEDDED_TEST_MODULES:
    module = import_module(module_name)
    namespace = module_name.rsplit(".", 2)[-2]
    for attribute_name, attribute_value in vars(module).items():
        if attribute_name.startswith("test_") and callable(attribute_value):
            globals()[f"test_{namespace}__{attribute_name[5:]}"] = _wrap_test_function(attribute_value)

