from __future__ import annotations

from contextlib import contextmanager
import runpy
import sys
from types import SimpleNamespace

import pandas as pd
import pytest

import soigia.ui as ui_mod


class _FakeBlock:
    def __init__(self, owner, name):
        self.owner = owner
        self.name = name

    def __enter__(self):
        self.owner.calls.append((self.name, "enter"))
        return self.owner

    def __exit__(self, exc_type, exc, tb):
        self.owner.calls.append((self.name, "exit"))
        return False


class _FakeRenderer:
    def __init__(self):
        self.calls = []
        self.session_state = {}
        self._button_results = []
        self._download_results = []
        self._number_results = []

    def _record(self, name, *args, **kwargs):
        self.calls.append((name, args, kwargs))

    def __enter__(self):
        self.calls.append(("enter", (), {}))
        return self

    def __exit__(self, exc_type, exc, tb):
        self.calls.append(("exit", (), {}))
        return False

    def title(self, value): self._record("title", value)
    def header(self, value): self._record("header", value)
    def subheader(self, value): self._record("subheader", value)
    def caption(self, value): self._record("caption", value)
    def markdown(self, value): self._record("markdown", value)
    def code(self, value): self._record("code", value)
    def json(self, value): self._record("json", value)
    def success(self, value): self._record("success", value)
    def info(self, value): self._record("info", value)
    def warning(self, value): self._record("warning", value)
    def error(self, value): self._record("error", value)
    def write(self, value): self._record("write", value)
    def divider(self): self._record("divider")
    def metric(self, label, value, **kwargs): self._record("metric", label, value, **kwargs)
    def dataframe(self, frame, **kwargs): self._record("dataframe", frame.copy(), **kwargs)
    def data_editor(self, frame, **kwargs): self._record("data_editor", frame.copy(), **kwargs); return frame
    def file_uploader(self, *args, **kwargs): self._record("file_uploader", *args, **kwargs); return "uploaded"
    def text_area(self, *args, **kwargs): self._record("text_area", *args, **kwargs); return "area"
    def text_input(self, *args, **kwargs): self._record("text_input", *args, **kwargs); return "text"
    def checkbox(self, *args, **kwargs): self._record("checkbox", *args, **kwargs); return True
    def selectbox(self, *args, **kwargs):
        self._record("selectbox", *args, **kwargs)
        options = kwargs.get("options")
        if options is None and len(args) > 1:
            options = args[1]
        return list(options)[0]
    def number_input(self, *args, **kwargs):
        self._record("number_input", *args, **kwargs)
        return self._number_results.pop(0) if self._number_results else kwargs["value"]
    def button(self, *args, **kwargs):
        self._record("button", *args, **kwargs)
        return self._button_results.pop(0) if self._button_results else False
    def download_button(self, *args, **kwargs):
        self._record("download_button", *args, **kwargs)
        return self._download_results.pop(0) if self._download_results else False
    def columns(self, specs):
        self._record("columns", specs)
        count = specs if isinstance(specs, int) else len(specs)
        return [_FakeRenderer() for _ in range(count)]
    def tabs(self, labels):
        self._record("tabs", labels)
        return [_FakeRenderer() for _ in labels]
    def expander(self, label, **kwargs):
        self._record("expander", label, **kwargs)
        return _FakeBlock(self, "expander")
    def popover(self, label):
        self._record("popover", label)
        return _FakeBlock(self, "popover")
    def container(self, **kwargs):
        self._record("container", **kwargs)
        return _FakeBlock(self, "container")

    @property
    def sidebar(self):
        self._record("sidebar")
        return self

    def set_page_config(self, **kwargs): self._record("set_page_config", **kwargs)
    def rerun(self): self._record("rerun")
    def stop(self): self._record("stop")


class _CallableNoSignature:
    __signature__ = None

    def __call__(self):
        return "no-signature"


def _two_args(value=None, other=None):
    return value, other


def test_ui_helper_functions_and_nodes(monkeypatch):
    fake_st = _FakeRenderer()
    monkeypatch.setattr(ui_mod, "st", fake_st)
    context = ui_mod.RenderContext(app=ui_mod.App(), st=fake_st)

    assert ui_mod._slugify(" Hello World ") == "hello_world"
    assert ui_mod._make_key("text", "Hello", None, 1).startswith("text:hello:")
    assert ui_mod._container_width_value(True) == "stretch"
    assert ui_mod._coerce_callable("x", context) == "x"
    assert ui_mod._coerce_callable(lambda: "a", context) == "a"
    assert ui_mod._coerce_callable(lambda ctx: ctx, context) is context
    assert ui_mod._coerce_callable(lambda *args: args[0], context) is context
    assert ui_mod._coerce_callable(_two_args, context) == (None, None)
    assert ui_mod._coerce_callable(_CallableNoSignature(), context) == "no-signature"

    called = []
    ui_mod._invoke_callback(lambda: called.append("noarg"), context)
    ui_mod._invoke_callback(lambda ctx: called.append(ctx.app.__class__.__name__), context)
    ui_mod._invoke_callback(lambda *args: called.append(type(args[0]).__name__), context)
    ui_mod._invoke_callback(_two_args, context)
    ui_mod._invoke_callback(None, context)
    assert called == ["noarg", "App", "RenderContext"]

    for kind in ["title", "header", "subheader", "caption", "markdown", "code", "json", "success", "info", "warning", "error", "text"]:
        node = ui_mod.TextNode(label="More", value="abcdef", kind=kind, truncate_at=3, expandable=True)
        node.render(context)
    assert any(name == "expander" for name, _, _ in fake_st.calls)

    ui_mod.DividerNode().render(context)
    ui_mod.MetricNode(label="M", value=lambda ctx: 2, delta=lambda ctx: 1).render(context)

    class ToDf:
        def to_df(self):
            return pd.DataFrame([{"x": 1}])

    frame = pd.DataFrame([{"x": 1}])
    assert ui_mod.TableNode(data=frame)._to_frame(frame) is frame
    assert list(ui_mod.TableNode(data=None)._to_frame({"x": [1]}).columns) == ["x"]
    assert list(ui_mod.TableNode(data=None)._to_frame([{"x": 1}]).columns) == ["x"]
    assert list(ui_mod.TableNode(data=None)._to_frame(ToDf()).columns) == ["x"]
    assert list(ui_mod.TableNode(data=object())._to_frame(object()).columns) == [0]
    assert ui_mod.TableNode(data=[]).render(context).empty
    fake_st._number_results = [1]
    table = ui_mod.TableNode(data=[{"id": 1}, {"id": 2}, {"id": 3}], paginate=True, page_size=2, editable=True, height=50)
    rendered = table.render(context)
    assert list(rendered.columns) == ["id"]
    ui_mod.TableNode(data=[{"id": 1}], height=20).render(context)

    upload = ui_mod.FileUploadNode(label="Upload", type=["csv"])
    assert upload.render(context) == "uploaded"
    fake_st.session_state[upload.key] = "from-state"
    assert upload.value == "from-state"

    clicked = []
    fake_st._download_results = [True]
    assert ui_mod.DownloadButtonNode(label="Download", data=b"x", on_click=lambda ctx: clicked.append("download")).render(context) is True
    assert clicked == ["download"]

    assert ui_mod.InputNode(label="Text").render(context) == "text"
    assert ui_mod.InputNode(label="Area", kind="textarea").render(context) == "area"
    assert ui_mod.InputNode(label="Check", kind="checkbox", default=True).render(context) is True
    assert ui_mod.InputNode(label="Select", kind="select", options=["a", "b"], default="b").render(context) == "a"
    assert ui_mod.InputNode(label="Number", kind="number", default=5, step=1).render(context) == 5

    fake_st._button_results = [True, True]
    button_hits = []
    assert ui_mod.ButtonNode(label="Go", on_click=lambda ctx: button_hits.append("go")).render(context) is True
    assert button_hits == ["go"]


def test_ui_containers_app_and_top_level_helpers(monkeypatch):
    fake_st = _FakeRenderer()
    monkeypatch.setattr(ui_mod, "st", fake_st)

    app = ui_mod.App(title="Demo", page_icon="X")
    app.text("root")
    with app.sidebar("Side") as side:
        side.add(ui_mod.TextNode(value="sidebar"))
    with app.columns([1, 2])[0] as col:
        col.add(ui_mod.TextNode(value="column"))
    with app.tabs(["A", "B"])[0] as tab:
        tab.add(ui_mod.TextNode(value="tab"))
    with app.form("Form", on_submit=lambda ctx: None) as form:
        form.add(ui_mod.TextNode(value="form"))
    with app.dialog("Dialog", on_open=lambda ctx: None) as dialog:
        dialog.add(ui_mod.TextNode(value="dialog"))
    with app.section("Section", level=4) as section:
        section.add(ui_mod.TextNode(value="section"))
    with app.expander("Expand", expanded=True) as exp:
        exp.add(ui_mod.TextNode(value="expand"))

    @app.page("Page")
    def _page(ctx):
        app.text("page-body")

    app.render()
    assert any(name == "set_page_config" for name, _, _ in fake_st.calls)
    assert app._root_nodes == []

    app2 = ui_mod.App()
    with app2._push(ui_mod.SectionNode(label="Ctx")) as pushed:
        pushed.add(ui_mod.TextNode(value="inside"))
    assert app2._root_nodes
    app2.clear()
    assert app2._root_nodes == []

    monkeypatch.setattr(ui_mod, "st", SimpleNamespace(session_state={}, rerun=lambda: "rerun", stop=lambda: "stop"))
    assert app2.state_get("x", 1) == 1
    assert app2.state_set("x", 2) == 2
    app2.state_delete("x")

    monkeypatch.setattr(ui_mod, "st", None)
    assert ui_mod.RenderContext(app=app2, st=SimpleNamespace(session_state={"x": 1})).session_state == {"x": 1}
    app2.rerun()
    app2.stop()
    assert app2.state_set("a", 1) == 1
    app2.state_get("a", 9) == 9
    app2.state_delete("a")

    with pytest.raises(RuntimeError):
        ui_mod.SidebarNode().__enter__()
    with pytest.raises(RuntimeError):
        ui_mod.ColumnNode().__enter__()
    with pytest.raises(RuntimeError):
        ui_mod.TabNode().__enter__()
    with pytest.raises(RuntimeError):
        ui_mod.FormNode().__enter__()
    with pytest.raises(RuntimeError):
        ui_mod.DialogNode().__enter__()
    with pytest.raises(RuntimeError):
        ui_mod.SectionNode().__enter__()
    with pytest.raises(RuntimeError):
        ui_mod.ExpanderNode().__enter__()

    singleton = ui_mod.ui
    singleton.clear()
    ui_mod.text("hello")
    ui_mod.markdown("md")
    ui_mod.code("print(1)")
    ui_mod.divider()
    ui_mod.json({"x": 1})
    ui_mod.success("ok")
    ui_mod.info("ok")
    ui_mod.warning("ok")
    ui_mod.error("ok")
    ui_mod.metric("M", 1)
    ui_mod.text_input("Text")
    ui_mod.ui.title("T")
    ui_mod.ui.header("H")
    ui_mod.ui.subheader("S")
    ui_mod.ui.caption("C")
    ui_mod.textbox("Textbox")
    ui_mod.text_area("Area")
    ui_mod.textarea("Area2")
    ui_mod.checkbox("Check")
    ui_mod.select("Select", ["a"])
    ui_mod.ui.number_input("N")
    ui_mod.button("Button")
    ui_mod.file_uploader("Upload")
    ui_mod.download_button("Download", b"x")
    ui_mod.table([{"id": 1}])
    ui_mod.sidebar("Side")
    ui_mod.columns(2)
    ui_mod.tabs(["A"])
    ui_mod.section("Section")
    ui_mod.expander("Exp")
    ui_mod.form("Form")
    ui_mod.dialog("Dialog")
    assert singleton._root_nodes or singleton._sidebar_nodes


def test_ui_remaining_branches_and_module_entrypoint(monkeypatch):
    fake_st = _FakeRenderer()
    monkeypatch.setattr(ui_mod, "st", fake_st)
    context = ui_mod.RenderContext(app=ui_mod.App(), st=fake_st)

    class _SentinelCallable:
        def __call__(self):
            return "called"

    sentinel = _SentinelCallable()
    original_signature = ui_mod.inspect.signature
    ui_mod.inspect.signature = lambda value: (_ for _ in ()).throw(TypeError("bad")) if value is sentinel else original_signature(value)
    try:
        assert ui_mod._coerce_callable(sentinel, context) == "called"
        ui_mod._invoke_callback(sentinel, context)
    finally:
        ui_mod.inspect.signature = original_signature

    with pytest.raises(NotImplementedError):
        ui_mod.Node().render(context)

    assert ui_mod.TextNode(visible=False).render(context) is None
    assert ui_mod.MetricNode(label="M", visible=False).render(context) is None
    assert ui_mod.TableNode(data=[{"x": 1}], visible=False).render(context) is None
    assert ui_mod.FileUploadNode(label="Up", visible=False).render(context) is None
    assert ui_mod.DownloadButtonNode(label="Down", visible=False).render(context) is False
    hidden_input = ui_mod.InputNode(label="Hidden", visible=False, default="x")
    assert hidden_input.render(context) == "x"
    fake_st.session_state["x"] = "y"
    hidden_input.key = "x"
    assert hidden_input.value == "y"
    assert ui_mod.ButtonNode(label="B", visible=False).render(context) is False

    sidebar = ui_mod.SidebarNode(label="Side", visible=False)
    sidebar.app = context.app
    assert sidebar.__exit__(None, None, None) is False
    assert sidebar.render(context) is None
    assert ui_mod.SidebarNode().__exit__(None, None, None) is False

    column = ui_mod.ColumnNode()
    column.app = context.app
    assert column.__exit__(None, None, None) is False
    assert ui_mod.ColumnNode().__exit__(None, None, None) is False

    columns = ui_mod.ColumnsNode(slots=[ui_mod.ColumnNode()], visible=False)
    assert columns.render(context) is None
    columns.visible = True
    columns.specs = 1
    columns.slots[0].children.append(ui_mod.TextNode(value="col"))
    columns.render(context)

    tab = ui_mod.TabNode()
    tab.app = context.app
    assert tab.__exit__(None, None, None) is False
    assert ui_mod.TabNode().__exit__(None, None, None) is False

    tabs = ui_mod.TabsNode(labels=["A"], slots=[ui_mod.TabNode()], visible=False)
    assert tabs.render(context) is None
    tabs.visible = True
    tabs.slots[0].children.append(ui_mod.TextNode(value="tab"))
    tabs.render(context)

    page = ui_mod.PageNode(label="Page", render_fn=None, visible=False)
    assert page.render(context) is None
    page.visible = True
    page.children.append(ui_mod.TextNode(value="child"))
    assert page.render(context) is None
    page.render_fn = sentinel
    page.render(context)
    broken = _CallableNoSignature()
    original_signature = ui_mod.inspect.signature
    ui_mod.inspect.signature = lambda value: (_ for _ in ()).throw(ValueError("bad")) if value is broken else original_signature(value)
    try:
        page.render_fn = broken
        page.render(context)
    finally:
        ui_mod.inspect.signature = original_signature

    fake_st._button_results = [True, True]
    form = ui_mod.FormNode(label="Form", on_submit=lambda ctx: None, visible=False)
    form.app = context.app
    assert form.__exit__(None, None, None) is False
    assert ui_mod.FormNode().__exit__(None, None, None) is False
    assert form.render(context) is None
    form.visible = True
    form.children.append(ui_mod.TextNode(value="inside-form"))
    assert form.render(context) is True

    class _NoPopover(_FakeRenderer):
        def __getattribute__(self, name):
            if name == "popover":
                raise AttributeError(name)
            return super().__getattribute__(name)

    no_pop = _NoPopover()
    dialog = ui_mod.DialogNode(label="D", on_open=lambda ctx: None, visible=False)
    dialog.app = context.app
    assert dialog.__exit__(None, None, None) is False
    assert ui_mod.DialogNode().__exit__(None, None, None) is False
    assert dialog.render(ui_mod.RenderContext(app=context.app, st=no_pop)) is None
    dialog.visible = True
    no_pop._button_results = [True]
    dialog.children.append(ui_mod.TextNode(value="inside-dialog"))
    assert dialog.render(ui_mod.RenderContext(app=context.app, st=no_pop)) is True
    fake_st._button_results = [True]
    dialog.render(context)

    section = ui_mod.SectionNode(label="S", visible=False)
    section.app = context.app
    assert section.__exit__(None, None, None) is False
    assert ui_mod.SectionNode().__exit__(None, None, None) is False
    assert section.render(context) is None
    for level in (1, 2, 3, 4):
        node = ui_mod.SectionNode(label="S", level=level)
        node.children.append(ui_mod.TextNode(value="section-child"))
        node.render(context)

    expander = ui_mod.ExpanderNode(label="E", visible=False)
    expander.app = context.app
    assert expander.__exit__(None, None, None) is False
    assert ui_mod.ExpanderNode().__exit__(None, None, None) is False
    assert expander.render(context) is None
    expander.visible = True
    expander.children.append(ui_mod.TextNode(value="child"))
    expander.render(context)

    app = ui_mod.App()
    with app.section_block("Block"):
        app.text("inside")
    with app.expander_block("Block2"):
        app.text("inside2")

    root_only = ui_mod.App()
    root_only.text("root")
    root_only.render()
    assert any(name == "write" for name, _, _ in fake_st.calls)

    rerun_hits = []
    monkeypatch.setattr(ui_mod, "st", None)
    with pytest.raises(RuntimeError):
        ui_mod.App().render()
    monkeypatch.setattr(ui_mod.App, "render", lambda self: rerun_hits.append("app-render"))
    ui_mod.App().run()

    stop_hits = []
    proxy_st = SimpleNamespace(session_state={}, rerun=lambda: rerun_hits.append(True), stop=lambda: stop_hits.append(True))
    monkeypatch.setattr(ui_mod, "st", proxy_st)
    monkeypatch.setattr(ui_mod.App, "run", lambda self: rerun_hits.append("run-ui"))
    ui_mod.run()
    ui_mod.rerun()
    ui_mod.stop()
    assert rerun_hits == ["app-render", "run-ui", True]
    assert stop_hits == [True]

    page_hits = []

    @ui_mod.page("Decorated")
    def _decorated():
        page_hits.append("decorated")

    ui_mod.state_set("k", 3)
    assert ui_mod.state_get("k") == 3
    ui_mod.state_delete("k")
    assert ui_mod.state_get("k", "missing") == "missing"
    assert callable(_decorated)

    monkeypatch.setitem(sys.modules, "streamlit", _FakeRenderer())
    runpy.run_module("soigia.ui", run_name="__main__")
