from __future__ import annotations

import importlib
import runpy
import sys
import types

import pytest


def _reload_soigia():
    import soigia

    return importlib.reload(soigia)


def test_soigia_lazy_exports_and_dir(monkeypatch):
    soigia = _reload_soigia()

    fake_erp = types.ModuleType("soigia.erp")
    fake_erp.Model = object()
    fake_erp.fields = object()
    fake_erp.setup = object()
    fake_erp.use_storage = object()
    monkeypatch.setitem(sys.modules, "soigia.erp", fake_erp)

    assert soigia.domain.__name__ == "soigia.domain"
    assert soigia.datatable.__name__ == "soigia.datatable"
    assert soigia.ui.__name__ == "soigia.ui"
    assert soigia.pipeline.__name__ == "soigia.pipeline"
    assert soigia.db.__name__ == "soigia.db"
    assert soigia.config.__name__ == "soigia.config"
    assert soigia.odoo_client.__name__ == "soigia.odoo_client"
    assert soigia.Tester.__name__ == "Tester"
    assert soigia._import_and_cache("domain").__name__ == "soigia.domain"
    assert soigia.Model is not None
    assert soigia.fields is not None
    assert soigia.setup is not None
    assert soigia.use_storage is not None
    assert soigia.Pipeline.__name__ == "Pipeline"
    assert soigia.BasePipeline.__name__ == "BasePipeline"
    assert soigia.FunctionStep.__name__ == "FunctionStep"
    assert soigia.ConfigStore.__name__ == "ConfigStore"
    assert soigia.DataTable.__name__ == "DataTable"
    assert soigia.df is soigia.DataTable
    assert soigia.OdooClient.__name__ == "OdooClient"
    assert "Tester" in dir(soigia)

    with pytest.raises(AttributeError):
        _ = soigia.missing_export


def test_domain_module_lazy_exports_and_dir():
    import soigia.domain as domain

    reloaded = importlib.reload(domain)
    assert reloaded.rent.__name__ == "soigia.domain.rent"
    assert reloaded.sales_subscription.__name__ == "soigia.domain.sales_subscription"
    assert reloaded.sheets.__name__ == "soigia.domain.sheets"
    assert "Money" in dir(reloaded)

    with pytest.raises(AttributeError):
        _ = reloaded.unknown_domain_module


def test_run_tests_module_main_entrypoint(monkeypatch):
    fake_pytest = types.SimpleNamespace(main=lambda argv: 9)
    monkeypatch.setitem(sys.modules, "pytest", fake_pytest)
    monkeypatch.setattr(sys, "argv", ["run_tests.py"])

    with pytest.raises(SystemExit) as exc_info:
        runpy.run_module("soigia.domain.run_tests", run_name="__main__")

    assert exc_info.value.code == 9
