from __future__ import annotations

from pathlib import Path

import pytest


def test_clean_architecture_example_modules_import():
    from examples.clean_architecture import application, domain, infrastructure, web

    assert domain.User.__name__ == "User"
    assert application.CreateUserUseCase.__name__ == "CreateUserUseCase"
    assert infrastructure.InMemoryUserRepository.__name__ == "InMemoryUserRepository"
    assert web.create_app.__name__ == "create_app"


def test_clean_architecture_use_cases_with_in_memory_repository():
    from examples.clean_architecture.application import CreateUserRequest, CreateUserUseCase, GetUserUseCase
    from examples.clean_architecture.infrastructure import InMemoryUserRepository

    repository = InMemoryUserRepository()
    create_user = CreateUserUseCase(repository)
    get_user = GetUserUseCase(repository)

    response = create_user.execute(CreateUserRequest(email="alice@example.com", username="alice"))
    assert response.success is True
    assert response.user is not None
    assert response.user.id == 1
    assert response.user.email == "alice@example.com"

    duplicate = create_user.execute(CreateUserRequest(email="alice@example.com", username="alice2"))
    assert duplicate.success is False
    assert "already exists" in duplicate.error

    fetched = get_user.execute(1)
    assert fetched.success is True
    assert fetched.user is not None
    assert fetched.user.username == "alice"


def test_clean_architecture_sqlalchemy_repository_round_trip():
    sandbox = Path.cwd() / ".test_artifacts" / "clean_architecture_sqlalchemy"
    sandbox.mkdir(parents=True, exist_ok=True)
    database_path = sandbox / "users.db"
    if database_path.exists():
        database_path.unlink()

    from examples.clean_architecture.application import CreateUserRequest, CreateUserUseCase, GetUserUseCase
    from examples.clean_architecture.infrastructure import Base, SQLAlchemyUserRepository
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    engine = create_engine(f"sqlite:///{database_path}")
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine)()
    try:
        repository = SQLAlchemyUserRepository(session)

        create_user = CreateUserUseCase(repository)
        get_user = GetUserUseCase(repository)

        response = create_user.execute(CreateUserRequest(email="bob@example.com", username="bob"))
        assert response.success is True
        assert response.user is not None
        assert response.user.id == 1

        fetched = get_user.execute(response.user.id)
        assert fetched.success is True
        assert fetched.user is not None
        assert fetched.user.email == "bob@example.com"
    finally:
        session.close()
        engine.dispose()


def test_clean_architecture_flask_app_when_available():
    pytest.importorskip("flask")

    sandbox = Path.cwd() / ".test_artifacts" / "clean_architecture_flask"
    sandbox.mkdir(parents=True, exist_ok=True)
    database_path = sandbox / "users.db"
    if database_path.exists():
        database_path.unlink()

    from examples.clean_architecture.web import create_app

    app = create_app(database_url=f"sqlite:///{database_path}")
    client = app.test_client()

    create_response = client.post("/api/users", json={"email": "carol@example.com", "username": "carol"})
    assert create_response.status_code == 201
    payload = create_response.get_json()
    assert payload["email"] == "carol@example.com"

    user_id = payload["id"]
    get_response = client.get(f"/api/users/{user_id}")
    assert get_response.status_code == 200
    assert get_response.get_json()["username"] == "carol"
