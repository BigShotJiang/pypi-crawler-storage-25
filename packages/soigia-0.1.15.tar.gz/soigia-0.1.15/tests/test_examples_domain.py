def test_domain_examples_modules_import():
    import examples.domain_customer_tiers
    import examples.domain_pipeline

    assert examples.domain_pipeline.__name__ == "examples.domain_pipeline"
    assert examples.domain_customer_tiers.__name__ == "examples.domain_customer_tiers"


def test_domain_package_reexports_common_primitives():
    from soigia import domain

    assert domain.Customer.__name__ == "Customer"
    assert domain.Order.__name__ == "Order"
    assert domain.Product.__name__ == "Product"
    assert domain.CustomerType.NORMAL.value == "normal"
    assert domain.InventoryService.__name__ == "InventoryService"
    assert domain.PricingService.__name__ == "PricingService"


def test_sales_domain_pipeline_runs_in_sandbox(monkeypatch):
    from pathlib import Path

    sandbox = Path.cwd() / ".test_artifacts" / "sales_domain_pipeline"
    sandbox.mkdir(parents=True, exist_ok=True)
    monkeypatch.chdir(sandbox)

    from examples.domain_pipeline import SalesDomainPipeline

    pipeline = SalesDomainPipeline(name="sales-domain")
    result = pipeline.run()

    assert result.success
    assert str(pipeline.model.final_total.amount) == "4275000.00"

    dump_dir = Path.cwd() / "data" / "SalesDomainPipeline"
    assert (dump_dir / "01_build_domain.csv").exists()
    assert (dump_dir / "04_summarize.csv").exists()
    summary_path = dump_dir / "pipeline_summary.md"
    assert summary_path.exists()
    summary_text = summary_path.read_text(encoding="utf-8", errors="replace")
    assert "final_total" in summary_text


def test_customer_tier_example_compares_normal_and_vip(monkeypatch):
    from pathlib import Path

    sandbox = Path.cwd() / ".test_artifacts" / "customer_tier_example"
    sandbox.mkdir(parents=True, exist_ok=True)
    monkeypatch.chdir(sandbox)

    from examples.domain_customer_tiers import run_case

    normal_discount, normal_total = run_case("Bob Tran", "normal")
    vip_discount, vip_total = run_case("Alice Nguyen", "vip")

    assert normal_discount == "250000.00"
    assert normal_total == "4750000.00"
    assert vip_discount == "500000.00"
    assert vip_total == "4500000.00"
