from __future__ import annotations

import json
import shutil
import time
from datetime import date, datetime
from pathlib import Path

import pandas as pd
import pytest

from soigia import db as db_mod


def _sandbox(name: str) -> Path:
    path = Path.cwd() / ".test_artifacts" / f"{name}_{time.time_ns()}"
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def test_db_helpers_fields_conditions_and_registry():
    assert db_mod._call_maybe(lambda: "x") == "x"
    assert db_mod._call_maybe(lambda instance: instance + 1, 2) == 3
    with pytest.raises(TypeError):
        db_mod._call_maybe(lambda instance: instance + 1)

    class Dummy:
        id = 7

    assert db_mod._normalize_related_value(None) is None
    assert db_mod._normalize_related_value(Dummy()) == 7
    assert db_mod._normalize_related_value({1, 2}) == {1, 2}
    assert db_mod._json_default(date(2024, 1, 1)) == "2024-01-01"
    assert db_mod._json_default(datetime(2024, 1, 1, 10, 0, 0)).startswith("2024-01-01T10:00:00")
    assert db_mod._json_default(Path("a")) == "a"
    assert sorted(db_mod._json_default({1, 2})) == [1, 2]
    assert db_mod._json_default(Dummy()) == 7
    with pytest.raises(TypeError):
        db_mod._json_default(object())

    conds = [
        db_mod.Condition("value", "eq", 2),
        db_mod.Condition("value", "!=", 3),
        db_mod.Condition("value", "gt", 1),
        db_mod.Condition("value", "gte", 2),
        db_mod.Condition("value", "lt", 3),
        db_mod.Condition("value", "lte", 2),
        db_mod.Condition("value", "in", [1, 2, 3]),
        db_mod.Condition("name", "contains", "bc"),
        db_mod.Condition("name", "icontains", "BC"),
        db_mod.Condition("name", "startswith", "ab"),
        db_mod.Condition("name", "istartswith", "AB"),
        db_mod.Condition("name", "endswith", "cd"),
        db_mod.Condition("name", "iendswith", "CD"),
        db_mod.Condition("other", "isnull", True),
    ]
    row = {"value": 2, "name": "abcd", "other": None}
    for condition in conds:
        assert condition.evaluate(row, type("M", (), {"_meta": type("Meta", (), {"fields": {}})()})(), None)
    assert db_mod.Condition("value", "eq", 2, negated=True).evaluate(row, type("M", (), {"_meta": type("Meta", (), {"fields": {}})()})(), None) is False
    with pytest.raises(ValueError):
        db_mod.Condition("x", "bad", 1)._compare(1, 1)

    field = db_mod.Field(default=lambda instance=None: 4)
    assert field.get_default() == 4
    assert field.validate(None) is None
    assert field.to_storage("x") == "x"
    assert field.from_storage("x") == "x"
    assert field.compute_value(type("Obj", (), {"f": lambda self: 9})()) is None
    with pytest.raises(ValueError):
        required = db_mod.Field(required=True, nullable=False)
        required.name = "x"
        required.validate(None)

    class Compute:
        value = db_mod.Field(default=1)
        doubled = db_mod.Field(compute=lambda self: self.value * 2)
        readonly = db_mod.Field(read_only=True)

        def __init__(self):
            self._values = {"value": 3}

    compute = Compute()
    Compute.doubled.name = "doubled"
    Compute.value.name = "value"
    assert Compute.doubled.__get__(compute, Compute) == 6
    with pytest.raises(AttributeError):
        Compute.readonly.name = "readonly"
        Compute.readonly.__set__(compute, 1)

    assert db_mod.String().validate(1) == "1"
    assert db_mod.Integer().validate("2") == 2
    assert db_mod.Float().validate("2.5") == 2.5
    assert db_mod.Boolean().validate("yes") is True
    assert db_mod.Date().from_storage("2024-01-02") == date(2024, 1, 2)
    assert db_mod.DateTime().from_storage("2024-01-02T03:04:05") == datetime(2024, 1, 2, 3, 4, 5)
    with pytest.raises(TypeError):
        db_mod.Date().validate(1)
    with pytest.raises(TypeError):
        db_mod.DateTime().validate(1)

    class RelBase(db_mod.Model):
        _name = "test.db.more.relbase"

        name = db_mod.fields.String()

    env = db_mod.Env(db_mod.default_registry, db_mod.MemoryBackend())
    rel = env["test.db.more.relbase"].create({"name": "A"})
    fk = db_mod.ForeignKey("test.db.more.relbase")
    m2m = db_mod.ManyToMany("test.db.more.relbase")
    assert fk.validate(rel) == rel.id
    assert m2m.validate(rel) == [rel.id]
    assert m2m.validate([rel]) == [rel.id]

    opts = db_mod.ModelOptions("x", "x")
    assert opts.model_name == "x"

    registry = db_mod.Registry()
    with pytest.raises(ValueError):
        registry.register(type("NoName", (), {"__name__": "NoName", "_meta": db_mod.ModelOptions("", "x")}))
    with pytest.raises(ValueError):
        registry.extend(type("BadExt", (db_mod.Model,), {"_inherit": None}))
    with pytest.raises(KeyError):
        registry.extend(type("BadExt2", (db_mod.Model,), {"_inherit": "missing"}))

    class BaseX(db_mod.Model):
        _name = "test.db.more.basex"

        name = db_mod.fields.String()

    class ExtX(db_mod.Model):
        _inherit = "test.db.more.basex"

        extra = db_mod.fields.String(default="x")

        def hello(self):
            return "hello"

    env2 = db_mod.Env(db_mod.default_registry, db_mod.MemoryBackend())
    rec = env2["test.db.more.basex"].create({"name": "demo"})
    assert rec.extra == "x"
    assert rec.hello() == "hello"


def test_db_backends_repository_recordsets_and_model_behaviour():
    sandbox = _sandbox("db_more")

    class Tag(db_mod.Model):
        _name = "test.db.more.tag"

        name = db_mod.fields.String(required=True)

    class Entry(db_mod.Model):
        _name = "test.db.more.entry"

        name = db_mod.fields.String(required=True)
        count = db_mod.fields.Integer(default=0)
        price = db_mod.fields.Float(default=0.0)
        active = db_mod.fields.Boolean(default=False)
        day = db_mod.fields.Date(default=lambda: date(2024, 1, 1))
        stamp = db_mod.fields.DateTime(default=lambda: datetime(2024, 1, 1, 0, 0, 0))
        tag = db_mod.fields.ForeignKey("test.db.more.tag")
        tags = db_mod.fields.ManyToMany("test.db.more.tag")

    env = db_mod.Env(db_mod.default_registry, db_mod.MemoryBackend())
    tag1 = env["test.db.more.tag"].create({"name": "one"})
    tag2 = env["test.db.more.tag"].create({"name": "two"})
    entry = env["test.db.more.entry"].create(
        {"name": "alpha", "count": "2", "price": "3.5", "active": "true", "tag": tag1, "tags": [tag1, tag2]}
    )
    assert entry.tag.id == tag1.id
    assert entry.tags.ids == [tag1.id, tag2.id]
    assert entry.to_dict(raw=True)["day"] == date(2024, 1, 1)

    repo = env.repository(Entry)
    assert repo.get(entry.id)["name"] == "alpha"
    assert len(repo.all()) == 1
    assert len(repo.search([db_mod.Condition("name", "eq", "alpha")])) == 1
    repo.update(entry.id, {"name": "beta"})
    assert repo.get(entry.id)["name"] == "beta"

    rs = Entry.search(env=env)
    assert len(rs) == 1
    assert rs.first().id == entry.id
    assert rs.mapped("name") == ["beta"]
    assert rs.filtered(lambda record: record.name == "beta").ids == [entry.id]
    assert rs.all()[0].id == entry.id
    assert rs.hello if hasattr(rs, "hello") else True
    rs.update(name="gamma")
    assert Entry.browse(entry.id, env=env).name == "gamma"
    browsed = Entry.browse([entry.id], env=env)
    assert browsed.ids == [entry.id]
    assert Entry.browse(999, env=env) is None

    qs = env["test.db.more.entry"].objects.filter(name__icontains="ga").exclude(count__lt=1).order_by("-name").limit(1)
    assert len(qs) == 1
    assert qs.first().name == "gamma"
    assert qs.search([("name", "=", "gamma")]).ids == [entry.id]
    created = qs.create({"name": "delta"})
    assert created.id is not None
    env["test.db.more.entry"].search([("name", "=", "delta")]).delete()
    assert env["test.db.more.entry"].search([("name", "=", "delta")]).ids == []

    proxy = env["test.db.more.entry"]
    assert proxy.all().ids
    assert proxy.browse(entry.id).id == entry.id
    assert proxy.search(name="gamma").ids == [entry.id]

    entry.count = 9
    entry.save()
    entry.refresh()
    assert entry.count == 9
    copied = entry.copy(name="copied")
    assert copied.name == "copied"
    orphan = Entry(name="orphan", env=env)
    orphan.delete()
    with pytest.raises(RuntimeError):
        orphan.refresh()

    session = db_mod.Session(env)
    fresh = Entry(name="sess", env=env)
    session.add(fresh)
    session.dirty(entry)
    session.delete(copied)
    session.commit()
    assert fresh.id is not None
    session.rollback()
    with db_mod.Session(env) as managed:
        managed.add(Entry(name="ctx", env=env))

    with db_mod.Session(env) as managed:
        managed.add(Entry(name="ctx2", env=env))
        raise_flag = True
        if raise_flag:
            managed.rollback()

    conditions = db_mod._build_conditions(db_mod.Condition("name", "eq", "gamma"), [("count", "gte", 1)], name__ne="zzz")
    assert len(conditions) == 3
    with pytest.raises(TypeError):
        db_mod._build_conditions(object())

    class ChildEntry(Entry):
        _name = "test.db.more.childentry"

        note = db_mod.fields.Text(default="n")

    child = ChildEntry.create({"name": "child"}, env=env)
    assert child.note == "n"

    pandas_env = db_mod.Env(db_mod.default_registry, db_mod.PandasBackend())
    pandas_tag = pandas_env["test.db.more.tag"].create({"name": "pt"})
    pandas_entry = pandas_env["test.db.more.entry"].create({"name": "pa", "tag": pandas_tag})
    assert pandas_env["test.db.more.entry"].browse(pandas_entry.id).name == "pa"
    pandas_env.backend.delete(Entry, pandas_entry.id)
    assert pandas_env["test.db.more.entry"].browse(pandas_entry.id) is None
    with pytest.raises(KeyError):
        pandas_env.backend.update(Entry, 999, {"name": "x"})

    sqlite_path = sandbox / "db.sqlite3"
    sqlite_env = db_mod.Env(db_mod.default_registry, db_mod.SQLiteBackend(sqlite_path))
    sqlite_tag = sqlite_env["test.db.more.tag"].create({"name": "st"})
    sqlite_entry = sqlite_env["test.db.more.entry"].create({"name": "sa", "tag": sqlite_tag, "tags": [sqlite_tag]})
    assert sqlite_env["test.db.more.entry"].browse(sqlite_entry.id).name == "sa"
    assert sqlite_env.backend.all(Entry)
    sqlite_env.backend.delete(Entry, sqlite_entry.id)
    assert sqlite_env["test.db.more.entry"].browse(sqlite_entry.id) is None
    with pytest.raises(KeyError):
        sqlite_env.backend.update(Entry, 999, {"name": "x"})

    assert json.dumps(entry.to_dict(raw=False), default=db_mod._json_default)
