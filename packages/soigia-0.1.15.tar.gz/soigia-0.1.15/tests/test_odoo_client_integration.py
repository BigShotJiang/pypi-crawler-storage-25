from __future__ import annotations

from datetime import datetime
from uuid import uuid4

import pandas as pd
import pytest

from soigia.odoo_client import OdooClient

ODOO_URL = "http://127.0.0.1:8070"
ODOO_DB = "odoo"
ODOO_LOGIN = "admin"
ODOO_PASSWORD = "admin"


def _build_client() -> OdooClient:
    return OdooClient(
        ODOO_URL,
        ODOO_DB,
        login=ODOO_LOGIN,
        password=ODOO_PASSWORD,
        context={"lang": "en_US"},
    )


def _odoo_is_ready() -> bool:
    try:
        return _build_client().version_info().get("server_serie") == "19.0"
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _odoo_is_ready(), reason="Local Odoo 19 Docker service is not available on 127.0.0.1:8070")


@pytest.fixture()
def live_client():
    client = _build_client()
    api_key = client.create_api_key(name=f"pytest-{uuid4().hex[:8]}", duration="1")
    assert api_key
    yield client
    try:
        client.revoke_api_key(api_key)
    except Exception:
        pass


def test_live_odoo_bootstrap_and_metadata(live_client: OdooClient):
    version = live_client.version_info()
    databases = live_client.list_databases()
    session = live_client.session_info()
    fields = live_client.fields_get("res.partner", attributes=["string", "type"])
    defaults = live_client.default_get("res.partner", ["name", "company_type"])
    matches = live_client.name_search("res.partner", "My", limit=5)

    assert version["server_serie"] == "19.0"
    assert "odoo" in databases
    assert session["uid"] == 2
    assert fields["name"]["type"] == "char"
    assert isinstance(defaults, dict)
    assert matches


def test_live_odoo_json2_crud_roundtrip(live_client: OdooClient):
    suffix = uuid4().hex[:8]
    partner_name = f"SoiGia JSON2 {suffix}"
    partner_id = live_client.create(
        "res.partner",
        {
            "name": partner_name,
            "email": f"codex+{suffix}@example.com",
        },
    )

    try:
        assert isinstance(partner_id, int)
        assert live_client.search_count("res.partner", [["id", "=", partner_id]]) == 1

        found = live_client.search_read(
            "res.partner",
            [["id", "=", partner_id]],
            fields=["name", "email"],
            limit=1,
        )
        assert found[0]["name"] == partner_name

        assert live_client.write("res.partner", partner_id, {"phone": "+840000000"})
        record = live_client.read("res.partner", partner_id, fields=["name", "phone", "write_date"])[0]
        assert record["phone"] == "+840000000"
        assert datetime.strptime(record["write_date"], "%Y-%m-%d %H:%M:%S")

        groups = live_client.read_group(
            "res.partner",
            [],
            fields=["id:count"],
            groupby=["is_company"],
        )
        assert groups
    finally:
        live_client.unlink("res.partner", partner_id)


def test_live_odoo_attachment_roundtrip(live_client: OdooClient):
    partner_id = live_client.create("res.partner", {"name": f"SoiGia Attachment {uuid4().hex[:8]}"})

    try:
        attachment_id = live_client.upload_attachment(
            name="hello.txt",
            content=b"hello odoo 19",
            res_model="res.partner",
            res_id=partner_id,
            mimetype="text/plain",
        )
        assert attachment_id > 0
        assert live_client.download_attachment(attachment_id) == b"hello odoo 19"
    finally:
        attachments = live_client.search("ir.attachment", [["res_model", "=", "res.partner"], ["res_id", "=", partner_id]])
        if attachments:
            live_client.unlink("ir.attachment", attachments)
        live_client.unlink("res.partner", partner_id)


def test_live_odoo_model_batch_dataframe_roundtrip(live_client: OdooClient):
    suffix = uuid4().hex[:8]
    email_a = f"batch-a-{suffix}@example.com"
    email_b = f"batch-b-{suffix}@example.com"
    email_c = f"batch-c-{suffix}@example.com"
    partner_model = live_client.env.model(
        "res.partner",
        fields=["id", "name", "email", "phone", "is_company"],
        key_fields=["email"],
    )

    cleanup_ids: list[int] = []
    existing_ids = live_client.search("res.partner", [["email", "in", [email_a, email_b, email_c]]])
    if existing_ids:
        live_client.unlink("res.partner", existing_ids)

    insert_df = pd.DataFrame(
        [
            {"name": f"Batch A {suffix}", "email": email_a, "phone": "+841111111"},
            {"name": f"Batch B {suffix}", "email": email_b, "phone": "+842222222"},
        ]
    )

    inserted = partner_model.insert(insert_df)
    cleanup_ids.extend(inserted.ids)

    try:
        assert len(inserted.ids) == 2
        inserted_df = inserted.datatable(fields=["id", "name", "email", "phone"])
        assert set(inserted_df["email"]) == {email_a, email_b}

        update_df = inserted_df.copy()
        update_df["phone"] = ["+849999991", "+849999992"]
        updated_count = partner_model.update(update_df)
        assert updated_count == 2

        refreshed_df = partner_model.objects.filter(email__in=[email_a, email_b]).order_by("email asc").datatable(
            "email",
            "phone",
            limit=10,
        )
        assert list(refreshed_df["phone"]) == ["+849999991", "+849999992"]

        upsert_df = pd.DataFrame(
            [
                {"email": email_a, "name": f"Batch A Updated {suffix}", "phone": "+847777771"},
                {"email": email_c, "name": f"Batch C New {suffix}", "phone": "+847777772"},
            ]
        )
        upsert_result = partner_model.upsert(upsert_df, fields=["id", "name", "email", "phone"])

        assert upsert_result["created_count"] == 1
        assert upsert_result["updated_count"] == 1
        cleanup_ids.extend(upsert_result["created_ids"])

        after_upsert_df = partner_model.objects.filter(email__in=[email_a, email_c]).order_by("email asc").datatable(
            "email",
            "name",
            "phone",
            limit=10,
        )
        assert list(after_upsert_df["email"]) == [email_a, email_c]
        assert list(after_upsert_df["phone"]) == ["+847777771", "+847777772"]
        assert after_upsert_df.iloc[0]["name"] == f"Batch A Updated {suffix}"

        delete_by_keys_df = pd.DataFrame({"email": [email_a, email_b, email_c]})
        deleted_count = partner_model.delete_by_keys(delete_by_keys_df)
        assert deleted_count == 3
        assert live_client.search_count("res.partner", [["email", "in", [email_a, email_b, email_c]]]) == 0
    finally:
        leftover_ids = live_client.search("res.partner", [["email", "in", [email_a, email_b, email_c]]])
        if leftover_ids:
            live_client.unlink("res.partner", leftover_ids)
