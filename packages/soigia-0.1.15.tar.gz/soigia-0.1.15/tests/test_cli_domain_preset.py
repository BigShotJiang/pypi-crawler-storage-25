from soigia.cli import PRESETS, _build_pane_specs, _resolve_layout_target


def test_domain_cli_preset_is_registered():
    pane_count, preset = _resolve_layout_target("domain")

    assert pane_count == 2
    assert preset is not None
    assert preset.name == "domain"
    assert "domain" in PRESETS


def test_domain_cli_preset_builds_example_commands():
    pane_count, preset = _resolve_layout_target("domain")
    pane_specs = _build_pane_specs(pane_count, preset=preset)

    assert [spec.title for spec in pane_specs] == ["domain-1", "domain-2"]
    assert "examples.domain_pipeline" in " ".join(pane_specs[0].command_template)
    assert "examples.domain_customer_tiers" in " ".join(pane_specs[1].command_template)
