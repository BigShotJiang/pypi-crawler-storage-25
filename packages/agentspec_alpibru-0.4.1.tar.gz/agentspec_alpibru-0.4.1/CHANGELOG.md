# Changelog

All notable changes to AgentSpec will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.4.0] — 2026-04-17

The provisioner: agentspec now materialises the agent's identity, rules,
skill instructions, and MCP server registrations into the config files
each CLI natively reads — before spawning the process. Previously,
agentspec declared *what* an agent needed but left the caller (e.g.
caloron-noether) to wire it up per-runtime. Now agentspec owns the
full path from manifest to running CLI.

### Added

- **`DependencySpec` model** — declares what a tool or skill needs
  installed: `pip`, `npm`, `cargo`, `nix` packages, `setup` commands,
  and required `env` vars. Used by `McpServerSpec.requires` and
  `SkillSpec.requires`.

- **`McpServerSpec` model** in `agentspec.parser.manifest`. Structured
  MCP server definition with `name`, `url`, `transport` (stdio/http/sse),
  `command`, `args`, `env`, `headers`, `requires`. Accepted alongside
  plain strings and legacy dicts in `tools.mcp`.

- **`SkillSpec` model** — enriched skill with optional `requires`.
  Skills can remain plain strings or become dicts with dependency
  declarations. Plain strings are the common case; enriched skills
  are for orchestrators that need to install deps before running.

- **`agentspec.runner.provisioner` module** — the core addition.
  `provision(plan, manifest, workdir)` writes runtime-specific config
  files before the CLI spawns:

  **Instruction files** (soul + rules + traits + skill instructions):
  | Runtime    | File                        |
  |------------|-----------------------------|
  | claude-code | `CLAUDE.md`                |
  | gemini-cli  | `GEMINI.md`                |
  | cursor-cli  | `.cursorrules`             |
  | codex-cli   | `AGENTS.md`                |
  | opencode    | `.open-code/instructions.md`|
  | aider       | `.aider.conf.yml`          |
  | goose       | *(uses --system flag)*     |

  **MCP config files** (server registrations):
  | Runtime    | File                        |
  |------------|-----------------------------|
  | claude-code | `.mcp.json`                |
  | cursor-cli  | `.cursor/mcp.json`         |
  | gemini-cli  | `.gemini/settings.json`    |
  | codex-cli   | `codex.json`               |
  | opencode    | `.open-code/mcp.json`      |

- **Well-known MCP server registry** — 13 servers (github, postgres,
  slack, filesystem, brave-search, google-scholar, arxiv, jira,
  playwright, puppeteer, noether, and aliases). Plain string entries
  like `- github` in `tools.mcp` are auto-expanded to their full
  server spec at provision time.

- **`SKILL_INSTRUCTIONS` dictionary** — 19 skill-specific instruction
  strings (web-search, code-execution, git, github, python-development,
  rust-development, typescript-development, pytest-testing, etc.).
  Injected as `## Skill Instructions` sections in each instruction file.

- **`provision_install()` function** — optional second step that
  registers MCP servers via CLI commands (`claude mcp add`,
  `gemini mcp add`, `codex mcp add`, `cursor --add-mcp`) and
  installs declared dependencies (pip, npm, cargo, setup commands).
  Returns a list of human-readable notes about what was done.

- **`WELL_KNOWN_SKILL_DEPS` registry** — 9 skills with default
  dependency declarations (data-analysis → pandas/numpy,
  pytest-testing → pytest/pytest-cov, browser → playwright, etc.).

- **Folder scaffolding** — `provision()` creates the directory
  structure each CLI expects before writing config files:
  `.claude/`, `.cursor/`, `.gemini/`, `.open-code/`.

- **`provision()` and `provision_install()` exported** from the
  `agentspec` namespace.

### Changed

- **Runner calls provisioner before `build_command()`.** `execute()`
  now accepts an optional `workdir` parameter and runs
  `provision(plan, manifest, workdir)` before spawning the CLI.

- **System prompt delivery simplified.** Command builders for codex-cli,
  cursor-cli, opencode, and gemini-cli no longer prepend `plan.system_prompt`
  to the user prompt or write framework-specific files directly. The
  provisioner handles it via native instruction files. Claude-code
  (`--system-prompt`) and goose (`--system`) still pass it as a flag.

- **GEMINI.md write moved from `_build_gemini_cmd` to provisioner.**

### Tests

- 170 → 247 green (77 new provisioner tests covering instruction files,
  MCP configs, well-known server expansion, normalisation, no-overwrite
  guards, end-to-end provisioning, parametric runtime coverage, folder
  scaffolding, DependencySpec, enriched skills, and provision_install).

### Migration from 0.3.x

- **No breaking changes to the manifest format.** Existing `tools.mcp`
  entries (strings and dicts) continue to work unchanged.
- **Skills can now be dicts.** `skills: [{name: "x", requires: {pip: [y]}}]`
  is accepted alongside plain strings. The resolver extracts the name
  for skill resolution; the provisioner uses `requires` for installation.
- **Behavioral change:** CLIs that previously received system prompts
  prepended to the user prompt now receive them via native instruction
  files. The user prompt is cleaner; the system instructions are in the
  file the CLI is designed to read.
- **New dependency for aider config:** `pyyaml` (already a transitive
  dep via pydantic, but now used directly for `.aider.conf.yml` writing).

## [0.3.3] — 2026-04-16

Continued the post-install audit: installed cursor-agent 2026.04.15,
opencode 1.4.6, and aider 0.86.2 rootless, ran live dry-runs against
each. **Every CLI had at least one gap vs its real `--help`** — fixed
here.

### Added

- **`cursor` provider prefix in `PROVIDER_MAP`.** Without this entry,
  manifests declaring `cursor/<model>` fell through as "unknown
  provider" and cursor-cli was unreachable via the resolver despite
  the runtime being registered. Caught by live dry-run.
- **cursor `--model <name>` threading.** `cursor-agent --model` takes
  cursor-specific names (`gpt-5`, `sonnet-4`, `sonnet-4-thinking`).
- **cursor `--force` under AGENTSPEC_GYM=1** for tool-approval bypass.
- **opencode `-m/--model <provider/model>` threading.** opencode's
  real flag takes a `provider/model` pair; manifest's caller-facing
  `opencode/` prefix is stripped once so we pass what opencode expects.
- **aider `--yes-always` under AGENTSPEC_GYM=1** for unattended runs.

### Fixed

- **cursor `-p` is now a bare flag**, not a prefix for the prompt.
  Previous `[-p, <prompt>]` worked by accident (cursor-agent parsed
  `-p` as a boolean and the next arg as positional) but the idiomatic
  shape separates them.

### Verified live (v0.3.3 argv against installed binaries)

```
cursor-agent -p --output-format text --force --model sonnet-4 "<prompt>"
opencode run -m anthropic/claude-sonnet-4-6 "<prompt>"
aider --yes-always --model claude-sonnet-4-6 --message "<prompt>"
```

All three match the binary's accepted argv exactly.

### Tests

- 161 → 170 green (9 new + 6 updated to v0.3.3 shapes).

### Still unvalidated

`ollama` is in the catalogue but couldn't be installed rootless —
GitHub release assets 404 via the sandbox's network. No code changes
this release; pinned to pre-existing builder.

## [0.3.2] — 2026-04-16

Post-install verification of v0.3.1: both goose (1.30.0) and codex-cli
(0.121.0) installed rootless on a test box, and the argv agentspec
produces was confirmed against `codex exec --help` and `goose run
--help` from the live binaries. One small fix surfaced:

### Fixed

- **codex-cli subscription auth fallback.** The resolver previously
  rejected codex-cli with "OPENAI_API_KEY not set" when no API key
  was in the env. But codex also supports subscription-style auth
  via `codex login` (browser OAuth or device code) — same pattern
  as `claude login` / gemini's logged-in CLI mode. Resolver now
  treats codex-cli the same as claude-code and gemini-cli for the
  subscription-fallback path: if the binary is on PATH but no API
  key is set, assume the CLI is logged in rather than skipping
  the candidate. Users with just `codex login` and no env var are
  no longer wrongly rejected.

### Verified

Live against installed binaries (v0.3.1 claims validated):

  codex exec --full-auto -m gpt-5 "<prompt>"   ← what agentspec produces
  goose run --model claude-sonnet-4-6 -t "<prompt>"  ← what agentspec produces

Both match `--help` output exactly.

## [0.3.1] — 2026-04-16

Extends v0.3.0's parity sweep to codex-cli (which had its own set of
broken flags) and adds support for Block's `goose`.

### Added

- **`goose` runtime**. MCP-native agent from Block; non-interactive
  form per https://goose-docs.ai/docs/guides/goose-cli-commands is
  `goose run -t "<prompt>"`. Supported flags:
  - `--model <name>` — bare model name with provider prefix stripped
  - `--system <text>` — **real** system-prompt flag (unlike
    codex/cursor/opencode where we have to prepend)
  - `-t <prompt>` — the user prompt
  Provider/auth managed by goose itself via `goose configure`; our
  resolver just needs the binary on PATH. Handles MCP-heavy agent
  manifests naturally because goose's entire design is MCP-first.

### Fixed

- **codex-cli uses `exec` subcommand now.** Previously built
  `codex <prompt>` which drops into the interactive TUI; modern codex
  requires `codex exec <prompt>` for non-interactive runs. Verified
  against https://developers.openai.com/codex/cli/reference.
- **codex-cli autonomous mode via `--full-auto`.** Added under
  `AGENTSPEC_GYM=1`, matching the treatment other autonomous CLIs get
  (claude's `--dangerously-skip-permissions`, gemini's `-y`).
- **codex-cli `-m/--model` threading.** Same gap as claude/gemini had —
  manifest's `model.preferred` was silently dropped.
- **codex-cli `--instructions` flag removal.** The previous builder
  wrote `plan.system_prompt` to a temp file and passed
  `--instructions <tmpfile>`, but codex doesn't have that flag.
  Modern codex rejected the argv with "unknown option". System prompts
  now prepend to the user prompt (same pattern as cursor/opencode).

### Not added (deliberate — flagged in commits)

- **Amazon Q Developer CLI**. The open-source `q` binary is "no longer
  actively maintained" per its own GitHub; AWS moved to Kiro which is
  closed-source. Speculative integration would generate exactly the
  silent-drift bugs the parity sweeps have been fixing. Will revisit
  if a user explicitly asks and can share the current flag contract.
- **Sourcegraph Cody, Continue, Windsurf**. Each exists as a CLI but
  field demand hasn't surfaced, and each has its own flag-drift
  surface to maintain. Adding only when asked.

### Tests

- 139 → 161 green. 22 new: 7 codex (exec subcommand, --full-auto gating,
  -m threading, --instructions removed, system-prompt prepended, model
  name stripping parametrized), 6 goose (dispatch reachability, run
  subcommand, --model, --system flag, empty-model guard, model name
  stripping parametrized), and the parity table was extended to pin
  goose → goose.

### Upgrading from 0.3.0

No breaking changes. New `goose` runtime is opt-in via
`model.preferred: [goose/...]` or the usual provider-prefix shapes
like `anthropic/claude-sonnet-4-6` when the claude-code runtime isn't
available. codex-cli behaviour changes for all callers — the old
argv was broken against modern codex anyway, so there's no
well-formed invocation that will regress.

## [0.3.0] — 2026-04-16

Runner + resolver parity sweep across all four supported coding CLIs
(claude-code, gemini-cli, cursor-cli, opencode), triggered by a field
report that gemini-cli calls were failing despite credentials being set.
Applying the same rigor to all four surfaced a real bug per CLI.

### Added

- **`cursor-cli` runtime is now actually runnable.** The resolver table
  had `"cursor" → "cursor"` but the real binary is `cursor-agent`, and
  the runner dispatcher had no builder entry at all — `build_command`
  raised `NotImplementedError` on the cursor path. Fixed the binary,
  renamed the runtime key to `cursor-cli` (matches caloron-noether's
  naming + every other `-cli` entry), and added `_build_cursor_cmd`
  producing `cursor-agent -p <prompt> --output-format text` with the
  system prompt prepended.
- **`--model` flag threading on claude-code and gemini-cli.** Both
  CLIs accept a model override flag (`--model` / `-m`) but the runner
  never passed it. Manifests' `model.preferred` was effectively
  ignored — both CLIs ran with whatever their own default was.
  `_claude_model_name()` and `_gemini_model_name()` strip the
  `provider/` prefix (`claude/claude-sonnet-4-6` → `claude-sonnet-4-6`;
  `gemini/gemini-2.5-pro` → `gemini-2.5-pro`; aliases like `sonnet`
  pass through unchanged).
- **Gemini-cli autonomous mode.** Gym runs now pass `-y` (yolo) under
  `AGENTSPEC_GYM=1`, matching the `--dangerously-skip-permissions`
  treatment claude-code was already getting. Without this, gemini
  hung every tool-approval prompt and stalled the subprocess.
- **Gemini-cli system prompts.** gemini-cli has no `--system-prompt`
  flag; it reads `GEMINI.md` from the CWD as system instructions.
  Runner now writes `plan.system_prompt` to that file when present,
  with a guard against stomping an existing `GEMINI.md` that belongs
  to the user's project.

### Fixed

- **`GEMINI_API_KEY` is now primary for gemini, not `GOOGLE_API_KEY`.**
  gemini-cli itself only reads `GEMINI_API_KEY` (verified via its own
  auth-error message listing the accepted env vars). Users who set
  only `GOOGLE_API_KEY` would pass our resolver then fail at runtime
  with "please set an Auth method". `PROVIDER_MAP["gemini"]` is now a
  tuple `(GEMINI_API_KEY, GOOGLE_API_KEY)` — any one set counts;
  `GOOGLE_API_KEY` stays as a historical fallback for users who set
  the Google-branded key. Resolver decision log names whichever key
  satisfied the check.
- **`opencode --print` → `opencode run`.** The runner built
  `opencode --print <prompt>` but the real non-interactive form per
  https://opencode.ai/docs/cli/ (and caloron-noether's field-validated
  FRAMEWORKS table) is the `run` subcommand. Modern opencode rejects
  `--print` with "unknown flag".
- **Opencode Vertex AI region goes to the right variable.**
  `vertex_env_for_runtime("opencode")` set `GOOGLE_CLOUD_LOCATION`
  (what gemini-cli reads) but opencode actually reads `VERTEX_LOCATION`
  per its google-vertex-ai provider docs. Symptom: opencode silently
  defaulted to the `global` region regardless of what the resolver
  picked; for EU-residency users (default `europe-west1`) every Vertex
  request went to the wrong region. Now injects both — opencode reads
  `VERTEX_LOCATION`, gemini-cli keeps reading `GOOGLE_CLOUD_LOCATION`.
- **Gym runner now threads the Vertex AI env to spawned CLIs.**
  Gym's `run_task` was doing `env = os.environ.copy()` and bypassing
  `build_env(plan)`, which is what injects the Vertex-specific env
  vars when the resolver picks that auth path. Result: even when a
  user had GCP + ADC set up correctly and the resolver reported
  `auth_source="vertex-ai …"`, the subprocess inherited
  `GOOGLE_CLOUD_PROJECT` (from os.environ) but not
  `GOOGLE_GENAI_USE_VERTEXAI=true`, so gemini-cli fell back to
  direct-API mode and failed. Fixed by returning
  `(argv, env, note)` from `_resolve_command` and layering
  `AGENTSPEC_GYM=1` on top of `build_env(plan)` instead of
  `os.environ.copy()`.
- **Stale `__version__` in `__init__.py`.** Was `0.1.0` while
  `pyproject.toml` was `0.2.2`. Both now at `0.3.0`.

### Changed (possibly breaking — minor surface)

- `PROVIDER_MAP` values changed from `tuple[str, str | None]` to
  `tuple[str, tuple[str, ...] | None]` so multiple accepted env keys
  can be listed. Internal API; not imported from the public
  `agentspec` namespace, but callers that depended on the old shape
  will need to adapt.
- Runtime key `"cursor"` renamed to `"cursor-cli"`. Affects the
  resolver's runtime-identifier surface and `RUNTIME_BINARIES`; no
  manifest-facing change (the provider prefix in
  `model.preferred` was never `cursor/...`).

### Tests

- 111 → 139 green (1 skipped is a deliberate unreachable-path test).
- New: 15 gemini-cli tests + 5 Vertex-integration tests +
  28 multi-CLI parity tests (including a meta-test that catches
  "binary added to `RUNTIME_BINARIES` but no builder in the
  dispatcher" — the exact regression that cursor-cli had before).

### Live-validation caveats (deliberate, flagged in commits)

- claude-code and gemini-cli fixes are validated against the real
  installed CLIs' `--help` output.
- cursor-agent and opencode aren't installed on the dev box used to
  ship this release; their fixes are validated against (a) official
  docs and (b) caloron-noether's field-tested `FRAMEWORKS` values.
  Next field opportunity is to run `agentspec gym run <agent> <task>`
  with each against a small fixture.

## [0.2.2] — 2026-04-13

### Fixed

- **Resolver: `opencode/default` and `aider/default` no longer fall through as
  unknown providers.** Both runtimes manage their own auth/model selection —
  the resolver now recognises them as valid providers that need only binary
  presence in PATH, not API keys.
- **Runner: `agentspec run <dir>` no longer crashes claude-code with
  "Input must be provided either through stdin or as a prompt argument".**
  When `--input` is omitted, the runner now derives a prompt from the agent's
  `SOUL.md` (for directory-format agents) or `description` field. Same fallback
  applies to gemini-cli and codex-cli.
- **Runner: opencode invocation updated to `opencode --print "<prompt>"`** —
  the non-interactive mode — instead of the previous `--prompt` flag. System
  prompts are prepended to the user prompt so opencode (which picks its own
  model) still sees the agent's persona and traits.

Reported by an integrator building the `llm-wiki` pipeline. Thanks.

### Added

- New helper `agentspec.runner.runner._derive_prompt` — single source of truth
  for the input/SOUL.md/description fallback chain. Used by all non-ollama
  runners.
- 12 regression tests in `tests/test_issue_opencode_and_fallback.py`.

## [0.2.0] — 2026-04-12

### Added

- **Vertex AI backend support** (`agentspec.resolver.vertex`). When
  `GOOGLE_CLOUD_PROJECT` is set and Application Default Credentials are
  available, the resolver routes claude-code, gemini-cli, aider, and
  opencode through Vertex AI instead of direct provider APIs. Default
  region: `europe-west1` (EU data residency).
- New env vars: `AGENTSPEC_VERTEX_PROJECT`, `AGENTSPEC_VERTEX_LOCATION`
  (override the standard `GOOGLE_CLOUD_*` if needed).
- Per-runtime env injection in the runner: `CLAUDE_CODE_USE_VERTEX=1`
  for claude-code, `GOOGLE_GENAI_USE_VERTEXAI=true` for gemini-cli,
  `VERTEX_PROJECT/LOCATION` for aider, base GCP env for opencode.
- 21 new tests (`tests/test_vertex.py`) covering detection, routing,
  per-runtime env, and runner env injection.

### Notes

- codex-cli (OpenAI) cannot route through Vertex AI — OpenAI models are
  not on Vertex Model Garden. Continues to use OpenAI direct API.
- Vertex AI takes precedence over direct API keys when both are
  configured for a routable provider (claude/anthropic, gemini/google).

## [0.1.0] — 2026-04-12

Initial public release.

### Added

- **Parser** — Pydantic models for the `.agent` schema, single-file and directory format support, content-addressable hashing (`ag1:` prefix).
- **Resolver** — auto-negotiates runtime, model, tools, and auth from the local environment. Supports 6 LLM runtimes: `claude-code`, `gemini-cli`, `codex-cli`, `aider`, `opencode`, `ollama`.
- **Inheritance & merger** — `base:` chain with explicit merge strategies (`append`, `override`, `restrict`). Hardcoded trust-restrict invariant: child agents can never escalate parent permissions.
- **Profile system** — persistent agent identity that accumulates across sprints. Memories, portfolio (CV), skill proofs. Cold-start seeding from manifest.
- **Signing** — Ed25519 (via PyNaCl) for memories, portfolio entries, and skill proofs. HMAC-SHA256 fallback when PyNaCl is not installed.
- **CLI** — ACLI-compliant: `init`, `validate`, `resolve`, `run`, `extend`, `push`, `pull`, `search`, `schema`. Plus `introspect`, `version`, `skill` from acli-spec.
- **Registry client** — push, pull, and semantic search against any Noether-compatible registry (e.g. `noether-cloud`).
- **Noether integration** — 9 AgentSpec operations registered as Noether stages (validate, resolve, hash, merge, evolve, schema, profile_create, profile_retro, profile_export).
- **Base templates** — `bases/{claude,gemini,codex,local}.agent` plus `-noether` variants for each.
- **Documentation** — full MkDocs Material site at <https://alpibrusl.github.io/agentspec/>.
- **45 tests** across parser, merger, and resolver.

[0.1.0]: https://github.com/alpibrusl/agentspec/releases/tag/v0.1.0
