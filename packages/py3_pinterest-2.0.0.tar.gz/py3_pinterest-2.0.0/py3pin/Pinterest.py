import json
import mimetypes
import os
import subprocess
import tempfile
import time
import uuid

import requests
import requests.cookies
from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
from py3pin.BookmarkManager import BookmarkManager
from py3pin.Registry import Registry
from py3pin.RequestBuilder import RequestBuilder
from requests.structures import CaseInsensitiveDict
from selenium import webdriver
from selenium.webdriver import ChromeOptions
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.proxy import Proxy, ProxyType
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By


AGENT_STRING = (
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36"
)

# Pinterest endpoints
HOME_PAGE = "https://www.pinterest.com/"
LOGIN_PAGE = "https://www.pinterest.com/login/?referrer=home_page"
CREATE_USER_SESSION = "https://www.pinterest.com/resource/UserSessionResource/create/"
DELETE_USER_SESSION = "https://www.pinterest.com/resource/UserSessionResource/delete/"
USER_RESOURCE = "https://www.pinterest.com/resource/UserResource/get/"
BOARD_PICKER_RESOURCE = (
    "https://www.pinterest.com/resource/BoardPickerBoardsResource/get/"
)
BOARDS_RESOURCE = "https://www.pinterest.com/resource/BoardsResource/get/"
CREATE_BOARD_RESOURCE = "https://www.pinterest.com/resource/BoardResource/create/"
DELETE_BOARD_RESOURCE = "https://www.pinterest.com/resource/BoardResource/delete/"
FOLLOW_BOARD_RESOURCE = "https://www.pinterest.com/resource/ApiResource/update/"
UNFOLLOW_BOARD_RESOURCE = "https://www.pinterest.com/resource/ApiResource/delete/"
FOLLOW_USER_RESOURCE = "https://www.pinterest.com/resource/UserFollowResource/create/"
UNFOLLOW_USER_RESOURCE = "https://www.pinterest.com/resource/UserFollowResource/delete/"
USER_FOLLOWING_RESOURCE = (
    "https://www.pinterest.com/resource/UserFollowingResource/get/"
)
USER_FOLLOWERS_RESOURCE = (
    "https://www.pinterest.com/resource/UserFollowersResource/get/"
)
PIN_RESOURCE_CREATE = "https://www.pinterest.com/resource/PinResource/create/"
REPIN_RESOURCE_CREATE = "https://www.pinterest.com/resource/RepinResource/create/"
PIN_LIKE_RESOURCE = "https://www.pinterest.com/resource/PinLikeResource/create/"
PIN_UNLIKE_RESOURCE = "https://www.pinterest.com/resource/PinLikeResource/delete/"
DELETE_PIN_RESOURCE = "https://www.pinterest.com/resource/PinResource/delete/"
PIN_COMMENT_RESOURCE = "https://www.pinterest.com/resource/PinCommentResource/create/"
VISUAL_LIVE_SEARCH_RESOURCE = (
    "https://www.pinterest.com/resource/VisualLiveSearchResource/get/"
)
SEARCH_RESOURCE = "https://www.pinterest.com/resource/SearchResource/get/"
TYPE_AHEAD_RESOURCE = (
    "https://www.pinterest.com/resource/AdvancedTypeaheadResource/get/"
)
BOARD_RECOMMEND_RESOURCE = (
    "https://www.pinterest.com/resource/BoardContentRecommendationResource/get/"
)
PINNABLE_IMAGES_RESOURCE = (
    "https://www.pinterest.com/resource/FindPinImagesResource/get/"
)
BOARD_FEED_RESOURCE = "https://www.pinterest.com/resource/BoardFeedResource/get/"
USER_HOME_FEED_RESOURCE = (
    "https://www.pinterest.com/resource/UserHomefeedResource/get/"
)
USER_PIN_RESOURCE = "https://www.pinterest.com/resource/UserPinsResource/get/"
BASE_SEARCH_RESOURCE = "https://www.pinterest.com/resource/BaseSearchResource/get/"
BOARD_INVITES_RESOURCE = (
    "https://www.pinterest.com/resource/BoardInvitesResource/get/"
)
CREATE_COMMENT_RESOURCE = (
    "https://www.pinterest.com/resource/AggregatedCommentResource/create/"
)
GET_PIN_COMMENTS_RESOURCE = (
    "https://www.pinterest.com/resource/AggregatedCommentFeedResource/get/"
)
LOAD_PIN_URL_FORMAT = "https://www.pinterest.com/pin/{}/"
PIN_RESOURCE_GET = "https://www.pinterest.com/resource/PinResource/get/"
DELETE_COMMENT = (
    "https://www.pinterest.com/resource/AggregatedCommentResource/delete/"
)
CONVERSATION_RESOURCE = "https://www.pinterest.com/resource/ConversationsResource/get/"
CONVERSATION_RESOURCE_CREATE = (
    "https://www.pinterest.com/resource/ConversationsResource/create/"
)
LOAD_CONVERSATION = (
    "https://www.pinterest.com/resource/ConversationMessagesResource/get/"
)
SEND_MESSAGE = "https://www.pinterest.com/resource/ConversationMessagesResource/create/"
BOARD_SECTION_RESOURCE = (
    "https://www.pinterest.com/resource/BoardSectionResource/create/"
)
GET_BOARD_SECTIONS = "https://www.pinterest.com/resource/BoardSectionsResource/get/"
BOARD_SECTION_EDIT_RESOURCE = (
    "https://www.pinterest.com/resource/BoardSectionEditResource/delete/"
)
GET_BOARD_SECTION_PINS = (
    "https://www.pinterest.com/resource/BoardSectionPinsResource/get/"
)
UPLOAD_IMAGE = "https://www.pinterest.com/upload-image/"
API_RESOURCE_CREATE = "https://www.pinterest.com/resource/ApiResource/create/"
STORY_PIN_RESOURCE_CREATE = "https://www.pinterest.com/resource/StoryPinResource/create/"
VIP_RESOURCE_GET = "https://www.pinterest.com/resource/VIPResource/get/"
S3_UPLOAD_URL = "https://pinterest-media-upload.s3-accelerate.amazonaws.com/"


class PinterestUploadError(Exception):
    pass


class Pinterest:
    def __init__(
        self,
        password="",
        proxies=None,
        username="",
        email="",
        cred_root="data",
        user_agent=None,
    ):
        self.email = email
        self.username = username
        self.password = password
        self.req_builder = RequestBuilder()
        self.bookmark_manager = BookmarkManager()
        self.http = requests.session()
        self.proxies = proxies
        self.user_agent = user_agent

        self.registry = Registry(cred_root, email)

        cookies = self.registry.get_all()
        for key in cookies.keys():
            self.http.cookies.set(key, cookies[key])

        if self.user_agent is None:
            self.user_agent = AGENT_STRING

    def request(self, method, url, data=None, files=None, extra_headers=None):
        headers = CaseInsensitiveDict(
            [
                ("Referer", HOME_PAGE),
                ("X-Requested-With", "XMLHttpRequest"),
                ("Accept", "application/json"),
                ("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8"),
                ("User-Agent", self.user_agent),
            ]
        )
        csrftoken = self.http.cookies.get("csrftoken")
        if csrftoken:
            headers.update([("X-CSRFToken", csrftoken)])

        if extra_headers is not None:
            for h in extra_headers:
                headers.update([(h, extra_headers[h])])

        response = self.http.request(
            method, url, data=data, headers=headers, files=files, proxies=self.proxies
        )
        response.raise_for_status()

        return response

    def get(self, url, headers=None):
        if headers is None:
            headers = {}
        if "X-Pinterest-PWS-Handler" not in headers:
            headers["X-Pinterest-PWS-Handler"] = "www/[username].js"
        return self.request("GET", url=url, extra_headers=headers)

    def post(self, url, data=None, files=None, headers=None):
        return self.request(
            "POST", url=url, data=data, files=files, extra_headers=headers
        )

    def login(self, headless=True, wait_time=15, proxy=None, lang="en", raspberry=False):
        """
        Logs user in with the provided credentials.
        User session is stored in the 'cred_root' folder
        and reused so there is no need to login every time.
        Pinterest sessions last for about 15 days
        Ideally you need to call this method 3-4 times a month at most.

        :param headless: If True, runs Chrome in headless mode (without GUI). Default is True.
        :param wait_time: Maximum time to wait for elements to load. Default is 15 seconds.
        :param proxy: Proxy server address to use. Default is None.
        :param lang: Language to use for the Pinterest interface. Default is "en".
        :param raspberry: if True, the code will be configured for Raspberry Pi. Default is False.
        :return: Python dict object describing the Pinterest response.
        """
        chrome_options = ChromeOptions()
        chrome_options.add_experimental_option('prefs', {'intl.accept_languages': lang})
        if headless:
            chrome_options.add_argument("--headless")

        if proxy is not None:
            http_proxy = Proxy()
            http_proxy.proxy_type = ProxyType.MANUAL
            http_proxy.http_proxy = proxy
            http_proxy.socks_proxy = proxy
            http_proxy.ssl_proxy = proxy
            http_proxy.add_to_capabilities(chrome_options)

        # For other systems, we assume ChromeDriver is installed in a specific location.
        if raspberry==False:
            service = Service(ChromeDriverManager().install())
        # For Raspberry Pi, use the locally installed ChromeDriver
        else:
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--remote-debugging-port=9222")
            service = Service("/usr/bin/chromedriver")
            
        driver = webdriver.Chrome(service=service,options=chrome_options)
        driver.get("https://pinterest.com/login")

        try:
            # Dismiss cookie consent banner if present (e.g. EU/GDPR regions)
            try:
                cookie_btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(., 'Accept')]"))
                )
                cookie_btn.click()
            except Exception:
                pass

            WebDriverWait(driver, wait_time).until(
                EC.element_to_be_clickable((By.ID, "email"))
            )

            driver.find_element(by=By.ID, value='email').send_keys(self.email)
            driver.find_element(by=By.ID, value="password").send_keys(self.password)

            login_button = WebDriverWait(driver, wait_time).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[type="submit"]'))
            )
            login_button.click()

            WebDriverWait(driver, wait_time).until(
                EC.invisibility_of_element((By.ID, "email"))
            )

            cookies = driver.get_cookies()

            self.http.cookies.clear()
            for cookie in cookies:
                self.http.cookies.set(cookie["name"], cookie["value"])

            self.registry.update_all(self.http.cookies.get_dict())

            print("Successfully logged in with account " + self.email)
        except Exception as e:
            print("Failed to login", e)
        finally:
            driver.quit()

    def logout(self):
        """
        Logs the current user out.
        Takes a few seconds for the session to be invalidated on pinterest's side
        """
        options = {"disable_auth_failure_redirect": True}

        data = self.req_builder.buildPost(options=options)
        return self.post(url=DELETE_USER_SESSION, data=data)


    def get_user_overview(self, username=None):
        """
        :param username target username, if left blank current user is assumed
        :return python dict describing the pinterest user profile response
        """
        if username is None:
            username = self.username

        options = {
            "isPrefetch": "false",
            "username": username,
            "field_set_key": "profile",
        }
        url = self.req_builder.buildGet(url=USER_RESOURCE, options=options)
        result = self.get(url=url).json()

        return result["resource_response"]["data"]

    def boards(self, username=None, page_size=50, reset_bookmark=False):
        """
        The data returned is chunked, this comes from pinterest's rest api.
        This method is batched. In order to obtain all boards
        you need to call it until an empty list is returned.
        :param username: target username. If left blank, the current user is assumed
        :param page_size: controls the batch size for each request
        :return python dict describing all the boards of a user.
        """
        if username is None:
            username = self.username

        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(
                primary="boards", secondary=username
            )

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="boards", secondary=username
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "page_size": page_size,
            "privacy_filter": "all",
            "sort": "custom",
            "username": username,
            "isPrefetch": False,
            "include_archived": True,
            "field_set_key": "profile_grid_item",
            "group_by": "visibility",
            "redux_normalize_feed": True,
            "bookmarks": [next_bookmark],
        }
        source_url = "/{}/boards/".format(username)
        url = self.req_builder.buildGet(
            url=BOARDS_RESOURCE, options=options, source_url=source_url
        )

        result = self.get(url=url).json()
        bookmark = result["resource"]["options"]["bookmarks"][0]

        self.bookmark_manager.add_bookmark(
            primary="boards", secondary=username, bookmark=bookmark
        )
        return result["resource_response"]["data"]

    def boards_all(self, username=None):
        """
        Obtains all boards of a user.
        NOTE: some users might have huge number of boards.
        In such cases 'boards' method (which is batched) should be used in order to avoid memory issues
        :param username: target user, if left blank current user is assumed
        :return all boards of a user
        """
        boards = []
        board_batch = self.boards(username=username)
        while len(board_batch) > 0:
            boards += board_batch
            board_batch = self.boards(username=username)

        return boards

    def get_user_pins(self, username=None, page_size=250, reset_bookmark=False):
        """
        Obtains all the pins of a user.
        This method is batched. In order to obtain all pins
        you need to call it until an empty list is returned.
        :return all pins under all pins board
        :param username: target user, if left blank current user is assumed
        """
        if username is None:
            username = self.username
            own_profile = True
        else:
            own_profile = False

        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(primary="pins", secondary=username)

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="pins", secondary=username
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "username": username,
            "is_own_profile_pins": own_profile,
            "field_set_key": "grid_item",
            "pin_filter": None,
            "bookmarks": [next_bookmark],
            "page_size": page_size,
        }
        url = self.req_builder.buildGet(url=USER_PIN_RESOURCE, options=options)

        response = self.get(url=url).json()
        bookmark = response["resource"]["options"]["bookmarks"][0]
        self.bookmark_manager.add_bookmark(
            primary="pins", secondary=username, bookmark=bookmark
        )

        return response["resource_response"]["data"]

    def create_board(
        self, name, description="", category="other", privacy="public", layout="default"
    ):
        """
        Creates a new board and returns the response from pinterest.
        :param name: board name (should be unique per user)
        :param description: board description
        :param category: if you have defined categories (it is not visible to external users)
        :param privacy: can be public or private
        :param layout: looks like a legacy parameter but it is mandatory (can be left as default)
        """
        options = {
            "name": name,
            "description": description,
            "category": category,
            "privacy": privacy,
            "layout": layout,
            "collab_board_email": "true",
            "collaborator_invites_enabled": "true",
        }

        source_url = "/{}/boards/".format(self.email)
        data = self.req_builder.buildPost(options=options, source_url=source_url)
        return self.post(url=CREATE_BOARD_RESOURCE, data=data)

    def delete_board(self, board_id):
        options = {"board_id": board_id}
        data = self.req_builder.buildPost(options=options)
        return self.post(url=DELETE_BOARD_RESOURCE, data=data)

    def follow_board(self, board_id):
        """
        Follows a board with current user.
        :param board_id: the id of the board to follow
        :return python dict with the pinterest response
        """
        options = {"url": "/v3/boards/{}/follow/".format(board_id)}
        data = self.req_builder.buildPost(options=options)
        return self.post(url=FOLLOW_BOARD_RESOURCE, data=data)

    def unfollow_board(self, board_id):
        """
        Unfollows a board with current user.
        :param board_id: the id of the board to follow
        :return python dict with the pinterest response
        """
        options = {"url": "/v3/boards/{}/follow/".format(board_id)}
        data = self.req_builder.buildPost(options=options)
        return self.post(url=UNFOLLOW_BOARD_RESOURCE, data=data)

    def follow_user(self, user_id):
        """
        Follows a user with current user.
        :param user_id: the id of the user to follow
        :return python dict with the pinterest response
        """
        options = {"user_id": user_id}
        data = self.req_builder.buildPost(options=options)
        return self.post(url=FOLLOW_USER_RESOURCE, data=data)

    def unfollow_user(self, user_id):
        """
        Unfollows a user with current user.
        :param user_id: the id of the user to follow
        :return python dict with the pinterest response
        """
        options = {"user_id": user_id}
        data = self.req_builder.buildPost(options=options)
        return self.post(url=UNFOLLOW_USER_RESOURCE, data=data)

    def get_following(self, username=None, page_size=250, reset_bookmark=False):
        """
        Get all users following this particular user.
        This method is batched. In order to obtain all following users
        you need to call it until an empty list is returned.
        :param username: target user, if left blank current user is assumed
        :param page_size:
        :return: python dict describing the 'following' list
        """
        if username is None:
            username = self.username

        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(
                primary="following", secondary=username
            )

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="following", secondary=username
        )

        if next_bookmark == "-end-":
            return []

        source_url = "/{}/_following/".format(self.email)
        options = {
            "isPrefetch": "false",
            "hide_find_friends_rep": "false",
            "username": username,
            "page_size": page_size,
            "bookmarks": [next_bookmark],
        }

        url = self.req_builder.buildGet(
            url=USER_FOLLOWING_RESOURCE, options=options, source_url=source_url
        )

        result = self.get(url=url).json()
        result = result["resource_response"]

        bookmark = "-end-"
        if "bookmark" in result:
            bookmark = result["bookmark"]

        self.bookmark_manager.add_bookmark(
            primary="following", secondary=username, bookmark=bookmark
        )

        return result["data"]

    def get_following_all(self, username=None):
        """
        Obtains list of all users that the specified user follows.
        NOTE: Some users might have huge following lists.
        In such cases using 'get_following' (which is batched) is preferred.
        :param username: target username
        :return: python dict containing all following
        """
        following = []
        following_batch = self.get_following(username=username)
        while len(following_batch) > 0:
            following += following_batch
            following_batch = self.get_following(username=username)

        return following

    def get_user_followers(self, username=None, page_size=250, reset_bookmark=False):
        """
        Obtains a list of user's followers.
        This method is batched. In order to obtain all user followers
        you need to call it until an empty list is returned.
        :param username: target username, is left blank current user is assumed
        :param page_size: batch size
        :return: python dict describing user followers
        """
        if username is None:
            username = self.username

        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(
                primary="followers", secondary=username
            )

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="followers", secondary=username
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "isPrefetch": False,
            "hide_find_friends_rep": True,
            "username": username,
            "page_size": page_size,
            "bookmarks": [next_bookmark],
        }
        source_url = "/{}/_followers/".format(self.username)

        url = self.req_builder.buildGet(
            url=USER_FOLLOWERS_RESOURCE, options=options, source_url=source_url
        )
        result = self.get(url=url).json()
        result = result["resource_response"]

        bookmark = "-end-"

        if "bookmark" in result:
            bookmark = result["bookmark"]

        self.bookmark_manager.add_bookmark(
            primary="followers", secondary=username, bookmark=bookmark
        )

        return result["data"]

    def get_user_followers_all(self, username=None):
        """
        Obtains a list of all the followers a user has.
        NOTE: Some users might have huge followers lists.
        In such cases 'get_user_followers' should be used to avoid memory errors
        :param username: target user, is left blank current user is assumed
        :return: list of follower objects
        """
        followers = []
        followers_batch = self.get_user_followers(username=username)
        while len(followers_batch) > 0:
            followers += followers_batch
            followers_batch = self.get_user_followers(username=username)

        return followers

    def pin(
        self,
        board_id,
        image_url,
        description="",
        link="",
        title="",
        alt_text="",
        section_id=None,
    ):
        """
        Perfoms a pin operation.
        If you want to upload a local image use 'upload_pin'
        :param board_id: id of the target board (current user should have rights to pin to it)
        :param image_url: web url of an image (not local one)
        :param description: pin description. Optional
        :param link: link to include. Optional
        :param title: title can be blank
        :param section_id: board section should be previously defined. Optional
        :return: python dict describing the pinterest response
        """
        options = {
            "board_id": board_id,
            "image_url": image_url,
            "description": description,
            "link": link if link else image_url,
            "scrape_metric": {"source": "www_url_scrape"},
            "method": "uploaded",
            "title": title,
            "alt_text": alt_text,
            "section": section_id,
        }
        source_url = "/pin/find/?url={}".format(self.req_builder.url_encode(image_url))
        data = self.req_builder.buildPost(options=options, source_url=source_url)

        return self.post(url=PIN_RESOURCE_CREATE, data=data)

    def upload_pin(
        self, board_id, image_file, description="", link="", title="", alt_text="", section_id=None
    ):
        """
        Upload a local image file and create a pin.
        Uses Pinterest's S3-based upload flow.
        """
        register_resp = self._register_media_upload("image-story-pin").json()
        upload_data = register_resp["resource_response"]["data"]
        upload_entry = self._extract_upload_entry(upload_data)
        upload_params = upload_entry.get("upload_parameters") or upload_entry.get("s3_upload_data")
        upload_url = upload_entry.get("upload_url", S3_UPLOAD_URL)
        upload_id = upload_entry.get("upload_id", str(uuid.uuid4()))

        self._upload_media_to_s3(upload_url, upload_params, image_file)
        upload_status = self._poll_upload_status(upload_id)
        image_signature = upload_status.get("signature")
        if not image_signature:
            raise PinterestUploadError(
                "Could not get image signature from upload status: " + json.dumps(upload_status)
            )

        options = {
            "board_id": board_id,
            "description": description,
            "link": link,
            "title": title,
            "alt_text": alt_text,
            "section": section_id,
            "upload_id": int(upload_id),
            "image_signature": image_signature,
            "method": "uploaded",
            "scrape_metric": {"source": "www_url_scrape"},
        }
        source_url = "/pin-creation-tool/"
        data = self.req_builder.buildPost(options=options, source_url=source_url)
        return self.post(url=PIN_RESOURCE_CREATE, data=data)

    def repin(self, board_id, pin_id, section_id=None):
        """
        Repin/Save action
        :param board_id: board id, current user should have right to pin to this board
        :param pin_id: pin id to repin
        :param section_id:  board section should be previously defined. Optional
        :return: python dict describing the pinterest response
        """
        options = {
            "board_id": board_id,
            "pin_id": pin_id,
            "section": section_id,
            "is_buyable_pin": False,
        }
        source_url = "/pin/{}/".format(pin_id)
        data = self.req_builder.buildPost(options=options, source_url=source_url)
        return self.post(url=REPIN_RESOURCE_CREATE, data=data)

    def _upload_image(self, image_file):
        file_name = os.path.basename(image_file)
        mime_type = mimetypes.guess_type(image_file)[0]

        form_data = MultipartEncoder(
            fields={"img": ("%s" % file_name, open(image_file, "rb"), mime_type)}
        )

        headers = {
            "Content-Length": "%s" % form_data.len,
            "Content-Type": form_data.content_type,
            "X-UPLOAD-SOURCE": "pinner_uploader",
        }

        return self.post(url=UPLOAD_IMAGE, data=form_data, headers=headers)

    def delete_pin(self, pin_id):
        """
        Deletes a pin the user owns
        :param pin_id: pin id to delete
        :return: python dict describing the pinterest response
        """
        options = {"id": pin_id}
        source_url = "/{}/".format(self.username)
        data = self.req_builder.buildPost(options=options, source_url=source_url)
        return self.post(url=DELETE_PIN_RESOURCE, data=data)

    def comment(self, pin_id, text):
        """
        Put comment on a pin
        :param pin_id: pin id to comment on
        :param text: text of the comment
        :return: python dict describing the pinterest response
        """
        pin_data = self.load_pin(pin_id=pin_id)
        options = {
            "objectId": pin_data["aggregated_pin_data"]["id"],
            "pinId": pin_id,
            "tags": "[]",
            "text": text,
        }
        data = self.req_builder.buildPost(options=options, source_url=pin_id)

        return self.post(url=CREATE_COMMENT_RESOURCE, data=data)

    def load_pin(self, pin_id):
        """
        Loads full information about a pin
        :param pin_id: pin id to load
        :return: python dict describing the pinterest response
        """
        options = {
            "id": pin_id,
            "field_set_key": "auth_web_main_pin",
            "add_fields": "pin.gen_ai_topics",
            "noCache": True,
            "fetch_visual_search_objects": True,
            "get_page_metadata": False,
        }
        source_url = "/pin/{}/".format(pin_id)
        url = self.req_builder.buildGet(
            url=PIN_RESOURCE_GET, options=options, source_url=source_url
        )
        resp = self.get(url=url).json()
        return resp["resource_response"]["data"]

    def get_comments(self, pin_id, page_size=50, reset_bookmark=False):
        """
        Get comments on a pin.
        This method is batched. In order to obtain all comments
        you need to call it until an empty list is returned.
        :param pin_id: target pin id
        :param page_size:  batch size
        :return: list of comment objects
        """
        pin_data = self.load_pin(pin_id=pin_id)

        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(
                primary="pin_comments", secondary=pin_id
            )

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="pin_comments", secondary=pin_id
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "isPrefetch": False,
            "objectId": pin_data["aggregated_pin_data"]["id"],
            "page_size": page_size,
            "redux_normalize_feed": True,
            "bookmarks": [next_bookmark],
        }
        source_url = "/pin/{}/".format(pin_id)
        url = self.req_builder.buildGet(
            url=GET_PIN_COMMENTS_RESOURCE, options=options, source_url=source_url
        )
        resp = self.get(url=url).json()
        resp = resp["resource_response"]

        bookmark = "-end-"
        if "bookmark" in resp:
            bookmark = resp["bookmark"]

        self.bookmark_manager.add_bookmark(
            primary="pin_comments", secondary=pin_id, bookmark=bookmark
        )

        return resp["data"]

    def get_comments_all(self, pin_id):
        """
        Obtains all comments of a pin.
        NOTE: If pin has too many comments this might cause memory issues.
        In such cases use 'get_comments' which is batched
        :param pin_id:
        :return: list of comment objects
        """
        results = []
        search_batch = self.get_comments(pin_id=pin_id)
        while len(search_batch) > 0:
            results += search_batch
            search_batch = self.get_comments(pin_id=pin_id)

        return results

    def delete_comment(self, pin_id, comment_id):
        """
        Deletes a comment
        :param pin_id: pin id to search the comment in
        :param comment_id: comment id
        :return:
        """
        options = {"commentId": comment_id}
        source_url = "/pin/{}/".format(pin_id)
        data = self.req_builder.buildPost(options=options, source_url=source_url)
        return self.post(url=DELETE_COMMENT, data=data)


    def get_board_invites(self, board_id, page_size=100):
        """
        Returns a list of users invited to the specified board.
        This method is batched. In order to obtain all board invites
        you need to call it until an empty list is returned.
        :param board_id: id of target board
        :param page_size: batch size
        :return: list of board objects
        """
        options = {
            "isPrefetch": False,
            "board_id": board_id,
            "sort": "viewer_first",
            "field_set_key": "boardEdit",
            "status_filters": "new,accepted,contact_request_not_approved,pending_approval",
            "include_inactive": True,
            "page_size": page_size,
        }
        url = self.req_builder.buildGet(url=BOARD_INVITES_RESOURCE, options=options)

        resp = self.get(url=url).json()

        return resp["resource_response"]["data"]

    def get_board_invites_all(self, board_id):
        """
        Obtains all invites of a board.
        NOTE: If board has too many invites this might cause memory issues.
        In such cases use 'get_board_invites' which is batched
        :param board_id:
        :return: list of board invite objects
        """
        results = []
        search_batch = self.get_board_invites(board_id=board_id)
        while len(search_batch) > 0:
            results += search_batch
            search_batch = self.get_board_invites(board_id=board_id)

        return results


    def visual_search(
        self, pin_data, x=None, y=None, w=None, h=None, padding=10, reset_bookmark=False
    ):
        """
        Gives access to pinterest search api
        This method is batched. In order to obtain all search results
        you need to call it until an empty list is returned.
        :param pin_data: pin data
        :param x: x position of the cropped part of the image used for searching
        :param y: y position of the cropped part of the image used for searching
        :param w: width of the cropped part of the image used for searching
        :param h: height of the cropped part of the image used for searching
        :param padding: Default padding for cropped image.

        :return: python dict describing the pinterest response
        """

        orig = pin_data["images"]["orig"]
        width = orig["width"]
        height = orig["height"]
        image_signature = pin_data["image_signature"]
        pin_id = pin_data["id"]

        x = padding if x is None else x
        y = padding if y is None else y
        w = width - padding * 2 if w is None else w
        h = height - padding * 2 if h is None else h

        source_url = "/pin/{}/visual-search/?x={}&y={}&w={}&h={}".format(
            pin_id, x, y, w, h
        )

        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(
                primary="visual_search", secondary=source_url
            )

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="visual_search", secondary=source_url
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "isPrefetch": False,
            "pin_id": pin_id,
            "image_signature": image_signature,
            "crop": {"x": x / width, "y": y / height, "w": w / width, "h": h / height},
            "bookmarks": [next_bookmark],
            "no_fetch_context_on_resource": False,
        }
        url = self.req_builder.buildGet(
            url=VISUAL_LIVE_SEARCH_RESOURCE, options=options, source_url=source_url
        )
        resp = self.get(url=url).json()

        bookmark = resp["resource"]["options"]["bookmarks"][0]

        self.bookmark_manager.add_bookmark(
            primary="visual_search", secondary=source_url, bookmark=bookmark
        )

        return resp["resource_response"]["data"]["results"]

    def search(self, scope, query, page_size=250, reset_bookmark=False):
        """
        Gives access to pinterest search api
        This method is batched. In order to obtain all search results
        you need to call it until an empty list is returned.
        NOTE: there is a max number of results set by Pinterest -> 1000
        :param scope: can be pins, buyable_pins, my_pins, videos, or boards
        :param query: search phrase
        :param page_size: batch size
        :return: list of search results
        """

        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(primary="search", secondary=query)

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="search", secondary=query
        )

        if next_bookmark == "-end-":
            return []

        terms = query.split(" ")
        escaped_query = "%20".join(terms)
        term_meta_arr = []
        for t in terms:
            term_meta_arr.append("term_meta[]=" + t)
        term_arg = "%7Ctyped&".join(term_meta_arr)
        source_url = "/search/{}/?q={}&rs=typed&{}%7Ctyped".format(
            scope, escaped_query, term_arg
        )
        options = {
            "isPrefetch": False,
            "auto_correction_disabled": False,
            "query": query,
            "redux_normalize_feed": True,
            "rs": "typed",
            "scope": scope,
            "page_size": page_size,
            "bookmarks": [next_bookmark],
        }
        url = self.req_builder.buildGet(
            url=BASE_SEARCH_RESOURCE, options=options, source_url=source_url
        )
        resp = self.get(url=url).json()

        bookmark = resp["resource"]["options"]["bookmarks"][0]

        self.bookmark_manager.add_bookmark(
            primary="search", secondary=query, bookmark=bookmark
        )
        return resp["resource_response"]["data"]["results"]

    def board_recommendations(self, board_id="", page_size=50, reset_bookmark=False):
        """
        This gives the list of pins you see when you open a board and click on 'More Ideas'
        This method is batched. In order to obtain all board recommendations
        you need to call it until an empty list is returned.
        :param board_id: target board id
        :param page_size: batch size
        :return: list of board recommendations
        """
        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(
                primary="boards", secondary=board_id
            )

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="boards", secondary=board_id
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "isPrefetch": False,
            "type": "board",
            "id": board_id,
            "page_size": page_size,
            "bookmarks": [next_bookmark],
        }
        url = self.req_builder.buildGet(url=BOARD_RECOMMEND_RESOURCE, options=options)

        response = self.get(url=url).json()
        bookmark = response["resource"]["options"]["bookmarks"][0]
        self.bookmark_manager.add_bookmark(
            primary="boards", secondary=board_id, bookmark=bookmark
        )

        return response["resource_response"]["data"]

    def get_pinnable_images(self, url):
        """
        Simple API pinterest uses to suggest images from site.
        """
        options = {
            "isPrefetch": "false",
            "url": url,
            "source": "pin_create",
            "appendItems": "false",
            "followRedirects": "true",
        }
        url = self.req_builder.buildGet(
            url=PINNABLE_IMAGES_RESOURCE, source_url="/pin-builder/", options=options
        )

        res = self.get(url=url).json()
        res = res["resource_response"]["data"]["items"]
        urls = []
        for item in res:
            if "url" in item:
                urls.append(item["url"])
        return urls

    def home_feed(self, page_size=100, reset_bookmark=False):
        """
        This gives the list of pins you see when you open the pinterest home page.
        This method is batched. In order to obtain all home feed items
        you need to call it until an empty list is returned.
        :param page_size:
        :return:
        """
        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(primary="home_feed")

        next_bookmark = self.bookmark_manager.get_bookmark(primary="home_feed")

        if next_bookmark == "-end-":
            return []

        options = {
            "bookmarks": [next_bookmark],
            "isPrefetch": False,
            "field_set_key": "hf_grid_partner",
            "in_nux": False,
            "prependPartner": True,
            "prependUserNews": False,
            "static_feed": False,
            "page_size": page_size,
        }
        url = self.req_builder.buildGet(url=USER_HOME_FEED_RESOURCE, options=options)

        response = self.get(url=url).json()

        bookmark = "-end-"

        if "bookmark" in response["resource_response"]:
            bookmark = response["resource_response"]["bookmark"]

        self.bookmark_manager.add_bookmark(primary="home_feed", bookmark=bookmark)

        return response["resource_response"]["data"]

    def board_feed(self, board_id="", page_size=250, reset_bookmark=False):
        """
        Gives a list of all pins in a board.
        This method is batched. In order to obtain all pins in a board
        you need to call it until an empty list is returned.
        """
        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(
                primary="board_feed", secondary=board_id
            )

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="board_feed", secondary=board_id
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "isPrefetch": False,
            "board_id": board_id,
            "field_set_key": "partner_react_grid_pin",
            "filter_section_pins": True,
            "layout": "default",
            "page_size": page_size,
            "redux_normalize_feed": True,
            "bookmarks": [next_bookmark],
        }

        url = self.req_builder.buildGet(url=BOARD_FEED_RESOURCE, options=options)
        response = self.get(url=url, headers={'X-Pinterest-PWS-Handler':'www/[username].js'}).json()
        bookmark = response["resource"]["options"]["bookmarks"][0]
        self.bookmark_manager.add_bookmark(
            primary="board_feed", secondary=board_id, bookmark=bookmark
        )

        return response["resource_response"]["data"]

    def initiate_conversation(self, user_ids):
        """
        Initiates a new conversation with one or more users
        :return: python dict object describing the pinterest response
        """
        options = {"user_ids": user_ids, "emails": []}
        data = self.req_builder.buildPost(options=options)
        return self.post(url=CONVERSATION_RESOURCE_CREATE, data=data)

    def send_message(self, message="", conversation_id="", pin_id=""):
        """
        Sends a new mesage to an already initiated conversation
        """
        options = {
            "conversation_id": conversation_id,
            "text": message,
            "field_set_key": ["default_with_reactions"],
        }
        if pin_id:
            options["pin"] = pin_id

        data = self.req_builder.buildPost(options=options)
        return self.post(url=SEND_MESSAGE, data=data)

    def load_conversation(self, conversation_id=""):
        """
        Loads a list of all messages in a conversation
        """
        messages = []

        message_batch = self._load_conversation_batch(conversation_id=conversation_id)
        while len(message_batch) > 0:
            messages += message_batch
            message_batch = self._load_conversation_batch(
                conversation_id=conversation_id
            )

        return messages

    def _load_conversation_batch(self, conversation_id="", page_size=25):
        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="conversation_messages", secondary=conversation_id
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "isPrefetch": False,
            "page_size": page_size,
            "conversation_id": conversation_id,
            "bookmarks": [next_bookmark],
        }

        url = self.req_builder.buildGet(url=LOAD_CONVERSATION, options=options)
        response = self.get(url=url).json()

        bookmark = response["resource"]["options"]["bookmarks"][0]
        self.bookmark_manager.add_bookmark(
            primary="conversation_messages", secondary=conversation_id, bookmark=bookmark
        )

        return response["resource_response"]["data"]

    def get_conversations(self):
        """
        Loads a list of all conversations the current user has
        """
        conversations = []
        conv_batch = self._get_conversation_batch()
        while len(conv_batch) > 0:
            conversations += conv_batch
            conv_batch = self._get_conversation_batch()

        return conversations

    def _get_conversation_batch(self):
        next_bookmark = self.bookmark_manager.get_bookmark(primary="conversations")

        if next_bookmark == "-end-":
            return []

        options = {
            "isPrefetch": False,
            "field_set_key": "default",
            "bookmarks": [next_bookmark],
        }

        url = self.req_builder.buildGet(url=CONVERSATION_RESOURCE, options=options)
        response = self.get(url=url).json()
        next_bookmark = response["resource"]["options"]["bookmarks"][0]
        self.bookmark_manager.add_bookmark(
            primary="conversations", bookmark=next_bookmark
        )

        return response["resource_response"]["data"]

    def create_board_section(self, board_id="", section_name=""):
        """
        Creates a new section in a board the current user owns
        """
        options = {
            "board_id": board_id,
            "initial_pins": [],
            "name": section_name,
            "name_source": 0,
        }

        data = self.req_builder.buildPost(options=options)
        return self.post(url=BOARD_SECTION_RESOURCE, data=data)

    def get_board_sections(self, board_id="", page_size=100, reset_bookmark=False):
        """
        Obtains a list of all sections of a board
        """
        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(
                primary="board_sections", secondary=board_id
            )

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="board_sections", secondary=board_id
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "isPrefetch": False,
            "board_id": board_id,
            "page_size": page_size,
            "redux_normalize_feed": True,
            "bookmarks": [next_bookmark],
        }

        url = self.req_builder.buildGet(url=GET_BOARD_SECTIONS, options=options)
        response = self.get(url=url).json()
        bookmark = response["resource"]["options"]["bookmarks"][0]
        self.bookmark_manager.add_bookmark(
            primary="board_sections", secondary=board_id, bookmark=bookmark
        )

        return response["resource_response"]["data"]

    def get_section_pins(self, section_id="", page_size=25, reset_bookmark=False):
        """
        Returns a list of all pins in a board section.
        This method is batched. In order to obtain all pins in the section
        you need to call it until an empty list is returned.
        """
        if reset_bookmark:
            self.bookmark_manager.reset_bookmark(
                primary="section_pins", secondary=section_id
            )

        next_bookmark = self.bookmark_manager.get_bookmark(
            primary="section_pins", secondary=section_id
        )

        if next_bookmark == "-end-":
            return []

        options = {
            "currentFilter": -1,
            "field_set_key": "react_grid_pin",
            "is_own_profile_pins": True,
            "page_size": page_size,
            "redux_normalize_feed": True,
            "section_id": section_id,
            "orbac_subject_id": "",
            "bookmarks": [next_bookmark],
        }

        url = self.req_builder.buildGet(url=GET_BOARD_SECTION_PINS, options=options)
        response = self.get(url=url).json()
        bookmark = response["resource"]["options"]["bookmarks"][0]
        self.bookmark_manager.add_bookmark(
            primary="section_pins", secondary=section_id, bookmark=bookmark
        )

        pins = [d for d in response["resource_response"]["data"] if "pinner" in d]
        return pins

    def delete_board_section(self, section_id=""):
        """
        Deletes a board section by id
        """
        options = {"section_id": section_id}
        data = self.req_builder.buildPost(options=options)
        return self.post(url=BOARD_SECTION_EDIT_RESOURCE, data=data)

    def type_ahead(self, scope="pins", count=5, term=""):
        """
        returns Pinterest predictions for given term.
        Response may include user profiles.
        Example term "dada" gives ["dadaism","dada art"] etc.
        :param scope: always "pins"
        :param count: max guess number
        :param term: word to be typed ahead
        :return: response items
        """

        source_url = "/"
        options = {
            "pin_scope": scope,
            "count": count,
            "term": term,
            "no_fetch_context_on_resource": False,
        }
        url = self.req_builder.buildGet(TYPE_AHEAD_RESOURCE, options, source_url)

        resp = self.get(url=url).json()
        return resp["resource_response"]["data"]["items"]

    # ── S3-based upload helpers ──────────────────────────────────────────

    def _api_resource_post(self, url_path, data, source_url='/pin-creation-tool/'):
        options = {"url": url_path, "data": data}
        post_data = self.req_builder.buildPost(options=options, source_url=source_url)
        return self.post(url=API_RESOURCE_CREATE, data=post_data)

    def _register_media_upload(self, media_type, duration_ms=None):
        upload_id = str(uuid.uuid4())
        media_info = {"id": upload_id, "media_type": media_type}
        if duration_ms is not None:
            media_info["upload_aux_data"] = {
                "clips": [{"durationMs": duration_ms, "isFromImage": False, "startTimestampMs": -1}]
            }
        data = {"media_info_list": json.dumps([media_info])}
        return self._api_resource_post(url_path="/v3/media/uploads/register/batch/", data=data)

    def _extract_upload_entry(self, upload_data):
        for key, value in upload_data.items():
            if isinstance(value, dict) and ("s3_upload_data" in value or "upload_parameters" in value):
                return value
        raise PinterestUploadError(
            "No upload entry found in registration response: " + json.dumps(upload_data)
        )

    def _upload_media_to_s3(self, upload_url, upload_params, file_path):
        file_name = os.path.basename(file_path)
        mime_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"

        fields = {}
        for key, value in upload_params.items():
            if key == "file":
                continue
            fields[key] = str(value)

        with open(file_path, "rb") as f:
            fields["file"] = (file_name, f, mime_type)
            form_data = MultipartEncoder(fields=fields)

            with requests.Session() as s3_session:
                s3_resp = s3_session.post(
                    upload_url,
                    data=form_data,
                    headers={
                        "Content-Type": form_data.content_type,
                        "Content-Length": str(form_data.len),
                        "Origin": "https://www.pinterest.com",
                        "Referer": "https://www.pinterest.com/",
                        "User-Agent": AGENT_STRING,
                    },
                    proxies=self.proxies,
                )

        if s3_resp.status_code not in (200, 201, 204):
            raise PinterestUploadError(
                "S3 upload failed with status {}: {}".format(s3_resp.status_code, s3_resp.text[:500])
            )
        return s3_resp

    def _poll_upload_status(self, upload_id, max_retries=30, interval=2):
        for _ in range(max_retries):
            options = {"upload_ids": [str(upload_id)]}
            url = self.req_builder.buildGet(
                url=VIP_RESOURCE_GET, options=options, source_url="/pin-creation-tool/"
            )
            resp = self.get(url=url).json()
            data = resp.get("resource_response", {}).get("data", {})
            upload_info = data.get(str(upload_id), data)

            if isinstance(upload_info, dict):
                status = upload_info.get("status", "unknown")
                has_result = (
                    upload_info.get("signature")
                    or upload_info.get("video_signature")
                    or upload_info.get("image_url")
                )
                if has_result or status == "succeeded":
                    return upload_info

            time.sleep(interval)

        raise PinterestUploadError("Upload processing timed out for upload_id: {}".format(upload_id))

    # ── Video pin upload ─────────────────────────────────────────────────

    def _get_video_info(self, video_file):
        result = subprocess.run(
            ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", video_file],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            return None
        try:
            probe = json.loads(result.stdout)
        except json.JSONDecodeError:
            return None

        info = {"duration_ms": int(float(probe["format"]["duration"]) * 1000)}
        for stream in probe.get("streams", []):
            if stream.get("codec_type") == "video":
                info["width"] = stream.get("width", 1080)
                info["height"] = stream.get("height", 1920)
                break
        info.setdefault("width", 1080)
        info.setdefault("height", 1920)
        return info

    def _extract_video_cover_image(self, video_file):
        cover_image = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
        cover_image.close()
        result = subprocess.run(
            ["ffmpeg", "-y", "-i", video_file, "-vframes", "1", "-q:v", "2", cover_image.name],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            os.remove(cover_image.name)
            raise PinterestUploadError("Failed to extract cover image: " + result.stderr[:300])
        return cover_image.name

    def upload_video_pin(
        self, video_file, title="", description="", link="",
        board_id=None, alt_text="", duration_ms=None,
        width=None, height=None, cover_image_file=None,
    ):
        """
        Upload a video pin (Story Pin / Idea Pin) to Pinterest.
        Requires ffmpeg/ffprobe on PATH unless duration_ms, width, height,
        and cover_image_file are all provided.
        """
        if duration_ms is None or width is None or height is None:
            info = self._get_video_info(video_file)
            if info is None:
                raise PinterestUploadError(
                    "Could not probe video. Install ffprobe or provide duration_ms, width, and height."
                )
            duration_ms = duration_ms or info["duration_ms"]
            width = width or info["width"]
            height = height or info["height"]

        # Pinterest requires 9:16 (0.56) for story/idea pin canvas
        aspect_ratio = 0.56

        register_resp = self._register_media_upload("video-story-pin", duration_ms).json()
        upload_data = register_resp["resource_response"]["data"]
        upload_entry = self._extract_upload_entry(upload_data)
        upload_params = upload_entry.get("upload_parameters") or upload_entry.get("s3_upload_data")
        upload_url = upload_entry.get("upload_url", S3_UPLOAD_URL)
        upload_id = upload_entry.get("upload_id", str(uuid.uuid4()))

        self._upload_media_to_s3(upload_url, upload_params, video_file)

        upload_status = self._poll_upload_status(upload_id)
        video_signature = upload_status.get("signature") or upload_status.get("video_signature")

        if cover_image_file:
            cover_path = cover_image_file
            remove_cover = False
        else:
            cover_path = self._extract_video_cover_image(video_file)
            remove_cover = True

        try:
            img_register_resp = self._register_media_upload("image-story-pin").json()
            img_upload_data = img_register_resp["resource_response"]["data"]
            img_upload_entry = self._extract_upload_entry(img_upload_data)
            img_upload_params = img_upload_entry.get("upload_parameters") or img_upload_entry.get("s3_upload_data")
            img_upload_url = img_upload_entry.get("upload_url", S3_UPLOAD_URL)
            img_upload_id = img_upload_entry.get("upload_id")

            self._upload_media_to_s3(img_upload_url, img_upload_params, cover_path)
            img_status = self._poll_upload_status(img_upload_id)
            pin_image_signature = img_status.get("signature") or img_status.get("video_signature")
        finally:
            if remove_cover and os.path.exists(cover_path):
                os.remove(cover_path)

        story_pin = {
            "metadata": {
                "pin_title": title,
                "pin_image_signature": pin_image_signature,
                "canvas_aspect_ratio": aspect_ratio,
            },
            "pages": [{
                "blocks": [{
                    "block_style": {"height": 100, "width": 100, "x_coord": 0, "y_coord": 0},
                    "tracking_id": str(upload_id),
                    "video_signature": video_signature,
                    "type": 3,
                }],
                "clips": [{
                    "clip_type": 1,
                    "end_time_ms": -1,
                    "is_converted_from_image": False,
                    "source_media_height": height,
                    "source_media_width": width,
                    "start_time_ms": -1,
                }],
                "layout": 0,
                "style": {"background_color": "#FFFFFF"},
            }],
        }

        options = {
            "alt_text": alt_text,
            "allow_shopping_rec": True,
            "description": description,
            "is_comments_allowed": True,
            "is_removable": False,
            "is_unified_builder": True,
            "link": link,
            "story_pin": json.dumps(story_pin),
            "user_mention_tags": "[]",
        }
        if board_id:
            options["board_id"] = board_id

        data = self.req_builder.buildPost(options=options, source_url="/pin-creation-tool/")
        return self.post(url=STORY_PIN_RESOURCE_CREATE, data=data)

