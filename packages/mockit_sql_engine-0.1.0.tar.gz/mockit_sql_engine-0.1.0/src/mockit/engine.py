import sqlalchemy as sa
from sqlalchemy import create_engine, MetaData, Table, insert, text
from sqlalchemy.engine import reflection
from faker import Faker
import random
import logging

# Setup professional logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mockit")

fake = Faker()

def get_mock_value(column):
    """
    Advanced mapping of SQL types and column names to Faker providers.
    Handles standard types, strings with length limits, and common names.
    """
    name = column.name.lower()
    # Get the string representation of the type (e.g., 'INTEGER', 'VARCHAR(50)', 'JSONB')
    ctype = str(column.type).upper()

    # 1. Specialized Name-based Smarts (Highest Priority)
    if "email" in name: return fake.email()
    if "user" in name or "name" in name: return fake.name()
    if "city" in name: return fake.city()
    if "phone" in name: return fake.phone_number()
    if "status" in name: return random.choice(['SUCCESS', 'FAILED', 'PENDING', 'ACTIVE'])
    if "url" in name: return fake.url()
    
    # 2. Complex Type Handling (JSON/UUID)
    if "JSON" in ctype:
        return {"id": random.randint(1, 100), "mocked": True, "data": fake.word()}
    if "UUID" in ctype:
        return fake.uuid4()

    # 3. Numeric Types
    if "INT" in ctype:
        return random.randint(1, 1000)
    if any(x in ctype for x in ["NUMERIC", "DECIMAL", "FLOAT", "DOUBLE"]):
        return round(random.uniform(10.0, 500.0), 2)
    
    # 4. Boolean
    if "BOOL" in ctype:
        return random.choice([True, False])
    
    # 5. Dates & Timestamps
    if "DATE" in ctype or "TIME" in ctype:
        return fake.date_time_this_year()
    
    # 6. String/Varchar with Length Protection
    if "CHAR" in ctype or "TEXT" in ctype:
        # Respect VARCHAR(N) limits if they exist to prevent 'value too long' errors
        limit = getattr(column.type, 'length', None)
        val = fake.word() if not limit or limit > 10 else fake.lexify("????")
        return val[:limit] if limit else val
    
    # Final Fallback
    return fake.word()

def mock_table(source_uri, target_uri, table_name, row_count, truncate=True):
    """
    Enterprise-grade table mocking:
    - Reflects source schema (Redshift/Postgres/etc)
    - Replicates structure to local Target
    - Strips constraints that cause local failures (FKs)
    - Generates type-safe fake data
    """
    src_engine = create_engine(source_uri)
    tgt_engine = create_engine(target_uri)
    
    schema = None
    actual_table_name = table_name
    if "." in table_name:
        schema, actual_table_name = table_name.split(".")

    try:
        # 1. Reflect Source Blueprint
        metadata_src = MetaData()
        source_table = Table(actual_table_name, metadata_src, autoload_with=src_engine, schema=schema)
        logger.info(f"Reflected source schema for {table_name}")

        # 2. Build Local Target Blueprint
        metadata_tgt = MetaData()
        target_table = Table(actual_table_name, metadata_tgt, schema=schema)
        
        for col in source_table.columns:
            new_col = col.copy()
            # Disable unique constraints and clear Foreign Keys to allow isolated testing
            new_col.unique = False
            new_col.foreign_keys.clear()
            target_table.append_column(new_col)

        # 3. Create Table on Local Target if missing
        metadata_tgt.create_all(tgt_engine)

        # 4. Clean Slate (Truncate)
        if truncate:
            with tgt_engine.begin() as conn:
                # Use RESTART IDENTITY to reset SERIAL counters to 1
                full_name = f"{schema}.{actual_table_name}" if schema else actual_table_name
                conn.execute(text(f"TRUNCATE TABLE {full_name} RESTART IDENTITY CASCADE;"))
                logger.info(f"Table {full_name} truncated and identities reset.")

        # 5. Generate Smart Mock Data
        mock_rows = []
        for _ in range(row_count):
            row_data = {}
            for col in target_table.columns:
                # Skip Auto-increment columns; let Local Postgres generate IDs
                if col.primary_key and col.autoincrement:
                    continue
                row_data[col.name] = get_mock_value(col)
            mock_rows.append(row_data)

        # 6. Bulk Insert into Local
        with tgt_engine.begin() as conn:
            conn.execute(insert(target_table), mock_rows)
        
        logger.info(f"✅ Successfully injected {row_count} mock rows into {table_name}")

    except Exception as e:
        logger.error(f"❌ Robust Mocking Failed: {str(e)}")
        raise e