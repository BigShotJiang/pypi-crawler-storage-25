import click
import logging
from .engine import mock_table

# Disable extra SQLAlchemy logging unless the user wants --debug
logging.basicConfig(level=logging.WARNING)

@click.command()
@click.option('--source', required=True, help='Source DB URI (e.g. Redshift/Prod)')
@click.option('--target', required=True, help='Target DB URI (e.g. Local Postgres)')
@click.option('--table', required=True, help='Table name (can be schema.table)')
@click.option('--rows', default=10, type=int, help='Number of rows to generate')
@click.option('--reset', is_flag=True, default=True, help='Wipe target table before inserting (True by default)')
@click.option('--debug', is_flag=True, help='Show full stack trace on error')
def main(source, target, table, rows, reset, debug):
    """🚀 MockIt: Recreate prod schemas locally with fake data."""
    
    if debug:
        logging.getLogger("mockit").setLevel(logging.INFO)

    click.secho(f"🔍 Analyzing schema for {table}...", fg='cyan')
    
    try:
        # We pass the 'reset' flag to the 'truncate' parameter in engine.py
        mock_table(
            source_uri=source, 
            target_uri=target, 
            table_name=table, 
            row_count=rows, 
            truncate=reset
        )
        
        click.secho(f"✨ Success!", fg='green', bold=True)
        click.echo(f"  - Table: {table}")
        click.echo(f"  - Rows Created: {rows}")
        click.echo(f"  - Reset Performed: {reset}")
        
    except Exception as e:
        click.secho(f"❌ Error: {e}", fg='red', err=True)
        if not debug:
            click.echo("\n💡 Tip: Use --debug for a full stack trace or check your DB credentials.")
        else:
            raise e

if __name__ == '__main__':
    main()