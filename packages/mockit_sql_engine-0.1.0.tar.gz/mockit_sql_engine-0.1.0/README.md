# MockIt 🚀

[![PyPI version](https://img.shields.io/pypi/v/mockit.svg)](https://pypi.org/project/mockit/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Replicate cloud database schemas locally with high-fidelity synthetic data.**

MockIt is a CLI-first developer tool designed for Data Engineers who want to escape the high costs and latency of testing against production cloud warehouses like AWS Redshift or Snowflake.

---

## 🌟 Key Features

* **Schema Reflection**: Automatically inspects source tables and clones their structure (columns, types, nullability) to a local target.
* **Smart Type Mapping**: Intelligently maps SQL types to relevant `Faker` providers (e.g., `JSON` columns get JSON objects, `VARCHAR(email)` gets realistic email addresses).
* **Constraint Stripping**: Automatically removes Foreign Key constraints during local replication to allow for isolated table testing.
* **Identity Management**: Handles `SERIAL` and `IDENTITY` columns by skipping manual inserts, allowing the local database to manage primary keys.
* **Transaction Safety**: Built on SQLAlchemy 2.0 for robust, atomic data injections.

---

## 🚀 Installation

Install MockIt via pip:

```bash
pip install mockit