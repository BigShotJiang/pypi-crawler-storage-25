"""Plan-file convention (P2.2).

The model's plan-mode scratchpad lives at
``.dsc/plans/plan-{session_id[:8]}.md``. The directory is created on
demand. This is intentionally OPT-IN: nothing auto-creates the file.
The model can write to it via the standard tools (``view`` first, then
``str_replace``) if it wants a persisted scratchpad; otherwise the
plan lives only in-context.

The path is exposed via the cli.py session state so the banner / status
line can show it; the path itself is gitignored via the existing
``.dsc/`` rule in ``.gitignore``.
"""
from __future__ import annotations

from pathlib import Path

PLANS_DIR_NAME = ".dsc/plans"


def plan_file_path(session_id: str, *, root: Path | None = None) -> Path:
    """Return the conventional plan-file path for `session_id`.

    Creates the parent directory if missing. Uses the first 8 chars of
    `session_id` for a short, debuggable filename (collisions across
    sessions are acceptable — the file is session-local scratchpad,
    not durable storage).
    """
    project_root = root if root is not None else Path.cwd()
    plans_dir = project_root / PLANS_DIR_NAME
    plans_dir.mkdir(parents=True, exist_ok=True)
    short = (session_id or "")[:8] or "session"
    return plans_dir / f"plan-{short}.md"
