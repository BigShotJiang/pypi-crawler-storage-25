"""User preferences store at ~/.config/fred/preferences.json.

Separate file from credentials.json so re-auth (which rewrites the
creds file) doesn't blow away preferences. Mode 0644 — not secrets.

Today this stores per-slot model choices and the once-per-session
"warned about pro" flag. New keys can be added freely; load tolerates
missing keys.
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

DEFAULT_PREFS_PATH = Path.home() / ".config" / "fred" / "preferences.json"


@dataclass
class Preferences:
    """Persisted preferences. version=1 is the current schema."""

    version: int = 1
    main_model: str | None = None
    editor_model: str | None = None
    weak_model: str | None = None
    # Once a user confirms `/pro` in any session we don't need to warn
    # them again. Persisted across sessions so re-launching `fred`
    # doesn't re-prompt every time. Reset by deleting the file.
    warned_about_pro: bool = False
    # Reserved for future presets (e.g. `balanced` = flash main + pro
    # editor); always None for now so the field exists in the file
    # without a schema bump later.
    preset: str | None = None

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> "Preferences":
        return cls(
            version=int(data.get("version", 1)),
            main_model=data.get("main_model"),
            editor_model=data.get("editor_model"),
            weak_model=data.get("weak_model"),
            warned_about_pro=bool(data.get("warned_about_pro", False)),
            preset=data.get("preset"),
        )


def _ensure_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def load_preferences(path: Path | None = None) -> Preferences:
    """Return preferences or defaults. Never raises — a malformed file
    logs a warning and falls back to defaults rather than blocking startup.
    """
    p = path or DEFAULT_PREFS_PATH
    if not p.exists():
        return Preferences()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"fred: could not read preferences at {p}: {e}", file=sys.stderr)
        return Preferences()
    try:
        return Preferences.from_json(data)
    except (KeyError, ValueError) as e:
        print(f"fred: malformed preferences at {p}: {e}", file=sys.stderr)
        return Preferences()


def save_preferences(prefs: Preferences, path: Path | None = None) -> None:
    """Atomic write with mode 0644. Logs and returns on failure rather
    than raising — preferences are best-effort."""
    p = path or DEFAULT_PREFS_PATH
    _ensure_dir(p)
    try:
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(asdict(prefs), indent=2) + "\n", encoding="utf-8")
        os.chmod(tmp, 0o644)
        tmp.replace(p)
    except OSError as e:
        print(f"fred: could not write preferences to {p}: {e}", file=sys.stderr)
