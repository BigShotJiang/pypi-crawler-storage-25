"""DeepSeek client wrapper + tool_call streaming accumulator.

DeepSeek is OpenAI-compatible at https://api.deepseek.com/v1, so we use
the official `openai` SDK with base_url override. We disable retries so
transient 5xx during streaming don't silently replay the entire stream
(which would duplicate tool calls).

Outer retry layer (`_retry_stream`) sits ABOVE the SDK and retries only
when no `tool_call_start` has been emitted yet — once a tool delta has
flowed to the agent loop, replaying the upstream call would cause the
model to re-execute already-dispatched tool calls.
"""
from __future__ import annotations

import copy
import json
import os
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterator

import httpx
import openai
from openai import OpenAI

from dsc.cache_segments import CacheableRequest, Segment, cacheable_prefix_size_estimate

DEFAULT_BASE_URL = "https://api.fredcode.net/v1"
DEFAULT_MODEL = "deepseek-v4-flash"

# Configurable via env at call time, captured once when the client is built.
_DEFAULT_RETRIES = 3
_DEFAULT_BACKOFF_BASE_MS = 500


# Exceptions classified as transient. Order matters only for `isinstance` cost;
# behavior is the same.
_RETRYABLE_EXCEPTIONS: tuple[type[BaseException], ...] = (
    # httpx network/transport errors
    httpx.ConnectError,
    httpx.ReadTimeout,
    httpx.WriteTimeout,
    httpx.PoolTimeout,
    httpx.ConnectTimeout,
    httpx.RemoteProtocolError,
    httpx.RequestError,  # base class — catches NetworkError, TimeoutException, etc.
    # OpenAI SDK transient classes
    openai.APIConnectionError,  # also covers APITimeoutError (subclass)
    openai.APITimeoutError,
    openai.RateLimitError,
    openai.InternalServerError,  # 5xx
)


def _is_retryable(exc: BaseException) -> bool:
    return isinstance(exc, _RETRYABLE_EXCEPTIONS)


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict
    raw_arguments: str
    parse_error: str | None = None


@dataclass
class StreamResult:
    text: str = ""
    reasoning: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str | None = None
    usage: dict | None = None


class ToolCallAccumulator:
    """Accumulates partial tool_call deltas from a streaming response.

    OpenAI streams tool_calls as a list of deltas; each delta has a stable
    `index` per call. Across deltas, `id` and `function.name` arrive once
    (early), and `function.arguments` arrives as a chunked string that
    must be concatenated. DeepSeek follows the same shape.
    """

    def __init__(self) -> None:
        self._slots: dict[int, dict[str, Any]] = {}

    def add(self, delta_tool_calls) -> list[tuple[str, dict]]:
        events: list[tuple[str, dict]] = []
        for d in delta_tool_calls or []:
            idx = d.index
            slot = self._slots.setdefault(
                idx, {"id": None, "name": None, "args_str": ""}
            )
            if getattr(d, "id", None):
                slot["id"] = d.id
            fn = getattr(d, "function", None)
            if fn:
                if getattr(fn, "name", None):
                    slot["name"] = fn.name
                    if slot["id"]:
                        events.append(
                            ("tool_call_start", {"index": idx, "id": slot["id"], "name": fn.name})
                        )
                if getattr(fn, "arguments", None):
                    slot["args_str"] += fn.arguments
                    events.append(
                        ("tool_call_args_delta", {"index": idx, "chunk": fn.arguments})
                    )
        return events

    def finalize(self) -> list[ToolCall]:
        out: list[ToolCall] = []
        for idx in sorted(self._slots):
            slot = self._slots[idx]
            raw = slot["args_str"] or "{}"
            try:
                parsed = json.loads(raw)
                err = None
            except json.JSONDecodeError as e:
                parsed = {}
                err = f"Invalid JSON arguments: {e}"
            out.append(
                ToolCall(
                    id=slot["id"] or "",
                    name=slot["name"] or "",
                    arguments=parsed,
                    raw_arguments=raw,
                    parse_error=err,
                )
            )
        return out


class StreamSession:
    """Iterator over streaming events; exposes assembled result after iteration.

    Yields tuples of (event_type, payload):
      - ("text", str)
      - ("tool_call_start", {index, id, name})
      - ("tool_call_args_delta", {index, chunk})

    Sets `self.tool_started = True` as soon as any tool-call event is
    emitted, so the outer retry layer can refuse to replay this attempt.
    """

    def __init__(self, openai_stream) -> None:
        self._stream = openai_stream
        self._acc = ToolCallAccumulator()
        self.text: str = ""
        self.reasoning: str = ""
        self.finish_reason: str | None = None
        self.usage: dict | None = None
        self._consumed = False
        self.tool_started: bool = False

    def __iter__(self) -> Iterator[tuple[str, Any]]:
        if self._consumed:
            raise RuntimeError("StreamSession already consumed")
        self._consumed = True
        for chunk in self._stream:
            if getattr(chunk, "usage", None):
                self.usage = chunk.usage.model_dump() if hasattr(chunk.usage, "model_dump") else dict(chunk.usage)
            if not chunk.choices:
                continue
            choice = chunk.choices[0]
            delta = choice.delta
            # DeepSeek thinking-mode reasoning trace; must be round-tripped to API
            rc = getattr(delta, "reasoning_content", None)
            if rc:
                self.reasoning += rc
                yield ("reasoning", rc)
            if getattr(delta, "content", None):
                self.text += delta.content
                yield ("text", delta.content)
            tcs = getattr(delta, "tool_calls", None)
            if tcs:
                for ev in self._acc.add(tcs):
                    if ev[0] in ("tool_call_start", "tool_call_args_delta"):
                        self.tool_started = True
                    yield ev
            if choice.finish_reason:
                self.finish_reason = choice.finish_reason

    @property
    def tool_calls(self) -> list[ToolCall]:
        return self._acc.finalize()

    def result(self) -> StreamResult:
        return StreamResult(
            text=self.text,
            reasoning=self.reasoning,
            tool_calls=self.tool_calls,
            finish_reason=self.finish_reason,
            usage=self.usage,
        )


class RetryingStreamSession:
    """Outer wrapper around `StreamSession` that retries transient failures.

    Retries fire ONLY when:
      - the inner session raises a retryable exception, AND
      - no tool-call delta has been emitted yet on this attempt.

    If a tool-call delta has already been yielded to the consumer, the
    exception propagates immediately — replaying would cause the model
    to re-dispatch already-handled tool calls (the AGENTS.md sharp edge).

    Exposes the same interface as `StreamSession`:
      - `__iter__()` yields (event_type, payload) tuples
      - `.result()` returns a `StreamResult`
      - `.tool_calls` finalized list (after iteration)
    """

    def __init__(
        self,
        opener: Callable[[], StreamSession],
        *,
        max_retries: int,
        backoff_base_ms: int,
        on_retry: Callable[[int, BaseException, int], None] | None = None,
        on_abort: Callable[[BaseException, str, int], None] | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._opener = opener
        self._max_retries = max_retries
        self._backoff_base_ms = backoff_base_ms
        self._on_retry = on_retry
        self._on_abort = on_abort
        self._sleep = sleep
        self._consumed = False
        self._inner: StreamSession | None = None

    def __iter__(self) -> Iterator[tuple[str, Any]]:
        if self._consumed:
            raise RuntimeError("RetryingStreamSession already consumed")
        self._consumed = True
        attempt = 1
        started_perf = time.perf_counter()
        while True:
            try:
                self._inner = self._opener()
                yield from self._inner
                return
            except BaseException as exc:  # noqa: BLE001 — re-raised below
                inner = self._inner
                tool_started = bool(getattr(inner, "tool_started", False))
                elapsed_ms = int((time.perf_counter() - started_perf) * 1000)
                if not _is_retryable(exc):
                    raise
                if tool_started:
                    if self._on_abort is not None:
                        self._on_abort(exc, "tool_dispatched", elapsed_ms)
                    raise
                if attempt >= self._max_retries:
                    if self._on_abort is not None:
                        self._on_abort(exc, "max_attempts", elapsed_ms)
                    raise
                # Exponential backoff: base, base*2, base*4, ...
                backoff_ms = self._backoff_base_ms * (2 ** (attempt - 1))
                # `attempt` in the callback is the NEW attempt number after
                # backoff (1-indexed; attempt 2 = first retry).
                if self._on_retry is not None:
                    self._on_retry(attempt + 1, exc, backoff_ms)
                self._sleep(backoff_ms / 1000.0)
                attempt += 1

    @property
    def tool_calls(self) -> list[ToolCall]:
        if self._inner is None:
            return []
        return self._inner.tool_calls

    def result(self) -> StreamResult:
        if self._inner is None:
            return StreamResult()
        return self._inner.result()

    @property
    def tool_started(self) -> bool:
        return bool(getattr(self._inner, "tool_started", False))


class DSClient:
    """Thin wrapper around openai.OpenAI configured for DeepSeek."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str = DEFAULT_MODEL,
        timeout: float = 120.0,
    ) -> None:
        # Resolve via the precedence chain in dsc.config when caller passes
        # nothing — this is what `dsc` itself does. Tests can still pass
        # explicit values to keep them hermetic.
        if api_key is None or base_url is None:
            from dsc.config import get_api_key, get_base_url

            if api_key is None:
                api_key = get_api_key()
            if base_url is None:
                base_url = get_base_url()
        key = api_key
        if not key:
            raise RuntimeError(
                "No credentials. Run `fred login` to authenticate, "
                "or set FRED_API_KEY (or legacy DEEPSEEK_API_KEY) for CI."
            )
        self.model = model
        self.base_url = base_url
        self._client = OpenAI(
            api_key=key,
            base_url=base_url,
            max_retries=0,  # we handle retries ourselves; default would replay whole streams
            timeout=timeout,
        )
        # Hooks the agent layer can install (renderer + tracer) without
        # importing the renderer/tracer types here. Both are optional.
        self.on_retry: Callable[[int, BaseException, int], None] | None = None
        self.on_abort: Callable[[BaseException, str, int], None] | None = None
        # Correlation IDs threaded as request headers so usage_events rows
        # written by the proxy can be joined back to CLI sessions/turns.
        # The proxy's columns are nullable; the CLI sends what it has.
        self.correlation_session_id: str | None = None
        self.correlation_turn_id: str | None = None

    def _stream_chat_inner(
        self,
        messages: list[dict] | CacheableRequest,
        tools: list[dict] | None,
        model: str | None,
        temperature: float | None,
    ) -> StreamSession:
        """Single-attempt streaming call. Raises transient errors up to caller.

        Accepts either a pre-built OpenAI-shape messages list (legacy path)
        or a CacheableRequest. The DeepSeek wire shape is identical either
        way; the abstraction exists so caller code can stay backend-agnostic
        for future Anthropic support.
        """
        if isinstance(messages, CacheableRequest):
            wire_messages = messages.for_deepseek()
        else:
            wire_messages = messages
        kwargs: dict[str, Any] = {
            "model": model or self.model,
            "messages": wire_messages,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if tools:
            kwargs["tools"] = tools
        if temperature is not None:
            kwargs["temperature"] = temperature
        # Per-call correlation headers — keyed off mutable client state
        # so the agent loop can update turn_id between iterations
        # without rebuilding the underlying HTTP client.
        extra_headers: dict[str, str] = {}
        if self.correlation_session_id:
            extra_headers["x-fred-session-id"] = self.correlation_session_id
        if self.correlation_turn_id:
            extra_headers["x-fred-turn-id"] = self.correlation_turn_id
        if extra_headers:
            kwargs["extra_headers"] = extra_headers
        try:
            stream = self._client.chat.completions.create(**kwargs)
        except openai.APIStatusError as e:
            # The proxy returns 402 with a {"error":{"type":"insufficient_credits","topup_url":...}}
            # body when the user's balance hits zero. Surface it as a typed error.
            if e.status_code == 402:
                from dsc.auth import InsufficientCreditsError

                topup_url: str | None = None
                try:
                    body = e.response.json() if e.response is not None else {}
                    topup_url = (body.get("error") or {}).get("topup_url")
                except Exception:
                    pass
                raise InsufficientCreditsError(topup_url) from e
            raise
        return StreamSession(stream)

    def with_model(self, name: str) -> "DSClient":
        """Return a SHALLOW copy of this client targeting a different model.

        Multi-model routing (P2.3) wants per-call model overrides without
        rebuilding the underlying HTTP client (the openai `OpenAI` instance
        owns a connection pool, header set, retry policy — all reusable
        across model names). Construct a new `DSClient` shell and rebind:
          - `model` → the new name
          - `_client` → SAME instance (HTTP session reuse)
          - `base_url` → unchanged (same provider)
          - `on_retry` / `on_abort` → SAME callbacks (caller-installed
            renderer/tracer hooks fire identically for the cloned client)

        The original client is not mutated; the existing `client.model = ...`
        direct-assignment path used by `/model` (PR3) is unaffected.

        Use case: editor-model and weak-model callsites (P2.3) call
        `client.with_model(cfg.editor_model).stream_chat(...)` once per
        slot-routed request without disturbing the parent's `model`.
        """
        twin = copy.copy(self)
        twin.model = name
        # `copy.copy` already preserves `_client`, `base_url`, `on_retry`,
        # `on_abort` references (shallow copy). Make the contract explicit.
        return twin

    def stream_chat(
        self,
        messages: list[dict] | CacheableRequest,
        tools: list[dict] | None = None,
        model: str | None = None,
        temperature: float | None = None,
    ) -> RetryingStreamSession:
        """Streaming chat completion with outer retry layer.

        Retries fire only when no tool-call delta has been emitted yet. If
        the model has begun dispatching a tool, transient exceptions
        propagate without retry — replaying would re-execute the tool.

        Accepts either a flat OpenAI-shape messages list (legacy) or a
        `CacheableRequest` for backend-aware caching segmentation.
        """
        max_retries = _env_int("DSC_API_RETRIES", _DEFAULT_RETRIES)
        backoff_base_ms = _env_int("DSC_API_BACKOFF_BASE_MS", _DEFAULT_BACKOFF_BASE_MS)

        def opener() -> StreamSession:
            return self._stream_chat_inner(messages, tools, model, temperature)

        return RetryingStreamSession(
            opener,
            max_retries=max_retries,
            backoff_base_ms=backoff_base_ms,
            on_retry=self.on_retry,
            on_abort=self.on_abort,
        )


def _env_int(name: str, default: int) -> int:
    """Parse an int env var, falling back to default on missing/invalid."""
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def messages_to_cacheable_request(messages: list[dict]) -> CacheableRequest:
    """Split a flat OpenAI-shape message list into a CacheableRequest.

    Treats the first contiguous run of system messages as the byte-stable
    cacheable prefix; the rest (user/assistant/tool) becomes the volatile
    tail. This is the integration point the agent loop uses to thread
    existing message-list construction into a backend-aware shape without
    forcing every caller to refactor.
    """
    segments: list[Segment] = []
    tail_start = 0
    for i, m in enumerate(messages):
        if m.get("role") == "system":
            content = m.get("content") or ""
            if isinstance(content, list):
                # Already a multi-block system message — flatten text blocks.
                content = "".join(
                    b.get("text", "") for b in content if isinstance(b, dict)
                )
            segments.append(Segment(content=content, cacheable=True))
            tail_start = i + 1
        else:
            break
    return CacheableRequest(
        system_segments=segments,
        tail_messages=list(messages[tail_start:]),
    )
