"""Wildcard matchers for hook (P2.4) and permission-rule (P3.1) configs.

Two related but separate matcher languages are exposed here so the hook
system, the permission-rule engine, and the future ``/perms`` slash command
all reach for the same shared code:

1. ``match_tool_pattern(pattern, tool_name, args) -> bool`` — top-level
   matcher used by hooks. Pattern syntax:

     - ``""`` or ``"*"`` matches any tool. Empty / missing matcher means
       "fire on every call of this event."
     - ``"<ToolName>"`` matches a tool whose name compares equal
       case-insensitively to ``<ToolName>``. Both sides are normalised to
       lower case so the user can write ``Bash`` and we still match the
       lower-case ``bash`` tool name we register internally.
     - ``"<ToolName>(<glob>)"`` matches when the tool name matches AND the
       canonical "specifier" string (see ``_specifier_for``) matches
       ``<glob>`` under shell-glob semantics (``*`` = any sequence,
       ``?`` = any single char). Specifier extraction is per-tool; e.g.
       for ``bash`` we use the ``command`` arg, for ``view`` /
       ``str_replace`` / ``create_file`` we use the ``path`` arg.
     - Comma-separated lists are supported: ``"Bash(rm -rf *), Edit(*.py)"``
       fires when ANY of the listed sub-patterns match.

2. ``match_glob(glob, value) -> bool`` — the underlying ``fnmatch``-style
   helper used by ``match_tool_pattern`` to compare the specifier string.

The grammar deliberately mirrors what Claude Code documents for its hook
and permission systems so users moving between tools can reuse muscle
memory, but the matcher is intentionally narrow — no shell-quoting
parser, no semicolons, no piping awareness. Hook authors who need finer
discrimination should match coarsely here and do their own filtering
inside the hook command.
"""
from __future__ import annotations

import fnmatch
import re

# Strip the leading "<ToolName>" off "ToolName(<glob>)" — capture name + body.
# Allows internal whitespace inside the body (e.g. ``Bash(git status:*)``).
# MCP-style tool names like ``mcp__server__tool`` are not capturable as a
# leading bare identifier, so they hit the no-match fallback in
# ``_match_single`` and become a plain tool-name glob — that's fine since
# MCP tools rarely take a useful specifier.
_TOOL_RE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(?:\((.*)\))?\s*$")

# Permission-rule and hook authors think in Claude-Code-style camelcase
# names (``Bash``, ``Read``, ``Edit``, ``Write``). Map them to dsc's
# internal snake_case names so a user porting their settings file doesn't
# have to learn a second vocabulary. Lowercased on both sides — matchers
# run name comparisons via ``str.lower()`` already.
_NAME_ALIASES: dict[str, str] = {
    "read": "view",
    "edit": "str_replace",
    "write": "create_file",
    # ``Bash`` already maps to itself; included for symmetry / clarity.
    "bash": "bash",
}


def _canonical_tool_name(name: str) -> str:
    """Resolve an alias into the registered tool name, lowercased."""
    lowered = (name or "").lower()
    return _NAME_ALIASES.get(lowered, lowered)


def _specifier_for(tool_name: str, args: dict) -> str:
    """Return the canonical specifier string used by the matcher for `tool_name`.

    For shell-y tools (``bash``) the specifier is the command. For file
    tools (``view``, ``str_replace``, ``create_file``) it's the path. For
    everything else it's a JSON-ish ``key=value`` blob built from the args
    dict so users can still write rough patterns; in practice the matcher
    is rarely used outside the well-known tools.

    Empty / missing args degrade to ``""`` — the empty string only matches
    a glob of ``""`` or ``"*"``.
    """
    if not isinstance(args, dict):
        return ""
    # Resolve aliases up front so callers can pass either the camelcase
    # display name (``Edit``) or the registered name (``str_replace``)
    # and get the same specifier.
    name = _canonical_tool_name(tool_name)
    if name == "bash":
        return str(args.get("command") or "")
    if name in ("view", "create_file", "str_replace", "glob", "grep"):
        return str(args.get("path") or args.get("pattern") or "")
    # Generic fallback: serialise each top-level arg as `k=v`, sorted, so
    # patterns over rare tools can still target a specific arg substring.
    parts = [f"{k}={args[k]}" for k in sorted(args)]
    return " ".join(parts)


def match_glob(pattern: str, value: str) -> bool:
    """Shell-glob match. Empty pattern matches any value; ``"*"`` matches any."""
    if pattern == "" or pattern == "*":
        return True
    return fnmatch.fnmatchcase(value, pattern)


def match_tool_pattern(pattern: str | None, tool_name: str, args: dict) -> bool:
    """Return True if `pattern` matches a call of `tool_name` with `args`.

    See module docstring for the grammar. ``None``, ``""``, and ``"*"``
    all match every call (used by hook configs that want a catch-all).
    """
    if pattern is None or pattern.strip() == "" or pattern.strip() == "*":
        return True

    # Comma-separated list — any match wins.
    for sub in (s.strip() for s in pattern.split(",") if s.strip()):
        if _match_single(sub, tool_name, args):
            return True
    return False


def _match_single(pattern: str, tool_name: str, args: dict) -> bool:
    m = _TOOL_RE.match(pattern)
    if m is None:
        # Pattern that doesn't fit the grammar is treated as a tool-name
        # glob over the bare name — e.g. ``"bash*"`` would match ``bash``
        # and a hypothetical ``bash_bg``. This keeps "is the matcher
        # syntax incorrect?" a recoverable user error instead of a hard
        # config-load failure. Comparison goes through the alias map so
        # ``Edit`` and ``str_replace`` are interchangeable.
        return fnmatch.fnmatchcase(
            _canonical_tool_name(tool_name), _canonical_tool_name(pattern),
        )
    name_part, body_part = m.group(1), m.group(2)
    name_glob = _canonical_tool_name(name_part)
    if not fnmatch.fnmatchcase(_canonical_tool_name(tool_name), name_glob):
        return False
    if body_part is None:
        return True
    spec = _specifier_for(tool_name, args)
    return match_glob(body_part, spec)
