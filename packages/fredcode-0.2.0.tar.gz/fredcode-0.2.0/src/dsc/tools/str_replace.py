"""str_replace tool: replace a UNIQUE string in a file.

Two model-facing contracts live here (and matter for both AGENTS.md and
the agent's behavior in the wild):

1. **Uniqueness invariant.** ``old_str`` must occur exactly once in the
   target file. The "found N matches" wording is part of the contract:
   the model relies on it to expand surrounding context on retry. Never
   silently replace the first or all matches.

2. **Prior-Read enforcement (P1.4).** A file must have been ``view``'d
   (or freshly ``create_file``'d) this session before it can be edited.
   The exact error wording — ``Error: must view {path} before editing
   it. Run view {path} first.`` — is the documented nudge the model is
   trained against; preserve it.

When ``old_str`` isn't found, we additionally try to surface the
*closest candidate* substring with its enclosing function/class scope
rendered via tree-sitter + grep_ast (P1.4 AST-context error feedback).
This is best-effort: small files, unsupported languages, or any
parser/render failure falls through to the original ``not_found``
wording so the model still gets a usable error.
"""
from __future__ import annotations

from difflib import SequenceMatcher
from pathlib import Path

from pydantic import BaseModel, Field

from dsc.tools._session_files import (
    is_tracked,
    mark_tracked,
    set_tool_outcome,
    tracking_active,
)
from dsc.tools.base import Tool

# Files shorter than this skip the AST-context render — there's no
# enclosing scope worth surfacing in a 20-line file, and the literal
# `Error: old_str not found in {path}.` wording is more useful when the
# whole file fits on a screen.
_AST_MIN_LINES = 50

# Below this similarity ratio we don't surface a candidate. SequenceMatcher's
# `ratio()` is in [0.0, 1.0]; 0.5 is the floor for "obviously the same
# region with edits" — anything lower is too noisy to be worth showing.
_AST_SIMILARITY_FLOOR = 0.5

# Sliding-window size for the candidate search. Three lines is the
# Aider precedent: enough to anchor on a function header + first
# statement without exploding the search space on big files.
_AST_WINDOW_LINES = 3


class StrReplaceArgs(BaseModel):
    path: str = Field(..., description="File to edit. Must already exist.")
    old_str: str = Field(..., description="Exact string to replace. Must occur exactly once in the file.")
    new_str: str = Field(..., description="String to substitute in. Can be empty to delete.")


def run(args: StrReplaceArgs) -> str:
    p = Path(args.path).expanduser()
    if not p.exists():
        return f"Error: file does not exist: {p}"
    if not p.is_file():
        return f"Error: not a file: {p}"

    # P1.4: prior-Read enforcement. The session-scoped tracker is set by
    # cli.py before each turn; if no tracker is installed (one-shot
    # script harnesses, embedded tests) the check is skipped — the
    # production REPL always installs one. Files marked via `view` or
    # `create_file` count; the wording below is the model-facing
    # contract and must not change.
    if tracking_active() and not is_tracked(p):
        set_tool_outcome("prior_read_required")
        return f"Error: must view {p} before editing it. Run view {p} first."

    try:
        text = p.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as e:
        return f"Error: cannot read {p}: {e}"

    count = text.count(args.old_str)
    if count == 0:
        # Lazy AST candidate render: pay the tree-sitter cost only on a
        # miss. Any failure here falls through to the historical wording
        # so the model still gets a useful nudge.
        candidate = _find_candidate_scope(p, text, args.old_str)
        if candidate is None:
            set_tool_outcome("not_found")
            return (
                f"Error: old_str not found in {p}. Did you escape whitespace and "
                "newlines correctly? Use `view` to inspect the exact contents first."
            )
        set_tool_outcome("not_found_with_candidate")
        scope_name, similarity, snippet = candidate
        return (
            f"Error: old_str not found in {p}. Closest candidate "
            f"(similarity {similarity:.2f}) is in {scope_name}:\n\n"
            f"{snippet}"
        )
    if count > 1:
        set_tool_outcome("not_unique")
        return (
            f"Error: found {count} matches for old_str in {p}; old_str must be "
            "unique. Include more surrounding context (e.g. preceding/following "
            "lines) so it identifies exactly one location."
        )

    new_text = text.replace(args.old_str, args.new_str, 1)
    try:
        p.write_text(new_text, encoding="utf-8")
    except OSError as e:
        return f"Error: cannot write {p}: {e}"
    # Successful edit: keep the file tracked so a follow-up edit on the
    # same file in the same turn doesn't trip the prior-Read guard. (It
    # was already tracked to get here, but mark_tracked is idempotent
    # and explicit is better than implicit.)
    mark_tracked(p)
    return f"Edited {p}: replaced 1 occurrence."


def _find_candidate_scope(
    path: Path, file_text: str, old_str: str,
) -> tuple[str, float, str] | None:
    """Return (scope_name, similarity, snippet) for the closest match, or None.

    Uses tree-sitter to find the enclosing function/class for the most
    similar 3-line window. Falls back to None whenever:
    - the file is shorter than ``_AST_MIN_LINES``,
    - the language isn't supported by our tree-sitter setup (P1.1),
    - the parser fails to load or parse,
    - no candidate clears ``_AST_SIMILARITY_FLOOR``.

    All exceptions are swallowed; the AST snippet is a hint, not a
    contract, and the caller has a fallback error wording.
    """
    lines = file_text.splitlines()
    if len(lines) < _AST_MIN_LINES:
        return None

    try:
        # Lazy-import P1.1's tree-sitter plumbing so the per-call cost
        # (driver load, language pack import) is paid only on a miss.
        from dsc.repomap.parser import (
            filename_to_language,
            get_language_and_parser,
        )
    except ImportError:
        return None

    lang = filename_to_language(str(path))
    if lang is None:
        return None

    # Find the highest-similarity sliding window. We compare against the
    # `old_str` as a single string, not line-by-line, to handle multi-
    # line `old_str` values cleanly.
    best_idx, best_ratio = _best_window(lines, old_str)
    if best_idx is None or best_ratio < _AST_SIMILARITY_FLOOR:
        return None

    language, parser = get_language_and_parser(lang)
    if language is None or parser is None:
        return None

    try:
        tree = parser.parse(file_text.encode("utf-8"))
    except Exception:
        return None

    scope_name, snippet = _render_enclosing_scope(
        path, file_text, tree.root_node, best_idx,
    )
    if not snippet:
        return None
    return scope_name, best_ratio, snippet


def _best_window(
    lines: list[str], target: str,
) -> tuple[int | None, float]:
    """Return (start_line_index, ratio) for the most-similar 3-line window.

    `start_line_index` is 0-based; ratio is in [0.0, 1.0]. Returns
    (None, 0.0) if the file is empty or every window scores zero.
    Uses :class:`difflib.SequenceMatcher`'s ``ratio()`` — quadratic in
    string length but only over short windows, so the cost is bounded.
    """
    if not lines:
        return None, 0.0
    target_norm = target.strip()
    if not target_norm:
        return None, 0.0
    best_idx: int | None = None
    best_ratio = 0.0
    n = len(lines)
    window = max(1, min(_AST_WINDOW_LINES, n))
    # Walk every starting position; SequenceMatcher recomputes from
    # scratch each iteration but the windows are short enough that the
    # absolute cost is small even on multi-thousand-line files.
    for i in range(n - window + 1):
        chunk = "\n".join(lines[i : i + window])
        if not chunk.strip():
            continue
        ratio = SequenceMatcher(None, chunk, target_norm).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_idx = i
    return best_idx, best_ratio


def _render_enclosing_scope(
    path: Path, file_text: str, root_node, candidate_line_idx: int,
) -> tuple[str, str]:
    """Walk the AST to find the smallest enclosing function/class scope.

    Returns (scope_name, snippet). `scope_name` is something like
    `function 'parse_args'` or `class 'ParserState'` for display; the
    snippet is the rendered TreeContext block for the scope, with
    `…⋮…` ellipses for omitted code. Empty strings on any failure.
    """
    target_node = _find_smallest_scope(root_node, candidate_line_idx)
    if target_node is None:
        scope_name = f"line {candidate_line_idx + 1}"
        # No enclosing function/class — surface a small linear excerpt.
        snippet = _linear_excerpt(file_text, candidate_line_idx)
        return scope_name, snippet

    scope_name = _scope_label(target_node)
    snippet = _tree_context_snippet(
        path, file_text, target_node, candidate_line_idx,
    )
    if not snippet:
        snippet = _linear_excerpt(file_text, candidate_line_idx)
    return scope_name, snippet


# Tree-sitter node types we recognize as "scopes" worth showing.
# Aligned with what `repomap/queries/python-tags.scm` matches as
# definitions; broader than necessary on purpose so JS / TS / Go / Rust
# class- and function-equivalents also surface.
_SCOPE_NODE_TYPES = frozenset({
    "function_definition",
    "function_declaration",
    "method_definition",
    "method_declaration",
    "class_definition",
    "class_declaration",
    "function",
    "method",
    "class",
    "decorated_definition",
})


def _find_smallest_scope(root_node, line_idx: int):
    """Walk down to the smallest scope node containing `line_idx`.

    None if no scope contains the line — usually means the candidate is
    at module top level.
    """
    target = None
    stack = [root_node]
    while stack:
        node = stack.pop()
        try:
            start = node.start_point[0]
            end = node.end_point[0]
        except (AttributeError, IndexError):
            continue
        if not (start <= line_idx <= end):
            continue
        if node.type in _SCOPE_NODE_TYPES:
            target = node  # keep walking — we want the SMALLEST enclosing
        try:
            children = node.children or []
        except AttributeError:
            children = []
        stack.extend(children)
    return target


def _scope_label(node) -> str:
    """Build a human-readable label like ``function 'foo'``.

    Best-effort: walks named children looking for an `identifier`-typed
    node. Falls back to the node type alone if no name is found.
    """
    if "function" in node.type or "method" in node.type:
        kind = "function"
    elif "class" in node.type:
        kind = "class"
    else:
        kind = node.type
    name = _node_name(node)
    if name:
        return f"{kind} {name!r}"
    return kind


def _node_name(node) -> str | None:
    """Find the first identifier-shaped child name, or None.

    Tree-sitter nodes for function/class definitions follow a consistent
    enough shape across our supported grammars: the immediate child of
    type ``identifier`` (or ``name``, ``property_identifier``, etc.) is
    the declared name. Walk one level deep — sufficient for our needs.
    """
    try:
        children = list(node.children or [])
    except AttributeError:
        return None
    name_types = {"identifier", "name", "property_identifier", "type_identifier"}
    for child in children:
        if getattr(child, "type", None) in name_types:
            try:
                return child.text.decode("utf-8")
            except (UnicodeDecodeError, AttributeError):
                continue
        # `decorated_definition` wraps a function/class one level deep.
        try:
            grandchildren = child.children or []
        except AttributeError:
            grandchildren = []
        for gc in grandchildren:
            if getattr(gc, "type", None) in name_types:
                try:
                    return gc.text.decode("utf-8")
                except (UnicodeDecodeError, AttributeError):
                    continue
    return None


def _tree_context_snippet(
    path: Path, file_text: str, scope_node, candidate_line_idx: int,
) -> str:
    """Render the scope as a TreeContext block with ``…⋮…`` ellipses.

    Reuses grep_ast's TreeContext (already a P1.1 dep). On any failure
    returns "" — the caller falls back to a linear excerpt.
    """
    try:
        from grep_ast import TreeContext
    except ImportError:
        return ""

    code = file_text if file_text.endswith("\n") else file_text + "\n"
    rel_fname = path.name

    try:
        ctx = TreeContext(
            rel_fname,
            code,
            color=False,
            line_number=True,
            child_context=False,
            last_line=False,
            margin=0,
            mark_lois=False,
            loi_pad=2,
            show_top_of_file_parent_scope=False,
        )
    except Exception:
        return ""

    try:
        scope_start = scope_node.start_point[0]
    except (AttributeError, IndexError):
        return ""

    # Lines of interest: the candidate match line (so the user sees the
    # near-miss context) plus the scope header (so the reader knows
    # which function/class they're in).
    lois = sorted({scope_start, candidate_line_idx})
    try:
        ctx.lines_of_interest = set()
        ctx.add_lines_of_interest(lois)
        ctx.add_context()
        rendered = ctx.format()
    except Exception:
        return ""

    # Hard-cap at 4000 chars defending against runaway parses on
    # generated/minified files that escape grep_ast's elision.
    if len(rendered) > 4000:
        rendered = rendered[:4000] + "\n[truncated]"
    return rendered.rstrip() + "\n"


def _linear_excerpt(file_text: str, line_idx: int, context_lines: int = 4) -> str:
    """Fallback excerpt when no AST scope is available.

    Returns a short slice with ``…⋮…`` markers above and below so the
    model still sees the candidate region's neighborhood without being
    misled into thinking we couldn't find anything.
    """
    lines = file_text.splitlines()
    if not lines:
        return ""
    start = max(0, line_idx - context_lines)
    end = min(len(lines), line_idx + context_lines + 1)
    parts: list[str] = []
    if start > 0:
        parts.append(f"…⋮… {start} earlier lines …⋮…")
    for i in range(start, end):
        # 1-indexed line numbers to match how `view` displays them.
        parts.append(f"{i + 1:>5}\t{lines[i]}")
    if end < len(lines):
        parts.append(f"…⋮… {len(lines) - end} later lines …⋮…")
    return "\n".join(parts) + "\n"


tool = Tool(
    name="str_replace",
    description=(
        "Surgically replace a UNIQUE string in a file. old_str must occur exactly "
        "once in the file; if it occurs zero or multiple times the call fails with "
        "an error explaining how many matches were found, and you should retry "
        "with more surrounding context. Use `view` first to inspect exact contents — "
        "you MUST `view` (or `create_file`) a file in this session before editing it. "
        "Prefer this over rewriting whole files."
    ),
    args_model=StrReplaceArgs,
    handler=run,
    requires_permission=True,
)
