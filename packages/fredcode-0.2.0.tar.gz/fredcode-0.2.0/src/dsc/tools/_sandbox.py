"""macOS Seatbelt sandbox wrapper (P4.1, Codex CLI pattern).

Two-axis security model, ported from Codex's ``codex-rs/sandboxing``:

* ``sandbox_mode`` ∈ ``{ro, workspace-write, full}`` — the kernel-enforced
  ground truth. Wraps every shell command in ``sandbox-exec -p <profile>``
  on macOS, denying writes / reads / network according to the profile.
* ``approval_mode`` ∈ ``{untrusted, on_request, never}`` — a separate axis
  governing the y/n/a/d Panel gate. Lives in ``permissions.py`` (the Panel
  is just a UI concern; sandbox is the real defense).

The two axes are deliberately ORTHOGONAL: a user can run with
``sandbox=full, approval=never`` (YOLO-equivalent) or
``sandbox=ro, approval=untrusted`` (read-only with maximum prompting). The
sandbox enforces the contract regardless of approval mode — even a
mis-configured approval=never can't write to ``/etc`` if the sandbox is
``ro``.

Implementation notes
--------------------

* **macOS-only in v1.** On Linux / other platforms ``wrap_command`` returns
  ``(cmd, None)`` — the legacy un-sandboxed bash flow runs unchanged. A
  Linux ``bwrap``-based implementation (with ``--unshare-net``,
  ``--unshare-pid``, ``--bind`` etc.) is deferred to P4.1.b.
* **Hardcoded ``/usr/bin/sandbox-exec``** to defeat PATH-injection attacks.
  Codex does the same. The system binary is always there on a real macOS
  install; if it's missing we fall back to no-wrap rather than failing
  closed (a developer machine without the system tool shouldn't be
  un-runnable).
* **Inline ``.sbpl`` profile templates.** Three profiles, ported from
  Codex's ``seatbelt_base_policy.sbpl`` / ``restricted_read_only_platform_defaults.sbpl``
  (with adjustments for our scope):

  - ``ro`` — deny-all, allow process operations + reads anywhere.
  - ``workspace-write`` — allow writes within the project root, ``/tmp``,
    ``$TMPDIR`` (per-user ``/var/folders/.../T/`` on macOS); deny writes
    elsewhere, including ``/etc``, ``/usr``, ``$HOME`` outside the project.
  - ``full`` — permissive (allow file ops everywhere) but still no network
    unless explicitly enabled. Approximates "what bash did before this PR"
    while keeping the network deny so a leaked secret can't phone home.

  Profile strings parameterize the project root path so multiple
  workspaces can coexist.

* The wrapper command shape is:
  ``["/usr/bin/sandbox-exec", "-p", profile_str, "/bin/sh", "-c", cmd]``

  Same shape as ``subprocess.Popen(args.command, shell=True)`` — we just
  prepend the sandbox shell. Combined ``stderr=STDOUT``, ``bufsize=1``,
  and ``start_new_session=True`` flags from bash.py / bash_bg.py work
  unchanged.

* When the kernel denies an operation, ``sandbox-exec`` writes a message
  prefixed ``sandbox-exec: `` to stderr (which we merge into stdout). The
  bash drain captures it like any other line so the model sees a clear
  marker in its tool-result that distinguishes a sandbox denial from an
  app error. The error wording prefix is part of the model-facing
  contract — preserve it.
"""
from __future__ import annotations

import contextvars
import os
import platform
from pathlib import Path
from typing import Literal

# ``sandbox_mode`` is a typed string so callers can pass it raw (env vars,
# CLI flags) and have static checkers / pydantic catch typos. The values
# are stable IDs surfaced in telemetry.
SandboxMode = Literal["ro", "workspace-write", "full"]
VALID_SANDBOX_MODES: tuple[SandboxMode, ...] = ("ro", "workspace-write", "full")

# Default mode if nothing is configured. Mirrors Codex's defaults: write-
# everywhere-the-project-root-is is the friendliest reasonable bound for
# an agentic coding tool. ``full`` is opt-in only.
DEFAULT_SANDBOX_MODE: SandboxMode = "workspace-write"

# Hardcoded path to the system sandbox-exec binary. Codex does the same to
# defeat PATH-injection: a malicious shell function or PATH-shadowing
# binary cannot intercept the wrap. If the binary doesn't exist (Linux,
# non-Apple Darwin, stripped systems), wrap_command returns the original
# argv and bash runs unsandboxed.
_SANDBOX_EXEC_PATH = "/usr/bin/sandbox-exec"


# ---------------------------------------------------------------------------
# Profile templates (Seatbelt SBPL, ported from Codex)
#
# SBPL is a Lisp-like DSL evaluated by macOS's ``sandbox`` framework.
# ``(version 1)`` is required at the top. ``(deny default)`` denies all
# operations; we then ``(allow ...)`` specific subjects.
#
# We use ``(literal ...)`` for exact-path matches and ``(subpath ...)``
# for prefix matches. The project-root path is interpolated as a literal
# subpath; the profile string is rebuilt per-call so different worktrees
# get different profiles (a tradeoff vs. a single cached profile, but
# correctness > caching here).
#
# WARNING: Seatbelt's SBPL is undocumented by Apple but stable. Don't
# embed user-supplied strings in profile templates — only paths we
# control. The project_root sanitization below enforces that.

_RO_PROFILE = """(version 1)
(deny default)

;; Process self-introspection
(allow process-fork)
(allow process-exec)
(allow signal (target self))

;; Allow reads from anywhere (sandbox is for writes)
(allow file-read*)

;; Standard sysctl + ipc the dynamic linker / system libs need
(allow sysctl-read)
(allow mach-lookup)
(allow ipc-posix-shm-read*)
(allow iokit-open)

;; Network: deny everything (a read-only command shouldn't egress)
(deny network*)
"""


def _workspace_write_profile(project_root: str, tmpdir: str) -> str:
    """Return a workspace-write SBPL profile parameterized for the project.

    Allows writes within ``project_root``, ``/tmp``, and ``$TMPDIR`` (the
    macOS per-user temp under ``/var/folders/.../T/``). Denies writes
    everywhere else, including ``/etc``, ``/usr``, ``/System``, and the
    user's home outside the project. Reads are allowed everywhere
    (matching ``ro``); the asymmetry is intentional — agentic coding
    typically needs to read system docs / installed libs but never
    needs to write outside the workspace.

    ``project_root`` and ``tmpdir`` MUST be already-resolved absolute
    paths; the caller (``wrap_command``) does the sanitization.
    """
    # ``literal`` form requires a string with NO unescaped quotes. We
    # use a raw-ish escape: any embedded ``"`` becomes ``\"``. macOS
    # filesystem paths can't legally contain a NUL byte; a path with
    # an embedded double-quote is rare but possible (a malicious user
    # could try to inject SBPL clauses via cwd). The escape is the
    # one defense.
    safe_root = project_root.replace('"', r'\"')
    safe_tmp = tmpdir.replace('"', r'\"') if tmpdir else ""

    # Build the (subpath ...) clauses. ``/tmp`` is always included
    # because /tmp on macOS is a stable system path that is sometimes
    # different from ``$TMPDIR``. Both must be writable for shell
    # scripts that hardcode `/tmp/foo`.
    write_clauses = [
        f'(subpath "{safe_root}")',
        '(subpath "/tmp")',
        '(subpath "/private/tmp")',  # /tmp is a symlink on macOS
        '(subpath "/var/folders")',  # Per-user tmp lives here
    ]
    if safe_tmp:
        # Add the resolved tmpdir explicitly so a non-/var/folders tmpdir
        # (e.g. user-overridden TMPDIR) also gets allowed.
        write_clauses.append(f'(subpath "{safe_tmp}")')
    write_block = "\n  ".join(write_clauses)

    return f"""(version 1)
(deny default)

;; Process self-introspection
(allow process-fork)
(allow process-exec)
(allow signal (target self))

;; Reads anywhere
(allow file-read*)

;; Writes only under the workspace + tmp dirs
(allow file-write*
  {write_block})
;; The standard /dev pseudo-files most shells need
(allow file-write*
  (literal "/dev/null")
  (literal "/dev/dtracehelper")
  (literal "/dev/stderr")
  (literal "/dev/stdout")
  (literal "/dev/stdin")
  (literal "/dev/tty")
  (regex #"^/dev/fd/[0-9]+$")
  (regex #"^/dev/ttys[0-9]+$"))

;; Sysctl + ipc + iokit for the dynamic linker / system libs
(allow sysctl-read)
(allow mach-lookup)
(allow ipc-posix-shm*)
(allow iokit-open)

;; Network: deny by default (matches Codex's workspace-write).
(deny network*)
"""


def _full_profile() -> str:
    """Return a permissive SBPL profile that still denies network egress.

    "full" = file system writes anywhere (matches the legacy no-sandbox
    behavior), but network is still denied unless explicitly opted in.
    The intent: an explicit YOLO-ish opt-in for sandbox concerns while
    keeping the data-egress door shut by default. A user who genuinely
    needs network from a sandboxed shell (curl, git push) currently
    has to disable the sandbox entirely — a follow-up will add
    ``--allow-network`` for the corner case.
    """
    return """(version 1)
(allow default)
(deny network*)
"""


# ---------------------------------------------------------------------------
# Public API


def normalize_mode(raw: str | None) -> SandboxMode | None:
    """Return a known ``SandboxMode`` or ``None`` if `raw` is invalid/missing.

    Tolerates underscore vs hyphen (``workspace_write`` ⇄ ``workspace-write``)
    and case so CLI flags / env vars / settings.json all converge.
    """
    if raw is None:
        return None
    s = raw.strip().lower().replace("_", "-")
    if s in VALID_SANDBOX_MODES:
        return s  # type: ignore[return-value]
    return None


def _resolve_project_root(project_root: Path) -> Path:
    """Best-effort absolute resolution. Bare ``Path.cwd()`` fallback on error."""
    try:
        return project_root.resolve()
    except (OSError, RuntimeError):
        try:
            return Path.cwd().resolve()
        except (OSError, RuntimeError):
            return Path("/")


def build_profile(mode: SandboxMode, project_root: Path) -> str:
    """Build the SBPL profile string for ``mode`` parameterized for the project.

    Pure function — no I/O. Useful in tests to assert profile contents
    independently of ``wrap_command``'s argv building.
    """
    root = _resolve_project_root(project_root)
    if mode == "ro":
        return _RO_PROFILE
    if mode == "full":
        return _full_profile()
    # workspace-write
    tmpdir = os.environ.get("TMPDIR", "") or ""
    if tmpdir:
        try:
            tmpdir = str(Path(tmpdir).resolve())
        except (OSError, RuntimeError):
            tmpdir = ""
    return _workspace_write_profile(str(root), tmpdir)


def is_supported() -> bool:
    """Return True if sandboxing can run on this platform.

    macOS only in v1. Linux falls through to the un-sandboxed flow; a
    follow-up (P4.1.b) will add ``bwrap`` support. We additionally
    require the system ``sandbox-exec`` binary to actually exist —
    a stripped-down macOS or a non-Apple Darwin variant could ship
    without it.
    """
    if platform.system() != "Darwin":
        # TODO(P4.1.b): bwrap-based wrapping on Linux.
        return False
    return os.path.exists(_SANDBOX_EXEC_PATH)


# ---------------------------------------------------------------------------
# Session-scoped configuration: ContextVar for the active sandbox mode plus
# a project-local settings.json override. Both bash.py and bash_bg.py read
# the active mode via ``current_sandbox_mode()``.

_SANDBOX_MODE: contextvars.ContextVar[SandboxMode | None] = contextvars.ContextVar(
    "dsc_sandbox_mode", default=None,
)


def set_sandbox_mode(mode: SandboxMode | None) -> contextvars.Token:
    """Install the session-scoped sandbox mode. Returns a reset token.

    Pair with ``reset_sandbox_mode(token)`` in a try/finally so the
    ContextVar is always restored. Pass ``None`` to defer to the
    env-var / settings.json / default fallback.
    """
    return _SANDBOX_MODE.set(mode)


def reset_sandbox_mode(token: contextvars.Token) -> None:
    _SANDBOX_MODE.reset(token)


def _read_settings_sandbox_mode(start: Path | None = None) -> SandboxMode | None:
    """Walk cwd → home for ``.dsc/settings.json`` and return the configured mode.

    Mirrors the layered settings approach used by hooks + permission rules
    (see ``permissions.load_permission_rules``). Project-level settings
    are honored; the local override (``settings.local.json``) is NOT
    consulted for sandbox mode — the reasoning is that sandbox is a
    defensive contract that should be visible / shared with collaborators
    rather than buried in a gitignored file. This matches Codex's choice
    of a project-level ``codex.toml`` for sandbox config.
    """
    import json

    start = (start or Path.cwd()).resolve()
    home = Path.home().resolve()
    current = start
    while True:
        candidate = current / ".dsc" / "settings.json"
        if candidate.exists():
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                data = None
            if isinstance(data, dict):
                sb = data.get("sandbox")
                if isinstance(sb, dict):
                    raw_mode = sb.get("mode")
                    if isinstance(raw_mode, str):
                        normalized = normalize_mode(raw_mode)
                        if normalized is not None:
                            return normalized
        if (current / ".git").exists():
            break
        if current == current.parent:
            break
        if current == home:
            break
        current = current.parent
    return None


def current_sandbox_mode(start: Path | None = None) -> SandboxMode:
    """Return the active sandbox mode, resolving in priority order.

    Resolution (highest to lowest):

    1. Session-scoped ``ContextVar`` — set by the CLI when ``--sandbox``
       is passed, or by tests directly.
    2. ``FRED_SANDBOX_MODE`` env var (CI / scripted use).
    3. Project ``.dsc/settings.json`` ``{"sandbox": {"mode": "..."}}``.
    4. ``DEFAULT_SANDBOX_MODE`` (``workspace-write``).

    The function never raises: on a malformed value it falls through to
    the next layer. Reading at call time (not import time) lets the
    ``/sandbox <mode>`` slash command propagate immediately.
    """
    explicit = _SANDBOX_MODE.get()
    if explicit is not None:
        return explicit
    env = normalize_mode(os.environ.get("FRED_SANDBOX_MODE"))
    if env is not None:
        return env
    settings = _read_settings_sandbox_mode(start)
    if settings is not None:
        return settings
    return DEFAULT_SANDBOX_MODE


# ---------------------------------------------------------------------------
# Telemetry: stats consumed by the agent loop after each bash dispatch.

_LAST_SANDBOX_STATS: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "dsc_sandbox_last_stats", default=None,
)


def record_invocation_stats(payload: dict) -> None:
    """Stash a stats dict for the most recent bash sandbox wrap.

    Read + cleared via ``last_stats_payload``. Written by both ``bash.py``
    and ``bash_bg.py`` after the Popen call so the agent loop can ship a
    ``sandbox_invoked`` event without changing handler signatures.
    """
    _LAST_SANDBOX_STATS.set(payload)


def last_stats_payload() -> dict | None:
    """Return + clear the most recent sandbox-invocation stats."""
    s = _LAST_SANDBOX_STATS.get()
    if s is not None:
        _LAST_SANDBOX_STATS.set(None)
    return s


def wrap_command(
    cmd: str,
    mode: SandboxMode,
    project_root: Path,
) -> tuple[list[str] | str, str | None]:
    """Wrap a shell ``cmd`` in a Seatbelt invocation.

    Returns ``(argv_or_cmd, profile_used)``:

    * ``argv_or_cmd`` is either the wrapped ``list[str]`` argv to pass to
      ``subprocess.Popen(..., shell=False)``, OR the original ``cmd``
      string when sandboxing is unavailable on this platform / for this
      mode (caller should fall back to ``shell=True``).
    * ``profile_used`` is the SBPL profile string when wrapping was
      applied, ``None`` otherwise. Telemetry can hash / size this for
      auditing.

    Caller pattern (used by both ``bash.py`` and ``bash_bg.py``)::

        wrapped, profile = wrap_command(cmd, mode, root)
        if isinstance(wrapped, list):
            popen = subprocess.Popen(wrapped, shell=False, ...)
        else:
            popen = subprocess.Popen(wrapped, shell=True, ...)

    The two-flavor return is deliberate so the un-wrapped path stays
    bit-for-bit identical to the pre-P4.1 behavior on Linux / when the
    sandbox is otherwise unavailable.
    """
    if not is_supported():
        return cmd, None
    profile = build_profile(mode, project_root)
    argv = [_SANDBOX_EXEC_PATH, "-p", profile, "/bin/sh", "-c", cmd]
    return argv, profile
