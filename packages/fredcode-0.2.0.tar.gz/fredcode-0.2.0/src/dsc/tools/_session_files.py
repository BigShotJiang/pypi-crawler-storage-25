"""Per-session file-tracking state for the prior-Read enforcement (P1.4).

The model is required to `view` (or `create_file`) a path before it can
`str_replace` it — this matches Claude Code's biggest behavioral guard
and lets us keep the model honest about its working set. The mechanism
is a per-session set of resolved absolute paths plumbed via a
ContextVar (matching the bash `on_line` precedent in P1.3) so the
existing `Registry.dispatch` signature stays unchanged.

Lifecycle:
- cli.py installs the session-scoped set once before each `run_turn`
  via `set_tracked_files`. The set is shared by reference across the
  REPL session (same object across turns).
- `view` adds successfully-viewed files; `create_file` adds files it
  creates; `str_replace` adds files after a successful edit (so a
  follow-up edit on the same file in the same turn doesn't error).
- `str_replace` reads the set on entry and rejects edits to untracked
  files with the documented model-facing error string.

Sub-outcome signalling: `str_replace` also uses a separate ContextVar
to override `Registry.dispatch`'s default `"ok"` outcome with a
fine-grained value (e.g. `prior_read_required`) that flows into the
`dsc_tool_calls.outcome` telemetry column without changing the dispatch
plumbing.
"""
from __future__ import annotations

import contextvars
from pathlib import Path

# The session-scoped set of paths the model has "touched" — viewed,
# created, or edited. Resolved/absolute paths only (so a relative and
# absolute reference to the same file collapse into one entry).
_TRACKED_FILES: contextvars.ContextVar[set[Path] | None] = contextvars.ContextVar(
    "dsc_tracked_files", default=None,
)

# Sub-outcome ContextVar: tools that want a finer-grained outcome value
# than the default "ok" set this before returning. `Registry.dispatch`
# reads + clears it immediately after the handler returns and propagates
# the value into `meta["outcome"]`. Using "consume" semantics (set->read->
# clear) keeps a stale value from leaking across calls.
_TOOL_OUTCOME_OVERRIDE: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "dsc_tool_outcome_override", default=None,
)


def _resolve(path: str | Path) -> Path | None:
    """Best-effort resolve to an absolute Path. None if the OS rejects it.

    We don't require the path to exist — `mark_tracked` is sometimes
    called immediately after `create_file`, so the path is fresh. We do
    require resolution to succeed (no symlink loops, no permission errors
    walking parents); on failure we return None and the caller silently
    skips tracking.
    """
    try:
        return Path(path).expanduser().resolve()
    except (OSError, RuntimeError):
        return None


def set_tracked_files(tracked: set[Path]) -> contextvars.Token:
    """Install the session-scoped tracked-files set. Returns a reset token.

    Callers should pair this with `reset_tracked_files` in a try/finally
    so the ContextVar is always restored. The set is held by reference;
    mutations from tools persist across turns within the same session.
    """
    return _TRACKED_FILES.set(tracked)


def reset_tracked_files(token: contextvars.Token) -> None:
    _TRACKED_FILES.reset(token)


def mark_tracked(path: str | Path) -> None:
    """Record `path` as tracked for the current session.

    No-op if no set is installed (e.g. headless tool tests, subagent
    contexts that don't install one). Resolution failures are swallowed
    — the tracker is a model-facing nudge, not a contract.
    """
    tracked = _TRACKED_FILES.get()
    if tracked is None:
        return
    resolved = _resolve(path)
    if resolved is None:
        return
    tracked.add(resolved)


def is_tracked(path: str | Path) -> bool:
    """True if `path` (resolved) is in the current session's tracked set.

    Returns False when no set is installed; callers that want
    "no-tracker = allow edit" semantics should gate this check with
    `tracking_active()` first. `str_replace` does exactly that — when
    no tracker is wired (one-shot tool tests, embedded harnesses) the
    prior-Read enforcement is skipped entirely.
    """
    tracked = _TRACKED_FILES.get()
    if tracked is None:
        return False
    resolved = _resolve(path)
    if resolved is None:
        return False
    return resolved in tracked


def tracking_active() -> bool:
    """True if a session-scoped tracked set is installed.

    `str_replace` consults this before enforcing the prior-Read rule:
    when no tracker is wired (e.g. one-shot tool tests, or an old
    embedding harness), it falls back to the historical no-check
    behavior. The REPL always installs one, so the production guard is
    always live.
    """
    return _TRACKED_FILES.get() is not None


def set_tool_outcome(outcome: str) -> None:
    """Record a finer-grained outcome for the *current* tool call.

    `Registry.dispatch` reads + clears this after the handler returns
    and propagates it into `meta["outcome"]`. Overriding the default
    `"ok"` lets tools surface specific failure modes (e.g.
    `prior_read_required`, `not_found_with_candidate`) into the
    `dsc_tool_calls` telemetry column without expanding the handler
    return signature.
    """
    _TOOL_OUTCOME_OVERRIDE.set(outcome)


def consume_tool_outcome() -> str | None:
    """Return + clear the most recent tool outcome override (if any)."""
    val = _TOOL_OUTCOME_OVERRIDE.get()
    if val is not None:
        _TOOL_OUTCOME_OVERRIDE.set(None)
    return val
