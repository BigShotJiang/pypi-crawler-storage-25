"""todo_write tool: maintain a session-scope task checklist."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from dsc.tools.base import Tool

Status = Literal["pending", "in_progress", "completed"]


class TodoItem(BaseModel):
    id: str = Field(..., description="Stable identifier for the task.")
    content: str = Field(..., description="What needs to be done.")
    status: Status = Field("pending", description="One of pending, in_progress, completed.")


class TodoWriteArgs(BaseModel):
    todos: list[TodoItem] = Field(..., description="The full updated task list. Replaces prior list.")


_state: list[TodoItem] = []


def get_todos() -> list[TodoItem]:
    return list(_state)


def run(args: TodoWriteArgs) -> str:
    global _state
    _state = list(args.todos)
    if not _state:
        return "Todo list cleared."
    lines = ["Todo list updated:"]
    icon = {"pending": "[ ]", "in_progress": "[*]", "completed": "[x]"}
    for t in _state:
        lines.append(f"  {icon[t.status]} {t.content}")
    return "\n".join(lines)


tool = Tool(
    name="todo_write",
    description=(
        "Replace the session task checklist with the given list. Use whenever the "
        "user's request takes more than ~3 steps. Each item has id, content, and "
        "status (pending/in_progress/completed). Pass the FULL updated list each "
        "time — partial updates are not supported."
    ),
    args_model=TodoWriteArgs,
    handler=run,
    requires_permission=False,
)
