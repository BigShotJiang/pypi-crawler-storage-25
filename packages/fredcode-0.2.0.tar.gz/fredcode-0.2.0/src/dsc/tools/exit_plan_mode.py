"""exit_plan_mode tool (P2.2).

Model-callable: when the agent is satisfied with the plan it produced
in plan mode, it calls ``exit_plan_mode`` with a one-line summary and
the dispatcher flips the session mode back to ``"act"``. Subsequent
tool calls in the same session can then mutate state (run shell, edit
files, etc.).

The tool is always available regardless of the current mode — that's
how plan mode can exit itself. In act mode, calling it is a no-op flip
(act → act) and the model just sees the confirmation string.

Mode flipping is done via the ``dsc.mode`` ContextVar machinery so the
``Registry.dispatch`` signature stays stable (matches the P1.3 / P1.4
precedents).
"""
from __future__ import annotations

from pydantic import BaseModel, Field

from dsc.mode import set_current_mode
from dsc.tools.base import Tool


class ExitPlanModeArgs(BaseModel):
    summary: str = Field(
        ...,
        description=(
            "A one-line description of the plan you are committing to. "
            "Will be shown to the user as the act-mode kickoff."
        ),
    )


def run(args: ExitPlanModeArgs) -> str:
    set_current_mode("act")
    # Returning a confirmation string lets the model see (in the next
    # iteration's tool result) that the flip succeeded and what plan
    # it just committed to. The cli.py side surfaces the same summary
    # via the `mode_change` event.
    return f"Plan accepted; switching to act mode.\n\n{args.summary}"


tool = Tool(
    name="exit_plan_mode",
    description=(
        "Switch from plan mode to act mode after producing a plan. Pass a "
        "one-line summary describing the plan you are committing to. After "
        "this call returns, you can use the full tool registry (bash, "
        "str_replace, etc.). Only useful in plan mode; in act mode it is a "
        "no-op aside from echoing the summary."
    ),
    args_model=ExitPlanModeArgs,
    handler=run,
    requires_permission=False,
)
