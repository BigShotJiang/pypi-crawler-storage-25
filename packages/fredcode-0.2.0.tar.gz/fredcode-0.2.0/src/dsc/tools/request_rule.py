"""`request_rule` tool — model-driven rule activation (P3.2).

Description-only rules in ``.dsc/rules/*.md`` are listed in the system
"Rules (available)" section so the model knows about them, but their
bodies are not injected by default. When the model decides one is
relevant, it invokes ``request_rule(name="...")`` and the rule's body
becomes part of the active block on every subsequent iteration.

Wiring follows the bash ``set_on_line`` precedent: a ContextVar holds
the per-session rule set and the explicit-request mutable set, which
the agent loop installs before each tool dispatch and resets in a
``finally``. Tool handlers stay (args) -> str — no signature change.

The handler returns the rule body verbatim so the model can use it
immediately on the SAME iteration (don't have to wait a turn for the
re-render). The session-scoped explicit set guarantees the rule stays
in the active block on subsequent iterations too — a one-shot model
request becomes persistent for the rest of the session.
"""
from __future__ import annotations

import contextvars

from pydantic import BaseModel, Field

from dsc.rules import Rule, RuleSet
from dsc.tools.base import Tool


class RequestRuleArgs(BaseModel):
    name: str = Field(
        ...,
        description=(
            "The rule name (file stem or `name:` field) listed in the "
            "system 'Rules (available)' section. Activates the rule for "
            "the rest of this session."
        ),
    )


class RuleRequestContext:
    """Per-session bag wired into the ContextVar by the agent loop.

    `rule_set` is the RuleSet loaded once at session start. `explicit`
    is the set the handler mutates on success — `RuleSet.applicable_for`
    reads from the same set on the next iteration so the requested
    rule appears in the active block.
    """

    def __init__(self, *, rule_set: RuleSet, explicit: set[str]) -> None:
        self.rule_set = rule_set
        self.explicit = explicit


_REQUEST_RULE_CTX: contextvars.ContextVar[RuleRequestContext | None] = (
    contextvars.ContextVar("dsc_request_rule_ctx", default=None)
)


def set_request_rule_context(
    ctx: RuleRequestContext | None,
) -> contextvars.Token:
    """Install the per-session rule context. Returns a reset token.

    Caller must pair this with ``reset_request_rule_context`` in a
    try/finally — same pattern as bash `set_on_line` and agent_tool's
    `set_dispatch_context`.

    Passing ``None`` masks any outer context (used by subagents that
    don't share the parent's RuleSet — they install ``None`` so a stray
    ``request_rule`` call surfaces a structured error instead of
    silently mutating the parent's explicit set).
    """
    return _REQUEST_RULE_CTX.set(ctx)


def reset_request_rule_context(token: contextvars.Token) -> None:
    _REQUEST_RULE_CTX.reset(token)


def get_request_rule_context() -> RuleRequestContext | None:
    """Return the currently-installed context, or None if not wired.

    Test convenience: callers can inspect the explicit set this returns
    to verify the handler mutated it correctly.
    """
    return _REQUEST_RULE_CTX.get()


def run(args: RequestRuleArgs) -> str:
    """Look up the named rule and add it to the session's explicit set.

    Returns:
      - The rule's body content on success (so the model can act on it
        immediately, not just on the next iteration).
      - ``Error: rule {name} not found. Available rules: {list}`` when
        the name isn't in the loaded set. The list lets the model
        recover via a follow-up call.
      - ``Error: request_rule has no rule context`` if the handler
        runs without the agent loop installing the context bag —
        defensive for headless tool tests.
    """
    ctx = _REQUEST_RULE_CTX.get()
    if ctx is None:
        return "Error: request_rule has no rule context (run from agent loop)"

    rule: Rule | None = ctx.rule_set.by_name.get(args.name)
    if rule is None:
        available = sorted(ctx.rule_set.by_name)
        if available:
            return (
                f"Error: rule {args.name!r} not found. "
                f"Available rules: {', '.join(available)}"
            )
        return f"Error: rule {args.name!r} not found. No rules are loaded."

    # Mutate the explicit set so subsequent iterations include the rule
    # in the active block via `RuleSet.applicable_for(..., explicit=...)`.
    ctx.explicit.add(rule.name)

    body = rule.body.strip()
    header = f"# {rule.name}"
    if rule.description:
        header += f"\n_{rule.description.strip()}_"
    return f"{header}\n\n{body}" if body else header


tool = Tool(
    name="request_rule",
    description=(
        "Activate a description-only rule from `.dsc/rules/*.md`. The rule's "
        "name (file stem or `name:` field) is listed in the 'Rules "
        "(available, request via request_rule)' section of the system "
        "context. Calling this returns the rule's body content immediately "
        "AND keeps the rule active in the system block for the rest of the "
        "session. Use it when an available rule is relevant to the user's "
        "current request."
    ),
    args_model=RequestRuleArgs,
    handler=run,
    requires_permission=False,
)
