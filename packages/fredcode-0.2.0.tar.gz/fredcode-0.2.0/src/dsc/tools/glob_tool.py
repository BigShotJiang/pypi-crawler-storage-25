"""glob tool: find files by glob pattern, sorted by mtime descending."""
from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field

from dsc.tools.base import Tool, truncate

MAX_RESULTS = 1000


class GlobArgs(BaseModel):
    pattern: str = Field(..., description="Glob pattern, e.g. '**/*.py' or 'src/**/test_*.py'.")
    path: str | None = Field(None, description="Root directory to search from. Defaults to cwd.")


def run(args: GlobArgs) -> str:
    root = Path(args.path).expanduser() if args.path else Path.cwd()
    if not root.exists() or not root.is_dir():
        return f"Error: path does not exist or is not a directory: {root}"
    matches = []
    try:
        for p in root.glob(args.pattern):
            if p.is_file():
                try:
                    mtime = p.stat().st_mtime
                except OSError:
                    mtime = 0
                matches.append((mtime, p))
    except (OSError, ValueError) as e:
        return f"Error: glob failed: {e}"
    matches.sort(key=lambda t: t[0], reverse=True)
    if not matches:
        return f"No files matched {args.pattern!r} under {root}"
    truncated = matches[:MAX_RESULTS]
    body = "\n".join(str(p) for _, p in truncated)
    suffix = f"\n[capped at {MAX_RESULTS}; {len(matches) - MAX_RESULTS} more matches]" if len(matches) > MAX_RESULTS else ""
    return truncate(body + suffix)


tool = Tool(
    name="glob",
    description=(
        "Find files matching a glob pattern (e.g. '**/*.py'). Returns paths sorted "
        "by mtime descending (newest first). Capped at 1000 results."
    ),
    args_model=GlobArgs,
    handler=run,
    requires_permission=False,
)
