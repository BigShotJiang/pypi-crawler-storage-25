"""Subagent dispatch tool (`agent`).

The model invokes `agent(prompt, agent_type, ...)` to spawn an isolated
`run_session` with its own message list, registry subset, and headless
renderer. The subagent's final text comes back as the tool result; the
parent renders one `subagent_card` Panel summarizing the child run.

Three built-in profiles to start (plan §P2.1):
- `explore`: read-only — `view, grep, glob, repo_map`
- `plan`:    `explore` + `todo_write` (scratchpad-style planning)
- `general`: full registry MINUS the `agent` tool itself (no recursion)

Recursion guard: AGENT_PROFILES never contains `agent`, so a subagent's
constrained registry literally cannot dispatch another `agent` call.
The recursion contract is enforced at the registry layer, not via a
runtime check.

Concurrency: SEQUENTIAL in v1 per the plan. A future ThreadPoolExecutor
landing in P2.1.b is blocked on `PermissionPolicy.check`'s stdin
coupling — explore-only subagents would be safe today (read-only
tools have `requires_permission=False`) but `general` would race the
parent's permission Panel. We don't ship that surface in this PR.

Context inheritance: subagents reuse the parent's `DSClient`,
`PermissionPolicy` (by reference, so `--yolo`/always_allow propagate),
and `Tracer` (forked via `tracer.fork_subagent` to write a child
`dsc_sessions` row with `parent_session_id` set). API key surface is
the parent's; no separate auth path. The same telemetry writer drains
both parent and child events on its single daemon thread.
"""
from __future__ import annotations

import contextvars
import os
import sys
import time
from typing import Literal

from pydantic import BaseModel, Field

from dsc.client import DSClient
from dsc.permissions import PermissionPolicy
from dsc.render import Renderer
from dsc.telemetry import NullTracer, Tracer
from dsc.tools.base import Tool
from dsc.tools.registry import Registry

# AGENT_PROFILES wires each agent label to the set of tool names a
# subagent of that type may dispatch. The set is `frozenset` to make
# the mapping safe to share across calls and clearly read-only.
#
# `general` is built dynamically below in `subset_for(...)` because the
# parent registry's tool list is the only authoritative source of "what
# exists" — hardcoding it here would drift the moment a new tool lands.
# We do hardcode `explore` and `plan` because their bounded scope is the
# point: the model gets a small, predictable surface to reason inside.
AGENT_PROFILES: dict[str, frozenset[str]] = {
    "explore": frozenset({"view", "grep", "glob", "repo_map"}),
    "plan":    frozenset({"view", "grep", "glob", "repo_map", "todo_write"}),
    # `general` is resolved lazily — see `_resolve_general(...)` below.
    "general": frozenset(),
}

# The `agent` tool itself MUST NOT appear in any subset. This is the
# recursion guard — `Registry.subset(...)` is the enforcement seam.
_AGENT_TOOL_NAME = "agent"


class AgentArgs(BaseModel):
    prompt: str = Field(
        ...,
        description=(
            "Self-contained instruction for the subagent. The subagent has "
            "no access to your conversation history; include any context it "
            "needs (file paths, symbol names, the question to answer)."
        ),
    )
    agent_type: Literal["explore", "plan", "general"] = Field(
        "explore",
        description=(
            "Built-in profile. `explore` gets read-only tools "
            "(view/grep/glob/repo_map); `plan` adds todo_write for "
            "scratchpad planning; `general` gets the full registry minus "
            "this tool. Default: explore."
        ),
    )
    max_iters: int = Field(
        10, ge=1, le=50,
        description="Iteration cap for the subagent's run_session loop. Default 10.",
    )
    model_override: str | None = Field(
        None,
        description=(
            "Optional model name override for this subagent's calls. "
            "Defaults to the parent's model. Reserved for P2.3 multi-model "
            "routing — supply only if you intentionally want a different "
            "model than the parent."
        ),
    )


# ---------------------------------------------------------------------------
# Dispatch-context ContextVar (mirrors the bash `set_on_line` precedent).
#
# The `agent` tool's handler signature is `(args) -> str` like every other
# tool, but it needs to reach into the parent's run_session context to
# get the parent client, permissions, registry, tracer, and the parent's
# renderer for rendering the subagent_card. Plumbing that as additional
# handler args would require changing every tool's signature; instead we
# stash a context object in a ContextVar that `agent.py` (the dispatch
# loop) sets before dispatching the agent tool and resets afterward.
# ---------------------------------------------------------------------------


class AgentDispatchContext:
    """Bag of parent-session references needed to spawn a subagent.

    Held in a ContextVar `set` by the parent's iteration loop right before
    it dispatches an `agent(...)` tool call, and `reset` in a try/finally
    afterward (mirrors the bash `set_on_line` pattern).
    """

    def __init__(
        self,
        *,
        client: DSClient,
        registry: Registry,
        permissions: PermissionPolicy,
        tracer: Tracer,
        renderer: Renderer,
        parent_session_id: str | None,
        parent_iteration_id: str | None,
    ) -> None:
        self.client = client
        self.registry = registry
        self.permissions = permissions
        self.tracer = tracer
        self.renderer = renderer
        self.parent_session_id = parent_session_id
        self.parent_iteration_id = parent_iteration_id


_AGENT_DISPATCH_CTX: contextvars.ContextVar[AgentDispatchContext | None] = (
    contextvars.ContextVar("dsc_agent_dispatch_ctx", default=None)
)


def set_dispatch_context(ctx: AgentDispatchContext) -> contextvars.Token:
    return _AGENT_DISPATCH_CTX.set(ctx)


def reset_dispatch_context(token: contextvars.Token) -> None:
    _AGENT_DISPATCH_CTX.reset(token)


# ---------------------------------------------------------------------------


def _resolve_general(parent_registry: Registry) -> frozenset[str]:
    """All names in the parent registry EXCEPT `agent` (recursion guard)."""
    return frozenset(n for n in parent_registry.names() if n != _AGENT_TOOL_NAME)


def subset_for(
    agent_type: str, parent_registry: Registry,
) -> frozenset[str]:
    """Return the tool-name subset for `agent_type` filtered against
    the parent registry.

    Raises `ValueError` for unknown agent types. For `general`, the set
    is computed against the parent registry so newly-registered tools
    are automatically included (minus `agent` itself). For built-in
    profiles, names that aren't registered in the parent (e.g. `repo_map`
    when the repo map is exposed as a system-message-only feature rather
    than a callable tool) are silently dropped — the profile spec is
    aspirational; the runtime subset is what's actually dispatchable.
    """
    if agent_type == "general":
        return _resolve_general(parent_registry)
    if agent_type not in AGENT_PROFILES:
        raise ValueError(f"unknown agent_type: {agent_type!r}")
    parent_names = set(parent_registry.names())
    return frozenset(AGENT_PROFILES[agent_type] & parent_names)


_SUBAGENT_SYSTEM_PROMPTS: dict[str, str] = {
    "explore": (
        "You are an `explore` subagent dispatched by the main dsc agent. "
        "Your job is to investigate the user's question using read-only "
        "tools (view, grep, glob, repo_map) and return a CONCISE summary "
        "of what you found. Do not edit files. When done, stop emitting "
        "tool calls and return a short prose answer — that text becomes "
        "the only thing your parent sees. Lead with the answer; cite "
        "specific files and line numbers; keep it under ~300 words."
    ),
    "plan": (
        "You are a `plan` subagent dispatched by the main dsc agent. "
        "Your job is to read the codebase, then produce a step-by-step "
        "implementation plan. You have read-only tools plus `todo_write` "
        "for structuring the plan. Do not edit other files. When done, "
        "return a concise prose plan summary — that text becomes the only "
        "thing your parent sees."
    ),
    "general": (
        "You are a `general` subagent dispatched by the main dsc agent. "
        "You have access to most tools (excluding `agent` itself, by "
        "design — no nested subagents). Complete the requested task and "
        "return a concise summary; that summary is the only thing your "
        "parent sees. Be thorough but bounded by your iteration cap."
    ),
}


def _build_initial_messages(prompt: str, agent_type: str) -> list[dict]:
    """Compose the [system, user] message list the subagent starts with.

    Subagents see a fresh context — they do NOT inherit the parent's
    conversation history. The `prompt` argument is the entire user-facing
    instruction; the system prompt is profile-specific.
    """
    return [
        {"role": "system", "content": _SUBAGENT_SYSTEM_PROMPTS[agent_type]},
        {"role": "user", "content": prompt},
    ]


def run(args: AgentArgs) -> str:
    """Dispatch a subagent and return its `final_text`.

    Returns the child's `SessionResult.final_text` directly so the parent
    model gets the synthesized answer as a tool result (the same way it
    consumes any other tool's output). All other observability — token
    counts, iteration-by-iteration trace, the visible card — happens via
    the parent renderer's `subagent_card` and the telemetry layer.
    """
    ctx = _AGENT_DISPATCH_CTX.get()
    if ctx is None:
        # Defensive: the dispatch loop should always set the context
        # before invoking agent. If it didn't, refuse rather than spawn
        # a subagent without a parent linkage (which would create a
        # zombie root session in telemetry).
        return "Error: agent tool requires a dispatch context (run from agent loop)"

    parent_registry = ctx.registry
    try:
        subset_names = subset_for(args.agent_type, parent_registry)
    except ValueError as e:
        return f"Error: {e}"

    # Materialize the constrained registry. `Registry.subset` raises if a
    # name is unknown — that means the parent registry is missing a tool
    # listed in the profile (e.g. `repo_map` if the feature is gated).
    # We surface the missing names rather than silently dropping them so
    # the model sees a structured error.
    try:
        sub_registry = parent_registry.subset(set(subset_names))
    except ValueError as e:
        return f"Error: {e}"

    # Fork a child tracer so the dsc_sessions row carries
    # parent_session_id + session_kind="subagent". We need a real session
    # row, not just events, for the dsc_session_cost_rollup view to work.
    parent_tracer = ctx.tracer
    agent_label = f"{args.agent_type}-{int(time.perf_counter() * 1000) % 100000}"
    child_tracer: Tracer = parent_tracer.fork_subagent(
        parent_session_id=ctx.parent_session_id,
        parent_iteration_id=ctx.parent_iteration_id,
        agent_label=agent_label,
        agent_tool_subset=sorted(subset_names),
    )
    child_tracer.start_session(
        model=ctx.client.model,
        base_url=str(ctx.client.base_url),
        yolo=ctx.permissions.yolo,
        one_shot=False,
        system_prompt=_SUBAGENT_SYSTEM_PROMPTS[args.agent_type],
        registry_names=sub_registry.names(),
        registry_perms={
            n: sub_registry.get(n).requires_permission for n in sub_registry.names()
        },
    )

    # Emit the dispatched event from the PARENT tracer so it lands on the
    # parent session's timeline (the child hasn't appended any events yet).
    child_session_id = getattr(child_tracer, "session_id", "")
    parent_tracer.event(
        "subagent_dispatched",
        payload={
            "parent_session_id": ctx.parent_session_id,
            "child_session_id": child_session_id,
            "agent_type": args.agent_type,
            "tools_allowed": sorted(subset_names),
            "max_iters": args.max_iters,
        },
    )

    # Spin up the headless renderer — same console as the parent so any
    # `DSC_SHOW_SUBAGENTS=1` forwarding can use stderr; the headless flag
    # prevents Live region or tool-card prints from leaking out.
    headless_renderer = Renderer(
        console=ctx.renderer.console,
        stream=False,
        show_thinking=False,
        headless=True,
    )

    # Build initial messages and run the loop. We import `run_session`
    # lazily here to avoid a circular import (session.py imports tools'
    # registry; tools/agent_tool.py is loaded at registry build time).
    from dsc.session import run_session

    initial = _build_initial_messages(args.prompt, args.agent_type)
    started = time.perf_counter()
    outcome = "ok"
    try:
        result = run_session(
            initial,
            ctx.client,
            sub_registry,
            permissions=ctx.permissions,
            max_iters=args.max_iters,
            mode="act",
            parent_session_id=ctx.parent_session_id,
            tracer=child_tracer,
            renderer=headless_renderer,
            turn=None,
            repo_map_provider=None,
        )
    except Exception as e:
        # Subagent errors must not raise out of the parent loop; surface
        # them as a structured tool error so the model recovers.
        elapsed = time.perf_counter() - started
        ctx.tracer.event(
            "subagent_completed",
            payload={
                "child_session_id": child_session_id,
                "outcome": "error",
                "iterations_used": 0,
                "summary_chars": 0,
                "total_tokens": 0,
                "elapsed_s": round(elapsed, 3),
                "error": str(e)[:200],
            },
        )
        child_tracer.end_session(reason="error")
        return f"Error: subagent {args.agent_type} crashed: {type(e).__name__}: {e}"

    elapsed_s = time.perf_counter() - started
    # Iterations = assistant messages produced by the loop. Each iteration
    # appends exactly one assistant message (whether or not it contained
    # tool_calls), so this count is exact regardless of how many tools
    # were dispatched.
    iterations_used = sum(
        1 for m in result.messages if m.get("role") == "assistant"
    )
    if iterations_used == 0:
        # Defensive: a loop that ended via budget_hard / api_error
        # before any assistant message was emitted. Show 1 so the
        # subagent_card doesn't read "0 iter."
        iterations_used = 1
    if not result.final_text and iterations_used >= args.max_iters:
        outcome = "iter_cap"

    summary = result.final_text or "(subagent did not produce a final answer)"
    total_tokens = result.total_tokens_in + result.total_tokens_out

    # Power-user override: forward the headless buffer to stderr so the
    # user can debug subagent behavior. Off by default. Best-effort —
    # any TTY error is swallowed.
    if os.environ.get("DSC_SHOW_SUBAGENTS") == "1":
        try:
            for line in headless_renderer.headless_buffer:
                print(f"  [{args.agent_type}] {line}", file=sys.stderr)
        except OSError:
            pass

    # Render the parent-side card on the parent's renderer. The parent's
    # renderer is NOT headless, so this prints a Panel into the user's
    # transcript. recent_results gets an entry so `/last` works.
    ctx.renderer.subagent_card(
        agent_type=args.agent_type,
        iterations=iterations_used,
        elapsed_s=elapsed_s,
        total_tokens=total_tokens,
        summary=summary,
        outcome=outcome,
    )

    # Final telemetry from the parent's perspective so the timeline
    # reads "dispatched -> ... -> completed" against the parent session.
    ctx.tracer.event(
        "subagent_completed",
        payload={
            "child_session_id": child_session_id,
            "outcome": outcome,
            "iterations_used": iterations_used,
            "summary_chars": len(summary),
            "total_tokens": total_tokens,
            "elapsed_s": round(elapsed_s, 3),
        },
    )
    child_tracer.end_session(reason="natural" if outcome == "ok" else outcome)

    # TODO(P2.1.b): once `PermissionPolicy.check`'s stdin coupling is
    # solved, multiple agent_tool dispatches in the same parent
    # iteration can run via a ThreadPoolExecutor. Until then, the
    # parent loop dispatches subagents sequentially — each blocks on
    # the previous one's run_session completion.
    return summary


tool = Tool(
    name="agent",
    description=(
        "Spawn an isolated subagent with a constrained tool set. The "
        "subagent has its own context window, runs in headless mode "
        "(its transcript is not streamed inline), and returns ONLY a "
        "summary as the tool result. Use this to delegate exploration "
        "without bloating your own context. Profiles: `explore` "
        "(view/grep/glob/repo_map), `plan` (explore + todo_write), "
        "`general` (full registry except `agent`). The subagent inherits "
        "your permission policy by reference."
    ),
    args_model=AgentArgs,
    handler=run,
    requires_permission=False,
)
