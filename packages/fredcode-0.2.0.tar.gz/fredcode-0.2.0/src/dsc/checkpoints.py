"""Shadow-git workspace checkpoints (P4.3, Cline pattern).

After each successful, write-flavored tool dispatch we snapshot the
workspace into a SHADOW git repo at ``~/.dsc/checkpoints/<workspace_hash>.git``.
The user's project never gains a `.git` directory, never has commits
appended to its real history, and never sees the snapshot author —
the shadow repo is the only writable git target.

Trick borrowed from Cline: git refuses to add a worktree that contains
nested ``.git`` directories. To work around this we rename any nested
``.git`` directories to ``.git_disabled`` for the duration of the snapshot
and restore them in a ``finally`` block, even on crash. The user's primary
``.git`` (project root) is rename-skipped; only nested submodules /
sub-repos see the temporary rename.

Restore semantics:
  - ``files_only=False`` (default): the caller's view-changes UI walks
    the conversation back to the matching turn AND ``checkout``s the
    workspace files. The conversation truncation is the caller's job
    (we return the SHA so they can locate it); the file-system part
    is what this module owns.
  - ``files_only=True``: only the workspace is restored; the conversation
    history is preserved (matches the "view changes" inline restore).

Stale-workspace cleanup (``prune_stale``) walks ``~/.dsc/checkpoints``
once per week and deletes shadow repos whose recorded workspace path
no longer exists. Best-effort; failures swallowed.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import time
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterator


# --- constants ------------------------------------------------------------

CHECKPOINT_AUTHOR_NAME = "dsc-checkpoint"
CHECKPOINT_AUTHOR_EMAIL = "checkpoint@dsc.local"

# Tools that NEVER trigger a snapshot. Read-only by definition; snapshotting
# after each one would add disk I/O + git churn for zero benefit. The
# session.py dispatch loop consults this set.
READ_ONLY_TOOLS: frozenset[str] = frozenset({
    "view", "grep", "glob", "repo_map", "request_rule",
})

# Debounce: tools sometimes fire bursts (e.g. multiple str_replaces in
# the same iteration). Skip a snapshot if the previous one for this
# Checkpointer instance landed less than this many milliseconds ago.
_DEBOUNCE_MS = 50

# How often to run the stale-workspace prune. Once per week is plenty —
# this is hygiene, not a hot path. The marker file lives next to the
# checkpoints directory.
_PRUNE_INTERVAL_DAYS = 7


# --- data ----------------------------------------------------------------


@dataclass(frozen=True)
class CheckpointEntry:
    """One row in ``Checkpointer.list()``.

    ``ts`` is the commit author-date as a ``datetime`` (tz-aware UTC);
    ``message`` is the commit subject (we never set a body).
    """

    sha: str
    ts: datetime
    message: str


# --- helpers --------------------------------------------------------------


def _checkpoints_root() -> Path:
    """Return ``~/.dsc/checkpoints`` (lazy-created)."""
    root = Path.home() / ".dsc" / "checkpoints"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _workspace_hash(project_root: Path) -> str:
    """Stable hash of the absolute project root.

    The shadow repo path collides with another project ONLY if their
    absolute paths share a sha256 (i.e. never, in practice). We use the
    full hash rather than a prefix to keep collisions out of the
    realm of "could happen on a busy laptop."
    """
    abs_root = str(project_root.expanduser().resolve())
    return hashlib.sha256(abs_root.encode("utf-8")).hexdigest()


def _shadow_repo_path(workspace_hash: str) -> Path:
    return _checkpoints_root() / f"{workspace_hash}.git"


def _workspace_marker_path(shadow_repo: Path) -> Path:
    """Sidecar file recording the workspace path this shadow repo backs.

    Lives next to the bare repo (NOT inside it — git would complain).
    Used by ``prune_stale`` to detect repos whose workspace no longer
    exists. Format: a single line with the absolute path.
    """
    return shadow_repo.with_suffix(".workspace")


def _last_prune_marker() -> Path:
    return _checkpoints_root() / ".last_prune"


def _now_ms() -> int:
    return int(time.time() * 1000)


def _git_env(shadow_repo: Path, project_root: Path) -> dict[str, str]:
    """Build the env dict for `git` invocations.

    We pin the author identity so the snapshot doesn't pollute the user's
    git log (defense in depth — these go to a separate repo anyway, but
    if anything ever escapes the sandbox we want the author to be
    obviously synthetic). ``GIT_DIR`` + ``GIT_WORK_TREE`` are the standard
    way to operate on a bare repo against an external worktree.
    """
    env = os.environ.copy()
    env["GIT_DIR"] = str(shadow_repo)
    env["GIT_WORK_TREE"] = str(project_root)
    env["GIT_AUTHOR_NAME"] = CHECKPOINT_AUTHOR_NAME
    env["GIT_AUTHOR_EMAIL"] = CHECKPOINT_AUTHOR_EMAIL
    env["GIT_COMMITTER_NAME"] = CHECKPOINT_AUTHOR_NAME
    env["GIT_COMMITTER_EMAIL"] = CHECKPOINT_AUTHOR_EMAIL
    return env


def _run_git(
    args: list[str], *, env: dict[str, str], cwd: Path | None = None,
    check: bool = True, timeout: float = 30.0,
) -> subprocess.CompletedProcess:
    """Invoke `git` with the shadow-repo env. Capture output.

    Errors raise ``subprocess.CalledProcessError`` when ``check=True``
    so callers can swallow / log per their best-effort policy.
    """
    return subprocess.run(
        ["git", *args],
        env=env,
        cwd=str(cwd) if cwd is not None else None,
        capture_output=True,
        text=True,
        check=check,
        timeout=timeout,
    )


def _find_nested_dotgits(
    project_root: Path, *, exclude_root: bool = True,
) -> list[Path]:
    """Walk the workspace and return every ``.git`` directory.

    Excludes the project root's own ``.git`` so the user's primary repo
    is never renamed. We don't follow symlinks to avoid traversing into
    arbitrary places; we don't recurse into ``.git_disabled`` (that's
    a previous-run leftover we'd never touch). We DO walk past the
    project's own ``.git`` because we may have a worktree-style layout
    where the top is just a marker file — let ``exclude_root`` handle
    that case via path equality.
    """
    found: list[Path] = []
    root_dotgit = (project_root / ".git").resolve()
    # os.walk is lighter than Path.rglob for "skip subtree" semantics —
    # we mutate `dirnames` to prune .git_disabled trees.
    for dirpath, dirnames, _ in os.walk(project_root, followlinks=False):
        # Prune previously-disabled trees so we don't recurse into them.
        if ".git_disabled" in dirnames:
            dirnames.remove(".git_disabled")
        if ".git" in dirnames:
            git_path = Path(dirpath) / ".git"
            try:
                resolved = git_path.resolve()
            except OSError:
                resolved = git_path
            if exclude_root and resolved == root_dotgit:
                # Skip — but DON'T `dirnames.remove(".git")` here, we
                # want os.walk to descend into the rest of the tree.
                pass
            else:
                found.append(git_path)
                # Don't descend into a nested git dir.
                dirnames.remove(".git")
    return found


@contextmanager
def _disable_nested_dotgits(project_root: Path) -> Iterator[list[Path]]:
    """Rename every nested ``.git`` -> ``.git_disabled`` for the duration.

    Restored in a ``finally`` block so a crash mid-snapshot leaves the
    workspace untouched. The yielded list is the set of paths we
    renamed (in the original-name form) — useful for tests and for
    future telemetry that wants to count submodules.
    """
    nested = _find_nested_dotgits(project_root, exclude_root=True)
    renamed: list[tuple[Path, Path]] = []
    try:
        for git_path in nested:
            disabled = git_path.with_name(".git_disabled")
            try:
                git_path.rename(disabled)
                renamed.append((git_path, disabled))
            except OSError:
                # Best effort — if rename fails (perms, race), skip.
                # The git add will likely fail too, and we'll surface
                # that error to the caller.
                pass
        yield [orig for orig, _ in renamed]
    finally:
        # Restore in reverse order so deeper directories get their .git
        # back before shallower ones (defensive — order shouldn't matter
        # for renames, but it's free).
        for orig, disabled in reversed(renamed):
            try:
                if disabled.exists() and not orig.exists():
                    disabled.rename(orig)
            except OSError:
                # Restoration failure is bad but not fatal to the
                # process. Best effort; log nothing to avoid stdio
                # in a finally block.
                pass


# --- main API ------------------------------------------------------------


class Checkpointer:
    """Per-workspace shadow-git snapshot manager.

    Construct one ``Checkpointer`` per session for a given project_root.
    Methods are safe to call repeatedly; the shadow repo is initialized
    lazily on the first ``snapshot()``.
    """

    def __init__(self, project_root: Path, *, debounce_ms: int = _DEBOUNCE_MS) -> None:
        self.project_root = project_root.expanduser().resolve()
        self.workspace_hash = _workspace_hash(self.project_root)
        self.shadow_repo = _shadow_repo_path(self.workspace_hash)
        self.debounce_ms = debounce_ms
        self._last_snapshot_ms: int | None = None

    # ---- init & telemetry helpers ------------------------------------

    def _ensure_repo(self) -> bool:
        """Initialize the bare shadow repo if missing. Returns True on init."""
        if self.shadow_repo.exists():
            return False
        self.shadow_repo.parent.mkdir(parents=True, exist_ok=True)
        # `git init --bare` is the simplest path; we set the default
        # branch explicitly so checkout works on git versions that
        # default to `master` while the rest of the world has moved
        # to `main` (and vice-versa).
        _run_git(
            ["init", "--bare", "--initial-branch=main", str(self.shadow_repo)],
            env=os.environ.copy(),
            check=True,
        )
        # Sidecar marker for prune_stale.
        try:
            _workspace_marker_path(self.shadow_repo).write_text(
                str(self.project_root) + "\n", encoding="utf-8",
            )
        except OSError:
            pass
        return True

    # ---- snapshot ----------------------------------------------------

    def snapshot(self, message: str) -> str | None:
        """Take a workspace snapshot. Returns the new commit SHA, or None.

        Returns ``None`` when:
          - the call was debounced (a snapshot landed <``debounce_ms`` ms ago),
          - there were no changes to commit,
          - the underlying git invocation failed (best-effort).

        The first snapshot for a workspace creates the bare repo on
        disk; subsequent calls reuse it. Nested ``.git`` directories
        are temporarily renamed (Cline trick) so git's nested-repo
        restriction doesn't refuse the ``add -A``.
        """
        now_ms = _now_ms()
        if (
            self._last_snapshot_ms is not None
            and now_ms - self._last_snapshot_ms < self.debounce_ms
        ):
            return None

        try:
            self._ensure_repo()
        except subprocess.SubprocessError:
            return None
        except OSError:
            return None

        env = _git_env(self.shadow_repo, self.project_root)
        try:
            with _disable_nested_dotgits(self.project_root):
                # Stage everything. `git add -A` walks the worktree and
                # picks up new + modified + deleted files. We don't
                # honor the user's .gitignore here intentionally — the
                # checkpoint is a forensic recovery aid, not a "what I
                # want to publish" snapshot. (If the user wants
                # exclusions, the shadow repo's own .gitignore — at
                # ``info/exclude`` — is how to add them; we don't
                # configure one by default.)
                _run_git(["add", "-A"], env=env, check=True)
                # `git commit -m ...`. If there are no changes, git
                # returns non-zero — we treat that as "nothing to
                # snapshot" and return None.
                proc = _run_git(
                    [
                        "commit",
                        "--allow-empty-message",
                        "-m", message or "(auto checkpoint)",
                    ],
                    env=env,
                    check=False,
                )
                if proc.returncode != 0:
                    # Most common: "nothing to commit, working tree
                    # clean" — not a failure, just a no-op. Treat all
                    # non-zero as "no snapshot" without raising.
                    return None
                # Read the resulting SHA.
                sha_proc = _run_git(
                    ["rev-parse", "HEAD"], env=env, check=True,
                )
                sha = sha_proc.stdout.strip()
        except subprocess.SubprocessError:
            return None
        except OSError:
            return None

        self._last_snapshot_ms = _now_ms()
        return sha or None

    # ---- list --------------------------------------------------------

    def list(self, limit: int = 20) -> list[CheckpointEntry]:
        """Return the most-recent ``limit`` checkpoints (newest first).

        Empty list when the shadow repo doesn't exist yet OR when it has
        no commits. Errors swallowed (best-effort surface).
        """
        if not self.shadow_repo.exists():
            return []
        env = _git_env(self.shadow_repo, self.project_root)
        try:
            # %H = full SHA, %ct = commit time (unix), %s = subject.
            # ``%x1f`` is the unit-separator byte — safe for git
            # log's --format because git just emits it verbatim, and
            # safe for our parser because subject lines never contain
            # raw 0x1f.
            proc = _run_git(
                [
                    "log",
                    f"-n{int(limit)}",
                    "--format=%H%x1f%ct%x1f%s",
                ],
                env=env,
                check=False,
            )
        except (subprocess.SubprocessError, OSError):
            return []
        if proc.returncode != 0:
            return []
        out: list[CheckpointEntry] = []
        for line in proc.stdout.splitlines():
            parts = line.split("\x1f", 2)
            if len(parts) != 3:
                continue
            sha, ts_raw, message = parts
            try:
                ts = datetime.fromtimestamp(int(ts_raw), tz=timezone.utc)
            except (ValueError, OSError):
                continue
            out.append(CheckpointEntry(sha=sha, ts=ts, message=message))
        return out

    # ---- restore -----------------------------------------------------

    def restore(self, sha: str, *, files_only: bool = False) -> dict:
        """Restore the workspace to ``sha``. Returns a stats dict.

        Stats: ``{"files_changed": N, "files_only": bool, "sha": str}``.

        ``files_only=True`` is the inline "view changes" restore — only
        the workspace files revert; the caller's conversation history
        is left alone. ``files_only=False`` is the same git operation
        AT THIS LAYER (file-system reset) plus a signal to the caller
        that they should also rewind conversation messages back to the
        matching turn. The conversation rewind is the caller's job
        because messages aren't owned here.

        Best-effort: returns ``files_changed=0`` on failure rather than
        raising, so an interactive ``/restore`` doesn't crash the REPL.
        """
        if not self.shadow_repo.exists():
            return {"files_changed": 0, "files_only": files_only, "sha": sha}
        env = _git_env(self.shadow_repo, self.project_root)
        try:
            with _disable_nested_dotgits(self.project_root):
                # `git checkout <sha> -- <root>` writes the indexed
                # contents at <sha> into the worktree. We use `--`
                # plus the project root path so git treats the rest
                # as pathspecs (defense against argv injection from a
                # weird sha).
                _run_git(
                    ["checkout", sha, "--", str(self.project_root)],
                    env=env,
                    check=True,
                )
                # Diff between worktree and the previous HEAD to count
                # files that actually changed. We do this AFTER checkout
                # because `git diff --name-only` against the parent of
                # <sha> answers "what does <sha> contain that the
                # previous tip didn't?" — that's the wrong question.
                # The answer we want is "what files are different from
                # what was on disk before restore?", which is best
                # answered by what checkout reported.
                # `git checkout` itself prints a summary on stderr, but
                # parsing that is brittle. Instead we re-walk the index
                # and count entries that match the snapshot but differ
                # from the previous state — but that's also expensive.
                # The pragmatic answer: count files in the snapshot
                # tree (`git ls-tree -r --name-only`) — that's the
                # upper bound and is what users care about ("how many
                # files came back?").
                proc = _run_git(
                    ["ls-tree", "-r", "--name-only", sha],
                    env=env,
                    check=False,
                )
                files_changed = (
                    len(proc.stdout.splitlines()) if proc.returncode == 0 else 0
                )
        except (subprocess.SubprocessError, OSError):
            return {"files_changed": 0, "files_only": files_only, "sha": sha}
        return {
            "files_changed": files_changed,
            "files_only": files_only,
            "sha": sha,
        }


# --- prune ---------------------------------------------------------------


def _is_prune_due() -> bool:
    """True if at least ``_PRUNE_INTERVAL_DAYS`` have elapsed since the marker.

    Missing marker → due (first run). Touch the marker on success so
    the next "due" check happens after the interval. Failures to read
    the marker treat it as "not due" so a permission error doesn't
    cause the prune to run on every session start.
    """
    marker = _last_prune_marker()
    if not marker.exists():
        return True
    try:
        mtime = datetime.fromtimestamp(marker.stat().st_mtime, tz=timezone.utc)
    except OSError:
        return False
    return datetime.now(timezone.utc) - mtime > timedelta(days=_PRUNE_INTERVAL_DAYS)


def _touch_prune_marker() -> None:
    marker = _last_prune_marker()
    try:
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text(str(_now_ms()), encoding="utf-8")
    except OSError:
        pass


def prune_stale(*, force: bool = False) -> list[dict]:
    """Delete shadow repos whose workspace path no longer exists.

    Runs at most once per ``_PRUNE_INTERVAL_DAYS`` unless ``force=True``
    (used by tests). Returns a list of pruned entries with
    ``{"workspace_hash", "age_days"}`` so the caller can fire telemetry.

    Best-effort: any I/O failure is swallowed; the function never raises.
    """
    if not force and not _is_prune_due():
        return []
    pruned: list[dict] = []
    root = _checkpoints_root()
    try:
        entries = list(root.iterdir())
    except OSError:
        return []
    for entry in entries:
        if not entry.name.endswith(".git"):
            continue
        if not entry.is_dir():
            continue
        marker = _workspace_marker_path(entry)
        workspace_path: Path | None = None
        if marker.exists():
            try:
                raw = marker.read_text(encoding="utf-8").strip()
                if raw:
                    workspace_path = Path(raw)
            except OSError:
                workspace_path = None
        # Only prune when we have a marker AND it points to a missing
        # path. Without a marker we can't know the workspace, so leave
        # the repo alone (defensive — the cost of a stale repo is small;
        # the cost of nuking a live one is high).
        if workspace_path is None or workspace_path.exists():
            continue
        # Compute age in days for telemetry. Use the directory mtime as
        # a proxy.
        try:
            mtime = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc)
            age_days = (datetime.now(timezone.utc) - mtime).days
        except OSError:
            age_days = 0
        workspace_hash = entry.name[:-len(".git")]
        try:
            shutil.rmtree(entry, ignore_errors=True)
            try:
                marker.unlink(missing_ok=True)
            except (OSError, AttributeError):
                pass
            pruned.append({
                "workspace_hash": workspace_hash, "age_days": age_days,
            })
        except OSError:
            continue
    _touch_prune_marker()
    return pruned
