"""Streaming renderer using rich.Live.

One Live context per assistant turn. Live exits BEFORE any user prompts
(permission gate) — never prompt while Live is active or you'll get
display corruption. Tool calls and results are printed outside Live.

The renderer is structured around a TurnState dataclass that owns
turn-scoped UI state (reasoning, text, per-call lifecycle). _LiveBuffer
mutates it on streaming events; agent.py drives status transitions
post-stream via tool_status / tool_done.

Headless mode (P2.1): subagents construct `Renderer(headless=True)` so
their iteration loop runs without opening a `rich.Live` region (no
concurrent Live regions vs the parent's renderer) and without printing
tool cards / info / error lines to the parent's console. Captured
strings are buffered on `headless_buffer` for the parent's
`subagent_card` Panel and for power-user `DSC_SHOW_SUBAGENTS=1`
forwarding. Existing renderer behavior is identical when
`headless=False` (the default).

Status line (P3.3): ``Renderer.status_line(...)`` formats a one-line
summary of model / mode / tokens / cost / cache / repo / todos and
``print_status_line(...)`` prints it after each turn finishes. The
line is mutually exclusive with the assistant ``rich.Live`` region —
print AFTER each ``run_turn`` returns, never inside an active Live
context. Honors ``FRED_REDUCED_MOTION=1`` to swap ``console.rule()``
for a plain dim print.
"""
from __future__ import annotations

import os
import time
from collections import deque
from contextlib import contextmanager
from typing import Any, Iterator

from rich.console import Console, Group, RenderableType
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text

from dsc.client import ToolCall
from dsc.result_format import format_result
from dsc.turn_state import CallState, CallStatus, TurnState

_SPIN_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

# Cost preview rates are pulled from rates.get_active_card() so the CLI
# stays in lockstep with FredWeb's pricing.ts via /api/pricing. The
# bundled fallback in dsc/bundled_rates.py covers offline/first-run.
# Numbers used here are *upstream* (what we pay DeepSeek) — that's
# what the existing display has shown historically.


def _glyph_for(s: CallStatus, spin: str) -> tuple[str, str]:
    return {
        CallStatus.QUEUED: ("◯", "grey50"),
        CallStatus.PERMISSION: ("?", "yellow"),
        CallStatus.RUNNING: (spin or "⠋", "cyan"),
        CallStatus.DONE_OK: ("✓", "green"),
        CallStatus.DONE_ERROR: ("✗", "red"),
        CallStatus.DENIED: ("⊘", "red"),
        # P2.2 plan-mode rejection: dim diamond, block reason in body.
        CallStatus.MODE_BLOCKED: ("◊", "grey50"),
    }[s]


# P2.1 subagent glyphs. The renderer uses these in `subagent_card` to
# show in-flight (`↳`) vs completed (`↲`) child sessions in the parent's
# transcript. They sit alongside the per-call CallStatus glyphs but are
# not part of the CallStatus enum because subagents own their own state
# machine (one Panel per child, not per-call lifecycle).
SUBAGENT_GLYPH_FLIGHT = "↳"
SUBAGENT_GLYPH_DONE = "↲"


def _waiting_verb(elapsed: float) -> str:
    if elapsed < 5:
        return "thinking"
    if elapsed < 15:
        return "still thinking"
    return "taking a while"


def _format_tokens(n: int) -> str:
    """Compact token count for inline status lines (e.g. 12345 -> '12k')."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n // 1_000}k"
    return str(n)


class _LiveBuffer:
    """Accepts streaming events and refreshes the Live display.

    Mutates the shared TurnState; reads it back to render frames.
    """

    def __init__(self, live: Live | None, console: Console, state: TurnState) -> None:
        self._live = live
        self._console = console
        self._state = state
        self._frame = 0

    def handle(self, ev_type: str, payload: Any) -> None:
        st = self._state
        if ev_type == "reasoning":
            st.reasoning += payload
            st.waiting_first_token = False
        elif ev_type == "text":
            st.text += payload
            st.waiting_first_token = False
            if st.reasoning and not st.reasoning_done:
                st.reasoning_done = True
                st.reasoning_duration_s = time.perf_counter() - st.started_at
        elif ev_type == "tool_call_start":
            idx = payload["index"]
            st.calls[idx] = CallState(
                index=idx,
                call_id=payload.get("id") or "",
                name=payload["name"],
            )
            st.waiting_first_token = False
        elif ev_type == "tool_call_args_delta":
            idx = payload["index"]
            cs = st.calls.get(idx)
            if cs is not None:
                cs.args_str += payload["chunk"]
        if self._live is not None:
            self._live.update(self._render(), refresh=True)

    def _render(self) -> RenderableType:
        st = self._state
        self._frame = (self._frame + 1) % len(_SPIN_FRAMES)
        spin = _SPIN_FRAMES[self._frame]
        parts: list[RenderableType] = []

        if st.waiting_first_token:
            elapsed = time.perf_counter() - st.started_at
            verb = _waiting_verb(elapsed)
            parts.append(Text(f"  {spin}  {verb}… {elapsed:0.1f}s",
                              style="dim italic"))

        if st.reasoning and st.show_thinking:
            if not st.reasoning_done:
                parts.append(Panel(
                    Text(st.reasoning, style="dim italic"),
                    title="[dim]thinking[/]",
                    title_align="left",
                    border_style="grey50",
                    padding=(0, 1),
                    expand=False,
                ))
            else:
                d = st.reasoning_duration_s or 0.0
                parts.append(Text(f"▶ thought for {d:0.1f}s", style="dim italic"))

        if st.text:
            parts.append(Markdown(st.text))

        for idx in sorted(st.calls):
            parts.append(self._render_call_line(st.calls[idx], spin))

        return Group(*parts) if parts else Text("")

    def _render_call_line(self, c: CallState, spin: str) -> Text:
        glyph, color = _glyph_for(c.status, spin)
        args_preview = c.args_str.strip().replace("\n", " ")
        if len(args_preview) > 60:
            args_preview = args_preview[:60] + "…"
        line = Text()
        line.append(f"  {glyph}  ", style=color)
        line.append(c.name, style=f"bold {color}")
        if args_preview:
            line.append(f"  {args_preview}", style="dim")
        if c.started_at and c.status == CallStatus.RUNNING:
            line.append(f"   {time.perf_counter() - c.started_at:0.1f}s", style="dim")
        elif c.started_at and c.ended_at:
            line.append(f"   {c.ended_at - c.started_at:0.1f}s", style="dim")
        return line

    def render_final(self) -> RenderableType:
        # The stream is finished: any reasoning that wasn't already
        # capped (e.g. when only tool calls follow, no text) should
        # collapse to the one-line summary in the committed frame.
        st = self._state
        if st.reasoning and not st.reasoning_done:
            st.reasoning_done = True
            st.reasoning_duration_s = time.perf_counter() - st.started_at
        return self._render()


class Renderer:
    def __init__(
        self,
        console: Console | None = None,
        stream: bool = True,
        show_thinking: bool = True,
        *,
        headless: bool = False,
    ) -> None:
        self.console = console or Console()
        self.stream = stream
        self.show_thinking = show_thinking
        # P2.1 headless mode: subagents pass `headless=True` so their
        # iteration loop drives `_LiveBuffer` without opening a `rich.Live`
        # region (mutually exclusive with the parent's Live) and without
        # printing tool cards or info/error lines. We still accept
        # streaming events (so tool_calls, reasoning, etc. populate the
        # TurnState the way `run_session` expects), and we still record
        # `recent_results` so `/last` can surface a subagent's outputs.
        self.headless = headless
        # Captured stand-in for stdout when headless. The parent's
        # `subagent_card` Panel reads this for the dim-bordered body
        # and `DSC_SHOW_SUBAGENTS=1` forwards it to stderr verbatim.
        self.headless_buffer: list[str] = []
        self._turn: TurnState | None = None
        self.last_reasoning: str | None = None
        self.recent_results: deque[tuple[str, str]] = deque(maxlen=10)

        # Session-cumulative usage counters (consumed by /cost).
        self.session_in = 0
        self.session_out = 0
        self.session_cached = 0
        self.session_cost = 0.0
        self.session_turns = 0

    @contextmanager
    def assistant_turn(
        self,
        *,
        iteration: int = 0,
        max_iters: int = 50,
    ) -> Iterator[_LiveBuffer]:
        self._turn = TurnState(
            iteration=iteration,
            max_iters=max_iters,
            show_thinking=self.show_thinking,
        )
        if self.headless:
            # No Live region; the parent's renderer owns the only Live in
            # the process. We still drive `_LiveBuffer` so streaming events
            # update the TurnState normally — the parent will read assembled
            # text out of `_turn` after the subagent completes.
            buf = _LiveBuffer(None, self.console, self._turn)
            yield buf
        elif self.stream:
            with Live(
                Text(""),
                console=self.console,
                refresh_per_second=20,
                transient=False,
                vertical_overflow="visible",
            ) as live:
                buf = _LiveBuffer(live, self.console, self._turn)
                yield buf
                live.update(buf.render_final(), refresh=True)
        else:
            buf = _LiveBuffer(None, self.console, self._turn)
            yield buf
            self.console.print(buf.render_final())
        self.last_reasoning = self._turn.reasoning or None

    # --- tool lifecycle (called from agent.py during dispatch) ---

    def find_call(self, openai_call_id: str) -> CallState | None:
        if self._turn is None:
            return None
        for cs in self._turn.calls.values():
            if cs.call_id == openai_call_id:
                return cs
        return None

    def tool_status(
        self,
        cs: CallState | None,
        status: CallStatus,
        *,
        lines: int | None = None,
    ) -> None:
        if cs is None:
            return
        cs.status = status
        if status == CallStatus.RUNNING and cs.started_at is None:
            cs.started_at = time.perf_counter()
        if lines is not None:
            cs.lines = lines

    def tool_done(
        self,
        cs: CallState | None,
        status: CallStatus,
        tc: ToolCall,
        result: str,
        *,
        checkpoint_sha: str | None = None,
    ) -> None:
        if cs is None:
            # Defensive: if streaming missed the call (shouldn't happen, but
            # don't crash) synthesize one so the user still sees the result.
            cs = CallState(index=-1, call_id=tc.id, name=tc.name)
        cs.status = status
        if cs.started_at is None:
            cs.started_at = time.perf_counter()
        cs.ended_at = time.perf_counter()
        cs.summary, cs.result_preview = format_result(tc.name, tc.arguments, result)
        cs.result_full = result
        # P4.3: stash the checkpoint SHA so `_render_tool_card` can emit
        # the dim ``↶ checkpoint <sha>`` line right after the result
        # Panel. ``None`` means "no checkpoint for this call" (read-only
        # tool, denied, debounced, or feature disabled) — the marker
        # is suppressed in that case.
        cs.checkpoint_sha = checkpoint_sha
        # P2.1: the `agent` tool already rendered a `subagent_card` Panel
        # from inside its handler; skip the generic tool-result panel for
        # it to avoid double-printing. Lifecycle bookkeeping (the
        # CallState mutations above) still happens so the parent's
        # in-frame glyph table reflects "subagent done."
        if tc.name == "agent":
            return
        self._render_tool_card(cs)

    def _render_tool_card(self, c: CallState) -> None:
        glyph, color = _glyph_for(c.status, "")
        elapsed = (
            (c.ended_at - c.started_at)
            if (c.started_at is not None and c.ended_at is not None)
            else 0.0
        )
        title = (
            f"[{color}]{glyph}[/] [bold]{c.name}[/] · "
            f"{c.summary} · [dim]{elapsed:0.1f}s[/]"
        )
        body = c.result_preview if c.result_preview else "(empty)"
        # Always record the result for /last and for the parent's
        # subagent_card body — but in headless mode we suppress the
        # Panel print so the parent's transcript stays clean.
        if not self.headless:
            self.console.print(Panel(
                body,
                title=title,
                title_align="left",
                border_style=color,
                padding=(0, 1),
                expand=False,
            ))
            # P4.3: inline checkpoint marker. Single dim line beneath the
            # result Panel; lets the user `/restore <sha>` later. Skipped
            # for headless renderers (subagent transcripts stay clean).
            if c.checkpoint_sha:
                short = c.checkpoint_sha[:7]
                self.console.print(
                    f"[dim]  ↶ checkpoint {short}[/]", highlight=False,
                )
        else:
            self.headless_buffer.append(f"{title}\n{body}")
        self.recent_results.append((title, c.result_full))

    # --- usage / cost ---

    def show_usage(self, usage: dict | None, model: str) -> None:
        if not usage:
            return
        from dsc.rates import get_active_card

        in_tok = usage.get("prompt_tokens", 0) or 0
        out_tok = usage.get("completion_tokens", 0) or 0
        # DeepSeek docs as of 2026-05 use sibling fields. Older nested
        # path is preserved here for compatibility with telemetry rows
        # captured before the worker started writing the new format.
        cached = (
            usage.get("prompt_cache_hit_tokens")
            or (usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0)
            or 0
        )
        non_cached = max(0, in_tok - cached)
        card = get_active_card(model)
        # bundled_rates / rate-card cache stores microcents/1M; divide
        # by 1_000_000 once for the per-token rate, then again to fold
        # microcents into dollars: (tokens * microcents_per_1M) / 1e12.
        cost = (
            non_cached * card.upstream.input_uncached
            + cached * card.upstream.input_cached
            + out_tok * card.upstream.output
        ) / 1_000_000_000_000
        self.session_in += in_tok
        self.session_out += out_tok
        self.session_cached += cached
        self.session_cost += cost
        self.session_turns += 1
        if self.headless:
            # Subagent: keep the cumulative token counters above (the
            # parent reads them off the child renderer to build the
            # subagent_card summary) but skip the per-iteration print.
            return
        self.console.print(
            f"[dim]  · {model}  in={in_tok} (cached={cached})  "
            f"out={out_tok}  ${cost:.5f}[/]",
            highlight=False,
        )
        # Promote cache health: when >50% of input tokens hit, surface the
        # ratio on its own dim line so the user can see the bill drop in
        # real time. K-formatting keeps the line short on big prompts.
        if in_tok > 0 and cached / in_tok > 0.5:
            pct = int(round(100 * cached / in_tok))
            self.console.print(
                f"[dim]  · cached {_format_tokens(cached)}/{_format_tokens(in_tok)} "
                f"({pct}%)[/]",
                highlight=False,
            )

    def cost_summary(self) -> str:
        lines = [
            f"Session totals across {self.session_turns} iteration(s):",
            f"  input tokens   : {self.session_in:,}  ({self.session_cached:,} cached)",
            f"  output tokens  : {self.session_out:,}",
            f"  estimated cost : ${self.session_cost:.4f}",
        ]
        if self.session_cached > 0 and self.session_in > 0:
            pct = 100.0 * self.session_cached / self.session_in
            lines.append(
                f"  cache hit rate : {pct:.1f}% "
                f"({self.session_cached:,} cached / {self.session_in:,} input)"
            )
        return "\n".join(lines)

    # --- todos ---

    def show_todos(self) -> None:
        # Lazy import keeps render.py free of tool-specific deps.
        from dsc.tools.todo import get_todos
        if self.headless:
            return
        todos = get_todos()
        if not todos:
            return
        glyph = {
            "pending": "[dim]☐[/]",
            "in_progress": "[yellow]◐[/]",
            "completed": "[green]☑[/]",
        }
        line_style = {
            "pending": "",
            "in_progress": "bold",
            "completed": "dim strike",
        }
        self.console.print()
        self.console.print("[bold]Todos[/]")
        for t in todos:
            text = t.content.replace("[", r"\[")
            style = line_style.get(t.status, "")
            self.console.print(f"  {glyph[t.status]}  [{style}]{text}[/]"
                               if style else f"  {glyph[t.status]}  {text}")
        self.console.print()

    # --- subagents (P2.1) ---

    def subagent_card(
        self,
        *,
        agent_type: str,
        iterations: int,
        elapsed_s: float,
        total_tokens: int,
        summary: str,
        outcome: str = "ok",
    ) -> None:
        """Render the parent-side Panel summarizing one completed subagent.

        Mirrors Claude Code's `↳ explore agent · 3 iter · 0.4s · 1.2k tokens`
        title with the final summary in dim borders. Always rendered to the
        parent's console (this method is called from the parent's renderer,
        never the child's). The full summary is appended to `recent_results`
        so `/last` works on it.

        `outcome` is "ok" / "iter_cap" / "error"; controls the glyph and
        border color (red on error, dim grey otherwise).
        """
        glyph = SUBAGENT_GLYPH_DONE
        color = "grey50" if outcome == "ok" else "yellow" if outcome == "iter_cap" else "red"
        title = (
            f"[{color}]{glyph}[/] [bold]{agent_type} agent[/] · "
            f"{iterations} iter · [dim]{elapsed_s:0.1f}s[/] · "
            f"[dim]{_format_tokens(total_tokens)} tokens[/]"
        )
        body = summary or "[dim](no summary returned)[/]"
        self.console.print(Panel(
            body,
            title=title,
            title_align="left",
            border_style=color,
            padding=(0, 1),
            expand=False,
        ))
        self.recent_results.append((title, summary))

    # --- misc ---

    def info(self, msg: str) -> None:
        if self.headless:
            self.headless_buffer.append(msg)
            return
        self.console.print(f"[dim]{msg}[/]")

    def error(self, msg: str) -> None:
        if self.headless:
            self.headless_buffer.append(f"ERROR: {msg}")
            return
        self.console.print(f"[red]{msg}[/]")

    def compaction_notification(
        self, before_tokens: int, after_tokens: int, focus: str | None,
    ) -> None:
        """Emit a single dim line confirming a compaction pass landed.

        Called both from the auto-trigger inside `run_session` and from
        the `/compact` slash branch in `cli.py`. Format mirrors the
        spec in P2.5: `compacted N messages -> M tokens (focus: …)`.
        We print just one line so the user notices the savings without
        the surrounding agent-turn UI shifting under them.

        `before_tokens` and `after_tokens` come from `compact_messages`'s
        stats dict; the formatter here doesn't know how many MESSAGES
        collapsed into the summary because that detail isn't part of the
        stats contract — instead we surface the meaningful number
        (tokens before/after) so the user sees the actual context save.
        """
        focus_label = focus.strip() if (focus and focus.strip()) else "general"
        self.console.print(
            f"[dim]compacted {_format_tokens(before_tokens)} -> "
            f"{_format_tokens(after_tokens)} tokens (focus: {focus_label})[/]"
        )

    # --- status line (P3.3) ---

    def status_line(
        self,
        *,
        model_cfg: Any = None,
        mode: str | None = None,
        used_tokens: int | None = None,
        total_tokens: int | None = None,
        cost: float | None = None,
        cache_hit_rate: float | None = None,
        repo_map_size: int | None = None,
        todos_active: tuple[int, int] | None = None,
    ) -> str:
        """Format the bottom-of-turn status line.

        Returns the rendered line as a plain string (no Rich markup).
        Fields are joined with `" · "` separators; missing fields are
        skipped so the line stays compact when stats aren't available.

        Format (when all fields populated):
            ``model · mode · used/total (X% cached) · $cost · repo: N files · todos: A/B in progress``

        - ``model_cfg`` may be a ``ModelConfig`` (we read ``main_model``)
          or a plain string. ``None`` omits the field.
        - ``cache_hit_rate`` is a 0..1 float; rendered as an integer
          percentage and only included when ``used_tokens`` is also set
          (so the cache figure has a denominator to attach to).
        - ``todos_active`` is ``(in_progress_count, total_count)``; only
          rendered when ``total_count > 0``.
        - The function is pure — no I/O, no rich calls. Use
          ``print_status_line`` to actually emit it.
        """
        parts: list[str] = []
        if model_cfg is not None:
            # Accept either a ModelConfig (preferred) or a bare model
            # name. Don't reach into rich/typer types — duck-type on
            # ``main_model`` so a fake from a unit test works.
            name = getattr(model_cfg, "main_model", None) or str(model_cfg)
            parts.append(name)
        if mode:
            parts.append(mode)
        if used_tokens is not None and total_tokens is not None and total_tokens > 0:
            seg = f"{_format_tokens(used_tokens)}/{_format_tokens(total_tokens)}"
            if cache_hit_rate is not None:
                pct = int(round(100 * max(0.0, min(1.0, cache_hit_rate))))
                seg += f" ({pct}% cached)"
            parts.append(seg)
        elif used_tokens is not None:
            seg = _format_tokens(used_tokens)
            if cache_hit_rate is not None:
                pct = int(round(100 * max(0.0, min(1.0, cache_hit_rate))))
                seg += f" ({pct}% cached)"
            parts.append(seg)
        if cost is not None:
            parts.append(f"${cost:.4f}" if cost < 0.01 else f"${cost:.2f}")
        if repo_map_size is not None and repo_map_size > 0:
            parts.append(f"repo: {repo_map_size} files")
        if todos_active is not None:
            in_progress, total = todos_active
            if total > 0:
                parts.append(f"todos: {in_progress}/{total} in progress")
        return " · ".join(parts)

    def print_status_line(
        self,
        *,
        model_cfg: Any = None,
        mode: str | None = None,
        used_tokens: int | None = None,
        total_tokens: int | None = None,
        cost: float | None = None,
        cache_hit_rate: float | None = None,
        repo_map_size: int | None = None,
        todos_active: tuple[int, int] | None = None,
    ) -> str:
        """Render the status line and print it to the console.

        This is the cli.py-facing entry point. Called AFTER each
        ``run_turn`` returns (never inside the assistant Live region —
        the two are mutually exclusive). Returns the rendered string so
        the caller can also feed it to telemetry without re-formatting.

        Reduced-motion behavior (``FRED_REDUCED_MOTION=1``): swaps
        ``console.rule()`` for a plain dim print on its own line. Both
        paths emit the same content; only the visual treatment differs.
        Headless renderers (subagents) skip output entirely so the
        parent's transcript stays clean — but we still return the
        formatted string for tracer payloads.
        """
        line = self.status_line(
            model_cfg=model_cfg,
            mode=mode,
            used_tokens=used_tokens,
            total_tokens=total_tokens,
            cost=cost,
            cache_hit_rate=cache_hit_rate,
            repo_map_size=repo_map_size,
            todos_active=todos_active,
        )
        if not line:
            return line
        if self.headless:
            return line
        if os.environ.get("FRED_REDUCED_MOTION") == "1":
            # Plain dim print — no horizontal rule, no spinner motion.
            # Mirrors the user's accessibility opt-out from the rich
            # animations that the rule line implies.
            self.console.print(f"[dim]{line}[/]", highlight=False)
        else:
            # `console.rule` writes a horizontal divider with the title
            # text inline, which gives a clear visual anchor for the
            # end-of-turn boundary without a second Live region.
            self.console.rule(f"[dim]{line}[/]", style="dim", align="left")
        return line
