"""Runtime rate-card cache.

Loads the most recent rate card published by FredWeb's /api/pricing
endpoint. The cache file lives at ~/.config/fred/rate-card.json. When
absent or stale, callers fall back to the wheel-bundled defaults in
``bundled_rates``.

This module is read-only at the moment — refresh logic (fetch on
``fred login`` and on a ``/pricing-refresh`` slash command) is wired
in a follow-up PR. The shape of the cache matches FredWeb's
publicRateCards() output exactly so the refresh path is a one-line
``json.dump(response.json(), …)``.
"""
from __future__ import annotations

import json
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from dsc.bundled_rates import BUNDLED_CARDS, BundledCard, Rates, get_bundled_card

DEFAULT_RATE_CARD_PATH = Path.home() / ".config" / "fred" / "rate-card.json"
STALE_THRESHOLD_S = 7 * 24 * 60 * 60  # 7 days


@dataclass(frozen=True)
class CachedCard:
    """Customer-facing rate card from /api/pricing."""

    model: str
    upstream: Rates
    billed: Rates


def _rates_from_dict(d: dict[str, Any]) -> Rates:
    """FredWeb's `Rates` shape uses camelCase. Bundle in snake_case."""
    return Rates(
        input_uncached=int(d["inputUncached"]),
        input_cached=int(d["inputCached"]),
        output=int(d["output"]),
    )


def _load_cache_file(path: Path) -> tuple[list[CachedCard], float] | None:
    """Return (cards, fetched_at_epoch) or None if absent/malformed."""
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"fred: could not read rate-card cache: {e}", file=sys.stderr)
        return None
    try:
        models = raw.get("models", [])
        cards: list[CachedCard] = []
        for m in models:
            # Skip retired cards — they're public_rate_cards entries with
            # an effectiveTo set; the active cards are what users care about.
            if m.get("effectiveTo") is not None:
                continue
            cards.append(
                CachedCard(
                    model=m["model"],
                    upstream=_rates_from_dict(m["upstream"]),
                    billed=_rates_from_dict(m["billed"]),
                )
            )
        fetched_at = float(raw.get("fetched_at", 0))
        return cards, fetched_at
    except (KeyError, TypeError, ValueError) as e:
        print(f"fred: malformed rate-card cache: {e}", file=sys.stderr)
        return None


def get_active_card(model: str, path: Path | None = None) -> CachedCard | BundledCard:
    """Return the active card for ``model``. Cache wins over bundled
    fallback. If neither has the model, returns the bundled flash card
    so display code never crashes — the pricing math itself is enforced
    server-side, this is for cost preview only.
    """
    cache = _load_cache_file(path or DEFAULT_RATE_CARD_PATH)
    if cache is not None:
        for c in cache[0]:
            if c.model == model:
                return c
    bundled = get_bundled_card(model)
    if bundled is not None:
        return bundled
    # Last-ditch fallback — keep render code happy.
    return BUNDLED_CARDS[0]


def known_models(path: Path | None = None) -> tuple[str, ...]:
    """Models known to either the cache or the bundled fallback."""
    seen: list[str] = []
    cache = _load_cache_file(path or DEFAULT_RATE_CARD_PATH)
    if cache is not None:
        for c in cache[0]:
            if c.model not in seen:
                seen.append(c.model)
    for c in BUNDLED_CARDS:
        if c.model not in seen:
            seen.append(c.model)
    return tuple(seen)


def cache_age_seconds(path: Path | None = None) -> float | None:
    """Return seconds since the cache was fetched, or None if no cache.
    Used by the CLI to surface a "stale rate card" notice on startup.
    """
    cache = _load_cache_file(path or DEFAULT_RATE_CARD_PATH)
    if cache is None:
        return None
    fetched_at = cache[1]
    if fetched_at <= 0:
        return None
    return max(0.0, time.time() - fetched_at)


def is_stale(path: Path | None = None) -> bool:
    age = cache_age_seconds(path)
    if age is None:
        return False  # missing cache is "no opinion" — let bundled handle it
    return age > STALE_THRESHOLD_S
