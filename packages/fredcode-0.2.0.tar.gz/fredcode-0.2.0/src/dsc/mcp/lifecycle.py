"""MCP server session lifecycle (P4.2).

Spawns all configured servers in parallel at session start (so a slow
server doesn't block faster ones), registers their tools with the dsc
``Registry``, and cleans up on session shutdown via the ``Stop`` hook
seam.

The public surface here is what cli.py consumes. ``connect_servers``
returns an ``MCPSession`` aggregate that owns the live clients +
adapters; ``register_mcp_tools`` then mounts the tools onto a registry
(typically ``default_registry()`` after the built-ins are registered);
``cleanup_servers`` SIGTERMs every process. None of these calls raise
out — every failure path degrades to a structured info line and a
crashed-but-cleanly-skipped tool registration.
"""
from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Callable

from dsc.mcp.client import MCPClient, MCPClientError
from dsc.mcp.config import MCPServerConfig
from dsc.mcp.registry import MCPToolAdapter, schemas_eager
from dsc.tools.registry import Registry


# Per-server status used by /mcp printing and telemetry. The vocabulary
# is small so dashboards can group cleanly.
STATUS_CONNECTED = "connected"
STATUS_DISCONNECTED = "disconnected"
STATUS_CRASHED = "crashed"


@dataclass
class MCPServerEntry:
    """Live state for one configured MCP server."""

    config: MCPServerConfig
    client: MCPClient | None = None
    adapters: list[MCPToolAdapter] = field(default_factory=list)
    status: str = STATUS_DISCONNECTED
    error: str | None = None
    init_ms: int = 0
    stderr_tail: list[str] = field(default_factory=list)


@dataclass
class MCPSession:
    """The aggregate of all servers connected for a dsc session."""

    entries: list[MCPServerEntry] = field(default_factory=list)
    # Lock so cleanup + crash-detection don't race against /mcp printing.
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def connected_entries(self) -> list[MCPServerEntry]:
        with self._lock:
            return [e for e in self.entries if e.status == STATUS_CONNECTED]

    def all_adapters(self) -> list[MCPToolAdapter]:
        out: list[MCPToolAdapter] = []
        with self._lock:
            for entry in self.entries:
                if entry.status != STATUS_CONNECTED:
                    continue
                out.extend(entry.adapters)
        return out

    def update_crash_states(self) -> None:
        """Walk the live clients and demote any newly-crashed ones."""
        with self._lock:
            for entry in self.entries:
                if entry.status == STATUS_CONNECTED and entry.client is not None:
                    if entry.client.is_crashed:
                        entry.status = STATUS_CRASHED
                        entry.error = entry.client.crash_reason or "client crashed"

    def find_entry(self, server_name: str) -> MCPServerEntry | None:
        with self._lock:
            for entry in self.entries:
                if entry.config.name == server_name:
                    return entry
        return None


# ---------------------------------------------------------------------------
# Connect
# ---------------------------------------------------------------------------


def connect_servers(
    configs: list[MCPServerConfig],
    *,
    on_event: Callable[[str, dict], None] | None = None,
    on_info: Callable[[str], None] | None = None,
) -> MCPSession:
    """Spawn all configured MCP servers in parallel.

    Returns an :class:`MCPSession` whose ``entries`` mirrors ``configs``;
    each entry's ``status`` reflects whether spawning + initialize +
    tools/list succeeded. A failed server stays in the session as a
    ``crashed`` entry so ``/mcp`` printing shows the failure without
    further investigation.

    ``on_event(kind, payload)`` is the telemetry hook; the lifecycle
    layer fires:

      - ``mcp_server_connect`` ``{name, transport, tool_count, init_ms}``
      - ``mcp_server_disconnect`` ``{name, reason, was_unexpected}``
        (fired when ``cleanup_servers`` runs)
      - ``mcp_server_crashed`` ``{name, error, init_ms}`` (fired on a
        startup failure that prevented the connect event)

    ``on_info(message)`` is a user-visible info hook (e.g. wired to
    ``Renderer.info``); we print one line per healthy server and one
    line per failure.
    """
    session = MCPSession()
    if not configs:
        return session
    entries: list[MCPServerEntry] = [MCPServerEntry(config=cfg) for cfg in configs]
    session.entries = entries

    # ThreadPoolExecutor is the simplest "fire all in parallel" shape;
    # MCP servers are I/O bound (subprocess spawn + a couple stdio
    # round-trips). Cap workers at min(8, len(entries)) — bigger pools
    # don't help and just churn threads.
    max_workers = max(1, min(8, len(entries)))
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        future_to_entry = {
            pool.submit(_start_one, entry): entry for entry in entries
        }
        for fut in as_completed(future_to_entry):
            entry = future_to_entry[fut]
            try:
                fut.result()
            except Exception as e:
                # Should be unreachable — _start_one swallows. Defensive.
                entry.status = STATUS_CRASHED
                entry.error = f"{type(e).__name__}: {e}"

    # Emit telemetry + info lines after all spawns settle so the user
    # sees them in a contiguous block rather than interleaved with each
    # server's spawn timing.
    for entry in entries:
        if entry.status == STATUS_CONNECTED and entry.client is not None:
            tool_count = len(entry.client.tools)
            if on_event is not None:
                try:
                    on_event("mcp_server_connect", {
                        "name": entry.config.name,
                        "transport": entry.config.transport,
                        "tool_count": tool_count,
                        "init_ms": entry.init_ms,
                    })
                except Exception:
                    pass
            if on_info is not None:
                try:
                    on_info(
                        f"mcp: connected {entry.config.name} "
                        f"({tool_count} tool{'s' if tool_count != 1 else ''}, "
                        f"{entry.init_ms}ms)"
                    )
                except Exception:
                    pass
        else:
            if on_event is not None:
                try:
                    on_event("mcp_server_crashed", {
                        "name": entry.config.name,
                        "error": entry.error,
                        "init_ms": entry.init_ms,
                    })
                except Exception:
                    pass
            if on_info is not None:
                try:
                    on_info(
                        f"mcp: failed to start {entry.config.name}: "
                        f"{entry.error or 'unknown'}"
                    )
                except Exception:
                    pass
    return session


def _start_one(entry: MCPServerEntry) -> None:
    """Worker fn for the connect-pool. Never raises."""
    cfg = entry.config
    t0 = time.perf_counter()
    client = MCPClient(cfg)
    try:
        client.start()
    except MCPClientError as e:
        entry.client = client
        entry.status = STATUS_CRASHED
        entry.error = str(e)
        entry.init_ms = int((time.perf_counter() - t0) * 1000)
        entry.stderr_tail = client.stderr_tail()
        # Best effort: tear down the (possibly-spawned) subprocess so
        # we don't leak it.
        try:
            client.shutdown()
        except Exception:
            pass
        return
    except Exception as e:
        entry.client = client
        entry.status = STATUS_CRASHED
        entry.error = f"{type(e).__name__}: {e}"
        entry.init_ms = int((time.perf_counter() - t0) * 1000)
        entry.stderr_tail = client.stderr_tail()
        try:
            client.shutdown()
        except Exception:
            pass
        return
    entry.client = client
    entry.init_ms = int((time.perf_counter() - t0) * 1000)
    entry.adapters = [
        MCPToolAdapter(client, cfg.name, td) for td in client.tools
    ]
    entry.status = STATUS_CONNECTED


# ---------------------------------------------------------------------------
# Register tools onto a Registry
# ---------------------------------------------------------------------------


def register_mcp_tools(
    registry: Registry,
    session: MCPSession,
    *,
    on_event: Callable[[str, dict], None] | None = None,
) -> int:
    """Mount every connected server's tools onto ``registry``.

    Returns the number of MCP tools registered (zero is the no-op path).
    Each adapter's telemetry callback is wired to fire
    ``mcp_tool_call`` events via ``on_event``.

    Idempotent w.r.t. the registry: a duplicate name (same server +
    tool registered twice) raises just like the built-in tools, so a
    settings file with two servers exposing the same tool name will
    surface a clear ``ValueError`` at session start. We DO NOT register
    tools from CRASHED entries — the adapter would just return an
    error on every call, which is worse than not exposing the name at
    all.
    """
    eager = schemas_eager()
    count = 0

    def _telemetry_cb_for(server_name: str) -> Callable[[dict], None] | None:
        if on_event is None:
            return None

        def cb(payload: dict) -> None:
            try:
                # Stamp the event kind so callers can route easily;
                # other fields come from the adapter handler.
                on_event("mcp_tool_call", payload)
            except Exception:
                pass
        return cb

    for entry in session.entries:
        if entry.status != STATUS_CONNECTED:
            continue
        for adapter in entry.adapters:
            tool = adapter.to_tool(eager=eager)
            try:
                registry.register(tool)
            except ValueError:
                # Duplicate name. Skip silently and continue — the user
                # sees the conflict via /mcp output if they care.
                continue
            adapter.set_telemetry_callback(_telemetry_cb_for(entry.config.name))
            count += 1
    return count


# ---------------------------------------------------------------------------
# Shutdown
# ---------------------------------------------------------------------------


def cleanup_servers(
    session: MCPSession,
    *,
    on_event: Callable[[str, dict], None] | None = None,
    grace_sec: float = 2.0,
) -> None:
    """SIGTERM every connected server, escalating to SIGKILL after grace.

    Idempotent. A second invocation is a no-op (clients have already
    been shut down). Wired to the P2.4 ``Stop`` hook seam in cli.py.
    """
    if session is None:
        return
    for entry in session.entries:
        client = entry.client
        if client is None:
            continue
        was_unexpected = entry.status == STATUS_CRASHED
        reason = "stop" if not was_unexpected else (
            entry.error or "crashed"
        )
        try:
            client.shutdown(grace_sec=grace_sec)
        except Exception:
            pass
        if entry.status == STATUS_CONNECTED:
            entry.status = STATUS_DISCONNECTED
        if on_event is not None:
            try:
                on_event("mcp_server_disconnect", {
                    "name": entry.config.name,
                    "reason": reason,
                    "was_unexpected": bool(was_unexpected),
                })
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Reporting (used by /mcp slash)
# ---------------------------------------------------------------------------


def summarize_servers(session: MCPSession) -> list[dict]:
    """Compact rows for the ``/mcp`` slash command output.

    Each row::

        {
          "name": str,
          "status": "connected" | "disconnected" | "crashed",
          "transport": str,
          "tool_count": int,
          "tools": [str, ...],   # short names (without mcp__ prefix)
          "error": str | None,
          "init_ms": int,
        }
    """
    if session is None:
        return []
    # Refresh crash states so /mcp output reflects current reality.
    session.update_crash_states()
    out: list[dict] = []
    with session._lock:
        for entry in session.entries:
            tools_short = [a.tool_name for a in entry.adapters]
            out.append({
                "name": entry.config.name,
                "status": entry.status,
                "transport": entry.config.transport,
                "tool_count": len(tools_short),
                "tools": tools_short,
                "error": entry.error,
                "init_ms": entry.init_ms,
            })
    return out
