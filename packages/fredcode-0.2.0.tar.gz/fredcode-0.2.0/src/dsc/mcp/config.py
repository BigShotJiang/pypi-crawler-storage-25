"""MCP server config loaded from ``.dsc/settings.json`` (P4.2).

Schema (additive — sits next to ``hooks`` and ``permissions``)::

    {
      "mcp": [
        {
          "name": "github",
          "type": "stdio",
          "command": "node",
          "args": ["/path/to/github-mcp.js"],
          "env": {"GITHUB_TOKEN": "$GITHUB_TOKEN"},
          "cwd": "/path/to/start/dir",
          "init_timeout": 10
        }
      ]
    }

Resolution
~~~~~~~~~~

Walks ``.dsc/settings.json`` up from cwd to a git boundary or ``$HOME``
(mirrors hooks / permissions resolution exactly), merges by overriding
the ``mcp`` array WHOLE per file (later layers replace earlier ones — a
project ``mcp`` array supersedes the user-level one). This matches how
``hooks`` does override semantics and keeps the user's mental model
consistent.

``$VAR`` substitution in the ``env`` map references the parent's
environment at config-load time; missing variables resolve to the empty
string (a deliberately quiet fallback so ``$GITHUB_TOKEN`` not being set
yet doesn't crash session startup).

Only ``stdio`` is supported in v1. Other transports (HTTP, WebSocket)
are out of scope per the plan.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

# Reuse hooks' walk/read primitives so the three settings layers (hooks,
# permissions, MCP) all anchor on the same project / user files. The
# wider walk in `permissions.py` includes a separate `settings.local.json`
# layer for "always allow" picks; MCP only needs the project + user
# layers since spawning a server is not a per-Panel decision.
from dsc.hooks import _read_settings, _walk_up_for_settings

# Default subprocess init timeout: how long we wait for ``initialize`` +
# ``tools/list`` to complete before declaring the server unhealthy. The
# user can raise this per server via the ``init_timeout`` field; we cap
# below at ``_MAX_INIT_TIMEOUT_SEC`` so a pathological config can't hang
# session startup forever.
_DEFAULT_INIT_TIMEOUT_SEC = 10
_MAX_INIT_TIMEOUT_SEC = 120

# `$VAR` substitution for env values — matches POSIX shell variable refs.
# `$$` is *not* an escape; users wanting a literal `$` should write `$$`
# in their config, but we don't actively interpret it (the regex below
# matches `$NAME` only and leaves unmatched `$` untouched).
_ENV_REF_RE = re.compile(r"\$([A-Za-z_][A-Za-z0-9_]*)")


@dataclass(frozen=True)
class MCPServerConfig:
    """A single configured MCP server entry.

    Frozen so configs can hash/compare cleanly in the lifecycle code
    (e.g. detecting duplicate names across layers).
    """

    name: str
    transport: str  # "stdio" — only supported value in v1
    command: str
    args: tuple[str, ...] = field(default_factory=tuple)
    env: dict[str, str] = field(default_factory=dict)
    cwd: str | None = None
    init_timeout: int = _DEFAULT_INIT_TIMEOUT_SEC

    def effective_init_timeout(self) -> int:
        if self.init_timeout <= 0:
            return _DEFAULT_INIT_TIMEOUT_SEC
        return min(self.init_timeout, _MAX_INIT_TIMEOUT_SEC)

    def resolve_env(self) -> dict[str, str]:
        """Materialize the ``env`` map by expanding ``$VAR`` references.

        Missing variables resolve to the empty string. The parent's
        environment is consulted via ``os.environ`` at call time so a
        subsequent ``os.environ`` mutation (e.g. test harness pokes a
        var) is respected on the NEXT spawn, not the first.
        """
        out: dict[str, str] = {}
        for key, raw in self.env.items():
            if not isinstance(raw, str):
                out[key] = ""
                continue
            out[key] = _ENV_REF_RE.sub(
                lambda m: os.environ.get(m.group(1), ""), raw,
            )
        return out


def _parse_one(entry: object) -> MCPServerConfig | None:
    """Validate one server entry. Tolerant: returns None on bad input.

    Required fields: ``name`` (non-empty str), ``command`` (non-empty
    str). Missing transport defaults to ``stdio``. Anything other than
    ``stdio`` is dropped silently — we don't have a transport for it
    yet, so spawning would just crash.
    """
    if not isinstance(entry, dict):
        return None
    name = entry.get("name")
    if not isinstance(name, str) or not name.strip():
        return None
    transport = entry.get("type", "stdio")
    if not isinstance(transport, str) or transport != "stdio":
        return None
    command = entry.get("command")
    if not isinstance(command, str) or not command.strip():
        return None
    raw_args = entry.get("args") or []
    if not isinstance(raw_args, list):
        return None
    args: list[str] = []
    for a in raw_args:
        if isinstance(a, (str, int, float)):
            args.append(str(a))
    raw_env = entry.get("env") or {}
    env: dict[str, str] = {}
    if isinstance(raw_env, dict):
        for k, v in raw_env.items():
            if isinstance(k, str) and isinstance(v, str):
                env[k] = v
    cwd = entry.get("cwd")
    if cwd is not None and not isinstance(cwd, str):
        cwd = None
    init_timeout = entry.get("init_timeout", _DEFAULT_INIT_TIMEOUT_SEC)
    if not isinstance(init_timeout, int) or init_timeout <= 0:
        init_timeout = _DEFAULT_INIT_TIMEOUT_SEC
    return MCPServerConfig(
        name=name.strip(),
        transport=transport,
        command=command,
        args=tuple(args),
        env=env,
        cwd=cwd,
        init_timeout=init_timeout,
    )


def parse_mcp_servers(settings: dict) -> list[MCPServerConfig]:
    """Pull a list of ``MCPServerConfig`` out of one parsed settings dict.

    Tolerant: malformed entries are skipped, duplicate names within the
    same file keep the FIRST entry (matches how `hooks` does it within
    a single file's array).
    """
    raw = settings.get("mcp") if isinstance(settings, dict) else None
    if not isinstance(raw, list):
        return []
    out: list[MCPServerConfig] = []
    seen: set[str] = set()
    for entry in raw:
        cfg = _parse_one(entry)
        if cfg is None:
            continue
        if cfg.name in seen:
            continue
        seen.add(cfg.name)
        out.append(cfg)
    return out


def load_mcp_config(start: Path | None = None) -> list[MCPServerConfig]:
    """Load + merge MCP server configs across the standard settings stack.

    Resolution order (later wins; layers REPLACE the ``mcp`` array
    rather than concatenating, matching `hooks` semantics):

      1. ``~/.dsc/settings.json`` (user-level, optional)
      2. Project ``.dsc/settings.json`` walked from `start` upward; the
         file CLOSEST to `start` overrides farther ancestors.

    A layer with no ``mcp`` key leaves the lower layer's array intact.
    Returning an empty list disables the feature for the session.
    """
    start = start or Path.cwd()
    sources: list[Path] = []
    user_settings = Path.home() / ".dsc" / "settings.json"
    if user_settings.exists():
        sources.append(user_settings)
    # Walking returns nearest-first; we want farthest-first so the
    # closest one is applied last and therefore wins.
    project_paths = list(reversed(_walk_up_for_settings(start)))
    sources.extend(project_paths)

    merged: list[MCPServerConfig] = []
    for path in sources:
        data = _read_settings(path)
        # Only override when the layer mentions `mcp` at all. A layer
        # silent on `mcp` leaves the lower layer's array intact (matches
        # the "implicit none = inherit" rule used by `hooks`).
        if not isinstance(data, dict) or "mcp" not in data:
            continue
        merged = parse_mcp_servers(data)
    # Deduplicate by name across ALL layers as a final guard. The merge
    # rule above keeps the highest-priority layer wholesale, but we
    # double-check here so a future "concat" mode wouldn't silently
    # spawn a server twice.
    by_name: dict[str, MCPServerConfig] = {}
    for cfg in merged:
        by_name.setdefault(cfg.name, cfg)
    return list(by_name.values())
