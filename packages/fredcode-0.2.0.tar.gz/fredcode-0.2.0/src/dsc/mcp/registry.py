"""MCP tool adapter — wraps remote tools as native ``Tool`` dataclasses (P4.2).

Each MCP tool exposed by a connected server appears in dsc's `Registry`
under the canonical name ``mcp__<server>__<tool>``. The same naming
scheme that Claude Code uses; the P3.1 `RuleEngine` matches this format
already (``Tool(specifier)`` syntax with snake_case fall-through).

Schema deferral
~~~~~~~~~~~~~~~

By default, the wire-shaped tool schema sent to the model is a
*stub* — just the tool name and a one-line description that says "MCP
tool from server X." The full JSON schema is fetched + validated on the
first invocation so the prompt prefix doesn't grow by ~5K tokens per
server. Override with ``ENABLE_TOOL_SEARCH=false`` or
``FRED_MCP_SCHEMAS=eager`` to load all schemas up front (matches Claude
Code's "all-schemas-at-once" mode).

The args model is built dynamically via ``pydantic.create_model`` from
the remote tool's ``inputSchema``. Unknown JSON-schema constructs
(``$ref``, ``allOf``, ``oneOf``) degrade to ``Any`` rather than failing
hard — the philosophy is "let the server validate; we just don't reject
calls the server would accept."
"""
from __future__ import annotations

import os
from typing import Any, Callable

from pydantic import BaseModel, ConfigDict, Field, create_model

from dsc.mcp.client import MCPClient, MCPClientError, MCPRpcError
from dsc.tools.base import Tool

# Stub description used when schema deferral is on. The actual remote
# tool's description is appended (truncated) so the model still sees
# something hint-y; the JSON schema is omitted.
_STUB_DESCRIPTION_TEMPLATE = (
    "[MCP] {server}::{tool} — {description}\n"
    "(args validated on dispatch; see ``mcp__{server}__{tool}`` rules.)"
)
_STUB_DESCRIPTION_MAX_CHARS = 220


def schemas_eager() -> bool:
    """True iff full MCP tool schemas should ship in the system prefix.

    Defaults to deferred (False). Two env knobs flip to eager:

      - ``ENABLE_TOOL_SEARCH=false`` — top-level "load all schemas" knob
        from the plan; "auto" / unset / anything else leaves deferred.
      - ``FRED_MCP_SCHEMAS=eager`` — MCP-specific override that wins
        over ``ENABLE_TOOL_SEARCH`` so users can opt MCP into eager
        without disabling tool search.
    """
    if os.environ.get("FRED_MCP_SCHEMAS", "").lower() == "eager":
        return True
    val = os.environ.get("ENABLE_TOOL_SEARCH")
    if val is None:
        return False
    if val.lower() in ("false", "0", "no", "off"):
        return True
    return False


def canonical_tool_name(server: str, tool: str) -> str:
    """Build the ``mcp__server__tool`` registry name."""
    return f"mcp__{server}__{tool}"


# ---------------------------------------------------------------------------
# Pydantic args model from JSON schema
# ---------------------------------------------------------------------------


def _python_type_for(prop: dict) -> Any:
    """Best-effort JSON Schema -> Python type mapping for create_model.

    The model is permissive: arrays/objects/null collapse to ``list`` /
    ``dict`` / ``Any``. Server-side validation is the contract; we just
    need pydantic to accept anything the server would.
    """
    if not isinstance(prop, dict):
        return Any
    t = prop.get("type")
    if isinstance(t, list):
        # Multi-type — pick the first concrete type or fall through.
        for entry in t:
            if entry in ("string", "number", "integer", "boolean"):
                t = entry
                break
        else:
            return Any
    if t == "string":
        return str
    if t == "integer":
        return int
    if t == "number":
        return float
    if t == "boolean":
        return bool
    if t == "array":
        return list
    if t == "object":
        return dict
    return Any


def _build_args_model(server: str, tool: str, schema: dict | None) -> type[BaseModel]:
    """Build a pydantic ``BaseModel`` subclass from the remote ``inputSchema``.

    Falls back to a permissive model that accepts any extra kwargs when
    the schema is missing or malformed. Required fields from the schema
    become required; optional fields default to ``None``.
    """
    cls_name = f"MCP_{server}_{tool}_Args"
    cls_name = "".join(c if c.isalnum() else "_" for c in cls_name)
    if not isinstance(schema, dict):
        # Permissive fallback — accept any kwargs, no validation.
        return create_model(
            cls_name,
            __config__=ConfigDict(extra="allow"),
        )
    properties = schema.get("properties") or {}
    required = set(schema.get("required") or [])
    if not isinstance(properties, dict):
        return create_model(
            cls_name,
            __config__=ConfigDict(extra="allow"),
        )
    fields: dict[str, tuple[Any, Any]] = {}
    for raw_name, prop in properties.items():
        if not isinstance(raw_name, str):
            continue
        # Sanitize prop names that aren't valid Python identifiers — the
        # spec allows them; pydantic doesn't. We replace the offender
        # with `_` and accept that the alias is lossy. The handler will
        # forward whatever the model emits anyway.
        py_name = "".join(c if (c.isalnum() or c == "_") else "_" for c in raw_name)
        if not py_name or py_name[0].isdigit():
            py_name = f"f_{py_name}"
        py_type = _python_type_for(prop if isinstance(prop, dict) else {})
        description = ""
        if isinstance(prop, dict):
            description = str(prop.get("description") or "")
        if raw_name in required:
            field_def = Field(..., description=description)
            fields[py_name] = (py_type, field_def)
        else:
            field_def = Field(default=None, description=description)
            fields[py_name] = (py_type | None, field_def)
    if not fields:
        # Empty schema — accept anything.
        return create_model(
            cls_name,
            __config__=ConfigDict(extra="allow"),
        )
    # ``extra="allow"`` so extra kwargs pass through; the server will
    # validate against the actual schema if it cares.
    return create_model(
        cls_name,
        __config__=ConfigDict(extra="allow"),
        **fields,
    )


# ---------------------------------------------------------------------------
# Result formatting
# ---------------------------------------------------------------------------


def _format_call_result(result: dict) -> str:
    """Render an MCP ``tools/call`` result envelope as a model-readable string.

    The MCP spec returns a ``content`` array of ``{type, text, ...}``
    entries plus an optional ``isError`` flag. We concatenate text
    blocks, prefix non-text blocks with their type, and surface
    ``isError=True`` as the standard ``Error: ...`` prefix so the model
    treats it the same as a built-in tool error.
    """
    if not isinstance(result, dict):
        return f"Error: MCP returned non-dict result: {type(result).__name__}"
    is_error = bool(result.get("isError"))
    content = result.get("content") or []
    if not isinstance(content, list):
        # Non-conformant server: fall back to a JSON dump so the model
        # at least sees something.
        import json
        body = json.dumps(result, default=str, sort_keys=True)
        return f"Error: {body}" if is_error else body
    parts: list[str] = []
    for blk in content:
        if not isinstance(blk, dict):
            continue
        kind = blk.get("type")
        if kind == "text":
            parts.append(str(blk.get("text") or ""))
        elif kind == "image":
            mime = blk.get("mimeType") or "image"
            parts.append(f"[image: {mime}]")
        elif kind == "resource":
            uri = blk.get("resource", {}).get("uri") or ""
            parts.append(f"[resource: {uri}]")
        else:
            # Unknown block type — surface a marker so the model can
            # see that something was returned even if it's opaque.
            parts.append(f"[{kind or 'unknown'}]")
    body = "\n".join(p for p in parts if p) or "(empty)"
    if is_error:
        return f"Error: {body}"
    return body


# ---------------------------------------------------------------------------
# Tool adapter
# ---------------------------------------------------------------------------


class MCPToolAdapter:
    """Wraps one remote MCP tool as a registerable ``Tool``.

    The adapter holds a reference to its ``MCPClient`` so dispatch can
    fire ``tools/call`` synchronously. It also caches the lazily-built
    args model so the second invocation skips ``create_model``.

    Telemetry hook
    ~~~~~~~~~~~~~~

    ``set_telemetry_callback`` lets the lifecycle layer wire a
    fire-and-forget ``mcp_tool_call`` event emitter without coupling
    the adapter to the tracer interface.
    """

    def __init__(self, client: MCPClient, server: str, tool_def: dict) -> None:
        self.client = client
        self.server = server
        self.tool_def = tool_def
        self.tool_name = str(tool_def.get("name") or "")
        self.description_full = str(tool_def.get("description") or "")
        self.input_schema = tool_def.get("inputSchema") if isinstance(
            tool_def.get("inputSchema"), dict,
        ) else None
        self._args_model: type[BaseModel] | None = None
        self._eager_model_built = False
        self._telemetry_cb: Callable[[dict], None] | None = None

    # ------------------------------------------------------------------
    # Public surface
    # ------------------------------------------------------------------

    @property
    def canonical_name(self) -> str:
        return canonical_tool_name(self.server, self.tool_name)

    def stub_description(self) -> str:
        """One-line description used in deferred-schema mode."""
        body = (self.description_full or "")
        if len(body) > _STUB_DESCRIPTION_MAX_CHARS:
            body = body[: _STUB_DESCRIPTION_MAX_CHARS - 1] + "…"
        return _STUB_DESCRIPTION_TEMPLATE.format(
            server=self.server, tool=self.tool_name,
            description=body or "(no description)",
        )

    def args_model(self) -> type[BaseModel]:
        """Lazily build (and cache) the pydantic args model.

        Always materialized on first invocation, even when the system
        catalog showed only the stub description. The model is needed
        for `Registry.dispatch`'s validation step.
        """
        if self._args_model is None:
            self._args_model = _build_args_model(
                self.server, self.tool_name, self.input_schema,
            )
        return self._args_model

    def to_tool(self, *, eager: bool) -> Tool:
        """Build the ``Tool`` dataclass that the registry will register.

        ``eager=True`` ships the full description (including the
        long-form server text) AND eagerly builds the args model so the
        full JSON schema appears in the wire-format tools array. The
        default deferred mode ships the stub description and a permissive
        args model; the FULL args model is built lazily on first
        invocation via ``args_model()``.

        Permission flag is hardcoded to ``True``: every MCP tool
        requires permission (the user can [a]llow once, persist via the
        P3.1 rule engine, etc.). Servers can be implicitly trusted via
        an ``allow: ["mcp__<server>__*"]`` rule in settings.local.json.
        """
        if eager:
            description = (
                self.description_full
                or _STUB_DESCRIPTION_TEMPLATE.format(
                    server=self.server,
                    tool=self.tool_name,
                    description="",
                )
            )
            args_model = self.args_model()
            self._eager_model_built = True
        else:
            description = self.stub_description()
            # Defer materialization. We hand the registry a permissive
            # placeholder model; the real one is built on-demand inside
            # the handler closure.
            args_model = create_model(
                f"MCP_{self.server}_{self.tool_name}_Stub",
                __config__=ConfigDict(extra="allow"),
            )
        handler = self._make_handler(eager_already_built=eager)
        return Tool(
            name=self.canonical_name,
            description=description,
            args_model=args_model,
            handler=handler,
            requires_permission=True,
        )

    def set_telemetry_callback(
        self, cb: Callable[[dict], None] | None,
    ) -> None:
        """Register a per-call telemetry emitter. ``None`` clears it."""
        self._telemetry_cb = cb

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    def _make_handler(self, *, eager_already_built: bool) -> Callable[[BaseModel], str]:
        """Closure used as the ``Tool.handler``.

        On first invocation in deferred mode, the closure validates
        against the lazily-built schema (``args_model()``) — the stub
        model accepted anything; the real one rejects malformed args
        with a model-readable error.
        """
        adapter = self

        def handler(args: BaseModel) -> str:
            import time as _time
            t0 = _time.perf_counter()
            # Lazy schema fetch: the full args_model is built on demand
            # so the system prefix didn't carry the schema. We re-validate
            # the args here against the real model to surface a structured
            # error if the model's call doesn't match.
            payload = args.model_dump() if hasattr(args, "model_dump") else dict(args)
            error_type: str | None = None
            error_message: str | None = None
            result_body: str
            if not eager_already_built and not adapter._eager_model_built:
                try:
                    real_model = adapter.args_model()
                    real_model.model_validate(payload)
                except Exception as e:
                    error_type = "validation_error"
                    error_message = (
                        f"Error: invalid arguments for {adapter.canonical_name}: {e}"
                    )
            if error_message is not None:
                result_body = error_message
            elif adapter.client.is_crashed:
                # The lifecycle code installed this adapter from a now-
                # crashed client. Surface a structured error rather than
                # raising — the model can read the message and stop trying.
                error_type = "server_crashed"
                result_body = (
                    f"Error: MCP server {adapter.server!r} crashed; "
                    f"tool {adapter.canonical_name} unavailable "
                    f"(reason: {adapter.client.crash_reason or 'unknown'})"
                )
            else:
                try:
                    result_envelope = adapter.client.call_tool(
                        adapter.tool_name, payload,
                    )
                    result_body = _format_call_result(result_envelope)
                except MCPRpcError as e:
                    error_type = "rpc_error"
                    error_message = (
                        f"Error: MCP server {adapter.server!r} returned an error "
                        f"calling {adapter.tool_name!r}: {e}"
                    )
                    result_body = error_message
                except MCPClientError as e:
                    # Transport failure — server probably crashed.
                    # Mark the client crashed so subsequent calls short-
                    # circuit cleanly.
                    error_type = "transport_error"
                    error_message = (
                        f"Error: MCP server {adapter.server!r} crashed; "
                        f"tool {adapter.canonical_name} unavailable: {e}"
                    )
                    if not adapter.client.is_crashed:
                        adapter.client._mark_crashed(str(e))
                    result_body = error_message
                except Exception as e:
                    error_type = type(e).__name__
                    error_message = (
                        f"Error: MCP call {adapter.canonical_name} raised "
                        f"{type(e).__name__}: {e}"
                    )
                    result_body = error_message
            duration_ms = int((_time.perf_counter() - t0) * 1000)
            if adapter._telemetry_cb is not None:
                try:
                    adapter._telemetry_cb({
                        "server": adapter.server,
                        "tool": adapter.tool_name,
                        "args_chars": len(_safe_repr(payload)),
                        "result_chars": len(result_body or ""),
                        "duration_ms": duration_ms,
                        "error_type": error_type,
                    })
                except Exception:
                    pass
            return result_body

        return handler


def _safe_repr(payload: object) -> str:
    """Stable JSON-like repr for telemetry char counting (never raises)."""
    try:
        import json
        return json.dumps(payload, default=str, sort_keys=True)
    except (TypeError, ValueError):
        return repr(payload)
