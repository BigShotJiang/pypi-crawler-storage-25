"""Frozen-at-build-time rate cards. Used as fallback when the runtime
cache at ~/.config/fred/rate-card.json is missing (offline first run,
brand-new install before login).

Keep these numbers in sync with FredWeb/src/lib/pricing.ts. They will
drift over time — a rate-card.json fetched from /api/pricing always
takes precedence. The bundled values exist only so Fred works at all
without network access.

NEVER add a discounted card here. Full retail only — the FredWeb
pricing module enforces this at the type level; this file is the
hand-mirrored Python equivalent.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True)
class Rates:
    """Microcents per 1M tokens. Same units as FredWeb/src/lib/pricing.ts."""

    input_uncached: int
    input_cached: int
    output: int


@dataclass(frozen=True)
class BundledCard:
    """Subset of FredWeb's RateCard. Customer-facing only."""

    model: str
    upstream: Rates
    billed: Rates


BUNDLED_CARDS: Final[tuple[BundledCard, ...]] = (
    BundledCard(
        model="deepseek-v4-flash",
        upstream=Rates(input_uncached=140_000, input_cached=2_800, output=280_000),
        billed=Rates(input_uncached=350_000, input_cached=7_000, output=700_000),
    ),
    BundledCard(
        model="deepseek-v4-pro",
        upstream=Rates(input_uncached=1_740_000, input_cached=14_500, output=3_480_000),
        billed=Rates(input_uncached=4_350_000, input_cached=36_250, output=8_700_000),
    ),
)


def known_models() -> tuple[str, ...]:
    return tuple(c.model for c in BUNDLED_CARDS)


def get_bundled_card(model: str) -> BundledCard | None:
    for c in BUNDLED_CARDS:
        if c.model == model:
            return c
    return None
