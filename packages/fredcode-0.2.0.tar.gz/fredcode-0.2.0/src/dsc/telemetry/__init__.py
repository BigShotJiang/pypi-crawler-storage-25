"""Postgres-backed telemetry for dsc.

Importing this module never connects to anything. Call `make_tracer()` to
construct a Tracer; if `DSC_TELEMETRY_DB_URL` is unset, you get a NullTracer
with zero overhead.
"""
from dsc.telemetry.tracer import (
    IterationHandle,
    NullTracer,
    PgTracer,
    Tracer,
    TurnHandle,
    make_tracer,
)

__all__ = [
    "IterationHandle",
    "NullTracer",
    "PgTracer",
    "Tracer",
    "TurnHandle",
    "make_tracer",
]
