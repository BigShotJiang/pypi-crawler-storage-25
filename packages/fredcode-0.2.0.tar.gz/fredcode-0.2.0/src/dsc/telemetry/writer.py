"""Background-thread Postgres writer for dsc telemetry.

Owns the single psycopg connection. Pulls envelopes off a bounded queue and
inserts them in small batches. Survives DB outages with exponential backoff;
records dropped-event counts as a follow-up `telemetry_drop` event so the gap
is visible in the data.
"""
from __future__ import annotations

import json
import os
import queue
import sys
import threading
import time
from typing import Any

# psycopg is an optional dep — caller (`make_tracer`) decides whether to spin
# up this writer based on import availability + DSC_TELEMETRY_DB_URL presence.
import psycopg

from dsc.telemetry.redact import redact_url


SCHEMA_DDL = r"""
CREATE TABLE IF NOT EXISTS dsc_sessions (
  session_id           UUID PRIMARY KEY,
  started_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ended_at             TIMESTAMPTZ,
  end_reason           TEXT,
  dsc_version          TEXT NOT NULL,
  python_version       TEXT NOT NULL,
  os                   TEXT NOT NULL,
  shell                TEXT,
  cwd                  TEXT NOT NULL,
  git_commit           TEXT,
  git_dirty            BOOLEAN,
  agents_md_sha256     TEXT,
  model                TEXT NOT NULL,
  base_url             TEXT NOT NULL,
  yolo_initial         BOOLEAN NOT NULL,
  one_shot             BOOLEAN NOT NULL,
  system_prompt_sha256 TEXT NOT NULL,
  system_prompt_text   TEXT,
  client_pid           INTEGER NOT NULL,
  hostname             TEXT,
  tool_catalog         JSONB NOT NULL,
  parent_session_id    UUID NULL REFERENCES dsc_sessions(session_id) ON DELETE CASCADE,
  session_kind         TEXT NOT NULL DEFAULT 'root',
  config_snapshot      JSONB
);
ALTER TABLE dsc_sessions ADD COLUMN IF NOT EXISTS parent_session_id UUID NULL
  REFERENCES dsc_sessions(session_id) ON DELETE CASCADE;
ALTER TABLE dsc_sessions ADD COLUMN IF NOT EXISTS session_kind TEXT NOT NULL DEFAULT 'root';
ALTER TABLE dsc_sessions ADD COLUMN IF NOT EXISTS config_snapshot JSONB;
CREATE INDEX IF NOT EXISTS idx_sessions_started ON dsc_sessions (started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_version ON dsc_sessions (dsc_version, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_model   ON dsc_sessions (model, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_parent  ON dsc_sessions (parent_session_id) WHERE parent_session_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS dsc_turns (
  turn_id                  UUID PRIMARY KEY,
  session_id               UUID NOT NULL REFERENCES dsc_sessions(session_id) ON DELETE CASCADE,
  turn_index               INTEGER NOT NULL,
  iteration_index          INTEGER NOT NULL,
  started_at               TIMESTAMPTZ NOT NULL,
  ended_at                 TIMESTAMPTZ,
  user_input               TEXT,
  user_input_truncated     BOOLEAN NOT NULL DEFAULT FALSE,
  assistant_text           TEXT,
  assistant_text_truncated BOOLEAN NOT NULL DEFAULT FALSE,
  finish_reason            TEXT,
  prompt_tokens            INTEGER,
  completion_tokens        INTEGER,
  cached_tokens            INTEGER,
  context_used_est         INTEGER,
  budget_status            TEXT,
  api_error_type           TEXT,
  api_error_message        TEXT,
  duration_ms              INTEGER,
  num_tool_calls           INTEGER NOT NULL DEFAULT 0,
  mode                     TEXT NOT NULL DEFAULT 'act'
);
ALTER TABLE dsc_turns ADD COLUMN IF NOT EXISTS mode TEXT NOT NULL DEFAULT 'act';
CREATE INDEX IF NOT EXISTS idx_turns_session ON dsc_turns (session_id, turn_index, iteration_index);
CREATE INDEX IF NOT EXISTS idx_turns_errors  ON dsc_turns (api_error_type) WHERE api_error_type IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_turns_finish  ON dsc_turns (finish_reason);

CREATE TABLE IF NOT EXISTS dsc_tool_calls (
  tool_call_id             UUID PRIMARY KEY,
  turn_id                  UUID NOT NULL REFERENCES dsc_turns(turn_id) ON DELETE CASCADE,
  session_id               UUID NOT NULL,
  call_index               INTEGER NOT NULL,
  openai_call_id           TEXT NOT NULL,
  tool_name                TEXT NOT NULL,
  args                     JSONB,
  raw_arguments            TEXT,
  parse_error              TEXT,
  args_fingerprint         TEXT NOT NULL,
  permission_outcome       TEXT,
  permission_prompt_ms     INTEGER,
  outcome                  TEXT NOT NULL,
  handler_exception_type   TEXT,
  result_text              TEXT,
  result_truncated         BOOLEAN NOT NULL DEFAULT FALSE,
  result_full_bytes        INTEGER,
  result_starts_with_error BOOLEAN NOT NULL,
  duration_ms              INTEGER NOT NULL,
  started_at               TIMESTAMPTZ NOT NULL,
  ended_at                 TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tool_calls_session   ON dsc_tool_calls (session_id, started_at);
CREATE INDEX IF NOT EXISTS idx_tool_calls_turn      ON dsc_tool_calls (turn_id, call_index);
CREATE INDEX IF NOT EXISTS idx_tool_calls_failures  ON dsc_tool_calls (tool_name, outcome) WHERE outcome <> 'ok';
CREATE INDEX IF NOT EXISTS idx_tool_calls_loops     ON dsc_tool_calls (session_id, args_fingerprint);
CREATE INDEX IF NOT EXISTS idx_tool_calls_perm_deny ON dsc_tool_calls (tool_name) WHERE permission_outcome = 'user_n';

CREATE TABLE IF NOT EXISTS dsc_events (
  event_id   BIGSERIAL PRIMARY KEY,
  session_id UUID NOT NULL REFERENCES dsc_sessions(session_id) ON DELETE CASCADE,
  turn_id    UUID,
  ts         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  kind       TEXT NOT NULL,
  payload    JSONB
);
CREATE INDEX IF NOT EXISTS idx_events_session ON dsc_events (session_id, ts);
CREATE INDEX IF NOT EXISTS idx_events_kind    ON dsc_events (kind, ts);

CREATE OR REPLACE VIEW dsc_session_tree AS
WITH RECURSIVE tree(root_session_id, descendant_session_id, depth) AS (
  SELECT session_id, session_id, 0
  FROM dsc_sessions
  WHERE parent_session_id IS NULL
  UNION ALL
  SELECT t.root_session_id, s.session_id, t.depth + 1
  FROM dsc_sessions s
  JOIN tree t ON s.parent_session_id = t.descendant_session_id
)
SELECT root_session_id, descendant_session_id, depth FROM tree;

CREATE OR REPLACE VIEW dsc_session_cost_rollup AS
SELECT
  st.root_session_id,
  COUNT(DISTINCT st.descendant_session_id) AS session_count,
  COALESCE(SUM(t.prompt_tokens), 0)         AS total_prompt_tokens,
  COALESCE(SUM(t.completion_tokens), 0)     AS total_completion_tokens,
  COALESCE(SUM(t.cached_tokens), 0)         AS total_cached_tokens,
  COALESCE(SUM(t.duration_ms), 0)           AS total_duration_ms
FROM dsc_session_tree st
LEFT JOIN dsc_turns t ON t.session_id = st.descendant_session_id
GROUP BY st.root_session_id;
"""


_SESSION_INSERT = """
INSERT INTO dsc_sessions (
  session_id, started_at, dsc_version, python_version, os, shell, cwd,
  git_commit, git_dirty, agents_md_sha256, model, base_url, yolo_initial,
  one_shot, system_prompt_sha256, system_prompt_text, client_pid, hostname,
  tool_catalog, config_snapshot, parent_session_id, session_kind
) VALUES (
  %(session_id)s, %(started_at)s, %(dsc_version)s, %(python_version)s, %(os)s,
  %(shell)s, %(cwd)s, %(git_commit)s, %(git_dirty)s, %(agents_md_sha256)s,
  %(model)s, %(base_url)s, %(yolo_initial)s, %(one_shot)s,
  %(system_prompt_sha256)s, %(system_prompt_text)s, %(client_pid)s,
  %(hostname)s, %(tool_catalog)s, %(config_snapshot)s, %(parent_session_id)s,
  %(session_kind)s
) ON CONFLICT (session_id) DO NOTHING
"""

_SESSION_END_UPDATE = """
UPDATE dsc_sessions SET ended_at = %(ended_at)s, end_reason = %(end_reason)s
 WHERE session_id = %(session_id)s
"""

_TURN_INSERT = """
INSERT INTO dsc_turns (
  turn_id, session_id, turn_index, iteration_index, started_at, ended_at,
  user_input, user_input_truncated, assistant_text, assistant_text_truncated,
  finish_reason, prompt_tokens, completion_tokens, cached_tokens,
  context_used_est, budget_status, api_error_type, api_error_message,
  duration_ms, num_tool_calls, mode
) VALUES (
  %(turn_id)s, %(session_id)s, %(turn_index)s, %(iteration_index)s,
  %(started_at)s, %(ended_at)s, %(user_input)s, %(user_input_truncated)s,
  %(assistant_text)s, %(assistant_text_truncated)s, %(finish_reason)s,
  %(prompt_tokens)s, %(completion_tokens)s, %(cached_tokens)s,
  %(context_used_est)s, %(budget_status)s, %(api_error_type)s,
  %(api_error_message)s, %(duration_ms)s, %(num_tool_calls)s, %(mode)s
) ON CONFLICT (turn_id) DO NOTHING
"""

_TOOL_CALL_INSERT = """
INSERT INTO dsc_tool_calls (
  tool_call_id, turn_id, session_id, call_index, openai_call_id, tool_name,
  args, raw_arguments, parse_error, args_fingerprint, permission_outcome,
  permission_prompt_ms, outcome, handler_exception_type, result_text,
  result_truncated, result_full_bytes, result_starts_with_error,
  duration_ms, started_at, ended_at
) VALUES (
  %(tool_call_id)s, %(turn_id)s, %(session_id)s, %(call_index)s,
  %(openai_call_id)s, %(tool_name)s, %(args)s, %(raw_arguments)s,
  %(parse_error)s, %(args_fingerprint)s, %(permission_outcome)s,
  %(permission_prompt_ms)s, %(outcome)s, %(handler_exception_type)s,
  %(result_text)s, %(result_truncated)s, %(result_full_bytes)s,
  %(result_starts_with_error)s, %(duration_ms)s, %(started_at)s, %(ended_at)s
) ON CONFLICT (tool_call_id) DO NOTHING
"""

_EVENT_INSERT = """
INSERT INTO dsc_events (session_id, turn_id, ts, kind, payload)
VALUES (%(session_id)s, %(turn_id)s, %(ts)s, %(kind)s, %(payload)s)
"""


_INSERT_SQL: dict[str, str] = {
    "session_start": _SESSION_INSERT,
    "session_end":   _SESSION_END_UPDATE,
    "turn":          _TURN_INSERT,
    "tool_call":     _TOOL_CALL_INSERT,
    "event":         _EVENT_INSERT,
}


# An "envelope" is just a tuple (kind, params_dict). The kind picks which SQL
# to run; the params dict is fed straight to psycopg via named-param substitution.

_SHUTDOWN: object = object()


def _debug_enabled() -> bool:
    return os.environ.get("DSC_TELEMETRY_DEBUG") == "1"


def _debug(msg: str) -> None:
    if _debug_enabled():
        print(f"dsc/telemetry: {msg}", file=sys.stderr)


class BatchWriter:
    """Daemon-thread queue drainer. One connection, one writer thread.

    Public surface:
      - submit(kind, params)   non-blocking; drops on full queue
      - drain(timeout)         best-effort flush, sends shutdown sentinel
      - dropped_events         int counter (only mutated by submit)

    All exceptions are caught inside the thread; the producer never sees them.
    """

    def __init__(self, dsn: str, *, queue_size: int = 4096,
                 batch_max: int = 100, flush_interval_s: float = 0.25) -> None:
        self._dsn = dsn
        self._q: queue.Queue[Any] = queue.Queue(maxsize=queue_size)
        self._batch_max = batch_max
        self._flush_interval = flush_interval_s
        self._conn: psycopg.Connection | None = None
        self._thread = threading.Thread(
            target=self._run, name="dsc-telemetry", daemon=True
        )
        self._stopped = threading.Event()
        self.dropped_events = 0
        self._schema_ready = False
        self._shutdown_sent = False

    # ---- producer side ---------------------------------------------------

    def start(self) -> None:
        self._thread.start()

    def submit(self, kind: str, params: dict) -> None:
        try:
            self._q.put_nowait((kind, params))
        except queue.Full:
            self.dropped_events += 1

    def drain(self, timeout: float = 2.0) -> None:
        if self._shutdown_sent:
            return
        self._shutdown_sent = True
        try:
            self._q.put_nowait(_SHUTDOWN)
        except queue.Full:
            # Force-feed: pop one, push sentinel
            try:
                self._q.get_nowait()
                self._q.put_nowait(_SHUTDOWN)
                self.dropped_events += 1
            except queue.Empty:
                pass
        self._thread.join(timeout=timeout)
        if self._thread.is_alive():
            _debug(f"drain timeout; thread still running. dropped={self.dropped_events}")

    # ---- consumer side ---------------------------------------------------

    def _run(self) -> None:
        backoff = 1.0
        while not self._stopped.is_set():
            batch = self._collect_batch()
            if batch is None:  # shutdown sentinel
                self._final_flush()
                return
            if not batch:
                continue
            try:
                self._ensure_conn()
                self._write_batch(batch)
                if self.dropped_events and self._can_announce_drops(batch):
                    # Best-effort: push a synthetic event noting the gap.
                    self._announce_drops(batch[0][1].get("session_id"))
                backoff = 1.0
            except (psycopg.OperationalError, OSError) as e:
                _debug(f"write failed: {type(e).__name__}: {e}; backoff={backoff:.1f}s")
                self._close_conn()
                # Re-enqueue the batch at the head — but with a bounded queue
                # we may have to drop. Push best-effort, count drops.
                for env in batch:
                    try:
                        self._q.put_nowait(env)
                    except queue.Full:
                        self.dropped_events += 1
                self._stopped.wait(backoff)
                backoff = min(backoff * 2, 30.0)
            except Exception as e:
                # Programmer bug or bad payload: log once and drop the batch.
                _debug(f"unexpected error: {type(e).__name__}: {e}; dropping batch")
                self.dropped_events += len(batch)

    def _collect_batch(self) -> list[tuple[str, dict]] | None:
        deadline = time.monotonic() + self._flush_interval
        batch: list[tuple[str, dict]] = []
        # Block on the first item so we don't spin.
        try:
            first = self._q.get(timeout=self._flush_interval)
        except queue.Empty:
            return batch
        if first is _SHUTDOWN:
            return None
        batch.append(first)
        # Drain whatever else is there, up to batch_max or until deadline.
        while len(batch) < self._batch_max:
            timeout = max(0.0, deadline - time.monotonic())
            if timeout == 0.0:
                break
            try:
                env = self._q.get(timeout=timeout)
            except queue.Empty:
                break
            if env is _SHUTDOWN:
                # Process what we have, then signal shutdown by re-pushing.
                self._q.put_nowait(_SHUTDOWN)
                break
            batch.append(env)
        return batch

    def _ensure_conn(self) -> None:
        if self._conn is not None and not self._conn.closed:
            return
        self._conn = psycopg.connect(self._dsn, autocommit=False)
        if not self._schema_ready:
            with self._conn.cursor() as cur:
                cur.execute(SCHEMA_DDL)
            self._conn.commit()
            self._schema_ready = True
            _debug(f"connected & schema bootstrapped: {redact_url(self._dsn)}")

    def _close_conn(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    def _write_batch(self, batch: list[tuple[str, dict]]) -> None:
        assert self._conn is not None
        with self._conn.cursor() as cur:
            for kind, params in batch:
                sql = _INSERT_SQL.get(kind)
                if sql is None:
                    _debug(f"unknown envelope kind: {kind!r}")
                    continue
                cur.execute(sql, params)
        self._conn.commit()

    def _final_flush(self) -> None:
        # Drain any remaining items in the queue without backoff.
        remaining: list[tuple[str, dict]] = []
        while True:
            try:
                env = self._q.get_nowait()
            except queue.Empty:
                break
            if env is _SHUTDOWN:
                continue
            remaining.append(env)
        if not remaining:
            self._close_conn()
            return
        try:
            self._ensure_conn()
            self._write_batch(remaining)
        except Exception as e:
            _debug(f"final flush failed: {type(e).__name__}: {e}; dropped={len(remaining)}")
            self.dropped_events += len(remaining)
        finally:
            self._close_conn()

    def _can_announce_drops(self, batch: list[tuple[str, dict]]) -> bool:
        # Only announce if we have a session_id in the current batch and there's
        # at least one drop we haven't reported yet.
        return self.dropped_events > 0 and any(
            env[1].get("session_id") for env in batch
        )

    def _announce_drops(self, session_id) -> None:
        if session_id is None:
            return
        try:
            assert self._conn is not None
            count = self.dropped_events
            self.dropped_events = 0
            from datetime import datetime, timezone
            with self._conn.cursor() as cur:
                cur.execute(
                    _EVENT_INSERT,
                    {
                        "session_id": session_id,
                        "turn_id": None,
                        "ts": datetime.now(timezone.utc),
                        "kind": "telemetry_drop",
                        "payload": json.dumps({"count": count}),
                    },
                )
            self._conn.commit()
        except Exception:
            # If we can't even announce, restore the counter so we try later.
            self.dropped_events += count
