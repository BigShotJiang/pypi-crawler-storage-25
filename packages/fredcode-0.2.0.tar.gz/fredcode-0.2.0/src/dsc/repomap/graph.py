"""PageRank-driven symbol ranking over a file-reference graph.

Aider's algorithm, ported verbatim with some renaming for clarity:

1. Build a `MultiDiGraph` whose nodes are files (rel paths) and whose
   edges go `referencer -> definer` for every (ident) shared between
   the two files. Edge weight = `mul * sqrt(num_refs)` where:
     - `mul` starts at 1.0
     - x10 if the identifier is in the user's `mentioned_idents` set
     - x10 if it's a "distinctive long name" (snake/kebab/camel, len>=8)
     - x0.1 if it starts with `_` (private)
     - x0.1 if it's defined in >5 files (probably noise)
     - x50 ON TOP of the above if the referencer is a chat file (signals
       "this is something the model is actively working with")

2. Build a personalization vector. Each file in `chat_files` plus each
   file mentioned via `mentioned_idents` matching a path component gets
   `100/N` weight where N is the total file count; the rest get 0.
   We additionally allow weight from the optional viewed/recent vector.

3. `nx.pagerank(G, personalization=p, dangling=p, weight="weight")`
   gives a rank per file. Re-attribute the file rank to symbols by
   distributing across each file's outgoing edges proportionally to
   weight, grouped by `(definer_file, ident)`.

The output is a list of `(rel_fname, ident, rank)` tuples ordered
descending by rank — the renderer slices the head of this list to fit
the token budget.
"""
from __future__ import annotations

import math
from collections import Counter, defaultdict

from dsc.repomap.tags import Tag

# Personalization weights (matches the plan's spec):
#   chat files     -> 1.0  (highest signal: model is editing here)
#   recently view'd -> 0.5  (model has seen the file this session)
#   mentioned via @ -> 0.3  (user pointed at it last turn)
PERSONALIZATION_CHAT = 1.0
PERSONALIZATION_VIEWED = 0.5
PERSONALIZATION_MENTIONED = 0.3


def build_graph_and_rank(
    tags_by_file: dict[str, list[Tag]],
    *,
    chat_rel_fnames: set[str],
    mentioned_idents: set[str],
    viewed_rel_fnames: set[str] | None = None,
    mentioned_rel_fnames: set[str] | None = None,
) -> tuple[list[tuple[str, str, float]], dict[tuple[str, str], list[Tag]]]:
    """Run PageRank over the file-reference graph and rank symbols.

    Returns a tuple of:
      - ranked: list of (rel_fname, ident, rank) descending by rank
      - definitions: dict[(rel_fname, ident) -> list[Tag]] for renderer
        to look up the line numbers it should highlight in each file.

    `tags_by_file` is the per-file output of `extract_tags` keyed by
    `rel_fname`. Files with no tags should be omitted (they contribute
    no edges and only inflate the personalization base).

    On any failure inside `nx.pagerank` (e.g. an all-zero graph causing
    `ZeroDivisionError`), we fall back to ranking by raw weight, then
    finally to lexicographic order so the caller always gets *some*
    deterministic output.
    """
    import networkx as nx

    if viewed_rel_fnames is None:
        viewed_rel_fnames = set()
    if mentioned_rel_fnames is None:
        mentioned_rel_fnames = set()

    # 1. Aggregate defs/refs across all files.
    defines: dict[str, set[str]] = defaultdict(set)
    references: dict[str, list[str]] = defaultdict(list)
    definitions: dict[tuple[str, str], list[Tag]] = defaultdict(list)

    for rel_fname, tags in tags_by_file.items():
        for tag in tags:
            if tag.kind == "def":
                defines[tag.name].add(rel_fname)
                definitions[(rel_fname, tag.name)].append(tag)
            elif tag.kind == "ref":
                references[tag.name].append(rel_fname)

    # If we saw zero refs (some languages only emit defs), backfill from
    # defs so the graph isn't completely empty. Aider does the same;
    # without it a Python-only project with no call sites returns nothing.
    if not references:
        references = {k: list(v) for k, v in defines.items()}

    # 2. Build the graph.
    idents = set(defines.keys()).intersection(set(references.keys()))
    G: "nx.MultiDiGraph" = nx.MultiDiGraph()

    # Self-edges for defs that have no refs — keeps such files in the
    # ranked output instead of zeroing them out.
    for ident in defines:
        if ident in references:
            continue
        for definer in defines[ident]:
            G.add_edge(definer, definer, weight=0.1, ident=ident)

    for ident in idents:
        # 4-prong identifier multiplier (plan §P1.1):
        mul = 1.0
        is_snake = ("_" in ident) and any(c.isalpha() for c in ident)
        is_kebab = ("-" in ident) and any(c.isalpha() for c in ident)
        is_camel = any(c.isupper() for c in ident) and any(c.islower() for c in ident)

        if ident in mentioned_idents:
            mul *= 10
        if (is_snake or is_kebab or is_camel) and len(ident) >= 8:
            mul *= 10
        if ident.startswith("_"):
            mul *= 0.1
        if len(defines[ident]) > 5:
            mul *= 0.1

        for referencer, num_refs in Counter(references[ident]).items():
            for definer in defines[ident]:
                use_mul = mul
                if referencer in chat_rel_fnames:
                    use_mul *= 50
                # sqrt(num_refs) keeps high-frequency mentions from
                # dominating the ranking
                weight = use_mul * math.sqrt(num_refs)
                G.add_edge(referencer, definer, weight=weight, ident=ident)

    # 3. Personalization vector. Files get a weight per the spec; sum
    # contributions when a file matches multiple criteria.
    personalization: dict[str, float] = {}
    all_files = set(tags_by_file.keys())
    # Aider distributes 100/N across all files as the base unit; we
    # follow that to keep magnitudes comparable and apply the per-source
    # weights as multipliers. With personalization values summed across
    # sources, they remain on the same order of magnitude as Aider's.
    if all_files:
        base = 100.0 / len(all_files)
    else:
        base = 0.0

    for rel_fname in all_files:
        score = 0.0
        if rel_fname in chat_rel_fnames:
            score += PERSONALIZATION_CHAT * base
        if rel_fname in viewed_rel_fnames:
            score += PERSONALIZATION_VIEWED * base
        if rel_fname in mentioned_rel_fnames:
            score += PERSONALIZATION_MENTIONED * base
        if score > 0:
            personalization[rel_fname] = score

    pers_args = {}
    if personalization:
        pers_args = {"personalization": personalization, "dangling": personalization}

    # 4. Run PageRank with belt-and-suspenders fallbacks.
    try:
        ranked = nx.pagerank(G, weight="weight", **pers_args)
    except ZeroDivisionError:
        try:
            ranked = nx.pagerank(G, weight="weight")
        except ZeroDivisionError:
            ranked = {n: 0.0 for n in G.nodes}
    except Exception:
        ranked = {n: 0.0 for n in G.nodes}

    # 5. Re-attribute file rank to symbol rank by walking outgoing edges.
    ranked_definitions: dict[tuple[str, str], float] = defaultdict(float)
    for src in G.nodes:
        src_rank = ranked.get(src, 0.0)
        out_edges = list(G.out_edges(src, data=True))
        total_weight = sum(d["weight"] for _s, _d, d in out_edges)
        if total_weight <= 0:
            continue
        for _s, dst, data in out_edges:
            data_rank = src_rank * data["weight"] / total_weight
            ident = data["ident"]
            ranked_definitions[(dst, ident)] += data_rank

    # 6. Sort descending. Use (rank, fname, ident) so ties break
    # deterministically — important for cache stability and tests.
    ranked_list = sorted(
        ranked_definitions.items(),
        key=lambda kv: (-kv[1], kv[0][0], kv[0][1]),
    )
    out = [(fname, ident, rank) for ((fname, ident), rank) in ranked_list]

    return out, dict(definitions)
