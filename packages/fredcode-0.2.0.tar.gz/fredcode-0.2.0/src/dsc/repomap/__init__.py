"""Tree-sitter repo map (Aider pattern) for dsc.

A token-budgeted summary of the most-relevant classes/functions/signatures
in the project, biased toward files the model has touched this session.
Built from a tree-sitter parse plus a personalized PageRank over a
file-reference graph.

Public surface: just `RepoMap`. The submodules (parser, tags, graph,
render, cache, walk, repo_map) are implementation details and may move
between releases.

Sharp edges:
- Parsing is best-effort; unsupported languages or parse failures are
  silently skipped (the repo map is a hint, not a contract).
- The cache lives in `~/.dsc/cache/repomap/<repo-hash>/`. Stale entries
  are invalidated by (path, mtime, size) tuple, so editing a file in
  another tool reliably refreshes its tags on the next read.
- Output is hard-capped at 100 chars per line to defend against minified
  JS or generated code escaping the head/tail truncation.
"""
from dsc.repomap.repo_map import RepoMap

__all__ = ["RepoMap"]
