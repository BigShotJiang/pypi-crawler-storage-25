"""Turn-scoped UI state shared by the renderer and agent loop.

The renderer holds a TurnState across the streaming Live phase AND the
post-stream tool-dispatch phase. agent.py mutates it via narrow renderer
methods (`tool_status`, `tool_done`); the renderer reads it to produce
frames.

This is the missing primitive that lets us draw `⠋ Reading cli.py...`
during streaming and `✓ Read cli.py · 154 lines · 0.2s` after dispatch,
plus retain the collapsed `▶ thought for 3.4s` line above the response.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class CallStatus(str, Enum):
    QUEUED = "queued"
    PERMISSION = "permission"
    RUNNING = "running"
    DONE_OK = "done_ok"
    DONE_ERROR = "done_error"
    DENIED = "denied"
    # P2.2 plan-mode rejection: the dispatcher refused the tool because
    # it isn't on the plan allowlist. Renders with a dim ◊ glyph; the
    # block reason is the result string from the dispatcher.
    MODE_BLOCKED = "mode_blocked"


@dataclass
class CallState:
    index: int
    call_id: str
    name: str
    args_str: str = ""
    status: CallStatus = CallStatus.QUEUED
    started_at: float | None = None
    ended_at: float | None = None
    summary: str = ""
    result_preview: str = ""
    result_full: str = ""
    # Streaming tools (currently `bash`) push a running line count here
    # via ``Renderer.tool_status(..., lines=N)`` so the final result
    # panel can show "14 lines" alongside the duration.
    lines: int = 0
    # P4.3: shadow-git checkpoint SHA recorded after a successful, write-
    # flavored tool dispatch. ``None`` for read-only tools, denied calls,
    # debounced bursts, or when checkpointing is disabled. Surfaces in
    # the result-card as a ``↶ checkpoint <sha>`` inline marker.
    checkpoint_sha: str | None = None


@dataclass
class TurnState:
    started_at: float = field(default_factory=time.perf_counter)
    reasoning: str = ""
    reasoning_done: bool = False
    reasoning_duration_s: float | None = None
    text: str = ""
    calls: dict[int, CallState] = field(default_factory=dict)
    iteration: int = 0
    max_iters: int = 50
    waiting_first_token: bool = True
    show_thinking: bool = True
