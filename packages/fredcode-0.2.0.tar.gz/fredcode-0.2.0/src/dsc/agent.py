"""The agent loop entry point for the REPL/cli path.

The inner streaming-and-dispatch loop lives in `dsc.session.run_session`.
`run_turn` is a thin wrapper that:
  1. Appends the user input to the caller's `messages` list (in-place
     for backwards compat with cli.py).
  2. Installs per-turn retry hooks on the client so transient API errors
     show up as a dim status line and an `api_retry` telemetry event.
  3. Calls `run_session` with a working copy.
  4. Mirrors any messages run_session appended back into the caller's list.

Subagents (P2.1) and other future callers should use `run_session`
directly; if they want retry hooks they should install them via
`_install_retry_hooks` (or its eventual public counterpart).
"""
from __future__ import annotations

import os
from typing import Callable

from dsc.checkpoints import Checkpointer
from dsc.client import DSClient
from dsc.hooks import HookConfig
from dsc.permissions import PermissionPolicy
from dsc.render import Renderer
from dsc.rules import RuleSet
from dsc.session import MAX_ITERS, run_session
from dsc.telemetry import NullTracer, Tracer
from dsc.tools.registry import Registry

# Re-exported for callers that imported MAX_ITERS from here historically.
__all__ = ["run_turn", "MAX_ITERS"]


def _max_attempts() -> int:
    """The retry budget the renderer cites, matching what `client.stream_chat` uses."""
    raw = os.environ.get("DSC_API_RETRIES")
    if raw is None or raw == "":
        return 3
    try:
        return int(raw)
    except ValueError:
        return 3


def _install_retry_hooks(client: DSClient, renderer: Renderer, tracer: Tracer, turn) -> None:
    """Wire the client's retry callbacks to the renderer + tracer.

    The hooks emit a dim status line on each retry and an `api_retry` event
    per attempt (including the final-failure event with its abort_reason).
    Both are non-blocking — the tracer drops envelopes onto a daemon-thread
    queue, the renderer prints a single line.
    """
    max_attempts = _max_attempts()

    def on_retry(attempt: int, exc: BaseException, backoff_ms: int) -> None:
        renderer.info(
            f"… retrying after transient error ({attempt}/{max_attempts}) "
            f"in {backoff_ms / 1000.0:.1f}s"
        )
        tracer.event("api_retry", payload={
            "attempt": attempt,
            "error_type": type(exc).__name__,
            "backoff_ms": backoff_ms,
            "abort_reason": None,
            "total_elapsed_ms": None,
        }, turn=turn)

    def on_abort(exc: BaseException, reason: str, elapsed_ms: int) -> None:
        tracer.event("api_retry", payload={
            "attempt": None,
            "error_type": type(exc).__name__,
            "backoff_ms": None,
            "abort_reason": reason,
            "total_elapsed_ms": elapsed_ms,
        }, turn=turn)

    client.on_retry = on_retry
    client.on_abort = on_abort


def run_turn(
    user_input: str,
    messages: list[dict],
    client: DSClient,
    registry: Registry,
    renderer: Renderer,
    permissions: PermissionPolicy,
    *,
    tracer: Tracer | None = None,
    repo_map_provider: Callable[[], str] | None = None,
    hooks_config: dict[str, list[HookConfig]] | None = None,
    rule_set: RuleSet | None = None,
    chat_files_provider: Callable[[], set] | None = None,
    checkpointer: Checkpointer | None = None,
) -> list[dict]:
    """Append user_input, run the loop until the model stops, return updated messages.

    Mutates `messages` in place to preserve the existing cli.py contract:
    the REPL keeps a single `messages` list across turns and expects
    `run_turn` to append the user / assistant / tool messages produced
    during the turn.

    `repo_map_provider`, if supplied, is forwarded to `run_session` and
    called once per iteration to fetch the rendered repo map. It is the
    cli.py-side hook for P1.1; subagents and other callers can supply
    a different provider or omit it.

    `hooks_config` is the user's loaded hook table from
    ``.dsc/settings.json`` (P2.4). Forwarded verbatim to ``run_session``.

    `rule_set` is the loaded ``.dsc/rules/*.md`` set (P3.2) and
    ``chat_files_provider`` is a zero-arg callable returning the set of
    paths referenced this turn (used by glob-scoped rules).  Both
    forwarded verbatim to ``run_session``.
    """
    if tracer is None:
        tracer = NullTracer()
    messages.append({"role": "user", "content": user_input})
    turn = tracer.start_turn(user_input=user_input)
    _install_retry_hooks(client, renderer, tracer, turn)

    initial = list(messages)  # snapshot before run_session adds anything
    result = run_session(
        initial,
        client,
        registry,
        permissions=permissions,
        max_iters=MAX_ITERS,
        tracer=tracer,
        renderer=renderer,
        turn=turn,
        repo_map_provider=repo_map_provider,
        hooks_config=hooks_config,
        rule_set=rule_set,
        chat_files_provider=chat_files_provider,
        checkpointer=checkpointer,
    )

    # Mirror any messages run_session appended back into the caller's list.
    appended = result.messages[len(initial):]
    messages.extend(appended)
    return messages
