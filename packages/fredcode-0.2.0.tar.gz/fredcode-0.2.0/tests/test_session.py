"""Tests for `dsc.session.run_session` and the `run_turn` thin wrapper.

Mocks the streaming OpenAI client by stubbing `DSClient._client.chat.completions.create`
with a SimpleNamespace-driven generator (same pattern used in test_accumulator.py).
This avoids respx for the layers above the http boundary — we're testing the
agent loop, not the wire format.
"""
from __future__ import annotations

import io
from types import SimpleNamespace

import pytest
from rich.console import Console

from dsc.agent import run_turn
from dsc.client import DSClient
from dsc.permissions import PermissionPolicy
from dsc.render import Renderer
from dsc.session import MAX_ITERS, SessionResult, run_session
from dsc.tools.registry import Registry, default_registry


# ---------- streaming-mock plumbing ---------------------------------------


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _delta_chunk(*, content=None, tool_calls=None, finish_reason=None, usage=None):
    """Build one streaming chunk shaped like the openai SDK objects."""
    delta = SimpleNamespace(
        content=content,
        tool_calls=tool_calls,
        reasoning_content=None,
    )
    choice = SimpleNamespace(delta=delta, finish_reason=finish_reason)
    usage_obj = None
    if usage is not None:
        usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[choice], usage=usage_obj)


def _final_usage_chunk(usage):
    """The terminal chunk in the openai stream carries usage and no choices."""
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[], usage=usage_obj)


def _tc_delta(index, *, id=None, name=None, args=None):
    fn = SimpleNamespace(name=name, arguments=args) if (name or args is not None) else None
    return SimpleNamespace(index=index, id=id, function=fn)


def _make_client(scripted_streams):
    """Construct a DSClient whose `_client.chat.completions.create` returns
    the next scripted stream from a list (one stream per iteration).
    """
    client = DSClient(api_key="test", model="deepseek-v4-flash")
    streams_iter = iter(scripted_streams)

    def fake_create(**_kwargs):
        return next(streams_iter)

    client._client = SimpleNamespace(
        chat=SimpleNamespace(
            completions=SimpleNamespace(create=fake_create),
        )
    )
    return client


# ---------- SessionResult shape ------------------------------------------


class TestRunSessionResultShape:
    def test_single_iteration_text_only(self):
        # Stream a plain assistant reply, no tool calls.
        stream = iter([
            _delta_chunk(content="Hello ", finish_reason=None),
            _delta_chunk(content="world.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 10, "completion_tokens": 2,
                                "prompt_tokens_details": {"cached_tokens": 4}}),
        ])
        client = _make_client([stream])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        initial = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "hi"},
        ]
        result = run_session(
            initial, client, registry,
            permissions=permissions,
            max_iters=5,
            renderer=renderer,
        )

        assert isinstance(result, SessionResult)
        assert result.final_text == "Hello world."
        assert result.total_tokens_in == 10
        assert result.total_tokens_out == 2
        assert result.total_cached == 4
        assert result.tool_calls == []
        assert result.finish_reason == "stop"
        assert result.ended_at > 0.0
        # initial_messages must NOT be mutated
        assert initial == [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "hi"},
        ]
        # working list has the assistant message appended
        assert len(result.messages) == 3
        assert result.messages[-1]["role"] == "assistant"
        assert result.messages[-1]["content"] == "Hello world."

    def test_one_tool_call_then_natural_stop(self, tmp_path):
        # Iteration 1: model emits a `view` tool_call.
        # Iteration 2: model returns text and stops.
        target = tmp_path / "hello.txt"
        target.write_text("hi from disk\n")

        stream1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="call_1", name="view")]),
            _delta_chunk(tool_calls=[_tc_delta(0, args=f'{{"path":"{target}"}}')],
                         finish_reason="tool_calls"),
            _final_usage_chunk({"prompt_tokens": 20, "completion_tokens": 5}),
        ])
        stream2 = iter([
            _delta_chunk(content="Read it.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 25, "completion_tokens": 3}),
        ])
        client = _make_client([stream1, stream2])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        initial = [{"role": "system", "content": "sys"},
                   {"role": "user", "content": "look at it"}]
        result = run_session(
            initial, client, registry,
            permissions=permissions,
            max_iters=5,
            renderer=renderer,
        )

        assert result.final_text == "Read it."
        assert result.total_tokens_in == 45  # 20 + 25
        assert result.total_tokens_out == 8  # 5 + 3
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "view"
        assert result.finish_reason == "stop"
        # initial untouched
        assert len(initial) == 2
        # working list: system, user, assistant(tool_calls), tool, assistant(text)
        assert len(result.messages) == 5
        assert result.messages[2]["role"] == "assistant"
        assert "tool_calls" in result.messages[2]
        assert result.messages[3]["role"] == "tool"
        assert "hi from disk" in result.messages[3]["content"]
        assert result.messages[4]["role"] == "assistant"
        assert result.messages[4]["content"] == "Read it."

    def test_default_kwargs_round_trip(self):
        # Confirm `mode` and `parent_session_id` are accepted without coupling.
        stream = iter([
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        client = _make_client([stream])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())
        result = run_session(
            [{"role": "system", "content": "s"}, {"role": "user", "content": "hi"}],
            client, registry,
            permissions=permissions,
            mode="plan",
            parent_session_id="00000000-0000-0000-0000-000000000001",
            renderer=renderer,
        )
        assert result.final_text == "ok"


# ---------- run_turn wrapper preserves in-place mutation ------------------


class TestRunTurnInPlace:
    def test_mutates_caller_messages_like_before(self):
        # The cli.py REPL relies on run_turn mutating its messages list
        # in place. This test mirrors the test_render style of driving
        # the renderer through agent code.
        stream = iter([
            _delta_chunk(content="hello!", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 7, "completion_tokens": 2}),
        ])
        client = _make_client([stream])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        messages = [{"role": "system", "content": "sys"}]
        same_object = messages
        out = run_turn(
            "hello?", messages, client, registry, renderer, permissions,
        )
        # Same object in / same object out (in-place contract).
        assert out is same_object
        assert messages is same_object
        # User input + assistant reply both appended.
        assert len(messages) == 3
        assert messages[1] == {"role": "user", "content": "hello?"}
        assert messages[2]["role"] == "assistant"
        assert messages[2]["content"] == "hello!"

    def test_with_tool_call_mutates_caller_messages_through(self, tmp_path):
        target = tmp_path / "x.txt"
        target.write_text("payload\n")
        stream1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="t1", name="view")]),
            _delta_chunk(tool_calls=[_tc_delta(0, args=f'{{"path":"{target}"}}')],
                         finish_reason="tool_calls"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        stream2 = iter([
            _delta_chunk(content="done", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 2, "completion_tokens": 1}),
        ])
        client = _make_client([stream1, stream2])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        messages = [{"role": "system", "content": "sys"}]
        run_turn("look", messages, client, registry, renderer, permissions)

        # system, user, assistant(tool_calls), tool, assistant("done")
        assert len(messages) == 5
        roles = [m["role"] for m in messages]
        assert roles == ["system", "user", "assistant", "tool", "assistant"]
        assert messages[3]["tool_call_id"] == "t1"
        assert "payload" in messages[3]["content"]


# ---------- Registry.subset ---------------------------------------------


class TestRegistrySubset:
    def test_rejects_unknown_names(self):
        r = default_registry()
        with pytest.raises(ValueError) as exc:
            r.subset({"view", "no_such_tool", "another_missing"})
        msg = str(exc.value)
        # Both missing names appear in the error.
        assert "another_missing" in msg
        assert "no_such_tool" in msg
        # The known name does NOT (only the missing ones are listed).
        assert "view" not in msg

    def test_returns_new_registry_with_only_named_tools(self):
        r = default_registry()
        sub = r.subset({"view", "grep"})
        assert isinstance(sub, Registry)
        # New object — not a shared reference.
        assert sub is not r
        # Only the requested tools are present, in parent-name order.
        assert sub.names() == ["grep", "view"]
        # Parent unchanged.
        assert "bash" in r.names()

    def test_subset_dispatch_works_for_included_tools(self, tmp_path):
        from dsc.client import ToolCall
        target = tmp_path / "f.txt"
        target.write_text("alpha\nbeta\n")
        r = default_registry().subset({"view"})
        call = ToolCall(
            id="x", name="view",
            arguments={"path": str(target)},
            raw_arguments=f'{{"path":"{target}"}}',
        )
        out, meta = r.dispatch(call)
        assert meta["outcome"] == "ok"
        assert "alpha" in out

    def test_subset_dispatch_rejects_excluded_tools(self):
        from dsc.client import ToolCall
        r = default_registry().subset({"view"})
        call = ToolCall(
            id="x", name="bash",
            arguments={"command": "ls"},
            raw_arguments='{"command":"ls"}',
        )
        out, meta = r.dispatch(call)
        # Excluded tools fall through to unknown_tool — same surface as
        # if the parent never had it. This is the contract subagents (P2.1)
        # rely on: a constrained registry refuses out-of-scope tools without
        # a separate guard layer.
        assert meta["outcome"] == "unknown_tool"
        assert out.startswith("Error:")
        assert "unknown tool" in out
        assert "bash" in out

    def test_subset_empty_set_is_legal(self):
        r = default_registry()
        sub = r.subset(set())
        assert sub.names() == []
        assert sub.openai_tools() == []

    def test_subset_preserves_parent_ordering(self):
        # `names()` is sorted; subset(...) walks parent's names(), so the
        # subset's names() is also sorted (subset of the parent's order).
        r = default_registry()
        parent_names = r.names()
        chosen = {parent_names[0], parent_names[2], parent_names[-1]}
        sub = r.subset(chosen)
        assert sub.names() == sorted(chosen)
