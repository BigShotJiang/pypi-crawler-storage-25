"""Tests for `dsc.checkpoints` (P4.3).

Each test uses ``tmp_path`` fixtures for both the workspace and the
shadow-repo home. We monkeypatch ``Path.home`` so the Checkpointer
writes its bare repo into a per-test directory rather than touching
``~/.dsc/checkpoints/``. Real ``git`` is invoked because the
nested-``.git`` rename trick + ``git add -A`` semantics are difficult
to mock faithfully, and the operations are cheap (single-process,
single-commit, ~50-100ms).
"""
from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path

import pytest

from dsc.checkpoints import (
    READ_ONLY_TOOLS,
    Checkpointer,
    CheckpointEntry,
    prune_stale,
)


# ---------- helpers -------------------------------------------------------


def _git_available() -> bool:
    try:
        subprocess.run(
            ["git", "--version"], capture_output=True, check=True, timeout=2,
        )
        return True
    except (FileNotFoundError, subprocess.SubprocessError):
        return False


pytestmark = pytest.mark.skipif(
    not _git_available(),
    reason="git CLI required for shadow-checkpoint tests",
)


@pytest.fixture
def fake_home(tmp_path, monkeypatch) -> Path:
    """Redirect ``~`` to a per-test tmpdir so checkpoint repos don't escape."""
    home = tmp_path / "fakehome"
    home.mkdir()
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: home))
    # Some helpers read $HOME directly; pin both so the test environment
    # is consistent.
    monkeypatch.setenv("HOME", str(home))
    return home


@pytest.fixture
def workspace(tmp_path) -> Path:
    """A scratch workspace populated with one tracked file."""
    ws = tmp_path / "ws"
    ws.mkdir()
    (ws / "a.txt").write_text("one\n", encoding="utf-8")
    return ws


# ---------- snapshot ------------------------------------------------------


class TestSnapshot:
    def test_first_snapshot_creates_bare_repo_and_returns_sha(
        self, workspace, fake_home
    ):
        cp = Checkpointer(workspace)
        sha = cp.snapshot("initial")
        assert sha is not None
        assert len(sha) == 40
        assert cp.shadow_repo.exists()
        # The shadow repo lives in fake_home, NOT in the workspace.
        assert cp.shadow_repo.is_relative_to(fake_home)
        assert not (workspace / ".git").exists()

    def test_snapshot_records_committed_content(self, workspace, fake_home):
        cp = Checkpointer(workspace)
        sha = cp.snapshot("first")
        assert sha is not None
        # Verify the file lives in the snapshot tree by reading it back
        # via `git show`.
        proc = subprocess.run(
            ["git", "--git-dir", str(cp.shadow_repo),
             "show", f"{sha}:a.txt"],
            capture_output=True, text=True, check=True,
        )
        assert proc.stdout == "one\n"

    def test_second_snapshot_after_change_lands_new_commit(
        self, workspace, fake_home
    ):
        cp = Checkpointer(workspace, debounce_ms=0)
        sha1 = cp.snapshot("v1")
        (workspace / "a.txt").write_text("two\n", encoding="utf-8")
        sha2 = cp.snapshot("v2")
        assert sha1 is not None
        assert sha2 is not None
        assert sha1 != sha2

    def test_snapshot_no_change_returns_none(self, workspace, fake_home):
        cp = Checkpointer(workspace, debounce_ms=0)
        sha1 = cp.snapshot("v1")
        # No file change between snapshots; second one should be a no-op.
        sha2 = cp.snapshot("v2")
        assert sha1 is not None
        assert sha2 is None

    def test_uses_synthetic_author(self, workspace, fake_home):
        cp = Checkpointer(workspace, debounce_ms=0)
        sha = cp.snapshot("v1")
        assert sha is not None
        proc = subprocess.run(
            ["git", "--git-dir", str(cp.shadow_repo),
             "log", "-1", "--format=%an <%ae>"],
            capture_output=True, text=True, check=True,
        )
        assert "dsc-checkpoint" in proc.stdout
        assert "checkpoint@dsc.local" in proc.stdout


# ---------- nested .git rename trick --------------------------------------


class TestNestedDotGit:
    def test_renames_nested_dotgit_during_snapshot_and_restores_after(
        self, workspace, fake_home
    ):
        # Simulate a vendored sub-repo by creating a nested .git directory.
        # We don't need it to be a real git repo — git just needs to
        # SEE it during `git add -A` to refuse with "embedded git
        # repository", which the rename trick avoids.
        sub = workspace / "subrepo"
        sub.mkdir()
        nested_git = sub / ".git"
        nested_git.mkdir()
        (nested_git / "HEAD").write_text("ref: refs/heads/main\n")
        (sub / "file.txt").write_text("hi\n")

        cp = Checkpointer(workspace, debounce_ms=0)
        sha = cp.snapshot("with nested")

        # Snapshot must succeed despite the nested .git.
        assert sha is not None
        # After the snapshot, the .git directory must be RESTORED.
        assert nested_git.exists()
        assert nested_git.is_dir()
        # The .git_disabled name must NOT linger.
        assert not (sub / ".git_disabled").exists()
        # And the HEAD content must be unchanged.
        assert (nested_git / "HEAD").read_text() == "ref: refs/heads/main\n"

    def test_does_not_touch_root_dotgit(self, workspace, fake_home):
        # If the user's project itself is a git repo, our checkpointer
        # must NOT rename the project's own .git (only nested ones).
        root_git = workspace / ".git"
        root_git.mkdir()
        (root_git / "HEAD").write_text("ref: refs/heads/main\n")

        cp = Checkpointer(workspace, debounce_ms=0)
        # The snapshot may or may not produce a SHA depending on
        # whether git can add the root .git contents — what matters
        # is that the user's primary .git is intact afterward.
        cp.snapshot("with-root-git")
        assert root_git.exists()
        assert (root_git / "HEAD").read_text() == "ref: refs/heads/main\n"


# ---------- restore -------------------------------------------------------


class TestRestore:
    def test_restore_brings_back_snapshotted_content(self, workspace, fake_home):
        cp = Checkpointer(workspace, debounce_ms=0)
        sha = cp.snapshot("v1")
        assert sha is not None
        # Mutate the workspace.
        (workspace / "a.txt").write_text("MUTATED\n", encoding="utf-8")
        # Restore.
        stats = cp.restore(sha)
        assert stats["sha"] == sha
        assert stats["files_changed"] >= 1
        # File contents revert.
        assert (workspace / "a.txt").read_text() == "one\n"

    def test_restore_files_only_does_not_touch_conversation_state(
        self, workspace, fake_home
    ):
        # files_only=True is a flag for the caller — at the Checkpointer
        # layer it just signals "don't expect us to mess with
        # conversation history." We assert the flag round-trips into
        # the stats dict (callers consult it) and that the file-system
        # restore still happens.
        cp = Checkpointer(workspace, debounce_ms=0)
        sha = cp.snapshot("v1")
        (workspace / "a.txt").write_text("MUTATED\n", encoding="utf-8")

        # Conversation messages live OUTSIDE the Checkpointer; we can't
        # observe them mutating from here — but we can confirm the
        # files_only flag is plumbed through the stats dict.
        stats = cp.restore(sha, files_only=True)
        assert stats["files_only"] is True
        assert (workspace / "a.txt").read_text() == "one\n"

    def test_restore_unknown_sha_returns_no_changes(self, workspace, fake_home):
        cp = Checkpointer(workspace, debounce_ms=0)
        cp.snapshot("v1")
        # An obviously-bogus sha — git will reject. We swallow and return 0.
        stats = cp.restore("0" * 40)
        assert stats["files_changed"] == 0


# ---------- read-only tools never trigger snapshots -----------------------


class TestReadOnlyToolsExclusion:
    @pytest.mark.parametrize(
        "tool_name", ["view", "grep", "glob", "repo_map", "request_rule"],
    )
    def test_session_loop_skips_snapshot_for_read_only_tools(self, tool_name):
        # The session.py dispatch loop consults READ_ONLY_TOOLS as a
        # frozenset before calling Checkpointer.snapshot. We assert the
        # set's membership directly here — the integration coverage is
        # in test_session.py via run_session() flows.
        assert tool_name in READ_ONLY_TOOLS


# ---------- debounce ------------------------------------------------------


class TestDebounce:
    def test_two_snapshots_within_debounce_only_produce_one_commit(
        self, workspace, fake_home
    ):
        # debounce_ms=50 (the default) — we fire two snapshots back to
        # back. The second one should be debounced even though we
        # mutated the workspace.
        cp = Checkpointer(workspace, debounce_ms=50)
        sha1 = cp.snapshot("v1")
        # Mutate the workspace to ensure git WOULD have something to
        # commit if the call wasn't debounced.
        (workspace / "a.txt").write_text("two\n")
        sha2 = cp.snapshot("v2")  # immediately — within 50ms
        assert sha1 is not None
        assert sha2 is None  # debounced

        # Sleep past the debounce window and try again. Now the burst
        # is over and git can commit the still-pending change.
        time.sleep(0.1)
        sha3 = cp.snapshot("v3")
        assert sha3 is not None
        assert sha3 != sha1


# ---------- list ----------------------------------------------------------


class TestList:
    def test_list_returns_recent_entries_newest_first(
        self, workspace, fake_home
    ):
        cp = Checkpointer(workspace, debounce_ms=0)
        cp.snapshot("first")
        (workspace / "a.txt").write_text("two\n")
        cp.snapshot("second")
        (workspace / "a.txt").write_text("three\n")
        cp.snapshot("third")
        entries = cp.list(limit=10)
        assert len(entries) == 3
        # Newest first.
        assert entries[0].message == "third"
        assert entries[1].message == "second"
        assert entries[2].message == "first"
        for e in entries:
            assert isinstance(e, CheckpointEntry)
            assert len(e.sha) == 40

    def test_list_empty_when_no_repo(self, workspace, fake_home):
        cp = Checkpointer(workspace)
        # Never called snapshot — bare repo doesn't exist yet.
        assert cp.list() == []


# ---------- stale prune ---------------------------------------------------


class TestPruneStale:
    def test_prune_removes_repo_for_missing_workspace(
        self, workspace, fake_home, tmp_path
    ):
        # Create a checkpoint for a workspace that we'll then delete.
        ghost_workspace = tmp_path / "ghost"
        ghost_workspace.mkdir()
        (ghost_workspace / "x.txt").write_text("hi\n")
        ghost_cp = Checkpointer(ghost_workspace, debounce_ms=0)
        sha = ghost_cp.snapshot("ghost")
        assert sha is not None
        ghost_repo = ghost_cp.shadow_repo
        assert ghost_repo.exists()

        # Also create a checkpoint for a workspace that still exists.
        live_cp = Checkpointer(workspace, debounce_ms=0)
        live_sha = live_cp.snapshot("live")
        assert live_sha is not None
        live_repo = live_cp.shadow_repo

        # Delete the ghost workspace — its shadow repo is now orphaned.
        import shutil
        shutil.rmtree(ghost_workspace)

        pruned = prune_stale(force=True)
        # The orphan repo should be gone; the live repo should remain.
        assert not ghost_repo.exists()
        assert live_repo.exists()
        # The pruned report names the ghost.
        ghost_hashes = [p["workspace_hash"] for p in pruned]
        assert ghost_cp.workspace_hash in ghost_hashes
        assert live_cp.workspace_hash not in ghost_hashes

    def test_prune_skipped_when_not_due(
        self, workspace, fake_home,
    ):
        # Setup: create a fresh repo + touch the prune marker so the
        # next call thinks "ran recently".
        cp = Checkpointer(workspace, debounce_ms=0)
        cp.snapshot("v1")
        from dsc.checkpoints import _checkpoints_root, _last_prune_marker
        marker = _last_prune_marker()
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text("recent")  # mtime = now

        # Without force=True, the prune is skipped — no work done.
        pruned = prune_stale()
        assert pruned == []
