"""Banner panel snapshot tests.

The banner is rendered via Rich's Panel; we capture the console output
with `color_system=None` so ANSI escapes don't get in the way of plain
text assertions.
"""
from __future__ import annotations

import io

from rich.console import Console

from dsc.cli import _render_banner
from dsc.tools.registry import default_registry


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=80, color_system=None),
        buf,
    )


class TestBanner:
    def test_ask_permission_mode(self):
        console, buf = _captured_console()
        registry = default_registry()
        _render_banner(console, "deepseek-v4-flash", yolo=False, registry=registry)
        out = buf.getvalue()
        assert "fred" in out
        assert "deepseek-v4-flash" in out
        assert "ask-permission" in out
        assert "tools" in out
        assert "/help for commands" in out
        assert "@path" in out
        assert "!cmd" in out

    def test_yolo_mode(self):
        console, buf = _captured_console()
        registry = default_registry()
        _render_banner(console, "deepseek-v4-pro", yolo=True, registry=registry)
        out = buf.getvalue()
        assert "deepseek-v4-pro" in out
        assert "YOLO" in out
        assert "ask-permission" not in out

    def test_tool_count_matches_registry(self):
        console, buf = _captured_console()
        registry = default_registry()
        _render_banner(console, "deepseek-v4-flash", yolo=False, registry=registry)
        out = buf.getvalue()
        # The mode line is "<mode> · N tools"; just confirm the count
        # number that appears matches the registry size.
        assert f"{len(registry.names())} tools" in out
