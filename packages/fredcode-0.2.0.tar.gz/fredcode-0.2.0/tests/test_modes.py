"""Plan/Act mode tests (P2.2).

Covers:
- Dispatcher-level rejection of out-of-mode tool calls in plan mode.
- The `exit_plan_mode` tool flips the session mode and unblocks
  downstream calls.
- Banner snapshot for the plan-mode badge.
- System prompt template selection by mode (light cross-check;
  test_system_prompt.py covers the bullet-level surface).
- Mode persistence within a single iteration: even after a successful
  read tool, plan mode still blocks bash in the same turn.
- An integration-flavored test driving `run_session` end-to-end and
  asserting the `mode_change` event is emitted when the model calls
  `exit_plan_mode`.
"""
from __future__ import annotations

import io
from types import SimpleNamespace

import pytest
from rich.console import Console

from dsc.client import DSClient, ToolCall
from dsc.mode import (
    PLAN_TOOLS,
    current_mode,
    mode_blocked_message,
    reset_mode_state,
    set_current_mode,
    set_mode_state,
)
from dsc.permissions import PermissionPolicy
from dsc.render import Renderer
from dsc.session import run_session
from dsc.tools.registry import default_registry


# ---------- helpers --------------------------------------------------------


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=80, color_system=None),
        buf,
    )


def _bash_call() -> ToolCall:
    return ToolCall(
        id="x", name="bash",
        arguments={"command": "echo hi"},
        raw_arguments='{"command":"echo hi"}',
    )


def _view_call(path: str) -> ToolCall:
    return ToolCall(
        id="v", name="view",
        arguments={"path": path},
        raw_arguments=f'{{"path":"{path}"}}',
    )


def _exit_plan_call(summary: str = "do the thing") -> ToolCall:
    return ToolCall(
        id="e", name="exit_plan_mode",
        arguments={"summary": summary},
        raw_arguments=f'{{"summary":"{summary}"}}',
    )


# ---------- dispatcher gating ---------------------------------------------


class TestDispatcherGating:
    def setup_method(self) -> None:
        # Each test installs its own mode state so cross-test leakage is
        # impossible. The token is the single mechanism for unwiring.
        self._state: list[str] = ["act"]
        self._token = set_mode_state(self._state)

    def teardown_method(self) -> None:
        reset_mode_state(self._token)

    def test_plan_mode_blocks_bash_with_documented_wording(self):
        self._state[0] = "plan"
        reg = default_registry()
        out, meta = reg.dispatch(_bash_call())
        # Outcome surface
        assert meta["outcome"] == "mode_blocked"
        # Wording is part of the model contract
        assert out == mode_blocked_message("bash")
        assert out.startswith("Error:")
        assert "not available in plan mode" in out
        assert "ExitPlanMode" in out

    def test_plan_mode_blocks_str_replace(self):
        self._state[0] = "plan"
        reg = default_registry()
        call = ToolCall(
            id="r", name="str_replace",
            arguments={"path": "/tmp/x", "old_str": "a", "new_str": "b"},
            raw_arguments='{"path":"/tmp/x","old_str":"a","new_str":"b"}',
        )
        out, meta = reg.dispatch(call)
        assert meta["outcome"] == "mode_blocked"
        assert "str_replace" in out

    def test_plan_mode_blocks_create_file(self):
        self._state[0] = "plan"
        reg = default_registry()
        call = ToolCall(
            id="c", name="create_file",
            arguments={"path": "/tmp/x", "content": "hi"},
            raw_arguments='{"path":"/tmp/x","content":"hi"}',
        )
        out, meta = reg.dispatch(call)
        assert meta["outcome"] == "mode_blocked"

    def test_plan_mode_allows_view(self, tmp_path):
        self._state[0] = "plan"
        target = tmp_path / "f.txt"
        target.write_text("alpha\nbeta\n")
        reg = default_registry()
        out, meta = reg.dispatch(_view_call(str(target)))
        assert meta["outcome"] == "ok", out
        assert "alpha" in out

    def test_plan_mode_allows_grep(self, tmp_path):
        self._state[0] = "plan"
        (tmp_path / "f.py").write_text("def needle(): pass\n")
        reg = default_registry()
        call = ToolCall(
            id="g", name="grep",
            arguments={"pattern": "needle", "path": str(tmp_path)},
            raw_arguments=f'{{"pattern":"needle","path":"{tmp_path}"}}',
        )
        out, meta = reg.dispatch(call)
        assert meta["outcome"] == "ok", out
        assert "needle" in out

    def test_plan_mode_allows_glob(self, tmp_path):
        self._state[0] = "plan"
        (tmp_path / "a.py").write_text("")
        (tmp_path / "b.py").write_text("")
        reg = default_registry()
        call = ToolCall(
            id="gb", name="glob",
            arguments={"pattern": "*.py", "path": str(tmp_path)},
            raw_arguments=f'{{"pattern":"*.py","path":"{tmp_path}"}}',
        )
        out, meta = reg.dispatch(call)
        assert meta["outcome"] == "ok", out

    def test_act_mode_does_not_block(self, tmp_path):
        # Sanity: with act mode the dispatcher behaves exactly as before.
        self._state[0] = "act"
        reg = default_registry()
        target = tmp_path / "f.txt"
        target.write_text("hi\n")
        out, meta = reg.dispatch(_view_call(str(target)))
        assert meta["outcome"] == "ok"

    def test_default_no_state_is_act(self):
        # Safety net: tools running outside the REPL (no installed
        # mode state) default to act so historical embeddings keep
        # working unchanged.
        reset_mode_state(self._token)
        # Re-install in the teardown's expected shape so cleanup is
        # idempotent — just point it at a fresh list.
        self._state = ["act"]
        self._token = set_mode_state(self._state)
        assert current_mode() == "act"

    def test_plan_tools_allowlist_includes_required_tools(self):
        # The set is part of the API contract — guard it.
        for name in ("view", "grep", "glob", "exit_plan_mode", "todo_write"):
            assert name in PLAN_TOOLS

    def test_status_cb_fires_with_mode_blocked_status(self):
        from dsc.turn_state import CallStatus
        self._state[0] = "plan"
        reg = default_registry()
        statuses: list[CallStatus] = []
        out, meta = reg.dispatch(
            _bash_call(), status_cb=lambda s: statuses.append(s),
        )
        assert meta["outcome"] == "mode_blocked"
        assert CallStatus.MODE_BLOCKED in statuses
        # Should NOT have transitioned to RUNNING (handler didn't run).
        assert CallStatus.RUNNING not in statuses


# ---------- exit_plan_mode flips the session ------------------------------


class TestExitPlanModeTool:
    def setup_method(self) -> None:
        self._state: list[str] = ["plan"]
        self._token = set_mode_state(self._state)

    def teardown_method(self) -> None:
        reset_mode_state(self._token)

    def test_calling_exit_plan_mode_in_plan_flips_to_act(self):
        reg = default_registry()
        out, meta = reg.dispatch(_exit_plan_call("rewrite cli.py"))
        assert meta["outcome"] == "ok", out
        assert "Plan accepted" in out
        assert "switching to act mode" in out
        assert "rewrite cli.py" in out
        # Mode has been flipped on the shared list.
        assert self._state[0] == "act"
        assert current_mode() == "act"

    def test_subsequent_bash_call_succeeds_after_exit(self):
        reg = default_registry()
        # First call: exit plan mode.
        out1, meta1 = reg.dispatch(_exit_plan_call())
        assert meta1["outcome"] == "ok"
        # Second call (same session): bash is now allowed.
        out2, meta2 = reg.dispatch(ToolCall(
            id="b", name="bash",
            arguments={"command": "echo ok"},
            raw_arguments='{"command":"echo ok"}',
        ))
        assert meta2["outcome"] == "ok", out2
        assert "ok" in out2

    def test_exit_plan_mode_is_callable_in_act_mode_too(self):
        # The tool must always be available so plan mode can exit
        # itself; calling it from act is harmless.
        self._state[0] = "act"
        reg = default_registry()
        out, meta = reg.dispatch(_exit_plan_call("noop"))
        assert meta["outcome"] == "ok"
        assert self._state[0] == "act"  # still act

    def test_set_current_mode_no_op_without_state(self):
        # Defensive: calling set_current_mode without an installed
        # state should not raise — used by handlers run outside a
        # REPL session.
        reset_mode_state(self._token)
        # No state installed now.
        set_current_mode("act")
        # Re-install for teardown idempotency.
        self._state = ["act"]
        self._token = set_mode_state(self._state)


# ---------- mode persistence within a single turn ------------------------


class TestModePersistenceWithinTurn:
    """Plan mode must remain active across multiple dispatcher calls in
    one iteration — a successful `view` doesn't accidentally re-enable
    blocked tools later in the same turn.
    """

    def setup_method(self) -> None:
        self._state: list[str] = ["plan"]
        self._token = set_mode_state(self._state)

    def teardown_method(self) -> None:
        reset_mode_state(self._token)

    def test_view_then_bash_still_blocked(self, tmp_path):
        target = tmp_path / "f.txt"
        target.write_text("hi\n")
        reg = default_registry()
        # Allowed call first.
        out1, meta1 = reg.dispatch(_view_call(str(target)))
        assert meta1["outcome"] == "ok"
        # Bash still blocked: view doesn't lift the gate.
        out2, meta2 = reg.dispatch(_bash_call())
        assert meta2["outcome"] == "mode_blocked"
        assert "ExitPlanMode" in out2

    def test_bash_then_view_then_bash(self, tmp_path):
        # The earlier blocked call shouldn't have side-effects on the
        # state. Run the sequence three calls deep.
        target = tmp_path / "f.txt"
        target.write_text("hi\n")
        reg = default_registry()
        out1, meta1 = reg.dispatch(_bash_call())
        assert meta1["outcome"] == "mode_blocked"
        out2, meta2 = reg.dispatch(_view_call(str(target)))
        assert meta2["outcome"] == "ok"
        out3, meta3 = reg.dispatch(_bash_call())
        assert meta3["outcome"] == "mode_blocked"

    def test_outcome_override_does_not_leak_across_calls(self, tmp_path):
        # Belt-and-suspenders: after a mode_blocked outcome, the next
        # successful call must surface "ok" (not the prior block).
        target = tmp_path / "f.txt"
        target.write_text("hi\n")
        reg = default_registry()
        _, meta1 = reg.dispatch(_bash_call())
        assert meta1["outcome"] == "mode_blocked"
        _, meta2 = reg.dispatch(_view_call(str(target)))
        assert meta2["outcome"] == "ok"


# ---------- banner snapshot ----------------------------------------------


class TestBannerPlanModeBadge:
    """Render-level snapshot that the banner shows the plan badge."""

    def test_banner_act_mode_no_plan_badge(self):
        from dsc.cli import _render_banner
        console, buf = _captured_console()
        reg = default_registry()
        _render_banner(console, "deepseek-v4-flash", yolo=False, registry=reg,
                       plan_mode=False)
        out = buf.getvalue()
        # We render "act" dimly; the loud red "PLAN" should NOT appear.
        assert "PLAN" not in out

    def test_banner_plan_mode_shows_red_plan_badge(self):
        from dsc.cli import _render_banner
        console, buf = _captured_console()
        reg = default_registry()
        _render_banner(console, "deepseek-v4-flash", yolo=False, registry=reg,
                       plan_mode=True)
        out = buf.getvalue()
        assert "PLAN" in out
        # The mode label row is present (banner contract).
        assert "mode" in out

    def test_banner_keeps_other_rows_in_plan_mode(self):
        from dsc.cli import _render_banner
        console, buf = _captured_console()
        reg = default_registry()
        _render_banner(console, "deepseek-v4-pro", yolo=False, registry=reg,
                       plan_mode=True)
        out = buf.getvalue()
        # Existing rows still render.
        assert "deepseek-v4-pro" in out
        assert "ask-permission" in out
        assert f"{len(reg.names())} tools" in out


# ---------- system-prompt template selection (cross-check) ----------------


class TestSystemPromptByMode:
    def test_build_with_plan_differs_from_act(self):
        from dsc.system_prompt import build
        reg = default_registry()
        act = build(reg, mode="act")
        plan = build(reg, mode="plan")
        assert act != plan
        assert "You are in PLAN mode" in plan

    def test_build_default_is_act(self):
        from dsc.system_prompt import build
        reg = default_registry()
        assert build(reg) == build(reg, mode="act")


# ---------- mode_change event firing through tool handler ----------------


class TestExitPlanModeFiresInPipeline:
    """The model-callable handler must flip mode_state before returning,
    so the next dispatcher call sees the new mode.
    """

    def setup_method(self) -> None:
        self._state: list[str] = ["plan"]
        self._token = set_mode_state(self._state)

    def teardown_method(self) -> None:
        reset_mode_state(self._token)

    def test_handler_runs_through_dispatch_pipeline(self):
        # Validate the args shape via dispatch (not direct handler call):
        # the dispatcher is the real integration point.
        reg = default_registry()
        out, meta = reg.dispatch(_exit_plan_call("proceed"))
        assert meta["outcome"] == "ok"
        assert self._state[0] == "act"

    def test_handler_rejects_missing_summary(self):
        reg = default_registry()
        bad = ToolCall(
            id="b", name="exit_plan_mode",
            arguments={},
            raw_arguments="{}",
        )
        out, meta = reg.dispatch(bad)
        # Pydantic's ValidationError pathway gives validation_error.
        assert meta["outcome"] == "validation_error"
        assert "summary" in out.lower()


# ---------- run_session integration --------------------------------------


def _delta_chunk(*, content=None, tool_calls=None, finish_reason=None):
    delta = SimpleNamespace(content=content, tool_calls=tool_calls, reasoning_content=None)
    choice = SimpleNamespace(delta=delta, finish_reason=finish_reason)
    return SimpleNamespace(choices=[choice], usage=None)


def _final_usage_chunk(usage):
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[], usage=usage_obj)


def _tc_delta(index, *, id=None, name=None, args=None):
    fn = SimpleNamespace(name=name, arguments=args) if (name or args is not None) else None
    return SimpleNamespace(index=index, id=id, function=fn)


def _make_client(scripted_streams):
    client = DSClient(api_key="test", model="deepseek-v4-flash")
    streams_iter = iter(scripted_streams)

    def fake_create(**_kwargs):
        return next(streams_iter)

    client._client = SimpleNamespace(
        chat=SimpleNamespace(completions=SimpleNamespace(create=fake_create))
    )
    return client


class _RecordingTracer:
    """Minimal tracer that captures `event(...)` calls for assertion."""

    def __init__(self) -> None:
        self.events: list[tuple[str, dict | None]] = []
        self._turn_idx = -1

    def start_session(self, **_): pass
    def end_session(self, **_): pass

    def start_turn(self, *, user_input=None):
        from dsc.telemetry import TurnHandle
        self._turn_idx += 1
        return TurnHandle(turn_index=self._turn_idx, user_input=user_input)

    def start_iteration(self, turn, *, iteration_index, context_used_est, budget_status,
                        mode="act"):
        from dsc.telemetry.tracer import IterationHandle
        from datetime import datetime, timezone
        return IterationHandle(
            turn_id="", session_id="", turn_index=turn.turn_index,
            iteration_index=iteration_index,
            started_at=datetime.now(timezone.utc),
            user_input=turn.user_input if iteration_index == 0 else None,
            context_used_est=context_used_est, budget_status=budget_status,
            mode=mode,
        )

    def end_iteration(self, it, **_): pass
    def record_tool_call(self, it, **_): pass

    def event(self, kind, *, payload=None, turn=None):
        self.events.append((kind, payload))

    def drain(self, timeout=2.0): pass


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


class TestRunSessionEmitsModeChangeOnExitPlan:
    """End-to-end: a plan-mode session in which the model first attempts
    `bash` (blocked), then calls `exit_plan_mode`, then `bash` (succeeds),
    must emit a `mode_change` event with `source="exit_plan_mode_tool"`.
    """

    def test_full_pipeline_emits_mode_change(self, tmp_path):
        # Iteration 1: model emits an `exit_plan_mode` tool call.
        # Iteration 2: model emits a `view` (bash would also work but
        # `view` keeps the test independent of subprocess plumbing).
        # Iteration 3: model returns text and stops.
        target = tmp_path / "f.txt"
        target.write_text("alpha\n")

        stream1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="e1", name="exit_plan_mode")]),
            _delta_chunk(
                tool_calls=[_tc_delta(0, args='{"summary":"do the thing"}')],
                finish_reason="tool_calls",
            ),
            _final_usage_chunk({"prompt_tokens": 10, "completion_tokens": 1}),
        ])
        stream2 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="v1", name="view")]),
            _delta_chunk(
                tool_calls=[_tc_delta(0, args=f'{{"path":"{target}"}}')],
                finish_reason="tool_calls",
            ),
            _final_usage_chunk({"prompt_tokens": 20, "completion_tokens": 1}),
        ])
        stream3 = iter([
            _delta_chunk(content="done", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 25, "completion_tokens": 1}),
        ])
        client = _make_client([stream1, stream2, stream3])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())
        tracer = _RecordingTracer()

        result = run_session(
            [{"role": "system", "content": "sys"}, {"role": "user", "content": "go"}],
            client, registry,
            permissions=permissions,
            mode="plan",   # session installs its own state with starting mode=plan
            renderer=renderer,
            tracer=tracer,
        )
        assert result.final_text == "done"

        # Find the `mode_change` event(s).
        mode_changes = [(k, p) for (k, p) in tracer.events if k == "mode_change"]
        assert len(mode_changes) == 1, mode_changes
        kind, payload = mode_changes[0]
        assert payload["from"] == "plan"
        assert payload["to"] == "act"
        assert payload["source"] == "exit_plan_mode_tool"

    def test_mode_blocked_outcome_routes_through_dispatch(self, tmp_path):
        # Iteration 1: model emits a `bash` tool call (blocked).
        # Iteration 2: text response and stop.
        stream1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="b1", name="bash")]),
            _delta_chunk(
                tool_calls=[_tc_delta(0, args='{"command":"ls"}')],
                finish_reason="tool_calls",
            ),
            _final_usage_chunk({"prompt_tokens": 10, "completion_tokens": 1}),
        ])
        stream2 = iter([
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 12, "completion_tokens": 1}),
        ])
        client = _make_client([stream1, stream2])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        result = run_session(
            [{"role": "system", "content": "sys"}, {"role": "user", "content": "go"}],
            client, registry,
            permissions=permissions,
            mode="plan",
            renderer=renderer,
        )
        # Tool message body contains the documented block string.
        tool_msg = [m for m in result.messages if m.get("role") == "tool"]
        assert len(tool_msg) == 1
        assert "not available in plan mode" in tool_msg[0]["content"]
        assert "ExitPlanMode" in tool_msg[0]["content"]
