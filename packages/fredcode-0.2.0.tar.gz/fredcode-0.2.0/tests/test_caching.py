"""P1.2 prompt caching: byte-stable prefix + CacheableRequest formatters.

These tests cover the cache-breaker fixes (system prompt date, tool-schema
serialization) and the new CacheableRequest abstraction. Wire-level fakes
substitute the openai SDK's chat.completions.create.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from dsc.cache_segments import (
    CacheableRequest,
    Segment,
    cacheable_prefix_size_estimate,
)
from dsc.client import DSClient, ToolCall, messages_to_cacheable_request
from dsc.system_prompt import build as build_system_prompt
from dsc.telemetry import PgTracer
from dsc.tools.registry import Registry, default_registry


# ---------- fakes ----------------------------------------------------------


class _FakeChunk:
    """Minimal SDK chunk shape for streaming."""
    def __init__(self, **fields):
        self.choices = fields.pop("choices", [])
        self.usage = fields.pop("usage", None)


def _usage(prompt: int, completion: int, cached: int = 0) -> SimpleNamespace:
    """SDK usage object — has model_dump() so the StreamSession can serialize."""
    raw = {
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "prompt_tokens_details": {"cached_tokens": cached},
    }
    obj = SimpleNamespace(**raw)
    obj.model_dump = lambda: raw
    return obj


def _stop_choice(text: str) -> SimpleNamespace:
    delta = SimpleNamespace(content=text, tool_calls=None, reasoning_content=None)
    return SimpleNamespace(delta=delta, finish_reason="stop")


def _stream_for(text: str, *, prompt_tokens=100, completion_tokens=10, cached=0):
    """Yield a one-chunk text stream then a usage chunk."""
    yield _FakeChunk(choices=[_stop_choice(text)])
    yield _FakeChunk(choices=[], usage=_usage(prompt_tokens, completion_tokens, cached))


class _RecordingClient:
    """Captures kwargs of every chat.completions.create call."""
    def __init__(self) -> None:
        self.calls: list[dict] = []

    def __call__(self, **kwargs):
        self.calls.append(kwargs)
        # Return an iterator that mimics the streaming SDK return.
        return _stream_for("ok", cached=kwargs.pop("__cached", 0))


# ---------- system prompt date stability ----------------------------------


class TestSystemPromptDate:
    def test_today_arg_is_threaded(self):
        reg = default_registry()
        a = build_system_prompt(reg, today="2026-04-30")
        b = build_system_prompt(reg, today="2026-05-01")
        assert "2026-04-30" in a
        assert "2026-05-01" in b
        assert a != b

    def test_today_default_uses_date_today(self, monkeypatch):
        # When `today` is None, build() falls back to date.today() — verify
        # we don't accidentally drop that fallback.
        from datetime import date
        reg = default_registry()
        out = build_system_prompt(reg, today=None)
        assert date.today().isoformat() in out

    def test_same_today_produces_byte_identical_output(self):
        # The whole point: same `today` -> same bytes.
        reg = default_registry()
        a = build_system_prompt(reg, today="2026-04-30")
        b = build_system_prompt(reg, today="2026-04-30")
        assert a == b
        assert a.encode("utf-8") == b.encode("utf-8")


# ---------- tool-schema byte stability ------------------------------------


class TestToolSchemaStability:
    def test_openai_tools_cached_per_registry(self):
        reg = default_registry()
        # Identity-equal across calls — proves caching is wired.
        first = reg.openai_tools()
        second = reg.openai_tools()
        assert first is second

    def test_openai_tools_bytes_stable_across_two_registries(self):
        # Two freshly-built registries produce byte-identical output —
        # which is what DeepSeek's prefix cache needs across REPL restarts.
        a = json.dumps(default_registry().openai_tools(), sort_keys=True)
        b = json.dumps(default_registry().openai_tools(), sort_keys=True)
        assert a == b

    def test_openai_tools_canonical_json_normalizes_key_order(self):
        # If a tool's pydantic schema produces keys in non-sorted order
        # (a real risk on pydantic version bumps), the registry must
        # still emit a sorted-keys representation.
        reg = default_registry()
        tools = reg.openai_tools()
        for t in tools:
            params = t["function"]["parameters"]
            # The top-level parameters dict has sorted keys after canonical
            # round-trip.
            assert list(params.keys()) == sorted(params.keys())

    def test_openai_tools_invalidated_on_register(self):
        from dsc.tools import view as view_tool
        reg = Registry()
        reg.register(view_tool.tool)
        first = reg.openai_tools()
        # Re-register a different tool: cache must reset.
        from dsc.tools import bash as bash_tool
        reg.register(bash_tool.tool)
        second = reg.openai_tools()
        assert first is not second
        assert len(second) == 2


# ---------- snapshot for ordering drift -----------------------------------


_SNAPSHOT_PATH = Path(__file__).parent / "fixtures" / "tool_schema_snapshot.json"


class TestToolSchemaSnapshot:
    def test_snapshot_matches(self):
        """Fixture exists to detect future ordering drift across pydantic
        / Python upgrades. Update it deliberately when tools change.
        """
        reg = default_registry()
        current = reg.openai_tools()
        if not _SNAPSHOT_PATH.exists():
            _SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            _SNAPSHOT_PATH.write_text(
                json.dumps(current, sort_keys=True, indent=2) + "\n"
            )
            pytest.skip("Wrote initial snapshot; re-run.")
        expected = json.loads(_SNAPSHOT_PATH.read_text())
        # Compare as sorted-key JSON to make this resilient against any
        # remaining ordering wobble — the cache-stability guarantee is the
        # round-trip via canonical_json, which sorts keys.
        a = json.dumps(current, sort_keys=True)
        b = json.dumps(expected, sort_keys=True)
        assert a == b, (
            "Tool schema drifted; if intentional, regenerate the snapshot at "
            f"{_SNAPSHOT_PATH}"
        )


# ---------- two-call wire stability ---------------------------------------


class TestStreamChatBytesStable:
    def _client_with_recorder(self) -> tuple[DSClient, _RecordingClient]:
        rec = _RecordingClient()
        with patch.object(DSClient, "__init__", lambda self, **k: None):
            c = DSClient()
        c.model = "deepseek-v4-flash"
        c._client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=rec),
            ),
        )
        # __init__ is patched out; restore the retry-hook attrs that
        # `stream_chat` reads (set to None by DSClient.__init__ in production).
        c.on_retry = None
        c.on_abort = None
        c.correlation_session_id = None
        c.correlation_turn_id = None
        return c, rec

    def test_two_calls_have_identical_system_and_tools_bytes(self):
        c, rec = self._client_with_recorder()
        reg = default_registry()
        sys_prompt = build_system_prompt(reg, today="2026-04-30")
        msgs1 = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": "first task"},
        ]
        msgs2 = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": "first task"},
            {"role": "assistant", "content": "ok"},
            {"role": "user", "content": "second task"},
        ]
        s1 = c.stream_chat(msgs1, tools=reg.openai_tools())
        list(iter(s1))  # drain
        s2 = c.stream_chat(msgs2, tools=reg.openai_tools())
        list(iter(s2))

        assert len(rec.calls) == 2
        # System message bytes identical between calls.
        sys1 = rec.calls[0]["messages"][0]
        sys2 = rec.calls[1]["messages"][0]
        assert sys1["role"] == "system"
        assert sys2["role"] == "system"
        assert sys1["content"] == sys2["content"]
        assert sys1["content"].encode("utf-8") == sys2["content"].encode("utf-8")
        # Tools array bytes identical between calls.
        t1 = json.dumps(rec.calls[0]["tools"], sort_keys=True)
        t2 = json.dumps(rec.calls[1]["tools"], sort_keys=True)
        assert t1 == t2

    def test_cacheable_request_passes_through(self):
        c, rec = self._client_with_recorder()
        reg = default_registry()
        sys_prompt = build_system_prompt(reg, today="2026-04-30")
        req = CacheableRequest(
            system_segments=[Segment(content=sys_prompt, cacheable=True)],
            tail_messages=[{"role": "user", "content": "hi"}],
        )
        s = c.stream_chat(req, tools=reg.openai_tools())
        list(iter(s))
        sent = rec.calls[0]["messages"]
        assert sent[0]["role"] == "system"
        assert sent[0]["content"] == sys_prompt
        assert sent[1] == {"role": "user", "content": "hi"}


# ---------- CacheableRequest formatters -----------------------------------


class TestCacheableRequestFormatters:
    def test_for_deepseek_concatenates_system_segments_no_markers(self):
        req = CacheableRequest(
            system_segments=[
                Segment(content="A", cacheable=True),
                Segment(content="B", cacheable=True),
            ],
            tail_messages=[{"role": "user", "content": "hi"}],
        )
        out = req.for_deepseek()
        assert out[0] == {"role": "system", "content": "AB"}
        assert out[1] == {"role": "user", "content": "hi"}
        # No cache_control markers anywhere — DeepSeek doesn't use them.
        assert all("cache_control" not in str(m) for m in out)

    def test_for_deepseek_empty_segments_skips_system(self):
        req = CacheableRequest(
            system_segments=[],
            tail_messages=[{"role": "user", "content": "hi"}],
        )
        out = req.for_deepseek()
        assert out == [{"role": "user", "content": "hi"}]

    def test_for_anthropic_marks_last_cacheable_segment(self):
        req = CacheableRequest(
            system_segments=[
                Segment(content="A", cacheable=True),
                Segment(content="B", cacheable=True),
                Segment(content="C", cacheable=False),
            ],
            tail_messages=[{"role": "user", "content": "hi"}],
        )
        wrapped = req.for_anthropic()
        assert len(wrapped) == 1
        sys_blocks = wrapped[0]["system"]
        # B was the last cacheable -> only B has the marker.
        assert sys_blocks[0] == {"type": "text", "text": "A"}
        assert sys_blocks[1] == {
            "type": "text", "text": "B",
            "cache_control": {"type": "ephemeral"},
        }
        assert sys_blocks[2] == {"type": "text", "text": "C"}
        assert wrapped[0]["messages"] == [{"role": "user", "content": "hi"}]

    def test_for_anthropic_no_marker_when_no_cacheable(self):
        req = CacheableRequest(
            system_segments=[Segment(content="X", cacheable=False)],
            tail_messages=[],
        )
        wrapped = req.for_anthropic()
        sys_blocks = wrapped[0]["system"]
        assert sys_blocks == [{"type": "text", "text": "X"}]
        assert "cache_control" not in sys_blocks[0]

    def test_messages_to_cacheable_request_splits_system_and_tail(self):
        msgs = [
            {"role": "system", "content": "S"},
            {"role": "user", "content": "U"},
            {"role": "assistant", "content": "A"},
        ]
        req = messages_to_cacheable_request(msgs)
        assert len(req.system_segments) == 1
        assert req.system_segments[0].content == "S"
        assert req.tail_messages == [
            {"role": "user", "content": "U"},
            {"role": "assistant", "content": "A"},
        ]

    def test_messages_to_cacheable_request_handles_no_system(self):
        msgs = [{"role": "user", "content": "U"}]
        req = messages_to_cacheable_request(msgs)
        assert req.system_segments == []
        assert req.tail_messages == msgs


# ---------- prefix size estimate ------------------------------------------


class TestCacheablePrefixEstimate:
    def test_zero_for_empty(self):
        assert cacheable_prefix_size_estimate([]) == 0

    def test_zero_for_only_system_and_first_user(self):
        # No prior turn yet — nothing to "cache" from a prefix POV.
        msgs = [
            {"role": "system", "content": "S"},
            {"role": "user", "content": "U"},
        ]
        # The prefix is bytes of [system] (the segment before the only user).
        assert cacheable_prefix_size_estimate(msgs) == len("S".encode("utf-8"))

    def test_grows_after_more_turns(self):
        # Multi-turn: prefix is everything before the LAST user message.
        msgs = [
            {"role": "system", "content": "SYS"},
            {"role": "user", "content": "u1"},
            {"role": "assistant", "content": "a1"},
            {"role": "tool", "content": "t1"},
            {"role": "user", "content": "u2"},
        ]
        size = cacheable_prefix_size_estimate(msgs)
        assert size == sum(len(s.encode("utf-8")) for s in ("SYS", "u1", "a1", "t1"))


# ---------- cache_stats event emission ------------------------------------


class _FakeWriter:
    def __init__(self) -> None:
        self.envelopes: list[tuple[str, dict]] = []
        self.drained = False

    def submit(self, kind: str, params: dict) -> None:
        self.envelopes.append((kind, params))

    def drain(self, timeout: float = 2.0) -> None:
        self.drained = True

    def by_kind(self, kind: str) -> list[dict]:
        return [p for k, p in self.envelopes if k == kind]


class TestCacheStatsEvent:
    def test_emit_cache_stats_writes_event_with_correct_hit_rate(self):
        from dsc.session import _emit_cache_stats
        w = _FakeWriter()
        t = PgTracer(w)
        t.start_session(model="m", base_url="b", yolo=False, one_shot=True,
                        system_prompt="s", registry_names=[], registry_perms={})
        turn = t.start_turn(user_input="hi")
        usage = {
            "prompt_tokens": 1000,
            "completion_tokens": 50,
            "prompt_tokens_details": {"cached_tokens": 800},
        }
        _emit_cache_stats(t, turn, usage=usage, prefix_size_est=4096)
        evs = w.by_kind("event")
        cache_stats = [e for e in evs if e["kind"] == "cache_stats"]
        assert len(cache_stats) == 1
        payload = json.loads(cache_stats[0]["payload"])
        assert payload["cached"] == 800
        assert payload["non_cached"] == 200
        assert payload["hit_rate"] == 0.8
        assert payload["prefix_size_est"] == 4096

    def test_emit_cache_stats_no_op_when_usage_missing(self):
        from dsc.session import _emit_cache_stats
        w = _FakeWriter()
        t = PgTracer(w)
        t.start_session(model="m", base_url="b", yolo=False, one_shot=True,
                        system_prompt="s", registry_names=[], registry_perms={})
        turn = t.start_turn(user_input="hi")
        _emit_cache_stats(t, turn, usage=None, prefix_size_est=0)
        assert w.by_kind("event") == []

    def test_emit_cache_stats_zero_prompt_yields_zero_rate(self):
        # Defensive: prompt_tokens=0 must not divide-by-zero.
        from dsc.session import _emit_cache_stats
        w = _FakeWriter()
        t = PgTracer(w)
        t.start_session(model="m", base_url="b", yolo=False, one_shot=True,
                        system_prompt="s", registry_names=[], registry_perms={})
        turn = t.start_turn(user_input="hi")
        usage = {"prompt_tokens": 0, "completion_tokens": 0}
        _emit_cache_stats(t, turn, usage=usage, prefix_size_est=0)
        payload = json.loads(w.by_kind("event")[0]["payload"])
        assert payload["hit_rate"] == 0.0
        assert payload["cached"] == 0


# ---------- renderer UX diffs --------------------------------------------


class TestRendererCacheUX:
    def _silent_console(self):
        import io
        from rich.console import Console
        return Console(file=io.StringIO(), force_terminal=False, width=120, color_system=None)

    def _captured_console(self):
        import io
        from rich.console import Console
        buf = io.StringIO()
        return (
            Console(file=buf, force_terminal=False, width=120, color_system=None),
            buf,
        )

    def test_cost_summary_includes_hit_rate(self):
        from dsc.render import Renderer
        r = Renderer(console=self._silent_console(), stream=False)
        r.show_usage(
            {"prompt_tokens": 1000, "completion_tokens": 10,
             "prompt_tokens_details": {"cached_tokens": 800}},
            "deepseek-v4-flash",
        )
        s = r.cost_summary()
        assert "cache hit rate" in s
        assert "80.0%" in s

    def test_cost_summary_omits_hit_rate_when_no_cached(self):
        from dsc.render import Renderer
        r = Renderer(console=self._silent_console(), stream=False)
        r.show_usage(
            {"prompt_tokens": 1000, "completion_tokens": 10},
            "deepseek-v4-flash",
        )
        s = r.cost_summary()
        assert "cache hit rate" not in s

    def test_show_usage_emits_dim_cached_line_when_majority_cached(self):
        from dsc.render import Renderer
        console, buf = self._captured_console()
        r = Renderer(console=console, stream=False)
        r.show_usage(
            {"prompt_tokens": 14_000, "completion_tokens": 100,
             "prompt_tokens_details": {"cached_tokens": 12_000}},
            "deepseek-v4-flash",
        )
        out = buf.getvalue()
        assert "cached" in out
        # ~85% should appear in the dim status line.
        assert "85%" in out or "86%" in out

    def test_show_usage_skips_dim_cached_line_below_threshold(self):
        from dsc.render import Renderer
        console, buf = self._captured_console()
        r = Renderer(console=console, stream=False)
        r.show_usage(
            {"prompt_tokens": 1000, "completion_tokens": 10,
             "prompt_tokens_details": {"cached_tokens": 100}},
            "deepseek-v4-flash",
        )
        out = buf.getvalue()
        # Headline still mentions cached=, but no separate dim line with %.
        assert "(86%)" not in out and "(50%)" not in out
