"""P2.3 — multi-model routing (main / editor / weak slots).

Covers four surfaces:
  1. `DSClient.with_model(name)` returns a shallow copy with a new model
     name but the same underlying `_client` (HTTP session is reused).
  2. `dsc.config.load_model_config()` reads the env vars correctly,
     including the FRED_/DSC_ alias precedence and the
     editor-defaults-to-main fallback.
  3. The `/model` slash command's slot-aware extension. Handler is
     `dsc.cli._handle_model_slash` — we drive it directly with a
     stub tracer + an in-memory Console so we don't have to spin up
     the typer REPL.
  4. The per-iteration `model_routed` event fires from `run_session`
     with `slot="main"` and the current `client.model`.
"""
from __future__ import annotations

import io
from types import SimpleNamespace

import pytest
from rich.console import Console

from dsc.cli import _format_model_line, _handle_model_slash
from dsc.client import DEFAULT_MODEL, DSClient
from dsc.config import ModelConfig, load_model_config
from dsc.permissions import PermissionPolicy
from dsc.render import Renderer
from dsc.session import run_session
from dsc.telemetry import NullTracer
from dsc.tools.registry import default_registry


# ---------- shared helpers ------------------------------------------------


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=120, color_system=None),
        buf,
    )


class _CapturingTracer(NullTracer):
    """Lightweight tracer stub that records every `event(...)` call.

    Mirrors the pattern in test_todo_injection.py — we only care about
    the `(kind, payload)` tuples, so other Tracer methods stay no-op.
    """

    def __init__(self):
        self.events: list[tuple[str, dict | None]] = []

    def event(self, kind, *, payload=None, turn=None):
        self.events.append((kind, payload))


def _delta_chunk(*, content=None, tool_calls=None, finish_reason=None, usage=None):
    delta = SimpleNamespace(content=content, tool_calls=tool_calls, reasoning_content=None)
    choice = SimpleNamespace(delta=delta, finish_reason=finish_reason)
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u) if usage is not None else None
    return SimpleNamespace(choices=[choice], usage=usage_obj)


def _final_usage_chunk(usage):
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[], usage=usage_obj)


def _scripted_client(streams: list) -> DSClient:
    """DSClient whose openai stub returns the next scripted stream per call."""
    client = DSClient(api_key="test", model="deepseek-v4-flash")
    streams_iter = iter(streams)

    def fake_create(**_kwargs):
        return next(streams_iter)

    client._client = SimpleNamespace(
        chat=SimpleNamespace(
            completions=SimpleNamespace(create=fake_create),
        )
    )
    return client


# ---------- DSClient.with_model -------------------------------------------


class TestWithModel:
    def test_returns_copy_with_new_model_and_shared_http(self):
        original = DSClient(api_key="test", model="deepseek-v4-flash")
        twin = original.with_model("deepseek-coder-v2-lite")

        # Different objects, different model names.
        assert twin is not original
        assert original.model == "deepseek-v4-flash"
        assert twin.model == "deepseek-coder-v2-lite"

        # Underlying openai client is the SAME instance — HTTP session
        # reuse is the whole point of `with_model`.
        assert twin._client is original._client
        # base_url is also reused (same provider).
        assert twin.base_url == original.base_url

    def test_original_unchanged_after_with_model(self):
        original = DSClient(api_key="test", model="deepseek-v4-flash")
        original.on_retry = lambda *a, **k: None  # type: ignore[assignment]
        original_retry = original.on_retry
        _ = original.with_model("other-model")

        # Mutating the twin must not bleed back into the original.
        assert original.model == "deepseek-v4-flash"
        assert original.on_retry is original_retry

    def test_callbacks_shared_by_default(self):
        # `with_model` is a shallow copy — caller-installed retry/abort
        # callbacks should still fire on the cloned client without manual
        # re-installation. This matches the architect-mode/editor flow.
        original = DSClient(api_key="test", model="deepseek-v4-flash")
        retry_calls: list[tuple] = []
        abort_calls: list[tuple] = []
        original.on_retry = lambda a, e, b: retry_calls.append((a, e, b))
        original.on_abort = lambda e, r, ms: abort_calls.append((e, r, ms))

        twin = original.with_model("editor-model")
        assert twin.on_retry is original.on_retry
        assert twin.on_abort is original.on_abort


# ---------- load_model_config --------------------------------------------


class TestLoadModelConfig:
    def test_defaults_when_env_unset(self, monkeypatch):
        # Clear all four env-name pairs the loader reads.
        for name in (
            "FRED_MAIN_MODEL", "DSC_MAIN_MODEL",
            "FRED_EDITOR_MODEL", "DSC_EDITOR_MODEL",
            "FRED_WEAK_MODEL", "DSC_WEAK_MODEL",
        ):
            monkeypatch.delenv(name, raising=False)

        cfg = load_model_config()
        assert cfg.main_model == DEFAULT_MODEL
        # editor & weak default to main when not explicitly set.
        assert cfg.editor_model == DEFAULT_MODEL
        assert cfg.weak_model == DEFAULT_MODEL

    def test_fred_prefix_overrides_main(self, monkeypatch):
        monkeypatch.delenv("DSC_MAIN_MODEL", raising=False)
        monkeypatch.setenv("FRED_MAIN_MODEL", "my-main-model")
        monkeypatch.delenv("FRED_EDITOR_MODEL", raising=False)
        monkeypatch.delenv("DSC_EDITOR_MODEL", raising=False)
        monkeypatch.delenv("FRED_WEAK_MODEL", raising=False)
        monkeypatch.delenv("DSC_WEAK_MODEL", raising=False)

        cfg = load_model_config()
        assert cfg.main_model == "my-main-model"
        # editor & weak inherit the overridden main.
        assert cfg.editor_model == "my-main-model"
        assert cfg.weak_model == "my-main-model"

    def test_dsc_prefix_used_when_fred_unset(self, monkeypatch):
        # Transitional support: DSC_* still works when FRED_* is unset.
        monkeypatch.delenv("FRED_MAIN_MODEL", raising=False)
        monkeypatch.setenv("DSC_MAIN_MODEL", "legacy-main")
        monkeypatch.delenv("FRED_EDITOR_MODEL", raising=False)
        monkeypatch.delenv("DSC_EDITOR_MODEL", raising=False)
        monkeypatch.delenv("FRED_WEAK_MODEL", raising=False)
        monkeypatch.delenv("DSC_WEAK_MODEL", raising=False)

        cfg = load_model_config()
        assert cfg.main_model == "legacy-main"

    def test_fred_wins_over_dsc_when_both_set(self, monkeypatch):
        # Per the rename: prefer FRED_* over DSC_*.
        monkeypatch.setenv("FRED_MAIN_MODEL", "fred-wins")
        monkeypatch.setenv("DSC_MAIN_MODEL", "dsc-loses")
        monkeypatch.delenv("FRED_EDITOR_MODEL", raising=False)
        monkeypatch.delenv("DSC_EDITOR_MODEL", raising=False)
        monkeypatch.delenv("FRED_WEAK_MODEL", raising=False)
        monkeypatch.delenv("DSC_WEAK_MODEL", raising=False)

        cfg = load_model_config()
        assert cfg.main_model == "fred-wins"

    def test_three_independent_slots(self, monkeypatch):
        monkeypatch.setenv("FRED_MAIN_MODEL", "main-X")
        monkeypatch.setenv("FRED_EDITOR_MODEL", "editor-X")
        monkeypatch.setenv("FRED_WEAK_MODEL", "weak-X")

        cfg = load_model_config()
        assert cfg.main_model == "main-X"
        assert cfg.editor_model == "editor-X"
        assert cfg.weak_model == "weak-X"

    def test_called_at_call_time_not_import(self, monkeypatch):
        # Test that env mutations between calls take effect on the next
        # `load_model_config()` — the `/model` slash relies on this.
        monkeypatch.delenv("FRED_MAIN_MODEL", raising=False)
        monkeypatch.delenv("DSC_MAIN_MODEL", raising=False)
        cfg1 = load_model_config()
        assert cfg1.main_model == DEFAULT_MODEL

        monkeypatch.setenv("FRED_MAIN_MODEL", "fresh-main")
        cfg2 = load_model_config()
        assert cfg2.main_model == "fresh-main"

    def test_for_slot_lookup(self):
        cfg = ModelConfig(main_model="m", editor_model="e", weak_model="w")
        assert cfg.for_slot("main") == "m"
        assert cfg.for_slot("editor") == "e"
        assert cfg.for_slot("weak") == "w"
        with pytest.raises(ValueError):
            cfg.for_slot("bogus")


# ---------- /model slash command -----------------------------------------


class TestModelSlash:
    """Drive `_handle_model_slash` directly. The cli.py REPL just wraps
    it; testing the helper covers all branches without typer.
    """

    def _stub(self, *, main="main-A", editor="editor-A", weak="weak-A"):
        client = DSClient(api_key="test", model=main)
        cfg = ModelConfig(main_model=main, editor_model=editor, weak_model=weak)
        console, buf = _captured_console()
        tracer = _CapturingTracer()
        return client, cfg, console, buf, tracer

    # -- no-arg form: print all three slots --------------------------------

    def test_no_arg_prints_three_slots(self):
        client, cfg, console, buf, tracer = self._stub(
            main="m1", editor="e1", weak="w1",
        )
        new_cfg = _handle_model_slash(
            None, client=client, model_cfg=cfg, console=console, tracer=tracer,
        )
        out = buf.getvalue()
        # All three slot names appear in the output.
        assert "main" in out and "m1" in out
        assert "editor" in out and "e1" in out
        assert "weak" in out and "w1" in out
        # No mutation.
        assert new_cfg == cfg
        assert client.model == "m1"
        # `slash_command` event fires; no `model_routed` since nothing changed.
        kinds = [k for k, _ in tracer.events]
        assert kinds == ["slash_command"]
        assert tracer.events[0][1]["changed"] is False

    # -- `/model main <name>` ---------------------------------------------

    def test_slot_main_swaps_client_model(self):
        client, cfg, console, buf, tracer = self._stub()
        new_cfg = _handle_model_slash(
            "main new-main", client=client, model_cfg=cfg,
            console=console, tracer=tracer,
        )
        # client.model is the main slot — must reflect the new name so
        # the agent loop's next `stream_chat` routes correctly.
        assert client.model == "new-main"
        assert new_cfg.main_model == "new-main"
        # editor + weak unchanged.
        assert new_cfg.editor_model == cfg.editor_model
        assert new_cfg.weak_model == cfg.weak_model
        # Two events: slash_command (with slot=main, changed=True),
        # then model_routed (slot=main, reason=user_/model).
        kinds = [k for k, _ in tracer.events]
        assert kinds == ["slash_command", "model_routed"]
        sc = tracer.events[0][1]
        mr = tracer.events[1][1]
        assert sc["slot"] == "main"
        assert sc["model"] == "new-main"
        assert sc["changed"] is True
        assert mr == {
            "slot": "main", "model": "new-main", "reason": "user_/model",
        }

    # -- `/model editor <name>` -------------------------------------------

    def test_slot_editor_updates_cfg_only(self):
        client, cfg, console, buf, tracer = self._stub()
        original_main = client.model
        new_cfg = _handle_model_slash(
            "editor my-editor", client=client, model_cfg=cfg,
            console=console, tracer=tracer,
        )
        # client.model should NOT change — editor calls happen elsewhere.
        assert client.model == original_main
        assert new_cfg.editor_model == "my-editor"
        # main + weak unchanged.
        assert new_cfg.main_model == cfg.main_model
        assert new_cfg.weak_model == cfg.weak_model
        kinds = [k for k, _ in tracer.events]
        assert kinds == ["slash_command", "model_routed"]
        assert tracer.events[1][1]["slot"] == "editor"

    # -- `/model weak <name>` ---------------------------------------------

    def test_slot_weak_updates_cfg_only(self):
        client, cfg, console, buf, tracer = self._stub()
        original_main = client.model
        new_cfg = _handle_model_slash(
            "weak my-weak", client=client, model_cfg=cfg,
            console=console, tracer=tracer,
        )
        assert client.model == original_main
        assert new_cfg.weak_model == "my-weak"
        assert new_cfg.main_model == cfg.main_model
        assert new_cfg.editor_model == cfg.editor_model
        kinds = [k for k, _ in tracer.events]
        assert kinds == ["slash_command", "model_routed"]
        assert tracer.events[1][1]["slot"] == "weak"

    # -- backwards compat: `/model <name>` (no slot keyword) --------------

    def test_single_arg_swaps_main_for_backwards_compat(self):
        client, cfg, console, buf, tracer = self._stub(
            main="old-main", editor="some-editor", weak="some-weak",
        )
        new_cfg = _handle_model_slash(
            "deepseek-v4-pro", client=client, model_cfg=cfg,
            console=console, tracer=tracer,
        )
        # Single-token, non-slot form swaps main and leaves the others alone.
        assert client.model == "deepseek-v4-pro"
        assert new_cfg.main_model == "deepseek-v4-pro"
        assert new_cfg.editor_model == "some-editor"
        assert new_cfg.weak_model == "some-weak"
        # `slash_command` payload retains the PR3 shape (no `slot` key
        # for the backwards-compat form), then `model_routed` fires.
        sc, mr = tracer.events[0][1], tracer.events[1][1]
        assert "slot" not in sc
        assert sc["model"] == "deepseek-v4-pro"
        assert sc["previous"] == "old-main"
        assert sc["changed"] is True
        assert mr == {
            "slot": "main", "model": "deepseek-v4-pro", "reason": "user_/model",
        }

    def test_backwards_compat_no_change_skips_model_routed(self):
        # If the user types the same model, no model_routed event fires.
        client, cfg, console, buf, tracer = self._stub(main="same-main")
        new_cfg = _handle_model_slash(
            "same-main", client=client, model_cfg=cfg,
            console=console, tracer=tracer,
        )
        assert client.model == "same-main"
        kinds = [k for k, _ in tracer.events]
        assert kinds == ["slash_command"]
        assert tracer.events[0][1]["changed"] is False

    def test_slot_keyword_without_name_prints_usage(self):
        client, cfg, console, buf, tracer = self._stub()
        new_cfg = _handle_model_slash(
            "main", client=client, model_cfg=cfg,
            console=console, tracer=tracer,
        )
        # No mutation, usage error printed, single slash_command event.
        assert new_cfg == cfg
        assert client.model == cfg.main_model
        out = buf.getvalue()
        assert "usage" in out.lower()
        kinds = [k for k, _ in tracer.events]
        assert kinds == ["slash_command"]
        assert tracer.events[0][1].get("error") == "missing_name"


# ---------- banner format ------------------------------------------------


class TestBannerFormat:
    def test_collapsed_when_all_slots_match(self):
        cfg = ModelConfig(main_model="x", editor_model="x", weak_model="x")
        # Single label — no parenthesized expansion.
        assert _format_model_line(cfg) == "x"

    def test_expanded_when_editor_differs(self):
        cfg = ModelConfig(main_model="m", editor_model="e", weak_model="m")
        line = _format_model_line(cfg)
        assert "m" in line
        assert "editor: e" in line
        assert "weak:" not in line

    def test_expanded_when_weak_differs(self):
        cfg = ModelConfig(main_model="m", editor_model="m", weak_model="w")
        line = _format_model_line(cfg)
        assert "weak: w" in line
        assert "editor:" not in line

    def test_both_differ(self):
        cfg = ModelConfig(main_model="m", editor_model="e", weak_model="w")
        line = _format_model_line(cfg)
        assert "m " in line  # main is the lead label
        assert "editor: e" in line
        assert "weak: w" in line


# ---------- `model_routed` event from run_session ------------------------


class TestModelRoutedEvent:
    """A `model_routed` event must fire per main-iteration call so analysis
    can group iterations by slot. The event includes the slot label
    ("main") and the current `client.model` at dispatch time.
    """

    def test_single_iteration_emits_one_main_event(self):
        stream = iter([
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        client = _scripted_client([stream])
        client.model = "deepseek-v4-flash"
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())
        tracer = _CapturingTracer()

        run_session(
            [
                {"role": "system", "content": "sys"},
                {"role": "user", "content": "hi"},
            ],
            client, registry,
            permissions=permissions,
            renderer=renderer,
            tracer=tracer,
        )

        routed = [p for k, p in tracer.events if k == "model_routed"]
        assert len(routed) == 1
        assert routed[0] == {
            "slot": "main",
            "model": "deepseek-v4-flash",
            "reason": "iteration",
        }

    def test_two_iterations_emit_two_main_events(self, tmp_path):
        # Iteration 1: tool call. Iteration 2: natural stop.
        target = tmp_path / "f.txt"
        target.write_text("data\n")

        def _tc_delta(index, *, id=None, name=None, args=None):
            fn = SimpleNamespace(
                name=name, arguments=args,
            ) if (name or args is not None) else None
            return SimpleNamespace(index=index, id=id, function=fn)

        stream1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="c1", name="view")]),
            _delta_chunk(
                tool_calls=[_tc_delta(0, args=f'{{"path":"{target}"}}')],
                finish_reason="tool_calls",
            ),
            _final_usage_chunk({"prompt_tokens": 10, "completion_tokens": 2}),
        ])
        stream2 = iter([
            _delta_chunk(content="done.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 12, "completion_tokens": 1}),
        ])
        client = _scripted_client([stream1, stream2])
        client.model = "fancy-main"
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())
        tracer = _CapturingTracer()

        run_session(
            [
                {"role": "system", "content": "sys"},
                {"role": "user", "content": "look"},
            ],
            client, default_registry(),
            permissions=permissions,
            renderer=renderer,
            tracer=tracer,
        )

        routed = [p for k, p in tracer.events if k == "model_routed"]
        assert len(routed) == 2
        for r in routed:
            assert r["slot"] == "main"
            assert r["model"] == "fancy-main"
            assert r["reason"] == "iteration"

    def test_event_records_current_model_after_swap(self):
        # If the client's model is mutated mid-session (the way `/model`
        # does it), subsequent iterations record the new model.
        stream1 = iter([
            _delta_chunk(content="hi", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        client = _scripted_client([stream1])
        client.model = "before-swap"
        tracer = _CapturingTracer()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        run_session(
            [{"role": "system", "content": "sys"},
             {"role": "user", "content": "go"}],
            client, default_registry(),
            permissions=permissions, renderer=renderer, tracer=tracer,
        )
        routed = [p for k, p in tracer.events if k == "model_routed"]
        assert routed[0]["model"] == "before-swap"


# ---------- config_snapshot in dsc_sessions row --------------------------


class TestSessionConfigSnapshot:
    """`tracer.start_session(..., config_snapshot=...)` writes the three-slot
    snapshot to the new `dsc_sessions.config_snapshot` JSONB column. This
    is what lets analysis group iterations by the slot they used.
    """

    def _writer(self):
        # Lift the FakeWriter pattern from test_telemetry.py without importing
        # private fixtures. The shape: a thin recorder.
        from dsc.telemetry.tracer import PgTracer

        class FakeWriter:
            def __init__(self):
                self.envelopes: list[tuple[str, dict]] = []
            def submit(self, kind, params):
                self.envelopes.append((kind, params))
            def drain(self, timeout=2.0):
                pass

        w = FakeWriter()
        return w, PgTracer(w)

    def test_snapshot_written_into_session_start_envelope(self):
        w, tracer = self._writer()
        snapshot = {
            "main_model": "m1",
            "editor_model": "e1",
            "weak_model": "w1",
            "run_mode": "normal",
        }
        tracer.start_session(
            model="m1", base_url="https://x", yolo=False, one_shot=True,
            system_prompt="SYS", registry_names=["bash"],
            registry_perms={"bash": True},
            config_snapshot=snapshot,
        )
        starts = [p for k, p in w.envelopes if k == "session_start"]
        assert len(starts) == 1
        # Stored as JSON (psycopg expects a JSONB-castable string for JSONB).
        import json
        snap = json.loads(starts[0]["config_snapshot"])
        assert snap == snapshot

    def test_omitted_snapshot_serializes_as_none(self):
        w, tracer = self._writer()
        tracer.start_session(
            model="m", base_url="b", yolo=False, one_shot=True,
            system_prompt="SYS", registry_names=[],
            registry_perms={},
        )
        starts = [p for k, p in w.envelopes if k == "session_start"]
        assert len(starts) == 1
        # When the caller doesn't pass config_snapshot, the column is NULL
        # so old sessions remain valid.
        assert starts[0]["config_snapshot"] is None
