"""P3.2: `.dsc/rules/*.md` system + `request_rule` tool + session integration.

Covers `dsc.rules` (loading, frontmatter parsing, glob matching, render
shape) plus the `request_rule` tool and the `run_session` integration
that injects the rules block as a system segment between repo map and
todos on every iteration.
"""
from __future__ import annotations

import io
from pathlib import Path
from types import SimpleNamespace

import pytest
from rich.console import Console

from dsc.client import DSClient
from dsc.permissions import PermissionPolicy
from dsc.render import Renderer
from dsc.rules import (
    RULES_SUBDIR,
    RuleSet,
    build_rules_message,
    env_disables_rules,
)
from dsc.session import run_session
from dsc.todo_inject import is_todo_block_message
from dsc.tools.registry import default_registry
from dsc.tools.request_rule import (
    RequestRuleArgs,
    RuleRequestContext,
    reset_request_rule_context,
    run as request_rule_run,
    set_request_rule_context,
)


# ---------------------------------------------------------------------- helpers


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console():
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=120, color_system=None),
        buf,
    )


def _delta_chunk(*, content=None, tool_calls=None, finish_reason=None, usage=None):
    delta = SimpleNamespace(content=content, tool_calls=tool_calls, reasoning_content=None)
    choice = SimpleNamespace(delta=delta, finish_reason=finish_reason)
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u) if usage is not None else None
    return SimpleNamespace(choices=[choice], usage=usage_obj)


def _final_usage_chunk(usage):
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[], usage=usage_obj)


def _tc_delta(index, *, id=None, name=None, args=None):
    fn = SimpleNamespace(name=name, arguments=args) if (name or args is not None) else None
    return SimpleNamespace(index=index, id=id, function=fn)


class _RecordingClient:
    """DSClient with a `chat.completions.create` that records every call's
    `messages` kwarg and returns the next scripted streaming chunk list.
    Mirrors the helper used in test_todo_injection.py.
    """

    def __init__(self, scripted_streams: list):
        self._streams = list(scripted_streams)
        self.calls: list[list[dict]] = []

        client = DSClient(api_key="test", model="deepseek-v4-flash")
        outer = self

        def fake_create(**kwargs):
            outer.calls.append([dict(m) for m in kwargs.get("messages", [])])
            return iter(outer._streams.pop(0))

        client._client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=fake_create),
            )
        )
        self.client = client


def _reset_todo_state():
    from dsc.tools import todo as todo_mod
    todo_mod._state = []


@pytest.fixture(autouse=True)
def _clean_todos():
    _reset_todo_state()
    yield
    _reset_todo_state()


def _make_basic_session(scripted_streams):
    rec = _RecordingClient(scripted_streams)
    registry = default_registry()
    renderer = Renderer(console=_silent_console(), stream=False)
    permissions = PermissionPolicy(yolo=True, console=_silent_console())
    return rec, registry, renderer, permissions


def _write_rule(dirpath: Path, name: str, frontmatter: dict, body: str = "") -> Path:
    """Compose a rule file under `<dirpath>/<name>.md`."""
    dirpath.mkdir(parents=True, exist_ok=True)
    fm_lines = ["---"]
    for k, v in frontmatter.items():
        if isinstance(v, bool):
            fm_lines.append(f"{k}: {'true' if v else 'false'}")
        elif isinstance(v, list):
            joined = ", ".join(f'"{g}"' for g in v)
            fm_lines.append(f"{k}: [{joined}]")
        else:
            fm_lines.append(f'{k}: "{v}"')
    fm_lines.append("---")
    text = "\n".join(fm_lines) + "\n" + body
    p = dirpath / f"{name}.md"
    p.write_text(text, encoding="utf-8")
    return p


# ---------------------------------------------------------------------- Rule loader


class TestRuleSetLoad:
    def test_alwaysapply_rule_loaded_with_metadata(self, tmp_path, monkeypatch):
        # Isolate from real $HOME so user-level rules don't leak in.
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        rules_dir = tmp_path / RULES_SUBDIR
        _write_rule(
            rules_dir, "always",
            {
                "name": "always-on",
                "description": "fires every turn",
                "alwaysApply": True,
            },
            body="Use 4-space indentation.",
        )
        rs = RuleSet.load(tmp_path)
        assert len(rs.rules) == 1
        rule = rs.rules[0]
        assert rule.name == "always-on"
        assert rule.always_apply is True
        assert rule.globs == ()
        assert "4-space" in rule.body
        assert rs.by_name["always-on"] is rule

    def test_glob_rule_with_string_globs(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "api",
            {
                "description": "applies to API code",
                "globs": ["src/api/**/*.py"],
            },
            body="Always use httpx.AsyncClient.",
        )
        rs = RuleSet.load(tmp_path)
        rule = rs.by_name["api"]
        assert rule.globs == ("src/api/**/*.py",)
        assert rule.always_apply is False

    def test_description_only_rule(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "use-case",
            {"description": "use when handling cron jobs"},
            body="cron-specific guidance",
        )
        rs = RuleSet.load(tmp_path)
        rule = rs.by_name["use-case"]
        assert rule.always_apply is False
        assert rule.globs == ()
        assert rule.description.startswith("use when")

    def test_no_frontmatter_uses_filestem_name(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        rules_dir = tmp_path / RULES_SUBDIR
        rules_dir.mkdir(parents=True)
        (rules_dir / "bare.md").write_text("Just a body.\n", encoding="utf-8")
        rs = RuleSet.load(tmp_path)
        # File stem becomes the name; body is preserved.
        assert "bare" in rs.by_name
        assert rs.by_name["bare"].body == "Just a body."

    def test_user_rules_layer_loaded_when_no_project_rules(
        self, tmp_path, monkeypatch
    ):
        # No project rules dir; user dir contains one rule.
        fake_home = tmp_path / "fakehome"
        monkeypatch.setenv("HOME", str(fake_home))
        _write_rule(
            fake_home / RULES_SUBDIR, "shared",
            {"alwaysApply": True},
            body="Shared body.",
        )
        rs = RuleSet.load(tmp_path)
        assert "shared" in rs.by_name

    def test_project_overrides_user_on_collision(self, tmp_path, monkeypatch):
        # Same name in both layers; project rule wins.
        fake_home = tmp_path / "fakehome"
        monkeypatch.setenv("HOME", str(fake_home))
        _write_rule(
            fake_home / RULES_SUBDIR, "shared",
            {"alwaysApply": True}, body="USER",
        )
        _write_rule(
            tmp_path / RULES_SUBDIR, "shared",
            {"alwaysApply": True}, body="PROJECT",
        )
        rs = RuleSet.load(tmp_path)
        assert "PROJECT" in rs.by_name["shared"].body
        assert "USER" not in rs.by_name["shared"].body

    def test_empty_directory_loads_empty_set(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        (tmp_path / RULES_SUBDIR).mkdir(parents=True)
        rs = RuleSet.load(tmp_path)
        assert rs.rules == []
        assert rs.by_name == {}

    def test_no_rules_dir_loads_empty_set(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        rs = RuleSet.load(tmp_path)
        assert rs.rules == []

    def test_walks_upward_for_project_dir(self, tmp_path, monkeypatch):
        # `.dsc/rules` lives at the project root; we run from a deep
        # subdir and expect upward discovery.
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "deep-found",
            {"alwaysApply": True}, body="X",
        )
        deep = tmp_path / "src" / "deep" / "module"
        deep.mkdir(parents=True)
        rs = RuleSet.load(deep)
        assert "deep-found" in rs.by_name


# ---------------------------------------------------------------------- selection


class TestApplicableFor:
    def test_alwaysapply_always_included(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "everywhere",
            {"alwaysApply": True}, body="X",
        )
        rs = RuleSet.load(tmp_path)
        out = rs.applicable_for(chat_files=set(), explicit=set())
        assert [r.name for r in out] == ["everywhere"]

    def test_glob_fires_when_chat_file_matches(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "api-rule",
            {"globs": ["src/api/**/*.py"]},
            body="API stuff",
        )
        rs = RuleSet.load(tmp_path)
        # Create a real file path under the project root so resolve()
        # can compute relative_to.
        api_file = tmp_path / "src" / "api" / "users.py"
        api_file.parent.mkdir(parents=True)
        api_file.write_text("# stub\n")
        out = rs.applicable_for(chat_files={api_file}, explicit=set())
        assert [r.name for r in out] == ["api-rule"]

    def test_glob_silent_when_no_chat_file_matches(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "api-rule",
            {"globs": ["src/api/**/*.py"]},
            body="API stuff",
        )
        rs = RuleSet.load(tmp_path)
        # File outside src/api — no match.
        other = tmp_path / "src" / "core" / "utils.py"
        other.parent.mkdir(parents=True)
        other.write_text("# stub\n")
        out = rs.applicable_for(chat_files={other}, explicit=set())
        assert out == []

    def test_glob_silent_with_empty_chat_files(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "api-rule",
            {"globs": ["src/api/**/*.py"]},
            body="API stuff",
        )
        rs = RuleSet.load(tmp_path)
        out = rs.applicable_for(chat_files=set(), explicit=set())
        assert out == []

    def test_description_only_not_in_active(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "deep-dive",
            {"description": "for cron edge cases"},
            body="cron body",
        )
        rs = RuleSet.load(tmp_path)
        out = rs.applicable_for(chat_files=set(), explicit=set())
        assert out == []
        # But it IS in the available list.
        avail = rs.available_descriptions(active_names=set())
        assert [r.name for r in avail] == ["deep-dive"]

    def test_explicit_request_promotes_to_active(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "deep-dive",
            {"description": "for cron edge cases"},
            body="cron body",
        )
        rs = RuleSet.load(tmp_path)
        out = rs.applicable_for(chat_files=set(), explicit={"deep-dive"})
        assert [r.name for r in out] == ["deep-dive"]


# ---------------------------------------------------------------------- render


class TestRenderBlock:
    def test_active_section_contains_bodies(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "alpha",
            {"alwaysApply": True}, body="alpha body",
        )
        _write_rule(
            tmp_path / RULES_SUBDIR, "beta",
            {"alwaysApply": True}, body="beta body",
        )
        rs = RuleSet.load(tmp_path)
        block = rs.render_block(chat_files=set(), explicit=set())
        assert "# Rules (active)" in block
        assert "## alpha" in block
        assert "alpha body" in block
        assert "## beta" in block
        assert "beta body" in block

    def test_available_section_renders_when_descriptions_exist(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "available1",
            {"description": "edge case A"},
            body="body A",
        )
        rs = RuleSet.load(tmp_path)
        block = rs.render_block(chat_files=set(), explicit=set())
        assert "# Rules (available, request via request_rule)" in block
        assert "available1" in block
        assert "edge case A" in block
        # Body should NOT leak into the available section.
        assert "body A" not in block

    def test_empty_rules_dir_renders_empty_string(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        (tmp_path / RULES_SUBDIR).mkdir(parents=True)
        rs = RuleSet.load(tmp_path)
        block = rs.render_block(chat_files=set(), explicit=set())
        assert block == ""

    def test_only_available_renders_only_available_section(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "only-avail",
            {"description": "yo"},
            body="x",
        )
        rs = RuleSet.load(tmp_path)
        block = rs.render_block(chat_files=set(), explicit=set())
        assert "# Rules (active)" not in block
        assert "# Rules (available" in block

    def test_explicit_promoted_rule_appears_in_active(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "by-request",
            {"description": "say what"},
            body="requested body",
        )
        rs = RuleSet.load(tmp_path)
        block = rs.render_block(chat_files=set(), explicit={"by-request"})
        # The active section now contains the body.
        assert "## by-request" in block
        assert "requested body" in block
        # And the available section is suppressed (no other description-
        # only rules exist).
        assert "# Rules (available" not in block


class TestBuildRulesMessage:
    def test_passthrough_with_trailing_newline(self):
        out = build_rules_message("# Rules\nfoo\n")
        assert out.endswith("\n")

    def test_empty_returns_empty(self):
        assert build_rules_message("") == ""


class TestEnvDisablesRules:
    def test_default_enabled(self, monkeypatch):
        monkeypatch.delenv("DSC_RULES", raising=False)
        assert env_disables_rules() is False

    def test_zero_disables(self, monkeypatch):
        monkeypatch.setenv("DSC_RULES", "0")
        assert env_disables_rules() is True


# ---------------------------------------------------------------------- request_rule tool


class TestRequestRuleTool:
    def test_unknown_name_returns_error_with_available_list(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "real",
            {"description": "yes"}, body="real body",
        )
        rs = RuleSet.load(tmp_path)
        explicit: set[str] = set()
        token = set_request_rule_context(
            RuleRequestContext(rule_set=rs, explicit=explicit)
        )
        try:
            out = request_rule_run(RequestRuleArgs(name="missing"))
        finally:
            reset_request_rule_context(token)
        assert out.startswith("Error: rule 'missing' not found")
        assert "real" in out  # the available list mentions the real rule

    def test_known_name_returns_body_and_mutates_explicit(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "secret-sauce",
            {"description": "the secret"},
            body="The secret is to use 4 spaces.",
        )
        rs = RuleSet.load(tmp_path)
        explicit: set[str] = set()
        token = set_request_rule_context(
            RuleRequestContext(rule_set=rs, explicit=explicit)
        )
        try:
            out = request_rule_run(RequestRuleArgs(name="secret-sauce"))
        finally:
            reset_request_rule_context(token)
        assert "secret-sauce" in out
        assert "The secret is to use 4 spaces" in out
        # Explicit set was mutated so the rule activates next iteration.
        assert "secret-sauce" in explicit

    def test_no_context_returns_error(self):
        # No context installed.
        out = request_rule_run(RequestRuleArgs(name="anything"))
        assert "no rule context" in out.lower()


# ---------------------------------------------------------------------- session integration


class TestSessionIntegration:
    """The rules block is injected as a system segment between the repo
    map and the todo block on every iteration. Empty rule sets render
    nothing (no break to existing wire shape)."""

    def test_rules_block_lands_in_messages(self, tmp_path, monkeypatch):
        # Build a project with one alwaysApply rule.
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "test-rule",
            {"alwaysApply": True}, body="rule body content",
        )
        rs = RuleSet.load(tmp_path)
        assert len(rs.rules) == 1

        stream = [
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = _make_basic_session([stream])
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "hi"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
            rule_set=rs,
        )
        assert len(rec.calls) == 1
        sent = rec.calls[0]
        # Wire shape: SYS, RULES, TODO, USER (no repo_map injected here).
        assert sent[0]["role"] == "system"
        assert sent[0]["content"] == "SYS"
        assert sent[1]["role"] == "system"
        assert "# Rules (active)" in sent[1]["content"]
        assert "test-rule" in sent[1]["content"]
        assert "rule body content" in sent[1]["content"]
        # Todo block still follows the rules block.
        assert is_todo_block_message(sent[2])
        assert sent[3]["role"] == "user"

    def test_empty_rule_set_skips_injection(self, tmp_path, monkeypatch):
        # Empty rule set → no rules block injected; wire shape unchanged.
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        rs = RuleSet.load(tmp_path)
        assert rs.rules == []
        stream = [
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = _make_basic_session([stream])
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "hi"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
            rule_set=rs,
        )
        sent = rec.calls[0]
        # No rules block — only SYS, TODO, USER.
        rules_msgs = [
            m for m in sent
            if m.get("role") == "system"
            and isinstance(m.get("content"), str)
            and "# Rules" in m["content"]
        ]
        assert rules_msgs == []
        assert sent[0]["role"] == "system"
        assert sent[0]["content"] == "SYS"
        assert is_todo_block_message(sent[1])

    def test_glob_rule_fires_when_chat_files_match(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "py-rule",
            {"globs": ["src/**/*.py"]},
            body="py-specific body",
        )
        rs = RuleSet.load(tmp_path)
        # Real file in chat_files for resolve() to relativize.
        target = tmp_path / "src" / "module" / "code.py"
        target.parent.mkdir(parents=True)
        target.write_text("# stub\n")

        stream = [
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = _make_basic_session([stream])
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "hi"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
            rule_set=rs,
            chat_files_provider=lambda: {target},
        )
        sent = rec.calls[0]
        # The rules block should appear and contain the py-rule body.
        rules_msg = next(
            m for m in sent
            if m.get("role") == "system"
            and isinstance(m.get("content"), str)
            and "# Rules" in m["content"]
        )
        assert "py-rule" in rules_msg["content"]
        assert "py-specific body" in rules_msg["content"]

    def test_glob_rule_silent_when_no_chat_files_match(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "py-rule",
            {"globs": ["src/api/**/*.py"]},
            body="api body",
        )
        rs = RuleSet.load(tmp_path)
        # File outside the matching glob.
        other = tmp_path / "src" / "core" / "utils.py"
        other.parent.mkdir(parents=True)
        other.write_text("# stub\n")
        stream = [
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = _make_basic_session([stream])
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "hi"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
            rule_set=rs,
            chat_files_provider=lambda: {other},
        )
        sent = rec.calls[0]
        # The block should still render (description-only-style listing
        # is empty here too — no description on the glob rule), but the
        # py-rule body should NOT appear.
        rules_msgs = [
            m for m in sent
            if m.get("role") == "system"
            and isinstance(m.get("content"), str)
            and "# Rules" in m.get("content", "")
        ]
        # No active block, no description, so render_block returns "".
        assert rules_msgs == []

    def test_description_only_then_request_rule_promotes(
        self, tmp_path, monkeypatch
    ):
        # Iteration 1: model calls request_rule(name="lookup").
        # Iteration 2: the next render_block has lookup in the active section.
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "lookup",
            {"description": "request when handling lookup logic"},
            body="lookup-body-content",
        )
        rs = RuleSet.load(tmp_path)
        # Stream 1: tool call to request_rule(name="lookup").
        args_json = '{"name":"lookup"}'
        stream1 = [
            _delta_chunk(tool_calls=[_tc_delta(0, id="rr1", name="request_rule")]),
            _delta_chunk(
                tool_calls=[_tc_delta(0, args=args_json)],
                finish_reason="tool_calls",
            ),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        # Stream 2: stop.
        stream2 = [
            _delta_chunk(content="done", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = _make_basic_session([stream1, stream2])
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "go"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
            rule_set=rs,
        )
        assert len(rec.calls) == 2
        # First call: rule is in the available section, NOT active.
        block1 = next(
            m["content"] for m in rec.calls[0]
            if m.get("role") == "system"
            and isinstance(m.get("content"), str)
            and "# Rules" in m["content"]
        )
        assert "# Rules (active)" not in block1
        assert "# Rules (available" in block1
        assert "lookup" in block1
        assert "lookup-body-content" not in block1

        # Second call: lookup now appears in the active section with body.
        block2 = next(
            m["content"] for m in rec.calls[1]
            if m.get("role") == "system"
            and isinstance(m.get("content"), str)
            and "# Rules" in m["content"]
        )
        assert "# Rules (active)" in block2
        assert "## lookup" in block2
        assert "lookup-body-content" in block2

    def test_telemetry_event_emitted(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "always-on",
            {"alwaysApply": True}, body="always body",
        )
        rs = RuleSet.load(tmp_path)
        stream = [
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = _make_basic_session([stream])

        from dsc.telemetry import NullTracer

        class _CapturingTracer(NullTracer):
            def __init__(self):
                self.events: list[tuple[str, dict | None]] = []

            def event(self, kind, *, payload=None, turn=None):
                self.events.append((kind, payload))

        cap = _CapturingTracer()
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "hi"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
            rule_set=rs,
            tracer=cap,
        )
        loaded = [p for k, p in cap.events if k == "rules_loaded"]
        assert len(loaded) == 1
        payload = loaded[0]
        assert payload["names"] == ["always-on"]
        assert payload["total_chars"] > 0
        assert payload["source"] == "always"
        assert "always-on" in payload["always"]


# ---------------------------------------------------------------------- /rules slash


class TestRulesSlashCommand:
    """The /rules slash command renders both active and available rule
    listings as a Panel. We invoke its body inline by replicating its
    logic — the same pattern test_todo_injection.py uses for /todos.
    """

    def test_active_and_available_section_titles(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        _write_rule(
            tmp_path / RULES_SUBDIR, "always-rule",
            {
                "alwaysApply": True,
                "description": "fires every turn",
            },
            body="always body",
        )
        _write_rule(
            tmp_path / RULES_SUBDIR, "avail-rule",
            {"description": "use when X happens"},
            body="avail body",
        )
        rs = RuleSet.load(tmp_path)
        active = rs.applicable_for(chat_files=set(), explicit=set())
        avail = rs.available_descriptions(active_names={r.name for r in active})

        # Active should be just the always-rule.
        assert [r.name for r in active] == ["always-rule"]
        # Avail should be the description-only one.
        assert [r.name for r in avail] == ["avail-rule"]
        # And both descriptions are surfaced.
        assert "fires every turn" in active[0].description
        assert "use when X happens" in avail[0].description

    def test_no_rules_renders_friendly_hint(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "fakehome"))
        rs = RuleSet.load(tmp_path)
        assert rs.rules == []
        # The cli.py handler prints a friendly message when no rules
        # are loaded; we assert the precondition that triggers it.
        # (The handler itself is exercised end-to-end by the live REPL.)
        assert not rs.rules
