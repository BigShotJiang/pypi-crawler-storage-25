"""Tests for `dsc.tools.str_replace`.

The first block exercises the historical contracts (uniqueness invariant,
exact wording for not_found / not_unique, empty-string delete). These
must NOT change — AGENTS.md treats the wording as a model-facing contract.

The second block covers the P1.4 additions:
  - Prior-Read enforcement: `view` (or `create_file`) must precede an edit.
  - AST-context error feedback on near-misses for supported languages.
  - Telemetry sub-outcome ContextVar wiring (`prior_read_required`,
    `not_found_with_candidate`, `not_found`, `not_unique`).
"""
from __future__ import annotations

from pathlib import Path

import pytest

from dsc.tools._session_files import (
    consume_tool_outcome,
    reset_tracked_files,
    set_tracked_files,
)
from dsc.tools.create_file import CreateFileArgs, run as create_file_run
from dsc.tools.str_replace import StrReplaceArgs, run
from dsc.tools.view import ViewArgs, run as view_run


# ---------- historical contract (must not change) -------------------------


def test_replaces_unique(tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("hello world\ngoodbye world\n")
    out = run(StrReplaceArgs(path=str(p), old_str="hello", new_str="HI"))
    assert out.startswith("Edited")
    assert p.read_text() == "HI world\ngoodbye world\n"


def test_zero_matches(tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("hello\n")
    out = run(StrReplaceArgs(path=str(p), old_str="zzz", new_str="x"))
    assert out.startswith("Error: old_str not found")
    assert p.read_text() == "hello\n"


def test_multiple_matches(tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("hi\nhi\nhi\n")
    out = run(StrReplaceArgs(path=str(p), old_str="hi", new_str="x"))
    assert "found 3 matches" in out
    assert "must be unique" in out
    assert p.read_text() == "hi\nhi\nhi\n"


def test_missing_file(tmp_path):
    out = run(StrReplaceArgs(path=str(tmp_path / "nope.txt"), old_str="x", new_str="y"))
    assert out.startswith("Error: file does not exist")


def test_empty_new_str_deletes(tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("keep\nDELETE\nkeep\n")
    out = run(StrReplaceArgs(path=str(p), old_str="DELETE\n", new_str=""))
    assert out.startswith("Edited")
    assert p.read_text() == "keep\nkeep\n"


# ---------- P1.4: prior-Read enforcement + AST-context errors -------------


@pytest.fixture
def session_files():
    """Install a session-scoped tracked-files set and consume any leftover
    sub-outcome from previous calls. Yields the set so tests can pre-populate
    or inspect it. Reset on teardown.
    """
    tracked: set[Path] = set()
    token = set_tracked_files(tracked)
    consume_tool_outcome()  # clear any stale value
    try:
        yield tracked
    finally:
        reset_tracked_files(token)


def test_edit_without_prior_view_is_rejected(tmp_path, session_files):
    """Plan-mandated wording: `Error: must view {path} before editing it.
    Run view {path} first.` — model-facing contract.
    """
    p = tmp_path / "f.txt"
    p.write_text("hello world\n")
    # session_files is empty: file is on disk but the model hasn't viewed it.
    out = run(StrReplaceArgs(path=str(p), old_str="hello", new_str="HI"))
    resolved = str(p.resolve())
    expected = (
        f"Error: must view {resolved} before editing it. Run view {resolved} first."
    )
    assert out == expected
    # File must NOT have been modified.
    assert p.read_text() == "hello world\n"
    # Sub-outcome ContextVar surfaced for telemetry.
    assert consume_tool_outcome() == "prior_read_required"


def test_edit_after_view_succeeds(tmp_path, session_files):
    """Control: viewing a file marks it tracked; the next str_replace works."""
    p = tmp_path / "f.txt"
    p.write_text("hello world\n")
    view_out = view_run(ViewArgs(path=str(p)))
    assert "hello world" in view_out
    # The view tool should have populated the tracked-files set.
    assert p.resolve() in session_files
    out = run(StrReplaceArgs(path=str(p), old_str="hello", new_str="HI"))
    assert out.startswith("Edited")
    assert p.read_text() == "HI world\n"


def test_edit_after_create_file_succeeds(tmp_path, session_files):
    """Fresh-create-then-edit exception: create_file counts as a prior view."""
    p = tmp_path / "new.txt"
    create_out = create_file_run(CreateFileArgs(path=str(p), content="hello\n"))
    assert create_out.startswith("Created")
    assert p.resolve() in session_files
    # No explicit `view` between create_file and str_replace — this is the
    # exception called out in the plan.
    out = run(StrReplaceArgs(path=str(p), old_str="hello", new_str="HI"))
    assert out.startswith("Edited")
    assert p.read_text() == "HI\n"


def test_edit_after_view_directory_does_not_grant_edit_rights(tmp_path, session_files):
    """Listing a directory shouldn't unlock editing arbitrary files inside.

    `view` only marks a file as tracked when the model has seen actual
    content. Directory listings are best-effort and don't expose contents.
    """
    sub = tmp_path / "sub"
    sub.mkdir()
    p = sub / "f.txt"
    p.write_text("hello\n")
    # View the directory, NOT the file.
    view_run(ViewArgs(path=str(sub)))
    # The file path should still not be tracked.
    out = run(StrReplaceArgs(path=str(p), old_str="hello", new_str="HI"))
    assert out.startswith("Error: must view")
    assert "before editing it" in out
    assert p.read_text() == "hello\n"


def test_second_edit_in_same_session_does_not_reprompt(tmp_path, session_files):
    """A successful edit keeps the file tracked so follow-ups don't error."""
    p = tmp_path / "f.txt"
    p.write_text("hello\nworld\n")
    view_run(ViewArgs(path=str(p)))
    first = run(StrReplaceArgs(path=str(p), old_str="hello", new_str="HI"))
    assert first.startswith("Edited")
    # Even without re-viewing, the next edit on the same file is allowed.
    second = run(StrReplaceArgs(path=str(p), old_str="world", new_str="WORLD"))
    assert second.startswith("Edited")
    assert p.read_text() == "HI\nWORLD\n"


# ---------- P1.4: AST candidate rendering ---------------------------------


# A 60+ line Python file with a clearly-named function — used by the
# AST-context tests. Lives at module scope so tests share it cheaply.
_PY_FILE_BODY = '''\
"""Sample module for str_replace AST-context tests.

This module is intentionally padded out beyond the 50-line floor that
str_replace uses to gate its AST-rendering path. The actual code under
test is the `FormatterEngine.render_summary` method below.
"""

import os
import sys


CONSTANT_ONE = 1
CONSTANT_TWO = 2
CONSTANT_THREE = 3


def helper_alpha(x):
    """Tiny helper used by the formatter."""
    return x + 1


def helper_beta(y):
    """Another helper, distinct line range."""
    return y * 2


def helper_gamma(z):
    """A third helper for padding."""
    return z - 1


class FormatterEngine:
    """The class whose method we want to surface as a near-miss candidate."""

    def __init__(self, prefix):
        self.prefix = prefix
        self.counter = 0

    def render_summary(self, items):
        # Build the summary string for each item, with the configured
        # prefix and a separator between entries.
        parts = []
        for item in items:
            line = self.prefix + ": " + str(item)
            parts.append(line)
            self.counter += 1
        return "\\n".join(parts)

    def render_detail(self, item):
        return self.prefix + ":: " + str(item)

    def reset(self):
        self.counter = 0


def main():
    engine = FormatterEngine("dsc")
    print(engine.render_summary([1, 2, 3]))
    print(engine.render_detail(42))
    return 0


if __name__ == "__main__":
    main()
'''


def _write_python(tmp_path: Path) -> Path:
    p = tmp_path / "sample.py"
    p.write_text(_PY_FILE_BODY)
    return p


def test_near_miss_python_renders_ast_scope(tmp_path, session_files):
    """A near-miss old_str on a Python file surfaces the enclosing scope.

    The model's old_str differs by whitespace/punctuation from a real
    line inside `FormatterEngine`; the response should name a function
    scope and include ellipses around the scope contents. We don't pin
    which exact method matches — the algorithm picks the highest-
    similarity 3-line window, which depends on SequenceMatcher's exact
    scoring across small whitespace edits and is brittle to anchor on.
    """
    p = _write_python(tmp_path)
    view_run(ViewArgs(path=str(p)))
    # Real text says `line = self.prefix + ": " + str(item)`. The model's
    # version drops the colon — close but not exact.
    near_miss = "line = self.prefix + \" \" + str(item)"
    out = run(StrReplaceArgs(path=str(p), old_str=near_miss, new_str="line = ''"))
    # File must NOT have been modified.
    assert p.read_text() == _PY_FILE_BODY
    # Existing not_found wording must still be present (extends, doesn't
    # replace, per the AGENTS.md sharp-edge rule).
    assert out.startswith(f"Error: old_str not found in {p.resolve()}.")
    # Closest-candidate paragraph names the scope and a similarity score.
    assert "Closest candidate" in out
    assert "similarity" in out
    # AST scope label: tree-sitter found a function/method/class scope.
    # Either `render_summary` or `render_detail` could win depending on
    # SequenceMatcher's scoring — both are inside FormatterEngine which
    # is the relevant region.
    assert "function" in out or "class" in out
    # Ellipses for omitted code (grep_ast's TreeContext renders these).
    assert "⋮" in out
    # The enclosing class context should appear (TreeContext walks the
    # parent scope chain).
    assert "FormatterEngine" in out
    # Telemetry sub-outcome.
    assert consume_tool_outcome() == "not_found_with_candidate"


def test_short_python_file_falls_back_to_plain_not_found(tmp_path, session_files):
    """A small file (<50 lines) skips the AST render and uses the original wording."""
    p = tmp_path / "tiny.py"
    p.write_text(
        "def foo():\n"
        "    return 1\n"
        "\n"
        "def bar():\n"
        "    return 2\n"
    )
    view_run(ViewArgs(path=str(p)))
    out = run(StrReplaceArgs(
        path=str(p), old_str="something_that_definitely_does_not_appear",
        new_str="x",
    ))
    # Original wording — no AST scope appended.
    assert out.startswith(f"Error: old_str not found in {p.resolve()}.")
    assert "Closest candidate" not in out
    assert "Did you escape whitespace" in out  # the historical hint
    assert consume_tool_outcome() == "not_found"


def test_non_python_file_falls_back_to_plain_not_found(tmp_path, session_files):
    """An unsupported language (e.g. .txt) skips AST even on a long file."""
    p = tmp_path / "log.txt"
    # 80+ lines so we clear the size threshold — language is the gate here.
    body = "\n".join(f"line {i}: payload contents" for i in range(80)) + "\n"
    p.write_text(body)
    view_run(ViewArgs(path=str(p)))
    out = run(StrReplaceArgs(
        path=str(p), old_str="this string does not exist",
        new_str="x",
    ))
    # No AST scope since .txt isn't a supported tree-sitter language.
    assert out.startswith(f"Error: old_str not found in {p.resolve()}.")
    assert "Closest candidate" not in out
    assert consume_tool_outcome() == "not_found"


# ---------- telemetry sub-outcome wiring ---------------------------------


def test_not_unique_emits_sub_outcome(tmp_path, session_files):
    p = tmp_path / "f.txt"
    p.write_text("hi\nhi\n")
    view_run(ViewArgs(path=str(p)))
    out = run(StrReplaceArgs(path=str(p), old_str="hi", new_str="x"))
    assert "found 2 matches" in out
    assert consume_tool_outcome() == "not_unique"


def test_successful_edit_does_not_set_sub_outcome(tmp_path, session_files):
    """A clean edit leaves the sub-outcome ContextVar empty so dispatch
    keeps its default `"ok"` value."""
    p = tmp_path / "f.txt"
    p.write_text("hello\n")
    view_run(ViewArgs(path=str(p)))
    out = run(StrReplaceArgs(path=str(p), old_str="hello", new_str="HI"))
    assert out.startswith("Edited")
    assert consume_tool_outcome() is None


def test_dispatch_propagates_prior_read_outcome(tmp_path, session_files):
    """End-to-end: `Registry.dispatch` reflects the str_replace sub-outcome.

    Confirms the wiring works through the dispatch boundary that
    `agent.py` records into telemetry.
    """
    from dsc.client import ToolCall
    from dsc.tools.registry import default_registry

    p = tmp_path / "f.txt"
    p.write_text("hello\n")
    reg = default_registry()
    call = ToolCall(
        id="x", name="str_replace",
        arguments={"path": str(p), "old_str": "hello", "new_str": "HI"},
        raw_arguments=f'{{"path":"{p}","old_str":"hello","new_str":"HI"}}',
    )
    out, meta = reg.dispatch(call, permissions=None)
    assert "must view" in out
    assert meta["outcome"] == "prior_read_required"
    # File untouched.
    assert p.read_text() == "hello\n"


def test_dispatch_propagates_not_found_with_candidate_outcome(tmp_path, session_files):
    """Same as above but for the AST-candidate path — confirms `meta["outcome"]`
    surfaces the new vocabulary value the plan calls for.
    """
    from dsc.client import ToolCall
    from dsc.tools.registry import default_registry

    p = _write_python(tmp_path)
    view_run(ViewArgs(path=str(p)))
    reg = default_registry()
    near_miss = "line = self.prefix + \" \" + str(item)"
    call = ToolCall(
        id="x", name="str_replace",
        arguments={"path": str(p), "old_str": near_miss, "new_str": "x"},
        raw_arguments="{}",
    )
    out, meta = reg.dispatch(call, permissions=None)
    assert "Closest candidate" in out
    assert meta["outcome"] == "not_found_with_candidate"


def test_dispatch_ok_outcome_for_clean_edit(tmp_path, session_files):
    """Backwards-compat check: an unproblematic edit still records `ok`."""
    from dsc.client import ToolCall
    from dsc.tools.registry import default_registry

    p = tmp_path / "f.txt"
    p.write_text("hello\n")
    view_run(ViewArgs(path=str(p)))
    reg = default_registry()
    call = ToolCall(
        id="x", name="str_replace",
        arguments={"path": str(p), "old_str": "hello", "new_str": "HI"},
        raw_arguments="{}",
    )
    out, meta = reg.dispatch(call, permissions=None)
    assert out.startswith("Edited")
    assert meta["outcome"] == "ok"
