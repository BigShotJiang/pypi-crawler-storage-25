"""P2.1 subagent tests.

Covers:
- `agent` tool dispatch via `run_session`: parent transcript shows only the
  summary card (not inline tool dispatch), child session row recorded
  with correct `parent_session_id`, iteration cap honored, structured
  errors for out-of-scope tool names.
- Subagent inheriting parent's `PermissionPolicy.always_allow` (mocked).
- `Renderer(headless=True)` does not open a `rich.Live`.
- AGENT_PROFILES never contains "agent" (recursion guard).
- `/subagents` slash command / SLASH_HELP entry.

Streaming uses the same SimpleNamespace-driven fake from `test_session.py`
(not respx — we're testing the agent loop, not the wire). Where this file
needs respx for HTTP-level boundaries it imports it explicitly.
"""
from __future__ import annotations

import io
from types import SimpleNamespace

import pytest
from rich.console import Console

from dsc.client import DSClient, ToolCall
from dsc.permissions import PermissionPolicy
from dsc.render import Renderer
from dsc.session import run_session
from dsc.telemetry import NullTracer, PgTracer
from dsc.tools import agent_tool
from dsc.tools.agent_tool import (
    AGENT_PROFILES,
    AgentDispatchContext,
    set_dispatch_context,
    reset_dispatch_context,
    subset_for,
)
from dsc.tools.registry import default_registry


# ---------- streaming-mock plumbing (mirrors test_session.py) -------------


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return Console(file=buf, force_terminal=False, width=120, color_system=None), buf


def _delta_chunk(*, content=None, tool_calls=None, finish_reason=None, usage=None):
    delta = SimpleNamespace(
        content=content, tool_calls=tool_calls, reasoning_content=None,
    )
    choice = SimpleNamespace(delta=delta, finish_reason=finish_reason)
    usage_obj = None
    if usage is not None:
        usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[choice], usage=usage_obj)


def _final_usage_chunk(usage):
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[], usage=usage_obj)


def _tc_delta(index, *, id=None, name=None, args=None):
    fn = SimpleNamespace(name=name, arguments=args) if (name or args is not None) else None
    return SimpleNamespace(index=index, id=id, function=fn)


def _make_client(scripted_streams):
    """Construct a DSClient whose `_client.chat.completions.create` returns
    the next scripted stream from a list (one stream per iteration)."""
    client = DSClient(api_key="test", model="deepseek-v4-flash")
    streams_iter = iter(scripted_streams)

    def fake_create(**_kwargs):
        return next(streams_iter)

    client._client = SimpleNamespace(
        chat=SimpleNamespace(
            completions=SimpleNamespace(create=fake_create),
        )
    )
    return client


# ---------- AGENT_PROFILES recursion guard -------------------------------


class TestProfilesRecursionGuard:
    def test_agent_tool_not_in_any_profile(self):
        """`agent` MUST NOT appear in any AGENT_PROFILES set — no recursion."""
        for label, tools in AGENT_PROFILES.items():
            assert "agent" not in tools, (
                f"profile {label!r} contains 'agent' — recursion guard broken"
            )

    def test_general_subset_excludes_agent(self):
        reg = default_registry()
        # Sanity: parent has the agent tool registered.
        assert "agent" in reg.names()
        # `general` is computed against the parent at call time.
        general_tools = subset_for("general", reg)
        assert "agent" not in general_tools
        # All non-agent tools should be present.
        for name in reg.names():
            if name == "agent":
                continue
            assert name in general_tools, (
                f"general subset missing parent tool {name!r}"
            )

    def test_unknown_agent_type_raises(self):
        reg = default_registry()
        with pytest.raises(ValueError):
            subset_for("nonexistent", reg)


# ---------- Renderer(headless=True) ---------------------------------------


class TestHeadlessRenderer:
    def test_headless_does_not_open_live(self, monkeypatch):
        """`assistant_turn` in headless mode must not enter a `rich.Live`."""
        live_entered = []

        # Spy on Live.__enter__: if we enter, append. The base class is in
        # `rich.live` — we monkeypatch the import site used in render.py.
        from rich.live import Live as _Live
        original_enter = _Live.__enter__

        def spy_enter(self):
            live_entered.append(True)
            return original_enter(self)

        monkeypatch.setattr(_Live, "__enter__", spy_enter)

        r = Renderer(console=_silent_console(), stream=True, headless=True)
        with r.assistant_turn(iteration=0, max_iters=5) as buf:
            buf.handle("text", "hello")
        assert live_entered == [], "headless renderer must not open Live"

    def test_headless_buffer_collects_info_and_error(self):
        r = Renderer(console=_silent_console(), headless=True)
        r.info("scanning files")
        r.error("oh no")
        # Both routed to the buffer, not the console.
        assert any("scanning" in s for s in r.headless_buffer)
        assert any("oh no" in s for s in r.headless_buffer)

    def test_non_headless_does_open_live(self, monkeypatch):
        """Sanity check: with `headless=False, stream=True` the Live IS opened."""
        live_entered = []
        from rich.live import Live as _Live
        original_enter = _Live.__enter__

        def spy_enter(self):
            live_entered.append(True)
            return original_enter(self)

        monkeypatch.setattr(_Live, "__enter__", spy_enter)
        r = Renderer(console=_silent_console(), stream=True, headless=False)
        with r.assistant_turn(iteration=0, max_iters=5):
            pass
        assert live_entered == [True]

    def test_headless_skip_tool_card_print(self):
        """In headless mode, tool_done does NOT render a Panel to console."""
        from dsc.turn_state import CallStatus
        console, out = _captured_console()
        r = Renderer(console=console, stream=False, headless=True)
        with r.assistant_turn(iteration=0, max_iters=5) as buf:
            buf.handle("tool_call_start", {"index": 0, "id": "a", "name": "view"})
            cs = r.find_call("a")
            tc = ToolCall(
                id="a", name="view",
                arguments={"path": "/tmp/x"}, raw_arguments='{"path":"/tmp/x"}',
            )
            r.tool_done(cs, CallStatus.DONE_OK, tc, "  1\thello\n")
        # No panel printed to the user-facing console.
        assert "view" not in out.getvalue()
        # But the result IS recorded in recent_results so /last works.
        assert len(r.recent_results) == 1


# ---------- Subagent dispatch via the agent tool --------------------------


def _agent_call(prompt: str, agent_type: str = "explore",
                max_iters: int = 5, call_id: str = "call_agent"):
    """Helper: build the streaming chunks that emit one `agent` tool call.

    Uses `json.dumps` to produce valid JSON (Python's `repr` would emit
    single quotes, which the tool's pydantic validator rejects).
    """
    import json as _json
    args_json = _json.dumps({
        "prompt": prompt, "agent_type": agent_type, "max_iters": max_iters,
    })
    return iter([
        _delta_chunk(tool_calls=[_tc_delta(0, id=call_id, name="agent")]),
        _delta_chunk(tool_calls=[_tc_delta(0, args=args_json)],
                     finish_reason="tool_calls"),
        _final_usage_chunk({"prompt_tokens": 30, "completion_tokens": 5}),
    ])


class TestAgentDispatch:
    def test_explore_one_view_then_summary(self, tmp_path):
        """Parent dispatches an explore subagent; subagent does one view +
        final answer. Parent transcript shows ONLY the summary card,
        not the inline view-tool dispatch."""
        target = tmp_path / "data.txt"
        target.write_text("hello\n")

        # Parent stream: emit one `agent(explore, ...)` call, then on the
        # next iteration emit a final answer with the subagent's summary.
        parent_stream_1 = _agent_call(
            f"look at {target}", agent_type="explore", max_iters=3,
            call_id="agent1",
        )
        parent_stream_2 = iter([
            _delta_chunk(content="The file contains hello.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 40, "completion_tokens": 5}),
        ])

        # Subagent stream: emit one `view` tool_call, then a final summary.
        sub_stream_1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="view1", name="view")]),
            _delta_chunk(tool_calls=[_tc_delta(0, args=f'{{"path": "{target}"}}')],
                         finish_reason="tool_calls"),
            _final_usage_chunk({"prompt_tokens": 20, "completion_tokens": 3}),
        ])
        sub_stream_2 = iter([
            _delta_chunk(content="File hello.txt contains 'hello'.",
                         finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 25, "completion_tokens": 8}),
        ])

        # The single shared client serves all four streams in order:
        # parent iter 1 -> subagent iter 1 -> subagent iter 2 -> parent iter 2.
        client = _make_client([
            parent_stream_1, sub_stream_1, sub_stream_2, parent_stream_2,
        ])

        registry = default_registry()
        console, out = _captured_console()
        renderer = Renderer(console=console, stream=False, headless=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        initial = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "explore that file"},
        ]
        result = run_session(
            initial, client, registry,
            permissions=permissions,
            max_iters=5,
            renderer=renderer,
        )

        # Parent saw the subagent's summary text as its final answer.
        assert "hello" in result.final_text.lower()
        # Subagent dispatched (one tool_call) — confirm via parent's recent_results
        # which captured the subagent_card title.
        assert len(renderer.recent_results) >= 1
        cards = [t for t, _ in renderer.recent_results]
        assert any("explore agent" in c for c in cards), (
            f"expected subagent_card title; got {cards!r}"
        )
        # Parent transcript does NOT show the subagent's `view` call inline.
        # The agent tool's tool_done is suppressed (no generic panel) — the
        # only Panel rendered should be the subagent_card itself.
        rendered = out.getvalue()
        # The subagent's `view` tool dispatched against tmp_path, so an
        # inline view-tool result panel would mention the absolute path.
        # The subagent_card body contains the summary text instead.
        assert "explore agent" in rendered

    def test_iteration_cap_honored(self, tmp_path):
        """A subagent that loops past max_iters returns iter_cap outcome
        and the parent's card reflects 'iter_cap'. We give the subagent
        max_iters=2 and feed it 2 streams that both keep dispatching tools
        (no final stop)."""
        target = tmp_path / "x.txt"
        target.write_text("x\n")

        parent_stream_1 = _agent_call(
            "loop forever", agent_type="explore", max_iters=2,
            call_id="agent_loop",
        )
        parent_stream_2 = iter([
            _delta_chunk(content="Subagent capped.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])

        # Two subagent iterations that BOTH dispatch tool calls and never
        # produce final text — hits the iteration cap of 2.
        def _view_call(idx):
            return iter([
                _delta_chunk(tool_calls=[
                    _tc_delta(0, id=f"v{idx}", name="view"),
                ]),
                _delta_chunk(tool_calls=[
                    _tc_delta(0, args=f'{{"path": "{target}"}}'),
                ], finish_reason="tool_calls"),
                _final_usage_chunk({"prompt_tokens": 10, "completion_tokens": 1}),
            ])

        client = _make_client([
            parent_stream_1, _view_call(1), _view_call(2), parent_stream_2,
        ])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        result = run_session(
            [{"role": "system", "content": "s"},
             {"role": "user", "content": "go"}],
            client, registry,
            permissions=permissions, max_iters=5, renderer=renderer,
        )
        # The agent tool returns the subagent's summary (or a placeholder
        # when no final_text was produced). The placeholder string from
        # agent_tool.run() lives in the parent's tool message.
        # Verify by inspecting the parent's tool message content.
        tool_msgs = [m for m in result.messages if m.get("role") == "tool"]
        assert len(tool_msgs) >= 1
        # Either we got a summary or the placeholder. Both signal cap was hit.
        assert (
            "subagent did not produce a final answer" in tool_msgs[0]["content"]
            or "Subagent capped" in result.final_text
        )

    def test_constrained_registry_rejects_out_of_scope_tool(self, tmp_path):
        """Subagent's constrained registry refuses out-of-scope tool names
        with the structured error from `Registry.dispatch`."""
        target = tmp_path / "f.txt"
        target.write_text("data\n")

        parent_stream_1 = _agent_call(
            "try to bash", agent_type="explore", max_iters=3,
            call_id="agent_oob",
        )
        parent_stream_2 = iter([
            _delta_chunk(content="Subagent tried out-of-scope tool.",
                         finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])

        # Subagent emits a `bash` call (NOT in `explore` profile). Then
        # the next iteration produces a final answer.
        sub_stream_1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="b1", name="bash")]),
            _delta_chunk(tool_calls=[_tc_delta(0, args='{"command":"ls"}')],
                         finish_reason="tool_calls"),
            _final_usage_chunk({"prompt_tokens": 10, "completion_tokens": 1}),
        ])
        sub_stream_2 = iter([
            _delta_chunk(content="Bash refused as expected.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 12, "completion_tokens": 4}),
        ])

        client = _make_client([
            parent_stream_1, sub_stream_1, sub_stream_2, parent_stream_2,
        ])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        result = run_session(
            [{"role": "system", "content": "s"},
             {"role": "user", "content": "go"}],
            client, registry,
            permissions=permissions, max_iters=5, renderer=renderer,
        )
        # Parent's final answer composed from the subagent's "bash refused"
        # statement plus its own wrap-up.
        assert "Subagent" in result.final_text or "bash" in result.final_text.lower()


# ---------- Telemetry: child session row + dispatched/completed events ----


class _RecordingWriter:
    """In-process FakeWriter so we can inspect what the tracer emitted."""

    def __init__(self) -> None:
        self.envelopes: list[tuple[str, dict]] = []
        self.drained = False

    def submit(self, kind: str, params: dict) -> None:
        self.envelopes.append((kind, params))

    def drain(self, timeout: float = 2.0) -> None:
        self.drained = True

    def by_kind(self, kind: str) -> list[dict]:
        return [p for k, p in self.envelopes if k == kind]


class TestTelemetry:
    def test_fork_subagent_emits_child_session_row(self):
        """`PgTracer.fork_subagent` returns a child PgTracer; the child's
        `start_session` writes a session row with parent_session_id set
        and session_kind='subagent'."""
        w = _RecordingWriter()
        parent = PgTracer(w)
        parent.start_session(
            model="m", base_url="u", yolo=False, one_shot=False,
            system_prompt="sys", registry_names=["agent"],
            registry_perms={"agent": False},
        )
        starts = w.by_kind("session_start")
        assert len(starts) == 1
        parent_id = starts[0]["session_id"]
        # Parent row has session_kind='root' and no parent_session_id.
        assert starts[0]["session_kind"] == "root"
        assert starts[0]["parent_session_id"] is None

        child = parent.fork_subagent(
            parent_session_id=parent_id,
            parent_iteration_id="iter-id",
            agent_label="explore-1",
            agent_tool_subset=["view", "grep"],
        )
        assert isinstance(child, PgTracer)
        assert child.session_id != parent_id

        child.start_session(
            model="m", base_url="u", yolo=False, one_shot=False,
            system_prompt="child-sys", registry_names=["view", "grep"],
            registry_perms={"view": False, "grep": False},
        )
        starts = w.by_kind("session_start")
        assert len(starts) == 2
        child_row = starts[1]
        assert child_row["parent_session_id"] == parent_id
        assert child_row["session_kind"] == "subagent"
        assert child_row["session_id"] == child.session_id

    def test_subagent_dispatched_and_completed_events(self, tmp_path):
        """End-to-end: the parent's tracer records `subagent_dispatched`
        and `subagent_completed` around an agent dispatch."""
        target = tmp_path / "f.txt"
        target.write_text("ok\n")

        parent_stream_1 = _agent_call(
            f"view {target}", agent_type="explore", max_iters=3,
            call_id="a1",
        )
        parent_stream_2 = iter([
            _delta_chunk(content="parent done.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        sub_stream = iter([
            _delta_chunk(content="Subagent done.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 5, "completion_tokens": 2}),
        ])
        client = _make_client([parent_stream_1, sub_stream, parent_stream_2])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        w = _RecordingWriter()
        tracer = PgTracer(w)
        tracer.start_session(
            model="m", base_url="u", yolo=True, one_shot=False,
            system_prompt="s", registry_names=registry.names(),
            registry_perms={n: registry.get(n).requires_permission for n in registry.names()},
        )

        run_session(
            [{"role": "system", "content": "s"},
             {"role": "user", "content": "go"}],
            client, registry,
            permissions=permissions, max_iters=5,
            renderer=renderer, tracer=tracer,
        )

        # Pick out the subagent-specific event envelopes. The PgTracer.event
        # insert stores the event-kind string in the `kind` key of the
        # params dict (the SQL-named param maps to the table column).
        events = w.by_kind("event")
        dispatched = [e for e in events if e.get("kind") == "subagent_dispatched"]
        completed = [e for e in events if e.get("kind") == "subagent_completed"]
        assert len(dispatched) == 1, f"expected one dispatched event, got {events}"
        assert len(completed) == 1, f"expected one completed event, got {events}"
        # Payload sanity (events store JSON-serialized payload strings).
        import json as _json
        d_payload = _json.loads(dispatched[0]["payload"])
        assert d_payload["agent_type"] == "explore"
        assert d_payload["max_iters"] == 3
        assert "view" in d_payload["tools_allowed"]
        c_payload = _json.loads(completed[0]["payload"])
        assert c_payload["outcome"] == "ok"
        assert c_payload["iterations_used"] >= 1


# ---------- Permission inheritance ---------------------------------------


class TestPermissionInheritance:
    def test_subagent_uses_parent_always_allow_set(self, tmp_path):
        """Subagent dispatches a tool that requires permission; parent's
        `always_allow` propagates by reference, so no prompt fires."""
        # `general` profile has bash (which requires permission). Pre-mark
        # bash as always-allowed on the parent's permission policy. The
        # subagent's PermissionPolicy is the SAME object (passed by
        # reference), so dispatching bash does NOT prompt.
        target = tmp_path / "out.txt"

        parent_stream_1 = _agent_call(
            "do something", agent_type="general", max_iters=3,
            call_id="a_perm",
        )
        parent_stream_2 = iter([
            _delta_chunk(content="Done.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        # Subagent emits a `bash` tool call. Bash requires_permission=True;
        # if the subagent didn't inherit always_allow, this would block on
        # stdin in PermissionPolicy.check (test would hang).
        sub_stream_1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="b1", name="bash")]),
            _delta_chunk(tool_calls=[_tc_delta(0, args=f'{{"command": "echo hi > {target}"}}')],
                         finish_reason="tool_calls"),
            _final_usage_chunk({"prompt_tokens": 5, "completion_tokens": 1}),
        ])
        sub_stream_2 = iter([
            _delta_chunk(content="Wrote the file.", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 6, "completion_tokens": 2}),
        ])
        client = _make_client([
            parent_stream_1, sub_stream_1, sub_stream_2, parent_stream_2,
        ])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)

        # Use yolo=False so the always_allow path is the live one (and
        # not bypassed entirely by yolo). Pre-add bash to always_allow.
        # P3.1: rules_start scopes the rule loader so this test never
        # picks up a stray ~/.dsc/settings.json on the runner.
        permissions = PermissionPolicy(
            yolo=False, console=_silent_console(), rules_start=tmp_path,
        )
        permissions.always_allow.add("bash")

        result = run_session(
            [{"role": "system", "content": "s"},
             {"role": "user", "content": "go"}],
            client, registry,
            permissions=permissions, max_iters=5, renderer=renderer,
        )
        # Parent saw a final answer from the subagent path, no hang.
        assert result.final_text  # non-empty
        # always_allow set is the same object — subagent's permission check
        # could not have fired a prompt (would have hit stdin and hung).
        assert "bash" in permissions.always_allow


# ---------- AgentDispatchContext requirement ------------------------------


class TestDispatchContextRequired:
    def test_agent_run_without_context_returns_error(self):
        """If the agent tool's handler is invoked without a dispatch
        context installed (defensive), it returns a structured error
        rather than spawning a zombie subagent."""
        from dsc.tools.agent_tool import AgentArgs, run as agent_run
        # Make sure no context is installed (the ContextVar default is None).
        out = agent_run(AgentArgs(prompt="hi", agent_type="explore"))
        assert out.startswith("Error:")
        assert "dispatch context" in out


# ---------- /subagents slash command --------------------------------------


class TestSlashSubagents:
    def test_slash_help_lists_subagents(self):
        from dsc.cli import SLASH_HELP
        assert "/subagents" in SLASH_HELP


# ---------- Renderer.subagent_card public surface -------------------------


class TestSubagentCard:
    def test_renders_panel_with_summary(self):
        console, out = _captured_console()
        r = Renderer(console=console, stream=False, headless=False)
        r.subagent_card(
            agent_type="explore",
            iterations=3,
            elapsed_s=0.42,
            total_tokens=1234,
            summary="Found three call sites in src/foo.py.",
        )
        rendered = out.getvalue()
        assert "explore agent" in rendered
        assert "3 iter" in rendered
        assert "Found three call sites" in rendered
        # Recent results gets the entry too so /last works on subagents.
        assert len(r.recent_results) == 1

    def test_iter_cap_outcome_uses_yellow(self):
        # Smoke test: outcome="iter_cap" doesn't crash + records to recent.
        r = Renderer(console=_silent_console(), stream=False)
        r.subagent_card(
            agent_type="general", iterations=10, elapsed_s=1.0,
            total_tokens=100, summary="capped", outcome="iter_cap",
        )
        assert len(r.recent_results) == 1
