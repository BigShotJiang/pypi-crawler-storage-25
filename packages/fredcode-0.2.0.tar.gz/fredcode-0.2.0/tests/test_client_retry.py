"""P1.5 — outer retry layer around `stream_chat` that does NOT replay tool calls.

Covers the four scenarios in the plan:
  1. transient 500 → success: one retry, single tool dispatch downstream,
     telemetry event with `attempt=2, abort_reason=None`.
  2. 500 → 500 → 500: two retry attempts then propagation; telemetry has the
     two retry events plus a final `abort_reason="max_attempts"` event.
  3. mid-stream crash AFTER `tool_call_start` was emitted: NO retry; one
     telemetry event with `abort_reason="tool_dispatched"`.
  4. env override DSC_API_RETRIES=1: zero retries fire (one attempt total).

The retry layer must preserve the `max_retries=0` SDK contract from
AGENTS.md — the openai client is constructed with `max_retries=0`, and the
retry happens at our outer wrapper where we know whether tool deltas have
been emitted yet.
"""
from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any, Iterator

import httpx
import openai
import pytest
import respx

from dsc.client import (
    DSClient,
    RetryingStreamSession,
    StreamSession,
    _is_retryable,
)


# ---------- helpers --------------------------------------------------------


class _FakeChunk:
    """Minimal duck-type for an openai stream chunk (one delta per chunk)."""

    def __init__(
        self,
        *,
        text: str | None = None,
        tool_id: str | None = None,
        tool_name: str | None = None,
        tool_args: str | None = None,
        finish_reason: str | None = None,
        usage: dict | None = None,
    ) -> None:
        delta_kwargs: dict[str, Any] = {"content": text, "reasoning_content": None}
        if tool_id or tool_name or tool_args is not None:
            fn = SimpleNamespace(name=tool_name, arguments=tool_args)
            delta_kwargs["tool_calls"] = [
                SimpleNamespace(index=0, id=tool_id, function=fn)
            ]
        else:
            delta_kwargs["tool_calls"] = None
        delta = SimpleNamespace(**delta_kwargs)
        choice = SimpleNamespace(delta=delta, finish_reason=finish_reason)
        self.choices = [choice]
        self.usage = SimpleNamespace(model_dump=lambda u=usage: dict(u)) if usage else None


def _stream_chunks(chunks: list[_FakeChunk]) -> Iterator[_FakeChunk]:
    """Iterator factory — must be re-callable for respx-style retry tests."""
    yield from chunks


def _good_session_factory() -> StreamSession:
    """A successful 'tool dispatched then done' stream."""
    chunks = [
        _FakeChunk(tool_id="call_42", tool_name="bash"),
        _FakeChunk(tool_args='{"command": "ls"}'),
        _FakeChunk(finish_reason="tool_calls", usage={"prompt_tokens": 10, "completion_tokens": 5}),
    ]
    return StreamSession(_stream_chunks(chunks))


def _make_retry(opener, *, max_retries=3, backoff_base_ms=500):
    """Build a RetryingStreamSession with deterministic sleeps + recording hooks."""
    retries: list[tuple[int, BaseException, int]] = []
    aborts: list[tuple[BaseException, str, int]] = []

    rs = RetryingStreamSession(
        opener,
        max_retries=max_retries,
        backoff_base_ms=backoff_base_ms,
        on_retry=lambda a, e, b: retries.append((a, e, b)),
        on_abort=lambda e, r, ms: aborts.append((e, r, ms)),
        sleep=lambda _s: None,  # don't sleep in tests
    )
    return rs, retries, aborts


# ---------- 1. retryable error classification -----------------------------


def test_retryable_classification():
    # httpx network/transport errors
    assert _is_retryable(httpx.ConnectError("x"))
    assert _is_retryable(httpx.ReadTimeout("x"))
    assert _is_retryable(httpx.RemoteProtocolError("x"))
    # openai SDK transient classes
    assert _is_retryable(openai.APIConnectionError(request=httpx.Request("POST", "https://x")))
    # non-retryable
    assert not _is_retryable(ValueError("x"))
    assert not _is_retryable(KeyboardInterrupt())


# ---------- 2. inner-opener level (deterministic, no HTTP) -----------------


def test_500_then_200_yields_one_retry_and_single_tool_dispatch():
    """500 → 200: one retry; downstream sees a single tool call."""
    call_count = {"n": 0}

    def opener() -> StreamSession:
        call_count["n"] += 1
        if call_count["n"] == 1:
            # Raise BEFORE any chunks come out — simulate 5xx at request time.
            raise httpx.RemoteProtocolError("transient 500")
        return _good_session_factory()

    rs, retries, aborts = _make_retry(opener)

    events = list(rs)

    # Two opener invocations (one failed + one success).
    assert call_count["n"] == 2
    # One retry recorded; no aborts.
    assert len(retries) == 1
    assert len(aborts) == 0
    # `attempt` in the retry callback is the new attempt number (2).
    new_attempt, exc, backoff_ms = retries[0]
    assert new_attempt == 2
    assert isinstance(exc, httpx.RemoteProtocolError)
    assert backoff_ms == 500  # base * 2^0
    # Downstream consumed exactly one tool_call_start (no replay).
    starts = [e for e in events if e[0] == "tool_call_start"]
    assert len(starts) == 1
    assert starts[0][1]["id"] == "call_42"
    # Final result reflects the successful attempt.
    result = rs.result()
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0].id == "call_42"
    assert result.finish_reason == "tool_calls"


def test_three_failures_propagates_and_emits_abort_event():
    """500 → 500 → 500: caller sees the original exception; abort event recorded."""
    call_count = {"n": 0}

    def opener() -> StreamSession:
        call_count["n"] += 1
        raise httpx.ConnectError(f"fail {call_count['n']}")

    rs, retries, aborts = _make_retry(opener, max_retries=3)

    with pytest.raises(httpx.ConnectError):
        list(rs)

    # 3 attempts total = 2 retries + 1 abort.
    assert call_count["n"] == 3
    assert len(retries) == 2
    # Backoff schedule: 500ms, 1000ms (doubling each retry).
    assert [r[2] for r in retries] == [500, 1000]
    # `attempt` reported is the new attempt number (2, 3).
    assert [r[0] for r in retries] == [2, 3]
    # One abort with reason="max_attempts".
    assert len(aborts) == 1
    abort_exc, reason, elapsed_ms = aborts[0]
    assert isinstance(abort_exc, httpx.ConnectError)
    assert reason == "max_attempts"
    assert elapsed_ms >= 0


def test_mid_stream_crash_after_tool_dispatch_no_retry():
    """If a tool_call_start has been yielded, replay is forbidden."""
    call_count = {"n": 0}

    def crashing_chunks():
        # First chunk delivers tool_call_start, then we crash.
        yield _FakeChunk(tool_id="call_99", tool_name="bash")
        raise httpx.ReadTimeout("crash mid-stream")

    def opener() -> StreamSession:
        call_count["n"] += 1
        return StreamSession(crashing_chunks())

    rs, retries, aborts = _make_retry(opener, max_retries=3)

    with pytest.raises(httpx.ReadTimeout):
        list(rs)

    # Only one attempt — NO replay.
    assert call_count["n"] == 1
    assert len(retries) == 0
    # Abort event with reason="tool_dispatched".
    assert len(aborts) == 1
    abort_exc, reason, elapsed_ms = aborts[0]
    assert isinstance(abort_exc, httpx.ReadTimeout)
    assert reason == "tool_dispatched"
    assert elapsed_ms >= 0


def test_env_override_dsc_api_retries_one(monkeypatch):
    """`DSC_API_RETRIES=1` → one attempt, no retries."""
    monkeypatch.setenv("DSC_API_RETRIES", "1")
    monkeypatch.setenv("DEEPSEEK_API_KEY", "test-key")  # required by DSClient

    call_count = {"n": 0}

    client = DSClient(api_key="test-key")
    # Replace the inner with a deterministic failure opener.
    def fake_inner(*args, **kwargs):
        call_count["n"] += 1
        raise httpx.ConnectError("no-go")

    client._stream_chat_inner = fake_inner  # type: ignore[assignment]

    retries: list = []
    aborts: list = []
    client.on_retry = lambda a, e, b: retries.append((a, e, b))
    client.on_abort = lambda e, r, ms: aborts.append((e, r, ms))

    rs = client.stream_chat([{"role": "user", "content": "hi"}])
    with pytest.raises(httpx.ConnectError):
        list(rs)

    # max_retries=1 → one attempt total → zero retries → one abort.
    assert call_count["n"] == 1
    assert len(retries) == 0
    assert len(aborts) == 1
    assert aborts[0][1] == "max_attempts"


def test_env_override_backoff_base_ms(monkeypatch):
    """`DSC_API_BACKOFF_BASE_MS` controls the first backoff and doubling."""
    monkeypatch.setenv("DSC_API_BACKOFF_BASE_MS", "100")
    monkeypatch.setenv("DEEPSEEK_API_KEY", "test-key")
    client = DSClient(api_key="test-key")
    client._stream_chat_inner = lambda *a, **kw: (_ for _ in ()).throw(  # type: ignore[assignment]
        httpx.ConnectError("nope")
    )
    retries: list = []
    client.on_retry = lambda a, e, b: retries.append((a, e, b))
    client.on_abort = lambda e, r, ms: None

    rs = client.stream_chat([{"role": "user", "content": "hi"}])
    # Patch the sleeper so test runs fast.
    rs._sleep = lambda _s: None  # type: ignore[attr-defined]
    with pytest.raises(httpx.ConnectError):
        list(rs)

    # Default 3 attempts → 2 retries with backoffs 100ms, 200ms.
    assert [r[2] for r in retries] == [100, 200]


def test_non_retryable_exception_propagates_without_retry():
    """A non-transient error (e.g., ValueError) is NOT retried."""
    call_count = {"n": 0}

    def opener() -> StreamSession:
        call_count["n"] += 1
        raise ValueError("a programmer bug")

    rs, retries, aborts = _make_retry(opener)
    with pytest.raises(ValueError):
        list(rs)

    assert call_count["n"] == 1
    assert len(retries) == 0
    assert len(aborts) == 0


def test_session_already_consumed():
    """Iterating a RetryingStreamSession twice raises RuntimeError."""
    rs, _, _ = _make_retry(_good_session_factory)
    list(rs)
    with pytest.raises(RuntimeError, match="already consumed"):
        list(rs)


# ---------- 3. respx-based integration test --------------------------------


def _sse_line(data: dict) -> bytes:
    return f"data: {json.dumps(data)}\n\n".encode("utf-8")


def _sse_done() -> bytes:
    return b"data: [DONE]\n\n"


def _ok_sse_body() -> bytes:
    """A minimal SSE stream: assistant text + a tool_call + finish."""
    chunks = [
        {
            "id": "c1", "object": "chat.completion.chunk", "model": "deepseek-v4-flash",
            "choices": [{"index": 0, "delta": {"content": "hi"}, "finish_reason": None}],
        },
        {
            "id": "c1", "object": "chat.completion.chunk", "model": "deepseek-v4-flash",
            "choices": [{
                "index": 0,
                "delta": {"tool_calls": [{
                    "index": 0,
                    "id": "call_xyz",
                    "type": "function",
                    "function": {"name": "bash", "arguments": '{"command":"ls"}'},
                }]},
                "finish_reason": None,
            }],
        },
        {
            "id": "c1", "object": "chat.completion.chunk", "model": "deepseek-v4-flash",
            "choices": [{"index": 0, "delta": {}, "finish_reason": "tool_calls"}],
            "usage": {"prompt_tokens": 12, "completion_tokens": 4},
        },
    ]
    return b"".join(_sse_line(c) for c in chunks) + _sse_done()


@respx.mock
def test_respx_500_then_200_one_retry_clean_stream(monkeypatch):
    """End-to-end via respx: 5xx then a clean 200 stream. One retry observed."""
    monkeypatch.setenv("DEEPSEEK_API_KEY", "test-key")
    # Side-effect-style route: first call returns 500, second returns 200 SSE.
    call_count = {"n": 0}

    def responder(request):
        call_count["n"] += 1
        if call_count["n"] == 1:
            return httpx.Response(500, json={"error": "transient"})
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            content=_ok_sse_body(),
        )

    respx.post("https://api.deepseek.com/v1/chat/completions").mock(side_effect=responder)

    client = DSClient(api_key="test-key")

    retries: list = []
    aborts: list = []
    client.on_retry = lambda a, e, b: retries.append((a, e, b))
    client.on_abort = lambda e, r, ms: aborts.append((e, r, ms))

    rs = client.stream_chat([{"role": "user", "content": "hello"}])
    rs._sleep = lambda _s: None  # type: ignore[attr-defined]
    events = list(rs)

    # One retry recorded (attempt=2 in the new-attempt convention).
    assert len(retries) == 1
    assert retries[0][0] == 2
    assert len(aborts) == 0
    # Two HTTP calls: the failed 500 and the successful 200.
    assert call_count["n"] == 2
    # Downstream sees exactly one tool_call_start (no replay).
    starts = [e for e in events if e[0] == "tool_call_start"]
    assert len(starts) == 1
    result = rs.result()
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0].name == "bash"
    assert result.tool_calls[0].arguments == {"command": "ls"}
