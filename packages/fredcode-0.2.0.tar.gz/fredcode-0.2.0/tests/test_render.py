"""Renderer / TurnState / lifecycle glyph tests.

These tests don't make network calls. They drive _LiveBuffer with synthetic
streaming events and assert the resulting TurnState shape, then exercise
the tool_done lifecycle via Renderer methods.
"""
from __future__ import annotations

import io

import pytest
from rich.console import Console

from dsc.client import ToolCall
from dsc.render import Renderer, _glyph_for, _waiting_verb
from dsc.turn_state import CallStatus


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return Console(file=buf, force_terminal=False, width=120, color_system=None), buf


class TestGlyphTable:
    @pytest.mark.parametrize(
        "status,expected_glyph,expected_color",
        [
            (CallStatus.QUEUED, "◯", "grey50"),
            (CallStatus.PERMISSION, "?", "yellow"),
            (CallStatus.DONE_OK, "✓", "green"),
            (CallStatus.DONE_ERROR, "✗", "red"),
            (CallStatus.DENIED, "⊘", "red"),
        ],
    )
    def test_static_glyphs(self, status, expected_glyph, expected_color):
        glyph, color = _glyph_for(status, "")
        assert glyph == expected_glyph
        assert color == expected_color

    def test_running_uses_spinner_frame(self):
        glyph, color = _glyph_for(CallStatus.RUNNING, "⠹")
        assert glyph == "⠹"
        assert color == "cyan"

    def test_running_falls_back_when_no_spinner(self):
        glyph, _ = _glyph_for(CallStatus.RUNNING, "")
        assert glyph == "⠋"


class TestWaitingVerb:
    def test_short_wait(self):
        assert _waiting_verb(2.0) == "thinking"

    def test_medium_wait(self):
        assert _waiting_verb(8.0) == "still thinking"

    def test_long_wait(self):
        assert _waiting_verb(30.0) == "taking a while"


class TestLiveBufferEvents:
    def _setup(self):
        r = Renderer(console=_silent_console(), stream=False)
        cm = r.assistant_turn(iteration=0, max_iters=11)
        buf = cm.__enter__()
        return r, cm, buf

    def test_reasoning_event_accumulates(self):
        r, cm, buf = self._setup()
        try:
            buf.handle("reasoning", "Let me think")
            buf.handle("reasoning", " about this.")
            assert r._turn.reasoning == "Let me think about this."
            assert r._turn.waiting_first_token is False
            assert r._turn.reasoning_done is False
        finally:
            cm.__exit__(None, None, None)

    def test_text_after_reasoning_marks_reasoning_done(self):
        r, cm, buf = self._setup()
        try:
            buf.handle("reasoning", "thinking…")
            assert r._turn.reasoning_done is False
            buf.handle("text", "I'll do X.")
            assert r._turn.reasoning_done is True
            assert r._turn.reasoning_duration_s is not None
            assert r._turn.text == "I'll do X."
        finally:
            cm.__exit__(None, None, None)

    def test_tool_call_lifecycle_through_streaming(self):
        r, cm, buf = self._setup()
        try:
            buf.handle("tool_call_start", {"index": 0, "id": "call_1", "name": "view"})
            buf.handle("tool_call_args_delta", {"index": 0, "chunk": '{"path":'})
            buf.handle("tool_call_args_delta", {"index": 0, "chunk": '"src/x.py"}'})
            cs = r._turn.calls[0]
            assert cs.name == "view"
            assert cs.call_id == "call_1"
            assert cs.args_str == '{"path":"src/x.py"}'
            assert cs.status == CallStatus.QUEUED
        finally:
            cm.__exit__(None, None, None)

    def test_two_tool_calls_independent_indices(self):
        r, cm, buf = self._setup()
        try:
            buf.handle("tool_call_start", {"index": 0, "id": "a", "name": "view"})
            buf.handle("tool_call_start", {"index": 1, "id": "b", "name": "grep"})
            buf.handle("tool_call_args_delta", {"index": 1, "chunk": '{"pattern":"foo"}'})
            buf.handle("tool_call_args_delta", {"index": 0, "chunk": '{"path":"y.py"}'})
            assert r._turn.calls[0].name == "view"
            assert r._turn.calls[0].args_str == '{"path":"y.py"}'
            assert r._turn.calls[1].name == "grep"
            assert r._turn.calls[1].args_str == '{"pattern":"foo"}'
        finally:
            cm.__exit__(None, None, None)


class TestToolStatusAndDone:
    def test_find_call_by_id(self):
        r = Renderer(console=_silent_console(), stream=False)
        with r.assistant_turn(iteration=0, max_iters=11) as buf:
            buf.handle("tool_call_start", {"index": 0, "id": "abc", "name": "view"})
            cs = r.find_call("abc")
            assert cs is not None
            assert cs.name == "view"
            assert r.find_call("nope") is None

    def test_tool_done_renders_card_and_records_recent(self):
        console, out = _captured_console()
        r = Renderer(console=console, stream=False)
        with r.assistant_turn(iteration=0, max_iters=11) as buf:
            buf.handle("tool_call_start", {"index": 0, "id": "xyz", "name": "view"})
            cs = r.find_call("xyz")
            r.tool_status(cs, CallStatus.RUNNING)
            tc = ToolCall(
                id="xyz", name="view",
                arguments={"path": "src/x.py"}, raw_arguments='{"path":"src/x.py"}',
            )
            r.tool_done(cs, CallStatus.DONE_OK, tc, "  1\thello\n  2\tworld\n")
        rendered = out.getvalue()
        assert "view" in rendered
        assert "src/x.py" in rendered
        assert "✓" in rendered
        assert len(r.recent_results) == 1
        title, full = r.recent_results[0]
        assert "view" in title
        assert "hello" in full

    def test_tool_done_synthesizes_when_streaming_missed_call(self):
        # If the model emits a tool_call without us seeing tool_call_start
        # (shouldn't happen, but defensive), tool_done still prints.
        console, out = _captured_console()
        r = Renderer(console=console, stream=False)
        with r.assistant_turn(iteration=0, max_iters=11):
            tc = ToolCall(id="m", name="grep",
                          arguments={"pattern": "x"}, raw_arguments='{}')
            r.tool_done(None, CallStatus.DONE_OK, tc, "no matches")
        assert "grep" in out.getvalue()

    def test_tool_status_accepts_streaming_lines_count(self):
        # P1.3: bash drain thread pushes a running line count onto the
        # CallState via tool_status(..., lines=N). The final result-card
        # title surfaces it.
        r = Renderer(console=_silent_console(), stream=False)
        with r.assistant_turn(iteration=0, max_iters=11) as buf:
            buf.handle("tool_call_start", {"index": 0, "id": "b", "name": "bash"})
            cs = r.find_call("b")
            r.tool_status(cs, CallStatus.RUNNING, lines=10)
            assert cs.lines == 10
            r.tool_status(cs, CallStatus.RUNNING, lines=42)
            assert cs.lines == 42

    def test_tool_status_lines_default_does_not_clobber(self):
        r = Renderer(console=_silent_console(), stream=False)
        with r.assistant_turn(iteration=0, max_iters=11) as buf:
            buf.handle("tool_call_start", {"index": 0, "id": "b", "name": "bash"})
            cs = r.find_call("b")
            r.tool_status(cs, CallStatus.RUNNING, lines=5)
            r.tool_status(cs, CallStatus.RUNNING)  # no `lines` kwarg
            assert cs.lines == 5  # untouched


class TestUsageAccumulation:
    def test_session_counters_accumulate(self):
        r = Renderer(console=_silent_console(), stream=False)
        r.show_usage(
            {"prompt_tokens": 1000, "completion_tokens": 500,
             "prompt_tokens_details": {"cached_tokens": 200}},
            "deepseek-v4-flash",
        )
        r.show_usage(
            {"prompt_tokens": 2000, "completion_tokens": 100,
             "prompt_tokens_details": {"cached_tokens": 0}},
            "deepseek-v4-flash",
        )
        assert r.session_in == 3000
        assert r.session_out == 600
        assert r.session_cached == 200
        assert r.session_turns == 2
        # Cost is positive and reflects two turns
        assert r.session_cost > 0

    def test_show_usage_handles_missing_usage(self):
        r = Renderer(console=_silent_console(), stream=False)
        r.show_usage(None, "deepseek-v4-flash")
        assert r.session_turns == 0

    def test_unknown_model_falls_back_to_default_rates(self):
        r = Renderer(console=_silent_console(), stream=False)
        r.show_usage({"prompt_tokens": 1000, "completion_tokens": 0}, "unknown-model")
        assert r.session_cost > 0  # used default rates, didn't crash

    def test_cost_summary_format(self):
        r = Renderer(console=_silent_console(), stream=False)
        r.show_usage({"prompt_tokens": 1000, "completion_tokens": 500},
                     "deepseek-v4-flash")
        s = r.cost_summary()
        assert "1 iteration" in s
        assert "1,000" in s
        assert "$" in s


class TestShowTodos:
    def _fake_todos(self):
        from dsc.tools.todo import TodoItem
        return [
            TodoItem(id="1", content="design schema", status="completed"),
            TodoItem(id="2", content="implement endpoint", status="in_progress"),
            TodoItem(id="3", content="write tests", status="pending"),
        ]

    def test_renders_all_three_glyphs(self, monkeypatch):
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        monkeypatch.setattr("dsc.tools.todo.get_todos", self._fake_todos)
        r.show_todos()
        out = buf.getvalue()
        assert "☑" in out
        assert "◐" in out
        assert "☐" in out
        assert "design schema" in out
        assert "implement endpoint" in out
        assert "write tests" in out
        assert "Todos" in out

    def test_empty_todos_prints_nothing(self, monkeypatch):
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        monkeypatch.setattr("dsc.tools.todo.get_todos", lambda: [])
        r.show_todos()
        assert buf.getvalue() == ""

    def test_escapes_brackets_in_content(self, monkeypatch):
        from dsc.tools.todo import TodoItem
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        monkeypatch.setattr(
            "dsc.tools.todo.get_todos",
            lambda: [TodoItem(id="1", content="fix [bug] in parser", status="pending")],
        )
        r.show_todos()
        out = buf.getvalue()
        # Brackets should be visible (not consumed as Rich markup tags).
        assert "[bug]" in out
