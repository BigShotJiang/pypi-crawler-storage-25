"""Permission Panel + [d]etails re-prompt tests.

Patches `rich.prompt.Prompt.ask` so the y/n/a/d loop runs without real
stdin. Captures console output with color_system=None for clean text
assertions.
"""
from __future__ import annotations

import io

import pytest
from rich.console import Console

from dsc.permissions import PermissionPolicy
from dsc.tools.registry import default_registry


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=120, color_system=None),
        buf,
    )


class TestPermissionPanel:
    def test_y_short_circuits(self, monkeypatch, tmp_path):
        console, buf = _captured_console()
        # P3.1: rules_start scopes the rule loader to tmp_path so this
        # test never reads a settings file outside the test sandbox.
        policy = PermissionPolicy(
            yolo=False, console=console, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")

        monkeypatch.setattr(
            "dsc.permissions.Prompt.ask", lambda *a, **kw: "y"
        )
        ok = policy.check(bash_tool, {"command": "ls -la"})
        out = buf.getvalue()

        assert ok is True
        assert policy.last_outcome == "user_y"
        assert "bash" in out
        assert "ls -la" in out
        assert "[y]es" in out
        assert "[n]o" in out
        assert "[a]lways" in out
        assert "[d]etails" in out

    def test_n_returns_false(self, monkeypatch, tmp_path):
        console, buf = _captured_console()
        policy = PermissionPolicy(
            yolo=False, console=console, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")

        monkeypatch.setattr(
            "dsc.permissions.Prompt.ask", lambda *a, **kw: "n"
        )
        ok = policy.check(bash_tool, {"command": "rm -rf /"})

        assert ok is False
        assert policy.last_outcome == "user_n"

    def test_a_adds_to_always_allow(self, monkeypatch, tmp_path):
        console, _ = _captured_console()
        # P3.1: scope ``rules_start`` to tmp_path so the [a] persistence
        # write lands in an isolated dir, and the rule loader doesn't
        # pick up the user's real ~/.dsc/. The legacy ``always_allow``
        # contract under test is unchanged.
        policy = PermissionPolicy(
            yolo=False, console=console, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")

        monkeypatch.setattr(
            "dsc.permissions.Prompt.ask", lambda *a, **kw: "a"
        )
        ok1 = policy.check(bash_tool, {"command": "ls"})
        assert ok1 is True
        assert "bash" in policy.always_allow
        assert policy.last_outcome == "user_a"

        # Second call should bypass the prompt entirely. P3.1 routes
        # this through the live engine's freshly-appended allow rule
        # (``rule_allow`` outcome) for the SAME args; for a different
        # args dict the in-session ``always_allow`` set still applies.
        called = {"n": 0}

        def boom(*a, **kw):
            called["n"] += 1
            return "n"

        monkeypatch.setattr("dsc.permissions.Prompt.ask", boom)
        ok2 = policy.check(bash_tool, {"command": "pwd"})
        assert ok2 is True
        assert policy.last_outcome == "always_allow"
        assert called["n"] == 0

    def test_d_shows_args_then_reprompts(self, monkeypatch, tmp_path):
        console, buf = _captured_console()
        policy = PermissionPolicy(
            yolo=False, console=console, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")

        replies = iter(["d", "n"])
        monkeypatch.setattr(
            "dsc.permissions.Prompt.ask", lambda *a, **kw: next(replies)
        )
        ok = policy.check(bash_tool, {"command": "echo hi", "extra": 42})
        out = buf.getvalue()

        assert ok is False
        assert "full args" in out
        # Args dict is rendered as JSON; both keys should appear.
        assert "echo hi" in out
        assert "extra" in out
        assert "42" in out

    def test_yolo_skips_prompt(self, monkeypatch, tmp_path):
        console, _ = _captured_console()
        policy = PermissionPolicy(
            yolo=True, console=console, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")

        def fail(*a, **kw):
            raise AssertionError("Prompt.ask should not be called in YOLO mode")

        monkeypatch.setattr("dsc.permissions.Prompt.ask", fail)
        ok = policy.check(bash_tool, {"command": "anything"})

        assert ok is True
        assert policy.last_outcome == "yolo"
