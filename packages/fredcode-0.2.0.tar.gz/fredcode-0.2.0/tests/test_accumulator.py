"""Verify ToolCallAccumulator handles partial JSON across deltas."""
from types import SimpleNamespace

from dsc.client import ToolCallAccumulator


def _delta(index, *, id=None, name=None, args=None):
    fn = SimpleNamespace(name=name, arguments=args) if (name is not None or args is not None) else None
    return SimpleNamespace(index=index, id=id, function=fn)


def test_single_call_chunked_args():
    acc = ToolCallAccumulator()
    acc.add([_delta(0, id="call_1", name="bash")])
    acc.add([_delta(0, args='{"comm')])
    acc.add([_delta(0, args='and": "ls"')])
    acc.add([_delta(0, args="}")])
    calls = acc.finalize()
    assert len(calls) == 1
    assert calls[0].id == "call_1"
    assert calls[0].name == "bash"
    assert calls[0].arguments == {"command": "ls"}
    assert calls[0].parse_error is None


def test_parallel_calls_interleaved():
    acc = ToolCallAccumulator()
    acc.add([_delta(0, id="a", name="view"), _delta(1, id="b", name="bash")])
    acc.add([_delta(0, args='{"path":"/tmp"}'), _delta(1, args='{"command":"pwd"}')])
    calls = acc.finalize()
    assert len(calls) == 2
    assert calls[0].name == "view"
    assert calls[0].arguments == {"path": "/tmp"}
    assert calls[1].name == "bash"
    assert calls[1].arguments == {"command": "pwd"}


def test_invalid_json_captured_not_raised():
    acc = ToolCallAccumulator()
    acc.add([_delta(0, id="x", name="bash", args='{"command": ')])
    calls = acc.finalize()
    assert len(calls) == 1
    assert calls[0].parse_error is not None
    assert "Invalid JSON" in calls[0].parse_error


def test_empty_args_defaults_to_empty_object():
    acc = ToolCallAccumulator()
    acc.add([_delta(0, id="x", name="todo_write")])
    calls = acc.finalize()
    assert calls[0].arguments == {}
    assert calls[0].parse_error is None


def test_id_arrives_late_then_args():
    acc = ToolCallAccumulator()
    acc.add([_delta(0, name="bash", args='{')])
    acc.add([_delta(0, id="late_id")])
    acc.add([_delta(0, args='"command":"echo hi"}')])
    calls = acc.finalize()
    assert calls[0].id == "late_id"
    assert calls[0].arguments == {"command": "echo hi"}
