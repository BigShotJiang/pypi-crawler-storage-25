#!/usr/bin/env python3
"""Minimal MCP server fixture for tests (P4.2).

Exposes one tool, ``echo``, that echoes its ``message`` argument back.
Speaks newline-delimited JSON-RPC 2.0 over stdio per the MCP spec. Used
by ``tests/test_mcp.py`` so we don't depend on any real MCP
implementation being installed.

The script is *deliberately* tiny — no schema validation, no logging,
no transport sugar. It just serves the three RPC methods dsc actually
calls during initialization + tool dispatch:

  - ``initialize``  → return protocolVersion + serverInfo + capabilities
  - ``tools/list``  → return one tool descriptor for ``echo``
  - ``tools/call``  → if name=='echo', return the message back

Behavior knobs (set via env so tests can drive the fixture without
edits):

  - ``MCP_ECHO_SLEEP_INIT``  — seconds to sleep before responding to
    initialize. Lets us exercise timeout paths.
  - ``MCP_ECHO_BAD_INIT``    — return a malformed initialize response.
  - ``MCP_ECHO_HANG_CALL``   — block forever inside tools/call.
  - ``MCP_ECHO_RPC_ERROR``   — return a JSON-RPC error envelope on
    tools/call.

Stderr is silent by default; tests can capture it via the client's
``stderr_tail`` if needed.
"""
from __future__ import annotations

import json
import os
import sys
import time


def _send(payload: dict) -> None:
    sys.stdout.write(json.dumps(payload) + "\n")
    sys.stdout.flush()


def _initialize(req: dict) -> None:
    sleep = float(os.environ.get("MCP_ECHO_SLEEP_INIT") or 0)
    if sleep > 0:
        time.sleep(sleep)
    if os.environ.get("MCP_ECHO_BAD_INIT"):
        _send({"jsonrpc": "2.0", "id": req["id"], "result": "not-a-dict"})
        return
    _send({
        "jsonrpc": "2.0",
        "id": req["id"],
        "result": {
            "protocolVersion": "2025-03-26",
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "echo-fixture", "version": "0.1.0"},
        },
    })


def _tools_list(req: dict) -> None:
    _send({
        "jsonrpc": "2.0",
        "id": req["id"],
        "result": {
            "tools": [
                {
                    "name": "echo",
                    "description": "Echo back the input message.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "message": {
                                "type": "string",
                                "description": "Text to echo back.",
                            },
                        },
                        "required": ["message"],
                    },
                },
                {
                    "name": "delete_thing",
                    "description": "Pretend to delete something.",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                        },
                        "required": ["id"],
                    },
                },
            ],
        },
    })


def _tools_call(req: dict) -> None:
    if os.environ.get("MCP_ECHO_HANG_CALL"):
        # Block forever — used to exercise timeout paths.
        while True:
            time.sleep(60)
    if os.environ.get("MCP_ECHO_RPC_ERROR"):
        _send({
            "jsonrpc": "2.0",
            "id": req["id"],
            "error": {
                "code": -32602,
                "message": "scripted RPC error",
                "data": {"detail": "fixture says no"},
            },
        })
        return
    params = req.get("params") or {}
    name = params.get("name")
    args = params.get("arguments") or {}
    if name == "echo":
        msg = str(args.get("message") or "")
        _send({
            "jsonrpc": "2.0",
            "id": req["id"],
            "result": {
                "content": [{"type": "text", "text": f"echo: {msg}"}],
                "isError": False,
            },
        })
        return
    if name == "delete_thing":
        the_id = str(args.get("id") or "")
        _send({
            "jsonrpc": "2.0",
            "id": req["id"],
            "result": {
                "content": [{"type": "text", "text": f"deleted {the_id}"}],
                "isError": False,
            },
        })
        return
    _send({
        "jsonrpc": "2.0",
        "id": req["id"],
        "error": {"code": -32601, "message": f"unknown tool {name!r}"},
    })


def main() -> int:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            # Malformed input — ignore (real servers would respond with
            # a parse error envelope; the fixture mirrors a permissive
            # implementation).
            continue
        if "id" not in req:
            # Notification — drop without responding.
            method = req.get("method") or ""
            if method == "shutdown":
                return 0
            continue
        method = req.get("method") or ""
        if method == "initialize":
            _initialize(req)
        elif method == "tools/list":
            _tools_list(req)
        elif method == "tools/call":
            _tools_call(req)
        else:
            _send({
                "jsonrpc": "2.0",
                "id": req["id"],
                "error": {
                    "code": -32601,
                    "message": f"method not found: {method!r}",
                },
            })
    return 0


if __name__ == "__main__":
    sys.exit(main())
