"""P4.2 MCP integration tests.

Covers the full integration:

  - ``MCPClient`` lifecycle: spawn echo-server fixture, ``initialize``,
    ``tools/list``, ``tools/call`` round-trip; shutdown.
  - ``register_mcp_tools`` mounts adapters with ``mcp__server__tool``
    canonical names; permissions required.
  - Schema deferral: stub description by default; full schema when
    ``FRED_MCP_SCHEMAS=eager`` flips on.
  - Crash recovery: SIGKILL the subprocess mid-session; subsequent calls
    return structured ``Error: ...`` strings, never raise.
  - Permission rule integration: ``deny: ["mcp__echo__*"]`` short-
    circuits at the rule layer with ``rule_deny`` outcome.
  - Permission Panel rendering: MCP tools render with the magenta
    ``mcp · [server] tool`` summary.
  - ``/mcp`` slash output: status colour, tool count, server name.
  - Telemetry: ``mcp_server_connect``, ``mcp_tool_call``,
    ``mcp_server_disconnect`` events fire with the documented payloads.
  - Config: ``parse_mcp_servers`` / ``load_mcp_config`` / ``$VAR``
    substitution.

The fixture at ``tests/fixtures/mcp_echo_server.py`` is a tiny stdio MCP
server we control — no external MCP package needed.
"""
from __future__ import annotations

import io
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

from dsc.mcp import (
    MCPClient,
    MCPClientError,
    MCPSession,
    MCPServerConfig,
    cleanup_servers,
    connect_servers,
    load_mcp_config,
    parse_mcp_servers,
    register_mcp_tools,
    summarize_servers,
)
from dsc.mcp.client import MCPRpcError
from dsc.mcp.lifecycle import (
    STATUS_CONNECTED,
    STATUS_CRASHED,
    STATUS_DISCONNECTED,
)
from dsc.mcp.registry import (
    MCPToolAdapter,
    canonical_tool_name,
    schemas_eager,
)
from dsc.permissions import (
    PermissionPolicy,
    RuleEngine,
    _summary_for,
)
from dsc.tools.registry import Registry


# ---------------------------------------------------------------------------
# Fixture path + config builder
# ---------------------------------------------------------------------------


_FIXTURE = Path(__file__).parent / "fixtures" / "mcp_echo_server.py"


def _echo_config(name: str = "echo", **overrides) -> MCPServerConfig:
    """Build a config that points at the in-tree echo fixture."""
    cfg = dict(
        name=name,
        transport="stdio",
        command=sys.executable,
        args=(str(_FIXTURE),),
        env={},
        cwd=None,
        init_timeout=5,
    )
    cfg.update(overrides)
    return MCPServerConfig(**cfg)


# ---------------------------------------------------------------------------
# Config parsing
# ---------------------------------------------------------------------------


class TestConfigParsing:
    def test_parse_minimal(self):
        settings = {
            "mcp": [{
                "name": "github",
                "type": "stdio",
                "command": "node",
                "args": ["/path/to/server.js"],
            }],
        }
        out = parse_mcp_servers(settings)
        assert len(out) == 1
        assert out[0].name == "github"
        assert out[0].transport == "stdio"
        assert out[0].command == "node"
        assert out[0].args == ("/path/to/server.js",)

    def test_skips_missing_required(self):
        settings = {
            "mcp": [
                {"name": "ok", "command": "node", "args": []},
                {"command": "node"},  # missing name
                {"name": "noempty", "command": ""},
                {"name": "ws", "type": "websocket", "command": "node"},  # bad transport
                "not-a-dict",
            ],
        }
        out = parse_mcp_servers(settings)
        assert len(out) == 1
        assert out[0].name == "ok"

    def test_dedup_within_layer(self):
        settings = {
            "mcp": [
                {"name": "x", "command": "a"},
                {"name": "x", "command": "b"},
            ],
        }
        out = parse_mcp_servers(settings)
        assert len(out) == 1
        # First wins.
        assert out[0].command == "a"

    def test_env_var_substitution(self, monkeypatch):
        cfg = MCPServerConfig(
            name="test",
            transport="stdio",
            command="x",
            env={"TOKEN": "$MY_TEST_TOKEN", "EMPTY": "$NOT_SET"},
        )
        monkeypatch.setenv("MY_TEST_TOKEN", "secret-value")
        resolved = cfg.resolve_env()
        assert resolved == {"TOKEN": "secret-value", "EMPTY": ""}

    def test_load_mcp_config_from_disk(self, tmp_path, monkeypatch):
        # Project-level settings.json
        dsc_dir = tmp_path / ".dsc"
        dsc_dir.mkdir()
        (dsc_dir / "settings.json").write_text(json.dumps({
            "mcp": [{"name": "fs", "command": "node", "args": ["fs.js"]}],
        }))
        # Pretend tmp_path is its own git root so the walk stops there.
        (tmp_path / ".git").mkdir()
        # Stub HOME so the user-level layer is not picked up.
        monkeypatch.setenv("HOME", str(tmp_path / "fake_home"))
        out = load_mcp_config(start=tmp_path)
        assert len(out) == 1
        assert out[0].name == "fs"


# ---------------------------------------------------------------------------
# MCPClient lifecycle (real subprocess)
# ---------------------------------------------------------------------------


class TestMCPClient:
    def test_start_lists_tools(self):
        client = MCPClient(_echo_config())
        try:
            client.start()
            assert client.is_started is True
            assert len(client.tools) == 2
            tool_names = {t["name"] for t in client.tools}
            assert "echo" in tool_names
            assert "delete_thing" in tool_names
            assert client.server_info.get("name") == "echo-fixture"
        finally:
            client.shutdown()

    def test_call_tool_round_trip(self):
        client = MCPClient(_echo_config())
        try:
            client.start()
            result = client.call_tool("echo", {"message": "hi there"})
            assert "content" in result
            assert result["content"][0]["text"] == "echo: hi there"
            assert result.get("isError") is False
        finally:
            client.shutdown()

    def test_rpc_error_envelope(self, monkeypatch):
        monkeypatch.setenv("MCP_ECHO_RPC_ERROR", "1")
        client = MCPClient(_echo_config())
        try:
            client.start()
            with pytest.raises(MCPRpcError) as excinfo:
                client.call_tool("echo", {"message": "x"})
            assert "scripted RPC error" in str(excinfo.value)
            assert excinfo.value.code == -32602
        finally:
            client.shutdown()

    def test_call_unknown_method_raises(self):
        client = MCPClient(_echo_config())
        try:
            client.start()
            with pytest.raises(MCPRpcError):
                client.call_tool("nonexistent_tool", {})
        finally:
            client.shutdown()

    def test_shutdown_is_idempotent(self):
        client = MCPClient(_echo_config())
        client.start()
        client.shutdown()
        client.shutdown()
        assert client.is_started is False

    def test_server_crash_marks_client_crashed(self):
        client = MCPClient(_echo_config())
        try:
            client.start()
            # SIGKILL the subprocess directly. The next call_tool should
            # surface as MCPClientError with the client marked crashed.
            assert client._proc is not None
            os.kill(client._proc.pid, signal.SIGKILL)
            # Give the OS a moment to deliver the signal.
            time.sleep(0.2)
            with pytest.raises(MCPClientError):
                client.call_tool("echo", {"message": "after-death"})
            assert client.is_crashed is True
            assert client.crash_reason
        finally:
            client.shutdown()


# ---------------------------------------------------------------------------
# Schema deferral
# ---------------------------------------------------------------------------


class TestSchemaDeferral:
    def test_default_is_deferred(self, monkeypatch):
        monkeypatch.delenv("FRED_MCP_SCHEMAS", raising=False)
        monkeypatch.delenv("ENABLE_TOOL_SEARCH", raising=False)
        assert schemas_eager() is False

    def test_enable_tool_search_false_means_eager(self, monkeypatch):
        monkeypatch.delenv("FRED_MCP_SCHEMAS", raising=False)
        monkeypatch.setenv("ENABLE_TOOL_SEARCH", "false")
        assert schemas_eager() is True

    def test_fred_mcp_schemas_eager_overrides(self, monkeypatch):
        monkeypatch.setenv("FRED_MCP_SCHEMAS", "eager")
        # Even with auto/default for ENABLE_TOOL_SEARCH, eager wins.
        monkeypatch.delenv("ENABLE_TOOL_SEARCH", raising=False)
        assert schemas_eager() is True

    def test_stub_description_short(self):
        client = MCPClient(_echo_config())
        try:
            client.start()
            adapter = MCPToolAdapter(client, "echo", client.tools[0])
            stub = adapter.stub_description()
            # Must mention server + tool + canonical name.
            assert "echo::echo" in stub or "[MCP]" in stub
            assert "mcp__echo__echo" in stub
            # And NOT contain the full JSON schema content.
            assert "inputSchema" not in stub
        finally:
            client.shutdown()

    def test_deferred_tool_lazy_validates(self, monkeypatch):
        """Calling an MCP tool with bad args raises at handler time even
        when the system catalog held only the stub."""
        monkeypatch.delenv("FRED_MCP_SCHEMAS", raising=False)
        monkeypatch.delenv("ENABLE_TOOL_SEARCH", raising=False)
        client = MCPClient(_echo_config())
        try:
            client.start()
            adapter = MCPToolAdapter(client, "echo", client.tools[0])
            tool = adapter.to_tool(eager=False)
            # The stub args model is permissive — accepts anything.
            stub_args = tool.args_model()  # extra="allow"
            # But at handler time the real schema rejects missing required.
            out = tool.handler(stub_args)
            # Real schema requires `message`; the lazy validation surfaces
            # an Error: prefix.
            assert out.startswith("Error:")
            assert "message" in out.lower()
        finally:
            client.shutdown()


# ---------------------------------------------------------------------------
# connect_servers + register_mcp_tools
# ---------------------------------------------------------------------------


class TestConnectAndRegister:
    def test_connect_and_register_full_flow(self):
        events: list[tuple[str, dict]] = []

        def emit(kind: str, payload: dict) -> None:
            events.append((kind, payload))

        session = connect_servers([_echo_config()], on_event=emit)
        try:
            assert len(session.entries) == 1
            entry = session.entries[0]
            assert entry.status == STATUS_CONNECTED
            assert len(entry.adapters) == 2

            # mcp_server_connect event fired
            kinds = [k for k, _ in events]
            assert "mcp_server_connect" in kinds
            connect_payload = next(p for k, p in events if k == "mcp_server_connect")
            assert connect_payload["name"] == "echo"
            assert connect_payload["transport"] == "stdio"
            assert connect_payload["tool_count"] == 2

            # Register on a fresh registry.
            reg = Registry()
            count = register_mcp_tools(reg, session, on_event=emit)
            assert count == 2
            names = reg.names()
            assert "mcp__echo__echo" in names
            assert "mcp__echo__delete_thing" in names

            # Tool requires permission.
            tool = reg.get("mcp__echo__echo")
            assert tool.requires_permission is True
        finally:
            cleanup_servers(session, on_event=emit)
            disconnect_events = [e for e in events if e[0] == "mcp_server_disconnect"]
            assert len(disconnect_events) == 1

    def test_dispatch_via_registry_returns_text(self):
        session = connect_servers([_echo_config()])
        try:
            reg = Registry()
            register_mcp_tools(reg, session)
            tool = reg.get("mcp__echo__echo")
            args = tool.args_model.model_validate({"message": "world"})
            output = tool.handler(args)
            assert "echo: world" in output
            assert not output.startswith("Error:")
        finally:
            cleanup_servers(session)

    def test_telemetry_per_call(self):
        events: list[tuple[str, dict]] = []

        def emit(kind: str, payload: dict) -> None:
            events.append((kind, payload))

        session = connect_servers([_echo_config()], on_event=emit)
        try:
            reg = Registry()
            register_mcp_tools(reg, session, on_event=emit)
            tool = reg.get("mcp__echo__echo")
            args = tool.args_model.model_validate({"message": "telemetry"})
            tool.handler(args)
            call_events = [p for k, p in events if k == "mcp_tool_call"]
            assert len(call_events) == 1
            payload = call_events[0]
            assert payload["server"] == "echo"
            assert payload["tool"] == "echo"
            assert payload["error_type"] is None
            assert payload["duration_ms"] >= 0
            assert payload["result_chars"] > 0
            assert payload["args_chars"] > 0
        finally:
            cleanup_servers(session, on_event=emit)


# ---------------------------------------------------------------------------
# Crash recovery
# ---------------------------------------------------------------------------


class TestCrashRecovery:
    def test_kill_during_session_returns_structured_error(self):
        session = connect_servers([_echo_config()])
        try:
            reg = Registry()
            register_mcp_tools(reg, session)
            tool = reg.get("mcp__echo__echo")

            # Sanity: first call works.
            ok = tool.handler(tool.args_model.model_validate({"message": "first"}))
            assert "echo: first" in ok

            # Kill the subprocess from underneath.
            entry = session.entries[0]
            assert entry.client and entry.client._proc
            os.kill(entry.client._proc.pid, signal.SIGKILL)
            time.sleep(0.2)

            # Second call must NOT raise; structured Error: string only.
            out = tool.handler(tool.args_model.model_validate({"message": "after"}))
            assert out.startswith("Error:")
            assert "echo" in out  # mentions server name in the message
            assert "crashed" in out.lower() or "unavailable" in out.lower()

            # /mcp summary reflects the crash.
            session.update_crash_states()
            rows = summarize_servers(session)
            assert rows[0]["status"] == STATUS_CRASHED
        finally:
            cleanup_servers(session)

    def test_session_continues_when_one_server_fails(self):
        """A bad command on one server doesn't poison the others."""
        bad_cfg = MCPServerConfig(
            name="bad", transport="stdio",
            command="/nonexistent/command_for_test", args=(),
            env={}, init_timeout=2,
        )
        good_cfg = _echo_config(name="good")
        session = connect_servers([bad_cfg, good_cfg])
        try:
            entries_by_name = {e.config.name: e for e in session.entries}
            assert entries_by_name["bad"].status == STATUS_CRASHED
            assert entries_by_name["bad"].error  # non-empty
            assert entries_by_name["good"].status == STATUS_CONNECTED

            reg = Registry()
            count = register_mcp_tools(reg, session)
            # Only the good server contributes tools.
            assert count == 2
            assert all(n.startswith("mcp__good__") for n in reg.names())
        finally:
            cleanup_servers(session)


# ---------------------------------------------------------------------------
# Permission integration
# ---------------------------------------------------------------------------


class TestPermissionIntegration:
    def test_deny_rule_short_circuits(self, tmp_path, monkeypatch):
        """A `deny: ["mcp__echo__*"]` rule blocks dispatch at the rule
        layer with rule_deny outcome — the subprocess is never called."""
        # Construct a rule engine with a deny rule for the echo server.
        engine = RuleEngine(deny=["mcp__echo__*"])
        # Use a silent console + a non-interactive Permission policy.
        policy = PermissionPolicy(
            console=_silent_console(), rules=engine,
        )
        session = connect_servers([_echo_config()])
        try:
            reg = Registry()
            register_mcp_tools(reg, session)
            tool = reg.get("mcp__echo__echo")
            allowed = policy.check(tool, {"message": "should-block"})
            assert allowed is False
            assert policy.last_outcome == "rule_deny"
            assert policy.last_matched_rule == "mcp__echo__*"
        finally:
            cleanup_servers(session)

    def test_allow_rule_lets_call_through(self):
        engine = RuleEngine(allow=["mcp__echo__echo"])
        policy = PermissionPolicy(
            console=_silent_console(), rules=engine,
        )
        session = connect_servers([_echo_config()])
        try:
            reg = Registry()
            register_mcp_tools(reg, session)
            tool = reg.get("mcp__echo__echo")
            allowed = policy.check(tool, {"message": "ok"})
            assert allowed is True
            assert policy.last_outcome == "rule_allow"
        finally:
            cleanup_servers(session)

    def test_dispatch_returns_denied_via_registry(self):
        from dsc.client import ToolCall

        engine = RuleEngine(deny=["mcp__echo__*"])
        policy = PermissionPolicy(
            console=_silent_console(), rules=engine,
        )
        session = connect_servers([_echo_config()])
        try:
            reg = Registry()
            register_mcp_tools(reg, session)
            call = ToolCall(
                id="t1",
                name="mcp__echo__echo",
                arguments={"message": "x"},
                raw_arguments=json.dumps({"message": "x"}),
            )
            output, meta = reg.dispatch(call, permissions=policy)
            assert output.startswith("Error:")
            assert "denied" in output.lower()
            assert meta["outcome"] == "denied"
            assert meta["permission_outcome"] == "rule_deny"
            assert meta["matched_rule"] == "mcp__echo__*"
        finally:
            cleanup_servers(session)


# ---------------------------------------------------------------------------
# Permission Panel rendering
# ---------------------------------------------------------------------------


class TestPanelSummary:
    def test_mcp_tool_renders_with_server_brackets(self):
        out = _summary_for("mcp__github__list_issues", {"repo": "foo/bar"})
        as_text = out.plain
        assert "mcp" in as_text
        assert "[github]" in as_text
        assert "list_issues" in as_text
        assert "foo/bar" in as_text


# ---------------------------------------------------------------------------
# /mcp slash output (programmatic)
# ---------------------------------------------------------------------------


class TestSummarizeServers:
    def test_summary_includes_all_status_categories(self):
        bad_cfg = MCPServerConfig(
            name="bad", transport="stdio",
            command="/nonexistent_for_test", args=(),
            init_timeout=1,
        )
        session = connect_servers([_echo_config(), bad_cfg])
        try:
            rows = summarize_servers(session)
            by_name = {r["name"]: r for r in rows}
            assert by_name["echo"]["status"] == STATUS_CONNECTED
            assert by_name["echo"]["tool_count"] == 2
            assert "echo" in by_name["echo"]["tools"]
            assert "delete_thing" in by_name["echo"]["tools"]
            assert by_name["bad"]["status"] == STATUS_CRASHED
            assert by_name["bad"]["error"]
        finally:
            cleanup_servers(session)

    def test_summary_empty_when_no_session(self):
        rows = summarize_servers(None)  # type: ignore[arg-type]
        assert rows == []


# ---------------------------------------------------------------------------
# Canonical name + adapter primitives
# ---------------------------------------------------------------------------


class TestPrimitives:
    def test_canonical_name(self):
        assert canonical_tool_name("github", "list_issues") == "mcp__github__list_issues"

    def test_eager_mode_full_description(self, monkeypatch):
        monkeypatch.setenv("FRED_MCP_SCHEMAS", "eager")
        client = MCPClient(_echo_config())
        try:
            client.start()
            adapter = MCPToolAdapter(client, "echo", client.tools[0])
            tool = adapter.to_tool(eager=True)
            # Eager mode: the description is the full server text, not
            # the stub template.
            assert "Echo back" in tool.description
            # Args model has the actual `message` field, not just extra-
            # allow placeholder.
            schema = tool.args_model.model_json_schema()
            assert "message" in schema.get("properties", {})
            assert "message" in schema.get("required", [])
        finally:
            client.shutdown()


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _silent_console():
    from rich.console import Console
    return Console(file=io.StringIO(), force_terminal=False, width=120, color_system=None)
