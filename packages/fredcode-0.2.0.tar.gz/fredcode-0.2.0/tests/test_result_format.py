"""Per-tool result formatter tests."""
from __future__ import annotations

import pytest

from dsc.result_format import format_result


class TestView:
    def test_file_with_total_hint(self):
        result = "  1\tline one\n  2\tline two\n  3\tline three\n[showing lines 1-3 of 200]"
        summary, preview = format_result("view", {"path": "src/foo.py"}, result)
        assert summary == "src/foo.py · 200 lines"
        assert "more lines" in preview
        assert "/last" in preview

    def test_short_file(self):
        result = "  1\thello\n  2\tworld"
        summary, preview = format_result("view", {"path": "x.py"}, result)
        assert summary == "x.py · 2 lines"
        assert "more lines" not in preview

    def test_directory_listing(self):
        result = "Directory: /tmp\n  src/\n  README.md"
        summary, _ = format_result("view", {"path": "/tmp"}, result)
        assert "/tmp" in summary
        assert "entr" in summary  # entry/entries

    def test_error(self):
        summary, preview = format_result("view", {"path": "nope"}, "Error: file not found")
        assert summary == "Error: file not found"
        assert preview == "Error: file not found"


class TestBash:
    def test_with_exit_code(self):
        result = "[exit 0]\nhello\nworld"
        summary, preview = format_result("bash", {"command": "echo hello && echo world"}, result)
        assert summary.startswith("exit 0 ·")
        assert "echo hello" in summary
        assert "hello" in preview
        assert "world" in preview

    def test_nonzero_exit(self):
        summary, _ = format_result("bash", {"command": "false"}, "[exit 1]\n")
        assert "exit 1" in summary

    def test_long_command_truncated(self):
        cmd = "x" * 200
        summary, _ = format_result("bash", {"command": cmd}, "[exit 0]\n")
        assert "…" in summary

    def test_no_exit_prefix(self):
        summary, _ = format_result("bash", {"command": "ls"}, "a\nb\nc")
        # Line count appended to the header (P1.3): "$ ls · 3 lines"
        assert summary.startswith("$ ls")
        assert "3 lines" in summary


class TestGrep:
    def test_matches_summary(self):
        result = (
            "src/a.py:10:foo\n"
            "src/a.py:20:foo\n"
            "src/b.py:5:foo\n"
        )
        summary, preview = format_result("grep", {"pattern": "foo"}, result)
        assert "3 matches" in summary
        assert "2 files" in summary
        assert '"foo"' in summary

    def test_no_matches(self):
        summary, preview = format_result("grep", {"pattern": "x"}, "No matches found.")
        assert summary == "No matches found."

    def test_single_match(self):
        result = "x.py:1:foo"
        summary, _ = format_result("grep", {"pattern": "foo"}, result)
        assert "1 match" in summary
        assert "1 file" in summary
        assert "matches" not in summary  # singular


class TestGlob:
    def test_files_summary(self):
        result = "src/a.py\nsrc/b.py\nsrc/c.py"
        summary, _ = format_result("glob", {"pattern": "src/*.py"}, result)
        assert "3 files" in summary
        assert "src/*.py" in summary

    def test_no_files(self):
        summary, _ = format_result("glob", {"pattern": "*.x"}, "No files matching pattern.")
        assert summary == "No files matching pattern."


class TestSimpleFormatters:
    def test_str_replace(self):
        summary, _ = format_result("str_replace", {"path": "x.py"}, "Replaced 1 occurrence.")
        assert summary == "x.py"

    def test_create_file(self):
        summary, _ = format_result("create_file", {"path": "y.py"}, "Created y.py")
        assert summary == "y.py"

    def test_todo(self):
        summary, _ = format_result("todo_write",
                                   {"todos": [{"id": "1", "content": "x", "status": "pending"}]},
                                   "Todo list updated:\n  [ ] x")
        assert summary == "1 item"

    def test_unknown_tool_falls_back_to_generic(self):
        summary, preview = format_result("nonexistent_tool", {}, "line1\nline2\nline3\nline4")
        assert "4 lines" in summary
        assert "more lines" in preview

    def test_empty_result_generic(self):
        summary, preview = format_result("nonexistent_tool", {}, "")
        assert summary == "(empty)"
        assert preview == ""
