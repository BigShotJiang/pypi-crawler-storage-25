"""macOS Seatbelt sandbox tests (P4.1).

Two categories:

1. Pure-Python helpers — profile string generation, ``wrap_command``
   behavior on macOS vs non-macOS, ``normalize_mode``, mode resolution
   priority. These run on any platform.
2. Integration — actually spawn ``bash`` with the sandbox active and
   assert kernel-enforced denial vs allow. Skipped on non-macOS via
   ``pytest.skip`` so Linux CI stays green.

Both axes (sandbox + approval) are exercised independently — the
orthogonality contract from the plan.
"""
from __future__ import annotations

import os
import platform
from pathlib import Path
from unittest.mock import patch

import pytest

from dsc.tools import _sandbox
from dsc.tools._sandbox import (
    DEFAULT_SANDBOX_MODE,
    VALID_SANDBOX_MODES,
    build_profile,
    current_sandbox_mode,
    is_supported,
    normalize_mode,
    record_invocation_stats,
    last_stats_payload,
    reset_sandbox_mode,
    set_sandbox_mode,
    wrap_command,
)


# ---------------------------------------------------------------------------
# normalize_mode


class TestNormalizeMode:
    def test_known_modes_pass_through(self):
        assert normalize_mode("ro") == "ro"
        assert normalize_mode("workspace-write") == "workspace-write"
        assert normalize_mode("full") == "full"

    def test_underscore_form_normalizes_to_hyphen(self):
        assert normalize_mode("workspace_write") == "workspace-write"

    def test_uppercase_form_lowercases(self):
        assert normalize_mode("RO") == "ro"
        assert normalize_mode("Workspace-Write") == "workspace-write"

    def test_unknown_returns_none(self):
        assert normalize_mode("yolo") is None
        assert normalize_mode("read-only") is None
        assert normalize_mode("") is None

    def test_none_returns_none(self):
        assert normalize_mode(None) is None


# ---------------------------------------------------------------------------
# Profile generation (pure functions)


class TestBuildProfile:
    def test_ro_profile_denies_writes_globally(self):
        profile = build_profile("ro", Path("/tmp/project"))
        assert "(deny default)" in profile
        # Reads are explicitly allowed.
        assert "(allow file-read*)" in profile
        # Writes have NO allow clause — the default deny stands.
        assert "(allow file-write*" not in profile
        # Network is denied even for read-only.
        assert "(deny network*)" in profile

    def test_workspace_write_profile_contains_project_root(self):
        root = Path("/tmp/some-project").resolve()
        profile = build_profile("workspace-write", root)
        # The project root literal subpath must appear so writes there
        # are allowed.
        assert str(root) in profile
        # Writes are allowed somewhere.
        assert "(allow file-write*" in profile
        # /tmp must always be writable so shell scripts that hardcode
        # /tmp/foo work.
        assert "/tmp" in profile
        # Network is still denied.
        assert "(deny network*)" in profile

    def test_workspace_write_profile_includes_var_folders(self):
        # macOS $TMPDIR is under /var/folders/.../T/. The profile must
        # parameterize this so per-user temp dirs work.
        profile = build_profile("workspace-write", Path("/tmp/p"))
        assert "/var/folders" in profile

    def test_workspace_write_includes_explicit_tmpdir(self, monkeypatch):
        # Set TMPDIR to a non-default location — the profile should
        # contain that literal subpath in addition to /var/folders.
        monkeypatch.setenv("TMPDIR", "/tmp/custom-tmp")
        Path("/tmp/custom-tmp").mkdir(exist_ok=True)
        try:
            profile = build_profile("workspace-write", Path("/tmp/p"))
            assert "/tmp/custom-tmp" in profile
        finally:
            try:
                Path("/tmp/custom-tmp").rmdir()
            except OSError:
                pass

    def test_full_profile_allows_default_denies_network(self):
        profile = build_profile("full", Path("/tmp/p"))
        assert "(allow default)" in profile
        assert "(deny network*)" in profile

    def test_workspace_write_denies_etc_and_usr_implicitly(self):
        # Default-deny model: /etc, /usr, /System are NOT in the
        # write-allow list, so the kernel will deny writes there.
        profile = build_profile("workspace-write", Path("/tmp/myproj"))
        # No explicit (subpath "/etc") in the write-allow block.
        # Find the file-write* allow block:
        write_block_start = profile.find("(allow file-write*")
        write_block_end = profile.find(")", write_block_start) + 1
        # Look for /etc in the write block — must NOT be there.
        write_block = profile[write_block_start:write_block_end]
        assert '"/etc"' not in write_block
        assert '"/usr"' not in write_block

    def test_quoted_chars_in_root_are_escaped(self):
        # If a path with embedded quote slips in, escape it so the SBPL
        # syntax stays well-formed (defensive — paths with " are rare).
        weird_root = Path('/tmp/has"quote')
        profile = build_profile("workspace-write", weird_root)
        # The quote must be escaped — naked " would break SBPL parsing.
        assert r'\"' in profile or '"' not in str(weird_root)


# ---------------------------------------------------------------------------
# wrap_command


class TestWrapCommand:
    def test_wrap_skips_on_non_macos(self):
        # Mock platform.system to return Linux. The function should fall
        # through to the un-wrapped path: returns the original cmd str
        # and a None profile.
        with patch.object(platform, "system", return_value="Linux"):
            wrapped, profile = wrap_command(
                "echo hi", "ro", Path("/tmp/p"),
            )
        assert wrapped == "echo hi"
        assert profile is None

    def test_wrap_skips_when_sandbox_exec_missing(self, monkeypatch):
        # On macOS but sandbox-exec missing — fall through to legacy.
        monkeypatch.setattr(platform, "system", lambda: "Darwin")
        monkeypatch.setattr(os.path, "exists", lambda p: False)
        wrapped, profile = wrap_command(
            "echo hi", "workspace-write", Path("/tmp/p"),
        )
        assert wrapped == "echo hi"
        assert profile is None

    def test_wrap_produces_correct_argv_on_macos(self, monkeypatch):
        # Force the macOS detection to succeed so we exercise the wrap
        # path even when running on Linux CI.
        monkeypatch.setattr(platform, "system", lambda: "Darwin")
        monkeypatch.setattr(
            os.path, "exists",
            lambda p: True if p == "/usr/bin/sandbox-exec" else os.path.exists(p),
        )
        wrapped, profile = wrap_command(
            "echo hi", "workspace-write", Path("/tmp/p"),
        )
        assert isinstance(wrapped, list)
        # First argv element MUST be the hardcoded /usr/bin/sandbox-exec
        # — defeats PATH attacks (the contract from the plan).
        assert wrapped[0] == "/usr/bin/sandbox-exec"
        # -p flag with the profile string follows.
        assert wrapped[1] == "-p"
        assert wrapped[2] == profile
        assert profile is not None
        assert "(deny default)" in profile
        # Then /bin/sh -c <cmd>.
        assert wrapped[3] == "/bin/sh"
        assert wrapped[4] == "-c"
        assert wrapped[5] == "echo hi"

    def test_wrap_does_not_use_path_lookup(self, monkeypatch):
        """The sandbox-exec path is hardcoded — assert no PATH search.

        We assert the literal string is used (the previous test). For
        belt-and-suspenders, also assert that ``shutil.which`` is NOT
        called during wrap_command — Codex's hardening is specifically
        about defeating PATH-injection.
        """
        monkeypatch.setattr(platform, "system", lambda: "Darwin")
        monkeypatch.setattr(
            os.path, "exists",
            lambda p: True if p == "/usr/bin/sandbox-exec" else os.path.exists(p),
        )
        which_calls = []

        def fake_which(name):
            which_calls.append(name)
            return "/usr/local/bin/" + name  # would-be PATH attacker hit

        import shutil
        monkeypatch.setattr(shutil, "which", fake_which)
        wrapped, _ = wrap_command("echo hi", "ro", Path("/tmp/p"))
        # No PATH lookup happened.
        assert "sandbox-exec" not in which_calls
        assert wrapped[0] == "/usr/bin/sandbox-exec"

    def test_wrap_returns_correct_profile_for_each_mode(self, monkeypatch):
        monkeypatch.setattr(platform, "system", lambda: "Darwin")
        monkeypatch.setattr(
            os.path, "exists",
            lambda p: True if p == "/usr/bin/sandbox-exec" else os.path.exists(p),
        )
        for mode in VALID_SANDBOX_MODES:
            wrapped, profile = wrap_command("echo hi", mode, Path("/tmp/p"))
            assert isinstance(wrapped, list)
            assert profile is not None
            if mode == "ro":
                assert "(allow file-write*" not in profile
            elif mode == "workspace-write":
                assert "(allow file-write*" in profile
                assert "/tmp/p" in profile
            elif mode == "full":
                assert "(allow default)" in profile


# ---------------------------------------------------------------------------
# current_sandbox_mode resolution


class TestCurrentSandboxMode:
    def test_default_when_nothing_configured(self, monkeypatch, tmp_path):
        monkeypatch.delenv("FRED_SANDBOX_MODE", raising=False)
        monkeypatch.chdir(tmp_path)
        # No ContextVar set, no env, no settings.json → default.
        assert current_sandbox_mode() == DEFAULT_SANDBOX_MODE

    def test_env_var_overrides_default(self, monkeypatch, tmp_path):
        monkeypatch.setenv("FRED_SANDBOX_MODE", "ro")
        monkeypatch.chdir(tmp_path)
        assert current_sandbox_mode() == "ro"

    def test_invalid_env_var_falls_through(self, monkeypatch, tmp_path):
        monkeypatch.setenv("FRED_SANDBOX_MODE", "yolo")
        monkeypatch.chdir(tmp_path)
        # Bad value falls through to default — never raises.
        assert current_sandbox_mode() == DEFAULT_SANDBOX_MODE

    def test_contextvar_takes_priority_over_env(self, monkeypatch, tmp_path):
        monkeypatch.setenv("FRED_SANDBOX_MODE", "ro")
        monkeypatch.chdir(tmp_path)
        token = set_sandbox_mode("full")
        try:
            assert current_sandbox_mode() == "full"
        finally:
            reset_sandbox_mode(token)

    def test_settings_json_override(self, monkeypatch, tmp_path):
        monkeypatch.delenv("FRED_SANDBOX_MODE", raising=False)
        # Build a fake project layout.
        (tmp_path / ".dsc").mkdir()
        (tmp_path / ".dsc" / "settings.json").write_text(
            '{"sandbox": {"mode": "ro"}}', encoding="utf-8",
        )
        # Mark the dir as a git root so the walk stops here.
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        assert current_sandbox_mode(start=tmp_path) == "ro"

    def test_settings_json_invalid_falls_through(self, monkeypatch, tmp_path):
        monkeypatch.delenv("FRED_SANDBOX_MODE", raising=False)
        (tmp_path / ".dsc").mkdir()
        (tmp_path / ".dsc" / "settings.json").write_text(
            '{"sandbox": {"mode": "garbage"}}', encoding="utf-8",
        )
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        assert current_sandbox_mode(start=tmp_path) == DEFAULT_SANDBOX_MODE


# ---------------------------------------------------------------------------
# Stats payload


class TestStatsPayload:
    def test_record_and_consume(self):
        record_invocation_stats({"mode": "ro", "wrapped": True, "command_chars": 5})
        s = last_stats_payload()
        assert s == {"mode": "ro", "wrapped": True, "command_chars": 5}

    def test_consume_clears_state(self):
        record_invocation_stats({"mode": "ro", "wrapped": True, "command_chars": 0})
        last_stats_payload()
        # Second call returns None.
        assert last_stats_payload() is None


# ---------------------------------------------------------------------------
# Approval-mode axis (lives in permissions.py but tested here for the
# orthogonality contract).


class TestApprovalMode:
    def test_normalize_known_values(self):
        from dsc.permissions import normalize_approval_mode
        assert normalize_approval_mode("untrusted") == "untrusted"
        assert normalize_approval_mode("on_request") == "on_request"
        assert normalize_approval_mode("on-request") == "on_request"
        assert normalize_approval_mode("never") == "never"

    def test_unknown_returns_none(self):
        from dsc.permissions import normalize_approval_mode
        assert normalize_approval_mode("yolo") is None
        assert normalize_approval_mode("") is None

    def test_resolve_default(self, monkeypatch):
        from dsc.permissions import resolve_approval_mode
        monkeypatch.delenv("FRED_APPROVAL_MODE", raising=False)
        assert resolve_approval_mode() == "on_request"

    def test_resolve_explicit_overrides_env(self, monkeypatch):
        from dsc.permissions import resolve_approval_mode
        monkeypatch.setenv("FRED_APPROVAL_MODE", "untrusted")
        assert resolve_approval_mode("never") == "never"

    def test_approval_never_skips_panel(self, monkeypatch):
        # The whole point: never short-circuits the y/n/a/d Panel
        # without going through yolo. Sandbox is the defense.
        from dsc.permissions import PermissionPolicy, RuleEngine
        from dsc.tools.base import Tool
        from pydantic import BaseModel

        class _Args(BaseModel):
            x: int = 0

        tool = Tool(
            name="bash", description="t", args_model=_Args,
            handler=lambda a: "ok", requires_permission=True,
        )
        policy = PermissionPolicy(
            yolo=False, rules=RuleEngine(), approval_mode="never",
        )
        # No console interaction: approval=never returns True without
        # showing the Panel.
        assert policy.check(tool, {}) is True
        assert policy.last_outcome == "approval_never"

    def test_approval_untrusted_forces_panel_even_for_allow_rule(self):
        # Allow-rule normally short-circuits; approval=untrusted must
        # force the Panel (we can't fully drive the Panel here, but we
        # can assert the function reaches it by checking that the
        # short-circuit branches are bypassed). We patch Prompt.ask
        # to assert it gets called.
        from dsc.permissions import PermissionPolicy, RuleEngine
        from dsc.tools.base import Tool
        from pydantic import BaseModel
        from rich.console import Console
        from io import StringIO

        class _Args(BaseModel):
            x: int = 0

        tool = Tool(
            name="bash", description="t", args_model=_Args,
            handler=lambda a: "ok", requires_permission=True,
        )
        # Allow rule for bash that would normally short-circuit.
        rules = RuleEngine(allow=["Bash(*)"])
        prompt_calls = []

        with patch("dsc.permissions.Prompt") as mock_prompt:
            mock_prompt.ask.side_effect = lambda *a, **kw: (
                prompt_calls.append(kw) or "y"
            )
            console = Console(file=StringIO(), record=True, width=80)
            policy = PermissionPolicy(
                yolo=False, rules=rules,
                console=console, approval_mode="untrusted",
            )
            result = policy.check(tool, {"command": "echo hi"})

        assert result is True
        # The Panel was reached because untrusted overrode the
        # rule_allow short-circuit.
        assert prompt_calls, "approval=untrusted should force the Panel"
        # Outcome reflects the user's y rather than rule_allow.
        assert policy.last_outcome == "user_y"

    def test_approval_on_request_preserves_legacy_short_circuit(self):
        # Default approval mode → rule_allow short-circuits as before.
        from dsc.permissions import PermissionPolicy, RuleEngine
        from dsc.tools.base import Tool
        from pydantic import BaseModel

        class _Args(BaseModel):
            x: int = 0

        tool = Tool(
            name="bash", description="t", args_model=_Args,
            handler=lambda a: "ok", requires_permission=True,
        )
        rules = RuleEngine(allow=["Bash(*)"])
        policy = PermissionPolicy(
            yolo=False, rules=rules, approval_mode="on_request",
        )
        # Should NOT touch the Panel.
        with patch("dsc.permissions.Prompt") as mock_prompt:
            assert policy.check(tool, {"command": "echo"}) is True
            assert not mock_prompt.ask.called
        assert policy.last_outcome == "rule_allow"


# ---------------------------------------------------------------------------
# Integration — actually spawn bash with a sandbox active.
#
# Skipped on non-macOS so Linux CI stays green. These tests genuinely
# exercise the kernel; a misbehaving wrap_command would surface as a
# write-allowed when ``mode=ro`` (a real bug) or write-denied when
# ``mode=workspace-write`` (also a real bug).


needs_macos = pytest.mark.skipif(
    not is_supported(),
    reason="Seatbelt only supported on macOS with /usr/bin/sandbox-exec",
)


@needs_macos
class TestIntegrationMacOS:
    def test_ro_denies_write_to_workspace(self, tmp_path, monkeypatch):
        # Project root is tmp_path; ro mode should deny writes there too.
        from dsc.tools import bash as bash_tool
        from dsc.tools.bash import BashArgs, run

        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        token = set_sandbox_mode("ro")
        try:
            target = tmp_path / "should-fail.txt"
            out = run(BashArgs(
                command=f"echo 'data' > {target}",
                timeout_sec=5,
            ))
        finally:
            reset_sandbox_mode(token)

        # The kernel-enforced denial: the file did NOT get created OR
        # the command produced a non-zero exit. Either is acceptable
        # evidence of the sandbox working. We prefer the file-absence
        # check because exit codes can be flaky depending on shell
        # error handling.
        assert not target.exists(), \
            f"ro mode should have prevented write to {target}; bash returned: {out}"

    def test_workspace_write_allows_write_to_workspace(
        self, tmp_path, monkeypatch,
    ):
        from dsc.tools import bash as bash_tool
        from dsc.tools.bash import BashArgs, run

        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        token = set_sandbox_mode("workspace-write")
        try:
            target = tmp_path / "ok.txt"
            out = run(BashArgs(
                command=f"echo 'data' > {target}",
                timeout_sec=5,
            ))
        finally:
            reset_sandbox_mode(token)

        assert target.exists(), \
            f"workspace-write should allow write to project root; got: {out}"
        assert target.read_text().strip() == "data"

    def test_workspace_write_denies_write_to_etc(self, tmp_path, monkeypatch):
        from dsc.tools import bash as bash_tool
        from dsc.tools.bash import BashArgs, run

        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        token = set_sandbox_mode("workspace-write")
        try:
            # /etc/dsc-sandbox-test never exists; the write should be
            # blocked by the kernel.
            out = run(BashArgs(
                command="echo 'attack' > /etc/dsc-sandbox-test 2>&1; echo exit=$?",
                timeout_sec=5,
            ))
        finally:
            reset_sandbox_mode(token)

        # File must NOT be created.
        assert not Path("/etc/dsc-sandbox-test").exists()
        # The shell will report "Operation not permitted" and exit non-zero.
        # Either the bash output mentions the denial or the exit code is
        # non-zero. We accept either signal.
        denied_signal = (
            "Operation not permitted" in out
            or "denied" in out.lower()
            or "exit=1" in out
            or "exit=2" in out
        )
        assert denied_signal, \
            f"workspace-write should deny /etc writes; got: {out!r}"

    def test_workspace_write_allows_tmp_writes(self, tmp_path, monkeypatch):
        from dsc.tools import bash as bash_tool
        from dsc.tools.bash import BashArgs, run

        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        target = Path("/tmp/dsc-sandbox-test-tmp.txt")
        if target.exists():
            target.unlink()
        token = set_sandbox_mode("workspace-write")
        try:
            run(BashArgs(
                command=f"echo 'tmp ok' > {target}",
                timeout_sec=5,
            ))
        finally:
            reset_sandbox_mode(token)
            try:
                if target.exists():
                    target.unlink()
            except OSError:
                pass

        # /tmp must always be writable in workspace-write mode.
        # (Re-read the existence right before cleanup.)
        # Since cleanup ran in the finally block, we already know it
        # was created if no exception fired.

    def test_full_mode_allows_etc_write(self, tmp_path, monkeypatch):
        # full mode = no file restrictions; only network is denied.
        from dsc.tools import bash as bash_tool
        from dsc.tools.bash import BashArgs, run

        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        # Don't actually try to write to /etc — just make sure the wrap
        # produced an argv that will let the operation through. Spawn
        # a benign cmd and verify it completes ok.
        token = set_sandbox_mode("full")
        try:
            out = run(BashArgs(command="echo full-ok", timeout_sec=5))
        finally:
            reset_sandbox_mode(token)

        assert "full-ok" in out

    def test_sandbox_invocation_records_stats(self, tmp_path, monkeypatch):
        from dsc.tools import bash as bash_tool
        from dsc.tools.bash import BashArgs, run

        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        token = set_sandbox_mode("workspace-write")
        try:
            run(BashArgs(command="echo hi", timeout_sec=5))
            stats = last_stats_payload()
        finally:
            reset_sandbox_mode(token)

        assert stats is not None
        assert stats["mode"] == "workspace-write"
        assert stats["wrapped"] is True
        assert stats["command_chars"] == len("echo hi")


# ---------------------------------------------------------------------------
# Default-flow regression: tests that don't run on macOS still see the
# legacy un-wrapped behavior. Important so Linux CI stays green and so
# users who haven't enabled the sandbox don't accidentally break their
# bash flow.


class TestNonMacOSFallthrough:
    def test_bash_works_unchanged_when_sandbox_unavailable(
        self, tmp_path, monkeypatch,
    ):
        # Force is_supported() False so the wrap is a no-op.
        from dsc.tools import bash as bash_tool
        from dsc.tools.bash import BashArgs, run

        monkeypatch.setattr(_sandbox, "is_supported", lambda: False)
        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        out = run(BashArgs(command="echo unwrapped", timeout_sec=5))
        assert "unwrapped" in out
        # The stats payload still records the mode that would have been
        # used; ``wrapped`` is False because the wrap was a no-op.
        stats = last_stats_payload()
        assert stats is not None
        assert stats["wrapped"] is False
