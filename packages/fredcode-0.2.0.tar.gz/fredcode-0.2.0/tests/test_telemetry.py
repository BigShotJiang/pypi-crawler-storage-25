"""Telemetry tests: tracer behavior, redact helpers, BatchWriter resilience.

No live DB calls — outage drill uses a connect URL that resolves but refuses.
"""
from __future__ import annotations

import os
import sys
import threading
import time
from datetime import datetime, timezone
from unittest.mock import patch

import pytest

from dsc.client import ToolCall
from dsc.telemetry import NullTracer, PgTracer, make_tracer
from dsc.telemetry.redact import (
    args_fingerprint,
    canonical_json,
    redact_url,
    sha256_text,
    truncate_field,
)


# ---------- redact helpers --------------------------------------------------


def test_canonical_json_sorts_keys():
    assert canonical_json({"b": 2, "a": 1}) == '{"a":1,"b":2}'
    # Same input, different order, same output.
    assert canonical_json({"a": 1, "b": 2}) == canonical_json({"b": 2, "a": 1})


def test_args_fingerprint_stable_across_key_order():
    a = args_fingerprint("bash", {"command": "ls", "cwd": "/tmp"})
    b = args_fingerprint("bash", {"cwd": "/tmp", "command": "ls"})
    assert a == b


def test_args_fingerprint_distinct_for_different_args():
    a = args_fingerprint("bash", {"command": "ls"})
    b = args_fingerprint("bash", {"command": "rm -rf /"})
    c = args_fingerprint("view", {"command": "ls"})  # tool name differs
    assert a != b != c
    assert a != c


def test_truncate_field_under_limit():
    val, trunc, full = truncate_field("hello", 100)
    assert val == "hello"
    assert trunc is False
    assert full == 5


def test_truncate_field_at_limit():
    s = "x" * 100
    val, trunc, full = truncate_field(s, 100)
    assert val == s
    assert trunc is False
    assert full == 100


def test_truncate_field_over_limit():
    s = "x" * 101
    val, trunc, full = truncate_field(s, 100)
    assert len(val.encode("utf-8")) <= 100
    assert trunc is True
    assert full == 101


def test_truncate_field_unicode_safe():
    # 4-byte char that would split mid-byte if naively sliced.
    s = "a" * 99 + "🦀"  # 99 + 4 bytes = 103
    val, trunc, full = truncate_field(s, 100)
    assert trunc is True
    assert full == 103
    # No mojibake — the 4-byte char is dropped, not partially included.
    assert val == "a" * 99


def test_truncate_field_none():
    val, trunc, full = truncate_field(None, 100)
    assert val is None
    assert trunc is False
    assert full == 0


def test_redact_url_strips_password():
    url = "postgresql://user:pw@host.example/db?sslmode=require"
    out = redact_url(url)
    assert "pw" not in out
    assert "***" in out
    assert "host.example" in out
    assert "user" in out


def test_sha256_text_stable():
    assert sha256_text("abc") == sha256_text("abc")
    assert sha256_text("abc") != sha256_text("abd")
    # Standard SHA-256 of "abc"
    assert sha256_text("abc") == (
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    )


# ---------- make_tracer ----------------------------------------------------


def test_make_tracer_no_env_returns_null(monkeypatch):
    monkeypatch.delenv("DSC_TELEMETRY_DB_URL", raising=False)
    t = make_tracer()
    assert isinstance(t, NullTracer)


def test_make_tracer_psycopg_missing_returns_null(monkeypatch, capsys):
    monkeypatch.setenv("DSC_TELEMETRY_DB_URL", "postgresql://nowhere/db")
    # Force the writer import to fail.
    import builtins
    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "dsc.telemetry.writer" or name.startswith("psycopg"):
            raise ImportError("simulated: psycopg not installed")
        return real_import(name, *args, **kwargs)

    with patch.object(builtins, "__import__", side_effect=fake_import):
        t = make_tracer()
    assert isinstance(t, NullTracer)
    err = capsys.readouterr().err
    assert "telemetry disabled" in err


def test_null_tracer_no_op_session_lifecycle():
    t = NullTracer()
    t.start_session(model="m", base_url="x", yolo=False, one_shot=True,
                    system_prompt="hi", registry_names=["bash"],
                    registry_perms={"bash": True})
    turn = t.start_turn(user_input="do something")
    it = t.start_iteration(turn, iteration_index=0,
                           context_used_est=42, budget_status="ok")
    t.end_iteration(it, assistant_text="done", tool_calls=[], finish_reason="stop",
                    usage={"prompt_tokens": 10, "completion_tokens": 2}, api_error=None)
    t.event("foo", payload={"x": 1}, turn=turn)
    t.end_session(reason="natural")
    t.drain(timeout=0.1)


# ---------- FakeWriter for PgTracer envelope inspection -------------------


class FakeWriter:
    def __init__(self) -> None:
        self.envelopes: list[tuple[str, dict]] = []
        self.drained = False

    def submit(self, kind: str, params: dict) -> None:
        self.envelopes.append((kind, params))

    def drain(self, timeout: float = 2.0) -> None:
        self.drained = True

    def by_kind(self, kind: str) -> list[dict]:
        return [p for k, p in self.envelopes if k == kind]


def _make_pg(writer):
    return PgTracer(writer)


def test_pg_tracer_session_start_envelope():
    w = FakeWriter()
    t = _make_pg(w)
    t.start_session(model="deepseek-v4-flash", base_url="https://api.deepseek.com/v1",
                    yolo=True, one_shot=False, system_prompt="SYS", registry_names=["bash", "view"],
                    registry_perms={"bash": True, "view": False})
    starts = w.by_kind("session_start")
    assert len(starts) == 1
    s = starts[0]
    assert s["model"] == "deepseek-v4-flash"
    assert s["yolo_initial"] is True
    assert s["one_shot"] is False
    assert s["system_prompt_text"] == "SYS"
    assert s["system_prompt_sha256"] == sha256_text("SYS")
    assert "tool_catalog" in s
    import json as _json
    catalog = _json.loads(s["tool_catalog"])
    assert {"name": "bash", "requires_permission": True} in catalog


def test_pg_tracer_records_turn_and_tool_call():
    w = FakeWriter()
    t = _make_pg(w)
    t.start_session(model="m", base_url="b", yolo=False, one_shot=True,
                    system_prompt="s", registry_names=["bash"], registry_perms={"bash": True})
    turn = t.start_turn(user_input="please")
    it = t.start_iteration(turn, iteration_index=0,
                           context_used_est=100, budget_status="ok")
    tc = ToolCall(id="call_1", name="bash", arguments={"command": "ls"},
                  raw_arguments='{"command": "ls"}', parse_error=None)
    now = datetime.now(timezone.utc)
    t.record_tool_call(it, call=tc, call_index=0, outcome="ok",
                       permission_outcome="user_y", permission_prompt_ms=42,
                       result="file1\nfile2\n", duration_ms=15,
                       started_at=now, ended_at=now,
                       handler_exception_type=None)
    t.end_iteration(it, assistant_text="here you go", tool_calls=[tc],
                    finish_reason="tool_calls",
                    usage={"prompt_tokens": 100, "completion_tokens": 10,
                           "prompt_tokens_details": {"cached_tokens": 25}},
                    api_error=None)

    turns = w.by_kind("turn")
    calls = w.by_kind("tool_call")
    assert len(turns) == 1
    assert len(calls) == 1
    assert turns[0]["user_input"] == "please"
    assert turns[0]["assistant_text"] == "here you go"
    assert turns[0]["prompt_tokens"] == 100
    assert turns[0]["completion_tokens"] == 10
    assert turns[0]["cached_tokens"] == 25
    assert turns[0]["context_used_est"] == 100
    assert turns[0]["budget_status"] == "ok"
    assert turns[0]["num_tool_calls"] == 1
    assert calls[0]["tool_name"] == "bash"
    assert calls[0]["raw_arguments"] == '{"command": "ls"}'
    assert calls[0]["openai_call_id"] == "call_1"
    assert calls[0]["outcome"] == "ok"
    assert calls[0]["permission_outcome"] == "user_y"
    assert calls[0]["result_text"] == "file1\nfile2\n"
    assert calls[0]["result_full_bytes"] == len("file1\nfile2\n".encode("utf-8"))
    assert calls[0]["result_starts_with_error"] is False


def test_pg_tracer_iteration_index_gates_user_input():
    w = FakeWriter()
    t = _make_pg(w)
    t.start_session(model="m", base_url="b", yolo=False, one_shot=True,
                    system_prompt="s", registry_names=[], registry_perms={})
    turn = t.start_turn(user_input="hi")
    it0 = t.start_iteration(turn, iteration_index=0, context_used_est=0, budget_status="ok")
    it1 = t.start_iteration(turn, iteration_index=1, context_used_est=0, budget_status="ok")
    t.end_iteration(it0, assistant_text="", tool_calls=[], finish_reason="tool_calls",
                    usage=None, api_error=None)
    t.end_iteration(it1, assistant_text="", tool_calls=[], finish_reason="stop",
                    usage=None, api_error=None)
    turns = w.by_kind("turn")
    assert len(turns) == 2
    assert turns[0]["user_input"] == "hi"
    assert turns[1]["user_input"] is None  # only iter 0 carries user_input


def test_pg_tracer_no_text_path(monkeypatch):
    monkeypatch.setenv("DSC_TELEMETRY_NO_TEXT", "1")
    w = FakeWriter()
    t = _make_pg(w)
    t.start_session(model="m", base_url="b", yolo=False, one_shot=True,
                    system_prompt="SECRET PROMPT", registry_names=[], registry_perms={})
    turn = t.start_turn(user_input="my secret")
    it = t.start_iteration(turn, iteration_index=0, context_used_est=0, budget_status="ok")
    tc = ToolCall(id="c1", name="bash", arguments={"command": "secret"},
                  raw_arguments='{"command": "secret"}', parse_error=None)
    now = datetime.now(timezone.utc)
    t.record_tool_call(it, call=tc, call_index=0, outcome="ok",
                       permission_outcome="yolo", permission_prompt_ms=None,
                       result="lots of output bytes", duration_ms=1,
                       started_at=now, ended_at=now, handler_exception_type=None)
    t.end_iteration(it, assistant_text="secret reply", tool_calls=[tc],
                    finish_reason="stop", usage=None, api_error=None)

    s = w.by_kind("session_start")[0]
    turn_row = w.by_kind("turn")[0]
    call_row = w.by_kind("tool_call")[0]
    # Texts are stripped...
    assert s["system_prompt_text"] is None
    assert s["system_prompt_sha256"]  # but the hash remains
    assert turn_row["user_input"] is None
    assert turn_row["assistant_text"] is None
    assert call_row["args"] is None
    assert call_row["raw_arguments"] is None
    assert call_row["result_text"] is None
    # ...metadata is not.
    assert turn_row["finish_reason"] == "stop"
    assert call_row["outcome"] == "ok"
    assert call_row["permission_outcome"] == "yolo"
    assert call_row["args_fingerprint"]
    # Full byte length still tracked even when text is dropped.
    assert call_row["result_full_bytes"] == len("lots of output bytes".encode("utf-8"))


def test_pg_tracer_api_error_captured():
    w = FakeWriter()
    t = _make_pg(w)
    t.start_session(model="m", base_url="b", yolo=False, one_shot=True,
                    system_prompt="s", registry_names=[], registry_perms={})
    turn = t.start_turn(user_input="x")
    it = t.start_iteration(turn, iteration_index=0, context_used_est=0, budget_status="ok")
    err = RuntimeError("boom")
    t.end_iteration(it, assistant_text="", tool_calls=[], finish_reason=None,
                    usage=None, api_error=err)
    row = w.by_kind("turn")[0]
    assert row["api_error_type"] == "RuntimeError"
    assert row["api_error_message"] == "boom"


def test_pg_tracer_event_envelope():
    w = FakeWriter()
    t = _make_pg(w)
    t.start_session(model="m", base_url="b", yolo=False, one_shot=True,
                    system_prompt="s", registry_names=[], registry_perms={})
    t.event("slash_command", payload={"cmd": "/yolo", "yolo": True})
    ev = w.by_kind("event")
    assert len(ev) == 1
    assert ev[0]["kind"] == "slash_command"
    import json as _json
    assert _json.loads(ev[0]["payload"]) == {"cmd": "/yolo", "yolo": True}


# ---------- BatchWriter outage drill ---------------------------------------


def test_batch_writer_survives_unreachable_db():
    """Push events at a connect URL that resolves but refuses.

    The writer thread must absorb the connection failures, the producer
    must never block, and drain must return within a small timeout.
    """
    from dsc.telemetry.writer import BatchWriter

    # 127.0.0.1:1 — port 1 is reserved/refused on macOS by default.
    bad_url = "postgresql://x:y@127.0.0.1:1/db?connect_timeout=1"
    w = BatchWriter(bad_url, queue_size=128, batch_max=10, flush_interval_s=0.05)
    w.start()
    try:
        for i in range(50):
            w.submit("event", {
                "session_id": "00000000-0000-0000-0000-000000000001",
                "turn_id": None,
                "ts": datetime.now(timezone.utc),
                "kind": "test",
                "payload": None,
            })
        # Give the writer a brief moment to fail at least once.
        time.sleep(0.2)
        # Drain returns within timeout even when the DB is unreachable.
        t0 = time.monotonic()
        w.drain(timeout=0.5)
        elapsed = time.monotonic() - t0
        assert elapsed < 1.5, f"drain blocked too long: {elapsed:.2f}s"
    finally:
        # Ensure thread exits even on assertion failure.
        if w._thread.is_alive():
            w._stopped.set()


def test_batch_writer_drop_counter_bounded_queue():
    """When the queue overflows, dropped_events must increment monotonically."""
    from dsc.telemetry.writer import BatchWriter

    bad_url = "postgresql://x:y@127.0.0.1:1/db?connect_timeout=1"
    w = BatchWriter(bad_url, queue_size=8, batch_max=4, flush_interval_s=10.0)
    # Don't start the thread — we want the queue to fill up without drainage.
    for _ in range(200):
        w.submit("event", {
            "session_id": "00000000-0000-0000-0000-000000000002",
            "turn_id": None,
            "ts": datetime.now(timezone.utc),
            "kind": "test",
            "payload": None,
        })
    assert w.dropped_events > 100
    # Producer never raised, never blocked.
