# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class App:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'app_name': 'str',
        'app_id': 'str',
        'state': 'AppState',
        'scope': 'str',
        'tenant_name': 'str',
        'domain': 'str',
        'create_time': 'str',
        'authentication': 'AppAuth',
        'callbacks': 'AppCallbacks',
        'auto_record_mode': 'AppAutoRecordMode'
    }

    attribute_map = {
        'app_name': 'app_name',
        'app_id': 'app_id',
        'state': 'state',
        'scope': 'scope',
        'tenant_name': 'tenant_name',
        'domain': 'domain',
        'create_time': 'create_time',
        'authentication': 'authentication',
        'callbacks': 'callbacks',
        'auto_record_mode': 'auto_record_mode'
    }

    def __init__(self, app_name=None, app_id=None, state=None, scope=None, tenant_name=None, domain=None, create_time=None, authentication=None, callbacks=None, auto_record_mode=None):
        r"""App

        The model defined in huaweicloud sdk

        :param app_name: app名称
        :type app_name: str
        :param app_id: 应用id
        :type app_id: str
        :param state: 
        :type state: :class:`huaweicloudsdkcloudrtc.v2.AppState`
        :param scope: RTC覆盖范围。  取值如下：    - DOMESTIC：国内范围。   - OVERSEA：海外范围。   - GLOBAL：全球范围。 
        :type scope: str
        :param tenant_name: 账号名
        :type tenant_name: str
        :param domain: 域名，App对应域名
        :type domain: str
        :param create_time: 创建时间，形如“2006-01-02T15:04:05.075Z”，时区为：UTC
        :type create_time: str
        :param authentication: 
        :type authentication: :class:`huaweicloudsdkcloudrtc.v2.AppAuth`
        :param callbacks: 
        :type callbacks: :class:`huaweicloudsdkcloudrtc.v2.AppCallbacks`
        :param auto_record_mode: 
        :type auto_record_mode: :class:`huaweicloudsdkcloudrtc.v2.AppAutoRecordMode`
        """
        
        

        self._app_name = None
        self._app_id = None
        self._state = None
        self._scope = None
        self._tenant_name = None
        self._domain = None
        self._create_time = None
        self._authentication = None
        self._callbacks = None
        self._auto_record_mode = None
        self.discriminator = None

        if app_name is not None:
            self.app_name = app_name
        if app_id is not None:
            self.app_id = app_id
        if state is not None:
            self.state = state
        if scope is not None:
            self.scope = scope
        if tenant_name is not None:
            self.tenant_name = tenant_name
        if domain is not None:
            self.domain = domain
        if create_time is not None:
            self.create_time = create_time
        if authentication is not None:
            self.authentication = authentication
        if callbacks is not None:
            self.callbacks = callbacks
        if auto_record_mode is not None:
            self.auto_record_mode = auto_record_mode

    @property
    def app_name(self):
        r"""Gets the app_name of this App.

        app名称

        :return: The app_name of this App.
        :rtype: str
        """
        return self._app_name

    @app_name.setter
    def app_name(self, app_name):
        r"""Sets the app_name of this App.

        app名称

        :param app_name: The app_name of this App.
        :type app_name: str
        """
        self._app_name = app_name

    @property
    def app_id(self):
        r"""Gets the app_id of this App.

        应用id

        :return: The app_id of this App.
        :rtype: str
        """
        return self._app_id

    @app_id.setter
    def app_id(self, app_id):
        r"""Sets the app_id of this App.

        应用id

        :param app_id: The app_id of this App.
        :type app_id: str
        """
        self._app_id = app_id

    @property
    def state(self):
        r"""Gets the state of this App.

        :return: The state of this App.
        :rtype: :class:`huaweicloudsdkcloudrtc.v2.AppState`
        """
        return self._state

    @state.setter
    def state(self, state):
        r"""Sets the state of this App.

        :param state: The state of this App.
        :type state: :class:`huaweicloudsdkcloudrtc.v2.AppState`
        """
        self._state = state

    @property
    def scope(self):
        r"""Gets the scope of this App.

        RTC覆盖范围。  取值如下：    - DOMESTIC：国内范围。   - OVERSEA：海外范围。   - GLOBAL：全球范围。 

        :return: The scope of this App.
        :rtype: str
        """
        return self._scope

    @scope.setter
    def scope(self, scope):
        r"""Sets the scope of this App.

        RTC覆盖范围。  取值如下：    - DOMESTIC：国内范围。   - OVERSEA：海外范围。   - GLOBAL：全球范围。 

        :param scope: The scope of this App.
        :type scope: str
        """
        self._scope = scope

    @property
    def tenant_name(self):
        r"""Gets the tenant_name of this App.

        账号名

        :return: The tenant_name of this App.
        :rtype: str
        """
        return self._tenant_name

    @tenant_name.setter
    def tenant_name(self, tenant_name):
        r"""Sets the tenant_name of this App.

        账号名

        :param tenant_name: The tenant_name of this App.
        :type tenant_name: str
        """
        self._tenant_name = tenant_name

    @property
    def domain(self):
        r"""Gets the domain of this App.

        域名，App对应域名

        :return: The domain of this App.
        :rtype: str
        """
        return self._domain

    @domain.setter
    def domain(self, domain):
        r"""Sets the domain of this App.

        域名，App对应域名

        :param domain: The domain of this App.
        :type domain: str
        """
        self._domain = domain

    @property
    def create_time(self):
        r"""Gets the create_time of this App.

        创建时间，形如“2006-01-02T15:04:05.075Z”，时区为：UTC

        :return: The create_time of this App.
        :rtype: str
        """
        return self._create_time

    @create_time.setter
    def create_time(self, create_time):
        r"""Sets the create_time of this App.

        创建时间，形如“2006-01-02T15:04:05.075Z”，时区为：UTC

        :param create_time: The create_time of this App.
        :type create_time: str
        """
        self._create_time = create_time

    @property
    def authentication(self):
        r"""Gets the authentication of this App.

        :return: The authentication of this App.
        :rtype: :class:`huaweicloudsdkcloudrtc.v2.AppAuth`
        """
        return self._authentication

    @authentication.setter
    def authentication(self, authentication):
        r"""Sets the authentication of this App.

        :param authentication: The authentication of this App.
        :type authentication: :class:`huaweicloudsdkcloudrtc.v2.AppAuth`
        """
        self._authentication = authentication

    @property
    def callbacks(self):
        r"""Gets the callbacks of this App.

        :return: The callbacks of this App.
        :rtype: :class:`huaweicloudsdkcloudrtc.v2.AppCallbacks`
        """
        return self._callbacks

    @callbacks.setter
    def callbacks(self, callbacks):
        r"""Sets the callbacks of this App.

        :param callbacks: The callbacks of this App.
        :type callbacks: :class:`huaweicloudsdkcloudrtc.v2.AppCallbacks`
        """
        self._callbacks = callbacks

    @property
    def auto_record_mode(self):
        r"""Gets the auto_record_mode of this App.

        :return: The auto_record_mode of this App.
        :rtype: :class:`huaweicloudsdkcloudrtc.v2.AppAutoRecordMode`
        """
        return self._auto_record_mode

    @auto_record_mode.setter
    def auto_record_mode(self, auto_record_mode):
        r"""Sets the auto_record_mode of this App.

        :param auto_record_mode: The auto_record_mode of this App.
        :type auto_record_mode: :class:`huaweicloudsdkcloudrtc.v2.AppAutoRecordMode`
        """
        self._auto_record_mode = auto_record_mode

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, App):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
