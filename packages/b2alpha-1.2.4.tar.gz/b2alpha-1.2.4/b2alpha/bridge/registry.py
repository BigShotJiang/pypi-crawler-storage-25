"""Adapter registry for intent resolution."""

from __future__ import annotations

from .adapter import RESTIntentAdapter, list_supported_intents


class AdapterRegistry:
    """Holds available adapters and resolves intents to one adapter."""

    def __init__(self) -> None:
        self._adapters: list[RESTIntentAdapter] = []

    def register(self, adapter: RESTIntentAdapter) -> None:
        self._adapters.append(adapter)

    def resolve(self, intent: str) -> RESTIntentAdapter:
        for adapter in self._adapters:
            if adapter.can_handle(intent):
                return adapter
        raise KeyError(f"no adapter registered for intent '{intent}'")

    def supported_intents(self) -> list[str]:
        return list_supported_intents(self._adapters)

