"""Core bridge datatypes."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True)
class B2AIntent:
    """Incoming B2A intent payload from a company-agent proxy."""

    intent: str
    params: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AdapterCall:
    """HTTP call produced by an adapter from a B2A intent."""

    method: str
    path: str
    query: Mapping[str, str] = field(default_factory=dict)
    headers: Mapping[str, str] = field(default_factory=dict)
    json_body: Any | None = None
    timeout_s: float = 15.0


@dataclass(frozen=True)
class AdapterResult:
    """Normalized result returned back to the company-agent proxy."""

    status_code: int
    ok: bool
    data: Any
    adapter: str

