exceptions
==========

.. automodule:: spicerack.exceptions
