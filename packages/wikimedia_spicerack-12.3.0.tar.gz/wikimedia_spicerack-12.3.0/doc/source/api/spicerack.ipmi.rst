ipmi
====

.. automodule:: spicerack.ipmi
