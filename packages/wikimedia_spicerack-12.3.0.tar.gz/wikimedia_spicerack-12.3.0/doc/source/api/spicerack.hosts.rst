hosts
=====

.. automodule:: spicerack.hosts
