cookbook
========

.. automodule:: spicerack.cookbook
