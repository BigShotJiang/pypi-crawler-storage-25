mediawiki
=========

.. automodule:: spicerack.mediawiki
