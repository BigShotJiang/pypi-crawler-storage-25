alerting
========

.. automodule:: spicerack.alerting
