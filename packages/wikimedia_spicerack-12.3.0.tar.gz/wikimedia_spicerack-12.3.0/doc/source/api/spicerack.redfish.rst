redfish
=======

.. automodule:: spicerack.redfish
