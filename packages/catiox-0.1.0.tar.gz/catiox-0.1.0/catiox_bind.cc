#include <cstddef>
#include <pybind11/pybind11.h>
#include <pybind11/functional.h>
#include <pybind11/stl.h>
#include "include/catiox_read.hpp"
#include "include/catiox_util.hpp"
#include "include/catiox_write.hpp"
#include "include/catiox_init.hpp"

namespace py = pybind11;
PYBIND11_MODULE(catiox, m) {
    m.doc() = "CatioX - Python binding for Catio";
    py::enum_<read_type>(m, "read_type")
        .value("catiox_read_full", read_type::catiox_read_full)
        .value("catiox_read_kv", read_type::catiox_read_kv)
        .export_values();
    py::enum_<write_type>(m, "write_type")
        .value("catiox_write_full", write_type::catiox_write_full)
        .value("catiox_write_append", write_type::catiox_write_append)
        .export_values();
    py::enum_<sleep_type>(m , "sleep_type")
        .value("catiox_sleep_ms" , sleep_type::catiox_sleep_ms)
        .value("catiox_sleep_sec", sleep_type::catiox_sleep_sec)
        .export_values();
    py::class_<catiox_async_read>(m, "catiox_async_read")
        .def(py::init<>())
        .def("async_readfile", &catiox_async_read::async_readfile,
             py::arg("file_path"), py::arg("file_name"),
             py::arg("read_tp"), py::arg("on_io_failed"), py::arg("on_io_success"));
    py::class_<catiox_async_write>(m, "catiox_async_write")
        .def(py::init<const std::string&>())
        .def("async_writefile", &catiox_async_write::async_writefile,
             py::arg("file_path"), py::arg("file_name"),
             py::arg("write_tp"), py::arg("on_io_failed"), 
             py::arg("on_io_success"));
    py::class_<catiox_init>(m , "catiox_init")
      .def(py::init<size_t>());
    py::class_<catiox_util>(m , "catiox_util")
        .def(py::init<>()) 
        .def("io_sleep" , &catiox_util::io_sleep , 
            py::arg("sleep_t") ,py::arg("sleep_time"));
}
