from setuptools import setup
import os

here = os.path.abspath(os.path.dirname(__file__))

setup(
    name="catiox",
    version="0.1.0",
    author="Kloveme",
    description="CatioX - Async I/O for Python, powered by C++",
    long_description=open(os.path.join(here, "README.md")).read(),
    long_description_content_type="text/markdown",
    url="https://github.com/kloveme/catiox",
    license="MIT",

    packages=["catiox"],
    package_dir={"catiox": "catiox"},
    
    package_data={
        "catiox": ["_core.so", "_core.pyi"],
    },
    include_package_data=True,
    
    install_requires=['pybind11'], 
    python_requires='>=3.8',
    
    classifiers=[
        "Programming Language :: C++",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
    ],
)