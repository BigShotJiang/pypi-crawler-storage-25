# catiox

> Python binding for **Catio** - Async I/O library powered by C++

[![GitHub](https://img.shields.io/badge/GitHub-kloveme/catiox-black?logo=github)](https://github.com/kloveme/catiox)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://python.org)
[![C++](https://img.shields.io/badge/C%2B%2B-17-blue.svg)](https://isocpp.org/)

## Installation

```bash
pip install catiox
```

## Qucik example

```python
import catiox

catiox.catiox_init(5)

def on_success(data):
    print(data)

reader = catiox.catiox_async_read()
reader.async_readfile("./", "config.conf",
    catiox.read_type.catiox_read_kv,
    on_io_failed=print,
    on_io_success=on_success
)

import time
time.sleep(0.5)

```
## Teachincal details

#### CatioX is powered by Catio, a high-performance C++ library featuring:

Async I/O - Non-blocking file operations

Thread Pool - Efficient task scheduling

Event Loop - Based on poll() system call
High Performance - Direct file I/O with minimal overhead

KV Parser - Built-in key-value config parsing

Thread-safe - Mutex-protected shared data

## Architecture

```text
Python Code → pybind11 → C++ catio → Thread Pool → File I/O → Callback → Python
```
#### C++ 20 standard

#### RAII resource management

#### Smart pointers for memory safety

#### Move semantics for zero-copy operations

# Documentation

## For detailed documentation, examples, and source code:
## > https://github.com/kloveme/catiox

License

MIT © 2026 Kloveme

