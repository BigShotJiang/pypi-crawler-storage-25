"""Build AI auth commands for API credentials and local developer auth state."""

from __future__ import annotations

import sys
from typing import Any

import typer
from rich.table import Table

from cli.auth_local import (
    DEFAULT_ENVIRONMENT,
    AuthReport,
    bootstrap_commands,
    build_auth_report,
    report_as_jsonable,
    resolve_sanctioned_profile,
    sanctioned_auth_profiles,
)
from cli.config import clear_credential, resolve_api_url, save_cli_config
from cli.console import data_console, error, info, status_console, success
from cli.internal_api import get_internal_api_client
from cli.output import Format, auto_format, format_option, render

app = typer.Typer(
    no_args_is_help=True,
    help="Inspect Build AI API auth, local Google auth, and sanctioned local-dev profiles.",
)


def _api_base_url() -> str:
    """Resolve the public API base URL once per command invocation."""

    return resolve_api_url()


def _store_token(token: str, *, profile: str | None = None) -> None:
    """Persist a public API token in the normal CLI credentials location."""

    save_cli_config(profile=profile, api_key=token)
    success("Saved CLI credentials to ~/.buildai/credentials.json")


def _prompt_for_token() -> str:
    """Prompt for an existing API key instead of pretending a browser flow exists."""

    info("Build AI CLI login stores an existing API key.")
    status_console.print("[dim]Get one from data.build.ai -> Developer -> Create API key.[/dim]")
    value = typer.prompt("Paste Build AI API key", hide_input=True).strip()
    if not value:
        error("Expected a non-empty API key.")
        raise typer.Exit(1)
    return value


def _profile_rows() -> list[dict[str, Any]]:
    """Flatten the sanctioned profile registry into one table-friendly shape."""

    rows: list[dict[str, Any]] = []
    for profile in sanctioned_auth_profiles():
        target = "requires --service <slug>" if profile.requires_service else "fixed target"
        rows.append(
            {
                "profile": profile.name,
                "audience": profile.audience,
                "target": target,
                "db_access": profile.db_access,
                "break_glass": profile.break_glass,
                "summary": profile.summary,
            }
        )
    return rows


def _render_profile_table() -> None:
    """Render sanctioned local auth profiles in a scan-friendly human table."""

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Profile")
    table.add_column("Audience")
    table.add_column("Target")
    table.add_column("DB")
    table.add_column("Break Glass")
    table.add_column("Summary")
    for row in _profile_rows():
        table.add_row(
            str(row["profile"]),
            str(row["audience"]),
            str(row["target"]),
            "yes" if row["db_access"] else "no",
            "yes" if row["break_glass"] else "no",
            str(row["summary"]),
        )
    data_console.print(table)


def _render_state_tables(report: AuthReport) -> None:
    """Show the combined API and local auth state without hiding drift."""

    api_table = Table(show_header=True, header_style="bold cyan", title="API Auth")
    api_table.add_column("Field")
    api_table.add_column("Value")
    api_table.add_row("status", report.state.api_status)
    api_table.add_row("display_name", report.state.api_display_name or "")
    api_table.add_row("subject", report.state.api_subject or "")
    api_table.add_row("error", report.state.api_error or "")

    local_table = Table(show_header=True, header_style="bold cyan", title="Local Auth")
    local_table.add_column("Field")
    local_table.add_column("Value")
    local_table.add_row("gcloud_account", report.state.gcloud_account or "")
    local_table.add_row("gcloud_project", report.state.gcloud_project or "")
    local_table.add_row(
        "gcloud_impersonation",
        report.state.gcloud_impersonate_service_account or "",
    )
    local_table.add_row("adc_path", report.state.adc_path)
    local_table.add_row("adc_type", report.state.adc_type or "")
    local_table.add_row(
        "adc_identity", report.state.adc_email or report.state.adc_target_principal or ""
    )
    local_table.add_row(
        "adc_token",
        "ok" if report.state.adc_access_token_ok else (report.state.adc_access_token_error or ""),
    )

    data_console.print(api_table)
    data_console.print(local_table)

    if report.profile is not None:
        profile_table = Table(
            show_header=True,
            header_style="bold cyan",
            title="Resolved Profile",
        )
        profile_table.add_column("Field")
        profile_table.add_column("Value")
        profile_table.add_row("name", report.profile.name)
        profile_table.add_row("audience", report.profile.audience)
        profile_table.add_row("environment", report.profile.environment)
        profile_table.add_row("service", report.profile.service_slug or "")
        profile_table.add_row("target_service_account", report.profile.target_service_account or "")
        profile_table.add_row("target_db_user", report.profile.target_db_user or "")
        data_console.print(profile_table)


def _render_check_table(report: AuthReport) -> None:
    """Render doctor/check results in a compact table with concrete fixes."""

    table = Table(show_header=True, header_style="bold cyan", title="Auth Checks")
    table.add_column("Status")
    table.add_column("Check")
    table.add_column("Summary")
    table.add_column("Fix")
    for check in report.checks:
        if check.ok:
            status = "ok"
        elif check.level == "warning":
            status = "warn"
        else:
            status = "fail"
        table.add_row(status, check.code, check.summary, check.fix or "")
    data_console.print(table)

    status_console.print("[dim]Next steps[/dim]")
    for step in report.next_steps:
        status_console.print(f"[dim]  {step}[/dim]")


def _emit_report(
    report: AuthReport, *, format: Format | None = None, include_state: bool = False
) -> None:
    """Render one auth report as either structured data or human-oriented tables."""

    fmt = format or auto_format()
    if fmt != Format.TABLE:
        render(report_as_jsonable(report), format=fmt)
        return
    if include_state:
        _render_state_tables(report)
    _render_check_table(report)


@app.command("login")
def login(
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        help="Store this API key directly instead of prompting.",
        hidden=True,
    ),
    token: bool = typer.Option(
        False,
        "--token",
        help="Read an API key from stdin instead of prompting.",
    ),
    profile: str | None = typer.Option(None, "--profile", hidden=True),
) -> None:
    """Store an existing Build AI API key for API-backed CLI commands."""

    if api_key and token:
        error("Choose either --api-key or --token, not both.")
        raise typer.Exit(1)

    if api_key:
        _store_token(api_key.strip(), profile=profile)
        return

    if token:
        value = sys.stdin.read().strip()
        if not value:
            error("Expected an API key on stdin.")
            raise typer.Exit(1)
        _store_token(value, profile=profile)
        return

    _store_token(_prompt_for_token(), profile=profile)


@app.command("whoami")
def whoami(
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="Optional local auth profile to resolve alongside current machine state.",
    ),
    service: str | None = typer.Option(
        None,
        "--service",
        help="Service slug for profiles that emulate one runtime surface.",
    ),
    env: str = typer.Option(
        DEFAULT_ENVIRONMENT,
        "--env",
        help="Behavioral environment to resolve profile-specific targets against.",
    ),
    format: Format = format_option(),
) -> None:
    """Show public API auth and local Google auth in one place."""

    report = build_auth_report(profile_name=profile, service=service, environment=env)
    _emit_report(report, format=format, include_state=True)
    if report.exit_code:
        raise typer.Exit(report.exit_code)


@app.command("profiles")
def profiles(
    format: Format = format_option(),
) -> None:
    """List the sanctioned local auth profiles and what each one is for."""

    if format != Format.TABLE:
        render(_profile_rows(), format=format)
        return
    _render_profile_table()


@app.command("check")
def check(
    profile: str = typer.Option(..., "--profile", help="Sanctioned local auth profile."),
    service: str | None = typer.Option(
        None,
        "--service",
        help="Service slug for profiles that emulate one runtime surface.",
    ),
    env: str = typer.Option(
        DEFAULT_ENVIRONMENT,
        "--env",
        help="Behavioral environment to validate against.",
    ),
    format: Format = format_option(),
) -> None:
    """Validate one named local auth workflow end to end."""

    report = build_auth_report(profile_name=profile, service=service, environment=env)
    _emit_report(report, format=format, include_state=False)
    if report.exit_code:
        raise typer.Exit(report.exit_code)


@app.command("bootstrap")
def bootstrap(
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="Optional sanctioned profile to tailor the bootstrap output.",
    ),
    service: str | None = typer.Option(
        None,
        "--service",
        help="Service slug for runtime-like profiles.",
    ),
    env: str = typer.Option(
        DEFAULT_ENVIRONMENT,
        "--env",
        help="Behavioral environment to show bootstrap wiring for.",
    ),
    format: Format = format_option(),
) -> None:
    """Print the explicit bootstrap path instead of relying on ambient magic."""

    resolved_profile = None
    if profile is not None:
        try:
            resolved_profile = resolve_sanctioned_profile(
                profile,
                service=service,
                environment=env,
            )
        except Exception as exc:
            error(str(exc))
            raise typer.Exit(1) from exc

    payload = {
        "profile": (
            {
                "name": resolved_profile.name,
                "service_slug": resolved_profile.service_slug,
                "environment": resolved_profile.environment,
                "target_service_account": resolved_profile.target_service_account,
                "target_db_user": resolved_profile.target_db_user,
                "bootstrap_exports": resolved_profile.bootstrap_exports(),
            }
            if resolved_profile is not None
            else None
        ),
        "steps": list(bootstrap_commands(profile=resolved_profile)),
    }

    if format != Format.TABLE:
        render(payload, format=format)
        return

    status_console.print("[bold]Bootstrap path[/bold]")
    for index, step in enumerate(payload["steps"], start=1):
        status_console.print(f"  {index}. {step}")

    if resolved_profile is not None and resolved_profile.bootstrap_exports():
        status_console.print("")
        status_console.print("[bold]Profile env wiring[/bold]")
        for line in resolved_profile.bootstrap_exports():
            status_console.print(f"  {line}")


@app.command("logout")
def logout() -> None:
    """Remove the stored public API credential without touching local Google auth."""

    clear_credential()
    success("Removed ~/.buildai/credentials.json")


def public_api_whoami() -> None:
    """Retain the old API-only `whoami` path for callers that still want it."""

    client = get_internal_api_client()
    try:
        access = client.access.inspect()
    finally:
        client.close()

    render(
        {
            "principal_display_name": access.principal_display_name,
            "principal_subject": access.principal_subject,
            "principal_type": access.principal_type,
            "audience": access.audience,
            "mode": access.mode,
            "permissions": access.permissions,
            "boundary": access.boundary,
        },
        format=auto_format(),
        columns=[
            "principal_display_name",
            "principal_subject",
            "principal_type",
            "audience",
            "mode",
            "permissions",
            "boundary",
        ],
    )
