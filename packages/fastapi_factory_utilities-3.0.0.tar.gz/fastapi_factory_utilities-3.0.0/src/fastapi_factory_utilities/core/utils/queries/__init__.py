"""Provides utilities for queries.

Examples:
- Filtering:
    - GET /api/v1/resources?field1=value1
    - GET /api/v1/resources?object1.field1=value1
      (dotted keys: use a nested ``BaseModel`` field on your :class:`QueryAbstract`, or a leaf
      ``Field(validation_alias=...)``, or :meth:`QueryResolver.add_authorized_field`.)
    - GET /api/v1/resources?field1[gt]=value1
    - GET /api/v1/resources?field1[lt]=value1
    - GET /api/v1/resources?field1[gte]=value1
    - GET /api/v1/resources?field1[lte]=value1
    - GET /api/v1/resources?field1[eq]=value1
    - GET /api/v1/resources?field1[neq]=value1
    - GET /api/v1/resources?field1[in]=value1&field1[in]=value2&field1[in]=value3
    - GET /api/v1/resources?field1[nin]=value1&field1[nin]=value2&field1[nin]=value3
    - GET /api/v1/resources?field1[contains]=value1
    - GET /api/v1/resources?field1[not_contains]=value1
    - GET /api/v1/resources?field1[starts_with]=value1
    - GET /api/v1/resources?field1[ends_with]=value1
- Sorting (ascending order if no prefix is provided):
    - GET /api/v1/users?sort=name
    - GET /api/v1/users?sort=-name&sort=+age

Dynamic filter models from entities: mark fields with ``Annotated[..., SearchableField]`` on a
:class:`SearchableEntity` subclass, then subclass the model returned by
:meth:`SearchableEntity.build_query_filter_model`.
"""

from .abstracts import QueryAbstract, QueryFilterNestedAbstract
from .entities import SearchableEntity, SearchableField, SearchableMarker
from .enums import QueryFieldOperatorEnum, QuerySortDirectionEnum
from .resolvers import QueryResolver
from .types import QueryField, QueryFieldName, QueryFieldOperation, QuerySort, RawQueryFieldName, RawQuerySort

# Backward-compatible alias: dynamic filter models from :meth:`SearchableEntity.build_query_filter_model`
# subclass :class:`QueryAbstract`.
QueryFilterAbstract = QueryAbstract

__all__: list[str] = [
    "QueryAbstract",
    "QueryField",
    "QueryFieldName",
    "QueryFieldOperation",
    "QueryFieldOperatorEnum",
    "QueryFilterAbstract",
    "QueryFilterNestedAbstract",
    "QueryResolver",
    "QuerySort",
    "QuerySortDirectionEnum",
    "RawQueryFieldName",
    "RawQuerySort",
    "SearchableEntity",
    "SearchableField",
    "SearchableMarker",
]
