import copy
import json
import secrets
from io import BytesIO
from pathlib import Path

import keyring
import openpyxl
import requests
import typer
from markdown_it import MarkdownIt
from mutagen.mp3 import MP3
from rich.console import Console
from rich.table import Table

from html_to_markdown import convert
from save_as_xlsx import SaveAsXlsx, ColumnWidth

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0"
REFERRER = "https://app.storylane.io/"

SERVICE = "slcli"
USERNAME = "api-key"


def _get_key(override: str | None) -> str:
    if override:
        return override
    key = keyring.get_password(SERVICE, USERNAME)
    if not key:
        key = typer.prompt("No cached key. Run `slcli login` first, or paste a Storylane API key", hide_input=True)
        keyring.set_password(SERVICE, USERNAME, key)
    return key


class StorylaneSession(requests.Session):
    def __init__(self, key: str | None = None, output_dir: Path | None = None) -> None:
        super().__init__()
        self.output_dir = output_dir
        self.headers.update({
            "User-Agent": USER_AGENT,
            "Referer": REFERRER,
            "Origin": REFERRER,
            "X-Storylane-Platform": "dashboard",
        })
        if key:
            self.headers["Authorization"] = f"Bearer {key}"

    def _check_auth(self, result: requests.Response) -> None:
        try:
            result.raise_for_status()
        except requests.HTTPError:
            if result.status_code == 401:
                typer.echo(
                    "Authentication failed. The cached API key may be stale — run `slcli logout` and try again.",
                    err=True,
                )
                raise typer.Exit(code=1)
            raise

    def _request_json(self, method: str, path: str, *, params=None, json_body=None, save: str | None = None) -> dict:
        path = path.removeprefix("/")
        result = self.request(method, "https://api.storylane.io/" + path, params=params, json=json_body)
        self._check_auth(result)
        data = result.json()
        if save and self.output_dir is not None:
            (self.output_dir / f"{save}.json").write_text(json.dumps(data, indent=2))
        return data

    def get_json(self, path: str, params=None, save: str | None = None) -> dict:
        return self._request_json("GET", path, params=params, save=save)

    def post_json(self, path: str, body=None, params=None, save: str | None = None) -> dict:
        return self._request_json("POST", path, params=params, json_body=body, save=save)

    def patch_json(self, path: str, body, save: str | None = None) -> dict:
        return self._request_json("PATCH", path, json_body=body, save=save)

    def post_raw(self, path: str, body=None) -> requests.Response:
        path = path.removeprefix("/")
        result = self.post("https://api.storylane.io/" + path, json=body)
        self._check_auth(result)
        return result


app = typer.Typer(no_args_is_help=True)


@app.command()
def export(
    project_id: str = typer.Argument(..., help="Storylane project UUID"),
    output_dir: Path = typer.Option(Path("output"), "--output", "-o", help="Directory for JSON dumps"),
    xlsx: Path | None = typer.Option(None, "--xlsx", "-x", help="Path to the output Excel file (default: <output-dir>/texts.xlsx)"),
    key: str | None = typer.Option(None, "--key", help="Override the cached API key (does not write to keyring)"),
):
    """Export the text content of a Storylane demo to an Excel file."""
    output_dir.mkdir(parents=True, exist_ok=True)
    xlsx_path = xlsx if xlsx is not None else output_dir / "texts.xlsx"

    s = StorylaneSession(_get_key(key), output_dir)
    project = s.get_json("/api/v1/company/projects/" + project_id, save="project")
    pages = s.get_json("/api/v1/company/pages", params={"project_id": project_id}, save="pages")
    s.get_json(f"/api/v1/company/projects/{project_id}/links", save="links")
    s.get_json(f"/api/v1/company/projects/{project_id}/flowlists", save="flowlists")
    s.get_json(f"/api/v1/company/themes", save="themes")

    texts = []
    for flow in project["project"]["flows"]:
        for widget in flow["widgets"]:
            texts.append({
                "project_id": project_id,
                "flow_name": flow["name"],
                "flow_id": flow["id"],
                "widget_id": widget["id"],
                "cta": widget["cta"],
                "url": next((page["url"] for page in pages["pages"] if page["id"] == widget["page_id"]), None),
                "html_text": widget["options"].get("description", {}).get("value"),
                "text": convert(widget["options"].get("description", {}).get("value") or "").strip(),
            })
    with SaveAsXlsx(xlsx_path, texts, column_order=list(texts[0].keys()) + ["new text", "new voiceover"], column_width={
        "flow_name": ColumnWidth.AUTOFIT,
        "project_id": ColumnWidth.HIDE,
        "flow_id": ColumnWidth.HIDE,
        "widget_id": ColumnWidth.HIDE,
        "cta": ColumnWidth.AUTOFIT,
        "url": -10,
    }) as saver:
        # https://xlsxwriter.readthedocs.io/worksheet.html#worksheet-protect
        saver.worksheet.protect("", {
            "format_columns": True,
            "format_rows": True,
            "format_cells": True,
            "sort": True,
            "autofilter": True,
            "delete_columns": True,
            "delete_rows": True,
            "insert_columns": True,
            "insert_rows": True,
        })
        saver.worksheet.unprotect_range(saver.column_ref("new text"))
        saver.worksheet.unprotect_range(saver.column_ref("new voiceover"))


def _read_xlsx_changes(xlsx_path: Path) -> list[dict]:
    wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    headers = next(rows)
    changes = []
    for row in rows:
        row_dict = dict(zip(headers, row))
        new_text = (row_dict.get("new text") or "").strip()
        new_voiceover = (row_dict.get("new voiceover") or "").strip()
        if new_text or new_voiceover:
            changes.append({
                "project_id": row_dict["project_id"],
                "flow_id": row_dict["flow_id"],
                "widget_id": row_dict["widget_id"],
                "new_text": new_text or None,
                "new_voiceover": new_voiceover or None,
            })
    wb.close()
    return changes


def _markdown_to_html(md: str) -> str:
    return MarkdownIt().render(md).strip()


def _generate_tts(session: StorylaneSession, prompt: str, voice_id: str, output_dir: Path | None, widget_id: str) -> bytes:
    response = session.post_raw("/api/v1/ai/transcriptions", body={"prompt": prompt, "voice_id": voice_id})
    content_type = response.headers.get("Content-Type", "")
    if "application/json" in content_type:
        data = response.json()
        url = data.get("url") or data.get("audio_url")
        if not url:
            raise RuntimeError(f"Unexpected TTS JSON response: {data}")
        mp3_response = requests.get(url)
        mp3_response.raise_for_status()
        mp3 = mp3_response.content
    else:
        mp3 = response.content
    if output_dir is not None:
        (output_dir / f"tts_{widget_id}.mp3").write_bytes(mp3)
    return mp3


def _upload_audio(session: StorylaneSession, mp3: bytes) -> dict:
    filename = secrets.token_urlsafe(15) + ".mp3"
    sig = session.post_json("/api/v1/company/aws_signatures", params={"key": "audios", "filename": filename})
    presigned_url = sig["url"]
    extra_headers = sig.get("headers", {})

    put = requests.put(
        presigned_url,
        data=mp3,
        headers={"Content-Type": "audio/mpeg", **extra_headers},
    )
    put.raise_for_status()

    bare_url = presigned_url.split("?")[0]
    upload = session.post_json(
        "/api/v1/uploads",
        body={"upload": {"name": "audio_tts.mp3", "url": bare_url}},
    )
    return upload["upload"]


def _compute_mp3_duration(mp3: bytes) -> float:
    return MP3(BytesIO(mp3)).info.length


def _resolve_voice_name(session: StorylaneSession, name: str) -> str:
    data = session.get_json("/api/v1/ai/transcriptions/voices", params={"legacy_format": "false"})
    candidates = [v for v in data["voices"] if not v.get("legacy") and name.casefold() in v["name"].casefold()]
    if not candidates:
        raise RuntimeError(f"no voice matched name {name!r}; try `slcli voices` to browse")
    if len(candidates) > 1:
        names = ", ".join(repr(v["name"]) for v in candidates)
        raise RuntimeError(f"voice name {name!r} is ambiguous, matched: {names}")
    return candidates[0]["voice_id"]


@app.command()
def update(
    xlsx: Path = typer.Option(Path("output/texts.xlsx"), "--xlsx", "-x", help="Edited xlsx to read"),
    output_dir: Path = typer.Option(Path("output"), "--output", "-o", help="Directory for debug dumps"),
    key: str | None = typer.Option(None, "--key", help="Override the cached API key"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt"),
    voice_id: str | None = typer.Option(None, "--voice-id", help="TTS voice ID to use when adding a voiceover to a widget that has none yet"),
    voice_name: str | None = typer.Option(None, "--voice-name", help="TTS voice name (case-insensitive substring match) as a friendlier alternative to --voice-id"),
    voice_override: bool = typer.Option(False, "--voice-override", help="Use the CLI-provided voice even when the widget already has its own"),
):
    """Push `new text` / `new voiceover` edits from an exported xlsx back to Storylane."""
    if voice_id and voice_name:
        typer.echo("Pass only one of --voice-id and --voice-name.", err=True)
        raise typer.Exit(code=1)
    if voice_override and not (voice_id or voice_name):
        typer.echo("--voice-override has no effect without --voice-id or --voice-name.", err=True)
        raise typer.Exit(code=1)
    if not xlsx.exists():
        typer.echo(f"xlsx not found: {xlsx}", err=True)
        raise typer.Exit(code=1)

    changes = _read_xlsx_changes(xlsx)
    if not changes:
        typer.echo("Nothing to update.")
        return

    project_ids = {c["project_id"] for c in changes}
    if len(project_ids) != 1:
        typer.echo(f"Rows reference multiple project_ids: {project_ids}", err=True)
        raise typer.Exit(code=1)
    project_id = project_ids.pop()

    output_dir.mkdir(parents=True, exist_ok=True)
    session = StorylaneSession(_get_key(key), output_dir)

    project = session.get_json(f"/api/v1/company/projects/{project_id}", save="project")
    widgets_by_id: dict[str, tuple[str, dict]] = {}
    for flow in project["project"]["flows"]:
        for widget in flow["widgets"]:
            widgets_by_id[widget["id"]] = (flow["id"], widget)

    missing = [c["widget_id"] for c in changes if c["widget_id"] not in widgets_by_id]
    if missing:
        typer.echo(f"Widgets in xlsx no longer exist in project: {missing}", err=True)
        raise typer.Exit(code=1)

    text_only = sum(1 for c in changes if c["new_text"] and not c["new_voiceover"])
    voice_only = sum(1 for c in changes if c["new_voiceover"] and not c["new_text"])
    both = sum(1 for c in changes if c["new_text"] and c["new_voiceover"])
    typer.echo(f"Will update {len(changes)} widgets in project {project_id}:")
    if text_only:
        typer.echo(f"  - {text_only} text-only")
    if voice_only:
        typer.echo(f"  - {voice_only} voiceover-only")
    if both:
        typer.echo(f"  - {both} both")
    if not yes and not typer.confirm("Apply?", default=False):
        typer.echo("Aborted.")
        return

    needs_voiceover = voice_only + both > 0
    if voice_name and needs_voiceover:
        try:
            voice_id = _resolve_voice_name(session, voice_name)
        except RuntimeError as e:
            typer.echo(str(e), err=True)
            raise typer.Exit(code=1)

    failures = 0
    for i, change in enumerate(changes, 1):
        flow_id, widget = widgets_by_id[change["widget_id"]]
        modifications: list[str] = []
        try:
            new_widget = copy.deepcopy(widget)
            if change["new_text"]:
                new_widget["options"]["description"]["value"] = _markdown_to_html(change["new_text"])
                modifications.append("text")
            if change["new_voiceover"]:
                existing = new_widget.get("transcription_options") or {}
                if voice_override and voice_id:
                    widget_voice_id = voice_id
                else:
                    widget_voice_id = existing.get("voice_id") or voice_id
                if not widget_voice_id:
                    raise RuntimeError(
                        "widget has no existing voice_id; pass --voice-id or --voice-name to specify one"
                    )
                mp3 = _generate_tts(session, change["new_voiceover"], widget_voice_id, output_dir, widget["id"])
                upload = _upload_audio(session, mp3)
                new_widget["audio_url"] = upload["url"]
                new_widget["media_source"] = "tts"
                new_widget["media_duration"] = _compute_mp3_duration(mp3)
                new_widget["transcription_options"] = {
                    **existing,
                    "voice_id": widget_voice_id,
                    "prompt": change["new_voiceover"],
                }
                modifications.append("voiceover")

            session.patch_json(
                f"/api/v1/company/projects/{project_id}/flows/{flow_id}/widgets/{widget['id']}",
                body={"widget": new_widget},
            )
            typer.echo(f"[{i}/{len(changes)}] OK   {widget['id']}  {' + '.join(modifications)}")
        except typer.Exit:
            raise
        except Exception as e:
            failures += 1
            typer.echo(f"[{i}/{len(changes)}] FAIL {widget['id']}  {e}", err=True)

    if failures:
        raise typer.Exit(code=1)


@app.command()
def voices(
    xlsx: Path | None = typer.Option(None, "--xlsx", "-x", help="Write the catalog to a spreadsheet instead of printing to stdout"),
    all_: bool = typer.Option(False, "--all", help="Include voices marked legacy/deprecated"),
    key: str | None = typer.Option(None, "--key", help="Override the cached API key"),
):
    """List Storylane TTS voices (name, voice_id, language, etc.)."""
    output_dir = xlsx.parent if xlsx is not None else None
    if output_dir is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
    session = StorylaneSession(_get_key(key), output_dir)

    data = session.get_json(
        "/api/v1/ai/transcriptions/voices",
        params={"legacy_format": "false"},
        save="voices" if xlsx is not None else None,
    )
    voice_list = data["voices"]
    if not all_:
        voice_list = [v for v in voice_list if not v.get("legacy")]
    voice_list.sort(key=lambda v: v["name"].casefold())

    if xlsx is not None:
        rows = [
            {
                "name": v["name"],
                "voice_id": v["voice_id"],
                "gender": v.get("gender"),
                "language": v.get("language"),
                "country_code": v.get("country_code"),
                "accent": v.get("accent"),
                "custom": v.get("custom"),
                "legacy": v.get("legacy"),
                "preview_url": v.get("preview_url"),
            }
            for v in voice_list
        ]
        with SaveAsXlsx(
            xlsx,
            rows,
            column_order=["name", "voice_id", "gender", "language", "country_code", "accent", "custom", "legacy", "preview_url"],
            column_width={
                "name": ColumnWidth.AUTOFIT,
                "accent": ColumnWidth.AUTOFIT,
                "preview_url": 60,
            },
        ):
            pass
        typer.echo(f"Wrote {len(rows)} voices to {xlsx}")
        return

    table = Table(title=f"Storylane voices ({len(voice_list)})")
    table.add_column("Name", overflow="fold")
    table.add_column("voice_id", overflow="fold")
    table.add_column("Gender")
    table.add_column("Lang")
    table.add_column("Country")
    table.add_column("Accent", overflow="fold")
    table.add_column("Custom")
    for v in voice_list:
        table.add_row(
            v["name"],
            v["voice_id"],
            v.get("gender") or "",
            v.get("language") or "",
            v.get("country_code") or "",
            v.get("accent") or "",
            "yes" if v.get("custom") else "",
        )
    Console().print(table)


@app.command()
def login(
    email: str | None = typer.Option(None, "--email", help="Storylane account email"),
):
    """Log into Storylane and cache the API token in the OS keyring."""
    email = email or typer.prompt("Email")
    password = typer.prompt("Password", hide_input=True)
    session = StorylaneSession()
    result = session.post(
        "https://api.storylane.io/api/v1/login",
        json={"email": email, "password": password},
    )
    if not result.ok:
        try:
            detail = result.json()["error"]["title"]
        except (ValueError, KeyError, TypeError):
            detail = result.reason
        typer.echo(f"Login failed: {detail}", err=True)
        raise typer.Exit(code=1)
    token = result.json()["user"]["auth_token"]
    keyring.set_password(SERVICE, USERNAME, token)
    typer.echo("Logged in.")


@app.command()
def logout():
    """Clear the cached Storylane API key."""
    try:
        keyring.delete_password(SERVICE, USERNAME)
        typer.echo("Cached API key cleared.")
    except keyring.errors.PasswordDeleteError:
        typer.echo("No cached API key to clear.")


if __name__ == "__main__":
    app()
