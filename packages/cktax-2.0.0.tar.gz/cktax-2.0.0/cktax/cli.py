import os
import sys
import zipfile
import random
import string
import hashlib
import shutil
import time
import subprocess
import glob

INSTALL_CFG = "install_path.ini"
CURRENT_KEY_CFG = "current_key.ini"
BACKUP_SEQ_CFG = "backup_seq.ini"


def get_key_hint(key):
    if len(key) > 12:
        return key[:6] + "..." + key[-6:]
    return key


def get_global_cktax_path():
    user_conf = os.path.expanduser("~/.cktax_install.ini")

    if not os.path.exists(user_conf):
        print("===== 首次使用 cktax 请设置安装存储目录 =====")
        install_path = input("请输入安装地址: ").strip()
        install_path = os.path.expanduser(install_path)
        install_path = os.path.abspath(install_path)
        os.makedirs(install_path, exist_ok=True)

        cktax_dir = os.path.join(install_path, ".cktax")
        os.makedirs(cktax_dir, exist_ok=True)

        with open(user_conf, "w", encoding="utf-8") as f:
            f.write(install_path)

        cfg_path = os.path.join(cktax_dir, INSTALL_CFG)
        with open(cfg_path, "w", encoding="utf-8") as f:
            f.write(install_path)

        key_cfg = os.path.join(cktax_dir, CURRENT_KEY_CFG)
        with open(key_cfg, "w", encoding="utf-8") as f:
            f.write("0")

        seq_path = os.path.join(cktax_dir, BACKUP_SEQ_CFG)
        with open(seq_path, "w", encoding="utf-8") as f:
            f.write("1")
    else:
        with open(user_conf, "r", encoding="utf-8") as f:
            install_path = f.read().strip()
        cktax_dir = os.path.join(install_path, ".cktax")
        os.makedirs(cktax_dir, exist_ok=True)

    return cktax_dir


def path_set():
    user_conf = os.path.expanduser("~/.cktax_install.ini")
    if not os.path.exists(user_conf):
        print("[cktax]  尚未初始化，请先运行任意 cktax 命令完成首次配置")
        return

    with open(user_conf, "r", encoding="utf-8") as f:
        old_install = f.read().strip()
    old_cktax = os.path.join(old_install, ".cktax")

    print("[cktax] 请输入新的全局存储安装地址:")
    new_install = input().strip()
    new_install = os.path.expanduser(new_install)
    new_install = os.path.abspath(new_install)
    os.makedirs(new_install, exist_ok=True)
    new_cktax = os.path.join(new_install, ".cktax")

    if os.path.exists(old_cktax):
        shutil.copytree(old_cktax, new_cktax, dirs_exist_ok=True)

    with open(user_conf, "w", encoding="utf-8") as f:
        f.write(new_install)

    inner_cfg = os.path.join(new_cktax, INSTALL_CFG)
    with open(inner_cfg, "w", encoding="utf-8") as f:
        f.write(new_install)

    print(f"[cktax]  已成功更换全局地址")
    print(f"旧地址: {old_install}")
    print(f"新地址: {new_install}")


def get_backup_seq():
    cktax_dir = get_global_cktax_path()
    seq_file = os.path.join(cktax_dir, BACKUP_SEQ_CFG)

    if not os.path.exists(seq_file):
        seq = 1
    else:
        with open(seq_file, "r", encoding="utf-8") as f:
            seq = int(f.read().strip() or 1)

    with open(seq_file, "w", encoding="utf-8") as f:
        f.write(str(seq + 1))

    return seq


def get_key_list():
    cktax_dir = get_global_cktax_path()
    keys = []
    for f in os.listdir(cktax_dir):
        if f.startswith("key_bak_") and os.path.isfile(os.path.join(cktax_dir, f)):
            try:
                num = int(f.replace("key_bak_", ""))
                keys.append(num)
            except:
                pass
    return sorted(keys)


def key_add():
    cktax_dir = get_global_cktax_path()
    print("[cktax] 请输入新的 PyPI Token/密钥：")
    new_key = input().strip()
    if not new_key:
        print("[cktax]  密钥不能为空")
        return

    nums = get_key_list()
    new_num = max(nums) + 1 if nums else 1
    key_path = os.path.join(cktax_dir, f"key_bak_{new_num}")

    with open(key_path, "w", encoding="utf-8") as f:
        f.write(new_key)

    hint = get_key_hint(new_key)
    print(f"[cktax]  密钥已保存为编号 {new_num}，片段：{hint}")


def key_set(num):
    cktax_dir = get_global_cktax_path()
    key_path = os.path.join(cktax_dir, f"key_bak_{num}")

    if not os.path.exists(key_path):
        print(f"[cktax]  不存在编号 {num} 的密钥")
        return

    cfg = os.path.join(cktax_dir, CURRENT_KEY_CFG)
    with open(cfg, "w", encoding="utf-8") as f:
        f.write(str(num))

    with open(key_path, "r", encoding="utf-8") as f:
        key = f.read().strip()
    hint = get_key_hint(key)
    print(f"[cktax]  已切换到密钥编号 {num}，片段：{hint}")


def get_current_key():
    cktax_dir = os.path.expanduser(get_global_cktax_path())
    cfg = os.path.join(cktax_dir, CURRENT_KEY_CFG)

    with open(cfg, "r", encoding="utf-8") as f:
        curr_num = f.read().strip()

    try:
        curr_num = int(curr_num)
    except:
        return None

    key_path = os.path.join(cktax_dir, f"key_bak_{curr_num}")
    if not os.path.exists(key_path):
        return None

    with open(key_path, "r", encoding="utf-8") as f:
        return f.read().strip()


def bak():
    print("[cktax] 正在备份当前目录...")

    seq_num = get_backup_seq()
    time_str = time.strftime("%Y%m%d_%H%M%S")
    rand_part = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    ts = str(int(time.time()))
    hash_part = hashlib.md5(ts.encode()).hexdigest()[:8]

    zip_filename = f"backup_{seq_num}_{time_str}_{rand_part}_{hash_part}.zip"

    skip_dirs = {"__pycache__", "dist", "build", ".egg-info", ".git", ".vscode"}

    with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk("."):
            if any(s in root for s in skip_dirs):
                continue
            for file in files:
                filepath = os.path.join(root, file)
                zf.write(filepath)

    print(f"[cktax]  备份完成 > 编号:{seq_num} 文件:{zip_filename}")


def back():
    print("[cktax] 开始打包项目...")
    subprocess.run([sys.executable, "-m", "build"], check=False)
    print("[cktax]  打包完成")

def back_up():
    if not os.path.exists("dist") or not os.listdir("dist"):
        print("[cktax]  未检测到 dist 打包文件，请先执行打包")
        return

    key = get_current_key()
    dist_files = glob.glob("dist/*")
    if not dist_files:
        print("[cktax]  未找到打包文件 (*.tar.gz, *.whl)")
        return

    file_list = " ".join(dist_files)

    if not key:
        print("[cktax]  未配置密钥，将手动输入")
        cmd = f"{sys.executable} -m twine upload {file_list}"
    else:
        hint = get_key_hint(key)
        print(f"[cktax]  使用全局密钥自动上传，当前密钥片段：{hint}")
        cmd = f"{sys.executable} -m twine upload -u __token__ -p {key} {file_list}"


    ret = os.system(cmd)
    if ret == 0:
        print("[cktax]  上传完成")
    else:
        print(f"[cktax]  上传失败，退出码: {ret}")

def all_task():
    print("===== cktax 全流程开始 =====")
    
    back()
    
    back_up()
    
    bak()
    
    remote_file = _get_git_remote_file()
    has_remote_config = os.path.exists(remote_file)
    

    has_origin = False
    if _is_git_repo():
        result = subprocess.run(["git", "remote", "get-url", "origin"], capture_output=True)
        has_origin = result.returncode == 0
    
    print("\n[cktax] 检测到 Git 状态：")
    if has_origin:
        print("    已有远程仓库 (origin)")
        choice = input("\n是否推送到已有仓库？(y/N): ").strip().lower()
        if choice == 'y':
            git_push_to_existing()
        else:
            print("[cktax] 跳过推送")
    elif has_remote_config:
        print("    有保存的远程地址但未添加 origin")
        choice = input("\n是否添加并推送？(y/N): ").strip().lower()
        if choice == 'y':
            git_add_remote_and_push()
        else:
            print("[cktax] 跳过推送")
    else:
        print("    未检测到远程仓库")
        print("\n请选择：")
        print("1) 创建新仓库并推送")
        print("2) 已有仓库（手动输入地址）")
        print("3) 跳过")
        choice = input("请选择 (1/2/3): ").strip()
        
        if choice == "1":
            if github_create_repo():
                git_push_to_existing()
        elif choice == "2":
            git_remote_set()
            git_push_to_existing()
        else:
            print("[cktax] 跳过推送")
    
    print("\n===== 全流程执行完毕 =====")

def git_push_to_existing():
    print("\n[cktax] 正在推送到 GitHub...")
    branch = _get_current_branch()
    if not branch:
        branch = input("分支名（默认 main）: ").strip()
        branch = branch or "main"
    
    try:
        status = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True)
        if status.stdout.strip():
            subprocess.run(["git", "add", "."], check=True)
            commit_msg = input("提交信息（回车 = Update from cktax）: ").strip()
            if not commit_msg:
                commit_msg = "Update from cktax"
            subprocess.run(["git", "commit", "-m", commit_msg], check=True)
        else:
            print("[cktax]  没有需要提交的变更")
        
        subprocess.run(["git", "push", "origin", branch], check=True)
        print("[cktax]  推送成功")
    except subprocess.CalledProcessError as e:
        print(f"[cktax]  推送失败: {e}")

def git_add_remote_and_push():
    remote_file = _get_git_remote_file()
    with open(remote_file, "r", encoding="utf-8") as f:
        remote_url = f.read().strip()
    

    token_file = _get_git_token_file()
    if remote_url.startswith("https://") and os.path.exists(token_file):
        with open(token_file, "r", encoding="utf-8") as f:
            token = f.read().strip()
        rest = remote_url[8:]
        auth_url = f"https://{token}@{rest}"
    else:
        auth_url = remote_url
    
    subprocess.run(["git", "remote", "add", "origin", auth_url], check=True)
    git_push_to_existing()

def key_subcmd():
    if len(sys.argv) < 3:
        print("[cktax key] 用法：")
        print("  cktax key add       新增密钥")
        print("  cktax key set 编号   切换密钥")
        return
    opt = sys.argv[2]
    if opt == "add":
        key_add()
    elif opt == "set":
        if len(sys.argv) < 4:
            print("[cktax] 格式：cktax key set 数字")
            return
        try:
            n = int(sys.argv[3])
            key_set(n)
        except:
            print("[cktax] 编号必须是整数")
    else:
        print("[cktax] 未知 key 子命令")


def path_subcmd():
    if len(sys.argv) < 3:
        print("[cktax path] 用法：")
        print("  cktax path set   修改全局存储地址")
        return
    opt = sys.argv[2]
    if opt == "set":
        path_set()
    else:
        print("[cktax] 未知 path 子命令")



def _get_git_remote_file():
    cktax_dir = get_global_cktax_path()
    return os.path.join(cktax_dir, "git_remote")

def _get_git_token_file():
    cktax_dir = get_global_cktax_path()
    return os.path.join(cktax_dir, "git_token")

def _is_git_repo():
    try:
        subprocess.run(["git", "rev-parse", "--git-dir"], check=True, capture_output=True)
        return True
    except:
        return False

def _get_current_branch():
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            text=True, stderr=subprocess.DEVNULL
        ).strip()
    except:
        return None

def github_create_repo():
    token_file = _get_git_token_file()
    if not os.path.exists(token_file):
        print("[cktax]  未配置 GitHub token，请先执行: cktax git token")
        return False
    
    with open(token_file, "r", encoding="utf-8") as f:
        token = f.read().strip()
    
    repo_name = input("\n请输入仓库名称: ").strip()
    if not repo_name:
        print("[cktax]  仓库名称不能为空")
        return False
    
    desc = input("仓库描述（可选）: ").strip()
    private = input("是否私有？(y/N): ").strip().lower() == 'y'
    
    import json
    import urllib.request
    
    url = "https://api.github.com/user/repos"
    data = json.dumps({
        "name": repo_name,
        "description": desc,
        "private": private,
        "auto_init": False
    }).encode()
    
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Authorization", f"token {token}")
    req.add_header("Accept", "application/json")
    req.add_header("Content-Type", "application/json")
    
    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode())
            print(f"[cktax]  GitHub 仓库已创建: {result['html_url']}")
            
            remote_file = _get_git_remote_file()
            with open(remote_file, "w", encoding="utf-8") as f:
                f.write(result['clone_url'])
            return True
    except urllib.error.HTTPError as e:
        print(f"[cktax]  创建失败: {e}")
        if e.code == 422:
            print("   仓库名可能已存在或无效")
        return False


def git_remote_set():
    remote_file = _get_git_remote_file()
    print("[cktax] 请输入远程仓库地址")
    print("  支持 HTTPS: https://github.com/用户名/仓库名.git")
    print("  支持 SSH:   git@github.com:用户名/仓库名.git")
    addr = input("地址: ").strip()
    if not addr:
        print("[cktax]  地址不能为空")
        return
    with open(remote_file, "w", encoding="utf-8") as f:
        f.write(addr)
    print(f"[cktax]  远程地址已保存")


def git_token_set():
    token_file = _get_git_token_file()
    print("[cktax] 请输入 GitHub Personal Access Token（需 repo 权限）")
    print("  获取方式: GitHub Settings → Developer settings → Personal access tokens → Tokens (classic)")
    token = input("Token: ").strip()
    if not token:
        print("[cktax]  token 不能为空")
        return
    with open(token_file, "w", encoding="utf-8") as f:
        f.write(token)
    print("[cktax]  token 已保存")

def git_all():
    print("[cktax]  开始一键开源流程")
    
    if not _is_git_repo():
        print("[cktax] 初始化 git 仓库...")
        subprocess.run(["git", "init"], check=True)
    
    remote_file = _get_git_remote_file()
    if not os.path.exists(remote_file):
        print("[cktax] 未配置远程地址，请先执行: cktax git remote")
        return
    
    git_push_to_existing() 

def git_init():
    if _is_git_repo():
        print("[cktax]  已经是 git 仓库")
        return
    subprocess.run(["git", "init"], check=True)
    print("[cktax]  git 仓库已初始化")

def git_clone():
    url = input("请输入仓库地址: ").strip()
    if not url:
        print("[cktax]  地址不能为空")
        return
    subprocess.run(["git", "clone", url], check=True)
    print("[cktax]  克隆完成")

def git_pull():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    branch = _get_current_branch()
    subprocess.run(["git", "pull", "origin", branch or "main"], check=True)
    print("[cktax]  拉取完成")

def git_status():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    subprocess.run(["git", "status"])

def git_log():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    subprocess.run(["git", "log", "--oneline", "--graph", "-20"])

def git_branch():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    subprocess.run(["git", "branch", "-a"])

def git_diff():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    subprocess.run(["git", "diff"])

def git_stash():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    print("\n1) 查看暂存列表")
    print("2) 暂存变更")
    print("3) 恢复暂存")
    c = input("请选择 (1-3): ").strip()
    if c == "1":
        subprocess.run(["git", "stash", "list"])
    elif c == "2":
        subprocess.run(["git", "stash", "push"])
    elif c == "3":
        subprocess.run(["git", "stash", "pop"])

def git_tag():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    print("\n1) 查看标签")
    print("2) 创建标签")
    c = input("请选择 (1-2): ").strip()
    if c == "1":
        subprocess.run(["git", "tag", "-n"])
    elif c == "2":
        name = input("标签名: ").strip()
        subprocess.run(["git", "tag", name])
        print(f"[cktax]  标签 {name} 已创建")

def git_reset():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    steps = input("回退几个提交？(默认 1): ").strip()
    steps = int(steps) if steps.isdigit() else 1
    subprocess.run(["git", "reset", f"HEAD~{steps}"])
    print(f"[cktax]  已回退 {steps} 个提交")

def git_push():
    remote_file = _get_git_remote_file()
    token_file = _get_git_token_file()

    if not os.path.exists(remote_file):
        print("[cktax]  未配置远程地址，请先执行: cktax git remote")
        return

    with open(remote_file, "r", encoding="utf-8") as f:
        remote_url = f.read().strip()

    is_https = remote_url.startswith("https://")
    is_ssh = remote_url.startswith("git@")

    if is_https:
        if not os.path.exists(token_file):
            print("[cktax]  HTTPS 方式需要 token，请先执行: cktax git token")
            return
        with open(token_file, "r", encoding="utf-8") as f:
            token = f.read().strip()
        rest = remote_url[8:]
        auth_url = f"https://{token}@{rest}"
    elif is_ssh:
        print("[cktax] 使用 SSH 方式推送，请确保已配置 SSH 密钥")
        auth_url = remote_url
    else:
        print("[cktax]  不支持的仓库地址格式")
        return


    try:
        subprocess.run(["git", "rev-parse", "--git-dir"], check=True, capture_output=True)
    except subprocess.CalledProcessError:
        print("[cktax]  当前目录不是 git 仓库，请先运行 git init")
        return


    remote_check = subprocess.run(["git", "remote", "get-url", "origin"], capture_output=True)
    has_origin = remote_check.returncode == 0

    if has_origin:
        subprocess.run(["git", "remote", "set-url", "origin", auth_url], check=True)
    else:
        subprocess.run(["git", "remote", "add", "origin", auth_url], check=True)


    try:
        current_branch = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL
        ).strip()
        print(f"[cktax] 检测到当前分支: {current_branch}")
        branch = current_branch
    except:
        branch = input("请输入要推送的分支名称（默认 main）: ").strip()
        if not branch:
            branch = "main"
        print(f"[cktax] 将使用分支: {branch}")


    print("\n请输入要添加的文件或目录（多个用空格隔开）")
    print("提示：直接回车 = 添加全部变更")
    add_input = input("> ").strip()
    if add_input:
        files = add_input.split()
        for f in files:
            print(f"  git add {f}")
            subprocess.run(["git", "add", f])
    else:
        print("  git add .")
        subprocess.run(["git", "add", "."])


    commit_msg = input("\n请输入本次提交的信息: ").strip()
    if not commit_msg:
        print("[cktax]  提交信息不能为空")
        return

    print("\n请选择推送方式：")
    print("1) 普通推送 (git push)")
    print("2) 强制推送 (git push --force)")
    print("3) 安全强制推送 (git push --force-with-lease)")
    choice = input("请输入 (1/2/3): ").strip()

    if choice == "1":
        push_cmd = ["git", "push", "origin", branch]
    elif choice == "2":
        push_cmd = ["git", "push", "--force", "origin", branch]
    elif choice == "3":
        push_cmd = ["git", "push", "--force-with-lease", "origin", branch]
    else:
        print("[cktax]  无效选择，取消推送")
        return

    try:
        status = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True)
        if not status.stdout.strip():
            print("[cktax]  没有需要提交的变更，跳过 commit")
        else:
            subprocess.run(["git", "commit", "-m", commit_msg], check=True)

        subprocess.run(push_cmd, check=True)
        print("[cktax]  推送成功")
    except subprocess.CalledProcessError as e:
        print(f"[cktax]  推送失败: {e}")
    except Exception as e:
        print(f"[cktax]  未知错误: {e}")


def git_subcmd():
    if len(sys.argv) < 3:
        print("\n[cktax git] 用法：")
        print("=" * 50)
        print("  cktax git all        一键自动开源（推荐）")
        print("  cktax git init       初始化仓库")
        print("  cktax git clone      克隆仓库")
        print("  cktax git remote     设置远程仓库地址")
        print("  cktax git token      设置 GitHub token")
        print("  cktax git push       推送代码")
        print("  cktax git pull       拉取更新")
        print("  cktax git status     查看状态")
        print("  cktax git log        查看历史")
        print("  cktax git branch     分支管理")
        print("  cktax git diff       查看差异")
        print("  cktax git stash      暂存管理")
        print("  cktax git tag        标签管理")
        print("  cktax git reset      撤销提交")
        print("=" * 50)
        return
    
    subcmd = sys.argv[2]
    if subcmd == "all":
        git_all()
    if subcmd == "init":
        git_init()
    elif subcmd == "clone":
        git_clone()
    elif subcmd == "remote":
        git_remote_set()
    elif subcmd == "push":
        git_push()
    elif subcmd == "pull":
        git_pull()
    elif subcmd == "status":
        git_status()
    elif subcmd == "log":
        git_log()
    elif subcmd == "branch":
        git_branch()
    elif subcmd == "diff":
        git_diff()
    elif subcmd == "stash":
        git_stash()
    elif subcmd == "tag":
        git_tag()
    elif subcmd == "reset":
        git_reset()
    elif subcmd == "token":
        git_token_set()
    else:
        print(f"[cktax] 未知 git 子命令: {subcmd}")


def main():
    if len(sys.argv) < 2:
        print("===== cktax 工具用法 =====")
        print("cktax bak      备份当前项目")
        print("cktax back     项目打包 build")
        print("cktax up       上传到 PyPI")
        print("cktax all      一条龙：备份+打包+上传")
        print("cktax key      密钥管理")
        print("cktax path     全局地址管理")
        print("cktax git      Git 推送管理")
        return

    cmd = sys.argv[1]
    if cmd == "bak":
        bak()
    elif cmd == "back":
        back()
    elif cmd == "up":
        back_up()
    elif cmd == "all":
        all_task()
    elif cmd == "key":
        key_subcmd()
    elif cmd == "path":
        path_subcmd()
    elif cmd == "git":
        git_subcmd()
    else:
        print(f"[cktax] 未知命令：{cmd}")


if __name__ == "__main__":
    main()