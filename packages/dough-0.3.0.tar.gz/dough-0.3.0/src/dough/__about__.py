# This is used by `hatch` to determine the version dynamically
__version__ = "0.3.0"
