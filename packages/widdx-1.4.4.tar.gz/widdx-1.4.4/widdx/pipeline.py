"""Execution pipeline — adaptive 7-step pipeline with lightweight shortcut."""
from __future__ import annotations

import json
import logging
import re
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# When set to False the preflight and scaffolding steps are skipped
# (controlled by config key: pipeline.scaffold_enabled)
_DEFAULT_SCAFFOLD_ENABLED = True


@dataclass
class PipelineResult:
    task_id: str
    intent: str
    complexity: int
    pipeline_depth: int
    plan: dict | None = None
    agents_generated: list = field(default_factory=list)
    execution_output: str = ""
    review_feedback: str = ""
    evolution_report: dict | None = None
    total_latency_ms: int = 0


class ExecutionPipeline:
    """Adaptive pipeline: lightweight for simple tasks, full pipeline for complex ones."""

    def __init__(self, router, agent_factory, memory, evolution, config: dict[str, Any] | None = None) -> None:
        self._router = router
        self._agent_factory = agent_factory
        self._memory = memory
        self._evolution = evolution
        cfg = config or {}
        self._complex_threshold = cfg.get("pipeline", {}).get("complex_threshold", 3)
        self._max_retries = 2
        self._scaffold_enabled = cfg.get("pipeline", {}).get("scaffold_enabled", _DEFAULT_SCAFFOLD_ENABLED)

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def run(self, command: str) -> PipelineResult:
        task_id = uuid.uuid4().hex[:12]
        start = time.perf_counter()

        intent, complexity = self._analyze_input(command)
        self._memory.create_task(task_id, command, intent, complexity)

        # ── Step 0: Scaffold project if needed ──────────────────────
        # (Runs before pre-flight so we know what framework/tools are needed)
        if self._scaffold_enabled:
            self._run_scaffolding(command)

        # ── Step 0b: Pre-flight health check ─────────────────────────
        # After scaffolding, we know the framework → check only relevant tools
        if self._scaffold_enabled:
            preflight_ok = self._run_preflight(command)
            if not preflight_ok:
                elapsed_ms = int((time.perf_counter() - start) * 1000)
                return PipelineResult(
                    task_id=task_id, intent=intent, complexity=complexity,
                    pipeline_depth=0,
                    execution_output="Pre-flight check failed — missing required tools.",
                    total_latency_ms=elapsed_ms,
                )

        is_creation_task = bool(re.search(r'(?i)(save\s+to|write\s+file|create\s+file|output\s+to)\s+\S+\.\w+', command))
        full_pipeline = (complexity >= self._complex_threshold) and not is_creation_task

        if full_pipeline:
            from .project_planner import ProjectPlanner
            planner = ProjectPlanner(self._router, self._memory)

            # ── Step 1: Requirements Analysis ──────────────────────────
            from . import ui
            ui.get_console().print("\n  [brand]◆[/] [bold]Requirements Analysis[/]")
            spec_result = planner.create_spec(command, self._agent_factory)

            # ── Step 2: Architecture Design ────────────────────────────
            ui.get_console().print("\n  [brand]◆[/] [bold]Architecture Design[/]")
            arch_result = planner.create_architecture(command, spec_result, self._agent_factory)

            # ── Step 3: Planning with spec + architecture context ──────
            project_plan = planner.create_plan(command, complexity, spec_result, arch_result)
            self._memory.log_decision(task_id, "planning", "task_plan", command, str(project_plan.to_dict())[:500], "deepseek")

            # ── Step 4: Execute phased plan (each phase includes Code Review Gate) ──
            planner.execute_plan(project_plan, self._agent_factory)

            execution_output = f"Executed multi-phase project plan '{project_plan.id}' with {len(project_plan.phases)} phases."

            # Collect files modified across all phases
            all_files = []
            for phase in project_plan.phases:
                all_files.extend(phase.files_created)
                all_files.extend(phase.files_edited)
            all_files = list(dict.fromkeys(all_files))

            # ── Step 5: Final Integration Testing ──────────────────────
            from .verifier import ProjectVerifier
            verifier = ProjectVerifier(router=self._router)
            verify_result = verifier.verify_pipeline(all_files)
            if not verify_result.passed:
                execution_output += (
                    "\n\n## Verification\n"
                    f"Status: FAILED after {verify_result.fix_attempts} fix attempts\n"
                    f"Errors: {chr(10).join(verify_result.errors[:5])}"
                )

            # ── Step 5b: Integration test ─────────────────────────
            self._run_integration_test(command)
            ui.get_console().print("  [success]✓[/] Integration tests passed")

            # ── Step 6: Build verification ─────────────────────────────
            build_result = verifier.verify_build()
            if build_result["passed"]:
                pass
            elif build_result["output"]:
                execution_output += (
                    f"\n\n## Build Check\n"
                    f"Status: {build_result['status']}\n"
                    f"{build_result['output'][:500]}"
                )

            # ── Step 7: Code Review Gate (full project review) ─────────
            review = self._run_final_code_review(command, all_files)

            # ── Step 8: Documentation Generation ───────────────────────
            self._run_documentation(command, project_plan)

            # ── Step 9: Deployment Files ───────────────────────────────
            self._run_deployment_setup(command)

            self._consolidate_memory(task_id, command, execution_output, review)
            evo_report = self._evolution_patch(task_id, command, complexity)

            agents_generated: list = []  # Handled dynamically by planner per-phase
        else:
            result = self._execute_simple(command, task_id)
            plan = None
            agents_generated = []
            execution_output = result.get("text", "")
            review = ""
            evo_report = None

            if self._is_error(result):
                execution_output = f"API Error: {result.get('error', 'unknown error')}"
                self._memory.complete_task(task_id, "failed")
            else:
                self._memory.complete_task(task_id)

        saved_files = self._extract_and_save(command, execution_output)

        total_ms = int((time.perf_counter() - start) * 1000)
        return PipelineResult(
            task_id=task_id,
            intent=intent,
            complexity=complexity,
            pipeline_depth=7 if full_pipeline else 2,
            plan=plan,
            agents_generated=agents_generated,
            execution_output=execution_output if not saved_files else execution_output + "\n\n" + saved_files,
            review_feedback=review,
            evolution_report=evo_report,
            total_latency_ms=total_ms,
        )

    # ------------------------------------------------------------------
    # Integration test + Code Review + Documentation + Deployment
    # ------------------------------------------------------------------

    def _run_integration_test(self, command: str) -> None:
        """Test that the full project builds and basic commands work."""
        from . import ui
        c = ui.get_console()
        c.print("  [dim]⎿ Running integration checks...[/]")
        try:
            from .verifier import ProjectVerifier
            verifier = ProjectVerifier(self._router)
            result = verifier.verify_build()
            if result.get("passed"):
                c.print("  [success]✓ Integration checks passed[/]")
            else:
                c.print(f"  [warning]⚠ Integration: {result.get('output', 'issues found')[:200]}[/]")
        except Exception as e:
            c.print(f"  [warning]⚠ Integration check skipped: {e}[/]")

    def _run_final_code_review(self, command: str, files: list[str]) -> str:
        """Final project-level code review by the architect model."""
        from . import ui
        c = ui.get_console()
        c.print("  [brand]◆[/] [bold]Final Code Review[/]")

        if not files:
            return ""

        system = (
            "You are a lead code reviewer. Review the list of files created for this project. "
            "Identify: (1) missing error handling, (2) security issues, (3) performance concerns, "
            "(4) missing tests, (5) documentation gaps. Be concise — 5 bullet points max."
        )
        msg = f"Files:\n" + "\n".join(files[:30])
        result = self._router.call_architect(system, msg, max_tokens=1024)
        review = result.get("text", "") if not self._is_error(result) else ""
        if review:
            c.print(f"  [dim]{review[:2000]}[/]")
        return review

    def _run_documentation(self, command: str, plan: object) -> None:
        """Generate README.md + API overview in .widdx/ (framework-agnostic)."""
        from . import ui
        c = ui.get_console()
        c.print("  [brand]◆[/] [bold]Generating Documentation[/]")

        try:
            from .project_state import get_widdx_dir
            widdx_dir = get_widdx_dir()
            cwd = __import__("pathlib").Path.cwd()
            project_name = cwd.name

            # Detect project type from ANY framework clues
            has_pkg = list(cwd.glob("package.json"))
            has_composer = list(cwd.glob("composer.json"))
            has_reqs = list(cwd.glob("requirements.txt"))
            has_artisan = list(cwd.glob("artisan"))
            has_manage = list(cwd.glob("manage.py"))
            has_cargo = list(cwd.glob("Cargo.toml"))
            has_go = list(cwd.glob("go.mod"))
            has_pubspec = list(cwd.glob("pubspec.yaml"))
            has_gemfile = list(cwd.glob("Gemfile"))
            has_mix = list(cwd.glob("mix.exs"))

            install_commands = []
            run_commands = []

            if has_composer:
                install_commands.append("composer install")
                run_commands.append("php artisan serve" if has_artisan else "php -S localhost:8000 -t public")
            if has_pkg:
                install_commands.append("npm install")
                run_commands.append("npm run dev")
            if has_reqs:
                install_commands.append("pip install -r requirements.txt")
                run_commands.append("python manage.py runserver" if has_manage else "python app.py")
            if has_cargo:
                install_commands.append("cargo build --release")
                run_commands.append("cargo run --release")
            if has_go:
                install_commands.append("go mod download")
                run_commands.append("go run .")
            if has_pubspec:
                install_commands.append("flutter pub get")
                run_commands.append("flutter run")
            if has_gemfile:
                install_commands.append("bundle install")
                run_commands.append("rails server" if list(cwd.glob("bin/rails")) else "ruby app.rb")
            if has_mix:
                install_commands.append("mix deps.get")
                run_commands.append("mix phx.server")

            if not install_commands:
                install_commands = ["# Check documentation for your specific framework"]
                run_commands = ["# Follow framework-specific instructions"]

            readme_lines = [
                f"# {project_name}",
                "",
                f"Built with **WIDDX CLI** — Autonomous AI Software Engineering OS",
                "",
                "## Quick Start",
                "",
                "```bash",
            ]
            for cmd in install_commands:
                readme_lines.append(cmd)
            readme_lines.append("")
            for cmd in run_commands:
                readme_lines.append(cmd)
            readme_lines.append("```\n")

            cwd_readme = cwd / "README.md"
            cwd_readme.write_text("\n".join(readme_lines), encoding="utf-8")
            c.print("  [success]✓[/] README.md generated")

            # API doc
            api_doc = (
                f"# API Documentation\n\n"
                f"## Endpoints\n\n"
                f"_(Generated by WIDDX — list key API endpoints here)_\n"
            )
            api_path = widdx_dir / "api.md"
            api_path.write_text(api_doc, encoding="utf-8")
            c.print(f"  [success]✓[/] API doc saved to [text].widdx/api.md[/]")
        except Exception:
            pass

    def _run_deployment_setup(self, command: str) -> None:
        """Generate Dockerfile + docker-compose.yml (generic — ANY framework)."""
        from . import ui
        c = ui.get_console()
        c.print("  [brand]◆[/] [bold]Deployment Setup[/]")

        try:
            from .project_state import get_widdx_dir
            widdx_dir = get_widdx_dir()
            cwd = __import__("pathlib").Path.cwd()

            if (cwd / "Dockerfile").exists() or (cwd / "docker-compose.yml").exists():
                c.print("  [dim]Deployment files already exist — skipping[/]")
                return

            cwd_files = list(cwd.glob("*"))
            cwd_names = {f.name.lower() for f in cwd_files}

            # Framework-agnostic detection
            has_php = any(f.suffix == ".php" for f in cwd_files)
            has_python = any(f.suffix == ".py" for f in cwd_files)
            has_js = any(f.suffix in (".js", ".jsx", ".ts", ".tsx") for f in cwd_files)
            has_go = "go.mod" in cwd_names
            has_rust = "cargo.toml" in cwd_names
            has_ruby = "gemfile" in cwd_names or "gemfile.lock" in cwd_names
            has_dart = "pubspec.yaml" in cwd_names

            # Generate Dockerfile
            if has_php:
                dockerfile = (
                    "FROM php:8.2-cli\n"
                    "RUN apt-get update && apt-get install -y git unzip libpq-dev libzip-dev \\\n"
                    "    && docker-php-ext-install pdo pdo_mysql pdo_pgsql zip\n"
                    "COPY --from=composer:latest /usr/bin/composer /usr/bin/composer\n"
                    "WORKDIR /app\nCOPY . .\n"
                    "RUN composer install --no-dev --optimize-autoloader\n"
                    'CMD ["php", "artisan", "serve", "--host=0.0.0.0", "--port=8000"]\n'
                )
                deploy_cmds = "composer install --no-dev\nphp artisan migrate\nphp artisan serve"
            elif has_python:
                dockerfile = (
                    "FROM python:3.12-slim\n"
                    "WORKDIR /app\nCOPY . .\n"
                    "RUN pip install -r requirements.txt 2>/dev/null || pip install -e . 2>/dev/null || true\n"
                    'CMD ["python", "-m", "uvicorn", "main:app", "--host=0.0.0.0", "--port=8000"]\n'
                )
                deploy_cmds = "pip install -r requirements.txt\npython manage.py migrate 2>/dev/null || true\npython app.py"
            elif has_js:
                dockerfile = (
                    "FROM node:20-alpine\n"
                    "WORKDIR /app\n"
                    "COPY package*.json .\n"
                    "RUN npm ci --only=production 2>/dev/null || npm install\n"
                    "COPY . .\n"
                    "RUN npm run build 2>/dev/null || true\n"
                    'CMD ["node", "dist/index.js"]\n'
                )
                deploy_cmds = "npm ci --only=production\nnpm run build\nnpm start"
            elif has_go:
                dockerfile = (
                    "FROM golang:1.22-alpine AS builder\n"
                    "WORKDIR /app\nCOPY go.mod go.sum ./\nRUN go mod download\n"
                    "COPY . .\nRUN CGO_ENABLED=0 go build -o /app/server .\n"
                    "FROM alpine:latest\n"
                    "COPY --from=builder /app/server /server\n"
                    'CMD ["/server"]\n'
                )
                deploy_cmds = "go build -o server .\n./server"
            elif has_rust:
                dockerfile = (
                    "FROM rust:1.77-slim AS builder\n"
                    "WORKDIR /app\nCOPY . .\nRUN cargo build --release\n"
                    "FROM debian:bookworm-slim\n"
                    "COPY --from=builder /app/target/release/* /app/\n"
                    'CMD ["/app/app"]\n'
                )
                deploy_cmds = "cargo build --release\n./target/release/app"
            elif has_ruby:
                dockerfile = (
                    "FROM ruby:3.3-slim\n"
                    "WORKDIR /app\nCOPY Gemfile Gemfile.lock ./\n"
                    "RUN bundle install --without development test\n"
                    "COPY . .\n"
                    'CMD ["ruby", "app.rb"]\n'
                )
                deploy_cmds = "bundle install --without development test\nruby app.rb"
            elif has_dart:
                dockerfile = (
                    "FROM dart:stable AS build\n"
                    "WORKDIR /app\nCOPY . .\n"
                    "RUN dart pub get && dart compile exe bin/main.dart -o /app/server\n"
                    "FROM debian:bookworm-slim\n"
                    "COPY --from=build /app/server /server\n"
                    'CMD ["/server"]\n'
                )
                deploy_cmds = "dart pub get\ndart compile exe bin/main.dart -o server\n./server"
            else:
                c.print("  [dim]Could not detect language — skipping Dockerfile[/]")
                return

            (cwd / "Dockerfile").write_text(dockerfile, encoding="utf-8")
            c.print("  [success]✓[/] Dockerfile generated")

            # docker-compose.yml
            compose = (
                "services:\n"
                "  app:\n"
                "    build: .\n"
                "    ports:\n"
                '      - "8000:8000"\n'
            )
            if has_php or has_python or has_ruby:
                compose += (
                    "    depends_on:\n"
                    "      - db\n"
                    "  db:\n"
                    '    image: postgres:16-alpine\n'
                    "    environment:\n"
                    '      POSTGRES_DB: app\n'
                    '      POSTGRES_USER: app\n'
                    '      POSTGRES_PASSWORD: secret\n'
                    "    volumes:\n"
                    '      - pgdata:/var/lib/postgresql/data\n'
                    "volumes:\n"
                    "  pgdata:\n"
                )
            (cwd / "docker-compose.yml").write_text(compose, encoding="utf-8")
            c.print("  [success]✓[/] docker-compose.yml generated")

            # Deploy guide
            deploy_guide = (
                "# Deployment Guide\n\n"
                "## Docker (recommended)\n"
                "```bash\n"
                "docker-compose up -d --build\n"
                "```\n\n"
                "## Manual\n"
                "```bash\n"
                f"{deploy_cmds}\n"
                "```\n"
            )
            (widdx_dir / "deploy.md").write_text(deploy_guide, encoding="utf-8")
            c.print(f"  [success]✓[/] Deploy guide saved to [text].widdx/deploy.md[/]")
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Step 0: Pre-flight and scaffolding
    # ------------------------------------------------------------------

    def _run_preflight(self, command: str) -> bool:
        """Run a pre-flight health check — only checks tools relevant to the task.

        Detects what language/framework is needed from the task description,
        then only checks those specific tools.  If tools are missing, offers
        to auto-install them before proceeding.
        """
        from . import ui
        from .preflight import check_requirements, print_report

        lowered = command.lower()
        if not any(kw in lowered for kw in ["build", "create", "install", "generate", "new project"]):
            return True

        lang_keywords = {
            "python":   ["python", "pygame", "django", "flask", "fastapi"],
            "php":      ["php", "laravel", "wordpress", "symfony"],
            "node":     ["node", "javascript", "typescript", "react", "vue", "nextjs", "npm"],
            "go":       ["golang", "go lang"],
            "rust":     ["rust", "cargo"],
            "ruby":     ["ruby", "rails"],
        }

        required = ["git"]
        for lang, keywords in lang_keywords.items():
            if any(kw in lowered for kw in keywords):
                required.append(lang)

        if len(required) <= 1:
            required.append("python")

        result = check_requirements(required)
        if not result.passed:
            c = ui.get_console()
            c.print(f"  [warning]⚠ Missing tools needed for this project[/]")
            print_report(result)

            if result.missing:
                return self._handle_missing_tools(result.missing)

            from .ui import confirm
            return confirm("Continue anyway?", default=False)

        return True

    def _handle_missing_tools(self, missing: list[str]) -> bool:
        """Offer to auto-install missing development tools."""
        from . import ui
        from .ui.professional import confirm_with_options
        c = ui.get_console()

        c.print()
        install_cmds = self._get_install_commands(missing)
        if not install_cmds:
            return ui.confirm("Continue anyway (no auto-install available)?", default=False)

        c.print(f"  [brand]◆[/] [text]Auto-install missing tools?[/]")
        for tool, cmd in install_cmds:
            c.print(f"     [cyan]{tool}[/]: [dim]{cmd}[/]")

        choice = confirm_with_options(
            "What would you like to do?",
            ["Install all missing tools", "Continue without installing", "Abort"],
            default="Install all missing tools",
        )

        if choice == "Abort":
            return False
        if choice == "Continue without installing":
            return True

        # Auto-install
        for tool, cmd in install_cmds:
            c.print(f"  [dim]⎿ Installing {tool}...[/]")
            try:
                import subprocess
                subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=300)
                c.print(f"  [success]✓ {tool} installed[/]")
            except Exception as e:
                c.print(f"  [error]✗ {tool} failed: {e}[/]")
                return ui.confirm(f"{tool} installation failed. Continue anyway?", default=False)

        c.print(f"  [success]✓ All tools installed[/]")
        return True

    @staticmethod
    def _get_install_commands(missing: list[str]) -> list[tuple[str, str]]:
        """Get OS-appropriate install commands for missing tools."""
        import sys
        import shutil
        commands: list[tuple[str, str]] = []

        is_win = sys.platform == "win32"

        # Detect available package managers
        has_choco = shutil.which("choco") is not None
        has_winget = is_win and shutil.which("winget") is not None
        has_brew = shutil.which("brew") is not None
        has_apt = shutil.which("apt-get") is not None

        tool_map: dict[str, list[str]] = {
            "python": (
                ["winget install Python.Python.3.12 --silent"] if has_winget
                else ["choco install python -y"] if has_choco
                else ["brew install python"] if has_brew
                else ["apt-get install -y python3"] if has_apt
                else []
            ),
            "php": (
                ["winget install PHP.PHP --silent"] if has_winget
                else ["choco install php -y"] if has_choco
                else ["brew install php"] if has_brew
                else ["apt-get install -y php-cli"] if has_apt
                else []
            ),
            "composer": (
                ["winget install Composer.Composer --silent"] if has_winget
                else ["choco install composer -y"] if has_choco
                else ["brew install composer"] if has_brew
                else ["apt-get install -y composer"] if has_apt
                else []
            ),
            "node": (
                ["winget install OpenJS.NodeJS --silent"] if has_winget
                else ["choco install nodejs -y"] if has_choco
                else ["brew install node"] if has_brew
                else ["apt-get install -y nodejs"] if has_apt
                else []
            ),
            "npm": (
                ["winget install OpenJS.NodeJS --silent"] if has_winget
                else ["choco install nodejs -y"] if has_choco
                else ["brew install node"] if has_brew
                else ["apt-get install -y nodejs"] if has_apt
                else []
            ),
            "git": (
                ["winget install Git.Git --silent"] if has_winget
                else ["choco install git -y"] if has_choco
                else ["brew install git"] if has_brew
                else ["apt-get install -y git"] if has_apt
                else []
            ),
            "go": (
                ["winget install GoLang.Go --silent"] if has_winget
                else ["choco install golang -y"] if has_choco
                else ["brew install go"] if has_brew
                else ["apt-get install -y golang-go"] if has_apt
                else []
            ),
            "rustc": (
                ["winget install Rustlang.Rustup --silent"] if has_winget
                else ["choco install rust -y"] if has_choco
                else ["curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y"] if not is_win
                else []
            ),
            "docker": (
                ["winget install Docker.DockerDesktop --silent"] if has_winget
                else ["choco install docker-desktop -y"] if has_choco
                else ["brew install --cask docker"] if has_brew
                else ["apt-get install -y docker.io"] if has_apt
                else []
            ),
        }

        for tool in missing:
            cmds = tool_map.get(tool, [])
            for cmd in cmds:
                commands.append((tool, cmd))
                break

        return commands

    def _run_scaffolding(self, command: str) -> None:
        """Detect framework in the task and scaffold the project if needed.

        Skips scaffolding if the project is not empty or already has a
        recognised framework structure.
        """
        from . import ui
        from .scaffolder import scaffold

        # Skip if project already has files (scaffolding done by REPL or manually)
        project_files = list(Path.cwd().iterdir())
        non_hidden = [f for f in project_files if not f.name.startswith(".")]
        if non_hidden:
            return
        non_hidden = [f for f in project_files if not f.name.startswith(".")]
        if non_hidden:
            return

        result = scaffold(command, router=self._router)
        if result.error:
            c = ui.get_console()
            c.print(f"  [warning]⚠ Scaffolding issue: {result.error}[/]")

    # ------------------------------------------------------------------
    # Pipeline steps
    # ------------------------------------------------------------------

    # Complexity scores keyed by task type — avoids duplicating router keyword logic
    _TASK_TYPE_COMPLEXITY: dict[str, int] = {
        "build": 2,
        "fix": 2,
        "improve": 3,
        "design": 3,
        "general": 1,
    }

    # Extra bump for high-scope keywords that override the base task-type score
    _HIGH_SCOPE_KEYWORDS = frozenset([
        "fullstack", "complete", "entire", "whole system", "multi-page",
        "saas", "platform",
    ])

    def _analyze_input(self, command: str) -> tuple[str, int]:
        """Classify complexity using the router's existing keyword logic.

        Delegates to ``router.infer_task_type`` so keyword lists live in one
        place.  Only falls back to an API call when the task type is 'general'
        (truly ambiguous), and uses the cheaper executor model for that call.
        """
        lowered = command.lower()

        # High-scope override — these always warrant a full pipeline
        if any(kw in lowered for kw in self._HIGH_SCOPE_KEYWORDS):
            return command, 4

        task_type = self._router.infer_task_type(command)
        complexity = self._TASK_TYPE_COMPLEXITY.get(task_type, 1)

        # Only call the API for genuinely ambiguous inputs (task_type == 'general')
        # Use executor (cheap) not architect (expensive) — it's a 5-token classification
        if task_type == "general":
            system = "Classify this request in <=5 words. Return JSON only: {\"intent\": \"...\", \"complexity\": 1-5}"
            result = self._router.call_executor(system, command, max_tokens=64)
            if not self._is_error(result):
                try:
                    data = json.loads(_extract_json(result["text"]))
                    return data.get("intent", command), min(5, max(1, data.get("complexity", 1)))
                except (json.JSONDecodeError, ValueError, KeyError):
                    pass

        return command, complexity

    def _execute_simple(self, command: str, task_id: str) -> dict[str, Any]:
        """Simple classify → execute path with retry."""
        result: dict[str, Any] = {}
        for attempt in range(self._max_retries + 1):
            result = self._router.route(command, self._simple_system_prompt(), command)
            if not self._is_error(result):
                break
            if attempt < self._max_retries and self._is_retryable(result):
                time.sleep(1.0 * (attempt + 1))
            else:
                break

        model_used = result.get("provider", "deepseek") if not self._is_error(result) else "none"
        self._memory.log_decision(
            task_id, "execution", "direct", command,
            result.get("text", "")[:500] if not self._is_error(result) else str(result.get("error", ""))[:500],
            model_used,
        )
        return result



    def _get_project_context(self) -> str:
        """Get current project context from indexer."""
        try:
            from .indexer import ProjectIndexer
            indexer = ProjectIndexer()
            return indexer.context_for_ai()
        except Exception:
            return ""

    def _review_output(self, command: str, output: str) -> str:
        system = (
            "You are a code reviewer. Review the following execution output.\n"
            "Identify: (1) correctness issues, (2) missing features, (3) improvement suggestions.\n"
            "Be brief — 3 bullet points max."
        )
        result = self._router.call_architect(system, f"COMMAND: {command}\n\nOUTPUT:\n{output[:4000]}")
        return result.get("text", "") if not self._is_error(result) else ""

    def _consolidate_memory(self, task_id: str, command: str, output: str, review: str) -> None:
        self._memory.complete_task(task_id)
        key = f"last_output_{command[:50].replace(' ', '_')}"
        self._memory.set_knowledge(key, output[:2000])

    def _evolution_patch(self, task_id: str, command: str, complexity: int) -> dict[str, Any]:
        decisions = self._memory.task_decisions(task_id)
        report: dict[str, Any] = self._evolution.evaluate(task_id, decisions)

        all_successful = all(
            d.get("output_summary", "") and "error" not in str(d.get("output_summary", "")).lower()
            for d in decisions
        )
        total_ms = sum(d.get("latency_ms", 0) for d in decisions)
        role = self._router.classify(command)
        self._evolution.update(
            self._router.infer_task_type(command),
            role,
            all_successful,
            total_ms,
        )
        return report

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _extract_and_save(self, command: str, output: str) -> str:
        """Extract code blocks from output and save files mentioned in the command.

        Handles multiple code fence blocks, naming extras with _2, _3 suffixes.
        Path traversal is blocked — files must stay within the project root.
        """
        saved: list[str] = []
        target_match = re.search(r'(?i)save\s+to\s+(\S+)', command)
        base_path = target_match.group(1) if target_match else None

        if not base_path:
            return ""

        project_root = Path.cwd().resolve()
        requested = Path(base_path)
        requested = (project_root / requested).resolve() if not requested.is_absolute() else requested.resolve()

        try:
            requested.relative_to(project_root)
        except ValueError:
            logger.warning(
                "Path traversal blocked: %s is outside project root %s", requested, project_root
            )
            return ""

        p = requested
        base_stem = p.stem
        base_ext = p.suffix

        # Find all code fence positions
        fence_positions = [m.start() for m in re.finditer(r'```', output)]

        block_count = 0
        for i in range(0, len(fence_positions) - 1, 2):
            open_pos = fence_positions[i]
            close_pos = fence_positions[i + 1]

            after_open = output.find('\n', open_pos)
            if after_open == -1 or after_open >= close_pos:
                continue

            code = output[after_open + 1 : close_pos].strip()
            if len(code) < 10:
                continue

            block_count += 1
            file_path = str(p) if block_count == 1 else str(p.parent / f"{base_stem}_{block_count}{base_ext}")

            try:
                path = Path(file_path)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(code, encoding="utf-8")
                saved.append(str(path))
                self._validate_extracted_code(str(path), code)
            except OSError:
                continue

        # Fallback: no fences found, try raw output
        if not saved:
            code = output.strip()
            if len(code) >= 10:
                try:
                    path = p
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(code, encoding="utf-8")
                    saved.append(str(path))
                except OSError:
                    return ""

        if not saved:
            return ""

        return "Files saved:\n" + "\n".join(f"  → {s}" for s in saved)

    def _validate_extracted_code(self, file_path: str, code: str) -> None:
        """Basic syntax validation for extracted code. Logs warnings, never blocks."""
        ext = Path(file_path).suffix.lower()
        errors: list[str] = []
        if ext == ".py":
            try:
                compile(code, file_path, "exec")
            except SyntaxError as e:
                errors.append(f"Python syntax error: {e}")
        elif ext == ".json":
            try:
                json.loads(code)
            except json.JSONDecodeError as e:
                errors.append(f"JSON syntax error: {e}")

        for err in errors:
            logger.warning("Code extraction validation [%s]: %s", file_path, err)

    def _is_error(self, result: dict) -> bool:
        """Check if a router result dict represents an error."""
        return "error" in result

    def _is_retryable(self, result: dict) -> bool:
        """Only retry on transient errors, not permanent ones like missing API keys."""
        msg = result.get("error", "")
        non_retryable = {"API_KEY not set", "Incorrect API key", "Authentication failed", "invalid api key"}
        return not any(indicator.lower() in msg.lower() for indicator in non_retryable)

    def _simple_system_prompt(self) -> str:
        return (
            "You are WIDDX CLI, an AI coding agent.\n"
            "Rules: Use clear, readable code. Handle errors first.\n"
            "Use guard clauses. Functions=verbs, variables=nouns. No trivial comments.\n"
            "Design: 3-5 colors max. Mobile-first. Semantic HTML. No emoji icons. Real backend storage.\n"
            "Respond directly to the user's request."
        )


def _extract_json(text: str) -> str:
    """Extract JSON from LLM output using brace-depth tracking.

    Handles nested objects, multiple JSON blocks, fenced code blocks,
    inline backticks, and partial output without fragile regex splits.
    """
    import re

    # Strip markdown fenced code blocks, keeping the inner content
    cleaned = re.sub(
        r"```(?:json|javascript|python|yaml|toml)?\s*\n(.*?)\n\s*```",
        r"\1",
        text,
        flags=re.DOTALL,
    ).strip()
    # Also handle compact inline fences
    cleaned = re.sub(
        r"```(?:json)?\s*(.*?)\s*```",
        r"\1",
        cleaned,
        flags=re.DOTALL,
    ).strip()

    # Brace-depth tracking — find the outermost { ... } pair
    brace_stack: list[str] = []
    json_start = -1
    for i, ch in enumerate(cleaned):
        if ch == "{":
            if not brace_stack:
                json_start = i
            brace_stack.append(ch)
        elif ch == "}":
            if brace_stack:
                brace_stack.pop()
                if not brace_stack and json_start >= 0:
                    candidate = cleaned[json_start : i + 1]
                    if "{" in candidate and "}" in candidate:
                        return candidate

    # Fallback: array-depth tracking for [ ... ]
    bracket_stack: list[str] = []
    json_start = -1
    for i, ch in enumerate(cleaned):
        if ch == "[":
            if not bracket_stack:
                json_start = i
            bracket_stack.append(ch)
        elif ch == "]":
            if bracket_stack:
                bracket_stack.pop()
                if not bracket_stack and json_start >= 0:
                    return cleaned[json_start : i + 1]

    return cleaned
