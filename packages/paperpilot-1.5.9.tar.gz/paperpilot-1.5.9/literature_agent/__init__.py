"""AI literature search agent."""

__version__ = "1.5.9"
