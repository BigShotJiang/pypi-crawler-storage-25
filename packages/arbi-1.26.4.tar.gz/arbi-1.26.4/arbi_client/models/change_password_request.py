from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.change_password_request_rewrapped_agent_recovery_keys_type_0 import ChangePasswordRequestRewrappedAgentRecoveryKeysType0
  from ..models.change_password_request_rewrapped_workspace_keys import ChangePasswordRequestRewrappedWorkspaceKeys





T = TypeVar("T", bound="ChangePasswordRequest")



@_attrs_define
class ChangePasswordRequest:
    """ Password change request with signature-based auth.

    Self re-key (agent_ext_id omitted):
      Client proves knowledge of current password by signing "email|timestamp"
      with their own Ed25519 key.

    Agent re-key (agent_ext_id provided):
      Parent re-keys an agent's signing/encryption keys.  Parent proves authority
      by signing "agent_ext_id|timestamp" with their own Ed25519 key.
      rewrapped_workspace_keys must contain entries for the agent's workspaces,
      each wrapped with the agent's new X25519 public key.

        Attributes:
            signature (str):
            timestamp (int):
            new_signing_key (str):
            rewrapped_workspace_keys (ChangePasswordRequestRewrappedWorkspaceKeys):
            agent_ext_id (None | str | Unset):
            rewrapped_agent_recovery_keys (ChangePasswordRequestRewrappedAgentRecoveryKeysType0 | None | Unset):
     """

    signature: str
    timestamp: int
    new_signing_key: str
    rewrapped_workspace_keys: ChangePasswordRequestRewrappedWorkspaceKeys
    agent_ext_id: None | str | Unset = UNSET
    rewrapped_agent_recovery_keys: ChangePasswordRequestRewrappedAgentRecoveryKeysType0 | None | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.change_password_request_rewrapped_workspace_keys import ChangePasswordRequestRewrappedWorkspaceKeys
        from ..models.change_password_request_rewrapped_agent_recovery_keys_type_0 import ChangePasswordRequestRewrappedAgentRecoveryKeysType0
        signature = self.signature

        timestamp = self.timestamp

        new_signing_key = self.new_signing_key

        rewrapped_workspace_keys = self.rewrapped_workspace_keys.to_dict()

        agent_ext_id: None | str | Unset
        if isinstance(self.agent_ext_id, Unset):
            agent_ext_id = UNSET
        else:
            agent_ext_id = self.agent_ext_id

        rewrapped_agent_recovery_keys: dict[str, Any] | None | Unset
        if isinstance(self.rewrapped_agent_recovery_keys, Unset):
            rewrapped_agent_recovery_keys = UNSET
        elif isinstance(self.rewrapped_agent_recovery_keys, ChangePasswordRequestRewrappedAgentRecoveryKeysType0):
            rewrapped_agent_recovery_keys = self.rewrapped_agent_recovery_keys.to_dict()
        else:
            rewrapped_agent_recovery_keys = self.rewrapped_agent_recovery_keys


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "signature": signature,
            "timestamp": timestamp,
            "new_signing_key": new_signing_key,
            "rewrapped_workspace_keys": rewrapped_workspace_keys,
        })
        if agent_ext_id is not UNSET:
            field_dict["agent_ext_id"] = agent_ext_id
        if rewrapped_agent_recovery_keys is not UNSET:
            field_dict["rewrapped_agent_recovery_keys"] = rewrapped_agent_recovery_keys

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.change_password_request_rewrapped_agent_recovery_keys_type_0 import ChangePasswordRequestRewrappedAgentRecoveryKeysType0
        from ..models.change_password_request_rewrapped_workspace_keys import ChangePasswordRequestRewrappedWorkspaceKeys
        d = dict(src_dict)
        signature = d.pop("signature")

        timestamp = d.pop("timestamp")

        new_signing_key = d.pop("new_signing_key")

        rewrapped_workspace_keys = ChangePasswordRequestRewrappedWorkspaceKeys.from_dict(d.pop("rewrapped_workspace_keys"))




        def _parse_agent_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        agent_ext_id = _parse_agent_ext_id(d.pop("agent_ext_id", UNSET))


        def _parse_rewrapped_agent_recovery_keys(data: object) -> ChangePasswordRequestRewrappedAgentRecoveryKeysType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                rewrapped_agent_recovery_keys_type_0 = ChangePasswordRequestRewrappedAgentRecoveryKeysType0.from_dict(data)



                return rewrapped_agent_recovery_keys_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChangePasswordRequestRewrappedAgentRecoveryKeysType0 | None | Unset, data)

        rewrapped_agent_recovery_keys = _parse_rewrapped_agent_recovery_keys(d.pop("rewrapped_agent_recovery_keys", UNSET))


        change_password_request = cls(
            signature=signature,
            timestamp=timestamp,
            new_signing_key=new_signing_key,
            rewrapped_workspace_keys=rewrapped_workspace_keys,
            agent_ext_id=agent_ext_id,
            rewrapped_agent_recovery_keys=rewrapped_agent_recovery_keys,
        )

        return change_password_request

