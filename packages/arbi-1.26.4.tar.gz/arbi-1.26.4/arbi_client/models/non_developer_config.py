from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.agents_user_config import AgentsUserConfig
  from ..models.doctag_llm_user_config import DoctagLLMUserConfig
  from ..models.parser_user_config import ParserUserConfig





T = TypeVar("T", bound="NonDeveloperConfig")



@_attrs_define
class NonDeveloperConfig:
    """ 
        Attributes:
            agents (AgentsUserConfig):
            doctag_llm (DoctagLLMUserConfig):
            parser (ParserUserConfig):
     """

    agents: AgentsUserConfig
    doctag_llm: DoctagLLMUserConfig
    parser: ParserUserConfig
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.agents_user_config import AgentsUserConfig
        from ..models.doctag_llm_user_config import DoctagLLMUserConfig
        from ..models.parser_user_config import ParserUserConfig
        agents = self.agents.to_dict()

        doctag_llm = self.doctag_llm.to_dict()

        parser = self.parser.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "Agents": agents,
            "DoctagLLM": doctag_llm,
            "Parser": parser,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agents_user_config import AgentsUserConfig
        from ..models.doctag_llm_user_config import DoctagLLMUserConfig
        from ..models.parser_user_config import ParserUserConfig
        d = dict(src_dict)
        agents = AgentsUserConfig.from_dict(d.pop("Agents"))




        doctag_llm = DoctagLLMUserConfig.from_dict(d.pop("DoctagLLM"))




        parser = ParserUserConfig.from_dict(d.pop("Parser"))




        non_developer_config = cls(
            agents=agents,
            doctag_llm=doctag_llm,
            parser=parser,
        )


        non_developer_config.additional_properties = d
        return non_developer_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
