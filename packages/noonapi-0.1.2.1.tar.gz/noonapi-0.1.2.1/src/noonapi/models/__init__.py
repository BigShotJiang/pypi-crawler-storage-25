"""Typed SDK models."""
