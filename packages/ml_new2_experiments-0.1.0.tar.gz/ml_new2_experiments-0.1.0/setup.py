from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ml-new2-experiments",
    version="0.1.0",
    author="Vinith B",
    author_email="vinith@example.com",
    description="A collection of machine learning experiments from new2.ipynb",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/example/ml-new2-experiments",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=[
        "numpy",
        "pandas",
        "matplotlib",
        "scikit-learn",
        "seaborn"
    ],
)
