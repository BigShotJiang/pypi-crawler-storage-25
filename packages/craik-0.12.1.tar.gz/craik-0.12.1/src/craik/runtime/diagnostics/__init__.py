"""Runtime diagnostics helpers."""
