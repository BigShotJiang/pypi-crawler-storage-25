"""Adjacent runtime migration helpers."""

