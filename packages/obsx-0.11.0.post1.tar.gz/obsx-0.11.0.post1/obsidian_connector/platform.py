"""Platform abstraction layer for obsidian-connector.

Centralizes all OS-specific path resolution, scheduling, and
notification logic. Every other module imports from here instead
of hardcoding ~/Library/... or %APPDATA%\\... paths.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


def _strip_html(text: str) -> str:
    """Remove HTML tags to prevent markup injection in notification bodies."""
    return re.sub(r'<[^>]+>', '', text)


@dataclass(frozen=True)
class PlatformPaths:
    """Resolved paths for the current operating system."""

    obsidian_config: Path
    """Path to Obsidian's obsidian.json (vault registry)."""

    claude_config_dir: Path
    """Directory containing claude_desktop_config.json."""

    scheduler_dir: Path | None
    """Directory for scheduled job definitions (launchd/systemd/Task Scheduler)."""

    data_dir: Path
    """obsidian-connector data directory (~/.obsidian-connector)."""

    log_dir: Path
    """Audit log directory."""

    scheduler_type: str
    """Scheduling backend: 'launchd', 'systemd', 'task_scheduler', or 'none'."""


def get_platform_paths() -> PlatformPaths:
    """Resolve all platform-specific paths for the current OS."""
    home = Path.home()
    data_dir = home / ".obsidian-connector"
    log_dir = data_dir / "logs"

    if sys.platform == "darwin":
        return PlatformPaths(
            obsidian_config=home / "Library" / "Application Support" / "obsidian" / "obsidian.json",
            claude_config_dir=home / "Library" / "Application Support" / "Claude",
            scheduler_dir=home / "Library" / "LaunchAgents",
            data_dir=data_dir,
            log_dir=log_dir,
            scheduler_type="launchd",
        )
    elif sys.platform == "win32":
        appdata = Path(os.environ.get("APPDATA", home / "AppData" / "Roaming"))
        return PlatformPaths(
            obsidian_config=appdata / "obsidian" / "obsidian.json",
            claude_config_dir=appdata / "Claude",
            scheduler_dir=None,
            data_dir=data_dir,
            log_dir=log_dir,
            scheduler_type="task_scheduler",
        )
    else:
        # XDG spec: empty $XDG_CONFIG_HOME is treated as unset
        xdg_config = Path(os.environ.get("XDG_CONFIG_HOME") or (home / ".config"))
        return PlatformPaths(
            obsidian_config=xdg_config / "obsidian" / "obsidian.json",
            claude_config_dir=xdg_config / "Claude",
            scheduler_dir=xdg_config / "systemd" / "user",
            data_dir=data_dir,
            log_dir=log_dir,
            scheduler_type="systemd",
        )


# ------------------------------------------------------------------
# Backward-compatible convenience wrappers (used by existing code
# and referenced in cross-platform-plan docs).  New code should
# prefer ``get_platform_paths()`` directly.
# ------------------------------------------------------------------

def current_os() -> str:
    """Detect the current operating system.

    Returns one of: "macos", "linux", "windows".
    """
    if sys.platform == "darwin":
        return "macos"
    elif sys.platform.startswith("linux"):
        return "linux"
    elif sys.platform == "win32":
        return "windows"
    raise RuntimeError(f"Unsupported platform: {sys.platform}")


def claude_desktop_config_path() -> Path:
    """Return the path to Claude Desktop's config file."""
    paths = get_platform_paths()
    return paths.claude_config_dir / "claude_desktop_config.json"


def obsidian_app_json_path() -> Path:
    """Return the path to Obsidian's app-level config (obsidian.json)."""
    return get_platform_paths().obsidian_config


def default_index_db_path() -> Path:
    """Return the default path for the SQLite index database."""
    return Path.home() / ".obsidian-connector" / "index.sqlite"


def schedule_config_dir() -> Path:
    """Return the directory for scheduling configuration files."""
    paths = get_platform_paths()
    if paths.scheduler_dir is not None:
        return paths.scheduler_dir
    # Windows fallback -- Task Scheduler doesn't use a config dir.
    return Path.home() / ".obsidian-connector" / "tasks"


# ------------------------------------------------------------------
# Scheduling abstraction
# ------------------------------------------------------------------

def scheduler_type() -> str:
    """Return the scheduling backend for this OS."""
    return get_platform_paths().scheduler_type


def install_schedule(
    repo_root: Path,
    python_path: Path,
    workflow: str,
    time: str,
    dry_run: bool = False,
) -> dict:
    """Install a scheduled job for the given workflow.

    Parameters
    ----------
    repo_root: Path to the obsidian-connector repo.
    python_path: Path to the Python interpreter (venv).
    workflow: One of "morning", "evening", "weekly".
    time: 24h time string, e.g. "08:00".
    dry_run: If True, return plan without installing.

    Returns
    -------
    dict with keys: scheduler, job_name, workflow, time, dry_run, installed.
    """
    sched = scheduler_type()
    job_name = f"com.obsidian-connector.{workflow}"
    hour, minute = time.split(":")

    result = {
        "scheduler": sched,
        "job_name": job_name,
        "workflow": workflow,
        "time": time,
        "dry_run": dry_run,
        "installed": False,
    }

    if dry_run:
        return result

    if sched == "launchd":
        result["installed"] = _install_launchd(
            repo_root, python_path, workflow, int(hour), int(minute)
        )
    elif sched == "systemd":
        result["installed"] = _install_systemd(
            repo_root, python_path, workflow, int(hour), int(minute)
        )
    elif sched == "task_scheduler":
        result["installed"] = _install_task_scheduler(
            repo_root, python_path, workflow, time
        )

    return result


def uninstall_schedule(job_name: str) -> bool:
    """Remove a scheduled job by name. Returns True on success."""
    sched = scheduler_type()
    if sched == "launchd":
        return _uninstall_launchd(job_name)
    elif sched == "systemd":
        return _uninstall_systemd(job_name)
    elif sched == "task_scheduler":
        return _uninstall_task_scheduler(job_name)
    return False


# ------------------------------------------------------------------
# Private scheduling implementations (platform-specific)
# ------------------------------------------------------------------

def _install_launchd(
    repo_root: Path, python_path: Path, workflow: str, hour: int, minute: int
) -> bool:
    """Install a launchd plist for the given workflow (macOS)."""
    job_name = f"com.obsidian-connector.{workflow}"
    plist_dir = Path.home() / "Library" / "LaunchAgents"
    plist_dir.mkdir(parents=True, exist_ok=True)
    plist_path = plist_dir / f"{job_name}.plist"

    plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{job_name}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{python_path}</string>
        <string>{repo_root}/scheduling/run_scheduled.py</string>
        <string>{workflow}</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key>
        <integer>{hour}</integer>
        <key>Minute</key>
        <integer>{minute}</integer>
    </dict>
    <key>WorkingDirectory</key>
    <string>{repo_root}</string>
    <key>StandardErrorPath</key>
    <string>{repo_root}/logs/{workflow}-stderr.log</string>
    <key>StandardOutPath</key>
    <string>{repo_root}/logs/{workflow}-stdout.log</string>
</dict>
</plist>
"""
    try:
        plist_path.write_text(plist_content)
        subprocess.run(
            ["launchctl", "load", str(plist_path)],
            capture_output=True,
            check=True,
        )
        return True
    except (subprocess.CalledProcessError, OSError):
        return False


def _uninstall_launchd(job_name: str) -> bool:
    """Unload and remove a launchd plist (macOS)."""
    plist_dir = Path.home() / "Library" / "LaunchAgents"
    plist_path = plist_dir / f"{job_name}.plist"
    try:
        if plist_path.exists():
            subprocess.run(
                ["launchctl", "unload", str(plist_path)],
                capture_output=True,
                check=False,
            )
            plist_path.unlink()
        return True
    except (IOError, OSError):
        return False


def _generate_systemd_unit(
    repo_root: Path, python_path: Path, workflow: str, hour: int, minute: int
) -> tuple[str, str]:
    """Generate systemd .service and .timer unit file contents.

    Returns
    -------
    tuple[str, str]
        (service_content, timer_content)
    """
    service_name = f"obsidian-connector-{workflow}"
    service = f"""[Unit]
Description=obsidian-connector {workflow} workflow
After=graphical-session.target

[Service]
Type=oneshot
ExecStart={python_path} {repo_root}/scheduling/run_scheduled.py {workflow}
WorkingDirectory={repo_root}
Environment=PYTHONPATH={repo_root}

[Install]
WantedBy=default.target
"""
    timer = f"""[Unit]
Description=obsidian-connector {workflow} timer

[Timer]
OnCalendar=*-*-* {hour:02d}:{minute:02d}:00
Persistent=true

[Install]
WantedBy=timers.target
"""
    return service, timer


def _install_systemd(
    repo_root: Path, python_path: Path, workflow: str, hour: int, minute: int
) -> bool:
    """Install a systemd user timer for the given workflow (Linux)."""
    try:
        service_content, timer_content = _generate_systemd_unit(
            repo_root, python_path, workflow, hour, minute
        )
        unit_dir = Path.home() / ".config" / "systemd" / "user"
        unit_dir.mkdir(parents=True, exist_ok=True)

        service_name = f"obsidian-connector-{workflow}"
        (unit_dir / f"{service_name}.service").write_text(service_content)
        (unit_dir / f"{service_name}.timer").write_text(timer_content)

        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            capture_output=True, check=True,
        )
        subprocess.run(
            ["systemctl", "--user", "enable", "--now", f"{service_name}.timer"],
            capture_output=True, check=True,
        )
        return True
    except (subprocess.CalledProcessError, OSError):
        return False


def _uninstall_systemd(job_name: str) -> bool:
    """Disable and remove a systemd user timer and service (Linux)."""
    try:
        # Map from com.obsidian-connector.{workflow} to obsidian-connector-{workflow}
        service_name = job_name.replace("com.obsidian-connector.", "obsidian-connector-")
        subprocess.run(
            ["systemctl", "--user", "disable", "--now", f"{service_name}.timer"],
            capture_output=True, check=False,
        )
        unit_dir = Path.home() / ".config" / "systemd" / "user"
        for ext in (".service", ".timer"):
            unit_file = unit_dir / f"{service_name}{ext}"
            if unit_file.exists():
                unit_file.unlink()
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            capture_output=True, check=False,
        )
        return True
    except OSError:
        return False


# ------------------------------------------------------------------
# Notification abstraction
# ------------------------------------------------------------------

def send_notification(title: str, message: str) -> bool:
    """Send a desktop notification using the OS-native method.

    Returns True if the notification was dispatched, False on failure
    or unsupported platform. Never raises.
    """
    os_name = current_os()
    try:
        if os_name == "macos":
            # Sanitize for AppleScript string literals
            def _applescript_escape(s: str) -> str:
                return (s.replace("\\", "\\\\")
                         .replace('"', '\\"')
                         .replace("'", "\\'")
                         .replace("\n", "\\n")
                         .replace("\r", "\\r")
                         .replace("\t", "\\t"))
            safe_title = _applescript_escape(title)
            safe_msg = _applescript_escape(message)
            script = f'display notification "{safe_msg}" with title "{safe_title}"'
            result = subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                timeout=5,
            )
            return result.returncode == 0
        elif os_name == "linux":
            result = subprocess.run(
                ["notify-send", _strip_html(title), _strip_html(message)],
                capture_output=True,
                timeout=5,
            )
            return result.returncode == 0
        elif os_name == "windows":
            # Safely encode to avoid PowerShell injection
            import base64
            # Pass title/message via environment variables instead of string interpolation
            ps_script = (
                '$title = $env:OBSX_NOTIF_TITLE; '
                '$msg = $env:OBSX_NOTIF_MSG; '
                '[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null; '
                '$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02); '
                '$text = $template.GetElementsByTagName("text"); '
                '$text.Item(0).AppendChild($template.CreateTextNode($title)) > $null; '
                '$text.Item(1).AppendChild($template.CreateTextNode($msg)) > $null; '
                '$toast = [Windows.UI.Notifications.ToastNotification]::new($template); '
                '[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("obsidian-connector").Show($toast)'
            )
            env = os.environ.copy()
            env["OBSX_NOTIF_TITLE"] = title
            env["OBSX_NOTIF_MSG"] = message
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_script],
                capture_output=True,
                timeout=10,
                env=env,
            )
            return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False
    return False


def _generate_schtasks_command(
    repo_root: Path, python_path: Path, workflow: str, time: str
) -> list[str]:
    """Generate a schtasks /CREATE command for Windows Task Scheduler.

    Parameters
    ----------
    repo_root: Path to the obsidian-connector repo.
    python_path: Path to the Python interpreter (venv).
    workflow: One of "morning", "evening", "weekly".
    time: 24h time string, e.g. "08:00".

    Returns
    -------
    list[str]
        Command list suitable for subprocess.run().
    """
    task_name = f"obsidian-connector-{workflow}"
    script_path = repo_root / "scheduling" / "run_scheduled.py"
    return [
        "schtasks", "/CREATE",
        "/SC", "DAILY",
        "/TN", task_name,
        "/TR", f'"{python_path}" "{script_path}" {workflow}',
        "/ST", time,
        "/F",  # Force overwrite if exists
    ]


def _install_task_scheduler(
    repo_root: Path, python_path: Path, workflow: str, time: str
) -> bool:
    """Install a Windows Task Scheduler task for the given workflow."""
    try:
        cmd = _generate_schtasks_command(repo_root, python_path, workflow, time)
        result = subprocess.run(cmd, capture_output=True, check=True)
        return result.returncode == 0
    except (subprocess.CalledProcessError, OSError):
        return False


def _uninstall_task_scheduler(job_name: str) -> bool:
    """Remove a Windows Task Scheduler task."""
    try:
        # Convert com.obsidian-connector.X format to obsidian-connector-X
        task_name = job_name.replace("com.obsidian-connector.", "obsidian-connector-")
        result = subprocess.run(
            ["schtasks", "/DELETE", "/TN", task_name, "/F"],
            capture_output=True, check=False,
        )
        return result.returncode == 0
    except OSError:
        return False


# ------------------------------------------------------------------
# Process detection and binary resolution
# ------------------------------------------------------------------

def is_obsidian_running() -> bool:
    """Check if the Obsidian desktop app is currently running."""
    os_name = current_os()
    try:
        if os_name == "macos":
            result = subprocess.run(
                ["pgrep", "-x", "Obsidian"],
                capture_output=True, timeout=5,
            )
            return result.returncode == 0
        elif os_name == "linux":
            result = subprocess.run(
                ["pgrep", "-x", "obsidian"],
                capture_output=True, timeout=5,
            )
            return result.returncode == 0
        elif os_name == "windows":
            result = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq Obsidian.exe", "/NH"],
                capture_output=True, text=True, timeout=5,
            )
            return "Obsidian.exe" in result.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return False


def obsidian_binary_candidates() -> list[str]:
    """Return a list of candidate Obsidian CLI binary names/paths.

    Ordered by preference. The caller should try each until one works.
    """
    os_name = current_os()
    if os_name == "macos":
        return ["obsidian", "/Applications/Obsidian.app/Contents/MacOS/Obsidian"]
    elif os_name == "linux":
        candidates = ["obsidian"]
        # AppImage typically extracted or symlinked
        home = Path.home()
        appimage_paths = [
            home / "Applications" / "Obsidian.AppImage",
            home / ".local" / "bin" / "obsidian",
            Path("/usr/bin/obsidian"),
            Path("/usr/local/bin/obsidian"),
        ]
        for p in appimage_paths:
            if p.exists():
                candidates.insert(0, str(p))
        # Flatpak and Snap
        if shutil.which("flatpak"):
            candidates.append("flatpak run md.obsidian.Obsidian")
        if Path("/snap/obsidian/current").exists():
            candidates.append("/snap/obsidian/current/obsidian")
        return candidates
    elif os_name == "windows":
        # Windows has no CLI; return the desktop app path.
        appdata = os.environ.get("LOCALAPPDATA", "")
        if appdata:
            exe = Path(appdata) / "Obsidian" / "Obsidian.exe"
            if exe.exists():
                return [str(exe)]
        return ["Obsidian.exe"]


# ---------------------------------------------------------------------------
# v0.11 platform-reliability: filename-safe fragment helper
# ---------------------------------------------------------------------------

_WINDOWS_RESERVED_CHARS = '<>:"/\\|?*'
_CONTROL_CHARS = "".join(chr(c) for c in range(0x20))


def safe_filename_fragment(value: str, replacement: str = "-") -> str:
    """Strip Windows-reserved and control characters from a filename fragment.

    NTFS + FAT32 disallow ``<>:"/\\|?*`` and control chars (0x00-0x1F).
    Upstream Claude Code has historically written MCP server log filenames
    containing ISO timestamps with `:` separators, which crashes the
    subsequent open on Windows. Our own code never emits colons in
    filenames (see audit.py / telemetry.py), but this helper is exposed
    so future code, docs, and bug-report workarounds share one canonical
    scrubber.

    Parameters
    ----------
    value:
        Any string intended to be part of a filename.
    replacement:
        Character (or empty string) to substitute for each disallowed
        char. Defaults to ``"-"`` because it round-trips cleanly across
        POSIX and Windows shells.

    Returns
    -------
    str
        A version of ``value`` with every NTFS-reserved and control
        character replaced. Trailing whitespace and dots are also
        stripped because NTFS silently strips them on open (a surprise
        source of bugs when a later path comparison fails).

    Examples
    --------
    >>> safe_filename_fragment("2026-04-16T14:30:00")
    '2026-04-16T14-30-00'
    """
    if not isinstance(value, str):
        value = str(value)
    banned = set(_WINDOWS_RESERVED_CHARS) | set(_CONTROL_CHARS)
    out = "".join(replacement if ch in banned else ch for ch in value)
    return out.rstrip(" .") or replacement
    return ["obsidian"]
