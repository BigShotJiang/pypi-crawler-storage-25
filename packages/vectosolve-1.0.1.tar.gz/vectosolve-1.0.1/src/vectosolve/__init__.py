"""VectoSolve — AI-powered image vectorization, background removal, upscaling & SVG generation."""

from .client import VectoSolve
from .exceptions import (
    VectoSolveError,
    AuthenticationError,
    InsufficientCreditsError,
    RateLimitError,
    ValidationError,
    ServerError,
)
from .types import (
    VectorizeResult,
    RemoveBgResult,
    UpscaleResult,
    GenerateSvgResult,
    GenerateLogoResult,
    GeneratePatternResult,
    BatchResult,
    BatchItemResult,
    CreditsInfo,
)

__version__ = "1.0.1"
__all__ = [
    "VectoSolve",
    "VectoSolveError",
    "AuthenticationError",
    "InsufficientCreditsError",
    "RateLimitError",
    "ValidationError",
    "ServerError",
    "VectorizeResult",
    "RemoveBgResult",
    "UpscaleResult",
    "GenerateSvgResult",
    "GenerateLogoResult",
    "GeneratePatternResult",
    "BatchResult",
    "BatchItemResult",
    "CreditsInfo",
]
