"""Type definitions for VectoSolve API responses."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional


def _safe_write(path: str, content: str) -> None:
    """Write content to a file, rejecting path traversal attempts."""
    resolved = Path(path).resolve()
    if ".." in Path(path).parts:
        raise ValueError(f"Path traversal detected: {path}")
    with open(resolved, "w", encoding="utf-8") as f:
        f.write(content)


@dataclass(frozen=True)
class CreditsInfo:
    """Credit usage information returned with every API response."""
    used: float
    remaining: float


@dataclass(frozen=True)
class VectorizeResult:
    """Result from the vectorize endpoint."""
    svg: str
    svg_url: str
    processing_time_ms: int
    credits: CreditsInfo

    def save(self, path: str) -> None:
        """Save the SVG content to a file."""
        _safe_write(path, self.svg)


@dataclass(frozen=True)
class RemoveBgResult:
    """Result from the remove-background endpoint."""
    image_url: str
    processing_time_ms: int
    credits: CreditsInfo


@dataclass(frozen=True)
class UpscaleResult:
    """Result from the upscale endpoint."""
    image_url: str
    processing_time_ms: int
    credits: CreditsInfo


@dataclass(frozen=True)
class GenerateSvgResult:
    """Result from the generate-svg endpoint."""
    svg: str
    svg_url: str
    processing_time_ms: int
    credits: CreditsInfo

    def save(self, path: str) -> None:
        """Save the SVG content to a file."""
        _safe_write(path, self.svg)


@dataclass(frozen=True)
class LogoVariant:
    """A single logo variant."""
    svg_url: str
    svg: Optional[str]

    def save(self, path: str) -> None:
        """Save the SVG content to a file (if available)."""
        if self.svg is None:
            raise ValueError("SVG content not available for this variant")
        _safe_write(path, self.svg)


@dataclass(frozen=True)
class GenerateLogoResult:
    """Result from the generate-logo endpoint."""
    logos: List[LogoVariant]
    processing_time_ms: int
    credits: CreditsInfo

    def save(self, path: str, index: int = 0) -> None:
        """Save a logo variant to a file."""
        if index >= len(self.logos):
            raise IndexError(f"Logo index {index} out of range (got {len(self.logos)} variants)")
        self.logos[index].save(path)


@dataclass(frozen=True)
class GeneratePatternResult:
    """Result from the generate-pattern endpoint."""
    image_url: str
    processing_time_ms: int
    credits: CreditsInfo


@dataclass(frozen=True)
class BatchItemResult:
    """Result for a single image in a batch operation."""
    index: int
    success: bool
    operation: str
    url: Optional[str] = None
    error: Optional[str] = None


@dataclass(frozen=True)
class BatchResult:
    """Result from the batch endpoint."""
    results: List[BatchItemResult]
    total_processed: int
    total_failed: int
    processing_time_ms: int
    credits: CreditsInfo
