"""VectoSolve API client — secure, typed, zero data leaks."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Union

import httpx

from .exceptions import (
    AuthenticationError,
    InsufficientCreditsError,
    RateLimitError,
    ServerError,
    ValidationError,
    VectoSolveError,
)
from .types import (
    BatchItemResult,
    BatchResult,
    CreditsInfo,
    GenerateLogoResult,
    GeneratePatternResult,
    GenerateSvgResult,
    LogoVariant,
    RemoveBgResult,
    UpscaleResult,
    VectorizeResult,
)

_API_KEY_PATTERN = re.compile(r"^vs_[A-Za-z0-9_-]{20,50}$")
_BASE_URL = "https://vectosolve.com/api/v1"
_DEFAULT_TIMEOUT = 120.0
_MAX_PROMPT_LENGTH = 1000
_MAX_BATCH_SIZE = 10
_MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB
_MAX_RESPONSE_SIZE = 50 * 1024 * 1024  # 50 MB


def _mask_key(key: str) -> str:
    """Return a masked version of the API key for safe logging."""
    if len(key) <= 8:
        return "vs_****"
    return key[:6] + "****" + key[-4:]


class VectoSolve:
    """VectoSolve API client.

    Usage::

        from vectosolve import VectoSolve

        client = VectoSolve(api_key="vs_...")
        result = client.vectorize("photo.png")
        result.save("output.svg")

    The API key can also be set via the ``VECTOSOLVE_API_KEY`` environment variable.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        resolved_key = api_key or os.environ.get("VECTOSOLVE_API_KEY", "")
        if not resolved_key:
            raise AuthenticationError(
                "API key is required. Pass api_key= or set the VECTOSOLVE_API_KEY environment variable. "
                "Get your key at https://vectosolve.com/dashboard"
            )
        if not _API_KEY_PATTERN.match(resolved_key):
            raise AuthenticationError(
                f"Invalid API key format ({_mask_key(resolved_key)}). "
                "Keys start with 'vs_' followed by 20-50 alphanumeric characters."
            )

        resolved_base = (base_url or _BASE_URL).rstrip("/")
        if not resolved_base.startswith("https://"):
            raise ValidationError(
                "base_url must use HTTPS to protect your API key in transit. "
                f"Got: {resolved_base[:50]}"
            )

        self._api_key = resolved_key
        self._base_url = resolved_base
        self._timeout = timeout
        self._closed = False
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "User-Agent": "vectosolve-python/1.0.0",
                "Accept": "application/json",
            },
            timeout=httpx.Timeout(self._timeout),
            follow_redirects=False,
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._closed = True
        self._client.close()

    def __enter__(self) -> "VectoSolve":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __del__(self) -> None:
        if not getattr(self, "_closed", True):
            self._client.close()

    def __repr__(self) -> str:
        return f"VectoSolve(key={_mask_key(self._api_key)}, base_url={self._base_url!r})"

    # ── Internal helpers ──────────────────────────────────────────────

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Map HTTP error status codes to typed exceptions."""
        if response.is_success:
            return

        try:
            body = response.json()
        except Exception:
            body = {}

        error_msg = body.get("error", response.reason_phrase or "Unknown error")
        status = response.status_code

        if status == 401:
            raise AuthenticationError(error_msg)
        if status == 402:
            raise InsufficientCreditsError(error_msg, required=body.get("required", 0))
        if status == 429:
            try:
                retry_after = int(response.headers.get("retry-after", "0"))
            except (ValueError, TypeError):
                retry_after = 0
            raise RateLimitError(error_msg, retry_after=retry_after)
        if status == 400:
            raise ValidationError(error_msg)
        if status >= 500:
            raise ServerError(error_msg)
        raise VectoSolveError(error_msg, status_code=status)

    def _safe_parse_json(self, response: httpx.Response) -> Dict[str, Any]:
        """Parse JSON response with size guard against memory exhaustion."""
        content_length = response.headers.get("content-length")
        if content_length and int(content_length) > _MAX_RESPONSE_SIZE:
            raise VectoSolveError(
                f"Response too large ({int(content_length)} bytes, max {_MAX_RESPONSE_SIZE})",
                status_code=response.status_code,
            )
        raw = response.content
        if len(raw) > _MAX_RESPONSE_SIZE:
            raise VectoSolveError(
                f"Response too large ({len(raw)} bytes, max {_MAX_RESPONSE_SIZE})",
                status_code=response.status_code,
            )
        return response.json()

    def _post_json(self, endpoint: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Send a JSON POST request and return the parsed response."""
        response = self._client.post(endpoint, json=payload)
        self._raise_for_status(response)
        return self._safe_parse_json(response)

    def _post_file(self, endpoint: str, file_path: str, extra_fields: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Upload a file via multipart POST and return the parsed response."""
        path = Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"File not found: {file_path}")

        file_size = path.stat().st_size
        if file_size > _MAX_FILE_SIZE:
            raise ValidationError(
                f"File too large ({file_size // (1024*1024)} MB, max {_MAX_FILE_SIZE // (1024*1024)} MB)"
            )

        # Read file content into memory (don't hold file handle open during network I/O)
        content = path.read_bytes()
        files = {"file": (path.name, content, "application/octet-stream")}
        data = extra_fields or {}

        response = self._client.post(endpoint, files=files, data=data)
        self._raise_for_status(response)
        return self._safe_parse_json(response)

    @staticmethod
    def _parse_credits(data: Dict[str, Any]) -> CreditsInfo:
        credits = data.get("credits", {})
        return CreditsInfo(used=credits.get("used", 0), remaining=credits.get("remaining", 0))

    # ── Public API ────────────────────────────────────────────────────

    def vectorize(self, image: str) -> VectorizeResult:
        """Convert a raster image to SVG.

        Args:
            image: Local file path or public URL of the image to vectorize.

        Returns:
            VectorizeResult with SVG content and metadata.
        """
        if image.startswith(("http://", "https://")):
            body = self._post_json("/vectorize", {"url": image})
        else:
            body = self._post_file("/vectorize", image)

        data = body.get("data", {})
        return VectorizeResult(
            svg=data.get("svg", ""),
            svg_url=data.get("svg_url", ""),
            processing_time_ms=data.get("processing_time_ms", 0),
            credits=self._parse_credits(body),
        )

    def remove_background(self, image: str) -> RemoveBgResult:
        """Remove the background from an image.

        Args:
            image: Local file path or public URL.

        Returns:
            RemoveBgResult with the processed image URL.
        """
        if image.startswith(("http://", "https://")):
            body = self._post_json("/remove-bg", {"url": image})
        else:
            body = self._post_file("/remove-bg", image)

        data = body.get("data", {})
        return RemoveBgResult(
            image_url=data.get("image_url", data.get("url", "")),
            processing_time_ms=data.get("processing_time_ms", 0),
            credits=self._parse_credits(body),
        )

    def upscale(self, image: str) -> UpscaleResult:
        """Upscale an image using AI.

        Args:
            image: Local file path or public URL.

        Returns:
            UpscaleResult with the upscaled image URL.
        """
        if image.startswith(("http://", "https://")):
            body = self._post_json("/upscale", {"url": image})
        else:
            body = self._post_file("/upscale", image)

        data = body.get("data", {})
        return UpscaleResult(
            image_url=data.get("image_url", data.get("url", "")),
            processing_time_ms=data.get("processing_time_ms", 0),
            credits=self._parse_credits(body),
        )

    def generate_svg(
        self,
        prompt: str,
        *,
        style: str = "vector_illustration",
        size: str = "1024x1024",
        colors: Optional[List[str]] = None,
    ) -> GenerateSvgResult:
        """Generate an SVG from a text prompt.

        Args:
            prompt: Description of the image to generate (3-1000 chars).
            style: Art style (default: "vector_illustration").
            size: Output size ("1024x1024", "1024x1536", or "1536x1024").
            colors: Optional list of hex colors (e.g. ["#ff0000", "#00ff00"]).

        Returns:
            GenerateSvgResult with SVG content and metadata.
        """
        if not prompt or len(prompt.strip()) < 3:
            raise ValidationError("Prompt must be at least 3 characters")
        if len(prompt) > _MAX_PROMPT_LENGTH:
            raise ValidationError(f"Prompt exceeds maximum length of {_MAX_PROMPT_LENGTH} characters")

        payload: Dict[str, Any] = {"prompt": prompt.strip(), "style": style, "size": size}
        if colors:
            payload["colors"] = colors[:5]

        body = self._post_json("/generate-svg", payload)
        data = body.get("data", {})
        return GenerateSvgResult(
            svg=data.get("svg", ""),
            svg_url=data.get("svg_url", ""),
            processing_time_ms=data.get("processing_time_ms", 0),
            credits=self._parse_credits(body),
        )

    def generate_logo(
        self,
        prompt: str,
        *,
        style: str = "vector_illustration",
        model: str = "v3",
        num_variants: int = 1,
        colors: Optional[List[str]] = None,
    ) -> GenerateLogoResult:
        """Generate logo variants from a text prompt.

        Args:
            prompt: Description of the logo (3-500 chars).
            style: Art style (default: "vector_illustration").
            model: "v3" (higher quality, $0.40) or "v2" ($0.25).
            num_variants: Number of variants (1, 2, or 4).
            colors: Optional list of hex colors.

        Returns:
            GenerateLogoResult with logo SVGs and metadata.
        """
        if not prompt or len(prompt.strip()) < 3:
            raise ValidationError("Prompt must be at least 3 characters")
        if len(prompt) > 500:
            raise ValidationError("Prompt exceeds maximum length of 500 characters")
        if num_variants not in (1, 2, 4):
            raise ValidationError("num_variants must be 1, 2, or 4")

        payload: Dict[str, Any] = {
            "prompt": prompt.strip(),
            "style": style,
            "model": model,
            "num_variants": num_variants,
        }
        if colors:
            payload["colors"] = colors[:5]

        body = self._post_json("/generate-logo", payload)
        data = body.get("data", {})

        logos = [
            LogoVariant(svg_url=logo.get("svg_url", ""), svg=logo.get("svg"))
            for logo in data.get("logos", [])
        ]

        return GenerateLogoResult(
            logos=logos,
            processing_time_ms=data.get("processing_time_ms", 0),
            credits=self._parse_credits(body),
        )

    def generate_pattern(
        self,
        prompt: str,
        *,
        style: str = "vector_illustration",
        colors: Optional[List[str]] = None,
    ) -> GeneratePatternResult:
        """Generate a seamless tileable pattern.

        Args:
            prompt: Description of the pattern (3-1000 chars).
            style: Art style.
            colors: Optional list of hex colors.

        Returns:
            GeneratePatternResult with image URL and metadata.
        """
        if not prompt or len(prompt.strip()) < 3:
            raise ValidationError("Prompt must be at least 3 characters")
        if len(prompt) > _MAX_PROMPT_LENGTH:
            raise ValidationError(f"Prompt exceeds maximum length of {_MAX_PROMPT_LENGTH} characters")

        payload: Dict[str, Any] = {"prompt": prompt.strip(), "style": style}
        if colors:
            payload["colors"] = colors[:5]

        body = self._post_json("/generate-pattern", payload)
        data = body.get("data", {})
        return GeneratePatternResult(
            image_url=data.get("image_url", ""),
            processing_time_ms=data.get("processing_time_ms", 0),
            credits=self._parse_credits(body),
        )

    def batch(
        self,
        images: Sequence[Dict[str, str]],
    ) -> BatchResult:
        """Process multiple images in a single request.

        Args:
            images: List of dicts with "url" and "operation" keys.
                    Operations: "vectorize", "remove_bg", "upscale".
                    Max 10 images per batch.

        Example::

            results = client.batch([
                {"url": "https://example.com/photo1.png", "operation": "vectorize"},
                {"url": "https://example.com/photo2.jpg", "operation": "remove_bg"},
            ])

        Returns:
            BatchResult with per-image results and metadata.
        """
        if not images:
            raise ValidationError("At least one image is required")
        if len(images) > _MAX_BATCH_SIZE:
            raise ValidationError(f"Batch size exceeds maximum of {_MAX_BATCH_SIZE} images")

        valid_ops = {"vectorize", "remove_bg", "upscale"}
        for i, img in enumerate(images):
            if "url" not in img or not isinstance(img["url"], str):
                raise ValidationError(f"Image at index {i} is missing a valid 'url'")
            if not img["url"].startswith("https://"):
                raise ValidationError(f"Image at index {i}: URL must use HTTPS")
            if "operation" not in img or img["operation"] not in valid_ops:
                raise ValidationError(
                    f"Image at index {i} has invalid 'operation'. Must be one of: {', '.join(sorted(valid_ops))}"
                )

        body = self._post_json("/batch", {"images": list(images)})
        data = body.get("data", {})

        results = [
            BatchItemResult(
                index=r.get("index", i),
                success=r.get("success", False),
                operation=r.get("operation", ""),
                url=r.get("url"),
                error=r.get("error"),
            )
            for i, r in enumerate(data.get("results", []))
        ]

        return BatchResult(
            results=results,
            total_processed=data.get("total_processed", 0),
            total_failed=data.get("total_failed", 0),
            processing_time_ms=data.get("processing_time_ms", 0),
            credits=self._parse_credits(body),
        )
