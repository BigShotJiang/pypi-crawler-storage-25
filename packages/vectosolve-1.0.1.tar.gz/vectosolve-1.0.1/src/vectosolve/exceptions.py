"""Exception hierarchy for VectoSolve SDK."""


class VectoSolveError(Exception):
    """Base exception for all VectoSolve errors."""

    def __init__(self, message: str, status_code: int = 0) -> None:
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class AuthenticationError(VectoSolveError):
    """Raised when API key is invalid or missing (HTTP 401)."""

    def __init__(self, message: str = "Invalid or missing API key") -> None:
        super().__init__(message, status_code=401)


class InsufficientCreditsError(VectoSolveError):
    """Raised when account has insufficient credits (HTTP 402)."""

    def __init__(self, message: str = "Insufficient credits", required: float = 0) -> None:
        self.required = required
        super().__init__(message, status_code=402)


class RateLimitError(VectoSolveError):
    """Raised when rate limit is exceeded (HTTP 429)."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = 0) -> None:
        self.retry_after = retry_after
        super().__init__(message, status_code=429)


class ValidationError(VectoSolveError):
    """Raised for invalid request parameters (HTTP 400)."""

    def __init__(self, message: str = "Invalid request") -> None:
        super().__init__(message, status_code=400)


class ServerError(VectoSolveError):
    """Raised for server-side errors (HTTP 5xx)."""

    def __init__(self, message: str = "Internal server error") -> None:
        super().__init__(message, status_code=500)
