"""Tests for VectoSolve client — security, validation, error handling."""

import os
import tempfile
import pytest
from unittest.mock import patch

from vectosolve import VectoSolve, AuthenticationError, ValidationError
from vectosolve.types import _safe_write


class TestApiKeySecurity:
    """Ensure API key handling is airtight."""

    def test_missing_key_raises(self):
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("VECTOSOLVE_API_KEY", None)
            with pytest.raises(AuthenticationError, match="API key is required"):
                VectoSolve()

    def test_invalid_format_raises(self):
        with pytest.raises(AuthenticationError, match="Invalid API key format"):
            VectoSolve(api_key="bad_key_123")

    def test_short_key_raises(self):
        with pytest.raises(AuthenticationError, match="Invalid API key format"):
            VectoSolve(api_key="vs_short")

    def test_valid_key_accepted(self):
        key = "vs_" + "a" * 24
        client = VectoSolve(api_key=key)
        assert client is not None
        client.close()

    def test_key_from_env(self):
        key = "vs_" + "b" * 24
        with patch.dict(os.environ, {"VECTOSOLVE_API_KEY": key}):
            client = VectoSolve()
            assert client is not None
            client.close()

    def test_repr_masks_key(self):
        key = "vs_" + "c" * 24
        client = VectoSolve(api_key=key)
        repr_str = repr(client)
        assert key not in repr_str
        assert "vs_ccc" in repr_str
        assert "****" in repr_str
        client.close()

    def test_key_not_in_str(self):
        key = "vs_" + "d" * 24
        client = VectoSolve(api_key=key)
        assert key not in str(client)
        client.close()

    def test_crlf_injection_blocked(self):
        """API key with CRLF characters must be rejected by regex."""
        with pytest.raises(AuthenticationError, match="Invalid API key format"):
            VectoSolve(api_key="vs_aaaa\r\nEvil: header\r\naaaaa")


class TestBaseUrlSecurity:
    """Ensure base_url only accepts HTTPS."""

    def test_http_base_url_rejected(self):
        key = "vs_" + "a" * 24
        with pytest.raises(ValidationError, match="HTTPS"):
            VectoSolve(api_key=key, base_url="http://evil.com/api/v1")

    def test_https_base_url_accepted(self):
        key = "vs_" + "a" * 24
        client = VectoSolve(api_key=key, base_url="https://custom.vectosolve.com/api/v1")
        assert client is not None
        client.close()

    def test_internal_ip_with_http_rejected(self):
        key = "vs_" + "a" * 24
        with pytest.raises(ValidationError, match="HTTPS"):
            VectoSolve(api_key=key, base_url="http://169.254.169.254/latest/meta-data/")


class TestInputValidation:
    """Test client-side validation catches bad inputs early."""

    @pytest.fixture
    def client(self):
        c = VectoSolve(api_key="vs_" + "x" * 24)
        yield c
        c.close()

    def test_generate_svg_empty_prompt(self, client):
        with pytest.raises(ValidationError, match="at least 3 characters"):
            client.generate_svg("")

    def test_generate_svg_short_prompt(self, client):
        with pytest.raises(ValidationError, match="at least 3 characters"):
            client.generate_svg("ab")

    def test_generate_svg_long_prompt(self, client):
        with pytest.raises(ValidationError, match="maximum length"):
            client.generate_svg("x" * 1001)

    def test_generate_logo_long_prompt(self, client):
        with pytest.raises(ValidationError, match="maximum length"):
            client.generate_logo("x" * 501)

    def test_generate_logo_bad_variants(self, client):
        with pytest.raises(ValidationError, match="num_variants"):
            client.generate_logo("test logo", num_variants=3)

    def test_batch_empty(self, client):
        with pytest.raises(ValidationError, match="At least one"):
            client.batch([])

    def test_batch_too_large(self, client):
        images = [{"url": f"https://example.com/{i}.png", "operation": "vectorize"} for i in range(11)]
        with pytest.raises(ValidationError, match="maximum"):
            client.batch(images)

    def test_batch_invalid_operation(self, client):
        with pytest.raises(ValidationError, match="invalid 'operation'"):
            client.batch([{"url": "https://example.com/1.png", "operation": "hack"}])

    def test_batch_missing_url(self, client):
        with pytest.raises(ValidationError, match="missing a valid 'url'"):
            client.batch([{"operation": "vectorize"}])

    def test_batch_http_url_rejected(self, client):
        """Batch URLs must use HTTPS — block plaintext HTTP."""
        with pytest.raises(ValidationError, match="HTTPS"):
            client.batch([{"url": "http://example.com/1.png", "operation": "vectorize"}])

    def test_batch_valid_https_url_passes_validation(self, client):
        """Valid HTTPS URL passes client-side validation (server will reject fake key)."""
        from vectosolve import AuthenticationError
        with pytest.raises((AuthenticationError, Exception)):
            client.batch([{"url": "https://example.com/1.png", "operation": "vectorize"}])


class TestPathTraversal:
    """Ensure save() methods reject path traversal attacks."""

    def test_safe_write_rejects_dotdot(self):
        with pytest.raises(ValueError, match="Path traversal"):
            _safe_write("../../etc/cron.d/evil", "<svg></svg>")

    def test_safe_write_rejects_nested_dotdot(self):
        with pytest.raises(ValueError, match="Path traversal"):
            _safe_write("output/../../../etc/passwd", "<svg></svg>")

    def test_safe_write_accepts_normal_path(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "output.svg")
            _safe_write(path, "<svg></svg>")
            with open(path, "r") as f:
                assert f.read() == "<svg></svg>"

    def test_safe_write_accepts_relative_path(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "subdir_test.svg")
            _safe_write(path, "<svg>test</svg>")
            with open(path, "r") as f:
                assert f.read() == "<svg>test</svg>"


class TestFileSizeLimit:
    """Ensure _post_file rejects oversized files."""

    @pytest.fixture
    def client(self):
        c = VectoSolve(api_key="vs_" + "x" * 24)
        yield c
        c.close()

    def test_missing_file_raises(self, client):
        with pytest.raises(FileNotFoundError):
            client.vectorize("/nonexistent/path/to/image.png")


class TestContextManager:
    def test_with_statement(self):
        key = "vs_" + "e" * 24
        with VectoSolve(api_key=key) as client:
            assert client is not None

    def test_del_doesnt_crash(self):
        key = "vs_" + "f" * 24
        client = VectoSolve(api_key=key)
        del client  # Should not raise
