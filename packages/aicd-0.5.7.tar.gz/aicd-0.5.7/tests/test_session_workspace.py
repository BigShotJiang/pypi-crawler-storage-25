"""session_workspace：默认 TUI 工作区目录与 /workspaces 维护逻辑。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from aicd.runtime import build_runtime
from aicd.session_workspace import (
    clear_managed_workspaces_except,
    create_session_workspace,
    list_managed_workspaces,
    new_stamped_workspace_name,
)


def test_new_stamped_workspace_name_format() -> None:
    s = new_stamped_workspace_name()
    assert s.startswith("workspace_")
    assert len(s) == len("workspace_") + 14


def test_create_session_workspace_under_container(tmp_path: Path) -> None:
    p = create_session_workspace(tmp_path / "nest")
    assert p.is_dir()
    assert p.parent.name == "nest"
    assert p.name.startswith("workspace_")


def test_list_and_clear_managed(tmp_path: Path) -> None:
    home = tmp_path / "home"
    root = home / "workspaces"
    root.mkdir(parents=True)
    a = root / "workspace_20990101120000"
    b = root / "workspace_20990101120001"
    skip = root / "other"
    a.mkdir()
    b.mkdir()
    skip.mkdir()
    assert list_managed_workspaces(home) == [a.resolve(), b.resolve()]
    n, deleted = clear_managed_workspaces_except(home, a)
    assert n == 1
    assert deleted == [str(b.resolve())]
    assert a.is_dir()
    assert not b.exists()
    assert skip.is_dir()


def test_list_ignores_bad_names(tmp_path: Path) -> None:
    home = tmp_path / "h"
    root = home / "workspaces"
    root.mkdir(parents=True)
    (root / "workspace_123").mkdir()
    (root / "workspace_20990101120000").mkdir()
    items = list_managed_workspaces(home)
    assert len(items) == 1
    assert items[0].name == "workspace_20990101120000"


def test_build_runtime_uses_initial_ai_workspace(tmp_path: Path) -> None:
    ws = tmp_path / "my_ws"
    ws.mkdir()

    async def _go() -> None:
        ctx = await build_runtime(
            home=tmp_path / "aicd_home",
            skip_first_setup=True,
            setup_tty_relaxed=True,
            initial_ai_workspace=ws,
        )
        assert ctx.workspace_cwd.resolve() == ws.resolve()
        await ctx.shutdown_graceful()

    asyncio.run(_go())
