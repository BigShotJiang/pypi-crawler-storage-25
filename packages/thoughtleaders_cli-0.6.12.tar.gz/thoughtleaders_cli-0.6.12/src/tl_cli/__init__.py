"""ThoughtLeaders CLI — query sponsorship data, channels, brands, and intelligence."""

__version__ = "0.6.12"
