import logging
import re

import duckdb

from mcard.config.settings import settings
from mcard.engine.abstract_sql_engine import AbstractSqlEngine
from mcard.engine.base import DatabaseConnection, resolve_db_path
from mcard.model.card import MCard
from mcard.model.pagination import Page

DEFAULT_PAGE_SIZE = settings.pagination.default_page_size

logger = logging.getLogger(__name__)


def _convert_placeholders(sql: str) -> str:
    """Convert ``?`` placeholders to DuckDB's ``$1, $2, ...`` syntax."""
    counter = 0

    def _replacer(match):
        nonlocal counter
        counter += 1
        return f"${counter}"

    return re.sub(r"\?", _replacer, sql)


class DuckDBConnection(DatabaseConnection):
    """Database connection for DuckDB -- an embedded columnar OLAP database.

    This mirrors SQLiteConnection but targets DuckDB, which excels at
    analytical queries, Parquet I/O, and columnar scans.  It provides
    a drop-in alternative engine behind the same StorageEngine interface.
    """

    def __init__(self, db_path: str):
        self.db_path = resolve_db_path(db_path)
        self.conn: duckdb.DuckDBPyConnection | None = None

    def connect(self):
        """Open the DuckDB connection and initialise schema."""
        logger.debug(f"Connecting to DuckDB at {self.db_path}")
        try:
            self.conn = duckdb.connect(self.db_path)
            logger.debug(f"Connection established to {self.db_path}")

            # Check if the card table exists
            result = self.conn.execute(
                "SELECT COUNT(*) FROM information_schema.tables "
                "WHERE table_name = 'card'"
            ).fetchone()

            if result[0] == 0:
                logger.debug(f"Creating new database schema at {self.db_path}")
                self._create_schema()
                logger.debug("Database schema created successfully")
            else:
                logger.debug(f"Using existing database at {self.db_path}")

        except duckdb.Error as e:
            logger.error(
                f"Database error connecting to {self.db_path}: {e}", exc_info=True
            )
            raise

    # =====================================================================
    # Single Source of Truth: Schema files
    # =====================================================================
    # The DuckDB engine does NOT define its own schema.  It loads all
    # table / index definitions from the canonical SQL files via the
    # MCardSchema singleton and applies only dialect-level transforms.
    #
    # Canonical source files:
    #   schema/mcard_schema.sql         (REQUIRED -- core tables)
    #   schema/mcard_vector_schema.sql  (optional -- vector/graph tables)
    #
    # If a new table is added to either file, this engine picks it up
    # automatically.  No hardcoded CREATE TABLE statements should ever
    # appear in this file.
    # =====================================================================

    SCHEMA_SOURCE_FILES = (
        "schema/mcard_schema.sql",  # Required -- core tables
        "schema/mcard_vector_schema.sql",  # Optional -- vector/graph tables
    )

    def _create_schema(self):
        """Create the MCard schema by loading from the canonical SQL files
        and applying DuckDB-specific transformations.

        The schema is loaded via ``MCardSchema`` (which reads
        ``schema/mcard_schema.sql`` and ``schema/mcard_vector_schema.sql``)
        so that this engine stays in sync with the single source of truth.

        DuckDB-specific overrides applied by ``_adapt_statement_for_duckdb``:
        1. Skip ``CREATE VIRTUAL TABLE ... USING fts5(...)`` (unsupported)
        2. ``INTEGER PRIMARY KEY AUTOINCREMENT`` -> sequence + ``nextval()``
        3. ``TEXT`` -> ``VARCHAR``  (DuckDB preference)
        4. Remove FK constraints from ``handle_history`` (DuckDB enforces
           FKs on UPDATE which blocks handle pointer updates)
        5. ``datetime('now')`` -> ``CURRENT_TIMESTAMP``

        Raises:
            FileNotFoundError: if the required core schema SQL file is missing.
            RuntimeError: if no CREATE statements are loaded from the schema.
        """
        from mcard.schema import MCardSchema, _find_schema_path

        # Validate that the canonical schema file exists (raises FileNotFoundError)
        schema_path = _find_schema_path()
        logger.debug(f"DuckDB schema loading from canonical source: {schema_path}")

        schema = MCardSchema.get_instance()
        statements = schema.get_all_statements()

        if not statements:
            raise RuntimeError(
                "No CREATE statements loaded from MCardSchema. "
                f"Ensure {self.SCHEMA_SOURCE_FILES[0]} contains valid SQL."
            )
        logger.debug(
            f"Loaded {len(statements)} schema statements from canonical SQL files"
        )

        sequences_created: set[str] = set()

        for stmt in statements:
            result = self._adapt_statement_for_duckdb(stmt, sequences_created)
            if result is None:
                # Statement should be skipped (e.g. FTS5 virtual table)
                continue
            seq_name, adapted_sql = result
            # Create the sequence if this table needs one (AUTOINCREMENT)
            if seq_name and seq_name not in sequences_created:
                self.conn.execute(f"CREATE SEQUENCE IF NOT EXISTS {seq_name} START 1")
                sequences_created.add(seq_name)
            self.conn.execute(adapted_sql)

        # Seed schema_version if not already present
        self.conn.execute(
            """
            INSERT INTO schema_version (version, applied_at, description)
            SELECT '3.0.0', CURRENT_TIMESTAMP, 'DuckDB Monadic Core Schema'
            WHERE NOT EXISTS (
                SELECT 1 FROM schema_version WHERE version = '3.0.0'
            )
        """
        )

    @staticmethod
    def _adapt_statement_for_duckdb(stmt, sequences_created):
        """Transform a single SQLite CREATE statement for DuckDB.

        Returns:
            ``None`` if the statement should be skipped entirely.
            A tuple ``(seq_name, sql)`` where *seq_name* is the sequence
            name to create (or ``None`` if no sequence is needed) and
            *sql* is the adapted DuckDB-compatible statement.
        """
        upper = stmt.upper()

        # -- Skip unsupported constructs ---------------------------------
        # FTS5 / vec0 virtual tables are SQLite-specific extensions
        if "USING FTS5" in upper or "USING VEC0" in upper:
            return None
        # INSERT statements are already filtered by MCardSchema, but guard
        if upper.strip().startswith("INSERT"):
            return None

        seq_name = None

        # -- AUTOINCREMENT -> sequence + nextval -------------------------
        autoincrement_re = re.compile(
            r"(\w+)\s+INTEGER\s+PRIMARY\s+KEY\s+AUTOINCREMENT",
            re.IGNORECASE,
        )
        match = autoincrement_re.search(stmt)
        if match:
            col_name = match.group(1)
            # Derive sequence name from the table name
            table_match = re.search(
                r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)",
                stmt,
                re.IGNORECASE,
            )
            table_name = table_match.group(1) if table_match else "unnamed"
            seq_name = f"{table_name}_seq"
            replacement = (
                f"{col_name} INTEGER PRIMARY KEY DEFAULT nextval('{seq_name}')"
            )
            stmt = autoincrement_re.sub(replacement, stmt)

        # -- TEXT -> VARCHAR ---------------------------------------------
        stmt = re.sub(r"\bTEXT\b", "VARCHAR", stmt, flags=re.IGNORECASE)

        # -- Remove FK constraints from handle_history -------------------
        # DuckDB enforces FK constraints on UPDATE (not just DELETE),
        # which blocks updating handle_registry.current_hash when
        # handle_history references the handle.  Integrity is
        # maintained at the application layer instead.
        if re.search(
            r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?handle_history\b",
            stmt,
            re.IGNORECASE,
        ):
            stmt = re.sub(
                r",\s*FOREIGN\s+KEY\s*\([^)]+\)\s*REFERENCES\s+\w+\s*\([^)]+\)",
                "",
                stmt,
                flags=re.IGNORECASE,
            )

        # -- datetime('now') -> CURRENT_TIMESTAMP ------------------------
        stmt = stmt.replace("datetime('now')", "CURRENT_TIMESTAMP")

        return (seq_name, stmt)

    # =====================================================================
    # Connection lifecycle
    # =====================================================================

    def disconnect(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def commit(self):
        # DuckDB auto-commits by default; explicit commit for consistency
        if self.conn:
            self.conn.commit()

    def rollback(self):
        if self.conn:
            self.conn.rollback()


class DuckDBEngine(AbstractSqlEngine):
    """Storage engine implementation using DuckDB.

    Provides the same StorageEngine interface as SQLiteEngine but uses
    DuckDB as the underlying database.  DuckDB excels at columnar scans,
    analytical queries, and cross-format I/O (Parquet, CSV, JSON).
    """

    def __init__(self, connection: DuckDBConnection):
        self.connection = connection
        self.connection.connect()

    def __del__(self):
        self.connection.disconnect()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.connection.disconnect()
        return False

    # =====================================================================
    # AbstractSqlEngine primitives
    # =====================================================================

    def _query_rows(self, sql: str, params: tuple = ()) -> list[dict]:
        ddb_sql = _convert_placeholders(sql)
        rows = self.connection.conn.execute(ddb_sql, list(params)).fetchall()
        # Get column names from the result description
        desc = self.connection.conn.description
        if not desc:
            return []
        columns = [d[0] for d in desc]
        return [dict(zip(columns, row, strict=False)) for row in rows]

    def _exec_sql(self, sql: str, params: tuple = ()) -> int:
        ddb_sql = _convert_placeholders(sql)
        # DuckDB doesn't expose rowcount directly; pre-count for DELETEs
        upper = sql.strip().upper()
        if upper.startswith("DELETE"):
            # Extract the WHERE clause to count affected rows
            # Parse table and condition from DELETE FROM <table> WHERE <cond>
            match = re.match(
                r"DELETE\s+FROM\s+(\S+)(?:\s+WHERE\s+(.+))?",
                sql.strip(),
                re.IGNORECASE | re.DOTALL,
            )
            if match:
                table = match.group(1)
                where = match.group(2)
                if where:
                    count_sql = _convert_placeholders(
                        f"SELECT COUNT(*) FROM {table} WHERE {where}"  # nosec B608
                    )
                    count = self.connection.conn.execute(
                        count_sql, list(params)
                    ).fetchone()[0]
                else:
                    count = self.connection.conn.execute(
                        f"SELECT COUNT(*) FROM {table}"  # nosec B608
                    ).fetchone()[0]
                self.connection.conn.execute(ddb_sql, list(params))
                return count
        self.connection.conn.execute(ddb_sql, list(params))
        return 0

    def _ensure_handle_tables(self) -> None:
        """Ensure handle tables exist (they're created in _create_schema)."""
        result = self.connection.conn.execute(
            "SELECT COUNT(*) FROM information_schema.tables "
            "WHERE table_name = 'handle_registry'"
        ).fetchone()
        if result[0] == 0:
            self.connection._create_schema()
        logger.debug("Handle tables ensured.")

    # =====================================================================
    # Card Operations (engine-specific)
    # =====================================================================

    def add(self, card: MCard) -> str:
        hash_value = str(card.hash)
        try:
            content_bytes = (
                card.content
                if isinstance(card.content, bytes)
                else card.content.encode("utf-8")
            )
            self.connection.conn.execute(
                "INSERT INTO card (hash, content, g_time) VALUES ($1, $2, $3)",
                [hash_value, content_bytes, str(card.g_time)],
            )
            logger.debug(f"Added card with hash {hash_value}")
            return hash_value
        except duckdb.ConstraintException as e:
            raise ValueError(
                f"Card with hash {hash_value} and {str(card.g_time)} already exists, "
                f"\n Content: {card.content[:20]}"
            ) from e

    def get(self, hash_value: str) -> MCard | None:
        result = self.connection.conn.execute(
            "SELECT content, g_time, hash FROM card WHERE hash = $1",
            [str(hash_value)],
        ).fetchone()

        if not result:
            return None

        content, g_time, hash_val = result
        return self._row_to_card(content, hash_val, g_time)

    def delete(self, hash_value: str) -> bool:
        # DuckDB doesn't expose rowcount the same way, so check first
        exists = self.connection.conn.execute(
            "SELECT 1 FROM card WHERE hash = $1", [str(hash_value)]
        ).fetchone()
        if not exists:
            return False
        self.connection.conn.execute(
            "DELETE FROM card WHERE hash = $1", [str(hash_value)]
        )
        return True

    def search_by_string(
        self,
        search_string: str,
        page_number: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> Page:
        """Search cards by string in content, hash, or g_time."""
        if page_number < 1:
            raise ValueError("Page number must be >= 1")
        if page_size < 1:
            raise ValueError("Page size must be >= 1")

        offset = (page_number - 1) * page_size
        pattern = f"%{search_string}%"

        total_items = self.connection.conn.execute(
            """
            SELECT COUNT(*) FROM card
            WHERE hash LIKE $1 OR g_time LIKE $2 OR CAST(content AS VARCHAR) LIKE $3
            """,
            [pattern, pattern, pattern],
        ).fetchone()[0]

        rows = self.connection.conn.execute(
            """
            SELECT content, g_time, hash FROM card
            WHERE hash LIKE $1 OR g_time LIKE $2 OR CAST(content AS VARCHAR) LIKE $3
            ORDER BY g_time DESC LIMIT $4 OFFSET $5
            """,
            [pattern, pattern, pattern, page_size, offset],
        ).fetchall()

        items = [
            self._row_to_card(content, hash_val, g_time)
            for content, g_time, hash_val in rows
        ]
        return Page.create(items, total_items, page_number, page_size)

    def search_by_content(
        self,
        search_string: str | bytes,
        page_number: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> Page:
        """Search cards by content pattern."""
        if page_number < 1:
            raise ValueError("Page number must be >= 1")
        if page_size < 1:
            raise ValueError("Page size must be >= 1")
        if not search_string:
            raise ValueError("Search string cannot be empty")

        offset = (page_number - 1) * page_size

        if isinstance(search_string, str):
            search_text = search_string
        else:
            search_text = search_string.decode("utf-8", errors="replace")

        # DuckDB: position() only works with VARCHAR, so cast BLOB content
        pattern = f"%{search_text}%"
        total_items = self.connection.conn.execute(
            "SELECT COUNT(*) FROM card WHERE CAST(content AS VARCHAR) LIKE $1",
            [pattern],
        ).fetchone()[0]

        rows = self.connection.conn.execute(
            """
            SELECT content, g_time, hash FROM card
            WHERE CAST(content AS VARCHAR) LIKE $1
            ORDER BY g_time DESC
            LIMIT $2 OFFSET $3
            """,
            [pattern, page_size, offset],
        ).fetchall()

        items = [
            self._row_to_card(content, hash_val, g_time)
            for content, g_time, hash_val in rows
        ]
        return Page.create(items, total_items, page_number, page_size)

    def count(self) -> int:
        return self.connection.conn.execute("SELECT COUNT(*) FROM card").fetchone()[0]

    def get_cards_by_page(
        self, page_number: int = 1, page_size: int = DEFAULT_PAGE_SIZE
    ) -> Page:
        """Get a page of cards."""
        if page_number < 1:
            raise ValueError("Page number must be >= 1")
        if page_size < 1:
            raise ValueError("Page size must be >= 1")

        total_items = self.connection.conn.execute(
            "SELECT COUNT(*) FROM card"
        ).fetchone()[0]

        offset = (page_number - 1) * page_size
        rows = self.connection.conn.execute(
            "SELECT content, g_time, hash FROM card ORDER BY g_time DESC LIMIT $1 OFFSET $2",
            [page_size, offset],
        ).fetchall()

        items = [
            self._row_to_card(content, hash_val, g_time)
            for content, g_time, hash_val in rows
        ]
        return Page.create(items, total_items, page_number, page_size)
