"""Private collection module for encrypted VCards and private execution logs."""

import logging
import os
from typing import Any

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from mcard.config.config_constants import DEFAULT_VCARD_DB_PATH
from mcard.model.card import MCard
from mcard.model.card_collection import CardCollection

logger = logging.getLogger(__name__)

_VOLATILE_DEV_KEY = AESGCM.generate_key(256)


class EncryptedStorageEngineWrapper:
    """Wraps an existing SQLite/DuckDB engine to transparently encrypt/decrypt content."""

    def __init__(self, engine: Any, aesgcm: AESGCM):
        self._engine = engine
        self._aesgcm = aesgcm

    def _encrypt(self, data: bytes) -> bytes:
        nonce = os.urandom(12)
        ciphertext = self._aesgcm.encrypt(nonce, data, None)
        return nonce + ciphertext

    def _decrypt(self, data: bytes) -> bytes:
        nonce = data[:12]
        ciphertext = data[12:]
        try:
            return self._aesgcm.decrypt(nonce, ciphertext, None)
        except InvalidTag as err:
            logger.error(
                "Failed to decrypt DB content. Key mismatch or data corruption."
            )
            raise ValueError(
                "Decryption failed. Invalid key or corrupted data."
            ) from err

    def add(self, card: MCard) -> str:
        # Create an encrypted version of the card, but maintain the plaintext hash for addressing
        content_bytes = (
            card.content
            if isinstance(card.content, bytes)
            else str(card.content).encode("utf-8")
        )
        encrypted_bytes = self._encrypt(content_bytes)

        # We construct a new MCard with encrypted bytes but WE OVERRIDE its hash
        # To avoid the engine calculating a new hash based on encrypted content,
        # we bypass the standard MCard hashing by directly interacting with the engine
        # if the engine calculates hash in `add()`.
        # However, SQLiteEngine `add` uses str(card.hash).
        # We can dynamically subclass or patch the card instance just for this engine call.

        class EncryptedCard(MCard):
            @property
            def hash(self):
                return card.hash  # Return plaintext hash

            @property
            def g_time(self):
                return card.g_time

            @property
            def content(self):
                return encrypted_bytes

        enc_card = EncryptedCard(encrypted_bytes)
        return self._engine.add(enc_card)

    def get(self, hash_value: str) -> MCard | None:
        enc_card = self._engine.get(hash_value)
        if not enc_card:
            return None
        plaintext_bytes = self._decrypt(enc_card.content)
        return MCard(plaintext_bytes)

    def delete(self, hash_value: str) -> bool:
        return self._engine.delete(hash_value)

    # Note: Search by content will not work over encrypted data with AES-GCM
    # Search by string will only work over hash/g_time.
    # We delegate other methods as needed, or raise NotImplementedError for full search
    def __getattr__(self, name):
        return getattr(self._engine, name)


class PrivateCollection(CardCollection):
    """A strictly isolated collection for VCards and execution traces.

    Ensures that all content stored in this collection is AES-GCM encrypted
    at rest. The encryption key should be provided via the `VCARD_ENCRYPTION_KEY`
    environment variable as a hex string.
    """

    def __init__(self, db_path: str | None = None, key_hex: str | None = None):
        """Initialize the private collection.

        Args:
            db_path: Path to the private database.
            key_hex: Optional explicitly provided 256-bit AES key in hex.
        """
        if db_path is None:
            db_path = DEFAULT_VCARD_DB_PATH

        # Resolve the private key
        if not key_hex:
            key_hex = os.getenv("VCARD_ENCRYPTION_KEY")

        if key_hex:
            try:
                self.key = bytes.fromhex(key_hex)
            except ValueError:
                logger.error("VCARD_ENCRYPTION_KEY must be valid hex.")
                raise
        else:
            logger.warning(
                "No VCARD_ENCRYPTION_KEY found. Generating a volatile key for this session. "
                "Data written will be unreadable after restart!"
            )
            self.key = _VOLATILE_DEV_KEY

        self.aesgcm = AESGCM(self.key)

        # Initialize the underlying standard CardCollection on the target db
        super().__init__(db_path=db_path)

        # Inject our encryption wrapper into the engine pipeline
        self.engine = EncryptedStorageEngineWrapper(self.engine, self.aesgcm)

    # The CardCollection methods will now safely call our wrapped engine's `add()` and `get()`
