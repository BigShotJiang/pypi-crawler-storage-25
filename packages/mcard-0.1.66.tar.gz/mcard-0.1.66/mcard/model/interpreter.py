"""
Content type detection and validation service.

This module provides a unified interface for content type detection and validation
using a modular architecture with separate concerns for detection strategies,
validation, and content analysis utilities.
"""

import json
import logging

try:
    from defusedxml.ElementTree import fromstring as safe_fromstring
except ImportError:
    from xml.etree.ElementTree import fromstring as safe_fromstring  # nosec B314

# Import modular components
from .validators.validation_registry import ValidationError, validation_registry

try:
    import mcard_core_py  # type: ignore
except ImportError:
    LOGGER = logging.getLogger(__name__)
    LOGGER.warning(
        "mcard_core_py native extension not found, functionality may be degraded."
    )

# Module logger
LOGGER = logging.getLogger(__name__)

# Re-export ValidationError for backward compatibility
__all__ = ["ContentTypeInterpreter", "ValidationError", "get_interpreter"]

# Module-level singleton instance (lazy)
_default_interpreter: "ContentTypeInterpreter | None" = None


def get_interpreter() -> "ContentTypeInterpreter":
    """Return the module-level ContentTypeInterpreter singleton."""
    global _default_interpreter
    if _default_interpreter is None:
        _default_interpreter = ContentTypeInterpreter()
    return _default_interpreter


class ContentTypeInterpreter:
    """
    Unified service for content type detection and validation.

    This consolidated class uses modular components internally while maintaining
    the same external API for backward compatibility.
    """

    # ─── Load shared MIME data from external JSON ─────────────────────────
    # The canonical data lives in mime_extensions.json at the repo root.
    # Both Python and TypeScript load from it, keeping them in sync.
    @staticmethod
    def _load_shared_mime_data() -> tuple[frozenset, dict]:
        """Load MIME data from the shared JSON file.

        Returns a (text_mime_types frozenset, mime_to_extension dict) tuple.
        Falls back to minimal built-in defaults if the file is not found.
        """
        from pathlib import Path

        # Walk up from this file to find mime_extensions.json at repo root
        search = Path(__file__).resolve().parent
        for _ in range(5):
            candidate = search / "mime_extensions.json"
            if candidate.exists():
                break
            search = search.parent
        else:
            candidate = None

        if candidate and candidate.exists():
            try:
                with open(candidate, encoding="utf-8") as f:
                    data = json.load(f)
                text_types = frozenset(data.get("textMimeTypes", []))
                ext_map = dict(data.get("mimeToExtension", {}))
                return text_types, ext_map
            except Exception as e:
                LOGGER.warning(
                    "Failed to load mime_extensions.json: %s — using defaults", e
                )

        # Minimal fallback if JSON file is missing
        return frozenset({"text/plain", "application/json"}), {
            "text/plain": "txt",
            "application/json": "json",
        }

    # Populated from the shared JSON (or fallback)
    _text_types, _ext_map = _load_shared_mime_data.__func__()  # type: ignore[attr-defined]
    TEXT_MIME_TYPES: frozenset = _text_types
    _MIME_TO_EXTENSION: dict = _ext_map

    @classmethod
    def register_extension(cls, mime_type: str, extension: str) -> None:
        """Dynamically register a new MIME-to-extension mapping.

        Accepts extensions with or without a leading dot (e.g., '.custom' or 'custom').
        The stored value will always be without a leading dot, consistent with the existing mapping.
        """
        if extension.startswith("."):
            extension = extension[1:]
        cls._MIME_TO_EXTENSION[mime_type] = extension

    @classmethod
    def register_extensions(cls, mapping: dict) -> None:
        """Dynamically register a batch of MIME-to-extension mappings."""
        for mime, ext in mapping.items():
            cls.register_extension(mime, ext)

    def __init__(self) -> None:
        """
        Initialize the interpreter.
        """
        pass

    @staticmethod
    def _decode_utf8(data: bytes) -> str:
        """Decode bytes to UTF-8 string using a consistent policy."""
        return data.decode("utf-8", errors="replace")

    @staticmethod
    def detect_content_type(
        content: str | bytes, file_extension: str | None = None
    ) -> tuple[str, str]:
        """
        Detect content type and suggested extension using Rust Core.
        """
        if isinstance(content, str):
            content = content.encode("utf-8")
        return mcard_core_py.detect_content_type(content, file_extension)  # type: ignore

    def detect_content_type_with_strategy(
        self, content: str | bytes, file_extension: str | None = None
    ) -> tuple[str, str]:
        """
        Detect content type using the configured strategy.

        Args:
            content: The content to analyze
            file_extension: Optional file extension hint

        Returns:
            Tuple of (mime_type, extension)
        """
        return self.detect_content_type(content, file_extension)

    def validate_content(self, content: str | bytes) -> None:
        """
        Validate content based on its detected type.

        This method now delegates to the validation registry for better modularity.

        Args:
            content: The content to validate

        Raises:
            ValidationError: If content is invalid
        """
        mime_type, _ = self.detect_content_type(content)
        validation_registry.validate(content, mime_type)

    @staticmethod
    def validate_content_static(content: str | bytes) -> None:
        """
        Static method for validating content (backward compatibility).

        Args:
            content: The content to validate

        Raises:
            ValidationError: If content is invalid
        """
        # Use default strategy for static method
        mime_type, _ = ContentTypeInterpreter.detect_content_type(content)
        validation_registry.validate(content, mime_type)

    @staticmethod
    def is_binary_content(content: str | bytes) -> bool:
        """
        Determine if content should be treated as binary using the Rust Core.
        """
        if isinstance(content, str):
            content = content.encode("utf-8")
        return mcard_core_py.is_binary_content(content)  # type: ignore

    @staticmethod
    def is_xml_content(content: str | bytes) -> bool:
        """Check if content is valid XML."""
        # Delegate to XMLDetector's is_valid_xml method
        try:
            if isinstance(content, str):
                content = content.encode("utf-8")

            # Try to parse the XML without requiring XML declaration
            safe_fromstring(content)  # nosec B314
            LOGGER.debug("Valid XML content detected.")
            return True
        except Exception as e:
            LOGGER.debug("Invalid XML content detected: %s", str(e))
            return False

    @staticmethod
    def is_svg_content(content: str | bytes) -> bool:
        """Check if content is SVG."""
        if isinstance(content, bytes):
            content = content.decode("utf-8", errors="ignore")

        # First check if it's valid XML
        if not ContentTypeInterpreter.is_xml_content(content):
            return False

        try:
            # Parse XML and check for SVG namespace
            tree = safe_fromstring(content)  # nosec B314
            return (
                tree.tag == "svg"
                or tree.tag.endswith("}svg")
                or any(
                    attr.endswith("xmlns") and "svg" in value
                    for attr, value in tree.attrib.items()
                )
            )
        except Exception:
            return False

    @staticmethod
    def is_mermaid_content(content: str) -> bool:
        """Check if content is Mermaid diagram."""
        content = content.strip().lower()
        mermaid_keywords = [
            "graph ",
            "sequencediagram",
            "classDiagram",
            "stateDiagram",
            "erDiagram",
            "gantt",
            "pie",
            "flowchart",
            "journey",
        ]
        return any(content.startswith(keyword.lower()) for keyword in mermaid_keywords)

    @staticmethod
    def is_diagram_content(content: str) -> bool:
        """Check if content is a diagram format."""
        content = content.strip().lower()
        # Check for PlantUML
        if content.startswith("@startuml") and content.endswith("@enduml"):
            return True
        # Check for Graphviz
        if content.startswith(("digraph", "graph", "strict")):
            return True
        # Check for Mermaid
        return ContentTypeInterpreter.is_mermaid_content(content)

    @staticmethod
    def get_extension(mime_type: str) -> str:
        """Get file extension from MIME type using Rust Core."""
        ext = mcard_core_py.get_extension(mime_type)
        if not ext:
            ext = ContentTypeInterpreter.get_default_extension(mime_type)
        return ext if ext is not None else ""

    @staticmethod
    def get_default_extension(mime_type: str) -> str:
        """
        Return the default file extension for a given MIME type.
        """
        return ContentTypeInterpreter._MIME_TO_EXTENSION.get(mime_type, "")
