"""
DEPRECATED: This module is deprecated in favor of `mcard.config.logging`.

This file exists for backward compatibility only. All new code should import from:
    from mcard.config.logging import setup_logging, get_logger, PerformanceTimer, SecurityAuditLogger

This module will be removed in a future release.
"""

import warnings

from .logging import (
    PerformanceTimer,
    SecurityAuditLogger,
    get_database_logger,
    get_logger,
    get_performance_logger,
    get_security_logger,
)
from .logging import (
    get_logging_config as get_improved_logging_config,  # Original name
)

# Issue deprecation warning on import
warnings.warn(
    "mcard.config.improved_logging is deprecated. Use mcard.config.logging instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new unified module for backward compatibility

__all__ = [
    "get_improved_logging_config",
    "get_logger",
    "get_security_logger",
    "get_performance_logger",
    "get_database_logger",
    "SecurityAuditLogger",
    "PerformanceTimer",
]
