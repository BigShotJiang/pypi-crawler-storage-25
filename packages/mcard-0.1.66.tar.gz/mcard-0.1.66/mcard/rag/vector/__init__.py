"""
Vector Store Package

SQLite-based vector storage using sqlite-vec extension.
Includes handle-aware semantic versioning support.
"""

from .handle_vector_store import (
    HandleVectorStore,
    HandleVersion,
    VersionSimilarityResult,
    classify_upgrade_type,
)
from .schema import HANDLE_VECTOR_SCHEMAS, VECTOR_SCHEMAS
from .store import MCardVectorStore, VectorSearchResult

__all__ = [
    # Core vector store
    "MCardVectorStore",
    "VectorSearchResult",
    "VECTOR_SCHEMAS",
    # Handle-aware semantic versioning
    "HandleVectorStore",
    "HandleVersion",
    "VersionSimilarityResult",
    "HANDLE_VECTOR_SCHEMAS",
    "classify_upgrade_type",
]
