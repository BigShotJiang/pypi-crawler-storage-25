"""
MCard RAG (Retrieval-Augmented Generation) Package

Provides vector search, semantic retrieval, and knowledge graph capabilities
for MCard content using SQLite with sqlite-vec extension and Ollama embeddings.
"""

from .config import DEFAULT_RAG_CONFIG, RAGConfig
from .engine import MCardRAGEngine, RAGResponse
from .graph import (
    Entity,
    GraphExtractor,
    GraphRAGEngine,
    GraphRAGResponse,
    GraphStore,
    Relationship,
)
from .indexer import PersistentIndexer, get_indexer, index_mcard, semantic_search
from .semantic_versioning import (
    compare_versions_by_similarity,
    find_most_similar_version,
    get_handle_version_history,
    get_semantic_evolution,
    get_store,
    get_store_info,
    get_version_distances,
    link_mcard_to_handle,
    list_handles,
    search_within_handle,
)
from .vector import (
    HandleVectorStore,
    HandleVersion,
    VersionSimilarityResult,
)

__all__ = [
    # Config
    "RAGConfig",
    "DEFAULT_RAG_CONFIG",
    # Vector RAG
    "MCardRAGEngine",
    "RAGResponse",
    # Persistent Indexer
    "PersistentIndexer",
    "get_indexer",
    "semantic_search",
    "index_mcard",
    # GraphRAG
    "GraphRAGEngine",
    "GraphRAGResponse",
    "GraphExtractor",
    "GraphStore",
    "Entity",
    "Relationship",
    # Semantic Versioning
    "link_mcard_to_handle",
    "get_handle_version_history",
    "compare_versions_by_similarity",
    "search_within_handle",
    "get_version_distances",
    "find_most_similar_version",
    "get_semantic_evolution",
    "list_handles",
    "get_store_info",
    "get_store",
    "HandleVectorStore",
    "HandleVersion",
    "VersionSimilarityResult",
]
