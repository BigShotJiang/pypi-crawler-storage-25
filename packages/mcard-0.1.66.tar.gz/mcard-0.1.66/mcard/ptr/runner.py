"""
CLM Runner - DEPRECATION SHIM

This module is DEPRECATED. All execution should route through PTREngine.

The CLMRunner class now proxies to PTREngine.run_file() and
PTREngine.run_chapter(). Existing callers will receive deprecation
warnings but will continue to function.

Migration Guide:
    # Old (deprecated):
    runner = CLMRunner()
    report = runner.run_file("chapter.yaml")

    # New (canonical):
    from mcard.ptr.core.engine import PTREngine
    engine = PTREngine()
    report = engine.run_file("chapter.yaml")
"""

import logging
import warnings
from typing import Any

from .core.engine import PTREngine


class CLMRunner:
    """
    DEPRECATED: Unified Runner for CLM execution.

    This class now delegates all execution to PTREngine.
    Use PTREngine directly for new code.
    """

    def __init__(self, collection=None, private_collection=None):
        warnings.warn(
            "CLMRunner is deprecated. Use PTREngine directly: "
            "from mcard.ptr.core.engine import PTREngine; engine = PTREngine()",
            DeprecationWarning,
            stacklevel=2,
        )
        self.logger = logging.getLogger(__name__)
        self._engine = PTREngine(
            storage_collection=collection,
            execution_log_collection=private_collection,
        )
        # Preserve legacy attributes for backward compatibility
        self.collection = self._engine.collection
        self.private_collection = private_collection

    def run_file(
        self, file_path: str, context: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Execute a CLM specification from a file.

        DEPRECATED: Delegates to PTREngine.run_file().
        """
        return self._engine.run_file(file_path, context=context)
