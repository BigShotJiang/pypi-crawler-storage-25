import logging
import socket
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from zeroconf import ServiceBrowser, ServiceInfo, Zeroconf

logger = logging.getLogger(__name__)


@dataclass
class PeerInfo:
    id: str
    ip: str
    port: int
    last_seen: datetime
    metadata: dict[str, str] = field(default_factory=dict)


class DiscoveryService:
    """Service to automatically discover other PTR nodes using pure zeroconf/mDNS"""

    SERVICE_TYPE = "_mcard-ptr._tcp.local."

    def __init__(self, node_id: str, port: int):
        self.node_id = node_id
        self.port = port
        self.zeroconf: Zeroconf | None = None
        self.browser: ServiceBrowser | None = None
        self.peers: dict[str, PeerInfo] = {}
        self.service_info: ServiceInfo | None = None

    def start(self) -> None:
        """Start advertising this node and discovering others."""
        # Note: Zeroconf automatically binds and responds to broadcasts in the background
        self.zeroconf = Zeroconf()

        # Get self IP
        ip_addr = self._get_local_ip()

        # Determine the name to advertise
        hostname = f"{self.node_id}.local."
        instance_name = f"{self.node_id}.{self.SERVICE_TYPE}"

        # Create ServiceInfo
        # Zeroconf properties should be bytes: bytes
        properties = {
            b"nodeId": self.node_id.encode("utf-8"),
            b"friendlyNetwork": b"true",
        }

        # Socket IP in bytes
        try:
            ip_bytes = socket.inet_aton(ip_addr)
        except Exception:
            ip_bytes = socket.inet_aton("127.0.0.1")

        self.service_info = ServiceInfo(
            self.SERVICE_TYPE,
            instance_name,
            addresses=[ip_bytes],
            port=self.port,
            properties=properties,
            server=hostname,
        )

        try:
            self.zeroconf.register_service(self.service_info)
            logger.info(
                f"Registered mDNS service {instance_name} at {ip_addr}:{self.port}"
            )
        except Exception as e:
            logger.error(f"Failed to register mDNS service: {e}")

        # Start browser to find peers
        self.browser = ServiceBrowser(self.zeroconf, self.SERVICE_TYPE, self)
        logger.info(f"Started peering discovery for {self.SERVICE_TYPE}")

    def stop(self) -> None:
        """Stop advertising and discovering."""
        if self.zeroconf:
            if self.service_info:
                try:
                    self.zeroconf.unregister_service(self.service_info)
                except Exception as e:
                    logger.warning(f"Error unregistering service: {e}")
            if self.browser:
                self.browser.cancel()
            self.zeroconf.close()
            self.zeroconf = None
        logger.info("Discovery service stopped")

    def get_peers(self) -> list[PeerInfo]:
        """Return list of active peers, filtering out stale ones (older than 35s)."""
        now = datetime.now()
        stale_ids = []
        for peer_id, peer in self.peers.items():
            if now - peer.last_seen > timedelta(seconds=35):
                stale_ids.append(peer_id)

        for pid in stale_ids:
            logger.debug(f"Removing stale peer {pid}")
            del self.peers[pid]

        return list(self.peers.values())

    # --- ServiceBrowser Callback Methods ---

    def remove_service(self, zeroconf: Zeroconf, type_: str, name: str) -> None:
        """Called when a service is removed."""
        pass  # We use the last_seen decay to remove them instead

    def add_service(self, zeroconf: Zeroconf, type_: str, name: str) -> None:
        """Called when a new service is discovered."""
        self.update_service(zeroconf, type_, name)

    def update_service(self, zeroconf: Zeroconf, type_: str, name: str) -> None:
        """Called when a service is updated (e.g. periodically rebroadcast)."""
        info = zeroconf.get_service_info(type_, name)
        if not info:
            return

        # Attempt to find the IP
        addr_str = None
        if info.addresses:
            try:
                addr_str = socket.inet_ntoa(info.addresses[0])
            except Exception:
                pass

        if not addr_str:
            return

        # Decode properties
        metadata = {}
        if info.properties:
            for key, value in info.properties.items():
                if isinstance(key, bytes):
                    try:
                        key_str = key.decode("utf-8")
                        val_str = (
                            value.decode("utf-8")
                            if isinstance(value, bytes)
                            else str(value)
                        )
                        metadata[key_str] = val_str
                    except Exception:
                        pass

        peer_id = metadata.get("nodeId")
        if not peer_id:
            # Fallback to interpreting from instance name
            peer_id = name.split(".")[0]

        if peer_id == self.node_id:
            return  # It's us

        if peer_id not in self.peers:
            logger.info(f"Discovered new peer {peer_id} at {addr_str}:{info.port}")

        self.peers[peer_id] = PeerInfo(
            id=peer_id,
            ip=addr_str,
            port=info.port,
            last_seen=datetime.now(),
            metadata=metadata,
        )

    def _get_local_ip(self) -> str:
        """Get the primary local IP address."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))
                return s.getsockname()[0]
        except Exception:
            return "127.0.0.1"
