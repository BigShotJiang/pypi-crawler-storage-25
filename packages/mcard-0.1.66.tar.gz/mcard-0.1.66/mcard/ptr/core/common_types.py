"""
Common types and data structures for the PTR Core system.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, NewType

# MCard as Prime Number (Atomic Identity)
PrimeHash = NewType("PrimeHash", str)


@dataclass
class PolynomialTerm:
    """
    Represents a term in the PCard Polynomial: A_i * X^{B_i}

    Where:
    - A_i (coefficient): Abstract Specification Hash (PrimeHash)
    - B_i (exponent): Balanced Expectation Hash (PrimeHash)
    - X: The Operator/Function being evaluated
    """

    coefficient: PrimeHash  # Abstract Spec
    exponent: PrimeHash  # Balanced Expectation
    weight: float = 1.0  # Optional weighting for semantic embedding


@dataclass
class SafetyViolation:
    """Records safety property violations"""

    property: str
    violation_type: str
    details: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class LivenessMetric:
    """Tracks liveness properties (progress toward goals)"""

    goal: str
    progress: float  # 0.0 to 1.0
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class VerificationStatus(Enum):
    """Status of CLM verification tracking temporal progression"""

    PENDING = "pending"
    VERIFIED = "verified"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ExecutionResult:
    """Result of a PCard execution with correctness measures

    Implements Computable Certificate pattern:
    - success/output: Generator's complex computation result
    - verification_vcard: Certificate (immutable audit evidence)
    - alignment_score: Directional alignment measure (cosine similarity)
    - invariants_preserved: Jacobian check (transformation verifiability)
    """

    success: bool
    output: Any
    verification_vcard: str | None  # Hash of the verification VCard
    execution_time_ms: int

    # Correctness Measures (from MVP+CLM Integration)
    alignment_score: float | None = None  # cos(actual, spec) - should be ≥ 0.85
    invariants_preserved: bool = True  # |J| ≠ 0 check

    # Safety and Liveness Tracking
    safety_violations: list[SafetyViolation] = field(default_factory=list)
    liveness_metrics: list[LivenessMetric] = field(default_factory=list)

    error_message: str | None = None


# ─────────────────────────────────────────────────────────────────────────────
# VCard Sandwich Boundary Exceptions
# ─────────────────────────────────────────────────────────────────────────────


class PreconditionViolation(RuntimeError):
    """Raised when a PCard's precondition VCard check fails.

    This means the input MCard did not satisfy the V_pre boundary
    evaluation defined by the PCard's abstract.preconditions.
    """

    def __init__(self, pcard_hash: str, input_hash: str, detail: str = ""):
        self.pcard_hash = pcard_hash
        self.input_hash = input_hash
        msg = f"Precondition violation: PCard {pcard_hash[:16]} rejected input {input_hash[:16]}"
        if detail:
            msg += f" — {detail}"
        super().__init__(msg)


class PostconditionViolation(RuntimeError):
    """Raised when a PCard's postcondition VCard check fails.

    This means the output of the Evaluation Map did not satisfy
    the V_post boundary evaluation defined by the PCard's abstract.postconditions.
    """

    def __init__(self, pcard_hash: str, output_repr: str = "", detail: str = ""):
        self.pcard_hash = pcard_hash
        self.output_repr = output_repr
        msg = f"Postcondition violation: PCard {pcard_hash[:16]} produced invalid output"
        if detail:
            msg += f" — {detail}"
        super().__init__(msg)
