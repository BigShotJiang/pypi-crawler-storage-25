from repoctx.main import main


if __name__ == "__main__":
    main()
