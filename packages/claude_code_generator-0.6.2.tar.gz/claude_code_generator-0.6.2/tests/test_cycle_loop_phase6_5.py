"""Tests for Phase 6.5 splice into cycle_loop._run_phases (#276)."""

from __future__ import annotations

import contextlib
import logging
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.commands._resume import next_start_phase, resolve_continue_multi_cycle
from code_generator.orchestrator import cycle_loop, phase5_closure


def _logger() -> logging.Logger:
    return logging.getLogger("test.cycle_loop_phase6_5")


def _make_state(tmp_path: Path, *, session_mode: str = "shared") -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.State(
        mode="single",
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        session_mode=session_mode,  # type: ignore[arg-type]
    )
    _state.save_state(state_dir / "state.json", st)
    return st


def _make_cycle(cycle_id: int = 1, *, phase: int = 0) -> _state.CycleState:
    return _state.CycleState(
        id=cycle_id,
        name=f"Cycle {cycle_id}",
        milestone_number=None,
        milestone_title="M",
        status="open",
        phase=phase,
        issues=[],
        commit_sha=None,
    )


def _async_track(name: str, order: list[str]) -> Any:
    async def _inner(*_a: object, **_kw: object) -> Any:
        order.append(name)
        if name == "phase5":
            return phase5_closure.FixResult()
        return None

    return _inner


def _patch_all_phases(stack: contextlib.ExitStack, order: list[str]) -> None:
    """Enter the patches into *stack* — caller manages lifetime."""
    for target, name in [
        (cycle_loop.phase1_plan, "phase1"),
        (cycle_loop.phase2_review, "phase2"),
        (cycle_loop.phase3_4_implement, "phase3"),
        (cycle_loop.phase5_closure, "phase5"),
        (cycle_loop.phase6_test, "phase6"),
        (cycle_loop.phase6_5_verify, "phase6_5"),
        (cycle_loop.phase7_commit, "phase7"),
        (cycle_loop.phase8_finalization, "phase8"),
    ]:
        stack.enter_context(patch.object(target, "run", _async_track(name, order)))
    stack.enter_context(patch.object(cycle_loop, "setup_phase_logger", return_value=_logger()))


# ---------------------------------------------------------------------------
# Constants registered
# ---------------------------------------------------------------------------


def test_phase_verify_constant_is_registered() -> None:
    assert hasattr(cycle_loop, "_PHASE_VERIFY")
    assert cycle_loop._PHASE_VERIFY == 65


def test_phase6_5_verify_module_imported_into_cycle_loop() -> None:
    assert hasattr(cycle_loop, "phase6_5_verify")


# ---------------------------------------------------------------------------
# (a) start_phase=6 → Phase 6 → 6.5 → 7
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_full_run_includes_phase6_5_between_6_and_7(tmp_path: Path) -> None:
    st = _make_state(tmp_path, session_mode="shared")
    order: list[str] = []

    with contextlib.ExitStack() as stack:
        _patch_all_phases(stack, order)
        await cycle_loop.run_single_mode(
            st,
            tmp_path,
            runner_module=MagicMock(),
            logger=_logger(),
            start_phase=6,
            session_mode="shared",
        )

    assert order == ["phase6", "phase6_5", "phase7", "phase8"]


# ---------------------------------------------------------------------------
# (b) Resume after Phase 6.5 (state.phase=65, start_phase=7) skips 6.5, runs 7
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_resume_after_phase6_5_runs_phase7_only(tmp_path: Path) -> None:
    st = _make_state(tmp_path, session_mode="shared")
    st.phase = 65  # simulate Phase 6.5 just completed
    order: list[str] = []

    with contextlib.ExitStack() as stack:
        _patch_all_phases(stack, order)
        start_phase = next_start_phase(st)
        await cycle_loop.run_single_mode(
            st,
            tmp_path,
            runner_module=MagicMock(),
            logger=_logger(),
            start_phase=start_phase,
            session_mode="shared",
        )

    assert "phase6_5" not in order
    assert order == ["phase7", "phase8"]


# ---------------------------------------------------------------------------
# (c) Phase 6.5 raises VerificationFailed → Phase 7 never called
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_verification_failed_aborts_before_phase7(tmp_path: Path) -> None:
    from code_generator.orchestrator.phase6_5_verify import VerificationFailed

    st = _make_state(tmp_path, session_mode="shared")
    order: list[str] = []

    async def fail_phase6_5(*_a: object, **_kw: object) -> None:
        order.append("phase6_5")
        raise VerificationFailed("simulated red tier")

    p7_mock = AsyncMock()

    with (
        patch.object(cycle_loop.phase6_test, "run", _async_track("phase6", order)),
        patch.object(cycle_loop.phase6_5_verify, "run", fail_phase6_5),
        patch.object(cycle_loop.phase7_commit, "run", p7_mock),
        patch.object(cycle_loop.phase8_finalization, "run", AsyncMock()),
        patch.object(cycle_loop, "setup_phase_logger", return_value=_logger()),
    ):
        with pytest.raises(VerificationFailed):
            await cycle_loop.run_single_mode(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_logger(),
                start_phase=6,
                session_mode="shared",
            )

    assert order == ["phase6", "phase6_5"]
    p7_mock.assert_not_called()


# ---------------------------------------------------------------------------
# Fresh mode (shared_client=None) skips Phase 6.5 silently
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_fresh_mode_skips_phase6_5(tmp_path: Path) -> None:
    st = _make_state(tmp_path, session_mode="fresh")
    order: list[str] = []

    with contextlib.ExitStack() as stack:
        _patch_all_phases(stack, order)
        await cycle_loop.run_single_mode(
            st,
            tmp_path,
            runner_module=MagicMock(),
            logger=_logger(),
            start_phase=6,
            session_mode="fresh",
        )

    assert "phase6_5" not in order
    assert "phase6" in order
    assert "phase7" in order


# ---------------------------------------------------------------------------
# Resume helpers
# ---------------------------------------------------------------------------


class TestNextStartPhase:
    def test_after_phase_6_returns_7(self) -> None:
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            phase=6,
        )
        assert next_start_phase(st) == 7

    def test_after_phase_6_5_returns_7_to_jump_to_phase_7(self) -> None:
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            phase=65,
        )
        assert next_start_phase(st) == 7

    def test_after_phase_7_returns_default_advance(self) -> None:
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            phase=7,
        )
        # phase=7 advances to 8; the strict Phase 6.5 guard
        # (current_phase == _PHASE_TEST) ensures Phase 6.5 is not re-run.
        assert next_start_phase(st) == 8


class TestResolveContinueMultiCycle:
    def _state_with_cycle(self, cycle_phase: int, status: str = "open") -> _state.State:
        cycle = _make_cycle(1, phase=cycle_phase)
        cycle.status = status
        return _state.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=1,
            cycles=[cycle],
        )

    def test_after_phase_6_5_returns_phase_7(self) -> None:
        st = self._state_with_cycle(cycle_phase=65)
        start_cycle, start_phase = resolve_continue_multi_cycle(st)
        assert (start_cycle, start_phase) == (1, 7)

    def test_after_phase_6_returns_phase_7(self) -> None:
        st = self._state_with_cycle(cycle_phase=6)
        start_cycle, start_phase = resolve_continue_multi_cycle(st)
        assert (start_cycle, start_phase) == (1, 7)
