"""Tests for code_generator.checklist — Issue #249.

Feature checklist module: seed at Phase 1; atomic ticks for tests_passed
(Phase 6) and committed (Phase 7); feature_done = tests_passed AND committed.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest  # noqa: TC002 — runtime fixture provider, not just type

from code_generator.checklist import (
    ChecklistEntry,
    done_total,
    load,
    seed,
    tick_committed,
    tick_professionalized,
    tick_runtime_verified,
    tick_tests_passed,
)
from code_generator.state import IssueState

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _issue(number: int, title: str = "") -> IssueState:
    return IssueState(
        number=number,
        status="open",
        agent="python-pro",
        title=title or f"Issue {number}",
    )


# ---------------------------------------------------------------------------
# seed()
# ---------------------------------------------------------------------------


class TestSeed:
    def test_seed_creates_file_with_expected_shape(self, tmp_path: Path) -> None:
        path = tmp_path / "abcd.json"
        seed(path, [_issue(1, "Login"), _issue(2, "Logout")])

        raw = json.loads(path.read_text(encoding="utf-8"))
        assert raw == [
            {
                "issue_number": 1,
                "title": "Login",
                "tests_passed": False,
                "committed": False,
                "feature_done": False,
                "runtime_verified": False,
                "professionalized": False,
            },
            {
                "issue_number": 2,
                "title": "Logout",
                "tests_passed": False,
                "committed": False,
                "feature_done": False,
                "runtime_verified": False,
                "professionalized": False,
            },
        ]

    def test_seed_creates_parent_directory(self, tmp_path: Path) -> None:
        path = tmp_path / "nested" / "subdir" / "h.json"
        seed(path, [_issue(1)])
        assert path.exists()

    def test_reseed_with_identical_issues_preserves_content(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        issues = [_issue(1), _issue(2)]
        seed(path, issues)
        first = path.read_text()

        seed(path, issues)

        assert path.read_text() == first

    def test_reseed_with_new_issues_appends_without_resetting_existing_ticks(
        self, tmp_path: Path
    ) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1), _issue(2)])
        tick_tests_passed(path, 1)
        tick_runtime_verified(path, 1)
        tick_committed(path, 1)
        tick_professionalized(path, 1)

        seed(path, [_issue(1), _issue(2), _issue(3, "New")])

        entries = load(path)
        by_num = {e.issue_number: e for e in entries}
        assert by_num[1].tests_passed is True
        assert by_num[1].runtime_verified is True
        assert by_num[1].committed is True
        assert by_num[1].professionalized is True
        assert by_num[1].feature_done is True
        assert by_num[3].title == "New"
        assert by_num[3].feature_done is False

    def test_seed_writes_atomically_via_tmp_file(self, tmp_path: Path) -> None:
        """Atomic write leaves no .tmp residue and final file matches payload."""
        path = tmp_path / "h.json"
        seed(path, [_issue(7)])

        residual = list(tmp_path.glob("*.tmp"))
        assert residual == []
        assert json.loads(path.read_text())[0]["issue_number"] == 7


# ---------------------------------------------------------------------------
# load()
# ---------------------------------------------------------------------------


class TestLoad:
    def test_load_returns_empty_list_when_file_missing(self, tmp_path: Path) -> None:
        assert load(tmp_path / "missing.json") == []

    def test_load_returns_checklist_entries(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1, "Foo")])

        entries = load(path)

        assert len(entries) == 1
        assert isinstance(entries[0], ChecklistEntry)
        assert entries[0].issue_number == 1
        assert entries[0].title == "Foo"
        assert entries[0].tests_passed is False


# ---------------------------------------------------------------------------
# tick_tests_passed / tick_committed
# ---------------------------------------------------------------------------


class TestTicks:
    def test_tick_tests_passed_sets_flag(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_tests_passed(path, 1)

        entry = load(path)[0]
        assert entry.tests_passed is True
        assert entry.committed is False
        assert entry.feature_done is False

    def test_tick_committed_sets_flag(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_committed(path, 1)

        entry = load(path)[0]
        assert entry.committed is True
        assert entry.tests_passed is False
        assert entry.feature_done is False

    def test_all_four_ticks_flip_feature_done_to_true(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_tests_passed(path, 1)
        tick_runtime_verified(path, 1)
        tick_committed(path, 1)
        tick_professionalized(path, 1)

        entry = load(path)[0]
        assert entry.tests_passed is True
        assert entry.runtime_verified is True
        assert entry.committed is True
        assert entry.professionalized is True
        assert entry.feature_done is True

    def test_three_ticks_without_professionalized_keeps_feature_done_false(
        self, tmp_path: Path
    ) -> None:
        """feature_done must NOT flip true when professionalized is False (#301 gate)."""
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_tests_passed(path, 1)
        tick_runtime_verified(path, 1)
        tick_committed(path, 1)

        entry = load(path)[0]
        assert entry.tests_passed is True
        assert entry.runtime_verified is True
        assert entry.committed is True
        assert entry.professionalized is False
        assert entry.feature_done is False

    def test_tests_and_committed_without_runtime_keeps_feature_done_false(
        self, tmp_path: Path
    ) -> None:
        """feature_done must NOT flip true when runtime_verified is False (#270 gate)."""
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_tests_passed(path, 1)
        tick_committed(path, 1)

        entry = load(path)[0]
        assert entry.tests_passed is True
        assert entry.committed is True
        assert entry.runtime_verified is False
        assert entry.feature_done is False

    def test_tick_runtime_verified_sets_flag(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_runtime_verified(path, 1)

        entry = load(path)[0]
        assert entry.runtime_verified is True
        assert entry.tests_passed is False
        assert entry.committed is False
        assert entry.feature_done is False

    def test_tick_runtime_verified_is_idempotent(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_runtime_verified(path, 1)
        first = path.read_text()
        tick_runtime_verified(path, 1)

        assert path.read_text() == first

    def test_tick_runtime_verified_writes_atomically(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_runtime_verified(path, 1)

        residual = list(tmp_path.glob("*.tmp"))
        assert residual == []

    def test_tick_unknown_issue_number_does_not_crash(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_tests_passed(path, 999)  # not in the checklist

        entry = load(path)[0]
        assert entry.tests_passed is False
        assert entry.feature_done is False

    def test_tick_unknown_issue_number_logs_warning(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        import logging

        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        with caplog.at_level(logging.WARNING):
            tick_committed(path, 999)

        assert any("999" in rec.getMessage() for rec in caplog.records)

    def test_tick_targets_only_matching_issue(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1), _issue(2), _issue(3)])

        tick_tests_passed(path, 2)

        by_num = {e.issue_number: e for e in load(path)}
        assert by_num[1].tests_passed is False
        assert by_num[2].tests_passed is True
        assert by_num[3].tests_passed is False

    def test_tick_writes_atomically(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_tests_passed(path, 1)

        residual = list(tmp_path.glob("*.tmp"))
        assert residual == []


# ---------------------------------------------------------------------------
# done_total()
# ---------------------------------------------------------------------------


class TestDoneTotal:
    def test_done_total_zero_zero_when_file_missing(self, tmp_path: Path) -> None:
        assert done_total(tmp_path / "missing.json") == (0, 0)

    def test_done_total_zero_done_after_seed(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1), _issue(2), _issue(3)])

        assert done_total(path) == (0, 3)

    def test_done_total_counts_only_fully_done_features(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1), _issue(2), _issue(3)])
        # Issue 1: all four flags
        tick_tests_passed(path, 1)
        tick_runtime_verified(path, 1)
        tick_committed(path, 1)
        tick_professionalized(path, 1)
        # Issue 2: only tests + committed (missing runtime_verified + professionalized)
        tick_tests_passed(path, 2)
        tick_committed(path, 2)
        # Issue 3: only commit
        tick_committed(path, 3)

        assert done_total(path) == (1, 3)

    def test_done_total_full_completion(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1), _issue(2)])
        for n in (1, 2):
            tick_tests_passed(path, n)
            tick_runtime_verified(path, n)
            tick_committed(path, n)
            tick_professionalized(path, n)

        assert done_total(path) == (2, 2)


# ---------------------------------------------------------------------------
# Backward compatibility (#270)
# ---------------------------------------------------------------------------


class TestRuntimeVerifiedBackwardCompat:
    def test_legacy_checklist_without_runtime_verified_loads_clean(self, tmp_path: Path) -> None:
        """A pre-#270 checklist JSON must deserialize cleanly with the field defaulting to False."""
        path = tmp_path / "h.json"
        legacy = [
            {
                "issue_number": 1,
                "title": "Legacy",
                "tests_passed": True,
                "committed": True,
                "feature_done": True,
            }
        ]
        path.write_text(json.dumps(legacy), encoding="utf-8")

        entries = load(path)

        assert len(entries) == 1
        assert entries[0].runtime_verified is False
        assert entries[0].tests_passed is True
        assert entries[0].committed is True


# ---------------------------------------------------------------------------
# Professionalized flag + Phase 8 gate (#301)
# ---------------------------------------------------------------------------


class TestProfessionalizedFlag:
    def test_default_professionalized_is_false(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])
        assert load(path)[0].professionalized is False

    def test_tick_professionalized_sets_flag(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_professionalized(path, 1)

        entry = load(path)[0]
        assert entry.professionalized is True
        assert entry.tests_passed is False
        assert entry.committed is False
        assert entry.runtime_verified is False
        assert entry.feature_done is False

    def test_tick_professionalized_is_idempotent(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_professionalized(path, 1)
        first = path.read_text()
        tick_professionalized(path, 1)

        assert path.read_text() == first

    def test_tick_professionalized_writes_atomically(self, tmp_path: Path) -> None:
        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        tick_professionalized(path, 1)

        residual = list(tmp_path.glob("*.tmp"))
        assert residual == []

    def test_tick_professionalized_unknown_issue_logs_warning(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        import logging

        path = tmp_path / "h.json"
        seed(path, [_issue(1)])

        with caplog.at_level(logging.WARNING):
            tick_professionalized(path, 999)

        assert any("999" in rec.getMessage() for rec in caplog.records)
        entry = load(path)[0]
        assert entry.professionalized is False


class TestProfessionalizedBackwardCompat:
    def test_legacy_checklist_without_professionalized_loads_clean(self, tmp_path: Path) -> None:
        """A pre-#301 checklist JSON must deserialize with professionalized=False."""
        path = tmp_path / "h.json"
        legacy = [
            {
                "issue_number": 1,
                "title": "Legacy",
                "tests_passed": True,
                "runtime_verified": True,
                "committed": True,
                "feature_done": True,
            }
        ]
        path.write_text(json.dumps(legacy), encoding="utf-8")

        entries = load(path)

        assert len(entries) == 1
        assert entries[0].professionalized is False
        assert entries[0].tests_passed is True
        assert entries[0].runtime_verified is True
        assert entries[0].committed is True

    def test_legacy_load_then_tick_promotes_feature_done(self, tmp_path: Path) -> None:
        """Legacy entry with three flags loads, tick_professionalized flips feature_done."""
        path = tmp_path / "h.json"
        legacy = [
            {
                "issue_number": 1,
                "title": "Legacy",
                "tests_passed": True,
                "runtime_verified": True,
                "committed": True,
                "feature_done": True,
            }
        ]
        path.write_text(json.dumps(legacy), encoding="utf-8")

        tick_professionalized(path, 1)

        entry = load(path)[0]
        assert entry.professionalized is True
        assert entry.feature_done is True
