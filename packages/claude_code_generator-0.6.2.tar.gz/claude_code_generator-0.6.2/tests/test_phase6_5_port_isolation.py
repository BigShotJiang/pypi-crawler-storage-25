"""Phase 6.5 ephemeral-port isolation (#1) and pre-flight port guard (#2).

Regression cover for the well-known-port collision that exhausted the
repair-retry budget: a co-resident ``chroma run`` (claude-mem plugin)
squatting ``:8000`` returned 404 to every health probe, so attempts 1+2
failed environmentally and attempt 3's real fix landed after the budget
was already spent. The fix moves verification onto an OS-assigned free
port and rerolls if that port is squatted before an attempt starts.
"""

from __future__ import annotations

import logging
import socket
from pathlib import Path

from code_generator.orchestrator.agent_spec import load_agent_spec
from code_generator.orchestrator.phase6_5_verify import (
    _alloc_free_port,
    _ensure_verify_port,
    _persist_spec_for_attempt,
)

_LOGGER = logging.getLogger("test.phase6_5.port_isolation")


def _make_project(tmp_path: Path) -> Path:
    project_dir = tmp_path / "project"
    (project_dir / ".code-generator").mkdir(parents=True)
    (project_dir / ".code-generator" / "requirements.md").write_text(
        "# Demo\n\n## Tech Stack\n\nFastAPI\n", encoding="utf-8"
    )
    return project_dir


def test_alloc_free_port_returns_a_bindable_ephemeral_port() -> None:
    port = _alloc_free_port()
    assert 1024 < port < 65536
    # Released back to the OS — re-bindable, proving it was genuinely free.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", port))


def test_persisted_spec_carries_ephemeral_port_not_8000(tmp_path: Path) -> None:
    project_dir = _make_project(tmp_path)
    port = _alloc_free_port()

    _persist_spec_for_attempt(
        project_dir, project_dir / ".code-generator" / "requirements.md", port
    )

    spec = load_agent_spec(project_dir / ".code-generator")
    assert spec.base_url == f"http://127.0.0.1:{port}"
    assert spec.base_url != "http://127.0.0.1:8000"
    # Every tier that declares a port (T1) is rewritten to the free port —
    # this is the field the SDK repair agent reads to boot the app.
    ported = [t for t in spec.tiers if t.port is not None]
    assert ported, "expected at least one tier with an explicit port (T1)"
    assert all(t.port == port for t in ported)


def test_guard_passes_through_a_free_port() -> None:
    port = _alloc_free_port()
    assert _ensure_verify_port(port, logger=_LOGGER) == port


def test_guard_rerolls_when_port_is_squatted(caplog) -> None:
    """A foreign listener on the chosen port → reroll, never reuse it.

    This is the chroma-on-:8000 scenario in miniature: the guard must
    hand back a *different*, free port so the squatter cannot fail a
    tier and burn a retry.
    """
    squatter = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    squatter.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    squatter.bind(("127.0.0.1", 0))
    squatter.listen(1)
    squatted_port = squatter.getsockname()[1]
    try:
        with caplog.at_level(logging.WARNING):
            rerolled = _ensure_verify_port(squatted_port, logger=_LOGGER)
        assert rerolled != squatted_port
        assert 1024 < rerolled < 65536
        assert "rerolled" in caplog.text
    finally:
        squatter.close()
