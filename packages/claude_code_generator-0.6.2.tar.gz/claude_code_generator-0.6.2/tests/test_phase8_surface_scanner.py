"""Tests for code_generator.surface_scanner (Phase 8 traceability, #325).

Covers pyproject/package.json entry-point detection, Typer/Click CLI command
extraction, FastAPI/router HTTP route extraction, exported-module discovery,
and walk-skip behaviour for ``__pycache__``/``tests``/``.venv``/``node_modules``.
"""

from __future__ import annotations

import dataclasses
import json
from pathlib import Path

import pytest

from code_generator import surface_scanner
from code_generator.surface_scanner import (
    ApiRoute,
    CliCommand,
    EntryPoint,
    SurfaceReport,
    scan_surface,
)

# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------


def _write_pyproject(
    root: Path,
    *,
    scripts: dict[str, str] | None = None,
    package_where: list[str] | None = None,
) -> Path:
    chunks: list[str] = ["[project]", 'name = "demo"', 'version = "0.1.0"']
    if scripts:
        chunks.append("\n[project.scripts]")
        for name, target in scripts.items():
            chunks.append(f'"{name}" = "{target}"')
    if package_where is not None:
        chunks.append("\n[tool.setuptools.packages.find]")
        where_repr = ", ".join(f'"{w}"' for w in package_where)
        chunks.append(f"where = [{where_repr}]")
    path = root / "pyproject.toml"
    path.write_text("\n".join(chunks) + "\n")
    return path


def _write_package_json(
    root: Path, *, bin_: dict[str, str] | None = None, scripts: dict[str, str] | None = None
) -> Path:
    body: dict[str, object] = {"name": "demo", "version": "0.1.0"}
    if bin_:
        body["bin"] = bin_
    if scripts:
        body["scripts"] = scripts
    path = root / "package.json"
    path.write_text(json.dumps(body, indent=2))
    return path


def _make_package(root: Path, name: str, src_layout: bool = True) -> Path:
    base = root / "src" / name if src_layout else root / name
    base.mkdir(parents=True)
    (base / "__init__.py").write_text("")
    return base


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


class TestValueObjectSlots:
    @pytest.mark.parametrize("value_object", [EntryPoint, CliCommand, ApiRoute])
    def test_when_inspected_then_value_object_uses_slots(self, value_object: type) -> None:
        """Value objects use ``slots=True`` — instance attribute set is locked."""
        assert hasattr(value_object, "__slots__"), f"{value_object.__name__} must be slotted"

    def test_when_unknown_attr_set_on_entry_point_then_attribute_error(self) -> None:
        ep = EntryPoint(name="x", module="m", script="m:f")
        with pytest.raises(AttributeError):
            ep.unknown = "boom"  # type: ignore[attr-defined]


class TestDataclasses:
    def test_when_entry_point_constructed_then_fields_present(self) -> None:
        ep = EntryPoint(name="x", module="m", script="m:f")
        assert ep.name == "x" and ep.module == "m" and ep.script == "m:f"

    def test_when_cli_command_constructed_then_fields_present(self, tmp_path: Path) -> None:
        c = CliCommand(name="run", source_path=tmp_path / "x.py")
        assert c.name == "run"
        assert c.source_path == tmp_path / "x.py"

    def test_when_api_route_constructed_then_fields_present(self, tmp_path: Path) -> None:
        r = ApiRoute(method="GET", path="/health", handler="ping", source_path=tmp_path / "x.py")
        assert r.method == "GET" and r.path == "/health" and r.handler == "ping"

    def test_when_report_serialized_then_asdict_works(self) -> None:
        report = SurfaceReport(
            entry_points=[EntryPoint("x", "m", "m:f")],
            cli_commands=[],
            api_routes=[],
            exported_modules=["pkg"],
        )
        result = dataclasses.asdict(report)
        assert result["entry_points"][0]["name"] == "x"
        assert result["exported_modules"] == ["pkg"]


# ---------------------------------------------------------------------------
# Empty project
# ---------------------------------------------------------------------------


class TestEmptyProject:
    def test_when_no_manifests_then_empty_report_is_returned(self, tmp_path: Path) -> None:
        report = scan_surface(tmp_path)
        assert report.entry_points == []
        assert report.cli_commands == []
        assert report.api_routes == []
        assert report.exported_modules == []


# ---------------------------------------------------------------------------
# pyproject [project.scripts]
# ---------------------------------------------------------------------------


class TestScanPyprojectScripts:
    def test_when_scripts_declared_then_entry_points_returned(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, scripts={"my-cli": "my_pkg.cli:app"})

        report = scan_surface(tmp_path)

        assert report.entry_points == [
            EntryPoint(name="my-cli", module="my_pkg.cli", script="my_pkg.cli:app")
        ]

    def test_when_no_scripts_section_then_no_entry_points(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path)
        report = scan_surface(tmp_path)
        assert report.entry_points == []

    def test_when_pyproject_invalid_then_no_entry_points(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("this is = not valid toml [[[\n")
        report = scan_surface(tmp_path)
        assert report.entry_points == []


# ---------------------------------------------------------------------------
# package.json bin/scripts
# ---------------------------------------------------------------------------


class TestScanPackageJson:
    def test_when_bin_declared_then_entry_points_returned(self, tmp_path: Path) -> None:
        _write_package_json(tmp_path, bin_={"my-tool": "./bin/cli.js"})

        report = scan_surface(tmp_path)

        names = [ep.name for ep in report.entry_points]
        assert "my-tool" in names

    def test_when_scripts_declared_then_entry_points_returned(self, tmp_path: Path) -> None:
        _write_package_json(tmp_path, scripts={"start": "node index.js"})

        report = scan_surface(tmp_path)

        names = [ep.name for ep in report.entry_points]
        assert "start" in names

    def test_when_only_package_json_then_other_sections_empty(self, tmp_path: Path) -> None:
        _write_package_json(tmp_path, scripts={"start": "node index.js"})

        report = scan_surface(tmp_path)

        assert report.cli_commands == []
        assert report.api_routes == []
        assert report.exported_modules == []

    def test_when_package_json_malformed_then_no_entry_points(self, tmp_path: Path) -> None:
        (tmp_path / "package.json").write_text("{ not: valid, json: [")
        report = scan_surface(tmp_path)
        assert report.entry_points == []


# ---------------------------------------------------------------------------
# Typer CLI commands
# ---------------------------------------------------------------------------


class TestDetectCliCommands:
    def test_when_app_command_decorator_then_cli_command_returned(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "my_pkg")
        (pkg / "cli.py").write_text(
            "import typer\napp = typer.Typer()\n\n@app.command()\ndef run():\n    pass\n"
        )

        report = scan_surface(tmp_path)

        assert len(report.cli_commands) == 1
        assert report.cli_commands[0].name == "run"
        assert report.cli_commands[0].source_path == pkg / "cli.py"

    def test_when_command_has_name_arg_then_name_overrides_funcname(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "my_pkg")
        (pkg / "cli.py").write_text(
            "import typer\n"
            "app = typer.Typer()\n"
            "\n"
            '@app.command("custom-name")\n'
            "def whatever():\n"
            "    pass\n"
        )

        report = scan_surface(tmp_path)

        assert report.cli_commands[0].name == "custom-name"

    def test_when_click_command_decorator_then_cli_command_returned(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "my_pkg")
        (pkg / "cli.py").write_text("import click\n\n@click.command()\ndef hello():\n    pass\n")

        report = scan_surface(tmp_path)

        names = [c.name for c in report.cli_commands]
        assert "hello" in names

    def test_when_function_undecorated_then_no_cli_command(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "my_pkg")
        (pkg / "cli.py").write_text(
            "def bare_func():\n    return None\n\ndef another():\n    pass\n"
        )

        report = scan_surface(tmp_path)

        assert report.cli_commands == []


# ---------------------------------------------------------------------------
# FastAPI routes
# ---------------------------------------------------------------------------


class TestDetectApiRoutes:
    def test_when_app_get_decorator_then_route_returned(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "api")
        (pkg / "main.py").write_text(
            "from fastapi import FastAPI\n"
            "app = FastAPI()\n"
            "\n"
            '@app.get("/health")\n'
            "def health():\n"
            "    return {}\n"
        )

        report = scan_surface(tmp_path)

        assert len(report.api_routes) == 1
        r = report.api_routes[0]
        assert r.method == "GET"
        assert r.path == "/health"
        assert r.handler == "health"
        assert r.source_path == pkg / "main.py"

    def test_when_router_post_decorator_then_route_returned(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "api")
        (pkg / "routes.py").write_text(
            "from fastapi import APIRouter\n"
            "router = APIRouter()\n"
            "\n"
            '@router.post("/items")\n'
            "def create_item():\n"
            "    return {}\n"
        )

        report = scan_surface(tmp_path)

        verbs = {(r.method, r.path) for r in report.api_routes}
        assert ("POST", "/items") in verbs

    def test_when_all_verbs_declared_then_all_returned(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "api")
        (pkg / "all.py").write_text(
            "app = object()\n"
            '@app.get("/a")\n'
            "def a(): pass\n"
            '@app.post("/b")\n'
            "def b(): pass\n"
            '@app.put("/c")\n'
            "def c(): pass\n"
            '@app.patch("/d")\n'
            "def d(): pass\n"
            '@app.delete("/e")\n'
            "def e(): pass\n"
        )

        report = scan_surface(tmp_path)

        methods = {r.method for r in report.api_routes}
        assert methods == {"GET", "POST", "PUT", "PATCH", "DELETE"}

    def test_when_non_http_verb_decorator_then_route_skipped(self, tmp_path: Path) -> None:
        """Decorators like ``@app.middleware`` / ``@app.options`` must not be routes."""
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "api")
        (pkg / "main.py").write_text(
            "app = object()\n"
            '@app.middleware("http")\n'
            "def mw(): pass\n"
            '@app.options("/x")\n'
            "def opt(): pass\n"
            '@app.websocket("/ws")\n'
            "def ws(): pass\n"
        )

        report = scan_surface(tmp_path)

        assert report.api_routes == []

    def test_when_unknown_receiver_then_route_skipped(self, tmp_path: Path) -> None:
        """``@blueprint.get(...)`` (non-``app``/``router``) must not be detected."""
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "api")
        (pkg / "main.py").write_text('blueprint = object()\n@blueprint.get("/x")\ndef y(): pass\n')

        report = scan_surface(tmp_path)

        assert report.api_routes == []


# ---------------------------------------------------------------------------
# Exported modules
# ---------------------------------------------------------------------------


class TestExportedModules:
    def test_when_src_layout_then_top_level_packages_returned(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, package_where=["src"])
        _make_package(tmp_path, "pkg_a")
        _make_package(tmp_path, "pkg_b")

        report = scan_surface(tmp_path)

        assert sorted(report.exported_modules) == ["pkg_a", "pkg_b"]

    def test_when_flat_layout_then_top_level_packages_returned(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, package_where=["."])
        _make_package(tmp_path, "flat_pkg", src_layout=False)

        report = scan_surface(tmp_path)

        assert "flat_pkg" in report.exported_modules


# ---------------------------------------------------------------------------
# Walk behaviour: skip __pycache__, tests/, .venv/
# ---------------------------------------------------------------------------


class TestSkipDirs:
    @pytest.mark.parametrize(
        "skip_dir",
        ["__pycache__", "tests", "node_modules", ".venv", "venv"],
    )
    def test_when_skip_dir_contains_routes_then_they_are_skipped(
        self, skip_dir: str, tmp_path: Path
    ) -> None:
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "api")
        leak_dir = pkg / skip_dir
        leak_dir.mkdir()
        (leak_dir / "__init__.py").write_text("")
        (leak_dir / "leak.py").write_text('app = object()\n@app.get("/leak")\ndef leak(): pass\n')

        report = scan_surface(tmp_path)

        paths = [str(r.source_path) for r in report.api_routes]
        assert not any(skip_dir in p for p in paths)


# ---------------------------------------------------------------------------
# Pure-Python end-to-end
# ---------------------------------------------------------------------------


class TestScanSurface:
    def test_when_pure_python_project_then_all_sections_populated(self, tmp_path: Path) -> None:
        _write_pyproject(
            tmp_path,
            scripts={"demo": "my_pkg.cli:app"},
            package_where=["src"],
        )
        pkg = _make_package(tmp_path, "my_pkg")
        (pkg / "cli.py").write_text(
            "import typer\napp = typer.Typer()\n\n@app.command()\ndef run():\n    pass\n"
        )
        (pkg / "api.py").write_text(
            'app = object()\n@app.get("/health")\ndef ping():\n    return {}\n'
        )

        report = scan_surface(tmp_path)

        assert any(ep.name == "demo" for ep in report.entry_points)
        assert any(c.name == "run" for c in report.cli_commands)
        assert any(r.path == "/health" for r in report.api_routes)
        assert "my_pkg" in report.exported_modules


def test_module_has_no_cli() -> None:
    """Module is consumed in-process; must not import argparse / typer."""
    src = Path(surface_scanner.__file__).read_text()
    assert "import argparse" not in src
    assert "import typer" not in src


def test_module_uses_ast_not_regex_for_decorators() -> None:
    """Per spec, route/CLI detection must use ast, not regex on source."""
    src = Path(surface_scanner.__file__).read_text()
    assert "import ast" in src or "from ast" in src


@pytest.mark.parametrize(
    "stack",
    ["typer_cli", "fastapi", "package_json_only", "empty"],
)
def test_scan_surface_returns_a_surface_report(stack: str, tmp_path: Path) -> None:
    if stack == "typer_cli":
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "p")
        (pkg / "cli.py").write_text("app = object()\n@app.command()\ndef x(): pass\n")
    elif stack == "fastapi":
        _write_pyproject(tmp_path, package_where=["src"])
        pkg = _make_package(tmp_path, "p")
        (pkg / "a.py").write_text("app = object()\n@app.get('/x')\ndef y(): pass\n")
    elif stack == "package_json_only":
        _write_package_json(tmp_path, scripts={"s": "node a.js"})

    report = scan_surface(tmp_path)
    assert isinstance(report, SurfaceReport)
