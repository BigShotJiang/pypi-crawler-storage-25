"""Tests for code_generator.orchestrator.tier_t4 — Issue #283.

T4 container tier: docker compose up + health wait + T2 replay +
guaranteed teardown. Subprocess is monkeypatched — no real Docker.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import TYPE_CHECKING

from code_generator.orchestrator import tier_t4
from code_generator.orchestrator.phase6_5_verify import Endpoint, TierResult
from code_generator.orchestrator.tier_t4 import run_t4_container

if TYPE_CHECKING:
    import pytest

# ---------------------------------------------------------------------------
# Fakes
# ---------------------------------------------------------------------------


class _FakeRunRecorder:
    def __init__(self, scripted: dict[str, subprocess.CompletedProcess] | None = None) -> None:
        self.calls: list[list[str]] = []
        self.envs: list[dict[str, str]] = []
        self.scripted = scripted or {}

    def __call__(
        self,
        cmd: list[str],
        cwd: Path,
        env: dict[str, str],
        *,
        timeout: float | None = None,
    ) -> subprocess.CompletedProcess:
        del cwd, timeout
        self.calls.append(list(cmd))
        self.envs.append(dict(env))
        key = " ".join(cmd[:2])
        result = self.scripted.get(key)
        if result is not None:
            return result
        return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")


def _make_compose(project_dir: Path, name: str = "docker-compose.yml") -> Path:
    project_dir.mkdir(parents=True, exist_ok=True)
    compose = project_dir / name
    compose.write_text("services: {}\n", encoding="utf-8")
    return compose


def _passing_t2_stub(*_args, **_kwargs) -> TierResult:
    return TierResult(
        tier_id="T2",
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=None,
        failing_detail=None,
    )


def _patch_t2_pass(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(tier_t4, "run_t2_api", _passing_t2_stub)
    monkeypatch.setattr(tier_t4, "_wait_for_health", lambda *_args, **_kwargs: True)


# ---------------------------------------------------------------------------
# Skip behavior
# ---------------------------------------------------------------------------


def test_when_no_manifest_then_t4_skipped_with_reason(tmp_path: Path) -> None:
    result = run_t4_container(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        endpoints=[Endpoint(path="/health")],
    )

    assert result.tier_id == "T4"
    assert result.skipped is True
    assert result.passed is False
    assert result.skip_reason


# ---------------------------------------------------------------------------
# Happy path: compose
# ---------------------------------------------------------------------------


def test_when_compose_passes_and_t2_passes_then_t4_passes(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _make_compose(tmp_path)
    recorder = _FakeRunRecorder()
    monkeypatch.setattr(tier_t4, "_run_capture", recorder)
    _patch_t2_pass(monkeypatch)

    result = run_t4_container(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        endpoints=[Endpoint(path="/health")],
    )

    assert result.passed is True
    assert result.skipped is False
    assert any("up" in " ".join(call) for call in recorder.calls)


# ---------------------------------------------------------------------------
# Failure: compose up returns non-zero
# ---------------------------------------------------------------------------


def test_when_compose_up_fails_then_t4_fails_with_stderr_populated(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _make_compose(tmp_path)
    boom = subprocess.CompletedProcess(
        args=["docker", "compose"],
        returncode=1,
        stdout="",
        stderr="ERROR: image build failed\n" + ("x" * 800),
    )
    recorder = _FakeRunRecorder(scripted={"docker compose": boom})
    monkeypatch.setattr(tier_t4, "_run_capture", recorder)
    _patch_t2_pass(monkeypatch)

    result = run_t4_container(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        endpoints=[Endpoint(path="/health")],
    )

    assert result.passed is False
    assert result.skipped is False
    assert result.exit_code == 1
    assert result.stderr_tail
    assert "image build failed" in (result.stdout_full or "")


# ---------------------------------------------------------------------------
# Teardown is always called
# ---------------------------------------------------------------------------


def test_when_t4_passes_then_compose_down_called(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _make_compose(tmp_path)
    recorder = _FakeRunRecorder()
    monkeypatch.setattr(tier_t4, "_run_capture", recorder)
    _patch_t2_pass(monkeypatch)

    run_t4_container(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        endpoints=[Endpoint(path="/health")],
    )

    assert any("down" in " ".join(call) for call in recorder.calls)


def test_when_t4_fails_then_compose_down_still_called(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _make_compose(tmp_path)
    boom = subprocess.CompletedProcess(
        args=["docker", "compose"], returncode=1, stdout="", stderr="bad"
    )
    recorder = _FakeRunRecorder(scripted={"docker compose": boom})
    monkeypatch.setattr(tier_t4, "_run_capture", recorder)
    _patch_t2_pass(monkeypatch)

    run_t4_container(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        endpoints=[Endpoint(path="/health")],
    )

    assert any("down" in " ".join(call) for call in recorder.calls)


# ---------------------------------------------------------------------------
# Env propagation: Anthropic key never leaks
# ---------------------------------------------------------------------------


def test_when_t4_runs_then_anthropic_api_key_absent_from_env(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _make_compose(tmp_path)
    recorder = _FakeRunRecorder()
    monkeypatch.setattr(tier_t4, "_run_capture", recorder)
    _patch_t2_pass(monkeypatch)

    run_t4_container(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        endpoints=[Endpoint(path="/health")],
    )

    assert recorder.envs
    for captured in recorder.envs:
        assert "ANTHROPIC_API_KEY" not in captured
        assert "ANTHROPIC_AUTH_TOKEN" not in captured


# ---------------------------------------------------------------------------
# __all__ export
# ---------------------------------------------------------------------------


def test_run_t4_container_in_phase6_5_verify_all() -> None:
    from code_generator.orchestrator import phase6_5_verify

    assert "run_t4_container" in phase6_5_verify.__all__
    assert phase6_5_verify.run_t4_container is run_t4_container


# ---------------------------------------------------------------------------
# Dockerfile-only fallback
# ---------------------------------------------------------------------------


def test_when_only_dockerfile_then_uses_docker_build_run(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    (tmp_path / "Dockerfile").write_text("FROM python:3.12\n", encoding="utf-8")
    recorder = _FakeRunRecorder()
    monkeypatch.setattr(tier_t4, "_run_capture", recorder)
    _patch_t2_pass(monkeypatch)

    result = run_t4_container(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        endpoints=[Endpoint(path="/health")],
    )

    assert result.passed is True
    commands_run = [" ".join(call) for call in recorder.calls]
    assert any(cmd.startswith("docker build") for cmd in commands_run)
    assert any(cmd.startswith("docker run") for cmd in commands_run)
    assert any(cmd.startswith("docker stop") or cmd.startswith("docker rm") for cmd in commands_run)
