"""Tests for code_generator.orchestrator.phase8_finalization (#302).

Phase 8 stub module: SDK-driven, one-shot, Opus 4.7, no git ops. Persists
``state.phase8`` / ``cycle.phase8`` atomically, ticks ``professionalized``
for every closed issue, and accumulates per-phase telemetry. The prompt body
is intentionally minimal — Cycles 2/3/4 add documentation / semver / CI work.
"""

from __future__ import annotations

import inspect
import logging
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from code_generator import checklist as _checklist
from code_generator import state as _state
from code_generator.orchestrator import phase8_finalization
from code_generator.runner.types import RunResult, TokenUsage


def _make_state(
    tmp_path: Path,
    issues: list[_state.IssueState] | None = None,
    *,
    requirements_hash: str | None = None,
) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    st.mode = "single"
    if issues:
        st.issues = issues
    st.requirements_hash = requirements_hash
    _state.save_state(state_dir / "state.json", st)
    return st


def _make_cycle(
    issues: list[_state.IssueState] | None = None,
    *,
    name: str = "Cycle 1",
    cycle_id: int = 1,
) -> _state.CycleState:
    return _state.CycleState(
        id=cycle_id,
        name=name,
        milestone_number=1,
        milestone_title=name,
        status="active",
        phase=8,
        issues=issues or [],
        commit_sha=None,
    )


def _make_run_result(text: str = "FINALIZATION_OK") -> RunResult:
    return RunResult(
        text=text,
        session_id=None,
        usage=TokenUsage(input=1, output=2),
        wall_seconds=0.1,
    )


def _seed_phase8_checklist(
    tmp_path: Path,
    requirements_hash: str,
    issue_numbers: list[int],
) -> Path:
    """Seed a fresh checklist with all flags pre-set except ``professionalized``."""
    checklist_path = tmp_path / ".code-generator" / "checklists" / f"{requirements_hash}.json"
    issues = [
        _state.IssueState(number=n, status="closed", agent="python-pro", title=f"Issue {n}")
        for n in issue_numbers
    ]
    _checklist.seed(checklist_path, issues)
    for n in issue_numbers:
        _checklist.tick_tests_passed(checklist_path, n)
        _checklist.tick_runtime_verified(checklist_path, n)
        _checklist.tick_committed(checklist_path, n)
    return checklist_path


class TestPhase8RunContract:
    @pytest.mark.asyncio
    async def test_run_signature_matches_phase7(self) -> None:
        sig = inspect.signature(phase8_finalization.run)
        params = sig.parameters
        assert list(params) == [
            "state",
            "cycle",
            "project_dir",
            "runner_module",
            "logger",
            "max_turns",
            "effective_model",
        ]
        assert params["logger"].default is None
        assert params["max_turns"].default is None
        assert params["effective_model"].default is None

    def test_module_does_not_hardcode_opus_string(self) -> None:
        """Acceptance: no `claude-opus-4-7` literal — model from phase_model(8)."""
        source = Path(phase8_finalization.__file__).read_text(encoding="utf-8")
        assert "claude-opus-4-7" not in source

    def test_module_does_not_set_max_turns_default_int(self) -> None:
        """Acceptance: no `max_turns=<int>` literal — non-negotiable #9."""
        source = Path(phase8_finalization.__file__).read_text(encoding="utf-8")
        for forbidden in ("max_turns=1", "max_turns=2", "max_turns=10", "max_turns=100"):
            assert forbidden not in source


class TestPhase8Run:
    @pytest.mark.asyncio
    async def test_calls_main_loop_exactly_once(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        main_loop_calls: list[tuple] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            main_loop_calls.append((runner, prompt, options))
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(main_loop_calls) == 1

    @pytest.mark.asyncio
    async def test_uses_opus_via_phase_model(self, tmp_path: Path) -> None:
        from code_generator import effort as _effort

        state = _make_state(tmp_path)
        captured: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured.append(options)
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured[0].model == _effort.phase_model(8) == "claude-opus-4-7"

    @pytest.mark.asyncio
    async def test_effective_model_override_takes_precedence(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        captured: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured.append(options)
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                effective_model="glm-5.1:cloud",
            )

        assert captured[0].model == "glm-5.1:cloud"

    @pytest.mark.asyncio
    async def test_persists_phase8_progress_ok(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        reloaded = _state.load_state(tmp_path / ".code-generator" / "state.json")
        assert reloaded.phase8 is not None
        assert reloaded.phase8.attempt == 1
        assert reloaded.phase8.status == "ok"
        assert reloaded.phase8.started_at is not None
        assert reloaded.phase8.finished_at is not None

    @pytest.mark.asyncio
    async def test_multi_cycle_persists_progress_on_cycle(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert cycle.phase8 is not None
        assert cycle.phase8.status == "ok"
        # Root-state phase8 stays untouched on multi-cycle runs.
        assert state.phase8 is None

    @pytest.mark.asyncio
    async def test_ticks_professionalized_for_closed_issues(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            issues=[
                _state.IssueState(number=1, status="closed", agent="python-pro", title="A"),
                _state.IssueState(number=2, status="closed", agent="python-pro", title="B"),
                _state.IssueState(number=3, status="open", agent="python-pro", title="C"),
            ],
            requirements_hash="abcd1234",
        )
        checklist_path = _seed_phase8_checklist(tmp_path, "abcd1234", [1, 2, 3])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        entries = {e.issue_number: e for e in _checklist.load(checklist_path)}
        assert entries[1].professionalized is True
        assert entries[2].professionalized is True
        assert entries[3].professionalized is False  # not closed
        # Issues 1 and 2 had the other 3 flags pre-ticked → feature_done True.
        assert entries[1].feature_done is True
        assert entries[2].feature_done is True
        assert entries[3].feature_done is False

    @pytest.mark.asyncio
    async def test_skips_checklist_tick_when_requirements_hash_missing(
        self,
        tmp_path: Path,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        state = _make_state(
            tmp_path,
            issues=[_state.IssueState(number=1, status="closed", agent="python-pro", title="A")],
        )
        state.requirements_hash = None

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            caplog.at_level(logging.WARNING),
            patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert any("requirements_hash" in rec.getMessage() for rec in caplog.records)

    @pytest.mark.asyncio
    async def test_accumulates_phase8_telemetry(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert "phase8" in state.token_usage
        usage = state.token_usage["phase8"]
        assert usage.input >= 1
        assert usage.output >= 2

    @pytest.mark.asyncio
    async def test_prompt_loaded_with_cycle_name_substituted(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        cycle = _make_cycle(name="Cycle Foundations")
        state.mode = "multi-cycle"
        prompts_seen: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            prompts_seen.append(prompt)
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(prompts_seen) == 1
        assert "Cycle Foundations" in prompts_seen[0]
        # No unsubstituted placeholders.
        assert "{CYCLE_NAME}" not in prompts_seen[0]


class TestPhase8Prompt:
    def test_prompt_registered_with_cycle_name_placeholder(self) -> None:
        from code_generator.prompts import PLACEHOLDER_SPEC

        assert "prompt-phase-8-finalization.md" in PLACEHOLDER_SPEC
        assert PLACEHOLDER_SPEC["prompt-phase-8-finalization.md"] == frozenset({"CYCLE_NAME"})

    def test_prompt_load_substitutes_cycle_name(self) -> None:
        from code_generator.prompts import load_prompt

        text = load_prompt("prompt-phase-8-finalization.md", CYCLE_NAME="Cycle 1")
        assert "{CYCLE_NAME}" not in text
        assert "Cycle 1" in text


# ---------------------------------------------------------------------------
# Cycle 3 (#319) — CI green-gate wiring
# ---------------------------------------------------------------------------


def _stub_workflow_gen(monkeypatch: pytest.MonkeyPatch) -> None:
    """Force ``generate_workflows`` to produce two writable files."""
    from code_generator.orchestrator.phase8_workflow_gen import WorkflowFile

    def fake_generate(_project_dir: Path) -> list[WorkflowFile]:
        return [
            WorkflowFile(rel_path=".github/workflows/ci.yml", content="# ci\n"),
            WorkflowFile(rel_path=".github/workflows/release.yml", content="# rel\n"),
        ]

    monkeypatch.setattr(
        phase8_finalization.phase8_workflow_gen, "generate_workflows", fake_generate
    )


def _stub_git(monkeypatch: pytest.MonkeyPatch, *, tags: list[str] | None = None) -> dict:
    """No-op the git_ops calls reached from phase8_finalization."""
    captured: dict = {"commits": [], "pushes": [], "tag_moves": []}

    def fake_add_all(_cwd: Path) -> None:
        return None

    def fake_commit(_cwd: Path, msg: str) -> None:
        captured["commits"].append(msg)

    def fake_branch(_cwd: Path) -> str:
        return "main"

    def fake_push(_cwd: Path, branch: str) -> None:
        captured["pushes"].append(branch)

    def fake_tag_list(_cwd: Path) -> list[str]:
        return list(tags or [])

    def fake_tag_move(_cwd: Path, tag: str, message: str) -> None:
        captured["tag_moves"].append((tag, message))

    monkeypatch.setattr(phase8_finalization, "git_add_all", fake_add_all)
    monkeypatch.setattr(phase8_finalization, "git_commit", fake_commit)
    monkeypatch.setattr(phase8_finalization, "git_current_branch", fake_branch)
    monkeypatch.setattr(phase8_finalization, "git_push", fake_push)
    monkeypatch.setattr(phase8_finalization, "git_tag_list", fake_tag_list)
    monkeypatch.setattr(phase8_finalization, "git_tag_move", fake_tag_move)
    return captured


def _stub_repair(
    monkeypatch: pytest.MonkeyPatch,
    outcome: str = "green",
) -> dict:
    """Patch the repair-loop dispatcher to return *outcome* without I/O."""
    captured: dict = {"calls": 0, "kwargs": []}

    async def fake_green_gate(**kwargs):
        captured["calls"] += 1
        captured["kwargs"].append(kwargs)
        return outcome  # type: ignore[return-value]

    monkeypatch.setattr(phase8_finalization, "_run_ci_green_gate", fake_green_gate)
    return captured


def _make_repo() -> object:
    from code_generator.repo_info import RepoInfo

    return RepoInfo(host="github.com", owner="o", name="r")


def _mark_as_git_repo(project_dir: Path) -> None:
    """Create a sentinel ``.git`` directory so finalization sees a real repo."""
    (project_dir / ".git").mkdir(exist_ok=True)


class TestPhase8GreenGate:
    @pytest.mark.asyncio
    async def test_when_green_records_ci_status_and_moves_tag_and_ticks(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        state = _make_state(
            tmp_path,
            issues=[_state.IssueState(number=1, status="closed", agent="python-pro", title="A")],
            requirements_hash="abcd1234",
        )
        state.repo = _make_repo()  # type: ignore[assignment]
        _mark_as_git_repo(tmp_path)
        _seed_phase8_checklist(tmp_path, "abcd1234", [1])

        _stub_workflow_gen(monkeypatch)
        git_capture = _stub_git(monkeypatch, tags=["v1.2.3"])
        repair_capture = _stub_repair(monkeypatch, outcome="green")

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        reloaded = _state.load_state(tmp_path / ".code-generator" / "state.json")
        assert reloaded.phase8 is not None
        assert reloaded.phase8.ci_status == "green"
        assert reloaded.phase8.status == "ok"
        assert sorted(reloaded.phase8.workflow_files_written) == [
            ".github/workflows/ci.yml",
            ".github/workflows/release.yml",
        ]
        assert git_capture["commits"] == ["ci: add GitHub Actions workflows for green-gate"]
        assert git_capture["tag_moves"] == [("v1.2.3", "CI green-gate passed: v1.2.3")]
        assert repair_capture["calls"] == 1

        entries = {
            e.issue_number: e
            for e in _checklist.load(tmp_path / ".code-generator" / "checklists" / "abcd1234.json")
        }
        assert entries[1].professionalized is True

    @pytest.mark.asyncio
    async def test_when_exhausted_records_status_and_skips_tag_and_no_tick(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        state = _make_state(
            tmp_path,
            issues=[_state.IssueState(number=1, status="closed", agent="python-pro", title="A")],
            requirements_hash="abcd1234",
        )
        state.repo = _make_repo()  # type: ignore[assignment]
        _mark_as_git_repo(tmp_path)
        _seed_phase8_checklist(tmp_path, "abcd1234", [1])

        _stub_workflow_gen(monkeypatch)
        git_capture = _stub_git(monkeypatch, tags=["v1.2.3"])
        _stub_repair(monkeypatch, outcome="exhausted")

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        reloaded = _state.load_state(tmp_path / ".code-generator" / "state.json")
        assert reloaded.phase8 is not None
        assert reloaded.phase8.ci_status == "exhausted"
        assert reloaded.phase8.status == "ok"
        assert git_capture["tag_moves"] == []

        # Without a green outcome, professionalized must remain False — the
        # repair loop already opened the remediation issue.
        entries = {
            e.issue_number: e
            for e in _checklist.load(tmp_path / ".code-generator" / "checklists" / "abcd1234.json")
        }
        assert entries[1].professionalized is False

    @pytest.mark.asyncio
    async def test_when_repo_is_none_skips_gate_and_ticks_professionalized(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        state = _make_state(
            tmp_path,
            issues=[_state.IssueState(number=1, status="closed", agent="python-pro", title="A")],
            requirements_hash="abcd1234",
        )
        assert state.repo is None  # precondition: local-only dev
        _seed_phase8_checklist(tmp_path, "abcd1234", [1])

        _stub_workflow_gen(monkeypatch)
        git_capture = _stub_git(monkeypatch)
        repair_capture = _stub_repair(monkeypatch, outcome="green")

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        reloaded = _state.load_state(tmp_path / ".code-generator" / "state.json")
        assert reloaded.phase8 is not None
        assert reloaded.phase8.ci_status == "skipped"
        assert reloaded.phase8.status == "ok"
        assert git_capture["commits"] == []  # no remote → no commit
        assert git_capture["pushes"] == []
        assert repair_capture["calls"] == 0  # green-gate not invoked

        entries = {
            e.issue_number: e
            for e in _checklist.load(tmp_path / ".code-generator" / "checklists" / "abcd1234.json")
        }
        assert entries[1].professionalized is True

    @pytest.mark.asyncio
    async def test_when_no_existing_tag_green_path_skips_tag_move(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        state = _make_state(tmp_path)
        state.repo = _make_repo()  # type: ignore[assignment]
        _mark_as_git_repo(tmp_path)
        _stub_workflow_gen(monkeypatch)
        git_capture = _stub_git(monkeypatch, tags=[])
        _stub_repair(monkeypatch, outcome="green")

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with patch.object(phase8_finalization.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase8_finalization.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert git_capture["tag_moves"] == []


class TestPhase8FinalizationPromptSentinel:
    def test_when_sentinel_missing_assert_raises(self) -> None:
        with pytest.raises(phase8_finalization.PromptError):
            phase8_finalization._assert_prompt_sentinel("nothing about the gate")

    def test_when_sentinel_present_assert_returns_none(self) -> None:
        phase8_finalization._assert_prompt_sentinel("intro\nCI_GREEN_GATE\nbody")
