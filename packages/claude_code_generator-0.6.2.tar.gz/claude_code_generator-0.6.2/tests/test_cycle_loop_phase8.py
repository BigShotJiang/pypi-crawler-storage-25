"""Tests for Phase 8 wiring inside ``orchestrator/cycle_loop.py`` (#303).

Covers the single-mode tail invocation, the multi-cycle once-per-run guard,
the ``start_phase > 8`` eligibility skip, and the call-order invariant
(Phase 8 fires after Phase 7).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import cycle_loop, phase5_closure

if TYPE_CHECKING:
    from pathlib import Path


def _make_logger() -> logging.Logger:
    return logging.getLogger("test.cycle_loop_phase8")


def _make_state(tmp_path: Path, mode: str = "single") -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        session_mode="fresh",
    )
    _state.save_state(state_dir / "state.json", st)
    return st


def _make_cycle(
    cycle_id: int,
    *,
    name: str | None = None,
    depends_on: list[int] | None = None,
    milestone_number: int | None = None,
) -> _state.CycleState:
    return _state.CycleState(
        id=cycle_id,
        name=name or f"Cycle {cycle_id}",
        milestone_number=milestone_number,
        milestone_title=f"Milestone {cycle_id}",
        status="open",
        phase=0,
        issues=[],
        commit_sha=None,
        depends_on=depends_on or [],
    )


def _stamp_phase8_ok(state: _state.State, cycle, *, fire: bool = True) -> None:
    """Side-effect that the spy uses to simulate phase8_finalization.run."""
    if not fire:
        return
    target = cycle if cycle is not None else state
    target.phase8 = _state.Phase8Progress(
        attempt=1,
        status="ok",
        started_at="2026-01-01T00:00:00Z",
        finished_at="2026-01-01T00:00:01Z",
    )


def _patch_pipeline_with_phase8(spy: AsyncMock):
    """Patch every phase module plus phase8 with the supplied spy."""
    return [
        patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
        patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
        patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
        patch.object(
            cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
        ),
        patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
        patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
        patch.object(cycle_loop.phase8_finalization, "run", spy),
        patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
    ]


# ---------------------------------------------------------------------------
# Constants + import wiring
# ---------------------------------------------------------------------------


class TestPhase8Constants:
    def test_phase_professionalize_constant_is_8(self) -> None:
        assert cycle_loop._PHASE_PROFESSIONALIZE == 8

    def test_phase8_module_imported(self) -> None:
        assert hasattr(cycle_loop, "phase8_finalization")


# ---------------------------------------------------------------------------
# Single-mode dispatch
# ---------------------------------------------------------------------------


class TestSingleModePhase8Dispatch:
    @pytest.mark.asyncio
    async def test_phase8_runs_after_phase7(self, tmp_path: Path) -> None:
        """Phase 8 fires after Phase 7 in single-mode."""
        st = _make_state(tmp_path)
        order: list[str] = []

        async def p7(*a, **kw):
            order.append("phase7")

        async def p8(state, cycle, project_dir, *, runner_module, logger=None, **kw):
            order.append("phase8")
            _stamp_phase8_ok(state, cycle)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop.phase8_finalization, "run", p8),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert order == ["phase7", "phase8"]

    @pytest.mark.asyncio
    async def test_phase8_receives_cycle_none(self, tmp_path: Path) -> None:
        """Phase 8 is invoked with cycle=None in single-mode."""
        st = _make_state(tmp_path)
        captured: list = []

        async def p8(state, cycle, project_dir, *, runner_module, logger=None, **kw):
            captured.append(cycle)
            _stamp_phase8_ok(state, cycle)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", p8),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert captured == [None]

    @pytest.mark.asyncio
    async def test_state_phase_is_8_after_run(self, tmp_path: Path) -> None:
        """state.phase == 8 after a clean single-mode run."""
        st = _make_state(tmp_path)

        async def p8(state, cycle, project_dir, *, runner_module, logger=None, **kw):
            _stamp_phase8_ok(state, cycle)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", p8),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert st.phase == 8
        assert st.phase8 is not None
        assert st.phase8.status == "ok"

    @pytest.mark.asyncio
    async def test_phase8_skipped_when_start_phase_past_8(self, tmp_path: Path) -> None:
        """start_phase=9 skips Phase 8 (eligibility guard)."""
        st = _make_state(tmp_path)
        spy = AsyncMock()

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", spy),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_single_mode(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_phase=9,
            )

        spy.assert_not_called()


# ---------------------------------------------------------------------------
# Multi-cycle dispatch
# ---------------------------------------------------------------------------


class TestMultiCyclePhase8Dispatch:
    @pytest.mark.asyncio
    async def test_phase8_fires_once_after_all_cycles(self, tmp_path: Path) -> None:
        """In multi-cycle, Phase 8 fires exactly once after the loop, on the root state."""
        st = _make_state(tmp_path, mode="multi-cycle")
        st.cycles = [_make_cycle(1, milestone_number=10), _make_cycle(2, milestone_number=11)]

        invocations: list = []

        async def p8(state, cycle, project_dir, *, runner_module, logger=None, **kw):
            invocations.append((cycle, id(state)))
            _stamp_phase8_ok(state, cycle)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", p8),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop.gh, "close_issue"),
        ):
            await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert len(invocations) == 1
        # Phase 8 receives cycle=None on multi-cycle path.
        assert invocations[0][0] is None
        # State.phase8 populated; cycle.phase8 left untouched.
        assert st.phase8 is not None
        assert st.phase8.status == "ok"
        for c in st.cycles:
            if isinstance(c, _state.CycleState):
                assert c.phase8 is None

    @pytest.mark.asyncio
    async def test_phase8_state_phase_set_to_8(self, tmp_path: Path) -> None:
        """root state.phase becomes 8 after multi-cycle finalization."""
        st = _make_state(tmp_path, mode="multi-cycle")
        st.cycles = [_make_cycle(1, milestone_number=10)]

        async def p8(state, cycle, project_dir, *, runner_module, logger=None, **kw):
            _stamp_phase8_ok(state, cycle)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", p8),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop.gh, "close_issue"),
        ):
            await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert st.phase == 8

    @pytest.mark.asyncio
    async def test_resume_skips_phase8_when_already_ok(self, tmp_path: Path) -> None:
        """When state.phase8.status == 'ok' a resumed multi-cycle run skips Phase 8."""
        st = _make_state(tmp_path, mode="multi-cycle")
        st.cycles = [_make_cycle(1, milestone_number=10, depends_on=[])]
        # Simulate Phase 8 already completed in a prior run.
        st.phase8 = _state.Phase8Progress(
            attempt=1,
            status="ok",
            started_at="2026-01-01T00:00:00Z",
            finished_at="2026-01-01T00:00:01Z",
        )
        # Mark the cycle completed so the eligibility loop exits immediately.
        st.cycles[0].status = "completed"  # type: ignore[union-attr]

        spy = AsyncMock()

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", spy),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop.gh, "close_issue"),
        ):
            await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        spy.assert_not_called()

    @pytest.mark.asyncio
    async def test_multi_cycle_start_phase_past_8_skips_phase8(self, tmp_path: Path) -> None:
        """start_phase=9 in run_multi_cycle skips the post-loop Phase 8 too."""
        st = _make_state(tmp_path, mode="multi-cycle")
        st.cycles = [_make_cycle(1, milestone_number=10)]
        st.cycles[0].status = "completed"  # type: ignore[union-attr]

        spy = AsyncMock()

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", spy),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop.gh, "close_issue"),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_phase=9,
            )

        spy.assert_not_called()

    @pytest.mark.asyncio
    async def test_phase8_failure_persists_last_error_and_reraises(self, tmp_path: Path) -> None:
        """Phase 8 crash in multi-cycle stamps state.last_error and re-raises."""
        st = _make_state(tmp_path, mode="multi-cycle")
        st.cycles = [_make_cycle(1, milestone_number=10)]
        st.cycles[0].status = "completed"  # type: ignore[union-attr]

        async def p8(*a, **kw):
            raise RuntimeError("phase8 exploded")

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", p8),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop.gh, "close_issue"),
            pytest.raises(RuntimeError, match="phase8 exploded"),
        ):
            await cycle_loop.run_multi_cycle(
                st, tmp_path, runner_module=MagicMock(), logger=_make_logger()
            )

        assert st.last_error == "phase8 exploded"
