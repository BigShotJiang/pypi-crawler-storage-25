"""Tests for code_generator.orchestrator.phase8_repair_loop."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pytest

from code_generator.orchestrator import phase8_repair_loop as repair_loop
from code_generator.orchestrator.phase8_local_verify import LocalVerifyResult
from code_generator.repo_info import RepoInfo
from code_generator.runner.types import RunResult, TokenUsage

_REPO = RepoInfo(host="github.com", owner="o", name="r")


# ---------------------------------------------------------------------------
# Lightweight stand-ins for State + runner_module
# ---------------------------------------------------------------------------


@dataclass
class _State:
    mode: str = "single"


@dataclass
class _RunnerStub:
    name: str = "fake"


def _result(text: str) -> RunResult:
    return RunResult(
        text=text,
        session_id=None,
        usage=TokenUsage(),
        wall_seconds=0.0,
    )


# ---------------------------------------------------------------------------
# Monkeypatch helpers
# ---------------------------------------------------------------------------


@dataclass
class _Recorded:
    list_runs_calls: list[tuple[str, str]] = field(default_factory=list)
    view_run_calls: list[int] = field(default_factory=list)
    log_calls: list[int] = field(default_factory=list)
    issues_created: list[dict[str, Any]] = field(default_factory=list)
    commits: list[str] = field(default_factory=list)
    pushes: list[str] = field(default_factory=list)
    head_shas: list[str] = field(default_factory=list)
    repair_invocations: int = 0
    verify_calls: int = 0


def _install_stubs(
    monkeypatch: pytest.MonkeyPatch,
    *,
    run_sequence: list[dict[str, Any]],
    view_run_payload: dict[str, Any] | None = None,
    log_text: str = "",
    repair_text: str = "[]",
    verify_result: LocalVerifyResult | None = None,
    head_sequence: list[str] | None = None,
) -> _Recorded:
    rec = _Recorded()
    runs_iter = iter(run_sequence)
    head_iter = iter(head_sequence or ["sha0", "sha1", "sha2", "sha3", "sha4"])

    def fake_list(repo: RepoInfo, sha: str) -> list[dict[str, Any]]:
        rec.list_runs_calls.append((repo.full, sha))
        try:
            payload = next(runs_iter)
        except StopIteration:
            return [{"databaseId": 1, "status": "completed", "conclusion": "success"}]
        return list(payload.get("runs", []))

    def fake_view(repo: RepoInfo, run_id: int) -> dict[str, Any]:
        rec.view_run_calls.append(run_id)
        return view_run_payload or {"jobs": [{"name": "ci", "conclusion": "failure"}]}

    def fake_logs(repo: RepoInfo, run_id: int) -> str:
        rec.log_calls.append(run_id)
        return log_text

    def fake_create_issue(
        repo: RepoInfo, title: str, body: str, labels: list[str] | None = None
    ) -> int:
        rec.issues_created.append({"title": title, "body": body, "labels": list(labels or [])})
        return 4242

    def fake_head(cwd: Path) -> str:
        sha = next(head_iter, "sha-final")
        rec.head_shas.append(sha)
        return sha

    def fake_add_all(cwd: Path) -> None:  # noqa: ARG001
        return None

    def fake_commit(cwd: Path, msg: str) -> None:  # noqa: ARG001
        rec.commits.append(msg)

    def fake_branch(cwd: Path) -> str:  # noqa: ARG001
        return "main"

    def fake_push(cwd: Path, branch: str) -> None:  # noqa: ARG001
        rec.pushes.append(branch)

    async def fake_main_loop(*_args: Any, **_kwargs: Any) -> RunResult:
        rec.repair_invocations += 1
        return _result(repair_text)

    async def fake_verify(project_dir: Path, workflow_diff: str) -> LocalVerifyResult:  # noqa: ARG001
        rec.verify_calls += 1
        return verify_result or LocalVerifyResult(
            passed=True,
            stderr_excerpt="",
            blocked_by_guardrail=False,
            guardrail_violations=[],
        )

    monkeypatch.setattr(repair_loop.gh_actions, "list_workflow_runs", fake_list)
    monkeypatch.setattr(repair_loop.gh_actions, "view_run", fake_view)
    monkeypatch.setattr(repair_loop.gh_actions, "get_failing_job_logs", fake_logs)
    monkeypatch.setattr(repair_loop, "create_issue", fake_create_issue)
    monkeypatch.setattr(repair_loop, "git_rev_parse_head", fake_head)
    monkeypatch.setattr(repair_loop, "git_add_all", fake_add_all)
    monkeypatch.setattr(repair_loop, "git_commit", fake_commit)
    monkeypatch.setattr(repair_loop, "git_current_branch", fake_branch)
    monkeypatch.setattr(repair_loop, "git_push", fake_push)
    monkeypatch.setattr(repair_loop.rate_limit, "main_loop", fake_main_loop)
    monkeypatch.setattr(repair_loop, "_verify_in_executor", fake_verify)

    async def no_sleep(_delay: float) -> None:
        return None

    monkeypatch.setattr(repair_loop.asyncio, "sleep", no_sleep)
    return rec


async def _run(
    tmp_path: Path,
    *,
    config: repair_loop.RepairLoopConfig | None = None,
) -> repair_loop.CiOutcome:
    return await repair_loop.run_ci_green_gate(
        _REPO,
        tmp_path,
        tmp_path / "state.json",
        _State(),  # type: ignore[arg-type]
        None,
        runner_module=_RunnerStub(),  # type: ignore[arg-type]
        effective_model=None,
        logger=logging.getLogger("test"),
        config=config,
    )


# ---------------------------------------------------------------------------
# Prompt sentinel
# ---------------------------------------------------------------------------


class TestPromptSentinel:
    def test_when_sentinel_missing_assert_raises(self) -> None:
        with pytest.raises(repair_loop.PromptError):
            repair_loop._assert_prompt_sentinel("no contract here")

    def test_when_sentinel_present_assert_returns_none(self) -> None:
        repair_loop._assert_prompt_sentinel("... Output patches as a JSON array ...")


# ---------------------------------------------------------------------------
# Patch parsing
# ---------------------------------------------------------------------------


class TestParsePatches:
    def test_when_valid_array_returns_patches(self) -> None:
        raw = '[{"file": "a.py", "line": 1, "old": "x", "new": "y"}]'
        assert repair_loop._parse_patches(raw) == [
            {"file": "a.py", "line": 1, "old": "x", "new": "y"}
        ]

    def test_when_prose_around_array_extracts_array(self) -> None:
        raw = 'prose [{"file": "a.py", "line": 1, "old": "x", "new": "y"}] trailing'
        assert len(repair_loop._parse_patches(raw)) == 1

    def test_when_empty_array_returns_empty_list(self) -> None:
        assert repair_loop._parse_patches("[]") == []

    def test_when_malformed_returns_empty_list(self) -> None:
        assert repair_loop._parse_patches("not json") == []

    def test_when_entries_missing_keys_filtered(self) -> None:
        raw = '[{"file": "a.py"}, {"file": "b.py", "line": 1, "old": "x", "new": "y"}]'
        assert len(repair_loop._parse_patches(raw)) == 1


# ---------------------------------------------------------------------------
# Patch application + revert
# ---------------------------------------------------------------------------


class TestApplyAndRevert:
    def test_when_patch_applied_file_contents_updated(self, tmp_path: Path) -> None:
        target = tmp_path / "src.py"
        target.write_text("old_value\n", encoding="utf-8")
        applied = repair_loop._apply_patches(
            tmp_path,
            [{"file": "src.py", "line": 1, "old": "old_value", "new": "new_value"}],
        )
        assert target.read_text(encoding="utf-8") == "new_value\n"
        assert len(applied) == 1

    def test_when_revert_called_file_restored(self, tmp_path: Path) -> None:
        target = tmp_path / "src.py"
        target.write_text("original\n", encoding="utf-8")
        applied = repair_loop._apply_patches(
            tmp_path,
            [{"file": "src.py", "line": 1, "old": "original", "new": "modified"}],
        )
        repair_loop._revert_patches(applied)
        assert target.read_text(encoding="utf-8") == "original\n"

    def test_when_old_snippet_missing_patch_skipped(self, tmp_path: Path) -> None:
        target = tmp_path / "src.py"
        target.write_text("hello world\n", encoding="utf-8")
        applied = repair_loop._apply_patches(
            tmp_path,
            [{"file": "src.py", "line": 1, "old": "absent", "new": "x"}],
        )
        assert applied == []
        assert target.read_text(encoding="utf-8") == "hello world\n"


# ---------------------------------------------------------------------------
# Loop integration
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestHappyPath:
    async def test_when_first_poll_green_returns_green_immediately(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        rec = _install_stubs(
            monkeypatch,
            run_sequence=[
                {
                    "runs": [
                        {
                            "databaseId": 1,
                            "status": "completed",
                            "conclusion": "success",
                            "workflowName": "ci",
                            "createdAt": "2026-05-16T10:00:00Z",
                        }
                    ]
                }
            ],
        )
        outcome = await _run(tmp_path)
        assert outcome == "green"
        assert rec.repair_invocations == 0
        assert rec.commits == []
        assert rec.pushes == []
        assert rec.issues_created == []


@pytest.mark.asyncio
class TestTransientThenGreen:
    async def test_when_transient_then_success_returns_green_without_repair(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        rec = _install_stubs(
            monkeypatch,
            run_sequence=[
                {
                    "runs": [
                        {
                            "databaseId": 1,
                            "status": "completed",
                            "conclusion": "failure",
                            "workflowName": "ci",
                            "createdAt": "2026-05-16T10:00:00Z",
                        }
                    ]
                },
                {
                    "runs": [
                        {
                            "databaseId": 2,
                            "status": "completed",
                            "conclusion": "success",
                            "workflowName": "ci",
                            "createdAt": "2026-05-16T10:05:00Z",
                        }
                    ]
                },
            ],
            log_text="ECONNRESET: connection reset by peer",
        )
        outcome = await _run(tmp_path)
        assert outcome == "green"
        assert rec.repair_invocations == 0


@pytest.mark.asyncio
class TestPermanentThenFixThenGreen:
    async def test_when_repair_succeeds_pushes_then_polls_again_for_green(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        target = tmp_path / "src.py"
        target.write_text("buggy\n", encoding="utf-8")
        patch_json = '[{"file": "src.py", "line": 1, "old": "buggy", "new": "fixed"}]'
        rec = _install_stubs(
            monkeypatch,
            run_sequence=[
                {
                    "runs": [
                        {
                            "databaseId": 1,
                            "status": "completed",
                            "conclusion": "failure",
                            "workflowName": "ci",
                            "createdAt": "2026-05-16T10:00:00Z",
                        }
                    ]
                },
                {
                    "runs": [
                        {
                            "databaseId": 2,
                            "status": "completed",
                            "conclusion": "success",
                            "workflowName": "ci",
                            "createdAt": "2026-05-16T10:10:00Z",
                        }
                    ]
                },
            ],
            log_text="FAILED tests/test_x.py::test_y",
            repair_text=patch_json,
        )
        outcome = await _run(tmp_path)
        assert outcome == "green"
        assert rec.repair_invocations == 1
        assert rec.commits == ["fix(ci): repair attempt 1"]
        assert rec.pushes == ["main"]
        assert target.read_text(encoding="utf-8") == "fixed\n"


@pytest.mark.asyncio
class TestGuardrailBlocksPatch:
    async def test_when_local_verify_blocks_no_push_attempt_increments(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        target = tmp_path / "src.py"
        target.write_text("orig\n", encoding="utf-8")
        rec = _install_stubs(
            monkeypatch,
            run_sequence=[
                {
                    "runs": [
                        {
                            "databaseId": 1,
                            "status": "completed",
                            "conclusion": "failure",
                            "workflowName": "ci",
                            "createdAt": "2026-05-16T10:00:00Z",
                        }
                    ]
                }
            ],
            log_text="FAILED tests/test_x.py::test_y",
            repair_text='[{"file": "src.py", "line": 1, "old": "orig", "new": "patched"}]',
            verify_result=LocalVerifyResult(
                passed=False,
                stderr_excerpt="",
                blocked_by_guardrail=True,
                guardrail_violations=["continue-on-error"],
            ),
        )
        outcome = await _run(tmp_path, config=repair_loop.RepairLoopConfig(max_repair_attempts=1))
        assert outcome == "exhausted"
        assert rec.pushes == []
        assert rec.commits == []
        assert target.read_text(encoding="utf-8") == "orig\n"
        assert len(rec.issues_created) == 1


@pytest.mark.asyncio
class TestBudgetExhausted:
    async def test_when_attempts_run_out_opens_remediation_issue_once(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        rec = _install_stubs(
            monkeypatch,
            run_sequence=[
                {
                    "runs": [
                        {
                            "databaseId": 1,
                            "status": "completed",
                            "conclusion": "failure",
                            "workflowName": "ci",
                            "createdAt": "2026-05-16T10:00:00Z",
                        }
                    ]
                }
            ]
            * 5,
            log_text="FAILED something",
            repair_text="[]",
        )
        outcome = await _run(tmp_path, config=repair_loop.RepairLoopConfig(max_repair_attempts=2))
        assert outcome == "exhausted"
        assert len(rec.issues_created) == 1
        issue = rec.issues_created[0]
        assert "manual remediation" in issue["title"]
        assert "needs-manual-review" in issue["labels"]
        assert "area:ci" in issue["labels"]
