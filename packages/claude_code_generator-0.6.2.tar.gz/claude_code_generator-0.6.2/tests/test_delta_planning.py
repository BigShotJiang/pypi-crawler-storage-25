"""Unit tests for delta planning — the path taken when requirements.md changes
and multi-cycle mode has previously-completed cycles.

Tests cover:
  - append phase0 delta into existing cycles (ID/depends_on remapping)
  - identical scopes → no new cycles (log message only)
  - Phase 0 failure → state unchanged (atomicity)
  - idempotency — running delta planning twice is safe
  - single-mode delta → re-runs from Phase 0 fresh
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as state_module
from code_generator.commands._dispatch import dispatch_async
from code_generator.state import CycleState, State

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

HASH_OLD = "a" * 64
HASH_NEW = "b" * 64


def _make_state(
    *,
    mode: str = "multi-cycle",
    cycles: list[CycleState] | None = None,
    requirements_hash: str | None = HASH_OLD,
) -> State:
    return State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        cycles=cycles or [],  # type: ignore[arg-type]
        requirements_hash=requirements_hash,
    )


def _completed_cycle(cycle_id: int, scope: str) -> CycleState:
    return CycleState(
        id=cycle_id,
        name=f"Cycle {cycle_id}",
        milestone_number=cycle_id,
        milestone_title=f"Cycle {cycle_id} — {scope}",
        status="completed",
        phase=7,
        issues=[],
        commit_sha=f"sha{cycle_id}",
        scope=scope,
    )


def _raw_cycle(raw_id: int, scope: str, depends_on: list[int] | None = None) -> dict[str, Any]:
    return {
        "id": raw_id,
        "name": f"Cycle {raw_id}",
        "milestone_title": f"Cycle {raw_id} — {scope}",
        "scope": scope,
        "depends_on": depends_on or [],
    }


def _make_runner() -> MagicMock:
    runner = MagicMock()
    runner.run = AsyncMock()
    return runner


def _make_state_dir(tmp_path: Path, st: State) -> Path:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    state_path = state_dir / "state.json"
    state_module.save_state(state_path, st)
    return state_path


# ---------------------------------------------------------------------------
# Delta planning: multi-cycle with completed cycles
# ---------------------------------------------------------------------------


class TestDeltaMultiCycleNewCycles:
    @pytest.mark.asyncio
    async def test_3_completed_plus_2_new_yields_5_total_cycles(self, tmp_path: Path) -> None:
        """3 completed cycles + Phase 0 returning 5 scopes → state has 5 cycles,
        first 3 completed, last 2 open, IDs 1–5."""
        st = _make_state(
            cycles=[
                _completed_cycle(1, "auth"),
                _completed_cycle(2, "api"),
                _completed_cycle(3, "database"),
            ]
        )
        state_path = _make_state_dir(tmp_path, st)

        raw_from_phase0 = [
            _raw_cycle(1, "auth"),
            _raw_cycle(2, "api"),
            _raw_cycle(3, "database"),
            _raw_cycle(4, "frontend", depends_on=[1]),
            _raw_cycle(5, "notifications", depends_on=[4]),
        ]

        with (
            patch(
                "code_generator.orchestrator.phase0_complexity.get_raw_cycle_plan",
                new=AsyncMock(return_value=raw_from_phase0),
            ),
            patch(
                "code_generator.orchestrator.cycle_loop.run_multi_cycle",
                new=AsyncMock(),
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
        ):
            await dispatch_async(
                st,
                tmp_path,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="multi-cycle",
                delta_hash=HASH_NEW,
                state_path=state_path,
            )

        assert len(st.cycles) == 5
        assert all(isinstance(c, CycleState) and c.status == "completed" for c in st.cycles[:3])
        assert all(isinstance(c, CycleState) and c.status == "open" for c in st.cycles[3:])
        assert all(isinstance(c, CycleState) for c in st.cycles)
        assert [c.id for c in st.cycles if isinstance(c, CycleState)] == [1, 2, 3, 4, 5]
        assert st.requirements_hash == HASH_NEW

    @pytest.mark.asyncio
    async def test_new_cycle_first_id_set_as_current_cycle(self, tmp_path: Path) -> None:
        """After delta planning, state.current_cycle is set to the first new cycle's ID."""
        st = _make_state(cycles=[_completed_cycle(1, "auth")])
        state_path = _make_state_dir(tmp_path, st)

        raw_from_phase0 = [
            _raw_cycle(1, "auth"),
            _raw_cycle(2, "frontend"),
        ]

        with (
            patch(
                "code_generator.orchestrator.phase0_complexity.get_raw_cycle_plan",
                new=AsyncMock(return_value=raw_from_phase0),
            ),
            patch(
                "code_generator.orchestrator.cycle_loop.run_multi_cycle",
                new=AsyncMock(),
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
        ):
            await dispatch_async(
                st,
                tmp_path,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="multi-cycle",
                delta_hash=HASH_NEW,
                state_path=state_path,
            )

        assert st.current_cycle == 2  # first new cycle

    @pytest.mark.asyncio
    async def test_depends_on_remapped_from_phase0_raw_ids_to_merged_state_ids(
        self, tmp_path: Path
    ) -> None:
        """New cycles get depends_on correctly remapped from Phase 0 raw IDs.

        Existing state has completed cycles 1=auth, 2=api, 3=database.
        Phase 0 returns raw IDs 1-5 where 4 and 5 are new.
        New cycle 4 (frontend) depends on Phase 0 raw id=1 (auth → state id=1).
        New cycle 5 (notifications) depends on Phase 0 raw id=4 (frontend → state id=4).
        """
        st = _make_state(
            cycles=[
                _completed_cycle(1, "auth"),
                _completed_cycle(2, "api"),
                _completed_cycle(3, "database"),
            ]
        )
        state_path = _make_state_dir(tmp_path, st)

        raw_from_phase0 = [
            _raw_cycle(1, "auth"),
            _raw_cycle(2, "api"),
            _raw_cycle(3, "database"),
            _raw_cycle(4, "frontend", depends_on=[1, 3]),
            _raw_cycle(5, "notifications", depends_on=[4]),
        ]

        with (
            patch(
                "code_generator.orchestrator.phase0_complexity.get_raw_cycle_plan",
                new=AsyncMock(return_value=raw_from_phase0),
            ),
            patch(
                "code_generator.orchestrator.cycle_loop.run_multi_cycle",
                new=AsyncMock(),
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
        ):
            await dispatch_async(
                st,
                tmp_path,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="multi-cycle",
                delta_hash=HASH_NEW,
                state_path=state_path,
            )

        frontend = next(c for c in st.cycles if isinstance(c, CycleState) and c.scope == "frontend")
        notifications = next(
            c for c in st.cycles if isinstance(c, CycleState) and c.scope == "notifications"
        )

        assert isinstance(frontend, CycleState)
        assert isinstance(notifications, CycleState)
        assert frontend.depends_on == [1, 3]  # remapped from Phase 0 ids 1,3 → state ids 1,3
        assert notifications.depends_on == [4]  # remapped from Phase 0 id 4 → state id 4


# ---------------------------------------------------------------------------
# Delta planning: no new cycles (identical scopes)
# ---------------------------------------------------------------------------


class TestDeltaNoNewCycles:
    @pytest.mark.asyncio
    async def test_identical_scopes_no_new_cycles_appended(self, tmp_path: Path) -> None:
        """When Phase 0 returns only existing scopes, no cycles are appended."""
        st = _make_state(cycles=[_completed_cycle(1, "auth"), _completed_cycle(2, "api")])
        state_path = _make_state_dir(tmp_path, st)
        original_cycle_count = len(st.cycles)

        raw_same_scopes = [_raw_cycle(1, "auth"), _raw_cycle(2, "api")]

        with (
            patch(
                "code_generator.orchestrator.phase0_complexity.get_raw_cycle_plan",
                new=AsyncMock(return_value=raw_same_scopes),
            ),
            patch(
                "code_generator.orchestrator.cycle_loop.run_multi_cycle",
                new=AsyncMock(),
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
        ):
            await dispatch_async(
                st,
                tmp_path,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="multi-cycle",
                delta_hash=HASH_NEW,
                state_path=state_path,
            )

        assert len(st.cycles) == original_cycle_count
        assert st.requirements_hash == HASH_NEW  # hash still updated

    @pytest.mark.asyncio
    async def test_identical_scopes_logs_no_new_cycles_message(self, tmp_path: Path) -> None:
        """When no new cycles are found, a 'no new cycles' log message is emitted."""
        st = _make_state(cycles=[_completed_cycle(1, "auth")])
        state_path = _make_state_dir(tmp_path, st)

        raw_same = [_raw_cycle(1, "auth")]
        mock_logger = MagicMock(spec=logging.Logger)

        with (
            patch(
                "code_generator.orchestrator.phase0_complexity.get_raw_cycle_plan",
                new=AsyncMock(return_value=raw_same),
            ),
            patch(
                "code_generator.orchestrator.cycle_loop.run_multi_cycle",
                new=AsyncMock(),
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
            patch(
                "code_generator.logging_setup.setup_phase_logger",
                return_value=mock_logger,
            ),
        ):
            await dispatch_async(
                st,
                tmp_path,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="multi-cycle",
                delta_hash=HASH_NEW,
                state_path=state_path,
            )

        all_info_calls = " ".join(str(call) for call in mock_logger.info.call_args_list)
        assert "no new cycles" in all_info_calls.lower()


# ---------------------------------------------------------------------------
# Delta planning: Phase 0 failure
# ---------------------------------------------------------------------------


class TestDeltaPhase0Failure:
    @pytest.mark.asyncio
    async def test_phase0_failure_leaves_cycles_unchanged(self, tmp_path: Path) -> None:
        """When Phase 0 returns None (failure), state.cycles must not be mutated."""
        original_cycles = [
            _completed_cycle(1, "auth"),
            _completed_cycle(2, "api"),
        ]
        st = _make_state(cycles=list(original_cycles))
        state_path = _make_state_dir(tmp_path, st)

        with (
            patch(
                "code_generator.orchestrator.phase0_complexity.get_raw_cycle_plan",
                new=AsyncMock(return_value=None),  # Phase 0 failed
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
        ):
            with pytest.raises(RuntimeError, match="[Pp]hase 0"):
                await dispatch_async(
                    st,
                    tmp_path,
                    dry_run=False,
                    start_phase=1,
                    start_cycle=None,
                    mode="multi-cycle",
                    delta_hash=HASH_NEW,
                    state_path=state_path,
                )

        assert len(st.cycles) == 2
        assert [c.id for c in st.cycles if isinstance(c, CycleState)] == [1, 2]

    @pytest.mark.asyncio
    async def test_phase0_failure_leaves_requirements_hash_unchanged(self, tmp_path: Path) -> None:
        """When Phase 0 fails during delta, requirements_hash must not be updated."""
        st = _make_state(
            cycles=[_completed_cycle(1, "auth")],
            requirements_hash=HASH_OLD,
        )
        state_path = _make_state_dir(tmp_path, st)

        with (
            patch(
                "code_generator.orchestrator.phase0_complexity.get_raw_cycle_plan",
                new=AsyncMock(return_value=None),
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
        ):
            with pytest.raises(RuntimeError):
                await dispatch_async(
                    st,
                    tmp_path,
                    dry_run=False,
                    start_phase=1,
                    start_cycle=None,
                    mode="multi-cycle",
                    delta_hash=HASH_NEW,
                    state_path=state_path,
                )

        assert st.requirements_hash == HASH_OLD


# ---------------------------------------------------------------------------
# Delta planning: idempotency
# ---------------------------------------------------------------------------


class TestDeltaIdempotency:
    @pytest.mark.asyncio
    async def test_second_delta_with_same_new_scopes_appends_nothing(self, tmp_path: Path) -> None:
        """Running delta planning twice with the same new scopes is idempotent."""
        st = _make_state(cycles=[_completed_cycle(1, "auth")])
        state_path = _make_state_dir(tmp_path, st)

        # Phase 0 always returns auth + frontend
        raw_with_new = [_raw_cycle(1, "auth"), _raw_cycle(2, "frontend")]

        run_multi = AsyncMock()

        with (
            patch(
                "code_generator.orchestrator.phase0_complexity.get_raw_cycle_plan",
                new=AsyncMock(return_value=raw_with_new),
            ),
            patch(
                "code_generator.orchestrator.cycle_loop.run_multi_cycle",
                run_multi,
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
        ):
            # First delta run
            await dispatch_async(
                st,
                tmp_path,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="multi-cycle",
                delta_hash=HASH_NEW,
                state_path=state_path,
            )

        assert len(st.cycles) == 2

        # Mark the new cycle completed to simulate a finished run
        assert isinstance(st.cycles[1], CycleState)
        st.cycles[1].status = "completed"
        state_module.save_state(state_path, st)

        # Second delta run with same new scopes (frontend is now completed too)
        HASH_NEWER = "c" * 64
        with (
            patch(
                "code_generator.orchestrator.phase0_complexity.get_raw_cycle_plan",
                new=AsyncMock(return_value=raw_with_new),
            ),
            patch(
                "code_generator.orchestrator.cycle_loop.run_multi_cycle",
                new=AsyncMock(),
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
        ):
            await dispatch_async(
                st,
                tmp_path,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="multi-cycle",
                delta_hash=HASH_NEWER,
                state_path=state_path,
            )

        # No new cycles should be appended — all scopes already exist
        assert len(st.cycles) == 2


# ---------------------------------------------------------------------------
# Delta planning: single-mode delta
# ---------------------------------------------------------------------------


class TestDeltaSingleMode:
    @pytest.mark.asyncio
    async def test_single_mode_delta_no_delta_hash_runs_normally(self, tmp_path: Path) -> None:
        """When delta_hash is None, dispatch_async runs without delta planning.

        Single-mode delta handling is done upstream in dispatch_orchestrator
        (it resets st.mode → "unknown" so Phase 0 re-runs naturally).
        This test verifies that dispatch_async itself doesn't break when
        delta_hash is omitted (backward compatibility).
        """
        st = _make_state(mode="single", cycles=[], requirements_hash=HASH_OLD)
        st.mode = "single"  # type: ignore[assignment]
        _make_state_dir(tmp_path, st)

        run_single = AsyncMock()

        with (
            patch(
                "code_generator.orchestrator.cycle_loop.run_single_mode",
                run_single,
            ),
            patch("code_generator.runner.get_runner", return_value=_make_runner()),
        ):
            await dispatch_async(
                st,
                tmp_path,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="single",
                delta_hash=None,  # No delta — normal path
            )

        run_single.assert_called_once()
