"""Tests for ``prompt-phase-8-finalization.md`` and ``prompt-phase-8-repair.md``.

Mirrors the registration/placeholder/content coverage of
``tests/test_phase6_5_prompt.py``. Locks the placeholder set, asserts each
prompt loads and substitutes cleanly, and verifies the named sentinels from
issue #326 (`CI_GREEN_GATE` for finalization, the patch-array directive for
repair) plus the YOLO + Constraints discipline used in every cycle prompt.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from code_generator import prompts as prompts_pkg
from code_generator.prompts import PLACEHOLDER_SPEC, PromptError, load_prompt

_FINALIZATION = "prompt-phase-8-finalization.md"
_REPAIR = "prompt-phase-8-repair.md"

_FINALIZATION_PLACEHOLDERS = frozenset({"CYCLE_NAME"})
_REPAIR_PLACEHOLDERS = frozenset({"CI_LOGS", "FAILING_JOBS", "ATTEMPT", "MAX_ATTEMPTS"})


def _finalization_kwargs() -> dict[str, str]:
    return {"CYCLE_NAME": "Cycle 4 — Testing"}


def _repair_kwargs() -> dict[str, str]:
    return {
        "CI_LOGS": "build failure log line",
        "FAILING_JOBS": "tests",
        "ATTEMPT": "1",
        "MAX_ATTEMPTS": "5",
    }


def _raw(filename: str) -> str:
    return (Path(prompts_pkg.__file__).parent / filename).read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# TestFinalizationPrompt — prompt-phase-8-finalization.md
# ---------------------------------------------------------------------------


class TestFinalizationPrompt:
    def test_when_placeholder_spec_loaded_then_prompt_is_registered(self) -> None:
        assert _FINALIZATION in PLACEHOLDER_SPEC

    def test_when_inspected_then_placeholder_set_matches_acceptance(self) -> None:
        assert PLACEHOLDER_SPEC[_FINALIZATION] == _FINALIZATION_PLACEHOLDERS

    def test_when_all_kwargs_supplied_then_prompt_loads_without_error(self) -> None:
        rendered = load_prompt(_FINALIZATION, **_finalization_kwargs())
        assert isinstance(rendered, str)
        assert len(rendered) > 0

    def test_when_substituted_then_cycle_name_value_appears(self) -> None:
        rendered = load_prompt(_FINALIZATION, **_finalization_kwargs())
        assert "Cycle 4 — Testing" in rendered
        assert "{CYCLE_NAME}" not in rendered

    def test_when_missing_placeholder_then_prompt_error_raised(self) -> None:
        with pytest.raises(PromptError, match="missing"):
            load_prompt(_FINALIZATION)

    def test_when_extra_placeholder_then_prompt_error_raised(self) -> None:
        kwargs = _finalization_kwargs()
        kwargs["UNEXPECTED"] = "x"
        with pytest.raises(PromptError, match="extra"):
            load_prompt(_FINALIZATION, **kwargs)

    def test_when_rendered_then_ci_green_gate_sentinel_present(self) -> None:
        rendered = load_prompt(_FINALIZATION, **_finalization_kwargs())
        assert "CI_GREEN_GATE" in rendered

    def test_when_rendered_then_yolo_mode_declared(self) -> None:
        rendered = load_prompt(_FINALIZATION, **_finalization_kwargs())
        assert "YOLO" in rendered

    def test_when_rendered_then_constraints_section_present(self) -> None:
        rendered = load_prompt(_FINALIZATION, **_finalization_kwargs())
        assert "### Constraints" in rendered or "## Constraints" in rendered

    def test_when_raw_read_then_no_dollar_brace_syntax(self) -> None:
        assert "${" not in _raw(_FINALIZATION)


# ---------------------------------------------------------------------------
# TestRepairPrompt — prompt-phase-8-repair.md
# ---------------------------------------------------------------------------


class TestRepairPrompt:
    def test_when_placeholder_spec_loaded_then_prompt_is_registered(self) -> None:
        assert _REPAIR in PLACEHOLDER_SPEC

    def test_when_inspected_then_placeholder_set_matches_acceptance(self) -> None:
        assert PLACEHOLDER_SPEC[_REPAIR] == _REPAIR_PLACEHOLDERS

    def test_when_all_kwargs_supplied_then_prompt_loads_without_error(self) -> None:
        rendered = load_prompt(_REPAIR, **_repair_kwargs())
        assert isinstance(rendered, str)
        assert len(rendered) > 0

    def test_when_substituted_then_every_placeholder_replaced(self) -> None:
        kwargs = _repair_kwargs()
        rendered = load_prompt(_REPAIR, **kwargs)
        for name, value in kwargs.items():
            assert value in rendered
            assert "{" + name + "}" not in rendered

    def test_when_missing_placeholder_then_prompt_error_raised(self) -> None:
        kwargs = _repair_kwargs()
        kwargs.pop("ATTEMPT")
        with pytest.raises(PromptError, match="missing"):
            load_prompt(_REPAIR, **kwargs)

    def test_when_rendered_then_patch_array_sentinel_present(self) -> None:
        rendered = load_prompt(_REPAIR, **_repair_kwargs())
        assert "Output patches as a JSON array" in rendered

    def test_when_raw_read_then_no_dollar_brace_syntax(self) -> None:
        assert "${" not in _raw(_REPAIR)


# ---------------------------------------------------------------------------
# TestCachePrefix — placeholder-token discipline on the stable prefix
# ---------------------------------------------------------------------------


class TestCachePrefix:
    """Cache-prefix discipline: rendered prefix must contain no ``{NAME}`` tokens.

    The 2048-byte cache window is a soft target — prompts shorter than 2048
    bytes still cache as a complete unit, just without ever splitting across
    the breakpoint. The hard invariant is that the *prefix portion* (whatever
    its length) carries no un-substituted ``{NAME}`` placeholders, otherwise
    the cache hash would shift per cycle and never re-hit.
    """

    @pytest.mark.parametrize(
        ("filename", "kwargs"),
        [
            (_FINALIZATION, _finalization_kwargs()),
            (_REPAIR, _repair_kwargs()),
        ],
    )
    def test_when_rendered_then_prefix_carries_no_placeholder_tokens(
        self, filename: str, kwargs: dict[str, str]
    ) -> None:
        rendered = load_prompt(filename, **kwargs)
        prefix = rendered[:2048]
        for placeholder in PLACEHOLDER_SPEC[filename]:
            assert "{" + placeholder + "}" not in prefix, (
                f"{filename}: un-substituted {{{placeholder}}} in cache prefix"
            )
