"""Tests for src/code_generator/runner/cache_breakpoints.py — issue #239.

Covers the §8 four-breakpoint layout invariants:

1. ``build_cache_breakpoints`` returns exactly four ``CacheBreakpoint`` entries
   in canonical BP1→BP4 order.
2. BP3 always emits a marker — even when ``cycle-repo-map.md`` is the fallback
   sentinel or the cycle-specialized prompt is absent (AC #6).
3. ``validate_breakpoints`` raises ``ValueError`` when any breakpoint sits more
   than 20 blocks past its predecessor (20-block lookback rule).
4. Volatile current-request blocks must never carry a cache marker — the
   validator rejects layouts that mark a volatile block.
5. The helper is the canonical builder consumed by ``_build_cycle_options``
   so the four-breakpoint layout is asserted at startup, not at runtime.
"""

from __future__ import annotations

import pytest

from code_generator.runner.cache_breakpoints import (
    CacheBreakpoint,
    build_cache_breakpoints,
    validate_breakpoints,
)

# ---------------------------------------------------------------------------
# build_cache_breakpoints — layout + ordering
# ---------------------------------------------------------------------------


class TestBuildCacheBreakpoints:
    def test_returns_exactly_four_entries(self) -> None:
        """The §8 layout has exactly four breakpoints — never more, never fewer."""
        breakpoints = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
        )
        assert len(breakpoints) == 4

    def test_canonical_bp1_bp2_bp3_bp4_ordering(self) -> None:
        """The returned list is in BP1→BP2→BP3→BP4 order."""
        breakpoints = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
        )
        names = [bp.name for bp in breakpoints]
        assert names == [
            "BP1_tools",
            "BP2_system",
            "BP3_repo_map_and_cycle_prompt",
            "BP4_boundary_user",
        ]

    def test_block_indices_match_inputs(self) -> None:
        """Each breakpoint's block_index reflects the input position."""
        breakpoints = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
        )
        assert breakpoints[0].block_index == 0
        assert breakpoints[1].block_index == 1
        # BP3 covers the LAST of repo-map / cycle-prompt so both contents sit
        # inside the cached prefix (Anthropic spec: cache extends backwards).
        assert breakpoints[2].block_index == 3
        assert breakpoints[3].block_index == 4

    def test_bp3_uses_repo_map_index_when_cycle_prompt_absent(self) -> None:
        """When the cycle-specialized prompt is absent, BP3 falls back to repo-map index (AC #6)."""
        breakpoints = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=None,
            boundary_user_block_index=3,
        )
        assert len(breakpoints) == 4, "BP3 must NEVER silently drop to three breakpoints"
        assert breakpoints[2].name == "BP3_repo_map_and_cycle_prompt"
        assert breakpoints[2].block_index == 2

    def test_default_cache_control_is_ephemeral_1h(self) -> None:
        """Default cache_control is ephemeral 1h (TTL assignment lives in #240)."""
        breakpoints = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
        )
        for bp in breakpoints:
            assert bp.cache_control == {"type": "ephemeral", "ttl": "1h"}

    def test_caller_supplied_cache_control_propagates_to_every_breakpoint(self) -> None:
        """A caller-supplied cache_control dict overrides the default on every entry."""
        custom = {"type": "ephemeral", "ttl": "5m"}
        breakpoints = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
            cache_control=custom,
        )
        for bp in breakpoints:
            assert bp.cache_control == custom

    def test_returns_breakpoint_instances(self) -> None:
        """Entries are CacheBreakpoint dataclass instances — typed, not bare dicts."""
        breakpoints = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
        )
        for bp in breakpoints:
            assert isinstance(bp, CacheBreakpoint)


# ---------------------------------------------------------------------------
# validate_breakpoints — 20-block lookback + volatile-no-marker
# ---------------------------------------------------------------------------


class TestValidateBreakpoints:
    def _layout(self, indices: tuple[int, int, int, int]) -> list[CacheBreakpoint]:
        return build_cache_breakpoints(
            tools_block_index=indices[0],
            system_block_index=indices[1],
            repo_map_block_index=indices[2],
            cycle_prompt_block_index=None,
            boundary_user_block_index=indices[3],
        )

    def test_accepts_layout_within_20_block_lookback(self) -> None:
        """Layout where every gap is <=20 blocks validates without raising."""
        validate_breakpoints(self._layout((0, 5, 18, 30)))

    def test_rejects_gap_of_21_blocks(self) -> None:
        """A breakpoint placed 21 blocks past its predecessor raises ValueError."""
        with pytest.raises(ValueError, match="20-block"):
            validate_breakpoints(self._layout((0, 5, 18, 39)))

    def test_rejects_out_of_order_breakpoints(self) -> None:
        """Block indices must be strictly ascending in BP1→BP4 order."""
        with pytest.raises(ValueError, match="ordered"):
            validate_breakpoints(self._layout((10, 5, 18, 30)))

    def test_rejects_marker_on_volatile_block(self) -> None:
        """Volatile current-request blocks must never receive a cache_control marker."""
        bps = self._layout((0, 5, 18, 30))
        # BP4 (block_index=30) is declared volatile — must be rejected.
        with pytest.raises(ValueError, match="volatile"):
            validate_breakpoints(bps, volatile_block_indices=[30])

    def test_accepts_when_no_volatile_blocks_match(self) -> None:
        """A volatile set that does not overlap with breakpoint indices is fine."""
        bps = self._layout((0, 5, 18, 30))
        validate_breakpoints(bps, volatile_block_indices=[31, 32, 99])

    def test_max_lookback_kwarg_is_configurable_for_tests(self) -> None:
        """The 20-block constant is exposed as an override so layout shifts can be tested."""
        bps = self._layout((0, 5, 18, 30))
        # With max_lookback=5 the gap 13 (5→18) is rejected.
        with pytest.raises(ValueError):
            validate_breakpoints(bps, max_lookback=5)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestModuleSurface:
    def test_max_lookback_constant_is_twenty(self) -> None:
        """The 20-block lookback rule is enshrined as a module-level constant."""
        from code_generator.runner.cache_breakpoints import MAX_LOOKBACK_BLOCKS

        assert MAX_LOOKBACK_BLOCKS == 20

    def test_breakpoint_count_constant_is_four(self) -> None:
        """The §8 layout cardinality is the module-level constant CACHE_BREAKPOINT_COUNT."""
        from code_generator.runner.cache_breakpoints import CACHE_BREAKPOINT_COUNT

        assert CACHE_BREAKPOINT_COUNT == 4


# ---------------------------------------------------------------------------
# _build_cycle_options consumes the helper (issue #239 wiring)
# ---------------------------------------------------------------------------


class TestClientLifecycleConsumesBreakpoints:
    def test_options_carry_cache_breakpoints_attribute(self, tmp_path) -> None:
        """_build_cycle_options exposes the four-breakpoint layout on options.cache_breakpoints."""
        from code_generator.orchestrator._client_lifecycle import _build_cycle_options

        opts = _build_cycle_options(tmp_path)
        breakpoints = getattr(opts, "cache_breakpoints", None)
        assert breakpoints is not None, (
            "options.cache_breakpoints must be set by _build_cycle_options"
        )
        assert len(breakpoints) == 4
        assert [bp.name for bp in breakpoints] == [
            "BP1_tools",
            "BP2_system",
            "BP3_repo_map_and_cycle_prompt",
            "BP4_boundary_user",
        ]


# ---------------------------------------------------------------------------
# Issue #245 — resolve_active_ttl helper
# ---------------------------------------------------------------------------


class _FakeState:
    def __init__(self, probe: str | None) -> None:
        self.cache_ttl_probe = probe


class _FakeCycle:
    def __init__(self, probe: str | None) -> None:
        self.cache_ttl_probe = probe


@pytest.mark.parametrize(
    ("bp_index", "expected"),
    [(0, "1h"), (1, "1h"), (2, "1h"), (3, "5m")],
)
def test_resolve_active_ttl_with_no_probe_falls_back_to_one_hour_layout(
    bp_index: int, expected: str
) -> None:
    """Missing probe data assumes the canonical '1h' layout (BP4 stays 5m)."""
    from code_generator.runner.cache_breakpoints import resolve_active_ttl

    state = _FakeState(probe=None)
    cycle = _FakeCycle(probe=None)
    assert resolve_active_ttl(state, cycle, bp_index=bp_index) == expected


@pytest.mark.parametrize(
    ("bp_index", "expected"),
    [(0, "1h"), (1, "1h"), (2, "1h"), (3, "5m")],
)
def test_resolve_active_ttl_with_one_hour_probe_routes_per_bp(bp_index: int, expected: str) -> None:
    """Probe '1h' yields BP1/BP2/BP3='1h' and BP4='5m'."""
    from code_generator.runner.cache_breakpoints import resolve_active_ttl

    cycle = _FakeCycle(probe="1h")
    state = _FakeState(probe=None)
    assert resolve_active_ttl(state, cycle, bp_index=bp_index) == expected


@pytest.mark.parametrize("bp_index", [0, 1, 2, 3])
def test_resolve_active_ttl_with_five_minute_probe_routes_uniform_5m(
    bp_index: int,
) -> None:
    """Probe '5m' routes every BP to '5m'."""
    from code_generator.runner.cache_breakpoints import resolve_active_ttl

    cycle = _FakeCycle(probe="5m")
    state = _FakeState(probe=None)
    assert resolve_active_ttl(state, cycle, bp_index=bp_index) == "5m"


def test_resolve_active_ttl_prefers_cycle_over_state_when_both_set() -> None:
    """Cycle-level probe takes precedence over State-level probe."""
    from code_generator.runner.cache_breakpoints import resolve_active_ttl

    cycle = _FakeCycle(probe="5m")
    state = _FakeState(probe="1h")
    assert resolve_active_ttl(state, cycle, bp_index=0) == "5m"


def test_resolve_active_ttl_uses_state_when_cycle_is_none() -> None:
    """Single-mode runs with no CycleState fall back to state.cache_ttl_probe."""
    from code_generator.runner.cache_breakpoints import resolve_active_ttl

    state = _FakeState(probe="1h")
    assert resolve_active_ttl(state, None, bp_index=3) == "5m"


def test_resolve_active_ttl_rejects_invalid_bp_index() -> None:
    """bp_index outside 0..3 raises ValueError — never silently picks a bucket."""
    from code_generator.runner.cache_breakpoints import resolve_active_ttl

    with pytest.raises(ValueError):
        resolve_active_ttl(_FakeState(probe="1h"), None, bp_index=4)
    with pytest.raises(ValueError):
        resolve_active_ttl(_FakeState(probe="1h"), None, bp_index=-1)
