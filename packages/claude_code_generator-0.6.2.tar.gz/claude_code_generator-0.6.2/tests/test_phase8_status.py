"""Unit tests for the Phase 8 rendering helpers in ``commands/status.py`` (#331).

Locks the rendering contract for ``_render_phase8_state``,
``_render_professionalized_summary``, and the per-issue ``[t,r,c,p]`` flag
line introduced by issue #321. Uses ``Console(record=True)`` capture so
assertions run against the rendered text rather than ANSI escapes.
"""

from __future__ import annotations

from pathlib import Path

from rich.console import Console

from code_generator import checklist as _checklist
from code_generator import state as _state
from code_generator.commands import status as status_module


def _capture(render_fn, *args, **kwargs) -> str:
    console = Console(record=True, width=200, force_terminal=False)
    render_fn(console, *args, **kwargs)
    return console.export_text()


def _state_with_phase8(ci_status: str | None) -> _state.State:
    st = _state.State(
        mode="single",
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    st.phase8 = _state.Phase8Progress(
        attempt=1,
        status="ok",
        ci_status=ci_status,
        started_at="2026-05-16T00:00:00Z",
        finished_at="2026-05-16T00:00:05Z",
    )
    return st


def _seed_checklist(
    project_dir: Path, requirements_hash: str, *, professionalized: int, total: int
) -> Path:
    checklist_path = project_dir / ".code-generator" / "checklists" / f"{requirements_hash}.json"
    issues = [
        _state.IssueState(number=n, status="open", agent="python-pro", title=f"Issue {n}")
        for n in range(1, total + 1)
    ]
    _checklist.seed(checklist_path, issues)
    for n in range(1, professionalized + 1):
        _checklist.tick_professionalized(checklist_path, n)
    return checklist_path


# ---------------------------------------------------------------------------
# _render_phase8_state
# ---------------------------------------------------------------------------


class TestRenderPhase8State:
    def test_render_phase8_state_none(self) -> None:
        """No ``phase8`` on scope → renders ``Phase 8: not run``."""
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        out = _capture(status_module._render_phase8_state, st)
        assert "Phase 8: not run" in out

    def test_render_phase8_state_with_ci_status(self) -> None:
        out = _capture(status_module._render_phase8_state, _state_with_phase8("green"))
        assert "ci_status=green" in out
        assert "status=ok" in out
        assert "attempt=1" in out

    def test_render_phase8_state_exhausted(self) -> None:
        out = _capture(status_module._render_phase8_state, _state_with_phase8("exhausted"))
        assert "ci_status=exhausted" in out

    def test_render_phase8_state_skipped(self) -> None:
        out = _capture(status_module._render_phase8_state, _state_with_phase8("skipped"))
        assert "ci_status=skipped" in out

    def test_render_phase8_state_ci_status_none_renders_dash(self) -> None:
        out = _capture(status_module._render_phase8_state, _state_with_phase8(None))
        assert "ci_status=-" in out


# ---------------------------------------------------------------------------
# _render_professionalized_summary
# ---------------------------------------------------------------------------


class TestProfessionalizedSummary:
    def test_professionalized_summary_renders_N_of_M(self, tmp_path: Path) -> None:
        cg = tmp_path / ".code-generator"
        cg.mkdir()
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = "abcd1234"
        _seed_checklist(tmp_path, "abcd1234", professionalized=2, total=3)

        out = _capture(status_module._render_professionalized_summary, st, tmp_path)

        assert "professionalized: 2/3" in out

    def test_professionalized_summary_missing_hash(self, tmp_path: Path) -> None:
        cg = tmp_path / ".code-generator"
        cg.mkdir()
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = None

        out = _capture(status_module._render_professionalized_summary, st, tmp_path)

        assert "professionalized: -" in out

    def test_professionalized_summary_missing_checklist_file(self, tmp_path: Path) -> None:
        cg = tmp_path / ".code-generator"
        cg.mkdir()
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = "abcd1234"  # file not created

        out = _capture(status_module._render_professionalized_summary, st, tmp_path)

        assert "professionalized: -" in out

    def test_professionalized_summary_zero_done(self, tmp_path: Path) -> None:
        cg = tmp_path / ".code-generator"
        cg.mkdir()
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = "abcd1234"
        _seed_checklist(tmp_path, "abcd1234", professionalized=0, total=4)

        out = _capture(status_module._render_professionalized_summary, st, tmp_path)

        assert "professionalized: 0/4" in out


# ---------------------------------------------------------------------------
# Per-issue [t,r,c,p] flag rendering
# ---------------------------------------------------------------------------


class TestPerIssueFlags:
    def test_per_issue_p_flag_shows_professionalized(self, tmp_path: Path) -> None:
        checklist_path = _seed_checklist(tmp_path, "abcd1234", professionalized=1, total=1)

        out = _capture(status_module._render_checklist_per_issue_flags, checklist_path)

        assert "#1[" in out
        # Last slot is the ``p`` flag.
        assert "#1[_,_,_,p]" in out

    def test_per_issue_p_flag_underscore_when_not_professionalized(self, tmp_path: Path) -> None:
        checklist_path = _seed_checklist(tmp_path, "abcd1234", professionalized=0, total=1)

        out = _capture(status_module._render_checklist_per_issue_flags, checklist_path)

        assert "#1[_,_,_,_]" in out

    def test_per_issue_legend_lists_professionalized(self, tmp_path: Path) -> None:
        checklist_path = _seed_checklist(tmp_path, "abcd1234", professionalized=0, total=1)

        out = _capture(status_module._render_checklist_per_issue_flags, checklist_path)

        assert "p=professionalized" in out


# ---------------------------------------------------------------------------
# Hostile fixture: legacy Phase8Progress without ``ci_status`` attribute
# ---------------------------------------------------------------------------


class TestLegacyPhase8Compatibility:
    def test_legacy_phase8_without_ci_status_attr_renders_dash(self) -> None:
        """Pre-Cycle-3 fixtures lack ``ci_status``; ``getattr`` default is used."""

        class _LegacyPhase8:
            attempt = 3
            status = "ok"

        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.phase8 = _LegacyPhase8()  # type: ignore[assignment]

        out = _capture(status_module._render_phase8_state, st)

        assert "Phase 8" in out
        assert "ci_status=-" in out
