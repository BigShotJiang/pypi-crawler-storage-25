"""Tests for code_generator.orchestrator.phase7_commit."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.git_ops import GitError
from code_generator.orchestrator import phase7_commit
from code_generator.orchestrator.phase7_commit import (
    Phase7CommitMessageError,
    _synthesize_fallback,
    _validate_commit_message,
)
from code_generator.runner.sdk_runner import RunResult

# ---------------------------------------------------------------------------
# Helpers — cycle factory
# ---------------------------------------------------------------------------


def _make_cycle(
    issues: list[_state.IssueState] | None = None,
    *,
    name: str = "Cycle 1",
    cycle_id: int = 1,
) -> _state.CycleState:
    return _state.CycleState(
        id=cycle_id,
        name=name,
        milestone_number=1,
        milestone_title=name,
        status="active",
        phase=7,
        issues=issues or [],
        commit_sha=None,
    )


if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "chore: cycle complete") -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state(
    tmp_path: Path,
    issues: list[_state.IssueState] | None = None,
) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    if issues:
        st.issues = issues
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPhase7Run:
    @pytest.fixture(autouse=True)
    def _mock_git_diff_cached(self):
        """Prevent real git subprocess calls in all Phase 7 tests."""
        with patch(
            "code_generator.orchestrator.phase7_commit.git_diff_cached",
            return_value="",
        ):
            yield

    @pytest.mark.asyncio
    async def test_skips_commit_when_nothing_staged(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("some msg")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=False,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit") as mock_commit,
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_commit.assert_not_called()

    @pytest.mark.asyncio
    async def test_commits_and_pushes_when_staged(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=1, status="closed", agent="python-pro")],
        )

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("feat: cycle 1 complete")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all") as mock_add,
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit") as mock_commit,
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push") as mock_push,
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_add.assert_called_once_with(tmp_path)
        mock_commit.assert_called_once_with(tmp_path, "feat: cycle 1 complete")
        mock_push.assert_called_once_with(tmp_path, "main")

    @pytest.mark.asyncio
    async def test_rebase_retry_on_push_rejection(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        push_calls = []

        def fake_push(cwd, branch):
            push_calls.append(len(push_calls))
            if len(push_calls) == 1:
                raise GitError(1, "rejected")

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("fix: rebase test")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_push",
                side_effect=fake_push,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_pull_rebase") as mock_rebase,
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(push_calls) == 2
        mock_rebase.assert_called_once_with(tmp_path)

    @pytest.mark.asyncio
    async def test_uses_opus_model(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("msg")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].model == "claude-opus-4-7"

    @pytest.mark.asyncio
    async def test_phase7_does_not_set_max_turns(self, tmp_path: Path) -> None:
        """Issue #208: Phase 7 must not hard-code a ``max_turns`` budget.

        Previously Phase 7 carried ``max_turns=10``; under the
        no-default-turn-budget policy (requirements §1) the kwarg is dropped
        so the SDK runs without a cap, with rate-limit / overage-abort /
        task-budgets acting as the real safety nets. A fire of
        ``MaxTurnsExceeded`` now signals a bug or explicit operator override.
        """
        state = _make_state(tmp_path)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("msg")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert getattr(captured_options[0], "max_turns", None) is None

    @pytest.mark.asyncio
    async def test_issues_closed_in_prompt(self, tmp_path: Path) -> None:
        state = _make_state(
            tmp_path,
            [
                _state.IssueState(number=3, status="closed", agent="python-pro"),
                _state.IssueState(number=7, status="closed", agent="python-pro"),
                _state.IssueState(number=9, status="open", agent="python-pro"),
            ],
        )
        captured_prompts = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result("msg")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        prompt = captured_prompts[0]
        assert "#3" in prompt
        assert "#7" in prompt
        # Open issue #9 should not appear.
        assert "#9" not in prompt

    @pytest.mark.asyncio
    async def test_fallback_commit_message_when_empty_result(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        commit_msgs = []

        def fake_commit(cwd, msg):
            commit_msgs.append(msg)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("")  # Empty text from Opus.

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_commit",
                side_effect=fake_commit,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert commit_msgs
        assert commit_msgs[0]  # Not empty.

    # ------------------------------------------------------------------
    # Multi-cycle mode: _closed_issue_numbers reads cycle.issues
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_closed_issue_numbers_multi_cycle_mode(self, tmp_path: Path) -> None:
        """_closed_issue_numbers reads from cycle.issues, not state.issues."""
        # State has a closed issue that must NOT appear in the prompt.
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=99, status="closed", agent="python-pro")],
        )
        # Cycle has its own closed issues that must appear.
        cycle = _make_cycle(
            issues=[
                _state.IssueState(number=10, status="closed", agent="python-pro"),
                _state.IssueState(number=20, status="open", agent="python-pro"),
            ]
        )
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result("feat: cycle 1 complete")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        prompt = captured_prompts[0]
        assert "#10" in prompt  # closed cycle issue → in prompt
        assert "#20" not in prompt  # open cycle issue → excluded
        assert "#99" not in prompt  # state.issues must not leak into cycle mode

    # ------------------------------------------------------------------
    # No closed issues: prompt must contain the literal word "none"
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_no_closed_issues_prompt_contains_none(self, tmp_path: Path) -> None:
        """When there are no closed issues, ISSUES_CLOSED is 'none' in the prompt."""
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=5, status="open", agent="python-pro")],
        )
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result("chore: no-op")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_prompts, "main_loop was never called"
        assert "none" in captured_prompts[0]

    # ------------------------------------------------------------------
    # Double push failure propagates GitError
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_double_push_failure_propagates_error(self, tmp_path: Path) -> None:
        """When both git push calls raise GitError, the error propagates."""
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("fix: something")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_push",
                side_effect=[GitError(1, "rejected"), GitError(1, "still rejected")],
            ),
            patch("code_generator.orchestrator.phase7_commit.git_pull_rebase"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            with pytest.raises(GitError):
                await phase7_commit.run(
                    state,
                    None,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=logging.getLogger("test"),
                )

    # ------------------------------------------------------------------
    # Whitespace-only commit message triggers default fallback
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_whitespace_only_message_triggers_fallback(self, tmp_path: Path) -> None:
        """A whitespace-only result from Opus uses the fallback commit message."""
        state = _make_state(tmp_path)
        commit_msgs: list[str] = []

        def fake_commit(cwd, msg):
            commit_msgs.append(msg)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("   \n\t  \n   ")  # whitespace only

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_commit",
                side_effect=fake_commit,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert commit_msgs, "git_commit was never called"
        assert commit_msgs[0].strip(), "commit message must not be empty"
        assert "chore:" in commit_msgs[0]  # fallback message format

    # ------------------------------------------------------------------
    # Effort wiring: phase 7 must use effort=low
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_effort_low_wired_into_options(self, tmp_path: Path) -> None:
        """Phase 7 resolves effort=low and passes it to make_agent_options."""
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("chore: done")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options, "make_agent_options was never called"
        assert hasattr(captured_options[0], "effort")
        assert captured_options[0].effort == "low"

    # ------------------------------------------------------------------
    # Pre-injected staged diff: STAGED_DIFF_STAT and STAGED_FILES in prompt
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_staged_diff_stat_injected_into_prompt(self, tmp_path: Path) -> None:
        """Phase 7 pre-fetches staged diff stat and injects it into the prompt."""
        state = _make_state(tmp_path)
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result("chore: done")

        diff_stat = "src/foo.py | 5 +++++\n1 file changed"
        diff_files = "src/foo.py"

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                side_effect=[diff_stat, diff_files],
            ),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_prompts, "main_loop was never called"
        prompt = captured_prompts[0]
        assert diff_stat in prompt, "STAGED_DIFF_STAT not injected into prompt"
        assert diff_files in prompt, "STAGED_FILES not injected into prompt"

    @pytest.mark.asyncio
    async def test_prompt_does_not_instruct_to_run_git_diff_cached(self, tmp_path: Path) -> None:
        """The rendered prompt must not instruct the model to run git diff --cached."""
        state = _make_state(tmp_path)
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result("chore: done")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                side_effect=["stat output", "files output"],
            ),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_prompts, "main_loop was never called"
        prompt = captured_prompts[0]
        # Prompt must not instruct the model to run these commands (old step 1 bash block).
        # The strings may still appear as section labels — what must be absent is the
        # imperative instruction pattern from the old prompt.
        assert "Read the diff" not in prompt, "Old step 1 instruction still present"
        assert "do not run `git diff` commands" in prompt, "Constraint phrase missing"

    @pytest.mark.asyncio
    async def test_diff_output_exceeding_20kb_is_truncated(self, tmp_path: Path) -> None:
        """Staged diff output exceeding 20KB is truncated with [TRUNCATED] marker."""
        state = _make_state(tmp_path)
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result("chore: done")

        # 21KB of content — exceeds the 20KB cap
        oversized_stat = "x" * (21 * 1024)
        oversized_files = "y" * (21 * 1024)

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                side_effect=[oversized_stat, oversized_files],
            ),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_prompts, "main_loop was never called"
        prompt = captured_prompts[0]
        # Accept both the phase7-specific marker and the shared truncate_placeholder marker
        has_truncation = "[TRUNCATED" in prompt or "[truncated," in prompt
        assert has_truncation, "Truncation marker missing from prompt"

    @pytest.mark.asyncio
    async def test_phase7_max_turns_unset_in_primary_call(self, tmp_path: Path) -> None:
        """Issue #208: Phase 7 primary call no longer hard-codes ``max_turns``.

        The earlier value of 10 has been removed per the no-default-turn-budget
        policy (requirements §1); the SDK call site must rely on rate-limit /
        overage-abort / task-budgets as the real safety nets.
        """
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("chore: done")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                side_effect=["stat output", "files output"],
            ),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options, "make_agent_options was never called"
        assert getattr(captured_options[0], "max_turns", None) is None


# ---------------------------------------------------------------------------
# Tests for shared truncate_placeholder delegation — issue #173
# ---------------------------------------------------------------------------


class TestPhase7TruncationDelegation:
    """Phase 7 must delegate diff truncation to prompts.truncate_placeholder, not inline logic."""

    @pytest.fixture(autouse=True)
    def _mock_git_diff_cached(self):
        """Prevent real git subprocess calls."""
        with patch(
            "code_generator.orchestrator.phase7_commit.git_diff_cached",
            return_value="",
        ):
            yield

    @pytest.mark.asyncio
    async def test_oversized_staged_diff_stat_is_truncated_via_shared_helper(
        self, tmp_path: Path
    ) -> None:
        """STAGED_DIFF_STAT exceeding 20KB must be truncated by prompts.truncate_placeholder."""
        from code_generator import prompts as _prompts

        state = _make_state(tmp_path)
        oversized = "x" * (21 * 1024)
        truncated_calls: list[str] = []
        original_fn = _prompts.truncate_placeholder

        def spy_truncate(text: object, max_tokens: int = 5000) -> str:
            truncated_calls.append(str(text)[:30])
            return original_fn(text, max_tokens)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("chore: done")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                side_effect=[oversized, oversized],
            ),
            patch("code_generator.prompts.truncate_placeholder", side_effect=spy_truncate),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert truncated_calls, "prompts.truncate_placeholder was never called"

    @pytest.mark.asyncio
    async def test_no_inline_cap_output_function_exists(self, tmp_path: Path) -> None:
        """The _cap_output helper must be removed; truncation is owned by load_prompt."""
        assert not hasattr(phase7_commit, "_cap_output"), (
            "_cap_output must be removed from phase7_commit — use prompts.truncate_placeholder"
        )


# ---------------------------------------------------------------------------
# Tests for _synthesize_fallback — issue #141
# ---------------------------------------------------------------------------


class TestSynthesizeFallback:
    def test_with_cycle_name_and_issues_returns_scoped_message_with_footer(self) -> None:
        """_synthesize_fallback with cycle_name and issues returns conventional-commit + footer."""
        result = _synthesize_fallback(cycle_name="Phase 5", issues_closed="#113, #114")
        assert result == "chore(Phase 5): cycle complete\n\nClosed issues: #113, #114"

    def test_with_empty_cycle_name_and_none_issues_returns_bare_message(self) -> None:
        """_synthesize_fallback with empty cycle_name and 'none' issues returns bare chore."""
        result = _synthesize_fallback(cycle_name="", issues_closed="none")
        assert result == "chore: cycle complete"

    def test_with_empty_cycle_name_no_parens_in_subject(self) -> None:
        """Empty cycle_name must not produce empty parens like 'chore(): ...'."""
        result = _synthesize_fallback(cycle_name="", issues_closed="none")
        assert "()" not in result

    def test_with_single_issue_includes_footer(self) -> None:
        """_synthesize_fallback with a single issue includes 'Closed issues: #1' footer."""
        result = _synthesize_fallback(cycle_name="DB Layer", issues_closed="#1")
        assert "Closed issues: #1" in result

    def test_none_issues_omits_footer(self) -> None:
        """When issues_closed is 'none', no footer paragraph is appended."""
        result = _synthesize_fallback(cycle_name="Phase 5", issues_closed="none")
        assert "Closed issues" not in result


# ---------------------------------------------------------------------------
# Tests for Phase7CommitMessageError — issue #141
# ---------------------------------------------------------------------------


class TestPhase7CommitMessageError:
    def test_is_subclass_of_runtime_error(self) -> None:
        """Phase7CommitMessageError must be a subclass of RuntimeError."""
        assert issubclass(Phase7CommitMessageError, RuntimeError)

    def test_can_be_raised_and_caught_as_runtime_error(self) -> None:
        """Phase7CommitMessageError can be raised and caught as RuntimeError."""
        with pytest.raises(RuntimeError):
            raise Phase7CommitMessageError("bad message")


# ---------------------------------------------------------------------------
# Tests for _validate_commit_message — issue #141
# ---------------------------------------------------------------------------


class TestValidateCommitMessage:
    def test_valid_feat_message_does_not_raise(self) -> None:
        """_validate_commit_message does not raise for a valid feat: message with body."""
        _validate_commit_message("feat: add X\n\nbody")  # must not raise

    def test_valid_fix_message_does_not_raise(self) -> None:
        """_validate_commit_message does not raise for a valid fix: message."""
        _validate_commit_message("fix: correct typo")  # must not raise

    def test_valid_chore_message_with_scope_does_not_raise(self) -> None:
        """_validate_commit_message does not raise for chore(scope): message."""
        _validate_commit_message("chore(Phase 5): cycle complete\n\nClosed issues: #1")

    def test_garbage_message_raises_phase7_error(self) -> None:
        """_validate_commit_message raises Phase7CommitMessageError for garbage input."""
        with pytest.raises(Phase7CommitMessageError):
            _validate_commit_message("random garbage")

    def test_empty_string_raises_phase7_error(self) -> None:
        """_validate_commit_message raises Phase7CommitMessageError for empty string."""
        with pytest.raises(Phase7CommitMessageError):
            _validate_commit_message("")

    def test_message_with_valid_first_line_and_bad_body_does_not_raise(self) -> None:
        """Only the first line is validated; body content is irrelevant."""
        _validate_commit_message("feat: something\n\nnot a commit line at all!!!")


# ---------------------------------------------------------------------------
# Tests for issue #143 — integration of extraction, retry, and fallback
# ---------------------------------------------------------------------------


class TestPhase7Integration:
    """Integration tests for the extraction → retry → fallback pipeline."""

    @pytest.fixture(autouse=True)
    def _mock_git_diff_cached(self):
        """Prevent real git subprocess calls in all integration tests."""
        with patch(
            "code_generator.orchestrator.phase7_commit.git_diff_cached",
            return_value="",
        ):
            yield

    @pytest.mark.asyncio
    async def test_both_attempts_fail_uses_fallback_and_logs_error(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Chatter on both attempts → synthesized fallback used, ERROR logged with raw_head=."""
        state = _make_state(
            tmp_path,
            [_state.IssueState(number=5, status="closed", agent="python-pro")],
        )
        chatter = "Here is my analysis of the staged changes. I have enough context now."
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _make_run_result(chatter)

        commit_msgs: list[str] = []

        def fake_commit(cwd, msg):
            commit_msgs.append(msg)

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_commit",
                side_effect=fake_commit,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
            caplog.at_level(logging.ERROR, logger="test"),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # Two attempts must be made
        assert call_count == 2, f"Expected 2 calls to main_loop, got {call_count}"

        # Fallback is used (not raw chatter)
        assert commit_msgs, "git_commit was never called"
        assert commit_msgs[0] != chatter, "Chatter must not be committed verbatim"
        assert "chore:" in commit_msgs[0], f"Expected fallback format, got: {commit_msgs[0]!r}"

        # ERROR must be logged with raw_head=
        error_records = [r for r in caplog.records if r.levelno >= logging.ERROR]
        assert error_records, "No ERROR log record found"
        error_texts = " ".join(r.getMessage() for r in error_records)
        assert "raw_head=" in error_texts, "ERROR log must include raw_head= prefix"

    @pytest.mark.asyncio
    async def test_chatter_then_valid_uses_retry_result(self, tmp_path: Path) -> None:
        """Chatter on attempt 1, valid message on attempt 2 → attempt-2 message is committed."""
        state = _make_state(tmp_path)
        chatter = "Let me think about the best commit message for these changes."
        valid_msg = "feat: add extraction pipeline for commit messages"
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            text = chatter if call_count == 1 else valid_msg
            return _make_run_result(text)

        commit_msgs: list[str] = []

        def fake_commit(cwd, msg):
            commit_msgs.append(msg)

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_commit",
                side_effect=fake_commit,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 2, f"Expected 2 calls to main_loop, got {call_count}"
        assert commit_msgs, "git_commit was never called"
        assert commit_msgs[0] == valid_msg, (
            f"Expected attempt-2 message {valid_msg!r}, got {commit_msgs[0]!r}"
        )

    @pytest.mark.asyncio
    async def test_fallback_includes_closed_issues_footer_when_present(
        self, tmp_path: Path
    ) -> None:
        """When chatter forces fallback and closed_numbers is non-empty, footer is included."""
        state = _make_state(
            tmp_path,
            [
                _state.IssueState(number=7, status="closed", agent="python-pro"),
                _state.IssueState(number=12, status="closed", agent="python-pro"),
            ],
        )
        chatter = "Here is the summary of my changes..."

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result(chatter)

        commit_msgs: list[str] = []

        def fake_commit(cwd, msg):
            commit_msgs.append(msg)

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_commit",
                side_effect=fake_commit,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert commit_msgs, "git_commit was never called"
        final_msg = commit_msgs[0]
        assert "Closed issues:" in final_msg, (
            f"Expected 'Closed issues:' footer in fallback, got: {final_msg!r}"
        )
        assert "#7" in final_msg and "#12" in final_msg, (
            f"Expected issue numbers in fallback footer, got: {final_msg!r}"
        )

    @pytest.mark.asyncio
    async def test_missing_prompt_sentinel_raises_prompt_error_at_startup(
        self, tmp_path: Path
    ) -> None:
        """PromptError raised at Phase 7 start when prompt hardening sentinel is absent."""
        from code_generator.prompts import PromptError

        state = _make_state(tmp_path)
        # A prompt without the sentinel string
        prompt_without_sentinel = "chore: cycle complete\nNo hardening here."

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch(
                "code_generator.orchestrator.phase7_commit.load_prompt",
                return_value=prompt_without_sentinel,
            ),
        ):
            with pytest.raises(PromptError):
                await phase7_commit.run(
                    state,
                    None,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=logging.getLogger("test"),
                )


# ---------------------------------------------------------------------------
# Issue #250 — Phase 7 ticks committed for closed issues only after push
# ---------------------------------------------------------------------------


def _seed_phase7_checklist(
    tmp_path: Path, requirements_hash: str, issue_numbers: list[int]
) -> Path:
    from code_generator import checklist

    checklist_path = tmp_path / ".code-generator" / "checklists" / f"{requirements_hash}.json"
    issues = [
        _state.IssueState(number=n, status="open", agent="python-pro", title=f"Issue {n}")
        for n in issue_numbers
    ]
    checklist.seed(checklist_path, issues)
    return checklist_path


class TestPhase7ChecklistTicks:
    @pytest.mark.asyncio
    async def test_phase7_ticks_committed_for_each_closed_issue_after_push(
        self, tmp_path: Path
    ) -> None:
        from code_generator import checklist

        closed = [
            _state.IssueState(number=1, status="closed", agent="python-pro", title="A"),
            _state.IssueState(number=2, status="closed", agent="python-pro", title="B"),
        ]
        state = _make_state(tmp_path, issues=closed)
        state.requirements_hash = "abcd1234"
        checklist_path = _seed_phase7_checklist(tmp_path, "abcd1234", [1, 2])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("chore: cycle complete")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        entries = {e.issue_number: e for e in checklist.load(checklist_path)}
        assert entries[1].committed is True
        assert entries[2].committed is True

    @pytest.mark.asyncio
    async def test_phase7_does_not_tick_when_push_raises(self, tmp_path: Path) -> None:
        from code_generator import checklist

        closed = [_state.IssueState(number=1, status="closed", agent="python-pro", title="A")]
        state = _make_state(tmp_path, issues=closed)
        state.requirements_hash = "abcd1234"
        checklist_path = _seed_phase7_checklist(tmp_path, "abcd1234", [1])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("chore: cycle complete")

        # First push raises; rebase-retry also raises → tick must not fire.
        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_push",
                side_effect=GitError(1, "push rejected"),
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_pull_rebase",
                side_effect=GitError(1, "rebase failed"),
            ),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
            pytest.raises(GitError),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        entry = checklist.load(checklist_path)[0]
        assert entry.committed is False

    @pytest.mark.asyncio
    async def test_feature_done_false_when_only_committed_set(self, tmp_path: Path) -> None:
        """Phase 6 raised → tests_passed False; Phase 7 still runs in isolation
        in this test → committed True. feature_done must be False."""
        from code_generator import checklist

        closed = [_state.IssueState(number=1, status="closed", agent="python-pro", title="A")]
        state = _make_state(tmp_path, issues=closed)
        state.requirements_hash = "abcd1234"
        checklist_path = _seed_phase7_checklist(tmp_path, "abcd1234", [1])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("chore: cycle complete")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        entry = checklist.load(checklist_path)[0]
        assert entry.committed is True
        assert entry.tests_passed is False
        assert entry.feature_done is False

    @pytest.mark.asyncio
    async def test_feature_done_true_when_all_ticks_set(self, tmp_path: Path) -> None:
        from code_generator import checklist

        closed = [_state.IssueState(number=1, status="closed", agent="python-pro", title="A")]
        state = _make_state(tmp_path, issues=closed)
        state.requirements_hash = "abcd1234"
        checklist_path = _seed_phase7_checklist(tmp_path, "abcd1234", [1])
        # Pre-tick tests_passed (Phase 6), runtime_verified (Phase 6.5),
        # professionalized (Phase 8). Phase 7 ticks `committed` below.
        checklist.tick_tests_passed(checklist_path, 1)
        checklist.tick_runtime_verified(checklist_path, 1)
        checklist.tick_professionalized(checklist_path, 1)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("chore: cycle complete")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        entry = checklist.load(checklist_path)[0]
        assert entry.tests_passed is True
        assert entry.committed is True
        assert entry.feature_done is True

    @pytest.mark.asyncio
    async def test_phase7_skips_tick_when_requirements_hash_missing(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        closed = [_state.IssueState(number=1, status="closed", agent="python-pro", title="A")]
        state = _make_state(tmp_path, issues=closed)
        state.requirements_hash = None

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("chore: cycle complete")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch(
                "code_generator.orchestrator.phase7_commit.git_diff_cached",
                return_value="",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
            caplog.at_level(logging.WARNING),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        checklists_dir = tmp_path / ".code-generator" / "checklists"
        assert not checklists_dir.exists()
        assert any("requirements_hash" in rec.getMessage().lower() for rec in caplog.records)
