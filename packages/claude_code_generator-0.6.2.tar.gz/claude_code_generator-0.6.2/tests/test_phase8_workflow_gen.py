"""Tests for code_generator.orchestrator.phase8_workflow_gen."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from code_generator.orchestrator.phase8_workflow_gen import (
    MANAGED_MARKER,
    WorkflowFile,
    detect_project_kind,
    generate_workflows,
    scan_for_guardrail_violations,
)

# ---------------------------------------------------------------------------
# detect_project_kind
# ---------------------------------------------------------------------------


class TestDetectProjectKind:
    def test_when_pyproject_present_returns_python(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        assert detect_project_kind(tmp_path) == "python"

    def test_when_package_json_present_returns_node(self, tmp_path: Path) -> None:
        (tmp_path / "package.json").write_text('{"name": "x"}')
        assert detect_project_kind(tmp_path) == "node"

    def test_when_both_present_prefers_python(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        (tmp_path / "package.json").write_text('{"name": "x"}')
        assert detect_project_kind(tmp_path) == "python"

    def test_when_neither_present_returns_unknown(self, tmp_path: Path) -> None:
        assert detect_project_kind(tmp_path) == "unknown"


# ---------------------------------------------------------------------------
# WorkflowFile
# ---------------------------------------------------------------------------


class TestWorkflowFile:
    def test_is_frozen(self) -> None:
        wf = WorkflowFile(rel_path=".github/workflows/ci.yml", content="x")
        with pytest.raises((AttributeError, Exception)):
            wf.content = "y"  # type: ignore[misc]

    def test_content_can_be_none_for_skip_write(self) -> None:
        wf = WorkflowFile(rel_path=".github/workflows/ci.yml", content=None)
        assert wf.content is None


# ---------------------------------------------------------------------------
# generate_workflows — green field
# ---------------------------------------------------------------------------


class TestGenerateWorkflowsGreenField:
    def test_when_python_project_returns_ci_and_release_files(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        files = generate_workflows(tmp_path)

        rel_paths = [f.rel_path for f in files]
        assert ".github/workflows/ci.yml" in rel_paths
        assert ".github/workflows/release.yml" in rel_paths

    def test_when_python_ci_yaml_round_trips(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        ci = next(f for f in generate_workflows(tmp_path) if f.rel_path.endswith("ci.yml"))
        parsed = yaml.safe_load(ci.content or "")
        assert isinstance(parsed, dict)
        assert parsed["name"]
        # PyYAML parses bare `on` (without quotes) as True. The YAML emitted by
        # this module must quote it so the key is a string after round-trip.
        assert "on" in parsed
        triggers = parsed["on"]
        assert "push" in triggers
        assert "pull_request" in triggers
        assert "jobs" in parsed

    def test_when_python_ci_calls_pip_install_and_ruff_and_pytest(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        ci = next(f for f in generate_workflows(tmp_path) if f.rel_path.endswith("ci.yml"))
        body = ci.content or ""
        assert "pip install -e .[dev]" in body
        assert "ruff check" in body
        assert "pytest" in body

    def test_when_node_ci_calls_npm_ci_lint_test(self, tmp_path: Path) -> None:
        (tmp_path / "package.json").write_text('{"name": "x"}')
        ci = next(f for f in generate_workflows(tmp_path) if f.rel_path.endswith("ci.yml"))
        body = ci.content or ""
        assert "npm ci" in body
        assert "npm run lint" in body
        assert "npm test" in body

    def test_when_unknown_stack_emits_minimal_echo_workflow(self, tmp_path: Path) -> None:
        ci = next(f for f in generate_workflows(tmp_path) if f.rel_path.endswith("ci.yml"))
        body = ci.content or ""
        assert "echo" in body
        parsed = yaml.safe_load(body)
        assert isinstance(parsed, dict)

    def test_when_release_yaml_triggers_on_v_tag_pattern(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        rel = next(f for f in generate_workflows(tmp_path) if f.rel_path.endswith("release.yml"))
        parsed = yaml.safe_load(rel.content or "")
        triggers = parsed["on"]
        assert "push" in triggers
        tags = triggers["push"]["tags"]
        assert "v*" in tags

    def test_when_emitted_content_carries_managed_marker(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        for wf in generate_workflows(tmp_path):
            assert MANAGED_MARKER in (wf.content or "")


# ---------------------------------------------------------------------------
# generate_workflows — upgrade rule
# ---------------------------------------------------------------------------


class TestGenerateWorkflowsUpgradeRule:
    def _seed_python(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        (tmp_path / ".github" / "workflows").mkdir(parents=True)

    def test_when_existing_managed_file_present_returns_new_content(self, tmp_path: Path) -> None:
        self._seed_python(tmp_path)
        (tmp_path / ".github" / "workflows" / "ci.yml").write_text(
            f"# {MANAGED_MARKER}\nname: old\n"
        )
        ci = next(f for f in generate_workflows(tmp_path) if f.rel_path.endswith("ci.yml"))
        assert ci.content is not None
        assert "name: old" not in ci.content

    def test_when_existing_unmanaged_file_present_returns_none_content(
        self, tmp_path: Path
    ) -> None:
        self._seed_python(tmp_path)
        (tmp_path / ".github" / "workflows" / "ci.yml").write_text(
            "name: user-managed\non: push\njobs: {}\n"
        )
        ci = next(f for f in generate_workflows(tmp_path) if f.rel_path.endswith("ci.yml"))
        assert ci.content is None

    def test_when_no_existing_file_returns_generated_content(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        ci = next(f for f in generate_workflows(tmp_path) if f.rel_path.endswith("ci.yml"))
        assert ci.content is not None
        assert MANAGED_MARKER in ci.content


# ---------------------------------------------------------------------------
# scan_for_guardrail_violations
# ---------------------------------------------------------------------------


class TestScanForGuardrailViolations:
    def test_when_continue_on_error_true_returns_violation(self) -> None:
        body = "jobs:\n  test:\n    steps:\n      - run: pytest\n        continue-on-error: true\n"
        assert "continue-on-error" in scan_for_guardrail_violations(body)

    def test_when_continue_on_error_false_returns_no_violation_for_it(
        self,
    ) -> None:
        body = "jobs:\n  test:\n    continue-on-error: false\n"
        assert "continue-on-error" not in scan_for_guardrail_violations(body)

    def test_when_if_false_skip_returns_violation(self) -> None:
        body = "jobs:\n  test:\n    if: false\n    steps:\n      - run: pytest\n"
        assert "if-false-skip" in scan_for_guardrail_violations(body)

    def test_when_no_test_step_returns_missing_test_violation(self) -> None:
        body = "jobs:\n  build:\n    steps:\n      - run: pip install .\n"
        assert "missing-test-step" in scan_for_guardrail_violations(body)

    def test_when_no_lint_step_returns_missing_lint_violation(self) -> None:
        body = "jobs:\n  test:\n    steps:\n      - run: pytest\n"
        assert "missing-lint-step" in scan_for_guardrail_violations(body)

    def test_when_clean_workflow_returns_empty_list(self) -> None:
        body = (
            "name: ci\n"
            "on: push\n"
            "jobs:\n"
            "  ci:\n"
            "    runs-on: ubuntu-latest\n"
            "    steps:\n"
            "      - run: ruff check\n"
            "      - run: pytest\n"
        )
        assert scan_for_guardrail_violations(body) == []
