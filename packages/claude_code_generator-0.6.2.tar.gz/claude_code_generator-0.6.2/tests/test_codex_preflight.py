"""Tests for the Codex preflight (binary + auth + trust-seed checks)."""

from unittest.mock import patch

import pytest

from code_generator.preflight import (
    PreflightError,
    _require_codex_trust,
    run_codex_preflight,
)


def test_binary_missing_raises():
    with patch("shutil.which", return_value=None):
        with pytest.raises(PreflightError, match="codex CLI binary not found"):
            run_codex_preflight()


def test_auth_missing_raises_and_openai_key_does_not_satisfy(tmp_path, monkeypatch):
    monkeypatch.setenv("CODEX_HOME", str(tmp_path))
    monkeypatch.setenv("OPENAI_API_KEY", "sk-should-not-count")
    with patch("shutil.which", return_value="/usr/local/bin/codex"):
        with pytest.raises(PreflightError) as exc_info:
            run_codex_preflight()
    assert exc_info.value.fix_command == "codex login"


def test_auth_present_via_auth_json_passes(tmp_path, monkeypatch):
    monkeypatch.setenv("CODEX_HOME", str(tmp_path))
    (tmp_path / "auth.json").write_text("{}", encoding="utf-8")
    project = tmp_path / "proj"
    project.mkdir()
    monkeypatch.chdir(project)
    with patch("shutil.which", return_value="/usr/local/bin/codex"):
        run_codex_preflight()  # must not raise
    # Trust seed must have been written so headless codex never hangs.
    config = (tmp_path / "config.toml").read_text(encoding="utf-8")
    assert 'trust_level = "trusted"' in config
    assert str(project) in config


def test_trust_seed_is_idempotent(tmp_path, monkeypatch):
    monkeypatch.setenv("CODEX_HOME", str(tmp_path))
    project = tmp_path / "proj"
    project.mkdir()
    monkeypatch.chdir(project)

    _require_codex_trust()
    first = (tmp_path / "config.toml").read_text(encoding="utf-8")
    _require_codex_trust()
    second = (tmp_path / "config.toml").read_text(encoding="utf-8")
    assert first == second  # second call is a no-op
    assert second.count('trust_level = "trusted"') == 1


def test_trust_seed_preserves_existing_unrelated_content(tmp_path, monkeypatch):
    monkeypatch.setenv("CODEX_HOME", str(tmp_path))
    project = tmp_path / "proj"
    project.mkdir()
    monkeypatch.chdir(project)
    config_path = tmp_path / "config.toml"
    config_path.write_text('[model]\nname = "gpt-5.5"\n', encoding="utf-8")

    _require_codex_trust()
    text = config_path.read_text(encoding="utf-8")
    assert "[model]" in text
    assert 'name = "gpt-5.5"' in text
    assert 'trust_level = "trusted"' in text
    assert str(project) in text
