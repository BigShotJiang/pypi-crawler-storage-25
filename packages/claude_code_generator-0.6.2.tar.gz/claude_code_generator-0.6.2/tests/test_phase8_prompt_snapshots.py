"""Drift lock for ``prompt-phase-8-finalization.md`` + ``prompt-phase-8-repair.md`` (#326).

Mirrors :mod:`tests.test_phase6_5_prompt_snapshot`. Each Phase 8 prompt has a
committed fixture under ``tests/fixtures/prompt_prefix_snapshots/`` containing
the rendered bytes (truncated to 2048 when longer, full content when shorter).
A byte-for-byte mismatch fails CI before the cache-stable region silently
drifts.

Regenerate via::

    python -m tests.regenerate_prompt_snapshots
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from code_generator.prompts import PLACEHOLDER_SPEC, load_prompt
from code_generator.prompts.hashes import compute_all_prompt_hashes
from tests.test_prompt_prefix_snapshots import PLACEHOLDER_SNAPSHOT_FIXTURES

_PREFIX_BYTES = 2048
_FIXTURE_DIR = Path(__file__).parent / "fixtures" / "prompt_prefix_snapshots"
_SHA256_HEX_RE = re.compile(r"^[0-9a-f]{64}$")

_FINALIZATION = "prompt-phase-8-finalization.md"
_REPAIR = "prompt-phase-8-repair.md"
_PROMPTS = (_FINALIZATION, _REPAIR)


def _render_neutral(filename: str) -> bytes:
    spec = PLACEHOLDER_SPEC[filename]
    kwargs = {name: PLACEHOLDER_SNAPSHOT_FIXTURES[name] for name in spec}
    return load_prompt(filename, **kwargs).encode("utf-8")


def _fixture_path(filename: str) -> Path:
    return _FIXTURE_DIR / filename.replace(".md", ".txt")


@pytest.mark.parametrize("filename", _PROMPTS)
def test_when_phase8_prompt_rendered_then_prefix_matches_snapshot(filename: str) -> None:
    """Rendered ``prompt[:2048]`` must equal the committed fixture byte-for-byte."""
    path = _fixture_path(filename)
    assert path.exists(), (
        f"Missing snapshot fixture: {path}. "
        "Run `python -m tests.regenerate_prompt_snapshots` to generate it."
    )

    snapshot_bytes = path.read_bytes()
    rendered_prefix = _render_neutral(filename)[:_PREFIX_BYTES]

    assert rendered_prefix == snapshot_bytes, (
        f"{filename}: rendered prefix drifted from committed snapshot. "
        "If intentional, regenerate via `python -m tests.regenerate_prompt_snapshots`."
    )


@pytest.mark.parametrize("filename", _PROMPTS)
def test_when_placeholder_spec_loaded_then_phase8_prompt_is_registered(filename: str) -> None:
    assert filename in PLACEHOLDER_SPEC


def test_when_finalization_spec_inspected_then_placeholder_set_locked() -> None:
    assert PLACEHOLDER_SPEC[_FINALIZATION] == frozenset({"CYCLE_NAME"})


def test_when_repair_spec_inspected_then_placeholder_set_locked() -> None:
    assert PLACEHOLDER_SPEC[_REPAIR] == frozenset(
        {"CI_LOGS", "FAILING_JOBS", "ATTEMPT", "MAX_ATTEMPTS"}
    )


@pytest.mark.parametrize("filename", _PROMPTS)
def test_when_raw_prompt_read_then_no_dollar_brace_syntax_present(filename: str) -> None:
    import importlib.resources

    raw = importlib.resources.files("code_generator.prompts").joinpath(filename).read_bytes()
    assert b"${" not in raw


@pytest.mark.parametrize("filename", _PROMPTS)
def test_when_all_prompt_hashes_computed_then_phase8_hash_is_64_char_hex(
    filename: str,
) -> None:
    hashes = compute_all_prompt_hashes()
    assert filename in hashes
    assert _SHA256_HEX_RE.match(hashes[filename])
