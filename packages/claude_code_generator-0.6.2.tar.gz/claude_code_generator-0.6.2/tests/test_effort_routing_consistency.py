"""Consistency check: CLAUDE.md phase table agrees with effort._BASELINE_MODEL.

Non-negotiable #8 (Fixed model per phase) requires the runtime mapping and the
documented mapping to never disagree. This test parses the markdown table near
the "Architecture" heading in CLAUDE.md and asserts pairwise model agreement
with `code_generator.effort._BASELINE_MODEL`.
"""

from __future__ import annotations

import pathlib
import re

import pytest

from code_generator.effort import _BASELINE_MODEL

_REPO_ROOT = pathlib.Path(__file__).resolve().parent.parent
_CLAUDE_MD = _REPO_ROOT / "CLAUDE.md"

_DOC_TO_CANONICAL: dict[str, str] = {
    "Opus 4.7": "claude-opus-4-7",
    "Sonnet 4.6": "claude-sonnet-4-6",
    "Haiku 4.5": "claude-haiku-4-5-20251001",
}


def _parse_phase_table() -> dict[int, str]:
    """Return {phase_int: doc_model_string} parsed from the CLAUDE.md phase table."""
    text = _CLAUDE_MD.read_text(encoding="utf-8")
    pattern = re.compile(
        r"^\|\s*(\d+(?:/\d+)?)\s*\|\s*`?phase[^`|]+`?\s*\|\s*([^|]+?)\s*\|",
        re.MULTILINE,
    )
    rows: dict[int, str] = {}
    for match in pattern.finditer(text):
        phase_token = match.group(1)
        model_doc = match.group(2).strip()
        for part in phase_token.split("/"):
            rows[int(part)] = model_doc
    return rows


@pytest.mark.parametrize("phase", sorted(_BASELINE_MODEL.keys()))
def test_claude_md_table_matches_baseline_model(phase: int) -> None:
    """CLAUDE.md phase table records the same model as effort._BASELINE_MODEL."""
    table = _parse_phase_table()
    assert phase in table, f"Phase {phase} missing from CLAUDE.md phase table"
    canonical = _DOC_TO_CANONICAL.get(table[phase])
    assert canonical is not None, (
        f"Phase {phase} CLAUDE.md cell {table[phase]!r} not in known model labels"
    )
    assert canonical == _BASELINE_MODEL[phase], (
        f"Phase {phase} mismatch: CLAUDE.md says {table[phase]!r} "
        f"(canonical {canonical!r}); _BASELINE_MODEL says {_BASELINE_MODEL[phase]!r}"
    )


def test_claude_md_table_covers_every_baseline_phase() -> None:
    """Every phase declared in _BASELINE_MODEL appears in the CLAUDE.md table."""
    table = _parse_phase_table()
    missing = sorted(set(_BASELINE_MODEL) - set(table))
    assert not missing, f"Phases missing from CLAUDE.md table: {missing}"
