"""Tests for orchestrator._memory_writers — cross-issue knowledge persistence.

Acceptance criteria covered (issue #187):
  - AC1: 3-issue Phase 3/4 loop produces cycle-summary.md with exactly 3 lines in order.
  - AC2: project-plan.md lists all issues with correct priority and agent name.
  - AC3: cycle-summary.md overwrite-then-append preserves atomicity (interrupt between
         tmp-write and os.replace → file is always either empty or complete-line-count).
  - AC4: current-issue.md remains the ONLY per-issue-overwritten memory file
         (regression guard: other memory files are not touched by soft_reset_context).
"""

from __future__ import annotations

import contextlib
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from code_generator import state as _state
from code_generator.memory import (
    overwrite_memory_file,
    read_memory_file,
    write_memory_file,
)
from code_generator.orchestrator._memory_writers import (
    append_cycle_summaries,
    reset_cycle_summary,
    write_project_plan,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def mem_dir(tmp_path: Path) -> Path:
    """Return a fresh temp directory to serve as memories_dir."""
    return tmp_path / "memories"


def _make_issue(
    number: int,
    title: str,
    agent: str = "python-pro",
    priority: str = "medium",
    status: str = "open",
) -> _state.IssueState:
    return _state.IssueState(
        number=number,
        title=title,
        status=status,  # type: ignore[arg-type]
        agent=agent,
        labels=[f"priority:{priority}"],
    )


# ---------------------------------------------------------------------------
# AC1: 3-issue cycle → exactly 3 lines in order in cycle-summary.md
# ---------------------------------------------------------------------------


def test_three_issues_produce_three_lines_in_order(mem_dir: Path) -> None:
    """append_cycle_summaries for 3 closed issues writes exactly 3 ordered lines."""
    issues = [
        _make_issue(1, "Add login endpoint", status="closed"),
        _make_issue(2, "Add logout endpoint", status="closed"),
        _make_issue(3, "Add token refresh", status="closed"),
    ]
    reset_cycle_summary(mem_dir)
    append_cycle_summaries(issues, commit_subject="feat: auth endpoints", memories_dir=mem_dir)

    content = read_memory_file(mem_dir, "cycle-summary.md")
    lines = [ln for ln in content.splitlines() if ln.strip()]
    assert len(lines) == 3, f"Expected 3 lines, got {len(lines)}: {lines}"
    assert lines[0].startswith("Issue #1:")
    assert lines[1].startswith("Issue #2:")
    assert lines[2].startswith("Issue #3:")


def test_only_closed_issues_appear_in_cycle_summary(mem_dir: Path) -> None:
    """append_cycle_summaries skips open issues — only closed ones appear."""
    issues = [
        _make_issue(1, "Implemented", status="closed"),
        _make_issue(2, "Still open", status="open"),
    ]
    reset_cycle_summary(mem_dir)
    append_cycle_summaries(issues, commit_subject="feat: partial", memories_dir=mem_dir)

    content = read_memory_file(mem_dir, "cycle-summary.md")
    lines = [ln for ln in content.splitlines() if ln.strip()]
    assert len(lines) == 1
    assert "Issue #1:" in lines[0]
    assert "Issue #2" not in content


def test_cycle_summary_line_format_contains_title_and_summary(mem_dir: Path) -> None:
    """Each line follows the canonical 'Issue #N: {title} — {summary}' format."""
    issues = [_make_issue(42, "feat: build planner", status="closed")]
    reset_cycle_summary(mem_dir)
    append_cycle_summaries(issues, commit_subject="feat: planner MVP", memories_dir=mem_dir)

    content = read_memory_file(mem_dir, "cycle-summary.md")
    assert "Issue #42: feat: build planner — feat: planner MVP" in content


def test_cycle_summary_uses_title_fallback_when_no_commit_subject(mem_dir: Path) -> None:
    """When commit_subject is empty, issue title is used as the summary."""
    issues = [_make_issue(10, "refactor: clean up models", status="closed")]
    reset_cycle_summary(mem_dir)
    append_cycle_summaries(issues, commit_subject="", memories_dir=mem_dir)

    content = read_memory_file(mem_dir, "cycle-summary.md")
    assert "Issue #10: refactor: clean up models — refactor: clean up models" in content


def test_reset_cycle_summary_creates_empty_file(mem_dir: Path) -> None:
    """reset_cycle_summary creates (or truncates) cycle-summary.md to empty."""
    # pre-populate so the overwrite is meaningful
    write_memory_file(mem_dir, "cycle-summary.md", "stale content\n")
    reset_cycle_summary(mem_dir)
    assert read_memory_file(mem_dir, "cycle-summary.md") == ""


def test_append_accumulates_across_multiple_calls(mem_dir: Path) -> None:
    """Multiple append_cycle_summaries calls accumulate lines (append-only)."""
    reset_cycle_summary(mem_dir)
    append_cycle_summaries(
        [_make_issue(1, "first", status="closed")],
        commit_subject="feat: first",
        memories_dir=mem_dir,
    )
    append_cycle_summaries(
        [_make_issue(2, "second", status="closed")],
        commit_subject="feat: second",
        memories_dir=mem_dir,
    )

    content = read_memory_file(mem_dir, "cycle-summary.md")
    lines = [ln for ln in content.splitlines() if ln.strip()]
    assert len(lines) == 2


# ---------------------------------------------------------------------------
# AC2: project-plan.md lists all issues with correct priority and agent name
# ---------------------------------------------------------------------------


def test_project_plan_lists_all_issues(mem_dir: Path) -> None:
    """write_project_plan writes one line per issue regardless of status."""
    issues = [
        _make_issue(1, "Bootstrap DB", agent="python-pro", priority="high", status="open"),
        _make_issue(2, "Auth flow", agent="nestjs-expert", priority="medium", status="open"),
        _make_issue(
            3, "Frontend skeleton", agent="frontend-developer", priority="low", status="open"
        ),
    ]
    write_project_plan(issues, mem_dir)

    content = read_memory_file(mem_dir, "project-plan.md")
    assert "#1" in content
    assert "#2" in content
    assert "#3" in content


def test_project_plan_includes_priority_label(mem_dir: Path) -> None:
    """write_project_plan includes the priority label in each line."""
    issues = [
        _make_issue(1, "Bootstrap DB", agent="python-pro", priority="high"),
        _make_issue(2, "Auth flow", agent="python-pro", priority="low"),
    ]
    write_project_plan(issues, mem_dir)

    content = read_memory_file(mem_dir, "project-plan.md")
    assert "[priority:high]" in content
    assert "[priority:low]" in content


# ---------------------------------------------------------------------------
# Issue #238: cycle_loop skips legacy cycle-summary writes when the memory tool
# is registered (model owns cross-issue knowledge via the memory tool).
# ---------------------------------------------------------------------------


class TestCycleLoopMemoryToolGate:
    """When the memory tool is available, the orchestrator must NOT rewrite cycle-summary.md."""

    def test_is_memory_tool_available_is_public_predicate(self) -> None:
        """runner.memory_tool exposes is_memory_tool_available() for cycle_loop branching."""
        from code_generator.runner.memory_tool import is_memory_tool_available

        # Boolean — value depends on installed SDK; both branches are valid.
        assert isinstance(is_memory_tool_available(), bool)

    @pytest.mark.asyncio
    async def test_cycle_loop_skips_reset_and_append_when_memory_tool_available(
        self, tmp_path: Path
    ) -> None:
        """With memory tool registered, _run_phases must not call reset/append helpers."""
        from unittest.mock import AsyncMock, MagicMock

        from code_generator.orchestrator import cycle_loop as _cl

        st = _state.State(
            mode="multi-cycle",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_dir / "state.json", st)

        mocks = {
            "p1": AsyncMock(return_value=None),
            "p2": AsyncMock(return_value=None),
            "p3_4": AsyncMock(return_value=None),
            "p5": AsyncMock(return_value=MagicMock(new_issues=[])),
            "p6": AsyncMock(return_value=None),
            "p7": AsyncMock(return_value="feat: x"),
        }

        with (
            patch.object(_cl.phase1_plan, "run", mocks["p1"]),
            patch.object(_cl.phase2_review, "run", mocks["p2"]),
            patch.object(_cl.phase3_4_implement, "run", mocks["p3_4"]),
            patch.object(_cl.phase5_closure, "run", mocks["p5"]),
            patch.object(_cl.phase6_test, "run", mocks["p6"]),
            patch.object(_cl.phase7_commit, "run", mocks["p7"]),
            patch.object(_cl.phase8_finalization, "run", AsyncMock()),
            patch.object(
                _cl, "setup_phase_logger", return_value=__import__("logging").getLogger("t")
            ),
            patch(
                "code_generator.orchestrator.cycle_loop.is_memory_tool_available",
                return_value=True,
            ),
            patch("code_generator.orchestrator.cycle_loop.reset_cycle_summary") as mock_reset,
            patch("code_generator.orchestrator.cycle_loop.append_cycle_summaries") as mock_append,
        ):
            await _cl._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=None,
            )

        mock_reset.assert_not_called()
        mock_append.assert_not_called()

    @pytest.mark.asyncio
    async def test_cycle_loop_falls_back_to_file_writes_when_memory_tool_unavailable(
        self, tmp_path: Path
    ) -> None:
        """When the memory tool is absent, the legacy reset/append flow still runs (review #c)."""
        from unittest.mock import AsyncMock, MagicMock

        from code_generator.orchestrator import cycle_loop as _cl

        st = _state.State(
            mode="multi-cycle",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_dir / "state.json", st)

        mocks = {
            "p1": AsyncMock(return_value=None),
            "p2": AsyncMock(return_value=None),
            "p3_4": AsyncMock(return_value=None),
            "p5": AsyncMock(return_value=MagicMock(new_issues=[])),
            "p6": AsyncMock(return_value=None),
            "p7": AsyncMock(return_value="feat: x"),
        }

        with (
            patch.object(_cl.phase1_plan, "run", mocks["p1"]),
            patch.object(_cl.phase2_review, "run", mocks["p2"]),
            patch.object(_cl.phase3_4_implement, "run", mocks["p3_4"]),
            patch.object(_cl.phase5_closure, "run", mocks["p5"]),
            patch.object(_cl.phase6_test, "run", mocks["p6"]),
            patch.object(_cl.phase7_commit, "run", mocks["p7"]),
            patch.object(_cl.phase8_finalization, "run", AsyncMock()),
            patch.object(
                _cl, "setup_phase_logger", return_value=__import__("logging").getLogger("t")
            ),
            patch(
                "code_generator.orchestrator.cycle_loop.is_memory_tool_available",
                return_value=False,
            ),
            patch("code_generator.orchestrator.cycle_loop.reset_cycle_summary") as mock_reset,
            patch("code_generator.orchestrator.cycle_loop.append_cycle_summaries") as mock_append,
        ):
            await _cl._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=None,
            )

        mock_reset.assert_called_once()
        mock_append.assert_called_once()


def test_project_plan_includes_agent_name(mem_dir: Path) -> None:
    """write_project_plan includes the agent name in each line."""
    issues = [
        _make_issue(5, "Implement search", agent="nestjs-expert"),
        _make_issue(6, "Optimize queries", agent="python-pro"),
    ]
    write_project_plan(issues, mem_dir)

    content = read_memory_file(mem_dir, "project-plan.md")
    assert "agent: nestjs-expert" in content
    assert "agent: python-pro" in content


def test_project_plan_line_format(mem_dir: Path) -> None:
    """write_project_plan uses canonical '- #N [priority] title — agent: name' format."""
    issues = [_make_issue(7, "Add rate limiting", agent="python-pro", priority="medium")]
    write_project_plan(issues, mem_dir)

    content = read_memory_file(mem_dir, "project-plan.md")
    assert "- #7 [priority:medium] Add rate limiting — agent: python-pro" in content


def test_project_plan_is_overwritten_not_appended(mem_dir: Path) -> None:
    """write_project_plan overwrites — calling twice produces one plan, not two."""
    issues_first = [_make_issue(1, "First issue", agent="python-pro")]
    issues_second = [_make_issue(2, "Second issue", agent="python-pro")]

    write_project_plan(issues_first, mem_dir)
    write_project_plan(issues_second, mem_dir)

    content = read_memory_file(mem_dir, "project-plan.md")
    # Only the second call's content should remain.
    assert "First issue" not in content
    assert "Second issue" in content


def test_project_plan_unknown_priority_fallback(mem_dir: Path) -> None:
    """Issues without a priority: label get 'priority:unknown' placeholder."""
    issue = _state.IssueState(
        number=9, title="No-priority issue", status="open", agent="python-pro", labels=[]
    )
    write_project_plan([issue], mem_dir)

    content = read_memory_file(mem_dir, "project-plan.md")
    assert "[priority:unknown]" in content


# ---------------------------------------------------------------------------
# AC3: Atomicity — interrupt between tmp-write and os.replace
# ---------------------------------------------------------------------------


def test_cycle_summary_atomicity_under_simulated_interrupt(mem_dir: Path) -> None:
    """Simulating an interrupt between tmp-write and os.replace leaves the file intact.

    Strategy: patch os.replace so it raises mid-way on the *first* call only.
    The target file must remain in its previous-complete state, never partial.
    """
    # Establish a complete base state (one line).
    reset_cycle_summary(mem_dir)
    append_cycle_summaries(
        [_make_issue(1, "existing", status="closed")],
        commit_subject="chore: base",
        memories_dir=mem_dir,
    )
    before = read_memory_file(mem_dir, "cycle-summary.md")
    assert before.strip(), "Precondition: base state must be non-empty"

    original_replace = os.replace
    call_count = 0

    def failing_replace(src: str, dst: str) -> None:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            # Simulate an OS crash / interrupt: remove the tmp file to mimic
            # the write being abandoned and raise, leaving dst unchanged.
            with contextlib.suppress(OSError):
                os.unlink(src)
            raise OSError("simulated interrupt")
        original_replace(src, dst)

    with patch("os.replace", side_effect=failing_replace):
        with pytest.raises(OSError, match="simulated interrupt"):
            append_cycle_summaries(
                [_make_issue(2, "new entry", status="closed")],
                commit_subject="chore: new",
                memories_dir=mem_dir,
            )

    # After the simulated interrupt the target file must be either:
    # (a) the complete previous state (os.replace never reached), or
    # (b) the complete new state (os.replace succeeded before interrupt).
    # It must NOT be partial.
    after = read_memory_file(mem_dir, "cycle-summary.md")
    after_lines = [ln for ln in after.splitlines() if ln.strip()]
    assert len(after_lines) in (1, 2), (
        f"File must have 1 (prev) or 2 (new) complete lines, got {len(after_lines)}: {after_lines}"
    )
    for line in after_lines:
        assert line.startswith("Issue #"), f"Partial/corrupt line: {line!r}"


# ---------------------------------------------------------------------------
# AC4: Regression guard — soft_reset_context only touches current-issue.md
# ---------------------------------------------------------------------------


def test_soft_reset_only_overwrites_current_issue(mem_dir: Path) -> None:
    """soft_reset_context touches ONLY current-issue.md; other memory files are unchanged."""
    # Pre-populate two memory files.
    write_memory_file(mem_dir, "current-issue.md", "issue #5 context")
    write_memory_file(mem_dir, "cycle-summary.md", "Issue #4: prev — done\n")
    write_memory_file(mem_dir, "project-plan.md", "- #5 [priority:high] Task — agent: python-pro\n")

    # Simulate soft_reset_context file side-effect (the function also calls client.query,
    # but the file-I/O part is what we guard here).
    overwrite_memory_file(mem_dir, "current-issue.md", "")

    # cycle-summary.md and project-plan.md must be untouched.
    assert read_memory_file(mem_dir, "cycle-summary.md") == "Issue #4: prev — done\n"
    assert "- #5" in read_memory_file(mem_dir, "project-plan.md")
    # current-issue.md was the only file reset.
    assert read_memory_file(mem_dir, "current-issue.md") == ""


def test_project_plan_not_written_by_soft_reset(mem_dir: Path) -> None:
    """project-plan.md is written once by write_project_plan, not by soft_reset_context."""
    issues = [_make_issue(1, "task", agent="python-pro")]
    write_project_plan(issues, mem_dir)

    # Call soft_reset_context file side-effect.
    overwrite_memory_file(mem_dir, "current-issue.md", "")

    # project-plan.md still has its original content.
    assert "- #1" in read_memory_file(mem_dir, "project-plan.md")


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


def test_empty_issue_list_produces_empty_project_plan(mem_dir: Path) -> None:
    """write_project_plan with no issues writes an empty file."""
    write_project_plan([], mem_dir)
    assert read_memory_file(mem_dir, "project-plan.md") == ""


def test_empty_issue_list_produces_no_cycle_summary_lines(mem_dir: Path) -> None:
    """append_cycle_summaries with empty list appends nothing."""
    reset_cycle_summary(mem_dir)
    append_cycle_summaries([], commit_subject="feat: nothing", memories_dir=mem_dir)
    assert read_memory_file(mem_dir, "cycle-summary.md") == ""
