"""Tests for runner/phase_telemetry.py — Issue #244.

Pure helper: per-phase TokenUsage accumulator with TTL routing and cache hit
ratio computation. No I/O, no state.py dependency.
"""

from __future__ import annotations

import pytest

from code_generator.runner.phase_telemetry import accumulate_phase_telemetry, cache_hit_ratio
from code_generator.runner.types import TokenUsage

# ---------------------------------------------------------------------------
# accumulate_phase_telemetry — TTL routing
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("ttl", "expected_5m", "expected_1h"),
    [("5m", 100, 0), ("1h", 0, 100)],
)
def test_accumulate_phase_telemetry_routes_cache_write_into_correct_bucket(
    ttl: str, expected_5m: int, expected_1h: int
) -> None:
    """Single result with cache_write=100 lands in the active TTL bucket."""
    target = TokenUsage()
    usage = TokenUsage(cache_write=100)

    accumulate_phase_telemetry(
        target,
        ttl=ttl,  # type: ignore[arg-type]
        usage=usage,
        compaction_delta=0,
        clear_delta=0,
    )

    assert target.cache_write_5m == expected_5m
    assert target.cache_write_1h == expected_1h
    assert target.cache_write == 100


def test_accumulate_phase_telemetry_zero_cache_write_keeps_buckets_zero() -> None:
    """A usage with no cache_write leaves both buckets at 0."""
    target = TokenUsage()
    accumulate_phase_telemetry(
        target,
        ttl="5m",
        usage=TokenUsage(input=1000, output=500),
        compaction_delta=0,
        clear_delta=0,
    )

    assert target.cache_write_5m == 0
    assert target.cache_write_1h == 0
    assert target.cache_write == 0
    assert target.input == 1000
    assert target.output == 500


def test_accumulate_phase_telemetry_accumulates_token_fields() -> None:
    """input / output / cache_read / num_turns add into the running phase total."""
    target = TokenUsage(input=10, output=5, cache_read=2, num_turns=1)
    usage = TokenUsage(input=20, output=15, cache_read=8, num_turns=3, cache_write=50)

    accumulate_phase_telemetry(target, ttl="1h", usage=usage, compaction_delta=0, clear_delta=0)

    assert target.input == 30
    assert target.output == 20
    assert target.cache_read == 10
    assert target.num_turns == 4
    assert target.cache_write == 50
    assert target.cache_write_1h == 50


def test_accumulate_phase_telemetry_increments_compaction_and_clear_deltas() -> None:
    """compaction_delta and clear_delta add into the per-phase counters."""
    target = TokenUsage(compaction_events=1, clear_events=2)

    accumulate_phase_telemetry(
        target, ttl="5m", usage=TokenUsage(), compaction_delta=2, clear_delta=3
    )

    assert target.compaction_events == 3
    assert target.clear_events == 5


def test_accumulate_phase_telemetry_multi_call_accumulates_all_buckets() -> None:
    """Sequential calls keep cache_write_5m + cache_write_1h == cache_write."""
    target = TokenUsage()

    accumulate_phase_telemetry(
        target,
        ttl="1h",
        usage=TokenUsage(cache_write=200),
        compaction_delta=1,
        clear_delta=0,
    )
    accumulate_phase_telemetry(
        target,
        ttl="5m",
        usage=TokenUsage(cache_write=70),
        compaction_delta=0,
        clear_delta=2,
    )
    accumulate_phase_telemetry(
        target,
        ttl="1h",
        usage=TokenUsage(cache_write=30),
        compaction_delta=1,
        clear_delta=0,
    )

    assert target.cache_write_5m == 70
    assert target.cache_write_1h == 230
    assert target.cache_write == 300
    assert target.cache_write_5m + target.cache_write_1h == target.cache_write
    assert target.compaction_events == 2
    assert target.clear_events == 2


def test_accumulate_phase_telemetry_invariant_5m_plus_1h_equals_flat() -> None:
    """The class invariant holds after a single call."""
    target = TokenUsage()
    accumulate_phase_telemetry(
        target,
        ttl="5m",
        usage=TokenUsage(cache_write=42),
        compaction_delta=0,
        clear_delta=0,
    )

    assert target.cache_write_5m + target.cache_write_1h == target.cache_write


def test_accumulate_phase_telemetry_rejects_unknown_ttl_string() -> None:
    """A typo in the TTL kwarg raises ValueError so writes never go to the wrong bucket."""
    target = TokenUsage()

    with pytest.raises(ValueError):
        accumulate_phase_telemetry(
            target,
            ttl="30m",  # type: ignore[arg-type]
            usage=TokenUsage(cache_write=10),
            compaction_delta=0,
            clear_delta=0,
        )


# ---------------------------------------------------------------------------
# cache_hit_ratio
# ---------------------------------------------------------------------------


def test_cache_hit_ratio_zero_denominator_returns_zero_float() -> None:
    """When input/cache_read/cache_write are all 0, the ratio is 0.0 (not NaN)."""
    assert cache_hit_ratio(TokenUsage()) == 0.0


def test_cache_hit_ratio_returns_zero_when_only_output_present() -> None:
    """output does not appear in the denominator — output-only usage → 0.0."""
    assert cache_hit_ratio(TokenUsage(output=999)) == 0.0


def test_cache_hit_ratio_pure_cache_read_returns_one() -> None:
    """A request that read entirely from cache has ratio 1.0."""
    assert cache_hit_ratio(TokenUsage(cache_read=100)) == 1.0


def test_cache_hit_ratio_half_cached() -> None:
    """50/50 cache_read vs cache_write yields 0.5."""
    usage = TokenUsage(cache_read=50, cache_write=50)
    assert cache_hit_ratio(usage) == 0.5


def test_cache_hit_ratio_with_input_and_cache_read() -> None:
    """ratio = cache_read / (cache_read + cache_write + input)."""
    usage = TokenUsage(input=20, cache_read=80, cache_write=0)
    assert cache_hit_ratio(usage) == pytest.approx(0.8)


def test_cache_hit_ratio_returns_float_type() -> None:
    """Return type is float, never int — even on integer-valued ratios."""
    result = cache_hit_ratio(TokenUsage(cache_read=10, cache_write=10, input=10))
    assert isinstance(result, float)
