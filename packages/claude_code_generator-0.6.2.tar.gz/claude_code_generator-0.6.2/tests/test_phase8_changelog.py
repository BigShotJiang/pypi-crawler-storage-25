"""Behavioural tests for ``code_generator.changelog`` — Phase 8 generator (#311, #324).

Covers ``format_section``, ``update_changelog``, idempotent prepend, grouping
order, title-block split, the ``_today`` date seam, and the atomic-write
contract.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path

import pytest

from code_generator import changelog as cl_mod
from code_generator.changelog import format_section, update_changelog
from code_generator.semver import CommitClass

_FIXED_DATE = date(2026, 5, 16)


@pytest.fixture
def fixed_today(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cl_mod, "_today", lambda: _FIXED_DATE)


def _commit(
    sha: str = "abc1234",
    subject: str = "feat: add x",
    ctype: str = "feat",
    breaking: bool = False,
) -> CommitClass:
    return CommitClass(sha=sha, subject=subject, type=ctype, breaking=breaking)


# ---------------------------------------------------------------------------
# format_section
# ---------------------------------------------------------------------------


class TestFormatSection:
    def test_when_no_commits_then_empty_string_is_returned(self, fixed_today: None) -> None:
        assert format_section("1.0.0", []) == ""

    def test_when_feat_commit_then_features_section_appears(self, fixed_today: None) -> None:
        out = format_section("1.0.0", [_commit(subject="feat: add login")])
        assert "## [v1.0.0] — 2026-05-16" in out
        assert "### Features" in out
        assert "feat: add login" in out

    def test_when_fix_commit_then_bug_fixes_section_appears(self, fixed_today: None) -> None:
        out = format_section("1.0.0", [_commit(subject="fix: x", ctype="fix")])
        assert "### Bug Fixes" in out

    def test_when_refactor_commit_then_refactor_section_appears(self, fixed_today: None) -> None:
        out = format_section("1.0.0", [_commit(subject="refactor: x", ctype="refactor")])
        assert "### Refactor" in out

    def test_when_chore_or_other_then_chore_section_appears(self, fixed_today: None) -> None:
        out = format_section(
            "1.0.0",
            [
                _commit(subject="chore: bump", ctype="chore"),
                _commit(subject="docs: update", ctype="docs"),
            ],
        )
        assert "### Chore" in out

    def test_when_breaking_commit_then_appears_in_both_breaking_and_type_section(
        self, fixed_today: None
    ) -> None:
        commits = [_commit(sha="deadbeef", subject="feat!: drop legacy", breaking=True)]
        out = format_section("2.0.0", commits)
        assert "### Breaking Changes" in out
        assert "### Features" in out
        # Same commit subject occurs in BOTH sections.
        assert out.count("feat!: drop legacy") == 2

    def test_when_mixed_commits_then_section_order_is_canonical(self, fixed_today: None) -> None:
        commits = [
            _commit(sha="1", subject="chore: d", ctype="chore"),
            _commit(sha="2", subject="refactor: c", ctype="refactor"),
            _commit(sha="3", subject="fix: b", ctype="fix"),
            _commit(sha="4", subject="feat: a", ctype="feat"),
            _commit(sha="5", subject="feat!: e", ctype="feat", breaking=True),
        ]
        out = format_section("1.0.0", commits)
        positions = {
            h: out.index(f"### {h}")
            for h in ("Breaking Changes", "Features", "Bug Fixes", "Refactor", "Chore")
        }
        assert (
            positions["Breaking Changes"]
            < positions["Features"]
            < positions["Bug Fixes"]
            < positions["Refactor"]
            < positions["Chore"]
        )

    def test_when_date_seam_patched_then_injected_date_appears(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(cl_mod, "_today", lambda: date(2030, 1, 1))
        out = format_section("9.9.9", [_commit()])
        assert "## [v9.9.9] — 2030-01-01" in out

    def test_when_commit_listed_then_short_sha_seven_chars_is_shown(
        self, fixed_today: None
    ) -> None:
        out = format_section("1.0.0", [_commit(sha="0123456789abcdef", subject="feat: x")])
        assert "(0123456)" in out


# ---------------------------------------------------------------------------
# update_changelog
# ---------------------------------------------------------------------------


class TestUpdateChangelog:
    def test_when_file_missing_then_file_is_created_with_title(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        update_changelog(path, "1.0.0", [_commit()])
        text = path.read_text(encoding="utf-8")
        assert text.startswith("# Changelog")
        assert "## [v1.0.0] — 2026-05-16" in text

    def test_when_called_with_new_version_then_prepended_above_old_section(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        update_changelog(path, "1.0.0", [_commit(subject="feat: first")])
        update_changelog(path, "1.1.0", [_commit(subject="feat: second")])
        text = path.read_text(encoding="utf-8")
        assert text.index("## [v1.1.0]") < text.index("## [v1.0.0]")

    def test_when_commits_empty_then_file_is_not_created(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        update_changelog(path, "1.0.0", [])
        assert not path.exists()

    def test_when_commits_empty_and_file_exists_then_file_unchanged(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        path.write_text("# Changelog\n\n## [v0.1.0]\n", encoding="utf-8")
        before = path.read_text(encoding="utf-8")
        update_changelog(path, "1.0.0", [])
        assert path.read_text(encoding="utf-8") == before

    def test_when_existing_body_present_then_it_is_preserved(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        path.write_text(
            "# Changelog\n\n## [v0.1.0] — 2026-01-01\n### Features\n- feat: initial\n",
            encoding="utf-8",
        )
        update_changelog(path, "1.0.0", [_commit(subject="feat: x")])
        text = path.read_text(encoding="utf-8")
        assert "## [v1.0.0]" in text
        assert "## [v0.1.0]" in text
        assert "feat: initial" in text


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------


class TestIdempotency:
    def test_when_called_twice_with_same_version_then_file_byte_identical(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        update_changelog(path, "1.0.0", [_commit()])
        first = path.read_bytes()
        update_changelog(path, "1.0.0", [_commit()])
        second = path.read_bytes()
        assert first == second

    def test_when_called_twice_then_version_header_appears_once(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        update_changelog(path, "1.0.0", [_commit()])
        update_changelog(path, "1.0.0", [_commit()])
        text = path.read_text(encoding="utf-8")
        assert text.count("## [v1.0.0]") == 1

    def test_when_called_with_different_commits_but_same_version_then_no_overwrite(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        update_changelog(path, "1.0.0", [_commit(subject="feat: original")])
        before = path.read_text(encoding="utf-8")
        update_changelog(path, "1.0.0", [_commit(subject="feat: replacement")])
        assert path.read_text(encoding="utf-8") == before


# ---------------------------------------------------------------------------
# Title-block split
# ---------------------------------------------------------------------------


class TestTitleSplit:
    def test_when_existing_file_has_changelog_header_then_title_block_preserved(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        path.write_text(
            "# Changelog\n\nAll notable changes documented here.\n\n## [v0.1.0] — 2026-01-01\n",
            encoding="utf-8",
        )
        update_changelog(path, "1.0.0", [_commit(subject="feat: x")])
        text = path.read_text(encoding="utf-8")
        assert text.startswith("# Changelog")
        assert "## [v1.0.0]" in text
        assert "## [v0.1.0]" in text

    def test_when_existing_file_lacks_changelog_header_then_header_is_prepended(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        path.write_text(
            "## [v0.1.0] — 2026-01-01\n### Features\n- feat: initial\n",
            encoding="utf-8",
        )
        update_changelog(path, "1.0.0", [_commit(subject="feat: x")])
        text = path.read_text(encoding="utf-8")
        assert text.startswith("# Changelog")
        assert text.count("# Changelog") == 1
        assert "## [v1.0.0]" in text
        assert "## [v0.1.0]" in text

    def test_when_existing_file_has_other_top_level_header_then_it_is_treated_as_title(
        self, tmp_path: Path, fixed_today: None
    ) -> None:
        path = tmp_path / "CHANGELOG.md"
        path.write_text("# Release Notes\n\n## [v0.1.0]\n", encoding="utf-8")
        update_changelog(path, "1.0.0", [_commit(subject="feat: x")])
        text = path.read_text(encoding="utf-8")
        assert text.startswith("# Release Notes")
        assert "## [v1.0.0]" in text


# ---------------------------------------------------------------------------
# Atomic write + date seam invariants
# ---------------------------------------------------------------------------


class TestAtomicWrite:
    def test_when_written_then_no_tmp_file_remains(self, tmp_path: Path, fixed_today: None) -> None:
        path = tmp_path / "CHANGELOG.md"
        update_changelog(path, "1.0.0", [_commit()])
        assert list(tmp_path.glob("*.tmp")) == []

    def test_source_uses_today_seam_not_direct_datetime_today_call(self) -> None:
        """Date seam must be patchable — no direct ``datetime.date.today()`` usage."""
        src = Path(cl_mod.__file__).read_text(encoding="utf-8")
        assert "date.today()" not in src
        assert ".today()" not in src.replace("def _today", "")

    def test_today_seam_returns_date(self) -> None:
        assert isinstance(cl_mod._today(), date)
