"""Tests for ``commands._dispatch._compute_and_persist_graph_report``.

Graphify supports headless seeding via ``graphify extract <path>`` (>= 0.8.1).
Our orchestrator therefore:

- runs ``graphify extract .`` when ``graphify-out/graph.json`` does not exist;
  on success reads and persists ``GRAPH_REPORT.md``; on failure writes the
  fallback sentinel and emits a setup hint;
- runs ``graphify update .`` (idempotent AST-only refresh, no LLM cost) when
  the graph already exists — except when the per-checkout stamp
  ``graphify-out/.graphify_min_version`` is absent or older than the 0.7.18
  node-id-format break, where a one-time ``graphify update . --force`` reseed
  runs first and the stamp is written with the detected graphify version.

The installed graphify version is probed via ``graphify --version`` (the
canonical source since 0.7.15), falling back to ``pip show graphifyy`` for
older binaries that reject the flag.
"""

from __future__ import annotations

import logging
import os
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any

from code_generator.commands import _dispatch
from code_generator.memory import REPOMAP_FALLBACK

if TYPE_CHECKING:
    import pytest

# A stamp at/above the node-id-format floor → steady-state plain `update .`.
_CURRENT_STAMP = "0.8.2"


def _logger() -> logging.Logger:
    return logging.getLogger("test-graph-report")


def _read_persisted(project_dir: Path) -> str:
    target = project_dir / ".code-generator" / "memories" / "cycle-repo-map.md"
    return target.read_text(encoding="utf-8") if target.exists() else ""


def _read_stamp(project_dir: Path) -> str | None:
    stamp = project_dir / "graphify-out" / _dispatch._GRAPHIFY_STAMP_NAME
    return stamp.read_text(encoding="utf-8") if stamp.exists() else None


def _seed_graph(project_dir: Path, *, stamp: str | None = _CURRENT_STAMP) -> Path:
    """Pre-create ``graphify-out/graph.json`` (and optionally the stamp).

    By default a current stamp is written so the steady-state plain
    ``graphify update .`` path runs.  Pass ``stamp=None`` to exercise the
    one-time forced reseed.
    """
    graphify_out = project_dir / "graphify-out"
    graphify_out.mkdir(parents=True, exist_ok=True)
    (graphify_out / "graph.json").write_text("{}", encoding="utf-8")
    (graphify_out / "GRAPH_REPORT.md").write_text("# seed report\n", encoding="utf-8")
    if stamp is not None:
        (graphify_out / _dispatch._GRAPHIFY_STAMP_NAME).write_text(stamp, encoding="utf-8")
    return graphify_out


def _is_version_probe(cmd: list[str]) -> bool:
    return cmd[:2] == ["graphify", "--version"]


def _is_pip(cmd: list[str]) -> bool:
    return bool(cmd) and cmd[0] == "pip"


def _build_calls(cmds: list[list[str]]) -> list[list[str]]:
    """Filter out version-probe / pip-show noise, keep extract/update calls."""
    return [c for c in cmds if c[:1] == ["graphify"] and not _is_version_probe(c)]


def _graphify_version_result(text: str, returncode: int = 0) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(
        args=list(_dispatch._GRAPHIFY_VERSION_PROBE_CMD),
        returncode=returncode,
        stdout=text,
        stderr="",
    )


def _pip_result(version: str | None, returncode: int = 0) -> subprocess.CompletedProcess[str]:
    stdout = f"Name: graphifyy\nVersion: {version}\n" if version else "Name: graphifyy\n"
    return subprocess.CompletedProcess(
        args=["pip", "show", "graphifyy"], returncode=returncode, stdout=stdout, stderr=""
    )


class TestGraphReportBuild:
    """Behaviour of _compute_and_persist_graph_report under each branch."""

    def test_no_graph_seed_runs_extract_and_persists_report(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When graph.json absent, run `graphify extract .`; on success persist GRAPH_REPORT.md."""
        graphify_out = tmp_path / "graphify-out"
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        commands_seen: list[list[str]] = []

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            commands_seen.append(list(cmd))
            graphify_out.mkdir(parents=True, exist_ok=True)
            (graphify_out / "graph.json").write_text("{}", encoding="utf-8")
            (graphify_out / "GRAPH_REPORT.md").write_text("# extracted report\n", encoding="utf-8")
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=b"", stderr=b"")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert ["graphify", "extract", "."] in commands_seen, (
            f"extract command not called; got {commands_seen}"
        )
        assert _read_persisted(tmp_path) == "# extracted report\n"

    def test_extract_nonzero_exit_writes_fallback_and_emits_setup_hint(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """graphify extract . non-zero exit → fallback sentinel + setup hint logged."""
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        called_cmds: list[list[str]] = []

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            called_cmds.append(list(cmd))
            raise subprocess.CalledProcessError(returncode=1, cmd=cmd, stderr=b"extract failed")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        with caplog.at_level("INFO"):
            _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert ["graphify", "extract", "."] in called_cmds
        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK
        messages = [r.getMessage() for r in caplog.records]
        assert any("/graphify" in m for m in messages), (
            "setup hint with /graphify must be logged on extract failure"
        )

    def test_extract_timeout_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """graphify extract . TimeoutExpired → fallback sentinel written."""
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        called_cmds: list[list[str]] = []

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            called_cmds.append(list(cmd))
            raise subprocess.TimeoutExpired(cmd=cmd, timeout=600)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert ["graphify", "extract", "."] in called_cmds
        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_extract_file_not_found_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """graphify extract . FileNotFoundError (binary vanishes mid-run) → fallback sentinel."""
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        called_cmds: list[list[str]] = []

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            called_cmds.append(list(cmd))
            raise FileNotFoundError("graphify vanished")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert ["graphify", "extract", "."] in called_cmds
        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_seeded_graph_runs_update_subcommand(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Stamped graph at the current version → plain `graphify update .`."""
        report_dir = _seed_graph(tmp_path, stamp=_CURRENT_STAMP)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        commands_seen: list[list[str]] = []

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[Any]:
            commands_seen.append(list(cmd))
            if _is_version_probe(cmd):
                return _graphify_version_result("graphify 0.8.2")
            (report_dir / "GRAPH_REPORT.md").write_text("# updated report\n", encoding="utf-8")
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=b"", stderr=b"")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _build_calls(commands_seen) == [["graphify", "update", "."]], (
            f"expected exactly one plain `graphify update .`; got {commands_seen}"
        )
        assert _read_persisted(tmp_path) == "# updated report\n"

    def test_binary_missing_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When `graphify` is not on PATH, write the fallback string and return."""
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: None)

        called = []

        def _fake_run(*a: object, **k: object) -> subprocess.CompletedProcess[bytes]:
            called.append(a)
            raise AssertionError("subprocess.run must not be called when binary is missing")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert called == []
        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_timeout_writes_fallback(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """A `TimeoutExpired` from the update subprocess writes the fallback."""
        _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            raise subprocess.TimeoutExpired(cmd=cmd, timeout=600)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_called_process_error_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Non-zero exit from the update subprocess writes the fallback."""
        _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            raise subprocess.CalledProcessError(returncode=2, cmd=cmd, stderr=b"boom")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_failure_logs_graphify_stderr(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """On non-zero exit, graphify's stderr must appear in the log warning."""
        _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        stderr_msg = b"Error: corrupted graph.json"

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[Any]:
            if _is_version_probe(cmd):
                return _graphify_version_result("graphify 0.8.2")
            raise subprocess.CalledProcessError(returncode=1, cmd=cmd, stderr=stderr_msg)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        with caplog.at_level("WARNING"):
            _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
        assert any("corrupted graph.json" in w for w in warnings), (
            f"stderr from graphify must be in the log warning. Got: {warnings}"
        )

    def test_missing_report_after_success_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If graphify exits 0 but the report file is missing, write fallback."""
        graphify_out = _seed_graph(tmp_path)
        # Remove the seed report so the read fails after success.
        (graphify_out / "GRAPH_REPORT.md").unlink()

        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[Any]:
            if _is_version_probe(cmd):
                return _graphify_version_result("graphify 0.8.2")
            # Exit 0 but don't (re)create the report file.
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=b"", stderr=b"")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK

    def test_no_env_argument_passed_to_subprocess(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Graphify must inherit the parent env (no `env=` arg)."""
        graphify_out = _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        captured_kwargs: dict[str, object] = {}

        def _fake_run(cmd: list[str], **kwargs: object) -> subprocess.CompletedProcess[Any]:
            captured_kwargs.update(kwargs)
            if _is_version_probe(cmd):
                return _graphify_version_result("graphify 0.8.2")
            (graphify_out / "GRAPH_REPORT.md").write_text("ok\n", encoding="utf-8")
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=b"", stderr=b"")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert "env" not in captured_kwargs, (
            "graphify subprocess must inherit parent env (no `env=` arg)"
        )

    def test_oserror_when_invoking_graphify_writes_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """An OSError from subprocess.run (e.g., permission denied) writes fallback."""
        _seed_graph(tmp_path)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            raise PermissionError("denied")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK


# ---------------------------------------------------------------------------
# Stale-graph one-time forced reseed
# ---------------------------------------------------------------------------


def _dispatching_run(report_dir: Path, version: str = "graphify 0.8.2"):
    """A subprocess.run fake: serves the version probe, succeeds on builds."""

    def _run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[Any]:
        if _is_version_probe(cmd):
            return _graphify_version_result(version)
        if _is_pip(cmd):
            return _pip_result("0.8.2")
        (report_dir / "GRAPH_REPORT.md").write_text("# refreshed\n", encoding="utf-8")
        return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=b"", stderr=b"")

    return _run


class TestStaleGraphReseed:
    """One-time `graphify update . --force` for pre-0.7.18 graphs."""

    def test_no_stamp_runs_forced_update_and_writes_stamp(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        report_dir = _seed_graph(tmp_path, stamp=None)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        commands_seen: list[list[str]] = []
        runner = _dispatching_run(report_dir, version="graphify 0.8.2")

        def _fake_run(cmd: list[str], **kw: object) -> subprocess.CompletedProcess[Any]:
            commands_seen.append(list(cmd))
            return runner(cmd, **kw)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _build_calls(commands_seen) == [["graphify", "update", ".", "--force"]], (
            f"missing stamp must force a reseed; got {commands_seen}"
        )
        assert _read_stamp(tmp_path) == "0.8.2"
        assert _read_persisted(tmp_path) == "# refreshed\n"

    def test_old_stamp_runs_forced_update(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        report_dir = _seed_graph(tmp_path, stamp="0.7.10")
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        commands_seen: list[list[str]] = []
        runner = _dispatching_run(report_dir, version="graphify 0.8.2")

        def _fake_run(cmd: list[str], **kw: object) -> subprocess.CompletedProcess[Any]:
            commands_seen.append(list(cmd))
            return runner(cmd, **kw)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _build_calls(commands_seen) == [["graphify", "update", ".", "--force"]]
        assert _read_stamp(tmp_path) == "0.8.2"

    def test_current_stamp_runs_plain_update(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        report_dir = _seed_graph(tmp_path, stamp="0.7.18")
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        commands_seen: list[list[str]] = []
        runner = _dispatching_run(report_dir)

        def _fake_run(cmd: list[str], **kw: object) -> subprocess.CompletedProcess[Any]:
            commands_seen.append(list(cmd))
            return runner(cmd, **kw)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _build_calls(commands_seen) == [["graphify", "update", "."]]
        # Stamp must be left untouched on the steady-state path.
        assert _read_stamp(tmp_path) == "0.7.18"

    def test_forced_update_failure_does_not_write_stamp(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _seed_graph(tmp_path, stamp=None)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kw: object) -> subprocess.CompletedProcess[Any]:
            if _is_version_probe(cmd):
                return _graphify_version_result("graphify 0.8.2")
            raise subprocess.CalledProcessError(returncode=1, cmd=cmd, stderr=b"force boom")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())

        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK
        # No stamp written → the forced reseed retries on the next run.
        assert _read_stamp(tmp_path) is None


# ---------------------------------------------------------------------------
# Version probe — graphify --version preferred, pip show fallback
# ---------------------------------------------------------------------------


class TestGraphifyVersionProbe:
    """Unit tests for _probe_graphify_version."""

    def test_old_version_emits_warning(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """0.5.2 < 0.8.1 → WARNING containing version string and upgrade hint."""
        monkeypatch.setattr(
            _dispatch.subprocess, "run", lambda *a, **k: _graphify_version_result("graphify 0.5.2")
        )
        with caplog.at_level("WARNING"):
            _dispatch._probe_graphify_version(_logger())
        warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
        assert any("0.5.2" in w and "uv tool install" in w for w in warnings)

    def test_current_version_no_warning(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """0.8.2 >= 0.8.1 → no WARNING."""
        monkeypatch.setattr(
            _dispatch.subprocess, "run", lambda *a, **k: _graphify_version_result("graphify 0.8.2")
        )
        with caplog.at_level("WARNING"):
            _dispatch._probe_graphify_version(_logger())
        warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
        assert not warnings

    def test_minimum_boundary_version_no_warning(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Exactly 0.8.1 → no WARNING."""
        monkeypatch.setattr(
            _dispatch.subprocess, "run", lambda *a, **k: _graphify_version_result("graphify 0.8.1")
        )
        with caplog.at_level("WARNING"):
            _dispatch._probe_graphify_version(_logger())
        warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
        assert not warnings

    def test_old_0710_now_warns_under_new_floor(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """0.7.10 < 0.8.1 → WARNING (locks in the floor bump)."""
        monkeypatch.setattr(
            _dispatch.subprocess, "run", lambda *a, **k: _graphify_version_result("graphify 0.7.10")
        )
        with caplog.at_level("WARNING"):
            _dispatch._probe_graphify_version(_logger())
        warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
        assert any("0.7.10" in w for w in warnings)

    def test_unparseable_version_falls_back_to_pip(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """`graphify --version` unparseable + pip has no Version line → WARNING."""

        def _fake_run(cmd: list[str], **_kw: object) -> subprocess.CompletedProcess[str]:
            if _is_version_probe(cmd):
                return _graphify_version_result("garbled output, no semver", returncode=0)
            return _pip_result(None)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)
        with caplog.at_level("WARNING"):
            _dispatch._probe_graphify_version(_logger())
        warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
        assert warnings

    def test_version_flag_unknown_command_falls_back_to_pip(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Pre-0.7.15 binary rejects --version → pip-show value is used (no warning)."""

        def _fake_run(cmd: list[str], **_kw: object) -> subprocess.CompletedProcess[str]:
            if _is_version_probe(cmd):
                return _graphify_version_result("error: unknown command '--version'", returncode=1)
            return _pip_result("0.8.2")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)
        with caplog.at_level("WARNING"):
            _dispatch._probe_graphify_version(_logger())
        warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
        assert not warnings

    def test_file_not_found_emits_warning(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Both `graphify --version` and `pip show` unavailable → WARNING."""

        def _raise(*a: object, **k: object) -> None:
            raise FileNotFoundError("not found")

        monkeypatch.setattr(_dispatch.subprocess, "run", _raise)
        with caplog.at_level("WARNING"):
            _dispatch._probe_graphify_version(_logger())
        warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
        assert warnings

    def test_no_graphify_no_tips_env_mutation(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """GRAPHIFY_NO_TIPS must not appear in os.environ after the function runs."""
        monkeypatch.delenv("GRAPHIFY_NO_TIPS", raising=False)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")
        report_dir = _seed_graph(tmp_path, stamp=_CURRENT_STAMP)

        monkeypatch.setattr(_dispatch.subprocess, "run", _dispatching_run(report_dir))
        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())
        assert "GRAPHIFY_NO_TIPS" not in os.environ

    def test_update_failure_unconditionally_falls_back(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A failing `graphify update .` writes the fallback even if a report exists."""
        _seed_graph(tmp_path, stamp=_CURRENT_STAMP)
        # Report exists so old code would read it as success; new code must still fall back.
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")

        def _fake_run(cmd: list[str], **_kw: object) -> subprocess.CompletedProcess[Any]:
            if _is_version_probe(cmd):
                return _graphify_version_result("error: unknown command", returncode=1)
            if _is_pip(cmd):
                return _pip_result("0.8.2")
            raise subprocess.CalledProcessError(
                returncode=1, cmd=cmd, stderr=b"NameError: name '_os' is not defined"
            )

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)
        _dispatch._compute_and_persist_graph_report(tmp_path, _logger())
        assert _read_persisted(tmp_path) == REPOMAP_FALLBACK


class TestGraphifyVersionProbeSource:
    """Probe ordering: graphify --version preferred over pip show."""

    def test_graphify_version_flag_preferred(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When --version works, pip show must not be consulted."""

        def _fake_run(cmd: list[str], **_kw: object) -> subprocess.CompletedProcess[str]:
            if _is_version_probe(cmd):
                return _graphify_version_result("graphify 0.8.2")
            raise AssertionError(f"pip must not be called; got {cmd}")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)
        assert _dispatch._get_graphify_version_str() == "0.8.2"

    def test_falls_back_to_pip_when_version_flag_unknown_command(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Models real pre-0.7.15: rc=1 'unknown command', pip yields the version."""

        def _fake_run(cmd: list[str], **_kw: object) -> subprocess.CompletedProcess[str]:
            if _is_version_probe(cmd):
                return _graphify_version_result("error: unknown command '--version'", returncode=1)
            return _pip_result("0.7.10")

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)
        assert _dispatch._get_graphify_version_str() == "0.7.10"

    def test_stderr_skill_warning_token_not_picked_up(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """stdout version wins over a stale-skill version token on stderr."""
        result = subprocess.CompletedProcess(
            args=list(_dispatch._GRAPHIFY_VERSION_PROBE_CMD),
            returncode=0,
            stdout="graphify 0.8.2\n",
            stderr="warning: skill is from graphify 0.7.13, package is 0.8.2\n",
        )
        monkeypatch.setattr(_dispatch.subprocess, "run", lambda *a, **k: result)
        assert _dispatch._get_graphify_version_str() == "0.8.2"

    def test_parse_handles_v_prefix_and_comma(self) -> None:
        parse = _dispatch._parse_graphify_version_output
        assert parse("graphify, version v0.8.1") == "0.8.1"
        assert parse("0.8.1") == "0.8.1"
        assert parse("graphify 0.8.1 (build x)") == "0.8.1"
        assert parse("no version here") is None


# ---------------------------------------------------------------------------
# --backend flag threading — issue #265
# ---------------------------------------------------------------------------


class TestExtractBackendFlag:
    """graphify extract argv varies by provider; update argv is always unchanged."""

    def _make_extract_mock(self, tmp_path: Path):
        """Return a fake subprocess.run that succeeds for graphify extract."""
        graphify_out = tmp_path / "graphify-out"

        def _fake_run(cmd: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
            graphify_out.mkdir(parents=True, exist_ok=True)
            (graphify_out / "graph.json").write_text("{}", encoding="utf-8")
            (graphify_out / "GRAPH_REPORT.md").write_text("# report\n", encoding="utf-8")
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=b"", stderr=b"")

        return _fake_run

    def test_anthropic_max_extract_uses_no_backend_flag(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """provider='anthropic-max' → extract argv has no --backend flag."""
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")
        called_cmds: list[list[str]] = []

        orig = self._make_extract_mock(tmp_path)

        def _fake_run(cmd: list[str], **kw: object) -> subprocess.CompletedProcess[bytes]:
            called_cmds.append(list(cmd))
            return orig(cmd, **kw)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger(), provider="anthropic-max")

        extract_calls = [c for c in called_cmds if c[:2] == ["graphify", "extract"]]
        assert extract_calls == [["graphify", "extract", "."]], (
            f"expected no --backend; got {extract_calls}"
        )

    def test_ollama_extract_appends_backend_ollama(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """provider='ollama' → extract argv includes --backend ollama."""
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")
        called_cmds: list[list[str]] = []

        orig = self._make_extract_mock(tmp_path)

        def _fake_run(cmd: list[str], **kw: object) -> subprocess.CompletedProcess[bytes]:
            called_cmds.append(list(cmd))
            return orig(cmd, **kw)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger(), provider="ollama")

        extract_calls = [c for c in called_cmds if c[:2] == ["graphify", "extract"]]
        assert extract_calls == [["graphify", "extract", ".", "--backend", "ollama"]], (
            f"expected --backend ollama; got {extract_calls}"
        )

    def test_update_cmd_never_receives_backend_flag(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Even with provider='ollama', graphify update argv carries no --backend."""
        report_dir = _seed_graph(tmp_path, stamp=_CURRENT_STAMP)
        monkeypatch.setattr(_dispatch.shutil, "which", lambda _name: "/usr/bin/graphify")
        called_cmds: list[list[str]] = []
        runner = _dispatching_run(report_dir)

        def _fake_run(cmd: list[str], **kw: object) -> subprocess.CompletedProcess[Any]:
            called_cmds.append(list(cmd))
            return runner(cmd, **kw)

        monkeypatch.setattr(_dispatch.subprocess, "run", _fake_run)

        _dispatch._compute_and_persist_graph_report(tmp_path, _logger(), provider="ollama")

        update_calls = _build_calls(called_cmds)
        assert update_calls == [["graphify", "update", "."]], (
            f"update must not receive --backend; got {update_calls}"
        )
        assert all("--backend" not in c for c in update_calls)
