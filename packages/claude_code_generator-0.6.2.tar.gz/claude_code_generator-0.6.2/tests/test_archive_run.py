"""Tests for archive_run.archive_completed_run."""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from code_generator.archive_run import (
    _REQUIREMENTS_TEMPLATE,
    _derive_slug,
    _slugify,
    archive_completed_run,
)
from code_generator.requirements_structure import (
    _H2_RE,
    _REQUIRED_H2,
    is_canonical_structure,
)
from code_generator.state import CycleState, State


def _state(mode: str = "single", codex_model: str | None = None) -> State:
    cyc = CycleState(
        id=1,
        name="c1",
        milestone_number=None,
        milestone_title="m",
        status="completed",
        phase=7,
        issues=[],
        commit_sha=None,
        depends_on=[],
        scope="s",
    )
    return State(
        mode=mode,  # type: ignore[arg-type]
        started_at="t0",
        updated_at="t1",
        cycles=[cyc],
        codex_model=codex_model,
    )


def _populate_cg(root: Path, title: str = "# Add A Cool Feature") -> Path:
    cg = root / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    (cg / "requirements.md").write_text(f"{title}\n\nbody\n", encoding="utf-8")
    (cg / "state.json").write_text("{}", encoding="utf-8")
    (cg / "logs").mkdir(exist_ok=True)
    (cg / "logs" / "generate.log").write_text("log", encoding="utf-8")
    (cg / "memories").mkdir(exist_ok=True)
    (cg / "memories" / "cycle-summary.md").write_text("mem", encoding="utf-8")
    (cg / "checklists").mkdir(exist_ok=True)
    (cg / "checklists" / "abc.json").write_text("[]", encoding="utf-8")
    return cg


def test_slugify_basics():
    assert _slugify("Add OpenAI Codex CLI!!") == "add-openai-codex-cli"
    assert _slugify("  --weird__Title--  ") == "weird-title"
    assert len(_slugify("x " * 100)) <= 60


def test_archive_full_copy_and_manifest(tmp_path):
    cg = _populate_cg(tmp_path)
    logger = MagicMock()
    dest = archive_completed_run(tmp_path, _state(codex_model="gpt-5.5"), logger)

    assert dest is not None
    assert dest == cg / "backup" / "add-a-cool-feature"
    assert (dest / "requirements.md").is_file()
    assert (dest / "state.json").is_file()
    assert (dest / "logs" / "generate.log").is_file()
    assert (dest / "memories" / "cycle-summary.md").is_file()
    assert (dest / "checklists" / "abc.json").is_file()

    manifest = json.loads((dest / "MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["title"] == "Add A Cool Feature"
    assert manifest["mode"] == "single"
    assert manifest["completed_cycles"] == 1
    assert manifest["provider_model"] == "gpt-5.5"
    assert "requirements_hash" in manifest
    logger.info.assert_called()


def test_backup_dir_is_excluded_and_existing_archive_untouched(tmp_path):
    cg = _populate_cg(tmp_path)
    prior = cg / "backup" / "graphify-integration"
    prior.mkdir(parents=True)
    (prior / "marker.txt").write_text("keep", encoding="utf-8")

    dest = archive_completed_run(tmp_path, _state(), MagicMock())

    assert dest is not None
    # backup/ must not be recursively copied into the new archive.
    assert not (dest / "backup").exists()
    # pre-existing archive left intact.
    assert (prior / "marker.txt").read_text(encoding="utf-8") == "keep"


def test_fallback_slug_when_no_h1(tmp_path):
    cg = _populate_cg(tmp_path, title="no heading here")
    dest = archive_completed_run(tmp_path, _state(), MagicMock())
    assert dest is not None
    assert dest.name.startswith("run-")
    assert dest.parent == cg / "backup"


def test_collision_appends_timestamp_suffix(tmp_path):
    cg = _populate_cg(tmp_path)
    first = archive_completed_run(tmp_path, _state(), MagicMock())
    # Reset wiped requirements.md back to the skeleton; a real same-title
    # collision means the operator re-populated it with the same title.
    _populate_cg(tmp_path)
    second = archive_completed_run(tmp_path, _state(), MagicMock())

    assert first == cg / "backup" / "add-a-cool-feature"
    assert second is not None
    assert second != first
    assert second.name.startswith("add-a-cool-feature-")
    assert first.exists() and second.exists()


def test_absent_optional_dirs_are_skipped(tmp_path):
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True)
    (cg / "requirements.md").write_text("# Tiny\n", encoding="utf-8")
    (cg / "state.json").write_text("{}", encoding="utf-8")

    dest = archive_completed_run(tmp_path, _state(), MagicMock())
    assert dest is not None
    assert (dest / "requirements.md").is_file()
    assert not (dest / "logs").exists()
    assert not (dest / "cycles_prompts").exists()


def test_missing_cg_dir_returns_none(tmp_path):
    assert archive_completed_run(tmp_path, _state(), MagicMock()) is None


def test_failure_is_non_fatal(tmp_path):
    _populate_cg(tmp_path)
    logger = MagicMock()
    with patch("code_generator.archive_run.shutil.copytree", side_effect=OSError("disk full")):
        result = archive_completed_run(tmp_path, _state(), logger)
    assert result is None
    logger.warning.assert_called()
    # No half-written archive left behind.
    leftovers = list((tmp_path / ".code-generator" / "backup").iterdir())
    assert leftovers == []


def test_derive_slug_reads_title(tmp_path):
    p = tmp_path / "requirements.md"
    p.write_text("#   Spaced   Title  \nrest", encoding="utf-8")
    assert _derive_slug(p) == "spaced-title"


def test_dispatch_archives_after_success_not_on_dry_run():
    """Source-level wiring guard: archive call sits after the run_* block and
    after the dry-run early return, and appears exactly once."""
    src = Path("src/code_generator/commands/_dispatch.py").read_text(encoding="utf-8")
    assert src.count("archive_completed_run(project_dir, st, logger)") == 1
    dry_return = src.index('logger.info("--dry-run')
    archive_call = src.index("archive_completed_run(project_dir, st, logger)")
    single_mode = src.index("cycle_loop.run_single_mode(")
    assert dry_return < archive_call
    assert single_mode < archive_call


@pytest.mark.parametrize("mode", ["single", "multi-cycle"])
def test_archives_for_both_modes(tmp_path, mode):
    _populate_cg(tmp_path)
    dest = archive_completed_run(tmp_path, _state(mode=mode), MagicMock())
    assert dest is not None and dest.is_dir()


def test_reset_clears_working_dir_and_writes_skeleton(tmp_path):
    cg = _populate_cg(tmp_path)
    prior = cg / "backup" / "graphify-integration"
    prior.mkdir(parents=True)
    (prior / "marker.txt").write_text("keep", encoding="utf-8")

    dest = archive_completed_run(tmp_path, _state(), MagicMock())
    assert dest is not None

    # Working dir wiped of the per-run artifact set.
    assert not (cg / "state.json").exists()
    assert not (cg / "logs").exists()
    assert not (cg / "memories").exists()
    assert not (cg / "checklists").exists()
    # requirements.md restored to the blank skeleton (not the archived body).
    assert (cg / "requirements.md").read_text(encoding="utf-8") == _REQUIREMENTS_TEMPLATE
    # backup/ and prior archives untouched; this run's archive intact.
    assert (prior / "marker.txt").read_text(encoding="utf-8") == "keep"
    assert (dest / "requirements.md").read_text(
        encoding="utf-8"
    ) == "# Add A Cool Feature\n\nbody\n"
    assert (dest / "state.json").is_file()


def test_reset_skeleton_is_non_canonical_but_has_required_headings():
    # Non-canonical so a plain `optimize` processes it (no --force needed).
    assert is_canonical_structure(_REQUIREMENTS_TEMPLATE) is False
    # Yet every required H2 heading is present for the operator to fill.
    present = {m.group(1).strip().lower() for m in _H2_RE.finditer(_REQUIREMENTS_TEMPLATE)}
    assert _REQUIRED_H2.issubset(present)


def test_reset_removes_readonly_state_json(tmp_path):
    cg = _populate_cg(tmp_path)
    # state_guard may leave state.json read-only — reset must still remove it.
    (cg / "state.json").chmod(0o444)

    dest = archive_completed_run(tmp_path, _state(), MagicMock())
    assert dest is not None
    assert not (cg / "state.json").exists()
    assert (dest / "state.json").is_file()
