"""Tests for src/code_generator/runner/memory_tool.py — issue #237.

Covers four invariants:

1. Persistence callbacks delegate to ``memory.overwrite_memory_file`` so the
   atomic ``tmp → os.replace`` invariant (non-negotiable #7) and traversal
   validation (``memory._validated_path``) are reused, not duplicated.
2. Path-traversal attempts (``../``, absolute paths, symlink escapes) raise
   ``ValueError`` — single-source validation via ``memory._validated_path``.
3. ``cycle_id`` strings containing ``..``, ``/``, leading dots, null bytes,
   or empty are rejected at construction with ``ValueError``.
4. SDK-absent path: when ``BetaAbstractMemoryTool`` cannot be imported, the
   :func:`build_cycle_memory_tool` factory returns ``None`` and emits a
   one-shot INFO log; callers fall through to the legacy file-write flow.
"""

from __future__ import annotations

import importlib
import logging
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

import code_generator.runner.memory_tool as memory_tool_mod
from code_generator.runner.memory_tool import (
    CycleMemoryTool,
    _validate_cycle_id,
    build_cycle_memory_tool,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def mem_root(tmp_path: Path) -> Path:
    """Fresh memories root directory (not yet created)."""
    return tmp_path / "memories"


@pytest.fixture()
def tool(mem_root: Path) -> CycleMemoryTool:
    """A CycleMemoryTool rooted at <mem_root>/cycle-1/."""
    return CycleMemoryTool(mem_root, "cycle-1")


# ---------------------------------------------------------------------------
# Cycle-id validation
# ---------------------------------------------------------------------------


class TestValidateCycleId:
    """Cycle-id sanitisation must reject anything that would escape memories_dir."""

    @pytest.mark.parametrize(
        "bad",
        [
            "",  # empty
            "..",  # parent traversal
            "../escape",  # parent traversal
            "a/b",  # path separator
            "a\\b",  # windows separator
            ".hidden",  # leading dot
            "..stillbad",  # leading double-dot
            "ok\0null",  # null byte
            "/abs",  # absolute path
        ],
    )
    def test_rejects_unsafe_cycle_id(self, bad: str) -> None:
        with pytest.raises(ValueError):
            _validate_cycle_id(bad)

    @pytest.mark.parametrize("good", ["cycle-1", "cycle_42", "abc123", "a"])
    def test_accepts_safe_cycle_id(self, good: str) -> None:
        # No exception expected.
        _validate_cycle_id(good)


class TestConstructorRejectsBadCycleId:
    def test_constructor_raises_on_bad_cycle_id(self, mem_root: Path) -> None:
        """Constructor invokes _validate_cycle_id — reject before any I/O."""
        with pytest.raises(ValueError):
            CycleMemoryTool(mem_root, "../escape")

    def test_constructor_raises_on_empty_cycle_id(self, mem_root: Path) -> None:
        with pytest.raises(ValueError):
            CycleMemoryTool(mem_root, "")


# ---------------------------------------------------------------------------
# Tool name (must match issue #234 exclude_tools list)
# ---------------------------------------------------------------------------


class TestToolName:
    def test_class_name_attribute_is_memory(self) -> None:
        """The SDK-registered tool name must be exactly 'memory' (#234 exclude_tools)."""
        assert CycleMemoryTool.name == "memory"


# ---------------------------------------------------------------------------
# Persistence callbacks — delegate to memory.overwrite_memory_file
# ---------------------------------------------------------------------------


class TestCreate:
    def test_create_writes_file_atomically(self, mem_root: Path, tool: CycleMemoryTool) -> None:
        """create(path, content) writes content under <mem_root>/cycle-1/<path>."""
        tool.create("notes.md", "hello")

        target = mem_root / "cycle-1" / "notes.md"
        assert target.read_text(encoding="utf-8") == "hello"

    def test_create_accepts_empty_content(self, mem_root: Path, tool: CycleMemoryTool) -> None:
        """Empty content is valid (mirrors overwrite_memory_file default)."""
        tool.create("empty.md", "")
        assert (mem_root / "cycle-1" / "empty.md").read_text(encoding="utf-8") == ""

    def test_create_creates_nested_directories(self, mem_root: Path, tool: CycleMemoryTool) -> None:
        """create('sub/notes.md', ...) creates parent directories under cycle root."""
        tool.create("sub/dir/notes.md", "x")
        target = mem_root / "cycle-1" / "sub" / "dir" / "notes.md"
        assert target.read_text(encoding="utf-8") == "x"

    def test_create_uses_atomic_write_helper(self, mem_root: Path, tool: CycleMemoryTool) -> None:
        """create() routes through memory.overwrite_memory_file (single source of atomicity)."""
        with patch("code_generator.runner.memory_tool.overwrite_memory_file") as mock_write:
            tool.create("notes.md", "hello")
        mock_write.assert_called_once_with(mem_root / "cycle-1", "notes.md", "hello")


class TestView:
    def test_view_returns_file_content(self, mem_root: Path, tool: CycleMemoryTool) -> None:
        """view(path) returns the content of <mem_root>/cycle-1/<path>."""
        tool.create("notes.md", "stored")
        assert tool.view("notes.md") == "stored"

    def test_view_returns_empty_string_when_file_absent(self, tool: CycleMemoryTool) -> None:
        """view() of an unknown file returns an empty string (no exception)."""
        assert tool.view("ghost.md") == ""


class TestDelete:
    def test_delete_clears_file_to_empty(self, mem_root: Path, tool: CycleMemoryTool) -> None:
        """delete(path) clears the file content (atomic empty-write)."""
        tool.create("notes.md", "x")
        tool.delete("notes.md")
        assert (mem_root / "cycle-1" / "notes.md").read_text(encoding="utf-8") == ""


class TestStrReplace:
    def test_str_replace_substitutes_substring(self, mem_root: Path, tool: CycleMemoryTool) -> None:
        tool.create("notes.md", "alpha bravo charlie")
        tool.str_replace("notes.md", "bravo", "BRAVO")
        assert (mem_root / "cycle-1" / "notes.md").read_text(
            encoding="utf-8"
        ) == "alpha BRAVO charlie"

    def test_str_replace_raises_when_substring_not_found(self, tool: CycleMemoryTool) -> None:
        tool.create("notes.md", "alpha")
        with pytest.raises(ValueError):
            tool.str_replace("notes.md", "missing", "x")


class TestInsert:
    def test_insert_appends_text_at_line(self, mem_root: Path, tool: CycleMemoryTool) -> None:
        tool.create("notes.md", "line0\nline1\n")
        tool.insert("notes.md", insert_line=2, insert_text="line2\n")
        assert (mem_root / "cycle-1" / "notes.md").read_text(
            encoding="utf-8"
        ) == "line0\nline1\nline2\n"


# ---------------------------------------------------------------------------
# Path-traversal validation (single source via memory._validated_path)
# ---------------------------------------------------------------------------


class TestTraversalRejected:
    """Path-traversal attempts must raise ValueError — single source via _validated_path."""

    @pytest.mark.parametrize(
        "evil",
        [
            "../escape.md",
            "../../escape.md",
            "/etc/passwd",
            "sub/../../escape.md",
        ],
    )
    def test_create_rejects_traversal(self, tool: CycleMemoryTool, evil: str) -> None:
        with pytest.raises(ValueError):
            tool.create(evil, "x")

    @pytest.mark.parametrize("evil", ["../escape.md", "/etc/passwd"])
    def test_view_rejects_traversal(self, tool: CycleMemoryTool, evil: str) -> None:
        with pytest.raises(ValueError):
            tool.view(evil)

    def test_symlink_resolving_outside_cycle_root_rejected(
        self, mem_root: Path, tool: CycleMemoryTool, tmp_path: Path
    ) -> None:
        """A symlink whose target sits outside the cycle root raises ValueError."""
        outer = tmp_path / "outer"
        outer.mkdir()
        target_file = outer / "secret.md"
        target_file.write_text("secret", encoding="utf-8")

        cycle_root = mem_root / "cycle-1"
        cycle_root.mkdir(parents=True)
        link = cycle_root / "leak.md"
        link.symlink_to(target_file)

        with pytest.raises(ValueError):
            tool.view("leak.md")


# ---------------------------------------------------------------------------
# Factory + SDK-absent fallback
# ---------------------------------------------------------------------------


class TestBuildCycleMemoryTool:
    def test_returns_instance_when_sdk_available(self, mem_root: Path) -> None:
        """build_cycle_memory_tool() returns a CycleMemoryTool instance when SDK base is present."""
        instance = build_cycle_memory_tool(mem_root, "cycle-1")
        # In tests we monkey-patch _SDK_AVAILABLE via the test below; default is the
        # real module state.  The factory must return an instance whenever the
        # subclass is constructible.
        assert instance is None or isinstance(instance, CycleMemoryTool)

    def test_returns_none_when_sdk_absent(
        self, mem_root: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When BetaAbstractMemoryTool is unavailable the factory returns None."""
        monkeypatch.setattr(memory_tool_mod, "_SDK_AVAILABLE", False)
        assert build_cycle_memory_tool(mem_root, "cycle-1") is None

    def test_factory_emits_one_shot_info_log_when_sdk_absent(
        self,
        mem_root: Path,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        """One-shot INFO log fires when SDK fallback path is taken (review comment #1)."""
        monkeypatch.setattr(memory_tool_mod, "_SDK_AVAILABLE", False)
        monkeypatch.setattr(memory_tool_mod, "_FALLBACK_LOGGED", False)

        with caplog.at_level(logging.INFO, logger="code_generator.runner.memory_tool"):
            build_cycle_memory_tool(mem_root, "cycle-1")
            build_cycle_memory_tool(mem_root, "cycle-1")  # second call — must NOT log again

        info_lines = [r for r in caplog.records if "memory tool" in r.message.lower()]
        assert len(info_lines) == 1


class TestImportGuard:
    def test_module_loads_without_sdk_installed(self) -> None:
        """memory_tool module imports cleanly even when claude_agent_sdk is absent."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            mod = importlib.reload(memory_tool_mod)
            # CycleMemoryTool class still exists (inherits from object fallback) so
            # construction-time validation tests still run; SDK-driven callbacks
            # would never fire because the SDK isn't there.
            assert hasattr(mod, "CycleMemoryTool")
            assert mod._SDK_AVAILABLE is False
        # Restore module for downstream tests.
        importlib.reload(memory_tool_mod)
