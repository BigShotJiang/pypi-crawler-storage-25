"""Tests for ``cli._configure_io_and_logging``.

The CLI applies two startup defaults so users don't need to set env vars
manually: line-buffered stdout/stderr (PYTHONUNBUFFERED=1) and DEBUG-level
console logging (LOGLEVEL=DEBUG).  Both are overridable via ``LOGLEVEL``.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from code_generator import cli

if TYPE_CHECKING:
    import pytest


class TestConfigureIoAndLogging:
    """``_configure_io_and_logging`` sets sane defaults at CLI startup."""

    def test_default_loglevel_is_debug(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When ``LOGLEVEL`` is unset, the code_generator namespace uses DEBUG."""
        monkeypatch.delenv("LOGLEVEL", raising=False)
        cli._configure_io_and_logging()

        assert logging.getLogger("code_generator").level == logging.DEBUG

    def test_loglevel_env_overrides_default(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """``LOGLEVEL=INFO`` reverts to the quieter 0.4.x default."""
        monkeypatch.setenv("LOGLEVEL", "INFO")
        cli._configure_io_and_logging()

        assert logging.getLogger("code_generator").level == logging.INFO

    def test_unknown_loglevel_falls_back_to_debug(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Typos like ``LOGLEVEL=NOPE`` fall back to DEBUG, not raise."""
        monkeypatch.setenv("LOGLEVEL", "NOPE")
        cli._configure_io_and_logging()

        assert logging.getLogger("code_generator").level == logging.DEBUG

    def test_idempotent_when_called_twice(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Calling twice in a row does not raise (e.g. on `--version` re-import)."""
        monkeypatch.setenv("LOGLEVEL", "INFO")
        cli._configure_io_and_logging()
        cli._configure_io_and_logging()  # must not raise

        assert logging.getLogger("code_generator").level == logging.INFO

    def test_stdout_is_line_buffered_after_setup(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """sys.stdout / sys.stderr must report line buffering after setup.

        On terminals where stdout is already line-buffered, this is a no-op;
        when running through a pipe (default block buffering), the call
        switches the stream to line buffering.
        """
        import sys

        monkeypatch.delenv("LOGLEVEL", raising=False)
        cli._configure_io_and_logging()

        # `line_buffering` attribute exists on TextIOWrapper. After
        # reconfigure(line_buffering=True), it must be True.  Streams that
        # don't support the attribute (rare) are intentionally tolerated.
        for stream in (sys.stdout, sys.stderr):
            buffering = getattr(stream, "line_buffering", None)
            if buffering is not None:
                assert buffering is True, f"{stream} not line-buffered"
