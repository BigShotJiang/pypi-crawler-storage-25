"""Drift lock for ``prompt-phase-6-5-verify.md`` (#297).

Focused snapshot regression for the Phase 6.5 verifier prompt — mirrors the
parametrized coverage in :mod:`tests.test_prompt_prefix_snapshots` but
isolates the four named acceptance criteria so a future churn limited to
this prompt fails an obvious, named test.
"""

from __future__ import annotations

import re
from pathlib import Path

from code_generator.prompts import PLACEHOLDER_SPEC, load_prompt
from code_generator.prompts.hashes import compute_all_prompt_hashes
from tests.test_prompt_prefix_snapshots import PLACEHOLDER_SNAPSHOT_FIXTURES

_PROMPT_FILENAME = "prompt-phase-6-5-verify.md"
_FIXTURE_FILENAME = "prompt-phase-6-5-verify.txt"
_PREFIX_BYTES = 2048
_FIXTURE_PATH = Path(__file__).parent / "fixtures" / "prompt_prefix_snapshots" / _FIXTURE_FILENAME
_SHA256_HEX_RE = re.compile(r"^[0-9a-f]{64}$")


def _render_neutral() -> bytes:
    spec = PLACEHOLDER_SPEC[_PROMPT_FILENAME]
    kwargs = {name: PLACEHOLDER_SNAPSHOT_FIXTURES[name] for name in spec}
    return load_prompt(_PROMPT_FILENAME, **kwargs).encode("utf-8")


def test_when_phase6_5_prompt_rendered_then_prefix_matches_snapshot():
    """Bytes 0..2047 of the rendered prompt must equal the committed fixture."""
    assert _FIXTURE_PATH.exists(), (
        f"Missing snapshot fixture: {_FIXTURE_PATH}. "
        "Run `python -m tests.regenerate_prompt_snapshots` to generate it."
    )

    snapshot_bytes = _FIXTURE_PATH.read_bytes()
    rendered_prefix = _render_neutral()[:_PREFIX_BYTES]

    assert rendered_prefix == snapshot_bytes, (
        f"{_PROMPT_FILENAME}: rendered prefix drifted from committed snapshot. "
        "If intentional, regenerate via `python -m tests.regenerate_prompt_snapshots`."
    )


def test_when_placeholder_spec_loaded_then_phase6_5_prompt_is_registered():
    """``PLACEHOLDER_SPEC`` must declare every Phase 6.5 prompt placeholder."""
    assert _PROMPT_FILENAME in PLACEHOLDER_SPEC

    declared = PLACEHOLDER_SPEC[_PROMPT_FILENAME]
    for name in (
        "PROJECT_DIR",
        "REQUIREMENTS_MD",
        "DETECTED_STACK",
        "TIER_PLAN",
        "FAILURE_REPORT",
        "ATTEMPT",
        "MAX_RETRIES",
        "AGENT_SPEC_PATH",
        "ORACLE_REPORT",
        "TIERS_ACTIVE",
        "TIERS_SKIPPED",
    ):
        assert name in declared, f"{name} missing from PLACEHOLDER_SPEC[{_PROMPT_FILENAME!r}]"


def test_when_raw_prompt_read_then_no_dollar_brace_syntax_present():
    """Placeholder discipline: only ``{NAME}`` (Python ``str.format``), never ``${NAME}``."""
    import importlib.resources

    raw = (
        importlib.resources.files("code_generator.prompts").joinpath(_PROMPT_FILENAME).read_bytes()
    )
    assert b"${" not in raw, (
        f"{_PROMPT_FILENAME}: forbidden `${{` placeholder syntax found. "
        "Use `{NAME}` (Python str.format) instead."
    )


def test_when_all_prompt_hashes_computed_then_phase6_5_hash_is_64_char_hex():
    """``compute_all_prompt_hashes`` must surface a 64-char hex SHA-256 for this prompt."""
    hashes = compute_all_prompt_hashes()

    assert _PROMPT_FILENAME in hashes, f"{_PROMPT_FILENAME} missing from prompt hash table"
    digest = hashes[_PROMPT_FILENAME]
    assert _SHA256_HEX_RE.match(digest), f"hash {digest!r} is not 64-char lowercase hex"
