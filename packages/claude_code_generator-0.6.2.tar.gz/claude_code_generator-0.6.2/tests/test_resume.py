"""Tests for resume helpers in commands/_resume.py with Phase 8 routing (#304)."""

from __future__ import annotations

from code_generator import state as state_module
from code_generator.commands._resume import (
    next_start_phase,
    resolve_continue_multi_cycle,
)


def _make_state(*, phase: int | None = None, mode: str = "single") -> state_module.State:
    return state_module.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-05-16T00:00:00Z",
        updated_at="2026-05-16T00:00:00Z",
        phase=phase,
    )


def _make_cycle(cycle_id: int, *, phase: int, status: str = "open") -> state_module.CycleState:
    return state_module.CycleState(
        id=cycle_id,
        name=f"Cycle {cycle_id}",
        milestone_number=None,
        milestone_title=f"Cycle {cycle_id}",
        status=status,
        phase=phase,
        issues=[],
        commit_sha=None,
    )


# ---------------------------------------------------------------------------
# next_start_phase
# ---------------------------------------------------------------------------


class TestNextStartPhase:
    def test_phase7_returns_8(self) -> None:
        """After Phase 7 the resume jumps to Phase 8."""
        st = _make_state(phase=7)
        assert next_start_phase(st) == 8

    def test_phase8_returns_8_terminal(self) -> None:
        """Phase 8 is terminal — resume returns 8, not 9."""
        st = _make_state(phase=8)
        assert next_start_phase(st) == 8

    def test_phase65_still_returns_7(self) -> None:
        """Phase 6.5 (recorded as 65) still maps to Phase 7 — unchanged."""
        st = _make_state(phase=65)
        assert next_start_phase(st) == 7

    def test_no_prior_phase_returns_1(self) -> None:
        """Fresh run (phase=None) resumes from 1."""
        st = _make_state(phase=None)
        assert next_start_phase(st) == 1


# ---------------------------------------------------------------------------
# resolve_continue_multi_cycle — Phase 8 post-loop routing
# ---------------------------------------------------------------------------


class TestResolveContinueMultiCycle:
    def test_last_cycle_completed_phase7_no_phase8_routes_to_phase8(self) -> None:
        """Last cycle done at Phase 7 but state.phase8 missing → route to Phase 8."""
        st = _make_state(mode="multi-cycle")
        st.current_cycle = 1
        st.cycles = [_make_cycle(1, phase=7, status="completed")]
        # state.phase8 is None — Phase 8 has not yet fired post-loop.

        start_cycle, start_phase = resolve_continue_multi_cycle(st)

        assert start_cycle is None
        assert start_phase == 8

    def test_last_cycle_completed_phase8_already_ok_no_phase8_rerun(self) -> None:
        """Last cycle done AND state.phase8.status=='ok' → no Phase 8 re-run."""
        st = _make_state(mode="multi-cycle")
        st.current_cycle = 1
        st.cycles = [_make_cycle(1, phase=7, status="completed")]
        st.phase8 = state_module.Phase8Progress(
            attempt=1,
            status="ok",
            started_at="2026-05-16T00:00:00Z",
            finished_at="2026-05-16T00:00:01Z",
        )

        start_cycle, start_phase = resolve_continue_multi_cycle(st)

        # Falls through to the legacy "advance to next id" semantics.
        assert start_cycle == 2
        assert start_phase == 1

    def test_mid_cycle_interrupted_unchanged(self) -> None:
        """A cycle interrupted mid-run still resumes within that cycle."""
        st = _make_state(mode="multi-cycle")
        st.current_cycle = 1
        st.cycles = [_make_cycle(1, phase=3, status="open")]

        start_cycle, start_phase = resolve_continue_multi_cycle(st)

        assert start_cycle == 1
        assert start_phase == 4

    def test_no_current_cycle_returns_none_one(self) -> None:
        """With no recorded current_cycle, resume from a full run."""
        st = _make_state(mode="multi-cycle")
        st.current_cycle = None

        assert resolve_continue_multi_cycle(st) == (None, 1)

    def test_phase65_still_maps_to_phase7(self) -> None:
        """Cycle interrupted at Phase 6.5 still resumes at Phase 7 — unchanged."""
        st = _make_state(mode="multi-cycle")
        st.current_cycle = 1
        st.cycles = [_make_cycle(1, phase=65, status="open")]

        start_cycle, start_phase = resolve_continue_multi_cycle(st)

        assert start_cycle == 1
        assert start_phase == 7
