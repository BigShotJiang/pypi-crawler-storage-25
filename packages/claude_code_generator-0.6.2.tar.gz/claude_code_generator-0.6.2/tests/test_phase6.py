"""Tests for code_generator.orchestrator.phase6_test."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase6_test
from code_generator.orchestrator.phase6_test import TestsFailed
from code_generator.runner.sdk_runner import RunResult

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "") -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state(tmp_path: Path) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPhase6Run:
    @pytest.mark.asyncio
    async def test_passes_when_no_sentinel(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("All 42 tests passed. Coverage: 95%")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            # Should not raise.
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_raises_tests_failed_on_sentinel(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("TESTS FAILED after 3 retries")

        with (
            patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop),
            pytest.raises(TestsFailed),
        ):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_uses_haiku_model(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("ok")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].model == "claude-haiku-4-5-20251001"

    @pytest.mark.asyncio
    async def test_max_retries_placeholder_is_3(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        captured_prompts = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result("ok")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # The loaded prompt should have had {MAX_RETRIES} replaced with "3".
        assert "{MAX_RETRIES}" not in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_allowed_tools_correct(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("ok")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert set(captured_options[0].allowed_tools) == {"Read", "Edit", "Bash"}

    @pytest.mark.asyncio
    async def test_sentinel_is_case_sensitive(self, tmp_path: Path) -> None:
        """Lowercase 'tests failed' must NOT trigger TestsFailed."""
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("tests failed — some lowercase message")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            # Must not raise: sentinel is "TESTS FAILED" (uppercase only).
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_effort_escalates_across_retries(self, tmp_path: Path) -> None:
        """Effort level escalates with each retry: low→medium→high."""
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("TESTS FAILED")  # always fail to exhaust retries

        with (
            patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop),
            pytest.raises(TestsFailed),
        ):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert len(captured_options) == 3
        assert captured_options[0].effort == "low"  # attempt 0
        assert captured_options[1].effort == "medium"  # attempt 1
        assert captured_options[2].effort == "high"  # attempt 2

    @pytest.mark.asyncio
    async def test_effort_low_on_first_attempt(self, tmp_path: Path) -> None:
        """First attempt (retry_count=0) uses effort=low."""
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("all good")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].effort == "low"

    @pytest.mark.asyncio
    async def test_succeeds_on_second_attempt_with_medium_effort(self, tmp_path: Path) -> None:
        """When the first attempt fails and second succeeds, no exception is raised."""
        state = _make_state(tmp_path)
        call_count = 0
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            captured_options.append(options)
            if call_count == 1:
                return _make_run_result("TESTS FAILED")
            return _make_run_result("all tests passed")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 2
        assert captured_options[0].effort == "low"
        assert captured_options[1].effort == "medium"


# ---------------------------------------------------------------------------
# Issue #250 — Phase 6 ticks tests_passed for closed issues on success
# ---------------------------------------------------------------------------


def _make_state_with_closed_issues(
    tmp_path: Path, closed_numbers: list[int], requirements_hash: str | None = "abcd1234"
) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    st.requirements_hash = requirements_hash
    st.issues = [
        _state.IssueState(number=n, status="closed", agent="python-pro", title=f"Issue {n}")
        for n in closed_numbers
    ]
    _state.save_state(state_dir / "state.json", st)
    return st


def _seed_checklist(tmp_path: Path, requirements_hash: str, issue_numbers: list[int]) -> Path:
    from code_generator import checklist

    checklist_path = tmp_path / ".code-generator" / "checklists" / f"{requirements_hash}.json"
    issues = [
        _state.IssueState(number=n, status="open", agent="python-pro", title=f"Issue {n}")
        for n in issue_numbers
    ]
    checklist.seed(checklist_path, issues)
    return checklist_path


class TestPhase6ChecklistTicks:
    @pytest.mark.asyncio
    async def test_phase6_ticks_tests_passed_for_each_closed_issue_on_success(
        self, tmp_path: Path
    ) -> None:
        from code_generator import checklist

        state = _make_state_with_closed_issues(tmp_path, [1, 2])
        checklist_path = _seed_checklist(tmp_path, "abcd1234", [1, 2])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("All 42 tests passed.")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        entries = {e.issue_number: e for e in checklist.load(checklist_path)}
        assert entries[1].tests_passed is True
        assert entries[2].tests_passed is True
        assert entries[1].committed is False
        assert entries[1].feature_done is False  # committed still False

    @pytest.mark.asyncio
    async def test_phase6_does_not_tick_on_failure_path(self, tmp_path: Path) -> None:
        from code_generator import checklist

        state = _make_state_with_closed_issues(tmp_path, [1])
        checklist_path = _seed_checklist(tmp_path, "abcd1234", [1])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("TESTS FAILED")

        with (
            patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop),
            pytest.raises(TestsFailed),
        ):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        entries = checklist.load(checklist_path)
        assert entries[0].tests_passed is False
        assert entries[0].feature_done is False

    @pytest.mark.asyncio
    async def test_phase6_skips_tick_when_requirements_hash_missing(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        state = _make_state_with_closed_issues(tmp_path, [1], requirements_hash=None)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result("All tests passed.")

        with (
            patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop),
            caplog.at_level(logging.WARNING),
        ):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        checklists_dir = tmp_path / ".code-generator" / "checklists"
        assert not checklists_dir.exists()
        assert any("requirements_hash" in rec.getMessage().lower() for rec in caplog.records)
