"""Tests for code_generator.manifest — multi-stack manifest reader/writer."""

from __future__ import annotations

import json
import logging
from pathlib import Path

import pytest

from code_generator import manifest
from code_generator.manifest import (
    ManifestMatch,
    detect_manifests,
    read_version,
    write_version,
)

# ---------------------------------------------------------------------------
# Fixture writers — one per stack
# ---------------------------------------------------------------------------


def _write_pyproject(root: Path, version: str = "1.2.3") -> Path:
    path = root / "pyproject.toml"
    path.write_text(
        f'[project]\nname = "demo"\nversion = "{version}"\n# trailing comment preserved\n'
    )
    return path


def _write_package_json(root: Path, version: str = "1.2.3") -> Path:
    path = root / "package.json"
    path.write_text(json.dumps({"name": "demo", "version": version}, indent=2))
    return path


def _write_cargo(root: Path, version: str = "1.2.3") -> Path:
    path = root / "Cargo.toml"
    path.write_text(f'[package]\nname = "demo"\nversion = "{version}"\nedition = "2021"\n')
    return path


def _write_gomod(root: Path) -> Path:
    path = root / "go.mod"
    path.write_text("module example.com/demo\n\ngo 1.22\n")
    return path


def _write_angular(root: Path, version: str = "1.2.3") -> Path:
    path = root / "angular.json"
    path.write_text(json.dumps({"version": version, "projects": {}}, indent=2))
    return path


def _write_nest_cli(root: Path, version: str = "1.2.3") -> Path:
    path = root / "nest-cli.json"
    path.write_text(json.dumps({"version": version, "sourceRoot": "src"}, indent=2))
    return path


_WRITERS = {
    "pyproject.toml": _write_pyproject,
    "package.json": _write_package_json,
    "Cargo.toml": _write_cargo,
    "angular.json": _write_angular,
    "nest-cli.json": _write_nest_cli,
}


# ---------------------------------------------------------------------------
# ManifestMatch
# ---------------------------------------------------------------------------


class TestManifestMatch:
    def test_when_constructed_then_fields_exposed(self, tmp_path: Path) -> None:
        m = ManifestMatch(path=tmp_path / "a", stack="pyproject", current_version="1.0.0")
        assert m.path == tmp_path / "a"
        assert m.stack == "pyproject"
        assert m.current_version == "1.0.0"


# ---------------------------------------------------------------------------
# detect_manifests
# ---------------------------------------------------------------------------


class TestDetectManifests:
    def test_when_no_manifests_then_empty_list_is_returned(self, tmp_path: Path) -> None:
        assert detect_manifests(tmp_path) == []

    def test_when_pyproject_exists_then_one_match_is_returned(self, tmp_path: Path) -> None:
        _write_pyproject(tmp_path, "1.2.3")
        matches = detect_manifests(tmp_path)
        assert len(matches) == 1
        assert matches[0].stack == "pyproject"
        assert matches[0].current_version == "1.2.3"
        assert matches[0].path == tmp_path / "pyproject.toml"

    def test_when_all_manifests_exist_then_returned_in_canonical_order(
        self, tmp_path: Path
    ) -> None:
        _write_pyproject(tmp_path)
        _write_package_json(tmp_path)
        _write_cargo(tmp_path)
        _write_gomod(tmp_path)
        _write_angular(tmp_path)
        _write_nest_cli(tmp_path)

        stacks = [m.stack for m in detect_manifests(tmp_path)]

        assert stacks == [
            "pyproject",
            "package.json",
            "Cargo.toml",
            "go.mod",
            "angular.json",
            "nest-cli.json",
        ]

    def test_when_go_mod_only_then_current_version_is_empty(self, tmp_path: Path) -> None:
        _write_gomod(tmp_path)
        matches = detect_manifests(tmp_path)
        assert len(matches) == 1
        assert matches[0].stack == "go.mod"
        assert matches[0].current_version == ""


# ---------------------------------------------------------------------------
# read_version / write_version round-trip per stack
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "filename",
    ["pyproject.toml", "package.json", "Cargo.toml", "angular.json", "nest-cli.json"],
)
class TestReadWriteRoundTrip:
    def test_when_read_then_initial_version_is_returned(
        self, tmp_path: Path, filename: str
    ) -> None:
        _WRITERS[filename](tmp_path, "1.0.0")
        match = detect_manifests(tmp_path)[0]
        assert read_version(match) == "1.0.0"

    def test_when_written_then_subsequent_read_returns_new_version(
        self, tmp_path: Path, filename: str
    ) -> None:
        _WRITERS[filename](tmp_path, "1.0.0")
        match = detect_manifests(tmp_path)[0]

        write_version(match, "2.3.4")

        new_match = detect_manifests(tmp_path)[0]
        assert new_match.current_version == "2.3.4"
        assert read_version(new_match) == "2.3.4"


# ---------------------------------------------------------------------------
# go.mod — special case
# ---------------------------------------------------------------------------


class TestGoMod:
    def test_when_read_then_empty_string_is_returned(self, tmp_path: Path) -> None:
        _write_gomod(tmp_path)
        match = detect_manifests(tmp_path)[0]
        assert read_version(match) == ""

    def test_when_write_then_file_is_unchanged(self, tmp_path: Path) -> None:
        path = _write_gomod(tmp_path)
        original = path.read_text()
        match = detect_manifests(tmp_path)[0]

        write_version(match, "9.9.9")

        assert path.read_text() == original

    def test_when_write_then_info_is_logged(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        _write_gomod(tmp_path)
        match = detect_manifests(tmp_path)[0]

        with caplog.at_level(logging.INFO, logger="code_generator.manifest"):
            write_version(match, "9.9.9")

        assert any("go.mod" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# pyproject — formatting preservation
# ---------------------------------------------------------------------------


class TestPyprojectPreservesFormatting:
    def test_when_written_then_comments_are_preserved(self, tmp_path: Path) -> None:
        path = _write_pyproject(tmp_path, "1.0.0")
        match = detect_manifests(tmp_path)[0]

        write_version(match, "2.0.0")

        text = path.read_text()
        assert 'version = "2.0.0"' in text
        assert "# trailing comment preserved" in text


# ---------------------------------------------------------------------------
# JSON — indent=2 round-trip
# ---------------------------------------------------------------------------


class TestJsonIndent:
    def test_when_package_json_written_then_indented_two_spaces(self, tmp_path: Path) -> None:
        path = _write_package_json(tmp_path, "1.0.0")
        match = detect_manifests(tmp_path)[0]

        write_version(match, "2.0.0")

        text = path.read_text()
        assert '  "version": "2.0.0"' in text


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------


class TestAtomicWrite:
    def test_when_written_then_tmp_file_does_not_remain(self, tmp_path: Path) -> None:
        _write_package_json(tmp_path, "1.0.0")
        match = detect_manifests(tmp_path)[0]

        write_version(match, "2.0.0")

        leftover = list(tmp_path.glob("*.tmp"))
        assert leftover == []


def test_module_has_no_cli() -> None:
    """manifest module must not expose argparse / Typer."""
    src = Path(manifest.__file__).read_text()
    assert "argparse" not in src
    assert "typer" not in src.lower()
