"""Unit tests for the bench command and fake runner.

Acceptance criteria (issue #193):
  - bench --fake --output produces JSON matching the documented schema keys.
  - Two identical --fake runs produce byte-identical JSON modulo timestamp_utc.
  - --real path exercises a mocked SDK that records it was invoked once per cycle.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest  # noqa: TC002

from code_generator.commands.bench import (
    SCHEMA_VERSION,
    _build_report,
    _iterate_cycles,
    _write_output,
)
from code_generator.runner.fake_runner import CANNED_PHASE_USAGE, get_phase_result
from code_generator.runner.types import RunResult, TokenUsage

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_FIXTURE_PATH = str(Path(__file__).parent / "fixtures" / "bench-project")
_ALL_PHASES = list(range(8))
_SCHEMA_REQUIRED_KEYS = {"schema_version", "timestamp_utc", "session_mode", "fixture", "cycles"}
_CYCLE_REQUIRED_KEYS = {"cycle_name", "phases", "totals"}
_PHASE_REQUIRED_KEYS = {
    "input",
    "output",
    "cache_read",
    "cache_write",
    "cache_hit_pct",
    "wall_seconds",
    "num_turns",
    "cache_write_5m",
    "cache_write_1h",
    "compaction_events",
    "clear_events",
    "cache_hit_ratio",
}


# ---------------------------------------------------------------------------
# Fake runner unit tests
# ---------------------------------------------------------------------------


class TestFakeRunner:
    """Validate determinism and shape of fake_runner outputs."""

    def test_get_phase_result_returns_run_result(self) -> None:
        result = get_phase_result(0)
        assert isinstance(result, RunResult)

    def test_canned_phase_usage_covers_all_phases(self) -> None:
        for phase in _ALL_PHASES:
            assert phase in CANNED_PHASE_USAGE, f"Phase {phase} missing from CANNED_PHASE_USAGE"

    def test_get_phase_result_is_deterministic(self) -> None:
        r1 = get_phase_result(3)
        r2 = get_phase_result(3)
        assert r1.usage == r2.usage
        assert r1.wall_seconds == r2.wall_seconds

    def test_canned_phase_usage_has_varied_cache_hit_ratios(self) -> None:
        """Ensure later phases have higher cache_read for realistic signal."""
        phase0_read = CANNED_PHASE_USAGE[0].cache_read
        phase5_read = CANNED_PHASE_USAGE[5].cache_read
        assert phase5_read > phase0_read, "Later phases should have more cache_read"


# ---------------------------------------------------------------------------
# _write_output unit tests
# ---------------------------------------------------------------------------


class TestWriteOutput:
    """Validate atomic write and stdout path."""

    def test_writes_json_to_file_atomically(self, tmp_path: Path) -> None:
        out = tmp_path / "bench.json"
        payload = {"schema_version": 1, "foo": "bar"}
        _write_output(out, payload)
        assert out.exists()
        loaded = json.loads(out.read_text())
        assert loaded == payload

    def test_write_output_none_prints_to_stdout(self, capsys: pytest.CaptureFixture) -> None:
        payload = {"schema_version": 1}
        _write_output(None, payload)
        captured = capsys.readouterr()
        assert json.loads(captured.out) == payload

    def test_atomic_write_uses_temp_then_replace(self, tmp_path: Path) -> None:
        """Verify the output file ends up with correct content (tmp→replace pattern)."""
        out = tmp_path / "report.json"
        _write_output(out, {"ok": True})
        assert json.loads(out.read_text()) == {"ok": True}


# ---------------------------------------------------------------------------
# _iterate_cycles + _build_report unit tests
# ---------------------------------------------------------------------------


class TestIterateCycles:
    """Validate that _iterate_cycles returns correctly structured cycle dicts."""

    def test_returns_n_cycles(self) -> None:
        cycles = _iterate_cycles(n=3, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        assert len(cycles) == 3

    def test_each_cycle_has_required_keys(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        assert set(cycles[0].keys()) >= _CYCLE_REQUIRED_KEYS

    def test_phases_dict_covers_all_eight_phases(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="shared")
        phases = cycles[0]["phases"]
        for phase in _ALL_PHASES:
            assert str(phase) in phases, f"Phase {phase} missing from cycle report"

    def test_each_phase_has_required_metrics(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        phase0 = cycles[0]["phases"]["0"]
        assert set(phase0.keys()) >= _PHASE_REQUIRED_KEYS

    def test_totals_has_required_metrics(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        assert set(cycles[0]["totals"].keys()) >= _PHASE_REQUIRED_KEYS


class TestBuildReport:
    """Validate _build_report output shape and field values."""

    def test_schema_version_is_correct(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        report = _build_report(cycles, fixture=_FIXTURE_PATH, session_mode="fresh", timestamp="t")
        assert report["schema_version"] == SCHEMA_VERSION

    def test_required_top_level_keys_present(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        report = _build_report(cycles, fixture=_FIXTURE_PATH, session_mode="fresh", timestamp="t")
        assert set(report.keys()) >= _SCHEMA_REQUIRED_KEYS

    def test_session_mode_reflected_in_report(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="shared")
        report = _build_report(cycles, fixture=_FIXTURE_PATH, session_mode="shared", timestamp="t")
        assert report["session_mode"] == "shared"

    def test_fixture_path_reflected_in_report(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        report = _build_report(cycles, fixture=_FIXTURE_PATH, session_mode="fresh", timestamp="t")
        assert report["fixture"] == _FIXTURE_PATH


# ---------------------------------------------------------------------------
# Bench --fake determinism tests
# ---------------------------------------------------------------------------


class TestFakeDeterminism:
    """Two --fake runs produce byte-identical JSON modulo timestamp_utc."""

    def _make_report(self) -> dict:
        cycles = _iterate_cycles(n=2, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        return _build_report(
            cycles, fixture=_FIXTURE_PATH, session_mode="fresh", timestamp="2026-01-01T00:00:00"
        )

    def test_two_fake_runs_identical_when_timestamp_excluded(self) -> None:
        r1 = self._make_report()
        r2 = self._make_report()
        # Remove the dynamic field before comparing
        r1.pop("timestamp_utc", None)
        r2.pop("timestamp_utc", None)
        assert json.dumps(r1, sort_keys=True) == json.dumps(r2, sort_keys=True)

    def test_fake_report_serialisable_as_json(self) -> None:
        report = self._make_report()
        serialised = json.dumps(report)
        assert json.loads(serialised) == report


# ---------------------------------------------------------------------------
# --real path mocked-SDK unit test
# ---------------------------------------------------------------------------


class TestRealPathMockedSdk:
    """--real dispatches through the real runner and invokes it once per cycle."""

    def test_real_path_invokes_runner_once_per_cycle(self, tmp_path: Path) -> None:
        fake_usage = TokenUsage(input=100, output=20, cache_read=50, cache_write=10)
        fake_result = RunResult(
            text="bench-ok", session_id=None, usage=fake_usage, wall_seconds=1.0
        )

        with patch(
            "code_generator.commands.bench._run_real_phase",
            return_value=fake_result,
        ) as mock_run:
            cycles = _iterate_cycles(
                n=2,
                use_fake=False,
                fixture=_FIXTURE_PATH,
                session_mode="fresh",
                _runner_override=mock_run,
            )

        # 2 cycles × 8 phases = 16 calls
        assert mock_run.call_count == 2 * len(_ALL_PHASES)
        assert len(cycles) == 2

    def test_real_path_cycle_report_has_expected_shape(self, tmp_path: Path) -> None:
        fake_usage = TokenUsage(input=100, output=20, cache_read=50, cache_write=10)
        fake_result = RunResult(text="ok", session_id=None, usage=fake_usage, wall_seconds=0.5)

        with patch(
            "code_generator.commands.bench._run_real_phase",
            return_value=fake_result,
        ) as mock_run:
            cycles = _iterate_cycles(
                n=1,
                use_fake=False,
                fixture=_FIXTURE_PATH,
                session_mode="fresh",
                _runner_override=mock_run,
            )

        assert set(cycles[0].keys()) >= _CYCLE_REQUIRED_KEYS
        assert set(cycles[0]["phases"]["0"].keys()) >= _PHASE_REQUIRED_KEYS


# ---------------------------------------------------------------------------
# JSON output AC test
# ---------------------------------------------------------------------------


class TestBenchOutput:
    """bench --fake writes valid JSON matching the documented schema."""

    def test_json_output_passes_loads_and_matches_schema(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from code_generator.cli import app

        out_file = tmp_path / "bench-out.json"
        runner = CliRunner()
        result = runner.invoke(app, ["bench", "--fake", "--output", str(out_file)])

        assert result.exit_code == 0, result.output
        assert out_file.exists()
        loaded = json.loads(out_file.read_text())

        assert set(loaded.keys()) >= _SCHEMA_REQUIRED_KEYS
        assert loaded["schema_version"] == SCHEMA_VERSION
        assert loaded["cycles"]
        cycle = loaded["cycles"][0]
        assert set(cycle.keys()) >= _CYCLE_REQUIRED_KEYS
        for phase in _ALL_PHASES:
            assert str(phase) in cycle["phases"]

    def test_json_output_to_stdout_when_no_output_flag(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from code_generator.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["bench", "--fake"])

        assert result.exit_code == 0, result.output
        loaded = json.loads(result.output)
        assert set(loaded.keys()) >= _SCHEMA_REQUIRED_KEYS


# ---------------------------------------------------------------------------
# Issue #212 — num_turns in bench output + SCHEMA_VERSION bump
# ---------------------------------------------------------------------------


class TestBenchSchemaVersion:
    """SCHEMA_VERSION is bumped so consumers know the shape changed."""

    def test_schema_version_is_bumped_to_3(self) -> None:
        """Issue #248: SCHEMA_VERSION bumped to 3 when TTL split + cache_hit_ratio added."""
        assert SCHEMA_VERSION == 3


class TestNumTurnsInBenchOutput:
    """`num_turns` appears in every phase dict and in totals."""

    def test_phase_metrics_includes_num_turns_from_usage(self) -> None:
        """Issue #212: _phase_metrics surfaces num_turns from the RunResult's usage."""
        from code_generator.commands.bench import _phase_metrics

        result = RunResult(
            text="ok",
            session_id=None,
            usage=TokenUsage(input=10, output=5, num_turns=12),
            wall_seconds=0.5,
        )
        metrics = _phase_metrics(result)
        assert metrics["num_turns"] == 12

    def test_fake_cycle_report_populates_num_turns_for_every_phase(self) -> None:
        """Every phases dict in a fake cycle run contains a num_turns integer."""
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        for phase in _ALL_PHASES:
            phase_dict = cycles[0]["phases"][str(phase)]
            assert "num_turns" in phase_dict, f"num_turns missing from phase {phase}"
            assert isinstance(phase_dict["num_turns"], int)

    def test_phase3_carries_specific_num_turns_value(self) -> None:
        """Issue #212 AC: a specific canned ``num_turns`` value is surfaced intact."""
        from code_generator.runner.fake_runner import CANNED_PHASE_USAGE

        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        expected = CANNED_PHASE_USAGE[3].num_turns
        assert expected > 0, "canned fake data must seed a non-zero num_turns for this AC"
        assert cycles[0]["phases"]["3"]["num_turns"] == expected

    def test_totals_sums_num_turns_across_phases(self) -> None:
        """Aggregate totals include a summed num_turns across all phases."""
        from code_generator.runner.fake_runner import CANNED_PHASE_USAGE

        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        expected_total = sum(u.num_turns for u in CANNED_PHASE_USAGE.values())
        assert cycles[0]["totals"]["num_turns"] == expected_total


# ---------------------------------------------------------------------------
# Issue #248 — v3 schema (TTL split, lifecycle counters, cache_hit_ratio)
# ---------------------------------------------------------------------------


class TestV3PhaseMetrics:
    """``_phase_metrics`` exposes the new v3 keys with correct values."""

    def test_phase_metrics_emits_cache_write_5m_and_1h_from_usage(self) -> None:
        from code_generator.commands.bench import _phase_metrics

        usage = TokenUsage(
            input=10,
            output=5,
            cache_write=42,
            cache_write_5m=12,
            cache_write_1h=30,
        )
        metrics = _phase_metrics(RunResult(text="x", session_id=None, usage=usage))

        assert metrics["cache_write_5m"] == 12
        assert metrics["cache_write_1h"] == 30
        assert metrics["cache_write"] == 42

    def test_phase_metrics_emits_compaction_and_clear_events(self) -> None:
        from code_generator.commands.bench import _phase_metrics

        usage = TokenUsage(compaction_events=3, clear_events=2)
        metrics = _phase_metrics(RunResult(text="x", session_id=None, usage=usage))

        assert metrics["compaction_events"] == 3
        assert metrics["clear_events"] == 2

    def test_phase_metrics_cache_hit_ratio_is_zero_to_one_float(self) -> None:
        from code_generator.commands.bench import _phase_metrics

        usage = TokenUsage(input=20, cache_read=80)
        metrics = _phase_metrics(RunResult(text="x", session_id=None, usage=usage))

        assert metrics["cache_hit_ratio"] == pytest.approx(0.8)

    def test_phase_metrics_cache_hit_ratio_zero_denominator_returns_zero(self) -> None:
        from code_generator.commands.bench import _phase_metrics

        usage = TokenUsage(output=999)
        metrics = _phase_metrics(RunResult(text="x", session_id=None, usage=usage))

        assert metrics["cache_hit_ratio"] == 0.0


class TestV3AggregateTotals:
    """``_aggregate_totals`` sums new counters and recomputes ratios."""

    def test_totals_sum_cache_write_split_and_compaction_clear_events(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        from code_generator.runner.fake_runner import CANNED_PHASE_USAGE

        totals = cycles[0]["totals"]
        assert totals["cache_write_5m"] == sum(
            u.cache_write_5m for u in CANNED_PHASE_USAGE.values()
        )
        assert totals["cache_write_1h"] == sum(
            u.cache_write_1h for u in CANNED_PHASE_USAGE.values()
        )
        assert totals["compaction_events"] == sum(
            u.compaction_events for u in CANNED_PHASE_USAGE.values()
        )
        assert totals["clear_events"] == sum(u.clear_events for u in CANNED_PHASE_USAGE.values())

    def test_totals_recompute_cache_hit_ratio_from_summed_counters(self) -> None:
        cycles = _iterate_cycles(n=1, use_fake=True, fixture=_FIXTURE_PATH, session_mode="fresh")
        from code_generator.runner.fake_runner import CANNED_PHASE_USAGE

        sum_read = sum(u.cache_read for u in CANNED_PHASE_USAGE.values())
        sum_write = sum(u.cache_write for u in CANNED_PHASE_USAGE.values())
        sum_input = sum(u.input for u in CANNED_PHASE_USAGE.values())
        expected = sum_read / (sum_read + sum_write + sum_input)

        assert cycles[0]["totals"]["cache_hit_ratio"] == pytest.approx(expected)
