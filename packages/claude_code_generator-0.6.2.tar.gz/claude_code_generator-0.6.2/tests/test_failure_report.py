"""Tests for code_generator.orchestrator.failure_report — Issue #282.

Trace-rich failure report dataclass + formatter consumed by Phase 6.6.
"""

from __future__ import annotations

import os
from pathlib import Path

from code_generator.orchestrator.failure_report import (
    FailureReport,
    format_failure_report,
    persist_failure_report,
)
from code_generator.orchestrator.phase6_5_verify import (
    TierResult,
    _format_failure_report,
)

# ---------------------------------------------------------------------------
# TierResult new fields — defaults preserve Cycle 1 construction sites
# ---------------------------------------------------------------------------


def test_legacy_tierresult_construction_no_kwargs_required() -> None:
    """Cycle-1 construction with only the original 7 fields must still work."""
    result = TierResult(
        tier_id="T0",
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=0,
        stderr_tail=None,
        failing_detail=None,
    )
    assert result.stdout_full is None
    assert result.http_request is None
    assert result.http_response is None
    assert result.browser_console == []
    assert result.screenshot_path is None


def test_tierresult_accepts_new_optional_fields() -> None:
    result = TierResult(
        tier_id="T3",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=None,
        failing_detail="UI did not render",
        stdout_full="stdout body",
        http_request="GET /api/items",
        http_response="200 OK\n[]",
        browser_console=["ReferenceError: x is not defined"],
        screenshot_path="/tmp/failure.png",
    )
    assert result.stdout_full == "stdout body"
    assert result.browser_console == ["ReferenceError: x is not defined"]


# ---------------------------------------------------------------------------
# FailureReport.from_tier_result
# ---------------------------------------------------------------------------


def test_when_from_tier_result_then_basic_fields_populated() -> None:
    result = TierResult(
        tier_id="T0",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=1,
        stderr_tail="boom",
        failing_detail="install failed",
    )

    report = FailureReport.from_tier_result(result, attempt=2, max_retries=3)

    assert report.tier_id == "T0"
    assert report.attempt == 2
    assert report.max_retries == 3
    assert report.exit_code == 1
    assert report.stderr_tail == "boom"
    assert report.failing_detail == "install failed"
    assert report.stdout_full is None
    assert report.http_request is None
    assert report.browser_console == ()


def test_when_from_tier_result_then_trace_fields_propagate() -> None:
    result = TierResult(
        tier_id="T3",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=None,
        failing_detail="UI broken",
        stdout_full="server logs...",
        http_request="GET /api/x",
        http_response="500 ISE",
        browser_console=["msg1", "msg2"],
        screenshot_path="/tmp/x.png",
    )

    report = FailureReport.from_tier_result(result, attempt=1, max_retries=3)

    assert report.stdout_full == "server logs..."
    assert report.http_request == "GET /api/x"
    assert report.http_response == "500 ISE"
    assert report.browser_console == ("msg1", "msg2")
    assert report.screenshot_path == "/tmp/x.png"


# ---------------------------------------------------------------------------
# format_failure_report
# ---------------------------------------------------------------------------


def test_when_format_then_includes_http_exchange_labels() -> None:
    report = FailureReport(
        tier_id="T2",
        attempt=1,
        max_retries=3,
        skipped=False,
        exit_code=None,
        failing_detail="endpoint failure",
        stderr_tail=None,
        stdout_full=None,
        http_request="GET /api/items",
        http_response="500 ISE\n{}",
        browser_console=(),
        screenshot_path=None,
    )

    text = format_failure_report(report)

    assert "HTTP request:" in text
    assert "GET /api/items" in text
    assert "HTTP response:" in text
    assert "500 ISE" in text


def test_when_format_then_omits_none_and_empty_fields() -> None:
    report = FailureReport(
        tier_id="T0",
        attempt=1,
        max_retries=3,
        skipped=False,
        exit_code=1,
        failing_detail="install failed",
        stderr_tail="boom",
        stdout_full=None,
        http_request=None,
        http_response=None,
        browser_console=(),
        screenshot_path=None,
    )

    text = format_failure_report(report)

    assert "Stdout (full):" not in text
    assert "HTTP request:" not in text
    assert "HTTP response:" not in text
    assert "Browser console:" not in text
    assert "Screenshot:" not in text
    assert "Stderr tail:" in text
    assert "boom" in text


def test_when_format_then_browser_console_lines_listed_in_order() -> None:
    report = FailureReport(
        tier_id="T3",
        attempt=1,
        max_retries=3,
        skipped=False,
        exit_code=None,
        failing_detail="ui broken",
        stderr_tail=None,
        stdout_full=None,
        http_request=None,
        http_response=None,
        browser_console=("first", "second", "third"),
        screenshot_path="/tmp/x.png",
    )

    text = format_failure_report(report)

    assert "Browser console:" in text
    first_idx = text.index("first")
    second_idx = text.index("second")
    third_idx = text.index("third")
    assert first_idx < second_idx < third_idx
    assert "/tmp/x.png" in text


# ---------------------------------------------------------------------------
# persist_failure_report — atomic
# ---------------------------------------------------------------------------


def test_when_persist_then_writes_atomically_to_phase6_5_failure_txt(
    tmp_path: Path, monkeypatch
) -> None:
    report = FailureReport(
        tier_id="T0",
        attempt=1,
        max_retries=3,
        skipped=False,
        exit_code=1,
        failing_detail="install failed",
        stderr_tail="boom",
        stdout_full=None,
        http_request=None,
        http_response=None,
        browser_console=(),
        screenshot_path=None,
    )

    captured: dict[str, tuple[str, str]] = {}
    original_replace = os.replace

    def spy_replace(src, dst) -> None:  # type: ignore[no-untyped-def]
        captured["call"] = (str(src), str(dst))
        original_replace(src, dst)

    monkeypatch.setattr(os, "replace", spy_replace)
    path = persist_failure_report(report, tmp_path)

    assert path == tmp_path / "phase6_5_failure.txt"
    src, dst = captured["call"]
    assert dst == str(path)
    assert src.endswith(".tmp")
    assert not Path(src).exists()
    assert path.exists()
    assert "PHASE 6.5 FAILURE REPORT" in path.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Backward compat: _format_failure_report unchanged shape for legacy inputs
# ---------------------------------------------------------------------------


def test_when_legacy_tierresult_then_format_failure_report_matches_cycle1_shape() -> None:
    """Wrapper output must keep the labels the repair prompt parses."""
    result = TierResult(
        tier_id="T1",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=42,
        stderr_tail="trace tail",
        failing_detail="port not listening",
    )

    text = _format_failure_report(result, attempt=2, max_retries=3)

    assert text.startswith("PHASE 6.5 FAILURE REPORT\n========================\n")
    assert "Attempt 2 of 3" in text
    assert "Tier: T1" in text
    assert "Skipped: False" in text
    assert "Exit code: 42" in text
    assert "Failing detail: port not listening" in text
    assert "Stderr tail:" in text
    assert "trace tail" in text


# ---------------------------------------------------------------------------
# __all__ export
# ---------------------------------------------------------------------------


def test_phase6_5_verify_exports_failure_report() -> None:
    from code_generator.orchestrator import phase6_5_verify

    assert "FailureReport" in phase6_5_verify.__all__
    assert phase6_5_verify.FailureReport is FailureReport
