"""Cycle 2 integration tests for Phase 6.5 (#290).

End-to-end coverage of the four Cycle 2 banner gates, with every
subprocess / HTTP / Playwright / docker seam patched to a deterministic
fake:

1. **Backend-only project** — T3 and T4 land in ``tiers_skipped`` with
   non-empty ``skip_reasons``.
2. **Full-stack project** — all five tiers run when both a frontend
   agent and ``docker-compose.yml`` are present.
3. **AgentSpec replay** — persist the spec, reload, re-run, and assert
   byte-equal ``Phase65Progress`` ordering.
4. **SICA isolation** — repair pass sees the
   ``clear_tool_uses_20250919`` directive in options; no Phase 3/4
   tool-use artifacts leak through.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from code_generator import checklist as _checklist
from code_generator import state as _state
from code_generator.orchestrator import phase6_5_verify, sica, tier_t3, tier_t4
from code_generator.orchestrator.agent_spec import (
    load_agent_spec,
    persist_agent_spec,
)
from code_generator.orchestrator.phase6_5_verify import TierResult, run

# ---------------------------------------------------------------------------
# Requirements fixtures
# ---------------------------------------------------------------------------


_BACKEND_REQUIREMENTS = """# Backend Service

## Description
A FastAPI service.

## Tech Stack
FastAPI + Postgres.

## Goals
- Ship the items API.

## Scope
### 1. Items API
Implement items endpoints.

Acceptance criteria
- [ ] `GET /api/items` returns 200 with JSON list

## Non-goals
- None.

## Constraints
- Linux only.

## Global acceptance criteria
- [ ] `GET /health` returns 200
"""


_FULLSTACK_REQUIREMENTS = """# Full-Stack App

## Description
Angular UI + FastAPI backend.

## Tech Stack
Angular + FastAPI + Postgres.

## Goals
- Ship full stack.

## Scope
### 1. Items API
Implement items endpoints.

Acceptance criteria
- [ ] `GET /api/items` returns 200 with JSON list

### 2. Dashboard
Render the dashboard page.

Acceptance criteria
- [ ] UI renders the dashboard with a header

## Non-goals
- None.

## Constraints
- Linux only.

## Global acceptance criteria
- [ ] `GET /health` returns 200
"""


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _passed(tier_id: str) -> TierResult:
    return TierResult(
        tier_id=tier_id,
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=0,
        stderr_tail=None,
        failing_detail=None,
    )


def _write_requirements(tmp_path: Path, body: str) -> Path:
    dot = tmp_path / ".code-generator"
    dot.mkdir(parents=True, exist_ok=True)
    req = dot / "requirements.md"
    req.write_text(body, encoding="utf-8")
    return req


def _seed_state(
    tmp_path: Path, *, requirements_hash: str, closed: list[int]
) -> tuple[_state.State, Path]:
    state_path = tmp_path / ".code-generator" / "state.json"
    state = _state.load_state(state_path)
    state.mode = "single"
    state.requirements_hash = requirements_hash
    state.issues = [
        _state.IssueState(number=n, status="closed", agent="python-pro", title=f"Issue {n}")
        for n in closed
    ]
    _state.save_state(state_path, state)
    return state, state_path


def _seed_checklist(tmp_path: Path, requirements_hash: str, issues: list[int]) -> Path:
    path = tmp_path / ".code-generator" / "checklists" / f"{requirements_hash}.json"
    _checklist.seed(
        path,
        [
            _state.IssueState(number=n, status="open", agent="python-pro", title=f"Issue {n}")
            for n in issues
        ],
    )
    return path


def _patch_pass_tiers(monkeypatch: pytest.MonkeyPatch) -> None:
    """Patch every tier to a deterministic pass for the active test."""
    monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: _passed("T0"))
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _passed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))
    monkeypatch.setattr(tier_t3, "run_t3_browser", lambda *_a, **_kw: _passed("T3"))
    monkeypatch.setattr(tier_t4, "run_t4_container", lambda *_a, **_kw: _passed("T4"))


@pytest.fixture
def logger() -> logging.Logger:
    return logging.getLogger("test.phase6_5_integration_cycle2")


@pytest.fixture
def shared_client() -> Any:
    return MagicMock(name="shared_client")


@pytest.fixture
def neutral_runner() -> Any:
    return MagicMock()


# ---------------------------------------------------------------------------
# Banner gate (1): backend-only → T3 + T4 skipped
# ---------------------------------------------------------------------------


class TestBackendOnlyProject:
    @pytest.mark.asyncio
    async def test_when_no_frontend_and_no_docker_then_t3_and_t4_skipped_with_reasons(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        neutral_runner: Any,
        shared_client: Any,
        logger: logging.Logger,
    ) -> None:
        _write_requirements(tmp_path, _BACKEND_REQUIREMENTS)
        state, state_path = _seed_state(tmp_path, requirements_hash="h1", closed=[1])
        _seed_checklist(tmp_path, "h1", [1])
        _patch_pass_tiers(monkeypatch)

        await run(
            state,
            None,
            tmp_path,
            state_path,
            runner_module=neutral_runner,
            logger=logger,
            shared_client=shared_client,
        )

        progress = state.phase6_5
        assert progress is not None
        assert set(progress.tiers_skipped) == {"T3", "T4"}
        assert progress.skip_reasons["T3"]
        assert progress.skip_reasons["T4"]
        assert "T0" in progress.tiers_passed
        assert "T1" in progress.tiers_passed
        assert "T2" in progress.tiers_passed


# ---------------------------------------------------------------------------
# Banner gate (2): full-stack → all five tiers run
# ---------------------------------------------------------------------------


class TestFullStackProject:
    @pytest.mark.asyncio
    async def test_when_frontend_and_compose_present_then_all_five_tiers_pass(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        neutral_runner: Any,
        shared_client: Any,
        logger: logging.Logger,
    ) -> None:
        _write_requirements(tmp_path, _FULLSTACK_REQUIREMENTS)
        (tmp_path / "docker-compose.yml").write_text("services: {}\n", encoding="utf-8")
        state, state_path = _seed_state(tmp_path, requirements_hash="h2", closed=[1, 2])
        _seed_checklist(tmp_path, "h2", [1, 2])
        _patch_pass_tiers(monkeypatch)

        await run(
            state,
            None,
            tmp_path,
            state_path,
            runner_module=neutral_runner,
            logger=logger,
            shared_client=shared_client,
        )

        progress = state.phase6_5
        assert progress is not None
        assert set(progress.tiers_passed) == {"T0", "T1", "T2", "T3", "T4"}
        assert progress.tiers_skipped == []
        assert progress.tiers_failed == []


# ---------------------------------------------------------------------------
# Banner gate (3): AgentSpec replay determinism
# ---------------------------------------------------------------------------


class TestAgentSpecReplay:
    @pytest.mark.asyncio
    async def test_when_spec_replayed_then_tier_sequence_byte_identical(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        neutral_runner: Any,
        shared_client: Any,
        logger: logging.Logger,
    ) -> None:
        _write_requirements(tmp_path, _FULLSTACK_REQUIREMENTS)
        (tmp_path / "docker-compose.yml").write_text("services: {}\n", encoding="utf-8")
        state_a, state_path_a = _seed_state(tmp_path, requirements_hash="h3", closed=[1])
        _seed_checklist(tmp_path, "h3", [1])
        _patch_pass_tiers(monkeypatch)

        await run(
            state_a,
            None,
            tmp_path,
            state_path_a,
            runner_module=neutral_runner,
            logger=logger,
            shared_client=shared_client,
        )
        spec_first = load_agent_spec(tmp_path / ".code-generator")
        progress_first = state_a.phase6_5
        assert progress_first is not None

        # Replay: persist + reload + run again under the same fakes
        persist_agent_spec(spec_first, tmp_path / ".code-generator")
        spec_reloaded = load_agent_spec(tmp_path / ".code-generator")
        state_b, state_path_b = _seed_state(tmp_path, requirements_hash="h3", closed=[1])

        await run(
            state_b,
            None,
            tmp_path,
            state_path_b,
            runner_module=neutral_runner,
            logger=logger,
            shared_client=shared_client,
        )
        progress_second = state_b.phase6_5

        assert spec_reloaded == spec_first
        assert progress_second is not None
        assert progress_second.tiers_passed == progress_first.tiers_passed
        assert progress_second.tiers_failed == progress_first.tiers_failed
        assert progress_second.tiers_skipped == progress_first.tiers_skipped

    def test_when_spec_persisted_before_tiers_run_then_file_exists_after_first_save(
        self, tmp_path: Path
    ) -> None:
        """AgentSpec lands on disk under .code-generator/phase6_5_spec.json."""
        from code_generator.orchestrator.tier_selector import select_tiers

        _write_requirements(tmp_path, _BACKEND_REQUIREMENTS)
        tiers = select_tiers(tmp_path, tmp_path / ".code-generator" / "requirements.md")
        from code_generator.orchestrator.agent_spec import build_agent_spec

        spec = build_agent_spec(
            tmp_path,
            (tmp_path / ".code-generator" / "requirements.md").read_text(encoding="utf-8"),
            {t.tier_id: t.enabled for t in tiers if t.tier_id in {"T3", "T4"}},
        )
        path = persist_agent_spec(spec, tmp_path / ".code-generator")

        assert path == tmp_path / ".code-generator" / "phase6_5_spec.json"
        assert path.exists()


# ---------------------------------------------------------------------------
# Banner gate (4): SICA isolation
# ---------------------------------------------------------------------------


class TestSICAIsolation:
    @pytest.mark.asyncio
    async def test_when_repair_pass_dispatched_then_clear_tool_uses_in_options(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        neutral_runner: Any,
        shared_client: Any,
        logger: logging.Logger,
    ) -> None:
        """Repair pass must inject ``clear_tool_uses_20250919`` server-side."""
        _write_requirements(tmp_path, _BACKEND_REQUIREMENTS)
        state, state_path = _seed_state(tmp_path, requirements_hash="h4", closed=[1])
        _seed_checklist(tmp_path, "h4", [1])

        # T0 fails so the repair pass fires.
        monkeypatch.setattr(
            phase6_5_verify,
            "run_t0_build",
            lambda *_a, **_kw: TierResult(
                tier_id="T0",
                passed=False,
                skipped=False,
                skip_reason=None,
                exit_code=1,
                stderr_tail="boom",
                failing_detail="install failed",
            ),
        )
        monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _passed("T1"))
        monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))

        captured: dict[str, Any] = {}

        async def fake_dispatch(
            client: Any, prompt: str, options: Any, *, logger: Any, state_path: Any
        ) -> Any:
            captured["client"] = client
            captured["options"] = options
            from code_generator.runner.types import RunResult, TokenUsage

            return RunResult(text="", session_id=None, usage=TokenUsage())

        monkeypatch.setattr(sica, "run_with_shared_client", fake_dispatch)

        with pytest.raises(phase6_5_verify.VerificationFailed):
            await run(
                state,
                None,
                tmp_path,
                state_path,
                runner_module=neutral_runner,
                logger=logger,
                shared_client=shared_client,
                max_retries=1,
            )

        # SICA wrapped the call: same client, clear_tool_uses_20250919 in options
        assert captured["client"] is shared_client
        cm = captured["options"].context_management
        assert cm is not None
        tools = cm.get("tools", [])
        assert any(t.get("type") == "clear_tool_uses_20250919" for t in tools)

    @pytest.mark.asyncio
    async def test_when_repair_pass_dispatched_then_no_phase34_artifacts_in_options(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        neutral_runner: Any,
        shared_client: Any,
        logger: logging.Logger,
    ) -> None:
        """Verifier role prefix is injected; Phase 3/4 noise stays out."""
        _write_requirements(tmp_path, _BACKEND_REQUIREMENTS)
        state, state_path = _seed_state(tmp_path, requirements_hash="h5", closed=[1])
        _seed_checklist(tmp_path, "h5", [1])

        monkeypatch.setattr(
            phase6_5_verify,
            "run_t1_boot",
            lambda *_a, **_kw: TierResult(
                tier_id="T1",
                passed=False,
                skipped=False,
                skip_reason=None,
                exit_code=1,
                stderr_tail="boom",
                failing_detail="boot failed",
            ),
        )
        monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: _passed("T0"))
        monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))

        captured: dict[str, Any] = {}

        async def fake_dispatch(
            client: Any, prompt: str, options: Any, *, logger: Any, state_path: Any
        ) -> Any:
            captured["options"] = options
            captured["prompt"] = prompt
            from code_generator.runner.types import RunResult, TokenUsage

            return RunResult(text="", session_id=None, usage=TokenUsage())

        monkeypatch.setattr(sica, "run_with_shared_client", fake_dispatch)

        with pytest.raises(phase6_5_verify.VerificationFailed):
            await run(
                state,
                None,
                tmp_path,
                state_path,
                runner_module=neutral_runner,
                logger=logger,
                shared_client=shared_client,
                max_retries=1,
            )

        sp = captured["options"].system_prompt
        text = sp.get("append", "") if isinstance(sp, dict) else sp or ""
        assert sica.VERIFIER_ROLE_PREFIX.strip() in text
        # No Phase 3/4 implementer artifacts in the dispatched prompt
        assert "TestImplementer" not in captured["prompt"]
        assert "Phase 3/4" not in captured["prompt"] or "verifier" in text.lower()


# Suppress unused-import lint on AsyncMock (kept for future test growth).
_ = AsyncMock
