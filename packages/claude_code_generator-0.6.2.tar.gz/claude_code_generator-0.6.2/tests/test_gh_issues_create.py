"""Tests for code_generator.gh.issues.create_issue — Phase 8 remediation helper."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from code_generator.gh.core import GhError
from code_generator.gh.issues import create_issue
from code_generator.repo_info import RepoInfo

_REPO = RepoInfo(host="github.com", owner="test", name="repo")


def _url(number: int) -> str:
    """`gh issue create` prints the new issue URL on stdout."""
    return f"https://github.com/{_REPO.full}/issues/{number}"


class TestCreateIssue:
    def test_when_gh_succeeds_returns_new_issue_number(self) -> None:
        with patch("code_generator.gh.issues._run", return_value=_url(4242)):
            assert create_issue(_REPO, "Repair: lint", "body text") == 4242

    def test_when_no_labels_omits_label_flags(self) -> None:
        with patch("code_generator.gh.issues._run", return_value=_url(1)) as mock_run:
            create_issue(_REPO, "T", "B")
        argv = mock_run.call_args[0][0]
        assert argv == [
            "gh",
            "issue",
            "create",
            "--repo",
            _REPO.full,
            "--title",
            "T",
            "--body",
            "B",
        ]
        assert "--json" not in argv
        assert mock_run.call_args.kwargs["env"] == {"GH_HOST": _REPO.host}

    def test_when_labels_passed_each_expands_to_label_flag(self) -> None:
        with patch("code_generator.gh.issues._run", return_value=_url(7)) as mock_run:
            create_issue(
                _REPO,
                "Repair",
                "body",
                labels=["priority:high", "area:ci", "agent:python-pro"],
            )
        argv = mock_run.call_args[0][0]
        assert argv.count("--label") == 3
        label_values = [argv[i + 1] for i, tok in enumerate(argv) if tok == "--label"]
        assert label_values == ["priority:high", "area:ci", "agent:python-pro"]

    def test_when_labels_none_omits_label_flags(self) -> None:
        with patch("code_generator.gh.issues._run", return_value=_url(9)) as mock_run:
            create_issue(_REPO, "T", "B", labels=None)
        argv = mock_run.call_args[0][0]
        assert "--label" not in argv

    def test_when_gh_fails_propagates_gh_error_unchanged(self) -> None:
        with (
            patch(
                "code_generator.gh.issues._run",
                side_effect=GhError(1, "validation failed: title required"),
            ),
            pytest.raises(GhError) as exc_info,
        ):
            create_issue(_REPO, "", "body")
        assert exc_info.value.returncode == 1
        assert "title required" in exc_info.value.stderr

    def test_when_url_has_trailing_slash_still_parses_number(self) -> None:
        with patch("code_generator.gh.issues._run", return_value=_url(55) + "/"):
            result = create_issue(_REPO, "T", "B")
        assert result == 55
        assert isinstance(result, int)
