"""Tests for code_generator.semver — Conventional-Commit → version bump."""

from __future__ import annotations

import logging

import pytest

from code_generator import semver
from code_generator.semver import (
    CommitClass,
    compute_bump,
    is_monotonic,
    next_version,
    parse_commits,
)

# ---------------------------------------------------------------------------
# CommitClass dataclass
# ---------------------------------------------------------------------------


class TestCommitClass:
    def test_when_constructed_then_fields_are_exposed(self) -> None:
        c = CommitClass(sha="abc123", subject="feat: x", type="feat", breaking=False)
        assert c.sha == "abc123"
        assert c.subject == "feat: x"
        assert c.type == "feat"
        assert c.breaking is False

    def test_when_two_instances_have_same_values_then_they_are_equal(self) -> None:
        a = CommitClass(sha="1", subject="feat: x", type="feat", breaking=False)
        b = CommitClass(sha="1", subject="feat: x", type="feat", breaking=False)
        assert a == b

    def test_when_field_assignment_attempted_then_frozen_dataclass_error(self) -> None:
        """CommitClass is a frozen dataclass — mutation must raise."""
        import dataclasses

        c = CommitClass(sha="1", subject="feat: x", type="feat", breaking=False)
        with pytest.raises(dataclasses.FrozenInstanceError):
            c.sha = "mutated"  # type: ignore[misc]

    def test_when_class_inspected_then_dataclass_params_frozen_is_true(self) -> None:
        """Frozen invariant locked at class level, not just at instance."""
        assert CommitClass.__dataclass_params__.frozen is True  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# parse_commits
# ---------------------------------------------------------------------------


class TestParseCommits:
    def test_when_empty_input_then_empty_list_is_returned(self) -> None:
        assert parse_commits([]) == []

    def test_when_feat_line_then_one_commit_is_parsed(self) -> None:
        commits = parse_commits(["abc123 feat: add login"])
        assert len(commits) == 1
        assert commits[0] == CommitClass(
            sha="abc123", subject="feat: add login", type="feat", breaking=False
        )

    def test_when_fix_line_then_type_is_fix(self) -> None:
        commits = parse_commits(["sha1 fix: handle null"])
        assert commits[0].type == "fix"

    def test_when_scoped_commit_then_type_is_extracted(self) -> None:
        commits = parse_commits(["sha1 feat(api): add endpoint"])
        assert commits[0].type == "feat"
        assert commits[0].breaking is False

    def test_when_bang_in_subject_then_breaking_is_true(self) -> None:
        commits = parse_commits(["sha1 feat!: drop legacy auth"])
        assert commits[0].breaking is True
        assert commits[0].type == "feat"

    def test_when_scoped_bang_then_breaking_is_true(self) -> None:
        commits = parse_commits(["sha1 feat(api)!: drop endpoint"])
        assert commits[0].breaking is True

    def test_when_breaking_change_trailer_then_breaking_is_true(self) -> None:
        line = "sha1 feat: add x\n\nBREAKING CHANGE: removes old behavior"
        commits = parse_commits([line])
        assert commits[0].breaking is True
        assert commits[0].subject == "feat: add x"

    def test_when_non_conformant_line_then_it_is_skipped(self) -> None:
        commits = parse_commits(["sha1 not a conventional commit"])
        assert commits == []

    def test_when_non_conformant_line_then_debug_logged(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        with caplog.at_level(logging.DEBUG, logger="code_generator.semver"):
            parse_commits(["sha1 random subject"])
        assert any("skipped" in r.message.lower() for r in caplog.records)

    def test_when_mixed_lines_then_only_conformant_returned(self) -> None:
        commits = parse_commits(
            [
                "sha1 feat: a",
                "sha2 garbage line",
                "sha3 fix: b",
            ]
        )
        assert [c.type for c in commits] == ["feat", "fix"]
        assert [c.sha for c in commits] == ["sha1", "sha3"]

    def test_when_line_has_no_subject_then_skipped(self) -> None:
        assert parse_commits(["sha1"]) == []
        assert parse_commits([""]) == []


# ---------------------------------------------------------------------------
# compute_bump — parametrized
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("commits", "expected"),
    [
        ([], "none"),
        ([CommitClass("s", "feat: x", "feat", False)], "minor"),
        ([CommitClass("s", "fix: x", "fix", False)], "patch"),
        ([CommitClass("s", "feat!: x", "feat", True)], "major"),
        ([CommitClass("s", "fix!: x", "fix", True)], "major"),
        ([CommitClass("s", "chore: x", "chore", False)], "patch"),
        ([CommitClass("s", "docs: x", "docs", False)], "patch"),
        (
            [
                CommitClass("s1", "fix: a", "fix", False),
                CommitClass("s2", "feat: b", "feat", False),
            ],
            "minor",
        ),
        (
            [
                CommitClass("s1", "feat: a", "feat", False),
                CommitClass("s2", "fix!: b", "fix", True),
            ],
            "major",
        ),
    ],
)
class TestComputeBumpParametrized:
    def test_when_commits_given_then_bump_matches_expected(
        self, commits: list[CommitClass], expected: str
    ) -> None:
        assert compute_bump(commits) == expected


# ---------------------------------------------------------------------------
# next_version
# ---------------------------------------------------------------------------


class TestNextVersion:
    def test_when_current_is_empty_string_then_returns_initial(self) -> None:
        assert next_version("", "minor") == "0.1.0"

    def test_when_current_is_none_then_returns_initial(self) -> None:
        assert next_version(None, "major") == "0.1.0"

    def test_when_current_is_empty_then_initial_regardless_of_bump(self) -> None:
        assert next_version("", "none") == "0.1.0"
        assert next_version("", "patch") == "0.1.0"

    @pytest.mark.parametrize(
        ("current", "bump", "expected"),
        [
            ("1.2.3", "major", "2.0.0"),
            ("1.2.3", "minor", "1.3.0"),
            ("1.2.3", "patch", "1.2.4"),
            ("1.2.3", "none", "1.2.3"),
            ("v1.2.3", "minor", "1.3.0"),
            ("v0.1.0", "patch", "0.1.1"),
            ("v0.0.0", "major", "1.0.0"),
        ],
    )
    def test_when_current_present_then_bumped_correctly(
        self, current: str, bump: str, expected: str
    ) -> None:
        assert next_version(current, bump) == expected  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# is_monotonic
# ---------------------------------------------------------------------------


class TestIsMonotonic:
    def test_when_no_existing_tags_then_true(self) -> None:
        assert is_monotonic("0.1.0", []) is True

    def test_when_new_strictly_greater_then_true(self) -> None:
        assert is_monotonic("1.1.0", ["v1.0.0", "v0.9.0"]) is True

    def test_when_new_equal_to_existing_then_false(self) -> None:
        assert is_monotonic("1.0.0", ["v1.0.0"]) is False

    def test_when_new_lower_than_existing_then_false(self) -> None:
        assert is_monotonic("0.9.0", ["v1.0.0"]) is False

    def test_when_new_has_v_prefix_then_treated_same_as_unprefixed(self) -> None:
        assert is_monotonic("v1.1.0", ["v1.0.0"]) is True
        assert is_monotonic("v1.0.0", ["v1.0.0"]) is False

    def test_when_existing_unprefixed_then_still_compared(self) -> None:
        assert is_monotonic("1.0.1", ["1.0.0"]) is True
        assert is_monotonic("1.0.0", ["1.0.0"]) is False

    @pytest.mark.parametrize(
        ("new_ver", "existing", "expected"),
        [
            ("0.1.0", [], True),
            ("0.1.0", ["v0.1.0"], False),
            ("0.1.0", ["v0.0.9"], True),
            ("2.0.0", ["v1.99.99", "v1.0.0"], True),
            ("1.0.0", ["v2.0.0"], False),
            ("1.10.0", ["v1.9.0"], True),
        ],
    )
    def test_parametrized_monotonic_regressions(
        self, new_ver: str, existing: list[str], expected: bool
    ) -> None:
        assert is_monotonic(new_ver, existing) is expected


# ---------------------------------------------------------------------------
# End-to-end: history → bump → version
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("lines", "current", "expected"),
    [
        # initial release
        ([], "", "0.1.0"),
        # feat only → minor
        (["s1 feat: add login"], "v0.1.0", "0.2.0"),
        # fix only → patch
        (["s1 fix: typo"], "v0.1.0", "0.1.1"),
        # mixed → minor wins over patch
        (["s1 fix: a", "s2 feat: b"], "v0.1.0", "0.2.0"),
        # breaking via !
        (["s1 feat!: drop auth"], "v0.1.0", "1.0.0"),
        # breaking via BREAKING CHANGE trailer
        (["s1 feat: x\n\nBREAKING CHANGE: removes y"], "v0.1.0", "1.0.0"),
        # chore-only → patch
        (["s1 chore: bump dep"], "v0.1.0", "0.1.1"),
        # no commits → no bump
        ([], "v1.2.3", "1.2.3"),
    ],
)
def test_end_to_end_history_to_version(lines: list[str], current: str, expected: str) -> None:
    commits = parse_commits(lines)
    bump = compute_bump(commits)
    assert next_version(current, bump) == expected


def test_module_imports_regex_from_phase7() -> None:
    """semver must reuse the canonical regex, not redefine it."""
    from code_generator.orchestrator.phase7_commit import _CONVENTIONAL_COMMIT_RE

    assert semver._CONVENTIONAL_COMMIT_RE is _CONVENTIONAL_COMMIT_RE
