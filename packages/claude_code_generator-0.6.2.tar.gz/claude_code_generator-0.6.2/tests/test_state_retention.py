"""Tests for state retention: CycleTelemetrySummary and truncate_old_cycles.

Issue #191: add Cache hit % column and retention-truncate older cycles.
"""

import logging
from pathlib import Path
from typing import cast

import pytest

from code_generator.runner.types import TokenUsage
from code_generator.state import (
    CycleState,
    IssueState,
    State,
    load_state,
    save_state,
)
from code_generator.state_retention import CycleTelemetrySummary, truncate_old_cycles

# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _make_cycle(cycle_id: int, name: str | None = None) -> CycleState:
    return CycleState(
        id=cycle_id,
        name=name or f"Cycle {cycle_id}",
        milestone_number=cycle_id,
        milestone_title=f"Milestone {cycle_id}",
        status="completed",
        phase=7,
        issues=[IssueState(number=cycle_id, status="closed", agent="python-pro")],
        commit_sha=f"sha{cycle_id}",
        token_usage={
            "phase3": TokenUsage(input=100, output=50, cache_read=200, cache_write=30),
        },
        cache_telemetry={
            "input": 100,
            "output": 50,
            "cache_read": 200,
            "cache_write": 30,
            "cache_hit_pct": 45.5,
            "wall_seconds": 120.0,
        },
        started_at="2026-01-01T10:00:00Z",
        finished_at="2026-01-01T10:02:00Z",
    )


def _make_12_cycle_state() -> State:
    st = State(
        mode="multi-cycle",
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    st.cycles = [_make_cycle(i) for i in range(1, 13)]  # cycles 1–12
    return st


# ---------------------------------------------------------------------------
# CycleTelemetrySummary: structural contract
# ---------------------------------------------------------------------------


class TestCycleTelemetrySummary:
    def test_is_frozen_dataclass(self) -> None:
        """CycleTelemetrySummary is immutable (frozen dataclass)."""
        import dataclasses

        summary = CycleTelemetrySummary(
            cycle_name="Cycle 1",
            total_tokens=1000,
            cache_hit_pct=35.2,
            wall_seconds=120.0,
        )
        assert dataclasses.is_dataclass(summary)
        with pytest.raises((AttributeError, dataclasses.FrozenInstanceError)):
            summary.total_tokens = 999  # type: ignore[misc]

    def test_has_kind_field_equal_to_summary(self) -> None:
        """CycleTelemetrySummary has a 'kind' field equal to 'summary' for JSON discrimination."""
        summary = CycleTelemetrySummary(
            cycle_name="X", total_tokens=0, cache_hit_pct=0.0, wall_seconds=0.0
        )
        assert summary.kind == "summary"

    def test_kind_field_serialized_by_asdict(self) -> None:
        """dataclasses.asdict includes the 'kind' field so JSON round-trip works."""
        import dataclasses

        summary = CycleTelemetrySummary(
            cycle_name="X", total_tokens=42, cache_hit_pct=10.5, wall_seconds=60.0
        )
        d = dataclasses.asdict(summary)
        assert d["kind"] == "summary"
        assert d["cycle_name"] == "X"
        assert d["total_tokens"] == 42
        assert d["cache_hit_pct"] == 10.5
        assert d["wall_seconds"] == 60.0


# ---------------------------------------------------------------------------
# truncate_old_cycles: pure function contract
# ---------------------------------------------------------------------------


class TestTruncateOldCycles:
    def test_fewer_than_keep_returns_all_cycles_unchanged(self) -> None:
        """When len(cycles) <= keep, all CycleState entries are returned as-is."""
        cycles = [_make_cycle(i) for i in range(1, 6)]  # 5 cycles
        result = truncate_old_cycles(cycles, keep=10)

        assert len(result) == 5
        assert all(isinstance(c, CycleState) for c in result)

    def test_exactly_keep_returns_all_cycles_unchanged(self) -> None:
        """When len(cycles) == keep, no truncation occurs."""
        cycles = [_make_cycle(i) for i in range(1, 11)]  # exactly 10
        result = truncate_old_cycles(cycles, keep=10)

        assert len(result) == 10
        assert all(isinstance(c, CycleState) for c in result)

    def test_12_cycles_produces_2_summaries_and_10_full(self) -> None:
        """12 cycles with keep=10: first 2 become CycleTelemetrySummary, last 10 remain CycleState."""
        cycles = [_make_cycle(i) for i in range(1, 13)]
        result = truncate_old_cycles(cycles, keep=10)

        assert len(result) == 12
        assert isinstance(result[0], CycleTelemetrySummary)
        assert isinstance(result[1], CycleTelemetrySummary)
        for entry in result[2:]:
            assert isinstance(entry, CycleState)

    def test_summary_retains_cycle_name(self) -> None:
        """Truncated summary preserves the original cycle name."""
        cycles = [_make_cycle(i, name=f"My Cycle {i}") for i in range(1, 12)]
        result = truncate_old_cycles(cycles, keep=10)

        summary = result[0]
        assert isinstance(summary, CycleTelemetrySummary)
        assert summary.cycle_name == "My Cycle 1"

    def test_summary_retains_cache_hit_pct(self) -> None:
        """Truncated summary retains cache_hit_pct from cache_telemetry."""
        cycles = [_make_cycle(i) for i in range(1, 12)]
        result = truncate_old_cycles(cycles, keep=10)

        summary = result[0]
        assert isinstance(summary, CycleTelemetrySummary)
        assert summary.cache_hit_pct == pytest.approx(45.5)

    def test_summary_retains_wall_seconds(self) -> None:
        """Truncated summary retains wall_seconds from cache_telemetry."""
        cycles = [_make_cycle(i) for i in range(1, 12)]
        result = truncate_old_cycles(cycles, keep=10)

        summary = result[0]
        assert isinstance(summary, CycleTelemetrySummary)
        assert summary.wall_seconds == pytest.approx(120.0)

    def test_summary_total_tokens_sums_all_phases(self) -> None:
        """total_tokens in summary is the sum of input+output+cache_read+cache_write across phases."""
        cycle = _make_cycle(1)
        # token_usage = {"phase3": TokenUsage(input=100, output=50, cache_read=200, cache_write=30)}
        # total = 100 + 50 + 200 + 30 = 380
        result = truncate_old_cycles([cycle] + [_make_cycle(i) for i in range(2, 12)], keep=10)

        summary = result[0]
        assert isinstance(summary, CycleTelemetrySummary)
        assert summary.total_tokens == 380

    def test_order_preserved_oldest_summaries_first(self) -> None:
        """Oldest cycles become summaries first; newer cycles remain full."""
        cycles = [_make_cycle(i) for i in range(1, 13)]
        result = truncate_old_cycles(cycles, keep=10)

        assert isinstance(result[0], CycleTelemetrySummary)
        assert result[0].cycle_name == "Cycle 1"
        assert isinstance(result[1], CycleTelemetrySummary)
        assert result[1].cycle_name == "Cycle 2"

        full_cycle = result[2]
        assert isinstance(full_cycle, CycleState)
        assert full_cycle.name == "Cycle 3"

    def test_truncation_logs_info_per_cycle(self, caplog: pytest.LogCaptureFixture) -> None:
        """truncate_old_cycles logs INFO once per truncated cycle."""
        cycles = [_make_cycle(i, name=f"Cycle {i}") for i in range(1, 13)]

        with caplog.at_level(logging.INFO, logger="code_generator.state_retention"):
            truncate_old_cycles(cycles, keep=10)

        messages = [r.message for r in caplog.records]
        assert any("Cycle 1" in m for m in messages)
        assert any("Cycle 2" in m for m in messages)
        # Only 2 truncations, not 12
        info_records = [r for r in caplog.records if r.levelno == logging.INFO]
        assert len(info_records) == 2


# ---------------------------------------------------------------------------
# JSON round-trip: save_state + load_state with retention
# ---------------------------------------------------------------------------


class TestRetentionRoundTrip:
    def test_12_cycle_save_reload_first_2_are_summary_last_10_are_full(
        self, tmp_path: Path
    ) -> None:
        """12-cycle state → save → reload: first 2 are CycleTelemetrySummary, last 10 are CycleState."""
        path = tmp_path / ".code-generator" / "state.json"
        st = _make_12_cycle_state()

        save_state(path, st)
        loaded = load_state(path)

        assert len(loaded.cycles) == 12
        assert isinstance(loaded.cycles[0], CycleTelemetrySummary)
        assert isinstance(loaded.cycles[1], CycleTelemetrySummary)
        for entry in loaded.cycles[2:]:
            assert isinstance(entry, CycleState)

    def test_summary_round_trip_preserves_fields(self, tmp_path: Path) -> None:
        """After round-trip, CycleTelemetrySummary fields match the original cycle values."""
        path = tmp_path / ".code-generator" / "state.json"
        st = _make_12_cycle_state()
        # Cycle 1 will be truncated
        original_cycle_1 = cast("CycleState", st.cycles[0])

        save_state(path, st)
        loaded = load_state(path)

        summary = loaded.cycles[0]
        assert isinstance(summary, CycleTelemetrySummary)
        assert summary.cycle_name == original_cycle_1.name
        assert summary.cache_hit_pct == pytest.approx(
            original_cycle_1.cache_telemetry["cache_hit_pct"]
        )
        assert summary.wall_seconds == pytest.approx(
            original_cycle_1.cache_telemetry["wall_seconds"]
        )

    def test_second_save_does_not_re_truncate_existing_summaries(self, tmp_path: Path) -> None:
        """Saving again when state already has summaries keeps existing summaries intact."""
        path = tmp_path / ".code-generator" / "state.json"
        st = _make_12_cycle_state()

        save_state(path, st)
        loaded = load_state(path)

        # Save again without adding new cycles
        save_state(path, loaded)
        reloaded = load_state(path)

        assert len(reloaded.cycles) == 12
        # Still 2 summaries, 10 full
        summaries = [c for c in reloaded.cycles if isinstance(c, CycleTelemetrySummary)]
        full = [c for c in reloaded.cycles if isinstance(c, CycleState)]
        assert len(summaries) == 2
        assert len(full) == 10

    def test_state_without_telemetry_loads_without_error(self, tmp_path: Path) -> None:
        """Backward-compat: 0.2.x state.json without cache_telemetry loads cleanly."""
        path = tmp_path / ".code-generator" / "state.json"
        path.parent.mkdir(parents=True)

        import json

        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "Legacy Cycle",
                    "milestone_number": 1,
                    "milestone_title": "Milestone 1",
                    "status": "completed",
                    "phase": 7,
                    "issues": [],
                    "commit_sha": None,
                    # No cache_telemetry key — legacy format
                }
            ],
        }
        path.write_text(json.dumps(raw))

        loaded = load_state(path)
        assert len(loaded.cycles) == 1
        cycle = loaded.cycles[0]
        assert isinstance(cycle, CycleState)
        # cache_telemetry defaults to all-zeros
        assert cycle.cache_telemetry["cache_hit_pct"] == 0.0
