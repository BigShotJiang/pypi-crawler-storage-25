"""Tests for code_generator.orchestrator.phase1_plan."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase1_plan
from code_generator.runner.sdk_runner import RunResult

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "") -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state(tmp_path: Path) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    _state.save_state(state_dir / "state.json", st)
    return st


def _raw_issues(numbers: list[int]) -> list[dict]:
    return [
        {
            "number": n,
            "title": f"Issue {n}",
            "state": "open",
            "labels": [{"name": "agent:python-pro"}],
        }
        for n in numbers
    ]


def _make_cycle(
    *,
    milestone_title: str = "Cycle 1 — scope",
    milestone_number: int | None = 1,
) -> _state.CycleState:
    return _state.CycleState(
        id=1,
        name="Cycle 1",
        milestone_number=milestone_number,
        milestone_title=milestone_title,
        status="open",
        phase=0,
        issues=[],
        commit_sha=None,
        scope="test scope",
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPhase1Run:
    @pytest.mark.asyncio
    async def test_single_mode_populates_state_issues(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([1, 2, 3])),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(state.issues) == 3
        assert state.issues[0].number == 1
        assert state.issues[0].agent == "python-pro"

    @pytest.mark.asyncio
    async def test_multi_cycle_creates_milestone(self, tmp_path: Path) -> None:
        from code_generator.repo_info import RepoInfo  # noqa: PLC0415

        state = _make_state(tmp_path)
        state.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=None,
            milestone_title="Cycle 1 — DB",
            status="open",
            phase=0,
            issues=[],
            commit_sha=None,
            scope="db scope",
        )
        state.cycles = [cycle]

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "create_milestone", return_value=7) as mock_milestone,
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([4, 5])),
        ):
            await phase1_plan.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_milestone.assert_called_once_with(state.repo, "Cycle 1 — DB", "db scope")
        assert cycle.milestone_number == 7
        assert len(cycle.issues) == 2

    @pytest.mark.asyncio
    async def test_skips_milestone_creation_when_number_already_set(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=42,  # Already set.
            milestone_title="Cycle 1 — DB",
            status="open",
            phase=0,
            issues=[],
            commit_sha=None,
        )

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "create_milestone") as mock_milestone,
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([10])),
        ):
            await phase1_plan.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_milestone.assert_not_called()

    @pytest.mark.asyncio
    async def test_default_agent_when_no_agent_label(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        raw = [{"number": 9, "title": "T", "state": "open", "labels": [{"name": "priority:high"}]}]

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=raw),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert state.issues[0].agent == "python-pro"

    @pytest.mark.asyncio
    async def test_options_use_opus_model(self, tmp_path: Path) -> None:
        state = _make_state(tmp_path)
        captured_options = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([1])),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].model == "claude-opus-4-7"

    @pytest.mark.asyncio
    async def test_completed_cycles_in_prompt(self, tmp_path: Path) -> None:
        """Completed cycle names appear in the COMPLETED_CYCLES placeholder."""
        state = _make_state(tmp_path)
        state.cycles = [
            _state.CycleState(
                id=1,
                name="DB",
                milestone_number=1,
                milestone_title="Cycle 1",
                status="completed",
                phase=7,
                issues=[],
                commit_sha="abc",
            )
        ]
        captured_prompts = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([1])),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert "DB" in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_completed_cycles_included_in_prompt(self, tmp_path: Path) -> None:
        """Cycles with status='completed' (set by cycle_loop.py) appear in COMPLETED_CYCLES.

        This test demonstrates the bug in phase1_plan.py line 95 where the code
        filters by c.status == 'closed', but cycle_loop.py sets status to 'completed'.
        As a result, completed cycles are invisible to the planning prompt in
        subsequent cycles, risking duplicate or conflicting implementations.
        """
        state = _make_state(tmp_path)
        state.cycles = [
            _state.CycleState(
                id=1,
                name="DB Setup",
                milestone_number=1,
                milestone_title="Cycle 1",
                status="completed",  # Value actually set by cycle_loop.py line 347
                phase=7,
                issues=[],
                commit_sha="abc",
            )
        ]
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([1])),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # "DB Setup" must appear in the prompt — currently fails because
        # phase1_plan.py checks status == "closed", not "completed"
        assert "DB Setup" in captured_prompts[0]


# ---------------------------------------------------------------------------
# Direct unit tests for _build_issue_states
# ---------------------------------------------------------------------------


class TestBuildIssueStates:
    def test_sorts_by_number_and_extracts_agent(self) -> None:
        raw = [
            {
                "number": 5,
                "title": "E",
                "state": "open",
                "labels": [{"name": "agent:frontend-developer"}],
            },
            {"number": 2, "title": "B", "state": "open", "labels": [{"name": "agent:python-pro"}]},
            {
                "number": 8,
                "title": "H",
                "state": "open",
                "labels": [{"name": "agent:nestjs-expert"}],
            },
        ]

        result = phase1_plan._build_issue_states(raw)

        assert [s.number for s in result] == [2, 5, 8]
        assert result[0].agent == "python-pro"
        assert result[1].agent == "frontend-developer"
        assert result[2].agent == "nestjs-expert"
        assert all(s.status == "open" for s in result)

    def test_empty_input_returns_empty_list(self) -> None:
        result = phase1_plan._build_issue_states([])

        assert result == []

    def test_preserves_all_label_names_from_raw_issue(self) -> None:
        """IssueState.labels must contain all label names from the raw GitHub dict."""
        raw = [
            {
                "number": 3,
                "title": "feat: complex task",
                "state": "open",
                "labels": [
                    {"name": "agent:python-pro"},
                    {"name": "complexity:high"},
                    {"name": "priority:high"},
                ],
            }
        ]

        result = phase1_plan._build_issue_states(raw)

        assert result[0].labels == ["agent:python-pro", "complexity:high", "priority:high"]

    def test_complexity_high_label_preserved_for_effort_hint(self) -> None:
        """When a raw issue has complexity:high, the IssueState must carry that label
        so that _find_effort_hint() in phase3_4 can return effort='high'."""
        raw = [
            {
                "number": 7,
                "title": "feat: heavy",
                "state": "open",
                "labels": [{"name": "complexity:high"}],
            }
        ]

        result = phase1_plan._build_issue_states(raw)

        assert "complexity:high" in result[0].labels

    def test_issue_with_no_labels_gets_empty_list(self) -> None:
        """Issues without labels must produce IssueState with labels=[]."""
        raw = [{"number": 1, "title": "plain", "state": "open", "labels": []}]

        result = phase1_plan._build_issue_states(raw)

        assert result[0].labels == []

    def test_deduplicates_by_title_case_insensitive_keeps_lowest_number(self) -> None:
        """Duplicate titles (case-insensitive, stripped) → only lowest-numbered entry survives."""
        raw = [
            {"number": 5, "title": "feat: do thing", "state": "open", "labels": []},
            {"number": 2, "title": "FEAT: DO THING", "state": "open", "labels": []},
            {"number": 8, "title": "  feat: do thing  ", "state": "open", "labels": []},
            {"number": 3, "title": "feat: unique task", "state": "open", "labels": []},
        ]

        result = phase1_plan._build_issue_states(raw)

        assert len(result) == 2
        assert result[0].number == 2  # lowest-numbered for "feat: do thing"
        assert result[1].number == 3  # unique title

    def test_label_dict_missing_name_key_is_skipped(self) -> None:
        """Malformed label dicts (no 'name' key) must not raise; they produce empty string."""
        raw = [
            {
                "number": 2,
                "title": "odd",
                "state": "open",
                "labels": [{"id": 123}, {"name": "priority:high"}],
            }
        ]

        result = phase1_plan._build_issue_states(raw)

        # The malformed dict yields "" which we filter; "priority:high" must survive
        assert "priority:high" in result[0].labels


# ---------------------------------------------------------------------------
# Phase1NoIssuesError raised when planning produces no issues
# ---------------------------------------------------------------------------


class TestPhase1NoIssuesError:
    @pytest.mark.asyncio
    async def test_raises_when_list_issues_returns_empty(self, tmp_path: Path) -> None:
        """Three consecutive empty listings → Phase1NoIssuesError with model name."""
        state = _make_state(tmp_path)
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=[]),
        ):
            with pytest.raises(phase1_plan.Phase1NoIssuesError, match="3 attempts"):
                await phase1_plan.run(
                    state,
                    None,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=logging.getLogger("test"),
                )

        assert call_count == phase1_plan._PHASE1_MAX_ATTEMPTS

    @pytest.mark.asyncio
    async def test_retry_succeeds_after_first_empty_attempt(self, tmp_path: Path) -> None:
        """If the first attempt created 0 issues but the second populates them, no raise."""
        state = _make_state(tmp_path)
        call_count = 0
        # First call → empty list; second call → real issues.
        listings = [[], _raw_issues([1, 2])]

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _make_run_result()

        def fake_list_issues(*_a, **_kw):
            return listings[min(call_count - 1, len(listings) - 1)]

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", side_effect=fake_list_issues),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 2
        assert len(state.issues) == 2

    @pytest.mark.asyncio
    async def test_retry_prompt_includes_strict_nudge(self, tmp_path: Path) -> None:
        """Second attempt's prompt must be prefixed with the stricter nudge."""
        state = _make_state(tmp_path)
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=[]),
        ):
            with pytest.raises(phase1_plan.Phase1NoIssuesError):
                await phase1_plan.run(
                    state,
                    None,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=logging.getLogger("test"),
                )

        assert len(captured_prompts) == phase1_plan._PHASE1_MAX_ATTEMPTS
        # First prompt is the plain Phase 1 prompt.
        assert (
            "Your previous attempt finished without creating any GitHub issues"
            not in (captured_prompts[0])
        )
        # Subsequent prompts carry the stricter nudge prefix.
        for retry_prompt in captured_prompts[1:]:
            assert retry_prompt.startswith(
                "Your previous attempt finished without creating any GitHub issues"
            )

    @pytest.mark.asyncio
    async def test_error_message_names_effective_model(self, tmp_path: Path) -> None:
        """Ollama path: final error text must reference the operator-supplied tag."""
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=[]),
        ):
            with pytest.raises(phase1_plan.Phase1NoIssuesError, match="glm-5.1:cloud"):
                await phase1_plan.run(
                    state,
                    None,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=logging.getLogger("test"),
                    effective_model="glm-5.1:cloud",
                )


# ---------------------------------------------------------------------------
# Phase 1 idempotency — AC from issue #134
# ---------------------------------------------------------------------------


class TestPhase1Idempotency:
    """Tests for Phase 1 idempotency: skip pre-existing issues, dedup defense."""

    @pytest.mark.asyncio
    async def test_pre_existing_titles_injected_into_prompt(self, tmp_path: Path) -> None:
        """Pre-existing milestone issues appear in the planning prompt so the model skips them."""
        from code_generator.repo_info import RepoInfo  # noqa: PLC0415

        state = _make_state(tmp_path)
        state.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _make_cycle()
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        pre_existing = [
            {"number": 1, "title": "feat: existing issue", "state": "open", "labels": []}
        ]

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", side_effect=[pre_existing, pre_existing]),
        ):
            await phase1_plan.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert "feat: existing issue" in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_zero_pre_existing_issues_preserves_baseline(self, tmp_path: Path) -> None:
        """When no pre-existing issues exist, all issues created in session are returned."""
        state = _make_state(tmp_path)
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([1, 2, 3])),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(state.issues) == 3

    @pytest.mark.asyncio
    async def test_all_issues_pre_existing_populates_state_without_error(
        self, tmp_path: Path
    ) -> None:
        """When ALL issues pre-exist, no error is raised and state/cycle.issues is populated."""
        state = _make_state(tmp_path)
        cycle = _make_cycle()
        all_issues = _raw_issues([1, 2, 3])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=all_issues),
        ):
            # Must NOT raise Phase1NoIssuesError
            await phase1_plan.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(cycle.issues) == 3
        assert [i.number for i in cycle.issues] == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_delta_resume_skips_pre_existing_and_captures_all_after_session(
        self, tmp_path: Path
    ) -> None:
        """Mid-Phase-1 failure scenario: 3 pre-existing issues in prompt, 6 total after session."""
        from code_generator.repo_info import RepoInfo  # noqa: PLC0415

        state = _make_state(tmp_path)
        state.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _make_cycle()
        captured_prompts: list[str] = []

        pre_existing = _raw_issues([1, 2, 3])
        all_issues = _raw_issues([1, 2, 3, 4, 5, 6])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", side_effect=[pre_existing, all_issues]),
        ):
            await phase1_plan.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # Pre-existing titles must appear in the prompt so the model skips them.
        assert "Issue 1" in captured_prompts[0]
        assert "Issue 2" in captured_prompts[0]
        assert "Issue 3" in captured_prompts[0]
        # Post-session: all 6 issues captured with no duplicates.
        assert len(cycle.issues) == 6


# ---------------------------------------------------------------------------
# Phase 1 milestone cleanup on failure — AC from issue #135
# ---------------------------------------------------------------------------


class TestPhase1MilestoneCleanup:
    """Milestone is deleted when Phase 1 raises after creating it."""

    @pytest.mark.asyncio
    async def test_milestone_deleted_when_phase1_raises_after_creation(
        self, tmp_path: Path
    ) -> None:
        """Phase 1 raises after milestone creation → gh.delete_milestone() is called."""
        from code_generator.repo_info import RepoInfo  # noqa: PLC0415

        state = _make_state(tmp_path)
        state.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _state.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=None,  # Not yet created.
            milestone_title="Cycle 1 — scope",
            status="open",
            phase=0,
            issues=[],
            commit_sha=None,
            scope="test scope",
        )

        async def failing_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            raise RuntimeError("planning session failed")

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=failing_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=[]),
            patch.object(phase1_plan.gh, "create_milestone", return_value=42),
            patch.object(phase1_plan.gh, "delete_milestone") as mock_delete,
        ):
            with pytest.raises(RuntimeError, match="planning session failed"):
                await phase1_plan.run(
                    state,
                    cycle,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=logging.getLogger("test"),
                )

        mock_delete.assert_called_once_with(state.repo, 42)

    @pytest.mark.asyncio
    async def test_original_exception_propagates_when_cleanup_also_fails(
        self, tmp_path: Path
    ) -> None:
        """Phase 1 raises AND milestone cleanup fails → WARNING logged, original exception propagates."""
        from code_generator.repo_info import RepoInfo  # noqa: PLC0415

        state = _make_state(tmp_path)
        state.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _state.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=None,
            milestone_title="Cycle 1 — scope",
            status="open",
            phase=0,
            issues=[],
            commit_sha=None,
            scope="test scope",
        )

        async def failing_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            raise RuntimeError("original error")

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=failing_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=[]),
            patch.object(phase1_plan.gh, "create_milestone", return_value=7),
            patch.object(
                phase1_plan.gh, "delete_milestone", side_effect=Exception("gh api failure")
            ),
        ):
            test_logger = logging.getLogger("test_cleanup_fail")
            with (
                patch.object(test_logger, "warning") as mock_warning,
                pytest.raises(RuntimeError, match="original error"),
            ):
                await phase1_plan.run(
                    state,
                    cycle,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=test_logger,
                )

        mock_warning.assert_called_once()

    @pytest.mark.asyncio
    async def test_no_cleanup_when_phase1_succeeds(self, tmp_path: Path) -> None:
        """Phase 1 succeeds normally → delete_milestone is never called."""
        from code_generator.repo_info import RepoInfo  # noqa: PLC0415

        state = _make_state(tmp_path)
        state.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _state.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=None,
            milestone_title="Cycle 1 — scope",
            status="open",
            phase=0,
            issues=[],
            commit_sha=None,
            scope="test scope",
        )

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "create_milestone", return_value=3),
            patch.object(phase1_plan.gh, "delete_milestone") as mock_delete,
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([1, 2])),
        ):
            await phase1_plan.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_delete.assert_not_called()


# ---------------------------------------------------------------------------
# Issue #246 — phase 1 routes cache_write into the BP3 1h bucket
# ---------------------------------------------------------------------------


class TestPhase1CacheWriteSplit:
    @pytest.mark.asyncio
    async def test_phase1_routes_cache_write_into_one_hour_bucket(self, tmp_path: Path) -> None:
        """Phase 1 (one-shot, BP3=1h) populates cache_write_1h on success."""
        from code_generator.runner.types import TokenUsage

        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return RunResult(
                text="",
                session_id=None,
                usage=TokenUsage(input=10, output=5, cache_read=2, cache_write=42),
            )

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([1])),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        persisted = state.token_usage["phase1"]
        assert persisted.cache_write == 42
        assert persisted.cache_write_1h == 42
        assert persisted.cache_write_5m == 0
        assert persisted.cache_write_5m + persisted.cache_write_1h == persisted.cache_write


# ---------------------------------------------------------------------------
# Issue #249 — Phase 1 seeds the feature checklist
# ---------------------------------------------------------------------------


class TestPhase1ChecklistSeeding:
    @pytest.mark.asyncio
    async def test_phase1_seeds_checklist_when_requirements_hash_set(self, tmp_path: Path) -> None:
        import json

        state = _make_state(tmp_path)
        state.requirements_hash = "abcd1234"

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([10, 20])),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        checklist_path = tmp_path / ".code-generator" / "checklists" / "abcd1234.json"
        assert checklist_path.exists()
        entries = json.loads(checklist_path.read_text())
        assert len(entries) == 2
        assert all(not e["tests_passed"] for e in entries)
        assert all(not e["committed"] for e in entries)
        assert all(not e["feature_done"] for e in entries)
        assert {e["issue_number"] for e in entries} == {10, 20}

    @pytest.mark.asyncio
    async def test_phase1_skips_checklist_when_requirements_hash_missing(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        state = _make_state(tmp_path)
        state.requirements_hash = None

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([1])),
            caplog.at_level(logging.WARNING),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        checklists_dir = tmp_path / ".code-generator" / "checklists"
        assert not checklists_dir.exists()
        assert any("requirements_hash" in rec.getMessage().lower() for rec in caplog.records)


# ---------------------------------------------------------------------------
# _load_specialized_prompt — issue #232
# ---------------------------------------------------------------------------


def _write_cycle_prompt(tmp_path: Path, requirements_hash: str, cycle_id: int, body: str) -> Path:
    """Materialise a per-cycle briefing under ``cycles_prompts/<hash>/``."""
    folder = tmp_path / ".code-generator" / "cycles_prompts" / requirements_hash
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"cycle_{cycle_id}.md"
    path.write_text(body, encoding="utf-8")
    return path


class TestLoadSpecializedPrompt:
    """Issue #232: multi-cycle Phase 1 must NOT silently fall back to inline requirements."""

    def test_single_cycle_returns_inline_requirements(self, tmp_path: Path) -> None:
        """cycle=None → inline-requirements fallback preserved."""
        state = _make_state(tmp_path)
        state.mode = "single"  # type: ignore[assignment]
        requirements = tmp_path / ".code-generator" / "requirements.md"
        requirements.write_text("# Project\nbody", encoding="utf-8")

        result = phase1_plan._load_specialized_prompt(tmp_path, state, None)

        assert result.startswith("## Requirements")
        assert "# Project" in result

    def test_single_cycle_missing_requirements_file_returns_path_marker(
        self, tmp_path: Path
    ) -> None:
        """Single-cycle + missing requirements.md → path-marker fallback (unit-test parity)."""
        state = _make_state(tmp_path)
        state.mode = "single"  # type: ignore[assignment]

        result = phase1_plan._load_specialized_prompt(tmp_path, state, None)

        assert "Requirements path:" in result

    def test_multi_cycle_missing_hash_falls_back(self, tmp_path: Path) -> None:
        """Multi-cycle + requirements_hash=None → fallback to raw requirements with warning."""
        state = _make_state(tmp_path)
        state.mode = "multi-cycle"  # type: ignore[assignment]
        state.requirements_hash = None
        cycle = _make_cycle()
        logger = logging.getLogger("test")

        result = phase1_plan._load_specialized_prompt(tmp_path, state, cycle, logger=logger)

        assert "Requirements path:" in result

    def test_multi_cycle_missing_file_falls_back(self, tmp_path: Path) -> None:
        """Multi-cycle + hash set + file missing → fallback to raw requirements with warning."""
        state = _make_state(tmp_path)
        state.mode = "multi-cycle"  # type: ignore[assignment]
        state.requirements_hash = "deadbeef"
        cycle = _make_cycle()
        logger = logging.getLogger("test")

        result = phase1_plan._load_specialized_prompt(tmp_path, state, cycle, logger=logger)

        assert "Requirements path:" in result

    def test_multi_cycle_happy_path_returns_file_content(self, tmp_path: Path) -> None:
        """Multi-cycle + hash + file present → returns file body verbatim."""
        state = _make_state(tmp_path)
        state.mode = "multi-cycle"  # type: ignore[assignment]
        state.requirements_hash = "abc123"
        cycle = _make_cycle()
        body = "# Cycle 1 briefing\n\n## Vision\nlocked"
        _write_cycle_prompt(tmp_path, "abc123", 1, body)

        result = phase1_plan._load_specialized_prompt(tmp_path, state, cycle)

        assert result == body

    def test_multi_cycle_falls_back_to_raw_requirements(self, tmp_path: Path) -> None:
        """Multi-cycle on miss → falls back to raw requirements.md content."""
        state = _make_state(tmp_path)
        state.mode = "multi-cycle"  # type: ignore[assignment]
        state.requirements_hash = "feedbeef"
        cycle = _make_cycle()
        (tmp_path / ".code-generator" / "requirements.md").write_text(
            "# Cycle scope here", encoding="utf-8"
        )

        result = phase1_plan._load_specialized_prompt(tmp_path, state, cycle)

        assert "Cycle scope here" in result
