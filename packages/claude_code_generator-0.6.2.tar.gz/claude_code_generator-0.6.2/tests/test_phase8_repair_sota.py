"""Phase 8 SOTA repair-loop scenario tests (#329).

Named coverage of briefing criterion E that is not already exercised by
``test_phase8_repair_loop.py``. Reuses the shared stub harness from that file
so the contracts (transient classification, permanent → patch → push,
guardrail revert, budget exhaustion → remediation issue) stay locked at the
loop boundary, plus pure-unit coverage of conventional-commit → semver →
CHANGELOG consistency and surface-scanner traceability.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from code_generator.changelog import format_section
from code_generator.orchestrator import phase8_repair_loop as repair_loop
from code_generator.orchestrator.phase8_local_verify import LocalVerifyResult
from code_generator.semver import CommitClass, compute_bump, next_version
from code_generator.surface_scanner import scan_surface
from tests.test_phase8_repair_loop import _install_stubs, _run


def _failing_run(database_id: int = 1, created: str = "2026-05-16T10:00:00Z") -> dict:
    return {
        "runs": [
            {
                "databaseId": database_id,
                "status": "completed",
                "conclusion": "failure",
                "workflowName": "ci",
                "createdAt": created,
            }
        ]
    }


def _success_run(database_id: int = 2, created: str = "2026-05-16T10:05:00Z") -> dict:
    return {
        "runs": [
            {
                "databaseId": database_id,
                "status": "completed",
                "conclusion": "success",
                "workflowName": "ci",
                "createdAt": created,
            }
        ]
    }


# ---------------------------------------------------------------------------
# Transient / permanent classification
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestTransientClassification:
    async def test_transient_classified_transient_repoll_no_repair(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``ECONNRESET`` log → classified transient → no repair invocation."""
        rec = _install_stubs(
            monkeypatch,
            run_sequence=[_failing_run(1), _success_run(2)],
            log_text="ECONNRESET: connection reset by peer",
        )

        outcome = await _run(tmp_path)

        assert outcome == "green"
        assert rec.repair_invocations == 0


@pytest.mark.asyncio
class TestPermanentClassification:
    async def test_permanent_classified_permanent_invokes_repair_then_push(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``SyntaxError`` log → permanent → repair → push → green on re-poll."""
        target = tmp_path / "src.py"
        target.write_text("buggy\n", encoding="utf-8")
        patch_json = '[{"file": "src.py", "line": 1, "old": "buggy", "new": "fixed"}]'

        rec = _install_stubs(
            monkeypatch,
            run_sequence=[_failing_run(1), _success_run(2)],
            log_text="SyntaxError: invalid syntax at line 42",
            repair_text=patch_json,
        )

        outcome = await _run(tmp_path)

        assert outcome == "green"
        assert rec.repair_invocations == 1
        assert rec.pushes == ["main"]
        assert target.read_text(encoding="utf-8") == "fixed\n"


# ---------------------------------------------------------------------------
# Local red tree blocks push (anti-gaming pre-push gate)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestLocalRedTreeBlocksPush:
    async def test_local_red_tree_blocks_push(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``LocalVerifyResult(passed=False)`` reverts patches and skips push."""
        target = tmp_path / "src.py"
        target.write_text("orig\n", encoding="utf-8")

        rec = _install_stubs(
            monkeypatch,
            run_sequence=[_failing_run(1)],
            log_text="FAILED tests/test_x.py::test_y",
            repair_text='[{"file": "src.py", "line": 1, "old": "orig", "new": "patched"}]',
            verify_result=LocalVerifyResult(
                passed=False,
                stderr_excerpt="local tests red",
                blocked_by_guardrail=False,
                guardrail_violations=[],
            ),
        )

        outcome = await _run(tmp_path, config=repair_loop.RepairLoopConfig(max_repair_attempts=1))

        assert outcome == "exhausted"
        assert rec.pushes == []
        assert rec.commits == []
        assert target.read_text(encoding="utf-8") == "orig\n"


# ---------------------------------------------------------------------------
# Anti-gaming guardrail
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestAntiGamingGuardrail:
    async def test_anti_gaming_guardrail_blocks_push(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``blocked_by_guardrail=True`` (``continue-on-error: true`` patch) reverts + no push."""
        target = tmp_path / ".github/workflows/ci.yml"
        target.parent.mkdir(parents=True)
        target.write_text("steps:\n  - run: pytest\n", encoding="utf-8")

        rec = _install_stubs(
            monkeypatch,
            run_sequence=[_failing_run(1)],
            log_text="FAILED tests/test_x.py::test_y",
            repair_text=(
                '[{"file": ".github/workflows/ci.yml", "line": 1, '
                '"old": "- run: pytest", "new": "- run: pytest\\n        continue-on-error: true"}]'
            ),
            verify_result=LocalVerifyResult(
                passed=False,
                stderr_excerpt="",
                blocked_by_guardrail=True,
                guardrail_violations=["continue-on-error"],
            ),
        )

        outcome = await _run(tmp_path, config=repair_loop.RepairLoopConfig(max_repair_attempts=1))

        assert outcome == "exhausted"
        assert rec.pushes == []
        assert rec.commits == []


# ---------------------------------------------------------------------------
# Budget exhaustion → remediation issue
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestBudgetExhaustionOpensRemediation:
    async def test_budget_exhausted_opens_remediation_issue(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``max_repair_attempts=2`` exhausted → outcome ``exhausted`` + one remediation issue."""
        rec = _install_stubs(
            monkeypatch,
            run_sequence=[_failing_run(1)] * 6,
            log_text="FAILED tests/test_x.py::test_y",
            repair_text="[]",
        )

        outcome = await _run(tmp_path, config=repair_loop.RepairLoopConfig(max_repair_attempts=2))

        assert outcome == "exhausted"
        assert len(rec.issues_created) == 1
        issue = rec.issues_created[0]
        assert "needs-manual-review" in issue["labels"]
        assert "area:ci" in issue["labels"]


# ---------------------------------------------------------------------------
# Conventional-commit → semver → CHANGELOG consistency (pure unit)
# ---------------------------------------------------------------------------


class TestConventionalCommitSemverChangelogConsistency:
    def test_conventional_commit_semver_changelog_consistency(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Same ``CommitClass`` list drives ``compute_bump``, ``next_version`` and
        ``format_section`` to mutually consistent outputs (breaking → major)."""
        from datetime import date

        from code_generator import changelog as cl_mod

        monkeypatch.setattr(cl_mod, "_today", lambda: date(2026, 5, 16))

        commits = [
            CommitClass(sha="aaa1111", subject="fix: patch", type="fix", breaking=False),
            CommitClass(sha="bbb2222", subject="feat: new", type="feat", breaking=False),
            CommitClass(
                sha="ccc3333",
                subject="feat!: drop legacy",
                type="feat",
                breaking=True,
            ),
        ]

        bump = compute_bump(commits)
        new_version = next_version("v1.2.3", bump)
        section = format_section(new_version, commits)

        assert bump == "major"
        assert new_version == "2.0.0"
        assert f"## [v{new_version}] — 2026-05-16" in section
        assert "### Breaking Changes" in section
        # Every commit subject appears in at least one section.
        for c in commits:
            assert c.subject in section


# ---------------------------------------------------------------------------
# Surface scanner traceability
# ---------------------------------------------------------------------------


class TestSurfaceScannerReturnsRealSurface:
    def test_surface_scanner_returns_real_surface_not_invented(self, tmp_path: Path) -> None:
        """Mini project with ``@app.get('/items')`` surfaces a real ``ApiRoute``."""
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n\n'
            '[tool.setuptools.packages.find]\nwhere = ["src"]\n',
            encoding="utf-8",
        )
        pkg = tmp_path / "src" / "api"
        pkg.mkdir(parents=True)
        (pkg / "__init__.py").write_text("", encoding="utf-8")
        (pkg / "main.py").write_text(
            "from fastapi import FastAPI\n"
            "app = FastAPI()\n"
            "\n"
            '@app.get("/items")\n'
            "def list_items():\n"
            "    return []\n",
            encoding="utf-8",
        )

        report = scan_surface(tmp_path)

        matching = [
            r
            for r in report.api_routes
            if r.method == "GET" and r.path == "/items" and r.handler == "list_items"
        ]
        assert len(matching) == 1
        # Handler is sourced from the actual file — not invented prose.
        assert matching[0].source_path.name == "main.py"
