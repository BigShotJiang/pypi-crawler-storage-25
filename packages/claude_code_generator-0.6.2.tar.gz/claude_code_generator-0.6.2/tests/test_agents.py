"""Tests for code_generator.agents — tech-stack detector and §7 matrix."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from code_generator.agents import AgentSelection, detect

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Fixtures — one per matrix row
# ---------------------------------------------------------------------------


@pytest.fixture
def angular_fastapi_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nAngular + FastAPI + PostgreSQL\n\n## Other\n\nstuff",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def angular_only_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nAngular 17, Tailwind CSS\n\n## Other\n\nstuff",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def angular_ng_space_req(tmp_path: Path) -> Path:
    """Angular detected via ' ng ' keyword."""
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nBuilt with ng router and signals\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def fastapi_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nFastAPI + SQLAlchemy + Postgres\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def python_api_req(tmp_path: Path) -> Path:
    """FastAPI detected via 'python api' keyword."""
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nPython API with uvicorn\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def baml_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nBAML + Python (LLM orchestration)\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def llm_function_req(tmp_path: Path) -> Path:
    """BAML detected via 'llm function' keyword."""
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nLLM function pipeline with structured output\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def typer_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nTyper CLI + Python 3.11\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def click_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nClick framework for Python\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def python_cli_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nPython CLI tool\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def generic_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\n## Tech Stack\n\nSomething totally unknown\n\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture
def missing_req(tmp_path: Path) -> Path:
    return tmp_path / "requirements.md"  # Does NOT exist.


@pytest.fixture
def no_tech_stack_req(tmp_path: Path) -> Path:
    p = tmp_path / "requirements.md"
    p.write_text(
        "# My App\n\nNo tech stack section here.\n\n",
        encoding="utf-8",
    )
    return p


# ---------------------------------------------------------------------------
# AgentSelection dataclass
# ---------------------------------------------------------------------------


class TestAgentSelection:
    def test_is_frozen(self) -> None:
        sel = AgentSelection(primary=("python-pro",), support=(), skills=("solid-principles",))
        from dataclasses import FrozenInstanceError  # type: ignore[attr-defined]

        with pytest.raises(FrozenInstanceError):
            sel.primary = ("other",)  # type: ignore[misc]

    def test_equality(self) -> None:
        a = AgentSelection(primary=("x",), support=("y",), skills=("z",))
        b = AgentSelection(primary=("x",), support=("y",), skills=("z",))
        assert a == b


# ---------------------------------------------------------------------------
# detect — full-stack combos (checked first)
# ---------------------------------------------------------------------------


class TestDetectAngularFastAPI:
    def test_primary_agents(self, angular_fastapi_req: Path) -> None:
        sel = detect(angular_fastapi_req)
        assert "frontend-developer" in sel.primary
        assert "python-pro" in sel.primary
        assert "fastapi-expert-agent" in sel.primary

    def test_support_agents(self, angular_fastapi_req: Path) -> None:
        sel = detect(angular_fastapi_req)
        assert "ui-ux-designer" in sel.support
        assert "supabase-connection-expert" in sel.support

    def test_skills(self, angular_fastapi_req: Path) -> None:
        sel = detect(angular_fastapi_req)
        assert "solid-principles" in sel.skills
        assert "python-expert" in sel.skills


# ---------------------------------------------------------------------------
# detect — single-stack
# ---------------------------------------------------------------------------


class TestDetectAngularOnly:
    def test_primary(self, angular_only_req: Path) -> None:
        sel = detect(angular_only_req)
        assert "frontend-developer" in sel.primary
        assert "python-pro" not in sel.primary

    def test_ng_space_keyword(self, angular_ng_space_req: Path) -> None:
        sel = detect(angular_ng_space_req)
        assert "frontend-developer" in sel.primary


class TestDetectFastAPI:
    def test_primary(self, fastapi_req: Path) -> None:
        sel = detect(fastapi_req)
        assert "python-pro" in sel.primary
        assert "fastapi-expert-agent" in sel.primary

    def test_python_api_keyword(self, python_api_req: Path) -> None:
        sel = detect(python_api_req)
        assert "fastapi-expert-agent" in sel.primary

    def test_skills(self, fastapi_req: Path) -> None:
        sel = detect(fastapi_req)
        assert "python-expert" in sel.skills


class TestDetectBAML:
    def test_baml_keyword(self, baml_req: Path) -> None:
        sel = detect(baml_req)
        assert "baml-expert-agent" in sel.primary

    def test_llm_function_keyword(self, llm_function_req: Path) -> None:
        sel = detect(llm_function_req)
        assert "baml-expert-agent" in sel.primary

    def test_skills(self, baml_req: Path) -> None:
        sel = detect(baml_req)
        assert "solid-principles" in sel.skills


class TestDetectPythonCLI:
    def test_typer_keyword(self, typer_req: Path) -> None:
        sel = detect(typer_req)
        assert "python-pro" in sel.primary

    def test_click_keyword(self, click_req: Path) -> None:
        sel = detect(click_req)
        assert "python-pro" in sel.primary

    def test_python_cli_keyword(self, python_cli_req: Path) -> None:
        sel = detect(python_cli_req)
        assert "python-pro" in sel.primary

    def test_skills(self, typer_req: Path) -> None:
        sel = detect(typer_req)
        assert "solid-principles" in sel.skills
        assert "python-expert" in sel.skills


# ---------------------------------------------------------------------------
# detect — fallback
# ---------------------------------------------------------------------------


class TestDetectFallback:
    def test_missing_file(self, missing_req: Path) -> None:
        sel = detect(missing_req)
        assert sel.primary == ("python-pro",)
        assert sel.skills == ("solid-principles",)

    def test_no_tech_stack_section(self, no_tech_stack_req: Path) -> None:
        sel = detect(no_tech_stack_req)
        assert sel.primary == ("python-pro",)

    def test_unknown_keywords(self, generic_req: Path) -> None:
        sel = detect(generic_req)
        assert sel.primary == ("python-pro",)
        assert sel.skills == ("solid-principles",)


# ---------------------------------------------------------------------------
# Ordering: full-stack combos beat single-stack
# ---------------------------------------------------------------------------


class TestDetectOrdering:
    def test_angular_fastapi_beats_angular_only(self, tmp_path: Path) -> None:
        """When both angular and fastapi are present, the full-stack combo wins."""
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nAngular + FastAPI\n", encoding="utf-8")
        sel = detect(p)
        assert "fastapi-expert-agent" in sel.primary  # Not angular-only


# ---------------------------------------------------------------------------
# Extra-skill detection — additive layer on top of base selection
# ---------------------------------------------------------------------------


class TestExtraSkillDetection:
    def test_supabase_keyword_appends_both_skills(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nFastAPI + Supabase\n", encoding="utf-8")
        sel = detect(p)
        assert "supabase" in sel.skills
        assert "supabase-postgres-best-practices" in sel.skills

    def test_skfolio_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nskfolio for portfolio optimization\n", encoding="utf-8")
        sel = detect(p)
        assert "skfolio" in sel.skills

    def test_portfolio_optim_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nportfolio optim framework\n", encoding="utf-8")
        sel = detect(p)
        assert "skfolio" in sel.skills

    def test_efficient_frontier_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nefficient frontier model\n", encoding="utf-8")
        sel = detect(p)
        assert "skfolio" in sel.skills

    def test_mean_variance_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nmean-variance optimization\n", encoding="utf-8")
        sel = detect(p)
        assert "skfolio" in sel.skills

    def test_risk_parity_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nrisk parity strategy\n", encoding="utf-8")
        sel = detect(p)
        assert "skfolio" in sel.skills

    def test_yfinance_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nyfinance data source\n", encoding="utf-8")
        sel = detect(p)
        assert "yfinance" in sel.skills

    def test_yahoo_finance_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nyahoo finance API\n", encoding="utf-8")
        sel = detect(p)
        assert "yfinance" in sel.skills

    def test_ohlcv_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nohlcv data pipeline\n", encoding="utf-8")
        sel = detect(p)
        assert "yfinance" in sel.skills

    def test_stock_data_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nstock data feed\n", encoding="utf-8")
        sel = detect(p)
        assert "yfinance" in sel.skills

    def test_ticker_data_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nticker data ingestion\n", encoding="utf-8")
        sel = detect(p)
        assert "yfinance" in sel.skills

    def test_xlsx_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nxlsx export\n", encoding="utf-8")
        sel = detect(p)
        assert "xlsx" in sel.skills

    def test_dotxlsx_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nexport to .xlsx format\n", encoding="utf-8")
        sel = detect(p)
        assert "xlsx" in sel.skills

    def test_excel_space_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nread excel files\n", encoding="utf-8")
        sel = detect(p)
        assert "xlsx" in sel.skills

    def test_spreadsheet_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nspreadsheet management\n", encoding="utf-8")
        sel = detect(p)
        assert "xlsx" in sel.skills

    def test_docx_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\ndocx generation\n", encoding="utf-8")
        sel = detect(p)
        assert "docx" in sel.skills

    def test_dotdocx_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\noutput .docx files\n", encoding="utf-8")
        sel = detect(p)
        assert "docx" in sel.skills

    def test_word_document_keyword(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nword document export\n", encoding="utf-8")
        sel = detect(p)
        assert "docx" in sel.skills

    def test_angular_fastapi_supabase_skills(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nAngular + FastAPI + Supabase\n", encoding="utf-8")
        sel = detect(p)
        assert sel.skills == (
            "solid-principles",
            "python-expert",
            "supabase",
            "supabase-postgres-best-practices",
        )

    def test_no_duplicate_skills(self, tmp_path: Path) -> None:
        p = tmp_path / "requirements.md"
        p.write_text("## Tech Stack\n\nTyper CLI with skfolio\n", encoding="utf-8")
        sel = detect(p)
        assert sel.skills.count("solid-principles") == 1
        assert "skfolio" in sel.skills

    def test_missing_file_unchanged(self, missing_req: Path) -> None:
        sel = detect(missing_req)
        assert sel.skills == ("solid-principles",)
        assert "supabase" not in sel.skills
