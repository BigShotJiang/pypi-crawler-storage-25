"""Tests for code_generator.orchestrator.agent_spec — Issue #279.

Declarative AgentSpec artifact: frozen dataclasses, atomic JSON persistence,
deterministic round-trip serialization, requirements-hash replay determinism.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import os
from pathlib import Path

import pytest

from code_generator.orchestrator.agent_spec import (
    AgentSpec,
    TierConfig,
    build_agent_spec,
    load_agent_spec,
    persist_agent_spec,
)

# ---------------------------------------------------------------------------
# Frozen dataclass guarantees
# ---------------------------------------------------------------------------


def test_tier_config_is_frozen_dataclass() -> None:
    tier = TierConfig(tier_id="T0", enabled=True)
    assert dataclasses.is_dataclass(tier)
    with pytest.raises(dataclasses.FrozenInstanceError):
        tier.enabled = False  # type: ignore[misc]


def test_agent_spec_is_frozen_dataclass_with_tuple_tiers() -> None:
    spec = AgentSpec(
        requirements_hash="abc",
        tiers=(TierConfig(tier_id="T0", enabled=True),),
        base_url="http://127.0.0.1:8000",
    )
    assert dataclasses.is_dataclass(spec)
    assert isinstance(spec.tiers, tuple)
    with pytest.raises(dataclasses.FrozenInstanceError):
        spec.requirements_hash = "xyz"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Round-trip and atomic persistence
# ---------------------------------------------------------------------------


def test_when_persist_then_load_round_trips_byte_identical_json(tmp_path: Path) -> None:
    spec = AgentSpec(
        requirements_hash=hashlib.sha256(b"hello").hexdigest(),
        tiers=(
            TierConfig(tier_id="T0", enabled=True),
            TierConfig(tier_id="T1", enabled=True, port=8000),
            TierConfig(tier_id="T2", enabled=True),
            TierConfig(tier_id="T3", enabled=False, skip_reason="no frontend"),
            TierConfig(tier_id="T4", enabled=False, skip_reason="no docker"),
        ),
        base_url="http://127.0.0.1:8000",
    )
    spec_path = persist_agent_spec(spec, tmp_path)

    loaded = load_agent_spec(tmp_path)

    assert loaded == spec
    assert spec_path == tmp_path / "phase6_5_spec.json"
    raw_first = spec_path.read_bytes()
    persist_agent_spec(loaded, tmp_path)
    raw_second = spec_path.read_bytes()
    assert raw_first == raw_second


def test_when_persist_then_tmp_file_is_replaced_atomically(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    spec = AgentSpec(
        requirements_hash="deadbeef",
        tiers=(TierConfig(tier_id="T0", enabled=True),),
        base_url="http://127.0.0.1:8000",
    )

    captured: dict[str, tuple[str, str]] = {}
    original_replace = os.replace

    def spy_replace(src, dst) -> None:  # type: ignore[no-untyped-def]
        captured["call"] = (str(src), str(dst))
        original_replace(src, dst)

    monkeypatch.setattr(os, "replace", spy_replace)
    target = persist_agent_spec(spec, tmp_path)

    src, dst = captured["call"]
    assert dst == str(target)
    assert src.endswith(".tmp")
    assert not Path(src).exists()
    assert target.exists()


# ---------------------------------------------------------------------------
# build_agent_spec — pure, deterministic
# ---------------------------------------------------------------------------


def test_when_same_requirements_text_then_same_hash_replay_determinism(
    tmp_path: Path,
) -> None:
    text = "# Project\n\n## Goals\n- A backend API.\n"
    spec_a = build_agent_spec(
        project_dir=tmp_path,
        requirements_text=text,
        tier_flags={"T3": False, "T4": False},
    )
    spec_b = build_agent_spec(
        project_dir=tmp_path,
        requirements_text=text,
        tier_flags={"T3": False, "T4": False},
    )
    expected = hashlib.sha256(text.encode("utf-8")).hexdigest()
    assert spec_a.requirements_hash == expected
    assert spec_a == spec_b


def test_when_tier_flag_false_then_tier_config_has_skip_reason(tmp_path: Path) -> None:
    spec = build_agent_spec(
        project_dir=tmp_path,
        requirements_text="text",
        tier_flags={"T3": False, "T4": False},
    )
    tiers_by_id = {t.tier_id: t for t in spec.tiers}
    assert tiers_by_id["T3"].enabled is False
    assert tiers_by_id["T3"].skip_reason
    assert tiers_by_id["T4"].enabled is False
    assert tiers_by_id["T4"].skip_reason


def test_build_agent_spec_does_no_io(tmp_path: Path) -> None:
    nonexistent = tmp_path / "does-not-exist"
    spec = build_agent_spec(
        project_dir=nonexistent,
        requirements_text="text",
        tier_flags={"T3": True, "T4": True},
    )
    assert spec.requirements_hash
    assert not nonexistent.exists()
    assert not (tmp_path / "phase6_5_spec.json").exists()


# ---------------------------------------------------------------------------
# Skip-reason serialization fidelity
# ---------------------------------------------------------------------------


def test_when_tier_skipped_then_skip_reason_survives_round_trip(tmp_path: Path) -> None:
    tier = TierConfig(tier_id="T3", enabled=False, skip_reason="no frontend")
    spec = AgentSpec(
        requirements_hash="h",
        tiers=(tier,),
        base_url="http://127.0.0.1:8000",
    )
    persist_agent_spec(spec, tmp_path)
    loaded = load_agent_spec(tmp_path)

    [restored] = loaded.tiers
    assert restored == tier
    assert restored.skip_reason == "no frontend"


# ---------------------------------------------------------------------------
# Missing-file behavior
# ---------------------------------------------------------------------------


def test_when_spec_file_absent_then_load_raises_file_not_found(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        load_agent_spec(tmp_path)


# ---------------------------------------------------------------------------
# Path-traversal sanity
# ---------------------------------------------------------------------------


def test_when_dot_dir_contains_traversal_then_value_error(tmp_path: Path) -> None:
    bad = tmp_path / "subdir" / ".." / ".."
    spec = AgentSpec(
        requirements_hash="h",
        tiers=(),
        base_url="http://127.0.0.1:8000",
    )
    with pytest.raises(ValueError):
        persist_agent_spec(spec, bad)


# ---------------------------------------------------------------------------
# JSON shape — deterministic ordering and indentation
# ---------------------------------------------------------------------------


def test_persisted_json_is_sorted_and_indented(tmp_path: Path) -> None:
    spec = AgentSpec(
        requirements_hash="h",
        tiers=(
            TierConfig(tier_id="T0", enabled=True),
            TierConfig(tier_id="T1", enabled=True, port=8000),
        ),
        base_url="http://127.0.0.1:8000",
    )
    path = persist_agent_spec(spec, tmp_path)
    raw = path.read_text(encoding="utf-8")

    parsed = json.loads(raw)
    assert list(parsed.keys()) == sorted(parsed.keys())
    assert "  " in raw  # indent=2


# ---------------------------------------------------------------------------
# __all__ export
# ---------------------------------------------------------------------------


def test_phase6_5_verify_exports_agent_spec_types() -> None:
    from code_generator.orchestrator import phase6_5_verify

    assert "AgentSpec" in phase6_5_verify.__all__
    assert "TierConfig" in phase6_5_verify.__all__
    assert phase6_5_verify.AgentSpec is AgentSpec
    assert phase6_5_verify.TierConfig is TierConfig


# ---------------------------------------------------------------------------
# Pass-rate threshold fields — round-trip + T3 defaults (#292)
# ---------------------------------------------------------------------------


def test_tier_config_runs_and_threshold_default_to_single_run_strict() -> None:
    tier = TierConfig(tier_id="T0", enabled=True)
    assert tier.runs == 1
    assert tier.pass_rate_threshold == 1.0


def test_when_runs_and_threshold_set_then_round_trip_preserves_them(tmp_path: Path) -> None:
    spec = AgentSpec(
        requirements_hash="h",
        tiers=(
            TierConfig(
                tier_id="T3",
                enabled=True,
                runs=3,
                pass_rate_threshold=0.67,
            ),
        ),
    )
    persist_agent_spec(spec, tmp_path)
    loaded = load_agent_spec(tmp_path)

    [t3] = loaded.tiers
    assert t3.runs == 3
    assert t3.pass_rate_threshold == 0.67


def test_build_agent_spec_sets_t3_runs_3_and_threshold_1_0(tmp_path: Path) -> None:
    spec = build_agent_spec(
        project_dir=tmp_path,
        requirements_text="text",
        tier_flags={"T3": True, "T4": False},
    )
    t3 = next(t for t in spec.tiers if t.tier_id == "T3")
    assert t3.runs == 3
    assert t3.pass_rate_threshold == 1.0


def test_when_runs_threshold_added_then_persisted_json_byte_stable(tmp_path: Path) -> None:
    spec = build_agent_spec(
        project_dir=tmp_path,
        requirements_text="abc",
        tier_flags={"T3": True, "T4": True},
    )
    target = persist_agent_spec(spec, tmp_path)
    first = target.read_bytes()
    persist_agent_spec(spec, tmp_path)
    assert target.read_bytes() == first
