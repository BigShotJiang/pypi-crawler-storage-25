"""Tests for prompt-phase-6-5-verify.md registration and content (#272)."""

from __future__ import annotations

import pytest

from code_generator.prompts import PLACEHOLDER_SPEC, PromptError, load_prompt

_PROMPT = "prompt-phase-6-5-verify.md"
_EXPECTED_PLACEHOLDERS = frozenset(
    {
        "PROJECT_DIR",
        "REQUIREMENTS_MD",
        "DETECTED_STACK",
        "TIER_PLAN",
        "FAILURE_REPORT",
        "ATTEMPT",
        "MAX_RETRIES",
        "ORACLE_REPORT",
        "AGENT_SPEC_PATH",
        "TIERS_ACTIVE",
        "TIERS_SKIPPED",
    }
)


def _valid_kwargs() -> dict[str, str]:
    return {
        "PROJECT_DIR": "/tmp/proj",
        "REQUIREMENTS_MD": "requirements.md",
        "DETECTED_STACK": "fastapi",
        "TIER_PLAN": "T0: pip install\n",
        "FAILURE_REPORT": "",
        "ATTEMPT": "1",
        "MAX_RETRIES": "3",
        "ORACLE_REPORT": "(none)",
        "AGENT_SPEC_PATH": "/tmp/proj/.code-generator/phase6_5_spec.json",
        "TIERS_ACTIVE": "T0,T1,T2",
        "TIERS_SKIPPED": "T3 (no frontend), T4 (no docker)",
    }


class TestPlaceholderSpec:
    def test_prompt_is_registered(self) -> None:
        assert _PROMPT in PLACEHOLDER_SPEC

    def test_placeholder_set_matches_acceptance_criteria(self) -> None:
        assert PLACEHOLDER_SPEC[_PROMPT] == _EXPECTED_PLACEHOLDERS


class TestLoadPrompt:
    def test_loads_without_keyerror_when_all_placeholders_supplied(self) -> None:
        rendered = load_prompt(_PROMPT, **_valid_kwargs())
        assert isinstance(rendered, str)
        assert len(rendered) > 0

    def test_substitutes_every_placeholder_value(self) -> None:
        kwargs = _valid_kwargs()
        rendered = load_prompt(_PROMPT, **kwargs)
        for name, value in kwargs.items():
            assert value in rendered, f"placeholder {name} value not substituted"
        for name in kwargs:
            assert "{" + name + "}" not in rendered, f"placeholder {name} left unsubstituted"

    def test_missing_placeholder_raises_prompt_error(self) -> None:
        kwargs = _valid_kwargs()
        kwargs.pop("ATTEMPT")
        with pytest.raises(PromptError, match="missing"):
            load_prompt(_PROMPT, **kwargs)

    def test_extra_placeholder_raises_prompt_error(self) -> None:
        kwargs = _valid_kwargs()
        kwargs["UNEXPECTED"] = "x"
        with pytest.raises(PromptError, match="extra"):
            load_prompt(_PROMPT, **kwargs)


class TestPromptContent:
    def test_declares_yolo_mode(self) -> None:
        rendered = load_prompt(_PROMPT, **_valid_kwargs())
        assert "YOLO" in rendered

    def test_contains_constraints_section(self) -> None:
        rendered = load_prompt(_PROMPT, **_valid_kwargs())
        assert "### Constraints" in rendered or "## Constraints" in rendered

    def test_forbids_editing_phase_6_tests(self) -> None:
        rendered = load_prompt(_PROMPT, **_valid_kwargs())
        lowered = rendered.lower()
        assert "tests" in lowered
        assert "phase 6" in lowered

    def test_forbids_touching_state_json(self) -> None:
        rendered = load_prompt(_PROMPT, **_valid_kwargs())
        assert "state.json" in rendered

    def test_forbids_touching_checklists_dir(self) -> None:
        rendered = load_prompt(_PROMPT, **_valid_kwargs())
        assert ".code-generator/checklists/" in rendered

    def test_t3_section_present(self) -> None:
        rendered = load_prompt(_PROMPT, **_valid_kwargs())
        assert "T3" in rendered
        lowered = rendered.lower()
        assert "playwright" in lowered or "browser" in lowered
        assert "screenshot" in lowered

    def test_t4_section_present(self) -> None:
        rendered = load_prompt(_PROMPT, **_valid_kwargs())
        assert "T4" in rendered
        lowered = rendered.lower()
        assert "docker" in lowered or "compose" in lowered

    def test_directs_model_to_read_agent_spec_path(self) -> None:
        rendered = load_prompt(_PROMPT, **_valid_kwargs())
        lowered = rendered.lower()
        assert "agentspec" in lowered or "agent spec" in lowered
        assert "phase6_5_spec.json" in rendered

    def test_no_dollar_brace_syntax(self) -> None:
        """Placeholder syntax is ``{NAME}`` — never ``${NAME}``."""
        from pathlib import Path

        from code_generator import prompts

        raw = (Path(prompts.__file__).parent / _PROMPT).read_text(encoding="utf-8")
        assert "${" not in raw
