"""Tests for the Ollama per-cycle adaptive safety backstop (0.4.13).

Both the turn counter and the wall-clock are **non-blocking soft warnings**
— the pipeline is never aborted on either threshold alone. Real per-call
failures are the job of :class:`~code_generator.runner.retry.CircuitBreaker`
and the rate-limit handlers.

Backwards compatibility: ``OLLAMA_TURN_BUDGET`` and
``OLLAMA_WALLCLOCK_BUDGET_SECONDS`` are preserved as aliases for
:data:`OLLAMA_SOFT_TURN_WARN` and :data:`OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS`
respectively, so existing scripts keep importing.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from code_generator import state as _state
from code_generator.orchestrator.ollama_budget import (
    OLLAMA_SOFT_TURN_WARN,
    OLLAMA_TURN_BUDGET,
    OLLAMA_WALLCLOCK_BUDGET_SECONDS,
    OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS,
    OllamaBudgetExceeded,
    OllamaBudgetTracker,
)
from code_generator.runner.types import TokenUsage

if TYPE_CHECKING:
    import pytest

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestThresholdConstants:
    def test_soft_turn_warn_default_is_500(self) -> None:
        assert OLLAMA_SOFT_TURN_WARN == 500

    def test_turn_budget_alias_matches_soft_turn_warn(self) -> None:
        """Legacy ``OLLAMA_TURN_BUDGET`` must alias the new soft-warn constant."""
        assert OLLAMA_TURN_BUDGET == OLLAMA_SOFT_TURN_WARN

    def test_wallclock_soft_warn_default_is_4_hours(self) -> None:
        assert OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS == 14400

    def test_wallclock_budget_alias_matches_soft_warn(self) -> None:
        """Legacy ``OLLAMA_WALLCLOCK_BUDGET_SECONDS`` must alias the soft-warn constant."""
        assert OLLAMA_WALLCLOCK_BUDGET_SECONDS == OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_state_with_usage(
    turns_per_phase: dict[str, int], cycle_turns: dict[str, int] | None = None
) -> tuple[_state.State, _state.CycleState | None]:
    """Build a State (and optional CycleState) with given num_turns per phase."""
    st = _state.State(
        mode="multi-cycle",
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    st.token_usage = {p: TokenUsage(num_turns=n) for p, n in turns_per_phase.items()}
    cycle: _state.CycleState | None = None
    if cycle_turns is not None:
        cycle = _state.CycleState(
            id=1,
            name="c1",
            milestone_number=1,
            milestone_title="c1",
            status="open",
            phase=None,
            issues=[],
            commit_sha=None,
        )
        cycle.token_usage = {p: TokenUsage(num_turns=n) for p, n in cycle_turns.items()}
    return st, cycle


# ---------------------------------------------------------------------------
# Soft-turn warning
# ---------------------------------------------------------------------------


class TestTurnSoftWarning:
    def test_under_threshold_does_not_warn(self, caplog: pytest.LogCaptureFixture) -> None:
        """Below the soft threshold → no WARNING emitted, no raise."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase1": 50, "phase2": 80})
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        with caplog.at_level(logging.WARNING):
            tracker.check(st, cycle)

        turn_warnings = [r for r in caplog.records if "turns" in r.message.lower()]
        assert turn_warnings == []

    def test_over_threshold_warns_without_raising(self, caplog: pytest.LogCaptureFixture) -> None:
        """Crossing the soft threshold logs a WARNING; the pipeline continues."""
        st, cycle = _make_state_with_usage(
            {}, cycle_turns={"phase3_4": OLLAMA_SOFT_TURN_WARN + 100}
        )
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        with caplog.at_level(logging.WARNING):
            tracker.check(st, cycle)  # must not raise

        turn_warnings = [r for r in caplog.records if "consumed" in r.message.lower()]
        assert len(turn_warnings) == 1
        msg = turn_warnings[0].message
        assert str(OLLAMA_SOFT_TURN_WARN + 100) in msg
        assert str(OLLAMA_SOFT_TURN_WARN) in msg

    def test_warning_is_emitted_only_once_per_cycle(self, caplog: pytest.LogCaptureFixture) -> None:
        """Subsequent checks after the first warning must stay silent."""
        st, cycle = _make_state_with_usage(
            {}, cycle_turns={"phase3_4": OLLAMA_SOFT_TURN_WARN + 100}
        )
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        with caplog.at_level(logging.WARNING):
            tracker.check(st, cycle)
            tracker.check(st, cycle)
            tracker.check(st, cycle)

        turn_warnings = [r for r in caplog.records if "consumed" in r.message.lower()]
        assert len(turn_warnings) == 1

    def test_turns_aggregate_across_phases(self, caplog: pytest.LogCaptureFixture) -> None:
        """num_turns from every phase sum toward the soft threshold."""
        st, cycle = _make_state_with_usage(
            {},
            cycle_turns={
                "phase0": 100,
                "phase1": 80,
                "phase2": 80,
                "phase3_4": 200,
                "phase5": 60,
                "phase6": 20,
                "phase7": 10,
            },
        )
        # Sum = 550 > 500.
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        with caplog.at_level(logging.WARNING):
            tracker.check(st, cycle)  # must not raise

        assert any("550" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Wall-clock hard abort
# ---------------------------------------------------------------------------


class TestWallclockSoftWarning:
    def test_under_threshold_does_not_warn(self, caplog: pytest.LogCaptureFixture) -> None:
        """Elapsed < threshold → no WARNING emitted, no raise."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        now = 1_000_000.0
        tracker = OllamaBudgetTracker(
            provider_is_ollama=True,
            clock=lambda: now,
        )
        tracker.start()
        now += OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS - 10

        with caplog.at_level(logging.WARNING):
            tracker.check(st, cycle)

        wallclock_warnings = [r for r in caplog.records if "running for" in r.message.lower()]
        assert wallclock_warnings == []

    def test_over_threshold_warns_without_raising(self, caplog: pytest.LogCaptureFixture) -> None:
        """Crossing the threshold logs a WARNING; the pipeline continues."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        t = [1_000_000.0]

        def _clock() -> float:
            return t[0]

        tracker = OllamaBudgetTracker(provider_is_ollama=True, clock=_clock)
        tracker.start()
        t[0] += OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS + 1

        with caplog.at_level(logging.WARNING):
            tracker.check(st, cycle)  # must not raise

        wallclock_warnings = [r for r in caplog.records if "running for" in r.message.lower()]
        assert len(wallclock_warnings) == 1
        assert str(OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS) in wallclock_warnings[0].message

    def test_warning_is_emitted_only_once_per_cycle(self, caplog: pytest.LogCaptureFixture) -> None:
        """Subsequent checks after the first wall-clock warning must stay silent."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        t = [1_000_000.0]
        tracker = OllamaBudgetTracker(provider_is_ollama=True, clock=lambda: t[0])
        tracker.start()
        t[0] += OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS + 1

        with caplog.at_level(logging.WARNING):
            tracker.check(st, cycle)
            tracker.check(st, cycle)
            tracker.check(st, cycle)

        wallclock_warnings = [r for r in caplog.records if "running for" in r.message.lower()]
        assert len(wallclock_warnings) == 1

    def test_start_is_required_before_check(self) -> None:
        """check() without start() returns immediately on wall-clock (None start)."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        tracker = OllamaBudgetTracker(provider_is_ollama=True, clock=lambda: 1e12)

        tracker.check(st, cycle)  # must not raise

    def test_extreme_turn_count_does_not_raise(self) -> None:
        """Neither counter should raise on its own — both are soft warnings now."""
        st, cycle = _make_state_with_usage(
            {}, cycle_turns={"phase3_4": OLLAMA_SOFT_TURN_WARN * 100}
        )
        tracker = OllamaBudgetTracker(provider_is_ollama=True)

        tracker.check(st, cycle)  # must not raise

    def test_extreme_wallclock_does_not_raise(self) -> None:
        """Wall-clock far past threshold must not raise either (0.4.13)."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        t = [1_000_000.0]
        tracker = OllamaBudgetTracker(provider_is_ollama=True, clock=lambda: t[0])
        tracker.start()
        t[0] += OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS * 10  # 40 h

        tracker.check(st, cycle)  # must not raise


# ---------------------------------------------------------------------------
# Anthropic Max path — thresholds do not fire
# ---------------------------------------------------------------------------


class TestAnthropicMaxUntouched:
    def test_anthropic_max_mode_skips_turn_warning(self, caplog: pytest.LogCaptureFixture) -> None:
        """provider_is_ollama=False → no WARNING, no raise."""
        st, cycle = _make_state_with_usage(
            {}, cycle_turns={"phase3_4": OLLAMA_SOFT_TURN_WARN + 100}
        )
        tracker = OllamaBudgetTracker(provider_is_ollama=False)

        with caplog.at_level(logging.WARNING):
            tracker.check(st, cycle)

        turn_warnings = [r for r in caplog.records if "consumed" in r.message.lower()]
        assert turn_warnings == []

    def test_anthropic_max_mode_skips_wallclock_warning(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """provider_is_ollama=False → no WARNING, no raise."""
        st, cycle = _make_state_with_usage({}, cycle_turns={"phase0": 1})
        t = [1_000_000.0]
        tracker = OllamaBudgetTracker(provider_is_ollama=False, clock=lambda: t[0])
        tracker.start()
        t[0] += OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS + 100

        with caplog.at_level(logging.WARNING):
            tracker.check(st, cycle)

        wallclock_warnings = [r for r in caplog.records if "running for" in r.message.lower()]
        assert wallclock_warnings == []


# ---------------------------------------------------------------------------
# Exception shape
# ---------------------------------------------------------------------------


class TestExceptionType:
    def test_ollama_budget_exceeded_is_runtime_error(self) -> None:
        """OllamaBudgetExceeded must subclass RuntimeError (no new hierarchy)."""
        assert issubclass(OllamaBudgetExceeded, RuntimeError)
