"""Tests for code_generator.orchestrator.sica — Issue #286.

Independent verifier context (SICA) inside the existing per-cycle
``ClaudeSDKClient``. Same workspace, same credentials, same client
identity — but a verifier-role system-prompt prepend and a
``clear_tool_uses_20250919`` directive wipe Phase 3/4 tool-use
artifacts before the repair turn.
"""

from __future__ import annotations

import logging
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from code_generator.orchestrator import sica as sica_module
from code_generator.orchestrator.sica import VerifierContext, build_verifier_context
from code_generator.runner.options import make_agent_options
from code_generator.runner.types import RunResult, TokenUsage

# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


@pytest.fixture
def shared_client() -> MagicMock:
    return MagicMock(name="shared_client")


@pytest.fixture
def captured_dispatch(monkeypatch: pytest.MonkeyPatch) -> dict[str, object]:
    """Patch run_with_shared_client; capture every kwarg for assertions."""
    captured: dict[str, object] = {}

    async def fake_dispatch(client, prompt, options, *, logger, state_path):  # type: ignore[no-untyped-def]
        captured["client"] = client
        captured["prompt"] = prompt
        captured["options"] = options
        captured["logger"] = logger
        captured["state_path"] = state_path
        return RunResult(text="", session_id=None, usage=TokenUsage())

    monkeypatch.setattr(sica_module, "run_with_shared_client", fake_dispatch)
    return captured


def _basic_options():  # type: ignore[no-untyped-def]
    return make_agent_options(
        allowed_tools=["Read", "Edit", "Bash", "Grep", "Glob"],
    )


# ---------------------------------------------------------------------------
# Client identity — no second ClaudeSDKClient
# ---------------------------------------------------------------------------


def test_when_build_verifier_context_then_client_identity_preserved(
    shared_client: MagicMock,
) -> None:
    context = build_verifier_context(shared_client)

    assert isinstance(context, VerifierContext)
    assert context.client is shared_client


# ---------------------------------------------------------------------------
# Role prefix injection
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_verifier_run_then_role_prefix_appended_to_system_prompt(
    shared_client: MagicMock,
    captured_dispatch: dict[str, object],
    tmp_path: Path,
) -> None:
    context = build_verifier_context(shared_client)

    await context.run(
        "prompt body",
        _basic_options(),
        logger=logging.getLogger("test"),
        state_path=tmp_path / "state.json",
    )

    options = captured_dispatch["options"]
    sp = options.system_prompt  # type: ignore[attr-defined]
    text = sp.get("append", "") if isinstance(sp, dict) else sp or ""
    assert sica_module.VERIFIER_ROLE_PREFIX.strip()
    assert sica_module.VERIFIER_ROLE_PREFIX.strip() in text


# ---------------------------------------------------------------------------
# clear_tool_uses_20250919 wired through context_management
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_verifier_run_then_clear_tool_uses_directive_in_options(
    shared_client: MagicMock,
    captured_dispatch: dict[str, object],
    tmp_path: Path,
) -> None:
    context = build_verifier_context(shared_client)

    await context.run(
        "prompt body",
        _basic_options(),
        logger=logging.getLogger("test"),
        state_path=tmp_path / "state.json",
    )

    options = captured_dispatch["options"]
    cm = getattr(options, "context_management", None)
    assert cm is not None
    tools = cm.get("tools", [])
    assert any(t.get("type") == "clear_tool_uses_20250919" for t in tools)


# ---------------------------------------------------------------------------
# Phase 3/4 tool-use entries do not appear in repair options
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_verifier_run_then_no_phase34_artifacts_in_options(
    shared_client: MagicMock,
    captured_dispatch: dict[str, object],
    tmp_path: Path,
) -> None:
    context = build_verifier_context(shared_client)

    options_in = _basic_options()
    # Simulate Phase 3/4 noise on the inbound options (the orchestrator should
    # never pass these but the verifier defensively does not propagate them).
    options_in.phase34_tool_uses = ["TestImplementer::Bash::pytest"]  # noqa: SLF001

    await context.run(
        "prompt body",
        options_in,
        logger=logging.getLogger("test"),
        state_path=tmp_path / "state.json",
    )

    options_out = captured_dispatch["options"]
    # The verifier hands the same options object to the dispatcher (no new
    # client, single workspace) but the context-management directive ensures
    # tool-use entries are cleared server-side before the verifier turn.
    cm = options_out.context_management  # type: ignore[attr-defined]
    tools = cm["tools"]
    clear_directive = next(t for t in tools if t["type"] == "clear_tool_uses_20250919")
    assert clear_directive["trigger"]["type"] == "input_tokens"


# ---------------------------------------------------------------------------
# Single-client invariant: no ClaudeSDKClient(...) call
# ---------------------------------------------------------------------------


def test_when_module_imported_then_no_claude_sdk_client_instantiation() -> None:
    import inspect

    source = inspect.getsource(sica_module)
    assert "ClaudeSDKClient(" not in source


# ---------------------------------------------------------------------------
# State write isolation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_verifier_run_then_state_json_not_written_by_pass(
    shared_client: MagicMock,
    captured_dispatch: dict[str, object],
    tmp_path: Path,
) -> None:
    state_path = tmp_path / "state.json"
    context = build_verifier_context(shared_client)

    await context.run(
        "prompt body",
        _basic_options(),
        logger=logging.getLogger("test"),
        state_path=state_path,
    )

    # The verifier itself never touches state.json — the orchestrator owns
    # save_state. The repair pass returns a RunResult; persisting is the
    # caller's job.
    assert not state_path.exists()


# ---------------------------------------------------------------------------
# Dispatcher receives the shared client identity
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_verifier_run_then_dispatcher_receives_shared_client(
    shared_client: MagicMock,
    captured_dispatch: dict[str, object],
    tmp_path: Path,
) -> None:
    context = build_verifier_context(shared_client)

    await context.run(
        "prompt body",
        _basic_options(),
        logger=logging.getLogger("test"),
        state_path=tmp_path / "state.json",
    )

    assert captured_dispatch["client"] is shared_client


# ---------------------------------------------------------------------------
# Integration: _run_repair_pass routes through SICA
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_phase6_5_repair_runs_then_routes_through_sica(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Phase 6.5 repair must dispatch through VerifierContext.run, not directly."""
    from code_generator.orchestrator import phase6_5_verify

    captured_calls: list[tuple[str, ...]] = []

    async def fake_run(self, prompt, options, *, logger, state_path):  # type: ignore[no-untyped-def]
        captured_calls.append(("VerifierContext.run", str(state_path)))
        return RunResult(text="", session_id=None, usage=TokenUsage())

    monkeypatch.setattr(VerifierContext, "run", fake_run)

    state = MagicMock()
    state.token_usage = {}
    state.phase6_5 = None
    target = MagicMock()
    target.token_usage = {}
    shared = MagicMock()

    await phase6_5_verify._run_repair_pass(
        failure_report="boom",
        shared_client=shared,
        project_dir=tmp_path,
        state_path=tmp_path / "state.json",
        logger=logging.getLogger("test"),
        runner_module=MagicMock(),
        max_turns=None,
        attempt=0,
        target=target,
    )

    assert captured_calls
    assert captured_calls[0][0] == "VerifierContext.run"


# Suppress unused fixture in lint
_ = AsyncMock
