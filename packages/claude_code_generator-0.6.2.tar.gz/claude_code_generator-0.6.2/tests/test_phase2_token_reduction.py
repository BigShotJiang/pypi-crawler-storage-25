"""Phase 2 token-reduction guard (issue #254).

Cycle 5 acceptance criterion 4 demands that the batched Phase 2 review uses
fewer Opus input tokens than the per-issue baseline. Since the per-issue
codepath was removed when the orchestrator switched to a single batched call,
the baseline is modelled arithmetically:

    per_issue.input  = N * S + N * delta
    batched.input    =     S + N * delta

where ``S`` is the system-prompt overhead paid once per Opus call and
``delta`` is the issue-specific input increment. ``S > 0`` and ``N > 1``
together imply ``batched.input < per_issue.input`` — that inequality is the
load-bearing assertion. The absolute constants below are illustrative; only
the inequality matters, so prompt-edit churn cannot make the test flaky.

This test file is placed alongside ``test_phase2.py`` and shares fixtures
through ``tests/_phase2_helpers.py``.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase2_review
from code_generator.runner.types import TokenUsage
from tests._phase2_helpers import (
    decisions_response,
    identity_with_backoff,
    make_state_with_issues,
    ok_decision,
)

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Token-cost model — illustrative numbers, only the inequality matters
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT_OVERHEAD_TOKENS = 1500
"""System-prompt + repo-map overhead paid once per Opus call."""

_PER_ISSUE_INPUT_DELTA = 350
"""Input-token increment that scales linearly with the number of issues."""


def _per_issue_baseline_input(n_issues: int) -> int:
    """Model the *removed* per-issue dispatch as N independent Opus calls."""
    return n_issues * _SYSTEM_PROMPT_OVERHEAD_TOKENS + n_issues * _PER_ISSUE_INPUT_DELTA


def _batched_input(n_issues: int) -> int:
    """Model the current single-batched dispatch as one Opus call."""
    return _SYSTEM_PROMPT_OVERHEAD_TOKENS + n_issues * _PER_ISSUE_INPUT_DELTA


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestBatchedReviewTokenReduction:
    """Phase 2 batched call must report fewer input tokens than the per-issue baseline."""

    @pytest.mark.asyncio
    @pytest.mark.parametrize("n_issues", [3, 5, 10])
    async def test_batched_input_tokens_below_per_issue_baseline(
        self, tmp_path: Path, n_issues: int
    ) -> None:
        numbers = list(range(1, n_issues + 1))
        state = make_state_with_issues(tmp_path, numbers)
        batched_usage = TokenUsage(input=_batched_input(n_issues), output=0)
        baseline_input = _per_issue_baseline_input(n_issues)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):  # noqa: ARG001
            return decisions_response([ok_decision(n) for n in numbers], usage=batched_usage)

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        persisted = state.token_usage["phase2"]
        assert persisted.input < baseline_input

    @pytest.mark.asyncio
    async def test_batched_cache_write_routes_to_1h_bucket(self, tmp_path: Path) -> None:
        """Phase 2 BP3 invariant: every ``cache_write`` lands in the 1h bucket."""
        state = make_state_with_issues(tmp_path, [1, 2, 3])
        batched_usage = TokenUsage(
            input=_batched_input(3),
            output=10,
            cache_read=200,
            cache_write=64,
        )

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):  # noqa: ARG001
            return decisions_response(
                [ok_decision(1), ok_decision(2), ok_decision(3)],
                usage=batched_usage,
            )

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        persisted = state.token_usage["phase2"]
        assert persisted.cache_write_1h == batched_usage.cache_write
        assert persisted.cache_write_5m == 0

    @pytest.mark.asyncio
    @pytest.mark.parametrize("n_issues", [3, 5, 10])
    async def test_token_reduction_holds_in_multi_cycle_payload(
        self, tmp_path: Path, n_issues: int
    ) -> None:
        from code_generator.repo_info import RepoInfo

        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle_issues = [
            _state.IssueState(number=n, status="open", agent="python-pro")
            for n in range(1, n_issues + 1)
        ]
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=1,
            issues=cycle_issues,
            commit_sha=None,
        )
        _state.save_state(state_dir / "state.json", st)

        batched_usage = TokenUsage(input=_batched_input(n_issues), output=0)
        baseline_input = _per_issue_baseline_input(n_issues)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):  # noqa: ARG001
            return decisions_response(
                [ok_decision(n) for n in range(1, n_issues + 1)],
                usage=batched_usage,
            )

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        persisted = cycle.token_usage["phase2"]
        assert persisted.input < baseline_input
        assert "phase2" not in st.token_usage
