"""Tests for code_generator.orchestrator.phase2_review — batched cycle-review flow."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase2_review
from code_generator.runner.retry import CircuitOpen
from code_generator.runner.sdk_runner import RunResult
from code_generator.runner.types import MaxTurnsExceeded, TokenUsage

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ok_decision(issue_number: int) -> dict:
    return {"issue_number": issue_number, "action": "ok", "comment_body": ""}


def _comment_decision(issue_number: int, body: str = "Add pagination AC.") -> dict:
    return {"issue_number": issue_number, "action": "comment", "comment_body": body}


def _response(decisions: list[dict]) -> RunResult:
    """Wrap a decisions list into a RunResult with valid batched-review JSON."""
    return RunResult(
        text=json.dumps({"decisions": decisions}),
        session_id=None,
        usage=TokenUsage(),
    )


def _make_state_with_issues(tmp_path: Path, numbers: list[int]) -> _state.State:
    from code_generator.repo_info import RepoInfo

    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    st.repo = RepoInfo(host="github.com", owner="test-owner", name="test-repo")
    st.issues = [_state.IssueState(number=n, status="open", agent="python-pro") for n in numbers]
    _state.save_state(state_dir / "state.json", st)
    return st


async def _identity_with_backoff(factory, *, breaker, **kw):
    """Pass-through replacement for retry.with_backoff that still surfaces exceptions."""
    return await factory()


# ---------------------------------------------------------------------------
# Tests — batched review
# ---------------------------------------------------------------------------


class TestBatchedReview:
    @pytest.mark.asyncio
    async def test_single_call_reviews_all_open_issues(self, tmp_path: Path) -> None:
        """Three open issues must trigger exactly one Opus call (the batched review)."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _response([_ok_decision(1), _ok_decision(2), _ok_decision(3)])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 1
        assert all(issue.reviewed for issue in state.issues)

    @pytest.mark.asyncio
    async def test_only_non_ok_decisions_trigger_post_comment(self, tmp_path: Path) -> None:
        """post_comment is called only for decisions with action != 'ok'."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _response(
                [
                    _ok_decision(1),
                    _comment_decision(2, "Please split."),
                    {"issue_number": 3, "action": "split", "comment_body": "REVIEW: split it."},
                ]
            )

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch.object(phase2_review.gh, "post_comment") as mock_post,
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        posted_numbers = sorted(call.args[1] for call in mock_post.call_args_list)
        assert posted_numbers == [2, 3]

    @pytest.mark.asyncio
    async def test_closed_issues_are_excluded_from_payload(self, tmp_path: Path) -> None:
        """Closed issues must not appear in the ISSUES_JSON payload."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        from code_generator.repo_info import RepoInfo

        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        st.issues = [
            _state.IssueState(number=901, status="closed", agent="python-pro"),
            _state.IssueState(number=902, status="open", agent="python-pro"),
        ]
        _state.save_state(state_dir / "state.json", st)

        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _response([_ok_decision(902)])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        assert '"issue_number": 902' in captured_prompts[0]
        assert '"issue_number": 901' not in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_already_reviewed_issues_excluded(self, tmp_path: Path) -> None:
        """Issues with reviewed=True from a prior run must be excluded from the batch."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        from code_generator.repo_info import RepoInfo

        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        st.issues = [
            _state.IssueState(number=901, status="open", agent="python-pro", reviewed=True),
            _state.IssueState(number=902, status="open", agent="python-pro", reviewed=False),
            _state.IssueState(number=903, status="open", agent="python-pro", reviewed=True),
        ]
        _state.save_state(state_dir / "state.json", st)

        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _response([_ok_decision(902)])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        assert '"issue_number": 902' in captured_prompts[0]
        assert '"issue_number": 901' not in captured_prompts[0]
        assert '"issue_number": 903' not in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_zero_open_unreviewed_skips_opus_call(self, tmp_path: Path) -> None:
        """When every issue is already reviewed, no Opus call is made."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        from code_generator.repo_info import RepoInfo

        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        st.issues = [_state.IssueState(number=1, status="closed", agent="python-pro")]
        _state.save_state(state_dir / "state.json", st)

        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _response([])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 0
        assert st.token_usage.get("phase2") == TokenUsage()

    @pytest.mark.asyncio
    async def test_multi_cycle_uses_cycle_issues(self, tmp_path: Path) -> None:
        """In multi-cycle mode the batched payload comes from cycle.issues, not state.issues."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        from code_generator.repo_info import RepoInfo

        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=1,
            issues=[_state.IssueState(number=99, status="open", agent="python-pro")],
            commit_sha=None,
        )
        _state.save_state(state_dir / "state.json", st)

        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _response([_ok_decision(99)])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        assert '"issue_number": 99' in captured_prompts[0]
        assert cycle.issues[0].reviewed is True

    @pytest.mark.asyncio
    async def test_options_use_opus_model(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _response([_ok_decision(1)])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].model == "claude-opus-4-7"


class TestBatchedReviewFailureModes:
    @pytest.mark.asyncio
    async def test_json_parse_failure_tags_every_issue(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1, 2])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return RunResult(text="not json at all", session_id=None, usage=TokenUsage())

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch.object(phase2_review.gh, "add_label") as mock_label,
            patch.object(phase2_review.gh, "post_comment") as mock_post,
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        tagged = sorted(call.args[1] for call in mock_label.call_args_list)
        assert tagged == [1, 2]
        assert mock_post.call_count == 0
        assert not any(issue.reviewed for issue in state.issues)

    @pytest.mark.asyncio
    async def test_circuit_open_tags_every_issue(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1, 2])

        async def fake_with_backoff(factory, *, breaker, **kw):
            raise CircuitOpen("opened")

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _response([])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch.object(phase2_review.gh, "add_label") as mock_label,
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        tagged = sorted(call.args[1] for call in mock_label.call_args_list)
        assert tagged == [1, 2]

    @pytest.mark.asyncio
    async def test_max_turns_exceeded_tags_every_issue(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [5])

        async def fake_with_backoff(factory, *, breaker, **kw):
            raise MaxTurnsExceeded("budget")

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _response([])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch.object(phase2_review.gh, "add_label") as mock_label,
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_label.assert_called_once_with(state.repo, 5, "needs-manual-review")

    @pytest.mark.asyncio
    async def test_label_gh_error_is_swallowed(self, tmp_path: Path) -> None:
        from code_generator.gh import GhError

        state = _make_state_with_issues(tmp_path, [1])

        async def fake_with_backoff(factory, *, breaker, **kw):
            raise CircuitOpen("opened")

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _response([])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch.object(phase2_review.gh, "add_label", side_effect=GhError(1, "not found")),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_unknown_issue_in_decision_is_skipped(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            # Model hallucinates an issue number that was never in the payload.
            return _response([_ok_decision(1), _comment_decision(999, "hallucinated")])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch.object(phase2_review.gh, "post_comment") as mock_post,
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert mock_post.call_count == 0


class TestBatchedReviewTelemetry:
    @pytest.mark.asyncio
    async def test_token_usage_persisted_single_cycle(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1, 2])
        usage = TokenUsage(input=123, output=45, cache_read=67, cache_write=8)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return RunResult(
                text=json.dumps({"decisions": [_ok_decision(1), _ok_decision(2)]}),
                session_id=None,
                usage=usage,
            )

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        persisted = state.token_usage["phase2"]
        assert persisted.input == usage.input
        assert persisted.output == usage.output
        assert persisted.cache_read == usage.cache_read
        assert persisted.cache_write == usage.cache_write
        # Issue #246: phase 2 routes cache_write into the BP3 (1h) bucket.
        assert persisted.cache_write_1h == usage.cache_write
        assert persisted.cache_write_5m == 0
        assert persisted.cache_write_5m + persisted.cache_write_1h == persisted.cache_write

    @pytest.mark.asyncio
    async def test_token_usage_persisted_on_cycle_in_multi_cycle(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        from code_generator.repo_info import RepoInfo

        st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=1,
            issues=[_state.IssueState(number=5, status="open", agent="python-pro")],
            commit_sha=None,
        )
        _state.save_state(state_dir / "state.json", st)
        usage = TokenUsage(input=50, output=5, cache_read=10, cache_write=1)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return RunResult(
                text=json.dumps({"decisions": [_ok_decision(5)]}),
                session_id=None,
                usage=usage,
            )

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        persisted = cycle.token_usage["phase2"]
        assert persisted.input == usage.input
        assert persisted.output == usage.output
        assert persisted.cache_read == usage.cache_read
        assert persisted.cache_write == usage.cache_write
        assert persisted.cache_write_1h == usage.cache_write
        assert persisted.cache_write_5m == 0
        assert persisted.cache_write_5m + persisted.cache_write_1h == persisted.cache_write
        assert "phase2" not in st.token_usage

    @pytest.mark.asyncio
    async def test_successful_batched_review_persists_reviewed_flags(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [42, 43])
        state_path = tmp_path / ".code-generator" / "state.json"

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _response([_ok_decision(42), _ok_decision(43)])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        reloaded = _state.load_state(state_path)
        assert all(issue.reviewed for issue in reloaded.issues)


class TestBatchedReviewMcpWiring:
    """Phase 2 must still wire build_mcp_servers into make_agent_options."""

    _FAKE_MCP_SERVERS = {"codebase_memory": {"type": "stdio", "command": "/bin/cm"}}

    @pytest.mark.asyncio
    async def test_mcp_servers_in_options(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _response([_ok_decision(1)])

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch(
                "code_generator.orchestrator.phase2_review.build_mcp_servers",
                return_value=self._FAKE_MCP_SERVERS,
            ),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].mcp_servers == self._FAKE_MCP_SERVERS
        allowed = captured_options[0].allowed_tools
        assert any("codebase_memory" in tool for tool in allowed)


class TestBatchedReviewSharedClient:
    """Phase 2 must route through ``run_with_shared_client`` when ``shared_client`` is set."""

    @pytest.mark.asyncio
    async def test_shared_client_path_calls_run_with_shared_client_not_main_loop(
        self, tmp_path: Path
    ) -> None:
        state = _make_state_with_issues(tmp_path, [1, 2])
        mock_shared_run = AsyncMock(return_value=_response([_ok_decision(1), _ok_decision(2)]))
        mock_main_loop = AsyncMock(return_value=_response([_ok_decision(1), _ok_decision(2)]))

        with (
            patch.object(phase2_review, "run_with_shared_client", new=mock_shared_run),
            patch.object(phase2_review.rate_limit, "main_loop", new=mock_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=MagicMock(name="shared_client"),
            )

        assert mock_shared_run.call_count == 1
        assert mock_main_loop.call_count == 0

    @pytest.mark.asyncio
    async def test_fresh_path_calls_main_loop_not_run_with_shared_client(
        self, tmp_path: Path
    ) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        mock_shared_run = AsyncMock(return_value=_response([_ok_decision(1)]))
        mock_main_loop = AsyncMock(return_value=_response([_ok_decision(1)]))

        with (
            patch.object(phase2_review, "run_with_shared_client", new=mock_shared_run),
            patch.object(phase2_review.rate_limit, "main_loop", new=mock_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=None,
            )

        assert mock_main_loop.call_count == 1
        assert mock_shared_run.call_count == 0

    @pytest.mark.asyncio
    @pytest.mark.parametrize("compaction_beta", [True, False])
    async def test_shared_client_path_invokes_soft_reset_or_boundary_prefix(
        self, tmp_path: Path, compaction_beta: bool
    ) -> None:
        """Beta-available → boundary_prefix_only; non-beta → soft_reset_context awaited.

        Both branches must end up prepending the boundary prefix to the prompt
        sent into ``run_with_shared_client``.
        """
        from code_generator.runner.soft_reset import SoftResetResult

        state = _make_state_with_issues(tmp_path, [7])
        mock_shared_run = AsyncMock(return_value=_response([_ok_decision(7)]))
        mock_boundary_only = MagicMock(return_value="BOUNDARY_BETA\n\n")
        mock_soft_reset = AsyncMock(
            return_value=SoftResetResult(
                boundary_prefix="BOUNDARY_NONBETA\n\n",
                context_management={"sentinel": True},
            )
        )

        with (
            patch.object(phase2_review, "run_with_shared_client", new=mock_shared_run),
            patch.object(
                phase2_review,
                "compaction_beta_available",
                return_value=compaction_beta,
            ),
            patch.object(phase2_review, "boundary_prefix_only", new=mock_boundary_only),
            patch.object(phase2_review, "soft_reset_context", new=mock_soft_reset),
            patch.object(phase2_review.retry, "with_backoff", side_effect=_identity_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=MagicMock(name="shared_client"),
            )

        assert mock_shared_run.call_count == 1
        prompt_arg = mock_shared_run.call_args.args[1]

        if compaction_beta:
            mock_boundary_only.assert_called_once()
            mock_soft_reset.assert_not_awaited()
            assert prompt_arg.startswith("BOUNDARY_BETA\n\n")
        else:
            mock_soft_reset.assert_awaited_once()
            mock_boundary_only.assert_not_called()
            assert prompt_arg.startswith("BOUNDARY_NONBETA\n\n")
