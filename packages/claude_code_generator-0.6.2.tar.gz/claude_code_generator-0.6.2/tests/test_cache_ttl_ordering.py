"""Tests for §9 per-breakpoint TTL assignment and 1h-before-5m ordering (issue #240).

Covers:

1. ``resolve_ttls(probe_result)`` returns a 4-tuple matching BP1/BP2/BP3/BP4
   in canonical order. Probe ``"1h"`` → ``("1h","1h","1h","5m")``; probe
   ``"5m"`` → ``("5m","5m","5m","5m")`` (degraded path stays valid by being
   uniform).
2. ``build_cache_breakpoints(..., ttls=...)`` propagates per-BP TTLs into
   each ``CacheBreakpoint.cache_control["ttl"]`` field.
3. ``validate_breakpoints`` rejects layouts where a ``5m`` marker precedes
   a ``1h`` marker (Anthropic invariant).
4. Index-pinned assertions per review-comment #1: BP4 is the **last** entry
   and is the **only** ``5m`` entry on the canonical 1h-probe path.
5. SDK-rejection fallback path produces a uniform all-``5m`` layout that
   still validates (review-comment #2 — no ``RuntimeError``, layout shape
   preserved).
6. Integration-style fixture: a paused-cycle simulation reports lower
   ``cache_creation_input_tokens`` when BP1/2/3 are ``1h`` than when forced
   to ``5m`` (the empirical signal that the 1h TTL is actually doing its
   job — issue body's bench AC).
"""

from __future__ import annotations

import pytest

from code_generator.runner.cache_breakpoints import (
    CacheBreakpoint,
    build_cache_breakpoints,
    resolve_ttls,
    validate_breakpoints,
)

# ---------------------------------------------------------------------------
# resolve_ttls — probe-driven TTL tuple
# ---------------------------------------------------------------------------


class TestResolveTtls:
    def test_probe_1h_returns_1h_1h_1h_5m_tuple(self) -> None:
        """Probe '1h' → BP1/BP2/BP3 carry 1h; BP4 stays at the 5m default."""
        assert resolve_ttls("1h") == ("1h", "1h", "1h", "5m")

    def test_probe_5m_returns_uniform_all_5m_tuple(self) -> None:
        """SDK rejection fallback: every BP collapses to 5m (uniform → no ordering issue)."""
        assert resolve_ttls("5m") == ("5m", "5m", "5m", "5m")

    def test_unknown_probe_result_raises_value_error(self) -> None:
        """Defensive guard — only '1h' and '5m' are supported probe outcomes."""
        with pytest.raises(ValueError, match="probe"):
            resolve_ttls("30s")

    def test_returns_tuple_of_four_strings(self) -> None:
        """Return type is a fixed-length 4-tuple to mirror CACHE_BREAKPOINT_COUNT."""
        result = resolve_ttls("1h")
        assert isinstance(result, tuple) and len(result) == 4


# ---------------------------------------------------------------------------
# build_cache_breakpoints with ttls= override
# ---------------------------------------------------------------------------


class TestBuildCacheBreakpointsWithTtls:
    def _layout(self, ttls: tuple[str, str, str, str]) -> list[CacheBreakpoint]:
        return build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
            ttls=ttls,
        )

    def test_ttls_propagate_to_each_breakpoint_in_order(self) -> None:
        """Per-BP TTLs land on the correct breakpoint by name and index."""
        bps = self._layout(("1h", "1h", "1h", "5m"))
        assert bps[0].cache_control["ttl"] == "1h"
        assert bps[1].cache_control["ttl"] == "1h"
        assert bps[2].cache_control["ttl"] == "1h"
        assert bps[3].cache_control["ttl"] == "5m"

    def test_index_pinned_assertion_bp4_is_only_5m_on_canonical_path(self) -> None:
        """Review-comment #1 — pin by index, not membership: BP4 is last AND the only 5m."""
        bps = self._layout(("1h", "1h", "1h", "5m"))
        assert bps[-1].cache_control["ttl"] == "5m"
        assert all(bp.cache_control["ttl"] == "1h" for bp in bps[:-1])

    def test_uniform_5m_layout_preserved_on_sdk_rejection_path(self) -> None:
        """Review-comment #2 — when the SDK rejects 1h, all four BPs collapse to 5m."""
        bps = self._layout(("5m", "5m", "5m", "5m"))
        assert all(bp.cache_control["ttl"] == "5m" for bp in bps)
        assert len(bps) == 4

    def test_ttls_argument_is_optional_and_default_preserves_legacy_dict(self) -> None:
        """When `ttls` is omitted, build_cache_breakpoints honours the old `cache_control` arg."""
        bps = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
        )
        for bp in bps:
            assert bp.cache_control == {"type": "ephemeral", "ttl": "1h"}


# ---------------------------------------------------------------------------
# validate_breakpoints — TTL ordering invariant
# ---------------------------------------------------------------------------


class TestValidateTtlOrdering:
    def test_canonical_1h_1h_1h_5m_layout_validates(self) -> None:
        """The §9 canonical layout passes the TTL-ordering check."""
        bps = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
            ttls=("1h", "1h", "1h", "5m"),
        )
        validate_breakpoints(bps)

    def test_uniform_5m_layout_validates(self) -> None:
        """The SDK-rejection fallback (all 5m) still validates — uniform TTL is in-order."""
        bps = build_cache_breakpoints(
            tools_block_index=0,
            system_block_index=1,
            repo_map_block_index=2,
            cycle_prompt_block_index=3,
            boundary_user_block_index=4,
            ttls=("5m", "5m", "5m", "5m"),
        )
        validate_breakpoints(bps)

    def test_5m_before_1h_raises_value_error(self) -> None:
        """Any 5m entry preceding a 1h entry violates Anthropic's longer-TTL-first invariant."""
        # Hand-craft a CacheBreakpoint list that violates the invariant —
        # build_cache_breakpoints itself only emits valid TTL tuples, so we
        # bypass it to simulate a corrupt layout.
        bps = [
            CacheBreakpoint("BP1_tools", 0, {"type": "ephemeral", "ttl": "5m"}),
            CacheBreakpoint("BP2_system", 1, {"type": "ephemeral", "ttl": "1h"}),
            CacheBreakpoint("BP3_repo_map_and_cycle_prompt", 2, {"type": "ephemeral", "ttl": "1h"}),
            CacheBreakpoint("BP4_boundary_user", 3, {"type": "ephemeral", "ttl": "5m"}),
        ]
        with pytest.raises(ValueError, match="TTL"):
            validate_breakpoints(bps)

    def test_5m_at_index_0_followed_by_1h_raises(self) -> None:
        """Defensive: any inversion (5m before 1h) raises regardless of position."""
        bps = [
            CacheBreakpoint("BP1_tools", 0, {"type": "ephemeral", "ttl": "5m"}),
            CacheBreakpoint("BP2_system", 1, {"type": "ephemeral", "ttl": "5m"}),
            CacheBreakpoint("BP3_repo_map_and_cycle_prompt", 2, {"type": "ephemeral", "ttl": "1h"}),
            CacheBreakpoint("BP4_boundary_user", 3, {"type": "ephemeral", "ttl": "5m"}),
        ]
        with pytest.raises(ValueError, match="TTL"):
            validate_breakpoints(bps)


# ---------------------------------------------------------------------------
# Bench-fixture integration: paused cycle reports lower cache_creation tokens
# ---------------------------------------------------------------------------


class TestPausedCycleCacheCreationFixture:
    """Synthetic fixture: a paused cycle simulator reports lower cache_creation
    tokens when BP1/2/3 are 1h than when forced to 5m. No live SDK call —
    cache_creation_input_tokens is computed by ``simulate_paused_cycle_cache``
    given a TTL tuple and a pause length.
    """

    def test_1h_layout_reports_lower_cache_creation_than_5m_for_5min_pause(self) -> None:
        """Issue body bench-AC: paused cycle ≥5min — 1h TTL beats 5m TTL on cache_creation."""
        from code_generator.runner.cache_breakpoints import simulate_paused_cycle_cache

        # 30k tokens of static prefix (tools + system + repo-map + cycle-prompt),
        # then a 6-minute pause before the next turn — an elapsed time the §9
        # 1h TTL should absorb but the 5m TTL must miss.
        prefix_tokens = 30_000
        pause_seconds = 6 * 60

        cache_creation_1h = simulate_paused_cycle_cache(
            prefix_tokens=prefix_tokens,
            pause_seconds=pause_seconds,
            ttls=("1h", "1h", "1h", "5m"),
        )
        cache_creation_5m = simulate_paused_cycle_cache(
            prefix_tokens=prefix_tokens,
            pause_seconds=pause_seconds,
            ttls=("5m", "5m", "5m", "5m"),
        )

        assert cache_creation_1h < cache_creation_5m, (
            "1h TTL must report lower cache_creation tokens than 5m TTL "
            "after a ≥5-minute pause (the empirical signal of §9)."
        )

    def test_short_pause_under_5min_keeps_both_layouts_equally_warm(self) -> None:
        """Pause shorter than 5m does not invalidate either layout — cache_creation is identical."""
        from code_generator.runner.cache_breakpoints import simulate_paused_cycle_cache

        cache_creation_1h = simulate_paused_cycle_cache(
            prefix_tokens=30_000,
            pause_seconds=60,
            ttls=("1h", "1h", "1h", "5m"),
        )
        cache_creation_5m = simulate_paused_cycle_cache(
            prefix_tokens=30_000,
            pause_seconds=60,
            ttls=("5m", "5m", "5m", "5m"),
        )
        assert cache_creation_1h == cache_creation_5m

    def test_long_pause_over_1h_invalidates_even_1h_layout(self) -> None:
        """Pauses past 1h invalidate even the 1h layout — neither path saves anything."""
        from code_generator.runner.cache_breakpoints import simulate_paused_cycle_cache

        cache_creation_1h = simulate_paused_cycle_cache(
            prefix_tokens=30_000,
            pause_seconds=60 * 65,  # 65 minutes — past the 1h TTL.
            ttls=("1h", "1h", "1h", "5m"),
        )
        # Past the 1h TTL: every BP1/2/3 marker has expired. cache_creation
        # must equal the full prefix again.
        assert cache_creation_1h == 30_000
