"""Tests for code_generator.orchestrator.cycle_prompts."""

from __future__ import annotations

import importlib.resources
import json
import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import cycle_prompts
from code_generator.runner.sdk_runner import RunResult
from code_generator.runner.types import TokenUsage

if TYPE_CHECKING:
    from pathlib import Path


_HASH = "deadbeef" * 8  # 64-hex-char stand-in

REQUIRED_SECTIONS = (
    "## Objective",
    "## Project vision",
    "## Preceding cycles",
    "## Following cycles",
    "## In scope",
    "## Out of scope",
    "## Acceptance criteria",
)


def _briefing_with_required_sections(cycle_id: int) -> str:
    return (
        f"# Cycle {cycle_id} — Foo\n\n"
        f"## Objective\nDeliver cycle {cycle_id}.\n\n"
        f"## Project vision\nThe end product, in one paragraph.\n\n"
        f"## Preceding cycles\nCycle {cycle_id - 1} delivered the prior step.\n\n"
        f"## Following cycles\nCycle {cycle_id + 1} will extend this work.\n\n"
        f"## In scope\nFoo, bar.\n\n"
        f"## Out of scope\nBaz.\n\n"
        f"## Acceptance criteria\n- [ ] one\n"
    )


def _full_section_response(cycles: list[int]) -> RunResult:
    payload = {f"cycle_{cid}": _briefing_with_required_sections(cid) for cid in cycles}
    return RunResult(text=json.dumps(payload), session_id=None, usage=TokenUsage())


def _ok_response(cycles: list[int]) -> RunResult:
    payload = {
        f"cycle_{cid}": f"# Cycle {cid}\n\n## Objective\nDo cycle {cid}.\n" for cid in cycles
    }
    return RunResult(text=json.dumps(payload), session_id=None, usage=TokenUsage())


def _make_state_with_cycles(tmp_path: Path, cycle_ids: list[int]) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    (state_dir / "requirements.md").write_text("# App\n\n## Description\nTest app.\n")
    st = _state.load_state(state_dir / "missing.json")
    st.mode = "multi-cycle"
    st.requirements_hash = _HASH
    st.cycles = [
        _state.CycleState(
            id=cid,
            name=f"Cycle {cid}",
            milestone_number=None,
            milestone_title=f"Cycle {cid} — Foo",
            status="open",
            phase=0,
            issues=[],
            commit_sha=None,
            scope=f"scope-{cid}",
            depends_on=[] if cid == 1 else [cid - 1],
        )
        for cid in cycle_ids
    ]
    _state.save_state(state_dir / "state.json", st)
    return st


class TestCyclesPromptsDir:
    def test_path_under_dot_code_generator(self, tmp_path: Path) -> None:
        path = cycle_prompts.cycles_prompts_dir(tmp_path, "abc123")
        assert path == tmp_path / ".code-generator" / "cycles_prompts" / "abc123"


class TestIsGenerated:
    def test_false_when_dir_missing(self, tmp_path: Path) -> None:
        assert cycle_prompts.is_generated(tmp_path, _HASH, [1, 2]) is False

    def test_false_when_file_missing(self, tmp_path: Path) -> None:
        folder = cycle_prompts.cycles_prompts_dir(tmp_path, _HASH)
        folder.mkdir(parents=True)
        (folder / "cycle_1.md").write_text("x")
        assert cycle_prompts.is_generated(tmp_path, _HASH, [1, 2]) is False

    def test_true_when_every_file_present(self, tmp_path: Path) -> None:
        folder = cycle_prompts.cycles_prompts_dir(tmp_path, _HASH)
        folder.mkdir(parents=True)
        (folder / "cycle_1.md").write_text("a")
        (folder / "cycle_2.md").write_text("b")
        assert cycle_prompts.is_generated(tmp_path, _HASH, [1, 2]) is True

    def test_empty_cycle_ids_returns_true(self, tmp_path: Path) -> None:
        """No cycles to generate → trivially done."""
        folder = cycle_prompts.cycles_prompts_dir(tmp_path, _HASH)
        folder.mkdir(parents=True)
        assert cycle_prompts.is_generated(tmp_path, _HASH, []) is True


class TestLoadCyclePrompt:
    def test_reads_existing_file(self, tmp_path: Path) -> None:
        folder = cycle_prompts.cycles_prompts_dir(tmp_path, _HASH)
        folder.mkdir(parents=True)
        (folder / "cycle_3.md").write_text("# Cycle 3 briefing")
        assert cycle_prompts.load_cycle_prompt(tmp_path, _HASH, 3) == "# Cycle 3 briefing"

    def test_raises_file_not_found(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError):
            cycle_prompts.load_cycle_prompt(tmp_path, _HASH, 7)


class TestGenerateCyclePrompts:
    @pytest.mark.asyncio
    async def test_happy_path_writes_one_file_per_cycle(self, tmp_path: Path) -> None:
        state = _make_state_with_cycles(tmp_path, [1, 2, 3])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _ok_response([1, 2, 3])

        with patch.object(cycle_prompts.rate_limit, "main_loop", side_effect=fake_main_loop):
            await cycle_prompts.generate_cycle_prompts(
                tmp_path,
                state,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        folder = cycle_prompts.cycles_prompts_dir(tmp_path, _HASH)
        for cid in [1, 2, 3]:
            assert (folder / f"cycle_{cid}.md").is_file()
            content = (folder / f"cycle_{cid}.md").read_text()
            assert "## Objective" in content
            assert f"cycle {cid}" in content.lower()

    @pytest.mark.asyncio
    async def test_idempotent_on_second_call(self, tmp_path: Path) -> None:
        state = _make_state_with_cycles(tmp_path, [1, 2])
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _ok_response([1, 2])

        with patch.object(cycle_prompts.rate_limit, "main_loop", side_effect=fake_main_loop):
            await cycle_prompts.generate_cycle_prompts(
                tmp_path,
                state,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )
            await cycle_prompts.generate_cycle_prompts(
                tmp_path,
                state,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 1

    @pytest.mark.asyncio
    async def test_missing_hash_raises(self, tmp_path: Path) -> None:
        state = _make_state_with_cycles(tmp_path, [1])
        state.requirements_hash = None

        with pytest.raises(cycle_prompts.CyclePromptGenerationError, match="requirements_hash"):
            await cycle_prompts.generate_cycle_prompts(
                tmp_path,
                state,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_no_cycles_is_noop(self, tmp_path: Path) -> None:
        state = _make_state_with_cycles(tmp_path, [])
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _ok_response([])

        with patch.object(cycle_prompts.rate_limit, "main_loop", side_effect=fake_main_loop):
            await cycle_prompts.generate_cycle_prompts(
                tmp_path,
                state,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 0

    @pytest.mark.asyncio
    async def test_invalid_json_raises(self, tmp_path: Path) -> None:
        state = _make_state_with_cycles(tmp_path, [1])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return RunResult(text="not json", session_id=None, usage=TokenUsage())

        with (
            patch.object(cycle_prompts.rate_limit, "main_loop", side_effect=fake_main_loop),
            pytest.raises(cycle_prompts.CyclePromptGenerationError),
        ):
            await cycle_prompts.generate_cycle_prompts(
                tmp_path,
                state,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # No partial files should be left behind.
        folder = cycle_prompts.cycles_prompts_dir(tmp_path, _HASH)
        if folder.is_dir():
            assert list(folder.iterdir()) == []

    @pytest.mark.asyncio
    async def test_missing_cycle_key_raises(self, tmp_path: Path) -> None:
        state = _make_state_with_cycles(tmp_path, [1, 2])

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            # Only cycle_1 returned; cycle_2 is missing.
            return RunResult(
                text=json.dumps({"cycle_1": "# one\n"}),
                session_id=None,
                usage=TokenUsage(),
            )

        with (
            patch.object(cycle_prompts.rate_limit, "main_loop", side_effect=fake_main_loop),
            pytest.raises(cycle_prompts.CyclePromptGenerationError, match="cycle_2"),
        ):
            await cycle_prompts.generate_cycle_prompts(
                tmp_path,
                state,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_prompt_includes_requirements_and_cycles(self, tmp_path: Path) -> None:
        state = _make_state_with_cycles(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _ok_response([1])

        with patch.object(cycle_prompts.rate_limit, "main_loop", side_effect=fake_main_loop):
            await cycle_prompts.generate_cycle_prompts(
                tmp_path,
                state,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        # Requirements content is embedded.
        assert "Test app." in captured_prompts[0]
        # Cycle JSON is embedded.
        assert '"id": 1' in captured_prompts[0]
        assert '"name": "Cycle 1"' in captured_prompts[0]


class TestSpecializerSections:
    """Drift guards: specializer output and prompt template must keep
    every required section (vision + neighbor + scope + criteria) so
    Phase 1 receives uniformly structured briefings.
    """

    @pytest.mark.asyncio
    async def test_when_briefings_have_all_sections_emitted_files_contain_them(
        self, tmp_path: Path
    ) -> None:
        cycle_ids = [1, 2, 3]
        state = _make_state_with_cycles(tmp_path, cycle_ids)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _full_section_response(cycle_ids)

        with patch.object(cycle_prompts.rate_limit, "main_loop", side_effect=fake_main_loop):
            await cycle_prompts.generate_cycle_prompts(
                tmp_path,
                state,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        folder = cycle_prompts.cycles_prompts_dir(tmp_path, _HASH)
        for cid in cycle_ids:
            content = (folder / f"cycle_{cid}.md").read_text(encoding="utf-8")
            for heading in REQUIRED_SECTIONS:
                assert heading in content, f"cycle_{cid}.md is missing heading {heading!r}"

    def test_prompt_template_mentions_every_required_section(self) -> None:
        template = (
            importlib.resources.files("code_generator.prompts")
            .joinpath("prompt-cycle-specializer.md")
            .read_text(encoding="utf-8")
        )
        for heading in REQUIRED_SECTIONS:
            assert heading in template, (
                f"prompt-cycle-specializer.md no longer mentions {heading!r}"
            )
