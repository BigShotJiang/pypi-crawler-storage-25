"""Tests for Phase 6.5 progress field on CycleState and State (#269)."""

import json
from pathlib import Path
from typing import cast

from code_generator.state import (
    CycleState,
    IssueState,
    Phase65Progress,
    State,
    load_state,
    save_state,
)


def _make_issue(number: int = 1) -> IssueState:
    return IssueState(number=number, status="open", agent="python-pro")


def _make_cycle(cycle_id: int = 1) -> CycleState:
    return CycleState(
        id=cycle_id,
        name="Cycle 1",
        milestone_number=1,
        milestone_title="Cycle 1 — Phase 6.5",
        status="in_progress",
        phase=65,
        issues=[_make_issue()],
        commit_sha=None,
    )


class TestPhase65ProgressDefaults:
    def test_default_attempt_is_zero(self) -> None:
        """Phase65Progress.attempt defaults to 0."""
        progress = Phase65Progress()
        assert progress.attempt == 0

    def test_default_last_tier_is_none(self) -> None:
        """Phase65Progress.last_tier defaults to None."""
        progress = Phase65Progress()
        assert progress.last_tier is None

    def test_default_tiers_passed_is_empty_list(self) -> None:
        """Phase65Progress.tiers_passed defaults to an empty list."""
        progress = Phase65Progress()
        assert progress.tiers_passed == []

    def test_default_tiers_failed_is_empty_list(self) -> None:
        """Phase65Progress.tiers_failed defaults to an empty list."""
        progress = Phase65Progress()
        assert progress.tiers_failed == []

    def test_default_tiers_skipped_is_empty_list(self) -> None:
        """Phase65Progress.tiers_skipped defaults to an empty list (#281)."""
        progress = Phase65Progress()
        assert progress.tiers_skipped == []

    def test_default_skip_reasons_is_empty_dict(self) -> None:
        """Phase65Progress.skip_reasons defaults to an empty dict (#281)."""
        progress = Phase65Progress()
        assert progress.skip_reasons == {}

    def test_default_factory_isolation(self) -> None:
        """Default factories yield independent list instances per dataclass."""
        a = Phase65Progress()
        b = Phase65Progress()
        a.tiers_passed.append("T0")
        a.tiers_failed.append("T2")
        assert b.tiers_passed == []
        assert b.tiers_failed == []


class TestCycleStatePhase65Field:
    def test_default_value_is_none(self) -> None:
        """CycleState.phase6_5 defaults to None when not provided."""
        cycle = _make_cycle()
        assert cycle.phase6_5 is None

    def test_state_default_value_is_none(self) -> None:
        """State.phase6_5 defaults to None when not provided."""
        state = State(
            mode="single",
            started_at="2026-05-15T00:00:00Z",
            updated_at="2026-05-15T00:00:00Z",
        )
        assert state.phase6_5 is None


class TestPhase65RoundTrip:
    def test_cycle_round_trip_preserves_phase65(self, tmp_path: Path) -> None:
        """save_state then load_state preserves CycleState.phase6_5 contents."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.phase6_5 = Phase65Progress(
            attempt=2,
            last_tier="T2",
            tiers_passed=["T0", "T1"],
            tiers_failed=["T2"],
        )
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        reloaded = cast("CycleState", loaded.cycles[0]).phase6_5
        assert reloaded is not None
        assert reloaded.attempt == 2
        assert reloaded.last_tier == "T2"
        assert reloaded.tiers_passed == ["T0", "T1"]
        assert reloaded.tiers_failed == ["T2"]

    def test_single_mode_round_trip_preserves_phase65(self, tmp_path: Path) -> None:
        """save_state then load_state preserves State.phase6_5 contents."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.phase6_5 = Phase65Progress(
            attempt=1,
            last_tier="T1",
            tiers_passed=["T0"],
            tiers_failed=["T1"],
        )

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.phase6_5 is not None
        assert loaded.phase6_5.attempt == 1
        assert loaded.phase6_5.last_tier == "T1"
        assert loaded.phase6_5.tiers_passed == ["T0"]
        assert loaded.phase6_5.tiers_failed == ["T1"]

    def test_none_value_round_trips_as_none(self, tmp_path: Path) -> None:
        """A None phase6_5 value survives the round trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        state.cycles = [_make_cycle()]

        save_state(path, state)
        loaded = load_state(path)

        assert cast("CycleState", loaded.cycles[0]).phase6_5 is None
        assert loaded.phase6_5 is None


class TestPhase65BackwardCompat:
    def test_legacy_state_without_phase65_loads_to_none(self, tmp_path: Path) -> None:
        """A pre-#269 state.json without phase6_5 must deserialize cleanly."""
        path = tmp_path / "state.json"
        legacy = {
            "mode": "single",
            "started_at": "2026-05-01T00:00:00Z",
            "updated_at": "2026-05-01T00:00:00Z",
            "session_mode": "shared",
        }
        path.write_text(json.dumps(legacy), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.phase6_5 is None

    def test_when_legacy_phase65_dict_then_tiers_skipped_defaults_empty(
        self, tmp_path: Path
    ) -> None:
        """A pre-#281 phase6_5 dict without tiers_skipped/skip_reasons defaults cleanly."""
        path = tmp_path / "state.json"
        legacy = {
            "mode": "single",
            "started_at": "2026-05-01T00:00:00Z",
            "updated_at": "2026-05-01T00:00:00Z",
            "session_mode": "shared",
            "phase6_5": {
                "attempt": 1,
                "last_tier": "T2",
                "tiers_passed": ["T0", "T1"],
                "tiers_failed": [],
            },
        }
        path.write_text(json.dumps(legacy), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.phase6_5 is not None
        assert loaded.phase6_5.tiers_skipped == []
        assert loaded.phase6_5.skip_reasons == {}

    def test_legacy_cycle_without_phase65_loads_to_none(self, tmp_path: Path) -> None:
        """A pre-#269 nested cycle without phase6_5 deserializes to None."""
        path = tmp_path / "state.json"
        legacy = {
            "mode": "multi-cycle",
            "started_at": "2026-05-01T00:00:00Z",
            "updated_at": "2026-05-01T00:00:00Z",
            "session_mode": "shared",
            "cycles": [
                {
                    "id": 1,
                    "name": "Cycle 1",
                    "milestone_number": 1,
                    "milestone_title": "Cycle 1",
                    "status": "in_progress",
                    "phase": 6,
                    "issues": [],
                    "commit_sha": None,
                }
            ],
        }
        path.write_text(json.dumps(legacy), encoding="utf-8")

        loaded = load_state(path)

        cycle = cast("CycleState", loaded.cycles[0])
        assert cycle.phase6_5 is None

    def test_partial_phase65_dict_fills_defaults(self, tmp_path: Path) -> None:
        """A phase6_5 dict missing keys deserializes with field defaults."""
        path = tmp_path / "state.json"
        legacy = {
            "mode": "single",
            "started_at": "2026-05-01T00:00:00Z",
            "updated_at": "2026-05-01T00:00:00Z",
            "session_mode": "shared",
            "phase6_5": {"attempt": 3},
        }
        path.write_text(json.dumps(legacy), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.phase6_5 is not None
        assert loaded.phase6_5.attempt == 3
        assert loaded.phase6_5.last_tier is None
        assert loaded.phase6_5.tiers_passed == []
        assert loaded.phase6_5.tiers_failed == []
