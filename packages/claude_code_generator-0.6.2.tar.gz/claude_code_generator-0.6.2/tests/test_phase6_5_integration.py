"""Cycle 1 acceptance-criteria integration tests for Phase 6.5 (#278).

These tests exercise the contract guarantees that span modules: hard commit
gate, retry counter bound, ``feature_done`` invariant, resume routing, repair
recovery, and atomic checklist writes. Module unit tests live elsewhere; this
suite is the regression net for cross-module invariants.
"""

from __future__ import annotations

import logging
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import checklist as _checklist
from code_generator import state as _state
from code_generator.checklist import ChecklistEntry
from code_generator.commands._resume import next_start_phase
from code_generator.orchestrator import cycle_loop, phase6_5_verify
from code_generator.orchestrator.phase6_5_verify import (
    TierResult,
    VerificationFailed,
)


def _logger() -> logging.Logger:
    return logging.getLogger("test.phase6_5_integration")


def _passed(tier_id: str) -> TierResult:
    return TierResult(
        tier_id=tier_id,
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=0,
        stderr_tail=None,
        failing_detail=None,
    )


def _failed(tier_id: str, detail: str = "fail") -> TierResult:
    return TierResult(
        tier_id=tier_id,
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=1,
        stderr_tail="tail",
        failing_detail=detail,
    )


@pytest.fixture
def state_path(tmp_path: Path) -> Path:
    return tmp_path / ".code-generator" / "state.json"


@pytest.fixture
def state_with_closed_issues(tmp_path: Path, state_path: Path) -> _state.State:
    st = _state.load_state(state_path)
    st.mode = "single"
    st.requirements_hash = "abcd1234"
    st.issues = [
        _state.IssueState(number=n, status="closed", agent="python-pro", title=f"Issue {n}")
        for n in (1, 2)
    ]
    _state.save_state(state_path, st)
    return st


def _seed_checklist(tmp_path: Path, requirements_hash: str, numbers: list[int]) -> Path:
    path = tmp_path / ".code-generator" / "checklists" / f"{requirements_hash}.json"
    issues = [
        _state.IssueState(number=n, status="open", agent="python-pro", title=f"#{n}")
        for n in numbers
    ]
    _checklist.seed(path, issues)
    return path


# ---------------------------------------------------------------------------
# (1) Hard commit gate — Phase 6.5 VerificationFailed ⇒ Phase 7 never runs
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_verification_failed_blocks_phase7_in_cycle_loop(
    tmp_path: Path, state_with_closed_issues: _state.State
) -> None:
    """`_run_phases` re-raises VerificationFailed; phase7_commit.run is never invoked."""
    state_with_closed_issues.phase = 6  # simulate Phase 6 just completed

    p65 = AsyncMock(side_effect=VerificationFailed("hard gate"))
    p7 = AsyncMock()

    with (
        patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
        patch.object(cycle_loop.phase6_5_verify, "run", p65),
        patch.object(cycle_loop.phase7_commit, "run", p7),
        patch.object(cycle_loop.phase8_finalization, "run", AsyncMock()),
        patch.object(cycle_loop, "setup_phase_logger", return_value=_logger()),
        pytest.raises(VerificationFailed, match="hard gate"),
    ):
        await cycle_loop.run_single_mode(
            state_with_closed_issues,
            tmp_path,
            runner_module=MagicMock(),
            logger=_logger(),
            start_phase=6,
            session_mode="shared",
        )

    p7.assert_not_called()


# ---------------------------------------------------------------------------
# (2) Retry counter bound — max_retries=3 ⇒ exactly 3 repair calls then raise
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_retry_counter_bound_exactly_max_retries_repair_attempts(
    tmp_path: Path,
    state_with_closed_issues: _state.State,
    state_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _seed_checklist(tmp_path, "abcd1234", [1, 2])

    # Distinct failing_detail per attempt so the deviation detector's
    # stuck_tier check does not fire and abort the retry budget early (#291).
    t0_calls = {"n": 0}

    def _t0_unique_fail(*_a: object, **_kw: object) -> TierResult:
        t0_calls["n"] += 1
        return _failed("T0", detail=f"fail-{t0_calls['n']}")

    monkeypatch.setattr(phase6_5_verify, "run_t0_build", _t0_unique_fail)
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _passed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))

    repair = AsyncMock()
    monkeypatch.setattr(phase6_5_verify, "_run_repair_pass", repair)

    with pytest.raises(VerificationFailed):
        await phase6_5_verify.run(
            state_with_closed_issues,
            None,
            tmp_path,
            state_path,
            runner_module=MagicMock(),
            logger=_logger(),
            shared_client=MagicMock(),
            max_retries=3,
        )

    assert repair.await_count == 3


# ---------------------------------------------------------------------------
# (2b) Deviation detector — stuck_tier aborts before retry budget exhausts (#291)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_stuck_tier_signature_repeats_then_run_aborts_with_deviation(
    tmp_path: Path,
    state_with_closed_issues: _state.State,
    state_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _seed_checklist(tmp_path, "abcd1234", [1, 2])

    # Identical failing_detail across attempts trips DeviationDetector.stuck_tier
    # at attempt 3 — repair pass should be invoked twice, then run raises before
    # the third pass (early-abort under the bounded-repair contract).
    monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: _failed("T0", "boom"))
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _passed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))

    repair = AsyncMock()
    monkeypatch.setattr(phase6_5_verify, "_run_repair_pass", repair)

    with pytest.raises(VerificationFailed, match="deviation"):
        await phase6_5_verify.run(
            state_with_closed_issues,
            None,
            tmp_path,
            state_path,
            runner_module=MagicMock(),
            logger=_logger(),
            shared_client=MagicMock(),
            max_retries=5,
        )

    assert repair.await_count == 2


# ---------------------------------------------------------------------------
# (3) feature_done invariant — three-flag gate
# ---------------------------------------------------------------------------


class TestFeatureDoneInvariant:
    def test_feature_done_false_when_runtime_verified_false(self) -> None:
        entry = ChecklistEntry(
            issue_number=1,
            title="x",
            tests_passed=True,
            runtime_verified=False,
            committed=True,
        )
        entry.recompute_feature_done()
        assert entry.feature_done is False

    def test_feature_done_true_only_when_all_four_flags_true(self) -> None:
        entry = ChecklistEntry(
            issue_number=1,
            title="x",
            tests_passed=True,
            runtime_verified=False,
            committed=True,
            professionalized=True,
        )
        entry.runtime_verified = True
        entry.recompute_feature_done()
        assert entry.feature_done is True

    def test_feature_done_false_when_committed_false(self) -> None:
        entry = ChecklistEntry(
            issue_number=1,
            title="x",
            tests_passed=True,
            runtime_verified=True,
            committed=False,
        )
        entry.recompute_feature_done()
        assert entry.feature_done is False


# ---------------------------------------------------------------------------
# (4) Resume mid-6.5 — after Phase 6, next_start_phase routes into Phase 6.5
# ---------------------------------------------------------------------------


def test_resume_after_phase6_routes_into_phase6_5_guard(state_path: Path) -> None:
    """state.phase=6 (Phase 6 done) → next_start_phase=7; the Phase 6.5 guard
    in cycle_loop runs only when start_phase <= _PHASE_VERIFY and the recorded
    phase is _PHASE_TEST (6) — so the resume routes through Phase 6.5, not
    Phase 7, and not back into Phase 5."""
    st = _state.load_state(state_path)
    st.phase = 6
    _state.save_state(state_path, st)

    next_phase = next_start_phase(st)

    assert next_phase == 7  # advances to 7; Phase 6.5 guard catches it via current_phase==6
    assert next_phase <= cycle_loop._PHASE_VERIFY
    assert st.phase == cycle_loop._PHASE_TEST  # current_phase==_PHASE_TEST → 6.5 fires


# ---------------------------------------------------------------------------
# (5) Injected runtime fault — repair pass adds missing dep; second T0 passes
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_injected_runtime_fault_recovers_via_repair_pass(
    tmp_path: Path,
    state_with_closed_issues: _state.State,
    state_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """First T0 fails with ModuleNotFoundError; mocked repair adds dep; second T0 passes.

    Mirrors the real fixture under ``tests/fixtures/phase6_5_missing_dep/`` — we
    materialise it inline to avoid file-system clutter.
    """
    project = tmp_path
    (project / "pyproject.toml").write_text(
        '[project]\nname = "sample"\nversion = "0.0.0"\n', encoding="utf-8"
    )
    (project / "app.py").write_text("import httpx\nprint(httpx.__version__)\n", encoding="utf-8")
    checklist_path = _seed_checklist(tmp_path, "abcd1234", [1, 2])

    fault_then_pass: list[TierResult] = [
        TierResult(
            tier_id="T0",
            passed=False,
            skipped=False,
            skip_reason=None,
            exit_code=1,
            stderr_tail="ModuleNotFoundError: No module named 'httpx'",
            failing_detail="import httpx failed",
        ),
        _passed("T0"),
    ]
    t0_iter = iter(fault_then_pass)
    monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: next(t0_iter))
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _passed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))

    repair = AsyncMock()
    monkeypatch.setattr(phase6_5_verify, "_run_repair_pass", repair)

    await phase6_5_verify.run(
        state_with_closed_issues,
        None,
        project,
        state_path,
        runner_module=MagicMock(),
        logger=_logger(),
        shared_client=MagicMock(),
        max_retries=3,
    )

    assert repair.await_count == 1
    entries = {e.issue_number: e for e in _checklist.load(checklist_path)}
    assert entries[1].runtime_verified is True
    assert entries[2].runtime_verified is True


# ---------------------------------------------------------------------------
# (6) Atomic checklist write under failure — no partial runtime_verified ticks
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_atomic_checklist_no_partial_ticks_on_failure(
    tmp_path: Path,
    state_with_closed_issues: _state.State,
    state_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    checklist_path = _seed_checklist(tmp_path, "abcd1234", [1, 2])

    monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: _passed("T0"))
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _failed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))
    monkeypatch.setattr(phase6_5_verify, "_run_repair_pass", AsyncMock())

    with pytest.raises(VerificationFailed):
        await phase6_5_verify.run(
            state_with_closed_issues,
            None,
            tmp_path,
            state_path,
            runner_module=MagicMock(),
            logger=_logger(),
            shared_client=MagicMock(),
            max_retries=2,
        )

    entries = _checklist.load(checklist_path)
    for entry in entries:
        assert entry.runtime_verified is False
        assert entry.feature_done is False
