"""Tests for DeviationDetector — bounded repair-loop overseer (#291)."""

from __future__ import annotations

from dataclasses import FrozenInstanceError
from pathlib import Path

import pytest

from code_generator.orchestrator.deviation_detector import (
    DeviationDetector,
    DeviationEvent,
)


def test_when_no_samples_recorded_then_check_returns_none():
    detector = DeviationDetector()
    assert detector.check() is None


def test_when_two_identical_failures_recorded_then_below_threshold_returns_none():
    detector = DeviationDetector()
    detector.record("T1", passed=False, failing_detail="boot timeout")
    detector.record("T1", passed=False, failing_detail="boot timeout")
    assert detector.check() is None


def test_when_three_identical_signature_failures_then_stuck_tier_event():
    detector = DeviationDetector()
    for _ in range(3):
        detector.record("T1", passed=False, failing_detail="boot timeout")

    event = detector.check()

    assert event is not None
    assert event.kind == "stuck_tier"
    assert "T1" in event.detail
    assert "boot timeout" in event.detail


def test_when_failing_details_differ_then_no_stuck_tier_event():
    detector = DeviationDetector()
    detector.record("T1", passed=False, failing_detail="port 8000 not listening")
    detector.record("T1", passed=False, failing_detail="health 500")
    detector.record("T1", passed=False, failing_detail="exit before boot window")
    assert detector.check() is None


def test_when_failing_tier_ids_differ_then_no_stuck_tier_event():
    detector = DeviationDetector()
    detector.record("T0", passed=False, failing_detail="install failed")
    detector.record("T1", passed=False, failing_detail="install failed")
    detector.record("T2", passed=False, failing_detail="install failed")
    assert detector.check() is None


def test_when_stuck_limit_overridden_then_smaller_threshold_fires():
    detector = DeviationDetector(stuck_limit=2)
    detector.record("T0", passed=False, failing_detail="install failed")
    detector.record("T0", passed=False, failing_detail="install failed")

    event = detector.check()

    assert event is not None
    assert event.kind == "stuck_tier"


def test_when_alternating_pass_fail_for_same_tier_then_oscillation_event():
    detector = DeviationDetector()
    for passed in (True, False, True, False):
        detector.record("T1", passed=passed, failing_detail=None if passed else "fail")

    event = detector.check()

    assert event is not None
    assert event.kind == "oscillation"
    assert "T1" in event.detail


def test_when_alternating_fail_pass_for_same_tier_then_oscillation_event():
    detector = DeviationDetector()
    for passed in (False, True, False, True):
        detector.record("T1", passed=passed, failing_detail=None if passed else "fail")

    event = detector.check()

    assert event is not None
    assert event.kind == "oscillation"


def test_when_only_three_samples_for_tier_then_no_oscillation():
    detector = DeviationDetector()
    for passed in (True, False, True):
        detector.record("T1", passed=passed, failing_detail=None if passed else "fail")
    assert detector.check() is None


def test_when_pass_fail_pattern_across_different_tiers_then_no_oscillation():
    detector = DeviationDetector()
    detector.record("T0", passed=True, failing_detail=None)
    detector.record("T1", passed=False, failing_detail="boom")
    detector.record("T0", passed=True, failing_detail=None)
    detector.record("T1", passed=False, failing_detail="boom")
    assert detector.check() is None


def test_when_edited_path_outside_target_then_context_drift_event(tmp_path: Path):
    detector = DeviationDetector()
    target = tmp_path / "app"
    target.mkdir()
    outside = tmp_path / "elsewhere.py"
    outside.write_text("x")

    detector.record_drift([target / "main.py", outside], target)

    event = detector.check()
    assert event is not None
    assert event.kind == "context_drift"
    assert str(outside) in event.detail


def test_when_all_edited_paths_inside_target_then_no_drift_event(tmp_path: Path):
    detector = DeviationDetector()
    target = tmp_path / "app"
    target.mkdir()
    (target / "sub").mkdir()

    detector.record_drift([target / "main.py", target / "sub" / "x.py"], target)

    assert detector.check() is None


def test_when_drift_recorded_then_takes_precedence_over_stuck_tier(tmp_path: Path):
    detector = DeviationDetector()
    target = tmp_path / "app"
    target.mkdir()
    outside = tmp_path / "elsewhere.py"

    detector.record_drift([outside], target)
    for _ in range(3):
        detector.record("T1", passed=False, failing_detail="boot timeout")

    event = detector.check()
    assert event is not None
    assert event.kind == "context_drift"


def test_when_passing_samples_interleaved_then_no_stuck_tier():
    detector = DeviationDetector()
    detector.record("T1", passed=False, failing_detail="x")
    detector.record("T1", passed=True, failing_detail=None)
    detector.record("T1", passed=False, failing_detail="x")
    detector.record("T1", passed=False, failing_detail="x")
    assert detector.check() is None


def test_when_event_constructed_then_frozen_dataclass():
    event = DeviationEvent(kind="oscillation", detail="x")
    with pytest.raises(FrozenInstanceError):
        event.kind = "stuck_tier"  # type: ignore[misc]
