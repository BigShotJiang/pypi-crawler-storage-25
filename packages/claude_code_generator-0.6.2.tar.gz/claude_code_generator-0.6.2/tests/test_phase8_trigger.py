"""Phase 8 trigger-point tests (#327).

Verifies the firing rules for ``phase8_finalization.run``:

- Single-mode: fires exactly once, after ``phase7_commit.run``.
- Multi-cycle: fires exactly once after the cycle loop, on the root ``state``
  (never inside ``_run_cycle_phases``).
- Always fires before ``archive_completed_run`` in ``dispatch_async``.
- ``--continue`` resumes are idempotent: when ``state.phase8.status == "ok"``
  multi-cycle skips re-firing.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import cycle_loop, phase5_closure
from tests.integration._helpers import make_3_cycle_fixture


def _logger() -> logging.Logger:
    return logging.getLogger("test.phase8_trigger")


def _stamp_ok(state: _state.State, cycle: _state.CycleState | None) -> None:
    target = cycle if cycle is not None else state
    target.phase8 = _state.Phase8Progress(
        attempt=1,
        status="ok",
        started_at="2026-01-01T00:00:00Z",
        finished_at="2026-01-01T00:00:01Z",
    )


def _make_single_state(tmp_path: Path) -> _state.State:
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    st = _state.State(
        mode="single",
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        session_mode="fresh",
    )
    _state.save_state(cg / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# Single-mode
# ---------------------------------------------------------------------------


class TestSingleModeTrigger:
    @pytest.mark.asyncio
    async def test_single_mode_phase8_fires_after_phase7(self, tmp_path: Path) -> None:
        st = _make_single_state(tmp_path)
        order: list[str] = []

        async def p8(state, cycle, *_a, **_kw):
            order.append("phase8")
            _stamp_ok(state, cycle)

        with (
            patch.object(
                cycle_loop.phase7_commit,
                "run",
                AsyncMock(side_effect=lambda *a, **k: order.append("phase7") or "subject"),
            ),
            patch.object(cycle_loop.phase8_finalization, "run", p8),
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_logger()
            )

        assert order == ["phase7", "phase8"]

    @pytest.mark.asyncio
    async def test_single_mode_phase8_fires_only_once_on_clean_run(self, tmp_path: Path) -> None:
        st = _make_single_state(tmp_path)
        spy = AsyncMock(side_effect=lambda state, cycle, *a, **k: _stamp_ok(state, cycle))

        with (
            patch.object(cycle_loop.phase8_finalization, "run", spy),
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure, "run", AsyncMock(return_value=phase5_closure.FixResult())
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock(return_value="x")),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_logger()),
        ):
            await cycle_loop.run_single_mode(
                st, tmp_path, runner_module=MagicMock(), logger=_logger()
            )

        assert spy.await_count == 1


# ---------------------------------------------------------------------------
# Multi-cycle
# ---------------------------------------------------------------------------


class TestMultiCycleTrigger:
    @pytest.mark.asyncio
    async def test_multi_cycle_phase8_fires_once_post_loop_not_per_cycle(
        self, tmp_path: Path
    ) -> None:
        project_dir = make_3_cycle_fixture(tmp_path)
        st = _state.load_state(project_dir / ".code-generator" / "state.json")

        spy = AsyncMock(side_effect=lambda state, cycle, *a, **k: _stamp_ok(state, cycle))

        with (
            patch.object(cycle_loop.phase8_finalization, "run", spy),
            patch.object(cycle_loop, "_run_phases", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_logger()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop.gh, "close_issue"),
        ):
            await cycle_loop.run_multi_cycle(
                st, project_dir, runner_module=MagicMock(), logger=_logger()
            )

        assert spy.await_count == 1
        # cycle=None confirms post-loop invocation on root state.
        assert spy.await_args.args[1] is None

    @pytest.mark.asyncio
    async def test_multi_cycle_phase8_never_fires_inside_cycle(self, tmp_path: Path) -> None:
        """``_run_phases`` is invoked per cycle; none of those calls fires Phase 8."""
        project_dir = make_3_cycle_fixture(tmp_path)
        st = _state.load_state(project_dir / ".code-generator" / "state.json")

        phase8_invocations: list[Any] = []

        async def p8(state, cycle, *_a, **_kw):
            phase8_invocations.append(cycle)
            _stamp_ok(state, cycle)

        async def fake_run_phases(state, cycle, *_a, **_kw):
            # Mark cycle "completed" so the multi-cycle loop progresses.
            if cycle is not None:
                cycle.status = "completed"

        with (
            patch.object(cycle_loop.phase8_finalization, "run", p8),
            patch.object(cycle_loop, "_run_phases", fake_run_phases),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_logger()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop.gh, "close_issue"),
        ):
            await cycle_loop.run_multi_cycle(
                st, project_dir, runner_module=MagicMock(), logger=_logger()
            )

        # Phase 8 called exactly once, never with a cycle argument.
        assert len(phase8_invocations) == 1
        assert phase8_invocations[0] is None

    @pytest.mark.asyncio
    async def test_when_phase8_already_ok_multi_cycle_skip(self, tmp_path: Path) -> None:
        project_dir = make_3_cycle_fixture(tmp_path)
        st = _state.load_state(project_dir / ".code-generator" / "state.json")
        st.phase8 = _state.Phase8Progress(
            attempt=1,
            status="ok",
            started_at="2026-01-01T00:00:00Z",
            finished_at="2026-01-01T00:00:01Z",
        )
        for c in st.cycles:
            if isinstance(c, _state.CycleState):
                c.status = "completed"

        spy = AsyncMock()

        with (
            patch.object(cycle_loop.phase8_finalization, "run", spy),
            patch.object(cycle_loop, "_run_phases", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_logger()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop.gh, "close_issue"),
        ):
            await cycle_loop.run_multi_cycle(
                st, project_dir, runner_module=MagicMock(), logger=_logger()
            )

        spy.assert_not_called()


# ---------------------------------------------------------------------------
# Archive ordering — dispatch_async
# ---------------------------------------------------------------------------


class TestArchiveOrdering:
    @pytest.mark.asyncio
    async def test_phase8_fires_before_archive_step(self, tmp_path: Path) -> None:
        """In ``dispatch_async`` order: ``run_single_mode`` (firing Phase 8) → archive."""
        from code_generator.commands import _dispatch

        project_dir = tmp_path
        cg = project_dir / ".code-generator"
        cg.mkdir(parents=True)
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            session_mode="fresh",
        )
        _state.save_state(cg / "state.json", st)

        order: list[str] = []

        async def fake_run_single(state, *_a, **_kw):
            order.append("phase8")
            _stamp_ok(state, None)

        def fake_archive(*_a: Any, **_kw: Any) -> None:
            order.append("archive")

        with (
            patch.object(cycle_loop, "run_single_mode", fake_run_single),
            patch("code_generator.archive_run.archive_completed_run", fake_archive),
            patch("code_generator.commands._dispatch._compute_and_persist_graph_report"),
        ):
            await _dispatch.dispatch_async(
                st,
                project_dir,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="single",
                session_mode="fresh",
            )

        assert order == ["phase8", "archive"]
