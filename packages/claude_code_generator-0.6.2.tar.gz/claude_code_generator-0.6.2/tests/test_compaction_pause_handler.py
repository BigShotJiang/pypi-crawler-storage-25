"""Tests for the single-roundtrip pause_after_compaction handler (issue #236).

Covers four invariants:

1. SDK pause-after-compaction signal flips the handler to *pending*.
2. The pending flag prepends the boundary user-message to the next outgoing
   prompt — exactly once, no separate ``client.query()`` (single roundtrip).
3. Older SDKs that do not emit the signal are a no-op (predicate returns
   False; handler stays not-pending).
4. A rate-limit event arriving on the same message takes priority over the
   pause signal — the rate-limit handler runs first and raises
   ``RateLimitHit``; the pause handler is never marked pending.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import pytest

from code_generator.runner.compaction_pause import CompactionPauseHandler
from code_generator.runner.message_parsing import is_compaction_pause_event
from code_generator.runner.sdk_runner import run_with_shared_client
from code_generator.runner.types import RateLimitHit

# ---------------------------------------------------------------------------
# Fakes
# ---------------------------------------------------------------------------


class _FakePauseEvent:
    """Mimics an SDK message carrying ``pause_after_compaction=True``."""

    def __init__(self) -> None:
        self.pause_after_compaction = True
        self.freed_tokens = 12_000
        self.type = "compact_20260112"


class _FakePausedFlagEvent:
    """Mimics an SDK message carrying the alternative ``paused=True`` flag."""

    def __init__(self) -> None:
        self.paused = True


class _FakeAssistantMessage:
    """Minimal duck-typed AssistantMessage (single text block)."""

    def __init__(self, text: str = "ok") -> None:
        self.content = [type("TextBlock", (), {"text": text})()]


class _FakeResultMessage:
    """Minimal duck-typed ResultMessage with usage."""

    def __init__(self) -> None:
        self.session_id = "sid-1"
        self.usage = {"input_tokens": 10, "output_tokens": 1}
        self.is_error = False
        self.subtype = "success"
        self.stop_reason = "end_turn"


class _FakeRateLimitEvent:
    """Duck-typed rate-limit event with no info — exercises the early-return path."""

    def __init__(self) -> None:
        # rate_limit_info absent → handle_rate_limit_event logs warning, returns.
        # That's still enough to assert "rate-limit branch fired before pause".
        self.rate_limit_info = None


class _RecordingClient:
    """Shared-client stand-in that counts query() calls and replays a script."""

    def __init__(self, script: list[object]) -> None:
        self.script = script
        self.queries: list[str] = []

    async def query(self, prompt: str) -> None:
        self.queries.append(prompt)

    async def receive_messages(self):
        for msg in self.script:
            yield msg


# ---------------------------------------------------------------------------
# Predicate — is_compaction_pause_event
# ---------------------------------------------------------------------------


class TestIsCompactionPauseEvent:
    def test_returns_true_when_pause_after_compaction_field_set(self) -> None:
        """A message with pause_after_compaction=True is a compaction-pause event."""
        assert is_compaction_pause_event(_FakePauseEvent()) is True

    def test_returns_true_when_paused_field_set(self) -> None:
        """A message with paused=True is also a compaction-pause event (alt SDK shape)."""
        assert is_compaction_pause_event(_FakePausedFlagEvent()) is True

    def test_returns_false_for_plain_assistant_message(self) -> None:
        """A regular assistant message is not a compaction-pause event."""
        assert is_compaction_pause_event(_FakeAssistantMessage("hello")) is False

    def test_returns_false_for_result_message(self) -> None:
        """A terminal ResultMessage is never a pause event (early return guard)."""
        assert is_compaction_pause_event(_FakeResultMessage()) is False

    def test_no_op_for_unsupported_sdk_message(self) -> None:
        """A bare object without pause flags returns False (older-SDK no-op path)."""

        class _Bare:
            pass

        assert is_compaction_pause_event(_Bare()) is False


# ---------------------------------------------------------------------------
# Handler — CompactionPauseHandler
# ---------------------------------------------------------------------------


class TestCompactionPauseHandler:
    def test_starts_not_pending(self) -> None:
        assert CompactionPauseHandler().is_pending() is False

    def test_mark_pending_flips_flag(self) -> None:
        h = CompactionPauseHandler()
        h.mark_pending()
        assert h.is_pending() is True

    def test_consume_returns_prompt_unchanged_when_not_pending(self) -> None:
        """When no pause is pending, consume() returns the prompt verbatim."""
        h = CompactionPauseHandler()
        assert h.consume("hello", issue_number=2) == "hello"

    def test_consume_prepends_boundary_when_pending(self) -> None:
        """Pending pause → consume() prepends the §6 boundary user-message."""
        h = CompactionPauseHandler()
        h.mark_pending()
        result = h.consume("Implement issue #2.", issue_number=2)
        assert result.startswith("Context reset. Starting issue #2 fresh.")
        assert (
            "All prior tool results and conversational context from issue #1 are discarded."
            in result
        )
        assert result.endswith("Implement issue #2.")

    def test_consume_clears_pending_flag_after_one_call(self) -> None:
        """consume() clears the flag — single-roundtrip, never two boundaries in a row."""
        h = CompactionPauseHandler()
        h.mark_pending()
        h.consume("x", issue_number=2)
        assert h.is_pending() is False

    def test_consume_twice_does_not_double_prepend(self) -> None:
        """Successive consume() calls without a fresh mark_pending stay verbatim."""
        h = CompactionPauseHandler()
        h.mark_pending()
        first = h.consume("x", issue_number=2)
        second = h.consume("x", issue_number=2)
        assert first != second  # first carries boundary, second does not
        assert second == "x"

    def test_handler_reuses_soft_reset_boundary_template(self) -> None:
        """Boundary text is sourced from runner.soft_reset to avoid duplication (#236 reuse rule)."""
        from code_generator.runner.soft_reset import format_boundary

        h = CompactionPauseHandler()
        h.mark_pending()
        result = h.consume("PROMPT", issue_number=5)
        assert result == format_boundary(5) + "PROMPT"


# ---------------------------------------------------------------------------
# Drain integration — single-roundtrip semantics
# ---------------------------------------------------------------------------


class TestRunWithSharedClientPauseHandling:
    """End-to-end: pause event in the message stream → handler marked, single roundtrip."""

    @pytest.mark.asyncio
    async def test_pause_event_marks_handler_pending_and_no_extra_query(
        self, tmp_path: Path
    ) -> None:
        """A pause event in the stream marks the handler pending; no extra client.query()."""
        client = _RecordingClient(
            script=[_FakePauseEvent(), _FakeAssistantMessage("done"), _FakeResultMessage()]
        )
        handler = CompactionPauseHandler()

        await run_with_shared_client(
            client,
            "Implement issue #2.",
            _make_minimal_options(),
            logger=logging.getLogger("test"),
            state_path=tmp_path / "state.json",
            pause_handler=handler,
        )

        assert handler.is_pending() is True
        # Single-roundtrip: exactly one outgoing query for this run.
        assert len(client.queries) == 1

    @pytest.mark.asyncio
    async def test_next_call_consumes_boundary_prefix_into_outgoing_prompt(
        self, tmp_path: Path
    ) -> None:
        """After a pause was observed, the next run_with_shared_client call prepends the boundary."""
        client = _RecordingClient(
            script=[_FakePauseEvent(), _FakeAssistantMessage("done"), _FakeResultMessage()]
        )
        handler = CompactionPauseHandler()

        # First call observes the pause.
        await run_with_shared_client(
            client,
            "Implement issue #2.",
            _make_minimal_options(),
            logger=logging.getLogger("test"),
            state_path=tmp_path / "state.json",
            pause_handler=handler,
        )

        # Second call: client receives a boundary-prefixed prompt for issue #3.
        client.script = [_FakeAssistantMessage("ok"), _FakeResultMessage()]
        await run_with_shared_client(
            client,
            "Implement issue #3.",
            _make_minimal_options(),
            logger=logging.getLogger("test"),
            state_path=tmp_path / "state.json",
            pause_handler=handler,
            issue_number=3,
        )

        assert client.queries[1].startswith("Context reset. Starting issue #3 fresh.")
        assert client.queries[1].endswith("Implement issue #3.")
        # Pending flag cleared after consume.
        assert handler.is_pending() is False

    @pytest.mark.asyncio
    async def test_pause_event_does_not_raise(self, tmp_path: Path) -> None:
        """Pause event must not bubble as an exception — silent state transition only."""
        client = _RecordingClient(
            script=[_FakePauseEvent(), _FakeAssistantMessage("done"), _FakeResultMessage()]
        )
        handler = CompactionPauseHandler()

        # Should not raise — the pause is a normal mid-stream signal.
        await run_with_shared_client(
            client,
            "x",
            _make_minimal_options(),
            logger=logging.getLogger("test"),
            state_path=tmp_path / "state.json",
            pause_handler=handler,
        )

    @pytest.mark.asyncio
    async def test_no_op_when_handler_is_none(self, tmp_path: Path) -> None:
        """When no handler is plumbed, a pause event is silently ignored — older-SDK fallback path."""
        client = _RecordingClient(
            script=[_FakePauseEvent(), _FakeAssistantMessage("done"), _FakeResultMessage()]
        )

        # No pause_handler kwarg → no-op path; the run still completes normally.
        await run_with_shared_client(
            client,
            "x",
            _make_minimal_options(),
            logger=logging.getLogger("test"),
            state_path=tmp_path / "state.json",
        )

        assert len(client.queries) == 1


# ---------------------------------------------------------------------------
# Rate-limit ordering: rate-limit takes priority over pause
# ---------------------------------------------------------------------------


class TestRateLimitTakesPriorityOverPause:
    @pytest.mark.asyncio
    async def test_rate_limit_event_raises_before_pause_marks_handler(self, tmp_path: Path) -> None:
        """A rate-limit event arriving before a pause event must propagate before pause is marked."""
        # Hit a real rate-limit branch by emitting a RateLimitEvent first; the
        # pause event after it must never be reached because the rate-limit
        # handler raises (or, with rate_limit_info=None, just logs and returns —
        # in that benign case the pause does still mark, which is correct).
        from code_generator.runner.message_parsing import handle_rate_limit_event

        # Surrogate test: directly invoke the rate-limit handler with an info
        # block that signals "rejected" overage state to ensure RateLimitHit
        # propagates synchronously.
        class _RejectedRateLimit:
            class _Info:
                overage_status = "disabled"
                resets_at = 1_900_000_000  # epoch seconds; concrete future moment
                status = "rejected"

            rate_limit_info = _Info()

        with pytest.raises(RateLimitHit):
            handle_rate_limit_event(
                _RejectedRateLimit(),
                logging.getLogger("test"),
                tmp_path / "state.json",
            )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_minimal_options() -> object:
    """Return a minimal duck-typed options object for run_with_shared_client logging."""

    class _Opts:
        model = "claude-sonnet-4-6"
        effort = None
        max_turns = None

    return _Opts()


# Quick async sanity: calling the module from sync wraps with asyncio.run.
def _sync(coro):
    return asyncio.run(coro)
