"""Tests for Phase 8 progress field on CycleState and State (#299).

Phase 8 (finalization) gets the same resume-friendly progress slot that
Phase 6.5 already uses: a small dataclass on both ``CycleState`` and
``State`` that round-trips through ``save_state``/``load_state`` and
defaults to ``None`` so pre-#299 ``state.json`` files keep loading.
"""

import json
from pathlib import Path
from typing import cast

from code_generator.state import (
    CycleState,
    IssueState,
    Phase8Progress,
    State,
    load_state,
    save_state,
)


def _make_issue(number: int = 1) -> IssueState:
    return IssueState(number=number, status="open", agent="python-pro")


def _make_cycle(cycle_id: int = 1) -> CycleState:
    return CycleState(
        id=cycle_id,
        name="Cycle 1",
        milestone_number=1,
        milestone_title="Cycle 1 — Phase 8",
        status="in_progress",
        phase=8,
        issues=[_make_issue()],
        commit_sha=None,
    )


class TestPhase8ProgressDefaults:
    def test_default_attempt_is_zero(self) -> None:
        """Phase8Progress.attempt defaults to 0."""
        progress = Phase8Progress()
        assert progress.attempt == 0

    def test_default_status_is_none(self) -> None:
        """Phase8Progress.status defaults to None."""
        progress = Phase8Progress()
        assert progress.status is None

    def test_default_started_at_is_none(self) -> None:
        """Phase8Progress.started_at defaults to None."""
        progress = Phase8Progress()
        assert progress.started_at is None

    def test_default_finished_at_is_none(self) -> None:
        """Phase8Progress.finished_at defaults to None."""
        progress = Phase8Progress()
        assert progress.finished_at is None


class TestCycleStatePhase8Field:
    def test_default_value_is_none(self) -> None:
        """CycleState.phase8 defaults to None when not provided."""
        cycle = _make_cycle()
        assert cycle.phase8 is None

    def test_state_default_value_is_none(self) -> None:
        """State.phase8 defaults to None when not provided."""
        state = State(
            mode="single",
            started_at="2026-05-15T00:00:00Z",
            updated_at="2026-05-15T00:00:00Z",
        )
        assert state.phase8 is None


class TestPhase8RoundTrip:
    def test_cycle_round_trip_preserves_phase8(self, tmp_path: Path) -> None:
        """save_state then load_state preserves CycleState.phase8 contents."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.phase8 = Phase8Progress(
            attempt=1,
            status="ok",
            started_at="2026-05-16T10:00:00+00:00",
            finished_at="2026-05-16T10:05:00+00:00",
        )
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        reloaded = cast("CycleState", loaded.cycles[0]).phase8
        assert reloaded is not None
        assert reloaded.attempt == 1
        assert reloaded.status == "ok"
        assert reloaded.started_at == "2026-05-16T10:00:00+00:00"
        assert reloaded.finished_at == "2026-05-16T10:05:00+00:00"

    def test_single_mode_round_trip_preserves_phase8(self, tmp_path: Path) -> None:
        """save_state then load_state preserves State.phase8 contents."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.phase8 = Phase8Progress(
            attempt=2,
            status="failed",
            started_at="2026-05-16T11:00:00+00:00",
            finished_at="2026-05-16T11:01:00+00:00",
        )

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.phase8 is not None
        assert loaded.phase8.attempt == 2
        assert loaded.phase8.status == "failed"
        assert loaded.phase8.started_at == "2026-05-16T11:00:00+00:00"
        assert loaded.phase8.finished_at == "2026-05-16T11:01:00+00:00"

    def test_none_value_round_trips_as_none(self, tmp_path: Path) -> None:
        """A None phase8 value survives the round trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        state.cycles = [_make_cycle()]

        save_state(path, state)
        loaded = load_state(path)

        assert cast("CycleState", loaded.cycles[0]).phase8 is None
        assert loaded.phase8 is None


class TestPhase8BackwardCompat:
    def test_legacy_state_without_phase8_loads_to_none(self, tmp_path: Path) -> None:
        """A pre-#299 state.json without phase8 must deserialize cleanly."""
        path = tmp_path / "state.json"
        legacy = {
            "mode": "single",
            "started_at": "2026-05-01T00:00:00Z",
            "updated_at": "2026-05-01T00:00:00Z",
            "session_mode": "shared",
        }
        path.write_text(json.dumps(legacy), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.phase8 is None

    def test_legacy_cycle_without_phase8_loads_to_none(self, tmp_path: Path) -> None:
        """A pre-#299 nested cycle without phase8 deserializes to None."""
        path = tmp_path / "state.json"
        legacy = {
            "mode": "multi-cycle",
            "started_at": "2026-05-01T00:00:00Z",
            "updated_at": "2026-05-01T00:00:00Z",
            "session_mode": "shared",
            "cycles": [
                {
                    "id": 1,
                    "name": "Cycle 1",
                    "milestone_number": 1,
                    "milestone_title": "Cycle 1",
                    "status": "in_progress",
                    "phase": 7,
                    "issues": [],
                    "commit_sha": None,
                }
            ],
        }
        path.write_text(json.dumps(legacy), encoding="utf-8")

        loaded = load_state(path)

        cycle = cast("CycleState", loaded.cycles[0])
        assert cycle.phase8 is None

    def test_partial_phase8_dict_fills_defaults(self, tmp_path: Path) -> None:
        """A phase8 dict missing keys deserializes with field defaults."""
        path = tmp_path / "state.json"
        legacy = {
            "mode": "single",
            "started_at": "2026-05-01T00:00:00Z",
            "updated_at": "2026-05-01T00:00:00Z",
            "session_mode": "shared",
            "phase8": {"attempt": 1},
        }
        path.write_text(json.dumps(legacy), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.phase8 is not None
        assert loaded.phase8.attempt == 1
        assert loaded.phase8.status is None
        assert loaded.phase8.started_at is None
        assert loaded.phase8.finished_at is None


# ---------------------------------------------------------------------------
# Cycle 3 (#319) — CI green-gate fields on Phase8Progress
# ---------------------------------------------------------------------------


class TestPhase8CiGreenGateFields:
    def test_when_default_ci_fields_are_empty(self) -> None:
        progress = Phase8Progress()
        assert progress.ci_status is None
        assert progress.ci_run_id is None
        assert progress.repair_attempts == 0
        assert progress.workflow_files_written == []

    def test_when_ci_fields_round_trip_through_state_json(self, tmp_path: Path) -> None:
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.phase8 = Phase8Progress(
            attempt=1,
            status="ok",
            ci_status="green",
            ci_run_id=987654321,
            repair_attempts=2,
            workflow_files_written=[
                ".github/workflows/ci.yml",
                ".github/workflows/release.yml",
            ],
        )

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.phase8 is not None
        assert loaded.phase8.ci_status == "green"
        assert loaded.phase8.ci_run_id == 987654321
        assert loaded.phase8.repair_attempts == 2
        assert loaded.phase8.workflow_files_written == [
            ".github/workflows/ci.yml",
            ".github/workflows/release.yml",
        ]

    def test_when_legacy_phase8_lacks_ci_fields_loads_with_defaults(self, tmp_path: Path) -> None:
        path = tmp_path / "state.json"
        legacy = {
            "mode": "single",
            "started_at": "2026-05-01T00:00:00Z",
            "updated_at": "2026-05-01T00:00:00Z",
            "session_mode": "shared",
            "phase8": {
                "attempt": 1,
                "status": "ok",
                "started_at": "2026-05-01T00:00:00Z",
                "finished_at": "2026-05-01T00:00:05Z",
            },
        }
        path.write_text(json.dumps(legacy), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.phase8 is not None
        assert loaded.phase8.ci_status is None
        assert loaded.phase8.ci_run_id is None
        assert loaded.phase8.repair_attempts == 0
        assert loaded.phase8.workflow_files_written == []
