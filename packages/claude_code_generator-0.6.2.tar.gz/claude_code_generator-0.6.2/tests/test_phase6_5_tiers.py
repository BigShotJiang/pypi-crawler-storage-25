"""Tests for Phase 6.5 T0 (build), T1 (boot), T2 (API) tiers + extractor (#273, #274)."""

from __future__ import annotations

import shutil
import socket
import sys
import textwrap
from pathlib import Path

import httpx
import pytest

from code_generator.orchestrator.phase6_5_verify import (
    Endpoint,
    TierResult,
    VerificationFailed,
    extract_endpoints_from_requirements,
    run_t0_build,
    run_t1_boot,
    run_t2_api,
)


@pytest.fixture
def neutral_env() -> dict[str, str]:
    """Minimal env sufficient for python + pip subprocess calls."""
    import os

    keep = {"PATH", "HOME", "LANG", "LC_ALL", "PYTHONPATH"}
    return {k: v for k, v in os.environ.items() if k in keep}


def _free_port() -> int:
    """Allocate an ephemeral port and release it."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# ---------------------------------------------------------------------------
# TierResult dataclass shape
# ---------------------------------------------------------------------------


class TestTierResult:
    def test_is_frozen(self) -> None:
        result = TierResult(
            tier_id="T0",
            passed=True,
            skipped=False,
            skip_reason=None,
            exit_code=0,
            stderr_tail=None,
            failing_detail=None,
        )
        with pytest.raises((AttributeError, TypeError)):
            result.passed = False  # type: ignore[misc]

    def test_required_fields_present(self) -> None:
        result = TierResult(
            tier_id="T1",
            passed=False,
            skipped=True,
            skip_reason="no entry_cmd",
            exit_code=None,
            stderr_tail=None,
            failing_detail=None,
        )
        assert result.tier_id == "T1"
        assert result.skipped is True
        assert result.skip_reason == "no entry_cmd"


# ---------------------------------------------------------------------------
# VerificationFailed exception
# ---------------------------------------------------------------------------


def test_verification_failed_is_runtime_error_subclass() -> None:
    assert issubclass(VerificationFailed, RuntimeError)


# ---------------------------------------------------------------------------
# T0 — Build tier
# ---------------------------------------------------------------------------


class TestT0Build:
    def test_skipped_when_no_pyproject_and_no_setup(
        self, tmp_path: Path, neutral_env: dict[str, str]
    ) -> None:
        """No installable manifest and no explicit install_cmd → skipped."""
        result = run_t0_build(tmp_path, env=neutral_env)
        assert result.tier_id == "T0"
        assert result.skipped is True
        assert result.skip_reason is not None
        assert result.passed is False

    def test_passes_with_explicit_import_target_for_stdlib_module(
        self, tmp_path: Path, neutral_env: dict[str, str]
    ) -> None:
        """import_target hitting a real stdlib module → pass without install."""
        result = run_t0_build(
            tmp_path,
            env=neutral_env,
            install_cmd=[sys.executable, "-c", "pass"],
            import_target="json",
        )
        assert result.tier_id == "T0"
        assert result.passed is True
        assert result.skipped is False
        assert result.exit_code == 0

    def test_fails_on_missing_module(self, tmp_path: Path, neutral_env: dict[str, str]) -> None:
        """import_target that does not exist → passed=False, exit_code != 0, stderr_tail populated."""
        result = run_t0_build(
            tmp_path,
            env=neutral_env,
            install_cmd=[sys.executable, "-c", "pass"],
            import_target="zzz_nonexistent_module_xyz",
        )
        assert result.passed is False
        assert result.skipped is False
        assert result.exit_code != 0
        assert result.stderr_tail is not None
        assert "ModuleNotFoundError" in result.stderr_tail or "No module" in result.stderr_tail

    def test_fails_when_install_command_fails(
        self, tmp_path: Path, neutral_env: dict[str, str]
    ) -> None:
        """install_cmd returning non-zero → passed=False, exit_code populated, no import attempted."""
        result = run_t0_build(
            tmp_path,
            env=neutral_env,
            install_cmd=[sys.executable, "-c", "import sys; sys.exit(7)"],
            import_target="json",
        )
        assert result.passed is False
        assert result.exit_code == 7

    def test_stderr_tail_capped_to_500_chars(
        self, tmp_path: Path, neutral_env: dict[str, str]
    ) -> None:
        """stderr tail is truncated to ~500 chars when output is large."""
        script = "import sys; sys.stderr.write('x' * 5000); sys.exit(1)"
        result = run_t0_build(
            tmp_path,
            env=neutral_env,
            install_cmd=[sys.executable, "-c", script],
            import_target="json",
        )
        assert result.passed is False
        assert result.stderr_tail is not None
        assert len(result.stderr_tail) <= 500

    def test_when_install_cmd_times_out_then_returns_timed_out_failure(
        self,
        tmp_path: Path,
        neutral_env: dict[str, str],
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """subprocess.TimeoutExpired must translate to passed=False with 'timed out' detail (#293)."""
        import subprocess as _subprocess

        from code_generator.orchestrator import phase6_5_verify as _verify

        def _raise_timeout(*_args: object, **_kwargs: object) -> None:
            raise _subprocess.TimeoutExpired(cmd=["fake"], timeout=2.0)

        monkeypatch.setattr(_verify.subprocess, "run", _raise_timeout)

        result = run_t0_build(
            tmp_path,
            env=neutral_env,
            install_cmd=[sys.executable, "-c", "pass"],
            timeout_s=2.0,
        )

        assert result.tier_id == "T0"
        assert result.passed is False
        assert result.skipped is False
        assert result.failing_detail is not None
        assert "timed out" in result.failing_detail
        assert "2" in result.failing_detail


# ---------------------------------------------------------------------------
# T1 — Boot smoke tier
# ---------------------------------------------------------------------------


def _build_http_server_script(tmp_path: Path, port: int) -> Path:
    script = tmp_path / "fake_server.py"
    script.write_text(
        textwrap.dedent(
            f"""
            import http.server
            import socketserver
            import threading
            import time

            class H(http.server.BaseHTTPRequestHandler):
                def do_GET(self):
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"ok")
                def log_message(self, *_a, **_kw):
                    return

            with socketserver.TCPServer(("127.0.0.1", {port}), H) as srv:
                srv.serve_forever()
            """
        ).strip(),
        encoding="utf-8",
    )
    return script


def _build_crashing_script(tmp_path: Path) -> Path:
    script = tmp_path / "crasher.py"
    script.write_text("import sys; sys.exit(2)\n", encoding="utf-8")
    return script


class TestT1Boot:
    def test_skipped_when_entry_cmd_empty(
        self, tmp_path: Path, neutral_env: dict[str, str]
    ) -> None:
        result = run_t1_boot(tmp_path, env=neutral_env, entry_cmd=[], port=_free_port())
        assert result.tier_id == "T1"
        assert result.skipped is True
        assert result.skip_reason is not None
        assert result.passed is False

    def test_passes_against_live_http_server(
        self, tmp_path: Path, neutral_env: dict[str, str]
    ) -> None:
        """Spawned server listens → tier passes; process is killed before return."""
        port = _free_port()
        script = _build_http_server_script(tmp_path, port)
        env = {**neutral_env, "PYTHONUNBUFFERED": "1"}

        result = run_t1_boot(
            tmp_path,
            env=env,
            entry_cmd=[sys.executable, str(script)],
            port=port,
            boot_window_s=5.0,
            health_path="/",
        )

        assert result.tier_id == "T1"
        assert result.passed is True
        assert result.skipped is False
        # Ensure nothing is actively *listening* on the port — proves cleanup
        # happened. (Connect should fail; TIME_WAIT on bind is acceptable.)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.settimeout(0.5)
            with pytest.raises(OSError):
                probe.connect(("127.0.0.1", port))

    def test_fails_when_process_exits_before_window(
        self, tmp_path: Path, neutral_env: dict[str, str]
    ) -> None:
        """Process that exits immediately → tier fails with exit_code populated."""
        script = _build_crashing_script(tmp_path)
        port = _free_port()

        result = run_t1_boot(
            tmp_path,
            env=neutral_env,
            entry_cmd=[sys.executable, str(script)],
            port=port,
            boot_window_s=2.0,
        )

        assert result.passed is False
        assert result.skipped is False
        assert result.exit_code is not None
        assert result.exit_code != 0

    def test_cleans_up_process_on_exception(
        self, tmp_path: Path, neutral_env: dict[str, str], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If the poll loop raises, the subprocess must still be killed."""
        port = _free_port()
        script = _build_http_server_script(tmp_path, port)

        from code_generator.orchestrator import phase6_5_verify as mod

        def boom(*_a: object, **_kw: object) -> None:
            raise RuntimeError("simulated poll failure")

        monkeypatch.setattr(mod, "_poll_until_ready", boom)

        with pytest.raises(RuntimeError, match="simulated poll failure"):
            run_t1_boot(
                tmp_path,
                env=neutral_env,
                entry_cmd=[sys.executable, str(script)],
                port=port,
                boot_window_s=2.0,
            )

        # Nothing should be listening — proves child died even on exception.
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.settimeout(0.5)
            with pytest.raises(OSError):
                probe.connect(("127.0.0.1", port))


# ---------------------------------------------------------------------------
# Stdlib pip path — only runs when pip is available; otherwise skipped
# ---------------------------------------------------------------------------


def test_t0_install_default_picks_up_pyproject(tmp_path: Path, neutral_env: dict[str, str]) -> None:
    """When a pyproject.toml is present and install_cmd is None, executor attempts pip install.

    We pass a deliberately broken pyproject so pip fails — proving the default
    install path is actually invoked (passed=False, exit_code populated).
    """
    if shutil.which("pip") is None:
        pytest.skip("pip not on PATH")
    (tmp_path / "pyproject.toml").write_text("not-valid-toml = {{\n", encoding="utf-8")
    result = run_t0_build(tmp_path, env=neutral_env, import_target="json")
    assert result.skipped is False
    assert result.passed is False
    assert result.exit_code is not None
    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Endpoint extractor (#274)
# ---------------------------------------------------------------------------


class TestExtractEndpoints:
    def test_returns_empty_list_for_empty_string(self) -> None:
        assert extract_endpoints_from_requirements("") == []

    def test_picks_up_simple_path_inside_checkbox_bullet(self) -> None:
        text = "- [ ] Service exposes `/health` for liveness probes\n"
        result = extract_endpoints_from_requirements(text)
        assert result == [Endpoint(method="GET", path="/health")]

    def test_parses_method_and_path_when_both_present(self) -> None:
        text = "- [ ] `POST /api/v1/orders` creates an order\n"
        result = extract_endpoints_from_requirements(text)
        assert result == [Endpoint(method="POST", path="/api/v1/orders")]

    def test_defaults_method_to_get(self) -> None:
        text = "- [ ] backticked path `/users/{id}` returns the user\n"
        result = extract_endpoints_from_requirements(text)
        assert result == [Endpoint(method="GET", path="/users/{id}")]

    def test_ignores_paths_outside_checkbox_bullets(self) -> None:
        text = "- some intro `/should-not-match` prose\n- [ ] real criterion `/api/items`\n"
        result = extract_endpoints_from_requirements(text)
        assert result == [Endpoint(method="GET", path="/api/items")]

    def test_rejects_file_paths_like_dot_py_md_json(self) -> None:
        text = (
            "- [ ] see `src/foo.py` for context\n"
            "- [ ] see `docs/spec.md` for context\n"
            "- [ ] see `config/settings.json` for context\n"
            "- [ ] real route `/v1/keep` matches\n"
        )
        result = extract_endpoints_from_requirements(text)
        assert result == [Endpoint(method="GET", path="/v1/keep")]

    def test_deduplicates_preserving_first_seen_order(self) -> None:
        text = (
            "- [ ] first `GET /a`\n"
            "- [ ] then `/b`\n"
            "- [ ] again `GET /a` (duplicate)\n"
            "- [ ] new `POST /a` (different method counts separately)\n"
        )
        result = extract_endpoints_from_requirements(text)
        assert result == [
            Endpoint(method="GET", path="/a"),
            Endpoint(method="GET", path="/b"),
            Endpoint(method="POST", path="/a"),
        ]

    def test_handles_multi_segment_path_with_braces(self) -> None:
        text = "- [ ] `PATCH /api/v2/users/{user_id}/profile` updates profile\n"
        result = extract_endpoints_from_requirements(text)
        assert result == [Endpoint(method="PATCH", path="/api/v2/users/{user_id}/profile")]


# ---------------------------------------------------------------------------
# T2 — API contract tier (#274)
# ---------------------------------------------------------------------------


def _mock_transport(handler):  # type: ignore[no-untyped-def]
    return httpx.MockTransport(handler)


class TestT2Api:
    def test_skips_when_no_endpoints_and_no_health(
        self, tmp_path: Path, neutral_env: dict[str, str], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/health":
                return httpx.Response(503)
            return httpx.Response(404)

        from code_generator.orchestrator import phase6_5_verify as mod

        monkeypatch.setattr(
            mod,
            "_make_http_client",
            lambda **kw: httpx.Client(transport=_mock_transport(handler), **kw),
        )

        result = run_t2_api(
            tmp_path,
            env=neutral_env,
            base_url="http://127.0.0.1:0",
            endpoints=[],
        )
        assert result.tier_id == "T2"
        assert result.skipped is True
        assert result.skip_reason == "no endpoints declared"

    def test_passes_against_healthy_mock_endpoints(
        self, tmp_path: Path, neutral_env: dict[str, str], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/health":
                return httpx.Response(200, json={"status": "ok"})
            if request.url.path == "/api/items" and request.method == "GET":
                return httpx.Response(200, json=[{"id": 1}])
            if request.url.path == "/api/items" and request.method == "POST":
                return httpx.Response(201, json={"id": 2})
            return httpx.Response(404)

        from code_generator.orchestrator import phase6_5_verify as mod

        monkeypatch.setattr(
            mod,
            "_make_http_client",
            lambda **kw: httpx.Client(transport=_mock_transport(handler), **kw),
        )

        result = run_t2_api(
            tmp_path,
            env=neutral_env,
            base_url="http://127.0.0.1:0",
            endpoints=[
                Endpoint(method="GET", path="/api/items"),
                Endpoint(method="POST", path="/api/items"),
            ],
        )
        assert result.tier_id == "T2"
        assert result.passed is True
        assert result.skipped is False

    def test_fails_on_500_response(
        self, tmp_path: Path, neutral_env: dict[str, str], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/health":
                return httpx.Response(200)
            return httpx.Response(500, text="boom" * 200)

        from code_generator.orchestrator import phase6_5_verify as mod

        monkeypatch.setattr(
            mod,
            "_make_http_client",
            lambda **kw: httpx.Client(transport=_mock_transport(handler), **kw),
        )

        result = run_t2_api(
            tmp_path,
            env=neutral_env,
            base_url="http://127.0.0.1:0",
            endpoints=[Endpoint(method="GET", path="/api/broken")],
        )
        assert result.passed is False
        assert result.skipped is False
        assert result.failing_detail is not None
        assert "/api/broken" in result.failing_detail
        assert result.stderr_tail is not None

    def test_fails_when_health_unreachable_and_endpoints_present(
        self, tmp_path: Path, neutral_env: dict[str, str], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(503)

        from code_generator.orchestrator import phase6_5_verify as mod

        monkeypatch.setattr(
            mod,
            "_make_http_client",
            lambda **kw: httpx.Client(transport=_mock_transport(handler), **kw),
        )

        result = run_t2_api(
            tmp_path,
            env=neutral_env,
            base_url="http://127.0.0.1:0",
            endpoints=[Endpoint(method="GET", path="/api/x")],
        )
        assert result.passed is False
        assert result.skipped is False
        assert result.failing_detail is not None
        assert "/health" in result.failing_detail

    def test_fails_when_get_response_not_json(
        self, tmp_path: Path, neutral_env: dict[str, str], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/health":
                return httpx.Response(200)
            return httpx.Response(200, text="<html>not json</html>")

        from code_generator.orchestrator import phase6_5_verify as mod

        monkeypatch.setattr(
            mod,
            "_make_http_client",
            lambda **kw: httpx.Client(transport=_mock_transport(handler), **kw),
        )

        result = run_t2_api(
            tmp_path,
            env=neutral_env,
            base_url="http://127.0.0.1:0",
            endpoints=[Endpoint(method="GET", path="/api/raw")],
        )
        assert result.passed is False
        assert "/api/raw" in (result.failing_detail or "")

    def test_empty_get_body_is_acceptable(
        self, tmp_path: Path, neutral_env: dict[str, str], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/health":
                return httpx.Response(200)
            return httpx.Response(204)  # no body

        from code_generator.orchestrator import phase6_5_verify as mod

        monkeypatch.setattr(
            mod,
            "_make_http_client",
            lambda **kw: httpx.Client(transport=_mock_transport(handler), **kw),
        )

        result = run_t2_api(
            tmp_path,
            env=neutral_env,
            base_url="http://127.0.0.1:0",
            endpoints=[Endpoint(method="GET", path="/api/nothing")],
        )
        assert result.passed is True
