"""Tests for §12 once-per-cycle cache pre-warm (issue #241).

Covers:

1. ``warm_workspace_cache`` issues exactly one ``run_with_shared_client``
   call carrying a deterministic no-op prompt — the request loads BP1/BP2/BP3
   into the workspace cache without producing meaningful output.
2. The pre-warm path constructs options via ``make_agent_options`` without a
   ``max_turns`` kwarg (non-negotiable #9 preserved).
3. Idempotency — when ``CycleState.cache_prewarmed`` (or single-mode
   ``State.cache_prewarmed``) is True, the warm-up is skipped on
   ``--continue``.
4. Skipped when ``shared_client is None`` (fresh-mode session) — pre-warm is
   strictly a shared-client optimisation.
5. Atomic state persistence — the flag flip rides through ``save_state``'s
   ``tmp → os.replace`` (non-negotiable #7).
6. Ordering — the warm-up call precedes Phase 2's first ``phase2_review.run``.
"""

from __future__ import annotations

import logging
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator._cache_warmup import warm_workspace_cache

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_state(tmp_path: Path) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.State(
        mode="multi-cycle",  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# State field
# ---------------------------------------------------------------------------


class TestCachePrewarmedField:
    def test_cycle_state_defaults_cache_prewarmed_false(self) -> None:
        """A fresh CycleState carries cache_prewarmed=False."""
        c = _state.CycleState(
            id=1,
            name="x",
            milestone_number=None,
            milestone_title="m",
            status="open",
            phase=0,
            issues=[],
            commit_sha=None,
        )
        assert c.cache_prewarmed is False

    def test_state_defaults_cache_prewarmed_false(self) -> None:
        """A fresh single-mode State carries cache_prewarmed=False."""
        s = _state.State(
            mode="single",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        assert s.cache_prewarmed is False

    def test_cache_prewarmed_persists_through_save_load_roundtrip(self, tmp_path: Path) -> None:
        """save_state → load_state preserves cache_prewarmed=True (atomic-write invariant)."""
        path = tmp_path / "state.json"
        st = _state.State(
            mode="single",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            cache_prewarmed=True,
        )
        _state.save_state(path, st)
        loaded = _state.load_state(path)
        assert loaded.cache_prewarmed is True

    def test_cycle_state_cache_prewarmed_persists_through_roundtrip(self, tmp_path: Path) -> None:
        """save/load preserves CycleState.cache_prewarmed=True."""
        path = tmp_path / "state.json"
        cycle = _state.CycleState(
            id=1,
            name="c1",
            milestone_number=None,
            milestone_title="m",
            status="open",
            phase=0,
            issues=[],
            commit_sha=None,
            cache_prewarmed=True,
        )
        st = _state.State(
            mode="multi-cycle",  # type: ignore[arg-type]
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            cycles=[cycle],
        )
        _state.save_state(path, st)
        loaded = _state.load_state(path)
        assert isinstance(loaded.cycles[0], _state.CycleState)
        assert loaded.cycles[0].cache_prewarmed is True


# ---------------------------------------------------------------------------
# warm_workspace_cache — single no-op query
# ---------------------------------------------------------------------------


class TestWarmWorkspaceCache:
    @pytest.mark.asyncio
    async def test_fires_exactly_one_run_with_shared_client_call(self, tmp_path: Path) -> None:
        """warm_workspace_cache delegates to run_with_shared_client exactly once."""
        client = MagicMock()
        captured: list[tuple] = []

        async def fake_run(c, prompt, options, *, logger, state_path):
            captured.append((c, prompt))

        with patch(
            "code_generator.orchestrator._cache_warmup.run_with_shared_client",
            side_effect=fake_run,
        ):
            await warm_workspace_cache(
                client,
                project_dir=tmp_path,
                logger=logging.getLogger("test"),
            )

        assert len(captured) == 1
        # The prompt must be a non-empty string — Anthropic rejects an empty body.
        assert isinstance(captured[0][1], str) and captured[0][1].strip()

    @pytest.mark.asyncio
    async def test_make_agent_options_called_without_max_turns_kwarg(self, tmp_path: Path) -> None:
        """Non-negotiable #9 — pre-warm path never sets max_turns."""
        client = MagicMock()

        async def fake_run(c, prompt, options, *, logger, state_path):
            return None

        with (
            patch(
                "code_generator.orchestrator._cache_warmup.run_with_shared_client",
                side_effect=fake_run,
            ),
            patch(
                "code_generator.orchestrator._cache_warmup.make_agent_options",
                wraps=__import__(
                    "code_generator.runner.options", fromlist=["make_agent_options"]
                ).make_agent_options,
            ) as mock_opts,
        ):
            await warm_workspace_cache(
                client,
                project_dir=tmp_path,
                logger=logging.getLogger("test"),
            )

        # Last call to make_agent_options inside the warmup path must not carry
        # max_turns (regression guard for #9).
        for call in mock_opts.call_args_list:
            assert "max_turns" not in call.kwargs, (
                f"warm_workspace_cache must not pass max_turns; got {call.kwargs}"
            )


# ---------------------------------------------------------------------------
# cycle_loop._run_phases — idempotency, gating, ordering
# ---------------------------------------------------------------------------


class TestCycleLoopWarmupGating:
    @pytest.mark.asyncio
    async def test_warmup_fires_once_in_shared_mode_when_flag_unset(self, tmp_path: Path) -> None:
        """Shared mode + cache_prewarmed=False → warm_workspace_cache called exactly once."""
        from code_generator.orchestrator import cycle_loop as _cl

        st = _make_state(tmp_path)
        client = MagicMock()
        warmup_calls: list[int] = []

        async def fake_warmup(c, *, project_dir, logger):
            warmup_calls.append(1)

        mocks = {
            "p1": AsyncMock(return_value=None),
            "p2": AsyncMock(return_value=None),
            "p3_4": AsyncMock(return_value=None),
            "p5": AsyncMock(return_value=MagicMock(new_issues=[])),
            "p6": AsyncMock(return_value=None),
            "p7": AsyncMock(return_value="feat: x"),
        }

        with (
            patch.object(_cl.phase1_plan, "run", mocks["p1"]),
            patch.object(_cl.phase2_review, "run", mocks["p2"]),
            patch.object(_cl.phase3_4_implement, "run", mocks["p3_4"]),
            patch.object(_cl.phase5_closure, "run", mocks["p5"]),
            patch.object(_cl.phase6_test, "run", mocks["p6"]),
            patch.object(_cl.phase7_commit, "run", mocks["p7"]),
            patch.object(_cl.phase8_finalization, "run", AsyncMock()),
            patch.object(_cl, "setup_phase_logger", return_value=logging.getLogger("t")),
            patch(
                "code_generator.orchestrator.cycle_loop.warm_workspace_cache",
                side_effect=fake_warmup,
            ),
        ):
            await _cl._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=client,
            )

        assert len(warmup_calls) == 1, f"Expected one warmup call, got {len(warmup_calls)}"
        assert st.cache_prewarmed is True, "flag must be flipped after successful warmup"

    @pytest.mark.asyncio
    async def test_warmup_skipped_when_shared_client_is_none(self, tmp_path: Path) -> None:
        """Fresh-mode (shared_client=None) → pre-warm is a no-op."""
        from code_generator.orchestrator import cycle_loop as _cl

        st = _make_state(tmp_path)
        warmup_calls: list[int] = []

        async def fake_warmup(c, *, project_dir, logger):
            warmup_calls.append(1)

        mocks = {
            "p1": AsyncMock(return_value=None),
            "p2": AsyncMock(return_value=None),
            "p3_4": AsyncMock(return_value=None),
            "p5": AsyncMock(return_value=MagicMock(new_issues=[])),
            "p6": AsyncMock(return_value=None),
            "p7": AsyncMock(return_value="feat: x"),
        }

        with (
            patch.object(_cl.phase1_plan, "run", mocks["p1"]),
            patch.object(_cl.phase2_review, "run", mocks["p2"]),
            patch.object(_cl.phase3_4_implement, "run", mocks["p3_4"]),
            patch.object(_cl.phase5_closure, "run", mocks["p5"]),
            patch.object(_cl.phase6_test, "run", mocks["p6"]),
            patch.object(_cl.phase7_commit, "run", mocks["p7"]),
            patch.object(_cl.phase8_finalization, "run", AsyncMock()),
            patch.object(_cl, "setup_phase_logger", return_value=logging.getLogger("t")),
            patch(
                "code_generator.orchestrator.cycle_loop.warm_workspace_cache",
                side_effect=fake_warmup,
            ),
        ):
            await _cl._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=None,
            )

        assert warmup_calls == []
        assert st.cache_prewarmed is False

    @pytest.mark.asyncio
    async def test_warmup_skipped_when_flag_already_true(self, tmp_path: Path) -> None:
        """--continue with cache_prewarmed=True → pre-warm is a no-op."""
        from code_generator.orchestrator import cycle_loop as _cl

        st = _make_state(tmp_path)
        st.cache_prewarmed = True
        client = MagicMock()
        warmup_calls: list[int] = []

        async def fake_warmup(c, *, project_dir, logger):
            warmup_calls.append(1)

        mocks = {
            "p1": AsyncMock(return_value=None),
            "p2": AsyncMock(return_value=None),
            "p3_4": AsyncMock(return_value=None),
            "p5": AsyncMock(return_value=MagicMock(new_issues=[])),
            "p6": AsyncMock(return_value=None),
            "p7": AsyncMock(return_value="feat: x"),
        }

        with (
            patch.object(_cl.phase1_plan, "run", mocks["p1"]),
            patch.object(_cl.phase2_review, "run", mocks["p2"]),
            patch.object(_cl.phase3_4_implement, "run", mocks["p3_4"]),
            patch.object(_cl.phase5_closure, "run", mocks["p5"]),
            patch.object(_cl.phase6_test, "run", mocks["p6"]),
            patch.object(_cl.phase7_commit, "run", mocks["p7"]),
            patch.object(_cl.phase8_finalization, "run", AsyncMock()),
            patch.object(_cl, "setup_phase_logger", return_value=logging.getLogger("t")),
            patch(
                "code_generator.orchestrator.cycle_loop.warm_workspace_cache",
                side_effect=fake_warmup,
            ),
        ):
            await _cl._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=client,
            )

        assert warmup_calls == []

    @pytest.mark.asyncio
    async def test_warmup_precedes_phase_2_first_call(self, tmp_path: Path) -> None:
        """Order invariant — warm_workspace_cache fires before phase2_review.run."""
        from code_generator.orchestrator import cycle_loop as _cl

        st = _make_state(tmp_path)
        client = MagicMock()
        order: list[str] = []

        async def fake_warmup(c, *, project_dir, logger):
            order.append("warmup")

        async def fake_p2(*a, **kw):
            order.append("phase2")

        mocks = {
            "p1": AsyncMock(return_value=None),
            "p3_4": AsyncMock(return_value=None),
            "p5": AsyncMock(return_value=MagicMock(new_issues=[])),
            "p6": AsyncMock(return_value=None),
            "p7": AsyncMock(return_value="feat: x"),
        }

        with (
            patch.object(_cl.phase1_plan, "run", mocks["p1"]),
            patch.object(_cl.phase2_review, "run", side_effect=fake_p2),
            patch.object(_cl.phase3_4_implement, "run", mocks["p3_4"]),
            patch.object(_cl.phase5_closure, "run", mocks["p5"]),
            patch.object(_cl.phase6_test, "run", mocks["p6"]),
            patch.object(_cl.phase7_commit, "run", mocks["p7"]),
            patch.object(_cl.phase8_finalization, "run", AsyncMock()),
            patch.object(_cl, "setup_phase_logger", return_value=logging.getLogger("t")),
            patch(
                "code_generator.orchestrator.cycle_loop.warm_workspace_cache",
                side_effect=fake_warmup,
            ),
        ):
            await _cl._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=client,
            )

        assert order.index("warmup") < order.index("phase2")

    @pytest.mark.asyncio
    async def test_flag_persisted_atomically_after_warmup(self, tmp_path: Path) -> None:
        """save_state is called after the flag flips so --continue sees True."""
        from code_generator.orchestrator import cycle_loop as _cl

        st = _make_state(tmp_path)
        state_path = tmp_path / ".code-generator" / "state.json"
        client = MagicMock()

        async def fake_warmup(c, *, project_dir, logger):
            pass

        mocks = {
            "p1": AsyncMock(return_value=None),
            "p2": AsyncMock(return_value=None),
            "p3_4": AsyncMock(return_value=None),
            "p5": AsyncMock(return_value=MagicMock(new_issues=[])),
            "p6": AsyncMock(return_value=None),
            "p7": AsyncMock(return_value="feat: x"),
        }

        with (
            patch.object(_cl.phase1_plan, "run", mocks["p1"]),
            patch.object(_cl.phase2_review, "run", mocks["p2"]),
            patch.object(_cl.phase3_4_implement, "run", mocks["p3_4"]),
            patch.object(_cl.phase5_closure, "run", mocks["p5"]),
            patch.object(_cl.phase6_test, "run", mocks["p6"]),
            patch.object(_cl.phase7_commit, "run", mocks["p7"]),
            patch.object(_cl.phase8_finalization, "run", AsyncMock()),
            patch.object(_cl, "setup_phase_logger", return_value=logging.getLogger("t")),
            patch(
                "code_generator.orchestrator.cycle_loop.warm_workspace_cache",
                side_effect=fake_warmup,
            ),
        ):
            await _cl._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=client,
            )

        loaded = _state.load_state(state_path)
        assert loaded.cache_prewarmed is True

    @pytest.mark.asyncio
    async def test_multi_cycle_flag_lives_on_cycle_state(self, tmp_path: Path) -> None:
        """Multi-cycle path flips CycleState.cache_prewarmed (not State.cache_prewarmed)."""
        from code_generator.orchestrator import cycle_loop as _cl

        st = _make_state(tmp_path)
        cycle = _state.CycleState(
            id=1,
            name="c1",
            milestone_number=None,
            milestone_title="m",
            status="open",
            phase=0,
            issues=[],
            commit_sha=None,
        )
        client = MagicMock()

        async def fake_warmup(c, *, project_dir, logger):
            pass

        mocks = {
            "p1": AsyncMock(return_value=None),
            "p2": AsyncMock(return_value=None),
            "p3_4": AsyncMock(return_value=None),
            "p5": AsyncMock(return_value=MagicMock(new_issues=[])),
            "p6": AsyncMock(return_value=None),
            "p7": AsyncMock(return_value="feat: x"),
        }

        with (
            patch.object(_cl.phase1_plan, "run", mocks["p1"]),
            patch.object(_cl.phase2_review, "run", mocks["p2"]),
            patch.object(_cl.phase3_4_implement, "run", mocks["p3_4"]),
            patch.object(_cl.phase5_closure, "run", mocks["p5"]),
            patch.object(_cl.phase6_test, "run", mocks["p6"]),
            patch.object(_cl.phase7_commit, "run", mocks["p7"]),
            patch.object(_cl.phase8_finalization, "run", AsyncMock()),
            patch.object(_cl, "setup_phase_logger", return_value=logging.getLogger("t")),
            patch(
                "code_generator.orchestrator.cycle_loop.warm_workspace_cache",
                side_effect=fake_warmup,
            ),
        ):
            await _cl._run_phases(
                st,
                cycle,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=client,
            )

        assert cycle.cache_prewarmed is True
        # Single-mode flag stays untouched in multi-cycle runs.
        assert st.cache_prewarmed is False


# ---------------------------------------------------------------------------
# Cache-warmup effect on Phase 2 (issue #241 final acceptance criterion)
# ---------------------------------------------------------------------------


class TestCacheWarmupEffect:
    """Phase 2's first turn shows non-zero ``cache_read`` after a successful warmup.

    The fake-runner fixture (``CANNED_PHASE_USAGE``) carries
    ``cache_read=1200`` for Phase 2. Driving ``phase2_review.run`` with that
    canned ``TokenUsage`` and asserting the persisted ``token_usage["phase2"]``
    exposes a non-zero ``cache_read`` proves the pipeline accumulates the
    cache hit that the warmup primed. This satisfies the
    ``--fake bench fixture or counter-injecting fake runner`` clause of #241.
    """

    def test_fake_runner_phase2_usage_carries_nonzero_cache_read(self) -> None:
        """Documents the fixture invariant the pipeline test relies on."""
        from code_generator.runner.fake_runner import CANNED_PHASE_USAGE

        assert CANNED_PHASE_USAGE[2].cache_read > 0

    @pytest.mark.asyncio
    async def test_phase2_first_turn_reports_nonzero_cache_read_after_warmup(
        self, tmp_path: Path
    ) -> None:
        """After the warmup primes BP1/BP2/BP3, Phase 2 persists non-zero ``cache_read``."""
        from unittest.mock import patch as _patch

        from code_generator.orchestrator import phase2_review
        from code_generator.repo_info import RepoInfo
        from code_generator.runner.fake_runner import CANNED_PHASE_USAGE
        from code_generator.runner.sdk_runner import RunResult
        from tests._phase2_helpers import (
            decisions_response,
            identity_with_backoff,
            ok_decision,
        )

        # Seed a state with one open issue so Phase 2 has work to do.
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.repo = RepoInfo(host="github.com", owner="test-owner", name="test-repo")
        st.issues = [_state.IssueState(number=1, status="open", agent="python-pro")]
        # Warmup already ran in this scenario — flag flipped, BP1/BP2/BP3 in cache.
        st.cache_prewarmed = True
        _state.save_state(state_dir / "state.json", st)

        # Reuse the canned Phase 2 usage so the assertion matches the fake runner.
        canned_usage = CANNED_PHASE_USAGE[2]

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):  # noqa: ARG001
            return RunResult(
                text=decisions_response([ok_decision(1)]).text,
                session_id=None,
                usage=canned_usage,
            )

        with (
            _patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            _patch.object(phase2_review.retry, "with_backoff", side_effect=identity_with_backoff),
            _patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=None,
            )

        persisted = st.token_usage["phase2"]
        assert persisted.cache_read > 0, (
            "Phase 2's first post-warmup turn must persist a non-zero "
            "cache_read; otherwise the warmup did not load BP1/BP2/BP3 "
            "(or accumulate_phase_telemetry dropped the value)."
        )
        assert persisted.cache_read == canned_usage.cache_read
