"""Tests for code_generator.orchestrator.phase8_ci_classifier."""

from __future__ import annotations

import pytest

from code_generator.orchestrator.phase8_ci_classifier import (
    ClassificationEvidence,
    classify,
)


def _ev(
    *,
    log: str = "",
    jobs: list[str] | None = None,
    conclusions: list[str] | None = None,
) -> ClassificationEvidence:
    return ClassificationEvidence(
        failing_job_names=jobs or [],
        log_excerpt=log,
        recent_conclusions=conclusions or [],
    )


# ---------------------------------------------------------------------------
# Transient patterns
# ---------------------------------------------------------------------------


class TestTransientPatterns:
    @pytest.mark.parametrize(
        "needle",
        [
            "rate limit exceeded",
            "RATE LIMIT exceeded",
            "HTTP 429 from registry",
            "ECONNRESET: connection reset by peer",
            "Operation timed out after 30000ms",
            "TIMEOUT during step",
            "npm ERR! network",
            "Could not connect to pypi.org",
            "docker pull failed: registry returned 503",
        ],
    )
    def test_when_log_matches_transient_pattern_returns_transient(self, needle: str) -> None:
        assert classify(_ev(log=needle)) == "transient"


# ---------------------------------------------------------------------------
# Permanent patterns
# ---------------------------------------------------------------------------


class TestPermanentPatterns:
    @pytest.mark.parametrize(
        "needle",
        [
            "SyntaxError: invalid syntax",
            "ModuleNotFoundError: No module named 'foo'",
            "TypeError: unsupported operand",
            "src/x.ts(12,4): error TS2304: Cannot find name 'Foo'",
            "FAILED tests/test_foo.py::test_bar",
            "ESLint found 3 problems",
            "ruff check failed: F401",
            "mypy: error: incompatible types",
        ],
    )
    def test_when_log_matches_permanent_pattern_returns_permanent(self, needle: str) -> None:
        assert classify(_ev(log=needle)) == "permanent"


# ---------------------------------------------------------------------------
# Precedence: permanent beats transient
# ---------------------------------------------------------------------------


class TestPermanentOverridesTransient:
    def test_when_both_patterns_present_returns_permanent(self) -> None:
        log = "rate limit exceeded\nSyntaxError: invalid token"
        assert classify(_ev(log=log)) == "permanent"

    def test_when_timeout_and_failed_both_present_returns_permanent(self) -> None:
        log = "Operation timed out\nFAILED tests/test_x.py::test_y"
        assert classify(_ev(log=log)) == "permanent"


# ---------------------------------------------------------------------------
# Flap override
# ---------------------------------------------------------------------------


class TestFlapOverride:
    def test_when_last_three_conclusions_all_failure_returns_permanent(
        self,
    ) -> None:
        ev = _ev(
            log="rate limit",
            conclusions=["failure", "failure", "failure"],
        )
        assert classify(ev) == "permanent"

    def test_when_more_than_three_history_uses_last_three_only(self) -> None:
        ev = _ev(
            log="rate limit",
            conclusions=["success", "success", "failure", "failure", "failure"],
        )
        assert classify(ev) == "permanent"

    def test_when_last_three_mixed_does_not_force_permanent(self) -> None:
        ev = _ev(
            log="rate limit",
            conclusions=["failure", "success", "failure"],
        )
        assert classify(ev) == "transient"

    def test_when_only_two_failures_in_history_does_not_force_permanent(
        self,
    ) -> None:
        ev = _ev(log="rate limit", conclusions=["failure", "failure"])
        assert classify(ev) == "transient"


# ---------------------------------------------------------------------------
# Safe default
# ---------------------------------------------------------------------------


class TestSafeDefault:
    def test_when_empty_evidence_returns_permanent(self) -> None:
        assert classify(_ev()) == "permanent"

    def test_when_log_matches_nothing_returns_permanent(self) -> None:
        assert classify(_ev(log="random unrelated output")) == "permanent"


# ---------------------------------------------------------------------------
# ClassificationEvidence
# ---------------------------------------------------------------------------


class TestClassificationEvidence:
    def test_is_frozen(self) -> None:
        ev = _ev(log="x")
        with pytest.raises((AttributeError, Exception)):
            ev.log_excerpt = "y"  # type: ignore[misc]
