"""Tests for code_generator.runner.options — make_agent_options factory."""

from __future__ import annotations

import importlib
import sys
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _reload_options(sdk_module: object) -> object:
    """Reload options_mod with a patched claude_agent_sdk entry."""
    with patch.dict(sys.modules, {"claude_agent_sdk": sdk_module}):
        import code_generator.runner.options as options_mod

        importlib.reload(options_mod)
        return options_mod


# ---------------------------------------------------------------------------
# RED tests — required keyword-only allowed_tools (new behaviour)
# ---------------------------------------------------------------------------


class TestAllowedToolsRequired:
    """allowed_tools must be a required keyword-only argument."""

    def test_docstring_notes_max_turns_is_opt_in_only(self) -> None:
        """Issue #207: docstring flags max_turns as opt-in with no production caller."""
        import code_generator.runner.options as options_mod

        doc = options_mod.make_agent_options.__doc__ or ""
        lowered = doc.lower()
        assert "max_turns" in doc, "docstring must mention max_turns"
        assert "opt-in" in lowered, "docstring must flag max_turns as opt-in"

    def test_no_args_raises_type_error(self) -> None:
        """make_agent_options() with no arguments must raise TypeError."""
        import code_generator.runner.options as options_mod

        importlib.reload(options_mod)
        with pytest.raises(TypeError):
            options_mod.make_agent_options()  # type: ignore[call-arg]

    def test_missing_allowed_tools_raises_type_error(self) -> None:
        """make_agent_options(model='x') without allowed_tools raises TypeError."""
        import code_generator.runner.options as options_mod

        importlib.reload(options_mod)
        with pytest.raises(TypeError):
            options_mod.make_agent_options(model="x")  # type: ignore[call-arg]

    def test_allowed_tools_none_raises_type_error(self) -> None:
        """passing allowed_tools=None raises TypeError; the value must be a list."""
        import code_generator.runner.options as options_mod

        importlib.reload(options_mod)
        with pytest.raises(TypeError):
            options_mod.make_agent_options(allowed_tools=None)  # type: ignore[arg-type]

    def test_valid_allowed_tools_surfaces_on_options(self) -> None:
        """make_agent_options(allowed_tools=['Read']) returns an object with .allowed_tools == ['Read']."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert result.allowed_tools == ["Read"]


# ---------------------------------------------------------------------------
# Tests with SDK available
# ---------------------------------------------------------------------------


class TestMakeAgentOptionsWithSdkAvailable:
    def test_returns_real_options_when_sdk_present(self) -> None:
        """When claude_agent_sdk is importable, returns a ClaudeAgentOptions instance."""
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], model="claude-sonnet-4-6", max_turns=5
            )

        # The constructor is called twice: once by the cache_control TTL probe (first call)
        # and once for the actual options creation (last call).
        # extra_headers and cache_control are NOT in the actual constructor call
        # (they are attached as post-init attributes instead).
        actual_call_kwargs = fake_cls.call_args_list[-1][1]
        assert actual_call_kwargs == {
            "allowed_tools": ["Read"],
            "model": "claude-sonnet-4-6",
            "max_turns": 5,
        }
        assert result is fake_options

    def test_real_options_carry_all_kwargs(self) -> None:
        """Every kwarg is forwarded to ClaudeAgentOptions without modification."""
        calls: list[dict] = []

        def capture(**kw: object) -> MagicMock:
            calls.append(dict(kw))
            return MagicMock(**kw)

        fake_sdk = MagicMock(ClaudeAgentOptions=capture)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            options_mod.make_agent_options(allowed_tools=["Read"], model="m", cwd="/tmp")

        # The last call is the actual options creation (probe is first).
        # extra_headers and cache_control are NOT forwarded to the constructor
        # (they are attached as post-init attributes by make_agent_options instead).
        assert calls[-1] == {
            "allowed_tools": ["Read"],
            "model": "m",
            "cwd": "/tmp",
        }


# ---------------------------------------------------------------------------
# Tests without SDK (fallback path)
# ---------------------------------------------------------------------------


class TestMakeAgentOptionsWithoutSdk:
    def test_returns_fallback_when_sdk_missing(self) -> None:
        """When claude_agent_sdk is absent, returns a duck-typed fallback object."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], model="claude-opus-4-7", max_turns=10
            )

        assert result.model == "claude-opus-4-7"
        assert result.max_turns == 10

    def test_fallback_supports_arbitrary_attributes(self) -> None:
        """Fallback object exposes every kwarg as an attribute."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read", "Grep"],
                model="m",
                cwd="/some/path",
                permission_mode="bypassPermissions",
            )

        assert result.model == "m"
        assert result.allowed_tools == ["Read", "Grep"]
        assert result.cwd == "/some/path"
        assert result.permission_mode == "bypassPermissions"

    def test_fallback_attributes_not_set_default_to_none(self) -> None:
        """Attributes not passed as kwargs are absent / not set by the fallback."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"], model="m")

        assert result.model == "m"
        # resume is not passed — must not raise, just not exist
        assert not hasattr(result, "resume")


# ---------------------------------------------------------------------------
# Tests for extra_headers and build_beta_header (issue #159)
# ---------------------------------------------------------------------------

_DEFAULT_BETA = (
    "compact-2026-01-12,context-management-2025-06-27,"
    "extended-cache-ttl-2025-04-11,token-efficient-tools-2025-02-19"
)


class TestBuildBetaHeader:
    """Unit tests for the pure helper build_beta_header."""

    def test_alphabetical_sort_enforced(self) -> None:
        """build_beta_header({'b', 'a'}) returns 'a,b' — sort is always applied."""
        from code_generator.runner.options import build_beta_header

        assert build_beta_header({"b", "a"}) == "a,b"

    def test_default_betas_produce_expected_string(self) -> None:
        """The four default betas produce the byte-exact canonical string."""
        from code_generator.runner.options import build_beta_header

        result = build_beta_header(
            {
                "compact-2026-01-12",
                "context-management-2025-06-27",
                "extended-cache-ttl-2025-04-11",
                "token-efficient-tools-2025-02-19",
            }
        )
        assert result == _DEFAULT_BETA

    def test_single_beta_no_comma(self) -> None:
        """A single beta value is returned as-is with no trailing comma."""
        from code_generator.runner.options import build_beta_header

        assert build_beta_header(["only-one"]) == "only-one"


class TestExtraHeadersKwarg:
    """Tests for extra_headers kwarg in make_agent_options."""

    def test_default_extra_headers_contains_anthropic_beta(self) -> None:
        """When extra_headers is None, anthropic-beta defaults to the canonical string."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert result.extra_headers == {"anthropic-beta": _DEFAULT_BETA}

    def test_default_anthropic_beta_is_byte_exact(self) -> None:
        """The default anthropic-beta value is the exact string, no extra spaces."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert result.extra_headers["anthropic-beta"] == _DEFAULT_BETA

    def test_caller_supplied_extra_headers_overrides_default(self) -> None:
        """Passing explicit extra_headers replaces the default entirely (caller wins)."""
        custom_headers = {"anthropic-beta": "custom-beta-value", "x-custom": "yes"}
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], extra_headers=custom_headers
            )

        assert result.extra_headers == custom_headers

    def test_extra_headers_attribute_exposed_on_result(self) -> None:
        """The returned options object exposes .extra_headers as the expected dict."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert hasattr(result, "extra_headers")
        assert isinstance(result.extra_headers, dict)

    def test_extra_headers_set_as_attribute_on_sdk_result(self) -> None:
        """When SDK is present, extra_headers is set as an attribute on the returned object.

        ClaudeAgentOptions does not yet accept extra_headers in its constructor, so
        make_agent_options attaches it as a post-init attribute instead.
        """
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        # extra_headers must NOT be in the constructor call (SDK doesn't support it yet)
        _, call_kwargs = fake_cls.call_args
        assert "extra_headers" not in call_kwargs
        # extra_headers IS set as an attribute on the returned object
        assert result.extra_headers == {"anthropic-beta": _DEFAULT_BETA}


class TestContextManagementAndCompactBetas:
    """Tests asserting the context-management + compact beta tokens (issue #227)."""

    def test_default_beta_headers_contains_context_management_token(self) -> None:
        """_default_beta_headers() output contains 'context-management-2025-06-27'."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            beta = options_mod._default_beta_headers()["anthropic-beta"]

        assert "context-management-2025-06-27" in beta.split(",")

    def test_default_beta_headers_contains_compact_token(self) -> None:
        """_default_beta_headers() output contains 'compact-2026-01-12'."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            beta = options_mod._default_beta_headers()["anthropic-beta"]

        assert "compact-2026-01-12" in beta.split(",")

    def test_make_agent_options_emits_both_new_tokens(self) -> None:
        """make_agent_options(allowed_tools=[]) header carries both new beta tokens."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=[])

        tokens = result.extra_headers["anthropic-beta"].split(",")
        assert "context-management-2025-06-27" in tokens
        assert "compact-2026-01-12" in tokens

    def test_module_constants_match_token_strings(self) -> None:
        """_FEATURE_BETA_CONTEXT_MANAGEMENT and _FEATURE_BETA_COMPACT match canonical tokens."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)

            assert options_mod._FEATURE_BETA_CONTEXT_MANAGEMENT == "context-management-2025-06-27"
            assert options_mod._FEATURE_BETA_COMPACT == "compact-2026-01-12"

    def test_droppable_features_includes_both_new_betas(self) -> None:
        """_DROPPABLE_FEATURES contains both beta tokens for retry-loop fallback."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)

            assert "context-management-2025-06-27" in options_mod._DROPPABLE_FEATURES
            assert "compact-2026-01-12" in options_mod._DROPPABLE_FEATURES

    def test_fallback_desc_has_entries_for_both_new_betas(self) -> None:
        """_FEATURE_FALLBACK_DESC has human-readable entries for both new betas."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)

            assert "context-management-2025-06-27" in options_mod._FEATURE_FALLBACK_DESC
            assert "compact-2026-01-12" in options_mod._FEATURE_FALLBACK_DESC


# ---------------------------------------------------------------------------
# Tests for cache_control kwarg and probe_cache_ttl_support (issue #160)
# ---------------------------------------------------------------------------

_DEFAULT_CACHE_CONTROL = {"type": "ephemeral", "ttl": "1h"}
_FALLBACK_CACHE_CONTROL = {"type": "ephemeral", "ttl": "5m"}


class TestCacheControlKwarg:
    """Tests for cache_control kwarg in make_agent_options."""

    def test_default_cache_control_equals_ephemeral_1h(self) -> None:
        """When cache_control is None, default equals {"type": "ephemeral", "ttl": "1h"}."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert result.cache_control == _DEFAULT_CACHE_CONTROL

    def test_sdk_rejection_of_ttl_1h_falls_back_to_5m_with_warning(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """When SDK raises TypeError on cache_control probe, options build with ttl='5m' and WARNING is logged."""
        import logging

        def raising_on_cache_control(**kwargs: object) -> MagicMock:
            if "cache_control" in kwargs:
                raise TypeError("cache_control kwarg not supported by this SDK version")
            return MagicMock()

        fake_sdk = MagicMock(ClaudeAgentOptions=raising_on_cache_control)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            with caplog.at_level(logging.WARNING, logger="code_generator.runner.options"):
                result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert result.cache_control == _FALLBACK_CACHE_CONTROL
        warning_records = [r for r in caplog.records if r.levelno >= logging.WARNING]
        assert len(warning_records) >= 1

    def test_caller_supplied_cache_control_passed_through_unchanged(self) -> None:
        """Caller-supplied cache_control is used as-is; no probe or fallback is applied."""
        custom = {"type": "ephemeral", "ttl": "30m"}
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"], cache_control=custom)

        assert result.cache_control == custom

    def test_cache_control_attribute_exposed_on_result(self) -> None:
        """The returned options object exposes .cache_control as the resolved dict."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert hasattr(result, "cache_control")
        assert isinstance(result.cache_control, dict)


class TestProbeCacheTtlSupport:
    """Tests for the probe_cache_ttl_support helper."""

    def test_returns_1h_when_sdk_accepts_it(self) -> None:
        """probe_cache_ttl_support returns '1h' when SDK constructor accepts the probe call."""
        import logging

        fake_opts = MagicMock()
        fake_sdk = MagicMock(ClaudeAgentOptions=MagicMock(return_value=fake_opts))

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            logger = logging.getLogger("test")
            result = options_mod.probe_cache_ttl_support(logger)

        assert result == "1h"

    def test_returns_5m_when_sdk_raises_type_error(self) -> None:
        """probe_cache_ttl_support returns '5m' when SDK raises TypeError on the probe."""

        def always_raise(**kwargs: object) -> None:
            raise TypeError("not supported")

        fake_sdk = MagicMock(ClaudeAgentOptions=always_raise)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import logging

            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            logger = logging.getLogger("test")
            result = options_mod.probe_cache_ttl_support(logger)

        assert result == "5m"

    def test_returns_5m_when_sdk_raises_value_error(self) -> None:
        """probe_cache_ttl_support returns '5m' when SDK raises ValueError on the probe."""

        def always_raise(**kwargs: object) -> None:
            raise ValueError("invalid ttl")

        fake_sdk = MagicMock(ClaudeAgentOptions=always_raise)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import logging

            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            logger = logging.getLogger("test")
            result = options_mod.probe_cache_ttl_support(logger)

        assert result == "5m"

    def test_result_cached_to_avoid_warning_spam(self, caplog: pytest.LogCaptureFixture) -> None:
        """probe_cache_ttl_support emits WARNING at most once (module-level cache)."""
        import logging

        call_count = 0

        def raising_cls(**kwargs: object) -> None:
            nonlocal call_count
            call_count += 1
            raise TypeError("not supported")

        fake_sdk = MagicMock(ClaudeAgentOptions=raising_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            logger = logging.getLogger("code_generator.runner.options")
            with caplog.at_level(logging.WARNING, logger="code_generator.runner.options"):
                options_mod.probe_cache_ttl_support(logger)
                options_mod.probe_cache_ttl_support(logger)
                options_mod.probe_cache_ttl_support(logger)

        # SDK was called exactly once (result was cached)
        assert call_count == 1
        warning_records = [r for r in caplog.records if r.levelno >= logging.WARNING]
        assert len(warning_records) == 1


# ---------------------------------------------------------------------------
# Tests for system_prompt kwarg and build_system_prompt helper (issue #161)
# ---------------------------------------------------------------------------

_DEFAULT_SYSTEM_PROMPT = {
    "type": "preset",
    "preset": "claude_code",
    "append": "",
    "exclude_dynamic_sections": True,
}


class TestBuildSystemPrompt:
    """Unit tests for the pure helper build_system_prompt."""

    def test_default_system_prompt_equals_full_4_key_dict(self) -> None:
        """build_system_prompt() with no args returns the exact 4-key dict with exclude_dynamic_sections=True."""
        from code_generator.runner.options import build_system_prompt

        result = build_system_prompt()
        assert result == _DEFAULT_SYSTEM_PROMPT

    def test_build_system_prompt_append_parameter_propagated(self) -> None:
        """build_system_prompt('extra notes') returns dict whose append == 'extra notes'."""
        from code_generator.runner.options import build_system_prompt

        result = build_system_prompt("extra notes")
        assert result["append"] == "extra notes"

    def test_build_system_prompt_all_keys_present(self) -> None:
        """build_system_prompt always returns all 4 required keys."""
        from code_generator.runner.options import build_system_prompt

        result = build_system_prompt("notes")
        assert set(result.keys()) == {"type", "preset", "append", "exclude_dynamic_sections"}

    def test_build_system_prompt_exclude_dynamic_sections_is_true(self) -> None:
        """exclude_dynamic_sections is always True regardless of append value."""
        from code_generator.runner.options import build_system_prompt

        assert build_system_prompt("anything")["exclude_dynamic_sections"] is True

    def test_build_system_prompt_preset_is_claude_code(self) -> None:
        """preset field is always 'claude_code'."""
        from code_generator.runner.options import build_system_prompt

        assert build_system_prompt()["preset"] == "claude_code"


class TestSystemPromptKwarg:
    """Tests for system_prompt kwarg in make_agent_options."""

    def test_default_system_prompt_is_full_preset_dict_when_none(self) -> None:
        """When system_prompt is None, options.system_prompt equals the full 4-key dict."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert result.system_prompt == _DEFAULT_SYSTEM_PROMPT

    def test_string_system_prompt_round_trips_unchanged(self) -> None:
        """Passing a str system_prompt forwards it unchanged to the options object."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], system_prompt="my raw prompt"
            )

        assert result.system_prompt == "my raw prompt"

    def test_dict_system_prompt_forwarded_unchanged(self) -> None:
        """Passing a dict system_prompt forwards it unchanged to the options object."""
        custom_prompt = {"type": "custom", "content": "override"}
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], system_prompt=custom_prompt
            )

        assert result.system_prompt == custom_prompt

    def test_system_prompt_not_in_sdk_constructor_call(self) -> None:
        """system_prompt is set as a post-init attribute, not passed to the SDK constructor."""
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            options_mod.make_agent_options(allowed_tools=["Read"])

        _, call_kwargs = fake_cls.call_args
        assert "system_prompt" not in call_kwargs

    def test_system_prompt_set_as_attribute_on_sdk_result(self) -> None:
        """When SDK is present, system_prompt is set as an attribute on the returned object."""
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert result.system_prompt == _DEFAULT_SYSTEM_PROMPT


# ---------------------------------------------------------------------------
# Tests for thinking and output_config kwargs (issue #162)
# ---------------------------------------------------------------------------


class TestThinkingKwarg:
    """Tests for thinking kwarg in make_agent_options."""

    def test_thinking_adaptive_round_trips_on_fallback(self) -> None:
        """thinking={"type": "adaptive"} is exposed as .thinking on fallback options."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], thinking={"type": "adaptive"}
            )

        assert result.thinking == {"type": "adaptive"}

    def test_thinking_defaults_to_none_when_omitted(self) -> None:
        """Omitting thinking leaves .thinking as None (getattr default)."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert getattr(result, "thinking", None) is None

    def test_thinking_budget_tokens_emits_deprecation_warning(self) -> None:
        """passing thinking={"budget_tokens": 10_000} still round-trips but emits DeprecationWarning."""
        import warnings

        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                result = options_mod.make_agent_options(
                    allowed_tools=["Read"], thinking={"budget_tokens": 10_000}
                )

        assert result.thinking == {"budget_tokens": 10_000}
        deprecation_warnings = [w for w in caught if issubclass(w.category, DeprecationWarning)]
        assert len(deprecation_warnings) >= 1
        assert "budget_tokens" in str(deprecation_warnings[0].message).lower()

    def test_thinking_set_as_attribute_on_sdk_result(self) -> None:
        """When SDK is present, thinking is set as a post-init attribute on the returned object."""
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], thinking={"type": "adaptive"}
            )

        _, call_kwargs = fake_cls.call_args
        assert "thinking" not in call_kwargs
        assert result.thinking == {"type": "adaptive"}


class TestOutputConfigKwarg:
    """Tests for output_config kwarg in make_agent_options."""

    def test_output_config_effort_xhigh_round_trips_on_fallback(self) -> None:
        """output_config={"effort": "xhigh"} is exposed as .output_config on fallback options."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], output_config={"effort": "xhigh"}
            )

        assert result.output_config == {"effort": "xhigh"}

    def test_output_config_defaults_to_none_when_omitted(self) -> None:
        """Omitting output_config leaves .output_config as None (getattr default)."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert getattr(result, "output_config", None) is None

    def test_output_config_set_as_attribute_on_sdk_result(self) -> None:
        """When SDK is present, output_config is set as a post-init attribute on the returned object."""
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], output_config={"effort": "medium"}
            )

        _, call_kwargs = fake_cls.call_args
        assert "output_config" not in call_kwargs
        assert result.output_config == {"effort": "medium"}


class TestThinkingAndOutputConfigBothOmitted:
    """Both thinking and output_config omitted — neither attribute is set."""

    def test_both_omitted_neither_attribute_set(self) -> None:
        """When both thinking and output_config are omitted, getattr returns None for each."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert getattr(result, "thinking", None) is None
        assert getattr(result, "output_config", None) is None


# ---------------------------------------------------------------------------
# Tests for task_budget kwarg (issue #163)
# ---------------------------------------------------------------------------

_TASK_BUDGET_BETA_HEADER = (
    "compact-2026-01-12,context-management-2025-06-27,"
    "extended-cache-ttl-2025-04-11,task-budgets-2026-03-13,"
    "token-efficient-tools-2025-02-19"
)


class TestTaskBudgetKwarg:
    """Tests for task_budget kwarg in make_agent_options (issue #163)."""

    def test_task_budget_256000_produces_exact_nested_dict(self) -> None:
        """task_budget=256_000 produces output_config['task_budget'] == {"type": "tokens", "total": 256000}."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"], task_budget=256_000)

        assert result.output_config["task_budget"] == {"type": "tokens", "total": 256_000}

    def test_task_budget_set_produces_alphabetical_beta_header(self) -> None:
        """When task_budget is set, anthropic-beta includes task-budgets-2026-03-13 alphabetically."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"], task_budget=256_000)

        assert result.extra_headers["anthropic-beta"] == _TASK_BUDGET_BETA_HEADER

    def test_task_budget_none_leaves_both_fields_untouched(self) -> None:
        """task_budget=None (default) leaves output_config as None and anthropic-beta header unchanged."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert getattr(result, "output_config", None) is None
        assert result.extra_headers["anthropic-beta"] == _DEFAULT_BETA

    def test_task_budget_coexists_with_caller_supplied_output_config(self) -> None:
        """When task_budget is set alongside output_config={'effort': 'medium'}, both keys coexist."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"],
                output_config={"effort": "medium"},
                task_budget=128_000,
            )

        assert result.output_config["effort"] == "medium"
        assert result.output_config["task_budget"] == {"type": "tokens", "total": 128_000}


# ---------------------------------------------------------------------------
# Tests for context_management kwarg and build_context_management_block (issue #164)
# ---------------------------------------------------------------------------


def _canonical_context_management() -> dict:
    """Return the §6 canonical context_management dict assembled from module constants."""
    from code_generator.runner.options import (
        _CONTEXT_MANAGEMENT_CLEAR_AT_LEAST_INPUT_TOKENS,
        _CONTEXT_MANAGEMENT_CLEAR_TRIGGER_INPUT_TOKENS,
        _CONTEXT_MANAGEMENT_COMPACT_INSTRUCTIONS,
        _CONTEXT_MANAGEMENT_EXCLUDE_TOOLS,
        _CONTEXT_MANAGEMENT_INPUT_TOKENS,
        _CONTEXT_MANAGEMENT_TOOL_USE_KEEP,
    )

    return {
        "edits": [
            {
                "type": "compact_20260112",
                "trigger": {
                    "type": "input_tokens",
                    "value": _CONTEXT_MANAGEMENT_INPUT_TOKENS,
                },
                "pause_after_compaction": True,
                "custom_instructions": _CONTEXT_MANAGEMENT_COMPACT_INSTRUCTIONS,
            }
        ],
        "tools": [
            {
                "type": "clear_tool_uses_20250919",
                "trigger": {
                    "type": "input_tokens",
                    "value": _CONTEXT_MANAGEMENT_CLEAR_TRIGGER_INPUT_TOKENS,
                },
                "keep": {"type": "tool_uses", "value": _CONTEXT_MANAGEMENT_TOOL_USE_KEEP},
                "clear_at_least": {
                    "type": "input_tokens",
                    "value": _CONTEXT_MANAGEMENT_CLEAR_AT_LEAST_INPUT_TOKENS,
                },
                "exclude_tools": list(_CONTEXT_MANAGEMENT_EXCLUDE_TOOLS),
            }
        ],
    }


class TestBuildContextManagementBlock:
    """Unit tests for the §6 canonical context_management block (issue #234)."""

    def test_returns_full_canonical_block(self) -> None:
        """build_context_management_block() emits the full §6 dict with every sub-field."""
        from code_generator.runner.options import build_context_management_block

        assert build_context_management_block() == _canonical_context_management()

    def test_clear_tool_uses_keeps_six_tool_use_groups(self) -> None:
        """tools[0].keep.value=6 (doubled from prior keep=3 to retain longer agentic depth)."""
        from code_generator.runner.options import build_context_management_block

        tool = build_context_management_block()["tools"][0]
        assert tool["keep"] == {"type": "tool_uses", "value": 6}

    def test_clear_tool_uses_trigger_at_input_tokens_100000(self) -> None:
        """tools[0] is triggered earlier than the compact edit, at input_tokens=100_000."""
        from code_generator.runner.options import build_context_management_block

        tool = build_context_management_block()["tools"][0]
        assert tool["trigger"] == {"type": "input_tokens", "value": 100_000}

    def test_clear_tool_uses_carries_clear_at_least_input_tokens_10000(self) -> None:
        """tools[0].clear_at_least guarantees compactor reclaims at least 10k input tokens."""
        from code_generator.runner.options import build_context_management_block

        tool = build_context_management_block()["tools"][0]
        assert tool["clear_at_least"] == {"type": "input_tokens", "value": 10_000}

    def test_clear_tool_uses_excludes_memory_and_read(self) -> None:
        """exclude_tools=['memory','Read'] (cycle invariant — must never regress)."""
        from code_generator.runner.options import build_context_management_block

        tool = build_context_management_block()["tools"][0]
        assert tool["exclude_tools"] == ["memory", "Read"]

    def test_compact_pause_after_compaction_is_true(self) -> None:
        """edits[0].pause_after_compaction=True so cycle_loop can resume in a single roundtrip."""
        from code_generator.runner.options import build_context_management_block

        edit = build_context_management_block()["edits"][0]
        assert edit["pause_after_compaction"] is True

    def test_compact_trigger_at_input_tokens_150000(self) -> None:
        """edits[0] is triggered at input_tokens=150_000 (existing threshold preserved)."""
        from code_generator.runner.options import build_context_management_block

        edit = build_context_management_block()["edits"][0]
        assert edit["trigger"] == {"type": "input_tokens", "value": 150_000}

    def test_compact_custom_instructions_is_non_empty_string(self) -> None:
        """edits[0].custom_instructions is a non-empty str (Anthropic uses it verbatim)."""
        from code_generator.runner.options import build_context_management_block

        edit = build_context_management_block()["edits"][0]
        assert isinstance(edit["custom_instructions"], str)
        assert edit["custom_instructions"].strip() != ""

    def test_compact_custom_instructions_wraps_artefacts_in_summary_tags(self) -> None:
        """custom_instructions wraps the four required artefacts inside <summary> tags."""
        from code_generator.runner.options import build_context_management_block

        text = build_context_management_block()["edits"][0]["custom_instructions"]
        assert "<summary>" in text and "</summary>" in text
        lowered = text.lower()
        for artefact in ("issue", "acceptance criteria", "file", "test"):
            assert artefact in lowered, (
                f"custom_instructions missing artefact mention: {artefact!r}"
            )


class TestContextManagementDropFeatureFallbacks:
    """SDK-rejection retry-loop must strip new sub-fields one at a time (issue #234)."""

    def _make_state(self, cm: dict) -> tuple[dict, dict, str, dict, dict]:
        """Build the 5-tuple shape that _drop_feature accepts/returns."""
        headers = {"anthropic-beta": ""}
        cache_control: dict = {"type": "ephemeral", "ttl": "1h"}
        system_prompt = "x"
        output_config: dict = {}
        return headers, cache_control, system_prompt, output_config, cm

    def _drop(self, feature: str, cm: dict) -> dict:
        """Run _drop_feature and assert the returned context_management is non-None."""
        import code_generator.runner.options as options_mod

        headers, cc, sp, oc, cm_in = self._make_state(cm)
        _, _, _, _, cm_out = options_mod._drop_feature(feature, headers, cc, sp, oc, cm_in)
        assert isinstance(cm_out, dict)
        return cm_out

    def test_drop_pause_after_compaction_strips_field_from_compact_edit(self) -> None:
        """_drop_feature('pause_after_compaction') removes only that key from edits[0]."""
        import code_generator.runner.options as options_mod

        cm = options_mod.build_context_management_block()
        cm_out = self._drop(options_mod._FEATURE_PAUSE_AFTER_COMPACTION, cm)

        assert "pause_after_compaction" not in cm_out["edits"][0]
        # Other fields preserved.
        assert cm_out["edits"][0]["trigger"]["value"] == 150_000
        assert cm_out["edits"][0]["custom_instructions"]
        assert cm_out["tools"] == cm["tools"]

    def test_drop_clear_at_least_strips_field_from_clear_tool_uses(self) -> None:
        """_drop_feature('clear_at_least') removes only that key from tools[0]."""
        import code_generator.runner.options as options_mod

        cm = options_mod.build_context_management_block()
        cm_out = self._drop(options_mod._FEATURE_CLEAR_AT_LEAST, cm)

        assert "clear_at_least" not in cm_out["tools"][0]
        assert cm_out["tools"][0]["keep"]["value"] == 6
        assert cm_out["edits"] == cm["edits"]

    def test_drop_exclude_tools_strips_field_from_clear_tool_uses(self) -> None:
        """_drop_feature('exclude_tools') removes only that key from tools[0]."""
        import code_generator.runner.options as options_mod

        cm = options_mod.build_context_management_block()
        cm_out = self._drop(options_mod._FEATURE_EXCLUDE_TOOLS, cm)

        assert "exclude_tools" not in cm_out["tools"][0]
        assert cm_out["edits"] == cm["edits"]

    def test_drop_compact_custom_instructions_strips_field_from_compact_edit(self) -> None:
        """_drop_feature('custom_instructions') removes only that key from edits[0]."""
        import code_generator.runner.options as options_mod

        cm = options_mod.build_context_management_block()
        cm_out = self._drop(options_mod._FEATURE_CUSTOM_INSTRUCTIONS, cm)

        assert "custom_instructions" not in cm_out["edits"][0]
        assert cm_out["edits"][0]["pause_after_compaction"] is True

    def test_droppable_features_includes_new_subfield_keys(self) -> None:
        """Each new sub-field key is registered so the retry loop will degrade gracefully."""
        import code_generator.runner.options as options_mod

        for feature in (
            options_mod._FEATURE_PAUSE_AFTER_COMPACTION,
            options_mod._FEATURE_CLEAR_AT_LEAST,
            options_mod._FEATURE_EXCLUDE_TOOLS,
            options_mod._FEATURE_CUSTOM_INSTRUCTIONS,
        ):
            assert feature in options_mod._DROPPABLE_FEATURES
            assert feature in options_mod._FEATURE_FALLBACK_DESC

    def test_build_with_retry_drops_pause_after_compaction_when_sdk_rejects_it(self) -> None:
        """When the SDK raises 'unknown keyword pause_after_compaction', the field is dropped and retry succeeds."""
        import code_generator.runner.options as options_mod

        attempts: list[dict | None] = []

        class _FakeSDK:
            """Mimic ClaudeAgentOptions: rejects context_management with pause_after_compaction."""

            def __init__(self, **_kwargs: object) -> None:
                pass

            def __setattr__(self, name: str, value: object) -> None:
                if name == "context_management":
                    cm = value if isinstance(value, dict) else None
                    attempts.append(cm)
                    if isinstance(cm, dict):
                        edits = cm.get("edits") or []
                        if edits and "pause_after_compaction" in edits[0]:
                            raise TypeError("unknown keyword pause_after_compaction")
                object.__setattr__(self, name, value)

        cm = options_mod.build_context_management_block()
        result = options_mod._build_with_retry(
            _FakeSDK,
            allowed_tools=[],
            extra_headers={"anthropic-beta": ""},
            cache_control={"type": "ephemeral", "ttl": "1h"},
            system_prompt="x",
            output_config=None,
            context_management=cm,
            thinking=None,
            mcp_servers=None,
        )

        # First attempt failed (had the field); second succeeded (field stripped).
        assert len(attempts) >= 2
        first_attempt = attempts[0]
        assert first_attempt is not None
        assert "pause_after_compaction" in first_attempt["edits"][0]
        result_cm = result.context_management
        assert isinstance(result_cm, dict)
        assert "pause_after_compaction" not in result_cm["edits"][0]
        # Other §6 fields preserved.
        assert result_cm["edits"][0]["custom_instructions"]
        assert result_cm["tools"][0]["exclude_tools"] == ["memory", "Read"]


class TestContextManagementCachePrefixStability:
    """Cache-coherence guard: §6 changes must not drift the system_prompt+tools cache prefix (issue #234)."""

    def test_system_prompt_bytes_unchanged_after_canonical_block_injection(self) -> None:
        """build_system_prompt() bytes are byte-identical regardless of context_management content."""
        from code_generator.runner.options import build_system_prompt

        assert build_system_prompt() == build_system_prompt()
        # exclude_dynamic_sections must still be set so the cache prefix is stable across sessions.
        assert build_system_prompt()["exclude_dynamic_sections"] is True


class TestContextManagementKwarg:
    """Tests for context_management and context_management_enabled kwargs in make_agent_options."""

    def test_enabled_flag_true_injects_canonical_block(self) -> None:
        """context_management_enabled=True injects the §6 canonical block."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], context_management_enabled=True
            )

        assert result.context_management == _canonical_context_management()

    def test_caller_supplied_dict_overrides_enabled_flag(self) -> None:
        """Explicitly supplied context_management dict is forwarded unchanged even when enabled=True."""
        custom_block = {"edits": [], "tools": [{"type": "custom_tool"}]}
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"],
                context_management=custom_block,
                context_management_enabled=True,
            )

        assert result.context_management == custom_block

    def test_defaults_leave_context_management_unset(self) -> None:
        """When both context_management and context_management_enabled use defaults, .context_management is None."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert getattr(result, "context_management", None) is None

    def test_context_management_set_as_attribute_on_sdk_result(self) -> None:
        """When SDK is present, context_management is set as a post-init attribute on the returned object."""
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"], context_management_enabled=True
            )

        _, call_kwargs = fake_cls.call_args
        assert "context_management" not in call_kwargs
        assert "context_management_enabled" not in call_kwargs
        assert result.context_management == _canonical_context_management()


# ---------------------------------------------------------------------------
# Tests for mcp_servers kwarg (issue #165)
# ---------------------------------------------------------------------------


class TestMcpServersKwarg:
    """Tests for mcp_servers kwarg in make_agent_options."""

    def test_mcp_servers_dict_round_trips_on_fallback(self) -> None:
        """mcp_servers={"codebase_memory": {"command": "x"}} is exposed as .mcp_servers on fallback options."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"],
                mcp_servers={"codebase_memory": {"command": "x"}},
            )

        assert result.mcp_servers == {"codebase_memory": {"command": "x"}}

    def test_mcp_servers_defaults_to_none_when_omitted(self) -> None:
        """Omitting mcp_servers leaves .mcp_servers as None (getattr default)."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(allowed_tools=["Read"])

        assert getattr(result, "mcp_servers", None) is None

    def test_mcp_servers_not_in_sdk_constructor_call(self) -> None:
        """mcp_servers is set as a post-init attribute, not passed to the SDK constructor."""
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            result = options_mod.make_agent_options(
                allowed_tools=["Read"],
                mcp_servers={"codebase_memory": {"command": "x"}},
            )

        _, call_kwargs = fake_cls.call_args
        assert "mcp_servers" not in call_kwargs
        assert result.mcp_servers == {"codebase_memory": {"command": "x"}}


# ---------------------------------------------------------------------------
# Tests for feature-detection fallbacks / retry loop (issue #166)
# ---------------------------------------------------------------------------


class _RejectingOptions:
    """Fake options object that raises on specific feature attribute assignment.

    Used to simulate SDK rejection of a feature without crashing. The constructor
    always succeeds; rejection is signalled via TypeError on attribute assignment.
    """

    def __init__(self, reject_feature: str) -> None:
        object.__setattr__(self, "_reject", reject_feature)

    def __setattr__(self, name: str, value: object) -> None:
        reject: str = object.__getattribute__(self, "_reject")
        if name == "extra_headers" and isinstance(value, dict):
            beta = value.get("anthropic-beta", "")
            if reject in beta:
                raise TypeError(f"anthropic_beta {reject} not supported")
        if name == "context_management" and value is not None and reject == "context_management":
            raise TypeError("context_management not supported")
        if (
            name == "system_prompt"
            and isinstance(value, dict)
            and reject == "exclude_dynamic_sections"
            and "exclude_dynamic_sections" in value
        ):
            raise TypeError("exclude_dynamic_sections unknown keyword")
        object.__setattr__(self, name, value)


def _make_rejecting_sdk(reject_feature: str) -> MagicMock:
    """Return a fake claude_agent_sdk whose ClaudeAgentOptions rejects one feature."""

    def fake_cls(**kwargs: object) -> _RejectingOptions:
        return _RejectingOptions(reject_feature)

    return MagicMock(ClaudeAgentOptions=fake_cls)


class TestFeatureDetectionFallbacks:
    """Tests for the feature-detection retry loop in make_agent_options (issue #166)."""

    def test_sdk_rejects_extended_cache_ttl_warning_logged_and_beta_dropped(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """SDK mock rejects extended-cache-ttl-2025-04-11 → WARNING, beta dropped, ttl='5m', success."""
        import logging

        fake_sdk = _make_rejecting_sdk("extended-cache-ttl-2025-04-11")
        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            with caplog.at_level(logging.WARNING, logger="code_generator.runner.options"):
                result = options_mod.make_agent_options(allowed_tools=["Read"])

        # Beta header must NOT contain the rejected feature
        assert "extended-cache-ttl-2025-04-11" not in result.extra_headers.get("anthropic-beta", "")
        # TTL must fall back to '5m'
        assert result.cache_control["ttl"] == "5m"
        # At least one WARNING must be logged
        warnings = [r for r in caplog.records if r.levelno >= logging.WARNING]
        assert len(warnings) >= 1
        assert "extended-cache-ttl-2025-04-11" in warnings[0].message

    def test_sdk_rejects_task_budgets_beta_warning_and_task_budget_key_removed(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """SDK mock rejects task-budgets-2026-03-13 → WARNING, header dropped, task_budget removed, other keys kept."""
        import logging

        fake_sdk = _make_rejecting_sdk("task-budgets-2026-03-13")
        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            with caplog.at_level(logging.WARNING, logger="code_generator.runner.options"):
                result = options_mod.make_agent_options(
                    allowed_tools=["Read"],
                    task_budget=128_000,
                    output_config={"effort": "medium"},
                )

        # Beta header must NOT contain the rejected feature
        assert "task-budgets-2026-03-13" not in result.extra_headers.get("anthropic-beta", "")
        # task_budget key must be removed from output_config
        assert "task_budget" not in (result.output_config or {})
        # Other output_config keys must be preserved
        assert result.output_config is not None
        assert result.output_config.get("effort") == "medium"
        # At least one WARNING must be logged
        warnings = [r for r in caplog.records if r.levelno >= logging.WARNING]
        assert len(warnings) >= 1
        assert "task-budgets-2026-03-13" in warnings[0].message

    def test_sdk_rejects_context_management_warning_logged_and_attribute_dropped(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """SDK mock rejects context_management → WARNING logged, attribute dropped, construction succeeds."""
        import logging

        fake_sdk = _make_rejecting_sdk("context_management")
        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            with caplog.at_level(logging.WARNING, logger="code_generator.runner.options"):
                result = options_mod.make_agent_options(
                    allowed_tools=["Read"], context_management_enabled=True
                )

        # context_management must be dropped (None)
        assert getattr(result, "context_management", None) is None
        # At least one WARNING must be logged
        warnings = [r for r in caplog.records if r.levelno >= logging.WARNING]
        assert len(warnings) >= 1
        assert "context_management" in warnings[0].message

    def test_sdk_rejects_exclude_dynamic_sections_warning_and_key_removed(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """SDK mock rejects exclude_dynamic_sections → WARNING, key removed from system_prompt, other keys kept."""
        import logging

        fake_sdk = _make_rejecting_sdk("exclude_dynamic_sections")
        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            with caplog.at_level(logging.WARNING, logger="code_generator.runner.options"):
                result = options_mod.make_agent_options(allowed_tools=["Read"])

        # exclude_dynamic_sections must be removed from the system_prompt dict
        assert isinstance(result.system_prompt, dict)
        assert "exclude_dynamic_sections" not in result.system_prompt
        # Other system_prompt keys must be preserved
        assert result.system_prompt.get("type") == "preset"
        assert result.system_prompt.get("preset") == "claude_code"
        # At least one WARNING must be logged
        warnings = [r for r in caplog.records if r.levelno >= logging.WARNING]
        assert len(warnings) >= 1
        assert "exclude_dynamic_sections" in warnings[0].message

    def test_all_features_accepted_no_warnings_emitted(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Happy path: all features accepted by SDK → zero WARNING logs emitted."""
        import logging

        # SDK that accepts everything (standard MagicMock — no attribute rejection)
        fake_options = MagicMock()
        fake_cls = MagicMock(return_value=fake_options)
        fake_sdk = MagicMock(ClaudeAgentOptions=fake_cls)

        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            with caplog.at_level(logging.WARNING, logger="code_generator.runner.options"):
                options_mod.make_agent_options(
                    allowed_tools=["Read"],
                    task_budget=128_000,
                    context_management_enabled=True,
                )

        feature_warnings = [
            r
            for r in caplog.records
            if r.levelno >= logging.WARNING and "rejected by SDK" in r.message
        ]
        assert len(feature_warnings) == 0

    def test_warning_emitted_at_most_once_per_process(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Each feature's WARNING is emitted at most once per process (module-level cache)."""
        import logging

        fake_sdk = _make_rejecting_sdk("context_management")
        with patch.dict(sys.modules, {"claude_agent_sdk": fake_sdk}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            with caplog.at_level(logging.WARNING, logger="code_generator.runner.options"):
                # Call three times — WARNING must appear only once
                options_mod.make_agent_options(
                    allowed_tools=["Read"], context_management_enabled=True
                )
                options_mod.make_agent_options(
                    allowed_tools=["Read"], context_management_enabled=True
                )
                options_mod.make_agent_options(
                    allowed_tools=["Read"], context_management_enabled=True
                )

        context_mgmt_warnings = [
            r
            for r in caplog.records
            if r.levelno >= logging.WARNING and "context_management" in r.message
        ]
        assert len(context_mgmt_warnings) == 1


# ---------------------------------------------------------------------------
# Tests for startup log (issue #167)
# ---------------------------------------------------------------------------


@pytest.fixture
def reset_startup_logged() -> object:
    """Reset _startup_logged to False before and after each startup-log test."""
    import code_generator.runner.options as options_mod

    options_mod._startup_logged = False
    yield
    options_mod._startup_logged = False


class TestStartupLog:
    """Tests for the one-line startup visibility log (issue #167)."""

    def test_first_call_emits_startup_log_second_call_does_not(
        self, caplog: pytest.LogCaptureFixture, reset_startup_logged: object
    ) -> None:
        """First make_agent_options() call emits the startup line; second call does not re-emit."""
        import logging

        import code_generator.runner.options as options_mod

        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            with caplog.at_level(logging.INFO, logger="code_generator.runner.options"):
                options_mod.make_agent_options(allowed_tools=["Read"])
                options_mod.make_agent_options(allowed_tools=["Read"])

        startup_records = [r for r in caplog.records if "runner: SDK=" in r.message]
        assert len(startup_records) == 1

    def test_all_features_fallen_back_log_reads_expected_values(
        self, caplog: pytest.LogCaptureFixture, reset_startup_logged: object
    ) -> None:
        """When all features fell back, log reads context_mgmt=no exclude_dynamic_sections=no ttl=5m."""
        import logging
        from unittest.mock import MagicMock

        import code_generator.runner.options as options_mod

        # Simulate opts where all droppable features have been removed
        fake_opts = MagicMock()
        fake_opts.context_management = None
        fake_opts.system_prompt = {"type": "preset", "preset": "claude_code"}
        fake_opts.cache_control = {"type": "ephemeral", "ttl": "5m"}
        fake_opts.extra_headers = {"anthropic-beta": "token-efficient-tools-2025-02-19"}

        with caplog.at_level(logging.INFO, logger="code_generator.runner.options"):
            options_mod._log_startup_once(fake_opts, sdk_available=True)

        record = next(r for r in caplog.records if "runner: SDK=" in r.message)
        assert "context_mgmt=no" in record.message
        assert "exclude_dynamic_sections=no" in record.message
        assert "ttl=5m" in record.message

    def test_sdk_absent_log_reads_unknown_and_betas_none(
        self, caplog: pytest.LogCaptureFixture, reset_startup_logged: object
    ) -> None:
        """When SDK is absent, log reads SDK=unknown and betas=none."""
        import logging

        import code_generator.runner.options as options_mod

        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            with caplog.at_level(logging.INFO, logger="code_generator.runner.options"):
                options_mod.make_agent_options(allowed_tools=["Read"])

        record = next(r for r in caplog.records if "runner: SDK=" in r.message)
        assert "SDK=unknown" in record.message
        assert "betas=none" in record.message


# ---------------------------------------------------------------------------
# assert_required_betas (issue #228)
# ---------------------------------------------------------------------------

_REMEDIATION = "pip install -U claude-agent-sdk"


class TestAssertRequiredBetas:
    """Self-check that both context-management + compact betas are emitted."""

    def test_passes_silently_when_both_betas_present(self) -> None:
        """assert_required_betas() returns None when both tokens are emitted."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)

            assert options_mod.assert_required_betas() is None

    def test_raises_runtime_error_when_context_management_missing(self) -> None:
        """Removing 'context-management-2025-06-27' from _DEFAULT_BETAS triggers RuntimeError."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            patched = options_mod._DEFAULT_BETAS - {"context-management-2025-06-27"}
            with patch.object(options_mod, "_DEFAULT_BETAS", patched):
                with pytest.raises(RuntimeError) as excinfo:
                    options_mod.assert_required_betas()

        assert "context-management-2025-06-27" in str(excinfo.value)
        assert _REMEDIATION in str(excinfo.value)

    def test_raises_runtime_error_when_compact_missing(self) -> None:
        """Removing 'compact-2026-01-12' from _DEFAULT_BETAS triggers RuntimeError."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            patched = options_mod._DEFAULT_BETAS - {"compact-2026-01-12"}
            with patch.object(options_mod, "_DEFAULT_BETAS", patched):
                with pytest.raises(RuntimeError) as excinfo:
                    options_mod.assert_required_betas()

        assert "compact-2026-01-12" in str(excinfo.value)
        assert _REMEDIATION in str(excinfo.value)

    def test_raises_when_both_missing_and_lists_both_tokens(self) -> None:
        """When both betas missing, error message lists both names."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            patched = options_mod._DEFAULT_BETAS - {
                "context-management-2025-06-27",
                "compact-2026-01-12",
            }
            with patch.object(options_mod, "_DEFAULT_BETAS", patched):
                with pytest.raises(RuntimeError) as excinfo:
                    options_mod.assert_required_betas()

        msg = str(excinfo.value)
        assert "context-management-2025-06-27" in msg
        assert "compact-2026-01-12" in msg
        assert _REMEDIATION in msg


# ---------------------------------------------------------------------------
# Tests for compaction_beta_available (issue #235 — soft-reset capability gate)
# ---------------------------------------------------------------------------


class TestCompactionBetaAvailable:
    """compaction_beta_available() reflects whether 'compact-2026-01-12' is emitted."""

    def test_returns_true_when_default_beta_set_includes_compact(self) -> None:
        """With the default beta set, compaction_beta_available() is True."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            assert options_mod.compaction_beta_available() is True

    def test_returns_false_when_compact_beta_dropped(self) -> None:
        """When 'compact-2026-01-12' is absent from _DEFAULT_BETAS, the gate returns False."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            patched = options_mod._DEFAULT_BETAS - {"compact-2026-01-12"}
            with patch.object(options_mod, "_DEFAULT_BETAS", patched):
                # Force a fresh probe (bypass any cached True result from import).
                options_mod._compaction_beta_probe_result = None
                assert options_mod.compaction_beta_available() is False

    def test_result_is_cached_module_level(self) -> None:
        """compaction_beta_available() probes once per process and reuses the cached result."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            options_mod._compaction_beta_probe_result = True
            # Even if the underlying default set is mutated, cached True is returned.
            with patch.object(options_mod, "_DEFAULT_BETAS", frozenset()):
                assert options_mod.compaction_beta_available() is True

    def test_no_network_call_no_subprocess(self) -> None:
        """compaction_beta_available() must not spawn any subprocess or network call."""
        with patch.dict(sys.modules, {"claude_agent_sdk": None}):
            import code_generator.runner.options as options_mod

            importlib.reload(options_mod)
            options_mod._compaction_beta_probe_result = None
            with (
                patch("subprocess.run") as run_mock,
                patch("urllib.request.urlopen") as urlopen_mock,
            ):
                options_mod.compaction_beta_available()
            run_mock.assert_not_called()
            urlopen_mock.assert_not_called()
