"""Tests for code_generator.preflight.

TDD: Red → Green → Refactor.
Covers all 8 acceptance criteria from issue #151.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from code_generator.preflight import PreflightError, run_preflight
from code_generator.repo_info import RepoInfo

_REMEDIATION = "pip install -U claude-agent-sdk"

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SSH_CONFIG_CONTENT = """\
Host ey
    HostName github.ey.com
    User git
    IdentityFile ~/.ssh/id_rsa_ey
"""


@pytest.fixture()
def ssh_config(tmp_path: Path) -> Path:
    """Write a minimal SSH config with an alias and return its path."""
    p = tmp_path / "ssh_config"
    p.write_text(SSH_CONFIG_CONTENT, encoding="utf-8")
    return p


def _cp(returncode: int = 0, stdout: str = "", stderr: str = "") -> MagicMock:
    """Build a fake CompletedProcess for subprocess.run mocking."""
    cp = MagicMock(spec=subprocess.CompletedProcess)
    cp.returncode = returncode
    cp.stdout = stdout
    cp.stderr = stderr
    return cp


# ---------------------------------------------------------------------------
# PreflightError
# ---------------------------------------------------------------------------


class TestPreflightError:
    def test_is_exception_subclass(self) -> None:
        assert issubclass(PreflightError, Exception)

    def test_stores_reason_and_fix_command(self) -> None:
        err = PreflightError(
            reason="not authenticated",
            fix_command="gh auth login --hostname github.com",
        )
        assert err.reason == "not authenticated"
        assert err.fix_command == "gh auth login --hostname github.com"

    def test_str_includes_reason(self) -> None:
        err = PreflightError(reason="no origin remote", fix_command="git remote add origin <url>")
        assert "no origin remote" in str(err)


# ---------------------------------------------------------------------------
# _get_origin_url (private helper — tested via subprocess mock)
# ---------------------------------------------------------------------------


class TestGetOriginUrl:
    def test_returns_stripped_url_on_success(self, tmp_path: Path) -> None:
        from code_generator.preflight import _get_origin_url

        with patch("code_generator.preflight.subprocess") as mock_sp:
            mock_sp.run.return_value = _cp(stdout="https://github.com/o/r.git\n")
            url = _get_origin_url(tmp_path)

        assert url == "https://github.com/o/r.git"

    def test_raises_preflight_error_when_origin_missing(self, tmp_path: Path) -> None:
        from code_generator.preflight import _get_origin_url

        with patch("code_generator.preflight.subprocess") as mock_sp:
            mock_sp.run.return_value = _cp(returncode=128, stderr="fatal: No such remote 'origin'")
            with pytest.raises(PreflightError) as exc_info:
                _get_origin_url(tmp_path)

        err = exc_info.value
        assert "git remote add origin" in err.fix_command

    def test_calls_git_remote_get_url_origin(self, tmp_path: Path) -> None:
        from code_generator.preflight import _get_origin_url

        with patch("code_generator.preflight.subprocess") as mock_sp:
            mock_sp.run.return_value = _cp(stdout="https://github.com/o/r.git\n")
            _get_origin_url(tmp_path)

        call_args = mock_sp.run.call_args
        assert "git" in call_args[0][0]
        assert "remote" in call_args[0][0]
        assert "get-url" in call_args[0][0]
        assert "origin" in call_args[0][0]


# ---------------------------------------------------------------------------
# run_preflight — success for github.com
# ---------------------------------------------------------------------------


class TestRunPreflightGithubComSuccess:
    def test_returns_repo_info_on_https_url(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch("code_generator.preflight._run_gh", return_value=_cp()),
            patch("code_generator.preflight.subprocess.run", return_value=_cp()),
        ):
            result = run_preflight(tmp_path)

        assert result == RepoInfo(host="github.com", owner="owner", name="repo")

    def test_runs_all_three_gh_checks_on_success(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch("code_generator.preflight._run_gh", return_value=_cp()) as mock_gh,
            patch("code_generator.preflight.subprocess.run", return_value=_cp()),
        ):
            run_preflight(tmp_path)

        # auth + labels go through _run_gh; repo view uses subprocess.run directly
        assert mock_gh.call_count == 2

    def test_passes_correct_hostname_to_gh(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch("code_generator.preflight._run_gh", return_value=_cp()) as mock_gh,
            patch("code_generator.preflight.subprocess.run", return_value=_cp()),
        ):
            run_preflight(tmp_path)

        hostnames = {call.kwargs["hostname"] for call in mock_gh.call_args_list}
        assert hostnames == {"github.com"}


# ---------------------------------------------------------------------------
# run_preflight — success for GitHub Enterprise Server (GHES)
# ---------------------------------------------------------------------------


class TestRunPreflightGhesSuccess:
    def test_returns_repo_info_for_ghes_host(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://ghes.corp.internal/org/project.git",
            ),
            patch("code_generator.preflight._run_gh", return_value=_cp()),
            patch("code_generator.preflight.subprocess.run", return_value=_cp()),
        ):
            result = run_preflight(tmp_path)

        assert result == RepoInfo(host="ghes.corp.internal", owner="org", name="project")

    def test_passes_ghes_hostname_to_gh_calls(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://ghes.corp.internal/org/project.git",
            ),
            patch("code_generator.preflight._run_gh", return_value=_cp()) as mock_gh,
            patch("code_generator.preflight.subprocess.run", return_value=_cp()),
        ):
            run_preflight(tmp_path)

        hostnames = {call.kwargs["hostname"] for call in mock_gh.call_args_list}
        assert hostnames == {"ghes.corp.internal"}


# ---------------------------------------------------------------------------
# run_preflight — missing origin
# ---------------------------------------------------------------------------


class TestRunPreflightMissingOrigin:
    def test_raises_preflight_error_when_no_origin_remote(self, tmp_path: Path) -> None:
        with patch("code_generator.preflight.subprocess") as mock_sp:
            mock_sp.run.return_value = _cp(returncode=128, stderr="fatal: No such remote 'origin'")
            with pytest.raises(PreflightError) as exc_info:
                run_preflight(tmp_path)

        assert "git remote add origin" in exc_info.value.fix_command

    def test_gh_checks_not_called_when_origin_missing(self, tmp_path: Path) -> None:
        with (
            patch("code_generator.preflight.subprocess") as mock_sp,
            patch("code_generator.preflight._run_gh") as mock_gh,
        ):
            mock_sp.run.return_value = _cp(returncode=128, stderr="no origin")
            with pytest.raises(PreflightError):
                run_preflight(tmp_path)

        mock_gh.assert_not_called()


# ---------------------------------------------------------------------------
# run_preflight — missing auth
# ---------------------------------------------------------------------------


class TestRunPreflightMissingAuth:
    def test_raises_preflight_error_with_login_fix_command(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch(
                "code_generator.preflight._run_gh",
                return_value=_cp(returncode=1, stderr="You are not logged into any GitHub hosts."),
            ),
        ):
            with pytest.raises(PreflightError) as exc_info:
                run_preflight(tmp_path)

        err = exc_info.value
        assert "github.com" in err.reason
        assert "gh auth login" in err.fix_command
        assert "github.com" in err.fix_command

    def test_repo_and_labels_not_called_when_auth_fails(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch(
                "code_generator.preflight._run_gh",
                return_value=_cp(returncode=1),
            ) as mock_gh,
        ):
            with pytest.raises(PreflightError):
                run_preflight(tmp_path)

        # Only auth check was called before failing
        assert mock_gh.call_count == 1


# ---------------------------------------------------------------------------
# run_preflight — missing repo permission
# ---------------------------------------------------------------------------


class TestRunPreflightMissingRepoPermission:
    def test_raises_preflight_error_with_repo_view_fix_command(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch("code_generator.preflight._run_gh", return_value=_cp()),  # auth: success
            patch(
                "code_generator.preflight.subprocess.run",
                return_value=_cp(returncode=1, stderr="Could not resolve to a Repository"),
            ),
        ):
            with pytest.raises(PreflightError) as exc_info:
                run_preflight(tmp_path)

        err = exc_info.value
        assert "owner/repo" in err.reason
        assert "gh repo view" in err.fix_command

    def test_labels_not_called_when_repo_check_fails(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch("code_generator.preflight._run_gh", return_value=_cp()) as mock_gh,
            patch(
                "code_generator.preflight.subprocess.run",
                return_value=_cp(returncode=1, stderr="not found"),
            ),
        ):
            with pytest.raises(PreflightError):
                run_preflight(tmp_path)

        # Only auth was called through _run_gh; repo check failed via subprocess.run
        assert mock_gh.call_count == 1


# ---------------------------------------------------------------------------
# run_preflight — missing labels API access
# ---------------------------------------------------------------------------


class TestRunPreflightMissingLabelsAccess:
    def test_raises_preflight_error_with_labels_fix_command(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch(
                "code_generator.preflight._run_gh",
                side_effect=[
                    _cp(),  # auth: success
                    _cp(
                        returncode=1, stderr="Resource not accessible by integration"
                    ),  # labels: fail
                ],
            ),
            patch(
                "code_generator.preflight.subprocess.run", return_value=_cp()
            ),  # repo view: success
        ):
            with pytest.raises(PreflightError) as exc_info:
                run_preflight(tmp_path)

        err = exc_info.value
        assert "label" in err.reason.lower() or "label" in err.fix_command.lower()
        assert "gh api" in err.fix_command

    def test_all_three_calls_made_before_labels_fail(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch(
                "code_generator.preflight._run_gh",
                side_effect=[_cp(), _cp(returncode=1)],  # auth: success, labels: fail
            ) as mock_gh,
            patch(
                "code_generator.preflight.subprocess.run", return_value=_cp()
            ),  # repo view: success
        ):
            with pytest.raises(PreflightError):
                run_preflight(tmp_path)

        # auth + labels go through _run_gh (2 calls); repo check via subprocess.run
        assert mock_gh.call_count == 2


# ---------------------------------------------------------------------------
# run_preflight — SSH alias resolved via fixture ~/.ssh/config
# ---------------------------------------------------------------------------


class TestRunPreflightSshAlias:
    def test_alias_resolved_to_real_hostname(self, tmp_path: Path, ssh_config: Path) -> None:
        """SSH alias 'ey' → 'github.ey.com' via fixture config."""
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="ey:owner/repo.git",
            ),
            patch("code_generator.repo_info._DEFAULT_SSH_CONFIG", ssh_config),
            patch("code_generator.preflight._run_gh", return_value=_cp()),
            patch("code_generator.preflight.subprocess.run", return_value=_cp()),
        ):
            result = run_preflight(tmp_path)

        assert result.host == "github.ey.com"
        assert result.owner == "owner"
        assert result.name == "repo"

    def test_gh_calls_use_resolved_hostname(self, tmp_path: Path, ssh_config: Path) -> None:
        """Resolved hostname (not alias) is passed to gh --hostname."""
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="ey:owner/repo.git",
            ),
            patch("code_generator.repo_info._DEFAULT_SSH_CONFIG", ssh_config),
            patch("code_generator.preflight._run_gh", return_value=_cp()) as mock_gh,
            patch("code_generator.preflight.subprocess.run", return_value=_cp()),
        ):
            run_preflight(tmp_path)

        hostnames = {call.kwargs["hostname"] for call in mock_gh.call_args_list}
        assert hostnames == {"github.ey.com"}


# ---------------------------------------------------------------------------
# Windows compatibility — skip with WARNING instead of raising
# ---------------------------------------------------------------------------


class TestRunPreflightWindowsCompatibility:
    def test_skips_gh_checks_with_warning_on_windows_failure(self, tmp_path: Path) -> None:
        """On Windows, failing gh checks log WARNING and do not raise."""
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch("code_generator.preflight._IS_WINDOWS", True),
            patch(
                "code_generator.preflight._run_gh",
                return_value=_cp(returncode=1, stderr="not logged in"),
            ),
            patch("code_generator.preflight.subprocess.run", return_value=_cp(returncode=1)),
            patch("code_generator.preflight.logger") as mock_logger,
        ):
            result = run_preflight(tmp_path)

        # No PreflightError raised — returned a valid RepoInfo
        assert result == RepoInfo(host="github.com", owner="owner", name="repo")
        # A warning was logged
        mock_logger.warning.assert_called()

    def test_warning_message_mentions_check_name(self, tmp_path: Path) -> None:
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch("code_generator.preflight._IS_WINDOWS", True),
            patch(
                "code_generator.preflight._run_gh",
                return_value=_cp(returncode=1),
            ),
            patch("code_generator.preflight.subprocess.run", return_value=_cp(returncode=1)),
            patch("code_generator.preflight.logger") as mock_logger,
        ):
            run_preflight(tmp_path)

        warning_calls = mock_logger.warning.call_args_list
        combined = " ".join(str(c) for c in warning_calls)
        assert "Windows" in combined or "windows" in combined.lower()


# ---------------------------------------------------------------------------
# run_preflight — required-betas self-check (issue #228)
# ---------------------------------------------------------------------------


class TestRunPreflightRequiredBetas:
    """run_preflight invokes assert_required_betas() and re-raises as PreflightError."""

    def test_raises_preflight_error_when_self_check_fails(self, tmp_path: Path) -> None:
        """assert_required_betas() raising RuntimeError aborts run_preflight with PreflightError."""
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch("code_generator.preflight._run_gh", return_value=_cp()),
            patch("code_generator.preflight.subprocess.run", return_value=_cp()),
            patch(
                "code_generator.preflight.assert_required_betas",
                side_effect=RuntimeError("context-management-2025-06-27 missing. " + _REMEDIATION),
            ),
        ):
            with pytest.raises(PreflightError) as excinfo:
                run_preflight(tmp_path)

        assert _REMEDIATION in excinfo.value.fix_command or _REMEDIATION in excinfo.value.reason

    def test_passes_when_self_check_passes(self, tmp_path: Path) -> None:
        """run_preflight returns RepoInfo when assert_required_betas() passes."""
        with (
            patch(
                "code_generator.preflight._get_origin_url",
                return_value="https://github.com/owner/repo.git",
            ),
            patch("code_generator.preflight._run_gh", return_value=_cp()),
            patch("code_generator.preflight.subprocess.run", return_value=_cp()),
            patch("code_generator.preflight.assert_required_betas", return_value=None),
        ):
            result = run_preflight(tmp_path)

        assert result == RepoInfo(host="github.com", owner="owner", name="repo")
