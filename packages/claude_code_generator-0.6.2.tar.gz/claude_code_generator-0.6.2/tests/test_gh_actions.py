"""Tests for code_generator.gh.actions — workflow run + job log wrappers."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from code_generator.gh.actions import (
    LOG_TRUNCATE_LIMIT,
    get_failing_job_logs,
    list_workflow_runs,
    view_run,
)
from code_generator.gh.core import GhError
from code_generator.repo_info import RepoInfo

_REPO = RepoInfo(host="github.com", owner="test", name="repo")
_SHA = "deadbeef1234567890abcdef1234567890abcdef"
_RUN_ID = 987654321


# ---------------------------------------------------------------------------
# list_workflow_runs
# ---------------------------------------------------------------------------


class TestListWorkflowRuns:
    def test_when_runs_exist_returns_parsed_list(self) -> None:
        payload = [
            {
                "databaseId": 111,
                "status": "completed",
                "conclusion": "success",
                "workflowName": "ci",
                "createdAt": "2026-05-16T10:00:00Z",
            },
            {
                "databaseId": 112,
                "status": "in_progress",
                "conclusion": None,
                "workflowName": "release",
                "createdAt": "2026-05-16T10:01:00Z",
            },
        ]
        with patch("code_generator.gh.actions._run", return_value=json.dumps(payload)) as mock_run:
            runs = list_workflow_runs(_REPO, _SHA)

        assert runs == payload
        argv = mock_run.call_args[0][0]
        assert argv == [
            "gh",
            "run",
            "list",
            "--repo",
            _REPO.full,
            "--commit",
            _SHA,
            "--json",
            "databaseId,status,conclusion,workflowName,createdAt",
        ]
        assert mock_run.call_args.kwargs["env"] == {"GH_HOST": _REPO.host}

    def test_when_no_runs_yet_returns_empty_list(self) -> None:
        with patch("code_generator.gh.actions._run", return_value="[]"):
            assert list_workflow_runs(_REPO, _SHA) == []

    def test_when_returncode_1_returns_empty_list(self) -> None:
        with patch(
            "code_generator.gh.actions._run",
            side_effect=GhError(1, "no runs found for commit"),
        ):
            assert list_workflow_runs(_REPO, _SHA) == []

    def test_when_other_returncode_propagates_error(self) -> None:
        with (
            patch(
                "code_generator.gh.actions._run",
                side_effect=GhError(4, "authentication required"),
            ),
            pytest.raises(GhError) as exc_info,
        ):
            list_workflow_runs(_REPO, _SHA)
        assert exc_info.value.returncode == 4


# ---------------------------------------------------------------------------
# view_run
# ---------------------------------------------------------------------------


class TestViewRun:
    def test_when_run_found_returns_parsed_dict(self) -> None:
        payload = {
            "status": "completed",
            "conclusion": "failure",
            "jobs": [
                {"name": "lint", "conclusion": "success"},
                {"name": "test", "conclusion": "failure"},
            ],
        }
        with patch("code_generator.gh.actions._run", return_value=json.dumps(payload)) as mock_run:
            result = view_run(_REPO, _RUN_ID)

        assert result == payload
        argv = mock_run.call_args[0][0]
        assert argv == [
            "gh",
            "run",
            "view",
            str(_RUN_ID),
            "--repo",
            _REPO.full,
            "--json",
            "status,conclusion,jobs",
        ]
        assert mock_run.call_args.kwargs["env"] == {"GH_HOST": _REPO.host}

    def test_when_gh_fails_propagates_error(self) -> None:
        with (
            patch(
                "code_generator.gh.actions._run",
                side_effect=GhError(1, "run not found"),
            ),
            pytest.raises(GhError),
        ):
            view_run(_REPO, _RUN_ID)


# ---------------------------------------------------------------------------
# get_failing_job_logs
# ---------------------------------------------------------------------------


class TestGetFailingJobLogs:
    def test_when_logs_short_returns_full_text(self) -> None:
        log_text = "FAIL test_thing\nAssertionError: nope\n"
        with patch("code_generator.gh.actions._run", return_value=log_text) as mock_run:
            result = get_failing_job_logs(_REPO, _RUN_ID)

        assert result == log_text
        argv = mock_run.call_args[0][0]
        assert argv == [
            "gh",
            "run",
            "view",
            str(_RUN_ID),
            "--repo",
            _REPO.full,
            "--log-failed",
        ]
        assert mock_run.call_args.kwargs["env"] == {"GH_HOST": _REPO.host}

    def test_when_logs_exceed_limit_truncates_to_last_chars(self) -> None:
        big = "A" * (LOG_TRUNCATE_LIMIT + 5000) + "TAIL_MARKER"
        with patch("code_generator.gh.actions._run", return_value=big):
            result = get_failing_job_logs(_REPO, _RUN_ID)
        assert len(result) == LOG_TRUNCATE_LIMIT
        assert result.endswith("TAIL_MARKER")

    def test_log_truncate_limit_is_8000(self) -> None:
        assert LOG_TRUNCATE_LIMIT == 8000

    def test_when_gh_fails_propagates_error(self) -> None:
        with (
            patch(
                "code_generator.gh.actions._run",
                side_effect=GhError(1, "log unavailable"),
            ),
            pytest.raises(GhError),
        ):
            get_failing_job_logs(_REPO, _RUN_ID)
