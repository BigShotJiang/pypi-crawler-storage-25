"""Historical assertions about the repo-root ``CHANGELOG.md`` 0.3.0 release.

Behavioural tests for the ``code_generator.changelog`` generator live in
``tests/test_phase8_changelog.py`` (#324).
"""

from __future__ import annotations

import re
from pathlib import Path

CHANGELOG = Path(__file__).resolve().parents[1] / "CHANGELOG.md"
ROLLBACK_CMD = "code-generator generate --session-mode fresh"


def _read_030_section() -> str:
    """Extract the text of the ## [0.3.0] section from CHANGELOG.md."""
    text = CHANGELOG.read_text(encoding="utf-8")
    # Match from ## [0.3.0] up to the next ## heading (or end of file)
    match = re.search(r"^## \[0\.3\.0\](.*?)(?=^## \[|\Z)", text, re.DOTALL | re.MULTILINE)
    assert match, "## [0.3.0] section not found in CHANGELOG.md"
    return match.group(0)


def test_no_separate_unreleased_section() -> None:
    """0.3.0 content must not live under ## [Unreleased] — it belongs in ## [0.3.0]."""
    text = CHANGELOG.read_text(encoding="utf-8")
    # There should be no ## [Unreleased] section at all (0.3.0 is the current release)
    unreleased_match = re.search(r"^## \[Unreleased\]", text, re.MULTILINE)
    assert unreleased_match is None, (
        "Found ## [Unreleased] section — 0.3.0 content must be folded into ## [0.3.0]"
    )


def test_changelog_has_required_headings() -> None:
    """The 0.3.0 section must contain ### Default flip and ### Rollback headings."""
    section = _read_030_section()
    assert "### Default flip" in section, "Missing '### Default flip' heading in [0.3.0]"
    assert "### Rollback" in section, "Missing '### Rollback' heading in [0.3.0]"
    assert ROLLBACK_CMD in section, (
        f"Missing verbatim rollback command '{ROLLBACK_CMD}' under [0.3.0]"
    )


def test_changelog_enumerates_19_scope_items() -> None:
    """The 0.3.0 section must contain at least 19 numbered list entries (^\\d+\\.)."""
    section = _read_030_section()
    numbered = re.findall(r"^\d+\.", section, re.MULTILINE)
    assert len(numbered) >= 19, (
        f"Expected at least 19 numbered scope items in [0.3.0], found {len(numbered)}"
    )


def test_breaking_change_make_agent_options() -> None:
    """Breaking change for make_agent_options() must be documented in [0.3.0]."""
    section = _read_030_section()
    assert "make_agent_options" in section, (
        "Missing make_agent_options() breaking-change note in [0.3.0]"
    )


def test_breaking_change_gh_py_repo_first() -> None:
    """Breaking change for gh.py repo-first signature must be documented in [0.3.0]."""
    section = _read_030_section()
    assert "gh.py" in section, "Missing gh.py breaking-change note in [0.3.0]"
    assert "RepoInfo" in section, "Missing RepoInfo mention in gh.py breaking-change note"


def test_breaking_change_non_negotiable_6() -> None:
    """Non-negotiable #6 rewrite must be documented as a breaking change in [0.3.0]."""
    section = _read_030_section()
    # The rewritten invariant uses "soft reset" language
    assert "soft reset" in section.lower() or "soft-reset" in section.lower(), (
        "Missing non-negotiable #6 rewrite note (soft reset) in [0.3.0]"
    )


def test_opus_47_thinking_migration_note() -> None:
    """Opus 4.7 thinking migration note (adaptive only, no thinking_budget) must appear."""
    section = _read_030_section()
    assert "thinking_budget" in section, (
        "Missing thinking_budget removal note (Opus 4.7 migration) in [0.3.0]"
    )
    assert "adaptive" in section, "Missing 'adaptive' thinking note (Opus 4.7 migration) in [0.3.0]"


def test_march_2026_ttl_regression_note() -> None:
    """March 2026 TTL regression mitigation (explicit ttl='1h') must be documented."""
    section = _read_030_section()
    assert "ttl" in section.lower(), "Missing TTL regression mitigation note in [0.3.0]"
    assert "46829" in section, "Missing reference to claude-code#46829 (TTL regression) in [0.3.0]"


def test_source_links_present() -> None:
    """Key source links must be preserved in the [0.3.0] section."""
    section = _read_030_section()
    assert "effective-harnesses" in section or "effective_harnesses" in section, (
        "Missing Anthropic 'Effective harnesses' blog link in [0.3.0]"
    )
    assert "46829" in section, "Missing claude-code#46829 link in [0.3.0]"


def test_030_heading_carries_release_date() -> None:
    """Issue #214: the release entry heading must carry an ISO YYYY-MM-DD date.

    Pattern: ``## [0.3.0] — YYYY-MM-DD`` (em-dash separator per the house style).
    An undated draft is acceptable while the release is pending, but the
    finalized entry must be dated so downstream consumers know when 0.3.0
    actually shipped.
    """
    text = CHANGELOG.read_text(encoding="utf-8")
    match = re.search(r"^## \[0\.3\.0\](.*)$", text, re.MULTILINE)
    assert match, "Missing '## [0.3.0]' heading in CHANGELOG.md"
    suffix = match.group(1)
    # Accept em-dash (preferred) or ASCII hyphen as the separator.
    date_pattern = re.compile(r"\s*[—-]\s*(\d{4}-\d{2}-\d{2})")
    date_match = date_pattern.search(suffix)
    assert date_match, (
        f"The '## [0.3.0]' heading must include an ISO YYYY-MM-DD date; suffix was: {suffix!r}"
    )
