"""Phase 2 cache_hit_ratio regression guard against the Cycle 4 baseline (#256).

Cycle 5 acceptance criterion 3 forbids regressing the Phase 2 cache-hit ratio
established in Cycle 4. This deterministic, no-LLM regression test loads two
checked-in fixtures (a Cycle 4 per-issue baseline and a Cycle 5 batched
result) and asserts the batched run does not drop the Phase 2
``cache_hit_ratio`` against the baseline.

The tests drive the public ``bench_compare`` API directly so the assertion
walks the same code path operators use via ``code-generator bench compare``.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from code_generator.commands._bench_io import SCHEMA_VERSION
from code_generator.commands.bench_compare import (
    DeltaRow,
    _is_cache_hit_ratio_regression,
    compute_deltas,
)

# ---------------------------------------------------------------------------
# Fixture paths
# ---------------------------------------------------------------------------


_FIXTURES_DIR = Path(__file__).parent / "fixtures" / "bench-baselines"
_BASELINE_PATH = _FIXTURES_DIR / "cycle4-phase2-baseline.json"
_BATCHED_PATH = _FIXTURES_DIR / "cycle5-phase2-batched.json"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_fixture(path: Path) -> dict:
    """Load a checked-in bench-output fixture as a dict."""
    return json.loads(path.read_text(encoding="utf-8"))


def _phase2_cache_hit_ratio_row(rows: list[DeltaRow]) -> DeltaRow:
    """Locate the Phase 2 ``cache_hit_ratio`` row in a delta-row list."""
    return next(r for r in rows if r.phase == 2 and r.metric == "cache_hit_ratio")


# ---------------------------------------------------------------------------
# Schema sanity guards
# ---------------------------------------------------------------------------


class TestFixtureSchemaIsV3:
    """Both checked-in fixtures must declare the v3 schema (#248)."""

    def test_baseline_fixture_schema_is_v3(self) -> None:
        data = _load_fixture(_BASELINE_PATH)
        assert data["schema_version"] == SCHEMA_VERSION

    def test_batched_fixture_schema_is_v3(self) -> None:
        data = _load_fixture(_BATCHED_PATH)
        assert data["schema_version"] == SCHEMA_VERSION

    def test_fixtures_have_a_single_cycle(self) -> None:
        """``compute_deltas`` reads ``cycles[0]``; both fixtures must have exactly one."""
        baseline = _load_fixture(_BASELINE_PATH)
        batched = _load_fixture(_BATCHED_PATH)
        assert len(baseline["cycles"]) == 1
        assert len(batched["cycles"]) == 1


# ---------------------------------------------------------------------------
# Phase 2 cache_hit_ratio at-or-above baseline
# ---------------------------------------------------------------------------


class TestPhase2CacheHitRatioAtOrAboveBaseline:
    """The batched-mode Phase 2 cache_hit_ratio must not regress vs. the baseline."""

    def test_batched_phase2_cache_hit_ratio_at_or_above_baseline(self) -> None:
        """``_is_cache_hit_ratio_regression`` returns False for the Phase 2 row."""
        baseline = _load_fixture(_BASELINE_PATH)
        batched = _load_fixture(_BATCHED_PATH)

        rows = compute_deltas(baseline, batched)
        row = _phase2_cache_hit_ratio_row(rows)

        assert row.delta is not None
        assert row.delta >= 0, (
            f"Phase 2 cache_hit_ratio regressed: baseline={row.a}, batched={row.b}, "
            f"delta={row.delta}"
        )
        assert not _is_cache_hit_ratio_regression(row), (
            "the bench comparator must NOT flag the batched fixture as a regression"
        )

    def test_phase2_cache_hit_ratio_strictly_improved_in_batched(self) -> None:
        """Strict improvement guard: delta is strictly positive, not just non-negative.

        If the fixtures ever drift to identical Phase 2 ratios, the regression
        guard above passes vacuously. This guard protects against that drift
        without coupling the assertion to a specific magnitude.
        """
        baseline = _load_fixture(_BASELINE_PATH)
        batched = _load_fixture(_BATCHED_PATH)

        rows = compute_deltas(baseline, batched)
        row = _phase2_cache_hit_ratio_row(rows)

        assert row.delta is not None and row.delta > 0


# ---------------------------------------------------------------------------
# Comparator flags a synthetic regression
# ---------------------------------------------------------------------------


class TestComparatorFlagsSyntheticRegression:
    """Mutating the batched fixture in-memory must surface a Phase 2 regression."""

    def test_mutated_batched_fixture_triggers_regression_warning(self) -> None:
        """Drop batched Phase 2 cache_hit_ratio well below baseline → regression flagged.

        The delta must be comfortably below the -0.05 threshold to dodge the
        float-precision quirks of the threshold equality check.
        """
        baseline = _load_fixture(_BASELINE_PATH)
        batched = copy.deepcopy(_load_fixture(_BATCHED_PATH))

        # Set batched ratio to baseline - 0.10 so the comparator's b-a delta
        # is -0.10, comfortably past the -0.05 threshold regardless of FP rep.
        baseline_phase2 = baseline["cycles"][0]["phases"]["2"]["cache_hit_ratio"]
        batched["cycles"][0]["phases"]["2"]["cache_hit_ratio"] = baseline_phase2 - 0.10

        rows = compute_deltas(baseline, batched)
        row = _phase2_cache_hit_ratio_row(rows)

        assert row.delta is not None
        assert _is_cache_hit_ratio_regression(row), (
            f"comparator should flag a -0.10 drop as a regression; got delta={row.delta}"
        )

    def test_threshold_boundary_separates_regression_from_no_regression(self) -> None:
        """Inside the regression band → flagged; outside → not flagged.

        The bench-comparator threshold is ``delta <= -0.05``. We test a
        comfortably-inside delta (-0.06) and a comfortably-outside delta
        (-0.04) so float-precision quirks at the exact boundary do not flake.
        """
        baseline = _load_fixture(_BASELINE_PATH)
        baseline_phase2 = baseline["cycles"][0]["phases"]["2"]["cache_hit_ratio"]

        # Inside the regression band: delta = -0.06.
        batched_inside = copy.deepcopy(_load_fixture(_BATCHED_PATH))
        batched_inside["cycles"][0]["phases"]["2"]["cache_hit_ratio"] = baseline_phase2 - 0.06
        row_inside = _phase2_cache_hit_ratio_row(compute_deltas(baseline, batched_inside))
        assert _is_cache_hit_ratio_regression(row_inside)

        # Outside the regression band: delta = -0.04.
        batched_outside = copy.deepcopy(_load_fixture(_BATCHED_PATH))
        batched_outside["cycles"][0]["phases"]["2"]["cache_hit_ratio"] = baseline_phase2 - 0.04
        row_outside = _phase2_cache_hit_ratio_row(compute_deltas(baseline, batched_outside))
        assert not _is_cache_hit_ratio_regression(row_outside)


# ---------------------------------------------------------------------------
# Schema mismatch surfaces correctly via the same code path
# ---------------------------------------------------------------------------


class TestSchemaMismatchAborts:
    """``compute_deltas`` exits 2 when the two fixtures have different schemas."""

    def test_schema_mismatch_raises_typer_exit(self) -> None:
        import typer

        baseline = _load_fixture(_BASELINE_PATH)
        batched = copy.deepcopy(_load_fixture(_BATCHED_PATH))
        batched["schema_version"] = 99  # synthetic mismatch

        with pytest.raises(typer.Exit) as excinfo:
            compute_deltas(baseline, batched)

        assert excinfo.value.exit_code == 2
