"""Tests for code_generator.orchestrator.vigil — Issue #287.

Reflective overseer at the Phase 3/4 → 6.5 boundary. Catches "premature
done" — model reports success while the app boots non-zero — and
forces Phase 6.5 re-entry by flipping ``vigil_triggered`` on the
state. Boot probe is mocked; no real subprocess runs in this suite.
"""

from __future__ import annotations

import logging
from pathlib import Path

import pytest

from code_generator.orchestrator import vigil as vigil_module
from code_generator.orchestrator.phase6_5_verify import TierResult
from code_generator.orchestrator.vigil import check_premature_done
from code_generator.state import CycleState, IssueState, State, load_state, save_state

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _issue(number: int, *, status: str = "closed") -> IssueState:
    return IssueState(number=number, status=status, agent="python-pro")  # type: ignore[arg-type]


def _cycle(issues: list[IssueState]) -> CycleState:
    return CycleState(
        id=1,
        name="Cycle 1",
        milestone_number=1,
        milestone_title="Cycle 1",
        status="in_progress",
        phase=4,
        issues=issues,
        commit_sha=None,
    )


def _state_with(issues: list[IssueState]) -> State:
    return State(
        mode="single",
        started_at="2026-05-15T00:00:00Z",
        updated_at="2026-05-15T00:00:00Z",
        issues=issues,
    )


def _passing_boot(*_args, **_kwargs) -> TierResult:
    return TierResult(
        tier_id="T1",
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=None,
        failing_detail=None,
    )


def _failing_boot(*_args, **_kwargs) -> TierResult:
    return TierResult(
        tier_id="T1",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=1,
        stderr_tail="boom",
        failing_detail="process exited before boot window elapsed",
    )


def _skipped_boot(*_args, **_kwargs) -> TierResult:
    return TierResult(
        tier_id="T1",
        passed=False,
        skipped=True,
        skip_reason="entry_cmd is empty",
        exit_code=None,
        stderr_tail=None,
        failing_detail=None,
    )


# ---------------------------------------------------------------------------
# Trigger path
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_all_closed_and_boot_fails_then_vigil_triggers(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    issues = [_issue(1), _issue(2)]
    cycle = _cycle(issues)
    state = State(
        mode="multi-cycle",
        started_at="2026-05-15T00:00:00Z",
        updated_at="2026-05-15T00:00:00Z",
        cycles=[cycle],
    )
    state_path = tmp_path / "state.json"
    monkeypatch.setattr(vigil_module, "run_t1_boot", _failing_boot)
    monkeypatch.setattr(vigil_module, "_resolve_entry_cmd", lambda *_a, **_k: ["python", "-m", "x"])

    triggered = await check_premature_done(
        state, cycle, tmp_path, state_path, logger=logging.getLogger("vigil")
    )

    assert triggered is True
    assert cycle.vigil_triggered is True
    assert state_path.exists()  # atomic save_state was called


@pytest.mark.asyncio
async def test_when_state_mode_single_then_writes_state_flag(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    state = _state_with([_issue(1)])
    state_path = tmp_path / "state.json"
    monkeypatch.setattr(vigil_module, "run_t1_boot", _failing_boot)
    monkeypatch.setattr(vigil_module, "_resolve_entry_cmd", lambda *_a, **_k: ["python", "-m", "x"])

    triggered = await check_premature_done(
        state, None, tmp_path, state_path, logger=logging.getLogger("vigil")
    )

    assert triggered is True
    assert state.vigil_triggered is True


# ---------------------------------------------------------------------------
# No-trigger paths
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_boot_passes_then_vigil_not_triggered(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cycle = _cycle([_issue(1), _issue(2)])
    state = State(
        mode="multi-cycle",
        started_at="2026-05-15T00:00:00Z",
        updated_at="2026-05-15T00:00:00Z",
        cycles=[cycle],
    )
    monkeypatch.setattr(vigil_module, "run_t1_boot", _passing_boot)
    monkeypatch.setattr(vigil_module, "_resolve_entry_cmd", lambda *_a, **_k: ["python", "-m", "x"])

    triggered = await check_premature_done(
        state, cycle, tmp_path, tmp_path / "state.json", logger=logging.getLogger("vigil")
    )

    assert triggered is False
    assert cycle.vigil_triggered is False


@pytest.mark.asyncio
async def test_when_open_issues_remain_then_vigil_skipped(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cycle = _cycle([_issue(1, status="closed"), _issue(2, status="open")])
    state = State(
        mode="multi-cycle",
        started_at="2026-05-15T00:00:00Z",
        updated_at="2026-05-15T00:00:00Z",
        cycles=[cycle],
    )
    boot_called = {"count": 0}

    def boot_spy(*_a, **_k):  # type: ignore[no-untyped-def]
        boot_called["count"] += 1
        return _passing_boot()

    monkeypatch.setattr(vigil_module, "run_t1_boot", boot_spy)
    monkeypatch.setattr(vigil_module, "_resolve_entry_cmd", lambda *_a, **_k: ["python", "-m", "x"])

    triggered = await check_premature_done(
        state, cycle, tmp_path, tmp_path / "state.json", logger=logging.getLogger("vigil")
    )

    assert triggered is False
    assert cycle.vigil_triggered is False
    assert boot_called["count"] == 0  # short-circuited before probe


@pytest.mark.asyncio
async def test_when_no_entry_cmd_then_vigil_skipped(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cycle = _cycle([_issue(1)])
    state = State(
        mode="multi-cycle",
        started_at="2026-05-15T00:00:00Z",
        updated_at="2026-05-15T00:00:00Z",
        cycles=[cycle],
    )
    monkeypatch.setattr(vigil_module, "_resolve_entry_cmd", lambda *_a, **_k: None)

    triggered = await check_premature_done(
        state, cycle, tmp_path, tmp_path / "state.json", logger=logging.getLogger("vigil")
    )

    assert triggered is False
    assert cycle.vigil_triggered is False


@pytest.mark.asyncio
async def test_when_boot_skipped_then_vigil_not_triggered(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cycle = _cycle([_issue(1)])
    state = State(
        mode="multi-cycle",
        started_at="2026-05-15T00:00:00Z",
        updated_at="2026-05-15T00:00:00Z",
        cycles=[cycle],
    )
    monkeypatch.setattr(vigil_module, "run_t1_boot", _skipped_boot)
    monkeypatch.setattr(vigil_module, "_resolve_entry_cmd", lambda *_a, **_k: ["python", "-m", "x"])

    triggered = await check_premature_done(
        state, cycle, tmp_path, tmp_path / "state.json", logger=logging.getLogger("vigil")
    )

    assert triggered is False
    assert cycle.vigil_triggered is False


# ---------------------------------------------------------------------------
# WARNING log
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_triggered_then_warning_logged(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    cycle = _cycle([_issue(1)])
    state = State(
        mode="multi-cycle",
        started_at="2026-05-15T00:00:00Z",
        updated_at="2026-05-15T00:00:00Z",
        cycles=[cycle],
    )
    monkeypatch.setattr(vigil_module, "run_t1_boot", _failing_boot)
    monkeypatch.setattr(vigil_module, "_resolve_entry_cmd", lambda *_a, **_k: ["python", "-m", "x"])

    logger = logging.getLogger("vigil")
    with caplog.at_level(logging.WARNING, logger="vigil"):
        await check_premature_done(state, cycle, tmp_path, tmp_path / "state.json", logger=logger)

    assert any("premature" in rec.message.lower() for rec in caplog.records)


# ---------------------------------------------------------------------------
# Atomic persistence
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_when_triggered_then_flag_persists_atomically_to_state_json(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cycle = _cycle([_issue(1)])
    state = State(
        mode="multi-cycle",
        started_at="2026-05-15T00:00:00Z",
        updated_at="2026-05-15T00:00:00Z",
        cycles=[cycle],
    )
    state_path = tmp_path / "state.json"
    save_state(state_path, state)  # seed
    monkeypatch.setattr(vigil_module, "run_t1_boot", _failing_boot)
    monkeypatch.setattr(vigil_module, "_resolve_entry_cmd", lambda *_a, **_k: ["python", "-m", "x"])

    await check_premature_done(
        state, cycle, tmp_path, state_path, logger=logging.getLogger("vigil")
    )

    loaded = load_state(state_path)
    reloaded_cycle = loaded.cycles[0]
    assert isinstance(reloaded_cycle, CycleState)
    assert reloaded_cycle.vigil_triggered is True


# ---------------------------------------------------------------------------
# Field defaults + backward-compat
# ---------------------------------------------------------------------------


def test_cycle_state_default_vigil_triggered_is_false() -> None:
    cycle = _cycle([])
    assert cycle.vigil_triggered is False


def test_state_default_vigil_triggered_is_false() -> None:
    state = _state_with([])
    assert state.vigil_triggered is False


def test_legacy_state_json_without_vigil_field_loads_to_false(tmp_path: Path) -> None:
    import json as _json

    state_path = tmp_path / "state.json"
    state_path.write_text(
        _json.dumps(
            {
                "mode": "single",
                "started_at": "2026-05-01T00:00:00Z",
                "updated_at": "2026-05-01T00:00:00Z",
                "session_mode": "shared",
            }
        ),
        encoding="utf-8",
    )

    loaded = load_state(state_path)

    assert loaded.vigil_triggered is False
