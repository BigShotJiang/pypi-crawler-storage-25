"""Tests for code_generator.orchestrator.criteria_oracle — Issue #280.

Pure parser that maps each acceptance criterion in requirements.md to a
concrete T2/T3 runtime check or marks it 'not runtime-verifiable' with a
reason.
"""

from __future__ import annotations

import dataclasses

import pytest

from code_generator.orchestrator.criteria_oracle import (
    CriterionMapping,
    OracleReport,
    build_oracle_report,
)

_REQUIREMENTS = """# Foo

## Description
A backend.

## Tech Stack
Python.

## Goals
- Ship it.

## Scope
### 1. Items API
Implement items endpoints.

Acceptance criteria
- [ ] `GET /api/items` returns 200 with JSON list
- [ ] `POST /api/items` creates an item

### 2. Dashboard
Render the dashboard page.

Acceptance criteria
- [ ] UI renders the dashboard with a header
- [ ] The page displays the items list

## Non-goals
- None.

## Constraints
- Linux only.

## Global acceptance criteria
- [ ] `GET /health` returns 200
- [ ] `src/app/main.py` exposes a `main()` function
"""


# ---------------------------------------------------------------------------
# Frozen dataclass guarantees
# ---------------------------------------------------------------------------


def test_criterion_mapping_is_frozen_dataclass() -> None:
    m = CriterionMapping(text="x", tier="T2", verifiable=True, not_verifiable_reason=None)
    assert dataclasses.is_dataclass(m)
    with pytest.raises(dataclasses.FrozenInstanceError):
        m.tier = "T3"  # type: ignore[misc]


def test_oracle_report_is_frozen_dataclass_with_tuple_criteria() -> None:
    rep = OracleReport(global_criteria=(), scope_criteria=())
    assert dataclasses.is_dataclass(rep)
    assert isinstance(rep.global_criteria, tuple)
    assert isinstance(rep.scope_criteria, tuple)
    with pytest.raises(dataclasses.FrozenInstanceError):
        rep.global_criteria = ()  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Endpoint criteria → T2
# ---------------------------------------------------------------------------


def test_when_criterion_has_http_endpoint_then_maps_to_t2() -> None:
    report = build_oracle_report(_REQUIREMENTS)
    global_texts = {c.text: c for c in report.global_criteria}

    health = next(c for c in global_texts.values() if "/health" in c.text)
    assert health.tier == "T2"
    assert health.verifiable is True
    assert health.not_verifiable_reason is None


def test_when_scope_criterion_has_http_endpoint_then_maps_to_t2() -> None:
    report = build_oracle_report(_REQUIREMENTS)
    items_get = next(c for c in report.scope_criteria if "GET /api/items" in c.text)

    assert items_get.tier == "T2"
    assert items_get.verifiable is True


# ---------------------------------------------------------------------------
# UI criteria → T3
# ---------------------------------------------------------------------------


def test_when_criterion_mentions_ui_render_then_maps_to_t3() -> None:
    report = build_oracle_report(_REQUIREMENTS)
    ui = next(c for c in report.scope_criteria if "UI renders" in c.text)

    assert ui.tier == "T3"
    assert ui.verifiable is True
    assert ui.not_verifiable_reason is None


# ---------------------------------------------------------------------------
# Internal / code-level criteria → not verifiable
# ---------------------------------------------------------------------------


def test_when_criterion_references_internal_code_then_not_verifiable() -> None:
    report = build_oracle_report(_REQUIREMENTS)
    internal = next(c for c in report.global_criteria if "main.py" in c.text)

    assert internal.verifiable is False
    assert internal.tier is None
    assert internal.not_verifiable_reason
    assert "internal" in internal.not_verifiable_reason.lower()


# ---------------------------------------------------------------------------
# Section separation: global vs scope
# ---------------------------------------------------------------------------


def test_global_criteria_parsed_separately_from_scope_subsections() -> None:
    report = build_oracle_report(_REQUIREMENTS)
    global_texts = [c.text for c in report.global_criteria]
    scope_texts = [c.text for c in report.scope_criteria]

    assert any("/health" in t for t in global_texts)
    assert any("main.py" in t for t in global_texts)
    assert all("/health" not in t for t in scope_texts)
    assert any("GET /api/items" in t for t in scope_texts)
    assert any("POST /api/items" in t for t in scope_texts)
    assert any("UI renders" in t for t in scope_texts)


# ---------------------------------------------------------------------------
# Purity
# ---------------------------------------------------------------------------


def test_when_same_input_then_build_oracle_report_is_pure() -> None:
    a = build_oracle_report(_REQUIREMENTS)
    b = build_oracle_report(_REQUIREMENTS)
    assert a == b


# ---------------------------------------------------------------------------
# Empty input
# ---------------------------------------------------------------------------


def test_when_empty_input_then_report_has_empty_lists() -> None:
    report = build_oracle_report("")
    assert report.global_criteria == ()
    assert report.scope_criteria == ()


def test_when_no_acceptance_criteria_blocks_then_empty_lists() -> None:
    report = build_oracle_report("# Title\n\n## Description\nNo criteria here.\n")
    assert report.global_criteria == ()
    assert report.scope_criteria == ()
