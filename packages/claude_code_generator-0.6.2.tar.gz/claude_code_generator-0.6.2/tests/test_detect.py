"""Unit tests for the re-run detection pure function.

Covers all branches of detect_run_mode:
  - first-run  (no prior hash)
  - resume     (same hash, incomplete run)
  - no-op      (same hash, run complete — single mode and multi-cycle mode)
  - delta      (hash differs)
"""

from __future__ import annotations

import pytest

from code_generator.commands._detect import RunMode, detect_run_mode
from code_generator.state import CycleState, State

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

HASH_A = "a" * 64
HASH_B = "b" * 64


def _make_state(
    *,
    mode: str = "single",
    phase: int | None = None,
    requirements_hash: str | None = None,
    cycles: list[CycleState] | None = None,
) -> State:
    return State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        phase=phase,
        requirements_hash=requirements_hash,
        cycles=cycles or [],  # type: ignore[arg-type]
    )


def _completed_cycle(cycle_id: int) -> CycleState:
    return CycleState(
        id=cycle_id,
        name=f"cycle-{cycle_id}",
        milestone_number=cycle_id,
        milestone_title=f"Cycle {cycle_id}",
        status="completed",
        phase=7,
        issues=[],
        commit_sha=None,
    )


def _open_cycle(cycle_id: int) -> CycleState:
    return CycleState(
        id=cycle_id,
        name=f"cycle-{cycle_id}",
        milestone_number=cycle_id,
        milestone_title=f"Cycle {cycle_id}",
        status="in_progress",
        phase=3,
        issues=[],
        commit_sha=None,
    )


# ---------------------------------------------------------------------------
# detect_run_mode — first-run branch
# ---------------------------------------------------------------------------


class TestFirstRun:
    def test_no_prior_hash_returns_first_run(self) -> None:
        """When requirements_hash is None, always return 'first-run'."""
        state = _make_state(requirements_hash=None)

        result = detect_run_mode(state, HASH_A)

        assert result == "first-run"

    def test_no_prior_hash_ignores_phase(self) -> None:
        """first-run is returned regardless of phase value when hash is absent."""
        state = _make_state(requirements_hash=None, phase=7)

        result = detect_run_mode(state, HASH_A)

        assert result == "first-run"

    def test_no_prior_hash_ignores_completed_cycles(self) -> None:
        """first-run is returned even if cycles look complete when hash is absent."""
        state = _make_state(
            mode="multi-cycle",
            requirements_hash=None,
            cycles=[_completed_cycle(1)],
        )

        result = detect_run_mode(state, HASH_A)

        assert result == "first-run"


# ---------------------------------------------------------------------------
# detect_run_mode — resume branch
# ---------------------------------------------------------------------------


class TestResume:
    def test_same_hash_and_incomplete_single_mode_returns_resume(self) -> None:
        """Same hash, phase < 7 in single mode → 'resume'."""
        state = _make_state(requirements_hash=HASH_A, phase=3)

        result = detect_run_mode(state, HASH_A)

        assert result == "resume"

    def test_same_hash_and_no_phase_returns_resume(self) -> None:
        """Same hash, phase=None (not started) in single mode → 'resume'."""
        state = _make_state(requirements_hash=HASH_A, phase=None)

        result = detect_run_mode(state, HASH_A)

        assert result == "resume"

    def test_same_hash_and_partial_multi_cycle_returns_resume(self) -> None:
        """Same hash with an incomplete cycle in multi-cycle mode → 'resume'."""
        state = _make_state(
            mode="multi-cycle",
            requirements_hash=HASH_A,
            cycles=[_completed_cycle(1), _open_cycle(2)],
        )

        result = detect_run_mode(state, HASH_A)

        assert result == "resume"

    def test_same_hash_and_empty_cycles_multi_cycle_returns_resume(self) -> None:
        """Same hash with no cycles recorded in multi-cycle mode → 'resume' (not started)."""
        state = _make_state(
            mode="multi-cycle",
            requirements_hash=HASH_A,
            cycles=[],
        )

        result = detect_run_mode(state, HASH_A)

        assert result == "resume"


# ---------------------------------------------------------------------------
# detect_run_mode — no-op branch
# ---------------------------------------------------------------------------


class TestNoOp:
    def test_same_hash_and_phase_7_single_mode_returns_noop(self) -> None:
        """Same hash + phase == 7 in single mode → 'no-op'."""
        state = _make_state(requirements_hash=HASH_A, phase=7)

        result = detect_run_mode(state, HASH_A)

        assert result == "no-op"

    def test_same_hash_and_all_cycles_completed_multi_cycle_returns_noop(self) -> None:
        """Same hash + all cycles completed in multi-cycle mode → 'no-op'."""
        state = _make_state(
            mode="multi-cycle",
            requirements_hash=HASH_A,
            cycles=[_completed_cycle(1), _completed_cycle(2)],
        )

        result = detect_run_mode(state, HASH_A)

        assert result == "no-op"

    def test_same_hash_single_completed_cycle_returns_noop(self) -> None:
        """Single completed cycle with matching hash → 'no-op'."""
        state = _make_state(
            mode="multi-cycle",
            requirements_hash=HASH_A,
            cycles=[_completed_cycle(1)],
        )

        result = detect_run_mode(state, HASH_A)

        assert result == "no-op"


# ---------------------------------------------------------------------------
# detect_run_mode — delta branch
# ---------------------------------------------------------------------------


class TestDelta:
    def test_different_hash_returns_delta(self) -> None:
        """When stored hash differs from current hash → 'delta'."""
        state = _make_state(requirements_hash=HASH_A)

        result = detect_run_mode(state, HASH_B)

        assert result == "delta"

    def test_different_hash_even_when_phase_7_returns_delta(self) -> None:
        """Hash mismatch takes priority over completion state → 'delta'."""
        state = _make_state(requirements_hash=HASH_A, phase=7)

        result = detect_run_mode(state, HASH_B)

        assert result == "delta"

    def test_different_hash_multi_cycle_completed_returns_delta(self) -> None:
        """Hash mismatch takes priority even when all cycles are completed."""
        state = _make_state(
            mode="multi-cycle",
            requirements_hash=HASH_A,
            cycles=[_completed_cycle(1)],
        )

        result = detect_run_mode(state, HASH_B)

        assert result == "delta"


# ---------------------------------------------------------------------------
# Return type contract
# ---------------------------------------------------------------------------


class TestReturnTypeContract:
    @pytest.mark.parametrize(
        "hash_stored,current_hash,mode,phase,cycles,expected",
        [
            (None, HASH_A, "single", None, [], "first-run"),
            (HASH_A, HASH_A, "single", 3, [], "resume"),
            (HASH_A, HASH_A, "single", 7, [], "no-op"),
            (HASH_A, HASH_B, "single", 3, [], "delta"),
        ],
    )
    def test_return_value_is_valid_literal(
        self,
        hash_stored: str | None,
        current_hash: str,
        mode: str,
        phase: int | None,
        cycles: list[CycleState],
        expected: RunMode,
    ) -> None:
        """detect_run_mode always returns one of the four expected literal values."""
        state = _make_state(
            mode=mode,
            phase=phase,
            requirements_hash=hash_stored,
            cycles=cycles,
        )

        result = detect_run_mode(state, current_hash)

        assert result == expected
        assert result in ("first-run", "resume", "no-op", "delta")
