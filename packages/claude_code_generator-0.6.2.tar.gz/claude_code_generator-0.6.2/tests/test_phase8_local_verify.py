"""Tests for code_generator.orchestrator.phase8_local_verify."""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

import pytest

from code_generator.orchestrator.phase8_local_verify import (
    LocalVerifyResult,
    detect_local_commands,
    run_local_verify,
)
from code_generator.orchestrator.phase8_workflow_gen import MANAGED_MARKER

_CLEAN_DIFF = (
    f"# {MANAGED_MARKER}\n"
    "name: ci\n"
    '"on": push\n'
    "jobs:\n"
    "  ci:\n"
    "    steps:\n"
    "      - run: ruff check\n"
    "      - run: pytest\n"
)


def _cp(returncode: int = 0, stdout: str = "", stderr: str = "") -> Any:
    cp = subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr=stderr)
    return cp


# ---------------------------------------------------------------------------
# detect_local_commands
# ---------------------------------------------------------------------------


class TestDetectLocalCommands:
    def test_when_python_project_returns_pytest_and_ruff(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        cmds = detect_local_commands(tmp_path)
        joined = [" ".join(c) for c in cmds]
        assert any("pytest" in c for c in joined)
        assert any("ruff" in c for c in joined)

    def test_when_node_project_returns_npm_test_and_npm_lint(self, tmp_path: Path) -> None:
        (tmp_path / "package.json").write_text('{"name": "x"}')
        cmds = detect_local_commands(tmp_path)
        joined = [" ".join(c) for c in cmds]
        assert any("npm test" in c for c in joined)
        assert any("npm run lint" in c for c in joined)

    def test_when_unknown_project_returns_empty(self, tmp_path: Path) -> None:
        assert detect_local_commands(tmp_path) == []


# ---------------------------------------------------------------------------
# Guardrail short-circuit
# ---------------------------------------------------------------------------


class TestGuardrailShortCircuit:
    def test_when_continue_on_error_in_diff_blocks_before_subprocess(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        diff = "+ continue-on-error: true\n"
        called: list[list[str]] = []

        def fake_run(cmd: list[str], **_: Any) -> Any:
            called.append(cmd)
            return _cp()

        result = run_local_verify(tmp_path, diff, _run_subprocess=fake_run)
        assert called == []
        assert result.passed is False
        assert result.blocked_by_guardrail is True
        assert "continue-on-error" in result.guardrail_violations

    def test_when_if_false_skip_in_diff_blocks_with_violation_label(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        diff = "+ if: false\n"
        result = run_local_verify(tmp_path, diff, _run_subprocess=lambda *a, **kw: _cp())
        assert result.passed is False
        assert "if-false-skip" in result.guardrail_violations


# ---------------------------------------------------------------------------
# Project kinds — subprocess behaviour
# ---------------------------------------------------------------------------


class TestPythonProjectFlow:
    def test_when_all_commands_pass_returns_passed_true(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")

        def fake_run(cmd: list[str], **_: Any) -> Any:
            return _cp(returncode=0)

        result = run_local_verify(tmp_path, _CLEAN_DIFF, _run_subprocess=fake_run)
        assert result.passed is True
        assert result.blocked_by_guardrail is False
        assert result.guardrail_violations == []

    def test_when_first_command_fails_does_not_run_second(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        called: list[list[str]] = []

        def fake_run(cmd: list[str], **_: Any) -> Any:
            called.append(cmd)
            return _cp(returncode=1, stderr="boom")

        result = run_local_verify(tmp_path, _CLEAN_DIFF, _run_subprocess=fake_run)
        assert len(called) == 1
        assert result.passed is False
        assert "boom" in result.stderr_excerpt

    def test_when_stderr_exceeds_limit_keeps_last_chars(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        big = "A" * 3000 + "TAIL"

        def fake_run(cmd: list[str], **_: Any) -> Any:
            return _cp(returncode=1, stderr=big)

        result = run_local_verify(tmp_path, _CLEAN_DIFF, _run_subprocess=fake_run)
        assert len(result.stderr_excerpt) == 2000
        assert result.stderr_excerpt.endswith("TAIL")

    def test_when_commands_run_cwd_is_project_dir(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        captured: list[dict[str, Any]] = []

        def fake_run(cmd: list[str], **kwargs: Any) -> Any:
            captured.append(kwargs)
            return _cp()

        run_local_verify(tmp_path, _CLEAN_DIFF, _run_subprocess=fake_run)
        for kw in captured:
            assert kw["cwd"] == tmp_path
            assert kw["capture_output"] is True
            assert kw["text"] is True


class TestNodeProjectFlow:
    def test_when_node_project_runs_npm_commands(self, tmp_path: Path) -> None:
        (tmp_path / "package.json").write_text('{"name": "x"}')
        called: list[list[str]] = []

        def fake_run(cmd: list[str], **_: Any) -> Any:
            called.append(cmd)
            return _cp()

        run_local_verify(tmp_path, _CLEAN_DIFF, _run_subprocess=fake_run)
        joined = [" ".join(c) for c in called]
        assert any("npm test" in j for j in joined)
        assert any("npm run lint" in j for j in joined)


class TestUnknownProjectFlow:
    def test_when_unknown_returns_passed_true_with_empty_excerpt(self, tmp_path: Path) -> None:
        called: list[list[str]] = []

        def fake_run(cmd: list[str], **_: Any) -> Any:
            called.append(cmd)
            return _cp()

        result = run_local_verify(tmp_path, _CLEAN_DIFF, _run_subprocess=fake_run)
        assert called == []
        assert result.passed is True
        assert result.stderr_excerpt == ""


# ---------------------------------------------------------------------------
# Timeout handling
# ---------------------------------------------------------------------------


class TestTimeoutHandling:
    def test_when_timeout_raised_returns_failed_with_excerpt(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")

        def fake_run(cmd: list[str], **_: Any) -> Any:
            raise subprocess.TimeoutExpired(cmd=cmd, timeout=5.0)

        result = run_local_verify(tmp_path, _CLEAN_DIFF, timeout_s=5.0, _run_subprocess=fake_run)
        assert result.passed is False
        assert "timeout" in result.stderr_excerpt.lower()

    def test_when_timeout_s_propagated_to_subprocess(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
        captured: list[dict[str, Any]] = []

        def fake_run(cmd: list[str], **kwargs: Any) -> Any:
            captured.append(kwargs)
            return _cp()

        run_local_verify(tmp_path, _CLEAN_DIFF, timeout_s=99.0, _run_subprocess=fake_run)
        for kw in captured:
            assert kw["timeout"] == 99.0


# ---------------------------------------------------------------------------
# LocalVerifyResult
# ---------------------------------------------------------------------------


class TestLocalVerifyResult:
    def test_is_frozen(self) -> None:
        r = LocalVerifyResult(
            passed=True,
            stderr_excerpt="",
            blocked_by_guardrail=False,
            guardrail_violations=[],
        )
        with pytest.raises((AttributeError, Exception)):
            r.passed = False  # type: ignore[misc]
