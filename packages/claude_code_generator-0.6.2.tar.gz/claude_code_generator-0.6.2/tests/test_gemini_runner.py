"""Tests for the gemini-cli headless runner.

The runner wraps ``subprocess.run`` in the extracted ``_run_subprocess``
helper; tests patch that helper so they assert against the parsed JSON
contract rather than stdlib internals.
"""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from code_generator.runner import gemini_runner
from code_generator.runner.types import (
    ApiUpstreamError,
    MaxTurnsExceeded,
    TokenUsage,
    TransientRunnerError,
)


def _options(model: str | None = "gemini-2.5-pro") -> MagicMock:
    opts = MagicMock()
    opts.model = model
    return opts


def _ok_payload(models: dict) -> str:
    return json.dumps({"response": "hello", "stats": {"models": models}})


async def _run(stdout: str = "", returncode: int = 0, stderr: str = "", options=None):
    logger = MagicMock()
    with patch.object(
        gemini_runner, "_run_subprocess", return_value=(returncode, stdout, stderr)
    ) as mock_sub:
        result = await gemini_runner.run(
            "test prompt",
            options or _options(),
            logger=logger,
            state_path=Path("state.json"),
        )
    return result, mock_sub, logger


@pytest.mark.asyncio
async def test_success_maps_tokens_including_thoughts():
    stdout = _ok_payload(
        {
            "gemini-2.5-pro": {
                "tokens": {"prompt": 100, "candidates": 50, "thoughts": 10, "cached": 20}
            }
        }
    )
    result, _, _ = await _run(stdout)
    assert result.text == "hello"
    assert result.usage.input == 100
    assert result.usage.output == 60  # candidates + thoughts
    assert result.usage.cache_read == 20
    assert result.usage.cache_write == 0
    assert result.session_id is None
    assert result.wall_seconds >= 0
    assert result.compaction_events == 0
    assert result.clear_events == 0


@pytest.mark.asyncio
async def test_success_sums_across_multiple_models():
    stdout = _ok_payload(
        {
            "model_a": {"tokens": {"prompt": 100, "candidates": 40}},
            "model_b": {"tokens": {"prompt": 50, "candidates": 20}},
        }
    )
    result, _, _ = await _run(stdout)
    assert result.usage.input == 150
    assert result.usage.output == 60


@pytest.mark.asyncio
async def test_missing_stats_falls_back_to_zero_usage_and_warns():
    result, _, logger = await _run(json.dumps({"response": "text"}))
    assert result.text == "text"
    assert result.usage == TokenUsage()
    assert logger.warning.called


@pytest.mark.asyncio
async def test_malformed_json_on_success_exit_raises_transient():
    with pytest.raises(TransientRunnerError):
        await _run("not json at all")


@pytest.mark.asyncio
async def test_exit_1_general_error_is_transient():
    stdout = json.dumps({"error": {"type": "INTERNAL", "message": "upstream failure", "code": 500}})
    with pytest.raises(TransientRunnerError, match="upstream failure"):
        await _run(stdout, returncode=1)


@pytest.mark.asyncio
async def test_resource_exhausted_is_transient():
    stdout = json.dumps(
        {"error": {"type": "RESOURCE_EXHAUSTED", "message": "quota exceeded", "code": 429}}
    )
    with pytest.raises(TransientRunnerError, match="RESOURCE_EXHAUSTED"):
        await _run(stdout, returncode=1)


@pytest.mark.asyncio
async def test_exit_42_input_error_is_not_retryable():
    stdout = json.dumps(
        {"error": {"type": "INVALID_ARGUMENT", "message": "bad prompt", "code": 400}}
    )
    with pytest.raises(ApiUpstreamError) as exc_info:
        await _run(stdout, returncode=42)
    assert not isinstance(exc_info.value, TransientRunnerError)


@pytest.mark.asyncio
async def test_exit_53_turn_limit_raises_max_turns():
    stdout = json.dumps({"error": {"type": "TURN_LIMIT", "message": "turn limit exceeded"}})
    with pytest.raises(MaxTurnsExceeded):
        await _run(stdout, returncode=53)


@pytest.mark.asyncio
async def test_exit_1_no_json_surfaces_stderr():
    with pytest.raises(TransientRunnerError, match="connection refused"):
        await _run("", returncode=1, stderr="connection refused")


@pytest.mark.asyncio
async def test_argv_uses_headless_yolo_json_contract():
    _, mock_sub, _ = await _run(_ok_payload({}))
    argv = mock_sub.call_args[0][0]
    assert argv == [
        "gemini",
        "-p",
        "test prompt",
        "-m",
        "gemini-2.5-pro",
        "--output-format",
        "json",
        "--yolo",
    ]
    assert "--model" not in argv  # old stub flag must be gone


@pytest.mark.asyncio
async def test_model_override_from_options():
    _, mock_sub, _ = await _run(_ok_payload({}), options=_options("gemini-1.5-flash"))
    argv = mock_sub.call_args[0][0]
    assert argv[3] == "-m" and argv[4] == "gemini-1.5-flash"


@pytest.mark.asyncio
async def test_default_model_when_options_model_none():
    _, mock_sub, _ = await _run(_ok_payload({}), options=_options(None))
    argv = mock_sub.call_args[0][0]
    assert argv[4] == "gemini-2.5-pro"


@pytest.mark.asyncio
async def test_env_strips_anthropic_keeps_gemini():
    logger = MagicMock()
    with (
        patch.dict(
            "os.environ",
            {"ANTHROPIC_API_KEY": "sk-evil", "GEMINI_API_KEY": "g-key"},
            clear=False,
        ),
        patch.object(
            gemini_runner, "_run_subprocess", return_value=(0, _ok_payload({}), "")
        ) as mock_sub,
    ):
        await gemini_runner.run("p", _options(), logger=logger, state_path=Path("state.json"))
    safe_env = mock_sub.call_args[0][1]
    assert "ANTHROPIC_API_KEY" not in safe_env
    assert safe_env.get("GEMINI_API_KEY") == "g-key"


@pytest.mark.asyncio
async def test_protect_state_file_is_entered():
    logger = MagicMock()
    guard = MagicMock()
    guard.__enter__ = MagicMock(return_value=None)
    guard.__exit__ = MagicMock(return_value=False)
    with (
        patch.object(gemini_runner, "protect_state_file", return_value=guard) as mock_guard,
        patch.object(gemini_runner, "_run_subprocess", return_value=(0, _ok_payload({}), "")),
    ):
        await gemini_runner.run("p", _options(), logger=logger, state_path=Path("state.json"))
    mock_guard.assert_called_once()
    guard.__enter__.assert_called_once()
