"""Tests for the codex-cli headless runner.

The runner wraps ``subprocess.run`` in the extracted ``_run_subprocess``
helper; tests patch that helper so they assert against the parsed JSONL
contract rather than stdlib internals.
"""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from code_generator.runner import codex_runner
from code_generator.runner.types import (
    ApiUpstreamError,
    RateLimitHit,
    TokenUsage,
    TransientRunnerError,
)


def _options(model: str | None = "gpt-5.5", cwd: str = "/work") -> MagicMock:
    opts = MagicMock()
    opts.model = model
    opts.cwd = cwd
    return opts


def _jsonl(*events: dict) -> str:
    return "\n".join(json.dumps(e) for e in events)


def _agent_msg(text: str = "hello") -> dict:
    return {"type": "item.completed", "item": {"type": "agent_message", "text": text}}


def _turn_completed(**usage: int) -> dict:
    return {"type": "turn.completed", "usage": usage}


async def _run(stdout: str = "", returncode: int = 0, stderr: str = "", options=None):
    logger = MagicMock()
    with patch.object(
        codex_runner, "_run_subprocess", return_value=(returncode, stdout, stderr)
    ) as mock_sub:
        result = await codex_runner.run(
            "test prompt",
            options or _options(),
            logger=logger,
            state_path=Path("state.json"),
        )
    return result, mock_sub, logger


@pytest.mark.asyncio
async def test_success_maps_tokens_including_reasoning():
    stdout = _jsonl(
        {"type": "thread.started", "thread_id": "t1"},
        {"type": "item.completed", "item": {"type": "reasoning", "text": "thinking"}},
        _agent_msg("hello"),
        _turn_completed(
            input_tokens=100,
            output_tokens=50,
            reasoning_output_tokens=10,
            cached_input_tokens=20,
        ),
    )
    result, _, _ = await _run(stdout)
    assert result.text == "hello"
    assert result.usage.input == 100
    assert result.usage.output == 60  # output + reasoning
    assert result.usage.cache_read == 20
    assert result.usage.cache_write == 0
    assert result.session_id is None
    assert result.wall_seconds >= 0
    assert result.compaction_events == 0
    assert result.clear_events == 0


@pytest.mark.asyncio
async def test_last_agent_message_wins_reasoning_ignored():
    stdout = _jsonl(
        _agent_msg("first"),
        {"type": "item.completed", "item": {"type": "reasoning", "text": "noise"}},
        _agent_msg("final"),
        _turn_completed(input_tokens=1, output_tokens=1),
    )
    result, _, _ = await _run(stdout)
    assert result.text == "final"


@pytest.mark.asyncio
async def test_missing_usage_falls_back_to_zero_and_warns():
    stdout = _jsonl(_agent_msg("text"))
    result, _, logger = await _run(stdout)
    assert result.text == "text"
    assert result.usage == TokenUsage()
    assert logger.warning.called


@pytest.mark.asyncio
async def test_malformed_lines_are_skipped_but_agent_message_parsed():
    stdout = "not json\n" + _jsonl(_agent_msg("ok")) + "\n{bad json"
    result, _, _ = await _run(stdout)
    assert result.text == "ok"


@pytest.mark.asyncio
async def test_exit_0_no_agent_message_raises_transient():
    stdout = _jsonl({"type": "turn.completed", "usage": {"input_tokens": 1}})
    with pytest.raises(TransientRunnerError, match="no parseable agent_message"):
        await _run(stdout)


@pytest.mark.asyncio
async def test_exit_2_usage_error_is_not_retryable():
    with pytest.raises(ApiUpstreamError) as exc_info:
        await _run("", returncode=2, stderr="error: unexpected argument '--bogus'")
    assert not isinstance(exc_info.value, TransientRunnerError)


@pytest.mark.asyncio
async def test_other_nonzero_exit_is_transient():
    with pytest.raises(TransientRunnerError, match="general/runtime failure"):
        await _run("", returncode=1, stderr="boom")


@pytest.mark.asyncio
async def test_usage_limit_reached_json_triggers_rate_limit():
    stdout = _jsonl({"error": {"type": "usage_limit_reached", "resets_in_seconds": 1800}})
    with patch.object(
        codex_runner, "handle_codex_429", side_effect=RateLimitHit(0, "codex_429")
    ) as mock_h:
        with pytest.raises(RateLimitHit):
            await _run(stdout, returncode=1)
    assert mock_h.call_args.kwargs["retry_after_seconds"] == 1800
    assert mock_h.call_args.kwargs["session_id"] is None


@pytest.mark.asyncio
async def test_stderr_429_triggers_rate_limit():
    with patch.object(
        codex_runner, "handle_codex_429", side_effect=RateLimitHit(0, "codex_429")
    ) as mock_h:
        with pytest.raises(RateLimitHit):
            await _run("", returncode=1, stderr="exceeded retry limit, last status: 429")
    assert mock_h.call_args.kwargs["retry_after_seconds"] is None


@pytest.mark.asyncio
async def test_argv_strict_order_contract():
    _, mock_sub, _ = await _run(_jsonl(_agent_msg(), _turn_completed(input_tokens=1)))
    argv = mock_sub.call_args[0][0]
    assert argv == [
        "codex",
        "-m",
        "gpt-5.5",
        "-C",
        "/work",
        "exec",
        "--skip-git-repo-check",
        "--dangerously-bypass-approvals-and-sandbox",
        "--json",
        "test prompt",
    ]


@pytest.mark.asyncio
async def test_model_override_from_options():
    _, mock_sub, _ = await _run(
        _jsonl(_agent_msg(), _turn_completed(input_tokens=1)),
        options=_options("gpt-5.4"),
    )
    argv = mock_sub.call_args[0][0]
    assert argv[2] == "gpt-5.4"


@pytest.mark.asyncio
async def test_default_model_when_options_model_none():
    _, mock_sub, _ = await _run(
        _jsonl(_agent_msg(), _turn_completed(input_tokens=1)),
        options=_options(None),
    )
    argv = mock_sub.call_args[0][0]
    assert argv[2] == "gpt-5.5"


@pytest.mark.asyncio
async def test_env_strips_anthropic_and_openai_credit_vars():
    logger = MagicMock()
    with (
        patch.dict(
            "os.environ",
            {
                "ANTHROPIC_API_KEY": "sk-evil",
                "OPENAI_API_KEY": "sk-openai",
                "CODEX_API_KEY": "sk-codex",
                "PATH": "/usr/bin",
            },
            clear=False,
        ),
        patch.object(
            codex_runner,
            "_run_subprocess",
            return_value=(0, _jsonl(_agent_msg(), _turn_completed(input_tokens=1)), ""),
        ) as mock_sub,
    ):
        await codex_runner.run("p", _options(), logger=logger, state_path=Path("state.json"))
    safe_env = mock_sub.call_args[0][1]
    assert "ANTHROPIC_API_KEY" not in safe_env
    assert "OPENAI_API_KEY" not in safe_env
    assert "CODEX_API_KEY" not in safe_env
    assert safe_env.get("PATH") == "/usr/bin"


@pytest.mark.asyncio
async def test_protect_state_file_is_entered():
    logger = MagicMock()
    guard = MagicMock()
    guard.__enter__ = MagicMock(return_value=None)
    guard.__exit__ = MagicMock(return_value=False)
    with (
        patch.object(codex_runner, "protect_state_file", return_value=guard) as mock_guard,
        patch.object(
            codex_runner,
            "_run_subprocess",
            return_value=(0, _jsonl(_agent_msg(), _turn_completed(input_tokens=1)), ""),
        ),
    ):
        await codex_runner.run("p", _options(), logger=logger, state_path=Path("state.json"))
    mock_guard.assert_called_once()
    guard.__enter__.assert_called_once()
