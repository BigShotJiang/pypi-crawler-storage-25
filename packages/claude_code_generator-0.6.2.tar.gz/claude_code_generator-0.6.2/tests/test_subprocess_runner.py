"""Tests for subprocess_runner — Issue #11, #52, #87.

subprocess.Popen is monkeypatched; no real subprocess is spawned.
"""

from __future__ import annotations

import io
import json
import logging
from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock, patch

if TYPE_CHECKING:
    from pathlib import Path

import pytest

from code_generator.runner.sdk_runner import ApiUpstreamError, MaxTurnsExceeded, OverageAbort
from code_generator.runner.subprocess_runner import (
    RateLimitHit,
    _check_overage_status,
    _check_upstream_5xx,
    _handle_assistant,
    _handle_line,
    _handle_rate_limit,
    _handle_result,
    _handle_system,
    _parse_ndjson,
    _translate_model,
    run,
)

# ---------------------------------------------------------------------------
# Fake Popen helpers
# ---------------------------------------------------------------------------


def _make_fake_popen(lines: list[str]) -> Any:
    """Return a MagicMock mimicking subprocess.Popen for stream-json output."""
    proc = MagicMock()
    encoded = [line.encode() + b"\n" for line in lines]
    proc.stdout = io.BytesIO(b"".join(encoded))
    proc.returncode = 0
    proc.wait.return_value = 0
    proc.kill = MagicMock()
    proc.__enter__ = MagicMock(return_value=proc)
    proc.__exit__ = MagicMock(return_value=False)
    return proc


def _make_options() -> Any:
    class FakeOptions:
        def __init__(self) -> None:
            self.permission_mode: str | None = None
            self.resume: str | None = None
            self.model = "claude-sonnet-4-6"
            self.max_turns = 10
            self.allowed_tools: list[str] = ["Read", "Bash"]
            self.cwd: str | None = None

    return FakeOptions()


def _assistant_line(text: str) -> str:
    return json.dumps(
        {
            "type": "assistant",
            "message": {"content": [{"type": "text", "text": text}]},
        }
    )


def _result_line(session_id: str = "sess-sub") -> str:
    return json.dumps(
        {
            "type": "result",
            "session_id": session_id,
            "usage": {"input_tokens": 5, "output_tokens": 15},
        }
    )


def _retry_line(retry_delay_ms: int, session_id: str = "sess-sub") -> str:
    return json.dumps(
        {
            "type": "system",
            "subtype": "api_retry",
            "error": "rate_limit",
            "retry_delay_ms": retry_delay_ms,
            "session_id": session_id,
        }
    )


def _error_result_line(session_id: str = "sess-err") -> str:
    """Return an NDJSON result line with is_error=True."""
    return json.dumps(
        {
            "type": "result",
            "is_error": True,
            "result": "some error",
            "session_id": session_id,
            "usage": {"input_tokens": 3, "output_tokens": 7},
        }
    )


def _overage_line(overage_status: str) -> str:
    """Return an NDJSON system event carrying overage_status."""
    return json.dumps({"type": "system", "overage_status": overage_status})


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_plain_text_and_result_populates_run_result(
    tmp_path: Path,
) -> None:
    """Plain assistant + result lines → populated RunResult."""
    state_path = tmp_path / ".code-generator" / "state.json"
    lines = [_assistant_line("Hello from subprocess!"), _result_line("s1")]
    fake_proc = _make_fake_popen(lines)

    import logging

    logger = logging.getLogger("test.sub.ok")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        result = await run("do something", options, logger=logger, state_path=state_path)

    assert result.text == "Hello from subprocess!"
    assert result.session_id == "s1"
    assert result.tokens_in == 5
    assert result.tokens_out == 15


@pytest.mark.asyncio
async def test_large_retry_delay_raises_rate_limit_hit(
    tmp_path: Path,
) -> None:
    """retry_delay_ms > 120_000 → RateLimitHit raised, state paused with +60s buffer."""
    from unittest.mock import patch as _patch

    state_path = tmp_path / ".code-generator" / "state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    lines = [_retry_line(200_000, "sess-big")]
    fake_proc = _make_fake_popen(lines)

    import logging

    logger = logging.getLogger("test.sub.bigratelimit")
    options = _make_options()
    fixed_now = 1_700_000_000.0

    popen_target = "code_generator.runner.subprocess_runner.subprocess.Popen"
    time_target = "code_generator.runner.subprocess_runner.time.time"
    with (
        _patch(time_target, return_value=fixed_now),
        patch(popen_target, return_value=fake_proc),
        pytest.raises(RateLimitHit),
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert state_path.exists()
    raw = json.loads(state_path.read_text())
    # Non-negotiable #5: paused_until must include +60s safety buffer
    expected = int(fixed_now + 200_000 / 1000 + 60)
    assert raw["paused_until"] == expected, (
        f"Expected paused_until={expected} (now + delay_s + 60), got {raw['paused_until']}"
    )


@pytest.mark.asyncio
async def test_small_retry_delay_no_raise(tmp_path: Path) -> None:
    """retry_delay_ms <= 120_000 → no raise, CLI retries internally."""
    state_path = tmp_path / ".code-generator" / "state.json"
    # After the small retry system line, a normal result follows.
    lines = [_retry_line(60_000), _assistant_line("Retried OK"), _result_line("s2")]
    fake_proc = _make_fake_popen(lines)

    import logging

    logger = logging.getLogger("test.sub.smallratelimit")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        result = await run("do something", options, logger=logger, state_path=state_path)

    assert result.text == "Retried OK"


@pytest.mark.asyncio
async def test_argv_never_contains_bare(tmp_path: Path) -> None:
    """The constructed argv must never include --bare."""
    state_path = tmp_path / ".code-generator" / "state.json"
    lines = [_result_line()]
    fake_proc = _make_fake_popen(lines)

    import logging

    logger = logging.getLogger("test.sub.bare")
    options = _make_options()

    captured_args: list[list[str]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_args.append(args)
        return fake_proc

    popen_target = "code_generator.runner.subprocess_runner.subprocess.Popen"
    with patch(popen_target, side_effect=capture_popen):
        await run("do something", options, logger=logger, state_path=state_path)

    assert captured_args, "Popen was not called"
    argv = captured_args[0]
    assert "--bare" not in argv, f"--bare found in argv: {argv}"


@pytest.mark.asyncio
async def test_env_passed_to_popen_has_no_dangerous_vars(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The env dict passed to Popen must not contain ANTHROPIC_API_KEY."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-should-be-stripped")
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
    state_path = tmp_path / ".code-generator" / "state.json"
    lines = [_result_line()]
    fake_proc = _make_fake_popen(lines)

    import logging

    logger = logging.getLogger("test.sub.env")
    options = _make_options()

    captured_envs: list[dict] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_envs.append(kwargs.get("env", {}))
        return fake_proc

    popen_target = "code_generator.runner.subprocess_runner.subprocess.Popen"
    with patch(popen_target, side_effect=capture_popen):
        await run("do something", options, logger=logger, state_path=state_path)

    assert captured_envs, "Popen was not called"
    assert "ANTHROPIC_API_KEY" not in captured_envs[0]


# ---------------------------------------------------------------------------
# Overage detection tests — Issue #35
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_overage_allowed_raises_overage_abort_and_kills_process(
    tmp_path: Path,
) -> None:
    """system event with overage_status='allowed' raises OverageAbort and kills proc."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    lines = [_overage_line("allowed")]
    fake_proc = _make_fake_popen(lines)

    logger = logging.getLogger("test.sub.overage.allowed")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        with pytest.raises(OverageAbort):
            await run("do something", options, logger=logger, state_path=state_path)

    fake_proc.kill.assert_called()


@pytest.mark.asyncio
async def test_overage_allowed_warning_raises_overage_abort_and_kills_process(
    tmp_path: Path,
) -> None:
    """system event with overage_status='allowed_warning' raises OverageAbort and kills proc."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    lines = [_overage_line("allowed_warning")]
    fake_proc = _make_fake_popen(lines)

    logger = logging.getLogger("test.sub.overage.allowed_warning")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        with pytest.raises(OverageAbort):
            await run("do something", options, logger=logger, state_path=state_path)

    fake_proc.kill.assert_called()


@pytest.mark.asyncio
async def test_overage_rejected_status_does_not_raise(
    tmp_path: Path,
) -> None:
    """system event with overage_status='rejected' must not raise OverageAbort."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    # 'rejected' means overage is OFF — safe to continue
    lines = [_overage_line("rejected"), _assistant_line("ok"), _result_line()]
    fake_proc = _make_fake_popen(lines)

    logger = logging.getLogger("test.sub.overage.rejected")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        result = await run("do something", options, logger=logger, state_path=state_path)

    assert result.text == "ok"


# ---------------------------------------------------------------------------
# Regression tests — Issue #35: subprocess_runner overage silence
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_overage_disabled_status_does_not_raise(
    tmp_path: Path,
) -> None:
    """system event with overage_status='disabled' must NOT raise OverageAbort."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    lines = [_overage_line("disabled"), _assistant_line("ok"), _result_line()]
    fake_proc = _make_fake_popen(lines)

    logger = logging.getLogger("test.sub.overage.disabled")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        result = await run("do something", options, logger=logger, state_path=state_path)

    assert result.text == "ok"


@pytest.mark.asyncio
async def test_overage_none_status_does_not_raise(
    tmp_path: Path,
) -> None:
    """system event with overage_status=null must NOT raise OverageAbort."""
    import json as _json
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    null_overage_line = _json.dumps({"type": "system", "overage_status": None})
    lines = [null_overage_line, _assistant_line("ok"), _result_line()]
    fake_proc = _make_fake_popen(lines)

    logger = logging.getLogger("test.sub.overage.null")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        result = await run("do something", options, logger=logger, state_path=state_path)

    assert result.text == "ok"


# ---------------------------------------------------------------------------
# is_error=True path — Issue #41
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_error_result_raises_api_upstream_error(
    tmp_path: Path,
) -> None:
    """result line with is_error=True → ApiUpstreamError raised and process killed."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    lines = [_error_result_line("sess-err")]
    fake_proc = _make_fake_popen(lines)

    logger = logging.getLogger("test.sub.error_result")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        with pytest.raises(ApiUpstreamError, match="is_error=True"):
            await run("do something", options, logger=logger, state_path=state_path)

    fake_proc.kill.assert_called()


# ---------------------------------------------------------------------------
# _translate_model unit tests — Issue #52
# ---------------------------------------------------------------------------


def test_translate_model_none_returns_default() -> None:
    """_translate_model(None) returns the default model 'claude-sonnet-4-6'."""
    assert _translate_model(None) == "claude-sonnet-4-6"


def test_translate_model_known_alias_returns_identity() -> None:
    """_translate_model('claude-opus-4-7') returns 'claude-opus-4-7' (identity alias)."""
    assert _translate_model("claude-opus-4-7") == "claude-opus-4-7"


def test_translate_model_unknown_passthrough() -> None:
    """_translate_model with an unknown string returns the input unchanged."""
    assert _translate_model("unknown-model-string") == "unknown-model-string"


# ---------------------------------------------------------------------------
# _handle_line unit tests — Issue #52
# ---------------------------------------------------------------------------


def test_handle_line_malformed_json_logs_debug_and_does_not_raise(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Malformed JSON in _handle_line does not raise and logs at DEBUG level."""
    from code_generator.runner.types import TokenUsage

    text_parts: list[str] = []
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    logger = logging.getLogger("test.handle_line.malformed")
    fake_proc = MagicMock()

    with caplog.at_level(logging.DEBUG, logger="test.handle_line.malformed"):
        _handle_line(
            "not valid json {{{",
            text_parts,
            result_holder,
            logger,
            tmp_path / "state.json",
            fake_proc,
        )

    assert text_parts == [], "text_parts must not be mutated on malformed JSON"
    assert result_holder["session_id"] is None, (
        "result_holder must not be mutated on malformed JSON"
    )
    assert any("malformed" in rec.message.lower() for rec in caplog.records), (
        "Expected a DEBUG log mentioning 'malformed'"
    )


def test_handle_line_unknown_msg_type_is_silently_ignored(
    tmp_path: Path,
) -> None:
    """Unknown msg_type in _handle_line does not raise and does not mutate accumulators."""
    from code_generator.runner.types import TokenUsage

    text_parts: list[str] = []
    initial_usage = TokenUsage()
    result_holder: dict[str, Any] = {"session_id": None, "usage": initial_usage}
    logger = logging.getLogger("test.handle_line.unknown_type")
    fake_proc = MagicMock()
    unknown_line = json.dumps({"type": "unknown_future_event", "data": "irrelevant"})

    _handle_line(
        unknown_line,
        text_parts,
        result_holder,
        logger,
        tmp_path / "state.json",
        fake_proc,
    )

    assert text_parts == [], "text_parts must not be mutated for unknown msg_type"
    assert result_holder["session_id"] is None, (
        "result_holder session_id must not be mutated for unknown msg_type"
    )
    assert result_holder["usage"] is initial_usage, (
        "result_holder usage must not be replaced for unknown msg_type"
    )


# ---------------------------------------------------------------------------
# _check_overage_status direct unit tests — Issue #52
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("safe_status", [None, "disabled", "rejected"])
def test_check_overage_status_safe_statuses_do_not_raise(safe_status: str | None) -> None:
    """_check_overage_status does not raise for safe overage statuses."""
    fake_proc = MagicMock()
    data: dict[str, Any] = {"overage_status": safe_status}
    _check_overage_status(data, fake_proc)  # must not raise
    fake_proc.kill.assert_not_called()


# ---------------------------------------------------------------------------
# argv construction tests — Issue #52
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_allowed_tools_present_in_argv_when_provided(
    tmp_path: Path,
) -> None:
    """--allowedTools appears in argv when options.allowed_tools is non-empty."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    options.allowed_tools = ["Read", "Bash"]
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.argv.allowedtools.present")

    captured_argv: list[list[str]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_argv.append(args)
        return fake_proc

    with patch(
        "code_generator.runner.subprocess_runner.subprocess.Popen", side_effect=capture_popen
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert "--allowedTools" in captured_argv[0], "Expected --allowedTools in argv"
    idx = captured_argv[0].index("--allowedTools")
    assert "Read" in captured_argv[0][idx + 1]
    assert "Bash" in captured_argv[0][idx + 1]


@pytest.mark.asyncio
async def test_allowed_tools_absent_from_argv_when_empty(
    tmp_path: Path,
) -> None:
    """--allowedTools is absent from argv when options.allowed_tools is empty."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    options.allowed_tools = []
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.argv.allowedtools.absent")

    captured_argv: list[list[str]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_argv.append(args)
        return fake_proc

    with patch(
        "code_generator.runner.subprocess_runner.subprocess.Popen", side_effect=capture_popen
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert "--allowedTools" not in captured_argv[0], (
        "Expected --allowedTools to be absent from argv"
    )


# ---------------------------------------------------------------------------
# Issue #207 — --max-turns is opt-in only (no silent default)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_max_turns_absent_from_argv_when_options_max_turns_is_none(
    tmp_path: Path,
) -> None:
    """options.max_turns is None → argv must NOT contain --max-turns (#207)."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    options.max_turns = None
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.argv.max_turns.none")

    captured_argv: list[list[str]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_argv.append(args)
        return fake_proc

    with patch(
        "code_generator.runner.subprocess_runner.subprocess.Popen", side_effect=capture_popen
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert "--max-turns" not in captured_argv[0], (
        f"--max-turns must not appear when options.max_turns is None; got {captured_argv[0]}"
    )


@pytest.mark.asyncio
async def test_max_turns_present_in_argv_when_options_max_turns_is_int(
    tmp_path: Path,
) -> None:
    """options.max_turns=200 → argv contains --max-turns followed by '200' (#207)."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    options.max_turns = 200
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.argv.max_turns.int")

    captured_argv: list[list[str]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_argv.append(args)
        return fake_proc

    with patch(
        "code_generator.runner.subprocess_runner.subprocess.Popen", side_effect=capture_popen
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    argv = captured_argv[0]
    assert "--max-turns" in argv, f"--max-turns must appear when opt-in is set; got {argv}"
    idx = argv.index("--max-turns")
    assert argv[idx + 1] == "200", f"expected '200' after --max-turns, got {argv[idx + 1]!r}"


@pytest.mark.asyncio
async def test_max_turns_forwarded_verbatim_when_options_max_turns_is_zero(
    tmp_path: Path,
) -> None:
    """options.max_turns=0 is forwarded as-is; Typer-level validation lives elsewhere (#207)."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    options.max_turns = 0
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.argv.max_turns.zero")

    captured_argv: list[list[str]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_argv.append(args)
        return fake_proc

    with patch(
        "code_generator.runner.subprocess_runner.subprocess.Popen", side_effect=capture_popen
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    argv = captured_argv[0]
    assert "--max-turns" in argv
    idx = argv.index("--max-turns")
    assert argv[idx + 1] == "0"


def test_subprocess_runner_has_no_silent_max_turns_fallback() -> None:
    """Source guard: no residual `getattr(options, "max_turns", 50)` in subprocess_runner (#207)."""
    import re
    from pathlib import Path as _Path

    source = _Path(
        "src/code_generator/runner/subprocess_runner.py",
    ).read_text(encoding="utf-8")

    assert not re.search(r'getattr\(\s*options\s*,\s*["\']max_turns["\']\s*,\s*\d+', source), (
        "subprocess_runner must not contain a numeric fallback for options.max_turns"
    )


@pytest.mark.asyncio
async def test_cwd_passed_to_popen_when_options_cwd_set(
    tmp_path: Path,
) -> None:
    """options.cwd is forwarded as the cwd kwarg to Popen."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    options.cwd = "/some/work/dir"
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.argv.cwd")

    captured_kwargs: list[dict[str, Any]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_kwargs.append(kwargs)
        return fake_proc

    with patch(
        "code_generator.runner.subprocess_runner.subprocess.Popen", side_effect=capture_popen
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert captured_kwargs[0].get("cwd") == "/some/work/dir", (
        "Expected cwd='/some/work/dir' passed to Popen"
    )


@pytest.mark.asyncio
async def test_resume_flag_present_in_argv_when_options_resume_set(
    tmp_path: Path,
) -> None:
    """--resume <session_id> appears in argv when options.resume is set."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    options.resume = "sess-abc-123"
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.argv.resume")

    captured_argv: list[list[str]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_argv.append(args)
        return fake_proc

    with patch(
        "code_generator.runner.subprocess_runner.subprocess.Popen", side_effect=capture_popen
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert "--resume" in captured_argv[0], "Expected --resume in argv"
    idx = captured_argv[0].index("--resume")
    assert captured_argv[0][idx + 1] == "sess-abc-123", "Expected session ID after --resume"


# ---------------------------------------------------------------------------
# Tests — effort plumbing — Issue #68
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_effort_non_none_appends_output_config_flag_to_argv(
    tmp_path: Any,
) -> None:
    """When options.effort is set, --output-config with effort JSON appears in argv."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    options.effort = "high"
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.argv.effort.set")

    captured_argv: list[list[str]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_argv.append(args)
        return fake_proc

    with patch(
        "code_generator.runner.subprocess_runner.subprocess.Popen", side_effect=capture_popen
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert "--output-config" in captured_argv[0], "Expected --output-config in argv"
    idx = captured_argv[0].index("--output-config")
    config = json.loads(captured_argv[0][idx + 1])
    assert config == {"effort": "high"}


@pytest.mark.asyncio
async def test_effort_none_does_not_append_output_config_to_argv(
    tmp_path: Any,
) -> None:
    """When options.effort is None (unset), --output-config is absent from argv."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.argv.effort.none")

    captured_argv: list[list[str]] = []

    def capture_popen(args: list[str], **kwargs: Any) -> Any:
        captured_argv.append(args)
        return fake_proc

    with patch(
        "code_generator.runner.subprocess_runner.subprocess.Popen", side_effect=capture_popen
    ):
        await run("do something", options, logger=logger, state_path=state_path)

    assert "--output-config" not in captured_argv[0], (
        "Expected --output-config to be absent from argv when effort is None"
    )


# ---------------------------------------------------------------------------
# _parse_ndjson unit tests — Issue #87
# ---------------------------------------------------------------------------


def test_parse_ndjson_valid_json_returns_dict() -> None:
    """_parse_ndjson returns a dict for a valid JSON line."""
    logger = logging.getLogger("test.parse_ndjson.valid")
    result = _parse_ndjson('{"type": "assistant"}', logger)
    assert result == {"type": "assistant"}


def test_parse_ndjson_malformed_logs_debug_and_returns_none(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """_parse_ndjson returns None and logs DEBUG for malformed input."""
    logger = logging.getLogger("test.parse_ndjson.malformed")
    with caplog.at_level(logging.DEBUG, logger="test.parse_ndjson.malformed"):
        result = _parse_ndjson("not valid json {{{", logger)
    assert result is None
    assert any("malformed" in rec.message.lower() for rec in caplog.records)


# ---------------------------------------------------------------------------
# _check_upstream_5xx unit tests — Issue #87
# ---------------------------------------------------------------------------


def test_check_upstream_5xx_raises_api_upstream_error_on_5xx_text() -> None:
    """_check_upstream_5xx raises ApiUpstreamError and kills proc on 5xx text."""
    fake_proc = MagicMock()
    with pytest.raises(ApiUpstreamError):
        _check_upstream_5xx("API Error: 502 Bad Gateway", fake_proc)
    fake_proc.kill.assert_called_once()


def test_check_upstream_5xx_does_not_raise_for_normal_text() -> None:
    """_check_upstream_5xx is a no-op for normal text."""
    fake_proc = MagicMock()
    _check_upstream_5xx("Hello, world!", fake_proc)  # must not raise
    fake_proc.kill.assert_not_called()


# ---------------------------------------------------------------------------
# _handle_assistant unit tests — Issue #87
# ---------------------------------------------------------------------------


def test_handle_assistant_appends_text_blocks_to_text_parts() -> None:
    """_handle_assistant accumulates text blocks in text_parts."""
    data = {"message": {"content": [{"type": "text", "text": "Hello!"}, {"type": "tool_use"}]}}
    text_parts: list[str] = []
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_assistant.text")
    _handle_assistant(data, text_parts, logger, fake_proc)
    assert text_parts == ["Hello!"]
    fake_proc.kill.assert_not_called()


def test_handle_assistant_5xx_raises_and_kills_proc() -> None:
    """_handle_assistant raises ApiUpstreamError and kills proc on upstream 5xx text."""
    fake_proc = MagicMock()
    data = {
        "message": {"content": [{"type": "text", "text": "API Error: 503 Service Unavailable"}]}
    }
    text_parts: list[str] = []
    logger = logging.getLogger("test.handle_assistant.5xx")
    with pytest.raises(ApiUpstreamError):
        _handle_assistant(data, text_parts, logger, fake_proc)
    fake_proc.kill.assert_called()


def test_handle_assistant_empty_content_does_nothing() -> None:
    """_handle_assistant with no content blocks leaves text_parts empty."""
    data = {"message": {"content": []}}
    text_parts: list[str] = []
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_assistant.empty")
    _handle_assistant(data, text_parts, logger, fake_proc)
    assert text_parts == []


# ---------------------------------------------------------------------------
# _handle_result unit tests — Issue #87
# ---------------------------------------------------------------------------


def test_handle_result_captures_session_id_and_tokens() -> None:
    """_handle_result populates result_holder with session_id and TokenUsage."""
    from code_generator.runner.types import TokenUsage

    data = {
        "session_id": "sess-xyz",
        "usage": {"input_tokens": 10, "output_tokens": 20},
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.ok")
    _handle_result(data, result_holder, logger, fake_proc)
    assert result_holder["session_id"] == "sess-xyz"
    assert result_holder["usage"].input == 10
    assert result_holder["usage"].output == 20
    fake_proc.kill.assert_not_called()


def test_handle_result_is_error_true_raises_and_kills_proc() -> None:
    """_handle_result raises ApiUpstreamError and kills proc when is_error=True."""
    from code_generator.runner.types import TokenUsage

    data = {
        "is_error": True,
        "result": "something went wrong",
        "session_id": "sess-err",
        "usage": {"input_tokens": 3, "output_tokens": 7},
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.error")
    with pytest.raises(ApiUpstreamError, match="is_error=True"):
        _handle_result(data, result_holder, logger, fake_proc)
    fake_proc.kill.assert_called()


def test_handle_result_max_turns_raises_max_turns_exceeded_not_upstream_error() -> None:
    """_handle_result raises MaxTurnsExceeded (not ApiUpstreamError) when
    subtype == 'error_max_turns' — the canonical SDK signal per Anthropic docs.
    stop_reason carries the model's own last stop reason (e.g. 'tool_use')
    and must NOT be used to detect agent-loop termination."""
    from code_generator.runner.types import TokenUsage

    data = {
        "is_error": True,
        "subtype": "error_max_turns",
        "stop_reason": "tool_use",  # model was mid-tool-use when SDK cut off
        "num_turns": 5,
        "result": "hit max_turns budget",
        "session_id": "sess-maxturns",
        "usage": {"input_tokens": 37, "output_tokens": 1319},
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.max_turns")
    with pytest.raises(MaxTurnsExceeded, match="max_turns budget") as exc_info:
        _handle_result(data, result_holder, logger, fake_proc)
    assert not isinstance(exc_info.value, ApiUpstreamError)
    assert "num_turns=5" in str(exc_info.value)
    assert "error_max_turns" in str(exc_info.value)
    fake_proc.kill.assert_called()


def test_handle_result_max_turns_logs_error_with_counters_before_reraise(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Issue #206: before re-raising MaxTurnsExceeded the runner logs an ERROR
    line carrying num_turns, tokens_in, tokens_out, and the operator-override hint."""
    from code_generator.runner.types import TokenUsage

    data = {
        "is_error": True,
        "subtype": "error_max_turns",
        "stop_reason": "tool_use",
        "num_turns": 12,
        "result": "budget exhausted",
        "session_id": "sess-maxturns-log",
        "usage": {"input_tokens": 250, "output_tokens": 900},
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.max_turns.error_log")
    logger.setLevel(logging.ERROR)

    with (
        caplog.at_level(logging.ERROR, logger=logger.name),
        pytest.raises(MaxTurnsExceeded),
    ):
        _handle_result(data, result_holder, logger, fake_proc)

    error_records = [r for r in caplog.records if r.levelno == logging.ERROR]
    assert error_records, "expected an ERROR log before MaxTurnsExceeded re-raise"
    msg = error_records[0].getMessage()
    assert "num_turns=12" in msg
    assert "tokens_in=250" in msg
    assert "tokens_out=900" in msg
    assert "Check for operator override (--max-turns), SDK/CLI default, or rogue fixture." in msg


def test_handle_result_max_turns_reraises_unchanged_exception_type() -> None:
    """Issue #206: ERROR logging must not change the exception type or inheritance.
    Callers that catch MaxTurnsExceeded (e.g. Phase 3/4 fail-fast) depend on this."""
    from code_generator.runner.types import TokenUsage

    data = {
        "is_error": True,
        "subtype": "error_max_turns",
        "num_turns": 5,
        "result": "hit budget",
        "session_id": "sess-maxturns-regr",
        "usage": {"input_tokens": 1, "output_tokens": 2},
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.max_turns.regression")

    with pytest.raises(MaxTurnsExceeded) as exc_info:
        _handle_result(data, result_holder, logger, fake_proc)

    assert type(exc_info.value) is MaxTurnsExceeded
    assert not isinstance(exc_info.value, ApiUpstreamError)


def test_handle_result_stop_reason_max_tokens_does_not_trigger_max_turns_exceeded() -> None:
    """Defensive regression: stop_reason='max_tokens' (model output ceiling)
    is NOT the same as subtype='error_max_turns' (agent-loop ceiling).
    Must fall through to ApiUpstreamError so the transient retry applies."""
    from code_generator.runner.types import TokenUsage

    data = {
        "is_error": True,
        "subtype": "error_during_execution",
        "stop_reason": "max_tokens",  # model hit output cap, unrelated to loop
        "num_turns": 1,
        "result": "partial output",
        "session_id": "sess-model-maxtok",
        "usage": {"input_tokens": 10, "output_tokens": 4096},
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.model_max_tokens")
    with pytest.raises(ApiUpstreamError) as exc_info:
        _handle_result(data, result_holder, logger, fake_proc)
    assert not isinstance(exc_info.value, MaxTurnsExceeded)


def test_handle_result_missing_usage_stores_zeroed_token_usage() -> None:
    """_handle_result stores a zeroed TokenUsage when usage key is absent in data."""
    from code_generator.runner.types import TokenUsage

    data = {"session_id": "sess-notokens"}
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.nousage")
    _handle_result(data, result_holder, logger, fake_proc)
    assert isinstance(result_holder["usage"], TokenUsage)
    assert result_holder["usage"].input == 0
    assert result_holder["usage"].output == 0


# ---------------------------------------------------------------------------
# Issue #205 — num_turns propagation from CLI stream to RunResult
# ---------------------------------------------------------------------------


def test_handle_result_captures_num_turns() -> None:
    """_handle_result reads num_turns from the NDJSON result and stores it on usage."""
    from code_generator.runner.types import TokenUsage

    data = {
        "session_id": "sess-turns",
        "usage": {"input_tokens": 10, "output_tokens": 20},
        "num_turns": 12,
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.num_turns")

    _handle_result(data, result_holder, logger, fake_proc)

    assert result_holder["usage"].num_turns == 12


def test_handle_result_missing_num_turns_defaults_to_zero() -> None:
    """Missing num_turns key → TokenUsage.num_turns == 0 (backward-compat)."""
    from code_generator.runner.types import TokenUsage

    data = {
        "session_id": "sess-no-turns",
        "usage": {"input_tokens": 1, "output_tokens": 2},
        # intentionally no "num_turns"
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.no_num_turns")

    _handle_result(data, result_holder, logger, fake_proc)

    assert result_holder["usage"].num_turns == 0


@pytest.mark.asyncio
async def test_subprocess_run_result_includes_num_turns(tmp_path: Path) -> None:
    """End-to-end: stream ending with num_turns=12 → RunResult.usage.num_turns == 12."""
    import logging as _logging

    state_path = tmp_path / ".code-generator" / "state.json"
    result_line = json.dumps(
        {
            "type": "result",
            "session_id": "sess-e2e",
            "usage": {"input_tokens": 5, "output_tokens": 15},
            "num_turns": 12,
        }
    )
    lines = [_assistant_line("Hi"), result_line]
    fake_proc = _make_fake_popen(lines)
    logger = _logging.getLogger("test.sub.num_turns")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        result = await run("prompt", options, logger=logger, state_path=state_path)

    assert result.usage.num_turns == 12


def test_two_token_usages_accumulate_num_turns_via_iadd() -> None:
    """Aggregation AC: TokenUsage(num_turns=3) += TokenUsage(num_turns=4) → num_turns=7."""
    from code_generator.runner.types import TokenUsage

    total = TokenUsage(num_turns=3)
    total += TokenUsage(num_turns=4)

    assert total.num_turns == 7


# ---------------------------------------------------------------------------
# _handle_rate_limit unit tests — Issue #87
# ---------------------------------------------------------------------------


def test_handle_rate_limit_large_delay_raises_rate_limit_hit_and_persists_state(
    tmp_path: Any,
) -> None:
    """_handle_rate_limit raises RateLimitHit and writes state with +60s buffer for delay > 120_000ms."""
    from unittest.mock import patch as _patch

    state_path = tmp_path / ".code-generator" / "state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    data = {"retry_delay_ms": 200_000, "session_id": "sess-rl"}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_rate_limit.large")
    fixed_now = 1_700_000_000.0
    with _patch("code_generator.runner.subprocess_runner.time.time", return_value=fixed_now):
        with pytest.raises(RateLimitHit):
            _handle_rate_limit(data, logger, state_path, fake_proc)
    assert state_path.exists()
    raw = json.loads(state_path.read_text())
    # Non-negotiable #5: paused_until = now + delay_seconds + 60
    expected = int(fixed_now + 200_000 / 1000 + 60)
    assert raw["paused_until"] == expected, (
        f"Expected paused_until={expected} (with +60s buffer), got {raw['paused_until']}"
    )
    fake_proc.kill.assert_called()


def test_handle_rate_limit_small_delay_logs_and_does_not_raise(
    tmp_path: Any,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """_handle_rate_limit logs and does not raise for delay <= 120_000ms."""
    state_path = tmp_path / ".code-generator" / "state.json"
    data = {"retry_delay_ms": 60_000, "session_id": "sess-small"}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_rate_limit.small")
    with caplog.at_level(logging.INFO, logger="test.handle_rate_limit.small"):
        _handle_rate_limit(data, logger, state_path, fake_proc)  # must not raise
    fake_proc.kill.assert_not_called()


# ---------------------------------------------------------------------------
# Exit code check tests — Issue #92
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_non_zero_exit_code_raises_api_upstream_error(
    tmp_path: Path,
) -> None:
    """When the CLI exits with a non-zero code, ApiUpstreamError is raised."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    fake_proc = _make_fake_popen([])
    fake_proc.returncode = 1  # simulate authentication failure / bad flag

    logger = logging.getLogger("test.sub.exitcode.nonzero")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        with pytest.raises(ApiUpstreamError, match="exited with code 1"):
            await run("do something", options, logger=logger, state_path=state_path)


@pytest.mark.asyncio
async def test_zero_exit_code_does_not_raise(
    tmp_path: Path,
) -> None:
    """When the CLI exits with code 0, no exception is raised and RunResult is returned."""
    import logging

    state_path = tmp_path / ".code-generator" / "state.json"
    lines = [_assistant_line("Hello!"), _result_line("sess-zero")]
    fake_proc = _make_fake_popen(lines)
    # returncode is already 0 in _make_fake_popen

    logger = logging.getLogger("test.sub.exitcode.zero")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        result = await run("do something", options, logger=logger, state_path=state_path)

    assert result.text == "Hello!"
    assert result.session_id == "sess-zero"


# ---------------------------------------------------------------------------
# _handle_system unit tests — Issue #87
# ---------------------------------------------------------------------------


def test_handle_system_delegates_overage_allowed_raises() -> None:
    """_handle_system raises OverageAbort when overage_status='allowed'."""
    data = {"type": "system", "overage_status": "allowed"}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_system.overage")
    with pytest.raises(OverageAbort):
        _handle_system(data, logger, MagicMock(), fake_proc)
    fake_proc.kill.assert_called()


def test_handle_system_api_retry_rate_limit_large_delay_raises_rate_limit_hit(
    tmp_path: Any,
) -> None:
    """_handle_system raises RateLimitHit for api_retry rate_limit with large delay."""
    state_path = tmp_path / ".code-generator" / "state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "type": "system",
        "subtype": "api_retry",
        "error": "rate_limit",
        "retry_delay_ms": 200_000,
        "session_id": "sess-sys",
    }
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_system.rate_limit")
    with pytest.raises(RateLimitHit):
        _handle_system(data, logger, state_path, fake_proc)


def test_handle_system_no_rate_limit_event_does_not_raise(tmp_path: Any) -> None:
    """_handle_system is silent for a safe system event without rate-limit."""
    state_path = tmp_path / ".code-generator" / "state.json"
    data = {"type": "system", "overage_status": "disabled", "subtype": "something_else"}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_system.safe")
    _handle_system(data, logger, state_path, fake_proc)  # must not raise
    fake_proc.kill.assert_not_called()


# ---------------------------------------------------------------------------
# TokenUsage adoption tests — Issue #119
# ---------------------------------------------------------------------------


def test_handle_result_populates_all_four_token_fields() -> None:
    """_handle_result constructs TokenUsage with all four fields from usage dict."""
    from code_generator.runner.types import TokenUsage

    data = {
        "session_id": "sess-all4",
        "usage": {
            "input_tokens": 10,
            "output_tokens": 20,
            "cache_creation_input_tokens": 30,
            "cache_read_input_tokens": 40,
        },
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.all4")
    _handle_result(data, result_holder, logger, fake_proc)

    usage = result_holder["usage"]
    assert isinstance(usage, TokenUsage)
    assert usage.input == 10
    assert usage.output == 20
    assert usage.cache_write == 30
    assert usage.cache_read == 40


def test_handle_result_missing_cache_fields_default_to_zero() -> None:
    """_handle_result defaults cache_write and cache_read to 0 when absent."""
    from code_generator.runner.types import TokenUsage

    data = {
        "session_id": "sess-nocache",
        "usage": {"input_tokens": 5, "output_tokens": 15},
    }
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.nocache")
    _handle_result(data, result_holder, logger, fake_proc)

    usage = result_holder["usage"]
    assert isinstance(usage, TokenUsage)
    assert usage.input == 5
    assert usage.output == 15
    assert usage.cache_write == 0
    assert usage.cache_read == 0


def test_handle_result_missing_usage_dict_stores_zero_token_usage() -> None:
    """_handle_result stores a zeroed TokenUsage when the usage key is absent."""
    from code_generator.runner.types import TokenUsage

    data = {"session_id": "sess-nousage"}
    result_holder: dict[str, Any] = {"session_id": None, "usage": TokenUsage()}
    fake_proc = MagicMock()
    logger = logging.getLogger("test.handle_result.nousage_token")
    _handle_result(data, result_holder, logger, fake_proc)

    usage = result_holder["usage"]
    assert isinstance(usage, TokenUsage)
    assert usage.input == 0
    assert usage.output == 0
    assert usage.cache_write == 0
    assert usage.cache_read == 0


@pytest.mark.asyncio
async def test_run_result_usage_contains_all_four_fields(
    tmp_path: Path,
) -> None:
    """run() returns RunResult.usage with all four token fields populated."""
    from code_generator.runner.types import TokenUsage

    state_path = tmp_path / ".code-generator" / "state.json"
    result_line_with_cache = json.dumps(
        {
            "type": "result",
            "session_id": "sess-cache",
            "usage": {
                "input_tokens": 100,
                "output_tokens": 200,
                "cache_creation_input_tokens": 50,
                "cache_read_input_tokens": 25,
            },
        }
    )
    lines = [_assistant_line("done"), result_line_with_cache]
    fake_proc = _make_fake_popen(lines)
    import logging as _logging

    logger = _logging.getLogger("test.run.cache")
    options = _make_options()

    with patch("code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc):
        result = await run("do something", options, logger=logger, state_path=state_path)

    assert isinstance(result.usage, TokenUsage)
    assert result.usage.input == 100
    assert result.usage.output == 200
    assert result.usage.cache_write == 50
    assert result.usage.cache_read == 25


# ---------------------------------------------------------------------------
# Session-start log tests — Issue #104
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_session_start_log_includes_effort(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """run() emits an INFO log containing model=, effort=high, and max_turns= when effort is set."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()
    options.effort = "high"
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.sub.session_start.effort_high")

    with caplog.at_level(logging.INFO, logger="test.sub.session_start.effort_high"):
        with patch(
            "code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc
        ):
            await run("do something", options, logger=logger, state_path=state_path)

    session_records = [r for r in caplog.records if "CLI session starting" in r.message]
    assert session_records, "Expected at least one 'CLI session starting' INFO log record"
    msg = session_records[0].message
    assert "model=" in msg, f"Expected 'model=' in log message: {msg!r}"
    assert "effort=high" in msg, f"Expected 'effort=high' in log message: {msg!r}"
    assert "max_turns=" in msg, f"Expected 'max_turns=' in log message: {msg!r}"


@pytest.mark.asyncio
async def test_session_start_log_effort_none_renders_default(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """run() renders effort=default in the session-start log when options.effort is None."""
    state_path = tmp_path / ".code-generator" / "state.json"
    options = _make_options()  # _make_options() does not set effort → getattr returns None
    fake_proc = _make_fake_popen([_result_line()])
    logger = logging.getLogger("test.sub.session_start.effort_none")

    with caplog.at_level(logging.INFO, logger="test.sub.session_start.effort_none"):
        with patch(
            "code_generator.runner.subprocess_runner.subprocess.Popen", return_value=fake_proc
        ):
            await run("do something", options, logger=logger, state_path=state_path)

    session_records = [r for r in caplog.records if "CLI session starting" in r.message]
    assert session_records, "Expected at least one 'CLI session starting' INFO log record"
    msg = session_records[0].message
    assert "effort=default" in msg, f"Expected 'effort=default' in log message: {msg!r}"
