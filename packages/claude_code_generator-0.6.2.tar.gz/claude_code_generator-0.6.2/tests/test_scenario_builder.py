"""Tests for code_generator.orchestrator.scenario_builder — Issue #285.

Group oracle-mapped criteria into named, business-outcome ``Scenario``
objects keyed on the ``### N.`` Scope subsection.
"""

from __future__ import annotations

import dataclasses

import pytest

from code_generator.orchestrator.agent_spec import (
    AgentSpec,
    TierConfig,
    load_agent_spec,
    persist_agent_spec,
)
from code_generator.orchestrator.criteria_oracle import build_oracle_report
from code_generator.orchestrator.scenario_builder import Scenario, build_scenarios

_REQUIREMENTS = """# Foo

## Description
A backend.

## Tech Stack
Python.

## Goals
- Ship it.

## Scope
### 1. Items API
Implement items endpoints.

Acceptance criteria
- [ ] `GET /api/items` returns 200 with JSON list
- [ ] `POST /api/items` creates an item

### 2. User Registration
Sign-up flow.

Acceptance criteria
- [ ] `POST /api/users` creates a user
- [ ] UI renders the registration page

### 3. Dashboard
Render the dashboard page.

Acceptance criteria
- [ ] UI renders the dashboard with a header
- [ ] The page displays the items list

## Non-goals
- None.

## Constraints
- Linux only.

## Global acceptance criteria
- [ ] `GET /health` returns 200
"""


# ---------------------------------------------------------------------------
# Frozen dataclass
# ---------------------------------------------------------------------------


def test_scenario_is_frozen_dataclass_with_tuple_collections() -> None:
    s = Scenario(name="x", section_index=1, criteria=(), t2_endpoints=(), t3_flows=())
    assert dataclasses.is_dataclass(s)
    assert isinstance(s.criteria, tuple)
    with pytest.raises(dataclasses.FrozenInstanceError):
        s.name = "y"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Grouping by `### N.` Scope subsection
# ---------------------------------------------------------------------------


def test_when_multiple_criteria_in_one_section_then_one_scenario_emitted() -> None:
    report = build_oracle_report(_REQUIREMENTS)

    scenarios = build_scenarios(report, _REQUIREMENTS)

    names = [s.name for s in scenarios]
    assert "User Registration" in names
    reg = next(s for s in scenarios if s.name == "User Registration")
    assert reg.section_index == 2
    assert len(reg.criteria) == 2


def test_when_three_scope_sections_then_three_scenarios() -> None:
    report = build_oracle_report(_REQUIREMENTS)

    scenarios = build_scenarios(report, _REQUIREMENTS)

    assert len(scenarios) == 3
    assert [s.section_index for s in scenarios] == [1, 2, 3]


# ---------------------------------------------------------------------------
# T2 endpoint filtering
# ---------------------------------------------------------------------------


def test_when_section_has_endpoints_then_t2_endpoints_only_verifiable_t2() -> None:
    report = build_oracle_report(_REQUIREMENTS)

    scenarios = build_scenarios(report, _REQUIREMENTS)

    items = next(s for s in scenarios if s.name == "Items API")
    assert "GET /api/items" in " ".join(items.t2_endpoints) or any(
        "GET /api/items" in e for e in items.t2_endpoints
    )
    assert all(e for e in items.t2_endpoints)
    reg = next(s for s in scenarios if s.name == "User Registration")
    assert any("/api/users" in e for e in reg.t2_endpoints)
    assert all("UI" not in e for e in reg.t2_endpoints)


# ---------------------------------------------------------------------------
# T3 flows
# ---------------------------------------------------------------------------


def test_when_section_has_ui_criterion_then_t3_flows_populated() -> None:
    report = build_oracle_report(_REQUIREMENTS)

    scenarios = build_scenarios(report, _REQUIREMENTS)

    dashboard = next(s for s in scenarios if s.name == "Dashboard")
    assert len(dashboard.t3_flows) >= 1
    assert any("UI renders" in f or "displays" in f for f in dashboard.t3_flows)


def test_when_section_has_no_ui_criterion_then_t3_flows_empty() -> None:
    report = build_oracle_report(_REQUIREMENTS)

    scenarios = build_scenarios(report, _REQUIREMENTS)

    items = next(s for s in scenarios if s.name == "Items API")
    assert items.t3_flows == ()


# ---------------------------------------------------------------------------
# Empty scope
# ---------------------------------------------------------------------------


def test_when_empty_scope_section_then_scenarios_empty() -> None:
    text = "# Title\n\n## Scope\n\n## Non-goals\n"
    report = build_oracle_report(text)

    scenarios = build_scenarios(report, text)

    assert scenarios == []


def test_when_empty_input_then_scenarios_empty() -> None:
    report = build_oracle_report("")
    assert build_scenarios(report, "") == []


# ---------------------------------------------------------------------------
# AgentSpec.scenarios round-trip
# ---------------------------------------------------------------------------


def test_when_agent_spec_carries_scenarios_then_round_trips_losslessly(tmp_path) -> None:
    scenarios = (
        Scenario(
            name="Items API",
            section_index=1,
            criteria=(),
            t2_endpoints=("GET /api/items", "POST /api/items"),
            t3_flows=(),
        ),
        Scenario(
            name="Dashboard",
            section_index=2,
            criteria=(),
            t2_endpoints=(),
            t3_flows=("UI renders the dashboard",),
        ),
    )
    spec = AgentSpec(
        requirements_hash="abc",
        tiers=(TierConfig(tier_id="T0", enabled=True),),
        scenarios=scenarios,
    )
    persist_agent_spec(spec, tmp_path)
    loaded = load_agent_spec(tmp_path)

    assert loaded == spec
    assert isinstance(loaded.scenarios, tuple)
    assert loaded.scenarios[0].t2_endpoints == ("GET /api/items", "POST /api/items")
    assert loaded.scenarios[1].t3_flows == ("UI renders the dashboard",)


def test_when_agent_spec_legacy_json_then_scenarios_default_empty(tmp_path) -> None:
    """Pre-#285 spec JSON without ``scenarios`` must still load."""
    import json

    target = tmp_path / "phase6_5_spec.json"
    target.write_text(
        json.dumps(
            {
                "requirements_hash": "h",
                "tiers": [
                    {
                        "tier_id": "T0",
                        "enabled": True,
                        "skip_reason": None,
                        "port": None,
                        "health_path": "/health",
                        "boot_window_s": 10.0,
                        "timeout_s": 5.0,
                    }
                ],
                "base_url": "http://127.0.0.1:8000",
                "entry_cmd": [],
            },
            indent=2,
            sort_keys=True,
        ),
        encoding="utf-8",
    )

    loaded = load_agent_spec(tmp_path)

    assert loaded.scenarios == ()
