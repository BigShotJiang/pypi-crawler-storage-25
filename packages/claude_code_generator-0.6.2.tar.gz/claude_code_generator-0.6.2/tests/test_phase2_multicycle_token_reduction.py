"""Phase 2 multi-cycle aggregate token-reduction guard (issue #255).

Cycle 5 acceptance criterion 5: total Opus token consumption for the Phase 2
review across a *full multi-cycle run* is lower than the previous per-issue
baseline. The single-cycle proof lives in
``tests/test_phase2_token_reduction.py``; this file extends the inequality
across an aggregate of multiple ``CycleState`` entries and through the
:mod:`code_generator.state_retention` compaction boundary, so neither a
per-cycle regression nor a retention-layer drop can reintroduce the
per-issue cost silently.

The test mirrors the constants and arithmetic of
``test_phase2_token_reduction.py`` to keep the comparison apples-to-apples.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator import state_retention as _retention
from code_generator.orchestrator import phase2_review
from code_generator.runner.types import TokenUsage
from tests._phase2_helpers import (
    decisions_response,
    identity_with_backoff,
    ok_decision,
)

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Token-cost model — same constants as test_phase2_token_reduction.py
# ---------------------------------------------------------------------------


_SYSTEM_PROMPT_OVERHEAD_TOKENS = 1500
"""System-prompt + repo-map overhead paid once per Opus call."""

_PER_ISSUE_INPUT_DELTA = 350
"""Input-token increment that scales linearly with the number of issues."""

_NUM_CYCLES = 3
"""Multi-cycle aggregate is computed over this many CycleState entries."""


def _per_issue_baseline_input(n_issues: int) -> int:
    """Per-cycle baseline modelled as N independent Opus calls (the legacy path)."""
    return n_issues * _SYSTEM_PROMPT_OVERHEAD_TOKENS + n_issues * _PER_ISSUE_INPUT_DELTA


def _batched_input(n_issues: int) -> int:
    """Per-cycle batched cost — one Opus call carries the system prompt once."""
    return _SYSTEM_PROMPT_OVERHEAD_TOKENS + n_issues * _PER_ISSUE_INPUT_DELTA


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_cycle(cycle_id: int, n_issues: int) -> _state.CycleState:
    """Construct a CycleState with ``n_issues`` open issues for the multi-cycle State."""
    return _state.CycleState(
        id=cycle_id,
        name=f"cycle_{cycle_id}",
        milestone_number=cycle_id,
        milestone_title=f"M{cycle_id}",
        status="open",
        phase=1,
        issues=[
            _state.IssueState(number=cycle_id * 100 + n, status="open", agent="python-pro")
            for n in range(1, n_issues + 1)
        ],
        commit_sha=None,
    )


async def _drive_phase2_for_cycle(
    state: _state.State,
    cycle: _state.CycleState,
    project_dir: Path,
    *,
    batched_usage: TokenUsage,
) -> None:
    """Run ``phase2_review.run`` against *cycle* with a deterministic fake batched call."""
    issue_numbers = [i.number for i in cycle.issues]

    async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):  # noqa: ARG001
        return decisions_response([ok_decision(n) for n in issue_numbers], usage=batched_usage)

    with (
        patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
        patch.object(phase2_review.retry, "with_backoff", side_effect=identity_with_backoff),
        patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
    ):
        await phase2_review.run(
            state,
            cycle,
            project_dir,
            runner_module=MagicMock(),
            logger=logging.getLogger("test"),
        )


def _aggregate_phase2_usage(state: _state.State) -> TokenUsage:
    """Sum every cycle's ``token_usage["phase2"]`` via the public ``__iadd__`` API."""
    aggregate = TokenUsage()
    for cycle in state.cycles:
        if not isinstance(cycle, _state.CycleState):
            continue
        if "phase2" not in cycle.token_usage:
            continue
        aggregate += cycle.token_usage["phase2"]
    return aggregate


# ---------------------------------------------------------------------------
# Aggregate input reduction across cycles
# ---------------------------------------------------------------------------


class TestMulticycleAggregateTokenReduction:
    """Aggregating Phase 2 input across cycles must beat the per-issue projection."""

    @pytest.mark.asyncio
    @pytest.mark.parametrize("n_issues", [3, 5, 7])
    async def test_aggregate_input_below_per_issue_projection(
        self, tmp_path: Path, n_issues: int
    ) -> None:
        """Sum of ``cycle.token_usage["phase2"].input`` < ``_NUM_CYCLES * per_issue_baseline``."""
        from code_generator.repo_info import RepoInfo

        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        state = _state.load_state(state_dir / "missing.json")
        state.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        state.cycles = [_build_cycle(c, n_issues) for c in range(1, _NUM_CYCLES + 1)]
        _state.save_state(state_dir / "state.json", state)

        per_cycle_usage = TokenUsage(input=_batched_input(n_issues), output=0)

        for cycle in state.cycles:
            assert isinstance(cycle, _state.CycleState)
            await _drive_phase2_for_cycle(state, cycle, tmp_path, batched_usage=per_cycle_usage)

        aggregate = _aggregate_phase2_usage(state)
        per_issue_total = _NUM_CYCLES * _per_issue_baseline_input(n_issues)

        assert aggregate.input < per_issue_total, (
            f"aggregate input {aggregate.input} must be < per-issue baseline "
            f"{per_issue_total} for n_issues={n_issues}"
        )

    @pytest.mark.asyncio
    async def test_aggregate_cache_write_split_invariant(self, tmp_path: Path) -> None:
        """BP3 routing: every cycle's ``cache_write`` lands in the 1h bucket on the aggregate."""
        from code_generator.repo_info import RepoInfo

        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        state = _state.load_state(state_dir / "missing.json")
        state.repo = RepoInfo(host="github.com", owner="acme", name="proj")
        n_issues = 4
        state.cycles = [_build_cycle(c, n_issues) for c in range(1, _NUM_CYCLES + 1)]
        _state.save_state(state_dir / "state.json", state)

        per_cycle_usage = TokenUsage(
            input=_batched_input(n_issues),
            output=20,
            cache_read=300,
            cache_write=64,
        )

        for cycle in state.cycles:
            assert isinstance(cycle, _state.CycleState)
            await _drive_phase2_for_cycle(state, cycle, tmp_path, batched_usage=per_cycle_usage)

        aggregate = _aggregate_phase2_usage(state)
        assert aggregate.cache_write_5m + aggregate.cache_write_1h == aggregate.cache_write
        assert aggregate.cache_write_1h == aggregate.cache_write
        assert aggregate.cache_write_5m == 0


# ---------------------------------------------------------------------------
# truncate_old_cycles preserves Phase 2 totals in CycleTelemetrySummary
# ---------------------------------------------------------------------------


class TestRetentionPreservesPhase2Totals:
    """``truncate_old_cycles`` must reflect Phase 2 batched totals in the summary."""

    @pytest.mark.parametrize("n_issues", [3, 5, 7])
    def test_compacted_summary_total_tokens_includes_phase2_input(self, n_issues: int) -> None:
        """Summarised cycles' ``total_tokens`` covers their ``token_usage["phase2"]``."""
        cycles: list[_state.CycleState] = []
        per_cycle_phase2 = TokenUsage(
            input=_batched_input(n_issues),
            output=0,
            cache_read=0,
            cache_write=64,
            cache_write_1h=64,
        )
        for cid in range(1, 13):  # 12 cycles → 2 will be compacted with keep=10
            cycle = _build_cycle(cid, n_issues)
            cycle.token_usage["phase2"] = TokenUsage(
                input=per_cycle_phase2.input,
                output=per_cycle_phase2.output,
                cache_read=per_cycle_phase2.cache_read,
                cache_write=per_cycle_phase2.cache_write,
                cache_write_1h=per_cycle_phase2.cache_write_1h,
            )
            cycles.append(cycle)

        result = _retention.truncate_old_cycles(cycles, keep=10)

        assert len(result) == 12
        compacted = result[:2]
        retained = result[2:]
        assert all(isinstance(s, _retention.CycleTelemetrySummary) for s in compacted)
        assert all(isinstance(c, _state.CycleState) for c in retained)

        expected_total = (
            per_cycle_phase2.input
            + per_cycle_phase2.output
            + per_cycle_phase2.cache_read
            + per_cycle_phase2.cache_write
        )
        for summary in compacted:
            assert isinstance(summary, _retention.CycleTelemetrySummary)
            assert summary.total_tokens == expected_total, (
                "CycleTelemetrySummary.total_tokens must include the Phase 2 contribution; "
                f"got {summary.total_tokens}, expected {expected_total}"
            )

    def test_truncate_with_no_old_cycles_is_passthrough(self) -> None:
        """``truncate_old_cycles`` with len <= keep returns a list of full ``CycleState``."""
        cycles = [_build_cycle(cid, 3) for cid in range(1, 6)]
        for c in cycles:
            c.token_usage["phase2"] = TokenUsage(input=_batched_input(3))

        result = _retention.truncate_old_cycles(cycles, keep=10)

        assert len(result) == len(cycles)
        assert all(isinstance(c, _state.CycleState) for c in result)
