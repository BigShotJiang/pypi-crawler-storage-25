"""Tests for T3 pass-rate threshold across N runs (#292)."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from code_generator.orchestrator.agent_spec import TierConfig
from code_generator.orchestrator.tier_t3 import (
    Scenario,
    ScenarioFailure,
    run_t3_browser,
)

if TYPE_CHECKING:
    from types import TracebackType


class _ProgrammableSession:
    """Fake Playwright MCP session whose ``run_scenario`` returns queued outcomes."""

    def __init__(self, outcomes: list[ScenarioFailure | None]) -> None:
        self._queue = list(outcomes)
        self.scenarios_run: list[str] = []
        self.closed = False

    def __enter__(self) -> _ProgrammableSession:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.closed = True

    def run_scenario(self, scenario: Scenario) -> ScenarioFailure | None:
        self.scenarios_run.append(scenario.name)
        return self._queue.pop(0) if self._queue else None

    def screenshot(self, path: str) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_bytes(b"png")

    def console_messages(self) -> list[str]:
        return []


def _factory(session: _ProgrammableSession):  # type: ignore[no-untyped-def]
    def make(*, env, base_url):  # type: ignore[no-untyped-def]
        del env, base_url
        return session

    return make


def _scenario(name: str = "smoke") -> Scenario:
    return Scenario(name=name, steps=("goto /",))


def test_when_two_of_three_runs_pass_at_threshold_1_0_then_t3_fails(tmp_path: Path) -> None:
    session = _ProgrammableSession([None, ScenarioFailure(detail="flake"), None])
    tier_config = TierConfig(tier_id="T3", enabled=True, runs=3, pass_rate_threshold=1.0)

    result = run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario()],
        mcp_factory=_factory(session),
        tier_config=tier_config,
    )

    assert result.tier_id == "T3"
    assert result.passed is False
    assert result.skipped is False
    assert result.failing_detail is not None


def test_when_two_of_three_runs_pass_at_threshold_0_67_then_t3_passes(tmp_path: Path) -> None:
    session = _ProgrammableSession([None, ScenarioFailure(detail="flake"), None])
    tier_config = TierConfig(tier_id="T3", enabled=True, runs=3, pass_rate_threshold=0.67)

    result = run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario()],
        mcp_factory=_factory(session),
        tier_config=tier_config,
    )

    assert result.passed is True
    assert result.skipped is False


def test_when_three_of_three_runs_pass_at_threshold_1_0_then_t3_passes(tmp_path: Path) -> None:
    session = _ProgrammableSession([None, None, None])
    tier_config = TierConfig(tier_id="T3", enabled=True, runs=3, pass_rate_threshold=1.0)

    result = run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario()],
        mcp_factory=_factory(session),
        tier_config=tier_config,
    )

    assert result.passed is True


def test_when_no_tier_config_then_legacy_single_run_behavior(tmp_path: Path) -> None:
    session = _ProgrammableSession([ScenarioFailure(detail="boom")])

    result = run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario()],
        mcp_factory=_factory(session),
    )

    assert result.passed is False
    assert len(session.scenarios_run) == 1


def test_when_session_closed_via_context_manager_after_multi_run(tmp_path: Path) -> None:
    session = _ProgrammableSession([None, None, None])
    tier_config = TierConfig(tier_id="T3", enabled=True, runs=3, pass_rate_threshold=1.0)

    run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario()],
        mcp_factory=_factory(session),
        tier_config=tier_config,
    )

    assert session.closed is True
