"""Tests for Phase65BudgetTracker — wall + turn budget for the Phase 6.5 loop (#293)."""

from __future__ import annotations

import logging
import time

import pytest

from code_generator.orchestrator.phase6_5_verify import VerificationFailed
from code_generator.orchestrator.phase65_budget import Phase65BudgetTracker


def _logger() -> logging.Logger:
    return logging.getLogger("test.phase65_budget")


def test_when_both_budgets_none_then_check_never_raises():
    tracker = Phase65BudgetTracker(wall_budget_s=None, turn_budget=None)
    tracker.start()

    for turns in (0, 5, 100, 10_000):
        tracker.check(turns_consumed=turns, logger=_logger())


def test_when_turn_budget_exceeded_then_check_raises_verification_failed():
    tracker = Phase65BudgetTracker(wall_budget_s=None, turn_budget=5)
    tracker.start()

    tracker.check(turns_consumed=4, logger=_logger())

    with pytest.raises(VerificationFailed, match="turn budget"):
        tracker.check(turns_consumed=6, logger=_logger())


def test_when_turn_budget_equals_consumed_then_no_raise():
    tracker = Phase65BudgetTracker(wall_budget_s=None, turn_budget=5)
    tracker.start()

    tracker.check(turns_consumed=5, logger=_logger())


def test_when_wall_budget_exceeded_then_check_raises_verification_failed(
    monkeypatch: pytest.MonkeyPatch,
):
    fake_clock = iter([100.0, 200.0])
    monkeypatch.setattr(time, "monotonic", lambda: next(fake_clock))

    tracker = Phase65BudgetTracker(wall_budget_s=30.0, turn_budget=None)
    tracker.start()

    with pytest.raises(VerificationFailed, match="wall budget"):
        tracker.check(turns_consumed=0, logger=_logger())


def test_when_wall_budget_within_then_no_raise(monkeypatch: pytest.MonkeyPatch):
    fake_clock = iter([100.0, 120.0])
    monkeypatch.setattr(time, "monotonic", lambda: next(fake_clock))

    tracker = Phase65BudgetTracker(wall_budget_s=30.0, turn_budget=None)
    tracker.start()

    tracker.check(turns_consumed=0, logger=_logger())


def test_when_check_called_without_start_then_raises_runtime_error():
    tracker = Phase65BudgetTracker(wall_budget_s=10.0, turn_budget=10)

    with pytest.raises(RuntimeError, match="start"):
        tracker.check(turns_consumed=0, logger=_logger())


def test_when_turn_budget_breached_then_error_carries_actual_count():
    tracker = Phase65BudgetTracker(wall_budget_s=None, turn_budget=3)
    tracker.start()

    with pytest.raises(VerificationFailed) as exc:
        tracker.check(turns_consumed=10, logger=_logger())

    assert "10" in str(exc.value)
    assert "3" in str(exc.value)
