"""Tests for code_generator.orchestrator.tier_selector — Issue #281.

Derives ``AgentSpec.tiers`` enabled/disabled flags from agent selection
plus filesystem presence checks for docker artifacts.
"""

from __future__ import annotations

from pathlib import Path

from code_generator.orchestrator.tier_selector import select_tiers

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_BACKEND_REQUIREMENTS = """# Foo

## Description
A backend.

## Tech Stack
FastAPI + Postgres.

## Goals
- Backend only.

## Scope

## Non-goals

## Constraints

## Global acceptance criteria
- [ ] `GET /health` returns 200
"""

_FULLSTACK_REQUIREMENTS = """# Foo

## Description
A full-stack app.

## Tech Stack
Angular + FastAPI + Postgres.

## Goals
- Full stack.

## Scope

## Non-goals

## Constraints

## Global acceptance criteria
- [ ] `GET /health` returns 200
"""

_FRONTEND_REQUIREMENTS = """# Foo

## Description
A frontend-only app.

## Tech Stack
Angular + Supabase.

## Goals
- Frontend only.

## Scope

## Non-goals

## Constraints

## Global acceptance criteria
- [ ] `GET /health` returns 200
"""


def _write_requirements(project_dir: Path, body: str) -> Path:
    dot = project_dir / ".code-generator"
    dot.mkdir(parents=True, exist_ok=True)
    req = dot / "requirements.md"
    req.write_text(body, encoding="utf-8")
    return req


def _tier_by_id(tiers: list, tier_id: str):  # type: ignore[type-arg]
    return next(t for t in tiers if t.tier_id == tier_id)


# ---------------------------------------------------------------------------
# Acceptance scenarios
# ---------------------------------------------------------------------------


def test_when_backend_only_then_t3_and_t4_skipped_with_reasons(tmp_path: Path) -> None:
    req = _write_requirements(tmp_path, _BACKEND_REQUIREMENTS)

    tiers = select_tiers(tmp_path, req)

    t3 = _tier_by_id(tiers, "T3")
    t4 = _tier_by_id(tiers, "T4")
    assert t3.enabled is False
    assert t3.skip_reason
    assert t4.enabled is False
    assert t4.skip_reason


def test_when_fullstack_with_compose_then_all_tiers_enabled(tmp_path: Path) -> None:
    req = _write_requirements(tmp_path, _FULLSTACK_REQUIREMENTS)
    (tmp_path / "docker-compose.yml").write_text("services: {}\n", encoding="utf-8")

    tiers = select_tiers(tmp_path, req)

    for tier_id in ("T0", "T1", "T2", "T3", "T4"):
        assert _tier_by_id(tiers, tier_id).enabled is True


def test_when_dockerfile_only_then_t4_enabled_t3_skipped(tmp_path: Path) -> None:
    req = _write_requirements(tmp_path, _BACKEND_REQUIREMENTS)
    (tmp_path / "Dockerfile").write_text("FROM python:3.12\n", encoding="utf-8")

    tiers = select_tiers(tmp_path, req)

    assert _tier_by_id(tiers, "T3").enabled is False
    assert _tier_by_id(tiers, "T4").enabled is True


def test_when_frontend_only_then_t3_enabled_t4_skipped(tmp_path: Path) -> None:
    req = _write_requirements(tmp_path, _FRONTEND_REQUIREMENTS)

    tiers = select_tiers(tmp_path, req)

    assert _tier_by_id(tiers, "T3").enabled is True
    assert _tier_by_id(tiers, "T4").enabled is False
    assert _tier_by_id(tiers, "T4").skip_reason


def test_when_compose_yaml_variant_then_t4_enabled(tmp_path: Path) -> None:
    req = _write_requirements(tmp_path, _FULLSTACK_REQUIREMENTS)
    (tmp_path / "docker-compose.yaml").write_text("services: {}\n", encoding="utf-8")

    tiers = select_tiers(tmp_path, req)

    assert _tier_by_id(tiers, "T4").enabled is True


def test_when_has_frontend_override_then_skips_filesystem_detect(tmp_path: Path) -> None:
    req = _write_requirements(tmp_path, _BACKEND_REQUIREMENTS)

    tiers = select_tiers(tmp_path, req, has_frontend=True)

    assert _tier_by_id(tiers, "T3").enabled is True
