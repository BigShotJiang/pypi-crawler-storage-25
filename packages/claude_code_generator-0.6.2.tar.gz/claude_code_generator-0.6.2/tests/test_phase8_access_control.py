"""Phase 8 access-control + orchestrator-derived professionalized flag (#330).

Locks the two briefing invariants:

1. The SDK runner has **no Write access** to ``.code-generator/checklists/``
   during the finalization prompt. ``allowed_tools=["Read"]`` is the only
   barrier between the model and a hostile checklist mutation. The repair
   prompt does receive ``Write`` (it edits workflow YAML), so the contrast is
   itself part of the contract.

2. ``professionalized`` is set by the orchestrator from real outcomes
   (``_tick_professionalized_for_closed_issues`` invoked AFTER
   ``_run_ci_green_gate``), never parsed from the prompt response. Exhausted
   outcomes leave the flag untouched; the ``state.repo is None``
   local-only path ticks unconditionally.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import pytest

from code_generator import checklist as _checklist
from code_generator import state as _state
from code_generator.orchestrator import phase8_finalization, phase8_repair_loop
from code_generator.repo_info import RepoInfo
from code_generator.runner.types import RunResult, TokenUsage
from tests.test_phase8_finalization import (
    _make_cycle,
    _make_run_result,
    _make_state,
    _seed_phase8_checklist,
    _stub_git,
    _stub_repair,
    _stub_workflow_gen,
)

_LOGGER = logging.getLogger("test.phase8_access_control")


def _make_repo() -> RepoInfo:
    return RepoInfo(host="github.com", owner="o", name="r")


def _mark_as_git_repo(project_dir: Path) -> None:
    (project_dir / ".git").mkdir(exist_ok=True)


def _empty_run_result() -> RunResult:
    return RunResult(text="", session_id=None, usage=TokenUsage(), wall_seconds=0.0)


# ---------------------------------------------------------------------------
# Finalization prompt — read-only contract
# ---------------------------------------------------------------------------


class TestFinalizationPromptAllowedTools:
    @pytest.mark.asyncio
    async def test_finalization_prompt_allowed_tools_read_only(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        state = _make_state(tmp_path, requirements_hash="abcd1234")
        _stub_workflow_gen(monkeypatch)
        captured: dict[str, Any] = {}

        async def capture_main_loop(_runner, _prompt, options, **_kw):
            captured["options"] = options
            return _make_run_result()

        monkeypatch.setattr(phase8_finalization.rate_limit, "main_loop", capture_main_loop)

        await phase8_finalization.run(state, None, tmp_path, runner_module=object(), logger=_LOGGER)

        assert captured["options"].allowed_tools == ["Read"]


# ---------------------------------------------------------------------------
# Repair agent — write + bash allowed
# ---------------------------------------------------------------------------


class TestRepairAgentAllowedTools:
    @pytest.mark.asyncio
    async def test_repair_agent_allowed_tools_includes_write_and_bash(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        captured: dict[str, Any] = {}

        async def capture_main_loop(_runner, _prompt, options, **_kw):
            captured["options"] = options
            return _empty_run_result()

        monkeypatch.setattr(phase8_repair_loop.rate_limit, "main_loop", capture_main_loop)

        await phase8_repair_loop._invoke_repair_agent(
            project_dir=tmp_path,
            state_path=tmp_path / "state.json",
            logger=_LOGGER,
            runner_module=object(),
            effective_model=None,
            state_mode="single",
            failing_jobs=["ci"],
            logs="FAILED tests/test_x.py",
            attempt=0,
            max_attempts=5,
        )

        tools = captured["options"].allowed_tools
        assert "Write" in tools
        assert "Bash" in tools


# ---------------------------------------------------------------------------
# Professionalized is orchestrator-derived, not model self-reported
# ---------------------------------------------------------------------------


class TestProfessionalizedDerivedFromOutcomes:
    @pytest.mark.asyncio
    async def test_professionalized_set_from_outcomes_not_model_response(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Tick must fire AFTER ``_run_ci_green_gate`` returns, not from prompt parse."""
        state = _make_state(
            tmp_path,
            issues=[_state.IssueState(number=1, status="closed", agent="python-pro", title="A")],
            requirements_hash="abcd1234",
        )
        state.repo = _make_repo()
        _mark_as_git_repo(tmp_path)
        _seed_phase8_checklist(tmp_path, "abcd1234", [1])

        _stub_workflow_gen(monkeypatch)
        _stub_git(monkeypatch, tags=["v1.2.3"])
        _stub_repair(monkeypatch, outcome="green")

        order: list[str] = []

        async def fake_main_loop(_runner, _prompt, _options, **_kw):
            order.append("prompt")
            return _make_run_result()

        # Patch the green-gate to record ordering relative to the tick.
        async def fake_green_gate(**_kw):
            order.append("green-gate")
            return "green"

        monkeypatch.setattr(phase8_finalization.rate_limit, "main_loop", fake_main_loop)
        monkeypatch.setattr(phase8_finalization, "_run_ci_green_gate", fake_green_gate)
        orig_tick = phase8_finalization._tick_professionalized_for_closed_issues

        def tracing_tick(*args, **kw):
            order.append("tick")
            orig_tick(*args, **kw)

        monkeypatch.setattr(
            phase8_finalization, "_tick_professionalized_for_closed_issues", tracing_tick
        )

        await phase8_finalization.run(state, None, tmp_path, runner_module=object(), logger=_LOGGER)

        # green-gate must precede the tick; tick must occur after prompt.
        assert order.index("green-gate") < order.index("tick")
        assert order.index("prompt") < order.index("tick")

        checklist_path = tmp_path / ".code-generator" / "checklists" / "abcd1234.json"
        entries = _checklist.load(checklist_path)
        assert entries[0].professionalized is True

    @pytest.mark.asyncio
    async def test_professionalized_not_ticked_on_exhausted_outcome(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        state = _make_state(
            tmp_path,
            issues=[_state.IssueState(number=1, status="closed", agent="python-pro", title="A")],
            requirements_hash="abcd1234",
        )
        state.repo = _make_repo()
        _mark_as_git_repo(tmp_path)
        _seed_phase8_checklist(tmp_path, "abcd1234", [1])

        _stub_workflow_gen(monkeypatch)
        _stub_git(monkeypatch, tags=[])
        _stub_repair(monkeypatch, outcome="exhausted")

        async def fake_main_loop(_runner, _prompt, _options, **_kw):
            return _make_run_result()

        monkeypatch.setattr(phase8_finalization.rate_limit, "main_loop", fake_main_loop)

        await phase8_finalization.run(state, None, tmp_path, runner_module=object(), logger=_LOGGER)

        checklist_path = tmp_path / ".code-generator" / "checklists" / "abcd1234.json"
        entries = _checklist.load(checklist_path)
        assert entries[0].professionalized is False

    @pytest.mark.asyncio
    async def test_professionalized_ticked_on_skipped_local_only_path(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``state.repo is None`` → CI gate skipped → tick still fires (local-only dev)."""
        state = _make_state(
            tmp_path,
            issues=[_state.IssueState(number=1, status="closed", agent="python-pro", title="A")],
            requirements_hash="abcd1234",
        )
        state.repo = None
        _seed_phase8_checklist(tmp_path, "abcd1234", [1])

        _stub_workflow_gen(monkeypatch)

        async def fake_main_loop(_runner, _prompt, _options, **_kw):
            return _make_run_result()

        monkeypatch.setattr(phase8_finalization.rate_limit, "main_loop", fake_main_loop)

        cycle = _make_cycle(
            issues=[_state.IssueState(number=1, status="closed", agent="python-pro", title="A")]
        )
        await phase8_finalization.run(
            state, cycle, tmp_path, runner_module=object(), logger=_LOGGER
        )

        checklist_path = tmp_path / ".code-generator" / "checklists" / "abcd1234.json"
        entries = _checklist.load(checklist_path)
        assert entries[0].professionalized is True
