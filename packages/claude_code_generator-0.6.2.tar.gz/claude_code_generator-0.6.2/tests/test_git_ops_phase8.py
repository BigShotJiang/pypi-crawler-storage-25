"""Tests for the Phase 8 tag/log primitives added to code_generator.git_ops.

Each test exercises the real git binary against a bare repo built in
``tmp_path``. Test-only ``subprocess.run`` for ``git init`` / setup is
permitted; production code under test must route every git call through
``code_generator.git_ops._run``.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest

from code_generator import git_ops
from code_generator.git_ops import GitError

# ---------------------------------------------------------------------------
# Repo fixture helpers (test-only direct subprocess use)
# ---------------------------------------------------------------------------


def _git_env() -> dict[str, str]:
    return {
        **os.environ,
        "GIT_AUTHOR_NAME": "test",
        "GIT_AUTHOR_EMAIL": "t@t.com",
        "GIT_COMMITTER_NAME": "test",
        "GIT_COMMITTER_EMAIL": "t@t.com",
    }


def _init_repo(path: Path) -> None:
    subprocess.run(
        ["git", "init", "-b", "main", str(path)],
        check=True,
        capture_output=True,
    )


def _commit(path: Path, message: str) -> str:
    subprocess.run(
        ["git", "commit", "--allow-empty", "-m", message],
        cwd=path,
        check=True,
        capture_output=True,
        env=_git_env(),
    )
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=path,
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def _tag(path: Path, tag: str, message: str = "") -> None:
    argv = ["git", "tag", "-a", tag, "-m", message or tag]
    subprocess.run(argv, cwd=path, check=True, capture_output=True, env=_git_env())


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    _init_repo(tmp_path)
    return tmp_path


@pytest.fixture
def origin(tmp_path: Path) -> tuple[Path, Path]:
    """Return (working_repo, bare_origin) with `origin` remote wired up."""
    bare = tmp_path / "origin.git"
    subprocess.run(
        ["git", "init", "--bare", str(bare)],
        check=True,
        capture_output=True,
    )
    work = tmp_path / "work"
    _init_repo(work)
    subprocess.run(
        ["git", "remote", "add", "origin", str(bare)],
        cwd=work,
        check=True,
        capture_output=True,
    )
    return work, bare


# ---------------------------------------------------------------------------
# git_tag_list
# ---------------------------------------------------------------------------


class TestGitTagList:
    def test_when_no_tags_then_empty_list_is_returned(self, repo: Path) -> None:
        _commit(repo, "init")
        assert git_ops.git_tag_list(repo) == []

    def test_when_empty_repo_then_empty_list_is_returned(self, repo: Path) -> None:
        assert git_ops.git_tag_list(repo) == []

    def test_when_tags_exist_then_v_prefixed_tags_returned_descending(self, repo: Path) -> None:
        _commit(repo, "init")
        _tag(repo, "v0.1.0")
        _commit(repo, "feat")
        _tag(repo, "v0.2.0")
        _commit(repo, "feat")
        _tag(repo, "v1.0.0")

        assert git_ops.git_tag_list(repo) == ["v1.0.0", "v0.2.0", "v0.1.0"]

    def test_when_non_v_tags_present_then_they_are_filtered_out(self, repo: Path) -> None:
        _commit(repo, "init")
        _tag(repo, "v0.1.0")
        _tag(repo, "release-1")
        _tag(repo, "hotfix")

        assert git_ops.git_tag_list(repo) == ["v0.1.0"]

    def test_when_cwd_is_not_a_repo_then_empty_list_is_returned(self, tmp_path: Path) -> None:
        """check=False — empty tag namespace must not raise."""
        not_a_repo = tmp_path / "no-repo"
        not_a_repo.mkdir()
        assert git_ops.git_tag_list(not_a_repo) == []


# ---------------------------------------------------------------------------
# git_log_since
# ---------------------------------------------------------------------------


class TestGitLogSince:
    def test_when_ref_is_empty_then_every_commit_is_returned(self, repo: Path) -> None:
        sha1 = _commit(repo, "feat: first")
        sha2 = _commit(repo, "fix: second")

        lines = git_ops.git_log_since(repo, "")

        assert lines == [f"{sha2} fix: second", f"{sha1} feat: first"]

    def test_when_ref_is_missing_tag_then_every_commit_is_returned(self, repo: Path) -> None:
        sha1 = _commit(repo, "feat: first")
        sha2 = _commit(repo, "fix: second")

        lines = git_ops.git_log_since(repo, "v9.9.9")

        assert lines == [f"{sha2} fix: second", f"{sha1} feat: first"]

    def test_when_empty_repo_then_empty_list_is_returned(self, repo: Path) -> None:
        assert git_ops.git_log_since(repo, "") == []

    def test_when_ref_exists_then_only_commits_after_ref_are_returned(self, repo: Path) -> None:
        _commit(repo, "init")
        _tag(repo, "v0.1.0")
        sha_a = _commit(repo, "feat: a")
        sha_b = _commit(repo, "fix: b")

        lines = git_ops.git_log_since(repo, "v0.1.0")

        assert lines == [f"{sha_b} fix: b", f"{sha_a} feat: a"]

    def test_when_ref_equals_head_then_empty_list_is_returned(self, repo: Path) -> None:
        _commit(repo, "init")
        _tag(repo, "v0.1.0")

        assert git_ops.git_log_since(repo, "v0.1.0") == []

    def test_when_cwd_is_not_a_repo_then_git_error_is_raised(self, tmp_path: Path) -> None:
        not_a_repo = tmp_path / "no-repo"
        not_a_repo.mkdir()
        with pytest.raises(GitError):
            git_ops.git_log_since(not_a_repo, "")


# ---------------------------------------------------------------------------
# git_tag_annotated
# ---------------------------------------------------------------------------


class TestGitTagAnnotated:
    def test_when_called_then_annotated_tag_is_created_at_head(self, repo: Path) -> None:
        _commit(repo, "init")

        git_ops.git_tag_annotated(repo, "v1.0.0", "release v1.0.0")

        result = subprocess.run(
            ["git", "tag", "--list", "v1.0.0"],
            cwd=repo,
            check=True,
            capture_output=True,
            text=True,
        )
        assert result.stdout.strip() == "v1.0.0"

    def test_when_called_then_tag_has_message(self, repo: Path) -> None:
        _commit(repo, "init")

        git_ops.git_tag_annotated(repo, "v1.0.0", "release v1.0.0")

        result = subprocess.run(
            ["git", "tag", "-l", "v1.0.0", "--format=%(contents)"],
            cwd=repo,
            check=True,
            capture_output=True,
            text=True,
        )
        assert "release v1.0.0" in result.stdout

    def test_when_called_then_tag_is_annotated_not_lightweight(self, repo: Path) -> None:
        _commit(repo, "init")

        git_ops.git_tag_annotated(repo, "v1.0.0", "release v1.0.0")

        result = subprocess.run(
            ["git", "cat-file", "-t", "v1.0.0"],
            cwd=repo,
            check=True,
            capture_output=True,
            text=True,
        )
        assert result.stdout.strip() == "tag"

    def test_when_tag_already_exists_then_git_error_is_raised(self, repo: Path) -> None:
        _commit(repo, "init")
        git_ops.git_tag_annotated(repo, "v1.0.0", "first")

        with pytest.raises(GitError):
            git_ops.git_tag_annotated(repo, "v1.0.0", "second")

    def test_when_cwd_is_not_a_repo_then_git_error_is_raised(self, tmp_path: Path) -> None:
        not_a_repo = tmp_path / "no-repo"
        not_a_repo.mkdir()
        with pytest.raises(GitError):
            git_ops.git_tag_annotated(not_a_repo, "v1.0.0", "msg")


# ---------------------------------------------------------------------------
# git_push_tag
# ---------------------------------------------------------------------------


class TestGitPushTag:
    def test_when_tag_pushed_then_origin_contains_it(self, origin: tuple[Path, Path]) -> None:
        work, bare = origin
        _commit(work, "init")
        git_ops.git_tag_annotated(work, "v1.0.0", "release")

        git_ops.git_push_tag(work, "v1.0.0")

        result = subprocess.run(
            ["git", "tag", "--list", "v1.0.0"],
            cwd=bare,
            check=True,
            capture_output=True,
            text=True,
        )
        assert result.stdout.strip() == "v1.0.0"

    def test_when_tag_does_not_exist_then_git_error_is_raised(
        self, origin: tuple[Path, Path]
    ) -> None:
        work = origin[0]
        _commit(work, "init")

        with pytest.raises(GitError):
            git_ops.git_push_tag(work, "v9.9.9")

    def test_when_origin_remote_missing_then_git_error_is_raised(self, repo: Path) -> None:
        _commit(repo, "init")
        git_ops.git_tag_annotated(repo, "v1.0.0", "release")

        with pytest.raises(GitError):
            git_ops.git_push_tag(repo, "v1.0.0")
