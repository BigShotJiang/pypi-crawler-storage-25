"""Tests for the Gemini preflight (binary + non-interactive auth checks)."""

from unittest.mock import patch

import pytest

from code_generator.preflight import PreflightError, run_gemini_preflight

_NO_AUTH_ENV = {
    "GEMINI_API_KEY": "",
    "GOOGLE_API_KEY": "",
    "GOOGLE_CLOUD_PROJECT": "",
    "GOOGLE_GENAI_USE_VERTEXAI": "",
    "GOOGLE_APPLICATION_CREDENTIALS": "",
}


def test_binary_missing_raises():
    with patch("shutil.which", return_value=None):
        with pytest.raises(PreflightError, match="gemini CLI binary not found"):
            run_gemini_preflight()


def test_gemini_api_key_satisfies_auth():
    with (
        patch("shutil.which", return_value="/usr/local/bin/gemini"),
        patch.dict("os.environ", {**_NO_AUTH_ENV, "GEMINI_API_KEY": "key123"}, clear=False),
    ):
        run_gemini_preflight()  # must not raise


def test_service_account_file_satisfies_auth(tmp_path):
    sa = tmp_path / "sa.json"
    sa.write_text("{}", encoding="utf-8")
    with (
        patch("shutil.which", return_value="/usr/local/bin/gemini"),
        patch.dict(
            "os.environ",
            {**_NO_AUTH_ENV, "GOOGLE_APPLICATION_CREDENTIALS": str(sa)},
            clear=False,
        ),
    ):
        run_gemini_preflight()  # must not raise


def test_google_api_key_with_vertex_satisfies_auth():
    with (
        patch("shutil.which", return_value="/usr/local/bin/gemini"),
        patch.dict(
            "os.environ",
            {**_NO_AUTH_ENV, "GOOGLE_API_KEY": "gk", "GOOGLE_CLOUD_PROJECT": "proj"},
            clear=False,
        ),
    ):
        run_gemini_preflight()  # must not raise


def test_cached_oauth_file_satisfies_auth(tmp_path):
    creds = tmp_path / "credentials.json"
    creds.write_text("{}", encoding="utf-8")
    with (
        patch("shutil.which", return_value="/usr/local/bin/gemini"),
        patch.dict("os.environ", _NO_AUTH_ENV, clear=False),
        patch(
            "code_generator.preflight._check_cached_oauth",
            return_value=True,
        ),
    ):
        run_gemini_preflight()  # must not raise

    # Sanity: the real check returns False when no creds file is present.
    with patch("os.path.isfile", return_value=False):
        from code_generator.preflight import _check_cached_oauth

        assert _check_cached_oauth() is False


def test_no_credentials_raises_with_fix_command():
    with (
        patch("shutil.which", return_value="/usr/local/bin/gemini"),
        patch.dict("os.environ", _NO_AUTH_ENV, clear=False),
        patch("code_generator.preflight._check_cached_oauth", return_value=False),
    ):
        with pytest.raises(PreflightError) as exc_info:
            run_gemini_preflight()
    assert "GEMINI_API_KEY" in exc_info.value.fix_command
