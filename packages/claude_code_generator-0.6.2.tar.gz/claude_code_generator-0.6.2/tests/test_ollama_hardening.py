"""Tests for Ollama single-model hardening (issue #268).

AC coverage:
- OllamaModelRequiredError exists with fix-action message
- _resolve_effective_model raises when on Ollama path and no model resolvable
- _run_phases raises when effective_model starts with claude-
- env warns when model tag starts with claude-* on localhost routing
- Legacy state.json without ollama_model raises clear error on --continue
- Anthropic Max path unchanged (effective_model=None)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.exceptions import OllamaModelRequiredError
from code_generator.runner.types import RunResult, TokenUsage

if TYPE_CHECKING:
    from pathlib import Path


_OLLAMA_TAG = "qwen3-coder:480b:cloud"
_CLAUDE_TAG = "claude-opus-4-7"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_runner() -> MagicMock:
    runner = MagicMock()
    runner.run = AsyncMock(
        return_value=RunResult(
            text='{"mode":"single","cycles":[]}', session_id=None, usage=TokenUsage()
        ),
    )
    return runner


def _make_state(tmp_path: Path) -> tuple[_state.State, Path]:
    st = _state.load_state(tmp_path / "missing.json")
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    (cg / "memories").mkdir(exist_ok=True)
    state_path = cg / "state.json"
    _state.save_state(state_path, st)
    return st, state_path


def _make_cycle(ollama_model: str | None) -> _state.CycleState:
    return _state.CycleState(
        id=1,
        name="c1",
        milestone_number=1,
        milestone_title="c1",
        status="open",
        phase=None,
        issues=[],
        commit_sha=None,
        ollama_model=ollama_model,
    )


def _make_cycle_no_ollama_field() -> _state.CycleState:
    """Create a CycleState that has no ollama_model attribute set."""
    cycle = _state.CycleState(
        id=1,
        name="c1",
        milestone_number=1,
        milestone_title="c1",
        status="open",
        phase=None,
        issues=[],
        commit_sha=None,
    )
    # Simulate legacy state.json: remove the ollama_model attr
    object.__setattr__(cycle, "ollama_model", None)
    return cycle


# ---------------------------------------------------------------------------
# OllamaModelRequiredError
# ---------------------------------------------------------------------------


class TestOllamaModelRequiredError:
    def test_exception_includes_reason_and_fix_action(self) -> None:
        err = OllamaModelRequiredError("no model found", "pass --model <tag>")
        assert "no model found" in str(err)
        assert "pass --model <tag>" in str(err)

    def test_exception_is_runtime_error(self) -> None:
        err = OllamaModelRequiredError("x", "y")
        assert isinstance(err, RuntimeError)

    def test_reason_and_fix_action_accessible_as_attrs(self) -> None:
        err = OllamaModelRequiredError("reason text", "fix text")
        assert err.reason == "reason text"
        assert err.fix_action == "fix text"


# ---------------------------------------------------------------------------
# _resolve_effective_model — raises when on Ollama path, no model resolvable
# ---------------------------------------------------------------------------


class TestResolveEffectiveModelRaisesOnMissingModel:
    def test_raises_when_cycle_has_ollama_model_none_and_state_has_none(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from code_generator.orchestrator import cycle_loop

        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://localhost:11434")
        state, _ = _make_state(tmp_path)
        cycle = _make_cycle(None)
        state.cycles = [cycle]

        with pytest.raises(OllamaModelRequiredError, match="no model tag"):
            cycle_loop._resolve_effective_model(state, cycle)

    def test_raises_when_cycle_is_none_and_state_cycles_have_none_model(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from code_generator.orchestrator import cycle_loop

        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://localhost:11434")
        state, _ = _make_state(tmp_path)
        cycle = _make_cycle(None)
        state.cycles = [cycle]

        with pytest.raises(OllamaModelRequiredError, match="no model tag"):
            cycle_loop._resolve_effective_model(state, None)

    def test_returns_model_when_cycle_has_valid_tag(self, tmp_path: Path) -> None:
        from code_generator.orchestrator import cycle_loop

        state, _ = _make_state(tmp_path)
        cycle = _make_cycle(_OLLAMA_TAG)
        state.cycles = [cycle]

        result = cycle_loop._resolve_effective_model(state, cycle)
        assert result == _OLLAMA_TAG

    def test_returns_none_on_anthropic_max_path(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When no cycle has ollama_model set (None), returns None — Anthropic Max."""
        from code_generator.orchestrator import cycle_loop

        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        state, _ = _make_state(tmp_path)
        # No cycles in state → anthropic max path
        result = cycle_loop._resolve_effective_model(state, None)
        assert result is None

    def test_returns_none_when_cycle_none_and_no_cycles_in_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from code_generator.orchestrator import cycle_loop

        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        state, _ = _make_state(tmp_path)
        state.cycles = []

        result = cycle_loop._resolve_effective_model(state, None)
        assert result is None


# ---------------------------------------------------------------------------
# _run_phases — raises when effective_model starts with "claude-"
# ---------------------------------------------------------------------------


class TestRunPhasesRejectsClaudeModelOnOllamaPath:
    @pytest.mark.asyncio
    async def test_raises_when_effective_model_starts_with_claude_prefix(
        self, tmp_path: Path
    ) -> None:
        from code_generator.orchestrator import cycle_loop

        state, _ = _make_state(tmp_path)
        cycle = _make_cycle(_CLAUDE_TAG)
        state.cycles = [cycle]

        with pytest.raises(OllamaModelRequiredError, match="claude-"):
            await cycle_loop._run_phases(
                state=state,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=_make_runner(),
                log_prefix="",
                start_phase=1,
                effective_model=_CLAUDE_TAG,
            )

    @pytest.mark.asyncio
    async def test_does_not_raise_when_effective_model_is_none(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from code_generator.orchestrator import cycle_loop

        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        state, _ = _make_state(tmp_path)
        cycle = _make_cycle(None)
        state.cycles = [cycle]

        with (
            patch.object(cycle_loop.phase1_plan, "run", new=AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", new=AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", new=AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure,
                "run",
                new=AsyncMock(return_value=MagicMock(new_issues=[])),
            ),
            patch.object(cycle_loop.phase6_test, "run", new=AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", new=AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", AsyncMock()),
            patch.object(cycle_loop, "reset_cycle_summary", lambda *a, **k: None),
            patch.object(cycle_loop, "write_project_plan", lambda *a, **k: None),
            patch.object(cycle_loop, "append_cycle_summaries", lambda *a, **k: None),
            patch.object(cycle_loop, "populate_cycle_start_fields", lambda *a, **k: None),
            patch.object(_state, "get_issues", lambda *a, **k: []),
            patch.object(cycle_loop, "_capture_base_commit", lambda *a, **k: None),
        ):
            await cycle_loop._run_phases(
                state=state,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=_make_runner(),
                log_prefix="",
                start_phase=1,
                effective_model=None,
            )

    @pytest.mark.asyncio
    async def test_does_not_raise_when_effective_model_is_valid_ollama_tag(
        self, tmp_path: Path
    ) -> None:
        from code_generator.orchestrator import cycle_loop

        state, _ = _make_state(tmp_path)
        cycle = _make_cycle(_OLLAMA_TAG)
        state.cycles = [cycle]

        with (
            patch.object(cycle_loop.phase1_plan, "run", new=AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", new=AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", new=AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure,
                "run",
                new=AsyncMock(return_value=MagicMock(new_issues=[])),
            ),
            patch.object(cycle_loop.phase6_test, "run", new=AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", new=AsyncMock()),
            patch.object(cycle_loop.phase8_finalization, "run", AsyncMock()),
            patch.object(cycle_loop, "reset_cycle_summary", lambda *a, **k: None),
            patch.object(cycle_loop, "write_project_plan", lambda *a, **k: None),
            patch.object(cycle_loop, "append_cycle_summaries", lambda *a, **k: None),
            patch.object(cycle_loop, "populate_cycle_start_fields", lambda *a, **k: None),
            patch.object(_state, "get_issues", lambda *a, **k: []),
            patch.object(cycle_loop, "_capture_base_commit", lambda *a, **k: None),
        ):
            await cycle_loop._run_phases(
                state=state,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=_make_runner(),
                log_prefix="",
                start_phase=1,
                effective_model=_OLLAMA_TAG,
            )


# ---------------------------------------------------------------------------
# env.warn_on_claude_model_for_ollama — WARNING for claude-* + localhost
# ---------------------------------------------------------------------------


class TestEnvWarnsOnClaudeModelWithLocalhost:
    def test_warns_when_model_starts_with_claude_prefix(self, caplog) -> None:
        from code_generator import env

        with caplog.at_level(logging.WARNING, logger="code_generator.env"):
            env.warn_on_claude_model_for_ollama("claude-opus-4-7")

        assert any("claude-" in record.message for record in caplog.records), (
            f"expected WARNING with 'claude-', got: {[r.message for r in caplog.records]}"
        )

    def test_does_not_warn_when_model_is_valid_ollama_tag(self, caplog) -> None:
        from code_generator import env

        with caplog.at_level(logging.WARNING, logger="code_generator.env"):
            env.warn_on_claude_model_for_ollama("qwen3-coder:480b:cloud")

        assert not caplog.records, (
            f"expected no WARNING, got: {[r.message for r in caplog.records]}"
        )

    def test_does_not_raise_or_warn_when_model_is_none(self, caplog) -> None:
        from code_generator import env

        with caplog.at_level(logging.WARNING, logger="code_generator.env"):
            env.warn_on_claude_model_for_ollama(None)

        assert not caplog.records


# ---------------------------------------------------------------------------
# Legacy state.json without ollama_model → clear error on --continue
# ---------------------------------------------------------------------------


class TestLegacyStateWithoutOllamaModel:
    @pytest.mark.asyncio
    async def test_resolve_effective_model_raises_for_legacy_cycle_no_model(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from code_generator.orchestrator import cycle_loop

        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://localhost:11434")
        state, _ = _make_state(tmp_path)
        cycle = _make_cycle_no_ollama_field()
        state.cycles = [cycle]

        with pytest.raises(OllamaModelRequiredError, match="--continue"):
            cycle_loop._resolve_effective_model(state, cycle)


# ---------------------------------------------------------------------------
# Anthropic Max path regression guard
# ---------------------------------------------------------------------------


class TestAnthropicMaxPathUnchanged:
    def test_resolve_effective_model_returns_none_when_no_ollama_model_anywhere(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from code_generator.orchestrator import cycle_loop

        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        state, _ = _make_state(tmp_path)
        cycle = _make_cycle(None)
        state.cycles = [cycle]

        result = cycle_loop._resolve_effective_model(state, cycle)
        assert result is None, f"Anthropic Max path broken: {result=}, expected None"

    def test_resolve_effective_model_returns_none_empty_cycles_single_mode(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from code_generator.orchestrator import cycle_loop

        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
        state, _ = _make_state(tmp_path)
        state.cycles = []

        result = cycle_loop._resolve_effective_model(state, None)
        assert result is None
