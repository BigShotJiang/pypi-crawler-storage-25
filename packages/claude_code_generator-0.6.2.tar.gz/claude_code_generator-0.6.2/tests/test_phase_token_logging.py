"""Tests for phase-boundary token logging and state persistence (issue #123).

Covers:
- TokenUsage.__iadd__ accumulation
- log_phase_usage helper format
- Phase 0: _run_phase0_prompt() accumulates TokenUsage across JSON-retry loop
- Phase 0: run() logs phase-boundary line and persists to state.token_usage
- Phase 0: get_raw_cycle_plan() still works after return-type change
- Phase 1: captures RunResult, logs boundary line, persists usage
- Phase 5: captures RunResult, logs boundary line, persists usage
- Phase 6: accumulates usage across retries, logs total, persists
- Phase 7: logs boundary line, persists usage
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.logging_setup import log_phase_usage
from code_generator.orchestrator import (
    phase0_complexity,
    phase1_plan,
    phase5_closure,
    phase6_test,
    phase7_commit,
)
from code_generator.runner.types import RunResult, TokenUsage

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _make_usage(
    input: int = 0,
    output: int = 0,
    cache_read: int = 0,
    cache_write: int = 0,
    num_turns: int = 0,
) -> TokenUsage:
    return TokenUsage(
        input=input,
        output=output,
        cache_read=cache_read,
        cache_write=cache_write,
        num_turns=num_turns,
    )


def _make_result(text: str = "", usage: TokenUsage | None = None) -> RunResult:
    return RunResult(text=text, session_id=None, usage=usage or TokenUsage())


def _make_state(tmp_path: Path) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# TokenUsage.__iadd__
# ---------------------------------------------------------------------------


class TestTokenUsageIadd:
    def test_accumulates_all_four_fields(self) -> None:
        a = _make_usage(input=10, output=5, cache_read=20, cache_write=15)
        b = _make_usage(input=3, output=2, cache_read=7, cache_write=4)
        a += b
        assert a.input == 13
        assert a.output == 7
        assert a.cache_read == 27
        assert a.cache_write == 19

    def test_accumulate_zero_leaves_unchanged(self) -> None:
        a = _make_usage(input=100, output=50, cache_read=200, cache_write=150)
        a += TokenUsage()
        assert a.input == 100
        assert a.output == 50
        assert a.cache_read == 200
        assert a.cache_write == 150

    def test_returns_self(self) -> None:
        a = _make_usage(input=1)
        original_id = id(a)
        a += _make_usage(input=1)
        assert id(a) == original_id

    def test_accumulates_num_turns(self) -> None:
        """`a += b` where a.num_turns=3, b.num_turns=5 → a.num_turns=8."""
        a = _make_usage(num_turns=3)
        b = _make_usage(num_turns=5)
        a += b
        assert a.num_turns == 8

    def test_accumulates_num_turns_with_other_fields(self) -> None:
        """num_turns accumulates alongside the existing four token counters."""
        a = _make_usage(input=10, output=5, cache_read=20, cache_write=15, num_turns=2)
        b = _make_usage(input=3, output=2, cache_read=7, cache_write=4, num_turns=9)
        a += b
        assert a.input == 13
        assert a.output == 7
        assert a.cache_read == 27
        assert a.cache_write == 19
        assert a.num_turns == 11


# ---------------------------------------------------------------------------
# log_phase_usage helper
# ---------------------------------------------------------------------------


class TestLogPhaseUsage:
    def test_emits_correct_format(self) -> None:
        records: list[logging.LogRecord] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                records.append(record)

        logger = logging.getLogger("test.log_phase_usage")
        logger.setLevel(logging.DEBUG)
        handler = _Capture()
        logger.addHandler(handler)
        try:
            usage = _make_usage(input=100, output=50, cache_read=200, cache_write=150)
            log_phase_usage(logger, 1, usage)
        finally:
            logger.removeHandler(handler)

        assert len(records) == 1
        msg = records[0].getMessage()
        assert "Phase 1 complete:" in msg
        assert "in=100" in msg
        assert "cache_read=200" in msg
        assert "cache_write=150" in msg
        assert "out=50" in msg
        assert "total=500" in msg  # 100+200+150+50

    def test_total_is_sum_of_all_four(self) -> None:
        records: list[logging.LogRecord] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                records.append(record)

        logger = logging.getLogger("test.log_total")
        logger.setLevel(logging.DEBUG)
        handler = _Capture()
        logger.addHandler(handler)
        try:
            usage = _make_usage(input=1, output=2, cache_read=3, cache_write=4)
            log_phase_usage(logger, "6", usage)
        finally:
            logger.removeHandler(handler)

        msg = records[0].getMessage()
        assert "total=10" in msg  # 1+2+3+4

    def test_accepts_string_phase_identifier(self) -> None:
        records: list[logging.LogRecord] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                records.append(record)

        logger = logging.getLogger("test.log_string_phase")
        logger.setLevel(logging.DEBUG)
        handler = _Capture()
        logger.addHandler(handler)
        try:
            log_phase_usage(logger, "0", _make_usage(input=5, output=3))
        finally:
            logger.removeHandler(handler)

        assert "Phase 0 complete:" in records[0].getMessage()


# ---------------------------------------------------------------------------
# Phase 0 — _run_phase0_prompt returns tuple
# ---------------------------------------------------------------------------


class TestPhase0RunPhasePromptReturnsUsage:
    @pytest.mark.asyncio
    async def test_returns_tuple_with_usage_on_success(self, tmp_path: Path) -> None:
        """`_run_phase0_prompt` returns (data_dict, TokenUsage) on first success."""
        payload = json.dumps({"mode": "single", "cycles": []})
        usage = _make_usage(input=100, output=50, cache_read=200, cache_write=150)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_result(payload, usage)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            data, returned_usage, _, _ = await phase0_complexity._run_phase0_prompt(
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert data is not None
        assert data["mode"] == "single"
        assert returned_usage.input == 100
        assert returned_usage.output == 50
        assert returned_usage.cache_read == 200
        assert returned_usage.cache_write == 150

    @pytest.mark.asyncio
    async def test_accumulates_usage_across_json_retry_loop(self, tmp_path: Path) -> None:
        """When first call fails JSON parse and second succeeds, TokenUsage is summed."""
        payload = json.dumps({"mode": "single", "cycles": []})
        call_count = 0
        first_usage = _make_usage(input=100, output=50)
        second_usage = _make_usage(input=200, output=80)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return _make_result("not json", first_usage)
            return _make_result(payload, second_usage)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            data, usage, _, _ = await phase0_complexity._run_phase0_prompt(
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert data is not None
        assert usage.input == 300  # 100 + 200
        assert usage.output == 130  # 50 + 80

    @pytest.mark.asyncio
    async def test_returns_none_data_with_accumulated_usage_on_all_retries_fail(
        self, tmp_path: Path
    ) -> None:
        """When all retries fail, (None, accumulated_usage) is returned."""
        call_count = 0

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            call_count += 1
            return _make_result("not json", _make_usage(input=50 * call_count))

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            data, usage, _, _ = await phase0_complexity._run_phase0_prompt(
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert data is None
        # 3 calls total (_MAX_JSON_RETRIES + 1 = 3): 50 + 100 + 150 = 300
        assert usage.input == 300


# ---------------------------------------------------------------------------
# Phase 0 — run() logs boundary line and persists usage
# ---------------------------------------------------------------------------


class TestPhase0RunLogsAndPersists:
    @pytest.mark.asyncio
    async def test_logs_phase_boundary_line_with_token_values(self, tmp_path: Path) -> None:
        payload = json.dumps({"mode": "single", "cycles": []})
        usage = _make_usage(input=100, output=50, cache_read=200, cache_write=150)
        records: list[logging.LogRecord] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                records.append(record)

        logger = logging.getLogger("test.phase0.run.log")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(_Capture())

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_result(payload, usage)

        state = _make_state(tmp_path)
        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase0_complexity.run(state, tmp_path, runner_module=MagicMock(), logger=logger)

        boundary_msgs = [r.getMessage() for r in records if "Phase 0 complete:" in r.getMessage()]
        assert boundary_msgs, "No 'Phase 0 complete:' log line found"
        msg = boundary_msgs[0]
        assert "in=100" in msg
        assert "out=50" in msg
        assert "cache_read=200" in msg
        assert "cache_write=150" in msg
        assert "total=500" in msg

    @pytest.mark.asyncio
    async def test_persists_usage_to_state_token_usage(self, tmp_path: Path) -> None:
        payload = json.dumps({"mode": "single", "cycles": []})
        usage = _make_usage(input=111, output=22, cache_read=33, cache_write=44)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_result(payload, usage)

        state = _make_state(tmp_path)
        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert "phase0" in result.token_usage
        assert result.token_usage["phase0"].input == 111
        assert result.token_usage["phase0"].output == 22

    @pytest.mark.asyncio
    async def test_state_json_contains_phase0_token_usage_after_run(self, tmp_path: Path) -> None:
        """Usage is persisted to state.json, not just in-memory."""
        payload = json.dumps({"mode": "single", "cycles": []})
        usage = _make_usage(input=77, output=33)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_result(payload, usage)

        state = _make_state(tmp_path)
        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase0_complexity.run(
                state, tmp_path, runner_module=MagicMock(), logger=logging.getLogger("test")
            )

        saved = _state.load_state(tmp_path / ".code-generator" / "state.json")
        assert "phase0" in saved.token_usage
        assert saved.token_usage["phase0"].input == 77


# ---------------------------------------------------------------------------
# Phase 0 — get_raw_cycle_plan() handles new return type
# ---------------------------------------------------------------------------


class TestPhase0GetRawCyclePlanHandlesNewReturnType:
    @pytest.mark.asyncio
    async def test_returns_cycle_list_without_error(self, tmp_path: Path) -> None:
        """get_raw_cycle_plan() correctly unpacks the tuple from _run_phase0_prompt."""
        raw = [{"id": 1, "name": "C1", "scope": "s1", "milestone_title": "C1", "depends_on": []}]
        payload = json.dumps({"mode": "multi-cycle", "cycles": raw})
        usage = _make_usage(input=50)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_result(payload, usage)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.get_raw_cycle_plan(
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert result is not None
        assert len(result) == 1
        assert result[0]["name"] == "C1"

    @pytest.mark.asyncio
    async def test_returns_none_when_json_fails(self, tmp_path: Path) -> None:
        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_result("not json", _make_usage())

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            result = await phase0_complexity.get_raw_cycle_plan(
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert result is None


# ---------------------------------------------------------------------------
# Phase 1 — logs boundary line and persists usage
# ---------------------------------------------------------------------------


class TestPhase1TokenLogging:
    @pytest.mark.asyncio
    async def test_logs_phase_boundary_line_with_token_values(self, tmp_path: Path) -> None:
        usage = _make_usage(input=500, output=200, cache_read=1000, cache_write=300)
        records: list[logging.LogRecord] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                records.append(record)

        logger = logging.getLogger("test.phase1.log")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(_Capture())

        state = _make_state(tmp_path)

        with (
            patch.object(
                phase1_plan.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_result("ok", usage)),
            ),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(
                phase1_plan.gh,
                "list_issues",
                return_value=[{"number": 1, "title": "t", "state": "open", "labels": []}],
            ),
        ):
            await phase1_plan.run(state, None, tmp_path, runner_module=MagicMock(), logger=logger)

        boundary = [r.getMessage() for r in records if "Phase 1 complete:" in r.getMessage()]
        assert boundary, "No 'Phase 1 complete:' log line emitted"
        msg = boundary[0]
        assert "in=500" in msg
        assert "cache_read=1000" in msg
        assert "cache_write=300" in msg
        assert "out=200" in msg
        assert "total=2000" in msg

    @pytest.mark.asyncio
    async def test_persists_usage_to_state_token_usage_single_mode(self, tmp_path: Path) -> None:
        usage = _make_usage(input=123, output=45)
        state = _make_state(tmp_path)

        with (
            patch.object(
                phase1_plan.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_result("ok", usage)),
            ),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(
                phase1_plan.gh,
                "list_issues",
                return_value=[{"number": 1, "title": "t", "state": "open", "labels": []}],
            ),
        ):
            await phase1_plan.run(
                state, None, tmp_path, runner_module=MagicMock(), logger=logging.getLogger("test")
            )

        assert "phase1" in state.token_usage
        assert state.token_usage["phase1"].input == 123

    @pytest.mark.asyncio
    async def test_persists_usage_to_cycle_token_usage_multi_mode(self, tmp_path: Path) -> None:
        usage = _make_usage(input=99, output=11)
        state = _make_state(tmp_path)
        cycle = _state.CycleState(
            id=1,
            name="C1",
            milestone_number=None,
            milestone_title="C1",
            status="open",
            phase=1,
            issues=[],
            commit_sha=None,
        )

        with (
            patch.object(
                phase1_plan.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_result("ok", usage)),
            ),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "create_milestone", return_value=42),
            patch.object(
                phase1_plan.gh,
                "list_issues",
                return_value=[{"number": 2, "title": "t", "state": "open", "labels": []}],
            ),
        ):
            await phase1_plan.run(
                state, cycle, tmp_path, runner_module=MagicMock(), logger=logging.getLogger("test")
            )

        assert "phase1" in cycle.token_usage
        assert cycle.token_usage["phase1"].input == 99


# ---------------------------------------------------------------------------
# Phase 5 — logs boundary line and persists usage
# ---------------------------------------------------------------------------


class TestPhase5TokenLogging:
    @pytest.mark.asyncio
    async def test_logs_phase_boundary_line_with_token_values(self, tmp_path: Path) -> None:
        usage = _make_usage(input=400, output=150, cache_read=800, cache_write=200)
        records: list[logging.LogRecord] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                records.append(record)

        logger = logging.getLogger("test.phase5.log")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(_Capture())

        state = _make_state(tmp_path)

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_result("ok", usage)),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
        ):
            await phase5_closure.run(
                state, None, tmp_path, runner_module=MagicMock(), logger=logger
            )

        boundary = [r.getMessage() for r in records if "Phase 5 complete:" in r.getMessage()]
        assert boundary, "No 'Phase 5 complete:' log line emitted"
        msg = boundary[0]
        assert "in=400" in msg
        assert "cache_read=800" in msg
        assert "cache_write=200" in msg
        assert "out=150" in msg
        assert "total=1550" in msg

    @pytest.mark.asyncio
    async def test_persists_usage_to_state_token_usage_single_mode(self, tmp_path: Path) -> None:
        usage = _make_usage(input=77, output=33)
        state = _make_state(tmp_path)

        with (
            patch.object(
                phase5_closure.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_result("ok", usage)),
            ),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
        ):
            await phase5_closure.run(
                state, None, tmp_path, runner_module=MagicMock(), logger=logging.getLogger("test")
            )

        assert "phase5" in state.token_usage
        assert state.token_usage["phase5"].input == 77


# ---------------------------------------------------------------------------
# Phase 6 — accumulates usage, logs, persists
# ---------------------------------------------------------------------------


class TestPhase6TokenLogging:
    @pytest.mark.asyncio
    async def test_logs_phase_boundary_line_on_first_pass_success(self, tmp_path: Path) -> None:
        usage = _make_usage(input=300, output=100)
        records: list[logging.LogRecord] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                records.append(record)

        logger = logging.getLogger("test.phase6.log")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(_Capture())

        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_result("all tests passed", usage)

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(state, None, tmp_path, runner_module=MagicMock(), logger=logger)

        boundary = [r.getMessage() for r in records if "Phase 6 complete:" in r.getMessage()]
        assert boundary, "No 'Phase 6 complete:' log line emitted"
        assert "in=300" in boundary[0]
        assert "out=100" in boundary[0]

    @pytest.mark.asyncio
    async def test_accumulates_usage_across_2_failed_plus_1_success(self, tmp_path: Path) -> None:
        """Phase 6 with 2 failed attempts + 1 success → accumulated usage is sum of all 3."""
        call_count = 0
        usages = [
            _make_usage(input=100, output=40),
            _make_usage(input=150, output=60),
            _make_usage(input=200, output=80),
        ]

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            u = usages[call_count]
            call_count += 1
            if call_count < 3:
                return _make_result("TESTS FAILED", u)
            return _make_result("all ok", u)

        state = _make_state(tmp_path)
        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                max_retries=3,
            )

        assert "phase6" in state.token_usage
        # 100 + 150 + 200 = 450
        assert state.token_usage["phase6"].input == 450
        # 40 + 60 + 80 = 180
        assert state.token_usage["phase6"].output == 180

    @pytest.mark.asyncio
    async def test_logs_total_accumulated_usage_after_retries(self, tmp_path: Path) -> None:
        records: list[logging.LogRecord] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                records.append(record)

        logger = logging.getLogger("test.phase6.accumulated")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(_Capture())

        call_count = 0
        usages = [
            _make_usage(input=100),
            _make_usage(input=200),
        ]

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_count
            u = usages[call_count]
            call_count += 1
            if call_count == 1:
                return _make_result("TESTS FAILED", u)
            return _make_result("ok", u)

        state = _make_state(tmp_path)
        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(state, None, tmp_path, runner_module=MagicMock(), logger=logger)

        boundary = [r.getMessage() for r in records if "Phase 6 complete:" in r.getMessage()]
        assert boundary
        # total accumulated input = 100 + 200 = 300
        assert "in=300" in boundary[0]

    @pytest.mark.asyncio
    async def test_persists_usage_to_cycle_token_usage_in_multi_mode(self, tmp_path: Path) -> None:
        usage = _make_usage(input=55, output=22)
        state = _make_state(tmp_path)
        cycle = _state.CycleState(
            id=1,
            name="C1",
            milestone_number=1,
            milestone_title="C1",
            status="open",
            phase=6,
            issues=[],
            commit_sha=None,
        )

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_result("ok", usage)

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert "phase6" in cycle.token_usage
        assert cycle.token_usage["phase6"].input == 55


# ---------------------------------------------------------------------------
# Phase 7 — logs boundary line and persists usage
# ---------------------------------------------------------------------------


class TestPhase7TokenLogging:
    @pytest.mark.asyncio
    async def test_logs_phase_boundary_line_with_token_values(self, tmp_path: Path) -> None:
        usage = _make_usage(input=250, output=80, cache_read=500, cache_write=100)
        records: list[logging.LogRecord] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                records.append(record)

        logger = logging.getLogger("test.phase7.log")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(_Capture())

        state = _make_state(tmp_path)

        with (
            patch.object(
                phase7_commit.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_result("chore: done", usage)),
            ),
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch("code_generator.orchestrator.phase7_commit.git_has_staged", return_value=True),
            patch("code_generator.orchestrator.phase7_commit.git_diff_cached", return_value=""),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
        ):
            await phase7_commit.run(state, None, tmp_path, runner_module=MagicMock(), logger=logger)

        boundary = [r.getMessage() for r in records if "Phase 7 complete:" in r.getMessage()]
        assert boundary, "No 'Phase 7 complete:' log line emitted"
        msg = boundary[0]
        assert "in=250" in msg
        assert "cache_read=500" in msg
        assert "cache_write=100" in msg
        assert "out=80" in msg
        assert "total=930" in msg

    @pytest.mark.asyncio
    async def test_persists_usage_to_state_token_usage(self, tmp_path: Path) -> None:
        usage = _make_usage(input=88, output=44)
        state = _make_state(tmp_path)

        with (
            patch.object(
                phase7_commit.rate_limit,
                "main_loop",
                new=AsyncMock(return_value=_make_result("chore: done", usage)),
            ),
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch("code_generator.orchestrator.phase7_commit.git_has_staged", return_value=True),
            patch("code_generator.orchestrator.phase7_commit.git_diff_cached", return_value=""),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
        ):
            await phase7_commit.run(
                state, None, tmp_path, runner_module=MagicMock(), logger=logging.getLogger("test")
            )

        assert "phase7" in state.token_usage
        assert state.token_usage["phase7"].input == 88
        assert state.token_usage["phase7"].output == 44
