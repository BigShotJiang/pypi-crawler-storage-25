"""Tests for code_generator.orchestrator.tier_t3 — Issue #284.

T3 browser E2E tier: drive the running app via Playwright MCP, run
scenarios, capture screenshot + console on failure. MCP session is
injected via a factory seam — no real Playwright in the test suite.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from code_generator.orchestrator import tier_t3
from code_generator.orchestrator.phase6_5_verify import TierResult
from code_generator.orchestrator.tier_t3 import (
    PlaywrightMcpSession,
    Scenario,
    ScenarioFailure,
    run_t3_browser,
)

if TYPE_CHECKING:
    import pytest


# ---------------------------------------------------------------------------
# Fakes
# ---------------------------------------------------------------------------


class _FakeSession(PlaywrightMcpSession):
    """In-memory Playwright MCP session for tests."""

    def __init__(
        self,
        *,
        failures: dict[str, ScenarioFailure] | None = None,
        console: list[str] | None = None,
        env_seen: dict[str, str] | None = None,
    ) -> None:
        self._failures = failures or {}
        self._console = console or []
        self.closed = False
        self.env_seen = env_seen if env_seen is not None else {}
        self.scenarios_run: list[str] = []
        self.screenshots: list[str] = []
        self.base_url = ""

    def __enter__(self) -> _FakeSession:
        return self

    def __exit__(self, *args: object) -> None:
        self.closed = True

    def run_scenario(self, scenario: Scenario) -> ScenarioFailure | None:
        self.scenarios_run.append(scenario.name)
        return self._failures.get(scenario.name)

    def screenshot(self, path: str) -> None:
        self.screenshots.append(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_bytes(b"fake-png")

    def console_messages(self) -> list[str]:
        return list(self._console)


def _factory(session: _FakeSession):  # type: ignore[no-untyped-def]
    def make(*, env, base_url):  # type: ignore[no-untyped-def]
        session.env_seen.update(env)
        session.base_url = base_url
        return session

    return make


def _scenario(name: str = "smoke") -> Scenario:
    return Scenario(name=name, steps=("goto /",))


# ---------------------------------------------------------------------------
# Skip behavior
# ---------------------------------------------------------------------------


def test_when_no_scenarios_then_t3_skipped(tmp_path: Path) -> None:
    result = run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[],
        mcp_factory=_factory(_FakeSession()),
    )

    assert result.tier_id == "T3"
    assert result.skipped is True
    assert result.passed is False
    assert result.skip_reason


def test_when_playwright_binary_absent_then_t3_skipped(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(tier_t3, "_playwright_on_path", lambda: False)

    result = run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario()],
    )

    assert result.skipped is True
    assert result.skip_reason
    assert "playwright" in result.skip_reason.lower()


# ---------------------------------------------------------------------------
# Pass / fail paths
# ---------------------------------------------------------------------------


def test_when_all_scenarios_pass_then_t3_passes(tmp_path: Path) -> None:
    session = _FakeSession()

    result = run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario("a"), _scenario("b")],
        mcp_factory=_factory(session),
    )

    assert result.passed is True
    assert result.skipped is False
    assert session.scenarios_run == ["a", "b"]
    assert session.closed is True


def test_when_scenario_fails_then_screenshot_and_console_captured(
    tmp_path: Path,
) -> None:
    session = _FakeSession(
        failures={"checkout": ScenarioFailure(detail="checkout button missing")},
        console=["TypeError: x", "404 /api/cart"],
    )

    result = run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario("smoke"), _scenario("checkout")],
        mcp_factory=_factory(session),
    )

    assert result.passed is False
    assert result.skipped is False
    assert result.failing_detail
    assert "checkout" in result.failing_detail
    assert result.screenshot_path
    assert Path(result.screenshot_path).exists()
    assert result.browser_console == ["TypeError: x", "404 /api/cart"]
    assert session.closed is True


def test_when_t3_fails_then_session_closed_via_context_manager(tmp_path: Path) -> None:
    session = _FakeSession(failures={"a": ScenarioFailure(detail="boom")})

    run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario("a")],
        mcp_factory=_factory(session),
    )

    assert session.closed is True


# ---------------------------------------------------------------------------
# Env propagation — Anthropic credentials must not reach MCP
# ---------------------------------------------------------------------------


def test_when_t3_runs_then_anthropic_vars_absent_from_mcp_env(tmp_path: Path) -> None:
    session = _FakeSession()

    run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[_scenario()],
        mcp_factory=_factory(session),
    )

    assert "ANTHROPIC_API_KEY" not in session.env_seen
    assert "ANTHROPIC_AUTH_TOKEN" not in session.env_seen


# ---------------------------------------------------------------------------
# Wildcard registration
# ---------------------------------------------------------------------------


def test_playwright_wildcard_in_shared_client_allowed_tools() -> None:
    from code_generator.orchestrator._client_lifecycle import _SHARED_CLIENT_ALLOWED_TOOLS

    assert "mcp__playwright__*" in _SHARED_CLIENT_ALLOWED_TOOLS


# ---------------------------------------------------------------------------
# __all__ export
# ---------------------------------------------------------------------------


def test_run_t3_browser_in_phase6_5_verify_all() -> None:
    from code_generator.orchestrator import phase6_5_verify

    assert "run_t3_browser" in phase6_5_verify.__all__
    assert phase6_5_verify.run_t3_browser is run_t3_browser


# ---------------------------------------------------------------------------
# build_playwright_server_config probe
# ---------------------------------------------------------------------------


def test_when_playwright_binary_missing_then_build_config_returns_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from code_generator.runner import mcp

    monkeypatch.setattr(mcp.shutil, "which", lambda _bin: None)

    assert mcp.build_playwright_server_config() is None


def test_when_playwright_binary_present_then_build_config_returns_dict(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from code_generator.runner import mcp

    monkeypatch.setattr(mcp.shutil, "which", lambda _bin: "/usr/local/bin/playwright-mcp")

    config = mcp.build_playwright_server_config()

    assert config is not None
    assert config["type"] == "stdio"
    assert config["command"] == "/usr/local/bin/playwright-mcp"


# ---------------------------------------------------------------------------
# TierResult type assertions
# ---------------------------------------------------------------------------


def test_t3_returns_tier_result_instance(tmp_path: Path) -> None:
    result = run_t3_browser(
        tmp_path,
        env={"PATH": "/usr/bin"},
        base_url="http://127.0.0.1:8000",
        scenarios=[],
        mcp_factory=_factory(_FakeSession()),
    )
    assert isinstance(result, TierResult)
