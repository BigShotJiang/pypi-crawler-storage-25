"""Tests for runner/message_parsing — Issue #65.

All message types are duck-typed fakes. No real SDK calls are made.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import pytest

from code_generator.runner.message_parsing import (
    extract_text,
    extract_usage,
    handle_rate_limit_event,
    is_assistant_message,
    is_rate_limit_event,
    is_result_message,
)
from code_generator.runner.types import OverageAbort, RateLimitHit, TokenUsage

# ---------------------------------------------------------------------------
# Fake SDK message types (duck-typed, no SDK imports needed)
# ---------------------------------------------------------------------------


class FakeTextBlock:
    def __init__(self, text: str) -> None:
        self.text = text


class FakeNonTextBlock:
    def __init__(self) -> None:
        self.type = "tool_use"
        self.id = "tu-1"


class FakeAssistantMessage:
    def __init__(self, text: str) -> None:
        self.content = [FakeTextBlock(text)]
        self.model = "claude-sonnet-4-6"
        self.session_id = "sess-abc"


class FakeResultMessage:
    def __init__(self, session_id: str = "sess-abc") -> None:
        self.session_id = session_id
        self.usage = {"input_tokens": 10, "output_tokens": 20}
        self.is_error = False


class FakeRateLimitInfo:
    def __init__(
        self,
        status: str,
        resets_at: int | None = None,
        rate_limit_type: str | None = None,
        overage_status: str | None = None,
    ) -> None:
        self.status = status
        self.resets_at = resets_at
        self.rate_limit_type = rate_limit_type
        self.overage_status = overage_status


class FakeRateLimitEvent:
    def __init__(self, info: FakeRateLimitInfo, session_id: str = "sess-rl") -> None:
        self.rate_limit_info = info
        self.session_id = session_id


# ---------------------------------------------------------------------------
# Tests — extract_text
# ---------------------------------------------------------------------------


def test_extract_text_with_empty_content_returns_empty_string() -> None:
    """extract_text returns '' when AssistantMessage.content is empty."""

    class Msg:
        content: list = []

    assert extract_text(Msg()) == ""


def test_extract_text_skips_non_text_blocks() -> None:
    """extract_text ignores blocks without a .text attribute."""

    class Msg:
        content = [FakeNonTextBlock(), FakeTextBlock("hello")]

    assert extract_text(Msg()) == "hello"


def test_extract_text_concatenates_multiple_text_blocks() -> None:
    """extract_text joins all text blocks in order."""

    class Msg:
        content = [FakeTextBlock("foo"), FakeTextBlock(" bar")]

    assert extract_text(Msg()) == "foo bar"


def test_extract_text_with_no_content_attribute_returns_empty_string() -> None:
    """extract_text returns '' when msg has no content attribute."""

    class Msg:
        pass

    assert extract_text(Msg()) == ""


# ---------------------------------------------------------------------------
# Tests — extract_usage
# ---------------------------------------------------------------------------


def test_extract_usage_with_dict_returns_token_usage() -> None:
    """extract_usage returns a TokenUsage for a plain dict with input/output tokens."""

    class Msg:
        usage = {"input_tokens": 42, "output_tokens": 7}

    result = extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 42
    assert result.output == 7
    assert result.cache_read == 0
    assert result.cache_write == 0


def test_extract_usage_with_object_returns_token_usage() -> None:
    """extract_usage returns a TokenUsage for an object with attributes."""

    class UsageObj:
        input_tokens = 100
        output_tokens = 200

    class Msg:
        usage = UsageObj()

    result = extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 100
    assert result.output == 200
    assert result.cache_read == 0
    assert result.cache_write == 0


def test_extract_usage_with_none_returns_zero_token_usage() -> None:
    """extract_usage returns zero-initialized TokenUsage when usage is absent."""

    class Msg:
        usage = None

    result = extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 0
    assert result.output == 0
    assert result.cache_read == 0
    assert result.cache_write == 0


def test_extract_usage_with_missing_usage_attribute_returns_zero_token_usage() -> None:
    """extract_usage returns zero-initialized TokenUsage when msg has no usage attribute."""

    class Msg:
        pass

    result = extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 0
    assert result.output == 0
    assert result.cache_read == 0
    assert result.cache_write == 0


def test_extract_usage_dict_with_all_four_cache_fields() -> None:
    """extract_usage reads all four cache fields from a dict-shaped usage payload."""

    class Msg:
        usage = {
            "input_tokens": 10,
            "output_tokens": 20,
            "cache_creation_input_tokens": 300,
            "cache_read_input_tokens": 400,
        }

    result = extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 10
    assert result.output == 20
    assert result.cache_write == 300
    assert result.cache_read == 400


def test_extract_usage_object_with_all_four_cache_fields() -> None:
    """extract_usage reads all four cache fields from an object-shaped usage payload."""

    class UsageObj:
        input_tokens = 5
        output_tokens = 15
        cache_creation_input_tokens = 500
        cache_read_input_tokens = 600

    class Msg:
        usage = UsageObj()

    result = extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 5
    assert result.output == 15
    assert result.cache_write == 500
    assert result.cache_read == 600


def test_extract_usage_partial_fields_only_input_tokens() -> None:
    """extract_usage defaults missing fields to 0 when only input_tokens is present."""

    class Msg:
        usage = {"input_tokens": 77}

    result = extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 77
    assert result.output == 0
    assert result.cache_read == 0
    assert result.cache_write == 0


def test_extract_usage_cache_fields_only_no_input_output() -> None:
    """extract_usage handles usage with only cache fields and no input/output."""

    class Msg:
        usage = {
            "cache_creation_input_tokens": 999,
            "cache_read_input_tokens": 888,
        }

    result = extract_usage(Msg())
    assert isinstance(result, TokenUsage)
    assert result.input == 0
    assert result.output == 0
    assert result.cache_write == 999
    assert result.cache_read == 888


# ---------------------------------------------------------------------------
# Tests — extract_usage.num_turns (issue #205)
# ---------------------------------------------------------------------------
# ``num_turns`` lives on the ResultMessage itself (alongside ``usage``),
# not inside the nested ``.usage`` payload.  extract_usage is the single
# extraction point for every usage-related field including num_turns.


def test_extract_usage_reads_num_turns_from_message() -> None:
    """extract_usage copies msg.num_turns into the returned TokenUsage."""

    class Msg:
        usage = {"input_tokens": 1, "output_tokens": 2}
        num_turns = 7

    result = extract_usage(Msg())
    assert result.num_turns == 7


def test_extract_usage_missing_num_turns_defaults_to_zero() -> None:
    """When msg has no num_turns attribute, TokenUsage.num_turns == 0."""

    class Msg:
        usage = {"input_tokens": 10, "output_tokens": 20}

    result = extract_usage(Msg())
    assert result.num_turns == 0


def test_extract_usage_num_turns_none_defaults_to_zero() -> None:
    """Defensive: msg.num_turns is None → TokenUsage.num_turns == 0."""

    class Msg:
        usage = {"input_tokens": 1, "output_tokens": 2}
        num_turns = None

    result = extract_usage(Msg())
    assert result.num_turns == 0


def test_extract_usage_num_turns_with_absent_usage() -> None:
    """num_turns is read even when msg.usage is None (zero tokens, N turns)."""

    class Msg:
        usage = None
        num_turns = 4

    result = extract_usage(Msg())
    assert result.num_turns == 4
    assert result.input == 0
    assert result.output == 0


# ---------------------------------------------------------------------------
# Tests — is_rate_limit_event
# ---------------------------------------------------------------------------


def test_is_rate_limit_event_true_for_rate_limit_event() -> None:
    """is_rate_limit_event returns True for a message with rate_limit_info."""
    info = FakeRateLimitInfo(status="allowed")
    assert is_rate_limit_event(FakeRateLimitEvent(info)) is True


def test_is_rate_limit_event_false_for_assistant_message() -> None:
    """is_rate_limit_event returns False for an AssistantMessage."""
    assert is_rate_limit_event(FakeAssistantMessage("hi")) is False


def test_is_rate_limit_event_false_for_result_message() -> None:
    """is_rate_limit_event returns False for a ResultMessage."""
    assert is_rate_limit_event(FakeResultMessage()) is False


# ---------------------------------------------------------------------------
# Tests — is_assistant_message
# ---------------------------------------------------------------------------


def test_is_assistant_message_true_for_assistant_message() -> None:
    """is_assistant_message returns True for a message with content and model."""
    assert is_assistant_message(FakeAssistantMessage("hi")) is True


def test_is_assistant_message_false_for_result_message() -> None:
    """is_assistant_message returns False for a ResultMessage."""
    assert is_assistant_message(FakeResultMessage()) is False


def test_is_assistant_message_false_for_rate_limit_event() -> None:
    """is_assistant_message returns False for a RateLimitEvent."""
    info = FakeRateLimitInfo(status="allowed")
    assert is_assistant_message(FakeRateLimitEvent(info)) is False


# ---------------------------------------------------------------------------
# Tests — is_result_message
# ---------------------------------------------------------------------------


def test_is_result_message_true_for_result_message() -> None:
    """is_result_message returns True for a message with session_id and is_error."""
    assert is_result_message(FakeResultMessage()) is True


def test_is_result_message_false_for_assistant_message() -> None:
    """is_result_message returns False for an AssistantMessage."""
    assert is_result_message(FakeAssistantMessage("hi")) is False


def test_is_result_message_false_for_rate_limit_event() -> None:
    """is_result_message returns False for a RateLimitEvent."""
    info = FakeRateLimitInfo(status="allowed")
    assert is_result_message(FakeRateLimitEvent(info)) is False


# ---------------------------------------------------------------------------
# Tests — handle_rate_limit_event
# ---------------------------------------------------------------------------


def test_handle_rate_limit_event_with_no_info_logs_warning(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """When rate_limit_info is absent, just log a warning — do not raise."""
    logger = logging.getLogger("test.no_info")
    state_path = tmp_path / ".code-generator" / "state.json"

    class MsgNoInfo:
        rate_limit_info = None

    with caplog.at_level(logging.WARNING):
        handle_rate_limit_event(MsgNoInfo(), logger, state_path)

    assert any("no rate_limit_info" in r.message for r in caplog.records)


def test_handle_rate_limit_event_overage_allowed_raises_overage_abort(
    tmp_path: Path,
) -> None:
    """Overage status 'allowed' raises OverageAbort immediately."""
    logger = logging.getLogger("test.overage_allowed")
    state_path = tmp_path / ".code-generator" / "state.json"

    info = FakeRateLimitInfo(status="allowed", overage_status="allowed")
    event = FakeRateLimitEvent(info)

    with pytest.raises(OverageAbort):
        handle_rate_limit_event(event, logger, state_path)


def test_handle_rate_limit_event_overage_allowed_warning_raises_overage_abort(
    tmp_path: Path,
) -> None:
    """Overage status 'allowed_warning' raises OverageAbort immediately."""
    logger = logging.getLogger("test.overage_warning")
    state_path = tmp_path / ".code-generator" / "state.json"

    info = FakeRateLimitInfo(status="allowed_warning", overage_status="allowed_warning")
    event = FakeRateLimitEvent(info)

    with pytest.raises(OverageAbort):
        handle_rate_limit_event(event, logger, state_path)


def test_handle_rate_limit_event_rejected_with_resets_at_raises_rate_limit_hit(
    tmp_path: Path,
) -> None:
    """Rejected with resets_at persists state and raises RateLimitHit with +60s buffer."""
    logger = logging.getLogger("test.rejected")
    state_path = tmp_path / ".code-generator" / "state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)

    info = FakeRateLimitInfo(
        status="rejected",
        resets_at=9_999_999_999,
        rate_limit_type="five_hour",
        overage_status=None,
    )
    event = FakeRateLimitEvent(info, session_id="sess-rl")

    with pytest.raises(RateLimitHit) as exc_info:
        handle_rate_limit_event(event, logger, state_path)

    # Non-negotiable #5: +60s safety buffer must be applied to resets_at.
    assert exc_info.value.resets_at == 9_999_999_999 + 60
    assert exc_info.value.rate_limit_type == "five_hour"

    raw = json.loads(state_path.read_text())
    assert raw["paused_until"] == 9_999_999_999 + 60


def test_handle_rate_limit_event_rejected_persists_60s_buffer_in_state(
    tmp_path: Path,
) -> None:
    """The +60s buffer is reflected in persisted paused_until, not just the exception."""
    logger = logging.getLogger("test.rejected.buffer")
    state_path = tmp_path / ".code-generator" / "state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)

    raw_resets_at = 1_000_000_000
    info = FakeRateLimitInfo(
        status="rejected",
        resets_at=raw_resets_at,
        rate_limit_type="five_hour",
        overage_status=None,
    )
    event = FakeRateLimitEvent(info, session_id="sess-buf")

    with pytest.raises(RateLimitHit) as exc_info:
        handle_rate_limit_event(event, logger, state_path)

    buffered = raw_resets_at + 60
    assert exc_info.value.resets_at == buffered, (
        f"RateLimitHit.resets_at must be raw+60 ({buffered}), got {exc_info.value.resets_at}"
    )
    raw = json.loads(state_path.read_text())
    assert raw["paused_until"] == buffered, (
        f"state paused_until must be raw+60 ({buffered}), got {raw['paused_until']}"
    )


def test_handle_rate_limit_event_rejected_without_resets_at_logs_warning(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """Rejected with no resets_at: log warning, do not raise."""
    logger = logging.getLogger("test.no_resets")
    state_path = tmp_path / ".code-generator" / "state.json"

    info = FakeRateLimitInfo(status="rejected", resets_at=None, rate_limit_type="five_hour")
    event = FakeRateLimitEvent(info)

    with caplog.at_level(logging.WARNING):
        handle_rate_limit_event(event, logger, state_path)

    assert any("no resets_at" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# render_blocks / render_system_message / render_prompt / new predicates
# ---------------------------------------------------------------------------


class FakeToolUseBlock:
    def __init__(self, name: str, input_data: dict) -> None:
        self.name = name
        self.input = input_data
        self.id = "tu-x"


class FakeToolResultBlock:
    def __init__(self, tool_use_id: str, content, is_error: bool = False) -> None:
        self.tool_use_id = tool_use_id
        self.content = content
        self.is_error = is_error


class FakeThinkingBlock:
    def __init__(self, thinking: str) -> None:
        self.thinking = thinking


class FakeSystemMessage:
    def __init__(self, subtype: str, data: dict | None = None) -> None:
        self.subtype = subtype
        self.data = data


class FakeUserMessage:
    def __init__(self, content) -> None:
        self.role = "user"
        self.content = content


def test_render_blocks_handles_text_block() -> None:
    from code_generator.runner.message_parsing import render_blocks

    rendered = render_blocks([FakeTextBlock("hello world")])
    assert rendered == "text: hello world"


def test_render_blocks_handles_tool_use_block() -> None:
    from code_generator.runner.message_parsing import render_blocks

    rendered = render_blocks([FakeToolUseBlock("Read", {"file_path": "/tmp/x.py"})])
    assert rendered.startswith("tool_use(Read): ")
    assert "/tmp/x.py" in rendered


def test_render_blocks_handles_tool_result_block_str() -> None:
    from code_generator.runner.message_parsing import render_blocks

    rendered = render_blocks([FakeToolResultBlock("tu-1", "result body")])
    assert rendered == "tool_result(tu-1): result body"


def test_render_blocks_marks_tool_result_errors() -> None:
    from code_generator.runner.message_parsing import render_blocks

    rendered = render_blocks([FakeToolResultBlock("tu-2", "boom", is_error=True)])
    assert rendered.startswith("tool_result_error(tu-2): ")


def test_render_blocks_handles_thinking_block() -> None:
    from code_generator.runner.message_parsing import render_blocks

    rendered = render_blocks([FakeThinkingBlock("planning step…")])
    assert rendered == "thinking: planning step…"


def test_render_blocks_renders_long_text_in_full() -> None:
    """No truncation — full text is preserved so DEBUG logs are lossless."""
    from code_generator.runner.message_parsing import render_blocks

    long = "x" * 5000
    rendered = render_blocks([FakeTextBlock(long)])
    assert rendered == f"text: {long}"
    assert "truncated" not in rendered


def test_render_blocks_joins_multiple_with_pipe() -> None:
    from code_generator.runner.message_parsing import render_blocks

    rendered = render_blocks(
        [
            FakeTextBlock("first"),
            FakeToolUseBlock("Read", {"path": "a.py"}),
        ]
    )
    assert " | " in rendered
    assert "text: first" in rendered
    assert "tool_use(Read)" in rendered


def test_render_blocks_empty_list_returns_marker() -> None:
    from code_generator.runner.message_parsing import render_blocks

    assert render_blocks([]) == "<empty>"


def test_render_system_message_with_subtype_and_data() -> None:
    from code_generator.runner.message_parsing import render_system_message

    msg = FakeSystemMessage("init", {"model": "claude-opus-4-7", "session_id": "s1"})
    rendered = render_system_message(msg)
    assert rendered.startswith("subtype=init")
    assert "model=" in rendered
    assert "session_id=" in rendered


def test_render_system_message_subtype_only() -> None:
    from code_generator.runner.message_parsing import render_system_message

    msg = FakeSystemMessage("compaction", None)
    rendered = render_system_message(msg)
    assert rendered.startswith("subtype=compaction")
    assert "no data" in rendered


def test_is_system_message_predicate() -> None:
    from code_generator.runner.message_parsing import is_system_message

    assert is_system_message(FakeSystemMessage("init"))
    assert not is_system_message(FakeAssistantMessage("hi"))
    assert not is_system_message(FakeUserMessage([FakeTextBlock("hi")]))


def test_is_user_message_predicate() -> None:
    from code_generator.runner.message_parsing import is_user_message

    assert is_user_message(FakeUserMessage([FakeTextBlock("hi")]))
    assert not is_user_message(FakeSystemMessage("init"))
    assert not is_user_message(FakeAssistantMessage("hi"))


# ---------------------------------------------------------------------------
# Issue #243 — is_clear_tool_uses_event predicate
# ---------------------------------------------------------------------------


class FakeClearToolUsesByType:
    """SDK message exposing ``type == 'clear_tool_uses_20250919'`` on the envelope."""

    def __init__(self) -> None:
        self.type = "clear_tool_uses_20250919"


class FakeClearToolUsesSystemSubtype:
    """SDK SystemMessage whose ``subtype`` is the clear identifier."""

    def __init__(self) -> None:
        self.subtype = "clear_tool_uses_20250919"
        self.data = None


class FakeClearToolUsesSystemData:
    """SDK SystemMessage whose ``data`` payload carries the clear type."""

    def __init__(self) -> None:
        self.subtype = "context_edit"
        self.data = {"type": "clear_tool_uses_20250919", "freed": 12345}


def test_is_clear_tool_uses_event_matches_type_envelope() -> None:
    """Top-level ``msg.type`` carrying the canonical identifier returns True."""
    from code_generator.runner.message_parsing import is_clear_tool_uses_event

    assert is_clear_tool_uses_event(FakeClearToolUsesByType()) is True


def test_is_clear_tool_uses_event_matches_system_subtype() -> None:
    """SystemMessage subtype carrying the canonical identifier returns True."""
    from code_generator.runner.message_parsing import is_clear_tool_uses_event

    assert is_clear_tool_uses_event(FakeClearToolUsesSystemSubtype()) is True


def test_is_clear_tool_uses_event_matches_system_data_dict() -> None:
    """SystemMessage data dict with ``type`` == clear identifier returns True."""
    from code_generator.runner.message_parsing import is_clear_tool_uses_event

    assert is_clear_tool_uses_event(FakeClearToolUsesSystemData()) is True


def test_is_clear_tool_uses_event_rejects_unrelated_messages() -> None:
    """Non-clear messages (assistant, plain system, result) return False."""
    from code_generator.runner.message_parsing import is_clear_tool_uses_event

    assert is_clear_tool_uses_event(FakeAssistantMessage("hi")) is False
    assert is_clear_tool_uses_event(FakeSystemMessage("init")) is False
    assert is_clear_tool_uses_event(FakeResultMessage()) is False


def test_is_clear_tool_uses_event_rejects_result_message_with_clear_type() -> None:
    """Even if a ResultMessage somehow carried the clear type, predicate returns False.

    Mirrors the early-return guard used by ``is_context_edit_message`` /
    ``is_compaction_pause_event`` — terminal ResultMessages are never lifecycle
    events.
    """
    from code_generator.runner.message_parsing import is_clear_tool_uses_event

    msg = FakeResultMessage()
    msg.type = "clear_tool_uses_20250919"  # type: ignore[attr-defined]
    assert is_clear_tool_uses_event(msg) is False


def test_render_prompt_renders_long_input_verbatim() -> None:
    """No truncation — prompts log in full so the model's exact input is auditable."""
    from code_generator.runner.message_parsing import render_prompt

    long = "y" * 5000
    rendered = render_prompt(long)
    assert rendered == long
    assert "truncated" not in rendered


def test_render_prompt_passthrough_short_input() -> None:
    from code_generator.runner.message_parsing import render_prompt

    assert render_prompt("hello") == "hello"


def test_render_blocks_renders_long_tool_result_in_full() -> None:
    """Tool results render verbatim — no body cap."""
    from code_generator.runner.message_parsing import render_blocks

    long = "z" * 5000
    rendered = render_blocks([FakeToolResultBlock("tu-9", long)])
    assert rendered == f"tool_result(tu-9): {long}"
    assert "truncated" not in rendered
