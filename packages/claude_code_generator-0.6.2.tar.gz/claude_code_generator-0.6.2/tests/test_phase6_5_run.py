"""Tests for Phase 6.5 ``run()`` orchestration entry point (#275)."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from code_generator import checklist as _checklist
from code_generator import state as _state
from code_generator.orchestrator import phase6_5_verify
from code_generator.orchestrator.phase6_5_verify import (
    TierResult,
    VerificationFailed,
    run,
)

# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------


def _passed(tier_id: str) -> TierResult:
    return TierResult(
        tier_id=tier_id,
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=0,
        stderr_tail=None,
        failing_detail=None,
    )


def _failed(tier_id: str, detail: str = "fail") -> TierResult:
    return TierResult(
        tier_id=tier_id,
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=1,
        stderr_tail="some stderr tail",
        failing_detail=detail,
    )


def _make_state_with_closed_issues(
    tmp_path: Path, requirements_hash: str, closed_numbers: list[int]
) -> _state.State:
    state_path = tmp_path / ".code-generator" / "state.json"
    state = _state.load_state(state_path)
    state.mode = "single"
    state.requirements_hash = requirements_hash
    state.issues = [
        _state.IssueState(number=n, status="closed", agent="python-pro", title=f"Issue {n}")
        for n in closed_numbers
    ]
    _state.save_state(state_path, state)
    return state


def _seed_checklist(tmp_path: Path, requirements_hash: str, numbers: list[int]) -> Path:
    checklist_path = tmp_path / ".code-generator" / "checklists" / f"{requirements_hash}.json"
    issues = [
        _state.IssueState(number=n, status="open", agent="python-pro", title=f"Issue {n}")
        for n in numbers
    ]
    _checklist.seed(checklist_path, issues)
    return checklist_path


@pytest.fixture
def neutral_runner() -> Any:
    """Lightweight runner stub (rate_limit is patched in tests, so this is a placeholder)."""
    return MagicMock()


@pytest.fixture
def shared_client() -> Any:
    """Non-None shared client stand-in — phase6_5.run requires shared_client."""
    return MagicMock()


@pytest.fixture
def logger() -> logging.Logger:
    return logging.getLogger("test.phase6_5")


# ---------------------------------------------------------------------------
# Pre-conditions / signature
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_raises_runtime_error_when_shared_client_none(
    tmp_path: Path, neutral_runner: Any, logger: logging.Logger
) -> None:
    state = _make_state_with_closed_issues(tmp_path, "abcd1234", [1])
    state_path = tmp_path / ".code-generator" / "state.json"

    with pytest.raises(RuntimeError, match="shared_client"):
        await run(
            state,
            None,
            tmp_path,
            state_path,
            runner_module=neutral_runner,
            logger=logger,
            shared_client=None,
        )


# ---------------------------------------------------------------------------
# (a) All tiers pass on attempt 1 → no repair, runtime_verified ticked
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_all_tiers_green_first_attempt_skips_repair_and_ticks_checklist(
    tmp_path: Path,
    neutral_runner: Any,
    shared_client: Any,
    logger: logging.Logger,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state = _make_state_with_closed_issues(tmp_path, "abcd1234", [1, 2])
    state_path = tmp_path / ".code-generator" / "state.json"
    checklist_path = _seed_checklist(tmp_path, "abcd1234", [1, 2])

    monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: _passed("T0"))
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _passed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))

    repair = AsyncMock()
    monkeypatch.setattr(phase6_5_verify, "_run_repair_pass", repair)

    await run(
        state,
        None,
        tmp_path,
        state_path,
        runner_module=neutral_runner,
        logger=logger,
        shared_client=shared_client,
    )

    assert repair.await_count == 0
    entries = {e.issue_number: e for e in _checklist.load(checklist_path)}
    assert entries[1].runtime_verified is True
    assert entries[2].runtime_verified is True


# ---------------------------------------------------------------------------
# (b) T1 fails repeatedly → exactly max_retries repair calls then VerificationFailed
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_t1_fails_repeatedly_raises_verification_failed_after_max_retries(
    tmp_path: Path,
    neutral_runner: Any,
    shared_client: Any,
    logger: logging.Logger,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state = _make_state_with_closed_issues(tmp_path, "abcd1234", [1])
    state_path = tmp_path / ".code-generator" / "state.json"
    _seed_checklist(tmp_path, "abcd1234", [1])

    monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: _passed("T0"))
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _failed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))

    repair = AsyncMock()
    monkeypatch.setattr(phase6_5_verify, "_run_repair_pass", repair)

    with pytest.raises(VerificationFailed):
        await run(
            state,
            None,
            tmp_path,
            state_path,
            runner_module=neutral_runner,
            logger=logger,
            shared_client=shared_client,
            max_retries=3,
        )

    # 3 attempts → 3 failures → 3 repair calls. After the third repair the
    # loop exits and raises VerificationFailed (no further repair).
    assert repair.await_count == 3


# ---------------------------------------------------------------------------
# (c) T0 passes attempt 2 after repair → loop exits cleanly
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_t0_recovers_on_attempt_2_after_repair_loop_succeeds(
    tmp_path: Path,
    neutral_runner: Any,
    shared_client: Any,
    logger: logging.Logger,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state = _make_state_with_closed_issues(tmp_path, "abcd1234", [1])
    state_path = tmp_path / ".code-generator" / "state.json"
    checklist_path = _seed_checklist(tmp_path, "abcd1234", [1])

    t0_outcomes = iter([_failed("T0"), _passed("T0")])
    monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: next(t0_outcomes))
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _passed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))

    repair = AsyncMock()
    monkeypatch.setattr(phase6_5_verify, "_run_repair_pass", repair)

    await run(
        state,
        None,
        tmp_path,
        state_path,
        runner_module=neutral_runner,
        logger=logger,
        shared_client=shared_client,
        max_retries=3,
    )

    assert repair.await_count == 1
    entry = _checklist.load(checklist_path)[0]
    assert entry.runtime_verified is True


# ---------------------------------------------------------------------------
# (d) Phase65Progress updated atomically each attempt
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_phase6_5_progress_updated_each_attempt(
    tmp_path: Path,
    neutral_runner: Any,
    shared_client: Any,
    logger: logging.Logger,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state = _make_state_with_closed_issues(tmp_path, "abcd1234", [1])
    state_path = tmp_path / ".code-generator" / "state.json"
    _seed_checklist(tmp_path, "abcd1234", [1])

    saved_progress_snapshots: list[tuple[int, str | None, list[str], list[str]]] = []

    real_save = _state.save_state

    def spy_save(path: Path, st: _state.State) -> None:
        progress = st.phase6_5
        if progress is not None:
            saved_progress_snapshots.append(
                (
                    progress.attempt,
                    progress.last_tier,
                    list(progress.tiers_passed),
                    list(progress.tiers_failed),
                )
            )
        real_save(path, st)

    monkeypatch.setattr(phase6_5_verify, "save_state", spy_save)

    monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: _passed("T0"))
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _failed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))

    monkeypatch.setattr(phase6_5_verify, "_run_repair_pass", AsyncMock())

    with pytest.raises(VerificationFailed):
        await run(
            state,
            None,
            tmp_path,
            state_path,
            runner_module=neutral_runner,
            logger=logger,
            shared_client=shared_client,
            max_retries=2,
        )

    # At least one save per attempt; T0 pass + T1 fail per attempt.
    assert len(saved_progress_snapshots) >= 2
    # Final snapshot reflects last attempt: T1 in failed list, T0 in passed list.
    last = saved_progress_snapshots[-1]
    assert "T1" in last[3]
    assert "T0" in last[2]


@pytest.mark.asyncio
async def test_verification_failed_message_mentions_failure_report(
    tmp_path: Path,
    neutral_runner: Any,
    shared_client: Any,
    logger: logging.Logger,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state = _make_state_with_closed_issues(tmp_path, "abcd1234", [1])
    state_path = tmp_path / ".code-generator" / "state.json"
    _seed_checklist(tmp_path, "abcd1234", [1])

    monkeypatch.setattr(phase6_5_verify, "run_t0_build", lambda *_a, **_kw: _failed("T0"))
    monkeypatch.setattr(phase6_5_verify, "run_t1_boot", lambda *_a, **_kw: _passed("T1"))
    monkeypatch.setattr(phase6_5_verify, "run_t2_api", lambda *_a, **_kw: _passed("T2"))
    monkeypatch.setattr(phase6_5_verify, "_run_repair_pass", AsyncMock())

    with pytest.raises(VerificationFailed) as excinfo:
        await run(
            state,
            None,
            tmp_path,
            state_path,
            runner_module=neutral_runner,
            logger=logger,
            shared_client=shared_client,
            max_retries=1,
        )

    assert "T0" in str(excinfo.value)
