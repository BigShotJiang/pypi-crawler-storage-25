"""Tests for the `code-generator status` command."""

import time
from pathlib import Path

import pytest
from typer.testing import CliRunner

from code_generator import state as state_module
from code_generator.cli import app

runner = CliRunner()


def _write_state(path: Path, st: state_module.State) -> None:
    state_module.save_state(path, st)


def test_no_state_file_prints_friendly_message(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "init" in result.output


def test_single_mode_state_shows_mode_and_phase(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "single"
    st.phase = 3
    st.issues = [
        state_module.IssueState(number=1, status="open", agent="python-pro"),
        state_module.IssueState(number=2, status="closed", agent="python-pro"),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "single" in result.output
    assert "3" in result.output
    # open count = 1, closed = 1
    assert "1" in result.output


def test_multi_cycle_state_renders_cycle_rows(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "multi-cycle"
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="Milestone 1",
            status="completed",
            phase=7,
            issues=[state_module.IssueState(number=1, status="closed", agent="python-pro")],
            commit_sha="abc123",
        ),
        state_module.CycleState(
            id=2,
            name="Cycle 2",
            milestone_number=2,
            milestone_title="Milestone 2",
            status="in-progress",
            phase=3,
            issues=[
                state_module.IssueState(number=2, status="open", agent="python-pro"),
                state_module.IssueState(number=3, status="closed", agent="python-pro"),
            ],
            commit_sha=None,
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "Cycle 1" in result.output
    assert "Cycle 2" in result.output
    assert "completed" in result.output
    assert "in-progress" in result.output


def _make_multi_cycle_state() -> state_module.State:
    """Helper: build a multi-cycle state with rich CycleState data."""
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=10,
            milestone_title="Milestone 10",
            status="completed",
            phase=7,
            issues=[state_module.IssueState(number=1, status="closed", agent="python-pro")],
            commit_sha="abc123",
            scope="Set up core database models and migrations",
            depends_on=[],
        ),
        state_module.CycleState(
            id=2,
            name="Cycle 2",
            milestone_number=11,
            milestone_title="Milestone 11",
            status="in-progress",
            phase=3,
            issues=[
                state_module.IssueState(number=2, status="open", agent="python-pro"),
                state_module.IssueState(number=3, status="closed", agent="python-pro"),
            ],
            commit_sha=None,
            scope="Implement REST API endpoints for user management",
            depends_on=[1],
        ),
    ]
    return st


def test_cycles_table_renders_scope_column(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = _make_multi_cycle_state()
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "scope" in result.output
    assert "Set up core database" in result.output
    assert "Implement REST API" in result.output


def test_cycles_table_renders_depends_on_column(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = _make_multi_cycle_state()
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "depends on" in result.output
    # cycle 1 has no deps → "—"; cycle 2 depends on [1] → "1"
    assert "1" in result.output


def test_cycles_table_renders_milestone_column(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = _make_multi_cycle_state()
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "milestone" in result.output
    assert "#10" in result.output
    assert "#11" in result.output


def test_cycles_table_shows_checkmark_for_completed_status(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = _make_multi_cycle_state()
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "✓" in result.output


def test_cycles_table_renders_dash_for_missing_scope_and_deps(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=None,
            milestone_title="",
            status="in-progress",
            phase=1,
            issues=[],
            commit_sha=None,
            scope="",
            depends_on=[],
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # "None" should never appear
    assert "None" not in result.output
    # em dash for empty scope, deps, and milestone
    assert "—" in result.output


def test_summary_table_shows_requirements_hash_when_present(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "single"
    # Simulate the requirements_hash field added by issue #109 — may not exist yet
    object.__setattr__(st, "requirements_hash", "abcdef1234567890") if not hasattr(
        st, "requirements_hash"
    ) else setattr(st, "requirements_hash", "abcdef1234567890")
    _write_state(cg_dir / "state.json", st)

    # Reload to simulate normal flow (hash may not survive save/load yet)
    # so we test the rendering function directly via monkeypatching load_state
    import unittest.mock as mock

    st_with_hash = state_module.load_state(cg_dir / "state.json")
    st_with_hash.__dict__["requirements_hash"] = "abcdef1234567890"

    with mock.patch(
        "code_generator.commands.status.state_module.load_state", return_value=st_with_hash
    ):
        result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "requirements hash" in result.output
    assert "abcdef12" in result.output  # truncated to 8 chars


def test_paused_state_shows_minutes_remaining(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.paused_until = int(time.time()) + 120
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "2" in result.output
    assert "minute" in result.output


# ---------------------------------------------------------------------------
# New tests for issue #125: token columns, wall-clock, last_error rendering
# ---------------------------------------------------------------------------


def _make_token_usage(
    input: int = 0,
    output: int = 0,
    cache_read: int = 0,
    cache_write: int = 0,
    num_turns: int = 0,
) -> state_module.TokenUsage:
    from code_generator.runner.types import TokenUsage

    return TokenUsage(
        input=input,
        output=output,
        cache_read=cache_read,
        cache_write=cache_write,
        num_turns=num_turns,
    )


def test_multi_cycle_token_columns_show_correct_values(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When cycles have populated token_usage, correct summed values appear in columns."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3": _make_token_usage(input=100, output=50, cache_read=200, cache_write=30),
                "phase4": _make_token_usage(input=10, output=5, cache_read=20, cache_write=3),
            },
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # summed: input=110, output=55, cache_read=220, cache_write=33
    assert "110" in result.output
    assert "55" in result.output
    assert "220" in result.output
    assert "33" in result.output


def test_multi_cycle_turns_column_shows_accumulated_num_turns(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Issue #211: Turns column renders the summed ``num_turns`` across phases."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3_4": _make_token_usage(input=100, num_turns=42),
            },
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # The cycles table gains a "Turns" header and the row shows 42.
    assert "Turns" in result.output
    assert "42" in result.output


def test_multi_cycle_turns_column_shows_zero_for_pre_upgrade_state(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Issue #211: legacy token_usage without ``num_turns`` renders ``0`` (no crash)."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    # Old state: TokenUsage is constructed without num_turns so the field
    # defaults to 0 via the dataclass default (same as reading pre-0.3.1 JSON).
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3_4": _make_token_usage(input=100),
            },
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "Turns" in result.output
    # The row for cycle 1 must carry a literal "0" in the Turns column and
    # must not crash with KeyError.
    assert "0" in result.output


def test_pre_upgrade_cycle_shows_dash_in_token_columns(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Pre-upgrade cycles with empty token_usage render — in all four token columns."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={},  # pre-upgrade: empty
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "—" in result.output
    assert result.exit_code == 0  # no crash


def test_wall_clock_column_shows_formatted_duration(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cycles with started_at and finished_at render formatted duration in wall-clock column."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            started_at="2026-01-01T10:00:00Z",
            finished_at="2026-01-01T11:23:00Z",  # 1h 23m
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "1h 23m" in result.output


def test_wall_clock_column_shows_minutes_seconds_for_short_duration(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cycles shorter than 1h render as Xm Ys in wall-clock column."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            started_at="2026-01-01T10:00:00Z",
            finished_at="2026-01-01T10:45:30Z",  # 45m 30s
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "45m 30s" in result.output


def test_wall_clock_column_shows_dash_when_timestamps_missing(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cycles with missing started_at or finished_at render — in wall-clock column."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="in-progress",
            phase=3,
            issues=[],
            commit_sha=None,
            started_at=None,
            finished_at=None,
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "—" in result.output


def test_pct_5h_column_shows_correct_percentage(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """% of 5h column shows sum(cache_read)/50_000_000*100 for each cycle."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    # 5_000_000 cache_read = 10.0% of 50_000_000 budget
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3": _make_token_usage(cache_read=3_000_000),
                "phase4": _make_token_usage(cache_read=2_000_000),
            },
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "10.0%" in result.output


def test_last_error_renders_in_red_at_top(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """When last_error is set, red error banner appears and no plain-text row in summary."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "single"
    st.last_error = "phase 3 failed: timeout"
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # red banner text is present
    assert "phase 3 failed: timeout" in result.output
    # the plain-text "last error" row in the summary table must NOT appear
    assert "last error" not in result.output


def test_no_red_banner_when_last_error_is_none(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When last_error is None, no red error banner in output."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "single"
    st.last_error = None
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "Last error" not in result.output
    assert "⚠" not in result.output


def test_single_cycle_mode_shows_token_totals_in_summary(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Single-cycle mode: summary table shows token totals summed across phases."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="single", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.token_usage = {
        "phase3": _make_token_usage(input=500, output=100, cache_read=1000, cache_write=50),
        "phase5": _make_token_usage(input=200, output=40, cache_read=400, cache_write=20),
    }
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # "Tokens" row group header should appear
    assert "Tokens" in result.output
    # summed: input=700, output=140, cache_read=1400, cache_write=70
    assert "700" in result.output
    assert "140" in result.output
    assert "1400" in result.output
    assert "70" in result.output


# ---------------------------------------------------------------------------
# Issue #191: Cache hit % column and CycleTelemetrySummary rendering
# ---------------------------------------------------------------------------


def _make_cycle_with_telemetry(
    cycle_id: int,
    cache_hit_pct: float = 0.0,
    wall_seconds: float = 0.0,
) -> state_module.CycleState:
    return state_module.CycleState(
        id=cycle_id,
        name=f"Cycle {cycle_id}",
        milestone_number=cycle_id,
        milestone_title=f"Milestone {cycle_id}",
        status="completed",
        phase=7,
        issues=[],
        commit_sha=None,
        cache_telemetry={
            "input": 100,
            "output": 50,
            "cache_read": 200,
            "cache_write": 30,
            "cache_hit_pct": cache_hit_pct,
            "wall_seconds": wall_seconds,
        },
    )


def test_cache_hit_pct_column_renders_when_populated(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cache hit % column shows XX.X% format when cache_hit_pct is non-zero."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_telemetry(1, cache_hit_pct=67.3)]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "67.3%" in result.output
    assert "Cache hit %" in result.output


def test_cache_hit_pct_column_renders_dash_when_all_zero(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cache hit % column renders '-' (not '0.0%') when all telemetry values are zero."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_telemetry(1, cache_hit_pct=0.0)]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "0.0%" not in result.output
    assert "-" in result.output


def test_cache_hit_pct_column_renders_dash_for_legacy_state(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Legacy state without cache_telemetry renders '-' in Cache hit % column without error."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()

    import json

    raw = {
        "mode": "multi-cycle",
        "started_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-01-01T00:00:00Z",
        "cycles": [
            {
                "id": 1,
                "name": "Legacy Cycle",
                "milestone_number": 1,
                "milestone_title": "Milestone 1",
                "status": "completed",
                "phase": 7,
                "issues": [],
                "commit_sha": None,
                # No cache_telemetry — legacy format
            }
        ],
    }
    (cg_dir / "state.json").write_text(json.dumps(raw))

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "0.0%" not in result.output
    assert "Cache hit %" in result.output


def test_status_12_cycles_shows_2_summary_rows_and_10_detail_rows(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """status on a 12-cycle state shows 10 full detail rows + 2 summary rows."""
    from code_generator.runner.types import TokenUsage

    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=i,
            name=f"Cycle {i}",
            milestone_number=i,
            milestone_title=f"Milestone {i}",
            status="completed",
            phase=7,
            issues=[state_module.IssueState(number=i, status="closed", agent="python-pro")],
            commit_sha=f"sha{i}",
            token_usage={
                "phase3": TokenUsage(input=100, output=50, cache_read=200, cache_write=30)
            },
            cache_telemetry={
                "input": 100,
                "output": 50,
                "cache_read": 200,
                "cache_write": 30,
                "cache_hit_pct": 45.5,
                "wall_seconds": 120.0,
            },
        )
        for i in range(1, 13)
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0

    # 12 cycle names should appear: Cycle 1 through Cycle 12
    for i in range(1, 13):
        assert f"Cycle {i}" in result.output

    # Summary indicator: "(summary)" or similar text should appear for old cycles
    assert "summary" in result.output.lower()


def test_summary_cycle_row_shows_retained_fields(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Summary cycle rows (from retention) show cycle name, total_tokens, cache_hit_pct, wall_seconds."""
    from code_generator.runner.types import TokenUsage

    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=i,
            name=f"Cycle {i}",
            milestone_number=i,
            milestone_title=f"Milestone {i}",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3": TokenUsage(input=100, output=50, cache_read=200, cache_write=30)
            },
            cache_telemetry={
                "input": 100,
                "output": 50,
                "cache_read": 200,
                "cache_write": 30,
                "cache_hit_pct": 33.3,
                "wall_seconds": 90.0,
            },
        )
        for i in range(1, 13)
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # Cache hit pct for detail rows should appear (last 10 cycles)
    assert "33.3%" in result.output


# ---------------------------------------------------------------------------
# Issue #222: "Model" column rendering (Ollama tag / Anthropic Max default)
# ---------------------------------------------------------------------------


def _make_cycle_with_model(cid: int, ollama_model: str | None) -> state_module.CycleState:
    """Build a minimal CycleState with an optional ollama_model tag."""
    return state_module.CycleState(
        id=cid,
        name=f"Cycle {cid}",
        milestone_number=cid,
        milestone_title=f"M{cid}",
        status="completed",
        phase=7,
        issues=[],
        commit_sha=None,
        ollama_model=ollama_model,
    )


def test_model_column_header_present_in_cycles_table(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The cycles table advertises a ``Model`` column header."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_model(1, ollama_model=None)]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    assert "Model" in result.output


def test_ollama_cycle_row_shows_ollama_prefixed_tag(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A cycle with ollama_model set renders ``ollama:<tag>`` in the Model column."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_model(1, ollama_model="qwen3-coder:480b:cloud")]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    assert "ollama:qwen3-coder:480b:cloud" in result.output


def test_anthropic_max_cycle_row_shows_anthropic_max_label(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A cycle without ollama_model renders a non-empty ``anthropic-max`` label."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_model(1, ollama_model=None)]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    # Default: the Anthropic Max path is labelled, not left blank.
    assert "anthropic-max" in result.output


def test_mixed_cycles_render_distinct_model_labels(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Snapshot-style check: two cycles with different providers surface
    distinguishable Model values in the same table render."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        _make_cycle_with_model(1, ollama_model=None),
        _make_cycle_with_model(2, ollama_model="gpt-oss:120b-cloud"),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    assert "anthropic-max" in result.output
    assert "ollama:gpt-oss:120b-cloud" in result.output


def test_format_model_unit_helper_returns_anthropic_max_by_default() -> None:
    """Unit-test the _format_model helper directly for the no-Ollama case."""
    from code_generator.commands.status import _format_model

    cycle = _make_cycle_with_model(1, ollama_model=None)
    assert _format_model(cycle) == "anthropic-max"


def test_format_model_unit_helper_returns_prefixed_ollama_tag() -> None:
    """Unit-test the _format_model helper directly for the Ollama case."""
    from code_generator.commands.status import _format_model

    cycle = _make_cycle_with_model(1, ollama_model="my-model:7b")
    assert _format_model(cycle) == "ollama:my-model:7b"


def test_summary_row_renders_without_crash_when_model_column_added(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Regression guard: adding the Model column must not break summary rows.

    CycleTelemetrySummary rows don't carry a model — they must render a
    sentinel (``—``) in the new column without raising.
    """
    from code_generator.state_retention import CycleTelemetrySummary

    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        CycleTelemetrySummary(
            cycle_name="Old",
            total_tokens=1000,
            cache_hit_pct=50.0,
            wall_seconds=120.0,
        ),
        _make_cycle_with_model(2, ollama_model="qwen:latest"),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    # Summary row renders (column count matches), and the Ollama cycle still
    # displays its tag beside it.
    assert "ollama:qwen:latest" in result.output
    assert "Old" in result.output  # summary row's cycle_name


# ---------------------------------------------------------------------------
# Issue #247 — per-phase telemetry block
# ---------------------------------------------------------------------------


class TestPhaseTelemetryRendering:
    """Snapshot tests for ``_render_phase_telemetry_lines`` (issue #247)."""

    def _capture(self, token_usage: dict[str, state_module.TokenUsage]) -> str:
        from rich.console import Console

        from code_generator.commands.status import _render_phase_telemetry_lines

        console = Console(record=True, width=200, force_terminal=False)
        _render_phase_telemetry_lines(console, token_usage)
        return console.export_text()

    def test_humanize_under_thousand_renders_verbatim(self) -> None:
        from code_generator.commands.status import _humanize

        assert _humanize(0) == "0"
        assert _humanize(1) == "1"
        assert _humanize(999) == "999"

    def test_humanize_rounds_to_nearest_thousand_with_k_suffix(self) -> None:
        from code_generator.commands.status import _humanize

        assert _humanize(1000) == "1k"
        assert _humanize(12_499) == "12k"
        assert _humanize(12_500) == "12k"
        assert _humanize(85_000) == "85k"
        assert _humanize(85_400) == "85k"

    def test_renders_briefing_format_for_populated_phase3_4(self) -> None:
        from code_generator.runner.types import TokenUsage

        usage = TokenUsage(
            input=12_000,
            output=4_000,
            cache_read=85_000,
            cache_write=23_000,
            cache_write_5m=3_000,
            cache_write_1h=20_000,
        )
        out = self._capture({"phase3_4": usage})
        assert (
            "phase 3/4: in=12k cache_read=85k(71%) cache_write_5m=3k cache_write_1h=20k out=4k"
        ) in out

    def test_renders_phases_in_canonical_order(self) -> None:
        from code_generator.runner.types import TokenUsage

        token_usage = {
            "phase7": TokenUsage(input=1, cache_read=1),
            "phase0": TokenUsage(input=2, cache_read=1),
            "phase3_4": TokenUsage(input=3, cache_read=1),
            "phase1": TokenUsage(input=4, cache_read=1),
            "phase2": TokenUsage(input=5, cache_read=1),
            "phase5": TokenUsage(input=6, cache_read=1),
            "phase6": TokenUsage(input=7, cache_read=1),
        }
        out = self._capture(token_usage)
        order = [
            out.index("phase 0:"),
            out.index("phase 1:"),
            out.index("phase 2:"),
            out.index("phase 3/4:"),
            out.index("phase 5:"),
            out.index("phase 6:"),
            out.index("phase 7:"),
        ]
        assert order == sorted(order)

    def test_zero_phase_is_suppressed(self) -> None:
        from code_generator.runner.types import TokenUsage

        out = self._capture({"phase1": TokenUsage(), "phase2": TokenUsage(input=10)})
        assert "phase 1:" not in out
        assert "phase 2:" in out

    def test_unknown_phase_keys_are_skipped(self) -> None:
        """Non-canonical phase keys never appear in the output."""
        from code_generator.runner.types import TokenUsage

        out = self._capture({"phase99": TokenUsage(input=10), "phase0": TokenUsage(input=20)})
        assert "phase 99:" not in out
        assert "phase 0:" in out

    def test_cache_hit_pct_zero_denominator_renders_zero(self) -> None:
        """A phase with output but zero cache/input still renders with 0%."""
        from code_generator.runner.types import TokenUsage

        out = self._capture({"phase5": TokenUsage(output=10)})
        assert "cache_read=0(0%)" in out

    def test_status_command_invokes_phase_block_in_single_mode(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from code_generator.runner.types import TokenUsage

        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = state_module.State(
            mode="single", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
        )
        st.token_usage = {"phase1": TokenUsage(input=5_000, output=1_000, cache_read=1_000)}
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "phase 1: in=5k" in result.output

    def test_status_command_renders_phase_block_per_cycle_in_multi_cycle(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from code_generator.runner.types import TokenUsage

        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.cycles = [
            state_module.CycleState(
                id=1,
                name="Cycle Alpha",
                milestone_number=None,
                milestone_title="M1",
                status="open",
                phase=3,
                issues=[],
                commit_sha=None,
                token_usage={
                    "phase3_4": TokenUsage(
                        input=12_000,
                        output=4_000,
                        cache_read=85_000,
                        cache_write=23_000,
                        cache_write_5m=3_000,
                        cache_write_1h=20_000,
                    )
                },
            ),
        ]
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Cycle Alpha" in result.output
        assert (
            "phase 3/4: in=12k cache_read=85k(71%) cache_write_5m=3k cache_write_1h=20k out=4k"
        ) in result.output


# ---------------------------------------------------------------------------
# Issue #251 — checklist done/total summary line
# ---------------------------------------------------------------------------


class TestChecklistSummaryRendering:
    """``_render_checklist_summary`` prints ``features: <done>/<total>`` (issue #251)."""

    def _seed_checklist(
        self, project_dir: Path, requirements_hash: str, *, done: int, total: int
    ) -> None:
        """Write a minimal checklist with *done* feature_done entries out of *total*."""
        from code_generator import checklist

        checklist_path = (
            project_dir / ".code-generator" / "checklists" / f"{requirements_hash}.json"
        )
        issues = [
            state_module.IssueState(number=n, status="open", agent="python-pro", title=f"Issue {n}")
            for n in range(1, total + 1)
        ]
        checklist.seed(checklist_path, issues)
        for n in range(1, done + 1):
            checklist.tick_tests_passed(checklist_path, n)
            checklist.tick_runtime_verified(checklist_path, n)
            checklist.tick_committed(checklist_path, n)
            checklist.tick_professionalized(checklist_path, n)

    def test_renders_done_over_total_when_checklist_exists(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = state_module.State(
            mode="single", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
        )
        st.requirements_hash = "abcd1234"
        _write_state(cg_dir / "state.json", st)
        self._seed_checklist(tmp_path, "abcd1234", done=3, total=8)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "features: 3/8" in result.output

    def test_renders_dim_placeholder_when_requirements_hash_missing(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = state_module.State(
            mode="single", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
        )
        st.requirements_hash = None
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "features: -" in result.output

    def test_renders_dim_placeholder_when_checklist_file_missing(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = state_module.State(
            mode="single", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
        )
        st.requirements_hash = "deadbeef"
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "features: -" in result.output

    def test_renders_zero_done_when_checklist_seeded_but_untouched(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = state_module.State(
            mode="single", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
        )
        st.requirements_hash = "abcd1234"
        _write_state(cg_dir / "state.json", st)
        self._seed_checklist(tmp_path, "abcd1234", done=0, total=5)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "features: 0/5" in result.output

    def test_helper_appears_between_summary_and_cycles_tables(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """In multi-cycle mode the line sits between summary and cycles tables."""
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = "abcd1234"
        st.cycles = [
            state_module.CycleState(
                id=1,
                name="Cycle Alpha",
                milestone_number=None,
                milestone_title="M",
                status="open",
                phase=3,
                issues=[],
                commit_sha=None,
            ),
        ]
        _write_state(cg_dir / "state.json", st)
        self._seed_checklist(tmp_path, "abcd1234", done=2, total=4)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        # Summary table emits "code-generator status"; cycles table emits "cycles".
        summary_idx = result.output.index("code-generator status")
        features_idx = result.output.index("features: 2/4")
        cycles_idx = result.output.index("cycles")
        assert summary_idx < features_idx < cycles_idx


# ---------------------------------------------------------------------------
# Issue #277 — Phase 6.5 render + checklist runtime_verified flag
# ---------------------------------------------------------------------------


class TestPhase65StatusRendering:
    def _state_with_phase65(
        self,
        *,
        attempt: int,
        last_tier: str | None,
        passed: list[str],
        failed: list[str],
    ) -> state_module.State:
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.phase6_5 = state_module.Phase65Progress(
            attempt=attempt,
            last_tier=last_tier,
            tiers_passed=passed,
            tiers_failed=failed,
        )
        return st

    def test_renders_phase6_5_line_when_progress_populated(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = self._state_with_phase65(attempt=1, last_tier="T2", passed=["T0", "T1"], failed=["T2"])
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Phase 6.5" in result.output
        assert "attempt" in result.output
        assert "T0" in result.output
        assert "T1" in result.output
        assert "T2" in result.output

    def test_omits_phase6_5_line_when_field_is_none(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Phase 6.5" not in result.output

    def test_status_runs_on_legacy_state_without_phase65_field(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Backward-compat: pre-#269 state.json with no phase6_5 key must not crash."""
        import json

        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        legacy = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "session_mode": "shared",
        }
        (cg_dir / "state.json").write_text(json.dumps(legacy), encoding="utf-8")

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Phase 6.5" not in result.output


class TestChecklistRuntimeVerifiedFlag:
    def _seed_partial(self, tmp_path: Path, requirements_hash: str) -> None:
        from code_generator import checklist

        path = tmp_path / ".code-generator" / "checklists" / f"{requirements_hash}.json"
        issues = [
            state_module.IssueState(number=n, status="open", agent="python-pro", title=f"#{n}")
            for n in (1, 2)
        ]
        checklist.seed(path, issues)
        checklist.tick_tests_passed(path, 1)
        checklist.tick_runtime_verified(path, 1)
        checklist.tick_committed(path, 1)
        checklist.tick_tests_passed(path, 2)
        # issue 2: runtime_verified stays False

    def test_renders_runtime_verified_flag_per_issue(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = "abcd1234"
        _write_state(cg_dir / "state.json", st)
        self._seed_partial(tmp_path, "abcd1234")

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        # Per-issue compact flags should distinguish runtime_verified true vs false.
        assert "#1" in result.output
        assert "#2" in result.output
        # The token labels declared by the implementation: t=tests_passed, r=runtime_verified, c=committed.
        # Issue 1 has all three; issue 2 has only tests.
        assert "verified" in result.output.lower() or "runtime" in result.output.lower()


# ---------------------------------------------------------------------------
# Cycle 2: T3/T4 skip reasons + VIGIL flag (#289)
# ---------------------------------------------------------------------------


class TestPhase65Cycle2Rendering:
    """Status renders ``tiers_skipped``, ``skip_reasons``, and ``vigil_triggered``."""

    def _seed_with_phase65(
        self,
        tmp_path: Path,
        progress: state_module.Phase65Progress,
        *,
        vigil: bool = False,
    ) -> None:
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.phase = 65
        st.phase6_5 = progress
        st.vigil_triggered = vigil
        _write_state(cg_dir / "state.json", st)

    def test_when_t3_skipped_then_status_shows_skip_reason(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        progress = state_module.Phase65Progress(
            attempt=1,
            last_tier="T2",
            tiers_passed=["T0", "T1", "T2"],
            tiers_failed=[],
            tiers_skipped=["T3", "T4"],
            skip_reasons={"T3": "no frontend", "T4": "no docker"},
        )
        self._seed_with_phase65(tmp_path, progress)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "T3" in result.output
        assert "no frontend" in result.output
        assert "T4" in result.output
        assert "no docker" in result.output

    def test_when_vigil_triggered_then_status_shows_warning_line(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        progress = state_module.Phase65Progress(
            attempt=1, last_tier="T1", tiers_passed=["T0"], tiers_failed=["T1"]
        )
        self._seed_with_phase65(tmp_path, progress, vigil=True)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "VIGIL" in result.output

    def test_when_t4_passes_then_status_shows_t4_pass(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        progress = state_module.Phase65Progress(
            attempt=1,
            last_tier="T4",
            tiers_passed=["T0", "T1", "T2", "T4"],
            tiers_failed=[],
        )
        self._seed_with_phase65(tmp_path, progress)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "T4" in result.output
        # T4 appears in tiers_passed list rendering
        assert "passed" in result.output

    def test_when_legacy_state_no_new_fields_then_status_does_not_crash(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Pre-#281/#287 state.json (no tiers_skipped/skip_reasons/vigil_triggered)."""
        import json as _json

        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        legacy = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "session_mode": "shared",
            "phase": 65,
            "phase6_5": {
                "attempt": 1,
                "last_tier": "T2",
                "tiers_passed": ["T0", "T1", "T2"],
                "tiers_failed": [],
            },
        }
        (cg_dir / "state.json").write_text(_json.dumps(legacy), encoding="utf-8")

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "T2" in result.output
        assert "VIGIL" not in result.output  # vigil_triggered defaulted False

    def test_when_no_phase65_then_no_crash_and_vigil_independent(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``vigil_triggered`` renders even when ``phase6_5`` itself is None."""
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.vigil_triggered = True
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "VIGIL" in result.output


# ---------------------------------------------------------------------------
# Phase 8 status rendering (#304)
# ---------------------------------------------------------------------------


class TestPhase8StatusRendering:
    def test_phase8_label_in_phase_labels_tuple(self) -> None:
        """status._PHASE_LABELS includes ('phase8', '8') after Phase 7."""
        from code_generator.commands import status as status_module

        labels = list(status_module._PHASE_LABELS)
        keys = [k for k, _ in labels]
        assert "phase8" in keys
        assert keys.index("phase8") == keys.index("phase7") + 1
        assert dict(labels)["phase8"] == "8"

    def test_per_issue_flags_legend_includes_professionalized(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Per-issue checklist line renders 4-flag legend with p=professionalized."""
        from code_generator import checklist

        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = "abcd1234"
        _write_state(cg_dir / "state.json", st)

        checklist_path = cg_dir / "checklists" / "abcd1234.json"
        issues = [
            state_module.IssueState(number=1, status="closed", agent="python-pro", title="Issue 1"),
        ]
        checklist.seed(checklist_path, issues)
        checklist.tick_tests_passed(checklist_path, 1)
        checklist.tick_runtime_verified(checklist_path, 1)
        checklist.tick_committed(checklist_path, 1)
        checklist.tick_professionalized(checklist_path, 1)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "p=professionalized" in result.output
        assert "#1[t,r,c,p]" in result.output

    def test_per_issue_flags_missing_professionalized_renders_underscore(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When professionalized is False the token shows `_` in the p slot."""
        from code_generator import checklist

        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = "abcd1234"
        _write_state(cg_dir / "state.json", st)

        checklist_path = cg_dir / "checklists" / "abcd1234.json"
        issues = [
            state_module.IssueState(number=1, status="closed", agent="python-pro", title="Issue 1"),
        ]
        checklist.seed(checklist_path, issues)
        checklist.tick_tests_passed(checklist_path, 1)
        checklist.tick_runtime_verified(checklist_path, 1)
        checklist.tick_committed(checklist_path, 1)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "#1[t,r,c,_]" in result.output

    def test_phase8_state_renders_when_progress_populated(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Phase 8 line shows attempt + status when state.phase8 is set."""
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.phase = 8
        st.phase8 = state_module.Phase8Progress(
            attempt=1,
            status="ok",
            started_at="2026-05-16T00:00:00Z",
            finished_at="2026-05-16T00:00:05Z",
        )
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Phase 8" in result.output
        assert "ok" in result.output

    def test_phase8_state_renders_dim_placeholder_when_none(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Phase 8 line shows 'not run' when state.phase8 is None."""
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Phase 8" in result.output
        assert "not run" in result.output

    def test_legacy_state_without_phase8_does_not_crash(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A pre-#299 state.json (no phase8 key) renders cleanly."""
        import json as _json

        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        legacy = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "session_mode": "shared",
            "phase": 7,
        }
        (cg_dir / "state.json").write_text(_json.dumps(legacy), encoding="utf-8")

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Phase 8" in result.output
        assert "not run" in result.output

    def test_phase8_renders_in_multi_cycle(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Multi-cycle mode renders Phase 8 line for root state."""
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.phase8 = state_module.Phase8Progress(
            attempt=1,
            status="ok",
            started_at="2026-05-16T00:00:00Z",
            finished_at="2026-05-16T00:00:05Z",
        )
        st.cycles = [
            state_module.CycleState(
                id=1,
                name="Cycle 1",
                milestone_number=None,
                milestone_title="Cycle 1",
                status="completed",
                phase=7,
                issues=[],
                commit_sha=None,
            )
        ]
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Phase 8" in result.output
        assert "ok" in result.output


# ---------------------------------------------------------------------------
# Issue #321 — ci_status + professionalized N/M rendering
# ---------------------------------------------------------------------------


class TestPhase8CiStatusRendering:
    """``_render_phase8_state`` surfaces ``ci_status`` alongside attempt/status (#321)."""

    def _make_state_with_phase8(self, ci_status: str | None) -> state_module.State:
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.phase = 8
        st.phase8 = state_module.Phase8Progress(
            attempt=1,
            status="ok",
            ci_status=ci_status,
            started_at="2026-05-16T00:00:00Z",
            finished_at="2026-05-16T00:00:05Z",
        )
        return st

    def test_when_ci_status_green_then_ci_status_green_is_rendered(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        _write_state(cg_dir / "state.json", self._make_state_with_phase8("green"))

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Phase 8: status=ok, ci_status=green, attempt=1" in result.output

    def test_when_ci_status_exhausted_then_ci_status_exhausted_is_rendered(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        _write_state(cg_dir / "state.json", self._make_state_with_phase8("exhausted"))

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "ci_status=exhausted" in result.output

    def test_when_ci_status_skipped_then_ci_status_skipped_is_rendered(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        _write_state(cg_dir / "state.json", self._make_state_with_phase8("skipped"))

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "ci_status=skipped" in result.output

    def test_when_ci_status_none_then_dash_is_rendered(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        _write_state(cg_dir / "state.json", self._make_state_with_phase8(None))

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "ci_status=-" in result.output

    def test_when_legacy_phase8_lacks_ci_status_attr_then_no_crash(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Pre-Cycle-3 ``Phase8Progress`` objects (no ``ci_status`` attr) render cleanly."""
        from rich.console import Console as _RichConsole

        from code_generator.commands import status as status_module

        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)

        class _LegacyPhase8:
            attempt = 2
            status = "ok"

        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.phase8 = _LegacyPhase8()  # type: ignore[assignment]

        terminal_console = _RichConsole(record=True, width=200)
        status_module._render_phase8_state(terminal_console, st)
        output = terminal_console.export_text()

        assert "Phase 8" in output
        assert "ci_status=-" in output


class TestProfessionalizedSummaryRendering:
    """``status`` prints a ``professionalized: N/M`` line beside ``features: N/M`` (#321)."""

    def _seed_with_professionalized(
        self,
        project_dir: Path,
        requirements_hash: str,
        *,
        professionalized: int,
        total: int,
    ) -> None:
        from code_generator import checklist

        checklist_path = (
            project_dir / ".code-generator" / "checklists" / f"{requirements_hash}.json"
        )
        issues = [
            state_module.IssueState(number=n, status="open", agent="python-pro", title=f"Issue {n}")
            for n in range(1, total + 1)
        ]
        checklist.seed(checklist_path, issues)
        for n in range(1, professionalized + 1):
            checklist.tick_professionalized(checklist_path, n)

    def test_when_some_professionalized_then_count_over_total_rendered(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = "abcd1234"
        _write_state(cg_dir / "state.json", st)
        self._seed_with_professionalized(tmp_path, "abcd1234", professionalized=2, total=5)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "professionalized: 2/5" in result.output

    def test_when_zero_professionalized_then_zero_over_total_rendered(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = "abcd1234"
        _write_state(cg_dir / "state.json", st)
        self._seed_with_professionalized(tmp_path, "abcd1234", professionalized=0, total=4)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "professionalized: 0/4" in result.output

    def test_when_no_requirements_hash_then_dim_placeholder_rendered(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir(exist_ok=True)
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        st.requirements_hash = None
        _write_state(cg_dir / "state.json", st)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "professionalized: -" in result.output
