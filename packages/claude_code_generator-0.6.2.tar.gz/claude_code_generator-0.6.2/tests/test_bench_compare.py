"""Unit tests for bench compare subcommand.

Acceptance criteria (issue #194):
  - Two canned JSON files → table contains expected rows and signs.
  - Identical A and B → every Δ row is 0 and every Δ% is 0.0%.
  - Schema-version mismatch → exit 2 with specific error text.
  - cache_hit_pct row uses the inverse color rule (higher-is-better).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from code_generator.commands.bench_compare import (
    METRIC_DIRECTION,
    DeltaRow,
    compute_deltas,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_report(
    schema_version: int = 3,
    *,
    phase_overrides: dict[str, dict[str, float]] | None = None,
) -> dict:
    """Build a minimal bench report with eight identical phases."""
    base_metrics: dict[str, float] = {
        "input": 1000.0,
        "output": 100.0,
        "cache_read": 500.0,
        "cache_write": 200.0,
        "cache_hit_pct": 50.0,
        "wall_seconds": 2.0,
        "num_turns": 5.0,
        # v3 metrics (issue #248). 0.5 ratio matches the 50% cache_hit_pct above.
        "cache_write_5m": 0.0,
        "cache_write_1h": 200.0,
        "compaction_events": 0.0,
        "clear_events": 0.0,
        "cache_hit_ratio": 0.5,
    }
    phases = {str(p): dict(base_metrics) for p in range(8)}
    if phase_overrides:
        for phase_key, overrides in phase_overrides.items():
            phases[phase_key].update(overrides)

    return {
        "schema_version": schema_version,
        "timestamp_utc": "2026-01-01T00:00:00Z",
        "session_mode": "fresh",
        "fixture": "/fake/fixture",
        "cycles": [{"cycle_name": "cycle-1", "phases": phases, "totals": dict(base_metrics)}],
    }


# ---------------------------------------------------------------------------
# Test: two canned reports → expected rows and signs
# ---------------------------------------------------------------------------


class TestComputeDeltasWithCannedReports:
    """compute_deltas on two distinct reports produces correct rows and signs."""

    def test_positive_delta_has_plus_sign_in_direction_field(self) -> None:
        """When B.input > A.input, delta is positive (worsening for lower-better)."""
        a = _make_report(phase_overrides={"0": {"input": 1000.0}})
        b = _make_report(phase_overrides={"0": {"input": 1200.0}})

        rows = compute_deltas(a, b)
        row = next(r for r in rows if r.phase == 0 and r.metric == "input")

        assert row.delta == pytest.approx(200.0)
        assert row.a == pytest.approx(1000.0)
        assert row.b == pytest.approx(1200.0)
        assert row.direction == "lower-better"

    def test_negative_delta_has_minus_direction(self) -> None:
        """When B.input < A.input, delta is negative (improvement for lower-better)."""
        a = _make_report(phase_overrides={"0": {"input": 1000.0}})
        b = _make_report(phase_overrides={"0": {"input": 800.0}})

        rows = compute_deltas(a, b)
        row = next(r for r in rows if r.phase == 0 and r.metric == "input")

        assert row.delta == pytest.approx(-200.0)

    def test_delta_pct_computed_correctly(self) -> None:
        """delta_pct = (B - A) / A * 100."""
        a = _make_report(phase_overrides={"3": {"cache_read": 500.0}})
        b = _make_report(phase_overrides={"3": {"cache_read": 600.0}})

        rows = compute_deltas(a, b)
        row = next(r for r in rows if r.phase == 3 and r.metric == "cache_read")

        assert row.delta_pct == pytest.approx(20.0)

    def test_returns_8_phases_times_12_metrics(self) -> None:
        """Issue #248: v3 schema → 12 metrics per phase (7 v2 + 5 new)."""
        rows = compute_deltas(_make_report(), _make_report())
        assert len(rows) == 8 * 12

    def test_all_metrics_covered_in_rows(self) -> None:
        rows = compute_deltas(_make_report(), _make_report())
        metrics_in_rows = {r.metric for r in rows}
        assert metrics_in_rows == set(METRIC_DIRECTION.keys())


# ---------------------------------------------------------------------------
# Test: identical A and B → all deltas are zero
# ---------------------------------------------------------------------------


class TestIdenticalReports:
    """When A and B are identical, every delta is zero."""

    def test_all_delta_values_are_zero(self) -> None:
        report = _make_report()
        rows = compute_deltas(report, report)

        for row in rows:
            assert row.delta == pytest.approx(0.0), (
                f"Phase {row.phase} metric {row.metric}: expected delta=0, got {row.delta}"
            )

    def test_all_delta_pct_values_are_zero(self) -> None:
        report = _make_report()
        rows = compute_deltas(report, report)

        for row in rows:
            if row.a != 0.0:  # guard: pct is None when A=0
                assert row.delta_pct == pytest.approx(0.0), (
                    f"Phase {row.phase} metric {row.metric}: expected delta_pct=0.0, got {row.delta_pct}"
                )


# ---------------------------------------------------------------------------
# Test: schema-version mismatch → exit 2
# ---------------------------------------------------------------------------


class TestSchemaMismatch:
    """Schema-version mismatch between A and B triggers exit 2."""

    def test_schema_mismatch_raises_typer_exit_code_2(self, tmp_path: Path) -> None:
        from code_generator.cli import app

        a_file = tmp_path / "a.json"
        b_file = tmp_path / "b.json"
        # Pre-0.3.1 report (v1) vs current report (v3) must fail fast.
        a_file.write_text(json.dumps(_make_report(schema_version=1)), encoding="utf-8")
        b_file.write_text(json.dumps(_make_report(schema_version=3)), encoding="utf-8")

        runner = CliRunner()
        result = runner.invoke(app, ["bench", "compare", str(a_file), str(b_file)])

        assert result.exit_code == 2

    def test_schema_mismatch_outputs_error_text(self, tmp_path: Path) -> None:
        from code_generator.cli import app

        a_file = tmp_path / "a.json"
        b_file = tmp_path / "b.json"
        a_file.write_text(json.dumps(_make_report(schema_version=3)), encoding="utf-8")
        b_file.write_text(json.dumps(_make_report(schema_version=99)), encoding="utf-8")

        runner = CliRunner()
        result = runner.invoke(app, ["bench", "compare", str(a_file), str(b_file)])

        assert result.exit_code == 2
        # Typer CliRunner mixes stderr into output by default
        assert "schema_version" in result.output or "schema version" in result.output.lower()

    def test_matching_schema_version_exits_0(self, tmp_path: Path) -> None:
        from code_generator.cli import app

        a_file = tmp_path / "a.json"
        b_file = tmp_path / "b.json"
        a_file.write_text(json.dumps(_make_report(schema_version=3)), encoding="utf-8")
        b_file.write_text(json.dumps(_make_report(schema_version=3)), encoding="utf-8")

        runner = CliRunner()
        result = runner.invoke(app, ["bench", "compare", str(a_file), str(b_file)])

        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# Test: cache_hit_pct inverse color rule (higher-is-better)
# ---------------------------------------------------------------------------


class TestCacheHitPctColorRule:
    """cache_hit_pct uses the higher-is-better direction (inverse of other metrics)."""

    def test_cache_hit_pct_direction_is_higher_better(self) -> None:
        assert METRIC_DIRECTION["cache_hit_pct"] == "higher-better"

    def test_all_other_metrics_are_lower_better(self) -> None:
        higher_better_metrics = {"cache_hit_pct", "cache_hit_ratio"}
        for metric, direction in METRIC_DIRECTION.items():
            if metric not in higher_better_metrics:
                assert direction == "lower-better", (
                    f"Expected {metric!r} to be lower-better, got {direction!r}"
                )

    def test_improving_cache_hit_pct_row_has_positive_delta(self) -> None:
        """When B.cache_hit_pct > A.cache_hit_pct, delta is positive — an improvement."""
        a = _make_report(phase_overrides={"0": {"cache_hit_pct": 50.0}})
        b = _make_report(phase_overrides={"0": {"cache_hit_pct": 75.0}})

        rows = compute_deltas(a, b)
        row = next(r for r in rows if r.phase == 0 and r.metric == "cache_hit_pct")

        assert row.delta == pytest.approx(25.0)
        assert row.direction == "higher-better"

    def test_worsening_cache_hit_pct_row_has_negative_delta(self) -> None:
        """When B.cache_hit_pct < A.cache_hit_pct, delta is negative — a regression."""
        a = _make_report(phase_overrides={"0": {"cache_hit_pct": 75.0}})
        b = _make_report(phase_overrides={"0": {"cache_hit_pct": 50.0}})

        rows = compute_deltas(a, b)
        row = next(r for r in rows if r.phase == 0 and r.metric == "cache_hit_pct")

        assert row.delta == pytest.approx(-25.0)
        assert row.direction == "higher-better"


# ---------------------------------------------------------------------------
# Test: missing phase in one file
# ---------------------------------------------------------------------------


class TestMissingPhase:
    """Missing phase in one file → row with None values, no crash."""

    def test_missing_phase_in_b_produces_none_values(self) -> None:
        a = _make_report()
        b = _make_report()
        # Remove phase 5 from B
        del b["cycles"][0]["phases"]["5"]

        rows = compute_deltas(a, b)
        phase5_rows = [r for r in rows if r.phase == 5]

        assert len(phase5_rows) == 12  # 12 v3 metric rows, all with b=None
        for row in phase5_rows:
            assert row.b is None
            assert row.delta is None
            assert row.delta_pct is None

    def test_missing_phase_in_a_produces_none_values(self) -> None:
        a = _make_report()
        b = _make_report()
        del a["cycles"][0]["phases"]["2"]

        rows = compute_deltas(a, b)
        phase2_rows = [r for r in rows if r.phase == 2]

        for row in phase2_rows:
            assert row.a is None


# ---------------------------------------------------------------------------
# Test: DeltaRow is a frozen dataclass
# ---------------------------------------------------------------------------


class TestDeltaRowIsFrozen:
    def test_delta_row_is_immutable(self) -> None:
        row = DeltaRow(
            phase=0,
            metric="input",
            a=100.0,
            b=120.0,
            delta=20.0,
            delta_pct=20.0,
            direction="lower-better",
        )
        with pytest.raises((AttributeError, TypeError)):
            row.phase = 1  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Issue #212 — num_turns as a delta metric
# ---------------------------------------------------------------------------


class TestNumTurnsMetric:
    """num_turns is a lower-better delta metric, rendered per phase."""

    def test_num_turns_is_lower_better(self) -> None:
        assert METRIC_DIRECTION["num_turns"] == "lower-better"

    def test_num_turns_rows_appear_per_phase(self) -> None:
        """compute_deltas emits a num_turns row for every phase."""
        rows = compute_deltas(_make_report(), _make_report())
        num_turns_rows = [r for r in rows if r.metric == "num_turns"]
        assert len(num_turns_rows) == 8

    def test_num_turns_delta_matches_difference(self) -> None:
        """Δ for num_turns equals B - A when both sides carry the metric."""
        a = _make_report(phase_overrides={"3": {"num_turns": 10.0}})
        b = _make_report(phase_overrides={"3": {"num_turns": 17.0}})

        rows = compute_deltas(a, b)
        row = next(r for r in rows if r.phase == 3 and r.metric == "num_turns")

        assert row.a == pytest.approx(10.0)
        assert row.b == pytest.approx(17.0)
        assert row.delta == pytest.approx(7.0)


# ---------------------------------------------------------------------------
# Issue #248 — v3 metrics, .get tolerance, regression-warning threshold
# ---------------------------------------------------------------------------


class TestV3MetricDirections:
    """v3 metrics carry the right direction in METRIC_DIRECTION."""

    def test_cache_write_5m_is_lower_better(self) -> None:
        assert METRIC_DIRECTION["cache_write_5m"] == "lower-better"

    def test_cache_write_1h_is_lower_better(self) -> None:
        assert METRIC_DIRECTION["cache_write_1h"] == "lower-better"

    def test_compaction_events_is_lower_better(self) -> None:
        assert METRIC_DIRECTION["compaction_events"] == "lower-better"

    def test_clear_events_is_lower_better(self) -> None:
        assert METRIC_DIRECTION["clear_events"] == "lower-better"

    def test_cache_hit_ratio_is_higher_better(self) -> None:
        assert METRIC_DIRECTION["cache_hit_ratio"] == "higher-better"


class TestV3GetToleranceForLegacyReports:
    """``_build_row`` uses ``.get`` so v2 reports compared against v3 do not crash."""

    def test_legacy_report_missing_v3_metric_yields_none_a_value(self) -> None:
        legacy = _make_report()
        for phase_dict in legacy["cycles"][0]["phases"].values():
            for key in (
                "cache_write_5m",
                "cache_write_1h",
                "compaction_events",
                "clear_events",
                "cache_hit_ratio",
            ):
                phase_dict.pop(key, None)

        rows = compute_deltas(legacy, _make_report())
        ratio_row = next(r for r in rows if r.phase == 0 and r.metric == "cache_hit_ratio")

        assert ratio_row.a is None
        assert ratio_row.b == pytest.approx(0.5)
        assert ratio_row.delta is None


class TestCacheHitRatioRegressionWarnings:
    """``render_cache_hit_ratio_warnings`` emits one line per ≥5pp regression."""

    def _capture(self, a: dict, b: dict) -> str:
        from rich.console import Console

        from code_generator.commands.bench_compare import (
            compute_deltas,
            render_cache_hit_ratio_warnings,
        )

        console = Console(record=True, width=200, force_terminal=False)
        render_cache_hit_ratio_warnings(compute_deltas(a, b), console)
        return console.export_text()

    def test_regression_at_minus_five_pp_triggers_warning(self) -> None:
        a = _make_report(phase_overrides={"3": {"cache_hit_ratio": 0.80}})
        b = _make_report(phase_overrides={"3": {"cache_hit_ratio": 0.75}})

        out = self._capture(a, b)

        assert "WARNING: cache_hit_ratio regressed" in out
        assert "phase 3" in out

    def test_regression_smaller_than_five_pp_does_not_trigger_warning(self) -> None:
        a = _make_report(phase_overrides={"3": {"cache_hit_ratio": 0.800}})
        b = _make_report(phase_overrides={"3": {"cache_hit_ratio": 0.751}})  # -4.9pp

        out = self._capture(a, b)

        assert "WARNING" not in out

    def test_improvement_does_not_trigger_warning(self) -> None:
        a = _make_report(phase_overrides={"3": {"cache_hit_ratio": 0.50}})
        b = _make_report(phase_overrides={"3": {"cache_hit_ratio": 0.60}})

        out = self._capture(a, b)

        assert "WARNING" not in out

    def test_one_warning_per_offending_phase(self) -> None:
        a = _make_report(
            phase_overrides={
                "1": {"cache_hit_ratio": 0.80},
                "4": {"cache_hit_ratio": 0.70},
            }
        )
        b = _make_report(
            phase_overrides={
                "1": {"cache_hit_ratio": 0.74},
                "4": {"cache_hit_ratio": 0.50},
            }
        )

        out = self._capture(a, b)

        assert "phase 1" in out
        assert "phase 4" in out
        assert out.count("WARNING") == 2

    def test_compare_command_exits_zero_even_when_warning_fires(self, tmp_path: Path) -> None:
        from code_generator.cli import app

        a = _make_report(phase_overrides={"3": {"cache_hit_ratio": 0.80}})
        b = _make_report(phase_overrides={"3": {"cache_hit_ratio": 0.50}})  # -30pp

        a_file = tmp_path / "a.json"
        b_file = tmp_path / "b.json"
        a_file.write_text(json.dumps(a), encoding="utf-8")
        b_file.write_text(json.dumps(b), encoding="utf-8")

        runner = CliRunner()
        result = runner.invoke(app, ["bench", "compare", str(a_file), str(b_file)])

        assert result.exit_code == 0
        assert "WARNING" in result.output
