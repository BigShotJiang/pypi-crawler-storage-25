"""Tests for prompt prefix stability.

First 2048 bytes of each phase prompt must be byte-identical across renders
that vary only the volatile placeholder values. This ensures Anthropic's
prompt cache can reuse the prefix across same-phase sessions.
"""

from __future__ import annotations

import pytest

from code_generator.prompts import load_prompt

# Byte length that must remain stable (Anthropic cache granularity)
_PREFIX_BYTES = 2048

# ---------------------------------------------------------------------------
# Fixture sets — three renders per prompt, each varying ALL volatile placeholders.
# ---------------------------------------------------------------------------
_FIXTURES: dict[str, list[dict[str, str]]] = {
    "prompt-phase-0-complexity.md": [
        {"REPO_MAP": ""},
        {"REPO_MAP": "src/app.py::MyClass\n"},
        {"REPO_MAP": "src/api.py::Router\nsrc/models.py::User\n"},
    ],
    "prompt-phase-1-planning.md": [
        {
            "CYCLE_SPECIALIZED_PROMPT": "# Cycle 1 — Database\n\n## Objective\nBuild DB.\n",
            "CYCLE_SCOPE": "database layer",
            "MILESTONE_TITLE": "Cycle 1 — Database",
            "COMPLETED_CYCLES": "none",
            "EXISTING_ISSUES": "none",
            "REPO_MAP": "",
        },
        {
            "CYCLE_SPECIALIZED_PROMPT": (
                "# Cycle 2 — API\n\n## Objective\nExpose REST endpoints on top of the DB.\n"
            ),
            "CYCLE_SCOPE": "API layer with authentication",
            "MILESTONE_TITLE": "Cycle 2 — API",
            "COMPLETED_CYCLES": "Cycle 1 — Database (commit abc123)",
            "EXISTING_ISSUES": "- #1: feat: create user schema\n- #2: feat: add migrations",
            "REPO_MAP": "src/app.py::MyClass\n",
        },
        {
            "CYCLE_SPECIALIZED_PROMPT": (
                "# Cycle 3 — Frontend\n\n## Objective\nShip the Angular UI on top of the API.\n"
            ),
            "CYCLE_SCOPE": "frontend components, routing, signals",
            "MILESTONE_TITLE": "Cycle 3 — Frontend",
            "COMPLETED_CYCLES": "Cycle 1 — Database\nCycle 2 — API",
            "EXISTING_ISSUES": (
                "- #1: feat: create user schema\n"
                "- #2: feat: add migrations\n"
                "- #3: feat: add JWT auth"
            ),
            "REPO_MAP": "src/api.py::Router\nsrc/models.py::User\n",
        },
    ],
    "prompt-cycle-specializer.md": [
        {
            "REQUIREMENTS_CONTENT": "# App A\n\n## Description\nSmall project.",
            "CYCLES_JSON": '[{"id": 1, "name": "Foundation", "scope": "env", "depends_on": []}]',
        },
        {
            "REQUIREMENTS_CONTENT": (
                "# App B\n\n## Description\nLarger project with multiple layers."
            ),
            "CYCLES_JSON": (
                '[{"id": 1, "name": "DB", "scope": "schema", "depends_on": []},'
                ' {"id": 2, "name": "API", "scope": "endpoints", "depends_on": [1]}]'
            ),
        },
        {
            "REQUIREMENTS_CONTENT": "# App C\n\n## Description\nRich multi-cycle project.",
            "CYCLES_JSON": (
                '[{"id": 1, "name": "DB", "scope": "schema", "depends_on": []},'
                ' {"id": 2, "name": "API", "scope": "endpoints", "depends_on": [1]},'
                ' {"id": 3, "name": "UI", "scope": "angular", "depends_on": [2]}]'
            ),
        },
    ],
    "prompt-phase-2-batch-review.md": [
        {
            "ISSUES_JSON": '[{"issue_number": 1, "title": "t", "agent": "python-pro"}]',
            "REPO_MAP": "",
        },
        {
            "ISSUES_JSON": (
                '[{"issue_number": 42, "title": "feat: /api/users", "agent": "fastapi-expert"}]'
            ),
            "REPO_MAP": "src/app.py::MyClass\n",
        },
        {
            "ISSUES_JSON": (
                '[{"issue_number": 99, "title": "feat: login", "agent": "frontend-developer"},'
                ' {"issue_number": 100, "title": "feat: logout", "agent": "frontend-developer"}]'
            ),
            "REPO_MAP": "src/api.py::Router\nsrc/models.py::User\n",
        },
    ],
    "prompt-phase-3-implementation.md": [
        {
            "ISSUE_NUMBER": "7",
            "PRIMARY_AGENT": "python-pro",
            "SKILLS": "solid-principles,python-expert",
            "ISSUE_COMMENTS": "",
        },
        {
            "ISSUE_NUMBER": "100",
            "PRIMARY_AGENT": "fastapi-expert-agent",
            "SKILLS": "solid-principles",
            "ISSUE_COMMENTS": (
                "## Pre-fetched Issue Comments\n\n"
                "**reviewer** (2024-03-01T12:00:00Z):\n> Review OK: clear and testable."
            ),
        },
        {
            "ISSUE_NUMBER": "255",
            "PRIMARY_AGENT": "nestjs-expert",
            "SKILLS": "solid-principles,python-expert,skfolio",
            "ISSUE_COMMENTS": (
                "## Pre-fetched Issue Comments\n\n"
                "**alice** (2024-04-01T08:00:00Z):\n> First comment\n\n"
                "**bob** (2024-04-01T09:00:00Z):\n> Second comment with\n> multi-line\n> content"
            ),
        },
    ],
    "prompt-phase-5-final-review.md": [
        {
            "CYCLE_SCOPE": "the entire project",
            "MILESTONE_TITLE": "Cycle 1",
            "OPEN_ISSUES_WITH_COMMENTS": "none",
            "DIFF_SINCE_BASE": "",
            "LINT_ERRORS": "",
        },
        {
            "CYCLE_SCOPE": "database and API layers",
            "MILESTONE_TITLE": "Cycle 2 — API",
            "OPEN_ISSUES_WITH_COMMENTS": "### Issue #5: feat: add JWT auth\nComments: none",
            "DIFF_SINCE_BASE": "diff --git a/src/api.py b/src/api.py\n+++ new line",
            "LINT_ERRORS": "src/api.py:10:1 E501 line too long",
        },
        {
            "CYCLE_SCOPE": "frontend components",
            "MILESTONE_TITLE": "Cycle 3 — Frontend",
            "OPEN_ISSUES_WITH_COMMENTS": (
                "### Issue #10: feat: create login form\n"
                "Comments: Review OK\n\n"
                "### Issue #11: feat: add routing\n"
                "Comments: none"
            ),
            "DIFF_SINCE_BASE": (
                "diff --git a/src/app/login.component.ts b/src/app/login.component.ts\n"
            )
            * 30,
            "LINT_ERRORS": "",
        },
    ],
    "prompt-phase-6-test.md": [
        {"MAX_RETRIES": "1"},
        {"MAX_RETRIES": "3"},
        {"MAX_RETRIES": "10"},
    ],
    "prompt-phase-6-5-verify.md": [
        {
            "PROJECT_DIR": "/tmp/proj-a",
            "REQUIREMENTS_MD": ".code-generator/requirements.md",
            "DETECTED_STACK": "fastapi+sqlalchemy",
            "TIER_PLAN": "T0: pip install\nT1: uvicorn app.main:app --port 8000\nT2: GET /health 200",
            "FAILURE_REPORT": "",
            "ATTEMPT": "1",
            "MAX_RETRIES": "3",
            "ORACLE_REPORT": "(none)",
            "AGENT_SPEC_PATH": "/tmp/proj-a/.code-generator/phase6_5_spec.json",
            "TIERS_ACTIVE": "T0,T1,T2",
            "TIERS_SKIPPED": "T3 (no frontend), T4 (no docker)",
        },
        {
            "PROJECT_DIR": "/srv/proj-b",
            "REQUIREMENTS_MD": "spec/requirements.md",
            "DETECTED_STACK": "nestjs+prisma",
            "TIER_PLAN": "T0: npm run build\nT1: node dist/main.js (port 3000)\nT2: SKIP",
            "FAILURE_REPORT": "TIER 0: FAIL — TypeScript error TS2339 in src/foo.ts",
            "ATTEMPT": "2",
            "MAX_RETRIES": "3",
            "ORACLE_REPORT": "Global criteria:\n  - [T2] `GET /health` returns 200",
            "AGENT_SPEC_PATH": "/srv/proj-b/.code-generator/phase6_5_spec.json",
            "TIERS_ACTIVE": "T0,T1,T2,T4",
            "TIERS_SKIPPED": "T3 (no frontend)",
        },
        {
            "PROJECT_DIR": "/work/proj-c",
            "REQUIREMENTS_MD": "requirements.md",
            "DETECTED_STACK": "angular+vite",
            "TIER_PLAN": "T0: ng build\nT1: SKIP (frontend only)\nT2: SKIP",
            "FAILURE_REPORT": "TIER 1: FAIL — process exited after 0.4s with code 1",
            "ATTEMPT": "3",
            "MAX_RETRIES": "5",
            "ORACLE_REPORT": "Scope criteria:\n  - [T3] UI renders the dashboard",
            "AGENT_SPEC_PATH": "/work/proj-c/.code-generator/phase6_5_spec.json",
            "TIERS_ACTIVE": "T0,T3",
            "TIERS_SKIPPED": "T4 (no docker)",
        },
    ],
    "prompt-phase-7-commit.md": [
        {
            "CYCLE_NAME": "Cycle 1 — Foundation",
            "ISSUES_CLOSED": "#1, #2, #3",
            "STAGED_DIFF_STAT": "src/foo.py | 5 +++++\n1 file changed",
            "STAGED_FILES": "src/foo.py",
        },
        {
            "CYCLE_NAME": "Cycle 2 — API Layer",
            "ISSUES_CLOSED": "#4, #5, #6, #7, #8, #9",
            "STAGED_DIFF_STAT": (
                "src/api/routes.py | 120 +++++++++++++++\n"
                "tests/test_routes.py | 80 +++++++++\n"
                "2 files changed"
            ),
            "STAGED_FILES": "src/api/routes.py\ntests/test_routes.py",
        },
        {
            "CYCLE_NAME": "Cycle 3 — Frontend",
            "ISSUES_CLOSED": "#10, #11",
            "STAGED_DIFF_STAT": "frontend/src/app/app.component.ts | 200 " + "+" * 200,
            "STAGED_FILES": ("frontend/src/app/app.component.ts\nfrontend/src/app/app.module.ts"),
        },
    ],
    "prompt-review.md": [
        {"CREATE_ISSUES": "false", "SEVERITY_FILTER": "low"},
        {"CREATE_ISSUES": "true", "SEVERITY_FILTER": "medium"},
        {"CREATE_ISSUES": "false", "SEVERITY_FILTER": "critical"},
    ],
}

_ALL_PROMPTS = sorted(_FIXTURES.keys())


class TestPromptPrefixStability:
    """First 2048 rendered bytes must be byte-identical across volatile-varied renders."""

    @pytest.mark.parametrize("filename", _ALL_PROMPTS)
    def test_first_2048_bytes_identical_across_three_renders(self, filename: str) -> None:
        """Rendered prefix[0:2048] must be the same for all three fixture sets."""
        fixtures = _FIXTURES[filename]
        prefixes = [load_prompt(filename, **f).encode("utf-8")[:_PREFIX_BYTES] for f in fixtures]
        assert prefixes[0] == prefixes[1], (
            f"{filename}: prefix differs between fixture[0] and fixture[1]\n"
            f"  first diff at byte {_first_diff_byte(prefixes[0], prefixes[1])}"
        )
        assert prefixes[1] == prefixes[2], (
            f"{filename}: prefix differs between fixture[1] and fixture[2]\n"
            f"  first diff at byte {_first_diff_byte(prefixes[1], prefixes[2])}"
        )

    @pytest.mark.parametrize("filename", _ALL_PROMPTS)
    def test_rendered_output_is_at_least_2048_bytes(self, filename: str) -> None:
        """Rendered prompt must be at least 2048 bytes so the stable prefix is non-trivial."""
        rendered = load_prompt(filename, **_FIXTURES[filename][0])
        byte_len = len(rendered.encode("utf-8"))
        assert byte_len >= _PREFIX_BYTES, (
            f"{filename}: rendered length {byte_len} < {_PREFIX_BYTES} bytes"
        )

    @pytest.mark.parametrize("filename", _ALL_PROMPTS)
    def test_volatile_context_section_present(self, filename: str) -> None:
        """Every prompt must contain a '## Volatile Context' section."""
        rendered = load_prompt(filename, **_FIXTURES[filename][0])
        assert "## Volatile Context" in rendered, (
            f"{filename}: '## Volatile Context' section not found in rendered output"
        )

    @pytest.mark.parametrize("filename", _ALL_PROMPTS)
    def test_volatile_context_section_is_at_the_end(self, filename: str) -> None:
        """The '## Volatile Context' *section* (last occurrence) must appear after byte 2048.

        Prompts may reference '## Volatile Context' inline in their instructions;
        the test uses rfind() to locate the actual trailing section heading.
        """
        rendered = load_prompt(filename, **_FIXTURES[filename][0])
        encoded = rendered.encode("utf-8")
        volatile_pos = encoded.rfind(b"## Volatile Context")
        assert volatile_pos >= _PREFIX_BYTES, (
            f"{filename}: '## Volatile Context' section starts at byte {volatile_pos}, "
            f"which is before the {_PREFIX_BYTES}-byte boundary"
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _first_diff_byte(a: bytes, b: bytes) -> int:
    """Return the index of the first byte where *a* and *b* differ."""
    for i, (x, y) in enumerate(zip(a, b, strict=False)):
        if x != y:
            return i
    return min(len(a), len(b))
