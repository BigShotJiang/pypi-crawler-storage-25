"""Mechanical static-analysis scan of a project's public surface.

Produces a :class:`SurfaceReport` of entry points, CLI commands, HTTP routes,
and exported modules. Pure file-I/O + ``ast`` — no SDK calls, no subprocess,
no regex on source code. Consumed only by ``orchestrator/phase8_finalization``.

Detection sources:

- Python entry points: ``pyproject.toml`` ``[project.scripts]`` via ``tomllib``.
- Node entry points: ``package.json`` ``bin`` and ``scripts`` keys.
- CLI commands: any function whose decorator list contains a call to
  ``<name>.command(...)`` (covers Typer's ``@app.command()`` and Click's
  ``@click.command()`` patterns).
- HTTP routes: any function whose decorator list contains a call to
  ``<app|router>.<verb>(...)`` for verb in ``{get, post, put, patch, delete}``.
- Exported modules: top-level packages under each ``where`` entry of
  ``[tool.setuptools.packages.find]`` (or the flat layout when absent).
"""

from __future__ import annotations

import ast
import json
import logging
import tomllib
from dataclasses import dataclass, field
from pathlib import Path  # noqa: TC003  (runtime use in dataclasses + helpers)

_LOG = logging.getLogger(__name__)

_HTTP_VERBS: frozenset[str] = frozenset({"get", "post", "put", "patch", "delete"})
_ROUTE_DECORATOR_RECEIVERS: frozenset[str] = frozenset({"app", "router"})
_SKIP_DIR_NAMES: frozenset[str] = frozenset(
    {"__pycache__", "tests", ".venv", "venv", "node_modules"}
)


# ---------------------------------------------------------------------------
# Value objects
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class EntryPoint:
    name: str
    module: str
    script: str


@dataclass(slots=True)
class CliCommand:
    name: str
    source_path: Path


@dataclass(slots=True)
class ApiRoute:
    method: str
    path: str
    handler: str
    source_path: Path


@dataclass(slots=True)
class SurfaceReport:
    entry_points: list[EntryPoint] = field(default_factory=list)
    cli_commands: list[CliCommand] = field(default_factory=list)
    api_routes: list[ApiRoute] = field(default_factory=list)
    exported_modules: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def scan_surface(project_dir: Path) -> SurfaceReport:
    """Scan *project_dir* and return its public surface."""
    report = SurfaceReport()
    report.entry_points.extend(_scan_pyproject_scripts(project_dir))
    report.entry_points.extend(_scan_package_json(project_dir))
    modules, roots = _scan_exported_packages(project_dir)
    report.exported_modules.extend(modules)
    commands, routes = _scan_python_files(roots)
    report.cli_commands.extend(commands)
    report.api_routes.extend(routes)
    return report


# ---------------------------------------------------------------------------
# pyproject [project.scripts]
# ---------------------------------------------------------------------------


def _scan_pyproject_scripts(project_dir: Path) -> list[EntryPoint]:
    data = _load_pyproject(project_dir)
    if data is None:
        return []
    scripts = data.get("project", {}).get("scripts", {})
    return [_make_entry_point(name, target) for name, target in scripts.items()]


def _make_entry_point(name: str, target: str) -> EntryPoint:
    module = target.split(":", 1)[0] if ":" in target else target
    return EntryPoint(name=name, module=module, script=target)


def _load_pyproject(project_dir: Path) -> dict | None:
    path = project_dir / "pyproject.toml"
    if not path.exists():
        return None
    try:
        return tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError:
        _LOG.warning("pyproject.toml is not valid TOML — skipping")
        return None


# ---------------------------------------------------------------------------
# package.json bin/scripts
# ---------------------------------------------------------------------------


def _scan_package_json(project_dir: Path) -> list[EntryPoint]:
    path = project_dir / "package.json"
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        _LOG.warning("package.json is not valid JSON — skipping")
        return []
    return _entry_points_from_node(data.get("bin", {})) + _entry_points_from_node(
        data.get("scripts", {})
    )


def _entry_points_from_node(mapping: object) -> list[EntryPoint]:
    if not isinstance(mapping, dict):
        return []
    return [EntryPoint(name=k, module=v, script=v) for k, v in mapping.items()]


# ---------------------------------------------------------------------------
# Exported packages
# ---------------------------------------------------------------------------


def _scan_exported_packages(project_dir: Path) -> tuple[list[str], list[Path]]:
    data = _load_pyproject(project_dir)
    where_entries = _resolve_where(data)
    names: list[str] = []
    roots: list[Path] = []
    for entry in where_entries:
        base = (project_dir / entry).resolve()
        if not base.exists():
            continue
        for sub in sorted(base.iterdir()):
            if sub.is_dir() and (sub / "__init__.py").exists():
                names.append(sub.name)
                roots.append(sub)
    return names, roots


def _resolve_where(data: dict | None) -> list[str]:
    if data is None:
        return []
    find_cfg = data.get("tool", {}).get("setuptools", {}).get("packages", {}).get("find", {})
    where = find_cfg.get("where", [".", "src"]) if find_cfg else [".", "src"]
    return where if isinstance(where, list) else [where]


# ---------------------------------------------------------------------------
# Python AST walk — CLI commands + HTTP routes
# ---------------------------------------------------------------------------


def _scan_python_files(
    roots: list[Path],
) -> tuple[list[CliCommand], list[ApiRoute]]:
    commands: list[CliCommand] = []
    routes: list[ApiRoute] = []
    for path in _iter_python_files(roots):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except (SyntaxError, OSError, UnicodeDecodeError):
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                continue
            commands.extend(_extract_cli_commands(node, path))
            routes.extend(_extract_api_routes(node, path))
    return commands, routes


def _iter_python_files(roots: list[Path]) -> list[Path]:
    seen: set[Path] = set()
    results: list[Path] = []
    for root in roots:
        for path in root.rglob("*.py"):
            if any(part in _SKIP_DIR_NAMES for part in path.parts):
                continue
            resolved = path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            results.append(path)
    return results


def _extract_cli_commands(
    node: ast.FunctionDef | ast.AsyncFunctionDef, path: Path
) -> list[CliCommand]:
    out: list[CliCommand] = []
    for deco in node.decorator_list:
        call = _decorator_call(deco)
        if call is None or not _is_attribute_with(call.func, "command"):
            continue
        name = _string_arg(call) or node.name
        out.append(CliCommand(name=name, source_path=path))
    return out


def _extract_api_routes(node: ast.FunctionDef | ast.AsyncFunctionDef, path: Path) -> list[ApiRoute]:
    out: list[ApiRoute] = []
    for deco in node.decorator_list:
        call = _decorator_call(deco)
        if call is None:
            continue
        verb = _route_verb(call.func)
        if verb is None:
            continue
        out.append(
            ApiRoute(
                method=verb.upper(),
                path=_string_arg(call) or "",
                handler=node.name,
                source_path=path,
            )
        )
    return out


# ---------------------------------------------------------------------------
# AST helpers
# ---------------------------------------------------------------------------


def _decorator_call(node: ast.AST) -> ast.Call | None:
    return node if isinstance(node, ast.Call) else None


def _is_attribute_with(func: ast.AST, attr: str) -> bool:
    return isinstance(func, ast.Attribute) and func.attr == attr


def _route_verb(func: ast.AST) -> str | None:
    if not isinstance(func, ast.Attribute) or func.attr not in _HTTP_VERBS:
        return None
    if not isinstance(func.value, ast.Name) or func.value.id not in _ROUTE_DECORATOR_RECEIVERS:
        return None
    return func.attr


def _string_arg(call: ast.Call) -> str | None:
    if not call.args:
        return None
    first = call.args[0]
    if isinstance(first, ast.Constant) and isinstance(first.value, str):
        return first.value
    return None
