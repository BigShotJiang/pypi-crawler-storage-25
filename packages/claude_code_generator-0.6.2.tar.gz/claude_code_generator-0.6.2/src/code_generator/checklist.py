"""Feature completion checklist (issue #249, runtime-verified gate #270, Phase 8 gate #301).

Persists a JSON array of per-issue completion entries at
``.code-generator/checklists/<requirements_hash>.json``. Phase 1 seeds the
file; Phase 6 ticks ``tests_passed``; Phase 6.5 ticks ``runtime_verified``;
Phase 7 ticks ``committed``; Phase 8 ticks ``professionalized``;
``feature_done`` is derived
(``tests_passed AND runtime_verified AND committed AND professionalized``) so
the model cannot self-report completion and a failing runtime verification or
missing finalization blocks feature completion even when unit tests and
commit succeed.

All writes follow the ``tmp → os.replace(tmp, path)`` pattern so a crash
mid-write cannot corrupt the file. The module is orchestrator-only state —
the SDK runner has no Write access to ``.code-generator/checklists/``.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable
    from pathlib import Path

    from code_generator.state import IssueState

_logger = logging.getLogger(__name__)


@dataclass
class ChecklistEntry:
    """One row in the per-feature completion checklist."""

    issue_number: int
    title: str
    tests_passed: bool = False
    committed: bool = False
    feature_done: bool = False
    runtime_verified: bool = False
    professionalized: bool = False

    def recompute_feature_done(self) -> None:
        """Set ``feature_done`` from the four underlying flags (#270, #301)."""
        self.feature_done = (
            self.tests_passed and self.runtime_verified and self.committed and self.professionalized
        )


def seed(path: Path, issues: Iterable[IssueState]) -> None:
    """Atomically write the checklist for *issues* to *path* (idempotent).

    Re-seeding with the same data is a no-op (file content stays byte-identical).
    Re-seeding with new entries appends them while preserving any existing
    ticks on the entries already in the file.
    """
    new_entries = [_entry_from_issue(issue) for issue in issues]
    existing = {e.issue_number: e for e in load(path)}
    merged: list[ChecklistEntry] = []
    for fresh in new_entries:
        prior = existing.get(fresh.issue_number)
        merged.append(prior if prior is not None else fresh)
    _atomic_write_json(path, [asdict(e) for e in merged])


def load(path: Path) -> list[ChecklistEntry]:
    """Return the checklist entries; ``[]`` when the file is absent."""
    if not path.exists():
        return []
    raw = json.loads(path.read_text(encoding="utf-8"))
    return [_entry_from_dict(item) for item in raw]


def tick_tests_passed(path: Path, issue_number: int) -> None:
    """Set ``tests_passed=True`` on *issue_number*; recompute ``feature_done``."""
    _tick(path, issue_number, "tests_passed")


def tick_committed(path: Path, issue_number: int) -> None:
    """Set ``committed=True`` on *issue_number*; recompute ``feature_done``."""
    _tick(path, issue_number, "committed")


def tick_runtime_verified(path: Path, issue_number: int) -> None:
    """Set ``runtime_verified=True`` on *issue_number*; recompute ``feature_done``.

    Called by Phase 6.5 (runtime verification) after the tier loop succeeds.
    Gates ``feature_done`` together with ``tests_passed`` and ``committed`` (#270).
    """
    _tick(path, issue_number, "runtime_verified")


def tick_professionalized(path: Path, issue_number: int) -> None:
    """Set ``professionalized=True`` on *issue_number*; recompute ``feature_done``.

    Called by Phase 8 (finalization) after the per-issue finalization succeeds.
    Final gate of ``feature_done`` per #301.
    """
    _tick(path, issue_number, "professionalized")


def done_total(path: Path) -> tuple[int, int]:
    """Return ``(feature_done_count, total_entries)`` — used by ``status``."""
    entries = load(path)
    return sum(1 for e in entries if e.feature_done), len(entries)


def _tick(path: Path, issue_number: int, field: str) -> None:
    """Mutate *field* to True for *issue_number*; warn + no-op when missing."""
    entries = load(path)
    target = next((e for e in entries if e.issue_number == issue_number), None)
    if target is None:
        _logger.warning(
            "checklist tick: issue_number=%s not found in %s — no-op.",
            issue_number,
            path,
        )
        return
    setattr(target, field, True)
    target.recompute_feature_done()
    _atomic_write_json(path, [asdict(e) for e in entries])


def _entry_from_issue(issue: IssueState) -> ChecklistEntry:
    return ChecklistEntry(issue_number=issue.number, title=issue.title)


def _entry_from_dict(item: dict) -> ChecklistEntry:
    return ChecklistEntry(
        issue_number=int(item["issue_number"]),
        title=str(item.get("title", "")),
        tests_passed=bool(item.get("tests_passed", False)),
        committed=bool(item.get("committed", False)),
        feature_done=bool(item.get("feature_done", False)),
        runtime_verified=bool(item.get("runtime_verified", False)),
        professionalized=bool(item.get("professionalized", False)),
    )


def _atomic_write_json(path: Path, payload: list[dict]) -> None:
    """``tmp.write_text(...) → os.replace(tmp, path)`` atomic write."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp_path, path)
