"""Multi-stack project-manifest detection and atomic version mutation.

Pure file-I/O utility. No SDK calls, no subprocess. Consumed exclusively by
``orchestrator/phase8_finalization.py``. Detection order matches the canonical
stack list at ``prompts/prompt-phase-6-5-verify.md``:

    pyproject.toml → package.json → Cargo.toml → go.mod → angular.json → nest-cli.json

All writes go through :func:`_atomic_write` (``tmp → os.replace``) — identical
to ``state.save_state``.
"""

from __future__ import annotations

import json
import logging
import os
import re
import tomllib
from collections.abc import Callable  # noqa: TC003  (runtime use in dispatch tables)
from dataclasses import dataclass
from pathlib import Path  # noqa: TC003  (runtime use in dataclass + helpers)

_LOG = logging.getLogger(__name__)

# Stack order matters — do not reorder.
_STACK_ORDER: tuple[tuple[str, str], ...] = (
    ("pyproject.toml", "pyproject"),
    ("package.json", "package.json"),
    ("Cargo.toml", "Cargo.toml"),
    ("go.mod", "go.mod"),
    ("angular.json", "angular.json"),
    ("nest-cli.json", "nest-cli.json"),
)

_VERSION_LINE_RE = re.compile(r'(?m)^version\s*=\s*".*"')


# ---------------------------------------------------------------------------
# Value object
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ManifestMatch:
    """A single detected manifest file."""

    path: Path
    stack: str
    current_version: str


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def detect_manifests(project_dir: Path) -> list[ManifestMatch]:
    """Return matches in canonical stack order; empty list when none exist."""
    matches: list[ManifestMatch] = []
    for filename, stack in _STACK_ORDER:
        path = project_dir / filename
        if path.exists():
            matches.append(
                ManifestMatch(path=path, stack=stack, current_version=_read(path, stack))
            )
    return matches


def read_version(match: ManifestMatch) -> str:
    """Return the stored version; empty string for ``go.mod``."""
    return _read(match.path, match.stack)


def write_version(match: ManifestMatch, new_version: str) -> None:
    """Atomically write *new_version* into the manifest.

    No-op for ``go.mod`` (Go projects version via git tags, not the manifest).
    """
    writer = _WRITERS.get(match.stack)
    if writer is None:
        _LOG.info("write_version skipped — go.mod has no version slot")
        return
    writer(match.path, new_version)


# ---------------------------------------------------------------------------
# Per-stack readers
# ---------------------------------------------------------------------------


def _read(path: Path, stack: str) -> str:
    reader = _READERS.get(stack)
    if reader is None:
        return ""
    return reader(path)


def _read_pyproject(path: Path) -> str:
    data = tomllib.loads(path.read_text(encoding="utf-8"))
    project = data.get("project", {})
    if "version" in project:
        return project["version"]
    return data.get("tool", {}).get("poetry", {}).get("version", "")


def _read_cargo(path: Path) -> str:
    data = tomllib.loads(path.read_text(encoding="utf-8"))
    return data.get("package", {}).get("version", "")


def _read_json(path: Path) -> str:
    data = json.loads(path.read_text(encoding="utf-8"))
    return data.get("version", "")


# ---------------------------------------------------------------------------
# Per-stack writers
# ---------------------------------------------------------------------------


def _write_pyproject(path: Path, version: str) -> None:
    text = path.read_text(encoding="utf-8")
    new_text = _VERSION_LINE_RE.sub(f'version = "{version}"', text, count=1)
    _atomic_write(path, new_text)


def _write_cargo(path: Path, version: str) -> None:
    _write_pyproject(path, version)


def _write_json(path: Path, version: str) -> None:
    data = json.loads(path.read_text(encoding="utf-8"))
    data["version"] = version
    _atomic_write(path, json.dumps(data, indent=2))


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------


def _atomic_write(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


# ---------------------------------------------------------------------------
# Dispatch tables
# ---------------------------------------------------------------------------


_READERS: dict[str, Callable[[Path], str]] = {
    "pyproject": _read_pyproject,
    "Cargo.toml": _read_cargo,
    "package.json": _read_json,
    "angular.json": _read_json,
    "nest-cli.json": _read_json,
}

_WRITERS: dict[str, Callable[[Path, str], None]] = {
    "pyproject": _write_pyproject,
    "Cargo.toml": _write_cargo,
    "package.json": _write_json,
    "angular.json": _write_json,
    "nest-cli.json": _write_json,
}
