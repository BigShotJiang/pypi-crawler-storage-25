"""Conventional-Commit history → semver bump (pure, zero I/O).

Canonical source of truth for Phase 8's version bump. Consumed exclusively by
``orchestrator/phase8_finalization.py``. Reuses the conventional-commit regex
defined in ``orchestrator/phase7_commit.py`` — never redefine it.

Algorithm (semantic-release / release-please rules):

- ``feat`` → minor
- ``fix`` (and any other recognised type) → patch
- ``!`` in subject **or** ``BREAKING CHANGE:`` trailer → major
- empty commit list → none

Initial release: ``0.1.0`` when no prior tag exists.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Literal

from code_generator.orchestrator.phase7_commit import _CONVENTIONAL_COMMIT_RE

_LOG = logging.getLogger(__name__)

Bump = Literal["major", "minor", "patch", "none"]

_INITIAL_VERSION = "0.1.0"
_BREAKING_TRAILER = "BREAKING CHANGE:"


# ---------------------------------------------------------------------------
# Value object
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CommitClass:
    """A single classified commit."""

    sha: str
    subject: str
    type: str
    breaking: bool


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------


def parse_commits(lines: list[str]) -> list[CommitClass]:
    """Parse ``"<sha> <subject>"`` lines into :class:`CommitClass` objects.

    Non-conformant lines are skipped and logged at DEBUG. A *line* may contain
    embedded newlines (multi-line commit body); only the first line is matched
    as the subject. The full block is scanned for ``BREAKING CHANGE:`` trailers.
    """
    commits: list[CommitClass] = []
    for raw in lines:
        commit = _parse_one(raw)
        if commit is None:
            _LOG.debug("skipped non-conventional line: %r", raw)
            continue
        commits.append(commit)
    return commits


def _parse_one(raw: str) -> CommitClass | None:
    sha, block = _split_sha(raw)
    if sha is None:
        return None
    subject = block.split("\n", 1)[0]
    match = _CONVENTIONAL_COMMIT_RE.match(subject)
    if match is None:
        return None
    breaking = "!:" in match.group(0) or _BREAKING_TRAILER in block
    return CommitClass(sha=sha, subject=subject, type=match.group(1), breaking=breaking)


def _split_sha(raw: str) -> tuple[str | None, str]:
    parts = raw.split(" ", 1)
    if len(parts) < 2 or not parts[0]:
        return None, ""
    return parts[0], parts[1]


# ---------------------------------------------------------------------------
# Bump computation
# ---------------------------------------------------------------------------


def compute_bump(commits: list[CommitClass]) -> Bump:
    """Apply semantic-release rules to a commit list."""
    if not commits:
        return "none"
    if any(c.breaking for c in commits):
        return "major"
    if any(c.type == "feat" for c in commits):
        return "minor"
    return "patch"


# ---------------------------------------------------------------------------
# Version arithmetic
# ---------------------------------------------------------------------------


def next_version(current: str | None, bump: Bump) -> str:
    """Compute the next version from *current* and *bump*.

    When *current* is empty or ``None``, returns ``"0.1.0"`` regardless of bump.
    Accepts *current* with or without a leading ``v``.
    """
    if not current:
        return _INITIAL_VERSION
    major, minor, patch = _parse_version(current)
    if bump == "major":
        return f"{major + 1}.0.0"
    if bump == "minor":
        return f"{major}.{minor + 1}.0"
    if bump == "patch":
        return f"{major}.{minor}.{patch + 1}"
    return f"{major}.{minor}.{patch}"


def is_monotonic(new_ver: str, existing_tags: list[str]) -> bool:
    """Return ``False`` when *new_ver* is ``<=`` any tag in *existing_tags*."""
    new_tuple = _parse_version(new_ver)
    return all(new_tuple > _parse_version(tag) for tag in existing_tags)


def _parse_version(version: str) -> tuple[int, int, int]:
    stripped = version.removeprefix("v")
    parts = stripped.split(".")
    if len(parts) != 3:
        raise ValueError(f"invalid semver: {version!r}")
    return int(parts[0]), int(parts[1]), int(parts[2])
