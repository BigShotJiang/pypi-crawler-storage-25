"""Release-section generator for ``CHANGELOG.md``.

Keep-a-Changelog format. Idempotent under re-run (returns without writing when
the version header already exists). Consumed only by
``orchestrator/phase8_finalization.py``.

The generator groups commits by Conventional-Commit type:

- ``feat``       → **Features**
- ``fix``        → **Bug Fixes**
- ``refactor``   → **Refactor**
- *everything else* → **Chore**
- ``breaking=True`` (any type) → **Breaking Changes**

A *breaking* commit appears under both **Breaking Changes** and its
type-specific section, so the breaking nature is visible regardless of which
header the reader scans first.
"""

from __future__ import annotations

import os
from collections import OrderedDict
from datetime import UTC, date, datetime
from pathlib import Path  # noqa: TC003  (runtime use in update_changelog)

from code_generator.semver import CommitClass  # noqa: TC001  (runtime use in signatures)

_TITLE_LINE = "# Changelog"

_SECTION_ORDER: tuple[str, ...] = (
    "Breaking Changes",
    "Features",
    "Bug Fixes",
    "Refactor",
    "Chore",
)

_TYPE_TO_SECTION: dict[str, str] = {
    "feat": "Features",
    "fix": "Bug Fixes",
    "refactor": "Refactor",
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def format_section(version: str, commits: list[CommitClass]) -> str:
    """Return the markdown release section for *version*; ``""`` when empty."""
    if not commits:
        return ""
    grouped = _group_commits(commits)
    lines: list[str] = [f"## [v{version}] — {_today().isoformat()}"]
    for heading in _SECTION_ORDER:
        bucket = grouped.get(heading, [])
        if not bucket:
            continue
        lines.append("")
        lines.append(f"### {heading}")
        for c in bucket:
            lines.append(f"- {c.subject} ({c.sha[:7]})")
    return "\n".join(lines) + "\n"


def update_changelog(path: Path, version: str, commits: list[CommitClass]) -> None:
    """Atomically prepend the new release section.

    No-op when *commits* is empty or when ``## [v{version}]`` already appears
    in the existing file.
    """
    section = format_section(version, commits)
    if not section:
        return
    if path.exists():
        existing = path.read_text(encoding="utf-8")
        if f"## [v{version}]" in existing:
            return
        new_text = _prepend(existing, section)
    else:
        new_text = f"{_TITLE_LINE}\n\n{section}"
    _atomic_write(path, new_text)


# ---------------------------------------------------------------------------
# Date seam (patched in tests)
# ---------------------------------------------------------------------------


def _today() -> date:
    return datetime.now(UTC).date()


# ---------------------------------------------------------------------------
# Grouping
# ---------------------------------------------------------------------------


def _group_commits(commits: list[CommitClass]) -> OrderedDict[str, list[CommitClass]]:
    buckets: OrderedDict[str, list[CommitClass]] = OrderedDict(
        (name, []) for name in _SECTION_ORDER
    )
    for c in commits:
        if c.breaking:
            buckets["Breaking Changes"].append(c)
        section = _TYPE_TO_SECTION.get(c.type, "Chore")
        buckets[section].append(c)
    return buckets


# ---------------------------------------------------------------------------
# File assembly
# ---------------------------------------------------------------------------


def _prepend(existing: str, section: str) -> str:
    title_block, body = _split_title(existing)
    body = body.lstrip("\n")
    if body:
        return f"{title_block}\n{section}\n{body}"
    return f"{title_block}\n{section}"


def _split_title(content: str) -> tuple[str, str]:
    lines = content.split("\n")
    idx = next((i for i, line in enumerate(lines) if line.startswith("# ")), None)
    if idx is None:
        return f"{_TITLE_LINE}\n", content
    end = idx + 1
    if end < len(lines) and lines[end] == "":
        end += 1
    return "\n".join(lines[:end]), "\n".join(lines[end:])


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------


def _atomic_write(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)
