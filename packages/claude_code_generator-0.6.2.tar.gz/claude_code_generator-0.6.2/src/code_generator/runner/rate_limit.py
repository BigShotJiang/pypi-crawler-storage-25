"""Wait-and-resume main loop for the SDK/subprocess runner.

Implements non-negotiable #5: rate-limit handling is wait-and-resume,
not exponential backoff. Session IDs are preserved across pauses so
Claude can continue from where it left off.
"""

from __future__ import annotations

import asyncio
import time
from typing import TYPE_CHECKING

from code_generator import state as _state
from code_generator.runner.types import (
    ApiUpstreamError,
    OverageAbort,
    RateLimitHit,
    RunResult,
)

# Escalating backoff for upstream 5xx outages (seconds). Caps at 10 min.
# Never gives up — we keep looping until Anthropic recovers.
_UPSTREAM_BACKOFF_SECS: list[int] = [60, 120, 240, 480, 600]

# Maximum allowed pause duration (12 hours). Any paused_until further
# than this from now is clamped. Prevents unbounded sleep from clock
# skew or malformed API timestamps. (Section 14, part 2)
MAX_PAUSE_SECONDS = 12 * 3600  # 43200


# ---------------------------------------------------------------------------
# Ollama 429 handling (#221)
#
# Ollama's Pro daemon throttles with a plain HTTP 429 + ``Retry-After``
# header rather than Anthropic's structured ``RateLimitEvent``. These
# constants scope the Ollama codepath without touching the Anthropic one.
# ---------------------------------------------------------------------------

OLLAMA_DEFAULT_RETRY_AFTER_SECONDS = 60
"""Documented fallback wait when a 429 response omits the ``Retry-After`` header."""

OLLAMA_MAX_RETRY_AFTER_SECONDS = 4 * 3600  # 14400 (4 hours)
"""Upper bound on a ``Retry-After`` value to cap malformed / absurd responses."""

OLLAMA_RATE_LIMIT_TYPE = "ollama_429"
"""Stable identifier persisted on ``State.rate_limit_type`` for telemetry."""

# ---------------------------------------------------------------------------
# Codex usage-limit handling (#codex)
#
# The OpenAI Codex CLI has no dedicated rate-limit exit code; it emits a JSON
# ``error`` object (``type == "usage_limit_reached"`` with ``resets_at`` /
# ``resets_in_seconds``) or a 429 in stderr. The runner extracts the wait
# interval and feeds the same wait-and-resume path as Ollama.
# ---------------------------------------------------------------------------

CODEX_DEFAULT_RETRY_AFTER_SECONDS = 60
"""Documented fallback wait when a Codex usage-limit error omits its reset time."""

CODEX_MAX_RETRY_AFTER_SECONDS = 4 * 3600  # 14400 (4 hours)
"""Upper bound on a Codex reset interval to cap malformed / absurd values."""

CODEX_RATE_LIMIT_TYPE = "codex_429"
"""Stable identifier persisted on ``State.rate_limit_type`` for telemetry."""

if TYPE_CHECKING:
    import logging
    from collections.abc import Callable, Coroutine
    from pathlib import Path
    from typing import Any

    from code_generator.runner.protocol import RunnerProtocol


async def main_loop(
    runner: RunnerProtocol,
    prompt: str,
    options: Any,
    *,
    state_path: Path,
    logger: logging.Logger,
    now_fn: Callable[[], float] = time.time,
    sleep_fn: Callable[[float], Coroutine[Any, Any, None]] = asyncio.sleep,
) -> RunResult:
    """Execute the wait-and-resume loop until a result is obtained.

    On entry, checks whether state.json indicates an active pause and waits
    in ≤60-second chunks before attempting the run. On RateLimitHit, reloads
    the state (already updated by the runner) and waits again. On success,
    clears the pause and persists the updated state.

    Args:
        runner: Module or object with ``async run(prompt, options, ...)`` method.
        prompt: The prompt text to pass to the runner.
        options: Options object forwarded to the runner (permission_mode and
            resume will be set here as needed).
        state_path: Path to state.json for persistence.
        logger: Phase logger.
        now_fn: Callable returning current time (injectable for tests).
        sleep_fn: Async sleep callable (injectable for tests).

    Returns:
        RunResult from the first successful run.

    Raises:
        OverageAbort: When overage billing is detected by the runner.
    """
    await _wait_if_paused(state_path, logger, now_fn, sleep_fn)

    upstream_attempt = 0

    while True:
        # Resume from the last session if one was saved.
        st = _state.load_state(state_path)
        if st.session_id:
            # Defensive assignment in case options doesn't expose resume as a field.
            options.resume = st.session_id
        else:
            # Ensure no stale session ID leaks across calls (non-negotiable #6).
            options.resume = None

        try:
            result = await runner.run(
                prompt,
                options,
                logger=logger,
                state_path=state_path,
            )
        except RateLimitHit:
            # State was already updated by the runner before raising.
            # Wait until the pause clears, then retry. Upstream-error retries
            # are independent of rate-limit pauses, so reset the counter.
            upstream_attempt = 0
            logger.info("RateLimitHit received — waiting for rate-limit window to reset.")
            await _wait_if_paused(state_path, logger, now_fn, sleep_fn)
            continue
        except ApiUpstreamError as exc:
            delay = _UPSTREAM_BACKOFF_SECS[min(upstream_attempt, len(_UPSTREAM_BACKOFF_SECS) - 1)]
            upstream_attempt += 1
            logger.error(
                "Anthropic upstream error (%s). Sleeping %ds before retry (attempt %d).",
                exc,
                delay,
                upstream_attempt,
            )
            # Persist so a user inspecting state.json (or a resume after
            # crash) sees why we're idle.
            st = _state.load_state(state_path)
            st.last_error = f"upstream_5xx: {exc}"
            st.paused_until = int(now_fn() + delay)
            st.rate_limit_type = "upstream_5xx"
            _state.save_state(state_path, st)
            await sleep_fn(float(delay))
            # Clear the pause marker so _wait_if_paused doesn't double-wait
            # on the next iteration; a retry will re-set it if it fails again.
            st = _state.load_state(state_path)
            _state.clear_pause(st)
            st.rate_limit_type = None
            _state.save_state(state_path, st)
            continue
        except OverageAbort:
            # Non-negotiable #4 — overage never retries.
            raise

        # Success — clear the pause and persist.
        st = _state.load_state(state_path)
        _state.clear_pause(st)
        st.last_error = None
        st.rate_limit_type = None
        _state.save_state(state_path, st)
        return result


async def _wait_if_paused(
    state_path: Path,
    logger: logging.Logger,
    now_fn: Callable[[], float],
    sleep_fn: Callable[[float], Coroutine[Any, Any, None]],
) -> None:
    """Sleep in ≤60-second chunks while state indicates an active pause.

    Args:
        state_path: Path to state.json.
        logger: Phase logger.
        now_fn: Callable returning current time.
        sleep_fn: Async sleep callable.
    """
    st = _state.load_state(state_path)
    while True:
        now = now_fn()
        # Clamp unreasonable paused_until (Section 14, part 2).
        if st.paused_until is not None and st.paused_until > now + MAX_PAUSE_SECONDS:
            original = st.paused_until
            st.paused_until = int(now + MAX_PAUSE_SECONDS)
            _state.save_state(state_path, st)
            logger.warning(
                "paused_until clamped from %d to %d (MAX_PAUSE_SECONDS=%d).",
                original,
                st.paused_until,
                MAX_PAUSE_SECONDS,
            )
        if not _state.is_paused(st, now=now):
            break
        remaining = st.paused_until - now  # type: ignore[operator]
        chunk = min(60.0, max(0.0, remaining))
        logger.info(
            "Rate-limit pause active; sleeping %.1fs (%.1fs remaining).",
            chunk,
            remaining,
        )
        await sleep_fn(chunk)
        st = _state.load_state(state_path)


# ---------------------------------------------------------------------------
# Ollama 429 handler (#221)
#
# The Anthropic codepath raises ``RateLimitHit`` via
# ``message_parsing._handle_rejected_rate_limit``; the main loop already
# catches it and transparently waits + resumes (non-negotiable #5). The
# Ollama codepath feeds the same path, but the wait interval comes from an
# HTTP ``Retry-After`` header instead of ``RateLimitEvent.resets_at``.
# Callers do the HTTP extraction; this helper does the persistence + raise.
# ---------------------------------------------------------------------------


def handle_ollama_429(
    *,
    retry_after_seconds: int | None,
    session_id: str | None,
    state_path: Path,
    logger: logging.Logger,
    now_fn: Callable[[], float] = time.time,
) -> None:
    """Persist an Ollama 429 pause and raise :class:`RateLimitHit`.

    Mirrors non-negotiable #5 semantics — ``paused_until = now + wait + 60s``
    (safety buffer) — and preserves ``session_id`` so the main loop can set
    ``options.resume`` on retry. The raised :class:`RateLimitHit` carries
    ``rate_limit_type=OLLAMA_RATE_LIMIT_TYPE`` so telemetry and test code
    can distinguish this path from Anthropic rate-limit events.

    Args:
        retry_after_seconds: Integer seconds parsed from the HTTP
            ``Retry-After`` header. ``None`` when the header is absent or
            unparseable; negative values are treated as absent. Clamped to
            ``OLLAMA_MAX_RETRY_AFTER_SECONDS`` to guard against absurd
            server values.
        session_id: The Claude session id (may be ``None`` for the first
            request of a fresh session).
        state_path: Path to ``state.json`` for atomic persistence.
        logger: Phase logger used for fallback / clamp warnings.
        now_fn: Injectable clock (seconds since epoch). Defaults to
            ``time.time`` so tests can override it.

    Raises:
        RateLimitHit: Always — the caller (typically ``main_loop``) catches
            it and drives the wait-and-resume loop.
    """
    wait = _resolve_ollama_wait(retry_after_seconds, logger)
    now = now_fn()
    paused_until = int(now + wait + 60)

    st = _state.load_state(state_path)
    _state.mark_paused(
        st,
        resets_at=paused_until,
        rate_limit_type=OLLAMA_RATE_LIMIT_TYPE,
        session_id=session_id,
    )
    _state.save_state(state_path, st)
    raise RateLimitHit(paused_until, OLLAMA_RATE_LIMIT_TYPE)


def _resolve_ollama_wait(retry_after_seconds: int | None, logger: logging.Logger) -> int:
    """Return a sane wait interval, logging warnings for fallback/clamp cases."""
    if retry_after_seconds is None or retry_after_seconds < 0:
        logger.warning(
            "Ollama 429 response lacked a valid Retry-After header — falling back "
            "to %ds default wait.",
            OLLAMA_DEFAULT_RETRY_AFTER_SECONDS,
        )
        return OLLAMA_DEFAULT_RETRY_AFTER_SECONDS
    if retry_after_seconds > OLLAMA_MAX_RETRY_AFTER_SECONDS:
        logger.warning(
            "Ollama 429 Retry-After=%ds exceeds cap — clamping to %ds.",
            retry_after_seconds,
            OLLAMA_MAX_RETRY_AFTER_SECONDS,
        )
        return OLLAMA_MAX_RETRY_AFTER_SECONDS
    return retry_after_seconds


def handle_codex_429(
    *,
    retry_after_seconds: int | None,
    session_id: str | None,
    state_path: Path,
    logger: logging.Logger,
    now_fn: Callable[[], float] = time.time,
) -> None:
    """Persist a Codex usage-limit pause and raise :class:`RateLimitHit`.

    Mirrors :func:`handle_ollama_429` (and non-negotiable #5 semantics —
    ``paused_until = now + wait + 60s``) for the OpenAI Codex CLI codepath.
    The Codex runner extracts the wait interval from the JSON
    ``usage_limit_reached`` error (``resets_in_seconds``, or
    ``resets_at - now``) and passes it here; this helper does the atomic
    persistence + raise so ``main_loop`` drives the wait-and-resume loop.

    Args:
        retry_after_seconds: Seconds until the usage limit resets. ``None``
            (or negative) falls back to ``CODEX_DEFAULT_RETRY_AFTER_SECONDS``;
            values above ``CODEX_MAX_RETRY_AFTER_SECONDS`` are clamped.
        session_id: Always ``None`` for Codex (headless = stateless), kept
            for signature parity with :func:`handle_ollama_429`.
        state_path: Path to ``state.json`` for atomic persistence.
        logger: Phase logger used for fallback / clamp warnings.
        now_fn: Injectable clock (seconds since epoch).

    Raises:
        RateLimitHit: Always — the caller (typically ``main_loop``) catches
            it and drives the wait-and-resume loop.
    """
    wait = _resolve_codex_wait(retry_after_seconds, logger)
    now = now_fn()
    paused_until = int(now + wait + 60)

    st = _state.load_state(state_path)
    _state.mark_paused(
        st,
        resets_at=paused_until,
        rate_limit_type=CODEX_RATE_LIMIT_TYPE,
        session_id=session_id,
    )
    _state.save_state(state_path, st)
    raise RateLimitHit(paused_until, CODEX_RATE_LIMIT_TYPE)


def _resolve_codex_wait(retry_after_seconds: int | None, logger: logging.Logger) -> int:
    """Return a sane Codex wait interval, logging fallback/clamp cases."""
    if retry_after_seconds is None or retry_after_seconds < 0:
        logger.warning(
            "Codex usage-limit error lacked a valid reset time — falling back to %ds default wait.",
            CODEX_DEFAULT_RETRY_AFTER_SECONDS,
        )
        return CODEX_DEFAULT_RETRY_AFTER_SECONDS
    if retry_after_seconds > CODEX_MAX_RETRY_AFTER_SECONDS:
        logger.warning(
            "Codex reset interval=%ds exceeds cap — clamping to %ds.",
            retry_after_seconds,
            CODEX_MAX_RETRY_AFTER_SECONDS,
        )
        return CODEX_MAX_RETRY_AFTER_SECONDS
    return retry_after_seconds
