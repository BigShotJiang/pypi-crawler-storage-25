"""Subprocess fallback runner: shells out to the `claude` CLI.

Used when claude_agent_sdk is not importable. Spawns:
  claude -p <prompt> --output-format stream-json --verbose
         --dangerously-skip-permissions --model <model>
         --max-turns <n> --allowedTools <csv>

Non-negotiables: #1 (build_agent_env), #2 (never --bare).
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import subprocess
import time
from typing import TYPE_CHECKING, Any

from code_generator import env as _env
from code_generator import state as _state
from code_generator.runner.state_guard import protect_state_file

# Import shared types from the canonical module (DIP: depend on abstraction).
# Re-exported here so callers that previously imported from subprocess_runner
# continue to work without modification.
from code_generator.runner.types import (
    ApiUpstreamError,
    MaxTurnsExceeded,
    OverageAbort,
    RateLimitHit,
    RunResult,
    TokenUsage,
)
from code_generator.runner.utils import looks_like_upstream_5xx

if TYPE_CHECKING:
    import logging
    from pathlib import Path

# ---------------------------------------------------------------------------
# Model name translation map
# SDK uses full model IDs; the `claude` CLI may use short aliases.
# ---------------------------------------------------------------------------

_MODEL_ALIASES: dict[str, str] = {
    "claude-opus-4-7": "claude-opus-4-7",
    "claude-sonnet-4-6": "claude-sonnet-4-6",
    "claude-haiku-4-5": "claude-haiku-4-5",
}


def _translate_model(model: str | None) -> str:
    """Return the CLI model alias for a given SDK model name."""
    if model is None:
        return "claude-sonnet-4-6"
    return _MODEL_ALIASES.get(model, model)


# ---------------------------------------------------------------------------
# NDJSON line handlers
# ---------------------------------------------------------------------------


def _check_overage_status(data: dict[str, Any], proc: Any) -> None:
    """Kill the process and raise OverageAbort when overage billing is active.

    Non-negotiable #4: the subprocess path must enforce overage protection the
    same way the SDK runner does.

    Args:
        data: Parsed NDJSON system event dict.
        proc: The Popen process to kill before raising.

    Raises:
        OverageAbort: When overage_status is "allowed" or "allowed_warning".
    """
    overage_status = data.get("overage_status")
    if overage_status in ("allowed", "allowed_warning"):
        with contextlib.suppress(Exception):
            proc.kill()
        raise OverageAbort(
            f"Overage API billing active ({overage_status}) — aborting to avoid charges"
        )


def _parse_ndjson(line: str, logger: logging.Logger) -> dict[str, Any] | None:
    """Parse JSON from a raw NDJSON line; return None on failure."""
    try:
        return json.loads(line)
    except json.JSONDecodeError:
        logger.debug("Ignoring malformed NDJSON line: %r", line[:200])
        return None


def _check_upstream_5xx(text: str, proc: Any) -> None:
    """Kill proc and raise ApiUpstreamError if text contains an upstream 5xx signal."""
    if looks_like_upstream_5xx(text):
        with contextlib.suppress(Exception):
            proc.kill()
        raise ApiUpstreamError(f"CLI streamed upstream 5xx in assistant text: {text[:200]}")


def _handle_assistant(
    data: dict[str, Any],
    text_parts: list[str],
    logger: logging.Logger,
    proc: Any,
) -> None:
    """Extract text blocks from an assistant message, detect upstream 5xx."""
    message = data.get("message", {})
    for block in message.get("content", []):
        if block.get("type") == "text":
            text = block.get("text", "")
            text_parts.append(text)
            _check_upstream_5xx(text, proc)


def _handle_result(
    data: dict[str, Any],
    result_holder: dict[str, Any],
    logger: logging.Logger,
    proc: Any,
) -> None:
    """Capture session_id/tokens from a result message, detect is_error."""
    result_holder["session_id"] = data.get("session_id")
    raw = data.get("usage") or {}
    # num_turns lives on the NDJSON result envelope itself (alongside usage),
    # not inside the nested usage payload — mirror the SDK message shape.
    result_holder["usage"] = TokenUsage(
        input=raw.get("input_tokens", 0) or 0,
        output=raw.get("output_tokens", 0) or 0,
        cache_write=raw.get("cache_creation_input_tokens", 0) or 0,
        cache_read=raw.get("cache_read_input_tokens", 0) or 0,
        num_turns=data.get("num_turns", 0) or 0,
    )
    # Per Anthropic docs: max_turns exhaustion surfaces as subtype ==
    # "error_max_turns", NOT stop_reason == "max_turns". stop_reason is
    # the model's last stop reason (end_turn/max_tokens/refusal/tool_use)
    # and never indicates why the agent loop terminated.
    subtype = data.get("subtype")
    if subtype == "error_max_turns":
        with contextlib.suppress(Exception):
            proc.kill()
        logger.error(
            "MaxTurnsExceeded fired but no call site should set max_turns. "
            "Check for operator override (--max-turns), SDK/CLI default, "
            "or rogue fixture. num_turns=%s tokens_in=%s tokens_out=%s",
            data.get("num_turns"),
            result_holder["usage"].input,
            result_holder["usage"].output,
        )
        raise MaxTurnsExceeded(
            f"CLI session exhausted max_turns budget "
            f"(subtype={subtype}, num_turns={data.get('num_turns')}, "
            f"result={str(data.get('result', ''))[:200]})"
        )
    if data.get("is_error") is True:
        with contextlib.suppress(Exception):
            proc.kill()
        raise ApiUpstreamError(
            f"CLI reported result.is_error=True "
            f"(subtype={subtype}, stop_reason={data.get('stop_reason')}): "
            f"{str(data.get('result', ''))[:200]}"
        )


def _persist_rate_limit_pause(
    delay_ms: int,
    session_id: str | None,
    state_path: Path,
    proc: Any,
) -> None:
    """Save pause state, kill proc, and raise RateLimitHit for a long rate-limit."""
    # Non-negotiable #5: add 60-second safety buffer so the API window
    # has fully cleared before we attempt to resume.
    paused_until = int(time.time() + delay_ms / 1000 + 60)
    st = _state.load_state(state_path)
    _state.mark_paused(
        st, resets_at=paused_until, rate_limit_type="five_hour", session_id=session_id
    )
    _state.save_state(state_path, st)
    proc.kill()
    raise RateLimitHit(paused_until, "five_hour")


def _handle_rate_limit(
    data: dict[str, Any],
    logger: logging.Logger,
    state_path: Path,
    proc: Any,
) -> None:
    """Persist pause and raise RateLimitHit for large delays; log small ones."""
    delay_ms: int = data.get("retry_delay_ms", 0)
    session_id: str | None = data.get("session_id")
    if delay_ms > 120_000:
        _persist_rate_limit_pause(delay_ms, session_id, state_path, proc)
    else:
        logger.info("CLI rate-limit retry in %dms — letting CLI handle internally.", delay_ms)


def _handle_system(
    data: dict[str, Any],
    logger: logging.Logger,
    state_path: Path,
    proc: Any,
) -> None:
    """Delegate overage checks and handle api_retry rate-limit events."""
    _check_overage_status(data, proc)
    if data.get("subtype") == "api_retry" and data.get("error") == "rate_limit":
        _handle_rate_limit(data, logger, state_path, proc)


def _handle_line(
    line: str,
    text_parts: list[str],
    result_holder: dict[str, Any],
    logger: logging.Logger,
    state_path: Path,
    proc: Any,
) -> None:
    """Parse one NDJSON line and dispatch to the appropriate type handler.

    Args:
        line: A single JSON line from the CLI stdout.
        text_parts: Accumulator for assistant text fragments.
        result_holder: Dict capturing session_id and token counts.
        logger: Phase logger.
        state_path: Path to state.json for pause persistence.
        proc: The Popen process (so it can be killed on hard rate-limit).

    Raises:
        RateLimitHit: When retry_delay_ms exceeds 120_000 ms.
    """
    data = _parse_ndjson(line, logger)
    if data is None:
        return
    msg_type = data.get("type")
    if msg_type == "assistant":
        _handle_assistant(data, text_parts, logger, proc)
    elif msg_type == "result":
        _handle_result(data, result_holder, logger, proc)
    elif msg_type == "system":
        _handle_system(data, logger, state_path, proc)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def run(
    prompt: str,
    options: Any,
    *,
    logger: logging.Logger,
    state_path: Path,
) -> RunResult:
    """Spawn the Claude CLI and parse its stream-json output.

    Non-negotiable #1: uses build_agent_env() — no dangerous vars reach the CLI.
    Non-negotiable #2: --bare is never included; an assertion guards this.

    Args:
        prompt: The prompt text to pass via -p.
        options: Duck-typed options object with model, max_turns, allowed_tools, cwd.
        logger: Phase logger for debug/info/warning messages.
        state_path: Path to state.json for pause persistence.

    Returns:
        RunResult with accumulated text, session_id, and token counts.

    Raises:
        RateLimitHit: When retry_delay_ms > 120_000 in the stream.
    """
    model = _translate_model(getattr(options, "model", None))
    # Issue #207: no silent default. --max-turns is opt-in; omit the flag
    # entirely when the caller did not set it so the CLI runs without a cap,
    # matching the "no default turn budget" invariant.
    max_turns: int | None = getattr(options, "max_turns", None)
    allowed_tools: list[str] = getattr(options, "allowed_tools", [])
    cwd: str | None = getattr(options, "cwd", None)
    resume: str | None = getattr(options, "resume", None)

    argv: list[str] = [
        "claude",
        "-p",
        prompt,
        "--output-format",
        "stream-json",
        "--verbose",
        "--dangerously-skip-permissions",
        "--model",
        model,
    ]
    if max_turns is not None:
        argv += ["--max-turns", str(max_turns)]
    if allowed_tools:
        argv += ["--allowedTools", ",".join(allowed_tools)]
    if resume:
        argv += ["--resume", resume]

    # Plumb effort through to --output-config when explicitly set (Issue #68).
    effort = getattr(options, "effort", None)
    if effort:
        argv += ["--output-config", json.dumps({"effort": effort})]

    # Non-negotiable #2 — never pass --bare.
    assert "--bare" not in argv, "BUG: --bare must never appear in the claude CLI argv."

    # INVARIANT: any log line with model= must also have effort=
    effort_display = getattr(options, "effort", None) or "default"
    logger.info(
        "CLI session starting (model=%s effort=%s max_turns=%s).", model, effort_display, max_turns
    )

    # Detect Ollama mode so build_agent_env() preserves the scoped localhost
    # routing (ANTHROPIC_API_KEY="" + pinned BASE_URL). Without provider="ollama"
    # the default "anthropic-max" path omits ANTHROPIC_API_KEY, which causes
    # the CLI to reject non-Claude model tags or fall back to real credentials.
    _provider: _env.Provider = (
        "ollama"
        if _env._is_localhost_base_url(os.environ.get("ANTHROPIC_BASE_URL"))
        else "anthropic-max"
    )
    safe_env = _env.build_agent_env(provider=_provider)

    text_parts: list[str] = []
    result_holder: dict[str, Any] = {
        "session_id": None,
        "usage": TokenUsage(),
    }

    # Run subprocess in a thread to keep the coroutine non-blocking.
    def _run_subprocess() -> None:
        with subprocess.Popen(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=safe_env,
            cwd=cwd,
        ) as proc:
            assert proc.stdout is not None  # stdout=PIPE guarantees this
            for raw_line in proc.stdout:
                line = raw_line.decode(errors="replace").rstrip()
                if not line:
                    continue
                _handle_line(line, text_parts, result_holder, logger, state_path, proc)
        if proc.returncode not in (0, None):
            raise ApiUpstreamError(f"claude CLI exited with code {proc.returncode}")

    t0 = time.monotonic()
    with protect_state_file(state_path):
        await asyncio.to_thread(_run_subprocess)
    wall_seconds = time.monotonic() - t0

    return RunResult(
        text="".join(text_parts),
        session_id=result_holder["session_id"],
        usage=result_holder["usage"],
        wall_seconds=wall_seconds,
        # Subprocess fallback path does not surface SDK lifecycle events
        # (compaction / clear-tool-uses). Zeros are explicit so callers can
        # rely on the fields being present (issue #243).
        compaction_events=0,
        clear_events=0,
    )
