"""Single-roundtrip handler for the SDK's ``pause_after_compaction`` signal (issue #236).

When the §6 ``compact_20260112`` edit (issue #234) is configured with
``pause_after_compaction=True``, the SDK suspends generation immediately after
compaction and waits for the next user input.  Without an explicit handler the
model would resume on whatever happens to come next — losing the boundary
semantic that the legacy soft-reset path provided.

This module's job is intentionally narrow:

1. Receive a ``mark_pending()`` call when the runner detects a compaction-pause
   event in the message stream.
2. Hand back the §6 boundary user-message (sourced from
   :func:`runner.soft_reset.format_boundary` — never duplicated) on the next
   :meth:`consume` call.
3. Clear the pending flag immediately so a single mark produces exactly one
   boundary, regardless of how many times :meth:`consume` is invoked
   afterwards (single-roundtrip invariant).

The handler holds **no global state**.  Phase loops own their own instance and
plumb it through to ``run`` / ``run_with_shared_client``.  Older SDKs that
never emit the pause signal leave the handler not-pending — the predicate
:func:`runner.message_parsing.is_compaction_pause_event` returns ``False`` and
:meth:`consume` returns the prompt verbatim (silent no-op fallback).
"""

from __future__ import annotations

from code_generator.runner.soft_reset import format_boundary


class CompactionPauseHandler:
    """Holds the "boundary pending" flag for one phase's run-loop (issue #236).

    Single-roundtrip semantics: at most one boundary message is produced per
    :meth:`mark_pending` call, regardless of consumer count.  The pending flag
    is cleared inside :meth:`consume` before the boundary text is returned.
    """

    __slots__ = ("_pending",)

    def __init__(self) -> None:
        self._pending = False

    def mark_pending(self) -> None:
        """Mark a pause event observed; the next :meth:`consume` will prepend the boundary."""
        self._pending = True

    def is_pending(self) -> bool:
        """Return whether a boundary prepend is pending for the next outgoing prompt."""
        return self._pending

    def consume(self, prompt: str, *, issue_number: int) -> str:
        """Return *prompt* unchanged when not pending; prepend the §6 boundary when pending.

        Clears the pending flag in either branch — single-roundtrip invariant.

        Args:
            prompt: The outgoing prompt text the caller is about to send.
            issue_number: Issue number for the boundary user-message
                (``Starting issue #N fresh``).

        Returns:
            The original prompt, optionally prefixed with the boundary text.
        """
        if not self._pending:
            return prompt
        self._pending = False
        return format_boundary(issue_number) + prompt
