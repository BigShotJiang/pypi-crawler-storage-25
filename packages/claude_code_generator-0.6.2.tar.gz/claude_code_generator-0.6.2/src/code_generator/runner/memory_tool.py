"""Client-side memory tool for the SDK ``memory_20250818`` beta (issue #237).

Subclasses :class:`claude_agent_sdk.BetaAbstractMemoryTool` and routes every
persistence callback through :mod:`code_generator.memory` so:

* The atomic ``tmp → os.replace`` invariant (non-negotiable #7) is reused.
* Path-traversal validation lives in **one** place
  (:func:`memory._validated_path`) — never duplicated here.
* Per-cycle scoping is enforced by rooting writes at
  ``<memories_dir>/<cycle_id>/`` so the model's reads/writes cannot escape
  the current cycle's history.

The SDK abstract base may not be importable on every install (older
``claude-agent-sdk`` versions ship without it). The import is wrapped in a
``try/except ImportError`` and the factory :func:`build_cycle_memory_tool`
returns ``None`` on the fallback path with a one-shot ``INFO`` log so callers
can degrade gracefully to the legacy file-write flow.

Tool name registered with the SDK is exactly ``"memory"`` — must match the
``exclude_tools`` entry in :func:`runner.options.build_context_management_block`
(issue #234).
"""

from __future__ import annotations

import contextlib
import logging
from typing import TYPE_CHECKING

from code_generator.memory import (
    overwrite_memory_file,
    read_memory_file,
)

if TYPE_CHECKING:
    from pathlib import Path

_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# SDK base import (guarded) — review comment #1 on issue #237.
# ---------------------------------------------------------------------------

try:
    from claude_agent_sdk import BetaAbstractMemoryTool as _MemoryToolBase  # type: ignore

    _SDK_AVAILABLE = True
except ImportError:  # pragma: no cover — branch exercised via monkeypatch
    _MemoryToolBase = object  # type: ignore[assignment,misc]
    _SDK_AVAILABLE = False


# Per-process latch so the SDK-absent fallback INFO log is emitted exactly once
# (mirrors ``options._warned_features`` pattern).
_FALLBACK_LOGGED = False


# ---------------------------------------------------------------------------
# Cycle-id sanitisation
# ---------------------------------------------------------------------------


_CYCLE_ID_FORBIDDEN = ("/", "\\", "\0", "..")


def _validate_cycle_id(cycle_id: str) -> None:
    """Reject *cycle_id* values that could escape the memories directory.

    The cycle id becomes a path component (``<memories_dir>/<cycle_id>/``),
    so any value that would let the model break out of the cycle root must
    be refused at construction time — before any I/O is attempted.

    Rejects:
        * empty string
        * leading dot (``.hidden``, ``..stillbad``)
        * path separators (``/``, ``\\``)
        * null byte
        * literal ``..`` segment

    Raises:
        ValueError: When *cycle_id* matches any of the above patterns.
    """
    if not cycle_id:
        raise ValueError("cycle_id must be non-empty")
    if cycle_id.startswith("."):
        raise ValueError(f"cycle_id {cycle_id!r} must not start with '.'")
    for token in _CYCLE_ID_FORBIDDEN:
        if token in cycle_id:
            raise ValueError(f"cycle_id {cycle_id!r} contains forbidden token {token!r}")


# ---------------------------------------------------------------------------
# CycleMemoryTool — subclasses BetaAbstractMemoryTool when SDK is present.
# ---------------------------------------------------------------------------


class CycleMemoryTool(_MemoryToolBase):  # type: ignore[misc, valid-type]
    """Per-cycle memory-tool subclass that routes persistence through ``memory.py``.

    All file paths the SDK passes to the callbacks are interpreted as relative
    to ``<memories_dir>/<cycle_id>/``. :func:`memory._validated_path` rejects
    any path that escapes that root with :class:`ValueError` (single source of
    traversal validation — review comment #2 on issue #237).
    """

    name = "memory"

    def __init__(self, memories_dir: Path, cycle_id: str) -> None:
        _validate_cycle_id(cycle_id)
        self._root: Path = memories_dir / cycle_id
        if _SDK_AVAILABLE:
            # SDK base may take arguments in some pre-release versions; suppress
            # TypeError so attribute-only construction still works in unit tests
            # without a real SDK session.
            with contextlib.suppress(TypeError):
                super().__init__()

    # -- SDK callbacks -------------------------------------------------------
    #
    # Anthropic memory tool commands (Jan 2026 spec):
    # ``view`` / ``create`` / ``str_replace`` / ``insert`` / ``delete``.
    # Each callback delegates to memory.py — never re-implements traversal,
    # atomicity, or directory creation.

    def create(self, path: str, file_text: str = "") -> None:
        """Atomically create or overwrite *path* with *file_text*."""
        overwrite_memory_file(self._root, path, file_text)

    def view(self, path: str) -> str:
        """Return the content of *path*; empty string when the file is absent."""
        return read_memory_file(self._root, path)

    def delete(self, path: str) -> None:
        """Atomically clear *path* to an empty file (preserves traversal validation)."""
        overwrite_memory_file(self._root, path, "")

    def str_replace(self, path: str, old_str: str, new_str: str) -> None:
        """Replace *old_str* with *new_str* in *path* and atomically rewrite."""
        existing = read_memory_file(self._root, path)
        if old_str not in existing:
            raise ValueError(f"str_replace: substring not found in {path!r}")
        overwrite_memory_file(self._root, path, existing.replace(old_str, new_str))

    def insert(self, path: str, insert_line: int, insert_text: str) -> None:
        """Insert *insert_text* before *insert_line* (0-indexed) in *path*."""
        existing = read_memory_file(self._root, path)
        lines = existing.splitlines(keepends=True)
        idx = max(0, min(insert_line, len(lines)))
        rebuilt = "".join(lines[:idx]) + insert_text + "".join(lines[idx:])
        overwrite_memory_file(self._root, path, rebuilt)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def is_memory_tool_available() -> bool:
    """Return True iff the SDK exposes ``BetaAbstractMemoryTool`` (issue #238 gate).

    Used by ``cycle_loop`` to decide whether the model owns cross-issue
    knowledge through the memory tool (skip orchestrator-side
    ``cycle-summary.md`` writes) or whether the legacy file-write flow must
    still run as fallback (review-comment #c on issue #238 — no resume gap on
    a mid-cycle memory-tool failure).
    """
    return _SDK_AVAILABLE


def build_cycle_memory_tool(memories_dir: Path, cycle_id: str) -> CycleMemoryTool | None:
    """Return a :class:`CycleMemoryTool` when the SDK base is available; ``None`` otherwise.

    Logs a one-shot ``INFO`` line on the SDK-absent path so operators see why
    the memory tool degraded to the legacy file-write flow (review comment #1
    on issue #237). Callers MUST handle the ``None`` return value — typically
    by falling back to direct ``memory.overwrite_memory_file`` calls.
    """
    global _FALLBACK_LOGGED  # noqa: PLW0603
    if not _SDK_AVAILABLE:
        if not _FALLBACK_LOGGED:
            _FALLBACK_LOGGED = True
            _logger.info(
                "memory tool unavailable: claude_agent_sdk lacks BetaAbstractMemoryTool. "
                "Falling back to legacy file-write flow."
            )
        return None
    return CycleMemoryTool(memories_dir, cycle_id)
