"""Runner package — SDK runner with subprocess fallback.

Factory function `get_runner()` selects the SDK runner when
`claude_agent_sdk` is importable, otherwise falls back to the subprocess
runner that shells out to the `claude` CLI.

All shared types are also re-exported here for convenience.
"""

from __future__ import annotations

from code_generator import env as _env  # noqa: TC001  (runtime use: get_runner annotation)
from code_generator.runner.protocol import RunnerProtocol
from code_generator.runner.types import (
    ApiUpstreamError,
    MaxTurnsExceeded,
    OverageAbort,
    RateLimitHit,
    RunResult,
    TokenUsage,
    TransientRunnerError,
)

__all__ = [
    "ApiUpstreamError",
    "MaxTurnsExceeded",
    "OverageAbort",
    "RateLimitHit",
    "RunResult",
    "RunnerProtocol",
    "TokenUsage",
    "TransientRunnerError",
    "get_runner",
]


def get_runner(provider: _env.Provider = "anthropic-max") -> RunnerProtocol:
    """Return the appropriate runner module for the given provider.

    Args:
        provider: The provider to get the runner for.

    Returns:
        The runner module satisfying RunnerProtocol.
    """
    if provider == "codex":
        from . import codex_runner

        return codex_runner  # type: ignore[return-value]

    if provider == "gemini":
        from . import gemini_runner

        return gemini_runner  # type: ignore[return-value]

    try:
        import claude_agent_sdk  # noqa: F401

        from . import sdk_runner

        return sdk_runner  # type: ignore[return-value]
    except ImportError:
        from . import subprocess_runner

        return subprocess_runner  # type: ignore[return-value]
