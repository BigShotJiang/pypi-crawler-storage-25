"""§8 four-breakpoint ``cache_control`` layout (issue #239).

Anthropic prompt-cache breakpoints flag the boundary at which the cached
prefix ends. The §8 spec pins exactly four breakpoints per shared-client
request, in this order:

* **BP1 — tools.** Catches the SDK tool definitions; stable across the entire
  cycle.
* **BP2 — base system prompt.** Catches the ``claude_code`` preset
  (``exclude_dynamic_sections=True`` so the prefix bytes stay byte-identical
  across sessions).
* **BP3 — cycle-repo-map + cycle-specialized prompt.** Catches the graphify
  ``cycle-repo-map.md`` content and the per-cycle prompt produced by
  :mod:`orchestrator.cycle_prompts` (Cycle 2). Both contents share one
  marker placed at the LAST of the two so both sit inside the cached prefix.
* **BP4 — last stable boundary user-message.** Catches the issue-boundary
  text from :func:`runner.soft_reset.format_boundary` so the response side
  of the next turn warms up against a stable user message.

The volatile current-request body MUST NOT carry a marker — re-marking it
would reset the cached prefix on every request.

The 20-block lookback rule guards against a runaway prompt structure: no
breakpoint may sit more than 20 blocks past its predecessor.

This module is **layout + ordering only** — TTL assignment (BP1/BP2/BP3=1h,
BP4=5m) lives in issue #240 and the cache pre-warm in issue #241.

Open question (issue body): the SDK ``ClaudeAgentOptions.cache_control``
field currently accepts a single ``dict``. SDK 0.1.65 has no per-block
marker API. ``_build_cycle_options`` exposes the layout as a post-init
attribute (``options.cache_breakpoints``) so when the SDK ships per-block
support the field becomes the single source of truth; until then the
top-level single ``cache_control`` dict (issue #234's default) provides the
cache backstop and a one-shot WARNING flags the degraded path.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, cast

if TYPE_CHECKING:
    from collections.abc import Iterable

# ---------------------------------------------------------------------------
# Public constants
# ---------------------------------------------------------------------------

#: Cardinality of the §8 breakpoint layout. Anthropic permits a maximum of 4
#: cache breakpoints per request; this layout uses every slot.
CACHE_BREAKPOINT_COUNT = 4

#: Maximum block-distance allowed between consecutive breakpoints. Anthropic
#: extends the cached prefix backwards from each marker; gaps larger than 20
#: blocks risk the cache lookup missing the prior marker entirely.
MAX_LOOKBACK_BLOCKS = 20

#: Default cache_control applied to every breakpoint when ``build_cache_breakpoints``
#: is called without ``ttls=`` and without ``cache_control=``. ``ephemeral 1h``
#: matches the §9 default for BP1/BP2/BP3.
_DEFAULT_CACHE_CONTROL: dict[str, str] = {"type": "ephemeral", "ttl": "1h"}

#: Per-BP TTL tuple keyed by SDK probe outcome (issue #240). The probe lives
#: in ``runner.options.probe_cache_ttl_support``; this map keeps the §9 policy
#: in one place so callers never re-derive it.
_TTLS_BY_PROBE: dict[str, tuple[str, str, str, str]] = {
    "1h": ("1h", "1h", "1h", "5m"),
    "5m": ("5m", "5m", "5m", "5m"),
}


# ---------------------------------------------------------------------------
# Value object
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CacheBreakpoint:
    """One ordered cache_control marker in the §8 layout.

    Attributes:
        name: Stable canonical identifier (``BP1_tools``, ``BP2_system``,
            ``BP3_repo_map_and_cycle_prompt``, ``BP4_boundary_user``). Tests
            and TTL assignment in #240 key off this string.
        block_index: Zero-based absolute index in the request block list at
            which the marker is placed. Anthropic extends the cached prefix
            backwards from this position.
        cache_control: The ``cache_control`` dict carried by the marker. TTL
            assignment is uniform here (issue #240 splits BP1/2/3=1h vs
            BP4=5m).
    """

    name: str
    block_index: int
    cache_control: dict


# Canonical order constants — kept out of the public API since callers should
# read them via the returned list, but exposed for tests to assert on.
_BP_NAMES: tuple[str, ...] = (
    "BP1_tools",
    "BP2_system",
    "BP3_repo_map_and_cycle_prompt",
    "BP4_boundary_user",
)


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------


def resolve_active_ttl(state: Any, cycle: Any, *, bp_index: int) -> Literal["1h", "5m"]:
    """Return the active TTL (``"1h"`` or ``"5m"``) for *bp_index* (issue #245).

    Looks up ``cycle.cache_ttl_probe`` (preferred — set on the active cycle by
    ``managed_shared_client``) then falls back to ``state.cache_ttl_probe``
    (single-mode runs without a CycleState). When neither is set the helper
    returns ``"1h"`` — the longer-TTL-first invariant: a missing probe
    must never silently mis-classify a write to the 5m bucket during an
    upgrade window.

    Args:
        state: Root :class:`State` (or duck-typed equivalent) — read for the
            single-mode fallback when *cycle* is ``None`` / has no probe.
        cycle: Active :class:`CycleState` (or duck-typed equivalent), or
            ``None`` for single-mode runs.
        bp_index: Zero-based index into the canonical BP1→BP4 tuple. Must
            be in ``[0, 3]``.

    Returns:
        The TTL string for the requested breakpoint.

    Raises:
        ValueError: When *bp_index* is outside ``[0, 3]``.
    """
    if not 0 <= bp_index < CACHE_BREAKPOINT_COUNT:
        raise ValueError(
            f"bp_index {bp_index} out of range; expected 0..{CACHE_BREAKPOINT_COUNT - 1}"
        )
    probe = getattr(cycle, "cache_ttl_probe", None) if cycle is not None else None
    if probe is None:
        probe = getattr(state, "cache_ttl_probe", None)
    # Longer-TTL-first invariant: when no probe data is recorded, assume the
    # canonical "1h" probe layout — BP1/BP2/BP3="1h", BP4="5m". Defaulting all
    # BPs to "1h" would mis-classify BP4 writes (BP4 is always 5m by spec).
    effective = cast("Literal['1h', '5m']", probe if probe is not None else "1h")
    return resolve_ttls(effective)[bp_index]


def resolve_ttls(
    probe_result: str,
) -> tuple[Literal["1h", "5m"], Literal["1h", "5m"], Literal["1h", "5m"], Literal["1h", "5m"]]:
    """Return the §9 per-BP TTL tuple for *probe_result* (issue #240).

    The probe lives in :func:`runner.options.probe_cache_ttl_support` and
    returns either ``"1h"`` (extended-cache-ttl beta accepted) or ``"5m"``
    (beta rejected, uniform fallback). Both outcomes resolve to a 4-tuple
    matching BP1/BP2/BP3/BP4 in canonical order so the resulting layout
    never violates the longer-TTL-first invariant.

    Args:
        probe_result: ``"1h"`` or ``"5m"`` — the only outcomes
            ``probe_cache_ttl_support`` returns.

    Returns:
        A 4-tuple ``(BP1_ttl, BP2_ttl, BP3_ttl, BP4_ttl)``. Probe ``"1h"``
        → ``("1h", "1h", "1h", "5m")``; probe ``"5m"`` → uniform
        ``("5m", "5m", "5m", "5m")``.

    Raises:
        ValueError: When *probe_result* is neither ``"1h"`` nor ``"5m"``.
    """
    if probe_result not in _TTLS_BY_PROBE:
        raise ValueError(f"probe result {probe_result!r} is not supported (expected '1h' or '5m')")
    return cast(
        "tuple[Literal['1h', '5m'], Literal['1h', '5m'], Literal['1h', '5m'], Literal['1h', '5m']]",
        _TTLS_BY_PROBE[probe_result],
    )


def build_cache_breakpoints(
    *,
    tools_block_index: int,
    system_block_index: int,
    repo_map_block_index: int,
    cycle_prompt_block_index: int | None,
    boundary_user_block_index: int,
    cache_control: dict | None = None,
    ttls: tuple[str, str, str, str] | None = None,
) -> list[CacheBreakpoint]:
    """Return the §8 four-breakpoint layout in BP1→BP4 order (issues #239 + #240).

    BP3 covers two contents (``cycle-repo-map.md`` + cycle-specialized prompt)
    with a single marker placed at the LAST of the two block indices so both
    contents fall inside the cached prefix. When the cycle-specialized prompt
    is absent (Cycle 2 not yet merged), BP3 falls back to the repo-map block
    index — never silently drops to three breakpoints.

    Args:
        tools_block_index: Position of the SDK tool-definitions block.
        system_block_index: Position of the base ``claude_code`` system prompt.
        repo_map_block_index: Position of the ``cycle-repo-map.md`` block.
        cycle_prompt_block_index: Position of the cycle-specialized prompt,
            or ``None`` when no per-cycle prompt has been generated.
        boundary_user_block_index: Position of the last stable boundary
            user-message (from :func:`runner.soft_reset.format_boundary`).
        cache_control: Optional uniform ``cache_control`` dict applied to
            every BP. Honoured only when ``ttls`` is ``None``.
        ttls: Optional per-BP TTL tuple ``(BP1_ttl, BP2_ttl, BP3_ttl,
            BP4_ttl)``. When set, overrides ``cache_control`` so each BP
            carries its own TTL while the rest of the dict mirrors the
            ``cache_control`` shape (``{"type": "ephemeral", "ttl": <ttl>}``).
            Use :func:`resolve_ttls` to build the canonical tuple from the
            SDK probe.

    Returns:
        A list of exactly :data:`CACHE_BREAKPOINT_COUNT` ``CacheBreakpoint``
        entries in BP1→BP4 canonical order.
    """
    base_cc = dict(cache_control) if cache_control is not None else dict(_DEFAULT_CACHE_CONTROL)
    bp3_index = (
        max(repo_map_block_index, cycle_prompt_block_index)
        if cycle_prompt_block_index is not None
        else repo_map_block_index
    )
    indices = (tools_block_index, system_block_index, bp3_index, boundary_user_block_index)
    chosen_ttls = ttls if ttls is not None else (base_cc.get("ttl"),) * CACHE_BREAKPOINT_COUNT
    return [
        CacheBreakpoint(
            name=_BP_NAMES[i],
            block_index=indices[i],
            cache_control={**base_cc, "ttl": chosen_ttls[i]},
        )
        for i in range(CACHE_BREAKPOINT_COUNT)
    ]


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------


def validate_breakpoints(
    breakpoints: list[CacheBreakpoint],
    *,
    volatile_block_indices: Iterable[int] = (),
    max_lookback: int = MAX_LOOKBACK_BLOCKS,
) -> None:
    """Validate the §8 invariants on *breakpoints*.

    Checks:

    * Indices are strictly ascending (BP1 < BP2 < BP3 < BP4).
    * Each consecutive gap is at most ``max_lookback`` blocks (default 20).
    * No breakpoint marks a volatile block.

    Args:
        breakpoints: The four entries from :func:`build_cache_breakpoints`.
        volatile_block_indices: Blocks belonging to the volatile current
            request — markers on these would reset the cached prefix on
            every request.
        max_lookback: Override the 20-block lookback constant for tests.

    Raises:
        ValueError: When any of the three invariants is violated.
    """
    indices = [bp.block_index for bp in breakpoints]
    if indices != sorted(indices) or len(set(indices)) != len(indices):
        raise ValueError(
            f"breakpoints must be ordered with strictly ascending block indices, got {indices}"
        )
    for prev, curr in zip(indices, indices[1:], strict=False):
        gap = curr - prev
        if gap > max_lookback:
            raise ValueError(f"breakpoint gap {gap} exceeds {max_lookback}-block lookback rule")
    volatile = set(volatile_block_indices)
    for bp in breakpoints:
        if bp.block_index in volatile:
            raise ValueError(
                f"breakpoint {bp.name} cannot mark a volatile block at index {bp.block_index}"
            )
    _validate_ttl_ordering(breakpoints)


# Numerical TTL rank used for the longer-TTL-first invariant: bigger means
# longer cache lifetime. The set is intentionally narrow — Anthropic accepts
# only ``"5m"`` and ``"1h"`` for ephemeral cache_control today.
_TTL_RANK: dict[str, int] = {"5m": 1, "1h": 2}


def _validate_ttl_ordering(breakpoints: list[CacheBreakpoint]) -> None:
    """Reject layouts where a shorter-TTL marker precedes a longer-TTL marker.

    Anthropic's prompt-cache machinery requires longer-TTL entries to appear
    before shorter-TTL entries within a single request — out-of-order TTLs
    invalidate the prefix and force re-creation of the cache. Issue #240's
    canonical layout (BP1/BP2/BP3=1h, BP4=5m) satisfies this; the SDK-rejection
    fallback (uniform 5m) is also valid because every TTL is equal.

    Raises:
        ValueError: When any breakpoint's TTL is *shorter* than a later
            breakpoint's TTL.
    """
    ranks = [_TTL_RANK.get(bp.cache_control.get("ttl", ""), 0) for bp in breakpoints]
    for prev_rank, curr_rank in zip(ranks, ranks[1:], strict=False):
        if prev_rank < curr_rank:
            raise ValueError(
                "TTL ordering invariant: longer-TTL breakpoints must precede "
                f"shorter-TTL ones; got ranks {ranks}"
            )


# ---------------------------------------------------------------------------
# Bench-fixture simulator: paused-cycle cache_creation prediction
# ---------------------------------------------------------------------------


def _ttl_seconds(ttl: str) -> int:
    """Translate ``"5m"`` / ``"1h"`` to seconds for the simulator."""
    if ttl == "5m":
        return 5 * 60
    if ttl == "1h":
        return 60 * 60
    raise ValueError(f"unsupported ttl {ttl!r}")


def simulate_paused_cycle_cache(
    *,
    prefix_tokens: int,
    pause_seconds: float,
    ttls: tuple[str, str, str, str],
) -> int:
    """Predict ``cache_creation_input_tokens`` after a pause of *pause_seconds*.

    Synthetic bench fixture (issue #240 integration AC). Mirrors Anthropic's
    cache-warmth model: every BP1/BP2/BP3 marker that survives the pause keeps
    its share of the prefix warm; expired markers force the prefix to be
    re-created on the next turn. BP4 sits on the volatile boundary side and
    does not contribute to the static prefix.

    Args:
        prefix_tokens: Total tokens in the static prefix (tools + system +
            repo-map + cycle-specialized prompt) covered by BP1/BP2/BP3.
        pause_seconds: Time elapsed between turns (e.g. a rate-limit wait
            or a Phase 5 pause).
        ttls: Per-BP TTL tuple — same shape as :func:`resolve_ttls` returns.

    Returns:
        Predicted ``cache_creation_input_tokens`` for the next turn:

        * 0 when every static-prefix BP (BP1/BP2/BP3) is still within its TTL
          (cache fully reused).
        * ``prefix_tokens`` when at least one of BP1/BP2/BP3 has expired
          (cache invalidated, full prefix re-created).
    """
    static_ttls = ttls[:3]
    if any(pause_seconds > _ttl_seconds(ttl) for ttl in static_ttls):
        return prefix_tokens
    return 0
