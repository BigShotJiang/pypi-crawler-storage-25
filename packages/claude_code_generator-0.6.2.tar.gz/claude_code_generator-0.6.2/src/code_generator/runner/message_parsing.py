"""Message parsing helpers for SDK runner messages.

Provides pure helpers that operate on duck-typed message objects.
These have no dependency on the SDK client and can be tested independently,
satisfying SRP by keeping parsing logic separate from session orchestration.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from code_generator import state as _state
from code_generator.runner.types import OverageAbort, RateLimitHit, TokenUsage

if TYPE_CHECKING:
    import logging
    from pathlib import Path


# ---------------------------------------------------------------------------
# Text and usage extraction
# ---------------------------------------------------------------------------


def extract_text(msg: Any) -> str:
    """Extract concatenated text from an AssistantMessage's content blocks."""
    parts: list[str] = []
    for block in getattr(msg, "content", []):
        text = getattr(block, "text", None)
        if text is not None:
            parts.append(text)
    return "".join(parts)


def extract_usage(msg: Any) -> TokenUsage:
    """Return a TokenUsage from a ResultMessage, defensively.

    Reads all four Anthropic token counters plus ``num_turns``.  Missing or
    ``None`` values default to 0 — never returns ``None`` fields.

    ``num_turns`` lives on the ResultMessage itself (sibling of ``usage``),
    not inside the nested ``.usage`` payload; this function is the single
    extraction point for every usage-related field.

    Args:
        msg: The ResultMessage (duck-typed; may have dict or object .usage).

    Returns:
        A fully populated ``TokenUsage`` with zero defaults for absent fields.
    """
    num_turns = getattr(msg, "num_turns", None) or 0
    usage = getattr(msg, "usage", None)
    if usage is None:
        return TokenUsage(num_turns=num_turns)
    if isinstance(usage, dict):
        return TokenUsage(
            input=usage.get("input_tokens") or 0,
            output=usage.get("output_tokens") or 0,
            cache_write=usage.get("cache_creation_input_tokens") or 0,
            cache_read=usage.get("cache_read_input_tokens") or 0,
            num_turns=num_turns,
        )
    return TokenUsage(
        input=getattr(usage, "input_tokens", None) or 0,
        output=getattr(usage, "output_tokens", None) or 0,
        cache_write=getattr(usage, "cache_creation_input_tokens", None) or 0,
        cache_read=getattr(usage, "cache_read_input_tokens", None) or 0,
        num_turns=num_turns,
    )


# ---------------------------------------------------------------------------
# Duck-type discriminators
# ---------------------------------------------------------------------------


def is_rate_limit_event(msg: Any) -> bool:
    """Return True when msg looks like a RateLimitEvent."""
    return hasattr(msg, "rate_limit_info")


def is_assistant_message(msg: Any) -> bool:
    """Return True when msg looks like an AssistantMessage."""
    return hasattr(msg, "content") and hasattr(msg, "model")


def is_result_message(msg: Any) -> bool:
    """Return True when msg looks like a ResultMessage."""
    return (
        hasattr(msg, "session_id")
        and hasattr(msg, "is_error")
        and not hasattr(msg, "rate_limit_info")
        and not hasattr(msg, "model")
    )


def is_system_message(msg: Any) -> bool:
    """Return True when msg looks like a SDK ``SystemMessage``.

    Duck-typed: SystemMessage carries a ``subtype`` (e.g. ``"init"``) and an
    optional ``data`` dict, while not having the discriminating attributes of
    AssistantMessage (``model``) or ResultMessage (``is_error``).
    """
    return (
        hasattr(msg, "subtype")
        and not hasattr(msg, "model")
        and not hasattr(msg, "is_error")
        and not hasattr(msg, "rate_limit_info")
    )


def is_user_message(msg: Any) -> bool:
    """Return True when msg looks like a SDK ``UserMessage``.

    Duck-typed: UserMessage has ``content`` (a list of blocks) and a
    ``role`` of ``"user"``, but not the AssistantMessage ``model`` field.
    """
    role = getattr(msg, "role", None)
    return (
        role == "user"
        and hasattr(msg, "content")
        and not hasattr(msg, "model")
        and not hasattr(msg, "is_error")
    )


def render_system_message(msg: Any) -> str:
    """Format a SystemMessage's ``subtype`` + ``data`` payload for DEBUG logs.

    Full payload — no truncation. Large ``data`` values can produce long
    lines; that is intentional so users running with ``LOGLEVEL=DEBUG`` see
    exactly what the SDK emitted.
    """
    subtype = getattr(msg, "subtype", None)
    data = getattr(msg, "data", None)
    if subtype is None and data is None:
        return type(msg).__name__

    if isinstance(data, dict):
        previews = [f"{k}={v!r}" for k, v in data.items()]
        body = " ".join(previews) if previews else "<empty>"
    elif data is None:
        body = "<no data>"
    else:
        body = repr(data)

    return f"subtype={subtype} {body}"


def render_blocks(content: Any) -> str:
    """Render an SDK message's ``content`` (list of blocks) verbatim.

    Handles every block shape the agent SDK currently emits:
    - **TextBlock** (``.text``) → ``text: <body>``
    - **ToolUseBlock** (``.name``, ``.input``) → ``tool_use(name): {args}``
    - **ToolResultBlock** (``.tool_use_id``, ``.content``) → ``tool_result(id): <body>``
    - **ThinkingBlock** (``.thinking``) → ``thinking: <body>``
    - Anything else falls through to the class name.

    No truncation: tool results, prompts, and thinking blocks render in
    full. Long lines are intentional so DEBUG logs are lossless.

    Args:
        content: The message's ``content`` attribute. Lists are walked
            block-by-block; non-lists are repr'd directly.

    Returns:
        A single string suitable for a DEBUG log line.
    """
    if not isinstance(content, list):
        return repr(content)

    if not content:
        return "<empty>"

    return " | ".join(_render_block(block) for block in content)


def _render_block(block: Any) -> str:
    """Render a single content block — see :func:`render_blocks`."""
    if hasattr(block, "text") and isinstance(block.text, str):
        return f"text: {block.text}"
    if hasattr(block, "name") and hasattr(block, "input"):
        return f"tool_use({block.name}): {block.input!r}"
    if hasattr(block, "tool_use_id"):
        result = getattr(block, "content", "<no content>")
        is_error = bool(getattr(block, "is_error", False))
        body = _render_tool_result(result)
        prefix = "tool_result_error" if is_error else "tool_result"
        return f"{prefix}({block.tool_use_id}): {body}"
    if hasattr(block, "thinking") and isinstance(block.thinking, str):
        return f"thinking: {block.thinking}"
    return type(block).__name__


def _render_tool_result(content: Any) -> str:
    """Render a ToolResultBlock's ``.content`` (str | list[block] | other) verbatim."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        chunks: list[str] = []
        for item in content:
            text = getattr(item, "text", None)
            if isinstance(text, str):
                chunks.append(text)
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                chunks.append(item["text"])
            else:
                chunks.append(repr(item))
        return " / ".join(chunks) if chunks else "<empty>"
    return repr(content)


def render_prompt(prompt: str) -> str:
    """Return the outgoing prompt verbatim for DEBUG logging (no truncation)."""
    return prompt


def is_context_edit_message(msg: Any) -> bool:
    """Return True when msg looks like a CompactionResult or ContextEditResult.

    Duck-typed: detects compaction / context-edit SDK messages by the presence
    of ``freed_tokens`` OR by a ``stop_reason == "compaction"`` on a message
    that is not also a ResultMessage (which carries ``is_error``).

    These messages are intermediate — the SDK emits them mid-stream before the
    final ResultMessage.  They must be logged and skipped; they do NOT terminate
    the ``receive_messages()`` loop.

    Args:
        msg: Any message object received from the SDK client.

    Returns:
        ``True`` when *msg* is a compaction / context-edit event.
    """
    if is_result_message(msg):
        return False
    return hasattr(msg, "freed_tokens") or getattr(msg, "stop_reason", None) == "compaction"


_CLEAR_TOOL_USES_TYPE = "clear_tool_uses_20250919"


def is_clear_tool_uses_event(msg: Any) -> bool:
    """Return True when msg signals a ``clear_tool_uses_20250919`` SDK event (issue #243).

    Detection is duck-typed across the three message shapes the agent SDK
    has been observed to emit when the server-side ``clear_tool_uses`` edit
    fires:

    * ``msg.type == "clear_tool_uses_20250919"`` — top-level envelope.
    * SystemMessage where ``msg.subtype == "clear_tool_uses_20250919"``.
    * SystemMessage where ``msg.data == {"type": "clear_tool_uses_20250919", ...}``.

    A terminal :class:`ResultMessage` is never a clear event (early-return
    guard mirroring :func:`is_context_edit_message` and
    :func:`is_compaction_pause_event`).

    Args:
        msg: Any message object received from the SDK client.

    Returns:
        ``True`` when *msg* identifies a clear-tool-uses event.
    """
    if is_result_message(msg):
        return False
    if getattr(msg, "type", None) == _CLEAR_TOOL_USES_TYPE:
        return True
    if not is_system_message(msg):
        return False
    if getattr(msg, "subtype", None) == _CLEAR_TOOL_USES_TYPE:
        return True
    data = getattr(msg, "data", None)
    return isinstance(data, dict) and data.get("type") == _CLEAR_TOOL_USES_TYPE


def is_compaction_pause_event(msg: Any) -> bool:
    """Return True when msg signals a ``pause_after_compaction`` SDK event (issue #236).

    The pinned ``claude-agent-sdk`` (>=0.1.61,<0.2.0) does not expose a
    dedicated ``PauseAfterCompactionEvent`` type. Detection is duck-typed:

    * ``msg.pause_after_compaction == True`` — the documented field name.
    * ``msg.paused == True`` — alternative shape some pre-release SDKs use.

    A terminal :class:`ResultMessage` is never a pause event (early-return
    guard mirroring :func:`is_context_edit_message`). When neither field is
    set, the predicate returns ``False`` and the runner is a no-op — safe
    fallback for older SDKs that never emit the signal.

    Args:
        msg: Any message object received from the SDK client.

    Returns:
        ``True`` when *msg* carries a compaction-pause flag.
    """
    if is_result_message(msg):
        return False
    return bool(getattr(msg, "pause_after_compaction", False) or getattr(msg, "paused", False))


# ---------------------------------------------------------------------------
# Rate-limit event handler
# ---------------------------------------------------------------------------


def handle_rate_limit_event(
    msg: Any,
    logger: logging.Logger,
    state_path: Path,
) -> None:
    """Process a RateLimitEvent; raise OverageAbort or RateLimitHit as needed.

    Args:
        msg: The RateLimitEvent message (duck-typed).
        logger: Phase logger for warnings.
        state_path: Path to state.json for persistence.

    Raises:
        OverageAbort: When overage billing is active.
        RateLimitHit: When the rate limit is rejected and resets_at is known.
    """
    info = getattr(msg, "rate_limit_info", None)
    if info is None:
        logger.warning("RateLimitEvent received but has no rate_limit_info — skipping.")
        return

    # Non-negotiable #4: overage check — abort before incurring charges.
    # SDK values: "allowed" / "allowed_warning" mean overage billing IS active
    # (unsafe); "rejected" means overage is off and requests are blocked (safe);
    # None / "disabled" also safe.
    overage_status = getattr(info, "overage_status", None)
    if overage_status in ("allowed", "allowed_warning"):
        raise OverageAbort(
            f"Overage API billing active ({overage_status}) — aborting to avoid charges"
        )

    status = getattr(info, "status", None)

    if status == "rejected":
        _handle_rejected_rate_limit(msg, info, logger, state_path)
    elif status == "allowed_warning":
        utilization = getattr(info, "utilization", None)
        logger.warning(
            "Rate limit allowed_warning: approaching limit (utilization=%s).",
            utilization,
        )


def _handle_rejected_rate_limit(
    msg: Any,
    info: Any,
    logger: logging.Logger,
    state_path: Path,
) -> None:
    """Persist pause state and raise RateLimitHit, or warn if resets_at is missing."""
    resets_at = getattr(info, "resets_at", None)
    rate_limit_type = getattr(info, "rate_limit_type", None) or "unknown"
    session_id = getattr(msg, "session_id", None)

    if resets_at is not None:
        # Non-negotiable #5: add 60-second safety buffer so the API window
        # has fully cleared before we attempt to resume.
        paused_until = resets_at + 60
        st = _state.load_state(state_path)
        _state.mark_paused(
            st,
            resets_at=paused_until,
            rate_limit_type=str(rate_limit_type),
            session_id=session_id,
        )
        _state.save_state(state_path, st)
        raise RateLimitHit(paused_until, str(rate_limit_type))

    logger.warning("Rate limit rejected but no resets_at provided — cannot pause.")
