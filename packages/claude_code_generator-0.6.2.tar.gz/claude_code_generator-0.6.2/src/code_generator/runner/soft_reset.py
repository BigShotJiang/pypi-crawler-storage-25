"""Soft-reset primitive for shared-session cycles.

Performs the coordinated actions between consecutive issues so the shared
SDK client starts the next issue with a clean slate:

1. Atomically overwrite `current-issue.md` with an empty string.
2. Return the boundary user-message text as a **prompt prefix** the caller
   prepends to the next review/implementation prompt.
3. Return the `context_management` block the caller merges into the next
   `make_agent_options()` call.
4. Emit one INFO log line.

The function is a **pure helper**: it never mutates caller state and never
issues a separate ``client.query()``.  Sending the boundary as its own query
without draining the response leaves the SDK with an un-drained assistant
message in the queue; the next ``client.query()`` then drains *that* response
instead of its own, mis-attributing the review output by one issue
(regression detected 2026-04-17 — every even-indexed issue in Phase 2 got an
ACK-only reply, every odd-indexed issue got the previous issue's review).
Returning the prefix as text and letting the caller concatenate it into the
single outgoing query keeps the query/drain pairing intact.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from code_generator.memory import overwrite_memory_file

if TYPE_CHECKING:
    from pathlib import Path

_logger = logging.getLogger(__name__)

_CURRENT_ISSUE_RELPATH = "current-issue.md"

_BOUNDARY_TEMPLATE = (
    "Context reset. Starting issue #{n} fresh. "
    "All prior tool results and conversational context from issue #{prev} are discarded. "
    "Re-read files as needed."
)


def format_boundary(issue_number: int) -> str:
    """Return the canonical boundary user-message for *issue_number*.

    Pure helper — no I/O, no side effects. Reused by:
    * :func:`soft_reset_context` (legacy fallback path)
    * :func:`boundary_prefix_only` (server-side compaction fast-path, #235)
    * :class:`runner.compaction_pause.CompactionPauseHandler` (#236)

    Centralising the format keeps the §6 boundary text single-sourced — issue
    #236 mandates "do not duplicate the template".

    Args:
        issue_number: The issue number starting *now*; the previous issue is
            implied as ``issue_number - 1``.

    Returns:
        The boundary user-message text with a trailing ``\\n\\n`` ready for
        prepending to an outgoing prompt.
    """
    return _BOUNDARY_TEMPLATE.format(n=issue_number, prev=issue_number - 1) + "\n\n"


_RESET_CONTEXT_MANAGEMENT: dict[str, Any] = {
    "tools": [
        {
            "type": "clear_tool_uses_20250919",
            "keep": {"type": "tool_uses", "value": 0},
        }
    ]
}


@dataclass(frozen=True)
class SoftResetResult:
    """Result of a soft-reset action between two issues in shared mode.

    Attributes:
        boundary_prefix: Text the caller MUST prepend to the next prompt.
        context_management: Dict the caller MUST pass to ``make_agent_options``.
    """

    boundary_prefix: str
    context_management: dict[str, Any]


def boundary_prefix_only(issue_number: int, memories_dir: Path) -> str:
    """Return the boundary prefix for the §6 server-side compaction fast-path (issue #235).

    When the SDK advertises ``compact-2026-01-12``, the canonical context block
    handles tool-use clearing and compaction server-side; the soft-reset
    ``context_management`` overlay becomes redundant. This helper performs only
    the two actions that remain mandatory on the boundary:

    1. Atomically empty ``current-issue.md`` so cross-issue scratch state is
       discarded (memory-reset invariant).
    2. Return the boundary user-message text the caller MUST prepend to the
       next outgoing prompt (regression guard from 2026-04-17 — see module
       docstring).

    Unlike :func:`soft_reset_context` this returns a plain ``str`` (no
    ``SoftResetResult`` wrapper, no ``context_management`` dict).

    Args:
        issue_number: The issue number starting *now* (used in the boundary text).
        memories_dir: Root memories directory (created if absent).

    Returns:
        The boundary prefix string (with trailing ``\\n\\n``) ready to be
        prepended to the next outgoing prompt.

    Raises:
        ValueError: If ``current-issue.md`` would resolve outside *memories_dir*
            (path-traversal guard delegated to ``overwrite_memory_file``).
    """
    overwrite_memory_file(memories_dir, _CURRENT_ISSUE_RELPATH, "")
    _logger.info(
        "soft_reset(server-side fast-path): issue=%d memories_reset=1 boundary_prefix=1",
        issue_number,
    )
    return format_boundary(issue_number)


async def soft_reset_context(
    client: Any,  # noqa: ARG001 — kept for signature stability; no client interaction
    issue_number: int,
    memories_dir: Path,
) -> SoftResetResult:
    """Perform the soft-reset actions between consecutive issues.

    Args:
        client: Duck-typed SDK client. **Not used** — kept in the signature for
            backward compatibility with existing call sites and tests. The
            boundary message is returned to the caller so it can be prepended
            to the outgoing prompt, avoiding a second ``client.query()`` whose
            response would otherwise go undrained and desynchronise the queue.
        issue_number: The issue number starting *now* (used in the boundary text).
        memories_dir: Root memories directory (created if absent).

    Returns:
        A :class:`SoftResetResult` carrying the boundary prefix and the
        ``context_management`` block for the next query.

    Raises:
        ValueError: If ``current-issue.md`` would resolve outside *memories_dir*
            (path-traversal guard delegated to ``overwrite_memory_file``).
    """
    # Step 1: atomic memory overwrite (MUST happen before step 2 — ordering invariant)
    overwrite_memory_file(memories_dir, _CURRENT_ISSUE_RELPATH, "")

    # Step 2: build the boundary text; caller prepends to next prompt.
    _logger.info("soft_reset: issue=%d memories_reset=1 boundary_prefix=1", issue_number)

    return SoftResetResult(
        boundary_prefix=format_boundary(issue_number),
        context_management=dict(_RESET_CONTEXT_MANAGEMENT),
    )
