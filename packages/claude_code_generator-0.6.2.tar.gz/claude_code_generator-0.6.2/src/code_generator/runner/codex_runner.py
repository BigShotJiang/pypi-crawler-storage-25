"""Codex CLI runner: shells out to the OpenAI ``codex`` CLI in headless mode.

Satisfies RunnerProtocol by implementing the module-level ``run()`` coroutine.

Invocation contract (codex-cli headless ``exec`` mode). Flag ordering is
**strict** — Codex uses ``clap`` and rejects misplaced flags with
``error: unexpected argument``. Global flags (``-m`` / ``-C``) precede the
``exec`` subcommand; exec flags follow it::

    codex -m <model> -C <workdir> exec --skip-git-repo-check \\
        --dangerously-bypass-approvals-and-sandbox --json "<prompt>"

``--json`` makes stdout a JSONL event stream (one JSON object per line)::

    {"type": "thread.started", "thread_id": "..."}
    {"type": "turn.started"}
    {"type": "item.completed", "item": {"type": "reasoning", ...}}
    {"type": "item.completed", "item": {"type": "agent_message", "text": "..."}}
    {"type": "turn.completed", "usage": {"input_tokens": N,
        "output_tokens": N, "cached_input_tokens": N,
        "reasoning_output_tokens": N}}

Headless mode is stateless — there is no session resume across subprocess
invocations, so ``RunResult.session_id`` is always ``None`` and every issue
runs with fresh context (consistent with non-negotiable #6).

The Codex CLI has no dedicated rate-limit exit code: a usage-limit failure
surfaces as a JSON ``error`` object (``type == "usage_limit_reached"`` with
``resets_at`` / ``resets_in_seconds``) or a ``429`` in stderr. That is routed
into the wait-and-resume layer via :func:`handle_codex_429` (non-negotiable
#5 analogue), unlike the Gemini runner which only raises
``TransientRunnerError``.

Non-negotiables honored: #1 (build_agent_env strips Anthropic + OpenAI
credit vars), #3 (``--dangerously-bypass-approvals-and-sandbox`` — never an
interactive prompt), #5 (usage-limit → wait-and-resume), #6 (stateless).
"""

from __future__ import annotations

import asyncio
import json
import subprocess
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, NoReturn

from code_generator import env as _env
from code_generator.runner.rate_limit import handle_codex_429
from code_generator.runner.state_guard import protect_state_file
from code_generator.runner.types import (
    ApiUpstreamError,
    RunResult,
    TokenUsage,
    TransientRunnerError,
)

if TYPE_CHECKING:
    import logging

# Current default Codex model. The operator's --model always overrides this;
# the constant only applies when no model was passed or resolved from state.
_DEFAULT_MODEL = "gpt-5.5"

# Documented codex-cli exit code: clap argument / usage error.
_EXIT_USAGE_ERROR = 2

_STDERR_LOG_LIMIT = 500

# Substrings that identify a Codex usage-limit / rate-limit failure when no
# structured JSON error object is present (stderr-only failures).
_RATE_LIMIT_MARKERS = (
    "usage_limit_reached",
    "exceeded retry limit, last status: 429",
    "status: 429",
    " 429 ",
)


# ---------------------------------------------------------------------------
# Pure helpers (SRP, < 10 lines each)
# ---------------------------------------------------------------------------


def _extract_model(options: Any) -> str:
    """Return the operator's model or the current default."""
    return getattr(options, "model", None) or _DEFAULT_MODEL


def _extract_workdir(options: Any) -> str:
    """Return the working dir for ``-C``; defaults to the process cwd.

    The orchestrator always runs in the project root, so ``Path.cwd()`` is
    the safe default when ``options`` does not expose a ``cwd``.
    """
    return getattr(options, "cwd", None) or str(Path.cwd())


def _build_argv(prompt: str, model: str, workdir: str) -> list[str]:
    """Build the strict-order headless codex-cli argv.

    ``-m`` / ``-C`` are global flags (before ``exec``);
    ``--skip-git-repo-check`` / ``--dangerously-bypass-approvals-and-sandbox``
    / ``--json`` are exec flags (after ``exec``). The bypass flag enforces
    non-negotiable #3.
    """
    return [
        "codex",
        "-m",
        model,
        "-C",
        workdir,
        "exec",
        "--skip-git-repo-check",
        "--dangerously-bypass-approvals-and-sandbox",
        "--json",
        prompt,
    ]


def _run_subprocess(argv: list[str], safe_env: dict[str, str]) -> tuple[int, str, str]:
    """Run codex-cli and return ``(returncode, stdout, stderr)``."""
    result = subprocess.run(  # noqa: S603
        argv,
        capture_output=True,
        text=True,
        env=safe_env,
        check=False,
    )
    return result.returncode, result.stdout, result.stderr


def _iter_events(stdout: str) -> list[dict[str, Any]]:
    """Parse the JSONL stream; silently skip blank / unparseable lines."""
    events: list[dict[str, Any]] = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            parsed = json.loads(line)
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(parsed, dict):
            events.append(parsed)
    return events


def _extract_text(events: list[dict[str, Any]]) -> str:
    """Return the last ``agent_message`` item's text, or ``""``."""
    text = ""
    for event in events:
        if event.get("type") != "item.completed":
            continue
        item = event.get("item")
        if isinstance(item, dict) and item.get("type") == "agent_message":
            text = item.get("text", "") or ""
    return text


def _sum_usage_field(usage: dict[str, Any], field: str) -> int:
    """Return one ``usage`` counter as int, tolerant of missing / null."""
    return int(usage.get(field, 0) or 0)


def _map_tokens(events: list[dict[str, Any]], logger: logging.Logger) -> TokenUsage:
    """Map the ``turn.completed`` usage object onto TokenUsage.

    ``reasoning_output_tokens`` are chain-of-thought output tokens, so they
    fold into ``output`` (analogous to how Gemini ``thoughts`` fold into
    ``output``). Codex has no cache-write analogue, so ``cache_write`` stays 0.
    """
    usage: dict[str, Any] | None = None
    for event in events:
        if event.get("type") == "turn.completed":
            candidate = event.get("usage")
            if isinstance(candidate, dict):
                usage = candidate
    if usage is None:
        logger.warning(
            "Codex CLI output had no usable turn.completed.usage — token usage unavailable."
        )
        return TokenUsage()
    return TokenUsage(
        input=_sum_usage_field(usage, "input_tokens"),
        output=_sum_usage_field(usage, "output_tokens")
        + _sum_usage_field(usage, "reasoning_output_tokens"),
        cache_read=_sum_usage_field(usage, "cached_input_tokens"),
    )


def _find_usage_limit_error(events: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Return the first ``usage_limit_reached`` error payload, or ``None``.

    Tolerant of both a top-level ``error`` key and a dedicated ``error``
    event type, since Codex's exact JSONL error shape varies by version.
    """
    for event in events:
        error = event.get("error")
        if isinstance(error, dict) and error.get("type") == "usage_limit_reached":
            return error
        if event.get("type") == "error" and event.get("error_type") == "usage_limit_reached":
            return event
    return None


def _rate_limit_in_stderr(stderr: str) -> bool:
    """True when stderr carries a Codex usage-limit / 429 marker."""
    lowered = stderr.lower()
    return any(marker in lowered for marker in _RATE_LIMIT_MARKERS)


def _resolve_retry_after(error: dict[str, Any] | None) -> int | None:
    """Derive the wait interval (seconds) from a usage-limit error payload."""
    if not error:
        return None
    resets_in = error.get("resets_in_seconds")
    if isinstance(resets_in, int | float) and resets_in >= 0:
        return int(resets_in)
    resets_at = error.get("resets_at")
    if isinstance(resets_at, int | float):
        delta = int(resets_at - time.time())
        return max(delta, 0)
    return None


def _classify_exit_error(
    returncode: int,
    stderr: str,
    logger: logging.Logger,
) -> NoReturn:
    """Map a non-zero codex-cli exit code onto the runner exception model.

    Always raises. ``ApiUpstreamError`` (exit 2 — clap usage/invalid-flag
    error) is deliberately NOT a TransientRunnerError so retry skips it (it
    indicates an argv-construction bug). Every other non-zero exit is a
    general/runtime failure and is retried via ``TransientRunnerError``.
    """
    detail = stderr.strip()[:_STDERR_LOG_LIMIT]
    logger.error("Codex CLI exited %d: %s", returncode, detail or "<no detail>")
    if returncode == _EXIT_USAGE_ERROR:
        raise ApiUpstreamError(f"Codex CLI usage/argv error (exit 2): {detail}")
    raise TransientRunnerError(f"Codex CLI general/runtime failure (exit {returncode}): {detail}")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def run(
    prompt: str,
    options: Any,
    *,
    logger: logging.Logger,
    state_path: Path,
) -> RunResult:
    """Spawn codex-cli in headless mode and return the accumulated result.

    Args:
        prompt: The prompt text passed as the ``exec`` positional argument.
        options: Duck-typed options object; ``options.model`` overrides the
            default and ``options.cwd`` (when present) overrides ``-C``.
        logger: Phase logger.
        state_path: Path to state.json (made read-only during the subprocess).

    Returns:
        RunResult with parsed agent text, ``session_id=None``, and token
        usage mapped from the codex-cli JSONL stream.

    Raises:
        RateLimitHit: usage_limit_reached / 429 — drives wait-and-resume.
        ApiUpstreamError: exit 2 (clap usage / invalid-flag error).
        TransientRunnerError: any other non-zero exit, or exit 0 with no
            parseable ``agent_message``.
    """
    model = _extract_model(options)
    workdir = _extract_workdir(options)
    argv = _build_argv(prompt, model, workdir)
    safe_env = _env.build_agent_env(provider="codex")

    # effort=n/a — Codex has no effort parameter; logged for the
    # model=/effort= log-line invariant so operators see full context.
    logger.info("Codex CLI session starting (model=%s effort=n/a).", model)

    t0 = time.monotonic()
    with protect_state_file(state_path):
        returncode, stdout, stderr = await asyncio.to_thread(_run_subprocess, argv, safe_env)
    wall_seconds = time.monotonic() - t0

    events = _iter_events(stdout)

    # Rate-limit / usage-limit takes priority over exit-code classification:
    # Codex may exit non-zero on a usage limit, and that must wait-and-resume
    # (non-negotiable #5 analogue), not be treated as a hard failure.
    usage_error = _find_usage_limit_error(events)
    if usage_error is not None or (returncode != 0 and _rate_limit_in_stderr(stderr)):
        handle_codex_429(  # always raises RateLimitHit
            retry_after_seconds=_resolve_retry_after(usage_error),
            session_id=None,
            state_path=state_path,
            logger=logger,
        )

    if returncode != 0:
        _classify_exit_error(returncode, stderr, logger)

    text = _extract_text(events)
    if not text:
        raise TransientRunnerError(
            "Codex CLI exited 0 but produced no parseable agent_message — treating as transient."
        )

    logger.info("Codex CLI session complete.")

    return RunResult(
        text=text,
        session_id=None,
        usage=_map_tokens(events, logger),
        wall_seconds=wall_seconds,
        compaction_events=0,
        clear_events=0,
    )
