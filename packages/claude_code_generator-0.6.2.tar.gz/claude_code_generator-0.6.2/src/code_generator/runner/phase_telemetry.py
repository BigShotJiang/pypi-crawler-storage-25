"""Per-phase TokenUsage accumulator with TTL routing (issue #244).

Pure helper module. No I/O, no logging, no dependence on ``state.py`` —
the cycle-level dict aggregator (``runner/_telemetry.py``) is a separate
concern that this module deliberately does not import or modify.

Two public functions:

* :func:`accumulate_phase_telemetry` — fold a single SDK result's
  :class:`~code_generator.runner.types.TokenUsage` into a running per-phase
  ``TokenUsage`` total, routing ``cache_creation_input_tokens`` into either
  ``cache_write_5m`` or ``cache_write_1h`` based on the active TTL probe.
* :func:`cache_hit_ratio` — derive the 0–1 cache hit ratio from a
  ``TokenUsage`` snapshot (``status``/``bench`` consumers compute on demand).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from code_generator.runner.types import TokenUsage


_VALID_TTLS: frozenset[str] = frozenset({"5m", "1h"})


def accumulate_phase_telemetry(
    phase_usage: TokenUsage,
    *,
    ttl: Literal["1h", "5m"],
    usage: TokenUsage,
    compaction_delta: int,
    clear_delta: int,
) -> None:
    """Mutate *phase_usage* in place with one SDK result's counters.

    Adds ``input``, ``output``, ``cache_read``, and ``num_turns`` from
    *usage* directly. Routes ``usage.cache_write`` into either
    ``cache_write_5m`` (when ``ttl == "5m"``) or ``cache_write_1h``
    (when ``ttl == "1h"``) and keeps the flat ``cache_write`` field equal
    to the sum of the two buckets. Increments ``compaction_events`` and
    ``clear_events`` by the supplied deltas.

    Args:
        phase_usage: The running per-phase ``TokenUsage`` accumulator.
        ttl: Active TTL probe result for the workspace.
        usage: Token counters from a single SDK / subprocess result.
        compaction_delta: Number of compaction events observed during the
            run that produced *usage* (from ``RunResult.compaction_events``).
        clear_delta: Number of clear-tool-uses events observed during the
            run that produced *usage* (from ``RunResult.clear_events``).

    Raises:
        ValueError: When *ttl* is not one of ``"5m"`` or ``"1h"``.
    """
    if ttl not in _VALID_TTLS:
        raise ValueError(f"unsupported ttl: {ttl!r} (expected one of {sorted(_VALID_TTLS)})")

    phase_usage.input += usage.input
    phase_usage.output += usage.output
    phase_usage.cache_read += usage.cache_read
    phase_usage.num_turns += usage.num_turns
    phase_usage.cache_write += usage.cache_write
    if ttl == "5m":
        phase_usage.cache_write_5m += usage.cache_write
    else:
        phase_usage.cache_write_1h += usage.cache_write
    phase_usage.compaction_events += compaction_delta
    phase_usage.clear_events += clear_delta

    assert phase_usage.cache_write == phase_usage.cache_write_5m + phase_usage.cache_write_1h


def cache_hit_ratio(usage: TokenUsage) -> float:
    """Return ``cache_read / (cache_read + cache_write + input)`` as a float.

    Returns ``0.0`` (not NaN) when the denominator is zero so callers never
    need to guard against ``ZeroDivisionError``. ``output`` is intentionally
    excluded from the denominator — it is not an input-side cost driver.
    """
    denominator = usage.cache_read + usage.cache_write + usage.input
    if denominator <= 0:
        return 0.0
    return usage.cache_read / denominator
