"""Gemini CLI runner: shells out to the `gemini` CLI in headless mode.

Satisfies RunnerProtocol by implementing the module-level ``run()`` coroutine.

Invocation contract (gemini-cli headless mode):
    gemini -p "<prompt>" -m "<model>" --output-format json --yolo

The CLI emits a single JSON object on stdout::

    {
      "response": "<assistant text>",
      "stats": {"models": {"<model>": {"tokens": {"prompt", "candidates",
                "cached", "total", "thoughts", "tool"}}}},
      "error": {"type": "...", "message": "...", "code": 0}
    }

Headless mode is stateless — there is no session resume across subprocess
invocations, so ``RunResult.session_id`` is always ``None`` and every issue
runs with fresh context (consistent with non-negotiable #6).

Non-negotiables honored: #1 (build_agent_env strips Anthropic creds),
#3 (``--yolo`` — never an interactive prompt).
"""

from __future__ import annotations

import asyncio
import json
import subprocess
import time
from typing import TYPE_CHECKING, Any, NoReturn

from code_generator import env as _env
from code_generator.runner.state_guard import protect_state_file
from code_generator.runner.types import (
    ApiUpstreamError,
    MaxTurnsExceeded,
    RunResult,
    TokenUsage,
    TransientRunnerError,
)

if TYPE_CHECKING:
    import logging
    from pathlib import Path

# Current default Gemini model. The operator's --model always overrides this;
# the constant only applies when no model was passed or resolved from state.
_DEFAULT_MODEL = "gemini-2.5-pro"

# Documented gemini-cli headless exit codes.
_EXIT_GENERAL_ERROR = 1  # general / API failure — transient, retryable
_EXIT_INPUT_ERROR = 42  # invalid prompt or arguments — deterministic
_EXIT_TURN_LIMIT = 53  # turn limit exceeded — hard failure

_STDERR_LOG_LIMIT = 500


# ---------------------------------------------------------------------------
# Pure helpers (SRP, < 10 lines each)
# ---------------------------------------------------------------------------


def _extract_model(options: Any) -> str:
    """Return the operator's model or the current default."""
    return getattr(options, "model", None) or _DEFAULT_MODEL


def _build_argv(prompt: str, model: str) -> list[str]:
    """Build the headless gemini-cli argv. ``--yolo`` enforces non-negotiable #3."""
    return ["gemini", "-p", prompt, "-m", model, "--output-format", "json", "--yolo"]


def _run_subprocess(argv: list[str], safe_env: dict[str, str]) -> tuple[int, str, str]:
    """Run gemini-cli and return ``(returncode, stdout, stderr)``."""
    result = subprocess.run(  # noqa: S603
        argv,
        capture_output=True,
        text=True,
        env=safe_env,
        check=False,
    )
    return result.returncode, result.stdout, result.stderr


def _parse_json_output(stdout: str, logger: logging.Logger) -> dict[str, Any] | None:
    """Parse the single JSON object from stdout; ``None`` + WARNING on failure."""
    try:
        parsed = json.loads(stdout)
    except (json.JSONDecodeError, ValueError):
        logger.warning("Gemini CLI stdout was not valid JSON: %r", stdout[:_STDERR_LOG_LIMIT])
        return None
    return parsed if isinstance(parsed, dict) else None


def _sum_token_field(models: dict[str, Any], field: str) -> int:
    """Sum one ``tokens`` field across every model entry in ``stats.models``."""
    return sum(int(entry.get("tokens", {}).get(field, 0) or 0) for entry in models.values())


def _map_tokens(payload: dict[str, Any] | None, logger: logging.Logger) -> TokenUsage:
    """Map gemini-cli token counters onto TokenUsage; tolerant of missing stats.

    ``thoughts`` are chain-of-thought tokens emitted by Gemini 2.5 thinking
    models; they are output tokens, so they fold into ``output``. Gemini has
    no cache-write analogue, so ``cache_write`` stays 0.
    """
    try:
        models = payload["stats"]["models"]  # type: ignore[index]
        if not isinstance(models, dict):
            raise TypeError
    except (KeyError, TypeError, AttributeError):
        logger.warning("Gemini CLI output had no usable stats.models — token usage unavailable.")
        return TokenUsage()
    return TokenUsage(
        input=_sum_token_field(models, "prompt"),
        output=_sum_token_field(models, "candidates") + _sum_token_field(models, "thoughts"),
        cache_read=_sum_token_field(models, "cached"),
    )


def _extract_error_message(payload: dict[str, Any] | None) -> str | None:
    """Return ``error.message`` from the payload when present."""
    if not payload:
        return None
    error = payload.get("error")
    if isinstance(error, dict):
        return error.get("message")
    return None


def _is_resource_exhausted(payload: dict[str, Any] | None, message: str | None) -> bool:
    """True when the error payload signals a quota / rate-limit failure."""
    error = (payload or {}).get("error") or {}
    error_type = error.get("type", "") if isinstance(error, dict) else ""
    return error_type == "RESOURCE_EXHAUSTED" or "RESOURCE_EXHAUSTED" in (message or "")


def _classify_exit_error(
    returncode: int,
    stdout: str,
    stderr: str,
    logger: logging.Logger,
) -> NoReturn:
    """Map a non-zero gemini-cli exit code onto the runner exception model.

    Always raises. ``TransientRunnerError`` feeds the existing retry layer;
    ``ApiUpstreamError`` (exit 42) is deliberately NOT a TransientRunnerError
    so retry skips it; ``MaxTurnsExceeded`` (exit 53) is never retried.
    """
    payload = _parse_json_output(stdout, logger)
    message = _extract_error_message(payload) or stderr.strip()[:_STDERR_LOG_LIMIT]
    logger.error("Gemini CLI exited %d: %s", returncode, message or "<no detail>")

    if _is_resource_exhausted(payload, message):
        raise TransientRunnerError(f"Gemini quota exhausted (RESOURCE_EXHAUSTED): {message}")
    if returncode == _EXIT_INPUT_ERROR:
        raise ApiUpstreamError(f"Gemini CLI input error (exit 42): {message}")
    if returncode == _EXIT_TURN_LIMIT:
        raise MaxTurnsExceeded(f"Gemini CLI turn limit exceeded (exit 53): {message}")
    if returncode == _EXIT_GENERAL_ERROR:
        raise TransientRunnerError(f"Gemini CLI general/API failure (exit 1): {message}")
    raise ApiUpstreamError(f"Gemini CLI failed (exit {returncode}): {message}")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def run(
    prompt: str,
    options: Any,
    *,
    logger: logging.Logger,
    state_path: Path,
) -> RunResult:
    """Spawn gemini-cli in headless mode and return the accumulated result.

    Args:
        prompt: The prompt text passed via ``-p``.
        options: Duck-typed options object; ``options.model`` overrides default.
        logger: Phase logger.
        state_path: Path to state.json (made read-only during the subprocess).

    Returns:
        RunResult with parsed response text, ``session_id=None``, and token
        usage mapped from the gemini-cli JSON output.

    Raises:
        TransientRunnerError: exit 1 / RESOURCE_EXHAUSTED / unparseable output.
        ApiUpstreamError: exit 42 (input error) or unknown non-zero exit.
        MaxTurnsExceeded: exit 53 (turn limit).
    """
    model = _extract_model(options)
    argv = _build_argv(prompt, model)
    safe_env = _env.build_agent_env(provider="gemini")

    # effort=n/a — Gemini has no effort parameter; logged for the model=/effort=
    # log-line invariant so operators see full context.
    logger.info("Gemini CLI session starting (model=%s effort=n/a).", model)

    t0 = time.monotonic()
    with protect_state_file(state_path):
        returncode, stdout, stderr = await asyncio.to_thread(_run_subprocess, argv, safe_env)
    wall_seconds = time.monotonic() - t0

    if returncode != 0:
        _classify_exit_error(returncode, stdout, stderr, logger)

    payload = _parse_json_output(stdout, logger)
    if payload is None:
        raise TransientRunnerError(
            "Gemini CLI exited 0 but produced no parseable JSON — treating as transient."
        )

    text = payload.get("response", "")
    if not text:
        logger.warning("Gemini CLI response field was empty or absent.")

    logger.info("Gemini CLI session complete.")

    return RunResult(
        text=text,
        session_id=None,
        usage=_map_tokens(payload, logger),
        wall_seconds=wall_seconds,
        compaction_events=0,
        clear_events=0,
    )
