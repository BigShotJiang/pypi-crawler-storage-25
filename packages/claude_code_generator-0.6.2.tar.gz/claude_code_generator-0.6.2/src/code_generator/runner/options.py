"""Centralised factory for ClaudeAgentOptions.

Eliminates the try/except import-with-fallback boilerplate that was duplicated
across every phase module and commands/review.py.  Call `make_agent_options`
once with the desired keyword arguments; it returns either the real
ClaudeAgentOptions (when claude_agent_sdk is installed) or a lightweight
duck-typed fallback that exposes the same attributes.
"""

from __future__ import annotations

import logging
import warnings
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Iterable

_DEFAULT_BETAS: frozenset[str] = frozenset(
    {
        "compact-2026-01-12",
        "context-management-2025-06-27",
        "extended-cache-ttl-2025-04-11",
        "token-efficient-tools-2025-02-19",
    }
)
_TASK_BUDGET_BETA = "task-budgets-2026-03-13"

_DEFAULT_CACHE_CONTROL: dict[str, str] = {"type": "ephemeral", "ttl": "1h"}
_FALLBACK_CACHE_TTL = "5m"

# §6 canonical context_management block (issue #234).
#
# `clear_tool_uses_20250919` fires earlier than the `compact_20260112` edit so the
# cheaper tool-use truncation runs first; only when input still grows past the
# higher threshold does the (more expensive) compactor kick in. `keep=6` is the
# measured median tool-use depth in Phase 3/4 flows; `clear_at_least` guarantees
# the truncation actually reclaims space; `exclude_tools` keeps the memory tool
# and `Read` results visible across the compaction boundary so the model retains
# canonical files and cycle memory after a clear.
_CONTEXT_MANAGEMENT_INPUT_TOKENS = 150_000
_CONTEXT_MANAGEMENT_TOOL_USE_KEEP = 6
_CONTEXT_MANAGEMENT_CLEAR_TRIGGER_INPUT_TOKENS = 100_000
_CONTEXT_MANAGEMENT_CLEAR_AT_LEAST_INPUT_TOKENS = 10_000
_CONTEXT_MANAGEMENT_EXCLUDE_TOOLS: tuple[str, ...] = ("memory", "Read")
_CONTEXT_MANAGEMENT_COMPACT_INSTRUCTIONS = (
    "<summary>\n"
    "Preserve, in this exact order:\n"
    "1. Issue list — every GitHub issue number this cycle is implementing.\n"
    "2. Acceptance criteria — verbatim bullet list from each open issue.\n"
    "3. File paths modified — every path touched so far this cycle.\n"
    "4. Unresolved test failures — pytest node IDs still failing, with the "
    "first line of each error.\n"
    "Drop tool-call transcripts, intermediate reasoning, and resolved errors.\n"
    "</summary>"
)

# Module-level cache so the SDK probe runs at most once (avoids WARNING-spam).
_ttl_probe_result: str | None = None

# Per-process startup log: fires once to confirm the effective feature mix (§18).
_startup_logged: bool = False

# Feature names used by the retry loop (§18).
_FEATURE_BETA_EXTENDED_CACHE = "extended-cache-ttl-2025-04-11"
_FEATURE_BETA_TASK_BUDGET = "task-budgets-2026-03-13"
_FEATURE_BETA_CONTEXT_MANAGEMENT = "context-management-2025-06-27"
_FEATURE_BETA_COMPACT = "compact-2026-01-12"
_FEATURE_CONTEXT_MANAGEMENT = "context_management"
_FEATURE_EXCLUDE_DYNAMIC = "exclude_dynamic_sections"

# §6 canonical-block sub-fields (issue #234). Each is a sub-key inside the
# context_management dict the SDK may reject independently. Stripping them one
# at a time (most-experimental first) lets the retry loop keep the rest of the
# block intact instead of dropping context_management entirely.
_FEATURE_PAUSE_AFTER_COMPACTION = "pause_after_compaction"
_FEATURE_CUSTOM_INSTRUCTIONS = "custom_instructions"
_FEATURE_CLEAR_AT_LEAST = "clear_at_least"
_FEATURE_EXCLUDE_TOOLS = "exclude_tools"

# Ordered sequence of features the retry loop will attempt to drop (most experimental first).
# §6 sub-fields come BEFORE _FEATURE_CONTEXT_MANAGEMENT so a single rejected
# sub-field is removed surgically rather than dropping the whole block.
_DROPPABLE_FEATURES: tuple[str, ...] = (
    _FEATURE_PAUSE_AFTER_COMPACTION,
    _FEATURE_CUSTOM_INSTRUCTIONS,
    _FEATURE_CLEAR_AT_LEAST,
    _FEATURE_EXCLUDE_TOOLS,
    _FEATURE_BETA_CONTEXT_MANAGEMENT,
    _FEATURE_BETA_COMPACT,
    _FEATURE_BETA_EXTENDED_CACHE,
    _FEATURE_BETA_TASK_BUDGET,
    _FEATURE_CONTEXT_MANAGEMENT,
    _FEATURE_EXCLUDE_DYNAMIC,
)

# Human-readable fallback description per feature (used in WARNING messages).
_FEATURE_FALLBACK_DESC: dict[str, str] = {
    _FEATURE_PAUSE_AFTER_COMPACTION: "compact_20260112 without pause_after_compaction",
    _FEATURE_CUSTOM_INSTRUCTIONS: "compact_20260112 without custom_instructions",
    _FEATURE_CLEAR_AT_LEAST: "clear_tool_uses_20250919 without clear_at_least",
    _FEATURE_EXCLUDE_TOOLS: "clear_tool_uses_20250919 without exclude_tools",
    _FEATURE_BETA_CONTEXT_MANAGEMENT: "no context-management beta header",
    _FEATURE_BETA_COMPACT: "no compact beta header",
    _FEATURE_BETA_EXTENDED_CACHE: "ttl='5m'",
    _FEATURE_BETA_TASK_BUDGET: "no task budget",
    _FEATURE_CONTEXT_MANAGEMENT: "no context management",
    _FEATURE_EXCLUDE_DYNAMIC: "no exclude_dynamic_sections",
}

# Each §6 sub-field is dispatched to one of these strip helpers (avoids a long
# `if/elif` chain and keeps `_drop_feature` under the SOLID 10-line cap).
_COMPACT_SUBFIELDS: frozenset[str] = frozenset(
    {_FEATURE_PAUSE_AFTER_COMPACTION, _FEATURE_CUSTOM_INSTRUCTIONS}
)
_CLEAR_TOOL_USES_SUBFIELDS: frozenset[str] = frozenset(
    {_FEATURE_CLEAR_AT_LEAST, _FEATURE_EXCLUDE_TOOLS}
)

# Keywords that indicate a feature-rejection error (conservative match per §18).
_REJECTION_SIGNALS: frozenset[str] = frozenset(
    {"anthropic_beta", "not supported", "unknown keyword"}
)

# Per-process cache: features whose WARNING has already been emitted (avoids spam in retries).
_warned_features: set[str] = set()

_logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Feature-detection helpers (§18 retry loop)
# ---------------------------------------------------------------------------


def _is_feature_rejection(exc: Exception) -> bool:
    """Return True when *exc* looks like a feature-rejection signal from the SDK."""
    msg = str(exc).lower()
    return any(signal in msg for signal in _REJECTION_SIGNALS)


def _identify_rejected_feature(exc: Exception) -> str | None:
    """Return the name of the rejected feature embedded in *exc*'s message, or None."""
    msg = str(exc)
    for feature in _DROPPABLE_FEATURES:
        if feature in msg:
            return feature
    return None


def _warn_feature_once(feature: str) -> None:
    """Emit a WARNING for *feature* at most once per process (module-level guard)."""
    if feature in _warned_features:
        return
    _warned_features.add(feature)
    desc = _FEATURE_FALLBACK_DESC.get(feature, "unknown fallback")
    _logger.warning("runner: feature %r rejected by SDK, falling back to %s", feature, desc)


def _strip_subfield_from_first_entry(cm: dict | None, list_key: str, subfield: str) -> dict | None:
    """Return *cm* with *subfield* removed from the first entry of *list_key*.

    Returns *cm* unchanged when the dict is missing the list, the list is empty,
    or the entry has no such sub-field.
    """
    if cm is None:
        return None
    entries = cm.get(list_key)
    if not isinstance(entries, list) or not entries:
        return cm
    first = entries[0]
    if not isinstance(first, dict) or subfield not in first:
        return cm
    new_first = {k: v for k, v in first.items() if k != subfield}
    new_entries = [new_first, *entries[1:]]
    return {**cm, list_key: new_entries}


def _drop_subfield(feature: str, context_management: dict | None) -> dict | None:
    """Strip a §6 sub-field from the right list (compact edits vs clear-tool-uses tools)."""
    if feature in _COMPACT_SUBFIELDS:
        return _strip_subfield_from_first_entry(context_management, "edits", feature)
    if feature in _CLEAR_TOOL_USES_SUBFIELDS:
        return _strip_subfield_from_first_entry(context_management, "tools", feature)
    return context_management


def _drop_feature(
    feature: str,
    headers: dict[str, str],
    cache_control: dict,
    system_prompt: dict | str,
    output_config: dict | None,
    context_management: dict | None,
) -> tuple[dict[str, str], dict, dict | str, dict | None, dict | None]:
    """Return updated state with *feature* removed and its fallback applied."""
    _warn_feature_once(feature)
    if feature in _COMPACT_SUBFIELDS or feature in _CLEAR_TOOL_USES_SUBFIELDS:
        return (
            headers,
            cache_control,
            system_prompt,
            output_config,
            _drop_subfield(feature, context_management),
        )
    if feature in (_FEATURE_BETA_CONTEXT_MANAGEMENT, _FEATURE_BETA_COMPACT):
        betas = set(filter(None, headers.get("anthropic-beta", "").split(",")))
        betas.discard(feature)
        return (
            {**headers, "anthropic-beta": build_beta_header(betas)},
            cache_control,
            system_prompt,
            output_config,
            context_management,
        )
    if feature == _FEATURE_BETA_EXTENDED_CACHE:
        betas = set(filter(None, headers.get("anthropic-beta", "").split(",")))
        betas.discard(feature)
        return (
            {**headers, "anthropic-beta": build_beta_header(betas)},
            {"type": "ephemeral", "ttl": _FALLBACK_CACHE_TTL},
            system_prompt,
            output_config,
            context_management,
        )
    if feature == _FEATURE_BETA_TASK_BUDGET:
        betas = set(filter(None, headers.get("anthropic-beta", "").split(",")))
        betas.discard(feature)
        new_output: dict | None = (
            {k: v for k, v in output_config.items() if k != "task_budget"} or None
            if output_config is not None
            else None
        )
        return (
            {**headers, "anthropic-beta": build_beta_header(betas)},
            cache_control,
            system_prompt,
            new_output,
            context_management,
        )
    if feature == _FEATURE_CONTEXT_MANAGEMENT:
        return headers, cache_control, system_prompt, output_config, None
    if feature == _FEATURE_EXCLUDE_DYNAMIC:
        new_sp: dict | str = (
            {k: v for k, v in system_prompt.items() if k != "exclude_dynamic_sections"}
            if isinstance(system_prompt, dict)
            else system_prompt
        )
        return headers, cache_control, new_sp, output_config, context_management
    # Unknown feature — return state unchanged (caller will re-raise)
    return headers, cache_control, system_prompt, output_config, context_management


def _try_construct(
    sdk_cls: Any,
    *,
    allowed_tools: list[str],
    extra_headers: dict[str, str],
    cache_control: dict,
    system_prompt: dict | str,
    output_config: dict | None,
    context_management: dict | None,
    thinking: dict | None,
    mcp_servers: dict | None,
    **kwargs: Any,
) -> Any:
    """One construction attempt; raises on SDK rejection for the retry loop."""
    opts = sdk_cls(allowed_tools=allowed_tools, **kwargs)
    opts.extra_headers = extra_headers  # type: ignore[attr-defined]
    opts.cache_control = cache_control  # type: ignore[attr-defined]
    opts.system_prompt = system_prompt  # type: ignore[attr-defined]
    opts.thinking = thinking  # type: ignore[attr-defined]
    opts.output_config = output_config  # type: ignore[attr-defined]
    opts.context_management = context_management  # type: ignore[attr-defined]
    opts.mcp_servers = mcp_servers  # type: ignore[attr-defined]
    return opts


def _build_with_retry(
    sdk_cls: Any,
    *,
    allowed_tools: list[str],
    extra_headers: dict[str, str],
    cache_control: dict,
    system_prompt: dict | str,
    output_config: dict | None,
    context_management: dict | None,
    thinking: dict | None,
    mcp_servers: dict | None,
    **kwargs: Any,
) -> Any:
    """Construct ClaudeAgentOptions with a retry loop that drops rejected features."""
    headers = extra_headers
    cc = cache_control
    sp = system_prompt
    oc = output_config
    cm = context_management

    for _ in range(len(_DROPPABLE_FEATURES) + 1):
        try:
            return _try_construct(
                sdk_cls,
                allowed_tools=allowed_tools,
                extra_headers=headers,
                cache_control=cc,
                system_prompt=sp,
                output_config=oc,
                context_management=cm,
                thinking=thinking,
                mcp_servers=mcp_servers,
                **kwargs,
            )
        except (TypeError, ValueError) as exc:
            if not _is_feature_rejection(exc):
                raise
            feature = _identify_rejected_feature(exc)
            if feature is None:
                raise
            headers, cc, sp, oc, cm = _drop_feature(feature, headers, cc, sp, oc, cm)

    raise RuntimeError("Feature-detection retry loop exhausted; all features dropped")


def probe_cache_ttl_support(logger: logging.Logger) -> str:
    """Probe whether the SDK accepts ttl='1h' in cache_control; cache result module-level.

    Runs the probe exactly once per process (module reload resets the cache).
    Returns ``'1h'`` when the SDK accepts the value; returns ``'5m'`` and emits
    a WARNING when the SDK raises ``TypeError`` or ``ValueError``.

    Args:
        logger: Logger used to emit the WARNING on fallback.

    Returns:
        The supported TTL string: ``'1h'`` or ``'5m'``.
    """
    global _ttl_probe_result  # noqa: PLW0603
    if _ttl_probe_result is not None:
        return _ttl_probe_result

    try:
        from claude_agent_sdk import ClaudeAgentOptions  # type: ignore[import-not-found]

        ClaudeAgentOptions(allowed_tools=[], cache_control=_DEFAULT_CACHE_CONTROL)
        _ttl_probe_result = "1h"
    except (TypeError, ValueError):
        logger.warning(
            "SDK rejected cache_control ttl='1h'; falling back to ttl='5m'. "
            "Upgrade claude-agent-sdk to restore 1h cache lifetime."
        )
        _ttl_probe_result = _FALLBACK_CACHE_TTL
    except ImportError:
        _ttl_probe_result = "1h"

    return _ttl_probe_result


_REQUIRED_BETAS: frozenset[str] = frozenset({"context-management-2025-06-27", "compact-2026-01-12"})
_REMEDIATION_HINT = "pip install -U claude-agent-sdk"

# Module-level cache for compaction_beta_available() — probe runs at most once per process.
_compaction_beta_probe_result: bool | None = None


def _emitted_betas() -> set[str]:
    """Return the set of beta tokens make_agent_options would emit on a default call.

    Pure local SDK reflection — no network, no subprocess, no env mutation. Reads
    the resolved ``anthropic-beta`` header from a default ``make_agent_options``
    call and splits it on commas.
    """
    options = make_agent_options(allowed_tools=[])
    header = (getattr(options, "extra_headers", {}) or {}).get("anthropic-beta", "")
    return set(filter(None, header.split(",")))


def compaction_beta_available() -> bool:
    """Return True iff the resolved anthropic-beta header advertises ``compact-2026-01-12``.

    Soft-reset (``runner.soft_reset.soft_reset_context``) is the pre-Cycle-3
    fallback for issue boundaries. When this predicate is True the §6 canonical
    block (``compact_20260112`` + ``clear_tool_uses_20250919``) handles boundary
    clears server-side and the orchestrator MUST skip the soft-reset call —
    running both layers double-truncates context and silently drops cycle
    memory.

    The result is cached module-level so the probe runs at most once per
    process. ``importlib.reload`` resets the cache.

    Returns:
        ``True`` when ``compact-2026-01-12`` is in the emitted ``anthropic-beta``
        header; ``False`` otherwise. Pure local reflection — no network call.
    """
    global _compaction_beta_probe_result  # noqa: PLW0603
    if _compaction_beta_probe_result is not None:
        return _compaction_beta_probe_result
    _compaction_beta_probe_result = _FEATURE_BETA_COMPACT in _emitted_betas()
    return _compaction_beta_probe_result


def assert_required_betas() -> None:
    """Raise RuntimeError when required beta tokens are missing from emitted headers.

    Inspects the ``anthropic-beta`` header that ``make_agent_options`` would emit
    and verifies both ``context-management-2025-06-27`` and ``compact-2026-01-12``
    are present. An older SDK that strips unrecognized betas turns the
    context-management + compaction blocks into silent no-ops; this self-check
    refuses to start in that state. No network calls, no env mutation.

    Raises:
        RuntimeError: When either required beta is missing. Message lists the
            missing tokens and includes the ``pip install -U claude-agent-sdk``
            remediation hint.
    """
    options = make_agent_options(allowed_tools=[])
    header = (getattr(options, "extra_headers", {}) or {}).get("anthropic-beta", "")
    emitted = set(filter(None, header.split(",")))
    missing = sorted(_REQUIRED_BETAS - emitted)
    if missing:
        raise RuntimeError(
            f"Required beta tokens missing from anthropic-beta header: {', '.join(missing)}. "
            f"Run `{_REMEDIATION_HINT}` to upgrade."
        )


def build_beta_header(betas: Iterable[str]) -> str:
    """Return a comma-joined, alphabetically-sorted string of beta feature names.

    Args:
        betas: Any iterable of beta feature name strings.

    Returns:
        A single string with all beta names joined by commas in sorted order.
    """
    return ",".join(sorted(betas))


def _build_compact_edit() -> dict:
    """Return the canonical ``compact_20260112`` edit entry (§6)."""
    return {
        "type": "compact_20260112",
        "trigger": {"type": "input_tokens", "value": _CONTEXT_MANAGEMENT_INPUT_TOKENS},
        "pause_after_compaction": True,
        "custom_instructions": _CONTEXT_MANAGEMENT_COMPACT_INSTRUCTIONS,
    }


def _build_clear_tool_uses_tool() -> dict:
    """Return the canonical ``clear_tool_uses_20250919`` tool entry (§6)."""
    return {
        "type": "clear_tool_uses_20250919",
        "trigger": {
            "type": "input_tokens",
            "value": _CONTEXT_MANAGEMENT_CLEAR_TRIGGER_INPUT_TOKENS,
        },
        "keep": {"type": "tool_uses", "value": _CONTEXT_MANAGEMENT_TOOL_USE_KEEP},
        "clear_at_least": {
            "type": "input_tokens",
            "value": _CONTEXT_MANAGEMENT_CLEAR_AT_LEAST_INPUT_TOKENS,
        },
        "exclude_tools": list(_CONTEXT_MANAGEMENT_EXCLUDE_TOOLS),
    }


def build_context_management_block() -> dict:
    """Return the §6 canonical context-management block for shared-client sessions.

    The block layers two server-side strategies:

    * ``clear_tool_uses_20250919`` (in ``tools``) fires at
      ``input_tokens=100_000`` and trims tool-use groups down to the most
      recent six, reclaiming at least 10k input tokens per fire.
      ``exclude_tools=("memory","Read")`` keeps memory-tool writes and ``Read``
      tool results visible across the truncation so the model retains canonical
      file contents and cycle memory.
    * ``compact_20260112`` (in ``edits``) fires at ``input_tokens=150_000``,
      pauses the model after compaction so the orchestrator can resume in a
      single roundtrip, and uses verbatim ``custom_instructions`` to preserve
      issue list, acceptance criteria, file paths modified, and unresolved
      test failures.

    Sub-fields the SDK rejects are stripped surgically by ``_build_with_retry``
    via ``_DROPPABLE_FEATURES`` / ``_drop_feature`` (issue #234).

    Returns:
        A 2-key dict with ``"edits"`` and ``"tools"`` lists ready to be passed
        as the ``context_management`` attribute of ``ClaudeAgentOptions``.
    """
    return {
        "edits": [_build_compact_edit()],
        "tools": [_build_clear_tool_uses_tool()],
    }


def build_system_prompt(append: str = "") -> dict:
    """Return the canonical Claude Code SystemPromptPreset dict.

    The returned dict instructs the SDK to use the shared ``claude_code`` preset
    while excluding volatile dynamic sections (cwd, memory, git status) so the
    cache prefix remains byte-identical across consecutive sessions (§2).

    Args:
        append: Optional string appended after the preset's base system prompt.
            Defaults to an empty string.

    Returns:
        A 4-key dict: ``{"type": "preset", "preset": "claude_code",
        "append": append, "exclude_dynamic_sections": True}``.
    """
    return {
        "type": "preset",
        "preset": "claude_code",
        "append": append,
        "exclude_dynamic_sections": True,
    }


def max_turns_kwargs(max_turns: int | None) -> dict[str, Any]:
    """Return ``{"max_turns": N}`` when *max_turns* is set, else ``{}`` (#210).

    Splats into a :func:`make_agent_options` call so operators can opt in to a
    turn cap via ``--max-turns`` without the no-flag path silently passing
    ``max_turns=None`` (which would re-open the silent-default trap).

    Args:
        max_turns: Optional turn cap from the ``--max-turns`` CLI flag.

    Returns:
        A kwargs dict with a single ``max_turns`` entry, or an empty dict.
        Typed as ``dict[str, Any]`` so ``**max_turns_kwargs(...)`` splats
        cleanly into :func:`make_agent_options` without pyright trying to
        match against the named kwargs on that signature.
    """
    return {} if max_turns is None else {"max_turns": max_turns}


def make_agent_options(
    *,
    allowed_tools: list[str],
    extra_headers: dict[str, str] | None = None,
    cache_control: dict | None = None,
    system_prompt: dict | str | None = None,
    thinking: dict | None = None,
    output_config: dict | None = None,
    task_budget: int | None = None,
    context_management: dict | None = None,
    context_management_enabled: bool = False,
    mcp_servers: dict | None = None,
    memory_tool: Any = None,
    cache_breakpoints: Any = None,
    **kwargs: Any,
) -> Any:
    """Return a ClaudeAgentOptions-compatible object populated with *kwargs*.

    When ``claude_agent_sdk`` is importable the real ``ClaudeAgentOptions``
    class is used so the SDK receives its native type.  When the SDK is absent
    (subprocess-runner path) a minimal duck-typed fallback is returned whose
    attributes mirror the passed keyword arguments exactly.

    Args:
        allowed_tools: Required. The list of tool names the agent may use.
            Must be a ``list[str]``; passing ``None`` raises ``TypeError``.
        extra_headers: Optional mapping of HTTP header names to values.
            When ``None``, defaults to a dict containing the ``anthropic-beta``
            header with the alphabetically-sorted default beta features.
        cache_control: Optional cache control dict (e.g. ``{"type": "ephemeral",
            "ttl": "1h"}``).  When ``None``, the default ``{"type": "ephemeral",
            "ttl": "1h"}`` is used after probing SDK support; falls back to
            ``ttl="5m"`` with a WARNING if the SDK rejects ``ttl="1h"``.
            A caller-supplied value is passed through unchanged.
        system_prompt: Optional system prompt value.  When ``None``, defaults to
            the canonical ``claude_code`` preset dict from ``build_system_prompt("")``
            (§2 cache-safe preset with ``exclude_dynamic_sections=True``).  A
            ``str`` or ``dict`` supplied by the caller is forwarded unchanged
            (backward compatibility for phases not yet migrated to the preset).
        thinking: Optional thinking configuration dict.  When set with
            ``{"type": "adaptive"}`` enables adaptive thinking (Opus 4.7 only).
            Passing ``{"budget_tokens": N}`` is accepted but emits a
            ``DeprecationWarning`` — Opus 4.7 removed fixed ``budget_tokens``.
            Set as a post-init attribute; not passed to the SDK constructor.
        output_config: Optional output configuration dict.  When set, e.g.
            ``{"effort": "xhigh"}``, controls per-phase effort levels (§7).
            Set as a post-init attribute; not passed to the SDK constructor.
        task_budget: Optional advisory token budget for the task (§13).  When
            set, injects ``output_config["task_budget"] = {"type": "tokens",
            "total": <N>}`` into the resolved output_config dict and adds
            ``task-budgets-2026-03-13`` to the ``anthropic-beta`` header
            (alphabetically merged).  When ``None`` (default), neither field
            is modified.
        context_management: Optional explicit context-management block.  When
            set, forwarded unchanged (caller wins) regardless of
            ``context_management_enabled``.  When ``None`` and
            ``context_management_enabled`` is ``True``, the canonical §3 block
            (``compact_20260112`` + ``clear_tool_uses_20250919``) is injected.
            When both are at their defaults, no ``context_management`` attribute
            is set on the returned options.
        context_management_enabled: Convenience flag for Phase 3/4.  When
            ``True`` and ``context_management`` is ``None``, injects the
            canonical §3 block via ``build_context_management_block()``.
            Defaults to ``False`` (no injection).
        mcp_servers: Optional MCP server config dict (e.g.
            ``{"codebase_memory": {"command": "x"}}``).  Forwarded verbatim
            as a post-init attribute; no validation or feature-detect is
            performed at this layer (§4 phase modules handle that).  Defaults
            to ``None``.
        **kwargs: Additional keyword arguments forwarded verbatim to
            ``ClaudeAgentOptions.__init__``.  The ``max_turns`` kwarg is
            accepted here as an **opt-in only** escape hatch (wired to the
            ``--max-turns`` CLI flag, issue #207): no production call site
            should set it, and the subprocess runner omits the corresponding
            argv flag when it is ``None``.  ``MaxTurnsExceeded`` in
            production logs therefore indicates a bug or an explicit operator
            override, not a recoverable outcome.

    Returns:
        A ``ClaudeAgentOptions`` instance or a duck-typed fallback object.

    Raises:
        TypeError: If ``allowed_tools`` is omitted or is not a ``list``.
    """
    if not isinstance(allowed_tools, list):
        raise TypeError(f"allowed_tools must be a list[str], got {type(allowed_tools).__name__!r}")
    _warn_if_budget_tokens(thinking)
    resolved_headers = _resolve_headers(extra_headers, task_budget)
    resolved_cache_control = _resolve_cache_control(cache_control)
    resolved_system_prompt = _resolve_system_prompt(system_prompt)
    resolved_output_config = _resolve_output_config(output_config, task_budget)
    resolved_context_management = _resolve_context_management(
        context_management, context_management_enabled
    )
    try:
        from claude_agent_sdk import ClaudeAgentOptions  # type: ignore[import-not-found]

        # Use the feature-detection retry loop (§18): each unsupported feature is
        # dropped one at a time, with a WARNING emitted at most once per process.
        result = _build_with_retry(
            ClaudeAgentOptions,
            allowed_tools=allowed_tools,
            extra_headers=resolved_headers,
            cache_control=resolved_cache_control,
            system_prompt=resolved_system_prompt,
            output_config=resolved_output_config,
            context_management=resolved_context_management,
            thinking=thinking,
            mcp_servers=mcp_servers,
            **kwargs,
        )
        # Memory tool is set as a post-init attribute so the SDK ignores it on
        # versions that don't recognise the field. _client_lifecycle reads it
        # back to register the tool when the SDK ships the API (issue #238).
        if memory_tool is not None:
            result.memory_tool = memory_tool
        # Same forward-compat hook for the §8 four-breakpoint cache layout
        # (issue #239). SDK 0.1.65 only accepts a single top-level
        # cache_control dict; storing the layout as a post-init attribute
        # lets future SDK versions read it once per-block markers ship.
        if cache_breakpoints is not None:
            result.cache_breakpoints = cache_breakpoints
        _log_startup_once(result, sdk_available=True)
        return result
    except ImportError:
        result = _FallbackOptions(
            allowed_tools=allowed_tools,
            extra_headers=resolved_headers,
            cache_control=resolved_cache_control,
            system_prompt=resolved_system_prompt,
            thinking=thinking,
            output_config=resolved_output_config,
            context_management=resolved_context_management,
            mcp_servers=mcp_servers,
            memory_tool=memory_tool,
            cache_breakpoints=cache_breakpoints,
            **kwargs,
        )
        _log_startup_once(result, sdk_available=False)
        return result


def _resolve_sdk_version(sdk_available: bool) -> str:
    """Return the SDK version when importable; 'unknown' otherwise."""
    if not sdk_available:
        return "unknown"
    try:
        import claude_agent_sdk  # type: ignore[import-not-found]

        return getattr(claude_agent_sdk, "__version__", "unknown")
    except ImportError:
        return "unknown"


def _resolve_betas_label(opts: Any, sdk_available: bool) -> str:
    """Return the effective betas label: the header value or 'none'."""
    if not sdk_available:
        return "none"
    headers = getattr(opts, "extra_headers", {}) or {}
    return headers.get("anthropic-beta", "") or "none"


def _build_startup_fields(opts: Any, sdk_available: bool) -> tuple[str, str, str, str, str]:
    """Return the 5 startup log fields extracted from a constructed options object."""
    sp = getattr(opts, "system_prompt", {}) or {}
    cc = getattr(opts, "cache_control", {}) or {}
    return (
        _resolve_sdk_version(sdk_available),
        _resolve_betas_label(opts, sdk_available),
        "yes" if getattr(opts, "context_management", None) is not None else "no",
        "yes" if (isinstance(sp, dict) and sp.get("exclude_dynamic_sections")) else "no",
        cc.get("ttl", "unknown") if isinstance(cc, dict) else "unknown",
    )


def _log_startup_once(opts: Any, *, sdk_available: bool) -> None:
    """Emit a one-line INFO startup summary on the first successful make_agent_options() call."""
    global _startup_logged  # noqa: PLW0603
    if _startup_logged:
        return
    _startup_logged = True
    sdk_ver, betas, ctx_mgmt, excl_dyn, ttl = _build_startup_fields(opts, sdk_available)
    _logger.info(
        "runner: SDK=%s betas=%s context_mgmt=%s exclude_dynamic_sections=%s ttl=%s",
        sdk_ver,
        betas,
        ctx_mgmt,
        excl_dyn,
        ttl,
    )


def _warn_if_budget_tokens(thinking: dict | None) -> None:
    """Emit DeprecationWarning when thinking contains 'budget_tokens'.

    Opus 4.7 removed fixed thinking budgets; only adaptive thinking is supported.
    """
    if thinking is not None and "budget_tokens" in thinking:
        warnings.warn(
            "thinking['budget_tokens'] is deprecated: Opus 4.7 removed fixed thinking_budget. "
            "Use thinking={'type': 'adaptive'} instead.",
            DeprecationWarning,
            stacklevel=3,
        )


def _default_beta_headers() -> dict[str, str]:
    """Return the default extra_headers dict with the canonical anthropic-beta value."""
    return {"anthropic-beta": build_beta_header(_DEFAULT_BETAS)}


def _resolve_headers(
    extra_headers: dict[str, str] | None, task_budget: int | None
) -> dict[str, str]:
    """Return the resolved extra_headers dict, injecting the task-budgets beta when set.

    When ``task_budget`` is set, ``task-budgets-2026-03-13`` is merged into the
    ``anthropic-beta`` header value in alphabetical order.  When ``task_budget``
    is ``None``, the headers are returned unchanged.
    """
    base = extra_headers if extra_headers is not None else _default_beta_headers()
    if task_budget is None:
        return base
    current_beta = base.get("anthropic-beta", "")
    current_betas = set(filter(None, current_beta.split(",")))
    current_betas.add(_TASK_BUDGET_BETA)
    return {**base, "anthropic-beta": build_beta_header(current_betas)}


def _resolve_output_config(output_config: dict | None, task_budget: int | None) -> dict | None:
    """Return the resolved output_config dict, injecting task_budget entry when set.

    When ``task_budget`` is set, merges ``{"task_budget": {"type": "tokens", "total": N}}``
    into the output_config dict (creating it if ``None``).  When ``task_budget``
    is ``None``, returns ``output_config`` unchanged.
    """
    if task_budget is None:
        return output_config
    base = dict(output_config) if output_config is not None else {}
    base["task_budget"] = {"type": "tokens", "total": task_budget}
    return base


def _resolve_system_prompt(system_prompt: dict | str | None) -> dict | str:
    """Return the resolved system_prompt value.

    Caller-supplied strings or dicts are passed through unchanged.  ``None``
    triggers the canonical ``claude_code`` preset (§2 cache-safe default).
    """
    if system_prompt is not None:
        return system_prompt
    return build_system_prompt()


def _resolve_cache_control(cache_control: dict | None) -> dict:
    """Return the resolved cache_control dict.

    Caller-supplied values are passed through unchanged.  ``None`` triggers the
    lazy SDK probe so the TTL is the best value the installed SDK supports.
    """
    if cache_control is not None:
        return cache_control
    ttl = probe_cache_ttl_support(_logger)
    return {"type": "ephemeral", "ttl": ttl}


def _resolve_context_management(
    context_management: dict | None, context_management_enabled: bool
) -> dict | None:
    """Return the resolved context_management block, or None when not applicable.

    Caller-supplied dict wins (caller wins principle).  When no explicit dict
    is provided and ``context_management_enabled`` is True, injects the
    canonical §3 block.  Otherwise returns None (no injection).
    """
    if context_management is not None:
        return context_management
    if context_management_enabled:
        return build_context_management_block()
    return None


class _FallbackOptions:
    """Duck-typed stand-in for ClaudeAgentOptions used when the SDK is absent."""

    def __init__(self, **kwargs: Any) -> None:
        self.__dict__.update(kwargs)
