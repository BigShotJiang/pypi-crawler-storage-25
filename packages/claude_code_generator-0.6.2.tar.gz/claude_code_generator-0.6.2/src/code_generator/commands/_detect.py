"""Re-run detection for the generate command.

Compares the current requirements.md hash against the stored hash in state to
decide the correct execution path on startup.

The sole exported function is a pure function (no I/O) so it is trivially
unit-testable.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from code_generator.state import CycleState

if TYPE_CHECKING:
    from code_generator import state as state_module

RunMode = Literal["first-run", "resume", "no-op", "delta"]

__all__ = ["RunMode", "detect_run_mode"]


def _run_is_complete(state: state_module.State) -> bool:
    """Return True when the generation run is fully complete.

    Single mode: complete when phase == 7 (final commit phase).
    Multi-cycle mode: complete when every cycle has status "completed"
    and at least one cycle exists.
    """
    if state.mode == "multi-cycle":
        cycle_states = [c for c in state.cycles if isinstance(c, CycleState)]
        return len(cycle_states) > 0 and all(c.status == "completed" for c in cycle_states)
    return state.phase == 7


def detect_run_mode(state: state_module.State, current_hash: str) -> RunMode:
    """Determine how the generate command should proceed given existing state.

    This is a pure function: it reads ``state`` and ``current_hash`` and
    returns a decision literal.  It never performs I/O.

    Decision rules (evaluated in order):
    1. No stored hash → ``"first-run"`` (treat as a brand-new run)
    2. Hashes differ  → ``"delta"``     (requirements changed)
    3. Run complete   → ``"no-op"``     (nothing left to do)
    4. Otherwise      → ``"resume"``    (same requirements, incomplete run)

    Args:
        state: Loaded root state (may have requirements_hash=None for old runs).
        current_hash: SHA-256 hex digest of the current requirements.md.

    Returns:
        One of ``"first-run"``, ``"resume"``, ``"no-op"``, or ``"delta"``.
    """
    if state.requirements_hash is None:
        return "first-run"
    if state.requirements_hash != current_hash:
        return "delta"
    if _run_is_complete(state):
        return "no-op"
    return "resume"
