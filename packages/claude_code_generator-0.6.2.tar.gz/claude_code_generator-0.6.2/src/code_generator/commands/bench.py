"""bench command — measure per-phase telemetry against a fixture.

Signature:
    code-generator bench [--fake|--real] [--session-mode fresh|shared]
                         [--cycles N] [--fixture PATH] [--output FILE]

Output schema (schema_version=3, see _bench_io.SCHEMA_VERSION):
    {schema_version, timestamp_utc, session_mode, fixture,
     cycles: [{cycle_name,
               phases: {"0"…"7": {input, output, cache_read, cache_write,
                                  cache_hit_pct, wall_seconds, num_turns,
                                  cache_write_5m, cache_write_1h,
                                  compaction_events, clear_events,
                                  cache_hit_ratio}},
               totals}]}

v3 (issue #248): added the TTL split (cache_write_5m / cache_write_1h), the
SDK lifecycle counters (compaction_events / clear_events), and the 0.0-1.0
``cache_hit_ratio`` float used by ``bench compare`` for regression flagging.

Bump schema_version + add a migration note for any breaking change.
"""

from __future__ import annotations

import logging
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Annotated, Any

import typer

from code_generator.commands._bench_io import SCHEMA_VERSION, write_output

if TYPE_CHECKING:
    from collections.abc import Callable

    from code_generator.runner.types import RunResult

# ---------------------------------------------------------------------------
# Sub-app: bench_app (registered as "bench" in the top-level CLI)
# ---------------------------------------------------------------------------

bench_app = typer.Typer(
    invoke_without_command=True,
    no_args_is_help=False,
    help="Benchmark commands: run --fake/--real, compare two reports.",
)
_NUM_PHASES: int = 8
_BENCH_PROBE_PROMPT: str = "Reply with a single word: ok"
_BENCH_MODEL: str = "claude-sonnet-4-6"
_LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Phase-metrics helpers
# ---------------------------------------------------------------------------


def _cache_hit_ratio(cache_read: int, cache_write: int, input_tokens: int) -> float:
    """Return the 0–1 cache hit ratio (issue #248). Zero denominator → 0.0."""
    denominator = cache_read + cache_write + input_tokens
    if denominator <= 0:
        return 0.0
    return cache_read / denominator


def _phase_metrics(result: RunResult) -> dict[str, int | float]:
    """Convert a RunResult into the v3 phase-metrics dict (issue #248).

    v3 adds the TTL split (``cache_write_5m`` / ``cache_write_1h``), the SDK
    lifecycle counters (``compaction_events`` / ``clear_events``), and the
    0.0-1.0 ``cache_hit_ratio`` float alongside the existing v2 keys.
    """
    u = result.usage
    denominator = u.cache_read + u.cache_write + u.input
    hit_pct = round(u.cache_read / denominator * 100, 1) if denominator else 0.0
    return {
        "input": u.input,
        "output": u.output,
        "cache_read": u.cache_read,
        "cache_write": u.cache_write,
        "cache_hit_pct": hit_pct,
        "wall_seconds": result.wall_seconds,
        "num_turns": u.num_turns,
        "cache_write_5m": u.cache_write_5m,
        "cache_write_1h": u.cache_write_1h,
        "compaction_events": u.compaction_events,
        "clear_events": u.clear_events,
        "cache_hit_ratio": _cache_hit_ratio(u.cache_read, u.cache_write, u.input),
    }


def _aggregate_totals(phases: dict[str, dict[str, int | float]]) -> dict[str, int | float]:
    """Sum per-phase metrics into cycle-level totals with recomputed ratios."""
    total_input = total_output = total_read = total_write = 0
    total_turns = 0
    total_wall = 0.0
    total_5m = total_1h = total_compaction = total_clear = 0
    for m in phases.values():
        total_input += int(m["input"])
        total_output += int(m["output"])
        total_read += int(m["cache_read"])
        total_write += int(m["cache_write"])
        total_turns += int(m.get("num_turns", 0))
        total_wall += float(m["wall_seconds"])
        total_5m += int(m.get("cache_write_5m", 0))
        total_1h += int(m.get("cache_write_1h", 0))
        total_compaction += int(m.get("compaction_events", 0))
        total_clear += int(m.get("clear_events", 0))

    denominator = total_read + total_write + total_input
    hit_pct = round(total_read / denominator * 100, 1) if denominator else 0.0
    return {
        "input": total_input,
        "output": total_output,
        "cache_read": total_read,
        "cache_write": total_write,
        "cache_hit_pct": hit_pct,
        "wall_seconds": total_wall,
        "num_turns": total_turns,
        "cache_write_5m": total_5m,
        "cache_write_1h": total_1h,
        "compaction_events": total_compaction,
        "clear_events": total_clear,
        "cache_hit_ratio": _cache_hit_ratio(total_read, total_write, total_input),
    }


# ---------------------------------------------------------------------------
# Real-phase runner (injectable for tests)
# ---------------------------------------------------------------------------


def _run_real_phase(phase: int, fixture: str, session_mode: str) -> RunResult:
    """Run one SDK probe call for *phase*. Non-negotiable #1: strips env vars."""
    import asyncio

    from code_generator.env import strip_dangerous_env
    from code_generator.runner.options import make_agent_options

    strip_dangerous_env()
    options = make_agent_options(allowed_tools=[], model=_BENCH_MODEL)

    async def _probe() -> RunResult:
        from code_generator.runner.sdk_runner import run as sdk_run

        dummy_state = Path(tempfile.mkdtemp()) / "state.json"
        return await sdk_run(_BENCH_PROBE_PROMPT, options, logger=_LOGGER, state_path=dummy_state)

    return asyncio.run(_probe())


# ---------------------------------------------------------------------------
# Cycle builder
# ---------------------------------------------------------------------------


def _build_cycle(
    cycle_name: str,
    use_fake: bool,
    fixture: str,
    session_mode: str,
    runner_fn: Callable[[int, str, str], RunResult] | None = None,
) -> dict[str, Any]:
    """Run all eight phases and return ``{cycle_name, phases, totals}``."""
    from code_generator.runner.fake_runner import get_phase_result as _fake

    phases: dict[str, dict[str, int | float]] = {}
    for phase in range(_NUM_PHASES):
        if use_fake:
            result = _fake(phase)
        else:
            fn = runner_fn if runner_fn is not None else _run_real_phase
            result = fn(phase, fixture, session_mode)
        phases[str(phase)] = _phase_metrics(result)

    return {"cycle_name": cycle_name, "phases": phases, "totals": _aggregate_totals(phases)}


# ---------------------------------------------------------------------------
# Public helpers (exported for tests)
# ---------------------------------------------------------------------------


def _iterate_cycles(
    n: int,
    use_fake: bool,
    fixture: str,
    session_mode: str,
    _runner_override: Callable[[int, str, str], RunResult] | None = None,
) -> list[dict[str, Any]]:
    """Run *n* bench cycles; return list of cycle dicts."""
    return [
        _build_cycle(
            cycle_name=f"cycle-{i + 1}",
            use_fake=use_fake,
            fixture=fixture,
            session_mode=session_mode,
            runner_fn=_runner_override,
        )
        for i in range(n)
    ]


def _build_report(
    cycles: list[dict[str, Any]],
    *,
    fixture: str,
    session_mode: str,
    timestamp: str,
) -> dict[str, Any]:
    """Assemble the top-level bench report dict."""
    return {
        "schema_version": SCHEMA_VERSION,
        "timestamp_utc": timestamp,
        "session_mode": session_mode,
        "fixture": fixture,
        "cycles": cycles,
    }


def _write_output(path: Path | None, payload: dict[str, Any]) -> None:
    """Write *payload* as JSON atomically to *path*, or print to stdout.

    Delegates to :func:`~code_generator.commands._bench_io.write_output`.
    Kept as a named wrapper so existing test imports are not broken.
    """
    write_output(path, payload)


# ---------------------------------------------------------------------------
# Typer command
# ---------------------------------------------------------------------------


@bench_app.callback(invoke_without_command=True)
def bench_command(
    ctx: typer.Context,
    fake: Annotated[
        bool,
        typer.Option("--fake/--real", help="Use deterministic fake runner (default: --fake)."),
    ] = True,
    session_mode: Annotated[
        str,
        typer.Option("--session-mode", help="Session mode: fresh or shared."),
    ] = "fresh",
    cycles: Annotated[
        int,
        typer.Option("--cycles", help="Number of iterations to run.", min=1),
    ] = 1,
    fixture: Annotated[
        str,
        typer.Option("--fixture", help="Path to the fixture project directory."),
    ] = "",
    output: Annotated[
        str,
        typer.Option("--output", help="Write JSON to this file; omit to print to stdout."),
    ] = "",
) -> None:
    """Run a canned cycle against a fixture and write per-phase telemetry to JSON.

    Use --fake (default) for deterministic CI benchmarks.
    Use --real for subscription-backed measurements (Max plan, no API keys).
    """
    if ctx.invoked_subcommand is not None:
        return

    if session_mode not in ("fresh", "shared"):
        typer.echo(
            f"Invalid --session-mode '{session_mode}': must be 'fresh' or 'shared'", err=True
        )
        raise typer.Exit(code=2)

    resolved_fixture = fixture or str(
        Path(__file__).parent.parent.parent.parent / "tests" / "fixtures" / "bench-project"
    )

    timestamp = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    cycle_list = _iterate_cycles(
        n=cycles,
        use_fake=fake,
        fixture=resolved_fixture,
        session_mode=session_mode,
    )
    report = _build_report(
        cycle_list,
        fixture=resolved_fixture,
        session_mode=session_mode,
        timestamp=timestamp,
    )
    _write_output(Path(output) if output else None, report)


# ---------------------------------------------------------------------------
# Register subcommands
# ---------------------------------------------------------------------------

from code_generator.commands.bench_compare import compare_command  # noqa: E402
from code_generator.commands.bench_export import export_command  # noqa: E402

bench_app.command("compare")(compare_command)
bench_app.command("export")(export_command)
