"""generate command — orchestrate a full project generation pipeline.

The ``generate`` surface is a Typer sub-app so we can register
``generate ollama`` as a child subcommand (#218) alongside the default
``generate`` callback. The sub-app uses ``invoke_without_command=True``
so the existing flat ``code-generator generate …`` invocation keeps
working unchanged.
"""

from __future__ import annotations

import logging
import time
from enum import StrEnum
from pathlib import Path
from typing import Annotated, Literal

import typer

from code_generator import env
from code_generator import preflight as preflight_module
from code_generator import state as state_module
from code_generator.commands._dispatch import dispatch_orchestrator
from code_generator.commands._validators import validate_max_turns


class SessionMode(StrEnum):
    """Valid values for the --session-mode CLI flag."""

    shared = "shared"
    fresh = "fresh"
    batch = "batch"


class OllamaSessionMode(StrEnum):
    """Valid values for --session-mode on the Ollama subcommand.

    Excludes ``batch`` because the Anthropic Batch API path is not compatible
    with the Ollama-proxied Messages endpoint.
    """

    shared = "shared"
    fresh = "fresh"


class GeminiSessionMode(StrEnum):
    """Valid values for --session-mode on the Gemini subcommand.

    Excludes ``batch`` because the Anthropic Batch API path is not compatible
    with the Gemini CLI.
    """

    shared = "shared"
    fresh = "fresh"


class CodexSessionMode(StrEnum):
    """Valid values for --session-mode on the Codex subcommand.

    Excludes ``batch`` because the Anthropic Batch API path is not compatible
    with the Codex CLI.
    """

    shared = "shared"
    fresh = "fresh"


_logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Typer sub-app
# ---------------------------------------------------------------------------

generate_app = typer.Typer(
    invoke_without_command=True,
    no_args_is_help=False,
    help=(
        "Orchestrate Claude Code to generate a whole project. "
        "Default: Anthropic Max. Subcommand `ollama` runs against a local daemon."
    ),
)

# ---------------------------------------------------------------------------
# Pause guard
# ---------------------------------------------------------------------------


def _check_paused(st: state_module.State) -> bool:
    """Return True and print a message when the state is paused for rate limit.

    Args:
        st: Root state to inspect.

    Returns:
        True when the state indicates an active rate-limit pause.
    """
    if st.paused_until is not None and st.paused_until > time.time():
        remaining_s = st.paused_until - time.time()
        remaining_m = remaining_s / 60
        typer.echo(
            f"Rate-limit pause active — {remaining_m:.1f} minutes remaining. "
            "Re-run after the reset window expires.",
            err=False,
        )
        return True
    return False


# ---------------------------------------------------------------------------
# Preflight helpers
# ---------------------------------------------------------------------------


def _run_preflight(project_dir: Path) -> preflight_module.RepoInfo:  # type: ignore[name-defined]
    """Call run_preflight and translate PreflightError into exit-2.

    Prints two copy-pastable lines to stderr on failure:
    - ``preflight failed: <reason>``
    - ``fix: <fix_command>``

    Args:
        project_dir: Root directory passed to run_preflight.

    Returns:
        Validated :class:`~code_generator.repo_info.RepoInfo` on success.

    Raises:
        typer.Exit: With code 2 when preflight fails.
    """
    try:
        return preflight_module.run_preflight(project_dir)
    except preflight_module.PreflightError as err:
        typer.echo(f"preflight failed: {err.reason}", err=True)
        typer.echo(f"fix: {err.fix_command}", err=True)
        raise typer.Exit(code=2) from err


def _persist_repo_info(
    st: state_module.State,
    repo_info: preflight_module.RepoInfo,  # type: ignore[name-defined]
    state_path: Path,
) -> None:
    """Write repo_info into state and persist atomically.

    Warns when the existing state.repo disagrees with the fresh preflight
    result (e.g. the operator moved the remote), then overwrites.

    Args:
        st: Root state to mutate in place.
        repo_info: Fresh RepoInfo returned by run_preflight.
        state_path: Destination for the atomic state write.
    """
    if st.repo is not None and st.repo != repo_info:
        _logger.warning(
            "preflight: state.repo %s disagrees with fresh result %s; overwriting",
            st.repo.full,
            repo_info.full,
        )
    st.repo = repo_info
    state_module.save_state(state_path, st)


# ---------------------------------------------------------------------------
# Typer command
# ---------------------------------------------------------------------------


@generate_app.callback(invoke_without_command=True)
def generate_command(
    ctx: typer.Context,
    model: Annotated[
        str | None,
        typer.Option(
            "--model",
            help=(
                "Model tag to use for ALL phases (single-model routing). "
                "When set, overrides the per-phase Opus/Sonnet/Haiku defaults "
                "and routes every phase through the operator's configured endpoint. "
                "Preserves existing ANTHROPIC_AUTH_TOKEN + ANTHROPIC_BASE_URL from "
                "the parent environment."
            ),
            show_default=False,
        ),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--no-dry-run", help="Print what would happen without doing it."),
    ] = False,
    phase: Annotated[
        int | None,
        typer.Option("--phase", help="Run only a specific phase number."),
    ] = None,
    continue_: Annotated[
        bool,
        typer.Option("--continue/--no-continue", help="Resume a paused generation run."),
    ] = False,
    mode: Annotated[
        str,
        typer.Option("--mode", help="Generation mode: auto, single, or multi-cycle."),
    ] = "auto",
    cycle: Annotated[
        int | None,
        typer.Option("--cycle", help="Target a specific cycle (multi-cycle mode only)."),
    ] = None,
    session_mode: Annotated[
        SessionMode | None,
        typer.Option(
            "--session-mode",
            help=(
                "SDK session strategy: 'shared' reuses one client per cycle, "
                "'fresh' creates a new client per issue. [default: shared]"
            ),
            show_default=False,
            case_sensitive=False,
        ),
    ] = None,
    max_turns: Annotated[
        int | None,
        typer.Option(
            "--max-turns",
            help=(
                "Opt-in per-session turn cap for debugging or strict cost control. "
                "Omit for the default (no cap). Must be a positive integer."
            ),
            callback=validate_max_turns,
            show_default=False,
        ),
    ] = None,
) -> None:
    """Run the full code-generation pipeline (default: Anthropic Max).

    Pass --model to route all phases through a custom endpoint (e.g. a local
    Ollama daemon or a cloud proxy) instead of Anthropic Max. When --model is
    set, the existing ANTHROPIC_AUTH_TOKEN and ANTHROPIC_BASE_URL from the
    parent environment are preserved.
    """
    # A subcommand like `generate ollama` has its own body; skip the default flow.
    if ctx.invoked_subcommand is not None:
        return

    if model is not None:
        env.assert_safe_environment_custom_model()
    else:
        env.assert_safe_environment()
    env.assert_single_workspace()

    if phase is not None and continue_:
        typer.echo(
            "ERROR: --phase and --continue are mutually exclusive.",
            err=True,
        )
        raise typer.Exit(code=2)

    if cycle is not None and mode not in ("multi-cycle",) and not continue_:
        typer.echo(
            "ERROR: --cycle is only valid with --mode multi-cycle or --continue.",
            err=True,
        )
        raise typer.Exit(code=2)

    project_dir = Path.cwd()
    cg_dir = project_dir / ".code-generator"

    if not cg_dir.exists():
        typer.echo(
            "ERROR: .code-generator/ not found. Run `code-generator init` first.",
            err=True,
        )
        raise typer.Exit(code=1)

    state_path = cg_dir / "state.json"

    # Preflight: validate GitHub connectivity before any state load or dispatch.
    # PreflightError is translated to exit 2 with copy-pastable fix instructions.
    repo_info = _run_preflight(project_dir)

    st = state_module.load_state(state_path)

    # Persist the fresh RepoInfo atomically; warns when it differs from stored value.
    _persist_repo_info(st, repo_info, state_path)

    # When --model is set, stamp the tag on existing cycles so --continue
    # resolves the correct model without the operator re-typing --model.
    if model is not None:
        _stamp_model_on_existing_cycles(st, model, state_path)

    # Rate-limit pause guard: inform user and exit cleanly.
    if _check_paused(st):
        raise typer.Exit(code=0)

    # Compute current requirements hash (absent when file does not yet exist).
    req_path = cg_dir / "requirements.md"
    current_hash = state_module.compute_requirements_hash(req_path) if req_path.exists() else None

    effective_session_mode: Literal["shared", "fresh", "batch"] = (  # type: ignore[assignment]
        session_mode.value if session_mode is not None else "shared"
    )
    session_mode_explicit = session_mode is not None

    try:
        dispatch_orchestrator(
            st,
            project_dir,
            dry_run=dry_run,
            phase=phase,
            continue_=continue_,
            mode=mode,
            cycle=cycle,
            state_path=state_path,
            requirements_hash=current_hash,
            session_mode=effective_session_mode,
            session_mode_explicit=session_mode_explicit,
            max_turns=max_turns,
            ollama_model=model,
        )
    except typer.Exit:
        raise
    except NotImplementedError as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=1) from exc
    except Exception as exc:  # noqa: BLE001
        from rich.console import Console
        from rich.traceback import Traceback

        Console(stderr=True).print(Traceback())
        raise typer.Exit(code=1) from exc


# ---------------------------------------------------------------------------
# `generate ollama` subcommand (#218)
# ---------------------------------------------------------------------------


def _run_ollama_preflight_or_exit() -> None:
    """Run the Ollama preflight, translating failures into exit-2 with remediation."""
    try:
        preflight_module.run_ollama_preflight()
    except preflight_module.PreflightError as err:
        typer.echo(f"preflight failed: {err.reason}", err=True)
        typer.echo(f"fix: {err.fix_command}", err=True)
        raise typer.Exit(code=2) from err


def _stamp_model_on_existing_cycles(st: state_module.State, model: str, state_path: Path) -> None:
    """Write ``model`` into every existing CycleState.ollama_model and persist.

    New cycles created later by phase 1 will receive the model via #219's
    orchestrator threading work; this call handles the ``--continue`` path
    where cycles already exist in state.
    """
    for cycle in st.cycles:
        if isinstance(cycle, state_module.CycleState):
            cycle.ollama_model = model
    state_module.save_state(state_path, st)


def _resolve_model_from_state(st: state_module.State) -> str | None:
    """Return the most recently stamped ``ollama_model`` across cycles, or None.

    On ``--continue`` without ``--model``, the CLI reads the previously saved
    tag so the operator does not have to re-type it. Returns None when no
    cycle carries a model string.
    """
    for cycle in reversed(st.cycles):
        if isinstance(cycle, state_module.CycleState) and cycle.ollama_model:
            return cycle.ollama_model
    return None


def _run_gemini_preflight_or_exit() -> None:
    """Run the Gemini preflight, translating failures into exit-2 with remediation."""
    try:
        preflight_module.run_gemini_preflight()
    except preflight_module.PreflightError as err:
        typer.echo(f"preflight failed: {err.reason}", err=True)
        typer.echo(f"fix: {err.fix_command}", err=True)
        raise typer.Exit(code=2) from err


def _stamp_gemini_model_on_existing_cycles(
    st: state_module.State, model: str, state_path: Path
) -> None:
    """Write ``model`` into every existing CycleState.gemini_model and persist.

    Handles the ``--continue`` path where cycles already exist in state.
    """
    st.gemini_model = model
    for cycle in st.cycles:
        if isinstance(cycle, state_module.CycleState):
            cycle.gemini_model = model
    state_module.save_state(state_path, st)


def _resolve_gemini_model_from_state(st: state_module.State) -> str | None:
    """Return the most recently stamped ``gemini_model`` across cycles, or from State."""
    if st.gemini_model:
        return st.gemini_model
    for cycle in reversed(st.cycles):
        if isinstance(cycle, state_module.CycleState) and cycle.gemini_model:
            return cycle.gemini_model
    return None


def _run_codex_preflight_or_exit() -> None:
    """Run the Codex preflight, translating failures into exit-2 with remediation."""
    try:
        preflight_module.run_codex_preflight()
    except preflight_module.PreflightError as err:
        typer.echo(f"preflight failed: {err.reason}", err=True)
        typer.echo(f"fix: {err.fix_command}", err=True)
        raise typer.Exit(code=2) from err


def _stamp_codex_model_on_existing_cycles(
    st: state_module.State, model: str, state_path: Path
) -> None:
    """Write ``model`` into State.codex_model and every CycleState, then persist.

    Handles the ``--continue`` path where cycles already exist in state.
    """
    st.codex_model = model
    for cycle in st.cycles:
        if isinstance(cycle, state_module.CycleState):
            cycle.codex_model = model
    state_module.save_state(state_path, st)


def _resolve_codex_model_from_state(st: state_module.State) -> str | None:
    """Return the most recently stamped ``codex_model`` across cycles, or from State."""
    if st.codex_model:
        return st.codex_model
    for cycle in reversed(st.cycles):
        if isinstance(cycle, state_module.CycleState) and cycle.codex_model:
            return cycle.codex_model
    return None


@generate_app.command(name="ollama")
def generate_ollama_command(
    model: Annotated[
        str | None,
        typer.Option(
            "--model",
            help=(
                "Ollama model tag (drives every phase — single-model by design). "
                "Required on fresh runs; optional with --continue (resolved from state). "
                "Examples: qwen3-coder:480b:cloud, gpt-oss:120b-cloud."
            ),
            show_default=False,
        ),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--no-dry-run", help="Print what would happen without doing it."),
    ] = False,
    phase: Annotated[
        int | None,
        typer.Option("--phase", help="Run only a specific phase number."),
    ] = None,
    continue_: Annotated[
        bool,
        typer.Option("--continue/--no-continue", help="Resume a paused generation run."),
    ] = False,
    mode: Annotated[
        str,
        typer.Option("--mode", help="Generation mode: auto, single, or multi-cycle."),
    ] = "auto",
    cycle: Annotated[
        int | None,
        typer.Option("--cycle", help="Target a specific cycle (multi-cycle mode only)."),
    ] = None,
    session_mode: Annotated[
        OllamaSessionMode | None,
        typer.Option(
            "--session-mode",
            help="SDK session strategy: 'shared' (default) or 'fresh'. 'batch' is not supported.",
            show_default=False,
            case_sensitive=False,
        ),
    ] = None,
    max_turns: Annotated[
        int | None,
        typer.Option(
            "--max-turns",
            help="Opt-in per-session turn cap. Omit for no cap. Must be a positive integer.",
            callback=validate_max_turns,
            show_default=False,
        ),
    ] = None,
) -> None:
    """Run the generation pipeline against a local Ollama daemon.

    Verifies the Ollama preconditions (daemon reachable, signed in,
    ``OLLAMA_API_KEY`` set), builds the scoped Ollama environment, and
    dispatches the orchestrator with ``provider='ollama'``. The ``--model``
    tag drives every phase (single-model by design — Opus/Sonnet split from
    the Anthropic Max path is unavailable here).

    Model recommendations (Opus-grade vs. Sonnet-grade tags) live in
    ``docs/ollama-model-guide.md``.
    """
    if phase is not None and continue_:
        typer.echo("ERROR: --phase and --continue are mutually exclusive.", err=True)
        raise typer.Exit(code=2)

    project_dir = Path.cwd()
    cg_dir = project_dir / ".code-generator"
    if not cg_dir.exists():
        typer.echo(
            "ERROR: .code-generator/ not found. Run `code-generator init` first.",
            err=True,
        )
        raise typer.Exit(code=1)

    state_path = cg_dir / "state.json"

    # (1) Strip any stray ANTHROPIC_* vars from the parent process env AND
    # install the scoped Ollama routing (ANTHROPIC_AUTH_TOKEN + BASE_URL +
    # empty API_KEY) into os.environ so every in-process SDK session and
    # every subprocess Claude Code spawns inherits the localhost daemon.
    # Without this install step Claude Code rejects non-Claude model tags
    # (e.g. ``glm-5.1:cloud``) — see the 0.4.8 fix.
    env.assert_safe_environment_ollama()

    # (2) Ollama preflight — cheap env-var checks then live-daemon probe.
    _run_ollama_preflight_or_exit()

    # (3) Re-validate the #215 preconditions defensively. The returned dict is
    # intentionally discarded — the SDK and subprocess runners now inherit the
    # Ollama routing from os.environ (installed above in step 1).
    env.build_agent_env(provider="ollama")

    # (4) GitHub preflight — detect the remote and persist RepoInfo on state.
    # Phase 1 (``gh.ensure_standard_labels`` / ``create_milestone`` /
    # ``list_issues``) requires ``state.repo`` to be non-None; without this
    # call the Ollama path crashes with ``'NoneType' has no attribute 'full'``.
    repo_info = _run_preflight(project_dir)

    # (5) Resolve the effective model. --model wins; on --continue without it,
    # read the tag stamped on the most recent CycleState.
    st = state_module.load_state(state_path)
    _persist_repo_info(st, repo_info, state_path)
    effective_model = model or _resolve_model_from_state(st)
    if effective_model is None:
        typer.echo(
            "ERROR: --model is required on a fresh run. "
            "On --continue, the model is resolved from state.json.",
            err=True,
        )
        raise typer.Exit(code=2)

    # #268: advisory warning when the Ollama path carries a claude-* model tag.
    env.warn_on_claude_model_for_ollama(effective_model)

    # (6) Persist the resolved model on existing cycles before dispatch so
    #     --continue resume stays consistent across sessions. New cycles
    #     created by phase 0/1 inherit the tag via the orchestrator thread
    #     wired in issue #219.
    _stamp_model_on_existing_cycles(st, effective_model, state_path)

    req_path = cg_dir / "requirements.md"
    current_hash = state_module.compute_requirements_hash(req_path) if req_path.exists() else None

    effective_session_mode: Literal["shared", "fresh"] = (  # type: ignore[assignment]
        session_mode.value if session_mode is not None else "shared"
    )
    session_mode_explicit = session_mode is not None

    try:
        dispatch_orchestrator(
            st,
            project_dir,
            dry_run=dry_run,
            phase=phase,
            continue_=continue_,
            mode=mode,
            cycle=cycle,
            state_path=state_path,
            requirements_hash=current_hash,
            session_mode=effective_session_mode,
            session_mode_explicit=session_mode_explicit,
            max_turns=max_turns,
            ollama_model=effective_model,
        )
    except typer.Exit:
        raise
    except NotImplementedError as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=1) from exc
    except Exception as exc:  # noqa: BLE001
        from rich.console import Console
        from rich.traceback import Traceback

        Console(stderr=True).print(Traceback())
        raise typer.Exit(code=1) from exc


@generate_app.command(name="gemini")
def generate_gemini_command(
    model: Annotated[
        str | None,
        typer.Option(
            "--model",
            help=(
                "Gemini model tag. Required on fresh runs; optional with --continue. "
                "Example: gemini-2.5-pro"
            ),
            show_default=False,
        ),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--no-dry-run", help="Print what would happen without doing it."),
    ] = False,
    phase: Annotated[
        int | None,
        typer.Option("--phase", help="Run only a specific phase number."),
    ] = None,
    continue_: Annotated[
        bool,
        typer.Option("--continue/--no-continue", help="Resume a paused generation run."),
    ] = False,
    mode: Annotated[
        str,
        typer.Option("--mode", help="Generation mode: auto, single, or multi-cycle."),
    ] = "auto",
    cycle: Annotated[
        int | None,
        typer.Option("--cycle", help="Target a specific cycle (multi-cycle mode only)."),
    ] = None,
    session_mode: Annotated[
        GeminiSessionMode | None,
        typer.Option(
            "--session-mode",
            help="SDK session strategy: 'shared' (default) or 'fresh'. 'batch' is not supported.",
            show_default=False,
            case_sensitive=False,
        ),
    ] = None,
    max_turns: Annotated[
        int | None,
        typer.Option(
            "--max-turns",
            help="Opt-in per-session turn cap. Omit for no cap. Must be a positive integer.",
            callback=validate_max_turns,
            show_default=False,
        ),
    ] = None,
) -> None:
    """Run the generation pipeline using the Google Gemini CLI.

    Verifies the Gemini CLI preconditions, builds the sanitized environment,
    and dispatches the orchestrator with ``provider='gemini'``.
    """
    if phase is not None and continue_:
        typer.echo("ERROR: --phase and --continue are mutually exclusive.", err=True)
        raise typer.Exit(code=2)

    project_dir = Path.cwd()
    cg_dir = project_dir / ".code-generator"
    if not cg_dir.exists():
        typer.echo(
            "ERROR: .code-generator/ not found. Run `code-generator init` first.",
            err=True,
        )
        raise typer.Exit(code=1)

    state_path = cg_dir / "state.json"

    # (1) Sanitize environment.
    env.assert_safe_environment_gemini()

    # (2) Gemini preflight.
    _run_gemini_preflight_or_exit()

    # (3) GitHub preflight.
    repo_info = _run_preflight(project_dir)

    # (4) Resolve model and persist.
    st = state_module.load_state(state_path)
    _persist_repo_info(st, repo_info, state_path)
    effective_model = model or _resolve_gemini_model_from_state(st)
    if effective_model is None:
        typer.echo(
            "ERROR: --model is required on a fresh run. "
            "On --continue, the model is resolved from state.json.",
            err=True,
        )
        raise typer.Exit(code=2)

    _stamp_gemini_model_on_existing_cycles(st, effective_model, state_path)

    req_path = cg_dir / "requirements.md"
    current_hash = state_module.compute_requirements_hash(req_path) if req_path.exists() else None

    effective_session_mode: Literal["shared", "fresh"] = (  # type: ignore[assignment]
        session_mode.value if session_mode is not None else "shared"
    )
    session_mode_explicit = session_mode is not None

    try:
        dispatch_orchestrator(
            st,
            project_dir,
            dry_run=dry_run,
            phase=phase,
            continue_=continue_,
            mode=mode,
            cycle=cycle,
            state_path=state_path,
            requirements_hash=current_hash,
            session_mode=effective_session_mode,
            session_mode_explicit=session_mode_explicit,
            max_turns=max_turns,
            gemini_model=effective_model,
        )
    except typer.Exit:
        raise
    except NotImplementedError as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=1) from exc
    except Exception as exc:  # noqa: BLE001
        from rich.console import Console
        from rich.traceback import Traceback

        Console(stderr=True).print(Traceback())
        raise typer.Exit(code=1) from exc


@generate_app.command(name="codex")
def generate_codex_command(
    model: Annotated[
        str | None,
        typer.Option(
            "--model",
            help=(
                "Codex model tag. Required on fresh runs; optional with --continue. "
                "Example: gpt-5.5"
            ),
            show_default=False,
        ),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--no-dry-run", help="Print what would happen without doing it."),
    ] = False,
    phase: Annotated[
        int | None,
        typer.Option("--phase", help="Run only a specific phase number."),
    ] = None,
    continue_: Annotated[
        bool,
        typer.Option("--continue/--no-continue", help="Resume a paused generation run."),
    ] = False,
    mode: Annotated[
        str,
        typer.Option("--mode", help="Generation mode: auto, single, or multi-cycle."),
    ] = "auto",
    cycle: Annotated[
        int | None,
        typer.Option("--cycle", help="Target a specific cycle (multi-cycle mode only)."),
    ] = None,
    session_mode: Annotated[
        CodexSessionMode | None,
        typer.Option(
            "--session-mode",
            help="SDK session strategy: 'shared' (default) or 'fresh'. 'batch' is not supported.",
            show_default=False,
            case_sensitive=False,
        ),
    ] = None,
    max_turns: Annotated[
        int | None,
        typer.Option(
            "--max-turns",
            help="Opt-in per-session turn cap. Omit for no cap. Must be a positive integer.",
            callback=validate_max_turns,
            show_default=False,
        ),
    ] = None,
) -> None:
    """Run the generation pipeline using the OpenAI Codex CLI.

    Verifies the Codex CLI preconditions, builds the sanitized environment,
    and dispatches the orchestrator with ``provider='codex'``.
    """
    if phase is not None and continue_:
        typer.echo("ERROR: --phase and --continue are mutually exclusive.", err=True)
        raise typer.Exit(code=2)

    project_dir = Path.cwd()
    cg_dir = project_dir / ".code-generator"
    if not cg_dir.exists():
        typer.echo(
            "ERROR: .code-generator/ not found. Run `code-generator init` first.",
            err=True,
        )
        raise typer.Exit(code=1)

    state_path = cg_dir / "state.json"

    # (1) Sanitize environment.
    env.assert_safe_environment_codex()

    # (2) Codex preflight.
    _run_codex_preflight_or_exit()

    # (3) GitHub preflight.
    repo_info = _run_preflight(project_dir)

    # (4) Resolve model and persist.
    st = state_module.load_state(state_path)
    _persist_repo_info(st, repo_info, state_path)
    effective_model = model or _resolve_codex_model_from_state(st)
    if effective_model is None:
        typer.echo(
            "ERROR: --model is required on a fresh run. "
            "On --continue, the model is resolved from state.json.",
            err=True,
        )
        raise typer.Exit(code=2)

    _stamp_codex_model_on_existing_cycles(st, effective_model, state_path)

    req_path = cg_dir / "requirements.md"
    current_hash = state_module.compute_requirements_hash(req_path) if req_path.exists() else None

    effective_session_mode: Literal["shared", "fresh"] = (  # type: ignore[assignment]
        session_mode.value if session_mode is not None else "shared"
    )
    session_mode_explicit = session_mode is not None

    try:
        dispatch_orchestrator(
            st,
            project_dir,
            dry_run=dry_run,
            phase=phase,
            continue_=continue_,
            mode=mode,
            cycle=cycle,
            state_path=state_path,
            requirements_hash=current_hash,
            session_mode=effective_session_mode,
            session_mode_explicit=session_mode_explicit,
            max_turns=max_turns,
            codex_model=effective_model,
        )
    except typer.Exit:
        raise
    except NotImplementedError as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=1) from exc
    except Exception as exc:  # noqa: BLE001
        from rich.console import Console
        from rich.traceback import Traceback

        Console(stderr=True).print(Traceback())
        raise typer.Exit(code=1) from exc
