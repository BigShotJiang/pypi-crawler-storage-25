"""status command — display current project generation state."""

import shutil
import textwrap
from datetime import UTC, datetime
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from code_generator import checklist as _checklist
from code_generator import state as state_module
from code_generator.runner.types import TokenUsage
from code_generator.state_retention import CycleTelemetrySummary

_MISSING = "—"
_SCOPE_MAX_LEN = 60

# Approximate Max plan 5-hour cache_read token budget.
# Used to compute "% of 5h window" column in the cycles table.
_5H_CACHE_READ_BUDGET = 50_000_000


def status_command() -> None:
    """Show the current generation state for this project."""
    project_dir = Path.cwd()
    state_path = project_dir / ".code-generator" / "state.json"

    if not state_path.exists():
        typer.echo(
            "no .code-generator/state.json in this directory — run `code-generator init` first"
        )
        raise typer.Exit(code=0)

    st = state_module.load_state(state_path)
    terminal_width = shutil.get_terminal_size((200, 24)).columns
    console = Console(file=typer.get_text_stream("stdout"), width=max(terminal_width, 200))

    if st.last_error:
        console.print(f"[bold red]⚠ Last error: {st.last_error}[/bold red]\n")

    _render_summary_table(console, st)
    _render_checklist_summary(console, st, project_dir)
    _render_professionalized_summary(console, st, project_dir)
    _render_phase6_5_state(console, st)
    _render_phase8_state(console, st)

    if st.mode == "multi-cycle" and st.cycles:
        _render_cycles_table(console, st)
        for cycle in st.cycles:
            if isinstance(cycle, CycleTelemetrySummary):
                continue
            _render_phase6_5_state(console, cycle)
            _render_phase8_state(console, cycle)
            if not cycle.token_usage:
                continue
            console.print(f"\n[bold]{cycle.name}[/bold]")
            _render_phase_telemetry_lines(console, cycle.token_usage)
    elif st.token_usage:
        console.print()
        _render_phase_telemetry_lines(console, st.token_usage)


def _pause_remaining(state: state_module.State) -> str:
    import time

    if state.paused_until is None:
        return "-"
    remaining = state.paused_until - time.time()
    if remaining <= 0:
        return "-"
    minutes = remaining / 60
    return f"{minutes:.1f} minutes remaining"


def _sum_token_usage(token_usage: dict[str, TokenUsage]) -> TokenUsage:
    """Sum all TokenUsage values in a phase→usage mapping."""
    total = TokenUsage()
    for usage in token_usage.values():
        total += usage
    return total


def _render_summary_table(console: Console, st: state_module.State) -> None:
    table = Table(title="code-generator status")
    table.add_column("Field", style="bold")
    table.add_column("Value")

    open_issues = sum(1 for i in st.issues if i.status == "open")
    closed_issues = sum(1 for i in st.issues if i.status == "closed")

    table.add_row("mode", st.mode)
    table.add_row("current cycle", str(st.current_cycle) if st.current_cycle is not None else "-")
    table.add_row("current phase", str(st.phase) if st.phase is not None else "-")
    table.add_row("open issues", str(open_issues))
    table.add_row("closed issues", str(closed_issues))
    table.add_row("rate-limit pause", _pause_remaining(st))

    requirements_hash = getattr(st, "requirements_hash", None)
    if requirements_hash:
        table.add_row("requirements hash", str(requirements_hash)[:8])

    if st.mode == "single" and st.token_usage:
        totals = _sum_token_usage(st.token_usage)
        table.add_section()
        table.add_row("Tokens", "")
        table.add_row("  in", str(totals.input))
        table.add_row("  cache_read", str(totals.cache_read))
        table.add_row("  cache_write", str(totals.cache_write))
        table.add_row("  out", str(totals.output))

    console.print(table)


def _format_status(status: str) -> str:
    if status == "completed":
        return f"✓ {status}"
    return status


def _format_scope(scope: str) -> str:
    if not scope:
        return _MISSING
    return textwrap.shorten(scope, width=_SCOPE_MAX_LEN, placeholder="…")


def _format_depends_on(depends_on: list[int]) -> str:
    if not depends_on:
        return _MISSING
    return ", ".join(str(d) for d in depends_on)


def _format_milestone(milestone_number: int | None) -> str:
    if milestone_number is None:
        return _MISSING
    return f"#{milestone_number}"


def _format_wall_clock(started_at: str | None, finished_at: str | None) -> str:
    """Format elapsed time from ISO 8601 timestamps as Xh Ym (≥1h) or Xm Ys (<1h)."""
    if started_at is None or finished_at is None:
        return _MISSING
    start = datetime.fromisoformat(started_at.replace("Z", "+00:00")).replace(tzinfo=UTC)
    end = datetime.fromisoformat(finished_at.replace("Z", "+00:00")).replace(tzinfo=UTC)
    total_seconds = int((end - start).total_seconds())
    if total_seconds < 0:
        return _MISSING
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours >= 1:
        return f"{hours}h {minutes}m"
    return f"{minutes}m {seconds}s"


def _format_pct_5h(token_usage: dict[str, TokenUsage]) -> str:
    """Format cache_read sum as % of the 5h budget constant."""
    if not token_usage:
        return _MISSING
    total_cache_read = sum(u.cache_read for u in token_usage.values())
    pct = total_cache_read / _5H_CACHE_READ_BUDGET * 100
    return f"{pct:.1f}%"


# Canonical phase order + display labels for the per-phase telemetry block (#247).
_PHASE_LABELS: tuple[tuple[str, str], ...] = (
    ("phase0", "0"),
    ("phase1", "1"),
    ("phase2", "2"),
    ("phase3_4", "3/4"),
    ("phase5", "5"),
    ("phase6", "6"),
    ("phase6_5", "6.5"),
    ("phase7", "7"),
    ("phase8", "8"),
)


def _humanize(n: int) -> str:
    """Render *n* as a compact token count (``"12k"`` for ``12_345``).

    Values below 1000 render verbatim. Values ≥ 1000 are divided by 1000 and
    rounded with banker's rounding, matching the briefing's worked examples
    (12_499 → ``"12k"``, 12_500 → ``"12k"``).
    """
    if n < 1000:
        return str(n)
    return f"{round(n / 1000)}k"


def _phase_cache_hit_pct(usage: TokenUsage) -> int:
    """Per-phase cache hit percent, rounded to the nearest integer.

    Returns ``0`` when the denominator is zero so callers never need to guard
    against ``ZeroDivisionError``.
    """
    denominator = usage.cache_read + usage.cache_write + usage.input
    if denominator <= 0:
        return 0
    return round(usage.cache_read / denominator * 100)


def _phase_has_activity(usage: TokenUsage) -> bool:
    """Return True when *usage* records any non-zero counter worth printing."""
    return bool(
        usage.input
        or usage.output
        or usage.cache_read
        or usage.cache_write
        or usage.cache_write_5m
        or usage.cache_write_1h
    )


def _render_checklist_summary(
    console: Console, state: state_module.State, project_dir: Path
) -> None:
    """Print ``features: <done>/<total>`` from the §13 checklist (issue #251).

    Also renders a compact per-issue flag line ``issues: #N[t,r,c] …`` showing
    ``tests_passed`` / ``runtime_verified`` / ``committed`` per entry (#277).
    Prints the dim placeholder ``features: -`` when ``state.requirements_hash``
    is unset or the checklist file does not yet exist. Never crashes — purely
    informational.
    """
    if state.requirements_hash is None:
        console.print("[dim]features: -[/dim]")
        return
    checklist_path = (
        project_dir / ".code-generator" / "checklists" / f"{state.requirements_hash}.json"
    )
    if not checklist_path.exists():
        console.print("[dim]features: -[/dim]")
        return
    done, total = _checklist.done_total(checklist_path)
    console.print(f"features: {done}/{total}")
    _render_checklist_per_issue_flags(console, checklist_path)


def _render_checklist_per_issue_flags(console: Console, checklist_path: Path) -> None:
    """Render a compact ``issues: #N[t,r,c,p] …`` line — 4-flag legend (#304)."""
    entries = _checklist.load(checklist_path)
    if not entries:
        return
    tokens = [
        f"#{e.issue_number}["
        f"{'t' if e.tests_passed else '_'},"
        f"{'r' if e.runtime_verified else '_'},"
        f"{'c' if e.committed else '_'},"
        f"{'p' if getattr(e, 'professionalized', False) else '_'}]"
        for e in entries
    ]
    legend = "t=tests, r=runtime_verified, c=committed, p=professionalized"
    console.print(f"issues ({legend}): {' '.join(tokens)}", markup=False)


def _render_phase6_5_state(
    console: Console, scope: state_module.State | state_module.CycleState
) -> None:
    """Render Phase 6.5 progress: pass/fail, T3/T4 skips with reasons, VIGIL flag.

    Cycle 1 fields (``tiers_passed``/``tiers_failed``) plus Cycle 2 additions
    (``tiers_skipped``/``skip_reasons`` from #281, ``vigil_triggered`` from
    #287) are surfaced. Legacy state files without the new fields render
    without crashing — ``getattr`` defaults handle the missing-attribute case
    even when the model was loaded by an older deserializer.
    """
    progress = getattr(scope, "phase6_5", None)
    if progress is None:
        _render_vigil_warning(console, scope)
        return
    skipped_summary = _format_skipped_tiers(progress)
    console.print(
        f"Phase 6.5: attempt {progress.attempt}, "
        f"last_tier={progress.last_tier or '-'}, "
        f"passed={progress.tiers_passed}, "
        f"failed={progress.tiers_failed}, "
        f"skipped={skipped_summary}"
    )
    _render_vigil_warning(console, scope)


def _render_phase8_state(
    console: Console, scope: state_module.State | state_module.CycleState
) -> None:
    """Render a one-line Phase 8 progress summary (#304, #321).

    Uses ``getattr(scope, "phase8", None)`` so legacy state files (deserialised
    before #299) render ``Phase 8: not run`` instead of raising. ``ci_status``
    is read with ``getattr`` for pre-Cycle-3 ``Phase8Progress`` payloads (#321).
    """
    progress = getattr(scope, "phase8", None)
    if progress is None:
        console.print("[dim]Phase 8: not run[/dim]")
        return
    ci_status = getattr(progress, "ci_status", None) or "-"
    console.print(
        f"Phase 8: status={progress.status or '-'}, "
        f"ci_status={ci_status}, "
        f"attempt={progress.attempt}"
    )


def _render_professionalized_summary(
    console: Console, state: state_module.State, project_dir: Path
) -> None:
    """Print ``professionalized: <N>/<M>`` from §13 checklist (#321)."""
    if state.requirements_hash is None:
        console.print("[dim]professionalized: -[/dim]")
        return
    checklist_path = (
        project_dir / ".code-generator" / "checklists" / f"{state.requirements_hash}.json"
    )
    if not checklist_path.exists():
        console.print("[dim]professionalized: -[/dim]")
        return
    entries = _checklist.load(checklist_path)
    done = sum(1 for e in entries if getattr(e, "professionalized", False))
    console.print(f"professionalized: {done}/{len(entries)}")


def _format_skipped_tiers(progress: state_module.Phase65Progress) -> str:
    """Return ``[T3 (reason), T4 (reason)]`` style summary for skipped tiers."""
    skipped = getattr(progress, "tiers_skipped", []) or []
    reasons = getattr(progress, "skip_reasons", {}) or {}
    if not skipped:
        return "[]"
    parts = [f"{tier} ({reasons.get(tier, 'no reason')})" for tier in skipped]
    return "[" + ", ".join(parts) + "]"


def _render_vigil_warning(
    console: Console, scope: state_module.State | state_module.CycleState
) -> None:
    """Render a highlighted WARNING line when ``vigil_triggered=True`` (#287)."""
    if getattr(scope, "vigil_triggered", False):
        console.print("[bold red]VIGIL: premature 'done' detected — Phase 6.5 forced re-entry[/]")


def _render_phase_telemetry_lines(console: Console, token_usage: dict[str, TokenUsage]) -> None:
    """Print one line per non-empty phase in canonical order (#247).

    Format::

        phase <label>: in=<X>k cache_read=<X>k(<P>%)
            cache_write_5m=<X>k cache_write_1h=<X>k out=<X>k

    Phases with all-zero counters are suppressed. Non-canonical keys are
    silently skipped.
    """
    for key, label in _PHASE_LABELS:
        usage = token_usage.get(key)
        if usage is None or not _phase_has_activity(usage):
            continue
        console.print(
            f"phase {label}: "
            f"in={_humanize(usage.input)} "
            f"cache_read={_humanize(usage.cache_read)}({_phase_cache_hit_pct(usage)}%) "
            f"cache_write_5m={_humanize(usage.cache_write_5m)} "
            f"cache_write_1h={_humanize(usage.cache_write_1h)} "
            f"out={_humanize(usage.output)}"
        )


def _format_cache_hit_pct(cache_telemetry: dict[str, int | float]) -> str:
    """Format cache_hit_pct as XX.X% or '-' when telemetry is absent or all-zero.

    Args:
        cache_telemetry: The cycle's ``cache_telemetry`` dict.

    Returns:
        Formatted percentage string, or ``'-'`` when the value is zero or absent.
    """
    pct = cache_telemetry.get("cache_hit_pct", 0.0)
    if not pct:
        return "-"
    return f"{pct:.1f}%"


def _format_model(cycle: state_module.CycleState) -> str:
    """Return the provider label for a cycle's Model column (#222).

    ``ollama:<tag>`` when the cycle ran on the Ollama codepath;
    ``anthropic-max`` otherwise. The short default label keeps the column
    narrow and avoids leaking the phase-specific Opus/Sonnet split.
    """
    if cycle.ollama_model:
        return f"ollama:{cycle.ollama_model}"
    return "anthropic-max"


def _format_turns(token_usage: dict[str, TokenUsage]) -> str:
    """Format the summed ``num_turns`` across all phases of one cycle (#211).

    Returns ``'0'`` for pre-0.3.1 state.json entries whose ``TokenUsage``
    carries a zeroed ``num_turns`` default, so legacy data renders without a
    crash and without an "unknown" sentinel.
    """
    return str(_sum_token_usage(token_usage).num_turns)


def _build_cycles_table() -> Table:
    """Create and return the cycles Rich table with all column headers."""
    table = Table(title="cycles")
    for col in (
        "id",
        "name",
    ):
        table.add_column(col)
    # Model column stays full-width — Ollama tags like ``qwen3-coder:480b:cloud``
    # must not be truncated with ellipsis (issue #222).
    table.add_column("Model", no_wrap=True, overflow="fold")
    for col in (
        "status",
        "phase",
        "closed/total",
        "scope",
        "depends on",
        "milestone",
        "in",
        "cache_read",
        "cache_write",
        "out",
        "Turns",
        "wall-clock",
        "% of 5h",
        "Cache hit %",
    ):
        table.add_column(col)
    return table


def _render_full_cycle_row(cycle: state_module.CycleState, table: Table) -> None:
    """Append a full-detail row for a CycleState entry to the table."""
    closed = sum(1 for i in cycle.issues if i.status == "closed")
    total = len(cycle.issues)
    if cycle.token_usage:
        totals = _sum_token_usage(cycle.token_usage)
        tok_in, tok_cr, tok_cw, tok_out = (
            str(totals.input),
            str(totals.cache_read),
            str(totals.cache_write),
            str(totals.output),
        )
    else:
        tok_in = tok_cr = tok_cw = tok_out = _MISSING
    table.add_row(
        str(cycle.id),
        cycle.name,
        _format_model(cycle),
        _format_status(cycle.status),
        str(cycle.phase),
        f"{closed}/{total}",
        _format_scope(cycle.scope),
        _format_depends_on(cycle.depends_on),
        _format_milestone(cycle.milestone_number),
        tok_in,
        tok_cr,
        tok_cw,
        tok_out,
        _format_turns(cycle.token_usage),
        _format_wall_clock(cycle.started_at, cycle.finished_at),
        _format_pct_5h(cycle.token_usage),
        _format_cache_hit_pct(cycle.cache_telemetry),
    )


def _render_summary_cycle_row(summary: CycleTelemetrySummary, table: Table) -> None:
    """Append a compact summary row for a CycleTelemetrySummary entry to the table."""
    pct = f"{summary.cache_hit_pct:.1f}%" if summary.cache_hit_pct else "-"
    table.add_row(
        _MISSING,
        summary.cycle_name,
        _MISSING,  # Model: not retained in the compact summary
        "(summary)",
        _MISSING,
        _MISSING,
        _MISSING,
        _MISSING,
        _MISSING,
        str(summary.total_tokens),
        _MISSING,
        _MISSING,
        _MISSING,
        _MISSING,  # Turns: not retained in the compact summary
        _MISSING,
        _MISSING,
        pct,
    )


def _render_cycles_table(console: Console, st: state_module.State) -> None:
    table = _build_cycles_table()
    for cycle in st.cycles:
        if isinstance(cycle, CycleTelemetrySummary):
            _render_summary_cycle_row(cycle, table)
        else:
            _render_full_cycle_row(cycle, table)
    console.print(table)
