"""Dispatch helpers for the generate command.

Handles resolving resume parameters from CLI flags and delegating to the
async orchestration pipeline.  Separated from the Typer command definition
so both layers can be tested in isolation.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import subprocess
from typing import TYPE_CHECKING, Literal

import typer

from code_generator import memory as _memory
from code_generator.commands._crash_recovery import check_and_log_crash_recovery
from code_generator.commands._resume import next_start_phase, resolve_continue_multi_cycle
from code_generator.state import CycleState

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator import state as state_module

_logger = logging.getLogger(__name__)

__all__ = ["dispatch_async", "dispatch_orchestrator"]


# ---------------------------------------------------------------------------
# Codebase graph build (graphify subprocess)
# ---------------------------------------------------------------------------

_GRAPHIFY_TIMEOUT = int(os.environ.get("CODE_GENERATOR_GRAPHIFY_TIMEOUT", "600"))

_GRAPHIFY_EXTRACT_CMD = ["graphify", "extract", "."]
_GRAPHIFY_UPDATE_CMD = ["graphify", "update", "."]
# `extract` has no --force flag; the node-id-format repair is an AST-only
# `update --force` (no LLM cost) — verified against graphifyy 0.8.2.
_GRAPHIFY_UPDATE_FORCE_CMD = ["graphify", "update", ".", "--force"]
_GRAPHIFY_VERSION_PROBE_CMD = ["graphify", "--version"]

_SETUP_HINT = (
    "graph-report: headless extraction via `graphify extract .` was attempted "
    "automatically but failed — ensure graphify >= 0.8.1 is installed "
    "(`uv tool install --upgrade graphifyy`) or run `/graphify .` once inside "
    "Claude Code to seed the knowledge graph manually. Using fallback for now."
)

# Soft-warning floor: warn when the installed graphify is below this.
_GRAPHIFY_MIN_VERSION = (0, 8, 1)
# Node-id format break (graphifyy 0.7.18). Graphs seeded by an older binary
# carry ghost-duplicate nodes that a plain `update` will not repair, so a
# one-time `update --force` is run when the per-checkout stamp is missing or
# older than this. Distinct from the soft-warning floor above.
_GRAPHIFY_NODEID_FLOOR = (0, 7, 18)
# Per-checkout stamp recording the graphify version that last (re)built the
# graph. Lives beside graph.json in the gitignored graphify-out/ dir.
_GRAPHIFY_STAMP_NAME = ".graphify_min_version"
_GRAPHIFY_UPGRADE_HINT = (
    "upgrade graphify for idempotent updates and stable node IDs: "
    "`uv tool install --upgrade graphifyy` (preferred) or `pip install -U graphifyy`"
)


#: First ``MAJOR.MINOR.PATCH`` token anywhere in a string. No leading word
#: boundary so a ``v`` prefix (``v0.8.1``) still matches; the lookbehind keeps
#: it from grabbing the tail of a longer number.
_SEMVER_RE = re.compile(r"(?<!\d)(\d+)\.(\d+)\.(\d+)")


def _parse_version_line(stdout: str) -> str | None:
    """Return 'X.Y.Z' from pip-show stdout, or None when the line is absent."""
    for line in stdout.splitlines():
        if line.startswith("Version:"):
            return line.split(":", 1)[1].strip()
    return None


def _parse_graphify_version_output(text: str) -> str | None:
    """Return the first 'X.Y.Z' token in *text*, or None when absent.

    Tolerates ``graphify 0.8.2``, ``graphify, version v0.8.2``, ``v0.8.2``
    and a bare ``0.8.2``.
    """
    match = _SEMVER_RE.search(text)
    return ".".join(match.groups()) if match else None


def _version_tuple(version_str: str | None) -> tuple[int, ...] | None:
    """Parse 'X.Y.Z' into an int tuple; None when *version_str* is unusable."""
    if not version_str:
        return None
    parts = tuple(int(p) for p in version_str.split(".") if p.isdigit())
    return parts or None


def _get_graphify_version_str() -> str | None:
    """Probe the installed graphify version; None on any failure.

    Prefers ``graphify --version`` (available since graphifyy 0.7.15 — the
    canonical source, and the only one that sees pipx/uv-tool installs that
    ``pip show`` in a different environment would miss).  ``graphify
    --version`` writes the version to stdout; stderr may carry an unrelated
    stale-skill warning whose own version token must not be picked up, so
    stdout is scanned first.  Falls back to ``pip show graphifyy`` for
    pre-0.7.15 binaries that reject ``--version``.
    """
    try:
        result = subprocess.run(
            _GRAPHIFY_VERSION_PROBE_CMD,
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        if result.returncode == 0:
            version = _parse_graphify_version_output(
                result.stdout or ""
            ) or _parse_graphify_version_output(result.stderr or "")
            if version is not None:
                return version
    except (OSError, subprocess.SubprocessError):
        pass

    try:
        result = subprocess.run(
            ["pip", "show", "graphifyy"], capture_output=True, text=True, check=False
        )
        return _parse_version_line(result.stdout or "")
    except (OSError, subprocess.SubprocessError):
        return None


def _probe_graphify_version(log: logging.Logger) -> None:
    """Warn when graphify is below _GRAPHIFY_MIN_VERSION or undetectable."""
    version_str = _get_graphify_version_str()
    version = _version_tuple(version_str)
    if version is None:
        log.warning("graph-report: graphify version unknown — %s", _GRAPHIFY_UPGRADE_HINT)
        return
    if version < _GRAPHIFY_MIN_VERSION:
        log.warning("graph-report: graphify %s detected — %s", version_str, _GRAPHIFY_UPGRADE_HINT)


def _decode_stderr(stderr: bytes | str | None) -> str:
    """Decode subprocess stderr to a short single-line string for logging."""
    if stderr is None:
        return ""
    text = stderr.decode("utf-8", errors="replace") if isinstance(stderr, bytes) else stderr
    text = text.strip().replace("\n", " | ")
    return text[:500]


def _extract_argv(provider: str) -> list[str]:
    """Build graphify extract argv, appending --backend ollama only for Ollama.

    ``--backend ollama`` is Ollama-specific. The Gemini and anthropic-max
    paths must not pass it, so the gate is on ``provider``, not on whether
    any model tag is present.
    """
    if provider == "ollama":
        return [*_GRAPHIFY_EXTRACT_CMD, "--backend", "ollama"]
    return list(_GRAPHIFY_EXTRACT_CMD)


def _run_graphify(
    cmd: list[str],
    project_dir: Path,
    log: logging.Logger,
    memories_dir: Path,
) -> bool:
    """Run a graphify subprocess. Write fallback and return False on any error."""
    try:
        log.info("graph-report: running %s", " ".join(cmd))
        subprocess.run(  # noqa: S603
            cmd,
            cwd=project_dir,
            timeout=_GRAPHIFY_TIMEOUT,
            capture_output=True,
            check=True,
        )
        return True
    except subprocess.CalledProcessError as exc:
        stderr = _decode_stderr(exc.stderr)
        log.warning(
            "graph-report: graphify exited %d; using fallback. stderr: %s",
            exc.returncode,
            stderr or "<empty>",
        )
    except subprocess.TimeoutExpired as exc:
        log.warning("graph-report: graphify timed out after %ss; using fallback", exc.timeout)
    except (FileNotFoundError, OSError) as exc:
        log.warning("graph-report: could not invoke graphify (%s); using fallback", exc)
    _memory.write_memory_file(memories_dir, "cycle-repo-map.md", _memory.REPOMAP_FALLBACK)
    return False


def _read_version_stamp(graphify_out: Path) -> tuple[int, ...] | None:
    """Return the graphify version recorded in the stamp file, or None."""
    stamp = graphify_out / _GRAPHIFY_STAMP_NAME
    try:
        return _version_tuple(stamp.read_text(encoding="utf-8").strip())
    except (FileNotFoundError, OSError):
        return None


def _write_version_stamp(graphify_out: Path, version_str: str) -> None:
    """Atomically record *version_str* as the builder of the current graph.

    Best-effort: a failed write just leaves the stamp missing, so the next
    run re-runs the one-time forced reseed rather than corrupting state.
    """
    stamp = graphify_out / _GRAPHIFY_STAMP_NAME
    tmp = stamp.parent / (stamp.name + ".tmp")
    try:
        tmp.write_text(version_str, encoding="utf-8")
        os.replace(tmp, stamp)
    except OSError as exc:
        _logger.debug("graph-report: could not write graphify stamp (%s)", exc)


def _compute_and_persist_graph_report(
    project_dir: Path, log: logging.Logger, *, provider: str = "anthropic-max"
) -> None:
    """Refresh the codebase graph via graphify and persist the report.

    Strategy:

    1. If ``graphify-out/graph.json`` does **not** exist, run
       ``graphify extract .`` (headless LLM-driven seeding, requires >= 0.8.1).
       On success, read ``GRAPH_REPORT.md`` and persist.  On failure, write the
       fallback sentinel and emit :data:`_SETUP_HINT`.

    2. If it exists, run ``graphify update .`` (AST-only refresh, no LLM cost).
       Refreshes ``graph.json`` and ``GRAPH_REPORT.md``.  When the per-checkout
       stamp (``graphify-out/.graphify_min_version``) is absent or older than
       the 0.7.18 node-id-format break, a one-time ``graphify update .
       --force`` reseed runs first (still AST-only, no LLM cost) and the stamp
       is written with the detected graphify version.

    Falls back to :data:`code_generator.memory.REPOMAP_FALLBACK` on any
    failure (binary missing, timeout, non-zero exit, missing report file).

    Args:
        project_dir: Project root directory.
        log: Phase logger.
    """
    memories_dir = project_dir / ".code-generator" / "memories"
    report_path = project_dir / "graphify-out" / "GRAPH_REPORT.md"
    graph_json = project_dir / "graphify-out" / "graph.json"

    if shutil.which("graphify") is None:
        log.warning(
            "graph-report: graphify binary not found; install via "
            "`uv tool install --upgrade graphifyy` (or `pip install -U "
            "graphifyy`). Using fallback."
        )
        _memory.write_memory_file(memories_dir, "cycle-repo-map.md", _memory.REPOMAP_FALLBACK)
        return

    if not graph_json.exists():
        log.info("graph-report: graph.json absent — attempting headless extraction")
        if not _run_graphify(_extract_argv(provider), project_dir, log, memories_dir):
            log.info(_SETUP_HINT)
            return
    else:
        _probe_graphify_version(log)
        graphify_out = graph_json.parent
        stamp = _read_version_stamp(graphify_out)
        if stamp is None or stamp < _GRAPHIFY_NODEID_FLOOR:
            log.info(
                "graph-report: graph predates node-id format %s — running "
                "one-time `graphify update . --force` reseed",
                ".".join(map(str, _GRAPHIFY_NODEID_FLOOR)),
            )
            if not _run_graphify(_GRAPHIFY_UPDATE_FORCE_CMD, project_dir, log, memories_dir):
                return
            detected = _get_graphify_version_str() or ".".join(map(str, _GRAPHIFY_NODEID_FLOOR))
            _write_version_stamp(graphify_out, detected)
        elif not _run_graphify(_GRAPHIFY_UPDATE_CMD, project_dir, log, memories_dir):
            return

    try:
        content = report_path.read_text(encoding="utf-8")
    except (FileNotFoundError, OSError) as exc:
        log.warning(
            "graph-report: graphify exited 0 but %s is missing (%s); using fallback",
            report_path.name,
            exc,
        )
        _memory.write_memory_file(memories_dir, "cycle-repo-map.md", _memory.REPOMAP_FALLBACK)
        return

    log.info("graph-report: built (%d chars / ~%d tokens)", len(content), len(content) // 4)
    _memory.write_memory_file(memories_dir, "cycle-repo-map.md", content)


def _warn_on_drift(st: state_module.State, logger: logging.Logger) -> None:
    """Emit WARNING logs when prompt hashes or SDK version have drifted.

    Computes current prompt hashes and SDK version, delegates the comparison
    to the pure :func:`~code_generator.state.warn_on_prompt_or_sdk_drift`
    helper, then emits each returned string via *logger*.

    Args:
        st: Root state carrying stored ``prompt_hashes`` and ``sdk_version``.
        logger: Logger used to emit WARNING-level messages.
    """
    from code_generator import state as _state_module
    from code_generator.env import detect_sdk_version
    from code_generator.prompts.hashes import compute_all_prompt_hashes

    warnings = _state_module.warn_on_prompt_or_sdk_drift(
        st, compute_all_prompt_hashes(), detect_sdk_version()
    )
    for message in warnings:
        logger.warning(message)


def _reset_failed_cycles_for_continue(
    st: state_module.State,
    *,
    target_cycle: int | None,
    state_path: Path,
) -> None:
    """Reset ``failed`` cycles back to ``open`` on ``--continue``.

    When a cycle crashes mid-run, ``cycle_loop.run_multi_cycle`` marks it as
    ``status="failed"`` and persists the exception in ``state.last_error``.
    The next ``--continue`` must treat these as retryable, otherwise the user
    has to hand-edit ``state.json`` every time a cycle crashes — which
    defeats the whole point of ``--continue``.

    When ``target_cycle`` is set (``--cycle N``), only that cycle is reset.
    Otherwise every failed cycle is reset. ``state.last_error`` and
    ``state.rate_limit_type`` are cleared on any successful reset so the
    status line stops showing red for a resolved failure.

    Args:
        st: Root state (mutated in place).
        target_cycle: When set, only reset this cycle id; otherwise reset all.
        state_path: Path to ``state.json`` for atomic persistence.
    """
    from code_generator import state as _state_module

    reset_ids: list[int] = []
    for c in st.cycles:
        if not isinstance(c, CycleState):
            continue
        if c.status != "failed":
            continue
        if target_cycle is not None and c.id != target_cycle:
            continue
        c.status = "open"
        reset_ids.append(c.id)

    if not reset_ids:
        return

    if getattr(st, "last_error", None):
        st.last_error = None
    if getattr(st, "rate_limit_type", None):
        st.rate_limit_type = None

    _state_module.save_state(state_path, st)
    _logger.info(
        "--continue: reset failed cycles to open: %s",
        ", ".join(str(i) for i in reset_ids),
    )


async def _apply_delta_plan(
    st: state_module.State,
    project_dir: Path,
    *,
    runner_module: object,
    delta_hash: str,
    state_path: Path,
    logger: logging.Logger,
    effective_model: str | None = None,
    provider: str = "anthropic-max",
) -> int | None:
    """Run Phase 0 and merge new cycles into state for multi-cycle delta planning.

    Atomicity guarantee: state is only mutated after a successful Phase 0
    response.  If Phase 0 fails, a ``RuntimeError`` is raised and neither
    ``state.cycles`` nor ``state.requirements_hash`` is changed.

    Args:
        st: Root state (mutated in place on success).
        project_dir: Project root directory.
        runner_module: Runner module for Phase 0 execution.
        delta_hash: The new requirements hash to store on success.
        state_path: Path to state.json for atomic persistence.
        logger: Phase logger.

    Returns:
        ID of the first newly appended cycle, or ``None`` when the new plan
        contains no scopes that are not already in ``state.cycles``.

    Raises:
        RuntimeError: When Phase 0 returns ``None`` (all retries exhausted).
    """
    from code_generator import state as state_module
    from code_generator.orchestrator import phase0_complexity

    raw_cycles = await phase0_complexity.get_raw_cycle_plan(
        project_dir,
        runner_module=runner_module,  # type: ignore[arg-type]
        logger=logger,
        effective_model=effective_model,
    )

    if raw_cycles is None:
        raise RuntimeError(
            "Phase 0 failed during delta planning; aborting to preserve cycle history."
        )

    new_cycles = state_module.append_new_cycles(
        st,
        raw_cycles,
        ollama_model=effective_model if provider == "ollama" else None,
        gemini_model=effective_model if provider == "gemini" else None,
        codex_model=effective_model if provider == "codex" else None,
    )

    if not new_cycles:
        logger.info("Delta planning: no new cycles detected.")
        st.requirements_hash = delta_hash
        state_module.save_state(state_path, st)
        return None

    # Extend state atomically: build new list, then assign all at once.
    st.cycles = list(st.cycles) + new_cycles
    st.current_cycle = new_cycles[0].id
    st.requirements_hash = delta_hash
    state_module.save_state(state_path, st)
    return new_cycles[0].id


async def dispatch_async(
    st: state_module.State,
    project_dir: Path,
    *,
    dry_run: bool,
    start_phase: int,
    start_cycle: int | None,
    mode: str,
    delta_hash: str | None = None,
    state_path: Path | None = None,
    session_mode: Literal["shared", "fresh", "batch"] = "shared",
    max_turns: int | None = None,
    ollama_model: str | None = None,
    gemini_model: str | None = None,
    codex_model: str | None = None,
) -> None:
    """Async entry point for the orchestration pipeline.

    Args:
        st: Root state object.
        project_dir: Project root directory.
        dry_run: When True, only phases 0 and 1 run.
        start_phase: Resume from this phase (1 = full run).
        start_cycle: Resume from this cycle (multi-cycle only).
        mode: ``"auto"``, ``"single"``, or ``"multi-cycle"``.
        delta_hash: When set, triggers delta planning for multi-cycle mode
            with completed cycles (the new requirements hash to persist on
            success).  ``None`` disables delta planning.
        state_path: Path to state.json; required when ``delta_hash`` is set.
        session_mode: SDK session strategy to thread to the cycle loop.
        max_turns: Optional per-session turn cap.
        ollama_model: Optional Ollama model override.
        gemini_model: Optional Gemini model override.
        codex_model: Optional Codex model override.
    """
    from code_generator import env as _env
    from code_generator.logging_setup import setup_phase_logger
    from code_generator.orchestrator import cycle_loop, phase0_complexity
    from code_generator.runner import get_runner

    provider: _env.Provider = "anthropic-max"
    if codex_model is not None:
        provider = "codex"
    elif ollama_model is not None:
        provider = "ollama"
    elif gemini_model is not None:
        provider = "gemini"

    runner_module = get_runner(provider=provider)
    logger = setup_phase_logger("generate", project_dir)

    # Build the codebase graph once at the top of dispatch so Phase 0
    # (complexity analysis) sees a fresh report alongside Phases 1 and 2.
    graph_logger = setup_phase_logger("graph-report", project_dir)
    _compute_and_persist_graph_report(project_dir, graph_logger, provider=provider)

    # Phase 0: determine mode when not already known.
    if mode == "auto":
        needs_phase0 = st.mode not in ("single", "multi-cycle")
    else:
        needs_phase0 = False
        # Force the mode from the flag.
        st.mode = mode  # type: ignore[assignment]

    # Delta planning: multi-cycle with completed cycles needs a merge, not a
    # fresh Phase 0 run.  Single-mode delta is handled upstream (mode reset to
    # "unknown" forces Phase 0 to re-run via needs_phase0=True).
    completed = [c for c in st.cycles if isinstance(c, CycleState) and c.status == "completed"]
    if delta_hash is not None and st.mode == "multi-cycle" and completed and state_path is not None:
        first_new_id = await _apply_delta_plan(
            st,
            project_dir,
            runner_module=runner_module,
            delta_hash=delta_hash,
            state_path=state_path,
            logger=logger,
            effective_model=codex_model or gemini_model or ollama_model,
            provider=provider,
        )
        if first_new_id is None:
            return  # No new cycles — nothing to run.
        start_cycle = first_new_id
        start_phase = 1
        needs_phase0 = False

    if needs_phase0:
        await phase0_complexity.run(
            st,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            effective_model=codex_model or gemini_model or ollama_model,
        )

    # Dry-run: planning only (phase 0 + phase 1).
    if dry_run:
        from code_generator.orchestrator import phase1_plan

        logger.info("--dry-run: running phase 1 (planning only).")
        await phase1_plan.run(
            st,
            None,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            effective_model=codex_model or gemini_model or ollama_model,
        )
        return

    # Dispatch to cycle loop.
    if st.mode == "multi-cycle":
        await cycle_loop.run_multi_cycle(
            st,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            start_cycle=start_cycle,
            start_phase=start_phase,
            session_mode=session_mode,
            max_turns=max_turns,
            effective_model=codex_model or gemini_model or ollama_model,
        )
    else:
        await cycle_loop.run_single_mode(
            st,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            start_phase=start_phase,
            session_mode=session_mode,
            max_turns=max_turns,
            effective_model=codex_model or gemini_model or ollama_model,
        )

    # Full run completed successfully (pauses/errors raised out of run_*
    # above and never reach here; --dry-run / delta-noop returned earlier).
    # Snapshot this run's artifacts; never raises.
    from code_generator.archive_run import archive_completed_run

    archive_completed_run(project_dir, st, logger)


def _apply_session_mode(
    st: state_module.State,
    *,
    continue_: bool,
    session_mode: Literal["shared", "fresh", "batch"],
    session_mode_explicit: bool,
    state_path: Path,
) -> None:
    """Persist or validate session_mode depending on whether this is a fresh or resume run.

    On a fresh run (not ``--continue``): write ``session_mode`` to state and persist.
    On ``--continue`` with an explicit flag: call ``assert_session_mode_compatible``
    and translate any ``ValueError`` to ``typer.Exit(code=2)``.
    On ``--continue`` without an explicit flag: inherit the stored value silently.

    Args:
        st: Root state (mutated in place on fresh run).
        continue_: Whether the user passed ``--continue``.
        session_mode: The resolved session mode from the CLI flag.
        session_mode_explicit: True when the user explicitly passed ``--session-mode``.
        state_path: Destination for atomic state persistence.

    Raises:
        typer.Exit: With code 2 on a session-mode mismatch during ``--continue``.
    """
    from code_generator import state as state_module

    if not continue_:
        st.session_mode = session_mode  # type: ignore[assignment]
        state_module.save_state(state_path, st)
        return

    if session_mode_explicit:
        try:
            state_module.assert_session_mode_compatible(st, session_mode)
        except ValueError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(code=2) from exc


def dispatch_orchestrator(
    st: state_module.State,
    project_dir: Path,
    *,
    dry_run: bool,
    phase: int | None,
    continue_: bool,
    mode: str,
    cycle: int | None,
    state_path: Path,
    requirements_hash: str | None = None,
    session_mode: Literal["shared", "fresh", "batch"] = "shared",
    session_mode_explicit: bool = False,
    max_turns: int | None = None,
    ollama_model: str | None = None,
    gemini_model: str | None = None,
    codex_model: str | None = None,
) -> None:
    """Resolve resume parameters and dispatch the async orchestrator.

    Args:
        st: Root state.
        project_dir: Project root directory.
        dry_run: When True, only phase 0/1 planning runs.
        phase: Resume from this explicit phase number.
        continue_: Resume from the last completed phase/cycle in state.
        mode: ``"auto"``, ``"single"``, or ``"multi-cycle"``.
        cycle: Resume from this specific cycle (multi-cycle only).
        state_path: Path to state.json, used for atomic hash updates.
        requirements_hash: SHA-256 digest of the current requirements.md, or
            None when the file is absent (detection is skipped).
        session_mode: SDK session strategy (``"shared"``, ``"fresh"``, or ``"batch"``).
        session_mode_explicit: True when the operator explicitly passed
            ``--session-mode``; governs mismatch-check on ``--continue``.
        max_turns: Optional per-session turn cap.
        ollama_model: Optional Ollama model override.
        gemini_model: Optional Gemini model override.
        codex_model: Optional Codex model override.
    """
    from code_generator import state as state_module

    # Re-run detection: only when no explicit resume flags override intent.
    # --continue and --phase N express explicit user intent, so they bypass
    # detection entirely to avoid surprising "nothing to do" responses.
    delta_hash_for_async: str | None = None
    if not continue_ and phase is None and requirements_hash is not None:
        from code_generator.commands._detect import detect_run_mode

        run_mode = detect_run_mode(st, requirements_hash)

        if run_mode == "no-op":
            _logger.info("nothing to do: all cycles complete, requirements unchanged")
            typer.echo("All cycles complete. Nothing to do.")
            return

        if run_mode == "first-run":
            st.requirements_hash = requirements_hash
            state_module.save_state(state_path, st)

        elif run_mode == "delta":
            completed = [
                c for c in st.cycles if isinstance(c, CycleState) and c.status == "completed"
            ]
            if st.mode == "multi-cycle" and completed:
                # Defer hash update to async path — atomicity requires Phase 0
                # to succeed before we store the new hash.
                delta_hash_for_async = requirements_hash
            else:
                # Single mode or no completed cycles: treat as fresh run from Phase 0.
                # Reset mode to "unknown" so Phase 0 re-runs and re-evaluates complexity.
                st.mode = "unknown"  # type: ignore[assignment]
                st.requirements_hash = requirements_hash
                state_module.save_state(state_path, st)

    # Resolve effective mode (honor existing state when --mode auto).
    effective_mode = mode
    if mode == "auto" and st.mode in ("single", "multi-cycle"):
        effective_mode = st.mode

    # Resolve start_phase and start_cycle.
    # Flag precedence (highest → lowest):
    #   1. --continue  → derive start_cycle + start_phase from state (last completed)
    #   2. --phase N   → explicit phase; start_cycle stays None (single-mode default)
    #   3. --cycle N   → overrides any continue-derived start_cycle; start_phase
    #                    defaults to 1 unless --phase N is also given
    #   4. (none)      → fresh run from phase 1, cycle None
    start_phase = 1
    start_cycle: int | None = None

    # Persist or validate session_mode before any async work.
    _apply_session_mode(
        st,
        continue_=continue_,
        session_mode=session_mode,
        session_mode_explicit=session_mode_explicit,
        state_path=state_path,
    )

    if continue_:
        # A cycle that crashed mid-run is marked "failed" by the exception
        # handler in cycle_loop.run_multi_cycle. Without this reset, `--continue`
        # would skip it forever because `_eligible_cycles` only returns "open"
        # cycles. Semantically, `--continue` means "retry from where we
        # crashed", so flip any failed cycle back to "open" and clear the
        # stale error. Explicit --cycle N also benefits: reset just the target.
        _reset_failed_cycles_for_continue(st, target_cycle=cycle, state_path=state_path)

        # Crash-recovery FSM: log diagnostic when client_alive_at is within TTL.
        # This means the client was orphaned by a crash; the cycle loop will open
        # a fresh client on resume regardless.  Silent when client_alive_at is
        # None (normal resume after rate-limit pause) or outside the TTL window.
        check_and_log_crash_recovery(st)

        # §17: Warn on prompt-file or SDK-version drift since cycle start.
        _warn_on_drift(st, _logger)

        # Resume from the *next* phase/cycle after the last completed one.
        if effective_mode == "multi-cycle":
            start_cycle, start_phase = resolve_continue_multi_cycle(st)
        else:
            start_phase = next_start_phase(st)

    elif phase is not None:
        start_phase = phase

    if cycle is not None:
        # --cycle N overrides any continue-derived start_cycle.
        start_cycle = cycle
        start_phase = phase or 1

    # Effective session_mode for the async path: on --continue without an
    # explicit flag, inherit the value already stored in state (set above or
    # pre-existing from the original run).
    effective_session_mode: Literal["shared", "fresh", "batch"] = st.session_mode  # type: ignore[assignment]

    asyncio.run(
        dispatch_async(
            st,
            project_dir,
            dry_run=dry_run,
            start_phase=start_phase,
            start_cycle=start_cycle,
            mode=effective_mode,
            delta_hash=delta_hash_for_async,
            state_path=state_path,
            session_mode=effective_session_mode,
            max_turns=max_turns,
            ollama_model=ollama_model,
            gemini_model=gemini_model,
            codex_model=codex_model,
        )
    )
