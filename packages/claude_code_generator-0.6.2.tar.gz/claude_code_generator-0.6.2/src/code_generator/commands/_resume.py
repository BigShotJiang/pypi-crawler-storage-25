"""Resume helpers for the generate command.

Derives ``start_phase`` and ``start_cycle`` from persisted state when the user
passes ``--continue``.  These functions are pure (no I/O) so they are easy to
unit-test in isolation.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from code_generator import state as state_module

from code_generator.state import CycleState

_logger = logging.getLogger(__name__)

__all__ = ["next_start_phase", "resolve_continue_multi_cycle"]


def next_start_phase(st: state_module.State) -> int:
    """Return the phase to resume from after ``--continue``.

    ``state.phase`` records the last *completed* phase, so the next phase to
    run is always ``phase + 1``.  When no prior phase is recorded (fresh run),
    start from phase 1. Phase 6.5 (#276) is recorded as 65 — after a successful
    Phase 6.5 the next phase is Phase 7, so the special case maps 65 → 7.
    Phase 8 (#304) is the terminal phase — resuming after it returns 8 again
    (idempotent), never 9.
    """
    from code_generator.orchestrator.cycle_loop import (
        _PHASE_COMMIT,
        _PHASE_PROFESSIONALIZE,
        _PHASE_VERIFY,
    )

    phase = st.phase or 0
    if phase == _PHASE_PROFESSIONALIZE:
        return _PHASE_PROFESSIONALIZE
    if phase == _PHASE_VERIFY:
        return _PHASE_COMMIT
    return phase + 1


def resolve_continue_multi_cycle(
    st: state_module.State,
) -> tuple[int | None, int]:
    """Return ``(start_cycle, start_phase)`` for a ``--continue`` in multi-cycle mode.

    Rules:
    - When ``current_cycle`` is *completed* (all phases done), advance to the
      next cycle and restart from phase 1 — the completed cycle must not be
      re-entered.
    - When ``current_cycle`` is still *open* (interrupted mid-cycle), resume
      within that cycle at the next phase.
    - When no ``current_cycle`` is recorded, return ``(None, 1)`` for a full run.

    Args:
        st: Root state.

    Returns:
        Tuple of ``(start_cycle, start_phase)`` to pass to ``run_multi_cycle``.
    """
    if st.current_cycle is None:
        return None, 1

    current = next(
        (c for c in st.cycles if isinstance(c, CycleState) and c.id == st.current_cycle),
        None,
    )
    if current is not None and current.status == "completed":
        next_cycle_id = st.current_cycle + 1
        has_next = any(isinstance(c, CycleState) and c.id == next_cycle_id for c in st.cycles)

        # Route to Phase 8 only if:
        # 1. The next cycle doesn't exist (it's the final cycle)
        # 2. Phase 8 hasn't completed yet (status != "ok")
        #
        # If phase8.status == "ok", the cycle loop already ran Phase 8 on a prior
        # resume, so advance to the next cycle (even though it doesn't exist) so
        # the cycle loop can detect no eligible cycles and exit normally.
        if not has_next:
            phase8 = getattr(st, "phase8", None)
            if phase8 is None or getattr(phase8, "status", None) != "ok":
                from code_generator.orchestrator.cycle_loop import (
                    _PHASE_PROFESSIONALIZE,
                )

                return None, _PHASE_PROFESSIONALIZE
        return next_cycle_id, 1

    if current is not None:
        from code_generator.orchestrator.cycle_loop import _PHASE_COMMIT, _PHASE_VERIFY

        cycle_phase = current.phase or 0
        if cycle_phase == _PHASE_VERIFY:
            # Phase 6.5 just completed — resume at Phase 7.
            start_phase = _PHASE_COMMIT
        elif cycle_phase < _PHASE_COMMIT:
            start_phase = cycle_phase + 1
        else:
            # Phase 7 with non-completed status → retry commit (don't advance beyond 7).
            start_phase = _PHASE_COMMIT
        return st.current_cycle, start_phase

    _logger.warning(
        "No cycle record found for current_cycle=%d; defaulting to phase 1.",
        st.current_cycle,
    )
    return st.current_cycle, 1
