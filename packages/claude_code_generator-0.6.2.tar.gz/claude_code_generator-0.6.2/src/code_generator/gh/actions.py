"""Thin ``gh`` CLI wrappers for GitHub Actions workflow runs and job logs.

Pure data-extraction primitives consumed by the Phase 8 CI poll-and-repair
loop. No polling, no retry, no business logic — callers compose with
``runner/retry.with_backoff`` for cadence.

All three wrappers route through :func:`code_generator.gh.core._run` and pass
``env={"GH_HOST": repo.host}`` to keep credentials scoped per-host, matching
the convention established by :mod:`code_generator.gh.issues`.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, TypedDict

from code_generator.gh.core import GhError, _run

if TYPE_CHECKING:
    from code_generator.repo_info import RepoInfo

LOG_TRUNCATE_LIMIT = 8000
"""Max chars of failing-job log returned by :func:`get_failing_job_logs`.

The repair agent prompt is the consumer; 8 000 chars is the budget that
fits inside one Sonnet 4.6 turn without crowding out the rest of the
boundary user-message.
"""

_LIST_FIELDS = "databaseId,status,conclusion,workflowName,createdAt"
_VIEW_FIELDS = "status,conclusion,jobs"


class WorkflowRun(TypedDict):
    """Shape of a single entry returned by :func:`list_workflow_runs`."""

    databaseId: int
    status: str
    conclusion: str | None
    workflowName: str
    createdAt: str


def list_workflow_runs(repo: RepoInfo, sha: str) -> list[dict]:  # type: ignore[type-arg]
    """List workflow runs for *sha*; empty list when none exist yet.

    Args:
        repo: Repository to target (drives ``--repo`` flag + ``GH_HOST`` env).
        sha: Commit SHA to filter runs on.

    Returns:
        Parsed list of run records. Empty list when no runs have been
        registered for *sha* yet — ``gh run list`` may exit 0 with ``[]``
        or exit 1 with ``"no runs found"`` immediately after a push; both
        collapse to ``[]`` here so the caller's poll loop can treat them
        uniformly.

    Raises:
        GhError: For any non-zero exit code other than 1 (e.g. auth failure).
    """
    argv = [
        "gh",
        "run",
        "list",
        "--repo",
        repo.full,
        "--commit",
        sha,
        "--json",
        _LIST_FIELDS,
    ]
    try:
        raw = _run(argv, env={"GH_HOST": repo.host})
    except GhError as err:
        if err.returncode == 1:
            return []
        raise
    return json.loads(raw)  # type: ignore[no-any-return]


def view_run(repo: RepoInfo, run_id: int) -> dict:  # type: ignore[type-arg]
    """Fetch a single workflow run with status, conclusion, and jobs.

    Args:
        repo: Repository to target.
        run_id: GitHub Actions run ``databaseId``.

    Returns:
        Parsed dict with keys ``status``, ``conclusion``, ``jobs``.

    Raises:
        GhError: When ``gh run view`` exits non-zero.
    """
    argv = [
        "gh",
        "run",
        "view",
        str(run_id),
        "--repo",
        repo.full,
        "--json",
        _VIEW_FIELDS,
    ]
    raw = _run(argv, env={"GH_HOST": repo.host})
    return json.loads(raw)  # type: ignore[no-any-return]


def get_failing_job_logs(repo: RepoInfo, run_id: int) -> str:
    """Return the failing-job logs for *run_id*, tail-truncated.

    Args:
        repo: Repository to target.
        run_id: GitHub Actions run ``databaseId``.

    Returns:
        Plain log text. When the raw output exceeds
        :data:`LOG_TRUNCATE_LIMIT`, only the last ``LOG_TRUNCATE_LIMIT``
        chars are returned — the tail contains the actual failure marker,
        not the setup chatter.

    Raises:
        GhError: When ``gh run view --log-failed`` exits non-zero.
    """
    argv = [
        "gh",
        "run",
        "view",
        str(run_id),
        "--repo",
        repo.full,
        "--log-failed",
    ]
    raw = _run(argv, env={"GH_HOST": repo.host})
    return raw[-LOG_TRUNCATE_LIMIT:] if len(raw) > LOG_TRUNCATE_LIMIT else raw
