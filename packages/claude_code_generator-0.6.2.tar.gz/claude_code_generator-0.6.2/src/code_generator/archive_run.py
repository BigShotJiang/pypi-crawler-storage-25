"""Archive a completed pipeline run into ``.code-generator/backup/<slug>/``.

When a full 0→7 run finishes successfully, the run's artifacts
(``requirements.md``, ``state.json``, ``logs/``, ``memories/``,
``checklists/``, ``cycles_prompts/``) are still sitting in
``.code-generator/`` and will be overwritten by the next run. This module
snapshots them into a per-requirement subfolder so every finished
requirement is preserved self-contained, then resets ``.code-generator/``
to a clean slate: the archived artifacts are removed from the working dir
and ``requirements.md`` is replaced with a blank canonical skeleton, ready
for the next requirement. ``backup/`` itself is never touched — it is the
archive root and accumulates one subfolder per finished run.

Invariants:
- Fires only on genuine full success (the single caller is the tail of
  ``dispatch_async``; pauses/errors/dry-run never reach it).
- Never raises — a finished pipeline must stay finished even if archiving
  fails (logged at WARNING and swallowed).
- Never recurses ``backup/`` into itself, and the reset step never deletes
  ``backup/`` or anything outside the known per-run artifact set.
- The reset runs only after the archive is atomically committed
  (``os.replace`` of the staging dir), so a failed reset can never lose an
  un-archived run.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from code_generator import git_ops
from code_generator.requirements_structure import _H1_RE
from code_generator.state import compute_requirements_hash

if TYPE_CHECKING:
    import logging

    from code_generator.state import State

# Reuse the exact UTC timestamp style of the optimize backup convention
# (``requirements.backup-<ts>.md``) for collision suffixes.
_TIMESTAMP_FORMAT = "%Y%m%dT%H%M%SZ"

_SLUG_MAX_LEN = 60
_NON_SLUG_RE = re.compile(r"[^a-z0-9]+")

# Per-run artifacts copied into the archive then removed from the working
# dir. ``backup`` is deliberately excluded from both lists so the archive
# never recurses into itself and the reset never deletes prior archives.
_ARTIFACT_FILES = ("requirements.md", "state.json")
_ARTIFACT_DIRS = ("logs", "memories", "checklists", "cycles_prompts")

# Blank canonical skeleton written back as ``requirements.md`` after a run
# is archived. Intentionally NOT canonical (the single ``### 1.`` scope
# subsection has no acceptance-criteria block), so a plain
# ``code-generator optimize`` still processes it instead of short-circuiting
# — ``optimize`` is what fills in the per-section/global acceptance criteria.
_REQUIREMENTS_TEMPLATE = """\
# <title>

## Description

<!-- One paragraph: what to build and why. -->

## Tech Stack

<!-- Languages, frameworks, runtimes, external services. -->

## Goals

<!-- Numbered, outcome-oriented. What does "done" mean at a high level? -->

## Scope

### 1. <first feature>

<!-- What this slice delivers. `code-generator optimize` adds the
     per-section acceptance-criteria block. Add more `### N.` subsections
     as needed. -->

## Non-goals

<!-- Explicitly out of scope, so the agent does not drift into it. -->

## Constraints

<!-- Hard rules the implementation must respect. -->

## Global acceptance criteria

<!-- Run-wide conditions that must hold before the work is considered done. -->
"""


def _slugify(title: str) -> str:
    """Lowercase, hyphenate, collapse, trim, truncate to 60 chars."""
    slug = _NON_SLUG_RE.sub("-", title.lower()).strip("-")
    return slug[:_SLUG_MAX_LEN].strip("-")


def _derive_slug(req_path: Path) -> str:
    """Slug from the requirements H1 title; fallback to ``run-<hash12>``."""
    text = req_path.read_text(encoding="utf-8")
    match = _H1_RE.search(text)
    if match:
        title = match.group(0).lstrip("#").strip()
        slug = _slugify(title)
        if slug:
            return slug
    return f"run-{compute_requirements_hash(req_path)[:12]}"


def _resolve_provider_model(st: State) -> str | None:
    """Single-model tag if any provider stamped one (State, then cycles)."""
    for attr in ("codex_model", "gemini_model", "ollama_model"):
        val = getattr(st, attr, None)
        if val:
            return val
    for cycle in reversed(st.cycles):
        for attr in ("codex_model", "gemini_model", "ollama_model"):
            val = getattr(cycle, attr, None)
            if val:
                return val
    return None


def _build_manifest(project_dir: Path, st: State, req_path: Path, slug: str) -> dict:
    """Provenance record written as ``MANIFEST.json`` inside the archive."""
    title_match = _H1_RE.search(req_path.read_text(encoding="utf-8"))
    provider_model = _resolve_provider_model(st)
    completed = sum(1 for c in st.cycles if getattr(c, "status", None) == "completed")
    manifest: dict = {
        "archived_at": datetime.now(UTC).strftime(_TIMESTAMP_FORMAT),
        "slug": slug,
        "title": title_match.group(0).lstrip("#").strip() if title_match else None,
        "requirements_hash": compute_requirements_hash(req_path),
        "mode": st.mode,
        "completed_cycles": completed,
        "provider_model": provider_model or "anthropic-max",
        "git_branch": None,
        "git_commit": None,
    }
    try:
        manifest["git_branch"] = git_ops.git_current_branch(project_dir)
        manifest["git_commit"] = git_ops.git_rev_parse_head(project_dir)
    except Exception:  # noqa: BLE001 — git context is best-effort
        pass
    return manifest


def _copy_artifacts(cg_dir: Path, staging: Path) -> None:
    """Copy present per-run artifacts into the staging dir."""
    for name in _ARTIFACT_FILES:
        src = cg_dir / name
        if src.is_file():
            shutil.copy2(src, staging / name)
    for name in _ARTIFACT_DIRS:
        src = cg_dir / name
        if src.is_dir():
            shutil.copytree(src, staging / name)


def _force_unlink(path: Path) -> None:
    """Remove *path* even if it was left read-only (e.g. by state_guard)."""
    with contextlib.suppress(OSError):
        path.chmod(0o644)  # best-effort — dir perms decide unlink, not file perms
    path.unlink()


def _reset_working_dir(cg_dir: Path, logger: logging.Logger) -> None:
    """Remove the just-archived artifacts and restore a blank skeleton.

    Deletes only the known per-run artifact set (never ``backup/`` or any
    unrecognised file), then writes a fresh non-canonical
    ``requirements.md`` so the next run starts from a clean slate. Runs only
    after the archive is atomically committed. Best-effort and never raises.
    """
    for name in _ARTIFACT_DIRS:
        shutil.rmtree(cg_dir / name, ignore_errors=True)
    for name in _ARTIFACT_FILES:
        target = cg_dir / name
        if target.is_file():
            try:
                _force_unlink(target)
            except OSError as exc:
                logger.warning("archive: could not remove %s (%s).", target, exc)

    # Atomic skeleton write (tmp → os.replace), same convention as state.py.
    req_path = cg_dir / "requirements.md"
    fd, tmp_name = tempfile.mkstemp(prefix=".requirements.", suffix=".tmp", dir=cg_dir)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(_REQUIREMENTS_TEMPLATE)
        os.replace(tmp_name, req_path)
    except OSError as exc:
        Path(tmp_name).unlink(missing_ok=True)
        logger.warning("archive: could not write blank requirements.md (%s).", exc)


def archive_completed_run(project_dir: Path, st: State, logger: logging.Logger) -> Path | None:
    """Snapshot a finished run into ``.code-generator/backup/<slug>/``.

    Returns the archive path on success, ``None`` when there is nothing to
    archive or archiving failed. Never raises.

    Args:
        project_dir: Project root (contains ``.code-generator/``).
        st: The final, persisted root state.
        logger: Phase logger.
    """
    try:
        cg_dir = project_dir / ".code-generator"
        req_path = cg_dir / "requirements.md"
        if not cg_dir.is_dir() or not req_path.is_file():
            logger.debug("archive: no .code-generator/requirements.md — skipping.")
            return None

        slug = _derive_slug(req_path)
        backup_dir = cg_dir / "backup"
        backup_dir.mkdir(parents=True, exist_ok=True)

        ts = datetime.now(UTC).strftime(_TIMESTAMP_FORMAT)
        dest = backup_dir / slug
        if dest.exists():
            dest = backup_dir / f"{slug}-{ts}"

        # Stage into a hidden sibling, then a single atomic rename so a
        # half-written archive is never visible.
        staging = Path(tempfile.mkdtemp(prefix=f".{slug}.partial-", dir=backup_dir))
        try:
            _copy_artifacts(cg_dir, staging)
            manifest = _build_manifest(project_dir, st, req_path, dest.name)
            (staging / "MANIFEST.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
            os.replace(staging, dest)
        except BaseException:
            shutil.rmtree(staging, ignore_errors=True)
            raise

        logger.info("archive: saved completed run to %s", dest)

        # Archive committed — safe to wipe the working dir back to a clean
        # slate. A failure here cannot lose the run (it is already in dest).
        _reset_working_dir(cg_dir, logger)
        logger.info("archive: reset .code-generator/ to blank requirements.md")
        return dest
    except Exception as exc:  # noqa: BLE001 — archiving must never break a finished run
        logger.warning("archive: failed to snapshot completed run (%s) — continuing.", exc)
        return None
