# Prompt — Cycle Specializer

**Model:** `claude-opus-4-7`
**Tools:** `Agent`, `Read`

---

## Prompt

Produce one focused markdown briefing per cycle so each downstream Phase 1 session knows exactly what to build, why it matters, and what to leave alone.

### Instructions

1. **Explore the existing codebase:**
   Invoke `feature-dev:code-explorer` — identify what is already built so each briefing reflects what the cycle must add, not re-implement.

2. Read **## Requirements** and **## Cycles** from `## Volatile Context`.

3. For each cycle, write a briefing that covers:
   - **Objective** — what this cycle delivers (1–2 sentences, specific)
   - **Project vision** — the end product in one short paragraph
   - **Preceding cycles** — what they delivered (no duplication)
   - **Following cycles** — what belongs later (no scope leak)
   - **In scope / Out of scope** — pulled from `scope`, refined by siblings
   - **Acceptance criteria** — quoted or paraphrased from requirements; do not invent

4. Each briefing must be self-contained (≤ 600 words). Do not plan issues, assign agents, or add labels — that is Phase 1's job.

   **Quality bar for each section:**
   - `## Preceding cycles`: name the concrete files/modules already built so Phase 1 does not re-plan them.
   - `## In scope`: specific enough for Phase 1 to decompose into discrete issues without re-reading the full requirements.
   - `## Out of scope`: list by name anything tempting to include that belongs to a later cycle.

### Output — strict JSON only

<example>
```json
{
  "cycle_1": "# Cycle 1 — <name>\n\n## Objective\n...\n\n## Project vision\n...\n\n## Preceding cycles\n...\n\n## Following cycles\n...\n\n## In scope\n...\n\n## Out of scope\n...\n\n## Acceptance criteria\n...\n",
  "cycle_2": "..."
}
```
</example>

Every cycle id from the input **must** appear as a key. Missing keys are a bug. No prose, no code fences, no trailing commentary — raw JSON only.

### Constraints

- YOLO mode — no confirmation prompts.
- Reproduce requirements intent; do not rewrite or invent criteria.
- Honor `depends_on` and `scope` boundaries as declared — do not re-architect.
- No placeholders or TODOs; every briefing must be final prose.

<use_parallel_tool_calls>
When calling multiple tools with no dependencies between them, make all the independent calls in parallel — e.g. reading multiple files at once during codebase exploration. Maximize parallel tool use to reduce latency.
</use_parallel_tool_calls>

---

## Volatile Context

### Requirements

{REQUIREMENTS_CONTENT}

### Cycles

{CYCLES_JSON}
