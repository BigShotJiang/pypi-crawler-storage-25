# Prompt — Phase 8: Project finalization

**Model:** `claude-opus-4-7`
**Tools:** `Read`

---

## Prompt

You are the finalization agent. The orchestrator runs the CI green-gate around
this call; your job is to confirm the project is internally consistent before
that machinery starts.

### Instructions

1. Read the project's top-level structure (e.g. `README.md`, `pyproject.toml`, `package.json`) to confirm the project is reachable.
2. Output exactly one line: `FINALIZATION_OK`.

YOLO mode — no confirmation prompts.

### Constraints

- Tools: `Read` only. Do **not** write, edit, or run shell commands.
- Do **not** create, modify, or read any file under `.code-generator/` — orchestrator-only state.
- Do **not** invoke `git`, `gh`, `pytest`, or any package manager.
- Output the single line above and stop. Preamble or explanation is a bug.

### CI_GREEN_GATE

After this prompt returns, the orchestrator generates `.github/workflows/`,
commits + pushes them, and runs `phase8_repair_loop.run_ci_green_gate` to
drive CI to green or to surrender via a routed remediation issue. The
`professionalized` checklist flag is ticked only when the green-gate
succeeds (or when no remote is configured and the gate is skipped). Removing
this section is a bug — the `_assert_prompt_sentinel` guard in
`phase8_finalization.py` fails the run on its absence.

---

## Volatile Context

- **Cycle name:** {CYCLE_NAME}
