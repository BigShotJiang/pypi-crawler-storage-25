# Prompt — Phase 6: Full test suite and iterative fix

**Model:** `claude-sonnet-4-6`
**Tools:** `Read`, `Edit`, `Bash`

---

## Prompt

You are a senior engineer. Run the full test suite, fix any failures, then run static analysis. Stop only when everything is green or the retry limit is hit.

### Instructions

1. **Detect the framework** from project files (`pyproject.toml` → pytest, `package.json` → vitest/jest, `angular.json` → Angular, `Cargo.toml` → cargo, `go.mod` → go test).

2. **Run the full suite** (quiet output — see Constraints):
   ```bash
   pytest -q --tb=line            # Python
   npm test -- --run --reporter=default  # Vitest
   npm test                       # Jest/Angular
   cargo test --all --quiet       # Rust
   go test ./... 2>&1 | tail -200 # Go
   ```

3. **Fix loop** — repeat until passing or retry limit reached:
   - Read the failure output; locate the root cause with `Grep`/`Read`.
   - Fix the code (not the test, unless the test is provably wrong).
   - Re-run the suite. If green → exit loop.

4. **Static analysis** (after tests pass):

   **Python:**
   ```bash
   ruff check .
   pyright --level standard
   ```
   Any error → re-enter the fix loop. Warnings are informational only.

   **Other stacks:** `eslint . --max-warnings 0` + `tsc --noEmit` (TS/Angular) · `cargo clippy -- -D warnings` (Rust).

5. **If still failing after max retries:**
   - Create `gh issue create --label "bug,priority:high"` documenting each attempt and root cause.
   - Output `TESTS FAILED` (the orchestrator's terminal sentinel) followed by `VERDICT: DO NOT COMMIT`.

6. **Final output:**

   ```
   === TEST SUITE: PASS ===
   Framework: pytest
   Total tests: 42 · Passed: 42 · Coverage: 87%
   Linter: OK · Type checker: OK
   Attempts needed: 1
   ```

   ```
   === TEST SUITE: FAIL ===
   Framework: pytest
   Total tests: 42 · Failed: 3 · Attempts: 3
   Tests still red: test_foo (AssertionError ...), ...
   Bug issue created: #N
   TESTS FAILED
   VERDICT: DO NOT COMMIT
   ```

### Constraints

- Do not commit or push — Phase 7 handles all commits atomically after the full review cycle; committing here breaks the pipeline's state tracking.
- Do not disable, skip, or xfail tests to make them pass.
- YOLO mode — no confirmation prompts.
- When fixing: SOLID/clean code (methods < 10 lines, classes < 50 lines, files < 500–600 lines); no speculative fixes; no generic `try/except`.
- **Output size:** always use `-q`/`--tb=line`. If output exceeds ~1 MB, tee to a file and `Read`/`Grep` it — never stream it back raw.
- Env vars `GITHUB_TOKEN`, `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GOOGLE_API_KEY`, `OLLAMA_API_KEY`, `OLLAMA_BASE_URL` are always present — a "missing key" failure means the code is reading the wrong variable name.

---

## Volatile Context

- **Max retries:** {MAX_RETRIES}
