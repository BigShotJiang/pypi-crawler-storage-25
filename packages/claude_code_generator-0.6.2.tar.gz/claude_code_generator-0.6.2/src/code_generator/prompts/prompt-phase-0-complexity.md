# Prompt — Phase 0: Complexity analysis and cycle decomposition

**Model:** `claude-opus-4-7`
**Tools:** `Agent`, `Read`, `Glob`, `Grep`
**Output:** structured JSON (schema below)

---

## Prompt

Analyze the project in `.code-generator/requirements.md` and decide: single cycle or multi-cycle decomposition.

### Instructions

1. **Explore the existing codebase:**
   Invoke `feature-dev:code-explorer` to identify what is already built. Use its output to avoid re-planning completed work and to calibrate the estimate.

2. **Read** `.code-generator/requirements.md`.

3. **Decide the mode:**
   - `single` — ≤ 8 estimated issues AND ≤ 2 architectural layers
   - `multi-cycle` — > 8 issues OR > 2 layers with mutual dependencies

4. **If multi-cycle**, decompose into ordered cycles:
   - Each cycle is self-contained and committable
   - Foundational layers first (DB → API → Frontend)
   - Each cycle has `depends_on`, `milestone_title`, `scope`
   - Maximum 5 cycles

5. **Output** the JSON below. No prose, no fences — raw JSON only.

### JSON schema

```json
{
  "mode": "single | multi-cycle",
  "reason": "string",
  "effort_hints": [{"scope_keyword": "string", "effort": "low|medium|high"}],
  "cycles": [
    {
      "id": 1,
      "name": "string",
      "milestone_title": "Cycle 1 — Name",
      "depends_on": [],
      "scope": "string",
      "estimated_issues": 4,
      "effort_hints": [{"scope_keyword": "string", "effort": "low|medium|high"}]
    }
  ]
}
```

`effort_hints` at root level = single mode only. `effort_hints` inside cycles = advisory per cycle. `effort` value `max` is **not** allowed anywhere.

### Examples

<examples>
<example>
```json
{
  "mode": "multi-cycle",
  "reason": "3 layers with dependencies: DB → API → Frontend",
  "cycles": [
    {"id": 1, "name": "Database Layer", "milestone_title": "Cycle 1 — Database Layer",
     "depends_on": [], "scope": "Schema, ORM models, migrations, repositories",
     "estimated_issues": 4, "effort_hints": [{"scope_keyword": "migration", "effort": "high"}]},
    {"id": 2, "name": "API Layer", "milestone_title": "Cycle 2 — API Layer",
     "depends_on": [1], "scope": "REST endpoints, auth, validation",
     "estimated_issues": 6, "effort_hints": [{"scope_keyword": "auth", "effort": "high"}]},
    {"id": 3, "name": "Frontend", "milestone_title": "Cycle 3 — Frontend",
     "depends_on": [2], "scope": "Components, routing, API integration",
     "estimated_issues": 5, "effort_hints": []}
  ]
}
```
</example>
<example>
```json
{
  "mode": "single",
  "reason": "2 layers, ~6 issues",
  "cycles": [],
  "effort_hints": [{"scope_keyword": "auth", "effort": "high"}]
}
```
</example>
</examples>

### Constraints

- Analysis only — do not create files, run `gh`, or write code.
- YOLO mode — decide autonomously; fall back to `single` on ambiguity.
- Do not invent features. One architectural responsibility per cycle.

<use_parallel_tool_calls>
When calling multiple tools with no dependencies between them, make all the independent calls in parallel — e.g. read several files at once rather than sequentially. Maximize parallel tool use to reduce latency.
</use_parallel_tool_calls>

---

## Volatile Context

### Codebase graph

{REPO_MAP}
