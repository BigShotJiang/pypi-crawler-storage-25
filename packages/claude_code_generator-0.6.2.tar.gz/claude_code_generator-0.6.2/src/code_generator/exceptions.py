"""Shared exception classes for the code-generator pipeline.

Single-responsibility: domain exception types only — no runner errors
(those live in runner/types.py), no preflight errors (preflight.py).
"""

from __future__ import annotations


class OllamaModelRequiredError(RuntimeError):
    """Raised when the Ollama codepath has no resolvable model tag.

    On the Ollama single-model path (#218), every phase requires a concrete
    model tag (e.g. ``qwen3-coder:480b:cloud``).  This error fires when the
    orchestrator detects that no model is available — either because
    ``--model`` wasn't passed on a fresh run, or because the stored
    ``CycleState.ollama_model`` is ``None`` on ``--continue``.

    The ``fix_action`` string is a ready-to-paste remediation for the
    operator; it is included in the error message automatically.
    """

    def __init__(self, reason: str, fix_action: str) -> None:
        self.reason = reason
        self.fix_action = fix_action
        super().__init__(f"{reason} {fix_action}")
