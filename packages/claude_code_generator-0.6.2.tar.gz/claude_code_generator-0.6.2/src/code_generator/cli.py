"""Entry-point CLI for code-generator.

Exposes a Typer application with --version and subcommands:
init, status, generate, review.

At import time we reconfigure stdout/stderr for line-buffered output (the
in-process equivalent of ``PYTHONUNBUFFERED=1``) so phase progress shows up
in the terminal in real time even when the CLI is invoked through buffering
wrappers like ``conda run``.  The default log level is DEBUG, overridable
via the ``LOGLEVEL`` env var (set ``LOGLEVEL=INFO`` for the quieter behaviour
that earlier 0.4.x releases shipped with).
"""

from __future__ import annotations

import contextlib
import logging
import os
import sys
from typing import Annotated

import typer

import code_generator
from code_generator.commands.bench import bench_app
from code_generator.commands.generate import generate_app
from code_generator.commands.init import init_command
from code_generator.commands.optimize import optimize_command
from code_generator.commands.review import review_command
from code_generator.commands.status import status_command


def _configure_io_and_logging() -> None:
    """Force line-buffered stdout/stderr and apply LOGLEVEL (default DEBUG).

    Equivalent to running with ``PYTHONUNBUFFERED=1 LOGLEVEL=DEBUG`` from
    the shell, but always-on so users don't have to remember the env vars.
    Both can still be overridden externally — ``LOGLEVEL=INFO`` reverts to
    the quieter default.

    Idempotent: safe to call multiple times (the ``reconfigure`` call is a
    no-op when line buffering is already on, and ``logging.basicConfig`` is
    a no-op once root handlers exist).
    """
    # Line-buffered console I/O: each ``\n`` flushes immediately. The
    # `contextlib.suppress` wrapper handles streams that are already buffered
    # as needed or are non-seekable (e.g. piped to another process).
    for stream in (sys.stdout, sys.stderr):
        with contextlib.suppress(AttributeError, OSError):
            stream.reconfigure(line_buffering=True)  # type: ignore[union-attr]

    level_name = os.environ.get("LOGLEVEL", "DEBUG").upper()
    level = getattr(logging, level_name, logging.DEBUG)
    logging.getLogger("code_generator").setLevel(level)


_configure_io_and_logging()

app = typer.Typer(
    name="code-generator",
    help="Orchestrate Claude Code to generate whole projects from a requirements.md.",
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"code-generator {code_generator.__version__}")
        raise typer.Exit()


@app.callback()
def root(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            "-V",
            help="Show version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """code-generator CLI root."""


app.add_typer(bench_app, name="bench")
app.add_typer(generate_app, name="generate")
app.command(name="init")(init_command)
app.command(name="status")(status_command)
app.command(name="optimize")(optimize_command)
app.command(name="review")(review_command)
