"""Phase 6 — Test suite runner.

Runs Haiku 4.5 to execute the test suite and fix failures iteratively
(max 3 attempts, controlled by the prompt). Raises :class:`TestsFailed`
if the session text contains the sentinel string ``"TESTS FAILED"``.

Non-negotiable #8: model is hard-coded via ``effort.phase_model(6)``
(``claude-haiku-4-5-20251001``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from code_generator import checklist as _checklist
from code_generator import effort as _effort
from code_generator import state as _state
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit
from code_generator.runner._telemetry import accumulate_telemetry
from code_generator.runner.cache_breakpoints import resolve_active_ttl
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.runner.phase_telemetry import accumulate_phase_telemetry
from code_generator.runner.types import TokenUsage
from code_generator.state import CycleState

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import State


# Sentinel emitted by the prompt when all retries are exhausted.
_FAIL_SENTINEL = "TESTS FAILED"


class TestsFailed(RuntimeError):  # noqa: N818
    """Raised when the test-runner session reports persistent test failures.

    The orchestrator should skip phase 7 (commit) when this is raised.
    """

    __test__ = False  # pytest: not a test class


_PHASE6_DEFAULT_MODEL = _effort.phase_model(6)
# CLAUDE.md invariant #8; overridden via ``effective_model`` on Ollama — #219.


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    max_retries: int = 3,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Execute phase 6: test suite runner with effort escalation.

    Runs up to *max_retries* attempts. Each attempt resolves an escalating
    effort level via ``resolve_effort(phase=6, retry_count=attempt)`` so the
    model receives progressively more compute on repeated failures.
    Token usage is accumulated across all attempts and persisted on success.

    Args:
        state: Root state object.
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
        max_retries: Maximum number of Python-level retry attempts (default 3).

    Raises:
        TestsFailed: When all attempts report ``"TESTS FAILED"``.
    """
    if logger is None:
        logger = setup_phase_logger("phase6", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"
    total_usage = TokenUsage()
    total_wall = 0.0
    total_compaction = 0
    total_clear = 0
    target = cycle if cycle is not None else state
    phase_ttl = resolve_active_ttl(state, cycle, bp_index=2)

    for attempt in range(max_retries):
        effort_level = _effort.resolve_effort(
            phase=6, complexity="", issue_labels=[], retry_count=attempt
        )
        _phase6_model = effective_model or _PHASE6_DEFAULT_MODEL
        _effort.validate_effort(effort_level, _phase6_model)

        prompt = load_prompt("prompt-phase-6-test.md", MAX_RETRIES="3")

        options = make_agent_options(
            model=_phase6_model,
            effort=effort_level,
            allowed_tools=["Read", "Edit", "Bash"],
            cwd=str(project_dir),
            **max_turns_kwargs(max_turns),
        )

        result = await rate_limit.main_loop(
            runner_module,
            prompt,
            options,
            state_path=state_path,
            logger=logger,
        )
        total_usage += result.usage
        total_wall += result.wall_seconds
        total_compaction += result.compaction_events
        total_clear += result.clear_events

        if _FAIL_SENTINEL not in result.text:
            target.token_usage["phase6"] = TokenUsage()
            accumulate_phase_telemetry(
                target.token_usage["phase6"],
                ttl=phase_ttl,
                usage=total_usage,
                compaction_delta=total_compaction,
                clear_delta=total_clear,
            )
            if isinstance(target, CycleState):
                accumulate_telemetry(target.cache_telemetry, total_usage, total_wall)
            # §13 checklist tick (#250). Tick BEFORE save_state so the
            # checklist file (binding source of truth) is consistent even if
            # save_state crashes.
            _tick_checklist_for_closed_issues(state, cycle, state_path, logger)
            _state.save_state(state_path, state)
            log_phase_usage(logger, 6, target.token_usage["phase6"])
            return

        logger.warning(
            "Phase 6: attempt %d/%d failed (TESTS FAILED sentinel found).",
            attempt + 1,
            max_retries,
        )

    logger.error("Phase 6: test runner reported persistent failures after %d retries.", max_retries)
    raise TestsFailed(
        "Test suite failed after all retries. Inspect the output above and fix manually."
    )


def _tick_checklist_for_closed_issues(
    state: State,
    cycle: CycleState | None,
    state_path: Path,
    logger: logging.Logger,
) -> None:
    """Tick ``tests_passed`` for every closed issue in scope (#250).

    No-op + WARNING when ``state.requirements_hash`` is unset (mirrors the
    Phase 1 seed guard from #249). The checklist file is the binding source
    of truth for feature completion — never silently skip a tick on missing
    state.requirements_hash; surface it.
    """
    if state.requirements_hash is None:
        logger.warning("Phase 6: skipping checklist tick — state.requirements_hash is None.")
        return
    checklist_path = state_path.parent / "checklists" / f"{state.requirements_hash}.json"
    issues = cycle.issues if cycle is not None else state.issues
    for issue in issues:
        if issue.status == "closed":
            _checklist.tick_tests_passed(checklist_path, issue.number)
