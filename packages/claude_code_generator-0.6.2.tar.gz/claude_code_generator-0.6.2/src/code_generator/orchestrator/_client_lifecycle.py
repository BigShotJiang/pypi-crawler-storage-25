"""Shared-client lifecycle helpers for the cycle orchestrator.

Isolated here so cycle_loop.py stays under the 600-line threshold.
Exposes three callables consumed by cycle_loop:

- ``_open_cycle_client(options_template)`` — returns a ``ClaudeSDKClient``
  async context manager ready for ``async with``.
- ``_build_cycle_options()`` — builds minimal cycle-scoped
  ``ClaudeAgentOptions`` (stable system-prompt + betas + cache_control).
  Per-phase differences (allowed_tools, thinking, task_budget) are applied
  by each phase when it calls ``run_with_shared_client()``.
- ``managed_shared_client(state, state_path)`` — async context manager that
  owns the full lifecycle: env-strip, construction, mark-alive on entry, and
  clear-alive **only** on clean exit (exception leaves ``client_alive_at``
  set so ``--continue`` can detect the orphaned client).
"""

from __future__ import annotations

import contextlib
import logging
from typing import TYPE_CHECKING, Any

from code_generator import env as _env
from code_generator import state as _state
from code_generator.runner.cache_breakpoints import build_cache_breakpoints, resolve_ttls
from code_generator.runner.mcp import build_mcp_servers, mcp_tool_wildcards
from code_generator.runner.memory_tool import build_cycle_memory_tool
from code_generator.runner.options import (
    build_system_prompt,
    make_agent_options,
    probe_cache_ttl_support,
)

_logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator.state import State

# Superset of every phase's tools. ClaudeSDKClient locks ``allowed_tools`` at
# open-time; per-query changes do not apply. The shared client must therefore
# open with a superset so any phase running on it can invoke any tool it needs.
# Phase-level narrowing is purely documentary — enforcement moves to the prompts.
_SHARED_CLIENT_ALLOWED_TOOLS: tuple[str, ...] = (
    "Read",
    "Edit",
    "Write",
    "Bash",
    "Glob",
    "Grep",
    # Web access — Phase 3/4 prompt instructs the model to consult upstream
    # docs for unfamiliar libraries before guessing. WebFetch is sandboxed by
    # the API: it can only retrieve URLs already in conversation context (no
    # arbitrary model-generated URLs), which closes the exfiltration vector.
    "WebSearch",
    "WebFetch",
    # ``memory`` is the SDK-registered name for ``runner.memory_tool.CycleMemoryTool``.
    # Listed even when the SDK lacks BetaAbstractMemoryTool (factory returns None);
    # an unknown allowed-tool entry is harmless on the older path. Required by
    # issue #238 + matches issue #234's ``exclude_tools=["memory","Read"]``.
    "memory",
    # Playwright MCP wildcard for the T3 browser tier (#284). Allowed-tool
    # entries are ignored when the corresponding server is not registered,
    # so this is safe in environments without ``playwright-mcp`` on PATH.
    "mcp__playwright__*",
)

# Auto-injected protocol prompt — appended to the ``claude_code`` system preset
# so every shared-client turn observes it. Issue #238 mandates this exact text.
_MEMORY_PROTOCOL_PROMPT = "ALWAYS VIEW YOUR MEMORY DIRECTORY BEFORE DOING ANYTHING ELSE"

# Single-mode cycle id — multi-cycle runs override with ``cycle-<N>``. Used by
# the memory tool to scope writes under ``<memories_dir>/<cycle_id>/``.
_SINGLE_MODE_CYCLE_ID = "single"

# Guard SDK import so this module can be loaded without the SDK installed
# (used by get_runner() to detect availability, and by subprocess-only paths).
try:
    from claude_agent_sdk import ClaudeSDKClient  # type: ignore[import-not-found]

    _SDK_AVAILABLE = True
except ImportError:  # pragma: no cover
    _SDK_AVAILABLE = False
    ClaudeSDKClient = None  # type: ignore[assignment,misc]


def _open_cycle_client(options_template: Any) -> Any:
    """Return a ``ClaudeSDKClient`` async context manager for the cycle.

    Callers use::

        async with _open_cycle_client(options) as client:
            ...

    The *options_template* carries the stable, cycle-scoped settings
    (system-prompt preset, betas, 1-hour cache TTL).  Per-phase differences
    (``allowed_tools``, ``thinking``, ``task_budget``) are applied by each
    phase when it calls ``run_with_shared_client()``.

    Args:
        options_template: Cycle-scoped ``ClaudeAgentOptions`` (or duck-typed
            fallback) produced by ``_build_cycle_options()``.

    Returns:
        A ``ClaudeSDKClient`` instance, which is itself an async context
        manager.

    Raises:
        RuntimeError: When ``claude_agent_sdk`` is not installed.
    """
    if not _SDK_AVAILABLE or ClaudeSDKClient is None:
        raise RuntimeError(
            "claude_agent_sdk is required for shared-session mode; "
            "install it or use --session-mode=fresh."
        )
    return ClaudeSDKClient(options=options_template)


def _resolve_cycle_id(state: State | None) -> str:
    """Return the cycle id used to scope memory-tool writes (issue #238).

    Multi-cycle runs use ``cycle-<N>`` derived from ``state.current_cycle``;
    single-mode runs use the ``single`` constant.
    """
    if state is None:
        return _SINGLE_MODE_CYCLE_ID
    current = getattr(state, "current_cycle", None)
    return f"cycle-{current}" if current is not None else _SINGLE_MODE_CYCLE_ID


def _build_cycle_options(
    project_dir: Path,
    effective_model: str | None = None,
    *,
    cycle_id: str = _SINGLE_MODE_CYCLE_ID,
) -> Any:
    """Return cycle-scoped options for the shared ``ClaudeSDKClient``.

    ``ClaudeSDKClient`` locks options at open-time — per-query changes do not
    apply. The shared client therefore opens with:

    - ``model``: the effective Ollama model tag (when on the Ollama codepath),
      or ``None`` to let the SDK default (Anthropic Max path). Must be set at
      open-time because per-query overrides are silently ignored.
    - ``system_prompt``: canonical ``claude_code`` preset with
      ``exclude_dynamic_sections=True`` (§2 cache-safe prefix).
    - ``extra_headers``: default betas (extended-cache-ttl + token-efficient-tools).
    - ``cache_control``: ``{"type": "ephemeral", "ttl": "1h"}`` (or ``"5m"``
      fallback if the installed SDK does not support ``"1h"``).
    - ``allowed_tools``: superset of every phase's tools (Phase 3/4 is the
      broadest — Read/Edit/Write/Bash/Glob/Grep) plus any MCP wildcards the
      repo exposes. Per-phase narrowing moves to the prompts.
    - ``permission_mode``: ``"bypassPermissions"`` (non-negotiable #3). Without
      this the SDK's default permission prompt intercepts every tool call and
      the model sits asking the orchestrator for approval it cannot give.
    - ``mcp_servers``: codebase-memory + serena fallback, resolved from the
      project dir.

    Args:
        project_dir: Project root; used to resolve MCP servers.
        effective_model: Ollama model tag to lock into the shared client
            (threaded from cycle_loop). When ``None``, the SDK default
            (Anthropic Max path) is used.

    Returns:
        A ``ClaudeAgentOptions`` instance (or duck-typed fallback) suitable
        for passing to ``_open_cycle_client()``.
    """
    mcp_servers = build_mcp_servers(project_dir)
    allowed_tools: list[str] = list(_SHARED_CLIENT_ALLOWED_TOOLS) + mcp_tool_wildcards(mcp_servers)
    memories_dir = project_dir / ".code-generator" / "memories"
    memory_tool = build_cycle_memory_tool(memories_dir, cycle_id)
    # §8 four-breakpoint cache layout (issue #239) + §9 per-BP TTL assignment
    # (issue #240). SDK 0.1.65 has no per-block marker API; the layout rides
    # as a post-init attribute (forward-compat hook). The probe (
    # ``probe_cache_ttl_support``) gates 1h vs 5m globally — when the SDK
    # rejects the extended-cache-ttl beta the entire layout collapses to a
    # uniform 5m fallback (review-comment #2 on issue #240).
    _ttls = resolve_ttls(probe_cache_ttl_support(_logger))
    cache_breakpoints = build_cache_breakpoints(
        tools_block_index=0,
        system_block_index=1,
        repo_map_block_index=2,
        cycle_prompt_block_index=3,
        boundary_user_block_index=4,
        ttls=_ttls,
    )
    kwargs: dict[str, Any] = dict(
        allowed_tools=allowed_tools,
        permission_mode="bypassPermissions",
        mcp_servers=mcp_servers,
        # Append the §7 memory-protocol directive so every shared-client turn
        # observes it. exclude_dynamic_sections stays True (§2 cache prefix).
        system_prompt=build_system_prompt(append=_MEMORY_PROTOCOL_PROMPT),
        memory_tool=memory_tool,
        cache_breakpoints=cache_breakpoints,
    )
    if effective_model is not None:
        kwargs["model"] = effective_model
    return make_agent_options(**kwargs)


@contextlib.asynccontextmanager
async def managed_shared_client(state: State, state_path: Path, effective_model: str | None = None):  # type: ignore[return]
    """Async context manager owning the full shared-client lifecycle.

    On entry: strips dangerous env vars (non-negotiable #1), opens one
    ``ClaudeSDKClient``, and calls ``mark_client_alive`` so crash-recovery
    can detect an orphaned session on ``--continue``.

    On **clean** exit: calls ``clear_client_alive`` so ``--continue`` knows
    the client was closed gracefully.

    On **exception**: ``clear_client_alive`` is **not** called.
    ``client_alive_at`` remains set so ``--continue`` treats the client as
    orphaned (crash-recovery FSM — issue #8).

    Usage::

        async with managed_shared_client(state, state_path) as client:
            await _run_phases(..., shared_client=client)

    Args:
        state: Root state (mutated by mark/clear helpers).
        state_path: Path to ``state.json`` for atomic persistence.
        effective_model: Ollama model tag to lock into the shared client.
            When ``None``, the SDK default (Anthropic Max path) is used.

    Yields:
        The open ``ClaudeSDKClient`` instance.
    """
    _env.strip_dangerous_env()
    # state.json lives at {project_dir}/.code-generator/state.json.
    project_dir = state_path.parent.parent

    # §9 active TTL probe (#245). Persist the outcome on the active CycleState
    # (multi-cycle) or on State (single mode) BEFORE the client opens so a
    # crash during options-build still records the probe result for
    # ``--continue`` to consult on the next launch.
    _persist_ttl_probe(state, state_path)

    options = _build_cycle_options(
        project_dir,
        effective_model=effective_model,
        cycle_id=_resolve_cycle_id(state),
    )
    async with _open_cycle_client(options) as client:
        _state.mark_client_alive(state, state_path)
        try:
            yield client
        except BaseException:
            raise
        else:
            _state.clear_client_alive(state, state_path)


def _persist_ttl_probe(state: State, state_path: Path) -> None:
    """Record the SDK TTL probe outcome on the active scope (#245).

    Multi-cycle: writes to ``state.cycles[current].cache_ttl_probe``.
    Single mode (no current cycle): writes to ``state.cache_ttl_probe``.

    Skipped silently when the probe has already been recorded for this scope —
    ``--continue`` must not re-probe and overwrite the prior value.
    """
    target = _resolve_probe_target(state)
    if target is None:
        return
    if getattr(target, "cache_ttl_probe", None) is not None:
        return
    target.cache_ttl_probe = probe_cache_ttl_support(_logger)
    _state.save_state(state_path, state)


def _resolve_probe_target(state: State) -> Any:
    """Return the object whose ``cache_ttl_probe`` field should be written."""
    current = getattr(state, "current_cycle", None)
    cycles = getattr(state, "cycles", None) or []
    if current is not None:
        for cy in cycles:
            if getattr(cy, "id", None) == current:
                return cy
    return state
