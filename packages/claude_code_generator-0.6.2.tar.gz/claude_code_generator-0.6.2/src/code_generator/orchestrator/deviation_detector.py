"""Deviation detector for the Phase 6.5 bounded repair loop (#291).

In-memory overseer that records each tier outcome across repair attempts
and surfaces three failure modes the retry budget alone cannot catch:
``oscillation`` (same tier alternates pass/fail x4), ``stuck_tier``
(``stuck_limit`` identical ``(tier_id, failing_detail)`` failures), and
``context_drift`` (repair edited paths outside the declared target).
Pure: no I/O, no SDK calls, no state.json mutation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from collections.abc import Iterable

__all__ = ["DeviationDetector", "DeviationEvent", "DeviationKind"]


DeviationKind = Literal["oscillation", "stuck_tier", "context_drift"]


@dataclass(frozen=True)
class DeviationEvent:
    """Single pathological-behaviour signal raised by the detector."""

    kind: DeviationKind
    detail: str


@dataclass(frozen=True)
class _Sample:
    tier_id: str
    passed: bool
    failing_detail: str | None


@dataclass
class DeviationDetector:
    """Records tier outcomes and surfaces deviation events on demand."""

    stuck_limit: int = 3
    _samples: list[_Sample] = field(default_factory=list)
    _drift: DeviationEvent | None = None

    def record(self, tier_id: str, *, passed: bool, failing_detail: str | None) -> None:
        """Record a single tier outcome for the current attempt."""
        self._samples.append(_Sample(tier_id, passed, failing_detail))

    def record_drift(
        self,
        edited_paths: Iterable[str | Path],
        repair_target: str | Path,
    ) -> None:
        """Mark ``context_drift`` when *edited_paths* contains entries outside *repair_target*."""
        root = Path(repair_target).resolve()
        outsiders = sorted(str(p) for p in edited_paths if not _within(Path(p).resolve(), root))
        if outsiders:
            self._drift = DeviationEvent(
                kind="context_drift",
                detail=f"paths outside repair target {root}: {', '.join(outsiders)}",
            )

    def check(self) -> DeviationEvent | None:
        """Return the first non-None deviation event or ``None`` if all clear."""
        if self._drift is not None:
            return self._drift
        return self._check_oscillation() or self._check_stuck_tier()

    def _check_oscillation(self) -> DeviationEvent | None:
        for tier_id in dict.fromkeys(s.tier_id for s in self._samples):
            event = _detect_alternation(tier_id, self._samples)
            if event is not None:
                return event
        return None

    def _check_stuck_tier(self) -> DeviationEvent | None:
        if len(self._samples) < self.stuck_limit:
            return None
        recent = self._samples[-self.stuck_limit :]
        if not _all_match_failing(recent):
            return None
        head = recent[0]
        return DeviationEvent(
            kind="stuck_tier",
            detail=(
                f"tier {head.tier_id} failed {self.stuck_limit}x with identical "
                f"signature: {head.failing_detail}"
            ),
        )


_ALTERNATION_PATTERNS: tuple[tuple[bool, ...], ...] = (
    (True, False, True, False),
    (False, True, False, True),
)


def _detect_alternation(tier_id: str, samples: list[_Sample]) -> DeviationEvent | None:
    pattern = tuple(s.passed for s in samples if s.tier_id == tier_id)[-4:]
    if len(pattern) < 4 or pattern not in _ALTERNATION_PATTERNS:
        return None
    return DeviationEvent(
        kind="oscillation",
        detail=f"tier {tier_id} alternating pass/fail across 4 records",
    )


def _all_match_failing(samples: list[_Sample]) -> bool:
    head = samples[0]
    if head.passed:
        return False
    return all(
        not s.passed and s.tier_id == head.tier_id and s.failing_detail == head.failing_detail
        for s in samples
    )


def _within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True
