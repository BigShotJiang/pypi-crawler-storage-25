"""Declarative verification spec artifact for Phase 6.5 (#279).

The ``AgentSpec`` is a frozen dataclass serialized atomically to
``.code-generator/phase6_5_spec.json``. It is the single source of truth
for which tiers run in Phase 6.5, with which ports, scenarios, and
skip reasons. Downstream Cycle-2 issues (T3/T4 tiers, adaptive selection,
oracle, overseer) read from or write to this artifact instead of
re-deriving tier plans imperatively.

Determinism contract
--------------------
``build_agent_spec`` is pure: given the same ``requirements_text`` and
``tier_flags`` it returns an ``AgentSpec`` with a byte-stable
``requirements_hash`` (SHA-256 of UTF-8 bytes). Serialization uses
``json.dumps(..., indent=2, sort_keys=True)`` so the persisted file is
byte-identical across replays — enabling cache-friendly diffs and
reproducibility audits.

Atomic write
------------
``persist_agent_spec`` writes to a sibling ``.tmp`` file then
``os.replace``s it onto the target, mirroring ``state.py::save_state``
and ``checklist.py::_atomic_write_json``. A crash mid-write cannot
corrupt the existing spec.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator.orchestrator.scenario_builder import Scenario


__all__ = [
    "AgentSpec",
    "TierConfig",
    "build_agent_spec",
    "load_agent_spec",
    "persist_agent_spec",
]


_SPEC_FILENAME = "phase6_5_spec.json"


@dataclass(frozen=True)
class TierConfig:
    """Declarative configuration for a single Phase 6.5 tier."""

    tier_id: str
    enabled: bool
    skip_reason: str | None = None
    port: int | None = None
    health_path: str = "/health"
    boot_window_s: float = 10.0
    timeout_s: float = 5.0
    # Pass-rate gate for non-deterministic tiers (#292). T0/T1/T2/T4 stay at
    # the defaults (single run, 100% threshold) so existing behaviour is
    # unchanged; only T3 sets ``runs=3, pass_rate_threshold=1.0`` so a flaky
    # scenario passing 2/3 reports failed under the strict-by-default policy.
    runs: int = 1
    pass_rate_threshold: float = 1.0


@dataclass(frozen=True)
class AgentSpec:
    """Declarative Phase 6.5 verification spec.

    ``tiers`` is a tuple (not a list) so the dataclass remains hashable
    and unambiguously immutable. ``scenarios`` carries the per-Scope-
    section :class:`Scenario` groups (#285) consumed by T2/T3.
    """

    requirements_hash: str
    tiers: tuple[TierConfig, ...]
    base_url: str = "http://127.0.0.1:8000"
    entry_cmd: tuple[str, ...] = field(default_factory=tuple)
    scenarios: tuple[Scenario, ...] = field(default_factory=tuple)


def build_agent_spec(
    project_dir: Path,  # noqa: ARG001 — reserved for future scope detection
    requirements_text: str,
    tier_flags: dict[str, bool],
) -> AgentSpec:
    """Build an ``AgentSpec`` from requirements text and tier flags.

    Pure: performs no I/O. The same ``requirements_text`` always yields
    the same ``requirements_hash`` (SHA-256). ``tier_flags`` keys are
    tier ids (``"T3"``, ``"T4"``); when ``False`` the resulting
    ``TierConfig`` carries a stable ``skip_reason`` so downstream
    consumers can surface "why was this skipped" without re-deriving.
    """
    requirements_hash = hashlib.sha256(requirements_text.encode("utf-8")).hexdigest()
    tiers = (
        TierConfig(tier_id="T0", enabled=True),
        TierConfig(tier_id="T1", enabled=True, port=8000),
        TierConfig(tier_id="T2", enabled=True),
        _optional_tier("T3", tier_flags.get("T3", False), "no frontend"),
        _optional_tier("T4", tier_flags.get("T4", False), "no docker"),
    )
    return AgentSpec(requirements_hash=requirements_hash, tiers=tiers)


_TIER_DEFAULTS: dict[str, dict[str, object]] = {
    # T3 is non-deterministic by nature (browser timing, network) — require
    # 3 runs at 100% pass-rate to gate flaky scenarios (#292).
    "T3": {"runs": 3, "pass_rate_threshold": 1.0},
}


def _optional_tier(tier_id: str, enabled: bool, skip_reason: str) -> TierConfig:
    extras = _TIER_DEFAULTS.get(tier_id, {})
    return TierConfig(
        tier_id=tier_id,
        enabled=enabled,
        skip_reason=None if enabled else skip_reason,
        **extras,  # type: ignore[arg-type]
    )


def persist_agent_spec(spec: AgentSpec, dot_dir: Path) -> Path:
    """Atomically persist *spec* to ``<dot_dir>/phase6_5_spec.json``.

    Returns the resolved spec path. Rejects ``dot_dir`` values that
    contain ``..`` traversal components, mirroring ``memory.py``.
    """
    target = _validated_spec_path(dot_dir)
    target.parent.mkdir(parents=True, exist_ok=True)

    payload = json.dumps(_to_jsonable(spec), indent=2, sort_keys=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(payload, encoding="utf-8")
    os.replace(tmp, target)
    return target


def load_agent_spec(dot_dir: Path) -> AgentSpec:
    """Load and deserialize ``<dot_dir>/phase6_5_spec.json``.

    Raises:
        FileNotFoundError: When the spec file is absent. Callers must
            handle this explicitly — silent ``None`` returns would mask
            bugs in adaptive tier selection (#281).
    """
    target = _validated_spec_path(dot_dir)
    if not target.exists():
        raise FileNotFoundError(f"AgentSpec not found at {target}")
    return _from_jsonable(json.loads(target.read_text(encoding="utf-8")))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _validated_spec_path(dot_dir: Path) -> Path:
    if ".." in dot_dir.parts:
        raise ValueError(f"dot_dir {dot_dir!r} contains traversal component '..'")
    return dot_dir / _SPEC_FILENAME


def _to_jsonable(spec: AgentSpec) -> dict[str, object]:
    return {
        "requirements_hash": spec.requirements_hash,
        "tiers": [dataclasses.asdict(tier) for tier in spec.tiers],
        "base_url": spec.base_url,
        "entry_cmd": list(spec.entry_cmd),
        "scenarios": [dataclasses.asdict(scenario) for scenario in spec.scenarios],
    }


def _from_jsonable(data: dict[str, object]) -> AgentSpec:
    raw_tiers = data.get("tiers", [])
    if not isinstance(raw_tiers, list):
        raise ValueError(f"AgentSpec.tiers must be a list, got {type(raw_tiers).__name__}")
    tiers = tuple(TierConfig(**tier) for tier in raw_tiers)
    raw_entry = data.get("entry_cmd") or ()
    if not isinstance(raw_entry, list | tuple):
        raise ValueError(
            f"AgentSpec.entry_cmd must be a list/tuple, got {type(raw_entry).__name__}"
        )
    return AgentSpec(
        requirements_hash=str(data["requirements_hash"]),
        tiers=tiers,
        base_url=str(data.get("base_url", "http://127.0.0.1:8000")),
        entry_cmd=tuple(str(item) for item in raw_entry),
        scenarios=_scenarios_from_jsonable(data.get("scenarios", [])),
    )


def _scenarios_from_jsonable(raw: object) -> tuple[Scenario, ...]:
    from code_generator.orchestrator.criteria_oracle import CriterionMapping
    from code_generator.orchestrator.scenario_builder import Scenario

    if not isinstance(raw, list):
        raise ValueError(f"AgentSpec.scenarios must be a list, got {type(raw).__name__}")
    scenarios: list[Scenario] = []
    for item in raw:
        if not isinstance(item, dict):
            raise ValueError(f"scenario entry must be a dict, got {type(item).__name__}")
        criteria = tuple(CriterionMapping(**c) for c in item.get("criteria", []))
        scenarios.append(
            Scenario(
                name=str(item["name"]),
                section_index=int(item["section_index"]),
                criteria=criteria,
                t2_endpoints=tuple(str(e) for e in item.get("t2_endpoints", [])),
                t3_flows=tuple(str(f) for f in item.get("t3_flows", [])),
            )
        )
    return tuple(scenarios)
