"""Phase 8 — Project finalization (Cycle 3 wiring).

After the Opus 4.7 confirmation prompt returns, the orchestrator:

1. Generates and writes ``.github/workflows/`` via
   :mod:`phase8_workflow_gen`. Generated paths are recorded on
   ``target.phase8.workflow_files_written``.
2. When ``state.repo`` is set, commits the workflow files via the
   standard ``git_add_all → git_commit → git_push`` flow with one
   rebase-and-retry on rejection (mirrors Phase 7).
3. When ``state.repo`` is ``None`` (local-only dev), records
   ``ci_status="skipped"``, ticks ``professionalized``, and returns —
   single-repo development is not penalized for a missing remote.
4. When the repo is configured, dispatches
   :func:`phase8_repair_loop.run_ci_green_gate`. On ``"green"``: the
   cycle-2 semver tag (if any) is relocated to the new HEAD via
   :func:`git_ops.git_tag_move`, and ``professionalized`` is ticked. On
   ``"exhausted"``: a warning is logged, the run finishes cleanly, and
   ``professionalized`` is left un-ticked (the repair loop already
   opened the remediation issue).

Non-negotiable #8: the model is hard-coded via ``effort.phase_model(8)``
(Opus 4.7). The Ollama/Codex/Gemini single-model paths override this via
``effective_model``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from code_generator import checklist as _checklist
from code_generator import effort as _effort
from code_generator import state as _state
from code_generator.git_ops import (
    GitError,
    git_add_all,
    git_commit,
    git_current_branch,
    git_pull_rebase,
    git_push,
    git_tag_list,
    git_tag_move,
)
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.orchestrator import phase8_repair_loop, phase8_workflow_gen
from code_generator.prompts import PromptError, load_prompt
from code_generator.runner import rate_limit
from code_generator.runner._telemetry import accumulate_telemetry
from code_generator.runner.cache_breakpoints import resolve_active_ttl
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.runner.phase_telemetry import accumulate_phase_telemetry
from code_generator.runner.types import TokenUsage
from code_generator.state import CycleState, Phase8Progress, utc_now_isoformat

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.repo_info import RepoInfo
    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import IssueState, State


_PHASE8_DEFAULT_MODEL = _effort.phase_model(8)
# CLAUDE.md invariant #8; overridden via ``effective_model`` on Ollama / Codex / Gemini.

_PROMPT_FINALIZATION_SENTINEL = "CI_GREEN_GATE"
_WORKFLOW_COMMIT_MSG = "ci: add GitHub Actions workflows for green-gate"


def _assert_prompt_sentinel(prompt: str) -> None:
    """Fail fast when the CI_GREEN_GATE section was removed from the prompt."""
    if _PROMPT_FINALIZATION_SENTINEL not in prompt:
        raise PromptError(
            f"prompt-phase-8-finalization.md missing sentinel: {_PROMPT_FINALIZATION_SENTINEL!r}"
        )


def _closed_issue_numbers(state: State, cycle: CycleState | None) -> list[int]:
    """Sorted issue numbers marked closed in the current scope."""
    issues: list[IssueState] = cycle.issues if cycle is not None else state.issues
    return sorted(i.number for i in issues if i.status == "closed")


def _tick_professionalized_for_closed_issues(
    state: State,
    cycle: CycleState | None,
    state_path: Path,
    logger: logging.Logger,
) -> None:
    """Tick ``professionalized`` for every closed issue in scope (#301)."""
    if state.requirements_hash is None:
        logger.warning("Phase 8: skipping checklist tick — state.requirements_hash is None.")
        return
    checklist_path = state_path.parent / "checklists" / f"{state.requirements_hash}.json"
    for number in _closed_issue_numbers(state, cycle):
        _checklist.tick_professionalized(checklist_path, number)


def _write_workflows(project_dir: Path, target: CycleState | State) -> list[str]:
    """Write managed workflow files; return their repo-relative paths."""
    written: list[str] = []
    for wf in phase8_workflow_gen.generate_workflows(project_dir):
        if wf.content is None:
            continue
        target_path = project_dir / wf.rel_path
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_text(wf.content, encoding="utf-8")
        written.append(wf.rel_path)
    if target.phase8 is not None:
        target.phase8.workflow_files_written = written
    return written


def _commit_workflows(project_dir: Path, logger: logging.Logger) -> None:
    """Stage + commit + push the workflow files with one rebase-and-retry."""
    git_add_all(project_dir)
    git_commit(project_dir, _WORKFLOW_COMMIT_MSG)
    branch = git_current_branch(project_dir)
    try:
        git_push(project_dir, branch)
    except GitError:
        logger.warning("Phase 8: workflow push rejected — rebasing and retrying.")
        git_pull_rebase(project_dir)
        git_push(project_dir, branch)


def _handle_green(
    project_dir: Path,
    state: State,
    cycle: CycleState | None,
    state_path: Path,
    logger: logging.Logger,
) -> None:
    """Move the cycle-2 semver tag (if any) and tick ``professionalized``."""
    tags = git_tag_list(project_dir)
    if tags:
        tag = tags[0]
        git_tag_move(project_dir, tag, f"CI green-gate passed: {tag}")
    _tick_professionalized_for_closed_issues(state, cycle, state_path, logger)


def _handle_exhausted(logger: logging.Logger) -> None:
    """Log a warning; the repair loop already opened the remediation issue."""
    logger.warning("Phase 8: CI repair budget exhausted — leaving professionalized un-ticked.")


def _handle_skipped(
    state: State,
    cycle: CycleState | None,
    state_path: Path,
    logger: logging.Logger,
) -> None:
    """No remote → tick ``professionalized`` and return cleanly."""
    logger.warning("Phase 8: state.repo is None — CI green-gate skipped (local-only dev).")
    _tick_professionalized_for_closed_issues(state, cycle, state_path, logger)


async def _run_ci_green_gate(
    *,
    repo: RepoInfo,
    project_dir: Path,
    state_path: Path,
    state: State,
    cycle: CycleState | None,
    runner_module: RunnerProtocol,
    effective_model: str | None,
    logger: logging.Logger,
) -> phase8_repair_loop.CiOutcome:
    """Thin dispatcher over the repair-loop entry point (DI seam for tests)."""
    return await phase8_repair_loop.run_ci_green_gate(
        repo,
        project_dir,
        state_path,
        state,
        cycle,
        runner_module=runner_module,
        effective_model=effective_model,
        logger=logger,
    )


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Execute Phase 8 finalization with the Cycle 3 CI green-gate wiring."""
    if logger is None:
        logger = setup_phase_logger("phase8", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"
    target = cycle if cycle is not None else state
    cycle_name = cycle.name if cycle is not None else ""

    started_at = utc_now_isoformat()
    target.phase8 = Phase8Progress(attempt=1, status="running", started_at=started_at)
    _state.save_state(state_path, state)

    result = await _invoke_finalization_prompt(
        project_dir=project_dir,
        state=state,
        state_path=state_path,
        runner_module=runner_module,
        logger=logger,
        max_turns=max_turns,
        effective_model=effective_model,
        cycle_name=cycle_name,
    )

    _write_workflows(project_dir, target)

    if state.repo is None or not (project_dir / ".git").exists():
        target.phase8.ci_status = "skipped"
        _state.save_state(state_path, state)
        _handle_skipped(state, cycle, state_path, logger)
    else:
        _commit_workflows(project_dir, logger)
        outcome = await _run_ci_green_gate(
            repo=state.repo,
            project_dir=project_dir,
            state_path=state_path,
            state=state,
            cycle=cycle,
            runner_module=runner_module,
            effective_model=effective_model,
            logger=logger,
        )
        target.phase8.ci_status = outcome
        _state.save_state(state_path, state)
        if outcome == "green":
            _handle_green(project_dir, state, cycle, state_path, logger)
        else:
            _handle_exhausted(logger)

    target.phase8.status = "ok"
    target.phase8.finished_at = utc_now_isoformat()

    _accumulate_phase_telemetry(state, cycle, target, result)
    _state.save_state(state_path, state)
    log_phase_usage(logger, 8, target.token_usage["phase8"])
    logger.info("Phase 8: finalization complete (ci_status=%s).", target.phase8.ci_status)


async def _invoke_finalization_prompt(
    *,
    project_dir: Path,
    state: State,
    state_path: Path,
    runner_module: RunnerProtocol,
    logger: logging.Logger,
    max_turns: int | None,
    effective_model: str | None,
    cycle_name: str,
) -> object:
    """Render the finalization prompt and call ``rate_limit.main_loop``."""
    prompt = load_prompt("prompt-phase-8-finalization.md", CYCLE_NAME=cycle_name)
    _assert_prompt_sentinel(prompt)

    effort_level = _effort.resolve_effort(
        phase=8,
        complexity=state.mode,
        issue_labels=[],
        retry_count=0,
    )
    _effort.validate_effort(effort_level, effective_model or _PHASE8_DEFAULT_MODEL)

    options = make_agent_options(
        model=effective_model or _PHASE8_DEFAULT_MODEL,
        effort=effort_level,
        allowed_tools=["Read"],
        cwd=str(project_dir),
        **max_turns_kwargs(max_turns),
    )
    return await rate_limit.main_loop(
        runner_module,
        prompt,
        options,
        state_path=state_path,
        logger=logger,
    )


def _accumulate_phase_telemetry(
    state: State,
    cycle: CycleState | None,
    target: CycleState | State,
    result: object,
) -> None:
    """Fold the run-result telemetry into ``target.token_usage['phase8']``."""
    target.token_usage["phase8"] = TokenUsage()
    accumulate_phase_telemetry(
        target.token_usage["phase8"],
        ttl=resolve_active_ttl(state, cycle, bp_index=2),
        usage=result.usage,  # type: ignore[attr-defined]
        compaction_delta=result.compaction_events,  # type: ignore[attr-defined]
        clear_delta=result.clear_events,  # type: ignore[attr-defined]
    )
    if isinstance(target, CycleState):
        accumulate_telemetry(target.cache_telemetry, result.usage, result.wall_seconds)  # type: ignore[attr-defined]
