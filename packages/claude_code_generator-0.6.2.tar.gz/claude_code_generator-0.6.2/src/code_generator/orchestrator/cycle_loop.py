"""Multi-cycle driver: single-mode and multi-cycle orchestration loops.

Implements the phase 1→7 execution in dependency order for multi-cycle mode.
Each cycle gets a fresh SDK session (non-negotiable #6: no ``options.resume``
across cycle boundaries).

Topological iteration:
    A cycle is eligible when all its ``depends_on`` cycle IDs have
    ``status == "completed"``. The loop iterates until no further eligible
    cycles remain. Cycles with unmet dependencies after all eligible ones are
    exhausted remain as ``"open"``.
"""

from __future__ import annotations

import logging
import os
import shutil
from typing import TYPE_CHECKING, Any, Literal

from code_generator import env as _env
from code_generator import gh, git_ops
from code_generator import state as _state
from code_generator.exceptions import OllamaModelRequiredError
from code_generator.logging_setup import setup_phase_logger
from code_generator.orchestrator import (
    phase1_plan,
    phase2_review,
    phase3_4_implement,
    phase5_closure,
    phase6_5_verify,
    phase6_test,
    phase7_commit,
    phase8_finalization,
)
from code_generator.orchestrator._cache_warmup import warm_workspace_cache
from code_generator.orchestrator._client_lifecycle import managed_shared_client
from code_generator.orchestrator._memory_writers import (
    append_cycle_summaries,
    reset_cycle_summary,
    write_project_plan,
)
from code_generator.orchestrator.ollama_budget import OllamaBudgetTracker
from code_generator.runner.memory_tool import is_memory_tool_available
from code_generator.state import CycleState

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import State


# Canonical phase numbers in execution order.
# Phase 3 and 4 are combined into a single implementation phase; the canonical
# boundary stored in state is 4 (the upper bound of the combined phase).
# These constants are used in guard conditions and state updates so that both
# locations stay in sync and no magic numbers appear in the code.
_PHASE_PLAN = 1
_PHASE_REVIEW = 2
_PHASE_IMPLEMENT = 4  # Combined phases 3+4; upper bound is 4.
_PHASE_CLOSURE = 5
_PHASE_TEST = 6
_PHASE_COMMIT = 7
# Phase 6.5 (runtime verification) sits between Phase 6 and Phase 7. The integer
# alias 65 fits the guard arithmetic (#276): the Phase 6.5 guard runs only when
# the previous phase was exactly _PHASE_TEST, so the larger numeric value does
# not cause spurious re-entry on resume from later phases. ``next_start_phase``
# in ``commands/_resume.py`` maps a recorded 65 back to ``_PHASE_COMMIT`` so a
# crash mid-Phase-7 resumes at Phase 7 instead of replaying Phase 6.5.
_PHASE_VERIFY = 65
# Phase 8 (project finalization, #303) — runs exactly once at the tail of a
# successful pipeline run: after Phase 7 in single-mode, and once after the
# final cycle's Phase 7 in multi-cycle mode (never per-cycle).
_PHASE_PROFESSIONALIZE = 8


# ---------------------------------------------------------------------------
# §17: Prompt-hash + SDK-version population
# ---------------------------------------------------------------------------


def populate_cycle_start_fields(state: State, state_path: Path) -> None:
    """Populate ``prompt_hashes`` and ``sdk_version`` and persist atomically.

    Called once at cycle start (before Phase 0) so that a subsequent
    ``--continue`` can detect out-of-band prompt edits or SDK upgrades.

    Args:
        state: Root state (mutated in place).
        state_path: Path to ``state.json`` for the atomic write.
    """
    from code_generator.env import detect_sdk_version
    from code_generator.prompts.hashes import compute_all_prompt_hashes

    state.prompt_hashes = compute_all_prompt_hashes()
    state.sdk_version = detect_sdk_version()
    _state.save_state(state_path, state)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _eligible_cycles(state: State, completed_ids: set[int]) -> list[CycleState]:
    """Return cycles whose dependencies are all completed and which are open.

    Args:
        state: Root state with ``cycles`` list.
        completed_ids: Set of cycle IDs already completed this run.

    Returns:
        List of :class:`~code_generator.state.CycleState` objects that are
        eligible to run (open + all deps satisfied).
    """
    return [
        c
        for c in state.cycles
        if isinstance(c, CycleState)
        and c.status == "open"
        and all(dep in completed_ids for dep in c.depends_on)
    ]


def _archive_cycle_logs(project_dir: Path, cycle_id: int) -> None:
    """Move completed cycle log files into a per-cycle subdirectory.

    Finds all files matching ``cycle{cycle_id}_*.log`` inside
    ``.code-generator/logs/`` and moves them to
    ``.code-generator/logs/cycle-{cycle_id}/``.  Existing files in the
    destination are overwritten.  A missing source match is a no-op.

    Args:
        project_dir: Root directory of the project being generated.
        cycle_id: Numeric ID of the cycle whose logs are to be archived.
    """
    logs_dir = project_dir / ".code-generator" / "logs"
    matches = [f for f in logs_dir.glob("*.log") if f.name.startswith(f"cycle{cycle_id}_")]
    if not matches:
        return
    dest_dir = logs_dir / f"cycle-{cycle_id}"
    dest_dir.mkdir(parents=True, exist_ok=True)
    for log_file in matches:
        shutil.move(str(log_file), str(dest_dir / log_file.name))


def _capture_base_commit(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    state_path: Path,
) -> None:
    """Capture HEAD SHA as base_commit before Phase 3/4, if not already set.

    Idempotent: a ``--continue`` resume that finds ``base_commit`` already
    set will not overwrite it.  A :class:`~code_generator.git_ops.GitError`
    is logged as a warning and the cycle continues without a baseline.

    Args:
        state: Root state (mutated in place).
        cycle: Active cycle, or ``None`` for single-mode.
        project_dir: Project root directory.
        state_path: Path to ``state.json`` for atomic persistence.
    """
    target = cycle if cycle is not None else state
    if target.base_commit is not None:
        return
    try:
        target.base_commit = git_ops.git_rev_parse_head(project_dir)
        _state.save_state(state_path, state)
    except git_ops.GitError:
        logging.getLogger(__name__).warning(
            "Could not capture base_commit: project_dir=%s is not a git repo or has no commits.",
            project_dir,
        )


# ---------------------------------------------------------------------------
# Shared phase sequence runner
# ---------------------------------------------------------------------------


def _resolve_effective_model(state: State, cycle: CycleState | None) -> str | None:
    """Return the model tag that overrides every phase, or None.

    Priority: cycle.codex_model / gemini_model / ollama_model (multi-cycle) >
    state.codex_model / gemini_model (single-mode) >
    state.cycles[-1].codex_model / gemini_model / ollama_model
    (single-mode fallback when ``cycle`` is not yet bound).

    Raises:
        OllamaModelRequiredError: When the Ollama codepath is detected
            (``ANTHROPIC_BASE_URL`` is localhost) and no model tag can be
            resolved from state/cycle — this prevents a silent fallback
            to an Anthropic model name.
    """
    if cycle is not None:
        if cycle.codex_model:
            return cycle.codex_model
        if cycle.gemini_model:
            return cycle.gemini_model
        if cycle.ollama_model:
            return cycle.ollama_model

    if cycle is None:
        if state.codex_model:
            return state.codex_model
        if state.gemini_model:
            return state.gemini_model
        if state.cycles:
            last = state.cycles[-1]
            if isinstance(last, CycleState):
                if last.codex_model:
                    return last.codex_model
                if last.gemini_model:
                    return last.gemini_model
                if last.ollama_model:
                    return last.ollama_model

    if _env._is_localhost_base_url(os.environ.get("ANTHROPIC_BASE_URL")):  # noqa: SLF001
        raise OllamaModelRequiredError(
            reason=(
                "Ollama daemon routing is active but no model tag is resolvable "
                "from state.json. This happens when --continue is used on a "
                "legacy state file that predates the ollama_model field, or "
                "when --model was omitted on a fresh run."
            ),
            fix_action=(
                "Re-run with --model <tag> to supply the model explicitly, e.g.: "
                "code-generator generate ollama --model qwen3-coder:480b:cloud"
            ),
        )

    return None


async def _run_phases(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    runner_module: RunnerProtocol,
    log_prefix: str,
    start_phase: int,
    shared_client: Any = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Execute phases 1→7 for single-mode or a cycle, eliminating duplication.

    Handles the full phase-sequence including phase 5's fix re-entry.  The
    caller supplies ``log_prefix`` so logger names remain distinct between
    single-mode (``"phase1"``, …) and per-cycle runs
    (``"cycle{id}_phase1"``, …).

    Args:
        state: Root state object (mutated in place).
        cycle: Active cycle, or ``None`` for single-mode.
        project_dir: Project root directory.
        runner_module: Runner module returned by ``get_runner()``.
        log_prefix: Prepended to every phase logger name.  Use ``""`` for
            single-mode and ``f"cycle{cycle.id}_"`` for per-cycle runs.
        start_phase: First phase to execute; earlier phases are skipped.
        shared_client: Open ``ClaudeSDKClient`` (or duck-typed equivalent)
            owned by the caller, or ``None`` in fresh-mode.  Threaded to
            Phases 2/3/4/5 only; Phases 1/6/7 never see it.
    """
    state_path = project_dir / ".code-generator" / "state.json"

    def _phase_logger(name: str):  # type: ignore[return]
        return setup_phase_logger(f"{log_prefix}{name}", project_dir)

    def _set_phase(n: int) -> None:
        if cycle is not None:
            cycle.phase = n
        else:
            state.phase = n

    # §17: Populate prompt_hashes + sdk_version before Phase 0 (idempotent).
    populate_cycle_start_fields(state, state_path)

    # #219: resolve the Ollama model override from state when the caller did
    # not pass one explicitly. The resolver returns None on the Anthropic Max
    # path, leaving each phase's per-phase default intact.
    if effective_model is None:
        effective_model = _resolve_effective_model(state, cycle)

    # #268: belt-and-suspenders — when the Ollama codepath is active
    # (effective_model is set) but the tag starts with "claude-", the operator
    # almost certainly intended a local model.  Refuse before any phase runs
    # so a mistyped tag never reaches the daemon (which would emit a cryptic
    # "model may not exist").
    if effective_model is not None and effective_model.startswith("claude-"):
        raise OllamaModelRequiredError(
            reason=(
                f"Ollama single-model routing is active but the model tag "
                f"{effective_model!r} starts with 'claude-'. "
                "This likely indicates a misconfiguration — did you mean "
                "to use an Ollama model tag?"
            ),
            fix_action=(
                "Pass a valid Ollama model tag instead, e.g.: "
                "code-generator generate ollama --model qwen3-coder:480b:cloud"
            ),
        )

    # #220: Ollama per-cycle budget tracker. ``effective_model is not None``
    # uniquely identifies the Ollama codepath inside the orchestrator, so we
    # key activation off it rather than threading an extra ``provider`` flag.
    # On the Anthropic Max path the tracker is inert and every check() is a
    # cheap no-op.
    _budget = OllamaBudgetTracker(provider_is_ollama=effective_model is not None)
    _budget.start()

    def _clear_error_and_save() -> None:
        """Reset stale error markers and persist state after a successful phase.

        Also enforces the Ollama per-cycle turn + wall-clock budgets (#220).
        The check is a no-op on the Anthropic Max path.
        """
        state.last_error = None
        state.rate_limit_type = None
        _state.save_state(state_path, state)
        _budget.check(state, cycle)

    if start_phase <= _PHASE_PLAN:
        await phase1_plan.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase1"),
            max_turns=max_turns,
            effective_model=effective_model,
        )
        _set_phase(_PHASE_PLAN)
        _clear_error_and_save()
        # Initialise cycle memory files immediately after Phase 1 so subsequent
        # phases (2, 3/4, 5) can read them via the memory tool.
        memories_dir = project_dir / ".code-generator" / "memories"
        # Issue #238: when the SDK exposes the memory tool, the model owns the
        # cycle-summary content (writes via `memory.create`). The orchestrator
        # only resets the file when no memory tool is available — the legacy
        # file-write flow stays as fallback per review-comment #c so a
        # mid-cycle memory-tool failure does not lose cross-issue knowledge.
        if not is_memory_tool_available():
            reset_cycle_summary(memories_dir)
        write_project_plan(_state.get_issues(state, cycle), memories_dir)

    # §12 once-per-cycle cache pre-warm (issue #241). Idempotency lives on the
    # active scope — multi-cycle uses CycleState.cache_prewarmed; single-mode
    # uses State.cache_prewarmed. Skipped when shared_client is None
    # (fresh-mode) and when --continue resumes a cycle whose flag is True.
    _prewarm_target = cycle if cycle is not None else state
    if shared_client is not None and not _prewarm_target.cache_prewarmed:
        await warm_workspace_cache(
            shared_client,
            project_dir=project_dir,
            logger=_phase_logger("cache_warmup"),
        )
        _prewarm_target.cache_prewarmed = True
        _state.save_state(state_path, state)

    if start_phase <= _PHASE_REVIEW:
        await phase2_review.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase2"),
            shared_client=shared_client,
            max_turns=max_turns,
            effective_model=effective_model,
        )
        _set_phase(_PHASE_REVIEW)
        _clear_error_and_save()

    if start_phase <= _PHASE_IMPLEMENT:
        _capture_base_commit(state, cycle, project_dir, state_path)
        await phase3_4_implement.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase3_4"),
            shared_client=shared_client,
            max_turns=max_turns,
            effective_model=effective_model,
        )
        _set_phase(_PHASE_IMPLEMENT)
        _clear_error_and_save()

        from code_generator.orchestrator import vigil

        await vigil.check_premature_done(
            state,
            cycle,
            project_dir,
            state_path,
            logger=_phase_logger("vigil"),
        )

    if start_phase <= _PHASE_CLOSURE:
        fix_result = await phase5_closure.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase5"),
            shared_client=shared_client,
            max_turns=max_turns,
            effective_model=effective_model,
        )
        _set_phase(_PHASE_CLOSURE)
        _clear_error_and_save()
        # Re-enter implementation for any fix issues detected by phase 5.
        if fix_result.new_issues:
            await phase3_4_implement.run(
                state,
                cycle,
                project_dir,
                runner_module=runner_module,
                logger=_phase_logger("phase3_4_fix"),
                shared_client=shared_client,
                max_turns=max_turns,
                effective_model=effective_model,
            )
            _clear_error_and_save()

    if start_phase <= _PHASE_TEST:
        await phase6_test.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase6"),
            max_turns=max_turns,
            effective_model=effective_model,
        )
        _set_phase(_PHASE_TEST)
        _clear_error_and_save()

    # Phase 6.5 (runtime verification, #276) sits between Phase 6 and Phase 7.
    # The strict guard ``current_phase == _PHASE_TEST`` ensures Phase 6.5 only
    # fires immediately after a successful Phase 6 — a resume from Phase 7
    # (current_phase=7) or a fully-completed cycle (current_phase=65) cannot
    # accidentally re-trigger it. Skipped in fresh mode (no shared client) as
    # Phase 6.5 requires the per-cycle ClaudeSDKClient (non-negotiable #6).
    _current_phase = (cycle.phase if cycle is not None else state.phase) or 0
    if start_phase <= _PHASE_VERIFY and shared_client is not None and _current_phase == _PHASE_TEST:
        await phase6_5_verify.run(
            state,
            cycle,
            project_dir,
            state_path,
            runner_module=runner_module,
            logger=_phase_logger("phase6_5"),
            shared_client=shared_client,
            max_turns=max_turns,
            effective_model=effective_model,
        )
        _set_phase(_PHASE_VERIFY)
        _clear_error_and_save()

    if start_phase <= _PHASE_COMMIT:
        commit_subject = await phase7_commit.run(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase7"),
            max_turns=max_turns,
            effective_model=effective_model,
        )
        _set_phase(_PHASE_COMMIT)
        _clear_error_and_save()
        # Append per-issue summary lines now that the commit subject is known.
        # Issue #238: skip on the memory-tool path — model writes via the tool.
        if not is_memory_tool_available():
            memories_dir = project_dir / ".code-generator" / "memories"
            append_cycle_summaries(_state.get_issues(state, cycle), commit_subject, memories_dir)

    # Phase 8 (project finalization, #303). Fires exactly once at the tail of a
    # successful pipeline run. Single-mode only here — multi-cycle invokes it
    # post-loop in ``run_multi_cycle`` so it runs once on the root state, not
    # per-cycle. The eligibility guard ``start_phase <= _PHASE_PROFESSIONALIZE``
    # naturally blocks a resume past Phase 8 (``--phase 9`` or higher).
    if cycle is None and start_phase <= _PHASE_PROFESSIONALIZE:
        await phase8_finalization.run(
            state,
            None,
            project_dir,
            runner_module=runner_module,
            logger=_phase_logger("phase8"),
            max_turns=max_turns,
            effective_model=effective_model,
        )
        _set_phase(_PHASE_PROFESSIONALIZE)
        _clear_error_and_save()


# ---------------------------------------------------------------------------
# Single-mode driver
# ---------------------------------------------------------------------------


async def run_single_mode(
    state: State,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    start_phase: int = 1,
    session_mode: Literal["shared", "fresh", "batch"] = "shared",
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> State:
    """Execute the single-mode pipeline: phases 1→7.

    Non-negotiable #6 is respected by phase 3/4, which clears ``session_id``
    before each issue. This function itself does not set ``options.resume``.

    Args:
        state: Root state object (mutated in place and returned).
        project_dir: Project root directory.
        runner_module: Runner module returned by ``get_runner()``.
        logger: Optional phase logger; one is created when omitted.
        start_phase: First phase to execute. Phases below this number are
            skipped. Defaults to 1 (full run).
        session_mode: SDK session strategy threaded from the CLI flag.
            ``"shared"`` reuses one client per cycle; ``"fresh"`` creates a
            new client per issue (0.2.x behaviour).  Client lifecycle is
            owned by issue #2 — this parameter is accepted here so the
            signature is wired end-to-end before that work lands.

    Returns:
        The mutated state.

    Raises:
        OverageAbort: Propagated unchanged from any phase.
        RateLimitHit: Propagated unchanged from any phase.
        TestsFailed: When phase 6 reports persistent test failures.
        CircuitOpen: When phase 2's circuit breaker trips.
    """
    log = logger or setup_phase_logger("cycle_loop", project_dir)
    log.info("run_single_mode: start_phase=%d", start_phase)

    state_path = project_dir / ".code-generator" / "state.json"

    if state.session_mode in ("shared", "batch"):
        async with managed_shared_client(
            state, state_path, effective_model=effective_model
        ) as client:
            await _run_phases(
                state,
                None,
                project_dir,
                runner_module,
                log_prefix="",
                start_phase=start_phase,
                shared_client=client,
                max_turns=max_turns,
                effective_model=effective_model,
            )
    else:
        await _run_phases(
            state,
            None,
            project_dir,
            runner_module,
            log_prefix="",
            start_phase=start_phase,
            shared_client=None,
            max_turns=max_turns,
            effective_model=effective_model,
        )

    log.info("run_single_mode: complete")
    return state


# ---------------------------------------------------------------------------
# Multi-cycle driver
# ---------------------------------------------------------------------------


async def run_multi_cycle(
    state: State,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    start_cycle: int | None = None,
    start_phase: int = 1,
    session_mode: Literal["shared", "fresh", "batch"] = "shared",
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> State:
    """Execute cycles in dependency order, each with a fresh SDK session.

    Eligible cycles are those whose ``depends_on`` cycle IDs are all
    ``"completed"``. The loop keeps running until no further eligible
    cycles remain.

    Non-negotiable #6: ``state.session_id`` is set to ``None`` at the entry
    of every cycle and persisted before any phase runs.

    Args:
        state: Root state object (mutated in place and returned).
        project_dir: Project root directory.
        runner_module: Runner module returned by ``get_runner()``.
        logger: Optional phase logger; one is created when omitted.
        start_cycle: When set, cycles with ``id < start_cycle`` are skipped
            even if their dependencies are not completed. The phase resume
            applies only to the *first* eligible cycle visited.
        start_phase: Resume from this phase in the first eligible cycle.
            Subsequent cycles always start at phase 1.
        session_mode: SDK session strategy threaded from the CLI flag.
            ``"shared"`` reuses one client per cycle; ``"fresh"`` creates a
            new client per issue (0.2.x behaviour).  Client lifecycle is
            owned by issue #2 — this parameter is accepted here so the
            signature is wired end-to-end before that work lands.

    Returns:
        The mutated state.

    Raises:
        OverageAbort: Propagated unchanged — stops all cycles.
        RateLimitHit: Propagated unchanged — stops all cycles.
        TestsFailed: When phase 6 fails — stops remaining cycles.
        CircuitOpen: Propagated unchanged — stops all cycles.
    """
    log = logger or setup_phase_logger("cycle_loop", project_dir)
    state_path = project_dir / ".code-generator" / "state.json"

    resumed_from = None
    if start_cycle is not None:
        current_cycle_record = next(
            (c for c in state.cycles if isinstance(c, CycleState) and c.id == start_cycle),
            None,
        )
        if current_cycle_record is not None:
            resumed_from = current_cycle_record.phase

    log.info(
        "run_multi_cycle: start_cycle=%s start_phase=%d total_cycles=%d resumed_from=%s",
        start_cycle,
        start_phase,
        len(state.cycles),
        f"state.cycles[{start_cycle - 1}].phase={resumed_from}"
        if start_cycle is not None
        else None,
    )

    # Track which cycles have been completed during this run.
    completed_ids: set[int] = {
        c.id for c in state.cycles if isinstance(c, CycleState) and c.status == "completed"
    }

    is_first_eligible = True

    while True:
        eligible = _eligible_cycles(state, completed_ids)
        if not eligible:
            break

        for cycle in eligible:
            # Honor --cycle N: skip cycles below the requested start.
            if start_cycle is not None and cycle.id < start_cycle:
                log.info("Skipping cycle %d (below start_cycle=%d).", cycle.id, start_cycle)
                # Mark as completed so dependent cycles can run.
                cycle.status = "completed"
                completed_ids.add(cycle.id)
                # Non-negotiable #7: persist every state mutation immediately.
                _state.save_state(state_path, state)
                continue

            # Non-negotiable #6: fresh session at every cycle entry.
            state.session_id = None
            state.current_cycle = cycle.id
            _state.save_state(state_path, state)

            log.info("Starting cycle %d (%s).", cycle.id, cycle.name)

            # Record wall-clock start; idempotent so --continue does not overwrite.
            if cycle.started_at is None:
                cycle.started_at = _state.utc_now()
                _state.save_state(state_path, state)

            # start_phase applies only to the first cycle we actually run.
            effective_start_phase = start_phase if is_first_eligible else 1
            is_first_eligible = False

            try:
                await _run_cycle_phases(
                    state=state,
                    cycle=cycle,
                    project_dir=project_dir,
                    runner_module=runner_module,
                    log=log,
                    start_phase=effective_start_phase,
                    max_turns=max_turns,
                    effective_model=effective_model,
                )
            except Exception as exc:
                cycle.finished_at = _state.utc_now()
                cycle.status = "failed"
                state.last_error = str(exc)
                _state.save_state(state_path, state)
                log.error(
                    "Cycle %d (%s) failed: %s. Aborting further cycles.",
                    cycle.id,
                    cycle.name,
                    exc,
                )
                raise

            # Cycle succeeded.
            cycle.status = "completed"
            cycle.finished_at = _state.utc_now()
            completed_ids.add(cycle.id)
            _archive_cycle_logs(project_dir, cycle.id)

            # Close the milestone for this cycle.
            if cycle.milestone_number is not None and state.repo is not None:
                try:
                    gh.close_milestone(state.repo, cycle.milestone_number)
                    log.info(
                        "Closed milestone #%d for cycle %d.",
                        cycle.milestone_number,
                        cycle.id,
                    )
                except gh.GhError as exc:
                    log.warning(
                        "Could not close milestone #%d: %s",
                        cycle.milestone_number,
                        exc,
                    )

            # Close GitHub issues whose implementation was marked done by Phase 3/4.
            if state.repo is not None:
                closed_nums = sorted(i.number for i in cycle.issues if i.status == "closed")
                for num in closed_nums:
                    try:
                        gh.close_issue(state.repo, num)
                        log.info("Closed issue #%d.", num)
                    except gh.GhError as exc:
                        log.warning("Could not close issue #%d: %s", num, exc)

            _state.save_state(state_path, state)
            log.info("Cycle %d (%s) completed.", cycle.id, cycle.name)

    # Phase 8 (project finalization, #303) — fires exactly once on the root
    # ``state`` after every eligible cycle has completed. Idempotent across
    # ``--continue``: when ``state.phase8`` is already populated with
    # ``status="ok"`` the post-loop block is a no-op so a resumed run does
    # not double-execute finalization.
    _phase8_done = state.phase8 is not None and state.phase8.status == "ok"
    if start_phase <= _PHASE_PROFESSIONALIZE and not _phase8_done:
        try:
            await phase8_finalization.run(
                state,
                None,
                project_dir,
                runner_module=runner_module,
                logger=setup_phase_logger("phase8", project_dir),
                max_turns=max_turns,
                effective_model=effective_model,
            )
        except Exception as exc:
            state.last_error = str(exc)
            _state.save_state(state_path, state)
            log.error("run_multi_cycle: Phase 8 failed: %s.", exc)
            raise
        state.phase = _PHASE_PROFESSIONALIZE
        _state.save_state(state_path, state)

    log.info("run_multi_cycle: all eligible cycles complete.")
    return state


# ---------------------------------------------------------------------------
# Per-cycle phase runner
# ---------------------------------------------------------------------------


async def _run_cycle_phases(
    state: State,
    cycle: CycleState,
    project_dir: Path,
    runner_module: RunnerProtocol,
    log: logging.Logger,
    start_phase: int,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Run phases 1→7 for a single cycle, owning the shared-client lifecycle.

    When ``state.session_mode == "shared"``:
    - Strips dangerous env vars (non-negotiable #1).
    - Opens exactly one ``ClaudeSDKClient`` via ``async with``.
    - Calls ``mark_client_alive`` on entry so crash-recovery can detect an
      orphaned client on ``--continue``.
    - Calls ``clear_client_alive`` **only** on clean exit.  Exceptions
      propagate unchanged, leaving ``client_alive_at`` set so ``--continue``
      knows the client was not cleanly closed.

    When ``state.session_mode == "fresh"``, no client is opened and no
    alive-marker writes occur.

    Args:
        state: Root state (mutated in place).
        cycle: The active cycle being executed.
        project_dir: Project root directory.
        runner_module: Runner module.
        log: Logger for cycle-level messages (start / complete).
        start_phase: First phase to execute (1 = full, higher = resume).
    """
    state_path = project_dir / ".code-generator" / "state.json"
    log_prefix = f"cycle{cycle.id}_"

    if state.session_mode in ("shared", "batch"):
        async with managed_shared_client(
            state, state_path, effective_model=effective_model
        ) as client:
            await _run_phases(
                state,
                cycle,
                project_dir,
                runner_module,
                log_prefix=log_prefix,
                start_phase=start_phase,
                shared_client=client,
                max_turns=max_turns,
                effective_model=effective_model,
            )
    else:
        await _run_phases(
            state,
            cycle,
            project_dir,
            runner_module,
            log_prefix=log_prefix,
            start_phase=start_phase,
            shared_client=None,
            max_turns=max_turns,
            effective_model=effective_model,
        )

    log.info("Cycle %d phases 1-7 complete.", cycle.id)
