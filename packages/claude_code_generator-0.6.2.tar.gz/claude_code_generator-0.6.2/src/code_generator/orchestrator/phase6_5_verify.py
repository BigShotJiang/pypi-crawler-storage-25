"""Phase 6.5 — runtime verification tier executors (#273, #274).

Pure-Python building blocks for the tiered runtime-verification pipeline.
This module is intentionally side-effect free at import time and never calls
the Anthropic SDK; tier executors are synchronous and invoked from the
orchestrator (or repair loop, in a later issue).

Tiers
-----
T0 — Build.        Optional install + ``python -c "import <target>"``.
T1 — Boot smoke.   Spawn entry-point process; poll the port/health endpoint
                   for a bounded window; assert the process is still alive;
                   tear it down on every code path.
T2 — API contract. Probe ``/health`` then replay endpoints extracted from the
                   requirements' acceptance criteria; 2xx + JSON-decodable
                   bodies (GET only) constitute pass.

Cache-workspace invariant #2 is preserved by accepting the subprocess env
as a parameter: callers must hand in a dict produced by
``code_generator.env.build_agent_env()`` so credentials never leak into the
generated app's process.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Any

import httpx

from code_generator import checklist as _checklist
from code_generator import effort as _effort
from code_generator.env import build_agent_env
from code_generator.orchestrator.agent_spec import (
    AgentSpec,
    TierConfig,
    build_agent_spec,
    load_agent_spec,
    persist_agent_spec,
)
from code_generator.orchestrator.deviation_detector import DeviationDetector
from code_generator.orchestrator.failure_report import (
    FailureReport,
    format_failure_report,
)
from code_generator.orchestrator.tier_selector import select_tiers
from code_generator.prompts import load_prompt
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.runner.soft_reset import boundary_prefix_only
from code_generator.runner.types import TokenUsage
from code_generator.state import Phase65Progress, save_state

if TYPE_CHECKING:
    import logging
    from collections.abc import Mapping, Sequence
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, State

__all__ = [
    "AgentSpec",
    "Endpoint",
    "FailureReport",
    "TierConfig",
    "TierResult",
    "VerificationFailed",
    "build_agent_spec",
    "extract_endpoints_from_requirements",
    "load_agent_spec",
    "persist_agent_spec",
    "run",
    "run_t0_build",
    "run_t1_boot",
    "run_t2_api",
    "run_t3_browser",  # noqa: F822 — resolved via PEP 562 __getattr__ (import cycle)
    "run_t4_container",  # noqa: F822 — resolved via PEP 562 __getattr__ (import cycle)
]


_DEFAULT_INSTALL_CMD: list[str] = ["pip", "install", "-e", "."]
_STDERR_TAIL_CHARS = 500
_POLL_INTERVAL_S = 0.5
# Sentinel returncode used when subprocess.TimeoutExpired is translated
# into a synthetic CompletedProcess (#293). Matches GNU `timeout` convention
# while staying distinct from any plausible exit code a real process would
# emit, so ``_is_timeout`` can re-classify without false positives.
_TIMEOUT_RETURNCODE = 124


class VerificationFailed(RuntimeError):
    """Raised when Phase 6.5 exhausts its repair budget with red tiers."""


@dataclass(frozen=True)
class TierResult:
    """Structured outcome of a single Phase 6.5 tier execution.

    Cycle-2 trace fields (#282) are optional with safe defaults so
    Cycle-1 construction sites at T0/T1/T2 keep working unchanged.
    """

    tier_id: str
    passed: bool
    skipped: bool
    skip_reason: str | None
    exit_code: int | None
    stderr_tail: str | None
    failing_detail: str | None
    stdout_full: str | None = None
    http_request: str | None = None
    http_response: str | None = None
    browser_console: list[str] = field(default_factory=list)
    screenshot_path: str | None = None


@dataclass(frozen=True)
class Endpoint:
    """Single HTTP endpoint extracted from a requirements acceptance criterion."""

    path: str
    method: str = "GET"


# ---------------------------------------------------------------------------
# T0 — Build tier
# ---------------------------------------------------------------------------


def run_t0_build(
    project_dir: Path,
    *,
    env: Mapping[str, str],
    install_cmd: list[str] | None = None,
    import_target: str | None = None,
    timeout_s: float | None = None,
) -> TierResult:
    """Run the T0 build tier: install + top-level import probe.

    Returns a :class:`TierResult` with ``skipped=True`` when no installable
    manifest is present and no explicit ``install_cmd`` was supplied. Returns
    ``passed=False`` with the stderr tail when either step fails. With
    *timeout_s* the install/import subprocess calls are bounded and
    :class:`subprocess.TimeoutExpired` is mapped to a structured failure
    via :func:`_fail_timeout` (#293).
    """
    effective_install = _resolve_install_cmd(project_dir, install_cmd)
    if effective_install is None:
        return _skip("T0", "no pyproject.toml or setup.py found and no install_cmd provided")

    install = _run_capture(effective_install, project_dir, env, timeout=timeout_s)
    if _is_timeout(install):
        return _fail_timeout("T0", timeout_s, install)
    if install.returncode != 0:
        return _fail("T0", install, failing_detail="install command failed")

    if import_target is None:
        return _pass("T0", install)

    probe = _run_capture(
        [sys.executable, "-c", f"import {import_target}"],
        project_dir,
        env,
        timeout=timeout_s,
    )
    if _is_timeout(probe):
        return _fail_timeout("T0", timeout_s, probe)
    if probe.returncode != 0:
        return _fail("T0", probe, failing_detail=f"import {import_target} failed")
    return _pass("T0", probe)


# ---------------------------------------------------------------------------
# T1 — Boot smoke tier
# ---------------------------------------------------------------------------


def run_t1_boot(
    project_dir: Path,
    *,
    env: Mapping[str, str],
    entry_cmd: list[str],
    port: int = 8000,
    boot_window_s: float = 10.0,
    health_path: str = "/health",
    timeout_s: float | None = None,
) -> TierResult:
    """Run the T1 boot smoke tier: spawn entry, poll, assert alive, tear down.

    Cleans up the spawned process on every code path (success, failure,
    exception). When *timeout_s* is supplied it caps the wait window for
    readiness (#293) — distinct from :class:`TierConfig.boot_window_s`
    only because ``_tier_runner`` forwards ``tier.timeout_s`` for every
    tier as a uniform per-tier wall budget.
    """
    if not entry_cmd:
        return _skip("T1", "entry_cmd is empty")
    effective_window = min(boot_window_s, timeout_s) if timeout_s is not None else boot_window_s

    proc = _spawn_child(entry_cmd, project_dir, env)
    try:
        _poll_until_ready(proc, port, health_path, effective_window)
        return _classify_t1_outcome(proc, port)
    finally:
        _terminate_process_tree(proc)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_install_cmd(project_dir: Path, install_cmd: list[str] | None) -> list[str] | None:
    if install_cmd is not None:
        return install_cmd
    if (project_dir / "pyproject.toml").exists() or (project_dir / "setup.py").exists():
        return list(_DEFAULT_INSTALL_CMD)
    return None


def _run_capture(
    cmd: list[str],
    cwd: Path,
    env: Mapping[str, str],
    *,
    timeout: float | None = None,
) -> subprocess.CompletedProcess[str]:
    """Wrap ``subprocess.run`` with optional timeout (#293).

    On :class:`subprocess.TimeoutExpired` returns a synthetic
    :class:`subprocess.CompletedProcess` whose ``returncode`` is
    :data:`_TIMEOUT_RETURNCODE` and whose ``stderr`` carries a
    machine-parseable ``"timed out after <s>s"`` message. Callers use
    :func:`_is_timeout` to re-classify into a structured
    :class:`TierResult` with the canonical ``failing_detail``.
    """
    try:
        return subprocess.run(  # noqa: S603 — args list, no shell
            cmd,
            cwd=cwd,
            env=dict(env),
            capture_output=True,
            text=True,
            check=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        return subprocess.CompletedProcess(
            args=cmd,
            returncode=_TIMEOUT_RETURNCODE,
            stdout=_decode_capture(exc.stdout),
            stderr=_decode_capture(exc.stderr) or f"timed out after {timeout}s",
        )


def _decode_capture(raw: object) -> str:
    if raw is None:
        return ""
    if isinstance(raw, bytes):
        return raw.decode("utf-8", errors="replace")
    return str(raw)


def _is_timeout(completed: subprocess.CompletedProcess[str]) -> bool:
    return completed.returncode == _TIMEOUT_RETURNCODE


def _fail_timeout(
    tier_id: str, timeout: float | None, completed: subprocess.CompletedProcess[str]
) -> TierResult:
    detail = f"{tier_id} timed out after {timeout}s"
    return TierResult(
        tier_id=tier_id,
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=completed.returncode,
        stderr_tail=_tail(completed.stderr),
        failing_detail=detail,
    )


def _skip(tier_id: str, reason: str) -> TierResult:
    return TierResult(
        tier_id=tier_id,
        passed=False,
        skipped=True,
        skip_reason=reason,
        exit_code=None,
        stderr_tail=None,
        failing_detail=None,
    )


def _pass(tier_id: str, completed: subprocess.CompletedProcess[str]) -> TierResult:
    return TierResult(
        tier_id=tier_id,
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=completed.returncode,
        stderr_tail=None,
        failing_detail=None,
    )


def _fail(
    tier_id: str,
    completed: subprocess.CompletedProcess[str],
    *,
    failing_detail: str,
) -> TierResult:
    return TierResult(
        tier_id=tier_id,
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=completed.returncode,
        stderr_tail=_tail(completed.stderr),
        failing_detail=failing_detail,
    )


def _tail(text: str | None) -> str | None:
    if text is None:
        return None
    return text[-_STDERR_TAIL_CHARS:] if len(text) > _STDERR_TAIL_CHARS else text


def _spawn_child(entry_cmd: list[str], cwd: Path, env: Mapping[str, str]) -> subprocess.Popen[str]:
    return subprocess.Popen(  # noqa: S603 — args list, no shell
        entry_cmd,
        cwd=cwd,
        env=dict(env),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )


def _alloc_free_port() -> int:
    """Bind ``127.0.0.1:0`` to obtain an OS-assigned free TCP port, then
    release it.

    Phase 6.5 must not hardcode ``:8000`` — co-resident tooling (e.g. the
    claude-mem plugin's ``chroma run``) squats well-known ports and returns
    404 to every health probe, burning the entire repair-retry budget on a
    purely environmental collision. An ephemeral port makes that collision
    structurally impossible.

    There is a benign TOCTOU window between release here and the app binding
    the port; :func:`_ensure_verify_port` closes it by re-checking (and
    rerolling) immediately before each attempt.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _ensure_verify_port(port: int, *, logger: logging.Logger) -> int:
    """Pre-flight port guard (#2).

    If *port* was claimed by a foreign listener between attempts (a plugin
    rebinding, a leaked uvicorn from a prior run), reroll to a fresh free
    port instead of letting the squatter fail a tier and consume a retry.
    A genuine app bug still fails the tier on its own port; only
    environmental collisions are absorbed here.
    """
    if not _port_open(port):
        return port
    new_port = _alloc_free_port()
    logger.warning(
        "Phase 6.5 verify port %d occupied by a foreign listener before the "
        "attempt began; rerolled to %d so the retry budget is not spent on "
        "an environmental port collision.",
        port,
        new_port,
    )
    return new_port


def _port_open(port: int, host: str = "127.0.0.1", timeout_s: float = 0.25) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout_s):
            return True
    except OSError:
        return False


def _health_ok(port: int, health_path: str) -> bool:
    url = f"http://127.0.0.1:{port}{health_path}"
    try:
        response = httpx.get(url, timeout=0.5)
    except httpx.HTTPError:
        return False
    return response.status_code < 500


def _poll_until_ready(
    proc: subprocess.Popen[str],
    port: int,
    health_path: str,
    boot_window_s: float,
) -> None:
    deadline = time.monotonic() + boot_window_s
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            return
        if _port_open(port) and _health_ok(port, health_path):
            return
        time.sleep(_POLL_INTERVAL_S)


def _classify_t1_outcome(proc: subprocess.Popen[str], port: int) -> TierResult:
    exit_code = proc.poll()
    if exit_code is not None:
        stderr_text = proc.stderr.read() if proc.stderr is not None else None
        return TierResult(
            tier_id="T1",
            passed=False,
            skipped=False,
            skip_reason=None,
            exit_code=exit_code,
            stderr_tail=_tail(stderr_text),
            failing_detail="process exited before boot window elapsed",
        )
    if not _port_open(port):
        return TierResult(
            tier_id="T1",
            passed=False,
            skipped=False,
            skip_reason=None,
            exit_code=None,
            stderr_tail=None,
            failing_detail=f"process alive but port {port} not listening",
        )
    return TierResult(
        tier_id="T1",
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=None,
        failing_detail=None,
    )


# ---------------------------------------------------------------------------
# Endpoint extractor (#274)
# ---------------------------------------------------------------------------


_CHECKBOX_BULLET_RE = re.compile(r"^\s*-\s*\[[ xX]\]\s+(.*)$")
_BACKTICK_TOKEN_RE = re.compile(r"`([^`]+)`")
_ENDPOINT_RE = re.compile(
    r"^\s*(?:(?P<method>GET|POST|PUT|PATCH|DELETE)\s+)?"
    r"(?P<path>/[A-Za-z0-9/_{}\-]+)\s*$"
)
_FILE_SUFFIXES: frozenset[str] = frozenset({".py", ".md", ".json"})


def extract_endpoints_from_requirements(text: str) -> list[Endpoint]:
    """Return endpoints declared inside ``- [ ]`` bullets, deduped, first-seen order.

    Pure function: no I/O, no caching. Tokens must be backticked, start with
    ``/``, and not contain any source-file suffix (``.py``, ``.md``, ``.json``).
    """
    endpoints: list[Endpoint] = []
    seen: set[tuple[str, str]] = set()
    for line in text.splitlines():
        bullet = _CHECKBOX_BULLET_RE.match(line)
        if bullet is None:
            continue
        for token in _BACKTICK_TOKEN_RE.findall(bullet.group(1)):
            endpoint = _parse_endpoint_token(token)
            if endpoint is None:
                continue
            key = (endpoint.method, endpoint.path)
            if key in seen:
                continue
            seen.add(key)
            endpoints.append(endpoint)
    return endpoints


def _parse_endpoint_token(token: str) -> Endpoint | None:
    if any(suffix in token for suffix in _FILE_SUFFIXES):
        return None
    match = _ENDPOINT_RE.match(token)
    if match is None:
        return None
    method = match.group("method") or "GET"
    return Endpoint(path=match.group("path"), method=method)


# ---------------------------------------------------------------------------
# T2 — API contract tier (#274)
# ---------------------------------------------------------------------------


_BODY_TAIL_CHARS = 500


def _make_http_client(**kwargs: object) -> httpx.Client:
    """Indirection seam: tests patch this to inject ``MockTransport``."""
    return httpx.Client(**kwargs)  # type: ignore[arg-type]


def run_t2_api(
    project_dir: Path,
    *,
    env: Mapping[str, str],
    base_url: str,
    endpoints: Sequence[Endpoint],
    timeout_s: float = 5.0,
    health_path: str = "/health",
) -> TierResult:
    """Run the T2 API contract tier: health probe + acceptance-criteria endpoints.

    Lightweight Cycle 1 contract: 2xx status code for every endpoint; GET
    response body must be JSON-decodable (or empty). Deeper schema checks
    land in Cycle 2. Skips when no endpoints declared and health is also
    unreachable; fails when endpoints are declared but health is unreachable.
    """
    del project_dir, env  # accepted for signature parity / future use
    with _make_http_client(base_url=base_url, timeout=timeout_s) as client:
        health = _probe_health(client, health_path)
        if health is not None:
            if not endpoints:
                return _skip("T2", "no endpoints declared")
            return _t2_health_fail(health_path, health)
        if not endpoints:
            return _skip("T2", "no endpoints declared")
        for endpoint in endpoints:
            failure = _check_endpoint(client, endpoint)
            if failure is not None:
                return failure
    return TierResult(
        tier_id="T2",
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=None,
        failing_detail=None,
    )


def _probe_health(client: httpx.Client, health_path: str) -> str | None:
    """Return ``None`` when health is OK, else a short failure description."""
    try:
        response = client.get(health_path)
    except httpx.HTTPError as exc:
        return f"GET {health_path} raised {type(exc).__name__}"
    if 200 <= response.status_code < 300:
        return None
    return f"GET {health_path} returned {response.status_code}"


def _t2_health_fail(health_path: str, detail: str) -> TierResult:
    return TierResult(
        tier_id="T2",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=detail,
        failing_detail=f"{health_path} health probe failed: {detail}",
    )


def _check_endpoint(client: httpx.Client, endpoint: Endpoint) -> TierResult | None:
    try:
        response = client.request(endpoint.method, endpoint.path)
    except httpx.HTTPError as exc:
        return _t2_endpoint_fail(
            endpoint,
            stderr_tail=f"{type(exc).__name__}: {exc}",
            detail=f"{endpoint.method} {endpoint.path} raised {type(exc).__name__}",
        )
    if not (200 <= response.status_code < 300):
        return _t2_endpoint_fail(
            endpoint,
            stderr_tail=response.text[-_BODY_TAIL_CHARS:],
            detail=f"{endpoint.method} {endpoint.path} returned {response.status_code}",
        )
    if endpoint.method == "GET" and not _is_json_or_empty(response):
        return _t2_endpoint_fail(
            endpoint,
            stderr_tail=response.text[-_BODY_TAIL_CHARS:],
            detail=f"GET {endpoint.path} returned non-JSON body",
        )
    return None


def _is_json_or_empty(response: httpx.Response) -> bool:
    body = response.content
    if not body:
        return True
    try:
        json.loads(body)
    except (ValueError, json.JSONDecodeError):
        return False
    return True


def _t2_endpoint_fail(_endpoint: Endpoint, *, stderr_tail: str, detail: str) -> TierResult:
    return TierResult(
        tier_id="T2",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=stderr_tail,
        failing_detail=detail,
    )


# ---------------------------------------------------------------------------
# T1 cleanup helper (kept at bottom of module)
# ---------------------------------------------------------------------------


def _terminate_process_tree(proc: subprocess.Popen[str]) -> None:
    if proc.poll() is not None:
        return
    with contextlib.suppress(OSError, ProcessLookupError):
        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    try:
        proc.wait(timeout=2.0)
        return
    except subprocess.TimeoutExpired:
        pass
    with contextlib.suppress(OSError, ProcessLookupError):
        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    with contextlib.suppress(subprocess.TimeoutExpired):
        proc.wait(timeout=2.0)


# ---------------------------------------------------------------------------
# Orchestration entry point (#275)
# ---------------------------------------------------------------------------


_PHASE66_REPAIR_MODEL = _effort.phase_model(66)


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    state_path: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger,
    shared_client: Any,
    max_retries: int = 3,
    max_turns: int | None = None,
    effective_model: str | None = None,
    wall_budget_s: float | None = None,
    turn_budget: int | None = None,
) -> None:
    """Execute Phase 6.5: T0 → T1 → T2 with a bounded Sonnet 4.6 repair loop.

    *wall_budget_s* / *turn_budget* compose additively with non-negotiable
    #4 (Anthropic overage abort) and :class:`OllamaBudgetTracker`; ``None``
    on either preserves the legacy unbounded contract (#293).

    Raises:
        RuntimeError: When ``shared_client`` is ``None``.
        VerificationFailed: When all retries exhausted with red tiers,
            when the deviation detector trips, or when either budget breaches.
    """
    del effective_model  # reserved for Ollama/Codex single-model path
    if shared_client is None:
        raise RuntimeError("Phase 6.5 requires the per-cycle shared_client; got None.")

    from code_generator.orchestrator.phase65_budget import Phase65BudgetTracker

    target = cycle if cycle is not None else state
    progress = Phase65Progress()
    target.phase6_5 = progress
    last_failure: TierResult | None = None
    detector = DeviationDetector()
    budget = Phase65BudgetTracker(wall_budget_s=wall_budget_s, turn_budget=turn_budget)
    budget.start()

    # Ephemeral verification port (#1): allocate once so base_url stays
    # stable across the retry loop; re-checked per attempt by the guard (#2).
    verify_port = _alloc_free_port()

    for attempt in range(max_retries):
        budget.check(turns_consumed=attempt, logger=logger)
        progress = _begin_attempt(target, progress, attempt)
        save_state(state_path, state)
        if attempt > 0:
            _soft_reset_for_repair(project_dir, attempt + 1)

        verify_port = _ensure_verify_port(verify_port, logger=logger)
        outcome = _run_tiers(
            project_dir,
            state,
            cycle,
            state_path,
            progress,
            attempt,
            target,
            port=verify_port,
            logger=logger,
            detector=detector,
        )
        if outcome is None:
            _tick_runtime_verified_for_closed_issues(state, cycle, state_path, logger)
            _finalize_progress(target, progress, state_path, state)
            return

        last_failure = outcome
        event = detector.check()
        if event is not None:
            raise VerificationFailed(f"Phase 6.5 deviation: {event.detail}")
        await _run_repair_pass(
            failure_report=_format_failure_report(outcome, attempt + 1, max_retries),
            shared_client=shared_client,
            project_dir=project_dir,
            state_path=state_path,
            logger=logger,
            runner_module=runner_module,
            max_turns=max_turns,
            attempt=attempt,
            target=target,
        )

    raise VerificationFailed(
        f"Phase 6.5 exhausted {max_retries} attempts; last failing tier="
        f"{last_failure.tier_id if last_failure else '?'}; "
        f"failure report path={state_path.parent / 'phase6_5_failure.txt'}"
    )


def _begin_attempt(target: Any, prev: Phase65Progress, attempt: int) -> Phase65Progress:
    fresh = Phase65Progress(
        attempt=attempt,
        last_tier=prev.last_tier,
        tiers_passed=list(prev.tiers_passed),
        tiers_failed=list(prev.tiers_failed),
        tiers_skipped=list(prev.tiers_skipped),
        skip_reasons=dict(prev.skip_reasons),
    )
    target.phase6_5 = fresh
    return fresh


def _run_tiers(
    project_dir: Path,
    state: State,
    cycle: CycleState | None,
    state_path: Path,
    progress: Phase65Progress,
    attempt: int,
    target: Any,
    *,
    port: int,
    logger: logging.Logger,
    detector: DeviationDetector | None = None,
) -> TierResult | None:
    """Run enabled tiers from the persisted ``AgentSpec`` fail-fast.

    Builds and persists ``AgentSpec`` once per attempt via
    :func:`tier_selector.select_tiers` then iterates ``spec.tiers``,
    skipping any tier with ``enabled=False`` and recording the
    skip reason on ``Phase65Progress``.

    *port* is the ephemeral free port allocated by :func:`run` (#1). It is
    woven into ``base_url``, the subprocess env (``PORT`` / ``UVICORN_PORT``
    / ``APP_PORT``), and the persisted spec so both the programmatic tier
    runners and the SDK repair agent bind the same collision-free port.
    """
    base_url = f"http://127.0.0.1:{port}"
    # The SDK repair agent does not inherit this env (its credentials are
    # locked at shared-client open time); it learns the port from the
    # persisted spec's base_url/T1.port instead. These vars steer the
    # programmatic T0/T2 subprocesses and any app that honours $PORT.
    env = {
        **build_agent_env(),
        "PORT": str(port),
        "UVICORN_PORT": str(port),
        "APP_PORT": str(port),
    }
    requirements_path = project_dir / ".code-generator" / "requirements.md"
    endpoints = _load_endpoints(requirements_path)

    spec = _persist_spec_for_attempt(project_dir, requirements_path, port)
    _record_skips(target, progress, spec, attempt, logger=logger)
    save_state(state_path, state)

    for tier in spec.tiers:
        if not tier.enabled:
            continue
        runner = _tier_runner(tier, project_dir, env, base_url, endpoints)
        if runner is None:
            continue
        result = runner()
        _record_outcome(target, progress, tier.tier_id, result, attempt)
        if detector is not None and not result.skipped:
            detector.record(
                tier.tier_id, passed=result.passed, failing_detail=result.failing_detail
            )
        save_state(state_path, state)
        if not result.passed and not result.skipped:
            return result
    return None


def _persist_spec_for_attempt(project_dir: Path, requirements_path: Path, port: int) -> AgentSpec:
    """Build the ``AgentSpec`` for this run and atomically persist it.

    The spec is the single source of truth consumed by :func:`_run_tiers`
    *and* the SDK repair agent (the prompt instructs it to trust the spec's
    declared ports). ``build_agent_spec`` stays pure and deterministic
    (default ``:8000``); the ephemeral *port* (#1) is layered on here via
    :func:`dataclasses.replace` so the agent boots the app on a
    collision-free port instead of the well-known ``:8000``.
    """
    tiers = select_tiers(project_dir, requirements_path)
    requirements_text = (
        requirements_path.read_text(encoding="utf-8") if requirements_path.exists() else ""
    )
    flags = {tier.tier_id: tier.enabled for tier in tiers if tier.tier_id in {"T3", "T4"}}
    spec = build_agent_spec(project_dir, requirements_text, flags)
    spec = replace(
        spec,
        base_url=f"http://127.0.0.1:{port}",
        tiers=tuple(
            replace(tier, port=port) if tier.port is not None else tier for tier in spec.tiers
        ),
    )
    persist_agent_spec(spec, project_dir / ".code-generator")
    return spec


def _record_skips(
    target: Any,
    progress: Phase65Progress,
    spec: AgentSpec,
    attempt: int,
    *,
    logger: logging.Logger,
) -> None:
    for tier in spec.tiers:
        if tier.enabled or tier.skip_reason is None:
            continue
        if tier.tier_id not in progress.tiers_skipped:
            progress.tiers_skipped.append(tier.tier_id)
        progress.skip_reasons[tier.tier_id] = tier.skip_reason
        logger.warning(
            "Phase 6.5: tier %s skipped — %s",
            tier.tier_id,
            tier.skip_reason,
        )
    updated = Phase65Progress(
        attempt=attempt,
        last_tier=progress.last_tier,
        tiers_passed=list(progress.tiers_passed),
        tiers_failed=list(progress.tiers_failed),
        tiers_skipped=list(progress.tiers_skipped),
        skip_reasons=dict(progress.skip_reasons),
    )
    target.phase6_5 = updated


def _tier_runner(
    tier: TierConfig,
    project_dir: Path,
    env: Mapping[str, str],
    base_url: str,
    endpoints: Sequence[Endpoint],
):  # type: ignore[no-untyped-def]
    timeout_s = tier.timeout_s
    if tier.tier_id == "T0":
        return lambda: run_t0_build(project_dir, env=env, timeout_s=timeout_s)
    if tier.tier_id == "T1":
        return lambda: run_t1_boot(project_dir, env=env, entry_cmd=[], timeout_s=timeout_s)
    if tier.tier_id == "T2":
        return lambda: run_t2_api(
            project_dir, env=env, base_url=base_url, endpoints=endpoints, timeout_s=timeout_s
        )
    if tier.tier_id == "T3":
        from code_generator.orchestrator.tier_t3 import run_t3_browser

        return lambda: run_t3_browser(
            project_dir,
            env=env,
            base_url=base_url,
            scenarios=[],
            tier_config=tier,
        )
    if tier.tier_id == "T4":
        from code_generator.orchestrator.tier_t4 import run_t4_container

        return lambda: run_t4_container(
            project_dir,
            env=env,
            base_url=base_url,
            endpoints=endpoints,
            command_timeout_s=timeout_s,
        )
    return None


def _load_endpoints(requirements_path: Path) -> list[Endpoint]:
    if not requirements_path.exists():
        return []
    return extract_endpoints_from_requirements(requirements_path.read_text(encoding="utf-8"))


def _record_outcome(
    target: Any,
    progress: Phase65Progress,
    tier_id: str,
    result: TierResult,
    attempt: int,
) -> None:
    bucket = progress.tiers_passed if result.passed else progress.tiers_failed
    if tier_id not in bucket:
        bucket.append(tier_id)
    updated = Phase65Progress(
        attempt=attempt,
        last_tier=tier_id,
        tiers_passed=list(progress.tiers_passed),
        tiers_failed=list(progress.tiers_failed),
        tiers_skipped=list(progress.tiers_skipped),
        skip_reasons=dict(progress.skip_reasons),
    )
    target.phase6_5 = updated
    # Mutate in place so caller's reference reflects the new lists.
    progress.tiers_passed[:] = updated.tiers_passed
    progress.tiers_failed[:] = updated.tiers_failed


def _finalize_progress(
    target: Any, progress: Phase65Progress, state_path: Path, state: State
) -> None:
    final = Phase65Progress(
        attempt=progress.attempt,
        last_tier="DONE",
        tiers_passed=list(progress.tiers_passed),
        tiers_failed=list(progress.tiers_failed),
        tiers_skipped=list(progress.tiers_skipped),
        skip_reasons=dict(progress.skip_reasons),
    )
    target.phase6_5 = final
    save_state(state_path, state)


def _soft_reset_for_repair(project_dir: Path, attempt_number: int) -> str:
    memories_dir = project_dir / ".code-generator" / "memories"
    memories_dir.mkdir(parents=True, exist_ok=True)
    return boundary_prefix_only(attempt_number, memories_dir)


def _format_failure_report(result: TierResult, attempt: int, max_retries: int) -> str:
    """Thin delegate to :func:`failure_report.format_failure_report` (#282)."""
    return format_failure_report(FailureReport.from_tier_result(result, attempt, max_retries))


def _summarize_tiers(target: Any) -> tuple[str, str]:
    """Return ``(active, skipped)`` summary strings for the repair prompt (#288)."""
    progress = getattr(target, "phase6_5", None)
    if progress is None:
        return "T0,T1,T2", ""
    active = ",".join(progress.tiers_passed + progress.tiers_failed) or "T0,T1,T2"
    skipped = ", ".join(
        f"{tier} ({progress.skip_reasons.get(tier, 'no reason')})"
        for tier in progress.tiers_skipped
    )
    return active, skipped


def _load_oracle_report_text(requirements_path: Path) -> str:
    """Render the oracle output as a short labeled text block for the prompt (#288)."""
    if not requirements_path.exists():
        return "(no requirements.md found)"
    from code_generator.orchestrator.criteria_oracle import build_oracle_report

    report = build_oracle_report(requirements_path.read_text(encoding="utf-8"))
    if not report.global_criteria and not report.scope_criteria:
        return "(no acceptance criteria parsed)"
    lines: list[str] = []
    if report.global_criteria:
        lines.append("Global criteria:")
        lines.extend(_format_criterion_line(c) for c in report.global_criteria)
    if report.scope_criteria:
        lines.append("Scope criteria:")
        lines.extend(_format_criterion_line(c) for c in report.scope_criteria)
    return "\n".join(lines)


def _format_criterion_line(criterion: Any) -> str:
    if criterion.verifiable:
        return f"  - [{criterion.tier}] {criterion.text}"
    return f"  - [NOT VERIFIABLE: {criterion.not_verifiable_reason}] {criterion.text}"


async def _run_repair_pass(
    *,
    failure_report: str,
    shared_client: Any,
    project_dir: Path,
    state_path: Path,
    logger: logging.Logger,
    runner_module: RunnerProtocol,
    max_turns: int | None,
    attempt: int,
    target: Any,
) -> None:
    """Dispatch the Sonnet 4.6 repair pass via the per-cycle shared client (#275)."""
    del runner_module  # rate_limit signal is replayed via run_with_shared_client
    requirements_path = project_dir / ".code-generator" / "requirements.md"
    spec_path = project_dir / ".code-generator" / "phase6_5_spec.json"
    tiers_active, tiers_skipped = _summarize_tiers(target)
    prompt = load_prompt(
        "prompt-phase-6-5-verify.md",
        PROJECT_DIR=str(project_dir),
        REQUIREMENTS_MD=str(requirements_path),
        DETECTED_STACK="unknown",
        TIER_PLAN="",
        FAILURE_REPORT=failure_report,
        ATTEMPT=str(attempt + 1),
        MAX_RETRIES="3",
        AGENT_SPEC_PATH=str(spec_path),
        ORACLE_REPORT=_load_oracle_report_text(requirements_path),
        TIERS_ACTIVE=tiers_active,
        TIERS_SKIPPED=tiers_skipped,
    )
    effort_level = _effort.resolve_effort(
        phase=66, complexity="", issue_labels=[], retry_count=attempt
    )
    _effort.validate_effort(effort_level, _PHASE66_REPAIR_MODEL)
    options = make_agent_options(
        model=_PHASE66_REPAIR_MODEL,
        effort=effort_level,
        allowed_tools=["Read", "Edit", "Bash", "Grep", "Glob"],
        cwd=str(project_dir),
        **max_turns_kwargs(max_turns),
    )
    from code_generator.orchestrator.sica import build_verifier_context

    verifier = build_verifier_context(shared_client)
    result = await verifier.run(prompt, options, logger=logger, state_path=state_path)
    bucket = target.token_usage.setdefault("phase6_5", TokenUsage())
    bucket += result.usage
    target.token_usage["phase6_5"] = bucket


def _tick_runtime_verified_for_closed_issues(
    state: State,
    cycle: CycleState | None,
    state_path: Path,
    logger: logging.Logger,
) -> None:
    """Tick ``runtime_verified`` for every closed issue in scope (#270).

    Mirrors :func:`phase6_test._tick_checklist_for_closed_issues` so the
    binding source of truth (checklist JSON) stays consistent even when the
    subsequent save_state crashes.
    """
    if state.requirements_hash is None:
        logger.warning("Phase 6.5: skipping checklist tick — state.requirements_hash is None.")
        return
    checklist_path = state_path.parent / "checklists" / f"{state.requirements_hash}.json"
    issues = cycle.issues if cycle is not None else state.issues
    for issue in issues:
        if issue.status == "closed":
            _checklist.tick_runtime_verified(checklist_path, issue.number)


def __getattr__(name: str) -> Any:  # noqa: N807 — PEP 562 module-level hook
    """Lazy re-export to break the ``tier_t4`` ↔ ``phase6_5_verify`` import cycle.

    ``tier_t4`` imports private helpers (``_run_capture``, ``_skip``,
    ``_tail``, ``run_t2_api``) from this module at load time, so a
    top-level ``from tier_t4 import run_t4_container`` would deadlock
    during package initialization. Resolving the name lazily lets
    ``phase6_5_verify.run_t4_container`` work for callers while
    ``__all__`` still advertises it (#283).
    """
    if name == "run_t3_browser":
        from code_generator.orchestrator.tier_t3 import run_t3_browser

        return run_t3_browser
    if name == "run_t4_container":
        from code_generator.orchestrator.tier_t4 import run_t4_container

        return run_t4_container
    raise AttributeError(f"module 'phase6_5_verify' has no attribute {name!r}")
