"""Phase 1 — Planning: milestone creation and issue seeding.

Uses Opus 4.7 to read the requirements and create GitHub Issues
(via Bash tool calls inside the SDK session).

Non-negotiable #8: model is hard-coded to ``claude-opus-4-7``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from code_generator import checklist as _checklist
from code_generator import effort as _effort
from code_generator import gh
from code_generator import memory as _memory
from code_generator import state as _state
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.orchestrator import cycle_prompts as _cycle_prompts
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit
from code_generator.runner._telemetry import accumulate_telemetry
from code_generator.runner.cache_breakpoints import resolve_active_ttl
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.runner.phase_telemetry import accumulate_phase_telemetry
from code_generator.runner.types import TokenUsage
from code_generator.state import CycleState

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.repo_info import RepoInfo
    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import State


class Phase1NoIssuesError(RuntimeError):
    """Phase 1 completed but created zero GitHub issues — abort the pipeline."""


def _deduplicate_by_title(issues: list[dict[str, Any]]) -> list[dict[str, Any]]:  # type: ignore[type-arg]
    """Return only the lowest-numbered issue per case-insensitive stripped title.

    Args:
        issues: List of issue dicts already sorted by number (ascending).

    Returns:
        Deduplicated list preserving the lowest-numbered entry per title.
    """
    seen: set[str] = set()
    unique: list[dict[str, Any]] = []  # type: ignore[type-arg]
    for issue in issues:
        key = issue.get("title", "").strip().lower()
        if key not in seen:
            seen.add(key)
            unique.append(issue)
    return unique


def _build_issue_states(raw_issues: list[dict[str, Any]]) -> list[_state.IssueState]:  # type: ignore[type-arg]
    """Convert raw gh issue dicts into IssueState objects.

    Deduplicates by title (case-insensitive, stripped) as a defense-in-depth
    measure: if the planning session created duplicate issues, only the
    lowest-numbered entry per title is kept.

    Args:
        raw_issues: List of dicts as returned by ``gh.list_issues()``.

    Returns:
        List of :class:`~code_generator.state.IssueState` instances.
    """
    sorted_issues = sorted(raw_issues, key=lambda i: i["number"])
    unique_issues = _deduplicate_by_title(sorted_issues)
    return [
        _state.IssueState(
            number=issue["number"],
            title=issue.get("title", ""),
            status=issue.get("state", "OPEN").lower(),
            agent=gh.agent_from_labels(issue.get("labels", [])),
            labels=[lbl.get("name", "") for lbl in issue.get("labels", []) if lbl.get("name")],
        )
        for issue in unique_issues
    ]


def _fetch_existing_issues(
    repo: _state.RepoInfo | None,
    milestone_title: str | None,
) -> list[dict[str, Any]]:  # type: ignore[type-arg]
    """Fetch all issues in the given milestone, or return empty list for single-mode.

    Args:
        repo: Repository info; when ``None`` returns empty list.
        milestone_title: Milestone name, or ``None`` for single-cycle mode.

    Returns:
        List of raw issue dicts (may be empty).
    """
    if repo is None or milestone_title is None:
        return []
    return gh.list_issues(repo, milestone=milestone_title, state="all")


def _format_existing_issues(issues: list[dict[str, Any]]) -> str:  # type: ignore[type-arg]
    """Format a list of raw issue dicts as a readable string for prompt injection.

    Args:
        issues: Raw issue dicts as returned by ``gh.list_issues()``.

    Returns:
        A newline-separated list of ``#N: title`` entries, or ``"none"`` when empty.
    """
    if not issues:
        return "none"
    return "\n".join(f"- #{i['number']}: {i['title']}" for i in issues)


_PHASE1_DEFAULT_MODEL = "claude-opus-4-7"
# CLAUDE.md invariant #8; overridden via ``effective_model`` on Ollama — #219.


_PHASE1_MAX_ATTEMPTS = 3
"""Max planning attempts before surfacing ``Phase1NoIssuesError`` (0.4.12).

Weak open models on the Ollama codepath often respond with prose describing
the plan instead of invoking ``gh issue create`` via the Bash tool. A single
stricter re-prompt is usually enough to unblock them without operator
intervention.
"""


_PHASE1_RETRY_NUDGE = (
    "Your previous attempt finished without creating any GitHub issues. "
    "This is a CRITICAL failure. You MUST use the Bash tool to invoke "
    "`gh issue create` for each issue right now. Do NOT output markdown "
    "or prose describing the plan — every planned issue must become a "
    "real GitHub issue via `gh issue create ... --milestone "
    '"{MILESTONE}" --assignee @me --label "..."`. Once you have called '
    "`gh issue create` for every planned issue, print a one-line summary "
    "per issue and stop.\n\n"
    "The original instructions follow.\n\n"
)


def _accumulate_usage(
    total: _state.TokenUsage | None,
    delta: _state.TokenUsage,
) -> _state.TokenUsage:
    """Sum two TokenUsage records field-by-field across Phase 1 attempts."""
    from code_generator.runner.types import TokenUsage

    if total is None:
        return delta
    return TokenUsage(
        input=total.input + delta.input,
        output=total.output + delta.output,
        cache_read=total.cache_read + delta.cache_read,
        cache_write=total.cache_write + delta.cache_write,
        num_turns=total.num_turns + delta.num_turns,
    )


def _multi_cycle_briefing(
    project_dir: Path,
    state: State,
    cycle: CycleState,
    logger: logging.Logger | None = None,
) -> str:
    """Load the per-cycle briefing or fall back to raw requirements.

    When the cycle prompt file is missing (e.g. because
    :func:`~code_generator.orchestrator.cycle_prompts.generate_cycle_prompts`
    failed during Phase 0 — common with non-Anthropic models that struggle with
    the specializer JSON format), a WARNING is emitted and the raw
    ``requirements.md`` is returned as a safe fallback. The operator can re-run
    ``--phase 0 --cycle N`` later to regenerate the specialized briefings.
    """
    if state.requirements_hash is None:
        if logger:
            logger.warning(
                "cycle-prompts: requirements_hash is None for cycle %d — "
                "falling back to raw requirements.",
                cycle.id,
            )
        return _single_cycle_fallback(project_dir)
    try:
        return _cycle_prompts.load_cycle_prompt(project_dir, state.requirements_hash, cycle.id)
    except FileNotFoundError:
        if logger:
            logger.warning(
                "cycle-prompts: specialized briefing missing for cycle %d (hash=%s) — "
                "falling back to raw requirements. Re-run "
                "`code-generator generate --phase 0 --cycle %d` to regenerate.",
                cycle.id,
                state.requirements_hash,
                cycle.id,
            )
        return _single_cycle_fallback(project_dir)


def _single_cycle_fallback(project_dir: Path) -> str:
    """Return the raw-requirements fallback used in single-cycle mode."""
    requirements_path = project_dir / ".code-generator" / "requirements.md"
    try:
        requirements_content = requirements_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return f"- **Requirements path:** {requirements_path}"
    return f"## Requirements\n\n{requirements_content}"


def _load_specialized_prompt(
    project_dir: Path,
    state: State,
    cycle: CycleState | None,
    logger: logging.Logger | None = None,
) -> str:
    """Return the cycle-specialized briefing or the single-cycle fallback.

    Multi-cycle mode reads the verbatim per-cycle briefing from
    ``.code-generator/cycles_prompts/<requirements_hash>/cycle_<id>.md``.
    When the file is missing (common when the cycle-prompts specializer call
    fails with non-Anthropic models), falls back to raw ``requirements.md``
    with a warning instead of crashing the pipeline.

    Single-cycle mode (``cycle is None``) keeps the historic raw-requirements
    fallback because there is no per-cycle briefing to load.
    """
    if state.mode == "multi-cycle" and cycle is not None:
        return _multi_cycle_briefing(project_dir, state, cycle, logger=logger)
    return _single_cycle_fallback(project_dir)


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Execute phase 1: planning.

    Seeds standard labels, optionally creates a milestone (multi-cycle),
    runs the planning prompt, then populates ``state.issues`` or
    ``cycle.issues`` from the newly-created GitHub issues.

    Args:
        state: Root state object (mutated in place).
        cycle: Active cycle (multi-cycle mode) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
    """
    if logger is None:
        logger = setup_phase_logger("phase1", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"

    # repo is populated by preflight before any phase runs; Phase 1 is
    # unreachable without a valid state.repo in production.
    repo = state.repo

    # Seed standard label taxonomy — idempotent.
    if repo is not None:
        gh.ensure_standard_labels(repo)

    # Multi-cycle: create the milestone if not yet done.
    # Track whether the milestone was created in this run so we can clean it up on failure.
    milestone_title: str | None = None
    milestone_number_before: int | None = None
    if cycle is not None:
        milestone_title = cycle.milestone_title
        milestone_number_before = cycle.milestone_number
        if cycle.milestone_number is None:
            cycle.milestone_number = gh.create_milestone(
                repo,  # type: ignore[arg-type]
                cycle.milestone_title,
                cycle.scope,
            )
            logger.info("Created milestone %r → #%d", cycle.milestone_title, cycle.milestone_number)

    try:
        # Determine completed cycle names for the prompt.
        completed_cycles: str = "none"
        if state.cycles:
            completed = [
                c.name
                for c in state.cycles
                if isinstance(c, CycleState) and c.status == "completed"
            ]
            if completed:
                completed_cycles = ", ".join(completed)

        # Pre-fetch existing issues so the model can skip them on --continue.
        existing_issues = _fetch_existing_issues(repo, milestone_title)

        memories_dir = project_dir / ".code-generator" / "memories"
        repo_map = _memory.read_cycle_repomap(memories_dir)
        prompt = load_prompt(
            "prompt-phase-1-planning.md",
            CYCLE_SPECIALIZED_PROMPT=_load_specialized_prompt(
                project_dir, state, cycle, logger=logger
            ),
            CYCLE_SCOPE=(
                cycle.scope
                if cycle is not None
                else "single-cycle — implement all features from requirements.md"
            ),
            MILESTONE_TITLE=milestone_title if milestone_title is not None else "",
            COMPLETED_CYCLES=completed_cycles,
            EXISTING_ISSUES=_format_existing_issues(existing_issues),
            REPO_MAP=repo_map,
        )

        effort_level = _effort.resolve_effort(
            phase=1,
            complexity="",
            issue_labels=[],
            retry_count=0,
        )
        _effort.validate_effort(effort_level, effective_model or _PHASE1_DEFAULT_MODEL)

        options = make_agent_options(
            model=effective_model or _PHASE1_DEFAULT_MODEL,
            effort=effort_level,
            allowed_tools=["Agent", "Read", "Bash", "Glob", "Grep"],
            cwd=str(project_dir),
            **max_turns_kwargs(max_turns),
        )

        # Up to _PHASE1_MAX_ATTEMPTS attempts: the first with the normal
        # prompt, subsequent attempts prefixed with a stricter nudge that
        # tells the model to use the Bash tool to call ``gh issue create``
        # right now. Weak open models on the Ollama codepath commonly
        # respond with prose on the first turn; the nudge recovers most
        # of those cases without operator intervention (0.4.12).
        issue_states: list[_state.IssueState] = []
        total_usage = TokenUsage()
        total_compaction = 0
        total_clear = 0
        total_wall = 0.0
        result = None  # type: ignore[assignment]
        attempt_prompt = prompt
        effective_model_name = effective_model or _PHASE1_DEFAULT_MODEL
        for attempt in range(1, _PHASE1_MAX_ATTEMPTS + 1):
            result = await rate_limit.main_loop(
                runner_module,
                attempt_prompt,
                options,
                state_path=state_path,
                logger=logger,
            )
            total_usage += result.usage
            total_compaction += result.compaction_events
            total_clear += result.clear_events
            total_wall += result.wall_seconds

            raw_issues = gh.list_issues(
                repo,  # type: ignore[arg-type]
                milestone=milestone_title,
                state="open",
            )
            issue_states = _build_issue_states(raw_issues)
            if issue_states:
                break

            if attempt >= _PHASE1_MAX_ATTEMPTS:
                break

            logger.warning(
                "Phase 1 attempt %d/%d: model returned without creating any "
                "GitHub issues. Re-prompting with a stricter nudge.",
                attempt,
                _PHASE1_MAX_ATTEMPTS,
            )
            nudge = _PHASE1_RETRY_NUDGE.replace("{MILESTONE}", milestone_title or "")
            attempt_prompt = nudge + prompt

        if not issue_states:
            raise Phase1NoIssuesError(
                f"Phase 1 finished without creating any GitHub issues after "
                f"{_PHASE1_MAX_ATTEMPTS} attempts (model={effective_model_name!r}). "
                "The model likely responded with prose instead of invoking "
                "`gh issue create` via the Bash tool. Inspect "
                ".code-generator/logs/phase1.log for the tool-call trace, "
                "try a stronger model, or simplify the cycle scope in "
                "requirements.md and re-run."
            )

        target = cycle if cycle is not None else state
        if cycle is not None:
            cycle.issues = issue_states
        else:
            state.issues = issue_states

        # §13 feature checklist (#249). Seed before save_state so the file is
        # in place when ``--continue`` resumes. Skipped (with a WARNING) when
        # ``requirements_hash`` is absent — legacy state.json files lack the
        # key and the pipeline must not crash for them.
        _seed_feature_checklist(state, state_path, issue_states, logger)

        # Persist the accumulated usage across all attempts (not just the last).
        target.token_usage["phase1"] = TokenUsage()
        accumulate_phase_telemetry(
            target.token_usage["phase1"],
            ttl=resolve_active_ttl(state, cycle, bp_index=2),
            usage=total_usage,
            compaction_delta=total_compaction,
            clear_delta=total_clear,
        )
        if isinstance(target, CycleState):
            accumulate_telemetry(
                target.cache_telemetry,
                target.token_usage["phase1"],
                total_wall,
            )

        _state.save_state(state_path, state)
        log_phase_usage(logger, 1, target.token_usage["phase1"])
        logger.info("Phase 1: %d issues created.", len(issue_states))

    except Exception:
        _cleanup_orphaned_milestone(repo, cycle, milestone_number_before, logger)
        raise


def _seed_feature_checklist(
    state: State,
    state_path: Path,
    issue_states: list[_state.IssueState],
    logger: logging.Logger,
) -> None:
    """Seed the §13 feature checklist for *state.requirements_hash*.

    No-op + WARNING when ``requirements_hash`` is unset (pre-Cycle-4 state).
    """
    if state.requirements_hash is None:
        logger.warning(
            "Phase 1: skipping feature checklist seed — state.requirements_hash is None."
        )
        return
    checklist_path = state_path.parent / "checklists" / f"{state.requirements_hash}.json"
    _checklist.seed(checklist_path, issue_states)


def _cleanup_orphaned_milestone(
    repo: RepoInfo | None,
    cycle: CycleState | None,
    milestone_number_before: int | None,
    logger: logging.Logger,
) -> None:
    """Delete a milestone created in this run if Phase 1 fails before persisting issues.

    Only deletes if the milestone was created during this run (i.e., it was None before
    and is now set). Best-effort: logs a WARNING if deletion itself fails.

    Args:
        repo: Repository info; when ``None`` deletion is skipped.
        cycle: Active cycle, or None in single-cycle mode.
        milestone_number_before: The milestone number before this run started (None = just created).
        logger: Phase logger for WARNING output.
    """
    if (
        repo is None
        or cycle is None
        or cycle.milestone_number is None
        or milestone_number_before is not None
    ):
        return
    try:
        gh.delete_milestone(repo, cycle.milestone_number)
    except Exception as cleanup_exc:
        logger.warning(
            "Failed to delete orphaned milestone #%d during Phase 1 cleanup: %s",
            cycle.milestone_number,
            cleanup_exc,
        )
