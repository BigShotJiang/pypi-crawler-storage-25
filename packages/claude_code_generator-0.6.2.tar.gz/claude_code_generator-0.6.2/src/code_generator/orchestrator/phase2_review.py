"""Phase 2 — Global cycle review (batched).

All open, unreviewed issues for the current cycle are evaluated in a single
Opus 4.7 call that returns a JSON ``{"decisions": [...]}`` payload. The
orchestrator posts a ``gh issue comment`` only on issues whose decision is
not ``"ok"`` and then marks every reviewed issue in one atomic
``save_state``.

Non-negotiable #8: model is hard-coded to ``claude-opus-4-7``.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from code_generator import effort as _effort
from code_generator import gh
from code_generator import memory as _memory
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.orchestrator._comments import fetch_formatted_comments
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit, retry
from code_generator.runner._telemetry import accumulate_telemetry
from code_generator.runner.cache_breakpoints import resolve_active_ttl
from code_generator.runner.mcp import build_mcp_servers, mcp_tool_wildcards
from code_generator.runner.options import (
    compaction_beta_available,
    make_agent_options,
    max_turns_kwargs,
)
from code_generator.runner.phase_telemetry import accumulate_phase_telemetry
from code_generator.runner.sdk_runner import run_with_shared_client
from code_generator.runner.soft_reset import boundary_prefix_only, soft_reset_context
from code_generator.runner.types import MaxTurnsExceeded, TokenUsage
from code_generator.state import CycleState, get_issues, save_state

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.runner.types import RunResult
    from code_generator.state import State


async def _run_one_review(
    prompt: str,
    options: Any,
    *,
    runner_module: RunnerProtocol,
    shared_client: Any | None,
    state_path: Path,
    logger: logging.Logger,
) -> RunResult:
    """Dispatch one issue review to shared-client or fresh-runner path."""
    if shared_client is not None:
        return await run_with_shared_client(
            shared_client, prompt, options, logger=logger, state_path=state_path
        )
    return await rate_limit.main_loop(
        runner_module, prompt, options, state_path=state_path, logger=logger
    )


_PHASE2_DEFAULT_MODEL = "claude-opus-4-7"
# CLAUDE.md invariant #8; overridden via ``effective_model`` on Ollama — #219.


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    shared_client: Any = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Execute phase 2: batched cycle review.

    All open, unreviewed issues for the current cycle are evaluated in a
    single Opus 4.7 call dispatched through :func:`_run_one_review`. The
    model returns a JSON ``{"decisions": [...]}`` payload; :func:`_apply_decisions`
    posts a ``gh issue comment`` only on decisions whose ``action`` is not
    ``"ok"``. Every reviewed issue is then marked ``reviewed=True`` in one
    atomic ``save_state``.

    A single :class:`~code_generator.runner.retry.CircuitBreaker` with
    ``max_failures=3`` wraps the one batched call. On a fatal failure
    (:class:`~code_generator.runner.retry.CircuitOpen`,
    :class:`~code_generator.runner.types.MaxTurnsExceeded`, or a JSON
    parse failure), every issue in the batch is tagged
    ``needs-manual-review`` and left unreviewed so the next run re-evaluates
    them.

    Args:
        state: Root state object.
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
        shared_client: Optional shared SDK client for the cycle.
        max_turns: Optional per-session ``max_turns`` override (debugging).
        effective_model: Override for the default Opus 4.7 model
            (Ollama path only — see CLAUDE.md non-negotiable #8).
    """
    if logger is None:
        logger = setup_phase_logger("phase2", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"

    # repo is populated by preflight before any phase runs; Phase 2 is
    # unreachable without a valid state.repo in production.
    repo = state.repo  # type: ignore[assignment]  # RepoInfo | None, narrowed by preflight

    issues = get_issues(state, cycle)
    open_unreviewed = [i for i in issues if i.status == "open" and not i.reviewed]

    target = cycle if cycle is not None else state

    if not open_unreviewed:
        logger.info("Phase 2: no open unreviewed issues — skipping.")
        target.token_usage["phase2"] = TokenUsage()
        save_state(state_path, state)
        log_phase_usage(logger, 2, TokenUsage())
        return

    mcp_servers = build_mcp_servers(project_dir)
    mcp_tools = mcp_tool_wildcards(mcp_servers)
    memories_dir = project_dir / ".code-generator" / "memories"

    # Pre-fetch any missing comments and persist them incrementally so a crash
    # mid-fetch does not force a full re-fetch on --continue.
    for issue in open_unreviewed:
        if issue.comments is None:
            issue.comments = fetch_formatted_comments(repo, issue.number, logger)  # type: ignore[arg-type]
            save_state(state_path, state)

    # Soft reset once per cycle (not per issue) — the batched call is a single
    # distinct client.query() from the cycle_loop's perspective, so the
    # "fresh context per issue" invariant collapses to "fresh context per
    # cycle" on the Phase 2 boundary.
    cm_block: dict | None = None
    boundary_prefix = ""
    if shared_client is not None:
        memories_dir.mkdir(parents=True, exist_ok=True)
        if compaction_beta_available():
            boundary_prefix = boundary_prefix_only(open_unreviewed[0].number, memories_dir)
        else:
            reset = await soft_reset_context(shared_client, open_unreviewed[0].number, memories_dir)
            cm_block = reset.context_management
            boundary_prefix = reset.boundary_prefix

    issues_payload = json.dumps(
        [
            {
                "issue_number": issue.number,
                "title": issue.title,
                "body": "",  # Phase 1 records the issue body on GitHub; the reviewer
                # can Read the live version when needed (the batched prompt,
                # like its predecessor, never embeds the body inline).
                "agent": issue.agent,
                "comments": issue.comments or "",
            }
            for issue in open_unreviewed
        ],
        indent=2,
    )

    repo_map = _memory.read_cycle_repomap(memories_dir)
    prompt = load_prompt(
        "prompt-phase-2-batch-review.md",
        ISSUES_JSON=issues_payload,
        REPO_MAP=repo_map,
    )
    if boundary_prefix:
        prompt = boundary_prefix + prompt

    effort_level = _effort.resolve_effort(phase=2, complexity="", issue_labels=[], retry_count=0)
    _main_model = effective_model or _PHASE2_DEFAULT_MODEL
    _effort.validate_effort(effort_level, _main_model)

    options = make_agent_options(
        model=_main_model,
        effort=effort_level,
        allowed_tools=["Agent", "Read", "Glob", "Grep", "WebSearch", "WebFetch"] + mcp_tools,
        cwd=str(project_dir),
        mcp_servers=mcp_servers,
        context_management=cm_block,
        **max_turns_kwargs(max_turns),
    )

    breaker = retry.CircuitBreaker(max_failures=3)
    phase_usage = TokenUsage()
    phase_wall = 0.0
    phase_compaction = 0
    phase_clear = 0
    review_text = ""
    fatal = False

    logger.info(
        "Phase 2: reviewing %d open unreviewed issues in a single batched call.",
        len(open_unreviewed),
    )

    try:
        result = await retry.with_backoff(
            lambda p=prompt, o=options: _run_one_review(  # type: ignore[misc]
                p,
                o,
                runner_module=runner_module,
                shared_client=shared_client,
                state_path=state_path,
                logger=logger,
            ),
            breaker=breaker,
        )
        if result is not None:
            review_text = result.text
            phase_usage = result.usage
            phase_wall = result.wall_seconds
            phase_compaction = result.compaction_events
            phase_clear = result.clear_events
    except MaxTurnsExceeded:
        fatal = True
        logger.error(
            "Phase 2: batched review hit max_turns — tagging every unreviewed "
            "issue in the batch for manual review."
        )
    except retry.CircuitOpen:
        fatal = True
        logger.error(
            "Phase 2: circuit breaker opened during batched review — tagging "
            "every unreviewed issue in the batch for manual review."
        )

    if not fatal:
        decisions = _parse_batch_decisions(review_text, logger)
        if decisions is None:
            fatal = True
        else:
            _apply_decisions(decisions, open_unreviewed, repo, logger)
            for issue in open_unreviewed:
                issue.reviewed = True

    if fatal:
        for issue in open_unreviewed:
            try:
                gh.add_label(repo, issue.number, "needs-manual-review")  # type: ignore[arg-type]
            except gh.GhError as exc:
                logger.warning(
                    "Could not add needs-manual-review label to #%d: %s",
                    issue.number,
                    exc,
                )

    target.token_usage["phase2"] = TokenUsage()
    accumulate_phase_telemetry(
        target.token_usage["phase2"],
        ttl=resolve_active_ttl(state, cycle, bp_index=2),
        usage=phase_usage,
        compaction_delta=phase_compaction,
        clear_delta=phase_clear,
    )
    log_phase_usage(logger, 2, target.token_usage["phase2"])
    if isinstance(target, CycleState):
        accumulate_telemetry(target.cache_telemetry, phase_usage, phase_wall)
    save_state(state_path, state)


def _parse_batch_decisions(
    text: str,
    logger: logging.Logger,
) -> list[dict[str, Any]] | None:
    """Extract the ``decisions`` array from the batched-review response.

    Returns ``None`` on any parse failure; the caller tags the affected
    issues ``needs-manual-review`` and skips marking them reviewed so that
    the next run re-evaluates them.
    """
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        logger.error("Phase 2: batched review output contained no JSON object.")
        return None
    try:
        raw = json.loads(text[start : end + 1])
    except json.JSONDecodeError as exc:
        logger.error("Phase 2: batched review JSON parse failed: %s", exc)
        return None
    if not isinstance(raw, dict):
        logger.error(
            "Phase 2: batched review output is not a JSON object (got %s).",
            type(raw).__name__,
        )
        return None
    decisions = raw.get("decisions")
    if not isinstance(decisions, list):
        logger.error(
            "Phase 2: batched review output missing 'decisions' list (got %s).",
            type(decisions).__name__ if decisions is not None else "None",
        )
        return None
    return decisions  # type: ignore[no-any-return]


def _apply_decisions(
    decisions: list[dict[str, Any]],
    open_unreviewed: list[Any],
    repo: Any,
    logger: logging.Logger,
) -> None:
    """Post a ``gh issue comment`` for each non-``ok`` decision.

    Decisions targeting an issue that is not in ``open_unreviewed`` are logged
    and ignored — the model must never comment on an issue it was not asked
    to review. Missing decisions (an issue with no matching entry) are also
    logged; the issue is still marked reviewed by the caller, since the
    absence of a decision is equivalent to an implicit ``"ok"``.
    """
    by_number = {issue.number: issue for issue in open_unreviewed}
    seen: set[int] = set()
    for decision in decisions:
        if not isinstance(decision, dict):
            logger.warning("Phase 2: skipping non-dict decision entry: %r", decision)
            continue
        number = decision.get("issue_number")
        action = decision.get("action")
        body = decision.get("comment_body") or ""
        if not isinstance(number, int) or number not in by_number:
            logger.warning("Phase 2: decision targets unknown issue #%r — skipping.", number)
            continue
        seen.add(number)
        if action == "ok":
            continue
        if action not in ("comment", "split"):
            logger.warning(
                "Phase 2: decision for #%d has unknown action %r — skipping comment.",
                number,
                action,
            )
            continue
        if not isinstance(body, str) or not body.strip():
            logger.warning(
                "Phase 2: decision for #%d has action=%s but empty body — skipping.",
                number,
                action,
            )
            continue
        try:
            gh.post_comment(repo, number, body)
            logger.info("Phase 2: posted comment on #%d (action=%s).", number, action)
        except gh.GhError as exc:
            logger.warning("Phase 2: could not post comment on #%d: %s", number, exc)

    missing = [issue.number for issue in open_unreviewed if issue.number not in seen]
    if missing:
        logger.warning(
            "Phase 2: reviewer did not return a decision for issues %s — treating as ok.",
            missing,
        )
