"""Phase 8 CI green-gate orchestration.

``run_ci_green_gate`` polls GitHub Actions on the current HEAD, classifies
any failure, dispatches a bounded LLM repair-agent on permanent failures,
verifies locally before every push, and either returns ``"green"`` or opens
a remediation issue and returns ``"exhausted"``.

Reuse-only contract — no new poll / sleep / backoff primitives. Polling
rides ``runner.retry.with_backoff`` + ``CircuitBreaker``. Every LLM call
goes through ``runner.rate_limit.main_loop``. Workflow / job log reads
come from ``gh.actions``. Issue creation from ``gh.issues.create_issue``.
Local verification + guardrail enforcement from
``phase8_local_verify.run_local_verify``. Failure triage from
``phase8_ci_classifier.classify``. Commit + push reuses ``git_ops``
primitives with one rebase-and-retry pass.
"""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from code_generator import effort as _effort
from code_generator.gh import actions as gh_actions
from code_generator.gh.issues import create_issue
from code_generator.git_ops import (
    GitError,
    git_add_all,
    git_commit,
    git_current_branch,
    git_pull_rebase,
    git_push,
    git_rev_parse_head,
)
from code_generator.orchestrator.phase8_ci_classifier import (
    ClassificationEvidence,
    classify,
)
from code_generator.orchestrator.phase8_local_verify import (
    LocalVerifyResult,
    run_local_verify,
)
from code_generator.prompts import PromptError, load_prompt
from code_generator.runner import rate_limit
from code_generator.runner.options import make_agent_options
from code_generator.runner.retry import CircuitBreaker, with_backoff
from code_generator.runner.types import TransientRunnerError

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.repo_info import RepoInfo
    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, State

CiOutcome = Literal["green", "exhausted"]

_PHASE8_DEFAULT_MODEL = _effort.phase_model(8)
_PROMPT_REPAIR_SENTINEL = "Output patches as a JSON array"
_RUNNING_STATUSES = frozenset({"queued", "in_progress", "waiting", "pending", "requested"})


@dataclass
class RepairLoopConfig:
    """Budgets for :func:`run_ci_green_gate`."""

    max_repair_attempts: int = 5
    wall_clock_budget_s: float = 1800.0
    poll_max_attempts: int = 20
    max_transient_retries: int = 2


@dataclass
class _AppliedPatch:
    """Reversible record of a patch applied to disk."""

    path: Path
    original: str


@dataclass
class _LoopState:
    """Mutable counters threaded through the loop."""

    attempt: int = 0
    transient_retries: int = 0
    start_monotonic: float = field(default_factory=time.monotonic)
    recent_conclusions: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Prompt sentinel — fail fast if the repair prompt loses its JSON contract.
# ---------------------------------------------------------------------------


def _assert_prompt_sentinel(prompt: str) -> None:
    """Raise :class:`PromptError` when the JSON-output instruction is absent."""
    if _PROMPT_REPAIR_SENTINEL not in prompt:
        raise PromptError(f"prompt-phase-8-repair.md missing sentinel: {_PROMPT_REPAIR_SENTINEL!r}")


# ---------------------------------------------------------------------------
# Polling — uses with_backoff + CircuitBreaker; TransientRunnerError drives retry.
# ---------------------------------------------------------------------------


async def _poll_for_completed_run(
    repo: RepoInfo,
    sha: str,
    config: RepairLoopConfig,
) -> dict[str, Any]:
    """Return the first completed run matching *sha*; retries while pending."""
    breaker = CircuitBreaker(max_failures=3)

    async def probe() -> dict[str, Any]:
        runs = gh_actions.list_workflow_runs(repo, sha)
        if not runs:
            raise TransientRunnerError(f"no runs yet for {sha[:8]}")
        completed = [r for r in runs if r.get("status") not in _RUNNING_STATUSES]
        if not completed:
            raise TransientRunnerError(f"runs still pending for {sha[:8]}")
        completed.sort(key=lambda r: r.get("createdAt", ""))
        return completed[-1]

    return await with_backoff(probe, attempts=config.poll_max_attempts, breaker=breaker)


# ---------------------------------------------------------------------------
# Evidence gathering — composes gh.actions + classifier inputs.
# ---------------------------------------------------------------------------


def _failing_job_names(repo: RepoInfo, run_id: int) -> list[str]:
    """Extract failing job names from ``gh run view --json jobs``."""
    detail = gh_actions.view_run(repo, run_id)
    jobs = detail.get("jobs") or []
    return [
        j.get("name", "")
        for j in jobs
        if j.get("conclusion") not in (None, "success", "skipped", "neutral")
    ]


def _build_evidence(
    repo: RepoInfo,
    run: dict[str, Any],
    recent_conclusions: list[str],
) -> tuple[ClassificationEvidence, str]:
    """Build a :class:`ClassificationEvidence` + return the raw log excerpt."""
    run_id = int(run["databaseId"])
    logs = gh_actions.get_failing_job_logs(repo, run_id)
    names = _failing_job_names(repo, run_id)
    return (
        ClassificationEvidence(
            failing_job_names=names,
            log_excerpt=logs,
            recent_conclusions=recent_conclusions,
        ),
        logs,
    )


# ---------------------------------------------------------------------------
# Repair-agent invocation.
# ---------------------------------------------------------------------------


async def _invoke_repair_agent(
    *,
    project_dir: Path,
    state_path: Path,
    logger: logging.Logger,
    runner_module: RunnerProtocol,
    effective_model: str | None,
    state_mode: str,
    failing_jobs: list[str],
    logs: str,
    attempt: int,
    max_attempts: int,
) -> Any:
    """Render the repair prompt and dispatch via ``rate_limit.main_loop``."""
    prompt = load_prompt(
        "prompt-phase-8-repair.md",
        FAILING_JOBS=", ".join(failing_jobs) if failing_jobs else "(unspecified)",
        CI_LOGS=logs,
        ATTEMPT=str(attempt + 1),
        MAX_ATTEMPTS=str(max_attempts),
    )
    _assert_prompt_sentinel(prompt)

    effort_level = _effort.resolve_effort(
        phase=8,
        complexity=state_mode,
        issue_labels=[],
        retry_count=attempt,
    )
    model = effective_model or _PHASE8_DEFAULT_MODEL
    _effort.validate_effort(effort_level, model)

    options = make_agent_options(
        model=model,
        effort=effort_level,
        allowed_tools=["Read", "Write", "Bash"],
        cwd=str(project_dir),
    )
    return await rate_limit.main_loop(
        runner_module,
        prompt,
        options,
        state_path=state_path,
        logger=logger,
    )


# ---------------------------------------------------------------------------
# Patch parsing + application.
# ---------------------------------------------------------------------------


def _parse_patches(raw: str) -> list[dict[str, Any]]:
    """Extract the JSON patch array from a noisy model response."""
    text = raw.strip()
    start = text.find("[")
    end = text.rfind("]")
    if start == -1 or end == -1 or end <= start:
        return []
    try:
        parsed = json.loads(text[start : end + 1])
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    return [p for p in parsed if _is_valid_patch(p)]


def _is_valid_patch(p: Any) -> bool:
    """Return ``True`` when *p* has the required ``file/line/old/new`` keys."""
    return (
        isinstance(p, dict)
        and isinstance(p.get("file"), str)
        and isinstance(p.get("line"), int)
        and isinstance(p.get("old"), str)
        and isinstance(p.get("new"), str)
    )


def _apply_patches(
    project_dir: Path,
    patches: list[dict[str, Any]],
) -> list[_AppliedPatch]:
    """Apply patches in order; collect originals so callers can revert."""
    applied: list[_AppliedPatch] = []
    for patch in patches:
        path = project_dir / patch["file"]
        if not path.is_file():
            continue
        original = path.read_text(encoding="utf-8")
        if patch["old"] not in original:
            continue
        path.write_text(original.replace(patch["old"], patch["new"], 1), encoding="utf-8")
        applied.append(_AppliedPatch(path=path, original=original))
    return applied


def _revert_patches(applied: list[_AppliedPatch]) -> None:
    """Restore each :class:`_AppliedPatch` to its captured original text."""
    for record in applied:
        record.path.write_text(record.original, encoding="utf-8")


# ---------------------------------------------------------------------------
# Local verify + commit/push.
# ---------------------------------------------------------------------------


def _collect_workflow_diff(
    project_dir: Path,
    applied: list[_AppliedPatch],
) -> str:
    """Concatenate post-patch text of any ``.github/workflows/`` files touched."""
    workflows_root = project_dir / ".github" / "workflows"
    pieces: list[str] = []
    for record in applied:
        try:
            record.path.relative_to(workflows_root)
        except ValueError:
            continue
        pieces.append(record.path.read_text(encoding="utf-8"))
    return "\n".join(pieces)


async def _verify_in_executor(
    project_dir: Path,
    workflow_diff: str,
) -> LocalVerifyResult:
    """Off-load the synchronous local-verify call to the default executor."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, lambda: run_local_verify(project_dir, workflow_diff))


def _commit_and_push(project_dir: Path, attempt: int, logger: logging.Logger) -> None:
    """Stage, commit, and push with one ``pull --rebase && push`` retry on rejection."""
    git_add_all(project_dir)
    git_commit(project_dir, f"fix(ci): repair attempt {attempt + 1}")
    branch = git_current_branch(project_dir)
    try:
        git_push(project_dir, branch)
    except GitError:
        logger.warning("Phase 8 repair: push rejected — rebasing and retrying once.")
        git_pull_rebase(project_dir)
        git_push(project_dir, branch)


# ---------------------------------------------------------------------------
# Remediation issue.
# ---------------------------------------------------------------------------


def _open_remediation_issue(
    repo: RepoInfo,
    last_logs: str,
    state: _LoopState,
    config: RepairLoopConfig,
) -> int:
    """Open the routed remediation issue on budget exhaustion."""
    body = (
        "## CI repair budget exhausted\n\n"
        f"- Attempts used: {state.attempt} / {config.max_repair_attempts}\n"
        f"- Wall-clock used: {time.monotonic() - state.start_monotonic:.1f}s "
        f"of {config.wall_clock_budget_s}s\n\n"
        "### Last failing logs (tail)\n\n"
        f"```\n{last_logs[-2000:]}\n```\n"
    )
    return create_issue(
        repo,
        "CI repair budget exhausted — manual remediation required",
        body,
        labels=["needs-manual-review", "area:ci"],
    )


# ---------------------------------------------------------------------------
# Public entry point.
# ---------------------------------------------------------------------------


async def run_ci_green_gate(
    repo: RepoInfo,
    project_dir: Path,
    state_path: Path,
    state: State,
    cycle: CycleState | None,
    *,
    runner_module: RunnerProtocol,
    effective_model: str | None,
    logger: logging.Logger,
    config: RepairLoopConfig | None = None,
) -> CiOutcome:
    """Drive the CI green-gate to ``"green"`` or surrender to ``"exhausted"``.

    See module docstring for the reuse-only contract. The function is
    deterministic about its budget: it stops when either
    ``max_repair_attempts`` is hit or ``wall_clock_budget_s`` elapses,
    measured against ``time.monotonic()`` captured at entry.
    """
    cfg = config or RepairLoopConfig()
    loop_state = _LoopState()
    last_logs = ""
    phase8 = getattr(cycle if cycle is not None else state, "phase8", None)

    while not _budget_exhausted(loop_state, cfg):
        sha = git_rev_parse_head(project_dir)
        run = await _poll_for_completed_run(repo, sha, cfg)
        if phase8 is not None:
            phase8.ci_run_id = int(run["databaseId"])

        if run.get("conclusion") == "success":
            return "green"

        loop_state.recent_conclusions.append(str(run.get("conclusion") or "failure"))
        evidence, last_logs = _build_evidence(repo, run, loop_state.recent_conclusions)
        kind = classify(evidence)

        if kind == "transient" and loop_state.transient_retries < cfg.max_transient_retries:
            loop_state.transient_retries += 1
            continue

        result = await _invoke_repair_agent(
            project_dir=project_dir,
            state_path=state_path,
            logger=logger,
            runner_module=runner_module,
            effective_model=effective_model,
            state_mode=state.mode,
            failing_jobs=evidence.failing_job_names,
            logs=last_logs,
            attempt=loop_state.attempt,
            max_attempts=cfg.max_repair_attempts,
        )

        patches = _parse_patches(result.text)
        applied = _apply_patches(project_dir, patches)
        verify = await _verify_in_executor(
            project_dir, _collect_workflow_diff(project_dir, applied)
        )

        if verify.blocked_by_guardrail or not verify.passed:
            logger.warning(
                "Phase 8 repair: attempt %d rejected (%s); reverting %d patches.",
                loop_state.attempt + 1,
                "guardrail" if verify.blocked_by_guardrail else "local-verify",
                len(applied),
            )
            _revert_patches(applied)
            loop_state.attempt += 1
            if phase8 is not None:
                phase8.repair_attempts = loop_state.attempt
            continue

        _commit_and_push(project_dir, loop_state.attempt, logger)
        loop_state.attempt += 1
        if phase8 is not None:
            phase8.repair_attempts = loop_state.attempt

    _open_remediation_issue(repo, last_logs, loop_state, cfg)
    return "exhausted"


def _budget_exhausted(loop_state: _LoopState, config: RepairLoopConfig) -> bool:
    """Return ``True`` once attempts or wall-clock budget run out."""
    if loop_state.attempt >= config.max_repair_attempts:
        return True
    return (time.monotonic() - loop_state.start_monotonic) >= config.wall_clock_budget_s
