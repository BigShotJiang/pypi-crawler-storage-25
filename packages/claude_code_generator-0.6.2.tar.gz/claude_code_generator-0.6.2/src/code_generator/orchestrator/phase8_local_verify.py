"""Phase 8 pre-push gate — guardrail scan + local build/lint/test.

The repair loop invokes :func:`run_local_verify` before every CI-fix
push so a locally-red tree (or one that loosens enforcement via a
workflow YAML edit) can never reach the remote. Two short-circuits:

1. Guardrail check: scans the workflow YAML diff with
   :func:`phase8_workflow_gen.scan_for_guardrail_violations`. Any
   violation aborts immediately — no subprocess fires.
2. Project commands: derived from
   :func:`phase8_workflow_gen.detect_project_kind`. Fail-fast on the
   first non-zero exit; the tail of stderr is returned for the repair
   agent's next prompt.

Synchronous module. The repair loop is responsible for off-loading via
``asyncio.get_event_loop().run_in_executor(None, ...)``.
"""

from __future__ import annotations

import subprocess
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from code_generator import env
from code_generator.orchestrator.phase8_workflow_gen import (
    ProjectKind,
    detect_project_kind,
    scan_for_guardrail_violations,
)

if TYPE_CHECKING:
    from pathlib import Path

STDERR_EXCERPT_LIMIT = 2000

SubprocessRun = Callable[..., subprocess.CompletedProcess[str]]


@dataclass(frozen=True)
class LocalVerifyResult:
    """Outcome of the pre-push gate for the repair loop's decision branch."""

    passed: bool
    stderr_excerpt: str
    blocked_by_guardrail: bool
    guardrail_violations: list[str] = field(default_factory=list)


_COMMANDS_BY_KIND: dict[ProjectKind, list[list[str]]] = {
    "python": [["pytest"], ["ruff", "check"]],
    "node": [["npm", "test"], ["npm", "run", "lint"]],
    "unknown": [],
}


def detect_local_commands(project_dir: Path) -> list[list[str]]:
    """Return argv lists for the detected project kind's verify suite."""
    kind = detect_project_kind(project_dir)
    return [list(cmd) for cmd in _COMMANDS_BY_KIND[kind]]


def run_local_verify(
    project_dir: Path,
    workflow_yaml_diff: str,
    *,
    timeout_s: float = 120.0,
    _run_subprocess: SubprocessRun = subprocess.run,
) -> LocalVerifyResult:
    """Run guardrail scan + local verify commands; return :class:`LocalVerifyResult`.

    Args:
        project_dir: Generated-project root the commands run inside.
        workflow_yaml_diff: Raw text of any workflow YAML changes about
            to be pushed. Empty string when the repair patch did not
            touch ``.github/workflows/``.
        timeout_s: Per-command timeout passed to ``subprocess.run``.
        _run_subprocess: DI hook for tests; defaults to
            :func:`subprocess.run`.
    """
    violations = scan_for_guardrail_violations(workflow_yaml_diff)
    if violations:
        return LocalVerifyResult(
            passed=False,
            stderr_excerpt="",
            blocked_by_guardrail=True,
            guardrail_violations=violations,
        )
    return _run_commands(project_dir, timeout_s, _run_subprocess)


def _run_commands(
    project_dir: Path,
    timeout_s: float,
    runner: SubprocessRun,
) -> LocalVerifyResult:
    """Execute detected commands fail-fast; return aggregate result."""
    commands = detect_local_commands(project_dir)
    sanitized_env = env.build_agent_env()
    for cmd in commands:
        outcome = _run_one(cmd, project_dir, timeout_s, sanitized_env, runner)
        if outcome is not None:
            return outcome
    return LocalVerifyResult(
        passed=True,
        stderr_excerpt="",
        blocked_by_guardrail=False,
        guardrail_violations=[],
    )


def _run_one(
    cmd: list[str],
    project_dir: Path,
    timeout_s: float,
    sanitized_env: dict[str, str],
    runner: SubprocessRun,
) -> LocalVerifyResult | None:
    """Run *cmd*; return a failing result, or ``None`` on success."""
    try:
        result = runner(
            cmd,
            cwd=project_dir,
            capture_output=True,
            text=True,
            timeout=timeout_s,
            env=sanitized_env,
        )
    except subprocess.TimeoutExpired:
        return LocalVerifyResult(
            passed=False,
            stderr_excerpt=f"timeout after {timeout_s}s running {' '.join(cmd)}",
            blocked_by_guardrail=False,
            guardrail_violations=[],
        )
    if result.returncode != 0:
        combined = (result.stdout or "") + (result.stderr or "")
        return LocalVerifyResult(
            passed=False,
            stderr_excerpt=combined[-STDERR_EXCERPT_LIMIT:],
            blocked_by_guardrail=False,
            guardrail_violations=[],
        )
    return None
