"""§12 once-per-cycle cache pre-warm (issue #241).

Fires exactly one near-empty request on the shared client between Phase 1
and Phase 2 so the §8 BP1/BP2/BP3 cache prefix (tools, base system prompt,
repo-map + cycle-specialized prompt) is loaded into the workspace cache
before Phase 2's first turn. Phase 2 then sees ``cache_read_input_tokens``
on its first ``ResultMessage`` instead of paying the full
``cache_creation_input_tokens`` cost.

The pre-warm is **not** meant to do anything visible — the prompt asks the
model for a one-token reply (``"ok"``). The Anthropic API requires
``max_tokens >= 1`` so a literal ``max_tokens=0`` is not portable; the
warmup relies on a deterministic short prompt instead. Output cost is
negligible compared with the cache-creation savings on subsequent turns.

Idempotency lives at the call site (``cycle_loop._run_phases`` flips a
``cache_prewarmed`` flag on the active ``CycleState`` / ``State``); this
module is a pure async helper with no state of its own.

The pre-warm rides on ``run_with_shared_client`` so:

* Non-negotiable #4 (overage abort) — ``handle_rate_limit_event`` is invoked
  if the SDK emits a ``RateLimitEvent`` mid-warmup.
* Non-negotiable #5 (rate-limit wait-and-resume) — the same handler
  persists ``paused_until`` and propagates ``RateLimitHit`` so the
  orchestrator's rate-limit machinery resumes correctly.
* Non-negotiable #9 (no ``max_turns``) — ``make_agent_options`` is called
  without the kwarg.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from code_generator.runner.options import make_agent_options
from code_generator.runner.sdk_runner import run_with_shared_client

if TYPE_CHECKING:
    import logging
    from pathlib import Path


# Deterministic no-op prompt — short, predictable, and free of cycle-specific
# content so the cache prefix the warmup loads is identical across cycles.
_PREWARM_PROMPT = "Pre-warm cache. Reply 'ok' only."


async def warm_workspace_cache(
    client: Any,
    *,
    project_dir: Path,
    logger: logging.Logger,
) -> None:
    """Fire one near-empty request on *client* to load BP1/BP2/BP3 into cache.

    Args:
        client: Open ``ClaudeSDKClient`` (or duck-typed equivalent) owned by
            ``managed_shared_client``.
        project_dir: Project root; used to resolve ``state.json`` for the
            rate-limit / overage handlers inside ``run_with_shared_client``.
        logger: Phase logger; the runner emits its own startup line plus any
            rate-limit warnings on this logger.
    """
    state_path = project_dir / ".code-generator" / "state.json"
    options = make_agent_options(allowed_tools=[])
    logger.info("cache pre-warm: firing once-per-cycle no-op request.")
    await run_with_shared_client(
        client,
        _PREWARM_PROMPT,
        options,
        logger=logger,
        state_path=state_path,
    )
    logger.info("cache pre-warm: complete.")
