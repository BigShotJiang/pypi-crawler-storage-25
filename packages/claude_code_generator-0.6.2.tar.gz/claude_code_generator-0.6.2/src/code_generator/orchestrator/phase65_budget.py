"""Wall + turn budget tracker for Phase 6.5 (#293).

Hard budget for the bounded repair loop. Phase 6.5 is finite by contract;
this tracker enforces the upper bound on wall-clock seconds and
cumulative SDK turns the loop may consume.

Additive only: never bypasses non-negotiable #4 (Anthropic overage abort)
or the ``OllamaBudgetTracker`` on Ollama/Codex codepaths. Both
``None`` budgets keep current behaviour (no enforcement).
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from code_generator.orchestrator.phase6_5_verify import VerificationFailed

if TYPE_CHECKING:
    import logging

__all__ = ["Phase65BudgetTracker"]


class Phase65BudgetTracker:
    """Hard wall + turn budget for the Phase 6.5 attempt loop."""

    def __init__(
        self,
        *,
        wall_budget_s: float | None,
        turn_budget: int | None,
    ) -> None:
        self._wall_budget_s = wall_budget_s
        self._turn_budget = turn_budget
        self._started_at: float | None = None

    def start(self) -> None:
        """Mark the wall-clock start point. Must be called before :meth:`check`."""
        self._started_at = time.monotonic()

    def check(self, *, turns_consumed: int, logger: logging.Logger) -> None:
        """Raise :class:`VerificationFailed` if either budget is breached."""
        if self._started_at is None:
            raise RuntimeError("Phase65BudgetTracker.check called before start()")
        self._check_turn(turns_consumed, logger)
        self._check_wall(logger)

    def _check_turn(self, turns_consumed: int, logger: logging.Logger) -> None:
        if self._turn_budget is None or turns_consumed <= self._turn_budget:
            return
        message = (
            f"Phase 6.5 turn budget exceeded: consumed={turns_consumed} budget={self._turn_budget}"
        )
        logger.warning(message)
        raise VerificationFailed(message)

    def _check_wall(self, logger: logging.Logger) -> None:
        if self._wall_budget_s is None or self._started_at is None:
            return
        elapsed = time.monotonic() - self._started_at
        if elapsed <= self._wall_budget_s:
            return
        message = (
            f"Phase 6.5 wall budget exceeded: elapsed={elapsed:.1f}s "
            f"budget={self._wall_budget_s:.1f}s"
        )
        logger.warning(message)
        raise VerificationFailed(message)
