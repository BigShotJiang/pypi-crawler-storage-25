"""VIGIL — reflective overseer at the Phase 3/4 → 6.5 boundary (#287).

Catches the "premature done" failure mode: every issue is closed (the
model reports success) but the app exits non-zero on boot. When the
condition fires, ``vigil_triggered`` flips True on the active
``CycleState`` (or root ``State`` in single-mode runs) and state.json
is written atomically. Phase 6.5 reads the flag on entry and refuses
to short-circuit even if a prior Phase 6 sentinel was recorded.

The boot probe reuses :func:`phase6_5_verify.run_t1_boot` with a tight
window so the overhead is bounded at ~5s per cycle.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from code_generator.env import build_agent_env
from code_generator.orchestrator.agent_spec import load_agent_spec
from code_generator.orchestrator.phase6_5_verify import run_t1_boot
from code_generator.state import save_state

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator.state import CycleState, IssueState, State


__all__ = ["check_premature_done"]


_logger = logging.getLogger(__name__)


async def check_premature_done(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    state_path: Path,
    *,
    logger: logging.Logger,
    boot_window_s: float = 5.0,
) -> bool:
    """Run the boundary check. Return ``True`` iff premature-done fires."""
    target = cycle if cycle is not None else state
    issues = _in_scope_issues(state, cycle)
    if not issues or any(issue.status != "closed" for issue in issues):
        return False

    entry_cmd = _resolve_entry_cmd(project_dir)
    if entry_cmd is None:
        logger.info("vigil: skipping boot probe — no entry_cmd available")
        return False

    result = run_t1_boot(
        project_dir,
        env=build_agent_env(),
        entry_cmd=entry_cmd,
        boot_window_s=boot_window_s,
    )
    if result.skipped or result.passed:
        return False

    target.vigil_triggered = True
    save_state(state_path, state)
    logger.warning(
        "vigil: premature 'done' detected — all issues closed but boot probe failed "
        "(tier=%s detail=%s); forcing Phase 6.5 re-entry",
        result.tier_id,
        result.failing_detail or "(none)",
    )
    return True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _in_scope_issues(state: State, cycle: CycleState | None) -> list[IssueState]:
    if cycle is not None:
        return list(cycle.issues)
    return list(state.issues)


def _resolve_entry_cmd(project_dir: Path) -> list[str] | None:
    """Pull the entry command from the persisted AgentSpec, when available."""
    dot_dir = project_dir / ".code-generator"
    try:
        spec = load_agent_spec(dot_dir)
    except FileNotFoundError:
        return None
    entry = list(spec.entry_cmd)
    return entry if entry else None
