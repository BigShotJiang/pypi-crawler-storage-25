"""Adaptive tier selection bridge for Phase 6.5 (#281).

Bridges :func:`code_generator.agents.detect` and a filesystem probe for
``docker-compose.yml`` / ``docker-compose.yaml`` / ``Dockerfile`` to the
``TierConfig`` tuple consumed by :func:`agent_spec.build_agent_spec`.

Backend-only project (no frontend agent, no compose, no Dockerfile)
yields ``T3.enabled=False`` and ``T4.enabled=False``; a full-stack
project with a compose file yields all tiers enabled. Each disabled
tier carries a non-empty ``skip_reason`` so logs and ``code-generator
status`` can surface *why* a tier was skipped.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from code_generator.agents import detect as _detect_agents
from code_generator.orchestrator.agent_spec import TierConfig

if TYPE_CHECKING:
    from pathlib import Path

__all__ = ["select_tiers"]


_FRONTEND_PRIMARY = "frontend-developer"
_DOCKER_ARTIFACTS: tuple[str, ...] = (
    "docker-compose.yml",
    "docker-compose.yaml",
    "Dockerfile",
)
_NO_FRONTEND_REASON = "no frontend agent detected (T3 requires a browser UI)"
_NO_DOCKER_REASON = "no docker-compose.yml/.yaml or Dockerfile at project root"


def select_tiers(
    project_dir: Path,
    requirements_path: Path,
    *,
    has_frontend: bool | None = None,
) -> list[TierConfig]:
    """Return the ordered ``TierConfig`` list for *project_dir*.

    T0/T1/T2 are always enabled. T3 is enabled iff a frontend agent is
    in :attr:`AgentSelection.primary` (or ``has_frontend=True``); T4 is
    enabled iff a docker artifact exists at the project root.
    """
    frontend = has_frontend if has_frontend is not None else _frontend_in_primary(requirements_path)
    docker = _has_docker_artifact(project_dir)

    return [
        TierConfig(tier_id="T0", enabled=True),
        TierConfig(tier_id="T1", enabled=True, port=8000),
        TierConfig(tier_id="T2", enabled=True),
        _optional("T3", frontend, _NO_FRONTEND_REASON),
        _optional("T4", docker, _NO_DOCKER_REASON),
    ]


def _frontend_in_primary(requirements_path: Path) -> bool:
    return _FRONTEND_PRIMARY in _detect_agents(requirements_path).primary


def _has_docker_artifact(project_dir: Path) -> bool:
    return any((project_dir / name).exists() for name in _DOCKER_ARTIFACTS)


def _optional(tier_id: str, enabled: bool, skip_reason: str) -> TierConfig:
    return TierConfig(
        tier_id=tier_id,
        enabled=enabled,
        skip_reason=None if enabled else skip_reason,
    )
