"""T4 container tier for Phase 6.5 (#283).

Boots the project under Docker (compose preferred; bare ``Dockerfile``
fallback), waits for the health endpoint, replays the T2 contract
suite against the containerized service, and tears the container
down on every code path via ``try/finally``.

Cleanly skips when no docker manifest exists — never crashes the
orchestrator even with a stale ``AgentSpec``.

The Anthropic credentials are stripped upstream by
``code_generator.env.build_agent_env()`` and threaded through to every
subprocess call here, satisfying cache-workspace invariant #2.
"""

from __future__ import annotations

import logging
import shutil
import time
from typing import TYPE_CHECKING

import httpx

from code_generator.orchestrator import phase6_5_verify as _verify
from code_generator.orchestrator.phase6_5_verify import (
    Endpoint,  # public dataclass — safe to import at module load
    TierResult,
)


def _run_capture(cmd, cwd, env, *, timeout=None):  # type: ignore[no-untyped-def]
    return _verify._run_capture(cmd, cwd, env, timeout=timeout)


def _skip(tier_id: str, reason: str) -> TierResult:
    return _verify._skip(tier_id, reason)


def _tail(text: str | None) -> str | None:
    return _verify._tail(text)


def run_t2_api(*args, **kwargs):  # type: ignore[no-untyped-def]
    return _verify.run_t2_api(*args, **kwargs)


if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence
    from pathlib import Path


__all__ = ["run_t4_container"]


_logger = logging.getLogger(__name__)

_COMPOSE_MANIFESTS: tuple[str, ...] = ("docker-compose.yml", "docker-compose.yaml")
_DOCKERFILE = "Dockerfile"
_IMAGE_TAG = "phase65-t4:latest"
_CONTAINER_NAME = "phase65-t4"
_POLL_INTERVAL_S = 0.5


def run_t4_container(
    project_dir: Path,
    *,
    env: Mapping[str, str],
    base_url: str,
    endpoints: Sequence[Endpoint],
    health_path: str = "/health",
    boot_timeout_s: float = 60.0,
    compose_file: Path | None = None,
    command_timeout_s: float | None = None,
) -> TierResult:
    """Run T4: boot container, wait healthy, replay T2, tear down.

    Detection order: explicit ``compose_file`` arg → ``docker-compose.yml``
    → ``docker-compose.yaml`` → bare ``Dockerfile`` fallback. *command_timeout_s*
    bounds each ``docker`` subprocess call (#293).
    """
    plan = _resolve_runtime(project_dir, compose_file)
    if plan is None:
        return _skip("T4", "no docker-compose.yml/.yaml or Dockerfile at project root")
    if shutil.which("docker") is None:
        return _skip("T4", "docker CLI not available on $PATH")

    return _execute_plan(
        plan,
        project_dir,
        env,
        base_url,
        endpoints,
        health_path,
        boot_timeout_s,
        command_timeout_s,
    )


# ---------------------------------------------------------------------------
# Plan resolution
# ---------------------------------------------------------------------------


class _ContainerPlan:
    """Command set for one of the two T4 runtime strategies."""

    def __init__(self, up: list[str], down: list[list[str]]) -> None:
        self.up = up
        self.down = down


def _resolve_runtime(project_dir: Path, compose_override: Path | None) -> _ContainerPlan | None:
    compose = _select_compose(project_dir, compose_override)
    if compose is not None:
        return _compose_plan(compose)
    if (project_dir / _DOCKERFILE).exists():
        return _dockerfile_plan()
    return None


def _select_compose(project_dir: Path, override: Path | None) -> Path | None:
    if override is not None and override.exists():
        return override
    for name in _COMPOSE_MANIFESTS:
        candidate = project_dir / name
        if candidate.exists():
            return candidate
    return None


def _compose_plan(compose_file: Path) -> _ContainerPlan:
    return _ContainerPlan(
        up=["docker", "compose", "-f", str(compose_file), "up", "-d", "--build"],
        down=[["docker", "compose", "-f", str(compose_file), "down", "-v"]],
    )


def _dockerfile_plan() -> _ContainerPlan:
    return _ContainerPlan(
        up=["docker", "build", "-t", _IMAGE_TAG, "."],
        down=[
            ["docker", "stop", _CONTAINER_NAME],
            ["docker", "rm", _CONTAINER_NAME],
        ],
    )


# ---------------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------------


def _execute_plan(
    plan: _ContainerPlan,
    project_dir: Path,
    env: Mapping[str, str],
    base_url: str,
    endpoints: Sequence[Endpoint],
    health_path: str,
    boot_timeout_s: float,
    command_timeout_s: float | None,
) -> TierResult:
    try:
        up_result = _bring_up(plan, project_dir, env, command_timeout_s)
        if up_result is not None:
            return up_result
        if not _wait_for_health(base_url, health_path, boot_timeout_s):
            return _t4_fail(
                exit_code=None,
                detail=f"health probe {health_path} did not respond within {boot_timeout_s}s",
                stderr="health-wait timeout",
                stdout_full=None,
            )
        return _replay_t2(project_dir, env, base_url, endpoints, health_path)
    finally:
        _teardown(plan, project_dir, env, command_timeout_s)


def _bring_up(
    plan: _ContainerPlan,
    project_dir: Path,
    env: Mapping[str, str],
    command_timeout_s: float | None,
) -> TierResult | None:
    """Execute the ``up`` command. Return failing :class:`TierResult` or ``None``."""
    completed = _run_capture(plan.up, project_dir, env, timeout=command_timeout_s)
    if _verify._is_timeout(completed):
        return _verify._fail_timeout("T4", command_timeout_s, completed)
    if completed.returncode == 0:
        if plan.up[1] == "build":
            return _docker_run_after_build(project_dir, env, command_timeout_s)
        return None
    return _t4_fail(
        exit_code=completed.returncode,
        detail=f"{' '.join(plan.up)} exited {completed.returncode}",
        stderr=completed.stderr,
        stdout_full=_combine_output(completed.stdout, completed.stderr),
    )


def _docker_run_after_build(
    project_dir: Path,
    env: Mapping[str, str],
    command_timeout_s: float | None,
) -> TierResult | None:
    run_cmd = [
        "docker",
        "run",
        "-d",
        "--rm",
        "-p",
        "8000:8000",
        "--name",
        _CONTAINER_NAME,
        _IMAGE_TAG,
    ]
    completed = _run_capture(run_cmd, project_dir, env, timeout=command_timeout_s)
    if _verify._is_timeout(completed):
        return _verify._fail_timeout("T4", command_timeout_s, completed)
    if completed.returncode == 0:
        return None
    return _t4_fail(
        exit_code=completed.returncode,
        detail=f"{' '.join(run_cmd)} exited {completed.returncode}",
        stderr=completed.stderr,
        stdout_full=_combine_output(completed.stdout, completed.stderr),
    )


def _replay_t2(
    project_dir: Path,
    env: Mapping[str, str],
    base_url: str,
    endpoints: Sequence[Endpoint],
    health_path: str,
) -> TierResult:
    t2 = run_t2_api(
        project_dir,
        env=env,
        base_url=base_url,
        endpoints=endpoints,
        health_path=health_path,
    )
    if t2.passed:
        return TierResult(
            tier_id="T4",
            passed=True,
            skipped=False,
            skip_reason=None,
            exit_code=None,
            stderr_tail=None,
            failing_detail=None,
        )
    return TierResult(
        tier_id="T4",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=t2.exit_code,
        stderr_tail=t2.stderr_tail,
        failing_detail=f"T2 replay in container failed: {t2.failing_detail or ''}",
        stdout_full=t2.stdout_full,
    )


def _teardown(
    plan: _ContainerPlan,
    project_dir: Path,
    env: Mapping[str, str],
    command_timeout_s: float | None,
) -> None:
    for cmd in plan.down:
        try:
            result = _run_capture(cmd, project_dir, env, timeout=command_timeout_s)
            if result.returncode != 0:
                _logger.warning(
                    "T4 teardown command %s exited %d (continuing): %s",
                    " ".join(cmd),
                    result.returncode,
                    _tail(result.stderr) or "",
                )
        except OSError as exc:
            _logger.warning("T4 teardown command %s raised %s (continuing)", " ".join(cmd), exc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _wait_for_health(base_url: str, health_path: str, timeout_s: float) -> bool:
    deadline = time.monotonic() + timeout_s
    url = base_url.rstrip("/") + health_path
    while time.monotonic() < deadline:
        try:
            response = httpx.get(url, timeout=1.0)
        except httpx.HTTPError:
            response = None
        if response is not None and response.status_code < 500:
            return True
        time.sleep(_POLL_INTERVAL_S)
    return False


def _t4_fail(
    *,
    exit_code: int | None,
    detail: str,
    stderr: str,
    stdout_full: str | None,
) -> TierResult:
    return TierResult(
        tier_id="T4",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=exit_code,
        stderr_tail=_tail(stderr),
        failing_detail=detail,
        stdout_full=stdout_full,
    )


def _combine_output(stdout: str | None, stderr: str | None) -> str:
    parts: list[str] = []
    if stdout:
        parts.append(f"--- stdout ---\n{stdout}")
    if stderr:
        parts.append(f"--- stderr ---\n{stderr}")
    return "\n".join(parts) if parts else ""
