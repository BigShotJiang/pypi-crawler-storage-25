"""Acceptance-criteria oracle (#280).

Pure parser that walks every ``- [ ]`` bullet under ``## Global acceptance
criteria`` and every numbered ``### N.`` subsection inside ``## Scope`` and
maps each criterion to a concrete runtime check:

- ``tier="T2"`` — backticked HTTP path / ``METHOD /path`` token present
  (delegates to ``phase6_5_verify.extract_endpoints_from_requirements``
  per criterion).
- ``tier="T3"`` — UI-rendering keywords (``UI``, ``renders``, ``displays``,
  ``screen``, ``page``).
- ``verifiable=False`` — references an internal file path or no concrete
  runtime check is inferable. ``not_verifiable_reason`` is always
  populated when ``verifiable`` is False.

Reuses the regex primitives from
``code_generator.requirements_structure`` rather than duplicating regex
logic (per the issue's implementation notes).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

from code_generator.orchestrator.phase6_5_verify import (
    extract_endpoints_from_requirements,
)
from code_generator.requirements_structure import (
    _NUMBERED_SECTION_RE,
    _SCOPE_BODY_RE,
)

__all__ = [
    "CriterionMapping",
    "OracleReport",
    "build_oracle_report",
]


Tier = Literal["T2", "T3"]


@dataclass(frozen=True)
class CriterionMapping:
    """A single acceptance criterion mapped to a runtime check (or not)."""

    text: str
    tier: Tier | None
    verifiable: bool
    not_verifiable_reason: str | None


@dataclass(frozen=True)
class OracleReport:
    """Structured oracle output: global and per-scope-section mappings."""

    global_criteria: tuple[CriterionMapping, ...]
    scope_criteria: tuple[CriterionMapping, ...]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_oracle_report(requirements_text: str) -> OracleReport:
    """Parse *requirements_text* into a structured ``OracleReport``.

    Pure — no I/O, no caching, no global state mutation. Same input
    yields an equal report.
    """
    if not requirements_text.strip():
        return OracleReport(global_criteria=(), scope_criteria=())

    global_mappings = tuple(_classify(c) for c in _global_criteria(requirements_text))
    scope_mappings = tuple(_classify(c) for c in _scope_criteria(requirements_text))
    return OracleReport(global_criteria=global_mappings, scope_criteria=scope_mappings)


# ---------------------------------------------------------------------------
# Section extraction
# ---------------------------------------------------------------------------


_GLOBAL_BODY_RE = re.compile(
    r"^## global acceptance criteria[ \t]*\n(.*?)(?=^## |\Z)",
    re.MULTILINE | re.DOTALL | re.IGNORECASE,
)
_AC_BLOCK_RE = re.compile(
    r"^[ \t]*Acceptance criteria[ \t]*\n(.*?)(?=^### |\Z)",
    re.MULTILINE | re.DOTALL | re.IGNORECASE,
)
_CHECKBOX_BULLET_RE = re.compile(r"^\s*-\s*\[[ xX]\]\s+(.*)$", re.MULTILINE)


def _global_criteria(text: str) -> list[str]:
    match = _GLOBAL_BODY_RE.search(text)
    if match is None:
        return []
    return _bullets(match.group(1))


def _scope_criteria(text: str) -> list[str]:
    scope = _SCOPE_BODY_RE.search(text)
    if scope is None:
        return []
    criteria: list[str] = []
    for section in _NUMBERED_SECTION_RE.findall(scope.group(1)):
        for ac_block in _AC_BLOCK_RE.findall(section):
            criteria.extend(_bullets(ac_block))
    return criteria


def _bullets(block: str) -> list[str]:
    return [m.group(1).strip() for m in _CHECKBOX_BULLET_RE.finditer(block)]


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------


_UI_KEYWORDS: frozenset[str] = frozenset({"ui", "renders", "displays", "screen", "page"})
_FILE_SUFFIXES: tuple[str, ...] = (".py", ".md", ".json", ".ts", ".tsx", ".yaml", ".yml")
_BACKTICK_TOKEN_RE = re.compile(r"`([^`]+)`")


def _classify(criterion: str) -> CriterionMapping:
    if _has_endpoint(criterion):
        return CriterionMapping(
            text=criterion, tier="T2", verifiable=True, not_verifiable_reason=None
        )
    if _references_internal_code(criterion):
        return CriterionMapping(
            text=criterion,
            tier=None,
            verifiable=False,
            not_verifiable_reason="internal/code-level criterion (references source path)",
        )
    if _mentions_ui(criterion):
        return CriterionMapping(
            text=criterion, tier="T3", verifiable=True, not_verifiable_reason=None
        )
    return CriterionMapping(
        text=criterion,
        tier=None,
        verifiable=False,
        not_verifiable_reason="no concrete runtime check inferable",
    )


def _has_endpoint(criterion: str) -> bool:
    bullet = f"- [ ] {criterion}\n"
    return bool(extract_endpoints_from_requirements(bullet))


def _references_internal_code(criterion: str) -> bool:
    for token in _BACKTICK_TOKEN_RE.findall(criterion):
        if any(suffix in token for suffix in _FILE_SUFFIXES):
            return True
    return False


def _mentions_ui(criterion: str) -> bool:
    lowered = criterion.lower()
    return any(_word_matches(lowered, kw) for kw in _UI_KEYWORDS)


def _word_matches(text: str, keyword: str) -> bool:
    return bool(re.search(rf"\b{re.escape(keyword)}\b", text))
