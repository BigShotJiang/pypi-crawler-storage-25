"""Phases 3 & 4 — Implementation loop (TDD, fresh session per issue).

Each open issue gets its own SDK session (non-negotiable #6: no ``resume``).
The issue agent is taken from state; skills default to ``solid-principles``
augmented by whatever ``agents.detect()`` returns for the requirements file.

Non-negotiable #8: model is hard-coded to ``claude-sonnet-4-6``.
"""

from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING, Any

from code_generator import agents as _agents
from code_generator import effort as _effort
from code_generator import gh as _gh
from code_generator import state as _state
from code_generator.logging_setup import log_issue_usage, log_phase_usage, setup_phase_logger
from code_generator.orchestrator._comments import get_or_fetch_comments
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit
from code_generator.runner import sdk_runner as _sdk_runner
from code_generator.runner._telemetry import accumulate_telemetry
from code_generator.runner.cache_breakpoints import resolve_active_ttl
from code_generator.runner.compaction_pause import CompactionPauseHandler
from code_generator.runner.mcp import build_mcp_servers, mcp_tool_wildcards
from code_generator.runner.options import (
    compaction_beta_available,
    make_agent_options,
    max_turns_kwargs,
)
from code_generator.runner.phase_telemetry import accumulate_phase_telemetry
from code_generator.runner.soft_reset import (
    boundary_prefix_only,
)
from code_generator.runner.soft_reset import (
    soft_reset_context as _soft_reset_context,
)
from code_generator.runner.types import MaxTurnsExceeded, OverageAbort, RateLimitHit, TokenUsage
from code_generator.state import CycleState

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import State


def _find_effort_hint(
    hints: list[_state.EffortHint],
    labels: list[str],
) -> _effort.EffortLevel | None:
    """Return effort from the first hint whose scope_keyword appears in any label.

    Args:
        hints: Effort hints from state or cycle (Phase 0 output).
        labels: GitHub label names attached to the current issue.

    Returns:
        Matching EffortLevel, or ``None`` when no hint matches.
    """
    for hint in hints:
        if any(hint.scope_keyword in label for label in labels):
            return _effort.EffortLevel(hint.effort)
    return None


def _default_skills(project_dir: Path) -> str:
    """Derive skill names from the requirements file (or use generic fallback).

    Args:
        project_dir: Project root; the requirements file lives at
            ``<project_dir>/.code-generator/requirements.md``.

    Returns:
        Comma-joined skill names string.
    """
    req_path = project_dir / ".code-generator" / "requirements.md"
    selection = _agents.detect(req_path)
    skills = selection.skills or ("solid-principles",)
    return ",".join(skills)


def _build_prompt(
    issue: _state.IssueState,
    skills: str,
    comments_section: str,
    attempt: int,
    last_err: str,
) -> str:
    """Build the implementation prompt for one attempt.

    Args:
        issue: The issue being implemented.
        skills: Comma-joined skill names.
        comments_section: Pre-formatted issue comments.
        attempt: Zero-based attempt index (0 = first try).
        last_err: Error message from the previous attempt (empty on first try).

    Returns:
        The prompt string to pass to the runner.
    """
    agent = issue.agent or "python-pro"
    base = load_prompt(
        "prompt-phase-3-implementation.md",
        ISSUE_NUMBER=str(issue.number),
        PRIMARY_AGENT=agent,
        SKILLS=skills,
        ISSUE_COMMENTS=comments_section,
    )
    if attempt > 0:
        return f"{base}\n\nPrevious attempt failed: {last_err}. Be more explicit this time."
    return base


def _resolve_issue_effort(
    issue: _state.IssueState,
    effort_hints: list[_state.EffortHint],
    attempt: int,
    complexity: str,
    effective_model: str | None = None,
) -> _effort.EffortLevel | None:
    """Resolve and validate the effort level for an issue attempt.

    Args:
        issue: The issue being implemented.
        effort_hints: Effort hints from state or cycle (Phase 0 output).
        attempt: Zero-based attempt index.
        complexity: Project complexity string from state (e.g. ``"single"``,
            ``"multi-cycle"``, ``"unknown"``).  Must be non-empty for phase 4
            when ``attempt == 0`` and no effort hint is found.

    Returns:
        Validated EffortLevel.

    Raises:
        ValueError: When the resolved effort is incompatible with the model.
        InvalidEffortInput: When complexity is empty and no override is available.
    """
    effort_hint = _find_effort_hint(effort_hints, issue.labels)
    effort_level = _effort.resolve_effort(
        phase=4,
        complexity=complexity,
        issue_labels=issue.labels,
        retry_count=attempt,
        effort_hint=effort_hint,
    )
    _effort.validate_effort(effort_level, effective_model or _PHASE3_4_DEFAULT_MODEL)
    return effort_level


_PHASE3_4_DEFAULT_MODEL = "claude-sonnet-4-6"
# CLAUDE.md invariant #8; overridden via ``effective_model`` on Ollama — #219.


async def _implement_single_issue(
    issue: _state.IssueState,
    state: State,
    state_path: Path,
    skills: str,
    effort_hints: list[_state.EffortHint],
    project_dir: Path,
    runner_module: RunnerProtocol,
    logger: logging.Logger,
    max_retries: int,
    mcp_servers: dict | None = None,
    shared_client: Any = None,
    boundary_prefix: str = "",
    context_management: dict | None = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
    pause_handler: CompactionPauseHandler | None = None,
) -> tuple[bool, TokenUsage, float, int, int]:
    """Run the retry loop for a single issue.

    Args:
        issue: The issue to implement.
        state: Root state object (mutated in place).
        state_path: Absolute path to state.json.
        skills: Comma-joined skill names.
        effort_hints: Effort hints for effort resolution.
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Phase logger.
        max_retries: Maximum number of attempts.
        mcp_servers: Optional MCP server config.
        shared_client: Open ``ClaudeSDKClient`` for shared-session mode, or
            ``None`` for fresh-mode (uses ``rate_limit.main_loop`` per attempt).
        boundary_prefix: Text prepended to the prompt on the first attempt only —
            carries the soft-reset boundary message from :func:`soft_reset_context`.
            Empty string when this is the cycle's first issue.
        context_management: Optional context-management override forwarded to
            ``make_agent_options``. When set (typically the ``clear_tool_uses``
            block from a soft reset), it takes precedence over the phase default.

    Returns:
        ``(success, issue_total, wall_seconds, compaction_events, clear_events)``
        where ``success`` is ``True`` if the issue was implemented,
        ``issue_total`` is the accumulated token usage across all attempts,
        ``wall_seconds`` is the total elapsed wall-clock time across all runner
        calls, and ``compaction_events`` / ``clear_events`` are the summed SDK
        lifecycle counters from each ``RunResult`` (issue #243).
    """
    repo = state.repo
    comments_section = get_or_fetch_comments(issue, repo, state, state_path, logger)  # type: ignore[arg-type]
    issue_total = TokenUsage()
    issue_wall = 0.0
    issue_compaction = 0
    issue_clear = 0
    last_err = ""
    mcp_tools = mcp_tool_wildcards(mcp_servers)
    for attempt in range(max_retries):
        if shared_client is None:
            # Non-negotiable #6: fresh session per attempt — never accumulate context.
            state.session_id = None
            _state.save_state(state_path, state)
        prompt = _build_prompt(issue, skills, comments_section, attempt, last_err)
        # Prepend soft-reset boundary on the first attempt only. Retries after
        # a failure stay within the same issue; no fresh reset needed.
        if attempt == 0 and boundary_prefix:
            prompt = boundary_prefix + prompt
        effort_level = _resolve_issue_effort(
            issue,
            effort_hints,
            attempt,
            complexity=state.mode,
            effective_model=effective_model,
        )
        options = make_agent_options(
            model=effective_model or _PHASE3_4_DEFAULT_MODEL,
            effort=effort_level,
            allowed_tools=[
                "Agent",
                "Read",
                "Edit",
                "Write",
                "Bash",
                "Glob",
                "Grep",
                "WebSearch",
                "WebFetch",
            ]
            + mcp_tools,
            cwd=str(project_dir),
            mcp_servers=mcp_servers,
            context_management_enabled=True,
            context_management=context_management if attempt == 0 else None,
            **max_turns_kwargs(max_turns),
        )
        try:
            if shared_client is not None:
                result = await _sdk_runner.run_with_shared_client(
                    shared_client,
                    prompt,
                    options,
                    logger=logger,
                    state_path=state_path,
                    pause_handler=pause_handler,
                    issue_number=issue.number,
                )
            else:
                result = await rate_limit.main_loop(
                    runner_module, prompt, options, state_path=state_path, logger=logger
                )
            issue_total += result.usage
            issue_wall += result.wall_seconds
            issue_compaction += result.compaction_events
            issue_clear += result.clear_events
            return True, issue_total, issue_wall, issue_compaction, issue_clear
        except (OverageAbort, RateLimitHit):
            # Non-negotiable: these must propagate immediately — never retry.
            raise
        except MaxTurnsExceeded:
            # Deterministic failure — retrying will hit the same ceiling.
            logger.error(
                "Phase 3/4: issue #%d hit max_turns ceiling at attempt %d/%d"
                " — no retry (deterministic failure).",
                issue.number,
                attempt + 1,
                max_retries,
            )
            with contextlib.suppress(Exception):
                _gh.add_label(repo, issue.number, "needs-manual-review")  # type: ignore[arg-type]
            break
        except Exception as exc:  # noqa: BLE001
            last_err = str(exc)
            logger.warning(
                "Phase 3/4: attempt %d/%d failed for issue #%d: %s",
                attempt + 1,
                max_retries,
                issue.number,
                last_err,
            )
    return False, issue_total, issue_wall, issue_compaction, issue_clear


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    max_retries: int = 3,
    shared_client: Any = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Execute phases 3 and 4: implementation loop.

    For each open issue delegates to ``_implement_single_issue`` which owns
    the per-issue retry loop.  On success the issue is marked ``closed`` in
    state; on failure an ERROR is logged and the issue is left open.

    When *shared_client* is provided (shared-session mode):

    - Each issue is implemented via ``run_with_shared_client()`` with
      ``context_management_enabled=True`` (compaction at 150 k tokens).
    - ``soft_reset_context()`` is awaited between every consecutive issue pair
      so the shared session starts each issue with a clean slate.

    When *shared_client* is ``None`` (fresh mode), ``rate_limit.main_loop``
    is used per issue; ``context_management_enabled=True`` still applies.

    Args:
        state: Root state object (mutated in place).
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
        max_retries: Maximum implementation retries per issue (default 3).
        shared_client: Open ``ClaudeSDKClient`` (or duck-typed equivalent)
            owned by the caller, or ``None`` in fresh-mode.
    """
    if logger is None:
        logger = setup_phase_logger("phase3_4", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"
    memories_dir = project_dir / ".code-generator" / "memories"
    skills = _default_skills(project_dir)
    effort_hints = cycle.effort_hints if cycle is not None else state.effort_hints
    phase_total = TokenUsage()
    phase_wall = 0.0
    phase_compaction = 0
    phase_clear = 0
    mcp_servers = build_mcp_servers(project_dir)
    # One handler instance per Phase 3/4 invocation owns the
    # pause_after_compaction "boundary pending" flag (issue #236). Single
    # roundtrip — the next outgoing prompt absorbs the boundary, no extra query.
    pause_handler = CompactionPauseHandler() if shared_client is not None else None

    prev_issue_ran = False
    for issue in _state.get_issues(state, cycle):
        if issue.status != "open":
            continue

        boundary_prefix = ""
        cm_block: dict | None = None
        if prev_issue_ran and shared_client is not None:
            if compaction_beta_available():
                # Server-side compaction (§6) handles tool-use clearing; the
                # soft-reset context_management overlay is redundant. Only the
                # boundary user-message text and current-issue.md reset remain.
                boundary_prefix = boundary_prefix_only(issue.number, memories_dir)
            else:
                reset = await _soft_reset_context(shared_client, issue.number, memories_dir)
                boundary_prefix = reset.boundary_prefix
                cm_block = reset.context_management

        agent = issue.agent or "python-pro"
        logger.info("Phase 3/4: implementing issue #%d (agent=%s).", issue.number, agent)
        (
            success,
            issue_usage,
            issue_wall,
            issue_compaction,
            issue_clear,
        ) = await _implement_single_issue(
            issue,
            state,
            state_path,
            skills,
            effort_hints,
            project_dir,
            runner_module,
            logger,
            max_retries,
            mcp_servers=mcp_servers,
            shared_client=shared_client,
            boundary_prefix=boundary_prefix,
            context_management=cm_block,
            max_turns=max_turns,
            pause_handler=pause_handler,
            effective_model=effective_model,
        )
        prev_issue_ran = True
        log_issue_usage(logger, "3/4", issue.number, issue_usage)
        phase_total += issue_usage
        phase_wall += issue_wall
        phase_compaction += issue_compaction
        phase_clear += issue_clear
        if success:
            issue.status = "closed"
            state.session_id = None
            _state.save_state(state_path, state)
            logger.info("Phase 3/4: issue #%d implemented (awaiting Phase 5 review).", issue.number)
        else:
            logger.error(
                "Phase 3/4: issue #%d could not be implemented after %d retries.",
                issue.number,
                max_retries,
            )

    target = cycle if cycle is not None else state
    target.token_usage["phase3_4"] = TokenUsage()
    accumulate_phase_telemetry(
        target.token_usage["phase3_4"],
        ttl=resolve_active_ttl(state, cycle, bp_index=3),
        usage=phase_total,
        compaction_delta=phase_compaction,
        clear_delta=phase_clear,
    )
    if isinstance(target, CycleState):
        accumulate_telemetry(target.cache_telemetry, phase_total, phase_wall)
    _state.save_state(state_path, state)
    log_phase_usage(logger, "3/4", target.token_usage["phase3_4"])
