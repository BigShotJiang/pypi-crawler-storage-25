"""Trace-rich failure report for Phase 6.5 → 6.6 (#282).

Replaces Cycle 1's minimal text block with a frozen :class:`FailureReport`
dataclass that carries the full execution trace consumed by the Phase
6.6 repair pass: command exit code, ordered stdout/stderr, HTTP
request/response exchange (T2), browser console + screenshot path (T3),
and container logs reach the model verbatim instead of being summarized
into a few hundred bytes of stderr tail.

The formatter omits any ``None`` or empty trace field so backend-only
runs keep the original Cycle-1 shape verbatim (regression-tested in
``test_when_legacy_tierresult_then_format_failure_report_matches_cycle1_shape``).

Persistence mirrors ``state.py::save_state`` and ``checklist.py``: a
sibling ``.tmp`` is written then ``os.replace``d into
``.code-generator/phase6_5_failure.txt`` — the path Cycle 1 already
references at ``phase6_5_verify.py`` line 580.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator.orchestrator.phase6_5_verify import TierResult


__all__ = [
    "FailureReport",
    "format_failure_report",
    "persist_failure_report",
]


_FAILURE_FILENAME = "phase6_5_failure.txt"
_HEADER = "PHASE 6.5 FAILURE REPORT\n========================\n"


@dataclass(frozen=True)
class FailureReport:
    """Structured Phase 6.5 failure payload — what the repair pass reads."""

    tier_id: str
    attempt: int
    max_retries: int
    skipped: bool
    exit_code: int | None
    failing_detail: str | None
    stderr_tail: str | None
    stdout_full: str | None
    http_request: str | None
    http_response: str | None
    browser_console: tuple[str, ...]
    screenshot_path: str | None

    @classmethod
    def from_tier_result(cls, result: TierResult, attempt: int, max_retries: int) -> FailureReport:
        """Project a :class:`TierResult` into a structured ``FailureReport``."""
        return cls(
            tier_id=result.tier_id,
            attempt=attempt,
            max_retries=max_retries,
            skipped=result.skipped,
            exit_code=result.exit_code,
            failing_detail=result.failing_detail,
            stderr_tail=result.stderr_tail,
            stdout_full=result.stdout_full,
            http_request=result.http_request,
            http_response=result.http_response,
            browser_console=tuple(result.browser_console),
            screenshot_path=result.screenshot_path,
        )


@dataclass(frozen=True)
class _Section:
    label: str
    value: object
    block: bool = False  # multi-line body emitted under the label
    always: bool = False  # render even when empty/None (Cycle-1 shape preservation)


def format_failure_report(report: FailureReport) -> str:
    """Render *report* as a labeled text block; ``None``/empty fields omitted.

    Cycle-1 fields (Attempt, Tier, Skipped, Exit code, Failing detail,
    Stderr tail) are always rendered to preserve the existing string
    shape consumed by the repair prompt; Cycle-2 trace fields are
    omitted when ``None`` or empty.
    """
    parts: list[str] = [_HEADER, f"Attempt {report.attempt} of {report.max_retries}\n"]
    for section in _ordered_sections(report):
        if not section.always and not _has_value(section.value):
            continue
        parts.append(_render_section(section))
    return "".join(parts)


def persist_failure_report(report: FailureReport, dot_dir: Path) -> Path:
    """Atomically persist *report* to ``<dot_dir>/phase6_5_failure.txt``."""
    target = dot_dir / _FAILURE_FILENAME
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = format_failure_report(report)
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(payload, encoding="utf-8")
    os.replace(tmp, target)
    return target


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ordered_sections(report: FailureReport) -> list[_Section]:
    return [
        _Section("Tier", report.tier_id, always=True),
        _Section("Skipped", str(report.skipped), always=True),
        _Section("Exit code", report.exit_code, always=True),
        _Section("Failing detail", report.failing_detail or "", always=True),
        _Section("Stderr tail", report.stderr_tail or "(none)", block=True, always=True),
        _Section("Stdout (full)", report.stdout_full, block=True),
        _Section("HTTP request", report.http_request, block=True),
        _Section("HTTP response", report.http_response, block=True),
        _Section("Browser console", report.browser_console, block=True),
        _Section("Screenshot", report.screenshot_path),
    ]


def _has_value(value: object) -> bool:
    if isinstance(value, tuple):
        return len(value) > 0
    return value is not None and value != ""


def _render_section(section: _Section) -> str:
    if section.block:
        body = _render_block_body(section.value)
        return f"{section.label}:\n{body}\n"
    return f"{section.label}: {section.value}\n"


def _render_block_body(value: object) -> str:
    if isinstance(value, tuple):
        return "\n".join(value)
    return str(value)
