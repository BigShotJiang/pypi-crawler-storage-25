"""Phase 8 CI + release YAML generators.

Pure functions — no subprocess, no git, no gh, no file writes. The
``finalization`` integration step is the sole writer; this module only
returns :class:`WorkflowFile` records describing what *should* exist.

Public surface:

- :data:`MANAGED_MARKER` — header comment string that distinguishes
  code-generator-managed workflows from user-authored ones. Upgrades
  only touch files carrying this marker.
- :class:`WorkflowFile` — frozen record with ``rel_path`` and
  ``content``. ``content is None`` signals "leave existing file
  untouched" (user-managed file present).
- :func:`detect_project_kind` — returns ``"python"``, ``"node"``, or
  ``"unknown"`` based on the presence of ``pyproject.toml`` /
  ``package.json``.
- :func:`generate_workflows` — returns the ci + release pair, honoring
  the upgrade rule.
- :func:`scan_for_guardrail_violations` — heuristic anti-gaming scanner
  reused by the local-verify gate.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from pathlib import Path

ProjectKind = Literal["python", "node", "unknown"]

MANAGED_MARKER = "code-generator-managed: true"

_CI_REL_PATH = ".github/workflows/ci.yml"
_RELEASE_REL_PATH = ".github/workflows/release.yml"


@dataclass(frozen=True)
class WorkflowFile:
    """A single workflow YAML target.

    Attributes:
        rel_path: Path relative to ``project_dir`` (always
            ``.github/workflows/<name>.yml``).
        content: YAML body to write, or ``None`` when an existing
            user-managed file must be left in place.
    """

    rel_path: str
    content: str | None


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------


def detect_project_kind(project_dir: Path) -> ProjectKind:
    """Classify the project at *project_dir* by manifest probing.

    ``pyproject.toml`` wins over ``package.json`` when both exist — the
    Python toolchain is more deterministic on CI, and Python-first
    projects routinely embed a frontend package.json that should not
    drive the workflow selection.
    """
    if (project_dir / "pyproject.toml").exists():
        return "python"
    if (project_dir / "package.json").exists():
        return "node"
    return "unknown"


# ---------------------------------------------------------------------------
# YAML bodies (string constants, not pyyaml-emitted)
# ---------------------------------------------------------------------------


def _ci_yaml(kind: ProjectKind) -> str:
    """Return the ci.yml body for *kind*, marker prepended."""
    body = _CI_BODIES[kind]
    return f"# {MANAGED_MARKER}\n{body}"


def _release_yaml(kind: ProjectKind) -> str:
    """Return the release.yml body for *kind*, marker prepended."""
    body = _RELEASE_BODIES[kind]
    return f"# {MANAGED_MARKER}\n{body}"


_CI_PYTHON = """\
name: ci
"on":
  push:
    branches: [main]
  pull_request:
    branches: [main]
jobs:
  ci:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: pip install -e .[dev]
      - run: ruff check src tests
      - run: pytest
"""

_CI_NODE = """\
name: ci
"on":
  push:
    branches: [main]
  pull_request:
    branches: [main]
jobs:
  ci:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci
      - run: npm run lint
      - run: npm test
"""

_CI_UNKNOWN = """\
name: ci
"on":
  push:
    branches: [main]
  pull_request:
    branches: [main]
jobs:
  ci:
    runs-on: ubuntu-latest
    steps:
      - run: echo "no project manifest detected; CI is a placeholder"
"""

_CI_BODIES: dict[ProjectKind, str] = {
    "python": _CI_PYTHON,
    "node": _CI_NODE,
    "unknown": _CI_UNKNOWN,
}

_RELEASE_PYTHON = """\
name: release
"on":
  push:
    tags: ['v*']
jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: pip install build
      - run: python -m build
"""

_RELEASE_NODE = """\
name: release
"on":
  push:
    tags: ['v*']
jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci
      - run: npm publish --provenance --access public
"""

_RELEASE_UNKNOWN = """\
name: release
"on":
  push:
    tags: ['v*']
jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - run: echo "no project manifest detected; release is a placeholder"
"""

_RELEASE_BODIES: dict[ProjectKind, str] = {
    "python": _RELEASE_PYTHON,
    "node": _RELEASE_NODE,
    "unknown": _RELEASE_UNKNOWN,
}


# ---------------------------------------------------------------------------
# generate_workflows
# ---------------------------------------------------------------------------


def generate_workflows(project_dir: Path) -> list[WorkflowFile]:
    """Return the ci + release :class:`WorkflowFile` records for *project_dir*.

    Honors the upgrade rule: any pre-existing target lacking
    :data:`MANAGED_MARKER` is preserved by setting ``content=None``.
    """
    kind = detect_project_kind(project_dir)
    return [
        _build_workflow(project_dir, _CI_REL_PATH, _ci_yaml(kind)),
        _build_workflow(project_dir, _RELEASE_REL_PATH, _release_yaml(kind)),
    ]


def _build_workflow(project_dir: Path, rel_path: str, fresh_content: str) -> WorkflowFile:
    """Return :class:`WorkflowFile` honoring the user-managed skip rule."""
    target = project_dir / rel_path
    if target.exists() and MANAGED_MARKER not in target.read_text(encoding="utf-8"):
        return WorkflowFile(rel_path=rel_path, content=None)
    return WorkflowFile(rel_path=rel_path, content=fresh_content)


# ---------------------------------------------------------------------------
# Guardrail scanner
# ---------------------------------------------------------------------------

_CONTINUE_ON_ERROR_TRUE = re.compile(r"continue-on-error\s*:\s*true", re.IGNORECASE)
_IF_FALSE = re.compile(r"\bif\s*:\s*false\b", re.IGNORECASE)

_TEST_STEP_PATTERNS = (
    "pytest",
    "npm test",
    "npm run test",
    "go test",
    "cargo test",
    "mvn test",
)
_LINT_STEP_PATTERNS = (
    "ruff",
    "flake8",
    "eslint",
    "npm run lint",
    "pylint",
    "biome",
)


def scan_for_guardrail_violations(workflow_yaml: str) -> list[str]:
    """Return labels naming anti-gaming violations in *workflow_yaml*.

    Heuristic (not a parse): pattern-matches on the raw YAML text. The
    same set of labels is reused by the local-verify gate so the two
    checks cannot drift.
    """
    violations: list[str] = []
    if _CONTINUE_ON_ERROR_TRUE.search(workflow_yaml):
        violations.append("continue-on-error")
    if _IF_FALSE.search(workflow_yaml):
        violations.append("if-false-skip")
    if not _has_any(workflow_yaml, _TEST_STEP_PATTERNS):
        violations.append("missing-test-step")
    if not _has_any(workflow_yaml, _LINT_STEP_PATTERNS):
        violations.append("missing-lint-step")
    return violations


def _has_any(text: str, needles: tuple[str, ...]) -> bool:
    """Case-insensitive substring check against any of *needles*."""
    lowered = text.lower()
    return any(n.lower() in lowered for n in needles)
