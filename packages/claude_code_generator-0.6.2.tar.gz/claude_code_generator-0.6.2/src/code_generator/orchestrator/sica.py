"""SICA — Self-Improved Coding Agent verifier context (#286).

Constructs a role-isolated *sub-context* inside the existing per-cycle
``ClaudeSDKClient``. Same client identity, same workspace, same
credentials (non-negotiable #6 and the cache-workspace invariants are
preserved) — but the verifier role is enforced through two layers:

1. A concise system-prompt prefix (``VERIFIER_ROLE_PREFIX``) appended
   to the canonical preset's ``append`` field. The model receives a
   strong signal that it must author its own boot/E2E scripts from the
   requirements rather than trust Phase 3/4 tool-use history.
2. The server-side ``clear_tool_uses_20250919`` directive in
   ``options.context_management``. Tool-use entries are truncated to
   the most recent six before the verifier turn, dropping the bulk of
   Phase 3/4 artifacts at the API boundary.

Nothing here opens a new ``ClaudeSDKClient`` — verified by a source
inspection test (``test_when_module_imported_then_no_claude_sdk_client_instantiation``).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from code_generator.runner.options import build_context_management_block, build_system_prompt
from code_generator.runner.sdk_runner import run_with_shared_client

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator.runner.types import RunResult


__all__ = [
    "VERIFIER_ROLE_PREFIX",
    "VerifierContext",
    "build_verifier_context",
]


_logger = logging.getLogger(__name__)


VERIFIER_ROLE_PREFIX = (
    "\n\n[VERIFIER ROLE — Phase 6.5]\n"
    "You are the runtime verifier, isolated from Phase 3/4 implementers. "
    "Author your own boot and end-to-end scripts directly from the "
    "requirements.md acceptance criteria. Do NOT trust prior tool-use "
    "history; do NOT assume any tests that ran in Phase 3/4 are correct. "
    "Verify the running artifact, not the codebase reasoning that produced it."
)


@dataclass(frozen=True)
class VerifierContext:
    """Role-isolated dispatcher bound to the shared per-cycle SDK client."""

    client: Any

    async def run(
        self,
        prompt: str,
        options: Any,
        *,
        logger: logging.Logger,
        state_path: Path,
    ) -> RunResult:
        """Dispatch *prompt* through the shared client with verifier-role isolation.

        Mutates *options* in-place to (a) append :data:`VERIFIER_ROLE_PREFIX`
        to the system-prompt's ``append`` field and (b) ensure the
        canonical context-management block (with
        ``clear_tool_uses_20250919``) is present. Same SDK client, same
        workspace — no second connection.
        """
        _inject_role_prefix(options)
        _ensure_clear_tool_uses(options)
        return await run_with_shared_client(
            self.client, prompt, options, logger=logger, state_path=state_path
        )


def build_verifier_context(shared_client: Any) -> VerifierContext:
    """Wrap *shared_client* in a :class:`VerifierContext` (no new connection)."""
    return VerifierContext(client=shared_client)


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _inject_role_prefix(options: Any) -> None:
    """Append :data:`VERIFIER_ROLE_PREFIX` to ``options.system_prompt``.

    Handles the three shapes ``make_agent_options`` may produce: the
    canonical ``build_system_prompt()`` dict (preset + ``append``), a
    raw string, or ``None``.
    """
    current = getattr(options, "system_prompt", None)
    if isinstance(current, dict):
        existing_append = current.get("append", "") or ""
        if VERIFIER_ROLE_PREFIX not in existing_append:
            current["append"] = existing_append + VERIFIER_ROLE_PREFIX
        return
    if isinstance(current, str):
        if VERIFIER_ROLE_PREFIX not in current:
            options.system_prompt = current + VERIFIER_ROLE_PREFIX
        return
    options.system_prompt = build_system_prompt(VERIFIER_ROLE_PREFIX)


def _ensure_clear_tool_uses(options: Any) -> None:
    """Ensure ``options.context_management`` carries ``clear_tool_uses_20250919``."""
    current = getattr(options, "context_management", None)
    if isinstance(current, dict) and _has_clear_tool_uses(current):
        return
    options.context_management = build_context_management_block()


def _has_clear_tool_uses(block: dict) -> bool:
    tools = block.get("tools", [])
    if not isinstance(tools, list):
        return False
    return any(
        isinstance(entry, dict) and entry.get("type") == "clear_tool_uses_20250919"
        for entry in tools
    )
