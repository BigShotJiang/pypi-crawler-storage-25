"""Phase 8 CI failure triage — transient vs permanent.

Pure heuristic classifier consumed by the Phase 8 repair loop. Pattern
table maps a regex to a :data:`FailureKind`; the first permanent match
wins, then transient, with a final ``"permanent"`` safe default so an
ambiguous failure never burns retry budget without progress.

A deterministic flap override kicks in when the last three CI
conclusions are all ``"failure"``: regardless of log patterns, the run
is classified ``"permanent"`` because the same flake has demonstrably
recurred and the repair agent should now intervene.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal

FailureKind = Literal["transient", "permanent"]

_FLAP_WINDOW = 3


@dataclass(frozen=True)
class ClassificationEvidence:
    """Normalized signal pulled from ``gh run view`` outputs.

    Attributes:
        failing_job_names: Names of jobs that finished with a non-success
            conclusion in the most recent run.
        log_excerpt: Tail-truncated text from ``gh run view --log-failed``.
        recent_conclusions: Prior run conclusions for the same workflow on
            the same branch, oldest first. The flap-override consults the
            tail of this list.
    """

    failing_job_names: list[str] = field(default_factory=list)
    log_excerpt: str = ""
    recent_conclusions: list[str] = field(default_factory=list)


_TRANSIENT_PATTERNS: tuple[re.Pattern[str], ...] = tuple(
    re.compile(p, re.IGNORECASE)
    for p in (
        r"rate limit",
        r"\b429\b",
        r"connection reset",
        r"\btimeout\b",
        r"timed out",
        r"npm ERR! network",
        r"pypi\.org",
        r"docker pull",
        r"registry returned 5\d\d",
    )
)

_PERMANENT_PATTERNS: tuple[re.Pattern[str], ...] = tuple(
    re.compile(p)
    for p in (
        r"SyntaxError",
        r"ModuleNotFoundError",
        r"TypeError",
        r"error TS\d+",
        r"\bFAILED\b",
        r"ESLint",
        r"\bruff\b",
        r"\bmypy\b",
    )
)


def classify(evidence: ClassificationEvidence) -> FailureKind:
    """Return ``"transient"`` or ``"permanent"`` for *evidence*.

    Precedence: flap-override > permanent patterns > transient
    patterns > safe default (``"permanent"``).
    """
    if _is_flapping(evidence.recent_conclusions):
        return "permanent"
    if _any_match(evidence.log_excerpt, _PERMANENT_PATTERNS):
        return "permanent"
    if _any_match(evidence.log_excerpt, _TRANSIENT_PATTERNS):
        return "transient"
    return "permanent"


def _is_flapping(conclusions: list[str]) -> bool:
    """Return ``True`` when the last :data:`_FLAP_WINDOW` runs all failed."""
    tail = conclusions[-_FLAP_WINDOW:]
    return len(tail) == _FLAP_WINDOW and all(c == "failure" for c in tail)


def _any_match(text: str, patterns: tuple[re.Pattern[str], ...]) -> bool:
    """Return ``True`` when *text* matches any compiled pattern."""
    return any(p.search(text) for p in patterns)
