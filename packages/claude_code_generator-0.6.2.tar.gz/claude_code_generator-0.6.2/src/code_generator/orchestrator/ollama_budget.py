"""Per-cycle safety backstop for the Ollama codepath.

The pre-0.4.11 design aborted cycles on two arbitrary counters — 200 turns
and 1 h wall-clock. That's the wrong layer: fault-detection already lives
in two places that trigger on real malfunctions, not on counters:

  * :class:`~code_generator.runner.retry.CircuitBreaker` — trips after ``N``
    consecutive failures on a single phase call. Already wrapped around
    Phase 2 (per-issue / batched review), Phase 3/4 (TDD implementation),
    and Phase 5 (closure).
  * :func:`~code_generator.runner.rate_limit.handle_ollama_429` —
    wait-and-resume on 429s returned by the Ollama daemon.

Starting with 0.4.13 both thresholds are **soft warnings** — the module
never aborts the pipeline. Weak open models are slow AND chatty; letting
them run is the right call. The operator can always Ctrl-C a runaway.

  * ``OLLAMA_SOFT_TURN_WARN``  (int, positive; default 500). Emitted once
    per cycle when cumulative ``num_turns`` crosses the threshold.
  * ``OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS``  (int, positive; default 14400).
    Emitted once per cycle when elapsed wall-clock crosses the threshold.

Backwards-compatible shims: the legacy env names ``OLLAMA_TURN_BUDGET`` and
``OLLAMA_WALLCLOCK_BUDGET_SECONDS`` remain honoured and map onto the new
soft-warn thresholds. Scripts that previously relied on the abort now see
a WARNING instead; the 0.4.11 changelog entry called this out for the turn
budget, and 0.4.13 extends the same semantics to wall-clock.

:class:`OllamaBudgetExceeded` is retained only as a concrete exception
type for backwards compatibility with callers that ``except`` it — it is
no longer raised by this module.

Nothing is persisted in ``state.json`` — the tracker is per-run and
discarded on clean completion.
"""

from __future__ import annotations

import logging
import os
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

    from code_generator.state import CycleState, State

_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Threshold constants
# ---------------------------------------------------------------------------

_DEFAULT_SOFT_TURN_WARN = 500
_DEFAULT_WALLCLOCK_SOFT_WARN_SECONDS = 14400  # 4 h


def _read_int_env(name: str, default: int) -> int:
    """Parse a positive int from the environment, falling back to *default*.

    Invalid values (empty, non-numeric, zero, or negative) are silently
    replaced with *default* — these are per-run tuning knobs, not safety
    gates, so noisy error handling would surprise operators who meant well.
    """
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if value > 0 else default


def _resolve_soft_turn_warn() -> int:
    """Honour the legacy ``OLLAMA_TURN_BUDGET`` env var for backwards compat."""
    legacy = _read_int_env("OLLAMA_TURN_BUDGET", 0)
    if legacy:
        return legacy
    return _read_int_env("OLLAMA_SOFT_TURN_WARN", _DEFAULT_SOFT_TURN_WARN)


OLLAMA_SOFT_TURN_WARN = _resolve_soft_turn_warn()
"""Soft warning threshold on per-cycle ``num_turns``.

Defaults to 500. Override via ``OLLAMA_SOFT_TURN_WARN`` (new name) or the
legacy ``OLLAMA_TURN_BUDGET`` (preserved for backwards compatibility). The
value is **non-blocking**: the pipeline only logs a WARNING once per cycle
when the cumulative turn count first crosses this threshold. It never
aborts.
"""

# Kept as a module-level alias so existing importers (tests, scripts) keep
# working. The semantics are now "soft warning threshold", not "abort".
OLLAMA_TURN_BUDGET = OLLAMA_SOFT_TURN_WARN
"""Backwards-compatible alias for :data:`OLLAMA_SOFT_TURN_WARN`."""


def _resolve_wallclock_soft_warn() -> int:
    """Honour legacy ``OLLAMA_WALLCLOCK_BUDGET_SECONDS`` env var for backwards compat."""
    legacy = _read_int_env("OLLAMA_WALLCLOCK_BUDGET_SECONDS", 0)
    if legacy:
        return legacy
    return _read_int_env("OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS", _DEFAULT_WALLCLOCK_SOFT_WARN_SECONDS)


OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS = _resolve_wallclock_soft_warn()
"""Soft warning threshold on per-cycle wall-clock elapsed (seconds).

Defaults to 14400 (4 h). Override via ``OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS``
(new name) or the legacy ``OLLAMA_WALLCLOCK_BUDGET_SECONDS`` (preserved for
backwards compatibility). The value is **non-blocking**: the pipeline only
logs a WARNING once per cycle when elapsed first crosses this threshold.
It never aborts.
"""

# Kept as a module-level alias so existing importers (tests, scripts) keep
# working. The semantics are now "soft warning threshold", not "abort".
OLLAMA_WALLCLOCK_BUDGET_SECONDS = OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS
"""Backwards-compatible alias for :data:`OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS`."""


# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------


class OllamaBudgetExceeded(RuntimeError):
    """Retained only for backwards compatibility with ``except`` clauses.

    As of 0.4.13 this module never raises ``OllamaBudgetExceeded``. Both the
    turn counter and the wall-clock are non-blocking soft WARNINGs. Real
    per-call failures are handled by the ``CircuitBreaker`` in
    :mod:`code_generator.runner.retry`.

    Subclasses ``RuntimeError`` to match the existing safety-abort hierarchy
    (e.g. :class:`~code_generator.runner.types.OverageAbort`).
    """


# ---------------------------------------------------------------------------
# Tracker
# ---------------------------------------------------------------------------


class OllamaBudgetTracker:
    """Adaptive per-cycle safety backstop; a no-op on the Anthropic Max path.

    Emits at most one WARNING per threshold (turn count, wall-clock). **Never
    aborts**. Real failures are the responsibility of
    :class:`~code_generator.runner.retry.CircuitBreaker` and the rate-limit
    handlers in :mod:`code_generator.runner.rate_limit`.
    """

    def __init__(
        self,
        *,
        provider_is_ollama: bool,
        clock: Callable[[], float] | None = None,
    ) -> None:
        """Initialise a tracker; call :meth:`start` at cycle kickoff.

        Args:
            provider_is_ollama: When False every :meth:`check` call is a
                no-op so the Anthropic Max path stays byte-for-byte unchanged.
            clock: Injectable monotonic clock for deterministic tests;
                defaults to ``time.monotonic``.
        """
        self._active = provider_is_ollama
        self._clock = clock or time.monotonic
        self._start_time: float | None = None
        self._turn_warning_emitted = False
        self._wallclock_warning_emitted = False

    def start(self) -> None:
        """Record the cycle start time. Idempotent; only the first call matters."""
        if self._active and self._start_time is None:
            self._start_time = self._clock()

    def check(self, state: State, cycle: CycleState | None) -> None:
        """Warn on either threshold; never raise."""
        if not self._active:
            return
        self._check_turn_soft_warn(state, cycle)
        self._check_wallclock_soft_warn()

    def _check_turn_soft_warn(self, state: State, cycle: CycleState | None) -> None:
        """Emit one WARNING the first time the cycle crosses the soft threshold.

        Never raises. Subsequent checks in the same cycle are no-ops because
        the warning flag is sticky until the tracker is discarded.
        """
        if self._turn_warning_emitted:
            return
        total = _sum_num_turns(state, cycle)
        if total > OLLAMA_SOFT_TURN_WARN:
            _logger.warning(
                "Ollama cycle has consumed %d turns (soft threshold: %d). "
                "Letting it run — real failures are caught by the per-phase "
                "CircuitBreaker in runner/retry.py. Raise the threshold via "
                "OLLAMA_SOFT_TURN_WARN or the legacy OLLAMA_TURN_BUDGET env "
                "var to silence this warning.",
                total,
                OLLAMA_SOFT_TURN_WARN,
            )
            self._turn_warning_emitted = True

    def _check_wallclock_soft_warn(self) -> None:
        """Emit one WARNING the first time the cycle crosses the wall-clock threshold.

        Never raises. As of 0.4.13 the wall-clock ceiling is advisory: a
        genuinely stuck daemon will be caught by the per-phase
        CircuitBreaker or by the operator's Ctrl-C; aborting a live session
        on a counter wastes hours of work.
        """
        if self._wallclock_warning_emitted or self._start_time is None:
            return
        elapsed = self._clock() - self._start_time
        if elapsed > OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS:
            _logger.warning(
                "Ollama cycle has been running for %.0fs (soft threshold: "
                "%ds). Letting it run — real stalls are caught by the "
                "per-phase CircuitBreaker in runner/retry.py. Raise the "
                "threshold via OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS or the "
                "legacy OLLAMA_WALLCLOCK_BUDGET_SECONDS env var to silence "
                "this warning. Use Ctrl-C to stop a truly runaway cycle.",
                elapsed,
                OLLAMA_WALLCLOCK_SOFT_WARN_SECONDS,
            )
            self._wallclock_warning_emitted = True


def _sum_num_turns(state: State, cycle: CycleState | None) -> int:
    """Sum ``num_turns`` across every phase of the active cycle (or state)."""
    source = cycle.token_usage if cycle is not None else state.token_usage
    return sum(usage.num_turns for usage in source.values())
