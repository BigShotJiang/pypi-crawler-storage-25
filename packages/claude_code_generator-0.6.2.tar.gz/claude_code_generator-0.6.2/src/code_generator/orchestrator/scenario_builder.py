"""Functional scenario builder for Phase 6.5 (#285).

Groups oracle-mapped criteria into named, business-outcome
:class:`Scenario` objects keyed on the ``### N.`` Scope subsection. T2
and T3 consume scenario groups instead of isolated per-endpoint checks.

Each scenario carries:

- ``name`` — the subsection heading text (e.g. ``"User Registration"``).
- ``section_index`` — the ``N`` from ``### N. Title``.
- ``criteria`` — every :class:`CriterionMapping` parsed for that section
  (verifiable or not).
- ``t2_endpoints`` — backticked endpoint strings extracted from
  ``tier=\"T2\"`` criteria. Drives :func:`run_t2_api` per scenario.
- ``t3_flows`` — the human-readable criterion text of ``tier=\"T3\"``
  criteria. Drives :func:`run_t3_browser` scenarios.

The signature accepts the raw ``requirements_text`` rather than the
pre-parsed list hinted in the issue notes — callers (Phase 6.5
orchestrator, tests) already have the full text and would otherwise
duplicate the ``### N.`` regex split.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

from code_generator.requirements_structure import _NUMBERED_SECTION_RE, _SCOPE_BODY_RE

if TYPE_CHECKING:
    from code_generator.orchestrator.criteria_oracle import CriterionMapping, OracleReport

__all__ = ["Scenario", "build_scenarios"]


@dataclass(frozen=True)
class Scenario:
    """Business-outcome scenario aggregating one ``### N.`` Scope subsection."""

    name: str
    section_index: int
    criteria: tuple[CriterionMapping, ...]
    t2_endpoints: tuple[str, ...]
    t3_flows: tuple[str, ...]


_SECTION_HEADER_RE = re.compile(r"^###\s+(?P<index>\d+)\.\s+(?P<name>.+?)\s*$", re.MULTILINE)
_AC_BLOCK_RE = re.compile(
    r"^[ \t]*Acceptance criteria[ \t]*\n(.*?)(?=^### |\Z)",
    re.MULTILINE | re.DOTALL | re.IGNORECASE,
)
_CHECKBOX_BULLET_RE = re.compile(r"^\s*-\s*\[[ xX]\]\s+(.*)$", re.MULTILINE)
_BACKTICK_ENDPOINT_RE = re.compile(
    r"`(?:(?P<method>GET|POST|PUT|PATCH|DELETE)\s+)?(?P<path>/[A-Za-z0-9/_{}\-]+)`"
)


def build_scenarios(report: OracleReport, requirements_text: str) -> list[Scenario]:
    """Return one :class:`Scenario` per ``### N.`` Scope subsection.

    Pure — performs no I/O.
    """
    scope = _SCOPE_BODY_RE.search(requirements_text)
    if scope is None:
        return []

    by_text = {c.text: c for c in report.scope_criteria}
    scenarios: list[Scenario] = []
    for section_text in _NUMBERED_SECTION_RE.findall(scope.group(1)):
        scenario = _scenario_from_section(section_text, by_text)
        if scenario is not None:
            scenarios.append(scenario)
    return scenarios


def _scenario_from_section(
    section_text: str, by_text: dict[str, CriterionMapping]
) -> Scenario | None:
    header = _SECTION_HEADER_RE.search(section_text)
    if header is None:
        return None

    criteria = _criteria_for_section(section_text, by_text)
    return Scenario(
        name=header.group("name").strip(),
        section_index=int(header.group("index")),
        criteria=criteria,
        t2_endpoints=tuple(_t2_endpoints_from(criteria)),
        t3_flows=tuple(c.text for c in criteria if c.tier == "T3" and c.verifiable),
    )


def _criteria_for_section(
    section_text: str, by_text: dict[str, CriterionMapping]
) -> tuple[CriterionMapping, ...]:
    bullets: list[CriterionMapping] = []
    for ac_block in _AC_BLOCK_RE.findall(section_text):
        for match in _CHECKBOX_BULLET_RE.finditer(ac_block):
            text = match.group(1).strip()
            mapping = by_text.get(text)
            if mapping is not None:
                bullets.append(mapping)
    return tuple(bullets)


def _t2_endpoints_from(criteria: tuple[CriterionMapping, ...]) -> list[str]:
    endpoints: list[str] = []
    seen: set[str] = set()
    for criterion in criteria:
        if criterion.tier != "T2" or not criterion.verifiable:
            continue
        for token in _BACKTICK_ENDPOINT_RE.finditer(criterion.text):
            method = token.group("method") or "GET"
            label = f"{method} {token.group('path')}"
            if label not in seen:
                seen.add(label)
                endpoints.append(label)
    return endpoints
