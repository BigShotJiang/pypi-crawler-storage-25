"""T3 browser E2E tier for Phase 6.5 (#284).

Drives the running app through the Playwright MCP server, executes
acceptance scenarios derived from the oracle (#280), and captures a
screenshot + browser-console snapshot on failure. Synchronous executor
matching T0/T1/T2/T4; the MCP session is acquired via a factory seam
so tests can inject a fake without a real Playwright binary.

Skip semantics
--------------
- No scenarios in scope → ``skipped=True``.
- Playwright MCP binary not on ``$PATH`` → ``skipped=True`` (logged WARNING).

Cache-workspace invariant #2 is preserved by routing the sanitized
``env`` (produced by ``code_generator.env.build_agent_env``) into the
MCP factory, never letting Anthropic credentials reach the browser
subprocess.
"""

from __future__ import annotations

import logging
import math
import shutil
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol

from code_generator.orchestrator.phase6_5_verify import TierResult, _skip

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence
    from pathlib import Path
    from types import TracebackType

    from code_generator.orchestrator.agent_spec import TierConfig


__all__ = [
    "PlaywrightMcpSession",
    "Scenario",
    "ScenarioFailure",
    "run_t3_browser",
]


_logger = logging.getLogger(__name__)

_PLAYWRIGHT_BIN = "playwright-mcp"
_SCREENSHOT_FILENAME = "phase65-t3-failure.png"


@dataclass(frozen=True)
class Scenario:
    """Single acceptance scenario for the T3 browser tier."""

    name: str
    steps: tuple[str, ...]
    description: str | None = None


@dataclass(frozen=True)
class ScenarioFailure:
    """Structured outcome of a failed scenario execution."""

    detail: str
    extras: dict[str, str] = field(default_factory=dict)


class PlaywrightMcpSession(Protocol):
    """Context-managed Playwright MCP session interface (factory seam)."""

    def __enter__(self) -> PlaywrightMcpSession: ...

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None: ...

    def run_scenario(self, scenario: Scenario) -> ScenarioFailure | None: ...

    def screenshot(self, path: str) -> None: ...

    def console_messages(self) -> list[str]: ...


class _SessionFactory(Protocol):
    def __call__(self, *, env: Mapping[str, str], base_url: str) -> PlaywrightMcpSession: ...


def run_t3_browser(
    project_dir: Path,
    *,
    env: Mapping[str, str],
    base_url: str,
    scenarios: Sequence[Scenario],
    screenshot_dir: Path | None = None,
    mcp_factory: _SessionFactory | None = None,
    tier_config: TierConfig | None = None,
) -> TierResult:
    """Run the T3 browser E2E tier. See module docstring for skip rules.

    With *tier_config* the executor runs scenarios ``tier_config.runs`` times
    and gates the tier on ``passed_runs / runs >= tier_config.pass_rate_threshold``
    (floor-style — required passes are ``floor(threshold * runs)``). Without
    *tier_config* the executor runs once at 100% threshold, matching legacy
    callers.
    """
    if not scenarios:
        return _skip("T3", "no acceptance scenarios in scope")
    if mcp_factory is None and not _playwright_on_path():
        _logger.warning("T3: playwright-mcp binary not on PATH; skipping browser tier")
        return _skip("T3", "playwright-mcp binary not on PATH")

    runs, threshold = _resolve_runs_threshold(tier_config)
    screenshots_root = _resolve_screenshot_dir(project_dir, screenshot_dir)
    factory = mcp_factory if mcp_factory is not None else _default_factory()

    with factory(env=env, base_url=base_url) as session:
        failure = _execute_scenarios_multi_run(session, scenarios, runs=runs, threshold=threshold)
        if failure is None:
            return _pass_result()
        return _fail_result(session, failure, screenshots_root)


def _resolve_runs_threshold(tier_config: TierConfig | None) -> tuple[int, float]:
    if tier_config is None:
        return 1, 1.0
    return tier_config.runs, tier_config.pass_rate_threshold


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _playwright_on_path() -> bool:
    try:
        return shutil.which(_PLAYWRIGHT_BIN) is not None
    except OSError:
        return False


def _resolve_screenshot_dir(project_dir: Path, override: Path | None) -> Path:
    target = override if override is not None else project_dir / ".code-generator" / "screenshots"
    target.mkdir(parents=True, exist_ok=True)
    return target


def _execute_scenarios(
    session: PlaywrightMcpSession, scenarios: Sequence[Scenario]
) -> tuple[Scenario, ScenarioFailure] | None:
    for scenario in scenarios:
        failure = session.run_scenario(scenario)
        if failure is not None:
            return scenario, failure
    return None


def _execute_scenarios_multi_run(
    session: PlaywrightMcpSession,
    scenarios: Sequence[Scenario],
    *,
    runs: int,
    threshold: float,
) -> tuple[Scenario, ScenarioFailure] | None:
    """Run *scenarios* ``runs`` times; return last failure unless pass-rate met."""
    passed_runs = 0
    last_failure: tuple[Scenario, ScenarioFailure] | None = None
    for _ in range(runs):
        failure = _execute_scenarios(session, scenarios)
        if failure is None:
            passed_runs += 1
        else:
            last_failure = failure
    if _passes_threshold(passed_runs, runs, threshold):
        return None
    return last_failure


def _passes_threshold(passed_runs: int, runs: int, threshold: float) -> bool:
    """Floor-style pass-rate gate (#292).

    ``required = floor(threshold * runs)`` so threshold=0.67 with 3 runs
    needs 2 passes (matching the natural "two-thirds" reading); strict
    threshold=1.0 still requires every run to pass.
    """
    if runs <= 0:
        return True
    return passed_runs >= math.floor(threshold * runs)


def _pass_result() -> TierResult:
    return TierResult(
        tier_id="T3",
        passed=True,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=None,
        failing_detail=None,
    )


def _fail_result(
    session: PlaywrightMcpSession,
    failure: tuple[Scenario, ScenarioFailure],
    screenshots_root: Path,
) -> TierResult:
    scenario, scenario_failure = failure
    screenshot_path = str(screenshots_root / _SCREENSHOT_FILENAME)
    session.screenshot(screenshot_path)
    console = list(session.console_messages())
    return TierResult(
        tier_id="T3",
        passed=False,
        skipped=False,
        skip_reason=None,
        exit_code=None,
        stderr_tail=None,
        failing_detail=f"scenario {scenario.name!r} failed: {scenario_failure.detail}",
        browser_console=console,
        screenshot_path=screenshot_path,
    )


def _default_factory() -> _SessionFactory:
    """Return the production MCP factory (raises until wired to the SDK)."""
    from code_generator.runner.mcp import build_playwright_server_config

    config = build_playwright_server_config()
    if config is None:
        raise RuntimeError("playwright-mcp config unavailable at runtime")

    def _factory(*, env: Mapping[str, str], base_url: str) -> PlaywrightMcpSession:
        del env, base_url  # SDK wiring lands in a follow-up — tests inject a fake
        raise NotImplementedError(
            "Production Playwright MCP session not yet wired — pass mcp_factory explicitly"
        )

    return _factory
