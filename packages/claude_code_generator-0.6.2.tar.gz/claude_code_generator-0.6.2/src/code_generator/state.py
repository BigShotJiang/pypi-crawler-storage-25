"""Atomic state persistence for the code-generator orchestrator.

State is serialized to JSON and written via a tmp-file + os.replace() pattern
so a crash mid-write cannot corrupt the existing state file.

Non-negotiables #5 (wait-and-resume) and #7 (atomic writes).
"""

import dataclasses
import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from code_generator.repo_info import RepoInfo
from code_generator.runner.types import TokenUsage
from code_generator.state_retention import CycleTelemetrySummary, truncate_old_cycles

# Sentinel used by helper functions that don't yet know the state file path.
# load_state() catches StateCorruptedError and attaches the real path before re-raising.
_SENTINEL_PATH = Path("")

# Valid values for State.session_mode.
_VALID_SESSION_MODES: frozenset[str] = frozenset({"shared", "fresh", "batch"})

# Valid TTL probe outcomes (#245). ``None`` is also accepted by callers to
# represent "probe not yet run / pre-Cycle-4 state.json".
_VALID_TTL_PROBES: frozenset[str] = frozenset({"1h", "5m"})


def _default_cache_telemetry() -> dict[str, int | float]:
    """Return a fresh canonical cache-telemetry dict with all counters zeroed.

    Returns:
        Dict with keys ``input``, ``output``, ``cache_read``, ``cache_write``,
        ``cache_hit_pct`` (float), and ``wall_seconds`` all set to zero.
    """
    return {
        "input": 0,
        "output": 0,
        "cache_read": 0,
        "cache_write": 0,
        "cache_hit_pct": 0.0,
        "wall_seconds": 0,
    }


class StateCorruptedError(Exception):
    """Raised when state.json fails post-parse schema validation.

    Attributes:
        path: Path to the state.json file (attached by load_state).
        location: JSON path of the corrupt value (e.g. ``cycles[0].issues[2]``).
        reason: Human-readable description of the schema violation.
    """

    def __init__(self, *, path: Path, location: str, reason: str) -> None:
        self.path = path
        self.location = location
        self.reason = reason
        super().__init__(f"state.json corrupted at {location}: {reason}")


@dataclass
class IssueState:
    """Lightweight record for a single GitHub issue within a phase."""

    number: int
    status: Literal["open", "closed"]
    agent: str
    labels: list[str] = field(default_factory=list)
    reviewed: bool = False
    comments: str | None = None
    title: str = ""


@dataclass
class Phase65Progress:
    """Persisted progress for Phase 6.5 (runtime verification, #269).

    Captures the repair-loop attempt counter and per-tier outcomes so that
    ``--continue`` can resume mid-phase and ``code-generator status`` can
    surface the per-tier verdict without reading the model transcript.
    """

    attempt: int = 0
    last_tier: str | None = None
    tiers_passed: list[str] = field(default_factory=list)
    tiers_failed: list[str] = field(default_factory=list)
    tiers_skipped: list[str] = field(default_factory=list)
    skip_reasons: dict[str, str] = field(default_factory=dict)


@dataclass
class Phase8Progress:
    """Persisted progress for Phase 8 (project finalization, #299).

    Cycle 1 seeded the attempt + status + timestamp fields. Cycle 3 (#319)
    appends the CI green-gate fields below with backward-compatible defaults
    so legacy state.json files still load via ``_phase8_from_dict``.
    """

    attempt: int = 0
    status: str | None = None
    started_at: str | None = None
    finished_at: str | None = None
    # Cycle 3 (#319) — CI green-gate outcome surface.
    ci_status: str | None = None
    ci_run_id: int | None = None
    repair_attempts: int = 0
    workflow_files_written: list[str] = field(default_factory=list)


@dataclass
class EffortHint:
    """Advisory effort hint emitted by Phase 0 for a class of issues.

    ``scope_keyword`` is a short descriptor (e.g. "database migration") that
    Phase 3/4 can match against issue titles or labels.  ``effort`` is one of
    ``"low"``, ``"medium"``, or ``"high"`` — ``"max"`` is deliberately excluded
    as it is gated to Opus-only phases.
    """

    scope_keyword: str
    effort: Literal["low", "medium", "high"]


@dataclass
class CycleState:
    """State for one generation cycle (maps 1-to-1 with a GitHub Milestone)."""

    id: int
    name: str
    milestone_number: int | None
    milestone_title: str
    status: str
    phase: int | None
    issues: list[IssueState]
    commit_sha: str | None
    depends_on: list[int] = field(default_factory=list)
    scope: str = ""
    effort_hints: list[EffortHint] = field(default_factory=list)
    base_commit: str | None = None
    token_usage: dict[str, TokenUsage] = field(default_factory=dict)
    started_at: str | None = None
    finished_at: str | None = None
    # TODO: §16 — populate from runner UsageEvent cache counters after each phase run.
    cache_telemetry: dict[str, int | float] = field(default_factory=_default_cache_telemetry)
    phase2_batch_id: str | None = None
    # Ollama model tag used for this cycle (#217). None on the Anthropic Max
    # path; populated by ``generate ollama --model <tag>`` so ``--continue``
    # can resume without the operator re-supplying the flag. Always serialized
    # (dataclasses.asdict) — pre-#217 state.json files lack the key and
    # deserialize to None via ``.get("ollama_model")``.
    ollama_model: str | None = None
    # Gemini model tag used for this cycle.
    gemini_model: str | None = None
    # Codex model tag used for this cycle.
    codex_model: str | None = None
    # §12 cache pre-warm idempotency flag (#241). Flipped to True after the
    # once-per-cycle ``max_tokens=0`` no-op succeeds; ``--continue`` reads it
    # so a resumed cycle does not re-fire the pre-warm.
    cache_prewarmed: bool = False
    # §9 active TTL probe outcome (#245). Written once per cycle by
    # ``managed_shared_client`` so ``--continue`` and per-phase telemetry
    # attribution honour the same TTL layout. ``None`` on legacy state.json
    # files; downstream callers fall back to ``"1h"``.
    cache_ttl_probe: Literal["1h", "5m"] | None = None
    # Phase 6.5 (runtime verification) repair-loop progress (#269). ``None``
    # on legacy state.json files and on cycles that have not yet entered
    # Phase 6.5; populated by the phase module via atomic save_state.
    phase6_5: Phase65Progress | None = None
    # VIGIL overseer flag (#287). Set True when the Phase 4 → 6.5 boundary
    # check detects a premature "done" (all issues closed, boot probe red)
    # and forces Phase 6.5 re-entry instead of allowing Phase 7 to commit.
    vigil_triggered: bool = False
    # Phase 8 (project finalization) progress (#299). ``None`` on legacy
    # state.json files and on cycles that have not yet entered Phase 8;
    # populated by the phase module via atomic save_state.
    phase8: Phase8Progress | None = None


@dataclass
class State:
    """Root state object persisted to .code-generator/state.json."""

    mode: Literal["single", "multi-cycle", "unknown"]
    started_at: str
    updated_at: str
    current_cycle: int | None = None
    cycles: list[CycleState | CycleTelemetrySummary] = field(default_factory=list)
    phase: int | None = None
    issues: list[IssueState] = field(default_factory=list)
    session_id: str | None = None
    paused_until: int | None = None
    rate_limit_type: str | None = None
    last_error: str | None = None
    effort_hints: list[EffortHint] = field(default_factory=list)
    requirements_hash: str | None = None
    base_commit: str | None = None
    token_usage: dict[str, TokenUsage] = field(default_factory=dict)
    session_mode: Literal["shared", "fresh", "batch"] = "shared"
    client_alive_at: str | None = None
    phase2_batch_id: str | None = None
    repo: RepoInfo | None = None
    prompt_hashes: dict[str, str] = field(default_factory=dict)
    sdk_version: str | None = None
    # Gemini model tag used for single-mode runs.
    gemini_model: str | None = None
    # Codex model tag used for single-mode runs.
    codex_model: str | None = None
    # §12 cache pre-warm idempotency flag for single-mode runs (#241).
    cache_prewarmed: bool = False
    # §9 active TTL probe outcome for single-mode runs (#245).
    cache_ttl_probe: Literal["1h", "5m"] | None = None
    # Phase 6.5 (runtime verification) progress for single-mode runs (#269).
    phase6_5: Phase65Progress | None = None
    # VIGIL overseer flag for single-mode runs (#287).
    vigil_triggered: bool = False
    # Phase 8 (project finalization) progress for single-mode runs (#299).
    phase8: Phase8Progress | None = None


def utc_now_isoformat() -> str:
    """Return the current UTC time as an ISO 8601 string with seconds precision.

    Uses ``datetime.isoformat(timespec="seconds")`` for deterministic formatting
    (no sub-second noise, explicit UTC offset).

    Returns:
        ISO 8601 string, e.g. ``"2026-04-17T10:00:00+00:00"``.
    """
    return datetime.now(tz=UTC).isoformat(timespec="seconds")


def mark_client_alive(state: State, state_path: Path) -> None:
    """Set client_alive_at to the current UTC time and atomically persist state.

    Call this just before each ``client.query()`` invocation so the crash-recovery
    FSM can detect stale sessions on ``--continue``.

    Args:
        state: State to mutate.
        state_path: Destination for the atomic state write.
    """
    state.client_alive_at = utc_now_isoformat()
    save_state(state_path, state)


def clear_client_alive(state: State, state_path: Path) -> None:
    """Set client_alive_at to None and atomically persist state.

    Call this on clean client close so ``--continue`` does not see a stale session.

    Args:
        state: State to mutate.
        state_path: Destination for the atomic state write.
    """
    state.client_alive_at = None
    save_state(state_path, state)


def is_client_presumed_alive(
    state: State,
    now_utc: "datetime | None" = None,
    *,
    ttl_minutes: int = 60,
) -> bool:
    """Return True iff client_alive_at exists and is within the TTL window.

    Args:
        state: State to inspect.
        now_utc: Override for the current UTC time (timezone-aware ``datetime``).
            Defaults to ``datetime.now(tz=UTC)`` when omitted.
        ttl_minutes: Age threshold in minutes (exclusive upper bound). Default 60.

    Returns:
        ``True`` if ``client_alive_at`` is set and the elapsed time is strictly
        less than ``ttl_minutes``; ``False`` otherwise.

    Raises:
        StateCorruptedError: When ``client_alive_at`` is not a valid ISO 8601 string.
    """
    if state.client_alive_at is None:
        return False
    try:
        alive_at = datetime.fromisoformat(state.client_alive_at)
    except ValueError as exc:
        raise StateCorruptedError(
            path=_SENTINEL_PATH,
            location="client_alive_at",
            reason=f"not a valid ISO 8601 string: {state.client_alive_at!r}",
        ) from exc
    reference = now_utc if now_utc is not None else datetime.now(tz=UTC)
    elapsed_minutes = (reference - alive_at).total_seconds() / 60
    return elapsed_minutes < ttl_minutes


def assert_session_mode_compatible(
    state: State,
    requested: "Literal['shared', 'fresh', 'batch']",
) -> None:
    """Raise ValueError if the stored session_mode conflicts with the requested mode.

    Full pairwise rejection matrix:
    - stored=fresh,  requested!=fresh  → raise
    - stored=batch,  requested!=batch  → raise
    - stored=shared, requested=batch   → raise
    - All other combinations           → OK (including shared→fresh one-way guard)

    Args:
        state: State to inspect.
        requested: The session mode the caller wants to use.

    Raises:
        ValueError: On any incompatible mode combination.
            The message matches the stored mode byte-for-byte so the downstream
            CLI guard can match it reliably.
    """
    if state.session_mode == "fresh" and requested != "fresh":
        raise ValueError(
            "State mode mismatch: state.json was written with --session-mode=fresh; "
            "re-run with that flag or clear state."
        )
    if state.session_mode == "batch" and requested != "batch":
        raise ValueError(
            "State mode mismatch: state.json was written with --session-mode=batch; "
            "re-run with that flag or clear state."
        )
    if state.session_mode == "shared" and requested == "batch":
        raise ValueError(
            "State mode mismatch: state.json was written with --session-mode=shared; "
            "re-run with that flag or clear state."
        )


def compute_requirements_hash(path: Path) -> str:
    """Return the SHA-256 hex digest of the UTF-8 encoded contents of path.

    Args:
        path: Path to the requirements file to hash.

    Returns:
        Lowercase hex-encoded SHA-256 digest (64 characters).
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc_now() -> str:
    """Return the current UTC time as an ISO 8601 string with ``Z`` suffix."""
    return datetime.now(tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


# Keep internal alias so existing call sites using the underscore name still work.
_utc_now = utc_now


def _issue_from_dict(d: Any, index: int = 0, location_prefix: str = "issues") -> IssueState:
    location = f"{location_prefix}[{index}]"
    if not isinstance(d, dict):
        raise StateCorruptedError(
            path=_SENTINEL_PATH,
            location=location,
            reason=f"expected dict, got {type(d).__name__}",
        )
    try:
        return IssueState(
            number=d["number"],
            status=d["status"],
            agent=d["agent"],
            labels=d.get("labels", []),
            reviewed=d.get("reviewed", False),
            comments=d.get("comments"),
            title=d.get("title", ""),
        )
    except KeyError as exc:
        raise StateCorruptedError(
            path=_SENTINEL_PATH,
            location=location,
            reason=f"missing required key {exc}",
        ) from exc


def _effort_hint_from_dict(d: dict) -> EffortHint:  # type: ignore[type-arg]
    return EffortHint(scope_keyword=d["scope_keyword"], effort=d["effort"])  # type: ignore[arg-type]


def _token_usage_from_dict(raw: dict) -> dict[str, TokenUsage]:  # type: ignore[type-arg]
    """Deserialize a raw token_usage dict to ``dict[str, TokenUsage]``.

    Each value is expected to be a dict with the token counter keys and the
    optional ``num_turns`` plus the Cycle 4 fields. Missing keys default to 0,
    matching ``TokenUsage`` field defaults — this keeps pre-0.3.1 state.json
    files (without ``num_turns``) and pre-Cycle-4 state.json files (without
    ``cache_write_5m`` / ``cache_write_1h`` / ``compaction_events`` /
    ``clear_events``) loadable without raising.

    Args:
        raw: Mapping of phase id → token counter dict (e.g. from JSON).

    Returns:
        Mapping of phase id → ``TokenUsage`` instances.
    """
    return {
        phase: TokenUsage(
            input=v.get("input", 0),
            output=v.get("output", 0),
            cache_read=v.get("cache_read", 0),
            cache_write=v.get("cache_write", 0),
            num_turns=v.get("num_turns", 0),
            cache_write_5m=v.get("cache_write_5m", 0),
            cache_write_1h=v.get("cache_write_1h", 0),
            compaction_events=v.get("compaction_events", 0),
            clear_events=v.get("clear_events", 0),
        )
        for phase, v in raw.items()
    }


def _phase6_5_from_dict(raw: Any) -> "Phase65Progress | None":
    """Reconstruct a :class:`Phase65Progress` from a deserialized JSON value.

    Returns ``None`` when *raw* is ``None`` or missing — this is the path
    pre-#269 state.json files take so they keep loading after the upgrade.
    Missing keys inside *raw* fall back to the dataclass field defaults.

    Args:
        raw: Value read from ``state.json`` (``None`` or a dict).

    Returns:
        ``None`` when *raw* is ``None``; otherwise a populated
        :class:`Phase65Progress` instance with defaults filling missing keys.
    """
    if raw is None:
        return None
    return Phase65Progress(
        attempt=raw.get("attempt", 0),
        last_tier=raw.get("last_tier"),
        tiers_passed=list(raw.get("tiers_passed", [])),
        tiers_failed=list(raw.get("tiers_failed", [])),
        tiers_skipped=list(raw.get("tiers_skipped", [])),
        skip_reasons=dict(raw.get("skip_reasons", {})),
    )


def _phase8_from_dict(raw: Any) -> "Phase8Progress | None":
    """Reconstruct a :class:`Phase8Progress` from a deserialized JSON value.

    Returns ``None`` when *raw* is ``None`` or missing — this is the path
    pre-#299 state.json files take so they keep loading after the upgrade.
    Missing keys inside *raw* fall back to the dataclass field defaults.

    Args:
        raw: Value read from ``state.json`` (``None`` or a dict).

    Returns:
        ``None`` when *raw* is ``None``; otherwise a populated
        :class:`Phase8Progress` instance with defaults filling missing keys.
    """
    if raw is None:
        return None
    return Phase8Progress(
        attempt=raw.get("attempt", 0),
        status=raw.get("status"),
        started_at=raw.get("started_at"),
        finished_at=raw.get("finished_at"),
        ci_status=raw.get("ci_status"),
        ci_run_id=raw.get("ci_run_id"),
        repair_attempts=raw.get("repair_attempts", 0),
        workflow_files_written=list(raw.get("workflow_files_written", [])),
    )


def _repo_info_from_dict(d: dict[str, Any]) -> RepoInfo:
    """Reconstruct a :class:`RepoInfo` from a plain dict (e.g. deserialized JSON).

    The derived ``full`` field is ignored — it is recomputed by ``RepoInfo.__post_init__``.

    Args:
        d: Dict with at least ``host``, ``owner``, and ``name`` keys.

    Returns:
        Immutable :class:`RepoInfo` instance.
    """
    return RepoInfo(host=d["host"], owner=d["owner"], name=d["name"])


def _repo_info_to_dict(repo: RepoInfo) -> dict[str, str]:
    """Serialize a :class:`RepoInfo` to a plain dict with core fields only.

    Args:
        repo: :class:`RepoInfo` instance to serialize.

    Returns:
        Dict with ``host``, ``owner``, and ``name`` keys.
    """
    return {"host": repo.host, "owner": repo.owner, "name": repo.name}


def _validate_cache_telemetry(raw: Any, location: str) -> dict[str, int | float]:
    """Validate and return a cache_telemetry dict, raising on invalid values.

    All values must be numeric (``int`` or ``float``) and must not be ``bool``
    (since ``isinstance(True, int) is True`` in Python).  If *raw* is ``None``
    the canonical default is returned.

    Args:
        raw: The value read from state.json (may be None or any type).
        location: JSON path prefix used in error messages (e.g. ``cycles[0]``).

    Returns:
        A validated ``dict[str, int | float]``.

    Raises:
        StateCorruptedError: When *raw* is not a dict or contains non-numeric values.
    """
    if raw is None:
        return _default_cache_telemetry()
    if not isinstance(raw, dict):
        raise StateCorruptedError(
            path=_SENTINEL_PATH,
            location=f"{location}.cache_telemetry",
            reason=f"expected dict, got {type(raw).__name__}",
        )
    for key, value in raw.items():
        if isinstance(value, bool) or not isinstance(value, int | float):
            raise StateCorruptedError(
                path=_SENTINEL_PATH,
                location=f"{location}.cache_telemetry",
                reason=f"key {key!r}: expected int or float, got {type(value).__name__}",
            )
    return raw  # type: ignore[return-value]


def _validate_cache_ttl_probe(raw_value: Any, location: str) -> "Literal['1h', '5m'] | None":
    """Validate that *raw_value* is ``None`` or a known TTL probe outcome.

    Args:
        raw_value: Value read from state.json (may be ``None`` or any type).
        location: JSON path prefix for error messages.

    Returns:
        ``None`` (when *raw_value* is missing/None) or the validated literal.

    Raises:
        StateCorruptedError: When *raw_value* is set but not one of ``"1h"`` / ``"5m"``.
    """
    if raw_value is None:
        return None
    if raw_value not in _VALID_TTL_PROBES:
        raise StateCorruptedError(
            path=_SENTINEL_PATH,
            location=f"{location}.cache_ttl_probe",
            reason=(
                f"unknown value {raw_value!r}; expected one of {sorted(_VALID_TTL_PROBES)} or null"
            ),
        )
    return raw_value  # type: ignore[return-value]


def _validate_session_mode(raw_value: str, path: Path) -> Literal["shared", "fresh", "batch"]:
    """Validate that *raw_value* is a known session_mode.

    Args:
        raw_value: The value read from state.json.
        path: Path to the state file (used in the error message).

    Returns:
        The validated value, narrowed to ``Literal['shared', 'fresh', 'batch']``.

    Raises:
        StateCorruptedError: When *raw_value* is not in ``{'shared', 'fresh'}``.
    """
    if raw_value not in _VALID_SESSION_MODES:
        raise StateCorruptedError(
            path=path,
            location="session_mode",
            reason=f"unknown value {raw_value!r}; expected one of {sorted(_VALID_SESSION_MODES)}",
        )
    return raw_value  # type: ignore[return-value]


def _cycle_from_dict(d: Any, index: int = 0) -> "CycleState | CycleTelemetrySummary":
    location = f"cycles[{index}]"
    if not isinstance(d, dict):
        raise StateCorruptedError(
            path=_SENTINEL_PATH,
            location=location,
            reason=f"expected dict, got {type(d).__name__}",
        )
    if d.get("kind") == "summary":
        return CycleTelemetrySummary(
            cycle_name=d["cycle_name"],
            total_tokens=d["total_tokens"],
            cache_hit_pct=float(d["cache_hit_pct"]),
            wall_seconds=float(d["wall_seconds"]),
        )
    raw_issues = d.get("issues", [])
    if not isinstance(raw_issues, list):
        raise StateCorruptedError(
            path=_SENTINEL_PATH,
            location=f"{location}.issues",
            reason=f"expected list, got {type(raw_issues).__name__}",
        )
    issue_prefix = f"{location}.issues"
    cache_telemetry = _validate_cache_telemetry(d.get("cache_telemetry"), location)
    try:
        return CycleState(
            id=d["id"],
            name=d["name"],
            milestone_number=d.get("milestone_number"),
            milestone_title=d["milestone_title"],
            status=d["status"],
            phase=d["phase"],
            issues=[_issue_from_dict(i, idx, issue_prefix) for idx, i in enumerate(raw_issues)],
            commit_sha=d.get("commit_sha"),
            depends_on=d.get("depends_on", []),
            scope=d.get("scope", ""),
            effort_hints=[_effort_hint_from_dict(h) for h in d.get("effort_hints", [])],
            base_commit=d.get("base_commit"),
            token_usage=_token_usage_from_dict(d.get("token_usage", {})),
            started_at=d.get("started_at"),
            finished_at=d.get("finished_at"),
            cache_telemetry=cache_telemetry,
            phase2_batch_id=d.get("phase2_batch_id"),
            ollama_model=d.get("ollama_model"),
            gemini_model=d.get("gemini_model"),
            codex_model=d.get("codex_model"),
            cache_prewarmed=d.get("cache_prewarmed", False),
            cache_ttl_probe=_validate_cache_ttl_probe(d.get("cache_ttl_probe"), location),
            phase6_5=_phase6_5_from_dict(d.get("phase6_5")),
            vigil_triggered=bool(d.get("vigil_triggered", False)),
            phase8=_phase8_from_dict(d.get("phase8")),
        )
    except KeyError as exc:
        raise StateCorruptedError(
            path=_SENTINEL_PATH,
            location=location,
            reason=f"missing required key {exc}",
        ) from exc


def load_state(path: Path) -> State:
    """Load state from path, or return a fresh default when the file is missing.

    Args:
        path: Location of state.json (need not exist).

    Returns:
        Deserialized State, or a default single-mode State if the file is absent.
    """
    if not path.exists():
        now = _utc_now()
        return State(mode="unknown", started_at=now, updated_at=now)

    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise StateCorruptedError(
            path=path,
            location="<root>",
            reason=f"expected dict, got {type(raw).__name__}",
        )
    try:
        raw_session_mode = raw.get("session_mode", "shared")
        session_mode = _validate_session_mode(raw_session_mode, path)

        raw_repo = raw.get("repo")
        repo = _repo_info_from_dict(raw_repo) if raw_repo is not None else None

        cycles: list[CycleState | CycleTelemetrySummary] = [
            _cycle_from_dict(c, i) for i, c in enumerate(raw.get("cycles", []))
        ]
        return State(
            mode=raw["mode"],
            started_at=raw["started_at"],
            updated_at=raw["updated_at"],
            current_cycle=raw.get("current_cycle"),
            cycles=cycles,
            phase=raw.get("phase"),
            issues=[
                _issue_from_dict(item, idx, "issues")
                for idx, item in enumerate(raw.get("issues", []))
            ],
            session_id=raw.get("session_id"),
            paused_until=raw.get("paused_until"),
            rate_limit_type=raw.get("rate_limit_type"),
            last_error=raw.get("last_error"),
            effort_hints=[_effort_hint_from_dict(h) for h in raw.get("effort_hints", [])],
            requirements_hash=raw.get("requirements_hash"),
            base_commit=raw.get("base_commit"),
            token_usage=_token_usage_from_dict(raw.get("token_usage", {})),
            session_mode=session_mode,
            client_alive_at=raw.get("client_alive_at"),
            repo=repo,
            prompt_hashes=raw.get("prompt_hashes", {}),
            sdk_version=raw.get("sdk_version"),
            gemini_model=raw.get("gemini_model"),
            codex_model=raw.get("codex_model"),
            phase2_batch_id=raw.get("phase2_batch_id"),
            cache_prewarmed=raw.get("cache_prewarmed", False),
            cache_ttl_probe=_validate_cache_ttl_probe(raw.get("cache_ttl_probe"), "<root>"),
            phase6_5=_phase6_5_from_dict(raw.get("phase6_5")),
            vigil_triggered=bool(raw.get("vigil_triggered", False)),
            phase8=_phase8_from_dict(raw.get("phase8")),
        )
    except StateCorruptedError as exc:
        exc.path = path
        raise


def save_state(path: Path, state: State) -> None:
    """Atomically persist state to path.

    Applies the retention policy (truncate_old_cycles) so the file shrinks
    monotonically when there are more than 10 full CycleState entries.
    Updates state.updated_at, serializes to JSON with 2-space indentation,
    writes to a sibling .tmp file, then replaces the target via os.replace()
    so no partial write is ever visible.

    Args:
        path: Destination for state.json.
        state: State object to persist.
    """
    state.updated_at = _utc_now()
    state.cycles = _apply_retention(state.cycles)
    path.parent.mkdir(parents=True, exist_ok=True)

    tmp = Path(str(path) + ".tmp")
    data = json.dumps(dataclasses.asdict(state), indent=2)
    tmp.write_text(data, encoding="utf-8")
    os.replace(tmp, path)


def _apply_retention(
    cycles: "list[CycleState | CycleTelemetrySummary]",
) -> "list[CycleState | CycleTelemetrySummary]":
    """Separate existing summaries from full cycles, then re-apply retention to full cycles.

    Existing :class:`CycleTelemetrySummary` entries (from a prior load) are
    preserved at the front; only the :class:`CycleState` entries are subject
    to the keep-10 window.

    Args:
        cycles: Current mixed list of full cycles and compact summaries.

    Returns:
        New list with existing summaries first, then the result of
        :func:`truncate_old_cycles` applied to the remaining full cycles.
    """
    existing_summaries = [c for c in cycles if isinstance(c, CycleTelemetrySummary)]
    full_cycles = [c for c in cycles if isinstance(c, CycleState)]
    return existing_summaries + truncate_old_cycles(full_cycles)


def mark_paused(
    state: State,
    *,
    resets_at: int,
    rate_limit_type: str,
    session_id: str | None,
) -> None:
    """Record a rate-limit pause in the state object (in-memory only).

    Caller must call save_state() afterwards to persist.

    Args:
        state: State to mutate.
        resets_at: Unix timestamp when the rate-limit window resets.
        rate_limit_type: Identifier for the type of rate limit hit.
        session_id: SDK session ID to resume from, if available.
    """
    state.paused_until = resets_at
    state.rate_limit_type = rate_limit_type
    state.session_id = session_id


def clear_pause(state: State) -> None:
    """Clear pause fields after the rate-limit window has passed.

    Args:
        state: State to mutate in place.
    """
    state.paused_until = None
    state.rate_limit_type = None


def is_paused(state: State, *, now: float | None = None) -> bool:
    """Return True when the state indicates an active rate-limit pause.

    Args:
        state: State to inspect.
        now: Override for the current time (seconds since epoch). Defaults to
            time.time() when omitted.

    Returns:
        True if paused_until is set and lies in the future.
    """
    if state.paused_until is None:
        return False
    return state.paused_until > (now if now is not None else time.time())


def _effort_hints_from_raw(raw: list[Any]) -> list[EffortHint]:
    """Convert a raw list of hint dicts to EffortHint objects, skipping invalid entries.

    Args:
        raw: List of dicts, each expected to have ``scope_keyword`` and ``effort`` keys.

    Returns:
        List of ``EffortHint`` instances; entries with missing keys are silently dropped.
    """
    hints = []
    for item in raw:
        if isinstance(item, dict) and "scope_keyword" in item and "effort" in item:
            hints.append(EffortHint(scope_keyword=item["scope_keyword"], effort=item["effort"]))  # type: ignore[arg-type]
    return hints


def append_new_cycles(
    state: State,
    raw_cycles: list[dict[str, Any]],
    *,
    ollama_model: str | None = None,
    gemini_model: str | None = None,
    codex_model: str | None = None,
) -> list[CycleState]:
    """Build new CycleState objects for scopes not yet in state.cycles.

    Phase 0 raw cycle IDs (typically 1-based) are remapped to actual IDs
    starting from ``max(existing_ids) + 1``. All ``depends_on`` references are
    remapped through the same mapping so cross-cycle dependencies remain
    consistent after the merge.

    Cycles whose ``scope`` already exists in ``state.cycles`` are silently
    skipped, making the operation idempotent — calling it twice with the same
    input produces no duplicates.

    Args:
        state: Current state with existing cycles (not mutated).
        raw_cycles: Raw cycle dicts from Phase 0 output (list of dicts with
            ``id``, ``scope``, ``name``, ``milestone_title``, ``depends_on``).
        ollama_model: When set, stamped on every new CycleState so delta-planned
            cycles inherit the single-model routing (otherwise they revert to
            hardcoded per-phase Anthropic models).
        gemini_model: Same as ``ollama_model`` for the Gemini provider path —
            stamped on every new CycleState so ``--continue`` resumes without
            re-typing ``--model``.
        codex_model: Same as ``ollama_model`` for the Codex provider path —
            stamped on every new CycleState so ``--continue`` resumes without
            re-typing ``--model``.

    Returns:
        List of new :class:`CycleState` objects (not yet appended to
        ``state.cycles``). Caller must extend ``state.cycles`` if desired.
    """
    full_cycles = [c for c in state.cycles if isinstance(c, CycleState)]
    existing_by_scope: dict[str, CycleState] = {c.scope: c for c in full_cycles}
    max_id = max((c.id for c in full_cycles), default=0)

    # Build ID remap: Phase 0 raw id → actual state id.
    id_remap: dict[int, int] = {}
    next_id = max_id + 1
    for idx, raw in enumerate(raw_cycles):
        raw_id = int(raw.get("id", idx + 1))
        scope = str(raw.get("scope", ""))
        if scope in existing_by_scope:
            id_remap[raw_id] = existing_by_scope[scope].id
        else:
            id_remap[raw_id] = next_id
            next_id += 1

    new_cycles: list[CycleState] = []
    for idx, raw in enumerate(raw_cycles):
        raw_id = int(raw.get("id", idx + 1))
        scope = str(raw.get("scope", ""))
        if scope in existing_by_scope:
            continue
        actual_id = id_remap[raw_id]
        raw_deps: list[int] = raw.get("depends_on", [])
        depends_on = [id_remap.get(d, d) for d in raw_deps]
        new_cycles.append(
            CycleState(
                id=actual_id,
                name=str(raw.get("name", f"Cycle {actual_id}")),
                milestone_number=None,
                milestone_title=str(raw.get("milestone_title", f"Cycle {actual_id}")),
                status="open",
                phase=0,
                issues=[],
                commit_sha=None,
                depends_on=depends_on,
                scope=scope,
                effort_hints=_effort_hints_from_raw(raw.get("effort_hints", [])),
                ollama_model=ollama_model,
                gemini_model=gemini_model,
                codex_model=codex_model,
            )
        )
    return new_cycles


def get_issues(state: State, cycle: CycleState | None) -> list[IssueState]:
    """Return the list of issues for the active scope, sorted ascending by number.

    Phase 1 already writes ``state.issues`` / ``cycle.issues`` in ascending
    order, but Phase 5 appends fix-issues mid-cycle from ``gh.list_issues()``
    which defaults to descending-by-number. A defensive sort here guarantees
    that every downstream phase (2, 3/4, 6, 7) iterates issues from lowest
    to highest number regardless of insertion order.

    Args:
        state: Root state.
        cycle: Active cycle or ``None`` for single-cycle mode.

    Returns:
        A new list of :class:`IssueState` sorted by ``number`` ascending.
        Callers that need to mutate the underlying list should access
        ``state.issues`` / ``cycle.issues`` directly.
    """
    source = cycle.issues if cycle is not None else state.issues
    return sorted(source, key=lambda issue: issue.number)


def warn_on_prompt_or_sdk_drift(
    state: State,
    recomputed_hashes: dict[str, str],
    current_sdk_version: str | None,
) -> list[str]:
    """Compare stored prompt hashes and SDK version against current values.

    Pure function: inspects ``state.prompt_hashes`` and ``state.sdk_version``
    against the freshly-computed equivalents and returns a list of human-readable
    WARNING strings.  The caller is responsible for emitting them via a logger.

    On ``--continue``, missing stored values (0.2.x state.json) are silently
    skipped — no WARNING is emitted for fields that were never populated.

    Args:
        state: Root state (read-only).
        recomputed_hashes: Fresh ``{filename: sha256_hex}`` from
            :func:`~code_generator.prompts.hashes.compute_all_prompt_hashes`.
        current_sdk_version: Fresh ``claude_agent_sdk.__version__`` or ``None``
            from :func:`~code_generator.env.detect_sdk_version`.

    Returns:
        List of warning strings (may be empty).  One entry per changed prompt
        file, plus one entry when the SDK version differs.
    """
    warnings: list[str] = []

    for filename, stored_digest in state.prompt_hashes.items():
        current_digest = recomputed_hashes.get(filename)
        if current_digest is not None and current_digest != stored_digest:
            warnings.append(
                f"Prompt '{filename}' changed since cycle start — cache reuse may be degraded."
            )

    if state.sdk_version is not None and current_sdk_version != state.sdk_version:
        warnings.append(f"SDK version changed from {state.sdk_version} to {current_sdk_version}.")

    return warnings


def clear_comment_cache(state: State) -> None:
    """Reset ``IssueState.comments`` to ``None`` on every issue in every cycle.

    Useful for operators who manually edit GitHub issue comments mid-cycle and
    want the next run to re-fetch instead of reusing stale cached text.
    Call :func:`save_state` after this to persist the change.

    Args:
        state: Root state object (mutated in place).
    """
    for issue in state.issues:
        issue.comments = None
    for cycle in state.cycles:
        if isinstance(cycle, CycleState):
            for issue in cycle.issues:
                issue.comments = None
