"""GitHub environment preflight validation.

Validates the local environment can talk to the target GitHub host
before any cycle starts. On failure raises :class:`PreflightError`
with a ready-to-paste fix command; on success returns a validated
:class:`~code_generator.repo_info.RepoInfo`.

Single responsibility: environment validation.
No state.json mutation — callers own that (see issue #156).

Checks performed in order
-------------------------
(a) ``git remote get-url origin`` succeeds.
(b) URL parses via :func:`~code_generator.repo_info.parse_remote_url`.
(c) ``gh auth status --hostname <host>`` exits 0.
(d) ``gh repo view <owner/repo> --hostname <host>`` exits 0.
(e) ``gh api repos/<owner/repo>/labels --hostname <host>`` exits 0.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
from typing import TYPE_CHECKING
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from code_generator.repo_info import RepoInfo, parse_remote_url
from code_generator.runner.options import assert_required_betas

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

logger = logging.getLogger(__name__)

# Ollama preflight constants — pinned so tests can assert exact values and
# the refusal gate in env.py (#215) and this preflight stay in sync.
OLLAMA_TAGS_URL = "http://localhost:11434/api/tags"
OLLAMA_SHOW_URL = "http://localhost:11434/api/show"
OLLAMA_PINNED_BASE_URL = "http://localhost:11434"
OLLAMA_PROBE_TIMEOUT_SECONDS = 2
OLLAMA_SIGNIN_COMMAND = "ollama signin"
# Cloud model fetched to probe signed-in state. The daemon returns 401 on
# this endpoint when not authenticated; 404 / 200 both mean authenticated
# (model absent vs present).
_OLLAMA_CLOUD_PROBE_MODEL = "qwen3-coder:480b-cloud"

# Injected by tests via ``patch("code_generator.preflight._IS_WINDOWS", True)``.
# Windows note: gh credentials integrate with Windows Credential Manager and
# may behave differently. Checks that fail on Windows log a WARNING and are
# skipped rather than aborting the run.
_IS_WINDOWS: bool = sys.platform == "win32"


# ---------------------------------------------------------------------------
# Public exception
# ---------------------------------------------------------------------------


class PreflightError(Exception):
    """Raised when a preflight check fails.

    Attributes:
        reason: Short human-readable description of the failure.
        fix_command: A copy-paste ready command to resolve the issue.
    """

    def __init__(self, *, reason: str, fix_command: str) -> None:
        self.reason = reason
        self.fix_command = fix_command
        super().__init__(reason)


# ---------------------------------------------------------------------------
# Subprocess seams (patch these in tests)
# ---------------------------------------------------------------------------


def _run_gh(args: list[str], *, hostname: str) -> subprocess.CompletedProcess:  # type: ignore[type-arg]
    """Execute a gh command appending ``--hostname`` and return CompletedProcess.

    Single seam for all gh subprocess calls — tests patch this one function.
    Never uses ``shell=True``.

    Args:
        args: Full argv including the ``gh`` binary.
        hostname: Value for the ``--hostname`` flag.

    Returns:
        CompletedProcess with returncode, stdout, and stderr populated.
    """
    return subprocess.run(
        [*args, "--hostname", hostname],
        capture_output=True,
        text=True,
        check=False,
    )


def _get_origin_url(project_dir: Path) -> str:
    """Return the git remote origin URL for *project_dir*.

    Args:
        project_dir: Root directory of the git project.

    Returns:
        Stripped remote URL string.

    Raises:
        PreflightError: When ``git remote get-url origin`` exits non-zero.
    """
    result = subprocess.run(
        ["git", "remote", "get-url", "origin"],
        cwd=project_dir,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise PreflightError(
            reason="No 'origin' remote found in this git repository.",
            fix_command="git remote add origin <url>",
        )
    return result.stdout.strip()


# ---------------------------------------------------------------------------
# Individual checks (SRP: one check per function, each < 10 lines)
# ---------------------------------------------------------------------------


def _check_auth(repo_info: RepoInfo) -> None:
    """Verify gh is authenticated for the target host.

    Args:
        repo_info: Parsed repository information supplying the hostname.

    Raises:
        PreflightError: When ``gh auth status`` exits non-zero.
    """
    result = _run_gh(["gh", "auth", "status"], hostname=repo_info.host)
    if result.returncode != 0:
        raise PreflightError(
            reason=f"Not authenticated to {repo_info.host}.",
            fix_command=f"gh auth login --hostname {repo_info.host}",
        )


def _check_repo(repo_info: RepoInfo) -> None:
    """Verify gh can access the repository.

    ``gh repo view`` does not accept ``--hostname``; the host is passed as part
    of the positional argument (``HOST/OWNER/REPO`` for enterprise,
    ``OWNER/REPO`` for github.com).

    Args:
        repo_info: Parsed repository information.

    Raises:
        PreflightError: When ``gh repo view`` exits non-zero.
    """
    if repo_info.host == "github.com":
        target = repo_info.full
    else:
        target = f"{repo_info.host}/{repo_info.full}"
    result = subprocess.run(
        ["gh", "repo", "view", target],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise PreflightError(
            reason=f"Cannot access repository {repo_info.full} on {repo_info.host}.",
            fix_command=f"gh repo view {target}",
        )


def _check_labels(repo_info: RepoInfo) -> None:
    """Verify gh can access the labels API for the repository.

    Args:
        repo_info: Parsed repository information.

    Raises:
        PreflightError: When ``gh api repos/.../labels`` exits non-zero.
    """
    result = _run_gh(
        ["gh", "api", f"repos/{repo_info.full}/labels"],
        hostname=repo_info.host,
    )
    if result.returncode != 0:
        raise PreflightError(
            reason=f"Cannot access labels API for {repo_info.full} on {repo_info.host}.",
            fix_command=f"gh api repos/{repo_info.full}/labels --hostname {repo_info.host}",
        )


# ---------------------------------------------------------------------------
# Windows-safe check runner
# ---------------------------------------------------------------------------


def _run_check_windows_safe(
    check_fn: Callable[[RepoInfo], None],
    repo_info: RepoInfo,
    check_name: str,
) -> None:
    """Run a check, logging WARNING and skipping on Windows instead of raising.

    On non-Windows systems exceptions propagate normally.

    # Windows note: credential manager integration may cause gh to behave
    # differently on Windows. Rather than hard-failing, we log a WARNING so
    # the operator can validate manually.

    Args:
        check_fn: Function taking a RepoInfo that may raise PreflightError.
        repo_info: Repository info forwarded to the check.
        check_name: Human-readable name used in the warning message.
    """
    try:
        check_fn(repo_info)
    except PreflightError:
        if _IS_WINDOWS:
            logger.warning(
                "Preflight check '%s' skipped on Windows — validate manually.",
                check_name,
            )
        else:
            raise


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_preflight(project_dir: Path) -> RepoInfo:
    """Validate the local environment can talk to the target GitHub host.

    Performs five checks in order (a–e, see module docstring).
    Returns a validated :class:`RepoInfo` on success.

    Args:
        project_dir: Root directory of the git project being generated.

    Returns:
        Parsed and validated :class:`RepoInfo` for the ``origin`` remote.

    Raises:
        PreflightError: When any check fails on a non-Windows system.
            Carries ``reason`` and ``fix_command`` for operator display.
    """
    # SDK self-check: required beta tokens must be in the emitted header.
    try:
        assert_required_betas()
    except RuntimeError as exc:
        raise PreflightError(
            reason=str(exc),
            fix_command="pip install -U claude-agent-sdk",
        ) from exc

    # (a) origin remote exists
    origin_url = _get_origin_url(project_dir)

    # (b) URL parses to a RepoInfo
    try:
        repo_info = parse_remote_url(origin_url)
    except ValueError as exc:
        raise PreflightError(
            reason=f"Cannot parse git remote URL: {origin_url!r}",
            fix_command="git remote set-url origin <valid-url>",
        ) from exc

    # (c–e) gh checks — Windows-safe
    _run_check_windows_safe(_check_auth, repo_info, "gh auth status")
    _run_check_windows_safe(_check_repo, repo_info, "gh repo view")
    _run_check_windows_safe(_check_labels, repo_info, "gh api labels")

    return repo_info


# ---------------------------------------------------------------------------
# Ollama preflight — separate entry point for the Ollama codepath (#216)
# ---------------------------------------------------------------------------


def _require_ollama_api_key() -> None:
    """Raise if OLLAMA_API_KEY is unset or empty."""
    if not os.environ.get("OLLAMA_API_KEY", ""):
        raise PreflightError(
            reason="OLLAMA_API_KEY is unset or empty.",
            fix_command='export OLLAMA_API_KEY="<your-ollama-pro-token>"',
        )


def _require_matching_base_url() -> None:
    """Raise if ANTHROPIC_BASE_URL is pre-set to anything other than localhost:11434."""
    preset = os.environ.get("ANTHROPIC_BASE_URL")
    if preset and preset != OLLAMA_PINNED_BASE_URL:
        raise PreflightError(
            reason=f"ANTHROPIC_BASE_URL must equal {OLLAMA_PINNED_BASE_URL}, got {preset!r}.",
            fix_command=f'export ANTHROPIC_BASE_URL="{OLLAMA_PINNED_BASE_URL}"',
        )


def _probe_daemon_reachable() -> None:
    """GET /api/tags within 2s; raise if unreachable or non-200."""
    try:
        with urlopen(OLLAMA_TAGS_URL, timeout=OLLAMA_PROBE_TIMEOUT_SECONDS) as resp:
            status = getattr(resp, "status", 0)
    except (URLError, TimeoutError, OSError) as exc:
        raise PreflightError(
            reason=f"Ollama daemon unreachable at {OLLAMA_TAGS_URL}.",
            fix_command="Start the Ollama daemon (e.g. `ollama serve`) and retry.",
        ) from exc

    if status != 200:
        raise PreflightError(
            reason=f"Ollama daemon unreachable at {OLLAMA_TAGS_URL} (HTTP {status}).",
            fix_command="Start the Ollama daemon (e.g. `ollama serve`) and retry.",
        )


def _probe_signed_in() -> None:
    """POST /api/show for a cloud model; 401 means the daemon is not signed in.

    The fetched model does not need to exist locally — we only care whether
    the daemon recognises the caller as authenticated for cloud endpoints.
    A 404 (model not found) is accepted: it still proves authentication
    succeeded because an unauthenticated daemon fails at the auth layer
    with 401 before model lookup.
    """
    body = json.dumps({"name": _OLLAMA_CLOUD_PROBE_MODEL}).encode()
    request = Request(
        OLLAMA_SHOW_URL,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request, timeout=OLLAMA_PROBE_TIMEOUT_SECONDS):
            return
    except HTTPError as exc:
        if exc.code == 401:
            raise PreflightError(
                reason=(
                    "Ollama daemon is not signed in to your Pro account. "
                    "Cloud models (:cloud) will return 401."
                ),
                fix_command=OLLAMA_SIGNIN_COMMAND,
            ) from exc
        # Any non-401 HTTP error (404 "model not found", 5xx, etc.) proves
        # the daemon accepted the call past the auth layer — signed in.
        return
    except (URLError, TimeoutError, OSError):
        # Network-level errors fall through; the tags probe already caught
        # reachability, so surface these as a reachability hint rather than
        # a spurious signin failure.
        return


def run_ollama_preflight(*, check_signin: bool = True) -> None:
    """Validate the Ollama codepath can talk to the local daemon.

    Performs four checks in fail-fast order — cheap env-var checks first,
    then network probes:

    (1) ``OLLAMA_API_KEY`` set and non-empty.
    (2) ``ANTHROPIC_BASE_URL`` either unset or equal to the pinned value.
    (3) ``GET /api/tags`` returns HTTP 200 within 2 seconds.
    (4) Signed-in probe: ``POST /api/show`` with a cloud model —
        a 401 response indicates the daemon is not signed in.

    Args:
        check_signin: When False, skips probe (4). Used by callers that
            already verified signin externally or by tests.

    Raises:
        PreflightError: On the first failing check, with a user-actionable
            ``reason`` and ``fix_command``.
    """
    _require_ollama_api_key()
    _require_matching_base_url()
    _probe_daemon_reachable()
    if check_signin:
        _probe_signed_in()


def _require_gemini_binary() -> None:
    """Raise if the ``gemini`` binary is not on PATH."""
    import shutil

    if shutil.which("gemini") is None:
        raise PreflightError(
            reason="gemini CLI binary not found on PATH.",
            fix_command="npm install -g @google/gemini-cli",
        )


def _check_gemini_api_key() -> bool:
    """True when GEMINI_API_KEY is set and non-empty."""
    return bool(os.environ.get("GEMINI_API_KEY", ""))


def _check_google_api_key_with_vertex() -> bool:
    """True when GOOGLE_API_KEY plus a Vertex project/flag are configured."""
    if not os.environ.get("GOOGLE_API_KEY", ""):
        return False
    return bool(
        os.environ.get("GOOGLE_CLOUD_PROJECT", "")
        or os.environ.get("GOOGLE_GENAI_USE_VERTEXAI", "") == "true"
    )


def _check_service_account() -> bool:
    """True when GOOGLE_APPLICATION_CREDENTIALS points at an existing file."""
    path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "")
    return bool(path) and os.path.isfile(path)


def _check_cached_oauth() -> bool:
    """True when a cached gemini-cli OAuth credentials file exists.

    Existence only — never parsed, never triggers the interactive OAuth flow.
    Covers both the npm package default (``~/.config/gemini``), the legacy
    ``~/.gemini`` path, and the Windows ``%APPDATA%\\gemini`` location.
    """
    candidates = [
        os.path.expanduser("~/.config/gemini/credentials.json"),
        os.path.expanduser("~/.gemini/credentials.json"),
    ]
    appdata = os.environ.get("APPDATA")
    if appdata:
        candidates.append(os.path.join(appdata, "gemini", "credentials.json"))
    return any(os.path.isfile(p) for p in candidates)


def _require_gemini_auth() -> None:
    """Raise unless at least one non-interactive Gemini auth method is present."""
    if (
        _check_gemini_api_key()
        or _check_google_api_key_with_vertex()
        or _check_service_account()
        or _check_cached_oauth()
    ):
        return
    raise PreflightError(
        reason=(
            "No Gemini authentication found. Set GEMINI_API_KEY, "
            "GOOGLE_APPLICATION_CREDENTIALS (service-account JSON), or run "
            "`gemini auth` once interactively to cache OAuth credentials."
        ),
        fix_command='export GEMINI_API_KEY="<your-api-key>"  # or: gemini auth',
    )


def run_gemini_preflight() -> None:
    """Validate that gemini-cli is installed and authenticated.

    Performs two fail-fast checks: the ``gemini`` binary is on PATH, and at
    least one non-interactive auth method is configured. Never blocks on an
    interactive OAuth prompt.

    Raises:
        PreflightError: When the binary is missing or no credential is found.
    """
    _require_gemini_binary()
    _require_gemini_auth()


def _require_codex_binary() -> None:
    """Raise if the ``codex`` binary is not on PATH."""
    import shutil

    if shutil.which("codex") is None:
        raise PreflightError(
            reason="codex CLI binary not found on PATH.",
            fix_command="npm install -g @openai/codex",
        )


def _codex_home() -> str:
    """Return the Codex home dir (``$CODEX_HOME`` or ``~/.codex``)."""
    return os.path.expanduser(os.environ.get("CODEX_HOME") or "~/.codex")


def _require_codex_auth() -> None:
    """Raise unless a cached ChatGPT-OAuth credentials file exists.

    The OpenAI API-key env vars are deliberately NOT an accepted auth
    signal: ``build_agent_env("codex")`` strips them (zero-credit
    invariant — silent-billing bug #15151/#20099), so accepting them here
    would pass preflight then fail at runtime. Existence only — the file is
    never parsed and the interactive ``codex login`` flow is never triggered.
    """
    if os.path.isfile(os.path.join(_codex_home(), "auth.json")):
        return
    raise PreflightError(
        reason=(
            "No Codex authentication found. The Codex provider runs on the "
            "ChatGPT-subscription login only (API keys are stripped for the "
            "zero-credit invariant)."
        ),
        fix_command="codex login",
    )


def _toml_quote_key(value: str) -> str:
    """Escape a string for use as a TOML basic (double-quoted) key."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _codex_dir_is_trusted(config_text: str, project_dir: str) -> bool:
    """True when ``config_text`` already trusts ``project_dir``.

    Prefers a real TOML parse; falls back to a section/marker scan when the
    file is hand-edited and ``tomllib`` cannot parse it.
    """
    import tomllib

    try:
        data = tomllib.loads(config_text)
        projects = data.get("projects", {})
        entry = projects.get(project_dir, {}) if isinstance(projects, dict) else {}
        return isinstance(entry, dict) and entry.get("trust_level") == "trusted"
    except (tomllib.TOMLDecodeError, ValueError):
        marker = f'[projects."{_toml_quote_key(project_dir)}"]'
        return marker in config_text and 'trust_level = "trusted"' in config_text


def _require_codex_trust() -> None:
    """Idempotently seed the project dir as trusted in ``config.toml``.

    Because of the headless trust-prompt bug (openai/codex #14547),
    ``codex exec`` can hang waiting for one-time directory-trust
    confirmation even under ``--dangerously-bypass-approvals-and-sandbox``.
    A hung subprocess is worse than a written config line, so this seeds
    rather than fails. Append-only (never rewrites existing content),
    atomic (``tmp`` → ``os.replace``).
    """
    home = _codex_home()
    config_path = os.path.join(home, "config.toml")
    project_dir = os.path.abspath(os.getcwd())

    existing = ""
    if os.path.isfile(config_path):
        with open(config_path, encoding="utf-8") as fh:
            existing = fh.read()
        if _codex_dir_is_trusted(existing, project_dir):
            logger.debug("codex trust: %s already trusted — skipping seed.", project_dir)
            return

    block = f'\n[projects."{_toml_quote_key(project_dir)}"]\ntrust_level = "trusted"\n'
    if existing and not existing.endswith("\n"):
        existing += "\n"
    new_text = existing + block

    os.makedirs(home, exist_ok=True)
    tmp = config_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(new_text)
    os.replace(tmp, config_path)
    logger.info("codex trust: seeded %s as trusted in %s.", project_dir, config_path)


def run_codex_preflight() -> None:
    """Validate that codex-cli is installed, authenticated, and trusted.

    Three fail-fast / fail-safe checks: the ``codex`` binary is on PATH, a
    ChatGPT-OAuth credentials file exists, and the project dir is pre-seeded
    as trusted in ``config.toml`` (so headless ``codex exec`` never blocks
    on the trust prompt — #14547). Never blocks on an interactive prompt.

    Raises:
        PreflightError: When the binary is missing or no credential is found.
    """
    _require_codex_binary()
    _require_codex_auth()
    _require_codex_trust()
