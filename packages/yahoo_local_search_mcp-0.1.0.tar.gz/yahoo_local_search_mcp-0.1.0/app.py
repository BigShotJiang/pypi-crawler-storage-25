"""
mcp-yahoo-localsearch
=====================

Yahoo!ローカルサーチAPI (YOLP) の MCP サーバー (シンプルラッパーパターン)。

公式仕様:
    https://developer.yahoo.co.jp/webapi/map/openlocalplatform/v1/localsearch.html

提供ツール:
    - search_local       : キーワード/業種/住所/緯度経度などで地域・拠点情報を検索
    - search_by_genre    : 業種コードを軸にした検索 (search_localの薄いラッパー)
    - search_nearby      : 中心座標+半径での円範囲検索 (search_localの薄いラッパー)

エンドポイント:
    GET https://map.yahooapis.jp/search/local/V1/localSearch

レスポンス形式:
    JSON 固定 (output=json をAPI側に強制送信)。
    Yahoo!の仕様上 XML がデフォルトのため、必ず明示する。

レート制限:
    1アプリケーション/24時間 = 50,000リクエスト

環境変数:
    YAHOO_APP_ID : Client ID (アプリケーションID, 必須)
"""

from __future__ import annotations

import os
from typing import Any, Optional

import httpx
from mcp.server.fastmcp import FastMCP


# --------------------------------------------------------------------------- #
# 設定
# --------------------------------------------------------------------------- #

APP_ID = os.environ.get("YAHOO_APP_ID", "")
API_BASE = os.environ.get(
    "YAHOO_LOCALSEARCH_BASE",
    "https://map.yahooapis.jp",
).rstrip("/")
ENDPOINT = "/search/local/V1/localSearch"

HTTP_TIMEOUT = 30.0

# 電話帳カセットID (公式仕様書記載)。最も網羅性が高い汎用カセット。
PHONEBOOK_CASSETTE_ID = "d8a23e9e64a4c817227ab09858bc1330"


# --------------------------------------------------------------------------- #
# 共通ユーティリティ
# --------------------------------------------------------------------------- #

def _ensure_credentials() -> None:
    if not APP_ID:
        raise RuntimeError(
            "環境変数 YAHOO_APP_ID が未設定です。"
            "Yahoo!デベロッパーネットワークで取得した Client ID を設定してください。"
        )


def _request(params: dict[str, Any]) -> dict[str, Any]:
    """ローカルサーチAPIへ GET リクエスト送信、JSON を返す。"""
    _ensure_credentials()

    # 必須・固定パラメータ
    params = {k: v for k, v in params.items() if v is not None and v != ""}
    params["appid"] = APP_ID
    params["output"] = "json"

    url = f"{API_BASE}{ENDPOINT}"

    try:
        with httpx.Client(timeout=HTTP_TIMEOUT) as client:
            response = client.get(url, params=params)
    except httpx.HTTPError as exc:
        raise RuntimeError(f"APIリクエスト時にネットワークエラーが発生しました: {exc}") from exc

    if response.status_code >= 400:
        try:
            body: Any = response.json()
        except ValueError:
            body = response.text
        raise RuntimeError(
            f"API呼び出しが失敗しました (HTTP {response.status_code}): {body}"
        )

    try:
        return response.json()
    except ValueError as exc:
        raise RuntimeError(
            f"APIレスポンスのJSONパースに失敗しました: {response.text[:500]}"
        ) from exc


# --------------------------------------------------------------------------- #
# MCP サーバー
# --------------------------------------------------------------------------- #

mcp = FastMCP("mcp-yahoo-localsearch")


@mcp.tool()
def search_local(
    query: Optional[str] = None,
    gc: Optional[str] = None,
    ac: Optional[str] = None,
    lat: Optional[float] = None,
    lon: Optional[float] = None,
    dist: Optional[float] = None,
    bbox: Optional[str] = None,
    sort: str = "hybrid",
    start: int = 1,
    results: int = 20,
    detail: str = "standard",
    cid: Optional[str] = None,
    open_param: Optional[str] = None,
    coupon: Optional[bool] = None,
    parking: Optional[bool] = None,
    creditcard: Optional[bool] = None,
    smoking: Optional[str] = None,
    reservation: Optional[str] = None,
    image: Optional[bool] = None,
    maxprice: Optional[int] = None,
    minprice: Optional[int] = None,
    group: Optional[str] = None,
    distinct: Optional[bool] = None,
) -> dict[str, Any]:
    """Yahoo!ローカルサーチAPIで店舗・施設情報を検索する汎用ツール。

    キーワード・業種コード・住所コード・緯度経度・矩形範囲などを組み合わせて、
    全国の店舗データ（電話帳カセットなど）を検索する。

    仕様上の必須条件:
        appid 以外に、query / gc / ac / lat+lon / cid のいずれかを必ず指定すること。
        いずれも未指定の場合は API 側で 400 エラーになる。

    Args:
        query: 検索キーワード (例: "焼肉", "イオン", "サントリー美術館")
        gc: 業種コード (例: "0118008"=焼肉, "0118"=韓国・朝鮮料理, "0202"=スーパーマーケット)
            YOLP業種コード一覧:
            https://developer.yahoo.co.jp/webapi/map/openlocalplatform/genre.html
        ac: 住所コード (JIS X 0401)
            都道府県は2桁 (例: "01"=北海道, "13"=東京都)
            市区町村は5桁 (例: "01101"=札幌市中央区, "13103"=東京都港区)
            国コード (ISO 3166-1 alpha-2) も指定可能 (例: "JP", "US")
        lat: 中心緯度 (世界測地系、例: 43.0644 = 札幌駅)
        lon: 中心経度 (例: 141.3470 = 札幌駅)
        dist: 検索距離 km (最大20、小数可)。lat/lonと併用必須。
        bbox: 矩形範囲。"左下経度,左下緯度,右上経度,右上緯度" 形式。
        sort: ソート順
            - "rating": 星の数順
            - "score": スコア順
            - "hybrid": 適合度・口コミ・評価のハイブリッド (デフォルト)
            - "review": 口コミ件数順
            - "kana": あいうえお順
            - "price": 金額順
            - "dist": 直線距離順 (lat/lon必須、geoより高速)
            - "geo": 球面三角法による距離順 (lat/lon必須、より正確)
            - "match": 適合度順
            "-rating" のように "-" を先頭に付けると降順。例: sort="-review"
        start: 取得開始位置 (1始まり、最大3000)
        results: 取得件数 (最大100)
        detail: 出力項目数
            - "simple": 最小限
            - "standard": 標準 (デフォルト)
            - "full": 全項目 (写真URL等含む)
        cid: カセットID。電話帳カセット = "d8a23e9e64a4c817227ab09858bc1330"
            未指定時は公開カセット全体が対象。
        open_param: 営業時間フィルタ
            - "now": 現在時刻に開店している施設
            - "5,19": 5日の19時に開店 (日付,時間)
            - "Mon,12": 月曜12時に開店 (曜日,時間。曜日はMon〜Sun)
        coupon: trueでクーポン利用可の店舗のみ
        parking: trueで駐車場ありの店舗のみ
        creditcard: trueでクレジットカード利用可の店舗のみ
        smoking: 喫煙可否 ("1"=禁煙, "2"=分煙, "3"=喫煙可、カンマ区切りで複数指定)
        reservation: "1" で予約可能な店舗のみ
        image: trueで画像があるデータのみ
        maxprice: 価格帯上限
        minprice: 価格帯下限
        group: "gid" を指定で同一店舗を名寄せ
        distinct: group=gid 時に false で重複レコード全表示

    Returns:
        APIレスポンス (YDF形式のJSON)。ResultInfo, Feature[] を含む dict。
    """
    # 必須条件チェック (APIに無駄なリクエストを投げる前に弾く)
    if not any([query, gc, ac, cid, (lat is not None and lon is not None)]):
        raise ValueError(
            "検索条件が不足しています。query / gc / ac / cid / (lat+lon) "
            "のいずれかを指定してください。"
        )

    if dist is not None and (lat is None or lon is None):
        raise ValueError("dist を指定する場合は lat と lon も必須です。")
    if dist is not None and not (0 < dist <= 20):
        raise ValueError("dist は 0 より大きく 20 以下で指定してください (km)。")

    if not (1 <= results <= 100):
        raise ValueError("results は 1 から 100 の範囲で指定してください。")
    if not (1 <= start <= 3000):
        raise ValueError("start は 1 から 3000 の範囲で指定してください。")

    valid_sorts = {"rating", "score", "hybrid", "review", "kana",
                   "price", "dist", "geo", "match"}
    sort_key = sort.lstrip("-")
    if sort_key not in valid_sorts:
        raise ValueError(
            f"sort は {sorted(valid_sorts)} のいずれか (任意で先頭に '-') を指定してください。"
        )

    if detail not in {"simple", "standard", "full"}:
        raise ValueError("detail は simple / standard / full のいずれかを指定してください。")

    # bool は Yahoo API では "true"/"false" 文字列を期待
    def _bool(v: Optional[bool]) -> Optional[str]:
        if v is None:
            return None
        return "true" if v else "false"

    params: dict[str, Any] = {
        "query": query,
        "gc": gc,
        "ac": ac,
        "lat": lat,
        "lon": lon,
        "dist": dist,
        "bbox": bbox,
        "sort": sort,
        "start": start,
        "results": results,
        "detail": detail,
        "cid": cid,
        "open": open_param,
        "coupon": _bool(coupon),
        "parking": _bool(parking),
        "creditcard": _bool(creditcard),
        "smoking": smoking,
        "reservation": reservation,
        "image": _bool(image),
        "maxprice": maxprice,
        "minprice": minprice,
        "group": group,
        "distinct": _bool(distinct),
    }

    return _request(params)


@mcp.tool()
def search_by_genre(
    gc: str,
    ac: Optional[str] = None,
    query: Optional[str] = None,
    lat: Optional[float] = None,
    lon: Optional[float] = None,
    dist: Optional[float] = None,
    sort: str = "hybrid",
    results: int = 20,
    detail: str = "standard",
    use_phonebook: bool = True,
) -> dict[str, Any]:
    """業種コード (gc) を軸に店舗を検索 (search_local の薄いラッパー)。

    YOLP業種コードの代表例:
        - "01"          : グルメ全般
        - "0118008"     : 焼肉/ホルモン
        - "0117001"     : 寿司
        - "01170011"    : 回転寿司
        - "0107001"     : 居酒屋
        - "0202"        : スーパーマーケット
        - "020201"      : コンビニエンスストア
        - "0203001"     : 百貨店・デパート
        - "030201"      : ホテル
    完全な一覧:
        https://developer.yahoo.co.jp/webapi/map/openlocalplatform/genre.html

    Args:
        gc: 業種コード (必須)
        ac: 住所コードで地域を絞り込む (例: "01"=北海道, "01101"=札幌市中央区)
        query: 追加のキーワード絞り込み (例: 業種=焼肉 + query="ジンギスカン")
        lat, lon, dist: 緯度経度+半径km (距離順検索したい時に有効)
        sort: ソート順 (デフォルト "hybrid"。距離順なら "geo")
        results: 取得件数 (最大100)
        detail: simple / standard / full
        use_phonebook: True で電話帳カセットに限定する (デフォルト True、データ品質安定)

    Returns:
        APIレスポンス (YDF形式のJSON)。
    """
    cid = PHONEBOOK_CASSETTE_ID if use_phonebook else None
    return search_local(
        query=query,
        gc=gc,
        ac=ac,
        lat=lat,
        lon=lon,
        dist=dist,
        sort=sort,
        results=results,
        detail=detail,
        cid=cid,
    )


@mcp.tool()
def search_nearby(
    lat: float,
    lon: float,
    dist: float = 1.0,
    query: Optional[str] = None,
    gc: Optional[str] = None,
    sort: str = "geo",
    results: int = 20,
    detail: str = "standard",
    use_phonebook: bool = True,
) -> dict[str, Any]:
    """指定緯度経度の中心から半径dist km以内の店舗を検索 (search_localの薄いラッパー)。

    主な用途:
        - 取引先住所をジオコーディングした後、その周辺の競合店・関連店舗を発掘
        - 営業エリアの店舗密度調査
        - イベント会場 (例: Food Taipei 会場) 周辺の飲食店リスト化

    Args:
        lat: 中心緯度 (世界測地系)
        lon: 中心経度
        dist: 検索半径 km (デフォルト1.0、最大20.0)
        query: キーワード絞り込み (例: "ラーメン")
        gc: 業種コード絞り込み (例: "0118008"=焼肉)
        sort: ソート順 (デフォルト "geo" = 距離順)
        results: 取得件数 (最大100)
        detail: simple / standard / full
        use_phonebook: True で電話帳カセットに限定 (デフォルト True)

    Returns:
        APIレスポンス (YDF形式のJSON)。
    """
    cid = PHONEBOOK_CASSETTE_ID if use_phonebook else None
    return search_local(
        query=query,
        gc=gc,
        lat=lat,
        lon=lon,
        dist=dist,
        sort=sort,
        results=results,
        detail=detail,
        cid=cid,
    )


# --------------------------------------------------------------------------- #
# エントリポイント
# --------------------------------------------------------------------------- #

if __name__ == "__main__":
    mcp.run()


def main() -> None:
    """Entry point for uvx execution."""
    mcp.run()


if __name__ == "__main__":
    main()