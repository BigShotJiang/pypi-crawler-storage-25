def main() -> None:
    """Entry point for uvx execution."""
    mcp.run()


if __name__ == "__main__":
    main()