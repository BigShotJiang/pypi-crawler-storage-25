"""Primary runner: async wrapper around claude_agent_sdk.ClaudeSDKClient.

Handles RateLimitEvent processing, overage abort, and session resume.
Non-negotiables: #1 (strip env), #3 (bypassPermissions), #4 (overage abort).
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

from code_generator import env as _env
from code_generator.runner.message_parsing import (
    extract_text,
    extract_usage,
    handle_rate_limit_event,
    is_assistant_message,
    is_context_edit_message,
    is_rate_limit_event,
    is_result_message,
)
from code_generator.runner.types import (
    ApiUpstreamError,
    MaxTurnsExceeded,
    OverageAbort,
    RateLimitHit,
    RunResult,
    TokenUsage,
)
from code_generator.runner.utils import looks_like_upstream_5xx

if TYPE_CHECKING:
    import logging
    from pathlib import Path

# Guard SDK import so the module can be loaded without the SDK installed
# (used by get_runner() to detect availability).
try:
    from claude_agent_sdk import (
        AssistantMessage,
        ClaudeSDKClient,
        ResultMessage,
        TextBlock,
    )
    from claude_agent_sdk.types import RateLimitEvent

    _SDK_AVAILABLE = True
except ImportError:  # pragma: no cover
    _SDK_AVAILABLE = False
    # Provide sentinel names so type checkers and duck-typed tests still work.
    ClaudeSDKClient = None  # type: ignore[assignment,misc]
    AssistantMessage = None  # type: ignore[assignment,misc]
    ResultMessage = None  # type: ignore[assignment,misc]
    TextBlock = None  # type: ignore[assignment,misc]
    RateLimitEvent = None  # type: ignore[assignment,misc]


# ---------------------------------------------------------------------------
# Re-exports for backward compatibility
# ---------------------------------------------------------------------------
# These names were originally defined here.  External code that imports them
# from sdk_runner continues to work without modification.
__all__ = [
    "ApiUpstreamError",
    "MaxTurnsExceeded",
    "OverageAbort",
    "RateLimitHit",
    "RunResult",
    "run_with_shared_client",
]

# Backward-compatible private aliases — test_sdk_runner.py imports these names.
_extract_text = extract_text
_extract_usage = extract_usage
_handle_rate_limit_event = handle_rate_limit_event
_is_rate_limit_event = is_rate_limit_event
_is_assistant_message = is_assistant_message
_is_result_message = is_result_message


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


async def _drain_messages(
    client: Any,
    logger: logging.Logger,
    state_path: Path,
    msg_count_start: int = 0,
) -> tuple[str, str | None, TokenUsage]:
    """Drain all messages from *client.receive_messages()* and return results.

    Shared by both ``run()`` and ``run_with_shared_client()``.  Handles
    RateLimitEvent, AssistantMessage, and ResultMessage with the same
    token-accounting, overage-abort, and error-raising logic.

    Args:
        client: An open SDK client (duck-typed) with ``receive_messages()``.
        logger: Phase logger for rate-limit warnings and debug output.
        state_path: Path to state.json used for pause persistence.
        msg_count_start: Offset for message numbering in log lines.

    Returns:
        A 3-tuple of ``(accumulated_text, session_id, usage)``.

    Raises:
        MaxTurnsExceeded: When the session exhausted its ``max_turns`` budget.
        ApiUpstreamError: When the upstream returned an error result.
        OverageAbort: When overage billing is detected.
        RateLimitHit: When the rate limit is rejected.
    """
    text_parts: list[str] = []
    session_id: str | None = None
    usage: TokenUsage | None = None
    msg_count = msg_count_start

    async for msg in client.receive_messages():
        msg_count += 1
        # Detect message type by duck-typing on attributes rather than
        # isinstance() so fake test objects work without SDK installed.
        if is_rate_limit_event(msg):
            logger.info("msg #%d: RateLimitEvent", msg_count)
            handle_rate_limit_event(msg, logger, state_path)
            continue

        if is_context_edit_message(msg):
            msg_type = getattr(msg, "type", type(msg).__name__)
            freed_tokens = getattr(msg, "freed_tokens", None)
            logger.info(
                "Phase 3/4: context edit triggered — type=%s freed_tokens=%s",
                msg_type,
                freed_tokens,
            )
            # Intermediate message — the receive_messages() generator continues.

        elif is_assistant_message(msg):
            chunk = extract_text(msg)
            text_parts.append(chunk)
            if chunk.strip():
                logger.info(
                    "msg #%d: assistant (%d chars)\n%s",
                    msg_count,
                    len(chunk),
                    chunk.rstrip(),
                )
            else:
                logger.debug("msg #%d: assistant (empty)", msg_count)
            # Some SDK versions attach session_id to AssistantMessage.
            if session_id is None:
                session_id = getattr(msg, "session_id", None)

        elif is_result_message(msg):
            session_id = getattr(msg, "session_id", session_id)
            usage = extract_usage(msg)
            is_error = bool(getattr(msg, "is_error", False))
            # Per Anthropic docs: the SDK signals terminal failure modes
            # via ResultMessage.subtype, not stop_reason. stop_reason
            # carries the model's own stop reason from the last assistant
            # response (end_turn | max_tokens | refusal | tool_use) and
            # does NOT indicate why the agent loop terminated.
            # Canonical subtypes: success | error_max_turns |
            # error_max_budget_usd | error_during_execution |
            # error_max_structured_output_retries.
            subtype = getattr(msg, "subtype", None)
            stop_reason = getattr(msg, "stop_reason", None)
            num_turns = getattr(msg, "num_turns", None)
            logger.info(
                "msg #%d: ResultMessage "
                "(tokens_in=%s tokens_out=%s cache_read=%s cache_write=%s "
                "is_error=%s subtype=%s stop_reason=%s num_turns=%s)",
                msg_count,
                usage.input,
                usage.output,
                usage.cache_read,
                usage.cache_write,
                is_error,
                subtype,
                stop_reason,
                num_turns,
            )
            if subtype == "error_max_turns":
                logger.error(
                    "MaxTurnsExceeded fired but no call site should set max_turns. "
                    "Check for operator override (--max-turns), SDK/CLI default, "
                    "or rogue fixture. num_turns=%s tokens_in=%s tokens_out=%s",
                    num_turns,
                    usage.input,
                    usage.output,
                )
                raise MaxTurnsExceeded(
                    f"SDK session exhausted max_turns budget "
                    f"(subtype={subtype}, num_turns={num_turns}, "
                    f"tokens_in={usage.input}, tokens_out={usage.output})"
                )
            accumulated = "".join(text_parts)
            if is_error or looks_like_upstream_5xx(accumulated):
                tail = text_parts[-1][:200] if text_parts else "<empty>"
                raise ApiUpstreamError(
                    f"Upstream error (is_error={is_error}, subtype={subtype}, "
                    f"stop_reason={stop_reason}, tokens_in={usage.input}, "
                    f"tokens_out={usage.output}): {tail}"
                )
            break
        else:
            logger.debug("msg #%d: %s", msg_count, type(msg).__name__)

    return "".join(text_parts), session_id, usage or TokenUsage()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def run(
    prompt: str,
    options: Any,
    *,
    logger: logging.Logger,
    state_path: Path,
) -> RunResult:
    """Run a prompt via ClaudeSDKClient and return the accumulated result.

    Non-negotiable #1: strips dangerous env vars at the start of every call.
    Non-negotiable #3: forces permission_mode to bypassPermissions.

    Args:
        prompt: The prompt text to send.
        options: ClaudeAgentOptions (or duck-typed equivalent).
        logger: Phase logger for rate-limit warnings and debug output.
        state_path: Path to state.json used for pause persistence.

    Returns:
        RunResult with accumulated text, session_id, and token counts.

    Raises:
        OverageAbort: When overage billing is detected.
        RateLimitHit: When the rate limit is rejected.
    """
    # Non-negotiable #1 — strip dangerous env vars on every invocation.
    _env.strip_dangerous_env()

    # Non-negotiable #3 — always force bypassPermissions; never trust caller.
    options.permission_mode = "bypassPermissions"

    # Plumb effort through to output_config when explicitly set (Issue #68).
    effort = getattr(options, "effort", None)
    if effort:
        options.output_config = {"effort": effort}

    # INVARIANT: any log line with model= must also have effort=
    logger.info(
        "SDK session starting (model=%s effort=%s max_turns=%s).",
        getattr(options, "model", "?"),
        getattr(options, "effort", None) or "default",
        getattr(options, "max_turns", "?"),
    )

    t0 = time.monotonic()
    async with ClaudeSDKClient(options=options) as client:
        await client.query(prompt)
        text, session_id, usage = await _drain_messages(client, logger, state_path)
    wall_seconds = time.monotonic() - t0

    logger.info("SDK session complete.")

    return RunResult(text=text, session_id=session_id, usage=usage, wall_seconds=wall_seconds)


async def run_with_shared_client(
    client: Any,
    prompt: str,
    options: Any,
    *,
    logger: logging.Logger,
    state_path: Path,
) -> RunResult:
    """Run a prompt on an already-open ClaudeSDKClient and return the result.

    Unlike ``run()``, this function:
    - Does **not** open or close the client (lifecycle is caller-owned).
    - Does **not** strip env vars (done once per process at cycle start).
    - Does **not** set ``options.permission_mode`` (already set on the client).

    The token-accounting, rate-limit, overage-abort, and error-handling
    logic is identical to ``run()`` via the shared ``_drain_messages()``
    helper.  Callers cannot tell which runner produced a given ``RunResult``.

    Args:
        client: An already-open ``ClaudeSDKClient`` (or duck-typed equivalent)
            managed by the caller (e.g. ``cycle_loop``).
        prompt: The prompt text to send.
        options: ClaudeAgentOptions (or duck-typed equivalent); used only for
            logging — permission_mode and env vars are the caller's concern.
        logger: Phase logger for rate-limit warnings and debug output.
        state_path: Path to state.json used for pause persistence.

    Returns:
        RunResult with accumulated text, session_id, and token counts.

    Raises:
        MaxTurnsExceeded: When the session exhausted its ``max_turns`` budget.
        ApiUpstreamError: When the upstream returned an error result.
        OverageAbort: When overage billing is detected.
        RateLimitHit: When the rate limit is rejected.
    """
    logger.info(
        "SDK shared-client session starting (model=%s effort=%s max_turns=%s).",
        getattr(options, "model", "?"),
        getattr(options, "effort", None) or "default",
        getattr(options, "max_turns", "?"),
    )

    t0 = time.monotonic()
    await client.query(prompt)
    text, session_id, usage = await _drain_messages(client, logger, state_path)
    wall_seconds = time.monotonic() - t0

    logger.info("SDK shared-client session complete.")

    return RunResult(text=text, session_id=session_id, usage=usage, wall_seconds=wall_seconds)
