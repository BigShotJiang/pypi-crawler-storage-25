"""Cache telemetry accumulation for the runner layer.

Single responsibility: maintain the six-key ``cache_telemetry`` dict that
lives on :class:`~code_generator.state.CycleState` and is surfaced by
``code-generator status`` via the §16 'Cache hit %' column.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from code_generator.runner.types import TokenUsage


def accumulate_telemetry(
    telemetry: dict[str, int | float],
    usage: TokenUsage,
    wall_seconds: float,
) -> None:
    """Add *usage* counters and *wall_seconds* to *telemetry* in place.

    Recomputes ``cache_hit_pct`` after every update:

        ``cache_read / (cache_read + cache_write + input) × 100``

    rounded to one decimal place. Emits ``0.0`` when the denominator is
    zero so callers never need to guard against ``NaN`` or ``ZeroDivisionError``.

    Args:
        telemetry: The ``CycleState.cache_telemetry`` dict to mutate —
            the six-key dict produced by
            :func:`~code_generator.state._default_cache_telemetry`.
        usage: Token counters from a single SDK/subprocess result message.
        wall_seconds: Elapsed wall-clock seconds for this call to add.
    """
    telemetry["input"] += usage.input
    telemetry["output"] += usage.output
    telemetry["cache_read"] += usage.cache_read
    telemetry["cache_write"] += usage.cache_write
    telemetry["wall_seconds"] = float(telemetry["wall_seconds"]) + wall_seconds

    denominator = telemetry["cache_read"] + telemetry["cache_write"] + telemetry["input"]
    if denominator > 0:
        telemetry["cache_hit_pct"] = round(float(telemetry["cache_read"]) / denominator * 100, 1)
    else:
        telemetry["cache_hit_pct"] = 0.0
