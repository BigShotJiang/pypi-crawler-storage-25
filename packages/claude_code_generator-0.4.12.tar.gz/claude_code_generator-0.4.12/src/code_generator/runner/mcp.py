"""MCP server config builders for code-generator phases.

Provides stdio transport config dicts for the Codebase-Memory MCP server
(primary) and Serena (fallback).  Downstream phases pass the result directly
as ``mcp_servers=build_mcp_servers(repo_path)`` into ``make_agent_options``.

External binary install
-----------------------
Codebase-Memory (Rust single-binary):
    cargo install codebase-memory-mcp
    # or
    brew install codebase-memory-mcp  # when available on homebrew

Serena (Python MCP server):
    pip install serena
    # or
    uvx serena  # zero-install via uv

When neither binary is on ``$PATH``, ``build_mcp_servers`` returns ``None``
and emits a single WARNING log — the cycle continues without MCP assistance.
"""

from __future__ import annotations

import logging
import shutil
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

_logger = logging.getLogger(__name__)

_CODEBASE_MEMORY_BIN = "codebase-memory-mcp"
_SERENA_BIN = "serena"


def build_codebase_memory_server_config(repo_path: Path) -> dict | None:
    """Return a stdio MCP server config for codebase-memory-mcp, or None if absent.

    Args:
        repo_path: Absolute path to the repository root to index.

    Returns:
        A dict with ``type``, ``command``, and ``args`` keys suitable for
        ``ClaudeAgentOptions.mcp_servers``, or ``None`` when the binary is not
        found or any unexpected error occurs.
    """
    try:
        binary = shutil.which(_CODEBASE_MEMORY_BIN)
    except Exception:
        return None
    if binary is None:
        return None
    return {"type": "stdio", "command": binary, "args": [str(repo_path)]}


def build_serena_server_config(repo_path: Path) -> dict | None:
    """Return a stdio MCP server config for Serena, or None if absent.

    Args:
        repo_path: Absolute path to the repository root to index.

    Returns:
        A dict with ``type``, ``command``, and ``args`` keys suitable for
        ``ClaudeAgentOptions.mcp_servers``, or ``None`` when the binary is not
        found or any unexpected error occurs.
    """
    try:
        binary = shutil.which(_SERENA_BIN)
    except Exception:
        return None
    if binary is None:
        return None
    return {"type": "stdio", "command": binary, "args": [str(repo_path)]}


def build_mcp_servers(repo_path: Path) -> dict[str, dict] | None:
    """Return an MCP servers mapping for ``ClaudeAgentOptions``, or None.

    Tries Codebase-Memory first; falls back to Serena; returns ``None`` when
    neither binary is on ``$PATH``.  Emits exactly one WARNING per call when
    both are missing — never aborts the cycle.

    Args:
        repo_path: Absolute path to the repository root to index.

    Returns:
        A ``dict[str, dict]`` with one entry keyed on the available server
        name (``"codebase_memory"`` or ``"serena"``), or ``None`` when neither
        is available.
    """
    codebase_memory = build_codebase_memory_server_config(repo_path)
    if codebase_memory is not None:
        return {"codebase_memory": codebase_memory}

    serena = build_serena_server_config(repo_path)
    if serena is not None:
        return {"serena": serena}

    _logger.warning(
        "mcp: neither %r nor %r found on PATH; proceeding without MCP code-navigation",
        _CODEBASE_MEMORY_BIN,
        _SERENA_BIN,
    )
    return None


def mcp_tool_wildcards(mcp_servers: dict[str, dict] | None) -> list[str]:
    """Return ``allowed_tools`` wildcard entries for the given *mcp_servers* dict.

    Each key in *mcp_servers* contributes one wildcard entry of the form
    ``mcp__<name>__*`` so the agent may call any tool exposed by that server
    without enumerating them individually.

    Args:
        mcp_servers: The dict returned by :func:`build_mcp_servers`, or ``None``.

    Returns:
        A list of wildcard tool strings, e.g. ``["mcp__codebase_memory__*"]``,
        or an empty list when *mcp_servers* is ``None`` or empty.
    """
    if not mcp_servers:
        return []
    return [f"mcp__{name}__*" for name in mcp_servers]
