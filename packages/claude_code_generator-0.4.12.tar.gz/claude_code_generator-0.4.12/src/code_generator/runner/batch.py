"""Anthropic Messages Batches API runner.

Implements ``submit_batch`` / ``poll_batch`` against the anthropic>=0.35
Messages Batches API. Gated behind the ``[batch]`` optional extra — raises
``BatchDependencyMissing`` when the ``anthropic`` package is not installed.

OAuth limitation
----------------
The Anthropic SDK authenticates via ``ANTHROPIC_API_KEY`` by default. In
code-generator's environment, non-negotiable #1 strips that key before every
runner invocation. The ``AsyncAnthropic`` client falls back to
``ANTHROPIC_AUTH_TOKEN`` (Claude.ai OAuth token) when present. If neither
credential is available at runtime, ``submit_batch`` / ``poll_batch`` will
raise ``BatchSubmitError`` wrapping the SDK's ``AuthenticationError``.

Operators who enable ``--session-mode batch`` (Issue #198) must ensure
``ANTHROPIC_AUTH_TOKEN`` is set in their environment. Do **not** introduce an
``ANTHROPIC_API_KEY`` path here — that would violate non-negotiable #1.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any, NewType

# ---------------------------------------------------------------------------
# Guarded import — module loads cleanly without anthropic installed
# ---------------------------------------------------------------------------

try:
    import anthropic as _anthropic

    _ANTHROPIC_AVAILABLE = True
except ImportError:  # pragma: no cover
    _ANTHROPIC_AVAILABLE = False

# ---------------------------------------------------------------------------
# Domain types
# ---------------------------------------------------------------------------

BatchId = NewType("BatchId", str)
"""Opaque identifier returned by the Batches API for a submitted batch."""


@dataclass
class BatchRequest:
    """A single request to include in a batch submission.

    Args:
        custom_id: Caller-assigned identifier — echoed back in BatchResult.
        params: Anthropic message params (model, max_tokens, messages, …).
    """

    custom_id: str
    params: dict[str, Any]


@dataclass
class BatchResult:
    """Result for a single request from a completed batch.

    Args:
        custom_id: Matches the custom_id from the originating BatchRequest.
        result: Raw Anthropic result object from the batch response.
    """

    custom_id: str
    result: Any


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class BatchDependencyMissing(ImportError):
    """Raised when the ``anthropic`` package is not installed.

    Install hint included in the message so operators know exactly what to do.
    """


class BatchSubmitError(RuntimeError):
    """Raised when the batch submission fails (auth error, network error, …)."""


class BatchPollError(RuntimeError):
    """Raised when a batch status poll fails."""


# ---------------------------------------------------------------------------
# Private constants
# ---------------------------------------------------------------------------

_POLL_INITIAL_S: float = 5.0
_POLL_MAX_S: float = 60.0

# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _require_anthropic() -> None:
    """Raise BatchDependencyMissing if anthropic is not installed."""
    if not _ANTHROPIC_AVAILABLE:
        raise BatchDependencyMissing(
            "anthropic package not found. "
            'Install it with: pip install "claude-code-generator[batch]"'
        )


def _make_client() -> Any:
    """Create and return an AsyncAnthropic client."""
    return _anthropic.AsyncAnthropic()


def _to_api_request(req: BatchRequest) -> dict[str, Any]:
    """Convert a BatchRequest into the dict form the Batches API expects."""
    return {"custom_id": req.custom_id, "params": req.params}


async def _collect_results(client: Any, batch_id: BatchId) -> list[BatchResult]:
    """Stream all results from an ended batch and return them as a list."""
    results: list[BatchResult] = []
    async for item in client.messages.batches.results(batch_id):
        results.append(BatchResult(custom_id=item.custom_id, result=item.result))
    return results


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def submit_batch(requests: list[BatchRequest]) -> BatchId:
    """Submit a list of requests to the Anthropic Messages Batches API.

    Args:
        requests: List of :class:`BatchRequest` objects to submit.

    Returns:
        :class:`BatchId` that identifies the batch for polling.

    Raises:
        BatchDependencyMissing: When the ``anthropic`` package is absent.
        BatchSubmitError: When submission fails (auth, network, validation).
    """
    _require_anthropic()
    client = _make_client()
    try:
        batch = await client.messages.batches.create(
            requests=[_to_api_request(r) for r in requests]
        )
        return BatchId(batch.id)
    except Exception as exc:
        raise BatchSubmitError(f"Batch submission failed: {exc}") from exc


async def poll_batch(
    batch_id: BatchId,
    timeout_s: int = 3600,
) -> list[BatchResult]:
    """Poll a batch until it ends, then return all results.

    Polls with exponential backoff starting at ``_POLL_INITIAL_S`` seconds,
    doubling each attempt up to ``_POLL_MAX_S`` seconds. Raises
    :class:`TimeoutError` when ``timeout_s`` elapses before the batch ends.

    Args:
        batch_id: The :class:`BatchId` from a prior :func:`submit_batch` call.
        timeout_s: Maximum wall-clock seconds to wait (default 3600).

    Returns:
        List of :class:`BatchResult` in arrival order.

    Raises:
        BatchDependencyMissing: When the ``anthropic`` package is absent.
        BatchPollError: When a status poll call fails.
        TimeoutError: When ``timeout_s`` is reached before the batch ends.
    """
    _require_anthropic()
    client = _make_client()
    deadline = time.monotonic() + timeout_s
    delay = _POLL_INITIAL_S

    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(f"Batch {batch_id!r} did not complete within {timeout_s}s")
        try:
            batch = await client.messages.batches.retrieve(batch_id)
        except Exception as exc:
            raise BatchPollError(f"Batch poll failed: {exc}") from exc

        if batch.processing_status == "ended":
            return await _collect_results(client, batch_id)

        await asyncio.sleep(min(delay, remaining))
        delay = min(delay * 2, _POLL_MAX_S)
