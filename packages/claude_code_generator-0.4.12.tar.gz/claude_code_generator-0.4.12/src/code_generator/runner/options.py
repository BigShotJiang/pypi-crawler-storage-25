"""Centralised factory for ClaudeAgentOptions.

Eliminates the try/except import-with-fallback boilerplate that was duplicated
across every phase module and commands/review.py.  Call `make_agent_options`
once with the desired keyword arguments; it returns either the real
ClaudeAgentOptions (when claude_agent_sdk is installed) or a lightweight
duck-typed fallback that exposes the same attributes.
"""

from __future__ import annotations

import logging
import warnings
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Iterable

_DEFAULT_BETAS: frozenset[str] = frozenset(
    {"extended-cache-ttl-2025-04-11", "token-efficient-tools-2025-02-19"}
)
_TASK_BUDGET_BETA = "task-budgets-2026-03-13"

_DEFAULT_CACHE_CONTROL: dict[str, str] = {"type": "ephemeral", "ttl": "1h"}
_FALLBACK_CACHE_TTL = "5m"

_CONTEXT_MANAGEMENT_INPUT_TOKENS = 150_000
_CONTEXT_MANAGEMENT_TOOL_USE_KEEP = 3

# Module-level cache so the SDK probe runs at most once (avoids WARNING-spam).
_ttl_probe_result: str | None = None

# Per-process startup log: fires once to confirm the effective feature mix (§18).
_startup_logged: bool = False

# Feature names used by the retry loop (§18).
_FEATURE_BETA_EXTENDED_CACHE = "extended-cache-ttl-2025-04-11"
_FEATURE_BETA_TASK_BUDGET = "task-budgets-2026-03-13"
_FEATURE_CONTEXT_MANAGEMENT = "context_management"
_FEATURE_EXCLUDE_DYNAMIC = "exclude_dynamic_sections"

# Ordered sequence of features the retry loop will attempt to drop (most experimental first).
_DROPPABLE_FEATURES: tuple[str, ...] = (
    _FEATURE_BETA_EXTENDED_CACHE,
    _FEATURE_BETA_TASK_BUDGET,
    _FEATURE_CONTEXT_MANAGEMENT,
    _FEATURE_EXCLUDE_DYNAMIC,
)

# Human-readable fallback description per feature (used in WARNING messages).
_FEATURE_FALLBACK_DESC: dict[str, str] = {
    _FEATURE_BETA_EXTENDED_CACHE: "ttl='5m'",
    _FEATURE_BETA_TASK_BUDGET: "no task budget",
    _FEATURE_CONTEXT_MANAGEMENT: "no context management",
    _FEATURE_EXCLUDE_DYNAMIC: "no exclude_dynamic_sections",
}

# Keywords that indicate a feature-rejection error (conservative match per §18).
_REJECTION_SIGNALS: frozenset[str] = frozenset(
    {"anthropic_beta", "not supported", "unknown keyword"}
)

# Per-process cache: features whose WARNING has already been emitted (avoids spam in retries).
_warned_features: set[str] = set()

_logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Feature-detection helpers (§18 retry loop)
# ---------------------------------------------------------------------------


def _is_feature_rejection(exc: Exception) -> bool:
    """Return True when *exc* looks like a feature-rejection signal from the SDK."""
    msg = str(exc).lower()
    return any(signal in msg for signal in _REJECTION_SIGNALS)


def _identify_rejected_feature(exc: Exception) -> str | None:
    """Return the name of the rejected feature embedded in *exc*'s message, or None."""
    msg = str(exc)
    for feature in _DROPPABLE_FEATURES:
        if feature in msg:
            return feature
    return None


def _warn_feature_once(feature: str) -> None:
    """Emit a WARNING for *feature* at most once per process (module-level guard)."""
    if feature in _warned_features:
        return
    _warned_features.add(feature)
    desc = _FEATURE_FALLBACK_DESC.get(feature, "unknown fallback")
    _logger.warning("runner: feature %r rejected by SDK, falling back to %s", feature, desc)


def _drop_feature(
    feature: str,
    headers: dict[str, str],
    cache_control: dict,
    system_prompt: dict | str,
    output_config: dict | None,
    context_management: dict | None,
) -> tuple[dict[str, str], dict, dict | str, dict | None, dict | None]:
    """Return updated state with *feature* removed and its fallback applied."""
    _warn_feature_once(feature)
    if feature == _FEATURE_BETA_EXTENDED_CACHE:
        betas = set(filter(None, headers.get("anthropic-beta", "").split(",")))
        betas.discard(feature)
        return (
            {**headers, "anthropic-beta": build_beta_header(betas)},
            {"type": "ephemeral", "ttl": _FALLBACK_CACHE_TTL},
            system_prompt,
            output_config,
            context_management,
        )
    if feature == _FEATURE_BETA_TASK_BUDGET:
        betas = set(filter(None, headers.get("anthropic-beta", "").split(",")))
        betas.discard(feature)
        new_output: dict | None = (
            {k: v for k, v in output_config.items() if k != "task_budget"} or None
            if output_config is not None
            else None
        )
        return (
            {**headers, "anthropic-beta": build_beta_header(betas)},
            cache_control,
            system_prompt,
            new_output,
            context_management,
        )
    if feature == _FEATURE_CONTEXT_MANAGEMENT:
        return headers, cache_control, system_prompt, output_config, None
    if feature == _FEATURE_EXCLUDE_DYNAMIC:
        new_sp: dict | str = (
            {k: v for k, v in system_prompt.items() if k != "exclude_dynamic_sections"}
            if isinstance(system_prompt, dict)
            else system_prompt
        )
        return headers, cache_control, new_sp, output_config, context_management
    # Unknown feature — return state unchanged (caller will re-raise)
    return headers, cache_control, system_prompt, output_config, context_management


def _try_construct(
    sdk_cls: Any,
    *,
    allowed_tools: list[str],
    extra_headers: dict[str, str],
    cache_control: dict,
    system_prompt: dict | str,
    output_config: dict | None,
    context_management: dict | None,
    thinking: dict | None,
    mcp_servers: dict | None,
    **kwargs: Any,
) -> Any:
    """One construction attempt; raises on SDK rejection for the retry loop."""
    opts = sdk_cls(allowed_tools=allowed_tools, **kwargs)
    opts.extra_headers = extra_headers  # type: ignore[attr-defined]
    opts.cache_control = cache_control  # type: ignore[attr-defined]
    opts.system_prompt = system_prompt  # type: ignore[attr-defined]
    opts.thinking = thinking  # type: ignore[attr-defined]
    opts.output_config = output_config  # type: ignore[attr-defined]
    opts.context_management = context_management  # type: ignore[attr-defined]
    opts.mcp_servers = mcp_servers  # type: ignore[attr-defined]
    return opts


def _build_with_retry(
    sdk_cls: Any,
    *,
    allowed_tools: list[str],
    extra_headers: dict[str, str],
    cache_control: dict,
    system_prompt: dict | str,
    output_config: dict | None,
    context_management: dict | None,
    thinking: dict | None,
    mcp_servers: dict | None,
    **kwargs: Any,
) -> Any:
    """Construct ClaudeAgentOptions with a retry loop that drops rejected features."""
    headers = extra_headers
    cc = cache_control
    sp = system_prompt
    oc = output_config
    cm = context_management

    for _ in range(len(_DROPPABLE_FEATURES) + 1):
        try:
            return _try_construct(
                sdk_cls,
                allowed_tools=allowed_tools,
                extra_headers=headers,
                cache_control=cc,
                system_prompt=sp,
                output_config=oc,
                context_management=cm,
                thinking=thinking,
                mcp_servers=mcp_servers,
                **kwargs,
            )
        except (TypeError, ValueError) as exc:
            if not _is_feature_rejection(exc):
                raise
            feature = _identify_rejected_feature(exc)
            if feature is None:
                raise
            headers, cc, sp, oc, cm = _drop_feature(feature, headers, cc, sp, oc, cm)

    raise RuntimeError("Feature-detection retry loop exhausted; all features dropped")


def probe_cache_ttl_support(logger: logging.Logger) -> str:
    """Probe whether the SDK accepts ttl='1h' in cache_control; cache result module-level.

    Runs the probe exactly once per process (module reload resets the cache).
    Returns ``'1h'`` when the SDK accepts the value; returns ``'5m'`` and emits
    a WARNING when the SDK raises ``TypeError`` or ``ValueError``.

    Args:
        logger: Logger used to emit the WARNING on fallback.

    Returns:
        The supported TTL string: ``'1h'`` or ``'5m'``.
    """
    global _ttl_probe_result  # noqa: PLW0603
    if _ttl_probe_result is not None:
        return _ttl_probe_result

    try:
        from claude_agent_sdk import ClaudeAgentOptions  # type: ignore[import-not-found]

        ClaudeAgentOptions(allowed_tools=[], cache_control=_DEFAULT_CACHE_CONTROL)
        _ttl_probe_result = "1h"
    except (TypeError, ValueError):
        logger.warning(
            "SDK rejected cache_control ttl='1h'; falling back to ttl='5m'. "
            "Upgrade claude-agent-sdk to restore 1h cache lifetime."
        )
        _ttl_probe_result = _FALLBACK_CACHE_TTL
    except ImportError:
        _ttl_probe_result = "1h"

    return _ttl_probe_result


def build_beta_header(betas: Iterable[str]) -> str:
    """Return a comma-joined, alphabetically-sorted string of beta feature names.

    Args:
        betas: Any iterable of beta feature name strings.

    Returns:
        A single string with all beta names joined by commas in sorted order.
    """
    return ",".join(sorted(betas))


def build_context_management_block() -> dict:
    """Return the canonical context-management block for Phase 3/4 sessions (§3).

    The block enables server-side compaction (``compact_20260112``) when input
    tokens exceed 150 000 and clears the three most-recent tool-use groups
    (``clear_tool_uses_20260112``) to bound context growth across long agentic
    turns.

    Returns:
        A 2-key dict with ``"edits"`` and ``"tools"`` lists ready to be passed
        as the ``context_management`` attribute of ``ClaudeAgentOptions``.
    """
    return {
        "edits": [
            {
                "type": "compact_20260112",
                "trigger": {"type": "input_tokens", "value": _CONTEXT_MANAGEMENT_INPUT_TOKENS},
            }
        ],
        "tools": [
            {
                "type": "clear_tool_uses_20260112",
                "keep": {"type": "tool_uses", "value": _CONTEXT_MANAGEMENT_TOOL_USE_KEEP},
            }
        ],
    }


def build_system_prompt(append: str = "") -> dict:
    """Return the canonical Claude Code SystemPromptPreset dict.

    The returned dict instructs the SDK to use the shared ``claude_code`` preset
    while excluding volatile dynamic sections (cwd, memory, git status) so the
    cache prefix remains byte-identical across consecutive sessions (§2).

    Args:
        append: Optional string appended after the preset's base system prompt.
            Defaults to an empty string.

    Returns:
        A 4-key dict: ``{"type": "preset", "preset": "claude_code",
        "append": append, "exclude_dynamic_sections": True}``.
    """
    return {
        "type": "preset",
        "preset": "claude_code",
        "append": append,
        "exclude_dynamic_sections": True,
    }


def max_turns_kwargs(max_turns: int | None) -> dict[str, Any]:
    """Return ``{"max_turns": N}`` when *max_turns* is set, else ``{}`` (#210).

    Splats into a :func:`make_agent_options` call so operators can opt in to a
    turn cap via ``--max-turns`` without the no-flag path silently passing
    ``max_turns=None`` (which would re-open the silent-default trap).

    Args:
        max_turns: Optional turn cap from the ``--max-turns`` CLI flag.

    Returns:
        A kwargs dict with a single ``max_turns`` entry, or an empty dict.
        Typed as ``dict[str, Any]`` so ``**max_turns_kwargs(...)`` splats
        cleanly into :func:`make_agent_options` without pyright trying to
        match against the named kwargs on that signature.
    """
    return {} if max_turns is None else {"max_turns": max_turns}


def make_agent_options(
    *,
    allowed_tools: list[str],
    extra_headers: dict[str, str] | None = None,
    cache_control: dict | None = None,
    system_prompt: dict | str | None = None,
    thinking: dict | None = None,
    output_config: dict | None = None,
    task_budget: int | None = None,
    context_management: dict | None = None,
    context_management_enabled: bool = False,
    mcp_servers: dict | None = None,
    **kwargs: Any,
) -> Any:
    """Return a ClaudeAgentOptions-compatible object populated with *kwargs*.

    When ``claude_agent_sdk`` is importable the real ``ClaudeAgentOptions``
    class is used so the SDK receives its native type.  When the SDK is absent
    (subprocess-runner path) a minimal duck-typed fallback is returned whose
    attributes mirror the passed keyword arguments exactly.

    Args:
        allowed_tools: Required. The list of tool names the agent may use.
            Must be a ``list[str]``; passing ``None`` raises ``TypeError``.
        extra_headers: Optional mapping of HTTP header names to values.
            When ``None``, defaults to a dict containing the ``anthropic-beta``
            header with the alphabetically-sorted default beta features.
        cache_control: Optional cache control dict (e.g. ``{"type": "ephemeral",
            "ttl": "1h"}``).  When ``None``, the default ``{"type": "ephemeral",
            "ttl": "1h"}`` is used after probing SDK support; falls back to
            ``ttl="5m"`` with a WARNING if the SDK rejects ``ttl="1h"``.
            A caller-supplied value is passed through unchanged.
        system_prompt: Optional system prompt value.  When ``None``, defaults to
            the canonical ``claude_code`` preset dict from ``build_system_prompt("")``
            (§2 cache-safe preset with ``exclude_dynamic_sections=True``).  A
            ``str`` or ``dict`` supplied by the caller is forwarded unchanged
            (backward compatibility for phases not yet migrated to the preset).
        thinking: Optional thinking configuration dict.  When set with
            ``{"type": "adaptive"}`` enables adaptive thinking (Opus 4.7 only).
            Passing ``{"budget_tokens": N}`` is accepted but emits a
            ``DeprecationWarning`` — Opus 4.7 removed fixed ``budget_tokens``.
            Set as a post-init attribute; not passed to the SDK constructor.
        output_config: Optional output configuration dict.  When set, e.g.
            ``{"effort": "xhigh"}``, controls per-phase effort levels (§7).
            Set as a post-init attribute; not passed to the SDK constructor.
        task_budget: Optional advisory token budget for the task (§13).  When
            set, injects ``output_config["task_budget"] = {"type": "tokens",
            "total": <N>}`` into the resolved output_config dict and adds
            ``task-budgets-2026-03-13`` to the ``anthropic-beta`` header
            (alphabetically merged).  When ``None`` (default), neither field
            is modified.
        context_management: Optional explicit context-management block.  When
            set, forwarded unchanged (caller wins) regardless of
            ``context_management_enabled``.  When ``None`` and
            ``context_management_enabled`` is ``True``, the canonical §3 block
            (``compact_20260112`` + ``clear_tool_uses_20260112``) is injected.
            When both are at their defaults, no ``context_management`` attribute
            is set on the returned options.
        context_management_enabled: Convenience flag for Phase 3/4.  When
            ``True`` and ``context_management`` is ``None``, injects the
            canonical §3 block via ``build_context_management_block()``.
            Defaults to ``False`` (no injection).
        mcp_servers: Optional MCP server config dict (e.g.
            ``{"codebase_memory": {"command": "x"}}``).  Forwarded verbatim
            as a post-init attribute; no validation or feature-detect is
            performed at this layer (§4 phase modules handle that).  Defaults
            to ``None``.
        **kwargs: Additional keyword arguments forwarded verbatim to
            ``ClaudeAgentOptions.__init__``.  The ``max_turns`` kwarg is
            accepted here as an **opt-in only** escape hatch (wired to the
            ``--max-turns`` CLI flag, issue #207): no production call site
            should set it, and the subprocess runner omits the corresponding
            argv flag when it is ``None``.  ``MaxTurnsExceeded`` in
            production logs therefore indicates a bug or an explicit operator
            override, not a recoverable outcome.

    Returns:
        A ``ClaudeAgentOptions`` instance or a duck-typed fallback object.

    Raises:
        TypeError: If ``allowed_tools`` is omitted or is not a ``list``.
    """
    if not isinstance(allowed_tools, list):
        raise TypeError(f"allowed_tools must be a list[str], got {type(allowed_tools).__name__!r}")
    _warn_if_budget_tokens(thinking)
    resolved_headers = _resolve_headers(extra_headers, task_budget)
    resolved_cache_control = _resolve_cache_control(cache_control)
    resolved_system_prompt = _resolve_system_prompt(system_prompt)
    resolved_output_config = _resolve_output_config(output_config, task_budget)
    resolved_context_management = _resolve_context_management(
        context_management, context_management_enabled
    )
    try:
        from claude_agent_sdk import ClaudeAgentOptions  # type: ignore[import-not-found]

        # Use the feature-detection retry loop (§18): each unsupported feature is
        # dropped one at a time, with a WARNING emitted at most once per process.
        result = _build_with_retry(
            ClaudeAgentOptions,
            allowed_tools=allowed_tools,
            extra_headers=resolved_headers,
            cache_control=resolved_cache_control,
            system_prompt=resolved_system_prompt,
            output_config=resolved_output_config,
            context_management=resolved_context_management,
            thinking=thinking,
            mcp_servers=mcp_servers,
            **kwargs,
        )
        _log_startup_once(result, sdk_available=True)
        return result
    except ImportError:
        result = _FallbackOptions(
            allowed_tools=allowed_tools,
            extra_headers=resolved_headers,
            cache_control=resolved_cache_control,
            system_prompt=resolved_system_prompt,
            thinking=thinking,
            output_config=resolved_output_config,
            context_management=resolved_context_management,
            mcp_servers=mcp_servers,
            **kwargs,
        )
        _log_startup_once(result, sdk_available=False)
        return result


def _resolve_sdk_version(sdk_available: bool) -> str:
    """Return the SDK version when importable; 'unknown' otherwise."""
    if not sdk_available:
        return "unknown"
    try:
        import claude_agent_sdk  # type: ignore[import-not-found]

        return getattr(claude_agent_sdk, "__version__", "unknown")
    except ImportError:
        return "unknown"


def _resolve_betas_label(opts: Any, sdk_available: bool) -> str:
    """Return the effective betas label: the header value or 'none'."""
    if not sdk_available:
        return "none"
    headers = getattr(opts, "extra_headers", {}) or {}
    return headers.get("anthropic-beta", "") or "none"


def _build_startup_fields(opts: Any, sdk_available: bool) -> tuple[str, str, str, str, str]:
    """Return the 5 startup log fields extracted from a constructed options object."""
    sp = getattr(opts, "system_prompt", {}) or {}
    cc = getattr(opts, "cache_control", {}) or {}
    return (
        _resolve_sdk_version(sdk_available),
        _resolve_betas_label(opts, sdk_available),
        "yes" if getattr(opts, "context_management", None) is not None else "no",
        "yes" if (isinstance(sp, dict) and sp.get("exclude_dynamic_sections")) else "no",
        cc.get("ttl", "unknown") if isinstance(cc, dict) else "unknown",
    )


def _log_startup_once(opts: Any, *, sdk_available: bool) -> None:
    """Emit a one-line INFO startup summary on the first successful make_agent_options() call."""
    global _startup_logged  # noqa: PLW0603
    if _startup_logged:
        return
    _startup_logged = True
    sdk_ver, betas, ctx_mgmt, excl_dyn, ttl = _build_startup_fields(opts, sdk_available)
    _logger.info(
        "runner: SDK=%s betas=%s context_mgmt=%s exclude_dynamic_sections=%s ttl=%s",
        sdk_ver,
        betas,
        ctx_mgmt,
        excl_dyn,
        ttl,
    )


def _warn_if_budget_tokens(thinking: dict | None) -> None:
    """Emit DeprecationWarning when thinking contains 'budget_tokens'.

    Opus 4.7 removed fixed thinking budgets; only adaptive thinking is supported.
    """
    if thinking is not None and "budget_tokens" in thinking:
        warnings.warn(
            "thinking['budget_tokens'] is deprecated: Opus 4.7 removed fixed thinking_budget. "
            "Use thinking={'type': 'adaptive'} instead.",
            DeprecationWarning,
            stacklevel=3,
        )


def _default_beta_headers() -> dict[str, str]:
    """Return the default extra_headers dict with the canonical anthropic-beta value."""
    return {"anthropic-beta": build_beta_header(_DEFAULT_BETAS)}


def _resolve_headers(
    extra_headers: dict[str, str] | None, task_budget: int | None
) -> dict[str, str]:
    """Return the resolved extra_headers dict, injecting the task-budgets beta when set.

    When ``task_budget`` is set, ``task-budgets-2026-03-13`` is merged into the
    ``anthropic-beta`` header value in alphabetical order.  When ``task_budget``
    is ``None``, the headers are returned unchanged.
    """
    base = extra_headers if extra_headers is not None else _default_beta_headers()
    if task_budget is None:
        return base
    current_beta = base.get("anthropic-beta", "")
    current_betas = set(filter(None, current_beta.split(",")))
    current_betas.add(_TASK_BUDGET_BETA)
    return {**base, "anthropic-beta": build_beta_header(current_betas)}


def _resolve_output_config(output_config: dict | None, task_budget: int | None) -> dict | None:
    """Return the resolved output_config dict, injecting task_budget entry when set.

    When ``task_budget`` is set, merges ``{"task_budget": {"type": "tokens", "total": N}}``
    into the output_config dict (creating it if ``None``).  When ``task_budget``
    is ``None``, returns ``output_config`` unchanged.
    """
    if task_budget is None:
        return output_config
    base = dict(output_config) if output_config is not None else {}
    base["task_budget"] = {"type": "tokens", "total": task_budget}
    return base


def _resolve_system_prompt(system_prompt: dict | str | None) -> dict | str:
    """Return the resolved system_prompt value.

    Caller-supplied strings or dicts are passed through unchanged.  ``None``
    triggers the canonical ``claude_code`` preset (§2 cache-safe default).
    """
    if system_prompt is not None:
        return system_prompt
    return build_system_prompt()


def _resolve_cache_control(cache_control: dict | None) -> dict:
    """Return the resolved cache_control dict.

    Caller-supplied values are passed through unchanged.  ``None`` triggers the
    lazy SDK probe so the TTL is the best value the installed SDK supports.
    """
    if cache_control is not None:
        return cache_control
    ttl = probe_cache_ttl_support(_logger)
    return {"type": "ephemeral", "ttl": ttl}


def _resolve_context_management(
    context_management: dict | None, context_management_enabled: bool
) -> dict | None:
    """Return the resolved context_management block, or None when not applicable.

    Caller-supplied dict wins (caller wins principle).  When no explicit dict
    is provided and ``context_management_enabled`` is True, injects the
    canonical §3 block.  Otherwise returns None (no injection).
    """
    if context_management is not None:
        return context_management
    if context_management_enabled:
        return build_context_management_block()
    return None


class _FallbackOptions:
    """Duck-typed stand-in for ClaudeAgentOptions used when the SDK is absent."""

    def __init__(self, **kwargs: Any) -> None:
        self.__dict__.update(kwargs)
