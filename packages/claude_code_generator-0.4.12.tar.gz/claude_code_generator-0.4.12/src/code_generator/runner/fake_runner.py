"""Deterministic fake runner for bench and tests.

Returns canned RunResult objects with pre-defined usage blocks for each
phase (0-7).  Designed to be byte-identical across runs so bench --fake
produces the same JSON regardless of environment.

Usage::

    from code_generator.runner.fake_runner import get_phase_result
    result = get_phase_result(phase=3)  # RunResult with canned usage
"""

from __future__ import annotations

from code_generator.runner.types import RunResult, TokenUsage

# ---------------------------------------------------------------------------
# Canned usage blocks per phase
# ---------------------------------------------------------------------------
# Values are chosen to produce varied cache-hit ratios across phases so that
# bench compare has meaningful signal. Later phases accumulate more cache_read
# as the shared context grows.

CANNED_PHASE_USAGE: dict[int, TokenUsage] = {
    0: TokenUsage(input=800, output=150, cache_read=0, cache_write=400, num_turns=4),
    1: TokenUsage(input=2000, output=350, cache_read=400, cache_write=800, num_turns=12),
    2: TokenUsage(input=2500, output=500, cache_read=1200, cache_write=600, num_turns=18),
    3: TokenUsage(input=3500, output=700, cache_read=2500, cache_write=300, num_turns=24),
    4: TokenUsage(input=3500, output=700, cache_read=3200, cache_write=150, num_turns=28),
    5: TokenUsage(input=2000, output=400, cache_read=4000, cache_write=80, num_turns=16),
    6: TokenUsage(input=1500, output=300, cache_read=4300, cache_write=0, num_turns=10),
    7: TokenUsage(input=500, output=100, cache_read=4000, cache_write=0, num_turns=3),
}

# Wall-clock time (seconds) per phase — kept constant for determinism.
CANNED_PHASE_WALL: dict[int, float] = {
    0: 1.5,
    1: 3.0,
    2: 2.5,
    3: 8.0,
    4: 8.0,
    5: 4.0,
    6: 3.5,
    7: 1.0,
}


def get_phase_result(phase: int) -> RunResult:
    """Return the canned RunResult for *phase*.

    Args:
        phase: Phase index (0-7).

    Returns:
        A deterministic :class:`~code_generator.runner.types.RunResult` with
        pre-defined usage counters and wall-clock time.

    Raises:
        KeyError: When *phase* is not in 0-7.
    """
    return RunResult(
        text="fake-bench-ok",
        session_id=None,
        usage=CANNED_PHASE_USAGE[phase],
        wall_seconds=CANNED_PHASE_WALL[phase],
    )
