"""state_guard — chmod-based protection for state.json during SDK sessions.

Exposes ``protect_state_file(state_path)``, a context manager that makes
``state.json`` read-only on enter and restores the original permissions on
exit — even if an exception is raised inside the block.

This prevents the model from writing to ``state.json`` via Bash during an
SDK session (incident 2026-04-15, requirements §12d).

Windows limitation
------------------
``os.chmod`` on Windows only controls the *read-only* attribute for the owner;
it does NOT enforce POSIX-style write permission checks at the OS level.
Therefore, ``write_text()`` will still succeed on Windows even inside this
context manager.  A WARNING is emitted once at module import time on Windows
so the limitation is visible in logs.  Wiring this guard into the hot path on
Windows is a no-op but harmless — it keeps the cross-platform call sites
uniform.
"""

from __future__ import annotations

import contextlib
import logging
import os
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Generator
    from pathlib import Path

logger = logging.getLogger(__name__)

# Compute platform check once at import; avoids branching in the hot path.
_IS_WINDOWS: bool = sys.platform == "win32"

if _IS_WINDOWS:
    logger.warning(
        "state_guard: chmod-based write protection is a no-op on Windows. "
        "state.json will NOT be protected during SDK sessions on this platform."
    )

_READ_ONLY_MODE = 0o444


@contextlib.contextmanager
def protect_state_file(state_path: Path) -> Generator[None, None, None]:
    """Make *state_path* read-only for the duration of the block.

    On enter
    --------
    - If the file does not exist: log DEBUG and yield (no-op).
    - Otherwise: capture ``st_mode``, ``chmod`` to ``0o444``.

    On exit (normal or exception)
    -----------------------------
    - Restore the original ``st_mode``.
    - Re-raise any exception unchanged.

    Windows
    -------
    chmod is skipped; the context manager degrades to a no-op (see module
    docstring for details).
    """
    if not state_path.exists():
        logger.debug("state_guard: %s does not exist — skipping protection", state_path)
        yield
        return

    original_mode = state_path.stat().st_mode

    if not _IS_WINDOWS:
        os.chmod(state_path, _READ_ONLY_MODE)

    try:
        yield
    finally:
        if not _IS_WINDOWS:
            os.chmod(state_path, original_mode)
