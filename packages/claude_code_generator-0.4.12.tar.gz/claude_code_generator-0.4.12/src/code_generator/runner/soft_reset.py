"""Soft-reset primitive for shared-session cycles.

Performs the coordinated actions between consecutive issues so the shared
SDK client starts the next issue with a clean slate:

1. Atomically overwrite `current-issue.md` with an empty string.
2. Return the boundary user-message text as a **prompt prefix** the caller
   prepends to the next review/implementation prompt.
3. Return the `context_management` block the caller merges into the next
   `make_agent_options()` call.
4. Emit one INFO log line.

The function is a **pure helper**: it never mutates caller state and never
issues a separate ``client.query()``.  Sending the boundary as its own query
without draining the response leaves the SDK with an un-drained assistant
message in the queue; the next ``client.query()`` then drains *that* response
instead of its own, mis-attributing the review output by one issue
(regression detected 2026-04-17 — every even-indexed issue in Phase 2 got an
ACK-only reply, every odd-indexed issue got the previous issue's review).
Returning the prefix as text and letting the caller concatenate it into the
single outgoing query keeps the query/drain pairing intact.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from code_generator.memory import overwrite_memory_file

if TYPE_CHECKING:
    from pathlib import Path

_logger = logging.getLogger(__name__)

_CURRENT_ISSUE_RELPATH = "current-issue.md"

_BOUNDARY_TEMPLATE = (
    "Context reset. Starting issue #{n} fresh. "
    "All prior tool results and conversational context from issue #{prev} are discarded. "
    "Re-read files as needed."
)

_RESET_CONTEXT_MANAGEMENT: dict[str, Any] = {
    "tools": [
        {
            "type": "clear_tool_uses_20260112",
            "keep": {"type": "tool_uses", "value": 0},
        }
    ]
}


@dataclass(frozen=True)
class SoftResetResult:
    """Result of a soft-reset action between two issues in shared mode.

    Attributes:
        boundary_prefix: Text the caller MUST prepend to the next prompt.
        context_management: Dict the caller MUST pass to ``make_agent_options``.
    """

    boundary_prefix: str
    context_management: dict[str, Any]


async def soft_reset_context(
    client: Any,  # noqa: ARG001 — kept for signature stability; no client interaction
    issue_number: int,
    memories_dir: Path,
) -> SoftResetResult:
    """Perform the soft-reset actions between consecutive issues.

    Args:
        client: Duck-typed SDK client. **Not used** — kept in the signature for
            backward compatibility with existing call sites and tests. The
            boundary message is returned to the caller so it can be prepended
            to the outgoing prompt, avoiding a second ``client.query()`` whose
            response would otherwise go undrained and desynchronise the queue.
        issue_number: The issue number starting *now* (used in the boundary text).
        memories_dir: Root memories directory (created if absent).

    Returns:
        A :class:`SoftResetResult` carrying the boundary prefix and the
        ``context_management`` block for the next query.

    Raises:
        ValueError: If ``current-issue.md`` would resolve outside *memories_dir*
            (path-traversal guard delegated to ``overwrite_memory_file``).
    """
    # Step 1: atomic memory overwrite (MUST happen before step 2 — ordering invariant)
    overwrite_memory_file(memories_dir, _CURRENT_ISSUE_RELPATH, "")

    # Step 2: build the boundary text; caller prepends to next prompt.
    boundary = _BOUNDARY_TEMPLATE.format(n=issue_number, prev=issue_number - 1)

    _logger.info("soft_reset: issue=%d memories_reset=1 boundary_prefix=1", issue_number)

    return SoftResetResult(
        boundary_prefix=boundary + "\n\n",
        context_management=dict(_RESET_CONTEXT_MANAGEMENT),
    )
