"""Atomic write primitives and read helpers for `.code-generator/memories/*.md` scratchpad files.

All writes use a sibling tmp file and `os.replace()` so a crash mid-write
cannot produce a partially-written or corrupt file.

Every `relpath` is validated against `memories_dir` before any I/O to prevent
path-traversal attacks (`../`, absolute paths, symlink escapes).
"""

import os
import tempfile
from pathlib import Path

# ---------------------------------------------------------------------------
# Repomap constants
# ---------------------------------------------------------------------------

#: Fallback string injected into prompts when the cycle-repo-map.md file is
#: missing or empty.  Matches the ``_FALLBACK`` sentinel in ``repomap.py``.
REPOMAP_FALLBACK = "(repomap unavailable — rely on MCP or Read tools)"

#: Relative path of the per-cycle repo-map memory file inside ``memories/``.
_REPOMAP_FILE = "cycle-repo-map.md"

# ---------------------------------------------------------------------------
# Path validation
# ---------------------------------------------------------------------------


def _validated_path(memories_dir: Path, relpath: str) -> Path:
    """Resolve and validate that `relpath` stays inside `memories_dir`.

    Args:
        memories_dir: The root memories directory (need not exist yet).
        relpath: A relative path such as ``"current-issue.md"``.

    Returns:
        The resolved absolute ``Path`` for the target file.

    Raises:
        ValueError: If ``relpath`` would escape ``memories_dir`` (traversal,
            absolute path, or symlink that resolves outside the root).
    """
    root = memories_dir.resolve()
    candidate = (memories_dir / relpath).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        raise ValueError(f"relpath {relpath!r} escapes memories_dir {memories_dir!r}") from None
    return candidate


# ---------------------------------------------------------------------------
# Low-level atomic helper
# ---------------------------------------------------------------------------


def _atomic_write(path: Path, data: bytes) -> None:
    """Write *data* to *path* atomically via a sibling temp file.

    Args:
        path: Destination file (parent directory must exist).
        data: Raw bytes to write.
    """
    fd, tmp_name = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp_name, path)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def write_memory_file(memories_dir: Path, relpath: str, content: str) -> None:
    """Create or overwrite a memories file with *content*.

    Equivalent to ``overwrite_memory_file`` — provided so callers that
    conceptually "write a new file" have a semantically clear name.

    Args:
        memories_dir: Root memories directory (created if absent).
        relpath: Relative path of the target file inside *memories_dir*.
        content: UTF-8 text to write.
    """
    overwrite_memory_file(memories_dir, relpath, content)


def overwrite_memory_file(memories_dir: Path, relpath: str, content: str = "") -> None:
    """Atomically overwrite a memories file with *content*.

    Args:
        memories_dir: Root memories directory (created if absent).
        relpath: Relative path of the target file inside *memories_dir*.
        content: UTF-8 text to write (default: empty string).
    """
    target = _validated_path(memories_dir, relpath)
    memories_dir.mkdir(parents=True, exist_ok=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    _atomic_write(target, content.encode("utf-8"))


def append_memory_file(memories_dir: Path, relpath: str, content: str) -> None:
    """Atomically append *content* to a memories file.

    Reads the existing content (empty string if file absent), concatenates
    *content*, then performs a single atomic replace — no partial flush.

    Args:
        memories_dir: Root memories directory (created if absent).
        relpath: Relative path of the target file inside *memories_dir*.
        content: UTF-8 text to append.
    """
    target = _validated_path(memories_dir, relpath)
    memories_dir.mkdir(parents=True, exist_ok=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    existing = target.read_text(encoding="utf-8") if target.exists() else ""
    _atomic_write(target, (existing + content).encode("utf-8"))


def clear_memory_file(memories_dir: Path, relpath: str) -> None:
    """Atomically overwrite a memories file with an empty string.

    Args:
        memories_dir: Root memories directory (created if absent).
        relpath: Relative path of the target file inside *memories_dir*.
    """
    overwrite_memory_file(memories_dir, relpath, "")


# ---------------------------------------------------------------------------
# Read helpers
# ---------------------------------------------------------------------------


def read_memory_file(memories_dir: Path, relpath: str) -> str:
    """Read the content of a memories file, returning ``""`` if absent.

    Path traversal is rejected identically to the write primitives.

    Args:
        memories_dir: Root memories directory.
        relpath: Relative path of the target file inside *memories_dir*.

    Returns:
        UTF-8 decoded file content, or ``""`` when the file does not exist.

    Raises:
        ValueError: If ``relpath`` would escape ``memories_dir``.
    """
    target = _validated_path(memories_dir, relpath)
    if not target.exists():
        return ""
    return target.read_text(encoding="utf-8")


def read_cycle_repomap(memories_dir: Path) -> str:
    """Read the cycle repo-map from ``cycle-repo-map.md``.

    Returns :data:`REPOMAP_FALLBACK` when the file is absent or contains only
    whitespace, so callers always receive a non-``None`` injectable string.

    Args:
        memories_dir: Root memories directory (typically
            ``<project_dir>/.code-generator/memories``).

    Returns:
        The repo-map content, or the fallback sentinel string.
    """
    content = read_memory_file(memories_dir, _REPOMAP_FILE)
    return content if content.strip() else REPOMAP_FALLBACK
