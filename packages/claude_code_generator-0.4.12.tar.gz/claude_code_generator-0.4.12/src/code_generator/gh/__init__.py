"""Thin subprocess wrapper around the `gh` CLI.

All GitHub operations in the orchestrator go through this package.
No direct subprocess.run() for gh is allowed outside this package.

Sub-modules:
- ``core``: GhError, _run()
- ``issues``: issue CRUD + agent_from_labels()
- ``labels``: label management
- ``milestones``: milestone lifecycle
"""

from __future__ import annotations

from code_generator.gh.core import (
    GhCommandRunner,
    GhError,
    SubprocessGhRunner,
    _run,
    reset_runner,
    set_runner,
)
from code_generator.gh.issues import (
    agent_from_labels,
    issue_state,
    list_issues,
    post_comment,
    view_issue,
)
from code_generator.gh.labels import add_label, ensure_label, ensure_standard_labels
from code_generator.gh.milestones import close_milestone, create_milestone, delete_milestone

__all__ = [
    "GhCommandRunner",
    "GhError",
    "SubprocessGhRunner",
    "_run",
    "reset_runner",
    "set_runner",
    "agent_from_labels",
    "issue_state",
    "list_issues",
    "post_comment",
    "view_issue",
    "add_label",
    "ensure_label",
    "ensure_standard_labels",
    "close_milestone",
    "create_milestone",
    "delete_milestone",
]
