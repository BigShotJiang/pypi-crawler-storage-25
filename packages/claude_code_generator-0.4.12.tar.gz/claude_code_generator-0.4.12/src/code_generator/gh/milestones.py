"""Milestone lifecycle: create, close, and delete via the GitHub API."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from code_generator.gh.core import _run

if TYPE_CHECKING:
    from code_generator.repo_info import RepoInfo


def create_milestone(repo: RepoInfo, title: str, description: str = "") -> int:
    """Create a GitHub milestone via the API and return its number.

    Args:
        repo: Repository to target (provides API path and ``--hostname`` flag).
        title: Milestone title.
        description: Optional description.

    Returns:
        The integer milestone number from the API response.

    Raises:
        GhError: When gh fails.
    """
    raw = _run(
        [
            "gh",
            "api",
            "--method",
            "POST",
            f"repos/{repo.full}/milestones",
            "--hostname",
            repo.host,
            "-f",
            f"title={title}",
            "-f",
            f"description={description}",
            "-f",
            "state=open",
        ]
    )
    data = json.loads(raw)
    return int(data["number"])


def delete_milestone(repo: RepoInfo, number: int) -> None:
    """Delete a GitHub milestone permanently via the API.

    Uses DELETE instead of PATCH/close because GitHub returns HTTP 422
    "already_exists" when creating a milestone whose title matches an existing
    one — even a closed one. Deletion is the only way to allow reuse of the
    same title on retry.

    Args:
        repo: Repository to target (provides API path and ``--hostname`` flag).
        number: The milestone number.

    Raises:
        GhError: When gh fails.
    """
    _run(
        [
            "gh",
            "api",
            "--method",
            "DELETE",
            f"repos/{repo.full}/milestones/{number}",
            "--hostname",
            repo.host,
        ]
    )


def close_milestone(repo: RepoInfo, number: int) -> None:
    """Close a GitHub milestone via the API.

    Args:
        repo: Repository to target (provides API path and ``--hostname`` flag).
        number: The milestone number.

    Raises:
        GhError: When gh fails.
    """
    _run(
        [
            "gh",
            "api",
            "--method",
            "PATCH",
            f"repos/{repo.full}/milestones/{number}",
            "--hostname",
            repo.host,
            "-f",
            "state=closed",
        ]
    )
