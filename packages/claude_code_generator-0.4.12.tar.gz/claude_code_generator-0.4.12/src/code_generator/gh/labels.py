"""Label management: create, add, and seed standard label taxonomy."""

from __future__ import annotations

from typing import TYPE_CHECKING

from code_generator.gh.core import GhError, _run

if TYPE_CHECKING:
    from code_generator.repo_info import RepoInfo


def ensure_label(repo: RepoInfo, name: str, color: str, description: str) -> None:
    """Create a label, ignoring "already exists" errors.

    Args:
        repo: Repository to target (provides ``--repo`` flag and ``GH_HOST`` env).
        name: Label name, e.g. ``"priority:high"``.
        color: Hex colour without leading ``#``, e.g. ``"FF0000"``.
        description: Human-readable description.

    Raises:
        GhError: On any error other than "already exists".
    """
    try:
        _run(
            [
                "gh",
                "label",
                "create",
                name,
                "--repo",
                repo.full,
                "--color",
                color,
                "--description",
                description,
            ],
            env={"GH_HOST": repo.host},
        )
    except GhError as exc:
        if "already exists" in exc.stderr.lower():
            return
        raise


def add_label(repo: RepoInfo, issue_number: int, label: str) -> None:
    """Add a label to an existing issue.

    Args:
        repo: Repository to target (provides ``--repo`` flag and ``GH_HOST`` env).
        issue_number: The issue number.
        label: Label name to add.

    Raises:
        GhError: When gh fails.
    """
    _run(
        [
            "gh",
            "issue",
            "edit",
            str(issue_number),
            "--repo",
            repo.full,
            "--add-label",
            label,
        ],
        env={"GH_HOST": repo.host},
    )


def ensure_standard_labels(repo: RepoInfo) -> None:
    """Seed the repository with the standard label taxonomy.

    Creates all labels defined in requirements.md §8. Idempotent —
    "already exists" errors are silently ignored.

    Args:
        repo: Repository to target.

    Raises:
        GhError: On unexpected gh failures.
    """
    _create_priority_labels(repo)
    _create_area_labels(repo)
    _create_phase_labels(repo)
    _create_agent_labels(repo)


def _create_priority_labels(repo: RepoInfo) -> None:
    for priority, color in [("high", "FF0000"), ("medium", "FBCA04"), ("low", "0E8A16")]:
        ensure_label(repo, f"priority:{priority}", color, f"{priority.capitalize()} priority")


def _create_area_labels(repo: RepoInfo) -> None:
    area_color = "0052CC"
    areas = [
        "cli",
        "orchestrator",
        "runner",
        "state",
        "prompts",
        "gh",
        "tests",
        "docs",
        "api",
        "frontend",
        "database",
        "auth",
        "infra",
    ]
    for area in areas:
        ensure_label(repo, f"area:{area}", area_color, f"Area: {area}")


def _create_phase_labels(repo: RepoInfo) -> None:
    phase_color = "D4C5F9"
    for phase in ["plan", "implement", "review", "test"]:
        ensure_label(repo, f"phase:{phase}", phase_color, f"Phase: {phase}")


def _create_agent_labels(repo: RepoInfo) -> None:
    agent_color = "7057FF"
    agents = [
        "frontend-developer",
        "typescript-pro",
        "tailwind-patterns",
        "ui-ux-designer",
        "python-pro",
        "fastapi-expert-agent",
        "supabase-connection-expert",
        "nestjs-expert",
        "baml-expert-agent",
        "riskfolio-expert",
    ]
    for agent in agents:
        ensure_label(repo, f"agent:{agent}", agent_color, f"Agent: {agent}")
