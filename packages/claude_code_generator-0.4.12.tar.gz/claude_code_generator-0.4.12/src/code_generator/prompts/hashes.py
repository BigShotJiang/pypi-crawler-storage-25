"""Prompt file hash computation for §17 drift detection.

Computes SHA-256 digests from the raw bytes of every prompt .md file so that
the orchestrator can detect out-of-band edits between cycle start and --continue.
"""

from __future__ import annotations

import hashlib
import importlib.resources


def compute_all_prompt_hashes() -> dict[str, str]:
    """Return SHA-256 hex digests for every prompt .md file.

    Iterates the ``code_generator.prompts`` package directory via
    ``importlib.resources`` (safe for pipx installs — no hard-coded path).
    Hashes are computed from raw file bytes so that placeholder substitutions
    do not affect the fingerprint.

    Returns:
        Mapping of ``filename → sha256_hex`` for all ``.md`` files in the
        prompts package.  Keys are bare filenames (e.g.
        ``"prompt-phase-1-planning.md"``), not full paths.
    """
    pkg = importlib.resources.files("code_generator.prompts")
    result: dict[str, str] = {}
    for entry in pkg.iterdir():
        name = entry.name
        if not name.endswith(".md"):
            continue
        raw = entry.read_bytes()
        result[name] = hashlib.sha256(raw).hexdigest()
    return result
