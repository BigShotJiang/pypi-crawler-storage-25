"""Prompt loader and comment formatter for the code-generator orchestrator.

Prompt files contain literal curly braces (bash code blocks, JSON schema
examples, etc.) that would break str.format(). Substitution is done by
simple text.replace() per placeholder name, which is immune to stray braces.
"""

from __future__ import annotations

import importlib.resources

__all__ = [
    "PromptError",
    "PLACEHOLDER_SPEC",
    "load_prompt",
    "available_prompts",
    "format_comments",
    "truncate_placeholder",
]


class PromptError(ValueError):
    """Raised when a prompt file is unknown or its placeholders are mismatched."""


# Maps each prompt filename to the exact set of placeholder names it accepts.
# A frozenset() means the file accepts no placeholders (it is fully static).
PLACEHOLDER_SPEC: dict[str, frozenset[str]] = {
    "prompt-optimize-requirements.md": frozenset({"CURRENT_REQUIREMENTS"}),
    "prompt-phase-0-complexity.md": frozenset({"REPO_MAP"}),
    "prompt-cycle-specializer.md": frozenset({"REQUIREMENTS_CONTENT", "CYCLES_JSON"}),
    "prompt-phase-1-planning.md": frozenset(
        {
            "CYCLE_SPECIALIZED_PROMPT",
            "MILESTONE_TITLE",
            "CYCLE_SCOPE",
            "COMPLETED_CYCLES",
            "EXISTING_ISSUES",
            "REPO_MAP",
        }
    ),
    "prompt-phase-2-issue-review.md": frozenset(
        {"ISSUE_NUMBER", "PRIMARY_AGENT", "ISSUE_COMMENTS", "REPO_MAP"}
    ),
    "prompt-phase-2-batch-review.md": frozenset({"ISSUES_JSON", "REPO_MAP"}),
    "prompt-phase-3-implementation.md": frozenset(
        {"ISSUE_NUMBER", "PRIMARY_AGENT", "SKILLS", "ISSUE_COMMENTS"}
    ),
    "prompt-phase-5-final-review.md": frozenset(
        {
            "MILESTONE_TITLE",
            "CYCLE_SCOPE",
            "OPEN_ISSUES_WITH_COMMENTS",
            "DIFF_SINCE_BASE",
            "LINT_ERRORS",
        }
    ),
    "prompt-phase-6-test.md": frozenset({"MAX_RETRIES"}),
    "prompt-phase-7-commit.md": frozenset(
        {"CYCLE_NAME", "ISSUES_CLOSED", "STAGED_DIFF_STAT", "STAGED_FILES"},
    ),
    "prompt-review.md": frozenset({"CREATE_ISSUES", "SEVERITY_FILTER"}),
}


def truncate_placeholder(text: object, max_tokens: int = 5000) -> str:
    """Truncate a placeholder value to fit within a token budget.

    Uses Anthropic's rule of thumb: 1 token ≈ 4 characters.
    On overflow, cuts at the nearest whitespace before the cap and appends
    a ``... [truncated, N bytes omitted]`` marker so the model knows content
    was dropped.

    Args:
        text: The placeholder value. Non-str inputs are converted via ``str()``.
        max_tokens: Maximum allowed tokens (default 5000).

    Returns:
        The original string when within budget, or a truncated string with
        the omission marker appended.
    """
    value = text if isinstance(text, str) else str(text)
    cap = max_tokens * 4
    if len(value) // 4 <= max_tokens:
        return value
    boundary = value.rfind(" ", 0, cap)
    truncated_body = value[:boundary] if boundary != -1 else value[:cap]
    omitted = len(value) - len(truncated_body)
    return f"{truncated_body}... [truncated, {omitted} bytes omitted]"


def load_prompt(filename: str, **placeholders: object) -> str:
    """Load a prompt file and substitute named placeholders.

    Placeholder tokens use the syntax ``{NAME_IN_UPPERCASE}``.  Substitution
    is done with plain string replacement so that stray ``{`` / ``}`` in the
    template (bash blocks, JSON schema examples) are never misinterpreted.

    Args:
        filename: One of the 9 registered prompt filenames.
        **placeholders: Keyword arguments whose names must match exactly the set
            declared in PLACEHOLDER_SPEC for this file.

    Returns:
        The prompt text with all placeholder tokens replaced by their values.

    Raises:
        PromptError: When *filename* is unrecognised, when required placeholders
            are missing, or when unexpected placeholders are supplied.
    """
    if filename not in PLACEHOLDER_SPEC:
        raise PromptError(f"unknown prompt file: {filename!r}")

    expected = PLACEHOLDER_SPEC[filename]
    supplied = set(placeholders)
    missing = expected - supplied
    extra = supplied - expected

    if missing or extra:
        parts: list[str] = []
        if missing:
            parts.append(f"missing: {', '.join(sorted(missing))}")
        if extra:
            parts.append(f"extra: {', '.join(sorted(extra))}")
        raise PromptError("; ".join(parts))

    text = (
        importlib.resources.files("code_generator.prompts")
        .joinpath(filename)
        .read_text(encoding="utf-8")
    )

    for name, value in placeholders.items():
        text = text.replace("{" + name + "}", truncate_placeholder(value))

    return text


def available_prompts() -> list[str]:
    """Return the list of registered prompt filenames.

    Returns:
        Sorted list of the 9 known prompt filenames.
    """
    return sorted(PLACEHOLDER_SPEC)


def _extract_author(comment: dict) -> str:  # type: ignore[type-arg]
    """Extract the author login from a comment dict, defaulting to 'unknown'."""
    author = comment.get("author")
    if not isinstance(author, dict):
        return "unknown"
    return author.get("login", "unknown") or "unknown"


def _blockquote(body: str) -> str:
    """Prefix each line of *body* with '> '."""
    return "\n".join(f"> {line}" for line in body.splitlines())


def _render_comment(comment: dict) -> str:  # type: ignore[type-arg]
    """Render a single comment dict as a markdown block."""
    author = _extract_author(comment)
    timestamp = comment.get("createdAt", "")
    body = comment.get("body") or ""
    header = f"**{author}** ({timestamp}):" if timestamp else f"**{author}**:"
    return f"{header}\n{_blockquote(body)}"


def format_comments(comments: list[dict] | None) -> str:  # type: ignore[type-arg]
    """Render a list of GitHub issue comment dicts as a markdown section.

    Produces a ``## Issue Comments`` section suitable for injection into
    phase prompts.  Comments are rendered in the order supplied (chronological).

    Args:
        comments: List of comment dicts as returned by ``gh/issues.py``, or
            ``None``.  Each dict may contain ``author``, ``createdAt``, and
            ``body`` keys; missing keys are handled gracefully.

    Returns:
        A markdown string starting with ``## Issue Comments`` when comments
        are present, or an empty string when *comments* is ``None`` or empty.
    """
    if not comments:
        return ""
    rendered = "\n\n".join(_render_comment(c) for c in comments)
    return f"## Pre-fetched Issue Comments\n\n{rendered}"
