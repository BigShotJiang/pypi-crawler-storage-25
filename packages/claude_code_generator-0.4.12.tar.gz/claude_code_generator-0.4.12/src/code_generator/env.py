"""Environment safety module.

Strips dangerous environment variables before any Claude Code invocation
to guarantee zero API credit usage (Max subscription only).

Non-negotiable constraint #1: no API keys must reach the Claude CLI.
Non-negotiable cache invariant: all SDK sessions must resolve to a single
workspace — see Cache workspace invariants section in CLAUDE.md.
Reference: ITAL-IA/kb/run-deep-research.py build_agent_env().
"""

import logging
import os
import sys
from collections.abc import Callable
from typing import Literal

_logger = logging.getLogger(__name__)

# Module-level state tracking the INFO-log guard for the deferred-probe path
# and the localhost short-circuit path (workspace invariant bypass).
_WS_STATE: dict[str, object] = {"warned": False, "localhost_logged": False}

DANGEROUS_VARS: tuple[str, ...] = (
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_AUTH_TOKEN",
    "ANTHROPIC_BEDROCK_API_KEY",
    "ANTHROPIC_VERTEX_PROJECT_ID",
    "CLAUDE_CODE_USE_BEDROCK",
    "CLAUDE_CODE_USE_VERTEX",
)

Provider = Literal["anthropic-max", "ollama"]

# Pinned local daemon endpoint for the Ollama bypass path.
# Refusal gate is strict on this exact value; the workspace short-circuit is
# deliberately lenient (any http://localhost:* — see assert_single_workspace).
OLLAMA_BASE_URL = "http://localhost:11434"


def strip_dangerous_env() -> None:
    """Remove every dangerous variable from the current process environment.

    When ``ANTHROPIC_BASE_URL`` points at a ``http://localhost:*`` endpoint
    (the Ollama single-model codepath — see #218), ``ANTHROPIC_AUTH_TOKEN`` is
    preserved so the scoped Ollama routing installed by
    :func:`assert_safe_environment_ollama` survives per-SDK-run strip calls
    (``sdk_runner.run``, ``run_with_shared_client``).
    """
    ollama_mode = _is_localhost_base_url(os.environ.get("ANTHROPIC_BASE_URL"))
    protected = {"ANTHROPIC_AUTH_TOKEN"} if ollama_mode else set()
    for var in DANGEROUS_VARS:
        if var in protected:
            continue
        os.environ.pop(var, None)


def build_agent_env(provider: Provider = "anthropic-max") -> dict[str, str]:
    """Return a sanitized copy of the environment suitable for subprocess.run(env=...).

    Default (provider="anthropic-max"): strips every DANGEROUS_VAR so no
    Anthropic API credentials reach the SDK (non-negotiable #1).

    provider="ollama": strips DANGEROUS_VARS then rewrites a scoped subset —
    ``ANTHROPIC_AUTH_TOKEN`` (from ``OLLAMA_API_KEY``), ``ANTHROPIC_BASE_URL``
    pinned to ``http://localhost:11434``, and ``ANTHROPIC_API_KEY=""``. No
    Anthropic traffic ever leaves the host because the SDK is routed at the
    localhost daemon.

    The calling process's ``os.environ`` is not mutated.

    Raises:
        ValueError: When ``provider`` is not one of the Literal values.
        RuntimeError: When ``provider="ollama"`` and the parent env violates
            a precondition (see ``_require_ollama_preconditions``).
    """
    if provider == "anthropic-max":
        return _build_anthropic_max_env()
    if provider == "ollama":
        return _build_ollama_env()
    raise ValueError(f"Unknown provider: {provider!r}. Expected 'anthropic-max' or 'ollama'.")


def _build_anthropic_max_env() -> dict[str, str]:
    """Strip DANGEROUS_VARS — the default Anthropic Max subscription path.

    When ``ANTHROPIC_BASE_URL`` in the parent env points at ``http://localhost:*``
    (the Ollama single-model codepath, #218), ``ANTHROPIC_AUTH_TOKEN`` is
    preserved in the returned dict so the subprocess inherits the Ollama
    auth token. This keeps the default subprocess-runner codepath usable for
    Ollama without threading a ``provider`` argument through every runner.
    """
    ollama_mode = _is_localhost_base_url(os.environ.get("ANTHROPIC_BASE_URL"))
    protected = {"ANTHROPIC_AUTH_TOKEN"} if ollama_mode else set()
    return {k: v for k, v in os.environ.items() if k not in DANGEROUS_VARS or k in protected}


def _build_ollama_env() -> dict[str, str]:
    """Build the scoped Ollama env: AUTH_TOKEN + BASE_URL + empty API_KEY.

    Strips every ANTHROPIC_* var from the parent env first, then rewrites
    exactly the three keys the Ollama-compatible Messages endpoint needs.
    This prevents stray vars like ``ANTHROPIC_API_URL`` from leaking into
    the SDK and overriding the pinned localhost base URL.
    """
    token = _require_ollama_preconditions()
    env = {k: v for k, v in os.environ.items() if not k.startswith("ANTHROPIC_")}
    env["ANTHROPIC_AUTH_TOKEN"] = token
    env["ANTHROPIC_BASE_URL"] = OLLAMA_BASE_URL
    env["ANTHROPIC_API_KEY"] = ""
    return env


def _require_ollama_preconditions() -> str:
    """Validate the Ollama bypass preconditions and return the token.

    Refuses the bypass when:
      * ``OLLAMA_API_KEY`` is unset or empty.
      * ``ANTHROPIC_BASE_URL`` is pre-set to anything other than the pinned URL.

    A non-empty ``ANTHROPIC_API_KEY`` in the parent env is **not** a refusal:
    ``_build_ollama_env`` strips every ``ANTHROPIC_*`` var from the returned
    dict and re-pins ``ANTHROPIC_BASE_URL`` to localhost, so no traffic can
    leak to Anthropic. Callers that want a clean parent ``os.environ`` for
    incidental subprocesses should invoke :func:`assert_safe_environment_ollama`
    before :func:`build_agent_env`.
    """
    token = os.environ.get("OLLAMA_API_KEY", "")
    if not token:
        raise RuntimeError(
            "OLLAMA_API_KEY is unset or empty. Set it to the Ollama Pro token "
            "before running with provider='ollama'."
        )
    preset_base = os.environ.get("ANTHROPIC_BASE_URL")
    if preset_base and preset_base != OLLAMA_BASE_URL:
        raise RuntimeError(
            f"ANTHROPIC_BASE_URL={preset_base!r} does not match the pinned "
            f"{OLLAMA_BASE_URL!r}. Unset it or point it at the local daemon."
        )
    return token


def detect_sdk_version() -> str | None:
    """Return the installed ``claude_agent_sdk`` version string, or ``None``.

    Returns ``None`` when the package is not importable (subprocess-only
    environments) or when the ``__version__`` attribute is absent.

    Returns:
        Version string (e.g. ``"0.1.59"``) or ``None``.
    """
    try:
        import claude_agent_sdk  # type: ignore[import-untyped]

        return str(claude_agent_sdk.__version__)
    except (ImportError, AttributeError):
        return None


class WorkspaceMismatchError(RuntimeError):
    """Raised when multiple workspace identities are detected in one cycle.

    Cache-reuse assumptions in §§1-2 of CLAUDE.md hold only within a single
    workspace. Mixing credentials that resolve to different workspaces silently
    destroys cache coherence without any observable error from the SDK.
    """


def _probe_workspace_identity() -> frozenset[str] | None:
    """Return workspace identities from the SDK, or None if the probe is absent.

    Returns:
        A frozenset of identity strings when the SDK exposes the probe, or
        None when the SDK does not expose a workspace identity API.
    """
    try:
        import claude_agent_sdk  # type: ignore[import-untyped]

        identities = claude_agent_sdk.get_workspace_identities()
        return frozenset(identities)
    except (ImportError, AttributeError):
        return None


def assert_single_workspace(
    *,
    probe: Callable[[], frozenset[str] | None] | None = None,
    _state: dict[str, object] | None = None,
) -> None:
    """Assert that the active credentials resolve to a single workspace.

    Logs a one-time INFO message when the SDK does not expose a workspace probe
    (the deferred-probe path blessed by §14). Raises WorkspaceMismatchError
    when the probe detects more than one workspace identity.

    Args:
        probe: Optional injectable probe callable, defaults to _probe_workspace_identity.
        _state: Optional mutable state dict for testing; defaults to _WS_STATE.

    Raises:
        WorkspaceMismatchError: When multiple workspace identities are detected.
    """
    state = _state if _state is not None else _WS_STATE

    if _is_localhost_base_url(os.environ.get("ANTHROPIC_BASE_URL")):
        _log_localhost_short_circuit_once(state)
        return

    resolver = probe if probe is not None else _probe_workspace_identity
    identities = resolver()

    if identities is None:
        _log_deferred_probe_once(state)
        return

    if len(identities) > 1:
        listed = ", ".join(sorted(identities))
        raise WorkspaceMismatchError(
            f"Multiple workspace identities detected: {listed}. "
            "All SDK sessions must use a single workspace. "
            "Ensure only one Anthropic API key / OAuth account is active for this invocation."
        )


def _is_localhost_base_url(base_url: str | None) -> bool:
    """Return True when the ANTHROPIC_BASE_URL points at any localhost port.

    Deliberately lenient — any ``http://localhost:*`` prefix matches — because
    the workspace invariant is \"local endpoint\", not the strict :11434 the
    Ollama preflight refusal gate enforces.
    """
    return base_url is not None and base_url.startswith("http://localhost:")


def _log_localhost_short_circuit_once(state: dict[str, object]) -> None:
    """Emit the localhost short-circuit INFO log at most once per invocation."""
    if not state.get("localhost_logged"):
        _logger.info("single-workspace assertion short-circuited — localhost ANTHROPIC_BASE_URL")
        state["localhost_logged"] = True


def _log_deferred_probe_once(state: dict[str, object]) -> None:
    """Emit the deferred-probe INFO log at most once per invocation."""
    if not state["warned"]:
        _logger.info("single-workspace assertion deferred — SDK does not expose workspace probe")
        state["warned"] = True


def assert_safe_environment() -> None:
    """Strip dangerous env vars from the current process, warning about each.

    The process environment is mutated in place so every downstream SDK and
    subprocess call inherits a clean environment — matching the pattern from
    ITAL-IA/kb/run-deep-research.py build_agent_env(). The user does not need
    to unset these variables in their shell.
    """
    offenders = [var for var in DANGEROUS_VARS if var in os.environ]
    if not offenders:
        return

    listed = ", ".join(offenders)
    print(
        f"Using Max subscription (ignoring {listed} for this process).",
        file=sys.stderr,
    )
    strip_dangerous_env()


def assert_safe_environment_ollama() -> None:
    """Strip Anthropic env vars and install the scoped Ollama routing in place.

    Mirrors :func:`assert_safe_environment` for the Ollama codepath: the user
    does not have to ``unset ANTHROPIC_API_KEY`` in their shell. An Anthropic
    credential in the parent env is not a safety hazard here — the scoped
    Ollama env pins ``ANTHROPIC_BASE_URL`` to ``http://localhost:11434`` and
    re-authenticates with ``OLLAMA_API_KEY``, so no traffic reaches Anthropic.

    When ``OLLAMA_API_KEY`` is already present and ``ANTHROPIC_BASE_URL`` is
    unset (or already pinned to localhost), ``ANTHROPIC_AUTH_TOKEN``,
    ``ANTHROPIC_BASE_URL``, and ``ANTHROPIC_API_KEY=""`` are written back
    into ``os.environ`` so every in-process SDK session and every subprocess
    Claude Code spawns inherits the Ollama routing. Without this install
    step, the SDK rejects non-Claude model tags (e.g. ``glm-5.1:cloud``)
    with *"There's an issue with the selected model"* — see the 0.4.8 fix.

    Missing or mismatched preconditions are **not** raised here; the
    downstream :func:`~code_generator.preflight.run_ollama_preflight` +
    :func:`build_agent_env` pair produce the user-facing error messages
    (with ``fix_command`` hints). Raising from this function would bypass
    those surfaces.
    """
    offenders = [var for var in DANGEROUS_VARS if var in os.environ]
    if offenders:
        listed = ", ".join(offenders)
        print(
            f"Using Ollama daemon at {OLLAMA_BASE_URL} (ignoring {listed} for this process).",
            file=sys.stderr,
        )
        strip_dangerous_env()

    token = os.environ.get("OLLAMA_API_KEY", "")
    preset_base = os.environ.get("ANTHROPIC_BASE_URL")
    if not token:
        return
    if preset_base and preset_base != OLLAMA_BASE_URL:
        return

    os.environ["ANTHROPIC_AUTH_TOKEN"] = token
    os.environ["ANTHROPIC_BASE_URL"] = OLLAMA_BASE_URL
    os.environ["ANTHROPIC_API_KEY"] = ""
