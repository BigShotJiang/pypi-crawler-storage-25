"""State retention policy: compact older cycles to summary form.

Keeps the last N=10 ``CycleState`` entries intact; older entries are replaced
with a lightweight ``CycleTelemetrySummary`` containing only the three fields
needed for retrospective display: ``total_tokens``, ``cache_hit_pct``, and
``wall_seconds``.

This module is intentionally pure (no I/O).  ``save_state`` in ``state.py``
is the only caller that wires retention into the persistence path.
"""

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from code_generator.state import CycleState

logger = logging.getLogger(__name__)

_DEFAULT_KEEP = 10


@dataclass(frozen=True)
class CycleTelemetrySummary:
    """Compact retention record for cycles older than the keep window.

    Attributes:
        cycle_name: Original cycle name — display key in ``status`` table.
        total_tokens: Sum of input + output + cache_read + cache_write across
            all phases of the original cycle.
        cache_hit_pct: Cache hit percentage from the cycle's ``cache_telemetry``.
        wall_seconds: Wall-clock duration from the cycle's ``cache_telemetry``.
        kind: JSON discriminator; always ``"summary"`` — never pass explicitly.
    """

    cycle_name: str
    total_tokens: int
    cache_hit_pct: float
    wall_seconds: float
    kind: str = field(default="summary", init=False)


def _compute_total_tokens(cycle: "CycleState") -> int:
    """Sum all four token counters across every phase in a cycle.

    Args:
        cycle: The full :class:`CycleState` to sum.

    Returns:
        Integer total of input + output + cache_read + cache_write.
    """
    total = 0
    for usage in cycle.token_usage.values():
        total += usage.input + usage.output + usage.cache_read + usage.cache_write
    return total


def _summarise(cycle: "CycleState") -> CycleTelemetrySummary:
    """Convert a single :class:`CycleState` to its compact summary form.

    Logs an INFO message so operators can see which cycles were compacted.

    Args:
        cycle: The cycle to compress.

    Returns:
        A :class:`CycleTelemetrySummary` with the retained telemetry fields.
    """
    logger.info("state retention: truncated cycle %s to summary form", cycle.name)
    return CycleTelemetrySummary(
        cycle_name=cycle.name,
        total_tokens=_compute_total_tokens(cycle),
        cache_hit_pct=float(cycle.cache_telemetry.get("cache_hit_pct", 0.0)),
        wall_seconds=float(cycle.cache_telemetry.get("wall_seconds", 0.0)),
    )


def truncate_old_cycles(
    cycles: "list[CycleState]",
    keep: int = _DEFAULT_KEEP,
) -> "list[CycleState | CycleTelemetrySummary]":
    """Replace cycles older than *keep* with compact summary entries.

    The function is pure: it reads cycles and returns a new list without any
    I/O or mutation of the inputs.

    Args:
        cycles: Ordered list of full :class:`CycleState` objects (oldest first).
        keep: Number of most-recent cycles to preserve in full. Default 10.

    Returns:
        A new list where the oldest ``max(0, len(cycles) - keep)`` entries are
        :class:`CycleTelemetrySummary` instances and the newest *keep* entries
        remain as :class:`CycleState`.
    """
    if len(cycles) <= keep:
        return list(cycles)

    split = len(cycles) - keep
    summaries: list[CycleState | CycleTelemetrySummary] = [_summarise(c) for c in cycles[:split]]
    return summaries + list(cycles[split:])
