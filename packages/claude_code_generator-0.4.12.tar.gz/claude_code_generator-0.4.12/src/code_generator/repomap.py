"""Aider-style repo map: tree-sitter + PageRank, ≤200 LOC.

Public API: compute_repomap(project_dir, *, max_tokens=5000) -> str
Falls back to a sentinel string when tree-sitter-languages is not installed.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

_log = logging.getLogger(__name__)

_FALLBACK = "(repomap unavailable — rely on MCP or Read tools)"
_FALLBACK_WARNING = "repomap: tree-sitter not installed; using fallback"

_LANG_MAP: dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
}

_DEF_TYPES: dict[str, frozenset[str]] = {
    "python": frozenset({"function_definition", "class_definition"}),
    "typescript": frozenset(
        {"function_declaration", "class_declaration", "method_definition", "interface_declaration"}
    ),
    "tsx": frozenset(
        {"function_declaration", "class_declaration", "method_definition", "interface_declaration"}
    ),
    "javascript": frozenset({"function_declaration", "class_declaration", "method_definition"}),
}

_SKIP_DIRS: frozenset[str] = frozenset(
    {
        ".git",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        "dist",
        "build",
        ".code-generator",
        "tests",
    }
)

_PAGERANK_ITERATIONS = 25
_PAGERANK_DAMPING = 0.85


def compute_repomap(
    project_dir: Path,
    *,
    max_tokens: int = 5000,
    include_tests: bool = False,
) -> str:
    """Return a PageRank-weighted symbol map capped at *max_tokens* tokens.

    The default skip set excludes ``tests/`` because the repomap is primarily
    consumed by Phase 0/1/2 prompts as a production-shape summary — test
    symbols drown out production ones when included (their cross-fixture
    references push PageRank higher than core production files). Pass
    ``include_tests=True`` to override when tests are actually what you want
    to see.

    Falls back to the sentinel string and logs a WARNING when tree-sitter-languages
    is not installed.
    """
    try:
        from tree_sitter_language_pack import get_parser  # type: ignore[import]
    except ImportError:
        # Fall back to the legacy package when only the old extra is installed.
        try:
            from tree_sitter_languages import get_parser  # type: ignore[import]
        except ImportError:
            _log.warning(_FALLBACK_WARNING)
            return _FALLBACK

    skip_dirs = _SKIP_DIRS - {"tests"} if include_tests else _SKIP_DIRS

    file_symbols: dict[str, list[str]] = {}
    name_to_files: dict[str, list[str]] = defaultdict(list)
    file_refs: dict[str, set[str]] = {}

    for path in _collect_source_files(project_dir, skip_dirs=skip_dirs):
        rel = str(path.relative_to(project_dir))
        lang = _LANG_MAP.get(path.suffix)
        if not lang:
            continue
        _process_file(path, rel, lang, get_parser, file_symbols, name_to_files, file_refs)

    graph = _build_graph(file_symbols, file_refs, name_to_files)
    ranks = _pagerank(graph, set(file_symbols))
    symbols = _rank_symbols(file_symbols, ranks)
    return _format_output(symbols, max_tokens)


def _collect_source_files(
    project_dir: Path,
    *,
    skip_dirs: frozenset[str] = _SKIP_DIRS,
) -> list[Path]:
    """Return source files under *project_dir*, skipping noise directories.

    Skip matching is evaluated on path components **relative to project_dir**
    so that a project whose absolute path happens to contain a skip-listed
    name (e.g. a fixture rooted at ``/repo/tests/fixtures/x/``) is not
    mistakenly emptied out.
    """
    result = []
    for path in project_dir.rglob("*"):
        rel_parts = path.relative_to(project_dir).parts
        if any(part in skip_dirs for part in rel_parts):
            continue
        if path.is_file() and path.suffix in _LANG_MAP:
            result.append(path)
    return result


def _process_file(
    path: Path,
    rel: str,
    lang: str,
    get_parser,  # callable — tree_sitter_languages.get_parser
    file_symbols: dict[str, list[str]],
    name_to_files: dict[str, list[str]],
    file_refs: dict[str, set[str]],
) -> None:
    """Parse one file and populate the shared symbol/reference tables."""
    try:
        source = path.read_bytes()
        tree = get_parser(lang).parse(source)
        if tree.root_node.has_error:
            raise SyntaxError("tree-sitter reported a parse error")
        syms = _extract_definitions(tree.root_node, lang, rel)
        ids = _extract_identifiers(tree.root_node)
    except Exception as exc:  # noqa: BLE001
        _log.warning("repomap: skipping %s: %s", rel, exc)
        return

    file_symbols[rel] = syms
    file_refs[rel] = ids
    for sym in syms:
        name_to_files[sym.split("::")[-1]].append(rel)


def _extract_definitions(root, lang: str, file_rel: str) -> list[str]:
    """Walk *root* iteratively and collect ``file::…::symbol`` keys."""
    def_types = _DEF_TYPES.get(lang, frozenset())
    results: list[str] = []
    stack: list[tuple] = [(root, [])]
    while stack:
        node, parents = stack.pop()
        if node.type in def_types:
            name_node = node.child_by_field_name("name")
            if name_node:
                name = name_node.text.decode("utf-8")
                key = "::".join([file_rel, *parents, name])
                results.append(key)
                stack.extend((c, [*parents, name]) for c in node.children)
                continue
        stack.extend((c, parents) for c in node.children)
    return results


def _extract_identifiers(root) -> set[str]:
    """Collect every identifier string in the syntax tree."""
    ids: set[str] = set()
    stack = [root]
    while stack:
        node = stack.pop()
        if node.type == "identifier":
            ids.add(node.text.decode("utf-8", errors="replace"))
        stack.extend(node.children)
    return ids


def _build_graph(
    file_symbols: dict[str, list[str]],
    file_refs: dict[str, set[str]],
    name_to_files: dict[str, list[str]],
) -> dict[str, set[str]]:
    """Build a file dependency graph: edge A→B when A references a symbol from B."""
    graph: dict[str, set[str]] = {f: set() for f in file_symbols}
    for src, refs in file_refs.items():
        for ident in refs:
            for tgt in name_to_files.get(ident, []):
                if tgt != src:
                    graph.setdefault(src, set()).add(tgt)
    return graph


def _pagerank(graph: dict[str, set[str]], nodes: set[str]) -> dict[str, float]:
    """Iterative PageRank (25 iterations, damping 0.85)."""
    n = len(nodes)
    if n == 0:
        return {}
    rank: dict[str, float] = {node: 1.0 / n for node in nodes}
    base = (1.0 - _PAGERANK_DAMPING) / n
    for _ in range(_PAGERANK_ITERATIONS):
        new_rank: dict[str, float] = {node: base for node in nodes}
        for src, targets in graph.items():
            if targets:
                share = _PAGERANK_DAMPING * rank[src] / len(targets)
                for tgt in targets:
                    new_rank[tgt] += share
        rank = new_rank
    return rank


def _rank_symbols(
    file_symbols: dict[str, list[str]],
    file_ranks: dict[str, float],
) -> list[str]:
    """Return symbol keys sorted by their file's PageRank (descending)."""
    pairs = [(file_ranks.get(f, 0.0), sym) for f, syms in file_symbols.items() for sym in syms]
    pairs.sort(key=lambda x: x[0], reverse=True)
    return [sym for _, sym in pairs]


def _format_output(symbols: list[str], max_tokens: int) -> str:
    """Join symbol keys as lines; stop before exceeding the token budget."""
    lines: list[str] = []
    total_len = 0
    for sym in symbols:
        entry = sym + "\n"
        if (total_len + len(entry)) // 4 > max_tokens:
            break
        lines.append(entry)
        total_len += len(entry)
    return "".join(lines)
