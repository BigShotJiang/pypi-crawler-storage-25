"""Shared-client lifecycle helpers for the cycle orchestrator.

Isolated here so cycle_loop.py stays under the 600-line threshold.
Exposes three callables consumed by cycle_loop:

- ``_open_cycle_client(options_template)`` — returns a ``ClaudeSDKClient``
  async context manager ready for ``async with``.
- ``_build_cycle_options()`` — builds minimal cycle-scoped
  ``ClaudeAgentOptions`` (stable system-prompt + betas + cache_control).
  Per-phase differences (allowed_tools, thinking, task_budget) are applied
  by each phase when it calls ``run_with_shared_client()``.
- ``managed_shared_client(state, state_path)`` — async context manager that
  owns the full lifecycle: env-strip, construction, mark-alive on entry, and
  clear-alive **only** on clean exit (exception leaves ``client_alive_at``
  set so ``--continue`` can detect the orphaned client).
"""

from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING, Any

from code_generator import env as _env
from code_generator import state as _state
from code_generator.runner.mcp import build_mcp_servers, mcp_tool_wildcards
from code_generator.runner.options import make_agent_options

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator.state import State

# Superset of every phase's tools. ClaudeSDKClient locks ``allowed_tools`` at
# open-time; per-query changes do not apply. The shared client must therefore
# open with a superset so any phase running on it can invoke any tool it needs.
# Phase-level narrowing is purely documentary — enforcement moves to the prompts.
_SHARED_CLIENT_ALLOWED_TOOLS: tuple[str, ...] = (
    "Read",
    "Edit",
    "Write",
    "Bash",
    "Glob",
    "Grep",
    # Web access — Phase 3/4 prompt instructs the model to consult upstream
    # docs for unfamiliar libraries before guessing. WebFetch is sandboxed by
    # the API: it can only retrieve URLs already in conversation context (no
    # arbitrary model-generated URLs), which closes the exfiltration vector.
    "WebSearch",
    "WebFetch",
)

# Guard SDK import so this module can be loaded without the SDK installed
# (used by get_runner() to detect availability, and by subprocess-only paths).
try:
    from claude_agent_sdk import ClaudeSDKClient  # type: ignore[import-not-found]

    _SDK_AVAILABLE = True
except ImportError:  # pragma: no cover
    _SDK_AVAILABLE = False
    ClaudeSDKClient = None  # type: ignore[assignment,misc]


def _open_cycle_client(options_template: Any) -> Any:
    """Return a ``ClaudeSDKClient`` async context manager for the cycle.

    Callers use::

        async with _open_cycle_client(options) as client:
            ...

    The *options_template* carries the stable, cycle-scoped settings
    (system-prompt preset, betas, 1-hour cache TTL).  Per-phase differences
    (``allowed_tools``, ``thinking``, ``task_budget``) are applied by each
    phase when it calls ``run_with_shared_client()``.

    Args:
        options_template: Cycle-scoped ``ClaudeAgentOptions`` (or duck-typed
            fallback) produced by ``_build_cycle_options()``.

    Returns:
        A ``ClaudeSDKClient`` instance, which is itself an async context
        manager.

    Raises:
        RuntimeError: When ``claude_agent_sdk`` is not installed.
    """
    if not _SDK_AVAILABLE or ClaudeSDKClient is None:
        raise RuntimeError(
            "claude_agent_sdk is required for shared-session mode; "
            "install it or use --session-mode=fresh."
        )
    return ClaudeSDKClient(options=options_template)


def _build_cycle_options(project_dir: Path) -> Any:
    """Return cycle-scoped options for the shared ``ClaudeSDKClient``.

    ``ClaudeSDKClient`` locks options at open-time — per-query changes do not
    apply. The shared client therefore opens with:

    - ``system_prompt``: canonical ``claude_code`` preset with
      ``exclude_dynamic_sections=True`` (§2 cache-safe prefix).
    - ``extra_headers``: default betas (extended-cache-ttl + token-efficient-tools).
    - ``cache_control``: ``{"type": "ephemeral", "ttl": "1h"}`` (or ``"5m"``
      fallback if the installed SDK does not support ``"1h"``).
    - ``allowed_tools``: superset of every phase's tools (Phase 3/4 is the
      broadest — Read/Edit/Write/Bash/Glob/Grep) plus any MCP wildcards the
      repo exposes. Per-phase narrowing moves to the prompts.
    - ``permission_mode``: ``"bypassPermissions"`` (non-negotiable #3). Without
      this the SDK's default permission prompt intercepts every tool call and
      the model sits asking the orchestrator for approval it cannot give.
    - ``mcp_servers``: codebase-memory + serena fallback, resolved from the
      project dir.

    Args:
        project_dir: Project root; used to resolve MCP servers.

    Returns:
        A ``ClaudeAgentOptions`` instance (or duck-typed fallback) suitable
        for passing to ``_open_cycle_client()``.
    """
    mcp_servers = build_mcp_servers(project_dir)
    allowed_tools: list[str] = list(_SHARED_CLIENT_ALLOWED_TOOLS) + mcp_tool_wildcards(mcp_servers)
    return make_agent_options(
        allowed_tools=allowed_tools,
        permission_mode="bypassPermissions",
        mcp_servers=mcp_servers,
    )


@contextlib.asynccontextmanager
async def managed_shared_client(state: State, state_path: Path):  # type: ignore[return]
    """Async context manager owning the full shared-client lifecycle.

    On entry: strips dangerous env vars (non-negotiable #1), opens one
    ``ClaudeSDKClient``, and calls ``mark_client_alive`` so crash-recovery
    can detect an orphaned session on ``--continue``.

    On **clean** exit: calls ``clear_client_alive`` so ``--continue`` knows
    the client was closed gracefully.

    On **exception**: ``clear_client_alive`` is **not** called.
    ``client_alive_at`` remains set so ``--continue`` treats the client as
    orphaned (crash-recovery FSM — issue #8).

    Usage::

        async with managed_shared_client(state, state_path) as client:
            await _run_phases(..., shared_client=client)

    Args:
        state: Root state (mutated by mark/clear helpers).
        state_path: Path to ``state.json`` for atomic persistence.

    Yields:
        The open ``ClaudeSDKClient`` instance.
    """
    _env.strip_dangerous_env()
    # state.json lives at {project_dir}/.code-generator/state.json.
    project_dir = state_path.parent.parent
    options = _build_cycle_options(project_dir)
    async with _open_cycle_client(options) as client:
        _state.mark_client_alive(state, state_path)
        try:
            yield client
        except BaseException:
            raise
        else:
            _state.clear_client_alive(state, state_path)
