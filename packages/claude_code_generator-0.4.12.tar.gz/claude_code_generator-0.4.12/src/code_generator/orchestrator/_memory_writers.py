"""Cross-issue knowledge persistence helpers for cycle memory files.

Two files are managed here:

``cycle-summary.md``
    Append-only log: one line per successfully closed issue.
    Reset to empty at cycle start (after Phase 1).
    Appended after Phase 7 completes (commit subject is available then).

``project-plan.md``
    Written once at cycle start (after Phase 1) from the issue list in state.
    Never appended to or rewritten mid-cycle.

Both files live under ``.code-generator/memories/`` so they are visible to the
memory tool during the shared session.

All writes go through the atomic helpers in :mod:`code_generator.memory`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from code_generator.memory import append_memory_file, overwrite_memory_file, write_memory_file

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator.state import IssueState


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_CYCLE_SUMMARY_FILE = "cycle-summary.md"
_PROJECT_PLAN_FILE = "project-plan.md"
_PRIORITY_UNKNOWN = "priority:unknown"


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _extract_priority(labels: list[str]) -> str:
    """Return the first ``priority:*`` label, or the unknown placeholder."""
    for label in labels:
        if label.startswith("priority:"):
            return label
    return _PRIORITY_UNKNOWN


def _format_plan_line(issue: IssueState) -> str:
    """Render one ``project-plan.md`` line for *issue*."""
    priority = _extract_priority(issue.labels)
    return f"- #{issue.number} [{priority}] {issue.title} — agent: {issue.agent}"


def _format_summary_line(issue: IssueState, commit_subject: str) -> str:
    """Render one ``cycle-summary.md`` line for *issue*.

    Uses *commit_subject* when non-empty; falls back to the issue title.
    """
    summary = commit_subject if commit_subject else issue.title
    return f"Issue #{issue.number}: {issue.title} — {summary}\n"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def reset_cycle_summary(memories_dir: Path) -> None:
    """Atomically overwrite ``cycle-summary.md`` with an empty string.

    Call once at cycle start (after Phase 1 returns) to clear any stale
    content from a previous cycle.

    Args:
        memories_dir: Root memories directory (created if absent).
    """
    overwrite_memory_file(memories_dir, _CYCLE_SUMMARY_FILE, "")


def write_project_plan(issues: list[IssueState], memories_dir: Path) -> None:
    """Atomically write ``project-plan.md`` from the current issue list.

    Called once at cycle start (after Phase 1 returns).  **Never** appended
    to or rewritten mid-cycle.

    Args:
        issues: All issues in the current cycle (from ``state.get_issues()``).
        memories_dir: Root memories directory (created if absent).
    """
    if not issues:
        write_memory_file(memories_dir, _PROJECT_PLAN_FILE, "")
        return
    lines = [_format_plan_line(issue) for issue in issues]
    write_memory_file(memories_dir, _PROJECT_PLAN_FILE, "\n".join(lines) + "\n")


def append_cycle_summaries(
    issues: list[IssueState],
    commit_subject: str,
    memories_dir: Path,
) -> None:
    """Append one summary line per closed issue to ``cycle-summary.md``.

    Called after Phase 7 completes so the commit subject (the most
    authoritative single-line summary of the batch) is available.  When
    *commit_subject* is empty the issue title is used as the fallback.

    Only issues with ``status == "closed"`` produce a line; open issues are
    silently skipped.

    Args:
        issues: All issues in the current scope (closed ones are filtered).
        commit_subject: First line of the Phase 7 commit message, or ``""``
            when Phase 7 staged nothing (no-op commit).
        memories_dir: Root memories directory (created if absent).
    """
    for issue in issues:
        if issue.status == "closed":
            line = _format_summary_line(issue, commit_subject)
            append_memory_file(memories_dir, _CYCLE_SUMMARY_FILE, line)
