"""Shared comment-fetching helpers for phase orchestrators.

Centralises the duplicated ``gh.view_issue`` + ``GhError`` fallback logic
that previously lived independently in phase2, phase3_4, and phase5.

Public API
----------
fetch_issue_comments(repo, number, logger) -> list[dict]
    Fetch raw comment dicts for one issue; returns [] on GhError.

fetch_formatted_comments(repo, number, logger) -> str
    Convenience wrapper: raw comments → formatted markdown section.

get_or_fetch_comments(issue, repo, state, state_path, logger) -> str
    Cache-first: return IssueState.comments when set, else fetch + persist.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from code_generator import gh
from code_generator.prompts import format_comments

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.repo_info import RepoInfo
    from code_generator.state import IssueState, State

__all__ = ["fetch_formatted_comments", "fetch_issue_comments", "get_or_fetch_comments"]


def fetch_issue_comments(
    repo: RepoInfo,
    number: int,
    logger: logging.Logger,
) -> list[dict]:  # type: ignore[type-arg]
    """Fetch raw comment dicts for *number*; return empty list on GhError.

    Args:
        repo: Repository to target.
        number: GitHub issue number.
        logger: Logger for warnings when the gh call fails.

    Returns:
        List of comment dicts extracted from the issue data, or ``[]``
        when :class:`~code_generator.gh.GhError` is raised.
    """
    try:
        issue_data = gh.view_issue(repo, number)
        return issue_data.get("comments", [])
    except gh.GhError as exc:
        logger.warning(
            "Could not fetch comments for issue #%d: %s. Continuing with empty comments.",
            number,
            exc,
        )
        return []


def fetch_formatted_comments(
    repo: RepoInfo,
    number: int,
    logger: logging.Logger,
) -> str:
    """Fetch and format issue comments as a markdown section.

    Calls :func:`fetch_issue_comments` then passes the result through
    :func:`~code_generator.prompts.format_comments`.

    Args:
        repo: Repository to target.
        number: GitHub issue number.
        logger: Logger forwarded to :func:`fetch_issue_comments`.

    Returns:
        Formatted ``## Issue Comments`` markdown section, or ``""`` when
        no comments exist or the gh call fails.
    """
    comments = fetch_issue_comments(repo, number, logger)
    return format_comments(comments)


def get_or_fetch_comments(
    issue: IssueState,
    repo: RepoInfo,
    state: State,
    state_path: Path,
    logger: logging.Logger,
) -> str:
    """Return cached comments or fetch, persist, and return live comments.

    If ``issue.comments`` is already populated (not ``None``), return it
    directly without touching the network.  Otherwise call
    :func:`fetch_formatted_comments`, persist the result onto the issue, and
    save state atomically before returning.

    Args:
        issue: The issue whose comments are needed.
        repo: Repository to target (used only on cache miss).
        state: Root state object (mutated in place on cache miss).
        state_path: Absolute path to ``state.json`` (used only on cache miss).
        logger: Logger for info/warning messages.

    Returns:
        Formatted ``## Issue Comments`` markdown section (may be ``""`` when
        the issue has no comments or the gh call fails).
    """
    if issue.comments is not None:
        logger.info("Phase: issue #%d comments cached — reusing.", issue.number)
        return issue.comments

    from code_generator.state import save_state  # local import to avoid circular

    comments = fetch_formatted_comments(repo, issue.number, logger)
    issue.comments = comments
    save_state(state_path, state)
    return comments
