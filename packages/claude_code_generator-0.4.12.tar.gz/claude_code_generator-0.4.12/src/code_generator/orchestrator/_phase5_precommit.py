"""Phase 5 pre-commit gate: run local linters before the SDK session.

Runs ``ruff check``, ``ruff format --check``, and ``mypy`` (when configured)
against the project directory. Returns an aggregated lint-error string and a
``is_clean`` boolean so Phase 5 can skip the expensive SDK call entirely on a
clean run.

SRP: each function handles exactly one tool. The aggregator composes them.
"""

from __future__ import annotations

import subprocess
import tomllib
from typing import TYPE_CHECKING

from code_generator.prompts import truncate_placeholder

if TYPE_CHECKING:
    import logging
    from pathlib import Path

__all__ = [
    "run_ruff_check",
    "run_ruff_format_check",
    "run_mypy_if_configured",
    "collect_lint_errors",
]

_MAX_LINT_TOKENS = 5000


def run_ruff_check(project_dir: Path) -> tuple[str, int] | None:
    """Run ``ruff check --output-format=concise`` on src and tests.

    Args:
        project_dir: Project root directory.

    Returns:
        ``(stdout+stderr, returncode)`` on success, or ``None`` when the ruff
        binary is not found.
    """
    try:
        result = subprocess.run(
            ["ruff", "check", "--output-format=concise", "src", "tests"],
            capture_output=True,
            text=True,
            check=False,
            cwd=str(project_dir),
        )
    except FileNotFoundError:
        return None
    return (result.stdout + result.stderr).strip(), result.returncode


def run_ruff_format_check(project_dir: Path) -> tuple[str, int] | None:
    """Run ``ruff format --check`` on src and tests.

    Args:
        project_dir: Project root directory.

    Returns:
        ``(stdout+stderr, returncode)`` on success, or ``None`` when the ruff
        binary is not found.
    """
    try:
        result = subprocess.run(
            ["ruff", "format", "--check", "src", "tests"],
            capture_output=True,
            text=True,
            check=False,
            cwd=str(project_dir),
        )
    except FileNotFoundError:
        return None
    return (result.stdout + result.stderr).strip(), result.returncode


def run_mypy_if_configured(project_dir: Path) -> tuple[str, int] | None:
    """Run ``mypy src`` only when ``pyproject.toml`` declares ``[tool.mypy]``.

    Args:
        project_dir: Project root directory.

    Returns:
        ``(stdout+stderr, returncode)`` when mypy ran, or ``None`` when mypy is
        not configured, the binary is missing, or ``pyproject.toml`` is absent.
    """
    pyproject = project_dir / "pyproject.toml"
    if not pyproject.exists():
        return None
    try:
        config = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError:
        return None
    if "mypy" not in config.get("tool", {}):
        return None
    try:
        result = subprocess.run(
            ["mypy", "src"],
            capture_output=True,
            text=True,
            check=False,
            cwd=str(project_dir),
        )
    except FileNotFoundError:
        return None
    return (result.stdout + result.stderr).strip(), result.returncode


def collect_lint_errors(
    project_dir: Path,
    logger: logging.Logger,
) -> tuple[str, bool]:
    """Run all linters and aggregate results.

    Logs a WARNING when ruff or mypy binary is missing and continues.
    Truncates the combined output to ``_MAX_LINT_TOKENS`` tokens via the
    existing :func:`~code_generator.prompts.truncate_placeholder` helper.

    Args:
        project_dir: Project root directory.
        logger: Logger for missing-binary warnings.

    Returns:
        Tuple of ``(aggregated_errors, is_clean)`` where ``is_clean`` is
        ``True`` only when every tool that actually ran exited with code 0.
    """
    parts: list[str] = []
    has_errors = False

    ruff_check = run_ruff_check(project_dir)
    if ruff_check is None:
        logger.warning("Phase 5: ruff binary not found — skipping ruff check/format")
    else:
        output, code = ruff_check
        if output:
            parts.append(f"[ruff check]\n{output}")
        if code != 0:
            has_errors = True

    ruff_fmt = run_ruff_format_check(project_dir)
    if ruff_fmt is None and ruff_check is not None:
        # ruff was found for check but not format — unusual, still warn
        logger.warning("Phase 5: ruff format check failed to run")
    elif ruff_fmt is not None:
        output, code = ruff_fmt
        if output:
            parts.append(f"[ruff format]\n{output}")
        if code != 0:
            has_errors = True

    mypy_result = run_mypy_if_configured(project_dir)
    if mypy_result is None:
        pass  # not configured or binary missing — not an error
    else:
        output, code = mypy_result
        if output:
            parts.append(f"[mypy]\n{output}")
        if code != 0:
            has_errors = True

    combined = "\n\n".join(parts)
    truncated = truncate_placeholder(combined, max_tokens=_MAX_LINT_TOKENS)
    return truncated, not has_errors
