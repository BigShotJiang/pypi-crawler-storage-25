"""Per-cycle safety backstop for the Ollama codepath.

The pre-0.4.11 design treated ``OLLAMA_TURN_BUDGET`` as a hard abort trigger
— cycles were aborted after exactly 200 turns regardless of whether the
model was making progress. That is the wrong layer: actual fault-detection
already lives in two places and triggers on real malfunctions, not on an
arbitrary counter:

  * :class:`~code_generator.runner.retry.CircuitBreaker` — trips after ``N``
    consecutive failures on a single phase call. Already wrapped around
    Phase 2 (per-issue / batched review), Phase 3/4 (TDD implementation),
    and Phase 5 (closure).
  * :func:`~code_generator.runner.rate_limit.handle_ollama_429` —
    wait-and-resume on 429s returned by the Ollama daemon.

This module therefore degrades to a **non-blocking adaptive** backstop:

  * The turn counter now emits a single **WARNING** when the cycle crosses
    the soft threshold (default 500). The pipeline is **never** aborted on
    the turn count alone. Weak open models are chatty by design; letting
    them run is the right call.
  * The wall-clock cap remains a **hard abort**, but the default is raised
    to 4 hours. It exists purely to catch a stuck daemon or a model trapped
    in a pathological loop the CircuitBreaker cannot see (e.g. infinite
    ``end_turn``→``continue`` cycle producing no tool calls).

Both thresholds are env-overridable:

  * ``OLLAMA_SOFT_TURN_WARN``  (int, positive; default 500)
  * ``OLLAMA_WALLCLOCK_BUDGET_SECONDS``  (int, positive; default 14400)

Backwards-compatible shim: the old ``OLLAMA_TURN_BUDGET`` env variable is
still honoured and maps onto the soft-warn threshold, so operators with
existing scripts see no behaviour change beyond the abort becoming a
warning.

Nothing is persisted in ``state.json`` — the tracker is per-run and
discarded on abort or clean completion.
"""

from __future__ import annotations

import logging
import os
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

    from code_generator.state import CycleState, State

_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Threshold constants
# ---------------------------------------------------------------------------

_DEFAULT_SOFT_TURN_WARN = 500
_DEFAULT_WALLCLOCK_BUDGET_SECONDS = 14400  # 4 h


def _read_int_env(name: str, default: int) -> int:
    """Parse a positive int from the environment, falling back to *default*.

    Invalid values (empty, non-numeric, zero, or negative) are silently
    replaced with *default* — these are per-run tuning knobs, not safety
    gates, so noisy error handling would surprise operators who meant well.
    """
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if value > 0 else default


def _resolve_soft_turn_warn() -> int:
    """Honour the legacy ``OLLAMA_TURN_BUDGET`` env var for backwards compat."""
    legacy = _read_int_env("OLLAMA_TURN_BUDGET", 0)
    if legacy:
        return legacy
    return _read_int_env("OLLAMA_SOFT_TURN_WARN", _DEFAULT_SOFT_TURN_WARN)


OLLAMA_SOFT_TURN_WARN = _resolve_soft_turn_warn()
"""Soft warning threshold on per-cycle ``num_turns``.

Defaults to 500. Override via ``OLLAMA_SOFT_TURN_WARN`` (new name) or the
legacy ``OLLAMA_TURN_BUDGET`` (preserved for backwards compatibility). The
value is **non-blocking**: the pipeline only logs a WARNING once per cycle
when the cumulative turn count first crosses this threshold. It never
aborts.
"""

# Kept as a module-level alias so existing importers (tests, scripts) keep
# working. The semantics are now "soft warning threshold", not "abort".
OLLAMA_TURN_BUDGET = OLLAMA_SOFT_TURN_WARN
"""Backwards-compatible alias for :data:`OLLAMA_SOFT_TURN_WARN`."""

OLLAMA_WALLCLOCK_BUDGET_SECONDS = _read_int_env(
    "OLLAMA_WALLCLOCK_BUDGET_SECONDS", _DEFAULT_WALLCLOCK_BUDGET_SECONDS
)
"""Hard wall-clock abort threshold (seconds) per cycle on the Ollama codepath.

Defaults to 14400 (4 h); override via ``OLLAMA_WALLCLOCK_BUDGET_SECONDS``.
This is the only hard abort enforced by this module — it exists to catch a
stuck daemon or a pathological loop the per-phase
:class:`~code_generator.runner.retry.CircuitBreaker` cannot see.
"""


# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------


class OllamaBudgetExceeded(RuntimeError):
    """Raised when the Ollama per-cycle wall-clock backstop is exceeded.

    Only fires on the wall-clock path. The turn counter now emits a WARNING
    instead; real per-call failures are handled by the ``CircuitBreaker``
    in :mod:`code_generator.runner.retry`.

    Subclasses ``RuntimeError`` to match the existing safety-abort hierarchy
    (e.g. :class:`~code_generator.runner.types.OverageAbort`).
    """


# ---------------------------------------------------------------------------
# Tracker
# ---------------------------------------------------------------------------


class OllamaBudgetTracker:
    """Adaptive per-cycle safety backstop; a no-op on the Anthropic Max path.

    Emits one WARNING when the cycle crosses the soft turn threshold; aborts
    only on the wall-clock backstop. Does **not** block the pipeline on the
    turn count — real failures are the responsibility of
    :class:`~code_generator.runner.retry.CircuitBreaker` and the rate-limit
    handlers in :mod:`code_generator.runner.rate_limit`.
    """

    def __init__(
        self,
        *,
        provider_is_ollama: bool,
        clock: Callable[[], float] | None = None,
    ) -> None:
        """Initialise a tracker; call :meth:`start` at cycle kickoff.

        Args:
            provider_is_ollama: When False every :meth:`check` call is a
                no-op so the Anthropic Max path stays byte-for-byte unchanged.
            clock: Injectable monotonic clock for deterministic tests;
                defaults to ``time.monotonic``.
        """
        self._active = provider_is_ollama
        self._clock = clock or time.monotonic
        self._start_time: float | None = None
        self._turn_warning_emitted = False

    def start(self) -> None:
        """Record the cycle start time. Idempotent; only the first call matters."""
        if self._active and self._start_time is None:
            self._start_time = self._clock()

    def check(self, state: State, cycle: CycleState | None) -> None:
        """Warn on soft-turn threshold; raise only on wall-clock overflow."""
        if not self._active:
            return
        self._check_turn_soft_warn(state, cycle)
        self._check_wallclock_budget()

    def _check_turn_soft_warn(self, state: State, cycle: CycleState | None) -> None:
        """Emit one WARNING the first time the cycle crosses the soft threshold.

        Never raises. Subsequent checks in the same cycle are no-ops because
        the warning flag is sticky until the tracker is discarded.
        """
        if self._turn_warning_emitted:
            return
        total = _sum_num_turns(state, cycle)
        if total > OLLAMA_SOFT_TURN_WARN:
            _logger.warning(
                "Ollama cycle has consumed %d turns (soft threshold: %d). "
                "Letting it run — real failures are caught by the per-phase "
                "CircuitBreaker in runner/retry.py. Raise the threshold via "
                "OLLAMA_SOFT_TURN_WARN or the legacy OLLAMA_TURN_BUDGET env "
                "var to silence this warning.",
                total,
                OLLAMA_SOFT_TURN_WARN,
            )
            self._turn_warning_emitted = True

    def _check_wallclock_budget(self) -> None:
        if self._start_time is None:
            return
        elapsed = self._clock() - self._start_time
        if elapsed > OLLAMA_WALLCLOCK_BUDGET_SECONDS:
            raise OllamaBudgetExceeded(
                f"Ollama wall-clock budget exceeded: {elapsed:.0f}s > "
                f"{OLLAMA_WALLCLOCK_BUDGET_SECONDS}s. "
                "Raise OLLAMA_WALLCLOCK_BUDGET_SECONDS (env var) if real "
                "workloads legitimately need more than 4 hours per cycle."
            )


def _sum_num_turns(state: State, cycle: CycleState | None) -> int:
    """Sum ``num_turns`` across every phase of the active cycle (or state)."""
    source = cycle.token_usage if cycle is not None else state.token_usage
    return sum(usage.num_turns for usage in source.values())
