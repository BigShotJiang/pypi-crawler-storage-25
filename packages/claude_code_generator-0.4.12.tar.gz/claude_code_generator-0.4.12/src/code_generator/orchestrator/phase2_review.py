"""Phase 2 — Global cycle review (batched).

All open, unreviewed issues for the current cycle are evaluated in a single
Opus 4.7 call that returns a JSON ``{"decisions": [...]}`` payload. The
orchestrator posts a ``gh issue comment`` only on issues whose decision is
not ``"ok"`` and then marks every reviewed issue in one atomic
``save_state``.

``run_batch`` (the Anthropic Messages Batches API path, entered when
``state.session_mode == "batch"``) is preserved unchanged for callers that
opt into asynchronous per-issue batches — it is a separate concern from
this prompt-level batched review.

Non-negotiable #8: model is hard-coded to ``claude-opus-4-7``.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from code_generator import effort as _effort
from code_generator import gh
from code_generator import memory as _memory
from code_generator.logging_setup import log_issue_usage, log_phase_usage, setup_phase_logger
from code_generator.orchestrator._comments import fetch_formatted_comments
from code_generator.prompts import load_prompt
from code_generator.runner import rate_limit, retry
from code_generator.runner._telemetry import accumulate_telemetry
from code_generator.runner.mcp import build_mcp_servers, mcp_tool_wildcards
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.runner.sdk_runner import run_with_shared_client
from code_generator.runner.soft_reset import soft_reset_context
from code_generator.runner.types import MaxTurnsExceeded, TokenUsage
from code_generator.state import get_issues, save_state

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.runner.types import RunResult
    from code_generator.state import CycleState, State

# Lazy module-level references to batch symbols — imported on first use inside
# run_batch so the module loads cleanly when the anthropic package is absent.
# The names are re-exported here so tests can patch them via the
# ``code_generator.orchestrator.phase2_review`` namespace.
try:
    from code_generator.runner.batch import (  # noqa: F401
        BatchId,
        BatchPollError,
        BatchRequest,
        BatchSubmitError,
        poll_batch,
        submit_batch,
    )
except ImportError:  # pragma: no cover — anthropic not installed in some envs
    BatchId = None  # type: ignore[assignment, misc]
    BatchPollError = None  # type: ignore[assignment]
    BatchRequest = None  # type: ignore[assignment]
    BatchSubmitError = None  # type: ignore[assignment]
    poll_batch = None  # type: ignore[assignment]
    submit_batch = None  # type: ignore[assignment]


async def _run_one_review(
    prompt: str,
    options: Any,
    *,
    runner_module: RunnerProtocol,
    shared_client: Any | None,
    state_path: Path,
    logger: logging.Logger,
) -> RunResult:
    """Dispatch one issue review to shared-client or fresh-runner path."""
    if shared_client is not None:
        return await run_with_shared_client(
            shared_client, prompt, options, logger=logger, state_path=state_path
        )
    return await rate_limit.main_loop(
        runner_module, prompt, options, state_path=state_path, logger=logger
    )


_PHASE2_DEFAULT_MODEL = "claude-opus-4-7"
# CLAUDE.md invariant #8; overridden via ``effective_model`` on Ollama — #219.


async def run_batch(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    shared_client: Any = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Execute phase 2 using the Anthropic Messages Batches API for N-1 issues.

    The first issue (warm-up) is processed via the regular runner to prime the
    shared client context.  The remaining N-1 issues are submitted as a single
    batch request.  When N==1, degrades gracefully to plain warm-up (no batch).

    On ``BatchSubmitError`` the function falls back to per-issue fresh runner
    for all remaining issues.  On ``TimeoutError`` or ``BatchPollError`` during
    polling the same fallback applies.

    ``phase2_batch_id`` is persisted before polling so that ``--continue`` can
    resume polling without re-submitting.

    Args:
        state: Root state object.
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
        shared_client: Open ``ClaudeSDKClient`` (or duck-typed equivalent)
            owned by the caller for the warm-up step.
    """
    if logger is None:
        logger = setup_phase_logger("phase2", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"
    repo = state.repo
    assert repo is not None, "state.repo must be set by preflight before Phase 2 batch runs"
    target = cycle if cycle is not None else state

    issues = get_issues(state, cycle)
    open_unreviewed = [i for i in issues if i.status == "open" and not i.reviewed]

    if not open_unreviewed:
        logger.info("Phase 2 batch: no open unreviewed issues — skipping.")
        return

    phase_total = TokenUsage()
    phase_wall = 0.0
    mcp_servers = build_mcp_servers(project_dir)
    mcp_tools = mcp_tool_wildcards(mcp_servers)
    memories_dir = project_dir / ".code-generator" / "memories"

    # In the resume path (batch_id already set), all open_unreviewed are the
    # batch issues that still need polling.  In the fresh path, the first issue
    # is the warm-up and the rest go to the batch.
    warmup_issue = open_unreviewed[0]
    remaining = open_unreviewed[1:]

    # Track which issues belong to the pending batch for the polling step.
    # In the resume path (batch_id already set), ALL open_unreviewed are batch
    # issues (warm-up already marked reviewed in the prior run).
    # In the fresh path, only ``remaining`` (open_unreviewed[1:]) are batched.
    _batch_issues: list = open_unreviewed if target.phase2_batch_id is not None else remaining

    # ------------------------------------------------------------------
    # Step 1: warm-up issue (always via regular runner)
    # ------------------------------------------------------------------
    if target.phase2_batch_id is None:
        logger.info(
            "Phase 2 batch: warm-up issue #%d (agent=%s).",
            warmup_issue.number,
            warmup_issue.agent,
        )

        if warmup_issue.comments is None:
            warmup_issue.comments = fetch_formatted_comments(repo, warmup_issue.number, logger)
            save_state(state_path, state)

        repo_map = _memory.read_cycle_repomap(memories_dir)
        warmup_prompt = load_prompt(
            "prompt-phase-2-issue-review.md",
            ISSUE_NUMBER=str(warmup_issue.number),
            PRIMARY_AGENT=warmup_issue.agent,
            ISSUE_COMMENTS=warmup_issue.comments,
            REPO_MAP=repo_map,
        )
        effort_level = _effort.resolve_effort(
            phase=2, complexity="", issue_labels=warmup_issue.labels, retry_count=0
        )
        _phase2_model = effective_model or _PHASE2_DEFAULT_MODEL
        _effort.validate_effort(effort_level, _phase2_model)
        warmup_options = make_agent_options(
            model=_phase2_model,
            effort=effort_level,
            allowed_tools=["Read", "Bash", "Glob", "Grep", "WebSearch", "WebFetch"] + mcp_tools,
            cwd=str(project_dir),
            mcp_servers=mcp_servers,
            context_management=None,
            **max_turns_kwargs(max_turns),
        )
        warmup_breaker = retry.CircuitBreaker(max_failures=3)
        warmup_reviewed = True
        warmup_usage = TokenUsage()
        warmup_wall = 0.0

        try:
            warmup_result = await retry.with_backoff(
                lambda p=warmup_prompt, o=warmup_options: _run_one_review(
                    p,
                    o,
                    runner_module=runner_module,
                    shared_client=shared_client,
                    state_path=state_path,
                    logger=logger,
                ),
                breaker=warmup_breaker,
            )
            warmup_usage = warmup_result.usage if warmup_result is not None else TokenUsage()
            warmup_wall = warmup_result.wall_seconds if warmup_result is not None else 0.0
        except MaxTurnsExceeded:
            warmup_reviewed = False
            logger.error(
                "Phase 2 batch: warm-up issue #%d hit max_turns — tagging for manual review.",
                warmup_issue.number,
            )
            try:
                gh.add_label(repo, warmup_issue.number, "needs-manual-review")
            except gh.GhError as exc:
                logger.warning(
                    "Could not add needs-manual-review label to #%d: %s",
                    warmup_issue.number,
                    exc,
                )
        except retry.CircuitOpen:
            warmup_reviewed = False
            logger.error(
                "Phase 2 batch: circuit breaker opened for warm-up issue #%d — tagging.",
                warmup_issue.number,
            )
            try:
                gh.add_label(repo, warmup_issue.number, "needs-manual-review")
            except gh.GhError as exc:
                logger.warning(
                    "Could not add needs-manual-review label to #%d: %s",
                    warmup_issue.number,
                    exc,
                )

        log_issue_usage(logger, 2, warmup_issue.number, warmup_usage)
        phase_total += warmup_usage
        phase_wall += warmup_wall

        if warmup_reviewed:
            warmup_issue.reviewed = True
            save_state(state_path, state)
            logger.info("Phase 2 batch: warm-up issue #%d reviewed.", warmup_issue.number)

        # N=1 edge case: no remaining issues, nothing to batch.
        if not remaining:
            target.token_usage["phase2"] = phase_total
            if hasattr(target, "cache_telemetry"):
                accumulate_telemetry(target.cache_telemetry, phase_total, phase_wall)  # type: ignore[union-attr]  # type: ignore[union-attr]
            save_state(state_path, state)
            log_phase_usage(logger, 2, phase_total)
            return

        # ------------------------------------------------------------------
        # Step 2: build and submit batch for remaining issues
        # ------------------------------------------------------------------
        batch_requests: list = []  # list[BatchRequest]; untyped to avoid None-guard issues
        for issue in remaining:
            if issue.comments is None:
                issue.comments = fetch_formatted_comments(repo, issue.number, logger)
                save_state(state_path, state)
            repo_map = _memory.read_cycle_repomap(memories_dir)
            prompt = load_prompt(
                "prompt-phase-2-issue-review.md",
                ISSUE_NUMBER=str(issue.number),
                PRIMARY_AGENT=issue.agent,
                ISSUE_COMMENTS=issue.comments,
                REPO_MAP=repo_map,
            )
            params = {
                "model": "claude-opus-4-7",
                "max_tokens": 8192,
                "messages": [{"role": "user", "content": prompt}],
            }
            batch_requests.append(
                BatchRequest(custom_id=f"phase2-issue-{issue.number}", params=params)  # type: ignore[misc]
            )

        try:
            batch_id = await submit_batch(batch_requests)  # type: ignore[misc]
        except BatchSubmitError as exc:  # type: ignore[misc]
            logger.warning(
                "Phase 2 batch: submit_batch failed (%s) — falling back to per-issue runner.",
                exc,
            )
            target.phase2_batch_id = None
            for issue in remaining:
                await _run_fallback_review(
                    issue,
                    state,
                    state_path,
                    project_dir,
                    runner_module=runner_module,
                    shared_client=shared_client,
                    mcp_servers=mcp_servers,
                    mcp_tools=mcp_tools,
                    memories_dir=memories_dir,
                    logger=logger,
                    repo=repo,
                    max_turns=max_turns,
                    effective_model=effective_model,
                )
            target.token_usage["phase2"] = phase_total
            if hasattr(target, "cache_telemetry"):
                accumulate_telemetry(target.cache_telemetry, phase_total, phase_wall)  # type: ignore[union-attr]  # type: ignore[union-attr]
            save_state(state_path, state)
            log_phase_usage(logger, 2, phase_total)
            return

        # Persist batch_id BEFORE polling so --continue can resume.
        target.phase2_batch_id = str(batch_id)
        save_state(state_path, state)
        logger.info("Phase 2 batch: submitted batch %s for %d issues.", batch_id, len(remaining))

    # ------------------------------------------------------------------
    # Step 3: poll batch (entered on first run after submission or on --continue)
    # ------------------------------------------------------------------
    current_batch_id = BatchId(target.phase2_batch_id)  # type: ignore[arg-type]
    # In the resume path (phase2_batch_id was already set on entry), all
    # open_unreviewed issues belong to the batch.  In the fresh path,
    # _batch_issues already points to ``remaining`` (open_unreviewed[1:]).
    remaining_unreviewed = [i for i in _batch_issues if not i.reviewed]

    try:
        results = await poll_batch(current_batch_id)  # type: ignore[misc]
    except (TimeoutError, BatchPollError) as exc:  # type: ignore[misc]
        logger.warning(
            "Phase 2 batch: poll_batch failed (%s) — falling back to per-issue runner.",
            exc,
        )
        for issue in remaining_unreviewed:
            await _run_fallback_review(
                issue,
                state,
                state_path,
                project_dir,
                runner_module=runner_module,
                shared_client=shared_client,
                mcp_servers=mcp_servers,
                mcp_tools=mcp_tools,
                memories_dir=memories_dir,
                logger=logger,
                repo=repo,
                max_turns=max_turns,
                effective_model=effective_model,
            )
        target.token_usage["phase2"] = phase_total
        if hasattr(target, "cache_telemetry"):
            accumulate_telemetry(target.cache_telemetry, phase_total, phase_wall)  # type: ignore[union-attr]
        save_state(state_path, state)
        log_phase_usage(logger, 2, phase_total)
        return

    # ------------------------------------------------------------------
    # Step 4: process batch results
    # ------------------------------------------------------------------
    issue_by_number = {i.number: i for i in remaining_unreviewed}
    for result in results:
        # custom_id format: "phase2-issue-{number}"
        parts = result.custom_id.split("-")
        if len(parts) >= 3 and parts[0] == "phase2" and parts[1] == "issue":
            try:
                number = int(parts[2])
            except ValueError:
                continue
            issue = issue_by_number.get(number)
            if issue is not None:
                issue.reviewed = True
                save_state(state_path, state)
                logger.info("Phase 2 batch: issue #%d reviewed (batch result).", number)

    # ------------------------------------------------------------------
    # Step 5: clear batch_id and finalize
    # ------------------------------------------------------------------
    target.phase2_batch_id = None
    target.token_usage["phase2"] = phase_total
    if hasattr(target, "cache_telemetry"):
        accumulate_telemetry(target.cache_telemetry, phase_total, phase_wall)  # type: ignore[union-attr]
    save_state(state_path, state)
    log_phase_usage(logger, 2, phase_total)


async def _run_fallback_review(
    issue: Any,
    state: Any,
    state_path: Any,
    project_dir: Any,
    *,
    runner_module: RunnerProtocol,
    shared_client: Any,
    mcp_servers: Any,
    mcp_tools: Any,
    memories_dir: Any,
    logger: Any,
    repo: Any,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Process a single issue via the regular (non-batch) runner path.

    Used as the fallback when batch submission or polling fails.

    Args:
        issue: The :class:`IssueState` to review.
        state: Root state (mutated in place).
        state_path: Path for atomic state persistence.
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        shared_client: Shared SDK client, or ``None`` for fresh mode.
        mcp_servers: MCP server dict (may be ``None``).
        mcp_tools: List of allowed MCP tool wildcards.
        memories_dir: Path to the memories directory.
        logger: Phase logger.
        repo: :class:`RepoInfo` for gh operations.
    """
    if issue.comments is None:
        issue.comments = fetch_formatted_comments(repo, issue.number, logger)
        save_state(state_path, state)

    repo_map = _memory.read_cycle_repomap(memories_dir)
    prompt = load_prompt(
        "prompt-phase-2-issue-review.md",
        ISSUE_NUMBER=str(issue.number),
        PRIMARY_AGENT=issue.agent,
        ISSUE_COMMENTS=issue.comments,
        REPO_MAP=repo_map,
    )
    effort_level = _effort.resolve_effort(
        phase=2, complexity="", issue_labels=issue.labels, retry_count=0
    )
    _fallback_model = effective_model or _PHASE2_DEFAULT_MODEL
    _effort.validate_effort(effort_level, _fallback_model)
    options = make_agent_options(
        model=_fallback_model,
        effort=effort_level,
        allowed_tools=["Read", "Bash", "Glob", "Grep", "WebSearch", "WebFetch"] + mcp_tools,
        cwd=str(project_dir),
        mcp_servers=mcp_servers,
        context_management=None,
        **max_turns_kwargs(max_turns),
    )
    breaker = retry.CircuitBreaker(max_failures=3)
    reviewed = True

    try:
        await retry.with_backoff(
            lambda p=prompt, o=options: _run_one_review(
                p,
                o,
                runner_module=runner_module,
                shared_client=shared_client,
                state_path=state_path,
                logger=logger,
            ),
            breaker=breaker,
        )
    except MaxTurnsExceeded:
        reviewed = False
        logger.error(
            "Phase 2 batch fallback: issue #%d hit max_turns — tagging for manual review.",
            issue.number,
        )
        try:
            gh.add_label(repo, issue.number, "needs-manual-review")
        except gh.GhError as exc:
            logger.warning(
                "Could not add needs-manual-review label to #%d: %s",
                issue.number,
                exc,
            )
    except retry.CircuitOpen:
        reviewed = False
        logger.error(
            "Phase 2 batch fallback: circuit breaker opened for issue #%d — tagging.",
            issue.number,
        )
        try:
            gh.add_label(repo, issue.number, "needs-manual-review")
        except gh.GhError as exc:
            logger.warning(
                "Could not add needs-manual-review label to #%d: %s",
                issue.number,
                exc,
            )

    if reviewed:
        issue.reviewed = True
        save_state(state_path, state)
        logger.info("Phase 2 batch fallback: issue #%d reviewed.", issue.number)


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    shared_client: Any = None,
    max_turns: int | None = None,
    effective_model: str | None = None,
) -> None:
    """Execute phase 2: per-issue review.

    Iterates open issues and reviews each with a fresh Opus 4.7 session.
    A :class:`~code_generator.runner.retry.CircuitBreaker` with
    ``max_failures=3`` wraps each issue. When the breaker trips, the issue
    is tagged ``needs-manual-review`` and skipped.

    Args:
        state: Root state object.
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
    """
    if logger is None:
        logger = setup_phase_logger("phase2", project_dir)

    # Dispatch to batch mode when requested.
    if state.session_mode == "batch":
        await run_batch(
            state,
            cycle,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            shared_client=shared_client,
            max_turns=max_turns,
            effective_model=effective_model,
        )
        return

    state_path = project_dir / ".code-generator" / "state.json"

    # repo is populated by preflight before any phase runs; Phase 2 is
    # unreachable without a valid state.repo in production.
    repo = state.repo  # type: ignore[assignment]  # RepoInfo | None, narrowed by preflight

    issues = get_issues(state, cycle)
    open_unreviewed = [i for i in issues if i.status == "open" and not i.reviewed]

    target = cycle if cycle is not None else state

    if not open_unreviewed:
        logger.info("Phase 2: no open unreviewed issues — skipping.")
        target.token_usage["phase2"] = TokenUsage()
        save_state(state_path, state)
        log_phase_usage(logger, 2, TokenUsage())
        return

    mcp_servers = build_mcp_servers(project_dir)
    mcp_tools = mcp_tool_wildcards(mcp_servers)
    memories_dir = project_dir / ".code-generator" / "memories"

    # Pre-fetch any missing comments and persist them incrementally so a crash
    # mid-fetch does not force a full re-fetch on --continue.
    for issue in open_unreviewed:
        if issue.comments is None:
            issue.comments = fetch_formatted_comments(repo, issue.number, logger)  # type: ignore[arg-type]
            save_state(state_path, state)

    # Soft reset once per cycle (not per issue) — the batched call is a single
    # distinct client.query() from the cycle_loop's perspective, so the
    # "fresh context per issue" invariant collapses to "fresh context per
    # cycle" on the Phase 2 boundary.
    cm_block: dict | None = None
    boundary_prefix = ""
    if shared_client is not None:
        memories_dir.mkdir(parents=True, exist_ok=True)
        reset = await soft_reset_context(shared_client, open_unreviewed[0].number, memories_dir)
        cm_block = reset.context_management
        boundary_prefix = reset.boundary_prefix

    issues_payload = json.dumps(
        [
            {
                "issue_number": issue.number,
                "title": issue.title,
                "body": "",  # Phase 1 records the issue body on GitHub; the reviewer
                # can Read the live version when needed (mirrors the prior
                # per-issue prompt, which also never embedded the body).
                "agent": issue.agent,
                "comments": issue.comments or "",
            }
            for issue in open_unreviewed
        ],
        indent=2,
    )

    repo_map = _memory.read_cycle_repomap(memories_dir)
    prompt = load_prompt(
        "prompt-phase-2-batch-review.md",
        ISSUES_JSON=issues_payload,
        REPO_MAP=repo_map,
    )
    if boundary_prefix:
        prompt = boundary_prefix + prompt

    effort_level = _effort.resolve_effort(phase=2, complexity="", issue_labels=[], retry_count=0)
    _main_model = effective_model or _PHASE2_DEFAULT_MODEL
    _effort.validate_effort(effort_level, _main_model)

    options = make_agent_options(
        model=_main_model,
        effort=effort_level,
        allowed_tools=["Read", "Glob", "Grep", "WebSearch", "WebFetch"] + mcp_tools,
        cwd=str(project_dir),
        mcp_servers=mcp_servers,
        context_management=cm_block,
        **max_turns_kwargs(max_turns),
    )

    breaker = retry.CircuitBreaker(max_failures=3)
    phase_usage = TokenUsage()
    phase_wall = 0.0
    review_text = ""
    fatal = False

    logger.info(
        "Phase 2: reviewing %d open unreviewed issues in a single batched call.",
        len(open_unreviewed),
    )

    try:
        result = await retry.with_backoff(
            lambda p=prompt, o=options: _run_one_review(  # type: ignore[misc]
                p,
                o,
                runner_module=runner_module,
                shared_client=shared_client,
                state_path=state_path,
                logger=logger,
            ),
            breaker=breaker,
        )
        if result is not None:
            review_text = result.text
            phase_usage = result.usage
            phase_wall = result.wall_seconds
    except MaxTurnsExceeded:
        fatal = True
        logger.error(
            "Phase 2: batched review hit max_turns — tagging every unreviewed "
            "issue in the batch for manual review."
        )
    except retry.CircuitOpen:
        fatal = True
        logger.error(
            "Phase 2: circuit breaker opened during batched review — tagging "
            "every unreviewed issue in the batch for manual review."
        )

    if not fatal:
        decisions = _parse_batch_decisions(review_text, logger)
        if decisions is None:
            fatal = True
        else:
            _apply_decisions(decisions, open_unreviewed, repo, logger)
            for issue in open_unreviewed:
                issue.reviewed = True

    if fatal:
        for issue in open_unreviewed:
            try:
                gh.add_label(repo, issue.number, "needs-manual-review")  # type: ignore[arg-type]
            except gh.GhError as exc:
                logger.warning(
                    "Could not add needs-manual-review label to #%d: %s",
                    issue.number,
                    exc,
                )

    log_phase_usage(logger, 2, phase_usage)
    target.token_usage["phase2"] = phase_usage
    if hasattr(target, "cache_telemetry"):
        accumulate_telemetry(target.cache_telemetry, phase_usage, phase_wall)  # type: ignore[union-attr]
    save_state(state_path, state)


def _parse_batch_decisions(
    text: str,
    logger: logging.Logger,
) -> list[dict[str, Any]] | None:
    """Extract the ``decisions`` array from the batched-review response.

    Returns ``None`` on any parse failure; the caller tags the affected
    issues ``needs-manual-review`` and skips marking them reviewed so that
    the next run re-evaluates them.
    """
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        logger.error("Phase 2: batched review output contained no JSON object.")
        return None
    try:
        raw = json.loads(text[start : end + 1])
    except json.JSONDecodeError as exc:
        logger.error("Phase 2: batched review JSON parse failed: %s", exc)
        return None
    if not isinstance(raw, dict):
        logger.error(
            "Phase 2: batched review output is not a JSON object (got %s).",
            type(raw).__name__,
        )
        return None
    decisions = raw.get("decisions")
    if not isinstance(decisions, list):
        logger.error(
            "Phase 2: batched review output missing 'decisions' list (got %s).",
            type(decisions).__name__ if decisions is not None else "None",
        )
        return None
    return decisions  # type: ignore[no-any-return]


def _apply_decisions(
    decisions: list[dict[str, Any]],
    open_unreviewed: list[Any],
    repo: Any,
    logger: logging.Logger,
) -> None:
    """Post a ``gh issue comment`` for each non-``ok`` decision.

    Decisions targeting an issue that is not in ``open_unreviewed`` are logged
    and ignored — the model must never comment on an issue it was not asked
    to review. Missing decisions (an issue with no matching entry) are also
    logged; the issue is still marked reviewed by the caller, since the
    absence of a decision is equivalent to an implicit ``"ok"``.
    """
    by_number = {issue.number: issue for issue in open_unreviewed}
    seen: set[int] = set()
    for decision in decisions:
        if not isinstance(decision, dict):
            logger.warning("Phase 2: skipping non-dict decision entry: %r", decision)
            continue
        number = decision.get("issue_number")
        action = decision.get("action")
        body = decision.get("comment_body") or ""
        if not isinstance(number, int) or number not in by_number:
            logger.warning("Phase 2: decision targets unknown issue #%r — skipping.", number)
            continue
        seen.add(number)
        if action == "ok":
            continue
        if action not in ("comment", "split"):
            logger.warning(
                "Phase 2: decision for #%d has unknown action %r — skipping comment.",
                number,
                action,
            )
            continue
        if not isinstance(body, str) or not body.strip():
            logger.warning(
                "Phase 2: decision for #%d has action=%s but empty body — skipping.",
                number,
                action,
            )
            continue
        try:
            gh.post_comment(repo, number, body)
            logger.info("Phase 2: posted comment on #%d (action=%s).", number, action)
        except gh.GhError as exc:
            logger.warning("Phase 2: could not post comment on #%d: %s", number, exc)

    missing = [issue.number for issue in open_unreviewed if issue.number not in seen]
    if missing:
        logger.warning(
            "Phase 2: reviewer did not return a decision for issues %s — treating as ok.",
            missing,
        )
