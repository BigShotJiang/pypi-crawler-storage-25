"""GitHub environment preflight validation.

Validates the local environment can talk to the target GitHub host
before any cycle starts. On failure raises :class:`PreflightError`
with a ready-to-paste fix command; on success returns a validated
:class:`~code_generator.repo_info.RepoInfo`.

Single responsibility: environment validation.
No state.json mutation — callers own that (see issue #156).

Checks performed in order
-------------------------
(a) ``git remote get-url origin`` succeeds.
(b) URL parses via :func:`~code_generator.repo_info.parse_remote_url`.
(c) ``gh auth status --hostname <host>`` exits 0.
(d) ``gh repo view <owner/repo> --hostname <host>`` exits 0.
(e) ``gh api repos/<owner/repo>/labels --hostname <host>`` exits 0.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
from typing import TYPE_CHECKING
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from code_generator.repo_info import RepoInfo, parse_remote_url

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

logger = logging.getLogger(__name__)

# Ollama preflight constants — pinned so tests can assert exact values and
# the refusal gate in env.py (#215) and this preflight stay in sync.
OLLAMA_TAGS_URL = "http://localhost:11434/api/tags"
OLLAMA_SHOW_URL = "http://localhost:11434/api/show"
OLLAMA_PINNED_BASE_URL = "http://localhost:11434"
OLLAMA_PROBE_TIMEOUT_SECONDS = 2
OLLAMA_SIGNIN_COMMAND = "ollama signin"
# Cloud model fetched to probe signed-in state. The daemon returns 401 on
# this endpoint when not authenticated; 404 / 200 both mean authenticated
# (model absent vs present).
_OLLAMA_CLOUD_PROBE_MODEL = "qwen3-coder:480b-cloud"

# Injected by tests via ``patch("code_generator.preflight._IS_WINDOWS", True)``.
# Windows note: gh credentials integrate with Windows Credential Manager and
# may behave differently. Checks that fail on Windows log a WARNING and are
# skipped rather than aborting the run.
_IS_WINDOWS: bool = sys.platform == "win32"


# ---------------------------------------------------------------------------
# Public exception
# ---------------------------------------------------------------------------


class PreflightError(Exception):
    """Raised when a preflight check fails.

    Attributes:
        reason: Short human-readable description of the failure.
        fix_command: A copy-paste ready command to resolve the issue.
    """

    def __init__(self, *, reason: str, fix_command: str) -> None:
        self.reason = reason
        self.fix_command = fix_command
        super().__init__(reason)


# ---------------------------------------------------------------------------
# Subprocess seams (patch these in tests)
# ---------------------------------------------------------------------------


def _run_gh(args: list[str], *, hostname: str) -> subprocess.CompletedProcess:  # type: ignore[type-arg]
    """Execute a gh command appending ``--hostname`` and return CompletedProcess.

    Single seam for all gh subprocess calls — tests patch this one function.
    Never uses ``shell=True``.

    Args:
        args: Full argv including the ``gh`` binary.
        hostname: Value for the ``--hostname`` flag.

    Returns:
        CompletedProcess with returncode, stdout, and stderr populated.
    """
    return subprocess.run(
        [*args, "--hostname", hostname],
        capture_output=True,
        text=True,
        check=False,
    )


def _get_origin_url(project_dir: Path) -> str:
    """Return the git remote origin URL for *project_dir*.

    Args:
        project_dir: Root directory of the git project.

    Returns:
        Stripped remote URL string.

    Raises:
        PreflightError: When ``git remote get-url origin`` exits non-zero.
    """
    result = subprocess.run(
        ["git", "remote", "get-url", "origin"],
        cwd=project_dir,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise PreflightError(
            reason="No 'origin' remote found in this git repository.",
            fix_command="git remote add origin <url>",
        )
    return result.stdout.strip()


# ---------------------------------------------------------------------------
# Individual checks (SRP: one check per function, each < 10 lines)
# ---------------------------------------------------------------------------


def _check_auth(repo_info: RepoInfo) -> None:
    """Verify gh is authenticated for the target host.

    Args:
        repo_info: Parsed repository information supplying the hostname.

    Raises:
        PreflightError: When ``gh auth status`` exits non-zero.
    """
    result = _run_gh(["gh", "auth", "status"], hostname=repo_info.host)
    if result.returncode != 0:
        raise PreflightError(
            reason=f"Not authenticated to {repo_info.host}.",
            fix_command=f"gh auth login --hostname {repo_info.host}",
        )


def _check_repo(repo_info: RepoInfo) -> None:
    """Verify gh can access the repository.

    ``gh repo view`` does not accept ``--hostname``; the host is passed as part
    of the positional argument (``HOST/OWNER/REPO`` for enterprise,
    ``OWNER/REPO`` for github.com).

    Args:
        repo_info: Parsed repository information.

    Raises:
        PreflightError: When ``gh repo view`` exits non-zero.
    """
    if repo_info.host == "github.com":
        target = repo_info.full
    else:
        target = f"{repo_info.host}/{repo_info.full}"
    result = subprocess.run(
        ["gh", "repo", "view", target],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise PreflightError(
            reason=f"Cannot access repository {repo_info.full} on {repo_info.host}.",
            fix_command=f"gh repo view {target}",
        )


def _check_labels(repo_info: RepoInfo) -> None:
    """Verify gh can access the labels API for the repository.

    Args:
        repo_info: Parsed repository information.

    Raises:
        PreflightError: When ``gh api repos/.../labels`` exits non-zero.
    """
    result = _run_gh(
        ["gh", "api", f"repos/{repo_info.full}/labels"],
        hostname=repo_info.host,
    )
    if result.returncode != 0:
        raise PreflightError(
            reason=f"Cannot access labels API for {repo_info.full} on {repo_info.host}.",
            fix_command=f"gh api repos/{repo_info.full}/labels --hostname {repo_info.host}",
        )


# ---------------------------------------------------------------------------
# Windows-safe check runner
# ---------------------------------------------------------------------------


def _run_check_windows_safe(
    check_fn: Callable[[RepoInfo], None],
    repo_info: RepoInfo,
    check_name: str,
) -> None:
    """Run a check, logging WARNING and skipping on Windows instead of raising.

    On non-Windows systems exceptions propagate normally.

    # Windows note: credential manager integration may cause gh to behave
    # differently on Windows. Rather than hard-failing, we log a WARNING so
    # the operator can validate manually.

    Args:
        check_fn: Function taking a RepoInfo that may raise PreflightError.
        repo_info: Repository info forwarded to the check.
        check_name: Human-readable name used in the warning message.
    """
    try:
        check_fn(repo_info)
    except PreflightError:
        if _IS_WINDOWS:
            logger.warning(
                "Preflight check '%s' skipped on Windows — validate manually.",
                check_name,
            )
        else:
            raise


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_preflight(project_dir: Path) -> RepoInfo:
    """Validate the local environment can talk to the target GitHub host.

    Performs five checks in order (a–e, see module docstring).
    Returns a validated :class:`RepoInfo` on success.

    Args:
        project_dir: Root directory of the git project being generated.

    Returns:
        Parsed and validated :class:`RepoInfo` for the ``origin`` remote.

    Raises:
        PreflightError: When any check fails on a non-Windows system.
            Carries ``reason`` and ``fix_command`` for operator display.
    """
    # (a) origin remote exists
    origin_url = _get_origin_url(project_dir)

    # (b) URL parses to a RepoInfo
    try:
        repo_info = parse_remote_url(origin_url)
    except ValueError as exc:
        raise PreflightError(
            reason=f"Cannot parse git remote URL: {origin_url!r}",
            fix_command="git remote set-url origin <valid-url>",
        ) from exc

    # (c–e) gh checks — Windows-safe
    _run_check_windows_safe(_check_auth, repo_info, "gh auth status")
    _run_check_windows_safe(_check_repo, repo_info, "gh repo view")
    _run_check_windows_safe(_check_labels, repo_info, "gh api labels")

    return repo_info


# ---------------------------------------------------------------------------
# Ollama preflight — separate entry point for the Ollama codepath (#216)
# ---------------------------------------------------------------------------


def _require_ollama_api_key() -> None:
    """Raise if OLLAMA_API_KEY is unset or empty."""
    if not os.environ.get("OLLAMA_API_KEY", ""):
        raise PreflightError(
            reason="OLLAMA_API_KEY is unset or empty.",
            fix_command='export OLLAMA_API_KEY="<your-ollama-pro-token>"',
        )


def _require_matching_base_url() -> None:
    """Raise if ANTHROPIC_BASE_URL is pre-set to anything other than localhost:11434."""
    preset = os.environ.get("ANTHROPIC_BASE_URL")
    if preset and preset != OLLAMA_PINNED_BASE_URL:
        raise PreflightError(
            reason=f"ANTHROPIC_BASE_URL must equal {OLLAMA_PINNED_BASE_URL}, got {preset!r}.",
            fix_command=f'export ANTHROPIC_BASE_URL="{OLLAMA_PINNED_BASE_URL}"',
        )


def _probe_daemon_reachable() -> None:
    """GET /api/tags within 2s; raise if unreachable or non-200."""
    try:
        with urlopen(OLLAMA_TAGS_URL, timeout=OLLAMA_PROBE_TIMEOUT_SECONDS) as resp:
            status = getattr(resp, "status", 0)
    except (URLError, TimeoutError, OSError) as exc:
        raise PreflightError(
            reason=f"Ollama daemon unreachable at {OLLAMA_TAGS_URL}.",
            fix_command="Start the Ollama daemon (e.g. `ollama serve`) and retry.",
        ) from exc

    if status != 200:
        raise PreflightError(
            reason=f"Ollama daemon unreachable at {OLLAMA_TAGS_URL} (HTTP {status}).",
            fix_command="Start the Ollama daemon (e.g. `ollama serve`) and retry.",
        )


def _probe_signed_in() -> None:
    """POST /api/show for a cloud model; 401 means the daemon is not signed in.

    The fetched model does not need to exist locally — we only care whether
    the daemon recognises the caller as authenticated for cloud endpoints.
    A 404 (model not found) is accepted: it still proves authentication
    succeeded because an unauthenticated daemon fails at the auth layer
    with 401 before model lookup.
    """
    body = json.dumps({"name": _OLLAMA_CLOUD_PROBE_MODEL}).encode()
    request = Request(
        OLLAMA_SHOW_URL,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request, timeout=OLLAMA_PROBE_TIMEOUT_SECONDS):
            return
    except HTTPError as exc:
        if exc.code == 401:
            raise PreflightError(
                reason=(
                    "Ollama daemon is not signed in to your Pro account. "
                    "Cloud models (:cloud) will return 401."
                ),
                fix_command=OLLAMA_SIGNIN_COMMAND,
            ) from exc
        # Any non-401 HTTP error (404 "model not found", 5xx, etc.) proves
        # the daemon accepted the call past the auth layer — signed in.
        return
    except (URLError, TimeoutError, OSError):
        # Network-level errors fall through; the tags probe already caught
        # reachability, so surface these as a reachability hint rather than
        # a spurious signin failure.
        return


def run_ollama_preflight(*, check_signin: bool = True) -> None:
    """Validate the Ollama codepath can talk to the local daemon.

    Performs four checks in fail-fast order — cheap env-var checks first,
    then network probes:

    (1) ``OLLAMA_API_KEY`` set and non-empty.
    (2) ``ANTHROPIC_BASE_URL`` either unset or equal to the pinned value.
    (3) ``GET /api/tags`` returns HTTP 200 within 2 seconds.
    (4) Signed-in probe: ``POST /api/show`` with a cloud model —
        a 401 response indicates the daemon is not signed in.

    Args:
        check_signin: When False, skips probe (4). Used by callers that
            already verified signin externally or by tests.

    Raises:
        PreflightError: On the first failing check, with a user-actionable
            ``reason`` and ``fix_command``.
    """
    _require_ollama_api_key()
    _require_matching_base_url()
    _probe_daemon_reachable()
    if check_signin:
        _probe_signed_in()
