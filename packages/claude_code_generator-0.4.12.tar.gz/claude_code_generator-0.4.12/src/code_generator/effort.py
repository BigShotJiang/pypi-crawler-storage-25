"""Effort-level policy engine for the adaptive effort feature.

Maps (phase, complexity, issue_labels, retry_count, effort_hint) to an
Anthropic API effort level: ``low`` | ``medium`` | ``high`` | ``max``.

Phase convention
----------------
Phases follow the 0→7 pipeline defined in ``orchestrator/cycle_loop.py``.
Phases 3 and 4 are both treated as the "implement" phase (cycle_loop.py
combines them as ``_PHASE_IMPLEMENT = 4``), so both map to the same effort.
Plain integers 0–7 are used as the ``phase`` parameter; private ``_PHASE_*``
constants from ``cycle_loop.py`` are intentionally NOT imported here.

Returns ``None`` for unknown phases, meaning "use the model default".
"""

from __future__ import annotations

from enum import StrEnum
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from collections.abc import Sequence

# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

EffortLiteral = Literal["low", "medium", "high", "xhigh", "max"]


class InvalidEffortInput(ValueError):
    """Raised when ``resolve_effort`` receives an empty ``complexity`` string in a phase
    that depends on Phase 0's output (phases 3, 4, and 7) and no ``effort_hint`` override
    is provided to compensate.

    An empty ``complexity`` in these phases means Phase 0 failed silently — the caller
    should have wired the Phase 0 output before invoking ``resolve_effort``.
    """


class EffortLevel(StrEnum):
    """Valid effort levels accepted by the Anthropic API."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    XHIGH = "xhigh"
    MAX = "max"


# ---------------------------------------------------------------------------
# Baseline table
# ---------------------------------------------------------------------------

_BASELINE: dict[int, EffortLevel] = {
    0: EffortLevel.XHIGH,  # complexity analysis + cycle decomposition (architectural)
    1: EffortLevel.XHIGH,  # plan
    2: EffortLevel.XHIGH,  # review
    3: EffortLevel.MEDIUM,  # implement (lower bound of 3+4 combined; Sonnet)
    4: EffortLevel.MEDIUM,  # implement (upper bound of 3+4 combined; Sonnet)
    5: EffortLevel.XHIGH,  # closure (cross-module review)
    6: EffortLevel.LOW,  # tests (Sonnet; escalated by retry_count)
    7: EffortLevel.LOW,  # commit (mechanical, Opus)
}

_COMPLEXITY_HIGH_LABEL = "complexity:high"
_COMPLEXITY_REQUIRED_PHASES: frozenset[int] = frozenset({3, 4, 7})


# ---------------------------------------------------------------------------
# Policy helpers
# ---------------------------------------------------------------------------


def _implement_effort(issue_labels: Sequence[str]) -> EffortLevel:
    """Return implement-phase effort, bumped to high when complexity:high present."""
    if _COMPLEXITY_HIGH_LABEL in issue_labels:
        return EffortLevel.HIGH
    return EffortLevel.MEDIUM


def _test_effort(retry_count: int) -> EffortLevel:
    """Return test-phase effort escalated by retry_count."""
    if retry_count == 0:
        return EffortLevel.LOW
    if retry_count == 1:
        return EffortLevel.MEDIUM
    return EffortLevel.HIGH


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


_OPUS_MODEL = "claude-opus-4-7"


_OPUS_ONLY_EFFORTS: frozenset[str] = frozenset({"xhigh", "max"})


def validate_effort(effort: str | None, model: str) -> None:
    """Raise ValueError when an Opus-only effort is paired with a non-Opus Claude model.

    ``xhigh`` and ``max`` are gated to Opus 4.7+ (introduced in 4.7); Sonnet
    and Haiku do not expose them. The constraint only applies to Anthropic
    Claude models (IDs prefixed with ``"claude-"``); for other model families
    — notably the Ollama single-model codepath (#218), which accepts tags like
    ``"glm-5.1:cloud"`` or ``"llama3.2:3b"`` — the effort flag is advisory and
    validation is skipped.

    Parameters
    ----------
    effort:
        Effort level string (``"low"`` / ``"medium"`` / ``"high"`` / ``"xhigh"``
        / ``"max"``), or ``None`` (no-op).
    model:
        Anthropic Claude model ID (e.g. ``"claude-opus-4-7"``) or a non-Claude
        tag (Ollama, etc.). Non-Claude tags are not validated.
    """
    if not model.startswith("claude-"):
        return
    if effort in _OPUS_ONLY_EFFORTS and model != _OPUS_MODEL:
        raise ValueError(f"effort={effort!r} is only allowed with {_OPUS_MODEL!r}, got {model!r}.")


def resolve_effort(
    *,
    phase: int,
    complexity: str,
    issue_labels: Sequence[str],
    retry_count: int,
    effort_hint: EffortLevel | None = None,
) -> EffortLevel | None:
    """Return the effort level for a given phase and context.

    Parameters
    ----------
    phase:
        Pipeline phase number (0–7).
    complexity:
        Project complexity string (reserved for future use).
    issue_labels:
        GitHub label names attached to the issue being implemented.
    retry_count:
        Number of previous attempts (used by phase 6 escalation logic).
    effort_hint:
        Optional override emitted by Phase 0. Takes precedence over all
        other logic when set.

    Returns
    -------
    EffortLevel | None
        Resolved effort level, or ``None`` for unknown phases (use model default).
    """
    if (
        complexity == ""
        and effort_hint is None
        and phase in _COMPLEXITY_REQUIRED_PHASES
        and retry_count == 0
    ):
        raise InvalidEffortInput(
            f"resolve_effort called with empty complexity for phase {phase} "
            "(retry_count=0, no effort_hint). "
            "Phase 0 must produce a complexity value before phases 3, 4, or 7 run."
        )

    if effort_hint is not None:
        return effort_hint

    if phase in (3, 4):
        return _implement_effort(issue_labels)

    if phase == 6:
        return _test_effort(retry_count)

    return _BASELINE.get(phase)
