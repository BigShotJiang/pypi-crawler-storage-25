"""Crash-recovery helpers for the --continue entry point.

On --continue, if the previous client was alive within the TTL window
(default 60 minutes), the client was likely orphaned by a process crash.
The orchestrator always opens a fresh client on resume; this module
provides the diagnostic check and log message.

The log message is exact — downstream bench/observability tooling greps for it.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from code_generator import state as _state

if TYPE_CHECKING:
    from code_generator.state import State

# Exact log string — do NOT change without updating downstream consumers.
CRASH_RECOVERY_LOG_MSG = (
    "previous client vanished; reopening with fresh KV cache (expected on crash recovery)"
)

_logger = logging.getLogger(__name__)


def check_and_log_crash_recovery(
    state: State,
    *,
    ttl_minutes: int = 60,
    logger: logging.Logger | None = None,
) -> None:
    """Log a crash-recovery diagnostic when client_alive_at is within the TTL window.

    Called on --continue before the cycle loop opens a new shared client.
    When client_alive_at is set and within ttl_minutes, the client was likely
    orphaned by a crash. The caller will open a fresh client regardless; this
    function only emits the INFO diagnostic.

    When client_alive_at is None or older than ttl_minutes, no log is emitted
    (normal resume after a rate-limit pause or a completed run).

    Args:
        state: Root state to inspect (read-only).
        ttl_minutes: Age threshold in minutes (exclusive upper bound). Default 60.
        logger: Logger for the INFO message. Defaults to the module logger.
    """
    log = logger or _logger
    if _state.is_client_presumed_alive(state, ttl_minutes=ttl_minutes):
        log.info(CRASH_RECOVERY_LOG_MSG)
