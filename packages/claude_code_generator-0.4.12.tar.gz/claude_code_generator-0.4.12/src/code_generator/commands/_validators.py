"""Small Typer callback helpers shared across command entry points."""

from __future__ import annotations

import typer


def validate_max_turns(value: int | None) -> int | None:
    """Raise :class:`typer.BadParameter` when ``--max-turns`` is not positive.

    The flag is strictly opt-in (issue #210): ``None`` means "no cap set by
    the operator" and propagates through every layer unchanged.  Any integer
    the operator passes must be ``>= 1`` — ``0`` and negatives defeat the
    purpose of the flag and point to a typo.

    Args:
        value: Raw integer (or ``None``) produced by Typer.

    Returns:
        The unchanged *value* when valid.

    Raises:
        typer.BadParameter: When *value* is a non-positive integer.
    """
    if value is not None and value < 1:
        raise typer.BadParameter("--max-turns must be a positive integer")
    return value
