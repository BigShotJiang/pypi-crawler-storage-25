"""Dispatch helpers for the generate command.

Handles resolving resume parameters from CLI flags and delegating to the
async orchestration pipeline.  Separated from the Typer command definition
so both layers can be tested in isolation.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Literal

import typer

from code_generator.commands._crash_recovery import check_and_log_crash_recovery
from code_generator.commands._resume import next_start_phase, resolve_continue_multi_cycle

if TYPE_CHECKING:
    from pathlib import Path

    from code_generator import state as state_module

_logger = logging.getLogger(__name__)

__all__ = ["dispatch_async", "dispatch_orchestrator"]


def _warn_on_drift(st: state_module.State, logger: logging.Logger) -> None:
    """Emit WARNING logs when prompt hashes or SDK version have drifted.

    Computes current prompt hashes and SDK version, delegates the comparison
    to the pure :func:`~code_generator.state.warn_on_prompt_or_sdk_drift`
    helper, then emits each returned string via *logger*.

    Args:
        st: Root state carrying stored ``prompt_hashes`` and ``sdk_version``.
        logger: Logger used to emit WARNING-level messages.
    """
    from code_generator import state as _state_module
    from code_generator.env import detect_sdk_version
    from code_generator.prompts.hashes import compute_all_prompt_hashes

    warnings = _state_module.warn_on_prompt_or_sdk_drift(
        st, compute_all_prompt_hashes(), detect_sdk_version()
    )
    for message in warnings:
        logger.warning(message)


def _reset_failed_cycles_for_continue(
    st: state_module.State,
    *,
    target_cycle: int | None,
    state_path: Path,
) -> None:
    """Reset ``failed`` cycles back to ``open`` on ``--continue``.

    When a cycle crashes mid-run, ``cycle_loop.run_multi_cycle`` marks it as
    ``status="failed"`` and persists the exception in ``state.last_error``.
    The next ``--continue`` must treat these as retryable, otherwise the user
    has to hand-edit ``state.json`` every time a cycle crashes — which
    defeats the whole point of ``--continue``.

    When ``target_cycle`` is set (``--cycle N``), only that cycle is reset.
    Otherwise every failed cycle is reset. ``state.last_error`` and
    ``state.rate_limit_type`` are cleared on any successful reset so the
    status line stops showing red for a resolved failure.

    Args:
        st: Root state (mutated in place).
        target_cycle: When set, only reset this cycle id; otherwise reset all.
        state_path: Path to ``state.json`` for atomic persistence.
    """
    from code_generator import state as _state_module

    reset_ids: list[int] = []
    for c in st.cycles:
        if c.status != "failed":
            continue
        if target_cycle is not None and c.id != target_cycle:
            continue
        c.status = "open"
        reset_ids.append(c.id)

    if not reset_ids:
        return

    if getattr(st, "last_error", None):
        st.last_error = None
    if getattr(st, "rate_limit_type", None):
        st.rate_limit_type = None

    _state_module.save_state(state_path, st)
    _logger.info(
        "--continue: reset failed cycles to open: %s",
        ", ".join(str(i) for i in reset_ids),
    )


async def _apply_delta_plan(
    st: state_module.State,
    project_dir: Path,
    *,
    runner_module: object,
    delta_hash: str,
    state_path: Path,
    logger: logging.Logger,
) -> int | None:
    """Run Phase 0 and merge new cycles into state for multi-cycle delta planning.

    Atomicity guarantee: state is only mutated after a successful Phase 0
    response.  If Phase 0 fails, a ``RuntimeError`` is raised and neither
    ``state.cycles`` nor ``state.requirements_hash`` is changed.

    Args:
        st: Root state (mutated in place on success).
        project_dir: Project root directory.
        runner_module: Runner module for Phase 0 execution.
        delta_hash: The new requirements hash to store on success.
        state_path: Path to state.json for atomic persistence.
        logger: Phase logger.

    Returns:
        ID of the first newly appended cycle, or ``None`` when the new plan
        contains no scopes that are not already in ``state.cycles``.

    Raises:
        RuntimeError: When Phase 0 returns ``None`` (all retries exhausted).
    """
    from code_generator import state as state_module
    from code_generator.orchestrator import phase0_complexity

    raw_cycles = await phase0_complexity.get_raw_cycle_plan(
        project_dir,
        runner_module=runner_module,  # type: ignore[arg-type]
        logger=logger,
    )

    if raw_cycles is None:
        raise RuntimeError(
            "Phase 0 failed during delta planning; aborting to preserve cycle history."
        )

    new_cycles = state_module.append_new_cycles(st, raw_cycles)

    if not new_cycles:
        logger.info("Delta planning: no new cycles detected.")
        st.requirements_hash = delta_hash
        state_module.save_state(state_path, st)
        return None

    # Extend state atomically: build new list, then assign all at once.
    st.cycles = list(st.cycles) + new_cycles
    st.current_cycle = new_cycles[0].id
    st.requirements_hash = delta_hash
    state_module.save_state(state_path, st)
    return new_cycles[0].id


async def dispatch_async(
    st: state_module.State,
    project_dir: Path,
    *,
    dry_run: bool,
    start_phase: int,
    start_cycle: int | None,
    mode: str,
    delta_hash: str | None = None,
    state_path: Path | None = None,
    session_mode: Literal["shared", "fresh", "batch"] = "shared",
    max_turns: int | None = None,
    ollama_model: str | None = None,
) -> None:
    """Async entry point for the orchestration pipeline.

    Args:
        st: Root state object.
        project_dir: Project root directory.
        dry_run: When True, only phases 0 and 1 run.
        start_phase: Resume from this phase (1 = full run).
        start_cycle: Resume from this cycle (multi-cycle only).
        mode: ``"auto"``, ``"single"``, or ``"multi-cycle"``.
        delta_hash: When set, triggers delta planning for multi-cycle mode
            with completed cycles (the new requirements hash to persist on
            success).  ``None`` disables delta planning.
        state_path: Path to state.json; required when ``delta_hash`` is set.
        session_mode: SDK session strategy to thread to the cycle loop.
    """
    from code_generator.logging_setup import setup_phase_logger
    from code_generator.orchestrator import cycle_loop, phase0_complexity
    from code_generator.runner import get_runner

    runner_module = get_runner()
    logger = setup_phase_logger("generate", project_dir)

    # Phase 0: determine mode when not already known.
    if mode == "auto":
        needs_phase0 = st.mode not in ("single", "multi-cycle")
    else:
        needs_phase0 = False
        # Force the mode from the flag.
        st.mode = mode  # type: ignore[assignment]

    # Delta planning: multi-cycle with completed cycles needs a merge, not a
    # fresh Phase 0 run.  Single-mode delta is handled upstream (mode reset to
    # "unknown" forces Phase 0 to re-run via needs_phase0=True).
    completed = [c for c in st.cycles if c.status == "completed"]
    if delta_hash is not None and st.mode == "multi-cycle" and completed and state_path is not None:
        first_new_id = await _apply_delta_plan(
            st,
            project_dir,
            runner_module=runner_module,
            delta_hash=delta_hash,
            state_path=state_path,
            logger=logger,
        )
        if first_new_id is None:
            return  # No new cycles — nothing to run.
        start_cycle = first_new_id
        start_phase = 1
        needs_phase0 = False

    if needs_phase0:
        await phase0_complexity.run(
            st,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            effective_model=ollama_model,
        )

    # Dry-run: planning only (phase 0 + phase 1).
    if dry_run:
        from code_generator.orchestrator import phase1_plan

        logger.info("--dry-run: running phase 1 (planning only).")
        await phase1_plan.run(
            st,
            None,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            effective_model=ollama_model,
        )
        return

    # Dispatch to cycle loop.
    if st.mode == "multi-cycle":
        await cycle_loop.run_multi_cycle(
            st,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            start_cycle=start_cycle,
            start_phase=start_phase,
            session_mode=session_mode,
            max_turns=max_turns,
            effective_model=ollama_model,
        )
    else:
        await cycle_loop.run_single_mode(
            st,
            project_dir,
            runner_module=runner_module,
            logger=logger,
            start_phase=start_phase,
            session_mode=session_mode,
            max_turns=max_turns,
            effective_model=ollama_model,
        )


def _apply_session_mode(
    st: state_module.State,
    *,
    continue_: bool,
    session_mode: Literal["shared", "fresh", "batch"],
    session_mode_explicit: bool,
    state_path: Path,
) -> None:
    """Persist or validate session_mode depending on whether this is a fresh or resume run.

    On a fresh run (not ``--continue``): write ``session_mode`` to state and persist.
    On ``--continue`` with an explicit flag: call ``assert_session_mode_compatible``
    and translate any ``ValueError`` to ``typer.Exit(code=2)``.
    On ``--continue`` without an explicit flag: inherit the stored value silently.

    Args:
        st: Root state (mutated in place on fresh run).
        continue_: Whether the user passed ``--continue``.
        session_mode: The resolved session mode from the CLI flag.
        session_mode_explicit: True when the user explicitly passed ``--session-mode``.
        state_path: Destination for atomic state persistence.

    Raises:
        typer.Exit: With code 2 on a session-mode mismatch during ``--continue``.
    """
    from code_generator import state as state_module

    if not continue_:
        st.session_mode = session_mode  # type: ignore[assignment]
        state_module.save_state(state_path, st)
        return

    if session_mode_explicit:
        try:
            state_module.assert_session_mode_compatible(st, session_mode)
        except ValueError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(code=2) from exc


def dispatch_orchestrator(
    st: state_module.State,
    project_dir: Path,
    *,
    dry_run: bool,
    phase: int | None,
    continue_: bool,
    mode: str,
    cycle: int | None,
    state_path: Path,
    requirements_hash: str | None = None,
    session_mode: Literal["shared", "fresh", "batch"] = "shared",
    session_mode_explicit: bool = False,
    max_turns: int | None = None,
    ollama_model: str | None = None,
) -> None:
    """Resolve resume parameters and dispatch the async orchestrator.

    Args:
        st: Root state.
        project_dir: Project root directory.
        dry_run: When True, only phase 0/1 planning runs.
        phase: Resume from this explicit phase number.
        continue_: Resume from the last completed phase/cycle in state.
        mode: ``"auto"``, ``"single"``, or ``"multi-cycle"``.
        cycle: Resume from this specific cycle (multi-cycle only).
        state_path: Path to state.json, used for atomic hash updates.
        requirements_hash: SHA-256 digest of the current requirements.md, or
            None when the file is absent (detection is skipped).
        session_mode: SDK session strategy (``"shared"``, ``"fresh"``, or ``"batch"``).
        session_mode_explicit: True when the operator explicitly passed
            ``--session-mode``; governs mismatch-check on ``--continue``.
    """
    from code_generator import state as state_module

    # Re-run detection: only when no explicit resume flags override intent.
    # --continue and --phase N express explicit user intent, so they bypass
    # detection entirely to avoid surprising "nothing to do" responses.
    delta_hash_for_async: str | None = None
    if not continue_ and phase is None and requirements_hash is not None:
        from code_generator.commands._detect import detect_run_mode

        run_mode = detect_run_mode(st, requirements_hash)

        if run_mode == "no-op":
            _logger.info("nothing to do: all cycles complete, requirements unchanged")
            typer.echo("All cycles complete. Nothing to do.")
            return

        if run_mode == "first-run":
            st.requirements_hash = requirements_hash
            state_module.save_state(state_path, st)

        elif run_mode == "delta":
            completed = [c for c in st.cycles if c.status == "completed"]
            if st.mode == "multi-cycle" and completed:
                # Defer hash update to async path — atomicity requires Phase 0
                # to succeed before we store the new hash.
                delta_hash_for_async = requirements_hash
            else:
                # Single mode or no completed cycles: treat as fresh run from Phase 0.
                # Reset mode to "unknown" so Phase 0 re-runs and re-evaluates complexity.
                st.mode = "unknown"  # type: ignore[assignment]
                st.requirements_hash = requirements_hash
                state_module.save_state(state_path, st)

    # Resolve effective mode (honor existing state when --mode auto).
    effective_mode = mode
    if mode == "auto" and st.mode in ("single", "multi-cycle"):
        effective_mode = st.mode

    # Resolve start_phase and start_cycle.
    # Flag precedence (highest → lowest):
    #   1. --continue  → derive start_cycle + start_phase from state (last completed)
    #   2. --phase N   → explicit phase; start_cycle stays None (single-mode default)
    #   3. --cycle N   → overrides any continue-derived start_cycle; start_phase
    #                    defaults to 1 unless --phase N is also given
    #   4. (none)      → fresh run from phase 1, cycle None
    start_phase = 1
    start_cycle: int | None = None

    # Persist or validate session_mode before any async work.
    _apply_session_mode(
        st,
        continue_=continue_,
        session_mode=session_mode,
        session_mode_explicit=session_mode_explicit,
        state_path=state_path,
    )

    if continue_:
        # A cycle that crashed mid-run is marked "failed" by the exception
        # handler in cycle_loop.run_multi_cycle. Without this reset, `--continue`
        # would skip it forever because `_eligible_cycles` only returns "open"
        # cycles. Semantically, `--continue` means "retry from where we
        # crashed", so flip any failed cycle back to "open" and clear the
        # stale error. Explicit --cycle N also benefits: reset just the target.
        _reset_failed_cycles_for_continue(st, target_cycle=cycle, state_path=state_path)

        # Crash-recovery FSM: log diagnostic when client_alive_at is within TTL.
        # This means the client was orphaned by a crash; the cycle loop will open
        # a fresh client on resume regardless.  Silent when client_alive_at is
        # None (normal resume after rate-limit pause) or outside the TTL window.
        check_and_log_crash_recovery(st)

        # §17: Warn on prompt-file or SDK-version drift since cycle start.
        _warn_on_drift(st, _logger)

        # Resume from the *next* phase/cycle after the last completed one.
        if effective_mode == "multi-cycle":
            start_cycle, start_phase = resolve_continue_multi_cycle(st)
        else:
            start_phase = next_start_phase(st)

    elif phase is not None:
        start_phase = phase

    if cycle is not None:
        # --cycle N overrides any continue-derived start_cycle.
        start_cycle = cycle
        start_phase = phase or 1

    # Effective session_mode for the async path: on --continue without an
    # explicit flag, inherit the value already stored in state (set above or
    # pre-existing from the original run).
    effective_session_mode: Literal["shared", "fresh", "batch"] = st.session_mode  # type: ignore[assignment]

    asyncio.run(
        dispatch_async(
            st,
            project_dir,
            dry_run=dry_run,
            start_phase=start_phase,
            start_cycle=start_cycle,
            mode=effective_mode,
            delta_hash=delta_hash_for_async,
            state_path=state_path,
            session_mode=effective_session_mode,
            max_turns=max_turns,
            ollama_model=ollama_model,
        )
    )
