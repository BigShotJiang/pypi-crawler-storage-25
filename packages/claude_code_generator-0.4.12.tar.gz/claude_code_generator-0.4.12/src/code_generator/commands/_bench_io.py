"""Shared I/O helpers for bench and bench export subcommands.

Extracted to break the circular-import between bench.py (which registers
subcommands) and bench_export.py (which needs the schema version and writer).
"""

from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING, Any

import typer

if TYPE_CHECKING:
    from pathlib import Path

# Bump this + add a migration note for any breaking schema change.
# v2 (issue #212): per-phase dicts + totals now include ``num_turns``.
SCHEMA_VERSION: int = 2


def write_output(path: Path | None, payload: dict[str, Any]) -> None:
    """Write *payload* as pretty-printed JSON atomically to *path*, or stdout.

    Uses tmp → os.replace() so a crash mid-write cannot corrupt the file.

    Args:
        path: Destination file path, or None to print to stdout.
        payload: JSON-serialisable dict to write.
    """
    serialised = json.dumps(payload, indent=2)
    if path is None:
        typer.echo(serialised)
        return

    tmp_path = path.with_suffix(".tmp")
    tmp_path.write_text(serialised, encoding="utf-8")
    os.replace(tmp_path, path)
