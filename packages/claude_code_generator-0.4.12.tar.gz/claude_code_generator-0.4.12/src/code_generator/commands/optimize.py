"""optimize command — rewrite requirements.md into canonical structure via Claude."""

from __future__ import annotations

import asyncio
import contextlib
import os
import re
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated

import typer

from code_generator import env
from code_generator.commands._validators import validate_max_turns
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.prompts import load_prompt
from code_generator.requirements_structure import is_canonical_structure
from code_generator.runner import get_runner, rate_limit
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.runner.retry import CircuitOpen
from code_generator.runner.types import OverageAbort, RunResult

_TIMESTAMP_FORMAT = "%Y%m%dT%H%M%SZ"
_HEADING_RE = re.compile(r"^#{1,4} .+", re.MULTILINE)


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _requirements_path(project_dir: Path) -> Path:
    return project_dir / ".code-generator" / "requirements.md"


def _validate_inputs(project_dir: Path) -> None:
    """Exit non-zero if .code-generator/ or requirements.md is missing."""
    cg_dir = project_dir / ".code-generator"
    if not cg_dir.exists():
        typer.echo("ERROR: .code-generator/ directory not found.", err=True)
        raise typer.Exit(code=1)
    if not _requirements_path(project_dir).exists():
        typer.echo("ERROR: .code-generator/requirements.md not found.", err=True)
        raise typer.Exit(code=1)


def _backup_path(cg_dir: Path) -> Path:
    """Return a timestamped backup path under cg_dir."""
    ts = datetime.now(UTC).strftime(_TIMESTAMP_FORMAT)
    return cg_dir / f"requirements.backup-{ts}.md"


def _write_atomic(path: Path, content: str) -> None:
    """Write content to path atomically via tmp + os.replace."""
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(content)
        os.replace(tmp, path)
    except Exception:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def _diff_summary(original: str, rewritten: str) -> str:
    """Return a brief diff summary: line counts and new section titles."""
    orig_lines = original.splitlines()
    new_lines = rewritten.splitlines()
    delta = len(new_lines) - len(orig_lines)
    sign = "+" if delta >= 0 else ""

    orig_headings = set(_HEADING_RE.findall(original))
    new_headings = _HEADING_RE.findall(rewritten)
    added = [h for h in new_headings if h not in orig_headings]

    parts = [f"Lines: {len(orig_lines)} → {len(new_lines)} ({sign}{delta})"]
    if added:
        parts.append("New sections:")
        parts.extend(f"  {h}" for h in added)
    return "\n".join(parts)


async def _run_optimize_session(
    prompt: str, project_dir: Path, *, max_turns: int | None = None
) -> RunResult:
    """Execute the optimize session via the main runner loop."""
    runner = get_runner()
    logger = setup_phase_logger("optimize", project_dir)
    options = make_agent_options(
        model="claude-opus-4-7",
        effort="high",
        allowed_tools=["Read", "Glob"],
        cwd=str(project_dir),
        **max_turns_kwargs(max_turns),
    )
    state_path = project_dir / ".code-generator" / "state.json"

    result = await rate_limit.main_loop(
        runner,
        prompt,
        options,
        state_path=state_path,
        logger=logger,
    )
    log_phase_usage(logger, "optimize", result.usage)
    return result


# ---------------------------------------------------------------------------
# Public command
# ---------------------------------------------------------------------------


def optimize_command(
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Print the rewrite to stdout without modifying files."),
    ] = False,
    force: Annotated[
        bool,
        typer.Option("--force", help="Bypass the canonical-structure short-circuit."),
    ] = False,
    max_turns: Annotated[
        int | None,
        typer.Option(
            "--max-turns",
            help=(
                "Opt-in per-session turn cap for debugging or strict cost control. "
                "Omit for the default (no cap). Must be a positive integer."
            ),
            callback=validate_max_turns,
            show_default=False,
        ),
    ] = None,
) -> None:
    """Rewrite .code-generator/requirements.md into canonical structure via Claude."""
    project_dir = Path.cwd()
    _validate_inputs(project_dir)

    cg_dir = project_dir / ".code-generator"
    req_path = _requirements_path(project_dir)
    content = req_path.read_text(encoding="utf-8")

    if not force and is_canonical_structure(content):
        typer.echo("requirements.md is already canonical. Use --force to rewrite anyway.")
        raise typer.Exit(code=0)

    prompt = load_prompt("prompt-optimize-requirements.md", CURRENT_REQUIREMENTS=content)
    env.assert_safe_environment()
    env.assert_single_workspace()

    try:
        result = asyncio.run(_run_optimize_session(prompt, project_dir, max_turns=max_turns))
    except OverageAbort as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=2) from exc
    except CircuitOpen as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    if dry_run:
        typer.echo(result.text)
        raise typer.Exit(code=0)

    backup = _backup_path(cg_dir)
    backup.write_text(content, encoding="utf-8")
    _write_atomic(req_path, result.text)

    typer.echo(_diff_summary(content, result.text))
    raise typer.Exit(code=0)
