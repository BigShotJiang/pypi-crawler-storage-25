"""status command — display current project generation state."""

import shutil
import textwrap
from datetime import UTC, datetime
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from code_generator import state as state_module
from code_generator.runner.types import TokenUsage
from code_generator.state_retention import CycleTelemetrySummary

_MISSING = "—"
_SCOPE_MAX_LEN = 60

# Approximate Max plan 5-hour cache_read token budget.
# Used to compute "% of 5h window" column in the cycles table.
_5H_CACHE_READ_BUDGET = 50_000_000


def status_command() -> None:
    """Show the current generation state for this project."""
    project_dir = Path.cwd()
    state_path = project_dir / ".code-generator" / "state.json"

    if not state_path.exists():
        typer.echo(
            "no .code-generator/state.json in this directory — run `code-generator init` first"
        )
        raise typer.Exit(code=0)

    st = state_module.load_state(state_path)
    terminal_width = shutil.get_terminal_size((200, 24)).columns
    console = Console(file=typer.get_text_stream("stdout"), width=max(terminal_width, 200))

    if st.last_error:
        console.print(f"[bold red]⚠ Last error: {st.last_error}[/bold red]\n")

    _render_summary_table(console, st)

    if st.mode == "multi-cycle" and st.cycles:
        _render_cycles_table(console, st)


def _pause_remaining(state: state_module.State) -> str:
    import time

    if state.paused_until is None:
        return "-"
    remaining = state.paused_until - time.time()
    if remaining <= 0:
        return "-"
    minutes = remaining / 60
    return f"{minutes:.1f} minutes remaining"


def _sum_token_usage(token_usage: dict[str, TokenUsage]) -> TokenUsage:
    """Sum all TokenUsage values in a phase→usage mapping."""
    total = TokenUsage()
    for usage in token_usage.values():
        total += usage
    return total


def _render_summary_table(console: Console, st: state_module.State) -> None:
    table = Table(title="code-generator status")
    table.add_column("Field", style="bold")
    table.add_column("Value")

    open_issues = sum(1 for i in st.issues if i.status == "open")
    closed_issues = sum(1 for i in st.issues if i.status == "closed")

    table.add_row("mode", st.mode)
    table.add_row("current cycle", str(st.current_cycle) if st.current_cycle is not None else "-")
    table.add_row("current phase", str(st.phase) if st.phase is not None else "-")
    table.add_row("open issues", str(open_issues))
    table.add_row("closed issues", str(closed_issues))
    table.add_row("rate-limit pause", _pause_remaining(st))

    requirements_hash = getattr(st, "requirements_hash", None)
    if requirements_hash:
        table.add_row("requirements hash", str(requirements_hash)[:8])

    if st.mode == "single" and st.token_usage:
        totals = _sum_token_usage(st.token_usage)
        table.add_section()
        table.add_row("Tokens", "")
        table.add_row("  in", str(totals.input))
        table.add_row("  cache_read", str(totals.cache_read))
        table.add_row("  cache_write", str(totals.cache_write))
        table.add_row("  out", str(totals.output))

    console.print(table)


def _format_status(status: str) -> str:
    if status == "completed":
        return f"✓ {status}"
    return status


def _format_scope(scope: str) -> str:
    if not scope:
        return _MISSING
    return textwrap.shorten(scope, width=_SCOPE_MAX_LEN, placeholder="…")


def _format_depends_on(depends_on: list[int]) -> str:
    if not depends_on:
        return _MISSING
    return ", ".join(str(d) for d in depends_on)


def _format_milestone(milestone_number: int | None) -> str:
    if milestone_number is None:
        return _MISSING
    return f"#{milestone_number}"


def _format_wall_clock(started_at: str | None, finished_at: str | None) -> str:
    """Format elapsed time from ISO 8601 timestamps as Xh Ym (≥1h) or Xm Ys (<1h)."""
    if started_at is None or finished_at is None:
        return _MISSING
    start = datetime.fromisoformat(started_at.replace("Z", "+00:00")).replace(tzinfo=UTC)
    end = datetime.fromisoformat(finished_at.replace("Z", "+00:00")).replace(tzinfo=UTC)
    total_seconds = int((end - start).total_seconds())
    if total_seconds < 0:
        return _MISSING
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours >= 1:
        return f"{hours}h {minutes}m"
    return f"{minutes}m {seconds}s"


def _format_pct_5h(token_usage: dict[str, TokenUsage]) -> str:
    """Format cache_read sum as % of the 5h budget constant."""
    if not token_usage:
        return _MISSING
    total_cache_read = sum(u.cache_read for u in token_usage.values())
    pct = total_cache_read / _5H_CACHE_READ_BUDGET * 100
    return f"{pct:.1f}%"


def _format_cache_hit_pct(cache_telemetry: dict[str, int | float]) -> str:
    """Format cache_hit_pct as XX.X% or '-' when telemetry is absent or all-zero.

    Args:
        cache_telemetry: The cycle's ``cache_telemetry`` dict.

    Returns:
        Formatted percentage string, or ``'-'`` when the value is zero or absent.
    """
    pct = cache_telemetry.get("cache_hit_pct", 0.0)
    if not pct:
        return "-"
    return f"{pct:.1f}%"


def _format_model(cycle: state_module.CycleState) -> str:
    """Return the provider label for a cycle's Model column (#222).

    ``ollama:<tag>`` when the cycle ran on the Ollama codepath;
    ``anthropic-max`` otherwise. The short default label keeps the column
    narrow and avoids leaking the phase-specific Opus/Sonnet split.
    """
    if cycle.ollama_model:
        return f"ollama:{cycle.ollama_model}"
    return "anthropic-max"


def _format_turns(token_usage: dict[str, TokenUsage]) -> str:
    """Format the summed ``num_turns`` across all phases of one cycle (#211).

    Returns ``'0'`` for pre-0.3.1 state.json entries whose ``TokenUsage``
    carries a zeroed ``num_turns`` default, so legacy data renders without a
    crash and without an "unknown" sentinel.
    """
    return str(_sum_token_usage(token_usage).num_turns)


def _build_cycles_table() -> Table:
    """Create and return the cycles Rich table with all column headers."""
    table = Table(title="cycles")
    for col in (
        "id",
        "name",
    ):
        table.add_column(col)
    # Model column stays full-width — Ollama tags like ``qwen3-coder:480b:cloud``
    # must not be truncated with ellipsis (issue #222).
    table.add_column("Model", no_wrap=True, overflow="fold")
    for col in (
        "status",
        "phase",
        "closed/total",
        "scope",
        "depends on",
        "milestone",
        "in",
        "cache_read",
        "cache_write",
        "out",
        "Turns",
        "wall-clock",
        "% of 5h",
        "Cache hit %",
    ):
        table.add_column(col)
    return table


def _render_full_cycle_row(cycle: state_module.CycleState, table: Table) -> None:
    """Append a full-detail row for a CycleState entry to the table."""
    closed = sum(1 for i in cycle.issues if i.status == "closed")
    total = len(cycle.issues)
    if cycle.token_usage:
        totals = _sum_token_usage(cycle.token_usage)
        tok_in, tok_cr, tok_cw, tok_out = (
            str(totals.input),
            str(totals.cache_read),
            str(totals.cache_write),
            str(totals.output),
        )
    else:
        tok_in = tok_cr = tok_cw = tok_out = _MISSING
    table.add_row(
        str(cycle.id),
        cycle.name,
        _format_model(cycle),
        _format_status(cycle.status),
        str(cycle.phase),
        f"{closed}/{total}",
        _format_scope(cycle.scope),
        _format_depends_on(cycle.depends_on),
        _format_milestone(cycle.milestone_number),
        tok_in,
        tok_cr,
        tok_cw,
        tok_out,
        _format_turns(cycle.token_usage),
        _format_wall_clock(cycle.started_at, cycle.finished_at),
        _format_pct_5h(cycle.token_usage),
        _format_cache_hit_pct(cycle.cache_telemetry),
    )


def _render_summary_cycle_row(summary: CycleTelemetrySummary, table: Table) -> None:
    """Append a compact summary row for a CycleTelemetrySummary entry to the table."""
    pct = f"{summary.cache_hit_pct:.1f}%" if summary.cache_hit_pct else "-"
    table.add_row(
        _MISSING,
        summary.cycle_name,
        _MISSING,  # Model: not retained in the compact summary
        "(summary)",
        _MISSING,
        _MISSING,
        _MISSING,
        _MISSING,
        _MISSING,
        str(summary.total_tokens),
        _MISSING,
        _MISSING,
        _MISSING,
        _MISSING,  # Turns: not retained in the compact summary
        _MISSING,
        _MISSING,
        pct,
    )


def _render_cycles_table(console: Console, st: state_module.State) -> None:
    table = _build_cycles_table()
    for cycle in st.cycles:
        if isinstance(cycle, CycleTelemetrySummary):
            _render_summary_cycle_row(cycle, table)
        else:
            _render_full_cycle_row(cycle, table)
    console.print(table)
