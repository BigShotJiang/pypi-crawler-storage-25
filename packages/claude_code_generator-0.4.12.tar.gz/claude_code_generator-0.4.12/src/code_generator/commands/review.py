"""review command — run a standalone code-review session via Claude."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Annotated

import typer

from code_generator import env
from code_generator.commands._validators import validate_max_turns
from code_generator.logging_setup import setup_phase_logger
from code_generator.prompts import load_prompt
from code_generator.runner import get_runner, rate_limit
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.runner.retry import CircuitOpen
from code_generator.runner.types import OverageAbort, RunResult


def _build_options(max_turns: int | None = None) -> object:
    """Build ClaudeAgentOptions for the review session.

    Args:
        max_turns: Optional per-session turn cap from the ``--max-turns`` flag;
            forwarded only when set.

    Returns:
        ClaudeAgentOptions if the SDK is available, else a duck-typed fallback.
    """
    return make_agent_options(
        model="claude-opus-4-7",
        allowed_tools=["Read", "Grep", "Glob", "Bash"],
        cwd=str(Path.cwd()),
        **max_turns_kwargs(max_turns),
    )


async def _run_review_session(
    prompt: str, project_dir: Path, *, max_turns: int | None = None
) -> RunResult:
    """Execute the review session via the main runner loop.

    Args:
        prompt: The fully rendered review prompt.
        project_dir: Root of the project being reviewed (used for state + logs).

    Returns:
        RunResult from the completed session.

    Raises:
        OverageAbort: When overage billing is detected.
        CircuitOpen: When the circuit breaker trips on transient failures.
    """
    runner = get_runner()
    logger = setup_phase_logger("review", project_dir)
    options = _build_options(max_turns=max_turns)
    state_path = project_dir / ".code-generator" / "state.json"

    return await rate_limit.main_loop(
        runner,
        prompt,
        options,
        state_path=state_path,
        logger=logger,
    )


def review_command(
    create_issues: Annotated[
        bool,
        typer.Option(
            "--create-issues/--no-create-issues",
            help="Automatically create GitHub issues for findings.",
        ),
    ] = False,
    severity: Annotated[
        str,
        typer.Option(
            "--severity",
            help="Minimum severity to report: low, medium, high, or critical.",
        ),
    ] = "low",
    max_turns: Annotated[
        int | None,
        typer.Option(
            "--max-turns",
            help=(
                "Opt-in per-session turn cap for debugging or strict cost control. "
                "Omit for the default (no cap). Must be a positive integer."
            ),
            callback=validate_max_turns,
            show_default=False,
        ),
    ] = None,
) -> None:
    """Run a standalone code review against the current repository."""
    offenders = [var for var in env.DANGEROUS_VARS if var in os.environ]
    if offenders:
        listed = ", ".join(offenders)
        typer.echo(
            f"ERROR: Dangerous env vars detected ({listed}). "
            "Unset them before running review to avoid API credit usage.",
            err=True,
        )
        raise typer.Exit(code=2)

    prompt = load_prompt(
        "prompt-review.md",
        CREATE_ISSUES=str(create_issues).lower(),
        SEVERITY_FILTER=severity,
    )

    project_dir = Path.cwd()

    try:
        result = asyncio.run(_run_review_session(prompt, project_dir, max_turns=max_turns))
        typer.echo(result.text)
        raise typer.Exit(code=0)
    except OverageAbort as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=2) from exc
    except CircuitOpen as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=1) from exc
