"""bench export subcommand — dump live state.json telemetry to JSON.

Usage:
    code-generator bench export [--cycles N] [--output FILE]

Reads .code-generator/state.json in the current working directory and
serializes the cycle telemetry into the same schema used by `bench` (#193).
Full cycles produce per-phase metrics; summary-form cycles (retention
policy §16) are marked with truncated: true and carry only the three
retained fields (total_tokens, cache_hit_pct, wall_seconds).

This command is strictly read-state-then-serialize: it never invokes the SDK
or any runner.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated, Any

import typer

from code_generator.commands._bench_io import SCHEMA_VERSION, write_output
from code_generator.state import CycleState, load_state
from code_generator.state_retention import CycleTelemetrySummary

_STATE_FILENAME = Path(".code-generator") / "state.json"


# ---------------------------------------------------------------------------
# Pure builders (exported for tests)
# ---------------------------------------------------------------------------


def build_cycle_report_from_state(cycle: CycleState) -> dict[str, Any]:
    """Build a cycle report dict from a full CycleState.

    Per-phase metrics come from cycle.token_usage; totals come from
    cycle.cache_telemetry. wall_seconds per phase is not tracked in state,
    so it defaults to 0.0.

    Args:
        cycle: A full CycleState with token_usage populated.

    Returns:
        Dict with cycle_name, phases, and totals keys matching the bench schema.
    """
    phases = {
        phase_key: _phase_metrics_from_usage(usage)
        for phase_key, usage in cycle.token_usage.items()
    }
    return {
        "cycle_name": cycle.name,
        "phases": phases,
        "totals": dict(cycle.cache_telemetry),
    }


def build_truncated_cycle_report(cycle: CycleTelemetrySummary) -> dict[str, Any]:
    """Build a cycle report dict from a compact CycleTelemetrySummary.

    Only the three retained fields are present in totals. The truncated flag
    signals to downstream consumers that per-phase data is unavailable.

    Args:
        cycle: A retention-policy summary with the three retained fields.

    Returns:
        Dict with cycle_name, truncated: true, and a partial totals dict.
    """
    return {
        "cycle_name": cycle.cycle_name,
        "truncated": True,
        "totals": {
            "total_tokens": cycle.total_tokens,
            "cache_hit_pct": cycle.cache_hit_pct,
            "wall_seconds": cycle.wall_seconds,
        },
    }


def select_cycles(
    cycles: list[CycleState | CycleTelemetrySummary],
    *,
    last_n: int | None,
) -> list[CycleState | CycleTelemetrySummary]:
    """Return the last *last_n* cycles, or all when last_n is None.

    Args:
        cycles: Full ordered cycle list from state (oldest first).
        last_n: Number of most-recent cycles to keep; None means all.

    Returns:
        A slice of the input list (original objects, no copy).
    """
    if last_n is None:
        return cycles
    return cycles[-last_n:] if last_n <= len(cycles) else cycles


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _phase_metrics_from_usage(usage: Any) -> dict[str, int | float]:
    """Convert a TokenUsage (or raw dict) to a seven-key phase-metrics dict.

    wall_seconds is not tracked per phase in state.json, so it is 0.0.
    ``num_turns`` is surfaced from the TokenUsage field (schema v2, issue #212);
    legacy pre-0.3.1 entries default to 0 via :func:`_get`.
    """
    inp = _get(usage, "input")
    out = _get(usage, "output")
    read = _get(usage, "cache_read")
    write = _get(usage, "cache_write")
    turns = _get(usage, "num_turns")
    denominator = read + write + inp
    hit_pct = round(read / denominator * 100, 1) if denominator else 0.0
    return {
        "input": inp,
        "output": out,
        "cache_read": read,
        "cache_write": write,
        "cache_hit_pct": hit_pct,
        "wall_seconds": 0.0,
        "num_turns": turns,
    }


def _get(obj: Any, key: str) -> int:
    """Get an integer attribute from a dataclass or dict."""
    if isinstance(obj, dict):
        return int(obj.get(key, 0))
    return int(getattr(obj, key, 0))


def _serialize_cycles(
    cycles: list[CycleState | CycleTelemetrySummary],
) -> list[dict[str, Any]]:
    return [
        build_truncated_cycle_report(c)
        if isinstance(c, CycleTelemetrySummary)
        else build_cycle_report_from_state(c)
        for c in cycles
    ]


def _build_export_report(cycles: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "timestamp_utc": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "cycles": cycles,
    }


def _resolve_output(output: str) -> Path | None:
    """Return None (stdout) for empty string or hyphen, else a Path."""
    if not output or output == "-":
        return None
    return Path(output)


# ---------------------------------------------------------------------------
# Typer command
# ---------------------------------------------------------------------------


def export_command(
    cycles: Annotated[
        int | None,
        typer.Option("--cycles", help="Export only the last N cycles (must be ≥1). Default: all."),
    ] = None,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            help="Write JSON to this file. Use '-' or omit to print to stdout.",
        ),
    ] = "",
) -> None:
    """Export live state.json telemetry to JSON for external analysis.

    Reads .code-generator/state.json in the current directory. Full cycles
    produce per-phase metrics; retention-truncated cycles are marked with
    truncated: true.

    Exit code 2 if state.json is missing or --cycles is not a positive integer.
    """
    if cycles is not None and cycles <= 0:
        typer.echo("--cycles must be a positive integer (≥ 1)", err=True)
        raise typer.Exit(code=2)

    state_path = Path.cwd() / _STATE_FILENAME
    if not state_path.exists():
        typer.echo(
            f"No state.json found — run 'code-generator generate' first (expected: {state_path})",
            err=True,
        )
        raise typer.Exit(code=2)

    state = load_state(state_path)
    selected = select_cycles(state.cycles, last_n=cycles)
    cycle_dicts = _serialize_cycles(selected)
    report = _build_export_report(cycle_dicts)
    write_output(_resolve_output(output), report)
