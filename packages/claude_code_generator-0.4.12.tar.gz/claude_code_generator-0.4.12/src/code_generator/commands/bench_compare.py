"""bench compare subcommand — per-phase delta table between two bench reports.

Usage:
    code-generator bench compare A.json B.json

Prints a Rich table with columns: phase, metric, A, B, Δ, Δ%.
Pure reporting — no exit-code gating, no threshold flags.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated, Literal

import typer
from rich.console import Console
from rich.table import Table

# Metric direction: whether a lower or higher value represents improvement.
# Used for color-coding rows: worsening → red, improving → green.
METRIC_DIRECTION: dict[str, Literal["lower-better", "higher-better"]] = {
    "input": "lower-better",
    "output": "lower-better",
    "cache_read": "lower-better",
    "cache_write": "lower-better",
    "wall_seconds": "lower-better",
    "num_turns": "lower-better",
    "cache_hit_pct": "higher-better",
}

_METRICS_ORDER: list[str] = [
    "input",
    "output",
    "cache_read",
    "cache_write",
    "cache_hit_pct",
    "wall_seconds",
    "num_turns",
]
_NUM_PHASES: int = 8


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DeltaRow:
    """Immutable record for one (phase, metric) delta pair."""

    phase: int
    metric: str
    a: float | None
    b: float | None
    delta: float | None
    delta_pct: float | None
    direction: Literal["lower-better", "higher-better"]


# ---------------------------------------------------------------------------
# Pure computation
# ---------------------------------------------------------------------------


def compute_deltas(a: dict, b: dict) -> list[DeltaRow]:
    """Return per-phase delta rows between two bench reports.

    Exits with code 2 on schema_version mismatch.
    Missing phases produce rows with None values — no crash.
    """
    _assert_schema_versions_match(a, b)

    a_phases = _first_cycle_phases(a)
    b_phases = _first_cycle_phases(b)

    rows: list[DeltaRow] = []
    for phase in range(_NUM_PHASES):
        key = str(phase)
        rows.extend(_rows_for_phase(phase, a_phases.get(key), b_phases.get(key)))
    return rows


def _assert_schema_versions_match(a: dict, b: dict) -> None:
    a_ver = a.get("schema_version")
    b_ver = b.get("schema_version")
    if a_ver != b_ver:
        typer.echo(
            f"Schema version mismatch: A has schema_version={a_ver!r},"
            f" B has schema_version={b_ver!r}",
            err=True,
        )
        raise typer.Exit(code=2)


def _first_cycle_phases(report: dict) -> dict[str, dict]:
    cycles = report.get("cycles", [])
    if not cycles:
        return {}
    return cycles[0].get("phases", {})


def _rows_for_phase(
    phase: int,
    a_phase: dict | None,
    b_phase: dict | None,
) -> list[DeltaRow]:
    return [_build_row(phase, metric, a_phase, b_phase) for metric in _METRICS_ORDER]


def _build_row(
    phase: int,
    metric: str,
    a_phase: dict | None,
    b_phase: dict | None,
) -> DeltaRow:
    a_val = float(a_phase[metric]) if a_phase is not None else None
    b_val = float(b_phase[metric]) if b_phase is not None else None
    delta, delta_pct = _delta_values(a_val, b_val)
    return DeltaRow(
        phase=phase,
        metric=metric,
        a=a_val,
        b=b_val,
        delta=delta,
        delta_pct=delta_pct,
        direction=METRIC_DIRECTION[metric],
    )


def _delta_values(
    a: float | None,
    b: float | None,
) -> tuple[float | None, float | None]:
    if a is None or b is None:
        return None, None
    delta = b - a
    delta_pct = None if a == 0 else round((b - a) / a * 100, 1)
    return delta, delta_pct


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------


def _fmt_value(val: float | None, metric: str) -> str:
    if val is None:
        return "-"
    if metric == "cache_hit_pct":
        return f"{val:.1f}%"
    if metric == "wall_seconds":
        return f"{val:.2f}s"
    return str(int(val))


def _fmt_delta(delta: float | None) -> str:
    if delta is None:
        return "-"
    if delta == 0:
        return "0"
    sign = "+" if delta > 0 else "\u2212"  # − (minus sign)
    mag = abs(delta)
    return f"{sign}{int(mag)}" if mag == int(mag) else f"{sign}{mag:.1f}"


def _fmt_delta_pct(delta_pct: float | None) -> str:
    if delta_pct is None:
        return "-"
    if delta_pct == 0.0:
        return "0.0%"
    sign = "+" if delta_pct > 0 else "\u2212"
    return f"{sign}{abs(delta_pct):.1f}%"


def _row_style(row: DeltaRow) -> str:
    """Return Rich style string: red=worsening, green=improving, empty=unchanged."""
    if row.delta is None or row.delta == 0:
        return ""
    worsening = (row.direction == "lower-better" and row.delta > 0) or (
        row.direction == "higher-better" and row.delta < 0
    )
    return "red" if worsening else "green"


# ---------------------------------------------------------------------------
# Rich rendering
# ---------------------------------------------------------------------------


def render_delta_table(rows: list[DeltaRow], console: Console | None = None) -> None:
    """Print the delta rows as a Rich table to *console* (or stdout)."""
    _console = console or Console()
    _console.print(_build_table(rows))


def _build_table(rows: list[DeltaRow]) -> Table:
    table = Table(title="bench compare", show_header=True, header_style="bold")
    table.add_column("phase", style="dim")
    table.add_column("metric")
    table.add_column("A", justify="right")
    table.add_column("B", justify="right")
    table.add_column("\u0394", justify="right")  # Δ
    table.add_column("\u0394%", justify="right")  # Δ%

    for row in rows:
        table.add_row(
            str(row.phase),
            row.metric,
            _fmt_value(row.a, row.metric),
            _fmt_value(row.b, row.metric),
            _fmt_delta(row.delta),
            _fmt_delta_pct(row.delta_pct),
            style=_row_style(row),
        )
    return table


# ---------------------------------------------------------------------------
# Typer command
# ---------------------------------------------------------------------------


def compare_command(
    a: Annotated[str, typer.Argument(help="Path to baseline report (A).")],
    b: Annotated[str, typer.Argument(help="Path to candidate report (B).")],
) -> None:
    """Print a Rich table of per-phase deltas between two bench reports.

    Exit code is always 0 on a successful compare (measurement-only guarantee).
    Exit code 2 if the reports have different schema_version values.
    """
    a_path = Path(a)
    b_path = Path(b)

    if not a_path.exists():
        typer.echo(f"File not found: {a}", err=True)
        raise typer.Exit(code=1)
    if not b_path.exists():
        typer.echo(f"File not found: {b}", err=True)
        raise typer.Exit(code=1)

    a_report = json.loads(a_path.read_text(encoding="utf-8"))
    b_report = json.loads(b_path.read_text(encoding="utf-8"))

    rows = compute_deltas(a_report, b_report)
    render_delta_table(rows)
