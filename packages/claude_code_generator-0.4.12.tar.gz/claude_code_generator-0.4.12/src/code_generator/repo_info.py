"""RepoInfo dataclass and git remote URL parser.

Single responsibility: represent a parsed git remote URL as an immutable
value object and resolve SSH host aliases via ~/.ssh/config.

No subprocess calls — this is a pure parser module. A separate module
(e.g. git_ops) is responsible for calling ``git remote get-url origin``
and passing the result here.

Supported URL forms
-------------------
- HTTPS:         ``https://host/owner/repo(.git)?``
- SSH (SCP):     ``user@host:owner/repo(.git)?``  (e.g. git@github.com:o/n.git)
- SSH URI:       ``ssh://host/owner/repo(.git)?``
- Alias (SCP):   ``alias:owner/repo(.git)?``      (no user@ prefix)

For SSH forms the host/alias is resolved through ~/.ssh/config before
being stored in :attr:`RepoInfo.host`.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_DEFAULT_SSH_CONFIG = Path.home() / ".ssh" / "config"

# HTTPS: https://host/owner/repo(.git)?
_HTTPS_RE = re.compile(r"^https?://([^/]+)/([^/]+)/([^/]+?)(?:\.git)?/?$")

# SSH SCP with user: user@host:owner/repo(.git)?
_SCP_USER_RE = re.compile(r"^[a-zA-Z0-9._-]+@([^:]+):([^/]+)/(.+?)(?:\.git)?$")

# SSH URI: ssh://host/owner/repo(.git)?
_SSH_URI_RE = re.compile(r"^ssh://([^/]+)/([^/]+)/(.+?)(?:\.git)?/?$")

# Bare alias SCP: alias:owner/repo(.git)?  (no user@ prefix)
_ALIAS_SCP_RE = re.compile(r"^([^/@:]+):([^/]+)/(.+?)(?:\.git)?$")


# ---------------------------------------------------------------------------
# Value object
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RepoInfo:
    """Immutable record for a parsed git remote.

    Attributes:
        host: Real hostname (after SSH alias resolution).
        owner: Repository owner (user or organisation).
        name: Repository name (without ``.git`` suffix).
        full: ``"{owner}/{name}"`` — derived convenience shorthand.
    """

    host: str
    owner: str
    name: str
    full: str = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "full", f"{self.owner}/{self.name}")


# ---------------------------------------------------------------------------
# SSH alias resolution
# ---------------------------------------------------------------------------


def resolve_ssh_alias(alias: str, ssh_config_path: Path) -> str:
    """Return the real hostname for *alias* from an SSH config file.

    Scans *ssh_config_path* for a ``Host <alias>`` stanza and returns the
    associated ``HostName`` value.  Returns *alias* unchanged when no
    matching stanza exists or the file does not exist.

    Args:
        alias: SSH host alias to resolve.
        ssh_config_path: Path to the SSH configuration file.

    Returns:
        Real hostname, or *alias* if the file is missing or alias not found.
    """
    if not ssh_config_path.exists():
        return alias
    text = ssh_config_path.read_text(encoding="utf-8")
    return _extract_hostname(alias, text)


def _extract_hostname(alias: str, config_text: str) -> str:
    """Scan raw SSH config text and return HostName for *alias*."""
    in_target_stanza = False
    for line in config_text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        parts = stripped.split(None, 1)
        key = parts[0].lower()
        value = parts[1].strip() if len(parts) > 1 else ""

        if key == "host":
            in_target_stanza = value == alias
            continue

        if in_target_stanza and key == "hostname":
            return value

    return alias


# ---------------------------------------------------------------------------
# Remote URL parser
# ---------------------------------------------------------------------------


def parse_remote_url(
    url: str,
    ssh_config_path: Path | None = None,
) -> RepoInfo:
    """Parse a git remote URL into a :class:`RepoInfo`.

    Args:
        url: Git remote URL string (HTTPS, SCP SSH, SSH URI, or bare alias).
        ssh_config_path: Path to the SSH config file used for alias resolution.
            Defaults to ``~/.ssh/config`` when ``None``.

    Returns:
        Populated, immutable :class:`RepoInfo` instance.

    Raises:
        ValueError: When *url* does not match any recognised git remote pattern.
    """
    config_path = ssh_config_path if ssh_config_path is not None else _DEFAULT_SSH_CONFIG
    host, owner, name = _match_url(url, config_path)
    return RepoInfo(host=host, owner=owner, name=name)


def _match_url(url: str, config_path: Path) -> tuple[str, str, str]:
    """Return ``(host, owner, name)`` for *url*, raising on no match."""
    if m := _HTTPS_RE.match(url):
        return m.group(1), m.group(2), m.group(3)

    if m := _SCP_USER_RE.match(url):
        host = resolve_ssh_alias(m.group(1), config_path)
        return host, m.group(2), m.group(3)

    if m := _SSH_URI_RE.match(url):
        host = resolve_ssh_alias(m.group(1), config_path)
        return host, m.group(2), m.group(3)

    if m := _ALIAS_SCP_RE.match(url):
        host = resolve_ssh_alias(m.group(1), config_path)
        return host, m.group(2), m.group(3)

    raise ValueError(f"Unrecognized git remote URL: {url!r}")
