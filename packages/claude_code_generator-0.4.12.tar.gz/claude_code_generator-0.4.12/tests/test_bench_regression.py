"""Integration test: bench --fake end-to-end schema well-formedness.

Acceptance criteria (issue #193):
  pytest tests/test_bench_regression.py runs bench --fake end-to-end and
  asserts schema well-formedness (NO absolute-number assertions).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from code_generator.cli import app
from code_generator.commands.bench import SCHEMA_VERSION

_SCHEMA_REQUIRED_KEYS = {"schema_version", "timestamp_utc", "session_mode", "fixture", "cycles"}
_CYCLE_REQUIRED_KEYS = {"cycle_name", "phases", "totals"}
_PHASE_REQUIRED_KEYS = {
    "input",
    "output",
    "cache_read",
    "cache_write",
    "cache_hit_pct",
    "wall_seconds",
    "num_turns",
}
_ALL_PHASES = [str(p) for p in range(8)]


@pytest.fixture
def bench_report(tmp_path: Path) -> dict:
    """Run bench --fake and return the parsed JSON report."""
    out_file = tmp_path / "bench.json"
    runner = CliRunner()
    result = runner.invoke(app, ["bench", "--fake", "--cycles", "2", "--output", str(out_file)])
    assert result.exit_code == 0, f"bench command failed: {result.output}"
    return json.loads(out_file.read_text())


class TestBenchRegressionSchema:
    """Verify the bench --fake output is schema-well-formed."""

    def test_top_level_keys_present(self, bench_report: dict) -> None:
        assert set(bench_report.keys()) >= _SCHEMA_REQUIRED_KEYS

    def test_schema_version_is_integer(self, bench_report: dict) -> None:
        assert isinstance(bench_report["schema_version"], int)

    def test_schema_version_matches_constant(self, bench_report: dict) -> None:
        assert bench_report["schema_version"] == SCHEMA_VERSION

    def test_timestamp_utc_is_string(self, bench_report: dict) -> None:
        assert isinstance(bench_report["timestamp_utc"], str)
        assert len(bench_report["timestamp_utc"]) > 0

    def test_session_mode_is_valid(self, bench_report: dict) -> None:
        assert bench_report["session_mode"] in ("fresh", "shared")

    def test_fixture_is_string(self, bench_report: dict) -> None:
        assert isinstance(bench_report["fixture"], str)

    def test_cycles_is_non_empty_list(self, bench_report: dict) -> None:
        assert isinstance(bench_report["cycles"], list)
        assert len(bench_report["cycles"]) > 0

    def test_each_cycle_has_required_keys(self, bench_report: dict) -> None:
        for i, cycle in enumerate(bench_report["cycles"]):
            assert set(cycle.keys()) >= _CYCLE_REQUIRED_KEYS, f"Cycle {i} missing keys"

    def test_each_cycle_phases_covers_all_eight(self, bench_report: dict) -> None:
        for i, cycle in enumerate(bench_report["cycles"]):
            phases = cycle["phases"]
            for phase_str in [str(p) for p in range(8)]:
                assert phase_str in phases, f"Cycle {i} missing phase {phase_str}"

    def test_each_phase_has_required_metric_keys(self, bench_report: dict) -> None:
        for i, cycle in enumerate(bench_report["cycles"]):
            for phase_str, metrics in cycle["phases"].items():
                assert set(metrics.keys()) >= _PHASE_REQUIRED_KEYS, (
                    f"Cycle {i} phase {phase_str} missing metric keys"
                )

    def test_each_phase_metric_values_are_numeric(self, bench_report: dict) -> None:
        for cycle in bench_report["cycles"]:
            for phase_str, metrics in cycle["phases"].items():
                for key in ("input", "output", "cache_read", "cache_write"):
                    assert isinstance(metrics[key], int), (
                        f"Phase {phase_str}.{key} should be int, got {type(metrics[key])}"
                    )
                assert isinstance(metrics["cache_hit_pct"], float), (
                    f"Phase {phase_str}.cache_hit_pct should be float"
                )
                assert isinstance(metrics["wall_seconds"], int | float), (
                    f"Phase {phase_str}.wall_seconds should be numeric"
                )

    def test_cache_hit_pct_in_valid_range(self, bench_report: dict) -> None:
        for cycle in bench_report["cycles"]:
            for phase_str, metrics in cycle["phases"].items():
                pct = metrics["cache_hit_pct"]
                assert 0.0 <= pct <= 100.0, f"Phase {phase_str}.cache_hit_pct={pct} out of [0,100]"

    def test_totals_has_required_keys(self, bench_report: dict) -> None:
        for i, cycle in enumerate(bench_report["cycles"]):
            assert set(cycle["totals"].keys()) >= _PHASE_REQUIRED_KEYS, (
                f"Cycle {i} totals missing keys"
            )

    def test_cycle_names_are_unique(self, bench_report: dict) -> None:
        names = [c["cycle_name"] for c in bench_report["cycles"]]
        assert len(names) == len(set(names)), "Duplicate cycle names"
