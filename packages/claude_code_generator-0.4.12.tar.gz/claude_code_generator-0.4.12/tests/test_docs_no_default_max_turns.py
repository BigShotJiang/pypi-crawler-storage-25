"""Doc guards for the no-default ``max_turns`` invariant (issue #213).

Three artefacts must carry the policy change end-to-end so operators and
future developers both see it:

- **README.md** — a short ``Turn budgets`` subsection explaining the default
  (no cap), the three real safety nets, and the ``--max-turns`` opt-in.
- **CLAUDE.md** — a non-negotiable invariant forbidding SDK callers from
  passing ``max_turns``.
- **CHANGELOG.md** — a top-of-entry breaking note, a section enumerating
  the §1–§5 changes, and a migration reference to the bench schema bump.
"""

from __future__ import annotations

import re
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
_README = _REPO_ROOT / "README.md"
_CLAUDE_MD = _REPO_ROOT / "CLAUDE.md"
_CHANGELOG = _REPO_ROOT / "CHANGELOG.md"


def _changelog_030_section() -> str:
    text = _CHANGELOG.read_text(encoding="utf-8")
    match = re.search(r"^## \[0\.3\.0\](.*?)(?=^## \[|\Z)", text, re.DOTALL | re.MULTILINE)
    assert match, "## [0.3.0] section not found in CHANGELOG.md"
    return match.group(0)


# ---------------------------------------------------------------------------
# README — Turn budgets subsection (AC #1)
# ---------------------------------------------------------------------------


def test_readme_turn_budgets_subsection_exists() -> None:
    text = _README.read_text(encoding="utf-8")
    assert re.search(r"^#{3,4} Turn budgets", text, re.MULTILINE), (
        "README must expose a 'Turn budgets' subsection"
    )


def test_readme_turn_budgets_covers_all_three_points() -> None:
    """The subsection must mention: no default cap, real safety nets, --max-turns opt-in."""
    text = _README.read_text(encoding="utf-8").lower()
    # No default cap.
    assert "no per-session turn budget is set by default" in text or (
        "no turn budget" in text and "default" in text
    )
    # The three real safety nets.
    assert "rate-limit" in text or "rate limit" in text
    assert "overage" in text
    assert "task budget" in text or "task-budget" in text
    # The opt-in flag.
    assert "--max-turns" in text


# ---------------------------------------------------------------------------
# CLAUDE.md — non-negotiable invariant (AC #2)
# ---------------------------------------------------------------------------


def test_claude_md_has_no_max_turns_invariant() -> None:
    """CLAUDE.md non-negotiables must forbid SDK callers from setting max_turns."""
    text = _CLAUDE_MD.read_text(encoding="utf-8")
    lowered = text.lower()
    # The key phrase identifying the invariant.
    assert "max_turns" in text
    assert "make_agent_options" in text
    # Semantic markers: "production logs is a bug" and the three safety nets.
    assert "production" in lowered and "bug" in lowered
    assert "rate-limit" in lowered or "rate limit" in lowered
    assert "overage" in lowered
    assert "task budget" in lowered or "task-budget" in lowered


def test_claude_md_invariant_lives_under_non_negotiables_section() -> None:
    """The max_turns invariant must sit under the 'Non-negotiable constraints' section."""
    text = _CLAUDE_MD.read_text(encoding="utf-8")
    # Extract from "## Non-negotiable constraints" up to the next ## heading.
    match = re.search(
        r"^## Non-negotiable constraints(.*?)(?=^## |\Z)",
        text,
        re.DOTALL | re.MULTILINE,
    )
    assert match, "Missing '## Non-negotiable constraints' section in CLAUDE.md"
    section = match.group(1)
    assert "max_turns" in section, (
        "max_turns invariant must live under the Non-negotiable constraints section"
    )
    assert "make_agent_options" in section


# ---------------------------------------------------------------------------
# CHANGELOG.md — breaking note + §1–§5 section + migration reference (AC #3,4)
# ---------------------------------------------------------------------------


def test_changelog_breaking_note_appears_at_top_of_030_entry() -> None:
    """The breaking default-change note must precede every ### sub-section."""
    section = _changelog_030_section()
    # Index of the first "### " subheading after the entry title.
    first_subheading = section.find("\n### ")
    assert first_subheading != -1, "Missing any ### subheading under [0.3.0]"
    prelude = section[:first_subheading].lower()
    # The breaking note must be inside the prelude.
    assert (
        "breaking" in prelude
        or "default behavior change" in prelude
        or ("no longer" in prelude and "turn" in prelude)
    ), "Breaking default-behavior note must appear at the top of [0.3.0]"


def test_changelog_enumerates_no_default_max_turns_change() -> None:
    """0.3.0 must call out: removal of the default budget, --max-turns flag, num_turns telemetry."""
    section = _changelog_030_section().lower()
    # Removal of the default budget.
    assert "no more" in section and "max_turns" in section, (
        "Missing 'no more max_turns default' call-out in [0.3.0]"
    )
    # The new --max-turns flag.
    assert "--max-turns" in section
    # New num_turns telemetry.
    assert "num_turns" in section


def test_changelog_references_bench_schema_bump() -> None:
    """Migration note referencing the bench schema bump from #212."""
    section = _changelog_030_section().lower()
    assert "schema" in section and ("v2" in section or "1 → 2" in section or "1-&gt;2" in section)


def test_changelog_breaking_note_mentions_max_turns_exceeded_migration() -> None:
    """The breaking note should tell operators what to do if they depended on MaxTurnsExceeded."""
    section = _changelog_030_section()
    assert "MaxTurnsExceeded" in section, (
        "Breaking note should reference MaxTurnsExceeded so operators see the migration hint"
    )
