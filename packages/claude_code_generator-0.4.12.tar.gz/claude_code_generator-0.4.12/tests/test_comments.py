"""Tests for the format_comments helper function."""

from __future__ import annotations


class TestFormatCommentsNoneOrEmpty:
    def test_none_returns_empty_string(self) -> None:
        """When comments is None, returns an empty string (no section header)."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        result = format_comments(None)

        assert result == ""

    def test_empty_list_returns_empty_string(self) -> None:
        """When comments is an empty list, returns an empty string (no section header)."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        result = format_comments([])

        assert result == ""

    def test_empty_string_has_no_section_header(self) -> None:
        """Empty/None result must not include '## Pre-fetched Issue Comments'."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        assert "## Pre-fetched Issue Comments" not in format_comments(None)
        assert "## Pre-fetched Issue Comments" not in format_comments([])


class TestFormatCommentsSectionHeader:
    def test_returns_section_header_when_comments_present(self) -> None:
        """When comments are present, the output starts with '## Pre-fetched Issue Comments'."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [
            {"author": {"login": "alice"}, "createdAt": "2026-01-01T12:00:00Z", "body": "Hello"}
        ]

        result = format_comments(comments)

        assert result.startswith("## Pre-fetched Issue Comments")


class TestFormatCommentsRendering:
    def test_single_comment_renders_author_timestamp_body(self) -> None:
        """A single comment is rendered with author, timestamp and blockquoted body."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [
            {
                "author": {"login": "alice"},
                "createdAt": "2026-01-01T12:00:00Z",
                "body": "This is a comment.",
            }
        ]

        result = format_comments(comments)

        assert "**alice**" in result
        assert "2026-01-01T12:00:00Z" in result
        assert "> This is a comment." in result

    def test_multiple_comments_all_rendered(self) -> None:
        """Multiple comments are all present in the output."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [
            {
                "author": {"login": "alice"},
                "createdAt": "2026-01-01T12:00:00Z",
                "body": "First comment.",
            },
            {
                "author": {"login": "bob"},
                "createdAt": "2026-01-01T13:00:00Z",
                "body": "Second comment.",
            },
        ]

        result = format_comments(comments)

        assert "**alice**" in result
        assert "**bob**" in result
        assert "> First comment." in result
        assert "> Second comment." in result

    def test_comments_preserved_in_order(self) -> None:
        """Comments appear in the order they are provided (chronological)."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [
            {"author": {"login": "alice"}, "createdAt": "2026-01-01T12:00:00Z", "body": "Alpha"},
            {"author": {"login": "bob"}, "createdAt": "2026-01-01T13:00:00Z", "body": "Beta"},
        ]

        result = format_comments(comments)

        assert result.index("Alpha") < result.index("Beta")


class TestFormatCommentsMultilineBody:
    def test_multiline_body_each_line_blockquoted(self) -> None:
        """Each line of a multi-line comment body is individually blockquoted."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [
            {
                "author": {"login": "alice"},
                "createdAt": "2026-01-01T12:00:00Z",
                "body": "Line one\nLine two\nLine three",
            }
        ]

        result = format_comments(comments)

        assert "> Line one" in result
        assert "> Line two" in result
        assert "> Line three" in result

    def test_multiline_body_no_unquoted_lines(self) -> None:
        """No body line appears in the output without a leading '> '."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [
            {
                "author": {"login": "user"},
                "createdAt": "2026-01-01T12:00:00Z",
                "body": "First\nSecond",
            }
        ]

        result = format_comments(comments)
        body_section = result.split("**user**")[1]

        assert "First\n" not in body_section or "> First" in body_section
        assert "> Second" in body_section


class TestFormatCommentsMissingFields:
    def test_missing_author_uses_unknown(self) -> None:
        """When 'author' key is absent, author name defaults to 'unknown'."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [{"createdAt": "2026-01-01T12:00:00Z", "body": "Some body"}]

        result = format_comments(comments)

        assert "**unknown**" in result

    def test_author_missing_login_uses_unknown(self) -> None:
        """When author dict lacks 'login', author name defaults to 'unknown'."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [{"author": {}, "createdAt": "2026-01-01T12:00:00Z", "body": "Some body"}]

        result = format_comments(comments)

        assert "**unknown**" in result

    def test_author_none_uses_unknown(self) -> None:
        """When author is None, author name defaults to 'unknown'."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [{"author": None, "createdAt": "2026-01-01T12:00:00Z", "body": "Some body"}]

        result = format_comments(comments)

        assert "**unknown**" in result

    def test_missing_created_at_uses_empty_string(self) -> None:
        """When 'createdAt' key is absent, the timestamp is empty (no crash)."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [{"author": {"login": "alice"}, "body": "Some body"}]

        result = format_comments(comments)

        assert "**alice**" in result
        assert "> Some body" in result

    def test_missing_body_renders_empty_blockquote(self) -> None:
        """When 'body' key is absent, the comment renders without crashing."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [{"author": {"login": "alice"}, "createdAt": "2026-01-01T12:00:00Z"}]

        result = format_comments(comments)

        assert "**alice**" in result

    def test_completely_empty_comment_dict_does_not_raise(self) -> None:
        """An empty comment dict renders without raising any exception."""
        from code_generator.prompts import format_comments  # noqa: PLC0415

        comments = [{}]

        result = format_comments(comments)

        assert isinstance(result, str)
        assert "## Pre-fetched Issue Comments" in result


class TestFormatCommentsExported:
    def test_format_comments_in_module_all(self) -> None:
        """format_comments is exported via __all__ in the prompts module."""
        import code_generator.prompts as prompts_module  # noqa: PLC0415

        assert hasattr(prompts_module, "__all__")
        assert "format_comments" in prompts_module.__all__


# ---------------------------------------------------------------------------
# Tests for the shared comment-fetching helpers in orchestrator/_comments.py
# ---------------------------------------------------------------------------


class TestFetchIssueCommentsSuccess:
    def test_returns_comments_list_on_success(self) -> None:
        """fetch_issue_comments returns the list of comment dicts from gh."""
        from unittest.mock import MagicMock, patch  # noqa: PLC0415

        from code_generator.orchestrator._comments import fetch_issue_comments  # noqa: PLC0415

        comments = [{"author": {"login": "alice"}, "createdAt": "2026-01-01", "body": "Hi"}]
        mock_logger = MagicMock()

        mock_repo = MagicMock()
        with patch("code_generator.orchestrator._comments.gh") as mock_gh:
            mock_gh.view_issue.return_value = {"comments": comments}
            result = fetch_issue_comments(mock_repo, 42, mock_logger)

        assert result == comments
        mock_gh.view_issue.assert_called_once_with(mock_repo, 42)

    def test_returns_empty_list_when_no_comments_key(self) -> None:
        """fetch_issue_comments returns [] when issue data has no 'comments' key."""
        from unittest.mock import MagicMock, patch  # noqa: PLC0415

        from code_generator.orchestrator._comments import fetch_issue_comments  # noqa: PLC0415

        mock_logger = MagicMock()

        mock_repo = MagicMock()
        with patch("code_generator.orchestrator._comments.gh") as mock_gh:
            mock_gh.view_issue.return_value = {}
            result = fetch_issue_comments(mock_repo, 7, mock_logger)

        assert result == []

    def test_returns_empty_list_when_comments_is_empty(self) -> None:
        """fetch_issue_comments returns [] when comments list is empty."""
        from unittest.mock import MagicMock, patch  # noqa: PLC0415

        from code_generator.orchestrator._comments import fetch_issue_comments  # noqa: PLC0415

        mock_logger = MagicMock()

        mock_repo = MagicMock()
        with patch("code_generator.orchestrator._comments.gh") as mock_gh:
            mock_gh.view_issue.return_value = {"comments": []}
            result = fetch_issue_comments(mock_repo, 3, mock_logger)

        assert result == []


class TestFetchIssueCommentsGhErrorFallback:
    def test_returns_empty_list_on_gh_error(self) -> None:
        """fetch_issue_comments returns [] and logs a warning when GhError is raised."""
        from unittest.mock import MagicMock, patch  # noqa: PLC0415

        from code_generator.orchestrator._comments import fetch_issue_comments  # noqa: PLC0415

        mock_logger = MagicMock()

        mock_repo = MagicMock()
        with patch("code_generator.orchestrator._comments.gh") as mock_gh:
            mock_gh.GhError = Exception
            mock_gh.view_issue.side_effect = Exception("network failure")
            result = fetch_issue_comments(mock_repo, 99, mock_logger)

        assert result == []
        mock_logger.warning.assert_called_once()

    def test_warning_includes_issue_number(self) -> None:
        """The warning message logged on GhError includes the issue number."""
        from unittest.mock import MagicMock, patch  # noqa: PLC0415

        from code_generator.orchestrator._comments import fetch_issue_comments  # noqa: PLC0415

        mock_logger = MagicMock()

        mock_repo = MagicMock()
        with patch("code_generator.orchestrator._comments.gh") as mock_gh:
            mock_gh.GhError = Exception
            mock_gh.view_issue.side_effect = Exception("timeout")
            fetch_issue_comments(mock_repo, 55, mock_logger)

        warning_args = mock_logger.warning.call_args
        assert "55" in str(warning_args)


class TestFetchFormattedCommentsSuccess:
    def test_returns_formatted_string_on_success(self) -> None:
        """fetch_formatted_comments returns a formatted markdown string."""
        from unittest.mock import MagicMock, patch  # noqa: PLC0415

        from code_generator.orchestrator._comments import fetch_formatted_comments  # noqa: PLC0415

        comments = [{"author": {"login": "bob"}, "createdAt": "2026-01-02", "body": "Hello"}]
        mock_repo = MagicMock()
        mock_logger = MagicMock()

        with patch("code_generator.orchestrator._comments.gh") as mock_gh:
            mock_gh.view_issue.return_value = {"comments": comments}
            result = fetch_formatted_comments(mock_repo, 10, mock_logger)

        assert "## Pre-fetched Issue Comments" in result
        assert "**bob**" in result

    def test_returns_empty_string_when_no_comments(self) -> None:
        """fetch_formatted_comments returns '' when there are no comments."""
        from unittest.mock import MagicMock, patch  # noqa: PLC0415

        from code_generator.orchestrator._comments import fetch_formatted_comments  # noqa: PLC0415

        mock_repo = MagicMock()
        mock_logger = MagicMock()

        with patch("code_generator.orchestrator._comments.gh") as mock_gh:
            mock_gh.view_issue.return_value = {"comments": []}
            result = fetch_formatted_comments(mock_repo, 10, mock_logger)

        assert result == ""

    def test_returns_empty_string_on_gh_error(self) -> None:
        """fetch_formatted_comments returns '' when GhError is raised."""
        from unittest.mock import MagicMock, patch  # noqa: PLC0415

        from code_generator.orchestrator._comments import fetch_formatted_comments  # noqa: PLC0415

        mock_repo = MagicMock()
        mock_logger = MagicMock()

        with patch("code_generator.orchestrator._comments.gh") as mock_gh:
            mock_gh.GhError = Exception
            mock_gh.view_issue.side_effect = Exception("auth error")
            result = fetch_formatted_comments(mock_repo, 77, mock_logger)

        assert result == ""
