"""Tests for code_generator.preflight.run_ollama_preflight.

TDD: Red → Green.
Covers all acceptance criteria from issue #216:
  * OLLAMA_API_KEY env-var check
  * ANTHROPIC_BASE_URL env-var check (pinned to http://localhost:11434)
  * Daemon reachability probe (GET /api/tags, HTTP 200, 2s timeout)
  * Signed-in probe (401 on cloud-model fetch → not signed in)

All network I/O is mocked via ``urllib.request.urlopen``; no live calls.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch
from urllib.error import HTTPError, URLError

import pytest

from code_generator.preflight import (
    OLLAMA_SIGNIN_COMMAND,
    OLLAMA_TAGS_URL,
    PreflightError,
    run_ollama_preflight,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ok_response(status: int = 200) -> MagicMock:
    """Fake urlopen return value with HTTP status attribute."""
    resp = MagicMock()
    resp.status = status
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


def _urlopen_sequence(*responses: Any):
    """Return a MagicMock that yields responses in order per call."""
    mock = MagicMock(side_effect=responses)
    return mock


def _setenv_valid(monkeypatch: pytest.MonkeyPatch) -> None:
    """Set OLLAMA_API_KEY and unset ANTHROPIC_BASE_URL."""
    monkeypatch.setenv("OLLAMA_API_KEY", "fake-token")
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)


# ---------------------------------------------------------------------------
# OLLAMA_API_KEY check
# ---------------------------------------------------------------------------


class TestOllamaApiKeyCheck:
    def test_missing_ollama_api_key_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Preflight aborts naming OLLAMA_API_KEY when the var is unset."""
        monkeypatch.delenv("OLLAMA_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)

        with pytest.raises(PreflightError, match="OLLAMA_API_KEY"):
            run_ollama_preflight()

    def test_empty_ollama_api_key_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Preflight aborts when OLLAMA_API_KEY is the empty string."""
        monkeypatch.setenv("OLLAMA_API_KEY", "")
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)

        with pytest.raises(PreflightError, match="OLLAMA_API_KEY"):
            run_ollama_preflight()

    def test_env_var_check_runs_before_network_probe(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Missing OLLAMA_API_KEY raises before any HTTP call is made."""
        monkeypatch.delenv("OLLAMA_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)

        with patch("code_generator.preflight.urlopen") as mock_open:
            with pytest.raises(PreflightError):
                run_ollama_preflight()
            mock_open.assert_not_called()


# ---------------------------------------------------------------------------
# ANTHROPIC_BASE_URL check
# ---------------------------------------------------------------------------


class TestAnthropicBaseUrlCheck:
    def test_non_localhost_base_url_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Preflight aborts when ANTHROPIC_BASE_URL is pre-set off-localhost."""
        monkeypatch.setenv("OLLAMA_API_KEY", "fake-token")
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://evil.example.com")

        with pytest.raises(
            PreflightError, match="ANTHROPIC_BASE_URL must equal http://localhost:11434"
        ):
            run_ollama_preflight()

    def test_unset_base_url_does_not_raise_for_this_check(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Unset ANTHROPIC_BASE_URL is accepted (env.py pins it before dispatch)."""
        monkeypatch.setenv("OLLAMA_API_KEY", "fake-token")
        monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)

        with patch("code_generator.preflight.urlopen", return_value=_ok_response(200)):
            run_ollama_preflight(check_signin=False)  # must not raise on the URL check

    def test_matching_base_url_is_accepted(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Pre-set ANTHROPIC_BASE_URL matching the pinned value passes."""
        monkeypatch.setenv("OLLAMA_API_KEY", "fake-token")
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://localhost:11434")

        with patch("code_generator.preflight.urlopen", return_value=_ok_response(200)):
            run_ollama_preflight(check_signin=False)  # must not raise

    def test_base_url_check_runs_before_network_probe(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A mismatched ANTHROPIC_BASE_URL aborts before any HTTP call."""
        monkeypatch.setenv("OLLAMA_API_KEY", "fake-token")
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com")

        with patch("code_generator.preflight.urlopen") as mock_open:
            with pytest.raises(PreflightError, match="ANTHROPIC_BASE_URL"):
                run_ollama_preflight()
            mock_open.assert_not_called()


# ---------------------------------------------------------------------------
# Daemon reachability probe
# ---------------------------------------------------------------------------


class TestDaemonReachabilityProbe:
    def test_daemon_unreachable_urlerror_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """URLError from /api/tags → PreflightError "Ollama daemon unreachable"."""
        _setenv_valid(monkeypatch)

        with patch(
            "code_generator.preflight.urlopen",
            side_effect=URLError("connection refused"),
        ):
            with pytest.raises(PreflightError, match="Ollama daemon unreachable"):
                run_ollama_preflight()

    def test_daemon_non_200_status_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Non-200 HTTP status from /api/tags → PreflightError."""
        _setenv_valid(monkeypatch)

        with patch(
            "code_generator.preflight.urlopen",
            return_value=_ok_response(500),
        ):
            with pytest.raises(PreflightError, match="Ollama daemon unreachable"):
                run_ollama_preflight()

    def test_daemon_timeout_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """A TimeoutError from the probe surfaces as daemon unreachable."""
        _setenv_valid(monkeypatch)

        with patch("code_generator.preflight.urlopen", side_effect=TimeoutError("timed out")):
            with pytest.raises(PreflightError, match="Ollama daemon unreachable"):
                run_ollama_preflight()

    def test_probe_uses_2s_timeout(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """urlopen is called with timeout=2 on the tags probe."""
        _setenv_valid(monkeypatch)

        with patch(
            "code_generator.preflight.urlopen",
            return_value=_ok_response(200),
        ) as mock_open:
            run_ollama_preflight(check_signin=False)
            # First positional arg is URL, 'timeout' kwarg should be 2.
            _, kwargs = mock_open.call_args_list[0]
            assert kwargs["timeout"] == 2

    def test_probe_targets_api_tags(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """The probe hits /api/tags on the pinned localhost URL."""
        _setenv_valid(monkeypatch)

        with patch(
            "code_generator.preflight.urlopen",
            return_value=_ok_response(200),
        ) as mock_open:
            run_ollama_preflight(check_signin=False)
            # First arg of first call is the Request/URL.
            first_call = mock_open.call_args_list[0]
            url_arg = first_call.args[0]
            url_str = url_arg if isinstance(url_arg, str) else url_arg.full_url
            assert url_str == OLLAMA_TAGS_URL
            assert OLLAMA_TAGS_URL == "http://localhost:11434/api/tags"


# ---------------------------------------------------------------------------
# Signed-in probe
# ---------------------------------------------------------------------------


class TestSignedInProbe:
    def test_401_on_cloud_probe_raises_with_signin_remediation(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """HTTPError 401 on the cloud probe → PreflightError mentioning `ollama signin`."""
        _setenv_valid(monkeypatch)

        http_401 = HTTPError(
            url="http://localhost:11434/api/show",
            code=401,
            msg="Unauthorized",
            hdrs=None,  # type: ignore[arg-type]
            fp=None,
        )
        # First call (tags) → 200; second call (cloud probe) → 401
        mock = _urlopen_sequence(_ok_response(200), http_401)

        with patch("code_generator.preflight.urlopen", mock):
            with pytest.raises(PreflightError) as exc_info:
                run_ollama_preflight()

        assert "signin" in exc_info.value.fix_command
        assert exc_info.value.fix_command == OLLAMA_SIGNIN_COMMAND
        assert OLLAMA_SIGNIN_COMMAND == "ollama signin"

    def test_signed_in_allows_run(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """200 on both probes (tags + cloud show) is the happy path."""
        _setenv_valid(monkeypatch)

        mock = _urlopen_sequence(_ok_response(200), _ok_response(200))
        with patch("code_generator.preflight.urlopen", mock):
            run_ollama_preflight()  # must not raise

    def test_cloud_probe_404_is_not_signed_out(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """A 404 from the cloud probe means model-not-found (signed in), not signed-out."""
        _setenv_valid(monkeypatch)

        http_404 = HTTPError(
            url="http://localhost:11434/api/show",
            code=404,
            msg="Not Found",
            hdrs=None,  # type: ignore[arg-type]
            fp=None,
        )
        mock = _urlopen_sequence(_ok_response(200), http_404)

        with patch("code_generator.preflight.urlopen", mock):
            run_ollama_preflight()  # must not raise — 404 ≠ unauthenticated

    def test_check_signin_false_skips_signin_probe(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When check_signin=False only the tags probe fires."""
        _setenv_valid(monkeypatch)

        with patch(
            "code_generator.preflight.urlopen",
            return_value=_ok_response(200),
        ) as mock_open:
            run_ollama_preflight(check_signin=False)
            assert mock_open.call_count == 1, "Only /api/tags should be probed"


# ---------------------------------------------------------------------------
# Exit ordering smoke test
# ---------------------------------------------------------------------------


class TestOrdering:
    def test_missing_api_key_beats_missing_daemon(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """OLLAMA_API_KEY check runs before daemon probe (cheap checks first)."""
        monkeypatch.delenv("OLLAMA_API_KEY", raising=False)
        monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://localhost:11434")

        with patch(
            "code_generator.preflight.urlopen",
            side_effect=URLError("connection refused"),
        ):
            with pytest.raises(PreflightError, match="OLLAMA_API_KEY"):
                run_ollama_preflight()
