"""Unit tests for bench export subcommand.

Acceptance criteria (issue #195):
  - 3-cycle state fixture → export produces JSON with 3 cycles.
  - 12-cycle state fixture (2 truncated summaries) → 2 cycles marked truncated: true.
  - --cycles 2 → exports only the most recent 2 cycles.
  - Missing state.json → exit 2 with a helpful message.
  - --cycles 0 or negative → exit 2 with a clear message.
  - Empty state (no cycles) → valid JSON with empty cycles array.
  - --output - or omitted → prints to stdout.
  - Output file uses atomic tmp → os.replace write.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
from typer.testing import CliRunner  # noqa: F401 — used by _RUNNER

from code_generator.commands.bench_export import (
    build_cycle_report_from_state,
    build_truncated_cycle_report,
    select_cycles,
)
from code_generator.state import CycleState
from code_generator.state_retention import CycleTelemetrySummary

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_RUNNER = CliRunner()


def _make_cycle_state(name: str, cycle_id: int = 1) -> CycleState:
    return CycleState(
        id=cycle_id,
        name=name,
        milestone_number=cycle_id,
        milestone_title=name,
        status="done",
        phase=7,
        issues=[],
        commit_sha=None,
        token_usage={
            "0": _token_usage_dict(100, 20, 50, 10),
            "1": _token_usage_dict(200, 40, 100, 20),
        },
        cache_telemetry={
            "input": 300,
            "output": 60,
            "cache_read": 150,
            "cache_write": 30,
            "cache_hit_pct": 27.8,
            "wall_seconds": 15.0,
        },
    )


def _token_usage_dict(inp: int, out: int, read: int, write: int) -> dict:
    return {"input": inp, "output": out, "cache_read": read, "cache_write": write}


def _make_summary(name: str) -> CycleTelemetrySummary:
    return CycleTelemetrySummary(
        cycle_name=name,
        total_tokens=5000,
        cache_hit_pct=42.0,
        wall_seconds=90.0,
    )


def _write_state_json(tmp_path: Path, cycles: list) -> Path:
    """Write a minimal state.json containing the given cycles list."""
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    state_path = state_dir / "state.json"

    cycle_dicts = []
    for c in cycles:
        if isinstance(c, CycleTelemetrySummary):
            cycle_dicts.append(
                {
                    "kind": "summary",
                    "cycle_name": c.cycle_name,
                    "total_tokens": c.total_tokens,
                    "cache_hit_pct": c.cache_hit_pct,
                    "wall_seconds": c.wall_seconds,
                }
            )
        else:
            import dataclasses

            d = dataclasses.asdict(c)
            cycle_dicts.append(d)

    state_json = {
        "mode": "multi-cycle",
        "started_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-01-01T01:00:00Z",
        "session_mode": "shared",
        "cycles": cycle_dicts,
    }
    state_path.write_text(json.dumps(state_json, indent=2), encoding="utf-8")
    return state_path


# ---------------------------------------------------------------------------
# Unit tests: build_cycle_report_from_state
# ---------------------------------------------------------------------------


class TestBuildCycleReportFromState:
    """build_cycle_report_from_state converts CycleState to cycle report dict."""

    def test_returns_cycle_name(self) -> None:
        cycle = _make_cycle_state("Cycle-1")
        report = build_cycle_report_from_state(cycle)
        assert report["cycle_name"] == "Cycle-1"

    def test_phases_key_present(self) -> None:
        cycle = _make_cycle_state("Cycle-1")
        report = build_cycle_report_from_state(cycle)
        assert "phases" in report

    def test_phases_contain_token_usage_keys(self) -> None:
        cycle = _make_cycle_state("Cycle-1")
        report = build_cycle_report_from_state(cycle)
        assert "0" in report["phases"]
        assert "1" in report["phases"]

    def test_phase_has_required_metrics(self) -> None:
        cycle = _make_cycle_state("Cycle-1")
        report = build_cycle_report_from_state(cycle)
        phase = report["phases"]["0"]
        required = {
            "input",
            "output",
            "cache_read",
            "cache_write",
            "cache_hit_pct",
            "wall_seconds",
            "num_turns",
        }
        assert required <= set(phase.keys())

    def test_phase_exposes_num_turns_from_state_token_usage(self) -> None:
        """Issue #212: num_turns from state.TokenUsage surfaces in the phase dict."""
        from code_generator.runner.types import TokenUsage
        from code_generator.state import CycleState

        cycle = CycleState(
            id=1,
            name="Cycle-nt",
            milestone_number=1,
            milestone_title="Cycle-nt",
            status="done",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "3": TokenUsage(input=100, output=20, cache_read=50, num_turns=12),
            },
            cache_telemetry={
                "input": 100,
                "output": 20,
                "cache_read": 50,
                "cache_write": 0,
                "cache_hit_pct": 0.0,
                "wall_seconds": 1.0,
            },
        )

        report = build_cycle_report_from_state(cycle)

        assert report["phases"]["3"]["num_turns"] == 12

    def test_totals_come_from_cache_telemetry(self) -> None:
        cycle = _make_cycle_state("Cycle-1")
        report = build_cycle_report_from_state(cycle)
        assert report["totals"]["wall_seconds"] == pytest.approx(15.0)
        assert report["totals"]["cache_hit_pct"] == pytest.approx(27.8)

    def test_no_truncated_flag_on_full_cycle(self) -> None:
        cycle = _make_cycle_state("Cycle-1")
        report = build_cycle_report_from_state(cycle)
        assert "truncated" not in report


# ---------------------------------------------------------------------------
# Unit tests: build_truncated_cycle_report
# ---------------------------------------------------------------------------


class TestBuildTruncatedCycleReport:
    """build_truncated_cycle_report converts CycleTelemetrySummary to report dict."""

    def test_cycle_name_preserved(self) -> None:
        summary = _make_summary("Cycle-Old")
        report = build_truncated_cycle_report(summary)
        assert report["cycle_name"] == "Cycle-Old"

    def test_truncated_flag_is_true(self) -> None:
        summary = _make_summary("Cycle-Old")
        report = build_truncated_cycle_report(summary)
        assert report["truncated"] is True

    def test_totals_contain_retained_fields(self) -> None:
        summary = _make_summary("Cycle-Old")
        report = build_truncated_cycle_report(summary)
        totals = report["totals"]
        assert totals["total_tokens"] == 5000
        assert totals["cache_hit_pct"] == pytest.approx(42.0)
        assert totals["wall_seconds"] == pytest.approx(90.0)

    def test_no_phases_key(self) -> None:
        summary = _make_summary("Cycle-Old")
        report = build_truncated_cycle_report(summary)
        assert "phases" not in report


# ---------------------------------------------------------------------------
# Unit tests: select_cycles
# ---------------------------------------------------------------------------


class TestSelectCycles:
    """select_cycles applies --cycles N slicing to a list of cycles."""

    def test_none_returns_all(self) -> None:
        cycles = [_make_cycle_state(f"c{i}", i) for i in range(3)]
        assert select_cycles(cycles, last_n=None) == cycles

    def test_n_returns_last_n(self) -> None:
        cycles = [_make_cycle_state(f"c{i}", i) for i in range(5)]
        result = select_cycles(cycles, last_n=2)
        assert result == cycles[-2:]

    def test_n_larger_than_list_returns_all(self) -> None:
        cycles = [_make_cycle_state(f"c{i}", i) for i in range(3)]
        assert select_cycles(cycles, last_n=10) == cycles

    def test_mixed_full_and_summary_preserved(self) -> None:
        cycles = [_make_summary("old"), _make_cycle_state("new", 2)]
        result = select_cycles(cycles, last_n=1)
        assert len(result) == 1
        assert result[0] is cycles[-1]


# ---------------------------------------------------------------------------
# Integration tests via CLI (Typer CliRunner)
# ---------------------------------------------------------------------------


class TestBenchExportCli:
    """CLI-level tests for bench export."""

    def test_export_3_cycles_from_state(self, tmp_path: Path) -> None:
        """state fixture with 3 full cycles → export produces JSON with 3 cycles."""
        cycles = [_make_cycle_state(f"Cycle-{i}", i) for i in range(1, 4)]
        _write_state_json(tmp_path, cycles)

        out_file = tmp_path / "dump.json"
        result = _invoke_export(tmp_path, ["--output", str(out_file)])
        assert result.exit_code == 0, result.output
        loaded = json.loads(out_file.read_text())
        assert len(loaded["cycles"]) == 3

    def test_export_marks_truncated_cycles(self, tmp_path: Path) -> None:
        """12 cycles (2 truncated summaries) → 2 cycles carry truncated: true."""
        old = [_make_summary(f"Old-{i}") for i in range(2)]
        full = [_make_cycle_state(f"Cycle-{i}", i) for i in range(3, 13)]
        _write_state_json(tmp_path, old + full)

        out_file = tmp_path / "dump.json"
        result = _invoke_export(tmp_path, ["--output", str(out_file)])

        assert result.exit_code == 0, result.output
        loaded = json.loads(out_file.read_text())
        assert len(loaded["cycles"]) == 12

        truncated = [c for c in loaded["cycles"] if c.get("truncated")]
        assert len(truncated) == 2
        for t in truncated:
            assert t["truncated"] is True

    def test_export_cycles_n(self, tmp_path: Path) -> None:
        """--cycles 2 → exports only the most recent 2 cycles."""
        cycles = [_make_cycle_state(f"Cycle-{i}", i) for i in range(1, 6)]
        _write_state_json(tmp_path, cycles)

        out_file = tmp_path / "dump.json"
        result = _invoke_export(tmp_path, ["--cycles", "2", "--output", str(out_file)])

        assert result.exit_code == 0, result.output
        loaded = json.loads(out_file.read_text())
        assert len(loaded["cycles"]) == 2
        # Most recent 2 (index 3 and 4)
        assert loaded["cycles"][0]["cycle_name"] == "Cycle-4"
        assert loaded["cycles"][1]["cycle_name"] == "Cycle-5"

    def test_export_missing_state_exits_2(self, tmp_path: Path) -> None:
        """Missing state.json → exit 2 with helpful message."""
        result = _invoke_export(tmp_path, [])

        assert result.exit_code == 2
        assert "generate" in result.output.lower() or "state.json" in result.output.lower()

    def test_export_cycles_zero_exits_2(self, tmp_path: Path) -> None:
        """--cycles 0 → exit 2."""
        cycles = [_make_cycle_state("Cycle-1", 1)]
        _write_state_json(tmp_path, cycles)

        result = _invoke_export(tmp_path, ["--cycles", "0"])
        assert result.exit_code == 2

    def test_export_empty_state_yields_empty_cycles(self, tmp_path: Path) -> None:
        """Empty state.json (no cycles) → valid JSON with empty cycles array."""
        _write_state_json(tmp_path, [])

        result = _invoke_export(tmp_path, [])
        assert result.exit_code == 0
        loaded = json.loads(result.output)
        assert loaded["cycles"] == []

    def test_export_stdout_when_output_hyphen(self, tmp_path: Path) -> None:
        """--output - → prints JSON to stdout."""
        cycles = [_make_cycle_state("Cycle-1", 1)]
        _write_state_json(tmp_path, cycles)

        result = _invoke_export(tmp_path, ["--output", "-"])
        assert result.exit_code == 0
        loaded = json.loads(result.output)
        assert len(loaded["cycles"]) == 1

    def test_export_stdout_when_no_output_flag(self, tmp_path: Path) -> None:
        """Omitted --output → prints JSON to stdout."""
        cycles = [_make_cycle_state("Cycle-1", 1)]
        _write_state_json(tmp_path, cycles)

        result = _invoke_export(tmp_path, [])
        assert result.exit_code == 0
        loaded = json.loads(result.output)
        assert len(loaded["cycles"]) == 1

    def test_export_atomic_write(self, tmp_path: Path) -> None:
        """Output file is atomically written (no .tmp file left behind)."""
        cycles = [_make_cycle_state("Cycle-1", 1)]
        _write_state_json(tmp_path, cycles)

        out_file = tmp_path / "dump.json"
        result = _invoke_export(tmp_path, ["--output", str(out_file)])

        assert result.exit_code == 0
        assert out_file.exists()
        tmp_file = out_file.with_suffix(".tmp")
        assert not tmp_file.exists()

    def test_export_schema_version_present(self, tmp_path: Path) -> None:
        """Top-level JSON includes schema_version field."""
        cycles = [_make_cycle_state("Cycle-1", 1)]
        _write_state_json(tmp_path, cycles)

        result = _invoke_export(tmp_path, [])
        assert result.exit_code == 0
        loaded = json.loads(result.output)
        assert "schema_version" in loaded
        assert "timestamp_utc" in loaded


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _invoke_export(cwd: Path, extra_args: list[str]):
    """Invoke `bench export` with cwd as the working directory."""
    from code_generator.cli import app

    original_cwd = os.getcwd()
    try:
        os.chdir(cwd)
        return _RUNNER.invoke(app, ["bench", "export"] + extra_args, catch_exceptions=False)
    finally:
        os.chdir(original_cwd)
