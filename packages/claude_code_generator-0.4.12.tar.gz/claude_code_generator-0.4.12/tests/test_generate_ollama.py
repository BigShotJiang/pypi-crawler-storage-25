"""Tests for the ``code-generator generate ollama`` Typer subcommand (#218).

TDD: Red → Green.

The subcommand registers under the ``generate`` sub-app so ``generate`` keeps
working flatly (``code-generator generate``) while also exposing
``code-generator generate ollama --model <tag>``.

All network I/O is mocked — the tests verify wiring, not real HTTP calls.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

import pytest
from typer.testing import CliRunner

from code_generator import state as state_module
from code_generator.cli import app
from code_generator.env import DANGEROUS_VARS

if TYPE_CHECKING:
    from pathlib import Path


runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Strip dangerous vars and provide a default OLLAMA_API_KEY for tests."""
    for var in DANGEROUS_VARS:
        monkeypatch.delenv(var, raising=False)
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
    monkeypatch.setenv("OLLAMA_API_KEY", "fake-ollama-token")


def _make_cg_dir(tmp_path: Path) -> Path:
    """Create a minimal .code-generator/ directory with an initial state file."""
    cg = tmp_path / ".code-generator"
    cg.mkdir()
    st = state_module.load_state(cg / "missing.json")
    state_module.save_state(cg / "state.json", st)
    return cg


def _patch_subcommand_wiring(monkeypatch: pytest.MonkeyPatch) -> dict[str, list]:
    """Patch the Ollama subcommand's side-effect seams and record call order.

    Returns a dict that records: preflight_calls, env_calls, dispatch_calls.
    """
    import code_generator.commands.generate as gen_mod

    call_order: list[str] = []
    preflight_calls: list[tuple] = []
    env_calls: list[str] = []
    dispatch_calls: list[dict] = []

    def _fake_preflight(*, check_signin: bool = True) -> None:
        call_order.append("preflight")
        preflight_calls.append((check_signin,))

    def _fake_build_env(provider: str = "anthropic-max") -> dict:
        call_order.append("build_env")
        env_calls.append(provider)
        return {"ANTHROPIC_AUTH_TOKEN": "x", "ANTHROPIC_BASE_URL": "http://localhost:11434"}

    def _fake_dispatch(st, project_dir, **kw) -> None:
        call_order.append("dispatch")
        dispatch_calls.append(kw)

    # Also patch preflight so GitHub preflight is a no-op.
    from code_generator.repo_info import RepoInfo

    monkeypatch.setattr(
        gen_mod.preflight_module,
        "run_preflight",
        lambda _: RepoInfo(host="github.com", owner="o", name="r"),
    )
    monkeypatch.setattr(gen_mod.preflight_module, "run_ollama_preflight", _fake_preflight)
    monkeypatch.setattr(gen_mod.env, "build_agent_env", _fake_build_env)
    monkeypatch.setattr(gen_mod, "dispatch_orchestrator", _fake_dispatch)

    return {
        "call_order": call_order,
        "preflight_calls": preflight_calls,
        "env_calls": env_calls,
        "dispatch_calls": dispatch_calls,
    }


# ---------------------------------------------------------------------------
# Help text + required flag
# ---------------------------------------------------------------------------


class TestHelpAndRequiredModelFlag:
    def test_ollama_help_mentions_model_required(self) -> None:
        """``generate ollama --help`` advertises --model and names it required."""
        result = runner.invoke(app, ["generate", "ollama", "--help"])
        assert result.exit_code == 0, result.output
        output = result.output + (result.stderr or "")
        assert "--model" in output
        # Typer marks REQUIRED options either with the literal word or a star.
        assert "required" in output.lower() or "*" in output

    def test_ollama_help_documents_single_model_drives_every_phase(self) -> None:
        """Help text mentions that the model applies to every phase."""
        result = runner.invoke(app, ["generate", "ollama", "--help"])
        output = result.output + (result.stderr or "")
        assert "phase" in output.lower()

    def test_missing_model_flag_exits_nonzero(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``generate ollama`` without --model exits non-zero."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        result = runner.invoke(app, ["generate", "ollama"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Rejected flags
# ---------------------------------------------------------------------------


class TestRejectedFlags:
    def test_provider_flag_is_rejected(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--provider is not a known flag — Typer exits non-zero."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        result = runner.invoke(
            app,
            ["generate", "ollama", "--model", "qwen3-coder:480b:cloud", "--provider", "anthropic"],
        )
        assert result.exit_code != 0

    def test_opus_model_override_flag_is_rejected(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Per-phase model override (e.g. --opus-model) is not accepted."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        result = runner.invoke(
            app,
            ["generate", "ollama", "--model", "qwen", "--opus-model", "claude-opus-4-7"],
        )
        assert result.exit_code != 0

    def test_session_mode_batch_is_rejected(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--session-mode batch is not allowed on the Ollama path (no batch API)."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        _patch_subcommand_wiring(monkeypatch)
        result = runner.invoke(
            app, ["generate", "ollama", "--model", "qwen", "--session-mode", "batch"]
        )
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Wiring — preflight → env → dispatch order and arguments
# ---------------------------------------------------------------------------


class TestCallOrdering:
    def test_preflight_runs_before_env_build_and_dispatch(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """run_ollama_preflight fires before build_agent_env and dispatch."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        captured = _patch_subcommand_wiring(monkeypatch)

        result = runner.invoke(app, ["generate", "ollama", "--model", "qwen3-coder:480b:cloud"])
        assert result.exit_code == 0, result.output

        order = captured["call_order"]
        assert order.index("preflight") < order.index("build_env")
        assert order.index("build_env") < order.index("dispatch")

    def test_build_agent_env_called_with_ollama_provider(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """build_agent_env receives provider='ollama' when the subcommand runs."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        captured = _patch_subcommand_wiring(monkeypatch)

        result = runner.invoke(app, ["generate", "ollama", "--model", "qwen3-coder:480b:cloud"])
        assert result.exit_code == 0, result.output
        assert captured["env_calls"] == ["ollama"]


# ---------------------------------------------------------------------------
# State persistence — --model stamp on existing cycles
# ---------------------------------------------------------------------------


class TestStatePersistence:
    def test_model_persisted_on_existing_cycle_before_dispatch(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """An existing CycleState has its ollama_model populated before dispatch."""
        monkeypatch.chdir(tmp_path)
        cg = _make_cg_dir(tmp_path)
        _patch_subcommand_wiring(monkeypatch)

        # Pre-load state with one cycle (no ollama_model set).
        state_path = cg / "state.json"
        st = state_module.load_state(state_path)
        st.cycles = [
            state_module.CycleState(
                id=1,
                name="c1",
                milestone_number=1,
                milestone_title="c1",
                status="open",
                phase=None,
                issues=[],
                commit_sha=None,
            )
        ]
        state_module.save_state(state_path, st)

        result = runner.invoke(app, ["generate", "ollama", "--model", "qwen3-coder:480b:cloud"])
        assert result.exit_code == 0, result.output

        persisted = json.loads(state_path.read_text(encoding="utf-8"))
        assert persisted["cycles"][0]["ollama_model"] == "qwen3-coder:480b:cloud"


# ---------------------------------------------------------------------------
# Regression — the default generate path is unchanged
# ---------------------------------------------------------------------------


class TestDefaultGenerateUnchanged:
    def test_help_for_generate_shows_parent_flags(self) -> None:
        """``generate --help`` still lists the flags owned by the default callback."""
        result = runner.invoke(app, ["generate", "--help"])
        assert result.exit_code == 0, result.output
        output = result.output + (result.stderr or "")
        assert "--continue" in output or "continue" in output.lower()
        assert "--phase" in output
        assert "--dry-run" in output

    def test_generate_without_subcommand_still_exits_1_without_cg_dir(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Default generate path still exits 1 when .code-generator is missing."""
        monkeypatch.chdir(tmp_path)
        # Note: no _make_cg_dir() here.
        result = runner.invoke(app, ["generate"])
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# Inherited flag threading
# ---------------------------------------------------------------------------


class TestInheritedFlags:
    def test_max_turns_threaded_to_dispatch(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--max-turns on the Ollama subcommand reaches dispatch_orchestrator."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        captured = _patch_subcommand_wiring(monkeypatch)

        result = runner.invoke(
            app,
            ["generate", "ollama", "--model", "qwen", "--max-turns", "42"],
        )
        assert result.exit_code == 0, result.output
        assert captured["dispatch_calls"][0]["max_turns"] == 42

    def test_continue_flag_threaded_to_dispatch(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue on the Ollama subcommand reaches dispatch_orchestrator."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        captured = _patch_subcommand_wiring(monkeypatch)

        result = runner.invoke(app, ["generate", "ollama", "--model", "qwen", "--continue"])
        assert result.exit_code == 0, result.output
        assert captured["dispatch_calls"][0]["continue_"] is True

    def test_session_mode_shared_threaded_to_dispatch(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--session-mode shared is accepted and forwarded."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        captured = _patch_subcommand_wiring(monkeypatch)

        result = runner.invoke(
            app, ["generate", "ollama", "--model", "qwen", "--session-mode", "shared"]
        )
        assert result.exit_code == 0, result.output
        assert captured["dispatch_calls"][0]["session_mode"] == "shared"

    def test_session_mode_fresh_accepted(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--session-mode fresh is accepted."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)
        captured = _patch_subcommand_wiring(monkeypatch)

        result = runner.invoke(
            app, ["generate", "ollama", "--model", "qwen", "--session-mode", "fresh"]
        )
        assert result.exit_code == 0, result.output
        assert captured["dispatch_calls"][0]["session_mode"] == "fresh"
