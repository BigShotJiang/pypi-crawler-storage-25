"""Tests for shared-client lifecycle wiring in cycle_loop (Issue #182).

Covers:
- _open_cycle_client: returns a ClaudeSDKClient async context manager.
- managed_shared_client: async CM owning mark/clear lifecycle.
- _run_cycle_phases: shared mode uses managed_shared_client; fresh skips it.
- _run_phases threading: shared_client forwarded to phases 2/3/4/5 only.
"""

from __future__ import annotations

import contextlib
import logging
from contextlib import ExitStack
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import cycle_loop
from code_generator.orchestrator._client_lifecycle import (
    _build_cycle_options,
    _open_cycle_client,
    managed_shared_client,
)

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _make_logger() -> logging.Logger:
    return logging.getLogger("test.client_lifecycle")


def _make_state(tmp_path: Path, session_mode: str = "shared") -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.State(
        mode="multi-cycle",  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        session_mode=session_mode,  # type: ignore[arg-type]
    )
    _state.save_state(state_dir / "state.json", st)
    return st


def _make_cycle(cycle_id: int = 1) -> _state.CycleState:
    return _state.CycleState(
        id=cycle_id,
        name=f"Cycle {cycle_id}",
        milestone_number=None,
        milestone_title=f"Milestone {cycle_id}",
        status="open",
        phase=0,
        issues=[],
        commit_sha=None,
        depends_on=[],
    )


def _make_async_cm(return_value: object = None) -> MagicMock:
    """Return a MagicMock that behaves as an async context manager."""
    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=return_value)
    cm.__aexit__ = AsyncMock(return_value=False)
    return cm


def _patch_all_phases(
    *,
    p5_new_issues: bool = False,
    phase3_raises: Exception | None = None,
) -> dict:
    """Return a dict of phase-name → AsyncMock for patching."""
    from code_generator.orchestrator import phase5_closure

    async def _p3(*args, **kwargs):
        if phase3_raises is not None:
            raise phase3_raises

    mocks: dict = {
        "phase3_4_implement": AsyncMock(side_effect=_p3 if phase3_raises else None),
        "phase5_closure": AsyncMock(
            return_value=phase5_closure.FixResult(
                new_issues=[_state.IssueState(number=99, status="open", agent="python-pro")]
                if p5_new_issues
                else []
            )
        ),
        "phase1_plan": AsyncMock(return_value=None),
        "phase2_review": AsyncMock(return_value=None),
        "phase6_test": AsyncMock(return_value=None),
        "phase7_commit": AsyncMock(return_value=None),
    }
    return mocks


@contextlib.contextmanager
def _standard_phase_context(mocks: dict, *extra_patches):
    """Context manager that patches all phase.run functions plus any extras."""
    base = [
        patch.object(cycle_loop.phase1_plan, "run", mocks["phase1_plan"]),
        patch.object(cycle_loop.phase2_review, "run", mocks["phase2_review"]),
        patch.object(cycle_loop.phase3_4_implement, "run", mocks["phase3_4_implement"]),
        patch.object(cycle_loop.phase5_closure, "run", mocks["phase5_closure"]),
        patch.object(cycle_loop.phase6_test, "run", mocks["phase6_test"]),
        patch.object(cycle_loop.phase7_commit, "run", mocks["phase7_commit"]),
        patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        *extra_patches,
    ]
    with ExitStack() as stack:
        for p in base:
            stack.enter_context(p)
        yield


# ---------------------------------------------------------------------------
# _open_cycle_client unit tests
# ---------------------------------------------------------------------------


class TestOpenCycleClient:
    def test_returns_claude_sdk_client_instance_when_sdk_available(self) -> None:
        """_open_cycle_client returns ClaudeSDKClient(options=template) when SDK present."""
        mock_cls = MagicMock(name="ClaudeSDKClient")
        mock_options = MagicMock(name="options_template")

        with (
            patch(
                "code_generator.orchestrator._client_lifecycle.ClaudeSDKClient",
                mock_cls,
            ),
            patch(
                "code_generator.orchestrator._client_lifecycle._SDK_AVAILABLE",
                True,
            ),
        ):
            result = _open_cycle_client(mock_options)

        mock_cls.assert_called_once_with(options=mock_options)
        assert result is mock_cls.return_value

    def test_raises_runtime_error_when_sdk_unavailable(self) -> None:
        """_open_cycle_client raises RuntimeError when claude_agent_sdk is not installed."""
        with (
            patch(
                "code_generator.orchestrator._client_lifecycle._SDK_AVAILABLE",
                False,
            ),
            patch(
                "code_generator.orchestrator._client_lifecycle.ClaudeSDKClient",
                None,
            ),
        ):
            with pytest.raises(RuntimeError, match="claude_agent_sdk"):
                _open_cycle_client(MagicMock())


# ---------------------------------------------------------------------------
# _build_cycle_options invariants (regression guard — issue from 2026-04-17)
# ---------------------------------------------------------------------------


class TestBuildCycleOptions:
    """The shared-client options template MUST set the fields the SDK locks at
    open-time. Omitting any of these produces silent permission-denied failures
    across every phase (Phase 2 review burned ~400k tokens/issue asking the
    orchestrator for `gh issue view` approval before this was fixed).
    """

    def test_permission_mode_is_bypass_permissions(self, tmp_path: Path) -> None:
        """Non-negotiable #3 — shared client must open with bypassPermissions."""
        opts = _build_cycle_options(tmp_path)
        assert opts.permission_mode == "bypassPermissions"

    def test_allowed_tools_contains_phase_3_4_superset(self, tmp_path: Path) -> None:
        """Shared client must allow every tool any phase uses; Phase 3/4 is the widest."""
        opts = _build_cycle_options(tmp_path)
        for tool in ("Read", "Edit", "Write", "Bash", "Glob", "Grep"):
            assert tool in opts.allowed_tools, (
                f"{tool} missing from shared-client allowed_tools; "
                f"phase needing it would get silent permission denial"
            )

    def test_mcp_servers_resolved_from_project_dir(self, tmp_path: Path) -> None:
        """build_mcp_servers must be called with project_dir so MCP tools register."""
        with patch(
            "code_generator.orchestrator._client_lifecycle.build_mcp_servers",
            return_value={"codebase_memory": {}},
        ) as mock_build:
            opts = _build_cycle_options(tmp_path)
        mock_build.assert_called_once_with(tmp_path)
        assert opts.mcp_servers == {"codebase_memory": {}}


# ---------------------------------------------------------------------------
# managed_shared_client unit tests
# ---------------------------------------------------------------------------


class TestManagedSharedClient:
    """Tests for the managed_shared_client context manager in _client_lifecycle."""

    def _lifecycle_patches(self, mock_client: MagicMock):
        """Return a tuple of patches that isolate managed_shared_client."""
        mock_cm = _make_async_cm(return_value=mock_client)
        return (
            patch("code_generator.orchestrator._client_lifecycle._env.strip_dangerous_env"),
            patch(
                "code_generator.orchestrator._client_lifecycle._build_cycle_options",
                return_value=MagicMock(),
            ),
            patch(
                "code_generator.orchestrator._client_lifecycle._open_cycle_client",
                return_value=mock_cm,
            ),
        )

    @pytest.mark.asyncio
    async def test_mark_called_before_yield_on_entry(self, tmp_path: Path) -> None:
        """mark_client_alive is called before yielding the client."""
        st = _make_state(tmp_path)
        state_path = tmp_path / ".code-generator" / "state.json"
        mock_client = MagicMock()
        env_p, opts_p, open_p = self._lifecycle_patches(mock_client)

        received: list[object] = []

        with (
            env_p,
            opts_p,
            open_p,
            patch("code_generator.orchestrator._client_lifecycle._state.mark_client_alive"),
            patch("code_generator.orchestrator._client_lifecycle._state.clear_client_alive"),
        ):
            async with managed_shared_client(st, state_path) as client:
                received.append(client)

        assert received == [mock_client]

    @pytest.mark.asyncio
    async def test_clear_called_on_clean_exit(self, tmp_path: Path) -> None:
        """clear_client_alive is called exactly once on clean exit."""
        st = _make_state(tmp_path)
        state_path = tmp_path / ".code-generator" / "state.json"
        env_p, opts_p, open_p = self._lifecycle_patches(MagicMock())

        with (
            env_p,
            opts_p,
            open_p,
            patch("code_generator.orchestrator._client_lifecycle._state.mark_client_alive"),
            patch(
                "code_generator.orchestrator._client_lifecycle._state.clear_client_alive"
            ) as mock_clear,
        ):
            async with managed_shared_client(st, state_path):
                pass

        mock_clear.assert_called_once()

    @pytest.mark.asyncio
    async def test_clear_not_called_on_exception(self, tmp_path: Path) -> None:
        """clear_client_alive is NOT called when the body raises."""
        st = _make_state(tmp_path)
        state_path = tmp_path / ".code-generator" / "state.json"
        env_p, opts_p, open_p = self._lifecycle_patches(MagicMock())

        cleared: list[bool] = []

        with (
            env_p,
            opts_p,
            open_p,
            patch("code_generator.orchestrator._client_lifecycle._state.mark_client_alive"),
            patch(
                "code_generator.orchestrator._client_lifecycle._state.clear_client_alive",
                side_effect=lambda *_: cleared.append(True),
            ),
        ):
            with pytest.raises(ValueError, match="boom"):
                async with managed_shared_client(st, state_path):
                    raise ValueError("boom")

        assert cleared == [], "clear_client_alive must NOT be called on exception"

    @pytest.mark.asyncio
    async def test_mark_clear_sequence_on_clean_exit(self, tmp_path: Path) -> None:
        """mark_client_alive is called before yield; clear after clean exit."""
        st = _make_state(tmp_path)
        state_path = tmp_path / ".code-generator" / "state.json"
        env_p, opts_p, open_p = self._lifecycle_patches(MagicMock())

        call_sequence: list[str] = []

        with (
            env_p,
            opts_p,
            open_p,
            patch(
                "code_generator.orchestrator._client_lifecycle._state.mark_client_alive",
                side_effect=lambda *_: call_sequence.append("mark"),
            ),
            patch(
                "code_generator.orchestrator._client_lifecycle._state.clear_client_alive",
                side_effect=lambda *_: call_sequence.append("clear"),
            ),
        ):
            async with managed_shared_client(st, state_path):
                pass

        assert call_sequence == ["mark", "clear"]


# ---------------------------------------------------------------------------
# _run_cycle_phases lifecycle — shared mode
# ---------------------------------------------------------------------------


class TestRunCyclePhasesSharedMode:
    @pytest.mark.asyncio
    async def test_shared_mode_invokes_managed_shared_client_once(self, tmp_path: Path) -> None:
        """Shared mode: managed_shared_client called exactly once per cycle."""
        st = _make_state(tmp_path, session_mode="shared")
        cycle = _make_cycle()
        mocks = _patch_all_phases()

        mock_client = MagicMock()
        mock_cm = _make_async_cm(return_value=mock_client)
        mock_managed = MagicMock(return_value=mock_cm)

        with _standard_phase_context(
            mocks,
            patch.object(cycle_loop, "managed_shared_client", mock_managed),
        ):
            await cycle_loop._run_cycle_phases(
                state=st,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=MagicMock(),
                log=_make_logger(),
                start_phase=1,
            )

        mock_managed.assert_called_once()

    @pytest.mark.asyncio
    async def test_exception_propagates_from_shared_mode(self, tmp_path: Path) -> None:
        """Exception inside lifecycle block propagates to caller."""
        st = _make_state(tmp_path, session_mode="shared")
        cycle = _make_cycle()

        class _PhaseError(Exception):
            pass

        mocks = _patch_all_phases(phase3_raises=_PhaseError("boom"))
        mock_client = MagicMock()
        mock_cm = _make_async_cm(return_value=mock_client)
        mock_managed = MagicMock(return_value=mock_cm)

        with _standard_phase_context(
            mocks,
            patch.object(cycle_loop, "managed_shared_client", mock_managed),
        ):
            with pytest.raises(_PhaseError, match="boom"):
                await cycle_loop._run_cycle_phases(
                    state=st,
                    cycle=cycle,
                    project_dir=tmp_path,
                    runner_module=MagicMock(),
                    log=_make_logger(),
                    start_phase=1,
                )


# ---------------------------------------------------------------------------
# _run_cycle_phases lifecycle — fresh mode
# ---------------------------------------------------------------------------


class TestRunCyclePhasesFreshMode:
    @pytest.mark.asyncio
    async def test_fresh_mode_does_not_invoke_managed_shared_client(self, tmp_path: Path) -> None:
        """Fresh mode: managed_shared_client is never called."""
        st = _make_state(tmp_path, session_mode="fresh")
        cycle = _make_cycle()
        mocks = _patch_all_phases()
        mock_managed = MagicMock()

        with _standard_phase_context(
            mocks,
            patch.object(cycle_loop, "managed_shared_client", mock_managed),
        ):
            await cycle_loop._run_cycle_phases(
                state=st,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=MagicMock(),
                log=_make_logger(),
                start_phase=1,
            )

        mock_managed.assert_not_called()

    @pytest.mark.asyncio
    async def test_fresh_mode_phases_receive_none_client(self, tmp_path: Path) -> None:
        """Fresh mode: phases 2/3/5 receive shared_client=None."""
        st = _make_state(tmp_path, session_mode="fresh")
        cycle = _make_cycle()
        mocks = _patch_all_phases()

        with _standard_phase_context(
            mocks,
            patch.object(cycle_loop, "managed_shared_client", MagicMock()),
        ):
            await cycle_loop._run_cycle_phases(
                state=st,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=MagicMock(),
                log=_make_logger(),
                start_phase=1,
            )

        assert mocks["phase2_review"].call_args.kwargs.get("shared_client") is None
        assert mocks["phase3_4_implement"].call_args.kwargs.get("shared_client") is None
        assert mocks["phase5_closure"].call_args.kwargs.get("shared_client") is None


# ---------------------------------------------------------------------------
# _run_phases — shared_client threading
# ---------------------------------------------------------------------------


class TestRunPhasesSharedClientThreading:
    """_run_phases threads shared_client to phases 2/3/4/5 and omits it from 1/6/7."""

    @pytest.mark.asyncio
    async def test_phase2_receives_shared_client(self, tmp_path: Path) -> None:
        """phase2_review.run is called with shared_client kwarg."""
        st = _make_state(tmp_path)
        sentinel_client = object()
        mocks = _patch_all_phases()

        with _standard_phase_context(mocks):
            await cycle_loop._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=sentinel_client,
            )

        assert mocks["phase2_review"].call_args.kwargs.get("shared_client") is sentinel_client

    @pytest.mark.asyncio
    async def test_phase3_4_receives_shared_client(self, tmp_path: Path) -> None:
        """phase3_4_implement.run is called with shared_client kwarg."""
        st = _make_state(tmp_path)
        sentinel_client = object()
        mocks = _patch_all_phases()

        with _standard_phase_context(mocks):
            await cycle_loop._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=sentinel_client,
            )

        assert mocks["phase3_4_implement"].call_args.kwargs.get("shared_client") is sentinel_client

    @pytest.mark.asyncio
    async def test_phase5_receives_shared_client(self, tmp_path: Path) -> None:
        """phase5_closure.run is called with shared_client kwarg."""
        st = _make_state(tmp_path)
        sentinel_client = object()
        mocks = _patch_all_phases()

        with _standard_phase_context(mocks):
            await cycle_loop._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=sentinel_client,
            )

        assert mocks["phase5_closure"].call_args.kwargs.get("shared_client") is sentinel_client

    @pytest.mark.asyncio
    async def test_phase1_does_not_receive_shared_client(self, tmp_path: Path) -> None:
        """phase1_plan.run is NOT called with shared_client kwarg."""
        st = _make_state(tmp_path)
        mocks = _patch_all_phases()

        with _standard_phase_context(mocks):
            await cycle_loop._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=object(),
            )

        assert "shared_client" not in mocks["phase1_plan"].call_args.kwargs

    @pytest.mark.asyncio
    async def test_phase6_does_not_receive_shared_client(self, tmp_path: Path) -> None:
        """phase6_test.run is NOT called with shared_client kwarg."""
        st = _make_state(tmp_path)
        mocks = _patch_all_phases()

        with _standard_phase_context(mocks):
            await cycle_loop._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=object(),
            )

        assert "shared_client" not in mocks["phase6_test"].call_args.kwargs

    @pytest.mark.asyncio
    async def test_phase7_does_not_receive_shared_client(self, tmp_path: Path) -> None:
        """phase7_commit.run is NOT called with shared_client kwarg."""
        st = _make_state(tmp_path)
        mocks = _patch_all_phases()

        with _standard_phase_context(mocks):
            await cycle_loop._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=object(),
            )

        assert "shared_client" not in mocks["phase7_commit"].call_args.kwargs

    @pytest.mark.asyncio
    async def test_none_client_threads_none_to_phases_2_3_5(self, tmp_path: Path) -> None:
        """When shared_client=None (fresh mode), phases 2/3/5 receive None."""
        st = _make_state(tmp_path)
        mocks = _patch_all_phases()

        with _standard_phase_context(mocks):
            await cycle_loop._run_phases(
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
                shared_client=None,
            )

        assert mocks["phase2_review"].call_args.kwargs.get("shared_client") is None
        assert mocks["phase3_4_implement"].call_args.kwargs.get("shared_client") is None
        assert mocks["phase5_closure"].call_args.kwargs.get("shared_client") is None
