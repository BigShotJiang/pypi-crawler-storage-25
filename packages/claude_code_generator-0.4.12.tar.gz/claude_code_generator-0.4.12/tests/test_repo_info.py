"""Tests for code_generator.repo_info.

TDD: tests are written before the implementation (Red → Green → Refactor).
All 7 acceptance criteria from issue #147 are covered.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from code_generator.repo_info import RepoInfo, parse_remote_url, resolve_ssh_alias

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SSH_CONFIG_CONTENT = """\
Host ey
    HostName github.ey.com
    User git
    IdentityFile ~/.ssh/id_rsa_ey

Host ghes-corp
    HostName ghes.corp.internal
    User git

Host *
    ServerAliveInterval 60
"""


@pytest.fixture()
def ssh_config(tmp_path: Path) -> Path:
    """Write a minimal SSH config with known aliases and return its path."""
    p = tmp_path / "ssh_config"
    p.write_text(SSH_CONFIG_CONTENT, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# RepoInfo dataclass
# ---------------------------------------------------------------------------


class TestRepoInfo:
    def test_is_immutable(self) -> None:
        """frozen=True means attributes cannot be reassigned after creation."""
        info = RepoInfo(host="github.com", owner="acme", name="widget")
        with pytest.raises(AttributeError):
            info.host = "other.host"  # type: ignore[misc]

    def test_full_is_computed_from_owner_and_name(self) -> None:
        info = RepoInfo(host="github.com", owner="acme", name="widget")
        assert info.full == "acme/widget"

    def test_equality_based_on_all_fields(self) -> None:
        a = RepoInfo(host="github.com", owner="acme", name="widget")
        b = RepoInfo(host="github.com", owner="acme", name="widget")
        assert a == b

    def test_inequality_when_host_differs(self) -> None:
        a = RepoInfo(host="github.com", owner="acme", name="widget")
        b = RepoInfo(host="ghes.corp.com", owner="acme", name="widget")
        assert a != b

    def test_full_not_a_constructor_argument(self) -> None:
        """full is derived — it should not be accepted as a positional arg."""
        info = RepoInfo(host="github.com", owner="acme", name="widget")
        assert info.full == "acme/widget"

    def test_hashable(self) -> None:
        """Frozen dataclasses must be hashable (usable as dict keys/set members)."""
        info = RepoInfo(host="github.com", owner="acme", name="widget")
        assert hash(info) is not None
        assert {info}  # can be placed in a set


# ---------------------------------------------------------------------------
# resolve_ssh_alias
# ---------------------------------------------------------------------------


class TestResolveSshAlias:
    def test_returns_real_hostname_for_known_alias(self, ssh_config: Path) -> None:
        assert resolve_ssh_alias("ey", ssh_config) == "github.ey.com"

    def test_returns_second_alias(self, ssh_config: Path) -> None:
        assert resolve_ssh_alias("ghes-corp", ssh_config) == "ghes.corp.internal"

    def test_returns_alias_unchanged_when_not_found(self, ssh_config: Path) -> None:
        assert resolve_ssh_alias("unknown-alias", ssh_config) == "unknown-alias"

    def test_returns_alias_unchanged_when_file_missing(self, tmp_path: Path) -> None:
        missing = tmp_path / "no_such_file"
        assert resolve_ssh_alias("ey", missing) == "ey"

    def test_wildcard_host_not_resolved(self, ssh_config: Path) -> None:
        """Host * stanzas must not be treated as alias matches."""
        assert resolve_ssh_alias("*", ssh_config) == "*"

    def test_does_not_match_partial_alias(self, ssh_config: Path) -> None:
        """'e' should not match the 'ey' stanza."""
        assert resolve_ssh_alias("e", ssh_config) == "e"


# ---------------------------------------------------------------------------
# parse_remote_url — GitHub.com HTTPS
# ---------------------------------------------------------------------------


class TestParseRemoteUrlGithubHttps:
    def test_basic_https_url(self, ssh_config: Path) -> None:
        info = parse_remote_url("https://github.com/acme/widget", ssh_config)
        assert info == RepoInfo(host="github.com", owner="acme", name="widget")

    def test_https_url_with_git_suffix(self, ssh_config: Path) -> None:
        info = parse_remote_url("https://github.com/acme/widget.git", ssh_config)
        assert info == RepoInfo(host="github.com", owner="acme", name="widget")

    def test_https_url_without_git_suffix(self, ssh_config: Path) -> None:
        info = parse_remote_url("https://github.com/acme/widget", ssh_config)
        assert info.name == "widget"

    def test_https_full_field(self, ssh_config: Path) -> None:
        info = parse_remote_url("https://github.com/acme/widget.git", ssh_config)
        assert info.full == "acme/widget"


# ---------------------------------------------------------------------------
# parse_remote_url — GitHub.com SSH
# ---------------------------------------------------------------------------


class TestParseRemoteUrlGithubSsh:
    def test_basic_ssh_url(self, ssh_config: Path) -> None:
        info = parse_remote_url("git@github.com:acme/widget.git", ssh_config)
        assert info == RepoInfo(host="github.com", owner="acme", name="widget")

    def test_ssh_url_without_git_suffix(self, ssh_config: Path) -> None:
        info = parse_remote_url("git@github.com:acme/widget", ssh_config)
        assert info.name == "widget"

    def test_ssh_host_not_in_config_returns_literal(self, ssh_config: Path) -> None:
        """github.com is not in the fixture config → host stays as 'github.com'."""
        info = parse_remote_url("git@github.com:acme/widget.git", ssh_config)
        assert info.host == "github.com"


# ---------------------------------------------------------------------------
# parse_remote_url — GitHub Enterprise HTTPS
# ---------------------------------------------------------------------------


class TestParseRemoteUrlGhesHttps:
    def test_ghes_https_url(self, ssh_config: Path) -> None:
        info = parse_remote_url("https://github.enterprise.com/acme/widget.git", ssh_config)
        assert info.host == "github.enterprise.com"
        assert info.owner == "acme"
        assert info.name == "widget"

    def test_ghes_subdomain_host(self, ssh_config: Path) -> None:
        info = parse_remote_url("https://ghes.corp.internal/org/project", ssh_config)
        assert info.host == "ghes.corp.internal"


# ---------------------------------------------------------------------------
# parse_remote_url — SSH alias (scp-like, primary happy path)
# ---------------------------------------------------------------------------


class TestParseRemoteUrlSshAlias:
    def test_alias_scp_form_with_fixture(self, ssh_config: Path) -> None:
        """alias:owner/repo resolved via SSH config fixture."""
        info = parse_remote_url("ey:ey-org/mef-sanzioni.git", ssh_config)
        assert info == RepoInfo(host="github.ey.com", owner="ey-org", name="mef-sanzioni")

    def test_alias_scp_without_git_suffix(self, ssh_config: Path) -> None:
        info = parse_remote_url("ey:ey-org/mef-sanzioni", ssh_config)
        assert info.host == "github.ey.com"
        assert info.name == "mef-sanzioni"

    def test_git_at_alias_scp_form(self, ssh_config: Path) -> None:
        """git@ey:owner/repo — the incident URL form — resolves alias."""
        info = parse_remote_url("git@ey:ey-org/mef-sanzioni.git", ssh_config)
        assert info.host == "github.ey.com"
        assert info.owner == "ey-org"
        assert info.name == "mef-sanzioni"

    def test_ssh_uri_form_with_alias(self, ssh_config: Path) -> None:
        """ssh://alias/owner/repo resolved via SSH config."""
        info = parse_remote_url("ssh://ey/ey-org/mef-sanzioni.git", ssh_config)
        assert info.host == "github.ey.com"
        assert info.owner == "ey-org"


# ---------------------------------------------------------------------------
# parse_remote_url — .git suffix handling
# ---------------------------------------------------------------------------


class TestParseRemoteUrlGitSuffix:
    def test_trailing_git_stripped_https(self, ssh_config: Path) -> None:
        info = parse_remote_url("https://github.com/acme/widget.git", ssh_config)
        assert info.name == "widget"

    def test_missing_git_suffix_https(self, ssh_config: Path) -> None:
        info = parse_remote_url("https://github.com/acme/widget", ssh_config)
        assert info.name == "widget"

    def test_trailing_git_stripped_ssh(self, ssh_config: Path) -> None:
        info = parse_remote_url("git@github.com:acme/widget.git", ssh_config)
        assert info.name == "widget"

    def test_missing_git_suffix_ssh(self, ssh_config: Path) -> None:
        info = parse_remote_url("git@github.com:acme/widget", ssh_config)
        assert info.name == "widget"


# ---------------------------------------------------------------------------
# parse_remote_url — malformed URL
# ---------------------------------------------------------------------------


class TestParseRemoteUrlMalformed:
    def test_raises_value_error_for_bare_string(self, ssh_config: Path) -> None:
        with pytest.raises(ValueError, match="not-a-url"):
            parse_remote_url("not-a-url", ssh_config)

    def test_raises_value_error_includes_offending_url(self, ssh_config: Path) -> None:
        bad = "ftp://github.com/o/n"
        with pytest.raises(ValueError, match=bad):
            parse_remote_url(bad, ssh_config)

    def test_raises_for_empty_string(self, ssh_config: Path) -> None:
        with pytest.raises(ValueError):
            parse_remote_url("", ssh_config)

    def test_raises_for_owner_only(self, ssh_config: Path) -> None:
        with pytest.raises(ValueError):
            parse_remote_url("https://github.com/acme", ssh_config)

    def test_default_ssh_config_path_used_when_none(self, tmp_path: Path) -> None:
        """When ssh_config_path is None, the function must not crash even if
        ~/.ssh/config doesn't exist — it falls back gracefully."""
        # Uses a real GitHub SSH URL that doesn't need alias resolution
        info = parse_remote_url("https://github.com/acme/widget.git", None)
        assert info.host == "github.com"
