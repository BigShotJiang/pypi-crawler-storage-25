"""Unit tests for tests/fixtures/bench-project/ deterministic fixture.

Acceptance criteria (issue #192):
  AC-6: requirements.md survives requirements_structure.is_canonical_structure without raising.
  AC-7: 3 scope items produce exactly 3 IssueState objects when Phase 1 runs with a mocked runner.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase1_plan
from code_generator.requirements_structure import is_canonical_structure
from code_generator.runner.sdk_runner import RunResult

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_FIXTURE_DIR = Path(__file__).parent / "fixtures" / "bench-project"
_REQUIREMENTS_PATH = _FIXTURE_DIR / ".code-generator" / "requirements.md"
_SCOPE_SECTION_RE = re.compile(r"^### \d+\.", re.MULTILINE)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result() -> RunResult:
    return RunResult(text="", session_id=None, tokens_in=None, tokens_out=None)


def _make_state(tmp_path: Path) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    (state_dir / "requirements.md").write_text(_REQUIREMENTS_PATH.read_text())
    st = _state.load_state(state_dir / "missing.json")
    _state.save_state(state_dir / "state.json", st)
    return st


def _raw_issues(count: int) -> list[dict]:
    return [
        {
            "number": i,
            "title": f"Scope item {i}",
            "state": "open",
            "labels": [{"name": "agent:python-pro"}],
        }
        for i in range(1, count + 1)
    ]


# ---------------------------------------------------------------------------
# AC-6: Fixture requirements.md is canonical
# ---------------------------------------------------------------------------


class TestRequirementsParsesCanonical:
    def test_requirements_parses_canonical(self) -> None:
        """Fixture requirements.md passes is_canonical_structure without raising."""
        content = _REQUIREMENTS_PATH.read_text()
        assert is_canonical_structure(content) is True

    def test_fixture_has_exactly_three_scope_items(self) -> None:
        """Fixture requirements.md contains exactly 3 numbered scope subsections."""
        content = _REQUIREMENTS_PATH.read_text()
        matches = _SCOPE_SECTION_RE.findall(content)
        assert len(matches) == 3, f"Expected 3 scope items, found {len(matches)}"

    def test_tech_stack_declares_python(self) -> None:
        """Tech Stack section references Python so agent detection resolves to python-pro."""
        content = _REQUIREMENTS_PATH.read_text()
        # Extract Tech Stack section
        tech_stack_match = re.search(
            r"^## Tech Stack[ \t]*\n(.*?)(?=^## |\Z)",
            content,
            re.MULTILINE | re.DOTALL | re.IGNORECASE,
        )
        assert tech_stack_match is not None, "## Tech Stack section is missing"
        tech_stack_body = tech_stack_match.group(1)
        assert re.search(r"\bPython\b", tech_stack_body, re.IGNORECASE), (
            "Tech Stack must mention Python for python-pro agent detection"
        )


# ---------------------------------------------------------------------------
# AC-7: 3 scope items → 3 issues via mocked Phase 1 planner
# ---------------------------------------------------------------------------


class TestThreeScopeItemsProduceThreeIssues:
    @pytest.mark.asyncio
    async def test_three_scope_items_produce_three_issues(self, tmp_path: Path) -> None:
        """3 scope items in fixture produce exactly 3 IssueState objects via mocked runner."""
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues(3)),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test_bench_fixture"),
            )

        assert len(state.issues) == 3, f"Expected 3 issues, got {len(state.issues)}"
        assert all(issue.agent == "python-pro" for issue in state.issues)

    @pytest.mark.asyncio
    async def test_issues_are_numbered_one_to_three(self, tmp_path: Path) -> None:
        """Issues from the mocked planner are numbered 1, 2, 3 matching the 3 scope items."""
        state = _make_state(tmp_path)

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues(3)),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test_bench_fixture"),
            )

        assert [issue.number for issue in state.issues] == [1, 2, 3]
