"""Regression guards: phases 0/1/6/7 must NOT pass mcp_servers to their options (issue #177).

These tests assert that the MCP wiring added to phases 2/3/4/5 was NOT accidentally
introduced into the phases that must remain MCP-free.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import (
    phase0_complexity,
    phase1_plan,
    phase6_test,
    phase7_commit,
)
from code_generator.repo_info import RepoInfo
from code_generator.runner.sdk_runner import RunResult

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "") -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state(tmp_path: Path) -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    st.repo = RepoInfo(host="github.com", owner="acme", name="proj")
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# Phase 0 regression
# ---------------------------------------------------------------------------


class TestPhase0McpRegression:
    """Phase 0 must not wire mcp_servers into its make_agent_options call."""

    @pytest.mark.asyncio
    async def test_mcp_servers_is_none_in_phase0_options(self, tmp_path: Path) -> None:
        """options.mcp_servers must be None in Phase 0 — it must not call build_mcp_servers."""
        payload = json.dumps({"mode": "single", "cycles": []})
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result(payload)

        with patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase0_complexity.run(
                state,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_options) == 1
        assert getattr(captured_options[0], "mcp_servers", None) is None


# ---------------------------------------------------------------------------
# Phase 1 regression
# ---------------------------------------------------------------------------


def _raw_issues(numbers: list[int]) -> list[dict]:  # type: ignore[type-arg]
    return [
        {"number": n, "title": f"feat: issue {n}", "state": "open", "labels": []} for n in numbers
    ]


class TestPhase1McpRegression:
    """Phase 1 must not wire mcp_servers into its make_agent_options call."""

    @pytest.mark.asyncio
    async def test_mcp_servers_is_none_in_phase1_options(self, tmp_path: Path) -> None:
        """options.mcp_servers must be None in Phase 1 — it must not call build_mcp_servers."""
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase1_plan.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase1_plan.gh, "ensure_standard_labels"),
            patch.object(phase1_plan.gh, "list_issues", return_value=_raw_issues([1])),
        ):
            await phase1_plan.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_options) == 1
        assert getattr(captured_options[0], "mcp_servers", None) is None


# ---------------------------------------------------------------------------
# Phase 6 regression
# ---------------------------------------------------------------------------


class TestPhase6McpRegression:
    """Phase 6 must not wire mcp_servers into its make_agent_options call."""

    @pytest.mark.asyncio
    async def test_mcp_servers_is_none_in_phase6_options(self, tmp_path: Path) -> None:
        """options.mcp_servers must be None in Phase 6 — it must not call build_mcp_servers."""
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("all tests passed")

        with patch.object(phase6_test.rate_limit, "main_loop", side_effect=fake_main_loop):
            await phase6_test.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_options) == 1
        assert getattr(captured_options[0], "mcp_servers", None) is None


# ---------------------------------------------------------------------------
# Phase 7 regression
# ---------------------------------------------------------------------------


class TestPhase7McpRegression:
    """Phase 7 must not wire mcp_servers into its make_agent_options call."""

    @pytest.mark.asyncio
    async def test_mcp_servers_is_none_in_phase7_options(self, tmp_path: Path) -> None:
        """options.mcp_servers must be None in Phase 7 — it must not call build_mcp_servers."""
        state = _make_state(tmp_path)
        captured_options: list = []

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result("feat: initial commit\n\nAdded files.")

        with (
            patch("code_generator.orchestrator.phase7_commit.git_add_all"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_has_staged",
                return_value=True,
            ),
            patch("code_generator.orchestrator.phase7_commit.git_diff_cached", return_value=""),
            patch("code_generator.orchestrator.phase7_commit.git_commit"),
            patch(
                "code_generator.orchestrator.phase7_commit.git_current_branch",
                return_value="main",
            ),
            patch("code_generator.orchestrator.phase7_commit.git_push"),
            patch.object(phase7_commit.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase7_commit.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_options) >= 1
        assert getattr(captured_options[0], "mcp_servers", None) is None
