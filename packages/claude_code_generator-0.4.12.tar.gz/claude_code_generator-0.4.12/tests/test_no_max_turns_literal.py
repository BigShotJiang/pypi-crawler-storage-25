"""Fast regression guard: no ``max_turns=<int>`` literal ever lands in a phase
module or an entry-point command (issue #209).

This is the cheapest long-term defense against the reactive-bump incident
pattern (requirements §3): a future developer (or LLM cycle) adding
``max_turns=40`` "just to be safe" makes CI red immediately, before the silent
turn cap can ship.

Scope (what is scanned):
- ``src/code_generator/orchestrator/*.py`` — every phase module.
- ``src/code_generator/commands/*.py`` — every CLI entry point.

Explicit non-targets (why they are excluded):
- ``runner/options.py`` — the kwarg accepter; ``max_turns: int | None = None``
  on its signature is by design and must not trip the guard.
- ``runner/subprocess_runner.py`` and the ``runner/`` subtree overall —
  runners forward whatever ``options.max_turns`` carries; they are not SDK
  callers and the ``--max-turns`` argv emission in the subprocess path is
  expected to reference a variable, never a literal.
- The future ``--max-turns`` CLI flag wiring in ``commands/generate.py``
  (#210): Typer options declare a kwarg, not an integer literal assignment,
  so they do not match ``max_turns\\s*=\\s*\\d+`` either.

The regex is deliberately narrow:
- ``max_turns\\s*=\\s*\\d+`` matches ``max_turns=40`` / ``max_turns = 40``.
- It rejects ``max_turns=None``, ``max_turns: int | None = None``,
  ``max_turns=opt_value``, and ``max_turns=max_turns``.
"""

from __future__ import annotations

import re
import time
from pathlib import Path

# Project-relative src root, independent of pytest CWD.
_SRC_ROOT = Path(__file__).resolve().parent.parent / "src" / "code_generator"
_ORCHESTRATOR_DIR = _SRC_ROOT / "orchestrator"
_COMMANDS_DIR = _SRC_ROOT / "commands"

# Narrow pattern: integer literal assignments only — never matches the kwarg
# signature (``int | None = None``) or the variable-threaded forward path.
_LITERAL_PATTERN = re.compile(r"max_turns\s*=\s*\d+")

# Under 100 ms budget per AC; measured on the local FS.  The scan is a few
# dozen small files + one regex per line, so the real wall time is well below
# this threshold.  The headroom here only exists so the guard does not flake
# on a cold cache.
_MAX_SCAN_SECONDS = 0.1


def _scan_for_literals(directory: Path) -> list[str]:
    """Return ``"<rel-path>:<lineno>: <stripped-line>"`` for every regex hit."""
    offenders: list[str] = []
    for py_path in sorted(directory.rglob("*.py")):
        text = py_path.read_text(encoding="utf-8")
        for lineno, line in enumerate(text.splitlines(), start=1):
            if _LITERAL_PATTERN.search(line):
                rel = py_path.relative_to(_SRC_ROOT.parent.parent)
                offenders.append(f"{rel}:{lineno}: {line.strip()}")
    return offenders


def test_no_max_turns_integer_literal_in_orchestrator_or_commands() -> None:
    """No ``max_turns=<integer-literal>`` assignment may exist in either dir.

    Reintroducing ``max_turns=40`` in any phase or entry-point command makes
    this test fail; removal makes it pass.  See module docstring for the
    scoping rationale.
    """
    start = time.perf_counter()
    orchestrator_hits = _scan_for_literals(_ORCHESTRATOR_DIR)
    command_hits = _scan_for_literals(_COMMANDS_DIR)
    elapsed = time.perf_counter() - start

    offenders = orchestrator_hits + command_hits
    assert not offenders, (
        "max_turns=<integer-literal> re-introduced. The no-default-turn-budget "
        "invariant (requirements §1) bans this: observability + rate-limit + "
        "overage-abort + task-budgets are the real safety nets.\n"
        "If you need a per-operator cap, use the `--max-turns` CLI opt-in "
        "from #210 (a kwarg, not a literal).\nOffenders:\n  " + "\n  ".join(offenders)
    )
    assert elapsed < _MAX_SCAN_SECONDS, (
        f"scan took {elapsed * 1000:.1f}ms (budget {_MAX_SCAN_SECONDS * 1000:.0f}ms); "
        "the guard must stay fast enough to run on every CI invocation"
    )
