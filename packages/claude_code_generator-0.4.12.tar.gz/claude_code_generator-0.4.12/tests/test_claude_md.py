"""Snippet tests for CLAUDE.md non-negotiable #6 invariants."""

from pathlib import Path

CLAUDE_MD = Path(__file__).parent.parent / "CLAUDE.md"


def _content() -> str:
    return CLAUDE_MD.read_text(encoding="utf-8")


def test_non_negotiable_6_soft_reset_phrase_present() -> None:
    """AC6: CLAUDE.md must contain the canonical soft-reset phrase."""
    assert "Fresh context per issue via soft reset" in _content(), (
        "CLAUDE.md non-negotiable #6 must read 'Fresh context per issue via soft reset …' "
        "(see issue #189)"
    )


def test_old_fresh_sdk_session_phrase_absent() -> None:
    """AC7: The superseded phrase must no longer appear in CLAUDE.md."""
    assert "Fresh SDK session per issue" not in _content(), (
        "CLAUDE.md still contains the old phrase 'Fresh SDK session per issue'; "
        "it was replaced in non-negotiable #6 by issue #189"
    )


def test_cache_workspace_invariants_section_present() -> None:
    """§14: CLAUDE.md must contain a 'Cache workspace invariants' section."""
    assert "## Cache workspace invariants" in _content(), (
        "CLAUDE.md is missing the '## Cache workspace invariants' section "
        "required by issue #199 (§14 workspace-isolation rule)"
    )
