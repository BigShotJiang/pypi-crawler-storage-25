"""Additional tests for cycle_loop: multi-cycle, _run_phases skip/re-entry, state persistence.

Kept separate from test_cycle_loop.py (already >1,120 lines) to stay under the
500-600 line clean-code limit.  This file focuses on:
  - _run_phases start_phase skip boundaries (phases 1/2/4 skipped when start_phase=5)
  - _run_phases phase-5 re-entry with / without new fix issues
  - run_multi_cycle start_cycle skip-and-mark-completed behaviour
  - run_multi_cycle termination when remaining cycles have unmet dependencies
  - _eligible_cycles returns empty list when all dependencies are unmet
  - state.json is written to disk after every phase in _run_phases
  - _archive_cycle_logs moves cycle log files into a per-cycle subdirectory
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import cycle_loop

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures / helpers  (mirror test_cycle_loop.py conventions)
# ---------------------------------------------------------------------------


def _make_logger() -> logging.Logger:
    return logging.getLogger("test.cycle_loop_multicycle")


def _make_state(tmp_path: Path, mode: str = "single") -> _state.State:
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    _state.save_state(state_dir / "state.json", st)
    return st


def _make_cycle(
    cycle_id: int,
    *,
    name: str | None = None,
    depends_on: list[int] | None = None,
    milestone_number: int | None = None,
    status: str = "open",
) -> _state.CycleState:
    return _state.CycleState(
        id=cycle_id,
        name=name or f"Cycle {cycle_id}",
        milestone_number=milestone_number,
        milestone_title=f"Milestone {cycle_id}",
        status=status,
        phase=0,
        issues=[],
        commit_sha=None,
        depends_on=depends_on or [],
    )


# ---------------------------------------------------------------------------
# _run_phases — start_phase skip boundaries
# ---------------------------------------------------------------------------


class TestRunPhasesStartPhaseSkips:
    """Verify every phase is skipped/run correctly at each start_phase boundary."""

    @pytest.mark.asyncio
    async def test_start_phase_5_skips_plan_review_implement_runs_closure_test_commit(
        self, tmp_path: Path
    ) -> None:
        """_run_phases(start_phase=5) skips phases 1, 2, 4; runs 5, 6, 7."""
        st = _make_state(tmp_path)
        calls: list[str] = []

        async def track(name: str, return_val=None):
            async def _fn(*_, **__):
                calls.append(name)
                return return_val

            return _fn

        from code_generator.orchestrator import phase5_closure

        p1 = await track("plan")
        p2 = await track("review")
        p3 = await track("implement")
        p5 = await track("closure", phase5_closure.FixResult())
        p6 = await track("test")
        p7 = await track("commit")

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", p2),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_phases(  # noqa: SLF001
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=5,
            )

        assert "plan" not in calls, "start_phase=5 must skip phase 1 (plan)"
        assert "review" not in calls, "start_phase=5 must skip phase 2 (review)"
        assert "implement" not in calls, "start_phase=5 must skip phase 4 (implement)"
        assert "closure" in calls, "start_phase=5 must run phase 5 (closure)"
        assert "test" in calls, "start_phase=5 must run phase 6 (test)"
        assert "commit" in calls, "start_phase=5 must run phase 7 (commit)"

    @pytest.mark.asyncio
    async def test_start_phase_2_skips_plan_runs_review_onward(self, tmp_path: Path) -> None:
        """_run_phases(start_phase=2) skips phase 1 (plan); runs phases 2, 4, 5, 6, 7."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        calls: list[str] = []

        async def track(name: str, return_val=None):
            async def _fn(*_, **__):
                calls.append(name)
                return return_val

            return _fn

        p1 = await track("plan")
        p2 = await track("review")
        p3 = await track("implement")
        p5 = await track("closure", phase5_closure.FixResult())
        p6 = await track("test")
        p7 = await track("commit")

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", p2),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", p6),
            patch.object(cycle_loop.phase7_commit, "run", p7),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_phases(  # noqa: SLF001
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=2,
            )

        assert "plan" not in calls, "start_phase=2 must skip phase 1 (plan)"
        assert "review" in calls, "start_phase=2 must run phase 2 (review)"
        assert "implement" in calls, "start_phase=2 must run phase 4 (implement)"
        assert "closure" in calls, "start_phase=2 must run phase 5 (closure)"
        assert "test" in calls, "start_phase=2 must run phase 6 (test)"
        assert "commit" in calls, "start_phase=2 must run phase 7 (commit)"


# ---------------------------------------------------------------------------
# _run_phases — phase-5 re-entry behaviour
# ---------------------------------------------------------------------------


class TestRunPhasesPhase5ReEntry:
    """Phase 5 re-entry: implement runs again when new_issues present, not otherwise."""

    @pytest.mark.asyncio
    async def test_no_reentry_when_phase5_returns_empty_fix_result(self, tmp_path: Path) -> None:
        """_run_phases does NOT call implement a second time when phase 5 returns FixResult()."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        implement_calls: list[int] = []

        async def p3(*a, **kw):
            implement_calls.append(1)

        async def p5(*a, **kw):
            return phase5_closure.FixResult()  # no new issues

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_phases(  # noqa: SLF001
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
            )

        assert len(implement_calls) == 1, (
            "implement must run exactly once when phase 5 returns no new issues"
        )

    @pytest.mark.asyncio
    async def test_reentry_when_phase5_returns_new_issues(self, tmp_path: Path) -> None:
        """_run_phases calls implement twice when phase 5 returns new_issues."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        implement_calls: list[int] = []
        new_issue = _state.IssueState(number=77, status="open", agent="python-pro")

        async def p3(*a, **kw):
            implement_calls.append(1)

        async def p5(*a, **kw):
            return phase5_closure.FixResult(new_issues=[new_issue])

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop._run_phases(  # noqa: SLF001
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
            )

        assert len(implement_calls) == 2, (
            "implement must run twice: once normally, once as fix re-entry"
        )

    @pytest.mark.asyncio
    async def test_fix_reentry_uses_phase3_4_fix_logger_name(self, tmp_path: Path) -> None:
        """The fix re-entry call to phase3_4_implement.run receives a logger named 'phase3_4_fix'."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        new_issue = _state.IssueState(number=77, status="open", agent="python-pro")
        implement_loggers: list[logging.Logger | None] = []

        async def capture_p3(*a, **kw):
            implement_loggers.append(kw.get("logger"))

        async def p5(*a, **kw):
            return phase5_closure.FixResult(new_issues=[new_issue])

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", capture_p3),
            patch.object(cycle_loop.phase5_closure, "run", p5),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(
                cycle_loop,
                "setup_phase_logger",
                side_effect=lambda name, _dir: logging.getLogger(name),
            ),
        ):
            await cycle_loop._run_phases(  # noqa: SLF001
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
            )

        assert len(implement_loggers) == 2, "implement must be called twice (normal + fix re-entry)"
        fix_logger = implement_loggers[1]
        assert fix_logger is not None, "fix re-entry must receive a logger kwarg"
        assert fix_logger.name == "phase3_4_fix", (
            f"fix re-entry logger name must be 'phase3_4_fix', got '{fix_logger.name}'"
        )


# ---------------------------------------------------------------------------
# run_multi_cycle — start_cycle skip-and-mark-completed
# ---------------------------------------------------------------------------


class TestRunMultiCycleStartCycle:
    """run_multi_cycle with start_cycle marks skipped cycles as completed."""

    @pytest.mark.asyncio
    async def test_start_cycle_2_marks_cycle_1_completed(self, tmp_path: Path) -> None:
        """start_cycle=2 skips cycle 1 and sets its status to 'completed'."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, milestone_number=11)
        st.cycles = [c1, c2]

        ran_cycles: list[int] = []

        async def p1(state, cycle, project_dir, *, runner_module, logger, **kw):
            if cycle is not None:
                ran_cycles.append(cycle.id)

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure,
                "run",
                AsyncMock(return_value=phase5_closure.FixResult()),
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_cycle=2,
            )

        assert 1 not in ran_cycles, "cycle 1 must not have run any phases"
        assert c1.status == "completed", (
            "skipped cycle must be marked completed so dependents can run"
        )
        assert 2 in ran_cycles, "cycle 2 must run normally"
        assert c2.status == "completed"

    @pytest.mark.asyncio
    async def test_skipped_cycle_status_persisted_to_disk_before_continue(
        self, tmp_path: Path
    ) -> None:
        """State file must be written to disk immediately after a cycle is marked completed
        via start_cycle skip — not lazily when the next real cycle begins (non-negotiable #7).

        Without the fix there are exactly 2 save_state calls in run_multi_cycle itself:
          1. cycle-2 entry (line 317)  2. cycle-2 completion (line 366)
        With the fix there is 1 extra call (the skip-persist for cycle 1) = 3 calls total.

        _run_cycle_phases is mocked so internal phase saves are excluded, making the count precise.
        """
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, milestone_number=11)
        st.cycles = [c1, c2]

        save_snapshots: list[dict] = []
        original_save = _state.save_state

        def tracking_save(path, state):
            save_snapshots.append({c.id: c.status for c in state.cycles})
            original_save(path, state)

        with (
            # Mock _run_cycle_phases so only run_multi_cycle's own save_state calls count.
            patch.object(cycle_loop, "_run_cycle_phases", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop._state, "save_state", tracking_save),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_cycle=2,
            )

        # With the fix: 4 saves (skip-c1 + c2-entry + c2-started_at + c2-completion).
        # Without the skip-persist fix: only 3 saves (c2-entry + c2-started_at + c2-completion)
        # — cycle 1's "completed" status is never persisted to disk immediately after the skip.
        assert len(save_snapshots) == 4, (
            f"expected 4 save_state calls (skip-persist + cycle-entry + started_at + cycle-completion), "
            f"got {len(save_snapshots)} — "
            "non-negotiable #7: every state mutation must be immediately followed by a persist"
        )
        # The FIRST call must be the skip-persist, capturing c1=completed before c2 starts.
        assert save_snapshots[0].get(1) == "completed", (
            "the skip-persist must record cycle 1 as 'completed' before cycle 2 entry"
        )
        assert save_snapshots[0].get(2) == "open", (
            "the skip-persist must not yet reflect cycle 2 as completed"
        )

    @pytest.mark.asyncio
    async def test_start_cycle_2_allows_dependent_cycle_to_run(self, tmp_path: Path) -> None:
        """start_cycle=2 with cycle 3 depending on cycle 2 lets cycle 3 execute."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, depends_on=[1], milestone_number=11)
        c3 = _make_cycle(3, depends_on=[2], milestone_number=12)
        st.cycles = [c1, c2, c3]

        ran_cycles: list[int] = []

        async def p1(state, cycle, project_dir, *, runner_module, logger, **kw):
            if cycle is not None:
                ran_cycles.append(cycle.id)

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure,
                "run",
                AsyncMock(return_value=phase5_closure.FixResult()),
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_cycle=2,
            )

        assert 1 not in ran_cycles
        assert c1.status == "completed"
        assert 2 in ran_cycles
        assert 3 in ran_cycles
        assert c3.status == "completed"


# ---------------------------------------------------------------------------
# run_multi_cycle — termination when deps unmet
# ---------------------------------------------------------------------------


class TestRunMultiCycleTermination:
    """run_multi_cycle exits cleanly when remaining cycles have unmet dependencies."""

    @pytest.mark.asyncio
    async def test_loop_exits_when_remaining_cycle_has_unmet_dep(self, tmp_path: Path) -> None:
        """After running eligible cycles, loop terminates if remaining cycles have unmet deps."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        # Cycle 1: no deps — eligible from the start.
        # Cycle 2: depends on ID 99 which never exists.
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, depends_on=[99], milestone_number=11)
        st.cycles = [c1, c2]

        ran_cycles: list[int] = []

        async def p1(state, cycle, project_dir, *, runner_module, logger, **kw):
            if cycle is not None:
                ran_cycles.append(cycle.id)

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure,
                "run",
                AsyncMock(return_value=phase5_closure.FixResult()),
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            result = await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
            )

        assert result is st
        assert ran_cycles == [1], "only cycle 1 ran; cycle 2 dep was never met"
        assert c1.status == "completed"
        assert c2.status == "open", "cycle 2 remains open because dep 99 was never completed"

    @pytest.mark.asyncio
    async def test_loop_exits_immediately_when_all_cycles_have_unmet_deps(
        self, tmp_path: Path
    ) -> None:
        """run_multi_cycle terminates at once when every cycle has unmet deps."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, depends_on=[42], milestone_number=10)
        c2 = _make_cycle(2, depends_on=[43], milestone_number=11)
        st.cycles = [c1, c2]

        ran_cycles: list[int] = []

        async def p1(state, cycle, project_dir, *, runner_module, logger, **kw):
            if cycle is not None:
                ran_cycles.append(cycle.id)

        with (
            patch.object(cycle_loop.phase1_plan, "run", p1),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure,
                "run",
                AsyncMock(return_value=phase5_closure.FixResult()),
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            result = await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
            )

        assert result is st
        assert ran_cycles == [], "no phases ran; all cycles had unmet deps"
        assert c1.status == "open"
        assert c2.status == "open"


# ---------------------------------------------------------------------------
# _eligible_cycles — all deps unmet (no infinite loop)
# ---------------------------------------------------------------------------


class TestEligibleCyclesAllDepsUnmet:
    """_eligible_cycles returns [] when every cycle has at least one unmet dependency."""

    def test_returns_empty_when_all_cycles_have_unmet_deps(self, tmp_path: Path) -> None:
        """No eligible cycles when every open cycle depends on a non-existent ID."""
        st = _make_state(tmp_path)
        c1 = _make_cycle(1, depends_on=[99])  # ID 99 never appears
        c2 = _make_cycle(2, depends_on=[100])  # ID 100 never appears
        st.cycles = [c1, c2]

        eligible = cycle_loop._eligible_cycles(st, completed_ids=set())  # noqa: SLF001

        assert eligible == [], (
            "_eligible_cycles must return [] when all deps are unmet — "
            "ensures the run_multi_cycle while-loop terminates"
        )


# ---------------------------------------------------------------------------
# State persistence — file is written after every phase
# ---------------------------------------------------------------------------


class TestStatePersistenceAfterEachPhase:
    """_run_phases must call save_state after every phase that executes."""

    @pytest.mark.asyncio
    async def test_state_saved_after_each_phase_full_run(self, tmp_path: Path) -> None:
        """When all 6 phases run (no fix issues), save_state is called 6 times."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        save_calls: list[str] = []

        original_save = _state.save_state

        def tracking_save(path, state):
            save_calls.append("save")
            original_save(path, state)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure,
                "run",
                AsyncMock(return_value=phase5_closure.FixResult()),
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop._state, "save_state", tracking_save),
        ):
            await cycle_loop._run_phases(  # noqa: SLF001
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
            )

        # populate_cycle_start_fields (§17) + phases 1, 2, 4, 5, 6, 7 = 7 saves.
        assert len(save_calls) == 7, (
            f"expected 7 save_state calls (1 §17 populate + 6 phases), got {len(save_calls)}"
        )

    @pytest.mark.asyncio
    async def test_state_saved_after_fix_reentry(self, tmp_path: Path) -> None:
        """When phase 5 returns new_issues, an extra save_state call occurs after fix run."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        save_calls: list[str] = []
        new_issue = _state.IssueState(number=88, status="open", agent="python-pro")

        original_save = _state.save_state

        def tracking_save(path, state):
            save_calls.append("save")
            original_save(path, state)

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure,
                "run",
                AsyncMock(return_value=phase5_closure.FixResult(new_issues=[new_issue])),
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop._state, "save_state", tracking_save),
        ):
            await cycle_loop._run_phases(  # noqa: SLF001
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
            )

        # §17 populate + 6 phases + 1 extra save after fix re-entry = 8 saves.
        assert len(save_calls) == 8, (
            f"expected 8 save_state calls (1 §17 populate + 6 phases + 1 fix-reentry save), got {len(save_calls)}"
        )

    @pytest.mark.asyncio
    async def test_state_file_reflects_phase_after_each_save(self, tmp_path: Path) -> None:
        """Disk state.json is updated with the latest phase number after every save."""
        from code_generator.orchestrator import phase5_closure

        st = _make_state(tmp_path)
        tmp_path / ".code-generator" / "state.json"
        phase_snapshots: list[int | None] = []

        original_save = _state.save_state

        def capturing_save(path, state):
            original_save(path, state)
            # Read back from disk after every write.
            data = json.loads(path.read_text(encoding="utf-8"))
            phase_snapshots.append(data.get("phase"))

        with (
            patch.object(cycle_loop.phase1_plan, "run", AsyncMock()),
            patch.object(cycle_loop.phase2_review, "run", AsyncMock()),
            patch.object(cycle_loop.phase3_4_implement, "run", AsyncMock()),
            patch.object(
                cycle_loop.phase5_closure,
                "run",
                AsyncMock(return_value=phase5_closure.FixResult()),
            ),
            patch.object(cycle_loop.phase6_test, "run", AsyncMock()),
            patch.object(cycle_loop.phase7_commit, "run", AsyncMock()),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
            patch.object(cycle_loop._state, "save_state", capturing_save),
        ):
            await cycle_loop._run_phases(  # noqa: SLF001
                st,
                None,
                tmp_path,
                MagicMock(),
                log_prefix="",
                start_phase=1,
            )

        # §17 populate (phase=None) + phases 1,2,4,5,6,7 → persisted values.
        assert phase_snapshots == [None, 1, 2, 4, 5, 6, 7], (
            f"disk state.json must capture phase after each save, got {phase_snapshots}"
        )


# ---------------------------------------------------------------------------
# _archive_cycle_logs — log archival into per-cycle subdirectory
# ---------------------------------------------------------------------------


class TestArchiveCycleLogs:
    """Unit tests for cycle_loop._archive_cycle_logs."""

    def test_moves_cycle_log_files_into_subdirectory(self, tmp_path: Path) -> None:
        """After archival, log files exist in .code-generator/logs/cycle-{N}/."""
        logs_dir = tmp_path / ".code-generator" / "logs"
        logs_dir.mkdir(parents=True)
        (logs_dir / "cycle1_phase1.log").write_text("phase1 output")
        (logs_dir / "cycle1_phase2.log").write_text("phase2 output")

        cycle_loop._archive_cycle_logs(tmp_path, cycle_id=1)  # noqa: SLF001

        dest = logs_dir / "cycle-1"
        assert (dest / "cycle1_phase1.log").exists()
        assert (dest / "cycle1_phase2.log").exists()

    def test_source_files_are_removed_after_move(self, tmp_path: Path) -> None:
        """Source log files are no longer present in the logs/ root after archival."""
        logs_dir = tmp_path / ".code-generator" / "logs"
        logs_dir.mkdir(parents=True)
        (logs_dir / "cycle2_phase3.log").write_text("impl output")

        cycle_loop._archive_cycle_logs(tmp_path, cycle_id=2)  # noqa: SLF001

        assert not (logs_dir / "cycle2_phase3.log").exists()

    def test_no_matching_files_is_a_noop(self, tmp_path: Path) -> None:
        """When no log files match the cycle prefix, the function raises no error."""
        logs_dir = tmp_path / ".code-generator" / "logs"
        logs_dir.mkdir(parents=True)

        # Should not raise.
        cycle_loop._archive_cycle_logs(tmp_path, cycle_id=99)  # noqa: SLF001

        dest = logs_dir / "cycle-99"
        assert not dest.exists()

    def test_destination_already_exists_overwrites_cleanly(self, tmp_path: Path) -> None:
        """If the destination directory already exists, files are overwritten without error."""
        logs_dir = tmp_path / ".code-generator" / "logs"
        logs_dir.mkdir(parents=True)
        dest = logs_dir / "cycle-3"
        dest.mkdir(parents=True)
        # Pre-existing stale file in the destination.
        (dest / "cycle3_phase1.log").write_text("stale content")
        # Fresh source file with same name.
        (logs_dir / "cycle3_phase1.log").write_text("fresh content")

        cycle_loop._archive_cycle_logs(tmp_path, cycle_id=3)  # noqa: SLF001

        assert (dest / "cycle3_phase1.log").read_text() == "fresh content"

    def test_only_matching_cycle_files_are_moved(self, tmp_path: Path) -> None:
        """Files from a different cycle or without the prefix are not moved."""
        logs_dir = tmp_path / ".code-generator" / "logs"
        logs_dir.mkdir(parents=True)
        (logs_dir / "cycle4_phase1.log").write_text("cycle4")
        (logs_dir / "cycle40_phase1.log").write_text("cycle40 — different cycle")
        other = logs_dir / "other.log"
        other.write_text("unrelated")

        cycle_loop._archive_cycle_logs(tmp_path, cycle_id=4)  # noqa: SLF001

        dest = logs_dir / "cycle-4"
        assert (dest / "cycle4_phase1.log").exists()
        # cycle40 must NOT be moved into cycle-4 subdirectory.
        assert not (dest / "cycle40_phase1.log").exists()
        # Unrelated log must remain in root.
        assert other.exists()


# ---------------------------------------------------------------------------
# Cycle wall-clock timestamps — started_at / finished_at (Issue #126)
# ---------------------------------------------------------------------------


class TestCycleTimestamps:
    """run_multi_cycle records started_at / finished_at on CycleState objects."""

    @pytest.mark.asyncio
    async def test_both_cycles_receive_started_at_and_finished_at(self, tmp_path: Path) -> None:
        """Multi-cycle run with 2 cycles: both have non-None started_at and finished_at."""

        st = _make_state(tmp_path, mode="multi-cycle")
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, milestone_number=11)
        st.cycles = [c1, c2]

        with (
            patch.object(cycle_loop, "_run_cycle_phases", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
            )

        assert c1.started_at is not None, "cycle 1 must have started_at set"
        assert c1.finished_at is not None, "cycle 1 must have finished_at set"
        assert c2.started_at is not None, "cycle 2 must have started_at set"
        assert c2.finished_at is not None, "cycle 2 must have finished_at set"

    @pytest.mark.asyncio
    async def test_started_at_not_overwritten_on_continue_resume(self, tmp_path: Path) -> None:
        """--continue resume of a cycle that already has started_at does NOT overwrite it."""
        original_started_at = "2026-01-01T10:00:00Z"
        c1 = _make_cycle(1, milestone_number=10)
        c1.started_at = original_started_at

        st = _make_state(tmp_path, mode="multi-cycle")
        st.cycles = [c1]

        with (
            patch.object(cycle_loop, "_run_cycle_phases", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
            )

        assert c1.started_at == original_started_at, (
            "started_at must not be overwritten on --continue resume"
        )

    @pytest.mark.asyncio
    async def test_failed_cycle_still_receives_finished_at(self, tmp_path: Path) -> None:
        """A cycle that raises an exception still gets finished_at set."""
        c1 = _make_cycle(1, milestone_number=10)
        st = _make_state(tmp_path, mode="multi-cycle")
        st.cycles = [c1]

        with (
            patch.object(
                cycle_loop,
                "_run_cycle_phases",
                AsyncMock(side_effect=RuntimeError("phase failed")),
            ),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            with pytest.raises(RuntimeError, match="phase failed"):
                await cycle_loop.run_multi_cycle(
                    st,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=_make_logger(),
                )

        assert c1.finished_at is not None, "failed cycle must still have finished_at set"

    @pytest.mark.asyncio
    async def test_skipped_cycle_does_not_receive_timestamps(self, tmp_path: Path) -> None:
        """Cycles skipped via --cycle N do not receive started_at or finished_at."""
        c1 = _make_cycle(1, milestone_number=10)
        c2 = _make_cycle(2, milestone_number=11)
        st = _make_state(tmp_path, mode="multi-cycle")
        st.cycles = [c1, c2]

        with (
            patch.object(cycle_loop, "_run_cycle_phases", AsyncMock()),
            patch.object(cycle_loop.gh, "close_milestone"),
            patch.object(cycle_loop, "setup_phase_logger", return_value=_make_logger()),
        ):
            await cycle_loop.run_multi_cycle(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=_make_logger(),
                start_cycle=2,
            )

        assert c1.started_at is None, "skipped cycle must NOT have started_at set"
        assert c1.finished_at is None, "skipped cycle must NOT have finished_at set"
