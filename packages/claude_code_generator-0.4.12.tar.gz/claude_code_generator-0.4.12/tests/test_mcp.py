"""Tests for src/code_generator/runner/mcp.py — MCP config builders.

Test strategy: Red → Green → Refactor (TDD).
Each acceptance criterion from issue #176 has a dedicated test.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pytest

# ---------------------------------------------------------------------------
# Test 1: codebase-memory-mcp binary found → config dict is well-formed
# ---------------------------------------------------------------------------


def test_build_codebase_memory_config_when_binary_found(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When shutil.which finds codebase-memory-mcp, returns a well-formed stdio config."""
    fake_binary = "/usr/local/bin/codebase-memory-mcp"
    monkeypatch.setattr(
        "shutil.which", lambda name: fake_binary if name == "codebase-memory-mcp" else None
    )

    from code_generator.runner.mcp import build_codebase_memory_server_config

    result = build_codebase_memory_server_config(tmp_path)

    assert result is not None
    assert result["type"] == "stdio"
    assert result["command"] == fake_binary
    assert "args" in result
    assert str(tmp_path) in result["args"]


# ---------------------------------------------------------------------------
# Test 2: serena binary found → config dict is well-formed
# ---------------------------------------------------------------------------


def test_build_serena_config_when_binary_found(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When shutil.which finds serena, returns a well-formed stdio config."""
    fake_binary = "/usr/local/bin/serena"
    monkeypatch.setattr("shutil.which", lambda name: fake_binary if name == "serena" else None)

    from code_generator.runner.mcp import build_serena_server_config

    result = build_serena_server_config(tmp_path)

    assert result is not None
    assert result["type"] == "stdio"
    assert result["command"] == fake_binary
    assert "args" in result
    assert str(tmp_path) in result["args"]


# ---------------------------------------------------------------------------
# Test 3: both binaries missing → build_mcp_servers returns None + one WARNING
# ---------------------------------------------------------------------------


def test_build_mcp_servers_both_missing_returns_none_with_warning(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """When both codebase-memory-mcp and serena are absent, returns None and warns once."""
    monkeypatch.setattr("shutil.which", lambda _name: None)

    from code_generator.runner import mcp as mcp_mod

    with caplog.at_level(logging.WARNING, logger="code_generator.runner.mcp"):
        result = mcp_mod.build_mcp_servers(tmp_path)

    assert result is None
    warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 1, f"expected exactly 1 WARNING, got {len(warnings)}"


# ---------------------------------------------------------------------------
# Test 4: fallback chain — codebase-memory-mcp absent, serena present → Serena dict, no WARNING
# ---------------------------------------------------------------------------


def test_build_mcp_servers_falls_back_to_serena_without_warning(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """When codebase-memory-mcp is absent but serena is present, returns Serena config, no WARNING."""
    fake_serena = "/usr/local/bin/serena"

    def which_side_effect(name: str) -> str | None:
        return fake_serena if name == "serena" else None

    monkeypatch.setattr("shutil.which", which_side_effect)

    from code_generator.runner import mcp as mcp_mod

    with caplog.at_level(logging.WARNING, logger="code_generator.runner.mcp"):
        result = mcp_mod.build_mcp_servers(tmp_path)

    assert result is not None
    assert "serena" in result
    warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 0, f"expected no WARNING, got {len(warnings)}"


# ---------------------------------------------------------------------------
# Test 5: repo_path is passed through to args so the indexer knows which repo to scan
# ---------------------------------------------------------------------------


def test_repo_path_passed_through_to_args(monkeypatch: pytest.MonkeyPatch) -> None:
    """repo_path is included in the config args for both builders."""
    fake_binary = "/opt/bin/codebase-memory-mcp"
    monkeypatch.setattr(
        "shutil.which", lambda name: fake_binary if name == "codebase-memory-mcp" else None
    )

    from code_generator.runner.mcp import build_codebase_memory_server_config

    repo = Path("/some/project/root")
    result = build_codebase_memory_server_config(repo)

    assert result is not None
    assert "/some/project/root" in result["args"]


# ---------------------------------------------------------------------------
# Test 6: unexpected exception from shutil.which → falls through to None, no crash
# ---------------------------------------------------------------------------


def test_unexpected_exception_from_which_returns_none(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An unexpected exception from shutil.which does not crash; returns None."""

    def exploding_which(_name: str) -> str:
        raise RuntimeError("unexpected OS error")

    monkeypatch.setattr("shutil.which", exploding_which)

    from code_generator.runner.mcp import build_codebase_memory_server_config

    result = build_codebase_memory_server_config(tmp_path)
    assert result is None


# ---------------------------------------------------------------------------
# Test 7: build_mcp_servers with codebase-memory-mcp present → keyed on correct name
# ---------------------------------------------------------------------------


def test_build_mcp_servers_returns_codebase_memory_key_when_binary_present(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When codebase-memory-mcp is found, build_mcp_servers returns dict keyed on it."""
    fake_binary = "/usr/local/bin/codebase-memory-mcp"
    monkeypatch.setattr(
        "shutil.which", lambda name: fake_binary if name == "codebase-memory-mcp" else None
    )

    from code_generator.runner import mcp as mcp_mod

    result = mcp_mod.build_mcp_servers(tmp_path)

    assert result is not None
    assert "codebase_memory" in result


# ---------------------------------------------------------------------------
# Test 8: mcp_tool_wildcards — None → empty list
# ---------------------------------------------------------------------------


def test_mcp_tool_wildcards_returns_empty_list_when_none() -> None:
    """mcp_tool_wildcards(None) returns an empty list (no MCP available)."""
    from code_generator.runner.mcp import mcp_tool_wildcards

    assert mcp_tool_wildcards(None) == []


# ---------------------------------------------------------------------------
# Test 9: mcp_tool_wildcards — codebase_memory → ["mcp__codebase_memory__*"]
# ---------------------------------------------------------------------------


def test_mcp_tool_wildcards_returns_wildcard_for_codebase_memory() -> None:
    """mcp_tool_wildcards with codebase_memory key returns the correct wildcard entry."""
    from code_generator.runner.mcp import mcp_tool_wildcards

    servers = {"codebase_memory": {"type": "stdio", "command": "/bin/cm"}}
    result = mcp_tool_wildcards(servers)

    assert result == ["mcp__codebase_memory__*"]


# ---------------------------------------------------------------------------
# Test 10: mcp_tool_wildcards — serena → ["mcp__serena__*"]
# ---------------------------------------------------------------------------


def test_mcp_tool_wildcards_returns_wildcard_for_serena() -> None:
    """mcp_tool_wildcards with serena key returns the correct wildcard entry."""
    from code_generator.runner.mcp import mcp_tool_wildcards

    servers = {"serena": {"type": "stdio", "command": "/bin/serena"}}
    result = mcp_tool_wildcards(servers)

    assert result == ["mcp__serena__*"]


# ---------------------------------------------------------------------------
# Test 11: mcp_tool_wildcards — empty dict → empty list
# ---------------------------------------------------------------------------


def test_mcp_tool_wildcards_returns_empty_list_for_empty_dict() -> None:
    """mcp_tool_wildcards({}) returns an empty list (falsy dict)."""
    from code_generator.runner.mcp import mcp_tool_wildcards

    assert mcp_tool_wildcards({}) == []
