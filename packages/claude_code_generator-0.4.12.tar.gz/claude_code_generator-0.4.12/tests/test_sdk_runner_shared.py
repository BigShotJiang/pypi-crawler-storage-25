"""Tests for run_with_shared_client() — Issue #168.

All SDK types are duck-typed fakes. No real SDK calls are made.
Verifies that the shared-client adapter reproduces the full token-accounting,
rate-limit, overage-abort, and error-handling logic of run() while delegating
client lifecycle to the caller.
"""

from __future__ import annotations

import logging
from typing import Any
from unittest.mock import MagicMock

import pytest

from code_generator.runner.sdk_runner import run_with_shared_client
from code_generator.runner.types import (
    ApiUpstreamError,
    MaxTurnsExceeded,
    RunResult,
    TokenUsage,
)

# ---------------------------------------------------------------------------
# Fake SDK message types (duck-typed, no SDK imports needed)
# ---------------------------------------------------------------------------


class FakeTextBlock:
    def __init__(self, text: str) -> None:
        self.text = text


class FakeAssistantMessage:
    def __init__(self, text: str, session_id: str = "sess-shared") -> None:
        self.content = [FakeTextBlock(text)]
        self.model = "claude-sonnet-4-6"
        self.usage = {"input_tokens": 10, "output_tokens": 20}
        self.session_id = session_id


class FakeResultMessage:
    def __init__(
        self,
        session_id: str = "sess-shared",
        is_error: bool = False,
        subtype: str = "success",
        input_tokens: int = 10,
        output_tokens: int = 20,
        cache_read: int = 0,
        cache_write: int = 0,
        num_turns: int = 1,
    ) -> None:
        self.session_id = session_id
        self.is_error = is_error
        self.subtype = subtype
        self.stop_reason = "end_turn"
        self.num_turns = num_turns
        self.usage = {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cache_read_input_tokens": cache_read,
            "cache_creation_input_tokens": cache_write,
        }


class FakeRateLimitInfo:
    def __init__(
        self,
        status: str = "allowed",
        resets_at: int | None = None,
        overage_status: str | None = None,
    ) -> None:
        self.status = status
        self.resets_at = resets_at
        self.overage_status = overage_status
        self.rate_limit_type = "token"


class FakeRateLimitEvent:
    def __init__(self, info: FakeRateLimitInfo, session_id: str = "sess-rl") -> None:
        self.rate_limit_info = info
        self.session_id = session_id
        self.uuid = "uuid-1"


def _make_fake_client(messages: list[Any]) -> Any:
    """Build a fake client with query() and receive_messages() — no lifecycle methods."""

    class FakeClient:
        def __init__(self) -> None:
            self._aenter_called = False
            self._aexit_called = False

        async def __aenter__(self) -> FakeClient:
            self._aenter_called = True
            return self

        async def __aexit__(self, *_: Any) -> None:
            self._aexit_called = True

        async def query(self, _prompt: str) -> None:
            pass

        async def receive_messages(self):
            for msg in messages:
                yield msg

    return FakeClient()


def _make_options() -> Any:
    opts = MagicMock()
    opts.model = "claude-sonnet-4-6"
    opts.effort = None
    opts.max_turns = 50
    return opts


# ---------------------------------------------------------------------------
# AC1: returns RunResult with correct text, session_id, usage
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_returns_run_result_with_text_session_id_usage(tmp_path: Any) -> None:
    """Fake client yields [AssistantMessage, ResultMessage] → RunResult with correct fields."""
    state_path = tmp_path / "state.json"
    messages = [
        FakeAssistantMessage("hello world", session_id="sess-1"),
        FakeResultMessage(
            session_id="sess-1",
            input_tokens=100,
            output_tokens=50,
            cache_read=20,
            cache_write=30,
        ),
    ]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.basic")

    result = await run_with_shared_client(
        client, "prompt", options, logger=logger, state_path=state_path
    )

    assert isinstance(result, RunResult)
    assert result.text == "hello world"
    assert result.session_id == "sess-1"
    assert isinstance(result.usage, TokenUsage)
    assert result.usage.input == 100
    assert result.usage.output == 50
    assert result.usage.cache_read == 20
    assert result.usage.cache_write == 30


@pytest.mark.asyncio
async def test_run_with_shared_client_populates_num_turns(tmp_path: Any) -> None:
    """ResultMessage.num_turns flows through run_with_shared_client (issue #205)."""
    state_path = tmp_path / "state.json"
    messages = [
        FakeAssistantMessage("done", session_id="sess-nt"),
        FakeResultMessage(session_id="sess-nt", num_turns=7),
    ]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.num_turns")

    result = await run_with_shared_client(
        client, "prompt", options, logger=logger, state_path=state_path
    )

    assert result.usage.num_turns == 7


# ---------------------------------------------------------------------------
# AC2: RateLimitEvent → handle_rate_limit_event called, loop continues
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_rate_limit_event_calls_handler_and_continues(tmp_path: Any) -> None:
    """RateLimitEvent → handle_rate_limit_event is called; loop resumes for next message."""
    from unittest.mock import patch

    state_path = tmp_path / "state.json"
    rate_limit_event = FakeRateLimitEvent(FakeRateLimitInfo(status="allowed"))
    messages = [
        rate_limit_event,
        FakeAssistantMessage("after rate limit"),
        FakeResultMessage(),
    ]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.ratelimit")

    with patch("code_generator.runner.sdk_runner.handle_rate_limit_event") as mock_handler:
        result = await run_with_shared_client(
            client, "prompt", options, logger=logger, state_path=state_path
        )

    mock_handler.assert_called_once_with(rate_limit_event, logger, state_path)
    assert result.text == "after rate limit"


# ---------------------------------------------------------------------------
# AC3: ResultMessage with subtype="error_max_turns" → raises MaxTurnsExceeded
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_max_turns_subtype_raises_max_turns_exceeded(tmp_path: Any) -> None:
    """ResultMessage with subtype='error_max_turns' → MaxTurnsExceeded raised."""
    state_path = tmp_path / "state.json"
    messages = [
        FakeAssistantMessage("partial"),
        FakeResultMessage(subtype="error_max_turns"),
    ]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.max_turns")

    with pytest.raises(MaxTurnsExceeded):
        await run_with_shared_client(
            client, "prompt", options, logger=logger, state_path=state_path
        )


# ---------------------------------------------------------------------------
# AC4: ResultMessage with is_error=True → raises ApiUpstreamError
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_is_error_true_raises_api_upstream_error(tmp_path: Any) -> None:
    """ResultMessage with is_error=True → ApiUpstreamError raised."""
    state_path = tmp_path / "state.json"
    messages = [
        FakeAssistantMessage("some output"),
        FakeResultMessage(is_error=True),
    ]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.is_error")

    with pytest.raises(ApiUpstreamError):
        await run_with_shared_client(
            client, "prompt", options, logger=logger, state_path=state_path
        )


# ---------------------------------------------------------------------------
# AC5: accumulated text matches assistant chunks in order
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_accumulated_text_matches_assistant_chunks_in_order(tmp_path: Any) -> None:
    """Multiple AssistantMessages are accumulated in order into RunResult.text."""
    state_path = tmp_path / "state.json"
    messages = [
        FakeAssistantMessage("chunk one "),
        FakeAssistantMessage("chunk two "),
        FakeAssistantMessage("chunk three"),
        FakeResultMessage(),
    ]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.accumulate")

    result = await run_with_shared_client(
        client, "prompt", options, logger=logger, state_path=state_path
    )

    assert result.text == "chunk one chunk two chunk three"


# ---------------------------------------------------------------------------
# AC6: token accounting round-trips from ResultMessage into RunResult.usage
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_token_accounting_round_trips_from_result_message(tmp_path: Any) -> None:
    """usage.input/output/cache_read/cache_write round-trip from ResultMessage."""
    state_path = tmp_path / "state.json"
    messages = [
        FakeAssistantMessage("text"),
        FakeResultMessage(
            input_tokens=200,
            output_tokens=75,
            cache_read=40,
            cache_write=60,
        ),
    ]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.tokens")

    result = await run_with_shared_client(
        client, "prompt", options, logger=logger, state_path=state_path
    )

    assert result.usage.input == 200
    assert result.usage.output == 75
    assert result.usage.cache_read == 40
    assert result.usage.cache_write == 60


# ---------------------------------------------------------------------------
# AC7: does NOT call __aenter__ or __aexit__ (lifecycle is caller-owned)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_does_not_call_client_lifecycle_methods(tmp_path: Any) -> None:
    """run_with_shared_client must not call __aenter__ or __aexit__ on the client."""
    state_path = tmp_path / "state.json"
    messages = [FakeAssistantMessage("ok"), FakeResultMessage()]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.lifecycle")

    await run_with_shared_client(client, "prompt", options, logger=logger, state_path=state_path)

    assert not client._aenter_called, "__aenter__ must not be called"
    assert not client._aexit_called, "__aexit__ must not be called"


# ---------------------------------------------------------------------------
# AC8: does NOT strip env vars (env is caller-managed)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_does_not_strip_env_vars(tmp_path: Any) -> None:
    """run_with_shared_client must not call env.strip_dangerous_env()."""
    from unittest.mock import patch

    state_path = tmp_path / "state.json"
    messages = [FakeAssistantMessage("ok"), FakeResultMessage()]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.no_env_strip")

    with patch("code_generator.runner.sdk_runner._env") as mock_env:
        await run_with_shared_client(
            client, "prompt", options, logger=logger, state_path=state_path
        )

    mock_env.strip_dangerous_env.assert_not_called()


# ---------------------------------------------------------------------------
# AC9: does NOT set permission_mode on options
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_does_not_set_permission_mode_on_options(tmp_path: Any) -> None:
    """run_with_shared_client must not mutate options.permission_mode."""
    state_path = tmp_path / "state.json"
    messages = [FakeAssistantMessage("ok"), FakeResultMessage()]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.no_permission_mode")

    # permission_mode is a MagicMock attr — track whether it was set
    del options.permission_mode  # remove default mock attr so assignment is detectable

    await run_with_shared_client(client, "prompt", options, logger=logger, state_path=state_path)

    assert not hasattr(options, "permission_mode") or options.permission_mode != "bypassPermissions"


# ---------------------------------------------------------------------------
# AC10: RunResult shape is identical to run() output (same fields)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_result_shape_has_text_session_id_usage(tmp_path: Any) -> None:
    """RunResult from run_with_shared_client has text, session_id, and usage fields."""
    state_path = tmp_path / "state.json"
    messages = [FakeAssistantMessage("hello", session_id="s-42"), FakeResultMessage("s-42")]
    client = _make_fake_client(messages)
    options = _make_options()
    logger = logging.getLogger("test.shared.shape")

    result = await run_with_shared_client(
        client, "prompt", options, logger=logger, state_path=state_path
    )

    assert hasattr(result, "text")
    assert hasattr(result, "session_id")
    assert hasattr(result, "usage")
    assert result.session_id == "s-42"
