"""Tests for phase2_review.run_batch — Issue #198.

TDD: Red → Green → Refactor.
All tests are unit/integration tests with mocked batch API and runner.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase2_review
from code_generator.runner.batch import BatchId, BatchResult, BatchSubmitError

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_state_with_issues(
    tmp_path: Path,
    numbers: list[int],
    *,
    session_mode: str = "batch",
    reviewed_numbers: set[int] | None = None,
    batch_id: str | None = None,
) -> _state.State:
    reviewed_numbers = reviewed_numbers or set()
    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    from code_generator.repo_info import RepoInfo

    st = _state.load_state(state_dir / "missing.json")
    st.session_mode = session_mode  # type: ignore[assignment]
    st.repo = RepoInfo(host="github.com", owner="test-owner", name="test-repo")
    st.issues = [
        _state.IssueState(
            number=n,
            status="open",
            agent="python-pro",
            reviewed=(n in reviewed_numbers),
        )
        for n in numbers
    ]
    if batch_id is not None:
        st.phase2_batch_id = batch_id
    _state.save_state(state_dir / "state.json", st)
    return st


def _make_run_result():
    from code_generator.runner.sdk_runner import RunResult

    return RunResult(text="reviewed", session_id=None, tokens_in=None, tokens_out=None)


def _make_batch_result(issue_number: int) -> BatchResult:
    return BatchResult(
        custom_id=f"phase2-issue-{issue_number}",
        result={"type": "succeeded"},
    )


# ---------------------------------------------------------------------------
# Unit Test 1: batch mode invokes submit_batch once with N-1 requests
# ---------------------------------------------------------------------------


class TestBatchModeSubmitsNMinusOne:
    @pytest.mark.asyncio
    async def test_three_issues_submits_two_requests(self, tmp_path: Path) -> None:
        """3 open issues → submit_batch called once with 2 BatchRequests (issues 2 and 3).

        The warm-up (issue 1) is processed via the regular runner.
        Issue 1 custom_id must NOT appear in the submitted batch requests.
        """
        state = _make_state_with_issues(tmp_path, [1, 2, 3])

        captured_requests: list = []

        async def fake_submit_batch(requests):
            captured_requests.extend(requests)
            return BatchId("msgbatch_test")

        async def fake_poll_batch(batch_id, **kw):
            return [_make_batch_result(2), _make_batch_result(3)]

        async def fake_with_backoff(factory, *, breaker, **kw):
            return await factory()

        async def fake_run_one_review(*args, **kwargs):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.submit_batch",
                side_effect=fake_submit_batch,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.poll_batch",
                side_effect=fake_poll_batch,
            ),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch(
                "code_generator.orchestrator.phase2_review._run_one_review",
                side_effect=fake_run_one_review,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.fetch_formatted_comments",
                return_value="",
            ),
        ):
            await phase2_review.run_batch(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # submit_batch called with exactly 2 requests (issues 2 and 3)
        assert len(captured_requests) == 2
        custom_ids = {r.custom_id for r in captured_requests}
        assert "phase2-issue-2" in custom_ids
        assert "phase2-issue-3" in custom_ids
        # Issue 1 (warm-up) is NOT in the batch
        assert "phase2-issue-1" not in custom_ids
        # All three issues are marked reviewed
        assert all(i.reviewed for i in state.issues)

    @pytest.mark.asyncio
    async def test_warmup_issue_processed_via_regular_runner(self, tmp_path: Path) -> None:
        """The warm-up issue (first one) is processed via with_backoff / _run_one_review."""
        state = _make_state_with_issues(tmp_path, [10, 20, 30])

        warmup_calls: list[int] = []

        async def fake_submit_batch(requests):
            return BatchId("msgbatch_warmup_test")

        async def fake_poll_batch(batch_id, **kw):
            return [_make_batch_result(20), _make_batch_result(30)]

        async def fake_with_backoff(factory, *, breaker, **kw):
            result = await factory()
            warmup_calls.append(1)
            return result

        async def fake_run_one_review(*args, **kwargs):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.submit_batch",
                side_effect=fake_submit_batch,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.poll_batch",
                side_effect=fake_poll_batch,
            ),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch(
                "code_generator.orchestrator.phase2_review._run_one_review",
                side_effect=fake_run_one_review,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.fetch_formatted_comments",
                return_value="",
            ),
        ):
            await phase2_review.run_batch(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # with_backoff was called once (for the warm-up issue only)
        assert len(warmup_calls) == 1


# ---------------------------------------------------------------------------
# Unit Test 2: submit_batch failure → WARNING + fallback
# ---------------------------------------------------------------------------


class TestBatchSubmitFailureFallback:
    @pytest.mark.asyncio
    async def test_submit_error_logs_warning_and_falls_back(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """When submit_batch raises BatchSubmitError: WARNING logged, fallback runs, all reviewed."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])

        async def fake_submit_batch(requests):
            raise BatchSubmitError("network error")

        async def fake_with_backoff(factory, *, breaker, **kw):
            return await factory()

        async def fake_run_one_review(*args, **kwargs):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.submit_batch",
                side_effect=fake_submit_batch,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.poll_batch",
            ) as mock_poll,
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch(
                "code_generator.orchestrator.phase2_review._run_one_review",
                side_effect=fake_run_one_review,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.fetch_formatted_comments",
                return_value="",
            ),
            caplog.at_level(logging.WARNING),
        ):
            await phase2_review.run_batch(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # WARNING was logged
        warning_msgs = [m for m in caplog.messages if "submit_batch failed" in m]
        assert warning_msgs, "Expected a WARNING about submit_batch failure"

        # poll_batch was NOT called after the submit failure
        mock_poll.assert_not_called()

        # phase2_batch_id stays None
        assert state.phase2_batch_id is None

        # All 3 issues are marked reviewed via fallback
        assert all(i.reviewed for i in state.issues)


# ---------------------------------------------------------------------------
# Unit Test 3: --continue with stored phase2_batch_id skips re-submission
# ---------------------------------------------------------------------------


class TestContinueWithStoredBatchId:
    @pytest.mark.asyncio
    async def test_stored_batch_id_skips_submit_and_polls(self, tmp_path: Path) -> None:
        """When target.phase2_batch_id is already set, submit_batch is NOT called.

        poll_batch IS called with the stored batch_id.
        Remaining unreviewed issues (2 and 3) are marked reviewed.
        """
        state = _make_state_with_issues(
            tmp_path,
            [1, 2, 3],
            reviewed_numbers={1},
            batch_id="msgbatch_stored",
        )

        polled_ids: list[str] = []

        async def fake_poll_batch(batch_id, **kw):
            polled_ids.append(str(batch_id))
            return [_make_batch_result(2), _make_batch_result(3)]

        with (
            patch(
                "code_generator.orchestrator.phase2_review.submit_batch",
            ) as mock_submit,
            patch(
                "code_generator.orchestrator.phase2_review.poll_batch",
                side_effect=fake_poll_batch,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.fetch_formatted_comments",
                return_value="",
            ),
        ):
            await phase2_review.run_batch(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # submit_batch was NOT called
        mock_submit.assert_not_called()

        # poll_batch was called with the stored batch_id
        assert polled_ids == ["msgbatch_stored"]

        # All remaining issues (2 and 3) are now reviewed
        issue_map = {i.number: i for i in state.issues}
        assert issue_map[2].reviewed is True
        assert issue_map[3].reviewed is True

        # phase2_batch_id cleared after success
        assert state.phase2_batch_id is None


# ---------------------------------------------------------------------------
# Unit Test 4: State.session_mode = "batch" round-trips through save/load
# ---------------------------------------------------------------------------


class TestStateSessionModeBatchRoundTrip:
    def test_batch_mode_saves_and_loads(self, tmp_path: Path) -> None:
        """State with session_mode='batch' and phase2_batch_id round-trips correctly."""
        state_path = tmp_path / ".code-generator" / "state.json"
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            session_mode="batch",  # type: ignore[arg-type]
            phase2_batch_id="msgbatch_xyz",
        )
        _state.save_state(state_path, st)

        loaded = _state.load_state(state_path)

        assert loaded.session_mode == "batch"
        assert loaded.phase2_batch_id == "msgbatch_xyz"

    def test_batch_mode_persisted_in_json(self, tmp_path: Path) -> None:
        """The raw JSON file contains session_mode='batch' and phase2_batch_id."""
        state_path = tmp_path / ".code-generator" / "state.json"
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            session_mode="batch",  # type: ignore[arg-type]
            phase2_batch_id="msgbatch_xyz",
        )
        _state.save_state(state_path, st)

        raw = json.loads(state_path.read_text())
        assert raw["session_mode"] == "batch"
        assert raw["phase2_batch_id"] == "msgbatch_xyz"


# ---------------------------------------------------------------------------
# Unit Test 5: assert_session_mode_compatible pairwise matrix
# ---------------------------------------------------------------------------


class TestAssertSessionModeCompatibleMatrix:
    def _make_state_with_mode(self, mode: str) -> _state.State:
        st = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            session_mode=mode,  # type: ignore[arg-type]
        )
        return st

    def test_batch_stored_shared_requested_raises(self) -> None:
        """stored=batch + requested=shared → ValueError."""
        st = self._make_state_with_mode("batch")
        with pytest.raises(ValueError, match="--session-mode=batch"):
            _state.assert_session_mode_compatible(st, "shared")

    def test_batch_stored_fresh_requested_raises(self) -> None:
        """stored=batch + requested=fresh → ValueError."""
        st = self._make_state_with_mode("batch")
        with pytest.raises(ValueError, match="--session-mode=batch"):
            _state.assert_session_mode_compatible(st, "fresh")

    def test_shared_stored_batch_requested_raises(self) -> None:
        """stored=shared + requested=batch → ValueError."""
        st = self._make_state_with_mode("shared")
        with pytest.raises(ValueError, match="--session-mode=shared"):
            _state.assert_session_mode_compatible(st, "batch")

    def test_batch_stored_batch_requested_ok(self) -> None:
        """stored=batch + requested=batch → no error."""
        st = self._make_state_with_mode("batch")
        _state.assert_session_mode_compatible(st, "batch")  # must not raise

    def test_fresh_stored_batch_requested_raises(self) -> None:
        """stored=fresh + requested=batch → ValueError (existing guard extended)."""
        st = self._make_state_with_mode("fresh")
        with pytest.raises(ValueError, match="--session-mode=fresh"):
            _state.assert_session_mode_compatible(st, "batch")

    def test_fresh_stored_fresh_requested_ok(self) -> None:
        """stored=fresh + requested=fresh → no error."""
        st = self._make_state_with_mode("fresh")
        _state.assert_session_mode_compatible(st, "fresh")  # must not raise

    def test_shared_stored_fresh_requested_ok(self) -> None:
        """stored=shared + requested=fresh → no error (one-way guard)."""
        st = self._make_state_with_mode("shared")
        _state.assert_session_mode_compatible(st, "fresh")  # must not raise

    def test_shared_stored_shared_requested_ok(self) -> None:
        """stored=shared + requested=shared → no error."""
        st = self._make_state_with_mode("shared")
        _state.assert_session_mode_compatible(st, "shared")  # must not raise


# ---------------------------------------------------------------------------
# Unit Test 6: N=1 degrades to plain fresh (no batch)
# ---------------------------------------------------------------------------


class TestNEqualsOneDegradesToFresh:
    @pytest.mark.asyncio
    async def test_single_issue_no_batch_submitted(self, tmp_path: Path) -> None:
        """When N=1, submit_batch is NOT called and the single issue is reviewed normally."""
        state = _make_state_with_issues(tmp_path, [42])

        async def fake_with_backoff(factory, *, breaker, **kw):
            return await factory()

        async def fake_run_one_review(*args, **kwargs):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.submit_batch",
            ) as mock_submit,
            patch(
                "code_generator.orchestrator.phase2_review.poll_batch",
            ) as mock_poll,
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch(
                "code_generator.orchestrator.phase2_review._run_one_review",
                side_effect=fake_run_one_review,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.fetch_formatted_comments",
                return_value="",
            ),
        ):
            await phase2_review.run_batch(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_submit.assert_not_called()
        mock_poll.assert_not_called()
        assert state.issues[0].reviewed is True
        assert state.phase2_batch_id is None


# ---------------------------------------------------------------------------
# Integration Test: full batch-mode cycle Phase 2 with mocked client
# ---------------------------------------------------------------------------


class TestBatchModeIntegration:
    @pytest.mark.asyncio
    async def test_full_batch_cycle_three_issues(self, tmp_path: Path) -> None:
        """Full integration: 3 issues in batch mode → all reviewed, batch_id cleared.

        Arrange: state with 3 open issues in 'batch' session_mode (single mode)
        Act: run_batch with mocked submit_batch + poll_batch
        Assert:
          - all 3 issues have reviewed=True
          - state.phase2_batch_id is None (cleared after success)
          - submit_batch was called once with 2 requests (issues 2 and 3)
        """
        state = _make_state_with_issues(tmp_path, [1, 2, 3])
        state_path = tmp_path / ".code-generator" / "state.json"

        submit_call_count = 0
        captured_batch_requests: list = []

        async def fake_submit_batch(requests):
            nonlocal submit_call_count
            submit_call_count += 1
            captured_batch_requests.extend(requests)
            return BatchId("msgbatch_integration")

        async def fake_poll_batch(batch_id, **kw):
            return [_make_batch_result(2), _make_batch_result(3)]

        async def fake_with_backoff(factory, *, breaker, **kw):
            return await factory()

        async def fake_run_one_review(*args, **kwargs):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.submit_batch",
                side_effect=fake_submit_batch,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.poll_batch",
                side_effect=fake_poll_batch,
            ),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch(
                "code_generator.orchestrator.phase2_review._run_one_review",
                side_effect=fake_run_one_review,
            ),
            patch(
                "code_generator.orchestrator.phase2_review.fetch_formatted_comments",
                return_value="",
            ),
        ):
            await phase2_review.run_batch(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # All 3 issues reviewed
        assert all(i.reviewed for i in state.issues), "All issues must be reviewed"

        # phase2_batch_id cleared
        assert state.phase2_batch_id is None

        # submit_batch called exactly once with 2 requests
        assert submit_call_count == 1
        assert len(captured_batch_requests) == 2
        ids = {r.custom_id for r in captured_batch_requests}
        assert ids == {"phase2-issue-2", "phase2-issue-3"}

        # Reloaded state reflects final reviewed=True
        reloaded = _state.load_state(state_path)
        assert all(i.reviewed for i in reloaded.issues)

    @pytest.mark.asyncio
    async def test_run_dispatches_to_run_batch_when_session_mode_is_batch(
        self, tmp_path: Path
    ) -> None:
        """phase2_review.run() must dispatch to run_batch when session_mode='batch'."""
        state = _make_state_with_issues(tmp_path, [1, 2])

        run_batch_called = False

        async def fake_run_batch(st, cycle, project_dir, **kw):
            nonlocal run_batch_called
            run_batch_called = True

        with patch.object(phase2_review, "run_batch", side_effect=fake_run_batch):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert run_batch_called


# ---------------------------------------------------------------------------
# CycleState.phase2_batch_id round-trip
# ---------------------------------------------------------------------------


class TestCycleStateBatchIdRoundTrip:
    def test_cycle_phase2_batch_id_saves_and_loads(self, tmp_path: Path) -> None:
        """CycleState.phase2_batch_id round-trips through save/load."""
        state_path = tmp_path / ".code-generator" / "state.json"
        cycle = _state.CycleState(
            id=1,
            name="Test",
            milestone_number=1,
            milestone_title="Test",
            status="open",
            phase=1,
            issues=[],
            commit_sha=None,
            phase2_batch_id="msgbatch_cycle_test",
        )
        st = _state.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            cycles=[cycle],
        )
        _state.save_state(state_path, st)

        loaded = _state.load_state(state_path)
        loaded_cycle = loaded.cycles[0]
        assert isinstance(loaded_cycle, _state.CycleState)
        assert loaded_cycle.phase2_batch_id == "msgbatch_cycle_test"
