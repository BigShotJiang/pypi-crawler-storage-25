"""Tests for runner/types.py — Issue #62.

Verifies that all shared runner types are importable from runner.types
and that backward-compatible re-exports still work from the original modules.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Importability from runner.types (primary source)
# ---------------------------------------------------------------------------


def test_overage_abort_importable_from_types() -> None:
    from code_generator.runner.types import OverageAbort

    assert issubclass(OverageAbort, RuntimeError)


def test_rate_limit_hit_importable_from_types() -> None:
    from code_generator.runner.types import RateLimitHit

    hit = RateLimitHit(resets_at=9999, rate_limit_type="five_hour")
    assert hit.resets_at == 9999
    assert hit.rate_limit_type == "five_hour"


def test_api_upstream_error_importable_from_types() -> None:
    from code_generator.runner.types import ApiUpstreamError

    assert issubclass(ApiUpstreamError, RuntimeError)


def test_run_result_importable_from_types() -> None:
    from code_generator.runner.types import RunResult

    result = RunResult(text="hello", session_id="s1", tokens_in=10, tokens_out=20)
    assert result.text == "hello"
    assert result.session_id == "s1"
    assert result.tokens_in == 10
    assert result.tokens_out == 20


def test_transient_runner_error_importable_from_types() -> None:
    from code_generator.runner.types import TransientRunnerError

    assert issubclass(TransientRunnerError, RuntimeError)


# ---------------------------------------------------------------------------
# Backward-compatible re-exports from sdk_runner
# ---------------------------------------------------------------------------


def test_overage_abort_reexported_from_sdk_runner() -> None:
    from code_generator.runner import types
    from code_generator.runner.sdk_runner import OverageAbort

    assert OverageAbort is types.OverageAbort


def test_rate_limit_hit_reexported_from_sdk_runner() -> None:
    from code_generator.runner import types
    from code_generator.runner.sdk_runner import RateLimitHit

    assert RateLimitHit is types.RateLimitHit


def test_api_upstream_error_reexported_from_sdk_runner() -> None:
    from code_generator.runner import types
    from code_generator.runner.sdk_runner import ApiUpstreamError

    assert ApiUpstreamError is types.ApiUpstreamError


def test_run_result_reexported_from_sdk_runner() -> None:
    from code_generator.runner import types
    from code_generator.runner.sdk_runner import RunResult

    assert RunResult is types.RunResult


# ---------------------------------------------------------------------------
# Backward-compatible re-exports from subprocess_runner
# ---------------------------------------------------------------------------


def test_overage_abort_reexported_from_subprocess_runner() -> None:
    from code_generator.runner import types
    from code_generator.runner.subprocess_runner import OverageAbort

    assert OverageAbort is types.OverageAbort


def test_rate_limit_hit_reexported_from_subprocess_runner() -> None:
    from code_generator.runner import types
    from code_generator.runner.subprocess_runner import RateLimitHit

    assert RateLimitHit is types.RateLimitHit


def test_api_upstream_error_reexported_from_subprocess_runner() -> None:
    from code_generator.runner import types
    from code_generator.runner.subprocess_runner import ApiUpstreamError

    assert ApiUpstreamError is types.ApiUpstreamError


def test_run_result_reexported_from_subprocess_runner() -> None:
    from code_generator.runner import types
    from code_generator.runner.subprocess_runner import RunResult

    assert RunResult is types.RunResult


# ---------------------------------------------------------------------------
# Backward-compatible re-exports from runner package __init__
# ---------------------------------------------------------------------------


def test_types_importable_from_runner_package() -> None:
    from code_generator.runner import (
        ApiUpstreamError,
        OverageAbort,
        RateLimitHit,
        RunResult,
        TransientRunnerError,
    )
    from code_generator.runner.types import (
        ApiUpstreamError as T_ApiUpstreamError,
    )
    from code_generator.runner.types import (
        OverageAbort as T_OverageAbort,
    )
    from code_generator.runner.types import (
        RateLimitHit as T_RateLimitHit,
    )
    from code_generator.runner.types import (
        RunResult as T_RunResult,
    )
    from code_generator.runner.types import (
        TransientRunnerError as T_TransientRunnerError,
    )

    assert OverageAbort is T_OverageAbort
    assert RateLimitHit is T_RateLimitHit
    assert ApiUpstreamError is T_ApiUpstreamError
    assert RunResult is T_RunResult
    assert TransientRunnerError is T_TransientRunnerError


# ---------------------------------------------------------------------------
# No circular imports — importing types must not trigger sdk_runner import
# ---------------------------------------------------------------------------


def test_no_circular_imports() -> None:
    """All runner sub-modules can be imported without errors."""
    import importlib

    for module_name in (
        "code_generator.runner.types",
        "code_generator.runner.sdk_runner",
        "code_generator.runner.subprocess_runner",
        "code_generator.runner.rate_limit",
        "code_generator.runner.retry",
    ):
        mod = importlib.import_module(module_name)
        assert mod is not None


# ---------------------------------------------------------------------------
# Identity checks: rate_limit and retry use types from runner.types
# ---------------------------------------------------------------------------


def test_rate_limit_uses_types_from_runner_types() -> None:
    import inspect

    import code_generator.runner.rate_limit as rl
    from code_generator.runner.types import ApiUpstreamError, OverageAbort, RateLimitHit

    # rate_limit source should not reference sdk_runner directly
    source = inspect.getsource(rl)
    assert "from code_generator.runner.sdk_runner" not in source
    # The exceptions used in rate_limit should be the same objects from types
    assert OverageAbort is OverageAbort  # noqa: PLR0124 (identity sanity)
    assert RateLimitHit is RateLimitHit  # noqa: PLR0124
    assert ApiUpstreamError is ApiUpstreamError  # noqa: PLR0124


def test_retry_uses_types_from_runner_types() -> None:
    import inspect

    import code_generator.runner.retry as retry
    from code_generator.runner.types import OverageAbort, RateLimitHit, TransientRunnerError

    source = inspect.getsource(retry)
    assert "from code_generator.runner.sdk_runner" not in source
    assert TransientRunnerError is TransientRunnerError  # noqa: PLR0124
    assert OverageAbort is OverageAbort  # noqa: PLR0124
    assert RateLimitHit is RateLimitHit  # noqa: PLR0124


# ---------------------------------------------------------------------------
# RateLimitHit str representation
# ---------------------------------------------------------------------------


def test_rate_limit_hit_str_representation() -> None:
    from code_generator.runner.types import RateLimitHit

    hit = RateLimitHit(resets_at=1_700_000_000, rate_limit_type="five_hour")
    assert "1700000000" in str(hit)
    assert "five_hour" in str(hit)


# ---------------------------------------------------------------------------
# MaxTurnsExceeded — Issue #206 docstring guard
# ---------------------------------------------------------------------------


def test_max_turns_exceeded_docstring_flags_production_surprise() -> None:
    """Issue #206: docstring must note that a production fire indicates a bug
    or explicit operator override, not a recoverable outcome."""
    from code_generator.runner.types import MaxTurnsExceeded

    doc = MaxTurnsExceeded.__doc__ or ""
    lowered = doc.lower()
    assert "production" in lowered
    assert "bug" in lowered or "surprise" in lowered or "unexpected" in lowered
    assert "operator override" in lowered or "--max-turns" in lowered


# ---------------------------------------------------------------------------
# RunResult with TokenUsage — Issue #117
# ---------------------------------------------------------------------------


def test_run_result_has_usage_field() -> None:
    """RunResult.usage is a TokenUsage instance."""
    from code_generator.runner.types import RunResult, TokenUsage

    result = RunResult(text="hello", session_id="s1", usage=TokenUsage(input=5, output=3))
    assert isinstance(result.usage, TokenUsage)


def test_run_result_usage_default_is_zero() -> None:
    """When no usage is given, RunResult.usage is a zero-initialized TokenUsage."""
    from code_generator.runner.types import RunResult, TokenUsage

    result = RunResult(text="hello", session_id=None)
    assert result.usage == TokenUsage()
    assert result.usage.input == 0
    assert result.usage.output == 0
    assert result.usage.cache_read == 0
    assert result.usage.cache_write == 0


def test_run_result_tokens_in_property_returns_usage_input() -> None:
    """result.tokens_in delegates to result.usage.input."""
    from code_generator.runner.types import RunResult, TokenUsage

    result = RunResult(text="x", session_id=None, usage=TokenUsage(input=7, output=3))
    assert result.tokens_in == 7


def test_run_result_tokens_out_property_returns_usage_output() -> None:
    """result.tokens_out delegates to result.usage.output."""
    from code_generator.runner.types import RunResult, TokenUsage

    result = RunResult(text="x", session_id=None, usage=TokenUsage(input=7, output=3))
    assert result.tokens_out == 3


def test_run_result_new_style_construction() -> None:
    """New-style: RunResult(text=..., usage=TokenUsage(...)) works correctly."""
    from code_generator.runner.types import RunResult, TokenUsage

    usage = TokenUsage(input=10, output=20, cache_read=5, cache_write=2)
    result = RunResult(text="output", session_id="abc", usage=usage)
    assert result.usage.input == 10
    assert result.usage.output == 20
    assert result.usage.cache_read == 5
    assert result.usage.cache_write == 2


def test_run_result_old_style_construction_with_tokens_in_out() -> None:
    """Old-style: RunResult(text=..., tokens_in=10, tokens_out=20) populates usage."""
    from code_generator.runner.types import RunResult, TokenUsage

    result = RunResult(text="x", session_id=None, tokens_in=10, tokens_out=20)
    assert result.usage == TokenUsage(input=10, output=20)
    assert result.tokens_in == 10
    assert result.tokens_out == 20


def test_run_result_old_and_new_style_equivalent() -> None:
    """Old-style and new-style construction produce equivalent usage objects."""
    from code_generator.runner.types import RunResult, TokenUsage

    old = RunResult(text="y", session_id="s", tokens_in=5, tokens_out=3)
    new = RunResult(text="y", session_id="s", usage=TokenUsage(input=5, output=3))
    assert old.usage == new.usage


def test_run_result_old_style_none_tokens() -> None:
    """Old-style with None tokens treats them as 0 in usage."""
    from code_generator.runner.types import RunResult, TokenUsage

    result = RunResult(text="z", session_id=None, tokens_in=None, tokens_out=None)
    assert result.usage == TokenUsage()
    assert result.tokens_in == 0
    assert result.tokens_out == 0


def test_run_result_tokens_in_is_a_property_not_an_instance_attribute() -> None:
    """tokens_in and tokens_out are read-only properties on the class, not stored instance attrs."""
    from code_generator.runner.types import RunResult

    assert isinstance(RunResult.tokens_in, property)
    assert isinstance(RunResult.tokens_out, property)

    result = RunResult(text="x", session_id=None, tokens_in=5, tokens_out=3)
    # usage IS an instance attribute; tokens_in/tokens_out are NOT
    assert "usage" in result.__dict__
    assert "tokens_in" not in result.__dict__
    assert "tokens_out" not in result.__dict__


# ---------------------------------------------------------------------------
# TokenUsage.num_turns — Issue #204
# ---------------------------------------------------------------------------


def test_token_usage_num_turns_defaults_to_zero() -> None:
    """TokenUsage() without args leaves num_turns at 0."""
    from code_generator.runner.types import TokenUsage

    assert TokenUsage().num_turns == 0


def test_token_usage_constructors_without_num_turns_still_work() -> None:
    """Existing callers that construct TokenUsage without num_turns keep working."""
    from code_generator.runner.types import TokenUsage

    usage = TokenUsage(input=10, output=20, cache_read=5, cache_write=2)

    assert usage.input == 10
    assert usage.output == 20
    assert usage.cache_read == 5
    assert usage.cache_write == 2
    assert usage.num_turns == 0


def test_token_usage_accepts_num_turns_kwarg() -> None:
    """TokenUsage(num_turns=N) records the turn count."""
    from code_generator.runner.types import TokenUsage

    usage = TokenUsage(num_turns=7)

    assert usage.num_turns == 7
