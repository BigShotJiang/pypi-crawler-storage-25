"""Per-call-site guards that no phase module or entry-point command passes a
``max_turns=<int>`` literal to ``make_agent_options`` (issue #208).

These are static checks: we parse each source file with :mod:`ast` and inspect
every ``make_agent_options(...)`` call for a ``max_turns`` keyword argument.
That gives us one deterministic per-module assertion without having to stand
up full phase invocation contexts.

A whole-tree regex guard for the same invariant lives in
``tests/test_no_max_turns_literal.py`` (issue #209); the per-module AST checks
here add semantic precision — they fail only when the literal lands on a
``make_agent_options`` call, which is where the silent turn cap would ship.

The kwargs-signature of ``make_agent_options`` is preserved (``**kwargs``
forwards ``max_turns``) so the ``--max-turns`` opt-in path landing in #210
still has a wiring target.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

SRC_ROOT = Path(__file__).resolve().parent.parent / "src" / "code_generator"
ORCHESTRATOR_DIR = SRC_ROOT / "orchestrator"
COMMANDS_DIR = SRC_ROOT / "commands"


# ---------------------------------------------------------------------------
# AST helper
# ---------------------------------------------------------------------------


def _max_turns_literal_sites(path: Path) -> list[tuple[int, str]]:
    """Return ``(lineno, code)`` for each ``make_agent_options(..., max_turns=<int>)``.

    An empty list means the file has no literal-integer ``max_turns`` kwarg on
    any ``make_agent_options`` call.
    """
    tree = ast.parse(path.read_text(encoding="utf-8"))
    hits: list[tuple[int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        name = getattr(func, "attr", None) or getattr(func, "id", None)
        if name != "make_agent_options":
            continue
        for kw in node.keywords:
            if (
                kw.arg == "max_turns"
                and isinstance(kw.value, ast.Constant)
                and isinstance(kw.value.value, int)
            ):
                hits.append((node.lineno, f"max_turns={kw.value.value}"))
    return hits


# ---------------------------------------------------------------------------
# Per-module tests — one per file listed in #208's scope table
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "relative_path",
    [
        "orchestrator/phase0_complexity.py",
        "orchestrator/phase1_plan.py",
        "orchestrator/phase2_review.py",
        "orchestrator/phase3_4_implement.py",
        "orchestrator/phase5_closure.py",
        "orchestrator/phase6_test.py",
        "orchestrator/phase7_commit.py",
        "commands/optimize.py",
        "commands/review.py",
    ],
)
def test_module_does_not_pass_max_turns_literal_to_make_agent_options(
    relative_path: str,
) -> None:
    """AC: no call to make_agent_options() carries a max_turns=<int> literal."""
    path = SRC_ROOT / relative_path
    hits = _max_turns_literal_sites(path)
    assert not hits, (
        f"{relative_path} still passes a max_turns literal to make_agent_options: "
        + ", ".join(f"line {ln}: {code}" for ln, code in hits)
    )


# ---------------------------------------------------------------------------
# Signature preservation — #210's --max-turns opt-in still has a wiring target
# ---------------------------------------------------------------------------


def test_make_agent_options_still_accepts_max_turns_kwarg() -> None:
    """AC: make_agent_options signature still forwards max_turns (for #210's opt-in)."""
    from code_generator.runner.options import make_agent_options

    # Should not raise — max_turns flows through **kwargs.
    opts = make_agent_options(allowed_tools=["Read"], max_turns=50)
    assert getattr(opts, "max_turns", None) == 50
