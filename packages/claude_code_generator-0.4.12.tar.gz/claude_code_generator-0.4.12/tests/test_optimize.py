"""Tests for the `code-generator optimize` command."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from typer.testing import CliRunner

from code_generator.cli import app
from code_generator.env import DANGEROUS_VARS
from code_generator.runner.retry import CircuitOpen
from code_generator.runner.types import OverageAbort, RunResult, TokenUsage

runner = CliRunner()


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

_NONCANONICAL_CONTENT = """\
# My Project

## Description
Build something cool.

## Tech Stack
Python, FastAPI.

## Goals
- Ship fast.

## Scope

### 1. Auth
Allow users to log in.

## Non-goals
- Mobile apps.

## Global acceptance criteria
- [ ] All tests pass.
"""

_CANONICAL_CONTENT = """\
# My Project

## Description
Build something cool.

## Tech Stack
Python, FastAPI.

## Goals
- Ship fast.

## Scope

### 1. Auth
Allow users to log in.

#### Acceptance criteria
- [ ] Users can log in with email and password.

## Non-goals
- Mobile apps.

## Constraints
- Python 3.11+.

## Global acceptance criteria
- [ ] All tests pass.
"""

_REWRITTEN_CONTENT = """\
# My Project

## Description
Build something cool.

## Tech Stack
Python, FastAPI.

## Goals
- Ship fast.

## Scope

### 1. Auth
Allow users to log in.

#### Acceptance criteria
- [ ] Users can log in with email and password.

## Non-goals
- Mobile apps.

## Constraints
- Must run on Python 3.11+.

## Global acceptance criteria
- [ ] All tests pass.

## Architecture
A new section added by the rewrite.
"""


@pytest.fixture(autouse=True)
def clear_dangerous_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Strip API-key vars so tests run without hitting the env safety check."""
    for var in DANGEROUS_VARS:
        monkeypatch.delenv(var, raising=False)


def _make_result(text: str = _REWRITTEN_CONTENT) -> RunResult:
    return RunResult(
        text=text,
        session_id="sess-optimize",
        usage=TokenUsage(input=100, output=500, cache_read=0, cache_write=0),
    )


def _fake_runner_module(result: RunResult | Exception) -> MagicMock:
    """Return a fake runner module whose run() returns/raises the given value."""
    module = MagicMock()
    if isinstance(result, Exception):
        module.run = AsyncMock(side_effect=result)
    else:
        module.run = AsyncMock(return_value=result)
    return module


def _setup_cg_dir(tmp_path: Path, content: str = _NONCANONICAL_CONTENT) -> Path:
    """Create .code-generator/requirements.md with given content."""
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    (cg_dir / "requirements.md").write_text(content, encoding="utf-8")
    return cg_dir


# ---------------------------------------------------------------------------
# AC 1: --help renders; command listed in root help
# ---------------------------------------------------------------------------


class TestHelp:
    def test_optimize_help_renders(self) -> None:
        """optimize --help renders without error."""
        result = runner.invoke(app, ["optimize", "--help"])
        assert result.exit_code == 0
        assert "--dry-run" in result.output
        assert "--force" in result.output

    def test_optimize_listed_in_root_help(self) -> None:
        """optimize appears in code-generator --help."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "optimize" in result.output


# ---------------------------------------------------------------------------
# AC 2: Non-canonical file runs the SDK and writes result atomically
# ---------------------------------------------------------------------------


class TestNonCanonicalFileRewrite:
    def test_noncanonical_file_calls_runner_and_writes_result(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Running optimize on a non-canonical requirements.md calls the runner and writes the result."""
        monkeypatch.chdir(tmp_path)
        cg_dir = _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        req_path = cg_dir / "requirements.md"
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 0
        assert req_path.read_text(encoding="utf-8") == _REWRITTEN_CONTENT

    def test_written_content_matches_runner_output_byte_for_byte(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The written file content matches the runner output exactly."""
        monkeypatch.chdir(tmp_path)
        cg_dir = _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        expected = "# Rewritten\n\nContent here.\n"
        fake_runner = _fake_runner_module(_make_result(expected))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 0
        written = (cg_dir / "requirements.md").read_text(encoding="utf-8")
        assert written == expected


# ---------------------------------------------------------------------------
# AC 3: --dry-run prints result, leaves file untouched, no backup created
# ---------------------------------------------------------------------------


class TestDryRun:
    def test_dry_run_prints_result_to_stdout(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--dry-run prints the rewrite to stdout."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize", "--dry-run"])

        assert result.exit_code == 0
        assert _REWRITTEN_CONTENT in result.output

    def test_dry_run_leaves_requirements_file_untouched(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--dry-run does not modify .code-generator/requirements.md."""
        monkeypatch.chdir(tmp_path)
        cg_dir = _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        req_path = cg_dir / "requirements.md"
        original_content = req_path.read_text(encoding="utf-8")
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            runner.invoke(app, ["optimize", "--dry-run"])

        assert req_path.read_text(encoding="utf-8") == original_content

    def test_dry_run_creates_no_backup_file(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--dry-run creates no backup file in .code-generator/."""
        monkeypatch.chdir(tmp_path)
        cg_dir = _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            runner.invoke(app, ["optimize", "--dry-run"])

        backups = list(cg_dir.glob("requirements.backup-*.md"))
        assert backups == []


# ---------------------------------------------------------------------------
# AC 4: Canonical short-circuit; --force bypasses it
# ---------------------------------------------------------------------------


class TestCanonicalShortCircuit:
    def test_canonical_file_exits_0_without_invoking_runner(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A canonical requirements.md exits 0 without calling the runner."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _CANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result())

        with patch(
            "code_generator.commands.optimize.get_runner", return_value=fake_runner
        ) as mock_get:
            result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 0
        mock_get.assert_not_called()

    def test_force_flag_bypasses_canonical_short_circuit(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--force causes the runner to be invoked even on a canonical file."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _CANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result())

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize", "--force"])

        assert result.exit_code == 0
        fake_runner.run.assert_called_once()


# ---------------------------------------------------------------------------
# AC 5: Missing files exit non-zero with distinct messages
# ---------------------------------------------------------------------------


class TestMissingFiles:
    def test_missing_requirements_file_exits_nonzero_with_error(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Missing .code-generator/requirements.md exits non-zero with a clear error."""
        monkeypatch.chdir(tmp_path)
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()  # dir exists but requirements.md does not

        result = runner.invoke(app, ["optimize"])

        assert result.exit_code != 0
        assert "requirements.md" in result.output.lower() or "requirements.md" in (
            result.stderr if hasattr(result, "stderr") else ""
        )

    def test_missing_cg_directory_exits_nonzero_with_distinct_error(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Missing .code-generator/ directory exits non-zero with a distinct error message."""
        monkeypatch.chdir(tmp_path)
        # Do NOT create .code-generator/

        result = runner.invoke(app, ["optimize"])

        assert result.exit_code != 0
        combined = result.output + (result.stderr if hasattr(result, "stderr") else "")
        assert ".code-generator" in combined

    def test_missing_cg_dir_and_missing_requirements_have_distinct_messages(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The error for missing .code-generator/ differs from the error for missing requirements.md."""
        monkeypatch.chdir(tmp_path)

        # Error 1: missing .code-generator/
        result_no_dir = runner.invoke(app, ["optimize"])
        error_no_dir = result_no_dir.output

        # Error 2: missing requirements.md only
        cg_dir = tmp_path / ".code-generator"
        cg_dir.mkdir()
        result_no_req = runner.invoke(app, ["optimize"])
        error_no_req = result_no_req.output

        assert error_no_dir != error_no_req


# ---------------------------------------------------------------------------
# AC 6: Backup file created on non-dry-run success; original round-trips
# ---------------------------------------------------------------------------


class TestBackup:
    def test_backup_created_on_success(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A timestamped backup file is created in .code-generator/ on success."""
        monkeypatch.chdir(tmp_path)
        cg_dir = _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 0
        backups = list(cg_dir.glob("requirements.backup-*.md"))
        assert len(backups) == 1

    def test_backup_filename_uses_timestamp_format(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Backup filename matches requirements.backup-<YYYYMMDDTHHMMSSz>.md pattern."""
        import re

        monkeypatch.chdir(tmp_path)
        cg_dir = _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            runner.invoke(app, ["optimize"])

        backups = list(cg_dir.glob("requirements.backup-*.md"))
        assert len(backups) == 1
        pattern = re.compile(r"requirements\.backup-\d{8}T\d{6}Z\.md")
        assert pattern.match(backups[0].name)

    def test_backup_contains_original_content_byte_for_byte(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The backup file contains the original requirements.md content unchanged."""
        monkeypatch.chdir(tmp_path)
        cg_dir = _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            runner.invoke(app, ["optimize"])

        backups = list(cg_dir.glob("requirements.backup-*.md"))
        assert len(backups) == 1
        assert backups[0].read_text(encoding="utf-8") == _NONCANONICAL_CONTENT


# ---------------------------------------------------------------------------
# AC 7: SDK session started with correct model, fresh session, YOLO, sanitized env
# ---------------------------------------------------------------------------


class TestSDKSessionOptions:
    def test_sdk_session_uses_opus_model(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """SDK session is started with model='claude-opus-4-7'."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result())

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            with patch("code_generator.commands.optimize.make_agent_options") as mock_make_opts:
                mock_make_opts.return_value = MagicMock()
                runner.invoke(app, ["optimize"])

        mock_make_opts.assert_called_once()
        call_kwargs = mock_make_opts.call_args[1]
        assert call_kwargs.get("model") == "claude-opus-4-7"

    def test_sdk_session_has_no_resume_on_fresh_start(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Fresh optimize session has no resume (options.resume is None or unset)."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result())

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize"])

        # The run should complete cleanly (no stale session being resumed)
        assert result.exit_code == 0

    def test_assert_safe_environment_called(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """env.assert_safe_environment() is called before the SDK session starts."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result())

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            with patch("code_generator.commands.optimize.env") as mock_env:
                mock_env.assert_safe_environment = MagicMock()
                mock_env.DANGEROUS_VARS = DANGEROUS_VARS
                runner.invoke(app, ["optimize"])

        mock_env.assert_safe_environment.assert_called_once()

    def test_sdk_session_does_not_set_max_turns(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Issue #208: no production call site sets ``max_turns``.

        Previously ``optimize`` hard-coded ``max_turns=20``; after the
        no-default-turn-budget policy (requirements §1) the kwarg is dropped
        so the CLI runs without a turn cap and rate-limit / overage-abort /
        task-budgets act as the real safety nets.
        """
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result())

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            with patch("code_generator.commands.optimize.make_agent_options") as mock_make_opts:
                mock_make_opts.return_value = MagicMock()
                runner.invoke(app, ["optimize"])

        call_kwargs = mock_make_opts.call_args[1]
        assert "max_turns" not in call_kwargs, (
            f"optimize must no longer pass max_turns; got kwargs={call_kwargs}"
        )

    def test_sdk_session_allows_read_tools(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """SDK session has Read/Glob available so the model can inspect context."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result())

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            with patch("code_generator.commands.optimize.make_agent_options") as mock_make_opts:
                mock_make_opts.return_value = MagicMock()
                runner.invoke(app, ["optimize"])

        call_kwargs = mock_make_opts.call_args[1]
        tools = call_kwargs.get("allowed_tools") or []
        # Must be read-only — no Edit/Write/Bash (file is written by Python).
        assert "Read" in tools
        assert "Edit" not in tools
        assert "Write" not in tools
        assert "Bash" not in tools


# ---------------------------------------------------------------------------
# AC 8: OverageAbort → stderr + exit 2
# ---------------------------------------------------------------------------


class TestOverageAbort:
    def test_overage_abort_exits_2(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """OverageAbort from the runner prints an error to stderr and exits with code 2."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(OverageAbort("billing active"))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 2


# ---------------------------------------------------------------------------
# AC 9: CircuitOpen → stderr + exit 1
# ---------------------------------------------------------------------------


class TestCircuitOpen:
    def test_circuit_open_exits_1(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """CircuitOpen from the runner prints an error to stderr and exits with code 1."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(CircuitOpen("circuit tripped"))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# AC 10: Diff summary printed on non-dry-run success
# ---------------------------------------------------------------------------


class TestDiffSummary:
    def test_diff_summary_shows_line_count_changes(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """On success, output contains line count information."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 0
        # Should show line count change
        assert "Lines:" in result.output or "lines" in result.output.lower()

    def test_diff_summary_shows_new_section_titles(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """On success, output contains any new section headings added by the rewrite."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        # _REWRITTEN_CONTENT adds "## Architecture" which wasn't in _NONCANONICAL_CONTENT
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 0
        assert "Architecture" in result.output


# ---------------------------------------------------------------------------
# AC 11: Atomic write via tmp → os.replace
# ---------------------------------------------------------------------------


class TestAtomicWrite:
    def test_atomic_write_no_temp_file_left_behind(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """No leftover .tmp file remains in .code-generator/ after a successful write."""
        monkeypatch.chdir(tmp_path)
        cg_dir = _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result(_REWRITTEN_CONTENT))

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 0
        tmp_files = list(cg_dir.glob("*.tmp"))
        assert tmp_files == []


# ---------------------------------------------------------------------------
# AC 12: Token usage logged
# ---------------------------------------------------------------------------


class TestTokenUsageLogging:
    def test_token_usage_logged_after_session(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Token usage (in/cache_read/cache_write/out) is logged after the session ends."""
        monkeypatch.chdir(tmp_path)
        _setup_cg_dir(tmp_path, _NONCANONICAL_CONTENT)
        fake_runner = _fake_runner_module(_make_result())

        with patch("code_generator.commands.optimize.get_runner", return_value=fake_runner):
            with patch("code_generator.commands.optimize.log_phase_usage") as mock_log:
                result = runner.invoke(app, ["optimize"])

        assert result.exit_code == 0
        mock_log.assert_called_once()
        # Verify the usage argument contains token data
        _, call_args, _ = mock_log.mock_calls[0]
        usage_arg = call_args[2] if len(call_args) > 2 else mock_log.call_args[0][2]
        from code_generator.runner.types import TokenUsage

        assert isinstance(usage_arg, TokenUsage)


# ---------------------------------------------------------------------------
# Prompt loading
# ---------------------------------------------------------------------------


class TestPromptLoading:
    def test_prompt_loads_without_crash(self) -> None:
        """Verify the optimize prompt file is present and substitution works."""
        from code_generator.prompts import load_prompt

        prompt = load_prompt(
            "prompt-optimize-requirements.md",
            CURRENT_REQUIREMENTS="# My Project\n\nSome content.",
        )
        assert len(prompt) > 0
        assert "My Project" in prompt
