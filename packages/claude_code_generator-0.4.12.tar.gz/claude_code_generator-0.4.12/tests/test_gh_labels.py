"""Tests for code_generator.gh.labels — ensure_label, add_label, ensure_standard_labels."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from code_generator.gh.core import GhError
from code_generator.gh.labels import add_label, ensure_label, ensure_standard_labels
from code_generator.repo_info import RepoInfo

_REPO = RepoInfo(host="github.com", owner="test", name="repo")

# ---------------------------------------------------------------------------
# ensure_label
# ---------------------------------------------------------------------------


class TestEnsureLabel:
    def test_creates_label_on_success(self) -> None:
        with patch("code_generator.gh.labels._run", return_value="") as mock_run:
            ensure_label(_REPO, "priority:high", "FF0000", "High priority")
        argv = mock_run.call_args[0][0]
        assert "create" in argv
        assert "priority:high" in argv

    def test_noop_when_already_exists(self) -> None:
        with patch(
            "code_generator.gh.labels._run",
            side_effect=GhError(1, "Label 'priority:high' already exists"),
        ):
            # Should not raise.
            ensure_label(_REPO, "priority:high", "FF0000", "High priority")

    def test_raises_on_other_error(self) -> None:
        with (
            patch(
                "code_generator.gh.labels._run",
                side_effect=GhError(1, "authentication required"),
            ),
            pytest.raises(GhError),
        ):
            ensure_label(_REPO, "priority:high", "FF0000", "High priority")


# ---------------------------------------------------------------------------
# add_label
# ---------------------------------------------------------------------------


class TestAddLabel:
    def test_calls_issue_edit(self) -> None:
        with patch("code_generator.gh.labels._run", return_value="") as mock_run:
            add_label(_REPO, 5, "needs-manual-review")
        argv = mock_run.call_args[0][0]
        assert "issue" in argv
        assert "edit" in argv
        assert "5" in argv
        assert "--add-label" in argv
        assert "needs-manual-review" in argv

    def test_propagates_gh_error_on_failure(self) -> None:
        """add_label propagates GhError when gh issue edit exits non-zero."""
        with (
            patch(
                "code_generator.gh.labels._run",
                side_effect=GhError(1, "issue not found"),
            ),
            pytest.raises(GhError) as exc_info,
        ):
            add_label(_REPO, 999, "some-label")
        assert exc_info.value.returncode == 1
        assert "issue not found" in exc_info.value.stderr


# ---------------------------------------------------------------------------
# ensure_standard_labels
# ---------------------------------------------------------------------------


class TestEnsureStandardLabels:
    def test_creates_expected_priority_labels(self) -> None:
        with patch("code_generator.gh.labels._run", return_value="") as mock_run:
            ensure_standard_labels(_REPO)

        all_calls = [c[0][0] for c in mock_run.call_args_list]
        label_names = [argv[argv.index("create") + 1] for argv in all_calls if "create" in argv]

        assert "priority:high" in label_names
        assert "priority:medium" in label_names
        assert "priority:low" in label_names

    def test_creates_area_labels(self) -> None:
        with patch("code_generator.gh.labels._run", return_value="") as mock_run:
            ensure_standard_labels(_REPO)

        all_calls = [c[0][0] for c in mock_run.call_args_list]
        label_names = [argv[argv.index("create") + 1] for argv in all_calls if "create" in argv]

        for area in ["cli", "orchestrator", "runner", "state", "gh", "tests", "api"]:
            assert f"area:{area}" in label_names

    def test_creates_phase_labels(self) -> None:
        with patch("code_generator.gh.labels._run", return_value="") as mock_run:
            ensure_standard_labels(_REPO)

        all_calls = [c[0][0] for c in mock_run.call_args_list]
        label_names = [argv[argv.index("create") + 1] for argv in all_calls if "create" in argv]

        for phase in ["plan", "implement", "review", "test"]:
            assert f"phase:{phase}" in label_names

    def test_creates_agent_labels_with_7057ff_color(self) -> None:
        with patch("code_generator.gh.labels._run", return_value="") as mock_run:
            ensure_standard_labels(_REPO)

        all_calls = [c[0][0] for c in mock_run.call_args_list]
        agent_label_calls = [
            argv
            for argv in all_calls
            if "create" in argv and any(name.startswith("agent:") for name in argv)
        ]

        assert len(agent_label_calls) > 0
        for argv in agent_label_calls:
            color_idx = argv.index("--color")
            assert argv[color_idx + 1] == "7057FF"

    def test_expected_agents_present(self) -> None:
        with patch("code_generator.gh.labels._run", return_value="") as mock_run:
            ensure_standard_labels(_REPO)

        all_calls = [c[0][0] for c in mock_run.call_args_list]
        label_names = [argv[argv.index("create") + 1] for argv in all_calls if "create" in argv]

        for agent in [
            "agent:python-pro",
            "agent:fastapi-expert-agent",
            "agent:frontend-developer",
            "agent:nestjs-expert",
            "agent:baml-expert-agent",
            "agent:riskfolio-expert",
        ]:
            assert agent in label_names

    def test_idempotent_on_already_exists(self) -> None:
        """Should not raise when all labels already exist."""
        with patch(
            "code_generator.gh.labels._run",
            side_effect=GhError(1, "Label 'x' already exists"),
        ):
            ensure_standard_labels(_REPO)  # Should not raise.
