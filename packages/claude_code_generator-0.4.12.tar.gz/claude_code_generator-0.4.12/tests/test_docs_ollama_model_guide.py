"""Docs guards for docs/ollama-model-guide.md (issue #224).

Requirements §5 mandates a recommendations page that pairs concrete Ollama
model tags with Opus-grade vs. Sonnet-grade workloads and warns operators
that single-model mode cannot reproduce the Opus-reasoning /
Sonnet-implementation split. The guide must also be reachable from
``code-generator generate ollama --help`` so it is discoverable from the CLI.
"""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from code_generator.cli import app

_REPO_ROOT = Path(__file__).resolve().parents[1]
_GUIDE = _REPO_ROOT / "docs" / "ollama-model-guide.md"

_OPUS_GRADE_TAGS = (
    "qwen3-coder:480b:cloud",
    "glm-5.1:cloud",
    "kimi-k2.5:cloud",
    "deepseek-v3.2:cloud",
)
_SONNET_GRADE_TAGS = (
    "devstral-small-2:24b:cloud",
    "qwen3-coder-next:cloud",
    "glm-4.7:cloud",
)


def _guide_text() -> str:
    assert _GUIDE.exists(), f"Missing docs file: {_GUIDE.relative_to(_REPO_ROOT)}"
    return _GUIDE.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# File existence + model tags (AC #1, #4)
# ---------------------------------------------------------------------------


def test_ollama_model_guide_file_exists() -> None:
    assert _GUIDE.exists(), "docs/ollama-model-guide.md must exist at the repo root"


def test_guide_lists_every_opus_grade_tag() -> None:
    text = _guide_text()
    missing = [tag for tag in _OPUS_GRADE_TAGS if tag not in text]
    assert not missing, f"Opus-grade tags missing from the guide: {missing}"


def test_guide_lists_every_sonnet_grade_tag() -> None:
    text = _guide_text()
    missing = [tag for tag in _SONNET_GRADE_TAGS if tag not in text]
    assert not missing, f"Sonnet-grade tags missing from the guide: {missing}"


# ---------------------------------------------------------------------------
# Regression warning (AC #2)
# ---------------------------------------------------------------------------


def test_guide_warns_about_single_model_regression() -> None:
    """The guide must warn that single-model mode will regress on hardest
    reasoning tasks compared to the Opus/Sonnet split."""
    lowered = _guide_text().lower()
    assert "single-model" in lowered or "single model" in lowered
    assert "regress" in lowered or "regression" in lowered or "degrade" in lowered
    assert "opus" in lowered and "sonnet" in lowered, (
        "The warning should explicitly name the Opus/Sonnet split it cannot reproduce"
    )


# ---------------------------------------------------------------------------
# --help discoverability (AC #3)
# ---------------------------------------------------------------------------


def test_ollama_subcommand_help_references_guide() -> None:
    """``code-generator generate ollama --help`` must reference the guide path."""
    runner = CliRunner()
    result = runner.invoke(app, ["generate", "ollama", "--help"])
    assert result.exit_code == 0, result.output
    assert "docs/ollama-model-guide.md" in result.output, (
        "The ollama subcommand's --help must reference docs/ollama-model-guide.md"
    )
